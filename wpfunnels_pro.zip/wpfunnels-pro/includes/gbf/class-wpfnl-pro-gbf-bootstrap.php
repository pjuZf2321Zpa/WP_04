<?php

namespace WPFunnelsPro\GBF;

use WPFunnelsPro\Wpfnl_Pro_Plan;
use WPFunnelsPro\GBF\Actions\Wpfnl_Pro_GB_Actions;
use WPFunnelsPro\GBF\Admin\Modules\GlobalCheckout\Wpfnl_Global_Checkout_Ajax;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Bootstrap class for Global Funnels (GBF) — formerly the standalone
 * wpfunnels-pro-gbf addon.
 *
 * Mirrors the CRM_Integrations bootstrap pattern:
 *  - Always registers admin conditions + assets so entitled users get the UI.
 *  - Gates the actual frontend/checkout logic behind is_gbf_license_active().
 *
 * @since 2.9.1
 * @package WPFunnelsPro\GBF
 */
class Wpfnl_Pro_GBF_Bootstrap {

    public function __construct() {
        // Admin: always register conditions + assets (plan-gated inside enqueue)
        add_filter( 'wpfunnels/supported-addons', [ $this, 'register_trigger_conditions' ], 10, 1 );
        add_filter( 'wpfunnels/supported-gbf-offer-condition', [ $this, 'register_offer_conditions' ], 10, 1 );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        add_action( 'admin_init', [ $this, 'init_admin_ajax' ] );
        add_filter( 'wpfunnels/check_update_transient', [ $this, 'check_update_transient' ] );

        if ( ! Wpfnl_Pro_Plan::is_gbf_license_active() ) {
            return;
        }

        // Frontend: only boot when license grants access
        Wpfnl_Pro_GB_Actions::getInstance();

        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_public_assets' ] );
        add_action( 'wpfunnels/after_init_checkout', [ $this, 'after_init_checkout' ], 10 );

        // REST controllers
        add_filter( 'wpfunnels/rest_api_controllers', [ $this, 'register_controllers' ] );
    }


    /**
     * Register GBF REST API controllers.
     *
     * @param array $controllers
     * @return array
     */
    public function register_controllers( array $controllers ): array {
        $controllers['category']     = 'CategoryController';
        $controllers['product']      = 'ProductController';
        $controllers['globalFunnel'] = 'GlobalFunnelController';
        return $controllers;
    }


    /**
     * Register GBF trigger conditions (used in global funnel condition builder).
     *
     * @param array $addons
     * @return array
     */
    public function register_trigger_conditions( array $addons ): array {
        if ( isset( $addons['global_funnel']['features']['trigger_options'] ) ) {
            $addons['global_funnel']['features']['trigger_options']['not_category']                  = __( 'Product category is not', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['cart_total_equal']              = __( 'Cart total is equal to', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['cart_total_greater']            = __( 'Cart total is greater than', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['cart_total_less']               = __( 'Cart total is less than', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['quantity']                      = __( 'Product quantity is', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['quantity_greater']              = __( 'Product quantity is greater than', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['highest_sold']                  = __( 'Highest Sold product is in the cart', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['least_sold']                    = __( 'Least Sold product is in the cart', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['popular']                       = __( 'Most Popular product is in the cart', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['highest_rating']                = __( 'Highest Rated product is in the cart', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['most_review']                   = __( 'Most reviewed product is in the cart', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['shipping']                      = __( 'Shipping class is', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['tag']                           = __( 'Product Tag is', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['tag_not']                       = __( 'Product Tag is not', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['role']                          = __( 'User Role is', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['dateRange']                     = __( 'Date is within range', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['date']                          = __( 'Date is', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['product_not']                   = __( 'Product is not', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['returningCustomer']             = __( 'User is a returning customer', 'wpfnl-pro' );
            $addons['global_funnel']['features']['trigger_options']['returningCustomerWithRange']    = __( 'User is a returning customer within last X days', 'wpfnl-pro' );
        }
        return $addons;
    }


    /**
     * Register GBF offer conditions (used in upsell/downsell offer selection).
     *
     * @param array $conditions
     * @return array
     */
    public function register_offer_conditions( array $conditions ): array {
        $conditions['_groups'] = [
            'sales_popularity' => __( 'Sales & Popularity', 'wpfnl-pro' ),
            'reviews'          => __( 'Reviews & Ratings', 'wpfnl-pro' ),
            'relationship'     => __( 'Related to Main Product', 'wpfnl-pro' ),
            'price'            => __( 'Price Based', 'wpfnl-pro' ),
            'random'           => __( 'Random Selection', 'wpfnl-pro' ),
            'stock'            => __( 'Stock Based', 'wpfnl-pro' ),
        ];

        // Sales & Popularity
        $conditions['popular']                              = [ 'label' => __( 'Most popular product in store', 'wpfnl-pro' ), 'group' => 'sales_popularity' ];
        $conditions['highestSold']                          = [ 'label' => __( 'Highest sold product in store', 'wpfnl-pro' ), 'group' => 'sales_popularity' ];
        $conditions['highestSoldInsideCategory']            = [ 'label' => __( 'Highest sold product in category', 'wpfnl-pro' ), 'group' => 'sales_popularity' ];
        $conditions['highestSoldInsideTag']                 = [ 'label' => __( 'Highest sold product with tag', 'wpfnl-pro' ), 'group' => 'sales_popularity' ];
        $conditions['leastSold']                            = [ 'label' => __( 'Least sold product in store', 'wpfnl-pro' ), 'group' => 'sales_popularity' ];

        // Reviews
        $conditions['mostReviewedProduct']                  = [ 'label' => __( 'Most reviewed product', 'wpfnl-pro' ), 'group' => 'reviews' ];

        // Relationship
        $conditions['productSameCategory']                  = [ 'label' => __( 'Product from the same category as main order', 'wpfnl-pro' ), 'group' => 'relationship' ];
        $conditions['productSameTag']                       = [ 'label' => __( 'Product with the same tag as main order', 'wpfnl-pro' ), 'group' => 'relationship' ];
        $conditions['productSameAttribute']                 = [ 'label' => __( 'Product with same attribute as main order', 'wpfnl-pro' ), 'group' => 'relationship' ];
        $conditions['productSameAttributeWithinPrice']      = [ 'label' => __( 'Product with same attribute within price range as main order', 'wpfnl-pro' ), 'group' => 'relationship' ];
        $conditions['moreQuantity']                         = [ 'label' => __( 'More quantity of the main product in cart', 'wpfnl-pro' ), 'group' => 'relationship' ];
        $conditions['complementaryProduct']                 = [ 'label' => __( 'Complementary product to main product', 'wpfnl-pro' ), 'group' => 'relationship' ];

        // Price
        $conditions['higherPricedProduct']                  = [ 'label' => __( 'Higher priced product than main order', 'wpfnl-pro' ), 'group' => 'price' ];
        $conditions['lowerPricedProduct']                   = [ 'label' => __( 'Lower priced product than main order', 'wpfnl-pro' ), 'group' => 'price' ];
        $conditions['productPriceDifferenceRange']          = [ 'label' => __( 'Product within price difference range', 'wpfnl-pro' ), 'group' => 'price' ];

        // Random
        $conditions['randomInShop']                         = [ 'label' => __( 'Random product in shop', 'wpfnl-pro' ), 'group' => 'random' ];
        $conditions['randomProduct']                        = [ 'label' => __( 'Random product in category', 'wpfnl-pro' ), 'group' => 'random' ];
        $conditions['randomProductInsideCategoryWithinPrice'] = [ 'label' => __( 'Random product in category within a price range', 'wpfnl-pro' ), 'group' => 'random' ];
        $conditions['randomProductInTag']                   = [ 'label' => __( 'Random product with tag', 'wpfnl-pro' ), 'group' => 'random' ];
        $conditions['randomProductInsideTagWithinPrice']    = [ 'label' => __( 'Random product with tag within a price range', 'wpfnl-pro' ), 'group' => 'random' ];

        return $conditions;
    }


    /**
     * Initialise AJAX handlers for the global-funnel enable/disable toggle.
     */
    public function init_admin_ajax(): void {
        if ( Wpfnl_Pro_Plan::is_gbf_license_active() ) {
            ( new Wpfnl_Global_Checkout_Ajax() )->init();
        }
    }


    /**
     * Enqueue admin assets on WPFunnels admin pages.
     *
     * @param string $hook
     */
    public function enqueue_admin_assets( string $hook ): void {
        $page_hooks = [
            'toplevel_page_wp_funnels',
            'wp-funnels_page_wp_funnel_settings',
            'wp-funnels_page_edit_funnel',
            'wp-funnels_page_create_funnel',
            'wp-funnels_page_wpfnl_settings',
            'wp-funnels_page_wpf-license',
            'wp-funnels_page_email-builder',
        ];

        if ( in_array( $hook, $page_hooks, true ) ) {
            wp_enqueue_style( 'wpfnl-pro-gbf-admin', WPFNL_PRO_URL . 'admin/assets/css/wpfnl-pro-gbf-admin.css', [], WPFNL_PRO_VERSION );
            wp_enqueue_script( 'wpfnl-pro-gbf-admin', WPFNL_PRO_URL . 'admin/assets/js/wpfnl-pro-gbf-admin.js', [ 'jquery' ], WPFNL_PRO_VERSION, false );
        }
    }


    /**
     * Enqueue public assets for GBF checkout pages.
     */
    public function enqueue_public_assets(): void {
        $public = new Wpfnl_Pro_GBF_Public( 'wpfnl-pro-gbf', WPFNL_PRO_VERSION );
        $public->enqueue_scripts();
    }


    /**
     * Apply GBF coupons after checkout is initialised.
     *
     * @param int|string $funnel_id
     */
    public function after_init_checkout( $funnel_id ): void {
        $public = new Wpfnl_Pro_GBF_Public( 'wpfnl-pro-gbf', WPFNL_PRO_VERSION );
        $public->after_init_checkout( $funnel_id );
    }


    /**
     * Clear the GBF plugin update transient.
     */
    public function check_update_transient(): void {
        global $wpdb;
        $sql = "DELETE a, b FROM $wpdb->options a, $wpdb->options b
        WHERE a.option_name LIKE %s
        AND a.option_name NOT LIKE %s
        AND b.option_name = CONCAT( '_site_transient_timeout_', SUBSTRING( a.option_name, 17 ) )";
        $wpdb->query( $wpdb->prepare( $sql, $wpdb->esc_like( '_site_transient_wpfunnelsprogbf-check_for_plugin_update' ) . '%', $wpdb->esc_like( '_site_transient_timeout_' ) . '%' ) );
    }
}
