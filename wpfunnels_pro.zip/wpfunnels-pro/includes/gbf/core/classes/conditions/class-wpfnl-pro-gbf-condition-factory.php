<?php

use WPFunnels\Traits\SingletonTrait;

class Wpfnl_Pro_GBF_Conditions_Factory {
    use SingletonTrait;

    public static function build($module)
    {
        $class_name = "WPFunnelsPro\\GBF\\Conditions\\".ucfirst($module);
        if (!class_exists($class_name)) {
            throw new \Exception('Invalid Condition Module.');
        } else {
            return new $class_name();
        }
    }
}