<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Product with same attribute
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class ProductSameAttribute extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get product with same attribute as main product
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        if( !$gbf_product || !isset($gbf_product['id']) ) {
            return $offer_product;
        }
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        $main_product = wc_get_product( $gbf_product['id'] );
        if( !$main_product ) {
            return $offer_product;
        }
        
        // Get product attributes
        $attributes = $main_product->get_attributes();
        if( empty($attributes) ) {
            return $offer_product;
        }
        
        // Build tax query for matching attributes
        $tax_query = array('relation' => 'OR');
        
        foreach( $attributes as $attribute ) {
            if( $attribute->is_taxonomy() ) {
                $terms = wp_get_post_terms( $gbf_product['id'], $attribute->get_name(), array('fields' => 'ids') );
                if( !empty($terms) ) {
                    $tax_query[] = array(
                        'taxonomy' => $attribute->get_name(),
                        'field' => 'term_id',
                        'terms' => $terms,
                    );
                }
            }
        }
        
        if( count($tax_query) === 1 ) {
            return $offer_product;
        }
        
        // Add main product to exclusion list
        $exclude_ids[] = $gbf_product['id'];
        
        // Get products with same attributes
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'post__not_in' => $exclude_ids,
            'tax_query' => $tax_query,
            'orderby' => 'rand',
        );
        
        $products = get_posts($args);
        
        if( !empty($products) ) {
            // Find first valid product
            foreach( $products as $product_post ) {
                $product = wc_get_product( $product_post->ID );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }
}
