<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Only in-stock products
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class InStockOnly extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get only in-stock products
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        // Get in-stock products
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'post__not_in' => $exclude_ids,
            'meta_query' => array(
                array(
                    'key' => '_stock_status',
                    'value' => 'instock',
                ),
            ),
            'orderby' => 'rand',
        );
        
        $products = get_posts($args);
        
        if( !empty($products) ) {
            // Find first valid product (check purchasability)
            foreach( $products as $product_post ) {
                $product = wc_get_product( $product_post->ID );
                if( $product && $product->is_purchasable() ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }
}
