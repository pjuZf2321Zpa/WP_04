<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * @author [Getwpfunnels Team]
 * @email [support@getwpfunnels.com]
 * @create date 2022-06-20 13:56:42
 * @modify date 2022-06-20 13:56:42
 * @desc [Get offer product when GBF condition on upsell is "Heighest sold product in a category"]
 */

use WPFunnelsPro\Wpfnl_Pro_functions;
use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;

class HighestSoldInsideTag extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get dynamic offer product for upsell or downsell
     * Offer product will be highest sold product in a category
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        $tag = isset($offer_mappings['tag']) ? $offer_mappings['tag'] : '';
        $highest_sold = Wpfnl_Pro_GBF_Functions::get_highest_sold_product_in_tag_for_offer( $tag, 10 );
        
        if( is_array($highest_sold) && isset($highest_sold['posts']) ) {
            // Find first valid product
            foreach( $highest_sold['posts'] as $product_post ) {
                if( in_array( $product_post->ID, $exclude_ids ) ) {
                    continue;
                }
                
                $product = wc_get_product( $product_post->ID );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }

}