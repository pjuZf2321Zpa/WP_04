<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Product from the same category as main product
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class ProductSameCategory extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get offer product from same category as main product
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        if( !$order_id ) {
            return $offer_product;
        }
        
        // Get all products from the order
        $order = wc_get_order( $order_id );
        if( !$order ) {
            return $offer_product;
        }
        
        $all_categories = array();
        $exclude_product_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        // Collect categories from all products in the order
        foreach( $order->get_items() as $item ) {
            $product_id = $item->get_product_id();
            if( $product_id ) {
                // Get categories for this product
                $product_categories = wp_get_post_terms( $product_id, 'product_cat', array('fields' => 'ids') );
                if( !empty($product_categories) ) {
                    $all_categories = array_merge( $all_categories, $product_categories );
                }
            }
        }
        
        // Remove duplicates
        $all_categories = array_unique( $all_categories );
        
        if( empty($all_categories) ) {
            return $offer_product;
        }
        
        // Check if onlyInStock filter is enabled
        $only_in_stock = isset($offer_mappings['onlyInStock']) ? $offer_mappings['onlyInStock'] : true;
        
        // Get products from any of the collected categories
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $all_categories,
                    'operator' => 'IN',
                ),
            ),
            'orderby' => 'rand',
        );
        
        // Add stock filter if enabled
        if( $only_in_stock ) {
            $args['meta_query'] = array(
                array(
                    'key' => '_stock_status',
                    'value' => 'instock',
                    'compare' => '=',
                ),
            );
        }
        
        $products = get_posts($args);
        
        // Find first valid product
        foreach( $products as $product_post ) {
            $product = wc_get_product( $product_post->ID );
            if( $this->is_valid_product( $product, $offer_mappings ) ) {
                $offer_mappings['show'] = $product_post->ID;
                $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                break;
            }
        }
        
        return $offer_product;
    }
}
