<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Product with the same tag as main product
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class ProductSameTag extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get offer product with same tag as main product
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        if( !$gbf_product || !isset($gbf_product['id']) ) {
            return $offer_product;
        }
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        // Get main product tags
        $main_product_id = $gbf_product['id'];
        $tags = wp_get_post_terms( $main_product_id, 'product_tag', array('fields' => 'ids') );
        
        if( empty($tags) ) {
            return $offer_product;
        }
        
        // Add main product to exclusion list
        $exclude_ids[] = $main_product_id;
        
        // Get products with same tag
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'post__not_in' => $exclude_ids,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_tag',
                    'field' => 'term_id',
                    'terms' => $tags,
                ),
            ),
            'orderby' => 'rand',
        );
        
        $products = get_posts($args);
        
        if( !empty($products) ) {
            // Find first valid product
            foreach( $products as $product_post ) {
                $product = wc_get_product( $product_post->ID );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }
}
