<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Most reviewed product in store
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class MostReviewedProduct extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get most reviewed product
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        $most_reviewed = Wpfnl_Pro_GBF_Functions::get_most_reviewed_product( 10 );
        
        if( is_array($most_reviewed) && isset($most_reviewed['posts']) ) {
            // Find first valid product
            foreach( $most_reviewed['posts'] as $product_post ) {
                if( in_array( $product_post->ID, $exclude_ids ) ) {
                    continue;
                }
                
                $product = wc_get_product( $product_post->ID );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }
}
