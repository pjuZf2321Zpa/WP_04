<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * @author [Getwpfunnels Team]
 * @email [support@getwpfunnels.com]
 * @create date 2022-06-20 13:56:42
 * @modify date 2022-06-20 13:56:42
 * @desc [Get offer product when GBF condition on upsell is "Least sold product in store"]
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class LeastSold extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get dynamic offer product for upsell or downsell
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        $least_sold = Wpfnl_Pro_GBF_Functions::get_least_sold_product( 10 );
        
        if( is_array($least_sold) ) {
            // Find first valid product
            foreach( $least_sold as $product_data ) {
                $product_id = isset($product_data->id) ? $product_data->id : null;
                
                if( !$product_id || in_array( $product_id, $exclude_ids ) ) {
                    continue;
                }
                
                $product = wc_get_product( $product_id );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_id;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }

}