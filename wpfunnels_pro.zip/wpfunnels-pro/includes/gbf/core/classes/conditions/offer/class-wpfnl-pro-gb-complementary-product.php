<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Complementary product to main product
 * Note: This requires custom configuration for product relationships
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class ComplementaryProduct extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get complementary product to main product
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        if( !$gbf_product || !isset($gbf_product['id']) ) {
            return $offer_product;
        }
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        // Get complementary products from custom meta or upsell/cross-sell products
        $main_product = wc_get_product( $gbf_product['id'] );
        if( !$main_product ) {
            return $offer_product;
        }
        
        // Try cross-sell products first
        $cross_sell_ids = $main_product->get_cross_sell_ids();
        if( !empty($cross_sell_ids) ) {
            foreach( $cross_sell_ids as $product_id ) {
                if( in_array( $product_id, $exclude_ids ) ) {
                    continue;
                }
                
                $product = wc_get_product( $product_id );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_id;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    return $offer_product;
                }
            }
        }
        
        // Try upsell products as fallback
        $upsell_ids = $main_product->get_upsell_ids();
        if( !empty($upsell_ids) ) {
            foreach( $upsell_ids as $product_id ) {
                if( in_array( $product_id, $exclude_ids ) ) {
                    continue;
                }
                
                $product = wc_get_product( $product_id );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_id;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    return $offer_product;
                }
            }
        }
        
        // Fallback: Get product from same category
        $categories = wp_get_post_terms( $gbf_product['id'], 'product_cat', array('fields' => 'ids') );
        if( !empty($categories) ) {
            // Add main product to exclusion list
            $exclude_ids[] = $gbf_product['id'];
            
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => 10,
                'post_status' => 'publish',
                'post__not_in' => $exclude_ids,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_cat',
                        'field' => 'term_id',
                        'terms' => $categories,
                    ),
                ),
                'orderby' => 'rand',
            );
            
            $products = get_posts($args);
            if( !empty($products) ) {
                // Find first valid product
                foreach( $products as $product_post ) {
                    $product = wc_get_product( $product_post->ID );
                    if( $this->is_valid_product( $product, $offer_mappings ) ) {
                        $offer_mappings['show'] = $product_post->ID;
                        $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                        break;
                    }
                }
            }
        }
        
        return $offer_product;
    }
}
