<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Higher priced product than main order
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class HigherPricedProduct extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get higher priced product than main order
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        if( !$gbf_product || !isset($gbf_product['id']) ) {
            return $offer_product;
        }
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        // Get main product price
        $main_product = wc_get_product( $gbf_product['id'] );
        if( !$main_product ) {
            return $offer_product;
        }
        
        $main_price = floatval( $main_product->get_price() );
        
        // Add main product to exclusion list
        $exclude_ids[] = $gbf_product['id'];
        
        // Get products with higher price
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'post__not_in' => $exclude_ids,
            'meta_query' => array(
                array(
                    'key' => '_price',
                    'value' => $main_price,
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
            ),
            'orderby' => 'meta_value_num',
            'meta_key' => '_price',
            'order' => 'ASC', // Get the lowest higher-priced product
        );
        
        $products = get_posts($args);
        
        if( !empty($products) ) {
            // Find first valid product
            foreach( $products as $product_post ) {
                $product = wc_get_product( $product_post->ID );
                if( $this->is_valid_product( $product, $offer_mappings ) ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }
}
