<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * @author [Getwpfunnels Team]
 * @email [support@getwpfunnels.com]
 * @create date 2022-06-20 13:55:10
 * @modify date 2022-06-20 13:55:10
 * @desc [Abstract class which is responsible for creating offer products]
 */

abstract class Wpfnl_Pro_GBF_Conditions {
    
    public function __construct()
    {
    }

    /**
     * Get dynamic offer product for upsell or downsell
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {

    }

    /**
     * Get product IDs to exclude based on filter settings
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * 
     * @return array
     */
    protected function get_excluded_product_ids( $offer_mappings, $order_id ) {
        $exclude_ids = array();
        
        // Check if excludeCartProducts is enabled (default: true)
        // Support both camelCase and snake_case for backward compatibility
        $exclude_cart = isset($offer_mappings['excludeCartProducts']) 
            ? $offer_mappings['excludeCartProducts'] 
            : (isset($offer_mappings['exclude_cart_products']) ? $offer_mappings['exclude_cart_products'] : true);
        
        if( $exclude_cart && $order_id ) {
            $order = wc_get_order( $order_id );
            if( $order ) {
                foreach( $order->get_items() as $item ) {
                    $product_id = $item->get_product_id();
                    if( $product_id ) {
                        $exclude_ids[] = $product_id;
                    }
                }
            }
        }
        return $exclude_ids;
    }

    /**
     * Check if product is valid based on filter settings
     * 
     * @param WC_Product $product
     * @param array $offer_mappings
     * 
     * @return bool
     */
    protected function is_valid_product( $product, $offer_mappings ) {
        if( !$product ) {
            return false;
        }
        
        // Check if onlyInStock is enabled (default: true)
        // Support both camelCase and snake_case for backward compatibility
        $only_in_stock = isset($offer_mappings['onlyInStock']) 
            ? $offer_mappings['onlyInStock'] 
            : (isset($offer_mappings['only_in_stock']) ? $offer_mappings['only_in_stock'] : true);
        
        if( $only_in_stock && !$product->is_in_stock() ) {
            return false;
        }
        
        if( !$product->is_purchasable() ) {
            return false;
        }
        
        return true;
    }


}