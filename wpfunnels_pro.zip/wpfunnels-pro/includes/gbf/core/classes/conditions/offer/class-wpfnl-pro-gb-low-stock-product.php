<?php
namespace WPFunnelsPro\GBF\Conditions\Offer;

/**
 * Low stock product
 */

use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

class LowStockProduct extends Wpfnl_Pro_GBF_Conditions {

    /**
     * Get low stock product
     * 
     * @param mixed $offer_mappings
     * @param mixed $order_id
     * @param mixed $step_id
     * @param mixed $gbf_product
     * 
     * @return array
     */
    public function get_offer_product( $offer_mappings, $order_id, $step_id, $gbf_product ) {
        $offer_product = array();
        
        // Get products to exclude based on filter settings
        $exclude_ids = $this->get_excluded_product_ids( $offer_mappings, $order_id );
        
        // Get low stock threshold (default 5)
        $low_stock_threshold = isset($offer_mappings['lowStockThreshold']) ? intval($offer_mappings['lowStockThreshold']) : 5;
        
        // Get products with low stock
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'post__not_in' => $exclude_ids,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_stock_status',
                    'value' => 'instock',
                ),
                array(
                    'key' => '_manage_stock',
                    'value' => 'yes',
                ),
                array(
                    'key' => '_stock',
                    'value' => $low_stock_threshold,
                    'compare' => '<=',
                    'type' => 'NUMERIC',
                ),
                array(
                    'key' => '_stock',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
            ),
            'orderby' => 'meta_value_num',
            'meta_key' => '_stock',
            'order' => 'ASC',
        );
        
        $products = get_posts($args);
        
        if( !empty($products) ) {
            // Find first valid product (check purchasability)
            foreach( $products as $product_post ) {
                $product = wc_get_product( $product_post->ID );
                if( $product && $product->is_purchasable() ) {
                    $offer_mappings['show'] = $product_post->ID;
                    $offer_product = Wpfnl_Pro_functions::get_offer_data( $step_id, $offer_mappings['show'], $offer_mappings['quantity'], $order_id );
                    break;
                }
            }
        }
        
        return $offer_product;
    }
}
