<?php

namespace WPFunnelsPro\GBF\Conditions;

class Payment extends Wpfnl_Pro_GBF_Conditions {


    /**
     * @param $order_id
     * @return float|void
     */
    public function get_value( $order_id ) {
        if( !$order_id ) {
            return;
        }
        $order = wc_get_order($order_id);
        return $order->get_payment_method();
    }
}