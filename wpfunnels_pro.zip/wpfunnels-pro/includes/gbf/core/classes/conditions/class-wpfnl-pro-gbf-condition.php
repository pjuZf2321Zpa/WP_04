<?php

namespace WPFunnelsPro\GBF\Conditions;

// use WPFunnels\Traits\SingletonTrait;

abstract class Wpfnl_Pro_GBF_Conditions {

    // use SingletonTrait;


    public function __construct()
    {
    }


    /**
     * rule comparison
     *
     * @param $value
     * @param $rule
     * @return bool
     */
    public function compare_to_rule( $value, $rule ) {
        $result = ( $value == $rule['value'] );
        // Allow "all" to match any value.
        if ( $rule['value'] === 'all' ) {
            $result = true;
        }

        // Reverse result for "!=" operator.
        if ( $rule['operator'] === '!=' ) {
            return ! $result;
        }

        if ( $rule['operator'] === '>' ) {
            return $value > $rule['value'];
        }

        if ( $rule['operator'] === '<' ) {
            return $value < $rule['value'];
        }

        return $result;
    }



}