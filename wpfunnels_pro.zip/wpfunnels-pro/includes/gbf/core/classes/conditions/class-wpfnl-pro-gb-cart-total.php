<?php

namespace WPFunnelsPro\GBF\Conditions;

class Cart_total extends Wpfnl_Pro_GBF_Conditions {

    /**
     * @param $value
     * @param $rule
     * @return bool|void
     */
    public function compare_to_rule( $value = '', $rule = [] ) {
        
        if( $value && $rule ){
            if( 'cart_total_equal' === $rule['param'] ){
                if( $value == $rule['value'] ){
                    return true;
                }
            }elseif( 'cart_total_less' === $rule['param'] ){
                if( $value < $rule['value'] ){
                    return true;
                }
            }elseif( 'cart_total_greater' === $rule['param'] ){
                if( $value > $rule['value'] ){
                    return true;
                }
            }
        }
        return false;
    }


}