<?php



namespace WPFunnelsPro\GBF\Conditions;

class Order extends Wpfnl_Pro_GBF_Conditions {

    /**
     * @param $order
     */
    public function get_value( $order ) {
        if(!$order) {
            return;
        }
        return $order->get_id();
    }
}