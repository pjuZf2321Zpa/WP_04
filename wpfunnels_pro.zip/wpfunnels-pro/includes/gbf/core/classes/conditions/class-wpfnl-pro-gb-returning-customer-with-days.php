<?php

namespace WPFunnelsPro\GBF\Conditions;
use WPFunnelsPro\GBF\Wpfnl_Pro_GBF_Functions;


class ReturningCustomerWithRange extends Wpfnl_Pro_GBF_Conditions {


    /**
     * Get product id from product object
     * 
     * @param Object $product
     * @return Number
     * @since 1.0.25
     */
    public function get_value( $product = '' ){
        if( $product ){
           return $product->get_id();
        }
        return false;
    }


    /**
     * Compare condition
     * @param $value
     * @param $rule
     * @return bool|void
     * @since 1.0.25
     */
    public function compare_to_rule( $value = '', $rule = [] ) {
        $is_returning = Wpfnl_Pro_GBF_Functions::maybe_returning_user_within_days( get_current_user_id(), $rule['value'] );
        return $is_returning;
    }


}