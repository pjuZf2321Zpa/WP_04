<?php

namespace WPFunnelsPro\GBF;

use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\GBF\Actions\Wpfnl_Pro_GB_Actions;

class Wpfnl_Pro_GBF_Functions {


    /**
     * check if the funnel is global funnel or not
     *
     * @param $funnel_id
     * @return bool
     */
    public static function is_global_funnel( $funnel_id ) {
        if(!$funnel_id) {
            return false;
        }

        $is_global_funnel = get_post_meta( $funnel_id, 'is_global_funnel', true );
        if( $is_global_funnel && 'yes' === $is_global_funnel ) {
            return true;
        }
        return false;
    }


    /**
     * @param $funnel_id
     * @return bool|array
     */
    public static function get_global_funnel_start_condition( $funnel_id ) {
        if(!$funnel_id) {
            return false;
        }
        
        $global_condition = get_post_meta( $funnel_id, 'global_funnel_data', true );
        if( $global_condition && is_array( $global_condition ) && isset($global_condition['start_condition'])) {
            return $global_condition['start_condition'];
        }
        return false;
    }


    /**
     * Gbf feature dependency with gbf version
     * 
     * @since 1.0.7
     */
    public static function gbf_feature_dependency(){

        $features = array(
            array(
                'index'     => 'all_product',
                'label'     => 'Any product is selected',
                'version'   => '1.0.7',
            ),
        );

        return $features;
    }


    /**
     * maybe match ob product with main product
     * 
     * @param $ob_products, $main_products
     * @since 1.0.9
     * @return Array
     */
    public static function maybe_ob_match( $funnel_id,$ob_products, $main_products ){

        if( $funnel_id ){
            $is_global_funnel = get_post_meta( $funnel_id, 'is_global_funnel', true );
            if( 'yes' === $is_global_funnel ){
                // Process dynamic order bumps
                $ob_products = self::resolve_dynamic_order_bumps( $ob_products, $main_products );
                
                $is_skip = get_post_meta( $funnel_id, '_wpfunnels_skip_offer', true );
                if( isset($is_skip['skip_offer']) && $is_skip['skip_offer'] === 'yes' ){
                    if( is_array( $ob_products ) && is_array($main_products) ){
                        foreach( $ob_products as $key=>$ob_product ){
                            if( $ob_product['isEnabled'] || 'yes' === $ob_product['isEnabled'] ){
                                $index = array_search($ob_product['product'], array_column($main_products, 'id'));
                                if( false !== $index ){
                                    if( isset($is_skip['skip_if_quantity']) && $is_skip['skip_if_quantity'] === 'yes' ){
                                        if( (int)$main_products[$key]['quantity'] >= (int)$ob_product['quantity'] ){
                                            unset($ob_products[$key]);
                                        }
                                    }else{
                                        unset($ob_products[$key]);
                                    }
                                }
                            }
                            
                        }
                        
                    }
                }
            }
        }
        return $ob_products;
    }

    /**
     * Resolve dynamic order bump products based on rules
     * 
     * @param array $ob_products Order bump products array
     * @param array $main_products Main cart products array
     * @return array Modified order bump products with resolved dynamic products
     * @since 2.8.0
     */
    public static function resolve_dynamic_order_bumps( $ob_products, $main_products ) {
        if( !is_array($ob_products) ) {
            return $ob_products;
        }


        foreach( $ob_products as $key => $ob_product ) {
            
            // Check if this is a dynamic order bump
            if( isset($ob_product['offerSelectionMode']) && $ob_product['offerSelectionMode'] === 'auto-match' ) {
                
                // Get the rules
                $rules = isset($ob_product['obRules']) ? $ob_product['obRules'] : array();
                $rule_type = isset($rules['type']) ? $rules['type'] : '';
                
                
                // Resolve product based on rule type
                $resolved_product_id = self::resolve_ob_product_by_rule( $rule_type, $rules, $main_products );
                
                
                // If no product matched and fallback is set
                if( !$resolved_product_id && isset($ob_product['fallbackBehavior']) ) {
                    
                    if( $ob_product['fallbackBehavior'] === 'default_product' && isset($ob_product['fallbackProduct']) ) {
                        // Use fallback product
                        $resolved_product_id = $ob_product['fallbackProduct'];
                    } elseif( $ob_product['fallbackBehavior'] === 'hide' ) {
                        // Hide the order bump
                        unset($ob_products[$key]);
                        continue;
                    }
                }
                
                // If we have a resolved product, update the order bump
                if( $resolved_product_id ) {
                    $product = wc_get_product( $resolved_product_id );
                    if( $product ) {
                        // Update product details in the order bump
                        $ob_products[$key]['product'] = $resolved_product_id;
                        $ob_products[$key]['productName'] = $product->get_name();
                        $ob_products[$key]['price'] = $product->get_regular_price();
                        $ob_products[$key]['salePrice'] = $product->get_sale_price();
                        $ob_products[$key]['htmlPrice'] = $product->get_price_html();
                        $ob_products[$key]['productType'] = $product->get_type();
                        
                        // For auto-match mode, use actual product title and description
                        // Update all text fields to show real product info
                        $ob_products[$key]['checkBoxLabel'] = $product->get_name();
                        $ob_products[$key]['highLightText'] = $product->get_name();
                        $ob_products[$key]['productDescriptionText'] = $product->get_description();
                        
                        // Get product image
                        $image_id = $product->get_image_id();
                        if( $image_id ) {
                            $image_url = wp_get_attachment_url( $image_id );
                            $ob_products[$key]['productImage'] = array(
                                'id' => $image_id,
                                'url' => $image_url
                            );
                        }
                        
                        // Set quantity from rules if available
                        if( isset($rules['quantity']) && $rules['quantity'] > 0 ) {
                            $ob_products[$key]['quantity'] = $rules['quantity'];
                        }
                    } else {
                        // Product not found, remove order bump
                        unset($ob_products[$key]);
                    }
                } else {
                    // No product resolved and no fallback, remove order bump
                    unset($ob_products[$key]);
                }
            }
        }
        
        return $ob_products;
    }

    /**
     * Resolve order bump product based on rule type
     * 
     * @param string $rule_type The type of rule to apply
     * @param array $rules The rules configuration
     * @param array $main_products Main cart products
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function resolve_ob_product_by_rule( $rule_type, $rules, $main_products ) {
        
        if( !Wpfnl_functions::is_wc_active() ) {
            return false;
        }

        $product_id = false;

        switch( $rule_type ) {
            // Random product in category
            case 'randomProduct':
                $category = isset($rules['category']) ? $rules['category'] : '';
                if( $category ) {
                    $product_id = self::get_ob_product_from_category( $category, $rule_type, $rules );
                }
                break;
                
            // Highest sold in category
            case 'highestSoldInsideCategory':
                $category = isset($rules['category']) ? $rules['category'] : '';
                if( $category ) {
                    $product_id = self::get_ob_product_from_category( $category, $rule_type, $rules );
                }
                break;
                
            // Random product in shop
            case 'randomInShop':
                $product_id = self::get_random_product_in_shop_for_ob( $rules );
                break;
                
            // Highest sold in store
            case 'highestSold':
                $product_id = self::get_highest_sold_product_for_ob( $rules );
                break;
                
            // Least sold in store
            case 'leastSold':
                $product_id = self::get_least_sold_product_for_ob( $rules );
                break;
                
            // Most popular product
            case 'popular':
                $product_id = self::get_most_popular_product_for_ob( $rules );
                break;
                
            // Most reviewed product
            case 'mostReviewedProduct':
                $product_id = self::get_most_reviewed_product_for_ob( $rules );
                break;
                
            // Random product in category within price range
            case 'randomProductInsideCategoryWithinPrice':
                $category = isset($rules['category']) ? $rules['category'] : '';
                $price_from = isset($rules['priceFrom']) ? floatval($rules['priceFrom']) : 0;
                $price_to = isset($rules['priceTo']) ? floatval($rules['priceTo']) : 0;
                if( $category && $price_from >= 0 && $price_to > 0 ) {
                    $product_id = self::get_ob_product_from_category_with_price( $category, $price_from, $price_to, $rules );
                }
                break;
                
            // Random product with tag
            case 'randomProductInTag':
                $tag = isset($rules['tag']) ? $rules['tag'] : '';
                if( $tag ) {
                    $product_id = self::get_ob_product_from_tag( $tag, $rule_type, $rules );
                }
                break;
                
            // Highest sold with tag
            case 'highestSoldInsideTag':
                $tag = isset($rules['tag']) ? $rules['tag'] : '';
                if( $tag ) {
                    $product_id = self::get_ob_product_from_tag( $tag, $rule_type, $rules );
                }
                break;
                
            // Random product with tag within price range
            case 'randomProductInsideTagWithinPrice':
                $tag = isset($rules['tag']) ? $rules['tag'] : '';
                $price_from = isset($rules['priceFrom']) ? floatval($rules['priceFrom']) : 0;
                $price_to = isset($rules['priceTo']) ? floatval($rules['priceTo']) : 0;
                if( $tag && $price_from >= 0 && $price_to > 0 ) {
                    $product_id = self::get_ob_product_from_tag_with_price( $tag, $price_from, $price_to, $rules );
                }
                break;
                
            // Product from same category as main cart product
            case 'productSameCategory':
                $product_id = self::get_ob_product_same_category( $main_products, $rules );
                break;
                
            // Product with same tag as main cart product
            case 'productSameTag':
                $product_id = self::get_ob_product_same_tag( $main_products, $rules );
                break;
                
            // Product with same attribute as main cart product
            case 'productSameAttribute':
                $product_id = self::get_ob_product_same_attribute( $main_products, $rules );
                break;
                
            // Product with same attribute within price range
            case 'productSameAttributeWithinPrice':
                $price_from = isset($rules['priceFrom']) ? floatval($rules['priceFrom']) : 0;
                $price_to = isset($rules['priceTo']) ? floatval($rules['priceTo']) : 0;
                $product_id = self::get_ob_product_same_attribute_within_price( $main_products, $price_from, $price_to, $rules );
                break;
                
            // More quantity of the main product in cart
            case 'moreQuantity':
                $product_id = self::get_ob_product_more_quantity( $main_products, $rules );
                break;
                
            // Complementary product (cross-sell or upsell)
            case 'complementaryProduct':
                $product_id = self::get_ob_complementary_product( $main_products, $rules );
                break;
                
            // Higher priced product than main cart product
            case 'higherPricedProduct':
                $product_id = self::get_ob_higher_priced_product( $main_products, $rules );
                break;
                
            // Lower priced product than main cart product
            case 'lowerPricedProduct':
                $product_id = self::get_ob_lower_priced_product( $main_products, $rules );
                break;
                
            // Product within price difference range
            case 'productPriceDifferenceRange':
                $price_from = isset($rules['priceFrom']) ? floatval($rules['priceFrom']) : 0;
                $price_to = isset($rules['priceTo']) ? floatval($rules['priceTo']) : 0;
                $product_id = self::get_ob_product_price_difference_range( $main_products, $price_from, $price_to, $rules );
                break;
                
            default:
                break;
        }
        
        return $product_id;
    }

    /**
     * Get order bump product from category
     * 
     * @param string $category Category slug or ID
     * @param string $rule_type Type of rule (randomProduct or highestSoldInsideCategory)
     * @param array $rules Additional filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_from_category( $category, $rule_type, $rules ) {
        
        // Determine if category is slug or term_id
        $field = is_numeric($category) ? 'term_id' : 'slug';
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => $field,
                    'terms' => $category,
                ),
            ),
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        // Set ordering
        if( $rule_type === 'highestSoldInsideCategory' ) {
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = 'total_sales';
            $args['order'] = 'DESC';
        } else {
            $args['orderby'] = 'rand';
        }
        
        
        $products = new \WP_Query( $args );
        
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product from category within price range
     * 
     * @param string $category Category slug or ID
     * @param float $price_from Minimum price
     * @param float $price_to Maximum price
     * @param array $rules Additional filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_from_category_with_price( $category, $price_from, $price_to, $rules ) {
        
        // Determine if category is slug or term_id
        $field = is_numeric($category) ? 'term_id' : 'slug';
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'orderby' => 'rand',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => $field,
                    'terms' => $category,
                ),
            ),
            'meta_query' => array(
                array(
                    'key' => '_price',
                    'value' => array( $price_from, $price_to ),
                    'compare' => 'BETWEEN',
                    'type' => 'NUMERIC'
                ),
            ),
        );
        
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        
        $products = new \WP_Query( $args );
        
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product from tag
     * 
     * @param string $tag Tag ID
     * @param string $rule_type Type of rule (randomProductInTag or highestSoldInsideTag)
     * @param array $rules Additional filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_from_tag( $tag, $rule_type, $rules ) {
        
        // Determine if tag is slug or term_id
        $field = is_numeric($tag) ? 'term_id' : 'slug';
        $tag_value = $tag;
        
        // If numeric (ID), verify it exists
        if( is_numeric($tag) ) {
            $tag_obj = get_term( $tag, 'product_tag' );
            if( !$tag_obj || is_wp_error($tag_obj) ) {
                return false;
            }
        }
        
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_tag',
                    'field' => $field,
                    'terms' => $tag_value,
                ),
            ),
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        // Set ordering
        if( $rule_type === 'highestSoldInsideTag' ) {
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = 'total_sales';
            $args['order'] = 'DESC';
        } else {
            $args['orderby'] = 'rand';
        }
        
        
        $products = new \WP_Query( $args );
        
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product from tag within price range
     * 
     * @param string $tag Tag ID
     * @param float $price_from Minimum price
     * @param float $price_to Maximum price
     * @param array $rules Additional filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_from_tag_with_price( $tag, $price_from, $price_to, $rules ) {
        
        // Determine if tag is slug or term_id
        $field = is_numeric($tag) ? 'term_id' : 'slug';
        $tag_value = $tag;
        
        // If numeric (ID), verify it exists
        if( is_numeric($tag) ) {
            $tag_obj = get_term( $tag, 'product_tag' );
            if( !$tag_obj || is_wp_error($tag_obj) ) {
                return false;
            }
        }
        
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'orderby' => 'rand',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_tag',
                    'field' => $field,
                    'terms' => $tag_value,
                ),
            ),
            'meta_query' => array(
                array(
                    'key' => '_price',
                    'value' => array( $price_from, $price_to ),
                    'compare' => 'BETWEEN',
                    'type' => 'NUMERIC'
                ),
            ),
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        
        $products = new \WP_Query( $args );
        
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Apply filter settings to product query
     * 
     * @param array $args WP_Query arguments
     * @param array $rules Filter rules
     * @return array Modified WP_Query arguments
     * @since 2.8.0
     */
    public static function apply_ob_filter_settings( $args, $rules ) {
        
        // Initialize meta_query if not exists
        if( !isset($args['meta_query']) ) {
            $args['meta_query'] = array();
        }
        
        // Initialize tax_query if not exists
        if( !isset($args['tax_query']) ) {
            $args['tax_query'] = array();
        }
        
        // Set tax_query relation FIRST if there are existing conditions
        if( count($args['tax_query']) > 0 && !isset($args['tax_query']['relation']) ) {
            $args['tax_query']['relation'] = 'AND';
        }
        
        // Include both products and variations in post type
        if( !isset($args['post_type']) || $args['post_type'] === 'product' ) {
            $args['post_type'] = array('product', 'product_variation');
        }
        
        // Exclude variable products (parent products), but allow variations
        // We do this by excluding products with product_type taxonomy term 'variable'
        $args['tax_query'][] = array(
            'taxonomy' => 'product_type',
            'field'    => 'slug',
            'terms'    => array('variable'),
            'operator' => 'NOT IN'
        );
        
        // Exclude products already in cart (check both parameter names for compatibility)
        if( (isset($rules['excludeCart']) && $rules['excludeCart'] === true) || 
            (isset($rules['excludeCartProducts']) && $rules['excludeCartProducts'] == 1) ) {
            $cart_product_ids = array();
            if( WC()->cart ) {
                foreach( WC()->cart->get_cart() as $cart_item ) {
                    $cart_product_ids[] = $cart_item['product_id'];
                }
            }
            if( !empty($cart_product_ids) ) {
                if( !isset($args['post__not_in']) ) {
                    $args['post__not_in'] = array();
                }
                $args['post__not_in'] = array_merge($args['post__not_in'], $cart_product_ids);
            }
        }
        
        // Only show in-stock products
        if( isset($rules['onlyInStock']) && $rules['onlyInStock'] === true ) {
            $args['meta_query'][] = array(
                'key' => '_stock_status',
                'value' => 'instock',
                'compare' => '='
            );
        }
        
        // Set meta_query relation if multiple conditions
        if( count($args['meta_query']) > 1 ) {
            $args['meta_query']['relation'] = 'AND';
        }
        
        
        return $args;
    }

    /**
     * Get random product in shop
     * 
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_random_product_in_shop_for_ob( $rules ) {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'orderby' => 'rand',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get highest sold product in store (for order bumps)
     * 
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_highest_sold_product_for_ob( $rules ) {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'orderby' => 'meta_value_num',
            'meta_key' => 'total_sales',
            'order' => 'DESC',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get least sold product in store (for order bumps)
     * 
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_least_sold_product_for_ob( $rules ) {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'orderby' => 'meta_value_num',
            'meta_key' => 'total_sales',
            'order' => 'ASC',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get most popular product (by views/purchases) for order bumps
     * 
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_most_popular_product_for_ob( $rules ) {
        // Most popular can be determined by total sales
        // Same as highest sold
        return self::get_highest_sold_product_for_ob( $rules );
    }

    /**
     * Get most reviewed product in store (for order bumps)
     * 
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_most_reviewed_product_for_ob( $rules ) {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'orderby' => 'meta_value_num',
            'meta_key' => '_wc_review_count',
            'order' => 'DESC',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product from same category as main cart products
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_same_category( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        // Collect all categories from main cart products
        $all_categories = array();
        $exclude_product_ids = array();
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( $product_id ) {
                // Add to exclusion list
                $exclude_product_ids[] = $product_id;
                
                // Get categories for this product
                $product_categories = wp_get_post_terms( $product_id, 'product_cat', array('fields' => 'ids') );
                if( !empty($product_categories) && !is_wp_error($product_categories) ) {
                    $all_categories = array_merge( $all_categories, $product_categories );
                }
            }
        }
        
        // Remove duplicates
        $all_categories = array_unique( $all_categories );
        
        if( empty($all_categories) ) {
            return false;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $all_categories,
                    'operator' => 'IN',
                ),
            ),
            'orderby' => 'rand',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product with same tag as main cart products
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_same_tag( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        // Collect all tags from main cart products
        $all_tags = array();
        $exclude_product_ids = array();
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( $product_id ) {
                // Add to exclusion list
                $exclude_product_ids[] = $product_id;
                
                // Get tags for this product
                $product_tags = wp_get_post_terms( $product_id, 'product_tag', array('fields' => 'ids') );
                if( !empty($product_tags) && !is_wp_error($product_tags) ) {
                    $all_tags = array_merge( $all_tags, $product_tags );
                }
            }
        }
        
        // Remove duplicates
        $all_tags = array_unique( $all_tags );
        
        if( empty($all_tags) ) {
            return false;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_tag',
                    'field' => 'term_id',
                    'terms' => $all_tags,
                    'operator' => 'IN',
                ),
            ),
            'orderby' => 'rand',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product with same attribute as main cart products
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_same_attribute( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        $exclude_product_ids = array();
        $tax_query = array('relation' => 'OR');
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( !$product_id ) {
                continue;
            }
            
            // Add to exclusion list
            $exclude_product_ids[] = $product_id;
            
            $product = wc_get_product( $product_id );
            if( !$product ) {
                continue;
            }
            
            // Get product attributes
            $attributes = $product->get_attributes();
            if( empty($attributes) ) {
                continue;
            }
            
            foreach( $attributes as $attribute ) {
                if( $attribute->is_taxonomy() ) {
                    $terms = wp_get_post_terms( $product_id, $attribute->get_name(), array('fields' => 'ids') );
                    if( !empty($terms) && !is_wp_error($terms) ) {
                        $tax_query[] = array(
                            'taxonomy' => $attribute->get_name(),
                            'field' => 'term_id',
                            'terms' => $terms,
                        );
                    }
                }
            }
        }
        
        // Check if we have any attribute queries
        if( count($tax_query) === 1 ) {
            return false;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'tax_query' => $tax_query,
            'orderby' => 'rand',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product with same attribute within price range
     * 
     * @param array $main_products Main cart products array
     * @param float $price_from Minimum price
     * @param float $price_to Maximum price
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_same_attribute_within_price( $main_products, $price_from, $price_to, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        $exclude_product_ids = array();
        $tax_query = array('relation' => 'OR');
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( !$product_id ) {
                continue;
            }
            
            // Add to exclusion list
            $exclude_product_ids[] = $product_id;
            
            $product = wc_get_product( $product_id );
            if( !$product ) {
                continue;
            }
            
            // Get product attributes
            $attributes = $product->get_attributes();
            if( empty($attributes) ) {
                continue;
            }
            
            foreach( $attributes as $attribute ) {
                if( $attribute->is_taxonomy() ) {
                    $terms = wp_get_post_terms( $product_id, $attribute->get_name(), array('fields' => 'ids') );
                    if( !empty($terms) && !is_wp_error($terms) ) {
                        $tax_query[] = array(
                            'taxonomy' => $attribute->get_name(),
                            'field' => 'term_id',
                            'terms' => $terms,
                        );
                    }
                }
            }
        }
        
        // Check if we have any attribute queries
        if( count($tax_query) === 1 ) {
            return false;
        }
        
        // Set default price range if not provided
        if( $price_to <= 0 ) {
            $price_to = 999999;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'tax_query' => $tax_query,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_price',
                    'value' => $price_from,
                    'compare' => '>=',
                    'type' => 'NUMERIC',
                ),
                array(
                    'key' => '_price',
                    'value' => $price_to,
                    'compare' => '<=',
                    'type' => 'NUMERIC',
                ),
            ),
            'orderby' => 'rand',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product - more quantity of main cart product
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_more_quantity( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        // Get the first main product (or variation if exists)
        $main_product = $main_products[0];
        $product_id = isset($main_product['variation_id']) && $main_product['variation_id'] 
            ? $main_product['variation_id'] 
            : (isset($main_product['id']) ? $main_product['id'] : 0);
        
        if( !$product_id ) {
            return false;
        }
        
        // Validate product exists and is purchasable
        $product = wc_get_product( $product_id );
        if( !$product || !$product->is_purchasable() ) {
            return false;
        }
        
        // Check stock if only in stock filter is enabled
        $only_in_stock = isset($rules['onlyInStock']) ? $rules['onlyInStock'] : true;
        if( $only_in_stock && !$product->is_in_stock() ) {
            return false;
        }
        
        return $product_id;
    }

    /**
     * Get order bump complementary product (cross-sell or upsell)
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_complementary_product( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        $exclude_product_ids = array();
        
        // Collect all main product IDs for exclusion
        foreach( $main_products as $main_product ) {
            if( isset($main_product['id']) ) {
                $exclude_product_ids[] = $main_product['id'];
            }
            if( isset($main_product['variation_id']) && $main_product['variation_id'] ) {
                $exclude_product_ids[] = $main_product['variation_id'];
            }
        }
        
        // Try to find cross-sell or upsell products
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( !$product_id ) {
                continue;
            }
            
            $product = wc_get_product( $product_id );
            if( !$product ) {
                continue;
            }
            
            // Try cross-sell products first
            $cross_sell_ids = $product->get_cross_sell_ids();
            if( !empty($cross_sell_ids) ) {
                foreach( $cross_sell_ids as $cs_id ) {
                    if( in_array( $cs_id, $exclude_product_ids ) ) {
                        continue;
                    }
                    
                    $cs_product = wc_get_product( $cs_id );
                    if( $cs_product && $cs_product->is_purchasable() ) {
                        // Check stock if only in stock filter is enabled
                        $only_in_stock = isset($rules['onlyInStock']) ? $rules['onlyInStock'] : true;
                        if( $only_in_stock && !$cs_product->is_in_stock() ) {
                            continue;
                        }
                        return $cs_id;
                    }
                }
            }
            
            // Try upsell products as fallback
            $upsell_ids = $product->get_upsell_ids();
            if( !empty($upsell_ids) ) {
                foreach( $upsell_ids as $us_id ) {
                    if( in_array( $us_id, $exclude_product_ids ) ) {
                        continue;
                    }
                    
                    $us_product = wc_get_product( $us_id );
                    if( $us_product && $us_product->is_purchasable() ) {
                        // Check stock if only in stock filter is enabled
                        $only_in_stock = isset($rules['onlyInStock']) ? $rules['onlyInStock'] : true;
                        if( $only_in_stock && !$us_product->is_in_stock() ) {
                            continue;
                        }
                        return $us_id;
                    }
                }
            }
        }
        
        // Fallback: Get random product from same category
        return self::get_ob_product_same_category( $main_products, $rules );
    }

    /**
     * Get order bump product with higher price than main cart products
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_higher_priced_product( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        // Get the highest price from main cart products
        $main_price = 0;
        $exclude_product_ids = array();
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( !$product_id ) {
                continue;
            }
            
            // Add to exclusion list
            $exclude_product_ids[] = $product_id;
            if( isset($main_product['variation_id']) && $main_product['variation_id'] ) {
                $exclude_product_ids[] = $main_product['variation_id'];
            }
            
            $product = wc_get_product( $product_id );
            if( $product ) {
                $price = floatval( $product->get_price() );
                if( $price > $main_price ) {
                    $main_price = $price;
                }
            }
        }
        
        if( $main_price <= 0 ) {
            return false;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'meta_query' => array(
                array(
                    'key' => '_price',
                    'value' => $main_price,
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
            ),
            'orderby' => 'meta_value_num',
            'meta_key' => '_price',
            'order' => 'ASC', // Get the lowest higher-priced product (closest to main price)
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product with lower price than main cart products
     * 
     * @param array $main_products Main cart products array
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_lower_priced_product( $main_products, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        // Get the lowest price from main cart products
        $main_price = PHP_FLOAT_MAX;
        $exclude_product_ids = array();
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( !$product_id ) {
                continue;
            }
            
            // Add to exclusion list
            $exclude_product_ids[] = $product_id;
            if( isset($main_product['variation_id']) && $main_product['variation_id'] ) {
                $exclude_product_ids[] = $main_product['variation_id'];
            }
            
            $product = wc_get_product( $product_id );
            if( $product ) {
                $price = floatval( $product->get_price() );
                if( $price > 0 && $price < $main_price ) {
                    $main_price = $price;
                }
            }
        }
        
        if( $main_price <= 0 || $main_price === PHP_FLOAT_MAX ) {
            return false;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'meta_query' => array(
                array(
                    'key' => '_price',
                    'value' => $main_price,
                    'compare' => '<',
                    'type' => 'NUMERIC',
                ),
                array(
                    'key' => '_price',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
            ),
            'orderby' => 'meta_value_num',
            'meta_key' => '_price',
            'order' => 'DESC', // Get the highest lower-priced product (closest to main price)
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }

    /**
     * Get order bump product within price difference range from main cart products
     * 
     * @param array $main_products Main cart products array
     * @param float $price_from Minimum price difference (can be negative for lower, positive for higher)
     * @param float $price_to Maximum price difference
     * @param array $rules Filter rules
     * @return int|false Product ID if found, false otherwise
     * @since 2.8.0
     */
    public static function get_ob_product_price_difference_range( $main_products, $price_from, $price_to, $rules ) {
        if( !is_array($main_products) || empty($main_products) ) {
            return false;
        }
        
        // Get the average price from main cart products
        $total_price = 0;
        $product_count = 0;
        $exclude_product_ids = array();
        
        foreach( $main_products as $main_product ) {
            $product_id = isset($main_product['id']) ? $main_product['id'] : 0;
            if( !$product_id ) {
                continue;
            }
            
            // Add to exclusion list
            $exclude_product_ids[] = $product_id;
            if( isset($main_product['variation_id']) && $main_product['variation_id'] ) {
                $exclude_product_ids[] = $main_product['variation_id'];
            }
            
            $product = wc_get_product( $product_id );
            if( $product ) {
                $total_price += floatval( $product->get_price() );
                $product_count++;
            }
        }
        
        if( $product_count === 0 ) {
            return false;
        }
        
        $main_price = $total_price / $product_count;
        
        // Calculate price range based on main product price
        $min_price = max( 0, $main_price + $price_from );
        $max_price = $main_price + $price_to;
        
        if( $max_price <= 0 ) {
            return false;
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post__not_in' => $exclude_product_ids,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_price',
                    'value' => $min_price,
                    'compare' => '>=',
                    'type' => 'NUMERIC',
                ),
                array(
                    'key' => '_price',
                    'value' => $max_price,
                    'compare' => '<=',
                    'type' => 'NUMERIC',
                ),
            ),
            'orderby' => 'rand',
        );
        
        // Apply filter settings
        $args = self::apply_ob_filter_settings( $args, $rules );
        
        $products = new \WP_Query( $args );
        
        if( $products->have_posts() ) {
            return $products->posts[0]->ID;
        }
        
        return false;
    }


    /**
     * maybe match offer product with main product
     * 
     * @param $offer_products, $main_products
     * @since 1.0.9
     * @return Bool
     */
    public static function maybe_match( $funnel_id, $offer_products, $main_products ){

        if( $funnel_id ){
            $is_global_funnel = get_post_meta( $funnel_id, 'is_global_funnel', true );
            if( 'yes' === $is_global_funnel ){
                $is_skip = get_post_meta( $funnel_id, '_wpfunnels_skip_offer', true );
                if( isset($is_skip['skip_offer']) && $is_skip['skip_offer'] === 'yes' ){
                    if( is_array($offer_products) ){
                        if( isset($offer_products['show']) && is_array($main_products) ){
                            $index = array_search($offer_products['show'], array_column($main_products, 'id'));
                            if( false !== $index ){
                                if( isset($is_skip['skip_if_quantity']) && $is_skip['skip_if_quantity'] === 'yes' ){
                                    if( (int)$main_products[$index]['quantity'] >= (int)$offer_products['quantity'] ){                                      
                                        return true;
                                    }
                                }else{
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }


    /**
     * Get best selling product on woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_least_sold_product( $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            global $wpdb;
            $limit_clause = intval($limit) <= 0 ? '' : 'LIMIT '. intval($limit);
            $curent_month = date('Y-m-01 00:00:00');
            

            return (array) $wpdb->get_results("
                SELECT p.ID as id, COUNT(oim2.meta_value) as count
                FROM {$wpdb->prefix}posts p
                INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim
                    ON p.ID = oim.meta_value
                INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2
                    ON oim.order_item_id = oim2.order_item_id
                INNER JOIN {$wpdb->prefix}woocommerce_order_items oi
                    ON oim.order_item_id = oi.order_item_id
                INNER JOIN {$wpdb->prefix}posts as o
                    ON o.ID = oi.order_id
                WHERE p.post_type = 'product'
                AND p.post_status = 'publish'
                AND o.post_status IN ('wc-processing','wc-completed')
                AND o.post_date >= '$curent_month'
                AND oim.meta_key = '_product_id'
                AND oim2.meta_key = '_qty'
                GROUP BY p.ID
                ORDER BY COUNT(oim2.meta_value) + 0 ASC
                $limit_clause
            ");
        }

    }


    /**
     * Get best selling product on woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_highest_sold_product( $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            global $wpdb;
            $limit_clause = intval($limit) <= 0 ? '' : 'LIMIT '. intval($limit);
            $curent_month = date('Y-m-01 00:00:00');

            return (array) $wpdb->get_results("
                SELECT p.ID as id, COUNT(oim2.meta_value) as count
                FROM {$wpdb->prefix}posts p
                INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim
                    ON p.ID = oim.meta_value
                INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2
                    ON oim.order_item_id = oim2.order_item_id
                INNER JOIN {$wpdb->prefix}woocommerce_order_items oi
                    ON oim.order_item_id = oi.order_item_id
                INNER JOIN {$wpdb->prefix}posts as o
                    ON o.ID = oi.order_id
                WHERE p.post_type = 'product'
                AND p.post_status = 'publish'
                AND o.post_status IN ('wc-processing','wc-completed')
                AND o.post_date >= '$curent_month'
                AND oim.meta_key = '_product_id'
                AND oim2.meta_key = '_qty'
                GROUP BY p.ID
                ORDER BY COUNT(oim2.meta_value) + 0 DESC
                $limit_clause
            ");
        }
    }


    /**
     * Get most popular product on woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_most_popular_product( $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array(
                'post_type' 	=> array( 'product' ),
                'meta_key'  	=> 'total_sales',
                'orderby'   	=> 'meta_value_num',
                'order' 		=> 'desc',
                'posts_per_page'=> $limit ? $limit : 1
            );
            $popular_products = new WP_Query( $args );

            return (array)$popular_products;
        }
    }

    
    /**
     * Get avg rating product on woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_highest_avg_rating_product( $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array(
                'post_type' 	=> array( 'product' ),
                'orderby'        => 'meta_value_num',
                'order'          => 'desc',
                'meta_key'       => '_wc_average_rating',
                'posts_per_page'=> $limit ? $limit : 1
            );
            $highest_rating = new WP_Query( $args );

            return (array)$highest_rating;
        }
    }


    /**
     * Get most reviewed product on woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_most_reviewed_product( $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array(
                'post_type' 	=> array( 'product' ),
                'orderby'        => 'meta_value_num',
                'order'          => 'desc',
                'meta_key'       => '_wc_review_count',
                'posts_per_page'=> $limit ? $limit : 1
            );
            $most_reviewed = new WP_Query( $args );

            return (array)$most_reviewed;
        }
        
    }


    /** 
     * Compare current date to a date range
     * 
     * 
     * @param mixed current_date
     * @param mixed $rule
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function date_is_within_date_range( $current_date, $rule) {
        $current_date = date('Y-m-d', strtotime($current_date));
        $startDate    = date('Y-m-d', strtotime($rule['startDate']));
        $endDate      = date('Y-m-d', strtotime($rule['endDate']));
        if(($current_date >= $startDate) && ($current_date <= $endDate)){
            return true;
        }else{
            return false;
        }
    }


    /**
     * Get best selling product on woo shop
     * 
     * @param String
     * @return Array
     * 
     * @param mixed $current_date
     * @param $rule
     * 
     * @return array
     */
    public static function get_highest_sold_product_for_offer( $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array(
                'post_type'      => array( 'product' ),
                'meta_key'       => 'total_sales',
                'orderby'        => 'meta_value_num',
                'posts_per_page' => $limit ? $limit : 1
            );
            $highest_sold = new \WP_Query( $args );
            return (array)$highest_sold;
        }
    }


    /** 
     * Compare current date to order date
     * 
     * @param mixed $value 
     * 
     * @return bool 
     * 
    */ 
    public static function date_is_similiar_to_current_date( $current_date, $rule ) { 
        $current_date = date( 'Y-m-d', strtotime( $current_date ) ); 
        $date = date( 'Y-m-d', strtotime( $rule['date'] ) ); 
        if( $date == $current_date ){ 
            return true; 
        }
        else{ 
            return false; 
        } 
    }


    /**
     * Get best selling product on woo shop in a category
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     */
    public static function get_highest_sold_product_in_category_for_offer( $limit, $category){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type' => array( 'product' ),
                'posts_per_page' => $limit ? $limit : 1, 
                'product_cat' => $category, 
                'meta_key'      => 'total_sales',
                'orderby'       => 'meta_value_num', 
            );
            $highest_sold = new WP_Query( $args );
            return (array)$highest_sold;
        }
    }


    /**
     * Get best selling product on woo shop in a tag
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     */
    public static function get_highest_sold_product_in_tag_for_offer(  $tag_id, $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            $tag = get_term( $tag_id );
            if( isset($tag->slug) ){
                $args = array( 
                    'post_type' => array( 'product' ),
                    'posts_per_page' => $limit ? $limit : 1, 
                    'tax_query' => array(
                        'relation' => 'AND',
                        array(
                            'taxonomy' => 'product_tag',
                            'field'    => 'slug',
                            'terms'    => $tag->slug,
                        )
                    ),
                    'meta_key'      => 'total_sales',
                    'orderby'       => 'meta_value_num', 
                );
                $highest_sold = new WP_Query( $args );
                return (array)$highest_sold;
            }
        }
    }


    /**
     * Get best selling product on woo shop in a tag
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     */
    public static function get_highest_sold_product_in_tag_for_offer_for_widget(  $tag_id, $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            $tag = get_term( $tag_id );
            if( isset($tag->slug) ){
                $args = array( 
                    'post_type' => array( 'product' ),
                    'posts_per_page' => $limit ? $limit : 1, 
                    'tax_query' => array(
                        'relation' => 'AND',
                        array(
                            'taxonomy' => 'product_tag',
                            'field'    => 'slug',
                            'terms'    => $tag->slug,
                        )
                    ),
                    'meta_key'      => 'total_sales',
                    'orderby'       => 'meta_value_num', 
                );
                $highest_sold = new WP_Query( $args );
                return (array)$highest_sold;
            }
            return [];
        }
    }



    /**
     * Updates random products which has been offered on render
     * 
     * @param String
     * @return void
     * 
     * @since 1.0.14
     * 
     */
    public static function get_random_product_in_category_for_offer( $limit, $category){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type'         => array( 'product' ),
                'posts_per_page'    => $limit ? $limit : 1, 
                'status'            => 'publish',
                'product_cat'       => $category,
                'orderby'           => 'rand', 
                'suppress_filters'  => true,
            );
            $rand_product = new WP_Query( $args );
            update_option( 'wpfunnels_dynamic_offer_data', wp_json_encode($rand_product->posts) );
        }
    }


    /**
     * Get random product on woo shop in a category
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_random_product_in_category_within_price_for_offer( $category, $priceFrom, $priceTo, $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type'         => array( 'product' ),
                'posts_per_page'    => $limit ? $limit : 1, 
                'status'            => 'publish',
                'product_cat'       => $category,
                'orderby'           => 'rand', 
                'suppress_filters'  => true,
                'meta_query' => array(
                    array(
                        'key' => '_price',
                        'value' => array($priceFrom, $priceTo),
                        'compare' => 'BETWEEN',
                        'type' => 'NUMERIC'
                    ),
                ),
            );
            $rand_product = new WP_Query( $args );
            update_option( 'wpfunnels_dynamic_offer_data', wp_json_encode($rand_product->posts) );
        }
    }


    /**
     * Get random product on woo shop in a tag
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_random_product_in_tag_for_offer( $limit, $tag_id){
        if( Wpfnl_functions::is_wc_active() ){
            if( !get_option( 'wpfunnels_dynamic_offer_data' ) ){
                $tag = get_term( $tag_id );
                if( isset($tag->slug) ){
                    $args = array( 
                        'post_type'         => array( 'product' ),
                        'status'            => 'publish',
                        'posts_per_page'    => $limit ? $limit : 1, 
                        'orderby'           => 'rand', 
                        'suppress_filters'  => true,
                        'tax_query' => array(
                            'relation' => 'AND',
                            array(
                                'taxonomy' => 'product_tag',
                                'field'    => 'slug',
                                'terms'    => $tag->slug,
                            )
                        ),
                    );
                    $rand_product = new WP_Query( $args );
                    update_option( 'wpfunnels_dynamic_offer_data', wp_json_encode($rand_product->posts) );
                }
            }
        }
    }


    /**
     * Get random product on woo shop in a tag
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.14
     * 
     */
    public static function get_random_product_in_tag_within_price_for_offer(  $tag_id , $priceFrom, $priceTo, $limit = '-1'){
        if( Wpfnl_functions::is_wc_active() ){
            if( !get_option( 'wpfunnels_dynamic_offer_data' ) ){
                $tag = get_term( $tag_id );
                if( isset($tag->slug) ){
                    $args = array( 
                        'post_type'         => array( 'product' ),
                        'status'            => 'publish',
                        'posts_per_page'    => $limit ? $limit : 1, 
                        'orderby'           => 'rand', 
                        'suppress_filters'  => true,
                        'tax_query' => array(
                            'relation' => 'AND',
                            array(
                                'taxonomy' => 'product_tag',
                                'field'    => 'slug',
                                'terms'    => $tag->slug,
                            )
                        ),
                        'meta_query' => array(
                            array(
                                'key' => '_price',
                                'value' => array($priceFrom, $priceTo),
                                'compare' => 'BETWEEN',
                                'type' => 'NUMERIC'
                            ),
                        ),
                    );
                    $rand_product = new WP_Query( $args );
                    update_option( 'wpfunnels_dynamic_offer_data', wp_json_encode($rand_product->posts) );
                }
            }
        }
    }


    /**
     * Get random product in woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.19
     * 
     */
    public static function get_random_product_in_tag_within_price_for_offer_for_widget( $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type'         => array( 'product' ),
                'posts_per_page'    => $limit ? $limit : 1, 
                'meta_key'          => 'total_sales',
                'orderby'           => 'rand', 
                'suppress_filters'  => true,
            );
            $random_product = new WP_Query( $args );
            return isset($random_product->posts) ? $random_product->posts : [];
        }
    }

    /**
     * Get random product in woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.19
     * 
     */
    public static function get_random_product_in_category_within_price_for_offer_for_widget( $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type'         => array( 'product' ),
                'posts_per_page'    => $limit ? $limit : 1, 
                'meta_key'          => 'total_sales',
                'orderby'           => 'rand', 
                'suppress_filters'  => true,
            );
            $random_product = new WP_Query( $args );
            return isset($random_product->posts) ? $random_product->posts : [];
        }
    }


    /**
     * Get random product in woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.19
     * 
     */
    public static function get_random_product_in_tag_for_offer_for_widget( $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type'         => array( 'product' ),
                'posts_per_page'    => $limit ? $limit : 1, 
                'meta_key'          => 'total_sales',
                'orderby'           => 'rand', 
                'suppress_filters'  => true,
            );
            $random_product = new WP_Query( $args );
            return isset($random_product->posts) ? $random_product->posts : [];
        }
    }


    /**
     * Get random product in woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.19
     * 
     */
    public static function get_random_product_in_shop( $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            if( !get_option( 'wpfunnels_dynamic_offer_data' ) ){
                $args = array( 
                    'post_type'         => array( 'product' ),
                    'posts_per_page'    => $limit ? $limit : 1, 
                    'meta_key'          => 'total_sales',
                    'orderby'           => 'rand', 
                    'suppress_filters'  => true,
                );
                $random_product = new WP_Query( $args );
                update_option( 'wpfunnels_dynamic_offer_data', wp_json_encode($random_product->posts) );
            }
        }
    }


    /**
     * Get random product in woo shop
     * 
     * @param String
     * @return Array
     * 
     * @since 1.0.19
     * 
     */
    public static function get_random_product_in_shop_for_widget( $limit = '-1' ){
        if( Wpfnl_functions::is_wc_active() ){
            $args = array( 
                'post_type'         => array( 'product' ),
                'posts_per_page'    => $limit ? $limit : 1, 
                'meta_key'          => 'total_sales',
                'orderby'           => 'rand', 
                'suppress_filters'  => true,
            );
            $random_product = new WP_Query( $args );
            return isset($random_product->posts) ? $random_product->posts : [];
        }
    }


    /**
     * Check user is returning customer or not
     * 
     * @param Number $user_id
     * @return Bool
     * @since 1.0.25
     */
    public static function maybe_returning_user( $user_id = 0 ) {
        if ( ! is_user_logged_in() && $user_id === 0 ) {
            return false;
        }

        global $wpdb;
        $count = $wpdb->get_var( $wpdb->prepare("
            SELECT COUNT(cus.customer_id) FROM {$wpdb->prefix}wc_customer_lookup AS cus
            WHERE cus.user_id = '%s'
            LIMIT 1
        ", $user_id ) );
        
        return $count > 0;
    }


    /**
     * Check user is returning customer or not within last X days
     * 
     * @param Number $user_id
     * @param Number $days
     * 
     * @return Bool 
     * 
     * @since 1.0.25
     */
    public static function maybe_returning_user_within_days( $user_id, $days ) {
        if ( ! is_user_logged_in() && $user_id === 0 ) {
            return false;
        }

        global $wpdb;
        $count = $wpdb->get_var( $wpdb->prepare("
            SELECT COUNT(cus.customer_id) FROM {$wpdb->prefix}wc_customer_lookup AS cus
            WHERE cus.user_id = '%s'
            AND cus.date_last_active > NOW() - INTERVAL '%s' DAY
            LIMIT 1
        ", $user_id, $days ) );
        return $count > 0;
    }

    /**
     * Updates the product price based on the quantity.
     *
     * @param int   $quantity      The quantity to update the prices for.
     * @param array $offer_product The array of offer product information.
     *
     * @return array The updated offer product information with adjusted prices.
     * @since 1.1.3
     */
    public static function update_product_price_on_quantity( $quantity = 0, $offer_product = []){
        if ( isset( $offer_product['qty'], $offer_product['unit_price'], $offer_product['unit_price_tax'], $offer_product['args'], $offer_product['price'],  $offer_product['total'] )){
            $subtotal = isset( $offer_product['args']['subtotal'] ) ? (float)$offer_product['args']['subtotal'] : (float)$offer_product['unit_price'];
            $total    = isset( $offer_product['args']['total'] ) ? (float)$offer_product['args']['total'] : (float)$offer_product['unit_price'];

            $quantity = (float)$quantity;

            $offer_product['qty']              = (float)$offer_product['qty'] * $quantity;
            $offer_product['unit_price']       = (float)$offer_product['unit_price'] * $quantity;
            $offer_product['unit_price_tax']   = (float)$offer_product['unit_price_tax'] * $quantity;
            $offer_product['args']['subtotal'] = $subtotal * $quantity;
            $offer_product['args']['total']    = $total * $quantity;
            $offer_product['price']            = (float)$offer_product['price'] * $quantity;
            $offer_product['total']            = (float)$offer_product['total'] * $quantity;
        }
        return $offer_product;
    }


    /**
     * Retrieves the matched GBF URL.
     *
     * @return string The matched GBF URL.
     * 
     * @since 1.1.9
     */
    public static function get_matched_gbf_url(){
        
        if( !Wpfnl_functions::is_wc_active() ){
            return false;
        }

        $redirect_url = '';
        $cookie_products = array();

        if( WC()->cart && !is_checkout() && ( is_cart() || is_shop() || is_product() ) ) {

            // No funnel is flagged as global, so there is nothing to match against
            // and no reason to walk the cart or write the coupon cookie.
            if( !Wpfnl_Pro_GB_Actions::getInstance()->has_active_global_funnels() ){
                return false;
            }

            $cart_total = WC()->cart->get_totals();
           
            $coupons = WC()->cart->get_applied_coupons();
            @setcookie( 'wpfnl_gbf_coupon', wp_json_encode($coupons) , time() + 3600, '/', COOKIE_DOMAIN );
            
            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                $global_funnels = Wpfnl_Pro_GB_Actions::getInstance()->get_activated_global_funnels();
                if( $global_funnels ){
                    
                    foreach ( $global_funnels as $funnel ) {
                        $funnel_id = $funnel->ID;
                        $gb_funnel_settings = wpfnl()->meta->get_funnel_meta( $funnel_id, 'global_funnel_start_condition' );

                        if( $gb_funnel_settings && is_array( $gb_funnel_settings ) ) {
                            
                            $product = wc_get_product( isset($cart_item['variation_id']) && $cart_item['variation_id'] !== 0 ? $cart_item['variation_id'] : $cart_item['product_id'] );
                            
                            $should_trigger_gb_funnels = Wpfnl_Pro_GB_Actions::getInstance()->should_trigger_gb_funnel( $funnel_id, $product, $gb_funnel_settings, $cart_total['total'], $cart_item['quantity']);
                            if( $cart_item['variation_id'] ){
                                $formatted_variation = array();
                                foreach( $cart_item['variation'] as $key=>$variation ){
                                    $key = str_replace("attribute_","",$key);
                                    $formatted_variation['attribute_'.$key] = $variation;
                                }
                                
                                $data           = array(
                                    'id'            => $cart_item['product_id'],
                                    'variation_id'  => $cart_item['variation_id'],
                                    'variations'    => $formatted_variation,
                                    'quantity'      => $cart_item['quantity'],
                                    'discount_type' => '',
                                    'discount_value'=> '',
                                    'funnel_id'     => $funnel_id,
                                );
                            }else{
                                $data           = array(
                                    'id'            => $cart_item['product_id'],
                                    'quantity'      => $cart_item['quantity'],
                                    'discount_type' => '',
                                    'discount_value'=> '',
                                    'funnel_id'     => $funnel_id,
                                );
                            }                            

                            array_push($cookie_products,$data);
                            WC()->session->set('wpfunnels_global_funnel_product', $cookie_products);
                            
                            if( !$should_trigger_gb_funnels ) {
                                continue;
                            }
                            $gbf_products = array();
                          
                            if( $cart_item['variation_id'] ){
                                $formatted_variation = array();
                                foreach( $cart_item['variation'] as $key=>$variation ){
                                    $key = str_replace("attribute_","",$key);
                                    $formatted_variation['attribute_'.$key] = $variation;
                                }
                                
                                $gbf_data           = array(
                                    'id'            => $cart_item['product_id'],
                                    'variation_id'  => $cart_item['variation_id'],
                                    'variations'    => $formatted_variation,
                                    'quantity'      => $cart_item['quantity'],
                                    'discount_type' => '',
                                    'discount_value'=> '',
                                    'funnel_id'     => $funnel_id,
                                );
                            }else{
                                $gbf_data           = array(
                                    'id'            => $cart_item['product_id'],
                                    'quantity'      => $cart_item['quantity'],
                                    'discount_type' => '',
                                    'discount_value'=> '',
                                    'funnel_id'     => $funnel_id,
                                );
                            }                            

                            array_push($gbf_products,$gbf_data);
                            WC()->session->set('wpfunnels_global_funnel_specific_product', $gbf_products);

                            WC()->session->set('wpfunnels_global_funnel_id', $funnel_id);
                            
                            $steps = Wpfnl_functions::get_steps($funnel_id);
                            if( !$steps ){
                                return $redirect_url;
                            }
                            $key = array_search('checkout', array_column($steps, 'step_type'));
                            $step_id = '';
                            if( $key !== false ){
                                $step_id = $steps[$key]['id'];
                            }
                            if( !$step_id ){
                                return $redirect_url;
                            }
                           
                            $redirect_url = add_query_arg(
                                'global_funnel',
                                'yes',
                                esc_url( get_permalink($step_id) )
                            );
                            break;
                        }
                    }
                }
            }
           
        }
        return $redirect_url;
    }
}