<?php

namespace WPFunnelsPro\GBF;

/**
 * The public-facing functionality of Global Funnels (GBF).
 *
 * @link       https://getwpfunnels.com/
 * @since      1.0.0
 *
 * @package    WPFunnelsPro\GBF
 */
class Wpfnl_Pro_GBF_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpfnl_Pro_Gb_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpfnl_Pro_Gb_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		// wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wpfnl-pro-gb-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpfnl_Pro_Gb_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpfnl_Pro_Gb_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		if ( ! \WPFunnels\Wpfnl_functions::is_wc_active() || is_checkout() ) {
			return;
		}

		// Only load the cart/checkout button rewriter when a global funnel actually
		// matches the current cart. Without a target URL the script has nothing to do
		// but would still poll the DOM on every page load.
		$redirect_url = Wpfnl_Pro_GBF_Functions::get_matched_gbf_url();
		if ( ! $redirect_url ) {
			return;
		}

		wp_enqueue_script( $this->plugin_name, WPFNL_PRO_URL . 'public/assets/js/gbf/wpfnl-pro-gb-public.js', array( 'jquery' ), $this->version, false );

		wp_localize_script( $this->plugin_name, 'wpfnl_pro_gbf_obj', [
				'ajaxurl'           => admin_url( 'admin-ajax.php' ),
				'funnel_id'         => get_post_meta( get_the_ID(), '_funnel_id', true ),
				'step_id'           => get_the_ID(),
				'ajaxNonce'        => wp_create_nonce( 'wpfnl_public_pro' ),
				'is_user_logged_in' => is_user_logged_in(),
				'user_id'           => get_current_user_id(),
				'redirect_url'      => $redirect_url,
				'general_settings' 	=> \WPFunnels\Wpfnl_functions::get_general_settings(),
			]
		);
	}


	/**
     * Adds coupons to the global funnel checkout
	 * 
	 * This function is triggered after the initialization of the checkout process for a global funnel.
	 * It checks if the funnel is a global funnel and applies any available coupons stored in the 'wpfnl_gbf_coupon' cookie
	 * to the cart as discounts if they have not already been applied.
     *
     * @param int|string $funnel_id Global Funnel ID.
     *
     * @since 1.1.5
	 * @return void
     */
	public function after_init_checkout( $funnel_id ){
		$is_global_funnel = 'yes' === get_post_meta( $funnel_id, 'is_global_funnel', true );
        if( $is_global_funnel ) {
            $gbf_coupons = [];
            if( isset( $_COOKIE[ 'wpfnl_gbf_coupon' ] ) ) {
                $gbf_coupons = json_decode( wp_unslash( $_COOKIE[ 'wpfnl_gbf_coupon' ] ), true );
            }

            if( !empty( $gbf_coupons ) ) {
                foreach( $gbf_coupons as $cp ) {
                    if( !in_array( $cp, WC()->cart->applied_coupons ) ) {
                        WC()->cart->add_discount( $cp );
                    }
                }
            }
        }
	}
}
