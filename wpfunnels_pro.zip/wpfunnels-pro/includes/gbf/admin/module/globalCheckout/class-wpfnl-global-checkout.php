<?php

namespace WPFunnelsPro\GBF\Admin\Modules\GlobalCheckout;

class Wpfnl_Global_Checkout_Ajax{

    public function init()
    {
		wp_ajax_helper()->handle('wpfnl-enable-global-funnel')
            ->with_callback([ $this, 'wpfnl_enable_global_funnel' ])
            ->with_validation($this->get_validation_data());
            
        wp_ajax_helper()->handle('wpfnl-get-enable-global-funnel-data')
            ->with_callback([ $this, 'wpfnl_get_enable_global_funnel_data' ])
            ->with_validation($this->get_validation_data());

    }

    /**
     * Validate data
     */
    public function get_validation_data()
    {
        return[
            'logged_in' => true,
            'user_can' => 'wpf_manage_funnels',
        ];
    }


    /**
     * Enable global checkout option
     */
    public function wpfnl_enable_global_funnel( $payload ){
        $funnel_id  = $payload['funnel_id'];
        $data       = get_post_meta( $payload['funnel_id'], 'is_global_funnel', true );
        if($data === 'yes' ){
            update_post_meta( $funnel_id, 'is_global_funnel', 'no' );
            $data = get_post_meta( $payload['funnel_id'], 'is_global_funnel', true );
        }else{
            // Enabling global funnel - migrate existing order bumps to manual mode
            update_post_meta( $funnel_id, 'is_global_funnel', 'yes' );
            $this->migrate_existing_order_bumps_to_manual( $funnel_id );
            $data = get_post_meta( $payload['funnel_id'], 'is_global_funnel', true );
        }
        \WPFunnelsPro\GBF\Actions\Wpfnl_Pro_GB_Actions::flush_activated_global_funnels_cache();

        return [
            'status' => 'success',
            'data'   => $data
        ]; 
    }

    /**
     * Migrate existing order bumps to manual mode when enabling global funnel
     * This ensures backward compatibility for funnels created before the auto-match feature
     * 
     * @param int $funnel_id The funnel ID
     * @return void
     * @since 2.8.0
     */
    private function migrate_existing_order_bumps_to_manual( $funnel_id ) {
        // Get all steps in this funnel
        $steps = \WPFunnels\Wpfnl_functions::get_steps( $funnel_id );
        if( !$steps || !is_array($steps) ) {
            return;
        }
        
        // Loop through each step to find checkout steps
        foreach( $steps as $step ) {
            if( $step['step_type'] !== 'checkout' ) {
                continue;
            }
            
            $step_id = $step['id'];
            
            // Get order bump settings for this checkout step
            $ob_settings = get_post_meta( $step_id, 'order-bump-settings', true );
            
            if( !$ob_settings || !is_array($ob_settings) ) {
                continue;
            }
            
            // Flag to track if any changes were made
            $has_changes = false;
            
            // Loop through each order bump
            foreach( $ob_settings as $key => $ob_product ) {
                // Check if this order bump doesn't have offerSelectionMode set
                // or if it's already set but we want to ensure it's manual for existing ones
                if( !isset($ob_product['offerSelectionMode']) ) {
                    // Set to manual mode for backward compatibility
                    $ob_settings[$key]['offerSelectionMode'] = 'manual';
                    $has_changes = true;
                }
            }
            
            // Update the order bump settings if changes were made
            if( $has_changes ) {
                update_post_meta( $step_id, 'order-bump-settings', $ob_settings );
            }
        }
    }

    /**
     * 
     */
    public function wpfnl_get_enable_global_funnel_data( $payload ){
        $data = get_post_meta( $payload['funnel_id'], 'is_global_funnel', true );
        return [
            'status' => 'success',
            'data'   => $data
        ];
    }
}