<?php

namespace WPFunnelsPro;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plan tier helper for WPFunnels Pro.
 *
 * Determines whether the active license grants access to CRM integrations
 * or Global Funnels (GBF), and provides legacy fallbacks for users who
 * previously held active addon licenses.
 *
 * @since 2.9.0
 * @package WPFunnelsPro
 */
class Wpfnl_Pro_Plan {

    /**
     * Plan slugs that include CRM integrations.
     */
    const PLANS_WITH_INTEGRATIONS = [ 'wpfunnels_tier1', 'wpfunnels_tier2', 'wpfunnels_tier3', 'mediumannual', 'largeannual', 'unlimited', 'bundlelifetime', 'lifetime', 'mediumlifetime', 'largelifetime', 'wpfunnels_tier2', 'wpfunnels_tier3', 'growth', 'growthannual', 'growthlifetime', 'business', 'businessannual', 'businesslifetime' ];

    /**
     * Plan slugs that include Global Funnels (GBF).
     */
    const PLANS_WITH_GBF = [ 'wpfunnels_tier1', 'wpfunnels_tier2', 'wpfunnels_tier3', 'mediumannual', 'largeannual', 'unlimited', 'bundlelifetime', 'lifetime', 'mediumlifetime', 'largelifetime', 'wpfunnels_tier2', 'wpfunnels_tier3', 'growth', 'growthannual', 'growthlifetime', 'business', 'businessannual', 'businesslifetime' ];

    /**
     * Return the plan slug stored during the last license activation.
     *
     * @return string e.g. 'starter', 'pro', 'growth', 'business', or '' if unknown.
     */
    public static function get_current_plan(): string {
        return (string) get_option( 'wpfunnels_pro_license_plan', '' );
    }

    /**
     * Decide whether integrations should be available for the current site.
     *
     * Rules (checked in order):
     *  1. Pro license must be active.
     *  2. Plan is 'mediumannual' or 'largeannual' → grant access.
     *  3. Legacy fallback: old addon license was previously activated → grant
     *     access during transition window so existing users are not locked out.
     *
     * @return bool
     */
    public static function is_integration_license_active(): bool {
        if ( 'active' !== get_option( 'wpfunnels_pro_license_status' ) ) {
            return false;
        }

        return in_array( self::get_current_plan(), self::PLANS_WITH_INTEGRATIONS, true );
    }

    /**
     * Decide whether Global Funnels (GBF) should be available for the current site.
     *
     * Rules (checked in order):
     *  1. Pro license must be active.
     *  2. Plan is 'mediumannual' or 'largeannual' → grant access.
     *  3. Legacy fallback: old wpfunnels-pro-gbf addon license was previously
     *     activated → grant access so existing ~3k users are not locked out.
     *
     * @since 2.9.1
     * @return bool
     */
    public static function is_gbf_license_active(): bool {
        if ( 'active' !== get_option( 'wpfunnels_pro_license_status' ) ) {
            return false;
        }

        return in_array( self::get_current_plan(), self::PLANS_WITH_GBF, true );
    }
}
