<?php
/**
 * Integrations page data for the React admin screen.
 *
 * Builds the `providers` schema that the free plugin's React Integrations
 * page renders in "active" mode. Every value mirrors the legacy card partials
 * in admin/partials/integrations/helper/* (markup classes, labels, copy, text
 * domains) and the client-side rules in admin/assets/js/wpfnl-pro-crm-integrations.js
 * so the React page can reproduce the legacy screen without loading the jQuery file.
 *
 * @package WPFunnelsPro\Integrations\CRM
 * @since   2.9.4
 */

namespace WPFunnelsPro\Integrations\CRM;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CRM_Integrations_Page_Data {

    /**
     * Text domain used by the legacy card partials.
     */
    const PARTIAL_TEXT_DOMAIN = 'wpfunnels-pro';

    /**
     * Filter callback for `wpfunnels/integrations_page_data`.
     *
     * @param array $data Page data built by the free plugin.
     * @return array
     */
    public function filter_page_data( $data ) {
        if ( ! is_array( $data ) ) {
            $data = [];
        }

        $data['mode']           = 'active';
        $data['active_heading'] = __( 'Enable WPFunnels Integration With Your Favourite Automation Tool Or CRM', 'wpfnl-pro' );
        $data['providers']      = $this->get_providers();

        return $data;
    }

    /**
     * Provider schema, in the order of wpfnl-pro-integrations-view.php.
     *
     * @return array
     */
    public function get_providers() {
        $providers = [];
        foreach ( $this->get_definitions() as $definition ) {
            $providers[] = $this->build_provider( $definition );
        }
        return $providers;
    }

    /**
     * Turn a raw definition into the public schema entry.
     *
     * @param array $definition Provider definition.
     * @return array
     */
    private function build_provider( array $definition ) {
        $toggle_only = empty( $definition['fields'] );
        $slug        = $definition['ui_slug'];

        $fields = [];
        if ( ! $toggle_only ) {
            foreach ( $definition['fields'] as $field ) {
                $fields[] = [
                    'name'        => $field['name'],
                    'input_class' => $field['input_class'],
                    'label'       => $field['label'],
                    'type'        => 'text',
                    'required'    => true,
                    'hint_class'  => $field['hint_class'],
                    'hint_text'   => $field['hint_text'],
                ];
            }
        }

        $provider = [
            'key'          => $definition['key'],
            'ui_slug'      => $slug,
            'title'        => $definition['title'],
            'logo_svg'     => $this->render_svg( $definition['svg'] . '-logo' ),
            'favicon_svg'  => $this->render_svg( $definition['svg'] . '-favicon' ),
            'intro_html'   => $this->guide_html( $definition['intro'], $definition['guide'] ),
            'description'  => $definition['description'],
            'toggle_only'  => $toggle_only,
            'oauth'        => ! empty( $definition['oauth'] ),
            'button_tag'   => $toggle_only ? null : $definition['button_tag'],
            'status_key'   => $toggle_only ? null : $definition['status_key'],
            'verified_key' => $toggle_only ? null : $definition['verified_key'],
            'fields'       => $fields,
        ];

        if ( ! $toggle_only ) {
            $provider['auth_label']   = __( 'Authorize Now', 'wpfunnels-pro' );
            $provider['reset_label']  = __( 'Reset', 'wpfunnels-pro' );
            $provider['invalid_text'] = $definition['invalid_text'];
        }

        if ( ! empty( $definition['notice_html'] ) ) {
            $provider['notice_html'] = $definition['notice_html'];
        }

        return $provider;
    }

    /**
     * Render one of the legacy SVG include files.
     *
     * @param string $name File name without extension, e.g. 'mailchimp-logo'.
     * @return string
     */
    private function render_svg( $name ) {
        $file = WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/' . $name . '.php';
        if ( ! file_exists( $file ) ) {
            return '';
        }
        ob_start();
        include $file;
        return trim( (string) ob_get_clean() );
    }

    /**
     * Build the `.addon-body-title` inner HTML exactly as the partials echo it.
     *
     * The partials pass the sentence through sprintf() untranslated, so it is
     * kept untranslated here too.
     *
     * @param string $sentence Intro sentence.
     * @param string $link     Documentation link.
     * @return string
     */
    private function guide_html( $sentence, $link ) {
        return sprintf( $sentence . ' <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $link );
    }

    /**
     * Build a field definition.
     *
     * @param string $name        Payload / stored key.
     * @param string $slug        UI slug (CSS prefix).
     * @param string $suffix      Input class suffix (apikey, server, url, api, secret).
     * @param string $label       Translated label.
     * @param string $hint_suffix Hint class suffix (api, server, url, secret).
     * @param string $hint_text   Hint text exactly as the partial prints it.
     * @return array
     */
    private function field( $name, $slug, $suffix, $label, $hint_suffix, $hint_text ) {
        return [
            'name'        => $name,
            'input_class' => $slug . '-' . $suffix,
            'label'       => $label,
            'hint_class'  => $slug . '-hints-' . $hint_suffix,
            'hint_text'   => $hint_text,
        ];
    }

    /**
     * Raw provider definitions taken from the 18 partials.
     *
     * @return array
     */
    private function get_definitions() {
        $required        = __( 'Field required', 'wpfunnels-pro' );
        $required_raw    = 'Field required';
        $invalid         = __( 'Please input valid credentials', 'wpfunnels-pro' );
        $invalid_raw     = 'Please input valid credentials';
        $docs            = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/';
        $connect_with    = 'Please connect with your %s account by providing the following credentials:';
        $integration_ok  = 'Integration successful! You can now send data to %s based on user events in your funnels.';

        return [
            [
                'key'          => 'mailchimp',
                'ui_slug'      => 'mailchimp',
                'svg'          => 'mailchimp',
                'title'        => 'MailChimp',
                'intro'        => sprintf( $connect_with, 'MailChimp' ),
                'guide'        => $docs . 'integrate-with-mailchimp/',
                'description'  => __( 'MailChimp is one of the best marketing, automation & email marketing platforms.', 'wpfunnels-pro' ),
                'button_tag'   => 'button',
                'status_key'   => 'mailchimp_status',
                'verified_key' => 'mailchimp_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'mailchimp_apikey', 'mailchimp', 'apikey', __( 'API key', 'wpfunnels-pro' ), 'api', $required ),
                    $this->field( 'mailchimp_server', 'mailchimp', 'server', __( 'Server', 'wpfunnels-pro' ), 'server', $required ),
                ],
            ],
            [
                'key'          => 'activecamp',
                'ui_slug'      => 'active-campaign',
                'svg'          => 'active-campaign',
                'title'        => 'ActiveCampaign',
                'intro'        => sprintf( $connect_with, 'ActiveCampaign' ),
                'guide'        => $docs . 'integrate-with-activecampaign/',
                'description'  => __( 'ActiveCampaign - reliable platform with email marketing, automation, and CRM for enhanced customer experience.', 'wpfunnels-pro' ),
                'button_tag'   => 'button',
                // The jQuery sends `active_camp_status`, the server stores `activecamp_status`.
                'status_key'   => 'active_camp_status',
                'verified_key' => 'activecamp_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'active_camp_url', 'active-campaign', 'url', __( 'Base URL', 'wpfunnels-pro' ), 'url', $required ),
                    $this->field( 'active_camp_api', 'active-campaign', 'api', __( 'API Token', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'         => 'mailpoet',
                'ui_slug'     => 'mailpoet',
                'svg'         => 'mailpoet',
                'title'       => 'MailPoet',
                'intro'       => sprintf( $integration_ok, 'MailPoet' ),
                'guide'       => $docs . 'integrate-with-mailpoet/',
                'description' => __( "MailPoet helps to manage your subscriber's list, run email campaigns, and set up automation easily in WordPress.", 'wpfunnels-pro' ),
                'fields'      => [],
            ],
            [
                'key'          => 'cc',
                'ui_slug'      => 'constant-contact',
                'svg'          => 'constant-contact',
                'title'        => 'Constant Contact',
                'intro'        => sprintf( $connect_with, 'Constant Contact' ),
                'guide'        => $docs . 'integrate-with-constantcontact/',
                'description'  => __( 'Constant Contact is one of the most renowned email marketing tools with a super easy UI.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'oauth'        => true,
                'status_key'   => 'cc_status',
                'verified_key' => 'cc_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'cc_url', 'constant-contact', 'url', __( 'Redirect URL', 'wpfunnels-pro' ), 'url', $required ),
                    $this->field( 'cc_api', 'constant-contact', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                    $this->field( 'cc_secret', 'constant-contact', 'secret', __( 'API Secret', 'wpfunnels-pro' ), 'secret', $required ),
                ],
            ],
            [
                'key'          => 'aweber',
                'ui_slug'      => 'aweber',
                'svg'          => 'aweber',
                'title'        => 'AWeber',
                'intro'        => sprintf( $connect_with, 'AWeber' ),
                'guide'        => $docs . 'integrate-with-aweber/',
                'description'  => __( 'Aweber is a prominent email marketing tool that allows you to collect leads and run automated email campaigns & sequences easily.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'oauth'        => true,
                'status_key'   => 'aweber_status',
                'verified_key' => 'aweber_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'aweber_url', 'aweber', 'url', __( 'Redirect URL', 'wpfunnels-pro' ), 'url', $required_raw ),
                    $this->field( 'aweber_api', 'aweber', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required_raw ),
                    $this->field( 'aweber_secret', 'aweber', 'secret', __( 'API Secret', 'wpfunnels-pro' ), 'secret', $required_raw ),
                ],
            ],
            [
                'key'          => 'sendinblue',
                'ui_slug'      => 'sendinblue',
                'svg'          => 'sendinblue',
                'title'        => 'Sendinblue',
                'intro'        => sprintf( $connect_with, 'Sendinblue' ),
                'guide'        => $docs . 'integrate-with-sendinblue/',
                'description'  => __( 'Sendinblue is an all-in-one platform to run B2B and B2C email campaigns for digital marketing and marketing automation.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'sendinblue_status',
                'verified_key' => 'sendinblue_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'sendinblue_api', 'sendinblue', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'          => 'mailerlite',
                'ui_slug'      => 'mailerlite',
                'svg'          => 'mailerlite',
                'title'        => 'MailerLite',
                'intro'        => sprintf( $connect_with, 'MailerLite' ),
                'guide'        => $docs . 'integrate-with-mailerlite/',
                'description'  => __( 'MailerLite is an email marketing software designed to help people of all skill levels create successful marketing campaigns.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'mailerlite_status',
                'verified_key' => 'mailerlite_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'mailerlite_api', 'mailerlite', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'          => 'getresponse',
                'ui_slug'      => 'getresponse',
                'svg'          => 'getresponse',
                'title'        => 'GetResponse',
                'intro'        => sprintf( $connect_with, 'GetResponse' ),
                'guide'        => $docs . 'integrate-with-getresponse/',
                'description'  => __( 'GetRespnse is an all-in-one marketing platform that comes with powerful email marketing features, CRM, and advanced automations.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'getresponse_status',
                'verified_key' => 'getresponse_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'getresponse_api', 'getresponse', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'          => 'encharge',
                'ui_slug'      => 'encharge',
                'svg'          => 'encharge',
                'title'        => 'Encharge',
                'intro'        => sprintf( $connect_with, 'Encharge' ),
                'guide'        => $docs . 'integrate-with-encharge/',
                'description'  => __( 'Encharge is an advanced automation tool focused on visually creating and running behaviour-based email campaigns easily.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'encharge_status',
                'verified_key' => 'encharge_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'encharge_api', 'encharge', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'         => 'zapier',
                'ui_slug'     => 'zapier',
                'svg'         => 'zapier',
                'title'       => 'Zapier',
                'intro'       => sprintf( $integration_ok, 'Zapier' ),
                'guide'       => 'https://getwpfunnels.com/docs/funnel-integrations/zapier-integration/',
                'description' => __( 'Zapier is the most popular automation tool that lets you connect your favorite tools and help you automate workflows.', 'wpfunnels-pro' ),
                'fields'      => [],
            ],
            [
                'key'          => 'hubspot',
                'ui_slug'      => 'hubspot',
                'svg'          => 'hubspot',
                'title'        => 'HubSpot',
                'intro'        => sprintf( $connect_with, 'Hubspot' ),
                'guide'        => $docs . 'integrate-with-hubspot/',
                'description'  => __( 'HubSpot is a CRM platform with all the software, integrations, and resources you need to connect marketing, sales, content management, and customer service.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'hubspot_status',
                'verified_key' => 'hubspot_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'hubspot_api', 'hubspot', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'          => 'convertkit',
                'ui_slug'      => 'convertkit',
                'svg'          => 'convertkit',
                'title'        => 'ConvertKit',
                'intro'        => sprintf( $connect_with, 'ConvertKit' ),
                'guide'        => $docs . 'integrate-with-convertkit/',
                'description'  => __( 'ConvertKit is an email marketing tool that caters to professional bloggers, podcasters, YouTubers and course creators. It is designed to help them grow and monetize their audience, automate their marketing flows.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'convertkit_status',
                'verified_key' => 'convertkit_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'convertkit_api', 'convertkit', 'api', __( 'API Secret', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'          => 'omnisend',
                'ui_slug'      => 'omnisend',
                'svg'          => 'omnisend',
                'title'        => 'Omnisend',
                'intro'        => sprintf( $connect_with, 'Omnisend' ),
                'guide'        => $docs . 'integrate-with-omnisend/',
                'description'  => __( 'Omnisend is an omni-channel marketing automation platform, built for eCommerce, to help with email automation, SMS & WhatsApp messaging, segmentation, and many more.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'omnisend_status',
                'verified_key' => 'omnisend_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'omnisend_api', 'omnisend', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'         => 'wpfusion',
                'ui_slug'     => 'wpfusion',
                'svg'         => 'wpfusion',
                'title'       => 'WP Fusion',
                'intro'       => sprintf( $integration_ok, 'WP Fusion' ),
                'guide'       => $docs . 'integrate-with-wpfusion/',
                'description' => __( 'WPFusion is a WordPress automation tool to help you integrate your leads and customer data with your preferred CRM.', 'wpfunnels-pro' ),
                'fields'      => [],
            ],
            [
                'key'          => 'zoho',
                'ui_slug'      => 'zoho',
                'svg'          => 'zoho',
                'title'        => 'Zoho CRM',
                'intro'        => sprintf( $connect_with, 'Zoho' ),
                'guide'        => $docs . 'integrate-with-zoho/',
                'description'  => __( 'Zoho CRM is a cloud-based customer relationship management software for managing sales, marketing, and customer support in a single system.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'oauth'        => true,
                'status_key'   => 'zoho_status',
                'verified_key' => 'zoho_status',
                'invalid_text' => $invalid_raw,
                'fields'       => [
                    $this->field( 'zoho_url', 'zoho', 'url', __( 'Redirect URL', 'wpfunnels-pro' ), 'url', $required_raw ),
                    $this->field( 'zoho_api', 'zoho', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required_raw ),
                    $this->field( 'zoho_secret', 'zoho', 'secret', __( 'API Secret', 'wpfunnels-pro' ), 'secret', $required_raw ),
                ],
            ],
            [
                'key'         => 'pabbly',
                'ui_slug'     => 'pabbly',
                'svg'         => 'pabbly',
                'title'       => 'Pabbly Connect',
                // The partial has no full stop before the Guide link.
                'intro'       => 'Integration successful! You can now send data to Pabbly based on user events in your funnels',
                'guide'       => $docs . 'integrate-with-pabbly-connect/',
                'description' => __( 'Pabbly Connect is a powerful automation tool to help you share data between apps & automate manual repetitive tasks in real-time - No Coding Required!', 'wpfunnels-pro' ),
                'fields'      => [],
            ],
            [
                'key'          => 'pabbly_email',
                'ui_slug'      => 'pabbly-email',
                'svg'          => 'pabbly-email',
                'title'        => 'Pabbly Email Marketing',
                'intro'        => sprintf( $connect_with, 'Pabbly' ),
                'guide'        => $docs . 'integrate-with-pabbly-email-marketing/',
                'description'  => __( 'Pabbly Email Marketing is a built-in email marketing powerhouse by Pabbly to run email campaigns with more control.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'pabbly_email_status',
                'verified_key' => 'pabbly_email_status',
                'invalid_text' => $invalid,
                'fields'       => [
                    $this->field( 'pabbly_email_api', 'pabbly-email', 'api', __( 'API Secret', 'wpfunnels-pro' ), 'api', $required ),
                ],
            ],
            [
                'key'          => 'drip',
                'ui_slug'      => 'drip',
                'svg'          => 'drip',
                'title'        => 'Drip',
                'intro'        => sprintf( $connect_with, 'Drip' ),
                'guide'        => $docs . 'integrate-with-drip/',
                'description'  => __( 'Drip CRM is a cloud-based customer relationship management software for managing sales, marketing, and customer support in a single system.', 'wpfunnels-pro' ),
                'button_tag'   => 'a',
                'status_key'   => 'drip_status',
                'verified_key' => 'drip_status',
                'invalid_text' => $invalid_raw,
                'fields'       => [
                    $this->field( 'drip_api', 'drip', 'api', __( 'API Key', 'wpfunnels-pro' ), 'api', $required_raw ),
                ],
            ],
        ];
    }
}
