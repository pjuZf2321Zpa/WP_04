<?php
namespace WPFunnelsPro\Integrations;
use WPFunnels\Traits\SingletonTrait;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Integrations\CRM;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Pabbly\Wpfnl_Integartion_Pabbly_functions;


/**
 * integration class for Pabbly
 *
 * Class Pabbly
 */
class Wpfnl_Pabbly extends CRM {

    use SingletonTrait;

    /**
     * Get CRM Name
     *
     * @return string
     *
     * @since 1.3.2
     */
    public function get_name(){
        return 'Pabbly Connect';
    }

    /**
     * Get user information from an order.
     *
     * @param int|null $order_id    Order ID (optional).
     * @param array    $user_info   Additional user information (optional).
     *
     * @return array User information array
     *
     * @since 1.3.2
     */
    public function get_user_info_from_order( $order_id = null, $user_info = [] ) {

        $user = [];
        $funnel_id = Wpfnl_functions::get_funnel_id_from_order( $order_id );

        if( $funnel_id ){
            $type = get_post_meta( $funnel_id, '_wpfnl_funnel_type', true );

            if( 'lms' === $type ){
                $user = $this->get_user_info_for_lms( $user_info );
            }elseif( 'wc' === $type ){
                $user = $this->get_user_info_for_woo( $order_id, $user_info);
            }elseif( 'lead' === $type ){
                $user = $this->get_user_info_for_lead( $user_info );
            }
        }else{
            $user = $this->get_user_info_for_woo( $order_id, $user_info );
        }
        $user['status']     = 'pending';

        return $user;
    }


    /**
     * Get user information for WooCommerce order.
     *
     * @param int   $order_id   WooCommerce order ID.
     * @param array $user_info  Additional user information (optional).
     *
     * @return array User information array
     *
     * @since 1.3.2
     */
    private function get_user_info_for_woo( $order_id, $user_info = [] ){
        $user = [];
        if( $order_id ){
            $order              = wc_get_order( $order_id );
            if( $order ){
                $customer_id        = $order->get_customer_id();
                $user               = array();

                if( 0 != $customer_id ) {
                    $customer           = new \WC_Customer( $customer_id );
                    $user['email']      = $customer->get_email();
                    $user['first_name'] = $customer->get_first_name();
                    $user['last_name']  = $customer->get_last_name();
                    $user['phone']      = get_user_meta( $customer_id, 'billing_phone', true ) ? get_user_meta( $customer_id, 'billing_phone', true ) : '';
                } else {
                    $user['email']      = $order->get_billing_email();
                    $user['first_name'] = $order->get_billing_first_name();
                    $user['last_name']  = $order->get_billing_last_name();
                    $user['phone']      = $order->get_billing_phone() ? $order->get_billing_phone() : '';
                }
            }else{
                $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
                $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
                $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
            }

        }else{
            $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
            $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
            $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        }
        return $user;
    }


    /**
     * Get user information for LMS.
     *
     * @param array $user_info User information array (optional).
     *
     * @return array User information array
     *
     * @return 1.3.2
     */
    private function get_user_info_for_lms( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;

    }


    /**
     * Get user information for lead.
     *
     * @param array $user_info User information array (optional).
     *
     * @return array User information array
     * @since 1.3.2
     */
    private function get_user_info_for_lead( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;

    }

    /**
     * Send or update data to pabbly.
     *
     * @since 1.3.2
     *
     * @param array $data The data to send or update.
     *
     * @return void|bool
     */
    public function send_or_update_data( $data )
    {
        if ( !$data ){
            return false;
        }

        if( is_array($data['tags']) && isset($data['tags']) && !empty($data['tags']) && isset($data['email']) && $data['email'] ){
            foreach( $data['tags'] as $key => $hook ){
                try{
                    if( $hook ){
                        $client = new \GuzzleHttp\Client( apply_filters( 'wpfunnels/pabbly/http_client_args', [
                            'timeout'         => 15,
                            'connect_timeout' => 5,
                        ] ) );
                        $name = '';
                        if( isset($data['first_name'],$data['last_name']) ){
                            $name = $data['first_name'].' '.$data['last_name'];
                        }elseif( isset($data['first_name'] ) ){
                            $name = $data['first_name'].' '.$data['last_name'];
                        }elseif( isset($data['last_name'] ) ){
                            $name = $data['last_name'];
                        }

                        $json_body_data = $this->get_formated_data( $data, $name );

                        $response = $client->request('POST', $hook, [
                            'headers' => [
                                'Content-Type'      => 'application/json',
                                'Accept' => 'application/json'
                            ],
                            'body'   => $json_body_data
                        ]);

                        if( 200 == $response->getStatusCode() ){
                            $result = json_decode($response->getBody()->getContents());
                            return $result;
                        }

                    }

                }catch (\Exception $e) {
                    error_log( 'WPFunnels Pabbly: ' . $e->getMessage() );
                }
            }
        }
    }


     /**
     * Get formated data to send in pabbly
     *
     * @param array $data
     * @param string $name
     *
     * @return string
     */
    public function get_formated_data( $data, $name){
        $action = isset($data['source']) ? $data['source'] : '';

        $formatted_data = [
                            'ad_tracking'         => 'WPFunnels',
                            'email'               => isset($data['email']) ? $data['email'] : '',
                            'name'                => $name,
                            'phone_number'        => isset($data['phone']) ? $data['phone'] : '',
                            'billing_email'       => isset($data['billing_email']) ? $data['billing_email'] : '',
                            'billing_first_name'  => isset($data['billing_first_name']) ? $data['billing_first_name'] : '',
                            'billing_last_name'   => isset($data['billing_last_name']) ? $data['billing_last_name'] : '',
                            'billing_phone'       => isset($data['billing_phone']) ? $data['billing_phone'] : '',
                        ];

        if ( isset($data['ordered_products']) ){
            for ($idx = 1; $idx <= count($data['ordered_products']); $idx++){
                $formatted_data['product_name_'.$idx] = $data['ordered_products'][$idx-1]['product_name'];
                $formatted_data['product_price_'.$idx] = $data['ordered_products'][$idx-1]['product_price'];
            }
        }

        return json_encode($formatted_data);
    }


    /**
     * Update contact with a specific list.
     *
     * @param Client $client The GuzzleHttp client.
     * @param array  $config_data Configuration data for the contact update.
     * @param int    $list_id The ID of the list to associate the contact with.
     * @param int    $contact_id The ID of the contact to update.
     *
     * @return void
     * @since 1.3.2
     */
    public function update_contact_with_list( $client, $config_data, $list_id , $contacts_id ){
        // TODO: Update list with contact
    }


    /**
     * Update contact with tags
     *
     * @param Client $client The GuzzleHttp client.
     * @param array  $config_data Configuration data for the contact update.
     * @param int    $list_id The ID of the list to associate the contact with.
     * @param int    $contact_id The ID of the contact to update.
     *
     * @return void
     *
     * @since 1.3.2
     */
    private function update_contact_with_tag( $client, $config_data, $tag_id, $contact_id ){
        // TODO: No tag for Pabbly
    }

     /**
     * Check if Pabbly is activated or not
     *
     * @return int $id
     *
     * @since 1.3.2
     */
    public function deleteData($id)
    {
        // TODO: Implement deleteData() method.
    }

    /**
     * Check if Pabbly is activated or not
     *
     * @return bool
     * @since 1.3.2
     */
    function is_connected()
    {
       return true;
    }

    /**
     * Get Pabbly lists
     *
     * @return array
     * @since 1.3.2
     */
    public function get_crm_contact_lists(){
        return Wpfnl_Integartion_Pabbly_functions::get_lists();
    }

    /**
     * Get Pabbly tags
     *
     * @param array $list
     * @return array
     *
     * @since 1.3.2
     */
    public function get_crm_contact_tags( $list = [] ){
        return Wpfnl_Integartion_Pabbly_functions::get_tags();
    }

}
