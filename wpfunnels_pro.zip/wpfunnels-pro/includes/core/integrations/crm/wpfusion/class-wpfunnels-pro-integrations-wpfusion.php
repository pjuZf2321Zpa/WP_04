<?php
namespace WPFunnelsPro\Integrations;
use WPFunnels\Traits\SingletonTrait;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Integrations\CRM;
use WPFunnelsPro\Integartions\Wpfusion\Wpfnl_Integartion_Wpfusion_functions;


/**
 * integration class for Wpfusion
 *
 * Class Wpfusion
 */
class Wpfnl_Wpfusion extends CRM {

    use SingletonTrait;

    /**
     * Get CRM Name
     * 
     * @param null
     * @return string
     */
    public function get_name(){
        return 'WPFusion';
    }

    /**
     * Retrieve user information from db
     * 
     * @param order_id
     * @return array
     */
    public function get_user_info_from_order( $order_id = null, $user_info = [] ) {
        
        $user = [];
        $funnel_id = Wpfnl_functions::get_funnel_id_from_order( $order_id );
        
        if( $funnel_id ){
            $type = get_post_meta( $funnel_id, '_wpfnl_funnel_type', true );
           
            if( 'lms' === $type ){
                $user = $this->get_user_info_for_lms( $user_info );
            }elseif( 'wc' === $type ){
                $user = $this->get_user_info_for_woo( $order_id, $user_info );
            }elseif( 'lead' === $type ){
                $user = $this->get_user_info_for_lead( $user_info );
            }
        }else{
            $user = $this->get_user_info_for_woo( $order_id, $user_info );
        }
        $user['status']     = 'pending';

        return $user;
    }


    /**
     * Get user for woocommerce
     */
    private function get_user_info_for_woo( $order_id, $user_info=[] ){
        $user = [];
        if( $order_id ){
            $order              = wc_get_order( $order_id );
            if( $order ){
                $customer_id        = $order->get_customer_id();
                $user               = array();
    
                if( 0 != $customer_id ) {
                    $customer           = new \WC_Customer( $customer_id );
                    $user['email']      = $customer->get_email();
                    $user['first_name'] = $customer->get_first_name();
                    $user['last_name']  = $customer->get_last_name();
                } else {
                    $user['email']      = $order->get_billing_email();
                    $user['first_name'] = $order->get_billing_first_name();
                    $user['last_name']  = $order->get_billing_last_name();
                }
            }else{
                $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
                $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
                $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
            }
            
        }else{
            $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
            $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
            $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        }
        return $user;
    }


    /**
     * Get user for woocommerce
     */
    private function get_user_info_for_lms( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }


    /**
     * Get user for woocommerce
     * 
     * @param Array
     * @return Array
     */
    private function get_user_info_for_lead( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }

    

    /**
     * Sending data to Wpfusion to create or update contact, contact lists and tags
     * 
     * @param data
     * @return array
     */
    public function send_or_update_data( $data )
    {
        if( $data ){
            if( isset($data['email']) && $data['email'] && isset($data['tags']) && !empty($data['tags']) ){
                foreach( $data['tags'] as $key => $tag ){
                    try{
                        if( isset($data['email']) && Wpfnl_Integartion_Wpfusion_functions::maybe_wpfusion_installed() ){
                            $creds = get_option( '_wpfnl_addons_cred' );
                            if( $creds && isset($creds['wpfusion'],$creds['wpfusion']['status']) && 'active' === $creds['wpfusion']['status']  ){
                                $email     = $data['email'];
                                $firstName = isset($data['first_name']) ? $data['first_name'] : '';
                                $lastName  = isset($data['last_name']) ? $data['last_name'] : '';
                                $phone     = isset($data['phone']) ? $data['phone'] : '';

                                $contact_data = [
                                    'user_email'     => $email,
                                    'first_name'=> $firstName,
                                    'last_name' => $lastName,
                                    'phone'     => $phone,
                                ];
                                $contact_id = wp_fusion()->crm->add_contact( $contact_data, $map_meta_fields = true );
                                if( !is_wp_error( $contact_id ) && !method_exists(wp_fusion()->crm, 'apply_tags') ){
                                    wp_fusion()->crm->apply_tags( [$tag], $contact_id );
                                }
                            }
                        }
                    }catch (\Exception $e) {
                        error_log(print_r($e->getMessage(),1));
                    }
                }
            } 
        }
    }


    public function deleteData($id)
    {
        // TODO: Implement deleteData() method.
    }

    /**
     * check if Wpfusion is activated or not
     *
     * @return bool
     */
    function is_connected()
    {
       return true;
    }

    /**
     * Get wpfusion lists
     * 
     * @param null
     * @return array
     */
    public function get_crm_contact_lists(){
        return Wpfnl_Integartion_Wpfusion_functions::get_lists();
    }

    /**
     * Get wpfusion tags
     * 
     * @param null
     * @return array
     */
    public function get_crm_contact_tags( $list = [] ){
        return Wpfnl_Integartion_Wpfusion_functions::get_tags();
    }

}