<?php

namespace WPFunnelsPro\Integrations;

class Wpfunnels_Integrations_Ajax {

    /**
     * Validation rules for AJAX handlers.
     *
     * @var array
     */
    private $validations;

    /**
     *
	 * @since 1.0.0
	 */
	public function __construct()
	{
		$this->validations = [
			'logged_in' => true,
			'user_can' => 'wpf_manage_funnels',
		];
		wp_ajax_helper()->handle('wpfnl-update-addons-cred')
			->with_callback([$this, 'update_addons_cred'])
			->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-get-addons-cred')
			->with_callback([$this, 'get_addons_cred'])
			->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-update-crm-status')
                    ->with_callback([$this, 'update_crm_status'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-constant-contact-authentication')
                    ->with_callback([$this, 'wpfunnels_constant_contact_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-zoho-authentication')
                    ->with_callback([$this, 'wpfunnels_zoho_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-aweber-authentication')
                    ->with_callback([$this, 'wpfunnels_aweber_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-sendinblue-authentication')
                    ->with_callback([$this, 'sendinblue_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-mailerlite-authentication')
                    ->with_callback([$this, 'mailerlite_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-getresponse-authentication')
                    ->with_callback([$this, 'wpfunnels_getresponse_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-encharge-authentication')
                    ->with_callback([$this, 'wpfunnels_encharge_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-hubspot-authentication')
                    ->with_callback([$this, 'wpfunnels_hubspot_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-omnisend-authentication')
                    ->with_callback([$this, 'wpfunnels_omnisend_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-convertkit-authentication')
                    ->with_callback([$this, 'wpfunnels_convertkit_authentication'])
                    ->with_validation($this->validations);

        wp_ajax_helper()->handle('wpfnl-pabbly-authentication')
                    ->with_callback([$this, 'wpfunnels_pabbly_authentication'])
                    ->with_validation($this->validations);


		wp_ajax_helper()->handle('wpfnl-pabbly-email-authentication')
                    ->with_callback([$this, 'wpfunnels_pabbly_email_authentication'])
                    ->with_validation($this->validations);
                    
        wp_ajax_helper()->handle('wpfnl-drip-authentication')
                    ->with_callback([$this, 'wpfunnels_drip_authentication'])
                    ->with_validation($this->validations);
	}


    /**
     * Update addons credentials (Mailchimp / ActiveCampaign).
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::update_addons_cred().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function update_addons_cred( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->update_addons_cred( $payload );
    }

    /**
     * Get addons credentials from option table.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::get_addons_cred().
     *
     * @return array
     */
    public function get_addons_cred() {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->get_addons_cred();
    }

    /**
     * Update crm status.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::update_crm_status().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function update_crm_status( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->update_crm_status( $payload );
    }

    /**
     * Constant Contact authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_constant_contact_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_constant_contact_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_constant_contact_authentication( $payload );
    }

    /**
     * Zoho authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_zoho_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_zoho_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_zoho_authentication( $payload );
    }

    /**
     * Drip authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_drip_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_drip_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_drip_authentication( $payload );
    }

    /**
     * AWeber authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_aweber_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_aweber_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_aweber_authentication( $payload );
    }

    /**
     * GetResponse authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_getresponse_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_getresponse_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_getresponse_authentication( $payload );
    }

    /**
     * Encharge authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_encharge_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_encharge_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_encharge_authentication( $payload );
    }

    /**
     * Sendinblue authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::sendinblue_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function sendinblue_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->sendinblue_authentication( $payload );
    }

    /**
     * Mailerlite authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::mailerlite_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function mailerlite_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->mailerlite_authentication( $payload );
    }

    /**
     * Hubspot authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_hubspot_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_hubspot_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_hubspot_authentication( $payload );
    }

    /**
     * Omnisend authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_omnisend_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_omnisend_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_omnisend_authentication( $payload );
    }

    /**
     * ConvertKit authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_convertkit_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_convertkit_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_convertkit_authentication( $payload );
    }

    /**
     * Pabbly authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_pabbly_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_pabbly_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_pabbly_authentication( $payload );
    }

    /**
     * Pabbly Email authentication.
     *
     * Delegates to Wpfnl_Pro_CRM_Credentials_Service::wpfunnels_pabbly_email_authentication().
     *
     * @param array $payload AJAX payload.
     * @return array
     */
    public function wpfunnels_pabbly_email_authentication( $payload ) {
        return Wpfnl_Pro_CRM_Credentials_Service::instance()->wpfunnels_pabbly_email_authentication( $payload );
    }


    /**
     * Get integration credentials data from database.
     *
     * Kept for backward compatibility; delegates to the credentials service.
     *
     * @param string $integration Integration key.
     * @return false|mixed|void
     */
    public static function get_integration_credentials( string $integration = '' ) {
        return Wpfnl_Pro_CRM_Credentials_Service::get_integration_credentials( $integration );
    }
}
