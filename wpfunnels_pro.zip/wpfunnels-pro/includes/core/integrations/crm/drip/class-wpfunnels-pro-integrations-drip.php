<?php
/**
 * Drip functions
 * 
 * @since 1.4.0
 */

namespace WPFunnelsPro\Integrations;
use WPFunnels\Traits\SingletonTrait;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Integrations\CRM;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use GuzzleHttp\Exception\GuzzleException;
use WPFunnelsPro\Integartions\Drip\Wpfnl_Integartion_Drip_functions;


/**
 * Integration class for Drip
 *
 * Class Wpfnl_Drip
 * 
 * @package WPFunnelsPro\Integrations
 * 
 * @since 1.4.0
 */
class Wpfnl_Drip extends CRM {

    use SingletonTrait;

    /**
     * Get CRM Name
     * 
     * @param null
     * @return string
     * 
     * @since 1.4.0
     */
    public function get_name(){
        return 'Drip';
    }

    /**
     * Retrieve user information from db
     * 
     * @param order_id
     * @return array
     * 
     * @since 1.4.0
     */
    public function get_user_info_from_order( $order_id = null, $user_info = [] ) {
        
        $user = [];
        $funnel_id = Wpfnl_functions::get_funnel_id_from_order( $order_id );
        
        if( $funnel_id ){
            $type = get_post_meta( $funnel_id, '_wpfnl_funnel_type', true );
           
            if( 'lms' === $type ){
                $user = $this->get_user_info_for_lms( $user_info );
            }elseif( 'wc' === $type ){
                $user = $this->get_user_info_for_woo( $order_id, $user_info);
            }elseif( 'lead' === $type ){
                $user = $this->get_user_info_for_lead( $user_info );
            }
        }else{
            $user = $this->get_user_info_for_woo( $order_id, $user_info );
        }
        $user['status']     = 'pending';

        return $user;
    }


    /**
     * Get user for woocommerce
     * 
     * @param order_id
     * @param user_info
     * @return array
     * 
     * @since 1.4.0
     */
    private function get_user_info_for_woo( $order_id, $user_info = [] ){
        $user = [];
        if( $order_id ){
            $order              = wc_get_order( $order_id );
            if( $order ){
                $customer_id        = $order->get_customer_id();
                $user               = array();
    
                if( 0 != $customer_id ) {
                    $customer           = new \WC_Customer( $customer_id );
                    $user['email']      = $customer->get_email();
                    $user['first_name'] = $customer->get_first_name();
                    $user['last_name']  = $customer->get_last_name();
                    $user['phone']      = get_user_meta( $customer_id, 'billing_phone', true ) ? get_user_meta( $customer_id, 'billing_phone', true ) : '';
                } else {
                    $user['email']      = $order->get_billing_email();
                    $user['first_name'] = $order->get_billing_first_name();
                    $user['last_name']  = $order->get_billing_last_name();
                    $user['phone']      = $order->get_billing_phone() ? $order->get_billing_phone() : '';
                }
            }else{
                $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
                $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
                $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
            }

        }else{
            $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
            $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
            $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        }
        return $user;
    }


    /**
     * Get user for woocommerce
     * 
     * @param Array
     * 
     * @return Array
     * 
     * @since 1.4.0
     */
    private function get_user_info_for_lms( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }


    /**
     * Get user for woocommerce
     * 
     * @param Array
     * @return Array
     * 
     * @since 1.4.0
     */
    private function get_user_info_for_lead( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }


    /**
     * Sending data to zoho to create or update contact, contact lists and tags
     * 
     * @param data
     * @return array
     * 
     * @since 1.4.0
     */
    public function send_or_update_data( $data )
    {
        if( $data ){
            if( isset($data['lists']) && !empty($data['lists']) && isset($data['email']) && $data['email'] ){
                foreach( $data['lists'] as $key => $list ){
                    try{
                        $firstName         = isset($data['first_name']) ? $data['first_name'] : '';
                        $lastName          = isset($data['last_name']) ? $data['last_name'] : '';
                        $phone          = isset($data['phone']) ? $data['phone'] : '';

                        $formatted_data = [
                            "subscribers" => [
                                [
                                    "email" => $data['email'],
                                    "first_name" => $firstName,
                                    "last_name" => $lastName,
                                    "phone" => $phone,
                                ]
                            ]
                        ];

                        $client = new \GuzzleHttp\Client();
                        $url = Wpfnl_Integartion_Drip_functions::get_drip_authorization_url();
                        $encodedCredentials = Wpfnl_Integartion_Drip_functions::get_drip_authorization_basic_auth();
                        $response = $client->request('POST', "{$url}/{$list}/subscribers", [
                            'headers' => [
                                'Accept'        => 'application/json',
                                'Authorization'     => "Basic {$encodedCredentials}",

                            ],
                            'json' => $formatted_data
                        ]);
                        
                        $tag = isset($data['tags'][0]) ? $data['tags'][0] : '';
                        if( $tag ){
                            // Tag data
                            $tag_data = [
                                "tags" => [
                                    [
                                        "email" => $data['email'],
                                        "tag" => $tag
                                    ]
                                ]
                            ];

                            // Apply tag to subscriber
                            $client->request('POST', "{$url}/{$list}/tags", [
                                'headers' => [
                                    'Accept'        => 'application/json',
                                    'Authorization' => "Basic {$encodedCredentials}",
                                ],
                                'json' => $tag_data
                            ]);
                        }
                    }catch( \Exception $e ){

                        return [];
                    }
                   
                }
            } 
        }
    }

    /**
     * Delete data
     * 
     * @param data
     * @return array
     * 
     * @since 1.4.0
     */
    public function deleteData($id)
    {
        // TODO: Implement deleteData() method.
    }

    /**
     * Check if Drip is activated or not
     *
     * @return bool
     * 
     * @since 1.4.0
     * 
     */
    public function is_connected()
    {
       return Wpfnl_Integartion_Drip_functions::maybe_drip_enable();
    }

    /**
     * Get Drip lists
     * 
     * @return array
     * 
     * @since 1.4.0
     */
    public function get_crm_contact_lists(){
        return Wpfnl_Integartion_Drip_functions::get_lists();
    }

    /**
     * Get Drip tags
     * 
     * @param array tags
     * @return array
     * 
     * @since 1.4.0
     */
    public function get_crm_contact_tags( $tags = [] ){
        return Wpfnl_Integartion_Drip_functions::get_drip_tags();
    }

}