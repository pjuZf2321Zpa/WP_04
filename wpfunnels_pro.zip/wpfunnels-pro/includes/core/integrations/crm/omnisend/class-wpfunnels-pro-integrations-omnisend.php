<?php
namespace WPFunnelsPro\Integrations;
use WPFunnels\Traits\SingletonTrait;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Integrations\CRM;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Omnisend\Wpfnl_Integartion_Omnisend_functions;


/**
 * integration class for mailchimp
 *
 * Class MailChimp
 */
class Wpfnl_Omnisend extends CRM {

    use SingletonTrait;

    /**
     * Get CRM Name
     * 
     * @return string
     * 
     * @since 1.2.0
     */
    public function get_name(){
        return 'Omnisend';
    }

    /**
     * Get user information from an order.
     *
     * @param int|null $order_id    Order ID (optional).
     * @param array    $user_info   Additional user information (optional).
     *
     * @return array User information array 
     * 
     * @since 1.2.0
     */
    public function get_user_info_from_order( $order_id = null, $user_info = [] ) {
        
        $user = [];
        $funnel_id = Wpfnl_functions::get_funnel_id_from_order( $order_id );
        
        if( $funnel_id ){
            $type = get_post_meta( $funnel_id, '_wpfnl_funnel_type', true );
           
            if( 'lms' === $type ){
                $user = $this->get_user_info_for_lms( $user_info );
            }elseif( 'wc' === $type ){
                $user = $this->get_user_info_for_woo( $order_id, $user_info);
            }elseif( 'lead' === $type ){
                $user = $this->get_user_info_for_lead( $user_info );
            }
        }else{
            $user = $this->get_user_info_for_woo( $order_id, $user_info );
        }
        $user['status']     = 'pending';

        return $user;
    }


    /**
     * Get user information for WooCommerce order.
     *
     * @param int   $order_id   WooCommerce order ID.
     * @param array $user_info  Additional user information (optional).
     *
     * @return array User information array 
     * 
     * @since 1.2.0
     */
    private function get_user_info_for_woo( $order_id, $user_info = [] ){
        $user = [];
        if( $order_id ){
            $order              = wc_get_order( $order_id );
            if( $order ){
                $customer_id        = $order->get_customer_id();
                $user               = array();
    
                if( 0 != $customer_id ) {
                    $customer           = new \WC_Customer( $customer_id );
                    $user['email']      = $customer->get_email();
                    $user['first_name'] = $customer->get_first_name();
                    $user['last_name']  = $customer->get_last_name();
                    $user['phone']      = get_user_meta( $customer_id, 'billing_phone', true ) ? get_user_meta( $customer_id, 'billing_phone', true ) : '';
                } else {
                    $user['email']      = $order->get_billing_email();
                    $user['first_name'] = $order->get_billing_first_name();
                    $user['last_name']  = $order->get_billing_last_name();
                    $user['phone']      = $order->get_billing_phone() ? $order->get_billing_phone() : '';
                }
            }else{
                $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
                $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
                $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
            }

        }else{
            $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
            $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
            $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        }
        return $user;
    }


    /**
     * Get user information for LMS.
     *
     * @param array $user_info User information array (optional).
     *
     * @return array User information array 
     * 
     * @return 1.2.0
     */
    private function get_user_info_for_lms( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }


    /**
     * Get user information for lead.
     *
     * @param array $user_info User information array (optional).
     *
     * @return array User information array 
     * @since 1.2.0
     */
    private function get_user_info_for_lead( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }

    /**
     * Send or update data to HubSpot.
     *
     * @since 1.2.0
     *
     * @param array $data The data to send or update.
     *
     * @return void|bool
     */
    public function send_or_update_data( $data )
    {
        if ( !$data ){
            return false;
        }
        if( isset($data['tags']) && !empty($data['tags']) && isset($data['email']) && $data['email'] ){
            foreach( $data['tags'] as $key => $tag ){
                try{
                    if( isset($data['email'])){
                        $url = Wpfnl_Integartion_Omnisend_functions::omnisend_authentication_url();
                        $creds = get_option( '_wpfnl_addons_cred' );
                        if( $creds && isset($creds['omnisend'],$creds['omnisend']['omnisend_status'],$creds['omnisend']['omnisend_api'],$creds['omnisend']['status']) && 'active' === $creds['omnisend']['omnisend_status'] && 'active' === $creds['omnisend']['status']  ){
                            $email     = $data['email'];
                            $firstName = isset($data['first_name']) ? $data['first_name'] : '';
                            $lastName  = isset($data['last_name']) ? $data['last_name'] : '';
                            $phone     = isset($data['phone']) ? $data['phone'] : '';

                            $formatted_data = array(
                                "createdAt" => gmdate('Y-m-d\TH:i:s\Z'),
                                "firstName" => $firstName,
                                "lastName" => $lastName,
                                "tags" => [$tag],
                                "identifiers" => [
                                    [
                                        "type"=> "email",
                                        "id" => $email,
                                        "channels" => [
                                            "email" => [
                                                "status" => "subscribed",
                                                "statusDate" => gmdate('Y-m-d\TH:i:s\Z')
                                            ]
                                        ]
                                    ]
                                    
                                ]
                            );

                            if( $phone ){
                                $formatted_data['identifiers'][] = [
                                            "type"=> "phone",
                                            "id" => $phone,
                                            "channels" => [
                                                "sms" => [
                                                    "status" => "nonSubscribed",
                                                    "statusDate" => gmdate('Y-m-d\TH:i:s\Z')
                                                ]
                                            ]
                                        ];
                            }
                         
                            $json_body_data = json_encode($formatted_data);
                            $client = new \GuzzleHttp\Client();
                            
                            $response = $client->request('POST', $url."contacts", [
                                'body' => $json_body_data,
                                'headers' => [
                                    'X-API-KEY' => Wpfunnels_Aes_Ctr::decrypt( $creds['omnisend']['omnisend_api'], WPFNL_SECURITY_KEY, 256 ),
                                    'accept' => 'application/json',
                                    'content-type' => 'application/json',
                                ],
                            ]);
                            $status_code = $response->getStatusCode();
                        }
                    }
                }catch (\Exception $e) {
                    error_log(print_r($e->getMessage(),1));
                }
            }
        } 
    }


    /**
     * Update contact with a specific list.
     *
     * @param Client $client The GuzzleHttp client.
     * @param array  $config_data Configuration data for the contact update.
     * @param int    $list_id The ID of the list to associate the contact with.
     * @param int    $contact_id The ID of the contact to update.
     *
     * @return void
     * @since 1.2.0
     */
    public function update_contact_with_list( $client, $config_data, $list_id , $contacts_id ){
        // TODO: Update list with contact
    }


    /**
     * Update contact with tags
     * 
     * @param Client $client The GuzzleHttp client.
     * @param array  $config_data Configuration data for the contact update.
     * @param int    $list_id The ID of the list to associate the contact with.
     * @param int    $contact_id The ID of the contact to update.
     * 
     * @return void
     * 
     * @since 1.2.0
     */
    private function update_contact_with_tag( $client, $config_data, $tag_id, $contact_id ){
        // TODO: No tag for omnisend
    }

     /**
     * Check if omnisend is activated or not
     *
     * @return int $id 
     * 
     * @since 1.2.0
     */
    public function deleteData($id)
    {
        // TODO: Implement deleteData() method.
    }

    /**
     * Check if omnisend is activated or not
     *
     * @return bool
     * @since 1.2.0
     */
    function is_connected()
    {
       return true;
    }

    /**
     * Get Omnisend lists
     * 
     * @return array
     * @since 1.2.0
     */
    public function get_crm_contact_lists(){
        return Wpfnl_Integartion_Omnisend_functions::get_lists();
    }

    /**
     * Get Omnisend tags
     * 
     * @param array $list
     * @return array
     * 
     * @since 1.2.0
     */
    public function get_crm_contact_tags( $tags = [] ){
        return Wpfnl_Integartion_Omnisend_functions::get_tags();
    }

}