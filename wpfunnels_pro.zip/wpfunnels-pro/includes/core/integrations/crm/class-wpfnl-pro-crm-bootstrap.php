<?php

namespace WPFunnelsPro\Integrations\CRM;

use WPFunnelsPro\Wpfnl_Pro_Plan;
use WPFunnelsPro\Integrations\Wpfunnels_Integrations_Ajax;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CRM Bootstrap — loaded by Wpfnl_Pro::init() when the current license
 * grants access to integrations (Growth / Business plan or legacy addon key).
 *
 * Responsibilities:
 *  - Instantiate CrmIntegrations (the scheduler / automation manager).
 *  - Register the AJAX handler class.
 *  - Enqueue integration-specific admin assets.
 *  - Register the admin page renderer action used by the free-core menu.
 *  - Feed the React Integrations page (react-ready handshake + provider schema).
 *
 * @since 2.9.0
 * @package WPFunnelsPro\Integrations\CRM
 */
class CRM_Integrations {

    /**
     * Set up all hooks.
     *
     * The render action and admin assets are always registered so users on any
     * plan see either the integrations UI or the upgrade prompt.
     * CrmIntegrations (Action Scheduler, cookie tracking) and AJAX handlers are
     * only activated when the license actually grants integration access.
     */
    public function __construct() {
        // Always register the page renderer so the menu page loads.
        add_action( 'wpfunnels/render_integrations_page', [ $this, 'render_page' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

        // Always register the CRM list filter so REST API calls return connected CRMs.
        add_filter( 'wpfunnels/supported_crm_integrations', [ $this, 'update_supported_crm' ] );

        if ( ! Wpfnl_Pro_Plan::is_integration_license_active() ) {
            return;
        }

        // Boot the CRM manager (Action Scheduler callbacks, cookie handler, etc.)
        CrmIntegrations::getInstance();

        // AJAX handlers
        new Wpfunnels_Integrations_Ajax();

        // React Integrations page (free plugin, ?page=wpfunnels#/integrations).
        // Declaring readiness tells the free plugin this Pro build serves the
        // wpfunnels/v1/integrations/* REST routes, so it may route to React.
        add_filter( 'wpfunnels/integrations_react_ready', '__return_true' );
        add_filter( 'wpfunnels/integrations_page_data', [ new CRM_Integrations_Page_Data(), 'filter_page_data' ] );
    }


    /**
     * Add all migrated CRM integrations to the supported list.
     *
     * Each entry's class_name maps to a class in the WPFunnelsPro\Integrations namespace.
     * Only integrations that have been configured (credentials saved) are added.
     *
     * @param array $crm Existing supported CRM array.
     * @return array
     */
    public function update_supported_crm( array $crm ): array {
        $ns = 'WPFunnelsPro\\Integartions\\';

        if ( ! isset( $crm['mailchimp'] ) && ( $ns . 'Mailchimp\\Wpfnl_Integartion_Mailchimp_functions' )::maybe_mailchimp_enable() ) {
            $crm['mailchimp'] = [ 'class_name' => 'Wpfnl_MailChimp' ];
        }

        if ( ! isset( $crm['mailpoet'] ) && is_plugin_active( 'mailpoet/mailpoet.php' ) && ( $ns . 'Mailpoet\\Wpfnl_Integartion_Mailpoet_functions' )::maybe_mailpoet_enable() ) {
            $crm['mailpoet'] = [ 'class_name' => 'Wpfnl_Mailpoet' ];
        }

        if ( ! isset( $crm['activecampaign'] ) && ( $ns . 'ActiveCampaign\\Wpfnl_Integartion_ActiveCampaign_functions' )::maybe_active_campaign_enable() ) {
            $crm['activecampaign'] = [ 'class_name' => 'Wpfnl_ActiveCampaign' ];
        }

        if ( ! isset( $crm['constantcontact'] ) && ( $ns . 'ConstantContact\\Wpfnl_Integartion_ConstantContact_functions' )::maybe_constant_contact_enable() ) {
            $crm['constantcontact'] = [ 'class_name' => 'Wpfnl_ConstantContact' ];
        }

        if ( ! isset( $crm['aweber'] ) && ( $ns . 'Aweber\\Wpfnl_Integartion_Aweber_functions' )::maybe_aweber_enable() ) {
            $crm['aweber'] = [ 'class_name' => 'Wpfnl_Aweber' ];
        }

        if ( ! isset( $crm['zapier'] ) && ( $ns . 'Zapier\\Wpfnl_Integartion_Zapier_functions' )::maybe_zapier_enable() ) {
            $crm['zapier'] = [ 'class_name' => 'Zapier' ];
        }

        if ( ! isset( $crm['sendinblue'] ) && ( $ns . 'SendInBlue\\Wpfnl_Integartion_SendInBlue_functions' )::maybe_sendinblue_enable() ) {
            $crm['sendinblue'] = [ 'class_name' => 'Wpfnl_SendInBlue' ];
        }

        if ( ! isset( $crm['mailerlite'] ) && ( $ns . 'Mailerlite\\Wpfnl_Integartion_Mailerlite_functions' )::maybe_mailerlite_enable() ) {
            $crm['mailerlite'] = [ 'class_name' => 'Wpfnl_Mailerlite' ];
        }

        if ( ! isset( $crm['getresponse'] ) && ( $ns . 'GetResponse\\Wpfnl_Integartion_GetResponse_functions' )::maybe_getresponse_enable() ) {
            $crm['getresponse'] = [ 'class_name' => 'Wpfnl_GetResponse' ];
        }

        if ( ! isset( $crm['encharge'] ) && ( $ns . 'Encharge\\Wpfnl_Integartion_Encharge_functions' )::maybe_encharge_enable() ) {
            $crm['encharge'] = [ 'class_name' => 'Wpfnl_Encharge' ];
        }

        if ( ! isset( $crm['hubspot'] ) && ( $ns . 'Hubspot\\Wpfnl_Integartion_Hubspot_functions' )::maybe_hubspot_enable() ) {
            $crm['hubspot'] = [ 'class_name' => 'Wpfnl_Hubspot' ];
        }

        if ( ! isset( $crm['convertkit'] ) && ( $ns . 'Convertkit\\Wpfnl_Integartion_Convertkit_functions' )::maybe_convertkit_enable() ) {
            $crm['convertkit'] = [ 'class_name' => 'Wpfnl_Convertkit' ];
        }

        if ( ! isset( $crm['pabbly'] ) && ( $ns . 'Pabbly\\Wpfnl_Integartion_Pabbly_functions' )::maybe_pabbly_enable() ) {
            $crm['pabbly'] = [ 'class_name' => 'Wpfnl_Pabbly' ];
        }

        if ( ! isset( $crm['pabbly_email'] ) && ( $ns . 'Pabbly\\Wpfnl_Integartion_Pabbly_Email_functions' )::maybe_pabbly_email_enable() ) {
            $crm['pabbly_email'] = [ 'class_name' => 'Wpfnl_Pabbly_Email' ];
        }

        if ( ! isset( $crm['wpfusion'] ) && ( $ns . 'Wpfusion\\Wpfnl_Integartion_Wpfusion_functions' )::maybe_wpfusion_enable() ) {
            $crm['wpfusion'] = [ 'class_name' => 'Wpfnl_Wpfusion' ];
        }

        if ( ! isset( $crm['zoho'] ) && ( $ns . 'Zoho\\Wpfnl_Integartion_Zoho_functions' )::maybe_zoho_enable() ) {
            $crm['zoho'] = [ 'class_name' => 'Wpfnl_Zoho' ];
        }

        if ( ! isset( $crm['omnisend'] ) && ( $ns . 'Omnisend\\Wpfnl_Integartion_Omnisend_functions' )::maybe_omnisend_enable() ) {
            $crm['omnisend'] = [ 'class_name' => 'Wpfnl_Omnisend' ];
        }

        if ( ! isset( $crm['drip'] ) && ( $ns . 'Drip\\Wpfnl_Integartion_Drip_functions' )::maybe_drip_enable() ) {
            $crm['drip'] = [ 'class_name' => 'Wpfnl_Drip' ];
        }

        return $crm;
    }


    /**
     * Enqueue integration CSS / JS on WPFunnels admin pages.
     *
     * @param string $hook Current admin page hook.
     */
    public function enqueue_assets( string $hook ) {
        $wpfnl_hooks = [
            'toplevel_page_wp_funnels',
            'wpfunnels_page_wpfunnels_integrations',
            'wp-funnels_page_wpfunnels_integrations',
        ];

        if ( ! in_array( $hook, $wpfnl_hooks, true ) ) {
            return;
        }

        wp_enqueue_style(
            'wpfnl-pro-crm-integrations',
            WPFNL_PRO_DIR_URL . 'admin/assets/css/wpfnl-pro-crm-integrations.css',
            [],
            WPFNL_PRO_VERSION
        );

        wp_enqueue_script(
            'wpfnl-pro-crm-integrations',
            WPFNL_PRO_DIR_URL . 'admin/assets/js/wpfnl-pro-crm-integrations.js',
            [ 'jquery' ],
            WPFNL_PRO_VERSION,
            true
        );

        wp_localize_script( 'wpfnl-pro-crm-integrations', 'WPFnlCRMVars', [
            'ajaxurl'      => admin_url( 'admin-ajax.php' ),
            'admin_nonce'  => wp_create_nonce( 'wpfnl-admin' ),
        ] );
    }


    /**
     * Render the integrations admin page.
     * Called via the wpfunnels/render_integrations_page action.
     */
    public function render_page() {
        if ( ! Wpfnl_Pro_Plan::is_integration_license_active() ) {
            require WPFNL_DIR . 'admin/modules/integration/view.php';
            return;
        }
        require WPFNL_PRO_DIR . 'admin/partials/integrations/wpfnl-pro-integrations-view.php';
    }
}
