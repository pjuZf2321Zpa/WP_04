<?php
namespace WPFunnelsPro\Integrations;
use WPFunnels\Traits\SingletonTrait;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Integrations\CRM;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use GuzzleHttp\Exception\GuzzleException;
use WPFunnelsPro\Integartions\Zoho\Wpfnl_Integartion_Zoho_functions;


/**
 * integration class for mailchimp
 *
 * Class MailChimp
 */
class Wpfnl_Zoho extends CRM {

    use SingletonTrait;

    /**
     * Get CRM Name
     * 
     * @param null
     * @return string
     */
    public function get_name(){
        return 'Zoho';
    }

    /**
     * Retrieve user information from db
     * 
     * @param order_id
     * @return array
     */
    public function get_user_info_from_order( $order_id = null, $user_info = [] ) {
        
        $user = [];
        $funnel_id = Wpfnl_functions::get_funnel_id_from_order( $order_id );
        
        if( $funnel_id ){
            $type = get_post_meta( $funnel_id, '_wpfnl_funnel_type', true );
           
            if( 'lms' === $type ){
                $user = $this->get_user_info_for_lms( $user_info );
            }elseif( 'wc' === $type ){
                $user = $this->get_user_info_for_woo( $order_id, $user_info);
            }elseif( 'lead' === $type ){
                $user = $this->get_user_info_for_lead( $user_info );
            }
        }else{
            $user = $this->get_user_info_for_woo( $order_id, $user_info );
        }
        $user['status']     = 'pending';

        return $user;
    }


    /**
     * Get user for woocommerce
     */
    private function get_user_info_for_woo( $order_id, $user_info = [] ){
        $user = [];
        if( $order_id ){
            $order              = wc_get_order( $order_id );
            if( $order ){
                $customer_id        = $order->get_customer_id();
                $user               = array();
    
                if( 0 != $customer_id ) {
                    $customer           = new \WC_Customer( $customer_id );
                    $user['email']      = $customer->get_email();
                    $user['first_name'] = $customer->get_first_name();
                    $user['last_name']  = $customer->get_last_name();
                    $user['phone']      = get_user_meta( $customer_id, 'billing_phone', true ) ? get_user_meta( $customer_id, 'billing_phone', true ) : '';
                } else {
                    $user['email']      = $order->get_billing_email();
                    $user['first_name'] = $order->get_billing_first_name();
                    $user['last_name']  = $order->get_billing_last_name();
                    $user['phone']      = $order->get_billing_phone() ? $order->get_billing_phone() : '';
                }
            }else{
                $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
                $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
                $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
            }

        }else{
            $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
            $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
            $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        }
        return $user;
    }


    /**
     * Get user for woocommerce
     */
    private function get_user_info_for_lms( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }


    /**
     * Get user for woocommerce
     * 
     * @param Array
     * @return Array
     */
    private function get_user_info_for_lead( $user_info ){

        $user = [];
        $user['email']       = isset($user_info['email']) ? $user_info['email'] : '';
        $user['first_name']  = isset($user_info['first_name']) ? $user_info['first_name'] : '';
        $user['last_name']   = isset($user_info['last_name']) ? $user_info['last_name'] : '';
        return $user;
        
    }


    /**
     * Sending data to zoho to create or update contact, contact lists and tags
     * 
     * @param data
     * @return array
     */
    public function send_or_update_data( $data )
    {
        if( $data ){
            if( isset($data['lists']) && !empty($data['lists']) && isset($data['email']) && $data['email'] ){
                foreach( $data['lists'] as $key => $list ){
                    try{
                        $creds = get_option( '_wpfnl_addons_cred' );
                        $token = '';

                        if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) && isset($creds['zoho']['zoho_refresh_token']) ){
                            Wpfnl_Integartion_Zoho_functions::get_token_by_refresh_token();
                            $creds = get_option( '_wpfnl_addons_cred' );
                            $token = $creds['zoho']['zoho_token'];
                        }else{
                            Wpfnl_Integartion_Zoho_functions::get_access_token();
                            $creds = get_option( '_wpfnl_addons_cred' );
                            if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) ){
                                $token = $creds['zoho']['zoho_token'];
                            }
                        }
                        
                        if( $token ){
                           
                            $client = new \GuzzleHttp\Client();

                            $response = $client->request('GET', "https://www.zohoapis.com/crm/v6/Contacts?fields=Email&per_page=200", [
                                'headers' => [
                                    'Content-Type'      => 'application/json',
                                    'Authorization'     => 'Zoho-oauthtoken '.$token,
                                ],
                            ]);
                           
                            if( 200 == $response->getStatusCode() ){
                                $result = json_decode($response->getBody()->getContents());
                               
                                if( isset($result->data) && is_array($result->data) ){
                                    $maybe_exist = false;
                                    foreach( $result->data as $contact ){
                                        if( $contact->Email === $data['email'] ){
                                            $maybe_exist = true;
                                            
                                            $contact_id = $contact->id;
                                            $formatted_data = [
                                                'Email'         => isset($data['email']) ? $data['email'] : '',
                                                'Phone'         => isset($data['phone']) ? $data['phone'] : '',
                                                'First_Name'    => isset($data['first_name']) ? $data['first_name'] : '',
                                                'Last_Name'    => isset($data['last_name']) ? $data['last_name'] : '',
                                                'Owner'          => [
                                                    'id' => $list
                                                ],
                                            ];
                                            
                                            $json_body_data = json_encode(['data' => [$formatted_data]]);
                                            $response = $client->request('PUT', "https://www.zohoapis.com/crm/v6/Contacts/".$contact_id, [
                                                'headers' => [
                                                    'Content-Type'      => 'application/json',
                                                    'Authorization'     => 'Zoho-oauthtoken '.$token,
                                                ],
                                                'body'    => $json_body_data,
                                            ]);

                                            $config_data = [
                                                'url' => 'https://www.zohoapis.com/crm/v3/Contacts/actions/add_tags',
                                                'token' => $token
                                            ];
                                            $tag_id = isset($data['tags'][0]) ? $data['tags'][0] : '';
                                            $this->update_contact_with_tag( $client, $config_data, $tag_id , $key, $contact_id );
                                            break;
                                        }                       
                                    }
                                    
                                    if( !$maybe_exist ){
                                        $formatted_data =[];
                                        $formatted_data = [
                                            'Email'         => isset($data['email']) ? $data['email'] : '',
                                            'Phone'         => isset($data['phone']) ? $data['phone'] : '',
                                            'First_Name'    => isset($data['first_name']) ? $data['first_name'] : '',
                                            'Last_Name'    => isset($data['last_name']) ? $data['last_name'] : '',
                                            'Owner'       =>  [
                                                'id' => $list
                                            ],
                                           
                                        ];
                                        $json_body_data = json_encode(['data' => [$formatted_data]]);
                                        
                                        $response = $client->request('POST', "https://www.zohoapis.com/crm/v6/Contacts", [
                                            'body'    => $json_body_data,
                                            'headers' => [
                                                'Accept'        => 'application/json',
                                                'Content-Type'  => 'application/json',
                                                'Authorization' => 'Zoho-oauthtoken '.$token,
                                            ],
                                        ]);
                                        
                                        if( 201 == $response->getStatusCode() ){
                                            $result = json_decode($response->getBody()->getContents());
                                           
                                            $config_data = [
                                                'url' => 'https://www.zohoapis.com/crm/v3/Contacts/actions/add_tags',
                                                'token' => $token
                                            ];
                                            $tag_id = isset($data['tags'][0]) ? $data['tags'][0] : '';
                                            $this->update_contact_with_tag( $client, $config_data, $tag_id ,$key, $result->data[0]->details->id );
                                        }
                                    }
                                }
                            }

                        }

                    }catch( \Exception $e ){
                        error_log(print_r($e,1));
                        return [];
                    }
                   
                }
            } 
        }
    }


    /**
     * Update contact with list
     * 
     * @since 
     */
    public function update_contact_with_tag( $client, $config_data, $tag_id , $tag_name, $contacts_id ){

        $formatted_tag_data = [
            "id" => $tag_id,
        ];
        
        $json_body_tag_data = json_encode(['tags' => [$formatted_tag_data]]);
        $update_list_response = $client->request('POST', "{$config_data['url']}?ids={$contacts_id}", [
            'body'    => $json_body_tag_data,
            'headers' => [
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Zoho-oauthtoken '.$config_data['token'],
                
            ],
        ]);
    }



    public function deleteData($id)
    {
        // TODO: Implement deleteData() method.
    }

    /**
     * check if mailchimp is activated or not
     *
     * @return bool
     */
    function is_connected()
    {
       return true;
    }

    /**
     * Get Mailchimp lists
     * 
     * @return array
     */
    public function get_crm_contact_lists(){
        return Wpfnl_Integartion_Zoho_functions::get_lists();
    }

    /**
     * Get Mailchimp tags
     * 
     * @param null
     * @return array
     */
    public function get_crm_contact_tags( $list = [] ){
        return Wpfnl_Integartion_Zoho_functions::get_tags();
    }

}