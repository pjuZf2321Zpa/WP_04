<?php
/**
 * AI Template Builder for WPFunnels.
 *
 * Sole remaining consumer: StepContentRegenerateController's "Regenerate with
 * AI" panel for a single existing step. The chat-driven "Create Funnel with
 * AI" flow now runs on the AgentLoop/Copilot system (core wpfunnels), which
 * builds pages by importing real templates instead of generating from
 * scratch — this class intentionally does not participate in that flow.
 *
 * Builds a complete page layout from scratch for a given step type and builder,
 * writing builder-native data directly to post meta / post content.
 *
 * No external template import required — every layout element is generated
 * programmatically using:
 *  - Real AI copy for all text (headline, subheadline, CTA, bullets, etc.)
 *  - Placeholder images via placehold.co
 *  - Dedicated WPFunnels widgets for each step type:
 *      Landing   → wpfnl-next-step   / wpfnl_next_step    / wpfnl_next_step_button
 *      Checkout  → wpfnl-checkout    / wpfnl_checkout      / wpfnl_checkout
 *      Upsell /
 *      Downsell  → wpfnl-offer       / wpfnl_offer_button  / wpfnl_offer_button
 *      Thank you → wpfnl-order-detail/ wpfnl_order_deatils / wpfnl_order_details
 *
 * @package WPFunnelsPro\AI
 */

namespace WPFunnelsPro\AI;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Wpfnl_AI_Template_Builder
 */
class Wpfnl_AI_Template_Builder {

	// ── Constants ─────────────────────────────────────────────────────────────

	/** Base URL for placeholder images. */
	const PLACEHOLDER_BASE = 'https://placehold.co';

	/** Brand purple used as placeholder image background colour. */
	const BRAND_COLOR = '6E42D3';

	// ── Public API ────────────────────────────────────────────────────────────

	/**
	 * Build and persist a complete page layout from scratch for the given step.
	 *
	 * @param int        $step_id      WP post ID of the step.
	 * @param string     $step_type    landing|checkout|upsell|downsell|thankyou
	 * @param string     $builder      elementor|bricks|divi-builder|gutenberg
	 * @param array      $copy         AI-generated copy keyed by copy-field name.
	 * @param array|null $product_data Optional product data from load_step_product().
	 *                                 Keys: id, name, price_raw, description, image_url.
	 */
	public static function build( $step_id, $step_type, $builder, array $copy, $product_data = null ) {
		switch ( $builder ) {
			case 'elementor':
				self::build_elementor( $step_id, $step_type, $copy, $product_data );
				break;
			case 'bricks':
				self::build_bricks( $step_id, $step_type, $copy, $product_data );
				break;
			case 'divi-builder':
				self::build_divi( $step_id, $step_type, $copy, $product_data );
				break;
			default:
				self::build_gutenberg( $step_id, $step_type, $copy, $product_data );
				break;
		}

		// Store raw copy in meta so themes / shortcodes can access it.
		update_post_meta( $step_id, '_wpfnl_ai_copy', $copy );
	}

	// ── Shared helpers ────────────────────────────────────────────────────────

	/**
	 * Return the best available image URL for a product.
	 *
	 * Uses the real product image if $product_data contains a non-empty image_url;
	 * otherwise falls back to a branded placeholder at placehold.co.
	 *
	 * @param array|null $product_data Product data array (may be null).
	 * @param string     $label        Fallback label for the placeholder image.
	 * @param int        $w            Placeholder width in pixels.
	 * @param int        $h            Placeholder height in pixels.
	 * @return string
	 */
	private static function product_image( $product_data, $label = 'Product Image', $w = 800, $h = 400 ) {
		if ( ! empty( $product_data['image_url'] ) ) {
			return esc_url( $product_data['image_url'] );
		}
		return self::placeholder( $label, $w, $h );
	}

	/**
	 * Return a placeholder image URL.
	 *
	 * @param string $label Text to display on the placeholder.
	 * @param int    $w     Image width in pixels.
	 * @param int    $h     Image height in pixels.
	 * @return string
	 */
	private static function placeholder( $label = 'Product Image', $w = 800, $h = 400 ) {
		$text = rawurlencode( wp_strip_all_tags( $label ) );
		return self::PLACEHOLDER_BASE . "/{$w}x{$h}/" . self::BRAND_COLOR . "/ffffff/png?text={$text}&font=open-sans";
	}

	/**
	 * Generate a random 8-character hex string (Elementor-style element ID).
	 *
	 * @return string
	 */
	private static function gen_id() {
		return substr( bin2hex( random_bytes( 4 ) ), 0, 8 );
	}

	/**
	 * Generate a random 6-character alpha-numeric string (Bricks-style element ID).
	 *
	 * @return string
	 */
	private static function bricks_id() {
		$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
		$id    = '';
		for ( $i = 0; $i < 6; $i++ ) {
			$id .= $chars[ random_int( 0, 35 ) ];
		}
		return $id;
	}

	/**
	 * Coerce a copy value to a plain-text string.
	 *
	 * Arrays are joined with newlines; missing values fall back to $fallback.
	 *
	 * @param mixed  $value
	 * @param string $fallback
	 * @return string
	 */
	private static function str( $value, $fallback = '' ) {
		if ( is_array( $value ) ) {
			return implode( "\n", array_filter( array_map( 'trim', $value ) ) );
		}
		return ! empty( $value ) ? (string) $value : $fallback;
	}

	/**
	 * Convert a copy value (newline-separated string or array) to an HTML <ul>.
	 *
	 * @param mixed $items
	 * @return string
	 */
	private static function bullets_html( $items ) {
		if ( is_string( $items ) ) {
			$items = array_filter( array_map( 'trim', explode( "\n", $items ) ) );
		}
		$lis = array_map(
			function ( $item ) {
				return '<li>' . esc_html( $item ) . '</li>';
			},
			(array) $items
		);
		return '<ul>' . implode( '', $lis ) . '</ul>';
	}

	// ══════════════════════════════════════════════════════════════════════════
	// ██  ELEMENTOR
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Write a fresh Elementor layout to post meta.
	 *
	 * Completely replaces any existing _elementor_data, sets the edit mode to
	 * 'builder', and clears stale CSS caches.
	 */
	private static function build_elementor( $step_id, $step_type, array $copy, $product_data ) {
		$elements = self::elementor_layout( $step_type, $copy, $product_data );

		update_post_meta( $step_id, '_elementor_data', wp_json_encode( $elements ) );
		update_post_meta( $step_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $step_id, '_elementor_template_type', 'wp-page' );
		delete_post_meta( $step_id, '_elementor_css' );
		delete_post_meta( $step_id, '_elementor_page_assets' );

		// Elementor reads from meta; keep post_content empty (standard practice).
		wp_update_post( array( 'ID' => $step_id, 'post_content' => '' ) );
	}

	/** Route to the correct Elementor step-type layout builder. */
	private static function elementor_layout( $step_type, array $copy, $product_data ) {
		switch ( $step_type ) {
			case 'checkout':
				return self::el_checkout( $copy, $product_data );
			case 'upsell':
			case 'downsell':
				return self::el_offer( $step_type, $copy, $product_data );
			case 'thankyou':
				return self::el_thankyou( $copy, $product_data );
			case 'landing':
			default:
				return self::el_landing( $copy, $product_data );
		}
	}

	// ── Elementor element factories ───────────────────────────────────────────

	/**
	 * Wrap widget elements in a section > column (single full-width column).
	 *
	 * @param array $widgets        Array of widget element definitions.
	 * @param array $extra_settings Additional settings to merge onto the section.
	 * @return array
	 */
	private static function el_section( array $widgets, array $extra_settings = array() ) {
		return array(
			'id'       => self::gen_id(),
			'elType'   => 'section',
			'settings' => array_merge(
				array(
					'content_width' => 'boxed',
					'padding'       => array(
						'unit'   => 'px',
						'top'    => '60',
						'right'  => '20',
						'bottom' => '60',
						'left'   => '20',
					),
				),
				$extra_settings
			),
			'elements' => array(
				array(
					'id'       => self::gen_id(),
					'elType'   => 'column',
					'settings' => array( '_column_size' => 100 ),
					'elements' => array_values( array_filter( $widgets ) ),
				),
			),
		);
	}

	/** Create a heading widget. */
	private static function el_heading( $text, $tag = 'h2', $align = 'center' ) {
		return array(
			'id'         => self::gen_id(),
			'elType'     => 'widget',
			'widgetType' => 'heading',
			'settings'   => array(
				'title'       => esc_html( $text ),
				'header_size' => $tag,
				'align'       => $align,
			),
			'elements'   => array(),
		);
	}

	/** Create a text-editor (rich text / paragraph) widget. */
	private static function el_text( $html, $align = 'left' ) {
		return array(
			'id'         => self::gen_id(),
			'elType'     => 'widget',
			'widgetType' => 'text-editor',
			'settings'   => array(
				'editor' => $html,
				'align'  => $align,
			),
			'elements'   => array(),
		);
	}

	/**
	 * Create an image widget — real product image when available, placeholder otherwise.
	 *
	 * @param array|null $product_data
	 * @param string     $label  Fallback placeholder label.
	 * @return array
	 */
	private static function el_image( $product_data = null, $label = 'Product Image' ) {
		$url = self::product_image( $product_data, $label );
		return array(
			'id'         => self::gen_id(),
			'elType'     => 'widget',
			'widgetType' => 'image',
			'settings'   => array(
				'image'      => array( 'url' => $url ),
				'image_size' => 'full',
				'align'      => 'center',
			),
			'elements'   => array(),
		);
	}

	/** Create any Elementor widget by type with arbitrary settings. */
	private static function el_widget( $widget_type, array $settings = array() ) {
		return array(
			'id'         => self::gen_id(),
			'elType'     => 'widget',
			'widgetType' => $widget_type,
			'settings'   => $settings,
			'elements'   => array(),
		);
	}

	// ── Elementor step layouts ─────────────────────────────────────────────────

	private static function el_landing( array $copy, $product_data ) {
		$headline = self::str( $copy['headline'] ?? '', ! empty( $product_data['name'] ) ? $product_data['name'] : 'Discover Our Solution' );
		$sub      = self::str( $copy['subheadline'] ?? '' );
		$urgency  = self::str( $copy['urgency_text'] ?? '' );
		$cta      = self::str( $copy['cta_button_text'] ?? 'Continue' );
		$bullets  = $copy['benefit_bullets'] ?? array();

		// ── Hero section (image + headline + subheadline) ──────────────────
		$hero_widgets = array(
			self::el_image( $product_data, $headline ),
			self::el_heading( $headline, 'h1' ),
		);
		if ( $sub ) {
			$hero_widgets[] = self::el_text( '<p>' . esc_html( $sub ) . '</p>', 'center' );
		}

		// ── Benefits / urgency section ─────────────────────────────────────
		$benefit_widgets = array();
		if ( ! empty( $bullets ) ) {
			$benefit_widgets[] = self::el_text( self::bullets_html( $bullets ) );
		}
		if ( $urgency ) {
			$benefit_widgets[] = self::el_text( '<p>' . esc_html( $urgency ) . '</p>', 'center' );
		}

		// ── CTA section (WPFunnels Next Step button) ───────────────────────
		$cta_widgets = array(
			self::el_widget(
				'wpfnl-next-step',
				array(
					'text'  => $cta,
					'align' => 'center',
					'size'  => 'lg',
				)
			),
		);

		$sections = array(
			self::el_section( $hero_widgets, array( 'content_width' => 'full_width' ) ),
		);
		if ( $benefit_widgets ) {
			$sections[] = self::el_section( $benefit_widgets );
		}
		$sections[] = self::el_section( $cta_widgets );

		return $sections;
	}

	private static function el_checkout( array $copy, $product_data ) {
		$default_headline = ! empty( $product_data['name'] ) ? 'Order ' . $product_data['name'] : 'Complete Your Order';
		$headline         = self::str( $copy['headline'] ?? '', $default_headline );
		$trust            = self::str( $copy['trust_text'] ?? '' );

		$header_widgets = array( self::el_heading( $headline, 'h2' ) );
		if ( $trust ) {
			$header_widgets[] = self::el_text( '<p>' . esc_html( $trust ) . '</p>', 'center' );
		}

		return array(
			self::el_section( $header_widgets ),
			// WPFunnels Checkout widget renders the full WooCommerce checkout form.
			self::el_section( array( self::el_widget( 'wpfnl-checkout' ) ) ),
		);
	}

	private static function el_offer( $step_type, array $copy, $product_data ) {
		$default_headline = ! empty( $product_data['name'] ) ? 'Special Offer: ' . $product_data['name'] : 'Special Offer Just For You';
		$headline         = self::str( $copy['offer_headline'] ?? '', $default_headline );
		$sub              = self::str( $copy['offer_subheadline'] ?? '' );
		$urgency          = self::str(
			$copy[ 'downsell' === $step_type ? 'special_offer_text' : 'urgency_text' ] ?? ''
		);
		$accept   = self::str( $copy['accept_button_text'] ?? 'Yes! I Want This' );
		$decline  = self::str( $copy['decline_button_text'] ?? 'No Thanks' );
		$bullets  = 'upsell' === $step_type ? ( $copy['value_stack_bullets'] ?? array() ) : array();

		// ── Hero ──────────────────────────────────────────────────────────
		$hero_widgets = array(
			self::el_image( $product_data, $headline ),
			self::el_heading( $headline, 'h2' ),
		);
		if ( $sub ) {
			$hero_widgets[] = self::el_text( '<p>' . esc_html( $sub ) . '</p>', 'center' );
		}

		// ── Value stack + urgency ─────────────────────────────────────────
		$value_widgets = array();
		if ( ! empty( $bullets ) ) {
			$value_widgets[] = self::el_text( self::bullets_html( $bullets ) );
		}
		if ( $urgency ) {
			$value_widgets[] = self::el_text( '<p>' . esc_html( $urgency ) . '</p>', 'center' );
		}

		// ── Offer buttons (WPFunnels Offer Button widget) ─────────────────
		$cta_widgets = array(
			self::el_widget(
				'wpfnl-offer',
				array(
					'text'              => $accept,
					'offer_type'        => 'accept',
					'offer_button_type' => $step_type,
					'align'             => 'center',
				)
			),
			self::el_widget(
				'wpfnl-offer',
				array(
					'text'              => $decline,
					'offer_type'        => 'reject',
					'offer_button_type' => $step_type,
					'align'             => 'center',
				)
			),
		);

		$sections = array(
			self::el_section( $hero_widgets, array( 'content_width' => 'full_width' ) ),
		);
		if ( $value_widgets ) {
			$sections[] = self::el_section( $value_widgets );
		}
		$sections[] = self::el_section( $cta_widgets );

		return $sections;
	}

	private static function el_thankyou( array $copy, $product_data ) {
		$headline  = self::str( $copy['headline'] ?? '', 'Thank You for Your Order!' );
		$confirm   = self::str( $copy['confirmation_text'] ?? '' );
		$next_step = self::str( $copy['next_steps_text'] ?? '' );
		$cta       = self::str( $copy['cta_button_text'] ?? '' );

		$header_widgets = array( self::el_heading( $headline, 'h2' ) );
		if ( $confirm ) {
			$header_widgets[] = self::el_text( '<p>' . esc_html( $confirm ) . '</p>', 'center' );
		}

		$sections = array(
			self::el_section( $header_widgets ),
			// WPFunnels Order Details widget renders full order summary.
			self::el_section( array( self::el_widget( 'wpfnl-order-detail' ) ) ),
		);

		$footer_widgets = array();
		if ( $next_step ) {
			$footer_widgets[] = self::el_text( '<p>' . esc_html( $next_step ) . '</p>' );
		}
		if ( $cta ) {
			$footer_widgets[] = self::el_widget(
				'button',
				array(
					'text'  => $cta,
					'align' => 'center',
				)
			);
		}
		if ( $footer_widgets ) {
			$sections[] = self::el_section( $footer_widgets );
		}

		return $sections;
	}

	// ══════════════════════════════════════════════════════════════════════════
	// ██  BRICKS
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Write a fresh Bricks layout to _bricks_data post meta.
	 *
	 * Bricks stores a flat array of elements; each element carries an 'id',
	 * 'name', 'parent' (0 for root), 'children' (array of child IDs), and
	 * 'settings'.
	 */
	private static function build_bricks( $step_id, $step_type, array $copy, $product_data ) {
		$elements = self::bricks_layout( $step_type, $copy, $product_data );
		update_post_meta( $step_id, '_bricks_data', wp_json_encode( $elements ) );
		wp_update_post( array( 'ID' => $step_id, 'post_content' => '' ) );
	}

	/**
	 * Build and return the flat Bricks element array for the given step type.
	 *
	 * Internally organised as "groups" (one section + block per group);
	 * each group's child definitions are wired up with generated IDs.
	 */
	private static function bricks_layout( $step_type, array $copy, $product_data ) {
		$groups = self::bricks_groups( $step_type, $copy, $product_data );
		$all    = array();

		foreach ( $groups as $group ) {
			$section_id = self::bricks_id();
			$block_id   = self::bricks_id();
			$child_ids  = array();
			$child_els  = array();

			foreach ( $group as $def ) {
				if ( empty( $def ) ) {
					continue;
				}
				$child_id    = self::bricks_id();
				$child_ids[] = $child_id;
				$el          = $def;
				$el['id']     = $child_id;
				$el['parent'] = $block_id;
				if ( ! isset( $el['children'] ) ) {
					$el['children'] = array();
				}
				$child_els[] = $el;
			}

			$all[] = array(
				'id'       => $section_id,
				'name'     => 'section',
				'parent'   => 0,
				'children' => array( $block_id ),
				'settings' => array(),
			);
			$all[] = array(
				'id'       => $block_id,
				'name'     => 'block',
				'parent'   => $section_id,
				'children' => $child_ids,
				'settings' => array(),
			);
			foreach ( $child_els as $el ) {
				$all[] = $el;
			}
		}

		return $all;
	}

	/** Return per-step-type groups of raw Bricks child element definitions. */
	private static function bricks_groups( $step_type, array $copy, $product_data ) {
		switch ( $step_type ) {
			case 'checkout':
				return self::bricks_checkout( $copy, $product_data );
			case 'upsell':
			case 'downsell':
				return self::bricks_offer( $step_type, $copy, $product_data );
			case 'thankyou':
				return self::bricks_thankyou( $copy, $product_data );
			case 'landing':
			default:
				return self::bricks_landing( $copy, $product_data );
		}
	}

	// ── Bricks element factories ──────────────────────────────────────────────

	private static function br_heading( $text, $tag = 'h2' ) {
		return array(
			'name'     => 'heading',
			'settings' => array(
				'text' => esc_html( $text ),
				'tag'  => $tag,
			),
		);
	}

	private static function br_text( $html ) {
		return array(
			'name'     => 'text-basic',
			'settings' => array( 'text' => wp_kses_post( $html ) ),
		);
	}

	private static function br_image( $product_data = null, $label = 'Product Image' ) {
		$url = self::product_image( $product_data, $label );
		return array(
			'name'     => 'image',
			'settings' => array(
				'image' => array(
					'external' => true,
					'url'      => $url,
				),
				'size'  => 'full',
			),
		);
	}

	private static function br_widget( $name, array $settings = array() ) {
		return array(
			'name'     => $name,
			'settings' => $settings,
		);
	}

	// ── Bricks step layouts ───────────────────────────────────────────────────

	private static function bricks_landing( array $copy, $product_data ) {
		$headline = self::str( $copy['headline'] ?? '', ! empty( $product_data['name'] ) ? $product_data['name'] : 'Discover Our Solution' );
		$sub      = self::str( $copy['subheadline'] ?? '' );
		$urgency  = self::str( $copy['urgency_text'] ?? '' );
		$cta      = self::str( $copy['cta_button_text'] ?? 'Continue' );
		$bullets  = $copy['benefit_bullets'] ?? array();

		$hero = array( self::br_image( $product_data, $headline ), self::br_heading( $headline, 'h1' ) );
		if ( $sub ) {
			$hero[] = self::br_text( '<p>' . esc_html( $sub ) . '</p>' );
		}

		$middle = array();
		if ( ! empty( $bullets ) ) {
			$middle[] = self::br_text( self::bullets_html( $bullets ) );
		}
		if ( $urgency ) {
			$middle[] = self::br_text( '<p>' . esc_html( $urgency ) . '</p>' );
		}

		// WPFunnels Next Step button widget.
		$cta_group = array(
			self::br_widget( 'wpfnl_next_step', array( 'text' => $cta ) ),
		);

		$groups = array( $hero );
		if ( $middle ) {
			$groups[] = $middle;
		}
		$groups[] = $cta_group;

		return $groups;
	}

	private static function bricks_checkout( array $copy, $product_data ) {
		$default_headline = ! empty( $product_data['name'] ) ? 'Order ' . $product_data['name'] : 'Complete Your Order';
		$headline         = self::str( $copy['headline'] ?? '', $default_headline );
		$trust            = self::str( $copy['trust_text'] ?? '' );

		$header = array( self::br_heading( $headline ) );
		if ( $trust ) {
			$header[] = self::br_text( '<p>' . esc_html( $trust ) . '</p>' );
		}

		return array(
			$header,
			// WPFunnels Checkout widget.
			array( self::br_widget( 'wpfnl_checkout' ) ),
		);
	}

	private static function bricks_offer( $step_type, array $copy, $product_data ) {
		$default_headline = ! empty( $product_data['name'] ) ? 'Special Offer: ' . $product_data['name'] : 'Special Offer Just For You';
		$headline         = self::str( $copy['offer_headline'] ?? '', $default_headline );
		$sub              = self::str( $copy['offer_subheadline'] ?? '' );
		$urgency          = self::str(
			$copy[ 'downsell' === $step_type ? 'special_offer_text' : 'urgency_text' ] ?? ''
		);
		$accept   = self::str( $copy['accept_button_text'] ?? 'Yes! I Want This' );
		$decline  = self::str( $copy['decline_button_text'] ?? 'No Thanks' );
		$bullets  = 'upsell' === $step_type ? ( $copy['value_stack_bullets'] ?? array() ) : array();

		$hero = array( self::br_image( $product_data, $headline ), self::br_heading( $headline ) );
		if ( $sub ) {
			$hero[] = self::br_text( '<p>' . esc_html( $sub ) . '</p>' );
		}

		$middle = array();
		if ( ! empty( $bullets ) ) {
			$middle[] = self::br_text( self::bullets_html( $bullets ) );
		}
		if ( $urgency ) {
			$middle[] = self::br_text( '<p>' . esc_html( $urgency ) . '</p>' );
		}

		// WPFunnels Offer Button widget (accept + reject instances).
		$cta_group = array(
			self::br_widget( 'wpfnl_offer_button', array( 'text' => $accept, 'offer_type' => 'accept' ) ),
			self::br_widget( 'wpfnl_offer_button', array( 'text' => $decline, 'offer_type' => 'reject' ) ),
		);

		$groups = array( $hero );
		if ( $middle ) {
			$groups[] = $middle;
		}
		$groups[] = $cta_group;

		return $groups;
	}

	private static function bricks_thankyou( array $copy, $product_data ) {
		$headline  = self::str( $copy['headline'] ?? '', 'Thank You for Your Order!' );
		$confirm   = self::str( $copy['confirmation_text'] ?? '' );
		$next_step = self::str( $copy['next_steps_text'] ?? '' );

		$header = array( self::br_heading( $headline ) );
		if ( $confirm ) {
			$header[] = self::br_text( '<p>' . esc_html( $confirm ) . '</p>' );
		}

		$sections = array(
			$header,
			// WPFunnels Order Details widget (note: intentional typo matches class $name).
			array( self::br_widget( 'wpfnl_order_deatils' ) ),
		);

		if ( $next_step ) {
			$sections[] = array( self::br_text( '<p>' . esc_html( $next_step ) . '</p>' ) );
		}

		return $sections;
	}

	// ══════════════════════════════════════════════════════════════════════════
	// ██  DIVI
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Write Divi shortcode content to post_content and divi_content meta.
	 */
	private static function build_divi( $step_id, $step_type, array $copy, $product_data ) {
		$content = self::divi_layout( $step_type, $copy, $product_data );
		wp_update_post( array( 'ID' => $step_id, 'post_content' => $content ) );
		update_post_meta( $step_id, 'divi_content', $content );
		update_post_meta( $step_id, '_et_pb_use_builder', 'on' );
	}

	/** Route to the correct Divi step-type layout builder. */
	private static function divi_layout( $step_type, array $copy, $product_data ) {
		switch ( $step_type ) {
			case 'checkout':
				return self::divi_checkout( $copy, $product_data );
			case 'upsell':
			case 'downsell':
				return self::divi_offer( $step_type, $copy, $product_data );
			case 'thankyou':
				return self::divi_thankyou( $copy, $product_data );
			case 'landing':
			default:
				return self::divi_landing( $copy, $product_data );
		}
	}

	/** Wrap inner shortcode content in the standard Divi section > row > column. */
	private static function divi_wrap( $inner ) {
		return '[et_pb_section][et_pb_row][et_pb_column type="4_4"]'
			. $inner
			. '[/et_pb_column][/et_pb_row][/et_pb_section]';
	}

	private static function divi_landing( array $copy, $product_data ) {
		$headline = self::str( $copy['headline'] ?? '', ! empty( $product_data['name'] ) ? $product_data['name'] : 'Discover Our Solution' );
		$sub      = self::str( $copy['subheadline'] ?? '' );
		$urgency  = self::str( $copy['urgency_text'] ?? '' );
		$cta      = self::str( $copy['cta_button_text'] ?? 'Continue' );
		$bullets  = $copy['benefit_bullets'] ?? array();

		$inner = '[et_pb_image src="' . esc_attr( self::product_image( $product_data, $headline ) ) . '" force_fullwidth="on" /]'
			. '[et_pb_heading title="' . esc_attr( $headline ) . '" /]';

		if ( $sub ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $sub ) . '</p>[/et_pb_text]';
		}
		if ( ! empty( $bullets ) ) {
			$inner .= '[et_pb_text]' . self::bullets_html( $bullets ) . '[/et_pb_text]';
		}
		if ( $urgency ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $urgency ) . '</p>[/et_pb_text]';
		}
		// WPFunnels Next Step Button Divi module.
		$inner .= '[wpfnl_next_step_button text="' . esc_attr( $cta ) . '" /]';

		return self::divi_wrap( $inner );
	}

	private static function divi_checkout( array $copy, $product_data ) {
		$default_headline = ! empty( $product_data['name'] ) ? 'Order ' . $product_data['name'] : 'Complete Your Order';
		$headline         = self::str( $copy['headline'] ?? '', $default_headline );
		$trust            = self::str( $copy['trust_text'] ?? '' );

		$inner = '[et_pb_heading title="' . esc_attr( $headline ) . '" /]';
		if ( $trust ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $trust ) . '</p>[/et_pb_text]';
		}
		// WPFunnels Checkout Divi module.
		$inner .= '[wpfnl_checkout /]';

		return self::divi_wrap( $inner );
	}

	private static function divi_offer( $step_type, array $copy, $product_data ) {
		$default_headline = ! empty( $product_data['name'] ) ? 'Special Offer: ' . $product_data['name'] : 'Special Offer Just For You';
		$headline         = self::str( $copy['offer_headline'] ?? '', $default_headline );
		$sub              = self::str( $copy['offer_subheadline'] ?? '' );
		$urgency          = self::str(
			$copy[ 'downsell' === $step_type ? 'special_offer_text' : 'urgency_text' ] ?? ''
		);
		$accept   = self::str( $copy['accept_button_text'] ?? 'Yes! I Want This' );
		$decline  = self::str( $copy['decline_button_text'] ?? 'No Thanks' );
		$bullets  = 'upsell' === $step_type ? ( $copy['value_stack_bullets'] ?? array() ) : array();

		$inner = '[et_pb_image src="' . esc_attr( self::product_image( $product_data, $headline ) ) . '" force_fullwidth="on" /]'
			. '[et_pb_heading title="' . esc_attr( $headline ) . '" /]';

		if ( $sub ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $sub ) . '</p>[/et_pb_text]';
		}
		if ( ! empty( $bullets ) ) {
			$inner .= '[et_pb_text]' . self::bullets_html( $bullets ) . '[/et_pb_text]';
		}
		if ( $urgency ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $urgency ) . '</p>[/et_pb_text]';
		}
		// WPFunnels Offer Button Divi modules (accept + reject).
		$inner .= '[wpfnl_offer_button text="' . esc_attr( $accept ) . '" offer_type="accept" /]';
		$inner .= '[wpfnl_offer_button text="' . esc_attr( $decline ) . '" offer_type="reject" /]';

		return self::divi_wrap( $inner );
	}

	private static function divi_thankyou( array $copy, $product_data ) {
		$headline  = self::str( $copy['headline'] ?? '', 'Thank You for Your Order!' );
		$confirm   = self::str( $copy['confirmation_text'] ?? '' );
		$next_step = self::str( $copy['next_steps_text'] ?? '' );

		$inner = '[et_pb_heading title="' . esc_attr( $headline ) . '" /]';
		if ( $confirm ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $confirm ) . '</p>[/et_pb_text]';
		}
		// WPFunnels Order Details Divi module.
		$inner .= '[wpfnl_order_details /]';
		if ( $next_step ) {
			$inner .= '[et_pb_text]<p>' . esc_html( $next_step ) . '</p>[/et_pb_text]';
		}

		return self::divi_wrap( $inner );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// ██  GUTENBERG
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Write Gutenberg block markup to post_content.
	 */
	private static function build_gutenberg( $step_id, $step_type, array $copy, $product_data ) {
		$content = self::gutenberg_layout( $step_type, $copy, $product_data );
		wp_update_post( array( 'ID' => $step_id, 'post_content' => $content ) );
	}

	private static function gutenberg_layout( $step_type, array $copy, $product_data ) {
		$blocks = array();

		// ── Closure helpers ──────────────────────────────────────────────────
		$add_image = function ( $label ) use ( &$blocks, $product_data ) {
			$url      = self::product_image( $product_data, $label );
			$alt      = ! empty( $product_data['name'] ) ? esc_attr( $product_data['name'] ) : 'Product Image';
			$blocks[] = sprintf(
				"<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"%s\" alt=\"%s\"/></figure>\n<!-- /wp:image -->",
				esc_url( $url ),
				$alt
			);
		};

		$add_heading = function ( $text, $level = 2 ) use ( &$blocks ) {
			$blocks[] = sprintf(
				"<!-- wp:heading {\"level\":%d} -->\n<h%d class=\"wp-block-heading\">%s</h%d>\n<!-- /wp:heading -->",
				$level,
				$level,
				esc_html( $text ),
				$level
			);
		};

		$add_paragraph = function ( $text ) use ( &$blocks ) {
			$blocks[] = sprintf(
				"<!-- wp:paragraph -->\n<p>%s</p>\n<!-- /wp:paragraph -->",
				esc_html( $text )
			);
		};

		$add_list = function ( $items ) use ( &$blocks ) {
			if ( is_string( $items ) ) {
				$items = array_filter( array_map( 'trim', explode( "\n", $items ) ) );
			}
			$lis      = implode(
				'',
				array_map(
					function ( $i ) { return '<li>' . esc_html( $i ) . '</li>'; },
					(array) $items
				)
			);
			$blocks[] = "<!-- wp:list -->\n<ul>$lis</ul>\n<!-- /wp:list -->";
		};

		$add_shortcode = function ( $code ) use ( &$blocks ) {
			$blocks[] = "<!-- wp:shortcode -->\n[$code]\n<!-- /wp:shortcode -->";
		};

		// ── Build per step type ───────────────────────────────────────────────
		switch ( $step_type ) {
			case 'landing':
				$headline = self::str( $copy['headline'] ?? '', 'Discover Our Solution' );
				$sub      = self::str( $copy['subheadline'] ?? '' );
				$urgency  = self::str( $copy['urgency_text'] ?? '' );
				$cta      = self::str( $copy['cta_button_text'] ?? 'Continue' );
				$bullets  = $copy['benefit_bullets'] ?? array();

				$add_image( $headline );
				$add_heading( $headline, 1 );
				if ( $sub )           { $add_paragraph( $sub ); }
				if ( ! empty( $bullets ) ) { $add_list( $bullets ); }
				if ( $urgency )       { $add_paragraph( $urgency ); }
				$add_shortcode( 'wpfnl_next_step text="' . esc_attr( $cta ) . '"' );
				break;

			case 'checkout':
				$headline = self::str( $copy['headline'] ?? '', 'Complete Your Order' );
				$trust    = self::str( $copy['trust_text'] ?? '' );

				$add_heading( $headline );
				if ( $trust ) { $add_paragraph( $trust ); }
				$add_shortcode( 'wpfnl_checkout' );
				break;

			case 'upsell':
			case 'downsell':
				$headline = self::str( $copy['offer_headline'] ?? '', 'Special Offer Just For You' );
				$sub      = self::str( $copy['offer_subheadline'] ?? '' );
				$urgency  = self::str(
					$copy[ 'downsell' === $step_type ? 'special_offer_text' : 'urgency_text' ] ?? ''
				);
				$accept   = self::str( $copy['accept_button_text'] ?? 'Yes! I Want This' );
				$decline  = self::str( $copy['decline_button_text'] ?? 'No Thanks' );
				$bullets  = 'upsell' === $step_type ? ( $copy['value_stack_bullets'] ?? array() ) : array();

				$add_image( $headline );
				$add_heading( $headline );
				if ( $sub )           { $add_paragraph( $sub ); }
				if ( ! empty( $bullets ) ) { $add_list( $bullets ); }
				if ( $urgency )       { $add_paragraph( $urgency ); }
				$add_shortcode( 'wpfnl_offer_button text="' . esc_attr( $accept ) . '" offer_type="accept"' );
				$add_shortcode( 'wpfnl_offer_button text="' . esc_attr( $decline ) . '" offer_type="reject"' );
				break;

			case 'thankyou':
				$headline  = self::str( $copy['headline'] ?? '', 'Thank You for Your Order!' );
				$confirm   = self::str( $copy['confirmation_text'] ?? '' );
				$next_step = self::str( $copy['next_steps_text'] ?? '' );

				$add_heading( $headline );
				if ( $confirm )   { $add_paragraph( $confirm ); }
				$add_shortcode( 'wpfnl_order_details' );
				if ( $next_step ) { $add_paragraph( $next_step ); }
				break;
		}

		return implode( "\n\n", $blocks );
	}
}
