<?php
/**
 * IntegrationTools — MCP abilities for WPFunnels Pro integrations: webhooks,
 * CRM, and tracking (GTM / Facebook Pixel).
 *
 * `list-webhooks` and `upsert-webhook` are moved unchanged (aside from the
 * namespace and an added Pro guard) from the Free plugin's
 * `Tools/AutomationTools.php`, which mixed the webhook domain with the
 * automation domain (now split out into `AutomationTools.php`).
 *
 * `get-tracking-settings` / `update-tracking-settings` (plan §5.2) are newly
 * implemented against the real, verified options WPFunnels Pro's own GTM and
 * Facebook Pixel classes read
 * (`WPFunnelsPro\Tracking\GTM::get_settings()` reads `_wpfunnels_gtm`;
 * `WPFunnelsPro\Tracking\Pixel\Facebook_Pixel_Integration` reads
 * `_wpfunnels_facebook_pixel`).
 *
 * @package WPFunnelsPro\MCP\Tools
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP\Tools;

defined( 'ABSPATH' ) || exit;

use WPFunnels\MCP\Helpers\MCPHelper;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Wpfnl_Pro_functions;
use WPFunnelsProWebHooks\Functions\Wpfnl_Pro_Webhook_Functions;

/**
 * Class IntegrationTools
 */
class IntegrationTools {

	/**
	 * Option name WPFunnelsPro\Tracking\GTM reads/writes.
	 */
	private const GTM_OPTION = '_wpfunnels_gtm';

	/**
	 * Option name WPFunnelsPro\Tracking\Pixel\Facebook_Pixel_Integration reads.
	 */
	private const FB_PIXEL_OPTION = '_wpfunnels_facebook_pixel';

	/**
	 * Register tool definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return [
			'wpfunnels/list-webhooks' => [
				'description' => 'List outgoing webhooks registered on a funnel (stored per-funnel, not site-wide).',
				'category'    => 'integration',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'funnel_id' => [
							'type'        => 'integer',
							'description' => 'Funnel post ID.',
						],
					],
					'required'   => [ 'funnel_id' ],
				],
				'callback'    => [ __CLASS__, 'listWebhooks' ],
			],

			'wpfunnels/upsert-webhook' => [
				'description' => 'Register or update an outgoing webhook on a funnel. Pass webhook_id to update an existing one; omit it to create a new one.',
				'category'    => 'integration',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'funnel_id'   => [
							'type'        => 'integer',
							'description' => 'Funnel post ID.',
						],
						'webhook_id'  => [
							'type'        => 'string',
							'description' => 'ID of an existing webhook to update (from list-webhooks). Omit to create a new one.',
						],
						'url'         => [
							'type'        => 'string',
							'description' => 'Destination HTTP endpoint URL.',
						],
						'event'       => [
							'type'        => 'string',
							'description' => 'Event that fires this webhook.',
							'enum'        => array_keys( Wpfnl_Pro_Webhook_Functions::get_all_supported_event() ),
						],
						'status'      => [
							'type'        => 'string',
							'enum'        => [ 'on', 'off' ],
							'description' => 'Whether the webhook is active. Defaults to on.',
						],
						'body_type'   => [
							'type'        => 'string',
							'enum'        => [ 'all', 'selected' ],
							'description' => 'Send all supported fields, or only the ones named in body_fields. Defaults to all.',
						],
						'body_fields' => [
							'type'        => 'object',
							'description' => 'Only used when body_type is "selected". Map of field key (from ' . implode( ', ', array_keys( Wpfnl_Pro_Webhook_Functions::get_all_body_fields() ) ) . ') to the label to send it under.',
						],
						'headers'     => [
							'type'        => 'array',
							'description' => 'Extra HTTP headers to send.',
							'items'       => [
								'type'       => 'object',
								'properties' => [
									'name'  => [ 'type' => 'string' ],
									'value' => [ 'type' => 'string' ],
								],
							],
						],
					],
					'required'   => [ 'funnel_id', 'url', 'event' ],
				],
				'callback'    => [ __CLASS__, 'upsertWebhook' ],
			],

			'wpfunnels/delete-webhook' => [
				'description' => 'Remove a webhook from a funnel.',
				'category'    => 'integration',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'funnel_id'  => [
							'type'        => 'integer',
							'description' => 'Funnel post ID.',
						],
						'webhook_id' => [
							'type'        => 'string',
							'description' => 'ID of the webhook to delete, from list-webhooks.',
						],
					],
					'required'   => [ 'funnel_id', 'webhook_id' ],
				],
				'callback'    => [ __CLASS__, 'deleteWebhook' ],
			],

			'wpfunnels/get-tracking-settings' => [
				'description' => 'Get Google Tag Manager and Facebook Pixel tracking configuration for this site.',
				'category'    => 'integration',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [],
				],
				'callback'    => [ __CLASS__, 'getTrackingSettings' ],
			],

			'wpfunnels/update-tracking-settings' => [
				'description' => 'Enable/disable and configure the Google Tag Manager container ID or Facebook Pixel ID.',
				'category'    => 'integration',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'gtm_enable'            => [
							'type'        => 'boolean',
							'description' => 'Enable Google Tag Manager site-wide.',
						],
						'gtm_container_id'      => [
							'type'        => 'string',
							'description' => 'GTM container ID, e.g. GTM-XXXXXXX.',
						],
						'facebook_pixel_enable' => [
							'type'        => 'boolean',
							'description' => 'Enable Facebook Pixel site-wide.',
						],
						'facebook_pixel_id'     => [
							'type'        => 'string',
							'description' => 'Facebook Pixel ID.',
						],
					],
				],
				'callback'    => [ __CLASS__, 'updateTrackingSettings' ],
			],

			'wpfunnels/test-webhook' => [
				'description' => 'Fire a real outbound HTTP request to a webhook endpoint using a synthetic sample payload shaped like a live event, so you can confirm the endpoint is reachable and accepts the request before relying on it for real funnel events. This is a genuine external side effect against a real third-party URL. Pass funnel_id + webhook_id to test an already-saved webhook (its own saved url/event/body/header configuration is used as-is); or pass url/event (and optionally body_type/body_fields/headers) to test settings that have not been saved yet.',
				'category'    => 'integration',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'funnel_id'   => [
							'type'        => 'integer',
							'description' => 'Funnel post ID. Required together with webhook_id to test an existing saved webhook.',
						],
						'webhook_id'  => [
							'type'        => 'string',
							'description' => 'ID of an existing webhook (from list-webhooks) to load and test as-is. Requires funnel_id. Omit to test raw settings passed directly via url/event instead.',
						],
						'url'         => [
							'type'        => 'string',
							'description' => 'Destination HTTP endpoint URL to test. Required when webhook_id is not provided.',
						],
						'event'       => [
							'type'        => 'string',
							'description' => 'Event type the sample payload should be shaped for. Required when webhook_id is not provided.',
							'enum'        => array_keys( Wpfnl_Pro_Webhook_Functions::get_all_supported_event() ),
						],
						'body_type'   => [
							'type'        => 'string',
							'enum'        => [ 'all', 'selected' ],
							'description' => 'Send all supported sample fields, or only the ones named in body_fields. Defaults to all. Ignored when webhook_id is provided — the saved webhook\'s own body configuration is used instead.',
						],
						'body_fields' => [
							'type'        => 'object',
							'description' => 'Only used when body_type is "selected" and webhook_id is not provided. Map of field key (from ' . implode( ', ', array_keys( Wpfnl_Pro_Webhook_Functions::get_all_body_fields() ) ) . ') to the label to send it under.',
						],
						'headers'     => [
							'type'        => 'array',
							'description' => 'Extra HTTP headers to send. Ignored when webhook_id is provided.',
							'items'       => [
								'type'       => 'object',
								'properties' => [
									'name'  => [ 'type' => 'string' ],
									'value' => [ 'type' => 'string' ],
								],
							],
						],
					],
				],
				'callback'    => [ __CLASS__, 'testWebhook' ],
			],

			// TODO(ai-v2): `list-crm-integrations` and `configure-funnel-crm`
			// (plan §5.2) are not implemented. WPFunnels Pro supports over a
			// dozen separate CRM providers (Mailchimp, HubSpot, ActiveCampaign,
			// Zapier, ConvertKit, …), each with its own credential/option shape
			// under `includes/core/integrations/crm/*`; confidently enumerating
			// "configured" state across all of them, or writing a
			// `configure-funnel-crm` that touches the right provider's schema,
			// needs more research time than was available. Skipped rather than
			// guessing at per-provider option names.
		];
	}

	/**
	 * Guard check for Pro plugin/license.
	 *
	 * @return bool
	 */
	protected static function checkPro() {
		return Wpfnl_functions::is_wpfnl_pro_activated();
	}

	/**
	 * List webhooks.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function listWebhooks( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Webhooks are a WPFunnels Pro feature.' );
		}

		$funnel = MCPHelper::requireFunnel( isset( $input['funnel_id'] ) ? $input['funnel_id'] : 0 );
		if ( is_wp_error( $funnel ) ) {
			return $funnel;
		}

		$settings = Wpfnl_Pro_Webhook_Functions::get_webhook_settings( $funnel->ID );

		return [
			'funnel_id' => (int) $funnel->ID,
			'webhooks'  => is_array( $settings ) ? array_values( $settings ) : [],
		];
	}

	/**
	 * Upsert webhook. Reuses the exact `_wpfunnels_webhook_settings` record
	 * shape and ID scheme the Webhook admin screen writes via
	 * WebhookController::save_or_update_webhook(), so records created either
	 * way stay addressable by both.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function upsertWebhook( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Webhooks are a WPFunnels Pro feature.' );
		}

		$funnel = MCPHelper::requireFunnel( isset( $input['funnel_id'] ) ? $input['funnel_id'] : 0 );
		if ( is_wp_error( $funnel ) ) {
			return $funnel;
		}

		$url   = isset( $input['url'] ) ? esc_url_raw( $input['url'] ) : '';
		$event = isset( $input['event'] ) ? sanitize_text_field( $input['event'] ) : '';
		if ( '' === $url || ! isset( Wpfnl_Pro_Webhook_Functions::get_all_supported_event()[ $event ] ) ) {
			return MCPHelper::error( 'invalid_webhook', 'Provide a url and a supported event.' );
		}

		$body_type   = isset( $input['body_type'] ) && 'selected' === $input['body_type'] ? 'selected' : 'all';
		$body_fields = [];
		if ( 'selected' === $body_type && ! empty( $input['body_fields'] ) && is_array( $input['body_fields'] ) ) {
			$allowed = Wpfnl_Pro_Webhook_Functions::get_all_body_fields();
			foreach ( $input['body_fields'] as $key => $label ) {
				if ( isset( $allowed[ $key ] ) ) {
					$body_fields[ sanitize_key( $key ) ] = sanitize_text_field( $label );
				}
			}
		}

		$headers = [];
		if ( ! empty( $input['headers'] ) && is_array( $input['headers'] ) ) {
			foreach ( $input['headers'] as $header ) {
				if ( isset( $header['name'], $header['value'] ) ) {
					$headers[] = [
						'name'  => sanitize_text_field( $header['name'] ),
						'value' => sanitize_text_field( $header['value'] ),
					];
				}
			}
		}

		$record = [
			'status'     => isset( $input['status'] ) && 'off' === $input['status'] ? 'off' : 'on',
			'conditions' => $event,
			'request'    => [
				'url'    => $url,
				'body'   => [
					'type'   => $body_type,
					'values' => $body_fields,
				],
				'header' => $headers,
			],
		];

		$settings   = Wpfnl_Pro_Webhook_Functions::get_webhook_settings( $funnel->ID );
		$settings   = is_array( $settings ) ? $settings : [];
		$webhook_id = isset( $input['webhook_id'] ) ? sanitize_text_field( $input['webhook_id'] ) : '';

		$key = '' !== $webhook_id ? array_search( $webhook_id, array_column( $settings, 'id' ), true ) : false;
		if ( false !== $key ) {
			$record['id']  = $webhook_id;
			$settings[ $key ] = $record;
		} else {
			$record['id'] = mt_rand() . date( 'Hi' );
			$settings[]   = $record;
		}

		update_post_meta( $funnel->ID, '_wpfunnels_webhook_settings', $settings );

		return [
			'upserted'  => true,
			'funnel_id' => (int) $funnel->ID,
			'webhook'   => $record,
		];
	}

	/**
	 * Delete a webhook from a funnel's settings blob.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function deleteWebhook( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Webhooks are a WPFunnels Pro feature.' );
		}

		$funnel = MCPHelper::requireFunnel( isset( $input['funnel_id'] ) ? $input['funnel_id'] : 0 );
		if ( is_wp_error( $funnel ) ) {
			return $funnel;
		}

		$webhook_id = isset( $input['webhook_id'] ) ? sanitize_text_field( $input['webhook_id'] ) : '';
		$settings   = Wpfnl_Pro_Webhook_Functions::get_webhook_settings( $funnel->ID );
		$settings   = is_array( $settings ) ? $settings : [];

		$key = array_search( $webhook_id, array_column( $settings, 'id' ), true );
		if ( false === $key ) {
			return MCPHelper::error( 'webhook_not_found', 'No webhook found with that ID on this funnel.' );
		}

		unset( $settings[ $key ] );
		$settings = array_values( $settings );

		if ( empty( $settings ) ) {
			delete_post_meta( $funnel->ID, '_wpfunnels_webhook_settings' );
		} else {
			update_post_meta( $funnel->ID, '_wpfunnels_webhook_settings', $settings );
		}

		return [
			'deleted'   => true,
			'funnel_id' => (int) $funnel->ID,
			'webhook_id' => $webhook_id,
		];
	}

	/**
	 * Get GTM + Facebook Pixel tracking settings.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function getTrackingSettings( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Tracking integrations are a WPFunnels Pro feature.' );
		}

		$gtm_default = [
			'gtm_enable'       => 'off',
			'gtm_container_id' => '',
		];
		$gtm = wp_parse_args( get_option( self::GTM_OPTION, $gtm_default ), $gtm_default );

		$fb = get_option( self::FB_PIXEL_OPTION, [] );
		$fb = is_array( $fb ) ? $fb : [];

		return [
			'gtm'            => [
				'enabled'      => 'on' === ( isset( $gtm['gtm_enable'] ) ? $gtm['gtm_enable'] : 'off' ),
				'container_id' => isset( $gtm['gtm_container_id'] ) ? $gtm['gtm_container_id'] : '',
			],
			'facebook_pixel' => [
				'enabled'  => isset( $fb['enable_fb_pixel'] ) && 'on' === $fb['enable_fb_pixel'],
				'pixel_id' => isset( $fb['facebook_pixel_id'] ) ? $fb['facebook_pixel_id'] : '',
			],
		];
	}

	/**
	 * Update GTM + Facebook Pixel tracking settings.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function updateTrackingSettings( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Tracking integrations are a WPFunnels Pro feature.' );
		}

		if ( array_key_exists( 'gtm_enable', $input ) || array_key_exists( 'gtm_container_id', $input ) ) {
			$gtm_default = [
				'gtm_enable'       => 'off',
				'gtm_container_id' => '',
			];
			$gtm = wp_parse_args( get_option( self::GTM_OPTION, $gtm_default ), $gtm_default );

			if ( array_key_exists( 'gtm_enable', $input ) ) {
				$gtm['gtm_enable'] = ! empty( $input['gtm_enable'] ) ? 'on' : 'off';
			}
			if ( array_key_exists( 'gtm_container_id', $input ) ) {
				$gtm['gtm_container_id'] = sanitize_text_field( $input['gtm_container_id'] );
			}

			update_option( self::GTM_OPTION, $gtm );
		}

		if ( array_key_exists( 'facebook_pixel_enable', $input ) || array_key_exists( 'facebook_pixel_id', $input ) ) {
			$fb = get_option( self::FB_PIXEL_OPTION, [] );
			$fb = is_array( $fb ) ? $fb : [];

			if ( array_key_exists( 'facebook_pixel_enable', $input ) ) {
				$fb['enable_fb_pixel'] = ! empty( $input['facebook_pixel_enable'] ) ? 'on' : 'off';
			}
			if ( array_key_exists( 'facebook_pixel_id', $input ) ) {
				$fb['facebook_pixel_id'] = sanitize_text_field( $input['facebook_pixel_id'] );
			}

			// Seed the event list when the stored option carries none. Without this the
			// pixel is enabled with no active events, and Facebook_Pixel_Integration
			// fires PageView only — while the settings screen, which merges defaults,
			// shows every event ticked.
			if ( empty( $fb['facebook_tracking_events'] ) || ! is_array( $fb['facebook_tracking_events'] ) ) {
				$fb['facebook_tracking_events'] = self::defaultPixelEvents();
			}

			update_option( self::FB_PIXEL_OPTION, $fb );
		}

		return array_merge( [ 'updated' => true ], self::getTrackingSettings() );
	}

	/**
	 * Default "all events on" map for the Facebook Pixel.
	 *
	 * Mirrors the defaults Wpfnl_functions::get_facebook_pixel_settings() merges over the
	 * stored option, so a pixel enabled through this tool tracks what the settings screen
	 * says it tracks.
	 *
	 * @return array
	 */
	private static function defaultPixelEvents() {
		$events = [];

		if ( method_exists( 'WPFunnels\\Wpfnl_functions', 'get_facebook_events' ) ) {
			foreach ( array_keys( \WPFunnels\Wpfnl_functions::get_facebook_events() ) as $event ) {
				$events[ $event ] = 'true';
			}
		}

		if ( empty( $events ) ) {
			$events = [
				'AddPaymentInfo'   => 'true',
				'AddToCart'        => 'true',
				'InitiateCheckout' => 'true',
				'Purchase'         => 'true',
				'ViewContent'      => 'true',
			];
		}

		return $events;
	}

	/**
	 * Fire a real test HTTP request against a webhook endpoint.
	 *
	 * Reuses the exact "send" primitive every real webhook event class
	 * (`WPFunnelsProWebHooks\Events\Wpfnl_Pro_Webhook_*`) calls at the end of
	 * its own `send_data()`: `Wpfnl_Pro_functions::prepare_common_request_args()`
	 * to build method/headers/body exactly as production does, then
	 * `wp_remote_request()` against `Wpfnl_Pro_Webhook_Functions::get_request_url()`.
	 *
	 * What is NOT reused is each event class's own `prepare_request_body()` —
	 * those all pull from a real `WC_Order` (`wc_get_order( $order_id )`) or a
	 * real opt-in `$record`, which a "test" call has neither of, and pulling in
	 * a real one would mean either mailing a real customer's data to a
	 * third-party test target or fatally erroring on a site with no orders
	 * yet. Instead `buildSampleWebhookPayload()` reproduces the exact field
	 * keys/labels those classes emit for `body_type` all/selected (verified
	 * against `Wpfnl_Pro_Webhook_Checkout`, `_Optin`, `_Orderbump`, `_Offer`)
	 * populated with obviously-synthetic sample values — same shape as a real
	 * event, no fabricated field names, no real customer data.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function testWebhook( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Webhooks are a WPFunnels Pro feature.' );
		}

		$webhook_id = isset( $input['webhook_id'] ) ? sanitize_text_field( $input['webhook_id'] ) : '';

		if ( '' !== $webhook_id ) {
			$funnel = MCPHelper::requireFunnel( isset( $input['funnel_id'] ) ? $input['funnel_id'] : 0 );
			if ( is_wp_error( $funnel ) ) {
				return $funnel;
			}

			$saved = Wpfnl_Pro_Webhook_Functions::get_webhook_settings( $funnel->ID );
			$saved = is_array( $saved ) ? $saved : [];
			$key   = array_search( $webhook_id, array_column( $saved, 'id' ), true );
			if ( false === $key ) {
				return MCPHelper::error( 'webhook_not_found', 'No webhook found with that ID on this funnel.' );
			}
			$settings = $saved[ $key ];
		} else {
			$url   = isset( $input['url'] ) ? esc_url_raw( $input['url'] ) : '';
			$event = isset( $input['event'] ) ? sanitize_text_field( $input['event'] ) : '';
			if ( '' === $url || ! isset( Wpfnl_Pro_Webhook_Functions::get_all_supported_event()[ $event ] ) ) {
				return MCPHelper::error( 'invalid_webhook', 'Provide either webhook_id (with funnel_id) to test a saved webhook, or a url and a supported event to test settings directly.' );
			}

			$body_type   = isset( $input['body_type'] ) && 'selected' === $input['body_type'] ? 'selected' : 'all';
			$body_fields = [];
			if ( 'selected' === $body_type && ! empty( $input['body_fields'] ) && is_array( $input['body_fields'] ) ) {
				$allowed = Wpfnl_Pro_Webhook_Functions::get_all_body_fields();
				foreach ( $input['body_fields'] as $field_key => $label ) {
					if ( isset( $allowed[ $field_key ] ) ) {
						$body_fields[ sanitize_key( $field_key ) ] = sanitize_text_field( $label );
					}
				}
			}

			$headers = [];
			if ( ! empty( $input['headers'] ) && is_array( $input['headers'] ) ) {
				foreach ( $input['headers'] as $header ) {
					if ( isset( $header['name'], $header['value'] ) ) {
						$headers[] = [
							'name'  => sanitize_text_field( $header['name'] ),
							'value' => sanitize_text_field( $header['value'] ),
						];
					}
				}
			}

			$settings = [
				'id'         => 'test',
				'status'     => 'on',
				'conditions' => $event,
				'request'    => [
					'url'    => $url,
					'method' => 'POST',
					'body'   => [
						'type'   => $body_type,
						'values' => $body_fields,
					],
					'header' => $headers,
				],
			];
		}

		if ( empty( $settings['request']['method'] ) ) {
			$settings['request']['method'] = 'POST';
		}
		if ( empty( $settings['id'] ) ) {
			$settings['id'] = 'test';
		}

		$request_url = Wpfnl_Pro_Webhook_Functions::get_request_url( $settings );
		if ( empty( $request_url ) ) {
			return MCPHelper::error( 'invalid_webhook', 'This webhook has no destination URL configured.' );
		}

		$event      = isset( $settings['conditions'] ) ? $settings['conditions'] : '';
		$payload    = self::buildSampleWebhookPayload( $event, $settings );
		$event_name = isset( $payload['Event Name'] ) ? $payload['Event Name'] : $event;

		$request_args = Wpfnl_Pro_functions::prepare_common_request_args( $settings, 'application/json', $payload, $event_name, home_url( '/' ) );

		$response = wp_remote_request( $request_url, $request_args );
		if ( is_wp_error( $response ) ) {
			return MCPHelper::error( 'webhook_test_failed', $response->get_error_message() );
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$body        = (string) wp_remote_retrieve_body( $response );

		return [
			'tested'         => true,
			'url'            => $request_url,
			'event'          => $event,
			'sample_payload' => $payload,
			'status_code'    => $status_code,
			'success'        => $status_code >= 200 && $status_code < 300,
			'response_body'  => mb_substr( $body, 0, 2000 ),
		];
	}

	/**
	 * Bucket a webhook condition string into the event class family that
	 * would really handle it, mirroring the same substring checks
	 * `class-wpfunnels-pro-webhook-mapping.php` itself uses to route a live
	 * event to `Wpfnl_Pro_Webhook_Checkout`/`_Optin`/`_Orderbump`/`_Offer`.
	 *
	 * @param string $event Webhook condition/event key.
	 * @return string One of checkout|optin|orderbump|offer.
	 */
	private static function classifyWebhookEvent( $event ) {
		if ( 0 === strpos( (string) $event, 'optin_submitted' ) ) {
			return 'optin';
		}
		if ( false !== strpos( (string) $event, 'order_bump' ) ) {
			return 'orderbump';
		}
		if ( false !== strpos( (string) $event, 'upsell' ) || false !== strpos( (string) $event, 'downsell' ) ) {
			return 'offer';
		}
		return 'checkout';
	}

	/**
	 * Synthetic sample value for one of `Wpfnl_Pro_Webhook_Functions::get_all_body_fields()`'s
	 * field keys — used for a "selected fields" test payload. Never real
	 * customer/order data.
	 *
	 * @param string $field_key Field key.
	 * @return int|string
	 */
	private static function sampleFieldValue( $field_key ) {
		$samples = [
			'product_id'       => 101,
			'product_name'     => 'Sample Product',
			'product_quantity' => 1,
			'order_id'         => 999001,
			'order_total'      => 49.99,
			'order_status'     => 'processing',
			'payment_method'   => 'Test Gateway',
			'shipping_method'  => 'Flat Rate',
			'customer_name'    => 'Jane Doe',
			'customer_email'   => 'jane.doe@example.com',
			'customer_phone'   => '+1-555-0100',
			'customer_city'    => 'Springfield',
			'customer_address' => '123 Test Street',
			'first_name'       => 'Jane',
			'last_name'        => 'Doe',
			'email'            => 'jane.doe@example.com',
			'phone'            => '+1-555-0100',
		];
		return isset( $samples[ $field_key ] ) ? $samples[ $field_key ] : '';
	}

	/**
	 * Normalize a webhook record's "selected fields" config into a flat list
	 * of [field_key, output_label] pairs, regardless of which of the two
	 * shapes this codebase uses for it: the real event classes'
	 * `prepare_selected_body_fields()` read
	 * `request.body.values = [ { key: <output label>, value: <field key> }, ... ]`,
	 * while `upsertWebhook()` above (and this file's own MCP-facing schema)
	 * writes `request.body.values = { <field key>: <output label> }`. Testing
	 * a webhook created either way should work.
	 *
	 * @param mixed $values Raw `request.body.values`.
	 * @return array List of ['field_key' => string, 'label' => string].
	 */
	private static function normalizeSelectedWebhookFields( $values ) {
		$pairs = [];
		if ( ! is_array( $values ) ) {
			return $pairs;
		}

		foreach ( $values as $k => $v ) {
			if ( is_array( $v ) && isset( $v['key'], $v['value'] ) ) {
				$pairs[] = [
					'field_key' => $v['value'],
					'label'     => $v['key'],
				];
			} elseif ( is_string( $v ) ) {
				$pairs[] = [
					'field_key' => $k,
					'label'     => $v,
				];
			}
		}

		return $pairs;
	}

	/**
	 * Full "send all fields" sample payload for one event family, using the
	 * exact field key/label strings the matching real event class's
	 * `prepare_all_body_fields()` emits (verified by reading
	 * `Wpfnl_Pro_Webhook_Checkout`/`_Optin`/`_Orderbump`/`_Offer`), populated
	 * with fixed synthetic sample values instead of a real order/opt-in.
	 *
	 * @param string $category One of checkout|optin|orderbump|offer.
	 * @param string $event    Original condition string (used to pick
	 *                         accepted/rejected and upsell/downsell wording).
	 * @return array
	 */
	private static function sampleAllWebhookFields( $category, $event ) {
		$date = date( 'Y-m-d h:i' );

		switch ( $category ) {
			case 'optin':
				return [
					'Date'       => $date,
					'Event Name' => 'After optin form submit',
					'First Name' => 'Jane',
					'Last Name'  => 'Doe',
					'Phone'      => '+1-555-0100',
					'Email'      => 'jane.doe@example.com',
					'Message'    => 'This is a sample test submission.',
					'Website'    => 'https://example.com',
				];

			case 'orderbump':
				$status = false !== strpos( (string) $event, 'rejected' ) ? 'Rejected' : 'Accepted';
				$body   = [
					'Date'             => $date,
					'Event Name'       => 'Order Bump ' . $status,
					'Product ID'       => 101,
					'Product Name'     => 'Sample Product',
					'Product Quantity' => 1,
				];
				if ( 'Accepted' === $status ) {
					$body['Order ID']     = 999001;
					$body['Total Price']  = 49.99;
					$body['Order Status'] = 'processing';
				}
				return $body + [
					'Payment Method'    => 'Test Gateway',
					'Shipping Method'   => 'Flat Rate',
					'Customer Name'     => 'Jane Doe',
					'Customer Phone'    => '+1-555-0100',
					'Customer Email'    => 'jane.doe@example.com',
					'Customer City'     => 'Springfield',
					'Customer Address'  => '123 Test Street',
				];

			case 'offer':
				$offer_type = false !== strpos( (string) $event, 'downsell' ) ? 'Downsell' : 'Upsell';
				$status     = false !== strpos( (string) $event, 'rejected' ) ? 'Rejected' : 'Accepted';
				$body       = [
					'Date'             => $date,
					'Event Name'       => $offer_type . ' ' . $status,
					'Product ID'       => 101,
					'Product Name'     => 'Sample Product',
					'Product Quantity' => 1,
				];
				if ( 'Accepted' === $status ) {
					$body['Order ID']     = 999001;
					$body['Total Price']  = 49.99;
					$body['Order Status'] = 'processing';
				} else {
					$body['Product Price'] = 49.99;
				}
				return $body + [
					'Payment Method'    => 'Test Gateway',
					'Shipping Method'   => 'Flat Rate',
					'Customer Name'     => 'Jane Doe',
					'Customer Phone'    => '+1-555-0100',
					'Customer Email'    => 'jane.doe@example.com',
					'Customer City'     => 'Springfield',
					'Customer Address'  => '123 Test Street',
				];

			case 'checkout':
			default:
				return [
					'Date'             => $date,
					'Event Name'       => 'Checkout Order Placed',
					'Order ID'         => 999001,
					'Order Status'     => 'processing',
					'Order Total'      => 49.99,
					'Payment Method'   => 'Test Gateway',
					'Shipping Method'  => 'Flat Rate',
					'Customer Name'    => 'Jane Doe',
					'Customer Phone'   => '+1-555-0100',
					'Customer Email'   => 'jane.doe@example.com',
					'Customer City'    => 'Springfield',
					'Customer Address' => '123 Test Street',
					'Items'            => [
						[
							'Product ID'       => 101,
							'Product Name'     => 'Sample Product',
							'Product Quantity' => 1,
						],
					],
				];
		}
	}

	/**
	 * Build the synthetic sample payload for a webhook test call, honoring
	 * the webhook's own `body_type` ("all" vs "selected") the same way every
	 * real event class's `prepare_request_body()` does.
	 *
	 * @param string $event    Webhook condition/event key.
	 * @param array  $settings Webhook settings (real or ad-hoc test settings).
	 * @return array
	 */
	private static function buildSampleWebhookPayload( $event, $settings ) {
		$category  = self::classifyWebhookEvent( $event );
		$all_body  = self::sampleAllWebhookFields( $category, $event );
		$body_type = isset( $settings['request']['body']['type'] ) ? $settings['request']['body']['type'] : 'all';

		if ( 'selected' !== $body_type ) {
			return $all_body;
		}

		$selected = self::normalizeSelectedWebhookFields( isset( $settings['request']['body']['values'] ) ? $settings['request']['body']['values'] : [] );
		if ( empty( $selected ) ) {
			return $all_body;
		}

		$body = [ 'Event Name' => isset( $all_body['Event Name'] ) ? $all_body['Event Name'] : '' ];
		foreach ( $selected as $field ) {
			$body[ $field['label'] ] = self::sampleFieldValue( $field['field_key'] );
		}

		return $body;
	}
}
