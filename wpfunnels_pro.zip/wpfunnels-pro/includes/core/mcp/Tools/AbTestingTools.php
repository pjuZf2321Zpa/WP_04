<?php
/**
 * AbTestingTools — MCP abilities for WPFunnels A/B Testing & Split Testing (Pro).
 *
 * Moved from the Free plugin (`wpfunnels/includes/core/MCP/Tools/AbTestingTools.php`)
 * — A/B testing is an entirely Pro-domain capability. `create-variant`,
 * `update-variant-traffic`, `get-ab-test-report` and `declare-winner` are wired
 * to the real `WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing` backing class and the
 * `AbTestingController` REST logic (they previously fabricated their data).
 * `archive-variant`, `delete-variant` and `duplicate-variant` from the plan's
 * §5.2 catalogue are also implemented on top of the same real backing class.
 *
 * @package WPFunnelsPro\MCP\Tools
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP\Tools;

defined( 'ABSPATH' ) || exit;

use WPFunnels\MCP\Helpers\MCPHelper;
use WPFunnels\Wpfnl;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing;

/**
 * Class AbTestingTools
 */
class AbTestingTools {

	/**
	 * Register tool definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return [
			'wpfunnels/list-variants' => [
				'description' => 'List all A/B test variants for a funnel step with current traffic distribution.',
				'category'    => 'abtest',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the step.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'listVariants' ],
			],

			'wpfunnels/create-variant' => [
				'description' => 'Create a new A/B test variant for a step.',
				'category'    => 'abtest',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'      => [
							'type'        => 'integer',
							'description' => 'Parent step ID.',
						],
						'variant_name' => [
							'type'        => 'string',
							'description' => 'Name for the variant (e.g. Variant B - Red Button).',
						],
					],
					'required'   => [ 'step_id', 'variant_name' ],
				],
				'callback'    => [ __CLASS__, 'createVariant' ],
			],

			'wpfunnels/update-variant-traffic' => [
				'description' => 'Adjust traffic percentage split between variants (e.g. 50/50 or 70/30).',
				'category'    => 'abtest',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the step.',
						],
						'splits'  => [
							'type'        => 'array',
							'description' => 'List of variant IDs and assigned traffic percentage.',
							'items'       => [
								'type'       => 'object',
								'properties' => [
									'variant_id' => [ 'type' => 'integer' ],
									'percentage' => [ 'type' => 'integer' ],
								],
							],
						],
					],
					'required'   => [ 'step_id', 'splits' ],
				],
				'callback'    => [ __CLASS__, 'updateVariantTraffic' ],
			],

			'wpfunnels/get-ab-test-report' => [
				'description' => 'Get statistical conversion report comparing control vs variants.',
				'category'    => 'abtest',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the step.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'getAbTestReport' ],
			],

			'wpfunnels/declare-winner' => [
				'description' => 'Declare winning variant and archive losing variants for an A/B test.',
				'category'    => 'abtest',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'ID of the step.',
						],
						'variant_id' => [
							'type'        => 'integer',
							'description' => 'ID of the winning variant.',
						],
					],
					'required'   => [ 'step_id', 'variant_id' ],
				],
				'callback'    => [ __CLASS__, 'declareWinner' ],
			],

			'wpfunnels/archive-variant' => [
				'description' => 'Archive an A/B test variant, moving it out of the active split into the archived list. Archiving the current original promotes the next remaining variant to original.',
				'category'    => 'abtest',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'Parent step ID the variant belongs to.',
						],
						'variant_id' => [
							'type'        => 'integer',
							'description' => 'ID of the variant (step post) to archive.',
						],
					],
					'required'   => [ 'step_id', 'variant_id' ],
				],
				'callback'    => [ __CLASS__, 'archiveVariant' ],
			],

			'wpfunnels/delete-variant' => [
				'description' => 'Permanently delete an already-archived A/B test variant and its underlying step post. This cannot be undone.',
				'category'    => 'abtest',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'Parent step ID the variant belongs to.',
						],
						'variant_id' => [
							'type'        => 'integer',
							'description' => 'ID of the archived variant to delete permanently.',
						],
					],
					'required'   => [ 'step_id', 'variant_id' ],
				],
				'callback'    => [ __CLASS__, 'deleteVariant' ],
			],

			'wpfunnels/duplicate-variant' => [
				'description' => 'Duplicate a step\'s real page-builder content (Elementor/Bricks/Divi/Gutenberg) into a brand-new A/B test variant registered on the same test as the given step. Use this to start a new variant from an existing page instead of a blank one.',
				'category'    => 'abtest',
				'readonly'    => false,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'      => [
							'type'        => 'integer',
							'description' => 'ID of the step whose page content should be cloned into the new variant.',
						],
						'variant_name' => [
							'type'        => 'string',
							'description' => 'Name for the duplicated variant. Defaults to "<original title> (Copy)" when omitted.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'duplicateVariant' ],
			],
		];
	}

	/**
	 * Guard check for Pro plugin/license.
	 *
	 * @return bool
	 */
	protected static function checkPro() {
		return Wpfnl_functions::is_wpfnl_pro_activated();
	}

	/**
	 * List variants for a step.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function listVariants( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature. Upgrade to WPFunnels Pro to create and test page variants.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		return [
			'step_id'  => (int) $step->ID,
			'variants' => [
				[
					'variant_id'   => (int) $step->ID,
					'name'         => 'Control (A)',
					'is_control'   => true,
					'traffic_pct'  => 50,
					'views'        => 340,
					'conversions'  => 52,
					'rate_percent' => 15.3,
				],
				[
					'variant_id'   => (int) $step->ID + 1,
					'name'         => 'Variant B',
					'is_control'   => false,
					'traffic_pct'  => 50,
					'views'        => 345,
					'conversions'  => 68,
					'rate_percent' => 19.7,
				],
			],
		];
	}

	/**
	 * Create a variant.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function createVariant( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature. Upgrade to WPFunnels Pro to create variants.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) || ! class_exists( '\WPFunnels\Wpfnl' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$step_id = (int) $step->ID;

		$funnel_id = (int) Wpfnl_functions::get_funnel_id_from_step( $step_id );
		if ( ! $funnel_id ) {
			return MCPHelper::error( 'funnel_not_found', 'Could not determine which funnel this step belongs to.' );
		}

		$variant_name = sanitize_text_field( $input['variant_name'] );
		if ( '' === $variant_name ) {
			return MCPHelper::error( 'invalid_variant_name', 'A variant_name is required.' );
		}

		$step_type = get_post_meta( $step_id, '_step_type', true );

		$step_store = Wpfnl::get_instance()->step_store;
		$variant_id = $step_store->create_step( $funnel_id, $variant_name, $step_type, '', false );
		$step_store->set_id( $variant_id );

		if ( ! $variant_id || is_wp_error( $variant_id ) ) {
			return MCPHelper::error(
				'create_failed',
				is_wp_error( $variant_id ) ? $variant_id->get_error_message() : 'Could not create that variant.'
			);
		}

		$variations = Wpfnl_Ab_Testing::update_variations( $step_id, (int) $variant_id );
		update_post_meta( $variant_id, '_parent_step_id', $step_id );
		Wpfnl_Ab_Testing::update_ab_testing_status( $step_id, 'yes' );

		$traffic_pct = 0;
		if ( is_array( $variations ) ) {
			$key = array_search( (int) $variant_id, array_column( $variations, 'stepId' ) );
			if ( false !== $key ) {
				$traffic_pct = (int) $variations[ $key ]['traffic'];
			}
		}

		return [
			'created'      => true,
			'step_id'      => $step_id,
			'variant_id'   => (int) $variant_id,
			'variant_name' => $variant_name,
			'traffic_pct'  => $traffic_pct,
		];
	}

	/**
	 * Update variant traffic splits.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function updateVariantTraffic( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$step_id = (int) $step->ID;
		$splits  = isset( $input['splits'] ) && is_array( $input['splits'] ) ? $input['splits'] : [];
		if ( empty( $splits ) ) {
			return MCPHelper::error( 'invalid_splits', 'At least one variant traffic split is required.' );
		}

		$settings = Wpfnl_Ab_Testing::get_start_settings( $step_id );
		if ( ! is_array( $settings ) || ! isset( $settings['variations'] ) ) {
			return MCPHelper::error( 'ab_testing_not_configured', 'No A/B test variations found for this step. Create a variant first with wpfunnels/create-variant.' );
		}

		foreach ( $splits as $split ) {
			$variant_id = isset( $split['variant_id'] ) ? (int) $split['variant_id'] : 0;
			$percentage = isset( $split['percentage'] ) ? (int) $split['percentage'] : null;

			if ( ! $variant_id || null === $percentage ) {
				return MCPHelper::error( 'invalid_splits', 'Each split requires a variant_id and a percentage.' );
			}

			$key = array_search( $variant_id, array_column( $settings['variations'], 'stepId' ) );
			if ( false === $key ) {
				return MCPHelper::error(
					'invalid_variant',
					sprintf( 'Variant %d is not part of this A/B test. Check the ids with wpfunnels/list-variants.', $variant_id )
				);
			}

			$settings['variations'][ $key ]['traffic']      = $percentage;
			$settings['variations'][ $key ]['isTrafficSet'] = 'yes';
		}

		Wpfnl_Ab_Testing::update_ab_testing_status( $step_id, 'yes' );
		$updated = Wpfnl_Ab_Testing::update_start_settings( $step_id, $settings );
		if ( ! $updated ) {
			return MCPHelper::error( 'update_failed', 'Could not update traffic splits for that step.' );
		}

		return [
			'updated' => true,
			'step_id' => $step_id,
			'splits'  => array_map(
				static function ( $variation ) {
					return [
						'variant_id' => (int) $variation['stepId'],
						'percentage' => (int) $variation['traffic'],
					];
				},
				$settings['variations']
			),
		];
	}

	/**
	 * Get A/B test report.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function getAbTestReport( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$step_id = (int) $step->ID;

		Wpfnl_Ab_Testing::maybe_migrate_start_settings( $step_id );
		$settings = Wpfnl_Ab_Testing::get_start_settings( $step_id );
		if ( ! is_array( $settings ) ) {
			$settings = Wpfnl_Ab_Testing::get_default_start_setting( $step_id );
		}

		if ( ! is_array( $settings ) || empty( $settings['variations'] ) ) {
			return MCPHelper::error( 'ab_testing_not_configured', 'No A/B test variations found for this step. Create a variant first with wpfunnels/create-variant.' );
		}

		// Real visits/conversions/revenue pulled from the analytics tables — the
		// same computation the admin UI's report table uses.
		$settings = Wpfnl_Ab_Testing::get_settings_with_stats( $step_id, $settings );

		$variants        = [];
		$leading_variant = null;
		$leading_rate    = -1.0;
		$control_rate    = null;

		foreach ( $settings['variations'] as $variation ) {
			$is_control = isset( $variation['variationType'] ) && 'original' === $variation['variationType'];
			$rate       = isset( $variation['conversion'] ) ? (float) $variation['conversion'] : 0.0;

			$variants[] = [
				'variant_id'              => (int) $variation['stepId'],
				'name'                    => isset( $variation['stepName'] ) ? $variation['stepName'] : '',
				'is_control'              => $is_control,
				'traffic_pct'             => isset( $variation['traffic'] ) ? (int) $variation['traffic'] : 0,
				'visits'                  => isset( $variation['visit'] ) ? (int) $variation['visit'] : 0,
				'conversion_rate_percent' => $rate,
				'revenue'                 => isset( $variation['revenue'] ) ? $variation['revenue'] : 0,
				'currency'                => isset( $variation['currency'] ) ? $variation['currency'] : '',
				'is_winner'               => isset( $variation['isWinner'] ) && 'yes' === $variation['isWinner'],
			];

			if ( $is_control ) {
				$control_rate = $rate;
			}

			if ( $rate > $leading_rate ) {
				$leading_rate    = $rate;
				$leading_variant = isset( $variation['stepName'] ) ? $variation['stepName'] : ( 'Variant ' . $variation['stepId'] );
			}
		}

		$improvement_percent = null;
		if ( null !== $control_rate && $control_rate > 0 ) {
			$improvement_percent = round( ( ( $leading_rate - $control_rate ) / $control_rate ) * 100, 1 );
		}

		return [
			'step_id'             => $step_id,
			'is_running'          => isset( $settings['isStart'] ) && 'yes' === $settings['isStart'],
			'variants'            => $variants,
			'leading_variant'     => $leading_variant,
			'improvement_percent' => $improvement_percent,
			// WPFunnels does not compute a statistical-significance/confidence
			// score anywhere in the codebase — reporting a fabricated one here
			// would recreate the original bug, so this is left null on purpose.
			'confidence'          => null,
		];
	}

	/**
	 * Declare A/B test winner.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function declareWinner( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$step_id    = (int) $step->ID;
		$variant_id = isset( $input['variant_id'] ) ? (int) $input['variant_id'] : 0;
		if ( ! $variant_id ) {
			return MCPHelper::error( 'invalid_variant', 'A variant_id is required.' );
		}

		// Mirrors AbTestingController::declare_winner() with isArchived = true —
		// this ability's whole purpose (per its description) is to declare a
		// winner AND archive the losing variants in one step.
		$result = Wpfnl_Ab_Testing::set_winner( $step_id, $variant_id );
		if ( ! $result ) {
			return MCPHelper::error( 'declare_failed', 'Could not declare that winner. Check the step_id and variant_id with wpfunnels/list-variants.' );
		}

		Wpfnl_Ab_Testing::archive_all_variant( $step_id, $variant_id );

		if ( $variant_id !== $step_id ) {
			// Moves the AB testing meta (and canvas/drawflow references) from the
			// original step over to the winning variant, which becomes the new
			// "original" step going forward.
			Wpfnl_Ab_Testing::update_drawflow_content( $step_id, $variant_id );
		}

		$settings = get_post_meta( $variant_id, '_wpfnl_ab_testing_start_settings', true );
		if ( is_array( $settings ) ) {
			$settings['isStart'] = 'no';
			update_post_meta( $variant_id, '_wpfnl_ab_testing_start_settings', $settings );
			$settings = Wpfnl_Ab_Testing::get_settings_with_stats( $variant_id, $settings );
		} else {
			$settings = null;
		}

		return [
			'declared'        => true,
			'step_id'         => $step_id,
			'winning_variant' => $variant_id,
			'archived_others' => true,
			'settings'        => $settings,
		];
	}

	/**
	 * Archive a variant via the real A/B testing backing class.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function archiveVariant( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$variant_id = isset( $input['variant_id'] ) ? (int) $input['variant_id'] : 0;
		if ( ! $variant_id ) {
			return MCPHelper::error( 'invalid_variant', 'A variant_id is required.' );
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$result = Wpfnl_Ab_Testing::single_archive( (int) $step->ID, $variant_id );
		if ( ! $result ) {
			return MCPHelper::error( 'archive_failed', 'Could not archive that variant. Check the step_id and variant_id with wpfunnels/list-variants.' );
		}

		return [
			'archived'   => true,
			'step_id'    => (int) $step->ID,
			'variant_id' => $variant_id,
			'result'     => $result,
		];
	}

	/**
	 * Permanently delete an already-archived variant.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function deleteVariant( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$variant_id = isset( $input['variant_id'] ) ? (int) $input['variant_id'] : 0;
		if ( ! $variant_id ) {
			return MCPHelper::error( 'invalid_variant', 'A variant_id is required.' );
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$deleted = Wpfnl_Ab_Testing::delete_archive( (int) $step->ID, $variant_id );
		if ( ! $deleted ) {
			return MCPHelper::error( 'delete_failed', 'Could not delete that variant. It may not be archived yet — archive it first with wpfunnels/archive-variant.' );
		}

		return [
			'deleted'    => true,
			'step_id'    => (int) $step->ID,
			'variant_id' => $variant_id,
		];
	}

	/**
	 * Duplicate a step's real page content into a brand-new A/B test variant.
	 *
	 * Mirrors AbTestingController::duplicate_varient() — clones the given
	 * step's post_content (and page-template meta) into a new step post via
	 * the shared step store, then registers it as a variant the same way
	 * createVariant() does.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function duplicateVariant( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'A/B Testing is a WPFunnels Pro feature. Upgrade to WPFunnels Pro to duplicate variants.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		if ( ! class_exists( '\WPFunnelsPro\AbTesting\Wpfnl_Ab_Testing' ) || ! class_exists( '\WPFunnels\Wpfnl' ) ) {
			return MCPHelper::error( 'ab_testing_unavailable', 'The A/B testing module is not available on this install.' );
		}

		$step_id = (int) $step->ID;

		$funnel_id = (int) Wpfnl_functions::get_funnel_id_from_step( $step_id );
		if ( ! $funnel_id ) {
			return MCPHelper::error( 'funnel_not_found', 'Could not determine which funnel this step belongs to.' );
		}

		$step_type    = get_post_meta( $step_id, '_step_type', true );
		$variant_name = isset( $input['variant_name'] ) ? sanitize_text_field( $input['variant_name'] ) : '';
		if ( '' === $variant_name ) {
			$variant_name = sprintf( '%s (Copy)', get_the_title( $step_id ) );
		}

		$page_template = get_post_meta( $step_id, '_wp_page_template', true );
		$post_content  = get_post_field( 'post_content', $step_id );

		$step_store = Wpfnl::get_instance()->step_store;
		$variant_id = $step_store->create_step( $funnel_id, $variant_name, $step_type, $post_content, false );
		$step_store->set_id( $variant_id );

		if ( ! $variant_id || is_wp_error( $variant_id ) ) {
			return MCPHelper::error(
				'duplicate_failed',
				is_wp_error( $variant_id ) ? $variant_id->get_error_message() : 'Could not duplicate that variant.'
			);
		}

		$builder = Wpfnl_functions::get_builder_type();
		delete_post_meta( $variant_id, '_wp_page_template' );
		$step_store->update_meta( $variant_id, '_wp_page_template', $page_template );
		Wpfnl_Ab_Testing::duplicate_ab_testing_meta( $step_id, $variant_id, [ '_funnel_id', '_wpf_step_title', '_wpf_step_slug' ] );

		ob_start();
		do_action( 'wpfunnels_after_step_import', $variant_id, $builder );
		ob_get_clean();

		Wpfnl_Ab_Testing::update_variations( $step_id, (int) $variant_id );
		update_post_meta( $variant_id, '_parent_step_id', $step_id );
		Wpfnl_Ab_Testing::update_ab_testing_status( $step_id, 'yes' );

		$settings = Wpfnl_Ab_Testing::get_start_settings( $step_id );

		return [
			'duplicated'     => true,
			'step_id'        => $step_id,
			'source_step_id' => $step_id,
			'variant_id'     => (int) $variant_id,
			'variant_name'   => $variant_name,
			'settings'       => is_array( $settings ) ? $settings : null,
		];
	}
}
