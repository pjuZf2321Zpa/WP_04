<?php
/**
 * CheckoutFieldTools — MCP abilities for WPFunnels Pro custom checkout fields.
 *
 * `list-checkout-fields` and `upsert-checkout-field` are moved unchanged (aside
 * from the namespace and an added Pro guard) from the Free plugin's
 * `Tools/CheckoutTools.php`, which mixed this Pro-only domain with Free
 * checkout-settings tools. `delete-checkout-field` (plan §5.2) is added here,
 * operating on the same `_wpfnl_custom_checkout_fields` step-meta model the two
 * moved tools already use.
 *
 * Note: this simplified per-field meta model is distinct from the fuller
 * billing/shipping/additional checkout-fields editor in
 * `admin/modules/steps/checkout/checkout-fields/wpfnl-checkout-fields.php`
 * (`CheckoutFields` class), which stores its data under the
 * `wpfnl_checkout_{billing,shipping,additional}_fields` post-meta keys
 * (confirmed by reading its `wpfn_show_checkout_*_fields()` / `wpfn_add_*` /
 * `wpfn_update_*` methods — NOT the `wpfnl_wc_{billing,shipping,additional}_fields`
 * keys that its `load_scripts()` reads purely to localize initial JS state).
 * That richer, section-based model is now covered below by
 * `list-checkout-field-sections`, `add-checkout-field`, `update-checkout-field`,
 * `remove-checkout-field`, `toggle-checkout-field-enabled`,
 * `toggle-checkout-field-required`, `reorder-checkout-fields`, and
 * `restore-default-checkout-fields`. Those tools delegate to the real
 * `CheckoutFields` methods rather than reimplementing their storage format, so
 * the two models stay independent: the three original tools above keep using
 * `_wpfnl_custom_checkout_fields` and are untouched.
 *
 * @package WPFunnelsPro\MCP\Tools
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP\Tools;

defined( 'ABSPATH' ) || exit;

use WPFunnels\MCP\Helpers\MCPHelper;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Admin\Modules\Steps\Checkout\CheckoutFields as CheckoutFieldsEditor;

/**
 * Class CheckoutFieldTools
 */
class CheckoutFieldTools {

	/**
	 * Register tool definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return [
			'wpfunnels/list-checkout-fields' => [
				'description' => 'List custom checkout fields (VAT number, delivery date, custom select) configured on a checkout step.',
				'category'    => 'checkout',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'listCheckoutFields' ],
			],

			'wpfunnels/upsert-checkout-field' => [
				'description' => 'Add or update a custom checkout field on a checkout step.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'field_name' => [
							'type'        => 'string',
							'description' => 'Field identifier key.',
						],
						'label'      => [
							'type'        => 'string',
							'description' => 'Field label text shown to customer.',
						],
						'type'       => [
							'type'        => 'string',
							'enum'        => [ 'text', 'textarea', 'select', 'checkbox', 'date' ],
							'description' => 'Field input type.',
						],
						'required'   => [
							'type'        => 'boolean',
							'description' => 'Whether input is mandatory.',
						],
					],
					'required'   => [ 'step_id', 'field_name', 'label' ],
				],
				'callback'    => [ __CLASS__, 'upsertCheckoutField' ],
			],

			'wpfunnels/delete-checkout-field' => [
				'description' => 'Delete a custom checkout field from a checkout step.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'field_name' => [
							'type'        => 'string',
							'description' => 'Field identifier key to remove.',
						],
					],
					'required'   => [ 'step_id', 'field_name' ],
				],
				'callback'    => [ __CLASS__, 'deleteCheckoutField' ],
			],

			'wpfunnels/list-checkout-field-sections' => [
				'description' => 'List the real billing, shipping, and additional (order) checkout fields configured for a step in the Checkout Fields editor — WooCommerce\'s default fields plus any custom fields added there, each with its enabled/required/show-on-order-page state. This is the richer, section-based field model behind the Checkout Fields editor UI; distinct from wpfunnels/list-checkout-fields.',
				'category'    => 'checkout',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'listCheckoutFieldSections' ],
			],

			'wpfunnels/add-checkout-field' => [
				'description' => 'Add a brand-new custom field to the billing, shipping, or additional (order) section of the Checkout Fields editor. The field name must be unique within its section and contain no whitespace. Use wpfunnels/list-checkout-field-sections first to see existing field names.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'            => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'section'            => [
							'type'        => 'string',
							'enum'        => [ 'billing', 'shipping', 'additional' ],
							'description' => 'Checkout field section to add the field to.',
						],
						'name'               => [
							'type'        => 'string',
							'description' => 'Unique field identifier key within the section. Must not contain whitespace.',
						],
						'label'              => [
							'type'        => 'string',
							'description' => 'Field label text shown to the customer.',
						],
						'field_type'         => [
							'type'        => 'string',
							'enum'        => [ 'text', 'password', 'email', 'phone', 'select', 'textarea', 'radio' ],
							'description' => 'Field input type. Defaults to "text".',
						],
						'placeholder'        => [
							'type'        => 'string',
							'description' => 'Placeholder text shown inside the input.',
						],
						'default_value'      => [
							'type'        => 'string',
							'description' => 'Default value pre-filled into the field.',
						],
						'required'           => [
							'type'        => 'boolean',
							'description' => 'Whether the field is mandatory. Defaults to false.',
						],
						'enabled'            => [
							'type'        => 'boolean',
							'description' => 'Whether the field is enabled/shown at checkout. Defaults to true.',
						],
						'show_on_order_page' => [
							'type'        => 'boolean',
							'description' => 'Whether the field also shows on the order-received/order-details page. Defaults to true.',
						],
						'collapsible'        => [
							'type'        => 'boolean',
							'description' => 'Whether the field is rendered inside a collapsible section.',
						],
						'validate'           => [
							'type'        => 'string',
							'description' => 'Optional WooCommerce validation rule to apply (e.g. "email", "phone", "postcode").',
						],
						'options'            => [
							'type'        => 'array',
							'items'       => [ 'type' => 'string' ],
							'description' => 'Option values for "select" or "radio" field types.',
						],
					],
					'required'   => [ 'step_id', 'section', 'name', 'label' ],
				],
				'callback'    => [ __CLASS__, 'addCheckoutField' ],
			],

			'wpfunnels/update-checkout-field' => [
				'description' => 'Replace the full definition of an existing field (default WooCommerce field or previously-added custom field) in a Checkout Fields editor section. This fully replaces the field\'s stored configuration (its display order/priority is preserved) — omitted flags are treated as false/off, so pass every property you want to keep. Use wpfunnels/list-checkout-field-sections to read the field\'s current values first.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'            => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'section'            => [
							'type'        => 'string',
							'enum'        => [ 'billing', 'shipping', 'additional' ],
							'description' => 'Checkout field section the field belongs to.',
						],
						'name'               => [
							'type'        => 'string',
							'description' => 'Field identifier key to update (e.g. "billing_email", or a custom field\'s name).',
						],
						'label'              => [
							'type'        => 'string',
							'description' => 'Field label text shown to the customer.',
						],
						'field_type'         => [
							'type'        => 'string',
							'enum'        => [ 'text', 'password', 'email', 'phone', 'select', 'textarea', 'radio' ],
							'description' => 'Field input type. Defaults to "text".',
						],
						'placeholder'        => [
							'type'        => 'string',
							'description' => 'Placeholder text shown inside the input.',
						],
						'default_value'      => [
							'type'        => 'string',
							'description' => 'Default value pre-filled into the field.',
						],
						'required'           => [
							'type'        => 'boolean',
							'description' => 'Whether the field is mandatory.',
						],
						'enabled'            => [
							'type'        => 'boolean',
							'description' => 'Whether the field is enabled/shown at checkout.',
						],
						'show_on_order_page' => [
							'type'        => 'boolean',
							'description' => 'Whether the field also shows on the order-received/order-details page.',
						],
						'collapsible'        => [
							'type'        => 'boolean',
							'description' => 'Whether the field is rendered inside a collapsible section.',
						],
						'validate'           => [
							'type'        => 'string',
							'description' => 'Optional WooCommerce validation rule to apply (e.g. "email", "phone", "postcode").',
						],
						'options'            => [
							'type'        => 'array',
							'items'       => [ 'type' => 'string' ],
							'description' => 'Option values for "select" or "radio" field types.',
						],
					],
					'required'   => [ 'step_id', 'section', 'name', 'label', 'required', 'enabled', 'show_on_order_page' ],
				],
				'callback'    => [ __CLASS__, 'updateCheckoutField' ],
			],

			'wpfunnels/remove-checkout-field' => [
				'description' => 'Remove a field (default or custom) from a billing, shipping, or additional Checkout Fields editor section.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'section'    => [
							'type'        => 'string',
							'enum'        => [ 'billing', 'shipping', 'additional' ],
							'description' => 'Checkout field section the field belongs to.',
						],
						'field_name' => [
							'type'        => 'string',
							'description' => 'Field identifier key to remove.',
						],
					],
					'required'   => [ 'step_id', 'section', 'field_name' ],
				],
				'callback'    => [ __CLASS__, 'removeCheckoutField' ],
			],

			'wpfunnels/toggle-checkout-field-enabled' => [
				'description' => 'Toggle whether a field in a Checkout Fields editor section is enabled/shown at checkout.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'section'    => [
							'type'        => 'string',
							'enum'        => [ 'billing', 'shipping', 'additional' ],
							'description' => 'Checkout field section the field belongs to.',
						],
						'field_name' => [
							'type'        => 'string',
							'description' => 'Field identifier key to toggle.',
						],
					],
					'required'   => [ 'step_id', 'section', 'field_name' ],
				],
				'callback'    => [ __CLASS__, 'toggleCheckoutFieldEnabled' ],
			],

			'wpfunnels/toggle-checkout-field-required' => [
				'description' => 'Toggle whether a field in a Checkout Fields editor section is required.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'    => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'section'    => [
							'type'        => 'string',
							'enum'        => [ 'billing', 'shipping', 'additional' ],
							'description' => 'Checkout field section the field belongs to.',
						],
						'field_name' => [
							'type'        => 'string',
							'description' => 'Field identifier key to toggle.',
						],
					],
					'required'   => [ 'step_id', 'section', 'field_name' ],
				],
				'callback'    => [ __CLASS__, 'toggleCheckoutFieldRequired' ],
			],

			'wpfunnels/reorder-checkout-fields' => [
				'description' => 'Reorder the fields within one billing/shipping/additional section of the Checkout Fields editor. The order list must include every field currently in that section (from wpfunnels/list-checkout-field-sections) — any field name left out is dropped from the section.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
						'section' => [
							'type'        => 'string',
							'enum'        => [ 'billing', 'shipping', 'additional' ],
							'description' => 'Checkout field section to reorder.',
						],
						'order'   => [
							'type'        => 'array',
							'items'       => [ 'type' => 'string' ],
							'minItems'    => 1,
							'description' => 'Field identifier keys in the desired display order. Must exactly match the full current set of field names in the section.',
						],
					],
					'required'   => [ 'step_id', 'section', 'order' ],
				],
				'callback'    => [ __CLASS__, 'reorderCheckoutFields' ],
			],

			'wpfunnels/restore-default-checkout-fields' => [
				'description' => 'Restore the billing, shipping, and additional Checkout Fields editor sections to WooCommerce\'s defaults, discarding all customizations and custom fields added there for this step.',
				'category'    => 'checkout',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the checkout step.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'restoreDefaultCheckoutFields' ],
			],
		];
	}

	/**
	 * Guard check for Pro plugin/license.
	 *
	 * @return bool
	 */
	protected static function checkPro() {
		return Wpfnl_functions::is_wpfnl_pro_activated();
	}

	/**
	 * List checkout fields.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function listCheckoutFields( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Custom checkout fields are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$fields = get_post_meta( $step->ID, '_wpfnl_custom_checkout_fields', true ) ?: [];

		return [
			'step_id' => (int) $step->ID,
			'fields'  => $fields,
		];
	}

	/**
	 * Upsert custom checkout field.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function upsertCheckoutField( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Custom checkout fields are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$fields = get_post_meta( $step->ID, '_wpfnl_custom_checkout_fields', true ) ?: [];
		$name   = sanitize_text_field( $input['field_name'] );

		$fields[ $name ] = [
			'name'     => $name,
			'label'    => sanitize_text_field( $input['label'] ),
			'type'     => isset( $input['type'] ) ? sanitize_text_field( $input['type'] ) : 'text',
			'required' => ! empty( $input['required'] ),
		];

		update_post_meta( $step->ID, '_wpfnl_custom_checkout_fields', $fields );

		return [
			'upserted'   => true,
			'step_id'    => (int) $step->ID,
			'field_name' => $name,
		];
	}

	/**
	 * Delete a custom checkout field.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function deleteCheckoutField( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Custom checkout fields are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$name   = isset( $input['field_name'] ) ? sanitize_text_field( $input['field_name'] ) : '';
		$fields = get_post_meta( $step->ID, '_wpfnl_custom_checkout_fields', true ) ?: [];

		if ( ! $name || ! isset( $fields[ $name ] ) ) {
			return MCPHelper::error(
				'field_not_found',
				sprintf( 'No custom checkout field named "%1$s" on step %2$d. Use wpfunnels/list-checkout-fields to see valid names.', $name, (int) $step->ID )
			);
		}

		unset( $fields[ $name ] );
		update_post_meta( $step->ID, '_wpfnl_custom_checkout_fields', $fields );

		return [
			'deleted'    => true,
			'step_id'    => (int) $step->ID,
			'field_name' => $name,
		];
	}

	/**
	 * Sections supported by the real Checkout Fields editor.
	 *
	 * @var string[]
	 */
	private static $sections = [ 'billing', 'shipping', 'additional' ];

	/**
	 * Validate a section slug.
	 *
	 * @param mixed $section Candidate section value.
	 * @return string|\WP_Error
	 */
	protected static function requireSection( $section ) {
		if ( ! in_array( $section, self::$sections, true ) ) {
			return MCPHelper::error(
				'invalid_section',
				sprintf( 'Invalid checkout field section "%1$s". Must be one of: billing, shipping, additional.', is_scalar( $section ) ? $section : gettype( $section ) )
			);
		}
		return $section;
	}

	/**
	 * Read the current field data for one section, via the real editor's own
	 * accessor (falls back to WooCommerce defaults just like the admin UI).
	 *
	 * @param CheckoutFieldsEditor $editor  Editor instance.
	 * @param int                  $step_id Step post id.
	 * @param string               $section Section slug.
	 * @return array
	 */
	protected static function getSectionFieldData( CheckoutFieldsEditor $editor, $step_id, $section ) {
		$all = $editor->wpfn_show_checkout_fields( [ 'step_id' => $step_id ] );
		return isset( $all[ $section . '_data' ] ) && is_array( $all[ $section . '_data' ] ) ? $all[ $section . '_data' ] : [];
	}

	/**
	 * List billing/shipping/additional checkout field sections for a step.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function listCheckoutFieldSections( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$editor = new CheckoutFieldsEditor();
		$data   = $editor->wpfn_show_checkout_fields( [ 'step_id' => $step->ID ] );

		return [
			'step_id'             => (int) $step->ID,
			'billing_fields'      => isset( $data['billing_data'] ) ? $data['billing_data'] : [],
			'shipping_fields'     => isset( $data['shipping_data'] ) ? $data['shipping_data'] : [],
			'additional_fields'   => isset( $data['additional_data'] ) ? $data['additional_data'] : [],
			'additional_settings' => isset( $data['settings'] ) ? $data['settings'] : null,
		];
	}

	/**
	 * Build the shared field payload fragment common to add/update.
	 *
	 * @param array $input Tool input.
	 * @return array
	 */
	protected static function buildFieldPayload( $input ) {
		$payload = [
			'sectionType'       => $input['section'],
			'selectedFieldType' => isset( $input['field_type'] ) ? sanitize_text_field( $input['field_type'] ) : 'text',
			'label'             => sanitize_text_field( $input['label'] ),
			'name'              => trim( sanitize_text_field( $input['name'] ) ),
			'placeholder'       => isset( $input['placeholder'] ) ? sanitize_text_field( $input['placeholder'] ) : '',
			'defaultValue'      => isset( $input['default_value'] ) ? sanitize_text_field( $input['default_value'] ) : '',
		];

		if ( ! empty( $input['validate'] ) ) {
			$payload['validate'] = sanitize_text_field( $input['validate'] );
		}

		if ( ! empty( $input['options'] ) && is_array( $input['options'] ) ) {
			$payload['options'] = array_map( 'sanitize_text_field', $input['options'] );
		}

		return $payload;
	}

	/**
	 * Add a new field to a Checkout Fields editor section.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function addCheckoutField( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$section = self::requireSection( isset( $input['section'] ) ? $input['section'] : null );
		if ( is_wp_error( $section ) ) {
			return $section;
		}

		$payload             = self::buildFieldPayload( $input );
		$payload['stepID']   = $step->ID;
		$payload['isRequired']         = ! empty( $input['required'] ) ? 'true' : 'false';
		$payload['isEnabled']          = ! array_key_exists( 'enabled', $input ) || ! empty( $input['enabled'] ) ? 'true' : 'false';
		$payload['isDisplayOrderPage'] = ! array_key_exists( 'show_on_order_page', $input ) || ! empty( $input['show_on_order_page'] ) ? 'true' : 'false';
		if ( array_key_exists( 'collapsible', $input ) ) {
			$payload['isCollapsible'] = ! empty( $input['collapsible'] ) ? 'true' : 'false';
		}

		$editor = new CheckoutFieldsEditor();
		$result = $editor->wpfn_add_checkout_fields( $payload );

		if ( ! isset( $result['status'] ) || 'success' !== $result['status'] ) {
			return MCPHelper::error(
				'add_checkout_field_failed',
				is_string( $result['data'] ?? null ) ? $result['data'] : 'Failed to add the checkout field.'
			);
		}

		return [
			'added'      => true,
			'step_id'    => (int) $step->ID,
			'section'    => $section,
			'field_name' => $payload['name'],
		];
	}

	/**
	 * Replace the full definition of an existing field in a Checkout Fields
	 * editor section (its stored display priority is preserved by the
	 * underlying editor).
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function updateCheckoutField( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$section = self::requireSection( isset( $input['section'] ) ? $input['section'] : null );
		if ( is_wp_error( $section ) ) {
			return $section;
		}

		$payload           = self::buildFieldPayload( $input );
		$payload['stepID'] = $step->ID;
		$payload['isRequired'] = ! empty( $input['required'] ) ? 1 : 0;
		$payload['isEnabled']  = ! empty( $input['enabled'] ) ? 1 : 0;
		$payload['isShow']     = ! empty( $input['show_on_order_page'] ) ? 1 : 0;
		if ( array_key_exists( 'collapsible', $input ) ) {
			$payload['isCollapsible'] = ! empty( $input['collapsible'] ) ? 1 : 0;
		}

		$editor = new CheckoutFieldsEditor();
		$result = $editor->wpfn_update_checkout_fields( $payload );

		if ( ! isset( $result['status'] ) || 'success' !== $result['status'] ) {
			return MCPHelper::error(
				'update_checkout_field_failed',
				is_string( $result['data'] ?? null ) ? $result['data'] : 'Failed to update the checkout field.'
			);
		}

		return [
			'updated'    => true,
			'step_id'    => (int) $step->ID,
			'section'    => $section,
			'field_name' => $payload['name'],
		];
	}

	/**
	 * Remove a field from a Checkout Fields editor section.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function removeCheckoutField( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$section = self::requireSection( isset( $input['section'] ) ? $input['section'] : null );
		if ( is_wp_error( $section ) ) {
			return $section;
		}

		$field_name = isset( $input['field_name'] ) ? sanitize_text_field( $input['field_name'] ) : '';
		$editor     = new CheckoutFieldsEditor();
		$current    = self::getSectionFieldData( $editor, $step->ID, $section );

		if ( '' === $field_name || ! isset( $current[ $field_name ] ) ) {
			return MCPHelper::error(
				'field_not_found',
				sprintf( 'No "%1$s" field named "%2$s" on step %3$d. Use wpfunnels/list-checkout-field-sections to see valid names.', $section, $field_name, (int) $step->ID )
			);
		}

		$editor->wpfn_delete_field(
			[
				'stepID'  => $step->ID,
				'section' => $section,
				'index'   => $field_name,
			]
		);

		return [
			'deleted'    => true,
			'step_id'    => (int) $step->ID,
			'section'    => $section,
			'field_name' => $field_name,
		];
	}

	/**
	 * Toggle a field's enabled state in a Checkout Fields editor section.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function toggleCheckoutFieldEnabled( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$section = self::requireSection( isset( $input['section'] ) ? $input['section'] : null );
		if ( is_wp_error( $section ) ) {
			return $section;
		}

		$field_name = isset( $input['field_name'] ) ? sanitize_text_field( $input['field_name'] ) : '';
		$editor     = new CheckoutFieldsEditor();
		$current    = self::getSectionFieldData( $editor, $step->ID, $section );

		if ( '' === $field_name || ! isset( $current[ $field_name ] ) ) {
			return MCPHelper::error(
				'field_not_found',
				sprintf( 'No "%1$s" field named "%2$s" on step %3$d. Use wpfunnels/list-checkout-field-sections to see valid names.', $section, $field_name, (int) $step->ID )
			);
		}

		$editor->wpfn_update_field_enable_status(
			[
				'stepID'  => $step->ID,
				'section' => $section,
				'index'   => $field_name,
			]
		);

		$updated = self::getSectionFieldData( $editor, $step->ID, $section );

		return [
			'step_id'    => (int) $step->ID,
			'section'    => $section,
			'field_name' => $field_name,
			'enabled'    => isset( $updated[ $field_name ]['enable'] ) ? (bool) $updated[ $field_name ]['enable'] : null,
		];
	}

	/**
	 * Toggle a field's required state in a Checkout Fields editor section.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function toggleCheckoutFieldRequired( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$section = self::requireSection( isset( $input['section'] ) ? $input['section'] : null );
		if ( is_wp_error( $section ) ) {
			return $section;
		}

		$field_name = isset( $input['field_name'] ) ? sanitize_text_field( $input['field_name'] ) : '';
		$editor     = new CheckoutFieldsEditor();
		$current    = self::getSectionFieldData( $editor, $step->ID, $section );

		if ( '' === $field_name || ! isset( $current[ $field_name ] ) ) {
			return MCPHelper::error(
				'field_not_found',
				sprintf( 'No "%1$s" field named "%2$s" on step %3$d. Use wpfunnels/list-checkout-field-sections to see valid names.', $section, $field_name, (int) $step->ID )
			);
		}

		$editor->wpfn_update_field_required(
			[
				'stepID'  => $step->ID,
				'section' => $section,
				'index'   => $field_name,
			]
		);

		$updated = self::getSectionFieldData( $editor, $step->ID, $section );

		return [
			'step_id'    => (int) $step->ID,
			'section'    => $section,
			'field_name' => $field_name,
			'required'   => isset( $updated[ $field_name ]['required'] ) ? (bool) $updated[ $field_name ]['required'] : null,
		];
	}

	/**
	 * Reorder the fields within a Checkout Fields editor section.
	 *
	 * The underlying editor method rebuilds the section's stored field list
	 * purely from the `order` array it is given — any current field name left
	 * out of `order` would silently be dropped from storage. To keep this tool
	 * safe, the `order` list is required to be an exact match (as a set) of the
	 * section's current field names before it is passed through.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function reorderCheckoutFields( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$section = self::requireSection( isset( $input['section'] ) ? $input['section'] : null );
		if ( is_wp_error( $section ) ) {
			return $section;
		}

		$order = isset( $input['order'] ) && is_array( $input['order'] ) ? array_map( 'sanitize_text_field', $input['order'] ) : [];
		if ( empty( $order ) ) {
			return MCPHelper::error( 'invalid_order', 'The order list must not be empty.' );
		}

		$editor  = new CheckoutFieldsEditor();
		$current = self::getSectionFieldData( $editor, $step->ID, $section );

		$current_names = array_keys( $current );
		$missing       = array_diff( $current_names, $order );
		$unknown       = array_diff( $order, $current_names );

		if ( $missing || $unknown ) {
			return MCPHelper::error(
				'order_mismatch',
				sprintf(
					'The order list must contain exactly the current "%1$s" field names, no more and no less.%2$s%3$s',
					$section,
					$missing ? ' Missing: ' . implode( ', ', $missing ) . '.' : '',
					$unknown ? ' Unknown: ' . implode( ', ', $unknown ) . '.' : ''
				)
			);
		}

		$editor->wpfn_update_field_order(
			[
				'stepID' => $step->ID,
				'index'  => $section,
				'order'  => $order,
			]
		);

		return [
			'reordered' => true,
			'step_id'   => (int) $step->ID,
			'section'   => $section,
			'order'     => $order,
		];
	}

	/**
	 * Restore billing/shipping/additional checkout field sections to
	 * WooCommerce defaults for a step.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function restoreDefaultCheckoutFields( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'The Checkout Fields editor is a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$editor = new CheckoutFieldsEditor();
		$editor->wpfn_restore_to_default_fields( [ 'stepID' => $step->ID ] );

		return [
			'restored' => true,
			'step_id'  => (int) $step->ID,
		];
	}
}
