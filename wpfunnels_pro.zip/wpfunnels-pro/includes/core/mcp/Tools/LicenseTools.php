<?php
/**
 * LicenseTools — MCP abilities for WPFunnels License & Plan status inspection.
 *
 * Moved from the Free plugin (`wpfunnels/includes/core/MCP/Tools/LicenseTools.php`)
 * — this is entirely Pro-domain, read-only plan/limits inspection. Content is
 * unchanged from the Free version aside from the namespace.
 *
 * @package WPFunnelsPro\MCP\Tools
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP\Tools;

defined( 'ABSPATH' ) || exit;

use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Wpfnl_Pro_Licensing;

/**
 * Class LicenseTools
 */
class LicenseTools {

	/**
	 * Register tool definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return [
			'wpfunnels/get-license-status' => [
				'description' => 'Check active license status, plan level (Free, Pro, Agency), and enabled capability flags.',
				'category'    => 'license',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [],
				],
				'callback'    => [ __CLASS__, 'getLicenseStatus' ],
			],

			'wpfunnels/activate-license' => [
				'description' => 'Activate a WPFunnels Pro license key against the license server. Never returns the license key itself.',
				'category'    => 'license',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'license_key' => [
							'type'        => 'string',
							'description' => 'The license key to activate.',
						],
					],
					'required'   => [ 'license_key' ],
				],
				'callback'    => [ __CLASS__, 'activateLicense' ],
			],

			'wpfunnels/deactivate-license' => [
				'description' => 'Deactivate the currently active WPFunnels Pro license so this site frees up an activation slot.',
				'category'    => 'license',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'license_key' => [
							'type'        => 'string',
							'description' => 'The license key to deactivate. Defaults to the currently stored license key when omitted.',
						],
					],
				],
				'callback'    => [ __CLASS__, 'deactivateLicense' ],
			],
		];
	}

	/**
	 * Get license status.
	 *
	 * @param array $input Tool input.
	 * @return array
	 */
	public static function getLicenseStatus( $input = [] ) {
		$is_pro = Wpfnl_functions::is_wpfnl_pro_activated();

		return [
			'pro_active'         => $is_pro,
			'license_status'     => $is_pro ? 'active' : 'free',
			'plan_type'          => $is_pro ? 'pro' : 'free',
			'capabilities'       => [
				'order_bumps'          => true,
				'optin_forms'          => true,
				'post_purchase_offers' => $is_pro,
				'ab_testing'           => $is_pro,
				'custom_checkout'      => $is_pro,
				'automations'          => $is_pro,
				'webhooks'             => $is_pro,
			],
		];
	}

	/**
	 * Activate a Pro license key.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function activateLicense( $input = [] ) {
		$license_key = isset( $input['license_key'] ) ? sanitize_key( trim( $input['license_key'] ) ) : '';

		if ( '' === $license_key ) {
			return new \WP_Error( 'wpfunnels_license_key_required', 'A license_key is required to activate a license.' );
		}

		return self::performOperation( 'activate', $license_key );
	}

	/**
	 * Deactivate a Pro license key.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function deactivateLicense( $input = [] ) {
		$license_key = isset( $input['license_key'] ) ? sanitize_key( trim( $input['license_key'] ) ) : '';

		if ( '' === $license_key ) {
			$license_key = get_option( 'wpfunnels_pro_license_key', '' );
		}

		if ( '' === $license_key ) {
			return new \WP_Error( 'wpfunnels_no_active_license', 'No license key is currently stored to deactivate.' );
		}

		return self::performOperation( 'deactivate', $license_key );
	}

	/**
	 * Run an activate/deactivate operation against the license server and shape
	 * the result for tool output.
	 *
	 * SECURITY: the raw license key is intentionally never included in the
	 * returned payload, not even masked.
	 *
	 * @param string $operation   'activate' or 'deactivate'.
	 * @param string $license_key License key to send.
	 * @return array
	 */
	protected static function performOperation( $operation, $license_key ) {
		$result = Wpfnl_Pro_Licensing::getInstance()->process_license_request( $operation, $license_key );

		return [
			'success'        => (bool) $result['success'],
			'message'        => isset( $result['message'] ) ? $result['message'] : '',
			'license_status' => isset( $result['license_status'] ) ? $result['license_status'] : '',
			'plan_type'      => isset( $result['plan'] ) ? $result['plan'] : '',
			'start_date'     => isset( $result['start_date'] ) ? $result['start_date'] : '',
			'end_date'       => isset( $result['end_date'] ) ? $result['end_date'] : '',
		];
	}
}
