<?php
/**
 * PostPurchaseOfferTools — MCP abilities for WPFunnels Post-Purchase Upsell &
 * Downsell Offers (Pro).
 *
 * Moved from the Free plugin's `Tools/OfferTools.php` — despite that file's
 * generic name, its content (offer step settings, upsell/downsell offers, skip
 * offer) is entirely the Pro "post-purchase offers" domain from the plan's
 * §5.2 catalogue. Renamed on the move; the old Free `OfferTools.php` filename
 * is intentionally left free for a separate, unrelated Free order-bump tool
 * file. Content unchanged from the Free version aside from the namespace and
 * the added Pro guard.
 *
 * @package WPFunnelsPro\MCP\Tools
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP\Tools;

defined( 'ABSPATH' ) || exit;

use WPFunnels\MCP\Helpers\MCPHelper;
use WPFunnels\Wpfnl_functions;

/**
 * Class PostPurchaseOfferTools
 */
class PostPurchaseOfferTools {

	/**
	 * Register tool definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return [
			'wpfunnels/get-offer-step-settings' => [
				'description' => 'Get configured offer product, discount, skip rules, and copy settings for an upsell or downsell step.',
				'category'    => 'offer',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'ID of the upsell or downsell step.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'getOfferSettings' ],
			],

			'wpfunnels/upsert-upsell-offer' => [
				'description' => 'Configure an upsell offer step with product selection, discount rates, replace-order toggles, and copy. This does NOT set what happens after the customer accepts or declines — call wpfunnels/set-offer-routing separately for that, or the canvas stays a straight chain regardless of the offer settings here.',
				'category'    => 'offer',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'              => [
							'type'        => 'integer',
							'description' => 'ID of the upsell step.',
						],
						'product_id'           => [
							'type'        => 'integer',
							'description' => 'WooCommerce product ID for the offer.',
						],
						'discount_type'        => [
							'type'        => 'string',
							'enum'        => [ 'flat', 'percent', 'original' ],
							'description' => 'Discount type applied to offer.',
						],
						'discount_value'       => [
							'type'        => 'number',
							'description' => 'Discount value (amount or percentage).',
						],
						'replace_main_product' => [
							'type'        => 'boolean',
							'description' => 'Whether accepting this offer replaces the main order product.',
						],
						'quantity'             => [
							'type'        => 'integer',
							'description' => 'Offer product quantity.',
						],
					],
					'required'   => [ 'step_id', 'product_id' ],
				],
				'callback'    => [ __CLASS__, 'upsertUpsellOffer' ],
			],

			'wpfunnels/upsert-downsell-offer' => [
				'description' => 'Configure a downsell offer step with alternative product selection, higher discount rate, and copy. This does NOT set what happens after the customer accepts or declines — call wpfunnels/set-offer-routing separately for that, or the canvas stays a straight chain regardless of the offer settings here.',
				'category'    => 'offer',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'        => [
							'type'        => 'integer',
							'description' => 'ID of the downsell step.',
						],
						'product_id'     => [
							'type'        => 'integer',
							'description' => 'WooCommerce product ID for the downsell offer.',
						],
						'discount_type'  => [
							'type'        => 'string',
							'enum'        => [ 'flat', 'percent', 'original' ],
							'description' => 'Discount type.',
						],
						'discount_value' => [
							'type'        => 'number',
							'description' => 'Discount value.',
						],
					],
					'required'   => [ 'step_id', 'product_id' ],
				],
				'callback'    => [ __CLASS__, 'upsertDownsellOffer' ],
			],

			'wpfunnels/configure-skip-offer' => [
				'description' => 'Set auto-skip rules for an offer step if buyer already purchased the product.',
				'category'    => 'offer',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'          => [
							'type'        => 'integer',
							'description' => 'ID of the offer step.',
						],
						'skip_if_purchased' => [
							'type'        => 'boolean',
							'description' => 'Skip offer if customer already bought product.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'configureSkipOffer' ],
			],

			'wpfunnels/set-offer-routing' => [
				'description' => 'Wire accept/reject branching for an upsell or downsell step: which step to send the customer to when they accept the offer, and which step to send them to when they decline it. Requires WPFunnels Pro — call wpfunnels/get-license-status first and only use this tool when post_purchase_offers is true.',
				'category'    => 'offer',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'              => [
							'type'        => 'integer',
							'description' => 'ID of the upsell or downsell step being routed.',
						],
						'accept_next_step_id'  => [
							'type'        => 'integer',
							'description' => 'Step ID to send the customer to when they accept this offer (e.g. the Thank You step).',
						],
						'reject_next_step_id'  => [
							'type'        => 'integer',
							'description' => 'Step ID to send the customer to when they decline this offer (e.g. the Downsell step, or Thank You).',
						],
					],
					'required'   => [ 'step_id', 'accept_next_step_id', 'reject_next_step_id' ],
				],
				'callback'    => [ __CLASS__, 'setOfferRouting' ],
			],
		];
	}

	/**
	 * Guard check for Pro plugin/license.
	 *
	 * @return bool
	 */
	protected static function checkPro() {
		return Wpfnl_functions::is_wpfnl_pro_activated();
	}

	/**
	 * Get offer settings for a step.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function getOfferSettings( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Post-purchase upsell/downsell offers are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$type = get_post_meta( $step->ID, '_step_type', true );
		if ( ! in_array( $type, [ 'upsell', 'downsell' ], true ) ) {
			return MCPHelper::error( 'invalid_step_type', 'Offer settings are only valid for upsell and downsell steps.' );
		}

		return [
			'step_id'              => (int) $step->ID,
			'step_name'            => $step->post_title,
			'type'                 => $type,
			'product_id'           => (int) get_post_meta( $step->ID, '_offer_product_id', true ),
			'discount_type'        => get_post_meta( $step->ID, '_offer_discount_type', true ) ?: 'original',
			'discount_value'       => (float) get_post_meta( $step->ID, '_offer_discount_value', true ),
			'replace_main_product' => 'yes' === get_post_meta( $step->ID, '_offer_replace_main_product', true ),
			'quantity'             => (int) ( get_post_meta( $step->ID, '_offer_product_quantity', true ) ?: 1 ),
			'skip_if_purchased'    => 'yes' === get_post_meta( $step->ID, '_offer_skip_if_purchased', true ),
		];
	}

	/**
	 * Configure an upsell offer.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function upsertUpsellOffer( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Post-purchase upsell/downsell offers are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$product_id = (int) $input['product_id'];
		update_post_meta( $step->ID, '_offer_product_id', $product_id );

		if ( isset( $input['discount_type'] ) ) {
			update_post_meta( $step->ID, '_offer_discount_type', sanitize_text_field( $input['discount_type'] ) );
		}
		if ( isset( $input['discount_value'] ) ) {
			update_post_meta( $step->ID, '_offer_discount_value', (float) $input['discount_value'] );
		}
		if ( isset( $input['replace_main_product'] ) ) {
			update_post_meta( $step->ID, '_offer_replace_main_product', $input['replace_main_product'] ? 'yes' : 'no' );
		}
		if ( isset( $input['quantity'] ) ) {
			update_post_meta( $step->ID, '_offer_product_quantity', max( 1, (int) $input['quantity'] ) );
		}

		return self::getOfferSettings( [ 'step_id' => $step->ID ] );
	}

	/**
	 * Configure a downsell offer.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function upsertDownsellOffer( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Post-purchase upsell/downsell offers are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$product_id = (int) $input['product_id'];
		update_post_meta( $step->ID, '_offer_product_id', $product_id );

		if ( isset( $input['discount_type'] ) ) {
			update_post_meta( $step->ID, '_offer_discount_type', sanitize_text_field( $input['discount_type'] ) );
		}
		if ( isset( $input['discount_value'] ) ) {
			update_post_meta( $step->ID, '_offer_discount_value', (float) $input['discount_value'] );
		}

		return self::getOfferSettings( [ 'step_id' => $step->ID ] );
	}

	/**
	 * Configure skip offer rules.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function configureSkipOffer( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Post-purchase upsell/downsell offers are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$skip = ! empty( $input['skip_if_purchased'] );
		update_post_meta( $step->ID, '_offer_skip_if_purchased', $skip ? 'yes' : 'no' );

		return [
			'step_id'           => (int) $step->ID,
			'skip_if_purchased' => $skip,
			'updated'           => true,
		];
	}

	/**
	 * Wire accept/reject branching for an upsell or downsell step.
	 *
	 * Writes the same `_wpfnl_maybe_enable_condition` / `_wpfnl_step_conditions` /
	 * `_wpfnl_next_step_after_condition` meta that the manual "Condition" panel
	 * writes via StepController::save_condition() — this is the mechanism that
	 * actually governs accept/reject redirects at runtime, not the legacy
	 * `_wpfnl_upsell_next_step_yes/no` keys.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function setOfferRouting( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Accept/reject offer routing is a WPFunnels Pro feature. Call wpfunnels/get-license-status to confirm plan capabilities before proposing this to the user.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$step_type = get_post_meta( $step->ID, '_step_type', true );
		if ( ! in_array( $step_type, [ 'upsell', 'downsell' ], true ) ) {
			return MCPHelper::error( 'invalid_step_type', 'Offer routing can only be set on upsell and downsell steps.' );
		}

		$accept_step = MCPHelper::requireStep( isset( $input['accept_next_step_id'] ) ? $input['accept_next_step_id'] : 0 );
		if ( is_wp_error( $accept_step ) ) {
			return $accept_step;
		}

		$reject_step = MCPHelper::requireStep( isset( $input['reject_next_step_id'] ) ? $input['reject_next_step_id'] : 0 );
		if ( is_wp_error( $reject_step ) ) {
			return $reject_step;
		}

		$funnel_id = (int) get_post_meta( $step->ID, '_funnel_id', true );
		foreach ( [ 'accept' => $accept_step, 'reject' => $reject_step ] as $branch => $target ) {
			if ( (int) get_post_meta( $target->ID, '_funnel_id', true ) !== $funnel_id ) {
				return MCPHelper::error(
					'step_not_in_funnel',
					sprintf( 'The %s target step (ID %d) does not belong to the same funnel as the offer step.', $branch, $target->ID )
				);
			}
		}

		$conditions = [
			[
				[
					'field'             => $step_type,
					'condition'         => 'is',
					// The runtime evaluator (Wpfnl_Condition_Checker::upsell_condition_checker())
					// only recognizes 'yes'/'no' here — it dispatches on the separate $checker
					// argument ('accept'/'reject') for which branch is being tested.
					'value'             => 'yes',
					'selectedCondition' => '',
				],
			],
		];

		$after_condition = [
			'true'  => (int) $accept_step->ID,
			'false' => (int) $reject_step->ID,
		];

		update_post_meta( $step->ID, '_wpfnl_maybe_enable_condition', 'yes' );
		update_post_meta( $step->ID, '_wpfnl_step_conditions', $conditions );
		update_post_meta( $step->ID, '_wpfnl_next_step_after_condition', $after_condition );

		$reconfigure_settings = get_post_meta( $funnel_id, '_wpfnl_reconfigurable_condition_data', true );
		if ( is_array( $reconfigure_settings ) && ! empty( $reconfigure_settings ) ) {
			$key = array_search( $step->ID, array_column( $reconfigure_settings, 'step_id' ), true );
			if ( false !== $key ) {
				unset( $reconfigure_settings[ $key ] );
				update_post_meta( $funnel_id, '_wpfnl_reconfigurable_condition_data', array_values( $reconfigure_settings ) );
			}
		}

		return [
			'step_id'              => (int) $step->ID,
			'step_type'            => $step_type,
			'accept_next_step_id'  => (int) $accept_step->ID,
			'reject_next_step_id'  => (int) $reject_step->ID,
			'enabled'              => true,
		];
	}
}
