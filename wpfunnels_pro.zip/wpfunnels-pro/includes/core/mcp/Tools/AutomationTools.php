<?php
/**
 * AutomationTools — MCP abilities for WPFunnels Pro per-step funnel automations.
 *
 * Automations are powered entirely by Mail Mint: a WPFunnels step's automation is
 * a real Mail Mint automation (`{$wpdb->prefix}mint_automations`) whose trigger
 * step is one of the `wpf_*`/`funnel_*` keys the automation canvas registers for
 * this connector, scoped to a specific funnel step via
 * `trigger.settings.settings.selectedStep` / `selected_funnel_ids` — the exact
 * shape `WPFunnelsPro\MailMint\Automation::prepare_settings()` and the canvas's
 * own React editor (`mail-mint/src/automation/integrations/core/triggers/wpfunnels/*`)
 * both write. Rather than re-deriving that shape and Mail Mint's step-id/next-id
 * chaining by hand, these tools build the same `steps[]` payload the canvas
 * sends and hand it to the real REST controller behind it,
 * `WPFunnels\Rest\Controllers\AutomationCanvasController`, which validates Mail
 * Mint availability, saves via `AutomationModel::create_or_update()`, and syncs
 * the `wpfnl_mint_automation_id` / `_wpfnl_automation_trigger` /
 * `_wpfnl_automation_steps` postmeta the funnel canvas reads.
 *
 * Only LINEAR flows (trigger + a plain sequence of actions) are supported here —
 * conditional branching is deliberately left to the visual editor, since getting
 * the branch/merge id-chaining wrong by hand is exactly how a hand-rolled
 * automation payload silently corrupts.
 *
 * @package WPFunnelsPro\MCP\Tools
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP\Tools;

defined( 'ABSPATH' ) || exit;

use WP_REST_Request;
use WPFunnels\MCP\Helpers\MCPHelper;
use WPFunnels\Rest\Controllers\AutomationCanvasController;
use WPFunnels\Wpfnl_functions;

/**
 * Class AutomationTools
 */
class AutomationTools {

	/**
	 * Step-scoped WPFunnels trigger keys the automation canvas registers, and the
	 * step type each is only relevant on. Sourced from the real trigger node
	 * registry (`mail-mint/src/automation/integrations/core/triggers/wpfunnels/*`),
	 * not the older, partly-stale `MintController.php` constants. Excludes
	 * `wpfunnels_funnel_created`, which is funnel-wide, not step-scoped.
	 */
	private const TRIGGERS = [
		'wpf_order_placed'           => 'Checkout order placed',
		'wpfunnels_cta_triggered'    => 'CTA button clicked',
		'funnel_optin_submitted'     => 'Opt-in form submitted',
		'funnel_upsell_trigger'      => 'Upsell offer shown',
		'funnel_upsell_accepted'     => 'Upsell accepted',
		'funnel_upsell_rejected'     => 'Upsell rejected',
		'funnel_downsell_trigger'    => 'Downsell offer shown',
		'funnel_downsell_accepted'   => 'Downsell accepted',
		'funnel_downsell_rejected'   => 'Downsell rejected',
		'funnel_order_bump_action'   => 'Order bump shown',
		'funnel_order_bump_accepted' => 'Order bump accepted',
		'funnel_order_bump_rejected' => 'Order bump rejected',
	];

	/**
	 * Register tool definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return [
			'wpfunnels/list-step-automations' => [
				'description' => 'List the automation attached to a funnel step, if any (WPFunnels automations are always scoped to one step, not the whole funnel).',
				'category'    => 'automation',
				'readonly'    => true,
				'destructive' => false,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'Funnel step post ID.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'listStepAutomation' ],
			],

			'wpfunnels/upsert-automation' => [
				'description' => 'Create or update a LINEAR automation (one trigger, then a plain sequence of actions — no branching) attached to one funnel step. Action keys/settings must come from Mail Mint\'s automation registry — common shapes: delay {"delay_settings":{"delay":1,"unit":"minutes|hours|days|weeks"}}; addTag {"tag_settings":{"tags":[{"id":N}]}}; addList {"list_settings":{"lists":[{"id":N}]}}; sendMail {"message_data":{"subject":"...","body":"<html>"}}. This is also how to "send a triggered email on a funnel event": add a sendMail action step.',
				'category'    => 'automation',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id'       => [
							'type'        => 'integer',
							'description' => 'Funnel step this automation is scoped to.',
						],
						'name'          => [
							'type'        => 'string',
							'description' => 'Automation name.',
						],
						'trigger'       => [
							'type'        => 'string',
							'enum'        => array_keys( self::TRIGGERS ),
							'description' => 'Event on this step that starts the automation.',
						],
						'steps'         => [
							'type'        => 'array',
							'description' => 'Ordered action steps run after the trigger. No "condition" steps — branching is not supported here.',
							'items'       => [
								'type'       => 'object',
								'required'   => [ 'key' ],
								'properties' => [
									'key'      => [ 'type' => 'string', 'description' => 'A Mail Mint action key (delay, sendMail, addTag, addList, …).' ],
									'settings' => [ 'type' => 'object' ],
								],
							],
						],
						'status'        => [
							'type'        => 'string',
							'enum'        => [ 'draft', 'active', 'pause' ],
							'description' => 'Defaults to draft. Set active to have it act on real site events immediately.',
						],
						'automation_id' => [
							'type'        => 'integer',
							'description' => 'Provide to update the automation already attached to this step (from list-step-automations). Omit to create a new one — this REPLACES the step list.',
						],
					],
					'required'   => [ 'step_id', 'name', 'trigger' ],
				],
				'callback'    => [ __CLASS__, 'upsertAutomation' ],
			],

			'wpfunnels/delete-automation' => [
				'description' => 'Delete the automation attached to a funnel step.',
				'category'    => 'automation',
				'readonly'    => false,
				'destructive' => true,
				'parameters'  => [
					'type'       => 'object',
					'properties' => [
						'step_id' => [
							'type'        => 'integer',
							'description' => 'Funnel step whose automation should be deleted.',
						],
					],
					'required'   => [ 'step_id' ],
				],
				'callback'    => [ __CLASS__, 'deleteAutomation' ],
			],
		];
	}

	/**
	 * Guard check for Pro plugin/license.
	 *
	 * @return bool
	 */
	protected static function checkPro() {
		return Wpfnl_functions::is_wpfnl_pro_activated();
	}

	/**
	 * Guard check for Mail Mint availability, mirroring
	 * AutomationCanvasController::check_mailmint_availability().
	 *
	 * @return true|\WP_Error
	 */
	private static function checkMailMint() {
		if ( ! Wpfnl_functions::is_mint_mrm_active() || ! class_exists( '\MintMail\App\Internal\Automation\AutomationModel' ) ) {
			return MCPHelper::error( 'mailmint_required', 'Mail Mint must be installed and active to use funnel automations.' );
		}
		return true;
	}

	/**
	 * Valid Mail Mint action keys, or a conservative fallback if the registry
	 * class is missing (definitions() must not fatal when Mail Mint is absent).
	 *
	 * @return array
	 */
	private static function validActionKeys() {
		if ( class_exists( '\MintMail\App\Internal\Automation\Action\AutomationAction' ) ) {
			return array_keys( (array) \MintMail\App\Internal\Automation\Action\AutomationAction::get_instance()->supported_actions() );
		}
		return [];
	}

	/**
	 * A funnel step's current automation, read straight from the postmeta the
	 * canvas maintains — no Mail Mint call needed for the common case.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function listStepAutomation( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Funnel automations are a WPFunnels Pro feature.' );
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$automation_id = (int) get_post_meta( $step->ID, 'wpfnl_mint_automation_id', true );
		if ( ! $automation_id ) {
			return [
				'step_id'   => (int) $step->ID,
				'automated' => false,
			];
		}

		$trigger = get_post_meta( $step->ID, '_wpfnl_automation_trigger', true );
		$status  = null;
		if ( class_exists( '\MintMail\App\Internal\Automation\AutomationModel' ) ) {
			$row    = \MintMail\App\Internal\Automation\AutomationModel::get_single( $automation_id );
			$status = isset( $row['data'][0]['status'] ) ? $row['data'][0]['status'] : null;
		}

		return [
			'step_id'       => (int) $step->ID,
			'automated'     => true,
			'automation_id' => $automation_id,
			'trigger'       => is_array( $trigger ) && isset( $trigger['value'] ) ? $trigger['value'] : null,
			'status'        => $status,
		];
	}

	/**
	 * Create or update a linear (trigger + sequential actions) automation on one
	 * step, via the same REST controller the automation canvas UI calls.
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function upsertAutomation( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Funnel automations are a WPFunnels Pro feature.' );
		}
		$mint_check = self::checkMailMint();
		if ( is_wp_error( $mint_check ) ) {
			return $mint_check;
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$name    = isset( $input['name'] ) ? sanitize_text_field( $input['name'] ) : '';
		$trigger = isset( $input['trigger'] ) ? sanitize_text_field( $input['trigger'] ) : '';
		if ( '' === $name || ! isset( self::TRIGGERS[ $trigger ] ) ) {
			return MCPHelper::error( 'invalid_automation', 'Provide a name and a supported trigger.' );
		}

		$status = isset( $input['status'] ) && in_array( $input['status'], [ 'active', 'pause', 'draft' ], true ) ? $input['status'] : 'draft';

		$steps_in = isset( $input['steps'] ) && is_array( $input['steps'] ) ? $input['steps'] : [];
		$valid_actions = self::validActionKeys();
		foreach ( $steps_in as $i => $step_in ) {
			$key = is_array( $step_in ) ? ( $step_in['key'] ?? '' ) : '';
			if ( 'condition' === $key ) {
				return MCPHelper::error( 'invalid_automation', 'Conditional branching is not supported here — build it in the automation canvas instead.' );
			}
			if ( '' === $key || ( ! empty( $valid_actions ) && ! in_array( $key, $valid_actions, true ) ) ) {
				return MCPHelper::error( 'invalid_automation', sprintf( 'steps[%d].key "%s" is not a registered Mail Mint action.', $i, $key ) );
			}
		}

		$automation_id = isset( $input['automation_id'] ) ? (int) $input['automation_id'] : 0;
		if ( $automation_id && (int) get_post_meta( $step->ID, 'wpfnl_mint_automation_id', true ) !== $automation_id ) {
			return MCPHelper::error( 'automation_mismatch', 'That automation_id is not the one attached to this step. Use list-step-automations to find the right one.' );
		}

		// Pre-assign every step id up front so each step can point at the next —
		// same one-pass chaining the canvas UI does for a purely linear flow.
		$ids = [ self::generateStepId() ];
		foreach ( $steps_in as $unused ) {
			$ids[] = self::generateStepId();
		}

		$funnel_id = (int) get_post_meta( $step->ID, '_funnel_id', true );

		$canvas_steps   = [];
		$canvas_steps[] = [
			'step_id' => $ids[0],
			'key'     => $trigger,
			'type'    => 'trigger',
			'title'   => self::TRIGGERS[ $trigger ],
			'settings'=> [
				'settings' => [
					'type'                => 'selected',
					'selected_funnel_ids' => [ $funnel_id ],
					'_funnel_label'       => get_the_title( $funnel_id ),
					'all_steps'           => 'no',
					'selectedStep'        => (int) $step->ID,
					'selectedType'        => get_post_meta( $step->ID, '_step_type', true ),
					'_step_label'         => get_the_title( $step->ID ),
				],
			],
			'next_step_id' => $ids[1] ?? '',
		];

		foreach ( $steps_in as $i => $step_in ) {
			$canvas_steps[] = [
				'step_id'      => $ids[ $i + 1 ],
				'key'          => sanitize_text_field( $step_in['key'] ),
				'type'         => 'action',
				'title'        => isset( $step_in['title'] ) ? sanitize_text_field( $step_in['title'] ) : sanitize_text_field( $step_in['key'] ),
				'settings'     => isset( $step_in['settings'] ) && is_array( $step_in['settings'] ) ? $step_in['settings'] : [],
				'next_step_id' => $ids[ $i + 2 ] ?? '',
			];
		}

		$payload = [
			'name'   => $name,
			'status' => $status,
			'steps'  => $canvas_steps,
		];

		$request = new WP_REST_Request( $automation_id ? 'PUT' : 'POST' );
		$request->set_header( 'content-type', 'application/json' );
		$request->set_body( wp_json_encode( $payload ) );
		if ( $automation_id ) {
			$request->set_param( 'id', $automation_id );
		}

		$controller = new AutomationCanvasController();
		$response   = $automation_id ? $controller->update_item( $request ) : $controller->create_item( $request );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = $response->get_data();

		return [
			'upserted'      => true,
			'step_id'       => (int) $step->ID,
			'automation_id' => isset( $data['id'] ) ? (int) $data['id'] : $automation_id,
			'status'        => $status,
			'step_count'    => count( $canvas_steps ),
		];
	}

	/**
	 * Delete the automation attached to a step, via the same controller the
	 * canvas UI uses (cleans up the trigger/steps postmeta on every linked step,
	 * not just this one, matching how the UI itself deletes an automation).
	 *
	 * @param array $input Tool input.
	 * @return array|\WP_Error
	 */
	public static function deleteAutomation( $input = [] ) {
		if ( ! self::checkPro() ) {
			return MCPHelper::error( 'pro_required', 'Funnel automations are a WPFunnels Pro feature.' );
		}
		$mint_check = self::checkMailMint();
		if ( is_wp_error( $mint_check ) ) {
			return $mint_check;
		}

		$step = MCPHelper::requireStep( isset( $input['step_id'] ) ? $input['step_id'] : 0 );
		if ( is_wp_error( $step ) ) {
			return $step;
		}

		$automation_id = (int) get_post_meta( $step->ID, 'wpfnl_mint_automation_id', true );
		if ( ! $automation_id ) {
			return MCPHelper::error( 'not_found', 'This step has no automation attached.' );
		}

		$request = new WP_REST_Request( 'DELETE' );
		$request->set_param( 'id', $automation_id );

		$controller = new AutomationCanvasController();
		$response   = $controller->delete_item( $request );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return [
			'deleted'       => true,
			'step_id'       => (int) $step->ID,
			'automation_id' => $automation_id,
		];
	}

	/**
	 * Generate a step id in the same format the canvas UI's client-side
	 * generator uses (short, unique enough within one automation).
	 *
	 * @return string
	 */
	private static function generateStepId() {
		return strtolower( wp_generate_password( 8, false, false ) );
	}
}
