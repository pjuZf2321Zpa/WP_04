<?php
/**
 * ProAbilitiesRegistrar — registers WPFunnels Pro's MCP abilities on top of
 * Free's tool layer.
 *
 * Free's `WPFunnels\MCP\MCPInit` already registers Free abilities and then
 * fires `wpfunnels/mcp_loaded`, and already reads
 * `apply_filters( 'wpfunnels/mcp_ability_names', ... )` to decide which
 * abilities the MCP server exposes. This class only needs to hook those two
 * existing extension points — no changes to Free's MCPInit are required.
 *
 * Ability names keep the `wpfunnels/xxx-yyy` prefix (not `wpfunnels-pro/...`)
 * and the shared `wpfunnels` category, so MCP clients see one consistent
 * namespace regardless of which plugin registered a given tool (plan §3 D2).
 *
 * Every Pro definition is prepared via Free's own
 * `WPFunnels\MCP\AbilitiesRegistrar::prepare()` before `wp_register_ability()`,
 * so Pro tools get the exact same destructive-confirmation hard stop and
 * schema normalization as Free tools — no separate implementation to keep in
 * sync. Every call into Free's registrar is guarded with `class_exists()` so
 * Pro never fatals if Free's MCP layer is older, disabled, or missing.
 *
 * @package WPFunnelsPro\MCP
 * @since 3.13.0
 */

namespace WPFunnelsPro\MCP;

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/Tools/AbTestingTools.php';
require_once __DIR__ . '/Tools/AnalyticsTools.php';
require_once __DIR__ . '/Tools/AutomationTools.php';
require_once __DIR__ . '/Tools/IntegrationTools.php';
require_once __DIR__ . '/Tools/CheckoutFieldTools.php';
require_once __DIR__ . '/Tools/LicenseTools.php';
require_once __DIR__ . '/Tools/PostPurchaseOfferTools.php';

use WPFunnelsPro\MCP\Tools\AbTestingTools;
use WPFunnelsPro\MCP\Tools\AnalyticsTools;
use WPFunnelsPro\MCP\Tools\AutomationTools;
use WPFunnelsPro\MCP\Tools\CheckoutFieldTools;
use WPFunnelsPro\MCP\Tools\IntegrationTools;
use WPFunnelsPro\MCP\Tools\LicenseTools;
use WPFunnelsPro\MCP\Tools\PostPurchaseOfferTools;

/**
 * Class ProAbilitiesRegistrar
 */
class ProAbilitiesRegistrar {

	/**
	 * Cached definitions.
	 *
	 * @var array|null
	 */
	private static $definitions = null;

	/**
	 * All Pro ability definitions, keyed by ability name.
	 *
	 * @return array
	 */
	public static function getDefinitions() {
		if ( null !== self::$definitions ) {
			return self::$definitions;
		}

		$definitions = array_merge(
			AbTestingTools::definitions(),
			AnalyticsTools::definitions(),
			AutomationTools::definitions(),
			IntegrationTools::definitions(),
			CheckoutFieldTools::definitions(),
			LicenseTools::definitions(),
			PostPurchaseOfferTools::definitions()
		);

		/**
		 * Filter Pro's MCP tool definitions before registration.
		 *
		 * @since 3.13.0
		 * @param array $definitions Ability name => definition array.
		 */
		self::$definitions = apply_filters( 'wpfunnels_pro/mcp_register_tools', $definitions );

		return self::$definitions;
	}

	/**
	 * Register every Pro ability with the Abilities API.
	 *
	 * Runs on `wpfunnels/mcp_loaded`, fired by Free's MCPInit right after Free
	 * abilities are registered.
	 *
	 * @return void
	 */
	public static function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		if ( ! class_exists( '\WPFunnels\MCP\AbilitiesRegistrar' ) ) {
			// Free's MCP layer isn't present/loaded — nothing safe to prepare
			// against, so skip rather than hand-roll a second confirmation
			// wrapper that could drift from Free's.
			return;
		}

		foreach ( self::getDefinitions() as $name => $definition ) {
			wp_register_ability( $name, \WPFunnels\MCP\AbilitiesRegistrar::prepare( $name, $definition ) );
		}
	}

	/**
	 * Append Pro's ability names to the list the MCP server exposes.
	 *
	 * Hooked onto `wpfunnels/mcp_ability_names`. Only appends when Free's
	 * registrar is available, since {@see self::register()} only actually
	 * registers the abilities in that case — appending names for abilities
	 * that were never registered would make the MCP server advertise tools it
	 * cannot execute.
	 *
	 * @param array $names Ability names registered so far.
	 * @return array
	 */
	public static function appendNames( $names ) {
		$names = is_array( $names ) ? $names : [];

		if ( ! class_exists( '\WPFunnels\MCP\AbilitiesRegistrar' ) ) {
			return $names;
		}

		return array_merge( $names, array_keys( self::getDefinitions() ) );
	}

	/**
	 * Wire Pro's registrar onto Free's MCP extension points.
	 *
	 * Safe to call unconditionally: {@see self::register()} and
	 * {@see self::appendNames()} each independently guard against Free's MCP
	 * layer being unavailable.
	 *
	 * @return void
	 */
	public static function boot() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			// No Abilities API on this WordPress version — nothing to hook.
			return;
		}

		add_action( 'wpfunnels/mcp_loaded', [ __CLASS__, 'register' ] );
		add_filter( 'wpfunnels/mcp_ability_names', [ __CLASS__, 'appendNames' ] );
	}
}
