<?php
/**
 * Divi 5 Widgets Manager for Pro Plugin
 *
 * Loaded by Wpfnl_Pro_Widgets_Manager when Divi 5 is detected.
 * Extends the free plugin's Divi 5 modules with Pro features.
 *
 * @package WPFunnelsPro\Widgets\DiviModulesV5
 * @since   3.10.6
 */

namespace WPFunnelsPro\Widgets\DiviModulesV5;

final class Manager {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/** @var string Path to the divi-5 modules directory */
	private string $d5_dir;

	public function __construct() {
		$this->d5_dir = plugin_dir_path( __FILE__ )
			. '../divi-modules/divi-5/';

		$this->init();
	}

	private function init(): void {
		$modules_file = $this->d5_dir . 'modules/Modules.php';
		if ( file_exists( $modules_file ) ) {
			require_once $modules_file;
		}

		$this->enqueue_vb_bundle();
	}

	/**
	 * Enqueue the Visual Builder JS bundle when the Divi 5 VB is active.
	 */
	private function enqueue_vb_bundle(): void {
		// Fires inside PackageBuildManager::enqueue_scripts() — app-window only,
		// before divi-module-library is queued, so our addAction listener is
		// registered before Divi fires divi.moduleLibrary.registerModuleLibraryStore.after.
		add_action( 'divi_visual_builder_assets_before_enqueue_app_window_scripts', function () {
			$build_dir = $this->d5_dir . 'visual-builder/build/';
			$build_url = plugins_url(
				'includes/core/widgets/divi-modules/divi-5/visual-builder/build/',
				\WPFNL_PRO_FILE
			);

			$js_file = $build_dir . 'wpfnl-pro-divi5-vb.js';
			if ( ! file_exists( $js_file ) ) {
				return;
			}

			wp_enqueue_script(
				'wpfnl-pro-divi5-vb',
				$build_url . 'wpfnl-pro-divi5-vb.js',
				[ 'divi-vendor-react', 'divi-vendor-wp-hooks', 'divi-module', 'divi-rest', 'wpfnl-divi5-vb' ],
				\WPFNL_PRO_VERSION . '.' . (string) filemtime( $js_file ),
				true
			);

			// Load WPFunnels Pro public CSS in the VB canvas
			$public_css = \WPFNL_PRO_DIR_URL . 'public/assets/css/wpfnl-pro-public.css';
			if ( file_exists( \WPFNL_PRO_DIR . 'public/assets/css/wpfnl-pro-public.css' ) ) {
				wp_enqueue_style( 'wpfnl-pro-public', $public_css, [], \WPFNL_PRO_VERSION );
			}

			wp_localize_script(
				'wpfnl-pro-divi5-vb',
				'wpfnlProDiviVBData',
				[
					'postId'    => get_the_ID(),
					'restUrl'   => rest_url( 'wpfnl-pro/v1' ),
					'nonce'     => wp_create_nonce( 'wp_rest' ),
					'isPro'     => true,
				]
			);
		} );
	}
}
