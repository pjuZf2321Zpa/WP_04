<?php

namespace WPFunnelsPro\Widgets\DiviModules;

use WPFunnels\Wpfnl_functions;

final class Manager {

    private static $_instance = null;

    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }


    public function __construct()
    {
        $this->init();
    }

    /**
     * Initialize divi modules.
     *
     * Hooks into both D4 and D5 entry points so that:
     * - Divi 4: modules register via divi_extensions_init → et_builder_ready.
     * - Divi 5: PluginHooksCheck sees the D5 hook and does NOT flag this plugin
     *   as "D4-only", which keeps the shortcode framework loading path intact.
     */
    private function init() {
        add_action( 'divi_extensions_init', array( $this, 'wpfnl_initialize_extension' ) );
        add_action( 'divi_visual_builder_assets_before_enqueue_scripts', array( $this, 'wpfnl_d5_vb_compat' ) );
    }

    /**
     * Initialize the Divi extension.
     *
     * @return void
     */
    public function wpfnl_initialize_extension() {
        WPFNL_DiviModules::get_instance();
    }

    /**
     * Divi 5 compatibility hook callback.
     *
     * This callback's mere existence on divi_visual_builder_assets_before_enqueue_scripts
     * signals to Divi 5's PluginHooksCheck that WPFunnels Pro is D5-aware.
     *
     * @return void
     * @since 3.10.6
     */
    public function wpfnl_d5_vb_compat() {
        // No-op: the signal is the hook registration itself.
    }

}
