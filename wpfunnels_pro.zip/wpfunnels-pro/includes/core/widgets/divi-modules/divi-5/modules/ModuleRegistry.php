<?php
/**
 * Pro Module registry for Divi 5.
 *
 * Registers Pro modules that override or extend free plugin modules.
 * When Pro is active, Pro modules take precedence.
 *
 * @package WPFunnelsPro\Widgets\DiviModules\D5
 * @since   3.10.6
 */

namespace WPFunnelsPro\Widgets\DiviModules\D5;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class ModuleRegistry {

	/**
	 * Map of Pro module directory → module class.
	 * These modules override or extend the free plugin's modules.
	 */
	private static array $modules = [
		'OfferButton' => 'WPFunnelsPro\Widgets\DiviModules\D5\OfferButton\OfferButton',
	];

	/**
	 * Register all Pro modules.
	 *
	 * @param mixed $dependency_tree  Passed by divi_module_library_modules_dependency_tree;
	 *                                null when called from our init:20 fallback.
	 */
	public static function register_modules( $dependency_tree ): void {
		// Post-type guard: skip on non-funnel pages (but not in REST/admin context)
		$post_type = self::get_current_post_type();
		if ( ! empty( $post_type )
			&& $post_type !== WPFNL_STEPS_POST_TYPE
			&& ! ( defined( 'REST_REQUEST' ) && REST_REQUEST )
			&& ! is_admin()
		) {
			return;
		}

		// Load the free plugin's BaseModule as our base
		$free_base_module = WPFNL_DIR . 'includes/core/widgets/divi-modules/divi-5/modules/BaseModule.php';
		if ( file_exists( $free_base_module ) ) {
			require_once $free_base_module;
		}

		// Load Pro BaseModule if we have one
		$pro_base_module = __DIR__ . '/BaseModule.php';
		if ( file_exists( $pro_base_module ) ) {
			require_once $pro_base_module;
		}

		$modules_dir = __DIR__;

		foreach ( self::$modules as $dir => $class ) {
			$module_file = $modules_dir . '/' . $dir . '/' . $dir . '.php';

			if ( ! class_exists( $class ) ) {
				if ( file_exists( $module_file ) ) {
					require_once $module_file;
				}
			}

			if ( ! class_exists( $class ) ) {
				continue;
			}

			/** @var \WPFunnels\Widgets\DiviModules\D5\BaseModule $instance */
			$instance = new $class();
			$instance->load();
		}
	}

	/**
	 * Register REST API routes for all Pro modules (called from rest_api_init).
	 */
	public static function register_rest_routes(): void {
		// Load the free plugin's BaseModule
		$free_base_module = WPFNL_DIR . 'includes/core/widgets/divi-modules/divi-5/modules/BaseModule.php';
		if ( file_exists( $free_base_module ) ) {
			require_once $free_base_module;
		}

		$modules_dir = __DIR__;

		foreach ( self::$modules as $dir => $class ) {
			// Load traits + class file so REST route registration methods are available
			$trait_dir  = $modules_dir . '/' . $dir . '/' . $dir . 'Trait/';
			$rest_trait = $trait_dir . 'RestApiTrait.php';
			if ( file_exists( $rest_trait ) ) {
				require_once $rest_trait;
			}

			$class_file = $modules_dir . '/' . $dir . '/' . $dir . '.php';
			if ( file_exists( $class_file ) ) {
				require_once $class_file;
			}

			if ( method_exists( $class, 'register_rest_routes_direct' ) ) {
				$class::register_rest_routes_direct();
			}
		}
	}

	/**
	 * Determine the current post type safely (returns empty string when unknown).
	 */
	private static function get_current_post_type(): string {
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return '';
		}
		if ( is_admin() ) {
			return '';
		}
		$type = get_post_type();
		return $type ?: '';
	}
}
