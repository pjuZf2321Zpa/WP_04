<?php
/**
 * Divi 5 Pro module registration orchestrator.
 *
 * Loaded once by the DiviModulesV5 Manager. Registers Pro modules that override
 * or extend the free plugin's Divi 5 modules.
 *
 * @package WPFunnelsPro\Widgets\DiviModules\D5
 * @since   3.10.6
 */

namespace WPFunnelsPro\Widgets\DiviModules\D5;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

if ( ! defined( 'WPFNL_PRO_DIVI5_MODULES_LOADED' ) ) {

	require_once __DIR__ . '/ModuleRegistry.php';

	// ── Primary: Divi 5 dependency tree (fires at init priority 0) ──────────
	// Register AFTER free plugin modules (priority 10 vs free's 10, but loaded later)
	add_action(
		'divi_module_library_modules_dependency_tree',
		static function ( $dependency_tree ) {
			if ( ! is_object( $dependency_tree ) ) {
				return;
			}
			ModuleRegistry::register_modules( $dependency_tree );
		},
		15, // Higher priority than free plugin to override
		1
	);

	// ── REST API: register routes independently of the dependency tree ───────
	add_action(
		'rest_api_init',
		static function () {
			if ( ! interface_exists( 'ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface' ) ) {
				return;
			}
			ModuleRegistry::register_rest_routes();
		},
		15 // After free plugin
	);

	// ── Fallback: if this file was loaded after init:0 already fired ─────────
	add_action(
		'init',
		static function () {
			static $done = false;
			if ( $done ) {
				return;
			}
			// Use the same detection logic as is_divi5_active()
			$is_divi5 = false;
			if ( function_exists( 'et_builder_d5_enabled' ) ) {
				$is_divi5 = et_builder_d5_enabled();
			} elseif ( interface_exists( 'ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface' ) ) {
				$is_divi5 = true;
			}
			
			if ( ! $is_divi5 ) {
				return;
			}
			ModuleRegistry::register_modules( null );
			$done = true;
		},
		25 // After free plugin's fallback
	);

	// ── D4 → D5 shortcode conversion map (Pro modules use same slugs) ────────
	// The free plugin already registers wpfnl_offer_button → wpfnl/offer-button
	// No additional conversion needed since Pro uses the same slug

	define( 'WPFNL_PRO_DIVI5_MODULES_LOADED', true );
}
