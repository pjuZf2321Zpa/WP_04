<?php
/**
 * Namespace for the OfferButton class.
 * This class is part of the WPFunnels\Widgets\Bricks namespace.
 */
namespace WPFunnelsPro\Widgets\Bricks;

require_once get_template_directory() . '/includes/elements/base.php';

use \Bricks\Element;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Wpfnl_Pro_functions;

if (! defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Class OfferButton
 * 
 * Represents a OfferButton element in the WP Funnels plugin.
 * This class extends the Element class.
 * 
 * @package WPFunnels\Widgets\Bricks
 */
class OfferButton extends Element {

    // Element properties
    public $category     = 'wpfunnels'; // Use predefined element category 'general'
    public $name         = 'wpfnl_offer_button'; // Make sure to prefix your elements
    public $icon         = 'fa-solid fa-cart-shopping'; // Themify icon font class
    public $scripts      = []; // Script(s) run when element is rendered on frontend or updated in builder
	public $css_selector = '.wpfnl-offerbtn-wrapper .wpfunnels_offer_button';
    public $tag         = 'button';


     /**
     * Return localised element label
     * 
     * @return string
     * @since 2.1.0
     */
    public function get_label()
    {
        return esc_html__('Offer Button', 'wpfnl-pro');
    }

	/**
	 * Get WordPress user roles for display condition.
	 *
	 * @return array
	 */
	protected function get_wp_user_roles_for_offer() {
		$roles = [ 'none' => esc_html__( 'None', 'wpfnl-pro' ) ];

		if ( ! function_exists( 'get_editable_roles' ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		foreach ( get_editable_roles() as $role_key => $role_info ) {
			$roles[ $role_key ] = $role_info['name'];
		}

		return $roles;
	}

	
	/**
     * Set builder control groups
     * 
     * @since 3.1.0
      * @access public
     */
    public function set_control_groups(){
		$this->control_groups['settings'] = [
			'title' => esc_html__( 'Settings', 'wpfnl' ),
			'tab'   => 'content',
		];

		$this->control_groups['offer_button_style'] = [
            'title' => esc_html__('Offer Button Style', 'wpfnl-pro'),
            'tab' => 'style',
        ];

		$this->control_groups['subtitle_style'] = [
			'title'    => esc_html__( 'Subtitle Style', 'wpfnl' ),
			'tab'      => 'content',
			'required' => [ 'enable_subtitle', '=', true ],
		];

		$this->control_groups['dynamic_data_template_style'] = [
            'title' => esc_html__('Dynamic Template Style', 'wpfnl-pro'),
            'tab' => 'style',
			'required' => [ 'show_product_data' ],
        ];

	}


    /**
     * Set builder controls
     * 
     * @since 2.1.0
     */
    public function set_controls() {
		$this->controls['offer_button_type'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label' => esc_html__( 'Button Type', 'wpfnl-pro' ),
			'type' => 'select',
			'options' => [
			  'upsell' => esc_html__( 'Upsell', 'wpfnl-pro' ),
			  'downsell' => esc_html__( 'Downsell', 'wpfnl-pro' ),
			],
			'inline' => true,
			'default' => 'upsell',
		];
		$this->controls['offer_type'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label' => esc_html__( 'Button action', 'wpfnl-pro' ),
			'type' => 'select',
			'options' => [
			  'accept' => esc_html__( 'Accept', 'wpfnl-pro' ),
			  'reject' => esc_html__( 'Reject', 'wpfnl-pro' ),
			],
			'inline' => true,
		];

        //separator
        $this->controls['buttonTypeSeparator'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'type'  => 'separator',
		];

        //---button content---
		$this->controls['text'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Button Title', 'wpfnl-pro' ),
			'type'        => 'text',
			'default'     => esc_html__( 'Accept Offer', 'wpfnl-pro' ),
			'placeholder' => esc_html__( 'Accept Offer', 'wpfnl-pro' ),
		];

        // separator
		$this->controls['gbfSeparator'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'type'  => 'separator',
			'required' => [ 'offer_type', '=', 'accept' ],
		];

        $get_product_type = Wpfnl_Pro_functions::get_offer_product_type( $this->post_id );
        if( $get_product_type == 'variable' || $get_product_type == 'variable-subscription' ){
            $this->controls['variation_tbl_title'] = [
				'tab'         => 'content',
				'group'       => 'settings',
                'tab' => 'content',
                'label' => esc_html__( 'Variation Table Title', 'wpfnl-pro' ),
                'type' => 'textarea',
                'spellcheck' => true,
                'inlineEditing' => true,
                'required' => [ 'offer_type', '=', 'accept' ],
            ];
        }

        $this->controls['show_product_price'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label' => esc_html__( 'Show Product Price', 'wpfnl-pro' ),
			'type'  => 'checkbox',
			'reset' => true,
            'required' => [ 'offer_type', '=', 'accept' ],
		];

        $this->controls['product_price_alignment'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label' => esc_html__( 'Price Alignment', 'wpfnl-pro' ),
			'type' => 'select',
			'options' => [
			  '' => esc_html__( 'On The Left Of Button', 'wpfnl-pro' ),
			  'price-right' => esc_html__( 'On The Right Of Button', 'wpfnl-pro' ),
			  'price-top' => esc_html__( 'Above The Button', 'wpfnl-pro' ),
			  'price-bottom' => esc_html__( 'Below The Button', 'wpfnl-pro' ),
			],
			'inline' => false,
            'required' => [ 'show_product_price' ],
		];

		// separator
		$this->controls['dynamicDataSeparator'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'type'  => 'separator',
			'required' => [ 'offer_type', '=', 'accept' ],
		];

        $funnel_id  = get_post_meta( $this->post_id, '_funnel_id', true );
        $is_gbf = get_post_meta( $funnel_id, 'is_global_funnel', true );

        if( 'yes' === $is_gbf ){
            $this->controls['show_product_data'] = [
				'tab'         => 'content',
				'group'       => 'settings',
                'label' => esc_html__( 'Show Product Data', 'wpfnl-pro' ),
                'type'  => 'checkbox',
                'reset' => true,
                'required' => [ 'offer_type', '=', 'accept' ],
            ];
        }

		$this->controls['dynamic_data_template_layout'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label' => esc_html__( 'Select Template Style', 'wpfnl-pro' ),
			'type' => 'select',
			'options' => [
			  'style1' => esc_html__( 'Left Image Right Content', 'wpfnl-pro' ),
			  'style2' => esc_html__( 'Left Content Right Image', 'wpfnl-pro' ),
			  'style3' => esc_html__( 'Top Image Bottom Content', 'wpfnl-pro' ),
			],
			'default' => 'style1',
			'inline' => false,
            'required' => [ 'show_product_data' ],
		];

		// ---- Icon ----
		$this->controls['iconSeparator'] = [
			'tab'   => 'content',
			'group' => 'settings',
			'type'  => 'separator',
			'label' => esc_html__( 'Icon', 'wpfnl' ),
		];

		$this->controls['icon'] = [
			'tab'   => 'content',
			'group' => 'settings',
			'label' => esc_html__( 'Icon', 'wpfnl' ),
			'type'  => 'icon',
		];

		$this->controls['iconPosition'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Icon Position', 'wpfnl' ),
			'type'        => 'select',
			'options'     => $this->control_options['iconPosition'],
			'inline'      => true,
			'placeholder' => esc_html__( 'Right', 'wpfnl' ),
			'required'    => [ 'icon', '!=', '' ],
		];

		// ---- Subtitle ----
		$this->controls['subtitleSeparator'] = [
			'tab'   => 'content',
			'group' => 'settings',
			'type'  => 'separator',
			'label' => esc_html__( 'Subtitle', 'wpfnl' ),
		];

		$this->controls['enable_subtitle'] = [
			'tab'     => 'content',
			'group'   => 'settings',
			'label'   => esc_html__( 'Enable Subtitle', 'wpfnl' ),
			'type'    => 'checkbox',
			'default' => false,
		];

		$this->controls['subtitle_text'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Subtitle Text', 'wpfnl' ),
			'type'        => 'text',
			'default'     => esc_html__( 'Click to continue', 'wpfnl' ),
			'placeholder' => esc_html__( 'Enter subtitle text', 'wpfnl' ),
			'required'    => [ 'enable_subtitle', '=', true ],
		];

		// ---- Subtitle Style (group) ----
		$this->controls['subtitleTypography'] = [
			'tab'      => 'content',
			'group'    => 'subtitle_style',
			'label'    => esc_html__( 'Subtitle Typography', 'wpfnl' ),
			'type'     => 'typography',
			'css'      => [
				[
					'property' => 'font',
					'selector' => '.wpfnl-button-subtitle',
				],
			],
			'exclude'  => [ 'text-align', 'text-decoration', 'line-height' ],
		];

		$this->controls['subtitleSpacing'] = [
			'tab'      => 'content',
			'group'    => 'subtitle_style',
			'label'    => esc_html__( 'Subtitle Spacing Top', 'wpfnl' ),
			'type'     => 'number',
			'units'    => true,
			'css'      => [
				[
					'property' => 'margin-top',
					'selector' => '.wpfnl-button-subtitle',
				],
			],
			'default'  => '2px',
		];

		// ---- Responsive Display ----
		$this->controls['responsiveSeparator'] = [
			'tab'   => 'content',
			'group' => 'settings',
			'label' => esc_html__( 'Responsive Display', 'wpfnl-pro' ),
			'type'  => 'separator',
		];

		$this->controls['hide_on_desktop'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Hide on Desktop (≥ 1200px)', 'wpfnl-pro' ),
			'type'        => 'checkbox',
			'default'     => false,
			'description' => esc_html__( 'Hide button on desktop devices (window width >= 1200px)', 'wpfnl-pro' ),
		];

		$this->controls['hide_on_tablet'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Hide on Tablet (768px – 1199px)', 'wpfnl-pro' ),
			'type'        => 'checkbox',
			'default'     => false,
			'description' => esc_html__( 'Hide button on tablet devices (window width 768px - 1199px)', 'wpfnl-pro' ),
		];

		$this->controls['hide_on_mobile'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Hide on Mobile (≤ 767px)', 'wpfnl-pro' ),
			'type'        => 'checkbox',
			'default'     => false,
			'description' => esc_html__( 'Hide button on mobile devices (window width <= 767px)', 'wpfnl-pro' ),
		];

		// ---- Display Conditions ----
		$this->controls['displayConditionSeparator'] = [
			'tab'   => 'content',
			'group' => 'settings',
			'label' => esc_html__( 'Display Conditions', 'wpfnl-pro' ),
			'type'  => 'separator',
		];

		$this->controls['display_condition_type'] = [
			'tab'     => 'content',
			'group'   => 'settings',
			'label'   => esc_html__( 'Display Condition', 'wpfnl-pro' ),
			'type'    => 'select',
			'options' => [
				'none'             => esc_html__( 'None', 'wpfnl-pro' ),
				'user_state'       => esc_html__( 'User State', 'wpfnl-pro' ),
				'user_role'        => esc_html__( 'User Role', 'wpfnl-pro' ),
				'browser'          => esc_html__( 'Browser', 'wpfnl-pro' ),
				'operating_system' => esc_html__( 'Operating System', 'wpfnl-pro' ),
				'day'              => esc_html__( 'Day', 'wpfnl-pro' ),
			],
			'inline'  => false,
			'default' => 'none',
		];

		$this->controls['hide_from_logged_in'] = [
			'tab'      => 'content',
			'group'    => 'settings',
			'label'    => esc_html__( 'Hide From Logged In User', 'wpfnl-pro' ),
			'type'     => 'checkbox',
			'default'  => false,
			'required' => [ 'display_condition_type', '=', 'user_state' ],
		];

		$this->controls['hide_from_logged_out'] = [
			'tab'      => 'content',
			'group'    => 'settings',
			'label'    => esc_html__( 'Hide From Logged Out User', 'wpfnl-pro' ),
			'type'     => 'checkbox',
			'default'  => false,
			'required' => [ 'display_condition_type', '=', 'user_state' ],
		];

		$this->controls['hide_for_user_role'] = [
			'tab'      => 'content',
			'group'    => 'settings',
			'label'    => esc_html__( 'Hide For User Role', 'wpfnl-pro' ),
			'type'     => 'select',
			'options'  => $this->get_wp_user_roles_for_offer(),
			'default'  => 'none',
			'required' => [ 'display_condition_type', '=', 'user_role' ],
		];

		$this->controls['hide_on_browser'] = [
			'tab'      => 'content',
			'group'    => 'settings',
			'label'    => esc_html__( 'Hide On Browser', 'wpfnl-pro' ),
			'type'     => 'select',
			'options'  => [
				'none'       => esc_html__( 'None', 'wpfnl-pro' ),
				'mozilla'    => esc_html__( 'Mozilla Firefox', 'wpfnl-pro' ),
				'chrome'     => esc_html__( 'Google Chrome', 'wpfnl-pro' ),
				'opera_mini' => esc_html__( 'Opera Mini', 'wpfnl-pro' ),
				'safari'     => esc_html__( 'Safari', 'wpfnl-pro' ),
				'edge'       => esc_html__( 'Microsoft Edge', 'wpfnl-pro' ),
			],
			'default'  => 'none',
			'required' => [ 'display_condition_type', '=', 'browser' ],
		];

		$this->controls['hide_on_os'] = [
			'tab'      => 'content',
			'group'    => 'settings',
			'label'    => esc_html__( 'Hide On Operating System', 'wpfnl-pro' ),
			'type'     => 'select',
			'options'  => [
				'none'    => esc_html__( 'None', 'wpfnl-pro' ),
				'ios'     => esc_html__( 'iOS', 'wpfnl-pro' ),
				'android' => esc_html__( 'Android', 'wpfnl-pro' ),
				'windows' => esc_html__( 'Windows', 'wpfnl-pro' ),
				'macos'   => esc_html__( 'MacOS', 'wpfnl-pro' ),
				'linux'   => esc_html__( 'Linux', 'wpfnl-pro' ),
				'sunos'   => esc_html__( 'SunOS', 'wpfnl-pro' ),
				'openbsd' => esc_html__( 'OpenBSD', 'wpfnl-pro' ),
			],
			'default'  => 'none',
			'required' => [ 'display_condition_type', '=', 'operating_system' ],
		];

		$this->controls['disable_on_days'] = [
			'tab'      => 'content',
			'group'    => 'settings',
			'label'    => esc_html__( 'Select Days You Want To Disable', 'wpfnl-pro' ),
			'type'     => 'select',
			'multiple' => true,
			'options'  => [
				'monday'    => esc_html__( 'Monday', 'wpfnl-pro' ),
				'tuesday'   => esc_html__( 'Tuesday', 'wpfnl-pro' ),
				'wednesday' => esc_html__( 'Wednesday', 'wpfnl-pro' ),
				'thursday'  => esc_html__( 'Thursday', 'wpfnl-pro' ),
				'friday'    => esc_html__( 'Friday', 'wpfnl-pro' ),
				'saturday'  => esc_html__( 'Saturday', 'wpfnl-pro' ),
				'sunday'    => esc_html__( 'Sunday', 'wpfnl-pro' ),
			],
			'default'  => [],
			'required' => [ 'display_condition_type', '=', 'day' ],
		];

		// ---- Animation ----
		$this->controls['animationSeparator'] = [
			'tab'   => 'content',
			'group' => 'settings',
			'label' => esc_html__( 'Animation', 'wpfnl-pro' ),
			'type'  => 'separator',
		];

		$this->controls['entrance_animation'] = [
			'tab'         => 'content',
			'group'       => 'settings',
			'label'       => esc_html__( 'Entrance Animation', 'wpfnl-pro' ),
			'type'        => 'select',
			'options'     => [
				''            => esc_html__( 'None', 'wpfnl-pro' ),
				'fadeIn'      => esc_html__( 'Fade In', 'wpfnl-pro' ),
				'fadeInUp'    => esc_html__( 'Fade In Up', 'wpfnl-pro' ),
				'fadeInDown'  => esc_html__( 'Fade In Down', 'wpfnl-pro' ),
				'fadeInLeft'  => esc_html__( 'Fade In Left', 'wpfnl-pro' ),
				'fadeInRight' => esc_html__( 'Fade In Right', 'wpfnl-pro' ),
				'zoomIn'      => esc_html__( 'Zoom In', 'wpfnl-pro' ),
				'zoomInUp'    => esc_html__( 'Zoom In Up', 'wpfnl-pro' ),
				'bounceIn'    => esc_html__( 'Bounce In', 'wpfnl-pro' ),
				'bounceInUp'  => esc_html__( 'Bounce In Up', 'wpfnl-pro' ),
				'slideInUp'   => esc_html__( 'Slide In Up', 'wpfnl-pro' ),
				'slideInLeft' => esc_html__( 'Slide In Left', 'wpfnl-pro' ),
				'slideInRight'=> esc_html__( 'Slide In Right', 'wpfnl-pro' ),
				'flipInX'     => esc_html__( 'Flip In X', 'wpfnl-pro' ),
				'flipInY'     => esc_html__( 'Flip In Y', 'wpfnl-pro' ),
				'pulse'       => esc_html__( 'Pulse', 'wpfnl-pro' ),
				'tada'        => esc_html__( 'Tada', 'wpfnl-pro' ),
				'wobble'      => esc_html__( 'Wobble', 'wpfnl-pro' ),
			],
			'inline'      => false,
			'placeholder' => esc_html__( 'None', 'wpfnl-pro' ),
			'default'     => '',
			'description' => esc_html__( 'Animation plays when the button enters the viewport on the live page.', 'wpfnl-pro' ),
		];


		//---------offer button style controls---------
        $this->register_offer_button_style();

		//---------subtitle style controls---------
        $this->register_subtitle_style();

		//---------daynamic data template style controls---------
        $this->register_dynamic_data_template_style();

	}


	/**
     * Register Offer Button Style Control.
     *
     * @since 3.1.0
     * @access public
     */
    protected function register_offer_button_style(){
		$this->controls['offer_button_Typography'] = [
			'group' => 'offer_button_style',
			'label' => esc_html__( 'Typography', 'wpfnl-pro' ),
			'type'  => 'typography',
			'css'   => [
				[
					'property' => 'font',
					'selector' => '.bricks-button',
				]
			],
		];
		$this->controls['offer_button_bg'] = [
			'group' => 'offer_button_style',
			'label' => esc_html__( 'Background', 'wpfnl-pro' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.bricks-button',
				]
			],
		];
		$this->controls['offer_button_border'] = [
			'group' => 'offer_button_style',
			'label' => esc_html__( 'Border', 'wpfnl-pro' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.bricks-button',
				],
			],
		];
		$this->controls['offer_button_margin'] = [
			'group' => 'offer_button_style',
			'label' => esc_html__( 'Margin', 'wpfnl-pro' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'margin',
					'selector' => '.bricks-button',
				],
			],
		];
		$this->controls['offer_button_padding'] = [
			'group' => 'offer_button_style',
			'label' => esc_html__( 'Padding', 'wpfnl-pro' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.bricks-button',
				],
			],
		];

        
	}
	

	/**
     * Register Subtitle Style Control.
     *
     * @since 3.1.0
     * @access protected
     */
    protected function register_subtitle_style() {
		$this->controls['subtitleTypography'] = [
			'group'    => 'subtitle_style',
			'label'    => esc_html__( 'Subtitle Typography', 'wpfnl-pro' ),
			'type'     => 'typography',
			'css'      => [
				[
					'property' => 'font',
					'selector' => '.wpfnl-button-subtitle',
				],
			],
			'exclude'  => [ 'text-align', 'text-decoration', 'line-height' ],
			'required' => [ 'enable_subtitle', '=', true ],
		];

		$this->controls['subtitleSpacing'] = [
			'group'    => 'subtitle_style',
			'label'    => esc_html__( 'Subtitle Spacing Top', 'wpfnl-pro' ),
			'type'     => 'number',
			'units'    => true,
			'css'      => [
				[
					'property' => 'margin-top',
					'selector' => '.wpfnl-button-subtitle',
				],
			],
			'default'  => '2px',
			'required' => [ 'enable_subtitle', '=', true ],
		];
	}

	/**
     * Register Dynamic Data Template Style Control.
     *
     * @since 3.1.0
     * @access public
     */
    public function register_dynamic_data_template_style(){
		// separator
		$this->controls['layout_separator'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Layout Style', 'wpfnl-pro' ),
			'type'  => 'separator',
		];

		$this->controls['template_layout_bg'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Background', 'wpfnl-pro' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.dynamic-offer-template-default',
				]
			],
		];

		$this->controls['template_left_col_width'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Image Column Width', 'wpfnl-pro' ),
			'type'  => 'number',
			'min' => 0,
			'inline' => true,
			'css' => [
				[
					'property' => 'width',
					'selector' => '.dynamic-offer-template-default .template-left',
				],
			],
		];
		$this->controls['template_right_col_width'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Content Column Width', 'wpfnl-pro' ),
			'type'  => 'number',
			'min' => 0,
			'inline' => true,
			'css' => [
				[
					'property' => 'width',
					'selector' => '.dynamic-offer-template-default .template-right',
				],
			],
		];
		$this->controls['template_col_gutter_width'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Column Gap', 'wpfnl-pro' ),
			'type'  => 'number',
			'min' => 0,
			'inline' => true,
			'css' => [
				[
					'property' => 'gap',
					'selector' => '.dynamic-offer-template-default',
				]
			],
		];

		$this->controls['template_layout_border'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Border', 'wpfnl-pro' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.dynamic-offer-template-default',
				],
			],
		];

		$this->controls['template_layout_shadow'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Box Shadow', 'wpfnl-pro' ),
			'type' => 'box-shadow',
			'css'   => [
				[
					'property' => 'box-shadow',
					'selector' => '.dynamic-offer-template-default',
				]
				
			],
			'inline' => true,
			'small' => true,
			'default' => [
			  'values' => [
				'offsetX' => 0,
				'offsetY' => 0,
				'blur' => 2,
				'spread' => 0,
			  ],
			  'color' => [
				'rgb' => 'rgba(0, 0, 0, .1)',
			  ],
			],
		];

		$this->controls['template_layout_padding'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Padding', 'wpfnl-pro' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.dynamic-offer-template-default',
				]
			],
		];

		$this->controls['template_layout_margin'] = [
			'group' => 'dynamic_data_template_style',
			'label'       => esc_html__( 'Margin', 'wpfnl-pro' ),
			'type'        => 'spacing',
			'css'         => [
				[
					'property' => 'margin',
					'selector' => '.dynamic-offer-template-default',
				],
			],
		];

		// separator
		$this->controls['template_image_separator'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Template Image Style', 'wpfnl-pro' ),
			'type'  => 'separator',
		];
		$this->controls['template_image_radius'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Border Radius', 'wpfnl-pro' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.dynamic-offer-template-default .product-img img',
				],
			],
			'exclude'  => [
				'width',
				'style',
				'color',
			],
		];

		// separator
		$this->controls['template_heading_separator'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Heading Style', 'wpfnl-pro' ),
			'type'  => 'separator',
		];
		$this->controls['template_heading_typography'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Typography', 'wpfnl-pro' ),
			'type'  => 'typography',
			'css'   => [
				[
					'property' => 'font',
					'selector' => '.dynamic-offer-template-default .template-content .template-product-title',
				]
			],
		];
		$this->controls['template_heading_margin'] = [
			'group' => 'dynamic_data_template_style',
			'label'       => esc_html__( 'Margin', 'wpfnl-pro' ),
			'type'        => 'spacing',
			'css'         => [
				[
					'property' => 'margin',
					'selector' => '.dynamic-offer-template-default .template-content .template-product-title',
				],
			],
		];

		// separator
		$this->controls['template_description_style'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Description Style', 'wpfnl-pro' ),
			'type'  => 'separator',
		];
		$this->controls['template_description_typography'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Typography', 'wpfnl-pro' ),
			'type'  => 'typography',
			'css'   => [
				[
					'property' => 'font',
					'selector' => '.dynamic-offer-template-default .template-content .template-product-description',
				]
			],
		];
		$this->controls['template_description_margin'] = [
			'group' => 'dynamic_data_template_style',
			'label'       => esc_html__( 'Margin', 'wpfnl-pro' ),
			'type'        => 'spacing',
			'css'         => [
				[
					'property' => 'margin',
					'selector' => '.dynamic-offer-template-default .template-content .template-product-description',
				],
			],
		];

		// separator
		$this->controls['template_price_style'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Price Style', 'wpfnl-pro' ),
			'type'  => 'separator',
		];
		$this->controls['template_discount_price_typography'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Discount Price Typography', 'wpfnl-pro' ),
			'type'  => 'typography',
			'css'   => [
				[
					'property' => 'font',
					'selector' => '.dynamic-offer-template-default #wpfnl-offerbtn-wrapper .wpfnl-offer-product-price bdi',
				]
			],
		];
		$this->controls['template_price_typography'] = [
			'group' => 'dynamic_data_template_style',
			'label' => esc_html__( 'Regular Price Typography', 'wpfnl-pro' ),
			'type'  => 'typography',
			'css'   => [
				[
					'property' => 'font',
					'selector' => '.dynamic-offer-template-default #wpfnl-offerbtn-wrapper .wpfnl-offer-product-price del bdi',
				],
				[
					'property' => 'font',
					'selector' => '.dynamic-offer-template-default #wpfnl-offerbtn-wrapper .wpfnl-offer-product-price',
				]
			],
		];
		$this->controls['template_price_margin'] = [
			'group' => 'dynamic_data_template_style',
			'label'       => esc_html__( 'Margin', 'wpfnl-pro' ),
			'type'        => 'spacing',
			'css'         => [
				[
					'property' => 'margin',
					'selector' => '.dynamic-offer-template-default #wpfnl-offerbtn-wrapper .wpfnl-offer-product-price',
				],
			],
		];
		

	}

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 2.1.0
     *
     * @access public
     */
    public function render() {
		$settings = $this->settings;

		// ---- Display Conditions ----
		$display_condition = ! empty( $settings['display_condition_type'] ) ? $settings['display_condition_type'] : 'none';

		if ( $display_condition === 'user_state' ) {
			$hide_logged_in  = ! empty( $settings['hide_from_logged_in'] );
			$hide_logged_out = ! empty( $settings['hide_from_logged_out'] );
			if ( $hide_logged_in && is_user_logged_in() ) { return; }
			if ( $hide_logged_out && ! is_user_logged_in() ) { return; }

		} elseif ( $display_condition === 'user_role' ) {
			$hide_for_user_role = ! empty( $settings['hide_for_user_role'] ) ? $settings['hide_for_user_role'] : 'none';
			if ( $hide_for_user_role !== 'none' && is_user_logged_in() ) {
				$user = wp_get_current_user();
				if ( in_array( $hide_for_user_role, $user->roles ) ) { return; }
			}

		} elseif ( $display_condition === 'day' ) {
			$disable_on_days = ! empty( $settings['disable_on_days'] ) ? $settings['disable_on_days'] : [];
			if ( ! empty( $disable_on_days ) && is_array( $disable_on_days ) ) {
				if ( in_array( strtolower( date( 'l' ) ), $disable_on_days ) ) { return; }
			}

		} elseif ( $display_condition === 'browser' ) {
			$hide_on_browser = ! empty( $settings['hide_on_browser'] ) ? $settings['hide_on_browser'] : 'none';
			if ( $hide_on_browser !== 'none' ) {
				$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';
				$cb = '';
				if ( strpos( $ua, 'edg' ) !== false )                                          { $cb = 'edge'; }
				elseif ( strpos( $ua, 'opr' ) !== false || strpos( $ua, 'opera' ) !== false )  { $cb = 'opera_mini'; }
				elseif ( strpos( $ua, 'chrome' ) !== false )                                   { $cb = 'chrome'; }
				elseif ( strpos( $ua, 'safari' ) !== false )                                   { $cb = 'safari'; }
				elseif ( strpos( $ua, 'firefox' ) !== false )                                  { $cb = 'mozilla'; }
				if ( $cb === $hide_on_browser ) { return; }
			}

		} elseif ( $display_condition === 'operating_system' ) {
			$hide_on_os = ! empty( $settings['hide_on_os'] ) ? $settings['hide_on_os'] : 'none';
			if ( $hide_on_os !== 'none' ) {
				$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';
				$co = '';
				if ( strpos( $ua, 'windows' ) !== false || strpos( $ua, 'win32' ) !== false || strpos( $ua, 'win64' ) !== false ) { $co = 'windows'; }
				elseif ( strpos( $ua, 'macintosh' ) !== false || strpos( $ua, 'mac os x' ) !== false )                           { $co = 'macos'; }
				elseif ( strpos( $ua, 'linux' ) !== false && strpos( $ua, 'android' ) === false )                                { $co = 'linux'; }
				elseif ( strpos( $ua, 'android' ) !== false )                                                                    { $co = 'android'; }
				elseif ( strpos( $ua, 'iphone' ) !== false || strpos( $ua, 'ipad' ) !== false || strpos( $ua, 'ipod' ) !== false ) { $co = 'ios'; }
				elseif ( strpos( $ua, 'sunos' ) !== false )                                                                      { $co = 'sunos'; }
				elseif ( strpos( $ua, 'openbsd' ) !== false )                                                                    { $co = 'openbsd'; }
				if ( $co === $hide_on_os ) { return; }
			}
		}
		// ---- End Display Conditions ----

		// offer button
		$offer_button_classes[] = 'bricks-button wpfunnels_offer_button';

		// Add subtitle class via set_attribute so it merges with render_attributes
		if ( ! empty( $settings['enable_subtitle'] ) && ! empty( $settings['subtitle_text'] ) ) {
			$offer_button_classes[] = 'wpfnl-has-subtitle';
		}

		$this->set_attribute( 'offer-button', 'class', $offer_button_classes );

		// Responsive display classes on the root wrapper
		if ( ! empty( $settings['hide_on_desktop'] ) ) {
			$this->set_attribute( '_root', 'class', 'wpfnl-hide-desktop' );
		}
		if ( ! empty( $settings['hide_on_tablet'] ) ) {
			$this->set_attribute( '_root', 'class', 'wpfnl-hide-tablet' );
		}
		if ( ! empty( $settings['hide_on_mobile'] ) ) {
			$this->set_attribute( '_root', 'class', 'wpfnl-hide-mobile' );
		}

		// Animation class on root
		$animation = ! empty( $settings['entrance_animation'] ) ? $settings['entrance_animation'] : '';
		if ( $animation ) {
			$this->set_attribute( '_root', 'class', 'wpfnl-animation ' . esc_attr( $animation ) );
		}
		$is_bricks_editor = isset( $_GET['bricks'] ) && 'run' === $_GET['bricks'];
		if ( $is_bricks_editor ) {
			$this->set_attribute( '_root', 'class', 'bricks-editor-active' );
		}

        $response = Wpfnl_Pro_functions::get_product_data_for_widget( $this->post_id );
        $offer_product       = isset($response['offer_product']) && $response['offer_product'] ? $response['offer_product'] : '';
        $get_product_type    = isset($response['get_product_type']) && $response['get_product_type'] ? $response['get_product_type'] : '';
        $is_gbf              = isset($response['is_gbf']) && $response['is_gbf'] ? $response['is_gbf'] : '';
        $builder = 'bricks';
        
		echo '<div ' . $this->render_attributes( '_root' ) . '>';
			if( 'yes' == $is_gbf && isset($settings['show_product_data']) && $settings['show_product_data'] && $settings['offer_type'] == 'accept' ){ 
				require WPFNL_PRO_DIR . 'public/modules/dynamic-offer-templates/styles/offer-' . $settings['dynamic_data_template_layout'] . '.php';
			}else{
				require WPFNL_PRO_DIR . 'public/modules/dynamic-offer-templates/bricks/offer-button.php';
			}
		echo '</div>';
	}

}
