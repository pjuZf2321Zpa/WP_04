<?php
namespace WPFunnelsPro\Widgets\Gutenberg\BlockTypes;

use WPFunnels\lms\helper\Wpfnl_lms_learndash_functions;
use WPFunnelsPro\OfferProduct\Wpfnl_Offer_Product;
use WPFunnelsPro\Wpfnl_Pro_functions;
use function \CodeRex\Ecommerce\ecommerce;
/**
 * OrderDetails class.
 */
class LmsOfferButton extends AbstractBlock {

    protected $defaults = array(
        'buttonAlign' => 'center',
        'buttonTextAlign' => 'center',
        'buttonText' => 'I will pass',
        'offerAction' => 'accept',
        'offerType' => 'upsell',
        'buttonColor' => '#39414d',
        'buttonTextColor' => '#fff',
        'paddingTopBottom' => 14,
        'paddingLeftRight' => 25,
        'buttonRadius' => 5,

    );

    /**
     * Block name.
     *
     * @var string
     */
    protected $block_name = 'lms-offer-button';


    public function __construct( $block_name = '' )
    {
        parent::__construct($block_name);
        add_action('wp_ajax_wpfnl_offer_variable_shortcode', [$this, 'render_offer_variable_shortcode']);
        add_action( 'wp_ajax_nopriv_wpfnl_offer_variable_shortcode', [$this, 'render_offer_variable_shortcode'] );
        add_action('wp_ajax_wpfnl_lms_load_offer_checkout', [$this, 'load_creatorlms_offer_checkout']);
        add_action('wp_ajax_nopriv_wpfnl_lms_load_offer_checkout', [$this, 'load_creatorlms_offer_checkout']);
    }

    /**
     * Render the Featured Product block.
     *
     * @param array  $attributes Block attributes.
     * @param string $content    Block content.
     * @return string Rendered block type output.
     */
    protected function render( $attributes, $content ) {
        $attributes = wp_parse_args( $attributes, $this->defaults );
        $dynamic_css = $this->generate_assets($attributes);
        
        ob_start();

        $step_id  = get_the_ID();
        $funnel_id = get_post_meta($step_id,'_funnel_id',true);
        $get_learn_dash_setting = Wpfnl_lms_learndash_functions::get_learndash_settings($funnel_id);
        $lms_button_text = get_option( 'learndash_settings_custom_labels' );

        if ($get_learn_dash_setting == 'yes'){
            $step_type = get_post_meta($step_id, '_step_type', true);
            if ($step_type != 'upsell' && $step_type != 'downsell'){
                echo __('Sorry, Please place the element in WPFunnels Offer page');
            }else{
                $button_action         = isset($attributes['offerAction']) ? $attributes['offerAction'] : 'accept' ;

                if ($button_action == 'accept'){
                    // Get course and detect provider
                    $lms_product_id = get_post_meta($step_id,'_wpfnl_upsell_products',true);
                    if ($step_type == 'downsell'){
                        $lms_product_id = get_post_meta($step_id,'_wpfnl_downsell_products',true);
                    }
                    
                    $course_id = isset($lms_product_id[0]['id']) ? $lms_product_id[0]['id'] : 0;
                    $provider_id = isset($lms_product_id[0]['lms_provider']) ? $lms_product_id[0]['lms_provider'] : null;
                  
                    // Detect provider from post type if not set
                    if (!$provider_id && $course_id) {
                        $course_post_type = get_post_type($course_id);
                        $provider_id = ($course_post_type === 'crlms-course') ? 'creatorlms' : 'learndash';
                    }
                    
                    // Get button text based on provider
                    if ($provider_id === 'learndash') {
                        $button_text = !empty($lms_button_text['button_take_this_course']) ? $lms_button_text['button_take_this_course'] : "Take this course";
                    } else {
                        $button_text = __('Accept Offer', 'wpfnl-pro');
                    }
                    
                    // Check course access based on provider
                    $course_access = false;
                    if ($provider_id === 'learndash' && function_exists('sfwd_lms_has_access')) {
                        $course_access = sfwd_lms_has_access($course_id, get_current_user_id());
                    } elseif ($provider_id === 'creatorlms' && class_exists('\WPFunnels\lms\providers\CreatorLMS_Provider')) {
                        $provider = new \WPFunnels\lms\providers\CreatorLMS_Provider();
                        $course_access = $provider->is_enrolled(get_current_user_id(), $course_id);
                    }
                    
                    $next_step_url = Wpfnl_lms_learndash_functions::get_next_step_url($funnel_id,$step_id).'?wpfnl_ld_payment=free';
                    if ($course_access ){
                        echo '<a class="btn-default btn-join" href="'.$next_step_url.'" id="wpfnl-lms-access-course">'.$button_text.'</a>';
                        echo '<span class="wpfnl-lms-access-course-message"></span>';
                    }else{

                        if( $this->is_learndash_bilder_mode() ) {
                            echo '<div class="learndash-block-inner"><a class="btn-join" href="#" id="btn-join"> '.$button_text.'</a></div>';

                        } else {
                            echo '<div class="wpfnl-lms-offer-btn-wrapper align-'.$attributes['buttonAlign'].'">';
                            
                            // Get course details based on provider
                            $course = [];
                            if ($provider_id === 'creatorlms' && class_exists('\WPFunnels\lms\providers\CreatorLMS_Provider')) {
                                $provider = new \WPFunnels\lms\providers\CreatorLMS_Provider();
                                $course = $provider->get_course_details($course_id);
                            } elseif ($provider_id === 'learndash' && isset($lms_product_id[0]['id'])) {
                                $course = Wpfnl_lms_learndash_functions::get_course_details_by_id($lms_product_id[0]['id']);
                            }
                            
                            if( !empty($course) ){
                                if( isset($course['type'])  && $course['type'] == 'free' ){
                                    $next_step_url = Wpfnl_lms_learndash_functions::get_next_step_url($funnel_id,$step_id);
                                    echo '<a class="btn-default" href="'.$next_step_url.'" data-user_id="'.get_current_user_id().'" data-step_id="'.$step_id.'" data-course_id="'.$course['id'].'" id="wpfnl-lms-free-course">'.$button_text.'</a>';
                                    echo '<span class="wpfnl-lms-free-course-message"></span>';
                                }
                                else{
                                    // For CreatorLMS, show button that opens modal
                                    if ($provider_id === 'creatorlms') {
                                        echo '<a class="btn-default wpfnl-lms-offer-accept-btn" href="#" data-course_id="'.$course_id.'" data-step_id="'.$step_id.'" data-funnel_id="'.$funnel_id.'" data-offer_type="'.$step_type.'">'.$button_text.'</a>';
                                        
                                        // Add modal structure
                                        $this->render_creatorlms_modal($step_id, $funnel_id, $step_type);
                                    } else {
                                        // For LearnDash, use payment buttons
                                        echo do_shortcode('[learndash_payment_buttons course_id='.$course_id.']');
                                    }
                                }
                            }
                            $attributes['lmsTypography']['spacing']['unit']  = isset($attributes['lmsTypography']['spacing']['unit']) ? $attributes['lmsTypography']['spacing']['unit'] : '';
                            $attributes['lmsTypography']['size']['unit']  = isset($attributes['lmsTypography']['size']['unit']) ? $attributes['lmsTypography']['size']['unit'] : '';
                            $attributes['lmsTypography']['type']  = isset($attributes['lmsTypography']['type']) ? $attributes['lmsTypography']['type'] : '';
                            $attributes['lmsTypography']['family']  = isset($attributes['lmsTypography']['family']) ? $attributes['lmsTypography']['family'] : '';
                            $attributes['lmsTypography']['weight']  = isset($attributes['lmsTypography']['weight']) ? $attributes['lmsTypography']['weight'] : '';
                            $attributes['lmsTypography']['size']['md']  = isset($attributes['lmsTypography']['size']['md']) ? $attributes['lmsTypography']['size']['md'] : '';
                            $attributes['lmsTypography']['transform']  = isset($attributes['lmsTypography']['transform']) ? $attributes['lmsTypography']['transform'] : '';
                            $attributes['lmsTypography']['spacing']['md']  = isset($attributes['lmsTypography']['spacing']['md']) ? $attributes['lmsTypography']['spacing']['md'] : '';
                            
                            echo '<style>
                                    .wpfnl-lms-offer-btn-wrapper.align-right{
                                        text-align:right;
                                    }
                                    .wpfnl-lms-offer-btn-wrapper.align-center{
                                        text-align:center;
                                    }
                                    .wpfnl-lms-offer-btn-wrapper.align-left{
                                        text-align:left;
                                    }
                                    .wpfnl-lms-offer-btn-wrapper input[type=button],
                                    .wpfnl-lms-offer-btn-wrapper .btn-join, 
                                    .wpfnl-lms-offer-btn-wrapper #btn-join,
                                    .wpfnl-lms-offer-btn-wrapper .wpfnl-lms-offer-accept-btn {
                                        background-color:'.$attributes['buttonColor'].'!important;
                                        color:'.$attributes['buttonTextColor'].'!important;
                                        padding:'.$attributes['paddingTopBottom'].'px '.$attributes['paddingLeftRight'].'px;
                                        border-radius:'.$attributes['buttonRadius'].'px;
                                        font-family:'.$attributes['lmsTypography']['family'].','.$attributes['lmsTypography']['type'].';
                                        font-weight:'.$attributes['lmsTypography']['weight'].';
                                        font-size:'.$attributes['lmsTypography']['size']['md'].''.$attributes['lmsTypography']['size']['unit'].';
                                        text-transform:'.$attributes['lmsTypography']['transform'].';
                                        letter-spacing:'.$attributes['lmsTypography']['spacing']['md'].''.$attributes['lmsTypography']['spacing']['unit'].';
                                        text-decoration: none;
                                        display: inline-block;
                                        cursor: pointer;
                                        border: none;
                                    }
                            </style>';

                            if( isset($attributes['outline']) ){
                                echo '<style>
                                    .wpfnl-lms-offer-btn-wrapper input[type=button],
                                    .wpfnl-lms-offer-btn-wrapper .btn-join,
                                    .wpfnl-lms-offer-btn-wrapper .wpfnl-lms-offer-accept-btn {
                                        background-color: transparent !important;
                                        color:'.$attributes['buttonTextColor'].' !important;
                                        border: 2px solid '.$attributes['buttonTextColor'].' !important;
                                    }
                            </style>';
                            }

                            echo '</div>';
                        }
                    }

                }else{
                    echo $content;
                }
            }
        }else{
            echo __('Sorry, Please place the element in WPFunnels when learnDash is active ');
        }
        
        return ob_get_clean();
    }

    public function is_learndash_bilder_mode()
    {

        if (isset($_GET['action']) && $_GET['action'] == 'edit'){
            return  true;
        }
        return false;

    }


    /**
     * Get the styles for the wrapper element (background image, color).
     *
     * @param array       $attributes Block attributes. Default empty array.
     * @return string
     */
    public function get_styles( $attributes ) {
        $style      = '';

        return $style;
    }


    /**
     * Get class names for the block container.
     *
     * @param array $attributes Block attributes. Default empty array.
     * @return string
     */
    public function get_classes( $attributes ) {
        $classes = array( 'wpfnl-block-' . $this->block_name );
        return implode( ' ', $classes );
    }


    /**
     * Extra data passed through from server to client for block.
     *
     * @param array $attributes  Any attributes that currently are available from the block.
     *                           Note, this will be empty in the editor context when the block is
     *                           not in the post content on editor load.
     */
    protected function enqueue_data( array $attributes = [] ) {
        parent::enqueue_data( $attributes );
    }


    /**
     * Get the frontend script handle for this block type.
     *
     * @see $this->register_block_type()
     * @param string $key Data to get, or default to everything.
     * @return array|string
     */
    protected function get_block_type_script( $key = null ) {
        $script = [
            'handle'       => 'wpfnl-offer-button-frontend',
            'path'         => $this->get_block_asset_build_path( 'offer-button-frontend' ),
            'dependencies' => [],
        ];
        return $key ? $script[ $key ] : $script;
    }

    /**
     * render offer product shortcode markup
     * based on type
     *
     */

    public function render_offer_variable_shortcode() {
        check_ajax_referer( 'wpfnl_gb_ajax_nonce', 'nonce' );
        $data = '';
        ob_start();
        echo do_shortcode('[wpf_variable_offer post_id="'.$_POST['id'].'" ]');
        $data = ob_get_clean();
        wp_send_json_success( $data );
    }

    /**
     * Render CreatorLMS checkout modal
     *
     * @param int    $step_id    Step ID
     * @param int    $funnel_id  Funnel ID
     * @param string $offer_type Offer type (upsell/downsell)
     * @since 3.0.0
     */
    private function render_creatorlms_modal($step_id, $funnel_id, $offer_type) {
        ?>
        <div class="wpfnl-lms-offer-checkout-modal" style="display: none;">
            <div class="wpfnl-lms-offer-checkout-modal-inner">
                <div class="wpfnl-lms-offer-checkout-modal-wrapper">
                    <button class="close-modal" type="button">
                        <svg width="12" height="13" fill="none" viewBox="0 0 12 13" xmlns="http://www.w3.org/2000/svg"><path stroke="#7A8B9A" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 1.969l-10 9.99m0-9.99l10 9.99"></path></svg>
                    </button>

                    <h3 class="wpfnl-lms-offer-checkout-title"><?php
                        echo __( 'Complete Your Enrollment', 'wpfnl-pro' );
                    ?></h3>
                    <div class="modal-overflow">
                        <div class="modal-loader">
                            <span class="wpfnl-loader"></span>
                            <h4><?php
                                echo __( 'Loading', 'wpfnl-pro' );
                            ?></h4>
                            <p><?php
                                echo __( 'Please wait...', 'wpfnl-pro' );
                            ?></p>
                        </div>

                        <div class="wpfnl-lms-offer-checkout-content" style="display: none;">
                            <!-- CreatorLMS checkout will be loaded here via AJAX -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .wpfnl-lms-offer-checkout-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .wpfnl-lms-offer-checkout-modal-inner {
                width: 90%;
                max-width: 800px;
                background: #fff;
                border-radius: 8px;
                position: relative;
            }
            .wpfnl-lms-offer-checkout-modal-wrapper {
                padding: 30px;
                position: relative;
            }
            .wpfnl-lms-offer-checkout-modal .close-modal {
                position: absolute;
                top: 15px;
                right: 15px;
                background: none;
                border: none;
                cursor: pointer;
                padding: 5px;
                z-index: 10;
            }
            .wpfnl-lms-offer-checkout-modal .close-modal:hover svg path {
                stroke: #000;
            }
            .wpfnl-lms-offer-checkout-title {
                margin: 0 0 20px;
                font-size: 24px;
                font-weight: 600;
                color: #333;
            }
            .wpfnl-lms-offer-checkout-modal .modal-overflow {
                max-height: 70vh;
                overflow-y: auto;
            }
            .wpfnl-lms-offer-checkout-modal .modal-loader {
                text-align: center;
                padding: 40px 20px;
            }
            .wpfnl-lms-offer-checkout-modal .wpfnl-loader {
                display: inline-block;
                width: 40px;
                height: 40px;
                border: 4px solid #f3f3f3;
                border-top: 4px solid #3b82f6;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
        <?php
    }

    /**
     * Load CreatorLMS checkout in modal via AJAX
     *
     * @since 3.0.0
     */
    public function load_creatorlms_offer_checkout() {
        $course_id = isset($_POST['course_id']) ? intval($_POST['course_id']) : 0;
        $step_id = isset($_POST['step_id']) ? intval($_POST['step_id']) : 0;
        $funnel_id = isset($_POST['funnel_id']) ? intval($_POST['funnel_id']) : 0;
        $offer_type = isset($_POST['offer_type']) ? sanitize_text_field($_POST['offer_type']) : 'upsell';
        
        if (!$course_id || !$step_id) {
            wp_send_json_error(array('message' => __('Invalid course or step', 'wpfnl-pro')));
        }

        
        // Add course to CreatorLMS cart (ecommerce function is imported at the top)
        try {
            // Ensure session is started and initialized
            if (!session_id()) {
                session_start();
            }
            
            // Initialize CreatorLMS session if needed
            if (function_exists('ecommerce') && ecommerce()->session) {
                // Force session cookie to be set
                ecommerce()->session->set_student_session_cookie(true);
            }
            
            $cart = ecommerce()->cart;
            if ($cart) {
                // Empty cart first (CreatorLMS only allows 1 item)
                $cart->empty_cart(true);
                
                // Add course to cart
                $added = $cart->add_to_cart($course_id, 1, array());
                
                if ($added) {
                    // Calculate totals to persist session
                    $cart->calculate_totals();
                    
                    // Force save cart session
                    if (method_exists($cart, 'set_session')) {
                        $cart->set_session();
                    }
                    
                    // Trigger action to save session data
                    do_action('creator_lms_set_cart_cookies', true);
                    
                    // Force save session data immediately
                    if (ecommerce()->session && method_exists(ecommerce()->session, 'save_data')) {
                        ecommerce()->session->save_data();
                    }
                    
                    error_log('WPFunnels: Course added to cart. Cart items: ' . count($cart->get_cart()));
                } else {
                    error_log('WPFunnels: Failed to add course to cart');
                }
            } else {
                error_log('WPFunnels: Cart object not available');
            }
        } catch (\Exception $e) {
            error_log( 'WPFunnels Error adding course to cart: ' . $e->getMessage() );
        }

        // Store offer context for redirect
        set_transient('wpfnl_creatorlms_offer_' . $course_id, array(
            'funnel_id' => $funnel_id,
            'step_id' => $step_id,
            'offer_type' => $offer_type,
            'user_id' => get_current_user_id(),
        ), HOUR_IN_SECONDS);

        set_transient('creatorlms_step_id', $step_id);

        // Ensure Stripe scripts are loaded
        wp_enqueue_script('crlms-checkout');
        
        // Verify cart has items before rendering
        $cart_items = ecommerce()->cart->get_cart();
        if (empty($cart_items)) {
            error_log('WPFunnels: Cart is empty after adding course');
            wp_send_json_error(array(
                'message' => __('Unable to add course to cart. Please try again.', 'wpfnl-pro')
            ));
            return;
        }
        
        // Get Stripe gateway settings to provide localized data
        // Force reload payment gateways to ensure they're available
        $stripe_gateway = null;
        if (function_exists('ecommerce')) {
            $payment_gateways = ecommerce()->payment_gateways();
            if ($payment_gateways) {
                $available_gateways = $payment_gateways->payment_gateways();
                if (isset($available_gateways['stripe'])) {
                    $stripe_gateway = $available_gateways['stripe'];
                }
            }
        }
        
        // Build Stripe configuration inline script
        $stripe_inline_script = '';
        if ($stripe_gateway && !empty($stripe_gateway->publishable_key)) {
            $current_order_id = 0;
            $is_subscription_purchase = false;
            
            // Get cart total safely
            $cart_total = 0;
            try {
                if (function_exists('ecommerce') && ecommerce()->cart) {
                    $cart_total = ecommerce()->cart->get_total('edit');
                }
            } catch (\Exception $e) {
                error_log('WPFunnels: Error getting cart total: ' . $e->getMessage());
            }
            
            $stripe_params = array(
                'publishableKey'        => $stripe_gateway->publishable_key,
                'ajax_url'              => admin_url('admin-ajax.php'),
                'create_intent_nonce'   => wp_create_nonce('crlms_stripe_intents_create_intent_nonce'),
                'handle_success_nonce'  => wp_create_nonce('crlms_stripe_intents_handle_success_nonce'),
                'create_intent_action'  => 'crlms_stripe_intents_create_payment_intent',
                'handle_success_action' => 'crlms_stripe_intents_handle_payment_success',
                'order_id'              => $current_order_id,
                'currency'              => strtolower(function_exists('get_crlms_currency') ? get_crlms_currency() : 'usd'),
                'error_prefix'          => __('Payment error: ', 'creatorlms'),
                'return_url'            => home_url('/'),
                'is_subscription'       => $is_subscription_purchase,
                'amount_in_cents'       => \CreatorLms\Packages\Ecommerce\Helpers\Helper::get_stripe_amount($cart_total)
            );
            
            $stripe_inline_script = sprintf(
                '<script type="text/javascript">var crlms_stripe_intents_params = %s;</script>',
                wp_json_encode($stripe_params)
            );
            
            error_log('WPFunnels: Stripe params created with key: ' . substr($stripe_gateway->publishable_key, 0, 10) . '...');
        } else {
            error_log('WPFunnels: Stripe gateway not available or no publishable key');
        }
        
        // Include Stripe scripts
        $stripe_sdk_tag = '<script type="text/javascript" src="https://js.stripe.com/v3/"></script>';
        
        // Don't include stripe-intents.js as it won't bind to the modal form properly
        // Instead, we'll create a custom handler in the reinit script below
        $stripe_intents_url = CREATOR_LMS_URL . '/packages/e-commerce/assets/js/stripe-intents.js';
        $stripe_intents_tag = sprintf(
            '<script type="text/javascript" src="%s?ver=%s"></script>',
            esc_url($stripe_intents_url),
            CREATOR_LMS_VERSION
        );

        // Render CreatorLMS checkout
        ob_start();
        echo do_shortcode('[creator_lms_checkout]');
        $checkout_html = ob_get_clean();

        // Add script to re-initialize checkout after AJAX load
        $reinit_script = "
        <script type='text/javascript'>
        (function($) {
            // Stripe modal handler
            var stripeModalHandler = {
                stripe: null,
                elements: null,
                paymentElement: null,
                form: null,
                
                init: function() {
                    console.log('WPFunnels: Initializing Stripe modal handler');
                    
                    if (typeof Stripe === 'undefined' || typeof crlms_stripe_intents_params === 'undefined') {
                        console.error('Stripe SDK or params not loaded');
                        return false;
                    }
                    
                    this.stripe = Stripe(crlms_stripe_intents_params.publishableKey);
                    this.form = $('.wpfnl-lms-offer-checkout-modal form.creator-lms-checkout-form, .wpfnl-lms-offer-checkout-modal form.checkout').first();
                    
                    if (!this.form.length) {
                        console.error('Checkout form not found in modal');
                        return false;
                    }
                    
                    console.log('WPFunnels: Form found, setting up Stripe Elements');
                    
                    // Create elements
                    this.elements = this.stripe.elements({
                        mode: 'payment',
                        amount: parseInt(crlms_stripe_intents_params.amount_in_cents || 100),
                        currency: crlms_stripe_intents_params.currency || 'usd',
                        loader: 'always',
                        paymentMethodCreation: 'manual',
                    });
                    
                    // Create and mount payment element
                    this.paymentElement = this.elements.create('payment', {
                        layout: 'accordion',
                    });
                    
                    var elementContainer = $('#payment-element');
                    if (elementContainer.length) {
                        this.paymentElement.mount('#payment-element');
                        elementContainer.prev('p').hide(); // Hide loading message
                        console.log('WPFunnels: Stripe Elements mounted');
                    }
                    
                    // Bind form submit
                    this.bindFormSubmit();
                    
                    return true;
                },
                
                bindFormSubmit: function() {
                    var self = this;
                    
                    // Remove any existing submit handlers
                    this.form.off('submit.wpfnl_stripe');
                    
                    // Add our submit handler
                    this.form.on('submit.wpfnl_stripe', async function(e) {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        
                        console.log('WPFunnels: Form submitting with Stripe');
                        
                        // Check if Stripe is the selected payment method
                        var selectedMethod = $('input[name=\"payment_method\"]:checked').val();
                        if (selectedMethod !== 'stripe') {
                            console.log('WPFunnels: Not Stripe payment, allowing normal submit');
                            self.form.off('submit.wpfnl_stripe');
                            self.form.submit();
                            return;
                        }
                        
                        var submitButton = self.form.find('.creator-lms-place-order-button, #place_order');
                        submitButton.prop('disabled', true);
                        submitButton.find('.creator-lms-loader').show();
                        
                        try {
                            // Submit elements
                            const {error: submitError} = await self.elements.submit();
                            if (submitError) {
                                console.error('Elements submit error:', submitError);
                                self.showError(submitError.message);
                                submitButton.prop('disabled', false);
                                submitButton.find('.creator-lms-loader').hide();
                                return;
                            }
                            
                            // Create payment method
                            const {paymentMethod, error: pmError} = await self.stripe.createPaymentMethod({
                                elements: self.elements,
                            });
                            
                            if (pmError) {
                                console.error('Payment method creation error:', pmError);
                                self.showError(pmError.message);
                                submitButton.prop('disabled', false);
                                submitButton.find('.creator-lms-loader').hide();
                                return;
                            }
                            
                            console.log('WPFunnels: Payment method created:', paymentMethod.id);
                            
                            // Submit form with payment method ID
                            await self.submitWithPaymentMethod(paymentMethod.id);
                            
                        } catch (error) {
                            console.error('Stripe error:', error);
                            self.showError(error.message || 'Payment processing failed');
                            submitButton.prop('disabled', false);
                            submitButton.find('.creator-lms-loader').hide();
                        }
                    });
                },
                
                submitWithPaymentMethod: async function(paymentMethodId) {
                    var self = this;
                    
                    try {
                        const response = await $.ajax({
                            url: crlms_stripe_intents_params.ajax_url,
                            type: 'POST',
                            dataType: 'json',
                            data: self.form.serialize() + '&action=creator_lms_checkout&payment_method=stripe&stripe_source=' + paymentMethodId
                        });
                        
                        console.log('WPFunnels: Server response:', response);
                        
                        if (response.result === 'requires_action' && response.client_secret) {
                            // Handle 3DS or other required actions
                            const {error, paymentIntent} = await self.stripe.confirmPayment({
                                elements: self.elements,
                                clientSecret: response.client_secret,
                                confirmParams: {
                                    return_url: response.return_url || window.location.href,
                                },
                                redirect: 'if_required'
                            });
                            
                            if (error) {
                                self.showError(error.message);
                                var submitButton = self.form.find('.creator-lms-place-order-button, #place_order');
                                submitButton.prop('disabled', false);
                                submitButton.find('.creator-lms-loader').hide();
                            } else if (paymentIntent && paymentIntent.status === 'succeeded') {
                                // Payment succeeded, redirect
                                if (response.redirect) {
                                    window.location.href = response.redirect;
                                }
                            }
                        } else if (response.result === 'succeeded' || response.success) {
                            // Payment succeeded, redirect
                            console.log('WPFunnels: Payment succeeded, redirecting');
                            if (response.redirect) {
                                window.location.href = response.redirect;
                            }
                        } else if (response.message) {
                            self.showError(response.message);
                            var submitButton = self.form.find('.creator-lms-place-order-button, #place_order');
                            submitButton.prop('disabled', false);
                            submitButton.find('.creator-lms-loader').hide();
                        }
                    } catch (error) {
                        console.error('AJAX error:', error);
                        self.showError('Payment processing failed. Please try again.');
                        var submitButton = self.form.find('.creator-lms-place-order-button, #place_order');
                        submitButton.prop('disabled', false);
                        submitButton.find('.creator-lms-loader').hide();
                    }
                },
                
                showError: function(message) {
                    var errorContainer = $('.crlms-notices-wrapper');
                    if (errorContainer.length) {
                        errorContainer.html('<div class=\"crlms-error\">' + message + '</div>');
                    } else {
                        alert(message);
                    }
                    console.error('Stripe error:', message);
                }
            };
            
            $(document).ready(function() {
                console.log('WPFunnels: Re-initializing CreatorLMS checkout in modal');
                
                // Re-bind all event handlers from checkout.js
                var \$checkoutForm = $('.wpfnl-lms-offer-checkout-modal form.checkout, .wpfnl-lms-offer-checkout-modal form.creator-lms-checkout-form');
                if (\$checkoutForm.length) {
                    console.log('WPFunnels: Found checkout form, binding events');
                    
                    // Payment method selection
                    \$checkoutForm.off('click', 'input[name=\"payment_method\"]').on('click', 'input[name=\"payment_method\"]', function(e) {
                        e.stopPropagation();
                        console.log('WPFunnels: Payment method clicked:', $(this).attr('id'));
                        
                        var \$radio = $(this);
                        var gatewayId = \$radio.attr('id').replace('payment_method_', '');
                        
                        \$radio.parents('.creator-lms-single-payment').addClass('selected').siblings().removeClass('selected');

                        if ($('.payment_methods input.input-radio').length > 1) {
                            var target_payment_box = \$radio.parents('.creator-lms-single-payment').find('div.payment_box.' + \$radio.attr('ID')),
                                is_checked = \$radio.is(':checked');

                            if (is_checked && !target_payment_box.is(':visible')) {
                                \$radio.parents('.creator-lms-single-payment').find('div.payment_box').filter(':visible').slideUp();

                                if (is_checked) {
                                    \$radio.parents('.creator-lms-single-payment').siblings().find('div.payment_box').slideUp();
                                    target_payment_box.slideDown(400, function() {
                                        // Initialize Stripe after slideDown animation completes
                                        if (gatewayId === 'stripe') {
                                            console.log('WPFunnels: Payment box visible, initializing Stripe');
                                            stripeModalHandler.init();
                                        }
                                    });
                                }
                            }
                        } else {
                            \$radio.parents('.creator-lms-single-payment').siblings().find('div.payment_box').slideUp();
                            \$radio.parents('.creator-lms-single-payment').find('div.payment_box').slideDown(400, function() {
                                // Initialize Stripe after slideDown animation completes
                                if (gatewayId === 'stripe') {
                                    console.log('WPFunnels: Payment box visible (single), initializing Stripe');
                                    stripeModalHandler.init();
                                }
                            });
                        }

                        if (\$radio.data('order_button_text')) {
                            $('#place_order').text(\$radio.data('order_button_text'));
                        } else {
                            $('#place_order').text($('#place_order').data('value'));
                        }

                        // Trigger payment method selected event
                        console.log('WPFunnels: Triggering payment_method_selected event');
                        $(document.body).trigger('payment_method_selected');
                    });
                    
                    // Auto-trigger click on checked payment method after initialization
                    setTimeout(function() {
                        var \$checkedPayment = $('.wpfnl-lms-offer-checkout-modal input[name=\"payment_method\"]:checked');
                        if (\$checkedPayment.length) {
                            console.log('WPFunnels: Auto-clicking checked payment method');
                            \$checkedPayment.trigger('click');
                        }
                    }, 500);
                }
                
                // Trigger custom event
                $(document).trigger('wpfnl_creatorlms_checkout_loaded');
            });
        })(jQuery);
        </script>
        ";

        wp_send_json_success(array(
            'html' => $stripe_sdk_tag . $stripe_inline_script . $checkout_html . $reinit_script,
        ));
    }


}