<?php
/**
 * Step Content Regenerate REST Controller
 *
 * Handles the in-editor "Regenerate with AI" panel for a single funnel step
 * (Elementor/Bricks/Divi/Gutenberg). This is a standalone feature, distinct
 * from the chat-driven "Create Funnel with AI" flow — extracted out of the
 * old AI_Controller when that controller's funnel-generation code was
 * removed in favor of the AgentLoop/Copilot system.
 *
 * @package WPFunnels\Rest\Controllers
 */

namespace WPFunnels\Rest\Controllers;

use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\AI\Wpfnl_AI_Template_Builder;
use WPFunnels\AI\Settings\AISettings;

class StepContentRegenerateController extends Wpfnl_REST_Controller {

	/**
	 * Endpoint namespace
	 *
	 * @var string
	 */
	protected $namespace = 'wpfunnels/v1';

	/**
	 * Route base
	 *
	 * @var string
	 */
	protected $rest_base = 'ai';

	/**
	 * Register REST routes
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/regenerate-step',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'regenerate_step' ],
					'permission_callback' => [ $this, 'update_items_permissions_check' ],
					'args'                => [
						'step_id'   => [
							'type'              => 'integer',
							'required'          => true,
							'description'       => __( 'WP post ID of the funnel step to regenerate', 'wpfnl-pro' ),
							'sanitize_callback' => 'absint',
						],
						'step_type' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
						'builder'   => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_key',        'default' => '' ],
						'niche'     => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
						'goal'      => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
						'audience'  => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
						'offering'  => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
					],
				],
			]
		);
	}

	/**
	 * Check permissions for editing a step's content.
	 *
	 * @param WP_REST_Request $request Full data about the request
	 * @return bool|WP_Error
	 */
	public function update_items_permissions_check( $request ) {
		if ( ! Wpfnl_functions::wpfnl_rest_check_manager_permissions( 'settings' ) ) {
			return new WP_Error(
				'wpfunnels_rest_cannot_edit',
				__( 'Sorry, you cannot edit AI settings.', 'wpfnl-pro' ),
				[ 'status' => rest_authorization_required_code() ]
			);
		}
		return true;
	}

	/**
	 * Regenerate AI copy + layout for a single funnel step.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function regenerate_step( WP_REST_Request $request ) {
		$provider = AISettings::getActiveProvider();
		if ( empty( $provider ) ) {
			return $this->error_response(
				__( 'AI is not configured. Please connect a provider in WPFunnels → Settings → AI Assistant.', 'wpfnl-pro' ),
				400,
				'ai_not_configured'
			);
		}

		$step_id  = absint( $request->get_param( 'step_id' ) );
		$niche    = trim( $request->get_param( 'niche' ) );
		$goal     = trim( $request->get_param( 'goal' ) );
		$audience = trim( $request->get_param( 'audience' ) );
		$offering = trim( $request->get_param( 'offering' ) );

		// Validate the step exists and is a WPFunnels step
		if ( ! $step_id ) {
			return $this->error_response( __( 'Invalid step ID.', 'wpfnl-pro' ), 400, 'invalid_step' );
		}

		$post = get_post( $step_id );
		if ( ! $post || $post->post_type !== 'wpfnl-steps' ) {
			return $this->error_response( __( 'Invalid step ID.', 'wpfnl-pro' ), 400, 'invalid_step' );
		}

		// Resolve step type (request param → stored meta fallback)
		$step_type = strtolower( trim( $request->get_param( 'step_type' ) ) );
		if ( empty( $step_type ) ) {
			$step_type = strtolower( get_post_meta( $step_id, '_step_type', true ) );
		}
		if ( empty( $step_type ) ) {
			$step_type = 'landing';
		}

		// At least one context field required
		if ( empty( $niche ) && empty( $goal ) && empty( $audience ) && empty( $offering ) ) {
			return $this->error_response(
				__( 'Please fill in at least one field (niche, goal, audience, or offering).', 'wpfnl-pro' ),
				400,
				'missing_context'
			);
		}

		// Load the actual WooCommerce product assigned to this step so the copy
		// is based on the real product rather than generic context fields alone.
		$product_data = $this->load_step_product( $step_id, $step_type );

		// Build copy via a focused, product-aware AI call.
		$user_context = [
			'niche'    => $niche,
			'goal'     => $goal,
			'audience' => $audience,
			'offering' => $offering,
		];

		$copy = $this->call_ai_for_copy( $provider, $step_type, $product_data, $user_context );

		if ( empty( $copy ) ) {
			return $this->error_response(
				__( 'AI returned no usable copy. Try adding more context and regenerate.', 'wpfnl-pro' ),
				500,
				'empty_copy'
			);
		}

		// Persist context so the panel pre-fills on next open
		update_post_meta( $step_id, '_wpfnl_ai_step_context', [
			'niche'    => $niche,
			'goal'     => $goal,
			'audience' => $audience,
			'offering' => $offering,
		] );

		// Determine the active page builder — use the value passed by the editor
		// panel JS; fall back to the global WPFunnels builder setting.
		$builder = sanitize_key( $request->get_param( 'builder' ) );
		if ( empty( $builder ) ) {
			$builder = Wpfnl_functions::get_builder_type() ?: 'gutenberg';
		}

		// Build the page from scratch — complete layout with dedicated WPFunnels
		// widgets, real AI copy, and real product images (placeholder as fallback).
		Wpfnl_AI_Template_Builder::build( $step_id, $step_type, $builder, $copy, $product_data );

		return new WP_REST_Response(
			[
				'success' => true,
				'message' => __( 'Step copy regenerated. Reload the editor to see changes.', 'wpfnl-pro' ),
				'copy'    => $copy,
			],
			200
		);
	}

	/**
	 * Load the WooCommerce product assigned to a funnel step.
	 *
	 * Returns an array with product details, or null if the step type has no
	 * product meta or no product has been assigned yet.
	 *
	 * @param int    $step_id   WP post ID of the step.
	 * @param string $step_type landing|checkout|upsell|downsell|thankyou
	 * @return array|null  Array with keys: id, name, price, description, image_url
	 */
	private function load_step_product( $step_id, $step_type ) {
		$meta_key_map = [
			'checkout' => '_wpfnl_checkout_products',
			'upsell'   => '_wpfnl_upsell_products',
			'downsell' => '_wpfnl_downsell_products',
		];

		if ( ! isset( $meta_key_map[ $step_type ] ) ) {
			return null; // landing and thankyou have no dedicated product
		}

		$products = get_post_meta( $step_id, $meta_key_map[ $step_type ], true );
		if ( empty( $products ) || ! is_array( $products ) ) {
			return null;
		}

		$first      = $products[0];
		$product_id = isset( $first['id'] ) ? (int) $first['id'] : ( isset( $first['product_id'] ) ? (int) $first['product_id'] : 0 );

		if ( ! $product_id ) {
			return null;
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
		if ( ! $product ) {
			return null;
		}

		// Product image — prefer the main featured image.
		$image_url = '';
		$image_id  = $product->get_image_id();
		if ( $image_id ) {
			$src = wp_get_attachment_image_url( $image_id, 'large' );
			if ( $src ) {
				$image_url = $src;
			}
		}
		// Fall back to the first gallery image if no featured image.
		if ( ! $image_url ) {
			$gallery = $product->get_gallery_image_ids();
			if ( ! empty( $gallery ) ) {
				$src = wp_get_attachment_image_url( $gallery[0], 'large' );
				if ( $src ) {
					$image_url = $src;
				}
			}
		}

		$description = $product->get_short_description();
		if ( empty( $description ) ) {
			$description = $product->get_description();
		}
		$description = wp_strip_all_tags( $description );
		// Truncate description to avoid bloating the prompt.
		if ( strlen( $description ) > 500 ) {
			$description = substr( $description, 0, 500 ) . '…';
		}

		return [
			'id'          => $product_id,
			'name'        => $product->get_name(),
			'price'       => $product->get_price_html(),
			'price_raw'   => $product->get_price(),
			'description' => $description,
			'image_url'   => $image_url,
		];
	}

	/**
	 * Call the configured AI provider directly with a focused copy prompt.
	 *
	 * Unlike the funnel-building AgentLoop, this speaks directly to the
	 * provider's completions endpoint and asks only for page-copy fields,
	 * returning a flat key → string array keyed by copy field names.
	 *
	 * @param string     $provider     Active provider slug ('openai'|'anthropic').
	 * @param string     $step_type    landing|checkout|upsell|downsell|thankyou
	 * @param array|null $product_data Product data from load_step_product().
	 * @param array      $user_context niche, goal, audience, offering.
	 * @return array|null Copy fields array, or null on failure.
	 */
	private function call_ai_for_copy( $provider, $step_type, $product_data, array $user_context ) {
		$api_key = AISettings::getApiKey( $provider );

		if ( empty( $api_key ) ) {
			return null;
		}

		$prompt = $this->build_copy_prompt( $step_type, $product_data, $user_context );

		if ( 'anthropic' === $provider ) {
			$response = $this->http_post_anthropic( $api_key, $prompt );
		} else {
			$response = $this->http_post_openai( $api_key, $prompt );
		}

		if ( is_wp_error( $response ) ) {
			return null;
		}

		$status = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $status ) {
			return null;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		// Extract raw content string from provider-specific response shape.
		if ( 'anthropic' === $provider ) {
			$content = $body['content'][0]['text'] ?? '';
		} else {
			$content = $body['choices'][0]['message']['content'] ?? '';
		}

		// Strip markdown fences if the model wrapped JSON in code blocks.
		$content = preg_replace( '/^```(?:json)?\s*/i', '', trim( $content ) );
		$content = preg_replace( '/\s*```$/i', '', $content );

		$copy = json_decode( $content, true );

		return is_array( $copy ) && ! empty( $copy ) ? $copy : null;
	}

	/**
	 * Build the focused copy-generation prompt for a single funnel step.
	 *
	 * The prompt asks the AI to return a strict JSON object whose keys map
	 * directly to the copy fields consumed by Wpfnl_AI_Template_Builder.
	 *
	 * @param string     $step_type
	 * @param array|null $product_data
	 * @param array      $user_context
	 * @return string
	 */
	private function build_copy_prompt( $step_type, $product_data, array $user_context ) {
		$type_label = ucfirst( $step_type );

		// ── Product block ───────────────────────────────────────────────────
		$product_block = '';
		if ( ! empty( $product_data ) ) {
			$product_block .= "\n\nPRODUCT DETAILS (write copy based on this specific product):\n";
			$product_block .= "- Product name: " . sanitize_text_field( $product_data['name'] ?? '' ) . "\n";
			if ( ! empty( $product_data['price_raw'] ) ) {
				$product_block .= "- Price: " . sanitize_text_field( $product_data['price_raw'] ) . "\n";
			}
			if ( ! empty( $product_data['description'] ) ) {
				$product_block .= "- Description: " . sanitize_textarea_field( $product_data['description'] ) . "\n";
			}
		}

		// ── User context block ─────────────────────────────────────────────
		$context_block = "\n\nCAMPAIGN CONTEXT:\n";
		if ( ! empty( $user_context['niche'] ) ) {
			$context_block .= "- Business niche: " . sanitize_text_field( $user_context['niche'] ) . "\n";
		}
		if ( ! empty( $user_context['goal'] ) ) {
			$context_block .= "- Goal: " . sanitize_text_field( $user_context['goal'] ) . "\n";
		}
		if ( ! empty( $user_context['audience'] ) ) {
			$context_block .= "- Target audience: " . sanitize_text_field( $user_context['audience'] ) . "\n";
		}
		if ( ! empty( $user_context['offering'] ) ) {
			$context_block .= "- Offering: " . sanitize_text_field( $user_context['offering'] ) . "\n";
		}

		// ── Field schema per step type ─────────────────────────────────────
		$schemas = [
			'landing'  => '{"headline":"...","subheadline":"...","urgency_text":"...","cta_button_text":"...","benefit_bullets":["...","...","...","..."]}',
			'checkout' => '{"headline":"...","trust_text":"...","cta_button_text":"..."}',
			'upsell'   => '{"offer_headline":"...","offer_subheadline":"...","urgency_text":"...","value_stack_bullets":["...","...","..."],"accept_button_text":"...","decline_button_text":"..."}',
			'downsell' => '{"offer_headline":"...","offer_subheadline":"...","special_offer_text":"...","accept_button_text":"...","decline_button_text":"..."}',
			'thankyou' => '{"headline":"...","confirmation_text":"...","next_steps_text":"..."}',
		];
		$schema = $schemas[ $step_type ] ?? $schemas['landing'];

		// ── Field guidance ─────────────────────────────────────────────────
		$guidance = [
			'landing'  => 'headline: bold value proposition (max 10 words); subheadline: 1-2 sentence expansion; urgency_text: scarcity/urgency line; cta_button_text: action verb + outcome (2-5 words); benefit_bullets: 3-5 specific, tangible benefits.',
			'checkout' => 'headline: reassuring completion message (max 8 words); trust_text: 1-2 trust/security statements; cta_button_text: action phrase on the order button.',
			'upsell'   => 'offer_headline: exciting one-time offer headline; offer_subheadline: expand the offer value; urgency_text: limited-time urgency; value_stack_bullets: 3-4 specific bonuses/benefits; accept_button_text: enthusiastic yes (e.g. "Yes! Add This Now"); decline_button_text: polite no (e.g. "No Thanks, I\'ll Pass").',
			'downsell' => 'offer_headline: softer re-engagement headline; offer_subheadline: explain the reduced/different offer; special_offer_text: discounted deal callout; accept_button_text: positive action; decline_button_text: gentle decline.',
			'thankyou' => 'headline: warm thank-you statement; confirmation_text: 1-2 sentences confirming order and next steps; next_steps_text: 1-2 sentences on what to expect next.',
		];
		$field_guide = $guidance[ $step_type ] ?? $guidance['landing'];

		return "You are an elite direct-response copywriter specialising in WooCommerce sales funnels.\n\n"
			. "Write conversion-optimised page copy for a **{$type_label}** funnel page.{$product_block}{$context_block}\n\n"
			. "FIELD GUIDANCE:\n{$field_guide}\n\n"
			. "RULES:\n"
			. "- Ground every claim in the real product details above.\n"
			. "- Do NOT invent product features not present in the description.\n"
			. "- Use the product name naturally in body copy where it fits.\n"
			. "- Match the tone to the audience and niche.\n"
			. "- Return ONLY a valid JSON object with exactly these keys (no extra keys, no markdown):\n"
			. $schema;
	}

	/**
	 * Execute a copy-generation request against the OpenAI chat completions API.
	 *
	 * @param string $api_key
	 * @param string $prompt
	 * @return array|WP_Error wp_remote_post() response.
	 */
	private function http_post_openai( $api_key, $prompt ) {
		$model = AISettings::getModel( 'openai' );

		return wp_remote_post(
			'https://api.openai.com/v1/chat/completions',
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode( [
					'model'           => $model,
					'messages'        => [ [ 'role' => 'user', 'content' => $prompt ] ],
					'temperature'     => 0.7,
					'max_tokens'      => 1024,
					'response_format' => [ 'type' => 'json_object' ],
				] ),
				'timeout' => 60,
			]
		);
	}

	/**
	 * Execute a copy-generation request against the Anthropic messages API.
	 *
	 * @param string $api_key
	 * @param string $prompt
	 * @return array|WP_Error wp_remote_post() response.
	 */
	private function http_post_anthropic( $api_key, $prompt ) {
		$model = AISettings::getModel( 'anthropic' );

		return wp_remote_post(
			'https://api.anthropic.com/v1/messages',
			[
				'headers' => [
					'x-api-key'         => $api_key,
					'anthropic-version' => '2023-06-01',
					'Content-Type'      => 'application/json',
				],
				'body'    => wp_json_encode( [
					'model'      => $model,
					'max_tokens' => 1024,
					'messages'   => [ [ 'role' => 'user', 'content' => $prompt ] ],
				] ),
				'timeout' => 60,
			]
		);
	}

	/**
	 * Build a standard error response.
	 *
	 * @param string $message
	 * @param int    $status
	 * @param string $code
	 * @return WP_REST_Response
	 */
	private function error_response( $message, $status = 400, $code = 'error' ) {
		return new WP_REST_Response(
			[
				'success' => false,
				'message' => $message,
				'code'    => $code,
			],
			$status
		);
	}
}
