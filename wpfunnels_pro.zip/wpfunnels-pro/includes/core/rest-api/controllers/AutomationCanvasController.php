<?php
/**
 * Automation Canvas REST API Controller
 *
 * Handles create, update, and delete operations for the WPFunnels
 * Automation Canvas – a pro-only feature powered by Mail Mint.
 *
 * Routes (namespace: wpfunnels/v1):
 *   POST   /automation-canvas          → create_item
 *   PUT    /automation-canvas/{id}     → update_item
 *   DELETE /automation-canvas/{id}     → delete_item
 *
 * @package WPFunnels\Rest\Controllers
 * @since   3.9.5
 */

namespace WPFunnels\Rest\Controllers;

use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use WPFunnels\Wpfnl_functions;
use Mint\MRM\DataBase\Tables\AutomationMetaSchema;

/**
 * Class AutomationCanvasController
 */
class AutomationCanvasController extends Wpfnl_REST_Controller {

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'wpfunnels/v1';

	/**
	 * Route base.
	 *
	 * @var string
	 */
	protected $rest_base = 'automation-canvas';

	/**
	 * Permission check for all operations.
	 *
	 * @param WP_REST_Request $request Full request data.
	 * @return bool|WP_Error
	 * @since 3.9.5
	 */
	public function get_items_permissions_check( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'wpfnl_rest_forbidden',
				__( 'You do not have permission to manage automations.', 'wpfnl-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}
		return true;
	}

	/**
	 * Register REST API routes.
	 *
	 * @since 3.9.5
	 */
	public function register_routes() {

		// Collection endpoint: create a new automation.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
			)
		);

		// Single-item endpoint: update or delete an automation.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)',
			array(
				'args' => array(
					'id' => array(
						'description' => __( 'Unique identifier for the automation.', 'wpfnl-pro' ),
						'type'        => 'integer',
						'required'    => true,
					),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
			)
		);
	}

	/**
	 * Create a new automation.
	 *
	 * @param WP_REST_Request $request Full request data.
	 * @return WP_REST_Response|WP_Error
	 * @since 3.9.5
	 */
	public function create_item( $request ) {
		$availability_check = $this->check_mailmint_availability();
		if ( is_wp_error( $availability_check ) ) {
			return $availability_check;
		}

		$data = $request->get_json_params();
		if ( empty( $data ) ) {
			$data = $request->get_params();
		}

		// Ensure the author is set to the current user.
		if ( empty( $data['author'] ) ) {
			$data['author'] = get_current_user_id();
		}

		$automation_id = \MintMail\App\Internal\Automation\AutomationModel::get_instance()->create_or_update( $data );

		if ( ! $automation_id ) {
			return new WP_Error(
				'wpfnl_automation_create_failed',
				__( 'Failed to create automation.', 'wpfnl-pro' ),
				array( 'status' => 500 )
			);
		}

		$this->save_automation_meta( $automation_id, 'source', 'wpf' );

		return new WP_REST_Response(
			array( 'id' => $automation_id ),
			201
		);
	}

	/**
	 * Update an existing automation.
	 *
	 * @param WP_REST_Request $request Full request data.
	 * @return WP_REST_Response|WP_Error
	 * @since 3.9.5
	 */
	public function update_item( $request ) {
		$availability_check = $this->check_mailmint_availability();
		if ( is_wp_error( $availability_check ) ) {
			return $availability_check;
		}

		$id = absint( $request->get_param( 'id' ) );

		$data = $request->get_json_params();
		if ( empty( $data ) ) {
			$data = $request->get_params();
		}

		// When only a partial payload is sent (e.g. a status toggle), merge with
		// the existing automation data so we don't accidentally wipe other fields.
		$non_route_keys = array_diff( array_keys( $data ), array( 'id' ) );
		if ( count( $non_route_keys ) <= 2 ) {
			$existing = $this->get_single_automation( $id );
			if ( ! empty( $existing ) ) {
				$data = array_merge( $existing, $data );
			}
		}

		$data['id'] = $id;

		$automation_id = \MintMail\App\Internal\Automation\AutomationModel::get_instance()->create_or_update( $data );

		if ( ! $automation_id ) {
			return new WP_Error(
				'wpfnl_automation_update_failed',
				__( 'Failed to update automation.', 'wpfnl-pro' ),
				array( 'status' => 500 )
			);
		}

		$this->sync_postmeta_from_steps( $automation_id, $data );

		// Re-assert ownership. Saving through MailMint's own automation endpoint — which the
		// email builder does when persisting a designed email — stamps the source back to
		// 'mint', dropping the automation out of the WPFunnels listing that filters on
		// source = 'wpf'. Restore it here so the automation cannot be orphaned by an older
		// MailMint that still overwrites the marker unconditionally.
		$this->save_automation_meta( $automation_id, 'source', 'wpf' );

		$automation_data = $this->get_single_automation( $automation_id );

		return new WP_REST_Response(
			array(
				'id'   => $automation_id,
				'data' => $automation_data,
			),
			200
		);
	}

	/**
	 * Sync WPFunnels postmeta from canvas automation steps.
	 *
	 * When a WPFunnels trigger step (key starts with 'wpf_') is present in the
	 * automation, its settings hold the linked funnel step post ID (selectedStep)
	 * and funnel ID (selected_funnel_ids[0]). This writes three postmeta entries
	 * on that step so the funnel canvas knows the automation is linked:
	 *
	 *   - wpfnl_mint_automation_id    → MailMint automation ID
	 *   - _wpfnl_automation_trigger   → trigger info array (makes maybe_mint_automation = 'yes')
	 *
	 * The funnel_id is also persisted to MailMint automation meta for parity with
	 * the MintAutomation Vue flow.
	 *
	 * @param int   $automation_id MailMint automation ID just saved.
	 * @param array $data          Full automation data from the request body.
	 * @since 3.9.5
	 */
	private function sync_postmeta_from_steps( $automation_id, $data ) {
		$steps = ! empty( $data['steps'] ) && is_array( $data['steps'] ) ? $data['steps'] : array();

		$trigger_step   = null;
		$action_steps   = array();

		foreach ( $steps as $step ) {
			if ( empty( $step['type'] ) ) {
				continue;
			}

			if ( 'trigger' === $step['type'] ) {
				$trigger_key = isset( $step['key'] ) ? $step['key'] : '';
				// Only handle WPFunnels triggers — all use the 'wpf_' prefix.
				if ( strpos( $trigger_key, 'wpf_' ) === 0 ) {
					$trigger_step = $step;
				}
			} else {
				$action_steps[] = $step;
			}
		}

		if ( ! $trigger_step ) {
			return;
		}

		// The edit.js components store user selections under settings['settings'].
		$settings   = isset( $trigger_step['settings']['settings'] ) ? $trigger_step['settings']['settings'] : array();
		$wp_step_id = isset( $settings['selectedStep'] ) ? absint( $settings['selectedStep'] ) : 0;
		$funnel_id  = isset( $settings['selected_funnel_ids'][0] ) ? absint( $settings['selected_funnel_ids'][0] ) : 0;

		if ( ! $wp_step_id ) {
			return;
		}

		update_post_meta( $wp_step_id, 'wpfnl_mint_automation_id', $automation_id );

		$trigger = array(
			'value' => $trigger_step['key'],
			'title' => isset( $trigger_step['title'] ) ? sanitize_text_field( $trigger_step['title'] ) : '',
			'id'    => isset( $trigger_step['step_id'] ) ? sanitize_text_field( $trigger_step['step_id'] ) : '',
		);
		update_post_meta( $wp_step_id, '_wpfnl_automation_trigger', $trigger );

		// Build _wpfnl_automation_steps aligned with the MintController format so
		// prepare_automation_data(), get_data(), and migrateAutomationData() all work.
		$postmeta_steps = array();
		foreach ( $action_steps as $action_step ) {
			$canvas_step_id = isset( $action_step['step_id'] ) ? $action_step['step_id'] : '';
			$step_type      = isset( $action_step['type'] ) ? $action_step['type'] : 'action';

			// The canvas stores user-configured fields under settings['settings'].
			// Wrap with the WP funnel step post ID (same $wp_step_id used for postmeta)
			// and type to match the MintController postmeta shape. save_mail_data() reads
			// settings.step_id to identify which funnel step to update.
			$raw_settings = isset( $action_step['settings'] ) ? $action_step['settings'] : array();
			$settings = array(
				'step_id'  => $wp_step_id,
				'type'     => $step_type,
				'settings' => isset( $raw_settings['settings'] ) ? $raw_settings['settings'] : $raw_settings,
			);

			$postmeta_steps[] = array(
				'key'                    => isset( $action_step['key'] ) ? $action_step['key'] : '',
				'name'                   => isset( $action_step['title'] ) ? sanitize_text_field( $action_step['title'] ) : '',
				'type'                   => $step_type,
				'settings'               => $settings,
				'automation_step_id'     => $canvas_step_id,
				'automation_next_step_id'=> isset( $action_step['next_step_id'] ) ? $action_step['next_step_id'] : '',
				'enterance'              => 0,
				'completed'              => 0,
				'exited'                 => 0,
			);
		}
		update_post_meta( $wp_step_id, '_wpfnl_automation_steps', $postmeta_steps );

		if ( $funnel_id ) {
			$this->save_automation_meta( $automation_id, 'funnel_id', (string) $funnel_id );
		}
	}

	/**
	 * Delete an automation.
	 *
	 * @param WP_REST_Request $request Full request data.
	 * @return WP_REST_Response|WP_Error
	 * @since 3.9.5
	 */
	public function delete_item( $request ) {
		$availability_check = $this->check_mailmint_availability();
		if ( is_wp_error( $availability_check ) ) {
			return $availability_check;
		}

		$id = absint( $request->get_param( 'id' ) );

		// Collect linked step IDs before deletion so we can clean up post meta after.
		// wpfunnel_steps has exclude_from_search => true, so 'post_type' => 'any' misses it.
		$step_post_type = defined( 'WPFNL_STEPS_POST_TYPE' ) ? WPFNL_STEPS_POST_TYPE : 'wpfunnel_steps';
		$linked_steps   = get_posts(
			array(
				'post_type'      => $step_post_type,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'meta_key'       => 'wpfnl_mint_automation_id',
				'meta_value'     => $id,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$result = \MintMail\App\Internal\Automation\AutomationModel::destroy( $id );

		if ( ! $result ) {
			return new WP_Error(
				'wpfnl_automation_not_found',
				__( 'Automation not found or could not be deleted.', 'wpfnl-pro' ),
				array( 'status' => 404 )
			);
		}

		// Remove automation post meta from every linked funnel step.
		foreach ( $linked_steps as $step_id ) {
			delete_post_meta( $step_id, 'wpfnl_mint_automation_id' );
			delete_post_meta( $step_id, '_wpfnl_automation_trigger' );
			delete_post_meta( $step_id, '_wpfnl_automation_steps' );
		}

		return new WP_REST_Response(
			array(
				'id'      => $id,
				'message' => __( 'Automation deleted successfully.', 'wpfnl-pro' ),
			),
			200
		);
	}

	/**
	 * Check that Mail Mint is active and the AutomationModel class is available.
	 *
	 * @return true|WP_Error
	 * @since 3.9.5
	 */
	private function check_mailmint_availability() {
		if ( ! Wpfnl_functions::is_mint_mrm_active() ) {
			return new WP_Error(
				'wpfnl_automation_not_available',
				__( 'Mail Mint is required for automation functionality.', 'wpfnl-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( ! class_exists( 'MintMail\\App\\Internal\\Automation\\AutomationModel' ) ) {
			return new WP_Error(
				'wpfnl_automation_not_available',
				__( 'Mail Mint automation model is not available.', 'wpfnl-pro' ),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Retrieve single automation data from Mail Mint.
	 *
	 * @param int $automation_id The automation ID.
	 * @return array Full automation data array, or empty array on failure.
	 * @since 3.9.5
	 */
	private function get_single_automation( $automation_id ) {
		if ( ! class_exists( 'MintMail\\App\\Internal\\Automation\\AutomationModel' ) ) {
			return array();
		}

		$result = \MintMail\App\Internal\Automation\AutomationModel::get_single( $automation_id );

		if ( isset( $result['data'][0] ) ) {
			return $result['data'][0];
		}

		if ( ! empty( $result['data'] ) ) {
			return $result['data'];
		}

		return array();
	}

	/**
	 * Insert or update an automation meta value.
	 *
	 * @param int    $automation_id The automation ID.
	 * @param string $meta_key      The meta key.
	 * @param string $meta_value    The meta value.
	 * @return bool|int False on failure, true or insert ID on success.
	 * @since 3.9.5
	 */
	private function save_automation_meta( $automation_id, $meta_key, $meta_value ) {
		if ( ! class_exists( 'Mint\\MRM\\DataBase\\Tables\\AutomationMetaSchema' ) ) {
			return false;
		}

		global $wpdb;

		$table = $wpdb->prefix . AutomationMetaSchema::$table_name;

		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE automation_id = %d AND meta_key = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$automation_id,
				$meta_key
			)
		);

		if ( $existing ) {
			return (bool) $wpdb->update(
				$table,
				array(
					'meta_value' => $meta_value,
					'updated_at' => current_time( 'mysql' ),
				),
				array( 'id' => $existing->id )
			);
		}

		$result = $wpdb->insert(
			$table,
			array(
				'automation_id' => $automation_id,
				'meta_key'      => $meta_key,
				'meta_value'    => $meta_value,
				'created_at'    => current_time( 'mysql' ),
				'updated_at'    => current_time( 'mysql' ),
			)
		);

		return false !== $result ? $wpdb->insert_id : false;
	}
}
