<?php
/**
 * Pro Integrations REST controller.
 *
 * Serves the React Integrations page (free plugin, ?page=wpfunnels#/integrations)
 * with the same credential logic the legacy AJAX handlers use. All work is
 * delegated to Wpfnl_Pro_CRM_Credentials_Service, so the stored
 * `_wpfnl_addons_cred` data is identical whichever transport saved it.
 *
 * The class is named ProIntegrationsController (not IntegrationsController)
 * because the free plugin owns `WPFunnels\Rest\Controllers\IntegrationsController`
 * for `GET wpfunnels/v1/integrations`; both plugins share that namespace and
 * use classmap autoloading, so identical names would shadow each other.
 *
 * Routes (namespace wpfunnels/v1), registered only when the integration plan is active:
 *  - GET  integrations/credentials
 *  - POST integrations/<provider>/connect
 *  - POST integrations/<provider>/reset
 *  - POST integrations/<provider>/status
 *
 * @package WPFunnels\Rest\Controllers
 * @since   2.9.4
 */

namespace WPFunnels\Rest\Controllers;

use WP_Error;
use WP_REST_Request;
use WP_REST_Server;
use WPFunnels\Wpfnl_functions;
use WPFunnelsPro\Wpfnl_Pro_Plan;
use WPFunnelsPro\Integrations\Wpfnl_Pro_CRM_Credentials_Service;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ProIntegrationsController extends Wpfnl_REST_Controller {

    /**
     * Endpoint namespace.
     *
     * @var string
     */
    protected $namespace = 'wpfunnels/v1';

    /**
     * Route base.
     *
     * @var string
     */
    protected $rest_base = 'integrations';

    /**
     * Connect handler per provider: service method name.
     *
     * Mailchimp and ActiveCampaign save through update_addons_cred(), like the
     * jQuery does; every other provider uses its own authentication handler.
     * Toggle-only providers (mailpoet, zapier, wpfusion, pabbly) have no connect
     * handler. Pabbly Connect does have a legacy `wpfnl-pabbly-authentication`
     * AJAX handle, but the UI never calls it and its body calls an undefined
     * method (Wpfnl_Integartion_Pabbly_functions::pabbly_authentication_url()),
     * so it is not exposed over REST.
     *
     * @var array<string,string>
     */
    const CONNECT_HANDLERS = [
        'mailchimp'    => 'update_addons_cred',
        'activecamp'   => 'update_addons_cred',
        'cc'           => 'wpfunnels_constant_contact_authentication',
        'aweber'       => 'wpfunnels_aweber_authentication',
        'sendinblue'   => 'sendinblue_authentication',
        'mailerlite'   => 'mailerlite_authentication',
        'getresponse'  => 'wpfunnels_getresponse_authentication',
        'encharge'     => 'wpfunnels_encharge_authentication',
        'hubspot'      => 'wpfunnels_hubspot_authentication',
        'convertkit'   => 'wpfunnels_convertkit_authentication',
        'omnisend'     => 'wpfunnels_omnisend_authentication',
        'zoho'         => 'wpfunnels_zoho_authentication',
        'pabbly_email' => 'wpfunnels_pabbly_email_authentication',
        'drip'         => 'wpfunnels_drip_authentication',
    ];

    /**
     * Payload the legacy Reset button sends, per provider: the credential
     * fields emptied plus the `<x>_status` key the jQuery adds from the toggle.
     * See admin/assets/js/wpfnl-pro-crm-integrations.js (Reset handlers).
     *
     * pabbly_email has a Reset button but no jQuery handler; it is given the
     * same treatment as the other single-key providers.
     *
     * @var array<string,array{fields:string[],status_key:string}>
     */
    const RESET_PAYLOADS = [
        'mailchimp'    => [ 'fields' => [ 'mailchimp_apikey', 'mailchimp_server' ], 'status_key' => 'mailchimp_status' ],
        'activecamp'   => [ 'fields' => [ 'active_camp_url', 'active_camp_api' ], 'status_key' => 'active_camp_status' ],
        'cc'           => [ 'fields' => [ 'cc_url', 'cc_api', 'cc_secret' ], 'status_key' => 'cc_status' ],
        'aweber'       => [ 'fields' => [ 'aweber_url', 'aweber_api', 'aweber_secret' ], 'status_key' => 'aweber_status' ],
        'sendinblue'   => [ 'fields' => [ 'sendinblue_api' ], 'status_key' => 'sendinblue_status' ],
        'mailerlite'   => [ 'fields' => [ 'mailerlite_api' ], 'status_key' => 'mailerlite_status' ],
        'getresponse'  => [ 'fields' => [ 'getresponse_api' ], 'status_key' => 'getresponse_status' ],
        'encharge'     => [ 'fields' => [ 'encharge_api' ], 'status_key' => 'encharge_status' ],
        'hubspot'      => [ 'fields' => [ 'hubspot_api' ], 'status_key' => 'hubspot_status' ],
        'convertkit'   => [ 'fields' => [ 'convertkit_api' ], 'status_key' => 'convertkit_status' ],
        'omnisend'     => [ 'fields' => [ 'omnisend_api' ], 'status_key' => 'omnisend_status' ],
        'zoho'         => [ 'fields' => [ 'zoho_url', 'zoho_api', 'zoho_secret' ], 'status_key' => 'zoho_status' ],
        'pabbly_email' => [ 'fields' => [ 'pabbly_email_api' ], 'status_key' => 'pabbly_email_status' ],
        'drip'         => [ 'fields' => [ 'drip_api' ], 'status_key' => 'drip_status' ],
    ];

    /**
     * Permission check shared by every route.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function get_items_permissions_check( $request ) {
        if ( ! Wpfnl_functions::wpfnl_rest_check_manager_permissions( 'settings' ) ) {
            return new WP_Error( 'wpfunnels_rest_cannot_get', __( 'Sorry, you cannot list resources.', 'wpfnl-pro' ), [ 'status' => rest_authorization_required_code() ] );
        }
        return true;
    }

    /**
     * Permission check for write routes.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function update_items_permissions_check( $request ) {
        if ( ! Wpfnl_functions::wpfnl_rest_check_manager_permissions( 'settings', 'edit' ) ) {
            return new WP_Error( 'wpfunnels_rest_cannot_edit', __( 'Sorry, you cannot edit this resource.', 'wpfnl-pro' ), [ 'status' => rest_authorization_required_code() ] );
        }
        return true;
    }

    /**
     * Register routes. Nothing is registered without the integration plan,
     * mirroring CRM_Integrations which only boots the AJAX handlers then.
     */
    public function register_routes() {
        if ( ! Wpfnl_Pro_Plan::is_integration_license_active() ) {
            return;
        }

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/credentials',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'get_credentials' ],
                    'permission_callback' => [ $this, 'get_items_permissions_check' ],
                ],
            ]
        );

        $provider_arg = [
            'provider' => [
                'description' => __( 'Integration key as stored in _wpfnl_addons_cred.', 'wpfnl-pro' ),
                'type'        => 'string',
            ],
        ];

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<provider>[a-z_]+)/connect',
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'connect' ],
                    'permission_callback' => [ $this, 'update_items_permissions_check' ],
                    'args'                => $provider_arg,
                ],
            ]
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<provider>[a-z_]+)/reset',
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'reset' ],
                    'permission_callback' => [ $this, 'update_items_permissions_check' ],
                    'args'                => $provider_arg,
                ],
            ]
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<provider>[a-z_]+)/status',
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'update_status' ],
                    'permission_callback' => [ $this, 'update_items_permissions_check' ],
                    'args'                => $provider_arg,
                ],
            ]
        );
    }

    /**
     * GET integrations/credentials — same response as AJAX `wpfnl-get-addons-cred`.
     *
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response
     */
    public function get_credentials( $request ) {
        return rest_ensure_response( $this->service()->get_addons_cred() );
    }

    /**
     * POST integrations/<provider>/connect — same as the provider's Authorize Now.
     *
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response|WP_Error
     */
    public function connect( $request ) {
        $provider = $this->get_provider( $request );
        if ( is_wp_error( $provider ) ) {
            return $provider;
        }

        if ( ! array_key_exists( $provider, self::CONNECT_HANDLERS ) ) {
            return new WP_Error(
                'wpfunnels_rest_integration_toggle_only',
                __( 'This integration has no credentials to connect. Use the status route instead.', 'wpfnl-pro' ),
                [ 'status' => 400 ]
            );
        }

        $payload = $this->get_body_payload( $request );
        if ( is_wp_error( $payload ) ) {
            return $payload;
        }

        $method = self::CONNECT_HANDLERS[ $provider ];
        return rest_ensure_response( $this->service()->{$method}( $payload ) );
    }

    /**
     * POST integrations/<provider>/reset — what the legacy Reset button does:
     * resend the provider's save/authenticate request with emptied fields.
     *
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response|WP_Error
     */
    public function reset( $request ) {
        $provider = $this->get_provider( $request );
        if ( is_wp_error( $provider ) ) {
            return $provider;
        }

        if ( ! array_key_exists( $provider, self::RESET_PAYLOADS ) || ! array_key_exists( $provider, self::CONNECT_HANDLERS ) ) {
            return new WP_Error(
                'wpfunnels_rest_integration_toggle_only',
                __( 'This integration has no credentials to reset.', 'wpfnl-pro' ),
                [ 'status' => 400 ]
            );
        }

        $method = self::CONNECT_HANDLERS[ $provider ];
        return rest_ensure_response( $this->service()->{$method}( $this->build_reset_payload( $provider ) ) );
    }

    /**
     * POST integrations/<provider>/status — same as the card toggle.
     *
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response|WP_Error
     */
    public function update_status( $request ) {
        $provider = $this->get_provider( $request );
        if ( is_wp_error( $provider ) ) {
            return $provider;
        }

        $body   = $this->get_body_payload( $request );
        $status = is_array( $body ) && isset( $body['status'] ) ? $body['status'] : null;
        if ( ! in_array( $status, [ 'active', 'deactive' ], true ) ) {
            return new WP_Error(
                'wpfunnels_rest_invalid_param',
                __( 'Invalid status. Expected "active" or "deactive".', 'wpfnl-pro' ),
                [ 'status' => 400 ]
            );
        }

        return rest_ensure_response(
            $this->service()->update_crm_status(
                [
                    'crm'    => $provider,
                    'status' => $status,
                ]
            )
        );
    }

    /**
     * Build the payload the legacy Reset button sends for a provider.
     *
     * @param string $provider Provider key.
     * @return array
     */
    public function build_reset_payload( $provider ) {
        $definition = self::RESET_PAYLOADS[ $provider ];
        $payload    = array_fill_keys( $definition['fields'], '' );

        // The jQuery adds `<x>_status` from the toggle, which mirrors the stored `status`.
        $creds = $this->service()->get_addons_cred();
        $payload[ $definition['status_key'] ] = isset( $creds['data'][ $provider ]['status'] ) && 'active' === $creds['data'][ $provider ]['status'] ? 'active' : 'deactive';

        return $payload;
    }

    /**
     * Validate the provider route segment against the 18 known keys.
     *
     * @param WP_REST_Request $request Request.
     * @return string|WP_Error
     */
    private function get_provider( $request ) {
        $provider = (string) $request->get_param( 'provider' );
        if ( ! in_array( $provider, Wpfnl_Pro_CRM_Credentials_Service::PROVIDERS, true ) ) {
            return new WP_Error(
                'wpfunnels_rest_integration_not_found',
                __( 'Unknown integration.', 'wpfnl-pro' ),
                [ 'status' => 404 ]
            );
        }
        return $provider;
    }

    /**
     * Read the request body as the flat payload the AJAX handlers receive.
     *
     * Only body parameters are used (never the route or query args). Values
     * are slashed because the AJAX handlers read `$_POST['payload']`, which
     * WordPress magic-quotes; slashing keeps the stored bytes identical.
     *
     * @param WP_REST_Request $request Request.
     * @return array|WP_Error
     */
    private function get_body_payload( $request ) {
        $body = $request->get_json_params();
        if ( null === $body ) {
            $body = $request->get_body_params();
        }
        if ( empty( $body ) ) {
            return [];
        }
        if ( ! is_array( $body ) ) {
            return $this->invalid_body();
        }
        foreach ( $body as $key => $value ) {
            if ( ! is_string( $key ) || ( null !== $value && ! is_scalar( $value ) ) ) {
                return $this->invalid_body();
            }
        }
        return wp_slash( $body );
    }

    /**
     * 400 error for a malformed body.
     *
     * @return WP_Error
     */
    private function invalid_body() {
        return new WP_Error(
            'wpfunnels_rest_invalid_body',
            __( 'Invalid request body. Expected a flat object of credential fields.', 'wpfnl-pro' ),
            [ 'status' => 400 ]
        );
    }

    /**
     * Credentials service.
     *
     * @return Wpfnl_Pro_CRM_Credentials_Service
     */
    private function service() {
        return Wpfnl_Pro_CRM_Credentials_Service::instance();
    }
}
