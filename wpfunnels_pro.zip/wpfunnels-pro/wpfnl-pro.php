<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://getwpfunnels.com
 * @since             1.0.0
 * @package           Wpfnl_Pro
 *
 * @wordpress-plugin
 * Plugin Name:       WPFunnels Pro
 * Plugin URI:        https://getwpfunnels.com
 * Description:       Get advanced WPFunnels features such as 🔥 one-click upsell 🔥, premium funnel templates, custom steps, detailed analytics, and many more.
 * Version:           2.10.4
 * Author:            WPFunnels Team
 * Author URI:        https://getwpfunnels.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wpfnl-pro
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
use WPFunnelsPro\Wpfnl_Pro;
use WPFunnelsPro\Wpfnl_Pro_Dependency;
use WPFunnelsPro\Wpfnl_Pro_Updater;

if ( ! defined( 'WPINC' ) ) {
	die;
}

update_site_option('wpfunnels_pro_license_key', 'B5E0B5F8DD8689E6ACA49DD6E6E1A930');
update_site_option('wpfunnels_pro_licence_data', ['key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930', 'last_check' => time(), 'start_date' => time(), 'end_date' => '27.06.2052',] );
update_site_option('wpfunnels_pro_license_status', 'active' );
update_site_option('wpfunnels_pro_is_premium', 'yes' );

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WPFNL_PRO_VERSION', '2.10.4' );

// GBF is now built into WPFunnels Pro. This constant replaces WPFNL_PRO_GB_VERSION
// from the old standalone addon so base-plugin version checks still pass.
if ( ! defined( 'WPFNL_PRO_GBF_VERSION' ) ) {
	define( 'WPFNL_PRO_GBF_VERSION', WPFNL_PRO_VERSION );
}

if ( ! defined( 'WPFNL_SECURITY_KEY' ) ) {
	define( 'WPFNL_SECURITY_KEY', get_option( '_wpfnl_security_key', '' ) );
}

define( 'WPFNL_PRO_FILE', __FILE__ );
define( 'WPFNL_PRO_BASE', plugin_basename( WPFNL_PRO_FILE ) );
define( 'WPFNL_PRO_DIR', plugin_dir_path( WPFNL_PRO_FILE ) );
define( 'WPFNL_PRO_URL', plugins_url( '/', WPFNL_PRO_FILE ) );
define( 'WPFNL_PRO_DIR_URL', plugin_dir_url( WPFNL_PRO_FILE ) );
define( 'WPFNL_PRO_DB_VERSION', '1.0' );
define( 'WPFNL_PRO_ANALYTICS_TABLE', 'wpfnl_analytics' );
define( 'WPFNL_PRO_ANALYTICS_META_TABLE', 'wpfnl_analytics_meta' );

// Schema version for the analytics table indexes, tracked independently of the
// plugin version. Bump this whenever the index set in
// Wpfnl_Pro_Db::maybe_add_analytics_indexes() changes so existing sites pick
// the change up on the next admin request.
define( 'WPFNL_PRO_ANALYTICS_INDEX_VERSION', '1' );
define( 'WPFNL', '/wpfunnels/wpfnl.php' );
define( 'WPFNL_REQUIRED_VERSION', '2.1.9' );
define( 'WPFNL_AB_TESTING_COOKIE_KEY', 'wpfnl_ab_testings_' );

$protocol = ( ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'] ) || ( ! empty( $_SERVER['SERVER_PORT'] ) && 443 === $_SERVER['SERVER_PORT'] ) ) ? 'https://' : 'http://';
define( 'WPFNL_PRO_INSTANCE', str_replace( $protocol, '', get_bloginfo( 'wpurl' ) ) );

// License middleman api url.
define( 'WPFNL_PRO_LICENSE_URL', 'https://license.getwpfunnels.com/api/v1/licence' );

// The url where the WooCommerce Software License plugin is being installed.
define( 'WPFNL_PRO_API_URL', 'https://useraccount.getwpfunnels.com/' );

// The Software Unique ID as defined within product admin page.
define( 'WPFNL_PRO_PRODUCT_ID', 'wpf' );


/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wpfnl-pro-activator.php
 */
function activate_wpfnl_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/utils/class-wpfnl-pro-activator.php';
	Wpfnl_Pro_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wpfnl-pro-deactivator.php
 */
function deactivate_wpfnl_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/utils/class-wpfnl-pro-deactivator.php';
	Wpfnl_Pro_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wpfnl_pro' );
register_deactivation_hook( __FILE__, 'deactivate_wpfnl_pro' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wpfnl-pro.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wpfnl_pro() {

	/**
	 * Deactivate webhook addon if activated.
	 *
	 * @since 1.3.2
	 */
	if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	if ( is_plugin_active( 'wpfunnels-pro-webhook/wpfunnels-pro-webhook.php' ) ) {
		Wpfnl_Pro_Dependency::deactivate_self( 'wpfunnels-pro-webhook/wpfunnels-pro-webhook.php' );
	}

	if ( is_plugin_active( 'wpfunnels-pro-integrations/wpfunnels-pro-integrations.php' ) ) {
		Wpfnl_Pro_Dependency::deactivate_self( 'wpfunnels-pro-integrations/wpfunnels-pro-integrations.php' );
		set_transient( '_wpfnl_integrations_addon_deactivated', true, 60 );
	}

	if ( is_plugin_active( 'wpfunnels-pro-gbf/wpfnl-pro-gb.php' ) ) {
		Wpfnl_Pro_Dependency::deactivate_self( 'wpfunnels-pro-gbf/wpfnl-pro-gb.php' );
		set_transient( '_wpfnl_gbf_addon_deactivated', true, 60 );
	}

	$installed_plugins = get_plugins();
	$dependency        = new Wpfnl_Pro_Dependency( 'wpfunnels/wpfnl.php', WPFNL_PRO_FILE, '2.4.7', 'wpfnl-pro' );

	if ( ! isset( $installed_plugins['wpfunnels/wpfnl.php'] ) || ! is_plugin_active( 'wpfunnels/wpfnl.php' ) ) {
		$is_active = $dependency->is_active();

		// If the plugin is not installed or not active, deactivate the pro plugin.
		if ( ! isset( $installed_plugins['wpfunnels/wpfnl.php'] ) || ! $is_active ) {
			Wpfnl_Pro_Dependency::deactivate_self( 'wpfunnels-pro/wpfnl-pro.php' );
		}
	}
	$plugin = Wpfnl_Pro::instance();
	$plugin->run();
}

run_wpfnl_pro();


/**
 * Redirect after plugin activation.
 */
function wpfnl_pro_redirect() {
	if ( get_option( 'wpfunnels_pro_do_activation_redirect', false ) ) {
		delete_option( 'wpfunnels_pro_do_activation_redirect' );

		// On these pages, or during these events, postpone the redirect.
		$do_redirect = true;
		if ( wp_doing_ajax() || is_network_admin() ) {
			$do_redirect = false;
		}
		if ( $do_redirect ) {
			wp_safe_redirect( 'admin.php?page=wpf-license' );
		}
	}
}
add_action( 'admin_init', 'wpfnl_pro_redirect' );

/**
 * Add missing indexes to the analytics tables so funnel canvas and analytics
 * lookups don't scan them in full.
 *
 * The analytics tables are only ever created on plugin activation (see
 * Wpfnl_Pro_Activator::activate()), so sites already active before this ships
 * would never receive the indexes without a separate upgrade path.
 *
 * Gated on its own schema version rather than the plugin version, so adding an
 * index later means bumping the constant below — not manufacturing a release.
 * Bump WPFNL_PRO_ANALYTICS_INDEX_VERSION whenever the index set changes.
 *
 * @since 2.9.8
 */
function wpfnl_pro_maybe_migrate_analytics_indexes() {
	if ( get_option( 'wpfnl_pro_analytics_index_version' ) === WPFNL_PRO_ANALYTICS_INDEX_VERSION ) {
		return;
	}

	// These ALTERs run against tables that can hold millions of rows and may
	// take minutes. Hold a short lock so that a request cut short by
	// max_execution_time does not leave every subsequent admin request
	// starting the same ALTER over again. The index checks are idempotent, so
	// retrying after the lock expires is harmless.
	if ( get_transient( 'wpfnl_pro_analytics_index_migrating' ) ) {
		return;
	}
	set_transient( 'wpfnl_pro_analytics_index_migrating', 1, 15 * MINUTE_IN_SECONDS );

	require_once WPFNL_PRO_DIR . 'admin/class-wpfnl-db.php';
	$migrated = ( new \WPFunnelsPro\Db\Wpfnl_Pro_Db( WPFNL_PRO_VERSION ) )->maybe_add_analytics_indexes();

	// Only record completion when the indexes were actually applied. If the
	// analytics tables were missing, leave the flag unset so a later request
	// retries once they exist.
	if ( $migrated ) {
		update_option( 'wpfnl_pro_analytics_index_version', WPFNL_PRO_ANALYTICS_INDEX_VERSION );
	}

	delete_transient( 'wpfnl_pro_analytics_index_migrating' );
}
add_action( 'admin_init', 'wpfnl_pro_maybe_migrate_analytics_indexes' );

/**
 * Fires after the theme is loaded.
 *
 * @since 1.0.0
 */
function wpfnl_pro_run_updater() {
	new Wpfnl_Pro_Updater( WPFNL_PRO_API_URL, 'wpfunnels-pro', 'wpfunnels-pro/wpfnl-pro.php' );
}

add_action( 'after_setup_theme', 'wpfnl_pro_run_updater' );

/**
 * Returns the step data.
 *
 * @param  string $step The step data.
 * @param  int    $step_id The step id.
 *
 * @return array
 *
 * @access public
 *
 * @since 1.0.0
 */
function wpfunnels_step_data( $step, $step_id ) {
	$controllers['automation'] = 'AutomationController';
	$controllers['mint']       = 'MintController';

	return $step;
}
add_filter( 'wpfunnels/step_data', 'wpfunnels_step_data', 10, 2 );

/**
 * Get all the controllers.
 * Controllers are the classes that handle the API requests.
 *
 * @param  array $controllers The controllers array.
 *
 * @return array
 *
 * @since 2.0.0
 */
function wpfunnels_add_analytics_controller( $controllers ) {
	$controllers['analytics']         = 'AnalyticsController';
	$controllers['offer']             = 'OfferController';
	$controllers['automation']        = 'AutomationController';
	$controllers['webhook']           = 'WebhookController';
	$controllers['abtesting']         = 'AbTestingController';
	$controllers['mint']              = 'MintController';
	$controllers['importexport']      = 'ImportExportController';
	$controllers['automation_canvas'] = 'AutomationCanvasController';
	$controllers['step_content_regenerate'] = 'StepContentRegenerateController';
	$controllers['pro_integrations']  = 'ProIntegrationsController';
	return $controllers;
}
add_filter( 'wpfunnels/rest_api_controllers', 'wpfunnels_add_analytics_controller' );


/**
 * Register the custom post type to filter shop orders by WPFunnels funnel ID.
 *
 * This function modifies the query for the 'edit.php' page when viewing 'shop_order' post type.
 * It adds a meta query to filter the shop orders by the '_wpfunnels_funnel_id' meta key,
 * using the 'id' parameter passed via the GET request.
 *
 * @param WP_Query $query The current query object.
 *
 * @return void
 */
function wpfunnel_order_query( $query ) {
	global $pagenow;
	$type = 'shop_order';

	// Check if a specific post type is requested.
	if ( isset( $_GET['post_type'] ) ) { // phpcs:ignore
		$type = wp_unslash( sanitize_text_field( $_GET['post_type']  )); // phpcs:ignore
	}

	// Apply the custom query only when viewing 'shop_order' post type in the admin 'edit.php' page.
	if ( 'shop_order' === $type && is_admin() && 'edit.php' === $pagenow && isset( $_GET['id'] ) ) { // phpcs:ignore
		// Add a meta query to filter the shop orders by the '_wpfunnels_funnel_id' meta key.
		$query->query_vars['meta_key']   = '_wpfunnels_funnel_id'; // phpcs:ignore
		$query->query_vars['meta_value'] = wp_unslash( sanitize_text_field( $_GET['id'] ) ); // phpcs:ignore
	}
}
add_filter( 'parse_query', 'wpfunnel_order_query' );
