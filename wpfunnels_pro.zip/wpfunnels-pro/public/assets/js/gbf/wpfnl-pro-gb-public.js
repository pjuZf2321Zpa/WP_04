(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	jQuery(document).ready(function($) {
		var url = window?.wpfnl_pro_gbf_obj?.redirect_url;

		// Nothing to redirect to: bail instead of polling the DOM forever.
		if (!url) {
			return;
		}

		// Give up after 15s so we never poll for the lifetime of the page when the
		// theme or cart plugin does not render the buttons we are looking for.
		var MAX_ATTEMPTS = 30;

		function rewriteButtonHref(selector, shouldRun) {
			var attempts = 0;
			var timer = setInterval(function() {
				attempts++;

				if (!shouldRun()) {
					clearInterval(timer);
					return;
				}

				var checkoutButton = $(selector);
				if (checkoutButton.length) {
					checkoutButton.attr('href', url);
					clearInterval(timer);
					return;
				}

				if (attempts >= MAX_ATTEMPTS) {
					clearInterval(timer);
				}
			}, 500); // check every 500ms
		}

		rewriteButtonHref('.wc-block-components-button', function() {
			return true;
		});

		rewriteButtonHref('.wc-forward', function() {
			return window?.wpfnl_pro_gbf_obj?.general_settings?.enable_skip_cart !== 'off';
		});
	});

})( jQuery );
