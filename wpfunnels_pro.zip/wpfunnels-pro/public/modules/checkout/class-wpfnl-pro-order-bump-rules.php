<?php
/**
 * Order Bump Rules Evaluator (Pro Feature)
 *
 * Handles evaluation of conditional rules for order bumps
 *
 * @package WPFunnelsPro\Modules\Frontend\Checkout
 * @since 2.6.0
 */

namespace WPFunnelsPro\Modules\Frontend\Checkout;

class Wpfnl_Pro_Order_Bump_Rules {

	/**
	 * Evaluate if order bump should be displayed based on rules
	 *
	 * @param array $order_bump_settings Order bump settings including ruleSettings
	 * @return bool True if should display, false otherwise
	 */
	public static function should_display_order_bump( $order_bump_settings ) {
		// Backward compatibility: if no ruleSettings or not enabled, show the order bump
		if ( empty( $order_bump_settings['ruleSettings'] ) ) {
			return true;
		}

		$rule_settings = $order_bump_settings['ruleSettings'];

		// If rules are not enabled, show the order bump
		if ( empty( $rule_settings['enabled'] ) || $rule_settings['enabled'] !== true ) {
			return true;
		}

		// If no rule groups defined, show the order bump
		if ( empty( $rule_settings['ruleGroups'] ) || ! is_array( $rule_settings['ruleGroups'] ) ) {
			return true;
		}

		// Evaluate rule groups (OR logic between groups)
		foreach ( $rule_settings['ruleGroups'] as $rule_group ) {
			if ( empty( $rule_group['conditions'] ) || ! is_array( $rule_group['conditions'] ) ) {
				continue;
			}

			// Check if this rule group passes (AND logic within group)
			if ( self::evaluate_rule_group( $rule_group['conditions'] ) ) {
				return true; // At least one group passed, show the order bump
			}
		}

		// No rule groups passed, don't show the order bump
		return false;
	}

	/**
	 * Evaluate a rule group (all conditions must pass - AND logic)
	 *
	 * @param array $conditions Array of conditions
	 * @return bool True if all conditions pass
	 */
	private static function evaluate_rule_group( $conditions ) {
		foreach ( $conditions as $condition ) {
			if ( empty( $condition['field'] ) || empty( $condition['operator'] ) ) {
				continue;
			}

			// Each condition must pass for the group to pass
			if ( ! self::evaluate_condition( $condition ) ) {
				return false;
			}
		}

		return true; // All conditions passed
	}

	/**
	 * Evaluate a single condition
	 *
	 * @param array $condition Condition with field, operator, and value
	 * @return bool True if condition passes
	 */
	private static function evaluate_condition( $condition ) {
		$field = $condition['field'];
		$operator = $condition['operator'];
		$value = isset( $condition['value'] ) ? $condition['value'] : null;

		// Get cart if available
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		$cart = WC()->cart;

		switch ( $field ) {
			case 'cart_total':
				return self::evaluate_numeric_condition( $cart->get_total( 'edit' ), $operator, $value );

			case 'cart_subtotal':
				return self::evaluate_numeric_condition( $cart->get_subtotal(), $operator, $value );

			case 'cart_items':
				return self::evaluate_cart_items( $operator, $value );

			case 'cart_item_count':
				return self::evaluate_numeric_condition( $cart->get_cart_contents_count(), $operator, $value );

			case 'cart_items_quantity':
				$total_quantity = 0;
				foreach ( $cart->get_cart() as $cart_item ) {
					$total_quantity += $cart_item['quantity'];
				}
				return self::evaluate_numeric_condition( $total_quantity, $operator, $value );

			case 'item_categories':
				return self::evaluate_categories( $operator, $value );

			case 'item_tags':
				return self::evaluate_tags( $operator, $value );

			case 'cart_coupons':
				return self::evaluate_coupons( $operator, $value );

			case 'shipping_method':
				return self::evaluate_shipping_method( $operator, $value );

			case 'shipping_country':
				return self::evaluate_country( 'shipping', $operator, $value );

			case 'billing_country':
				return self::evaluate_country( 'billing', $operator, $value );

			case 'wpfunnels_checkout':
				return self::evaluate_checkout_page( $operator, $value );

			default:
				return true; // Unknown field, pass by default
		}
	}

	/**
	 * Evaluate numeric conditions (equals, not equals, greater than, less than, etc.)
	 *
	 * @param float $actual_value Actual value from cart
	 * @param string $operator Comparison operator
	 * @param mixed $expected_value Expected value from rule
	 * @return bool
	 */
	private static function evaluate_numeric_condition( $actual_value, $operator, $expected_value ) {
		$expected_value = floatval( $expected_value );
		$actual_value = floatval( $actual_value );

		switch ( $operator ) {
			case '==':
			case 'equal_to':
				return $actual_value == $expected_value;
			case '!=':
			case 'not_equal_to':
				return $actual_value != $expected_value;
			case '>':
			case 'greater_than':
				return $actual_value > $expected_value;
			case '<':
			case 'less_than':
				return $actual_value < $expected_value;
			case '>=':
			case 'greater_or_equal':
				return $actual_value >= $expected_value;
			case '<=':
			case 'less_or_equal':
				return $actual_value <= $expected_value;
			default:
				return false;
		}
	}

	/**
	 * Evaluate cart items condition
	 *
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of product objects with {value, label}
	 * @return bool
	 */
	private static function evaluate_cart_items( $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$cart = WC()->cart;
		$cart_product_ids = array();

		foreach ( $cart->get_cart() as $cart_item ) {
			$cart_product_ids[] = $cart_item['product_id'];
			if ( $cart_item['variation_id'] ) {
				$cart_product_ids[] = $cart_item['variation_id'];
			}
		}

		// Extract product IDs from value array
		$rule_product_ids = array();
		foreach ( $value as $product ) {
			if ( is_array( $product ) && isset( $product['value'] ) ) {
				$rule_product_ids[] = intval( $product['value'] );
			} elseif ( is_numeric( $product ) ) {
				$rule_product_ids[] = intval( $product );
			}
		}

		$matching_products = array_intersect( $cart_product_ids, $rule_product_ids );

		switch ( $operator ) {
			case 'matches_any':
			case 'in_list':
				return ! empty( $matching_products );
			case 'matches_all':
				return count( $matching_products ) === count( $rule_product_ids );
			case 'matches_none':
			case 'not_in_list':
				return empty( $matching_products );
			default:
				return false;
		}
	}

	/**
	 * Evaluate categories condition
	 *
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of category objects
	 * @return bool
	 */
	private static function evaluate_categories( $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$cart = WC()->cart;
		$cart_category_ids = array();

		foreach ( $cart->get_cart() as $cart_item ) {
			$product_id = $cart_item['product_id'];
			$terms = get_the_terms( $product_id, 'product_cat' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$cart_category_ids[] = $term->term_id;
				}
			}
		}

		// Remove duplicates
		$cart_category_ids = array_unique( $cart_category_ids );

		// Extract category IDs from value array
		$rule_category_ids = array();
		foreach ( $value as $category ) {
			if ( is_array( $category ) && isset( $category['value'] ) ) {
				$rule_category_ids[] = intval( $category['value'] );
			} elseif ( is_numeric( $category ) ) {
				$rule_category_ids[] = intval( $category );
			}
		}

		$matching_categories = array_intersect( $cart_category_ids, $rule_category_ids );

		switch ( $operator ) {
			case 'matches_any':
			case 'in_list':
				return ! empty( $matching_categories );
			case 'matches_all':
				return count( $matching_categories ) === count( $rule_category_ids );
			case 'matches_none':
			case 'not_in_list':
				return empty( $matching_categories );
			default:
				return false;
		}
	}

	/**
	 * Evaluate tags condition
	 *
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of tag objects
	 * @return bool
	 */
	private static function evaluate_tags( $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$cart = WC()->cart;
		$cart_tag_ids = array();

		foreach ( $cart->get_cart() as $cart_item ) {
			$product_id = $cart_item['product_id'];
			$terms = get_the_terms( $product_id, 'product_tag' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$cart_tag_ids[] = $term->term_id;
				}
			}
		}

		// Remove duplicates
		$cart_tag_ids = array_unique( $cart_tag_ids );

		// Extract tag IDs from value array
		$rule_tag_ids = array();
		foreach ( $value as $tag ) {
			if ( is_array( $tag ) && isset( $tag['value'] ) ) {
				$rule_tag_ids[] = intval( $tag['value'] );
			} elseif ( is_numeric( $tag ) ) {
				$rule_tag_ids[] = intval( $tag );
			}
		}

		$matching_tags = array_intersect( $cart_tag_ids, $rule_tag_ids );

		switch ( $operator ) {
			case 'matches_any':
			case 'in_list':
				return ! empty( $matching_tags );
			case 'matches_all':
				return count( $matching_tags ) === count( $rule_tag_ids );
			case 'matches_none':
			case 'not_in_list':
				return empty( $matching_tags );
			default:
				return false;
		}
	}

	/**
	 * Evaluate coupons condition
	 *
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of coupon codes (strings)
	 * @return bool
	 */
	private static function evaluate_coupons( $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$cart = WC()->cart;
		$applied_coupons = $cart->get_applied_coupons();

		// Normalize coupon codes to lowercase for comparison
		$applied_coupons = array_map( 'strtolower', $applied_coupons );
		$rule_coupons = array_map( 'strtolower', $value );

		$matching_coupons = array_intersect( $applied_coupons, $rule_coupons );

		switch ( $operator ) {
			case 'matches_any':
			case 'in_list':
				return ! empty( $matching_coupons );
			case 'matches_all':
				return count( $matching_coupons ) === count( $rule_coupons );
			case 'matches_none':
			case 'not_in_list':
				return empty( $matching_coupons );
			default:
				return false;
		}
	}

	/**
	 * Evaluate shipping method condition
	 *
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of shipping method objects
	 * @return bool
	 */
	private static function evaluate_shipping_method( $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
		if ( empty( $chosen_methods ) ) {
			return false;
		}

		// Extract shipping method IDs from value array
		$rule_method_ids = array();
		foreach ( $value as $method ) {
			if ( is_array( $method ) && isset( $method['value'] ) ) {
				$rule_method_ids[] = $method['value'];
			} elseif ( is_string( $method ) ) {
				$rule_method_ids[] = $method;
			}
		}

		$matching_methods = array_intersect( $chosen_methods, $rule_method_ids );

		switch ( $operator ) {
			case 'matches_any':
			case 'in_list':
				return ! empty( $matching_methods );
			case 'matches_all':
				return count( $matching_methods ) === count( $rule_method_ids );
			case 'matches_none':
			case 'not_in_list':
				return empty( $matching_methods );
			default:
				return false;
		}
	}

	/**
	 * Evaluate country condition (shipping or billing)
	 *
	 * @param string $type 'shipping' or 'billing'
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of country objects
	 * @return bool
	 */
	private static function evaluate_country( $type, $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$customer = WC()->customer;
		if ( ! $customer ) {
			return false;
		}

		$country = $type === 'shipping' ? $customer->get_shipping_country() : $customer->get_billing_country();

		if ( empty( $country ) ) {
			return false;
		}

		// Extract country codes from value array
		$rule_countries = array();
		foreach ( $value as $country_data ) {
			if ( is_array( $country_data ) && isset( $country_data['value'] ) ) {
				$rule_countries[] = $country_data['value'];
			} elseif ( is_string( $country_data ) ) {
				$rule_countries[] = $country_data;
			}
		}

		$has_match = in_array( $country, $rule_countries );

		switch ( $operator ) {
			case 'matches_any':
			case 'matches_all': // For single country selection, any and all are the same
			case 'in_list':
				return $has_match;
			case 'matches_none':
			case 'not_in_list':
				return ! $has_match;
			default:
				return false;
		}
	}

	/**
	 * Evaluate checkout page condition
	 *
	 * @param string $operator matches_any, matches_all, matches_none
	 * @param mixed $value Array of checkout page objects
	 * @return bool
	 */
	private static function evaluate_checkout_page( $operator, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$current_checkout_id = get_the_ID();

		// Extract checkout page IDs from value array
		$rule_checkout_ids = array();
		foreach ( $value as $checkout ) {
			if ( is_array( $checkout ) && isset( $checkout['value'] ) ) {
				$rule_checkout_ids[] = intval( $checkout['value'] );
			} elseif ( is_numeric( $checkout ) ) {
				$rule_checkout_ids[] = intval( $checkout );
			}
		}

		$has_match = in_array( $current_checkout_id, $rule_checkout_ids );

		switch ( $operator ) {
			case 'matches_any':
			case 'matches_all': // For current page, any and all are the same
			case 'in_list':
				return $has_match;
			case 'matches_none':
			case 'not_in_list':
				return ! $has_match;
			default:
				return false;
		}
	}
}
