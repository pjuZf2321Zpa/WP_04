
<div class="wpfnl">
    <div class="wpfnl-addons">
        <div class="wpfnl-dashboard">
            <nav class="wpfnl-dashboard__nav">
                <?php use WPFunnels\Wpfnl_functions;
                require_once WPFNL_DIR . '/admin/partials/dashboard-nav.php'; ?>
            </nav>

            <div class="dashboard-nav__content">
                <div class="addon-loader">
                    <div class="loader-inner">
                        <span class="wpfnl-loader"></span>
                    </div>
                </div>

                <div class="wpfnl-dashboard__header funnel-settings__header">
                    <div class="title">
                        <h2 class="addon-title">
                            <?php echo __('Enable WPFunnels Integration With Your Favourite Automation Tool Or CRM', 'wpfnl-pro'); ?>
                        </h2>
                    </div>
                </div>

                <div class="addon-wrapper">
                    <!-- mailchimp -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/mail-chimp/mailchimp.php'; ?>

                    <!-- active-campaign -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/active-campaign/active-campaign.php'; ?>

                    <!-- Mailpoet -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/mailpoet/mailpoet.php'; ?>

                    <!-- Constant Contact -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/constant-contact/constant-contact.php'; ?>

                    <!-- aweber -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/aweber/aweber.php'; ?>

                    <!-- sendinblue -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/send-in-blue/sendinblue.php'; ?>

                    <!-- mailerlite -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/mailerlite/mailerlite.php'; ?>

                    <!-- getresponse -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/get-response/getresponse.php'; ?>

                    <!-- encharge -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/encharge/encharge.php'; ?>

                    <!-- zapier -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/zapier/zapier.php'; ?>

                    <!-- hubspot -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/hubspot/hubspot.php'; ?>

                    <!-- ConvertKit -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/convertkit/convertkit.php'; ?>

                    <!-- Omnisend -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/omnisend/omnisend.php'; ?>

                    <!-- WP Fusion -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/wpfusion/wpfusion.php'; ?>

                    <!-- Zoho -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/zoho/zoho.php'; ?>

                    <!-- Pabbly -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/pabbly/pabbly.php'; ?>

                    <!-- Pabbly Email -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/pabbly/pabbly-email.php'; ?>

                    <!-- Drip -->
                    <?php require_once WPFNL_PRO_DIR . 'admin/partials/integrations/helper/drip/drip.php'; ?>

                    <?php do_action( 'wpfunnels/after_integration_forms' ) ?>

                </div>
            </div>

        </div>
    </div>
</div>
