<div class="single-addon zapier">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/zapier-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="zapier-active" class="zapier-active" name="zapier-active" type="checkbox" value="" />
            <label for="zapier-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="zapier-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $zapier_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/zapier-integration/';

                echo sprintf('Integration successful! You can now send data to Zapier based on user events in your funnels. <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $zapier_guide_link);
                ?>
            </p>


        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/zapier-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __("Zapier is the most popular automation tool that lets you connect your favorite tools and help you automate workflows.", 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>