<?php

namespace WPFunnelsPro\Integartions\Convertkit;

use Exception;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;


class Wpfnl_Integartion_Convertkit_functions
{
    /**
     * Get lists from convertkit account
     * 
     * @return Array|bool
     * @since 1.2.7
     */
    public static function get_lists(){
        return false;
    }

    /**
     * Get tags from convertkit account
     * 
     * @return Array
     * @since 1.2.7
     */
    public static function get_tags(){
        $creds = get_option( '_wpfnl_addons_cred' );
        if( $creds && isset($creds['convertkit'],$creds['convertkit']['convertkit_status'],$creds['convertkit']['convertkit_api'],$creds['convertkit']['status'])  ){
            $url = self::convertkit_authentication_url();
           
            if( $url ) {
                try {
                    $response = wp_remote_request($url.'tags/?api_secret='.Wpfunnels_Aes_Ctr::decrypt( $creds['convertkit']['convertkit_api'], WPFNL_SECURITY_KEY, 256 ));
                    $status_code = wp_remote_retrieve_response_code($response);
                    
                    if( 200 === $status_code){
                        $response_body = wp_remote_retrieve_body($response);

                        $result = json_decode($response_body);
                        if( !empty($result->tags) && is_array($result->tags) ){
                            $formatted_tags = [];
                            foreach( $result->tags as $tag ){
                                if( !empty($tag->name) && !empty($tag->id) ){
                                    $formatted_tags[$tag->id] = $tag->name;
                                }
                            }
                            
                            return $formatted_tags;
                        }
                    }
                }catch (\Exception $e) {
                    error_log(print_r($e->getMessage(),1));
                }
            }
        }
    }


    /**
     * Convertkit authentication url
     * @return String
     * 
     * @since 1.2.7
     */
    public static function convertkit_authentication_url(){
        $auth_url = 'https://api.convertkit.com/v3/';
        return $auth_url;
    }


    /**
     * Check convertkit settings enable
     * 
     * @return Bool
     * @since 1.2.7
     */
    public static function maybe_convertkit_enable(){
        if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated() ){
            $creds = get_option( '_wpfnl_addons_cred' );
            if( isset($creds['convertkit']) && isset($creds['convertkit']['status']) && isset($creds['convertkit']['convertkit_status']) && isset($creds['convertkit']['convertkit_api'])){
                if( 'active' === $creds['convertkit']['convertkit_status'] && 'active' === $creds['convertkit']['status'] ){
                    return true;
                }
            }
        }
        return false;;
    }
}