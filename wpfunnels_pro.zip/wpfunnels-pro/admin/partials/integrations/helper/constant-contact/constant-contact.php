<div class="single-addon constant-contact">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/constant-contact-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="constant-contact-active" class="constant-contact-active" name="constant-contact-active" type="checkbox" value="" />
            <label for="constant-contact-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="constant-contact-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $constant_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-constantcontact/';

                echo sprintf('Please connect with your Constant Contact account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $constant_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('Redirect URL', 'wpfunnels-pro'); ?>
                </label>
                <input class="constant-contact-url" name="constant-contact-url" type="text">
                <span class="hints constant-contact-hints constant-contact-hints-url" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group">
                <label>
                    <?php echo __('API Key', 'wpfunnels-pro'); ?>
                </label>
                <input class="constant-contact-api" name="constant-contact-api" type="text">
                <span class="hints constant-contact-hints constant-contact-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group">
                <label>
                    <?php echo __('API Secret', 'wpfunnels-pro'); ?>
                </label>
                <input class="constant-contact-secret" name="constant-contact-secret" type="text">
                <span class="hints constant-contact-hints constant-contact-hints-secret" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group action-btn">
                <a class="btn-default constant-contact-auth" href="#">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default constant-contact-reset" href="#">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints constant-contact-hints constant-contact-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/constant-contact-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('Constant Contact is one of the most renowned email marketing tools with a super easy UI.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>
<!-- /.single-addon -->