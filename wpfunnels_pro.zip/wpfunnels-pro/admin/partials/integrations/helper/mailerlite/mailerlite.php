<div class="single-addon mailerlite">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/mailerlite-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="mailerlite-active" class="mailerlite-active" name="mailerlite-active" type="checkbox" value="" />
            <label for="mailerlite-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="mailerlite-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php echo __('', 'wpfunnels-pro'); ?>
                <?php
                $mailerlite_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-mailerlite/';

                echo sprintf('Please connect with your MailerLite account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $mailerlite_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('API Key', 'wpfunnels-pro'); ?>
                </label>
                <input class="mailerlite-api" name="mailerlite-api" type="text">
                <span class="hints mailerlite-hints mailerlite-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group action-btn">
                <a class="btn-default mailerlite-auth" href="#">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default mailerlite-reset" href="#">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints mailerlite-hints mailerlite-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/mailerlite-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('MailerLite is an email marketing software designed to help people of all skill levels create successful marketing campaigns.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>