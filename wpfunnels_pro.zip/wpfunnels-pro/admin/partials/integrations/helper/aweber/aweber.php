<div class="single-addon aweber">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/aweber-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="aweber-active" class="aweber-active" name="aweber-active" type="checkbox" value="" />
            <label for="aweber-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="aweber-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $aweber_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-aweber/';

                echo sprintf('Please connect with your AWeber account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $aweber_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('Redirect URL', 'wpfunnels-pro'); ?>
                </label>
                <input class="aweber-url" name="aweber-url" type="text">
                <span class="hints aweber-hints aweber-hints-url" style="color:red">Field required</span>
            </div>

            <div class="form-group">
                <label>
                    <?php echo __('API Key', 'wpfunnels-pro'); ?>
                </label>
                <input class="aweber-api" name="aweber-api" type="text">
                <span class="hints aweber-hints aweber-hints-api" style="color:red">Field required</span>
            </div>

            <div class="form-group">
                <label>
                    <?php echo __('API Secret', 'wpfunnels-pro'); ?>
                </label>
                <input class="aweber-secret" name="aweber-secret" type="text">
                <span class="hints aweber-hints aweber-hints-secret" style="color:red">Field required</span>
            </div>

            <div class="form-group action-btn">
                <a class="btn-default aweber-auth" href="#">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default aweber-reset" href="#">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints aweber-hints aweber-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/aweber-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('Aweber is a prominent email marketing tool that allows you to collect leads and run automated email campaigns & sequences easily.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>