<div class="single-addon getresponse">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/getresponse-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="getresponse-active" class="getresponse-active" name="getresponse-active" type="checkbox" value="" />
            <label for="getresponse-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="getresponse-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $getresponse_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-getresponse/';

                echo sprintf('Please connect with your GetResponse account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $getresponse_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('API Key', 'wpfunnels-pro'); ?>
                </label>
                <input class="getresponse-api" name="getresponse-api" type="text">
                <span class="hints getresponse-hints getresponse-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group action-btn">
                <a class="btn-default getresponse-auth" href="#">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default getresponse-reset" href="#">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints getresponse-hints getresponse-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/getresponse-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('GetRespnse is an all-in-one marketing platform that comes with powerful email marketing features, CRM, and advanced automations.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>