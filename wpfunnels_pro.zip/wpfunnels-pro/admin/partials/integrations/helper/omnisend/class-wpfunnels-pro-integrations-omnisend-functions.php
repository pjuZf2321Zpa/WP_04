<?php

namespace WPFunnelsPro\Integartions\Omnisend;

use Exception;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;


class Wpfnl_Integartion_Omnisend_functions
{
    /**
     * Get lists from Omnisend account
     * 
     * @return Array|bool
     * @since 1.2.0
     */
    public static function get_lists(){
        return false;
    }

    /**
     * Get tags from omnisend account
     * 
     * @return Array
     * @since 1.2.0
     */
    public static function get_tags(){
        return false;
    }


    /**
     * omnisend authentication url
     * @return String
     * 
     * @since 1.2.0
     */
    public static function omnisend_authentication_url(){
        $auth_url = 'https://api.omnisend.com/v3/';
        return $auth_url;
    }


    /**
     * Check omnisend settings enable
     * 
     * @return Bool
     * @since 1.2.0
     */
    public static function maybe_omnisend_enable(){
        // if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated() ){
            $creds = get_option( '_wpfnl_addons_cred' );
           
            if( isset($creds['omnisend']) && isset($creds['omnisend']['status']) && isset($creds['omnisend']['omnisend_status']) && isset($creds['omnisend']['omnisend_api'])){
                if( 'active' === $creds['omnisend']['omnisend_status'] && 'active' === $creds['omnisend']['status'] ){
                   
                    return true;
                }
            }
        // }
        return false;
    }
}