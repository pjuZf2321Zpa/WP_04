<div class="single-addon omnisend">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/omnisend-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="omnisend-active" class="omnisend-active" name="omnisend-active" type="checkbox" value="" />
            <label for="omnisend-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="omnisend-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $omnisend_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-omnisend/';
                echo sprintf('Please connect with your Omnisend account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $omnisend_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('API Key', 'wpfunnels-pro'); ?>
                </label>
                <input class="omnisend-api" name="omnisend-api" type="text">
                <span class="hints omnisend-hints omnisend-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>



            <div class="form-group action-btn">
                <a class="btn-default omnisend-auth" href="#">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default omnisend-reset" href="#">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints omnisend-hints omnisend-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/omnisend-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('Omnisend is an omni-channel marketing automation platform, built for eCommerce, to help with email automation, SMS & WhatsApp messaging, segmentation, and many more.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>