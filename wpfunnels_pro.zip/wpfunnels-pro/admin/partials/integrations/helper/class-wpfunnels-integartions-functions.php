<?php

namespace WPFunnelsPro\Integartions;

class Wpfnl_Integartion_functions
{


    /**
     * check if the license is activated or not
     *
     * @return bool
     */
    public static function is_pro_integrations_license_activated() {
        // Legacy addon license
        if ( get_option( 'wpfunnels_pro_integrations_license_status' ) === 'active' ) {
            return true;
        }
        // New plan-based license (mediumannual / largeannual)
        return apply_filters( 'wpfunnels/is_integration_license_active', false );
    }
    

}