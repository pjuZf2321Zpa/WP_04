<?php
/**
 * Drip functions
 * @since 1.4.0
 */
namespace WPFunnelsPro\Integartions\Drip;

use Error;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;
use GuzzleHttp\Exception\GuzzleException;

/**
 * Drip helper class
 * 
 * @package WPFunnelsPro\Integartions\Drip
 * 
 * @since 1.4.0
 */
class Wpfnl_Integartion_Drip_functions
{

    /**
     * Get lists from drip
     * 
     * @return Array
     * @since 1.4.0
     */
    public static function get_lists(){
        try {
            // Create a new GuzzleHttp client
            $client = new \GuzzleHttp\Client();

            // Get the Drip authorization URL
            $url = self::get_drip_authorization_url();

            // Get the encoded credentials for Drip authorization
            $encodedCredentials = self::get_drip_authorization_basic_auth();

            // Send a GET request to the Drip API to get the accounts
            $response = $client->request('GET', "{$url}/accounts", [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization'     => "Basic {$encodedCredentials}",

                ],
            ]);

            // Check if the response status code is 200 (OK)
            if( 200 == $response->getStatusCode() ){
                // Decode the JSON response body
                $result = json_decode($response->getBody()->getContents());
                
                // Check if the response contains accounts
                if( isset($result->accounts) ){
                    // Check if accounts is an array
                    if( is_array($result->accounts) ){

                        // Initialize an empty array to store the formatted lists
                        $formatted_lists = [];

                        // Loop through each account
                        foreach( $result->accounts as $account ){
                            // Check if the account has an id
                            if( $account->id ){
                                // Add the account to the formatted_lists array
                                $formatted_lists[$account->id] = [
                                    'value' => $account->name
                                ];
                            }
                        }

                        // Return the formatted_lists array
                        return $formatted_lists;
                    }
                }
            }
        }catch (\Exception $e) {
            // If an exception is thrown, return an empty array
			return [];
        }

        // If the function has not returned by this point, return an empty array
        return [];
        
    }


    /**
     * Get tags from drip
     * 
     * @return Array
     * @since 1.4.0
     */
    public static function get_drip_tags( $list_data = []){
        try {
            // Check if list_data is not empty
            if( !empty($list_data) ){
                 // Get the account_id from list_data
                $account_id = $list_data['list_id'];

                // Create a new GuzzleHttp client
                $client = new \GuzzleHttp\Client();

                 // Get the Drip authorization URL
                $url = self::get_drip_authorization_url();

                // Get the encoded credentials for Drip authorization
                $encodedCredentials = self::get_drip_authorization_basic_auth();

                // Send a GET request to the Drip API to get the tags for the account
                $response = $client->request('GET', "{$url}/{$account_id}/tags", [
                    'headers' => [
                        'Accept'        => 'application/json',
                        'Authorization'     => "Basic {$encodedCredentials}",

                    ],
                ]);

                // Check if the response status code is 200 (OK)
                if( 200 == $response->getStatusCode() ){
                    // Decode the JSON response body
                    $result = json_decode($response->getBody()->getContents());

                    // Check if the response contains tags
                    if( isset($result->tags) ){

                        // Check if tags is an array
                        if( is_array($result->tags) ){

                            // Initialize an empty array to store the formatted tags
                            $formatted_tags = [];

                            // Loop through each tag
                            foreach( $result->tags as $tag ){
                                // Check if the tag is not empty
                                if( $tag ){
                                    // Add the tag to the formatted_tags array
                                    $formatted_tags[$tag] = $tag;
                                }
                            }

                            // Return the formatted_tags array
                            return $formatted_tags;
                        }
                    }
                }
            }  

            // If list_data is empty or the response does not contain tags, return an empty array
            return []; 
            
        }catch (\Exception $e) {
            // If an exception is thrown, return an empty array
			return [];
        }

         // If the function has not returned by this point, return an empty array
        return [];
    }

    /**
     * Get drip authorization url
     * 
     * @param
     * @return String
     * @since 1.4.0
     */
    public static function get_drip_authorization_url(){
       return 'https://api.getdrip.com/v2';
    } 

    /**
     * Get drip authorization basic auth key
     * 
     * @param String $username
     * @return String
     * @since 1.4.0
     */
    public static function get_drip_authorization_basic_auth( $username = '' ){
        $creds = get_option( '_wpfnl_addons_cred' );
        if( isset($creds['drip']) && isset($creds['drip']['drip_api']) ){
            $username = sanitize_text_field($creds['drip']['drip_api']);
        }
        $password = ""; // If there's no password, leave it as an empty string

        if( !$username ){
            return '';
        }
        // Concatenate the username and password with a colon
        $credentials = $username . ":" . $password;

        // Encode the credentials in Base64
        $encodedCredentials = base64_encode($credentials);
        return $encodedCredentials;
    }


    /**
     * Maybe drip enabled
     * 
     * @return Bool
     * @since 1.4.0
     */
    public static function maybe_drip_enable(){
        // Check if the pro integrations license is activated
        if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated() ){
            // Get the credentials from the '_wpfnl_addons_cred' option
            $creds = get_option( '_wpfnl_addons_cred' );
    
            // Check if the 'drip' key exists in the credentials and if the 'status', 'drip_status', and 'drip_api' keys exist in the 'drip' array
            if( isset($creds['drip']) && isset($creds['drip']['status']) && isset($creds['drip']['drip_status']) && isset($creds['drip']['drip_api'])){
                // Check if the 'drip_status' and 'status' keys in the 'drip' array are both set to 'active'
                if( 'active' == $creds['drip']['drip_status'] && 'active' == $creds['drip']['status'] ){
                    // If all conditions are met, return true
                    return true;
                }
            }
        }
    
        // If any of the conditions are not met, return false
        return false;
    }
}