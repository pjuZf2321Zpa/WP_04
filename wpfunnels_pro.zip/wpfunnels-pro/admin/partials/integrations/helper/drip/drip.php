<div class="single-addon drip">
    <div class="addon-header">
        <div class="logo">
            <?php
            include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/drip-logo.php';
            ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="drip-active" class="drip-active" name="drip-active" type="checkbox" value="" />
            <label for="drip-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="drip-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $drip_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-drip/';

                echo sprintf('Please connect with your Drip account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $drip_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php
                    echo __('API Key', 'wpfunnels-pro');
                    ?>
                </label>
                <input class="drip-api" name="drip-api" type="text">
                <span class="hints drip-hints drip-hints-api" style="color:red">Field required</span>
            </div>

            <div class="form-group action-btn">
                <a class="btn-default drip-auth" href="#">
                    <span class="btn-text"><?php
                                            echo __('Authorize Now', 'wpfunnels-pro');
                                            ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default drip-reset" href="#">
                    <span class="btn-text"><?php
                                            echo __('Reset', 'wpfunnels-pro');
                                            ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints drip-hints drip-hints-auth" style="color:red">Please input valid credentials</span>
            </div>
        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php
                include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/drip-favicon.php';
                ?>
            </span>
            <p class="banner-title"><?php
                                    echo __('Drip CRM is a cloud-based customer relationship management software for managing sales, marketing, and customer support in a single system.', 'wpfunnels-pro');
                                    ?></p>
        </div>
    </div>
</div>