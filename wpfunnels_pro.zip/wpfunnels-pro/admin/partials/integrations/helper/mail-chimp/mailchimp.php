<div class="single-addon mailchimp">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/mailchimp-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="mailchimp-active" name="mailchimp-active" class="mailchimp-active" type="checkbox" value="" />
            <label for="mailchimp-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="mailchimp-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $mailchimp_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-mailchimp/';

                echo sprintf('Please connect with your MailChimp account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $mailchimp_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('API key', 'wpfunnels-pro'); ?>
                </label>
                <input class="mailchimp-apikey" name="mailchimp-apikey" type="text" />
                <span class="hints mailchimp-hints mailchimp-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group">
                <label>
                    <?php echo __('Server', 'wpfunnels-pro'); ?>
                </label>
                <input class="mailchimp-server" name="mailchimp-server" type="text" />
                <span class="hints mailchimp-hints mailchimp-hints-server" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group action-btn">
                <button class="btn-default mailchimp-auth">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </button>
                <button class="btn-default mailchimp-reset">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </button>

                <span class="hints mailchimp-hints mailchimp-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/mailchimp-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('MailChimp is one of the best marketing, automation & email marketing platforms.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>