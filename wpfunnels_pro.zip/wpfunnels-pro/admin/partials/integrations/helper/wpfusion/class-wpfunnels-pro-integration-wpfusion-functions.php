<?php

namespace WPFunnelsPro\Integartions\Wpfusion;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;

class Wpfnl_Integartion_Wpfusion_functions
{


    /**
     * Get wpfusion tags by tag ID
     * 
     * @param Array 
     * @return Array
     * @since 1.2.9
     */
    public static function get_tags(){
        if( !wp_fusion()->crm || !wp_fusion()->crm->connect( $auth = null, $test = false ) ){
            return false;
        }
        #sync tags fro wpfusion
        $tags = wp_fusion()->crm->sync_tags();

        if( !$tags ){
            return false;
        }

        return $tags;
    }


    /**
     * Get wpfusion lists by wpfusion object
     * 
     * @param Object
     * @return Array
     * @since 1.2.9
     * 
     */
    public static function get_lists(){
        $formatted_lists = [];

        if( !wp_fusion()->crm || !wp_fusion()->crm->connect( $auth = null, $test = false ) ){
            return false;
        }

        #sync lists fro wpfusion
        $lists = wp_fusion()->crm->sync_lists();
        if( !$lists ){
            return false;
        }
        foreach( $lists as $key=>$list ){
            $formatted_lists[$key] = [
                'list_id' => $key,
                'value'   => $list
            ];
        }
        return $formatted_lists;
    }

    /**
     * Checks if the WP Fusion plugin is installed.
     *
     * @return bool True if WP Fusion is installed, false otherwise.
     * @since 1.2.9
     */
    public static function maybe_wpfusion_installed(){
        #check if wp_fusion class exists
        if( !class_exists('wp_fusion') ){
            return false;
        }
       
        if( !wp_fusion()->crm || !wp_fusion()->crm->connect( $auth = null, $test = false ) ){
            return false;
        }
        return true;
    }


    /**
     * maybe wpfusion settings enable
     * 
     * @return Bool
     * 
     * @since 1.2.9
     */
    public static function maybe_wpfusion_enable(){
        if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated()  ){
            $creds = get_option( '_wpfnl_addons_cred' );
           
            if( $creds ){
                if( self::maybe_wpfusion_installed() && isset($creds['wpfusion']['status'])  &&  $creds['wpfusion']['status'] == 'active' ){
                    return true;
                }
            }
        }
        return false;
    }

}