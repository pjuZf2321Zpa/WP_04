<div class="single-addon active-campaign">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/active-campaign-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="active-campaign-active" class="active-campaign-active" name="active-campaign-active" type="checkbox" value="" />
            <label for="active-campaign-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="active-campaign-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $active_campaign_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-activecampaign/';

                echo sprintf('Please connect with your ActiveCampaign account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $active_campaign_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('Base URL', 'wpfunnels-pro'); ?>
                </label>
                <input class="active-campaign-url" name="active-campaign-url" type="text">
                <span class="hints active-campaign-hints active-campaign-hints-url" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group">
                <label>
                    <?php echo __('API Token', 'wpfunnels-pro'); ?>
                </label>
                <input class="active-campaign-api" name="active-campaign-api" type="text">
                <span class="hints active-campaign-hints active-campaign-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group action-btn">
                <button class="btn-default active-campaign-auth">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </button>
                <button class="btn-default active-campaign-reset">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </button>

                <span class="hints active-campaign-hints active-campaign-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>

                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/active-campaign-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('ActiveCampaign - reliable platform with email marketing, automation, and CRM for enhanced customer experience.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>