<?php

namespace WPFunnelsPro\Integartions\Zoho;

use Error;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;
use GuzzleHttp\Exception\GuzzleException;

class Wpfnl_Integartion_Zoho_functions
{

    /**
     * Get lists
     * 
     * @return Array
     * @since 1.0.0
     */
    public static function get_lists(){
        try {
            
			$client = new \GuzzleHttp\Client();

            $creds = get_option( '_wpfnl_addons_cred' );
            $token = '';
            
            if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) ){
              
                self::get_token_by_refresh_token();
                $creds = get_option( '_wpfnl_addons_cred' );
                $token = $creds['zoho']['zoho_token'];
            }else{
                self::get_access_token();
                $creds = get_option( '_wpfnl_addons_cred' );
                if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) ){
                    $token = $creds['zoho']['zoho_token'];
                }
            }
            
            if( $token ){   
                
                $users = $client->request('GET', "https://www.zohoapis.com/crm/v6/users", [
                    'headers' => [
                        'Content-Type'      => 'application/json',
                        'Authorization'     => 'Zoho-oauthtoken '.$token,
                    ],
                ]);
           
                if( 200 == $users->getStatusCode() ){
                    $result = json_decode($users->getBody()->getContents());
                  
                    if( isset($result->users) ){
                        if( is_array($result->users) ){
                            $formatted_lists = [];
                            foreach( $result->users as $user ){
                                if( $user->full_name ){
                                    $formatted_lists[$user->id] = [
                                        'value' => $user->full_name 
                                    ];
                                }
                            }
                            return $formatted_lists;
                        }
                    }
                }
            }
            
        }catch (\Exception $e) {
			
        }
        return [];
        
    }


    /**
     * Get tags
     * 
     * @return Array
     * @since 1.0.0
     */
    public static function get_tags(){
        try {
			$client = new \GuzzleHttp\Client();
            $creds = get_option( '_wpfnl_addons_cred' );
            $token = '';
            
            if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) ){
              
                self::get_token_by_refresh_token();
                $creds = get_option( '_wpfnl_addons_cred' );
                $token = $creds['zoho']['zoho_token'];
            }else{
                self::get_access_token();
                $creds = get_option( '_wpfnl_addons_cred' );
                if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) ){
                    $token = $creds['zoho']['zoho_token'];
                }
            }

            // self::get_access_token();
            // $creds = get_option( '_wpfnl_addons_cred' );
            // if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_token']) ){
            //     $token = Wpfunnels_Aes_Ctr::decrypt( $creds['zoho']['zoho_token'], get_option('_wpfnl_security_key'), 256 );
            // }
            if( $token ){   
                $tags = $client->request('GET', "https://www.zohoapis.com/crm/v3/settings/tags?module=Contacts", [
                    'headers' => [
                        'Content-Type'      => 'application/json',
                        'Authorization'     => 'Zoho-oauthtoken '.$token,
                    ],
                ]);

                if( 200 == $tags->getStatusCode() ){
                    $result = json_decode($tags->getBody()->getContents());
                  
                    if( isset($result->tags) ){
                        if( is_array($result->tags) ){
                            $formatted_tags = [];
                            foreach( $result->tags as $tag ){
                                if( $tag->name ){
                                    $formatted_tags[$tag->id] = $tag->name;
                                }
                            }
                            return $formatted_tags;
                        }
                    }
                }
            }
            
        }catch (\Exception $e) {
			
        }
        return [];
    }


    /**
     * CC authentication
     * 
     * @since 1.0.3
     */
    public static function zoho_authentication( $clientId = '' , $redirect_url = '' ){

        if( $clientId && $redirect_url ){
            $scope           = 'ZohoCRM.modules.ALL,ZohoCRM.settings.ALL,ZohoCRM.users.ALL';
            $access_type           = 'offline';
            $auth_url        = self::get_zoho_authorization_url( $clientId, $redirect_url, $scope, $access_type );
            return $auth_url;
        }
        return '#';
    }

    /**
     * Get CC authorization url
     * 
     * @param
     * @return String
     * @since 1.0.3
     */
    public static function get_zoho_authorization_url( $clientId, $redirectURI, $scope, $access_type ){
        $baseURL = "https://accounts.zoho.com/oauth/v2/auth";
        $authURL = $baseURL . "?client_id=" . $clientId . "&scope=" . $scope . "&response_type=code&access_type=" . $access_type . "&redirect_uri=" . $redirectURI;
        return $authURL;
    } 


    /**
     * get access token 
     * 
     * @since 1.0.3
     * 
     */
    public static function get_access_token(){
        $creds = get_option( '_wpfnl_addons_cred' );
        if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_code']) && isset($creds['zoho']['zoho_url']) && isset($creds['zoho']['zoho_secret']) && isset($creds['zoho']['zoho_api']) ){
            try{
                $token_url = self::prepare_url_for_token( $creds['zoho']['zoho_code'], $creds['zoho']['zoho_url'], $creds['zoho']['zoho_api'], $creds['zoho']['zoho_secret'] );
                
                if( $token_url && $creds['zoho']['zoho_secret'] && $creds['zoho']['zoho_api'] ){
                    $client = new \GuzzleHttp\Client();
                    $response = $client->request('POST', $token_url, [
                        'headers' => [
                            'Content-Type'   => 'application/x-www-form-urlencoded',
                            'Authorization'  => 'Basic '.base64_encode($creds['zoho']['zoho_api'].':'.$creds['zoho']['zoho_secret']),
                        ],
                    ]);
                   
                    if( 200 == $response->getStatusCode() ){
                        $result = json_decode($response->getBody()->getContents());
                       
                        if( isset($result->access_token) && isset($result->refresh_token)){
                            $creds['zoho']['zoho_token']         = $result->access_token;
                            $creds['zoho']['zoho_refresh_token'] = $result->refresh_token;
                            update_option( '_wpfnl_addons_cred', $creds );
                            return true;
                        }
                    }

                   
                }
            }catch (\Exception $e) {
                error_log(print_r($e->getMessage(), true));
                return false;
            }catch (GuzzleException $e) {
                error_log(print_r($e->getMessage(), true));
                return false;
            }catch (\GuzzleHttp\Exception\ClientException $e) {
                error_log(print_r($e->getMessage(), true));
                return false;
            }
            
        }
    } 

    /**
     * get access token by refresh token
     * 
     * @since 1.0.3
     * 
     */
    public static function get_token_by_refresh_token(){
        $creds = get_option( '_wpfnl_addons_cred' );
     
        if( $creds && isset($creds['zoho']) && isset($creds['zoho']['zoho_code']) && isset($creds['zoho']['zoho_url']) && isset($creds['zoho']['zoho_secret']) && isset($creds['zoho']['zoho_api']) && isset($creds['zoho']['zoho_refresh_token']) ){
            $token_url = self::prepare_url_for_refresh_token( $creds['zoho']['zoho_refresh_token'], $creds['zoho']['zoho_api'],$creds['zoho']['zoho_secret'] );
            // $token_url = self::prepare_url_for_refresh_token( Wpfunnels_Aes_Ctr::decrypt( $creds['zoho']['zoho_refresh_token'],get_option('_wpfnl_security_key'), 256), '1000.D2875QAHMEW6CP480OUOX63BMCRWVG','8ad6e40321ff930e15b6393472bf9708ca1fcb8301' );
          
            if( $token_url && $creds['zoho']['zoho_secret'] && $creds['zoho']['zoho_api'] ){
                $client = new \GuzzleHttp\Client();
                try{
                    
                    $response = $client->request('POST', $token_url, [
                        'headers' => [
                            'Content-Type'   => 'application/x-www-form-urlencoded',
                            // 'Authorization'  => 'Basic '.base64_encode(Wpfunnels_Aes_Ctr::decrypt( $creds['zoho']['zoho_api'], get_option('_wpfnl_security_key'), 256 ).':'.Wpfunnels_Aes_Ctr::decrypt( $creds['zoho']['zoho_secret'], get_option('_wpfnl_security_key'), 256 )),
                        ],
                    ]);
                  
                    if( 200 == $response->getStatusCode() ){
                        $result = json_decode($response->getBody()->getContents());
                        
                        if( isset($result->access_token)){
                            $creds['zoho']['zoho_token']         =  $result->access_token;
                            update_option( '_wpfnl_addons_cred', $creds );
                            return true;
                        }
                    }
                }catch (\Exception $e) {
                    error_log(print_r($e->getMessage(), true));
                    return false;
                }
            }
        }
    }


    /**
     * prepare url for access token
     * 
     * @since 1.0.2
     * 
     */
    public static function prepare_url_for_token( $code, $redirect_url,$api, $secret ){
        
        if( $code && $redirect_url ){
            $baseURL = "https://accounts.zoho.com/oauth/v2/token";
            $token_url = $baseURL."?code=".$code."&client_id=".$api."&client_secret=".$secret."&redirect_uri=".$redirect_url."&grant_type=authorization_code";

           
            return $token_url;
        }
        return false;
    }


    /**
     * prepare url for access token
     * 
     * @since 1.0.2
     * 
     */
    public static function prepare_url_for_refresh_token( $refresh_token, $api, $secret ){
        
        if( $refresh_token ){
            $baseURL = "https://accounts.zoho.com/oauth/v2/token";
            $token_url = $baseURL."?refresh_token=".$refresh_token."&client_id=".$api."&client_secret=".$secret."&grant_type=refresh_token";
            return $token_url;
        }
        return false;
    }



    /**
     * maybe zoho settings enable
     * 
     * @return Bool
     * @since 1.0.3
     */
    public static function maybe_zoho_enable(){
        if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated() ){
            $creds = get_option( '_wpfnl_addons_cred' );
            if( isset($creds['zoho']) && isset($creds['zoho']['status']) && isset($creds['zoho']['zoho_status'])  && isset($creds['zoho']['zoho_url']) && isset($creds['zoho']['zoho_api'])){
                if( 'active' == $creds['zoho']['zoho_status'] && 'active' == $creds['zoho']['status'] ){
                    return true;
                }
            }
        }
        return false;
    }
}