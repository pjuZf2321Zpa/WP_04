<div class="single-addon pabbly-email">
    <div class="addon-header">
        <div class="logo">
            <?php
            include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/pabbly-email-logo.php';
            ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="pabbly-email-active" class="pabbly-email-active" name="pabbly-email-active" type="checkbox" value="" />
            <label for="pabbly-email-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="pabbly-email-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $pabbly_email_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-pabbly-email-marketing/';
                echo sprintf('Please connect with your Pabbly account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $pabbly_email_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php
                    echo __('API Secret', 'wpfunnels-pro'); ?>
                </label>
                <input class="pabbly-email-api" name="pabbly-email-api" type="text">
                <span class="hints pabbly-email-hints pabbly-email-hints-api" style="color:red">
                    <?php
                    echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>



            <div class="form-group action-btn">
                <a class="btn-default pabbly-email-auth" href="#">
                    <span class="btn-text"><?php
                                            echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default pabbly-email-reset" href="#">
                    <span class="btn-text"><?php
                                            echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints pabbly-email-hints pabbly-email-hints-auth" style="color:red">
                    <?php
                    echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/pabbly-email-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php
                                    echo __('Pabbly Email Marketing is a built-in email marketing powerhouse by Pabbly to run email campaigns with more control.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>