<div class="single-addon pabbly">
    <div class="addon-header">
        <div class="logo">
            <?php
            include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/pabbly-logo.php';
            ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="pabbly-active" class="pabbly-active" name="pabbly-active" type="checkbox" value="" />
            <label for="pabbly-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="pabbly-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $pabbly_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-pabbly-connect/';
                echo sprintf('Integration successful! You can now send data to Pabbly based on user events in your funnels <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $pabbly_guide_link);
                ?>
            </p>
        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/pabbly-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php
                                    echo __('Pabbly Connect is a powerful automation tool to help you share data between apps & automate manual repetitive tasks in real-time - No Coding Required!', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>