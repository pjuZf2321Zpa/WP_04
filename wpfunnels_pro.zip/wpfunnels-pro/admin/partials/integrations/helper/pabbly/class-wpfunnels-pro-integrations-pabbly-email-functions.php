<?php

namespace WPFunnelsPro\Integartions\Pabbly;

use Exception;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;


class Wpfnl_Integartion_Pabbly_Email_functions
{
    /**
     * Get lists from Pabbly account
     *
     * @return Array|bool
     * @since 1.2.8
     */
    public static function get_lists(){
        $creds = get_option( '_wpfnl_addons_cred' );
        if( $creds && isset($creds['pabbly_email'],$creds['pabbly_email']['pabbly_email_status'],$creds['pabbly_email']['pabbly_email_api'],$creds['pabbly_email']['status'])  ){
            $url = self::pabbly_authentication_url();
            if( $url ) {
                try {
                    $response = wp_remote_request($url.'subscribers-list', [
                        'headers' => [
                            'Authorization' => 'Bearer ' . Wpfunnels_Aes_Ctr::decrypt( $creds['pabbly_email']['pabbly_email_api'], WPFNL_SECURITY_KEY, 256 ),
                            'Content-Type' => 'application/json',
                        ],
                    ]);

                    $status_code = wp_remote_retrieve_response_code($response);
                    if( 200 === $status_code){
                        $response_body = wp_remote_retrieve_body($response);

                        $result = json_decode($response_body);
                        if( !empty($result->subscribers_list) && is_array($result->subscribers_list) ){

                            $formatted_lists = [];
                            foreach( $result->subscribers_list as $list ){
                                if( !empty($list->list_name) && !empty($list->list_id) ){
                                    $formatted_lists[$list->list_id] = [
                                        'list_id' => $list->list_id,
                                        'value'   => $list->list_name
                                    ];
                                }
                            }
                            return $formatted_lists;
                        }
                    }
                }catch (\Exception $e) {
                    error_log(print_r($e->getMessage(),1));
                }
            }
        }
    }

    /**
     * Get tags from Pabbly account
     *
     * @return Array
     * @since 1.2.8
     */
    public static function get_tags(){
        return false;
    }


    /**
     * Pabbly authentication url
     * @return String
     *
     * @since 1.2.8
     */
    public static function pabbly_authentication_url(){
        $auth_url = 'https://emails.pabbly.com/api/';
        return $auth_url;
    }


    /**
     * Check pabbly settings enable
     *
     * @return Bool
     * @since 1.2.8
     */
    public static function maybe_pabbly_email_enable(){
        if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated() ){
            $creds = get_option( '_wpfnl_addons_cred' );
            if( isset($creds['pabbly_email']) && isset($creds['pabbly_email']['status']) && isset($creds['pabbly_email']['pabbly_email_status']) && isset($creds['pabbly_email']['pabbly_email_api'])){
                if( 'active' === $creds['pabbly_email']['pabbly_email_status'] && 'active' === $creds['pabbly_email']['status'] ){
                    return true;
                }
            }
        }
        return false;;
    }
}
