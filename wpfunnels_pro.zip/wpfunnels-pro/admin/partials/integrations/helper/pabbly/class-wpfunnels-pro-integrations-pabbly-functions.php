<?php

namespace WPFunnelsPro\Integartions\Pabbly;
use WpfunnelsPro\Integrations\Wpfunnels_AES_Encription\Wpfunnels_Aes_Ctr;
use WPFunnelsPro\Integartions\Wpfnl_Integartion_functions;
use GuzzleHttp\Exception\GuzzleException;

class Wpfnl_Integartion_Pabbly_functions
{

    /**
     * Get lists
     *
     * @return Array
     * @since 1.0.0
     */
    public static function get_lists(){

    }


    /**
     * Get accounts
     *
     * @param Object
     * @param String
     *
     * @return Mix
     */
    public static function get_account( $client, $token ){

    }


    /**
     * Get tags
     *
     * @return Array
     * @since 1.0.0
     */
    public static function get_tags(){
        return [];
    }


    /**
     * pabbly authentication
     *
     * @since 1.0.3
     */
    public static function pabbly_authentication( $clientId = '' , $redirect_url = '' ){

    }

    /**
     * Get pabbly authorization url
     *
     * @param
     * @return String
     * @since 1.0.3
     */
    public static function get_pabbly_authorization_url( $clientId, $redirectURI, $scope, $state ){

    }


    /**
     * get access token
     *
     * @since 1.0.3
     *
     */
    public static function get_access_token(){

    }

    /**
     * get access token by refresh token
     *
     * @since 1.0.3
     *
     */
    public static function get_token_by_refresh_token(){

    }


    /**
     * prepare url for access token
     *
     * @since 1.0.2
     *
     */
    public static function prepare_url_for_token( $code, $redirect_url ){

    }


    /**
     * prepare url for access token
     *
     * @since 1.0.2
     *
     */
    public static function prepare_url_for_refresh_token( $refresh_token ){}



    /**
     * maybe Pabbly settings enable
     *
     * @return Bool
     * @since 1.0.3
     */
    public static function maybe_pabbly_enable(){
        if( Wpfnl_Integartion_functions::is_pro_integrations_license_activated() ){
            $creds = get_option( '_wpfnl_addons_cred' );
            if( isset($creds['pabbly']['status']) && 'active' === $creds['pabbly']['status']  ) {
                return true;
            }
        }
        return false;;
    }
}
