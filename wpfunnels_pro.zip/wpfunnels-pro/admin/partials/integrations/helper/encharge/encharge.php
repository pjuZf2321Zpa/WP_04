<div class="single-addon encharge">
    <div class="addon-header">
        <div class="logo">
            <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/encharge-logo.php'; ?>
        </div>

        <div class="wpfnl-switcher sm">
            <input id="encharge-active" class="encharge-active" name="encharge-active" type="checkbox" value="" />
            <label for="encharge-active"></label>
        </div>

    </div>

    <div class="addon-body">
        <div class="encharge-addon addon-authorize-form">
            <p class="addon-body-title">
                <?php
                $encharge_guide_link = 'https://getwpfunnels.com/docs/funnel-integrations/crm-integration/integrate-with-encharge/';
                echo sprintf('Please connect with your Encharge account by providing the following credentials: <a href="%s" target="_blank" title="View Documentation">Guide <svg width="8" height="9" viewBox="0 0 8 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7.5L7 1.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1.5H7V7.5" stroke="#7742E6" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> </a>', $encharge_guide_link);
                ?>
            </p>

            <div class="form-group">
                <label>
                    <?php echo __('API Key', 'wpfunnels-pro'); ?>
                </label>
                <input class="encharge-api" name="encharge-api" type="text">
                <span class="hints encharge-hints encharge-hints-api" style="color:red">
                    <?php echo __('Field required', 'wpfunnels-pro'); ?>
                </span>
            </div>

            <div class="form-group action-btn">
                <a class="btn-default encharge-auth" href="#">
                    <span class="btn-text"><?php echo __('Authorize Now', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <a class="btn-default encharge-reset" href="#">
                    <span class="btn-text"><?php echo __('Reset', 'wpfunnels-pro'); ?></span>
                    <span class="wpfnl-loader"></span>
                </a>
                <span class="hints encharge-hints encharge-hints-auth" style="color:red">
                    <?php echo __('Please input valid credentials', 'wpfunnels-pro'); ?>
                </span>
            </div>

        </div>

        <div class="addon-banner">
            <span class="logo">
                <?php include WPFNL_PRO_DIR . 'admin/assets/images/svg/integrations/encharge-favicon.php'; ?>
            </span>
            <p class="banner-title"><?php echo __('Encharge is an advanced automation tool focused on visually creating and running behaviour-based email campaigns easily.', 'wpfunnels-pro'); ?></p>
        </div>
    </div>
</div>