
<div class="wpfnl">
    <div class="wpfnl-addons">
        <div class="wpfnl-dashboard">
            <nav class="wpfnl-dashboard__nav">
                <?php use WPFunnels\Wpfnl_functions;
                require_once WPFNL_DIR . '/admin/partials/dashboard-nav.php'; ?>
            </nav>

            <div class="dashboard-nav__content">
                <div class="wpfnl-dashboard__header funnel-settings__header">
                    <div class="title">
                        <h2 class="addon-title">
                            <?php echo __('Integrations', 'wpfnl-pro'); ?>
                        </h2>
                    </div>
                </div>

                <div class="wpfnl-upgrade-notice" style="padding:40px 20px;text-align:center;">
                    <h3><?php echo __('Upgrade to Growth or Business Plan', 'wpfnl-pro'); ?></h3>
                    <p><?php echo __('CRM &amp; Email Automation integrations are available on the Growth and Business plans. Upgrade your WPFunnels Pro license to connect with ActiveCampaign, Mailchimp, HubSpot, and 15 more tools.', 'wpfnl-pro'); ?></p>
                    <a href="https://getwpfunnels.com/pricing/" target="_blank" class="button button-primary">
                        <?php echo __('Upgrade Now', 'wpfnl-pro'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
