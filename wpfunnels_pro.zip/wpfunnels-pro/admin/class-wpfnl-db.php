<?php
namespace WPFunnelsPro\Db;

use WPFunnels\Traits\SingletonTrait;

/**
 * The database related functionality.
 *
 * @link       https://rextheme.com
 * @since      1.0.0
 *
 * @package    Wpfnl_Pro
 * @subpackage Wpfnl_Pro/db
 */

class Wpfnl_Pro_Db {


    use SingletonTrait;
	
	/**
	 * The database version
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string
	 */
	private $db_version;
	

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string
	 */
	public function __construct( $db_version ) {
		$this->db_version = $db_version;
	}

	
    /**
     * Creating Tables for WPFunnels
     */
    public function create_wpfnl_pro_tables() {

        if ( is_multisite() ) {
            global $wpdb;
            $blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
            foreach ( $blog_ids as $blog_id ) {
                switch_to_blog( $blog_id );
                $this->create_analytics_table();
                $this->create_analytics_meta_table();
                update_option( 'wpfunnels_pro_tables_created', 'yes' );
                restore_current_blog();
            }
        } else {
            $this->create_analytics_table();
            $this->create_analytics_meta_table();
            update_option( 'wpfunnels_pro_tables_created', 'yes' );
        }
    }
	
    /**
     * WPFunnels Analytics TABLE
	 *
	 *@param NULL
	 *@return NULL
     */	
	public function create_analytics_table() {
		global $wpdb;

		$table_name = $wpdb->prefix . "wpfnl_analytics";
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
				id BIGINT(20) NOT NULL AUTO_INCREMENT,
				funnel_id BIGINT(20),
				step_id BIGINT(20),
				user_id BIGINT(20) DEFAULT 0,
				user_ip VARCHAR(225) DEFAULT NULL,
				visitor_type ENUM( 'new','returning' ) NOT NULL DEFAULT 'new',
				analytics_data LONGTEXT NULL,
				date_created DATETIME DEFAULT '0000-00-00 00:00:00',
				date_created_gmt DATETIME DEFAULT '0000-00-00 00:00:00',
				date_modified DATETIME DEFAULT '0000-00-00 00:00:00',
				date_modified_gmt DATETIME DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY (id)
			  ) $charset_collate; ";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta($sql);
	}

	/**
	 * Add missing indexes to the analytics tables for funnel canvas performance.
	 *
	 * The analytics tables previously only had a PRIMARY KEY, so lookups
	 * filtered by step_id or funnel_id (e.g. the funnel canvas stats)
	 * full-scanned the whole table, and the conversion lookup joined every
	 * meta row per visit. Each index is guarded individually via SHOW INDEX so
	 * this stays idempotent on sites where an index may already have been
	 * applied manually.
	 *
	 * @since 2.9.8
	 */
	public function maybe_add_analytics_indexes() {
		global $wpdb;
		$table      = $wpdb->prefix . WPFNL_PRO_ANALYTICS_TABLE;
		$meta_table = $wpdb->prefix . WPFNL_PRO_ANALYTICS_META_TABLE;

		// The analytics tables are created on activation, which won't have run
		// for a multisite subsite added afterwards. SHOW INDEX errors on a
		// missing table, and reporting success here would permanently mark the
		// migration done for a site that never received the indexes — so bail
		// and let a later request retry.
		$table_exists      = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore
		$meta_table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $meta_table ) ); // phpcs:ignore

		if ( ! $table_exists || ! $meta_table_exists ) {
			return false;
		}

		$existing    = $wpdb->get_results( "SHOW INDEX FROM `$table`", ARRAY_A ); // phpcs:ignore
		$index_names = wp_list_pluck( (array) $existing, 'Key_name' );

		if ( ! in_array( 'idx_step_id', $index_names, true ) ) {
			$wpdb->query( "ALTER TABLE `$table` ADD INDEX idx_step_id (step_id)" ); // phpcs:ignore
		}
		if ( ! in_array( 'idx_funnel_id', $index_names, true ) ) {
			$wpdb->query( "ALTER TABLE `$table` ADD INDEX idx_funnel_id (funnel_id)" ); // phpcs:ignore
		}

		$meta_existing    = $wpdb->get_results( "SHOW INDEX FROM `$meta_table`", ARRAY_A ); // phpcs:ignore
		$meta_index_names = wp_list_pluck( (array) $meta_existing, 'Key_name' );

		// Supports the per-step conversion lookup, which reads this table
		// directly on its denormalised step_id. meta_value is included because
		// a 'conversion' row is written for every visit regardless of outcome —
		// without it the index still matches every visit and each row has to be
		// read just to test the value. The prefix is enough to isolate
		// 'yes' from 'no'.
		if ( ! in_array( 'idx_step_meta_val', $meta_index_names, true ) ) {
			$wpdb->query( "ALTER TABLE `$meta_table` ADD INDEX idx_step_meta_val (step_id, meta_key(20), meta_value(3))" ); // phpcs:ignore
		}

		// The declared FOREIGN KEY on analytics_id does not reliably produce
		// an index on existing installs, leaving joins against this table
		// unindexed. Kept for the analytics reports that still join this way.
		if ( ! in_array( 'idx_analytics_meta_key', $meta_index_names, true ) ) {
			$wpdb->query( "ALTER TABLE `$meta_table` ADD INDEX idx_analytics_meta_key (analytics_id, meta_key(20))" ); // phpcs:ignore
		}

		return true;
	}

    /**
     * WPFunnels Analytics Meta TABLE
	 *
	 *@param NULL
	 *@return NULL
     */		
	public function create_analytics_meta_table() {
		global $wpdb;

		$analytics_table        = $wpdb->prefix .WPFNL_PRO_ANALYTICS_TABLE;
        $analytics_meta_table   = $wpdb->prefix . WPFNL_PRO_ANALYTICS_META_TABLE;

		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE IF NOT EXISTS $analytics_meta_table (
				id BIGINT(20) NOT NULL AUTO_INCREMENT,
				analytics_id BIGINT(20),
				funnel_id BIGINT(20) DEFAULT 0,
				step_id BIGINT(20) DEFAULT 0,
				meta_key VARCHAR(255) NULL,
				meta_value LONGTEXT NULL,
				PRIMARY KEY (id),
				FOREIGN KEY (`analytics_id`) REFERENCES $analytics_table(`id`) ON DELETE CASCADE
			  ) $charset_collate; ";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta($sql);
	}
	
}
