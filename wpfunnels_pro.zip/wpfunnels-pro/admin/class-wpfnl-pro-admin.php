<?php
namespace WPFunnelsPro\Admin;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://rextheme.com
 * @since      1.0.0
 *
 * @package    Wpfnl_Pro
 * @subpackage Wpfnl_Pro/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wpfnl_Pro
 * @subpackage Wpfnl_Pro/admin
 * @author     RexTheme <support@rextheme.com>
 */
class Wpfnl_Pro_Admin {

	/**
	 * Option flag recording that the "global funnels are active" notice was dismissed.
	 */
	const GBF_ACTIVE_NOTICE_DISMISSED_OPTION = 'wpfnl_pro_gbf_active_notice_dismissed';

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Page hooks
	 *
	 * @var array
	 */
	private $page_hooks = [
		'toplevel_page_wp_funnels',
		'wp-funnels_page_wp_funnel_settings',
		'wp-funnels_page_edit_funnel',
		'wp-funnels_page_create_funnel',
		'wp-funnels_page_wpfnl_settings',
		'wp-funnels_page_wpf-license',
		'wp-funnels_page_email-builder',
		'index.php',
		'plugins.php',
		'wpfunnels_page_wp_funnels',
	];


	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;

        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		// AI step editor panel: Bricks + Divi editors (front-end context)
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_ai_step_editor_frontend' ] );

        add_action( 'admin_notices', [ $this, 'integrations_addon_deactivated_notice' ] );
        add_action( 'admin_notices', [ $this, 'gbf_addon_deactivated_notice' ] );
        add_action( 'admin_notices', [ $this, 'active_global_funnels_notice' ] );
        add_action( 'admin_init', [ $this, 'maybe_dismiss_active_global_funnels_notice' ] );
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles($hook) {
		if (in_array($hook, $this->page_hooks)) {
			/**
			 * This function is provided for demonstration purposes only.
			 *
			 * An instance of this class should be passed to the run() function
			 * defined in Wpfnl_Pro_Loader as all of the hooks are defined
			 * in that particular class.
			 *
			 * The Wpfnl_Pro_Loader will then create the relationship
			 * between the defined hooks and the functions defined in this
			 * class.
			 */
			
			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'assets/css/wpfnl-pro-admin.css', array(), $this->version, 'all' );
		}
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts($hook) {
		if (in_array($hook, $this->page_hooks)) {
			/**
			 * This function is provided for demonstration purposes only.
			 *
			 * An instance of this class should be passed to the run() function
			 * defined in Wpfnl_Pro_Loader as all the hooks are defined
			 * in that particular class.
			 *
			 * The Wpfnl_Pro_Loader will then create the relationship
			 * between the defined hooks and the functions defined in this
			 * class.
			 */
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'assets/js/wpfnl-pro-admin.js', array( 'jquery' ), $this->version, false );
			//wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wpfnl-pro-checkout.js', array( 'jquery' ), $this->version, false );

			wp_localize_script( $this->plugin_name, 'WPFunnelProVars', array(
				'ajaxurl'      => admin_url( 'admin-ajax.php' ),
				'rest_api_url' => get_rest_url(),
				'admin_nonce'     => wp_create_nonce( 'wpfnl-admin' ),
			) );
		}
	}

	/**
	 * Enqueue the AI step-editor panel for Bricks and Divi front-end editors.
	 *
	 * Bricks editor: URL contains ?bricks=run
	 * Divi Visual Builder: URL contains ?et_fb=1
	 *
	 * @since 2.8.0
	 */
	public function enqueue_ai_step_editor_frontend() {
		$is_bricks = isset( $_GET['bricks'] ) && sanitize_key( $_GET['bricks'] ) === 'run';
		$is_divi   = isset( $_GET['et_fb'] )  && (int) $_GET['et_fb'] === 1;

		if ( ! $is_bricks && ! $is_divi ) {
			return;
		}

		$post_id = get_the_ID();
		if ( ! $post_id || get_post_type( $post_id ) !== 'wpfnl-steps' ) {
			return;
		}

		$builder   = $is_bricks ? 'bricks' : 'divi';
		$step_type = strtolower( get_post_meta( $post_id, '_step_type', true ) ?: 'landing' );
		$step_name = get_the_title( $post_id ) ?: ucfirst( $step_type ) . ' Page';
		$saved     = get_post_meta( $post_id, '_wpfnl_ai_step_context', true ) ?: [];

		wp_enqueue_style(
			'wpfnl-ai-step-editor',
			WPFNL_PRO_DIR_URL . 'admin/assets/css/ai-step-editor.css',
			[],
			WPFNL_PRO_VERSION
		);

		wp_enqueue_script(
			'wpfnl-ai-step-editor',
			WPFNL_PRO_DIR_URL . 'admin/assets/js/ai-step-editor.js',
			[ 'jquery' ],
			WPFNL_PRO_VERSION,
			true
		);

		wp_localize_script( 'wpfnl-ai-step-editor', 'wpfnlAiEditor', [
			'step_id'   => $post_id,
			'step_type' => $step_type,
			'step_name' => $step_name,
			'builder'   => $builder,
			'rest_url'  => get_rest_url(),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'saved'     => [
				'niche'    => sanitize_text_field( $saved['niche']    ?? '' ),
				'goal'     => sanitize_text_field( $saved['goal']     ?? '' ),
				'audience' => sanitize_text_field( $saved['audience'] ?? '' ),
				'offering' => sanitize_text_field( $saved['offering'] ?? '' ),
			],
		] );
	}
    /**
     * Show a one-time notice after the integrations addon has been auto-deactivated.
     *
     * @since 2.9.0
     */
    public function integrations_addon_deactivated_notice() {
        if ( ! get_transient( '_wpfnl_integrations_addon_deactivated' ) ) {
            return;
        }
        delete_transient( '_wpfnl_integrations_addon_deactivated' );
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php echo esc_html__( 'WPFunnels Pro Integrations addon has been deactivated. CRM & Email integrations are now built into WPFunnels Pro.', 'wpfnl-pro' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Show a one-time notice after the GBF addon has been auto-deactivated.
     *
     * @since 2.9.1
     */
    public function gbf_addon_deactivated_notice() {
        if ( ! get_transient( '_wpfnl_gbf_addon_deactivated' ) ) {
            return;
        }
        delete_transient( '_wpfnl_gbf_addon_deactivated' );
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php echo esc_html__( 'WPFunnels Pro - Global Funnel addon has been deactivated. Global Funnels are now built into WPFunnels Pro.', 'wpfnl-pro' ); ?>
            </p>
        </div>
        <?php
    }


    /**
     * Warn that one or more global funnels are live and overriding the store checkout.
     *
     * A global funnel is switched on by the `is_global_funnel` post meta alone. That
     * meta survives uninstalling the old standalone Global Funnel add-on, so sites
     * that used the add-on before it was merged into Pro can find their WooCommerce
     * checkout taken over again without having turned anything on themselves. Surface
     * exactly which funnels are responsible instead of leaving them to guess.
     *
     * @since 2.10.2
     */
    public function active_global_funnels_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( 'yes' === get_option( self::GBF_ACTIVE_NOTICE_DISMISSED_OPTION ) ) {
            return;
        }

        if ( ! \WPFunnelsPro\Wpfnl_Pro_Plan::is_gbf_license_active() ) {
            return;
        }

        $screen = get_current_screen();
        $show_on = [ 'plugins', 'dashboard' ];
        if ( ! $screen || ( ! in_array( $screen->id, $show_on, true ) && false === strpos( $screen->id, 'funnel' ) ) ) {
            return;
        }

        $global_funnels = \WPFunnelsPro\GBF\Actions\Wpfnl_Pro_GB_Actions::getInstance()->get_activated_global_funnels();
        if ( empty( $global_funnels ) ) {
            return;
        }

        $dismiss_url = wp_nonce_url(
            add_query_arg( 'wpfnl_dismiss_gbf_active_notice', '1' ),
            'wpfnl_dismiss_gbf_active_notice'
        );
        ?>
        <div class="notice notice-warning">
            <p>
                <strong><?php echo esc_html__( 'WPFunnels: Global Funnels are active on your store.', 'wpfnl-pro' ); ?></strong>
            </p>
            <p>
                <?php echo esc_html__( 'Global Funnels are now part of WPFunnels Pro. The funnels below are marked as global funnels, so they replace your WooCommerce cart and checkout whenever their conditions match:', 'wpfnl-pro' ); ?>
            </p>
            <ul style="list-style: disc; margin-left: 2em;">
                <?php foreach ( $global_funnels as $funnel ) : ?>
                    <li>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=edit_funnel&id=' . $funnel->ID . '&step_id=0' ) ); ?>">
                            <?php echo esc_html( get_the_title( $funnel->ID ) ); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p>
                <?php echo esc_html__( 'If you did not mean to run a global funnel, turn off the Global Funnel toggle on each of them to restore your default checkout.', 'wpfnl-pro' ); ?>
                <a href="<?php echo esc_url( $dismiss_url ); ?>"><?php echo esc_html__( 'Dismiss this notice', 'wpfnl-pro' ); ?></a>
            </p>
        </div>
        <?php
    }


    /**
     * Persist dismissal of the active global funnels notice.
     *
     * @since 2.10.2
     */
    public function maybe_dismiss_active_global_funnels_notice() {
        if ( ! isset( $_GET['wpfnl_dismiss_gbf_active_notice'] ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        check_admin_referer( 'wpfnl_dismiss_gbf_active_notice' );

        update_option( self::GBF_ACTIVE_NOTICE_DISMISSED_OPTION, 'yes' );

        wp_safe_redirect( remove_query_arg( [ 'wpfnl_dismiss_gbf_active_notice', '_wpnonce' ] ) );
        exit;
    }

}
