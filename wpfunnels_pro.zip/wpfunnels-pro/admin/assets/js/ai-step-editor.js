/**
 * WPFunnels – In-Editor "Ask AI" Panel
 *
 * Injects a floating "Ask AI" trigger button + side panel into the page builder
 * editor (Elementor, Bricks, Divi). The panel lets users fill in structured
 * context (niche, goal, audience, offering) and regenerates copy for the current
 * funnel step without leaving the editor.
 *
 * Localised data expected on `window.wpfnlAiEditor`:
 *   step_id      – WP post ID of the current step
 *   step_type    – 'landing'|'checkout'|'upsell'|'downsell'|'thankyou'
 *   step_name    – human-readable step name
 *   builder      – 'elementor'|'bricks'|'divi'|'gutenberg'
 *   rest_url     – WP REST API root URL
 *   nonce        – WP nonce for REST requests
 *   saved        – { niche, goal, audience, offering } from previous run (may be empty)
 *
 * @package WPFunnelsPro
 * @since   2.8.0
 */
(function ($) {
	'use strict';

	/* ── Guard ─────────────────────────────────────────────── */
	if ( typeof window.wpfnlAiEditor === 'undefined' ) { return; }
	var cfg = window.wpfnlAiEditor;

	/* ── Colour token (matches CSS) ────────────────────────── */
	var PURPLE = '#6E42D3';

	/* ── Step-type display names ───────────────────────────── */
	var STEP_LABELS = {
		landing:  'Landing Page',
		checkout: 'Checkout Page',
		upsell:   'Upsell Page',
		downsell: 'Downsell Page',
		thankyou: 'Thank-You Page',
	};

	/* ── Helpers ───────────────────────────────────────────── */
	function esc( s ) {
		return $('<span>').text(s).html();
	}

	function highlight( text ) {
		return '<mark class="wpfnl-ase-hl">' + esc( text ) + '</mark>';
	}

	/* ── Build rendered prompt text with highlighted keywords ─ */
	function buildPromptHTML( niche, goal, audience, offering ) {
		var type = cfg.step_type || 'landing';
		var label = STEP_LABELS[ type ] || ( type.charAt(0).toUpperCase() + type.slice(1) + ' Page' );

		if ( ! niche && ! goal && ! audience && ! offering ) {
			return '<span class="wpfnl-ase-prompt-placeholder">Fill in the fields above — your prompt will appear here.</span>';
		}

		var html = 'Generate a compelling <strong>' + esc( label ) + '</strong>';
		if ( niche )    { html += ' for ' + highlight( niche ); }
		if ( audience ) { html += ', targeting ' + highlight( audience ); }
		if ( goal )     { html += '. The goal is to ' + highlight( goal ); }
		if ( offering ) { html += ' by offering a ' + highlight( offering ); }
		html += '.';
		return html;
	}

	/* ── Build chips row ───────────────────────────────────── */
	function buildChips( niche, goal, audience, offering ) {
		var html = '';
		var CHIP_ICONS = {
			niche:    '<svg width="11" height="11" viewBox="0 0 24 24" fill="none"><path d="M22 12h-4l-3 9L9 3l-3 9H2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
			goal:     '<svg width="11" height="11" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>',
			audience: '<svg width="11" height="11" viewBox="0 0 24 24" fill="none"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="9" cy="7" r="4" stroke="currentColor" stroke-width="2"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
			offering: '<svg width="11" height="11" viewBox="0 0 24 24" fill="none"><path d="M20 7H4l1.5 9h13.5L20 7z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="18" r="2" fill="currentColor"/></svg>',
		};
		var pairs = [ ['niche', niche], ['goal', goal], ['audience', audience], ['offering', offering] ];
		pairs.forEach(function(p) {
			if (!p[1]) return;
			html += '<span class="wpfnl-ase-chip" data-field="' + p[0] + '">' +
				CHIP_ICONS[ p[0] ] + esc(p[1]) +
				'<button class="wpfnl-ase-chip-rm" aria-label="Remove">×</button></span>';
		});
		return html || '<span class="wpfnl-ase-chips-empty">Add details above to see your profile.</span>';
	}

	/* ── Build the full panel HTML ─────────────────────────── */
	function buildPanelHTML() {
		var type      = cfg.step_type || 'landing';
		var stepLabel = STEP_LABELS[ type ] || 'Funnel Step';
		var saved     = cfg.saved || {};

		return (
			/* floating trigger */
			'<button id="wpfnl-ase-trigger" class="wpfnl-ase-trigger" title="Ask AI">' +
				'<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z"/></svg>' +
				'<span>Ask AI</span>' +
			'</button>' +

			/* panel */
			'<div id="wpfnl-ase-panel" class="wpfnl-ase-panel" aria-hidden="true">' +

				/* header */
				'<div class="wpfnl-ase-hd">' +
					'<span class="wpfnl-ase-hd-icon">' +
						'<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z"/></svg>' +
					'</span>' +
					'<h3 class="wpfnl-ase-hd-title">Ask AI</h3>' +
					'<button class="wpfnl-ase-hd-close" aria-label="Close panel">' +
						'<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>' +
					'</button>' +
				'</div>' +

				/* main panels (prompt form + loading + success + error) */
				'<div class="wpfnl-ase-screens">' +

					/* ── Prompt screen ── */
					'<div class="wpfnl-ase-screen" id="wpfnl-ase-screen-form">' +

						'<div class="wpfnl-ase-step-badge-row">' +
							'<span class="wpfnl-ase-step-badge">' + esc(stepLabel) + '</span>' +
							'<span class="wpfnl-ase-step-hint">AI will regenerate this step\'s copy.</span>' +
						'</div>' +

						'<p class="wpfnl-ase-sub">Fill in the fields below. The more context you provide, the better your copy will be.</p>' +

						/* fields */
						'<div class="wpfnl-ase-fields">' +

							field( 'Business Niche',    'wpfnl-ase-niche',    'niche',    'e.g. Fitness Coaching',    saved.niche    || '' ) +
							field( 'Goal of this Page', 'wpfnl-ase-goal',     'goal',     'e.g. book appointments',  saved.goal     || '' ) +
							field( 'Target Audience',   'wpfnl-ase-audience', 'audience', 'e.g. small businesses',   saved.audience || '' ) +
							field( 'What are you offering?', 'wpfnl-ase-offering', 'offering', 'e.g. free consultation', saved.offering || '' ) +

						'</div>' +

						/* step profile card */
						'<div class="wpfnl-ase-profile">' +
							'<div class="wpfnl-ase-profile-title">Step Profile</div>' +
							'<div class="wpfnl-ase-chips" id="wpfnl-ase-chips">' +
								buildChips( saved.niche||'', saved.goal||'', saved.audience||'', saved.offering||'' ) +
							'</div>' +
							'<div class="wpfnl-ase-prompt" id="wpfnl-ase-prompt">' +
								buildPromptHTML( saved.niche||'', saved.goal||'', saved.audience||'', saved.offering||'' ) +
							'</div>' +
							'<div class="wpfnl-ase-profile-ft">' +
								'<button class="wpfnl-ase-gen-btn" id="wpfnl-ase-generate">' +
									'<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z"/></svg>' +
									'Generate' +
								'</button>' +
							'</div>' +
						'</div>' +

					'</div>' + /* /screen-form */

					/* ── Loading screen ── */
					'<div class="wpfnl-ase-screen wpfnl-ase-screen--hidden" id="wpfnl-ase-screen-loading">' +
						'<div class="wpfnl-ase-spinner"></div>' +
						'<p class="wpfnl-ase-loading-msg">Generating copy with AI&hellip;</p>' +
						'<p class="wpfnl-ase-loading-sub">This usually takes 10–20 seconds.</p>' +
					'</div>' +

					/* ── Success screen ── */
					'<div class="wpfnl-ase-screen wpfnl-ase-screen--hidden" id="wpfnl-ase-screen-success">' +
						'<div class="wpfnl-ase-success-icon">' +
							'<svg width="32" height="32" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#16A34A" stroke-width="2"/><path d="M8 12l3 3 5-5" stroke="#16A34A" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
						'</div>' +
						'<p class="wpfnl-ase-success-msg">Copy regenerated!</p>' +
						'<p class="wpfnl-ase-success-sub">Reload the editor to see your new content applied to the page.</p>' +
						'<button class="wpfnl-ase-reload-btn" id="wpfnl-ase-reload">' +
							'Reload Editor' +
							'<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M23 4v6h-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 20v-6h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
						'</button>' +
						'<button class="wpfnl-ase-back-btn" id="wpfnl-ase-back-from-success">← Regenerate</button>' +
					'</div>' +

					/* ── Error screen ── */
					'<div class="wpfnl-ase-screen wpfnl-ase-screen--hidden" id="wpfnl-ase-screen-error">' +
						'<div class="wpfnl-ase-error-icon">' +
							'<svg width="32" height="32" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#DC2626" stroke-width="2"/><path d="M12 8v4M12 16h.01" stroke="#DC2626" stroke-width="2.2" stroke-linecap="round"/></svg>' +
						'</div>' +
						'<p class="wpfnl-ase-error-msg" id="wpfnl-ase-error-msg">An error occurred.</p>' +
						'<button class="wpfnl-ase-back-btn" id="wpfnl-ase-back-from-error">← Try Again</button>' +
					'</div>' +

				'</div>' + /* /screens */

			'</div>' /* /panel */
		);
	}

	/* ── Single field builder ──────────────────────────────── */
	function field( label, id, dataField, placeholder, value ) {
		return (
			'<div class="wpfnl-ase-field">' +
				'<label class="wpfnl-ase-label" for="' + id + '">' + esc(label) + '</label>' +
				'<input type="text" id="' + id + '" class="wpfnl-ase-input" data-field="' + dataField + '"' +
					' placeholder="' + esc(placeholder) + '"' +
					' value="' + esc(value) + '">' +
			'</div>'
		);
	}

	/* ── Show a specific screen ────────────────────────────── */
	function showScreen( name ) {
		$('.wpfnl-ase-screen').addClass('wpfnl-ase-screen--hidden');
		$('#wpfnl-ase-screen-' + name).removeClass('wpfnl-ase-screen--hidden');
	}

	/* ── Refresh prompt preview + chips ───────────────────── */
	function refreshPreview() {
		var niche    = $('#wpfnl-ase-niche').val().trim();
		var goal     = $('#wpfnl-ase-goal').val().trim();
		var audience = $('#wpfnl-ase-audience').val().trim();
		var offering = $('#wpfnl-ase-offering').val().trim();

		$('#wpfnl-ase-chips').html( buildChips( niche, goal, audience, offering ) );
		$('#wpfnl-ase-prompt').html( buildPromptHTML( niche, goal, audience, offering ) );

		/* enable/disable generate button */
		var hasInput = niche || goal || audience || offering;
		$('#wpfnl-ase-generate').prop( 'disabled', ! hasInput );
	}

	/* ── Open / close panel ────────────────────────────────── */
	function openPanel() {
		$('#wpfnl-ase-panel').addClass('wpfnl-ase-panel--open').attr('aria-hidden', 'false');
		$('#wpfnl-ase-trigger').addClass('wpfnl-ase-trigger--active');
	}

	function closePanel() {
		$('#wpfnl-ase-panel').removeClass('wpfnl-ase-panel--open').attr('aria-hidden', 'true');
		$('#wpfnl-ase-trigger').removeClass('wpfnl-ase-trigger--active');
	}

	/* ── Call REST API ─────────────────────────────────────── */
	function doGenerate() {
		var niche    = $('#wpfnl-ase-niche').val().trim();
		var goal     = $('#wpfnl-ase-goal').val().trim();
		var audience = $('#wpfnl-ase-audience').val().trim();
		var offering = $('#wpfnl-ase-offering').val().trim();

		if ( ! niche && ! goal && ! audience && ! offering ) {
			$('#wpfnl-ase-niche').focus();
			return;
		}

		showScreen('loading');

		$.ajax({
			url: cfg.rest_url + 'wpfunnels/v1/ai/regenerate-step',
			method: 'POST',
			contentType: 'application/json',
			beforeSend: function ( xhr ) {
				xhr.setRequestHeader( 'X-WP-Nonce', cfg.nonce );
			},
			data: JSON.stringify({
				step_id:   cfg.step_id,
				step_type: cfg.step_type,
				builder:   cfg.builder,
				niche:     niche,
				goal:      goal,
				audience:  audience,
				offering:  offering,
			}),
			success: function () {
				showScreen('success');
			},
			error: function ( xhr ) {
				var msg = 'Generation failed. Please try again.';
				if ( xhr.responseJSON && xhr.responseJSON.message ) {
					msg = xhr.responseJSON.message;
				}
				$('#wpfnl-ase-error-msg').text( msg );
				showScreen('error');
			},
		});
	}

	/* ── Init ──────────────────────────────────────────────── */
	function init() {
		/* Inject HTML */
		$('body').append( buildPanelHTML() );

		/* Initial state */
		refreshPreview();
		$('#wpfnl-ase-generate').prop('disabled', true);

		/* Trigger: open panel */
		$(document).on('click', '#wpfnl-ase-trigger', function () {
			if ( $('#wpfnl-ase-panel').hasClass('wpfnl-ase-panel--open') ) {
				closePanel();
			} else {
				openPanel();
			}
		});

		/* Close button */
		$(document).on('click', '.wpfnl-ase-hd-close', closePanel);

		/* Live-update preview on input */
		$(document).on('input', '.wpfnl-ase-input', refreshPreview);

		/* Remove chip → clear matching input */
		$(document).on('click', '.wpfnl-ase-chip-rm', function () {
			var fieldKey = $(this).closest('.wpfnl-ase-chip').data('field');
			$('.wpfnl-ase-input[data-field="' + fieldKey + '"]').val('');
			refreshPreview();
		});

		/* Generate button */
		$(document).on('click', '#wpfnl-ase-generate', doGenerate);

		/* Reload editor after success */
		$(document).on('click', '#wpfnl-ase-reload', function () {
			window.location.reload();
		});

		/* Back from success/error */
		$(document).on('click', '#wpfnl-ase-back-from-success, #wpfnl-ase-back-from-error', function () {
			showScreen('form');
		});

		/* Close on clicking outside (backdrop) */
		$(document).on('click', function ( e ) {
			if (
				$('#wpfnl-ase-panel').hasClass('wpfnl-ase-panel--open') &&
				! $('#wpfnl-ase-panel').is(e.target) &&
				! $('#wpfnl-ase-panel').has(e.target).length &&
				! $('#wpfnl-ase-trigger').is(e.target) &&
				! $('#wpfnl-ase-trigger').has(e.target).length
			) {
				closePanel();
			}
		});
	}

	/* ── Boot on DOM ready ─────────────────────────────────── */
	$(document).ready(function () {
		/* Small delay so the builder's own UI has finished rendering */
		setTimeout( init, 800 );
	});

})(jQuery);
