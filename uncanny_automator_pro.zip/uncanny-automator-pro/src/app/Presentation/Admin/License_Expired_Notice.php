<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Presentation\Admin;

use Uncanny_Automator\App\Presentation\Admin\Notices\Notice;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Dismissal;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Message;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Screen;
use Uncanny_Automator_Pro\Licensing;

/**
 * "Your license expired", while the Pro license is expired, with when and
 * what still works ({@see Licensing::expiry_message()}). Shown by
 * Automator's notice center on every admin page except Settings. As before,
 * its X closes it for this view, and on Automator's own pages it has none.
 *
 * @since 8.0.0
 */
final class License_Expired_Notice extends Notice {

	/**
	 * @var Licensing
	 */
	private $licensing;

	/**
	 * @param Licensing $licensing Words the expiry.
	 */
	public function __construct( Licensing $licensing ) {
		$this->licensing = $licensing;
	}

	/**
	 * @return string
	 */
	public function id(): string {
		return 'pro-license-expired';
	}

	/**
	 * @return string
	 */
	public function capability(): string {
		return automator_pro_get_admin_capability();
	}

	/**
	 * @return Notice_Dismissal
	 */
	public function dismissal(): Notice_Dismissal {
		return false !== strpos( $this->query( 'post_type' ), 'uo-recipe' ) ? Notice_Dismissal::none() : Notice_Dismissal::for_this_view();
	}

	/**
	 * @param Notice_Screen $screen The screen.
	 *
	 * @return Notice_Message|null
	 */
	public function message( Notice_Screen $screen ): ?Notice_Message {

		if ( 'uncanny-automator-config' === $this->query( 'page' ) ) {
			return null;
		}

		if ( 'expired' !== automator_get_option( 'uap_automator_pro_license_status', '' ) ) {
			return null;
		}

		return $this->expired( $this->licensing->expiry_message() );
	}

	/**
	 * Expired lately, past the grace window (Licensing::EXPIRY_GRACE_DAYS), and on an unknown date.
	 *
	 * @return Notice_Message[]
	 */
	public function previews(): array {

		return array(
			$this->expired( $this->licensing->expiry_sentence( '', gmdate( 'Y-m-d H:i:s', time() - 10 * DAY_IN_SECONDS ) ) ),
			$this->expired( $this->licensing->expiry_sentence( '', gmdate( 'Y-m-d H:i:s', time() - 60 * DAY_IN_SECONDS ) ) ),
			$this->expired( $this->licensing->expiry_sentence( '', '' ) ),
		);
	}

	/**
	 * @param string $sentence What the expiry means, as Licensing words it.
	 *
	 * @return Notice_Message
	 */
	private function expired( string $sentence ): Notice_Message {

		return Notice_Message::error( esc_html_x( 'Your Uncanny Automator Pro license has expired', 'Admin notice', 'uncanny-automator-pro' ) )
			->with_paragraph( $sentence );
	}

	/**
	 * A read-only query argument of this admin page.
	 *
	 * @param string $key The argument.
	 *
	 * @return string
	 */
	private function query( string $key ): string {
		return isset( $_GET[ $key ] ) ? sanitize_key( wp_unslash( $_GET[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only: which screen is showing.
	}
}
