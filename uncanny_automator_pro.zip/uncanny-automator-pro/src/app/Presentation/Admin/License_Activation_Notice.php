<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Presentation\Admin;

use Uncanny_Automator\App\Presentation\Admin\Notices\Notice;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Dismissal;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Message;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Screen;

/**
 * "Activate your copy of Uncanny Automator Pro", while no license key is
 * entered. Shown by Automator's notice center on every admin page except
 * Settings, where the License tab asks for the key. Its X closes it for this
 * view.
 *
 * @since 8.0.0
 */
final class License_Activation_Notice extends Notice {

	/**
	 * @return string
	 */
	public function id(): string {
		return 'pro-license-activation';
	}

	/**
	 * @return string
	 */
	public function capability(): string {
		return automator_pro_get_admin_capability();
	}

	/**
	 * @return Notice_Dismissal
	 */
	public function dismissal(): Notice_Dismissal {
		return Notice_Dismissal::for_this_view();
	}

	/**
	 * @param Notice_Screen $screen The screen.
	 *
	 * @return Notice_Message|null
	 */
	public function message( Notice_Screen $screen ): ?Notice_Message {

		if ( 'uncanny-automator-config' === $this->query( 'page' ) ) {
			return null;
		}

		$license_key = automator_get_option( 'uap_automator_pro_license_key', '' );
		if ( '' !== trim( (string) $license_key ) ) {
			return null;
		}

		return $this->activate();
	}

	/**
	 * @return Notice_Message[]
	 */
	public function previews(): array {

		return array( $this->activate() );
	}

	/**
	 * @return Notice_Message
	 */
	private function activate(): Notice_Message {

		$sentence = sprintf(
			/* translators: 1: "Activate" link, 2: the plugin name, 3: "here" link to the pricing page */
			esc_html__( "%1\$s your copy of %2\$s to unlock unlimited tool usage for your AI, every Pro trigger and action, and addons (Plus and up). Don't have a license key? Click %3\$s to buy one.", 'uncanny-automator-pro' ),
			sprintf( '<a href="%s">%s</a>', esc_url( admin_url( 'edit.php?post_type=uo-recipe&page=uncanny-automator-config' ) ), esc_html__( 'Activate', 'uncanny-automator-pro' ) ),
			'<strong>Uncanny Automator Pro</strong>',
			sprintf( '<a href="%s" target="_blank">%s</a>', esc_url( 'https://automatorplugin.com/pricing/?utm_source=uncanny-automator-pro&utm_medium=in-plugin&utm_content=admin-header#pricing' ), esc_html__( 'here', 'uncanny-automator-pro' ) )
		);

		return Notice_Message::warning( esc_html_x( 'Activate Uncanny Automator Pro', 'Admin notice', 'uncanny-automator-pro' ) )
			->with_paragraph( $sentence );
	}

	/**
	 * A read-only query argument of this admin page.
	 *
	 * @param string $key The argument.
	 *
	 * @return string
	 */
	private function query( string $key ): string {
		return isset( $_GET[ $key ] ) ? sanitize_key( wp_unslash( $_GET[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only: which screen is showing.
	}
}
