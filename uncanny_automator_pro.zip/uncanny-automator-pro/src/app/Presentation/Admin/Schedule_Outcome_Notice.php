<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Presentation\Admin;

use Uncanny_Automator\App\Presentation\Admin\Notices\Notice;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Dismissal;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Message;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Screen;

/**
 * "Scheduled recipe cancelled" or "Recipe queued to run", once, on the
 * Scheduled recipes page a Cancel or Run now returned to. The handlers in
 * {@see \Uncanny_Automator_Pro\Integrations\Schedule\Admin_Helper} leave a 60-second transient and a query argument; the
 * notice center shows the outcome and it is forgotten once drawn.
 *
 * @since 8.0.0
 */
final class Schedule_Outcome_Notice extends Notice {

	/**
	 * The outcomes: query argument and transient of each.
	 */
	private const OUTCOMES = array(
		'cancelled'     => 'uo_recipe_schedule_cancelled',
		'run_completed' => 'uo_recipe_schedule_run_now',
	);

	/**
	 * @return string
	 */
	public function id(): string {
		return 'pro-schedule-outcome';
	}

	/**
	 * @return string
	 */
	public function capability(): string {
		return automator_pro_get_capability();
	}

	/**
	 * @return Notice_Dismissal
	 */
	public function dismissal(): Notice_Dismissal {
		return Notice_Dismissal::for_this_view();
	}

	/**
	 * @param Notice_Screen $screen The screen.
	 *
	 * @return Notice_Message|null
	 */
	public function message( Notice_Screen $screen ): ?Notice_Message {

		$outcome = $this->outcome();

		return '' !== $outcome ? $this->said( $outcome ) : null;
	}

	/**
	 * Cancelled, and queued.
	 *
	 * @return Notice_Message[]
	 */
	public function previews(): array {

		return array_map( array( $this, 'said' ), array_keys( self::OUTCOMES ) );
	}

	/**
	 * @param string $outcome A key of self::OUTCOMES.
	 *
	 * @return Notice_Message
	 */
	private function said( string $outcome ): Notice_Message {

		if ( 'cancelled' === $outcome ) {
			return Notice_Message::success( esc_html_x( 'Scheduled recipe cancelled', 'Admin notice', 'uncanny-automator-pro' ) );
		}

		return Notice_Message::success( esc_html_x( 'Recipe queued to run', 'Admin notice', 'uncanny-automator-pro' ) )
			->with_paragraph( esc_html_x( 'The recipe is queued to run shortly.', 'Admin notice', 'uncanny-automator-pro' ) );
	}

	/**
	 * Drawn: forget the outcome, so it is shown once.
	 *
	 * @return void
	 */
	public function shown(): void {

		$outcome = $this->outcome();
		if ( '' !== $outcome ) {
			delete_transient( self::OUTCOMES[ $outcome ] );
		}
	}

	/**
	 * The outcome this page shows: its query argument is present and its
	 * transient is still there; '' when none.
	 *
	 * @return string
	 */
	private function outcome(): string {

		foreach ( self::OUTCOMES as $argument => $transient ) {
			if ( isset( $_GET[ $argument ] ) && false !== get_transient( $transient ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only: which outcome to show.
				return $argument;
			}
		}

		return '';
	}
}
