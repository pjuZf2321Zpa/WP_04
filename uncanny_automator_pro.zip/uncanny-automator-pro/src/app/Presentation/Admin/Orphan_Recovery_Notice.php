<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Presentation\Admin;

use Uncanny_Automator\App\Presentation\Admin\Notices\Notice;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Action;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Message;
use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Screen;
use Uncanny_Automator_Pro\Async_Orphan_Recovery;

/**
 * Proactive admin nudge for the "Scheduled actions recovery" tool. On the first admin
 * page load after this version ships it cheaply checks whether the site has at least one
 * RECOVERABLE orphaned scheduled action (the leftover from the 7.2.0 cleanup-cap bug); if
 * so it raises a notice pointing the admin at Status > Tools > Scheduled actions recovery.
 *
 * Detects and notifies only: it never recovers anything. The admin still opens the tool
 * and clicks recover. The notice clears itself once recovery is done, so it has no
 * dismiss. Shown by Automator's notice center; Bootstrap wires maybe_evaluate() to
 * admin_init.
 *
 * @since 8.0.0
 */
final class Orphan_Recovery_Notice extends Notice {

	/**
	 * uap_options flag holding the one-time evaluation result.
	 *
	 * Absent  → never evaluated (evaluate once on admin_init).
	 * '1'     → an orphan was found; show the nudge (subject to the throttled re-check).
	 * '0'     → no orphan / recovery done; nudge is permanently off.
	 *
	 * @var string
	 */
	const FLAG_OPTION = 'automator_orphan_recovery_nudge';

	/**
	 * Transient caching the throttled re-check result, so has_recoverable_orphans() is not
	 * re-run on every admin_init once the flag is '1'.
	 *
	 * @var string
	 */
	const RECHECK_TRANSIENT = 'automator_orphan_recovery_nudge_recheck';

	/**
	 * How long the throttled re-check is cached.
	 *
	 * @var int
	 */
	const RECHECK_TTL = 6 * HOUR_IN_SECONDS;

	/**
	 * @return string
	 */
	public function id(): string {
		return 'pro-orphan-recovery';
	}

	/**
	 * @return string
	 */
	public function capability(): string {
		return automator_pro_get_admin_capability();
	}

	/**
	 * No dismiss: the nudge clears itself once recovery is done.
	 *
	 * @param Notice_Screen $screen The screen.
	 *
	 * @return Notice_Message|null
	 */
	public function message( Notice_Screen $screen ): ?Notice_Message {

		if ( ! $this->should_show() ) {
			return null;
		}

		return $this->recover();
	}

	/**
	 * @return Notice_Message[]
	 */
	public function previews(): array {

		return array( $this->recover() );
	}

	/**
	 * @return Notice_Message
	 */
	private function recover(): Notice_Message {

		return Notice_Message::warning( esc_html_x( 'Some scheduled actions need recovery', 'Admin notice', 'uncanny-automator-pro' ) )
			->with_paragraph( esc_html_x( 'Uncanny Automator Pro found scheduled actions left in a broken state by an earlier cleanup defect. Open the recovery tool to review the status.', 'Admin notice', 'uncanny-automator-pro' ) )
			->with_action( Notice_Action::link( esc_html_x( 'Review & recover', 'Admin notice', 'uncanny-automator-pro' ), $this->recovery_tool_url() )->primary() );
	}

	/**
	 * One-time evaluation: if the flag has never been written, run the cheap existence check
	 * ONCE and persist the result. Cheap on every admin_init thereafter (a single option read).
	 *
	 * @return void
	 */
	public function maybe_evaluate() {

		// Only ever run the (DB-touching) check for a user who could act on it.
		if ( ! current_user_can( automator_pro_get_admin_capability() ) ) {
			return;
		}

		// A sentinel default distinguishes "never evaluated" from a stored '0'/'1'.
		$flag = automator_get_option( self::FLAG_OPTION, null );
		if ( null !== $flag ) {
			return; // Already evaluated once.
		}

		$found = ( new Async_Orphan_Recovery() )->has_recoverable_orphans();
		automator_update_option( self::FLAG_OPTION, $found ? '1' : '0' );
	}

	/**
	 * Whether the nudge should render: the flag says an orphan was found, and a THROTTLED
	 * re-check still finds orphans. The re-check is cached in a transient so
	 * has_recoverable_orphans() runs at most once per RECHECK_TTL. When the re-check comes back
	 * empty (recovery is done) the flag is flipped to '0' permanently, so the nudge never costs
	 * anything again.
	 *
	 * @return bool
	 */
	public function should_show(): bool {

		if ( '1' !== (string) automator_get_option( self::FLAG_OPTION, '0' ) ) {
			return false;
		}

		return $this->recheck_has_orphans();
	}

	/**
	 * Throttled re-check. Returns the cached transient when present; otherwise runs
	 * has_recoverable_orphans() once, caches it, and — when it comes back false — clears the
	 * flag so the nudge is gone for good.
	 *
	 * @return bool
	 */
	private function recheck_has_orphans(): bool {

		$cached = get_transient( self::RECHECK_TRANSIENT );
		if ( false !== $cached ) {
			return '1' === (string) $cached;
		}

		$found = ( new Async_Orphan_Recovery() )->has_recoverable_orphans();
		set_transient( self::RECHECK_TRANSIENT, $found ? '1' : '0', self::RECHECK_TTL );

		if ( ! $found ) {
			// Recovery is done — turn the nudge off permanently.
			automator_update_option( self::FLAG_OPTION, '0' );
		}

		return $found;
	}

	/**
	 * The deep-link to Status > Tools > "Scheduled actions recovery".
	 *
	 * The Tools page selects its sub-tab from the `tools` query param (see
	 * Admin_Tools_Tab_Tools::tab_output()); the recovery sub-tab is registered under the
	 * key `recovery` (preload=true) on automator_admin_tools_tools_tabs. So the deep-link is
	 * the Admin Tools page (edit.php?post_type=uo-recipe&page=uncanny-automator-admin-tools)
	 * with tab=tools&tools=recovery.
	 *
	 * @return string
	 */
	private function recovery_tool_url(): string {
		return add_query_arg(
			array(
				'post_type' => 'uo-recipe',
				'page'      => 'uncanny-automator-admin-tools',
				'tab'       => 'tools',
				'tools'     => 'recovery',
			),
			admin_url( 'edit.php' )
		);
	}
}
