<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Presentation\Admin;

use Uncanny_Automator\App\Presentation\Admin\Notices\Notice_Center;
use Uncanny_Automator_Pro\Licensing;
use Uncanny_Automator_Pro\Utilities;

/**
 * Adds Pro's admin notices to Free's notice center, the way Free adds its
 * own: license activation, license expired, the scheduled-actions recovery
 * nudge and the Scheduled recipes outcome. Invoked (guarded) from
 * `src/boot.php`, after Pro's core classes are built. Registration only.
 *
 * @since 8.0.0
 */
final class Bootstrap {

	/**
	 * @param Notice_Center|null $center The center; Free's when not given.
	 *
	 * @return void
	 */
	public static function register_all( ?Notice_Center $center = null ): void {

		if ( ! is_admin() ) {
			return;
		}

		$center = $center ?? automator_notice_center();

		$center->add( new License_Activation_Notice() );

		$licensing = Utilities::get_class_instance( Licensing::class );
		if ( $licensing instanceof Licensing ) {
			$center->add( new License_Expired_Notice( $licensing ) );
		}

		$recovery = new Orphan_Recovery_Notice();
		add_action( 'admin_init', array( $recovery, 'maybe_evaluate' ) );
		$center->add( $recovery );

		$center->add( new Schedule_Outcome_Notice() );
	}
}
