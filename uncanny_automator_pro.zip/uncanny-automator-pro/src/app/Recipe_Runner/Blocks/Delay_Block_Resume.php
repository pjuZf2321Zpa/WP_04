<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Recipe_Runner\Recipe_Runner;
use Uncanny_Automator_Pro\Loops\Entry_Point;
use Uncanny_Automator_Pro\Loops\Loop\Background_Process\Entity_Actions;
use Uncanny_Automator_Pro\Loops\Loop\Execute;

/**
 * Answers the delay block's Action Scheduler job: reads the payload, registers the loop entity's
 * token parsers when the block sits in a loop body, resumes the block's path, drops the payload.
 */
final class Delay_Block_Resume {

	/**
	 * The runner whose resume_block() runs the path.
	 *
	 * @var Recipe_Runner
	 */
	private Recipe_Runner $runner;

	/**
	 * Bind to a runner.
	 *
	 * @param Recipe_Runner $runner The recipe runner.
	 */
	public function __construct( Recipe_Runner $runner ) {
		$this->runner = $runner;
	}

	/**
	 * Listener body for Delay_Block_Processor::RESUME_HOOK.
	 *
	 * @param string $hash Option name holding the payload.
	 *
	 * @return int|null The status the waiting steps were settled to when the resume was refused, null when the path ran or the payload is gone.
	 */
	public function handle( $hash ): ?int {
		$payload = automator_get_option( (string) $hash, false );

		if ( ! is_array( $payload ) || empty( $payload['recipe_log_id'] ) || empty( $payload['block_id'] ) ) {
			automator_log( 'Delay block resume skipped: payload missing for ' . (string) $hash, 'Delay_Block_Resume' );
			return null;
		}

		$args      = is_array( $payload['args'] ?? null ) ? $payload['args'] : array();
		$completed = array();

		if ( isset( $args['loop'] ) && is_array( $args['loop'] ) ) {
			$loop      = $args['loop'];
			$loop_item = (array) ( $loop['loop_item'] ?? array() );
			$process   = new Entity_Actions( (string) ( $loop_item['filter_id'] ?? '' ) );
			$item      = array(
				'entity_id'         => $loop['entity_id'] ?? 0,
				'process_transient' => Execute::generate_key( (string) ( $loop_item['filter_id'] ?? '' ) ),
			);
			$process->register_entity_parsers( $item, $loop_item, (array) ( $payload['triggers'] ?? array() ), $args );
			$completed = $process->get_completed_action_ids_for_entity( (int) ( $loop['user_id'] ?? 0 ), (int) ( $loop['entity_id'] ?? 0 ), $loop_item );
		}

		$waiting = array_map( 'intval', (array) ( $payload['action_ids'] ?? array() ) );

		// A failed tree read throws through here on purpose: the payload stays and the scheduler records the failure for the retry cron.
		$settled = $this->runner->resume_block(
			(int) $payload['recipe_log_id'],
			(int) $payload['block_id'],
			(string) ( $payload['path_code'] ?? 'DELAY-COMPLETED' ),
			(int) ( $payload['user_id'] ?? 0 ),
			$args,
			$completed,
			$waiting
		);

		// Loop scope has no action rows; the entity's parked items take the refusal status, then the run is re-evaluated.
		if ( null !== $settled && isset( $loop, $loop_item ) ) {
			$entry_point = Entry_Point::get_instance();
			foreach ( $waiting as $action_id ) {
				$entry_point->settle_entry_item( $settled, (int) ( $loop['user_id'] ?? 0 ), (int) ( $loop['entity_id'] ?? 0 ), $action_id, $loop_item );
			}
			// The args travel with the finalize: Pro's loop status intercept bails
			// without recipe_id, recipe_log_id and run_number, and the run's status
			// would then never be recomputed from the loop entries.
			$this->runner->finalize_recipe_by_log_id( (int) $payload['recipe_log_id'], $args );
		}

		automator_delete_option( (string) $hash );

		return $settled;
	}
}
