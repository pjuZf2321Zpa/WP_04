<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Events\Dispatcher;
use Uncanny_Automator\App\Recipe_Runner\Services\Recipe_Data_Provider;

/**
 * Turns a delay block's token-mode expression into a UTC timestamp: replaces the two
 * current-time tokens, parses recipe tokens, then reads a Unix timestamp (with optional
 * +/- arithmetic) or a natural-language date in the site timezone.
 */
final class Delay_Token_Timestamp {

	/**
	 * Recipe token parser.
	 *
	 * @var Recipe_Data_Provider
	 */
	private Recipe_Data_Provider $data_provider;

	/**
	 * Wire the resolver to the token parser.
	 *
	 * @param Recipe_Data_Provider|null $data_provider Token parser; defaults to a fresh provider.
	 */
	public function __construct( ?Recipe_Data_Provider $data_provider = null ) {
		$this->data_provider = $data_provider ?? new Recipe_Data_Provider();
	}

	/**
	 * Resolve an expression to a Unix timestamp.
	 *
	 * @param string $expression The DELAY_TOKEN expression, tokens unparsed.
	 * @param int    $recipe_id  Recipe id for token parsing.
	 * @param int    $user_id    User id for token parsing.
	 * @param array  $args       Run args for token parsing.
	 *
	 * @return int
	 * @throws \InvalidArgumentException When the expression is not a single point in time.
	 */
	public function resolve( string $expression, int $recipe_id, int $user_id, array $args ): int {
		$expression = $this->replace_timestamp_tokens( $expression );
		$expression = $this->data_provider->parse_text( $expression, $recipe_id, $user_id, $args );

		return $this->to_timestamp( trim( $expression ) );
	}

	/**
	 * Replace the two current-time tokens, which the generic parser would resolve in site-local seconds.
	 *
	 * @param string $expression Expression.
	 *
	 * @return string
	 */
	public function replace_timestamp_tokens( string $expression ): string {
		return str_replace(
			array( '{{current_unix_timestamp}}', '{{currentdate_unix_timestamp}}' ),
			array( (string) time(), (string) strtotime( gmdate( 'Y-m-d', time() ) ) ),
			$expression
		);
	}

	/**
	 * Parse a resolved expression: a Unix timestamp, timestamp arithmetic, or a natural-language date.
	 *
	 * @param string $input Resolved expression.
	 *
	 * @return int
	 * @throws \InvalidArgumentException When the input is not a single point in time.
	 */
	public function to_timestamp( string $input ): int {
		if ( ctype_digit( $input ) || preg_match( '/^(\d+)\s*([\+\-])\s*(\d+)$/', $input, $matches ) ) {
			$timestamp = ctype_digit( $input )
				? (int) $input
				: ( '+' === $matches[2] ? (int) $matches[1] + (int) $matches[3] : (int) $matches[1] - (int) $matches[3] );

			if ( $timestamp < -2147483648 || $timestamp > 2147483647 ) {
				throw new \InvalidArgumentException(
					sprintf(
						// translators: %s is the user-provided input value.
						esc_html_x( 'Provided input: %s is not a valid timestamp.', 'Async action error', 'uncanny-automator-pro' ),
						esc_html( $input )
					)
				);
			}

			return $timestamp;
		}

		$input = $this->simplify( $input );

		if ( false !== stripos( $input, 'every' ) ) {
			throw new \InvalidArgumentException(
				sprintf(
					// translators: %s is the user-provided recurring event string.
					esc_html_x( "Recurring events like '%s' cannot be parsed into a single timestamp.", 'Async action error', 'uncanny-automator-pro' ),
					esc_html( $input )
				)
			);
		}

		try {
			return ( new \DateTime( $input, wp_timezone() ) )->getTimestamp();
		} catch ( \Exception $e ) {
			throw new \InvalidArgumentException(
				sprintf(
					// translators: %s is the user-provided input that could not be parsed.
					esc_html_x( "Cannot parse the input '%s'.", 'Async action error', 'uncanny-automator-pro' ),
					esc_html( $input )
				)
			);
		}
	}

	/**
	 * Normalise synonyms and word order so DateTime accepts the phrase.
	 *
	 * @param string $input Natural-language expression.
	 *
	 * @return string
	 */
	public function simplify( string $input ): string {
		$mappings = Dispatcher::filter(
			'automator_pro_custom_delay_synonyms_mapping',
			array(
				'midday'             => '12:00 PM',
				'midnight'           => '12:00 AM',
				'coming'             => 'next',
				'upcoming'           => 'next',
				'following'          => 'next',
				'tonight'            => 'today 8:00 PM',
				'tomorrow night'     => 'tomorrow 8:00 PM',
				'end of the day'     => 'today 11:59 PM',
				'eod'                => 'today 11:59 PM',
				'start of the day'   => 'today 12:00 AM',
				'sod'                => 'today 12:00 AM',
				'noon'               => '12:00 PM',
				'afternoon'          => '2:00 PM',
				'evening'            => '6:00 PM',
				'morning'            => '8:00 AM',
				'early morning'      => '5:00 AM',
				'late morning'       => '11:00 AM',
				'mid-morning'        => '10:00 AM',
				'pre-noon'           => '11:00 AM',
				'late night'         => '10:00 PM',
				'early evening'      => '5:00 PM',
				'pre-midnight'       => '11:00 PM',
				'next week'          => 'next week',
				'next month'         => 'next month',
				'next year'          => 'next year',
				'yesterday'          => 'yesterday',
				'day after tomorrow' => 'tomorrow +1 day',
				'last night'         => 'yesterday 8:00 PM',
				'this morning'       => 'today 8:00 AM',
				'this afternoon'     => 'today 2:00 PM',
				'this evening'       => 'today 6:00 PM',
				'weekend'            => 'next Saturday',
				'end of this week'   => 'this Sunday',
				'start of this week' => 'this Monday',
				'end of the month'   => 'last day of this month 11:59 PM',
				'start of the month' => 'first day of this month 12:00 AM',
				'mid of the month'   => '15th day of this month 12:00 PM',
			)
		);

		foreach ( (array) $mappings as $key => $value ) {
			if ( false !== stripos( $input, $key ) ) {
				$input = str_ireplace( $key, $value, $input );
			}
		}

		// DateTime wants the clock time last.
		if ( preg_match( '/(\b\d{1,2}(:\d{2})?\s*(am|pm)\b)/i', $input, $matches ) ) {
			$date_part = trim( preg_replace( '/\b\d{1,2}(:\d{2})?\s*(am|pm)\b/i', '', $input ) );
			$input     = $date_part . ( '' === $date_part ? '' : ' ' ) . $matches[0];
		}

		$input = str_replace( array( ' at ', ' this ' ), ' ', $input );

		return trim( preg_replace( '!\s+!', ' ', $input ) );
	}
}
