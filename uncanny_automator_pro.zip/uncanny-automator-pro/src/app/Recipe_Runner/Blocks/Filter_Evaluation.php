<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Recipe_Builder\Block\Enums\Block_Path_Code;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Action_Error;

/**
 * What evaluating one filter block's conditions decided: whether they are met, the path a walk takes,
 * what each condition it asked answered, the messages the failed conditions logged, and the error to
 * record for a failed condition, an unanswered condition, or an evaluation that threw.
 *
 * @since 8.0.0
 */
final class Filter_Evaluation {

	/**
	 * Whether the block's conditions are met.
	 *
	 * @var bool
	 */
	private bool $met;

	/**
	 * Messages the failed conditions logged, in evaluation order.
	 *
	 * @var string[]
	 */
	private array $failure_messages;

	/**
	 * The error to record on the run: evaluation threw, a failed condition supplied a message, or a condition
	 * nothing answered (which counts as not met, so a met block can carry it too).
	 *
	 * @var Action_Error|null
	 */
	private ?Action_Error $error;

	/**
	 * What each condition the filter asked answered, by modifier id: true when it passed. A condition nothing
	 * answered is false; one the filter decided without is absent.
	 *
	 * @since 8.0.2
	 *
	 * @var array<int|string, bool>
	 */
	private array $condition_results;

	/**
	 * Use met() or not_met().
	 *
	 * @param bool                    $met               Whether the conditions are met.
	 * @param string[]                $failure_messages  Messages the failed conditions logged.
	 * @param Action_Error|null       $error             The error to record on the run.
	 * @param array<int|string, bool> $condition_results What each condition asked answered, by modifier id.
	 *
	 * @since 8.0.2 Accepts $condition_results.
	 */
	private function __construct( bool $met, array $failure_messages, ?Action_Error $error, array $condition_results ) {
		$this->met               = $met;
		$this->failure_messages  = $failure_messages;
		$this->error             = $error;
		$this->condition_results = $condition_results;
	}

	/**
	 * The conditions are met.
	 *
	 * @param Action_Error|null       $error             What the run log records beside the result: the condition nothing answered.
	 * @param array<int|string, bool> $condition_results What each condition asked answered, by modifier id.
	 *
	 * @since 8.0.2 Accepts $condition_results.
	 *
	 * @return self
	 */
	public static function met( ?Action_Error $error = null, array $condition_results = array() ): self {
		return new self( true, array(), $error, $condition_results );
	}

	/**
	 * The conditions are not met.
	 *
	 * @param string[]                $failure_messages  Messages the failed conditions logged.
	 * @param Action_Error|null       $error             The reason to record with the filter block, if any.
	 * @param array<int|string, bool> $condition_results What each condition asked answered, by modifier id.
	 *
	 * @since 8.0.2 Accepts $condition_results.
	 *
	 * @return self
	 */
	public static function not_met( array $failure_messages = array(), ?Action_Error $error = null, array $condition_results = array() ): self {
		return new self( false, array_values( array_map( 'strval', $failure_messages ) ), $error, $condition_results );
	}

	/**
	 * What each condition the filter asked answered, by modifier id: true when it passed. A condition nothing
	 * answered is false; one the filter decided without (it stopped at a decisive answer, or evaluation threw) is
	 * absent. The children runner keeps this with the chosen path for the run log.
	 *
	 * @since 8.0.2
	 *
	 * @return array<int|string, bool>
	 */
	public function condition_results(): array {
		return $this->condition_results;
	}

	/**
	 * Whether the conditions are met.
	 *
	 * @return bool
	 */
	public function is_met(): bool {
		return $this->met;
	}

	/**
	 * The path a walk takes through the block.
	 *
	 * @return string Block_Path_Code::FILTER_CONDITIONS_MET or FILTER_CONDITIONS_NOT_MET.
	 */
	public function taken_path(): string {
		return $this->met ? Block_Path_Code::FILTER_CONDITIONS_MET : Block_Path_Code::FILTER_CONDITIONS_NOT_MET;
	}

	/**
	 * Messages the failed conditions logged, in evaluation order.
	 *
	 * @return string[]
	 */
	public function failure_messages(): array {
		return $this->failure_messages;
	}

	/**
	 * The error to record on the run, if any.
	 *
	 * @return Action_Error|null
	 */
	public function error(): ?Action_Error {
		return $this->error;
	}
}
