<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Recipe_Builder\Loop\Value_Objects\Loop_Field_Translator;
use Uncanny_Automator\App\Recipe_Builder\Recipe\Schema\Recipe_Schema_Reader;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Children_Runner;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Outcome;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Processor;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Refusal_Aware;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Walk_Completion_Aware;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Execution_Context;
use Uncanny_Automator_Pro\Loops\Loop\Execute;
use Uncanny_Automator_Pro\Loops\Loop_MQ;
use Uncanny_Automator_Pro\Loops_Process_Registry;

/**
 * Runs a loop block: queues the loop's entities as a background process and defers to them;
 * after the whole walk, dispatches the first queued loop so every loop is queued before any starts.
 * A loop that could not be queued finalizes itself in run_loop() and completes here.
 * A refused loop records its entry through the same failure path.
 * Each entity's path then runs through Block_Children_Runner in Entity_Actions::task().
 */
final class Loop_Block_Processor implements Block_Processor, Walk_Completion_Aware, Block_Refusal_Aware {

	/**
	 * Queue the loop; completion belongs to the loop's own callbacks.
	 *
	 * @param array<string, mixed>  $block_node Loop block node.
	 * @param Execution_Context     $context    The run.
	 * @param Block_Children_Runner $children   Unused here; entities run through their own runner.
	 *
	 * @return Block_Outcome Deferred when the loop was queued; completed when it could not start.
	 */
	public function process( array $block_node, Execution_Context $context, Block_Children_Runner $children ): Block_Outcome {
		$tree = (array) Recipe_Schema_Reader::instance()->get_or_build( $context->get_recipe_id() );
		$exe  = $this->execute_for( $block_node, $context, $tree );
		// Every loop is queued during the walk; after_walk() dispatches the first.
		$exe->set_defer_dispatch( true );

		$block_node['iterable_expression'] = Loop_Field_Translator::from_fields( (array) ( $block_node['fields'] ?? array() ) );

		// Deferred only when entities were queued; a loop that could not start finalized itself in run_loop().
		return $exe->run_loop( $block_node, (array) ( $tree['triggers'] ?? array() ) ) ? Block_Outcome::deferred() : Block_Outcome::completed();
	}

	/**
	 * Record the walker's refusal on the loop's entry, as a loop that could not start.
	 *
	 * @param array<string, mixed> $block_node Loop block node.
	 * @param Execution_Context    $context    The run.
	 * @param string               $reason     Plain-text reason.
	 *
	 * @return void
	 */
	public function refused( array $block_node, Execution_Context $context, string $reason ): void {
		$this->execute_for( $block_node, $context, (array) Recipe_Schema_Reader::instance()->get_or_build( $context->get_recipe_id() ) )->refuse( $reason );
	}

	/**
	 * The loop executor for this block and run.
	 *
	 * @param array<string, mixed> $block_node Loop block node.
	 * @param Execution_Context    $context    The run.
	 * @param array<string, mixed> $tree       The recipe tree.
	 *
	 * @return Execute
	 */
	private function execute_for( array $block_node, Execution_Context $context, array $tree ): Execute {
		$exe = new Execute();
		$exe->set_flow( (array) ( $tree['content'] ?? array() ) );
		$exe->set_recipe_id( $context->get_recipe_id() );
		$exe->set_recipe_log_id( $context->get_recipe_log_id() );
		$exe->set_process_args( $context->get_args() );
		$exe->set_loop_id( (int) ( $block_node['id'] ?? 0 ) );
		$exe->set_user_id( $context->get_user_id() );

		return $exe;
	}

	/**
	 * Dispatch the first queued loop process; the queue chains the rest.
	 *
	 * @param Execution_Context $context The run.
	 *
	 * @return void
	 */
	public function after_walk( Execution_Context $context ): void {
		$next_loop = ( new Loop_MQ() )->get_next_item();
		if ( false === $next_loop ) {
			return;
		}

		$registry     = Loops_Process_Registry::get_instance();
		$loop_process = $registry->get_object( $next_loop['process_id'] );
		if ( false === $loop_process ) {
			$registry->spawn_process( $next_loop['process_id'] );
			$loop_process = $registry->get_object( $next_loop['process_id'] );
		}

		if ( false !== $loop_process ) {
			$loop_process->dispatch();
		}
	}
}
