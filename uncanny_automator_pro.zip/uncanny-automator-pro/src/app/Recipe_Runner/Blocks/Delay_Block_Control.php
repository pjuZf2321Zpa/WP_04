<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Infrastructure\Database\Database;
use Uncanny_Automator\App\Infrastructure\Database\Interfaces\Execution_Log_Store;
use Uncanny_Automator\App\Recipe_Builder\Recipe\Schema\Recipe_Schema_Reader;
use Uncanny_Automator\App\Recipe_Logs\Wire_Serializer\Run_Data_Bundle;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Control;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Tree_Walk;
use Uncanny_Automator\Automator_Status;
use Uncanny_Automator_Pro\Async_Actions;
use Uncanny_Automator\Services\Action_Scheduler;

/**
 * A delay block the run is still waiting on can be run now or cancelled. One Action Scheduler job resumes
 * every row under the block, so either action settles them all and finalizes the run.
 *
 * Run now unschedules only the job and resumes the path itself, the way the job would have: the rows are
 * not cancelled and the payload is read before it is dropped. A tick that still fires finds no payload.
 *
 * Loop-scoped delays park entry items rather than action-log rows and ship no control; the log offers
 * nothing on a delay inside a loop body.
 */
final class Delay_Block_Control implements Block_Control {

	/**
	 * The block type this control answers for, and the prefix of every process code it issues.
	 *
	 * @var string
	 */
	private const CODE_PREFIX = 'delay_schedule';

	/**
	 * Rows, run meta and the recipe-log row.
	 *
	 * @var Execution_Log_Store
	 */
	private Execution_Log_Store $log_store;

	/**
	 * The job's listener, which Run now calls in the job's place.
	 *
	 * @var Delay_Block_Resume
	 */
	private Delay_Block_Resume $resume;

	/**
	 * Wire the control.
	 *
	 * @param Delay_Block_Resume       $resume    The listener the block's job calls.
	 * @param Execution_Log_Store|null $log_store Log store; defaults to the shared one.
	 */
	public function __construct( Delay_Block_Resume $resume, ?Execution_Log_Store $log_store = null ) {
		$this->resume    = $resume;
		$this->log_store = $log_store ?? Database::get_execution_log_store();
	}

	/**
	 * Run now and cancel, when at least one row under the block is still waiting on its job.
	 *
	 * @param array<string, mixed> $block  The block's tree node.
	 * @param Run_Data_Bundle      $bundle The run.
	 *
	 * @return array{process_code: string, actions: list<'run_now'|'cancel'>}|null
	 */
	public function control_for( array $block, Run_Data_Bundle $bundle ): ?array {
		$waiting = false;
		foreach ( Tree_Walk::action_ids( array( $block ) ) as $action_id ) {
			$row = $bundle->action_row( $action_id );
			if ( ! is_array( $row ) || Automator_Status::IN_PROGRESS !== (int) ( $row['completed'] ?? 0 ) ) {
				continue;
			}
			if ( '' !== (string) $bundle->action_meta( (int) $row['ID'], Execution_Log_Store::ACTION_META_ASYNC_JOB_ID ) ) {
				$waiting = true;
				break;
			}
		}

		if ( ! $waiting ) {
			return null;
		}

		return array(
			'process_code' => self::CODE_PREFIX . ':' . (int) ( $bundle->recipe_log_row()['ID'] ?? 0 ) . ':' . (int) ( $block['id'] ?? 0 ),
			'actions'      => array( 'run_now', 'cancel' ),
		);
	}

	/**
	 * Run the block's waiting rows now, or cancel the block's job and with it every row the job would have resumed.
	 *
	 * @param string $process_code `delay_schedule:<recipe_log_id>:<block_id>`.
	 * @param string $action       'run_now' | 'cancel'.
	 *
	 * @return array{success: bool, message: string}|\WP_Error
	 */
	public function handle( string $process_code, string $action ) {
		if ( 'run_now' !== $action && 'cancel' !== $action ) {
			return new \WP_Error( 'rest_block_control_unsupported', 'A delay can only be run now or cancelled.', array( 'status' => 400 ) );
		}

		$parts = explode( ':', $process_code );
		if ( 3 !== count( $parts ) ) {
			return $this->not_found();
		}

		$recipe_log_id = (int) $parts[1];
		$block_id      = (int) $parts[2];

		$run = $this->log_store->get_recipe_log_row( $recipe_log_id );
		if ( null === $run ) {
			return $this->not_found();
		}
		$recipe_id = (int) $run->automator_recipe_id;

		try {
			$tree = Recipe_Schema_Reader::instance()->get_or_build( $recipe_id );
		} catch ( \Throwable $e ) {
			return $this->not_found();
		}

		$block = Tree_Walk::find_block( (array) ( $tree['content'] ?? array() ), $block_id );
		if ( null === $block ) {
			return $this->not_found();
		}

		$waiting = $this->waiting_row( $recipe_log_id, Tree_Walk::action_ids( array( $block ) ) );
		if ( null === $waiting ) {
			return $this->not_found();
		}

		if ( 'run_now' === $action ) {
			$job     = Action_Scheduler::fetch_action( $waiting['async_job_id'] );
			$hash    = null === $job ? '' : (string) ( $job->get_args()[0] ?? '' );
			$pending = Action_Scheduler::get_scheduled_actions(
				array(
					'hook'     => Delay_Block_Processor::RESUME_HOOK,
					'args'     => array( $hash ),
					'status'   => Action_Scheduler::STATUS_PENDING,
					'per_page' => 1,
				),
				'ids'
			);

			// A job the scheduler already claimed is resuming this payload; resuming it here too would run the rows twice.
			if ( empty( $pending ) ) {
				return $this->not_found();
			}

			// Without its payload the resume runs nothing, so leave the job alone rather than report a run that did not happen.
			if ( ! is_array( automator_get_option( $hash, false ) ) ) {
				return new \WP_Error( 'rest_block_control_refused', 'The delay has lost the run data it needs, so it cannot run now.', array( 'status' => 409 ) );
			}

			$ran_at = time();

			// Unscheduled before the resume, so the scheduler cannot fire the same payload while the path runs.
			Action_Scheduler::cancel_action( $waiting['async_job_id'] );

			try {
				$settled = $this->resume->handle( $hash );
			} catch ( \Throwable $e ) {
				// The payload stays, so a failed job is the retry cron's to run again, as when the scheduler's own run throws.
				Action_Scheduler::mark_failure( $waiting['async_job_id'] );
				return new \WP_Error( 'rest_block_control_failed', esc_html( 'The delay could not run now and will be retried: ' . $e->getMessage() ), array( 'status' => 500 ) );
			}

			if ( Automator_Status::CANCELLED === $settled ) {
				return new \WP_Error( 'rest_block_control_refused', 'The recipe is not published, so the waiting steps were cancelled.', array( 'status' => 409 ) );
			}
			if ( null !== $settled ) {
				return new \WP_Error( 'rest_block_control_refused', 'The delay is no longer in the recipe, so the waiting steps did not run.', array( 'status' => 409 ) );
			}

			$this->record_run_now( $recipe_id, $recipe_log_id, Tree_Walk::action_ids( array( $block ) ), $ran_at );

			return array(
				'success' => true,
				'message' => 'Delay ran now',
			);
		}

		// Since the block processor schedules one job for the whole path, cancelling it settles every row sharing it and finalizes the run.
		Async_Actions::cancel_job( $waiting['action_log_id'], $waiting['action_id'], $recipe_log_id );

		return array(
			'success' => true,
			'message' => 'Delay cancelled',
		);
	}

	/**
	 * The first row of the run under these actions that is still waiting on a job.
	 *
	 * @param int   $recipe_log_id The run.
	 * @param int[] $action_ids    Actions under the block.
	 *
	 * @return array{action_log_id: int, action_id: int, async_job_id: int}|null
	 */
	private function waiting_row( int $recipe_log_id, array $action_ids ): ?array {
		$rows = array();
		foreach ( $this->log_store->get_action_log_rows( $recipe_log_id ) as $row ) {
			if ( in_array( (int) $row['automator_action_id'], $action_ids, true ) && Automator_Status::IN_PROGRESS === (int) $row['completed'] ) {
				$rows[ (int) $row['ID'] ] = (int) $row['automator_action_id'];
			}
		}

		if ( empty( $rows ) ) {
			return null;
		}

		foreach ( $this->log_store->get_action_log_meta_bag( array_keys( $rows ) ) as $action_log_id => $meta ) {
			if ( '' !== (string) ( $meta[ Execution_Log_Store::ACTION_META_ASYNC_JOB_ID ] ?? '' ) ) {
				return array(
					'action_log_id' => (int) $action_log_id,
					'action_id'     => $rows[ (int) $action_log_id ],
					'async_job_id'  => (int) $meta[ Execution_Log_Store::ACTION_META_ASYNC_JOB_ID ],
				);
			}
		}

		return null;
	}

	/**
	 * Record on each step's delay entry when an admin ran it early and who, for the log's dates and message.
	 *
	 * @param int   $recipe_id     The recipe.
	 * @param int   $recipe_log_id The run.
	 * @param int[] $action_ids    Actions under the block.
	 * @param int   $ran_at        When Run now was asked for.
	 *
	 * @return void
	 */
	private function record_run_now( int $recipe_id, int $recipe_log_id, array $action_ids, int $ran_at ): void {
		// The runner read-merge-writes the run's meta under this lock; a lock it refuses is logged and the write proceeds, as there.
		$lock = 'automator_run_meta_' . $recipe_log_id;
		if ( ! $this->log_store->acquire_lock( $lock, 5 ) ) {
			automator_log( sprintf( 'Recipe log %d: run-meta lock not acquired; Run now recorded unlocked.', $recipe_log_id ), 'Delay_Block_Control' );
		}

		try {
			$delays = json_decode( (string) $this->log_store->get_recipe_log_meta( $recipe_log_id, Execution_Log_Store::META_ACTION_DELAYS ), true );
			$delays = is_array( $delays ) ? $delays : array();
			$by     = (string) wp_get_current_user()->user_email;

			foreach ( $action_ids as $action_id ) {
				$entry = json_decode( (string) ( $delays[ (string) $action_id ] ?? '' ), true );
				if ( ! is_array( $entry ) ) {
					continue;
				}
				$entry['ran_now_at']           = $ran_at;
				$entry['ran_now_by']           = $by;
				$delays[ (string) $action_id ] = (string) wp_json_encode( $entry );
			}

			$this->log_store->set_recipe_log_meta( $recipe_id, $recipe_log_id, Execution_Log_Store::META_ACTION_DELAYS, (string) wp_json_encode( $delays ) );
		} finally {
			$this->log_store->release_lock( $lock );
		}
	}

	/**
	 * The 404 every unresolvable process code answers with.
	 *
	 * @return \WP_Error
	 */
	private function not_found(): \WP_Error {
		return new \WP_Error( 'rest_block_control_not_found', 'No delay of this run is waiting.', array( 'status' => 404 ) );
	}
}
