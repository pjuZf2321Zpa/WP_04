<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Recipe_Builder\Block\Enums\Block_Type;
use Uncanny_Automator\App\Recipe_Runner\Recipe_Runner;

/**
 * Wires Pro's block processors and controls into Free's runner and the delay resume listener into Action Scheduler.
 * The one place Pro registers block execution; called once at boot from automator-pro-recipe-process-complete.php.
 */
final class Bootstrap {

	/**
	 * Register the three processors, the two controls, the resume listener and the delete listener.
	 *
	 * @param Recipe_Runner $runner Free's recipe runner.
	 *
	 * @return void
	 */
	public function register( Recipe_Runner $runner ): void {
		$runner->register_block_processor( Block_Type::FILTER, new Filter_Block_Processor() );
		$runner->register_block_processor( Block_Type::DELAY_SCHEDULE, new Delay_Block_Processor() );
		$runner->register_block_processor( Block_Type::LOOP, new Loop_Block_Processor() );

		$resume = new Delay_Block_Resume( $runner );

		$runner->register_block_control( Block_Type::DELAY_SCHEDULE, new Delay_Block_Control( $resume ) );
		$runner->register_block_control( Block_Type::LOOP, new Loop_Block_Control() );

		add_action( Delay_Block_Processor::RESUME_HOOK, array( $resume, 'handle' ), 10, 1 );
		add_action( 'before_delete_post', array( new Delay_Block_Deletion(), 'handle' ), 10, 2 );
	}
}
