<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Recipe_Logs\Wire_Serializer\Run_Data_Bundle;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Control;
use Uncanny_Automator_Pro\Loops\Process_Controller;
use Uncanny_Automator_Pro\Loops_Process_Registry;

/**
 * A loop still running can be paused, resumed or cancelled. Pause is not a loop-entry status — the row
 * stays in-progress while the background process is paused — so the affordances come from the entry
 * (is the loop still live?) and the process object (is it paused right now?).
 *
 * The transitions themselves are Process_Controller::apply(), the same implementation the loops REST
 * route calls.
 */
final class Loop_Block_Control implements Block_Control {

	/**
	 * The block type this control answers for, and the prefix of every process code it issues.
	 *
	 * @var string
	 */
	private const CODE_PREFIX = 'loop';

	/**
	 * The loop-entry status a live loop carries.
	 *
	 * @var string
	 */
	private const LIVE_STATUS = 'in-progress';

	/**
	 * The actions this control performs, and what each reports.
	 *
	 * @var array<string,string>
	 */
	private const MESSAGES = array(
		'pause'  => 'Loop paused',
		'resume' => 'Loop resumed',
		'cancel' => 'Loop cancelled',
	);

	/**
	 * What the user may do to this loop right now.
	 *
	 * @param array<string, mixed> $block  The block's tree node.
	 * @param Run_Data_Bundle      $bundle The run.
	 *
	 * @return array{process_code: string, actions: list<'pause'|'resume'|'cancel'>}|null
	 */
	public function control_for( array $block, Run_Data_Bundle $bundle ): ?array {
		$entry = $bundle->loop_entry( (int) ( $block['id'] ?? 0 ) );
		if ( null === $entry || self::LIVE_STATUS !== (string) ( $entry['status'] ?? '' ) ) {
			return null;
		}

		$process_id = (string) ( $entry['process_id'] ?? '' );
		if ( '' === $process_id ) {
			return null;
		}

		$process = Loops_Process_Registry::get_instance()->get_object( $process_id );
		if ( false === $process ) {
			// The entry is live but this request has no process object; cancelling still resolves it, pausing needs the object.
			return $this->affordances( $process_id, array( 'cancel' ) );
		}

		if ( $process->is_cancelled() ) {
			return null;
		}

		return $this->affordances( $process_id, array( $process->is_paused() ? 'resume' : 'pause', 'cancel' ) );
	}

	/**
	 * Pause, resume or cancel the loop process the code names.
	 *
	 * @param string $process_code `loop:<process_id>`.
	 * @param string $action       'pause' | 'resume' | 'cancel'.
	 *
	 * @return array{success: bool, message: string}|\WP_Error
	 */
	public function handle( string $process_code, string $action ) {
		// Process_Controller::apply() answers an unrecognised action with a no-op, which would report success.
		if ( ! isset( self::MESSAGES[ $action ] ) ) {
			return new \WP_Error( 'rest_block_control_unsupported', 'A loop can be paused, resumed or cancelled.', array( 'status' => 400 ) );
		}

		$process_id = substr( $process_code, strlen( self::CODE_PREFIX ) + 1 );
		$process    = Loops_Process_Registry::get_instance()->get_object( $process_id );

		if ( false === $process ) {
			return new \WP_Error( 'rest_block_control_not_found', 'No loop is running under this process id.', array( 'status' => 404 ) );
		}

		( new Process_Controller() )->apply( $process, $action, $process_id );

		return array(
			'success' => true,
			'message' => self::MESSAGES[ $action ],
		);
	}

	/**
	 * The control payload for a live loop.
	 *
	 * @param string                          $process_id The loop's process id.
	 * @param list<'pause'|'resume'|'cancel'> $actions    The actions offered.
	 *
	 * @return array{process_code: string, actions: list<'pause'|'resume'|'cancel'>}
	 */
	private function affordances( string $process_id, array $actions ): array {
		return array(
			'process_code' => self::CODE_PREFIX . ':' . $process_id,
			'actions'      => $actions,
		);
	}
}
