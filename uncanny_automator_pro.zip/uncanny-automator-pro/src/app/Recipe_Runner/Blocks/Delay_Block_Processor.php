<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Events\Dispatcher;
use Uncanny_Automator\App\Infrastructure\Database\Database;
use Uncanny_Automator\App\Infrastructure\Database\Interfaces\Execution_Log_Store;
use Uncanny_Automator\App\Recipe_Builder\Block\Enums\Block_Path_Code;
use Uncanny_Automator\App\Recipe_Builder\Block\Registry\Blocks\Delay_Block;
use Uncanny_Automator\App\Recipe_Builder\Block\Value_Objects\Fields_Bag;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Children_Runner;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Outcome;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Processor;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Tree_Walk;
use Uncanny_Automator\App\Recipe_Runner\Services\Error_Code;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Action_Error;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Execution_Context;
use Uncanny_Automator_Pro\Loops\Filter\Registry;
use Uncanny_Automator_Pro\Loops\Loop\Execute;
use Uncanny_Automator_Pro\Loops\Entry_Point;
use Uncanny_Automator\Services\Action_Scheduler;

/**
 * Runs a delay block: schedules one Action Scheduler job for the block's path and returns
 * deferred. Outside a loop the rows under the path are marked scheduled; inside a loop, one entry
 * item per action is parked at in-progress for this entity. A schedule or token time that has
 * passed runs the path now, with a note on the block. A delay amount of 0 or less, a time that
 * cannot be worked out, or a job that cannot be saved or scheduled, runs nothing: the block
 * reports that it did not run and why.
 */
final class Delay_Block_Processor implements Block_Processor {

	/**
	 * Action Scheduler hook the resume listener answers.
	 *
	 * @var string
	 */
	public const RESUME_HOOK = 'automator_pro_run_delay_block';

	/**
	 * Option-name prefix for payload hashes; the orphan cleanup selects on it.
	 *
	 * @var string
	 */
	public const HASH_PREFIX = 'automator_async_';

	/**
	 * Row transitions and run meta.
	 *
	 * @var Execution_Log_Store
	 */
	private Execution_Log_Store $log_store;

	/**
	 * Token-mode expression resolver.
	 *
	 * @var Delay_Token_Timestamp
	 */
	private Delay_Token_Timestamp $token_timestamp;

	/**
	 * Whether Action Scheduler is running and can take a job.
	 *
	 * @var \Closure
	 */
	private \Closure $scheduler_available;

	/**
	 * Wire the processor.
	 *
	 * @param Execution_Log_Store|null   $log_store           Log store; defaults to the shared one.
	 * @param Delay_Token_Timestamp|null $token_timestamp     Token resolver; defaults to a fresh one.
	 * @param \Closure|null              $scheduler_available Returns whether Action Scheduler is running; defaults to the service's check.
	 */
	public function __construct( ?Execution_Log_Store $log_store = null, ?Delay_Token_Timestamp $token_timestamp = null, ?\Closure $scheduler_available = null ) {
		$this->log_store           = $log_store ?? Database::get_execution_log_store();
		$this->token_timestamp     = $token_timestamp ?? new Delay_Token_Timestamp();
		$this->scheduler_available = $scheduler_available ?? \Closure::fromCallable( array( Action_Scheduler::class, 'is_available' ) );
	}

	/**
	 * Schedule the block's path, run it now when its time has passed, or run nothing when it cannot be scheduled.
	 *
	 * @param array<string, mixed>  $block_node Delay block node with `delay_seconds`, `schedule_at`, `delay_token`.
	 * @param Execution_Context     $context    The run.
	 * @param Block_Children_Runner $children   Path runner.
	 *
	 * @return Block_Outcome Deferred when scheduled; completed with a note when it ran now; not run, with the reason, when its delay amount is 0 or less or it could not be scheduled.
	 */
	public function process( array $block_node, Execution_Context $context, Block_Children_Runner $children ): Block_Outcome {
		$block_id = (int) ( $block_node['id'] ?? 0 );
		$mode     = Fields_Bag::from_array( (array) ( $block_node['fields'] ?? array() ) )->scalar( Delay_Block::FIELD_MODE );
		$mode     = '' === $mode ? Delay_Block::MODE_DELAY : $mode;

		$path       = Tree_Walk::path( $block_node, Block_Path_Code::DELAY_COMPLETED );
		$action_ids = Tree_Walk::action_ids( null === $path ? array() : $path['items'] );

		try {
			$timestamp = $this->timestamp( $mode, $block_node, $context );
		} catch ( \InvalidArgumentException $e ) {
			return $this->not_run(
				$block_node,
				$context,
				$action_ids,
				sprintf(
					// translators: %s is why the delay's time could not be worked out.
					esc_html_x( "These actions did not run because the delay's time could not be worked out: %s", 'Delay block', 'uncanny-automator-pro' ),
					esc_html( $e->getMessage() )
				)
			);
		}

		if ( $timestamp <= time() ) {
			// An amount of 0 or less is a mistake, such as a token that resolved to nothing: running at once would surprise.
			if ( Delay_Block::MODE_DELAY === $mode && 0 >= (int) ( $block_node['delay_seconds'] ?? 0 ) ) {
				return $this->not_run( $block_node, $context, $action_ids, esc_html_x( 'These actions did not run because the delay amount is not a number above 0.', 'Delay block', 'uncanny-automator-pro' ) );
			}
			return $this->run_now( $block_node, $context, $children, esc_html_x( 'The scheduled time had already passed, so these actions ran right away.', 'Delay block', 'uncanny-automator-pro' ) );
		}

		$args = $context->get_args();

		$payload = array(
			'recipe_log_id' => $context->get_recipe_log_id(),
			'block_id'      => $block_id,
			'path_code'     => Block_Path_Code::DELAY_COMPLETED,
			'user_id'       => $context->get_user_id(),
			'args'          => $args,
			'timestamp'     => $timestamp,
			'action_ids'    => $action_ids,
			'triggers'      => $context->is_loop_scoped() ? $this->loop_triggers( $args['loop'] ) : array(),
			'retries'       => 0,
		);

		$encoded = wp_json_encode( $payload );
		if ( false === $encoded ) {
			return $this->not_run( $block_node, $context, $action_ids, esc_html_x( 'These actions did not run because the delay could not save its data.', 'Delay block', 'uncanny-automator-pro' ) );
		}
		$hash = self::HASH_PREFIX . md5( $encoded );

		// Checked before the payload option is written, so a site without Action Scheduler is left with nothing to clean up.
		if ( ! ( $this->scheduler_available )() ) {
			return $this->not_run( $block_node, $context, $action_ids, esc_html_x( 'These actions could not be scheduled because Action Scheduler is not running on this site.', 'Delay block', 'uncanny-automator-pro' ) );
		}

		// The same block of the same run already waiting on this exact payload keeps its job; the rows follow that job.
		$pending = Action_Scheduler::get_scheduled_actions(
			array(
				'hook'     => self::RESUME_HOOK,
				'args'     => array( $hash ),
				'status'   => Action_Scheduler::STATUS_PENDING,
				'per_page' => 1,
			),
			'ids'
		);
		if ( ! empty( $pending ) ) {
			$job_id = (int) reset( $pending );
		} else {
			if ( ! automator_add_option( $hash, $payload, false, false ) ) {
				automator_update_option( $hash, $payload, false );
			}
			$group = (string) Dispatcher::filter( 'automator_pro_asyc_actions_group', 'Uncanny Automator', array( 'action_data' => array( 'loop' => $args['loop'] ?? null ) ) );
			// The job is scheduled before the rows are marked on purpose: a resume runs every unfinished row whatever its status, so a failure between the two heals when the job fires; rows marked first with no job would wait forever.
			$job_id = (int) Action_Scheduler::schedule_single_action( $timestamp, self::RESUME_HOOK, array( $hash ), $group );
			if ( $job_id <= 0 ) {
				automator_delete_option( $hash );
				return $this->not_run( $block_node, $context, $action_ids, esc_html_x( 'These actions could not be scheduled because Action Scheduler did not accept the job.', 'Delay block', 'uncanny-automator-pro' ) );
			}
		}

		if ( $context->is_loop_scoped() ) {
			$this->park_entry_items( $action_ids, $args['loop'] );
		} else {
			$this->mark_rows_scheduled( $action_ids, $context, $timestamp, $job_id, $mode );
		}

		return Block_Outcome::deferred();
	}

	/**
	 * The UTC timestamp the block waits for, by mode.
	 *
	 * @param string               $mode       DELAY_MODE value.
	 * @param array<string, mixed> $block_node Block node.
	 * @param Execution_Context    $context    The run.
	 *
	 * @return int
	 * @throws \InvalidArgumentException When a token expression is not a single point in time, or a scheduled date could not be read.
	 */
	private function timestamp( string $mode, array $block_node, Execution_Context $context ): int {
		if ( Delay_Block::MODE_SCHEDULE === $mode ) {
			// The tree stores 0 for a date and time it could not parse.
			$schedule_at = (int) ( $block_node['schedule_at'] ?? 0 );
			if ( 0 >= $schedule_at ) {
				throw new \InvalidArgumentException( esc_html__( 'The scheduled date and time could not be read.', 'uncanny-automator-pro' ) );
			}
			return $schedule_at;
		}
		if ( Delay_Block::MODE_TOKEN === $mode ) {
			return $this->token_timestamp->resolve( (string) ( $block_node['delay_token'] ?? '' ), $context->get_recipe_id(), $context->get_user_id(), $context->get_args() );
		}
		return time() + (int) ( $block_node['delay_seconds'] ?? 0 );
	}

	/**
	 * Report that the block ran none of its actions, and why. Free's runner skips the rows under the block; in a loop
	 * body the entity's items are the processor's, so they are skipped here.
	 *
	 * @since 8.0.0
	 *
	 * @param array<string, mixed> $block_node Block node.
	 * @param Execution_Context    $context    The run.
	 * @param int[]                $action_ids Actions under the path.
	 * @param string               $reason     User-facing reason, escaped.
	 *
	 * @return Block_Outcome
	 */
	private function not_run( array $block_node, Execution_Context $context, array $action_ids, string $reason ): Block_Outcome {
		if ( $context->is_loop_scoped() ) {
			$this->skip_entry_items( $action_ids, $context->get_args()['loop'] );
		}

		return Block_Outcome::not_run(
			$reason,
			array(
				'block_id'  => (int) ( $block_node['id'] ?? 0 ),
				'recipe_id' => $context->get_recipe_id(),
			)
		);
	}

	/**
	 * Run the path inline when the delay's time has already passed, with a note on the block.
	 *
	 * @param array<string, mixed>  $block_node Block node.
	 * @param Execution_Context     $context    The run.
	 * @param Block_Children_Runner $children   Path runner.
	 * @param string                $reason     User-facing note for the block, escaped.
	 *
	 * @return Block_Outcome
	 */
	private function run_now( array $block_node, Execution_Context $context, Block_Children_Runner $children, string $reason ): Block_Outcome {
		$children->run( $block_node, Block_Path_Code::DELAY_COMPLETED, $context );

		return Block_Outcome::completed(
			new Action_Error(
				Error_Code::EXECUTION_FAILED,
				$reason,
				array(
					'block_id'  => (int) ( $block_node['id'] ?? 0 ),
					'recipe_id' => $context->get_recipe_id(),
				)
			)
		);
	}

	/**
	 * Mark every run-start row under the path scheduled, with its delay descriptor and job id.
	 *
	 * @param int[]             $action_ids Actions under the path.
	 * @param Execution_Context $context    The run.
	 * @param int               $timestamp  When the job fires.
	 * @param int               $job_id     Action Scheduler job id.
	 * @param string            $mode       DELAY_MODE value, recorded as the descriptor type.
	 *
	 * @return void
	 */
	private function mark_rows_scheduled( array $action_ids, Execution_Context $context, int $timestamp, int $job_id, string $mode ): void {
		$recipe_log_id = $context->get_recipe_log_id();
		$date_time     = wp_date( 'Y-m-d H:i:s', $timestamp );
		$delays        = json_decode( (string) $this->log_store->get_recipe_log_meta( $recipe_log_id, Execution_Log_Store::META_ACTION_DELAYS ), true );
		$delays        = is_array( $delays ) ? $delays : array();

		foreach ( $action_ids as $action_id ) {
			$action_log_id = $context->action_log_id_for( $action_id );
			if ( null === $action_log_id ) {
				continue;
			}
			$this->log_store->mark_action_scheduled( $action_id, $recipe_log_id, $date_time );
			$this->log_store->add_action_meta( $context->get_user_id(), $action_log_id, $action_id, Execution_Log_Store::ACTION_META_ASYNC_JOB_ID, (string) $job_id );
			$delays[ (string) $action_id ] = (string) wp_json_encode(
				array(
					'type' => $mode,
					'time' => $timestamp,
				)
			);
		}

		$this->log_store->set_recipe_log_meta( $context->get_recipe_id(), $recipe_log_id, Execution_Log_Store::META_ACTION_DELAYS, (string) wp_json_encode( $delays ) );
	}

	/**
	 * Park one in-progress loop entry item per action for this entity.
	 *
	 * @param int[] $action_ids Actions under the path.
	 * @param array $loop       `args['loop']`: user_id, entity_id, loop_item.
	 *
	 * @return void
	 */
	private function park_entry_items( array $action_ids, array $loop ): void {
		foreach ( $action_ids as $action_id ) {
			Entry_Point::get_instance()->park_entry_item( (int) $loop['user_id'], (int) $loop['entity_id'], $action_id, (array) $loop['loop_item'] );
		}
	}

	/**
	 * Skip this entity's loop entry item for every action under the path.
	 *
	 * @since 8.0.0
	 *
	 * @param int[] $action_ids Actions under the path.
	 * @param array $loop       `args['loop']`: user_id, entity_id, loop_item.
	 *
	 * @return void
	 */
	private function skip_entry_items( array $action_ids, array $loop ): void {
		foreach ( $action_ids as $action_id ) {
			Entry_Point::get_instance()->skip_entry_item( (int) $loop['user_id'], (int) $loop['entity_id'], $action_id, (array) $loop['loop_item'] );
		}
	}

	/**
	 * The loop's trigger nodes from its process transient, for re-registering trigger token hooks at resume.
	 *
	 * @param array $loop `args['loop']`.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function loop_triggers( array $loop ): array {
		$transient = Registry::get_process_transient( Execute::generate_key( (string) ( $loop['loop_item']['filter_id'] ?? '' ) ) );

		return is_array( $transient ) && is_array( $transient['triggers'] ?? null ) ? $transient['triggers'] : array();
	}
}
