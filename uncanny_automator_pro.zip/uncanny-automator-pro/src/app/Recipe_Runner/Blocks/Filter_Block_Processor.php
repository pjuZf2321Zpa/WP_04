<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Events\Dispatcher;
use Uncanny_Automator\App\Recipe_Builder\Block\Registry\Blocks\Filter_Block;
use Uncanny_Automator\App\Recipe_Builder\Block\Value_Objects\Fields_Bag;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Children_Runner;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Outcome;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Block_Processor;
use Uncanny_Automator\App\Recipe_Runner\Blocks\Tree_Walk;
use Uncanny_Automator\App\Recipe_Runner\Services\Error_Code;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Action_Error;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Execution_Context;
use Uncanny_Automator_Pro\Loops\Entry_Point;

/**
 * Runs a filter block: evaluates its condition modifiers through the seam every
 * Action_Condition subclass listens on, then runs the met or not-met path. A block with no
 * modifiers is met. An evaluation failure is not-met, with the failure stored on the run.
 * A condition no class answers (its plugin is inactive, or nothing registers it any more)
 * counts as not met, as it did in 7.x, and the run's error log names it. When the filter is
 * not met, the messages the failed conditions gave `condition_failed()` are recorded with it,
 * as 7.x recorded them on the actions it skipped.
 */
final class Filter_Block_Processor implements Block_Processor {

	/**
	 * The seam legacy condition classes register on.
	 *
	 * @var string
	 */
	private const EVALUATE_HOOK = 'automator_pro_evaluate_actions_conditions';

	/**
	 * Evaluate the block and run exactly one of its two paths.
	 *
	 * @param array<string, mixed>  $block_node Filter block node.
	 * @param Execution_Context     $context    The run.
	 * @param Block_Children_Runner $children   Path runner.
	 *
	 * @since 8.0.0 Carries the failed conditions' own messages when the filter is not met.
	 * @since 8.0.2 Hands the children runner what each condition it asked answered, for the run log.
	 *
	 * @return Block_Outcome Always completed; carries an error for an evaluation failure, unanswered condition, or failed condition with a message.
	 */
	public function process( array $block_node, Execution_Context $context, Block_Children_Runner $children ): Block_Outcome {
		$evaluation = $this->evaluate( $block_node, $context );
		$taken      = $evaluation->taken_path();

		// Loop scope has no action rows to flip; the untaken path's actions are recorded as skipped entry items instead.
		if ( $context->is_loop_scoped() ) {
			$loop = $context->get_args()['loop'];
			foreach ( (array) ( $block_node['paths'] ?? array() ) as $path ) {
				if ( (string) ( $path['path_code'] ?? '' ) === $taken ) {
					continue;
				}
				foreach ( Tree_Walk::action_ids( (array) ( $path['items'] ?? array() ) ) as $action_id ) {
					Entry_Point::get_instance()->skip_entry_item( (int) $loop['user_id'], (int) $loop['entity_id'], $action_id, (array) $loop['loop_item'] );
				}
			}
		}

		// A Free whose children runner takes three arguments ignores the fourth.
		$children->run( $block_node, $taken, $context, $evaluation->condition_results() );

		return Block_Outcome::completed( $evaluation->error() );
	}

	/**
	 * Evaluate the block's conditions without running a path. A block with no modifiers is met; an
	 * evaluation that throws is not met and carries the error.
	 *
	 * A 7.x delayed job that deferred its conditions to its run time evaluates the filter now holding
	 * its action through here (Async_Actions::run_execution()).
	 *
	 * @since 8.0.0
	 *
	 * @param array<string, mixed> $block_node Filter block node.
	 * @param Execution_Context    $context    The run.
	 *
	 * @return Filter_Evaluation
	 */
	public function evaluate( array $block_node, Execution_Context $context ): Filter_Evaluation {
		$modifiers = (array) ( $block_node['modifiers'] ?? array() );

		if ( empty( $modifiers ) ) {
			return Filter_Evaluation::met();
		}

		// Filled as each condition answers, so a throw keeps the answers given before it.
		$condition_results = array();

		try {
			return $this->conditions_met( $modifiers, $block_node, $context, $condition_results );
		} catch ( \Throwable $e ) {
			return Filter_Evaluation::not_met(
				array(),
				new Action_Error(
					Error_Code::EXECUTION_FAILED,
					sprintf(
						// translators: %s is the error a condition stopped with.
						esc_html_x( 'The conditions could not be checked, so this block took its Conditions not met path: %s', 'Filter block', 'uncanny-automator-pro' ),
						esc_html( $e->getMessage() )
					),
					array(
						'block_id'  => (int) ( $block_node['id'] ?? 0 ),
						'recipe_id' => $context->get_recipe_id(),
						'exception' => get_class( $e ),
					)
				),
				$condition_results
			);
		}
	}

	/**
	 * Evaluate the modifiers under the block's match mode, short-circuiting on the first decisive result.
	 *
	 * A condition class claims a condition by setting `process_further` (the abstract's hydrate()
	 * sets it before evaluating), so the seam is called without it; a result still without it was
	 * answered by nothing and counts as not met.
	 *
	 * @since 8.0.0 Collects every condition that did not pass, with the messages its class gave.
	 * @since 8.0.2 Records what each condition it asks answered, by modifier id, in $condition_results.
	 *
	 * @param array<int, array<string, mixed>> $modifiers         Modifier nodes.
	 * @param array<string, mixed>             $block_node        Filter block node.
	 * @param Execution_Context                $context           The run.
	 * @param array<int|string, bool>          $condition_results Filled with each asked condition's answer as it comes, so the caller keeps them if a later one throws.
	 *
	 * @return Filter_Evaluation Not met carries the failed conditions' messages; either result can carry an error for the run log, and both carry $condition_results.
	 */
	private function conditions_met( array $modifiers, array $block_node, Execution_Context $context, array &$condition_results ): Filter_Evaluation {
		$mode = Fields_Bag::from_array( (array) ( $block_node['fields'] ?? array() ) )->scalar( Filter_Block::FIELD_MATCH_MODE );
		$mode = '' === $mode ? Filter_Block::MATCH_MODE_ANY : $mode;

		// Condition classes key their log writes on args.recipe_log_id and read loop scope from args.loop.
		$args                  = $context->get_args();
		$args['recipe_id']     = $context->get_recipe_id();
		$args['recipe_log_id'] = $context->get_recipe_log_id();

		$envelope = array(
			'recipe_id'   => $context->get_recipe_id(),
			'user_id'     => $context->get_user_id(),
			'args'        => $args,
			'action_data' => array(
				'ID'            => (int) ( $block_node['id'] ?? 0 ),
				'recipe_log_id' => $context->get_recipe_log_id(),
			),
		);

		$failure_messages = array();
		$failed           = array();

		foreach ( $modifiers as $modifier ) {
			$condition = array(
				'integration' => (string) ( $modifier['integration_code'] ?? '' ),
				'condition'   => (string) ( $modifier['code'] ?? '' ),
				'fields'      => Fields_Bag::to_legacy_flat( (array) ( $modifier['fields'] ?? array() ) ),
			);

			$result = (array) Dispatcher::filter( self::EVALUATE_HOOK, $envelope, $condition );
			$passed = isset( $result['process_further'] ) && false !== $result['process_further'];

			$condition_results[ (string) ( $modifier['id'] ?? '' ) ] = $passed;

			if ( ! $passed ) {
				$messages         = $this->failure_messages( $result );
				$failed[]         = array(
					'condition'   => $condition['condition'],
					'integration' => $condition['integration'],
					'answered'    => isset( $result['process_further'] ),
					'messages'    => $messages,
				);
				$failure_messages = array_merge( $failure_messages, $messages );
			}

			if ( Filter_Block::MATCH_MODE_ANY === $mode && $passed ) {
				return Filter_Evaluation::met( $this->conditions_error( $this->unanswered( $failed ), $block_node, $context ), $condition_results );
			}
			if ( Filter_Block::MATCH_MODE_ALL === $mode && ! $passed ) {
				return Filter_Evaluation::not_met( $failure_messages, $this->conditions_error( $failed, $block_node, $context ), $condition_results );
			}
		}

		if ( Filter_Block::MATCH_MODE_ALL === $mode ) {
			return Filter_Evaluation::met( $this->conditions_error( $this->unanswered( $failed ), $block_node, $context ), $condition_results );
		}

		return Filter_Evaluation::not_met( $failure_messages, $this->conditions_error( $failed, $block_node, $context ), $condition_results );
	}

	/**
	 * The messages a condition class gave `condition_failed()` for one condition, in order, as
	 * 7.x recorded them for the actions it skipped. Empty for a condition nothing answered, and
	 * for an evaluator that fails a condition without a message.
	 *
	 * @since 8.0.0
	 *
	 * @param array<string, mixed> $result The envelope the evaluation seam returned.
	 *
	 * @return string[]
	 */
	private function failure_messages( array $result ): array {
		$messages = array();

		foreach ( (array) ( $result['action_data']['actions_conditions_log'] ?? array() ) as $message ) {
			$message = is_scalar( $message ) ? trim( (string) $message ) : '';
			if ( '' !== $message ) {
				$messages[] = $message;
			}
		}

		return $messages;
	}

	/**
	 * The conditions nothing answered, out of those that did not pass. A met filter records only
	 * these: a condition that answered and failed did not keep the filter from being met.
	 *
	 * @since 8.0.0
	 *
	 * @param array<int, array<string, mixed>> $failed `{ condition, integration, answered, messages }` per condition that did not pass.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function unanswered( array $failed ): array {
		return array_values(
			array_filter(
				$failed,
				static function ( array $condition ): bool {
					return ! $condition['answered'];
				}
			)
		);
	}

	/**
	 * The error that says why each condition did not pass, stored with the run as a failed
	 * condition: the condition class's own messages for a condition that answered, and the
	 * run log's sentence for a condition nothing answered, one per line in evaluation order.
	 *
	 * @since 8.0.0
	 *
	 * @param array<int, array<string, mixed>> $failed     `{ condition, integration, answered, messages }` per condition to record, in evaluation order.
	 * @param array<string, mixed>             $block_node Filter block node.
	 * @param Execution_Context                $context    The run.
	 *
	 * @return Action_Error|null Null when there is nothing to say.
	 */
	private function conditions_error( array $failed, array $block_node, Execution_Context $context ): ?Action_Error {
		$block_id   = (int) ( $block_node['id'] ?? 0 );
		$messages   = array();
		$unanswered = array();
		$answered   = array();

		foreach ( $failed as $condition ) {
			$identity = array(
				'condition'   => $condition['condition'],
				'integration' => $condition['integration'],
			);

			if ( ! $condition['answered'] ) {
				$messages[]   = $this->unanswered_message( $block_id, $condition['condition'], $condition['integration'] );
				$unanswered[] = $identity;
				continue;
			}

			if ( ! empty( $condition['messages'] ) ) {
				$messages   = array_merge( $messages, $condition['messages'] );
				$answered[] = $identity;
			}
		}

		if ( empty( $messages ) ) {
			return null;
		}

		return new Action_Error(
			Error_Code::CONDITION_FAILED,
			implode( "\n", $messages ),
			array(
				'block_id'          => $block_id,
				'recipe_id'         => $context->get_recipe_id(),
				'conditions'        => $unanswered,
				'failed_conditions' => $answered,
			)
		);
	}

	/**
	 * The run log's sentence for one unanswered condition: its code, and its integration when the
	 * modifier names one.
	 *
	 * @since 8.0.0
	 *
	 * @param int    $block_id    Filter block id.
	 * @param string $code        Condition code.
	 * @param string $integration Integration code, '' when the modifier names none.
	 *
	 * @return string
	 */
	private function unanswered_message( int $block_id, string $code, string $integration ): string {
		if ( '' === $integration ) {
			return sprintf(
				/* translators: 1: Filter block ID, 2: Condition code */
				esc_html_x( 'Filter block %1$d: condition %2$s could not be evaluated because no active plugin provides it, so it counts as not met.', 'Recipe run log', 'uncanny-automator-pro' ),
				$block_id,
				esc_html( $code )
			);
		}

		return sprintf(
			/* translators: 1: Filter block ID, 2: Condition code, 3: Integration code */
			esc_html_x( 'Filter block %1$d: condition %2$s (%3$s) could not be evaluated because no active plugin provides it, so it counts as not met.', 'Recipe run log', 'uncanny-automator-pro' ),
			$block_id,
			esc_html( $code ),
			esc_html( $integration )
		);
	}
}
