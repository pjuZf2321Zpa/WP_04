<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Infrastructure\Database\Database;
use Uncanny_Automator\App\Infrastructure\Database\Interfaces\Execution_Log_Store;
use Uncanny_Automator_Pro\Async_Actions;
use Uncanny_Automator\Services\Action_Scheduler;

/**
 * Deleting a delay block cancels the runs still waiting on it.
 *
 * Without this the block's resume job fires later, finds no block, and settles
 * the waiting rows with an error — days after the user removed the delay, on
 * steps that may still be in the recipe. Cancelled rows say what happened.
 *
 * Every block removal reaches `wp_delete_post()` — the block itself, nested
 * blocks in delete mode, keep-mode placement violators, loops, recipe
 * cascades — so this listens there rather than on one delete path. Only the
 * deleted block's own jobs are cancelled: a nested delay that survives a
 * keep-mode delete keeps waiting.
 *
 * A delay inside a loop body parks entry items rather than rows, so it has no
 * waiting row to settle and is left as it is, the same as Delay_Block_Control.
 */
final class Delay_Block_Deletion {

	/**
	 * Rows and row meta of the waiting runs.
	 *
	 * @var Execution_Log_Store
	 */
	private Execution_Log_Store $log_store;

	/**
	 * Wire the listener.
	 *
	 * @param Execution_Log_Store|null $log_store Log store; defaults to the shared one.
	 */
	public function __construct( ?Execution_Log_Store $log_store = null ) {
		$this->log_store = $log_store ?? Database::get_execution_log_store();
	}

	/**
	 * `before_delete_post` listener: cancel the waiting runs of a block being deleted.
	 *
	 * @param int           $post_id Post being deleted.
	 * @param \WP_Post|null $post    The post.
	 *
	 * @return void
	 */
	public function handle( $post_id, $post = null ): void {
		if ( ! $post instanceof \WP_Post || AUTOMATOR_POST_TYPE_BLOCK !== $post->post_type ) {
			return;
		}

		// Read before the delete removes the row: the recipe scopes the lookup
		// to its own waiting runs rather than every pending delay on the site.
		$block     = Database::get_block_store()->get( (int) $post_id );
		$recipe_id = (int) ( $block['recipe_id'] ?? 0 );
		if ( $recipe_id <= 0 ) {
			return;
		}

		foreach ( $this->waiting_jobs( $recipe_id ) as $job_id => $row ) {
			$payload = $this->pending_payload( $job_id );
			if ( null !== $payload && (int) ( $payload['block_id'] ?? 0 ) === (int) $post_id ) {
				// Settles every row sharing the job and finalizes the run.
				Async_Actions::cancel_job( $row['action_log_id'], $row['action_id'], (int) $payload['recipe_log_id'] );
			}
		}
	}

	/**
	 * The recipe's rows still waiting on a job, one per job.
	 *
	 * @param int $recipe_id Recipe post id.
	 *
	 * @return array<int,array{action_log_id:int,action_id:int}> Job id => a waiting row.
	 */
	private function waiting_jobs( int $recipe_id ): array {
		$rows = array();
		foreach ( Async_Actions::get_scheduled_actions( $recipe_id ) as $row ) {
			$rows[ (int) $row->ID ] = (int) $row->automator_action_id;
		}

		if ( empty( $rows ) ) {
			return array();
		}

		$jobs = array();
		foreach ( $this->log_store->get_action_log_meta_bag( array_keys( $rows ) ) as $action_log_id => $meta ) {
			$job_id = (int) ( $meta[ Execution_Log_Store::ACTION_META_ASYNC_JOB_ID ] ?? 0 );
			if ( $job_id > 0 && ! isset( $jobs[ $job_id ] ) ) {
				$jobs[ $job_id ] = array(
					'action_log_id' => (int) $action_log_id,
					'action_id'     => $rows[ (int) $action_log_id ],
				);
			}
		}

		return $jobs;
	}

	/**
	 * A still-pending delay-block resume job's payload.
	 *
	 * @param int $job_id Action Scheduler job id.
	 *
	 * @return array|null The payload, or null when the job is not a pending delay-block resume.
	 */
	private function pending_payload( int $job_id ): ?array {
		try {
			// A row can point at a job Action Scheduler has since purged.
			if ( Action_Scheduler::STATUS_PENDING !== Action_Scheduler::get_status( $job_id ) ) {
				return null;
			}
		} catch ( \InvalidArgumentException $e ) {
			return null;
		}

		// Purged between the status read and the fetch.
		$job = Action_Scheduler::fetch_action( $job_id );
		if ( null === $job || Delay_Block_Processor::RESUME_HOOK !== $job->get_hook() ) {
			return null;
		}

		$payload = automator_get_option( (string) ( $job->get_args()[0] ?? '' ), false );

		return is_array( $payload ) && ! empty( $payload['recipe_log_id'] ) ? $payload : null;
	}
}
