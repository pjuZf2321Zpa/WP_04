<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Recipe_Runner\Blocks;

use Uncanny_Automator\App\Infrastructure\Database\Database;
use Uncanny_Automator\App\Infrastructure\Database\Interfaces\Action_Error_Store;
use Uncanny_Automator\App\Recipe_Builder\Block\Enums\Block_Type;
use Uncanny_Automator\App\Recipe_Builder\Recipe\Schema\Recipe_Schema_Reader;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Execution_Context;

/**
 * Decides, when a delayed job Pro 7.x queued runs, whether the conditions it deferred let its action run.
 *
 * In 7.x a condition group whose actions were all delayed was evaluated when each delayed job ran, not at
 * dispatch: the job carries `postponing_evaluation`. The 8.0 migration moved the groups into filter
 * blocks, so the job's conditions are now the filter blocks that hold its action in the recipe's tree.
 * Each one is evaluated with Filter_Block_Processor's own logic, against the state now, every time a job
 * runs: no earlier job's result is reused.
 *
 * @since 8.0.0
 */
final class Deferred_Conditions_Gate {

	/**
	 * The filter block's evaluation.
	 *
	 * @var Filter_Block_Processor
	 */
	private Filter_Block_Processor $processor;

	/**
	 * The recipe tree, migrated from 7.x storage on its first read.
	 *
	 * @var Recipe_Schema_Reader
	 */
	private Recipe_Schema_Reader $reader;

	/**
	 * Where an evaluation's error is recorded with its filter block, as the walker records a block outcome's error.
	 *
	 * @var Action_Error_Store
	 */
	private Action_Error_Store $errors;

	/**
	 * Wire the gate.
	 *
	 * @param Filter_Block_Processor|null $processor Filter evaluation; Pro's processor when null.
	 * @param Recipe_Schema_Reader|null   $reader    Tree reader; the shared reader when null.
	 * @param Action_Error_Store|null     $errors    Run error store; Free's when null.
	 */
	public function __construct( ?Filter_Block_Processor $processor = null, ?Recipe_Schema_Reader $reader = null, ?Action_Error_Store $errors = null ) {
		$this->processor = $processor ?? new Filter_Block_Processor();
		$this->reader    = $reader ?? Recipe_Schema_Reader::instance();
		$this->errors    = $errors ?? Database::get_action_error_store();
	}

	/**
	 * The evaluation that keeps the action from running, or null when it may run.
	 *
	 * Every filter block that holds the action is evaluated, outermost first, with the job's user and run
	 * args; the action runs only when each one takes the path the action sits on. An action no filter
	 * holds, or one the tree no longer has, is not gated here.
	 *
	 * @param int                  $recipe_id     Recipe post id.
	 * @param int                  $user_id       User the job runs as.
	 * @param int                  $recipe_log_id The run.
	 * @param int                  $action_id     Action post id.
	 * @param array<string, mixed> $args          The run args the job carries.
	 *
	 * @return Filter_Evaluation|null
	 * @throws \Throwable When the recipe tree cannot be read; the job fails and keeps its payload for Pro's retry.
	 */
	public function blocking_evaluation( int $recipe_id, int $user_id, int $recipe_log_id, int $action_id, array $args ): ?Filter_Evaluation {
		$tree = $this->reader->get_or_build( $recipe_id );

		if ( null === $tree ) {
			return null;
		}

		$context = new Execution_Context( $recipe_id, $user_id, $recipe_log_id, $args );

		foreach ( $this->enclosing_filters( (array) ( $tree['content'] ?? array() ), $action_id ) ?? array() as $enclosing ) {
			$evaluation = $this->processor->evaluate( $enclosing['block'], $context );

			if ( null !== $evaluation->error() ) {
				$this->errors->store_block_error( $recipe_log_id, (int) ( $enclosing['block']['id'] ?? 0 ), $evaluation->error() );
			}

			if ( $evaluation->taken_path() !== $enclosing['path_code'] ) {
				return $evaluation;
			}
		}

		return null;
	}

	/**
	 * The filter blocks that hold the action, outermost first, each with the path the action sits on.
	 * Block paths are searched at every depth, loop bodies included.
	 *
	 * @param array<int, array<string, mixed>> $items     Tree items.
	 * @param int                              $action_id Action post id.
	 *
	 * @return array<int, array{block: array<string, mixed>, path_code: string}>|null Null when the action is not among the items.
	 */
	private function enclosing_filters( array $items, int $action_id ): ?array {
		foreach ( $items as $item ) {
			$kind = (string) ( $item['kind'] ?? '' );

			if ( 'action' === $kind && (int) ( $item['id'] ?? 0 ) === $action_id ) {
				return array();
			}

			if ( 'block' !== $kind ) {
				continue;
			}

			foreach ( (array) ( $item['paths'] ?? array() ) as $path ) {
				$inner = $this->enclosing_filters( (array) ( $path['items'] ?? array() ), $action_id );

				if ( null === $inner ) {
					continue;
				}

				if ( Block_Type::FILTER === (string) ( $item['block_type'] ?? '' ) ) {
					array_unshift(
						$inner,
						array(
							'block'     => $item,
							'path_code' => (string) ( $path['path_code'] ?? '' ),
						)
					);
				}

				return $inner;
			}
		}

		return null;
	}
}
