<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

/**
 * Prevents administrator users from being selected in Everyone recipes.
 *
 * Centralizes the admin role check used across User_Creator and User_Finder.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class Admin_Guard {

	/**
	 * Check whether a user is an administrator.
	 *
	 * @param \WP_User $user The user to check.
	 *
	 * @return bool True if the user has the administrator role.
	 */
	public static function is_admin( \WP_User $user ): bool {
		return in_array( 'administrator', $user->roles, true );
	}

	/**
	 * Build an admin-rejection error message.
	 *
	 * @param \WP_User $user The rejected admin user.
	 *
	 * @return string
	 */
	public static function rejection_message( \WP_User $user ): string {
		return sprintf(
			/* translators: 1. The user email */
			esc_html_x( 'An existing user was found matching (%1$s), cannot select administrators', 'Recipe log message', 'uncanny-automator-pro' ),
			$user->user_email
		);
	}
}
