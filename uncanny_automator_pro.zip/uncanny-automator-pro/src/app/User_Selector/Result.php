<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

/**
 * Builds standardized legacy result arrays for user selector operations.
 *
 * Centralizes the `array('status' => ..., 'data' => array(...))` contract
 * used throughout the user selector pipeline.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class Result {

	/**
	 * Build a success result.
	 *
	 * @param int    $user_id     Resolved user ID.
	 * @param string $action      Action type (newUser|existingUser).
	 * @param string $fallback    Fallback that was applied.
	 * @param string $message     Human-readable log message.
	 * @param array  $parsed_data Parsed field data for trigger meta storage.
	 *
	 * @return array
	 */
	public static function success( int $user_id, string $action, string $fallback, string $message, array $parsed_data = array() ): array {
		return array(
			'status'      => true,
			'data'        => array(
				'user_id'  => $user_id,
				'fallback' => $fallback,
				'action'   => $action,
				'message'  => $message,
			),
			'parsed_data' => $parsed_data,
		);
	}

	/**
	 * Build an error result.
	 *
	 * @param int    $user_id  User ID (0 if none resolved).
	 * @param string $action   Action type (newUser|existingUser).
	 * @param string $fallback Fallback that was applied.
	 * @param string $message  Error message.
	 *
	 * @return array
	 */
	public static function error( int $user_id, string $action, string $fallback, string $message ): array {
		return array(
			'status' => false,
			'data'   => array(
				'user_id'  => $user_id,
				'fallback' => $fallback,
				'action'   => $action,
				'error'    => true,
				'message'  => $message,
			),
		);
	}

	/**
	 * Build a do-nothing result.
	 *
	 * @param int    $user_id  User ID (0 if none resolved).
	 * @param string $action   Action type (newUser|existingUser).
	 * @param string $fallback Fallback that was applied.
	 * @param string $message  Reason for doing nothing.
	 *
	 * @return array
	 */
	public static function do_nothing( int $user_id, string $action, string $fallback, string $message ): array {
		return array(
			'status' => false,
			'data'   => array(
				'user_id'  => $user_id,
				'fallback' => $fallback,
				'action'   => $action,
				'message'  => $message,
			),
		);
	}
}
