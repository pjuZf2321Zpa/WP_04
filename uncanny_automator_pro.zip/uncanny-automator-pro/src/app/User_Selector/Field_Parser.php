<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

/**
 * Parses the recipe's run-as (user selector) fields.
 *
 * Reads the selector through Free's `automator_get_recipe_user_selector()`,
 * which normalizes every stored shape. Handles token hydration, sanitization,
 * and logged-in user fallback.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class Field_Parser {

	/**
	 * Parse and hydrate the recipe's run-as fields.
	 *
	 * @param int   $recipe_id   The recipe ID.
	 * @param int   $user_id     The current user ID (may be 0 for anonymous).
	 * @param array $replace_args Token replacement args.
	 *
	 * @return array{user_data: array, parsed_data: array, fallback: string, user_action: string}|false False when the recipe has no valid selector.
	 */
	public function parse( int $recipe_id, int $user_id, array $replace_args ) {

		$selector = automator_get_recipe_user_selector( $recipe_id );

		if ( null === $selector ) {
			return false;
		}

		$fields      = $this->selector_fields( $selector );
		$user_action = $selector['source'];

		$data        = array();
		$parsed_data = array();
		$fallback    = array_key_exists( 'fallback', $fields ) ? $fields['fallback'] : '';

		foreach ( $fields as $key => $field_value ) {
			$data[ $key ]        = \Automator()->parse->text( $field_value, $recipe_id, $user_id, $replace_args );
			$parsed_data[ $key ] = $field_value;
		}

		if ( empty( $data ) ) {
			return false;
		}

		$user_data = $this->build_user_data( $data, $fields );
		$user_data = $this->maybe_fill_from_logged_in_user( $user_data );

		$combined_data = array_merge( $data, $parsed_data );

		return array(
			'user_data'   => $user_data,
			'parsed_data' => $combined_data,
			'fallback'    => $fallback,
			'user_action' => $user_action,
		);
	}

	/**
	 * Flatten the selector into the field keys the resolver reads and the run log stores.
	 *
	 * @since 8.0.0
	 *
	 * @param array $selector Selector from automator_get_recipe_user_selector().
	 *
	 * @return array
	 */
	private function selector_fields( array $selector ): array {

		$fields = array(
			'uniqueField'      => $selector['unique_field'] ?? null,
			'uniqueFieldValue' => $selector['unique_field_value'] ?? null,
			'fallback'         => $selector['fallback'] ?? null,
			'prioritizedField' => $selector['prioritized_field'] ?? null,
		) + ( $selector['user_data'] ?? array() );

		// User_Creator logs the user in on the stored 'yes', not a bool.
		if ( isset( $fields['logUserIn'] ) ) {
			$fields['logUserIn'] = $fields['logUserIn'] ? 'yes' : 'no';
		}

		return array_filter(
			$fields,
			static function ( $value ) {
				return null !== $value;
			}
		);
	}

	/**
	 * Build the user data array from hydrated field values.
	 *
	 * @param array $data   Hydrated field data.
	 * @param array $fields Raw fields from post meta.
	 *
	 * @return array
	 */
	private function build_user_data( array $data, array $fields ): array {

		$user_data = array(
			'first_name'         => $data['firstName'] ?? '',
			'last_name'          => $data['lastName'] ?? '',
			'user_email'         => $data['email'] ?? '',
			'user_login'         => $data['username'] ?? ( $data['email'] ?? '' ),
			'role'               => $data['role'] ?? apply_filters( 'uap_default_user_role', get_option( 'default_role', 'subscriber' ) ),
			'prioritized_field'  => $fields['prioritizedField'] ?? '',
			'unique_field_value' => $data['uniqueFieldValue'] ?? '',
			'unique_field'       => $fields['uniqueField'] ?? '',
		);

		$user_data['user_pass'] = ! empty( $data['password'] )
			? $data['password']
			: apply_filters( 'uap_maybe_generate_anonymous_user_password', wp_generate_password(), $user_data );

		return $user_data;
	}

	/**
	 * Fill empty email/username from current logged-in user when available.
	 *
	 * @param array $user_data The user data array.
	 *
	 * @return array
	 */
	private function maybe_fill_from_logged_in_user( array $user_data ): array {

		if ( ! empty( $user_data['user_email'] ) && ! empty( $user_data['user_login'] ) ) {
			return $user_data;
		}

		if ( ! is_user_logged_in() ) {
			return $user_data;
		}

		$current_user = wp_get_current_user();

		if ( empty( $user_data['user_email'] ) ) {
			$user_data['user_email'] = $current_user->user_email;
		}

		if ( empty( $user_data['user_login'] ) ) {
			$user_data['user_login'] = $current_user->user_login;
		}

		if ( empty( $user_data['unique_field_value'] ) ) {
			$user_data['unique_field_value'] = $current_user->user_email;
		}

		return $user_data;
	}
}
