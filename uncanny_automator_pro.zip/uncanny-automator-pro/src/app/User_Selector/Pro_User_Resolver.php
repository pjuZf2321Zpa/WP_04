<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

use Uncanny_Automator\App\Recipe_Runner\Value_Objects\User_Resolution;
use Uncanny_Automator\App\Recipe_Runner\Services\User_Resolver;

/**
 * Resolves WordPress users for Everyone recipes.
 *
 * Reads recipe config, parses fields, and delegates to User_Creator or User_Finder.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class Pro_User_Resolver implements User_Resolver {

	/**
	 * @var User_Creator
	 */
	private $user_creator;

	/**
	 * @var User_Finder
	 */
	private $user_finder;

	/**
	 * @var Field_Parser
	 */
	private $field_parser;

	/**
	 * @param User_Creator $user_creator Creates new users.
	 * @param User_Finder  $user_finder  Finds existing users.
	 * @param Field_Parser $field_parser Parses recipe user selector fields.
	 */
	public function __construct( User_Creator $user_creator, User_Finder $user_finder, Field_Parser $field_parser ) {
		$this->user_creator = $user_creator;
		$this->user_finder  = $user_finder;
		$this->field_parser = $field_parser;
	}

	/**
	 * Resolve a WordPress user for an anonymous recipe run.
	 *
	 * Returns the legacy-format result array used by the monolith, maintaining
	 * backward compatibility with action failure handler and log storage.
	 *
	 * @param array $process Filter context from automator_maybe_continue_recipe_process.
	 *
	 * @return array Legacy result array with status, data, and parsed_data keys.
	 */
	public function resolve_legacy( array $process ): array {

		$recipe_id = absint( $process['recipe_id'] );
		$user_id   = absint( $process['user_id'] );
		$args      = $process['args'] ?? array();

		$replace_args = array(
			'recipe_id'      => $recipe_id,
			'recipe_log_id'  => absint( $process['recipe_log_id'] ?? 0 ),
			'trigger_id'     => absint( $args['trigger_id'] ?? 0 ),
			'trigger_log_id' => absint( $args['trigger_log_id'] ?? 0 ),
			'run_number'     => $args['run_number'] ?? 0,
			'user_id'        => $user_id,
		);

		$parsed = $this->field_parser->parse( $recipe_id, $user_id, $replace_args );

		if ( false === $parsed ) {
			return array(
				'status' => false,
				'data'   => array(
					'error'   => true,
					'message' => esc_html_x( 'There was an issue parsing action fields. Please confirm action fields are correctly saved in your recipe.', 'Recipe log message', 'uncanny-automator-pro' ),
				),
			);
		}

		$user_data   = $parsed['user_data'];
		$fallback    = $parsed['fallback'];
		$user_action = $parsed['user_action'];
		$parsed_data = $parsed['parsed_data'];

		// Validate before proceeding.
		$validation = $this->validate_user_data( $user_data, $fallback, $user_action );

		if ( false !== $validation ) {
			return $validation;
		}

		if ( 'new-user' === $user_action ) {
			return $this->user_creator->create_or_fallback( $user_data, $fallback, $parsed_data );
		}

		if ( 'existing-user' === $user_action ) {
			return $this->user_finder->find_or_fallback( $user_data, $fallback, $parsed_data );
		}

		return array(
			'status' => false,
			'data'   => array(
				'error'   => true,
				'message' => esc_html_x( 'There was an issue in running your recipe. Automator failed to run a new or existing user scenario.', 'Recipe log message', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function resolve( array $process ): User_Resolution {

		$this->fire_before_lifecycle_hook( $process );

		$result = $this->resolve_legacy( $process );

		$status    = $result['status'] ?? false;
		$data      = $result['data'] ?? array();
		$user_id   = (int) ( $data['user_id'] ?? 0 );
		$message   = $data['message'] ?? '';
		$parsed    = $result['parsed_data'] ?? array();

		$this->fire_after_lifecycle_hooks( $process, $result );

		if ( true === $status ) {
			return User_Resolution::success( $user_id, $message, $parsed );
		}

		if ( isset( $data['error'] ) && true === $data['error'] ) {
			return User_Resolution::error( $message, $user_id );
		}

		return User_Resolution::do_nothing( $message, $user_id );
	}

	/**
	 * Fire the pre-resolution anon-user lifecycle hook (backward compat).
	 *
	 * Retained for add-ons that hooked the pre-7.3 Everyone-recipe completion
	 * flow. do_action_deprecated() is a no-op unless a listener is attached, so
	 * this costs nothing for sites that don't use it. Scheduled for removal in 8.0.
	 *
	 * @deprecated 7.3 Use automator_before_action_executed to intercept actions.
	 *
	 * @param array $process Resolution context.
	 *
	 * @return void
	 */
	private function fire_before_lifecycle_hook( array $process ): void {

		$user_id        = absint( $process['user_id'] ?? 0 );
		$recipe_id      = absint( $process['recipe_id'] ?? 0 );
		$trigger_log_id = absint( $process['trigger_log_id'] ?? 0 );
		$args           = $process['args'] ?? array();

		do_action_deprecated(
			'automator_pro_before_anon_user_action_completed',
			array( $user_id, $recipe_id, $trigger_log_id, $args, $process ),
			'7.3',
			'automator_before_action_executed'
		);
	}

	/**
	 * Fire the post-resolution anon-user lifecycle hooks (backward compat).
	 *
	 * `automator_pro_after_user_action_completed` fires only on a successful
	 * resolution; `automator_pro_after_anon_user_action_completed` always fires.
	 * Both are no-ops unless a listener is attached. Scheduled for removal in 8.0.
	 *
	 * @deprecated 7.3 Use automator_before_action_executed to intercept actions.
	 *
	 * @param array $process Resolution context.
	 * @param array $result  Legacy resolution result.
	 *
	 * @return void
	 */
	private function fire_after_lifecycle_hooks( array $process, array $result ): void {

		$recipe_id        = absint( $process['recipe_id'] ?? 0 );
		$trigger_log_id   = absint( $process['trigger_log_id'] ?? 0 );
		$args             = $process['args'] ?? array();
		$resolved_user_id = $this->resolved_user_id( $result, $args );

		$attributes            = $process;
		$attributes['user_id'] = $resolved_user_id;
		if ( 0 !== $resolved_user_id ) {
			$attributes['args']['user_id'] = $resolved_user_id;
		}

		if ( true === ( $result['status'] ?? false ) ) {
			do_action_deprecated(
				'automator_pro_after_user_action_completed',
				array( $result, $resolved_user_id, $recipe_id, $trigger_log_id, $args ),
				'7.3',
				'automator_before_action_executed'
			);
		}

		do_action_deprecated(
			'automator_pro_after_anon_user_action_completed',
			array( $resolved_user_id, $recipe_id, $trigger_log_id, $attributes ),
			'7.3',
			'automator_before_action_executed'
		);
	}

	/**
	 * Resolve the effective user id: resolver result, falling back to trigger args.
	 *
	 * @param array $result Legacy resolution result.
	 * @param array $args   Trigger args.
	 *
	 * @return int
	 */
	private function resolved_user_id( array $result, array $args ): int {

		$data     = $result['data'] ?? array();
		$resolved = array_key_exists( 'user_id', $data ) ? (int) $data['user_id'] : 0;

		if ( 0 === $resolved && isset( $args['user_id'] ) && 0 !== absint( $args['user_id'] ) ) {
			$resolved = absint( $args['user_id'] );
		}

		return $resolved;
	}

	/**
	 * Validate required user data before user creation/lookup.
	 *
	 * @param array  $user_data   The user data to validate.
	 * @param string $fallback    Fallback action setting.
	 * @param string $user_action The user action type.
	 *
	 * @return array|false Error array if validation fails, false if valid.
	 */
	private function validate_user_data( array $user_data, string $fallback, string $user_action ) {

		if ( 'do-nothing' === $fallback ) {
			return false;
		}

		$checks = array(
			array(
				'condition' => empty( $user_data['user_email'] ) && empty( $user_data['user_login'] ),
				'message'   => esc_html_x( 'Username and email fields were empty', 'Validation error message', 'uncanny-automator-pro' ),
			),
			array(
				'condition' => empty( $user_data['user_email'] ),
				'message'   => esc_html_x( 'Email field was empty', 'Validation error message', 'uncanny-automator-pro' ),
			),
			array(
				'condition' => empty( $user_data['user_login'] ),
				'message'   => esc_html_x( 'Username field was empty', 'Validation error message', 'uncanny-automator-pro' ),
			),
			array(
				'condition' => ! is_email( $user_data['user_email'] ),
				'message'   => sprintf(
					/* translators: %s: The invalid email address */
					esc_html_x( 'Invalid email provided (%s)', 'Validation error message', 'uncanny-automator-pro' ),
					$user_data['user_email']
				),
			),
		);

		foreach ( $checks as $check ) {
			if ( $check['condition'] ) {
				return array(
					'status' => false,
					'data'   => array(
						'user_id'  => 0,
						'error'    => true,
						'fallback' => $fallback,
						'action'   => $user_action,
						'message'  => $check['message'],
					),
				);
			}
		}

		return false;
	}
}
