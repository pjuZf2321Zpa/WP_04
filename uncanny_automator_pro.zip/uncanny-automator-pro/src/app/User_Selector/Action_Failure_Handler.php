<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

/**
 * Skips and logs actions when Everyone-recipe user resolution fails.
 *
 * Hooked on `automator_before_action_executed` (priority 1), it short-circuits
 * each action whenever the run's user resolution did not yield a usable user.
 *
 * Stateless by design: the resolution outcome is read directly from the action
 * args that the Recipe_Runner pipeline already carries. Trigger_Complete_Stage
 * (Free) stamps `do-nothing`, `complete_with_errors`, and `user_action_message`
 * onto `$process['args']`; Pipeline_Result::set_execution_ready() preserves
 * those keys, so they arrive intact as `$action['args']` here. There is no
 * mutable per-run state to populate or clear — the handler is a pure function
 * of the data flowing through the pipeline, which removes the temporal coupling
 * that previously required a separate result-injection step.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class Action_Failure_Handler {

	/**
	 * Filter callback for `automator_before_action_executed`.
	 *
	 * Prevents action execution and logs the outcome when user resolution failed.
	 *
	 * @param array $action The action data array.
	 *
	 * @return array Modified action data.
	 */
	public function maybe_handle_failure( array $action ): array {

		$args = $action['args'] ?? array();

		if ( ! $this->is_user_action_failure( $args ) ) {
			return $action;
		}

		$action['process_further'] = false;
		$this->log_action( $action );

		return $action;
	}

	/**
	 * Whether the run's user resolution failed (do-nothing or error).
	 *
	 * Both states are propagated by Trigger_Complete_Stage::resolve_anonymous_user()
	 * and are mutually exclusive for a single resolution.
	 *
	 * @param array $args The action args carrying the resolution outcome.
	 *
	 * @return bool
	 */
	private function is_user_action_failure( array $args ): bool {

		return array_key_exists( 'complete_with_errors', $args )
			|| array_key_exists( 'do-nothing', $args );
	}

	/**
	 * Log the action with the appropriate error or do-nothing status.
	 *
	 * @param array $action Action data with user_id, action_data, recipe_id, args.
	 *
	 * @return void
	 */
	private function log_action( array $action ): void {

		$user_id     = $action['user_id'] ?? 0;
		$action_data = $action['action_data'] ?? array();
		$recipe_id   = $action['recipe_id'] ?? 0;
		$args        = $action['args'] ?? array();

		$message     = $this->resolve_message( $args );
		$action_data = $this->apply_failure_flags( $action_data, $args );

		if ( isset( $action_data['args'] ) && ! isset( $action_data['args']['user_action_message'] ) ) {
			$action_data['args']['user_action_message'] = $message;
		}

		\Automator()->complete->action( $user_id, $action_data, $recipe_id, $message );
	}

	/**
	 * Apply error or do-nothing flags to action data based on the resolution outcome.
	 *
	 * Error takes precedence over do-nothing, matching the resolution priority.
	 *
	 * @param array $action_data The action data to modify.
	 * @param array $args        The action args carrying the resolution outcome.
	 *
	 * @return array Modified action data.
	 */
	private function apply_failure_flags( array $action_data, array $args ): array {

		if ( array_key_exists( 'complete_with_errors', $args ) ) {
			$action_data['complete_with_errors']         = true;
			$action_data['args']['complete_with_errors'] = true;
		} elseif ( array_key_exists( 'do-nothing', $args ) ) {
			$action_data['do-nothing']         = true;
			$action_data['args']['do-nothing'] = true;
		}

		return $action_data;
	}

	/**
	 * Resolve the log message from the propagated resolution outcome.
	 *
	 * @param array $args The action args carrying the resolution outcome.
	 *
	 * @return string
	 */
	private function resolve_message( array $args ): string {

		if ( ! empty( $args['user_action_message'] ) ) {
			return (string) $args['user_action_message'];
		}

		return esc_html_x( 'There was an error completing recipe.', 'Recipe log message', 'uncanny-automator-pro' );
	}
}
