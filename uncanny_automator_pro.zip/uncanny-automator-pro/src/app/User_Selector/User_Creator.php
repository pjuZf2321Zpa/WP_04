<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

use Uncanny_Automator_Pro\Automator_Pro_Deferred_User_Login;

/**
 * Creates new WordPress users for Everyone recipes.
 *
 * Handles user creation + fallback when user already exists.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class User_Creator {

	/**
	 * Create a new user or fall back when one already exists.
	 *
	 * @param array  $user_data   Validated user data for wp_insert_user.
	 * @param string $fallback    Fallback action (select-existing-user|do-nothing).
	 * @param array  $parsed_data Combined field data for log storage.
	 *
	 * @return array Legacy-format result array with status, data, and parsed_data.
	 */
	public function create_or_fallback( array $user_data, string $fallback, array $parsed_data ): array {

		$existing_user_id = $this->find_existing_user( $user_data );

		if ( false !== $existing_user_id ) {
			return $this->handle_existing_user_fallback( $existing_user_id, $fallback, $parsed_data );
		}

		return $this->insert_user( $user_data, $fallback, $parsed_data );
	}

	/**
	 * Insert a new WordPress user.
	 *
	 * @param array  $user_data   Data for wp_insert_user.
	 * @param string $fallback    Fallback setting.
	 * @param array  $parsed_data Parsed recipe fields.
	 *
	 * @return array
	 */
	public function insert_user( array $user_data, string $fallback, array $parsed_data ): array {

		$user_id = wp_insert_user( $user_data );

		if ( is_wp_error( $user_id ) ) {
			return Result::error(
				(int) email_exists( $user_data['user_email'] ),
				'newUser',
				'do-nothing',
				sprintf(
					/* translators: 1. The user email, 2. The error */
					esc_html_x( 'Creating a new user failed (%1$s). %2$s', 'Recipe log message', 'uncanny-automator-pro' ),
					$user_data['user_email'],
					$user_id->get_error_message()
				)
			);
		}

		$this->maybe_defer_login( $user_id, $parsed_data );

		return Result::success(
			$user_id,
			'newUser',
			$fallback,
			sprintf(
				/* translators: 1. The user email */
				esc_html_x( 'A new user was created (%1$s)', 'Recipe log message', 'uncanny-automator-pro' ),
				$user_data['user_email']
			),
			$parsed_data
		);
	}

	/**
	 * Handle fallback when user already exists during "Create new user" action.
	 *
	 * @param int    $user_id     Existing user ID.
	 * @param string $fallback    Fallback action.
	 * @param array  $parsed_data Parsed recipe fields.
	 *
	 * @return array
	 */
	private function handle_existing_user_fallback( int $user_id, string $fallback, array $parsed_data ): array {

		$user = get_user_by( 'ID', $user_id );

		if ( Admin_Guard::is_admin( $user ) ) {
			return Result::error( $user_id, 'newUser', 'do-nothing', Admin_Guard::rejection_message( $user ) );
		}

		if ( 'select-existing-user' === $fallback ) {
			return Result::success(
				$user_id,
				'newUser',
				$fallback,
				sprintf(
					/* translators: 1. The user email */
					esc_html_x( 'An existing user was found matching (%1$s), selected existing user', 'Recipe log message', 'uncanny-automator-pro' ),
					$user->user_email
				),
				$parsed_data
			);
		}

		// do-nothing or any unknown fallback.
		return Result::do_nothing(
			$user_id,
			'newUser',
			$fallback,
			sprintf(
				/* translators: 1. The user email */
				esc_html_x( 'An existing user was found matching (%1$s), "do nothing" selected in the recipe', 'Recipe log message', 'uncanny-automator-pro' ),
				$user->user_login
			)
		);
	}

	/**
	 * Trigger deferred login if configured.
	 *
	 * @param int   $user_id     The created user ID.
	 * @param array $parsed_data Parsed recipe fields.
	 *
	 * @return void
	 */
	private function maybe_defer_login( int $user_id, array $parsed_data ): void {
		if ( isset( $parsed_data['logUserIn'] ) && 'yes' === $parsed_data['logUserIn'] ) {
			Automator_Pro_Deferred_User_Login::maybe_login_user( $user_id );
		}
	}

	/**
	 * Check if a user exists by email or username based on prioritized field.
	 *
	 * @param array $user_data User data with prioritized_field, user_email, user_login.
	 *
	 * @return int|false User ID if found, false otherwise.
	 */
	private function find_existing_user( array $user_data ) {

		$priority = $user_data['prioritized_field'] ?? 'email';

		if ( 'username' === (string) $priority ) {
			$user_id = username_exists( $user_data['user_login'] );

			if ( $user_id ) {
				return (int) $user_id;
			}

			return ! empty( $user_data['user_email'] ) ? email_exists( $user_data['user_email'] ) : false;
		}

		// Default: email priority.
		$user_id = email_exists( $user_data['user_email'] );

		if ( $user_id ) {
			return (int) $user_id;
		}

		return ! empty( $user_data['user_login'] ) ? username_exists( $user_data['user_login'] ) : false;
	}
}
