<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\User_Selector;

/**
 * Finds existing WordPress users for Everyone recipes.
 *
 * Handles user lookup by email/username/ID + fallback to create.
 *
 * @package Uncanny_Automator_Pro\App\User_Selector
 * @since   7.2
 */
class User_Finder {

	/**
	 * @var User_Creator
	 */
	private $user_creator;

	/**
	 * @param User_Creator $user_creator Injected creator for create-new-user fallback.
	 */
	public function __construct( User_Creator $user_creator ) {
		$this->user_creator = $user_creator;
	}

	/**
	 * Find an existing user or handle the not-found fallback.
	 *
	 * @param array  $user_data   User data with unique_field and unique_field_value.
	 * @param string $fallback    Fallback action (create-new-user|do-nothing).
	 * @param array  $parsed_data Combined field data for log storage.
	 *
	 * @return array Legacy-format result array with status, data, and parsed_data.
	 */
	public function find_or_fallback( array $user_data, string $fallback, array $parsed_data ): array {

		$user_id = $this->lookup_user( $user_data );

		if ( false !== $user_id ) {
			return $this->use_existing_user( $user_id, $fallback, $parsed_data );
		}

		return $this->handle_not_found_fallback( $user_data, $fallback, $parsed_data );
	}

	/**
	 * Use an existing user with admin guard.
	 *
	 * @param int    $user_id     Found user ID.
	 * @param string $fallback    Fallback action.
	 * @param array  $parsed_data Parsed recipe fields.
	 *
	 * @return array
	 */
	private function use_existing_user( int $user_id, string $fallback, array $parsed_data ): array {

		$user = get_user_by( 'ID', $user_id );

		if ( ! $user instanceof \WP_User ) {
			return Result::error(
				$user_id,
				'existingUser',
				'do-nothing',
				sprintf(
					/* translators: %s: The user ID */
					esc_html_x( 'A user was not found: (%s)', 'Error message when user not found by ID', 'uncanny-automator-pro' ),
					$user_id
				)
			);
		}

		if ( Admin_Guard::is_admin( $user ) ) {
			return Result::error( $user_id, 'existingUser', 'do-nothing', Admin_Guard::rejection_message( $user ) );
		}

		return Result::success(
			$user_id,
			'existingUser',
			$fallback,
			sprintf(
				/* translators: %1$s: The user email */
				esc_html_x( 'A user found matching (%1$s), user was selected', 'Success message when existing user is found', 'uncanny-automator-pro' ),
				$user->user_email
			),
			$parsed_data
		);
	}

	/**
	 * Handle fallback when no existing user is found.
	 *
	 * @param array  $user_data   User data for potential creation.
	 * @param string $fallback    Fallback action.
	 * @param array  $parsed_data Parsed recipe fields.
	 *
	 * @return array
	 */
	private function handle_not_found_fallback( array $user_data, string $fallback, array $parsed_data ): array {

		if ( 'create-new-user' === $fallback ) {
			return $this->user_creator->insert_user( $user_data, $fallback, $parsed_data );
		}

		// do-nothing or any unknown fallback.
		return Result::do_nothing(
			0,
			'existingUser',
			$fallback,
			sprintf(
				/* translators: 1. The user ID, email or username */
				esc_html_x( 'A user was not found matching (%1$s), "do nothing" selected in the recipe.', 'Recipe log message', 'uncanny-automator-pro' ),
				$user_data['unique_field_value']
			)
		);
	}

	/**
	 * Look up a user by the configured unique field.
	 *
	 * @param array $user_data User data with unique_field and unique_field_value.
	 *
	 * @return int|false User ID if found, false otherwise.
	 */
	private function lookup_user( array $user_data ) {

		$unique_field = ! empty( $user_data['unique_field'] ) ? $user_data['unique_field'] : 'email';
		$value        = $user_data['unique_field_value'] ?? '';

		if ( empty( $value ) ) {
			return false;
		}

		switch ( $unique_field ) {
			case 'username':
				$user_id = username_exists( $value );
				return ! is_wp_error( $user_id ) ? $user_id : false;

			case 'id':
				$user = get_user_by( 'ID', $value );
				return $user instanceof \WP_User ? $user->ID : false;

			case 'email':
			default:
				$user_id = email_exists( $value );
				return ! is_wp_error( $user_id ) ? $user_id : false;
		}
	}
}
