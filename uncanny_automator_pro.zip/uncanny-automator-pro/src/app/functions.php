<?php
/**
 * Uncanny Automator Pro API Functions
 *
 * Loader for Pro's `automator_pro_*` helper files under `src/app/functions/`.
 * Mirrors Free's `src/app/functions.php` ladder.
 *
 * @since 8.0.0
 * @package Uncanny_Automator_Pro\Api
 */

declare(strict_types=1);

// Prevent direct access (skip in test environment)
if ( ! defined( 'ABSPATH' ) && ! defined( 'PHPUNIT_COMPOSER_INSTALL' ) && ! defined( 'WP_TESTS_DIR' ) ) {
	exit;
}

require_once __DIR__ . '/functions/loop.php';
