<?php
/**
 * Automator Pro core transient keys.
 *
 * @package Uncanny_Automator_Pro
 */

declare(strict_types=1);

namespace Uncanny_Automator_Pro\App\Transient\Domain;

/**
 * Lists the transients invalidated by Automator Pro lifecycle changes.
 */
class Core_Transient_Keys {

	/**
	 * Transients invalidated by Automator Pro lifecycle changes.
	 *
	 * @var string[]
	 */
	private static array $keys = array(
		'automator_api_license',
		'automator_license_check_failed',
		'automator_api_credit_data',
		'automator_api_credits',
	);

	/**
	 * Get the Automator Pro core transient keys.
	 *
	 * @return string[]
	 */
	public static function get_all(): array {
		return self::$keys;
	}
}
