<?php
/**
 * Pro Loop Functions
 *
 * Pro-side guard seams over Free's loop helpers.
 *
 * @since 8.0.0
 * @package Uncanny_Automator_Pro\App\Functions
 */

declare(strict_types=1);

// Prevent direct access
if ( ! defined( 'ABSPATH' ) && ! defined( 'PHPUNIT_COMPOSER_INSTALL' ) && ! defined( 'WP_TESTS_DIR' ) ) {
	exit;
}

if ( ! function_exists( 'automator_pro_get_loop_filters' ) ) {
	/**
	 * Retrieve a loop's filters as unified modifier rows.
	 *
	 * Guarded delegate to Free's `automator_get_loop_filters()` — Pro runtime
	 * code calls this seam so a Free install predating the helper degrades to
	 * a WP_Error (empty filter set downstream) instead of a fatal. Version
	 * gating enforces the Free>=8.0.0 pairing at release; this guard is the
	 * belt to that suspenders.
	 *
	 * @param int $loop_id Unified loop block post id.
	 *
	 * @return array|\WP_Error Modifier rows ordered by menu_order, or WP_Error.
	 */
	function automator_pro_get_loop_filters( int $loop_id ) {
		if ( ! function_exists( 'automator_get_loop_filters' ) ) {
			return new \WP_Error(
				'free_helper_unavailable',
				esc_html_x( 'Uncanny Automator 8.0.0+ is required to read loop filters.', 'Loop helper error', 'uncanny-automator-pro' )
			);
		}

		return automator_get_loop_filters( $loop_id );
	}
}
