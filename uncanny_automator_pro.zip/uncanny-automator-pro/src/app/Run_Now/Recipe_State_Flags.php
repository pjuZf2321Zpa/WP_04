<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Run_Now;

use Uncanny_Automator\Automator_Status;

/**
 * Reports the recipe-builder wire state flags for Run Now recipes.
 *
 * Hooks Free's `automator_recipe_state_flags` filter and fills the
 * Pro-writable flags — `has_run_now` / `can_edit` / `latest_recipe_log_id` /
 * `latest_run_number` — for any recipe whose trigger is run-now-style (fires
 * on `automator_pro_run_now_recipe`: the manual trigger and the loopable
 * CSV/JSON/XML/RSS triggers).
 *
 * The run-now-style trigger codes are hardcoded here, not contributed by each
 * integration through a filter. This is closed Pro functionality with no
 * extension need, and a filter would be unreliable under demand-driven
 * integration loading: an integration that doesn't load on a given request
 * could not contribute its code. This reporter is wired from `src/boot.php`
 * (always loaded) and asks Free the same question the run-now route guards on —
 * `automator_recipe_has_manual_trigger()`, which matches the manual trigger by
 * code and every other run-now-style trigger by the `automator_pro_run_now_recipe`
 * hook it registers. A new run-now trigger therefore needs no change here.
 *
 * Run state is read through the Free public helper `automator_get_recipe_latest_log`
 * — the single source of truth for the latest `uap_recipe_log` row.
 */
final class Recipe_State_Flags {

	/**
	 * Log `completed` values that mean the run is still going, so editing must
	 * stay locked. IN_PROGRESS_WITH_ERROR is stamped when an action has already
	 * errored but scheduled actions are still pending — the run is live.
	 *
	 * @var int[]
	 */
	const RUNNING_STATUSES = array(
		Automator_Status::IN_PROGRESS,
		Automator_Status::IN_PROGRESS_WITH_ERROR,
	);

	/**
	 * Filter callback on `automator_recipe_state_flags`.
	 *
	 * @param array $flags     { can_edit, has_run_now, latest_recipe_log_id, latest_run_number }.
	 * @param int   $recipe_id Recipe ID.
	 *
	 * @return array
	 */
	public function report( $flags, $recipe_id ) {

		$recipe_id = (int) $recipe_id;

		if ( ! $this->is_run_now_recipe( $recipe_id ) ) {
			return $flags;
		}

		$log = automator_get_recipe_latest_log( $recipe_id );

		$flags['has_run_now']          = true;
		$flags['latest_recipe_log_id'] = null !== $log ? $log['recipe_log_id'] : null;
		$flags['latest_run_number']    = null !== $log ? $log['run_number'] : null;
		$flags['can_edit']             = null === $log
			? true
			: ! in_array( $log['completed'], self::RUNNING_STATUSES, true );

		return $flags;
	}

	/**
	 * Whether the recipe has any run-now-style trigger.
	 *
	 * @param int $recipe_id Recipe ID.
	 *
	 * @return bool
	 */
	private function is_run_now_recipe( int $recipe_id ): bool {
		return automator_recipe_has_manual_trigger( $recipe_id );
	}
}
