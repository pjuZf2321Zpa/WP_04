<?php
declare( strict_types=1 );

namespace Uncanny_Automator_Pro\App\Run_Now;

/**
 * Wires the Run Now recipe state-flags reporter onto Free's
 * `automator_recipe_state_flags` filter.
 *
 * The Pro-tier analogue of the Recipe_Runner Blocks bootstrap — invoked
 * (guarded) from `src/boot.php`. Kept thin: registration only.
 */
final class Bootstrap {

	/**
	 * Register the state-flags reporter.
	 *
	 * @return void
	 */
	public static function register_all(): void {

		$reporter = new Recipe_State_Flags();

		add_filter( 'automator_recipe_state_flags', array( $reporter, 'report' ), 10, 2 );
	}
}
