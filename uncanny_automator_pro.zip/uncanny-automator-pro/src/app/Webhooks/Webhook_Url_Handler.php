<?php
/**
 * Webhook URL handler for webhook-type triggers.
 *
 * Owns the full lifecycle of auto-generated inbound webhook URLs in Pro:
 * - the canonical receive-webhook trigger family ({@see self::TRIGGER_FAMILY}),
 * - the URL construction itself,
 * - persistence of the `WEBHOOK_URL` post meta after a trigger save,
 * - triggering a webhook route index rebuild,
 * - enriching the Core API trigger-save response with `webhook_url` +
 *   `webhook_note` so the MCP save_trigger tool can surface them without
 *   knowing anything about webhooks.
 *
 * This class is the single source of truth for "is this trigger a webhook
 * trigger?" and "what is its inbound URL?" The core plugin fires
 * `automator_event_recipe_changed` after every trigger write and filters the
 * trigger CRUD response through `automator_trigger_response`; this handler
 * listens on both. Core stays oblivious to webhooks.
 *
 * @package Uncanny_Automator_Pro
 */

declare(strict_types=1);

namespace Uncanny_Automator_Pro\App\Webhooks;

use Uncanny_Automator\App\Events\Enums\Recipe_Change_Operation;
use Uncanny_Automator\App\Infrastructure\Database\Database;

/**
 * Webhook_Url_Handler
 *
 * @since 7.2.0
 */
class Webhook_Url_Handler {

	/**
	 * The receive-webhook trigger family — every trigger rendering the
	 * shared webhook options group (`Webhook_Common_Options`), keyed
	 * integration code => trigger code. The URL allowlist derives from the
	 * values; the node-tests bootstrap registers a provider per entry.
	 * Hardcoded because both consumers must answer without depending on
	 * which integrations demand loading constructed;
	 * Receive_Webhook_Family_Census_Test pins it to the trigger files.
	 *
	 * @var array<string, string>
	 */
	public const TRIGGER_FAMILY = array(
		'WEBHOOKS'      => 'WP_ANON_WEBHOOKS',
		'ZAPIER'        => 'ANON_ZAPIERWEBHOOKS',
		'MAKE'          => 'ANON_MAKE_WEBHOOKS',
		'INTEGROMAT'    => 'ANON_INTEGROMATWEBHOOKS',
		'INTEGRATELY'   => 'ANON_INTEGRATELYWEBHOOKS',
		'IFTTT'         => 'ANON_IFTTTWEBHOOKS',
		'KONNECTZ_IT'   => 'ANON_KONNECTZ_IT_WEBHOOKS',
		'TYPEFORM'      => 'ANON_TYPEFORM_WEBHOOKS',
		'THRIVECART'    => 'ANON_THRIVECART_WEBHOOKS',
		'OPTINMONSTER'  => 'ANON_OPTINMONSTERWEBHOOKS',
		'GOOGLE_SHEETS' => 'ANON_GOOGLE_SHEETSWEBHOOKS',
	);

	/**
	 * Per-instance memo of the resolved webhook trigger code allowlist.
	 *
	 * Within a single trigger save, both `store_url` and `enrich_response`
	 * call `generate_url()`, which calls `get_webhook_trigger_codes()`. Without
	 * memoization, the `automator_mcp_webhook_trigger_codes` filter would fire
	 * twice per save. Cache the filtered result once — filters are registered
	 * at boot and stable within a request.
	 *
	 * @var string[]|null
	 */
	private $cached_codes = null;

	/**
	 * Register listeners on the recipe change event and the trigger CRUD
	 * response filter exposed by the core plugin.
	 */
	public function __construct() {

		// Side effect after trigger persistence: store the URL, rebuild the index. A copied
		// trigger reports trigger_created too, so it gets its own URL.
		add_action( 'automator_event_trigger_created', array( $this, 'store_url' ) );
		add_action( 'automator_event_trigger_updated', array( $this, 'store_url' ) );

		// Response enrichment: inject `webhook_url` + `webhook_note` into the
		// trigger payload so the tool layer passes them through for free.
		add_filter( 'automator_trigger_response', array( $this, 'enrich_response' ), 10, 4 );
	}

	/**
	 * Persist the webhook URL and request an index rebuild when a trigger is added,
	 * or when an edit finds the URL missing or wrong.
	 *
	 * Listens to `automator_event_trigger_created` and `automator_event_trigger_updated`,
	 * so builder, MCP and automator_*() saves alike reach it. An added trigger always
	 * gets its own URL: a copied one arrives carrying the original's. An edit writes it
	 * only when the stored URL is not this trigger's, which heals a legacy or imported
	 * trigger without one and a copy that still carries another recipe's URL.
	 *
	 * @since 8.0.0
	 *
	 * @param object $change The trigger_created or trigger_updated payload.
	 * @return void
	 */
	public function store_url( $change ): void {

		$change        = $change->to_array();
		$trigger_id    = (int) $change['item_id'];
		$trigger_store = Database::get_recipe_trigger_store();

		$url = $this->generate_url( (int) $change['recipe_id'], $trigger_id, (string) $trigger_store->get_meta( $trigger_id, 'code' ) );
		if ( null === $url ) {
			return;
		}

		if ( Recipe_Change_Operation::CREATED !== $change['operation'] && $url === (string) $trigger_store->get_meta( $trigger_id, 'WEBHOOK_URL' ) ) {
			return;
		}

		$trigger_store->update_meta( $trigger_id, 'WEBHOOK_URL', $url );

		// The Webhook_Index listener in this same package handles the rebuild.
		do_action( 'automator_webhook_index_rebuild' );
	}

	/**
	 * Inject `webhook_url` and `webhook_note` into the trigger CRUD response
	 * shape so the MCP save_trigger tool returns them transparently.
	 *
	 * @param array  $response     Response array from the core CRUD service.
	 * @param int    $recipe_id    Recipe post ID.
	 * @param int    $trigger_id   Trigger post ID.
	 * @param string $trigger_code Trigger code.
	 * @return array Possibly enriched response.
	 */
	public function enrich_response( $response, int $recipe_id, int $trigger_id, string $trigger_code ) {

		if ( ! is_array( $response ) ) {
			return $response;
		}

		$url = $this->generate_url( $recipe_id, $trigger_id, $trigger_code );
		if ( null === $url ) {
			return $response;
		}

		if ( ! isset( $response['trigger'] ) || ! is_array( $response['trigger'] ) ) {
			return $response;
		}

		$response['trigger']['webhook_url']  = $url;
		$response['trigger']['webhook_note'] = 'This webhook URL becomes active after both trigger and recipe are published. Publish the trigger (save_trigger with status=publish) and recipe (save_recipe with status=publish) to activate.';

		// The trigger "add" path exposes a configuration sub-array; surface the
		// URL there too for callers that read it from the trigger configuration.
		if ( isset( $response['trigger']['configuration'] ) && is_array( $response['trigger']['configuration'] ) ) {
			$response['trigger']['configuration']['WEBHOOK_URL'] = $url;
		}

		return $response;
	}

	/**
	 * Build the deterministic inbound webhook URL for a trigger.
	 *
	 * @param int    $recipe_id    Recipe post ID.
	 * @param int    $trigger_id   Trigger post ID.
	 * @param string $trigger_code Trigger code.
	 * @return string|null URL, or null if this is not a webhook trigger.
	 */
	private function generate_url( int $recipe_id, int $trigger_id, string $trigger_code ): ?string {

		if ( ! in_array( $trigger_code, $this->get_webhook_trigger_codes(), true ) ) {
			return null;
		}

		if ( $recipe_id <= 0 || $trigger_id <= 0 ) {
			return null;
		}

		$prefix = function_exists( 'automator_pro_get_webhook_route_prefix' )
			? automator_pro_get_webhook_route_prefix()
			: 'uap';

		$endpoint = defined( 'AUTOMATOR_REST_API_END_POINT' )
			? AUTOMATOR_REST_API_END_POINT
			: 'uap/v2';

		return sprintf( '%s%s/%s-%d-%d', get_rest_url(), $endpoint, $prefix, $recipe_id, $trigger_id );
	}

	/**
	 * Get trigger codes that receive an auto-generated inbound webhook URL.
	 *
	 * Derived from {@see self::TRIGGER_FAMILY}; memoized per-instance — see
	 * `$cached_codes` for rationale.
	 *
	 * @return string[] Trigger codes.
	 */
	private function get_webhook_trigger_codes(): array {

		if ( null !== $this->cached_codes ) {
			return $this->cached_codes;
		}

		/**
		 * Filter the list of trigger codes that receive auto-generated webhook URLs.
		 *
		 * Third-party integrations that register webhook triggers can add their
		 * trigger codes here so the MCP server returns the inbound URL on creation.
		 *
		 * @param string[] $codes Webhook trigger codes.
		 */
		$this->cached_codes = apply_filters( 'automator_mcp_webhook_trigger_codes', array_values( self::TRIGGER_FAMILY ) );

		return $this->cached_codes;
	}
}
