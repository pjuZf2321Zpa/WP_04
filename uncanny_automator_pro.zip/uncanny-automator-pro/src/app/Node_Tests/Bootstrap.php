<?php
declare(strict_types=1);
namespace Uncanny_Automator_Pro\App\Node_Tests;

use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Registry\Node_Tests_Registry;
use Uncanny_Automator_Pro\App\Webhooks\Webhook_Url_Handler;

/**
 * Registers Pro's node-test providers into Free's registry (Rule 14:
 * Pro plugs into Free's shared static registries from its own bootstrap).
 * Called from the automator_node_tests_register hook, not directly.
 */
final class Bootstrap {

	/**
	 * Register every Pro node-test provider, lazily (class-string —
	 * autoload-cold, matches Free's own registration). The receive-webhook
	 * provider registers once per family identity — the family list lives
	 * on its SSoT ({@see Webhook_Url_Handler::TRIGGER_FAMILY}, census-pinned).
	 *
	 * @return void
	 */
	public static function register_all(): void {
		foreach ( Webhook_Url_Handler::TRIGGER_FAMILY as $integration_code => $trigger_code ) {
			Node_Tests_Registry::register_class( Receive_Webhook_Tests_Provider::class, 'item', $integration_code, $trigger_code );
		}

		Node_Tests_Registry::register_class( Capture_Hook_Tests_Provider::class, 'item', 'ADD_ACTION', 'ADD_ACTION_TRIGGER_CODE' );
	}
}
