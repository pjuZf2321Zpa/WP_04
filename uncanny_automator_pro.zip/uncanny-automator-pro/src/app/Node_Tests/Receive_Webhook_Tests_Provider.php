<?php
declare(strict_types=1);
namespace Uncanny_Automator_Pro\App\Node_Tests;

use Uncanny_Automator\App\Infrastructure\Database\Stores\WP_Recipe_Store;
use Uncanny_Automator\App\Infrastructure\Database\Stores\WP_Recipe_Trigger_Store;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Node_Test_Context;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Node_Test_Provider;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Services\Field_Values_Flattener;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Value_Objects\Node_Test;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Value_Objects\Run_Result;
use Uncanny_Automator_Pro\Webhook_Rest_Sample_Handler;

/**
 * Receive-webhook launch test: arm the existing Pro sample listener, poll
 * for a capture, render the sample as a markdown table. Serves the whole
 * receive-webhook family — the bootstrap registers this class once per
 * family identity ({@see Bootstrap::RECEIVE_WEBHOOK_FAMILY}); every member
 * renders the same shared options group and the route key derives from
 * recipe/trigger ids, so execution is identity-agnostic. The identity
 * methods below return the canonical WEBHOOKS/WP_ANON_WEBHOOKS pair, used
 * only by instance-based registration.
 *
 * Draft gate is a PER-PROVIDER fact (spec Stage 5): the live route and the
 * catch route register the same REST path, and Webhook_Index only registers
 * the live route when BOTH the recipe and trigger posts are publish — so
 * that is the exact (and only) state the gate refuses; either post in any
 * other status means the catch route has the path to itself (spec §11,
 * closed). Cancel results are never persisted by the Free service (spec D3).
 */
final class Receive_Webhook_Tests_Provider implements Node_Test_Provider {

	/**
	 * The node kind.
	 *
	 * @return string
	 */
	public function kind(): string {
		return 'item';
	}

	/**
	 * The owning integration.
	 *
	 * @return string
	 */
	public function integration_code(): string {
		return 'WEBHOOKS';
	}

	/**
	 * The trigger code.
	 *
	 * @return string
	 */
	public function code(): string {
		return 'WP_ANON_WEBHOOKS';
	}

	/**
	 * The single listen-mode launch test (§3.2 shape).
	 *
	 * @param Node_Test_Context $context Node context.
	 * @return Node_Test[]
	 */
	public function get_tests( Node_Test_Context $context ): array {
		return array(
			new Node_Test(
				array(
					'id'           => 'receive-webhook',
					'name'         => esc_html_x( 'Receive a webhook', 'Node tests', 'uncanny-automator-pro' ),
					'description'  => esc_html_x( 'Send a request to the webhook URL above to capture a sample. The recipe must be off while listening.', 'Node tests', 'uncanny-automator-pro' ),
					'required'     => true,
					'run_mode'     => 'listen',
					'button_label' => esc_html_x( 'Listen for webhook', 'Node tests', 'uncanny-automator-pro' ),
					'fields'       => array(),
					'poll'         => array(
						'interval_ms' => 1000,
						'timeout_ms'  => 60000,
					),
				)
			),
		);
	}

	/**
	 * Arm the sample listener (or fail with the recipe-off copy).
	 *
	 * @param string            $test_id     Test id.
	 * @param array             $node_values FieldsOutput node config (DATA_FORMAT read from here).
	 * @param array             $test_values FieldsOutput test fields (none declared).
	 * @param Node_Test_Context $context     Node context.
	 * @return Run_Result Running when armed; failed for state reasons (§8).
	 */
	public function run( string $test_id, array $node_values, array $test_values, Node_Test_Context $context ): Run_Result {
		$trigger = ( new WP_Recipe_Trigger_Store() )->get_wp_post( $context->get_node_id() );
		$recipe  = ( new WP_Recipe_Store() )->get_wp_post( $context->get_recipe_id() );

		$both_live = null !== $trigger && null !== $recipe
			&& 'publish' === $trigger->post_status
			&& 'publish' === $recipe->post_status;

		if ( null === $trigger || $both_live ) {
			return Run_Result::failed(
				esc_html_x( 'This test needs the recipe to be off.', 'Node tests', 'uncanny-automator-pro' ),
				esc_html_x( 'Switch the recipe off, then listen for test data again.', 'Node tests', 'uncanny-automator-pro' )
			);
		}

		$data_format = (string) ( Field_Values_Flattener::flatten( $node_values )['DATA_FORMAT'] ?? '' );

		Webhook_Rest_Sample_Handler::activate_listener(
			$this->route_key( $context ),
			'' !== $data_format ? $data_format : 'json'
		);

		return Run_Result::running();
	}

	/**
	 * Poll the armed listener.
	 *
	 * @param string            $test_id Test id.
	 * @param Node_Test_Context $context Node context.
	 * @return Run_Result Running until captured, then passed with the sample table.
	 */
	public function status( string $test_id, Node_Test_Context $context ): Run_Result {
		$route_key = $this->route_key( $context );
		$fields    = Webhook_Rest_Sample_Handler::get_captured_fields( $route_key );

		if ( false === $fields ) {
			return Run_Result::running();
		}

		// Capture complete — release the temporary route. WEBHOOK_SAMPLE
		// postmeta was already stamped by catch_sample_data() (token side effect).
		Webhook_Rest_Sample_Handler::deactivate_listener( $route_key );

		return Run_Result::passed(
			esc_html_x( 'A webhook was received!', 'Node tests', 'uncanny-automator-pro' ),
			$this->sample_table( (array) $fields )
		);
	}

	/**
	 * Stop listening. The Free service never persists cancel results (D3).
	 *
	 * @param string            $test_id Test id.
	 * @param string            $reason  'cancelled' or 'timed_out'.
	 * @param Node_Test_Context $context Node context.
	 * @return Run_Result
	 */
	public function cancel( string $test_id, string $reason, Node_Test_Context $context ): Run_Result {
		Webhook_Rest_Sample_Handler::deactivate_listener( $this->route_key( $context ) );

		if ( 'timed_out' === $reason ) {
			return Run_Result::failed(
				esc_html_x( 'No webhook was received within the time limit.', 'Node tests', 'uncanny-automator-pro' ),
				esc_html_x( 'Send a request to the webhook URL and try again. Any previous test result is kept.', 'Node tests', 'uncanny-automator-pro' )
			);
		}

		return Run_Result::not_run();
	}

	/**
	 * The sample listener's route key for this node.
	 *
	 * @param Node_Test_Context $context Node context.
	 * @return string
	 */
	private function route_key( Node_Test_Context $context ): string {
		return \automator_pro_get_webhook_route_prefix() . '-' . $context->get_recipe_id() . '-' . $context->get_node_id();
	}

	/**
	 * Render captured fields as a markdown table (allowed tags include table markup).
	 *
	 * Handles both leaf-row shapes ({key,type,data} arrays) and plain
	 * key => value maps; cells are pipe-escaped.
	 *
	 * @param array $fields Captured sample fields.
	 * @return string
	 */
	private function sample_table( array $fields ): string {
		$rows = array();

		foreach ( $fields as $key => $field ) {
			if ( is_array( $field ) && isset( $field['key'] ) ) {
				$rows[] = array( (string) $field['key'], (string) ( $field['data'] ?? '' ) );
				continue;
			}

			$rows[] = array( (string) $key, is_scalar( $field ) ? (string) $field : (string) wp_json_encode( $field ) );
		}

		// Cell values come from an arbitrary inbound request body. Escape the pipe so a
		// value cannot forge a column, and the backtick so it cannot close the code span
		// it is wrapped in.
		$escape = static function ( string $cell ): string {
			return str_replace( array( '|', '`' ), array( '\\|', '\\`' ), $cell );
		};

		$table = "| Key | Value |\n| --- | --- |\n";
		foreach ( $rows as $row ) {
			$table .= '| ' . $escape( $row[0] ) . ' | `' . $escape( $row[1] ) . "` |\n";
		}

		return $table;
	}
}
