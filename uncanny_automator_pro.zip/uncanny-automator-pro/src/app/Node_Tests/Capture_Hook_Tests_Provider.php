<?php
declare(strict_types=1);
namespace Uncanny_Automator_Pro\App\Node_Tests;

use Uncanny_Automator\App\Infrastructure\Database\Stores\WP_Recipe_Trigger_Store;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Node_Test_Context;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Node_Test_Provider;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Value_Objects\Node_Test;
use Uncanny_Automator\App\Recipe_Builder\Node_Tests\Value_Objects\Run_Result;
use Uncanny_Automator_Pro\Integration\Plugin_Actions\Actions\Listeners\Queries;
use Uncanny_Automator_Pro\Integrations\Plugin_Actions\Listener\Recipe_Builder_Trigger;
use Uncanny_Automator_Pro\Integrations\Plugin_Actions\Triggers\Add_Action_Trigger;
use Uncanny_Automator_Pro\Integrations\Plugin_Actions\Utils\Array_Flattener;

/**
 * ADD_ACTION/ADD_ACTION_TRIGGER_CODE launch test: arm the existing
 * hook-capture listener, poll for a fire, render the flattened hook
 * arguments as a markdown table.
 *
 * No draft gate — WP hooks are multicast, so capturing never consumes the
 * event and there is no route collision (contrast the receive-webhook
 * provider). The runtime capture reads the SAVED hook config
 * (`fetch_triggers_listening()` queries postmeta), so the test declares
 * `requires_saved_values` and the builder saves the trigger before it
 * opens the Test step; a trigger with no saved hook still gates with a
 * failed result. Unlike the legacy
 * flow, which never disarmed, terminal paths here clear the per-trigger
 * listening state and drop the autoloaded runtime flag once no trigger is
 * listening. Cancel results are never persisted by the Free service (D3).
 */
final class Capture_Hook_Tests_Provider implements Node_Test_Provider {

	/**
	 * The node kind.
	 *
	 * @return string
	 */
	public function kind(): string {
		return 'item';
	}

	/**
	 * The owning integration.
	 *
	 * @return string
	 */
	public function integration_code(): string {
		return 'ADD_ACTION';
	}

	/**
	 * The trigger code.
	 *
	 * @return string
	 */
	public function code(): string {
		return 'ADD_ACTION_TRIGGER_CODE';
	}

	/**
	 * The single listen-mode launch test.
	 *
	 * @param Node_Test_Context $context Node context.
	 * @return Node_Test[]
	 */
	public function get_tests( Node_Test_Context $context ): array {
		return array(
			new Node_Test(
				array(
					'id'                    => 'capture-hook',
					'name'                  => esc_html_x( 'Capture hook data', 'Node tests', 'uncanny-automator-pro' ),
					'description'           => esc_html_x( 'Fire the saved action hook anywhere on this site to capture its arguments as sample data.', 'Node tests', 'uncanny-automator-pro' ),
					'required'              => true,
					'run_mode'              => 'listen',
					'button_label'          => esc_html_x( 'Listen for hook', 'Node tests', 'uncanny-automator-pro' ),
					'fields'                => array(),
					'poll'                  => array(
						'interval_ms' => 1000,
						'timeout_ms'  => 60000,
					),
					// The listener reads the saved hook, so the builder must save the trigger first.
					'requires_saved_values' => true,
				)
			),
		);
	}

	/**
	 * Arm the hook-capture listener (or fail when no hook is saved).
	 *
	 * @param string            $test_id     Test id.
	 * @param array             $node_values FieldsOutput node config (unused — capture reads saved meta).
	 * @param array             $test_values FieldsOutput test fields (none declared).
	 * @param Node_Test_Context $context     Node context.
	 * @return Run_Result Running when armed; failed for state reasons (§8).
	 */
	public function run( string $test_id, array $node_values, array $test_values, Node_Test_Context $context ): Run_Result {
		$store      = new WP_Recipe_Trigger_Store();
		$saved_hook = (string) $store->get_meta( $context->get_node_id(), 'ADD_ACTION_TRIGGER_META', '' );

		if ( '' === $saved_hook ) {
			return Run_Result::failed(
				esc_html_x( 'This test needs a saved action hook.', 'Node tests', 'uncanny-automator-pro' ),
				esc_html_x( 'Enter the action hook name, save the trigger, then listen again.', 'Node tests', 'uncanny-automator-pro' )
			);
		}

		$store->update_meta( $context->get_node_id(), Recipe_Builder_Trigger::STATE_OPTION_KEY, 'listening' );
		$store->delete_meta( $context->get_node_id(), 'hook_fired_args' );
		automator_update_option( 'automator_run_hook_listening', 'yes' );

		return Run_Result::running();
	}

	/**
	 * Poll for a captured fire.
	 *
	 * @param string            $test_id Test id.
	 * @param Node_Test_Context $context Node context.
	 * @return Run_Result Running until the hook fires, then passed with the args table.
	 */
	public function status( string $test_id, Node_Test_Context $context ): Run_Result {
		$raw = (string) ( new WP_Recipe_Trigger_Store() )->get_meta( $context->get_node_id(), 'hook_fired_args', '' );

		if ( '' === $raw ) {
			return Run_Result::running();
		}

		$this->disarm( $context );

		$flattener = new Array_Flattener();
		$flattener->flatten_array( (array) json_decode( $raw, true ) );
		$flattened = $flattener->get_flattened_array();

		// Token side effect (WEBHOOK_SAMPLE parity): stamp the captured
		// argument keys as the trigger's token definitions — the legacy
		// "Use these fields" endpoint wrote this same meta; define_tokens()
		// reads it. Tokens are derived metadata, not form fields, so this
		// needs no FE involvement.
		$token_rows = array();
		foreach ( $flattened as $key => $value ) {
			$token_rows[] = array(
				'key'  => 'argument_' . $key,
				'type' => Recipe_Builder_Trigger::determine_string_type( $value ),
			);
		}
		( new WP_Recipe_Trigger_Store() )->update_meta( $context->get_node_id(), Add_Action_Trigger::CAPTURED_TOKENS_POSTMETA_KEY, $token_rows );

		return Run_Result::passed(
			esc_html_x( 'The hook fired!', 'Node tests', 'uncanny-automator-pro' ),
			$this->args_table( $flattened )
		);
	}

	/**
	 * Stop listening. The Free service never persists cancel results (D3).
	 *
	 * @param string            $test_id Test id.
	 * @param string            $reason  'cancelled' or 'timed_out'.
	 * @param Node_Test_Context $context Node context.
	 * @return Run_Result
	 */
	public function cancel( string $test_id, string $reason, Node_Test_Context $context ): Run_Result {
		$this->disarm( $context );

		if ( 'timed_out' === $reason ) {
			return Run_Result::failed(
				esc_html_x( 'The hook did not fire within the time limit.', 'Node tests', 'uncanny-automator-pro' ),
				esc_html_x( 'Fire the saved action hook and try again. Any previous test result is kept.', 'Node tests', 'uncanny-automator-pro' )
			);
		}

		return Run_Result::not_run();
	}

	/**
	 * Clear this trigger's listening state, and drop the autoloaded runtime
	 * flag once no trigger is listening — the flag gates a per-request query
	 * in `fetch_triggers_listening()`, and the legacy flow left it on forever.
	 *
	 * @param Node_Test_Context $context Node context.
	 * @return void
	 */
	private function disarm( Node_Test_Context $context ): void {
		$store = new WP_Recipe_Trigger_Store();
		$store->delete_meta( $context->get_node_id(), Recipe_Builder_Trigger::STATE_OPTION_KEY );
		$store->delete_meta( $context->get_node_id(), 'hook_fired_args' );

		if ( array() === ( new Queries() )->find_triggers_listening() ) {
			automator_update_option( 'automator_run_hook_listening', 'no' );
		}
	}

	/**
	 * Render flattened hook arguments as a markdown table, keys prefixed the
	 * same way the trigger's token hydration prefixes them; cells are
	 * pipe-escaped.
	 *
	 * @param array $flattened Flattened argument map.
	 * @return string
	 */
	private function args_table( array $flattened ): string {
		$table = "| Key | Value |\n| --- | --- |\n";

		foreach ( $flattened as $key => $value ) {
			$value  = is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value );
			$table .= '| ' . str_replace( '|', '\\|', 'argument_' . $key ) . ' | `' . str_replace( '|', '\\|', $value ) . "` |\n";
		}

		return $table;
	}
}
