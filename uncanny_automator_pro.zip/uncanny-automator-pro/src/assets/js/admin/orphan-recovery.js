/**
 * Scheduled Action Recovery admin page.
 *
 * Drives the live scan (Rescan) and restore (Run recovery) loops against the
 * orphan_recovery_scan / orphan_recovery_restore REST routes, updating the
 * bucket counts, progress bar and status line as each batch returns. No build
 * step: plain jQuery in an IIFE, runs directly in the browser. The transport is
 * wp.apiFetch, which sends the wp_rest nonce and resolves to the payload
 * directly (it rejects on a non-2xx REST response).
 */
(function ($) {
	'use strict';

	$(document).ready(function () {

		// Bail if the localized config or the page markup is missing.
		if (typeof uapOrphanRecovery === 'undefined') {
			return;
		}

		var $root = $('[data-orphan-recovery]');

		if (0 === $root.length) {
			return;
		}

		var i18n = uapOrphanRecovery.i18n || {};

		// Register the WordPress REST nonce middleware once so every apiFetch
		// request carries the X-WP-Nonce header (core validates it; the route's
		// permission callback is the capability gate).
		if (window.wp && wp.apiFetch && uapOrphanRecovery.nonce) {
			wp.apiFetch.use(wp.apiFetch.createNonceMiddleware(uapOrphanRecovery.nonce));
		}

		// Labels + one-line descriptions for the four buckets, used when the markup
		// is built client-side. Both come from the localized i18n payload, falling
		// back to English. The data keys (pending/finalized/healthy/expired) are the
		// stable hooks the markup + counts use; only the human text changed.
		// descHealthy is intentionally blank: a Healthy bucket needs no caption.
		var BUCKETS = [
			{ key: 'pending', label: i18n.pending || 'Stuck', desc: i18n.descPending || 'Queued, but the data was wiped. Actions will be restored to run on schedule.' },
			{ key: 'finalized', label: i18n.finalized || 'Failed', desc: i18n.descFinalized || 'Marked failed by the cleanup. Actions will be restored to run on schedule.' },
			{ key: 'healthy', label: i18n.healthy || 'Healthy', desc: i18n.descHealthy || '' },
			{ key: 'expired', label: i18n.expired || 'Expired', desc: i18n.descExpired || 'Over %d days overdue. Skipping.' }
		];

		// Cache the controls and live regions once.
		var $scanBtn = $root.find('[data-orphan-scan]');
		var $runBtn = $root.find('[data-orphan-run]');
		var $stopBtn = $root.find('[data-orphan-stop]');
		var $testPickBtn = $root.find('[data-orphan-test-pick]');
		var $testModeSelect = $root.find('[data-orphan-test-mode]');
		var $testCandidate = $root.find('[data-orphan-test-candidate]');
		var $testResult = $root.find('[data-orphan-test-result]');
		var $undatable = $root.find('[data-orphan-undatable]');
		var $undatableAttemptBtn = $root.find('[data-orphan-undatable-attempt]');
		var $undatableSkipBtn = $root.find('[data-orphan-undatable-skip]');
		var $progress = $root.find('[data-orphan-progress]');
		var $progressBar = $root.find('[data-orphan-progress-bar]');
		var $status = $root.find('[data-orphan-status]');

		// Loop state shared between batches.
		var stopped = false;
		var busy = false;
		// Total candidate rows for the active scan (cached from the first batch).
		var scanTotal = 0;

		/**
		 * Locale-formats an integer for display (matches PHP number_format_i18n()).
		 *
		 * @param {number|string} value
		 * @return {string}
		 */
		function nf(value) {
			var n = parseInt(value, 10) || 0;
			return n.toLocaleString();
		}

		/**
		 * Reads the user-settable grace window (in days) off the page, clamped to a
		 * sane floor. Sent with every recovery request so the chosen window is applied
		 * per AJAX call (each request is its own PHP process).
		 *
		 * @return {number}
		 */
		function graceDays() {
			var days = parseInt($root.find('[data-orphan-grace]').val(), 10);
			if (isNaN(days) || days < 0) {
				days = 45;
			}
			return days;
		}

		/**
		 * Re-renders the EXPIRED bucket's description so its "Over N days overdue…"
		 * reflects the current grace-days field. Called on load, live as the field
		 * changes, and whenever buckets are (re)built. Text-only (no .html()).
		 */
		function refreshExpiredDesc() {
			$root.find('[data-orphan-desc-expired]').text(
				format(i18n.descExpired || 'Over %d days overdue. Skipping.', [graceDays()])
			);
		}

		/**
		 * Arms the "leaving will stop the run" browser guard while a loop is active.
		 */
		function armUnloadGuard() {
			window.onbeforeunload = function () {
				return i18n.leaveWarn || 'A recovery operation is still running. Leaving this page will stop it.';
			};
		}

		/**
		 * Disarms the unload guard once a loop finishes, errors, or is stopped.
		 */
		function disarmUnloadGuard() {
			window.onbeforeunload = null;
		}

		/**
		 * Replaces printf-style "%d"/"%s" and positional "%1$d"/"%1$s" tokens with
		 * the given args. Keeps the i18n strings intact while avoiding a sprintf
		 * dependency.
		 *
		 * @param {string} template The localized template string.
		 * @param {Array}  args     Positional replacement values.
		 * @return {string}
		 */
		function format(template, args) {
			if (!template) {
				return '';
			}
			var i = 0;
			// Positional tokens first (%1$d / %1$s), then sequential (%d / %s).
			return String(template).replace(/%(\d+)\$[ds]/g, function (match, pos) {
				return args[pos - 1];
			}).replace(/%[ds]/g, function () {
				return args[i++];
			});
		}

		/**
		 * Writes a message into the aria-live status line.
		 *
		 * @param {string} message
		 */
		function setStatus(message) {
			$status.text(message);
		}

		/**
		 * Resets the live view to a clean "starting…" state at the top of a scan or
		 * run. Clears the stale test panels (candidate preview + before/after report)
		 * and the armed recover id they carried, blanks the stale recoverable summary,
		 * and re-opens the progress region with a zeroed bar and the "Scanning…" line.
		 *
		 * @param {string} startStatus The status line to seed (e.g. scanning/running).
		 */
		function resetView(startStatus) {
			// Drop the candidate preview AND its client-built "Recover this candidate"
			// button, so no stale action_log_id stays armed for the delegated handler.
			$testCandidate.empty().attr('hidden', 'hidden');
			// Drop the before/after recovery report.
			$testResult.empty().attr('hidden', 'hidden');

			// Don't leave a stale recoverable total on screen mid-operation; the buckets
			// repopulate as the first batch returns.
			$root.find('[data-orphan-summary]').text(startStatus);

			// Re-open the progress region with an open-ended, zeroed bar.
			$progress.removeAttr('hidden');
			$progressBar.attr('value', 0).attr('max', 100);
			setStatus(startStatus);
		}

		/**
		 * Toggles the controls while a loop runs to guard against double-clicks.
		 *
		 * @param {boolean} running Whether a scan/restore loop is in flight.
		 * @param {boolean} showStop Whether to surface the Stop button.
		 */
		function setBusy(running, showStop) {
			busy = running;
			$scanBtn.prop('disabled', running);
			$runBtn.prop('disabled', running);
			$testPickBtn.prop('disabled', running);
			if (running && showStop) {
				$stopBtn.removeAttr('hidden');
			} else {
				$stopBtn.attr('hidden', 'hidden');
			}
		}

		/**
		 * Ensures the buckets list exists in the DOM.
		 *
		 * On a first-ever scan the server-rendered view shows only the empty
		 * prompt, so the bucket cells are absent. We build them once (without
		 * touching the PHP view) so counts can render in place.
		 */
		function ensureBuckets() {
			if ($root.find('[data-orphan-buckets]').length > 0) {
				return;
			}
			$root.find('[data-orphan-empty]').remove();
			var $list = $('<ul class="uap-orphan-recovery__buckets" data-orphan-buckets></ul>');
			$.each(BUCKETS, function (idx, bucket) {
				var $li = $('<li></li>')
					.append($('<strong></strong>').attr('data-orphan-count', bucket.key).text('0'))
					.append($('<span></span>').text(bucket.label));
				// The expired desc carries a %d for the grace window; tag it with the
				// refresh hook and leave its text to refreshExpiredDesc() below (so it
				// always reflects the current grace-days field, not a baked-in default).
				if ('expired' === bucket.key) {
					$li.append($('<span class="uap-orphan-recovery__desc"></span>').attr('data-orphan-desc-expired', ''));
				} else if (bucket.desc) {
					// Healthy carries no desc — only append one when there is copy.
					$li.append($('<span class="uap-orphan-recovery__desc"></span>').text(bucket.desc));
				}
				$li.appendTo($list);
			});
			// Sit the buckets ahead of the actions row, with the summary just below them.
			var $anchor = $root.find('[data-orphan-actions], .uap-orphan-recovery__actions').first();
			$anchor.before($list);
			$('<p class="uap-orphan-recovery__summary" data-orphan-summary></p>').insertAfter($list);

			// The expired desc span exists now — fill it with the current grace window.
			refreshExpiredDesc();
		}

		/**
		 * Renders the four bucket counts (locale-formatted) from a scan response.
		 *
		 * The recoverable summary line is intentionally NOT updated here: while the
		 * scan is still walking batches the buckets are partial, so showing a running
		 * "N recoverable" total would be misleading. The summary is filled in once,
		 * on completion (see the scan() done handler).
		 *
		 * @param {Object} counts Keyed pending/finalized/healthy/expired.
		 */
		function renderCounts(counts) {
			counts = counts || {};
			ensureBuckets();
			$.each(BUCKETS, function (idx, bucket) {
				var value = typeof counts[bucket.key] === 'undefined' ? 0 : counts[bucket.key];
				$root.find('[data-orphan-count="' + bucket.key + '"]').text(nf(value));
			});

			// Undatable count + region: show the Attempt-now/Skip controls only when there are
			// undatable orphans (a custom/schedule token whose date couldn't be resolved).
			var undatable = parseInt(counts.undatable, 10) || 0;
			$root.find('[data-orphan-count="undatable"]').text(nf(undatable));
			if (undatable > 0) {
				$undatable.removeAttr('hidden');
			} else {
				$undatable.attr('hidden', 'hidden');
			}

			// Expired-by-mode breakdown caption (delay / schedule / custom).
			$root.find('[data-orphan-expired-modes]').text(
				format(i18n.expiredByMode, [
					nf(counts.expired_delay),
					nf(counts.expired_schedule),
					nf(counts.expired_custom)
				])
			);

			// Keep the expired desc in step with the current grace window.
			refreshExpiredDesc();
		}

		/**
		 * Updates the "recoverable / healthy / expired" summary from running counts.
		 *
		 * @param {Object} counts Keyed pending/finalized/healthy/expired.
		 */
		function renderSummary(counts) {
			counts = counts || {};
			var recoverable = (parseInt(counts.pending, 10) || 0) + (parseInt(counts.finalized, 10) || 0);
			$root.find('[data-orphan-summary]').text(
				format(i18n.summary, [nf(recoverable), nf(counts.healthy), nf(counts.expired)])
			);
		}

		/**
		 * POSTs a single batch to a recovery REST route via wp.apiFetch.
		 *
		 * Resolves to the payload directly (no .data envelope) and rejects on a
		 * non-2xx REST response. The wp_rest nonce rides along via the middleware
		 * registered at init.
		 *
		 * @param {string} route The REST route name (e.g. 'orphan_recovery_scan').
		 * @param {Object} data  The request body (last_id, grace_days, mode, …).
		 * @return {Promise}
		 */
		function restRequest(route, data) {
			return wp.apiFetch({
				path: '/' + uapOrphanRecovery.rest_namespace + '/' + route,
				method: 'POST',
				data: data
			});
		}

		/**
		 * POSTs a single scan/restore batch to a recovery REST route.
		 *
		 * @param {string} route   The REST route name.
		 * @param {number} lastId  The cursor from the previous batch.
		 * @return {Promise}
		 */
		function postBatch(route, lastId) {
			return restRequest(route, {
				last_id: lastId,
				grace_days: graceDays()
			});
		}

		/**
		 * Runs the scan loop one batch at a time, recursing while has_more.
		 *
		 * @param {number} lastId The cursor to scan from (0 to start fresh).
		 */
		function scan(lastId) {
			postBatch('orphan_recovery_scan', lastId)
				.then(function (response) {
					var data = response || {};
					var counts = data.counts || {};

					// The first batch carries the candidate total; cache it to drive
					// "Scanned N of M" and the determinate progress bar.
					if (typeof data.total !== 'undefined') {
						scanTotal = parseInt(data.total, 10) || 0;
					}

					renderCounts(counts);

					var scanned = parseInt(counts.scanned, 10) || 0;
					if (scanTotal > 0) {
						$progressBar.attr('max', scanTotal).attr('value', Math.min(scanned, scanTotal));
						setStatus(format(i18n.scannedOf, [nf(scanned), nf(scanTotal)]));
					} else {
						setStatus(format(i18n.scanned, [nf(scanned)]));
					}

					if (data.has_more) {
						scan(parseInt(data.last_id, 10) || 0);
						return;
					}

					// Scan complete: now that the buckets are final, fill the recoverable
					// summary line in place of the "Scanning…" placeholder.
					renderSummary(counts);
					var actionable = (parseInt(counts.pending, 10) || 0) + (parseInt(counts.finalized, 10) || 0);
					if (scanTotal > 0) {
						$progressBar.attr('value', scanTotal);
					}
					setBusy(false, false);
					disarmUnloadGuard();
					$runBtn.prop('disabled', actionable <= 0);
					setStatus(i18n.done);
				})
				.catch(function (error) {
					scanFailed(error);
				});
		}

		/**
		 * Surfaces a scan failure and unwinds the loop.
		 *
		 * @param {Object|null} error The rejected apiFetch error payload.
		 */
		function scanFailed(error) {
			setBusy(false, false);
			disarmUnloadGuard();
			setStatus(errorMessage(error));
		}

		/**
		 * Runs the restore loop, accumulating the tally and advancing the bar.
		 *
		 * @param {number} lastId The cursor to restore from.
		 * @param {Object} totals Accumulated restored/expired/skipped counts.
		 * @param {number} denom  Total actionable rows (progress denominator).
		 */
		function run(lastId, totals, denom) {
			if (stopped) {
				finishRun(totals, i18n.stopped);
				return;
			}

			postBatch('orphan_recovery_restore', lastId)
				.then(function (response) {
					var data = response || {};
					var tally = data.tally || {};

					totals.restored += parseInt(tally.restored, 10) || 0;
					totals.expired += parseInt(tally.expired, 10) || 0;
					totals.skipped += parseInt(tally.skipped, 10) || 0;

					// Advance the bar against the actionable denominator.
					var processed = totals.restored + totals.expired + totals.skipped;
					if (denom > 0) {
						$progressBar.attr('value', Math.min(100, Math.round((processed / denom) * 100)));
					}
					setStatus(format(i18n.totals, [totals.restored, totals.expired, totals.skipped]));

					if (data.has_more && !stopped) {
						run(parseInt(data.last_id, 10) || 0, totals, denom);
						return;
					}

					$progressBar.attr('value', 100);
					finishRun(totals, stopped ? i18n.stopped : i18n.done);
				})
				.catch(function (error) {
					finishRun(totals, errorMessage(error));
				});
		}

		/**
		 * Closes out a restore loop: restores controls and shows final totals.
		 *
		 * @param {Object} totals  Accumulated counts.
		 * @param {string} message The terminal status message.
		 */
		function finishRun(totals, message) {
			setBusy(false, false);
			disarmUnloadGuard();
			setStatus(format(i18n.totals, [totals.restored, totals.expired, totals.skipped]) + ' ' + message);
			// A run mutates the queue, so the cached counts are stale: force a rescan.
			$runBtn.prop('disabled', true);
		}

		/**
		 * Toggles the undatable bulk buttons while their loop runs.
		 *
		 * @param {boolean} running
		 */
		function setUndatableBusy(running) {
			busy = running;
			$undatableAttemptBtn.prop('disabled', running);
			$undatableSkipBtn.prop('disabled', running);
			$scanBtn.prop('disabled', running);
			$runBtn.prop('disabled', running);
			$testPickBtn.prop('disabled', running);
		}

		/**
		 * Runs the undatable bulk loop one batch at a time (mirrors the restore loop), recursing
		 * while has_more. Each batch posts orphan_recovery_undatable with the chosen mode.
		 *
		 * @param {string} mode   'attempt' | 'skip'.
		 * @param {number} lastId The cursor to process from.
		 * @param {Object} totals Accumulated attempted/skipped/passed counts.
		 */
		function runUndatable(mode, lastId, totals) {
			restRequest('orphan_recovery_undatable', {
				mode: mode,
				last_id: lastId,
				grace_days: graceDays()
			})
				.then(function (response) {
					var data = response || {};
					var tally = data.tally || {};

					totals.attempted += parseInt(tally.attempted, 10) || 0;
					totals.skipped += parseInt(tally.skipped, 10) || 0;
					totals.passed += parseInt(tally.passed, 10) || 0;

					setStatus(format(i18n.undatableTotals, [totals.attempted, totals.skipped, totals.passed]));

					if (data.has_more) {
						runUndatable(mode, parseInt(data.last_id, 10) || 0, totals);
						return;
					}

					$progressBar.attr('value', 100);
					finishUndatable(totals, (i18n.done || 'Done.') + ' ' + (i18n.rescanHint || 'Re-scan to refresh the counts.'));
				})
				.catch(function (error) {
					finishUndatable(totals, errorMessage(error));
				});
		}

		/**
		 * Closes out the undatable loop: restores controls, shows the final tally, and suggests a
		 * rescan (the queue was mutated, so the cached counts are stale).
		 *
		 * @param {Object} totals  Accumulated counts.
		 * @param {string} message The terminal status message.
		 */
		function finishUndatable(totals, message) {
			setUndatableBusy(false);
			disarmUnloadGuard();
			setStatus(format(i18n.undatableTotals, [totals.attempted, totals.skipped, totals.passed]) + ' ' + message);
			// The buckets are stale now — make the next run go through a fresh scan.
			$runBtn.prop('disabled', true);
		}

		/**
		 * Picks an error message from a rejected apiFetch error, falling back to the
		 * i18n default. A REST error body is shaped { code, message, data }, so the
		 * server-supplied message (when present) is read off error.message.
		 *
		 * @param {Object|null} error
		 * @return {string}
		 */
		function errorMessage(error) {
			if (error && error.message) {
				return error.message;
			}
			return i18n.error;
		}

		/**
		 * Builds one "<label>: <before> → <after>" row for the test report table.
		 * Every value is written via .text() — never .html() — so server values are
		 * always treated as text.
		 *
		 * @param {string} label
		 * @param {string|number} before
		 * @param {string|number} after
		 * @return {jQuery}
		 */
		function testRow(label, before, after) {
			var $tr = $('<tr></tr>');
			$tr.append($('<th></th>').text(label));
			$tr.append($('<td></td>').text(before));
			$tr.append($('<td></td>').text(after));
			return $tr;
		}

		/**
		 * Builds the two-line user cell shown in the candidate preview and the
		 * before/after report. Line 1 is "#<id> <name>" (or just "#<id>" when the
		 * name is empty); line 2 is the email when present. A zero/negative id (no
		 * user / system run) collapses to a single line carrying the name only.
		 * Every value is written via .text() — never .html() — so server values are
		 * always treated as text.
		 *
		 * @param {string} name
		 * @param {number|string} id
		 * @param {string} email
		 * @return {jQuery} A detached fragment to drop into a <td>.
		 */
		function userCell(name, id, email) {
			var uid = parseInt(id, 10) || 0;
			var $frag = $('<span></span>');
			if (uid <= 0) {
				// No user / system run: one line with whatever name we have ("No user").
				return $frag.append($('<span class="uap-orphan-recovery__user-name"></span>').text(name || ''));
			}
			// A deleted user has no display name, so the server falls back to "User #<id>".
			// Don't prefix that with the id again ("#17 User #17") — show the name alone.
			var line1;
			if (!name || name === 'User #' + uid) {
				line1 = name || ('#' + uid);
			} else {
				line1 = '#' + uid + ' ' + name;
			}
			$frag.append($('<span class="uap-orphan-recovery__user-name"></span>').text(line1));
			if (email) {
				$frag.append($('<span class="uap-orphan-recovery__user-email"></span>').text(email));
			}
			return $frag;
		}

		/**
		 * Builds a truncating cell for a potentially-long value (e.g. an API-error
		 * dump or a long recipe title): the full text sits in a <uo-tooltip> default
		 * slot and a single-line, ellipsised <span slot="target"> shows the same
		 * text. Both go in via .text() — never .html(). An empty/null value renders
		 * a plain muted cell with no tooltip (matching the previous behaviour).
		 *
		 * @param {string|number|null} text
		 * @return {jQuery} A detached fragment to drop into a <td>.
		 */
		function truncatedCell(text) {
			var value = (null === text || typeof text === 'undefined') ? '' : String(text);
			if ('' === value) {
				return $('<span class="uap-orphan-recovery__muted"></span>').text('');
			}
			var $tooltip = $('<uo-tooltip placement="top"></uo-tooltip>').text(value);
			$tooltip.append(
				$('<span slot="target" class="uap-orphan-recovery__truncate"></span>').text(value)
			);
			return $tooltip;
		}

		/**
		 * Builds one "<label>: <before> → <after>" report row whose before/after
		 * cells each receive a jQuery fragment (rather than plain text). Used for the
		 * user cell (same identity in both columns) so the two-line markup lands
		 * inside each <td>.
		 *
		 * @param {string} label
		 * @param {jQuery} $before
		 * @param {jQuery} $after
		 * @return {jQuery}
		 */
		function testRowNodes(label, $before, $after) {
			return $('<tr></tr>')
				.append($('<th></th>').text(label))
				.append($('<td></td>').append($before))
				.append($('<td></td>').append($after));
		}

		/**
		 * Renders the read-only candidate preview (step 1): the action's current (failed)
		 * state plus a recipe-logs link, and reveals the "Recover this candidate" button
		 * carrying that exact action_log_id. Every value is written via .text()/.attr().
		 *
		 * @param {Object} candidate The candidate returned by orphan_recovery_test_pick.
		 */
		function renderCandidate(candidate) {
			candidate = candidate || {};
			$testResult.empty().attr('hidden', 'hidden');
			$testCandidate.empty().removeAttr('hidden');

			$testCandidate.append($('<p></p>').text(i18n.testInspect || "Open the recipe logs to see this action's current (failed) state, then recover."));

			var $table = $('<table class="uap-orphan-recovery__test-table widefat striped"></table>');
			var $body = $('<tbody></tbody>');
			$body.append(candidateRowNodes(i18n.user || 'User', userCell(candidate.user_name, candidate.user_id, candidate.user_email)));
			$body.append(recipeRow(i18n.recipe || 'Recipe', candidate.recipe_title, candidate.recipe_url, candidate.recipe_id, 1));
			$body.append(candidateRow('Current status', candidate.completed_label));
			// Recipe start (the immutable trigger fire time the delay math runs from), the async
			// mode, and the date this candidate WOULD run at once recovered (all computed read-only
			// on the server) — surfaced in the table so the owner sees them BEFORE recovering.
			$body.append(candidateRow(i18n.recipeStart || 'Recipe start', candidate.recipe_start_human || ''));
			$body.append(candidateRow(i18n.mode || 'Mode', candidate.async_mode || 'delay'));
			// Plain-language basis for the run time, derived per mode on the server.
			$body.append(candidateRow(i18n.schedule || 'Schedule', candidate.schedule_basis || ''));
			$body.append(candidateRow(i18n.wouldRun || 'Would run', candidate.would_run_at_human || ''));
			$table.append($body);
			$testCandidate.append($table);

			if (candidate.recipe_logs_url) {
				$testCandidate.append(
					$('<p></p>').append(viewLogsLink(candidate.recipe_logs_url, candidate.recipe_log_available))
				);
			}

			// Carry the exact id onto the recover button (step 2 recovers THIS row).
			var $recover = $('<uo-button></uo-button>')
				.attr('data-orphan-test-recover', '')
				.text(i18n.testRecover || 'Recover this candidate')
				.attr('data-action-log-id', parseInt(candidate.action_log_id, 10) || 0);
			$testCandidate.append($('<p></p>').append($recover));
		}

		/**
		 * Builds one "<label>: <value>" row for the candidate preview table.
		 *
		 * @param {string} label
		 * @param {string|number} value
		 * @return {jQuery}
		 */
		function candidateRow(label, value) {
			return $('<tr></tr>')
				.append($('<th></th>').text(label))
				.append($('<td></td>').text(value));
		}

		/**
		 * Builds one "<label>: <value>" candidate row whose value is a jQuery
		 * fragment (rather than plain text) — used for the two-line user cell.
		 *
		 * @param {string} label
		 * @param {jQuery} $value
		 * @return {jQuery}
		 */
		function candidateRowNodes(label, $value) {
			return $('<tr></tr>')
				.append($('<th></th>').text(label))
				.append($('<td></td>').append($value));
		}

		/**
		 * Builds a row whose value is the recipe title linked to its edit screen (new
		 * tab); falls back to "#<id>" text when no title/url. colspan > 1 spans the
		 * before/after columns of the result table. Link via .attr(), text via .text().
		 *
		 * @param {string} label
		 * @param {string} title
		 * @param {string} url
		 * @param {number} id
		 * @param {number} colspan
		 * @return {jQuery}
		 */
		function recipeRow(label, title, url, id, colspan) {
			var text = title || ('#' + (parseInt(id, 10) || 0));
			var $cell = $('<td></td>');
			if (colspan && colspan > 1) {
				$cell.attr('colspan', colspan);
			}
			// Wrap the visible title text in a truncating tooltip so a long title can't
			// stretch the cell; the link (when present) carries the truncated target.
			if (url) {
				var $link = $('<a target="_blank" rel="noopener noreferrer"></a>').attr('href', url);
				$link.append(
					$('<uo-tooltip placement="top"></uo-tooltip>').text(text).append(
						$('<span slot="target" class="uap-orphan-recovery__truncate"></span>').text(text)
					)
				);
				$cell.append($link);
			} else {
				$cell.append(truncatedCell(text));
			}
			return $('<tr></tr>').append($('<th></th>').text(label)).append($cell);
		}

		/**
		 * Builds the "View recipe logs" link. When the run log was purged (available === false)
		 * the link still points at the server-provided fallback URL (the filtered logs list, no
		 * dead modal) and its label gains a muted "(run log purged)" suffix. Text via .text(),
		 * URL via .attr() — never .html().
		 *
		 * @param {string}  url       The server-built recipe-logs URL.
		 * @param {boolean} available Whether the recipe-log row still exists.
		 * @return {jQuery}
		 */
		function viewLogsLink(url, available) {
			var label = i18n.viewLogs || 'View recipe logs →';
			if (false === available) {
				label += ' ' + (i18n.logPurged || '(run log purged)');
			}
			return $('<a></a>')
				.attr('href', url)
				.attr('target', '_blank')
				.attr('rel', 'noopener noreferrer')
				.text(label);
		}

		/**
		 * Renders the before→after recovery report (step 2) for the recovered candidate.
		 *
		 * @param {Object} report The report returned by orphan_recovery_test_recover.
		 */
		function renderRecoverReport(report) {
			report = report || {};
			var before = report.before || {};
			var after = report.after || {};

			// Collapse the candidate preview (table + "Recover this candidate" button):
			// once recovered there is nothing left to act on there, so only the
			// before→after "Recovered" result stays on screen.
			$testCandidate.empty().attr('hidden', 'hidden');

			$testResult.empty().removeAttr('hidden');
			$testResult.append($('<p></p>').text(i18n.testAfterNote || 'Recovered. Refresh the recipe logs to see it flip to in-progress/scheduled.'));

			var beforeLbl = i18n.before || 'Before';
			var afterLbl = i18n.after || 'After';

			var $table = $('<table class="uap-orphan-recovery__test-table widefat striped"></table>');
			var $head = $('<tr></tr>');
			$head.append($('<th></th>').text(''));
			$head.append($('<th></th>').text(beforeLbl));
			$head.append($('<th></th>').text(afterLbl));
			$table.append($('<thead></thead>').append($head));

			var $body = $('<tbody></tbody>');
			// Both Before and After show the same user, so each <td> gets its own
			// two-line fragment (a node can't live in two places at once).
			$body.append(testRowNodes(
				i18n.user || 'User',
				userCell(report.user_name, report.user_id, report.user_email),
				userCell(report.user_name, report.user_id, report.user_email)
			));
			$body.append(recipeRow(i18n.recipe || 'Recipe', report.recipe_title, report.recipe_url, report.recipe_id, 2));
			$body.append(testRow('Completed', before.completed_label, after.completed_label));
			$body.append(testRow('Async job ID', before.async_job_id, after.async_job_id));
			// The Error values can be long API dumps; truncate + hover for the full text.
			$body.append(testRowNodes(
				'Error',
				truncatedCell(before.error),
				null === after.error ? truncatedCell('(cleared)') : truncatedCell(after.error)
			));
			$body.append(testRow('Scheduled run', '', after.run_time_human));
			$table.append($body);
			$testResult.append($table);

			if (report.recipe_logs_url) {
				$testResult.append(
					$('<p></p>').append(viewLogsLink(report.recipe_logs_url, report.recipe_log_available))
				);
			}

			// Deep-link the NEW Action Scheduler job so the owner can confirm it exists. Built
			// via .attr()/.text() (never .html()) so the server-provided URL is treated as data.
			if (report.as_url) {
				$testResult.append(
					$('<p></p>').append(
						$('<a></a>').attr('href', report.as_url).attr('target', '_blank').attr('rel', 'noopener noreferrer').text(i18n.viewInAS || 'View in Action Scheduler →')
					)
				);
			}
		}

		// --- Wire up the controls. ---------------------------------------

		// Seed the EXPIRED desc from the current grace field, then keep it live as the
		// number changes (the server-rendered span starts at the default of 2).
		refreshExpiredDesc();
		$root.find('[data-orphan-grace]').on('input', refreshExpiredDesc);

		$scanBtn.on('click', function (event) {
			event.preventDefault();
			if (busy) {
				return;
			}
			stopped = false;
			scanTotal = 0;
			// Clear the stale candidate/result panels + summary and re-seed the
			// progress region (open-ended until the first batch reports the total).
			resetView(i18n.scanning);
			$runBtn.prop('disabled', true);
			setBusy(true, false);
			armUnloadGuard();
			// A true fresh scan: last_id=0 makes the server reset its running totals
			// and return the candidate "total" used for the determinate progress bar.
			scan(0);
		});

		$runBtn.on('click', function (event) {
			event.preventDefault();
			if (busy) {
				return;
			}
			if (!window.confirm(i18n.confirm)) {
				return;
			}

			// Denominator: ALL rows restore_batch walks, not just the recoverable ones.
			// The loop scans the whole in-progress + failed set (completed IN 5,2) and
			// skips healthy/expired in place — so the bar must count them too, else it
			// pins at 100% the moment the recoverable count is reached while the loop is
			// still grinding the (often larger) healthy remainder. Sum every rendered
			// bucket; strip locale grouping ("1,234") so the parse matches the figure.
			// Read BEFORE resetView() — buckets stay intact, but order keeps intent clear.
			var bucketCount = function (key) {
				return parseInt($root.find('[data-orphan-count="' + key + '"]').text().replace(/[^\d]/g, ''), 10) || 0;
			};
			var denom = bucketCount('pending') + bucketCount('finalized') + bucketCount('healthy') + bucketCount('expired');

			stopped = false;
			// Clear the stale candidate/result panels + summary and re-seed progress.
			resetView(i18n.running);
			setBusy(true, true);
			armUnloadGuard();
			run(0, { restored: 0, expired: 0, skipped: 0 }, denom);
		});

		$stopBtn.on('click', function (event) {
			event.preventDefault();
			// The loop checks this flag before issuing the next batch.
			stopped = true;
			$stopBtn.prop('disabled', true);
			disarmUnloadGuard();
			setStatus(i18n.stopped);
		});

		// Step 1 — Find a test candidate (READ-ONLY): a single quick request, no loop,
		// no unload guard. Surfaces one Failed orphan for inspection before recovery.
		$testPickBtn.on('click', function (event) {
			event.preventDefault();
			if (busy) {
				return;
			}

			$testPickBtn.prop('disabled', true);
			$testResult.empty().attr('hidden', 'hidden');
			$testCandidate.empty().attr('hidden', 'hidden');

			// Optional async-mode constraint, so the owner can hunt a schedule/custom
			// candidate instead of repeatedly landing on the dominant delay ones.
			var mode = $testModeSelect.val() || '';

			restRequest('orphan_recovery_test_pick', {
				grace_days: graceDays(),
				mode: mode
			})
				.then(function (response) {
					var candidate = (response || {}).candidate;
					if (!candidate || !candidate.action_log_id) {
						var none = mode
							? format(i18n.testNoneMode || 'No recoverable Failed %s action found. Try another mode.', [mode])
							: (i18n.testNone || 'No recoverable Failed actions found.');
						$testCandidate.empty().removeAttr('hidden').append($('<p></p>').text(none));
						return;
					}
					renderCandidate(candidate);
				})
				.catch(function (error) {
					$testCandidate.empty().removeAttr('hidden').append($('<p></p>').text(errorMessage(error)));
				})
				.finally(function () {
					$testPickBtn.prop('disabled', false);
				});
		});

		// Step 2 — Recover this candidate. The button is built client-side, so the
		// handler is delegated from the candidate region. Recovers THAT exact id.
		$testCandidate.on('click', '[data-orphan-test-recover]', function (event) {
			event.preventDefault();
			if (busy) {
				return;
			}

			var $recoverBtn = $(this);
			var id = parseInt($recoverBtn.attr('data-action-log-id'), 10) || 0;
			if (id <= 0) {
				return;
			}

			$recoverBtn.prop('disabled', true);
			$testPickBtn.prop('disabled', true);

			restRequest('orphan_recovery_test_recover', {
				action_log_id: id,
				grace_days: graceDays()
			})
				.then(function (response) {
					var report = (response || {}).report;
					if (!report || !report.ok) {
						$testResult.empty().removeAttr('hidden').append($('<p></p>').text(i18n.testInvalid || 'This action is no longer a recoverable Failed orphan. Try finding another candidate.'));
						return;
					}
					renderRecoverReport(report);
				})
				.catch(function (error) {
					$testResult.empty().removeAttr('hidden').append($('<p></p>').text(errorMessage(error)));
				})
				.finally(function () {
					$recoverBtn.prop('disabled', false);
					$testPickBtn.prop('disabled', false);
				});
		});

		/**
		 * Starts the undatable bulk loop in the chosen mode. 'attempt' confirms first (it
		 * reschedules the actions to fire shortly). Reuses the busy flag, the unload guard and
		 * the progress region.
		 *
		 * @param {string} mode 'attempt' | 'skip'.
		 */
		function startUndatable(mode) {
			if (busy) {
				return;
			}
			if ('attempt' === mode && !window.confirm(i18n.attemptConfirm)) {
				return;
			}

			stopped = false;
			// Open the progress region with an open-ended, zeroed bar and seed the status line.
			$progress.removeAttr('hidden');
			$progressBar.attr('value', 0).attr('max', 100);
			setStatus('attempt' === mode ? (i18n.running || 'Restoring…') : (i18n.scanning || 'Scanning…'));
			setUndatableBusy(true);
			armUnloadGuard();
			runUndatable(mode, 0, { attempted: 0, skipped: 0, passed: 0 });
		}

		$undatableAttemptBtn.on('click', function (event) {
			event.preventDefault();
			startUndatable('attempt');
		});

		$undatableSkipBtn.on('click', function (event) {
			event.preventDefault();
			startUndatable('skip');
		});
	});

})(jQuery);
