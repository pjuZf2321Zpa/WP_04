<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Automator_Status;
use Uncanny_Automator_Pro\App\Recipe_Runner\Blocks\Deferred_Conditions_Gate;
use Uncanny_Automator_Pro\App\Recipe_Runner\Blocks\Delay_Token_Timestamp;
use Uncanny_Automator_Pro\App\Recipe_Runner\Blocks\Filter_Evaluation;
use Uncanny_Automator_Pro\Loops\Entry_Point;
use Uncanny_Automator\Services\Action_Scheduler;

/**
 * Class Async_Actions
 * @package Uncanny_Automator
 */
class Async_Actions {

	/**
	 * Run args for token resolution, set by the orphan recovery before re-deriving a run time.
	 *
	 * @var array
	 */
	public $args = array();

	/**
	 * Every Action Scheduler hook a delayed action may be waiting on: the per-action drain and the delay block.
	 *
	 * @var string[]
	 */
	private const DELAY_HOOKS = array( 'automator_async_run_with_hash', \Uncanny_Automator_Pro\App\Recipe_Runner\Blocks\Delay_Block_Processor::RESUME_HOOK );

	/**
	 * @var array
	 */
	public $actions_and_fields = array();

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		/**
		 * Runs a scheduled action when its Action Scheduler job fires. The job carries only an
		 * option-name hash; the action payload lives in the options table under that hash.
		 */
		add_action( 'automator_async_run_with_hash', array( $this, 'run_with_hash' ) );

		/**
		 * Filter added to modify some fields during the async execution
		 */
		add_filter(
			'automator_pro_before_async_action_executed',
			array(
				$this,
				'maybe_update_parts_of_action',
			)
		);

		// Cancel scheduled actions before recipe logs are deleted.
		add_action( 'automator_before_recipe_log_deleted', array( $this, 'cancel_scheduled_actions_for_log' ), 10, 2 );
		add_action( 'automator_before_recipe_logs_cleared', array( $this, 'cancel_scheduled_actions_for_recipe' ), 10, 1 );

		// Action Scheduler throughput tuning for high-volume delayed actions.
		add_filter( 'action_scheduler_queue_runner_batch_size', array( $this, 'adjust_batch_size' ) );
		add_filter( 'action_scheduler_queue_runner_concurrent_batches', array( $this, 'adjust_concurrent_batches' ) );

		// Auto-retry failed async actions (e.g., Pro was inactive during AS execution).
		add_action( 'automator_async_retry_failed_actions', array( $this, 'maybe_retry_failed_actions' ) );

		// Orphan cleanup for stale hash records.
		add_action( 'automator_async_cleanup_orphaned_hashes', array( $this, 'cleanup_orphaned_hashes' ) );

		// One-time recovery of orphaned scheduled actions left by the pre-fix cleanup defect.
		add_action( 'automator_async_recover_orphans', array( $this, 'recover_orphaned_async_actions' ) );

		// Schedule recurring AS jobs for retry and orphan cleanup.
		add_action( 'admin_init', array( $this, 'maybe_schedule_async_jobs' ) );
	}

	/**
	 * get_timestamp
	 *
	 * This function will generate a timestamp, when an action is suposed to be scheduled.
	 *
	 * @param array $action
	 *
	 * @return int
	 */
	public function get_timestamp( $action ) {

		$async_mode = $action['action_data']['meta']['async_mode'];
		$timestamp  = current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested -- Intentional for local time comparison.

		switch ( $async_mode ) {
			case 'delay':
				$timestamp = $this->get_delay_seconds( $action );
				break;
			case 'schedule':
				$timestamp = $this->get_schedule_seconds( $action );
				break;
			case 'custom':
				$timestamp = $this->get_custom_delay( $action );
				break;
			default:
				// Do nothing
				break;
		}

		return $timestamp;
	}
	/**
	 * get_delay_seconds
	 *
	 * This fnction will translate the values from the delay UI into a timestamp.
	 *
	 * @param array $action
	 *
	 * @return int
	 */
	public function get_delay_seconds( $action ) {

		$unit       = $action['action_data']['meta']['async_delay_unit'];
		$number     = (int) $action['action_data']['meta']['async_delay_number'];
		$multiplier = 1;

		switch ( $unit ) {
			case 'minutes':
				$multiplier = 60;
				break;
			case 'hours':
				$multiplier = 60 * 60;
				break;
			case 'days':
				$multiplier = 60 * 60 * 24;
				break;
			case 'years':
				$multiplier = 60 * 60 * 24 * 365;
				break;
			default:
				// Do nothing
				break;
		}

		return time() + $number * $multiplier;
	}
	/**
	 * get_schedule_seconds
	 *
	 * This fnction will translate the values from the schedule UI into a timestamp.
	 *
	 * @param array $action
	 * @param mixed $gmt
	 *
	 * @return int
	 */
	public function get_schedule_seconds( $action ) {

		$date = trim( $action['action_data']['meta']['async_schedule_date'] );
		$time = trim( $action['action_data']['meta']['async_schedule_time'] );

		$date_format = 'Y-m-d';
		$time_format = 'g:i A';

		if ( defined( 'AUTOMATOR_PLUGIN_VERSION' ) && version_compare( AUTOMATOR_PLUGIN_VERSION, '4.1.1', '<' ) ) {
			$date_format = get_option( 'date_format' );
		}

		$date_time = \DateTime::createFromFormat( $date_format . ' ' . $time_format, $date . ' ' . $time, wp_timezone() );

		if ( ! $date_time ) {
			automator_log( \DateTime::getLastErrors(), 'DateTime::createFromFormat failed: ' );
			automator_log( $date, '$date: ' );
			automator_log( $date_format, '$date_format: ' );
			automator_log( $time, '$time: ' );
			automator_log( $time_format, '$time_format: ' );
			automator_log( wp_timezone(), 'wp_timezone(): ' );

			return time();
		}

		return $date_time->getTimestamp();
	}

	/**
	 * @param $action
	 *
	 * @return int|mixed|null
	 */
	public function get_custom_delay( $action ) {

		$custom_value = (string) ( $action['action_data']['meta']['async_custom'] ?? '' );
		$args         = is_array( $action['args'] ?? null ) ? $action['args'] : array();

		try {
			$custom_value = ( new Delay_Token_Timestamp() )->resolve( $custom_value, (int) $action['recipe_id'], (int) $action['user_id'], $args );
		} catch ( \InvalidArgumentException $e ) {
			$custom_value = $e->getMessage();
		}

		return apply_filters( 'automator_pro_async_action_custom_date_time', $custom_value, $action, $this );
	}

	/**
	 * These token return current_time('timestamp') which returns time - timezone,
	 * by this point, the timestamp is already in the past. Manually handle this situation
	 *
	 * @param string $date_string The string containing tokens to replace.
	 *
	 * @return array|string|string[]
	 */
	public function handle_timestamp_tokens( $date_string ) {
		return ( new Delay_Token_Timestamp() )->replace_timestamp_tokens( (string) $date_string );
	}


	/**
	 * @param $action_hash
	 *
	 * @return void
	 * @since v4.7
	 */
	public function run_with_hash( $action_hash ) {
		$action = automator_get_option( $action_hash );

		// Guard against double execution — if a previous run already completed
		// (e.g., AS marked the job as failed due to timeout, but the action actually
		// finished), skip re-execution and just clean up the hash.
		if ( is_array( $action ) && ! empty( $action['action_data']['action_log_id'] ) ) {
			$status = Automator()->db->action->get_action_log_completion_status( (int) $action['action_data']['action_log_id'] );
			if ( null !== $status && Automator_Status::IN_PROGRESS !== (int) $status ) {
				automator_log( 'Async action skipped — action_log_id ' . $action['action_data']['action_log_id'] . ' already has completed status ' . $status );
				automator_delete_option( $action_hash );
				delete_option( $action_hash );
				return;
			}
		}

		$this->run_execution( $action );

		automator_delete_option( $action_hash );
		delete_option( $action_hash );
	}

	/**
	 * @param $action
	 *
	 * @return void
	 */
	private function run_execution( $action ) {

		if ( ! is_array( $action ) || empty( $action['action_data'] ) || empty( $action['recipe_id'] ) ) {
			automator_log( 'Async action skipped — action data is missing or invalid.' );
			return;
		}

		$action = apply_filters( 'automator_pro_before_async_action_executed', $action );

		if ( isset( $action['process_further'] ) && false === $action['process_further'] ) {

			automator_log( 'Action was skipped by automator_pro_before_async_action_executed filter.' );

			return;
		}

		// A 7.x job whose condition group was all delayed deferred its conditions to now.
		if ( ! empty( $action['action_data']['postponing_evaluation'] ) && $this->skipped_on_deferred_conditions( $action ) ) {
			return;
		}

		$action_id   = $action['action_data']['ID'];
		$recipe_id   = $action['recipe_id'];
		$action_post = get_post( $action_id );
		$recipe_post = get_post( $recipe_id );

		// If action or recipe no longer exists
		if ( empty( $action_post ) || empty( $recipe_post ) || ! $action_post instanceof \WP_Post || ! $recipe_post instanceof \WP_Post ) {
			$this->recipe_or_action_no_longer_exists( $action );

			return;
		}

		// If action or recipe is set to draft
		if ( 'publish' !== $action_post->post_status || 'publish' !== $recipe_post->post_status ) {
			$this->recipe_or_action_is_not_live( $action );

			return;
		}

		$action_code = $action['action_data']['meta']['code'];

		$action_execution_function = Automator()->get->action_execution_function_from_action_code( $action_code );

		$action['action_data']['async']['status']       = 'completed';
		$action['action_data']['async']['completed_at'] = current_time( 'timestamp' ); //phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested

		if ( isset( $action['process_further'] ) ) {
			unset( $action['process_further'] );
		}

		if ( empty( $action_execution_function ) ) {
			$this->missing_execution_function( $action );
			return;
		}

		try {

			call_user_func_array( $action_execution_function, $action );

			do_action( 'automator_pro_async_action_after_run_execution', $action );
		} catch ( \Error $e ) {
			$this->complete_with_error( $action, $e->getMessage() );
			return;
		} catch ( \Exception $e ) {
			$this->complete_with_error( $action, $e->getMessage() );
			return;
		}

		$this->finalize_run( $action );
	}

	/**
	 * Close the job's run when nothing in it still waits. Completing an action does not, and a run left
	 * open does not count against the recipe's run limits or report `automator_recipe_completed`.
	 *
	 * @since 8.0.0
	 *
	 * @param array $action The job's payload.
	 *
	 * @return void
	 */
	private function finalize_run( $action ) {
		$recipe_log_id = $action['action_data']['recipe_log_id'] ?? ( $action['args']['recipe_log_id'] ?? 0 );

		if ( 0 === absint( $recipe_log_id ) ) {
			return;
		}

		Automator()->recipe_runner->finalize_recipe(
			absint( $action['recipe_id'] ),
			absint( $action['user_id'] ),
			absint( $recipe_log_id ),
			$action['args'] ?? array()
		);
	}

	/**
	 * Evaluate the conditions a Pro 7.x job deferred to its run time, and skip its action when they keep it from running.
	 *
	 * 7.x evaluated a condition group whose actions were all delayed when each job ran (Pro v7.7.0
	 * actions-conditions.php:546-563). The 8.0 migration moved the group into a filter block, so the
	 * filter blocks that now hold the action are evaluated, every time a job runs.
	 *
	 * @since 8.0.0
	 *
	 * @param array $action The job's payload.
	 *
	 * @return bool True when the action was skipped.
	 * @throws \Throwable When the recipe tree cannot be read; the payload stays for the retry cron.
	 */
	private function skipped_on_deferred_conditions( $action ) {
		$evaluation = ( new Deferred_Conditions_Gate() )->blocking_evaluation(
			absint( $action['recipe_id'] ),
			absint( $action['user_id'] ?? 0 ),
			absint( $action['action_data']['recipe_log_id'] ?? 0 ),
			absint( $action['action_data']['ID'] ?? 0 ),
			is_array( $action['args'] ?? null ) ? $action['args'] : array()
		);

		if ( null === $evaluation ) {
			return false;
		}

		$this->mark_skipped_on_conditions( $action, $evaluation );

		return true;
	}

	/**
	 * Record a job's action as skipped by its conditions, as Pro 7.x did (v7.7.0 actions-conditions.php:1148-1156):
	 * the action's row takes the skipped status with the failed conditions' messages, `uap_action_completed`
	 * fires, and the run is finalized. In loop scope the action's record is the entity's entry item, which takes
	 * the skipped status as Filter_Block_Processor records an untaken path.
	 *
	 * @since 8.0.0
	 *
	 * @param array             $action     The job's payload.
	 * @param Filter_Evaluation $evaluation The evaluation that keeps the action from running.
	 *
	 * @return void
	 */
	private function mark_skipped_on_conditions( $action, Filter_Evaluation $evaluation ) {
		$recipe_id     = absint( $action['recipe_id'] );
		$user_id       = absint( $action['user_id'] ?? 0 );
		$action_id     = absint( $action['action_data']['ID'] );
		$recipe_log_id = absint( $action['action_data']['recipe_log_id'] ?? 0 );
		$args          = is_array( $action['args'] ?? null ) ? $action['args'] : array();

		// Each message on its own line, as 7.x's extract_errors() joined them.
		$message = '';
		foreach ( $evaluation->failure_messages() as $failure_message ) {
			$message .= $failure_message . "\n";
		}

		$args['user_action_message'] = $message;

		Automator()->recipe_runner->complete_action( $action_id, $recipe_log_id, Automator_Status::SKIPPED, $message );

		do_action( 'uap_action_completed', $user_id, $action_id, $recipe_id, $message, $args );

		if ( isset( $args['loop'] ) && is_array( $args['loop'] ) ) {
			Entry_Point::get_instance()->skip_entry_item( absint( $args['loop']['user_id'] ?? 0 ), absint( $args['loop']['entity_id'] ?? 0 ), $action_id, (array) ( $args['loop']['loop_item'] ?? array() ) );
		}

		Automator()->recipe_runner->finalize_recipe( $recipe_id, $user_id, $recipe_log_id, $args );
	}

	/**
	 * @param $action
	 * @param $error
	 *
	 * @return void
	 */
	public function complete_with_error( $action, $error = '' ) {

		if ( ! is_array( $action ) || empty( $action['recipe_id'] ) || empty( $action['action_data'] ) ) {
			automator_log( 'Async action complete_with_error skipped — action data is missing or invalid.' );
			return;
		}

		$recipe_id = $action['recipe_id'];
		$user_id   = $action['user_id'];

		$action['action_data']['complete_with_errors'] = true;

		Automator()->complete->action( $user_id, $action['action_data'], $recipe_id, $error );

		$this->finalize_run( $action );
	}

	/**
	 * missing_execution_function
	 *
	 * @param array $action
	 *
	 * @return void
	 */
	public function missing_execution_function( $action ) {

		$error = esc_html_x( 'Action is missing or the integration plugin is deactivated.', 'Async action error', 'uncanny-automator-pro' );

		automator_log( $error );

		$this->complete_with_error( $action, $error );
	}

	/**
	 * @param $action
	 *
	 * @return void
	 */
	public function recipe_or_action_is_not_live( $action ) {
		$error = esc_html_x( 'The associated recipe or action is not live.', 'Async action error', 'uncanny-automator-pro' );

		automator_log( $error, '$error', AUTOMATOR_DEBUG_MODE, 'recipe_or_action_is_not_live' );
		automator_log( $action, '$action', AUTOMATOR_DEBUG_MODE, 'recipe_or_action_is_not_live' );

		$this->complete_with_error( $action, $error );
	}

	/**
	 * @param $action
	 *
	 * @return void
	 */
	public function recipe_or_action_no_longer_exists( $action ) {

		$error = esc_html_x( 'The associated recipe or action is no longer available.', 'Async action error', 'uncanny-automator-pro' );

		automator_log( $error, '$error', AUTOMATOR_DEBUG_MODE, 'recipe_or_action_no_longer_exists' );
		automator_log( $action, '$action', AUTOMATOR_DEBUG_MODE, 'recipe_or_action_no_longer_exists' );

		$this->complete_with_error( $action, $error );
	}

	/**
	 * Function to modify parts of the action
	 *
	 * @param $action
	 *
	 * @return array|mixed
	 * @since 5.0
	 */
	public function maybe_update_parts_of_action( $action ) {
		// Filter to allow users to not update fields
		if ( false === apply_filters( 'automator_pro_update_async_action_fields', true, $action ) ) {
			return $action;
		}

		// Find action code
		$action_code = $this->get_action_code_from_action( $action );
		if ( empty( $action_code ) ) {
			return $action;
		}

		// Is action modifiable during delayed execution?
		if ( false === $this->is_modifiable_action( $action_code ) ) {
			return $action;
		}

		// Modify fields and return action
		return $this->fetch_updated_fields( $action_code, $action );
	}

	/**
	 * Get action code from the $action
	 *
	 * @param $action
	 *
	 * @return mixed|string
	 * @since 5.0
	 */
	public function get_action_code_from_action( $action ) {
		if ( ! isset( $action['action_data'] ) || ! isset( $action['action_data']['meta'] ) || ! isset( $action['action_data']['meta']['code'] ) ) {
			return '';
		}

		return $action['action_data']['meta']['code'];
	}

	/**
	 * Validate if action can be modified
	 *
	 * @param $action_code
	 *
	 * @return bool
	 * @since 5.0
	 */
	public function is_modifiable_action( $action_code ) {

		// Add a filter to include more action_code => fields
		$this->actions_and_fields = apply_filters(
			'automator_pro_maybe_update_action_fields',
			array(
				'SENDEMAIL' => array(
					'EMAILFROM',
					'EMAILFROMNAME',
					'EMAILTO',
					'REPLYTO',
					'EMAILCC',
					'EMAILBCC',
					'EMAILSUBJECT',
					'EMAILBODY',
				),
			)
		);

		return array_key_exists( $action_code, $this->actions_and_fields );
	}

	/**
	 * Function to modify the value and fetch updated content from the action meta
	 *
	 * @param $action_code
	 * @param $action
	 *
	 * @return array
	 * @since 5.0
	 */
	public function fetch_updated_fields( $action_code, $action ) {

		// Action ID
		$action_id = absint( $action['action_data']['ID'] );

		foreach ( $action['action_data']['meta'] as $key => $value ) {
			if ( ! in_array( $key, $this->actions_and_fields[ $action_code ], true ) ) {
				continue;
			}

			// Fetch new value from the action meta
			$new_value = get_post_meta( $action_id, $key, true );

			// Update existing value with the new value
			$action['action_data']['meta'][ $key ] = apply_filters( 'automator_pro_async_action_updated_field_value', $new_value, $key, $action_code, $action_id, $action );

			// Store the old value, just-in-case
			$action['action_data']['meta'][ $key . '_scheduled_value' ] = $value;
		}

		return $action;
	}

	/**
	 * @param $input
	 *
	 * @return string
	 */
	public function parse_date_time_string( $input ) {
		try {
			return ( new Delay_Token_Timestamp() )->to_timestamp( (string) $input );
		} catch ( \InvalidArgumentException $e ) {
			return $e->getMessage();
		}
	}

	/**
	 * @param $input
	 *
	 * @return string
	 */
	public function simplifying_date_input( $input ) {
		return ( new Delay_Token_Timestamp() )->simplify( (string) $input );
	}

	/**
	 * get_upcoming_jobs_for_user
	 *
	 * @param  mixed $user_id
	 * @return mixed
	 */
	public static function get_upcoming_jobs_for_user( $user_id ) {

		global $wpdb;

		$output = array();

		$results = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, automator_action_id, automator_recipe_id, automator_recipe_log_id
				FROM {$wpdb->prefix}uap_action_log
				WHERE user_id = %d
				AND completed = %d",
				$user_id,
				Automator_Status::IN_PROGRESS
			),
			ARRAY_A
		);

		foreach ( $results as $action_run ) {
			$output[] = array(
				'action_log_id' => (int) $action_run['ID'],
				'async_job_id'  => (int) Automator()->db->action->get_meta( $action_run['ID'], 'async_job_id' ),
				'action_id'     => (int) $action_run['automator_action_id'],
				'recipe_id'     => (int) $action_run['automator_recipe_id'],
				'recipe_log_id' => (int) $action_run['automator_recipe_log_id'],
			);
		}

		return $output;
	}

	/**
	 * @param $action_log_id
	 * @param $action_id
	 *
	 * @return string|null
	 */
	private static function get_recipe_log_id( $action_log_id, $action_id ) {
		global $wpdb;
		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT `automator_recipe_log_id`
				FROM {$wpdb->prefix}uap_action_log
				WHERE ID = %d
				AND automator_action_id = %d
				LIMIT 0, 1",
				$action_log_id,
				$action_id
			)
		);
	}

	/**
	 * cancel_job
	 *
	 * @param  mixed $action_log_id
	 * @param  mixed $action_id
	 * @param  mixed $recipe_log_id
	 *
	 * @return array
	 */
	public static function cancel_job( $action_log_id, $action_id, $recipe_log_id = '', $recipe_id = null ) {

		$response = array();

		$async_job_id = (int) Automator()->db->action->get_meta( $action_log_id, 'async_job_id' );
		$job_details  = Action_Scheduler::fetch_action( $async_job_id );

		if ( empty( $recipe_log_id ) || ! is_numeric( $recipe_log_id ) ) {
			$recipe_log_id = self::get_recipe_log_id( $action_log_id, $action_id );
		}

		$error_message = esc_html_x( 'Scheduled action was manually cancelled.', 'Async action status', 'uncanny-automator-pro' );
		if ( ! empty( wp_get_current_user() ) ) {
			$error_message = sprintf(
				// translators: %s is the email address of the user who cancelled the action.
				esc_html_x( 'Scheduled action was cancelled by %s.', 'Async action status', 'uncanny-automator-pro' ),
				wp_get_current_user()->user_email
			);
		}

		if ( null !== $recipe_id ) {
			$recipe_title  = get_the_title( $recipe_id );
			$error_message = sprintf(
				// translators: %s is the recipe title.
				esc_html_x( 'Scheduled action was cancelled by recipe: %s.', 'Async action status', 'uncanny-automator-pro' ),
				$recipe_title
			);
		}

		try {

			Action_Scheduler::cancel_action( $async_job_id );
			$response['success'] = true;

			// One job resumes every row under the delay block; cancelling it cancels them all.
			foreach ( self::action_ids_sharing_job( $async_job_id, absint( $recipe_log_id ), absint( $action_id ) ) as $shared_action_id ) {
				Automator()->recipe_runner->complete_action( $shared_action_id, absint( $recipe_log_id ), Automator_Status::CANCELLED, $error_message );
			}

			// Finalize recipe status via the pipeline proxy.
			Automator()->recipe_runner->finalize_recipe_by_log_id( absint( $recipe_log_id ) );

			if ( null !== $job_details ) {
				$job_args    = $job_details->get_args();
				$action_hash = array_shift( $job_args );

				automator_delete_option( $action_hash );
			}
		} catch ( \InvalidArgumentException $th ) {

			automator_log( 'cancel_job for action ' . $action_log_id . ' failed with the following error: ' . $th->getMessage() );
			$response['success'] = false;
			$response['error']   = $th;
		}

		return $response;
	}

	/**
	 * Every in-flight action in the run whose row carries this job id, the requested action first.
	 *
	 * @param int $async_job_id  Action Scheduler job id.
	 * @param int $recipe_log_id The run.
	 * @param int $action_id     The action the cancel was requested on.
	 *
	 * @return int[]
	 */
	private static function action_ids_sharing_job( $async_job_id, $recipe_log_id, $action_id ) {
		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT a.automator_action_id FROM {$wpdb->prefix}uap_action_log a
				 INNER JOIN {$wpdb->prefix}uap_action_log_meta m ON m.automator_action_log_id = a.ID
				 WHERE a.automator_recipe_log_id = %d AND a.completed = %d AND m.meta_key = 'async_job_id' AND m.meta_value = %s",
				$recipe_log_id,
				Automator_Status::IN_PROGRESS,
				(string) $async_job_id
			)
		);

		return array_values( array_unique( array_merge( array( (int) $action_id ), array_map( 'intval', (array) $ids ) ) ) );
	}

	/**
	 * Get scheduled actions for a recipe, optionally filtered by recipe log ID.
	 *
	 * @since 6.9
	 *
	 * @param int      $recipe_id     The recipe ID.
	 * @param int|null $recipe_log_id Optional. The recipe log ID to filter by.
	 *
	 * @return array Array of scheduled action objects with ID and automator_action_id.
	 */
	public static function get_scheduled_actions( $recipe_id, $recipe_log_id = null ) {

		global $wpdb;

		$sql = "SELECT ID, automator_action_id
				FROM {$wpdb->prefix}uap_action_log
				WHERE automator_recipe_id = %d";

		$params = array( $recipe_id );

		if ( null !== $recipe_log_id ) {
			$sql     .= ' AND automator_recipe_log_id = %d';
			$params[] = $recipe_log_id;
		}

		$sql     .= ' AND completed = %d';
		$params[] = Automator_Status::IN_PROGRESS;

		return $wpdb->get_results( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- SQL is safely built with placeholders and prepared with $params.
	}

	/**
	 * Cancel all scheduled actions for a specific recipe log before deletion.
	 *
	 * This method is called before a single recipe run log is deleted to ensure
	 * any pending Action Scheduler jobs are cancelled and cleaned up.
	 *
	 * @since 6.9
	 *
	 * @param int $recipe_id     The recipe ID.
	 * @param int $recipe_log_id The recipe log ID being deleted.
	 *
	 * @return void
	 */
	public function cancel_scheduled_actions_for_log( $recipe_id, $recipe_log_id ) {
		$scheduled_actions = self::get_scheduled_actions( $recipe_id, $recipe_log_id );
		$this->cancel_scheduled_actions( $scheduled_actions );
	}

	/**
	 * Cancel all scheduled actions for an entire recipe before logs are cleared.
	 *
	 * This method is called before all logs for a recipe are cleared to ensure
	 * any pending Action Scheduler jobs are cancelled and cleaned up.
	 *
	 * @since 6.9
	 *
	 * @param int $recipe_id The recipe ID.
	 *
	 * @return void
	 */
	public function cancel_scheduled_actions_for_recipe( $recipe_id ) {
		$scheduled_actions = self::get_scheduled_actions( $recipe_id );
		$this->cancel_scheduled_actions( $scheduled_actions );
	}

	/**
	 * Cancel a list of scheduled actions.
	 *
	 * @since 6.9
	 *
	 * @param array $scheduled_actions Array of action objects to cancel.
	 *
	 * @return void
	 */
	private function cancel_scheduled_actions( $scheduled_actions ) {

		if ( empty( $scheduled_actions ) ) {
			return;
		}

		foreach ( $scheduled_actions as $action ) {
			$async_job_id = (int) Automator()->db->action->get_meta( $action->ID, 'async_job_id' );

			if ( ! empty( $async_job_id ) ) {
				$this->cancel_action_scheduler_job( $async_job_id );
			}
		}
	}

	/**
	 * Cancel an Action Scheduler job and clean up associated data.
	 *
	 * @since 6.9
	 *
	 * @param int $async_job_id The Action Scheduler job ID.
	 *
	 * @return void
	 */
	private function cancel_action_scheduler_job( $async_job_id ) {

		if ( ! Action_Scheduler::is_available() ) {
			return;
		}

		try {
			$job = Action_Scheduler::fetch_action( $async_job_id );

			if ( null === $job ) {
				return;
			}

			// Get the hash to clean up options data. Guard against legacy
			// automator_async_run jobs whose first arg is the full action array.
			$args = $job->get_args();
			if ( ! empty( $args[0] ) && is_string( $args[0] ) ) {
				automator_delete_option( $args[0] );
			}

			// Cancel the Action Scheduler job.
			Action_Scheduler::cancel_action( $async_job_id );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Intentional silent failure.
			// Silent failure - the job may have already been executed or cancelled.
		}
	}

	/**
	 * Delete a failed Action Scheduler job by ID.
	 *
	 * Removes the job row entirely so it won't be returned by future
	 * STATUS_FAILED queries in the retry loop.
	 *
	 * @since 7.2
	 *
	 * @param int $job_id The Action Scheduler job ID.
	 *
	 * @return void
	 */
	private function delete_failed_job( $job_id ) {
		try {
			Action_Scheduler::delete_action( $job_id );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			// Job may have already been deleted or cleaned up by AS.
		}
	}

	/**
	 * Increase Action Scheduler batch size for better throughput on high-volume sites.
	 *
	 * Default AS batch size is 25. Automator increases this to 100 to process
	 * delayed/scheduled actions faster. Sites can override via the
	 * `automator_async_batch_size` filter.
	 *
	 * @since 7.1
	 *
	 * @param int $batch_size The current batch size.
	 *
	 * @return int
	 */
	public function adjust_batch_size( $batch_size ) {
		$automator_size = apply_filters( 'automator_async_batch_size', 100 );

		return max( (int) $batch_size, $automator_size );
	}

	/**
	 * Allow multiple concurrent Action Scheduler batches.
	 *
	 * Default AS concurrency is 1 batch at a time. Automator increases this to 2
	 * for parallel processing of delayed actions. Sites can override via the
	 * `automator_async_concurrent_batches` filter.
	 *
	 * @since 7.1
	 *
	 * @param int $concurrent The current concurrent batch count.
	 *
	 * @return int
	 */
	public function adjust_concurrent_batches( $concurrent ) {
		$automator_concurrent = apply_filters( 'automator_async_concurrent_batches', 2 );

		return max( (int) $concurrent, $automator_concurrent );
	}

	/**
	 * Automatically retry failed async actions.
	 *
	 * Queries Action Scheduler directly for failed `automator_async_run_with_hash` jobs,
	 * then checks if the hash payload still exists in uap_options. If so, reschedules.
	 * Throttled to run at most once per hour. Max retries per action is filterable.
	 *
	 * @since 7.1
	 *
	 * @return void
	 */
	public function maybe_retry_failed_actions() {

		if ( ! Action_Scheduler::is_available() ) {
			return;
		}

		$max_retries  = apply_filters( 'automator_async_max_retries', 3 );
		$chunk_size   = apply_filters( 'automator_async_retry_chunk_size', 50 );
		$memory_limit = function_exists( 'wp_convert_hr_to_bytes' )
			? (int) ( wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) ) * 0.8 )
			: PHP_INT_MAX;

		// Process failed jobs in chunks to handle backlogs larger than a single page.
		// Track work done per iteration to avoid an infinite loop — the AS query
		// returns the same failed jobs every time (their status isn't mutated),
		// so once no job produces useful work we must exit.
		foreach ( self::DELAY_HOOKS as $hook ) {
			do {
				$failed_jobs = Action_Scheduler::get_scheduled_actions(
					array(
						'hook'     => $hook,
						'status'   => Action_Scheduler::STATUS_FAILED,
						'per_page' => $chunk_size,
					)
				);

				if ( empty( $failed_jobs ) ) {
					break;
				}

				$fetched   = count( $failed_jobs );
				$processed = 0;

				foreach ( $failed_jobs as $job_id => $job ) {
					if ( $this->retry_failed_job( $job_id, $job, $max_retries ) ) {
						++$processed;
					}
				}

				// No jobs were retried or cleaned up — remaining jobs are stale
				// (hash already deleted, missing args, etc.). Exit to avoid infinite loop.
				if ( 0 === $processed ) {
					break;
				}

				// Bail if approaching memory limit — remaining jobs will be picked up next run.
				if ( memory_get_usage( true ) > $memory_limit ) {
					break;
				}
			} while ( $fetched >= $chunk_size );
		}
	}

	/**
	 * Retry a single failed Action Scheduler job.
	 *
	 * Extracts the hash from the AS job args, loads the action payload from uap_options,
	 * and reschedules if the payload exists and retry limit is not exhausted.
	 *
	 * @since 7.1
	 *
	 * @param int                      $job_id      The Action Scheduler job ID.
	 * @param \ActionScheduler_Action  $job         The failed AS action object.
	 * @param int                      $max_retries Maximum retry attempts allowed.
	 *
	 * @return bool True if the job was retried or permanently failed (work was done),
	 *              false if skipped (missing args, hash already cleaned up, etc.).
	 */
	private function retry_failed_job( $job_id, $job, $max_retries ) {

		$args = $job->get_args();

		if ( empty( $args[0] ) ) {
			return false;
		}

		$hash   = $args[0];
		$action = automator_get_option( $hash );

		// Hash payload must still exist — if cleaned up, the action already completed.
		if ( empty( $action ) || ! is_array( $action ) ) {
			return false;
		}

		if ( isset( $action['block_id'], $action['recipe_log_id'] ) ) {
			return $this->retry_failed_block_job( $job_id, $job, $hash, $action, $max_retries );
		}

		// Resolve the action log entry from the payload data.
		$action_id     = isset( $action['action_data']['ID'] ) ? (int) $action['action_data']['ID'] : 0;
		$recipe_log_id = isset( $action['action_data']['recipe_log_id'] ) ? (int) $action['action_data']['recipe_log_id'] : 0;

		if ( empty( $action_id ) || empty( $recipe_log_id ) ) {
			return false;
		}

		$action_log_id = $this->get_action_log_id( $action_id, $recipe_log_id );

		if ( empty( $action_log_id ) ) {
			return false;
		}

		// Check retry count.
		$retry_count = (int) Automator()->db->action->get_meta( $action_log_id, 'async_retry_count' );

		if ( $retry_count >= $max_retries ) {
			// Exhausted retries — mark as failed permanently.
			$error = sprintf(
				/* translators: %d is the number of retry attempts */
				esc_html_x(
					'Scheduled action failed after %d retry attempts.',
					'Async action status',
					'uncanny-automator-pro'
				),
				$max_retries
			);

			Automator()->recipe_runner->complete_action( absint( $action_id ), absint( $recipe_log_id ), Automator_Status::COMPLETED_WITH_ERRORS, $error );

			// Finalize recipe — retries exhausted, recipe needs final status.
			Automator()->recipe_runner->finalize_recipe_by_log_id( absint( $recipe_log_id ) );

			// Clean up the hash payload and the failed AS job.
			automator_delete_option( $hash );
			delete_option( $hash );
			$this->delete_failed_job( $job_id );

			return true;
		}

		// Remove the original failed job so it isn't picked up again on the next retry cycle.
		$this->delete_failed_job( $job_id );

		// Reschedule: 60 seconds from now to ensure Pro is fully loaded on next request.
		$hook       = 'automator_async_run_with_hash';
		$group      = apply_filters( 'automator_pro_asyc_actions_group', 'Uncanny Automator', $action );
		$new_job_id = Action_Scheduler::schedule_single_action( time() + 60, $hook, array( $hash ), $group );

		// Update the job ID reference in action log meta.
		Automator()->db->action->update_meta( $action_log_id, $action_id, 'async_job_id', $new_job_id );

		// Persist retry count — upsert to handle both first retry and subsequent retries
		// without risking duplicate rows or silent no-ops.
		$new_count = $retry_count + 1;
		$updated   = Automator()->db->action->update_meta( $action_log_id, $action_id, 'async_retry_count', $new_count );

		if ( 0 === $updated || false === $updated ) {
			Automator()->db->action->add_meta( 0, $action_log_id, $action_id, 'async_retry_count', $new_count );
		}

		return true;
	}

	/**
	 * Retry a failed delay-block job: reschedule on its own hook and count retries in the payload;
	 * when exhausted, fail every row the block was waiting on and finalize the run.
	 *
	 * @param int                     $job_id      Failed AS job id.
	 * @param \ActionScheduler_Action $job         The failed job.
	 * @param string                  $hash        Payload option name.
	 * @param array                   $payload     Delay block payload.
	 * @param int                     $max_retries Retry cap.
	 *
	 * @return bool True when work was done.
	 */
	private function retry_failed_block_job( $job_id, $job, $hash, array $payload, $max_retries ) {

		$retries       = (int) ( $payload['retries'] ?? 0 );
		$recipe_log_id = (int) $payload['recipe_log_id'];

		if ( $retries >= $max_retries ) {
			$error = sprintf(
				/* translators: %d is the number of retry attempts */
				esc_html_x( 'Delayed actions failed to resume after %d retry attempts.', 'Async action status', 'uncanny-automator-pro' ),
				$max_retries
			);
			$args = is_array( $payload['args'] ?? null ) ? $payload['args'] : array();
			$loop = is_array( $args['loop'] ?? null ) ? $args['loop'] : null;

			foreach ( (array) ( $payload['action_ids'] ?? array() ) as $action_id ) {

				// In loop scope the action owns no uap_action_log row — its state is an
				// entry item — so completing the action id settles nothing and the entity
				// stays parked forever. Delay_Block_Resume does the same on a refusal.
				if ( null !== $loop ) {
					Loops\Entry_Point::get_instance()->settle_entry_item(
						Automator_Status::COMPLETED_WITH_ERRORS,
						(int) ( $loop['user_id'] ?? 0 ),
						(int) ( $loop['entity_id'] ?? 0 ),
						(int) $action_id,
						(array) ( $loop['loop_item'] ?? array() )
					);
					continue;
				}

				Automator()->recipe_runner->complete_action( (int) $action_id, $recipe_log_id, Automator_Status::COMPLETED_WITH_ERRORS, $error );
			}

			// The args carry recipe_id, recipe_log_id and run_number; without them Pro's
			// loop status intercept bails and the run is never recomputed from its entries.
			Automator()->recipe_runner->finalize_recipe_by_log_id( $recipe_log_id, $args );
			automator_delete_option( $hash );
			delete_option( $hash );
			$this->delete_failed_job( $job_id );
			return true;
		}

		$new_job_id = (int) Action_Scheduler::schedule_single_action( time() + 60, $job->get_hook(), array( $hash ), $job->get_group() );
		if ( $new_job_id <= 0 ) {
			// The failed job stays for the next pass; nothing else moved.
			automator_log( 'Delay block retry could not be scheduled for ' . $hash );
			return false;
		}

		$this->delete_failed_job( $job_id );

		$payload['retries'] = $retries + 1;
		automator_update_option( $hash, $payload, false );

		// Every row waiting on the block follows the replacement, so cancel and orphan recovery find the live job.
		foreach ( (array) ( $payload['action_ids'] ?? array() ) as $action_id ) {
			$action_log_id = $this->get_action_log_id( (int) $action_id, $recipe_log_id );
			if ( $action_log_id > 0 ) {
				Automator()->db->action->update_meta( $action_log_id, (int) $action_id, 'async_job_id', $new_job_id );
			}
		}

		return true;
	}

	/**
	 * Get the action log ID from the action ID and recipe log ID.
	 *
	 * @since 7.1
	 *
	 * @param int $action_id     The action post ID.
	 * @param int $recipe_log_id The recipe log ID.
	 *
	 * @return int The action log ID, or 0 if not found.
	 */
	private function get_action_log_id( $action_id, $recipe_log_id ) {

		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID
				 FROM {$wpdb->prefix}uap_action_log
				 WHERE automator_action_id = %d
				 AND automator_recipe_log_id = %d
				 AND completed = %d
				 LIMIT 1",
				$action_id,
				$recipe_log_id,
				Automator_Status::IN_PROGRESS
			)
		);
	}

	/**
	 * Schedule recurring AS jobs for failed-action retry and orphan hash cleanup.
	 *
	 * @return void
	 */
	public function maybe_schedule_async_jobs() {

		// One-time orphan recovery — scheduled independently of the recurring-jobs
		// transient so it starts promptly on the upgrade that ships the fix. The
		// "checked" transient is set unconditionally to throttle the lookup: this
		// runs on every admin_init (every admin page load), and as_next_scheduled_action()
		// is a real DB query, so without the throttle it would fire on every request
		// until recovery completes. Re-checking every few minutes also re-schedules
		// the job if a batch ever dies without rescheduling itself.
		if ( false === (bool) get_option( 'automator_async_orphan_restore_done', false )
			&& false === get_transient( 'automator_async_orphan_recovery_checked' ) ) {

			set_transient( 'automator_async_orphan_recovery_checked', 1, 5 * MINUTE_IN_SECONDS );

			if ( true === (bool) apply_filters( 'automator_async_orphan_restore_enabled', false )
				&& Action_Scheduler::is_available()
				&& false === Action_Scheduler::next_scheduled_action( 'automator_async_recover_orphans' ) ) {
				Action_Scheduler::schedule_single_action( time() + MINUTE_IN_SECONDS, 'automator_async_recover_orphans', array(), 'uncanny-automator' );
			}
		}

		// Skip if we've already verified the jobs exist recently.
		if ( false !== get_transient( 'automator_async_jobs_scheduled' ) ) {
			return;
		}

		if ( false === Action_Scheduler::next_scheduled_action( 'automator_async_retry_failed_actions' ) ) {
			Action_Scheduler::schedule_recurring_action( time() + 6 * HOUR_IN_SECONDS, 6 * HOUR_IN_SECONDS, 'automator_async_retry_failed_actions', array(), 'uncanny-automator' );
		}

		if ( false === Action_Scheduler::next_scheduled_action( 'automator_async_cleanup_orphaned_hashes' ) ) {
			Action_Scheduler::schedule_recurring_action( time() + DAY_IN_SECONDS, DAY_IN_SECONDS, 'automator_async_cleanup_orphaned_hashes', array(), 'uncanny-automator' );
		}

		set_transient( 'automator_async_jobs_scheduled', 1, DAY_IN_SECONDS );
	}

	/**
	 * Clean up orphaned hash records in uap_options.
	 *
	 * When an AS job fails or is cleaned up by AS retention, the hash record in
	 * uap_options persists forever. This method finds hash records that have no
	 * corresponding pending AS job and removes them.
	 *
	 * @return void
	 */
	public function cleanup_orphaned_hashes() {

		global $wpdb;

		$uap_options_table = $wpdb->prefix . 'uap_options';

		// Find prefixed async hash records (7.2+) created by postpone().
		$prefixed = $wpdb->get_col(
			"SELECT option_name FROM {$uap_options_table} WHERE option_name LIKE 'automator\_async\_%' LIMIT 500" // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		// Legacy unprefixed MD5 hashes (pre-7.2) — bare 32-char hex strings.
		// CHAR_LENGTH + REGEXP narrows the scan; the value validation in the loop
		// below (action_data + recipe_id check) prevents accidental deletion of
		// non-Automator rows that happen to share the same key format.
		$legacy = $wpdb->get_col(
			"SELECT option_name FROM {$uap_options_table} WHERE CHAR_LENGTH(option_name) = 32 AND option_name REGEXP '^[a-f0-9]{32}$' LIMIT 500" // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		$candidates = array_merge( $prefixed, $legacy );

		if ( empty( $candidates ) ) {
			return;
		}

		// Collect all hashes from pending AS jobs so we can skip them.
		$pending_hashes = $this->get_pending_async_hashes();

		$cleaned = 0;

		foreach ( $candidates as $hash ) {
			// If this hash still has a pending/in-progress AS job, leave it alone.
			if ( isset( $pending_hashes[ $hash ] ) ) {
				continue;
			}

			// Verify the value looks like an async action record before deleting.
			$value = automator_get_option( $hash );

			$is_legacy = isset( $value['action_data'], $value['recipe_id'] );
			$is_block  = isset( $value['block_id'], $value['recipe_log_id'] );
			if ( ! is_array( $value ) || ( ! $is_legacy && ! $is_block ) ) {
				continue;
			}

			// A payload scheduled for the future has not run yet — it is a live
			// action, never an orphan. Skip it regardless of the pending-job lookup.
			// Safety net for the protection-set query ever being incomplete on a
			// large queue: a future-dated payload can never be wrongly deleted.
			//
			// A payload with no async timestamp defaults to 0, making this check a
			// no-op for it (0 > time() is false), so it stays eligible for deletion —
			// correct, because without a timestamp it is not a future-scheduled action.
			$scheduled_ts = (int) ( $value['action_data']['async']['timestamp'] ?? $value['timestamp'] ?? 0 );

			if ( $scheduled_ts > time() ) {
				continue;
			}

			automator_delete_option( $hash );
			delete_option( $hash );
			++$cleaned;
		}

		if ( $cleaned > 0 ) {
			automator_log( 'Cleaned up ' . $cleaned . ' orphaned async action hash(es).', 'async-orphan-cleanup', true, 'async-orphan-cleanup' );
		}
	}

	/**
	 * Get all hashes from pending/in-progress/failed automator_async_run_with_hash AS jobs.
	 *
	 * Includes STATUS_FAILED because those jobs are awaiting retry via
	 * maybe_retry_failed_actions(). Excluding them would let the orphan cleanup
	 * delete their hash payload, permanently stranding the action at status 5.
	 *
	 * @return array<string, true> Hash-keyed lookup array.
	 */
	private function get_pending_async_hashes() {

		$hashes = array();

		if ( ! Action_Scheduler::is_available() ) {
			return $hashes;
		}

		// Paginate over EVERY pending/running/failed job. The protection set must be
		// complete on every run — a capped lookup (the original bug) wrongly treats
		// live jobs beyond the cap as orphans and deletes their payload.
		//
		// Clamp to a minimum of 1: a filtered value of 0 or negative would make the
		// do/while below never terminate (per_page never bounds the result and the
		// offset never advances).
		$chunk_size = max( 1, (int) apply_filters( 'automator_async_cleanup_chunk_size', 1000 ) );

		foreach ( self::DELAY_HOOKS as $hook ) {
			$offset = 0;

			do {
				// Page on IDs: a job that can't be read back still fills its slot, so it can't end the paging early.
				$job_ids = Action_Scheduler::get_scheduled_actions(
					array(
						'hook'     => $hook,
						'status'   => array( Action_Scheduler::STATUS_PENDING, Action_Scheduler::STATUS_RUNNING, Action_Scheduler::STATUS_FAILED ),
						'per_page' => $chunk_size,
						'offset'   => $offset,
					),
					'ids'
				);

				$fetched = count( $job_ids );

				foreach ( $job_ids as $job_id ) {
					$job  = Action_Scheduler::fetch_action( $job_id );
					$args = null === $job ? array() : $job->get_args();
					if ( ! empty( $args[0] ) ) {
						$hashes[ $args[0] ] = true;
					}
				}

				$offset += $chunk_size;
			} while ( $fetched >= $chunk_size );
		}

		return $hashes;
	}

	/**
	 * One-time recovery of orphaned async actions left by the pre-fix cleanup defect.
	 *
	 * Runs as a self-rescheduling Action Scheduler job so the backlog is processed in
	 * throttled batches that survive timeouts. Idempotent and resumable via a stored
	 * cursor; sets a done-flag when finished. Drives the restore (off by default via
	 * `automator_async_orphan_restore_enabled`).
	 *
	 * @return void
	 */
	public function recover_orphaned_async_actions() {

		// Restore is OFF by default — an admin must opt in. Scheduling is also gated in
		// maybe_schedule_async_jobs(), so restore simply resumes if the filter is later
		// added — deliberately do NOT set the done flag here, or staying opted out would
		// permanently look "done".
		if ( true !== apply_filters( 'automator_async_orphan_restore_enabled', false ) ) {
			return;
		}

		$batch_size = max( 1, (int) apply_filters( 'automator_async_recovery_batch_size', 100 ) );
		$last_id    = (int) get_option( 'automator_async_orphan_restore_cursor', 0 );

		$result = ( new Async_Orphan_Recovery() )->restore_batch( $last_id, $batch_size );

		update_option( 'automator_async_orphan_restore_cursor', $result['last_id'], false );

		if ( $result['restored'] > 0 || $result['expired'] > 0 ) {
			automator_log( 'Async orphan restore — ' . $result['restored'] . ' restored, ' . $result['expired'] . ' expired, ' . $result['skipped'] . ' skipped.', 'async-orphan-restore', true, 'async-orphan-restore' );
		}

		// More rows remain — schedule the next batch.
		if ( $result['has_more'] ) {
			Action_Scheduler::schedule_single_action( time() + MINUTE_IN_SECONDS, 'automator_async_recover_orphans', array(), 'uncanny-automator' );
			return;
		}

		// Finished — mark done (autoloaded, so the admin_init check short-circuits
		// for free afterwards) and clear the cursor.
		update_option( 'automator_async_orphan_restore_done', 1 );
		delete_option( 'automator_async_orphan_restore_cursor' );
	}

	/**
	 * Process one batch of stuck scheduled action logs, finalizing forward orphans.
	 *
	 * A forward orphan is an action log still at IN_PROGRESS ("Scheduled") whose
	 * Action Scheduler job exists but whose payload was deleted (the cleanup defect).
	 * Such an action can never run, so its log is finalized as COMPLETED_WITH_ERRORS
	 * and the dead job is cancelled. Healthy scheduled actions (payload present) and
	 * ambiguous rows (no AS job) are left untouched.
	 *
	 * Public for the recurring AS handler and for regression coverage.
	 *
	 * @param int $last_id    Process action-log rows with ID greater than this (keyset pagination).
	 * @param int $batch_size Maximum rows to process this batch.
	 *
	 * @return array{recovered:int,last_id:int,has_more:bool}
	 */
	public function recover_orphans_batch( $last_id, $batch_size ) {

		global $wpdb;

		$batch_size = max( 1, (int) $batch_size );
		$last_id    = (int) $last_id;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, automator_action_id, automator_recipe_log_id
				FROM {$wpdb->prefix}uap_action_log
				WHERE completed = %d AND ID > %d
				ORDER BY ID ASC
				LIMIT %d",
				Automator_Status::IN_PROGRESS,
				$last_id,
				$batch_size
			)
		);

		if ( empty( $rows ) ) {
			return array(
				'recovered' => 0,
				'last_id'   => $last_id,
				'has_more'  => false,
			);
		}

		$recovered   = 0;
		$new_last_id = $last_id;

		foreach ( $rows as $row ) {
			// Advance the cursor first so a row that throws below can never stall
			// the whole recovery — the batch still makes progress past it.
			$new_last_id = (int) $row->ID;

			try {
				$async_job_id = (int) Automator()->db->action->get_meta( (int) $row->ID, 'async_job_id' );

				// Not an async-scheduled action (no job reference) — leave it alone.
				if ( empty( $async_job_id ) ) {
					continue;
				}

				// Only finalize confirmed forward orphans: the job still exists but its
				// payload is gone. Healthy actions (payload present) and rows whose job
				// has vanished entirely are intentionally left untouched.
				if ( ! $this->async_job_payload_missing( $async_job_id ) ) {
					continue;
				}

				$error = esc_html_x(
					'Scheduled action could not run — its stored data was removed by an orphan-cleanup defect and has been recovered.',
					'Async action status',
					'uncanny-automator-pro'
				);

				Automator()->recipe_runner->complete_action( (int) $row->automator_action_id, (int) $row->automator_recipe_log_id, Automator_Status::COMPLETED_WITH_ERRORS, $error );
				Automator()->recipe_runner->finalize_recipe_by_log_id( (int) $row->automator_recipe_log_id );

				// Cancel the dead job and clean up its (already-missing) option.
				$this->cancel_action_scheduler_job( $async_job_id );

				++$recovered;
			} catch ( \Throwable $e ) {
				// A single problematic row must not abort the batch or block the
				// cursor — log it and continue.
				automator_log( 'Async orphan recovery skipped action log ' . (int) $row->ID . ': ' . $e->getMessage(), 'async-orphan-recovery', true, 'async-orphan-recovery' );
			}
		}

		return array(
			'recovered' => $recovered,
			'last_id'   => $new_last_id,
			'has_more'  => count( $rows ) >= $batch_size,
		);
	}

	/**
	 * Whether an Action Scheduler job is a forward orphan: the job still exists but
	 * its stored payload has been deleted.
	 *
	 * Returns false for healthy jobs (payload present) and for jobs that no longer
	 * exist at all (ambiguous — not a confirmed orphan).
	 *
	 * @param int $async_job_id
	 *
	 * @return bool
	 */
	private function async_job_payload_missing( $async_job_id ) {

		if ( ! Action_Scheduler::is_available() ) {
			return false;
		}

		$job = Action_Scheduler::fetch_action( (int) $async_job_id );

		if ( null === $job ) {
			return false;
		}

		// Only the hash mechanism stores a deletable, string-keyed payload. Legacy
		// automator_async_run jobs carry the full action ARRAY inline as their arg,
		// so they are never hash-based forward orphans — and passing that array to
		// automator_get_option() would fatal.
		if ( ! in_array( $job->get_hook(), self::DELAY_HOOKS, true ) ) {
			return false;
		}

		$args = $job->get_args();
		$hash = isset( $args[0] ) ? $args[0] : '';

		if ( ! is_string( $hash ) || '' === $hash ) {
			return false;
		}

		$payload = automator_get_option( $hash );

		return empty( $payload );
	}
}
