<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Migrations\Migrate_Gemini_Key_Scrub;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Item_Error_Message_Query;

/**
 * Removes the Gemini API keys that loop item errors have held since 6.6.0.
 *
 * A Gemini action inside a loop stored each item's error in uap_loop_entries_items.error_message, and a
 * Gemini answer that was not JSON put the address it called there, key included. Automator's
 * Migrate_Gemini_Key_Scrub replaces each key with its marker in runs WP-Cron makes, here under Pro's own
 * migration name, batch hook and position, so Pro's table is scrubbed and recorded on its own.
 *
 * @since 8.0.0
 */
class Migrate_Loop_Gemini_Key_Scrub {

	/**
	 * Migration name, stamped in Automator's migrations option when the scrub completes.
	 *
	 * @since 8.0.0
	 *
	 * @var string
	 */
	const NAME = '80_pro_gemini_key_scrub';

	/**
	 * Batch hook.
	 *
	 * @since 8.0.0
	 *
	 * @var string
	 */
	const CRON_HOOK = 'automator_pro_gemini_key_scrub_batch';

	/**
	 * Option holding where the scrub stopped.
	 *
	 * @since 8.0.0
	 *
	 * @var string
	 */
	const CURSOR_OPTION = 'automator_pro_gemini_key_scrub_cursor';

	/**
	 * Register the scrub of the loop items.
	 *
	 * Against an Automator without Migrate_Gemini_Key_Scrub nothing is registered; the scrub starts on the
	 * first request after Automator is updated.
	 *
	 * @since 8.0.0
	 *
	 * @return Migrate_Gemini_Key_Scrub|null The registered scrub, or null when Automator has none.
	 */
	public static function register() {

		if ( ! class_exists( Migrate_Gemini_Key_Scrub::class ) ) {
			return null;
		}

		return new Migrate_Gemini_Key_Scrub(
			array( 'uap_loop_entries_items' => new Loop_Entry_Item_Error_Message_Query() ),
			self::NAME,
			self::CRON_HOOK,
			self::CURSOR_OPTION
		);
	}
}
