<?php
namespace Uncanny_Automator_Pro;

/**
 * Class BP_Notification_Display
 *
 * Makes Automator's BuddyPress/BuddyBoss notifications visible.
 *
 * BuddyPress only queries notifications whose component appears in
 * `bp_notifications_get_registered_components`, and renders their text via
 * `bp_notifications_get_notifications_for_user`. Every Automator notification
 * action — BuddyBoss and BuddyPress, single-user and group-wide, including the
 * on-screen one — writes the same `uncanny-automator` / `uncannyautomator_bdb_notification`
 * pair and stores its text in the `uo_notification_content` / `uo_notification_link`
 * notification meta, so this registration is one shared per-request concern.
 *
 * It deliberately does NOT live on an action class. `actions` is a gated directory
 * (automator_get_gated_directory_types()), so on an ordinary request no action is
 * instantiated — display registration hung off an action constructor never ran, and
 * BuddyBoss dropped our notifications from both the notifications list and the
 * on-screen toast. Nor does it belong on an integration class: Free owns the live
 * `Add_Bdb_Integration`, so Pro's never runs.
 *
 * Instead each integration's helper constructor calls register(). `helpers` is
 * ungated — Recipe_Part_Loader::load_helpers() instantiates it on every request for
 * any integration a published recipe uses — so this loads only where BuddyPress or
 * BuddyBoss is actually in play, not site-wide. That is the same seam WPForms uses
 * for its always-on token filters and AJAX endpoints.
 *
 * One consequence worth knowing: helpers are skipped for an integration no published
 * recipe uses, so a site that created notifications and has since removed every
 * BuddyPress/BuddyBoss recipe will not render those historical notifications.
 *
 * @since 7.4.1
 */
class BP_Notification_Display {

	/**
	 * BuddyPress component every Automator notification is filed under.
	 *
	 * @var string
	 */
	const COMPONENT_NAME = 'uncanny-automator';

	/**
	 * Component action every Automator notification is filed under. The `bdb`
	 * spelling is historical — the BuddyPress actions share it, so notifications
	 * created before this class stay renderable.
	 *
	 * @var string
	 */
	const COMPONENT_ACTION = 'uncannyautomator_bdb_notification';

	/**
	 * The registered instance, or null while unregistered.
	 *
	 * @var BP_Notification_Display|null
	 */
	private static $instance = null;

	/**
	 * Attaches the display filters. Reached via register() from
	 * Buddyboss_Pro_Helpers::__construct() and Buddypress_Pro_Helpers::__construct(),
	 * which Recipe_Part_Loader::load_helpers() runs on every request — see the
	 * class docblock above for why that is the seam.
	 *
	 * Attaching here rather than in register() means a bare `new self()` is enough.
	 * The guard makes a second instantiation inert, so listing the component twice or
	 * resolving content twice cannot happen.
	 */
	public function __construct() {

		if ( null !== self::$instance ) {
			return;
		}

		self::$instance = $this;

		add_filter( 'bp_notifications_get_registered_components', array( $this, 'add_component' ), 10, 2 );
		add_filter( 'bp_notifications_get_notifications_for_user', array( $this, 'filter_content' ), 10, 8 );
	}

	/**
	 * Ensure the display filters are attached. This is the entry point the
	 * integration helpers call; it exists so callers need not care whether an
	 * instance already exists.
	 *
	 * @return BP_Notification_Display The registered instance.
	 */
	public static function register() {

		if ( null === self::$instance ) {
			new self();
		}

		return self::$instance;
	}

	/**
	 * Forget the registered instance. Test seam only — filters are removed by the
	 * test's own remove_all_filters(), this clears the idempotency guard so a
	 * subsequent register() is observable.
	 *
	 * @return void
	 */
	public static function reset_for_tests() {
		self::$instance = null;
	}

	/**
	 * Register the Automator component so BuddyPress includes our notifications.
	 *
	 * @param array $component_names   Registered component names.
	 * @param array $active_components Active BuddyPress components. Unused.
	 *
	 * @return array
	 */
	public function add_component( $component_names, $active_components ) {

		$component_names = is_array( $component_names ) ? $component_names : array();

		if ( in_array( self::COMPONENT_NAME, $component_names, true ) ) {
			return $component_names;
		}

		$component_names[] = self::COMPONENT_NAME;

		return $component_names;
	}

	/**
	 * Resolve the stored text for an Automator notification.
	 *
	 * @param string $content               Existing content. Returned untouched for
	 *                                      any component that is not ours.
	 * @param int    $item_id               Notification item ID. Unused.
	 * @param int    $secondary_item_id     Notification secondary item ID. Unused.
	 * @param int    $action_item_count     Number of notifications with the same action. Unused.
	 * @param string $format                Either 'string' or 'object'.
	 * @param string $component_action_name Canonical notification action.
	 * @param string $component_name        Notification component ID. Unused.
	 * @param int    $id                    Notification ID — the meta lookup key.
	 *
	 * @return string|array A string when $format is 'string', otherwise an array of
	 *                      'text' and 'link'.
	 */
	public function filter_content( $content, $item_id, $secondary_item_id, $action_item_count, $format, $component_action_name, $component_name, $id ) {

		if ( self::COMPONENT_ACTION !== $component_action_name ) {
			return $content;
		}

		if ( ! function_exists( 'bp_notifications_get_meta' ) ) {
			return $content;
		}

		return $this->build_content(
			(string) bp_notifications_get_meta( $id, 'uo_notification_content' ),
			(string) bp_notifications_get_meta( $id, 'uo_notification_link' ),
			$format
		);
	}

	/**
	 * Build the rendered notification from its stored content and link.
	 *
	 * @param string $stored_content The `uo_notification_content` meta.
	 * @param string $link           The `uo_notification_link` meta.
	 * @param string $format         Either 'string' or 'object'.
	 *
	 * @return string|array A string when $format is 'string', otherwise an array of
	 *                      'text' and 'link'.
	 */
	public function build_content( $stored_content, $link, $format ) {

		// Two stored shapes exist and both must keep working, because live sites hold
		// rows of each:
		//
		//  - PRE-WRAPPED — bdb-sendnotification, bdb-sendonscreennotification and
		//    bp-sendnotificationtoallgroupmembers build the anchor at creation time,
		//    so the stored content already carries it.
		//  - RAW — bdb-sendnotificationtoallgroupmembers stored bare content and
		//    applied the anchor in its own render filter (at priority 100);
		//    bp-sendnotification stored bare content and never applied it at all.
		//
		// So the decision is made from the data rather than from which action created
		// the row: wrap only when a link is stored and the content is not already
		// anchored to it. That reproduces every previous path and additionally fixes
		// two defects — the nested anchors produced whenever the group action's
		// priority-100 filter was loaded alongside pre-wrapped content, and
		// bp-sendnotification's link never being applied.

		// Every previous copy returned the stored text plus the link separately here
		// and never wrapped — BuddyBoss builds its own markup from these keys.
		if ( 'object' === $format ) {
			return array(
				'text' => $stored_content,
				'link' => $link,
			);
		}

		if ( '' === (string) $link || $this->is_anchored_to( $stored_content, $link ) ) {
			return $stored_content;
		}

		return '<a href="' . esc_attr( esc_url( $link ) ) . '">' . $stored_content . '</a>';
	}

	/**
	 * Whether the stored content already carries an anchor for this link.
	 *
	 * Both conditions are required: creation-time wrapping always produces an anchor
	 * whose href is the link, so demanding both avoids re-wrapping pre-wrapped
	 * content while still linking raw content that merely happens to contain an
	 * unrelated anchor.
	 *
	 * @param string $stored_content The stored notification content.
	 * @param string $link           The stored notification link.
	 *
	 * @return bool
	 */
	private function is_anchored_to( $stored_content, $link ) {

		if ( false === strpos( $stored_content, '<a ' ) ) {
			return false;
		}

		foreach ( array( $link, esc_url( $link ), esc_attr( esc_url( $link ) ) ) as $variant ) {
			if ( '' !== (string) $variant && false !== strpos( $stored_content, $variant ) ) {
				return true;
			}
		}

		return false;
	}
}
