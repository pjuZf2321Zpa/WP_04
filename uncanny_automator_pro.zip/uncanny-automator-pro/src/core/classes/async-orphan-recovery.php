<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Automator_Status;
use Uncanny_Automator\Services\Action_Scheduler;

/**
 * Restores orphaned async actions (payload deleted by the 7.2.0 cleanup bug) by
 * reconstructing them from uap_action_log_meta.
 */
class Async_Orphan_Recovery {

	/**
	 * Rebuild a runnable $action from the surviving action-log meta.
	 *
	 * @param int $action_log_id
	 *
	 * @return array|null
	 */
	public function reconstruct_action( $action_log_id ) {

		global $wpdb;

		$log = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, user_id, automator_action_id, automator_recipe_id, automator_recipe_log_id
				FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
				$action_log_id
			)
		);

		if ( null === $log ) {
			return null;
		}

		$metas_raw = Automator()->db->action->get_meta( (int) $action_log_id, 'metas' );

		if ( empty( $metas_raw ) ) {
			return null;
		}

		$metas = maybe_unserialize( $metas_raw );

		if ( ! is_array( $metas ) ) {
			return null;
		}

		$meta = array();
		foreach ( $metas as $entry ) {
			if ( is_object( $entry ) && isset( $entry->meta_key ) ) {
				$meta[ $entry->meta_key ] = $entry->meta_value;
			}
		}

		if ( empty( $meta['code'] ) ) {
			return null;
		}

		// Orphans lost their in-memory trigger args, but the parser can re-resolve trigger
		// tokens from persisted uap_trigger_log_meta — provided $args carries the run's
		// trigger IDs. Rebuild that context from uap_trigger_log keyed by recipe_log_id.
		$args = $this->trigger_context_args( (int) $log->automator_recipe_log_id, (int) $log->automator_recipe_id, (int) $log->user_id, $meta['code'] );

		// Shape and top-level key ORDER mirror a real surviving payload (verified
		// 2026-06-17 against option automator_async_d1523d3f… / action_log 264830), because
		// run_execution() feeds $action to call_user_func_array() positionally:
		// ($user_id, $action_data, $recipe_id, $args).
		return array(
			'user_id'     => (int) $log->user_id,
			'action_data' => array(
				'ID'            => (int) $log->automator_action_id,
				'post_status'   => 'publish',
				'meta'          => $meta,
				'recipe_log_id' => (int) $log->automator_recipe_log_id,
				'completed'     => 0,
				'action_log_id' => (int) $log->ID,
				'args'          => $args,
				'async'         => array(
					'timestamp' => 0,
					'mode'      => isset( $meta['async_mode'] ) ? $meta['async_mode'] : 'delay',
					'status'    => 'waiting',
				),
			),
			'recipe_id'   => (int) $log->automator_recipe_id,
			'args'        => $args,
		);
	}

	/**
	 * Build the $action args (trigger run context) for a reconstructed orphan by
	 * looking up the recipe run's triggers from uap_trigger_log. The parser uses
	 * recipe_triggers[<trigger_id>]['trigger_log_id'] (and the top-level ids) to
	 * re-resolve trigger tokens from persisted uap_trigger_log_meta.
	 *
	 * @param int    $recipe_log_id
	 * @param int    $recipe_id
	 * @param int    $user_id
	 * @param string $code
	 *
	 * @return array
	 */
	private function trigger_context_args( $recipe_log_id, $recipe_id, $user_id, $code ) {

		global $wpdb;

		$args = array(
			'code'            => $code,
			'user_id'         => (int) $user_id,
			'recipe_id'       => (int) $recipe_id,
			'recipe_log_id'   => (int) $recipe_log_id,
			'run_number'      => 1,
			'recipe_triggers' => array(),
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, automator_trigger_id, user_id
				FROM {$wpdb->prefix}uap_trigger_log
				WHERE automator_recipe_log_id = %d
				ORDER BY ID ASC",
				$recipe_log_id
			)
		);

		foreach ( (array) $rows as $row ) {
			$trigger_id = (int) $row->automator_trigger_id;

			$args['recipe_triggers'][ $trigger_id ] = array(
				'trigger_id'     => $trigger_id,
				'trigger_log_id' => (int) $row->ID,
				'recipe_log_id'  => (int) $recipe_log_id,
				'run_number'     => 1,
				'user_id'        => (int) $row->user_id,
			);

			// First logged trigger becomes the primary top-level context.
			if ( empty( $args['trigger_id'] ) ) {
				$args['trigger_id']     = $trigger_id;
				$args['trigger_log_id'] = (int) $row->ID;
			}
		}

		return $args;
	}

	/**
	 * @return int Grace window in seconds (default 45 days; the UI lets the admin set any value).
	 */
	private function recovery_grace_window() {
		return (int) apply_filters( 'automator_orphan_recovery_grace_seconds', 45 * DAY_IN_SECONDS );
	}

	/**
	 * Apply the recovery time policy to an action's intended run time.
	 *
	 * @param int $intended_ts Unix timestamp the action was originally scheduled for.
	 *
	 * @return int|false Unix timestamp to run at, or false if too far past to restore.
	 */
	public function resolve_run_time( $intended_ts ) {
		$now = time();
		if ( (int) $intended_ts >= $now ) {
			return (int) $intended_ts;          // future → original schedule
		}
		if ( (int) $intended_ts >= $now - $this->recovery_grace_window() ) {
			return $now + MINUTE_IN_SECONDS;    // recently due → run now
		}
		return false;                            // long past → 'expired', do not restore
	}

	/**
	 * Compute the intended run time for a finalized orphan.
	 *
	 * Prefer the surviving (cancelled) AS job's scheduled date; otherwise recompute
	 * from the recipe-run start + the meta delay. The returned timestamp is the RAW
	 * intended time — resolve_run_time() applies the grace policy.
	 *
	 * @param int   $async_job_id
	 * @param array $action
	 *
	 * @return int Unix timestamp to run at.
	 */
	public function compute_run_time( $async_job_id, $action ) {

		// Prefer the surviving (cancelled) AS job's scheduled date.
		if ( ! empty( $async_job_id ) && Action_Scheduler::is_available() ) {
			$job = Action_Scheduler::fetch_action( (int) $async_job_id );
			$ts  = null === $job ? null : Action_Scheduler::get_scheduled_timestamp( $job );
			if ( null !== $ts ) {
				return $ts; // intended time, unclamped; resolve_run_time() applies the grace policy
			}
		}

		// No surviving job → recompute. Branch on the async mode, because each mode
		// derives its run time differently:
		//
		//  - delay    : recipe_run_start + delay (the original time was the recipe-run
		//               time + the configured delay — re-derivable without "now").
		//  - schedule : an absolute calendar date (async_schedule_date + time).
		//  - custom   : an absolute date parsed from async_custom (often a token that
		//               must be re-resolved against the run's args).
		//
		// schedule/custom must NOT fall back to recipe_run_start + delay — with no delay
		// in meta that lands on the recipe-run date and the action falsely reads "expired".
		// Reuse Automator's Async_Actions::get_timestamp(), which computes these as
		// absolute dates independent of "now". If the absolute date cannot be resolved
		// (an unresolvable token, an empty schedule date), return 0 — the caller treats
		// 0 as "undatable" and surfaces it to the admin rather than silently expiring it.
		$meta = (array) $action['action_data']['meta'];
		$mode = isset( $meta['async_mode'] ) ? (string) $meta['async_mode'] : 'delay';

		if ( 'schedule' === $mode || 'custom' === $mode ) {

			// The legacy payload's absolute-date maths returns time() (NOT 0) on a malformed date,
			// so an empty async_schedule_date would read as "now" and resolve to a false present.
			// A schedule action's date is a literal UI value normally present + valid; catch
			// the empty case here and report undatable (0) before calling get_timestamp().
			if ( 'schedule' === $mode && '' === trim( (string) ( isset( $meta['async_schedule_date'] ) ? $meta['async_schedule_date'] : '' ) ) ) {
				return 0; // undatable
			}

			$async = $this->async_actions();
			if ( null !== $async ) {
				// get_custom_delay() reads $this->args (dynamic property) for token
				// resolution — wire the reconstructed action's args so tokens re-resolve.
				$async->args = isset( $action['args'] ) ? $action['args'] : array();

				// A custom value whose token cannot be resolved parses down to empty; PHP's
				// new \DateTime('') then yields "now" (NOT an error string), so get_timestamp()
				// would return a false present. Resolve the token text the SAME way
				// get_custom_delay() does and treat an empty/whitespace result as undatable
				// BEFORE we trust get_timestamp(). (A parse error string still casts to 0 below.)
				if ( 'custom' === $mode ) {
					$resolved = $async->handle_timestamp_tokens( (string) ( isset( $meta['async_custom'] ) ? $meta['async_custom'] : '' ) );
					$resolved = Automator()->parse->text( $resolved, (int) $action['recipe_id'], (int) $action['user_id'], $async->args );
					if ( '' === trim( (string) $resolved ) ) {
						return 0; // undatable — the token resolved to nothing.
					}
				}

				// On a custom parse failure get_custom_delay()→parse_date_time_string()
				// returns an error STRING; (int) casts it to 0 → undatable.
				$ts = (int) $async->get_timestamp( $action );
				if ( $ts > 0 ) {
					return $ts; // absolute date; resolve_run_time() applies the grace policy.
				}
			}

			// Undatable: the absolute date could not be resolved. Do NOT fall back to
			// recipe_run_start + delay (a false past). Report 0 so classify() routes it to
			// the 'undatable' bucket for the admin to Skip or Attempt-now.
			return 0;
		}

		// delay (or missing mode): recipe_run_start + the meta delay.
		$number = isset( $meta['async_delay_number'] ) ? (int) $meta['async_delay_number'] : 0;
		$unit   = isset( $meta['async_delay_unit'] ) ? $meta['async_delay_unit'] : 'days';
		$mult   = array(
			'minutes' => MINUTE_IN_SECONDS,
			'hours'   => HOUR_IN_SECONDS,
			'days'    => DAY_IN_SECONDS,
			'years'   => YEAR_IN_SECONDS,
		);
		$delay  = $number * ( isset( $mult[ $unit ] ) ? $mult[ $unit ] : DAY_IN_SECONDS );

		$start = $this->recipe_run_start( (int) $action['action_data']['recipe_log_id'] );
		$ts    = ( $start > 0 ? $start : time() ) + $delay;

		return (int) $ts; // intended time, unclamped; resolve_run_time() applies the grace policy
	}

	/**
	 * The already-booted Async_Actions instance, used to re-derive schedule/custom run
	 * times via the legacy payload's absolute-date maths.
	 *
	 * Its constructor registers WordPress hooks, so it must NOT be instantiated per row
	 * (scan/restore walk thousands). We reuse the single instance boot.php registered via
	 * Utilities::add_class_instance(); if that registry has no instance (e.g. unit tests
	 * that boot the class directly), we lazily cache exactly ONE instance here so at most
	 * one extra Async_Actions ever exists for the life of the request.
	 *
	 * @return Async_Actions|null
	 */
	private function async_actions() {

		if ( ! class_exists( '\Uncanny_Automator_Pro\Async_Actions' ) ) {
			return null;
		}

		// boot.php registers the instance under the NON-leading-slash FQCN
		// ( __NAMESPACE__ . '\\Async_Actions' ), so the lookup key must match exactly.
		$booted = Utilities::get_class_instance( 'Uncanny_Automator_Pro\Async_Actions' );
		if ( $booted instanceof Async_Actions ) {
			return $booted;
		}

		static $instance = null;
		if ( null === $instance ) {
			$instance = new Async_Actions();
		}

		return $instance;
	}

	/**
	 * Recipe-run start time (Unix GMT) from the IMMUTABLE trigger fire time, falling back to
	 * the recipe-log row only if no trigger log exists; 0 if neither is available.
	 *
	 * The trigger fire time (uap_trigger_log.date_time of the first logged trigger) is the
	 * true, immutable run start. uap_recipe_log.date_time is a TIMESTAMP that gets bumped to
	 * "now" on any row update — older MySQL gives the first TIMESTAMP an implicit
	 * ON UPDATE CURRENT_TIMESTAMP, and the orphan cleanup re-finalized these recipes in June
	 * 2026 — so it is NOT a reliable original run time. Prefer the trigger log.
	 *
	 * @param int $recipe_log_id
	 *
	 * @return int
	 */
	private function recipe_run_start( $recipe_log_id ) {
		global $wpdb;

		$date = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT date_time FROM {$wpdb->prefix}uap_trigger_log
				WHERE automator_recipe_log_id = %d
				ORDER BY ID ASC LIMIT 1",
				$recipe_log_id
			)
		);

		if ( empty( $date ) ) {
			$date = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT date_time FROM {$wpdb->prefix}uap_recipe_log WHERE ID = %d",
					$recipe_log_id
				)
			);
		}

		return empty( $date ) ? 0 : (int) get_gmt_from_date( $date, 'U' );
	}

	/**
	 * Recipe-run number from the recipe log (used to build the log dialog URL), or 1.
	 *
	 * @param int $recipe_log_id
	 *
	 * @return int
	 */
	private function recipe_run_number( $recipe_log_id ) {
		global $wpdb;
		$run = $wpdb->get_var( $wpdb->prepare( "SELECT run_number FROM {$wpdb->prefix}uap_recipe_log WHERE ID = %d", $recipe_log_id ) );
		return empty( $run ) ? 1 : (int) $run;
	}

	/**
	 * Whether the recipe-log row still exists. The log dialog can only open for a run whose
	 * uap_recipe_log row survives; if it was purged the candidate/report must degrade the
	 * "View recipe logs" link to the filtered list rather than a dead modal.
	 *
	 * @param int $recipe_log_id
	 *
	 * @return bool
	 */
	private function recipe_log_exists( $recipe_log_id ): bool {
		global $wpdb;
		$found = $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->prefix}uap_recipe_log WHERE ID = %d LIMIT 1", (int) $recipe_log_id ) );
		return ! empty( $found );
	}

	/**
	 * Display name for a user id, with sensible fallbacks for a deleted user (User #N) or a
	 * system/no-user run (No user).
	 *
	 * @param int $user_id
	 *
	 * @return string
	 */
	private function user_display_name( $user_id ): string {
		$user_id = (int) $user_id;
		$u       = get_userdata( $user_id );
		return $u ? $u->display_name : ( $user_id > 0 ? 'User #' . $user_id : 'No user' );
	}

	/**
	 * Email address for a user id, or '' for a deleted/system/no-user run. Surfaced as the
	 * second line of the user cell in the candidate preview and before/after report.
	 *
	 * @param int $user_id
	 *
	 * @return string
	 */
	private function user_email( $user_id ): string {
		$u = get_userdata( (int) $user_id );
		return $u ? (string) $u->user_email : '';
	}

	/**
	 * Human recipe title for display. Decodes HTML entities (get_the_title returns
	 * the stored title with `&` as `&#038;`) because the client renders this via
	 * jQuery .text() — which escapes again — so a raw `&` is what we want to hand it.
	 * Falls back to "Recipe #<id>" when the post has no title.
	 *
	 * @param int $recipe_id
	 *
	 * @return string
	 */
	private function recipe_title( $recipe_id ): string {
		$recipe_id = (int) $recipe_id;
		$title     = html_entity_decode( (string) get_the_title( $recipe_id ), ENT_QUOTES, 'UTF-8' );
		return '' !== $title ? $title : ( 'Recipe #' . $recipe_id );
	}

	/**
	 * Reschedule an already-finalized orphan: reconstruct it, schedule a FRESH AS job
	 * for the computed run-time, store the payload under a fresh hash, point the
	 * async_job_id meta at the new job, reset the log to IN_PROGRESS, and clear the
	 * recovery uap_error_log row.
	 *
	 * @param object $log_row
	 *
	 * @return string 'restored'|'expired'|'skipped'
	 */
	public function reschedule_finalized( $log_row ) {

		$action = $this->reconstruct_action( (int) $log_row->ID );

		if ( null === $action ) {
			return 'skipped';
		}

		$async_job_id = (int) Automator()->db->action->get_meta( (int) $log_row->ID, 'async_job_id' );
		$timestamp    = $this->resolve_run_time( $this->compute_run_time( $async_job_id, $action ) );

		if ( false === $timestamp ) {
			return 'expired'; // original run time is too far past to restore
		}

		return $this->reschedule_at( $log_row, $action, (int) $timestamp );
	}

	/**
	 * Schedule a reconstructed orphan at $timestamp and finalize the row: store the payload
	 * under a fresh hash, schedule a FRESH AS job, point the async_job_id meta at it, reset
	 * the log to IN_PROGRESS (clearing its error), drop the recovery error row, and re-open
	 * the recipe run.
	 *
	 * Shared mutation body for reschedule_finalized() (computed run-time) and
	 * attempt_undatable() (forced now+1min) — the run-time decision lives in the callers; the
	 * write path lives here exactly once.
	 *
	 * @param object $log_row
	 * @param array  $action    The reconstructed action.
	 * @param int    $timestamp The Unix time to schedule the fresh AS job for.
	 *
	 * @return string 'restored'
	 */
	private function reschedule_at( $log_row, $action, $timestamp ) {

		$timestamp = (int) $timestamp;

		$action['action_data']['async']['timestamp'] = $timestamp;

		$hash = 'automator_async_' . md5( wp_json_encode( $action ) . '|recovered|' . (int) $log_row->ID );
		automator_add_option( $hash, $action, false, false );

		$group      = apply_filters( 'automator_pro_asyc_actions_group', 'Uncanny Automator', $action );
		$new_job_id = Action_Scheduler::schedule_single_action( $timestamp, 'automator_async_run_with_hash', array( $hash ), $group );

		// Scheduling failed (as_schedule_single_action returned 0): roll back the payload option
		// and leave the row untouched (recovery marker intact) so it stays a recoverable Failed
		// orphan for a later pass, rather than a false 'restored' with no job to ever run it.
		if ( empty( $new_job_id ) ) {
			automator_delete_option( $hash );
			return 'skipped';
		}

		// Point the log's async_job_id meta at the fresh job. update_meta() only touches an
		// existing row (the original job-id meta written when the job was scheduled); if the row
		// was never written, insert it so the fresh job id is always recorded.
		//
		// We decide update-vs-insert on the row's ACTUAL existence, not on the update return.
		// update_meta() returns $wpdb->update(), which yields 0 for BOTH "row exists, value
		// unchanged" AND "no matching row" — the two are indistinguishable by return value.
		// Gating the insert on empty() would duplicate the row when the value is unchanged;
		// gating it on false === $updated would never insert a genuinely-missing row. An
		// explicit existence check is the only deterministic choice and keeps exactly one row.
		global $wpdb;
		$meta_exists = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}uap_action_log_meta
				WHERE automator_action_log_id = %d AND automator_action_id = %d AND meta_key = %s",
				(int) $log_row->ID,
				(int) $log_row->automator_action_id,
				'async_job_id'
			)
		);
		if ( $meta_exists > 0 ) {
			Automator()->db->action->update_meta( (int) $log_row->ID, (int) $log_row->automator_action_id, 'async_job_id', (int) $new_job_id );
		} else {
			Automator()->db->action->add_meta( (int) $log_row->user_id, (int) $log_row->ID, (int) $log_row->automator_action_id, 'async_job_id', (int) $new_job_id );
		}

		// Reset the log to scheduled and drop the recovery error row.
		$wpdb->update(
			$wpdb->prefix . 'uap_action_log',
			array(
				'completed'     => Automator_Status::IN_PROGRESS,
				'error_message' => '',
			),
			array( 'ID' => (int) $log_row->ID ),
			array( '%d', '%s' ),
			array( '%d' )
		);
		$wpdb->delete( $wpdb->prefix . 'uap_error_log', array( 'action_log_id' => (int) $log_row->ID ), array( '%d' ) );

		// Re-open the recipe run so it no longer displays as completed-with-errors while the
		// rescheduled action is pending; it recomputes when the action re-runs and completes.
		$wpdb->update( $wpdb->prefix . 'uap_recipe_log', array( 'completed' => Automator_Status::IN_PROGRESS ), array( 'ID' => (int) $log_row->automator_recipe_log_id ), array( '%d' ), array( '%d' ) );

		return 'restored';
	}

	/**
	 * Mark an undatable orphan as admin-skipped so it drops out of every recovery bucket.
	 *
	 * Writes action meta orphan_recovery_skipped = '1' (existence-checked add-vs-update, the
	 * same deterministic pattern reschedule_at() uses for async_job_id). classify() honors
	 * the marker and returns 'skip' for the row thereafter.
	 *
	 * @param int $action_log_id
	 *
	 * @return bool
	 */
	public function skip_undatable( $action_log_id ): bool {

		global $wpdb;

		$action_log_id = (int) $action_log_id;

		$log_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, user_id, automator_action_id FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
				$action_log_id
			)
		);

		if ( null === $log_row ) {
			return false;
		}

		$meta_exists = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}uap_action_log_meta
				WHERE automator_action_log_id = %d AND automator_action_id = %d AND meta_key = %s",
				$action_log_id,
				(int) $log_row->automator_action_id,
				'orphan_recovery_skipped'
			)
		);

		if ( $meta_exists > 0 ) {
			Automator()->db->action->update_meta( $action_log_id, (int) $log_row->automator_action_id, 'orphan_recovery_skipped', '1' );
		} else {
			Automator()->db->action->add_meta( (int) $log_row->user_id, $action_log_id, (int) $log_row->automator_action_id, 'orphan_recovery_skipped', '1' );
		}

		return true;
	}

	/**
	 * Recover an undatable orphan by scheduling it to run NOW (now + 1 minute), bypassing the
	 * compute/resolve step (the date could not be resolved). Reuses the same mutation body as
	 * reschedule_finalized() via reschedule_at().
	 *
	 * @param int $action_log_id
	 *
	 * @return string 'restored'|'skipped'
	 */
	public function attempt_undatable( $action_log_id ): string {

		global $wpdb;

		$action_log_id = (int) $action_log_id;

		$log_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, user_id, automator_action_id, automator_recipe_id, automator_recipe_log_id
				FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
				$action_log_id
			)
		);

		if ( null === $log_row ) {
			return 'skipped';
		}

		$action = $this->reconstruct_action( $action_log_id );

		if ( null === $action ) {
			return 'skipped';
		}

		// Undatable: force a run-time of ~now; do NOT compute/resolve (the date is unresolvable).
		return $this->reschedule_at( $log_row, $action, time() + MINUTE_IN_SECONDS );
	}

	/**
	 * Re-hydrate a pending orphan: store the reconstructed payload under the job's hash.
	 *
	 * @param object $log_row
	 *
	 * @return string 'restored'|'expired'|'skipped'
	 */
	public function rehydrate_pending( $log_row ) {

		$async_job_id = (int) Automator()->db->action->get_meta( (int) $log_row->ID, 'async_job_id' );

		if ( empty( $async_job_id ) || ! Action_Scheduler::is_available() ) {
			return 'skipped';
		}

		$job = Action_Scheduler::fetch_action( $async_job_id );

		if ( null === $job ) {
			return 'skipped';
		}

		$args = $job->get_args();
		$hash = isset( $args[0] ) ? $args[0] : '';

		if ( ! is_string( $hash ) || '' === $hash ) {
			return 'skipped';
		}

		// Already present (healthy or already restored) — leave it alone, regardless of its
		// schedule. A live payload is not ours to touch; only a MISSING payload is an orphan.
		// This MUST be checked before the time policy below: on a backlogged queue, huge
		// numbers of healthy jobs sit overdue waiting their turn, and checking the time first
		// would miscount every one of them as "expired" (it inflated the tally 10-20x in
		// production). Mirrors classify()'s healthy-before-expired ordering.
		if ( ! empty( automator_get_option( $hash ) ) ) {
			return 'skipped';
		}

		// Payload is gone (a real orphan). Time policy: don't re-hydrate a job whose scheduled
		// time is too far past (it would run badly late) — let it no-op instead.
		$scheduled_at = Action_Scheduler::get_scheduled_timestamp( $job );
		if ( null !== $scheduled_at && false === $this->resolve_run_time( $scheduled_at ) ) {
			return 'expired';
		}

		$action = $this->reconstruct_action( (int) $log_row->ID );

		if ( null === $action ) {
			return 'skipped';
		}

		automator_add_option( $hash, $action, false, false );

		return 'restored';
	}

	/**
	 * Process one keyset batch of candidate orphan logs, restoring each.
	 *
	 * @param int $last_id    Process action-log rows with ID greater than this.
	 * @param int $batch_size Max rows this batch.
	 *
	 * @return array{restored:int,expired:int,skipped:int,last_id:int,has_more:bool}
	 */
	public function restore_batch( $last_id, $batch_size ) {

		global $wpdb;

		$batch_size = max( 1, (int) $batch_size );
		$last_id    = (int) $last_id;

		$tally = array(
			'restored' => 0,
			'expired'  => 0,
			'skipped'  => 0,
			'last_id'  => $last_id,
			'has_more' => false,
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, completed
				FROM {$wpdb->prefix}uap_action_log
				WHERE completed IN ( %d, %d ) AND ID > %d
				ORDER BY ID ASC
				LIMIT %d",
				Automator_Status::IN_PROGRESS,
				Automator_Status::COMPLETED_WITH_ERRORS,
				$last_id,
				$batch_size
			)
		);

		if ( empty( $rows ) ) {
			return $tally;
		}

		foreach ( $rows as $row ) {
			$tally['last_id'] = (int) $row->ID;

			try {
				$log_row = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT ID, user_id, automator_action_id, automator_recipe_id, automator_recipe_log_id
						FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
						(int) $row->ID
					)
				);

				if ( null === $log_row ) {
					++$tally['skipped'];
					continue;
				}

				if ( Automator_Status::IN_PROGRESS === (int) $row->completed ) {
					// Phase 1 — rehydrate_pending self-gates (healthy/no-job/expired).
					$result = $this->rehydrate_pending( $log_row );
				} else {
					// Phase 2 — only the orphans the prior recovery finalized.
					if ( false === $this->is_recovery_finalized( (int) $row->ID ) ) {
						++$tally['skipped'];
						continue;
					}
					$result = $this->reschedule_finalized( $log_row );
				}

				++$tally[ $result ];
			} catch ( \Throwable $e ) {
				++$tally['skipped'];
				automator_log( 'Orphan restore skipped action log ' . (int) $row->ID . ': ' . $e->getMessage(), 'async-orphan-restore', true, 'async-orphan-restore' );
			}
		}

		$tally['has_more'] = count( $rows ) >= $batch_size;

		return $tally;
	}

	/**
	 * CHEAP existence check: does the site have at least ONE recoverable orphan?
	 *
	 * Drives the proactive "scheduled actions need recovery" admin nudge, which must add
	 * effectively zero cost to every admin page load. It therefore does the MINIMUM the
	 * recoverable definition allows — a single indexed `LIMIT 1` against the Failed-orphan
	 * signature pick_test_candidate() uses: a completed_with_errors action log joined to a
	 * recovery error-log row whose message carries recovery_marker(). The marker is the
	 * discriminator, so a clean/fresh site (and a site with only GENUINE action errors)
	 * returns false — unlike count_candidates(), which counts every in_progress +
	 * completed_with_errors row and would false-positive on a healthy site.
	 *
	 * SCOPE: this covers the FAILED recoverable bucket only. The STUCK (pending) bucket
	 * cannot be expressed as a cheap SQL existence check — a stuck orphan is an in_progress
	 * row whose surviving Action Scheduler job has had its payload option deleted, which can
	 * only be confirmed per row (fetch the AS job → read its hash arg → check the option is
	 * gone). That is exactly the full classify() walk the scan does and is far too costly for
	 * an admin_init nudge. Failed orphans are the dominant cap-bug leftover; a Stuck-only site
	 * is rare, and the admin can still reach the tool by other means. So the nudge is precise
	 * (no false positives) and cheap, at the cost of not nudging a Stuck-only site.
	 *
	 * @return bool True iff at least one recoverable Failed orphan exists.
	 */
	public function has_recoverable_orphans(): bool {

		global $wpdb;

		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1
				FROM {$wpdb->prefix}uap_error_log el
				INNER JOIN {$wpdb->prefix}uap_action_log al ON al.ID = el.action_log_id
				WHERE al.completed = %d AND el.error_message LIKE %s
				LIMIT 1",
				Automator_Status::COMPLETED_WITH_ERRORS,
				'%' . $wpdb->esc_like( $this->recovery_marker() ) . '%'
			)
		);

		return ! empty( $found );
	}

	/**
	 * Total number of candidate action-log rows the scan will ever examine.
	 *
	 * READ-ONLY count of the rows scan_counts() walks (same WHERE clause), so the
	 * UI can show "Scanned N of M". Touches nothing.
	 *
	 * @return int
	 */
	public function count_candidates(): int {

		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*)
				FROM {$wpdb->prefix}uap_action_log
				WHERE completed IN ( %d, %d )",
				Automator_Status::IN_PROGRESS,
				Automator_Status::COMPLETED_WITH_ERRORS
			)
		);
	}

	/**
	 * Read-only classification of one keyset batch of candidate action logs.
	 *
	 * @param int $last_id
	 * @param int $batch_size
	 *
	 * @return array{pending:int,finalized:int,healthy:int,expired:int,undatable:int,expired_delay:int,expired_schedule:int,expired_custom:int,scanned:int,last_id:int,has_more:bool}
	 */
	public function scan_counts( $last_id, $batch_size ) {

		global $wpdb;

		$batch_size = max( 1, (int) $batch_size );
		$last_id    = (int) $last_id;

		$counts = array(
			'pending'          => 0,
			'finalized'        => 0,
			'healthy'          => 0,
			'expired'          => 0,
			'undatable'        => 0,
			'expired_delay'    => 0,
			'expired_schedule' => 0,
			'expired_custom'   => 0,
			'scanned'          => 0,
			'last_id'          => $last_id,
			'has_more'         => false,
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, completed
				FROM {$wpdb->prefix}uap_action_log
				WHERE completed IN ( %d, %d ) AND ID > %d
				ORDER BY ID ASC
				LIMIT %d",
				Automator_Status::IN_PROGRESS,
				Automator_Status::COMPLETED_WITH_ERRORS,
				$last_id,
				$batch_size
			)
		);

		if ( empty( $rows ) ) {
			return $counts;
		}

		foreach ( $rows as $row ) {
			$counts['last_id'] = (int) $row->ID;
			++$counts['scanned'];

			try {
				$bucket = $this->classify( (int) $row->ID, (int) $row->completed );
				if ( isset( $counts[ $bucket ] ) ) {
					++$counts[ $bucket ];
				}

				// Break EXPIRED down by async_mode so the admin sees which kind aged out.
				if ( 'expired' === $bucket ) {
					$mode_key = 'expired_' . $this->reconstructed_async_mode( (int) $row->ID );
					if ( isset( $counts[ $mode_key ] ) ) {
						++$counts[ $mode_key ];
					}
				}
			} catch ( \Throwable $e ) {
				// Unclassifiable row — leave it out of the buckets (scanned still counts it).
				continue;
			}
		}

		$counts['has_more'] = count( $rows ) >= $batch_size;

		return $counts;
	}

	/**
	 * Classify a single action log into a recovery bucket WITHOUT mutating anything.
	 *
	 * @param int $action_log_id
	 * @param int $completed
	 *
	 * @return string One of 'pending'|'finalized'|'healthy'|'expired'|'undatable'|'skip'.
	 */
	private function classify( $action_log_id, $completed ) {

		if ( Automator_Status::COMPLETED_WITH_ERRORS === (int) $completed ) {
			if ( false === $this->is_recovery_finalized( (int) $action_log_id ) ) {
				return 'skip'; // genuine error, not an orphan we finalized.
			}

			// Admin-skipped (via skip_undatable) — drop it out of every bucket.
			if ( '1' === (string) Automator()->db->action->get_meta( (int) $action_log_id, 'orphan_recovery_skipped' ) ) {
				return 'skip';
			}

			$action = $this->reconstruct_action( (int) $action_log_id );
			if ( null === $action ) {
				return 'skip';
			}
			$async_job_id = (int) Automator()->db->action->get_meta( (int) $action_log_id, 'async_job_id' );
			$ts           = $this->compute_run_time( $async_job_id, $action );

			// 0 from a custom/schedule recompute means the date could not be resolved:
			// undatable, NOT expired (delay always yields a real ts, so never lands here).
			if ( $this->is_undatable_ts( $ts, $action ) ) {
				return 'undatable';
			}

			return false === $this->resolve_run_time( $ts ) ? 'expired' : 'finalized';
		}

		// IN_PROGRESS path.
		$async_job_id = (int) Automator()->db->action->get_meta( (int) $action_log_id, 'async_job_id' );
		if ( empty( $async_job_id ) || ! Action_Scheduler::is_available() ) {
			return 'skip';
		}

		$job = Action_Scheduler::fetch_action( $async_job_id );
		if ( null === $job ) {
			return 'skip';
		}

		$args = $job->get_args();
		$hash = isset( $args[0] ) ? $args[0] : '';
		if ( ! is_string( $hash ) || '' === $hash ) {
			return 'skip';
		}

		if ( ! empty( automator_get_option( $hash ) ) ) {
			return 'healthy'; // payload present — it will run.
		}

		// Orphan: payload gone. Resolve the job's scheduled time through the grace policy.
		$intended = Action_Scheduler::get_scheduled_timestamp( $job ) ?? time();

		return false === $this->resolve_run_time( $intended ) ? 'expired' : 'pending';
	}

	/**
	 * Whether a reconstructed run-time is "undatable": a custom/schedule orphan whose absolute
	 * date could not be resolved (compute_run_time() returned 0). delay mode always yields a
	 * real ts, so it never reads as undatable. The single source of the undatable rule, shared
	 * by classify() and process_undatable_batch() (DRY).
	 *
	 * @param int   $ts     The compute_run_time() result.
	 * @param array $action The reconstructed action.
	 *
	 * @return bool
	 */
	private function is_undatable_ts( $ts, $action ): bool {
		$mode = isset( $action['action_data']['meta']['async_mode'] ) ? (string) $action['action_data']['meta']['async_mode'] : 'delay';
		return (int) $ts <= 0 && ( 'custom' === $mode || 'schedule' === $mode );
	}

	/**
	 * Whether a recovery-finalized Failed orphan is CURRENTLY undatable — reuses the exact rule
	 * classify() applies (reconstruct → compute_run_time → is_undatable_ts), so the bulk batch
	 * acts on the same set the scan's "Undatable" count surfaces. A non-finalized/unreconstructable
	 * row is not undatable.
	 *
	 * @param int $action_log_id
	 *
	 * @return bool
	 */
	private function is_undatable( $action_log_id ): bool {
		$action_log_id = (int) $action_log_id;

		if ( false === $this->is_recovery_finalized( $action_log_id ) ) {
			return false;
		}

		// An admin-skipped row is out of every bucket — not undatable any more.
		if ( '1' === (string) Automator()->db->action->get_meta( $action_log_id, 'orphan_recovery_skipped' ) ) {
			return false;
		}

		$action = $this->reconstruct_action( $action_log_id );
		if ( null === $action ) {
			return false;
		}

		$async_job_id = (int) Automator()->db->action->get_meta( $action_log_id, 'async_job_id' );
		$ts           = $this->compute_run_time( $async_job_id, $action );

		return $this->is_undatable_ts( $ts, $action );
	}

	/**
	 * Process one keyset batch of Failed orphans for the bulk Undatable action, acting ONLY on
	 * rows that are currently undatable (same rule classify() uses, via is_undatable()).
	 *
	 *  - 'attempt' → reschedule the undatable row to run ~now (attempt_undatable()).
	 *  - 'skip'    → mark the undatable row admin-skipped (skip_undatable()).
	 *  - datable / non-undatable rows are passed (counted, untouched).
	 *
	 * Keyset over completed = COMPLETED_WITH_ERRORS, ID > $last_id, ascending. Per-row try/catch
	 * advances last_id first so a throwing row can never re-enter the next batch.
	 *
	 * @param int    $last_id    Process action-log rows with ID greater than this.
	 * @param int    $batch_size Max rows this batch.
	 * @param string $mode       'skip' | 'attempt'.
	 *
	 * @return array{attempted:int,skipped:int,passed:int,last_id:int,has_more:bool}
	 */
	public function process_undatable_batch( $last_id, $batch_size, $mode ): array {

		global $wpdb;

		$batch_size = max( 1, (int) $batch_size );
		$last_id    = (int) $last_id;
		$mode       = 'attempt' === $mode ? 'attempt' : 'skip';

		$tally = array(
			'attempted' => 0,
			'skipped'   => 0,
			'passed'    => 0,
			'last_id'   => $last_id,
			'has_more'  => false,
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID
				FROM {$wpdb->prefix}uap_action_log
				WHERE completed = %d AND ID > %d
				ORDER BY ID ASC
				LIMIT %d",
				Automator_Status::COMPLETED_WITH_ERRORS,
				$last_id,
				$batch_size
			)
		);

		if ( empty( $rows ) ) {
			return $tally;
		}

		foreach ( $rows as $row ) {
			$id               = (int) $row->ID;
			$tally['last_id'] = $id;

			try {
				if ( false === $this->is_undatable( $id ) ) {
					++$tally['passed'];
					continue;
				}

				if ( 'attempt' === $mode ) {
					$this->attempt_undatable( $id );
					++$tally['attempted'];
				} else {
					$this->skip_undatable( $id );
					++$tally['skipped'];
				}
			} catch ( \Throwable $e ) {
				++$tally['passed'];
				automator_log( 'Orphan undatable batch passed action log ' . $id . ': ' . $e->getMessage(), 'async-orphan-undatable', true, 'async-orphan-undatable' );
			}
		}

		$tally['has_more'] = count( $rows ) >= $batch_size;

		return $tally;
	}

	/**
	 * The recovery finalize marker, built from the SAME esc_html_x() call the finalizer
	 * (Async_Actions::recover_orphans_batch) uses to write it, so it resolves to whatever
	 * locale wrote the row — matching existing finalized rows and future ones on any locale.
	 * A hard-coded English literal would silently miss every row on a localized site and
	 * skip Phase 2 entirely. Kept in one place so the locale-safe needle never drifts.
	 *
	 * @return string
	 */
	private function recovery_marker(): string {
		return esc_html_x(
			'Scheduled action could not run — its stored data was removed by an orphan-cleanup defect and has been recovered.',
			'Async action status',
			'uncanny-automator-pro'
		);
	}

	/**
	 * Whether an action log was finalized by the orphan-cleanup recovery (vs a genuine
	 * action error), identified by the recovery marker in uap_error_log.
	 *
	 * @param int $action_log_id
	 *
	 * @return bool
	 */
	private function is_recovery_finalized( $action_log_id ) {

		global $wpdb;

		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$wpdb->prefix}uap_error_log
				WHERE action_log_id = %d AND error_message LIKE %s
				LIMIT 1",
				(int) $action_log_id,
				'%' . $wpdb->esc_like( $this->recovery_marker() ) . '%'
			)
		);

		return ! empty( $found );
	}

	/**
	 * READ-ONLY: surface ONE Failed orphan (completed_with_errors + recovery error-log
	 * marker) with the fields the admin needs to inspect it BEFORE recovering. Mutates
	 * nothing — no reschedule, no writes.
	 *
	 * @param string $mode Optional async mode to constrain the pick to
	 *                     ('delay'|'schedule'|'custom'). Empty = any. Lets the owner
	 *                     hunt a schedule/custom candidate instead of repeatedly hitting
	 *                     the (usually dominant) delay ones.
	 *
	 * @return array The candidate fields, or an empty array if none found.
	 */
	public function pick_test_candidate( string $mode = '' ): array {

		global $wpdb;

		// async_mode is held in the run snapshot (the serialized `metas` blob), which can't
		// be filtered in SQL — but it also lives on the action POST (postmeta), keyed by
		// uap_action_log.automator_action_id. Join that (indexed) when a mode is requested.
		$mode  = in_array( $mode, array( 'delay', 'schedule', 'custom' ), true ) ? $mode : '';
		$join  = '';
		$where = '';
		$args  = array( Automator_Status::COMPLETED_WITH_ERRORS, '%' . $wpdb->esc_like( $this->recovery_marker() ) . '%' );
		if ( '' !== $mode ) {
			$join   = "INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = al.automator_action_id AND pm.meta_key = 'async_mode'";
			$where  = 'AND pm.meta_value = %s';
			$args[] = $mode;
		}

		$query = "SELECT DISTINCT el.action_log_id
			FROM {$wpdb->prefix}uap_error_log el
			INNER JOIN {$wpdb->prefix}uap_action_log al ON al.ID = el.action_log_id
			{$join}
			WHERE al.completed = %d AND el.error_message LIKE %s {$where}
			ORDER BY RAND()
			LIMIT 1";

		$action_log_id = (int) $wpdb->get_var( $wpdb->prepare( $query, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $query's $join and $where are the fixed fragments above; the mode and the other values are bound through placeholders here.

		if ( empty( $action_log_id ) ) {
			return array();
		}

		$log_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, user_id, automator_recipe_id, automator_recipe_log_id, completed
				FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
				$action_log_id
			)
		);

		if ( null === $log_row ) {
			return array();
		}

		$code  = $this->resolve_action_code( $action_log_id );
		$error = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT error_message FROM {$wpdb->prefix}uap_error_log WHERE action_log_id = %d ORDER BY ID DESC LIMIT 1",
				$action_log_id
			)
		);

		// READ-ONLY preview of the date this candidate WOULD run at once recovered, so the
		// owner sees it BEFORE recovering. Reconstruct the action and run the (read-only)
		// compute_run_time()/resolve_run_time() the recovery would use — touches nothing.
		$async_job_id  = (int) Automator()->db->action->get_meta( $action_log_id, 'async_job_id' );
		$reconstructed = $this->reconstruct_action( $action_log_id );
		$async_mode    = is_array( $reconstructed ) && ! empty( $reconstructed['action_data']['meta']['async_mode'] )
			? (string) $reconstructed['action_data']['meta']['async_mode']
			: '';
		$would_run_at  = 0;
		if ( is_array( $reconstructed ) ) {
			$resolved     = $this->resolve_run_time( $this->compute_run_time( $async_job_id, $reconstructed ) );
			$would_run_at = false === $resolved ? 0 : (int) $resolved;
		}

		// Immutable trigger fire time the delay math runs from — shown so the owner can sanity-check
		// the "Would run" date. 0 (unknown) renders as an em dash rather than a misleading epoch.
		$recipe_start = $this->recipe_run_start( (int) $log_row->automator_recipe_log_id );

		return array(
			'action_log_id'       => $action_log_id,
			'recipe_id'           => (int) $log_row->automator_recipe_id,
			'recipe_title'        => $this->recipe_title( (int) $log_row->automator_recipe_id ),
			'recipe_url'          => admin_url( 'post.php?post=' . (int) $log_row->automator_recipe_id . '&action=edit' ),
			'recipe_log_id'       => (int) $log_row->automator_recipe_log_id,
			'run_number'          => $this->recipe_run_number( (int) $log_row->automator_recipe_log_id ),
			'recipe_log_exists'   => $this->recipe_log_exists( (int) $log_row->automator_recipe_log_id ),
			'user_id'             => (int) $log_row->user_id,
			'user_name'           => $this->user_display_name( (int) $log_row->user_id ),
			'user_email'          => $this->user_email( (int) $log_row->user_id ),
			'code'                => $code,
			'completed'           => (int) $log_row->completed,
			'completed_label'     => Automator_Status::name( (int) $log_row->completed ),
			'async_job_id'        => $async_job_id,
			'async_mode'          => $async_mode,
			'schedule_basis'      => $this->schedule_basis( (array) ( isset( $reconstructed['action_data']['meta'] ) ? $reconstructed['action_data']['meta'] : array() ) ),
			'recipe_start'        => (int) $recipe_start,
			'recipe_start_human'  => $recipe_start > 0 ? ( wp_date( 'Y-m-d H:i', $recipe_start ) . ' ' . wp_timezone_string() ) : '-',
			'would_run_at'        => $would_run_at,
			'would_run_at_human'  => $would_run_at > 0 ? ( wp_date( 'Y-m-d H:i', $would_run_at ) . ' ' . wp_timezone_string() . ' · ' . gmdate( 'Y-m-d H:i', $would_run_at ) . ' UTC' ) : 'expired (too old)',
			'error'               => null === $error ? null : (string) $error,
		);
	}

	/**
	 * Recover ONE specific Failed orphan (reusing the production reschedule_finalized()
	 * path — no parallel recovery) and return a before/after report so the site owner can
	 * confirm THAT exact row recovered before running the full set.
	 *
	 * Guards against an arbitrary/stale id from the client by re-validating it is still a
	 * recoverable Failed orphan before touching it.
	 *
	 * @param int $action_log_id The action-log id to recover.
	 *
	 * @return array The before/after report, or array( 'ok' => false ) if not recoverable.
	 */
	public function test_restore_action( $action_log_id ): array {

		global $wpdb;

		$action_log_id = (int) $action_log_id;

		// Guard: only recover an id that is still a recovery-finalized Failed orphan.
		if ( false === $this->is_recovery_finalized( $action_log_id ) ) {
			return array( 'ok' => false );
		}

		$log_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, user_id, automator_action_id, automator_recipe_id, automator_recipe_log_id, completed
				FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
				$action_log_id
			)
		);

		if ( null === $log_row ) {
			return array( 'ok' => false );
		}

		// Snapshot BEFORE the recovery mutates the row.
		$before_completed = (int) $log_row->completed;
		$before_job_id    = (int) Automator()->db->action->get_meta( $action_log_id, 'async_job_id' );
		$before_error     = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT error_message FROM {$wpdb->prefix}uap_error_log WHERE action_log_id = %d ORDER BY ID DESC LIMIT 1",
				$action_log_id
			)
		);

		$code = $this->resolve_action_code( $action_log_id );

		// Reconstruct once to derive the plain-language schedule basis BEFORE the recovery
		// mutates the row (it reads only the surviving metas, so order is moot, but keep it
		// alongside the other read-only fields).
		$reconstructed  = $this->reconstruct_action( $action_log_id );
		$schedule_basis = $this->schedule_basis( (array) ( is_array( $reconstructed ) && isset( $reconstructed['action_data']['meta'] ) ? $reconstructed['action_data']['meta'] : array() ) );

		// Run the real recovery — this mutates the row (status, meta, error row).
		$result = $this->reschedule_finalized( $log_row );

		// Snapshot AFTER.
		$after_completed = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT completed FROM {$wpdb->prefix}uap_action_log WHERE ID = %d",
				$action_log_id
			)
		);
		$after_job_id    = (int) Automator()->db->action->get_meta( $action_log_id, 'async_job_id' );
		$after_error     = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT error_message FROM {$wpdb->prefix}uap_error_log WHERE action_log_id = %d ORDER BY ID DESC LIMIT 1",
				$action_log_id
			)
		);

		$run_time     = $this->resolve_job_run_time( $after_job_id );
		$recipe_start = $this->recipe_run_start( (int) $log_row->automator_recipe_log_id );

		return array(
			'ok'                 => true,
			'action_log_id'      => $action_log_id,
			'recipe_id'          => (int) $log_row->automator_recipe_id,
			'recipe_title'       => $this->recipe_title( (int) $log_row->automator_recipe_id ),
			'recipe_url'         => admin_url( 'post.php?post=' . (int) $log_row->automator_recipe_id . '&action=edit' ),
			'recipe_log_id'      => (int) $log_row->automator_recipe_log_id,
			'run_number'         => $this->recipe_run_number( (int) $log_row->automator_recipe_log_id ),
			'recipe_log_exists'  => $this->recipe_log_exists( (int) $log_row->automator_recipe_log_id ),
			'user_id'            => (int) $log_row->user_id,
			'user_name'          => $this->user_display_name( (int) $log_row->user_id ),
			'user_email'         => $this->user_email( (int) $log_row->user_id ),
			'code'               => $code,
			'schedule_basis'     => $schedule_basis,
			'recipe_start'       => (int) $recipe_start,
			'recipe_start_human' => $recipe_start > 0 ? ( wp_date( 'Y-m-d H:i', $recipe_start ) . ' ' . wp_timezone_string() ) : '-',
			'result'             => $result,
			'before'        => array(
				'completed'       => $before_completed,
				'completed_label' => Automator_Status::name( (int) $before_completed ),
				'async_job_id'    => $before_job_id,
				'error'           => null === $before_error ? null : (string) $before_error,
			),
			'after'         => array(
				'completed'       => $after_completed,
				'completed_label' => Automator_Status::name( (int) $after_completed ),
				'async_job_id'    => $after_job_id,
				'error'           => null === $after_error ? null : (string) $after_error,
				'run_time'        => $run_time,
				'run_time_human'  => $run_time > 0 ? ( wp_date( 'Y-m-d H:i', $run_time ) . ' ' . wp_timezone_string() . ' · ' . gmdate( 'Y-m-d H:i', $run_time ) . ' UTC' ) : '',
			),
		);
	}

	/**
	 * Action code for a log row: prefer the reconstructed metas (authoritative); fall back
	 * to a standalone `code` meta.
	 *
	 * @param int $action_log_id
	 *
	 * @return string
	 */
	private function resolve_action_code( $action_log_id ): string {
		$reconstructed = $this->reconstruct_action( (int) $action_log_id );
		return ( is_array( $reconstructed ) && ! empty( $reconstructed['action_data']['meta']['code'] ) )
			? (string) $reconstructed['action_data']['meta']['code']
			: (string) Automator()->db->action->get_meta( (int) $action_log_id, 'code' );
	}

	/**
	 * The reconstructed async_mode for a log row ('delay'|'schedule'|'custom'), defaulting
	 * to 'delay' when the meta is absent. Used to attribute an expired row to its mode.
	 *
	 * @param int $action_log_id
	 *
	 * @return string
	 */
	private function reconstructed_async_mode( $action_log_id ): string {
		$reconstructed = $this->reconstruct_action( (int) $action_log_id );
		return ( is_array( $reconstructed ) && ! empty( $reconstructed['action_data']['meta']['async_mode'] ) )
			? (string) $reconstructed['action_data']['meta']['async_mode']
			: 'delay';
	}

	/**
	 * Plain-language explanation of HOW the run time is derived from the async config,
	 * branched per mode (delay / schedule / custom). Surfaced in the candidate table so the
	 * owner reads, in words, why "Would run" lands where it does.
	 *
	 * Returns a PLAIN translated string (__(), NOT esc_html__) — the JS renders it through
	 * .text(), which escapes, so escaping here would double-encode.
	 *
	 * @param array $meta The reconstructed action_data.meta.
	 *
	 * @return string
	 */
	private function schedule_basis( $meta ) {
		$mode = isset( $meta['async_mode'] ) ? (string) $meta['async_mode'] : 'delay';

		if ( 'schedule' === $mode ) {
			$date = isset( $meta['async_schedule_date'] ) ? trim( (string) $meta['async_schedule_date'] ) : '';
			$time = isset( $meta['async_schedule_time'] ) ? trim( (string) $meta['async_schedule_time'] ) : '';
			/* translators: 1: scheduled date, 2: scheduled time. */
			return trim( sprintf( __( 'Fixed date: %1$s %2$s', 'uncanny-automator-pro' ), $date, $time ) ); // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text(); escaping would double-encode.
		}

		if ( 'custom' === $mode ) {
			$custom = isset( $meta['async_custom'] ) ? trim( (string) $meta['async_custom'] ) : '';
			/* translators: %s: the custom date value/token. */
			return sprintf( __( 'Custom value: %s', 'uncanny-automator-pro' ), $custom ); // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text(); escaping would double-encode.
		}

		// delay
		$num  = isset( $meta['async_delay_number'] ) ? (int) $meta['async_delay_number'] : 0;
		$unit = isset( $meta['async_delay_unit'] ) ? (string) $meta['async_delay_unit'] : 'days';
		/* translators: 1: number, 2: unit (days/hours/…). e.g. "700 days after the recipe start". */
		return sprintf( __( '%1$s %2$s after the recipe start', 'uncanny-automator-pro' ), $num, $unit ); // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text(); escaping would double-encode.
	}

	/**
	 * Resolve an AS job's scheduled run time (Unix), or 0 if unavailable.
	 *
	 * @param int $async_job_id
	 *
	 * @return int
	 */
	private function resolve_job_run_time( $async_job_id ): int {

		if ( empty( $async_job_id ) || ! Action_Scheduler::is_available() ) {
			return 0;
		}

		$job = Action_Scheduler::fetch_action( (int) $async_job_id );
		if ( null === $job ) {
			return 0;
		}

		return (int) Action_Scheduler::get_scheduled_timestamp( $job );
	}
}
