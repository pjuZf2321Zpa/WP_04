<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Api_Server;
use WP_Error;

use function Uncanny_Automator\App\Infrastructure\automator_license_manager;

/**
 * Class AdminMenu
 *
 * This class should only be used to inherit classes
 *
 * @package Uncanny_Automator_Pro
 */
class Licensing {

	/**
	 * Days an expired license keeps working before the site drops to Lite.
	 *
	 * The platform owns the window (LicenseGracePolicy::DEFAULT_GRACE_DAYS,
	 * narrowed from 30 to 15 on 2026-09-11) and serves an expired license as
	 * valid until it ends. The expiry notice only words it, so it must match.
	 *
	 * @since 8.0.1
	 */
	const EXPIRY_GRACE_DAYS = 15;

	/**
	 * The name of the licensing page
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $page_name = null;

	/**
	 * The slug of the licensing page
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $page_slug = null;

	/**
	 * The slug of the parent that the licensing page is organized under
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $parent_slug = null;

	/**
	 * The URL of store powering the plugin
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $store_url = AUTOMATOR_LICENSING_URL;

	/**
	 * The Author of the Plugin
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $item_name = AUTOMATOR_PRO_ITEM_NAME;

	/**
	 * @var int
	 */
	public $item_id = AUTOMATOR_PRO_ITEM_ID;
	/**
	 * @var string
	 */
	public $license = '';

	/**
	 * The Author of the Plugin
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $author = 'Uncanny Owl';

	/**
	 * Is this a beta version release
	 *
	 * @since    1.0.0
	 * @access   public
	 * @var      string
	 */
	public $beta = null;

	/**
	 * @var bool|string|null
	 */
	public $error = null;

	/**
	 * Licensing constructor.
	 */
	public function __construct() {

		// Create sub-page for EDD licensing
		$this->page_name   = 'Licensing';
		$this->page_slug   = 'uncanny-automator-config';
		$this->parent_slug = 'uo-recipe';
		$this->store_url   = AUTOMATOR_LICENSING_URL;
		$this->item_name   = AUTOMATOR_PRO_ITEM_NAME;
		$this->item_id     = AUTOMATOR_PRO_ITEM_ID;
		$this->author      = 'Uncanny Automator';

		$this->error = $this->set_defaults();

		if ( true === $this->error ) {
			add_action( 'admin_init', array( $this, 'clear_field' ) );
			$this->init_sdk_updater();
			//          add_action( 'admin_menu', array( $this, 'license_menu' ), 199 );
			add_action( 'admin_init', array( $this, 'activate_license' ) );
			add_action( 'admin_init', array( $this, 'deactivate_license' ) );
			add_action( 'automator_settings_general_license_content', array( $this, 'add_licensing_errors' ) );
			add_action( 'uapro_notify_admin_of_license_expiry', array( $this, 'admin_notices_for_expiry' ) );
			//Add license notice
			add_action(
				'after_plugin_row',
				array(
					$this,
					'plugin_row',
				),
				10,
				3
			);

			// Maybe pre-activate Pro license.
			if ( defined( 'AUTOMATOR_PRO_LICENSE_KEY' ) ) {
				add_action( 'init', array( $this, 'maybe_pre_activate' ) );
				add_action( 'wp_initialize_site', array( $this, 'maybe_pre_activate_multisite' ), 1000 );
			}

			// Add license to the settings page
			$this->add_setting();
		}
	}

	/**
	 * @param $plugin_name
	 * @param $plugin_data
	 * @param $status
	 */
	public function plugin_row( $plugin_name, $plugin_data, $status ) {
		if ( 'uncanny-automator-pro/uncanny-automator-pro.php' !== $plugin_name ) {
			return;
		}
		$slug    = 'uncanny-automator-pro';
		$message = $this->expiry_message();

		if ( empty( $message ) ) {
			return;
		}
		if ( is_network_admin() ) {
			$active_class = is_plugin_active_for_network( $plugin_name ) ? ' active' : '';
		} else {
			$active_class = is_plugin_active( $plugin_name ) ? ' active' : '';
		}

		// Get the columns for this table so we can calculate the colspan attribute.
		$screen  = get_current_screen();
		$columns = get_column_headers( $screen );

		// If something went wrong with retrieving the columns, default to 3 for colspan.
		$colspan = ! is_countable( $columns ) ? 3 : count( $columns );

		echo '<tr class="plugin-update-tr' . $active_class . '" id="' . $slug . '-update" data-slug="' . $slug . '" data-plugin="' . $plugin_name . '">';
		echo '<td colspan="' . $colspan . '" class="plugin-update colspanchange">';
		echo '<div class="update-message notice inline notice-warning notice-alt">';
		echo '<p>';
		echo wp_kses_post( $message );
		echo '</p></div></td></tr>';

		// Apply the class "update" to the plugin row to get rid of the ugly border.
		echo "
				<script type='text/javascript'>
					jQuery('#$slug-update').prev('tr').addClass('update');
				</script>
				";
	}

	/**
	 * @return string
	 */
	public function expiry_message() {
		$this->check_license();
		$license_key    = automator_get_option( 'uap_automator_pro_license_key', '' );
		$license_key    = null === $license_key ? '' : trim( $license_key );
		$license_status = automator_get_option( 'uap_automator_pro_license_status', '' );
		$license_expiry = automator_get_option( 'uap_automator_pro_license_expiry' );

		if ( 'expired' !== $license_status ) {
			return '';
		}

		return $this->expiry_sentence( $license_key, (string) $license_expiry );
	}

	/**
	 * What an expired license's notice says: by how long ago it expired, with
	 * the renewal link for the key.
	 *
	 * @since 8.0.0
	 *
	 * @param string $license_key    The license key.
	 * @param string $license_expiry When it expired; '' when unknown.
	 *
	 * @return string
	 */
	public function expiry_sentence( $license_key, $license_expiry ) {
		$message = '';
		$elapsed = 0;
		if ( ! empty( $license_expiry ) ) {
			$elapsed = time() - strtotime( $license_expiry );
		}
		$days_diff = round( $elapsed / DAY_IN_SECONDS );
		// The platform's cut-off is exact (expired more than the window ago), so this is too.
		$past_grace = $elapsed >= self::EXPIRY_GRACE_DAYS * DAY_IN_SECONDS;
		$renew_link = sprintf(
			'<a href="%s" target="_blank">%s</a>',
			esc_url( AUTOMATOR_STORE_URL . 'checkout/?edd_license_key=' . rawurlencode( $license_key ) . '&download_id=' . AUTOMATOR_PRO_ITEM_ID . '&utm_source=uncanny-automator-pro&utm_medium=in-plugin&utm_content=plugins-page' ),
			__( 'Renew now', 'uncanny-automator-pro' )
		);
		if ( $past_grace ) {
			$message .= sprintf(
				/* translators: 1: Product name, 2: "This site is now on Lite", 3: Renewal link, 4: Number of days the license kept working after it expired. */
				_x(
					'Your %1$s license expired more than %4$d days ago. %2$s: up to 150 tool uses a day for your AI, and app integrations are limited to the Lite allowance. Plugin updates and support have stopped. %3$s to restore them.',
					'License expiry notice',
					'uncanny-automator-pro'
				),
				'<strong>Uncanny Automator Pro</strong>',
				'<strong>' . __( 'This site is now on Lite', 'uncanny-automator-pro' ) . '</strong>',
				$renew_link,
				self::EXPIRY_GRACE_DAYS
			);
		} elseif ( $days_diff >= 1 ) {
			$message .= sprintf(
				_x(
					'Your %1$s license expired on %2$s. %3$s to keep unlimited tool usage for your AI, app integrations beyond the Lite allowance, full use of your addons (Plus and up), and plugin updates and support.',
					'License expiry notice',
					'uncanny-automator-pro'
				),
				'<strong>Uncanny Automator Pro</strong>',
				date( 'F d, Y', strtotime( $license_expiry ) ),
				$renew_link
			);
		} else {
			$message .= sprintf(
				_x(
					'Your license for %1$s has expired. %2$s to keep unlimited tool usage for your AI, app integrations beyond the Lite allowance, full use of your addons (Plus and up), and plugin updates and support.',
					'License expiry notice',
					'uncanny-automator-pro'
				),
				'<strong>Uncanny Automator Pro</strong>',
				$renew_link
			);
		}

		return $message;
	}

	/**
	 * Add license link to the menu
	 * This won't output content, but just send to the
	 * Settings > General > License
	 *
	 * @since 3.7
	 */
	public function license_menu() {
		// Get the global $submenu array
		global $submenu;

		// Add a custom URL to the Automator menu
		$submenu['edit.php?post_type=uo-recipe'][] = array(
			/* translators: 1. Trademarked term */
			sprintf( __( '%1$s license', 'uncanny-automator-pro' ), 'Automator Pro' ),

			automator_pro_get_admin_capability(),

			add_query_arg(
				array(
					'post_type' => 'uo-recipe',
					'page'      => 'uncanny-automator-config',
					'tab'       => 'general',
					'general'   => 'license',
				),
				admin_url( 'edit.php' )
			),
		);
	}

	/**
	 *
	 */
	public function admin_notices_for_expiry() {
		$license_data = $this->check_license( true );
	}

	/**
	 * @return bool
	 */
	public function is_automator_page() {
		if ( filter_has_var( INPUT_GET, 'post_type' ) && preg_match( '/uo\-recipe/', filter_input( INPUT_GET, 'post_type' ) ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Set all the defaults for the plugin licensing
	 *
	 * @return bool|string True if success and error message if not
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_defaults() {

		if ( null === $this->page_name ) {
			$this->page_name = AUTOMATOR_PRO_ITEM_NAME;
		}

		if ( null === $this->page_slug ) {
			$this->page_slug = 'uncanny-automator-config';
		}

		if ( null === $this->parent_slug ) {
			$this->parent_slug = 'uo-recipe';
		}

		if ( null === $this->store_url ) {
			return __( 'Error: Licensed plugin store URL not set.', 'uncanny-automator-pro' );
		}

		if ( null === $this->item_name ) {
			return __( 'Error: Licensed plugin item name not set', 'uncanny-automator-pro' );
		}

		if ( null === $this->author ) {
			$this->author = 'Uncanny Owl';
		}

		if ( null === $this->beta ) {
			$this->beta = false;
		}

		return true;
	}

	/**
	 * Boots the EDD Software Licensing SDK and registers Automator Pro for updates.
	 *
	 * The SDK fires `edd_sl_sdk_registry` on `after_setup_theme`, so the listener is
	 * attached BEFORE the bootstrap file is required: requiring the bootstrap after
	 * `after_setup_theme` has already run triggers the registry synchronously, and the
	 * listener must already be in place for that to register Pro.
	 *
	 * @since    7.3.0.7
	 *
	 * @return void
	 */
	private function init_sdk_updater() {

		$sdk_bootstrap = UAPro_ABSPATH . 'vendor/easy-digital-downloads/edd-sl-sdk/edd-sl-sdk.php';

		if ( ! is_readable( $sdk_bootstrap ) ) {
			return;
		}

		add_action( 'edd_sl_sdk_registry', array( $this, 'register_sdk_updater' ) );
		add_filter( 'edd_sl_sdk_api_params_automatorplugin', array( $this, 'sdk_update_request_params' ) );
		// Ahead of the SDK's own plugins_api filter (priority 10).
		add_filter( 'plugins_api', array( $this, 'sdk_plugin_information_fallback' ), 9, 3 );

		require_once $sdk_bootstrap;
	}

	/**
	 * Gives the SDK an object to work with when the store cannot be reached.
	 *
	 * WordPress asks plugins_api() about every plugin another plugin requires, and the Automator add-ons
	 * require uncanny-automator-pro, which the SDK answers from the store. When that request fails, the SDK
	 * (1.0.4 and earlier) sets properties on the `false` it was handed: an Error on PHP 8, so the Plugins
	 * screen dies whenever the store is down, blocked by a firewall, or outbound HTTP is off. A successful
	 * store response still replaces this.
	 *
	 * @since 8.0.0
	 *
	 * @param false|object|array $result The plugin information so far.
	 * @param string             $action The plugins_api action.
	 * @param object|null        $args   The request arguments.
	 *
	 * @return false|object|array
	 */
	public function sdk_plugin_information_fallback( $result, $action = '', $args = null ) {

		if ( false !== $result || 'plugin_information' !== $action || ! isset( $args->slug ) || 'uncanny-automator-pro' !== $args->slug ) {
			return $result;
		}

		return (object) array(
			'name'    => 'Uncanny Automator Pro',
			'slug'    => 'uncanny-automator-pro',
			'version' => defined( 'AUTOMATOR_PRO_PLUGIN_VERSION' ) ? AUTOMATOR_PRO_PLUGIN_VERSION : '',
		);
	}

	/**
	 * Registers Automator Pro with the EDD Software Licensing SDK updater.
	 *
	 * Update checks are sent natively to the EDD store, bypassing the UO licensing
	 * proxy. `keyless` keeps the updater running off Automator Pro's own license
	 * storage (and suppresses the SDK's built-in license UI); `weekly_check` is
	 * disabled because Automator Pro runs its own license validation.
	 *
	 * @since    7.3.0.7
	 *
	 * @param \EasyDigitalDownloads\Updater\Registry $registry The SDK registry.
	 *
	 * @return void
	 */
	public function register_sdk_updater( $registry ) {

		$registry->register(
			array(
				'id'           => 'uncanny-automator-pro',
				'url'          => AUTOMATOR_STORE_URL,
				'item_id'      => AUTOMATOR_PRO_ITEM_ID,
				'version'      => AUTOMATOR_PRO_PLUGIN_VERSION,
				'file'         => AUTOMATOR_PRO_FILE,
				'keyless'      => true,
				'weekly_check' => false,
			)
		);
	}

	/**
	 * Injects Automator Pro's license key into the SDK update request.
	 *
	 * The SDK reads from its own (unused) license option, so the key is supplied
	 * from Automator Pro's storage. The store needs it to return the download
	 * package URL for authenticated updates.
	 *
	 * @since    7.3.0.7
	 *
	 * @param array $params The outgoing API request parameters.
	 *
	 * @return array
	 */
	public function sdk_update_request_params( $params ) {

		$params['license']   = trim( (string) automator_get_option( 'uap_automator_pro_license_key' ) );
		$params['item_name'] = AUTOMATOR_PRO_ITEM_NAME;

		return $params;
	}

	/**
	 * Adds the content used to verify the Pro license
	 */
	private function add_setting() {
		// Override the output of the "License" tab in the Settings page
		add_filter(
			'automator_settings_general_tabs',
			function ( $tabs ) {
				// Check if the license tab is defined
				if ( isset( $tabs['license'] ) ) {
					// Get the license status
					$license_status = automator_get_option( 'uap_automator_pro_license_status' );

					// Set another function
					$tabs['license']->function = array( $this, 'tab_output_license' );
				}

				// Return tabs
				return $tabs;
			},
			99,
			1
		);
	}

	/**
	 * Adds the content used to verify the Pro license
	 *
	 * @since 3.7
	 */
	public function tab_output_license() {
		// Get data about the license
		$license = $this->check_license( true );

		// Add the license KEY, if there is one
		$license->key = automator_get_option( 'uap_automator_pro_license_key' );

		// Rename one of the properties so it's easier to understand
		$license->status = isset( $license->license ) ? $license->license : '';

		// Get the link to remove the license
		$remove_license_url = add_query_arg(
			array(
				'clear_license_field' => 1,
				'uapro_nonce'         => wp_create_nonce( 'uapro_nonce' ),
			),
			$this->get_license_page_url()
		);

		// Renew license URL
		$renew_license_url = add_query_arg(
			array(
				'edd_license_key' => $license->key,
				'download_id'     => AUTOMATOR_PRO_ITEM_ID,

				// UTM
				'utm_source'      => 'uncanny-automator-pro',
				'utm_medium'      => 'in-plugin',
				'utm_content'      => 'license-page',
			),
			AUTOMATOR_STORE_URL . 'checkout'
		);

		// Contact support URL
		$contact_support_url = add_query_arg(
			array(
				// UTM
				'utm_source' => 'uncanny-automator-pro',
				'utm_medium' => 'in-plugin',
				'utm_content' => 'license-page',
			),
			AUTOMATOR_STORE_URL . 'automator-support'
		);

		// My account URL
		$automator_account_url = add_query_arg(
			array(
				// UTM
				'utm_source' => 'uncanny-automator-pro',
				'utm_medium' => 'in-plugin',
				'utm_content' => 'license-page',
			),
			AUTOMATOR_STORE_URL . 'my-account/licenses'
		);

		// Buy new license URL
		$buy_new_license_url = add_query_arg(
			array(
				// UTM
				'utm_source' => 'uncanny-automator-pro',
				'utm_medium' => 'in-plugin',
				'utm_content' => 'license-page',
			),
			AUTOMATOR_STORE_URL . 'pricing'
		);

		// Get the message we have to show to the user
		$license->notice = (object) array(
			'type'    => 'error',
			'title'   => '',
			'content' => '',
		);

		// Check if the license is active
		if ( $license->success ) {
			// Change the type of the alert
			$license->notice->type = 'success';

			// Set the title
			$license->notice->title = esc_html__( 'Your license is active', 'uncanny-automator-pro' );

			// For the content, check if we have the name and email of the owner
			if ( isset( $license->customer_name ) && isset( $license->customer_email ) ) {
				// Add content
				$license->notice->content .= '<div><strong>' . esc_html__( 'Account:', 'uncanny-automator-pro' ) . '</strong> ' . $license->customer_name . ' (' . $license->customer_email . ')</div>';
			}

			// Plan label — sourced from the free plugin's License_Manager (storefront plan_name with slug fallback).
			// Guard: the helper lives in the free plugin and may be absent on sites running an older free release,
			// and even when present it can return null. Only render the plan line when both are available.
			if ( function_exists( '\Uncanny_Automator\App\Infrastructure\automator_license_manager' ) ) {
				$license_manager = automator_license_manager();
				$plan_label      = null !== $license_manager ? $license_manager->get_resolved_plan_name() : '';
				if ( ! empty( $plan_label ) ) {
					$license->notice->content .= '<div><strong>' . esc_html__( 'Plan:', 'uncanny-automator-pro' ) . '</strong> ' . esc_html( $plan_label ) . '</div>';
				}
			}

			// For the content, check if we have information about the expiration date
			if ( isset( $license->expires ) && ! empty( $license->expires ) ) {
				// Expiration date
				$expiration_date = $license->expires === 'lifetime' ? __( 'Never (Lifetime)', 'uncanny-automator-pro' ) : wp_date( get_option( 'date_format' ), strtotime( $license->expires ) );

				// Add content
				$license->notice->content .= '<div><strong>' . esc_html__( 'Expires:', 'uncanny-automator-pro' ) . '</strong> ' . $expiration_date . '</div>';
			}

			// For the content, check if we have the number of activations left
			if ( isset( $license->activations_left ) && isset( $license->license_limit ) ) {
				// Check if this user has unlimited activations left
				if ( $license->activations_left === 'unlimited' ) {
					// Add content
					$license->notice->content .= '<div><strong>' . esc_html__( 'Activations left:', 'uncanny-automator-pro' ) . '</strong> ' . esc_html__( 'Unlimited', 'uncanny-automator-pro' ) . '</div>';
				} else {
					// Add content
					$license->notice->content .= '<div><strong>' . esc_html__( 'Activations left:', 'uncanny-automator-pro' ) . '</strong> ' . sprintf( __( '%1$d of %2$d', 'uncanny-automator-pro' ), $license->activations_left, $license->license_limit ) . '</div>';
				}
			}
		} else {
			// Add a different message for each license status
			switch ( $license->status ) {

				case 'expired':
					/* translators: 1. The expiration date */
					$license->notice->title = sprintf(
						__( 'Your license key expired on %1$s', 'uncanny-automator-pro' ),
						date_i18n( get_option( 'date_format' ), strtotime( $license->expires, current_time( 'timestamp' ) ) )
					);

					$license->notice->content = sprintf(
					/* translators: 1. "renew your license key" link */
						__( 'Please %1$s', 'uncanny-automator-pro' ),
						// Renew your license key
						sprintf(
							'<a href="%s" target="_blank">%s <uo-icon id="external-link"></uo-icon></a>',
							esc_url( $renew_license_url ),
							esc_html__( 'renew your license key', 'uncanny-automator-pro' )
						)
					);

					break;

				case 'revoked':
					$license->notice->title = __( 'Your license key has been disabled', 'uncanny-automator-pro' );

					$license->notice->content = sprintf(
					/* translators: 1. "contact support" link */
						__( 'Please %1$s for more information.', 'uncanny-automator-pro' ),
						// Renew your license key
						sprintf(
							'<a href="%s" target="_blank">%s <uo-icon id="external-link"></uo-icon></a>',
							esc_url( $contact_support_url ),
							esc_html__( 'contact support', 'uncanny-automator-pro' )
						)
					);

					break;

				case 'missing':
					$license->notice->title = __( 'Your license key is invalid', 'uncanny-automator-pro' );

					$license->notice->content = sprintf(
					/* translators: 1. "visit your account page" link */
						__( 'Please %1$s and verify it.', 'uncanny-automator-pro' ),
						// Renew your license key
						sprintf(
							'<a href="%s" target="_blank">%s <uo-icon id="external-link"></uo-icon></a>',
							esc_url( $automator_account_url ),
							esc_html__( 'visit your account page', 'uncanny-automator-pro' )
						)
					);

					break;

				case 'invalid':
				case 'site_inactive':
					$license->notice->title = esc_html__( 'Your license is not active for this URL', 'uncanny-automator-pro' );

					$license->notice->content = sprintf(
					/* translators: 1. "visit your account page" link */
						__( 'Please %1$s to manage your license key URLs.', 'uncanny-automator-pro' ),
						// Renew your license key
						sprintf(
							'<a href="%s" target="_blank">%s <uo-icon id="external-link"></uo-icon></a>',
							esc_url( $automator_account_url ),
							esc_html__( 'visit your account page', 'uncanny-automator-pro' )
						)
					);

					break;

				case 'item_name_mismatch':
					/* translators: 1. Trademarked term */
					$license->notice->title = sprintf(
						__( 'This appears to be an invalid license key for %1$s.', 'uncanny-automator-pro' ),
						'Uncanny Automator Pro'
					);

					$license->notice->content = sprintf(
					/* translators: 1. "visit your account page" link */
						__( 'Please %1$s to manage your license key URLs.', 'uncanny-automator-pro' ),
						// Renew your license key
						sprintf(
							'<a href="%s" target="_blank">%s <uo-icon id="external-link"></uo-icon></a>',
							esc_url( $automator_account_url ),
							esc_html__( 'visit your account page', 'uncanny-automator-pro' )
						)
					);

					break;

				case 'no_activations_left':
					$license->notice->title = __( 'Your license key has reached its activation limit.', 'uncanny-automator-pro' );

					$license->notice->content = sprintf(
						'<a href="%s" target="_blank">%s <uo-icon id="external-link"></uo-icon></a>',
						esc_url( $buy_new_license_url ),
						esc_html__( 'View possible upgrades', 'uncanny-automator-pro' )
					);

					break;
			}
		}

		// Load the license template
		include Utilities::get_view( 'admin-settings/tab/general/license/pro-license.php' );
	}

	/**
	 * Clear cached license / credits transients.
	 *
	 * Called whenever the Pro license key changes (activate or deactivate) so
	 * downstream gates (e.g. Uncanny Agent settings tab) read fresh state on the
	 * very next request instead of waiting for the natural transient TTL.
	 *
	 * @return void
	 */
	private function flush_license_caches() {
		delete_transient( 'automator_api_license' );
		delete_transient( 'automator_license_check_failed' );
		delete_transient( 'automator_api_credit_data' );
		delete_transient( 'automator_api_credits' );
	}

	/**
	 * API call to activate License
	 *
	 * @since    1.0.0
	 */
	public function activate_license() {

		// listen for our activate button to be clicked
		if ( ! filter_has_var( INPUT_POST, 'uapro_license_activate' ) ) {
			return;
		}

		// run a quick security check
		if ( ! check_admin_referer( 'uapro_nonce', 'uapro_nonce' ) ) {
			return;
		} // get out if we didn't click the Activate button

		if ( ! current_user_can( automator_pro_get_admin_capability() ) ) {
			return;
		}

		$this->flush_license_caches();

		$license_key = filter_input( INPUT_POST, 'uap_automator_pro_license_key' );

		$redirect = $this->get_license_page_url();

		try {
			$response = $this->edd_activate_license( $license_key );
		} catch ( \Exception $e ) {
			$redirect = add_query_arg(
				array(
					'sl_activation' => 'false',
					'message'       => urlencode( $e->getMessage() ),
				),
				$redirect
			);
		}

		wp_redirect( $redirect );
		exit();
	}

	/**
	 * API call to de-activate License
	 *
	 * @since    1.0.0
	 */
	public function deactivate_license() {

		// listen for our activate button to be clicked
		if ( ! filter_has_var( INPUT_POST, 'uapro_license_deactivate' ) ) {
			return;
		}

		// run a quick security check
		if ( ! check_admin_referer( 'uapro_nonce', 'uapro_nonce' ) ) {
			return;
		} // get out if we didn't click the Activate button

		if ( ! current_user_can( automator_pro_get_admin_capability() ) ) {
			return;
		}

		$this->flush_license_caches();

		$license_data = $this->licensing_call( 'deactivate-license' );
		if ( $license_data ) {
			if ( 'deactivated' === $license_data->license || 'failed' === $license_data->license ) {
				automator_update_option( 'uap_automator_pro_license_status', '' );
				automator_update_option( 'uap_automator_pro_license_expiry', 'inactive' );

				return true;
			}
		}
		wp_redirect( $this->get_license_page_url() );
		exit();
	}


	/**
	 * Load Scripts that are specific to the admin page
	 *
	 * @param string $hook Admin page being loaded
	 *
	 * @since 1.0
	 */
	public function admin_scripts( $hook ) {

		if ( 'uo-recipe_page_uncanny-automator-license-activation' === $hook ) {
			wp_enqueue_style( 'uapro-admin-license', Utilities::get_css( 'admin/license.css' ), array(), AUTOMATOR_PRO_PLUGIN_VERSION );
		}
	}


	/**
	 * This is a means of catching errors from the activation method above and displaying it to the customer
	 *
	 * @since    1.0.0
	 */
	public function add_licensing_errors() {

		if ( filter_has_var( INPUT_GET, 'page' ) && $this->page_slug == filter_input( INPUT_GET, 'page' ) ) {

			if ( filter_has_var( INPUT_GET, 'sl_activation' ) && ! empty( filter_input( INPUT_GET, 'error_message' ) ) ) {
				switch ( filter_input( INPUT_GET, 'sl_activation' ) ) {

					case 'false':
						$message = urldecode( esc_html__( wp_kses( filter_input( INPUT_GET, 'error_message' ), array() ), 'uncanny-automator-pro' ) );

						?>
						<uo-alert class="uap-spacing-top" type="error"
								  heading="<?php esc_html_e( 'There was an issue in activating your license:', 'uncanny-automator-pro' ); ?>">

							<?php
							if ( strpos( $message, 'invalid license key for' ) ) {
								$message = str_replace( ' .', ' ' . AUTOMATOR_PRO_ITEM_NAME . '.', $message );
							}
							echo esc_html( $message );
							?>

						</uo-alert>
						<?php

						break;
				}
			}
		}
	}

	/**
	 * API call to check if License key is valid
	 *
	 * The updater class does this for you. This function can be used to do something custom.
	 *
	 * @return null|object|bool
	 * @since    1.0.0
	 * @throws \Exception
	 */
	public function check_license( $force_check = false ) {

		$invalid_license = (object) array(
			'success' => false,
		);

		$status = automator_get_option( 'uap_automator_pro_license_status', '' );

		if ( 'valid' !== $status ) {
			return $invalid_license;
		}

		$license = trim( automator_get_option( 'uap_automator_pro_license_key' ) );

		if ( empty( $license ) ) {
			return $invalid_license;
		}

		$license_data = Api_Server::is_automator_connected( $force_check );

		if ( ! $license_data ) {
			return $invalid_license;
		}

		$license_data = (object) $license_data;

		// Add the success attribute to match EDD responses.
		$license_data->success = false;

		if ( isset( $license_data->license ) && 'valid' === $license_data->license ) {
			$license_data->success = true;
		}

		// this license is still valid
		if ( $license_data->license == 'valid' ) {
			automator_update_option( 'uap_automator_pro_license_status', $license_data->license );

			// Lifetime/perpetual licenses have no expiry. The API strips the null
			// `expires` from the response (sparse-shape parity), so the property is
			// absent on the wire — or, on older records, carries the 'lifetime'
			// sentinel. Normalise a missing/null value to 'lifetime' so the checks
			// below don't warn on an undefined property or pass null to DateTime.
			$expires = $license_data->expires ?? 'lifetime';

			if ( 'lifetime' !== $expires ) {
				automator_update_option( 'uap_automator_pro_license_expiry', $expires );
			} else {
				automator_update_option( 'uap_automator_pro_license_expiry', date( 'Y-m-d H:i:s', mktime( 12, 59, 59, 12, 31, 2099 ) ) );
			}

			if ( 'lifetime' !== $expires ) {
				$expire_notification = new \DateTime( $expires, wp_timezone() );
				automator_update_option( 'uap_automator_pro_license_expiry_notice', $expire_notification );
				if ( wp_get_scheduled_event( 'uapro_notify_admin_of_license_expiry' ) ) {
					wp_unschedule_hook( 'uapro_notify_admin_of_license_expiry' );
				}
				// 1 hour after the license is schedule to expire.
				wp_schedule_single_event( $expire_notification->getTimestamp() + 3600, 'uapro_notify_admin_of_license_expiry' );

			}
		} else {
			automator_update_option( 'uap_automator_pro_license_status', $license_data->license );
			automator_update_option( 'uap_automator_pro_license_expiry', '' );
			// this license is no longer valid
		}
		automator_update_option( 'uap_automator_pro_license_last_checked', time() );

		return $license_data;
	}

	/**
	 * @return void
	 */
	public function clear_field() {

		if ( ! automator_filter_has_var( 'clear_license_field' ) ) {
			return;
		}

		if ( ! automator_filter_has_var( 'page' ) ) {
			return;
		}

		if ( 'uncanny-automator-config' !== automator_filter_input( 'page' ) ) {
			return;
		}

		// run a quick security check
		if ( ! check_admin_referer( 'uapro_nonce', 'uapro_nonce' ) ) {
			return;
		}

		if ( ! current_user_can( automator_pro_get_admin_capability() ) ) {
			return;
		}

		automator_delete_option( 'uap_automator_pro_license_expiry_notice' );
		automator_delete_option( 'uap_automator_pro_license_status' );
		automator_delete_option( 'uap_automator_pro_license_expiry' );
		automator_delete_option( 'uap_automator_pro_license_last_checked' );
		automator_update_option( 'uap_automator_pro_license_key', '' );

		wp_safe_redirect( $this->get_license_page_url() );
		exit;
	}

	/**
	 * Returns the URL of the license page
	 *
	 * @return string The URL of the settings page
	 */
	public function get_license_page_url() {
		return add_query_arg(
			array(
				'post_type' => 'uo-recipe',
				'page'      => 'uncanny-automator-config',
				'tab'       => 'general',
				'general'   => 'license',
			),
			admin_url( 'edit.php' )
		);
	}

	/**
	 * Conditionally updates the license returns error in the form of redirect or array response.
	 *
	 * @param string $license_key
	 * @param bool $should_redirect
	 *
	 * @return true
	 */
	public function edd_activate_license( $license_key = '', $should_redirect = true ) {

		$this->save_license_key( $license_key );
		$this->license = $license_key;

		$license_data = $this->licensing_call( 'activate-license', $should_redirect );

		if ( is_wp_error( $license_data ) ) {
			return $license_data;
		}

		if ( isset( $license_data->license ) && isset( $license_data->expires ) ) {
			automator_update_option( 'uap_automator_pro_license_status', $license_data->license );
			automator_update_option( 'uap_automator_pro_license_expiry', $license_data->expires );
		}

		return true;
	}

	/**
	 * save_license_key
	 *
	 * @param mixed $license_key
	 *
	 * @return bool
	 */
	public function save_license_key( $license_key ) {
		// Save license key
		$license_key = sanitize_text_field( trim( $license_key ) );

		return automator_update_option( 'uap_automator_pro_license_key', $license_key );
	}

	/**
	 * activate_license_in_background
	 *
	 * @param mixed $license_key
	 *
	 * @return void
	 */
	public function activate_license_in_background( $license_key ) {
		try {
			$this->edd_activate_license( $license_key );
			automator_log( 'License activated in the background', 'activate_license_in_background' );
		} catch ( \Exception $e ) {
			automator_log( $e->getMessage(), 'activate_license_in_background' );
		}
	}

	/**
	 * maybe_pre_activate
	 *
	 * @return void
	 */
	public function maybe_pre_activate() {

		if ( 'not-exists' !== automator_get_option( 'uap_automator_pro_license_key', 'not-exists' ) ) {
			return;
		}

		$this->activate_license_in_background( AUTOMATOR_PRO_LICENSE_KEY );
	}

	/**
	 * maybe_pre_activate_multisite
	 *
	 * Push the network license onto a freshly created subsite. Runs at
	 * priority 1000 on `wp_initialize_site` so it fires AFTER WP core's
	 * own `wp_initialize_site()` handler (priority 10) has populated the
	 * new blog's options/roles, and after `newblog_notify_siteadmin` /
	 * `wpmu_log_new_registrations` (priority 100). Automator's own
	 * `uap_*` tables still need to exist on the new subsite before
	 * `save_license_key()` can write to them, so we run `create_tables()`
	 * once we're switched in.
	 *
	 * Wrapped in a `finally` so a fatal in the EDD activation never
	 * strands the blog stack.
	 *
	 * @param \WP_Site $new_site
	 *
	 * @return void
	 */
	public function maybe_pre_activate_multisite( $new_site ) {

		switch_to_blog( (int) $new_site->blog_id );

		try {
			if ( class_exists( '\Uncanny_Automator\Automator_DB' ) ) {
				\Uncanny_Automator\Automator_DB::create_tables();
			}

			$this->activate_license_in_background( AUTOMATOR_PRO_LICENSE_KEY );
		} finally {
			restore_current_blog();
		}
	}

	/**
	 * @param $endpoint
	 *
	 * @return false|mixed|void|null
	 */
	public function licensing_call( $endpoint = 'check-license', $should_redirect = true ) {

		if ( empty( $this->license ) ) {

			$license = trim( automator_get_option( 'uap_automator_pro_license_key' ) );

			if ( empty( $license ) ) {
				return false;
			}

			$this->license = $license;

		}

		// Check if Free method exists.
		if ( method_exists( '\Uncanny_Automator\Admin_Menu', 'licensing_call' ) ) {
			return \Uncanny_Automator\Admin_Menu::licensing_call( $endpoint, $this->license, AUTOMATOR_PRO_ITEM_ID, AUTOMATOR_LICENSING_URL, $should_redirect );
		}

		$data = array(
			'license' => $this->license,
			'item_id' => $this->item_id,
			'url'     => home_url(),
		);

		// Convert data to JSON
		// Convert array to JSON and then encode it with Base64
		$encoded_data = base64_encode( wp_json_encode( $data ) ); //phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode

		// Call the custom API.
		$response = wp_remote_post(
			$this->store_url . $endpoint,
			array(
				'timeout'   => 10,
				'body'      => '',
				'headers'   => array(
					'X-UO-Licensing'   => $encoded_data,
					'X-UO-Destination' => 'ap',
				),
				'sslverify' => true,
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			$error = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $response ) ) {
				$error = $response->get_error_message();
			}

			$query_params = array(
				'sl_activation' => 'false',
				'error_message' => urlencode( $error ),
			);

			$redirect = add_query_arg( $query_params, $this->get_license_page_url() );

			if ( $should_redirect ) {
				wp_safe_redirect( $redirect );
				exit();
			}

			return new WP_Error( 400, 'Invalid license', $query_params );

		}

		return json_decode( wp_remote_retrieve_body( $response ) );
	}
}
