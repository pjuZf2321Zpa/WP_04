<?php
/**
 * Orphan_Recovery_Admin
 *
 * Registers the "Action Recovery" sub-tab under Status > Tools and renders the
 * diagnostic view for the async orphan recovery engine.
 *
 * @package Uncanny_Automator_Pro
 */

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Services\Action_Scheduler;

/**
 * Class Orphan_Recovery_Admin
 *
 * @package Uncanny_Automator_Pro
 */
class Orphan_Recovery_Admin {

	/**
	 * Option key holding the cached scan buckets (written by Task 3).
	 *
	 * @var string
	 */
	const SCAN_OPTION = 'automator_async_orphan_scan';

	/**
	 * Constructor.
	 *
	 * Registers the "Action Recovery" tab on the Status (Admin Tools) page, the
	 * asset enqueue, and the REST routes.
	 */
	public function __construct() {
		add_filter( 'automator_admin_tools_tools_tabs', array( $this, 'register_tab' ), 20, 1 );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Registers the REST routes that drive the recovery sub-tab.
	 *
	 * One POST route per former AJAX handler, under the Automator REST namespace.
	 * The wp_rest nonce is sent by the frontend via the X-WP-Nonce header (core
	 * validates it); the permission callback is the capability gate.
	 *
	 * @return void
	 */
	public function register_rest_routes() {
		$perm   = function () {
			return current_user_can( automator_pro_get_admin_capability() );
		};
		$routes = array(
			'orphan_recovery_scan'         => 'rest_scan',
			'orphan_recovery_restore'      => 'rest_restore',
			'orphan_recovery_undatable'    => 'rest_undatable',
			'orphan_recovery_test_pick'    => 'rest_test_pick',
			'orphan_recovery_test_recover' => 'rest_test_recover',
		);
		foreach ( $routes as $route => $method ) {
			register_rest_route(
				AUTOMATOR_REST_API_END_POINT,
				'/' . $route . '/',
				array(
					'methods'             => 'POST',
					'permission_callback' => $perm,
					'callback'            => array( $this, $method ),
				)
			);
		}
	}

	/**
	 * Enqueues the recovery sub-tab CSS/JS and localizes the REST config.
	 *
	 * Gated to Status > Tools (where the preloaded "Scheduled actions recovery"
	 * sub-tab panel lives).
	 *
	 * @param string $hook The current admin page hook suffix.
	 *
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if (
			false === strpos( (string) $hook, 'uncanny-automator-admin-tools' )
			|| 'tools' !== automator_filter_input( 'tab' )
		) {
			return;
		}
		wp_enqueue_style( 'uap-orphan-recovery', Utilities::get_css( 'admin/orphan-recovery.css' ), array(), AUTOMATOR_PRO_PLUGIN_VERSION );
		wp_enqueue_script( 'uap-orphan-recovery', Utilities::get_js( 'admin/orphan-recovery.js' ), array( 'jquery', 'wp-api-fetch' ), AUTOMATOR_PRO_PLUGIN_VERSION, true );
		wp_localize_script(
			'uap-orphan-recovery',
			'uapOrphanRecovery',
			array(
				'rest_namespace' => AUTOMATOR_REST_API_END_POINT,
				'nonce'          => wp_create_nonce( 'wp_rest' ),
				// NOTE: every string here is rendered client-side via jQuery .text()
				// (never .html()), which escapes on insertion. So these use __() — NOT
				// esc_html__(), which would double-encode (e.g. an apostrophe → &#039;).
				'i18n'           => array(
					'confirm'    => __( 'This will reschedule the recoverable scheduled actions. Continue?', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'scanning'   => __( 'Scanning…', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'running'    => __( 'Restoring…', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'done'       => __( 'Done.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'stopped'    => __( 'Stopped.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: 1: number of rows scanned so far, 2: total candidate rows. Both already locale-formatted. */
					'scannedOf'  => __( 'Scanned %1$s of %2$s…', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: %s: number of action-log rows scanned so far (locale-formatted). */
					'scanned'    => __( 'Scanned %s so far…', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'error'      => __( 'Something went wrong. Please try again.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'leaveWarn'  => __( 'A recovery operation is still running. Leaving this page will stop it.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: 1: restored count, 2: expired count, 3: healthy/left-untouched count. */
					'totals'     => __( 'Restored %1$d, expired %2$d, healthy %3$d.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: 1: recoverable count, 2: healthy count, 3: expired count. All locale-formatted. */
					'summary'    => __( '✔ %1$s recoverable (Stuck + Failed) · %2$s healthy · %3$s expired', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'pending'    => __( 'Stuck', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'finalized'  => __( 'Failed', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'healthy'    => __( 'Healthy', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'expired'    => __( 'Expired', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'descPending'   => __( 'Queued, but the data was wiped. Actions will be restored to run on schedule.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'descFinalized' => __( 'Marked failed by the cleanup. Actions will be restored to run on schedule.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'descHealthy'   => '',
					/* translators: %d: grace window in days. */
					'descExpired'   => __( 'Over %d days overdue. Skipping.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testPick'      => __( 'Find a test candidate', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testRecover'   => __( 'Recover this candidate', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testNone'      => __( 'No recoverable Failed actions found.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: %s: async mode (delay/schedule/custom). */
					'testNoneMode'  => __( 'No recoverable Failed %s action found. Try another mode.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testInspect'   => __( "Open the recipe logs to see this action's current (failed) state, then recover.", 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testInvalid'   => __( 'This action is no longer a recoverable Failed orphan. Try finding another candidate.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testAfterNote' => __( 'Recovered. Refresh the recipe logs to see it flip to in-progress/scheduled.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'viewLogs'      => __( 'View recipe logs →', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'user'          => __( 'User', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'recipe'        => __( 'Recipe', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'recipeStart'   => __( 'Recipe start', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'mode'          => __( 'Mode', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'schedule'      => __( 'Schedule', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'wouldRun'      => __( 'Would run', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'logPurged'     => __( '(run log purged)', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'before'        => __( 'Before', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'after'         => __( 'After', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testMode'         => __( 'Mode', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testWouldRun'     => __( 'Would run', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'testWouldRunNever' => __( 'Would not run', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'undatable'        => __( 'Unknown date', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'undatableDesc'    => __( "Couldn't resolve the scheduled date (custom/schedule token). Choose what to do with these.", 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'attemptNow'       => __( 'Attempt now', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'skip'             => __( 'Skip', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'attemptConfirm'   => __( "Reschedule the undatable actions to run shortly? They'll fire soon, not on a specific date.", 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'viewInAS'         => __( 'View in Action Scheduler →', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: 1: expired-by-delay count, 2: expired-by-schedule count, 3: expired-by-custom count. All locale-formatted. The \n render one per line (CSS white-space: pre-line). */
					'expiredByMode'    => __( "Expired by mode:\n%1\$s delay\n%2\$s schedule\n%3\$s custom", 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					/* translators: 1: attempted count, 2: skipped count, 3: passed count. */
					'undatableTotals'  => __( 'Attempted %1$d, skipped %2$d, passed %3$d.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
					'rescanHint'       => __( 'Re-scan to refresh the counts.', 'uncanny-automator-pro' ), // phpcs:ignore Uncanny_Automator.Strings.TranslationFunction.UnescapedTranslation, Uncanny_Automator.Strings.AutoContextTranslation.MissingContext -- plain text the script writes with .text() or window.confirm(); escaping would double-encode.
				),
			)
		);
	}

	/**
	 * Registers the "Scheduled actions recovery" sub-tab under Status (Admin Tools)
	 * → Tools, alongside Database.
	 *
	 * @param array $tabs The registered Tools sub-tabs.
	 *
	 * @return array
	 */
	public function register_tab( $tabs ) {
		$tabs['recovery'] = (object) array(
			'name'     => esc_html__( 'Scheduled actions recovery', 'uncanny-automator-pro' ),
			'function' => array( $this, 'render_tab' ),
			// Preloaded so the panel is always in the DOM. The Tools sidebar switches
			// sub-tabs client-side; a non-preloaded sub-tab would instead deep-link to a
			// (non-existent) top-level tab and break. Mirrors how Database behaves.
			'preload'  => true,
		);

		return $tabs;
	}

	/**
	 * Renders the recovery sub-tab panel body.
	 *
	 * Rendered inside the Admin Tools page's <uo-tab-panel>, so it outputs the
	 * panel body only (no page chrome).
	 *
	 * @return void
	 */
	public function render_tab() {

		if ( ! current_user_can( automator_pro_get_admin_capability() ) ) {
			return;
		}

		$scan = get_option( self::SCAN_OPTION, array() );

		if ( ! is_array( $scan ) ) {
			$scan = array();
		}

		include Utilities::get_view( 'recovery/recovery-page.php' );
	}

	/**
	 * Accumulates a single scan batch into the running scan totals.
	 *
	 * Pure function: sums the bucket counts, carries the latest cursor, and marks
	 * the scan complete once a batch reports no further rows.
	 *
	 * @param array $running The running totals carried between batches.
	 * @param array $batch   A single batch result from scan_counts().
	 *
	 * @return array{pending:int,finalized:int,healthy:int,expired:int,undatable:int,expired_delay:int,expired_schedule:int,expired_custom:int,scanned:int,last_id:int,complete:bool}
	 */
	public function merge_scan( $running, $batch ) {
		$keys = array( 'pending', 'finalized', 'healthy', 'expired', 'undatable', 'expired_delay', 'expired_schedule', 'expired_custom', 'scanned' );
		$out  = array();
		foreach ( $keys as $k ) {
			$out[ $k ] = (int) ( isset( $running[ $k ] ) ? $running[ $k ] : 0 ) + (int) ( isset( $batch[ $k ] ) ? $batch[ $k ] : 0 );
		}
		$out['last_id']  = (int) $batch['last_id'];
		$out['complete'] = empty( $batch['has_more'] );

		return $out;
	}

	/**
	 * Applies the user-settable grace window (in days) to the recovery engine for
	 * THIS request only.
	 *
	 * Clamps the given grace_days to 0..100 years, and hooks the
	 * automator_orphan_recovery_grace_seconds filter so resolve_run_time() (and the
	 * scan that reclassifies expired vs recoverable) honor the chosen window. Each
	 * REST request is its own PHP process, so the filter is scoped to that request.
	 *
	 * @param int $grace_days The requested grace window in days.
	 *
	 * @return void
	 */
	private function apply_grace_window( int $grace_days ) {
		$grace_days = max( 0, min( 36500, $grace_days ) ); // 0..100 years.
		add_filter(
			'automator_orphan_recovery_grace_seconds',
			function () use ( $grace_days ) {
				return $grace_days * DAY_IN_SECONDS;
			}
		);
	}

	/**
	 * REST handler: scans a batch of process action-log rows and accumulates the
	 * bucket counts into the cached scan option.
	 *
	 * @param \WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_scan( \WP_REST_Request $request ) {
		$this->apply_grace_window( (int) $request->get_param( 'grace_days' ) );

		$last_id = (int) $request->get_param( 'last_id' );
		$engine  = new Async_Orphan_Recovery();
		$batch   = max( 1, (int) apply_filters( 'automator_orphan_scan_batch_size', 500 ) );
		$result  = $engine->scan_counts( $last_id, $batch );

		$running              = ( 0 === $last_id ) ? array() : (array) get_option( self::SCAN_OPTION, array() );
		$merged               = $this->merge_scan( $running, $result );
		$merged['scanned_at'] = time();
		update_option( self::SCAN_OPTION, $merged, false );

		$payload = array(
			'counts'   => $merged,
			'last_id'  => $result['last_id'],
			'has_more' => (bool) $result['has_more'],
		);

		// On a fresh scan only, hand the JS the candidate total so it can render
		// "Scanned N of M" and drive a determinate progress bar (it caches it).
		if ( 0 === $last_id ) {
			$payload['total'] = $engine->count_candidates();
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * REST handler: restores a batch of orphaned scheduled actions.
	 *
	 * @param \WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_restore( \WP_REST_Request $request ) {
		$this->apply_grace_window( (int) $request->get_param( 'grace_days' ) );

		$last_id = (int) $request->get_param( 'last_id' );
		$batch   = max( 1, (int) apply_filters( 'automator_orphan_restore_batch_size', 100 ) );
		$tally   = ( new Async_Orphan_Recovery() )->restore_batch( $last_id, $batch );

		return rest_ensure_response(
			array(
				'tally'    => $tally,
				'last_id'  => $tally['last_id'],
				'has_more' => (bool) $tally['has_more'],
			)
		);
	}

	/**
	 * REST handler: processes one batch of the bulk Undatable action — either rescheduling the
	 * undatable orphans to run shortly ('attempt') or marking them admin-skipped ('skip').
	 *
	 * @param \WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_undatable( \WP_REST_Request $request ) {
		$this->apply_grace_window( (int) $request->get_param( 'grace_days' ) );

		$last_id = (int) $request->get_param( 'last_id' );

		// Sanitize the mode to exactly 'skip' or 'attempt' (default 'skip').
		$mode = (string) $request->get_param( 'mode' );
		$mode = 'attempt' === $mode ? 'attempt' : 'skip';

		$batch = max( 1, (int) apply_filters( 'automator_orphan_undatable_batch_size', 100 ) );
		$r     = ( new Async_Orphan_Recovery() )->process_undatable_batch( $last_id, $batch, $mode );

		return rest_ensure_response(
			array(
				'tally'    => $r,
				'last_id'  => $r['last_id'],
				'has_more' => (bool) $r['has_more'],
			)
		);
	}

	/**
	 * REST handler (step 1, READ-ONLY): surface ONE Failed orphan and a recipe-logs link
	 * so the site owner can inspect its current (failed) state BEFORE recovering. Mutates
	 * nothing.
	 *
	 * @param \WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_test_pick( \WP_REST_Request $request ) {
		$this->apply_grace_window( (int) $request->get_param( 'grace_days' ) );

		// Optional async-mode constraint (delay|schedule|custom); the engine allowlists it.
		$mode      = (string) $request->get_param( 'mode' );
		$candidate = ( new Async_Orphan_Recovery() )->pick_test_candidate( $mode );

		if ( ! empty( $candidate ) ) {
			$log_exists                        = ! empty( $candidate['recipe_log_exists'] );
			$candidate['recipe_logs_url']      = $this->log_dialog_url( $candidate['recipe_id'], $candidate['recipe_log_id'], $candidate['run_number'], $candidate['user_id'], $log_exists );
			$candidate['recipe_log_available'] = $log_exists;
		}

		return rest_ensure_response( array( 'candidate' => $candidate ) );
	}

	/**
	 * REST handler (step 2): really recover THAT exact candidate row via the production
	 * engine and return a before/after report. The engine re-validates the id is still a
	 * recoverable Failed orphan before touching it.
	 *
	 * @param \WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_test_recover( \WP_REST_Request $request ) {
		$this->apply_grace_window( (int) $request->get_param( 'grace_days' ) );

		$id     = (int) $request->get_param( 'action_log_id' );
		$report = ( new Async_Orphan_Recovery() )->test_restore_action( $id );

		if ( ! empty( $report['ok'] ) ) {
			$log_exists                     = ! empty( $report['recipe_log_exists'] );
			$report['recipe_logs_url']      = $this->log_dialog_url( $report['recipe_id'], $report['recipe_log_id'], $report['run_number'], $report['user_id'], $log_exists );
			$report['recipe_log_available'] = $log_exists;

			// Deep-link the NEW Action Scheduler job (searchable by its hash arg), so the owner
			// can confirm the rescheduled job exists in tools.php?page=action-scheduler.
			$new_job_id = isset( $report['after']['async_job_id'] ) ? (int) $report['after']['async_job_id'] : 0;
			if ( $new_job_id > 0 && Action_Scheduler::is_available() ) {
				$job = Action_Scheduler::fetch_action( $new_job_id );
				if ( null !== $job ) {
					$args = $job->get_args();
					$hash = (string) ( isset( $args[0] ) ? $args[0] : '' );
					if ( '' !== $hash ) {
						$report['as_url'] = add_query_arg(
							array(
								'page'    => 'action-scheduler',
								'orderby' => 'schedule',
								'order'   => 'desc',
								's'       => $hash,
							),
							admin_url( 'tools.php' )
						);
					}
				}
			}
		}

		return rest_ensure_response( array( 'report' => $report ) );
	}

	/**
	 * Build the recipe-log URL.
	 *
	 * When the recipe-log row still exists, return the URL that auto-opens the run's detail
	 * dialog (matches the UOA-tokens log-url format: recipe_id filter + log_dialog_id/
	 * log_recipe_id/log_run_number). When it was purged, drop the log_dialog_* params and
	 * land on the filtered logs LIST instead — never link to a dialog that cannot open.
	 *
	 * @param int  $recipe_id
	 * @param int  $recipe_log_id
	 * @param int  $run_number
	 * @param int  $user_id           The action's user, to filter the log list down.
	 * @param bool $recipe_log_exists Whether the uap_recipe_log row still exists.
	 *
	 * @return string
	 */
	private function log_dialog_url( $recipe_id, $recipe_log_id, $run_number, $user_id = 0, $recipe_log_exists = true ) {

		// Filter by recipe AND user so the (often huge) log list is trimmed enough for the
		// run's row to render — otherwise the details button has no modal markup to open.
		$base = array(
			'post_type'     => 'uo-recipe',
			'page'          => 'uncanny-automator-admin-logs',
			'recipe_id'     => (int) $recipe_id,
			'user_id'       => (int) $user_id,
			'filter_action' => 'Filter',
			'tab'           => 'recipe',
		);

		// Purged run: no dialog to open — land on the filtered logs list (no dead modal).
		if ( ! $recipe_log_exists ) {
			return add_query_arg( $base, admin_url( 'edit.php' ) );
		}

		return add_query_arg(
			array_merge(
				$base,
				array(
					'log_dialog_id'  => (int) $recipe_log_id,
					'log_recipe_id'  => (int) $recipe_id,
					'log_run_number' => (int) $run_number,
				)
			),
			admin_url( 'edit.php' )
		);
	}
}
