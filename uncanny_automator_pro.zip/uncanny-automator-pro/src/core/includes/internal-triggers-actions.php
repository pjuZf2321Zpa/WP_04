<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Set_Up_Automator;
use Uncanny_Automator_Pro\Integration_Loader\Pro_Addon_Loader;

/**
 * Class Internal_Triggers_Actions
 *
 * Orchestrates Pro integration loading. When Free's Addon_Registry API is
 * available (Free >= 7.2), delegates to Pro_Addon_Loader. Otherwise falls
 * back to the manual merge methods in this class.
 *
 * @package Uncanny_Automator_Pro
 */
class Internal_Triggers_Actions {
	/**
	 * @var array
	 */
	public $all_integrations = array();

	/**
	 * @var string
	 */
	public $integrations_directory_path;

	/**
	 * Pro_Addon_Loader instance (null when Free < 7.2).
	 *
	 * @var Pro_Addon_Loader|null
	 */
	private $addon_loader = null;

	/**
	 * @throws \Uncanny_Automator\Automator_Exception
	 */
	public function __construct() {
		// Path of the Pro integration directory
		$this->integrations_directory_path = dirname( AUTOMATOR_PRO_FILE ) . '/src/integrations';

		// Load Pro's integration file map (cached).
		$integrations = Automator()->cache->get( 'automator_pro_get_all_integrations' );

		if ( empty( $integrations ) || ! $this->is_mapped_from_this_folder( $integrations ) ) {
			$map_file = dirname( AUTOMATOR_PRO_FILE ) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'composer' . DIRECTORY_SEPARATOR . 'autoload_integrations_map.php';

			if ( file_exists( $map_file ) ) {
				$integrations = include $map_file;
			} else {
				$legacy_integrations = new Pro_Legacy_Integrations();
				$integrations        = $legacy_integrations->generate_integrations_file_map();
			}
			Automator()->cache->set( 'automator_pro_get_all_integrations', $integrations, 'automator', Automator()->cache->long_expires );
		}

		$this->all_integrations = apply_filters( 'automator_pro_integrations_setup', $integrations );

		// ──────────────────────────────────────────────
		// Addon Registry API (Free >= 7.2)
		//
		// When Free ships the Addon_Registry class, Pro delegates to
		// Pro_Addon_Loader which composes Free's Addon_Registry and
		// encapsulates all Pro-specific config (vendor paths, filemap
		// detection, framework fallback).
		//
		// When Addon_Registry is absent (older Free), this class falls
		// back to the manual merge methods: merge_pro_files_into_free(),
		// register_pro_only_integrations(), and merge_pro_item_map().
		//
		// TODO: Phase 3 cleanup — Once Free >= 7.2 is the minimum
		// required version for Pro, remove the legacy fallback entirely:
		//   1. Delete the $addon_loader null check and the else branch
		//   2. Delete merge_pro_files_into_free(),
		//      register_pro_only_integrations(), merge_pro_item_map(),
		//      finalize_directory_merge(), init(),
		//      load_framework_integrations(), get_framework_file_map()
		//   3. Keep only register_via_addon_loader() as the sole init hook
		//   4. The wire_pro_helper_chains() hook stays (both paths need it)
		// See: Pro's src/core/integration-loader/class-pro-addon-loader.php
		// ──────────────────────────────────────────────
		if ( class_exists( 'Uncanny_Automator\\Integration_Loader\\Addon_Registry' ) ) {
			$this->addon_loader = new Pro_Addon_Loader( dirname( AUTOMATOR_PRO_FILE ) );
			add_action( 'automator_add_integration', array( $this, 'register_via_addon_loader' ), 11 );
		} else {
			// Legacy path: manual merge + hooks.
			add_filter( 'automator_item_map', array( $this, 'merge_pro_item_map' ) );
			add_action( 'automator_add_integration', array( $this, 'init' ), 11 );
		}

		// Both paths need this — finalize_directory_merge adds Pro-contributed types
		// (conditions, loop-filters) to Free's directories_to_include for shared integrations.
		// TODO: Phase 3 cleanup — Move this logic into Addon_Registry so addons don't
		// need a separate hook. The registry would accept a 'directory_types' config key
		// and merge them during register().
		add_action( 'automator_after_add_integrations', array( $this, 'finalize_directory_merge' ), 11 );

		// Both paths need this — wires Pro helper →pro chains after Free loads helpers.
		add_action( 'automator_add_integration_helpers', array( $this, 'wire_pro_helper_chains' ), 11 );
	}

	/**
	 * Whether a cached integration file map was built from this plugin folder.
	 *
	 * The map lists every one of Pro's integration files, and they all sit under
	 * its integrations folder. A map that holds none of them was built for another
	 * plugin folder (the folder was moved or renamed, or the object cache was
	 * copied from another site), so its absolute paths point there.
	 *
	 * @since 8.0.0
	 *
	 * @param mixed $integrations Cached integration file map.
	 *
	 * @return bool
	 */
	private function is_mapped_from_this_folder( $integrations ) {

		$integrations_folder = trailingslashit( wp_normalize_path( $this->integrations_directory_path ) );

		$files = new \RecursiveIteratorIterator( new \RecursiveArrayIterator( (array) $integrations ) );

		foreach ( $files as $file ) {
			if ( is_string( $file ) && 0 === strpos( wp_normalize_path( $file ), $integrations_folder ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get the Pro_Addon_Loader instance.
	 *
	 * Returns null when Free < 7.2 (Addon_Registry not available).
	 *
	 * @return Pro_Addon_Loader|null
	 */
	public function get_addon_loader() {
		return $this->addon_loader;
	}

	/**
	 * Register Pro via Pro_Addon_Loader → Free's Addon_Registry API.
	 *
	 * Pro_Addon_Loader handles config building, vendor path detection,
	 * item map/filemap attachment, and framework integration fallback.
	 * This method is the hook callback that fires backward-compatible actions.
	 *
	 * @since Pro 7.2
	 *
	 * @return void
	 */
	public function register_via_addon_loader() {

		$this->addon_loader->register( $this->all_integrations );

		// Backward-compatible hooks.
		do_action_deprecated( 'uncanny_automator_pro_loaded', array(), '3.9', 'automator_pro_loaded' );
		do_action( 'automator_pro_loaded' );
	}

	/**
	 * @throws \Exception
	 */
	public function init() {
		// Merge Pro file arrays into Free's static structures.
		$this->merge_pro_files_into_free();

		// Register Pro-only integrations into Free's statics.
		$this->register_pro_only_integrations();

		// Load modern framework integrations (extends \Uncanny_Automator\Integration).
		if ( class_exists( 'Uncanny_Automator\Integration' ) ) {
			$this->load_framework_integrations();
		}

		// Keep existing filters and actions for backwards compatibility.
		do_action_deprecated( 'uncanny_automator_pro_loaded', array(), '3.9', 'automator_pro_loaded' );
		do_action( 'automator_pro_loaded' );
	}

	/**
	 * Merge Pro file arrays into Free's static structures for shared integrations.
	 *
	 * @return void
	 */
	private function merge_pro_files_into_free() {
		$file_types = array( 'helpers', 'triggers', 'actions', 'tokens', 'conditions', 'loop-filters' );

		foreach ( $this->all_integrations as $dir_name => $files ) {
			// Only merge shared integrations (already in Free's map).
			if ( ! isset( Set_Up_Automator::$all_integrations[ $dir_name ] ) ) {
				continue;
			}

			foreach ( $file_types as $type ) {
				if ( ! empty( $files[ $type ] ) ) {
					if ( ! isset( Set_Up_Automator::$all_integrations[ $dir_name ][ $type ] ) ) {
						Set_Up_Automator::$all_integrations[ $dir_name ][ $type ] = array();
					}
					Set_Up_Automator::$all_integrations[ $dir_name ][ $type ] = array_merge(
						Set_Up_Automator::$all_integrations[ $dir_name ][ $type ],
						$files[ $type ]
					);
				}
			}

			// Register Pro namespace so Free's get_class_name() resolves correctly.
			Set_Up_Automator::$external_integrations_namespace[ $dir_name ] = 'Uncanny_Automator_Pro';
		}
	}

	/**
	 * Register Pro-only integrations into Free's statics.
	 *
	 * @return void
	 */
	private function register_pro_only_integrations() {
		foreach ( $this->all_integrations as $dir_name => $files ) {
			// Skip shared integrations (already merged above).
			if ( isset( Set_Up_Automator::$all_integrations[ $dir_name ] ) ) {
				continue;
			}

			// Add the entire Pro-only integration to Free's map.
			Set_Up_Automator::$all_integrations[ $dir_name ] = $files;

			// Add to auto_loaded_directories so Free's initialize_add_integrations() picks it up.
			if ( isset( $files['main'] ) ) {
				Set_Up_Automator::$auto_loaded_directories[] = dirname( $files['main'] );
			}

			// Register Pro namespace.
			Set_Up_Automator::$external_integrations_namespace[ $dir_name ] = 'Uncanny_Automator_Pro';
		}
	}

	/**
	 * Finalize directory merging after Free processes all integrations.
	 *
	 * Adds any Pro directory types missing from Free's directories_to_include.
	 * This covers shared integrations where Pro contributes types Free doesn't
	 * declare (e.g. Webhooks Free has no triggers, Pro adds them).
	 *
	 * @param object $free_instance The Free Initialize_Automator instance.
	 *
	 * @return void
	 */
	public function finalize_directory_merge( $free_instance ) {
		// All types Pro may contribute to shared integrations.
		$all_types = array( 'helpers', 'triggers', 'actions', 'tokens', 'conditions', 'loop-filters' );

		foreach ( $this->all_integrations as $dir_name => $files ) {
			// Only process shared integrations that are active in Free's loader.
			// If directories_to_include doesn't exist yet (Free integration has no
			// add_integration_directory_func), initialize it so Pro types get added.
			if ( ! isset( $free_instance->active_directories[ $dir_name ] ) ) {
				continue;
			}

			if ( ! isset( $free_instance->directories_to_include[ $dir_name ] ) ) {
				$free_instance->directories_to_include[ $dir_name ] = array();
			}

			foreach ( $all_types as $type ) {
				if ( ! empty( $files[ $type ] ) && ! in_array( $type, $free_instance->directories_to_include[ $dir_name ], true ) ) {
					$free_instance->directories_to_include[ $dir_name ][] = $type;
				}
			}
		}
	}

	/**
	 * Wire Pro helper →pro chains after Free finishes loading all helpers.
	 *
	 * In the old Pro loader, helpers were stored in Pro's Utilities tracker and
	 * load_pro_recipe_helpers() read from it. Now Free's pipeline loads all helpers
	 * into Free's Utilities tracker, so we read from there and wire the ->pro chains
	 * that actions/triggers depend on (e.g. Automator()->helpers->recipe->wp->options->pro).
	 *
	 * @deprecated Remove this method and its hook registration in __construct() once
	 *             setPro() is fully removed from all helper classes. At that point,
	 *             Pro helpers loaded through Free's pipeline will work without wiring.
	 *
	 * @return void
	 */
	public function wire_pro_helper_chains() {
		// Read from Free's Utilities — that's where all helpers live now.
		$helpers = \Uncanny_Automator\Utilities::get_all_helper_instances();

		if ( empty( $helpers ) ) {
			return;
		}

		foreach ( $helpers as $integration => $helper_instance ) {
			// Only wire Pro helpers — Free helpers are already set by load_helpers_for_recipes().
			$class_name = get_class( $helper_instance );
			if ( false === strpos( $class_name, 'Uncanny_Automator_Pro' ) ) {
				continue;
			}

			if ( ! isset( Automator()->helpers->recipe->$integration ) ) {
				Automator()->helpers->recipe->$integration = $helper_instance;
				if ( method_exists( $helper_instance, 'setOptions' ) ) {
					$helper_instance->setOptions( $helper_instance );
				}
				if ( method_exists( $helper_instance, 'setPro' ) ) {
					$helper_instance->setPro( $helper_instance );
				}
				continue;
			}

			$recipe_helper = Automator()->helpers->recipe->$integration;
			if ( property_exists( $recipe_helper, 'pro' ) && method_exists( $recipe_helper, 'setPro' ) ) {
				$recipe_helper->setPro( $helper_instance );
			}
		}
	}

	/**
	 * Merge Pro's item map into Free's item map for demand-driven loading.
	 *
	 * @param array $map The current (Free) item map.
	 *
	 * @return array Merged item map.
	 */
	public function merge_pro_item_map( $map ) {

		$pro_map_file = dirname( AUTOMATOR_PRO_FILE ) . '/vendor/composer/autoload_item_map.php';

		if ( ! file_exists( $pro_map_file ) ) {
			return $map;
		}

		$pro_map = include $pro_map_file;

		if ( ! is_array( $pro_map ) ) {
			return $map;
		}

		foreach ( $pro_map as $integration_code => $types ) {
			if ( ! isset( $map[ $integration_code ] ) ) {
				$map[ $integration_code ] = $types;
			} else {
				foreach ( $types as $type => $items ) {
					$map[ $integration_code ][ $type ] = array_merge(
						$map[ $integration_code ][ $type ] ?? array(),
						$items
					);
				}
			}
		}

		return $map;
	}

	/**
	 * Prepends loop filters namespace into a class name.
	 *
	 * @param string $class The fully qualified class name of the filter.
	 */
	public function prepend_loop_filter_namespace( $class = '' ) {
		$class = str_replace( 'Uncanny_Automator_Pro\\', '', $class );

		return 'Uncanny_Automator_Pro\\Loop_Filters\\' . $class;
	}

	/**
	 * Get a class name based on file name
	 *
	 * @param $file
	 * @param bool $uppercase
	 *
	 * @return mixed|void
	 */
	public function get_class_name( $file, $uppercase = false ) {
		// Remove file extension my-class-name.php to my-class-name
		$file_name = basename( $file, '.php' );
		// Implode array into class name - eg. array( 'My', 'Class', 'Name') to My_Class_Name
		$class_name = Set_Up_Automator::file_name_to_class( $file_name );
		if ( $uppercase ) {
			$class_name = strtoupper( $class_name );
		}
		$class = __NAMESPACE__ . '\\' . $class_name;

		return apply_filters( 'automator_pro_recipes_class_name', $class, $file, $file_name );
	}

	/**
	 * load_framework_integrations
	 *
	 * Loads Pro framework integrations via load.php files.
	 * Uses pre-built autoload_filemap.php when available (eliminates scandir),
	 * falls back to scandir for dev environments.
	 *
	 * @return void
	 */
	public function load_framework_integrations() {

		$pro_file_map = $this->get_framework_file_map();

		if ( empty( $pro_file_map ) ) {
			return;
		}

		// @todo Next Pro release — consolidate manifest-gating into Free's shared helper.
		//
		// What to do:
		//   1. Delete everything from the "Guard: Free must have Recipe_Manifest" comment
		//      down to the end of this method (the Recipe_Manifest guard, should_load_all()
		//      block, and the targeted-mode foreach loop with get_directory_code_map()).
		//   2. Replace with this single line:
		//      \Uncanny_Automator\Integration_Loader\Addon_Registry::include_gated_files( $pro_file_map );
		//
		// Why:
		//   Free 7.2 added Addon_Registry::include_gated_files() (public static) in
		//   src/core/integration-loader/class-addon-registry.php. It encapsulates the
		//   exact same logic below: Recipe_Manifest guard, should_load_all() check,
		//   get_directory_code_map() targeted loop, and should_include_framework_file().
		//   This eliminates the duplication between this method, Pro_Addon_Loader::
		//   load_framework_integrations_fallback(), and Addon_Registry::load_framework_integrations().
		//
		// Prerequisite:
		//   Free 7.2+ must be the minimum required Free version for this Pro release.
		//   The class_exists guard below handles older Free, but once 7.2 is minimum,
		//   that guard is unnecessary and the whole block can be replaced.
		//
		// Also note:
		//   This entire method (and this class) is the legacy loading path. Once
		//   Pro_Addon_Loader fully replaces Internal_Triggers_Actions, this method
		//   can be removed entirely — Pro_Addon_Loader already delegates to
		//   Addon_Registry::include_gated_files() in its fallback.

		// Guard: Free must have Recipe_Manifest (7.2+). Fall back to full load.
		if ( ! class_exists( '\Uncanny_Automator\Recipe_Manifest' ) ) {
			foreach ( $pro_file_map as $file ) {
				include_once $file;
			}
			return;
		}

		$manifest = \Uncanny_Automator\Recipe_Manifest::get_instance();

		// Full load on: recipe editor, escape hatches, first deploy, or Automator admin pages.
		if ( $manifest->should_load_all() ) {
			foreach ( $pro_file_map as $file ) {
				include_once $file;
			}
			return;
		}

		// Frontend / cron / REST — only include load.php for integrations with active codes.
		$dir_codes = $manifest->get_directory_code_map();

		foreach ( $pro_file_map as $file ) {
			$dir = basename( dirname( $file ) );

			// Directory not in item map — third-party or unmapped, safe fallback: load it.
			if ( ! isset( $dir_codes[ $dir ] ) ) {
				include_once $file;
				continue;
			}

			if ( $manifest->is_integration_needed( $dir_codes[ $dir ] ) ) {
				include_once $file;
			}
		}
	}

	/**
	 * Get the framework file map for Pro integrations.
	 *
	 * Prefers pre-built autoload_filemap.php (generated by Composer post-autoload-dump).
	 * Falls back to scandir() when the filemap is unavailable (dev environments).
	 *
	 * @return string[] Array of absolute paths to load.php files.
	 */
	protected function get_framework_file_map() {

		$filemap_path = dirname( AUTOMATOR_PRO_FILE )
			. DIRECTORY_SEPARATOR . 'vendor'
			. DIRECTORY_SEPARATOR . 'composer'
			. DIRECTORY_SEPARATOR . 'autoload_filemap.php';

		if ( file_exists( $filemap_path ) ) {
			return include $filemap_path;
		}

		// Fallback: runtime scandir when filemap is not generated.
		$files = array();
		$dirs  = scandir( $this->integrations_directory_path );

		if ( empty( $dirs ) ) {
			return $files;
		}

		foreach ( $dirs as $integration ) {
			if ( '.' === $integration || '..' === $integration ) {
				continue;
			}

			$load_file_path = $this->integrations_directory_path
				. DIRECTORY_SEPARATOR . $integration
				. DIRECTORY_SEPARATOR . 'load.php';

			if ( is_file( $load_file_path ) ) {
				$files[] = $load_file_path;
			}
		}

		return $files;
	}
}
