<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator_Pro\App\Transient\Application\Delete_Core_Transients;
use Uncanny_Automator_Pro\App\Transient\Domain\Core_Transient_Keys;
use Uncanny_Automator_Pro\App\Transient\Infrastructure\WP_Transient_Adapter;

/**
 *
 */
class Automator_Pro_Cache_Handler {

	/**
	 * Stores the last Pro version that completed transient cleanup.
	 *
	 * WordPress runs the old plugin code during an update. The new version reads
	 * this marker on its first load and completes cleanup once.
	 */
	const TRANSIENT_CLEANUP_VERSION_OPTION = 'automator_pro_transient_cleanup_version';

	/**
	 * Automator Pro core transient cleanup use case.
	 *
	 * @var Delete_Core_Transients
	 */
	private $delete_core_transients;

	/**
	 *
	 */
	public function __construct() {
		// Load the cleanup classes before a plugin update can replace their files.
		$this->delete_core_transients = new Delete_Core_Transients(
			new WP_Transient_Adapter(),
			Core_Transient_Keys::get_all()
		);
		$this->maybe_delete_outdated_core_transients();

		add_action(
			'automator_cache_reset_integrations_directory',
			array(
				$this,
				'reset_integrations_directory',
			),
			20,
			2
		);
		add_action( 'activated_plugin', array( $this, 'reset_integrations_directory' ), 99999, 2 );
		add_action( 'deactivated_plugin', array( $this, 'plugin_deactivated' ), 99999, 2 );
		add_action( 'upgrader_process_complete', array( $this, 'upgrader_process_completed' ), 999, 2 );

		add_action( 'automator_cache_recipe_post_status_changed', array( $this, 'recipe_post_status_changed' ) );
		add_action( 'transition_post_status', array( $this, 'recipe_post_status_changed' ), 99999, 3 );

		add_action( 'admin_init', array( $this, 'admin_remove_all' ) );
		add_action( 'automator_cache_remove_all', array( $this, 'remove_all' ) );
	}

	/**
	 * @param $plugin
	 * @param $network_wide
	 *
	 * @return void
	 */
	public function reset_integrations_directory( $plugin, $network_wide ) {
		Automator()->cache->remove( 'automator_pro_get_all_integrations' );
	}

	/**
	 * Reset integration caches after plugin deactivation.
	 *
	 * @param string $plugin       The deactivated plugin file.
	 * @param bool   $network_wide Whether WordPress deactivated the plugin for the network.
	 *
	 * @return void
	 */
	public function plugin_deactivated( $plugin, $network_wide ) {
		$this->reset_integrations_directory( $plugin, $network_wide );

		if ( $this->is_automator_pro_plugin( $plugin ) ) {
			$this->delete_core_automator_transients();
			delete_option( self::TRANSIENT_CLEANUP_VERSION_OPTION );
		}
	}

	/**
	 * Clear Automator Pro core transients after an update.
	 *
	 * @param mixed $upgrader The WordPress upgrader instance.
	 * @param array $options  The upgrader hook data.
	 *
	 * @return void
	 */
	public function upgrader_process_completed( $upgrader = null, $options = array() ) {
		foreach ( $this->resolve_updated_plugins( $upgrader, $options ) as $plugin ) {
			if ( $this->is_automator_pro_plugin( $plugin ) ) {
				$this->reset_integrations_directory( $plugin, false );
				$this->delete_core_automator_transients();
				break;
			}
		}
	}

	/**
	 * Get plugin files from a WordPress upgrader event.
	 *
	 * WordPress provides different data for bulk updates, single updates, and
	 * uploaded ZIP replacements. Normalize those forms into one plugin list.
	 *
	 * @param mixed $upgrader The WordPress upgrader instance.
	 * @param array $options  The upgrader hook data.
	 *
	 * @return string[]
	 */
	private function resolve_updated_plugins( $upgrader, $options ) {
		if ( 'plugin' !== ( $options['type'] ?? '' ) ) {
			return array();
		}

		if ( ! in_array( $options['action'] ?? '', array( 'install', 'update' ), true ) ) {
			return array();
		}

		if ( ! empty( $options['plugins'] ) && is_array( $options['plugins'] ) ) {
			return array_values( $options['plugins'] );
		}

		if ( ! empty( $options['plugin'] ) && is_string( $options['plugin'] ) ) {
			return array( $options['plugin'] );
		}

		if ( is_object( $upgrader ) && method_exists( $upgrader, 'plugin_info' ) ) {
			$plugin = $upgrader->plugin_info();

			if ( is_string( $plugin ) && '' !== $plugin ) {
				return array( $plugin );
			}
		}

		return array();
	}

	/**
	 * Determine whether a plugin is Automator Pro.
	 *
	 * @param mixed $plugin The plugin file.
	 *
	 * @return bool
	 */
	private function is_automator_pro_plugin( $plugin ) {
		if ( ! is_string( $plugin ) ) {
			return false;
		}

		return plugin_basename( AUTOMATOR_PRO_FILE ) === str_replace( '\\', '/', $plugin );
	}

	/**
	 * Delete Automator Pro core transients.
	 *
	 * @return void
	 */
	private function delete_core_automator_transients() {
		// TODO: Add deferred network-wide cleanup for multisite lifecycle events.
		$this->delete_core_transients->execute();
	}

	/**
	 * Delete stale transients after the installed Pro version changes.
	 *
	 * The updater executes the previously installed code after it replaces the
	 * plugin files. This check runs when the new code first loads.
	 *
	 * @return void
	 */
	private function maybe_delete_outdated_core_transients() {
		$cleaned_version = (string) get_option( self::TRANSIENT_CLEANUP_VERSION_OPTION, '' );

		if ( AUTOMATOR_PRO_PLUGIN_VERSION === $cleaned_version ) {
			return;
		}

		$this->reset_integrations_directory( null, false );
		$this->delete_core_automator_transients();
		update_option( self::TRANSIENT_CLEANUP_VERSION_OPTION, AUTOMATOR_PRO_PLUGIN_VERSION, true );
	}

	/**
	 * Reset the integration caches when a recipe part changes status.
	 *
	 * Only Automator's recipe post types count, as in Free's cache handler: a status
	 * change on any other post (a published blog post, the revision WordPress saves on
	 * every update, a trashed page) keeps the caches.
	 *
	 * @param mixed ...$args transition_post_status passes ( $new_status, $old_status, $post );
	 *                       automator_cache_recipe_post_status_changed passes those three as one array.
	 *
	 * @return void
	 */
	public function recipe_post_status_changed( ...$args ) {
		if ( isset( $args[0] ) && is_array( $args[0] ) ) {
			$args = $args[0];
		}
		$post = $args[2] ?? null;

		if ( ! $post instanceof \WP_Post || ! $this->is_recipe_part( $post ) ) {
			return;
		}

		$this->reset_integrations_directory( null, null );
	}

	/**
	 * Whether the post is one of Automator's recipe post types.
	 *
	 * @since 8.0.0
	 *
	 * @param \WP_Post $post The post that changed.
	 *
	 * @return bool
	 */
	private function is_recipe_part( \WP_Post $post ) {
		if ( ! function_exists( 'automator_get_recipe_post_types' ) ) {
			return false;
		}

		return in_array( $post->post_type, automator_get_recipe_post_types(), true );
	}

	/**
	 * @return void
	 */
	public function admin_remove_all() {
		if ( ! automator_filter_has_var( 'automator_flush_all' ) ) {
			return;
		}
		if ( ! wp_verify_nonce( automator_filter_input( '_wpnonce' ), AUTOMATOR_BASE_FILE ) ) {
			return;
		}
		$this->remove_all();
	}

	/**
	 * @return void
	 */
	public function remove_all() {
		wp_cache_flush();
		$this->reset_integrations_directory( null, null );
	}
}
