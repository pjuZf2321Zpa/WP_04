<?php

namespace Uncanny_Automator_Pro;

/**
 * Class Automator_Pro_Deferred_User_Login
 *
 * Handles deferred user login when headers have already been sent.
 * This is necessary for "Everyone" recipes that process via the Trigger Engine
 * during AJAX requests or at shutdown, where wp_set_auth_cookie() cannot work directly.
 *
 * Strategy:
 * 1. If headers not sent: direct login immediately
 * 2. If headers sent (AJAX/shutdown): store pending login in transient
 * 3. On next page load (init hook): check for pending login and complete it
 *
 * Uses IP-based identification to ensure consistent matching across all browser
 * contexts (tabs, windows). IP is hashed for privacy and validated on retrieval.
 *
 * @package Uncanny_Automator_Pro
 */
class Automator_Pro_Deferred_User_Login {

	/**
	 * Transient prefix for pending logins.
	 *
	 * @var string
	 */
	const TRANSIENT_PREFIX = 'automator_pending_login_';

	/**
	 * Option key for caching whether deferred login recipes exist.
	 *
	 * @var string
	 */
	const CACHE_OPTION_KEY = 'automator_has_deferred_login_recipes';

	/**
	 * Transient expiry in seconds (5 minutes).
	 *
	 * @var int
	 */
	const TRANSIENT_EXPIRY = 300;

	/**
	 * Maximum number of pending login transients allowed.
	 * Prevents database flooding during attacks.
	 *
	 * @var int
	 */
	const MAX_PENDING_LOGINS = 1000;

	/**
	 * Constructor - Register hooks.
	 */
	public function __construct() {
		// Priority 1: Must run early on init before headers are sent and before
		// other plugins that might redirect or output content. This ensures we can
		// set the auth cookie before any output occurs.
		add_action( 'init', array( $this, 'check_pending_login' ), 1 );

		// Clear cache when recipes are saved or deleted, and on any recipe change
		// Automator reports: a run-as save writes post meta only, so save_post never fires.
		add_action( 'save_post_uo-recipe', array( $this, 'clear_recipe_cache' ) );
		add_action( 'delete_post', array( $this, 'clear_recipe_cache' ) );
		add_action( 'automator_event_recipe_changed', array( $this, 'clear_recipe_cache' ) );
	}

	/**
	 * Clear the cached recipe check.
	 *
	 * @return void
	 */
	public function clear_recipe_cache(): void {
		automator_delete_option( self::CACHE_OPTION_KEY );
	}

	/**
	 * Check if any "Everyone" recipes with "Log user in" enabled exist.
	 *
	 * Uses cached option in uap_options to avoid expensive queries on every page load.
	 * The uap_options system is loaded at plugin file level (no hook), so it's
	 * available well before init:1 where check_pending_login() runs.
	 *
	 * @return bool True if such recipes exist, false otherwise.
	 */
	private static function has_deferred_login_recipes(): bool {
		// Check cache first — uap_options has in-memory + object cache layers.
		$cached = automator_get_option( self::CACHE_OPTION_KEY, null );
		if ( null !== $cached ) {
			return (bool) $cached;
		}

		// Free's run-as store reads every stored shape of the log-in flag.
		$has_recipes = automator_any_published_recipe_logs_user_in();

		// Cache in uap_options with autoload for fast retrieval.
		automator_update_option( self::CACHE_OPTION_KEY, $has_recipes ? 1 : 0, true );

		return $has_recipes;
	}

	/**
	 * Check for pending login on init and perform login if valid.
	 *
	 * @return void
	 */
	public function check_pending_login(): void {
		// Skip if user is already logged in.
		if ( is_user_logged_in() ) {
			return;
		}

		// Skip during AJAX/REST requests - wait for regular page load.
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		// Performance optimization: skip if no recipes use this feature.
		if ( ! self::has_deferred_login_recipes() ) {
			return;
		}

		// Get identifier for this user/client.
		$identifier = self::get_client_identifier();
		if ( empty( $identifier ) ) {
			return;
		}

		// Check for pending login.
		$transient_key = self::TRANSIENT_PREFIX . $identifier;
		$data          = get_transient( $transient_key );
		if ( false === $data ) {
			return;
		}

		// Delete transient immediately (one-time use).
		delete_transient( $transient_key );

		// Validate data structure.
		if ( ! isset( $data['user_id'] ) || ! isset( $data['ip_address'] ) ) {
			return;
		}

		// Validate IP address matches (security check).
		// Silent failure is intentional - IP changes are expected (mobile networks, VPNs).
		$current_ip = self::get_client_ip();
		if ( $data['ip_address'] !== $current_ip ) {
			return;
		}

		// Get the user.
		$user_id = absint( $data['user_id'] );
		$user    = get_user_by( 'ID', $user_id );

		if ( ! $user instanceof \WP_User ) {
			return;
		}

		// Perform the login.
		self::login_user( $user_id, $user );
	}

	/**
	 * Main entry point - decides between direct vs deferred login.
	 *
	 * @param int $user_id The user ID to log in.
	 *
	 * @return void
	 */
	public static function maybe_login_user( int $user_id ): void {
		// Skip if user is already logged in - don't switch their session.
		if ( is_user_logged_in() ) {
			return;
		}

		$user_id = absint( $user_id );

		if ( empty( $user_id ) ) {
			return;
		}

		$user = get_user_by( 'ID', $user_id );

		if ( ! $user instanceof \WP_User ) {
			return;
		}

		// Direct login if headers not yet sent.
		if ( ! headers_sent() ) {
			self::login_user( $user_id, $user );
			return;
		}

		// Headers already sent - store for deferred login on next page load.
		self::store_pending_login( $user_id );
	}

	/**
	 * Set the user as logged in.
	 *
	 * @param int      $user_id The user ID.
	 * @param \WP_User $user    The user object.
	 *
	 * @return void
	 */
	private static function login_user( int $user_id, \WP_User $user ): void {
		wp_set_current_user( $user_id, $user->user_login );
		wp_set_auth_cookie( $user_id );
		do_action( 'wp_login', $user->user_login, $user, false );
	}

	/**
	 * Store pending login for deferred processing.
	 *
	 * @param int $user_id The user ID to be logged in.
	 *
	 * @return bool True if stored successfully, false otherwise.
	 */
	private static function store_pending_login( int $user_id ): bool {
		// Get identifier for this user/client.
		$identifier = self::get_client_identifier();
		if ( empty( $identifier ) ) {
			return false;
		}

		// Safety check: prevent database flooding.
		if ( ! self::check_pending_login_limit() ) {
			return false;
		}

		// Store pending login data.
		$data = array(
			'user_id'    => absint( $user_id ),
			'created_at' => time(),
			'ip_address' => self::get_client_ip(),
		);

		$transient_key = self::TRANSIENT_PREFIX . $identifier;
		set_transient( $transient_key, $data, self::TRANSIENT_EXPIRY );

		return true;
	}

	/**
	 * Get unique identifier for current user/client.
	 *
	 * Uses IP-based identification only. This ensures consistent identification
	 * across all browser contexts (tabs, windows) without relying on session cookies
	 * which may not be shared across new browser windows.
	 *
	 * The IP is hashed with wp_salt() to prevent direct IP exposure in transient keys.
	 *
	 * @return string Client identifier or empty string if unavailable.
	 */
	private static function get_client_identifier(): string {
		$ip = self::get_client_ip();
		if ( ! empty( $ip ) ) {
			return 'ip_' . md5( $ip . wp_salt( 'auth' ) );
		}

		return '';
	}

	/**
	 * Check if we're under the pending login storage limit.
	 *
	 * @return bool True if under limit, false if exceeded.
	 */
	private static function check_pending_login_limit(): bool {
		global $wpdb;

		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::TRANSIENT_PREFIX ) . '%'
			)
		);

		return (int) $count < self::MAX_PENDING_LOGINS;
	}

	/**
	 * Get the client's IP address.
	 *
	 * Checks forwarded headers first to support sites behind proxies/CDNs,
	 * which is standard WordPress practice. The IP is used for client identification
	 * (transient key matching), not for authorization. The actual security comes from
	 * the combination of: client identifier match + IP validation + short TTL (5 min).
	 *
	 * Note: While forwarded headers can be spoofed, exploiting this would require
	 * knowing a pending login exists for a specific IP within the 5-minute window.
	 *
	 * @return string The client IP address or empty string if unavailable.
	 */
	private static function get_client_ip(): string {
		$headers = array(
			'HTTP_CF_CONNECTING_IP', // Cloudflare.
			'HTTP_TRUE_CLIENT_IP',   // Akamai, Cloudflare Enterprise.
			'HTTP_X_REAL_IP',        // nginx.
			'HTTP_CLIENT_IP',
			'HTTP_X_FORWARDED_FOR',
			'REMOTE_ADDR',
		);

		foreach ( $headers as $header ) {
			if ( empty( $_SERVER[ $header ] ) ) {
				continue;
			}

			$ip = sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) );

			// X-Forwarded-For can contain multiple IPs, get the first one.
			if ( strpos( $ip, ',' ) !== false ) {
				$ip = trim( explode( ',', $ip )[0] );
			}

			// Validate it's actually an IP address.
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}

		return '';
	}
}
