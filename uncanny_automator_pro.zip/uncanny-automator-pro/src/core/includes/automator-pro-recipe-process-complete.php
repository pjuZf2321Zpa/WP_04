<?php
namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Automator_Recipe_Process_Complete;
use Uncanny_Automator_Pro\App\User_Selector\Action_Failure_Handler;
use Uncanny_Automator_Pro\App\User_Selector\Field_Parser;
use Uncanny_Automator_Pro\App\User_Selector\Pro_User_Resolver;
use Uncanny_Automator_Pro\App\User_Selector\User_Creator;
use Uncanny_Automator_Pro\App\User_Selector\User_Finder;

/**
 * Handles recipe completion processing for anonymous (Everyone) recipes.
 *
 * Thin registration wrapper that wires the user selector into the Recipe_Runner:
 *
 *  - Pro_User_Resolver is injected into the runner; Trigger_Complete_Stage
 *    calls it to resolve (or create) the recipe user and stamps the outcome
 *    (`do-nothing` / `complete_with_errors` / `user_action_message`) onto the
 *    run args.
 *  - Action_Failure_Handler reads that outcome off the action args and skips +
 *    logs each action when resolution did not yield a usable user.
 *
 * Both pieces are driven by the single resolution the runner performs — there
 * is no separate result-injection step, which keeps the two in lockstep.
 *
 * @package Uncanny_Automator_Pro
 */
class Automator_Pro_Recipe_Process_Complete extends Automator_Recipe_Process_Complete {

	/**
	 * @var Automator_Pro_Recipe_Process_Anon Legacy property — kept for backward compat.
	 */
	public $anon;

	/**
	 * @var Pro_User_Resolver
	 */
	private $user_resolver;

	/**
	 * @var Action_Failure_Handler
	 */
	private $failure_handler;

	/**
	 * Initialize and register hooks.
	 */
	public function __construct() {

		$field_parser  = new Field_Parser();
		$user_creator  = new User_Creator();
		$user_finder   = new User_Finder( $user_creator );

		$this->user_resolver   = new Pro_User_Resolver( $user_creator, $user_finder, $field_parser );
		$this->failure_handler = new Action_Failure_Handler();

		if ( function_exists( 'Automator' ) && null !== Automator()->recipe_runner ) {
			Automator()->recipe_runner->set_user_resolver( $this->user_resolver );
			( new \Uncanny_Automator_Pro\App\Recipe_Runner\Blocks\Bootstrap() )->register( Automator()->recipe_runner );
		}

		add_filter( 'automator_before_action_executed', array( $this->failure_handler, 'maybe_handle_failure' ), 1 );
	}

	/**
	 * Create a standardized error response array.
	 *
	 * @param string $err_message The error message.
	 *
	 * @return array
	 */
	public static function invalid_message( $err_message = '' ) {
		return array(
			'status' => false,
			'data'   => array(
				'error'   => true,
				'message' => $err_message,
			),
		);
	}

	/**
	 * Fetch action logs for a specific recipe run filtered by completion status.
	 *
	 * Used by loops process — must remain static.
	 *
	 * @param int $recipe_id     The recipe ID.
	 * @param int $recipe_log_id The recipe log ID.
	 * @param int $status        The completion status.
	 *
	 * @return array
	 */
	public static function fetch_specific_recipe_log_by_status( $recipe_id, $recipe_log_id, $status ) {

		global $wpdb;

		return (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}uap_action_log WHERE automator_recipe_id = %d AND automator_recipe_log_id = %d AND completed = %d",
				absint( $recipe_id ),
				absint( $recipe_log_id ),
				$status
			),
			ARRAY_A
		);
	}
}
