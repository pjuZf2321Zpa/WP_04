<?php
/**
 * Scheduled Action Recovery sub-tab panel body.
 *
 * Renders the cached diagnostic buckets and the Rescan / Run / Stop controls.
 * Rendered inside the Status > Tools > Action Recovery <uo-tab-panel>, so it
 * outputs the panel body only (no page chrome). Behaviour (AJAX,
 * confirm-before-run, progress) is wired via the localized JS object; this view
 * only renders escaped values.
 *
 * @var array $scan Cached scan buckets keyed pending/finalized/healthy/expired,
 *                  plus an optional "scanned_at" timestamp. Empty until a scan runs.
 *
 * @package Uncanny_Automator_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$has_scan         = ! empty( $scan );
$pending          = isset( $scan['pending'] ) ? (int) $scan['pending'] : 0;
$finalized        = isset( $scan['finalized'] ) ? (int) $scan['finalized'] : 0;
$healthy          = isset( $scan['healthy'] ) ? (int) $scan['healthy'] : 0;
$expired          = isset( $scan['expired'] ) ? (int) $scan['expired'] : 0;
$undatable        = isset( $scan['undatable'] ) ? (int) $scan['undatable'] : 0;
$expired_delay    = isset( $scan['expired_delay'] ) ? (int) $scan['expired_delay'] : 0;
$expired_schedule = isset( $scan['expired_schedule'] ) ? (int) $scan['expired_schedule'] : 0;
$expired_custom   = isset( $scan['expired_custom'] ) ? (int) $scan['expired_custom'] : 0;
$scanned_at       = isset( $scan['scanned_at'] ) ? (int) $scan['scanned_at'] : 0;
$recoverable      = $pending + $finalized;

// Run recovery is only actionable when a scan exists and there is something to restore.
$can_run = $has_scan && $recoverable > 0;
?>
<div class="uap-settings-panel">
	<div class="uap-settings-panel-top">
		<div class="uap-settings-panel-content"><?php // Provides the native 14px body type base (var(--uap-font-size--body-small)). ?>

<p>
	<?php
	echo esc_html__( 'Find and restore scheduled (delayed/async) action payloads that were orphaned and would otherwise never run. Start by scanning to see how many actions fall into each bucket, then run recovery to restore the ones that can still be rescheduled.', 'uncanny-automator-pro' );
	?>
</p>

<div class="uap-orphan-recovery" data-orphan-recovery>

	<?php if ( ! $has_scan ) : ?>

		<p class="uap-orphan-recovery__empty" data-orphan-empty>
			<?php echo esc_html__( 'Run a scan to see counts.', 'uncanny-automator-pro' ); ?>
		</p>

	<?php else : ?>

		<?php if ( $scanned_at > 0 ) : ?>
			<p class="uap-orphan-recovery__scanned-at" data-orphan-scanned-at>
				<?php
				/* translators: %s: human-readable date and time of the last scan. */
				echo esc_html( sprintf( __( 'Last scanned: %s', 'uncanny-automator-pro' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $scanned_at ) ) );
				?>
			</p>
		<?php endif; ?>

		<ul class="uap-orphan-recovery__buckets" data-orphan-buckets>
			<li>
				<strong data-orphan-count="pending"><?php echo esc_html( number_format_i18n( $pending ) ); ?></strong>
				<span><?php echo esc_html__( 'Stuck', 'uncanny-automator-pro' ); ?></span>
				<span class="uap-orphan-recovery__desc"><?php echo esc_html__( 'Queued, but the data was wiped. Actions will be restored to run on schedule.', 'uncanny-automator-pro' ); ?></span>
			</li>
			<li>
				<strong data-orphan-count="finalized"><?php echo esc_html( number_format_i18n( $finalized ) ); ?></strong>
				<span><?php echo esc_html__( 'Failed', 'uncanny-automator-pro' ); ?></span>
				<span class="uap-orphan-recovery__desc"><?php echo esc_html__( 'Marked failed by the cleanup. Actions will be restored to run on schedule.', 'uncanny-automator-pro' ); ?></span>
			</li>
			<li>
				<strong data-orphan-count="healthy"><?php echo esc_html( number_format_i18n( $healthy ) ); ?></strong>
				<span><?php echo esc_html__( 'Healthy', 'uncanny-automator-pro' ); ?></span>
			</li>
			<li>
				<strong data-orphan-count="expired"><?php echo esc_html( number_format_i18n( $expired ) ); ?></strong>
				<span><?php echo esc_html__( 'Expired', 'uncanny-automator-pro' ); ?></span>
				<span class="uap-orphan-recovery__desc" data-orphan-desc-expired><?php echo esc_html( sprintf( __( 'Over %d days overdue. Skipping.', 'uncanny-automator-pro' ), 45 ) ); ?></span>
				<span class="uap-orphan-recovery__expired-modes description" data-orphan-expired-modes>
					<?php
					// \n separated; CSS white-space: pre-line renders each mode on its own line.
					echo esc_html(
						sprintf(
							/* translators: 1: expired-by-delay count, 2: expired-by-schedule count, 3: expired-by-custom count. All locale-formatted. */
							__( "Expired by mode:\n%1\$s delay\n%2\$s schedule\n%3\$s custom", 'uncanny-automator-pro' ),
							number_format_i18n( $expired_delay ),
							number_format_i18n( $expired_schedule ),
							number_format_i18n( $expired_custom )
						)
					);
					?>
				</span>
			</li>
		</ul>

		<uo-alert type="success" class="uap-spacing-bottom">
			<span data-orphan-summary>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: recoverable count, 2: healthy count, 3: expired count. All locale-formatted. */
						__( '%1$s recoverable (Stuck + Failed) · %2$s healthy · %3$s expired', 'uncanny-automator-pro' ),
						number_format_i18n( $recoverable ),
						number_format_i18n( $healthy ),
						number_format_i18n( $expired )
					)
				);
				?>
			</span>
		</uo-alert>

		<div data-orphan-undatable<?php echo $undatable > 0 ? '' : ' hidden'; ?>>
			<uo-alert type="warning" class="uap-spacing-bottom" heading="<?php esc_attr_e( 'Unknown date', 'uncanny-automator-pro' ); ?>">
				<p class="uap-orphan-recovery__undatable-desc description">
					<strong data-orphan-count="undatable"><?php echo esc_html( number_format_i18n( $undatable ) ); ?></strong>
					<?php echo esc_html__( "Couldn't resolve the scheduled date (custom/schedule token). Choose what to do with these.", 'uncanny-automator-pro' ); ?>
				</p>
				<p class="uap-orphan-recovery__undatable-actions">
					<uo-button color="secondary" size="small" data-orphan-undatable-attempt>
						<?php echo esc_html__( 'Attempt now', 'uncanny-automator-pro' ); ?>
					</uo-button>
					<uo-button color="transparent" size="small" data-orphan-undatable-skip>
						<?php echo esc_html__( 'Skip', 'uncanny-automator-pro' ); ?>
					</uo-button>
				</p>
			</uo-alert>
		</div>

	<?php endif; ?>

	<p class="uap-orphan-recovery__grace">
		<label>
			<?php echo esc_html__( 'Recover actions overdue by up to', 'uncanny-automator-pro' ); ?>
			<input type="number" data-orphan-grace value="45" min="0" step="1" class="small-text" aria-describedby="uap-orphan-recovery-grace-hint" />
			<?php echo esc_html__( 'days', 'uncanny-automator-pro' ); ?>
		</label>
		<span id="uap-orphan-recovery-grace-hint" class="uap-orphan-recovery__grace-hint description">
			<?php echo esc_html__( "Default 45. Lower it to be stricter, or raise it to also recover actions whose run time is further in the past (they'll fire late). Re-scan to see the effect.", 'uncanny-automator-pro' ); ?>
		</span>
	</p>

	<p class="uap-orphan-recovery__actions">
		<uo-button color="secondary" data-orphan-scan>
			<uo-icon id="rotate"></uo-icon>
			<?php echo esc_html__( 'Rescan', 'uncanny-automator-pro' ); ?>
		</uo-button>

		<uo-button data-orphan-run<?php echo $can_run ? '' : ' disabled'; ?>>
			<?php echo esc_html__( 'Run recovery', 'uncanny-automator-pro' ); ?>
		</uo-button>

		<uo-button color="secondary" data-orphan-test-pick>
			<uo-icon id="magnifying-glass"></uo-icon>
			<?php echo esc_html__( 'Find a test candidate', 'uncanny-automator-pro' ); ?>
		</uo-button>

		<label class="uap-orphan-recovery__test-mode">
			<span class="screen-reader-text"><?php echo esc_html__( 'Constrain test candidate to async mode', 'uncanny-automator-pro' ); ?></span>
			<select data-orphan-test-mode>
				<option value=""><?php echo esc_html__( 'Any mode', 'uncanny-automator-pro' ); ?></option>
				<option value="delay"><?php echo esc_html__( 'Delay', 'uncanny-automator-pro' ); ?></option>
				<option value="schedule"><?php echo esc_html__( 'Schedule', 'uncanny-automator-pro' ); ?></option>
				<option value="custom"><?php echo esc_html__( 'Custom', 'uncanny-automator-pro' ); ?></option>
			</select>
		</label>

		<uo-button color="danger" data-orphan-stop hidden>
			<?php echo esc_html__( 'Stop', 'uncanny-automator-pro' ); ?>
		</uo-button>
	</p>

	<p class="uap-orphan-recovery__hint">
		<?php echo esc_html__( 'Find a single Failed action and inspect its recipe logs before recovering it.', 'uncanny-automator-pro' ); ?>
	</p>

	<div class="uap-orphan-recovery__test-candidate" data-orphan-test-candidate hidden></div>

	<div class="uap-orphan-recovery__test-result" data-orphan-test-result hidden></div>

	<uo-alert type="error" class="uap-orphan-recovery__caption uap-spacing-top" heading="<?php echo esc_attr__( 'Keep this tab open while scanning or recovering.', 'uncanny-automator-pro' ); ?>"></uo-alert>

	<div class="uap-orphan-recovery__progress" data-orphan-progress hidden>
		<progress value="0" max="100" data-orphan-progress-bar></progress>
		<p class="uap-orphan-recovery__status" data-orphan-status aria-live="polite"></p>
	</div>

	<p class="uap-orphan-recovery__note">
		<?php echo esc_html__( "This only applies if you ran Uncanny Automator Pro 7.2.x through 7.3.x.x (the window affected by the cleanup defect); on other versions there is nothing to recover. It is a best-effort courtesy tool, not a guarantee. Some actions can't be restored: their logs or settings may not have survived, their run date may no longer be resolvable, they may be too far overdue, or their recipe may no longer be active. Anything it restores that is still due in the future is rescheduled to run at its original date and time (when that can be recovered); anything already overdue runs now, which is later than it was originally scheduled. Review the buckets, and try a single test candidate, before running the full recovery.", 'uncanny-automator-pro' ); ?>
	</p>

</div>

		</div><!-- .uap-settings-panel-content -->
	</div><!-- .uap-settings-panel-top -->
</div><!-- .uap-settings-panel -->
