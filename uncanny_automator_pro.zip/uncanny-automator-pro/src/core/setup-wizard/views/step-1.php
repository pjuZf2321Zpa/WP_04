<?php
/**
 * Step 1 for Pro: activate the license.
 *
 * Replaces the free plugin's account screen. The wizard shell (logo, stepper,
 * dashboard link) is rendered by the free plugin; this file is the card body.
 *
 * @see src/core/admin/setup-wizard/src/views/step-1.php
 * @var $this \Uncanny_Automator\Setup_Wizard
 *
 * @since 5.8
 */

use Uncanny_Automator_Pro\Setup_Wizard\Setup_Wizard;

if ( ! defined( 'ABSPATH' ) || ! class_exists( 'Uncanny_Automator\Utilities' ) ) {
	return;
}

// "Later" ends the wizard on the free plugin's Skipped screen. Older free
// releases without screen URLs fall back to the dashboard.
$later_url = method_exists( $this, 'get_screen_uri' )
	? $this->get_screen_uri( 'skipped' )
	: $this->get_automator_dashboard_uri();
?>

<div id="automator-setup-step-1" class="automator-pro-setup-wizard-step-1">

	<div class="automator-setup-wizard__head">
		<h2 class="automator-setup-wizard__title"><?php esc_html_e( 'Activate your Pro license', 'uncanny-automator-pro' ); ?></h2>
	</div>

	<p class="automator-setup-wizard__ticks-intro"><?php esc_html_e( 'Activating your license enables:', 'uncanny-automator-pro' ); ?></p>

	<ul class="automator-setup-wizard__ticks automator-pro-setup-wizard-step-1__ticks">
		<li><?php esc_html_e( 'Unlimited tool uses: Use your AI to manage your site(s) with no daily limits.', 'uncanny-automator-pro' ); ?></li>
		<li><?php esc_html_e( 'Unlimited app credits: Use app integrations like CRMs, social media and Google apps with no per-transaction fees.', 'uncanny-automator-pro' ); ?></li>
		<li><?php esc_html_e( 'Automator Addons (Plus and Elite licenses only)', 'uncanny-automator-pro' ); ?></li>
		<li><?php esc_html_e( 'Plugin updates and priority email support from our team.', 'uncanny-automator-pro' ); ?></li>
	</ul>

	<div class="automator-setup-wizard__card automator-setup-wizard__card--center">
		<p>
			<?php
			printf(
				/* translators: %1$s opens the account link, %2$s closes it. */
				esc_html__( 'Paste the key from your purchase email or %1$syour account%2$s.', 'uncanny-automator-pro' ),
				'<a href="https://automatorplugin.com/my-account/licenses/" target="_blank" rel="noopener">',
				'</a>'
			);
			?>
		</p>

		<form method="POST" action="" id="license_key_form" class="automator-pro-setup-wizard-step-1__form">
			<div class="uap-form-control">
				<label id="license_label" for="license_key">
					<?php esc_html_e( 'Uncanny Automator Pro license key', 'uncanny-automator-pro' ); ?>
				</label>
			</div>
			<div class="uap-form-control">
				<input type="text" id="license_key" autocomplete="off" />
			</div>
			<div class="uap-form-control uap-form-control-bottom">
				<uas-alert id="feedback" class="message-response hidden"></uas-alert>
				<uas-button id="license_key_btn" filled size="lg" class="automator-setup-wizard__cta">
					<?php esc_html_e( 'Activate license', 'uncanny-automator-pro' ); ?>
				</uas-button>
			</div>
		</form>

		<p class="automator-setup-wizard__small">
			<a href="https://automatorplugin.com/knowledge-base/where-can-i-find-my-license-key/" target="_blank" rel="noopener"><?php esc_html_e( 'Where can I find my license key?', 'uncanny-automator-pro' ); ?></a>
		</p>
	</div>

	<div class="automator-setup-wizard__step-nav">
		<span></span>
		<uas-button
			color="transparent"
			size="sm"
			class="automator-setup-wizard__nav-button"
			href="<?php echo esc_url( $later_url ); ?>"
			needs-confirmation
			confirmation-heading="<?php esc_attr_e( 'Are you sure?', 'uncanny-automator-pro' ); ?>"
			confirmation-content="<?php esc_attr_e( "If you don't activate your license, you won't be able to manage your site with your AI, and app integrations and addons won't work.", 'uncanny-automator-pro' ); ?>"
			confirmation-button-label="<?php esc_attr_e( 'Skip for now', 'uncanny-automator-pro' ); ?>"
		><?php esc_html_e( 'Later', 'uncanny-automator-pro' ); ?></uas-button>
	</div>

</div>

<?php
wp_enqueue_script( Setup_Wizard::$script_handler );
?>
