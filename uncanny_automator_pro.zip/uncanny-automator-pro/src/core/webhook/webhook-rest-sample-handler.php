<?php

namespace Uncanny_Automator_Pro;

use WP_REST_Request;
use WP_REST_Response;

/**
 * Webhook_Rest_Sample_Handler
 *
 * Registers temporary REST routes for webhook sample data collection.
 * Active listeners are stored in a single option (object-cached) instead of
 * scattered transient-like options that required a LIKE scan on every request.
 *
 * @package Uncanny_Automator_Pro
 * @since   7.2 Refactored to use a single option registry.
 */
class Webhook_Rest_Sample_Handler {

	/**
	 * Option key for the active sample listeners registry.
	 *
	 * @var string
	 */
	const LISTENERS_KEY = 'automator_webhook_sample_listeners';

	/**
	 * Option key prefix for captured sample field data.
	 *
	 * @var string
	 */
	const FIELDS_PREFIX = 'webhook_sample_fields_';

	/**
	 * How long a sample listener stays active (seconds).
	 *
	 * @var int
	 */
	const LISTENER_TTL = 60;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_sample_routes' ) );
		add_filter( 'automator_item_structural_meta_keys', array( __CLASS__, 'add_sample_structural_key' ) );
	}

	/**
	 * The captured-sample cache written by catch_sample_data() — item
	 * metadata, never a configured field; keep it off the wire fields map.
	 *
	 * @param mixed $keys Structural meta keys collected so far.
	 * @return array
	 */
	public static function add_sample_structural_key( $keys ) {
		$keys[] = 'WEBHOOK_SAMPLE';
		return $keys;
	}

	/**
	 * Register temporary REST routes for active sample listeners.
	 *
	 * Reads from a single object-cached option — zero DB queries on the hot path.
	 * Expired entries are pruned lazily during this check.
	 *
	 * @return void
	 */
	public static function register_sample_routes() {

		$listeners = \automator_get_option( self::LISTENERS_KEY, array() );

		if ( empty( $listeners ) || ! is_array( $listeners ) ) {
			return;
		}

		$now     = time();
		$changed = false;

		foreach ( $listeners as $route_key => $listener ) {

			$age = $now - absint( $listener['created_at'] );

			// Expired — prune and clean up any leftover field data.
			if ( $age > self::LISTENER_TTL ) {
				unset( $listeners[ $route_key ] );
				\automator_delete_option( self::FIELDS_PREFIX . $route_key );
				$changed = true;
				continue;
			}

			// Active — register the temporary route.
			register_rest_route(
				AUTOMATOR_REST_API_END_POINT,
				'/' . $route_key,
				array(
					'methods'             => array( 'POST', 'GET', 'PUT' ),
					'callback'            => array( __CLASS__, 'catch_sample_data' ),
					'args'                => array(),
					'permission_callback' => '__return_true',
				)
			);
		}

		// Persist pruned list if any expired entries were removed.
		if ( $changed ) {
			if ( empty( $listeners ) ) {
				\automator_delete_option( self::LISTENERS_KEY );
			} else {
				\automator_update_option( self::LISTENERS_KEY, $listeners, false );
			}
		}
	}

	/**
	 * Activate a sample listener for a given route.
	 *
	 * Called by the AJAX poll handler when the user clicks "Get sample".
	 *
	 * @param string $route_key   The route key (e.g., 'uap-123-456').
	 * @param string $data_format The expected data format (json, xml, csv, etc.).
	 *
	 * @return void
	 */
	public static function activate_listener( $route_key, $data_format = 'json' ) {

		$listeners = \automator_get_option( self::LISTENERS_KEY, array() );

		if ( ! is_array( $listeners ) ) {
			$listeners = array();
		}

		$listeners[ $route_key ] = array(
			'created_at'  => time(),
			'data_format' => $data_format,
		);

		\automator_update_option( self::LISTENERS_KEY, $listeners, false );
	}

	/**
	 * Deactivate a sample listener and clean up.
	 *
	 * @param string $route_key The route key.
	 *
	 * @return void
	 */
	public static function deactivate_listener( $route_key ) {

		$listeners = \automator_get_option( self::LISTENERS_KEY, array() );

		if ( is_array( $listeners ) && isset( $listeners[ $route_key ] ) ) {
			unset( $listeners[ $route_key ] );

			if ( empty( $listeners ) ) {
				\automator_delete_option( self::LISTENERS_KEY );
			} else {
				\automator_update_option( self::LISTENERS_KEY, $listeners, false );
			}
		}

		\automator_delete_option( self::FIELDS_PREFIX . $route_key );
	}

	/**
	 * Get the captured sample fields for a route, if available.
	 *
	 * @param string $route_key The route key.
	 *
	 * @return array|false The captured fields or false if not yet received.
	 */
	public static function get_captured_fields( $route_key ) {

		$fields = \automator_get_option( self::FIELDS_PREFIX . $route_key, false );

		if ( empty( $fields ) ) {
			return false;
		}

		return $fields;
	}

	/**
	 * Get the data format for an active listener.
	 *
	 * @param string $route_key The route key.
	 *
	 * @return string The data format or 'json' as default.
	 */
	public static function get_listener_data_format( $route_key ) {

		$listeners = \automator_get_option( self::LISTENERS_KEY, array() );

		if ( is_array( $listeners ) && isset( $listeners[ $route_key ]['data_format'] ) ) {
			return $listeners[ $route_key ]['data_format'];
		}

		return 'json';
	}

	/**
	 * Catch incoming webhook sample data.
	 *
	 * @param WP_REST_Request $request The REST request.
	 *
	 * @return WP_REST_Response|\WP_Error A WP_Error (status 400) when an XML body is not well-formed.
	 */
	public static function catch_sample_data( WP_REST_Request $request ) {

		$route     = $request->get_route();
		$params    = $request->get_params();
		$body      = $request->get_body();
		$route_key = self::extract_route_key( $route );

		if ( empty( $route_key ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid route.',
				),
				400
			);
		}

		// Verify this listener is still active.
		$listeners = \automator_get_option( self::LISTENERS_KEY, array() );
		if ( ! is_array( $listeners ) || ! isset( $listeners[ $route_key ] ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Listener expired.',
				),
				410
			);
		}

		if ( empty( $params ) && empty( $body ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No data received.',
				),
				400
			);
		}

		// Parse the incoming data.
		$data_format = $listeners[ $route_key ]['data_format'] ?? 'json';

		if ( ! empty( $body ) && empty( $params ) ) {
			$params = Webhook_Rest_Handler::handle_non_json_type_format( $body, $data_format );
		}

		if ( is_wp_error( $params ) ) {
			return $params;
		}

		$fields = Webhook_Rest_Handler::handle_params( $params, true );

		// Store the parsed fields for the AJAX poller to pick up.
		\automator_update_option( self::FIELDS_PREFIX . $route_key, $fields, false );

		// Save raw sample to trigger postmeta for future reference.
		$trigger_id = self::extract_trigger_id( $route_key );
		if ( $trigger_id > 0 ) {
			$sample = empty( $body ) ? $params : $body;
			update_post_meta( $trigger_id, 'WEBHOOK_SAMPLE', $sample );
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'Sample data received.',
			),
			200
		);
	}

	/**
	 * Extract the route key from a full REST route path.
	 *
	 * @param string $route The full route (e.g., '/uap/v2/uap-123-456').
	 *
	 * @return string The route key or empty string.
	 */
	private static function extract_route_key( $route ) {
		$parts = explode( '/', trim( $route, '/' ) );
		return end( $parts );
	}

	/**
	 * Extract the trigger ID from a route key.
	 *
	 * @param string $route_key The route key (e.g., 'uap-123-456').
	 *
	 * @return int The trigger ID or 0.
	 */
	private static function extract_trigger_id( $route_key ) {
		$parts = explode( '-', $route_key );
		return isset( $parts[2] ) ? absint( $parts[2] ) : 0;
	}
}
