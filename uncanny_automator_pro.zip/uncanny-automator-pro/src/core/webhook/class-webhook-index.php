<?php
/**
 * Webhook Index
 *
 * Pre-computed, event-driven cache mapping webhook routes to trigger/recipe metadata.
 * Eliminates the expensive get_recipes() + get_recipes_data() queries that previously
 * ran on every rest_api_init — even for non-webhook requests.
 *
 * Zero queries at runtime — reads from uap_options (already object-cached).
 * Rebuilt via wp_after_insert_post when recipe/trigger posts change.
 *
 * @package Uncanny_Automator_Pro
 * @since   7.2
 */

namespace Uncanny_Automator_Pro;

class Webhook_Index {

	const OPTION_KEY = 'automator_webhook_index';

	/**
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Cached index: route_key => webhook config.
	 *
	 * @var array|null
	 */
	private $index = null;

	/**
	 * Re-entrancy guard for rebuild.
	 *
	 * @var bool
	 */
	private $is_rebuilding = false;

	/**
	 * @return self
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register invalidation hooks.
	 *
	 * Rebuilds when:
	 * - A trigger is saved (WEBHOOK_URL, WEBHOOK_FIELDS, etc.), for builder, MCP and automator_*() saves alike
	 * - A recipe, trigger or action changes status (every status write is a wp_update_post())
	 * - A recipe post is deleted
	 * Also invalidates on plugin activation/deactivation.
	 *
	 * @return void
	 */
	public function register_hooks() {
		// Trigger saved (WEBHOOK_URL, WEBHOOK_FIELDS, etc.).
		add_action( 'automator_event_recipe_changed', array( $this, 'on_recipe_changed' ) );
		// Post status transitions: the recipe builder, MCP, bulk actions, WP-CLI.
		add_action( 'transition_post_status', array( $this, 'on_status_change' ), 10, 3 );
		// Recipe/trigger deletion, once the row is gone: a rebuild before it would still index the deleted recipe or trigger.
		add_action( 'after_delete_post', array( $this, 'on_post_deleted' ), 10, 2 );
		// Plugin activation.
		add_action( 'activate_plugin', array( $this, 'invalidate' ) );
		// Plugin deactivation.
		add_action( 'deactivate_plugin', array( $this, 'invalidate' ) );
		// Explicit rebuild request from consumers that just mutated webhook routing state for Core API.
		add_action( 'automator_webhook_index_rebuild', array( $this, 'rebuild' ), 100 );
	}

	/**
	 * Rebuild after a trigger is saved; the index holds trigger meta only.
	 *
	 * @since 8.0.0
	 *
	 * @param object $event The recipe_changed event.
	 *
	 * @return void
	 */
	public function on_recipe_changed( $event ) {

		if ( 'trigger' !== $event->to_array()['item_type'] ) {
			return;
		}

		$this->rebuild();
	}

	/**
	 * Rebuild on WP post status transition if it's a recipe post type.
	 *
	 * @param string   $new_status New post status.
	 * @param string   $old_status Old post status.
	 * @param \WP_Post $post       The post object.
	 *
	 * @return void
	 */
	public function on_status_change( $new_status, $old_status, $post ) {

		if ( ! $this->is_automator_post( $post ) ) {
			return;
		}

		$this->rebuild();
	}

	/**
	 * Rebuild when an Automator post has been deleted.
	 *
	 * Runs on after_delete_post, once the post and its meta are gone, so the
	 * rebuild no longer finds the deleted recipe or trigger.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object, as it was before the delete.
	 *
	 * @return void
	 */
	public function on_post_deleted( $post_id, $post ) {

		if ( ! $this->is_automator_post( $post ) ) {
			return;
		}

		$this->rebuild();
	}

	/**
	 * Check if a post is an Automator recipe post type.
	 *
	 * Guards against early calls (e.g., revision cleanup) before
	 * Automator's global functions are loaded.
	 *
	 * @param mixed $post The post object.
	 *
	 * @return bool
	 */
	private function is_automator_post( $post ) {

		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		if ( ! function_exists( 'automator_get_recipe_post_types' ) ) {
			return false;
		}

		return in_array( $post->post_type, automator_get_recipe_post_types(), true );
	}

	/**
	 * Get the full index. Lazy-builds from DB on first access.
	 *
	 * @return array Route key => webhook config.
	 */
	public function get() {

		if ( null !== $this->index ) {
			return $this->index;
		}

		$raw = \automator_get_option( self::OPTION_KEY, false );

		if ( false !== $raw && is_array( $raw ) ) {
			$this->index = $raw;
			return $this->index;
		}

		// First access or invalidated — rebuild.
		$this->index = $this->build();
		$this->save( $this->index );

		return $this->index;
	}

	/**
	 * O(1) lookup by route key.
	 *
	 * @param string $route_key The route key (e.g., 'uap-123-456').
	 *
	 * @return array|null Webhook config or null if not found.
	 */
	public function get_by_route( $route_key ) {

		$index = $this->get();

		return isset( $index[ $route_key ] ) ? $index[ $route_key ] : null;
	}

	/**
	 * Get all route keys from the index.
	 *
	 * @return array Array of route key strings.
	 */
	public function get_route_keys() {
		return array_keys( $this->get() );
	}

	/**
	 * Build the index from the database.
	 *
	 * Single query fetches all meta for triggers that have a WEBHOOK_URL,
	 * then groups by trigger into the index structure.
	 *
	 * @return array Route key => webhook config.
	 */
	private function build() {

		global $wpdb;

		$route_prefix = \automator_pro_get_webhook_route_prefix();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					recipe.ID AS recipe_id,
					trigger_post.ID AS trigger_id,
					tm.meta_key,
					tm.meta_value
				FROM {$wpdb->posts} recipe
				INNER JOIN {$wpdb->posts} trigger_post
					ON trigger_post.post_parent = recipe.ID
					AND trigger_post.post_type = %s
					AND trigger_post.post_status = 'publish'
				INNER JOIN {$wpdb->postmeta} tm
					ON tm.post_id = trigger_post.ID
				INNER JOIN {$wpdb->postmeta} url_check
					ON url_check.post_id = trigger_post.ID
					AND url_check.meta_key = 'WEBHOOK_URL'
					AND url_check.meta_value != ''
				WHERE recipe.post_type = %s
					AND recipe.post_status = 'publish'
				ORDER BY recipe.ID, trigger_post.ID",
				'uo-trigger',
				'uo-recipe'
			),
			OBJECT
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $this->group_rows( $rows, $route_prefix );
	}

	/**
	 * Meta keys needed at runtime for route registration and callback execution.
	 * Everything else is display-only and excluded from the index to keep it lean.
	 *
	 * @var array
	 */
	const INDEXED_META_KEYS = array(
		'code',
		'WEBHOOK_URL',
		'WEBHOOK_FIELDS',
		'WEBHOOK_HEADERS',
		'DATA_FORMAT',
		'WEBHOOK_RESPONSE_TYPE',
		'WEBHOOK_RESPONSE_CODE',
		'WEBHOOK_RESPONSE_CONTENT_TYPE',
		'WEBHOOK_RESPONSE_BODY',
		'WEBHOOK_RESPONSE_FILTER_FUNCTION',
	);

	/**
	 * Group raw DB rows into the index structure.
	 *
	 * @param array  $rows         DB result rows.
	 * @param string $route_prefix The webhook route prefix.
	 *
	 * @return array Route key => webhook config.
	 */
	private function group_rows( $rows, $route_prefix ) {

		$index = array();

		if ( empty( $rows ) ) {
			return $index;
		}

		$allowed = array_flip( self::INDEXED_META_KEYS );

		// First pass: collect meta per trigger (only runtime-relevant keys).
		$triggers = array();

		foreach ( $rows as $row ) {
			$tid = absint( $row->trigger_id );

			if ( ! isset( $triggers[ $tid ] ) ) {
				$triggers[ $tid ] = array(
					'recipe_id'  => absint( $row->recipe_id ),
					'trigger_id' => $tid,
					'meta'       => array(),
				);
			}

			if ( ! isset( $allowed[ $row->meta_key ] ) ) {
				continue;
			}

			$triggers[ $tid ]['meta'][ $row->meta_key ] = $row->meta_value;
		}

		// Second pass: build index keyed by route.
		foreach ( $triggers as $trigger ) {

			$webhook_url = isset( $trigger['meta']['WEBHOOK_URL'] ) ? $trigger['meta']['WEBHOOK_URL'] : '';

			if ( '' === $webhook_url ) {
				continue;
			}

			$route_key = sprintf( '%s-%d-%d', $route_prefix, $trigger['recipe_id'], $trigger['trigger_id'] );

			$index[ $route_key ] = array(
				'recipe_id'  => $trigger['recipe_id'],
				'trigger_id' => $trigger['trigger_id'],
				'meta'       => $trigger['meta'],
			);
		}

		return $index;
	}

	/**
	 * Rebuild the index and persist.
	 *
	 * @return void
	 */
	public function rebuild() {

		if ( $this->is_rebuilding ) {
			return;
		}

		$this->is_rebuilding = true;
		$this->index         = $this->build();
		$this->save( $this->index );
		$this->is_rebuilding = false;
	}

	/**
	 * Invalidate the index (delete from DB). Will lazy-rebuild on next get().
	 *
	 * @return void
	 */
	public function invalidate() {
		\automator_delete_option( self::OPTION_KEY );
		$this->index = null;
	}

	/**
	 * Persist the index to uap_options.
	 *
	 * @param array $index The index data.
	 *
	 * @return void
	 */
	private function save( $index ) {
		\automator_update_option( self::OPTION_KEY, $index );
	}
}
