<?php

namespace Uncanny_Automator_Pro;

use WP_REST_Request;
use WP_REST_Response;

/**
 * Webhook_Rest_Handler class. One class to catch all webhook triggers (Automator, Zapier and Integromat)
 */
class Webhook_Rest_Handler {

	/**
	 * Store all webhook trigger codes.
	 *
	 * Seeded with Automator's built-in (internal) webhook trigger code(s) so they
	 * are always known, independent of demand-driven integration loading: this
	 * handler is a boot.php core-class-init (referenced on every request, ungated),
	 * whereas the owning integration's setup() is manifest-gated and may not run.
	 * Third-party webhook triggers (Zapier, IFTTT, Make, etc.) append their own
	 * codes via set_trigger_codes() from their (gated) setups.
	 *
	 * @var string[]
	 */
	private static $trigger_codes = array( 'WP_ANON_WEBHOOKS' );

	/**
	 * Array key joiner in token "KEY"
	 *
	 * @var mixed|void
	 */
	private static $array_key_separator;

	/**
	 * Webhook_Rest_Handler construct
	 */
	public function __construct() {
		self::$array_key_separator = apply_filters( 'automator_pro_webhook_array_key_in_token_separator', '/' );

		// Load and wire the webhook index file.
		require_once __DIR__ . '/class-webhook-index.php';
		Webhook_Index::get_instance()->register_hooks();

		add_action( 'rest_api_init', array( __CLASS__, 'automator_webhook_init_rest_api' ) );
	}

	/**
	 * Return $trigger_codes
	 *
	 * @return array
	 */
	public static function get_trigger_codes() {
		return self::$trigger_codes;
	}

	/**
	 * Store $trigger_codes
	 *
	 * @param string $trigger_codes
	 */
	public static function set_trigger_codes( $trigger_codes ) {
		if ( ! in_array( $trigger_codes, self::$trigger_codes, true ) ) {
			self::$trigger_codes[] = $trigger_codes;
		}
	}

	/**
	 * Webhooks Rest API inits
	 *
	 * @return void
	 */
	public static function automator_webhook_init_rest_api() {
		$available_hooks = self::get_available_hooks();
		if ( empty( $available_hooks ) ) {
			return;
		}

		foreach ( $available_hooks as $hook ) {
			$args = array();
			if ( ! empty( $hook['params'] ) ) {
				foreach ( $hook['params'] as $param ) {
					$args[ $param['key'] ] = array(
						'type'     => $param['type'],
						'format'   => $param['format'],
						'required' => true,
						'items'    => array(
							'type' => 'string',
						),
					);
				}
			}
			$_route = '/' . $hook['WEBHOOKID'];
			self::register_rest_route( $_route, $hook );
		}
	}

	/**
	 * Get all available webhook end-points.
	 *
	 * Reads from the Webhook_Index — zero DB queries on the hot path.
	 *
	 * @return array
	 */
	public static function get_available_hooks() {

		$index = Webhook_Index::get_instance()->get();

		if ( empty( $index ) ) {
			return array();
		}

		$available_hooks = array();

		foreach ( $index as $route_key => $entry ) {

			// Build a trigger-like structure for setup_hook_params / setup_custom_headers.
			$trigger_proxy = array( 'meta' => $entry['meta'] );

			$_hooks                   = array();
			$_hooks['WEBHOOKID']      = $route_key;
			$_hooks['params']         = self::setup_hook_params( $trigger_proxy );
			$_hooks['custom_headers'] = self::setup_custom_headers( $trigger_proxy );
			$available_hooks[]        = $_hooks;
		}

		return $available_hooks;
	}

	/**
	 * Setup params
	 *
	 * @param array $trigger
	 *
	 * @return array
	 */
	public static function setup_hook_params( $trigger ) {
		if ( empty( $trigger['meta']['WEBHOOK_FIELDS'] ) ) {
			return array();
		}
		$_fields = ( json_decode( $trigger['meta']['WEBHOOK_FIELDS'] ) );
		if ( empty( $_fields ) ) {
			return array();
		}
		$params = array();
		foreach ( $_fields as $_field ) {
			$params[] = array(
				//phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				'key'    => $_field->KEY,
				//phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				'type'   => $_field->VALUE_TYPE,
				'format' => '',
				'items'  => array(
					'type' => 'string',
				),
			);
		}

		return $params;
	}

	/**
	 * Setup custom header
	 *
	 * @param array $trigger
	 *
	 * @return array
	 */
	public static function setup_custom_headers( $trigger ) {
		if ( ! isset( $trigger['meta']['WEBHOOK_HEADERS'] ) ) {
			return array();
		}
		$headers     = array();
		$header_meta = json_decode( $trigger['meta']['WEBHOOK_HEADERS'], true );
		if ( ! empty( $header_meta ) ) {
			foreach ( $header_meta as $head ) {
				$key = strtolower( $head['NAME'] );
				// remove colon if user added in NAME
				$key   = str_replace( ':', '', $key );
				$value = $head['VALUE'];
				if ( ! is_null( $value ) ) {
					if ( 'authorization' === $key || 'authentication' === $key ) {
						$headers[ $key ] = self::parse_basic_authentication( $value );
					} else {
						$headers[ $key ] = $value;
					}
				}
			}
		}

		return $headers;
	}

	/**
	 * Parse basic authentication
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	public static function parse_basic_authentication( $value ) {
		$data   = sanitize_text_field( str_ireplace( 'Basic ', '', $value ) );
		$string = base64_encode( $data ); //phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode

		return "Basic $string";
	}

	/**
	 * Registering all routes
	 *
	 * @param string $_route
	 * @param array $hook
	 *
	 * @return void
	 */
	public static function register_rest_route( $_route, $hook = array() ) {
		register_rest_route(
			AUTOMATOR_REST_API_END_POINT,
			$_route,
			array(
				'methods'             => apply_filters(
					'automator_pro_webhook_rest_route_methods',
					array(
						'POST',
						'GET',
						'PUT',
					),
					$_route
				),
				'callback'            => array( __CLASS__, 'automator_webhook_rest_api_callback' ),
				'custom_headers'      => isset( $hook['custom_headers'] ) ? $hook['custom_headers'] : null,
				'permission_callback' => function ( $request ) {
					$attributes = $request->get_attributes();
					if ( empty( $attributes ) || ! isset( $attributes['custom_headers'] ) ) {
						return apply_filters( 'automator_pro_webhook_rest_route_permission_callback', true, $attributes, $request );
					}

					$request_headers = $request->get_headers();
					foreach ( $attributes['custom_headers'] as $header_name => $header_value ) {
						if ( ! isset( $request_headers[ $header_name ] ) ) {
							return apply_filters( 'automator_pro_webhook_rest_route_permission_callback', false, $attributes, $request );
						}
						if ( ! array_intersect( array( $header_value ), $request_headers[ $header_name ] ) ) {
							return apply_filters( 'automator_pro_webhook_rest_route_permission_callback', false, $attributes, $request );
						}
					}

					return apply_filters( 'automator_pro_webhook_rest_route_permission_callback', true, $attributes, $request );
				},
			)
		);
	}

	/**
	 * Catch all "Live" Webhook recipe calls
	 *
	 * @param WP_REST_Request $data
	 *
	 * @return WP_REST_Response|\WP_Error A WP_Error (status 400) when an XML body is not well-formed.
	 */
	public static function automator_webhook_rest_api_callback( WP_REST_Request $data ) {

		$route = $data->get_route();

		if ( empty( $route ) ) {
			return new WP_REST_Response(
				array(
					'status' => 'failed',
					'route'  => '(empty)',
				),
				200
			);
		}

		$params = $data->get_params();
		$body   = $data->get_body();
		if ( empty( $params ) && empty( $body ) ) {
			return new WP_REST_Response(
				array(
					'status'  => 'success',
					'recipes' => '(empty)',
				),
				200
			);
		}

		// Extract the route key from the REST route path.
		// Route format: /uap/v2/{route_key} — the last segment is the key.
		$route_parts = explode( '/', trim( $route, '/' ) );
		$route_key   = end( $route_parts );

		// O(1) lookup from the index.
		$webhook_entry = Webhook_Index::get_instance()->get_by_route( $route_key );

		if ( empty( $webhook_entry ) ) {
			return new WP_REST_Response(
				array(
					'status'  => 'success',
					'recipes' => '(empty)',
				),
				200
			);
		}

		// The index carries the trigger's runtime meta; listeners read only the recipe id.
		$recipe  = array( 'ID' => absint( $webhook_entry['recipe_id'] ) );
		$trigger = array(
			'ID'   => absint( $webhook_entry['trigger_id'] ),
			'meta' => (array) $webhook_entry['meta'],
		);

		if ( empty( $trigger ) || ! array_key_exists( 'WEBHOOK_URL', $trigger['meta'] ) ) {
			return new WP_REST_Response(
				array(
					'status'  => 'success',
					'recipes' => '(empty)',
				),
				200
			);
		}

		$response_data = array(
			'success' => true,
			'message' => 'Webhook received successfully.',
		);

		$response_headers = array(
			'Content-Type' => 'application/json',
		);

		$response_status_code = 200;

		$wp_rest_response = false;

		// Process the matched trigger — direct lookup, no iteration.
		$_hooks = array(
			'WEBHOOKID'    => $trigger['ID'],
			'WEBHOOK_BODY' => $body,
		);

		$_fields = ! empty( $trigger['meta']['WEBHOOK_FIELDS'] )
			? json_decode( $trigger['meta']['WEBHOOK_FIELDS'] )
			: array();

		// No field mappings configured — skip this trigger (matches pre-7.2 behavior).
		if ( empty( $_fields ) ) {
			return new \WP_REST_Response( $response_data, $response_status_code, $response_headers );
		}

		$data_type = isset( $trigger['meta']['DATA_FORMAT'] ) ? $trigger['meta']['DATA_FORMAT'] : 'json';
		if ( ! empty( $body ) && empty( $params ) ) {
			$params = self::handle_non_json_type_format( $body, $data_type );
		}
		if ( is_wp_error( $params ) ) {
			return $params;
		}
		$params        = apply_filters( 'automator_pro_webhook_params_pre_handle_params', $params, $trigger['meta'], $data );
		$parsed_fields = self::handle_params( $params );
		foreach ( $_fields as $_field ) {
			if ( isset( $parsed_fields[ $_field->KEY ] ) ) { //phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$value = $parsed_fields[ $_field->KEY ]; //phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			} else {
				$value = apply_filters( 'automator_pro_webhook_field_key_not_found', esc_html_x( 'Key not found in data', 'Webhooks', 'uncanny-automator-pro' ), $_field, $parsed_fields, $_fields, $data );
			}
			if ( is_array( $value ) ) {
				$value = serialize( $value ); //phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
			}
			$_hooks['params'][] = array(
				'key'        => $_field->KEY, //phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				'type'       => $_field->VALUE_TYPE, //phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				'format'     => '',
				'meta_key'   => $_field->KEY, //phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				'meta_value' => $value,
			);
		}

		$_hooks = apply_filters( 'automator_pro_webhook_hooks_data', $_hooks, $recipe, $data );
		do_action_deprecated(
			'uncanny_automator_pro_wp_webhook',
			array( $_hooks, $recipe ),
			'3.6',
			'automator_pro_run_webhook'
		);

		try {
			do_action( 'automator_pro_run_webhook', $_hooks, $recipe, $data );
		} catch ( \Error $e ) {
			automator_log( $e->getMessage(), '', AUTOMATOR_DEBUG_MODE, 'automator_pro_run_webhook' );
		} catch ( \Exception $e ) {
			automator_log( $e->getMessage(), '', AUTOMATOR_DEBUG_MODE, 'automator_pro_run_webhook' );
		}

		// Handle custom response configuration.
		$response_type = isset( $trigger['meta']['WEBHOOK_RESPONSE_TYPE'] ) ? $trigger['meta']['WEBHOOK_RESPONSE_TYPE'] : 'default';
		if ( 'custom' === $response_type ) {
			$response_status_code  = isset( $trigger['meta']['WEBHOOK_RESPONSE_CODE'] ) ? (int) $trigger['meta']['WEBHOOK_RESPONSE_CODE'] : $response_status_code;
			$response_content_type = isset( $trigger['meta']['WEBHOOK_RESPONSE_CONTENT_TYPE'] ) ? $trigger['meta']['WEBHOOK_RESPONSE_CONTENT_TYPE'] : 'json';
			$response_content_type = self::map_content_type_mime( $response_content_type );
			$response_data         = isset( $trigger['meta']['WEBHOOK_RESPONSE_BODY'] ) ? $trigger['meta']['WEBHOOK_RESPONSE_BODY'] : $response_data;
			$response_data         = self::maybe_format_custom_response( $response_data, $response_content_type );
			$response_headers      = array( 'Content-Type' => $response_content_type );
		}

		if ( 'filter' === $response_type ) {
			$function_name = isset( $trigger['meta']['WEBHOOK_RESPONSE_FILTER_FUNCTION'] ) ? $trigger['meta']['WEBHOOK_RESPONSE_FILTER_FUNCTION'] : '';

			// Block dangerous PHP built-in functions that could be used for RCE
			// if an admin account is compromised or via stored XSS in the recipe editor.
			$blocked_functions = apply_filters(
				'automator_pro_webhook_blocked_response_functions',
				array(
					'system',
					'exec',
					'passthru',
					'shell_exec',
					'popen',
					'proc_open',
					'pcntl_exec',
					'eval',
					'assert',
					'create_function',
					'call_user_func',
					'call_user_func_array',
					'preg_replace_callback',
					'usort',
					'uasort',
					'uksort',
					'array_map',
					'array_filter',
					'array_walk',
					'extract',
					'parse_str',
					'putenv',
					'ini_set',
					'dl',
					'mail',
					'header',
					'file_put_contents',
					'fwrite',
					'fputs',
					'unlink',
					'rmdir',
				)
			);

			if ( ! empty( $function_name ) && ! in_array( strtolower( $function_name ), $blocked_functions, true ) ) {
				try {
					if ( function_exists( $function_name ) ) {
						$reflection = new \ReflectionFunction( $function_name );
						$args_count = $reflection->getNumberOfParameters();
						add_filter( 'automator_pro_full_webhook_response_' . $recipe['ID'], $function_name, 10, $args_count );
					} else {
						$error = sprintf(
							/* translators: %s - function name */
							esc_html_x( 'Webhook response filter function %s does not exist.', 'Webhooks', 'uncanny-automator-pro' ),
							$function_name
						);
						throw new \Exception( $error );
					}
				} catch ( \Exception $e ) {
					automator_log( $e->getMessage(), '', AUTOMATOR_DEBUG_MODE, 'automator_pro_webhook_response' );
				}
			}
		}

		$response_data = apply_filters(
			"automator_pro_webhook_response_{$recipe['ID']}",
			$response_data,
			$_hooks,
			$recipe,
			$data
		);

		$response_headers = apply_filters(
			"automator_pro_webhook_response_headers_{$recipe['ID']}",
			$response_headers,
			$_hooks,
			$recipe,
			$data
		);

		$wp_rest_response = new WP_REST_Response( $response_data, $response_status_code, $response_headers );
		$wp_rest_response = apply_filters(
			"automator_pro_full_webhook_response_{$recipe['ID']}",
			$wp_rest_response,
			$_hooks,
			$recipe,
			$data
		);

		if ( false === $wp_rest_response || ! is_a( $wp_rest_response, 'WP_REST_Response' ) ) {
			$wp_rest_response = new WP_REST_Response( $response_data, $response_status_code, $response_headers );
		}

		return $wp_rest_response;
	}

	/**
	 * Map content type to mime type
	 *
	 * @param string $type
	 *
	 * @return string
	 */
	public static function map_content_type_mime( $type ) {

		$type       = strtolower( $type );
		$mime_types = array(
			'json'                  => 'application/json',
			'x-www-form-urlencoded' => 'application/x-www-form-urlencoded',
			'form-data'             => 'multipart/form-data',
			'plain'                 => 'text/plain',
			'html'                  => 'text/html',
			'xml'                   => 'application/xml',
			'graphql'               => 'application/graphql',
			'raw'                   => 'application/octet-stream',
		);

		return isset( $mime_types[ $type ] ) ? $mime_types[ $type ] : 'application/json';
	}

	/**
	 * Maybe format custom response data.
	 *
	 * @param string $data - Content added to the custom field.
	 * @param string $type - Content type.
	 *
	 * @return array
	 */
	public static function maybe_format_custom_response( $data, $type ) {
		$response_data = $data;
		try {
			// Handle formatting for different content types
			switch ( $type ) {
				case 'application/json':
				case 'application/graphql':
					// Decode to clean up formatting and convert to JSON
					$decoded_data = json_decode( $data, true );
					if ( JSON_ERROR_NONE !== json_last_error() ) {
						$error_type = 'application/json' === $type ? 'JSON' : 'GraphQL';
						throw new \Exception(
							sprintf(
								/* translators: 1: Error type, 2: Error message */
								esc_html_x( 'Invalid %1$s response body: %2$s', 'Webhooks', 'uncanny-automator-pro' ),
								$error_type,
								json_last_error_msg()
							)
						);
					}
					$response_data = $decoded_data;
					break;

				case 'application/x-www-form-urlencoded':
					// Parse URL-encoded data to validate and convert to array
					parse_str( $data, $parsed_data );
					if ( ! is_array( $parsed_data ) ) {
						throw new \Exception( esc_html_x( 'Invalid URL-encoded response body', 'Webhooks', 'uncanny-automator-pro' ) );
					}
					// Re-encode as URL-encoded string
					$response_data = http_build_query( $parsed_data );
					break;
			}
		} catch ( \Exception $e ) {
			$response_data = array(
				'error' => $e->getMessage(),
				'code'  => $e->getCode(),
				'data'  => $data,
			);
		}

		return $response_data;
	}

	/**
	 * Covert param values to KEY => VALUE pair
	 *
	 * @param array $params
	 * @param bool $is_sample
	 *
	 * @return array
	 */
	public static function handle_params( $params, $is_sample = false ) {
		$fields = self::get_leafs( $params );
		if ( $is_sample ) {
			return $fields;
		}

		return self::switch_to_key_value_pairs( $fields );
	}

	/**
	 * Get leafs from array
	 *
	 * @param mixed $data
	 *
	 * @return array
	 */
	public static function get_leafs( $data ) {

		$leafs = array();

		if ( ! is_array( $data ) ) {
			return $leafs;
		}

		$array_iterator    = new \RecursiveArrayIterator( $data );
		$iterator_iterator = new \RecursiveIteratorIterator( $array_iterator, \RecursiveIteratorIterator::LEAVES_ONLY );
		foreach ( $iterator_iterator as $key => $value ) {
			$keys = array();
			for ( $i = 0; $i < $iterator_iterator->getDepth(); $i++ ) { //phpcs:ignore Generic.CodeAnalysis.ForLoopWithTestFunctionCall.NotAllowed
				$keys[] = $iterator_iterator->getSubIterator( $i )->key();
			}
			$keys[]   = $key;
			$leaf_key = implode( self::$array_key_separator, $keys );

			$leafs[] = array(
				'key'  => $leaf_key,
				'type' => Webhook_Common_Options::value_maybe_of_type( $key, $value ),
				'data' => $value,
			);
		}

		return $leafs;
	}

	/**
	 * Switch to key value pairs
	 *
	 * @param array $fields
	 *
	 * @return array|mixed
	 */
	public static function switch_to_key_value_pairs( $fields ) {
		if ( empty( $fields ) ) {
			return $fields;
		}
		$data = array();
		foreach ( $fields as $field ) {
			$data[ $field['key'] ] = $field['data'];
		}

		return $data;
	}

	/**
	 * The format of a body sent to a trigger whose Data format is Auto: XML when
	 * it carries an XML declaration; a form when it is not JSON and reads as
	 * `key=value` pairs joined by `&`; otherwise JSON.
	 *
	 * @since 8.0.0
	 *
	 * @param mixed $data Request body.
	 *
	 * @return string 'xml', 'x-www-form-urlencoded' or 'json'.
	 */
	private static function detect_auto_format( $data ) {
		if ( ! is_string( $data ) ) {
			return 'json';
		}

		if ( preg_match( '/\<\?xml/', $data ) ) {
			return 'xml';
		}

		json_decode( $data );

		if ( JSON_ERROR_NONE !== json_last_error() && 1 === preg_match( '/^[^=&\s]+=[^&\s]*(?:&[^=&\s]+=[^&\s]*)*&?$/', trim( $data ) ) ) {
			return 'x-www-form-urlencoded';
		}

		return 'json';
	}

	/**
	 * Convert non-json formatted data to arrays for parsing
	 *
	 * @param mixed $data
	 * @param string $type
	 *
	 * @return array|array[]|object|\WP_Error A WP_Error (status 400) when an XML body is not well-formed.
	 */
	public static function handle_non_json_type_format( $data, $type ) {
		if ( 'auto' === $type ) {
			$type = self::detect_auto_format( $data );
		}
		switch ( $type ) {
			case 'xml':
				$value = self::xml_string_to_array( $data );
				break;
			case 'csv':
				$value = self::csvstring_to_array( $data );
				break;
			case 'form-data':
			case 'x-www-form-urlencoded':
				parse_str( $data, $value );
				break;
			default:
				$value = json_decode( $data );
				break;
		}

		return $value;
	}

	/**
	 * Parse an XML body into an array keyed by its root element's name.
	 *
	 * A body that is not well-formed XML is refused the way WordPress refuses a
	 * JSON body that does not decode: a 400 error, with the parser's reason in
	 * the error data.
	 *
	 * @since 8.0.0
	 *
	 * @param string $data XML body.
	 *
	 * @return array|\WP_Error
	 */
	private static function xml_string_to_array( $data ) {
		$previous_internal_errors = libxml_use_internal_errors( true );
		libxml_clear_errors();

		// Disable external entity loading to prevent XXE on PHP < 8.0.
		$previous = libxml_disable_entity_loader( true ); // phpcs:ignore Generic.PHP.DeprecatedFunctions.Deprecated
		$xml      = simplexml_load_string( $data, 'SimpleXMLElement', LIBXML_NONET );
		libxml_disable_entity_loader( $previous ); // phpcs:ignore Generic.PHP.DeprecatedFunctions.Deprecated

		$errors = libxml_get_errors();
		libxml_clear_errors();
		libxml_use_internal_errors( $previous_internal_errors );

		if ( false === $xml ) {
			return new \WP_Error(
				'automator_pro_webhook_invalid_xml',
				esc_html_x( 'Invalid XML body passed.', 'Webhooks', 'uncanny-automator-pro' ),
				array(
					'status'            => 400,
					'xml_error_message' => empty( $errors ) ? '' : trim( $errors[0]->message ),
				)
			);
		}

		return array( $xml->getName() => self::xml_to_array( $xml ) );
	}

	/**
	 * Convert nested XML to an array.
	 *
	 * An element that repeats under the same parent becomes a list of its values,
	 * in document order: `<tag>a</tag><tag>b</tag>` reads as `tag/0` and `tag/1`,
	 * as the same data sent as a JSON array does. An element that appears once
	 * keeps its own key.
	 *
	 * @param \SimpleXMLElement $parent_element
	 *
	 * @return array
	 */
	private static function xml_to_array( \SimpleXMLElement $parent_element ) {
		$array = array();
		$lists = array();

		foreach ( $parent_element as $name => $element ) {
			$value = $element->count() ? self::xml_to_array( $element ) : trim( (string) $element );

			if ( ! array_key_exists( $name, $array ) ) {
				$array[ $name ] = $value;
				continue;
			}

			if ( ! isset( $lists[ $name ] ) ) {
				$array[ $name ] = array( $array[ $name ] );
				$lists[ $name ] = true;
			}

			$array[ $name ][] = $value;
		}

		return $array;
	}

	/**
	 * Convert CSV string to array
	 *
	 * @param string $string_value
	 * @param string $separator_char
	 * @param string $enclosure_char
	 * @param string $newline_char
	 *
	 * @return array
	 */
	private static function csvstring_to_array( $string_value, $separator_char = ',', $enclosure_char = '"', $newline_char = "\n" ) {
		// @author: Klemen Nagode
		$array         = array();
		$size          = strlen( $string_value );
		$column_index  = 0;
		$row_index     = 0;
		$field_value   = '';
		$is_enclosured = false;
		for ( $i = 0; $i < $size; $i++ ) {
			$char     = $string_value[ $i ];
			$add_char = '';
			if ( $is_enclosured ) {
				if ( $char === $enclosure_char ) {
					if ( $i + 1 < $size && $string_value[ $i + 1 ] === $enclosure_char ) {
						// escaped char
						$add_char = $char;
						++$i; // dont check next char
					} else {
						$is_enclosured = false;
					}
				} else {
					$add_char = $char;
				}
			} else {
				if ( $char === $enclosure_char ) {
					$is_enclosured = true;
				} else {

					if ( $char === $separator_char ) {

						$array[ $row_index ][ $column_index ] = $field_value;
						$field_value                          = '';

						++$column_index;
					} elseif ( $char === $newline_char ) {
						$array[ $row_index ][ $column_index ] = $field_value;
						$field_value                          = '';
						$column_index                         = 0;
						++$row_index;
					} else {
						$add_char = $char;
					}
				}
			}
			if ( '' !== $add_char ) {
				$field_value .= $add_char;
			}
		}

		if ( $field_value ) { // save last field
			$array[ $row_index ][ $column_index ] = $field_value;
		}

		return $array;
	}
}
