<?php
namespace Uncanny_Automator_Pro\Loops\Recipe;

use Exception;
use Uncanny_Automator_Pro\Utilities;

final class Token_Loop_Auto {

	/**
	 * Integrations whose items auto-create a token loop.
	 *
	 * Declaring a single loopable token is NOT sufficient identity — unrelated
	 * integrations do it too (Sugar Calendar's RSVP and ticket triggers both
	 * declare one `ATTENDEES` token), and an auto-created loop is a published,
	 * permanent mutation of the user's recipe. So membership is by integration,
	 * hardcoded: this is closed Pro functionality with no extension need, and a
	 * filter would be unreliable under demand-driven loading.
	 *
	 * @var string[]
	 */
	const LOOPABLE_INTEGRATIONS = array(
		'LOOPABLE_CSV',
		'LOOPABLE_JSON',
		'LOOPABLE_XML',
		'LOOPABLE_RSS',
	);

	/**
	 * Automatically create the default token loop for a root-level loopable
	 * trigger or action once its "Describe data" field is saved.
	 *
	 * Listens to `automator_event_recipe_changed`, so builder, MCP and
	 * automator_*() saves alike reach it. The loop is labelled with that field,
	 * once, so an item added empty (the builder adds items before their fields
	 * are filled) waits for the save that fills it. `LOOP_ADDED` guards repeats.
	 *
	 * @since 8.0.0
	 *
	 * @param object $event The recipe_changed event.
	 *
	 * @return void
	 */
	public static function on_recipe_changed( $event ) {

		$change = $event->to_array();
		if ( 'deleted' === $change['operation'] || ! in_array( $change['item_type'], array( 'trigger', 'action' ), true ) ) {
			return;
		}

		$item_id   = absint( $change['item_id'] );
		$recipe_id = absint( $change['recipe_id'] );

		if ( 'yes' === get_post_meta( $item_id, 'LOOP_ADDED', true ) ) {
			return;
		}

		$config = self::resolve_item_loop_config( (string) get_post_meta( $item_id, 'code', true ), (string) $change['item_type'] );
		if ( null === $config || '' === (string) get_post_meta( $item_id, $config['meta'], true ) ) {
			return;
		}

		$item = get_post( $item_id );
		if ( ! $item instanceof \WP_Post ) {
			return;
		}

		// Root-level loopable sources only — block-nested items manage their
		// own iteration context.
		if ( absint( $item->post_parent ) !== $recipe_id ) {
			return;
		}

		self::persist( $item, $recipe_id, $config );
	}

	/**
	 * Resolve the auto-loop configuration for a loopable trigger or action
	 * from its registered definition.
	 *
	 * @param string $code Item code.
	 * @param string $type Item type ('trigger'|'action').
	 *
	 * @return array<string,string>|null
	 */
	private static function resolve_item_loop_config( string $code, string $type ) {

		if ( '' === $code || ! function_exists( 'Automator' ) || ! in_array( $type, array( 'trigger', 'action' ), true ) ) {
			return null;
		}

		$is_trigger = 'trigger' === $type;
		$definition = $is_trigger ? \Automator()->get_trigger( $code ) : \Automator()->get_action( $code );

		if ( ! is_array( $definition ) ) {
			return null;
		}

		if ( ! in_array( (string) ( $definition['integration'] ?? '' ), self::LOOPABLE_INTEGRATIONS, true ) ) {
			return null;
		}

		$loopable_tokens = $definition['loopable_tokens'] ?? array();
		if ( ! is_array( $loopable_tokens ) || 1 !== count( $loopable_tokens ) ) {
			return null;
		}

		$loopable_id = array_key_first( $loopable_tokens );
		// Both modern abstracts register the option-group code as `meta_code`, and the
		// integration gate above admits only items built on them — legacy raw-array
		// registrations (triggers use `meta`, actions `action_meta`) cannot reach here.
		$meta_code = (string) ( $definition['meta_code'] ?? '' );

		if ( ! is_string( $loopable_id ) || '' === $loopable_id || '' === $meta_code ) {
			return null;
		}

		return array(
			'loopable_id' => $loopable_id,
			'type'        => $is_trigger ? 'TRIGGER_TOKEN' : 'ACTION_TOKEN',
			'entity_code' => $code,
			'meta'        => $meta_code,
		);
	}

	/**
	 * Creates a unified token loop block for the given item and recipe.
	 *
	 * Delegates to automator_add_loop_to_recipe() which produces a
	 * uo-block(block_type='loop') row and auto-seeds the ITEM_NOT_EMPTY
	 * default loop filter for token iteration types.
	 *
	 * @param \WP_Post $item      The loopable action/trigger post.
	 * @param int      $recipe_id ID of the parent recipe post.
	 * @param array    $config    Loop configuration: loopable_id, type, entity_code, meta.
	 *
	 * @return void
	 */
	public static function persist( $item, $recipe_id, $config ) {

		$entity_id = $item->ID ?? '';

		$post_meta = Utilities::flatten_post_meta( get_post_meta( $entity_id ) );

		// Create the loop here automatically.
		$field_value = "{{TOKEN_EXTENDED:DATA_TOKEN_{$config['loopable_id']}:{$entity_id}:{$config['entity_code']}:{$config['loopable_id']}}}";

		if ( 'ACTION_TOKEN' === $config['type'] ) {
			$field_value = "{{TOKEN_EXTENDED:DATA_TOKEN_{$config['loopable_id']}:{$config['type']}:{$entity_id}:{$config['entity_code']}:{$config['loopable_id']}}}";
		}

		try {

			$fields = array(
				'TOKEN' => array(
					'type'   => 'text',
					'value'  => $field_value,
					'backup' => array(
						'show_label_in_sentence' => false,
						'label'                  => $post_meta[ $config['meta'] ] ?? '(Empty describe data)',
					),
				),
			);

			$iterable_expression = array(
				'type'   => 'token',
				'fields' => wp_json_encode( $fields ),
			);

			$result = automator_add_loop_to_recipe( absint( $recipe_id ), $iterable_expression );

			if ( is_wp_error( $result ) ) {
				automator_log( 'Creating loop failed with error: ' . $result->get_error_message(), 'loop error', true, 'debug' );
				return;
			}

			update_post_meta( $item->ID, 'LOOP_ADDED', 'yes' );

		} catch ( Exception $e ) {

			// Defensive: the helper converts service throws to WP_Error; this guards the field-prep above.
			automator_log( 'Creating loop failed with error: ' . $e->getMessage(), 'loop error', true, 'debug' );

		}
	}
}
