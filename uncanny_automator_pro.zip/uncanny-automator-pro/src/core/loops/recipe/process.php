<?php
namespace Uncanny_Automator_Pro\Loops\Recipe;

use Uncanny_Automator\Automator_Status;
use Uncanny_Automator_Pro\Automator_Pro_Recipe_Process_Complete;
use Uncanny_Automator_Pro\Loops\Loop\Model\Loop_Entry_Model;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Query;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Item_Query;

class Process {

	/**
	 * Trait_Process contains the properties, setter, and getter for this Process object.
	 */
	use Trait_Process;

	// $recipe_process_complete_class property + constructor removed in 7.3.
	// complete_action(), complete_actions_conditions(), run_loops(),
	// generate_action_data(), and retrieve_flow_actions_items() also removed.
	// Loops run through Loop_Block_Processor via the Free walker.

	/**
	 * Portable function complete_recipe
	 *
	 * @param int $recipe_id
	 * @param int $recipe_log_id
	 * @param int $run_number
	 *
	 * @return void
	 */
	public static function complete_recipe( $recipe_id, $recipe_log_id, $run_number ) {

		// Check if other loops are still running. If so, don't finalize yet —
		// the last loop to complete will call this again.
		$status = self::resolve_recipe_status( $recipe_id, $recipe_log_id, $run_number );

		if ( Automator_Status::IN_PROGRESS === $status ) {
			return;
		}

		// All loops done — finalize via the pipeline proxy.
		Automator()->recipe_runner->finalize_recipe_by_log_id( absint( $recipe_log_id ) );
	}

	/**
	 * Resolves the recipe status.
	 *
	 * The status will be marked as in-progress when any of the following is true:
	 *
	 * - Multiple loop entries in a single recipe and the next recipe is still in progress.
	 * - If the current loop has still items in progress (e.g. delayed).
	 *
	 * @param int $recipe_id
	 * @param int $recipe_log_id
	 * @param int $run_number
	 *
	 * @return int See Automator_Status.
	 */
	public static function resolve_recipe_status( $recipe_id, $recipe_log_id, $run_number ) {

		$entry_query = new Loop_Entry_Query();

		$results = $entry_query->find_by_recipe_process( $recipe_id, $recipe_log_id, $run_number );

		$status = Automator_Status::COMPLETED;

		// If there are multiple loops in a single recipe.
		if ( self::loop_entries_has_inprogress_state( $results ) ) {
			$status = Automator_Status::IN_PROGRESS;
		}

		// If the current loop process has items in-progress remaining (scheduled/delayed ).
		if ( self::loop_entries_items_has_inprogress_state( $recipe_id, $recipe_log_id, $run_number ) ) {
			$status = Automator_Status::IN_PROGRESS;
		}

		// If the recipe's root actions has in-progress status.
		if ( self::recipe_has_in_progress_actions( $recipe_id, $recipe_log_id ) ) {
			$status = Automator_Status::IN_PROGRESS;
		}

		return $status;
	}

	/**
	 * Determines whether the recipe has still items that are in progress.
	 *
	 * @param int $recipe_id
	 * @param int $recipe_log_id
	 *
	 * @return bool True if the specific recipe run has in-progress action. Otherwise, returns false.
	 */
	public static function recipe_has_in_progress_actions( $recipe_id, $recipe_log_id ) {

		$results = Automator_Pro_Recipe_Process_Complete::fetch_specific_recipe_log_by_status(
			$recipe_id,
			$recipe_log_id,
			Automator_Status::IN_PROGRESS
		);

		return ! empty( $results );
	}

	/**
	 * @param int $recipe_id
	 * @param int $recipe_log_id
	 * @param int $run_number
	 *
	 * @return bool True if there are items that are marked in-progress in the entries items table. Returns false, otherwise.
	 */
	public static function loop_entries_items_has_inprogress_state( $recipe_id, $recipe_log_id, $run_number ) {

		$loop_entries_items_query = new Loop_Entry_Item_Query();

		return $loop_entries_items_query->has_in_progress( $recipe_id, $recipe_log_id, $run_number );
	}

	/**
	 * Whether a loop ended Completed with errors: Pro records that status on the entry of a loop that could not
	 * start (its filter or token failed) or that the walker refused.
	 *
	 * @since 8.0.0
	 *
	 * @param Loop_Entry_Model[] $loop_entries The run's loop entries.
	 *
	 * @return bool
	 */
	public static function loop_entries_has_failed_state( $loop_entries ) {

		$failed = Automator_Status::get_class_name( Automator_Status::COMPLETED_WITH_ERRORS );

		foreach ( (array) $loop_entries as $loop_entry ) {
			if ( $failed === $loop_entry->get_status() ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Portable function loop_entries_has_inprogress_state
	 *
	 * Determines whether the loop entries has 'in_progress' state.
	 *
	 * @param Loop_Entry_Model[] $loop_entries
	 *
	 * @return bool True or false.
	 *
	 * @phpstan-ignore-next-line
	 */
	public static function loop_entries_has_inprogress_state( $loop_entries ) {

		$processing_state = array(
			Automator_Status::get_class_name( Automator_Status::IN_PROGRESS ),
			Automator_Status::get_class_name( Automator_Status::QUEUED ),
		);

		foreach ( (array) $loop_entries as $loop_entry ) {
			if ( in_array( $loop_entry->get_status(), $processing_state, true ) ) {
				return true;
			}
		}

		return false;
	}
}
