<?php
namespace Uncanny_Automator_Pro\Loops\Filter\Model\Active_Record;

use Uncanny_Automator\App\Infrastructure\Database\Database;
use Uncanny_Automator\App\Infrastructure\Database\Interfaces\Execution_Log_Store;
use Uncanny_Automator\App\Recipe_Runner\Services\Integration_Registry;
use Uncanny_Automator_Pro\Loops\Loop\Entity_Factory;

class Entity_Filter_Record {

	/**
	 * @var int $recipe_id
	 */
	protected $recipe_id;

	/**
	 * @var int $loop_id
	 */
	protected $loop_id;

	/**
	 * @var string
	 */
	protected $loop_type = '';

	/**
	 * @var mixed[]
	 */
	protected $run_args = array();

	/**
	 * The integration code of each filter find_all() read, keyed by filter id.
	 *
	 * @var array<int, string>
	 */
	private $filter_integrations = array();

	/**
	 * @param int $recipe_id
	 * @param int $loop_id
	 * @param mixed[] $run_args
	 *
	 * @return void
	 */
	public function __construct( $recipe_id, $loop_id, $run_args ) {

		$this->recipe_id = $recipe_id;
		$this->loop_id   = $loop_id;
		$this->run_args  = $run_args;
	}

	/**
	 * Sets the loop id.
	 *
	 * @param int $loop_id
	 *
	 * @return void
	 */
	public function set_loop_id( $loop_id ) {
		$this->loop_id = absint( $loop_id );
	}

	/**
	 * Sets the loop type.
	 *
	 * @param string $type
	 * @return void
	 */
	public function set_loop_type( $type ) {
		$this->loop_type = $type;
	}

	/**
	 * Returns the loop type.
	 *
	 * @return string
	 */
	public function get_loop_type() {
		return $this->loop_type;
	}

	/**
	 * Returns the loop id.
	 *
	 * @return int
	 */
	public function get_loop_id() {
		return $this->loop_id;
	}

	/**
	 * Retrieves all filters inside a specific loop.
	 *
	 * Loops are unified `uo-block(loop)` rows whose filters live as
	 * `uo-block-modifier` rows — `automator_pro_get_loop_filters()` is the
	 * guarded read seam (delegates to Free, degrades to WP_Error on a
	 * mismatched Free version) and each row already carries the code, so no
	 * per-filter meta lookups are needed.
	 *
	 * @return mixed[] Map of filter_id => filter code.
	 */
	public function find_all() {

		$filters = automator_pro_get_loop_filters( absint( $this->loop_id ) );

		$loop_filters = array();

		if ( is_wp_error( $filters ) ) {

			automator_log(
				sprintf(
					'Loop %d could not read its filters (%s) — returning no entities.',
					absint( $this->loop_id ),
					$filters->get_error_message()
				),
				'loops',
				true
			);

			return $loop_filters;
		}

		foreach ( (array) $filters as $filter ) {

			$filter_id   = absint( $filter['id'] ?? 0 );
			$filter_code = (string) ( $filter['code'] ?? '' );

			if ( $filter_id > 0 && '' !== $filter_code ) {
				$loop_filters[ $filter_id ]              = $filter_code;
				$this->filter_integrations[ $filter_id ] = (string) ( $filter['integration_code'] ?? '' );
			}
		}

		return $loop_filters;
	}

	/**
	 * Retrieve final entities to iterate from.
	 *
	 * @return int[]
	 */
	public function get_entities() {

		$loop_entity_filters = $this->find_all();

		$entity_list = array();

		// Snapshot the registered-filter map once per call so each iteration can
		// look up the concrete class without re-walking the registry. Filters
		// self-register their class via `static::class` during construction
		// (see Loop_Filter::__construct), which keeps the resolver namespace-
		// agnostic — integrations can house their filters in any namespace
		// they like and the runtime still finds them.
		$registered_classes = self::resolve_registered_classes();

		foreach ( $loop_entity_filters as $filter_id => $entity_filter ) {

			// A filter whose plugin is not active matches nothing, so the loop runs none of its actions; its query never runs.
			$inactive_integration = $this->inactive_integration( absint( $filter_id ) );
			if ( '' !== $inactive_integration ) {
				$entity_list[] = array();
				$this->record_unmatched_filter(
					absint( $filter_id ),
					sprintf(
						/* translators: %s: The name of the integration the loop filter belongs to, for example LearnDash. */
						esc_html_x( '%s is not active, so this loop filter matched nothing and the loop ran none of its actions.', 'Loop filter', 'uncanny-automator-pro' ),
						$this->integration_name( $inactive_integration )
					)
				);
				continue;
			}

			// Prefer the class the filter registered itself with. The loader
			// fix populates the registry under demand loading, so the item
			// map and legacy namespace are defense-in-depth for filters that
			// never self-registered.
			$default_class_mapping = isset( $registered_classes[ $entity_filter ] )
				? $registered_classes[ $entity_filter ]
				: $this->resolve_unregistered_class( $filter_id, $entity_filter );

			$filter_class = apply_filters(
				'uncanny_automator_pro_loop_filter_class',
				$default_class_mapping,
				array(
					'filter'         => $entity_filter,
					'filter_id'      => $filter_id,
					'entity_filters' => $loop_entity_filters,
				)
			);

			$base_class = 'Uncanny_Automator_Pro\\Loops\\Filter\\Base\\Loop_Filter';

			if ( is_subclass_of( $filter_class, $base_class ) ) {

				$loop_id = $this->get_loop_id();

				$filter = new $filter_class( $filter_id, $this->run_args, $loop_id );

				$filter->set_run_args( $this->run_args );
				$filter->set_loop_id( $loop_id );

				try {
					$entities_from_filter = $filter->get_entities();
				} catch ( \Throwable $e ) {
					// The loop cannot start; the run log shows this filter as not met, with the error.
					$this->record_unmatched_filter( absint( $filter_id ), $e->getMessage() );
					throw $e;
				}

				if ( ! is_wp_error( $entities_from_filter ) ) {
					$entity_list[] = $entities_from_filter;
				}
			} else {
				// Fail closed. A filter the runtime cannot resolve must never
				// silently widen the loop audience — contribute an empty set
				// so the intersection yields no entities, and leave a trail.
				$entity_list[] = array();

				automator_log(
					sprintf(
						'Loop filter "%s" (post %d) did not resolve to a Loop_Filter class (tried "%s") — failing closed with an empty entity set.',
						$entity_filter,
						$filter_id,
						is_string( $filter_class ) ? $filter_class : gettype( $filter_class )
					),
					'loops',
					// Forced: this is the trail for a loop that silently returned
					// no entities, and it is useless if it only exists in debug mode.
					true
				);
			}
		}

		if ( empty( $entity_list ) ) {
			return array();
		}

		// Get the intersection of the array to find the entities that are common in two or more filter conditions.
		if ( count( $entity_list ) >= 2 ) {
			if ( Entity_Factory::TYPE_TOKEN === $this->get_loop_type() ) {
				// Return the associative intersection.
				return $this->get_loopable_token_intersection( $entity_list );
			}
			// Return the numeric intersection.
			return $this->get_intersection( $entity_list );
		}

		// Just shift the array if there is only 1 filter condition.
		$entity_list = array_shift( $entity_list );

		return $entity_list;
	}

	/**
	 * The filter's integration code when that integration's plugin is not active, otherwise ''. A filter saved with
	 * no integration code is left to run, as before.
	 *
	 * @since 8.0.0
	 *
	 * @param int $filter_id The loop filter (block modifier) id.
	 *
	 * @return string
	 */
	private function inactive_integration( $filter_id ) {

		$integration = $this->filter_integrations[ $filter_id ] ?? '';

		if ( '' === $integration || ( new Integration_Registry() )->is_plugin_active( $integration ) ) {
			return '';
		}

		return $integration;
	}

	/**
	 * The integration's name for the run log, or its code when the site knows no name for it.
	 *
	 * @since 8.0.0
	 *
	 * @param string $integration The integration code.
	 *
	 * @return string
	 */
	private function integration_name( $integration ) {

		$name = (string) Automator()->get_integration_name_by_code( $integration );

		return '' !== $name ? $name : $integration;
	}

	/**
	 * Record on the run that a loop filter matched nothing, and why, for the run log
	 * (Free's Execution_Log_Store::META_LOOP_FILTER_OUTCOMES). A Free without that record keeps no outcome.
	 *
	 * @since 8.0.0
	 *
	 * @param int    $filter_id The loop filter (block modifier) id.
	 * @param string $message   Why it matched nothing, in plain text.
	 *
	 * @return void
	 */
	private function record_unmatched_filter( $filter_id, $message ) {

		$recipe_log_id = absint( $this->run_args['recipe_log_id'] ?? 0 );

		if ( 0 === $recipe_log_id || ! defined( Execution_Log_Store::class . '::META_LOOP_FILTER_OUTCOMES' ) ) {
			return;
		}

		Database::get_execution_log_store()->merge_recipe_log_meta_entry(
			absint( $this->recipe_id ),
			$recipe_log_id,
			Execution_Log_Store::META_LOOP_FILTER_OUTCOMES,
			(string) $filter_id,
			array(
				'met'     => false,
				'message' => (string) $message,
			)
		);
	}

	/**
	 * Calculates the intersection of entities. Returns a subset of data that is common to all lists.
	 *
	 * @param mixed[] $entities_list
	 *
	 * @return int[]
	 */
	private function get_intersection( $entities_list ) {

		$intersection = (array) call_user_func_array( 'array_intersect', $entities_list );

		return array_map( 'absint', $intersection );
	}

	/**
	 * Calculates the intersection of associative intities.
	 *
	 * @param mixed[] $entities_list
	 *
	 * @return mixed[]
	 */
	private function get_loopable_token_intersection( $entities_list ) {

		$intersection_map = $this->convert_to_hash_map( $entities_list[0] );

		// Iterate through each subsequent array and find intersection.
		$total = count( $entities_list );
		for ( $i = 1; $i < $total; $i++ ) {
			$current_map      = $this->convert_to_hash_map( $entities_list[ $i ] );
			$intersection_map = array_intersect_key( $intersection_map, $current_map );
		}

		// Convert hash map back to array.
		$intersection = array_values( $intersection_map );

		return $intersection;
	}

	/**
	 * Converts array to hashmaps for efficiency.
	 *
	 * @param mixed $array
	 * @return array
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.arrayFound -- existing signature.
	private function convert_to_hash_map( $array ) {
		$map = array();
		foreach ( $array as $item ) {
			$key         = wp_json_encode( $item );
			$map[ $key ] = $item;
		}
		return $map;
	}

	/**
	 * Resolve a loop-filter class for a filter that never self-registered.
	 *
	 * The item map (generated at build time and merged across Free/Pro/
	 * addons) maps every loop filter's composite key to its concrete class,
	 * regardless of namespace. The legacy namespace remains the last resort
	 * for filters that predate both mechanisms.
	 *
	 * @param int    $filter_id     The filter post ID (uo-block-modifier).
	 * @param string $entity_filter The filter code, e.g. WP_USER_HAS_ROLE.
	 *
	 * @return string Fully qualified class name candidate (existence is
	 *                validated by the caller via is_subclass_of()).
	 */
	private function resolve_unregistered_class( $filter_id, $entity_filter ) {

		$legacy_class = 'Uncanny_Automator_Pro\\Loop_Filters\\' . $entity_filter;

		if ( ! class_exists( '\Uncanny_Automator\Recipe_Manifest' ) ) {
			return $legacy_class;
		}

		$integration = (string) get_post_meta( absint( $filter_id ), 'integration', true );

		if ( '' === $integration ) {
			// Unified uo-block-modifier rows may carry the alternate key.
			$integration = (string) get_post_meta( absint( $filter_id ), 'integration_code', true );
		}

		if ( '' === $integration ) {
			return $legacy_class;
		}

		$item_map      = \Uncanny_Automator\Recipe_Manifest::get_instance()->get_item_map();
		$composite_key = $integration . '_' . $entity_filter;

		if ( ! empty( $item_map[ $integration ]['loop_filters'][ $composite_key ]['class'] )
			&& is_string( $item_map[ $integration ]['loop_filters'][ $composite_key ]['class'] ) ) {
			return $item_map[ $integration ]['loop_filters'][ $composite_key ]['class'];
		}

		return $legacy_class;
	}

	/**
	 * Build a flat `meta => fully-qualified-class-name` map from the global
	 * loop-filter registry. Each filter records its concrete class when it
	 * self-registers in Loop_Filter::__construct() so the resolver can find
	 * it regardless of namespace.
	 *
	 * @return array<string, string>
	 */
	private static function resolve_registered_classes() {

		if ( ! function_exists( 'automator_pro_loop_filters' ) ) {
			return array();
		}

		$flat = array();

		foreach ( (array) automator_pro_loop_filters()->get_filters() as $by_integration ) {
			if ( ! is_array( $by_integration ) ) {
				continue;
			}
			foreach ( $by_integration as $meta => $filter_data ) {
				if ( is_array( $filter_data ) && ! empty( $filter_data['class'] ) && is_string( $filter_data['class'] ) ) {
					$flat[ $meta ] = $filter_data['class'];
				}
			}
		}

		return $flat;
	}
}
