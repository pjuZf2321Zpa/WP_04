<?php
namespace Uncanny_Automator_Pro\Loops;

use Uncanny_Automator\Automator_Status;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Query;
use Uncanny_Automator_Pro\Loops_Process_Registry;

use WP_REST_Response;
use WP_REST_Request;
use WP_Error;
use Uncanny_Automator\Services\Action_Scheduler;

/**
 * Class Process_Controller
 *
 * @since 5.0
 */
class Process_Controller {

	/**
	 * Handles various commands
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_Rest_Response|WP_Error|mixed[]
	 */
	public function handle( $request ) {

		// The action to execute.
		$action = $request->get_param( 'action' );

		// The process ID.
		$process_id = strval( $request->get_param( 'process_id' ) ); // @phpstan-ignore-line

		$transports = Loops_Process_Registry::get_instance();

		// Retrieve the loop process.
		$loop_process = $transports->get_object( $process_id );

		if ( empty( $loop_process ) ) {
			return new \WP_Error(
				'loop_process_not_found',
				'Cannot find loop process with process ID of: ' . $process_id,
				array(
					'received' => time(),
				)
			);
		}

		$command = $this->apply( $loop_process, (string) $action, $process_id );

		return array(
			'success'    => true,
			'state'      => array(
				'is_processing' => $loop_process->is_processing(),
				'is_active'     => $loop_process->is_active(),
				'is_paused'     => $loop_process->is_paused(),
				'is_cancelled'  => $loop_process->is_cancelled(),
				'command'       => 'Issued ' . $command . ' at ' . time(),
			),
			'properties' => array(
				'process_id' => $process_id,
			),
		);

	}

	/**
	 * Move one loop process, whatever asked for it: this route, or the log's block control.
	 *
	 * @param \Uncanny_Automator_Pro\Loops\Loop\Background_Process\Entity_Actions $loop_process The process.
	 * @param string                                                              $action       pause | resume | cancel | cancel_scheduled_actions.
	 * @param string                                                              $process_id   The process id.
	 *
	 * @return string The PROCESS::* command token, empty for a command that issues none.
	 */
	public function apply( $loop_process, $action, $process_id ) {

		switch ( $action ) {
			case 'pause':
				$loop_process->pause();
				return 'PROCESS::PAUSE';
			case 'resume':
				$loop_process->resume();
				return 'PROCESS::RESUME';
			case 'cancel':
				$loop_process->cancel();

				// Make sure its cancelled.
				if ( $loop_process->is_cancelled() ) {

					$loop_entry_query = new Loop_Entry_Query();

					$loop_entry = $loop_entry_query->find_entry_by_process_id( $process_id );

					if ( false !== $loop_entry ) {
						// Mark the current process as cancelled.
						$loop_entry->set_status( Automator_Status::get_class_name( Automator_Status::CANCELLED ) );
						$loop_entry->set_process_date_ended( current_time( 'mysql' ) );
						$loop_entry_query->update( $loop_entry );
						// Finalize recipe — checks for other in-progress loops before writing.
						Recipe\Process::complete_recipe(
							$loop_entry->get_recipe_id(),
							$loop_entry->get_recipe_log_id(),
							$loop_entry->get_run_number()
						);
					}
				}

				return 'PROCESS::CANCEL';
			case 'cancel_scheduled_actions':
				// Cancel all scheduled actions regardless.
				if ( Action_Scheduler::is_available() ) {
					Action_Scheduler::cancel_actions_by_group( $process_id );
				}
				return '';
			default:
				return 'PROCESS::LISTEN';
		}
	}

}
