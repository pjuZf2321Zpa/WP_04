<?php
namespace Uncanny_Automator_Pro\Loops;

/**
 * A simple database driven message queue for
 * proccesing the loop execution in-order on FIFO bases.
 *
 * @class Automator_Loop_MQ
 */
class Loop_MQ {

	/**
	 * @var \wpdb
	 */
	protected $db;

	/**
	 * @var string $table
	 */
	protected $table = '';

	public function __construct() {

		global $wpdb;

		$this->db    = $wpdb;
		$this->table = $wpdb->prefix . 'uap_queue';
	}

	/**
	 * @param string $process_id The process ID.
	 * @param string $state
	 *
	 * @return false|int|-1
	 */
	public function add( $process_id = null, $state = '' ) {

		return $this->db->insert(
			$this->table,
			array(
				'process_id' => $process_id,
				'state'      => $state,
			)
		);
	}

	/**
	 * @param string $process_id
	 *
	 * @return false|array{ID: int, process_id: string, state: string} The process. False if empty result.
	 */
	public function get( $process_id ) {

		$result = (array) $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->table} WHERE process_id = %s",
				$process_id
			),
			ARRAY_A
		);

		if ( empty( $result ) ) {
			return false;
		}

		return $result; // @phpstan-ignore-line (core-wp built-in)
	}

	/**
	 * Remove a process from queue.
	 *
	 * @param string $process_id
	 *
	 * @return int|false The number of rows updated, or false on error.
	 */
	public function remove( $process_id ) {

		// Optional throttle between queue removals. Default 0 (no delay).
		$delay = (int) apply_filters( 'automator_queue_next_delay', 0, $process_id );

		if ( $delay > 0 ) {
			sleep( $delay );
		}

		$queue_item = $this->get( $process_id );

		if ( false === $queue_item ) {
			return false;
		}

		$deleted = $this->db->delete(
			$this->table,
			array(
				'ID' => $queue_item['ID'],
			),
			array(
				'%d',
			)
		);

		return $deleted;
	}

	/**
	 * Determines if the process exists from the queue.
	 *
	 * @param string $process_id
	 *
	 * @return bool
	 */
	public function exists( $process_id ) {

		$process = $this->db->get_var(
			$this->db->prepare(
				"SELECT process_id FROM {$this->table} WHERE process_id = %s",
				$process_id
			)
		);

		return ! empty( $process );
	}

	/**
	 * Determines if there are any active queues.
	 *
	 * @return bool
	 */
	public function has_active() {

		$result = $this->db->get_var( "SELECT 1 FROM {$this->table} LIMIT 1" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery

		return null !== $result;
	}

	/**
	 * Get the next item to process.
	 *
	 * This queue is based on FIFO, next process means the first item in the table.
	 *
	 * @return false|array{'process_id': string} Returns false if process id cannot be found. Otherwise an array.
	 */
	public function get_next_item() {

		$process = $this->db->get_row( "SELECT process_id FROM {$this->table} ORDER BY ID ASC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery

		if ( empty( $process ) ) {
			return false;
		}

		return $process;
	}
}
