<?php
namespace Uncanny_Automator_Pro\Loops;

use Exception;
use Uncanny_Automator\Automator_Status;
use Uncanny_Automator\Automator_Compression;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Item_Data_Query;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Item_Query;
use Uncanny_Automator_Pro\Loops\Loop\Model\Loop_Entry_Item_Model;
use Uncanny_Automator_Pro\Loops_Process_Registry;
use Uncanny_Automator_Pro\Utilities;
use WP_REST_Request;

/**
 * Class Entry_Point
 *
 * Entry point for loop processing. Singleton.
 *
 * @since 5.0
 */
final class Entry_Point {

	/**
	 * The instance of this class.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Retrieves the instance.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register callbacks on construction.
	 *
	 * @return void
	 */
	protected function __construct() {

		// Loops run through Loop_Block_Processor via the Free walker.

		// Update the action status to 'completed' from 'processing'.
		add_action( 'automator_action_created', array( $this, 'complete_loop_entry_item_status' ), 10, 1 );

		// Inject loop filters to integrations.
		add_filter( 'automator_integration_loop_filters', array( $this, 'integration_insert_loop_filters' ), 10, 1 );

		// Register process controller endpoint.
		add_action( 'rest_api_init', array( $this, 'register_process_controller' ), 10, 1 );

		// Handle recipe log deletion.
		add_action( 'automator_recipe_log_deleted', array( $this, 'purge_recipe_run_loops_process' ), 10, 3 );

		// Handle purge requests.
		add_action( 'automator_tables_purged', array( $this, 'purge_all_process' ) );

		// Disable background actions for looped actions (already running in background).
		add_filter( 'automator_action_should_process_in_background', array( $this, 'disable_background_actions' ), 10, 2 );
	}

	/**
	 * Disable background processing for actions that are in a loop.
	 *
	 * @param bool   $should_be_process_as_bg Whether the action should run in background.
	 * @param array  $action                  The action data.
	 *
	 * @return bool
	 */
	public function disable_background_actions( $should_be_process_as_bg, $action ) {

		// If action is inside the loop, return false immediately.
		if ( is_array( $action['action_data'] ) && isset( $action['action_data']['loop'] ) ) {
			return false;
		}

		return $should_be_process_as_bg;
	}

	/**
	 * Purges all processes and related storage.
	 *
	 * @return void
	 */
	public function purge_all_process() {

		$registry  = Loops_Process_Registry::get_instance();
		$processes = $registry->get_processes();

		if ( ! empty( $processes ) ) {
			foreach ( $processes as $proc_id => $process ) {
				// Gracefully delete all processes.
				$process->delete_all();

				// Delete the transient as well.
				delete_transient( $proc_id . '_transaction_transient' );
			}
		}

		// Truncate individual tables.
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}uap_loop_entries" );
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}uap_loop_entries_items" );
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}uap_loop_entries_items_data" );
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}uap_queue" );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery

		// Delete all wp_options processes in chunks to avoid memory exhaustion.
		// This safely deletes stale processes as well.
		$loops_process  = '%' . $wpdb->esc_like( 'uap_loops_loop_process_' ) . '%';
		$batch_size     = 100; // Delete 100 rows at a time.
		$max_iterations = 10000; // Safety limit: max 1M rows (100 * 10000).
		$iteration      = 0;

		// Keep deleting in batches until no rows remain.
		do {
			$deleted = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"DELETE FROM $wpdb->options WHERE option_name LIKE %s LIMIT %d",
					$loops_process,
					$batch_size
				)
			);

			$iteration++;

		} while ( $deleted > 0 && $iteration < $max_iterations );
	}

	/**
	 * Purges recipe-run loop processes.
	 *
	 * @param int $recipe_id       Recipe ID.
	 * @param int $recipe_log_id   Recipe log ID.
	 * @param int $recipe_run_number Recipe run number.
	 *
	 * @return void
	 */
	public function purge_recipe_run_loops_process( $recipe_id, $recipe_log_id, $recipe_run_number ) {
		$registry = Loops_Process_Registry::get_instance();
		$registry->delete_process( $recipe_id, $recipe_log_id, $recipe_run_number );
	}

	/**
	 * Injects the registered loop filters into the integration object.
	 *
	 * @param array $filters Existing filters.
	 *
	 * @return array
	 */
	public function integration_insert_loop_filters( $filters ) {
		return array_merge( $filters, automator_pro_loop_filters()->get_filters() );
	}

	/**
	 * Completes a loop entry item's status when the loop starts running actions under it.
	 *
	 * Callback to 'automator_action_created'.
	 *
	 * @param array{error_message:null|string,action_data:array{error_message:string,completed:int,loop:null|array{user_id:int,entity_id:int,action_id:int,loop_item:array{id:int,recipe_id:int,filter_id:string,recipe_log_id:int,run_number:int}}}} $args Args.
	 *
	 * @return void
	 */
	public function complete_loop_entry_item_status( $args ) {

		$action_data = $args['action_data'];

		// Bail if from normal actions.
		if ( ! isset( $action_data['loop'] ) ) {
			return;
		}

		$entry_item = new Loop_Entry_Item_Model();
		$record     = new Loop_Entry_Item_Query();
		$data_query = new Loop_Entry_Item_Data_Query();

		$loop_item   = $action_data['loop']['loop_item'];
		$action_id   = absint( $action_data['loop']['action_id'] );
		$action_meta = Utilities::flatten_post_meta( (array) get_post_meta( $action_id ) );

		$serialized_args = maybe_serialize( $args );

		// Store only serialized arrays.
		if ( ! is_string( $serialized_args ) || is_numeric( $serialized_args ) ) {
			$serialized_args = '';
		}

		// Set status to the one sent by Automator process args' action_data.
		$entry_item->set_status( Automator_Status::get_class_name( $action_data['completed'] ) );
		$entry_item->set_user( absint( $action_data['loop']['user_id'] ) );
		$entry_item->set_entity_id( absint( $action_data['loop']['entity_id'] ) );
		$entry_item->set_filter_id( $loop_item['filter_id'] );
		$entry_item->set_recipe_id( $loop_item['recipe_id'] );
		$entry_item->set_recipe_log_id( $loop_item['recipe_log_id'] );
		$entry_item->set_recipe_run_number( $loop_item['run_number'] );
		$entry_item->set_tokens_snapshot( $this->create_token_snapshot( $args ) );

		// Do not persist the large action_data blob; rely on action_data_id instead for tokens.
		$entry_item->set_action_id( $action_id );

		// Store the reference to the deduplicated action data row.
		$data_id = $data_query->find_or_create_by_action_meta( $action_id, $action_meta );
		$entry_item->set_action_data_id( $data_id );

		// Set the error message.
		$error_message = isset( $args['error_message'] ) ? $args['error_message'] : '';
		$entry_item->set_error_message( $error_message );

		// A row parked by a delay block already exists for this entity and action; finish it rather than adding a second.
		$existing = $record->find_by_entity_process(
			absint( $action_data['loop']['user_id'] ),
			absint( $action_data['loop']['entity_id'] ),
			$action_id,
			absint( $loop_item['id'] ),
			absint( $loop_item['recipe_id'] ),
			absint( $loop_item['recipe_log_id'] ),
			absint( $loop_item['run_number'] )
		);

		try {
			if ( false !== $existing ) {
				$entry_item->set_id( $existing->get_id() );
				$record->update( $entry_item );
			} else {
				$record->save( $entry_item );
			}
		} catch ( Exception $e ) {
			$force_log = defined( 'AUTOMATOR_DEBUG_MODE' ) ? AUTOMATOR_DEBUG_MODE : true;

			// @phpstan-ignore-next-line
			automator_log(
				array(
					'message'         => $e->getMessage(),
					'possible_reason' => 'Cannot save the entry in the database. Check if there are any missing tables. Run repair.',
					'args'            => $args,
				),
				'Loop iteration error',
				$force_log,
				'loop-iteration-error'
			);
		}
	}

	/**
	 * Park one loop entry item at in-progress for an action a delay block will run later for this entity.
	 *
	 * @param int   $user_id   Entity user id.
	 * @param int   $entity_id Entity id.
	 * @param int   $action_id Action post id.
	 * @param array $loop_item The loop item (`id`, `filter_id`, `recipe_id`, `recipe_log_id`, `run_number`).
	 *
	 * @return void
	 */
	public function park_entry_item( $user_id, $entity_id, $action_id, $loop_item ) {
		if ( false !== $this->find_entry_item( $user_id, $entity_id, $action_id, $loop_item ) ) {
			return;
		}
		$this->write_entry_item( Automator_Status::IN_PROGRESS, $user_id, $entity_id, $action_id, $loop_item );
	}

	/**
	 * Record an action on a path the entity did not take as skipped: finalizes a parked item, or creates the record.
	 *
	 * @param int   $user_id   Entity user id.
	 * @param int   $entity_id Entity id.
	 * @param int   $action_id Action post id.
	 * @param array $loop_item The loop item.
	 *
	 * @return void
	 */
	public function skip_entry_item( $user_id, $entity_id, $action_id, $loop_item ) {
		$this->settle_entry_item( Automator_Status::SKIPPED, $user_id, $entity_id, $action_id, $loop_item );
	}

	/**
	 * Give the entity's item for an action a terminal status: finalizes a parked item, or creates the record.
	 *
	 * @param int   $status    Terminal Automator_Status value.
	 * @param int   $user_id   Entity user id.
	 * @param int   $entity_id Entity id.
	 * @param int   $action_id Action post id.
	 * @param array $loop_item The loop item.
	 *
	 * @return void
	 */
	public function settle_entry_item( $status, $user_id, $entity_id, $action_id, $loop_item ) {
		$existing = $this->find_entry_item( $user_id, $entity_id, $action_id, $loop_item );
		if ( false !== $existing ) {
			$existing->set_status( Automator_Status::get_class_name( $status ) );
			( new Loop_Entry_Item_Query() )->update( $existing );
			return;
		}
		$this->write_entry_item( $status, $user_id, $entity_id, $action_id, $loop_item );
	}

	/**
	 * The entity's entry item for an action in this loop process, or false.
	 *
	 * @param int   $user_id   Entity user id.
	 * @param int   $entity_id Entity id.
	 * @param int   $action_id Action post id.
	 * @param array $loop_item The loop item.
	 *
	 * @return Loop_Entry_Item_Model|false
	 */
	private function find_entry_item( $user_id, $entity_id, $action_id, $loop_item ) {
		return ( new Loop_Entry_Item_Query() )->find_by_entity_process( absint( $user_id ), absint( $entity_id ), absint( $action_id ), absint( $loop_item['id'] ), absint( $loop_item['recipe_id'] ), absint( $loop_item['recipe_log_id'] ), absint( $loop_item['run_number'] ) );
	}

	/**
	 * Insert an entry item at the given status with the action's deduplicated data reference.
	 *
	 * @param int   $status    Automator_Status value.
	 * @param int   $user_id   Entity user id.
	 * @param int   $entity_id Entity id.
	 * @param int   $action_id Action post id.
	 * @param array $loop_item The loop item.
	 *
	 * @return void
	 */
	private function write_entry_item( $status, $user_id, $entity_id, $action_id, $loop_item ) {
		$entry_item = new Loop_Entry_Item_Model();
		$entry_item->set_status( Automator_Status::get_class_name( $status ) );
		$entry_item->set_user( absint( $user_id ) );
		$entry_item->set_entity_id( absint( $entity_id ) );
		$entry_item->set_action_id( absint( $action_id ) );
		$entry_item->set_filter_id( $loop_item['filter_id'] );
		$entry_item->set_recipe_id( absint( $loop_item['recipe_id'] ) );
		$entry_item->set_recipe_log_id( absint( $loop_item['recipe_log_id'] ) );
		$entry_item->set_recipe_run_number( absint( $loop_item['run_number'] ) );
		$entry_item->set_action_data_id(
			( new Loop_Entry_Item_Data_Query() )->find_or_create_by_action_meta( absint( $action_id ), Utilities::flatten_post_meta( (array) get_post_meta( absint( $action_id ) ) ) )
		);

		( new Loop_Entry_Item_Query() )->save( $entry_item );
	}

	/**
	 * Creates a token snapshot.
	 *
	 * @param array $args Args.
	 *
	 * @return string
	 */
	public function create_token_snapshot( $args ) {

		$maybe_parsed = $args['action_data']['maybe_parsed'] ?? array();

		if ( method_exists( Automator_Compression::class, 'maybe_compress_string' ) ) {
			return Automator_Compression::maybe_compress_string(
				maybe_serialize( $maybe_parsed )
			);
		}

		return maybe_serialize( $maybe_parsed );
	}

	/**
	 * Registers various process controllers.
	 *
	 * @param WP_REST_Request $request Request (unused; signature kept for action compatibility).
	 *
	 * @return void
	 */
	public function register_process_controller( $request ) {

		$process_controller = new Process_Controller();

		register_rest_route(
			'uap/v2',
			'/loop/process/(?P<action>\w+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $process_controller, 'handle' ),
				'permission_callback' => function () {
					return current_user_can( automator_pro_get_capability() );
				},
				'args'                => array(
					'process_id' => array(
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Prevents cloning of object.
	 *
	 * @return void
	 */
	protected function __clone() {}

	/**
	 * Prevents unserialization of the object.
	 *
	 * @return void
	 *
	 * @throws Exception Cannot unserialize a singleton.
	 */
	public function __wakeup() {
		throw new Exception( 'Cannot unserialize a singleton.' );
	}
}
