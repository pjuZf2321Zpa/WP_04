<?php
namespace Uncanny_Automator_Pro\Loops\Loopable;

use Uncanny_Automator\Services\Loopable\Action_Loopable_Token\Store;
use Uncanny_Automator\Services\Loopable\Data_Integrations\Traits\Array_Loopable;
use Uncanny_Automator\Services\Loopable\Loopable_Token_Collection;
use Uncanny_Automator\Utilities;

/**
 * Shared run pipeline for the loopable data-integration actions.
 *
 * Concretes extend \Uncanny_Automator\Recipe\Action and declare their own
 * setup_action() as usual; this trait carries the pipeline the four copies
 * duplicated — resolve the source content, project the root path, apply
 * LIMIT_ROWS, normalize (per-type seam), build the token collection, hydrate
 * the action token store. RSS keeps its own process_action() (unique-item
 * filtering + completion notice are real per-type behavior) while reusing
 * the trait's collection/hydrate helpers.
 */
trait Loopable_Data_Action {

	use Array_Loopable;

	/**
	 * The type's helpers class exposing make_fields().
	 *
	 * @var class-string
	 */
	protected $helpers_class;

	/**
	 * The token id hydrated into the action token store.
	 *
	 * @var string
	 */
	protected $loopable_token_id;

	/**
	 * The type's Loopable_Source_Analyzer concrete.
	 *
	 * @var class-string
	 */
	protected $analyzer_class;

	/**
	 * Fails the action with the reason when its source is in the wrong format or can't be read.
	 *
	 * @since 8.0.2
	 *
	 * @param mixed[] $meta The action's saved meta.
	 *
	 * @return void
	 *
	 * @throws \Exception When the source can't be used.
	 */
	protected function refuse_unusable_source( array $meta ) {
		$analyzer = $this->analyzer_class;
		foreach ( $analyzer::source_problem( $meta ) as $problem ) {
			throw new \Exception( esc_html( $problem ) );
		}
	}

	/**
	 * Produces the full content array from the saved meta (converter glue).
	 *
	 * @param mixed[] $meta   The action's saved meta.
	 * @param mixed[] $parsed The parsed field values.
	 *
	 * @return mixed[]
	 */
	abstract protected function resolve_content( $meta, $parsed );

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		$helpers = $this->helpers_class;
		return $helpers::make_fields( $this->get_action_meta() );
	}

	/**
	 * JSONPath the content array is projected through. JSON reads ROOT_PATH
	 * from the parsed fields; the others are root.
	 *
	 * @param mixed[] $parsed The parsed field values.
	 *
	 * @return string|null
	 */
	protected function root_path( $parsed ) {
		return '$.';
	}

	/**
	 * Per-type post-projection seam (RSS: atom normalization + uniqueness).
	 *
	 * @param mixed[] $items       The limited content items.
	 * @param mixed[] $action_data The action row.
	 * @param mixed[] $parsed      The parsed field values.
	 *
	 * @return mixed[]
	 */
	protected function normalize_items( $items, $action_data, $parsed ) {
		return $items;
	}

	/**
	 * Builds the token collection (CSV overrides with its flat-row variant).
	 *
	 * @param mixed[] $loopable_array The normalized items.
	 *
	 * @return Loopable_Token_Collection
	 */
	public function create_loopable_items( $loopable_array ) {
		return self::create_loopables( new Loopable_Token_Collection(), $loopable_array );
	}

	/**
	 * Hydrates the action token store.
	 *
	 * @param Loopable_Token_Collection $loopable  The collection.
	 * @param int                       $action_id The action post id.
	 *
	 * @return void
	 */
	protected function hydrate( Loopable_Token_Collection $loopable, $action_id ) {

		$action_token_store = new Store();

		$action_token_store->hydrate_loopable_tokens(
			array( $this->loopable_token_id => $loopable ),
			absint( $action_id )
		);
	}

	/**
	 * Processes the action through the shared pipeline.
	 *
	 * @param int     $user_id     The user id.
	 * @param mixed[] $action_data The action row.
	 * @param int     $recipe_id   The recipe id.
	 * @param mixed[] $args        The run args.
	 * @param mixed[] $parsed      The parsed field values.
	 *
	 * @return bool True on success.
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$this->refuse_unusable_source( (array) ( $action_data['meta'] ?? array() ) );

		$content_array = $this->resolve_content( (array) ( $action_data['meta'] ?? array() ), (array) $parsed );

		$limit = $parsed['LIMIT_ROWS'] ?? null;

		$items = (array) Utilities::get_array_value( $content_array, $this->root_path( (array) $parsed ) );
		$items = (array) Utilities::limit_array_elements( $items, absint( $limit ) );
		$items = $this->normalize_items( $items, $action_data, (array) $parsed );

		$this->hydrate( $this->create_loopable_items( (array) $items ), $action_data['ID'] ?? 0 );

		return true;
	}
}
