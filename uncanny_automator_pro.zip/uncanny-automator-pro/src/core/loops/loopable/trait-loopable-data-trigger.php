<?php
namespace Uncanny_Automator_Pro\Loops\Loopable;

use Uncanny_Automator\Automator_Status;

/**
 * Shared behavior for the loopable data-integration triggers (CSV/JSON/XML/RSS).
 *
 * Concretes extend \Uncanny_Automator\Recipe\Trigger and declare their own
 * setup_trigger() as usual — including the `automator_pro_run_now_recipe`
 * add_action, whose contract is documented on Free's
 * WP_Recipe_Trigger_Store::RUN_NOW_TRIGGER_HOOK. This trait carries only the
 * logic the four copies share: options() delegation, validate() and the field
 * tokens.
 */
trait Loopable_Data_Trigger {

	/**
	 * The type's helpers class exposing make_fields().
	 *
	 * @var class-string
	 */
	protected $helpers_class;

	/**
	 * The type's Loopable_Source_Analyzer concrete.
	 *
	 * @var class-string
	 */
	protected $analyzer_class;

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		$helpers = $this->helpers_class;
		return $helpers::make_fields( $this->get_trigger_meta() );
	}

	/**
	 * Validates the Trigger: the dispatched recipe must be this trigger's
	 * recipe, and its latest log must not be an in-progress run.
	 *
	 * @param array{'ID': int, 'post_status': string, 'meta': mixed[]} $trigger   The trigger row.
	 * @param mixed[]                                                  $hook_args The action hook arguments.
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		$recipe_id           = $trigger['post_parent'] ?? null;
		$recipe_id_from_hook = $hook_args[0] ?? null;

		if ( empty( $recipe_id ) || empty( $recipe_id_from_hook ) ) {
			return false;
		}

		if ( absint( $recipe_id ) !== absint( $recipe_id_from_hook ) ) {
			return false;
		}

		$log = automator_get_recipe_latest_log( $recipe_id );

		return null === $log || Automator_Status::IN_PROGRESS !== $log['completed'];
	}

	/**
	 * Answers the trigger's "Field value" tokens with what the run was saved
	 * with, as an action's field tokens do. The parser has no general answer
	 * for these tokens, and takes a number for a post id without this.
	 *
	 * A file field reads as the file's URL: its saved value is the attachment
	 * as the media library gave it, nonces included.
	 *
	 * @since 8.0.1
	 *
	 * @param array{'ID': int, 'post_status': string, 'meta': mixed[]} $completed_trigger The trigger row.
	 * @param mixed[]                                                  $hook_args         The action hook arguments.
	 *
	 * @return array<string,string> Option code => value, for every field.
	 */
	public function hydrate_tokens( $completed_trigger, $hook_args ) {

		$meta = $completed_trigger['meta'] ?? array();

		// A source in the wrong format, or one that can't be read, fails the run with the reason before the loop
		// reads it: Trigger::process() closes the run as Completed with errors and stores the message.
		$analyzer = $this->analyzer_class;
		foreach ( $analyzer::source_problem( (array) $meta ) as $problem ) {
			throw new \RuntimeException( esc_html( $problem ) );
		}

		$tokens = array();

		foreach ( $this->options() as $field ) {

			$code  = $field['option_code'];
			$value = (string) ( $meta[ $code ] ?? '' );

			if ( 'automator_custom_value' === $value ) {
				$value = (string) ( $meta[ $code . '_custom' ] ?? '' );
			}

			if ( 'file' === ( $field['input_type'] ?? '' ) ) {
				$file  = (array) json_decode( $value, true );
				$value = (string) ( $file[0]['url'] ?? '' );
			}

			$tokens[ $code ] = $value;
		}

		return $tokens;
	}
}
