<?php
namespace Uncanny_Automator_Pro\Loops\Loopable;

use WP_Error;

/**
 * The loopable family's single remote-source fetch.
 *
 * Every CSV/JSON/XML/RSS source URL goes through here — builder analysis, the
 * root-path AJAX endpoints, trigger runs and action runs alike — so the builder
 * can never accept a source the runtime would refuse, and a source that analyzes
 * cannot then fetch differently when the recipe runs.
 *
 * It replaces three policies that disagreed both across integrations and within
 * them: the XML converter's `load_from_url()` (25s, feed user-agent, one redirect
 * hop), the CSV converter's (WordPress defaults, no user-agent), and Free's
 * `Source_Fetch::remote_contents()` (three hops, 200-only, no timeout override).
 *
 * SSRF posture is Free's `automator_remote_get_ssrf_safe()` — private and
 * reserved hosts are refused and every redirect hop is re-validated, so a public
 * URL cannot bounce to an internal one.
 */
final class Loopable_Remote_Source {

	/**
	 * Feed and export endpoints are routinely slower than WordPress's 5s default;
	 * this is the value the XML converter has always used.
	 *
	 * @var int
	 */
	const TIMEOUT_SECONDS = 25;

	/**
	 * Redirect hops to follow. Each is re-validated against the private ranges
	 * before it is requested.
	 *
	 * @var int
	 */
	const MAX_REDIRECT_HOPS = 3;

	/**
	 * Object cache group holding the body a source check fetched, for the read that follows it. Non-persistent.
	 *
	 * @var string
	 */
	const CHECKED_GROUP = 'automator_loopable_checked';

	/**
	 * Fetch a user-configured source URL.
	 *
	 * The read right after a source check takes the body the check fetched (see fetch_for_check()), so a check and
	 * its read cost one request, and a feed that answers a repeat request with 429, as Reddit's does, isn't asked
	 * twice. Every other read fetches.
	 *
	 * @param mixed $url The source URL.
	 *
	 * @return string|WP_Error Response body, or WP_Error (invalid_url,
	 *                         automator_ssrf_blocked, automator_too_many_redirects,
	 *                         invalid_response, empty_response, or a transport error).
	 */
	public static function fetch( $url ) {

		if ( ! is_string( $url ) || '' === $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return new WP_Error(
				'invalid_url',
				esc_html_x( 'The URL provided is not valid.', 'Loopable source', 'uncanny-automator-pro' )
			);
		}

		wp_cache_add_non_persistent_groups( array( self::CHECKED_GROUP ) );

		$found   = false;
		$checked = wp_cache_get( md5( $url ), self::CHECKED_GROUP, false, $found );

		if ( $found ) {
			wp_cache_delete( md5( $url ), self::CHECKED_GROUP );
			return $checked;
		}

		$response = automator_remote_get_ssrf_safe( $url, self::request_args( $url ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error(
				'invalid_response',
				esc_html_x( 'The request did not return a valid response.', 'Loopable source', 'uncanny-automator-pro' )
			);
		}

		$body = wp_remote_retrieve_body( $response );

		if ( '' === $body ) {
			return new WP_Error(
				'empty_response',
				esc_html_x( 'No content was found at the provided URL.', 'Loopable source', 'uncanny-automator-pro' )
			);
		}

		return $body;
	}

	/**
	 * Fetch a source URL for a check, and hold the body for the next read of the URL in this request.
	 *
	 * A check always fetches. Only a body is held: after an error, the read asks again.
	 *
	 * @param mixed $url The source URL.
	 *
	 * @return string|WP_Error As fetch().
	 */
	public static function fetch_for_check( $url ) {

		self::forget_check( $url );

		$body = self::fetch( $url );

		if ( is_string( $body ) ) {
			wp_cache_set( md5( $url ), $body, self::CHECKED_GROUP );
		}

		return $body;
	}

	/**
	 * Drop the body a check holds for a URL, when no read will follow the check.
	 *
	 * @param mixed $url The source URL.
	 *
	 * @return void
	 */
	public static function forget_check( $url ) {
		wp_cache_add_non_persistent_groups( array( self::CHECKED_GROUP ) );
		wp_cache_delete( md5( (string) $url ), self::CHECKED_GROUP );
	}

	/**
	 * Request arguments shared by every source fetch in the family.
	 *
	 * The user-agent override is deliberate: some feeds reject WordPress's
	 * default agent string.
	 *
	 * @param string $url The source URL, passed to the core timeout filter.
	 *
	 * @return array<string,mixed>
	 */
	private static function request_args( string $url ): array {

		return array(
			'timeout'     => apply_filters( 'http_request_timeout', self::TIMEOUT_SECONDS, $url ),
			// get_bloginfo( 'version' ), not wp_get_wp_version(): the latter is WP 6.7+
			// and both plugins support 5.8. Both return $wp_version, so the agent string
			// is unchanged.
			'user-agent'  => 'WordPress/' . get_bloginfo( 'version' ) . ';' . urlencode( get_bloginfo( 'url' ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode -- matches the agent the XML converter has always sent.
			'redirection' => self::MAX_REDIRECT_HOPS,
		);
	}
}
