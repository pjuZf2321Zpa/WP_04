<?php
namespace Uncanny_Automator_Pro\Loops\Loopable;

/**
 * Shared wiring for the loopable data integrations (CSV/JSON/XML/RSS).
 *
 * Concretes extend \Uncanny_Automator\Integration and declare their own
 * setup() as usual (identity setters + load_hooks call), with the family
 * config on the properties below. This trait carries the wiring the four
 * copies duplicated: mime merging, the analyzer listener, declared AJAX
 * hooks, and load() instantiation. The shared Token_Loop_Auto listeners are
 * NOT wired here — Loops\Loopable\Bootstrap registers those once.
 */
trait Loopable_Data_Integration {

	/**
	 * The Loopable_Source_Analyzer concrete for this type.
	 *
	 * @var class-string
	 */
	protected $analyzer_class;

	/**
	 * The trigger class load() instantiates.
	 *
	 * @var class-string
	 */
	protected $trigger_class;

	/**
	 * The action class load() instantiates.
	 *
	 * @var class-string
	 */
	protected $action_class;

	/**
	 * Upload mime map to merge, extension => type.
	 *
	 * @var array<string,string>
	 */
	protected $mime_entries = array();

	/**
	 * Extra AJAX hooks, hook => callable (JSON/XML root-path endpoints).
	 *
	 * @var array<string,callable>
	 */
	protected $ajax_hooks = array();

	/**
	 * Wires the declared hooks.
	 *
	 * @param mixed $helper Unused; kept for the established signature.
	 *
	 * @return void
	 */
	public function load_hooks( $helper ) {

		if ( ! empty( $this->mime_entries ) ) {
			add_filter( 'upload_mimes', array( $this, 'allow_mime_types' ) );
		}

		// Analyze this type's source after an item is saved.
		add_action( 'automator_event_recipe_changed', array( $this->analyzer_class, 'on_recipe_changed' ) );

		// Refuse a save whose source is in the wrong format or can't be read.
		add_filter( 'automator_item_save_refusals', array( $this->analyzer_class, 'refuse_unusable_source' ), 10, 4 );

		foreach ( $this->ajax_hooks as $hook => $callback ) {
			add_action( $hook, $callback, 10, 2 );
		}
	}

	/**
	 * Merges the declared mime entries.
	 *
	 * @param array $mimes Allowed mime types.
	 *
	 * @return array
	 */
	public function allow_mime_types( $mimes ) {
		foreach ( $this->mime_entries as $extension => $type ) {
			$mimes[ $extension ] = $type;
		}
		return $mimes;
	}

	/**
	 * Loads the trigger and action.
	 *
	 * @return void
	 */
	public function load() {
		$trigger_class = $this->trigger_class;
		$action_class  = $this->action_class;

		new $trigger_class();
		new $action_class();
	}
}
