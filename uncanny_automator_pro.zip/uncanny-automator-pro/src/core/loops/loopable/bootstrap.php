<?php
namespace Uncanny_Automator_Pro\Loops\Loopable;

use Uncanny_Automator_Pro\Loops\Recipe\Token_Loop_Auto;

/**
 * One-time wiring for the loopable data-integration family.
 *
 * The Token_Loop_Auto listener is registered here exactly once rather than
 * per-integration behind has_action guards. It still resolves each saved item
 * against its registered definition, but membership of the family is decided by
 * integration code — see Token_Loop_Auto::LOOPABLE_INTEGRATIONS, which exists
 * because declaring a single loopable token is not sufficient identity. Items
 * outside that set no-op.
 */
final class Bootstrap {

	/**
	 * Registers the family's shared listener.
	 *
	 * @return void
	 */
	public static function register() {
		add_action( 'automator_event_recipe_changed', array( Token_Loop_Auto::class, 'on_recipe_changed' ) );
	}
}
