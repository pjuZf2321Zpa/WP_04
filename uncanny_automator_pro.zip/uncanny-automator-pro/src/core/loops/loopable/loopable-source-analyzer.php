<?php
namespace Uncanny_Automator_Pro\Loops\Loopable;

use Uncanny_Automator\Services\Loopable\Data_Integrations\Source_Fetch;
use Uncanny_Automator_Pro\Utilities;
use WP_Error;
use WP_Post;

/**
 * Base for the loopable Content analyzers (CSV/JSON/XML/RSS).
 *
 * Owns the builder-time entry point: gate the saved item on the family's
 * codes, load the post, flatten its meta, and dispatch DATA_SOURCE through
 * the source map. Concretes declare their codes and implement the per-source
 * analyze methods (converter glue + persisted meta keys).
 */
abstract class Loopable_Source_Analyzer {

	/**
	 * What a source's content is, as classify() names it.
	 */
	const KIND_EMPTY         = 'empty';
	const KIND_BINARY        = 'binary';
	const KIND_JSON          = 'json';
	const KIND_JSON_WITH_BOM = 'json_with_bom';
	const KIND_XML           = 'xml';
	const KIND_RSS           = 'rss';
	const KIND_HTML          = 'html';
	const KIND_XHTML         = 'xhtml';
	const KIND_BROKEN_XML    = 'broken_xml';
	const KIND_TEXT          = 'text';

	/**
	 * What a piece of content is, as the parser a run uses would read it.
	 *
	 * @since 8.0.2
	 *
	 * @param string $content The content a source holds.
	 *
	 * @return string One of the KIND_* constants. Text that is none of the others is KIND_TEXT, which CSV reads.
	 */
	public static function classify( $content ) {

		$content = (string) $content;

		// UTF-16 and UTF-32 XML, with or without a BOM, is valid, and the XML parser reads it as it is: its NUL bytes aren't binary.
		if ( false !== strpos( substr( $content, 0, 1024 ), "\0" ) ) {
			$xml = self::parse_xml( $content );
			if ( false !== $xml ) {
				return self::xml_kind( $xml );
			}
		}

		$has_bom = 0 === strncmp( $content, "\xEF\xBB\xBF", 3 );
		$text    = trim( $has_bom ? substr( $content, 3 ) : $content );

		if ( '' === $text ) {
			return self::KIND_EMPTY;
		}

		if ( false !== strpos( substr( $content, 0, 1024 ), "\0" ) ) {
			return self::KIND_BINARY;
		}

		if ( in_array( $text[0], array( '[', '{' ), true ) && is_array( json_decode( $text, true ) ) ) {
			// The JSON parser a run uses can't read JSON behind a UTF-8 BOM.
			return $has_bom ? self::KIND_JSON_WITH_BOM : self::KIND_JSON;
		}

		if ( '<' !== $text[0] ) {
			return self::KIND_TEXT;
		}

		$xml = self::parse_xml( $text );

		if ( false !== $xml ) {
			return self::xml_kind( $xml );
		}

		return self::is_web_page( $text ) ? self::KIND_HTML : self::KIND_BROKEN_XML;
	}

	/**
	 * Whether text that isn't well-formed XML is a web page.
	 *
	 * A page is one html document: comments and an XML declaration can come before its doctype or html tag, and
	 * only whitespace and comments after its closing tag. CSV fields can hold HTML (`<html>`, or whole documents
	 * as fputcsv() writes them), so a second html tag, or data after the closing tag, means CSV. Without a closing
	 * tag, a doctype is a page, and an html tag is one alongside a page's head or body.
	 *
	 * @param string $text The trimmed content, starting with "<".
	 *
	 * @return bool
	 */
	private static function is_web_page( $text ) {

		$start   = (string) preg_replace( '/^(?:\s*(?:<!--.*?-->|<\?xml[^>]*\?>))+\s*/s', '', $text );
		$doctype = 1 === preg_match( '/^<!doctype\s+html/i', $start );

		if ( ! $doctype && 1 !== preg_match( '/^<html[\s>]/i', $start ) ) {
			return false;
		}

		if ( preg_match_all( '/<html[\s>]/i', $text ) > 1 ) {
			return false;
		}

		$close = strripos( $text, '</html' );

		if ( false !== $close ) {
			$after = (string) preg_replace( '/^<\/html\s*>/i', '', substr( $text, $close ) );
			return '' === trim( (string) preg_replace( '/<!--.*?-->/s', '', $after ) );
		}

		return $doctype || 1 === preg_match( '/<(?:head|body)[\s>]/i', $text );
	}

	/**
	 * Parses XML the way the XML converter does, without its warnings and without network access.
	 *
	 * @param string $content The content.
	 *
	 * @return \SimpleXMLElement|false
	 */
	private static function parse_xml( $content ) {
		$previous = libxml_use_internal_errors( true );
		$xml      = simplexml_load_string( $content, 'SimpleXMLElement', LIBXML_NONET );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		return $xml;
	}

	/**
	 * Whether parsed XML is a feed (RSS, Atom or RSS 1.0), a well-formed web page, or other XML.
	 *
	 * Some web pages are well-formed XML (BBC News is). The XML run reads one with its own XPath, but it is still a
	 * web page to RSS unless it holds the items the RSS run reads (//channel/item).
	 *
	 * @param \SimpleXMLElement $xml Parsed XML.
	 *
	 * @return string KIND_RSS, KIND_XHTML or KIND_XML.
	 */
	private static function xml_kind( \SimpleXMLElement $xml ) {

		$root = strtolower( $xml->getName() );

		if ( in_array( $root, array( 'rss', 'feed', 'rdf' ), true ) ) {
			return self::KIND_RSS;
		}

		if ( 'html' === $root && empty( $xml->xpath( '//channel/item' ) ) ) {
			return self::KIND_XHTML;
		}

		return self::KIND_XML;
	}

	/**
	 * The format's name as the site owner reads it: CSV, JSON, XML or RSS.
	 *
	 * @return string
	 */
	abstract protected static function format_name();

	/**
	 * The format's file as the site owner reads it, with its article: "a CSV file", "an RSS feed".
	 *
	 * @return string
	 */
	abstract protected static function format_file();

	/**
	 * The KIND_* constants this format reads.
	 *
	 * @return string[]
	 */
	abstract protected static function accepted_kinds();

	/**
	 * The problem with the source an item's values point at, keyed by the field that holds it.
	 *
	 * Reads what a run reads: the uploaded file, the pasted data or the linked file. A missing value is the
	 * field checks' job, so it is no problem here.
	 *
	 * A save only refuses a link that can never work. A link that fails for now (an HTTP error, a timeout) still
	 * saves, because a valid feed can have a bad minute: YouTube's feed endpoint answers 404 and 500 for real
	 * channels. A run reports every failure.
	 *
	 * @since 8.0.2
	 *
	 * @param array<string,mixed> $values The item's field values, keyed by option code.
	 * @param bool                $saving Whether a save asks, rather than a run.
	 *
	 * @return array<string,string> Option code => the sentence the site owner reads; empty when the source is usable.
	 */
	public static function source_problem( array $values, $saving = false ) {

		$values = array_change_key_case( $values, CASE_UPPER );

		switch ( (string) ( $values['DATA_SOURCE'] ?? '' ) ) {
			case 'upload':
				$field   = 'FILE';
				$content = self::read_uploaded_file( $values['FILE'] ?? '' );
				break;
			case 'paste':
				$field   = 'DATA';
				$content = '' === trim( (string) ( $values['DATA'] ?? '' ) ) ? null : (string) $values['DATA'];
				break;
			case 'link':
				$field   = 'LINK';
				$content = self::read_link( (string) ( $values['LINK'] ?? '' ), (bool) $saving );
				break;
			default:
				return array();
		}

		if ( null === $content ) {
			return array();
		}

		if ( $content instanceof WP_Error ) {
			return array( $field => $content->get_error_message() );
		}

		$kind = self::classify( $content );

		if ( in_array( $kind, static::accepted_kinds(), true ) ) {
			return array();
		}

		// No read follows a refused link, so nothing should take the body its check holds.
		if ( 'LINK' === $field ) {
			Loopable_Remote_Source::forget_check( trim( (string) $values['LINK'] ) );
		}

		return array( $field => self::problem_sentence( $field, $kind ) );
	}

	/**
	 * The uploaded file's contents.
	 *
	 * @param mixed $file The FILE value: the media library's attachments, as JSON or decoded.
	 *
	 * @return string|WP_Error|null Null when no file is chosen.
	 */
	private static function read_uploaded_file( $file ) {

		$files = is_array( $file ) ? $file : (array) json_decode( (string) $file, true );
		$url   = (string) ( $files[0]['url'] ?? '' );

		if ( '' === $url ) {
			return null;
		}

		$path = Source_Fetch::attachment_path_from_url( $url );

		if ( false === $path || ! is_readable( $path ) ) {
			return new WP_Error(
				'loopable_file_missing',
				esc_html_x( 'This file couldn’t be found in the media library. Choose it again.', 'Loopable source', 'uncanny-automator-pro' )
			);
		}

		return (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a media-library file on this site.
	}

	/**
	 * The linked file's contents.
	 *
	 * @param string $url    The LINK value.
	 * @param bool   $saving Whether a save asks: then only a link that can never work is a problem.
	 *
	 * @return string|WP_Error|null Null when no link is given, or when a save meets a failure that can pass.
	 */
	private static function read_link( $url, $saving ) {

		$url = trim( $url );

		if ( '' === $url ) {
			return null;
		}

		$body = Loopable_Remote_Source::fetch_for_check( $url );

		// Not a URL, or a private or reserved host: these never work. A redirect chain can change, so it passes.
		$never_works = array( 'invalid_url', 'automator_ssrf_blocked' );

		if ( $saving && is_wp_error( $body ) && ! in_array( $body->get_error_code(), $never_works, true ) ) {
			return null;
		}

		if ( is_wp_error( $body ) ) {
			return new WP_Error(
				$body->get_error_code(),
				sprintf(
					/* translators: %s: why the link couldn't be read */
					esc_html_x( 'This link couldn’t be read: %s', 'Loopable source', 'uncanny-automator-pro' ),
					esc_html( $body->get_error_message() )
				)
			);
		}

		return (string) $body;
	}

	/**
	 * The sentence for a source of the wrong kind.
	 *
	 * @param string $field FILE, DATA or LINK.
	 * @param string $kind  What the content is, one of the KIND_* constants.
	 *
	 * @return string
	 */
	private static function problem_sentence( $field, $kind ) {

		$subjects = array(
			'FILE' => esc_html_x( 'This file', 'Loopable source', 'uncanny-automator-pro' ),
			'DATA' => esc_html_x( 'This data', 'Loopable source', 'uncanny-automator-pro' ),
			'LINK' => esc_html_x( 'This link', 'Loopable source', 'uncanny-automator-pro' ),
		);
		$subject  = $subjects[ $field ];

		if ( self::KIND_EMPTY === $kind ) {
			/* translators: %s: "This file", "This data" or "This link" */
			return sprintf( esc_html_x( '%s is empty.', 'Loopable source', 'uncanny-automator-pro' ), $subject );
		}

		$remedies = array(
			/* translators: %s: the format's file, such as "a CSV file" */
			'FILE' => sprintf( esc_html_x( 'Choose %s instead.', 'Loopable source', 'uncanny-automator-pro' ), static::format_file() ),
			/* translators: %s: the format, such as CSV */
			'DATA' => sprintf( esc_html_x( 'Paste %s data instead.', 'Loopable source', 'uncanny-automator-pro' ), static::format_name() ),
			/* translators: %s: the format's file, such as "a CSV file" */
			'LINK' => sprintf( esc_html_x( 'Link to %s instead.', 'Loopable source', 'uncanny-automator-pro' ), static::format_file() ),
		);
		$remedy   = $remedies[ $field ];

		$looks_like = array(
			self::KIND_JSON          => 'JSON',
			self::KIND_JSON_WITH_BOM => 'JSON',
			self::KIND_XML           => 'XML',
			self::KIND_RSS           => 'RSS',
			self::KIND_HTML          => esc_html_x( 'a web page', 'Loopable source', 'uncanny-automator-pro' ),
			self::KIND_XHTML         => esc_html_x( 'a web page', 'Loopable source', 'uncanny-automator-pro' ),
		);

		// JSON this format would read, but for the BOM in front of it.
		if ( self::KIND_JSON_WITH_BOM === $kind && in_array( self::KIND_JSON, static::accepted_kinds(), true ) ) {
			return sprintf(
				/* translators: 1: "This file", "This data" or "This link", 2: the format, such as JSON */
				esc_html_x( '%1$s starts with a byte order mark (BOM), so it can’t be read as %2$s. Save it as UTF-8 without a BOM instead.', 'Loopable source', 'uncanny-automator-pro' ),
				$subject,
				static::format_name()
			);
		}

		if ( self::KIND_BINARY === $kind ) {
			return sprintf(
				/* translators: 1: "This file", "This data" or "This link", 2: the format, such as CSV */
				esc_html_x( '%1$s isn’t UTF-8 text, so it can’t be read as %2$s.', 'Loopable source', 'uncanny-automator-pro' ),
				$subject,
				static::format_name()
			) . ' ' . $remedy;
		}

		if ( isset( $looks_like[ $kind ] ) ) {
			return sprintf(
				/* translators: 1: "This file", "This data" or "This link", 2: what the content is, 3: the format, such as CSV */
				esc_html_x( '%1$s looks like %2$s, not %3$s.', 'Loopable source', 'uncanny-automator-pro' ),
				$subject,
				$looks_like[ $kind ],
				static::format_name()
			) . ' ' . $remedy;
		}

		return sprintf(
			/* translators: 1: "This file", "This data" or "This link", 2: the format, such as JSON */
			esc_html_x( '%1$s isn’t valid %2$s.', 'Loopable source', 'uncanny-automator-pro' ),
			$subject,
			static::format_name()
		) . ' ' . $remedy;
	}

	/**
	 * The trigger/action codes this analyzer serves.
	 *
	 * @return string[]
	 */
	abstract protected static function item_codes();

	/**
	 * Label passed to automator_log(), e.g. 'CSV error'.
	 *
	 * @return string
	 */
	abstract protected static function log_label();

	/**
	 * automator_log() channel, e.g. 'csv-loopable'.
	 *
	 * @return string
	 */
	abstract protected static function log_channel();

	/**
	 * DATA_SOURCE value → analyze method name.
	 *
	 * @return array<string,string>
	 */
	protected static function source_map() {
		return array(
			'link'   => 'analyze_linked_file',
			'upload' => 'analyze_uploaded_file',
		);
	}

	/**
	 * Refuses a save whose source is in the wrong format or can't be read.
	 *
	 * Listens on Automator's `automator_item_save_refusals`, which the trigger and action CRUD services ask
	 * before they write, so builder, MCP and automator_*() saves are refused alike.
	 *
	 * @since 8.0.2
	 *
	 * @param mixed  $refusals  Option code => message refusals so far.
	 * @param string $item_type Item type ('trigger' | 'action').
	 * @param string $item_code Item code.
	 * @param mixed  $values    The item's field values as the save would store them.
	 *
	 * @return mixed The refusals, with this source's problem when it has one.
	 */
	public static function refuse_unusable_source( $refusals, $item_type, $item_code, $values ) {

		if ( ! is_array( $refusals ) || ! is_array( $values ) || ! in_array( (string) $item_code, static::item_codes(), true ) ) {
			return $refusals;
		}

		return array_merge( $refusals, static::source_problem( $values, true ) );
	}

	/**
	 * Analyze the item's source after it is saved.
	 *
	 * Listens to `automator_event_recipe_changed`, so builder, MCP and
	 * automator_*() saves alike reach it on requests that load the loopable
	 * integration, and reads the just-saved item meta.
	 *
	 * @since 8.0.0
	 *
	 * @param object $event The recipe_changed event.
	 *
	 * @return void
	 */
	public static function on_recipe_changed( $event ) {

		$change = $event->to_array();
		if ( 'deleted' === $change['operation'] || ! in_array( $change['item_type'], array( 'trigger', 'action' ), true ) ) {
			return;
		}

		$item = get_post( absint( $change['item_id'] ) );
		if ( ! $item instanceof WP_Post || ! in_array( (string) get_post_meta( $item->ID, 'code', true ), static::item_codes(), true ) ) {
			return;
		}

		$meta        = Utilities::flatten_post_meta( get_post_meta( $item->ID ) );
		$data_source = $meta['DATA_SOURCE'] ?? '';

		$map = static::source_map();

		if ( isset( $map[ $data_source ] ) ) {
			$method = $map[ $data_source ];
			static::$method( $meta, $item );
		}
	}

	/**
	 * Writes to the analyzer's log channel.
	 *
	 * @param string $message The failure detail.
	 *
	 * @return void
	 */
	protected static function log( $message ) {
		automator_log( $message, static::log_label(), true, static::log_channel() );
	}

	/**
	 * Extracts the contents of the first file in a FILE-field value —
	 * upload-source items store the media-library reference as JSON.
	 *
	 * @param array $file The decoded file's field JSON.
	 *
	 * @return string|void
	 */
	public static function extract_content_from_the_file_field( array $file ) {

		// Bail if json decode returns empty array or the URL is not set from the first file.
		if ( empty( $file ) || ! isset( $file[0]['url'] ) ) {
			return;
		}

		$path = Source_Fetch::attachment_path_from_url( $file[0]['url'] );

		// Bail if path can't be found.
		if ( false === $path ) {
			return;
		}

		// This is not a remote file.
		return file_get_contents( $path ); //phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}
}
