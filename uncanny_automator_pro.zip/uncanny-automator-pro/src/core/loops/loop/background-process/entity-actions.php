<?php
namespace Uncanny_Automator_Pro\Loops\Loop\Background_Process;

use Uncanny_Automator_Pro\Loops\Filter\Registry;
use Uncanny_Automator_Pro\Loops\Loop\Background_Process\Lib\Auth;
use Uncanny_Automator_Pro\Loops\Loop\Background_Process\Lib\WP_Background_Processing\WP_Background_Process;
use Uncanny_Automator_Pro\Loops\Loop\Entity_Factory;
use Uncanny_Automator_Pro\Loops\Loop\Model\Query\Loop_Entry_Item_Query;
use Uncanny_Automator_Pro\Loops\Process_Hooks_Callback;
use Uncanny_Automator_Pro\Loops\Recipe\Process;
use Uncanny_Automator_Pro\Loops\Token;
use Uncanny_Automator_Pro\Loops_Process_Registry;

use Uncanny_Automator\Recipe\Trigger_Late_Resolver;
use Uncanny_Automator\App\Recipe_Builder\Block\Enums\Block_Path_Code;
use Uncanny_Automator\App\Recipe_Runner\Value_Objects\Execution_Context;

/**
 * Class Entity_Actions
 *
 * Entity_Actions class stands for {User}_{Actions} or {Posts}_{Actions}
 *
 * As each item in the task represents the entity and the actions belongs to it.
 *
 * @since 5.0
 */
final class Entity_Actions extends WP_Background_Process {

	/**
	 * @var mixed[] $items
	 */
	protected $items = array();

	/**
	 * @var int $cron_interval
	 */
	protected $cron_interval = 5; // 5 minute.

	/**
	 * The unique identifier prefix.
	 *
	 * @var string
	 */
	protected $prefix = '';

	/**
	 * The unique identifier action.
	 *
	 * @var string
	 */
	protected $action = '';

	/**
	 * @var string
	 */
	const AUTH_ACTION = 'loop_start_process';

	/**
	 * Status for terminated process.
	 *
	 * The 'End Loop' action depends on this status to terminate the process. The
	 * STATUS_TERMINATED is used instead of STATUS_ENDED because "ENDED" is ubiquitous
	 * depending on the context and we don't want to confuse it with the loop termination.
	 *
	 * @var int
	 */
	const STATUS_TERMINATED = 10001; // WP Background Process starts at 1. Lets start at 10001 to avoid conflicts.

	/**
	 * Current batch index
	 *
	 * @var int
	 */
	protected $current_batch_index = 0;

	/**
	 * @param string $process_id
	 *
	 * @return void
	 */
	public function __construct( $process_id = '' ) {

		$this->prefix = 'uap_loops';
		$this->action = $process_id;

		parent::__construct();
	}

	/**
	 * @return void
	 */
	public function clear_process_schedule() {
		$this->clear_scheduled_event();
	}

	/**
	 * @return string
	 */
	public function get_cron_hook_identifier() {
		return $this->cron_hook_identifier;
	}

	/**
	 * This method is copied from \Uncanny_Automator\Recipe\Trigger_Tokens Trait.
	 *
	 * @param mixed $value
	 * @param mixed $pieces
	 * @param mixed $recipe_id
	 * @param mixed[] $trigger_data
	 * @param mixed $user_id
	 * @param mixed $replace_arg
	 * @return mixed
	 */
	public function fetch_token_data( $value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_arg ) {

		if ( empty( $trigger_data ) || ! isset( $trigger_data[0] ) ) {
			return $value;
		}

		if ( ! is_array( $pieces ) || ! isset( $pieces[1] ) || ! isset( $pieces[2] ) ) {
			return $value;
		}

		list( $recipe_id, $token_identifier, $token_id ) = $pieces;

		$data = Automator()->db->token->get( $token_identifier, $replace_arg );
		$data = is_array( $data ) ? $data : json_decode( $data, true );

		if ( is_array( $data ) && isset( $data[ $token_id ] ) ) {
			return $data[ $token_id ];
		}

		return $value;
	}

	/**
	 * Get the current batch index
	 *
	 * @return int
	 */
	public function get_current_batch_index() {
		return $this->current_batch_index;
	}

	/**
	 * @param array{entity_id:int,process_transient:string} $item
	 */
	protected function task( $item ) {

		$throttle_seconds = apply_filters( 'automator_pro_throttle_background_task_execution', 0, $item );

		if ( $throttle_seconds >= 1 ) {
			sleep( $throttle_seconds );
		}

		$transient = Registry::get_process_transient( $item['process_transient'] );

		$entity_id = $item['entity_id'];
		$args      = $transient['args'];
		$loop_item = $transient['loop_item'];
		$loop_node = (array) ( $transient['loop_node'] ?? array() );

		$user_id = $this->register_entity_parsers( $item, $loop_item, (array) $transient['triggers'], $args );

		$args['loop'] = array(
			'user_id'   => $user_id,
			'entity_id' => $entity_id,
			'loop_item' => $loop_item,
		);

		$context = new Execution_Context(
			absint( $loop_item['recipe_id'] ),
			absint( $user_id ),
			absint( $loop_item['recipe_log_id'] ),
			$args,
			array(),
			$this->get_completed_action_ids_for_entity( $user_id, $entity_id, $loop_item )
		);

		Automator()->recipe_runner->children_runner()->run( $loop_node, Block_Path_Code::LOOP_ITERATION_COMPLETED, $context );

		return false;
	}

	/**
	 * Register the token parsers one entity's actions need: trigger token hooks, the common parser,
	 * the entity-type parser, and for token loops the source action's child parsers.
	 *
	 * @param mixed[] $item      Queue item: entity_id, process_transient.
	 * @param mixed[] $loop_item The loop item.
	 * @param mixed[] $triggers  Trigger nodes.
	 * @param mixed[] $args      Process args.
	 *
	 * @return int The user id the entity's actions run as.
	 */
	public function register_entity_parsers( $item, $loop_item, $triggers, $args ) {

		foreach ( $triggers as $trigger ) {
			$this->attach_trigger_token_hooks( $trigger );
		}

		$loop_type = $loop_item['type'];
		$user_id   = absint( $args['user_id'] ?? 0 );

		$common_parser = new Token\Common\Parser();
		$common_parser->register_parser();
		$common_parser->set_loop_item( $item );

		if ( Entity_Factory::TYPE_USERS === $loop_type ) {
			$user_parser = new Token\Users\Parser();
			$user_parser->set_loop_item( $item );
			$user_parser->register_parser();
			$user_id = absint( $item['entity_id'] );
		}

		if ( Entity_Factory::TYPE_POSTS === $loop_type ) {
			$post_parser = new Token\Posts\Parser();
			$post_parser->set_loop_item( $item );
			$post_parser->register_parser();
		}

		if ( Entity_Factory::TYPE_TOKEN === $loop_type ) {
			Token\Loopable\Parser_Support::register_parser( $loop_item );
			$this->register_source_action_child_parsers( $loop_item );
		}

		return $user_id;
	}

	/**
	 * For a token loop fed by an action token, register that action's loopable-token child parsers.
	 *
	 * @param mixed[] $loop_item The loop item.
	 *
	 * @return void
	 */
	private function register_source_action_child_parsers( $loop_item ) {

		$iterable_expression = get_post_meta( absint( $loop_item['id'] ), 'iterable_expression', true );
		$fields              = (array) json_decode( (string) ( $iterable_expression['fields'] ?? '' ), true );
		$value               = (string) ( $fields['TOKEN']['value'] ?? '' );

		if ( ! preg_match( '/ACTION_TOKEN:(\d+)/', $value, $matches ) ) {
			return;
		}

		$action_id   = absint( $matches[1] );
		$action_meta = \Uncanny_Automator\Utilities::flatten_post_meta( get_post_meta( $action_id ) );
		$action      = Automator()->get_action( $action_meta['code'] ?? '' );

		foreach ( (array) ( $action['loopable_tokens'] ?? array() ) as $class ) {
			if ( is_string( $class ) && class_exists( $class ) ) {
				( new $class( $action_id ) )->register_child_parser_hooks();
			}
		}
	}

	/**
	 * Attaches the missing trigger tokens.
	 *
	 * @param  mixed[] $trigger A trigger node from the recipe tree.
	 * @return void
	 */
	public function attach_trigger_token_hooks( $trigger ) {

		$trigger_props = json_decode( Process_Hooks_Callback::json_encode( $trigger ), true );

		if ( false === $trigger ) {
			return;
		}

		if ( ! is_array( $trigger_props ) || ! isset( $trigger_props['integration_code'] ) || ! isset( $trigger_props['code'] ) ) {
			return;
		}

		$filter = strtr(
			'automator_parse_token_for_trigger_{{integration}}_{{trigger_code}}',
			array(
				'{{integration}}'  => strtolower( $trigger_props['integration_code'] ),
				'{{trigger_code}}' => strtolower( $trigger_props['code'] ),
			)
		);

		// Get the token value when `automator_parse_token_for_trigger_{{integration}}_{{trigger_code}}`.
		add_filter( $filter, array( $this, 'fetch_token_data' ), 20, 6 );

		// Loopable tokens.
		$this->register_loopable_trigger_tokens_hooks( $trigger_props['code'], $trigger_props['id'] );
	}

	/**
	 * Register the loopable-token hooks for a trigger driving a loop iteration.
	 *
	 * @param string|null $trigger_code Trigger code.
	 * @param int|null    $trigger_id   Trigger post ID.
	 *
	 * @return void
	 */
	private function register_loopable_trigger_tokens_hooks( $trigger_code, $trigger_id ) {

		$trigger_code = $trigger_code ?? null;

		if ( empty( $trigger_code ) ) {
			return;
		}

		$trigger = Automator()->get_trigger( $trigger_code );

		// Eager-registered triggers carry `loopable_tokens` on the registry.
		$loopable_tokens = is_array( $trigger ) ? ( $trigger['loopable_tokens'] ?? array() ) : array();

		// Lazy-registered triggers emit a stub with no `loopable_tokens`
		// (`setup_trigger()` calls `set_loopable_tokens()` on the instance,
		// but the eager `automator_triggers` filter that would have propagated
		// it to the registry is skipped in deferred-construction mode). Resolve
		// through the constructed instance — memoised across consumers.
		if ( empty( $loopable_tokens ) ) {
			$instance = Trigger_Late_Resolver::get( $trigger_code );
			if ( null !== $instance && method_exists( $instance, 'get_loopable_tokens' ) ) {
				$loopable_tokens = $instance->get_loopable_tokens();
			}
		}

		foreach ( (array) $loopable_tokens as $token_class ) {
			if ( is_string( $token_class ) && class_exists( $token_class ) ) {
				$token_class = new $token_class( $trigger_id );
				$token_class->register_hooks( $trigger );
				$token_class->set_trigger( $trigger );
			}
		}
	}


	/**
	 * Handle a dispatched request.
	 *
	 * Pass each queue item to the task handler, while remaining
	 * within server memory and time limit constraints.
	 *
	 * @return void|mixed
	 */
	protected function handle() {
		$this->lock_process();

		/**
		 * Number of seconds to sleep between batches. Defaults to 0 seconds, minimum 0.
		 *
		 * @param int $seconds
		 */
		$throttle_seconds = max(
			0,
			apply_filters(
				$this->identifier . '_seconds_between_batches',
				apply_filters(
					$this->prefix . '_seconds_between_batches',
					0
				)
			)
		);

		// P1: Checkpoint interval — save batch progress every N items instead of every item.
		// At ~32ms/item, 25 items ≈ 800ms max re-work on crash. Reduces serialization by ~90%.
		$checkpoint_interval = (int) apply_filters( 'automator_pro_loop_checkpoint_interval', 25 );

		// P2: DB guard interval — check is_paused/is_cancelled every N items instead of every item.
		// Saves 2 DB queries per skipped item. Max ~800ms delay responding to pause/cancel.
		$guard_db_interval = (int) apply_filters( 'automator_pro_loop_guard_db_interval', 25 );

		do {
			$batch      = $this->get_batch();
			$item_index = 0;
			$_dirty     = false; // Track whether batch has unsaved changes.

			foreach ( $batch->data as $key => $value ) {
				// Add index to the item.
				$value['batch_index'] = $this->current_batch_index++;

				$task = $this->task( $value );

				++$item_index;

				if ( $this->is_terminated() ) {
					$this->loop_terminated( $value );
					// Clear batches without calling delete_all() because v1.4.0's
					// delete_all() triggers cancelled(), which is the wrong semantic
					// for termination. Status key cleanup happens in complete().
					$remaining_batches = $this->get_batches();
					foreach ( $remaining_batches as $b ) {
						$this->delete( $b->key );
					}
					// Every batch is gone: the flush below would write this one back and start another request.
					$_dirty = false;
					break;
				}

				if ( false !== $task ) {
					$batch->data[ $key ] = $task;
				} else {
					unset( $batch->data[ $key ] );
				}

				$_dirty = true;

				// P1: Checkpoint every N items instead of every item.
				// Reduces O(n²) serialization to O(n²/N). At N=25, that's ~96% reduction.
				if ( 0 === $item_index % $checkpoint_interval && ! empty( $batch->data ) ) {
					$this->update( $batch->key, $batch->data );
					$_dirty = false;
				}

				// Let the server breathe a little.
				sleep( $throttle_seconds );

				// Always check cheap guards (no DB hit).
				$_time_exceeded   = $this->time_exceeded();
				$_memory_exceeded = $this->memory_exceeded();

				// P2: Only check DB-hitting guards every N items.
				$_is_paused    = false;
				$_is_cancelled = false;

				if ( 0 === $item_index % $guard_db_interval ) {
					$_is_paused    = $this->is_paused();
					$_is_cancelled = $this->is_cancelled();
				}

				if ( $_time_exceeded || $_memory_exceeded || $_is_paused || $_is_cancelled ) {
					// Flush unsaved progress before bailing.
					if ( $_dirty && ! empty( $batch->data ) ) {
						$this->update( $batch->key, $batch->data );
						$_dirty = false;
					}

					$this->loop_batch_completed( $value );
					break;
				}
			}

			// Flush any remaining unsaved progress after the foreach.
			if ( $_dirty && ! empty( $batch->data ) ) {
				$this->update( $batch->key, $batch->data );
			}

			// Delete current batch if fully processed.
			if ( empty( $batch->data ) ) {
				if ( isset( $value ) ) {
					$this->loop_batch_completed( $value );
				}
				$this->delete( $batch->key );
			}
		} while ( ! $this->time_exceeded()
			&& ! $this->memory_exceeded()
			&& ! $this->is_queue_empty()
			&& ! $this->is_paused()
			&& ! $this->is_cancelled()
			&& ! $this->is_terminated()
		);

		$this->unlock_process();

		// Start next batch or complete process.
		if ( ! $this->is_queue_empty() ) {
			$this->dispatch();
		} else {
			$this->complete();
		}

		return $this->maybe_wp_die();
	}

	/**
	 * Loop batch completed.
	 *
	 * @param mixed[] $value
	 *
	 * @return void
	 */
	public function loop_batch_completed( array $value ): void {

		if ( ! isset( $value ) || ! isset( $value['process_transient'] ) ) {
			return;
		}

		$process_transient = Registry::get_process_transient( $value['process_transient'] );

		do_action(
			'automator_pro_loop_batch_completed',
			$process_transient['loop_item'],
			$value['process_transient']
		);
	}

	/**
	 * Loop batch item process stopped.
	 *
	 * @param mixed[] $value
	 *
	 * @return void
	 */
	public function loop_terminated( array $value ): void {

		if ( ! isset( $value ) || ! isset( $value['process_transient'] ) ) {
			return;
		}

		$process_transient = Registry::get_process_transient( $value['process_transient'] );

		do_action(
			'automator_pro_loop_batch_item_process_terminated',
			$process_transient['loop_item'],
			$value['process_transient']
		);
	}
	/**
	 * @return void
	 */
	public function cancelled() {

		// Update the status.
		$item_query = new Loop_Entry_Item_Query();
		$item_query->cancel_by_group( $this->action );

		$process_args = Loops_Process_Registry::extract_process_id( $this->action );

		if ( is_array( $process_args ) ) {

			$recipe_id     = $process_args['recipe_id'];
			$recipe_log_id = $process_args['recipe_log_id'];
			$run_number    = $process_args['run_number'];

			Process::complete_recipe( absint( $recipe_id ), absint( $recipe_log_id ), absint( $run_number ) );

			// Start the next one.
			$loop = array(
				'filter_id' => $this->action,
			);

			Process_Hooks_Callback::process_next( $loop );

		}

		parent::cancelled();
	}

	/**
	 * Adds a query parameter to post request.
	 *
	 * @return mixed[]
	 */
	protected function get_query_args() {

		$query_args = parent::get_query_args();

		$token = automator_pro_loop_auth_token()->generate_token( self::AUTH_ACTION );

		$query_args['token'] = $token;

		return $query_args;
	}

	/**
	 * Exits the process with different status.
	 *
	 * @return void
	 */
	public function terminate() {
		update_site_option( $this->get_status_key(), self::STATUS_TERMINATED );
		// In case the process was paused, dispatch it again.
		$this->terminated();
	}

	/**
	 * Triggered when the process is terminated.
	 *
	 * @return void
	 */
	protected function terminated() {
		do_action( $this->identifier . '_terminated' );
	}

	/**
	 * Has the process been terminated?
	 *
	 * @return bool
	 */
	public function is_terminated() {
		$status = get_site_option( $this->get_status_key(), 0 );

		if ( absint( $status ) === self::STATUS_TERMINATED ) {
			return true;
		}

		return false;
	}
	/**
	 * Get action IDs that have already completed for a specific entity in this loop process.
	 *
	 * Used by task() to skip re-execution of actions that completed before a crash.
	 * The checkpoint system only persists the batch pointer every N items, so on
	 * crash recovery the batch may still contain items whose actions already ran.
	 *
	 * @param int|null $user_id   The user ID (null for anonymous).
	 * @param int      $entity_id The loop entity ID.
	 * @param array    $loop_item The loop item metadata.
	 *
	 * @return array<int, true> Action IDs that are already completed, keyed for isset() lookup.
	 */
	public function get_completed_action_ids_for_entity( $user_id, $entity_id, $loop_item ) {

		global $wpdb;

		$process_id = Loops_Process_Registry::generate_process_id_manual(
			$loop_item['id'],
			$loop_item['recipe_id'],
			$loop_item['recipe_log_id'],
			$loop_item['run_number']
		);

		$table = $wpdb->prefix . 'uap_loop_entries_items';

		// Single query: fetch all completed action IDs for this entity + process.
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT action_id FROM {$table}
				WHERE entity_id = %d
					AND filter_id = %s
					AND recipe_id = %d
					AND recipe_log_id = %d
					AND recipe_run_number = %d
					AND status != %s",
				absint( $entity_id ),
				$process_id,
				absint( $loop_item['recipe_id'] ),
				absint( $loop_item['recipe_log_id'] ),
				absint( $loop_item['run_number'] ),
				\Uncanny_Automator\Automator_Status::get_class_name( \Uncanny_Automator\Automator_Status::IN_PROGRESS )
			)
		);

		$lookup = array();

		foreach ( $rows as $action_id ) {
			$lookup[ (int) $action_id ] = true;
		}

		return $lookup;
	}

	/**
	 * Schedule a dispatch.
	 *
	 * @return void
	 */
	public function scheduled_dispatch() {
		$this->schedule_event();
	}
}
