<?php

namespace Uncanny_Automator_Pro\Loops\Loop\Model\Query;

use Uncanny_Automator\App\Infrastructure\Database\Interfaces\Error_Message_Rewrite_Store;
use Uncanny_Automator\App\Infrastructure\Database\Stores\Traits\Error_Message_Like;
use Uncanny_Automator\App\Infrastructure\Exceptions\Store_Exception;

/**
 * The error messages of loop items (uap_loop_entries_items.error_message), walked by ID and rewritten in
 * place for Automator's Error_Message_Rewrite_Store.
 *
 * Loaded only by Migrate_Loop_Gemini_Key_Scrub, and only against an Automator that has the interface.
 *
 * @since 8.0.0
 */
class Loop_Entry_Item_Error_Message_Query implements Error_Message_Rewrite_Store {

	use Error_Message_Like;

	/**
	 * @var \wpdb
	 */
	private $wpdb;

	/**
	 * @since 8.0.0
	 *
	 * @param \wpdb|null $wpdb Database; the global one when null.
	 */
	public function __construct( $wpdb = null ) {

		if ( null === $wpdb ) {
			global $wpdb;
		}

		$this->wpdb = $wpdb;
	}

	/**
	 * @inheritDoc
	 *
	 * @since 8.0.0
	 */
	public function scan_error_messages( int $after_id, int $rows, array $fragments ): array {

		$wpdb = $this->wpdb;
		$like = $this->error_message_like( $rows, $fragments );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- A bounded walk over a log table; nothing to cache.
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, error_message LIKE %s AS matched FROM {$wpdb->prefix}uap_loop_entries_items WHERE ID > %d ORDER BY ID ASC LIMIT %d",
				$like,
				$after_id,
				$rows
			),
			ARRAY_A
		);

		if ( '' !== $wpdb->last_error || ! is_array( $results ) ) {
			throw new Store_Exception( 'The loop items could not be scanned: ' . esc_html( $wpdb->last_error ) );
		}

		$scanned = array();

		foreach ( $results as $row ) {
			$scanned[ (int) $row['ID'] ] = '1' === (string) $row['matched'];
		}

		return $scanned;
	}

	/**
	 * @inheritDoc
	 *
	 * @since 8.0.0
	 */
	public function find_error_message( int $id ): ?string {

		$wpdb = $this->wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One row by primary key, read just before it is rewritten.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT error_message FROM {$wpdb->prefix}uap_loop_entries_items WHERE ID = %d", $id ),
			ARRAY_A
		);

		if ( '' !== $wpdb->last_error ) {
			throw new Store_Exception( 'The loop item could not be read: ' . esc_html( $wpdb->last_error ) );
		}

		return is_array( $row ) ? (string) $row['error_message'] : null;
	}

	/**
	 * @inheritDoc
	 *
	 * @since 8.0.0
	 */
	public function replace_error_message( int $id, string $expected, string $replacement ): bool {

		$wpdb = $this->wpdb;

		// The item keeps its time: date_updated updates itself on any change unless it is set to itself.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Compare-and-set on one row of a log table.
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}uap_loop_entries_items SET error_message = %s, date_updated = date_updated WHERE ID = %d AND CAST(error_message AS BINARY) = CAST(%s AS BINARY)",
				$replacement,
				$id,
				$expected
			)
		);

		if ( false === $updated ) {
			throw new Store_Exception( 'The loop item could not be rewritten: ' . esc_html( $wpdb->last_error ) );
		}

		return 1 === (int) $updated;
	}
}
