<?php
/**
 * Abstract base class for Pro integration helpers.
 *
 * Concrete Pro helpers extend this and compose (never inherit) their
 * counterpart — typically Free's helper for the same integration, but the
 * $base slot is intentionally generic: a Pro helper may compose another
 * Pro source, a vendor SDK wrapper, or anything with the required method
 * surface.
 *
 * Pro-specific helper infrastructure (licensing gates, telemetry) lands
 * here when a concrete need appears — no speculative API.
 *
 * @package Uncanny_Automator_Pro\Recipe
 * @since   Pro 7.3
 */

namespace Uncanny_Automator_Pro\Recipe;

use Uncanny_Automator\Recipe\Abstract_Helpers;

abstract class Abstract_Pro_Helpers extends Abstract_Helpers {

	/**
	 * Composed base helper. Assigned by the concrete Pro helper's
	 * constructor. Intentionally untyped at the abstract level so concrete
	 * classes can narrow via class-level @property docblock (PHPStan +
	 * PhpStorm honor it) without hitting PHP's property-invariance wall.
	 *
	 * @var object|null
	 */
	protected $base;
}
