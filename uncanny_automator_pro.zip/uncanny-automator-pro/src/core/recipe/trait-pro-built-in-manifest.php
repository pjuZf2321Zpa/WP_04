<?php

namespace Uncanny_Automator_Pro;

/**
 * Shared manifest values for Pro's own built-in integrations.
 *
 * Sixteen integrations are Automator Pro functionality rather than a connection
 * to something else, so their metadata is identical: Pro is the plugin, Uncanny
 * Automator is the developer, there is nothing external to install, and the
 * version is Pro's own. Declaring that per integration meant sixteen copies of
 * the same six values.
 *
 * Use this trait and call declare_pro_built_in() from setup(). Integrations that
 * connect to a third party declare their own values instead — this is only for
 * functionality Pro itself provides.
 */
trait Pro_Built_In_Manifest {

	/**
	 * Declare the metadata shared by every Pro built-in integration.
	 *
	 * @return void
	 */
	protected function declare_pro_built_in() {
		$this->set_plugin_file_path( 'uncanny-automator-pro/uncanny-automator-pro.php' );
		$this->set_developer_name( 'Uncanny Automator' );
		$this->set_integration_type( 'built-in' );
		$this->set_distribution_type( 'commercial' );
		$this->set_integration_tier( 'pro-basic' );
		$this->set_integration_version( AUTOMATOR_PRO_PLUGIN_VERSION );
	}
}
