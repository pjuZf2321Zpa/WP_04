<?php
/**
 * Pro Addon Loader
 *
 * Encapsulates Pro-specific registration logic: config building, vendor path
 * detection, filemap/item-map handling, and framework integration fallback.
 *
 * Composes Free's Addon_Registry via Integration_Loader::register_addon()
 * to inject Pro's data into the unified loading pipeline.
 *
 * @package Uncanny_Automator_Pro\Integration_Loader
 * @since   Pro 7.2
 */

namespace Uncanny_Automator_Pro\Integration_Loader;

/**
 * Class Pro_Addon_Loader
 *
 * Single responsibility: build Pro-specific addon config and delegate
 * registration to Free's Addon_Registry. Internal_Triggers_Actions
 * orchestrates WHEN this runs (hook timing, fallback decisions).
 */
class Pro_Addon_Loader {

	/**
	 * Root namespace for Pro classes.
	 *
	 * @var string
	 */
	const NAMESPACE = 'Uncanny_Automator_Pro';

	/**
	 * Absolute path to Pro's integrations directory.
	 *
	 * @var string
	 */
	private $integrations_path;

	/**
	 * Absolute path to Pro's vendor/composer/ directory.
	 *
	 * @var string
	 */
	private $vendor_path;

	/**
	 * Cached result of the filemap existence check.
	 *
	 * @var bool|null null = not yet checked.
	 */
	private $has_filemap;

	/**
	 * Pro_Addon_Loader constructor.
	 *
	 * @param string $pro_root Absolute path to Pro plugin root (dirname of AUTOMATOR_PRO_FILE).
	 */
	public function __construct( $pro_root ) {
		$this->integrations_path = $pro_root . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'integrations';
		$this->vendor_path       = $pro_root . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'composer' . DIRECTORY_SEPARATOR;
	}

	/**
	 * Register Pro's integrations via Free's Addon_Registry API.
	 *
	 * Builds the config array with Pro-specific paths and delegates to
	 * Integration_Loader::register_addon(). Handles the framework integration
	 * fallback when autoload_filemap.php is absent.
	 *
	 * @param array $integrations Pro's integration file map.
	 *
	 * @return bool True if registration succeeded.
	 */
	public function register( array $integrations ) {

		$loader = \Uncanny_Automator\Initialize_Automator::get_instance()->get_loader();
		$config = $this->build_config( $integrations );

		$result = $loader->register_addon( $config );

		// If registration succeeded but Addon_Registry couldn't load framework
		// integrations (no filemap), fall back to the runtime scandir method.
		if ( false !== $result && ! $this->has_filemap() && class_exists( 'Uncanny_Automator\Integration' ) ) {
			$this->load_framework_integrations_fallback();
		}

		return $result;
	}

	/**
	 * Build the addon config array for Free's Addon_Registry.
	 *
	 * @param array $integrations Pro's integration file map.
	 *
	 * @return array Config array for Addon_Registry::register().
	 */
	public function build_config( array $integrations ) {

		$config = array(
			'integrations_path' => $this->integrations_path,
			'namespace'         => self::NAMESPACE,
			'integrations'      => $integrations,
		);

		$item_map_file = $this->vendor_path . 'autoload_item_map.php';
		if ( file_exists( $item_map_file ) ) {
			$config['item_map_file'] = $item_map_file;
		}

		if ( $this->has_filemap() ) {
			$config['filemap_file'] = $this->get_filemap_path();
		}

		// Lazy trigger metadata — Pro's extracted definition() metadata for
		// triggers that opt into lazy loading. Absent on older Pro installs or
		// in dev environments where composer dump has not regenerated vendor;
		// Addon_Registry silently skips the filter wiring in that case. Free
		// versions prior to 7.3 ignore the unknown config key entirely.
		$trigger_metadata_file = $this->vendor_path . 'autoload_trigger_metadata.php';
		if ( file_exists( $trigger_metadata_file ) ) {
			$config['trigger_metadata_file'] = $trigger_metadata_file;
		}

		return $config;
	}

	/**
	 * Whether the pre-built filemap exists.
	 *
	 * @return bool
	 */
	public function has_filemap() {
		if ( null === $this->has_filemap ) {
			$this->has_filemap = file_exists( $this->get_filemap_path() );
		}
		return $this->has_filemap;
	}

	/**
	 * Get the absolute path to Pro's autoload_filemap.php.
	 *
	 * @return string
	 */
	public function get_filemap_path() {
		return $this->vendor_path . 'autoload_filemap.php';
	}

	/**
	 * Get the absolute path to Pro's integrations directory.
	 *
	 * @return string
	 */
	public function get_integrations_path() {
		return $this->integrations_path;
	}

	/**
	 * Get the absolute path to Pro's vendor/composer/ directory.
	 *
	 * @return string
	 */
	public function get_vendor_path() {
		return $this->vendor_path;
	}

	/**
	 * Fallback: load framework integrations via scandir when filemap is absent.
	 *
	 * This mirrors the existing Internal_Triggers_Actions::load_framework_integrations()
	 * behavior for dev environments where autoload_filemap.php hasn't been generated.
	 *
	 * @return void
	 */
	private function load_framework_integrations_fallback() {

		$files = $this->scan_for_load_files();

		if ( empty( $files ) ) {
			return;
		}

		// @todo Next Pro release — consolidate manifest-gating into Free's shared helper.
		//
		// What to do:
		//   1. Delete everything from the "Guard: Free must have Recipe_Manifest" comment
		//      down to the end of this method (lines after this comment block).
		//   2. Replace with this single line:
		//      \Uncanny_Automator\Integration_Loader\Addon_Registry::include_gated_files( $files );
		//
		// Why:
		//   Free 7.2 added Addon_Registry::include_gated_files() (public static) in
		//   src/core/integration-loader/class-addon-registry.php. It encapsulates the
		//   exact same logic below: Recipe_Manifest guard, should_load_all() check,
		//   get_directory_code_map() targeted loop, and should_include_framework_file().
		//   This eliminates the duplication between this method, Internal_Triggers_Actions::
		//   load_framework_integrations(), and Addon_Registry::load_framework_integrations().
		//
		// Prerequisite:
		//   Free 7.2+ must be the minimum required Free version for this Pro release.
		//   The class_exists guard below handles older Free, but once 7.2 is minimum,
		//   that guard is unnecessary and the whole block can be replaced.

		// Guard: Free must have Recipe_Manifest (7.2+). Fall back to full load.
		if ( ! class_exists( '\Uncanny_Automator\Recipe_Manifest' ) ) {
			foreach ( $files as $file ) {
				include_once $file;
			}
			return;
		}

		$manifest = \Uncanny_Automator\Recipe_Manifest::get_instance();

		if ( $manifest->should_load_all() ) {
			foreach ( $files as $file ) {
				include_once $file;
			}
			return;
		}

		// Targeted mode — only include integrations with active codes.
		$dir_codes = $manifest->get_directory_code_map();

		foreach ( $files as $file ) {
			$dir = basename( dirname( $file ) );

			// Directory not in item map — safe fallback: load it.
			if ( ! isset( $dir_codes[ $dir ] ) ) {
				include_once $file;
				continue;
			}

			if ( $manifest->is_integration_needed( $dir_codes[ $dir ] ) ) {
				include_once $file;
			}
		}
	}

	/**
	 * Scan the integrations directory for load.php files.
	 *
	 * @return string[] Array of absolute paths to load.php files.
	 */
	private function scan_for_load_files() {

		$files = array();

		if ( ! is_dir( $this->integrations_path ) ) {
			return $files;
		}

		$dirs = scandir( $this->integrations_path );

		if ( empty( $dirs ) ) {
			return $files;
		}

		foreach ( $dirs as $integration ) {
			if ( '.' === $integration || '..' === $integration ) {
				continue;
			}

			$load_file = $this->integrations_path
				. DIRECTORY_SEPARATOR . $integration
				. DIRECTORY_SEPARATOR . 'load.php';

			if ( is_file( $load_file ) ) {
				$files[] = $load_file;
			}
		}

		return $files;
	}
}
