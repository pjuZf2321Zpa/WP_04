<?php

use Uncanny_Automator_Pro\Loops\Loop\Background_Process\Lib\Auth;

/**
 * Returns incoming webhooks route's prefix.
 *
 * @return string
 */
function automator_pro_get_webhook_route_prefix() {
	return apply_filters( 'automator_pro_get_webhook_route_prefix', 'uap' );
}

/**
 * Only identify and add tokens IF it's edit recipe page
 * @return bool
 */
function automator_pro_do_identify_tokens() {
	if (
		isset( $_REQUEST['action'] ) && //phpcs:ignore WordPress.Security.NonceVerification.Recommended
		(
			'heartbeat' === (string) sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) || //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'wp-remove-post-lock' === (string) sanitize_text_field( wp_unslash( $_REQUEST['action'] ) )  //phpcs:ignore WordPress.Security.NonceVerification.Recommended
		)
	) { //phpcs:ignore WordPress.Security.NonceVerification.Recommended
		// if it's heartbeat, post lock actions bail
		return false;
	}

	if ( ! Automator()->helpers->recipe->is_edit_page() && ! Automator()->helpers->recipe->is_rest() ) {
		// If not automator edit page or rest call, bail
		return false;
	}

	return true;
}

/**
 * Retrieves the filter registry class.
 *
 * Filter registry class is used to load all filters for UI consumption.
 *
 * @return \Uncanny_Automator_Pro\Loops\Filter\Registry
 */
function automator_pro_loop_filters() {

	return \Uncanny_Automator_Pro\Loops\Filter\Registry::get_instance();
}

/**
 * automator_free_older_than
 *
 * Returns true if Automator Free is older than the $version
 *
 * @param mixed $version
 *
 * @return bool|int
 */
function automator_free_older_than( $version ) {

	if ( defined( 'AUTOMATOR_PLUGIN_VERSION' ) ) {
		return version_compare( AUTOMATOR_PLUGIN_VERSION, $version, '<' );
	}

	return false;
}

/**
 * Basic singleton function that returns the Auth object for loops.
 *
 * @return Auth
 */
function automator_pro_loop_auth_token() {

	static $instance = null;

	if ( null === $instance ) {
		$secret   = apply_filters( 'automator_pro_loop_process_secret', '' );
		$instance = new Auth( $secret );
	}

	return $instance;
}

/**
 * Get the required capability for core Automator operations.
 *
 * This function wraps the Free version if available, otherwise implements
 * the same logic. This prevents fatal errors if Pro updates before Free.
 *
 * This capability is used for general operations like viewing/editing recipes,
 * accessing admin pages, viewing logs, and basic recipe management.
 *
 * @since 5.10
 * @return string The capability required. Defaults to 'manage_options'.
 */
function automator_pro_get_capability() {
	// Use Free version if available (single source of truth)
	if ( function_exists( 'automator_get_capability' ) ) {
		return automator_get_capability();
	}

	// Fallback if Free hasn't been updated yet
	return apply_filters( 'automator_capability', 'manage_options' );
}

/**
 * Get the required capability for sensitive administrative operations.
 *
 * This function wraps the Free version if available, otherwise implements
 * the same logic. This prevents fatal errors if Pro updates before Free.
 *
 * This capability is used for sensitive operations that require higher privileges,
 * such as plugin settings, integration credentials, import/export, and system tools.
 *
 * @since 5.10
 * @return string The capability required. Defaults to 'manage_options'.
 */
function automator_pro_get_admin_capability() {
	// Use Free version if available (single source of truth)
	if ( function_exists( 'automator_get_admin_capability' ) ) {
		return automator_get_admin_capability();
	}

	// Fallback if Free hasn't been updated yet
	return apply_filters( 'automator_admin_capability', 'manage_options' );
}

/**
 * Whether a user can manage the site (`manage_options`).
 *
 * This function wraps the Free version if available, otherwise implements
 * the same logic. This prevents fatal errors if Pro updates before Free.
 *
 * @since 7.6.2
 *
 * @param int|\WP_User|false|null $user The matched user, or 0/false when none matched.
 *
 * @return bool
 */
function automator_pro_is_admin_user( $user ) {
	// Use Free version if available (single source of truth).
	if ( function_exists( 'automator_is_admin_user' ) ) {
		return automator_is_admin_user( $user );
	}

	// Fallback if Free hasn't been updated yet.
	return user_can( $user, 'manage_options' );
}

/**
 * Whether a user matched from submitted data (a typed email) may be bound to a recipe run.
 *
 * This function wraps the Free version if available, otherwise implements
 * the same logic. This prevents fatal errors if Pro updates before Free.
 *
 * @since 7.6.2
 *
 * @param int|\WP_User|false|null $user The matched user, or 0/false when none matched.
 *
 * @return bool
 */
function automator_pro_can_bind_user( $user ) {
	// Use Free version if available (single source of truth).
	if ( function_exists( 'automator_can_bind_user' ) ) {
		return automator_can_bind_user( $user );
	}

	// Fallback if Free hasn't been updated yet.
	if ( ! automator_pro_is_admin_user( $user ) ) {
		return true;
	}

	$user_id = $user instanceof \WP_User ? $user->ID : (int) $user;

	return 0 !== $user_id && get_current_user_id() === $user_id;
}

/**
 * Unserialize a value WITHOUT allowing object instantiation (prevents PHP Object Injection).
 *
 * This function wraps the Free version if available (single source of truth),
 * otherwise implements the same safe logic. This prevents fatal errors if Pro
 * updates before Free.
 *
 * Mirrors maybe_unserialize() semantics (non-serialized input returned as-is)
 * but passes allowed_classes => false so an attacker-supplied serialized object
 * string can never instantiate a class. Serialized arrays still decode to arrays.
 *
 * @since 7.3.0.7
 *
 * @param mixed $value Possibly-serialized value.
 *
 * @return mixed Decoded value with objects neutralised, or the original value.
 */
function automator_pro_safe_unserialize( $value ) {
	// Use Free version if available (single source of truth).
	if ( function_exists( 'automator_safe_unserialize' ) ) {
		return automator_safe_unserialize( $value );
	}

	// Fallback if Free hasn't been updated yet.
	if ( ! is_string( $value ) ) {
		return $value;
	}
	$trimmed = trim( $value );
	if ( ! is_serialized( $trimmed ) ) {
		return $value;
	}
	// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize -- only stdClass, which has no magic methods, may be restored (matches Free).
	return unserialize( $trimmed, array( 'allowed_classes' => array( 'stdClass' ) ) );
}

/**
 * Unserialize a value Automator stored from a plugin's object, restoring that plugin's classes.
 *
 * Delegates to Free's automator_unserialize_objects_of(); with an older Free it
 * falls back to automator_pro_safe_unserialize(), which restores stdClass only.
 *
 * @since 7.7.0
 *
 * @param mixed    $value    Possibly-serialized value.
 * @param string[] $families Classes, or their parents, the value may hold.
 *
 * @return mixed
 */
function automator_pro_unserialize_objects_of( $value, array $families ) {
	if ( function_exists( 'automator_unserialize_objects_of' ) ) {
		return automator_unserialize_objects_of( $value, $families );
	}

	return automator_pro_safe_unserialize( $value );
}

/**
 * One trigger in the legacy recipe-object trigger shape: its id and each meta key's first value.
 *
 * For listeners that still take a `{ ID, meta }` trigger array.
 *
 * @since 8.0.0
 *
 * @param int $trigger_id Trigger post id.
 *
 * @return array{ID: int, meta: array<string, mixed>}
 */
function automator_pro_trigger_data( $trigger_id ) {

	$trigger_id = absint( $trigger_id );
	$meta       = array();

	foreach ( (array) get_post_meta( $trigger_id ) as $key => $values ) {
		$meta[ $key ] = $values[0] ?? '';
	}

	return array(
		'ID'   => $trigger_id,
		'meta' => $meta,
	);
}

/**
 * Every trigger of a recipe, live and draft, in the legacy recipe-object trigger shape, in menu order.
 *
 * For listeners that still walk a recipe's `triggers` list.
 *
 * @since 8.0.0
 *
 * @param int $recipe_id Recipe post id.
 *
 * @return array<int, array{ID: int, meta: array<string, mixed>}>
 */
function automator_pro_recipe_triggers_data( $recipe_id ) {

	$triggers = array();

	foreach ( automator_get_recipe_trigger_store()->get_recipe_trigger_posts( absint( $recipe_id ) ) as $trigger_post ) {
		$triggers[] = automator_pro_trigger_data( $trigger_post->ID );
	}

	return $triggers;
}
