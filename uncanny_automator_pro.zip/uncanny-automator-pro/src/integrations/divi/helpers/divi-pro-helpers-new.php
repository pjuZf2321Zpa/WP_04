<?php

namespace Uncanny_Automator_Pro\Integrations\Divi;

use Uncanny_Automator\Integrations\Divi\Divi_Helpers;
use Uncanny_Automator\Integrations\Divi\Divi_Tokens;
use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;

/**
 * Class Divi_Pro_Helpers
 *
 * Composes Free's Divi_Helpers instead of inheriting it. Pro and Free both
 * register the same `automator_remote_data_instance_divi` filter; Pro loads
 * later and wins the dispatcher, so any Free-owned segment Pro still needs
 * to serve is declared as a thin delegator below.
 *
 * @property Divi_Helpers $base
 *
 * @package Uncanny_Automator_Pro\Integrations\Divi
 */
class Divi_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * Constructor — composes the Free helper as $this->base.
	 */
	public function __construct() {
		$this->base = new Divi_Helpers();
	}

	/**
	 * Override the inherited setter to propagate the routing id to $base,
	 * so any delegated builder method (e.g. form_select_config()) calling
	 * $this->base->remote_data_load_config() emits the same `id` Pro uses.
	 *
	 * @param string $remote_data_id
	 *
	 * @return void
	 */
	public function set_remote_data_id( string $remote_data_id ) {
		parent::set_remote_data_id( $remote_data_id );
		$this->base->set_remote_data_id( $remote_data_id );
	}

	// =========================================================================
	// Free-segment delegators — Pro's explicit contract with Free's data plane.
	// One line per segment Pro still needs to serve via the shared `divi` filter.
	// =========================================================================

	/**
	 * Routes the `forms` segment back to Free's owner.
	 *
	 * @param \Uncanny_Automator\App\Transports\Restful\Remote_Data\Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_forms( $request ): array {
		return $this->base->process_remote_data_request( 'forms', $request );
	}

	/**
	 * Lazy tokens accessor — delegates to the Free helper's instance so
	 * Divi_Tokens always receives the concrete Free Divi_Helpers its
	 * constructor type-hint expects.
	 *
	 * @return Divi_Tokens
	 */
	public function tokens(): Divi_Tokens {
		return $this->base->tokens();
	}

	/**
	 * Form-picker option field — delegates to Free which owns the definition
	 * (string lives in 'uncanny-automator' text domain).
	 *
	 * @param string $option_code
	 *
	 * @return array
	 */
	public function form_select_config( $option_code = 'DIVIFORM' ) {
		return $this->base->form_select_config( $option_code );
	}

	// =========================================================================
	// Pro-only option-field builders.
	// =========================================================================

	/**
	 * Cascading "Field" picker — child of the DIVIFORM picker.
	 *
	 * @param string $option_code The trigger's TRIGGER_CODE (legacy quirk: the
	 *                            field picker's option_code mirrors the trigger
	 *                            code in recipe meta).
	 * @param string $parent_code Parent picker's option_code (typically 'DIVIFORM').
	 *
	 * @return array
	 */
	public function field_select_config( $option_code, $parent_code = 'DIVIFORM' ) {
		return array(
			'option_code' => $option_code,
			'label'       => esc_html_x( 'Field', 'Divi', 'uncanny-automator-pro' ),
			'input_type'  => 'select',
			'required'    => true,
			'options'     => array(),
			'remote_data' => $this->remote_data_parent_config( 'form_fields', array( $parent_code ) ),
		);
	}

	/**
	 * Free-text SUBVALUE input — the value the submitted field must equal.
	 *
	 * @return array
	 */
	public function field_value_config() {
		return array(
			'option_code' => 'SUBVALUE',
			'label'       => esc_html_x( 'Value', 'Divi', 'uncanny-automator-pro' ),
			'input_type'  => 'text',
			'required'    => true,
		);
	}

	// =========================================================================
	// Pro-owned segments and helpers.
	// =========================================================================

	/**
	 * Build the option array for a form's fields — shared between the modern
	 * remote_data handler and the legacy AJAX endpoint
	 * (\Uncanny_Automator_Pro\Divi_Pro_Helpers::select_form_fields_func).
	 *
	 * Single source of truth so the modern REST envelope and the legacy
	 * JSON-die response emit identical option shapes.
	 *
	 * @param string $form_id        Stored picker form id.
	 * @param bool   $updated_format Use the {post_id}__{uid}__{idx} keyspace (true for the modern picker, false for legacy *-dep callers).
	 *
	 * @return array Array of [ 'value' => field_id, 'text' => field_title ] entries.
	 */
	public static function form_fields_options( $form_id, $updated_format = true ) {
		if ( '' === $form_id || '-1' === (string) $form_id ) {
			return array();
		}

		$fields  = Divi_Helpers::get_form_by_id( $form_id, $updated_format );
		$options = array();

		foreach ( $fields as $field ) {
			if ( empty( $field['field_id'] ) ) {
				continue;
			}
			$options[] = array(
				'value' => (string) $field['field_id'],
				'text'  => isset( $field['field_title'] ) && '' !== $field['field_title']
					? $field['field_title']
					: (string) $field['field_id'],
			);
		}

		return $options;
	}

	/**
	 * Remote-data handler: list of fields for the form selected in DIVIFORM.
	 *
	 * @param \Uncanny_Automator\App\Transports\Restful\Remote_Data\Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_form_fields( $request ): array {
		$form_id = $request->get_field_value( 'DIVIFORM' );

		return $this->remote_data_success( self::form_fields_options( $form_id, true ) );
	}

	/**
	 * Narrow already-form-matched recipes by the field/value pair the recipe
	 * was configured with.
	 *
	 * Match semantics:
	 * - String values: literal equality on the submitted field's `value`.
	 * - Array values: every comma-separated `SUBVALUE` token must appear in
	 *   the submitted array (i.e. no diff between configured and submitted).
	 *
	 * @param array  $fields_values Hook arg #1 — Divi's submitted-fields map.
	 * @param string $field_id      The field the recipe is matching against.
	 * @param string $expected      The recipe's SUBVALUE meta.
	 *
	 * @return bool
	 */
	public function field_value_matches( array $fields_values, $field_id, $expected ) {
		if ( '' === $field_id ) {
			return false;
		}

		$submitted = $fields_values[ $field_id ]['value'] ?? null;

		if ( null === $submitted ) {
			return false;
		}

		if ( is_array( $submitted ) ) {
			$expected_parts = explode( ',', (string) $expected );
			return empty( array_diff( $expected_parts, $submitted ) );
		}

		return (string) $submitted === (string) $expected;
	}
}
