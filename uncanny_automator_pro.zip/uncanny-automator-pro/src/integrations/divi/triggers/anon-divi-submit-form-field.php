<?php

namespace Uncanny_Automator_Pro\Integrations\Divi;

use Uncanny_Automator\Integrations\Divi\Divi_Helpers;

/**
 * Class ANON_DIVI_SUBMIT_FORM_FIELD
 *
 * Anonymous variant of DIVI_SUBMIT_FORM_FIELD.
 *
 * @property Divi_Pro_Helpers $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Divi
 */
class ANON_DIVI_SUBMIT_FORM_FIELD extends \Uncanny_Automator\Recipe\Trigger {

	const TRIGGER_CODE = 'ANON_DIVI_SUBMIT_FORM_FIELD';
	const TRIGGER_META = 'DIVIFORM';

	/**
	 * Lazy-load definition.
	 *
	 * @return \Uncanny_Automator\Recipe\Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( self::TRIGGER_CODE, 'DIVI' )
			->trigger_meta( self::TRIGGER_META )
			->trigger_type( 'anonymous' )
			->hook( 'et_pb_contact_form_submit', 100, 3 );
	}

	/**
	 * setup_trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {
		// integration / code / trigger_meta / trigger_type / hook are auto-applied from definition().
		$this->set_is_pro( true );

		// translators: %1$s form picker, %2$s value field, %3$s field picker
		$this->set_sentence(
			sprintf(
				esc_html_x(
					'{{A form:%1$s}} is submitted with {{a specific value:%2$s}} in {{a specific field:%3$s}}',
					'Divi',
					'uncanny-automator-pro'
				),
				self::TRIGGER_META,
				'SUBVALUE:' . self::TRIGGER_META,
				self::TRIGGER_CODE . ':' . self::TRIGGER_META
			)
		);
		$this->set_readable_sentence( esc_html_x( '{{A form}} is submitted with {{a specific value}} in {{a specific field}}', 'Divi', 'uncanny-automator-pro' ) );
	}

	/**
	 * options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->form_select_config( self::TRIGGER_META ),
			$this->item_helpers->field_select_config( self::TRIGGER_CODE, self::TRIGGER_META ),
			$this->item_helpers->field_value_config(),
		);
	}

	/**
	 * define_tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return $this->item_helpers->tokens()->define_form_tokens(
			$tokens,
			$trigger['meta'][ self::TRIGGER_META ] ?? '',
			self::TRIGGER_META
		);
	}

	/**
	 * validate.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {
		if ( ! Divi_Helpers::matches_form_selection( $hook_args, $trigger['meta'][ self::TRIGGER_META ] ?? '' ) ) {
			return false;
		}

		return $this->item_helpers->field_value_matches(
			(array) ( $hook_args[0] ?? array() ),
			$trigger['meta'][ self::TRIGGER_CODE ] ?? '',
			$trigger['meta']['SUBVALUE'] ?? ''
		);
	}

	/**
	 * hydrate_tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		return $this->item_helpers->tokens()->hydrate_from_hook_args( $hook_args );
	}
}
