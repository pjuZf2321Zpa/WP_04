<?php

namespace Uncanny_Automator_Pro\Integrations\Divi;

use Uncanny_Automator\Integrations\Divi\Divi_Helpers;

/**
 * Class DIVI_SUBMIT_FORM_FIELD
 *
 * Logged-in user submits a Divi contact form whose chosen field equals a specific value.
 *
 * @property Divi_Pro_Helpers $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Divi
 */
class DIVI_SUBMIT_FORM_FIELD extends \Uncanny_Automator\Recipe\Trigger {

	const TRIGGER_CODE = 'DIVI_SUBMIT_FORM_FIELD';
	const TRIGGER_META = 'DIVIFORM';

	/**
	 * Lazy-load definition.
	 *
	 * @return \Uncanny_Automator\Recipe\Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( self::TRIGGER_CODE, 'DIVI' )
			->trigger_meta( self::TRIGGER_META )
			->hook( 'et_pb_contact_form_submit', 100, 3 );
	}

	/**
	 * setup_trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {
		// integration / code / trigger_meta / trigger_type / hook are auto-applied from definition().
		$this->set_is_pro( true );

		// translators: %1$s form picker, %2$s value field, %3$s field picker
		$this->set_sentence(
			sprintf(
				esc_html_x(
					'A user submits {{a form:%1$s}} with {{a value:%2$s}} in {{a field:%3$s}}',
					'Divi',
					'uncanny-automator-pro'
				),
				self::TRIGGER_META,
				'SUBVALUE:' . self::TRIGGER_META,
				self::TRIGGER_CODE . ':' . self::TRIGGER_META
			)
		);
		$this->set_readable_sentence( esc_html_x( 'A user submits {{a form}} with {{a value}} in {{a field}}', 'Divi', 'uncanny-automator-pro' ) );
	}

	/**
	 * options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->form_select_config( self::TRIGGER_META ),
			$this->item_helpers->field_select_config( self::TRIGGER_CODE, self::TRIGGER_META ),
			$this->item_helpers->field_value_config(),
		);
	}

	/**
	 * define_tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return $this->item_helpers->tokens()->define_form_tokens(
			$tokens,
			$trigger['meta'][ self::TRIGGER_META ] ?? '',
			self::TRIGGER_META
		);
	}

	/**
	 * validate — Free's form gate + Pro's field/value match.
	 * Logged-in gate is handled by the framework via trigger_type='user'.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {
		if ( ! Divi_Helpers::matches_form_selection( $hook_args, $trigger['meta'][ self::TRIGGER_META ] ?? '' ) ) {
			return false;
		}

		return $this->item_helpers->field_value_matches(
			(array) ( $hook_args[0] ?? array() ),
			$trigger['meta'][ self::TRIGGER_CODE ] ?? '',
			$trigger['meta']['SUBVALUE'] ?? ''
		);
	}

	/**
	 * hydrate_tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		return $this->item_helpers->tokens()->hydrate_from_hook_args( $hook_args );
	}
}
