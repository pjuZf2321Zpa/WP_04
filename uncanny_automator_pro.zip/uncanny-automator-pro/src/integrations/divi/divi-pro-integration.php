<?php

namespace Uncanny_Automator_Pro\Integrations\Divi;

/**
 * Class Divi_Pro_Integration
 *
 * @package Uncanny_Automator_Pro\Integrations\Divi
 */
class Divi_Pro_Integration extends \Uncanny_Automator\Integration {

	/**
	 * Integration setup.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->helpers = new Divi_Pro_Helpers();
		$this->set_integration( 'DIVI' );
		$this->set_name( 'Divi' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/divi-icon.svg' );
		// NOTE: Pro setup() is intentionally clean — no singleton shim, no
		// setPro(), no legacy wiring. Pro requires Free to be updated first,
		// so all backward-compat lives in Free.

		$this->set_plugin_file_path( 'divi-builder/divi-builder.php' );
		$this->set_developer_name( 'Elegant Themes' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'commercial' );
	}

	/**
	 * Active only when the Divi theme is the current template.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		$theme = wp_get_theme();

		return 'Divi' === $theme->get_template();
	}

	/**
	 * Load Pro Divi triggers (full-load mode).
	 *
	 * @return void
	 */
	public function load() {
		$this->register_legacy_token_parser();

		new DIVI_SUBMIT_FORM_FIELD( $this->helpers );
		new ANON_DIVI_SUBMIT_FORM_FIELD( $this->helpers );
	}

	/**
	 * Shared hooks (targeted-load mode).
	 *
	 * @return void
	 */
	protected function load_shared_hooks() {
		$this->register_legacy_token_parser();
	}

	/**
	 * Register the legacy `\Uncanny_Automator_Pro\Divi_Pro_Tokens` parser.
	 *
	 * Resolves any recipe still referencing the *_FIELD-shaped token
	 * identifiers (e.g. `DIVI_SUBMIT_FORM_FIELD` as the middle segment) and
	 * Pro's SUBVALUE token. Modern Pro triggers emit DIVIFORM-identifier
	 * tokens which the Free legacy parser handles, so this parser
	 * doesn't double-resolve them — its routing checks are gated on the
	 * Pro-specific trigger codes in $pieces.
	 *
	 * @return void
	 */
	private function register_legacy_token_parser() {
		new \Uncanny_Automator_Pro\Divi_Pro_Tokens();
	}
}
