<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

// Guard: free plugin must have the modern Divi integration loaded.
if ( ! class_exists( 'Uncanny_Automator\Integrations\Divi\Divi_Integration' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Divi\Divi_Pro_Integration' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\Divi\Divi_Pro_Integration();
