<?php

namespace Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration;

use Uncanny_Automator\Integration;

/**
 * Class All_In_One_Wp_Migration_Integration
 *
 * Pro shell for the All-in-One WP Migration integration. The integration code
 * stays 'ALL_IN_ONE_WP_MIGRATION' (shared with Free) so Pro items merge under
 * the same integration in the recipe builder. Pro composes Free's helper through
 * All_In_One_Wp_Migration_Pro_Helpers (extends Abstract_Pro_Helpers, forwards
 * the shared `backup_files_strict` remote-data segment to Free via $base) rather
 * than reaching into Free's concrete helper directly.
 *
 * @package Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration
 */
class All_In_One_Wp_Migration_Integration extends Integration {

	/**
	 * Set up integration code, name, icon and helpers.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->helpers = new All_In_One_Wp_Migration_Pro_Helpers();
		$this->set_integration( 'ALL_IN_ONE_WP_MIGRATION' );
		$this->set_name( 'All-in-One WP Migration' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/all-in-one-wp-migration-icon.svg' );

		$this->set_plugin_file_path( 'all-in-one-wp-migration/all-in-one-wp-migration.php' );
		$this->set_developer_name( 'ServMask' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * Bootstrap Pro triggers, actions and conditions.
	 *
	 * @return void
	 */
	public function load() {
		// Triggers.
		new Ai1wm_Restore_Completed( $this->helpers );
		new Ai1wm_Restore_Failed( $this->helpers );

		// Actions.
		new Ai1wm_Remove_Backup_Label( $this->helpers );

		// Conditions.
		new Ai1wm_Backup_Count( $this->helpers );
	}

	/**
	 * Active when All-in-One WP Migration is installed. `AI1WM_PLUGIN_BASENAME`
	 * is defined in the plugin's main file at load, so it is the earliest
	 * reliable "is the plugin active" signal — the `Ai1wm_*` model classes are
	 * autoloaded later. Every Pro item here runs off the base plugin; none needs
	 * the Unlimited Extension.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return defined( 'AI1WM_PLUGIN_BASENAME' );
	}
}
