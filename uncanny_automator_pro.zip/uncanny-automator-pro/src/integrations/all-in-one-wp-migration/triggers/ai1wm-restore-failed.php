<?php

namespace Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration;

use Uncanny_Automator\Recipe\Trigger;

/**
 * Class Ai1wm_Restore_Failed
 *
 * Fires when an import step throws — All-in-One WP Migration dispatches
 * `ai1wm_status_import_error` from both the database-exception and the general
 * exception path in `Ai1wm_Import_Controller::import()` (2 args: `$params`,
 * `$exception`). Anonymous: a failing import may be running under WP-CLI with no
 * inherent recipe user.
 *
 * The separate `ai1wm_status_upload_error` hook (the file-upload step) is
 * deliberately not listened on — it reports a failure before the import chain
 * starts, and folding it in here would make "a site restore fails" fire for
 * something that was never a restore.
 *
 * @package Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration
 *
 * @property All_In_One_Wp_Migration_Pro_Helpers $item_helpers
 */
class Ai1wm_Restore_Failed extends Trigger {

	/**
	 * @return \Uncanny_Automator\Recipe\Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'AI1WM_RESTORE_FAILED', 'ALL_IN_ONE_WP_MIGRATION' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'AI1WM_RESTORE_FAILURE' )
			->hook( 'ai1wm_status_import_error', 10, 2 );
	}

	/**
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence( esc_html_x( 'A site restore fails', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
		$this->set_readable_sentence( esc_html_x( 'A site restore fails', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
	}

	/**
	 * No options — the failure reason is a free-form exception string with no
	 * finite enum to filter on, so it is surfaced as output tokens instead.
	 *
	 * @return array
	 */
	public function options() {
		return array();
	}

	/**
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->restore_failure_token_definitions() );
	}

	/**
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		// The exception is the payload that matters; $params may legitimately be
		// partial at the point the import blew up, so it is not required here.
		if ( ! isset( $hook_args[1] ) || ! $hook_args[1] instanceof \Throwable ) {
			return false;
		}

		// Anonymous system event — no actor in the payload, so the trigger runs
		// unattributed. Intentionally no set_user_id() / current-user gate.
		return true;
	}

	/**
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		return $this->item_helpers->hydrate_restore_failure_tokens(
			isset( $hook_args[0] ) ? $hook_args[0] : null,
			isset( $hook_args[1] ) ? $hook_args[1] : null
		);
	}
}
