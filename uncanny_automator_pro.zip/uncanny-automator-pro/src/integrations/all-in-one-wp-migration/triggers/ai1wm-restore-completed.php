<?php

namespace Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration;

use Uncanny_Automator\Recipe\Trigger;

/**
 * Class Ai1wm_Restore_Completed
 *
 * Fires after All-in-One WP Migration finishes importing an archive —
 * `ai1wm_status_import_done` (1 arg: `$params`), dispatched at the end of
 * `Ai1wm_Import_Done::execute()` once the database is restored, plugins are
 * re-activated and the site is usable again. Anonymous by design: an import runs
 * from the admin screen or WP-CLI with no inherent recipe user.
 *
 * ⚠️ Self-replacement: by the time this hook fires, the WordPress database has
 * been entirely replaced by the imported one. The recipe that is listening was
 * loaded from the *old* database — its rows only still exist if Automator and
 * that recipe were part of the restored snapshot. Treat this as a
 * logging/notification trigger and expect it to be reliable only when the
 * destination site's backup already contained the recipe.
 *
 * @package Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration
 *
 * @property All_In_One_Wp_Migration_Pro_Helpers $item_helpers
 */
class Ai1wm_Restore_Completed extends Trigger {

	/**
	 * @return \Uncanny_Automator\Recipe\Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'AI1WM_RESTORE_COMPLETED', 'ALL_IN_ONE_WP_MIGRATION' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'AI1WM_RESTORE' )
			->hook( 'ai1wm_status_import_done', 10, 1 );
	}

	/**
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence( esc_html_x( 'A site restore is completed', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
		$this->set_readable_sentence( esc_html_x( 'A site restore is completed', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
	}

	/**
	 * No options — every completed import fires this. The hook carries no
	 * selectable enum to filter on.
	 *
	 * @return array
	 */
	public function options() {
		return array();
	}

	/**
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->restore_token_definitions() );
	}

	/**
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		$params = isset( $hook_args[0] ) ? $hook_args[0] : null;

		if ( ! is_array( $params ) || empty( $params['archive'] ) ) {
			return false;
		}

		// Anonymous system event — no actor in the payload, so the trigger runs
		// unattributed. Intentionally no set_user_id() / current-user gate.
		return true;
	}

	/**
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		return $this->item_helpers->hydrate_restore_tokens( isset( $hook_args[0] ) ? $hook_args[0] : null );
	}
}
