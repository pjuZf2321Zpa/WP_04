<?php

namespace Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration;

use Uncanny_Automator_Pro\Action_Condition;

/**
 * Class Ai1wm_Backup_Count
 *
 * Condition: gate the rest of the recipe on how many `.wpress` backups are
 * currently in the backups directory — the prune-when-over-N gate that pairs
 * with Free's "Delete a backup file" action.
 *
 * The count is read live off disk (`get_files()` scans the backups directory on
 * every call; there are no database records for backups), so it reflects any
 * deletions earlier actions in the same run already made.
 *
 * @package Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration
 *
 * @property All_In_One_Wp_Migration_Pro_Helpers $item_helpers
 */
class Ai1wm_Backup_Count extends Action_Condition {

	/**
	 * Option code of the expected-count field. Kept distinct from the condition
	 * code so the field reads like the rest of the corpus (THRESHOLD /
	 * SCORE_VALUE / WPAL_SEVERITY).
	 */
	const VALUE = 'AI1WM_COUNT_VALUE';

	/**
	 * Define condition metadata.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration = 'ALL_IN_ONE_WP_MIGRATION';

		$this->name = esc_html_x( 'The site backup count is {{greater than, less than, or equal to}} {{a value}}', 'All-in-One WP Migration', 'uncanny-automator-pro' );

		$this->code = 'AI1WM_BACKUP_COUNT';

		$this->dynamic_name = sprintf(
			/* translators: %1$s: Comparison, %2$s: Number of backups */
			esc_html_x( 'The site backup count is {{greater than, less than, or equal to:%1$s}} {{a value:%2$s}}', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
			'NUMBERCOND',
			self::VALUE
		);

		$this->is_pro        = true;
		$this->requires_user = false;
	}

	/**
	 * Whether All-in-One WP Migration is active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return defined( 'AI1WM_PLUGIN_BASENAME' );
	}

	/**
	 * Define condition fields.
	 *
	 * @return array
	 */
	public function fields() {
		return array(
			$this->field->select_field_args(
				array(
					'option_code'           => 'NUMBERCOND',
					'label'                 => esc_html_x( 'Condition', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
					'required'              => true,
					'options'               => $this->item_helpers->comparison_options(),
					'supports_custom_value' => false,
				)
			),
			$this->field->text(
				array(
					'option_code'     => self::VALUE,
					'label'           => esc_html_x( 'Number of backups', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
					'input_type'      => 'int',
					'required'        => true,
					'supports_tokens' => true,
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$comparison = (string) $this->get_parsed_option( 'NUMBERCOND' );
		$expected   = (int) $this->get_parsed_option( self::VALUE );

		if ( '' === $comparison ) {
			$this->condition_failed( 'No comparison selected.' );
			return;
		}

		$actual = $this->item_helpers->get_backup_count();

		if ( ! Automator()->utilities->match_condition_vs_number( $comparison, $expected, $actual ) ) {
			$this->condition_failed(
				sprintf(
					'The site has [%d] backups, which is not %s [%d].',
					$actual,
					$this->item_helpers->comparison_label( $comparison ),
					$expected
				)
			);
		}
	}
}
