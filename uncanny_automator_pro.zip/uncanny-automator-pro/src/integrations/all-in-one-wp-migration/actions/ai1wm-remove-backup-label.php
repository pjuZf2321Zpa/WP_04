<?php

namespace Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration;

use Ai1wm_Backups;
use Uncanny_Automator\Recipe\Action;

/**
 * Class Ai1wm_Remove_Backup_Label
 *
 * Clears a `.wpress` backup's label via `Ai1wm_Backups::delete_label()`, which
 * unsets the filename key in the `ai1wm_backups_labels` option. Pairs with
 * Free's "Set a backup file's label" action. Non-destructive: it only touches
 * the label map, never the archive itself.
 *
 * @package Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration
 *
 * @property All_In_One_Wp_Migration_Pro_Helpers $item_helpers
 */
class Ai1wm_Remove_Backup_Label extends Action {

	/**
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'ALL_IN_ONE_WP_MIGRATION' );
		$this->set_action_code( 'AI1WM_REMOVE_BACKUP_LABEL' );
		$this->set_action_meta( 'AI1WM_BACKUP_FILE' );
		$this->set_is_pro( true );
		// Writes an option, no recipe user needed.
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: %1$s: Backup file selector token placeholder */
				esc_html_x( 'Remove the label from {{a backup file:%1$s}}', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'Remove the label from {{a backup file}}', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
	}

	/**
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'     => $this->get_action_meta(),
				'label'           => esc_html_x( 'Backup file', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options'         => array(),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'backup_files_strict' ),
			),
		);
	}

	/**
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'AI1WM_BACKUP_FILENAME'      => array(
				'name' => esc_html_x( 'Backup filename', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'AI1WM_REMOVED_BACKUP_LABEL' => array(
				'name' => esc_html_x( 'Removed backup label', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! class_exists( '\Ai1wm_Backups' ) ) {
			$this->add_log_error( esc_html_x( 'All-in-One WP Migration is not available.', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
			return false;
		}

		$file = isset( $parsed[ $this->get_action_meta() ] ) ? trim( (string) $parsed[ $this->get_action_meta() ] ) : '';

		if ( '' === $file ) {
			$this->add_log_error( esc_html_x( 'A backup file is required.', 'All-in-One WP Migration', 'uncanny-automator-pro' ) );
			return false;
		}

		// The field is a select fed by remote_data, but it also accepts a token,
		// so the value is not guaranteed to be one of the options we offered.
		// Same trust boundary as Free's set-label action — delete_label() unsets
		// whatever key it is handed without validating it.
		if ( ! $this->item_helpers->is_safe_backup_filename( $file ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: %s: the backup filename */
					esc_html_x( '%s is not a valid backup filename.', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
					$file
				)
			);
			return false;
		}

		// Deliberately no ai1wm_is_filename_supported() check, unlike Free's
		// delete-file and set-label actions: those either touch the archive or
		// write a NEW key into the label map, so they must reject anything that
		// is not a .wpress backup. This action only unsets a key that already
		// exists — the isset() gate below is the stronger guarantee, and an
		// extension check would refuse to clean up a label left behind by an
		// older filename convention.
		$labels = $this->item_helpers->get_backup_labels();

		// delete_label() returns update_option()'s result, which is false when
		// the stored value is unchanged. Removing a label that was never set is
		// a no-op, not a failure, so resolve that case before calling.
		if ( ! isset( $labels[ $file ] ) ) {
			$this->hydrate_tokens(
				array(
					'AI1WM_BACKUP_FILENAME'      => $file,
					'AI1WM_REMOVED_BACKUP_LABEL' => '',
				)
			);
			return true;
		}

		$removed_label = (string) $labels[ $file ];

		if ( ! Ai1wm_Backups::delete_label( $file ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: %s: the backup filename */
					esc_html_x( 'The label for %s could not be removed.', 'All-in-One WP Migration', 'uncanny-automator-pro' ),
					$file
				)
			);
			return false;
		}

		$this->hydrate_tokens(
			array(
				'AI1WM_BACKUP_FILENAME'      => $file,
				'AI1WM_REMOVED_BACKUP_LABEL' => $removed_label,
			)
		);

		return true;
	}
}
