<?php

namespace Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration;

use Uncanny_Automator\App\Transports\Restful\Remote_Data\Remote_Data_Request;
use Uncanny_Automator\Integrations\All_In_One_Wp_Migration\All_In_One_Wp_Migration_Helpers;
use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;

/**
 * Class All_In_One_Wp_Migration_Pro_Helpers
 *
 * Composes Free's All_In_One_Wp_Migration_Helpers via $base. Pro's remove-label
 * action reuses Free's `backup_files_strict` remote-data segment and filename
 * trust boundary, so this class is the decoupling seam — Pro never reaches into
 * Free's concrete helper directly. The delegation block below is Pro's contract
 * with Free: a rename on the Free side surfaces as a PHPStan failure here rather
 * than a production fatal.
 *
 * Pro and Free share the `all_in_one_wp_migration` remote_data_id, so Pro's
 * helper wins the dispatcher filter (registered last) and
 * process_remote_data_request() forwards every segment dispatch to Free.
 *
 * @package Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration
 *
 * @property All_In_One_Wp_Migration_Helpers $base
 */
class All_In_One_Wp_Migration_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * Compose the Free helper.
	 */
	public function __construct() {
		$this->base = new All_In_One_Wp_Migration_Helpers();
	}

	// =========================================================================
	// Delegation block — Pro's explicit contract with Free.
	// =========================================================================

	/**
	 * Forward remote-data dispatch to the composed Free helper — Free owns the
	 * `backup_files_strict` segment that Pro's remove-label action loads.
	 *
	 * @param string              $data
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	public function process_remote_data_request( string $data, Remote_Data_Request $request ): array {
		return $this->base->process_remote_data_request( $data, $request );
	}

	/**
	 * Delegates to Free's is_safe_backup_filename().
	 *
	 * @param string $file
	 *
	 * @return bool
	 */
	public function is_safe_backup_filename( $file ) {
		return $this->base->is_safe_backup_filename( $file );
	}

	/**
	 * Delegates to Free's get_backup_labels().
	 *
	 * @return array<string,string>
	 */
	public function get_backup_labels() {
		return $this->base->get_backup_labels();
	}

	/**
	 * Delegates to Free's get_backup_files().
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function get_backup_files() {
		return $this->base->get_backup_files();
	}

	/**
	 * Delegates to Free's backup_token_definitions().
	 *
	 * @return array<int,array<string,string>>
	 */
	public function backup_token_definitions() {
		return $this->base->backup_token_definitions();
	}

	/**
	 * Delegates to Free's hydrate_backup_tokens().
	 *
	 * @param array $params
	 *
	 * @return array<string,mixed>
	 */
	public function hydrate_backup_tokens( $params ) {
		return $this->base->hydrate_backup_tokens( $params );
	}

	/**
	 * Delegates to Free's backup_failure_token_definitions().
	 *
	 * @return array<int,array<string,string>>
	 */
	public function backup_failure_token_definitions() {
		return $this->base->backup_failure_token_definitions();
	}

	/**
	 * Delegates to Free's hydrate_backup_failure_tokens().
	 *
	 * @param array           $params
	 * @param \Throwable|null $exception
	 *
	 * @return array<string,mixed>
	 */
	public function hydrate_backup_failure_tokens( $params, $exception ) {
		return $this->base->hydrate_backup_failure_tokens( $params, $exception );
	}

	/**
	 * Delegates to Free's static reset_deleting_guard().
	 *
	 * @return void
	 */
	public static function reset_deleting_guard() {
		All_In_One_Wp_Migration_Helpers::reset_deleting_guard();
	}

	// =========================================================================
	// Pro-only helpers.
	// =========================================================================

	/**
	 * Number of `.wpress` backups currently on disk.
	 *
	 * `Ai1wm_Backups::count_files()` is literally `count( get_files() )`, so this
	 * counts the same list through the composed Free getter and inherits its
	 * "plugin not loaded" guard instead of fataling on a missing class.
	 *
	 * @return int
	 */
	public function get_backup_count() {
		return count( $this->get_backup_files() );
	}

	/**
	 * Comparison operators for the backup-count condition, converted from the
	 * legacy `less_or_greater_than()` field to the modern option shape. Sourcing
	 * them from core keeps the stored operator values (`<`, `>`, `=`, `!=`,
	 * `<=`, `>=`) identical to every other numeric condition, which is what
	 * `Automator()->utilities->match_condition_vs_number()` expects.
	 *
	 * @return array<int,array{text:string,value:string}>
	 */
	public function comparison_options() {

		$legacy  = Automator()->helpers->recipe->field->less_or_greater_than();
		$options = array();

		if ( ! is_array( $legacy ) || empty( $legacy['options'] ) ) {
			return $options;
		}

		foreach ( $legacy['options'] as $value => $label ) {
			$options[] = array(
				'text'  => $label,
				'value' => $value,
			);
		}

		return $options;
	}

	/**
	 * Human-readable label for a stored comparison operator, for the condition's
	 * failure log ("is not greater than 5" reads better than "is not > 5").
	 *
	 * Resolved from {@see comparison_options()} rather than the saved
	 * `NUMBERCOND_readable` option, which `get_option()` throws on when the
	 * recipe never stored one. Falls back to the raw operator.
	 *
	 * @param string $operator
	 *
	 * @return string
	 */
	public function comparison_label( $operator ) {

		foreach ( $this->comparison_options() as $option ) {
			if ( $operator === $option['value'] ) {
				return (string) $option['text'];
			}
		}

		return (string) $operator;
	}

	// =========================================================================
	// Restore token definitions and hydration.
	//
	// Restore is Pro-only, so these live here rather than in Free. Hydrators
	// always return the full keyset — a recipe must never see a partial token
	// map when the plugin hands us an incomplete payload.
	// =========================================================================

	/**
	 * Token definitions describing a completed restore (trigger format).
	 *
	 * @return array<int,array<string,string>>
	 */
	public function restore_token_definitions() {
		return array(
			$this->token_def( 'AI1WM_RESTORE_FILENAME', esc_html_x( 'Restored backup filename', 'All-in-One WP Migration', 'uncanny-automator-pro' ), 'text' ),
			$this->token_def( 'AI1WM_RESTORE_SIZE', esc_html_x( 'Restored backup size', 'All-in-One WP Migration', 'uncanny-automator-pro' ), 'text' ),
			$this->token_def( 'AI1WM_RESTORE_BYTES', esc_html_x( 'Restored backup size in bytes', 'All-in-One WP Migration', 'uncanny-automator-pro' ), 'int' ),
		);
	}

	/**
	 * Hydrate the restore tokens from an import `$params` array.
	 *
	 * An import reads the archive from the *storage* directory, not the backups
	 * directory — `Ai1wm_Import_Upload` copies the uploaded file to
	 * `ai1wm_archive_path()` and every later import step extracts from there. So
	 * the size getters here are the `ai1wm_archive_*` variants, the mirror image
	 * of the export-done trigger in Free (which must use `ai1wm_backup_*`
	 * because the export archive has already been renamed into the backups
	 * directory by the time its hook fires).
	 *
	 * Storage is cleaned up after the import chain finishes, so the size is read
	 * defensively: `filesize()` is unguarded inside the plugin's getters and
	 * would warn on a missing file.
	 *
	 * @param array $params Import parameters.
	 *
	 * @return array<string,mixed>
	 */
	public function hydrate_restore_tokens( $params ) {

		$empty = array(
			'AI1WM_RESTORE_FILENAME' => '',
			'AI1WM_RESTORE_SIZE'     => '',
			// Declared as an int token, so the unknown value is 0 — not ''.
			'AI1WM_RESTORE_BYTES'    => 0,
		);

		if ( ! is_array( $params ) || empty( $params['archive'] ) ) {
			return $empty;
		}

		$bytes = $this->archive_bytes( $params );

		return array(
			'AI1WM_RESTORE_FILENAME' => function_exists( 'ai1wm_archive_name' ) ? (string) ai1wm_archive_name( $params ) : basename( (string) $params['archive'] ),
			'AI1WM_RESTORE_SIZE'     => $bytes > 0 && function_exists( 'ai1wm_size_format' ) ? (string) ai1wm_size_format( $bytes ) : '',
			'AI1WM_RESTORE_BYTES'    => $bytes,
		);
	}

	/**
	 * Size in bytes of the archive being imported, or 0 when it is no longer on
	 * disk or the path cannot be resolved.
	 *
	 * `ai1wm_archive_path()` throws `Ai1wm_Archive_Exception` /
	 * `Ai1wm_Storage_Exception` for a missing or illegal `archive` / `storage`
	 * value, and a token trigger must never let that escape into the recipe run
	 * — hence the catch. It is also the function that knows a manual restore
	 * reads from the backups directory rather than storage, which is why the
	 * path is resolved through it instead of being assembled here.
	 *
	 * @param array $params Import parameters.
	 *
	 * @return int
	 */
	private function archive_bytes( $params ) {

		if ( ! function_exists( 'ai1wm_archive_path' ) ) {
			return 0;
		}

		try {
			$path = (string) ai1wm_archive_path( $params );
		} catch ( \Exception $e ) {
			return 0;
		}

		if ( '' === $path || ! file_exists( $path ) ) {
			return 0;
		}

		return (int) filesize( $path );
	}

	/**
	 * Token definitions describing a failed restore (trigger format).
	 *
	 * @return array<int,array<string,string>>
	 */
	public function restore_failure_token_definitions() {
		return array(
			$this->token_def( 'AI1WM_RESTORE_FILENAME', esc_html_x( 'Backup filename', 'All-in-One WP Migration', 'uncanny-automator-pro' ), 'text' ),
			$this->token_def( 'AI1WM_ERROR_MESSAGE', esc_html_x( 'Error message', 'All-in-One WP Migration', 'uncanny-automator-pro' ), 'text' ),
			$this->token_def( 'AI1WM_ERROR_CODE', esc_html_x( 'Error code', 'All-in-One WP Migration', 'uncanny-automator-pro' ), 'text' ),
		);
	}

	/**
	 * Hydrate the failure tokens from the import `$params` and the thrown
	 * exception.
	 *
	 * The filename is read straight off `$params` — a failed import may have
	 * blown up before the archive reached storage, so nothing on disk is
	 * guaranteed and no size is reported.
	 *
	 * @param array           $params    Import parameters at time of failure.
	 * @param \Throwable|null $exception The thrown exception.
	 *
	 * @return array<string,mixed>
	 */
	public function hydrate_restore_failure_tokens( $params, $exception ) {

		$filename = '';

		if ( is_array( $params ) && ! empty( $params['archive'] ) ) {
			$filename = basename( (string) $params['archive'] );
		}

		return array(
			'AI1WM_RESTORE_FILENAME' => $filename,
			'AI1WM_ERROR_MESSAGE'    => $exception instanceof \Throwable ? $exception->getMessage() : '',
			'AI1WM_ERROR_CODE'       => $exception instanceof \Throwable ? (string) $exception->getCode() : '',
		);
	}

	/**
	 * Build a single trigger token definition.
	 *
	 * @param string $id
	 * @param string $name
	 * @param string $type
	 *
	 * @return array<string,string>
	 */
	private function token_def( $id, $name, $type ) {
		return array(
			'tokenId'   => $id,
			'tokenName' => $name,
			'tokenType' => $type,
		);
	}
}
