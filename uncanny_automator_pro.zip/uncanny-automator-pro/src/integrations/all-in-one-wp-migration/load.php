<?php
if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration\All_In_One_Wp_Migration_Integration' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\All_In_One_Wp_Migration\All_In_One_Wp_Migration_Integration();
