<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class EDD_SL_HAS_USER_ACTIVE_LICENSE
 *
 * Loop filter: The user {{has/does not have}} an active license for {{a download}}.
 *
 * @package Uncanny_Automator_Pro
 */
class EDD_SL_HAS_USER_ACTIVE_LICENSE extends Loop_Filter {

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function setup() {

		$this->set_integration( 'EDD_SL' );
		$this->set_meta( 'EDD_SL_HAS_USER_ACTIVE_LICENSE' );

		$this->set_sentence( esc_html_x( 'The user {{has/does not have}} an active license for {{a download}}', 'EDD - Software Licensing', 'uncanny-automator-pro' ) );

		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Download */
				esc_html_x( 'The user {{has/does not have:%1$s}} an active license for {{a download:%2$s}}', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
				'CRITERIA',
				$this->get_meta()
			)
		);

		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_users_with_active_license' ) );
		$this->set_loop_type( 'users' );
	}

	/**
	 * Check if EDD Software Licensing is active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return class_exists( '\EDD_Software_Licensing' );
	}

	/**
	 * @return mixed[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
					'options'               => array(
						array(
							'text'  => esc_html_x( 'has', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
							'value' => 'has',
						),
						array(
							'text'  => esc_html_x( 'does not have', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
							'value' => 'does-not-have',
						),
					),
				),
				array(
					'option_code'           => $this->get_meta(),
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Download', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
					'options'               => $this->get_download_options(),
					'supports_custom_value' => false,
				),
			),
		);
	}

	/**
	 * Build the list of EDD SL-enabled downloads.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_download_options() {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any download', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
			),
		);

		$downloads = get_posts(
			array(
				'post_type'      => 'download',
				'posts_per_page' => 9999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
				'meta_key'       => '_edd_sl_enabled', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => 1, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);

		foreach ( $downloads as $download ) {
			$options[] = array(
				'value' => (string) $download->ID,
				'text'  => $download->post_title,
			);
		}

		return $options;
	}

	/**
	 * @param array{EDD_SL_HAS_USER_ACTIVE_LICENSE:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_users_with_active_license( $fields ) {

		$criteria    = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$download_id = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';

		if ( empty( $criteria ) || '' === $download_id ) {
			return array();
		}

		$licensee_ids = $this->get_licensee_ids( $download_id );

		if ( 'does-not-have' === $criteria ) {
			return $this->get_users_without_license( $licensee_ids );
		}

		return $licensee_ids;
	}

	/**
	 * @param int|string $download_id
	 *
	 * @return int[]
	 */
	private function get_licensee_ids( $download_id ) {

		$args = array(
			'status' => 'active',
			'number' => -1,
		);

		if ( -1 !== intval( $download_id ) ) {
			$args['download_id'] = absint( $download_id );
		}

		$licenses = edd_software_licensing()->licenses_db->get_licenses( $args );

		if ( empty( $licenses ) ) {
			return array();
		}

		$user_ids = array();
		foreach ( $licenses as $license ) {
			$user_id = absint( $license->user_id );
			if ( $user_id ) {
				$user_ids[] = $user_id;
				continue;
			}
			$customer = new \EDD_Customer( $license->customer_id );
			if ( $customer && $customer->user_id ) {
				$user_ids[] = absint( $customer->user_id );
			}
		}

		return array_values( array_unique( array_filter( $user_ids ) ) );
	}

	/**
	 * @param int[] $licensee_ids
	 *
	 * @return int[]
	 */
	private function get_users_without_license( $licensee_ids ) {

		$all_users = new \WP_User_Query(
			array(
				'cache_results' => false,
				'fields'        => 'ID',
			)
		);

		$all_user_ids = $all_users->get_results();

		if ( empty( $licensee_ids ) ) {
			return $all_user_ids;
		}

		return array_values( array_diff( $all_user_ids, $licensee_ids ) );
	}
}
