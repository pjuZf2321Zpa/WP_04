<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class EDD_SL_HAS_USER_ACTIVE_LICENSE_PRICE_OPTION
 *
 * Loop filter: The user {{has/does not have}} an active license for {{a price option}} of {{a download}}.
 *
 * @package Uncanny_Automator_Pro
 */
class EDD_SL_HAS_USER_ACTIVE_LICENSE_PRICE_OPTION extends Loop_Filter {

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function setup() {

		$this->register_hooks();

		$this->set_integration( 'EDD_SL' );
		$this->set_meta( 'EDD_SL_HAS_USER_ACTIVE_LICENSE_PRICE_OPTION' );

		$this->set_sentence( esc_html_x( 'The user {{has/does not have}} an active license for {{a price option}} of {{a download}}', 'EDD - Software Licensing', 'uncanny-automator-pro' ) );

		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Price option, %3$s: Download */
				esc_html_x( 'The user {{has/does not have:%1$s}} an active license for {{a price option:%2$s}} of {{a download:%3$s}}', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
				'CRITERIA',
				'EDDPRICEOPTION',
				'EDDPRODUCT'
			)
		);

		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_users_with_active_license' ) );
		$this->set_loop_type( 'users' );
	}

	/**
	 * Check if EDD Software Licensing is active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return class_exists( '\EDD_Software_Licensing' );
	}

	/**
	 * Wire the AJAX endpoint that loads price options for the selected SL-enabled download.
	 *
	 * Guarded against double-registration because this filter is instantiated both
	 * by the auto-loader and by the integration's load() method.
	 *
	 * @return void
	 */
	protected function register_hooks() {
		if ( false !== has_action( 'wp_ajax_automator_pro_edd_sl_loop_filter_price_options' ) ) {
			return;
		}
		add_action( 'wp_ajax_automator_pro_edd_sl_loop_filter_price_options', array( $this, 'price_options_ajax_handler' ) );
	}

	/**
	 * AJAX handler: returns the price options for the selected EDD SL-enabled download,
	 * preceded by an "Any price option" entry.
	 *
	 * @return void
	 */
	public function price_options_ajax_handler() {

		Automator()->utilities->ajax_auth_check();

		$values      = filter_input( INPUT_POST, 'values', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$download_id = isset( $values['EDDPRODUCT']['value'] ) ? $values['EDDPRODUCT']['value'] : 0;

		wp_send_json(
			array(
				'success' => true,
				'options' => $this->get_price_options( $download_id ),
			)
		);
	}

	/**
	 * Build the price option dropdown list for an SL-enabled download.
	 *
	 * Returns every variable price option for the download. EDD SL stores licensing
	 * at the download level — each variable price can produce a license — so we don't
	 * filter further. If a price option has never produced an active license, the
	 * filter's entity callback simply returns an empty user set.
	 *
	 * @param int|string $download_id
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_price_options( $download_id ) {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any price option', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
			),
		);

		$download_id = absint( $download_id );

		if ( $download_id <= 0 || ! function_exists( 'edd_has_variable_prices' ) ) {
			return $options;
		}

		// Only surface price options for downloads that actually have SL enabled.
		if ( ! get_post_meta( $download_id, '_edd_sl_enabled', true ) ) {
			return $options;
		}

		if ( ! edd_has_variable_prices( $download_id ) ) {
			return $options;
		}

		$variable_prices = edd_get_variable_prices( $download_id );

		if ( empty( $variable_prices ) ) {
			return $options;
		}

		foreach ( $variable_prices as $price_id => $price ) {
			$name = isset( $price['name'] ) ? esc_html( $price['name'] ) : sprintf(
				/* translators: %d is the price option ID */
				esc_html_x( 'Price option %d', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
				$price_id
			);
			$options[] = array(
				'value' => (string) $price_id,
				'text'  => $name,
			);
		}

		return $options;
	}

	/**
	 * @return mixed[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
					'options'               => array(
						array(
							'text'  => esc_html_x( 'has', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
							'value' => 'has',
						),
						array(
							'text'  => esc_html_x( 'does not have', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
							'value' => 'does-not-have',
						),
					),
				),
				array(
					'option_code'           => 'EDDPRODUCT',
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Download', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
					'options'               => $this->get_download_options(),
					'supports_custom_value' => false,
				),
				array(
					'option_code'           => 'EDDPRICEOPTION',
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Price option', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
					'options'               => array(),
					'supports_custom_value' => false,
					'ajax'                  => array(
						'event'         => 'parent_fields_change',
						'endpoint'      => 'automator_pro_edd_sl_loop_filter_price_options',
						'listen_fields' => array( 'EDDPRODUCT' ),
					),
				),
			),
		);
	}

	/**
	 * Build the list of EDD SL-enabled downloads.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_download_options() {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any download', 'EDD - Software Licensing', 'uncanny-automator-pro' ),
			),
		);

		$downloads = get_posts(
			array(
				'post_type'      => 'download',
				'posts_per_page' => 9999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
				'meta_key'       => '_edd_sl_enabled', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => 1, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);

		foreach ( $downloads as $download ) {
			$options[] = array(
				'value' => (string) $download->ID,
				'text'  => $download->post_title,
			);
		}

		return $options;
	}

	/**
	 * @param array{EDDPRODUCT:string,EDDPRICEOPTION:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_users_with_active_license( $fields ) {

		$criteria        = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$download_id     = isset( $fields['EDDPRODUCT'] ) ? $fields['EDDPRODUCT'] : '';
		$price_option_id = isset( $fields['EDDPRICEOPTION'] ) ? $fields['EDDPRICEOPTION'] : '';

		if ( empty( $criteria ) || '' === $download_id || '' === $price_option_id ) {
			return array();
		}

		$licensee_ids = $this->get_licensee_ids( $download_id, $price_option_id );

		if ( 'does-not-have' === $criteria ) {
			return $this->get_users_without_license( $licensee_ids );
		}

		return $licensee_ids;
	}

	/**
	 * @param int|string $download_id
	 * @param int|string $price_option_id
	 *
	 * @return int[]
	 */
	private function get_licensee_ids( $download_id, $price_option_id ) {

		$args = array(
			'status' => 'active',
			'number' => -1,
		);

		if ( -1 !== intval( $download_id ) ) {
			$args['download_id'] = absint( $download_id );
		}

		if ( -1 !== intval( $price_option_id ) ) {
			$args['price_id'] = absint( $price_option_id );
		}

		$licenses = edd_software_licensing()->licenses_db->get_licenses( $args );

		if ( empty( $licenses ) ) {
			return array();
		}

		$user_ids = array();
		foreach ( $licenses as $license ) {
			$user_id = absint( $license->user_id );
			if ( $user_id ) {
				$user_ids[] = $user_id;
				continue;
			}
			$customer = new \EDD_Customer( $license->customer_id );
			if ( $customer && $customer->user_id ) {
				$user_ids[] = absint( $customer->user_id );
			}
		}

		return array_values( array_unique( array_filter( $user_ids ) ) );
	}

	/**
	 * @param int[] $licensee_ids
	 *
	 * @return int[]
	 */
	private function get_users_without_license( $licensee_ids ) {

		$all_users = new \WP_User_Query(
			array(
				'cache_results' => false,
				'fields'        => 'ID',
			)
		);

		$all_user_ids = $all_users->get_results();

		if ( empty( $licensee_ids ) ) {
			return $all_user_ids;
		}

		return array_values( array_diff( $all_user_ids, $licensee_ids ) );
	}
}
