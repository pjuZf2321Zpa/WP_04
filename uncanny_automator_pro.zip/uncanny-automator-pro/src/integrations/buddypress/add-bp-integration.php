<?php

namespace Uncanny_Automator_Pro;

/**
 * Class Add_Bp_Integration
 *
 * @package Uncanny_Automator_Pro
 */
class Add_Bp_Integration {

	/**
	 * Integration code
	 *
	 * @var string
	 */
	public static $integration = 'BP';

	/**
	 * Only load this integration and its triggers and actions if the related plugin is active
	 *
	 * @param $status
	 * @param $code
	 *
	 * @return bool
	 */
	public function plugin_active( $status, $code ) {

		if ( self::$integration === $code ) {
			if ( class_exists( 'BuddyPress' ) ) {
				$status = true;
			} else {
				$status = false;
			}
		}

		return $status;
	}

	/**
	 * Set the directories that the auto loader will run in
	 *
	 * @param $directory
	 *
	 * @return array
	 */
	public function add_integration_directory_func( $directory ) {

		$directory[] = __DIR__ . '/helpers';
		$directory[] = __DIR__ . '/actions';
		$directory[] = __DIR__ . '/triggers';
		$directory[] = __DIR__ . '/tokens';
		$directory[] = __DIR__ . '/loop-filters';

		return $directory;
	}

	/**
	 * Register the integration by pushing it into the global automator object
	 */
	public function add_integration_func() {

		Automator()->register->integration(
			self::$integration,
			array(
				'name'        => 'BuddyPress',
				'icon_16'     => \Uncanny_Automator\Utilities::get_integration_icon( 'integration-buddypress-icon-16.png' ),
				'icon_32'     => \Uncanny_Automator\Utilities::get_integration_icon( 'integration-buddypress-icon-32.png' ),
				'icon_64'     => \Uncanny_Automator\Utilities::get_integration_icon( 'integration-buddypress-icon-64.png' ),
				'logo'        => \Uncanny_Automator\Utilities::get_integration_icon( 'integration-buddypress.png' ),
				'logo_retina' => \Uncanny_Automator\Utilities::get_integration_icon( 'integration-buddypress@2x.png' ),
			)
		);
	}
}
