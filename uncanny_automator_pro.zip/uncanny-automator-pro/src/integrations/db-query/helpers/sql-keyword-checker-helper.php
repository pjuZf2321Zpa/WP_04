<?php
// phpcs:disable Universal.Operators.DisallowStandalonePostIncrementDecrement.PostIncrementFound

namespace Uncanny_Automator_Pro\Integrations\Db_Query\Helpers;

/**
 * Class Sql_Keyword_Checker_Helper
 *
 * Parses an SQL string and determines if dangerous keywords appear
 * as actual SQL commands (not inside literals, comments, or identifiers).
 *
 * @package Uncanny_Automator_Pro\Integrations\Db_Query\Helpers
 */
class Sql_Keyword_Checker_Helper {

	/**
	 * The SQL query being parsed.
	 *
	 * @var string
	 */
	private $query;

	/**
	 * Length of the SQL query.
	 *
	 * @var int
	 */
	private $query_length;

	/**
	 * Current parse position.
	 *
	 * @var int
	 */
	private $position;

	/**
	 * Accumulated SQL command tokens (excluding literals and comments).
	 *
	 * @var string
	 */
	private $sql_tokens;

	/**
	 * Checks if the query contains dangerous keywords outside of literals and comments.
	 *
	 * @param string $query SQL query to inspect.
	 * @param array  $disallowed_keywords Array of keywords to check (case-insensitive).
	 * @return bool True if dangerous keyword is found, false otherwise.
	 */
	public static function contains_dangerous_keyword( $query, $disallowed_keywords ) {

		// Validate inputs.
		if ( empty( $query ) || ! is_string( $query ) ) {
			return false;
		}

		if ( empty( $disallowed_keywords ) || ! is_array( $disallowed_keywords ) ) {
			return false;
		}

		// Validate keywords are alphanumeric/underscore only (security).
		$validated_keywords = array();
		foreach ( $disallowed_keywords as $keyword ) {
			if ( is_string( $keyword ) && preg_match( '/^[a-zA-Z0-9_]+$/', $keyword ) ) {
				$validated_keywords[] = $keyword;
			}
		}

		if ( empty( $validated_keywords ) ) {
			return false;
		}

		// Create instance and perform check.
		$instance = new self();
		return $instance->check_query( $query, $validated_keywords );
	}

	/**
	 * Internal method to check the query for dangerous keywords.
	 *
	 * @param string $query SQL query to inspect.
	 * @param array  $disallowed_keywords Validated array of keywords.
	 * @return bool True if dangerous keyword is found, false otherwise.
	 */
	private function check_query( $query, $disallowed_keywords ) {

		$this->query        = $query;
		$this->query_length = strlen( $query );
		$this->position     = 0;
		$this->sql_tokens   = '';

		// Extract only SQL command tokens (skip literals and comments).
		$this->tokenize();

		// Check if any dangerous keyword appears in SQL tokens.
		return $this->check_sql_tokens( $disallowed_keywords );
	}

	/**
	 * Tokenize the query, extracting only SQL commands (skipping literals and comments).
	 *
	 * @return void
	 */
	private function tokenize() {

		while ( $this->position < $this->query_length ) {
			$char = $this->query[ $this->position ];

			switch ( $char ) {
				case '-':
					if ( '-' === $this->peek( 1 ) ) {
						$this->skip_single_line_comment( 2 );
						continue 2;
					}
					break;

				case '#':
					$this->skip_single_line_comment( 1 );
					continue 2;

				case '/':
					if ( '*' === $this->peek( 1 ) ) {
						$this->skip_multi_line_comment();
						continue 2;
					}
					break;

				case '$':
					if ( $this->skip_dollar_quoted() ) {
						continue 2;
					}
					break;

				case '"':
				case "'":
				case '`':
					$this->skip_quoted_literal( $char );
					// Add a space to separate tokens.
					$this->sql_tokens .= ' ';
					continue 2;

				case '[':
					$this->skip_bracket_identifier();
					// Add a space to separate tokens.
					$this->sql_tokens .= ' ';
					continue 2;
			}

			// Accumulate SQL command characters.
			$this->sql_tokens .= $char;
			$this->position++;
		}
	}

	/**
	 * Check if SQL tokens contain any dangerous keywords using word boundaries.
	 *
	 * @param array $disallowed_keywords Array of keywords to check.
	 * @return bool True if keyword found, false otherwise.
	 */
	private function check_sql_tokens( $disallowed_keywords ) {

		foreach ( $disallowed_keywords as $keyword ) {
			// Use word boundary to match whole words only.
			// Keywords are pre-validated to be alphanumeric/underscore only.
			$pattern = '/\b' . preg_quote( $keyword, '/' ) . '\b/i';
			if ( preg_match( $pattern, $this->sql_tokens ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Peek ahead in the query.
	 *
	 * @param int $offset Number of chars ahead to peek.
	 * @return string|null
	 */
	private function peek( $offset ) {
		$idx = $this->position + $offset;
		return ( $idx < $this->query_length )
			? $this->query[ $idx ]
			: null;
	}

	/**
	 * Skip a single-line comment starting at current position.
	 *
	 * @param int $start_len Length of the comment start sequence.
	 * @return void
	 */
	private function skip_single_line_comment( $start_len ) {
		$this->position += $start_len;
		while ( $this->position < $this->query_length
			&& "\n" !== $this->query[ $this->position ]
		) {
			$this->position++;
		}
		// Add space to separate tokens.
		$this->sql_tokens .= ' ';
	}

	/**
	 * Skip a multi-line comment (/* ... *\/).
	 *
	 * @return void
	 */
	private function skip_multi_line_comment() {
		$this->position += 2;
		while ( $this->position + 1 < $this->query_length ) {
			if (
				'*' === $this->query[ $this->position ]
				&& '/' === $this->peek( 1 )
			) {
				$this->position += 2;
				// Add space to separate tokens.
				$this->sql_tokens .= ' ';
				return;
			}
			$this->position++;
		}
		// Add space even if comment is not closed.
		$this->sql_tokens .= ' ';
	}

	/**
	 * Attempt to skip a dollar-quoted string (PostgreSQL style).
	 *
	 * @return bool True if skipped, false otherwise.
	 */
	private function skip_dollar_quoted() {
		if ( preg_match(
			'/\A\$(?:[A-Za-z0-9_]+)?\$/',
			substr( $this->query, $this->position ),
			$m
		) ) {
			$delimiter       = $m[0];
			$this->position += strlen( $delimiter );
			$end             = strpos( $this->query, $delimiter, $this->position );
			if ( false === $end ) {
				$this->position = $this->query_length;
				// Add space to separate tokens.
				$this->sql_tokens .= ' ';
				return true;
			}
			$this->position = $end + strlen( $delimiter );
			// Add space to separate tokens.
			$this->sql_tokens .= ' ';
			return true;
		}

		return false;
	}

	/**
	 * Skip a quoted literal ('...', "..." or `...`).
	 *
	 * Handles two SQL escape mechanisms:
	 * 1. Doubled quotes: 'It''s' represents the string "It's"
	 * 2. Backslash escapes: 'It\'s' (not supported for backticks)
	 *
	 * @param string $quote The quote character.
	 * @return void
	 */
	private function skip_quoted_literal( $quote ) {
		$this->position++;
		while ( $this->position < $this->query_length ) {
			$c = $this->query[ $this->position ];

			// Found a quote character - check if it's escaped or closing.
			if ( $quote === $c ) {
				// Check for doubled quote escape (e.g., '' or "" or ``).
				// The condition '\\' !== $quote is always true for ', ", ` quotes.
				// It's kept for consistency with the semicolon checker pattern.
				if (
					'\\' !== $quote
					&& $this->peek( 1 ) === $quote
				) {
					// Doubled quote - this is an escaped quote, skip both.
					$this->position += 2;
					continue;
				}
				// Single quote - this is the closing quote.
				$this->position++;
				break;
			}

			// Handle backslash escape (e.g., \' or \").
			// Backticks don't support backslash escapes in standard SQL.
			if (
				'\\' === $c
				&& '`' !== $quote
				&& null !== $this->peek( 1 )
			) {
				// Skip backslash and the next character.
				$this->position += 2;
				continue;
			}

			$this->position++;
		}
	}

	/**
	 * Skip a SQL Server bracketed identifier [ ... ].
	 *
	 * @return void
	 */
	private function skip_bracket_identifier() {
		$this->position++;
		while (
			$this->position < $this->query_length
			&& ']' !== $this->query[ $this->position ]
		) {
			$this->position++;
		}
		if ( $this->position < $this->query_length ) {
			$this->position++;
		}
	}
}
