<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName

namespace Uncanny_Automator_Pro;

/**
 * Class Autonami_Helpers
 *
 * @package Uncanny_Automator
 */
class Autonami_Pro_Helpers extends \Uncanny_Automator\Autonami_Helpers {

	public function __construct() {
		// By default, bwfan_contact_removed_from_lists action passes a single list or an array of lists.
		// We need to create a custom hook that fires for each list separately to make sure our tokens work.
		add_action( 'bwfan_contact_removed_from_lists', array( $this, 'contact_removed_from_lists' ), 10, 2 );

		// By default, bwfan_tags_added_to_contact action passes a single tag or an array of tags.
		// We need to create a custom hook that fires for each tag separately to make sure our tokens work.
		add_action( 'bwfan_tags_removed_from_contact', array( $this, 'tag_removed_from_contact' ), 10, 2 );
	}

	/**
	 * Method contact_removed_from_lists
	 *
	 * @param  mixed $lists
	 * @param  mixed $bwfcrm_contact_object
	 * @return void
	 */
	public function contact_removed_from_lists( $lists, $bwfcrm_contact_object ) {

		if ( ! is_array( $lists ) ) {
			do_action( 'automator_bwfan_contact_removed_from_list', $lists, $bwfcrm_contact_object );
			return;
		}

		foreach ( $lists as $list ) {
			do_action( 'automator_bwfan_contact_removed_from_list', $list, $bwfcrm_contact_object );
		}
	}

	/**
	 * Method tag_removed_from_contact
	 *
	 * @param  mixed $tags
	 * @param  mixed $bwfcrm_contact_object
	 * @return void
	 */
	public function tag_removed_from_contact( $tags, $bwfcrm_contact_object ) {

		if ( ! is_array( $tags ) ) {
			do_action( 'automator_bwfan_tag_removed_from_contact', $tags, $bwfcrm_contact_object );
			return;
		}

		foreach ( $tags as $tag ) {
			do_action( 'automator_bwfan_tag_removed_from_contact', $tag, $bwfcrm_contact_object );
		}
	}

	/**
	 * Method add_tag_to_contact
	 *
	 * @param  mixed $email
	 * @param  mixed $tag_id
	 * @param  mixed $tag_readable
	 * @return void
	 */
	public function remove_tag_from_contact( $email, $tag_id, $tag_readable ) {

		$tags_to_remove = array(
			$tag_id,
		);

		$autonami_contact = new \BWFCRM_Contact( $email );

		$result = $autonami_contact->remove_tags( $tags_to_remove );

		if ( is_wp_error( $result ) ) {
			throw new \Exception( esc_html( $result->get_error_message() ) );
		}

		if ( empty( $result ) ) {
			/* translators: %s - the tag name. */
			throw new \Exception( sprintf( esc_html_x( 'User did not have the %s tag', 'Autonami', 'uncanny-automator' ), esc_html( $tag_readable ) ) );
		}

		$autonami_contact->save();
	}

	/**
	 * add_contact_to_list
	 *
	 * @param  mixed $email
	 * @param  mixed $list_id
	 * @param  mixed $list_readable
	 * @return void
	 */
	public function add_contact_to_list( $email, $list_id, $list_readable ) {

		$lists_to_add = array(
			array(
				'id' => $list_id,
			),
		);

		$autonami_contact = new \BWFCRM_Contact( $email );

		$result = $autonami_contact->add_lists( $lists_to_add );

		if ( is_wp_error( $result ) ) {
			throw new \Exception( esc_html( $result->get_error_message() ) );
		}

		if ( empty( $result ) ) {
			/* translators: %s - the tag name. */
			throw new \Exception( sprintf( esc_html_x( 'User was already a member of %s', 'Autonami', 'uncanny-automator' ), esc_html( $list_readable ) ) );
		}

		$autonami_contact->save();
	}

	/**
	 * add_contact_to_list
	 *
	 * @param  mixed $email
	 * @param  mixed $list_id
	 * @param  mixed $list_readable
	 * @return void
	 */
	public function remove_contact_from_list( $email, $list_id, $list_readable ) {

		$lists_to_rempve = array(
			$list_id,
		);

		$autonami_contact = new \BWFCRM_Contact( $email );

		$result = $autonami_contact->remove_lists( $lists_to_rempve );

		if ( is_wp_error( $result ) ) {
			throw new \Exception( esc_html( $result->get_error_message() ) );
		}

		if ( empty( $result ) ) {
			/* translators: %s - the tag name. */
			throw new \Exception( sprintf( esc_html_x( 'The user was not a member of %s ', 'Autonami', 'uncanny-automator' ), esc_html( $list_readable ) ) );
		}

		$autonami_contact->save();
	}
}
