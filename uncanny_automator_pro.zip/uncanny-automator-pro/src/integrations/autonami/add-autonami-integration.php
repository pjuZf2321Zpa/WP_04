<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Recipe;

/**
 * Class Add_Autonami_Integration
 *
 * @package Uncanny_Automator_Pro
 */
class Add_Autonami_Integration {

	use Recipe\Integrations;

	/**
	 * Add_Integration constructor.
	 */
	public function __construct() {
		$this->setup();
	}

	/**
	 * Integration Set-up.
	 */
	protected function setup() {
		$this->set_integration( 'AUTONAMI' );

		$this->set_plugin_file_path( 'wp-marketing-automations/wp-marketing-automations.php' );
		$this->set_developer_name( 'FunnelKit' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * automator_free_requirement_met
	 *
	 * @return bool
	 */
	public function automator_free_requirement_met() {

		if ( ! defined( 'AUTOMATOR_PLUGIN_VERSION' ) || version_compare( AUTOMATOR_PLUGIN_VERSION, '4.1', '<' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Only load this integration and its triggers and actions if the related plugin is active
	 *
	 * @param $status
	 * @param $plugin
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return class_exists( 'BWFCRM_Contact' ) && $this->automator_free_requirement_met();
	}
}
