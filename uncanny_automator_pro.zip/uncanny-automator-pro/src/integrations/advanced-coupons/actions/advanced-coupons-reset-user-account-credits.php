<?php

namespace Uncanny_Automator_Pro;

use ACFWF\Models\Objects\Store_Credit_Entry;
use ACFWF\Helpers\Plugin_Constants;

/**
 * Class ADVANCED_COUPONS_RESET_USER_ACCOUNT_CREDITS
 *
 * @package Uncanny_Automator_Pro
 */
class ADVANCED_COUPONS_RESET_USER_ACCOUNT_CREDITS extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Define action properties.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ACFWC' );
		$this->set_action_code( 'ACFWC_RESET_CREDIT' );
		$this->set_action_meta( 'RESET_USERS_CREDIT' );
		$this->set_is_pro( true );
		$this->set_requires_user( true );
		/* translators: Action - Advanced Coupons */
		$this->set_sentence( sprintf( esc_html_x( "Reset a user's store credit to zero {{with a note:%1\$s}}", 'Advanced Coupons', 'uncanny-automator-pro' ), $this->get_action_meta() ) );
		$this->set_readable_sentence( esc_html_x( "Reset a user's store credit to zero", 'Advanced Coupons', 'uncanny-automator-pro' ) );
	}

	/**
	 * Define the options for this action.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_action_meta(),
				'label'       => esc_html_x( 'Activity description', 'Advanced Coupons', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
				'tokens'      => true,
				'default_value' => esc_html_x( 'Store credit reset by Uncanny Automator', 'Advanced Coupons', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Define the output tokens for this action.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'PREVIOUS_STORE_CREDIT' => array(
				'name' => esc_html_x( "User's previous store credit", 'Advanced Coupons', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process the action - reset the user's store credit to zero.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$label   = isset( $parsed[ $this->get_action_meta() ] ) ? sanitize_text_field( $parsed[ $this->get_action_meta() ] ) : '';
		$balance = Automator()->helpers->recipe->advanced_coupons->get_current_balance_of_the_customer( $user_id );

		$balance = (float) $balance;
		if ( $balance <= 0 ) {
			$this->add_log_error( esc_html_x( 'The user does not have any store credit to reset', 'Advanced Coupons', 'uncanny-automator-pro' ) );
			return false;
		}

		// Create a decrease entry for the full balance amount.
		$store_credit_entry = new Store_Credit_Entry();
		$store_credit_entry->set_prop( 'user_id', $user_id );
		$store_credit_entry->set_prop( 'type', 'decrease' );
		$store_credit_entry->set_prop( 'amount', $balance );
		$store_credit_entry->set_prop( 'action', 'admin_decrease_auto' );
		$store_credit_entry->set_prop( 'note', ! empty( $label ) ? $label : esc_html_x( 'Store credit reset by Uncanny Automator', 'Advanced Coupons', 'uncanny-automator-pro' ) );
		$store_credit_entry->set_date_prop( 'date', gmdate( 'Y-m-d H:i:s' ), Plugin_Constants::DB_DATE_FORMAT );
		$store_credit_entry->set_prop( 'object_id', $recipe_id );

		$check = $store_credit_entry->save();

		if ( is_wp_error( $check ) ) {
			$this->add_log_error( $check->get_error_message() );
			return false;
		}

		$this->hydrate_tokens(
			array(
				'PREVIOUS_STORE_CREDIT' => $balance,
			)
		);

		return true;
	}
}
