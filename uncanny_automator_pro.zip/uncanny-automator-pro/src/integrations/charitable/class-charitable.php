<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class Charitable_Integration
 *
 * @package Uncanny_Automator_Pro
 */
class Charitable_Integration extends \Uncanny_Automator\Integration {

	/**
	 * Setup Automator integration.
	 *
	 * @return void
	 */
	protected function setup() {

		$this->helpers = new Charitable_Pro_Helpers();
		$this->set_integration( 'CHARITABLE' );
		$this->set_name( 'Charitable' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/charitable-icon.svg' );

		$this->set_plugin_file_path( 'charitable/charitable.php' );
		$this->set_developer_name( 'WP Charitable' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * Load Integration Classes.
	 *
	 * @return void
	 */
	protected function load() {

		// Native Charitable -> Automator hook bridges must register even in
		// targeted mode, so they live in load_shared_hooks(). load() calls it
		// for full-load mode (recipe editor / Automator admin pages).
		$this->load_shared_hooks();

		// Legacy triggers.
		new ANON_CHARITABLE_CAMPAIGN_DONATION_AMOUNT( $this->helpers );
		// Check for Charitable Recurring Add On.
		if ( class_exists( 'Charitable_Recurring' ) ) {
			// Recurring Triggers.
			new ANON_CHARITABLE_RECURRING_CAMPAIGN_DONATION_CANCELLED( $this->helpers );
			new ANON_CHARITABLE_RECURRING_CAMPAIGN_DONATION_MADE( $this->helpers );
			new CHARITABLE_RECURRING_DONATION_STATUS_CHANGED( $this->helpers );
		}

		// Pro triggers.
		new CHARITABLE_DONATION_STATUS_TRANSITION( $this->helpers );
		new CHARITABLE_DONOR_PROFILE_UPDATED( $this->helpers );
		new CHARITABLE_DONOR_CONSENT_CHANGED( $this->helpers );
		new CHARITABLE_CAMPAIGN_SAVED( $this->helpers );
		new CHARITABLE_USER_VERIFIED( $this->helpers );
		new CHARITABLE_STRIPE_EVENT_RECEIVED( $this->helpers );
		new CHARITABLE_PAYPAL_IPN_RECEIVED( $this->helpers );
		new CHARITABLE_DONATION_PROCESSED_BY_GATEWAY( $this->helpers );
		new CHARITABLE_REFUND_INITIATED_BY_GATEWAY( $this->helpers );

		// Legacy actions.
		new ANON_CHARITABLE_ADD_DONATION_LOG_ENTRY( $this->helpers );

		// Pro actions.
		new CHARITABLE_UPDATE_DONOR_ADDRESS( $this->helpers );
		new CHARITABLE_ADD_DONOR_EMAIL( $this->helpers );
		new CHARITABLE_LINK_WP_USER_TO_DONOR( $this->helpers );
		new CHARITABLE_DELETE_DONOR( $this->helpers );
		new CHARITABLE_CANCEL_PENDING_DONATION( $this->helpers );
		new CHARITABLE_UPDATE_DONOR_SOCIAL_LINKS( $this->helpers );
		new CHARITABLE_CREATE_CAMPAIGN( $this->helpers );

	}

	/**
	 * Shared hooks required for Charitable execution.
	 *
	 * These native Charitable -> Automator bridges re-dispatch internal actions
	 * that Pro triggers listen on. They must run whenever the integration is
	 * needed — including targeted (runtime) mode, where the base does NOT call
	 * load(). Registering them in load() alone left them unregistered on live
	 * donations / campaign saves, so those triggers silently never fired.
	 *
	 * @return void
	 */
	protected function load_shared_hooks() {

		// Bridge charitable_process_donation_{gateway} filters into a safe action
		// the donation-processed trigger can listen to without corrupting the
		// filter chain return value.
		$this->register_donation_processed_bridge();

		// Normalize both campaign-save paths into automator_charitable_campaign_saved.
		$this->register_campaign_saved_bridge();
	}

	/**
	 * Check if Plugin is active.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return class_exists( 'Charitable' );
	}

	/**
	 * Register a low-priority filter callback on every active gateway's
	 * charitable_process_donation_{$gateway} filter that forwards the donation
	 * event to the safe action automator_charitable_donation_processed_by_gateway.
	 * The forwarder returns the filter value unchanged, so Charitable's own
	 * gateway-processing return shape (true|false|array) is preserved.
	 *
	 * @return void
	 */
	private function register_donation_processed_bridge() {

		$gateways = array( 'stripe', 'paypal', 'offline', 'square_core', 'square', 'paypal_commerce' );

		foreach ( $gateways as $gateway ) {
			add_filter( 'charitable_process_donation_' . $gateway, array( $this, 'forward_donation_processed_to_gateway' ), 99, 3 );
		}
	}

	/**
	 * Listen on both campaign-save paths and normalize to one internal action.
	 *
	 * - save_post_campaign     : classic WP admin editor + campaign builder (via wp_update_post/wp_insert_post)
	 * - charitable_campaign_processor_save_core : campaign builder (fires from Charitable_Campaign_Processor::save_core)
	 *
	 * Both paths fire for builder saves, so dispatch_campaign_saved() deduplicates per request.
	 *
	 * @return void
	 */
	private function register_campaign_saved_bridge() {
		add_action( 'save_post_campaign', array( $this, 'on_campaign_save_post' ), 10, 3 );
		add_action( 'charitable_campaign_processor_save_core', array( $this, 'on_campaign_processor_save_core' ), 10, 4 );
	}

	/**
	 * Normalizer for save_post_campaign.
	 *
	 * @param int     $campaign_id
	 * @param WP_Post $post
	 * @param bool    $update
	 *
	 * @return void
	 */
	public function on_campaign_save_post( $campaign_id, $post, $update ) {
		if ( wp_is_post_autosave( $campaign_id ) || wp_is_post_revision( $campaign_id ) ) {
			return;
		}
		$this->dispatch_campaign_saved( (int) $campaign_id, $update ? 'update' : 'insert' );
	}

	/**
	 * Normalizer for charitable_campaign_processor_save_core.
	 *
	 * @param string $action      'insert' or 'update'.
	 * @param int    $campaign_id
	 * @param array  $data
	 * @param object $processor
	 *
	 * @return void
	 */
	public function on_campaign_processor_save_core( $action, $campaign_id, $data, $processor ) {
		if ( empty( $campaign_id ) || is_wp_error( $campaign_id ) ) {
			return;
		}
		$this->dispatch_campaign_saved( (int) $campaign_id, (string) $action );
	}

	/**
	 * Fire automator_charitable_campaign_saved exactly once per campaign+action combo per request.
	 *
	 * @param int    $campaign_id
	 * @param string $action 'insert' or 'update'.
	 *
	 * @return void
	 */
	private function dispatch_campaign_saved( int $campaign_id, string $action ) {
		static $fired = array();
		$key = $campaign_id . '_' . $action;
		if ( isset( $fired[ $key ] ) ) {
			return;
		}
		$fired[ $key ] = true;
		do_action( 'automator_charitable_campaign_saved', $campaign_id, $action );
	}

	/**
	 * Filter pass-through that fires our safe action.
	 *
	 * @param mixed                                $value       Filter value from charitable_process_donation_{gateway}.
	 * @param int                                  $donation_id Donation ID being processed.
	 * @param \Charitable_Donation_Processor|null  $processor   Processor instance, or null on early bail.
	 *
	 * @return mixed The original filter value, unchanged.
	 */
	public function forward_donation_processed_to_gateway( $value, $donation_id = 0, $processor = null ) {

		$hook    = current_filter();
		$prefix  = 'charitable_process_donation_';
		$gateway = 0 === strpos( (string) $hook, $prefix ) ? substr( $hook, strlen( $prefix ) ) : '';

		if ( ! empty( $donation_id ) && '' !== $gateway ) {
			do_action( 'automator_charitable_donation_processed_by_gateway', (int) $donation_id, $gateway, $processor );
		}

		return $value;
	}

}
