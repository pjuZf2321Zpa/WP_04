<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_UPDATE_DONOR_SOCIAL_LINKS
 *
 * Sets the donor's Twitter, Facebook, and website URL via
 * Charitable_Donor::update_social_links(). Only fields the user fills in are
 * written; existing networks for that donor are preserved so empty inputs
 * don't silently erase other links.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_UPDATE_DONOR_SOCIAL_LINKS extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_UPDATE_DONOR_SOCIAL_LINKS' );
		$this->set_action_meta( 'DONOR_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Donor */
				esc_html_x( "Update {{a donor's:%1\$s}} social links", 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( "Update {{a donor's}} social links", 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Donor', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'donors_strict' ),
			),
			array(
				'option_code' => 'DONOR_TWITTER',
				'label'       => esc_html_x( 'Twitter URL', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'url',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_FACEBOOK',
				'label'       => esc_html_x( 'Facebook URL', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'url',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_WEBSITE',
				'label'       => esc_html_x( 'Website URL', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'url',
				'required'    => false,
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! class_exists( 'Charitable_Donor' ) ) {
			$this->add_log_error( 'Charitable is not active.' );
			return false;
		}

		$donor_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		if ( empty( $donor_id ) ) {
			$this->add_log_error( 'Donor is required.' );
			return false;
		}

		$donor = new \Charitable_Donor( $donor_id );
		if ( ! $donor->donor_id ) {
			$this->add_log_error( sprintf( 'Donor %d not found.', $donor_id ) );
			return false;
		}

		if ( ! method_exists( $donor, 'update_social_links' ) ) {
			$this->add_log_error( 'Charitable_Donor::update_social_links() is not available. Charitable Pro may be required.' );
			return false;
		}

		$incoming = array(
			'twitter'  => esc_url_raw( $parsed['DONOR_TWITTER'] ?? '' ),
			'facebook' => esc_url_raw( $parsed['DONOR_FACEBOOK'] ?? '' ),
			'url'      => esc_url_raw( $parsed['DONOR_WEBSITE'] ?? '' ),
		);

		$incoming = array_filter(
			$incoming,
			function ( $value ) {
				return '' !== $value;
			}
		);

		if ( empty( $incoming ) ) {
			$this->add_log_error( 'At least one social link is required.' );
			return false;
		}

		// Merge over existing networks so unselected fields don't blank out other links.
		// Admin form stores each network as an array of URLs (see Charitable_Donors::ajax_donor_social_update),
		// so we match that shape for compatibility with the donor profile UI.
		$social_links = method_exists( $donor, 'get_social_links' ) ? (array) $donor->get_social_links() : array();
		foreach ( $incoming as $network => $link ) {
			$social_links[ $network ] = array( $link );
		}

		$result = $donor->update_social_links( $social_links );
		if ( false === $result || is_wp_error( $result ) ) {
			$this->add_log_error( is_wp_error( $result ) ? $result->get_error_message() : 'Failed to update donor social links.' );
			return false;
		}

		return true;
	}
}
