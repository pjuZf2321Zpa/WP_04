<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class ANON_CHARITABLE_ADD_DONATION_LOG_ENTRY
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class ANON_CHARITABLE_ADD_DONATION_LOG_ENTRY extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Entry Content Meta Key.
	 *
	 * @var string
	 */
	const ENTRY_META = 'CHARITABLE_DONATION_LOG_ENTRY_CONTENT';

	/**
	 * Register action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		// Define the Actions's info
		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_ADD_DONATION_LOG_ENTRY' );
		$this->set_action_meta( 'CHARITABLE_DONATION_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );

		// Active State Sentence.
		$this->set_sentence(
			sprintf(
				esc_attr_x(
					'Add an entry in {{a donation:%1$s}} log',
					'Charitable',
					'uncanny-automator-pro'
				),
				$this->get_action_meta()
			)
		);

		// Non Active State Sentence.
		$this->set_readable_sentence(
			esc_attr_x(
				'Add an entry in {{a donation}} log',
				'Charitable',
				'uncanny-automator-pro'
			)
		);

	}

	/**
	 * Define the Action's options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Donation ID', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'donations_strict' ),
			),
			array(
				'option_code' => self::ENTRY_META,
				'label'       => esc_html_x( 'Entry', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'textarea',
				'required'    => true,
				'placeholder' => esc_html_x( 'Entry content', 'Charitable', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Process the action.
	 *
	 * @param int $user_id
	 * @param array $action_data
	 * @param int $recipe_id
	 * @param array $args
	 * @param mixed $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$donation_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		$entry       = wp_filter_post_kses( stripslashes( $parsed[ self::ENTRY_META ] ?? '' ) );

		if ( empty( $donation_id ) ) {
			$this->add_log_error( esc_attr_x( 'Invalid donation ID', 'Charitable', 'uncanny-automator-pro' ) );
			return false;
		}

		if ( '' === $entry ) {
			$this->add_log_error( esc_attr_x( 'No entry content provided', 'Charitable', 'uncanny-automator-pro' ) );
			return false;
		}

		$donation = $this->item_helpers->get_donation( $donation_id );
		if ( ! $donation ) {
			// Check if it's a recurring donation.
			$donation = $this->item_helpers->get_recurring_donation( $donation_id );
		}

		if ( ! $donation ) {
			$this->add_log_error( esc_attr_x( 'Donation not found', 'Charitable', 'uncanny-automator-pro' ) );
			return false;
		}

		if ( ! method_exists( $donation, 'update_donation_log' ) ) {
			$this->add_log_error( 'Charitable_Donation::update_donation_log() is not available.' );
			return false;
		}

		$result = $donation->update_donation_log( $entry );

		// On success returns the meta_id for the first log entry or true; false on failure.
		if ( empty( $result ) ) {
			$this->add_log_error( esc_attr_x( 'Failed to add entry', 'Charitable', 'uncanny-automator-pro' ) );
			return false;
		}

		return true;
	}

}
