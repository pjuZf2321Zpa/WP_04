<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_UPDATE_DONOR_ADDRESS
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_UPDATE_DONOR_ADDRESS extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_UPDATE_DONOR_ADDRESS' );
		$this->set_action_meta( 'DONOR_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Donor ID */
				esc_html_x( "Update {{a donor's:%1\$s}} primary address", 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( "Update {{a donor's}} primary address", 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Donor', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'donors_strict' ),
			),
			array(
				'option_code' => 'DONOR_ADDRESS_1',
				'label'       => esc_html_x( 'Address line 1', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_ADDRESS_2',
				'label'       => esc_html_x( 'Address line 2', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_CITY',
				'label'       => esc_html_x( 'City', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_STATE',
				'label'       => esc_html_x( 'State / Province', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_POSTCODE',
				'label'       => esc_html_x( 'Postcode / ZIP', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code' => 'DONOR_COUNTRY',
				'label'       => esc_html_x( 'Country (2-letter code)', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! class_exists( 'Charitable_Donor' ) ) {
			$this->add_log_error( 'Charitable is not active.' );
			return false;
		}

		$donor_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		if ( empty( $donor_id ) ) {
			$this->add_log_error( 'Donor ID is required.' );
			return false;
		}

		$donor = new \Charitable_Donor( $donor_id );
		if ( ! $donor->donor_id ) {
			$this->add_log_error( sprintf( 'Donor %d not found.', $donor_id ) );
			return false;
		}

		if ( ! method_exists( $donor, 'update_primary_address' ) ) {
			$this->add_log_error( 'Charitable_Donor::update_primary_address() is not available. Charitable Pro may be required.' );
			return false;
		}

		$address = array();
		$map     = array(
			'DONOR_ADDRESS_1' => 'address',
			'DONOR_ADDRESS_2' => 'address_2',
			'DONOR_CITY'      => 'city',
			'DONOR_STATE'     => 'state',
			'DONOR_POSTCODE'  => 'postcode',
			'DONOR_COUNTRY'   => 'country',
		);

		foreach ( $map as $code => $key ) {
			$value = sanitize_text_field( $parsed[ $code ] ?? '' );
			if ( '' !== $value ) {
				$address[ $key ] = $value;
			}
		}

		if ( empty( $address ) ) {
			$this->add_log_error( 'At least one address field is required.' );
			return false;
		}

		$result = $donor->update_primary_address( $address );
		if ( false === $result || is_wp_error( $result ) ) {
			$this->add_log_error( is_wp_error( $result ) ? $result->get_error_message() : 'Failed to update donor address.' );
			return false;
		}

		return true;
	}
}
