<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_LINK_WP_USER_TO_DONOR
 *
 * Associates a WordPress user account with an existing donor record.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_LINK_WP_USER_TO_DONOR extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_LINK_WP_USER_TO_DONOR' );
		$this->set_action_meta( 'DONOR_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Donor 2: WP user */
				esc_html_x( "Link {{a donor:%1\$s}} to {{a WP user:%2\$s}}", 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'DONOR_USER_ID:' . $this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( "Link {{a donor}} to {{a WP user}}", 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {

		$helpers = $this->item_helpers;

		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Donor', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'remote_data'           => $helpers->remote_data_load_config( 'donors_strict' ),
			),
			array(
				'option_code'           => 'DONOR_USER_ID',
				'label'                 => esc_html_x( 'WP user', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'remote_data'           => $helpers->remote_data_load_config( 'wp_users_strict' ),
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! class_exists( 'Charitable_Donor' ) ) {
			$this->add_log_error( 'Charitable is not active.' );
			return false;
		}

		$donor_id    = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		$wp_user_id  = absint( $parsed['DONOR_USER_ID'] ?? 0 );

		if ( empty( $donor_id ) ) {
			$this->add_log_error( 'Donor ID is required.' );
			return false;
		}

		if ( empty( $wp_user_id ) ) {
			$this->add_log_error( 'WP user ID is required.' );
			return false;
		}

		if ( ! get_userdata( $wp_user_id ) ) {
			$this->add_log_error( sprintf( 'WP user %d not found.', $wp_user_id ) );
			return false;
		}

		$donor = new \Charitable_Donor( $donor_id );
		if ( ! $donor->donor_id ) {
			$this->add_log_error( sprintf( 'Donor %d not found.', $donor_id ) );
			return false;
		}

		if ( ! method_exists( $donor, 'set_user_id' ) ) {
			$this->add_log_error( 'Charitable_Donor::set_user_id() is not available.' );
			return false;
		}

		$result = $donor->set_user_id( $wp_user_id );
		if ( false === $result || is_wp_error( $result ) ) {
			$this->add_log_error( is_wp_error( $result ) ? $result->get_error_message() : 'Failed to link WP user to donor.' );
			return false;
		}

		return true;
	}
}
