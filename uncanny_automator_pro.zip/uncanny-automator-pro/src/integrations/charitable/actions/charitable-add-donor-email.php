<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_ADD_DONOR_EMAIL
 *
 * Adds a secondary email address to a donor (e.g. work email).
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_ADD_DONOR_EMAIL extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_ADD_DONOR_EMAIL' );
		$this->set_action_meta( 'DONOR_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Donor ID 2: Email */
				esc_html_x( 'Add {{an email:%2$s}} to {{a donor:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'DONOR_SECONDARY_EMAIL:' . $this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'Add {{an email}} to {{a donor}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Donor', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'donors_strict' ),
			),
			array(
				'option_code' => 'DONOR_SECONDARY_EMAIL',
				'label'       => esc_html_x( 'Email', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'email',
				'required'    => true,
			),
			array(
				'option_code'           => 'DONOR_EMAIL_TYPE',
				'label'                 => esc_html_x( 'Email type', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => false,
				'supports_custom_value' => true,
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'donor_email_types_strict' ),
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! class_exists( 'Charitable_Donor' ) ) {
			$this->add_log_error( 'Charitable is not active.' );
			return false;
		}

		$donor_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		$email    = sanitize_email( $parsed['DONOR_SECONDARY_EMAIL'] ?? '' );
		$type     = sanitize_text_field( $parsed['DONOR_EMAIL_TYPE'] ?? '' );

		if ( empty( $donor_id ) ) {
			$this->add_log_error( 'Donor ID is required.' );
			return false;
		}

		if ( empty( $email ) || ! is_email( $email ) ) {
			$this->add_log_error( 'A valid email is required.' );
			return false;
		}

		$donor = new \Charitable_Donor( $donor_id );
		if ( ! $donor->donor_id ) {
			$this->add_log_error( sprintf( 'Donor %d not found.', $donor_id ) );
			return false;
		}

		if ( ! method_exists( $donor, 'add_email' ) ) {
			$this->add_log_error( 'Charitable_Donor::add_email() is not available. Charitable Pro may be required.' );
			return false;
		}

		$result = $donor->add_email(
			array(
				'donor_email'      => $email,
				'donor_email_type' => $type,
			),
			$donor_id,
			$type
		);
		if ( false === $result || is_wp_error( $result ) ) {
			$this->add_log_error( is_wp_error( $result ) ? $result->get_error_message() : 'Failed to add donor email.' );
			return false;
		}

		return true;
	}
}
