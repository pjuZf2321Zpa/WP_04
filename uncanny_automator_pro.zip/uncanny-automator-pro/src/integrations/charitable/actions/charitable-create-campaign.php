<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_CREATE_CAMPAIGN
 *
 * Creates a Charitable campaign via charitable_create_campaign() (which delegates
 * to Charitable_Campaign_Processor). The processor accepts core post fields
 * (title, content, status) plus campaign meta (goal, end_date, suggested
 * donations, custom donations toggle, minimum donation amount, description).
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_CREATE_CAMPAIGN extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_CREATE_CAMPAIGN' );
		$this->set_action_meta( 'CAMPAIGN_TITLE' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Campaign title */
				esc_html_x( 'Create {{a campaign:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'Create {{a campaign}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Define action tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'CAMPAIGN_ID'    => array(
				'name' => esc_html_x( 'Campaign ID', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'CAMPAIGN_LINK'  => array(
				'name' => esc_html_x( 'Campaign link', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'url',
			),
			'CAMPAIGN_TITLE' => array(
				'name' => esc_html_x( 'Campaign title', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_action_meta(),
				'label'       => esc_html_x( 'Title', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => true,
			),
			array(
				'option_code' => 'CAMPAIGN_DESCRIPTION',
				'label'       => esc_html_x( 'Short description', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'textarea',
				'required'    => false,
			),
			array(
				'option_code' => 'CAMPAIGN_CONTENT',
				'label'       => esc_html_x( 'Content', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'textarea',
				'required'    => false,
			),
			array(
				'option_code' => 'CAMPAIGN_GOAL',
				'label'       => esc_html_x( 'Goal', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'float',
				'required'    => false,
				'description' => esc_html_x( 'Leave empty for no goal.', 'Charitable', 'uncanny-automator-pro' ),
			),
			array(
				'option_code' => 'CAMPAIGN_END_DATE',
				'label'       => esc_html_x( 'End date', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'date',
				'required'    => false,
				'description' => esc_html_x( 'Format: YYYY-MM-DD. Leave empty for no end date.', 'Charitable', 'uncanny-automator-pro' ),
			),
			array(
				'option_code' => 'CAMPAIGN_SUGGESTED_DONATIONS',
				'label'       => esc_html_x( 'Suggested donation amounts', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
				'description' => esc_html_x( 'Comma-separated amounts, e.g. 10, 25, 50, 100.', 'Charitable', 'uncanny-automator-pro' ),
			),
			array(
				'option_code' => 'CAMPAIGN_ALLOW_CUSTOM_DONATIONS',
				'label'       => esc_html_x( 'Allow custom donation amounts', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'checkbox',
				'required'    => false,
			),
			array(
				'option_code' => 'CAMPAIGN_MINIMUM_DONATION',
				'label'       => esc_html_x( 'Minimum donation amount', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'float',
				'required'    => false,
			),
			array(
				'option_code'           => 'CAMPAIGN_CREATOR',
				'label'                 => esc_html_x( 'Campaign creator', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => false,
				'description'           => esc_html_x( 'Optional. Defaults to the recipe user.', 'Charitable', 'uncanny-automator-pro' ),
				'supports_custom_value' => true,
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'wp_users_strict' ),
			),
			array(
				'option_code' => 'CAMPAIGN_STATUS',
				'label'       => esc_html_x( 'Status', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => false,
				'options'     => array(
					array(
						'text'  => esc_html_x( 'Published', 'Charitable', 'uncanny-automator-pro' ),
						'value' => 'publish',
					),
					array(
						'text'  => esc_html_x( 'Draft', 'Charitable', 'uncanny-automator-pro' ),
						'value' => 'draft',
					),
					array(
						'text'  => esc_html_x( 'Pending review', 'Charitable', 'uncanny-automator-pro' ),
						'value' => 'pending',
					),
					array(
						'text'  => esc_html_x( 'Private', 'Charitable', 'uncanny-automator-pro' ),
						'value' => 'private',
					),
				),
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! function_exists( 'charitable_create_campaign' ) ) {
			$this->add_log_error( 'Charitable is not active.' );
			return false;
		}

		$title = sanitize_text_field( $parsed[ $this->get_action_meta() ] ?? '' );
		if ( '' === $title ) {
			$this->add_log_error( 'Campaign title is required.' );
			return false;
		}

		$creator_id = absint( $parsed['CAMPAIGN_CREATOR'] ?? 0 );
		if ( empty( $creator_id ) ) {
			$creator_id = (int) $user_id;
		}

		$campaign_args = array(
			'title'   => $title,
			'creator' => $creator_id,
			'status'  => sanitize_text_field( $parsed['CAMPAIGN_STATUS'] ?? 'publish' ),
		);

		$content = $parsed['CAMPAIGN_CONTENT'] ?? '';
		if ( '' !== $content ) {
			$campaign_args['content'] = wp_kses_post( $content );
		}

		$description = $parsed['CAMPAIGN_DESCRIPTION'] ?? '';
		if ( '' !== $description ) {
			$campaign_args['description'] = sanitize_textarea_field( $description );
		}

		$goal = $parsed['CAMPAIGN_GOAL'] ?? '';
		if ( '' !== $goal ) {
			$campaign_args['goal'] = (string) $goal;
		}

		$end_date = sanitize_text_field( $parsed['CAMPAIGN_END_DATE'] ?? '' );
		if ( '' !== $end_date ) {
			$campaign_args['end_date'] = $end_date;
		}

		$suggested_raw = sanitize_text_field( $parsed['CAMPAIGN_SUGGESTED_DONATIONS'] ?? '' );
		if ( '' !== $suggested_raw ) {
			$suggested = array();
			foreach ( explode( ',', $suggested_raw ) as $entry ) {
				$entry = trim( $entry );
				if ( '' !== $entry && is_numeric( $entry ) ) {
					$suggested[] = array( 'amount' => $entry );
				}
			}
			if ( ! empty( $suggested ) ) {
				$campaign_args['suggested_donations'] = $suggested;
			}
		}

		if ( array_key_exists( 'CAMPAIGN_ALLOW_CUSTOM_DONATIONS', $parsed ) && '' !== $parsed['CAMPAIGN_ALLOW_CUSTOM_DONATIONS'] ) {
			$campaign_args['allow_custom_donations'] = filter_var( $parsed['CAMPAIGN_ALLOW_CUSTOM_DONATIONS'], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0;
		}

		$minimum = $parsed['CAMPAIGN_MINIMUM_DONATION'] ?? '';
		if ( '' !== $minimum ) {
			$campaign_args['minimum_donation_amount'] = (string) $minimum;
		}

		$campaign_id = charitable_create_campaign( $campaign_args );

		if ( empty( $campaign_id ) || is_wp_error( $campaign_id ) ) {
			$this->add_log_error( is_wp_error( $campaign_id ) ? $campaign_id->get_error_message() : 'Failed to create campaign.' );
			return false;
		}

		$this->hydrate_tokens(
			array(
				'CAMPAIGN_ID'    => $campaign_id,
				'CAMPAIGN_LINK'  => get_permalink( $campaign_id ),
				'CAMPAIGN_TITLE' => $title,
			)
		);

		return true;
	}
}
