<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_DELETE_DONOR
 *
 * Deletes a Charitable donor record. Mirrors Charitable Pro's admin "Delete donor"
 * flow (Charitable_Donors::delete_donor) which also cascades into donormeta,
 * donor logs, custom fields, donations, and donor term relationships.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_DELETE_DONOR extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_DELETE_DONOR' );
		$this->set_action_meta( 'DONOR_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Donor */
				esc_html_x( 'Delete {{a donor:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'Delete {{a donor}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Define action tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'DONOR_ID'    => array(
				'name' => esc_html_x( 'Donor ID', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'DONOR_EMAIL' => array(
				'name' => esc_html_x( 'Donor email', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'email',
			),
			'DONOR_NAME'  => array(
				'name' => esc_html_x( 'Donor name', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Donor', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'description'           => esc_html_x( 'Deleting a donor also removes their donations, custom fields, logs, and tag relationships. This cannot be undone.', 'Charitable', 'uncanny-automator-pro' ),
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'donors_strict' ),
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! class_exists( 'Charitable_Donor' ) ) {
			$this->add_log_error( 'Charitable is not active.' );
			return false;
		}

		$donor_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		if ( empty( $donor_id ) ) {
			$this->add_log_error( 'Donor is required.' );
			return false;
		}

		$donor = new \Charitable_Donor( $donor_id );
		if ( ! $donor->donor_id ) {
			$this->add_log_error( sprintf( 'Donor %d not found.', $donor_id ) );
			return false;
		}

		// Snapshot identifiers before deletion so the tokens still resolve downstream.
		$donor_email = (string) $donor->email;
		$donor_name  = trim( $donor->first_name . ' ' . $donor->last_name );

		// Prefer Charitable Pro's cascading admin helper. It also wipes donormeta,
		// donor logs, custom fields, donations, and term relationships, matching the
		// admin "Delete donor" button. Fall back to the donor object's own delete()
		// (donors table only) when the admin helper isn't loaded.
		if ( class_exists( '\Charitable_Donors' ) && method_exists( '\Charitable_Donors', 'get_instance' ) ) {
			$result = \Charitable_Donors::get_instance()->delete_donor( $donor_id );
		} else {
			$result = $donor->delete( $donor_id );
		}

		if ( ! $result ) {
			$this->add_log_error( sprintf( 'Failed to delete donor %d.', $donor_id ) );
			return false;
		}

		$this->hydrate_tokens(
			array(
				'DONOR_ID'    => $donor_id,
				'DONOR_EMAIL' => $donor_email,
				'DONOR_NAME'  => $donor_name,
			)
		);

		return true;
	}
}
