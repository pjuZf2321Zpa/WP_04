<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_CANCEL_PENDING_DONATION
 *
 * Cancels a Charitable donation that is currently in the "pending" status —
 * the only state Charitable itself allows a donation to be cancelled from
 * (see charitable_cancel_donation() in includes/donations/charitable-donation-functions.php).
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_CANCEL_PENDING_DONATION extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CHARITABLE' );
		$this->set_action_code( 'CHARITABLE_CANCEL_PENDING_DONATION' );
		$this->set_action_meta( 'CHARITABLE_DONATION_ID' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Donation */
				esc_html_x( 'Cancel {{a pending donation:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'Cancel {{a pending donation}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Define action tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'DONATION_ID'    => array(
				'name' => esc_html_x( 'Donation ID', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'DONATION_TITLE' => array(
				'name' => esc_html_x( 'Donation title', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'DONOR_EMAIL'    => array(
				'name' => esc_html_x( 'Donor email', 'Charitable', 'uncanny-automator-pro' ),
				'type' => 'email',
			),
		);
	}

	/**
	 * Action options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_action_meta(),
				'label'                 => esc_html_x( 'Pending donation', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'supports_custom_value' => true,
				'description'           => esc_html_x( 'Only donations currently in the Pending status can be cancelled.', 'Charitable', 'uncanny-automator-pro' ),
				'remote_data'           => $this->item_helpers->remote_data_load_config( 'pending_donations_strict' ),
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$donation_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );

		if ( empty( $donation_id ) ) {
			$this->add_log_error( 'Donation is required.' );
			return false;
		}

		$donation = $this->item_helpers->get_donation( $donation_id );
		if ( ! $donation ) {
			$this->add_log_error( sprintf( 'Donation %d not found.', $donation_id ) );
			return false;
		}

		if ( 'charitable-pending' !== $donation->get_status() ) {
			$this->add_log_error( sprintf( 'Donation %d is not pending. Current status: %s.', $donation_id, $donation->get_status() ) );
			return false;
		}

		$result = $donation->update_status( 'charitable-cancelled' );
		if ( empty( $result ) ) {
			$this->add_log_error( 'Failed to cancel the donation.' );
			return false;
		}

		$donor_email = '';
		$donor_data  = $donation->get_donor_data();
		if ( ! empty( $donor_data['email'] ) ) {
			$donor_email = $donor_data['email'];
		}

		$this->hydrate_tokens(
			array(
				'DONATION_ID'    => $donation_id,
				'DONATION_TITLE' => get_the_title( $donation_id ),
				'DONOR_EMAIL'    => $donor_email,
			)
		);

		return true;
	}
}
