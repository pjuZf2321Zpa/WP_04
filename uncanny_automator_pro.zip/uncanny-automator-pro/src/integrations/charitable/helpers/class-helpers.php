<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;
use Uncanny_Automator\Integrations\Charitable\Charitable_Helpers;

/**
 * Class Charitable_Pro_Helpers
 *
 * Composes Free's Charitable_Helpers rather than inheriting it. Pro registers
 * its helper LATER than Free, so Pro's instance wins the
 * automator_remote_data_instance_charitable filter — Pro must therefore
 * delegate Free segments explicitly so they don't disappear.
 *
 * @package Uncanny_Automator_Pro
 * @property Charitable_Helpers $base
 */
class Charitable_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->base = new Charitable_Helpers();
	}

	// ============================================================
	// Free helper delegators (composition).
	// ============================================================

	/**
	 * Campaign select field, built on this Pro helper so its remote_data routing
	 * id is set (same pattern as recurring_campaign_select()). Delegating to
	 * $this->base->campaign_select() emits an empty id — the composed Free helper
	 * is never registered — producing /remote-data//campaigns (rest_no_route 404).
	 *
	 * @return array
	 */
	public function campaign_select() {
		return array(
			'input_type'  => 'select',
			'option_code' => 'CHARITABLE_CAMPAIGN',
			'label'       => esc_html_x( 'Campaign', 'Charitable', 'uncanny-automator-pro' ),
			'required'    => true,
			'remote_data' => $this->remote_data_load_config( 'campaigns' ),
		);
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function donation_amount_conditions_select() {
		return $this->base->donation_amount_conditions_select();
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function donation_amount_input() {
		return $this->base->donation_amount_input();
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function get_campaign_tokens_config() {
		return $this->base->get_campaign_tokens_config();
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @param mixed $donation Maybe Charitable_Donation object or Donation Post ID.
	 *
	 * @return mixed Charitable_Campaign object or false.
	 */
	public function get_donation_campaign( $donation ) {
		return $this->base->get_donation_campaign( $donation );
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function get_donation_tokens_config() {
		return $this->base->get_donation_tokens_config();
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @param int $donation_id Donation Post ID.
	 *
	 * @return mixed Charitable_Donation object or false.
	 */
	public function get_donation( $donation_id ) {
		return $this->base->get_donation( $donation_id );
	}

	/**
	 * Delegate to base Free helper. Used internally by
	 * get_recurring_donation_campaign().
	 *
	 * @param int $campaign_id Campaign Post ID.
	 *
	 * @return mixed Charitable_Campaign object or false.
	 */
	public function get_campaign( $campaign_id ) {
		return $this->base->get_campaign( $campaign_id );
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function get_donor_tokens_config() {
		return $this->base->get_donor_tokens_config();
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @param int $campaign_id
	 *
	 * @return array
	 */
	public function hydrate_campaign_tokens( $campaign_id ) {
		return $this->base->hydrate_campaign_tokens( $campaign_id );
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @param int $donation_id Donation ID.
	 *
	 * @return array
	 */
	public function hydrate_donation_tokens( $donation_id ) {
		return $this->base->hydrate_donation_tokens( $donation_id );
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @param int $donor_id
	 *
	 * @return array
	 */
	public function hydrate_donor_tokens( $donor_id ) {
		return $this->base->hydrate_donor_tokens( $donor_id );
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @param int $donation_id Donation Post ID.
	 *
	 * @return mixed Charitable_Donation object or false.
	 */
	public function validate_approved_donation( $donation_id ) {
		return $this->base->validate_approved_donation( $donation_id );
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function get_active_gateway_options() {
		return $this->base->get_active_gateway_options();
	}

	/**
	 * Delegate to base Free helper.
	 *
	 * @return array
	 */
	public function get_donation_status_options() {
		return $this->base->get_donation_status_options();
	}

	// ============================================================
	// Free Remote_Data segment delegators.
	// ============================================================

	/**
	 * Delegate Free segment: campaigns.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_campaigns( $request ): array {
		return $this->remote_data_success( $this->base->get_campaign_options() );
	}

	/**
	 * Delegate Free segment: campaigns_strict.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_campaigns_strict( $request ): array {
		return $this->remote_data_success(
			array_values(
				array_filter(
					$this->base->get_campaign_options(),
					static function ( $opt ) {
						return -1 !== (int) $opt['value'];
					}
				)
			)
		);
	}

	/**
	 * Delegate Free segment: donors_strict.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_donors_strict( $request ): array {
		return $this->remote_data_success( $this->base->get_donor_options() );
	}

	/**
	 * Delegate Free segment: donor_prefixes_strict.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_donor_prefixes_strict( $request ): array {
		return $this->remote_data_success( $this->base->get_donor_prefix_options() );
	}

	/**
	 * Delegate Free segment: donor_suffixes_strict.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_donor_suffixes_strict( $request ): array {
		return $this->remote_data_success( $this->base->get_donor_suffix_options() );
	}

	/**
	 * Delegate Free segment: donor_languages_strict.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_donor_languages_strict( $request ): array {
		return $this->remote_data_success( $this->base->get_donor_language_options() );
	}

	/**
	 * Delegate Free segment: donor_tags_strict.
	 *
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	protected function remote_data_get_donor_tags_strict( $request ): array {
		return $this->remote_data_success( $this->base->get_donor_tag_options() );
	}

	/**
	 * Get Recurring Campaign Select.
	 *
	 * @param string $code
	 *
	 * @return array
	 */
	public function recurring_campaign_select( $code ) {
		return array(
			'input_type'  => 'select',
			'option_code' => $code,
			'label'       => __( 'Campaign', 'uncanny-automator' ),
			'required'    => true,
			'remote_data' => $this->remote_data_load_config( 'recurring_campaigns' ),
		);
	}

	/**
	 * Get Recurring Campaign Options for Select.
	 *
	 * @return array
	 */
	public function get_recurring_campaign_options() {

		// Return cached options.
		static $options = null;
		if ( null !== $options ) {
			return $options;
		}

		// Build options.
		$options   = array();
		$campaigns = $this->get_recurring_campaigns();
		if ( ! empty( $campaigns ) ) {
			$options[] = array(
				'text'  => _x( 'Any Recurring campaign', 'Charitable', 'uncanny-automator-pro' ),
				'value' => -1,
			);
			foreach ( $campaigns as $campaign ) {
				$options[] = array(
					'text'  => $campaign->post_title,
					'value' => $campaign->ID,
				);
			}
		}

		return $options;
	}

	/**
	 * Get Recurring Campaign Posts By Meta.
	 *
	 * @return array
	 */
	public function get_recurring_campaigns() {

		$campaigns = \Charitable_Campaigns::query(
			array(
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'relation' => 'OR',
						array(
							'key'     => '_campaign_end_date',
							'value'   => gmdate( 'Y-m-d H:i:s' ),
							'compare' => '>=',
							'type'    => 'datetime',
						),
						array(
							'key'     => '_campaign_end_date',
							'value'   => 0,
							'compare' => '=',
						),
					),
					array(
						'key'     => '_campaign_recurring_donation_mode',
						'value'   => array( 'simple', 'advanced' ),
						'compare' => 'IN',
					),
				),
			)
		);

		return ! empty( $campaigns->posts ) ? $campaigns->posts : array();
	}

	/**
	 * Get Charitable Recurring Donation Object.
	 *
	 * @param mixed $donation - Maybe Charitable_Recurring_Donation object or Recurring Donation Post ID.
	 *
	 * @return mixed - Charitable_Donation object or false.
	 */
	public function get_recurring_donation( $donation ) {

		// Already a Charitable_Recurring_Donation object.
		if ( is_a( $donation, 'Charitable_Recurring_Donation' ) ) {
			return $donation;
		}

		// Check By ID.
		if ( is_int( $donation ) ) {
			$donation_id = $donation;
			$donation    = charitable_get_donation( $donation_id );
			if ( ! $donation ) {
				return false;
			}
		}

		return is_a( $donation, 'Charitable_Recurring_Donation' ) ? $donation : false;
	}

	/**
	 * Get Charitable Campaign Object from Recurring Donation.
	 *
	 * @param mixed $donation - Maybe Charitable_Recurring_Donation object or Recurring Donation Post ID.
	 *
	 * @return mixed - Charitable_Campaign object or false.
	 */
	public function get_recurring_donation_campaign( $donation ) {

		// Validate donation.
		$donation = $this->get_recurring_donation( $donation );
		if ( ! $donation ) {
			return false;
		}

		// Get campaigns.
		$campaigns = $donation->get_campaign_donations();
		// Bail no campaigns.
		if ( empty( $campaigns ) ) {
			return false;
		}

		// TODO REVIEW - Handle Multiple Campaigns.
		$campaign_obj = reset( $campaigns );
		$campaign_id  = $campaign_obj->campaign_id;
		$campaign     = $this->get_campaign( $campaign_id );

		return $campaign ? $campaign : false;
	}

	/**
	 * Recurring donation status options for trigger dropdowns. Reads from
	 * charitable_recurring_get_valid_donation_statuses() so third-party
	 * additions via the `charitable_recurring_donation_statuses` filter are
	 * picked up automatically.
	 *
	 * @return array
	 */
	public function get_recurring_donation_status_options() {

		$options = array(
			array(
				'text'  => esc_html_x( 'Any status', 'Charitable', 'uncanny-automator-pro' ),
				'value' => '-1',
			),
		);

		if ( ! function_exists( 'charitable_recurring_get_valid_donation_statuses' ) ) {
			return $options;
		}

		foreach ( (array) charitable_recurring_get_valid_donation_statuses() as $status_key => $label ) {
			$options[] = array(
				'text'  => (string) $label,
				'value' => (string) $status_key,
			);
		}

		return $options;
	}

	/**
	 * Check if a campaign is recurring.
	 *
	 * @param int $campaign_id
	 *
	 * @return bool
	 */
	public function is_recurring_campaign( $campaign_id ) {
		$campaign_id = (int) $campaign_id;
		$campaigns   = $this->get_recurring_campaign_options();
		$campaigns   = wp_list_pluck( $campaigns, 'value' );

		return in_array( $campaign_id, $campaigns );
	}

	/**
	 * Check if a campaign is recurring and matches the given campaign ID.
	 *
	 * @param int $campaign_id
	 * @param int $check_campaign_id
	 *
	 * @return bool
	 */
	public function is_recurring_campaign_match( $campaign_id, $check_campaign_id ) {
		$campaign_id = (int) $campaign_id;
		if ( ! $this->is_recurring_campaign( $campaign_id ) ) {
			return false;
		}
		$check_campaign_id = (int) $check_campaign_id;
		if ( -1 === $check_campaign_id || $campaign_id === $check_campaign_id ) {
			return true;
		}

		return false;
	}

	/**
	 * Validates Recurring Campaign Donation Trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 * @param string $meta_key
	 *
	 * @return bool
	 */
	public function validate_recurring_campaign_donation_trigger( $trigger, $hook_args, $meta_key ) {

		// Ensure the trigger has our selected options.
		$meta = ! empty( $trigger['meta'] ) ? $trigger['meta'] : array();
		if ( ! isset( $meta[ $meta_key ] ) ) {
			return false;
		}

		// Validate the donation.
		$donation = $hook_args[0];

		// Bail early if not a recurring donation.
		if ( ! is_a( $donation, 'Charitable_Recurring_Donation' ) ) {
			return false;
		}

		// Validate the campaign.
		$campaign = $this->get_recurring_donation_campaign( $donation );
		if ( ! $campaign ) {
			return false;
		}
		$campaign_id = (int) $campaign->get_campaign_id();

		// Get our Selected Campaign ID.
		$check_campaign_id = (int) $meta[ $meta_key ];

		// Validate if campaign matches.
		return $this->is_recurring_campaign_match( $campaign_id, $check_campaign_id );
	}

	/**
	 * Get Recurring Donation Tokens Config.
	 *
	 * @return array
	 */
	public function get_recurring_donation_tokens_config() {
		//REVIEW - should we just merge in all default tokens from $this->get_donation_tokens_config()
		return array(
			// Campaign tokens.
			array(
				'tokenId'   => 'CAMPAIGN_TITLE',
				'tokenName' => __( 'Campaign title', 'uncanny-automator' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CAMPAIGN_ID',
				'tokenName' => __( 'Campaign ID', 'uncanny-automator' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CAMPAIGN_CREATOR_EMAIL',
				'tokenName' => __( 'Campaign creator email', 'uncanny-automator' ),
				'tokenType' => 'email',
			),
			// Donation tokens.
			array(
				'tokenId'   => 'DONATION_TITLE',
				'tokenName' => __( 'Donation title', 'uncanny-automator' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'DONATION_ID',
				'tokenName' => __( 'Donation ID', 'uncanny-automator' ),
				'tokenType' => 'int',
			),
			array(
				'tokenId'   => 'RECURRING_AMOUNT',
				'tokenName' => __( 'Recurring amount', 'uncanny-automator' ),
				'tokenType' => 'int', //round?
			),
			array(
				'tokenId'   => 'DONATION_DONOR_NAME',
				'tokenName' => __( 'Donor name', 'uncanny-automator' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'DONATION_DONOR_EMAIL',
				'tokenName' => __( 'Donor email', 'uncanny-automator' ),
				'tokenType' => 'email',
			),
		);
	}

	/**
	 * Populate Reccuring Donation Token Values.
	 *
	 * @param mixed $donation - Maybe Charitable_Recurring_Donation object or Recurring Donation Post ID.
	 *
	 * @return array
	 */
	public function hydrate_recurring_donation_tokens( $donation ) {

		// Generate array of empty default values.
		$defaults = wp_list_pluck( $this->get_donation_tokens_config(), 'tokenId' );
		$tokens   = array_fill_keys( $defaults, '' );

		// Get Recurring Charitable_Donation object.
		$donation = $this->get_recurring_donation( $donation );
		// Bail invalid donation.
		if ( ! $donation ) {
			return $tokens;
		}

		$donation_id = $donation->ID;

		// Donation Data.
		$tokens['DONATION_ID']      = $donation_id;
		$tokens['DONATION_TITLE']   = get_the_title( $donation_id );
		$tokens['RECURRING_AMOUNT'] = $donation->get_recurring_donation_amount( true );

		// Donor Data.
		$donor_data = $donation->get_donor_data();

		if ( ! empty( $donor_data ) ) {
			$tokens['DONATION_DONOR_NAME']  = $donor_data['first_name'] . ' ' . $donor_data['last_name'];
			$tokens['DONATION_DONOR_EMAIL'] = $donor_data['email'];
		}

		// Campaign Data.
		$campaign = $this->get_recurring_donation_campaign( $donation );
		// Bail invalid campaign.
		if ( ! $campaign ) {
			return $tokens;
		}

		$tokens['CAMPAIGN_ID']            = $campaign->get_campaign_id();
		$tokens['CAMPAIGN_TITLE']         = $campaign->post_title;
		$tokens['CAMPAIGN_CREATOR_EMAIL'] = $campaign->get_campaign_creator_email();

		return $tokens;
	}

	/**
	 * Donor email type options for the "Add donor email" action.
	 *
	 * Mirrors Charitable Pro's admin form (Charitable_Admin_Donor_Form::get_email_types)
	 * including the `charitable_donor_email_types` filter, so third-party additions
	 * surface here too. Falls back to Charitable's hard-coded list when Pro's admin
	 * form class isn't loaded.
	 *
	 * @return array
	 */
	public function get_donor_email_type_options() {

		if ( class_exists( '\Charitable_Admin_Donor_Form' ) ) {
			$types = ( new \Charitable_Admin_Donor_Form() )->get_email_types();
		} else {
			$types = apply_filters(
				'charitable_donor_email_types',
				array(
					'primary' => esc_html_x( 'Primary', 'Charitable', 'uncanny-automator-pro' ),
					'work'    => esc_html_x( 'Work', 'Charitable', 'uncanny-automator-pro' ),
					'other'   => esc_html_x( 'Other', 'Charitable', 'uncanny-automator-pro' ),
				)
			);
		}

		$options = array();
		foreach ( (array) $types as $value => $text ) {
			$options[] = array(
				'text'  => $text,
				'value' => $value,
			);
		}

		return $options;
	}

	/**
	 * Pending donation options for the "Cancel a pending donation" action.
	 *
	 * Only post_status = charitable-pending donations are eligible — Charitable's
	 * own cancel flow refuses anything else. Custom values stay supported on the
	 * action field so trigger tokens can still target dynamic donation IDs.
	 *
	 * @return array
	 */
	public function get_pending_donation_options() {

		static $options = null;
		if ( null !== $options ) {
			return $options;
		}

		$options = array();
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'donation' AND post_status = 'charitable-pending' ORDER BY post_date DESC" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		foreach ( (array) $rows as $row ) {
			$options[] = array(
				'text'  => sprintf( '%s, #%d', $row->post_title, (int) $row->ID ),
				'value' => (int) $row->ID,
			);
		}

		return $options;
	}

	/**
	 * WordPress user select options for the "Link WP user to donor" action.
	 *
	 * Uses Automator's cached wp_users() helper (transient-backed) so the option
	 * list stays cheap to render even on sites with many users.
	 *
	 * @return array
	 */
	public function get_wp_user_options() {

		static $options = null;
		if ( null !== $options ) {
			return $options;
		}

		$options = array();
		$users   = \Automator()->helpers->recipe->wp_users();

		foreach ( (array) $users as $user ) {
			$display   = trim( $user->display_name );
			$options[] = array(
				'text'  => sprintf( '%s, #%d', '' !== $display ? $display : (string) $user->ID, (int) $user->ID ),
				'value' => (int) $user->ID,
			);
		}

		return $options;
	}

	/**
	 * Get Donation Tokens.
	 *
	 * @param mixed $donation - Maybe Charitable_Recurring_Donation object or Recurring Donation Post ID.
	 *
	 * @return array
	 */
	function get_donation_options() {

		// Return cached options.
		static $options = null;
		if ( null !== $options ) {
			return $options;
		}

		// Build options.
		$options = array();

		// Get donations.
		global $wpdb;
		$sql       = "SELECT `ID`, `post_title` FROM {$wpdb->posts} WHERE `post_type` = 'donation' ORDER BY `post_date` DESC";
		$donations = $wpdb->get_results( $sql, OBJECT_K );

		if ( class_exists( 'Charitable_Recurring' ) ) {
			$sql                 = "SELECT `ID`, `post_title`, `post_parent` FROM {$wpdb->posts} WHERE `post_type` = 'recurring_donation' ORDER BY `post_date` DESC";
			$recurring_donations = $wpdb->get_results( $sql, OBJECT_K );
			if ( ! empty( $recurring_donations ) ) {
				foreach ( $recurring_donations as $recurring_donation ) {
					$donations[ $recurring_donation->ID ] = $recurring_donation;
				}
			}
		}

		if ( ! empty( $donations ) ) {
			foreach ( $donations as $donation ) {
				$options[] = array(
					'text'  => $donation->post_title,
					'value' => $donation->ID,
				);
			}
		}

		return $options;
	}

	// ============================================================
	// Remote_Data segments — wrap existing get_*_options() methods.
	// ============================================================

	/**
	 * Remote_Data segment: recurring campaigns.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_recurring_campaigns( $request ): array {
		return $this->remote_data_success( $this->get_recurring_campaign_options() );
	}

	/**
	 * Remote_Data segment: donor_email_types_strict.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_donor_email_types_strict( $request ): array {
		return $this->remote_data_success( $this->get_donor_email_type_options() );
	}

	/**
	 * Remote_Data segment: pending_donations_strict.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_pending_donations_strict( $request ): array {
		return $this->remote_data_success( $this->get_pending_donation_options() );
	}

	/**
	 * Remote_Data segment: wp_users_strict.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_wp_users_strict( $request ): array {
		return $this->remote_data_success( $this->get_wp_user_options() );
	}

	/**
	 * Remote_Data segment: donations_strict (one-time + recurring).
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_donations_strict( $request ): array {
		return $this->remote_data_success( $this->get_donation_options() );
	}
}

if ( ! class_exists( 'Uncanny_Automator_Pro\\Integrations\\Charitable\\CHARITABLE_HELPERS_PRO' ) ) {
	class_alias(
		Charitable_Pro_Helpers::class,
		'Uncanny_Automator_Pro\\Integrations\\Charitable\\CHARITABLE_HELPERS_PRO'
	);
}
