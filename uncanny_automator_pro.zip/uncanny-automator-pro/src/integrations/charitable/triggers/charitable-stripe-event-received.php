<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_STRIPE_EVENT_RECEIVED
 *
 * Fires when Charitable receives a Stripe webhook event that is NOT handled by
 * one of Charitable's default event processors. Transaction lifecycle events
 * (payment_intent.succeeded, charge.refunded, invoice.payment_*, customer.subscription.*,
 * checkout.session.completed) are processed and short-circuited inside
 * Charitable_Stripe_Webhook_Processor::run_event_processors() before this hook
 * fires — use the donation-status triggers for those.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_STRIPE_EVENT_RECEIVED extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_STRIPE_EVENT_RECEIVED', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_STRIPE_EVENT_TYPE' )
			->hook( 'charitable_stripe_ipn_event', 20, 2 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Stripe event type placeholder */
				esc_html_x( 'A {{Stripe webhook event:%1$s}} is received', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'A {{Stripe webhook event}} is received', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_trigger_meta(),
				'label'       => esc_html_x( 'Stripe event type', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
				'placeholder' => esc_attr_x( 'e.g., customer.subscription.created (leave blank to match any)', 'Charitable', 'uncanny-automator-pro' ),
				'description' => esc_html_x( 'Charitable handles payment_intent.*, charge.refunded, invoice.*, customer.subscription.* and checkout.session.completed internally, so those will not fire this trigger. Use the donation-status triggers for transaction lifecycle events.', 'Charitable', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $event_type, $event ) = array_pad( $hook_args, 2, null );

		if ( empty( $event_type ) ) {
			return false;
		}

		$selected = trim( (string) ( $trigger['meta'][ $this->get_trigger_meta() ] ?? '' ) );

		if ( '' !== $selected && $selected !== (string) $event_type ) {
			return false;
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'STRIPE_EVENT_TYPE',
				'tokenName' => esc_html_x( 'Stripe event type', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'STRIPE_EVENT_ID',
				'tokenName' => esc_html_x( 'Stripe event ID', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'STRIPE_EVENT_OBJECT_ID',
				'tokenName' => esc_html_x( 'Stripe object ID', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'STRIPE_EVENT_API_VERSION',
				'tokenName' => esc_html_x( 'Stripe API version', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'STRIPE_EVENT_CREATED',
				'tokenName' => esc_html_x( 'Stripe event created (Unix timestamp)', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'STRIPE_EVENT_LIVEMODE',
				'tokenName' => esc_html_x( 'Stripe livemode', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $event_type, $event ) = array_pad( $hook_args, 2, null );

		$tokens = array(
			'STRIPE_EVENT_TYPE'        => (string) $event_type,
			'STRIPE_EVENT_ID'          => '',
			'STRIPE_EVENT_OBJECT_ID'   => '',
			'STRIPE_EVENT_API_VERSION' => '',
			'STRIPE_EVENT_CREATED'     => '',
			'STRIPE_EVENT_LIVEMODE'    => '',
		);

		if ( ! is_object( $event ) ) {
			return $tokens;
		}

		$tokens['STRIPE_EVENT_ID']          = isset( $event->id ) ? (string) $event->id : '';
		$tokens['STRIPE_EVENT_API_VERSION'] = isset( $event->api_version ) ? (string) $event->api_version : '';
		$tokens['STRIPE_EVENT_CREATED']     = isset( $event->created ) ? (string) $event->created : '';
		$tokens['STRIPE_EVENT_LIVEMODE']    = ! empty( $event->livemode ) ? '1' : '0';

		if ( isset( $event->data->object->id ) ) {
			$tokens['STRIPE_EVENT_OBJECT_ID'] = (string) $event->data->object->id;
		}

		return $tokens;
	}
}
