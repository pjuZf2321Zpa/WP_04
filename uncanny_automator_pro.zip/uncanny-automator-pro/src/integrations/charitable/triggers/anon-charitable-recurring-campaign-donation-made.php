<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class ANON_CHARITABLE_RECURRING_CAMPAIGN_DONATION_MADE
 *
 * @package Uncanny_Automator_Pro
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class ANON_CHARITABLE_RECURRING_CAMPAIGN_DONATION_MADE extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'RECURRING_DONATION_MADE', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_RECURRING_CAMPAIGN' )
			->hook( 'charitable_recurring_donation_status_charitable-active', 999, 2 );
	}

	/**
	 * Anonymous trigger that will fire even if no user is logged in.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_pro( true );
		$this->set_support_link( Automator()->get_author_support_link( 'RECURRING_DONATION_MADE', 'integration/charitable/' ) );

		// Non Active State Sentence.
		$this->set_readable_sentence(
			esc_attr_x(
				'A recurring donation to {{a campaign}} is made',
				'Charitable',
				'uncanny-automator-pro'
			)
		);

		// Active State Sentence.
		$this->set_sentence(
			sprintf(
				/* Translators: Trigger sentence - Charitable */
				esc_attr_x(
					'A recurring donation to {{a campaign:%1$s}} is made',
					'Charitable',
					'uncanny-automator-pro'
				),
				'CHARITABLE_RECURRING_CAMPAIGN'
			)
		);
	}

	/**
	 * Load Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->recurring_campaign_select( 'CHARITABLE_RECURRING_CAMPAIGN' ),
		);
	}

	/**
	 * Validate Trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {
		return $this->item_helpers->validate_recurring_campaign_donation_trigger( $trigger, $hook_args, 'CHARITABLE_RECURRING_CAMPAIGN' );
	}

	/**
	 * Define Tokens.
	 *
	 * @param array $tokens
	 * @param array $trigger - options selected in the current recipe/trigger
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->get_recurring_donation_tokens_config() );
	}

	/**
	 * Hydrate Tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		return $this->item_helpers->hydrate_recurring_donation_tokens( $hook_args[0] );
	}

}
