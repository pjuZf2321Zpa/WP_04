<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_DONOR_PROFILE_UPDATED
 *
 * Fires when a donor saves the Charitable profile form (frontend).
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_DONOR_PROFILE_UPDATED extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_DONOR_PROFILE_UPDATED', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_DONOR' )
			->hook( 'charitable_profile_updated', 20, 3 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence( esc_html_x( "A donor's profile is updated", 'Charitable', 'uncanny-automator-pro' ) );
		$this->set_readable_sentence( esc_html_x( "A donor's profile is updated", 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Validate trigger.
	 *
	 * Resolves the user from the profile form context (always a logged-in user).
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		$user_id = get_current_user_id();
		if ( empty( $user_id ) ) {
			return false;
		}

		$this->set_user_id( (int) $user_id );

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->get_donor_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		$user_id = get_current_user_id();
		if ( empty( $user_id ) || ! function_exists( 'charitable_get_table' ) ) {
			return array();
		}

		$donor_id = 0;
		$table    = charitable_get_table( 'donors' );
		if ( $table && method_exists( $table, 'get_donor_id_by_user_id' ) ) {
			$donor_id = (int) $table->get_donor_id_by_user_id( $user_id );
		}

		if ( empty( $donor_id ) ) {
			return array();
		}

		return $this->item_helpers->hydrate_donor_tokens( $donor_id );
	}
}
