<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_DONATION_STATUS_TRANSITION
 *
 * Fires when a donation's status transitions from a specific OLD status to a specific NEW status.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_DONATION_STATUS_TRANSITION extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_DONATION_STATUS_TRANSITION', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_DONATION_FROM_STATUS' )
			->hook( 'charitable_donation_status_changed', 20, 3 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: From status 2: To status 3: Campaign */
				esc_html_x(
					"A donation's status transitions from {{a status:%1\$s}} to {{a status:%2\$s}} for {{a campaign:%3\$s}}",
					'Charitable',
					'uncanny-automator-pro'
				),
				$this->get_trigger_meta(),
				'CHARITABLE_DONATION_TO_STATUS:' . $this->get_trigger_meta(),
				'CHARITABLE_CAMPAIGN:' . $this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( "A donation's status transitions from {{a status}} to {{a status}} for {{a campaign}}", 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_trigger_meta(),
				'label'       => esc_html_x( 'From status', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => $this->item_helpers->get_donation_status_options(),
			),
			array(
				'option_code' => 'CHARITABLE_DONATION_TO_STATUS',
				'label'       => esc_html_x( 'To status', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => $this->item_helpers->get_donation_status_options(),
			),
			array(
				'option_code' => 'CHARITABLE_CAMPAIGN',
				'label'       => esc_html_x( 'Campaign', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'remote_data' => $this->item_helpers->remote_data_load_config( 'campaigns' ),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $donation, $new_status, $old_status ) = array_pad( $hook_args, 3, null );

		if ( ! is_a( $donation, 'Charitable_Donation' ) ) {
			return false;
		}

		$from_selected     = $trigger['meta'][ $this->get_trigger_meta() ] ?? '-1';
		$to_selected       = $trigger['meta']['CHARITABLE_DONATION_TO_STATUS'] ?? '-1';
		$selected_campaign = (int) ( $trigger['meta']['CHARITABLE_CAMPAIGN'] ?? -1 );

		if ( '-1' !== $from_selected && $from_selected !== $old_status ) {
			return false;
		}

		if ( '-1' !== $to_selected && $to_selected !== $new_status ) {
			return false;
		}

		if ( -1 !== $selected_campaign ) {
			$campaign = $this->item_helpers->get_donation_campaign( $donation->ID );
			if ( ! $campaign || (int) $campaign->get_campaign_id() !== $selected_campaign ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'DONATION_OLD_STATUS',
				'tokenName' => esc_html_x( 'Donation old status', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'DONATION_NEW_STATUS',
				'tokenName' => esc_html_x( 'Donation new status', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_donation_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $donation, $new_status, $old_status ) = array_pad( $hook_args, 3, null );

		if ( ! is_a( $donation, 'Charitable_Donation' ) ) {
			return array();
		}

		$tokens = $this->item_helpers->hydrate_donation_tokens( $donation->ID );

		$tokens['DONATION_OLD_STATUS'] = (string) $old_status;
		$tokens['DONATION_NEW_STATUS'] = (string) $new_status;

		return $tokens;
	}
}
