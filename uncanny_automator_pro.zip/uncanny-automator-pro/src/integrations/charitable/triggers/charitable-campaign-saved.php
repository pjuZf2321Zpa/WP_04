<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_CAMPAIGN_SAVED
 *
 * Fires when a campaign is created or updated via any save path.
 * Charitable_Integration::register_campaign_saved_bridge() normalizes both
 * save_post_campaign and charitable_campaign_processor_save_core into the
 * single internal action this trigger listens on.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_CAMPAIGN_SAVED extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_CAMPAIGN_SAVED', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_SAVE_ACTION' )
			->hook( 'automator_charitable_campaign_saved', 10, 2 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Save action 2: Campaign */
				esc_html_x( '{{A campaign:%2$s}} is {{created or updated:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta(),
				'CHARITABLE_CAMPAIGN:' . $this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( '{{A campaign}} is {{created or updated}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_trigger_meta(),
				'label'       => esc_html_x( 'Save action', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => array(
					array(
						'text'  => esc_html_x( 'Created or updated', 'Charitable', 'uncanny-automator-pro' ),
						'value' => '-1',
					),
					array(
						'text'  => esc_html_x( 'Created', 'Charitable', 'uncanny-automator-pro' ),
						'value' => 'insert',
					),
					array(
						'text'  => esc_html_x( 'Updated', 'Charitable', 'uncanny-automator-pro' ),
						'value' => 'update',
					),
				),
			),
			array(
				'option_code' => 'CHARITABLE_CAMPAIGN',
				'label'       => esc_html_x( 'Campaign', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'description' => esc_html_x( 'If the "Save action" field above is set to "Created", this "Campaign" field is ignored. The trigger fires for any newly created campaign.', 'Charitable', 'uncanny-automator-pro' ),
				'remote_data' => $this->item_helpers->remote_data_load_config( 'campaigns' ),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $campaign_id, $action ) = array_pad( $hook_args, 2, null );

		if ( empty( $campaign_id ) ) {
			return false;
		}

		$selected_action   = $trigger['meta'][ $this->get_trigger_meta() ] ?? '-1';
		$selected_campaign = (int) ( $trigger['meta']['CHARITABLE_CAMPAIGN'] ?? -1 );

		if ( '-1' !== $selected_action && $selected_action !== $action ) {
			return false;
		}

		// "Created" can never match a specific campaign: a brand-new campaign has
		// no ID chosen at recipe-build time. So the campaign selection is ignored
		// for "Created" and only enforced for "Updated" / "Created or updated".
		if ( 'insert' !== $selected_action && -1 !== $selected_campaign && (int) $campaign_id !== $selected_campaign ) {
			return false;
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'CAMPAIGN_SAVE_ACTION',
				'tokenName' => esc_html_x( 'Save action', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_campaign_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $campaign_id, $action ) = array_pad( $hook_args, 2, null );

		$tokens = $this->item_helpers->hydrate_campaign_tokens( $campaign_id );

		$tokens['CAMPAIGN_SAVE_ACTION'] = (string) $action;

		return $tokens;
	}
}
