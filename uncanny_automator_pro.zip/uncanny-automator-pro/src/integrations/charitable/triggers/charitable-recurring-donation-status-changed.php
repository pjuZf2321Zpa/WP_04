<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_RECURRING_DONATION_STATUS_CHANGED
 *
 * Fires when a recurring donation transitions to any new status via
 * Charitable_Recurring_Donation::update_status(). Both fields filter the run:
 *   - Recurring campaign dropdown: only recurring campaigns (Pro helper).
 *   - To-status dropdown: every status from
 *     charitable_recurring_get_valid_donation_statuses(), plus "Any".
 *
 * Gated at instantiation on class_exists( 'Charitable_Recurring' ) — see
 * Charitable_Integration::load() in Pro.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_RECURRING_DONATION_STATUS_CHANGED extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_RECURRING_DONATION_STATUS_CHANGED', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_RECURRING_CAMPAIGN' )
			->hook( 'charitable_recurring_donation_status_changed', 20, 3 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Campaign placeholder 2: Status placeholder */
				esc_html_x( "A recurring donation to {{a campaign:%1\$s}} changes status to {{a status:%2\$s}}", 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta(),
				'CHARITABLE_RECURRING_NEW_STATUS:' . $this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'A recurring donation to {{a campaign}} changes status to {{a status}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->recurring_campaign_select( $this->get_trigger_meta() ),
			array(
				'option_code' => 'CHARITABLE_RECURRING_NEW_STATUS',
				'label'       => esc_html_x( 'New status', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => $this->item_helpers->get_recurring_donation_status_options(),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $donation, $new_status, $old_status ) = array_pad( $hook_args, 3, null );

		if ( ! is_a( $donation, 'Charitable_Recurring_Donation' ) ) {
			return false;
		}

		$selected_status = (string) ( $trigger['meta']['CHARITABLE_RECURRING_NEW_STATUS'] ?? '-1' );
		if ( '-1' !== $selected_status && $selected_status !== (string) $new_status ) {
			return false;
		}

		// Validate the recurring-campaign selection via the shared helper.
		// is_recurring_campaign_match handles the "Any" sentinel (-1) and
		// confirms the donation's campaign is a recurring one.
		$campaign = $this->item_helpers->get_recurring_donation_campaign( $donation );
		if ( ! $campaign ) {
			return false;
		}

		$campaign_id       = (int) $campaign->get_campaign_id();
		$selected_campaign = (int) ( $trigger['meta'][ $this->get_trigger_meta() ] ?? -1 );

		if ( ! $this->item_helpers->is_recurring_campaign_match( $campaign_id, $selected_campaign ) ) {
			return false;
		}

		// Link recipe run to the donor's WP user when one exists.
		$donor_id = (int) $donation->get_donor_id();
		if ( $donor_id > 0 && class_exists( 'Charitable_Donor' ) ) {
			$donor = new \Charitable_Donor( $donor_id );
			$user  = $donor ? $donor->get_user() : null;
			if ( $user && isset( $user->ID ) && $user->ID > 0 ) {
				$this->set_user_id( (int) $user->ID );
			}
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'RECURRING_DONATION_NEW_STATUS',
				'tokenName' => esc_html_x( 'Recurring donation new status', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'RECURRING_DONATION_OLD_STATUS',
				'tokenName' => esc_html_x( 'Recurring donation old status', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_recurring_donation_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $donation, $new_status, $old_status ) = array_pad( $hook_args, 3, null );

		$tokens = $this->item_helpers->hydrate_recurring_donation_tokens( $donation );

		$tokens['RECURRING_DONATION_NEW_STATUS'] = (string) $new_status;
		$tokens['RECURRING_DONATION_OLD_STATUS'] = (string) $old_status;

		return $tokens;
	}
}
