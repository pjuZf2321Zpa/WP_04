<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_REFUND_INITIATED_BY_GATEWAY
 *
 * Fires when an admin initiates a gateway refund from the donation edit screen.
 * Listens to all known charitable_process_refund_{$gateway} actions and matches
 * against the user's selected gateway. Since the upstream hooks are real
 * do_action() calls, the trigger listens to them directly via the multi-hook
 * definition().
 *
 * Note: this is the gateway-side refund dispatch (the admin "Refund in gateway"
 * checkbox). For the donation-status-changed-to-refunded event, see
 * CHARITABLE_DONATION_REFUNDED.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_REFUND_INITIATED_BY_GATEWAY extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 *
	 * The list mirrors the bundled gateway IDs in Charitable + Charitable Pro
	 * (stripe, paypal, offline, square_core, square legacy, paypal_commerce).
	 * Third-party gateways registered via charitable_payment_gateways will not
	 * fire this trigger unless they also register charitable_process_refund_{id}.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_REFUND_INITIATED_BY_GATEWAY', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_GATEWAY' )
			->hook( 'charitable_process_refund_stripe', 20, 1 )
			->hook( 'charitable_process_refund_paypal', 20, 1 )
			->hook( 'charitable_process_refund_square_core', 20, 1 )
			->hook( 'charitable_process_refund_square', 20, 1 )
			->hook( 'charitable_process_refund_paypal_commerce', 20, 1 )
			->hook( 'charitable_process_refund_offline', 20, 1 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Gateway placeholder */
				esc_html_x( 'A refund is initiated via {{a payment gateway:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'A refund is initiated via {{a payment gateway}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_trigger_meta(),
				'label'       => esc_html_x( 'Payment gateway', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => $this->item_helpers->get_active_gateway_options(),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		$donation_id = isset( $hook_args[0] ) ? (int) $hook_args[0] : 0;
		if ( empty( $donation_id ) ) {
			return false;
		}

		$gateway = $this->gateway_from_hook( current_action() );
		if ( '' === $gateway ) {
			return false;
		}

		$selected = (string) ( $trigger['meta'][ $this->get_trigger_meta() ] ?? '-1' );
		if ( '-1' !== $selected && $selected !== $gateway ) {
			return false;
		}

		// Link recipe run to donor's WP user when one exists.
		$donation = $this->item_helpers->get_donation( $donation_id );
		if ( $donation && class_exists( 'Charitable_Donor' ) ) {
			$donor_id = (int) $donation->get_donor_id();
			if ( $donor_id > 0 ) {
				$donor = new \Charitable_Donor( $donor_id );
				$user  = $donor ? $donor->get_user() : null;
				if ( $user && isset( $user->ID ) && $user->ID > 0 ) {
					$this->set_user_id( (int) $user->ID );
				}
			}
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'CHARITABLE_GATEWAY',
				'tokenName' => esc_html_x( 'Payment gateway ID', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CHARITABLE_GATEWAY_LABEL',
				'tokenName' => esc_html_x( 'Payment gateway label', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_donation_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		$donation_id = isset( $hook_args[0] ) ? (int) $hook_args[0] : 0;
		$tokens      = $this->item_helpers->hydrate_donation_tokens( $donation_id );

		// current_action() is reliable here — Trigger_Queue::call_with_filter_context()
		// keeps $wp_current_filter populated through both validate() and
		// hydrate_tokens(). Fall back to the donation's stored gateway if the
		// hook context is unexpectedly empty.
		$gateway = $this->gateway_from_hook( current_action() );
		if ( '' === $gateway ) {
			$gateway = $this->resolve_gateway_from_donation( $donation_id );
		}

		$tokens['CHARITABLE_GATEWAY']       = $gateway;
		$tokens['CHARITABLE_GATEWAY_LABEL'] = $this->resolve_gateway_label( $gateway );

		return $tokens;
	}

	/**
	 * Strip the charitable_process_refund_ prefix to recover the gateway ID.
	 *
	 * @param string $hook
	 *
	 * @return string
	 */
	private function gateway_from_hook( $hook ) {
		$prefix = 'charitable_process_refund_';
		if ( 0 !== strpos( (string) $hook, $prefix ) ) {
			return '';
		}
		return substr( $hook, strlen( $prefix ) );
	}

	/**
	 * Fallback: read the gateway off the donation itself.
	 *
	 * @param int $donation_id
	 *
	 * @return string
	 */
	private function resolve_gateway_from_donation( $donation_id ) {
		$donation = $this->item_helpers->get_donation( $donation_id );
		return $donation ? (string) $donation->get_gateway() : '';
	}

	/**
	 * Resolve a gateway ID to its admin label.
	 *
	 * @param string $gateway_id
	 *
	 * @return string
	 */
	private function resolve_gateway_label( $gateway_id ) {
		if ( '' === $gateway_id || ! function_exists( 'charitable_get_helper' ) ) {
			return $gateway_id;
		}

		$gateways_helper = charitable_get_helper( 'gateways' );
		if ( ! $gateways_helper || ! method_exists( $gateways_helper, 'get_gateway_choices' ) ) {
			return $gateway_id;
		}

		$choices = (array) $gateways_helper->get_gateway_choices();
		return isset( $choices[ $gateway_id ] ) ? (string) $choices[ $gateway_id ] : $gateway_id;
	}
}
