<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_PAYPAL_IPN_RECEIVED
 *
 * Fires when Charitable receives a PayPal IPN payload via charitable_paypal_web_accept.
 * Charitable's own handler (Charitable_Gateway_Paypal::process_web_accept) consumes
 * the same hook to update the donation status — this trigger runs alongside it.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_PAYPAL_IPN_RECEIVED extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_PAYPAL_IPN_RECEIVED', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_PAYPAL_PAYMENT_STATUS' )
			->hook( 'charitable_paypal_web_accept', 20, 2 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: PayPal payment status placeholder */
				esc_html_x( 'A PayPal IPN is received with {{a payment status:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'A PayPal IPN is received with {{a payment status}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_trigger_meta(),
				'label'       => esc_html_x( 'Payment status', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => $this->get_paypal_payment_status_options(),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $data, $donation_id ) = array_pad( $hook_args, 2, null );

		if ( empty( $donation_id ) || ! is_array( $data ) ) {
			return false;
		}

		$selected = (string) ( $trigger['meta'][ $this->get_trigger_meta() ] ?? '-1' );
		$status   = isset( $data['payment_status'] ) ? strtolower( (string) $data['payment_status'] ) : '';

		if ( '-1' !== $selected && $selected !== $status ) {
			return false;
		}

		// Link recipe run to the donor's WP user when one exists.
		$donation = $this->item_helpers->get_donation( (int) $donation_id );
		if ( $donation && class_exists( 'Charitable_Donor' ) ) {
			$donor_id = (int) $donation->get_donor_id();
			if ( $donor_id > 0 ) {
				$donor = new \Charitable_Donor( $donor_id );
				$user  = $donor ? $donor->get_user() : null;
				if ( $user && isset( $user->ID ) && $user->ID > 0 ) {
					$this->set_user_id( (int) $user->ID );
				}
			}
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'PAYPAL_PAYMENT_STATUS',
				'tokenName' => esc_html_x( 'PayPal payment status', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'PAYPAL_TRANSACTION_ID',
				'tokenName' => esc_html_x( 'PayPal transaction ID', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'PAYPAL_TRANSACTION_TYPE',
				'tokenName' => esc_html_x( 'PayPal transaction type', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'PAYPAL_GROSS_AMOUNT',
				'tokenName' => esc_html_x( 'PayPal gross amount', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'PAYPAL_CURRENCY',
				'tokenName' => esc_html_x( 'PayPal currency', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'PAYPAL_PAYER_EMAIL',
				'tokenName' => esc_html_x( 'PayPal payer email', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'email',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_donation_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $data, $donation_id ) = array_pad( $hook_args, 2, null );

		$donation_id = (int) $donation_id;
		$tokens      = $this->item_helpers->hydrate_donation_tokens( $donation_id );

		$data = is_array( $data ) ? $data : array();

		$tokens['PAYPAL_PAYMENT_STATUS']   = isset( $data['payment_status'] ) ? strtolower( (string) $data['payment_status'] ) : '';
		$tokens['PAYPAL_TRANSACTION_ID']   = isset( $data['txn_id'] ) ? (string) $data['txn_id'] : '';
		$tokens['PAYPAL_TRANSACTION_TYPE'] = isset( $data['txn_type'] ) ? (string) $data['txn_type'] : 'web_accept';
		$tokens['PAYPAL_GROSS_AMOUNT']     = isset( $data['mc_gross'] ) ? (string) $data['mc_gross'] : '';
		$tokens['PAYPAL_CURRENCY']         = isset( $data['mc_currency'] ) ? strtoupper( (string) $data['mc_currency'] ) : '';
		$tokens['PAYPAL_PAYER_EMAIL']      = isset( $data['payer_email'] ) ? (string) $data['payer_email'] : '';

		return $tokens;
	}

	/**
	 * PayPal payment status options. Mirrors the lowercase status values
	 * Charitable_Gateway_Paypal::process_web_accept() compares against.
	 *
	 * @return array
	 */
	private function get_paypal_payment_status_options() {
		return array(
			array(
				'text'  => esc_html_x( 'Any status', 'Charitable', 'uncanny-automator-pro' ),
				'value' => '-1',
			),
			array(
				'text'  => esc_html_x( 'Completed', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'completed',
			),
			array(
				'text'  => esc_html_x( 'Pending', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'pending',
			),
			array(
				'text'  => esc_html_x( 'Failed', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'failed',
			),
			array(
				'text'  => esc_html_x( 'Refunded', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'refunded',
			),
			array(
				'text'  => esc_html_x( 'Reversed', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'reversed',
			),
			array(
				'text'  => esc_html_x( 'Denied', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'denied',
			),
			array(
				'text'  => esc_html_x( 'Voided', 'Charitable', 'uncanny-automator-pro' ),
				'value' => 'voided',
			),
		);
	}
}
