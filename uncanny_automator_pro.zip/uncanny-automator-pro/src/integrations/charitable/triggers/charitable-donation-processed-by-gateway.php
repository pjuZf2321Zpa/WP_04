<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_DONATION_PROCESSED_BY_GATEWAY
 *
 * Fires when Charitable dispatches donation processing to a payment gateway via
 * the dynamic charitable_process_donation_{$gateway} hook. Because that upstream
 * hook is apply_filters() (not do_action()), listening directly with a void
 * callback would corrupt the filter chain. Instead, Charitable_Integration::
 * forward_donation_processed_to_gateway() bridges every active-gateway filter
 * to the safe action automator_charitable_donation_processed_by_gateway, which
 * is what this trigger listens to.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_DONATION_PROCESSED_BY_GATEWAY extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_DONATION_PROCESSED_BY_GATEWAY', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_GATEWAY' )
			->hook( 'automator_charitable_donation_processed_by_gateway', 20, 3 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Gateway placeholder */
				esc_html_x( 'A donation is processed via {{a payment gateway:%1$s}}', 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'A donation is processed via {{a payment gateway}}', 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_trigger_meta(),
				'label'       => esc_html_x( 'Payment gateway', 'Charitable', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
				'required'    => true,
				'options'     => $this->item_helpers->get_active_gateway_options(),
			),
		);
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $donation_id, $gateway ) = array_pad( $hook_args, 3, null );

		$donation_id = (int) $donation_id;
		$gateway     = (string) $gateway;

		if ( empty( $donation_id ) || '' === $gateway ) {
			return false;
		}

		$selected = (string) ( $trigger['meta'][ $this->get_trigger_meta() ] ?? '-1' );

		if ( '-1' !== $selected && $selected !== $gateway ) {
			return false;
		}

		// Link the recipe run to the donor's WP user when one exists.
		$donation = $this->item_helpers->get_donation( $donation_id );
		if ( $donation && class_exists( 'Charitable_Donor' ) ) {
			$donor_id = (int) $donation->get_donor_id();
			if ( $donor_id > 0 ) {
				$donor = new \Charitable_Donor( $donor_id );
				$user  = $donor ? $donor->get_user() : null;
				if ( $user && isset( $user->ID ) && $user->ID > 0 ) {
					$this->set_user_id( (int) $user->ID );
				}
			}
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'CHARITABLE_GATEWAY',
				'tokenName' => esc_html_x( 'Payment gateway ID', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CHARITABLE_GATEWAY_LABEL',
				'tokenName' => esc_html_x( 'Payment gateway label', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_donation_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $donation_id, $gateway ) = array_pad( $hook_args, 3, null );

		$donation_id = (int) $donation_id;
		$tokens      = $this->item_helpers->hydrate_donation_tokens( $donation_id );

		$tokens['CHARITABLE_GATEWAY']       = (string) $gateway;
		$tokens['CHARITABLE_GATEWAY_LABEL'] = $this->resolve_gateway_label( (string) $gateway );

		return $tokens;
	}

	/**
	 * Resolve a gateway ID to its admin label via Charitable_Gateways::get_gateway_choices().
	 *
	 * @param string $gateway_id
	 *
	 * @return string
	 */
	private function resolve_gateway_label( $gateway_id ) {
		if ( '' === $gateway_id || ! function_exists( 'charitable_get_helper' ) ) {
			return $gateway_id;
		}

		$gateways_helper = charitable_get_helper( 'gateways' );
		if ( ! $gateways_helper || ! method_exists( $gateways_helper, 'get_gateway_choices' ) ) {
			return $gateway_id;
		}

		$choices = (array) $gateways_helper->get_gateway_choices();
		return isset( $choices[ $gateway_id ] ) ? (string) $choices[ $gateway_id ] : $gateway_id;
	}
}
