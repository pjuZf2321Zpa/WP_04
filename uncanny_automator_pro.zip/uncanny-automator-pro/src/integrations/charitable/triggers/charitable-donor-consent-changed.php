<?php

namespace Uncanny_Automator_Pro\Integrations\Charitable;

/**
 * Class CHARITABLE_DONOR_CONSENT_CHANGED
 *
 * Fires when a donor opts in or out of contact/communication consent.
 *
 * @property \Uncanny_Automator_Pro\Integrations\Charitable\Charitable_Pro_Helpers $item_helpers
 */
class CHARITABLE_DONOR_CONSENT_CHANGED extends \Uncanny_Automator\Recipe\Trigger {

	/**
	 * Opt this trigger into the lazy loading path.
	 */
	public static function definition() {
		return self::new_definition( 'CHARITABLE_DONOR_CONSENT_CHANGED', 'CHARITABLE' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CHARITABLE_CONSENT_CHANGE' )
			->hook( 'charitable_donor_contact_consent_changed', 20, 3 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		// integration / code / trigger_meta / trigger_type are auto-applied from definition().
		$this->set_is_login_required( false );
		$this->set_is_pro( true );
		$this->set_sentence(
			sprintf(
				/* translators: 1: Consent type placeholder */
				esc_html_x( "A donor's consent is updated", 'Charitable', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( "A donor's consent is updated", 'Charitable', 'uncanny-automator-pro' ) );
	}

	/**
	 * Validate trigger.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $consent_changed, $statement_changed, $donor_id ) = array_pad( $hook_args, 3, null );

		if ( empty( $donor_id ) ) {
			return false;
		}

		if ( empty( $consent_changed )  && empty( $statement_changed ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$extra = array(
			array(
				'tokenId'   => 'CONSENT_CHANGED',
				'tokenName' => esc_html_x( 'Consent changed', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'STATEMENT_CHANGED',
				'tokenName' => esc_html_x( 'Statement changed', 'Charitable', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $extra, $this->item_helpers->get_donor_tokens_config() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $consent_changed, $statement_changed, $donor_id ) = array_pad( $hook_args, 3, null );

		$tokens = $this->item_helpers->hydrate_donor_tokens( $donor_id );

		$tokens['CONSENT_CHANGED']   = true === $consent_changed ? 'yes' : 'no';
		$tokens['STATEMENT_CHANGED'] = true === $statement_changed ? 'yes' : 'no';

		return $tokens;
	}
}
