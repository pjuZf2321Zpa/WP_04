<?php

namespace Uncanny_Automator_Pro\Integrations\Aioseo;

use Uncanny_Automator_Pro\Integrations\Aioseo\AIOSEO_POST_SEO_SCORE;
use Uncanny_Automator_Pro\Loop_Filters\AIOSEO_POST_SEO_FIELD_IS_EMPTY;
use Uncanny_Automator_Pro\Loop_Filters\AIOSEO_POST_SEO_SCORE_MEETS_CONDITION;

/**
 * Class Aioseo_Integration
 *
 * @package Uncanny_Automator_Pro
 */
class Aioseo_Integration extends \Uncanny_Automator\Integration {

	/**
	 * Setup Automator integration.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->set_integration( 'AIOSEO' );
		$this->set_name( 'All in One SEO' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/aioseo-icon.svg' );

		$this->set_plugin_file_path( 'all-in-one-seo-pack/all_in_one_seo_pack.php' );
		$this->set_developer_name( 'All in One SEO' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * Load Integration Classes.
	 *
	 * @return void
	 */
	public function load() {
		new AIOSEO_POST_SEO_SCORE();
		new AIOSEO_POST_SEO_SCORE_MEETS_CONDITION();
		new AIOSEO_POST_SEO_FIELD_IS_EMPTY();
	}

	/**
	 * Check if All in One SEO is active.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return function_exists( 'aioseo' );
	}
}
