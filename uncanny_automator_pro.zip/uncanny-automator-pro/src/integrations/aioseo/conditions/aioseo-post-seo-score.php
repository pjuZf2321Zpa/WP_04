<?php

namespace Uncanny_Automator_Pro\Integrations\Aioseo;

use Uncanny_Automator_Pro\Action_Condition;

/**
 * Class AIOSEO_POST_SEO_SCORE
 *
 * @package Uncanny_Automator_Pro
 */
class AIOSEO_POST_SEO_SCORE extends Action_Condition {

	/**
	 * Define condition metadata.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration = 'AIOSEO';

		$this->name = esc_html_x( "A post's SEO score is {{greater than, less than, or equal to}} {{a value}}", 'All in One SEO', 'uncanny-automator-pro' );

		$this->code = 'POST_SEO_SCORE';

		// translators: %1$s: Post ID, %2$s: Condition, %3$s: Score value.
		$this->dynamic_name = sprintf(
			esc_html_x( "{{A post's:%1\$s}} SEO score is {{greater than, less than, or equal to:%2\$s}} {{a value:%3\$s}}", 'All in One SEO', 'uncanny-automator-pro' ),
			'POST_ID',
			'NUMBERCOND',
			'SCORE_VALUE'
		);

		$this->is_pro        = true;
		$this->requires_user = false;
	}

	/**
	 * Define condition fields.
	 *
	 * @return array
	 */
	public function fields() {

		// Convert legacy less_or_greater_than options to modern format.
		$number_conditions = Automator()->helpers->recipe->field->less_or_greater_than();
		$condition_options = array();

		foreach ( $number_conditions['options'] as $key => $label ) {
			$condition_options[] = array(
				'text'  => $label,
				'value' => $key,
			);
		}

		return array(
			$this->field->text(
				array(
					'option_code'    => 'POST_ID',
					'label'          => esc_html_x( 'Post ID', 'All in One SEO', 'uncanny-automator-pro' ),
					'input_type'     => 'text',
					'required'       => true,
					'description'    => esc_html_x( 'Enter a post ID or use a token.', 'All in One SEO', 'uncanny-automator-pro' ),
					'supports_tokens' => true,
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'           => 'NUMBERCOND',
					'label'                 => esc_html_x( 'Condition', 'All in One SEO', 'uncanny-automator-pro' ),
					'required'              => true,
					'options'               => $condition_options,
					'supports_custom_value' => false,
				)
			),
			$this->field->text(
				array(
					'option_code'    => 'SCORE_VALUE',
					'label'          => esc_html_x( 'Score', 'All in One SEO', 'uncanny-automator-pro' ),
					'input_type'     => 'text',
					'required'       => true,
					'description'    => esc_html_x( 'Enter a value between 0 and 100.', 'All in One SEO', 'uncanny-automator-pro' ),
					'supports_tokens' => true,
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$post_id     = $this->get_parsed_option( 'POST_ID' );
		$condition   = $this->get_parsed_option( 'NUMBERCOND' );
		$score_value = $this->get_parsed_option( 'SCORE_VALUE' );

		// Validate post ID.
		if ( empty( $post_id ) || ! is_numeric( $post_id ) ) {
			$this->condition_failed( sprintf( 'Invalid post ID provided: [%s]', $post_id ) );
			return;
		}

		$post = get_post( absint( $post_id ) );

		if ( null === $post ) {
			$this->condition_failed( sprintf( 'Post not found with ID: [%s]', $post_id ) );
			return;
		}

		// Get AIOSEO data.
		if ( ! class_exists( '\AIOSEO\Plugin\Common\Models\Post' ) ) {
			$this->condition_failed( 'All in One SEO Post model is not available.' );
			return;
		}

		$aioseo_post = \AIOSEO\Plugin\Common\Models\Post::getPost( absint( $post_id ) );

		if ( null === $aioseo_post ) {
			$this->condition_failed( sprintf( 'No AIOSEO data found for post ID: [%s]', $post_id ) );
			return;
		}

		$current_score = isset( $aioseo_post->seo_score ) ? (int) $aioseo_post->seo_score : 0;

		// Evaluate the numeric condition.
		$condition_met = Automator()->utilities->match_condition_vs_number( $condition, (int) $score_value, $current_score );

		if ( ! $condition_met ) {
			$readable_condition = $this->get_option( 'NUMBERCOND_readable' );
			$this->condition_failed(
				sprintf(
					'Post [%d] SEO score is [%d] which is not %s [%s].',
					$post_id,
					$current_score,
					$readable_condition,
					$score_value
				)
			);
		}
	}

	/**
	 * Check if AIOSEO dependencies are active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return function_exists( 'aioseo' ) && class_exists( '\AIOSEO\Plugin\Common\Models\Post' );
	}
}

new AIOSEO_POST_SEO_SCORE();
