<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AIOSEO_POST_SEO_FIELD_IS_EMPTY
 *
 * @package Uncanny_Automator_Pro
 */
final class AIOSEO_POST_SEO_FIELD_IS_EMPTY extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AIOSEO' );
		$this->set_meta( 'AIOSEO_POST_SEO_FIELD_IS_EMPTY' );
		$this->set_sentence( esc_html_x( "A post's SEO {{field}} {{is/is not}} empty", 'All in One SEO', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				// translators: %1$s: SEO field, %2$s: Criteria (is/is not).
				esc_html_x( "A post's SEO {{field:%1\$s}} {{is/is not:%2\$s}} empty", 'All in One SEO', 'uncanny-automator-pro' ),
				$this->get_meta(),
				'CRITERIA'
			)
		);
		$this->set_loop_type( 'posts' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_posts' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		$field = array(
			'option_code'     => $this->get_meta(),
			'type'            => 'select',
			'label'           => esc_html_x( 'Field', 'All in One SEO', 'uncanny-automator-pro' ),
			'required'        => true,
			'options'         => $this->get_seo_fields(),
			'options_show_id' => false,
		);

		$criteria = array(
			'option_code'     => 'CRITERIA',
			'type'            => 'select',
			'label'           => esc_html_x( 'Criteria', 'All in One SEO', 'uncanny-automator-pro' ),
			'required'        => true,
			'options'         => array(
				array(
					'text'  => esc_attr_x( 'is', 'All in One SEO', 'uncanny-automator-pro' ),
					'value' => 'is-empty',
				),
				array(
					'text'  => esc_attr_x( 'is not', 'All in One SEO', 'uncanny-automator-pro' ),
					'value' => 'is-not-empty',
				),
			),
			'options_show_id' => false,
		);

		return array(
			$this->get_meta() => array(
				$field,
				$criteria,
			),
		);
	}

	/**
	 * Retrieve post IDs matching the SEO field empty/not-empty condition.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_posts( $fields ) {

		$seo_field = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';
		$criteria  = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';

		$column = $this->get_column( $seo_field );

		if ( null === $column || empty( $criteria ) ) {
			return array();
		}

		global $wpdb;

		$table = $wpdb->prefix . 'aioseo_posts';

		// Verify the AIOSEO table exists.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( null === $table_exists ) {
			return array();
		}

		if ( 'is-empty' === $criteria ) {
			$query = 'SELECT ap.post_id FROM `' . esc_sql( $table ) . "` ap WHERE ap.`" . esc_sql( $column ) . "` IS NULL OR ap.`" . esc_sql( $column ) . "` = ''"; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		} else {
			$query = 'SELECT ap.post_id FROM `' . esc_sql( $table ) . "` ap WHERE ap.`" . esc_sql( $column ) . "` IS NOT NULL AND ap.`" . esc_sql( $column ) . "` != ''"; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		$results = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		return (array) array_column( $results, 'post_id' );
	}

	/**
	 * Get available SEO fields.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_seo_fields() {
		return array(
			array(
				'text'  => esc_attr_x( 'SEO title', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'seo_title',
			),
			array(
				'text'  => esc_attr_x( 'SEO description', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'seo_description',
			),
			array(
				'text'  => esc_attr_x( 'Canonical URL', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'canonical_url',
			),
			array(
				'text'  => esc_attr_x( 'Open Graph title', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'og_title',
			),
			array(
				'text'  => esc_attr_x( 'Open Graph description', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'og_description',
			),
		);
	}

	/**
	 * Map a field slug to its AIOSEO database column name.
	 *
	 * @param string $field The field slug.
	 *
	 * @return string|null The column name, or null if invalid.
	 */
	private function get_column( $field ) {

		$columns = array(
			'seo_title'       => 'title',
			'seo_description' => 'description',
			'canonical_url'   => 'canonical_url',
			'og_title'        => 'og_title',
			'og_description'  => 'og_description',
		);

		return isset( $columns[ $field ] ) ? $columns[ $field ] : null;
	}
}
