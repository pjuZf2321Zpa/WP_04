<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AIOSEO_POST_SEO_SCORE_MEETS_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
final class AIOSEO_POST_SEO_SCORE_MEETS_CONDITION extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AIOSEO' );
		$this->set_meta( 'AIOSEO_POST_SEO_SCORE_MEETS_CONDITION' );
		$this->set_sentence( esc_html_x( "A post's SEO score meets {{a condition}}", 'All in One SEO', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				// translators: %1$s: Condition, %2$s: Score value.
				esc_html_x( "A post's SEO score {{is:%1\$s}} {{a value:%2\$s}}", 'All in One SEO', 'uncanny-automator-pro' ),
				'CONDITION',
				'SCORE_VALUE'
			)
		);
		$this->set_loop_type( 'posts' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_posts' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		$condition = array(
			'option_code'     => 'CONDITION',
			'type'            => 'select',
			'label'           => esc_html_x( 'Condition', 'All in One SEO', 'uncanny-automator-pro' ),
			'required'        => true,
			'options'         => $this->get_conditions(),
			'options_show_id' => false,
		);

		$score_value = array(
			'option_code' => 'SCORE_VALUE',
			'type'        => 'text',
			'label'       => esc_html_x( 'Score', 'All in One SEO', 'uncanny-automator-pro' ),
			'required'    => true,
			'description' => esc_html_x( 'Enter a value between 0 and 100.', 'All in One SEO', 'uncanny-automator-pro' ),
		);

		return array(
			$this->get_meta() => array(
				$condition,
				$score_value,
			),
		);
	}

	/**
	 * Retrieve post IDs matching the SEO score condition.
	 *
	 * Queries the AIOSEO posts table directly for performance.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_posts( $fields ) {

		$condition   = isset( $fields['CONDITION'] ) ? $fields['CONDITION'] : '';
		$score_value = isset( $fields['SCORE_VALUE'] ) ? trim( $fields['SCORE_VALUE'] ) : '';
		$symbol      = $this->create_symbol( $condition );

		if ( empty( $condition ) || 0 === strlen( $score_value ) || null === $symbol ) {
			return array();
		}

		if ( ! is_numeric( $score_value ) ) {
			return array();
		}

		global $wpdb;

		$table = $wpdb->prefix . 'aioseo_posts';

		// Verify the AIOSEO table exists.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( null === $table_exists ) {
			return array();
		}

		$query = $wpdb->prepare(
			'SELECT ap.post_id FROM `' . esc_sql( $table ) . '` ap WHERE ap.seo_score ' . $symbol . ' %d', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			(int) $score_value
		);

		$results = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		return (array) array_column( $results, 'post_id' );
	}

	/**
	 * Get available comparison conditions.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_conditions() {
		return array(
			array(
				'text'  => esc_attr_x( 'equal to', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'is',
			),
			array(
				'text'  => esc_attr_x( 'not equal to', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'is-not',
			),
			array(
				'text'  => esc_attr_x( 'less than', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'less-than',
			),
			array(
				'text'  => esc_attr_x( 'greater than', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'greater-than',
			),
			array(
				'text'  => esc_attr_x( 'greater than or equal to', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'greater-than-or-equal-to',
			),
			array(
				'text'  => esc_attr_x( 'less than or equal to', 'All in One SEO', 'uncanny-automator-pro' ),
				'value' => 'less-than-or-equal-to',
			),
		);
	}

	/**
	 * Convert a condition slug to its SQL operator.
	 *
	 * @param string $condition The condition slug.
	 *
	 * @return string|null The SQL operator, or null if invalid.
	 */
	private function create_symbol( $condition ) {

		$symbols = array(
			'is'                       => '=',
			'is-not'                   => '!=',
			'less-than'                => '<',
			'greater-than'             => '>',
			'less-than-or-equal-to'    => '<=',
			'greater-than-or-equal-to' => '>=',
		);

		return isset( $symbols[ $condition ] ) ? $symbols[ $condition ] : null;
	}
}
