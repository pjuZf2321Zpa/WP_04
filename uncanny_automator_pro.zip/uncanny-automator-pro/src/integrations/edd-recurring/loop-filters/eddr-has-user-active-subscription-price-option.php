<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use EDD_Subscriptions_DB;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class EDDR_HAS_USER_ACTIVE_SUBSCRIPTION_PRICE_OPTION
 *
 * Loop filter: The user {{has/does not have}} an active subscription for {{a price option}} of {{a download}}.
 *
 * @package Uncanny_Automator_Pro
 */
class EDDR_HAS_USER_ACTIVE_SUBSCRIPTION_PRICE_OPTION extends Loop_Filter {

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function setup() {

		$this->register_hooks();

		$this->set_integration( 'EDD_RECURRING' );
		$this->set_meta( 'EDDR_HAS_USER_ACTIVE_SUBSCRIPTION_PRICE_OPTION' );

		$this->set_sentence( esc_html_x( 'The user {{has/does not have}} an active subscription for {{a price option}} of {{a download}}', 'EDD - Recurring Payments', 'uncanny-automator-pro' ) );

		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Price option, %3$s: Download */
				esc_html_x( 'The user {{has/does not have:%1$s}} an active subscription for {{a price option:%2$s}} of {{a download:%3$s}}', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
				'CRITERIA',
				'EDDPRICEOPTION',
				'EDDPRODUCT'
			)
		);

		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_users_with_active_subscription' ) );
		$this->set_loop_type( 'users' );
	}

	/**
	 * Check if EDD Recurring is active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return class_exists( '\EDD_Recurring' );
	}

	/**
	 * Wire the AJAX endpoint that loads recurring price options for the selected download.
	 *
	 * Guarded against double-registration because this filter is instantiated both
	 * by the auto-loader and by the integration's load() method.
	 *
	 * @return void
	 */
	protected function register_hooks() {
		if ( false !== has_action( 'wp_ajax_automator_pro_eddr_loop_filter_price_options' ) ) {
			return;
		}
		add_action( 'wp_ajax_automator_pro_eddr_loop_filter_price_options', array( $this, 'price_options_ajax_handler' ) );
	}

	/**
	 * AJAX handler: returns the recurring-capable price options for the selected EDD
	 * download, preceded by an "Any price option" entry. Non-recurring price options
	 * are filtered out so the dropdown only surfaces choices that can produce subscriptions.
	 *
	 * @return void
	 */
	public function price_options_ajax_handler() {

		Automator()->utilities->ajax_auth_check();

		$values      = filter_input( INPUT_POST, 'values', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$download_id = isset( $values['EDDPRODUCT']['value'] ) ? $values['EDDPRODUCT']['value'] : 0;

		wp_send_json(
			array(
				'success' => true,
				'options' => $this->get_recurring_price_options( $download_id ),
			)
		);
	}

	/**
	 * Build the recurring-only price option dropdown list for a download.
	 *
	 * @param int|string $download_id
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_recurring_price_options( $download_id ) {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any price option', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
			),
		);

		$download_id = absint( $download_id );

		if ( $download_id <= 0 || ! function_exists( 'edd_has_variable_prices' ) ) {
			return $options;
		}

		// Whole-product recurring: every price option behaves as recurring.
		$whole_product_recurring = function_exists( 'edd_recurring' ) && edd_recurring()->is_recurring( $download_id );

		if ( ! edd_has_variable_prices( $download_id ) ) {
			return $options;
		}

		$variable_prices = edd_get_variable_prices( $download_id );

		if ( empty( $variable_prices ) ) {
			return $options;
		}

		foreach ( $variable_prices as $price_id => $price ) {

			$is_recurring_price = isset( $price['recurring'] ) && 'yes' === $price['recurring'];

			if ( ! $whole_product_recurring && ! $is_recurring_price ) {
				continue;
			}

			$name = isset( $price['name'] ) ? esc_html( $price['name'] ) : sprintf(
				/* translators: %d is the price option ID */
				esc_html_x( 'Price option %d', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
				$price_id
			);
			$options[] = array(
				'value' => (string) $price_id,
				'text'  => $name,
			);
		}

		return $options;
	}

	/**
	 * @return mixed[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
					'options'               => array(
						array(
							'text'  => esc_html_x( 'has', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
							'value' => 'has',
						),
						array(
							'text'  => esc_html_x( 'does not have', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
							'value' => 'does-not-have',
						),
					),
				),
				array(
					'option_code'           => 'EDDPRODUCT',
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Download', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
					'options'               => $this->get_recurring_download_options(),
					'supports_custom_value' => false,
				),
				array(
					'option_code'           => 'EDDPRICEOPTION',
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Price option', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
					'options'               => array(),
					'supports_custom_value' => false,
					'ajax'                  => array(
						'event'         => 'parent_fields_change',
						'endpoint'      => 'automator_pro_eddr_loop_filter_price_options',
						'listen_fields' => array( 'EDDPRODUCT' ),
					),
				),
			),
		);
	}

	/**
	 * Build list of EDD downloads that support recurring billing.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_recurring_download_options() {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any download', 'EDD - Recurring Payments', 'uncanny-automator-pro' ),
			),
		);

		$downloads = get_posts(
			array(
				'post_type'      => 'download',
				'posts_per_page' => 9999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
			)
		);

		foreach ( $downloads as $download ) {

			$download_id = $download->ID;

			if ( edd_recurring()->is_recurring( $download_id ) ) {
				$options[] = array(
					'value' => (string) $download_id,
					'text'  => $download->post_title,
				);
				continue;
			}

			if ( ! edd_has_variable_prices( $download_id ) ) {
				continue;
			}

			$variable_prices = edd_get_variable_prices( $download_id );

			if ( empty( $variable_prices ) ) {
				continue;
			}

			foreach ( $variable_prices as $price ) {
				if ( isset( $price['recurring'] ) && 'yes' === $price['recurring'] ) {
					$options[] = array(
						'value' => (string) $download_id,
						'text'  => $download->post_title,
					);
					break;
				}
			}
		}

		return $options;
	}

	/**
	 * @param array{EDDPRODUCT:string,EDDPRICEOPTION:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_users_with_active_subscription( $fields ) {

		$criteria        = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$download_id     = isset( $fields['EDDPRODUCT'] ) ? $fields['EDDPRODUCT'] : '';
		$price_option_id = isset( $fields['EDDPRICEOPTION'] ) ? $fields['EDDPRICEOPTION'] : '';

		if ( empty( $criteria ) || '' === $download_id || '' === $price_option_id ) {
			return array();
		}

		$subscriber_ids = $this->get_active_subscriber_ids( $download_id, $price_option_id );

		if ( 'does-not-have' === $criteria ) {
			return $this->get_users_without_subscription( $subscriber_ids );
		}

		return $subscriber_ids;
	}

	/**
	 * @param int|string $download_id
	 * @param int|string $price_option_id
	 *
	 * @return int[]
	 */
	private function get_active_subscriber_ids( $download_id, $price_option_id ) {

		$args = array(
			'status' => array( 'active', 'trialling' ),
			'number' => -1,
		);

		if ( -1 !== intval( $download_id ) ) {
			$args['product_id'] = absint( $download_id );
		}

		if ( -1 !== intval( $price_option_id ) ) {
			$args['price_id'] = absint( $price_option_id );
		}

		$subs_db = new EDD_Subscriptions_DB();

		$subscriptions = $subs_db->get_subscriptions( $args );

		if ( empty( $subscriptions ) ) {
			return array();
		}

		$user_ids = array();
		foreach ( $subscriptions as $subscription ) {
			$customer_id = isset( $subscription->customer_id ) ? absint( $subscription->customer_id ) : 0;
			if ( ! $customer_id ) {
				continue;
			}
			$customer = $subscription->customer;
			if ( $customer && $customer->user_id ) {
				$user_ids[] = absint( $customer->user_id );
			}
		}

		return array_values( array_unique( array_filter( $user_ids ) ) );
	}

	/**
	 * @param int[] $subscriber_ids
	 *
	 * @return int[]
	 */
	private function get_users_without_subscription( $subscriber_ids ) {

		$all_users = new \WP_User_Query(
			array(
				'cache_results' => false,
				'fields'        => 'ID',
			)
		);

		$all_user_ids = $all_users->get_results();

		if ( empty( $subscriber_ids ) ) {
			return $all_user_ids;
		}

		return array_values( array_diff( $all_user_ids, $subscriber_ids ) );
	}
}
