<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Edd_Recurring_Integration\Edd_Recurring_Integration' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator\Integrations\Edd_Recurring_Integration\Edd_Recurring_Helpers' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\Edd_Recurring_Integration\Edd_Recurring_Integration();
