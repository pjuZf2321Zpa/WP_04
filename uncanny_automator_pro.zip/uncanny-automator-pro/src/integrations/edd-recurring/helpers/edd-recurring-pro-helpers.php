<?php

namespace Uncanny_Automator_Pro\Integrations\Edd_Recurring_Integration;

use Uncanny_Automator\Integrations\Edd_Recurring_Integration\Edd_Recurring_Helpers;

/**
 * Class Edd_Recurring_Pro_Helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Edd_Recurring_Integration
 */
class Edd_Recurring_Pro_Helpers extends Edd_Recurring_Helpers {
}
