<?php

namespace Uncanny_Automator_Pro\Integrations\Beaver_Builder;

use Uncanny_Automator\App\Transports\Restful\Remote_Data\Remote_Data_Request;
use Uncanny_Automator\Integrations\Beaver_Builder\Beaver_Builder_Helpers;
use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;

/**
 * Class Beaver_Builder_Pro_Helpers
 *
 * Composes Free's Beaver_Builder_Helpers via $base. The anonymous form triggers
 * add no Pro-specific logic, so this class is purely a decoupling seam: the
 * delegation block below is Pro's explicit contract with Free — any Free rename
 * that breaks a line here surfaces as a PHPStan failure in Pro CI rather than a
 * production fatal. Pro recipe parts never reach around $this->base into Free's
 * concrete helper.
 *
 * @package Uncanny_Automator_Pro\Integrations\Beaver_Builder
 *
 * @property Beaver_Builder_Helpers $base
 */
class Beaver_Builder_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * "Any" sentinel for the form selector (mirrors Free's constant so Pro
	 * recipe parts reference this class, not Free's).
	 */
	const ANY_VALUE = '-1';

	/**
	 * Compose the Free helper.
	 */
	public function __construct() {
		$this->base = new Beaver_Builder_Helpers();
	}

	// =========================================================================
	// Delegation block — Pro's explicit contract with Free.
	// =========================================================================

	/**
	 * Delegates to Free's contact_form_tokens().
	 *
	 * @return array<int,array{tokenId:string,tokenName:string,tokenType:string}>
	 */
	public function contact_form_tokens() {
		return $this->base->contact_form_tokens();
	}

	/**
	 * Delegates to Free's subscribe_form_tokens().
	 *
	 * @return array<int,array{tokenId:string,tokenName:string,tokenType:string}>
	 */
	public function subscribe_form_tokens() {
		return $this->base->subscribe_form_tokens();
	}

	/**
	 * Delegates to Free's hydrate_contact_form_tokens().
	 *
	 * @param array $hook_args
	 *
	 * @return array<string,mixed>
	 */
	public function hydrate_contact_form_tokens( $hook_args ) {
		return $this->base->hydrate_contact_form_tokens( $hook_args );
	}

	/**
	 * Delegates to Free's hydrate_subscribe_form_tokens().
	 *
	 * @param array $hook_args
	 *
	 * @return array<string,mixed>
	 */
	public function hydrate_subscribe_form_tokens( $hook_args ) {
		return $this->base->hydrate_subscribe_form_tokens( $hook_args );
	}

	// =========================================================================
	// Remote_Data dispatcher — Pro and Free share the `beaver_builder`
	// remote_data_id, so Pro's helper is what the REST resolver returns
	// (registered last). Forward every dispatch to Free so the existing
	// remote_data_get_* handlers (contact_forms / subscribe_forms) keep working
	// for Pro's recipe parts.
	// =========================================================================

	/**
	 * Forward remote-data dispatch to the composed Free helper.
	 *
	 * @param string              $data
	 * @param Remote_Data_Request $request
	 *
	 * @return array
	 */
	public function process_remote_data_request( string $data, Remote_Data_Request $request ): array {
		return $this->base->process_remote_data_request( $data, $request );
	}
}
