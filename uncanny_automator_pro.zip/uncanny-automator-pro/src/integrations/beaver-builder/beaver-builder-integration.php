<?php

namespace Uncanny_Automator_Pro\Integrations\Beaver_Builder;

/**
 * Class Beaver_Builder_Integration
 *
 * Pro side of the Beaver Builder integration — the anonymous ("Everyone") form
 * trigger variants. Pro composes Free's helper through Beaver_Builder_Pro_Helpers
 * (extends Abstract_Pro_Helpers, wraps Free's token/hydrate methods via $base and
 * forwards the shared remote-data segments) rather than reaching into Free's
 * concrete helper directly.
 *
 * @package Uncanny_Automator_Pro
 */
class Beaver_Builder_Integration extends \Uncanny_Automator\Integration {

	/**
	 * @return void
	 */
	protected function setup() {
		$this->helpers = new Beaver_Builder_Pro_Helpers();
		$this->set_integration( 'BEAVER_BUILDER' );
		$this->set_name( 'Beaver Builder' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/beaver-builder-icon.svg' );

		$this->set_plugin_file_path( 'beaver-builder-lite-version/fl-builder.php' );
		$this->set_developer_name( 'The Beaver Builder Team' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * @return void
	 */
	public function load() {
		// Anonymous ("Everyone") trigger variants.
		new Bb_Anon_Subscribe_Form_Submitted( $this->helpers );
		new Bb_Anon_Contact_Form_Submitted( $this->helpers );
	}

	/**
	 * @return bool
	 */
	public function plugin_active() {
		return defined( 'FL_BUILDER_VERSION' );
	}
}
