<?php
if ( ! defined( 'ABSPATH' ) ) {
	return;
}
if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Beaver_Builder\Beaver_Builder_Integration' ) ) {
	return;
}
new Uncanny_Automator_Pro\Integrations\Beaver_Builder\Beaver_Builder_Integration();
