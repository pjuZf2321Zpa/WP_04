<?php

namespace Uncanny_Automator_Pro;

/**
 * Class DATETIME_IS_BETWEEN_SPECIFIC_DATETIMES
 *
 * @package Uncanny_Automator_Pro
 */
class DATETIME_IS_BETWEEN_SPECIFIC_DATETIMES extends Action_Condition {

	/**
	 * Method define_condition
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'DATETIME';
		$this->name         = esc_html_x( '{{The date and time}} {{is}} between {{a specific date and time}} and {{a specific date and time}}', 'Date and time', 'uncanny-automator-pro' );
		$this->code         = 'IS_BETWEEN_SPECIFIC_DATETIMES';
		$this->dynamic_name = sprintf(
			/* translators: 1. Date and time 2. Criteria 3. Date and time 4. Date and time */
			esc_html_x( '{{The date and time:%1$s}} {{is:%2$s}} between {{a specific date and time:%3$s}} and {{a specific date and time:%4$s}}', 'Date and time', 'uncanny-automator-pro' ),
			'DATETIME_A',
			'CRITERIA',
			'DATETIME_B',
			'DATETIME_C'
		);
		$this->requires_user = false;
	}

	/**
	 * Method fields
	 *
	 * @return array
	 */
	public function fields() {

		$conditions = array(
			'option_code'           => 'CRITERIA',
			'label'                 => esc_html_x( 'Criteria', 'Date and time', 'uncanny-automator-pro' ),
			'required'              => true,
			'options'               => array(
				array(
					'value' => 'is',
					'text'  => esc_html_x( 'is', 'Date and time', 'uncanny-automator-pro' ),
				),
				array(
					'value' => 'is_not',
					'text'  => esc_html_x( 'is not', 'Date and time', 'uncanny-automator-pro' ),
				),
			),
			'supports_custom_value' => false,
		);

		return array(
			// Token field.
			$this->field->text(
				array(
					'option_code' => 'DATETIME_A',
					'label'       => esc_html_x( 'Date and time', 'Date and time', 'uncanny-automator-pro' ),
					'placeholder' => '{{current_date_and_time}}',
					'default'     => '{{current_date_and_time}}',
					'input_type'  => 'text',
					'required'    => true,
				)
			),
			// Criteria field.
			$this->field->select_field_args( $conditions ),
			// Value fields.
			$this->field->text(
				array(
					'option_code' => 'DATETIME_B',
					'label'       => esc_html_x( 'Start date and time', 'Date and time', 'uncanny-automator-pro' ),
					'input_type'  => 'text',
					'required'    => true,
				)
			),
			$this->field->text(
				array(
					'option_code' => 'DATETIME_C',
					'label'       => esc_html_x( 'End date and time', 'Date and time', 'uncanny-automator-pro' ),
					'input_type'  => 'text',
					'required'    => true,
				)
			),
		);
	}

	/**
	 * Evaluate_condition
	 *
	 * Has to use the $this->condition_failed( $message ); method if the condition is not met.
	 *
	 * @return void
	 * @throws \Exception
	 */
	public function evaluate_condition() {

		try {
			$input      = $this->get_parsed_option( 'DATETIME_A' );
			$datetime_a = DateTime_Helpers::date_object( $input );
			$datetime_b = DateTime_Helpers::date_object( $this->get_parsed_option( 'DATETIME_B' ) );
			$datetime_c = DateTime_Helpers::date_object( $this->get_parsed_option( 'DATETIME_C' ) );
		} catch ( \Exception $e ) {
			$this->condition_failed( $e->getMessage() );
			return;
		}

		$criteria = $this->get_parsed_option( 'CRITERIA' );

		$date_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

		$error = $input . ' %s ' . $datetime_b->format( $date_format ) . ' %s ' . $datetime_c->format( $date_format );

		// If DATETIME_B > DATETIME_C (inverted range), the 'is' case never passes by design — the condition
		// acts as a no-op for misconfigured ranges rather than wrapping around midnight or dates.
		switch ( $criteria ) {
			case 'is':
				if ( ( $datetime_a != $datetime_b && $datetime_a < $datetime_b ) || ( $datetime_a != $datetime_c && $datetime_a > $datetime_c ) ) { // phpcs:ignore Universal.Operators.StrictComparisons
					$this->condition_failed( sprintf( $error, esc_html_x( ' is not between', 'Date and time', 'uncanny-automator-pro' ), esc_html_x( ' and ', 'Date and time', 'uncanny-automator-pro' ) ) );
				}
				break;
			case 'is_not':
				if ( $datetime_a == $datetime_b || $datetime_a == $datetime_c || ( $datetime_a > $datetime_b && $datetime_a < $datetime_c ) ) { // phpcs:ignore Universal.Operators.StrictComparisons
					$this->condition_failed( sprintf( $error, esc_html_x( ' is between', 'Date and time', 'uncanny-automator-pro' ), esc_html_x( ' and ', 'Date and time', 'uncanny-automator-pro' ) ) );
				}
				break;
		}
	}
}
