<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName

namespace Uncanny_Automator_Pro;

/**
 * Class DateTime_Helpers
 *
 * @package Uncanny_Automator
 */
class DateTime_Helpers {

	/**
	 * Parse an arbitrary user- or token-supplied date/time string into a
	 * \DateTime in the site timezone.
	 *
	 * Accepts Unix timestamps, ISO Y-m-d, English/relative strings
	 * (e.g. "Monday", "tomorrow", "3:15 PM September 6, 2022"), the
	 * configured WordPress date_format/time_format combination, and
	 * localized strings via IntlDateFormatter when available.
	 *
	 * @param mixed $input The value to parse.
	 *
	 * @return \DateTime
	 * @throws \Exception When the input is empty or unparseable.
	 */
	public static function date_object( $input ) {

		$timezone = wp_timezone();

		// Reject empty/whitespace input. An unresolved token parses to an empty
		// string, and \DateTime's constructor would silently treat that as "now",
		// causing filters to evaluate against the current moment instead of
		// surfacing the missing data. Fail loudly instead.
		if ( ! is_numeric( $input ) && ( ! is_string( $input ) || '' === trim( $input ) ) ) {
			throw new \Exception( esc_html_x( 'Unable to parse the date. The input was empty.', 'Date and time', 'uncanny-automator-pro' ) );
		}

		// Timestamp.
		if ( is_numeric( $input ) ) {
			return ( new \DateTime() )->setTimestamp( (int) $input )->setTimezone( $timezone );
		}

		// ISO format (how dates are stored in DB).
		$date = \DateTime::createFromFormat( 'Y-m-d', $input, $timezone );
		if ( false !== $date ) {
			return $date;
		}

		// Parse English/relative formats (e.g. "Monday", "now", "April 6, 2026 8:30 am")
		// in the site timezone. Using strtotime() + setTimezone() is incorrect because
		// WordPress forces PHP's default timezone to UTC, so wall-clock strings would be
		// anchored to UTC and then shifted into the site timezone, landing on the wrong
		// calendar day at boundary hours.
		try {
			return new \DateTime( $input, $timezone );
		} catch ( \Exception $e ) {
			// Fall through to later parsers.
			unset( $e );
		}

		// WordPress configured format.
		$wp_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		$date      = \DateTime::createFromFormat( $wp_format, $input, $timezone );
		if ( false !== $date ) {
			return $date;
		}

		// IntlDateFormatter for localized strings.
		if ( class_exists( 'IntlDateFormatter' ) ) {
			$date = self::parse_with_intl( $input, $timezone );
			if ( null !== $date ) {
				return $date;
			}
		}

		throw new \Exception( esc_html_x( 'Unable to parse the date. The PHP intl extension may be required for non-English dates.', 'Date and time', 'uncanny-automator-pro' ) );
	}

	/**
	 * Cached IntlDateFormatter instances.
	 *
	 * @var array
	 */
	private static $intl_formatters = array();

	/**
	 * Parse a localized date string using IntlDateFormatter.
	 *
	 * @param string        $input    The date string.
	 * @param \DateTimeZone $timezone The timezone.
	 *
	 * @return \DateTime|null
	 */
	private static function parse_with_intl( $input, $timezone ) {

		if ( empty( $input ) || ! is_string( $input ) ) {
			return null;
		}

		$locale    = get_locale();
		$cache_key = $locale . '_' . $timezone->getName();

		if ( ! isset( self::$intl_formatters[ $cache_key ] ) ) {
			self::$intl_formatters[ $cache_key ] = array();
			$date_types                          = array( \IntlDateFormatter::LONG, \IntlDateFormatter::MEDIUM, \IntlDateFormatter::SHORT );
			$time_types                          = array( \IntlDateFormatter::SHORT, \IntlDateFormatter::MEDIUM, \IntlDateFormatter::NONE );

			foreach ( $date_types as $date_type ) {
				foreach ( $time_types as $time_type ) {
					$formatter = new \IntlDateFormatter( $locale, $date_type, $time_type, $timezone );
					$formatter->setLenient( true );
					self::$intl_formatters[ $cache_key ][] = $formatter;
				}
			}
		}

		foreach ( self::$intl_formatters[ $cache_key ] as $formatter ) {
			$timestamp = $formatter->parse( $input );
			if ( false !== $timestamp ) {
				return ( new \DateTime() )->setTimestamp( (int) $timestamp )->setTimezone( $timezone );
			}
		}

		return null;
	}

	/**
	 * Parse the input and normalize the time-of-day to noon so that date-level
	 * comparisons (is / is_before / is_after) are insensitive to hour drift.
	 *
	 * @param mixed $input The value to parse.
	 *
	 * @return \DateTime
	 * @throws \Exception When the input is empty or unparseable.
	 */
	public static function get_date( $input ) {
		$date = self::date_object( $input );
		$date->setTime( 12, 0, 0 );
		return $date;
	}

	/**
	 * Parse the input and zero out the date portion so that only the
	 * time-of-day is significant for comparison.
	 *
	 * @param mixed $input The value to parse.
	 *
	 * @return \DateTime
	 * @throws \Exception When the input is empty or unparseable.
	 */
	public static function get_time( $input ) {
		$date = self::date_object( $input );
		$date->setDate( 0, 0, 0 );
		return $date;
	}

	/**
	 * Get the day-of-week index for the given input, normalized to the
	 * WordPress start_of_week setting (0-based, starting on start_of_week).
	 *
	 * @param mixed $input The value to parse.
	 *
	 * @return int 0..6, where 0 corresponds to start_of_week.
	 * @throws \Exception When the input is empty or unparseable.
	 */
	public static function get_weekday( $input ) {

		$format = 'w'; // 0 (for Sunday) through 6 (for Saturday)

		$date = self::date_object( $input );
		$day  = (int) $date->format( $format );

		return self::shift_weekday( $day );
	}

	/**
	 * Normalize a day-of-week value into a 0-based index relative to the
	 * WordPress start_of_week setting.
	 *
	 * Accepts two different input ranges and treats them uniformly:
	 *   - PHP 'w' format: 0 = Sunday .. 6 = Saturday (used by get_weekday()).
	 *   - DATETIME_IS_SPECIFIC_WEEKDAY dropdown: 1 = Monday .. 7 = Sunday.
	 *
	 * The modulo ensures both ranges collapse to the same normalized index
	 * for every day regardless of start_of_week. Prior to this, a naive
	 * subtract-with-wrap produced an out-of-range 7 for dropdown Sunday on
	 * sites configured with start_of_week = 0 (Sunday-first week), silently
	 * breaking every comparison against Sunday.
	 *
	 * @param int $day A day-of-week value in either 0..6 or 1..7.
	 *
	 * @return int 0..6.
	 */
	public static function shift_weekday( $day ) {

		$start_of_week = (int) get_option( 'start_of_week', '1' );

		return ( $day - $start_of_week + 7 ) % 7;
	}

	/**
	 * Get the month number (1..12) for the given input. Short numeric inputs
	 * (1..11) are treated as month numbers directly; anything else is parsed
	 * as a date string.
	 *
	 * @param mixed $input The value to parse.
	 *
	 * @return int 1..12.
	 * @throws \Exception When the input is empty or unparseable.
	 */
	public static function get_month( $input ) {

		if ( is_numeric( $input ) ) {
			$intval = intval( $input );
			if ( $intval > 0 && $intval <= 12 ) {
				return $intval;
			}
		}

		$date  = self::date_object( $input );
		$month = (int) $date->format( 'n' );
		return $month;
	}

	/**
	 * Get the day-of-month (1..31) for the given input.
	 *
	 * @param mixed $input The value to parse.
	 *
	 * @return int 1..31.
	 * @throws \Exception When the input is empty or unparseable.
	 */
	public static function get_month_day( $input ) {
		$date = self::date_object( $input );
		$day  = (int) $date->format( 'j' );
		return $day;
	}
}
