<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator\Integrations\DateTime\DateTime_Integration' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\DateTime\DateTime_Pro_Integration' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\DateTime\DateTime_Pro_Integration();
