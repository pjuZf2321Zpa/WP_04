<?php

namespace Uncanny_Automator_Pro\Integrations\DateTime;

/**
 * Class DateTime_Pro_Integration
 *
 * @package Uncanny_Automator_Pro
 */
class DateTime_Pro_Integration extends \Uncanny_Automator\Integration {

	/**
	 * Setup integration.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->set_integration( 'DATETIME' );
		$this->set_name( 'Date and time' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/date-time-icon.svg' );

		$this->set_plugin_file_path( 'uncanny-automator/uncanny-automator.php' );
		$this->set_developer_name( 'Uncanny Automator' );
		$this->set_integration_type( 'built-in' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * Load pro components.
	 *
	 * @return void
	 */
	protected function load() {
		// Helper.
		new \Uncanny_Automator_Pro\DateTime_Helpers();

		// Actions.
		new \Uncanny_Automator_Pro\UOA_APPLY_DATETIME_MODIFIER();
		new \Uncanny_Automator_Pro\UOA_GENERATE_NEW_DATE();
		new \Uncanny_Automator_Pro\UOA_GENERATE_NEW_DATETIME();

		// Conditions.
		new \Uncanny_Automator_Pro\DATETIME_IS_BETWEEN_SPECIFIC_DATES();
		new \Uncanny_Automator_Pro\DATETIME_IS_BETWEEN_SPECIFIC_DATETIMES();
		new \Uncanny_Automator_Pro\DATETIME_IS_BETWEEN_SPECIFIC_TIMES();
		new \Uncanny_Automator_Pro\DATETIME_IS_SPECIFIC_DATE();
		new \Uncanny_Automator_Pro\DATETIME_IS_SPECIFIC_MONTH_DAY();
		new \Uncanny_Automator_Pro\DATETIME_IS_SPECIFIC_MONTH();
		new \Uncanny_Automator_Pro\DATETIME_IS_SPECIFIC_TIME();
		new \Uncanny_Automator_Pro\DATETIME_IS_SPECIFIC_WEEKDAY();
	}

	/**
	 * Plugin active check.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return true;
	}
}
