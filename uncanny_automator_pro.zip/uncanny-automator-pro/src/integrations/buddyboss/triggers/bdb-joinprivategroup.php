<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Recipe\Trigger;

/**
 * Class BDB_JOINPRIVATEGROUP
 *
 * "A user joins a private group". Hooks come from definition(), so a recipe saved
 * with the old `automator_groups_join_group` hook in its add_action postmeta
 * still listens on `groups_join_group`. That bridge is fired by BuddyPress Pro's
 * helper, which only loads when a recipe uses a BuddyPress item.
 *
 * Namespace and class name stay flat: BuddyBoss is a shared integration, and the
 * gated loader resolves Pro's files in it as `Uncanny_Automator_Pro\{CLASS}`.
 *
 * @package Uncanny_Automator_Pro
 */
class BDB_JOINPRIVATEGROUP extends Trigger {

	/**
	 * Static definition — opts the trigger into code-defined hooks.
	 *
	 * @return \Uncanny_Automator\Recipe\Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'BDBJOINPRIVATEGROUP', 'BDB' )
			->trigger_meta( 'BDBGROUPS' )
			->hook( 'groups_membership_accepted', 60, 3 )
			->hook( 'groups_accept_invite', 60, 3 )
			->hook( 'groups_join_group', 60, 2 );
	}

	/**
	 * Sets up the trigger sentences and flags.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );

		// Admins and recipes add members, so the joining user is rarely the one logged in.
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				// translators: %1$s is a private group
				esc_html_x( 'A user joins {{a private group:%1$s}}', 'BuddyBoss', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence( esc_html_x( 'A user joins {{a private group}}', 'BuddyBoss', 'uncanny-automator-pro' ) );
	}

	/**
	 * Defines the private group field.
	 *
	 * @return array
	 */
	public function options() {

		$field = Automator()->helpers->recipe->buddyboss->options->all_buddyboss_groups(
			esc_html_x( 'Private group', 'BuddyBoss', 'uncanny-automator-pro' ),
			$this->get_trigger_meta(),
			array(
				'uo_include_any' => true,
				'uo_any_label'   => esc_html_x( 'Any private group', 'BuddyBoss', 'uncanny-automator-pro' ),
				'status'         => array( 'private' ),
			)
		);

		$field['options'] = automator_array_as_options( $field['options'] );

		return array( $field );
	}

	/**
	 * Defines the group token.
	 *
	 * @param array $trigger The trigger.
	 * @param array $tokens  The tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {

		return array_merge(
			$tokens,
			array(
				array(
					'tokenId'   => 'BDBGROUPS',
					'tokenName' => esc_html_x( 'Private group', 'BuddyBoss', 'uncanny-automator-pro' ),
					'tokenType' => 'text',
				),
			)
		);
	}

	/**
	 * Matches a join to a private group against the selected group.
	 *
	 * @param array $trigger   The trigger.
	 * @param array $hook_args The hook arguments.
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		if ( ! isset( $trigger['meta'][ $this->get_trigger_meta() ] ) ) {
			return false;
		}

		list( $user_id, $group_id ) = $this->get_user_and_group( $hook_args );

		if ( 0 >= $user_id || 0 >= $group_id ) {
			return false;
		}

		$selected = (string) $trigger['meta'][ $this->get_trigger_meta() ];

		if ( '-1' !== $selected && (int) $selected !== $group_id ) {
			return false;
		}

		$group = groups_get_group( $group_id );

		if ( empty( $group->id ) || 'private' !== $group->status ) {
			return false;
		}

		$this->set_user_id( $user_id );

		return true;
	}

	/**
	 * Hydrates the group token with the joined group's name.
	 *
	 * @param array $trigger   The trigger.
	 * @param array $hook_args The hook arguments.
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( , $group_id ) = $this->get_user_and_group( $hook_args );

		$group = groups_get_group( $group_id );

		return array(
			'BDBGROUPS' => isset( $group->name ) ? $group->name : '',
		);
	}

	/**
	 * Reads the user and group IDs in the order the current hook passes them.
	 *
	 * `groups_join_group` passes ( $group_id, $user_id ); the accept hooks pass
	 * ( $user_id, $group_id, … ).
	 *
	 * @param array $hook_args The hook arguments.
	 *
	 * @return int[] The user ID and the group ID, 0 when not a positive ID.
	 */
	private function get_user_and_group( $hook_args ) {

		$first  = isset( $hook_args[0] ) ? $hook_args[0] : 0;
		$second = isset( $hook_args[1] ) ? $hook_args[1] : 0;

		if ( 'groups_join_group' === current_action() ) {
			list( $first, $second ) = array( $second, $first );
		}

		return array(
			is_numeric( $first ) ? (int) $first : 0,
			is_numeric( $second ) ? (int) $second : 0,
		);
	}
}
