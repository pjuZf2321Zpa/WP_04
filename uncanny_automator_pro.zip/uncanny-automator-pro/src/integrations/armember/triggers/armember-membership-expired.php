<?php

namespace Uncanny_Automator_Pro\Integrations\Armember;

use Uncanny_Automator\Integrations\Armember\Armember_Helpers;
use Uncanny_Automator\Recipe\Trigger;

/**
 * Class ARMEMBER_MEMBERSHIP_EXPIRED
 *
 * @package Uncanny_Automator_Pro
 *
 * @property Armember_Helpers $item_helpers
 */
class ARMEMBER_MEMBERSHIP_EXPIRED extends Trigger {

	/**
	 * Declare the trigger so the engine can register its hook without
	 * constructing the class on every frontend request.
	 *
	 * ARMember's expiry cron calls `arm_user_plan_status_action()`, which
	 * fires `arm_user_plan_status_action_{action}` with the payload array and
	 * the plan object; `eot` is end of term.
	 *
	 * @return object
	 */
	public static function definition() {
		return self::new_definition( 'ARM_PLAN_EXPIRES', 'ARMEMBER' )
			->trigger_meta( 'ARM_ALL_PLANS' )
			->hook( 'arm_user_plan_status_action_eot', 10, 2 );
	}

	/**
	 * Trigger setup.
	 *
	 * @return void
	 */
	protected function setup_trigger() {
		// integration / code / trigger_meta / trigger_type / hook are auto-applied from definition().
		$this->set_is_pro( true );
		// The cron that fires this has nobody logged in; the member is set from the payload in validate().
		$this->set_is_login_required( false );

		// translators: %1$s is the membership plan selector
		$this->set_sentence( sprintf( esc_html_x( "A user's {{membership plan:%1\$s}} expires", 'ARMember', 'uncanny-automator-pro' ), $this->get_trigger_meta() ) );
		$this->set_readable_sentence( esc_html_x( "A user's {{membership plan}} expires", 'ARMember', 'uncanny-automator-pro' ) );
	}

	/**
	 * Trigger fields.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->get_plan_option_config( $this->get_trigger_meta() ),
		);
	}

	/**
	 * Token definitions: the shared membership tokens plus the expiry date.
	 *
	 * @param array $trigger
	 * @param array $tokens
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {

		$token_class = $this->item_helpers->tokens();

		return array_merge( $tokens, $token_class->membership_tokens(), $token_class->expiry_tokens() );
	}

	/**
	 * Did the selected plan, or any plan, reach its end of term for a member?
	 *
	 * @param array $trigger
	 * @param array $hook_args ( array $args{plan_id,user_id,action}, ARM_Plan $plan )
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $user_id, $plan_id, $action ) = $this->unpack( $hook_args );

		if ( 'eot' !== $action || 0 === $user_id || 0 === $plan_id ) {
			return false;
		}

		// The member is the subject; the cron that fired this has no user of its own.
		$this->set_user_id( $user_id );

		$selected = $trigger['meta'][ $this->get_trigger_meta() ] ?? '';

		if ( intval( '-1' ) === intval( $selected ) ) {
			return true;
		}

		return absint( $selected ) === $plan_id;
	}

	/**
	 * Token values for the expired plan and its member.
	 *
	 * @param array $trigger
	 * @param array $hook_args
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $user_id, $plan_id ) = $this->unpack( $hook_args );

		$token_class = $this->item_helpers->tokens();

		return array_merge(
			$token_class->hydrate_membership_tokens( $user_id, $plan_id ),
			$token_class->hydrate_expiry_tokens( $user_id, $plan_id )
		);
	}

	/**
	 * The member, plan and status from ARMember's payload array.
	 *
	 * @param array $hook_args
	 *
	 * @return array ( int $user_id, int $plan_id, string $action )
	 */
	private function unpack( $hook_args ) {

		$args = (array) ( $hook_args[0] ?? array() );

		return array(
			absint( $args['user_id'] ?? 0 ),
			absint( $args['plan_id'] ?? 0 ),
			(string) ( $args['action'] ?? '' ),
		);
	}
}
