<?php

namespace Uncanny_Automator_Pro\Integrations\Armember;

use Uncanny_Automator\Integrations\Armember\Armember_Helpers;
use Uncanny_Automator\Recipe\Action;

/**
 * Class ARMEMBER_ADD_TO_MEMBERSHIP_PLAN
 *
 * @package Uncanny_Automator_Pro
 *
 * @property Armember_Helpers $item_helpers
 */
class ARMEMBER_ADD_TO_MEMBERSHIP_PLAN extends Action {

	/**
	 * Action setup.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ARMEMBER' );
		$this->set_action_code( 'ARM_ADD_TO_PLAN' );
		$this->set_action_meta( 'ARM_PLANS' );
		$this->set_is_pro( true );
		$this->set_requires_user( true );

		// translators: %1$s is the membership plan selector
		$this->set_sentence( sprintf( esc_html_x( 'Add the user to {{a membership plan:%1$s}}', 'ARMember', 'uncanny-automator-pro' ), $this->get_action_meta() ) );
		$this->set_readable_sentence( esc_html_x( 'Add the user to {{a membership plan}}', 'ARMember', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action fields.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->get_plan_option_config( $this->get_action_meta(), 'plans_strict', true ),
		);
	}

	/**
	 * Assign the plan the way ARMember's own flow does: announce the change,
	 * update the member's data, then update the subscription attributed to
	 * Automator with no trial.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$plan_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );

		if ( 0 === $plan_id ) {
			$this->add_log_error( esc_html_x( 'Plan does not exist.', 'ARMember', 'uncanny-automator-pro' ) );
			return false;
		}

		$plans   = $this->item_helpers->subscription_plans();
		$members = $this->item_helpers->members();

		if ( null === $plans || null === $members ) {
			$this->add_log_error( esc_html_x( 'ARMember is not available.', 'ARMember', 'uncanny-automator-pro' ) );
			return false;
		}

		// ARMember stores and compares plan ids as strings throughout.
		$plan_arg = (string) $plan_id;

		do_action( 'arm_before_update_user_subscription', $user_id, $plan_arg );
		$members->arm_manual_update_user_data( $user_id, $plan_arg );
		$plans->arm_update_user_subscription( $user_id, $plan_arg, 'Automator', false );

		// arm_update_user_subscription() returns nothing and silently declines a
		// plan that is inactive or deleted, leaving the member on their previous
		// plan. Without this check the recipe reports success and the only symptom
		// is the member's profile still showing the old plan.
		$assigned = $this->item_helpers->normalize_plan_ids( get_user_meta( $user_id, 'arm_user_plan_ids', true ) );

		if ( ! in_array( $plan_id, $assigned, true ) ) {
			$name = $plans->arm_get_plan_name_by_id( $plan_id );
			$this->add_log_error(
				sprintf(
					// translators: %1$s is the membership plan name or its id
					esc_html_x( 'ARMember did not assign %1$s to the user. The plan may be inactive or deleted.', 'ARMember', 'uncanny-automator-pro' ),
					'' !== (string) $name ? $name : $plan_id
				)
			);
			return false;
		}

		return true;
	}
}
