<?php

namespace Uncanny_Automator_Pro\Integrations\Armember;

use Uncanny_Automator\Integrations\Armember\Armember_Helpers;
use Uncanny_Automator\Recipe\Action;

/**
 * Class ARMEMBER_REMOVE_FROM_MEMBERSHIP_PLAN
 *
 * @package Uncanny_Automator_Pro
 *
 * @property Armember_Helpers $item_helpers
 */
class ARMEMBER_REMOVE_FROM_MEMBERSHIP_PLAN extends Action {

	/**
	 * Action setup.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ARMEMBER' );
		// The code is ARM_REMOVE_TO_PLAN in every recipe that stores it.
		$this->set_action_code( 'ARM_REMOVE_TO_PLAN' );
		$this->set_action_meta( 'ARM_PLANS' );
		$this->set_is_pro( true );
		$this->set_requires_user( true );

		// translators: %1$s is the membership plan selector
		$this->set_sentence( sprintf( esc_html_x( 'Remove the user from {{a membership plan:%1$s}}', 'ARMember', 'uncanny-automator-pro' ), $this->get_action_meta() ) );
		$this->set_readable_sentence( esc_html_x( 'Remove the user from {{a membership plan}}', 'ARMember', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action fields.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			$this->item_helpers->get_plan_option_config( $this->get_action_meta(), 'plans_strict', true ),
		);
	}

	/**
	 * Cancel the member's plan the way ARMember's admin flow does.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool|null Null when the user does not hold the plan — nothing to do.
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$plan_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );

		if ( 0 === $plan_id ) {
			$this->add_log_error( esc_html_x( 'Plan does not exist.', 'ARMember', 'uncanny-automator-pro' ) );
			return false;
		}

		$plans = $this->item_helpers->subscription_plans();

		if ( null === $plans ) {
			$this->add_log_error( esc_html_x( 'ARMember is not available.', 'ARMember', 'uncanny-automator-pro' ) );
			return false;
		}

		// ARMember stores the ids as strings; compare by value.
		$current_plan_ids = $this->item_helpers->normalize_plan_ids( get_user_meta( $user_id, 'arm_user_plan_ids', true ) );

		if ( empty( $current_plan_ids ) ) {
			$this->add_log_error( esc_html_x( 'The user is not a member of any membership plan.', 'ARMember', 'uncanny-automator-pro' ) );
			return null;
		}

		if ( ! in_array( $plan_id, $current_plan_ids, true ) ) {
			// translators: %1$s is the membership plan name
			$this->add_log_error( sprintf( esc_html_x( 'The user is not a member of %1$s.', 'ARMember', 'uncanny-automator-pro' ), $plans->arm_get_plan_name_by_id( $plan_id ) ) );
			return null;
		}

		$plan_data   = get_user_meta( $user_id, 'arm_user_plan_' . $plan_id, true );
		$plan_data   = is_array( $plan_data ) ? $plan_data : array();
		$plan_detail = isset( $plan_data['arm_current_plan_detail'] ) ? $plan_data['arm_current_plan_detail'] : null;

		// ARMember's own flag, spelling included.
		$plan_data['arm_cencelled_plan'] = 'yes';
		update_user_meta( $user_id, 'arm_user_plan_' . $plan_id, $plan_data );

		$plan = $this->item_helpers->plan( $plan_id, $plan_detail );

		if ( null !== $plan && $plan->exists() && $plan->is_recurring() ) {
			do_action( 'arm_cancel_subscription_gateway_action', $user_id, $plan_id );
		}

		// ARMember stores and compares plan ids as strings throughout.
		$plan_arg = (string) $plan_id;

		$plans->arm_add_membership_history( $user_id, $plan_arg, 'cancel_subscription', array(), 'admin' );
		do_action( 'arm_cancel_subscription', $user_id, $plan_arg );
		$plans->arm_clear_user_plan_detail( $user_id, $plan_arg );

		$this->forget_future_plan( $user_id, $plan_id );

		return true;
	}

	/**
	 * Drop the plan from the member's queued future plans, keeping the rest in order.
	 *
	 * @param int $user_id
	 * @param int $plan_id
	 *
	 * @return void
	 */
	private function forget_future_plan( $user_id, $plan_id ) {

		$future = get_user_meta( $user_id, 'arm_user_future_plan_ids', true );
		$future = is_array( $future ) ? $future : array();

		$remaining = array_values(
			array_filter(
				$future,
				static function ( $id ) use ( $plan_id ) {
					return absint( $id ) !== $plan_id;
				}
			)
		);

		if ( count( $remaining ) !== count( $future ) ) {
			update_user_meta( $user_id, 'arm_user_future_plan_ids', $remaining );
		}
	}
}
