<?php

namespace Uncanny_Automator_Pro\Integrations\Armember;

use Uncanny_Automator\Integrations\Armember\Armember_Helpers;

/**
 * Class Armember_Pro_Integration
 *
 * Pro adds no helper methods of its own, so its items run on Free's helper.
 * Both plugins register the `armember` remote-data id and Pro loads last, so
 * the instance registered here answers every plan segment — it is the same
 * class Free registered, so nothing needs delegating.
 *
 * @package Uncanny_Automator_Pro
 */
class Armember_Pro_Integration extends \Uncanny_Automator\Integration {

	/**
	 * Integration setup.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->helpers = new Armember_Helpers();
		$this->set_integration( 'ARMEMBER' );
		$this->set_name( 'ARMember' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/armember-icon.svg' );

		$this->set_plugin_file_path( 'armember-membership/armember-membership.php' );
		$this->set_plugin_variations( array( 'armember/armember.php' ) );
		$this->set_developer_name( 'Repute InfoSystems' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'commercial' );
	}

	/**
	 * Load Pro triggers and actions.
	 *
	 * @return void
	 */
	public function load() {
		new ARMEMBER_MEMBERSHIP_EXPIRED( $this->helpers );

		new ARMEMBER_ADD_TO_MEMBERSHIP_PLAN( $this->helpers );
		new ARMEMBER_REMOVE_FROM_MEMBERSHIP_PLAN( $this->helpers );
	}

	/**
	 * Whether ARMember is active, in either edition.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return defined( 'MEMBERSHIPLITE_DIR_NAME' ) || defined( 'MEMBERSHIP_DIR_NAME' );
	}
}
