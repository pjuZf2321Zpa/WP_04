<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

// Pro's ARMember integration requires the modern Free integration. When Free
// has not been updated yet, Pro's ARMember stays out rather than half-loading
// against a helper and token layer that no longer exist.
if ( ! class_exists( 'Uncanny_Automator\Integrations\Armember\Armember_Integration' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Armember\Armember_Pro_Integration' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\Armember\Armember_Pro_Integration();
