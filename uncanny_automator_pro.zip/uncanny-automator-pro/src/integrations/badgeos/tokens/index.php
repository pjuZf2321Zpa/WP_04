<?php
// Silent is golden.
