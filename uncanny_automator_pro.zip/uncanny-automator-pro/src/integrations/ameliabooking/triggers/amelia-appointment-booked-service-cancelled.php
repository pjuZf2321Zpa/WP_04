<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Recipe;

/**
 * Class AMELIA_APPOINTMENT_BOOKED_SERVICE_CANCELLED
 *
 * @package Uncanny_Automator
 */
class AMELIA_APPOINTMENT_BOOKED_SERVICE_CANCELLED {

	use Recipe\Triggers;

	/**
	 * Trigger code.
	 *
	 * @var string
	 */
	const TRIGGER_CODE = 'AMELIA_APPOINTMENT_BOOKED_SERVICE_CANCELLED';

	/**
	 * Trigger meta.
	 *
	 * @var string
	 */
	const TRIGGER_META = 'AMELIA_APPOINTMENT_BOOKED_SERVICE_CANCELLED_META';

	/**
	 * Set up Automator trigger constructor.
	 */
	public function __construct() {

		// Only enable in Amelia Pro.
		if ( ! defined( 'AMELIA_LITE_VERSION' ) ) {

			$this->setup_trigger();

		}

	}

	/**
	 * Define and register the trigger by pushing it into the Automator object
	 */
	public function setup_trigger() {

		// Bailout if helpers from base Automator is not found.
		if ( is_null( Automator()->helpers->recipe->ameliabooking ) ) {
			return;
		}

		$this->set_integration( 'AMELIABOOKING' );
		$this->set_trigger_code( self::TRIGGER_CODE );
		$this->set_trigger_meta( self::TRIGGER_META );
		$this->set_is_pro( true );
		$this->set_is_login_required( false );
		$this->set_trigger_type( 'anonymous' );

		// The hook 'automator_ameliabooking_status_cancelled' is a fake hook that is used to fire the trigger for each booking.
		// Check the Ameliabooking_Pro_Helpers::ameliabooking_status_cancelled() method for more details.
		$this->add_action( 'automator_ameliabooking_status_cancelled' );

		// The number of arguments that the action hook accepts.
		$this->set_action_args_count( 3 );

		// translators: Trigger sentence
		$this->set_sentence( sprintf( esc_html_x( 'A booking of an appointment for {{a specific service:%1$s}} is canceled', 'Amelia Booking', 'uncanny-automator-pro' ), $this->get_trigger_meta() ) );

		$this->set_readable_sentence( esc_html_x( 'A booking of an appointment for {{a specific service}} is canceled', 'Amelia Booking', 'uncanny-automator-pro' ) );

		// Set the options field group.
		$this->set_options_callback( array( $this, 'load_options' ) );

		// Register the trigger.
		$this->register_trigger();

	}

	/**
	 * @return array
	 */
	public function load_options() {
		return Automator()->utilities->keep_order_of_options(
			array(
				'options_group' => $this->get_trigger_option_fields(),
			)
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * Return false if returned booking data is empty.
	 */
	public function validate_trigger( ...$args ) {

		// The trigger trait passes every hook argument in one array.
		list( $reservation, $booking, $container ) = $args[0];

		return 'appointment' === (string) $reservation['type'] && 'canceled' === (string) $booking['status'];

	}

	/**
	 * Prepare to run.
	 *
	 * Sets the conditional trigger to true.
	 *
	 * @return void.
	 */
	public function prepare_to_run( $data ) {

		$this->set_conditional_trigger( true );

	}

	/**
	 * Trigger conditions.
	 *
	 * Only run the trigger if service is set to 'Any' or if service id is equals to the one set in the recipe.
	 *
	 * @return void.
	 */
	protected function trigger_conditions( $args ) {

		// Grab the individual booking data from wrapper hook.
		list( $reservation, $booking, $container ) = $args;

		// Match 'Any services' condition.
		$this->do_find_any( true );

		// Match specific condition.
		$this->do_find_this( $this->get_trigger_meta() );

		$this->do_find_in( array( $reservation['serviceId'] ) );

	}

	/**
	 * The trigger options fields.
	 *
	 * @return array The field options.
	 */
	public function get_trigger_option_fields() {

		return Automator()->helpers->recipe->ameliabooking->options->get_option_fields(
			$this->get_trigger_code(),
			$this->get_trigger_meta()
		);

	}

	/**
	 * Continue trigger process even for logged-in user.
	 *
	 * @return boolean True.
	 */
	public function do_continue_anon_trigger( ...$args ) {

		return true;

	}

}
