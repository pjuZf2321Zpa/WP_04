<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Recipe;

/**
 * Class AMELIA_APPOINTMENT_BOOKED_SERVICE
 *
 * @package Uncanny_Automator
 */
class AMELIA_APPOINTMENT_BOOKED_SERVICE {

	use Recipe\Triggers;

	/**
	 * Trigger code.
	 *
	 * @var string
	 */
	const TRIGGER_CODE = 'AMELIA_APPOINTMENT_BOOKED_SERVICE';

	/**
	 * Trigger meta.
	 *
	 * @var string
	 */
	const TRIGGER_META = 'AMELIA_APPOINTMENT_BOOKED_SERVICE_META';

	/**
	 * Set up Automator trigger constructor.
	 */
	public function __construct() {
		$this->setup_trigger();
	}

	/**
	 * Define and register the trigger by pushing it into the Automator object
	 */
	public function setup_trigger() {

		// Bailout if helpers from base Automator is not found.
		if ( is_null( Automator()->helpers->recipe->ameliabooking ) ) {
			return;
		}

		$this->set_integration( 'AMELIABOOKING' );
		$this->set_trigger_code( self::TRIGGER_CODE );
		$this->set_trigger_meta( self::TRIGGER_META );
		$this->set_trigger_type( 'anonymous' );
		$this->set_is_login_required( false );
		$this->set_is_pro( true );

		// The action hook to attach this trigger into.
		$this->add_action( 'automator_amelia_appointment_booked' );

		// translators: %1$s is the service trigger meta. %2$s is the category trigger meta.
		$this->set_sentence( sprintf( esc_html_x( 'An appointment is booked for {{a specific service:%2$s}} in {{a specific category:%1$s}}', 'Amelia Booking', 'uncanny-automator-pro' ), $this->get_trigger_code() . '_SERVICES:'. $this->get_trigger_meta(), $this->get_trigger_meta() ) );

		$this->set_readable_sentence( esc_html_x( 'An appointment is booked for {{a specific service}} in {{a specific category}}', 'Amelia Booking', 'uncanny-automator-pro' ) );

		// Set the options field group.
		$this->set_options_callback( array( $this, 'load_options' ) );
		// Register the trigger.
		$this->register_trigger();

	}

	/**
	 * @return array
	 */
	public function load_options() {
		return Automator()->utilities->keep_order_of_options(
			array(
				'options_group' => $this->get_trigger_option_fields(),
			)
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * Return false if returned booking data is empty.
	 */
	public function validate_trigger( ...$args ) {

		// Bailout if args is empty.
		if ( empty( $args ) ) {
			return false;
		}

		$normalized_data = array_shift( $args[0] );

		if ( empty( $normalized_data['type'] ) ) {
			return false;
		}

		// Only run for appointments. Don't run for events.
		if ( 'appointment' === $normalized_data['type'] ) {
			return true;
		}

		return false;

	}

	/**
	 * Prepare to run.
	 *
	 * Sets the conditional trigger to true.
	 *
	 * @return void.
	 */
	public function prepare_to_run( $data ) {

		$normalized_data = $data[0];

		$this->set_conditional_trigger( true );

	}

	/**
	 * Trigger conditions.
	 *
	 * Only run the trigger if service is set to 'Any' or if service id is equals to the one set in the recipe.
	 *
	 * @return void.
	 */
	protected function trigger_conditions( $args ) {

		// Grab the normalized data.
		$normalized_data = $args[0];

		// Match 'Any services' condition.
		$this->do_find_any( true );

		// Match specific condition.
		$this->do_find_this( $this->get_trigger_meta() );
		$this->do_find_in( array( $normalized_data['appointment']['serviceId'] ) );

	}

	/**
	 * The trigger options fields.
	 *
	 * @return array The field options.
	 */
	public function get_trigger_option_fields() {

		return Automator()->helpers->recipe->ameliabooking->options->get_option_fields(
			$this->get_trigger_code(),
			$this->get_trigger_meta()
		);

	}

	/**
	 * Continue trigger process even for logged-in user.
	 *
	 * @return boolean True.
	 */
	public function do_continue_anon_trigger( ...$args ) {

		return true;

	}

}
