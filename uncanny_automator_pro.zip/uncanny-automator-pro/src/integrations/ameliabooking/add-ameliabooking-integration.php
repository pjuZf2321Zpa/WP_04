<?php

namespace Uncanny_Automator_Pro;

/**
 * Class Add_Bo_Integration
 *
 * @package Uncanny_Automator_Pro
 */
class Add_Ameliabooking_Integration {

	/**
	 * Integration code
	 *
	 * @var string
	 */
	public static $integration = 'AMELIABOOKING';
}
