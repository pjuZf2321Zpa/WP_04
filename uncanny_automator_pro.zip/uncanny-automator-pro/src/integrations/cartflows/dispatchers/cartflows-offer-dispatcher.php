<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows\Dispatchers;

use Uncanny_Automator_Pro\Integrations\Cartflows\Cartflows_Pro_Helpers;
use WC_Order;

/**
 * Class Cartflows_Offer_Dispatcher
 *
 * Normalizes CartFlows Pro's two offer hooks into two internal actions the
 * offer triggers listen on. Three upstream facts make a dispatcher the right
 * seam rather than doing this inside validate():
 *
 * 1. `cartflows_offer_accepted` fires from TWO code paths for a single accepted
 *    offer — `Cartflows_Pro_Base_Offer_Markup::offer_accepted()` and
 *    `Cartflows_Pro_Flow_Frontend::after_offer_charge()` — depending on which
 *    payment gateway processed the charge. Without de-duplication a recipe runs
 *    twice for one purchase.
 *
 * 2. Neither hook carries the offer type or the funnel. The type has to be
 *    derived from `$offer_product['step_id']` and the funnel from the order's
 *    `_wcf_flow_id` meta before a trigger can filter on either. Doing that once
 *    here keeps it out of both triggers.
 *
 * 3. CartFlows also fires a runtime-built per-type variant next to each generic
 *    hook — `'cartflows_' . $step_type . '_offer_accepted'` and
 *    `..._offer_rejected`. Those are not static hook names and cannot be
 *    registered against; the generic hook plus a derived type is the only
 *    listenable shape.
 *
 * Two normalized actions are emitted:
 *
 *   `automator_cartflows_offer_accepted( int $order_id, int $step_id, string $step_type, int $flow_id, array $offer_product )`
 *   `automator_cartflows_offer_rejected( int $order_id, int $step_id, string $step_type, int $flow_id, array $offer_product )`
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows\Dispatchers
 */
class Cartflows_Offer_Dispatcher {

	/**
	 * Whether the upstream listeners have been registered.
	 *
	 * @var bool
	 */
	private static $booted = false;

	/**
	 * Helper used to derive the step type and funnel.
	 *
	 * @var Cartflows_Pro_Helpers|null
	 */
	private static $helpers = null;

	/**
	 * "{order}:{step}" keys already dispatched this request, keyed per event so
	 * an accept and a reject on the same step stay independent.
	 *
	 * @var array<string,bool>
	 */
	private static $dispatched = array();

	/**
	 * Idempotent boot.
	 *
	 * @param Cartflows_Pro_Helpers|null $helpers The integration's helper instance.
	 *
	 * @return void
	 */
	public static function boot( $helpers = null ) {

		if ( null !== $helpers ) {
			self::$helpers = $helpers;
		}

		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		add_action( 'cartflows_offer_accepted', array( __CLASS__, 'on_offer_accepted' ), 20, 2 );
		add_action( 'cartflows_offer_rejected', array( __CLASS__, 'on_offer_rejected' ), 20, 2 );
	}

	/**
	 * Clear the boot guard and unregister the upstream listeners.
	 *
	 * Test seam only — a WPUnit case that removes hooks in tearDown would
	 * otherwise leave the guard set and no listeners attached, so the next test
	 * in the process would silently observe nothing.
	 *
	 * @return void
	 */
	public static function reset_boot() {

		remove_action( 'cartflows_offer_accepted', array( __CLASS__, 'on_offer_accepted' ), 20 );
		remove_action( 'cartflows_offer_rejected', array( __CLASS__, 'on_offer_rejected' ), 20 );

		self::$booted     = false;
		self::$helpers    = null;
		self::$dispatched = array();
	}

	/**
	 * An offer was accepted and charged.
	 *
	 * @param mixed $order         The WooCommerce order.
	 * @param mixed $offer_product The offer product payload.
	 *
	 * @return void
	 */
	public static function on_offer_accepted( $order, $offer_product ) {
		self::maybe_dispatch( 'automator_cartflows_offer_accepted', $order, $offer_product );
	}

	/**
	 * An offer was declined.
	 *
	 * @param mixed $order         The WooCommerce order.
	 * @param mixed $offer_product The offer product payload.
	 *
	 * @return void
	 */
	public static function on_offer_rejected( $order, $offer_product ) {
		self::maybe_dispatch( 'automator_cartflows_offer_rejected', $order, $offer_product );
	}

	/**
	 * Emit the normalized event once per order + step.
	 *
	 * @param string $event         The internal action to emit.
	 * @param mixed  $order         The WooCommerce order.
	 * @param mixed  $offer_product The offer product payload.
	 *
	 * @return void
	 */
	private static function maybe_dispatch( $event, $order, $offer_product ) {

		// The reject path (`Cartflows_Pro_Base_Offer_Markup::offer_rejected()`)
		// builds its order with wc_get_order( $order_id ) and does not check the
		// result, so a deleted or unreadable order arrives here as false.
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( ! is_array( $offer_product ) ) {
			return;
		}

		$step_id = absint( $offer_product['step_id'] ?? 0 );

		// Without the step there is no offer type to filter on, and the funnel
		// step tokens cannot be resolved. get_offer_data() only omits step_id
		// when the offer step has no product configured.
		if ( 0 === $step_id ) {
			return;
		}

		$order_id = absint( $order->get_id() );
		$key      = $event . ':' . $order_id . ':' . $step_id;

		if ( isset( self::$dispatched[ $key ] ) ) {
			return;
		}

		self::$dispatched[ $key ] = true;

		$helpers = self::$helpers instanceof Cartflows_Pro_Helpers ? self::$helpers : new Cartflows_Pro_Helpers();

		do_action(
			$event,
			$order_id,
			$step_id,
			$helpers->get_step_type( $step_id ),
			$helpers->get_order_flow_id( $order ),
			$offer_product
		);
	}
}
