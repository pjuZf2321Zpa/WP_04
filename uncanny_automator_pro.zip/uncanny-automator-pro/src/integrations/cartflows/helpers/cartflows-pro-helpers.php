<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows;

use Uncanny_Automator\App\Transports\Restful\Remote_Data\Remote_Data_Request;
use Uncanny_Automator\Integrations\Cartflows\Cartflows_Helpers;
use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;
use WC_Order;
use WP_Error;
use WP_Post;

/**
 * Class Cartflows_Pro_Helpers
 *
 * Composes Free's Cartflows_Helpers via $base. Pro reuses Free's flow and
 * product pickers, its step-type vocabulary and its attach_step_to_flow()
 * sequence, so this class is the decoupling seam — Pro never reaches into
 * Free's concrete helper directly. The delegation block below is Pro's
 * contract with Free: a rename on the Free side surfaces as a static-analysis
 * failure here rather than a production fatal.
 *
 * Free and Pro both call set_integration( 'CARTFLOWS' ), so both helpers claim
 * the same remote_data routing ID and Pro's instance wins the
 * `automator_remote_data_instance_cartflows` filter by registering last. That
 * makes process_remote_data_request() below load-bearing for FREE's dropdowns
 * as well as Pro's: it resolves Pro-only segments locally and forwards
 * everything else to Free.
 *
 * On clone_step_into_flow(): it deliberately does not call CartFlows Pro's
 * `Cartflows_Pro_Utils::clone_step()`. That helper copies the post, its
 * taxonomies and its meta, then stops — it never touches the target funnel's
 * `wcf-steps` array, so on its own it produces a step that exists in the
 * database but never appears inside a funnel. Every caller inside CartFlows Pro
 * compensates afterwards. CartFlows' own user-facing clone is a Free admin route
 * that takes the funnel as a second argument, and the ability runtime does the
 * same. Reimplementing that sequence here also drops the CartFlows Pro
 * requirement from the action entirely.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows
 *
 * @property Cartflows_Helpers $base
 */
class Cartflows_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * "Any" sentinel. Aliases Free's constant rather than redeclaring the
	 * literal, so the two can never drift apart.
	 *
	 * @var string
	 */
	const ANY = Cartflows_Helpers::ANY;

	/**
	 * The only two offer step types CartFlows Pro ships. Both offer hooks derive
	 * their per-type variant from this same value
	 * (`Cartflows_Pro_Base_Offer_Markup::offer_accepted()` / `::offer_rejected()`).
	 *
	 * @var string[]
	 */
	const OFFER_TYPES = array( 'upsell', 'downsell' );

	/**
	 * Compose the Free helper.
	 */
	public function __construct() {
		$this->base = new Cartflows_Helpers();
	}

	// =========================================================================
	// Delegation block — Pro's explicit contract with Free.
	// =========================================================================

	/**
	 * Resolve a remote-data segment.
	 *
	 * Pro-only segments (the two step pickers) resolve here; every Free segment —
	 * `flows`, `flows_strict`, `products`, `products_strict` — forwards to the
	 * composed Free helper. Without that forward, Free's own checkout triggers
	 * lose their dropdowns the moment Pro is active.
	 *
	 * @param string              $data    The data identifier.
	 * @param Remote_Data_Request $request The typed request DTO.
	 *
	 * @return array
	 */
	public function process_remote_data_request( string $data, Remote_Data_Request $request ): array {

		$method = 'remote_data_get_' . sanitize_key( $data );

		if ( method_exists( $this, $method ) ) {
			return $this->{ $method }( $request );
		}

		return $this->base->process_remote_data_request( $data, $request );
	}

	/**
	 * Delegates to Free's woocommerce_active().
	 *
	 * @return bool
	 */
	public function woocommerce_active() {
		return $this->base->woocommerce_active();
	}

	/**
	 * Delegates to Free's cartflows_pro_active().
	 *
	 * @return bool
	 */
	public function cartflows_pro_active() {
		return $this->base->cartflows_pro_active();
	}

	/**
	 * Delegates to Free's get_flow_options().
	 *
	 * @param bool $include_any Whether to prepend the "Any flow" sentinel.
	 *
	 * @return array
	 */
	public function get_flow_options( $include_any = true ) {
		return $this->base->get_flow_options( $include_any );
	}

	/**
	 * Delegates to Free's get_product_options().
	 *
	 * @param bool $include_any Whether to prepend the "Any product" sentinel.
	 *
	 * @return array
	 */
	public function get_product_options( $include_any = true ) {
		return $this->base->get_product_options( $include_any );
	}

	/**
	 * Delegates to Free's get_step_type_options().
	 *
	 * @return array
	 */
	public function get_step_type_options() {
		return $this->base->get_step_type_options();
	}

	/**
	 * Delegates to Free's get_step_types().
	 *
	 * @return string[]
	 */
	public function get_step_types() {
		return $this->base->get_step_types();
	}

	/**
	 * Delegates to Free's step_type_requires_pro().
	 *
	 * @param string $step_type The step-type slug.
	 *
	 * @return bool
	 */
	public function step_type_requires_pro( $step_type ) {
		return $this->base->step_type_requires_pro( $step_type );
	}

	/**
	 * Delegates to Free's attach_step_to_flow().
	 *
	 * @param int    $step_id    The step post ID.
	 * @param int    $flow_id    The funnel to attach it to.
	 * @param string $step_type  The step-type slug.
	 * @param string $step_title The step title.
	 *
	 * @return void
	 */
	public function attach_step_to_flow( $step_id, $flow_id, $step_type, $step_title ) {
		$this->base->attach_step_to_flow( $step_id, $flow_id, $step_type, $step_title );
	}

	// =========================================================================
	// Pro-only helpers.
	// =========================================================================

	/**
	 * Offer-type options for the two offer triggers.
	 *
	 * @param bool $include_any Whether to prepend the "Any offer" sentinel.
	 *
	 * @return array
	 */
	public function get_offer_type_options( $include_any = true ) {

		$options = array();

		if ( true === $include_any ) {
			$options[] = array(
				'value' => self::ANY,
				'text'  => esc_html_x( 'Any offer', 'CartFlows', 'uncanny-automator-pro' ),
			);
		}

		$options[] = array(
			'value' => 'upsell',
			'text'  => esc_html_x( 'Upsell', 'CartFlows', 'uncanny-automator-pro' ),
		);

		$options[] = array(
			'value' => 'downsell',
			'text'  => esc_html_x( 'Downsell', 'CartFlows', 'uncanny-automator-pro' ),
		);

		return $options;
	}

	/**
	 * Step types with plain labels.
	 *
	 * Free's get_step_type_options() annotates upsell and downsell with
	 * "requires CartFlows Pro", which is the right thing to say when the field
	 * is about to create a step and the wrong thing when the field is only
	 * reading a step's type back.
	 *
	 * @return array
	 */
	public function get_plain_step_type_options() {

		$labels = array(
			'landing'  => esc_html_x( 'Landing', 'CartFlows', 'uncanny-automator-pro' ),
			'optin'    => esc_html_x( 'Optin', 'CartFlows', 'uncanny-automator-pro' ),
			'checkout' => esc_html_x( 'Checkout', 'CartFlows', 'uncanny-automator-pro' ),
			'thankyou' => esc_html_x( 'Thank You', 'CartFlows', 'uncanny-automator-pro' ),
			'upsell'   => esc_html_x( 'Upsell', 'CartFlows', 'uncanny-automator-pro' ),
			'downsell' => esc_html_x( 'Downsell', 'CartFlows', 'uncanny-automator-pro' ),
		);

		$options = array();

		foreach ( $labels as $value => $text ) {
			$options[] = array(
				'value' => $value,
				'text'  => $text,
			);
		}

		return $options;
	}

	/**
	 * CartFlows steps as dropdown options, optionally narrowed to one step type.
	 *
	 * Steps carry their type on the `wcf-step-type` post meta and mirror it onto
	 * the `cartflows_step_type` taxonomy. The meta is what CartFlows reads at
	 * runtime (`Cartflows_Utils::get_step_type()`), so it is what this filters on.
	 *
	 * @param string $step_type Optional step-type slug to filter by.
	 *
	 * @return array
	 */
	public function get_step_options( $step_type = '' ) {

		$options = array();

		if ( ! defined( 'CARTFLOWS_STEP_POST_TYPE' ) ) {
			return $options;
		}

		$args = array(
			'post_type'        => CARTFLOWS_STEP_POST_TYPE,
			'post_status'      => array( 'publish', 'draft' ),
			// phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
			'posts_per_page'   => apply_filters( 'automator_select_all_posts_limit', 999, CARTFLOWS_STEP_POST_TYPE ),
			'orderby'          => 'title',
			'order'            => 'ASC',
			'suppress_filters' => false,
		);

		if ( '' !== (string) $step_type ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$args['meta_key'] = 'wcf-step-type';
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			$args['meta_value'] = (string) $step_type;
		}

		foreach ( get_posts( $args ) as $step ) {
			$options[] = array(
				'value' => (string) $step->ID,
				'text'  => $step->post_title,
			);
		}

		return $options;
	}

	/**
	 * A step's type, read through CartFlows' own resolver where available.
	 *
	 * @param int $step_id The step post ID.
	 *
	 * @return string
	 */
	public function get_step_type( $step_id ) {

		$step_id = absint( $step_id );

		if ( 0 === $step_id ) {
			return '';
		}

		if ( function_exists( 'wcf' ) && isset( wcf()->utils ) ) {
			return (string) wcf()->utils->get_step_type( $step_id );
		}

		return (string) get_post_meta( $step_id, 'wcf-step-type', true );
	}

	/**
	 * Whether a step-type slug is one of the two offer types.
	 *
	 * @param string $step_type The step-type slug.
	 *
	 * @return bool
	 */
	public function is_offer_step_type( $step_type ) {
		return in_array( (string) $step_type, self::OFFER_TYPES, true );
	}

	/**
	 * The funnel an order was placed through, or 0.
	 *
	 * @param mixed $order A WC_Order, or an order ID.
	 *
	 * @return int
	 */
	public function get_order_flow_id( $order ) {

		if ( is_numeric( $order ) ) {
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( absint( $order ) ) : false;
		}

		if ( ! $order instanceof WC_Order ) {
			return 0;
		}

		// Read the key off the composed instance rather than naming Free's
		// concrete class again — $base is the only seam where it belongs.
		return absint( $order->get_meta( $this->base::ORDER_FLOW_META ) );
	}

	/**
	 * A checkout step's configured product rows, straight from post meta.
	 *
	 * Deliberately not read through `wcf()->options->get_checkout_meta_value()`.
	 * That reader substitutes the field's default when the meta is empty and
	 * passes the result through `cartflows_checkout_meta_wcf-checkout-products`,
	 * so a value that was never saved — or one a third party filtered in for
	 * display — can come back. The only caller appends a row and writes the
	 * array straight back to `wcf-checkout-products`, and a read-modify-write
	 * has to read the store it is about to overwrite or it persists whatever the
	 * filter invented.
	 *
	 * @param int $step_id The checkout step post ID.
	 *
	 * @return array
	 */
	public function get_checkout_products( $step_id ) {

		$step_id = absint( $step_id );

		if ( 0 === $step_id ) {
			return array();
		}

		$products = get_post_meta( $step_id, 'wcf-checkout-products', true );

		return is_array( $products ) ? $products : array();
	}

	/**
	 * Build a checkout product row in CartFlows' current shape.
	 *
	 * CartFlows 3.2.0 stores six keys per row, not the two an "ID + quantity"
	 * reading would suggest (`Cartflows_Ability_Runtime::update_checkout_products()`).
	 * `unique_id` in particular is what the funnel editor keys rows on — a row
	 * written without one is not editable in the CartFlows UI.
	 *
	 * @param int $product_id The WooCommerce product ID.
	 * @param int $quantity   The quantity.
	 * @param int $index      Position used to seed the unique ID.
	 *
	 * @return array
	 */
	public function build_checkout_product_row( $product_id, $quantity, $index = 0 ) {
		return array(
			'product'        => absint( $product_id ),
			// intval, not absint: absint( -5 ) is 5, which would silently turn a
			// negative quantity into a large one. CartFlows clamps the same way
			// (`Cartflows_Ability_Runtime::update_checkout_products()`).
			'quantity'       => max( 1, intval( $quantity ) ),
			'discount_type'  => '',
			'discount_value' => '',
			'add_to_cart'    => 'yes',
			'unique_id'      => md5( absint( $product_id ) . '_' . absint( $index ) . '_' . time() ),
		);
	}

	/**
	 * Clone a CartFlows step into a funnel.
	 *
	 * See the class docblock for why this reimplements the sequence instead of
	 * calling CartFlows Pro's clone_step().
	 *
	 * @param int $step_id The step to clone.
	 * @param int $flow_id The funnel to attach the clone to.
	 *
	 * @return int|WP_Error The new step ID, or a WP_Error.
	 */
	public function clone_step_into_flow( $step_id, $flow_id ) {

		$step_id = absint( $step_id );
		$flow_id = absint( $flow_id );

		$source = get_post( $step_id );

		if ( ! $source instanceof WP_Post ) {
			return new WP_Error(
				'cartflows_step_missing',
				esc_html_x( 'The step could not be found.', 'CartFlows', 'uncanny-automator-pro' )
			);
		}

		$title = $source->post_title . ' Clone';

		$new_step_id = wp_insert_post(
			array(
				'comment_status' => $source->comment_status,
				'ping_status'    => $source->ping_status,
				'post_author'    => absint( get_current_user_id() ),
				'post_content'   => $source->post_content,
				'post_excerpt'   => $source->post_excerpt,
				'post_parent'    => $source->post_parent,
				'post_password'  => $source->post_password,
				'post_status'    => $source->post_status,
				'post_title'     => $title,
				'post_type'      => $source->post_type,
				'to_ping'        => $source->to_ping,
				'menu_order'     => $source->menu_order,
			),
			true
		);

		if ( is_wp_error( $new_step_id ) ) {
			return $new_step_id;
		}

		// Copy every taxonomy term. attach_step_to_flow() re-points the two
		// CartFlows taxonomies afterwards; this preserves anything else.
		foreach ( get_object_taxonomies( $source->post_type ) as $taxonomy ) {

			$terms = wp_get_object_terms( $step_id, $taxonomy, array( 'fields' => 'slugs' ) );

			if ( ! is_wp_error( $terms ) ) {
				wp_set_object_terms( $new_step_id, $terms, $taxonomy, false );
			}
		}

		// Copy the step meta. `_wp_old_slug` is excluded for the same reason
		// CartFlows excludes it — it would resurrect stale permalink redirects.
		//
		// maybe_unserialize(), not automator_safe_unserialize(): this is a
		// verbatim duplication, and the safe variant decodes with
		// allowed_classes => false, which would turn any legitimately
		// object-valued step meta into __PHP_Incomplete_Class and persist that
		// to the clone. get_post_meta() without a key returns raw serialized
		// strings and add_post_meta() re-serializes, so the decode cannot be
		// skipped. WP core's own _wp_copy_post_meta() does exactly this. The
		// input is plugin settings written through the CartFlows admin, not a
		// user-supplied payload.
		foreach ( get_post_meta( $step_id ) as $meta_key => $meta_values ) {

			if ( '_wp_old_slug' === $meta_key ) {
				continue;
			}

			foreach ( (array) $meta_values as $meta_value ) {
				add_post_meta( $new_step_id, $meta_key, maybe_unserialize( $meta_value ) );
			}
		}

		// Owns wcf-flow-id, wcf-step-type, both taxonomies, and the funnel's own
		// wcf-steps array — the part clone_step() leaves out.
		$this->attach_step_to_flow( $new_step_id, $flow_id, $this->get_step_type( $step_id ), $title );

		if ( function_exists( 'wcf' ) && isset( wcf()->utils ) ) {
			wcf()->utils->clear_cache();
		}

		return absint( $new_step_id );
	}

	// =========================================================================
	// Remote_Data segments — Pro-only.
	// =========================================================================

	/**
	 * Remote_Data segment: every step.
	 *
	 * No `_strict` twin: steps are only ever picked by actions and conditions,
	 * so there is no "Any step" variant for this to be the strict half of.
	 *
	 * @param mixed $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_steps_strict( $request ): array {
		return $this->remote_data_success( $this->get_step_options() );
	}

	/**
	 * Remote_Data segment: checkout steps only.
	 *
	 * @param mixed $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_checkout_steps_strict( $request ): array {
		return $this->remote_data_success( $this->get_step_options( 'checkout' ) );
	}
}
