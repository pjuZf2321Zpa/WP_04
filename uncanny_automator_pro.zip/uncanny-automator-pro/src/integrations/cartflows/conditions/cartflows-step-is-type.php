<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows\Conditions;

use Uncanny_Automator_Pro\Action_Condition;
use Uncanny_Automator_Pro\Integrations\Cartflows\Cartflows_Pro_Helpers;

/**
 * Class Cartflows_Step_Is_Type
 *
 * Condition: gate the rest of the recipe on a CartFlows step's type. Useful for
 * branching a funnel-wide recipe — run one path for checkout steps, another for
 * offers — without splitting it into separate recipes per step.
 *
 * The type is read from the `wcf-step-type` post meta through CartFlows' own
 * resolver (`Cartflows_Utils::get_step_type()`). CartFlows also mirrors the type onto
 * the `cartflows_step_type` taxonomy, but the meta is what it reads at runtime,
 * so the meta is what this compares.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows\Conditions
 *
 * @property Cartflows_Pro_Helpers $item_helpers
 */
class Cartflows_Step_Is_Type extends Action_Condition {

	/**
	 * Option code of the step field.
	 */
	const STEP = 'CARTFLOWS_STEP';

	/**
	 * Option code of the direction selector.
	 */
	const CRITERIA = 'CRITERIA';

	/**
	 * Option code of the step-type field.
	 */
	const STEP_TYPE = 'CARTFLOWS_STEP_TYPE';

	/**
	 * Define condition metadata.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration = 'CARTFLOWS';

		$this->name = esc_html_x( '{{A step}} {{is/is not}} {{a specific type}}', 'CartFlows', 'uncanny-automator-pro' );

		$this->code = 'CARTFLOWS_STEP_IS_TYPE';

		$this->dynamic_name = sprintf(
			/* translators: 1: CartFlows step, 2: Criteria (is / is not), 3: Step type */
			esc_html_x( '{{A step:%1$s}} {{is/is not:%2$s}} {{a specific type:%3$s}}', 'CartFlows', 'uncanny-automator-pro' ),
			self::STEP,
			self::CRITERIA,
			self::STEP_TYPE
		);

		$this->is_pro        = true;
		$this->requires_user = false;
	}

	/**
	 * Reads CartFlows post meta only — no WooCommerce dependency.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return defined( 'CARTFLOWS_FILE' );
	}

	/**
	 * Define condition fields.
	 *
	 * @return array
	 */
	public function fields() {
		return array(
			$this->field->select_field_args(
				array(
					'option_code' => self::STEP,
					'label'       => esc_html_x( 'Step', 'CartFlows', 'uncanny-automator-pro' ),
					'required'    => true,
					'options'     => array(),
					'remote_data' => $this->item_helpers->remote_data_load_config( 'steps_strict' ),
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'           => self::CRITERIA,
					'label'                 => esc_html_x( 'Criteria', 'CartFlows', 'uncanny-automator-pro' ),
					'required'              => true,
					'supports_custom_value' => false,
					'options'               => array(
						array(
							'value' => 'is',
							'text'  => esc_html_x( 'is', 'CartFlows', 'uncanny-automator-pro' ),
						),
						array(
							'value' => 'is-not',
							'text'  => esc_html_x( 'is not', 'CartFlows', 'uncanny-automator-pro' ),
						),
					),
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'           => self::STEP_TYPE,
					'label'                 => esc_html_x( 'Step type', 'CartFlows', 'uncanny-automator-pro' ),
					'required'              => true,
					'supports_custom_value' => false,
					'options_show_id'       => false,
					// The plain list, not Free's action-facing one: that variant
					// labels upsell and downsell "requires CartFlows Pro", which
					// is true when creating a step and misleading when merely
					// reading one back.
					'options'               => $this->item_helpers->get_plain_step_type_options(),
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$step_id  = absint( $this->get_parsed_option( self::STEP ) );
		$expected = (string) $this->get_parsed_option( self::STEP_TYPE );
		$criteria = (string) $this->get_parsed_option( self::CRITERIA );

		if ( 0 === $step_id ) {
			$this->condition_failed( esc_html_x( 'No step provided.', 'CartFlows', 'uncanny-automator-pro' ) );
			return;
		}

		if ( '' === $expected ) {
			$this->condition_failed( esc_html_x( 'No step type selected.', 'CartFlows', 'uncanny-automator-pro' ) );
			return;
		}

		if ( ! defined( 'CARTFLOWS_STEP_POST_TYPE' ) || CARTFLOWS_STEP_POST_TYPE !== get_post_type( $step_id ) ) {
			$this->condition_failed(
				sprintf(
					/* translators: 1: Step ID */
					esc_html_x( 'Step [%1$d] could not be found.', 'CartFlows', 'uncanny-automator-pro' ),
					$step_id
				)
			);
			return;
		}

		$actual = $this->item_helpers->get_step_type( $step_id );

		$matches    = ( $actual === $expected );
		$want_match = ( 'is-not' !== $criteria );

		if ( $want_match === $matches ) {
			return;
		}

		if ( $want_match ) {
			$this->condition_failed(
				sprintf(
					/* translators: 1: Step ID, 2: Actual step type, 3: Expected step type */
					esc_html_x( 'Step [%1$d] is a [%2$s] step, not a [%3$s] step.', 'CartFlows', 'uncanny-automator-pro' ),
					$step_id,
					'' === $actual ? '-' : $actual,
					$expected
				)
			);
			return;
		}

		$this->condition_failed(
			sprintf(
				/* translators: 1: Step ID, 2: Step type */
				esc_html_x( 'Step [%1$d] is a [%2$s] step.', 'CartFlows', 'uncanny-automator-pro' ),
				$step_id,
				$expected
			)
		);
	}
}
