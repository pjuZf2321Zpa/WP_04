<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows\Conditions;

use Uncanny_Automator_Pro\Action_Condition;
use Uncanny_Automator_Pro\Integrations\Cartflows\Cartflows_Pro_Helpers;

/**
 * Class Cartflows_Order_Placed_Through_Flow
 *
 * Condition: gate the rest of the recipe on whether a given WooCommerce order
 * originated in a specific CartFlows funnel. Not user-scoped — the order is
 * provided explicitly, so this composes with any WooCommerce or CartFlows
 * trigger that exposes an order ID token.
 *
 * CartFlows stamps `_wcf_flow_id` onto the order during checkout
 * (`Cartflows_Checkout_Markup::store_flow_metadata_on_order()`), which is the
 * same signal CartFlows itself reads back in `Cartflows_Utils`. An order placed
 * outside a funnel carries no such meta and resolves to 0, so it never matches
 * a selected funnel.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows\Conditions
 *
 * @property Cartflows_Pro_Helpers $item_helpers
 */
class Cartflows_Order_Placed_Through_Flow extends Action_Condition {

	/**
	 * Option code of the order field.
	 */
	const ORDER = 'ORDER';

	/**
	 * Option code of the direction selector.
	 */
	const CRITERIA = 'CRITERIA';

	/**
	 * Option code of the funnel field.
	 */
	const FLOW = 'CARTFLOWS_FLOW';

	/**
	 * Define condition metadata.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration = 'CARTFLOWS';

		$this->name = esc_html_x( '{{An order}} {{was/was not}} placed through {{a flow}}', 'CartFlows', 'uncanny-automator-pro' );

		$this->code = 'CARTFLOWS_ORDER_PLACED_THROUGH_FLOW';

		$this->dynamic_name = sprintf(
			/* translators: 1: Order ID, 2: Criteria (was / was not), 3: CartFlows flow */
			esc_html_x( '{{An order:%1$s}} {{was/was not:%2$s}} placed through {{a flow:%3$s}}', 'CartFlows', 'uncanny-automator-pro' ),
			self::ORDER,
			self::CRITERIA,
			self::FLOW
		);

		$this->is_pro        = true;
		$this->requires_user = false;
	}

	/**
	 * WooCommerce is required as well as CartFlows — the condition reads a
	 * WooCommerce order.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return defined( 'CARTFLOWS_FILE' ) && function_exists( 'WC' );
	}

	/**
	 * Define condition fields.
	 *
	 * @return array
	 */
	public function fields() {
		return array(
			$this->field->text(
				array(
					'option_code'     => self::ORDER,
					'label'           => esc_html_x( 'Order ID', 'CartFlows', 'uncanny-automator-pro' ),
					'input_type'      => 'text',
					'required'        => true,
					'supports_tokens' => true,
					'description'     => esc_html_x( 'Enter the order ID or use a token.', 'CartFlows', 'uncanny-automator-pro' ),
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'           => self::CRITERIA,
					'label'                 => esc_html_x( 'Criteria', 'CartFlows', 'uncanny-automator-pro' ),
					'required'              => true,
					'supports_custom_value' => false,
					'options'               => array(
						array(
							'value' => 'was',
							'text'  => esc_html_x( 'was', 'CartFlows', 'uncanny-automator-pro' ),
						),
						array(
							'value' => 'was-not',
							'text'  => esc_html_x( 'was not', 'CartFlows', 'uncanny-automator-pro' ),
						),
					),
				)
			),
			$this->field->select_field_args(
				array(
					'option_code' => self::FLOW,
					'label'       => esc_html_x( 'Flow', 'CartFlows', 'uncanny-automator-pro' ),
					'required'    => true,
					'options'     => array(),
					// Strict (no "Any flow"): the sentinel would make the
					// condition pass for every CartFlows order, which the
					// "was placed through a specific funnel" question never wants.
					'remote_data' => $this->item_helpers->remote_data_load_config( 'flows_strict' ),
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$order_id = absint( $this->get_parsed_option( self::ORDER ) );
		$flow_id  = absint( $this->get_parsed_option( self::FLOW ) );
		$criteria = (string) $this->get_parsed_option( self::CRITERIA );

		if ( 0 === $order_id ) {
			$this->condition_failed( esc_html_x( 'No order ID provided.', 'CartFlows', 'uncanny-automator-pro' ) );
			return;
		}

		if ( 0 === $flow_id ) {
			$this->condition_failed( esc_html_x( 'No flow selected.', 'CartFlows', 'uncanny-automator-pro' ) );
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			$this->condition_failed(
				sprintf(
					/* translators: 1: Order ID */
					esc_html_x( 'Order [%1$d] could not be found.', 'CartFlows', 'uncanny-automator-pro' ),
					$order_id
				)
			);
			return;
		}

		$order_flow_id = $this->item_helpers->get_order_flow_id( $order );

		$matches    = ( $order_flow_id === $flow_id );
		$want_match = ( 'was-not' !== $criteria );

		if ( $want_match === $matches ) {
			return;
		}

		if ( ! $want_match ) {
			$this->condition_failed(
				sprintf(
					/* translators: 1: Order ID, 2: Flow ID */
					esc_html_x( 'Order [%1$d] was placed through flow [%2$d].', 'CartFlows', 'uncanny-automator-pro' ),
					$order_id,
					$flow_id
				)
			);
			return;
		}

		if ( 0 === $order_flow_id ) {
			$this->condition_failed(
				sprintf(
					/* translators: 1: Order ID */
					esc_html_x( 'Order [%1$d] was not placed through a CartFlows flow.', 'CartFlows', 'uncanny-automator-pro' ),
					$order_id
				)
			);
			return;
		}

		$this->condition_failed(
			sprintf(
				/* translators: 1: Order ID, 2: Actual flow ID, 3: Selected flow ID */
				esc_html_x( 'Order [%1$d] was placed through flow [%2$d], not flow [%3$d].', 'CartFlows', 'uncanny-automator-pro' ),
				$order_id,
				$order_flow_id,
				$flow_id
			)
		);
	}
}
