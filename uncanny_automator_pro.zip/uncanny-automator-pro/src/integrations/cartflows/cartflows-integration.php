<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows;

use Uncanny_Automator\Integration;
use Uncanny_Automator_Pro\Integrations\Cartflows\Conditions\Cartflows_Order_Placed_Through_Flow;
use Uncanny_Automator_Pro\Integrations\Cartflows\Conditions\Cartflows_Step_Is_Type;
use Uncanny_Automator_Pro\Integrations\Cartflows\Dispatchers\Cartflows_Offer_Dispatcher;
use Uncanny_Automator_Pro\Loop_Filters\CARTFLOWS_ORDER_PLACED_THROUGH_FLOW as CARTFLOWS_ORDER_PLACED_THROUGH_FLOW_LOOP;

/**
 * Class Cartflows_Integration
 *
 * Pro shell for the CartFlows integration. The integration code stays
 * 'CARTFLOWS' (shared with Free) so Pro items merge under the same integration
 * in the recipe builder. Pro composes Free's helper through
 * Cartflows_Pro_Helpers rather than reaching into Free's concrete helper
 * directly.
 *
 * Only the two offer triggers require the CartFlows Pro plugin; they gate
 * themselves through requirements_met(). The actions, conditions and loop
 * filter run on CartFlows Free — including the clone action, which reimplements
 * the funnel-attaching sequence rather than calling CartFlows Pro's incomplete
 * clone_step().
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows
 */
class Cartflows_Integration extends Integration {

	/**
	 * Set up integration code, name, icon and helpers.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->helpers = new Cartflows_Pro_Helpers();
		$this->set_integration( 'CARTFLOWS' );
		$this->set_name( 'CartFlows' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/cart-flows-icon.svg' );

		$this->set_plugin_file_path( 'cartflows/cartflows.php' );
		$this->set_developer_name( 'Brainstorm Force' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * Always-on upstream listeners — registered in targeted mode too.
	 *
	 * The offer dispatcher listens on CartFlows Pro's offer hooks, which fire on
	 * the front end. In targeted mode the framework never calls load(); only
	 * this method runs. Booting the dispatcher here is what makes both offer
	 * triggers fire at all outside the recipe builder.
	 *
	 * @return void
	 */
	protected function load_shared_hooks() {
		Cartflows_Offer_Dispatcher::boot( $this->helpers );
	}

	/**
	 * Bootstrap Pro triggers, actions, conditions and loop filters.
	 *
	 * @return void
	 */
	public function load() {

		// Register the always-on listeners in full-load mode too — the parent
		// only calls load_shared_hooks() in targeted mode, never alongside load().
		$this->load_shared_hooks();

		// Triggers.
		new Cartflows_User_Accepts_Offer( $this->helpers );
		new Cartflows_User_Rejects_Offer( $this->helpers );

		// Actions.
		new Cartflows_Add_Product_To_Checkout_Step( $this->helpers );
		new Cartflows_Clone_Step( $this->helpers );

		// Conditions.
		new Cartflows_Order_Placed_Through_Flow( $this->helpers );
		new Cartflows_Step_Is_Type( $this->helpers );

		// Loop filters — Post entity (WooCommerce orders).
		new CARTFLOWS_ORDER_PLACED_THROUGH_FLOW_LOOP( null, array(), null, $this->helpers );
	}

	/**
	 * Active when CartFlows Free is installed.
	 *
	 * WooCommerce is NOT gated here — the clone action and the step-type
	 * condition work on a CartFlows install without it. The items that do read
	 * WooCommerce orders gate themselves through requirements_met() or
	 * is_dependency_active().
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return defined( 'CARTFLOWS_FILE' );
	}
}
