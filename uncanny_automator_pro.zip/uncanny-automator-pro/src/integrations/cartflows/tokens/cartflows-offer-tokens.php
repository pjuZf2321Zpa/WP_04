<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows\Tokens;

use WC_Order;

/**
 * Class Cartflows_Offer_Tokens
 *
 * Token definitions and hydration shared by the offer-accepted and
 * offer-rejected triggers.
 *
 * The two sets are deliberately not identical. On the accept path CartFlows
 * resolves the offer with the customer's actual selection —
 * `get_offer_data( $step_id, $variation_id, $input_qty, $order_id )` in
 * `Cartflows_Pro_Flow_Frontend::after_offer_charge()` — so quantity and pricing
 * reflect what was charged. On the reject path it resolves with the step alone,
 * `get_offer_data( $step_id )` in `Cartflows_Pro_Base_Offer_Markup::offer_rejected()`,
 * so quantity and price would only ever echo the step's defaults, not anything
 * the customer saw or declined. Rather than publish tokens that quietly mean
 * something different per trigger, the reject set omits them.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows\Tokens
 */
class Cartflows_Offer_Tokens {

	/**
	 * Tokens for the offer-accepted trigger.
	 *
	 * @return array
	 */
	public function accepted_tokens() {

		return array_merge(
			$this->shared_tokens(),
			array(
				array(
					'tokenId'   => 'CF_ORDER_TOTAL',
					'tokenName' => esc_html_x( 'Order total', 'CartFlows', 'uncanny-automator-pro' ),
					'tokenType' => 'float',
				),
				array(
					'tokenId'   => 'CF_OFFER_QUANTITY',
					'tokenName' => esc_html_x( 'Offer quantity', 'CartFlows', 'uncanny-automator-pro' ),
					'tokenType' => 'int',
				),
				array(
					'tokenId'   => 'CF_OFFER_ORIGINAL_PRICE',
					'tokenName' => esc_html_x( 'Offer original price', 'CartFlows', 'uncanny-automator-pro' ),
					'tokenType' => 'float',
				),
				array(
					'tokenId'   => 'CF_OFFER_UNIT_PRICE',
					'tokenName' => esc_html_x( 'Offer discounted unit price', 'CartFlows', 'uncanny-automator-pro' ),
					'tokenType' => 'float',
				),
				array(
					'tokenId'   => 'CF_CUSTOMER_NAME',
					'tokenName' => esc_html_x( 'Customer name', 'CartFlows', 'uncanny-automator-pro' ),
					'tokenType' => 'text',
				),
			)
		);
	}

	/**
	 * Tokens for the offer-rejected trigger.
	 *
	 * @return array
	 */
	public function rejected_tokens() {
		return $this->shared_tokens();
	}

	/**
	 * Tokens both offer triggers publish.
	 *
	 * @return array
	 */
	private function shared_tokens() {

		return array(
			array(
				'tokenId'   => 'CF_ORDER_ID',
				'tokenName' => esc_html_x( 'Order ID', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'int',
			),
			array(
				'tokenId'   => 'CF_OFFER_TYPE',
				'tokenName' => esc_html_x( 'Offer type', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CF_OFFER_PRODUCT_ID',
				'tokenName' => esc_html_x( 'Offer product ID', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'int',
			),
			array(
				'tokenId'   => 'CF_OFFER_PRODUCT_NAME',
				'tokenName' => esc_html_x( 'Offer product name', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CF_OFFER_STEP_ID',
				'tokenName' => esc_html_x( 'Offer step ID', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'int',
			),
			array(
				'tokenId'   => 'CF_OFFER_STEP_TITLE',
				'tokenName' => esc_html_x( 'Offer step title', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CF_FLOW_ID',
				'tokenName' => esc_html_x( 'Flow ID', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'int',
			),
			array(
				'tokenId'   => 'CF_FLOW_TITLE',
				'tokenName' => esc_html_x( 'Flow title', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'CF_CUSTOMER_EMAIL',
				'tokenName' => esc_html_x( 'Customer email', 'CartFlows', 'uncanny-automator-pro' ),
				'tokenType' => 'email',
			),
		);
	}

	/**
	 * Hydrate the offer-accepted tokens.
	 *
	 * @param int    $order_id      The order ID.
	 * @param int    $step_id       The offer step ID.
	 * @param string $step_type     The offer type slug.
	 * @param int    $flow_id       The funnel ID.
	 * @param array  $offer_product The offer payload.
	 *
	 * @return array
	 */
	public function hydrate_accepted( $order_id, $step_id, $step_type, $flow_id, $offer_product ) {

		$tokens = $this->hydrate_rejected( $order_id, $step_id, $step_type, $flow_id, $offer_product );

		$tokens['CF_ORDER_TOTAL']          = '';
		$tokens['CF_CUSTOMER_NAME']        = '';
		$tokens['CF_OFFER_QUANTITY']       = absint( $offer_product['qty'] ?? 0 );
		$tokens['CF_OFFER_ORIGINAL_PRICE'] = (string) ( $offer_product['original_price'] ?? '' );
		$tokens['CF_OFFER_UNIT_PRICE']     = (string) ( $offer_product['unit_price'] ?? '' );

		$order = $this->get_order( $order_id );

		if ( $order instanceof WC_Order ) {
			$tokens['CF_ORDER_TOTAL']   = (string) $order->get_total();
			$tokens['CF_CUSTOMER_NAME'] = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		}

		return $tokens;
	}

	/**
	 * Hydrate the offer-rejected tokens.
	 *
	 * Returns the full keyset even when the order cannot be read, so a recipe
	 * never resolves a partial map.
	 *
	 * @param int    $order_id      The order ID.
	 * @param int    $step_id       The offer step ID.
	 * @param string $step_type     The offer type slug.
	 * @param int    $flow_id       The funnel ID.
	 * @param array  $offer_product The offer payload.
	 *
	 * @return array
	 */
	public function hydrate_rejected( $order_id, $step_id, $step_type, $flow_id, $offer_product ) {

		$order_id = absint( $order_id );
		$step_id  = absint( $step_id );
		$flow_id  = absint( $flow_id );

		$offer_product = is_array( $offer_product ) ? $offer_product : array();

		$tokens = array(
			'CF_ORDER_ID'           => $order_id,
			'CF_OFFER_TYPE'         => (string) $step_type,
			'CF_OFFER_PRODUCT_ID'   => absint( $offer_product['id'] ?? 0 ),
			'CF_OFFER_PRODUCT_NAME' => (string) ( $offer_product['name'] ?? '' ),
			'CF_OFFER_STEP_ID'      => $step_id,
			'CF_OFFER_STEP_TITLE'   => 0 === $step_id ? '' : (string) get_the_title( $step_id ),
			'CF_FLOW_ID'            => $flow_id,
			'CF_FLOW_TITLE'         => 0 === $flow_id ? '' : (string) get_the_title( $flow_id ),
			'CF_CUSTOMER_EMAIL'     => '',
		);

		$order = $this->get_order( $order_id );

		if ( $order instanceof WC_Order ) {
			$tokens['CF_CUSTOMER_EMAIL'] = (string) $order->get_billing_email();
		}

		return $tokens;
	}

	/**
	 * Resolve an order, tolerating a missing WooCommerce.
	 *
	 * @param int $order_id The order ID.
	 *
	 * @return WC_Order|false
	 */
	private function get_order( $order_id ) {

		if ( ! function_exists( 'wc_get_order' ) ) {
			return false;
		}

		return wc_get_order( absint( $order_id ) );
	}
}
