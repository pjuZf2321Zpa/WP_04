<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows;

use Uncanny_Automator\Recipe\Action;

/**
 * Class Cartflows_Add_Product_To_Checkout_Step
 *
 * Adds a WooCommerce product to a CartFlows checkout step's product list.
 *
 * The list lives on the step's `wcf-checkout-products` post meta as an array of
 * rows. The row shape is not "product ID plus quantity" — CartFlows 3.2.0
 * writes six keys (`Cartflows_Ability_Runtime::update_checkout_products()`), and the
 * funnel editor keys rows on `unique_id`, so a row written without one is saved
 * but is not editable in the CartFlows UI. Row construction is centralized in
 * Cartflows_Pro_Helpers::build_checkout_product_row() for that reason.
 *
 * Adding a product the step already carries updates that row's quantity rather
 * than appending a duplicate.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows
 *
 * @property Cartflows_Pro_Helpers $item_helpers
 */
class Cartflows_Add_Product_To_Checkout_Step extends Action {

	/**
	 * Option code of the checkout-step field.
	 */
	const CHECKOUT_STEP = 'CARTFLOWS_CHECKOUT_STEP';

	/**
	 * Option code of the quantity field.
	 */
	const QUANTITY = 'CARTFLOWS_QUANTITY';

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CARTFLOWS' );
		$this->set_action_code( 'CARTFLOWS_ADD_PRODUCT_TO_CHECKOUT_STEP' );
		$this->set_action_meta( 'CARTFLOWS_PRODUCT' );
		$this->set_is_pro( true );
		// Writes post meta on a funnel step, no recipe user needed.
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: 1: WooCommerce product, 2: CartFlows checkout step */
				esc_html_x( 'Add {{a product:%1$s}} to {{a checkout step:%2$s}}', 'CartFlows', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				// Secondary options are addressed as OPTION_CODE:ACTION_META. A bare
				// code does not bind to the field, so the builder renders the
				// placeholder as inert text instead of an editable token.
				self::CHECKOUT_STEP . ':' . $this->get_action_meta()
			)
		);

		$this->set_readable_sentence( esc_html_x( 'Add {{a product}} to {{a checkout step}}', 'CartFlows', 'uncanny-automator-pro' ) );
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'     => $this->get_action_meta(),
				'label'           => esc_html_x( 'Product', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options'         => array(),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'products_strict' ),
			),
			array(
				'option_code'     => self::CHECKOUT_STEP,
				'label'           => esc_html_x( 'Checkout step', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options'         => array(),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'checkout_steps_strict' ),
			),
			array(
				'option_code'     => self::QUANTITY,
				'label'           => esc_html_x( 'Quantity', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'      => 'int',
				'required'        => false,
				'default_value'   => 1,
				'supports_tokens' => true,
			),
		);
	}

	/**
	 * Define output tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'CARTFLOWS_STEP_ID'      => array(
				'name' => esc_html_x( 'Step ID', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'CARTFLOWS_PRODUCT_ID'   => array(
				'name' => esc_html_x( 'Product ID', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'CARTFLOWS_PRODUCT_NAME' => array(
				'name' => esc_html_x( 'Product name', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id     The user ID.
	 * @param array $action_data The action data.
	 * @param int   $recipe_id   The recipe ID.
	 * @param array $args        The args.
	 * @param array $parsed      The parsed options.
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! defined( 'CARTFLOWS_STEP_POST_TYPE' ) ) {
			$this->add_log_error( esc_html_x( 'CartFlows is not active.', 'CartFlows', 'uncanny-automator-pro' ) );
			return false;
		}

		if ( ! $this->item_helpers->woocommerce_active() ) {
			$this->add_log_error( esc_html_x( 'WooCommerce is not active.', 'CartFlows', 'uncanny-automator-pro' ) );
			return false;
		}

		$product_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		$step_id    = absint( $parsed[ self::CHECKOUT_STEP ] ?? 0 );
		// intval, not absint — a negative token value must clamp to 1, not flip
		// sign into a large quantity.
		$quantity = max( 1, intval( $parsed[ self::QUANTITY ] ?? 1 ) );

		if ( 0 === $step_id || CARTFLOWS_STEP_POST_TYPE !== get_post_type( $step_id ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Step ID */
					esc_html_x( 'Step not found: [%1$d].', 'CartFlows', 'uncanny-automator-pro' ),
					$step_id
				)
			);
			return false;
		}

		// The product list is only read on checkout steps — writing it onto an
		// optin or thank-you step would store meta CartFlows never looks at.
		$step_type = $this->item_helpers->get_step_type( $step_id );

		if ( 'checkout' !== $step_type ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Step ID, 2: Step type slug */
					esc_html_x( 'Step [%1$d] is a %2$s step, not a checkout step.', 'CartFlows', 'uncanny-automator-pro' ),
					$step_id,
					'' === $step_type ? esc_html_x( 'typeless', 'CartFlows', 'uncanny-automator-pro' ) : $step_type
				)
			);
			return false;
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Product ID */
					esc_html_x( 'WooCommerce product not found: [%1$d].', 'CartFlows', 'uncanny-automator-pro' ),
					$product_id
				)
			);
			return false;
		}

		$products = $this->item_helpers->get_checkout_products( $step_id );
		$existing = $products;
		$matched  = false;

		foreach ( $products as $index => $row ) {

			if ( absint( $row['product'] ?? 0 ) !== $product_id ) {
				continue;
			}

			$products[ $index ]['quantity'] = $quantity;
			$matched                        = true;
			break;
		}

		if ( false === $matched ) {
			$products[] = $this->item_helpers->build_checkout_product_row( $product_id, $quantity, count( $products ) );
		}

		// update_post_meta() returns false both on failure and when the stored
		// value is unchanged, so re-adding a product at its current quantity
		// would otherwise read as an error. Resolve the no-op first.
		if ( $existing === $products ) {
			$this->hydrate_result_tokens( $step_id, $product_id, $product->get_name() );
			return true;
		}

		if ( false === update_post_meta( $step_id, 'wcf-checkout-products', $products ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Step ID */
					esc_html_x( 'The product list for step [%1$d] could not be updated.', 'CartFlows', 'uncanny-automator-pro' ),
					$step_id
				)
			);
			return false;
		}

		$this->hydrate_result_tokens( $step_id, $product_id, $product->get_name() );

		return true;
	}

	/**
	 * Publish the action's output tokens.
	 *
	 * @param int    $step_id      The checkout step ID.
	 * @param int    $product_id   The product ID.
	 * @param string $product_name The product name.
	 *
	 * @return void
	 */
	private function hydrate_result_tokens( $step_id, $product_id, $product_name ) {
		$this->hydrate_tokens(
			array(
				'CARTFLOWS_STEP_ID'      => absint( $step_id ),
				'CARTFLOWS_PRODUCT_ID'   => absint( $product_id ),
				'CARTFLOWS_PRODUCT_NAME' => (string) $product_name,
			)
		);
	}
}
