<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows;

use Uncanny_Automator\Recipe\Action;

/**
 * Class Cartflows_Clone_Step
 *
 * Duplicates a CartFlows step and attaches the copy to a funnel.
 *
 * Two design notes worth keeping:
 *
 * 1. The funnel is an explicit field, not something derived from the source
 *    step. CartFlows' own user-facing clone route takes both
 *    (`Cartflows_Admin_Ajax::clone_step()`), and cloning into a different funnel is
 *    the more useful half of the feature — reusing a proven checkout step
 *    across funnels.
 *
 * 2. The work is done by Cartflows_Pro_Helpers::clone_step_into_flow() rather
 *    than `wcf_pro()->utils->clone_step()`. That CartFlows Pro helper copies the
 *    post, taxonomies and meta and then stops — it never writes the funnel's own
 *    `wcf-steps` array, so a step cloned through it exists in the database but
 *    never appears inside a funnel. Doing the full sequence ourselves also drops
 *    the CartFlows Pro requirement: the step post type and the funnel meta are
 *    both CartFlows Free.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows
 *
 * @property Cartflows_Pro_Helpers $item_helpers
 */
class Cartflows_Clone_Step extends Action {

	/**
	 * Option code of the destination funnel field.
	 */
	const FLOW = 'CARTFLOWS_FLOW';

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {

		$this->set_integration( 'CARTFLOWS' );
		$this->set_action_code( 'CARTFLOWS_CLONE_STEP' );
		$this->set_action_meta( 'CARTFLOWS_STEP' );
		$this->set_is_pro( true );
		// Creates a post and updates funnel meta, no recipe user needed.
		$this->set_requires_user( false );

		// "Duplicate" is the corpus verb for this operation (Duplicate {{a page}} /
		// Duplicate {{a post}}); "Clone" appears nowhere else. The action code
		// stays CARTFLOWS_CLONE_STEP — codes are DB identifiers, not copy.
		$this->set_sentence(
			sprintf(
				/* translators: 1: CartFlows step, 2: CartFlows flow */
				esc_html_x( 'Duplicate {{a step:%1$s}} in {{a flow:%2$s}}', 'CartFlows', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				// Secondary options are addressed as OPTION_CODE:ACTION_META. A bare
				// code does not bind to the field, so the builder renders the
				// placeholder as inert text instead of an editable token.
				self::FLOW . ':' . $this->get_action_meta()
			)
		);

		$this->set_readable_sentence( esc_html_x( 'Duplicate {{a step}} in {{a flow}}', 'CartFlows', 'uncanny-automator-pro' ) );
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'     => $this->get_action_meta(),
				'label'           => esc_html_x( 'Step', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options'         => array(),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'steps_strict' ),
			),
			array(
				'option_code'     => self::FLOW,
				'label'           => esc_html_x( 'Flow', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options'         => array(),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'flows_strict' ),
			),
		);
	}

	/**
	 * Define output tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'CARTFLOWS_CLONED_STEP_ID'    => array(
				'name' => esc_html_x( 'New step ID', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'CARTFLOWS_CLONED_STEP_TITLE' => array(
				'name' => esc_html_x( 'New step title', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'CARTFLOWS_CLONED_STEP_TYPE'  => array(
				'name' => esc_html_x( 'New step type', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'CARTFLOWS_CLONED_STEP_URL'   => array(
				'name' => esc_html_x( 'New step URL', 'CartFlows', 'uncanny-automator-pro' ),
				'type' => 'url',
			),
		);
	}

	/**
	 * Process action.
	 *
	 * @param int   $user_id     The user ID.
	 * @param array $action_data The action data.
	 * @param int   $recipe_id   The recipe ID.
	 * @param array $args        The args.
	 * @param array $parsed      The parsed options.
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		// Every CartFlows constant this action reaches: the two post types here,
		// and the two taxonomies inside attach_step_to_flow(). CartFlows defines
		// all four together, so one failed check means it is not loaded.
		if ( ! defined( 'CARTFLOWS_STEP_POST_TYPE' )
			|| ! defined( 'CARTFLOWS_FLOW_POST_TYPE' )
			|| ! defined( 'CARTFLOWS_TAXONOMY_STEP_TYPE' )
			|| ! defined( 'CARTFLOWS_TAXONOMY_STEP_FLOW' ) ) {
			$this->add_log_error( esc_html_x( 'CartFlows is not active.', 'CartFlows', 'uncanny-automator-pro' ) );
			return false;
		}

		$step_id = absint( $parsed[ $this->get_action_meta() ] ?? 0 );
		$flow_id = absint( $parsed[ self::FLOW ] ?? 0 );

		if ( 0 === $step_id || CARTFLOWS_STEP_POST_TYPE !== get_post_type( $step_id ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Step ID */
					esc_html_x( 'Step not found: [%1$d].', 'CartFlows', 'uncanny-automator-pro' ),
					$step_id
				)
			);
			return false;
		}

		if ( 0 === $flow_id || CARTFLOWS_FLOW_POST_TYPE !== get_post_type( $flow_id ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Flow ID */
					esc_html_x( 'Flow not found: [%1$d].', 'CartFlows', 'uncanny-automator-pro' ),
					$flow_id
				)
			);
			return false;
		}

		$step_type = $this->item_helpers->get_step_type( $step_id );

		// Upsell and downsell steps only render with CartFlows Pro, so cloning
		// one onto a Free-only site would produce a step the funnel cannot show.
		if ( $this->item_helpers->is_offer_step_type( $step_type ) && ! $this->item_helpers->cartflows_pro_active() ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Step type, e.g. Upsell */
					esc_html_x( '%1$s steps require CartFlows Pro.', 'CartFlows', 'uncanny-automator-pro' ),
					ucfirst( $step_type )
				)
			);
			return false;
		}

		$new_step_id = $this->item_helpers->clone_step_into_flow( $step_id, $flow_id );

		if ( is_wp_error( $new_step_id ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: Error message returned by WordPress */
					esc_html_x( 'Could not duplicate the step: %1$s', 'CartFlows', 'uncanny-automator-pro' ),
					$new_step_id->get_error_message()
				)
			);
			return false;
		}

		$this->hydrate_tokens(
			array(
				'CARTFLOWS_CLONED_STEP_ID'    => absint( $new_step_id ),
				'CARTFLOWS_CLONED_STEP_TITLE' => (string) get_the_title( $new_step_id ),
				'CARTFLOWS_CLONED_STEP_TYPE'  => (string) $step_type,
				'CARTFLOWS_CLONED_STEP_URL'   => (string) get_permalink( $new_step_id ),
			)
		);

		return true;
	}
}
