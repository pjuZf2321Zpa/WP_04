<?php

namespace Uncanny_Automator_Pro\Integrations\Cartflows;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator_Pro\Integrations\Cartflows\Dispatchers\Cartflows_Offer_Dispatcher;
use Uncanny_Automator_Pro\Integrations\Cartflows\Tokens\Cartflows_Offer_Tokens;
use WC_Order;

/**
 * Class Cartflows_User_Rejects_Offer
 *
 * Fires when a customer declines an upsell or a downsell — the "No thanks"
 * path. CartFlows Pro emits `cartflows_offer_rejected` for both offer types
 * (`Cartflows_Pro_Base_Offer_Markup::offer_rejected()`), so one trigger with an
 * offer-type selector covers both; the per-type variants next to it are built
 * at runtime from the step type and cannot be registered against.
 *
 * Listens on the normalized
 * `automator_cartflows_offer_rejected( int $order_id, int $step_id, string $step_type, int $flow_id, array $offer_product )`
 * emitted by Cartflows_Offer_Dispatcher.
 *
 * Anonymous rather than user-scoped, for the same reason as its accept twin:
 * the offer belongs to an order, which may well be a guest order.
 *
 * @package Uncanny_Automator_Pro\Integrations\Cartflows
 *
 * @property Cartflows_Pro_Helpers $item_helpers
 */
class Cartflows_User_Rejects_Offer extends Trigger {

	/**
	 * Option code of the funnel filter.
	 */
	const FLOW = 'CARTFLOWS_FLOW';

	/**
	 * Opt this trigger into the lazy loading path.
	 *
	 * @return \Uncanny_Automator\Recipe\Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'CARTFLOWS_OFFER_REJECTED', 'CARTFLOWS' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'CARTFLOWS_OFFER' )
			->hook( 'automator_cartflows_offer_rejected', 10, 5 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* translators: 1: Offer type, 2: CartFlows flow */
				esc_html_x( '{{An offer:%1$s}} is rejected in {{a flow:%2$s}}', 'CartFlows', 'uncanny-automator-pro' ),
				$this->get_trigger_meta(),
				// A trigger's secondary options are addressed as OPTION_CODE:TRIGGER_META.
				// A bare code does not bind to the field, so the builder renders the
				// placeholder as inert text instead of an editable token.
				self::FLOW . ':' . $this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence( esc_html_x( '{{An offer}} is rejected in {{a flow}}', 'CartFlows', 'uncanny-automator-pro' ) );
	}

	/**
	 * Offer steps are a CartFlows Pro feature, and the payload is a WooCommerce
	 * order.
	 *
	 * @return bool
	 */
	public function requirements_met() {
		return $this->item_helpers->woocommerce_active() && $this->item_helpers->cartflows_pro_active();
	}

	/**
	 * Trigger options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'           => $this->get_trigger_meta(),
				'label'                 => esc_html_x( 'Offer', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'            => 'select',
				'required'              => true,
				'options_show_id'       => false,
				'supports_custom_value' => false,
				'options'               => $this->item_helpers->get_offer_type_options(),
			),
			array(
				'option_code'     => self::FLOW,
				'label'           => esc_html_x( 'Flow', 'CartFlows', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options'         => array(),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'flows' ),
			),
		);
	}

	/**
	 * Validate the offer type and funnel, then bind the buyer.
	 *
	 * @param array $trigger   The trigger.
	 * @param array $hook_args The hook arguments.
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		$order_id  = isset( $hook_args[0] ) ? absint( $hook_args[0] ) : 0;
		$step_type = isset( $hook_args[2] ) ? (string) $hook_args[2] : '';
		$flow_id   = isset( $hook_args[3] ) ? absint( $hook_args[3] ) : 0;

		if ( 0 === $order_id || '' === $step_type ) {
			return false;
		}

		$selected_offer = (string) ( $trigger['meta'][ $this->get_trigger_meta() ] ?? Cartflows_Pro_Helpers::ANY );

		if ( Cartflows_Pro_Helpers::ANY !== $selected_offer && $selected_offer !== $step_type ) {
			return false;
		}

		$selected_flow = (string) ( $trigger['meta'][ self::FLOW ] ?? Cartflows_Pro_Helpers::ANY );

		if ( Cartflows_Pro_Helpers::ANY !== $selected_flow && absint( $selected_flow ) !== $flow_id ) {
			return false;
		}

		$this->set_user_id( $this->resolve_user_id( $order_id ) );

		return true;
	}

	/**
	 * Resolve the buyer: the order's customer, falling back to whoever is logged
	 * in. Genuine guest checkouts resolve to 0, which anonymous recipes accept.
	 *
	 * @param int $order_id The order ID.
	 *
	 * @return int
	 */
	private function resolve_user_id( $order_id ) {

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( absint( $order_id ) ) : false;

		if ( $order instanceof WC_Order && 0 !== absint( $order->get_customer_id() ) ) {
			return absint( $order->get_customer_id() );
		}

		return absint( get_current_user_id() );
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger The trigger.
	 * @param array $tokens  The tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, ( new Cartflows_Offer_Tokens() )->rejected_tokens() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   The trigger.
	 * @param array $hook_args The hook arguments.
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		return ( new Cartflows_Offer_Tokens() )->hydrate_rejected(
			isset( $hook_args[0] ) ? absint( $hook_args[0] ) : 0,
			isset( $hook_args[1] ) ? absint( $hook_args[1] ) : 0,
			isset( $hook_args[2] ) ? (string) $hook_args[2] : '',
			isset( $hook_args[3] ) ? absint( $hook_args[3] ) : 0,
			isset( $hook_args[4] ) ? (array) $hook_args[4] : array()
		);
	}
}
