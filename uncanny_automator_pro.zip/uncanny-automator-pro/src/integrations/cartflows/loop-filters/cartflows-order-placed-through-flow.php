<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Integrations\Cartflows\Cartflows_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Loop filter: An order placed through {{a flow}}.
 *
 * Narrows an order loop to the WooCommerce orders that originated in a given
 * CartFlows funnel — the loopable twin of the condition by the same name, for
 * "do something to every order this funnel produced" recipes.
 *
 * Uses the `posts` loop type even though HPOS stores orders in their own
 * tables: the loop framework's `posts` type is what every WooCommerce order
 * filter in Pro already resolves against (see WC_ORDER_STATUS), and entities
 * are returned as order IDs either way.
 *
 * @property Cartflows_Pro_Helpers $item_helpers
 *
 * @package Uncanny_Automator_Pro\Loop_Filters
 */
class CARTFLOWS_ORDER_PLACED_THROUGH_FLOW extends Loop_Filter {

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function setup() {

		$this->set_integration( 'CARTFLOWS' );
		$this->set_meta( 'CARTFLOWS_ORDER_PLACED_THROUGH_FLOW' );

		// Participial, matching the corpus shape for order loop filters
		// ("An order placed between {{start date}} and {{end date}}") — a loop
		// filter names the set it selects, it does not assert a past event.
		$this->set_sentence( esc_html_x( 'An order placed through {{a flow}}', 'CartFlows', 'uncanny-automator-pro' ) );

		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: CartFlows flow */
				esc_html_x( 'An order placed through {{a flow:%1$s}}', 'CartFlows', 'uncanny-automator-pro' ),
				$this->get_meta()
			)
		);

		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_loop_type( 'posts' );
		$this->set_entities( array( $this, 'retrieve_orders_from_flow' ) );
	}

	/**
	 * WooCommerce is required as well as CartFlows — this queries orders.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return defined( 'CARTFLOWS_FILE' ) && function_exists( 'WC' );
	}

	/**
	 * @return mixed[]
	 */
	public function load_options() {
		return array(
			$this->get_meta() => array(
				array(
					'option_code' => $this->get_meta(),
					'type'        => 'select',
					'label'       => esc_html_x( 'Flow', 'CartFlows', 'uncanny-automator-pro' ),
					'required'    => true,
					'options'     => array(),
					// Strict (no "Any flow"): the sentinel would widen the loop
					// to every order on the site, which is what an unfiltered
					// loop already does.
					'remote_data' => $this->item_helpers->remote_data_load_config( 'flows_strict' ),
				),
			),
		);
	}

	/**
	 * Resolve the orders placed through the selected funnel.
	 *
	 * @param array{CARTFLOWS_ORDER_PLACED_THROUGH_FLOW:string} $fields The filter fields.
	 *
	 * @return int[]
	 */
	public function retrieve_orders_from_flow( $fields ) {

		$flow_id = absint( $fields[ $this->get_meta() ] ?? 0 );

		if ( 0 === $flow_id || ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$orders = wc_get_orders(
			array(
				'return'     => 'ids',
				'limit'      => 99999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_numberposts
				'status'     => array_keys( wc_get_order_statuses() ),
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_wcf_flow_id',
						'value'   => (string) $flow_id,
						'compare' => '=',
					),
				),
			)
		);

		return is_array( $orders ) ? array_map( 'absint', $orders ) : array();
	}
}
