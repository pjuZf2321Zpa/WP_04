<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Affwp_Helpers;

/**
 * Class Affwp_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Affwp_Pro_Helpers extends Affwp_Helpers {

	/**
	 * @param Affwp_Pro_Helpers $pro
	 */
	public function setPro( \Uncanny_Automator_Pro\Affwp_Pro_Helpers $pro ) {
		$this->pro = $pro;
	}

	/**
	 * Affwp_Pro_Helpers constructor.
	 */
	public function __construct() {
	}

	/**
	 * Select all WooCommerce products
	 *
	 * @param null $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed|void
	 */
	public function get_wc_products( $label = null, $option_code = 'WCPRODUCTS', $args = array() ) {
		if ( ! $label ) {
			$label = __( 'Product', 'uncanny-automator-pro' );
		}

		$token        = key_exists( 'token', $args ) ? $args['token'] : false;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';
		$any_option   = key_exists( 'any_option', $args ) ? $args['any_option'] : false;

		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => 999,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'post_status'    => 'publish',
		);

		$options = Automator()->helpers->recipe->options->wp_query( $args, $any_option, esc_attr__( 'Any product', 'uncanny-automator' ) );

		$option = array(
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'supports_tokens' => $token,
			'is_ajax'         => $is_ajax,
			'fill_values_in'  => $target_field,
			'endpoint'        => $end_point,
			'options'         => $options,
		);

		return apply_filters( 'uap_option_get_wc_products', $option );
	}

	/**
	 * Select all MemberPress products
	 *
	 * @param null $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed|void
	 */
	public function get_mp_products( $label = null, $option_code = 'MPPRODUCTS', $args = array() ) {
		if ( ! $label ) {
			$label = __( 'Product', 'uncanny-automator-pro' );
		}

		$token        = key_exists( 'token', $args ) ? $args['token'] : false;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';
		$any_option   = key_exists( 'any_option', $args ) ? $args['any_option'] : false;

		$args = array(
			'post_type'      => 'memberpressproduct',
			'posts_per_page' => 999,
			'post_status'    => 'publish',
		);

		$options = Automator()->helpers->recipe->options->wp_query( $args, $any_option, esc_attr__( 'Any product', 'uncanny-automator' ) );

		$option = array(
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'supports_tokens' => $token,
			'is_ajax'         => $is_ajax,
			'fill_values_in'  => $target_field,
			'endpoint'        => $end_point,
			'options'         => $options,
		);

		return apply_filters( 'uap_option_get_mp_products', $option );
	}

	/**
	 * Select all Easy Digital Downloads products
	 *
	 * @param null $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed|void
	 */
	public function get_edd_products( $label = null, $option_code = 'EDDPRODUCTS', $args = array() ) {
		if ( ! $label ) {
			$label = __( 'Product', 'uncanny-automator-pro' );
		}

		$token        = key_exists( 'token', $args ) ? $args['token'] : false;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';
		$any_option   = key_exists( 'any_option', $args ) ? $args['any_option'] : false;

		$args = array(
			'post_type'      => 'download',
			'posts_per_page' => 999,
			'post_status'    => 'publish',
		);

		$options = Automator()->helpers->recipe->options->wp_query( $args, $any_option, esc_attr__( 'Any product', 'uncanny-automator' ) );

		$option = array(
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'supports_tokens' => $token,
			'is_ajax'         => $is_ajax,
			'fill_values_in'  => $target_field,
			'endpoint'        => $end_point,
			'options'         => $options,
		);

		return apply_filters( 'uap_option_get_edd_products', $option );
	}

	/**
	 * @param null $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed|void
	 */
	public function get_affiliates( $label = null, $option_code = 'ALLAFFILIATES', $args = array() ) {
		if ( ! $label ) {
			$label = __( 'Affiliate', 'uncanny-automator-pro' );
		}

		$token        = key_exists( 'token', $args ) ? $args['token'] : true;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';
		$any_option   = key_exists( 'any_option', $args ) ? $args['any_option'] : false;
		$options      = array();

		if ( $any_option ) {
			$options['-1'] = esc_attr__( 'Any affiliate', 'uncanny-automator-pro' );
		}

		global $wpdb;
		$affiliates = $wpdb->get_results( "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_affiliates" );

		if ( is_array( $affiliates ) ) {
			foreach ( $affiliates as $affiliate ) {
				$options[ $affiliate->affiliate_id ] = affwp_get_affiliate_name( $affiliate->affiliate_id );
			}
		}

		$option = array(
			'option_code'           => $option_code,
			'label'                 => $label,
			'input_type'            => 'select',
			'required'              => true,
			'supports_tokens'       => $token,
			'supports_custom_value' => true,
			'is_ajax'               => $is_ajax,
			'fill_values_in'        => $target_field,
			'endpoint'              => $end_point,
			'options'               => $options,
		);

		return apply_filters( 'uap_option_get_affiliates', $option );
	}

	/**
	 * Get comparison conditions for select fields.
	 *
	 * @return array
	 */
	public static function get_comparison_conditions() {
		return array(
			array(
				'text'  => esc_attr_x( 'is equal to', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'is',
			),
			array(
				'text'  => esc_attr_x( 'is not equal to', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'is-not',
			),
			array(
				'text'  => esc_attr_x( 'is less than', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'less-than',
			),
			array(
				'text'  => esc_attr_x( 'is greater than', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'greater-than',
			),
			array(
				'text'  => esc_attr_x( 'is greater than or equal to', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'greater-than-or-equal-to',
			),
			array(
				'text'  => esc_attr_x( 'is less than or equal to', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'less-than-or-equal-to',
			),
		);
	}

	/**
	 * Convert a comparison condition slug to its SQL operator symbol.
	 *
	 * @param string $condition The condition slug.
	 *
	 * @return string|null
	 */
	public static function create_comparison_symbol( $condition ) {
		$symbols = array(
			'is'                       => '=',
			'is-not'                   => '!=',
			'less-than'                => '<',
			'greater-than'             => '>',
			'less-than-or-equal-to'    => '<=',
			'greater-than-or-equal-to' => '>=',
		);

		return isset( $symbols[ $condition ] ) ? $symbols[ $condition ] : null;
	}

	/**
	 * Compare two numeric values using the given symbol.
	 *
	 * @param mixed  $a      The left-hand value.
	 * @param string $symbol The comparison operator.
	 * @param mixed  $b      The right-hand value.
	 *
	 * @return bool
	 */
	public static function compare_values( $a, $symbol, $b ) {
		switch ( $symbol ) {
			case '=':
				return $a == $b;
			case '!=':
				return $a != $b;
			case '<':
				return $a < $b;
			case '>':
				return $a > $b;
			case '<=':
				return $a <= $b;
			case '>=':
				return $a >= $b;
			default:
				return false;
		}
	}

	/**
	 * Get is/is-not options for select fields.
	 *
	 * @return array
	 */
	public static function get_is_is_not_options() {
		return array(
			array(
				'text'  => esc_html_x( 'is', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'is',
			),
			array(
				'text'  => esc_html_x( 'is not', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'is-not',
			),
		);
	}

	/**
	 * Get affiliate status options from AffiliateWP.
	 *
	 * @return array
	 */
	public static function get_affiliate_status_options() {
		if ( ! function_exists( 'affwp_get_affiliate_statuses' ) ) {
			return array();
		}

		$statuses = affwp_get_affiliate_statuses();
		$options  = array();

		foreach ( $statuses as $value => $label ) {
			$options[] = array(
				'value' => $value,
				'text'  => $label,
			);
		}

		return $options;
	}

	/**
	 * Get referral status options from AffiliateWP.
	 *
	 * @return array
	 */
	public static function get_referral_status_options() {
		if ( ! function_exists( 'affwp_get_referral_statuses' ) ) {
			return array();
		}

		$statuses = affwp_get_referral_statuses();
		$options  = array();

		foreach ( $statuses as $value => $label ) {
			$options[] = array(
				'value' => $value,
				'text'  => $label,
			);
		}

		return $options;
	}

	/**
	 * Get referral type options.
	 *
	 * @return array
	 */
	public static function get_referral_type_options() {
		return array(
			array(
				'text'  => esc_html_x( 'Sale', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'sale',
			),
			array(
				'text'  => esc_html_x( 'Opt-in', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'opt-in',
			),
			array(
				'text'  => esc_html_x( 'Lead', 'AffiliateWP', 'uncanny-automator-pro' ),
				'value' => 'lead',
			),
		);
	}

	/**
	 * Map affiliate IDs to their corresponding WP user IDs.
	 *
	 * @param array $affiliate_ids The affiliate IDs to map.
	 *
	 * @return array
	 */
	public static function affiliate_ids_to_user_ids( $affiliate_ids ) {
		$user_ids = array();

		foreach ( $affiliate_ids as $affiliate_id ) {
			$user_id = affwp_get_affiliate_user_id( $affiliate_id );
			if ( ! empty( $user_id ) ) {
				$user_ids[] = $user_id;
			}
		}

		return $user_ids;
	}
}
