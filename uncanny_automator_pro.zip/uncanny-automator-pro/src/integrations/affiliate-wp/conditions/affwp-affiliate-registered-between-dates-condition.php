<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_AFFILIATE_REGISTERED_BETWEEN_DATES_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_AFFILIATE_REGISTERED_BETWEEN_DATES_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( 'An affiliate registered between {{a start date}} and {{an end date}}', 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_REGISTERED_BETWEEN_DATES_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Start date, %2$s: End date */
			esc_html_x( 'An affiliate registered between {{a start date:%1$s}} and {{an end date:%2$s}}', 'AffiliateWP', 'uncanny-automator-pro' ),
			'START_DATE',
			'END_DATE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->text(
				array(
					'option_code' => 'START_DATE',
					'label'       => esc_html_x( 'Start date', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'input_type'  => 'date',
				)
			),
			$this->field->text(
				array(
					'option_code' => 'END_DATE',
					'label'       => esc_html_x( 'End date', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'input_type'  => 'date',
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$start_date   = $this->get_parsed_option( 'START_DATE' );
		$end_date     = $this->get_parsed_option( 'END_DATE' );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( empty( $start_date ) || empty( $end_date ) ) {
			$this->condition_failed( esc_html_x( 'Start date and end date are required.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$affiliate = affwp_get_affiliate( $affiliate_id );

		if ( null === $affiliate || false === $affiliate ) {
			$this->condition_failed( esc_html_x( 'Affiliate data not found.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$registered = strtotime( $affiliate->date_registered );
		$start      = strtotime( $start_date );
		$end        = strtotime( $end_date );

		if ( false === $registered || false === $start || false === $end ) {
			$this->condition_failed( esc_html_x( 'Invalid date format.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( $start > $end ) {
			$this->condition_failed( esc_html_x( 'Start date must be before end date.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( $registered < $start || $registered > $end ) {
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Registration date, %2$s: Start date, %3$s: End date */
					esc_html_x( 'The affiliate registered on %1$s, which is not between %2$s and %3$s', 'AffiliateWP', 'uncanny-automator-pro' ),
					$affiliate->date_registered,
					$start_date,
					$end_date
				)
			);
		}
	}
}
