<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_EARNINGS_MEET_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_EARNINGS_MEET_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's {{paid/unpaid}} earnings meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_EARNINGS_MEET_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Earnings type, %2$s: Condition, %3$s: Value */
			esc_html_x( "An affiliate's {{paid/unpaid:%1\$s}} earnings {{is:%2\$s}} {{a value:%3\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'EARNINGS_TYPE',
			'CONDITION',
			'EARNINGS_VALUE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'EARNINGS_TYPE',
					'label'           => esc_html_x( 'Earnings type', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => array(
						array(
							'text'  => esc_attr_x( 'Paid', 'AffiliateWP', 'uncanny-automator-pro' ),
							'value' => 'paid',
						),
						array(
							'text'  => esc_attr_x( 'Unpaid', 'AffiliateWP', 'uncanny-automator-pro' ),
							'value' => 'unpaid',
						),
					),
					'options_show_id' => false,
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'     => 'CONDITION',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				)
			),
			$this->field->text(
				array(
					'option_code' => 'EARNINGS_VALUE',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'input_type'  => 'text',
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$earnings_type = $this->get_parsed_option( 'EARNINGS_TYPE' );
		$condition     = $this->get_parsed_option( 'CONDITION' );
		$value         = $this->get_parsed_option( 'EARNINGS_VALUE' );
		$symbol        = Affwp_Pro_Helpers::create_comparison_symbol( $condition );
		$affiliate_id  = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( ! is_numeric( $value ) || null === $symbol ) {
			$this->condition_failed( esc_html_x( 'Invalid condition or value.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( 'paid' === $earnings_type ) {
			$earnings = (float) affwp_get_affiliate_earnings( $affiliate_id );
		} else {
			$affiliate = affwp_get_affiliate( $affiliate_id );

			if ( null === $affiliate || false === $affiliate ) {
				$this->condition_failed( esc_html_x( 'Affiliate data not found.', 'AffiliateWP', 'uncanny-automator-pro' ) );
				return;
			}

			$earnings = (float) $affiliate->unpaid_earnings;
		}

		if ( false === Affwp_Pro_Helpers::compare_values( $earnings, $symbol, (float) $value ) ) {
			$readable_condition = $this->get_option( 'CONDITION_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Earnings type, %2$s: Earnings amount, %3$s: Condition, %4$s: Expected value */
					esc_html_x( "The affiliate's %1\$s earnings (%2\$s) does not meet the condition: %3\$s %4\$s", 'AffiliateWP', 'uncanny-automator-pro' ),
					$earnings_type,
					$earnings,
					$readable_condition,
					$value
				)
			);
		}
	}
}
