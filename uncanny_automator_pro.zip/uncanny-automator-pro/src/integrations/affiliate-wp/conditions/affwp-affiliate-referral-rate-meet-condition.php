<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_AFFILIATE_REFERRAL_RATE_MEET_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_AFFILIATE_REFERRAL_RATE_MEET_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's commission rate meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_REFERRAL_RATE_MEET_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Condition, %2$s: Value */
			esc_html_x( "An affiliate's commission rate {{is:%1\$s}} {{a value:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'CONDITION',
			'RATE_VALUE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'CONDITION',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				)
			),
			$this->field->text(
				array(
					'option_code'  => 'RATE_VALUE',
					'label'        => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'     => true,
					'input_type'   => 'text',
					'description'  => esc_html_x( 'Enter the rate as a decimal, e.g. 0.20 for 20%', 'AffiliateWP', 'uncanny-automator-pro' ),

				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$condition    = $this->get_parsed_option( 'CONDITION' );
		$value        = $this->get_parsed_option( 'RATE_VALUE' );
		$symbol       = Affwp_Pro_Helpers::create_comparison_symbol( $condition );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( ! is_numeric( $value ) || null === $symbol ) {
			$this->condition_failed( esc_html_x( 'Invalid condition or value.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$rate = (float) affwp_get_affiliate_rate( $affiliate_id );

		if ( false === Affwp_Pro_Helpers::compare_values( $rate, $symbol, (float) $value ) ) {
			$readable_condition = $this->get_option( 'CONDITION_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Rate, %2$s: Condition, %3$s: Expected value */
					esc_html_x( "The affiliate's commission rate (%1\$s) does not meet the condition: %2\$s %3\$s", 'AffiliateWP', 'uncanny-automator-pro' ),
					$rate,
					$readable_condition,
					$value
				)
			);
		}
	}
}
