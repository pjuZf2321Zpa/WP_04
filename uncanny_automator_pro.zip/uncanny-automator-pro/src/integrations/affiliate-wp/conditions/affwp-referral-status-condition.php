<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_REFERRAL_STATUS_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_REFERRAL_STATUS_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's most recent referral {{is/is not}} {{a status}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_REFERRAL_STATUS_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Criteria, %2$s: Status */
			esc_html_x( "An affiliate's most recent referral {{is/is not:%1\$s}} {{a status:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'CRITERIA',
			'STATUS'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'CRITERIA',
					'label'           => esc_html_x( 'Criteria', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_is_is_not_options(),
					'options_show_id' => false,
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'     => 'STATUS',
					'label'           => esc_html_x( 'Status', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_referral_status_options(),
					'options_show_id' => false,
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$criteria     = $this->get_parsed_option( 'CRITERIA' );
		$status       = $this->get_parsed_option( 'STATUS' );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		// Check the most recent referral for this affiliate.
		$referrals = affiliate_wp()->referrals->get_referrals(
			array(
				'number'       => 1,
				'affiliate_id' => $affiliate_id,
				'orderby'      => 'date',
				'order'        => 'DESC',
			)
		);

		if ( empty( $referrals ) ) {
			$this->condition_failed( esc_html_x( 'The affiliate has no referrals.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$current_status = $referrals[0]->status;
		$matches        = ( $status === $current_status );

		if ( ( 'is' === $criteria && ! $matches ) || ( 'is-not' === $criteria && $matches ) ) {
			$readable_status = $this->get_option( 'STATUS_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Current status, %2$s: Criteria, %3$s: Expected status */
					esc_html_x( 'The referral status is "%1$s" but expected %2$s "%3$s"', 'AffiliateWP', 'uncanny-automator-pro' ),
					$current_status,
					$criteria,
					$readable_status
				)
			);
		}
	}
}
