<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_AFFILIATE_REFERRAL_COUNT_MEET_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_AFFILIATE_REFERRAL_COUNT_MEET_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's {{referral count}} meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_REFERRAL_COUNT_MEET_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Referral status, %2$s: Condition, %3$s: Value */
			esc_html_x( "An affiliate's {{referral count:%1\$s}} {{is:%2\$s}} {{a value:%3\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'REFERRAL_STATUS',
			'CONDITION',
			'REFERRAL_COUNT_VALUE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'REFERRAL_STATUS',
					'label'           => esc_html_x( 'Referral status', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => array_merge(
						array(
							array(
								'text'  => esc_attr_x( 'All', 'AffiliateWP', 'uncanny-automator-pro' ),
								'value' => '-1',
							),
						),
						Affwp_Pro_Helpers::get_referral_status_options()
					),
					'options_show_id' => false,
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'     => 'CONDITION',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				)
			),
			$this->field->text(
				array(
					'option_code' => 'REFERRAL_COUNT_VALUE',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'input_type'  => 'int',
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$status    = $this->get_parsed_option( 'REFERRAL_STATUS' );
		$condition = $this->get_parsed_option( 'CONDITION' );
		$value     = $this->get_parsed_option( 'REFERRAL_COUNT_VALUE' );
		$symbol    = Affwp_Pro_Helpers::create_comparison_symbol( $condition );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( ! is_numeric( $value ) || null === $symbol ) {
			$this->condition_failed( esc_html_x( 'Invalid condition or value.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$count = '-1' === $status
			? (float) affwp_count_referrals( $affiliate_id )
			: (float) affwp_count_referrals( $affiliate_id, $status );

		if ( false === Affwp_Pro_Helpers::compare_values( $count, $symbol, (float) $value ) ) {
			$readable_condition = $this->get_option( 'CONDITION_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Count, %2$s: Condition, %3$s: Expected value */
					esc_html_x( "The affiliate's referral count (%1\$s) does not meet the condition: %2\$s %3\$s", 'AffiliateWP', 'uncanny-automator-pro' ),
					$count,
					$readable_condition,
					$value
				)
			);
		}
	}
}
