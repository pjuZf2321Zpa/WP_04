<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_AFFILIATE_RATE_TYPE_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_AFFILIATE_RATE_TYPE_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's rate type {{is/is not}} {{a type}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_AFFILIATE_RATE_TYPE_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Criteria, %2$s: Rate type */
			esc_html_x( "An affiliate's rate type {{is/is not:%1\$s}} {{a type:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'CRITERIA',
			'RATE_TYPE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'CRITERIA',
					'label'           => esc_html_x( 'Criteria', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_is_is_not_options(),
					'options_show_id' => false,
				)
			),
			$this->field->select_field_args(
				array(
					'option_code'     => 'RATE_TYPE',
					'label'           => esc_html_x( 'Rate type', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => array(
						array(
							'value' => 'percentage',
							'text'  => esc_html_x( 'Percentage', 'AffiliateWP', 'uncanny-automator-pro' ),
						),
						array(
							'value' => 'flat',
							'text'  => esc_html_x( 'Flat rate', 'AffiliateWP', 'uncanny-automator-pro' ),
						),
					),
					'options_show_id' => false,
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$criteria     = $this->get_parsed_option( 'CRITERIA' );
		$rate_type    = $this->get_parsed_option( 'RATE_TYPE' );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$current_rate_type = affwp_get_affiliate_rate_type( $affiliate_id );
		$matches           = ( $rate_type === $current_rate_type );

		if ( ( 'is' === $criteria && ! $matches ) || ( 'is-not' === $criteria && $matches ) ) {
			$readable_type = $this->get_option( 'RATE_TYPE_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Current rate type, %2$s: Criteria, %3$s: Expected rate type */
					esc_html_x( "The affiliate's rate type is \"%1\$s\" but expected %2\$s \"%3\$s\"", 'AffiliateWP', 'uncanny-automator-pro' ),
					$current_rate_type,
					$criteria,
					$readable_type
				)
			);
		}
	}
}
