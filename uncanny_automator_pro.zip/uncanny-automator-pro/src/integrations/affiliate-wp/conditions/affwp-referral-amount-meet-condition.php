<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_REFERRAL_AMOUNT_MEET_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_REFERRAL_AMOUNT_MEET_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's most recent referral amount meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_REFERRAL_AMOUNT_MEET_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Condition, %2$s: Value */
			esc_html_x( "An affiliate's most recent referral amount {{is:%1\$s}} {{a value:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'CONDITION',
			'AMOUNT_VALUE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'CONDITION',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				)
			),
			$this->field->text(
				array(
					'option_code' => 'AMOUNT_VALUE',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'input_type'  => 'text',
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$condition    = $this->get_parsed_option( 'CONDITION' );
		$value        = $this->get_parsed_option( 'AMOUNT_VALUE' );
		$symbol       = Affwp_Pro_Helpers::create_comparison_symbol( $condition );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( ! is_numeric( $value ) || null === $symbol ) {
			$this->condition_failed( esc_html_x( 'Invalid condition or value.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		// Check the most recent referral for this affiliate.
		$referrals = affiliate_wp()->referrals->get_referrals(
			array(
				'number'       => 1,
				'affiliate_id' => $affiliate_id,
				'orderby'      => 'date',
				'order'        => 'DESC',
			)
		);

		if ( empty( $referrals ) ) {
			$this->condition_failed( esc_html_x( 'The affiliate has no referrals.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$amount = (float) $referrals[0]->amount;

		if ( false === Affwp_Pro_Helpers::compare_values( $amount, $symbol, (float) $value ) ) {
			$readable_condition = $this->get_option( 'CONDITION_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Amount, %2$s: Condition, %3$s: Expected value */
					esc_html_x( 'The referral amount (%1$s) does not meet the condition: %2$s %3$s', 'AffiliateWP', 'uncanny-automator-pro' ),
					$amount,
					$readable_condition,
					$value
				)
			);
		}
	}
}
