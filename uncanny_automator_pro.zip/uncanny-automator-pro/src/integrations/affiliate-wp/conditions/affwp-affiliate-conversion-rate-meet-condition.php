<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_AFFILIATE_CONVERSION_RATE_MEET_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_AFFILIATE_CONVERSION_RATE_MEET_CONDITION extends Action_Condition {

	/**
	 * Define the condition.
	 *
	 * @return void
	 */
	public function define_condition() {

		$this->integration  = 'AFFWP';
		$this->name         = esc_html_x( "An affiliate's conversion rate meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' );
		$this->code         = 'AFFWP_CONVERSION_RATE_MEET_CONDITION';
		$this->dynamic_name = sprintf(
			/* translators: %1$s: Condition, %2$s: Value */
			esc_html_x( "An affiliate's conversion rate {{is:%1\$s}} {{a value:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
			'CONDITION',
			'CONVERSION_RATE_VALUE'
		);
		$this->requires_user = true;
		$this->is_pro        = true;
	}

	/**
	 * Define the fields.
	 *
	 * @return array
	 */
	public function fields() {

		return array(
			$this->field->select_field_args(
				array(
					'option_code'     => 'CONDITION',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				)
			),
			$this->field->text(
				array(
					'option_code' => 'CONVERSION_RATE_VALUE',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'input_type'  => 'text',
					'description' => esc_html_x( 'Percentage value, e.g. 25 for 25%', 'AffiliateWP', 'uncanny-automator-pro' ),
				)
			),
		);
	}

	/**
	 * Evaluate the condition.
	 *
	 * @return void
	 */
	public function evaluate_condition() {

		$condition    = $this->get_parsed_option( 'CONDITION' );
		$value        = $this->get_parsed_option( 'CONVERSION_RATE_VALUE' );
		$symbol       = Affwp_Pro_Helpers::create_comparison_symbol( $condition );
		$affiliate_id = affwp_get_affiliate_id( $this->user_id );

		if ( empty( $affiliate_id ) ) {
			$this->condition_failed( esc_html_x( 'The user is not an affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		if ( ! is_numeric( $value ) || null === $symbol ) {
			$this->condition_failed( esc_html_x( 'Invalid condition or value.', 'AffiliateWP', 'uncanny-automator-pro' ) );
			return;
		}

		$visits    = absint( affwp_count_visits( $affiliate_id ) );
		$referrals = absint( affwp_count_referrals( $affiliate_id ) );
		$rate      = 0 < $visits ? ( $referrals / $visits ) * 100 : 0;

		if ( false === Affwp_Pro_Helpers::compare_values( $rate, $symbol, (float) $value ) ) {
			$readable_condition = $this->get_option( 'CONDITION_readable' );
			$this->condition_failed(
				sprintf(
					/* translators: %1$s: Rate, %2$s: Condition, %3$s: Expected value */
					esc_html_x( "The affiliate's conversion rate (%1\$s%%) does not meet the condition: %2\$s %3\$s%%", 'AffiliateWP', 'uncanny-automator-pro' ),
					round( $rate, 2 ),
					$readable_condition,
					$value
				)
			);
		}
	}
}
