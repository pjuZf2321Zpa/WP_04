<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Affwp_Tokens;

/**
 * Class Affwp_Pro_Tokens
 * @package Uncanny_Automator_Pro
 */
class Affwp_Pro_Tokens extends Affwp_Tokens {

	/** Integration code
	 * @var string
	 */
	public static $integration = 'AFFWP';

	public function __construct() {
		add_filter(
			'automator_maybe_trigger_affwp_affwppaidreferral_tokens',
			array(
				$this,
				'affwp_possible_affiliate_ref_tokens',
			),
			20,
			2
		);

		add_filter(
			'automator_maybe_trigger_affwp_affwprejectreferral_tokens',
			array(
				$this,
				'affwp_possible_affiliate_ref_tokens',
			),
			20,
			2
		);

		add_filter(
			'automator_maybe_trigger_affwp_referswcproduct_tokens',
			array(
				$this,
				'affwp_possible_affiliate_ref_pro_tokens',
			),
			20,
			2
		);

		add_filter(
			'automator_maybe_trigger_affwp_refersmpproduct_tokens',
			array(
				$this,
				'affwp_possible_affiliate_ref_pro_tokens',
			),
			20,
			2
		);

		add_filter(
			'automator_maybe_trigger_affwp_referseddproduct_tokens',
			array(
				$this,
				'affwp_possible_affiliate_ref_pro_tokens',
			),
			20,
			2
		);

		add_filter( 'automator_maybe_parse_token', array( $this, 'parse_affwp_pro_trigger_tokens' ), 20, 6 );
	}

	/**
	 * @param array $tokens
	 * @param array $args
	 *
	 * @return array
	 */
	public function affwp_possible_affiliate_ref_pro_tokens( $tokens = array(), $args = array() ) {
		if ( ! automator_pro_do_identify_tokens() ) {
			return $tokens;
		}

		$trigger_integration = $args['integration'];
		$trigger_meta        = $args['meta'];

		$fields = array(
			array(
				'tokenId'         => 'AFFILIATEWPID',
				'tokenName'       => esc_html_x( 'Affiliate ID', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPURL',
				'tokenName'       => esc_html_x( 'Affiliate URL', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPSTATUS',
				'tokenName'       => esc_html_x( 'Affiliate status', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPREGISTERDATE',
				'tokenName'       => esc_html_x( 'Registration date', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPWEBSITE',
				'tokenName'       => esc_html_x( 'Website', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPREFRATETYPE',
				'tokenName'       => esc_html_x( 'Referral rate type', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPREFRATE',
				'tokenName'       => esc_html_x( 'Referral rate', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPCOUPON',
				'tokenName'       => esc_html_x( 'Dynamic coupon', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPACCEMAIL',
				'tokenName'       => esc_html_x( 'Account email', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPPAYMENTEMAIL',
				'tokenName'       => esc_html_x( 'Payment email', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPPROMOMETHODS',
				'tokenName'       => esc_html_x( 'Promotion methods', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'AFFILIATEWPNOTES',
				'tokenName'       => esc_html_x( 'Affiliate notes', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALTYPE',
				'tokenName'       => esc_html_x( 'Referral type', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALAMOUNT',
				'tokenName'       => esc_html_x( 'Referral amount', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALDATE',
				'tokenName'       => esc_html_x( 'Referral date', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALDESCRIPTION',
				'tokenName'       => esc_html_x( 'Referral description', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALREFERENCE',
				'tokenName'       => esc_html_x( 'Referral reference', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALCONTEXT',
				'tokenName'       => esc_html_x( 'Referral context', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALCUSTOM',
				'tokenName'       => esc_html_x( 'Referral custom', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'REFERRALSTATUS',
				'tokenName'       => esc_html_x( 'Referral status', 'Affiliate Wp', 'uncanny-automator' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
		);

		$tokens = array_merge( $tokens, $fields );

		return $tokens;
	}

	/**
	 * @param $value
	 * @param $pieces
	 * @param $recipe_id
	 * @param $trigger_data
	 * @param int $user_id
	 * @param $replace_args
	 *
	 * @return int|mixed|string
	 */
	public function parse_affwp_pro_trigger_tokens( $value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_args ) {
		if ( $pieces ) {
			if ( in_array( 'WCSALES', $pieces ) ||
				 in_array( 'MPSLES', $pieces ) ||
				 in_array( 'EDDSLES', $pieces ) ||
				 in_array( 'REFERSMPPRODUCT', $pieces ) ||
				 in_array( 'REFERSEDDPRODUCT', $pieces ) ||
				 in_array( 'REFERSWCPRODUCT', $pieces ) ||
				 in_array( 'REFERRALTYPE', $pieces )
			) {
				global $wpdb;
				$trigger_id     = $pieces[0];
				$trigger_meta   = $pieces[2];
				$trigger_log_id = isset( $replace_args['trigger_log_id'] ) ? absint( $replace_args['trigger_log_id'] ) : 0;
				$entry          = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT meta_value
													FROM {$wpdb->prefix}uap_trigger_log_meta
													WHERE meta_key = %s
													AND automator_trigger_log_id = %d
													AND automator_trigger_id = %d
													LIMIT 0,1",
						$trigger_meta,
						$trigger_log_id,
						$trigger_id
					)
				);

				$value = automator_pro_safe_unserialize( $entry );
			}
		}

		return $value;
	}
}
