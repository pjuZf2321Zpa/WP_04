<?php

namespace Uncanny_Automator_Pro;

/**
 * Class AFFWP_SET_REFERRAL_RATE
 *
 * @package Uncanny_Automator_Pro
 */
class AFFWP_SET_REFERRAL_RATE extends \Uncanny_Automator\Recipe\Action {

	/**
	 * Define and register the action by pushing it into the Automator object.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'AFFWP' );
		$this->set_action_code( 'AFFWP_SET_REFERRAL_RATE' );
		$this->set_action_meta( 'AFFWP_AFFILIATE' );
		$this->set_requires_user( false );
		$this->set_is_pro( true );

		/* translators: Action - Affiliate WP */
		$this->set_sentence(
			sprintf(
				esc_attr_x( "Set {{an affiliate's:%1\$s}} {{commission rate:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'REFERRAL_RATE:' . $this->get_action_meta()
			)
		);

		/* translators: Action - Affiliate WP */
		$this->set_readable_sentence( esc_attr_x( "Set an affiliate's commission rate", 'AffiliateWP', 'uncanny-automator-pro' ) );
	}

	/**
	 * Define the Action's options.
	 *
	 * @return array
	 */
	public function options() {
		$helpers        = new Affwp_Pro_Helpers();
		$all_affiliates = $helpers->get_affiliates( null, $this->get_action_meta() );
		$affiliates     = array();

		foreach ( $all_affiliates['options'] as $k => $option ) {
			$affiliates[] = array(
				'value' => $k,
				'text' => $option,
			);
		}

		$all_rate_types = affwp_get_affiliate_rate_types();
		$rate_types     = array();

		foreach ( $all_rate_types as $key => $value ) {
			$rate_types[] = array(
				'value' => $key,
				'text' => $value,
			);
		}

		return array(
			array(
				'input_type' => 'select',
				'required' => true,
				'option_code' => $this->get_action_meta(),
				'label' => esc_html_x( 'Affiliate ID', 'Affiliate WP', 'uncanny-automator-pro' ),
				'options' => $affiliates,
			),
			array(
				'option_code'           => 'RATE_TYPE',
				'label'                 => esc_html_x( 'Referral rate type', 'AffiliateWP', 'uncanny-automator-pro' ),
				'options'               => $rate_types,
				'supports_custom_value' => false,
				'description'           => esc_html_x( 'Select the type of referral rate to set for this affiliate.', 'AffiliateWP', 'uncanny-automator-pro' ),
				'input_type'  => 'select',
			),
			array(
				'option_code' => 'REFERRAL_RATE',
				'label'       => esc_html_x( 'Referral rate', 'AffiliateWP', 'uncanny-automator-pro' ),
				'placeholder' => esc_html_x( 'e.g. 20 for percentage or 5.00 for flat rate', 'AffiliateWP', 'uncanny-automator-pro' ),
				'required'    => true,
				'input_type'  => 'float',
				'description' => esc_html_x( 'Enter the referral rate. For percentage type, enter the percentage value (e.g. 20 for 20%). For flat rate, enter the amount (e.g. 5.00).', 'AffiliateWP', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Define action tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'AFFILIATE_ID'       => array(
				'name' => esc_html_x( 'Affiliate ID', 'AffiliateWP', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'AFFILIATE_NAME'     => array(
				'name' => esc_html_x( 'Affiliate name', 'AffiliateWP', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'PREVIOUS_RATE'      => array(
				'name' => esc_html_x( 'Previous referral rate', 'AffiliateWP', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'PREVIOUS_RATE_TYPE' => array(
				'name' => esc_html_x( 'Previous referral rate type', 'AffiliateWP', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'NEW_RATE'           => array(
				'name' => esc_html_x( 'New referral rate', 'AffiliateWP', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'NEW_RATE_TYPE'      => array(
				'name' => esc_html_x( 'New referral rate type', 'AffiliateWP', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process the action.
	 *
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool|null true on success, false on error.
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		$affiliate_id = absint( sanitize_text_field( $this->get_parsed_meta_value( $this->get_action_meta(), '' ) ) );
		$rate_type    = sanitize_text_field( $this->get_parsed_meta_value( 'RATE_TYPE', '' ) );
		$rate         = sanitize_text_field( $this->get_parsed_meta_value( 'REFERRAL_RATE', '' ) );

		// Validate affiliate ID.
		if ( empty( $affiliate_id ) ) {
			$this->add_log_error( esc_html_x( 'An affiliate must be specified.', 'AffiliateWP', 'uncanny-automator-pro' ) );

			return false;
		}

		// Validate the affiliate exists.
		$affiliate = affwp_get_affiliate( $affiliate_id );
		if ( ! $affiliate ) {
			$this->add_log_error(
				sprintf(
					/* translators: %d - Affiliate ID */
					esc_html_x( 'Affiliate with ID %d was not found.', 'AffiliateWP', 'uncanny-automator-pro' ),
					$affiliate_id
				)
			);

			return false;
		}

		// Validate rate is a valid number.
		if ( '' === $rate || ! is_numeric( $rate ) ) {
			$this->add_log_error( esc_html_x( 'A valid referral rate must be provided.', 'AffiliateWP', 'uncanny-automator-pro' ) );

			return false;
		}

		// Validate rate type.
		$valid_rate_types = affwp_get_affiliate_rate_types();
		if ( empty( $rate_type ) || ! array_key_exists( $rate_type, $valid_rate_types ) ) {
			$this->add_log_error( esc_html_x( 'A valid referral rate type must be selected.', 'AffiliateWP', 'uncanny-automator-pro' ) );

			return false;
		}

		// Capture previous values before updating.
		$previous_rate      = affwp_get_affiliate_rate( $affiliate_id, true );
		$previous_rate_type = affwp_get_affiliate_rate_type( $affiliate_id );

		// Update the affiliate with new rate and rate type.
		$updated = affwp_update_affiliate(
			array(
				'affiliate_id' => $affiliate_id,
				'rate'         => $rate,
				'rate_type'    => $rate_type,
			)
		);

		if ( false === $updated ) {
			$this->add_log_error(
				sprintf(
					/* translators: %d - Affiliate ID */
					esc_html_x( 'Failed to update the referral rate for affiliate ID %d.', 'AffiliateWP', 'uncanny-automator-pro' ),
					$affiliate_id
				)
			);

			return false;
		}

		// Hydrate tokens with affiliate data.
		$this->hydrate_tokens(
			array(
				'AFFILIATE_ID'       => $affiliate_id,
				'AFFILIATE_NAME'     => affwp_get_affiliate_name( $affiliate_id ),
				'PREVIOUS_RATE'      => $previous_rate,
				'PREVIOUS_RATE_TYPE' => isset( $valid_rate_types[ $previous_rate_type ] ) ? $valid_rate_types[ $previous_rate_type ] : $previous_rate_type,
				'NEW_RATE'           => $rate,
				'NEW_RATE_TYPE'      => isset( $valid_rate_types[ $rate_type ] ) ? $valid_rate_types[ $rate_type ] : $rate_type,
			)
		);

		return true;
	}
}
