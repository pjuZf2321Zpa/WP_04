<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_REFERRAL_TYPE
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_REFERRAL_TYPE extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_REFERRAL_TYPE' );
		$this->set_sentence( esc_html_x( 'A referral {{is/is not}} {{a type}}', 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Type. */
				esc_html_x( 'A referral {{is/is not:%1$s}} {{a type:%2$s}}', 'AffiliateWP', 'uncanny-automator-pro' ),
				'CRITERIA',
				$this->get_meta()
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => Affwp_Pro_Helpers::get_is_is_not_options(),
				),
				array(
					'option_code'           => $this->get_meta(),
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Type', 'AffiliateWP', 'uncanny-automator-pro' ),
					'supports_custom_value' => false,
					'options'               => Affwp_Pro_Helpers::get_referral_type_options(),
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates whose referrals match the specified type.
	 *
	 * @param array{AFFWP_REFERRAL_TYPE:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$criteria = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$type     = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';

		if ( empty( $criteria ) || empty( $type ) ) {
			return array();
		}

		$referrals = affiliate_wp()->referrals->get_referrals( array( 'number' => -1 ) );

		if ( empty( $referrals ) ) {
			return array();
		}

		$matched_users = array();

		foreach ( $referrals as $referral ) {
			$matches = ( $type === $referral->type );

			if ( ( 'is' === $criteria && $matches ) || ( 'is-not' === $criteria && ! $matches ) ) {
				$user_id = affwp_get_affiliate_user_id( $referral->affiliate_id );
				if ( ! empty( $user_id ) ) {
					$matched_users[] = $user_id;
				}
			}
		}

		return array_unique( $matched_users );
	}
}
