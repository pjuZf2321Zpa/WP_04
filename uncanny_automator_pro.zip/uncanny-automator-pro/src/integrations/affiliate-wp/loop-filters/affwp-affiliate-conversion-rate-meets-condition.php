<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_AFFILIATE_CONVERSION_RATE_MEETS_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_AFFILIATE_CONVERSION_RATE_MEETS_CONDITION extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_AFFILIATE_CONVERSION_RATE_MEETS_CONDITION' );
		$this->set_sentence( esc_html_x( "An affiliate's conversion rate meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				// translators: %1$s: Condition, %2$s: Value.
				esc_html_x( "An affiliate's conversion rate {{is:%1\$s}} {{a value:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
				'CONDITION',
				'CONVERSION_RATE_VALUE'
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'     => 'CONDITION',
					'type'            => 'select',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				),
				array(
					'option_code' => 'CONVERSION_RATE_VALUE',
					'type'        => 'text',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
					'description' => esc_html_x( 'Percentage value, e.g. 25 for 25%', 'AffiliateWP', 'uncanny-automator-pro' ),
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates whose conversion rate matches the condition.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$condition = isset( $fields['CONDITION'] ) ? $fields['CONDITION'] : '';
		$value     = isset( $fields['CONVERSION_RATE_VALUE'] ) ? trim( $fields['CONVERSION_RATE_VALUE'] ) : '';
		$symbol    = Affwp_Pro_Helpers::create_comparison_symbol( $condition );

		if ( empty( $condition ) || 0 === strlen( $value ) || null === $symbol ) {
			return array();
		}

		if ( ! is_numeric( $value ) ) {
			return array();
		}

		$value       = (float) $value;
		$affiliates  = affiliate_wp()->affiliates->get_affiliates( array( 'number' => -1, 'fields' => 'ids' ) );
		$matched_ids = array();

		foreach ( $affiliates as $affiliate_id ) {
			$visits    = absint( affwp_count_visits( $affiliate_id ) );
			$referrals = absint( affwp_count_referrals( $affiliate_id ) );
			$rate      = 0 < $visits ? ( $referrals / $visits ) * 100 : 0;

			if ( Affwp_Pro_Helpers::compare_values( $rate, $symbol, $value ) ) {
				$matched_ids[] = $affiliate_id;
			}
		}

		return Affwp_Pro_Helpers::affiliate_ids_to_user_ids( $matched_ids );
	}
}
