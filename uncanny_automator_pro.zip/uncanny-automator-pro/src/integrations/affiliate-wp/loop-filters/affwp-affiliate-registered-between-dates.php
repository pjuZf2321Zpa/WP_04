<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_AFFILIATE_REGISTERED_BETWEEN_DATES
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_AFFILIATE_REGISTERED_BETWEEN_DATES extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_AFFILIATE_REGISTERED_BETWEEN_DATES' );
		$this->set_sentence( esc_html_x( 'An affiliate registered between {{a start date}} and {{an end date}}', 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Start date, %2$s: End date. */
				esc_html_x( 'An affiliate registered between {{a start date:%1$s}} and {{an end date:%2$s}}', 'AffiliateWP', 'uncanny-automator-pro' ),
				'START_DATE',
				'END_DATE'
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'START_DATE',
					'type'                  => 'date',
					'label'                 => esc_html_x( 'Start date', 'AffiliateWP', 'uncanny-automator-pro' ),
					'supports_custom_value' => false,
				),
				array(
					'option_code'           => 'END_DATE',
					'type'                  => 'date',
					'label'                 => esc_html_x( 'End date', 'AffiliateWP', 'uncanny-automator-pro' ),
					'supports_custom_value' => false,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates registered between the given dates.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$start_date = isset( $fields['START_DATE'] ) ? $fields['START_DATE'] : '';
		$end_date   = isset( $fields['END_DATE'] ) ? $fields['END_DATE'] : '';

		if ( empty( $start_date ) || empty( $end_date ) ) {
			return array();
		}

		$affiliates = affiliate_wp()->affiliates->get_affiliates(
			array(
				'number' => -1,
				'date'   => array(
					'start' => $start_date,
					'end'   => $end_date,
				),
				'fields' => 'ids',
			)
		);

		return Affwp_Pro_Helpers::affiliate_ids_to_user_ids( $affiliates );
	}
}
