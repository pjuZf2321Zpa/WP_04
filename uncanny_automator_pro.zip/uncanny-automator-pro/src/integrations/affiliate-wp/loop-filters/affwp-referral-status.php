<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_REFERRAL_STATUS
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_REFERRAL_STATUS extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_REFERRAL_STATUS' );
		$this->set_sentence( esc_html_x( 'A referral {{is/is not}} {{a status}}', 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Status. */
				esc_html_x( 'A referral {{is/is not:%1$s}} {{a status:%2$s}}', 'AffiliateWP', 'uncanny-automator-pro' ),
				'CRITERIA',
				$this->get_meta()
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => Affwp_Pro_Helpers::get_is_is_not_options(),
				),
				array(
					'option_code'           => $this->get_meta(),
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Status', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => Affwp_Pro_Helpers::get_referral_status_options(),
					'supports_custom_value' => false,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates whose referrals match the specified status.
	 *
	 * @param array{AFFWP_REFERRAL_STATUS:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$criteria = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$status   = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';

		if ( empty( $criteria ) || empty( $status ) ) {
			return array();
		}

		if ( 'is' === $criteria ) {
			$referrals = affiliate_wp()->referrals->get_referrals(
				array(
					'number' => -1,
					'status' => $status,
				)
			);
		} else {
			$all_statuses = array_keys( affwp_get_referral_statuses() );
			$all_statuses = array_diff( $all_statuses, array( $status ) );
			$referrals    = affiliate_wp()->referrals->get_referrals(
				array(
					'number' => -1,
					'status' => $all_statuses,
				)
			);
		}

		if ( empty( $referrals ) ) {
			return array();
		}

		$matched_users = array();

		foreach ( $referrals as $referral ) {
			$user_id = affwp_get_affiliate_user_id( $referral->affiliate_id );
			if ( ! empty( $user_id ) ) {
				$matched_users[] = $user_id;
			}
		}

		return array_unique( $matched_users );
	}
}
