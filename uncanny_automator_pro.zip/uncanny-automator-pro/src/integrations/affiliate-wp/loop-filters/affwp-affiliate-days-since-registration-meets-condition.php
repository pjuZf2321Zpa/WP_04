<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_AFFILIATE_DAYS_SINCE_REGISTRATION_MEETS_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_AFFILIATE_DAYS_SINCE_REGISTRATION_MEETS_CONDITION extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_AFFILIATE_DAYS_SINCE_REGISTRATION_MEETS_CONDITION' );
		$this->set_sentence( esc_html_x( "An affiliate's days since registration meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Condition, %2$s: Value. */
				esc_html_x( "An affiliate's days since registration {{is:%1\$s}} {{a value:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
				'CONDITION',
				'DAYS_VALUE'
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'     => 'CONDITION',
					'type'            => 'select',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				),
				array(
					'option_code' => 'DAYS_VALUE',
					'type'        => 'text',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates whose days since registration meets the condition.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$condition = isset( $fields['CONDITION'] ) ? $fields['CONDITION'] : '';
		$value     = isset( $fields['DAYS_VALUE'] ) ? trim( $fields['DAYS_VALUE'] ) : '';
		$symbol    = Affwp_Pro_Helpers::create_comparison_symbol( $condition );

		if ( empty( $condition ) || 0 === strlen( $value ) || null === $symbol ) {
			return array();
		}

		if ( ! is_numeric( $value ) ) {
			return array();
		}

		$value       = (float) $value;
		$affiliates  = affiliate_wp()->affiliates->get_affiliates( array( 'number' => -1 ) );
		$matched_ids = array();
		$now         = time();

		foreach ( $affiliates as $affiliate ) {
			$registered = strtotime( $affiliate->date_registered );

			if ( false === $registered ) {
				continue;
			}

			$days = floor( ( $now - $registered ) / DAY_IN_SECONDS );

			if ( Affwp_Pro_Helpers::compare_values( $days, $symbol, $value ) ) {
				$matched_ids[] = $affiliate->affiliate_id;
			}
		}

		return Affwp_Pro_Helpers::affiliate_ids_to_user_ids( $matched_ids );
	}
}
