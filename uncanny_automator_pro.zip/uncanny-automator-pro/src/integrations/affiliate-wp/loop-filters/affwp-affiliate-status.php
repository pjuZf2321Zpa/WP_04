<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_AFFILIATE_STATUS
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_AFFILIATE_STATUS extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_AFFILIATE_STATUS' );
		$this->set_sentence( esc_html_x( 'An affiliate {{is/is not}} {{a status}}', 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Status. */
				esc_html_x( 'An affiliate {{is/is not:%1$s}} {{a status:%2$s}}', 'AffiliateWP', 'uncanny-automator-pro' ),
				'CRITERIA',
				$this->get_meta()
			)
		);
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_loop_type( 'users' );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => Affwp_Pro_Helpers::get_is_is_not_options(),
				),
				array(
					'option_code'           => $this->get_meta(),
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Status', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => Affwp_Pro_Helpers::get_affiliate_status_options(),
					'supports_custom_value' => false,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates matching the specified status criteria.
	 *
	 * @param array{AFFWP_AFFILIATE_STATUS:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$criteria = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$status   = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';

		if ( empty( $criteria ) || empty( $status ) ) {
			return array();
		}

		if ( 'is' === $criteria ) {
			$affiliates = affiliate_wp()->affiliates->get_affiliates(
				array(
					'number' => -1,
					'status' => $status,
					'fields' => 'ids',
				)
			);
		} else {
			$all_affiliates    = affiliate_wp()->affiliates->get_affiliates( array( 'number' => -1, 'fields' => 'ids' ) );
			$status_affiliates = affiliate_wp()->affiliates->get_affiliates(
				array(
					'number' => -1,
					'status' => $status,
					'fields' => 'ids',
				)
			);
			$affiliates        = array_diff( $all_affiliates, $status_affiliates );
		}

		return Affwp_Pro_Helpers::affiliate_ids_to_user_ids( $affiliates );
	}
}
