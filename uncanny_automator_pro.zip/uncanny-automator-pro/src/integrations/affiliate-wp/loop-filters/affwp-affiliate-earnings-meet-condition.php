<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_AFFILIATE_EARNINGS_MEET_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_AFFILIATE_EARNINGS_MEET_CONDITION extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_AFFILIATE_EARNINGS_MEET_CONDITION' );
		$this->set_sentence( esc_html_x( "An affiliate's {{paid/unpaid}} earnings meets {{a condition}}", 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				// translators: %1$s: Earnings type, %2$s: Condition, %3$s: Value.
				esc_html_x( "An affiliate's {{paid/unpaid:%1\$s}} earnings {{is:%2\$s}} {{a value:%3\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
				'EARNINGS_TYPE',
				'CONDITION',
				'EARNINGS_VALUE'
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'     => 'EARNINGS_TYPE',
					'type'            => 'select',
					'label'           => esc_html_x( 'Earnings type', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => array(
						array(
							'text'  => esc_attr_x( 'Paid', 'AffiliateWP', 'uncanny-automator-pro' ),
							'value' => 'paid',
						),
						array(
							'text'  => esc_attr_x( 'Unpaid', 'AffiliateWP', 'uncanny-automator-pro' ),
							'value' => 'unpaid',
						),
					),
					'options_show_id' => false,
				),
				array(
					'option_code'     => 'CONDITION',
					'type'            => 'select',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				),
				array(
					'option_code' => 'EARNINGS_VALUE',
					'type'        => 'text',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates whose earnings match the condition.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$earnings_type = isset( $fields['EARNINGS_TYPE'] ) ? $fields['EARNINGS_TYPE'] : '';
		$condition     = isset( $fields['CONDITION'] ) ? $fields['CONDITION'] : '';
		$value         = isset( $fields['EARNINGS_VALUE'] ) ? trim( $fields['EARNINGS_VALUE'] ) : '';
		$symbol        = Affwp_Pro_Helpers::create_comparison_symbol( $condition );

		if ( empty( $earnings_type ) || empty( $condition ) || 0 === strlen( $value ) || null === $symbol ) {
			return array();
		}

		if ( ! is_numeric( $value ) ) {
			return array();
		}

		$value       = (float) $value;
		$affiliates  = affiliate_wp()->affiliates->get_affiliates( array( 'number' => -1, 'fields' => 'ids' ) );
		$matched_ids = array();

		foreach ( $affiliates as $affiliate_id ) {
			if ( 'paid' === $earnings_type ) {
				$earnings = (float) affwp_get_affiliate_earnings( $affiliate_id );
			} else {
				$affiliate = affwp_get_affiliate( $affiliate_id );
				$earnings  = null !== $affiliate ? (float) $affiliate->unpaid_earnings : 0;
			}

			if ( Affwp_Pro_Helpers::compare_values( $earnings, $symbol, $value ) ) {
				$matched_ids[] = $affiliate_id;
			}
		}

		return Affwp_Pro_Helpers::affiliate_ids_to_user_ids( $matched_ids );
	}
}
