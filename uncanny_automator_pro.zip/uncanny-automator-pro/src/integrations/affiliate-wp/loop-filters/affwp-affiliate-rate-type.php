<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_AFFILIATE_RATE_TYPE
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_AFFILIATE_RATE_TYPE extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_AFFILIATE_RATE_TYPE' );
		$this->set_sentence( esc_html_x( "An affiliate's rate type {{is/is not}} {{a type}}", 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Rate type. */
				esc_html_x( "An affiliate's rate type {{is/is not:%1\$s}} {{a type:%2\$s}}", 'AffiliateWP', 'uncanny-automator-pro' ),
				'CRITERIA',
				$this->get_meta()
			)
		);
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_loop_type( 'users' );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => Affwp_Pro_Helpers::get_is_is_not_options(),
				),
				array(
					'option_code'           => $this->get_meta(),
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Rate type', 'AffiliateWP', 'uncanny-automator-pro' ),
					'options'               => array(
						array(
							'value' => 'percentage',
							'text'  => esc_html_x( 'Percentage', 'AffiliateWP', 'uncanny-automator-pro' ),
						),
						array(
							'value' => 'flat',
							'text'  => esc_html_x( 'Flat rate', 'AffiliateWP', 'uncanny-automator-pro' ),
						),
					),
					'supports_custom_value' => false,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates matching the specified rate type criteria.
	 *
	 * @param array{AFFWP_AFFILIATE_RATE_TYPE:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$criteria  = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$rate_type = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';

		if ( empty( $criteria ) || empty( $rate_type ) ) {
			return array();
		}

		$affiliates  = affiliate_wp()->affiliates->get_affiliates( array( 'number' => -1, 'fields' => 'ids' ) );
		$matched_ids = array();

		foreach ( $affiliates as $affiliate_id ) {
			$affiliate_rate_type = affwp_get_affiliate_rate_type( $affiliate_id );
			$matches             = ( $rate_type === $affiliate_rate_type );

			if ( ( 'is' === $criteria && $matches ) || ( 'is-not' === $criteria && ! $matches ) ) {
				$matched_ids[] = $affiliate_id;
			}
		}

		return Affwp_Pro_Helpers::affiliate_ids_to_user_ids( $matched_ids );
	}
}
