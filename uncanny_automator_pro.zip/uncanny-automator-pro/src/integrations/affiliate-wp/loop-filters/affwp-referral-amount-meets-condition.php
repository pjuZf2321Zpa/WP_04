<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Affwp_Pro_Helpers;
use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class AFFWP_REFERRAL_AMOUNT_MEETS_CONDITION
 *
 * @package Uncanny_Automator_Pro
 */
final class AFFWP_REFERRAL_AMOUNT_MEETS_CONDITION extends Loop_Filter {

	/**
	 * Setup the filter.
	 *
	 * @return void
	 */
	public function setup() {

		$this->set_integration( 'AFFWP' );
		$this->set_meta( 'AFFWP_REFERRAL_AMOUNT_MEETS_CONDITION' );
		$this->set_sentence( esc_html_x( 'An affiliate has a referral whose amount meets {{a condition}}', 'AffiliateWP', 'uncanny-automator-pro' ) );
		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Condition, %2$s: Value. */
				esc_html_x( 'An affiliate has a referral whose amount {{is:%1$s}} {{a value:%2$s}}', 'AffiliateWP', 'uncanny-automator-pro' ),
				'CONDITION',
				'AMOUNT_VALUE'
			)
		);
		$this->set_loop_type( 'users' );
		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_affiliates' ) );
	}

	/**
	 * Load the field options.
	 *
	 * @return array[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'     => 'CONDITION',
					'type'            => 'select',
					'label'           => esc_html_x( 'Condition', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'        => true,
					'options'         => Affwp_Pro_Helpers::get_comparison_conditions(),
					'options_show_id' => false,
				),
				array(
					'option_code' => 'AMOUNT_VALUE',
					'type'        => 'text',
					'label'       => esc_html_x( 'Value', 'AffiliateWP', 'uncanny-automator-pro' ),
					'required'    => true,
				),
			),
		);
	}

	/**
	 * Retrieve user IDs of affiliates whose referrals match the amount condition.
	 *
	 * @param array $fields The field values.
	 *
	 * @return int[]
	 */
	public function retrieve_affiliates( $fields ) {

		$condition = isset( $fields['CONDITION'] ) ? $fields['CONDITION'] : '';
		$value     = isset( $fields['AMOUNT_VALUE'] ) ? trim( $fields['AMOUNT_VALUE'] ) : '';
		$symbol    = Affwp_Pro_Helpers::create_comparison_symbol( $condition );

		if ( empty( $condition ) || 0 === strlen( $value ) || null === $symbol ) {
			return array();
		}

		if ( ! is_numeric( $value ) ) {
			return array();
		}

		$value     = (float) $value;
		$referrals = affiliate_wp()->referrals->get_referrals( array( 'number' => -1 ) );

		if ( empty( $referrals ) ) {
			return array();
		}

		$matched_users = array();

		foreach ( $referrals as $referral ) {
			$amount = (float) $referral->amount;

			if ( Affwp_Pro_Helpers::compare_values( $amount, $symbol, $value ) ) {
				$user_id = affwp_get_affiliate_user_id( $referral->affiliate_id );
				if ( ! empty( $user_id ) ) {
					$matched_users[] = $user_id;
				}
			}
		}

		return array_unique( $matched_users );
	}
}
