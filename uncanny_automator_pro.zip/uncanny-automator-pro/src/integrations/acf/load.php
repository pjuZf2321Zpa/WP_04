<?php
if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\\Integrations\\Acf\\Acf_Integration' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\Acf\Acf_Integration();
