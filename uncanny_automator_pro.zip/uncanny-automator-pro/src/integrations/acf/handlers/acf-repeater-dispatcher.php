<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

/**
 * Class Acf_Repeater_Dispatcher
 *
 * Bridges ACF's generic acf/save_post into a normalised
 * automator_acf_repeater_row_added action for ACF_REPEATER_ROW_ADDED_ON_POST.
 *
 * ACF has no native "row added" hook, so we snapshot repeater/flex row counts
 * before ACF writes (priority 9), diff after the write (priority 20), and fire
 * one action per field whose row count increased. Owning the diff here keeps the
 * timing explicit and independent of when the lazy trigger is constructed.
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class Acf_Repeater_Dispatcher {

	/**
	 * Pre-save row counts for this request, keyed by "{post_id}:{field_name}".
	 *
	 * @var array<string,int>
	 */
	private $pre_counts = array();

	/**
	 * Wire the snapshot + dispatch listeners on acf/save_post.
	 */
	public function __construct() {
		add_action( 'acf/save_post', array( $this, 'snapshot' ), 9, 1 );
		add_action( 'acf/save_post', array( $this, 'dispatch' ), 20, 1 );
	}

	/**
	 * Snapshot every repeater/flex row count on the post before ACF writes.
	 *
	 * @param mixed $post_id The post being saved.
	 *
	 * @return void
	 */
	public function snapshot( $post_id ) {

		if ( ! is_numeric( $post_id ) ) {
			return;
		}

		$post_id = (int) $post_id;

		foreach ( $this->repeater_flex_field_names( $post_id ) as $field_name ) {
			$this->pre_counts[ $post_id . ':' . $field_name ] = (int) get_post_meta( $post_id, $field_name, true );
		}
	}

	/**
	 * After ACF writes, fire automator_acf_repeater_row_added for each repeater/flex
	 * field whose row count increased.
	 *
	 * @param mixed $post_id The post being saved.
	 *
	 * @return void
	 */
	public function dispatch( $post_id ) {

		if ( ! is_numeric( $post_id ) ) {
			return;
		}

		$post_id = (int) $post_id;

		foreach ( $this->repeater_flex_field_names( $post_id ) as $field_name ) {

			$key       = $post_id . ':' . $field_name;
			$old_count = isset( $this->pre_counts[ $key ] ) ? (int) $this->pre_counts[ $key ] : 0;
			$new_count = (int) get_post_meta( $post_id, $field_name, true );

			if ( $new_count <= $old_count ) {
				continue;
			}

			// Fire once per newly added row (indices old_count .. new_count - 1).
			for ( $row_index = $old_count; $row_index < $new_count; $row_index++ ) {
				/**
				 * Fires once for each row appended to a repeater/flex field on save.
				 *
				 * @param int    $post_id    The post ID.
				 * @param string $field_name The repeater/flex field name.
				 * @param int    $row_index  Zero-based index of the newly added row.
				 * @param int    $new_count  Total row count after the save.
				 */
				do_action( 'automator_acf_repeater_row_added', $post_id, $field_name, $row_index, $new_count );
			}
		}
	}

	/**
	 * List repeater/flexible-content field names registered on a post.
	 *
	 * @param int $post_id The post ID.
	 *
	 * @return string[]
	 */
	private function repeater_flex_field_names( $post_id ) {

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return array();
		}

		$names = array();

		foreach ( acf_get_field_groups( array( 'post_id' => $post_id ) ) as $group ) {

			$fields = acf_get_fields( $group['key'] );

			if ( empty( $fields ) ) {
				continue;
			}

			foreach ( $fields as $field ) {
				if ( ! isset( $field['type'], $field['name'] ) ) {
					continue;
				}
				if ( 'repeater' === $field['type'] || 'flexible_content' === $field['type'] ) {
					$names[] = $field['name'];
				}
			}
		}

		return $names;
	}
}

new Acf_Repeater_Dispatcher();
