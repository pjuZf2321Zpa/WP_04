<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Integration;

/**
 * Class Acf_Integration
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class Acf_Integration extends Integration {

	/**
	 * Setup integration.
	 *
	 * @return void
	 */
	protected function setup() {
		$this->helpers = new Acf_Helpers_Pro();
		$this->set_integration( 'ACF' );
		$this->set_name( 'ACF' );
		$this->set_icon_url( plugin_dir_url( __FILE__ ) . 'img/advanced-custom-fields-icon.svg' );

		$this->set_plugin_file_path( 'advanced-custom-fields/acf.php' );
		$this->set_plugin_variations( array( 'advanced-custom-fields-pro/acf.php' ) );
		$this->set_developer_name( 'WP Engine' );
		$this->set_integration_type( 'plugin' );
		$this->set_distribution_type( 'wp_org' );
	}

	/**
	 * Load triggers.
	 *
	 * @return void
	 */
	public function load() {

		// Bridge listeners must wire in full-load mode too (recipe editor),
		// where the loader does not auto-call load_shared_hooks().
		$this->load_shared_hooks();

		// Existing triggers.
		new ACF_GROUP_SUBFIELD_UPDATED( $this->helpers );
		new ACF_GROUP_SUBFIELD_UPDATED_TO_VALUE( $this->helpers );
		new ACF_POST_FIELD_UPDATED( $this->helpers );
		new ACF_USER_FIELD_UPDATED( $this->helpers );
		new ACF_USER_POST_FIELD_UPDATED( $this->helpers );

		// New triggers.
		new ACF_FIELD_DELETED_ON_POST( $this->helpers );
		new ACF_REPEATER_ROW_ADDED_ON_POST( $this->helpers );
		new ACF_OPTIONS_PAGE_SAVED( $this->helpers );

		// New actions.
		new ACF_UPDATE_FIELD_ON_POST( $this->helpers );
		new ACF_UPDATE_FIELD_ON_USER( $this->helpers );
		new ACF_ADD_ROW_TO_REPEATER_ON_POST( $this->helpers );
		new ACF_UPDATE_FIELD_ON_OPTIONS_PAGE( $this->helpers );
	}

	/**
	 * Wire always-on bridge listeners that must register in targeted (lazy) mode
	 * too, where load() is skipped.
	 *
	 * Loads the repeater dispatcher, which bridges acf/save_post into the
	 * normalised automator_acf_repeater_row_added action the row-added trigger
	 * listens on.
	 *
	 * @return void
	 */
	protected function load_shared_hooks() {

		if ( ! class_exists( 'ACF' ) ) {
			return;
		}

		require_once __DIR__ . '/handlers/acf-repeater-dispatcher.php';
	}

	/**
	 * Check whether ACF is active.
	 *
	 * @return bool
	 */
	public function plugin_active() {
		return class_exists( 'ACF' );
	}
}
