<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

/**
 * Class Acf_Tokens
 *
 * Shared token shapes + hydration for the modernized ACF triggers.
 *
 * Token IDs are SACRED — they appear in recipe DBs and exported manifests.
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class Acf_Tokens {

	/**
	 * Owning helpers instance.
	 *
	 * @var Acf_Helpers_Pro
	 */
	private $helpers;

	/**
	 * Constructor.
	 *
	 * @param Acf_Helpers_Pro $helpers The owning helpers instance.
	 */
	public function __construct( Acf_Helpers_Pro $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * Token definitions for the post-field + user-post-field triggers.
	 *
	 * @return array
	 */
	public function acf_post_field_tokens() {
		return array(
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_NAME',
				'tokenName' => esc_html_x( 'ACF field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD',
				'tokenName' => esc_html_x( 'ACF field value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_ID',
				'tokenName' => esc_html_x( 'Post ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_TITLE',
				'tokenName' => esc_html_x( 'Post title', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_TYPE',
				'tokenName' => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_URL',
				'tokenName' => esc_html_x( 'Post URL', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);
	}

	/**
	 * Hydrate ACF post-field tokens.
	 *
	 * @param string $meta_key     The meta key being updated.
	 * @param mixed  $meta_value   The meta value being saved.
	 * @param int    $post_id      The post ID.
	 * @param string $post_type    The selected post type slug.
	 * @param array  $field_object The field_object returned by acf get_field_object().
	 *
	 * @return array
	 */
	public function hydrate_acf_post_field_tokens( $meta_key, $meta_value, $post_id, $post_type, $field_object ) {

		$field_value = $this->normalize_meta_value( $meta_value, $field_object );

		$field_label = is_array( $field_object ) && isset( $field_object['label'] ) ? $field_object['label'] : $meta_key;

		return array(
			'ACF_TRIGGER_FIELD_NAME' => $field_label,
			'ACF_TRIGGER_FIELD'      => $field_value,
			'ACF_TRIGGER_POST_ID'    => absint( $post_id ),
			'ACF_TRIGGER_POST_TITLE' => get_the_title( $post_id ),
			'ACF_TRIGGER_POST_TYPE'  => $post_type,
			'ACF_TRIGGER_POST_URL'   => get_permalink( $post_id ),
		);
	}

	/**
	 * Token definitions for ACF_USER_FIELD_UPDATED.
	 *
	 * Token IDs are SACRED. The legacy trigger registered each token with a
	 * per-field `tokenIdentifier` of `ACF_USER_FIELD_{tokenId}` (legacy
	 * acf-tokens.php::register_trigger_user_form_tokens()), so live recipes
	 * store pills as `{id}:ACF_USER_FIELD_{tokenId}:{tokenId}`. The modern
	 * framework defaults `tokenIdentifier` to the trigger code, which would
	 * rewrite that middle segment to `ACF_USER_FIELD_UPDATED` and orphan every
	 * existing pill. We declare the legacy identifier explicitly so the
	 * partitioner buckets values under the same key the saved pills resolve by.
	 *
	 * @return array
	 */
	public function acf_user_field_tokens() {

		$definitions = array(
			'acf_field_name'                  => esc_html_x( 'ACF field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'acf_field_value'                 => esc_html_x( 'ACF field value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_biographical_info' => esc_html_x( "Updated user's biographical info", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_display_name'      => esc_html_x( "Updated user's display name", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_email'             => esc_html_x( "Updated user's email", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_first_name'        => esc_html_x( "Updated user's first name", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_id'                => esc_html_x( "Updated user's ID", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_last_name'         => esc_html_x( "Updated user's last name", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_nickname'          => esc_html_x( "Updated user's nickname", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'updated_users_username'          => esc_html_x( "Updated user's username", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
		);

		$tokens = array();

		foreach ( $definitions as $token_id => $token_name ) {
			$tokens[] = array(
				'tokenId'         => $token_id,
				'tokenName'       => $token_name,
				'tokenType'       => 'text',
				'tokenIdentifier' => 'ACF_USER_FIELD_' . $token_id,
			);
		}

		return $tokens;
	}

	/**
	 * Hydrate ACF user-field tokens.
	 *
	 * @param int    $user_id    The user being updated.
	 * @param string $meta_key   The user_meta key.
	 * @param mixed  $meta_value The user_meta value.
	 *
	 * @return array
	 */
	public function hydrate_acf_user_field_tokens( $user_id, $meta_key, $meta_value ) {

		$user        = get_userdata( $user_id );
		$field_value = is_array( $meta_value ) ? implode( ', ', $meta_value ) : (string) $meta_value;

		$tokens = array(
			'acf_field_name'                  => $meta_key,
			'acf_field_value'                 => $field_value,
			'updated_users_biographical_info' => '',
			'updated_users_display_name'      => '',
			'updated_users_email'             => '',
			'updated_users_first_name'        => '',
			'updated_users_id'                => '',
			'updated_users_last_name'         => '',
			'updated_users_nickname'          => '',
			'updated_users_username'          => '',
		);

		if ( false === $user ) {
			return $tokens;
		}

		$tokens['updated_users_biographical_info'] = get_user_meta( $user_id, 'description', true );
		$tokens['updated_users_display_name']      = $user->display_name;
		$tokens['updated_users_email']             = $user->user_email;
		$tokens['updated_users_first_name']        = get_user_meta( $user_id, 'first_name', true );
		$tokens['updated_users_id']                = (string) $user->ID;
		$tokens['updated_users_last_name']         = get_user_meta( $user_id, 'last_name', true );
		$tokens['updated_users_nickname']          = $user->user_nicename;
		$tokens['updated_users_username']          = $user->user_login;

		return $tokens;
	}

	/**
	 * Normalize an ACF meta value to a string suitable for token output.
	 *
	 * Mirrors legacy gallery/image/true_false/array conversion.
	 *
	 * @param mixed $meta_value   Raw meta value.
	 * @param array $field_object ACF field object (from acf_get_field_object()).
	 *
	 * @return string
	 */
	protected function normalize_meta_value( $meta_value, $field_object ) {

		$field_type = is_array( $field_object ) && isset( $field_object['type'] ) ? $field_object['type'] : '';

		// Gallery: collect attachment URLs.
		if ( 'gallery' === $field_type && is_array( $meta_value ) ) {
			$images = array();
			foreach ( $meta_value as $image_id ) {
				$images[] = wp_get_attachment_url( $image_id );
			}
			$meta_value = $images;
		}

		// Image: resolve attachment URL.
		if ( 'image' === $field_type ) {
			$meta_value = wp_get_attachment_url( $meta_value );
		}

		// True/False: cast to readable string.
		if ( 'true_false' === $field_type ) {
			$values     = array( 'False', 'True' );
			$meta_value = isset( $values[ (int) $meta_value ] ) ? $values[ (int) $meta_value ] : '';
		}

		// Group: flatten sub-fields.
		if ( 'group' === $field_type && is_array( $meta_value ) ) {
			$group_data = array();
			foreach ( $meta_value as $sub_field_key => $sub_field_value ) {
				$sub_field_object = function_exists( 'get_field_object' ) ? get_field_object( $sub_field_key ) : false;
				$sub_field_name   = $sub_field_object ? $sub_field_object['label'] : $sub_field_key;
				$processed_value  = is_array( $sub_field_value ) ? implode( ', ', $sub_field_value ) : $sub_field_value;
				$group_data[]     = $sub_field_name . ': ' . $processed_value;
			}
			$meta_value = implode( ' | ', $group_data );
		}

		// Generic array → comma list.
		if ( is_array( $meta_value ) ) {
			$meta_value = apply_filters( 'ua_acf_field_meta_value', implode( ', ', $meta_value ) );
		}

		return (string) $meta_value;
	}
}
