<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_USER_FIELD_UPDATED
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_USER_FIELD_UPDATED extends Trigger {

	/**
	 * Lazy-load definition.
	 *
	 * Legacy listened to both updated_user_meta and added_user_meta — both
	 * pass [ $meta_id, $object_id, $meta_key, $_meta_value ].
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_USER_FIELD_UPDATED', 'ACF' )
			->trigger_meta( 'ACF_USER_FIELD_UPDATED_META' )
			->hook( 'updated_user_meta', 10, 4 )
			->hook( 'added_user_meta', 10, 4 )
			->enqueue_gate( 'ACF_USER_FIELD_UPDATED_META', array( '-1' ) );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* Translators: Trigger sentence */
				esc_html_x( "A user's {{field:%1\$s}} is updated", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence(
			/* Translators: Trigger sentence */
			esc_html_x( "A user's {{field}} is updated", 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'input_type'      => 'select',
				'required'        => true,
				'option_code'     => $this->get_trigger_meta(),
				'options'         => array(),
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'user_fields' ),
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger data.
	 * @param array $tokens  Existing tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->tokens()->acf_user_field_tokens() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args Hook arguments [ $meta_id, $user_id, $meta_key, $meta_value ].
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		list( $meta_id, $user_id, $meta_key, $meta_value ) = $hook_args;
		unset( $meta_id );

		return $this->item_helpers->tokens()->hydrate_acf_user_field_tokens(
			absint( $user_id ),
			$meta_key,
			$meta_value
		);
	}

	/**
	 * Validate the trigger. Mirrors legacy validate_trigger() + trigger_conditions().
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args Hook arguments [ $meta_id, $user_id, $meta_key, $meta_value ].
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		if ( ! isset( $hook_args[2] ) ) {
			return false;
		}

		// added_user_meta fires when the value is added initially — only count
		// it when the value is non-empty (legacy parity).
		if ( false === $this->is_initial_value_empty( $hook_args ) ) {
			return false;
		}

		$meta_key = $hook_args[2];

		// Field must belong to ACF's user_form fields.
		$user_fields = $this->item_helpers->get_user_fields();

		if ( ! in_array( $meta_key, array_keys( $user_fields ), true ) ) {
			return false;
		}

		$selected_field = $trigger['meta'][ $this->get_trigger_meta() ] ?? '';

		if ( '' === $selected_field ) {
			return false;
		}

		// "Any field" sentinel or exact-key match.
		if ( '-1' !== (string) $selected_field && $meta_key !== $selected_field ) {
			return false;
		}

		// Bind the trigger to the user being edited, not the actor.
		$this->set_user_id( absint( $hook_args[1] ) );

		return true;
	}

	/**
	 * Check if the action is `added_user_meta` and the value is empty or not.
	 *
	 * @param array $hook_args The arguments passed to the action hook.
	 *
	 * @return boolean False if current_action is `added_user_meta` and the field value is empty.
	 */
	protected function is_initial_value_empty( $hook_args ) {

		if ( 'added_user_meta' === current_action() ) {
			return ! empty( $hook_args[3] );
		}

		return true;
	}
}
