<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_POST_FIELD_UPDATED
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_POST_FIELD_UPDATED extends Trigger {

	/**
	 * Lazy-load definition.
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_POST_FIELD_UPDATED', 'ACF' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'ACF_POST_FIELD_UPDATED_META' )
			->hook( 'updated_post_meta', 10, 4 )
			->enqueue_gate( 'ACF_FIELD_LIST', array( '-1' ) );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF Field trigger */
				esc_html_x( '{{A field:%1$s}} is updated on {{a post:%2$s}} of {{a post type:%3$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'ACF_FIELD_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_OBJECT_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_LIST:' . $this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence(
			/* translators: ACF Field trigger */
			esc_html_x( '{{A field}} is updated on {{a post}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {

		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_LIST',
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'post_types', 'wp' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_OBJECT_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'Post', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'posts_by_post_type',
					array( 'ACF_WP_POSTS_LIST' )
				),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_FIELD_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'fields',
					array( 'ACF_WP_POSTS_OBJECT_LIST' )
				),
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger data.
	 * @param array $tokens  Existing tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->tokens()->acf_post_field_tokens() );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args Hook arguments [ $meta_id, $object_id, $meta_key, $meta_value ].
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $meta_id, $post_id, $meta_key, $meta_value ) = $hook_args;
		unset( $meta_id );

		$field_object = function_exists( 'get_field_object' ) ? get_field_object( $meta_key ) : array();
		$post_type    = $trigger['meta']['ACF_WP_POSTS_LIST'] ?? get_post_type( $post_id );

		return $this->item_helpers->tokens()->hydrate_acf_post_field_tokens(
			$meta_key,
			$meta_value,
			$post_id,
			$post_type,
			$field_object
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args Hook arguments [ $meta_id, $post_id, $meta_key, $meta_value ].
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $meta_id, $post_id, $meta_key, $meta_value ) = $hook_args;
		unset( $meta_id, $meta_value );

		if ( ! function_exists( 'get_fields' ) ) {
			return false;
		}

		$post_acf_fields = get_fields( $post_id );

		if ( ! is_array( $post_acf_fields ) || empty( $post_acf_fields ) ) {
			return false;
		}

		// Bail when the meta_key is not part of the post's ACF fields.
		if ( ! in_array( $meta_key, array_keys( $post_acf_fields ), true ) ) {
			return false;
		}

		$selected_post_type = $trigger['meta']['ACF_WP_POSTS_LIST'] ?? '';

		if ( '' !== $selected_post_type && $selected_post_type !== get_post_type( $post_id ) ) {
			return false;
		}

		$selected_field = $trigger['meta']['ACF_FIELD_LIST'] ?? '';

		// "Any field" sentinel or exact-key match.
		return -1 === (int) $selected_field || $meta_key === $selected_field;
	}
}
