<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_GROUP_SUBFIELD_UPDATED
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_GROUP_SUBFIELD_UPDATED extends Trigger {

	/**
	 * Lazy-load definition.
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_GROUP_SUBFIELD_UPDATED_CODE', 'ACF' )
			->trigger_meta( 'ACF_GROUP_SUBFIELD_UPDATED_META' )
			->hook( 'update_post_meta', 10, 4 );
	}

	/**
	 * Setup the trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );

		$this->set_readable_sentence(
			esc_html_x(
				'{{A sub field}} in {{a group field}} is updated',
				'Advanced Custom Fields',
				'uncanny-automator-pro'
			)
		);

		$this->set_sentence(
			sprintf(
				/* translators: %1$s: Sub field, %2$s: Group field */
				esc_html_x(
					'{{A sub field:%1$s}} in {{a group field:%2$s}} is updated',
					'Advanced Custom Fields',
					'uncanny-automator-pro'
				),
				$this->get_trigger_meta(),
				'ACF_GROUP_FIELD:' . $this->get_trigger_meta()
			)
		);

		$this->set_support_link(
			Automator()->get_author_support_link(
				$this->get_trigger_code(),
				'integration/advanced-custom-fields/'
			)
		);
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger definition.
	 * @param array $tokens  Tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		$tokens[] = array(
			'tokenId'   => 'ACF_FIELD_NAME',
			'tokenName' => esc_html_x( 'Field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			'tokenType' => 'text',
		);

		return $tokens;
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   Trigger definition.
	 * @param array $hook_args Hook arguments.
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {
		list( $id, $post_id, $meta_key, $meta_value ) = $hook_args;
		unset( $id, $post_id, $meta_value );

		return array(
			'ACF_FIELD_NAME' => $meta_key,
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'option_code'     => 'ACF_GROUP_FIELD',
				'options_show_id' => false,
				'label'           => esc_html_x( 'Group field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'group_fields' ),
			),
			array(
				'option_code'     => $this->get_trigger_meta(),
				'options_show_id' => false,
				'label'           => esc_html_x( 'Sub field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'sub_fields',
					array( 'ACF_GROUP_FIELD' )
				),
			),
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * @param array $trigger   Trigger definition.
	 * @param array $hook_args Hook arguments.
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		// Reject disallowed post types early.
		if ( in_array( $hook_args[2], Acf_Helpers_Pro::get_disallowed_post_types(), true ) ) {
			return false;
		}

		list( $id, $post_id, $meta_key, $meta_value ) = $hook_args;
		unset( $id, $post_id, $meta_value );

		// Ignore WP internal meta.
		if ( '_edit_lock' === $meta_key || '_edit_last' === $meta_key ) {
			return false;
		}

		$selected_group_field = $trigger['meta']['ACF_GROUP_FIELD'] ?? '';
		$selected_sub_field   = $trigger['meta'][ $this->get_trigger_meta() ] ?? '';

		if ( '' === $selected_group_field || '' === $selected_sub_field ) {
			return false;
		}

		// Case 1: Any group + any subfield.
		if ( -1 === (int) $selected_group_field && -1 === (int) $selected_sub_field ) {
			static $pattern = null; // Cache the pattern for better performance.
			if ( null === $pattern ) {
				$needles = Acf_Helpers_Pro::get_group_field_names();
				if ( $needles ) {
					$pattern = '/' . implode( '|', array_map( 'preg_quote', $needles ) ) . '/i';
				}
			}
			return $pattern && preg_match( $pattern, $meta_key );
		}

		// Case 2: Specific group, any subfield.
		if ( -1 === (int) $selected_sub_field ) {
			return str_starts_with( $meta_key, $selected_group_field . '_' );
		}

		// Case 3: Specific group + exact subfield.
		$key_from_postmeta = $selected_group_field . '_' . $selected_sub_field;
		return $meta_key === $key_from_postmeta;
	}
}
