<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_OPTIONS_PAGE_SAVED
 *
 * Fires when an ACF options page is saved via admin. Requires ACF Pro 6.1.7+.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_OPTIONS_PAGE_SAVED extends Trigger {

	/**
	 * Lazy-load definition.
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_OPTIONS_PAGE_SAVED', 'ACF' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'ACF_OPTIONS_PAGE' )
			->hook( 'acf/options_page/save', 10, 2 );
	}

	/**
	 * Per-item active check — Options pages require ACF Pro 6.1.7+.
	 *
	 * @return bool
	 */
	public function requirements_met() {

		if ( ! class_exists( 'ACF' ) ) {
			return false;
		}

		if ( ! function_exists( 'acf_is_pro' ) || ! acf_is_pro() ) {
			return false;
		}

		if ( ! defined( 'ACF_VERSION' ) || version_compare( ACF_VERSION, '6.1.7', '<' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF options-page saved trigger */
				esc_html_x( '{{An options page:%1$s}} is saved', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				$this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( '{{An options page}} is saved', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {

		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => $this->get_trigger_meta(),
				'required'        => true,
				'label'           => esc_html_x( 'Options page', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'options_pages' ),
			),
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $post_id, $menu_slug ].
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $post_id, $menu_slug ) = array_pad( $hook_args, 2, null );
		unset( $post_id );

		$selected_slug = $trigger['meta'][ $this->get_trigger_meta() ] ?? '';

		if ( '' === $selected_slug ) {
			return false;
		}

		if ( -1 === (int) $selected_slug ) {
			return true;
		}

		return $selected_slug === (string) $menu_slug;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger data.
	 * @param array $tokens  Existing tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {

		$page_tokens = array(
			array(
				'tokenId'   => 'ACF_TRIGGER_OPTIONS_PAGE_SLUG',
				'tokenName' => esc_html_x( 'Options page slug', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_OPTIONS_PAGE_POST_ID',
				'tokenName' => esc_html_x( 'Options page post ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_OPTIONS_PAGE_TITLE',
				'tokenName' => esc_html_x( 'Options page title', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_OPTIONS_PAGE_FIELDS_JSON',
				'tokenName' => esc_html_x( 'Options page fields (JSON)', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge( $tokens, $page_tokens );
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $post_id, $menu_slug ].
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		unset( $trigger );

		list( $post_id, $menu_slug ) = array_pad( $hook_args, 2, null );

		$page_title = '';

		if ( function_exists( 'acf_get_options_page' ) ) {
			$page = acf_get_options_page( (string) $menu_slug );
			if ( is_array( $page ) && isset( $page['page_title'] ) ) {
				$page_title = (string) $page['page_title'];
			}
		}

		$fields_json = '';

		if ( function_exists( 'get_fields' ) ) {
			$fields      = get_fields( (string) $post_id );
			$fields_json = wp_json_encode( is_array( $fields ) ? $fields : array() );
		}

		return array(
			'ACF_TRIGGER_OPTIONS_PAGE_SLUG'        => (string) $menu_slug,
			'ACF_TRIGGER_OPTIONS_PAGE_POST_ID'     => (string) $post_id,
			'ACF_TRIGGER_OPTIONS_PAGE_TITLE'       => $page_title,
			'ACF_TRIGGER_OPTIONS_PAGE_FIELDS_JSON' => (string) $fields_json,
		);
	}
}
