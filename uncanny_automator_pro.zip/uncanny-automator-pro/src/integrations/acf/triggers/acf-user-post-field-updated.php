<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_USER_POST_FIELD_UPDATED
 *
 * Fires when a logged-in user updates an ACF field (top-level or group sub-field)
 * on a post.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_USER_POST_FIELD_UPDATED extends Trigger {

	/**
	 * Lazy-load definition. Listens to both add_post_meta and updated_post_meta
	 * for legacy parity.
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_USER_POST_FIELD_UPDATED', 'ACF' )
			->trigger_meta( 'ACF_USER_POST_FIELD_UPDATED_META' )
			->hook( 'updated_post_meta', 10, 4 )
			->hook( 'added_post_meta', 10, 4 );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF user-post-field trigger */
				esc_html_x( 'A user updates {{a field:%1$s}} on {{a post:%2$s}} of {{a post type:%3$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'ACF_FIELD_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_OBJECT_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_LIST:' . $this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( 'A user updates {{a field}} on {{a post}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {

		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_LIST',
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'post_types', 'wp' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_OBJECT_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'Post', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'posts_by_post_type',
					array( 'ACF_WP_POSTS_LIST' )
				),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_FIELD_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'fields',
					array( 'ACF_WP_POSTS_OBJECT_LIST' )
				),
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger data.
	 * @param array $tokens  Existing tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {
		return array_merge( $tokens, $this->item_helpers->tokens()->acf_post_field_tokens() );
	}

	/**
	 * Hydrate tokens. Handles top-level ACF fields and group sub-fields.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $meta_id, $post_id, $meta_key, $meta_value ].
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		list( $meta_id, $post_id, $meta_key, $meta_value ) = $hook_args;
		unset( $meta_id );

		$field_object = function_exists( 'get_field_object' ) ? get_field_object( $meta_key ) : array();
		$post_type    = $trigger['meta']['ACF_WP_POSTS_LIST'] ?? get_post_type( $post_id );

		// Group sub-field: load the parent group's full value so token output
		// matches legacy formatting (`label: value | label: value`).
		$post_acf_fields    = function_exists( 'get_fields' ) ? get_fields( absint( $post_id ) ) : array();
		$parent_group_field = $this->get_parent_group_field( $meta_key, $post_acf_fields );

		if ( null !== $parent_group_field && function_exists( 'get_field' ) ) {

			$group_data           = get_field( $parent_group_field, $post_id );
			$group_data_formatted = array();

			if ( ! empty( $group_data ) && is_array( $group_data ) ) {
				foreach ( $group_data as $sub_field_key => $sub_field_value ) {
					$sub_field_object       = function_exists( 'get_field_object' ) ? get_field_object( $sub_field_key ) : false;
					$sub_field_name         = $sub_field_object ? $sub_field_object['label'] : $sub_field_key;
					$processed_value        = is_array( $sub_field_value ) ? implode( ', ', $sub_field_value ) : $sub_field_value;
					$group_data_formatted[] = $sub_field_name . ': ' . $processed_value;
				}
			}

			$meta_value = implode( ' | ', $group_data_formatted );
		}

		return $this->item_helpers->tokens()->hydrate_acf_post_field_tokens(
			$meta_key,
			$meta_value,
			$post_id,
			$post_type,
			$field_object
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $meta_id, $post_id, $meta_key, $meta_value ].
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $meta_id, $post_id, $meta_key, $meta_value ) = $hook_args;
		unset( $meta_id, $meta_value );

		if ( ! function_exists( 'get_fields' ) ) {
			return false;
		}

		$post_acf_fields = get_fields( absint( $post_id ) );

		if ( ! is_array( $post_acf_fields ) ) {
			$post_acf_fields = array();
		}

		$is_acf_field      = in_array( $meta_key, array_keys( $post_acf_fields ), true );
		$is_group_subfield = $this->is_group_subfield( $meta_key, $post_acf_fields );

		if ( ! $is_acf_field && ! $is_group_subfield ) {
			return false;
		}

		// Post type filter — must match the selected post type.
		$selected_post_type = $trigger['meta']['ACF_WP_POSTS_LIST'] ?? '';

		if ( '' !== $selected_post_type && $selected_post_type !== get_post_type( $post_id ) ) {
			return false;
		}

		$selected_field = $trigger['meta']['ACF_FIELD_LIST'] ?? '';

		// "Any field" sentinel.
		if ( -1 === (int) $selected_field ) {
			return true;
		}

		// Exact-key match.
		if ( $meta_key === $selected_field ) {
			return true;
		}

		// Group sub-field selected by its parent group's name.
		if ( $is_group_subfield ) {
			$parent_group_field = $this->get_parent_group_field( $meta_key, $post_acf_fields );
			return null !== $parent_group_field && $parent_group_field === $selected_field;
		}

		return false;
	}

	/**
	 * Check if a meta_key is a sub-field of any group field.
	 *
	 * @param string $meta_key        The meta key to check.
	 * @param array  $post_acf_fields The ACF fields for the post.
	 *
	 * @return bool
	 */
	protected function is_group_subfield( $meta_key, $post_acf_fields ) {

		if ( ! is_array( $post_acf_fields ) || empty( $post_acf_fields ) ) {
			return false;
		}

		foreach ( $post_acf_fields as $field_name => $field_value ) {
			unset( $field_value );
			$field_object = function_exists( 'get_field_object' ) ? get_field_object( $field_name ) : false;

			if ( $field_object && 'group' === $field_object['type'] && 0 === strpos( $meta_key, $field_name . '_' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get the parent group field name for a sub-field meta key.
	 *
	 * @param string $meta_key        The sub-field meta key.
	 * @param array  $post_acf_fields The ACF fields for the post.
	 *
	 * @return string|null
	 */
	protected function get_parent_group_field( $meta_key, $post_acf_fields ) {

		if ( ! is_array( $post_acf_fields ) || empty( $post_acf_fields ) ) {
			return null;
		}

		foreach ( $post_acf_fields as $field_name => $field_value ) {
			unset( $field_value );
			$field_object = function_exists( 'get_field_object' ) ? get_field_object( $field_name ) : false;

			if ( $field_object && 'group' === $field_object['type'] && 0 === strpos( $meta_key, $field_name . '_' ) ) {
				return $field_name;
			}
		}

		return null;
	}
}
