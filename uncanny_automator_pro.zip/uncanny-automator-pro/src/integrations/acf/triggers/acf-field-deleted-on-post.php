<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_FIELD_DELETED_ON_POST
 *
 * Fires when ACF removes a field's stored value on a post — e.g. a repeater /
 * flexible-content row is deleted (ACF deletes each sub-field value), a group is
 * torn down, or a value is deleted programmatically (delete_field / null update).
 * Emptying a plain field and saving does NOT fire this — that is an update to ''.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_FIELD_DELETED_ON_POST extends Trigger {

	/**
	 * Lazy-load definition.
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_FIELD_DELETED_ON_POST', 'ACF' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'ACF_FIELD_DELETED_ON_POST_META' )
			->hook( 'acf/delete_value', 10, 3 );
	}

	/**
	 * Per-item active check — ACF Free or Pro is sufficient.
	 *
	 * @return bool
	 */
	public function requirements_met() {
		return class_exists( 'ACF' );
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF field deleted trigger */
				esc_html_x( '{{A field:%1$s}} is deleted on {{a post:%2$s}} of {{a post type:%3$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'ACF_FIELD_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_OBJECT_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_LIST:' . $this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( '{{A field}} is deleted on {{a post}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {

		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_LIST',
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'post_types', 'wp' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_OBJECT_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'Post', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'posts_by_post_type',
					array( 'ACF_WP_POSTS_LIST' )
				),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_FIELD_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'description'     => esc_html_x( "Only fields that support delete operations in ACF are listed here. When 'Any field' is selected, the trigger runs whenever a supported field's value is deleted.", 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'deletable_fields',
					array( 'ACF_WP_POSTS_OBJECT_LIST' )
				),
			),
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args Hook arguments [ $post_id, $meta_name, $field ].
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $post_id, $meta_name, $field ) = array_pad( $hook_args, 3, null );
		unset( $meta_name );

		// Reject non-post scopes (user_, term_, options, etc.).
		if ( ! is_numeric( $post_id ) ) {
			return false;
		}

		$post_id   = (int) $post_id;
		$post_type = get_post_type( $post_id );

		if ( empty( $post_type ) ) {
			return false;
		}

		$selected_post_type = $trigger['meta']['ACF_WP_POSTS_LIST'] ?? '';

		if ( '' !== $selected_post_type && $selected_post_type !== $post_type ) {
			return false;
		}

		$selected_post = $trigger['meta']['ACF_WP_POSTS_OBJECT_LIST'] ?? '';

		// "Any post" stores the post-type slug (non-numeric), not -1; only filter
		// when a specific post ID was chosen.
		if ( is_numeric( $selected_post ) && (int) $selected_post > 0 && (int) $selected_post !== $post_id ) {
			return false;
		}

		$selected_field = $trigger['meta']['ACF_FIELD_LIST'] ?? '';

		// Match on the field key — stable across repeater rows, unlike the
		// row-indexed meta name (e.g. repeat_list_2_fruit_name).
		$fired_field_key = is_array( $field ) && isset( $field['key'] ) ? (string) $field['key'] : '';

		if ( '' !== $selected_field && '-1' !== (string) $selected_field && (string) $selected_field !== $fired_field_key ) {
			return false;
		}

		return true;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger data.
	 * @param array $tokens  Existing tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {

		$field_tokens = array(
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_NAME',
				'tokenName' => esc_html_x( 'ACF field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_KEY',
				'tokenName' => esc_html_x( 'ACF field key', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_TYPE',
				'tokenName' => esc_html_x( 'ACF field type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge(
			$tokens,
			$field_tokens,
			$this->item_helpers->trigger_post_id_tokens()
		);
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $post_id, $meta_name, $field ].
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		unset( $trigger );

		list( $post_id, $meta_name, $field ) = array_pad( $hook_args, 3, null );

		$field      = is_array( $field ) ? $field : array();
		$field_name = isset( $field['label'] ) && '' !== $field['label'] ? $field['label'] : (string) $meta_name;
		$field_key  = isset( $field['key'] ) ? (string) $field['key'] : '';
		$field_type = isset( $field['type'] ) ? (string) $field['type'] : '';

		$tokens = array(
			'ACF_TRIGGER_FIELD_NAME' => $field_name,
			'ACF_TRIGGER_FIELD_KEY'  => $field_key,
			'ACF_TRIGGER_FIELD_TYPE' => $field_type,
		);

		return array_merge( $tokens, $this->item_helpers->hydrate_trigger_post_id_tokens( (int) $post_id ) );
	}
}
