<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Trigger;
use Uncanny_Automator\Recipe\Trigger_Definition;

/**
 * Class ACF_REPEATER_ROW_ADDED_ON_POST
 *
 * Fires when a row is appended to a repeater or flexible-content field on a post.
 *
 * Detection runs in Acf_Integration's dispatcher: it snapshots row counts at
 * acf/save_post priority 9 (before ACF writes at 10), diffs at priority 20, and
 * fires the normalised automator_acf_repeater_row_added action this trigger
 * listens on. Doing the diff in the dispatcher keeps the timing explicit and
 * independent of when this (lazy) trigger is constructed.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_REPEATER_ROW_ADDED_ON_POST extends Trigger {

	/**
	 * Lazy-load definition.
	 *
	 * @return Trigger_Definition
	 */
	public static function definition() {
		return self::new_definition( 'ACF_REPEATER_ROW_ADDED_ON_POST', 'ACF' )
			->trigger_type( 'anonymous' )
			->trigger_meta( 'ACF_REPEATER_ROW_ADDED_ON_POST_META' )
			->hook( 'automator_acf_repeater_row_added', 10, 4 );
	}

	/**
	 * Per-item active check — Repeater/Flex are ACF Pro only.
	 *
	 * @return bool
	 */
	public function requirements_met() {

		if ( ! class_exists( 'ACF' ) ) {
			return false;
		}

		return function_exists( 'acf_is_pro' ) && acf_is_pro();
	}

	/**
	 * Setup trigger.
	 *
	 * @return void
	 */
	protected function setup_trigger() {

		$this->set_is_pro( true );
		$this->set_is_login_required( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF repeater/flex row-added trigger */
				esc_html_x( 'A row is added to {{a repeater/flex field:%1$s}} on {{a post:%2$s}} of {{a post type:%3$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'ACF_REPEATER_FLEX_FIELD:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_OBJECT_LIST:' . $this->get_trigger_meta(),
				'ACF_WP_POSTS_LIST:' . $this->get_trigger_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( 'A row is added to {{a repeater/flex field}} on {{a post}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {

		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_LIST',
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'post_types', 'wp' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_OBJECT_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'Post', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'posts_by_post_type',
					array( 'ACF_WP_POSTS_LIST' )
				),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_REPEATER_FLEX_FIELD',
				'required'        => true,
				'label'           => esc_html_x( 'Repeater or flexible content field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'repeater_flex_fields',
					array( 'ACF_WP_POSTS_OBJECT_LIST' )
				),
			),
		);
	}

	/**
	 * Validate the trigger.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $post_id, $field_name, $row_index, $new_count ].
	 *
	 * @return bool
	 */
	public function validate( $trigger, $hook_args ) {

		list( $post_id, $field_name ) = array_pad( $hook_args, 4, null );

		if ( ! is_numeric( $post_id ) || empty( $field_name ) ) {
			return false;
		}

		$post_id   = (int) $post_id;
		$post_type = get_post_type( $post_id );

		if ( empty( $post_type ) ) {
			return false;
		}

		$selected_post_type = $trigger['meta']['ACF_WP_POSTS_LIST'] ?? '';

		if ( '' !== $selected_post_type && $selected_post_type !== $post_type ) {
			return false;
		}

		$selected_post = $trigger['meta']['ACF_WP_POSTS_OBJECT_LIST'] ?? '';

		// "Any post" stores the post-type slug (non-numeric), not -1; only filter
		// when a specific post ID was chosen.
		if ( is_numeric( $selected_post ) && (int) $selected_post > 0 && (int) $selected_post !== $post_id ) {
			return false;
		}

		$selected_field = $trigger['meta']['ACF_REPEATER_FLEX_FIELD'] ?? '';

		if ( '' === $selected_field ) {
			return false;
		}

		return -1 === (int) $selected_field || (string) $selected_field === (string) $field_name;
	}

	/**
	 * Define tokens.
	 *
	 * @param array $trigger Trigger data.
	 * @param array $tokens  Existing tokens.
	 *
	 * @return array
	 */
	public function define_tokens( $trigger, $tokens ) {

		$row_tokens = array(
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_NAME',
				'tokenName' => esc_html_x( 'Field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_KEY',
				'tokenName' => esc_html_x( 'Field key', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_FIELD_TYPE',
				'tokenName' => esc_html_x( 'Field type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_ROW_INDEX',
				'tokenName' => esc_html_x( 'New row index', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_ROW_COUNT',
				'tokenName' => esc_html_x( 'Total row count', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_ROW_LAYOUT',
				'tokenName' => esc_html_x( 'Row layout', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_ROW_VALUE',
				'tokenName' => esc_html_x( 'Row value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_ROW_JSON',
				'tokenName' => esc_html_x( 'Row data (JSON)', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);

		return array_merge(
			$tokens,
			$this->item_helpers->trigger_post_id_tokens(),
			$row_tokens
		);
	}

	/**
	 * Hydrate tokens.
	 *
	 * @param array $trigger   Trigger data.
	 * @param array $hook_args [ $post_id, $field_name, $row_index, $new_count ].
	 *
	 * @return array
	 */
	public function hydrate_tokens( $trigger, $hook_args ) {

		unset( $trigger );

		list( $post_id, $field_name, $row_index, $new_count ) = array_pad( $hook_args, 4, null );

		$post_id    = (int) $post_id;
		$field_name = (string) $field_name;
		$row_index  = (int) $row_index;
		$new_count  = (int) $new_count;

		$field_object = function_exists( 'get_field_object' ) ? get_field_object( $field_name, $post_id ) : array();
		$field_object = is_array( $field_object ) ? $field_object : array();

		$row_data   = array();
		$row_layout = '';

		if ( function_exists( 'get_field' ) ) {
			$full_value = get_field( $field_name, $post_id );
			if ( is_array( $full_value ) && isset( $full_value[ $row_index ] ) && is_array( $full_value[ $row_index ] ) ) {
				$row_data   = $full_value[ $row_index ];
				$row_layout = isset( $row_data['acf_fc_layout'] ) ? (string) $row_data['acf_fc_layout'] : '';
			}
		}

		// Plain-text rendering of the row's sub-field values (scalars joined with
		// commas; non-scalars fall back to JSON). The full structure stays in
		// ACF_TRIGGER_ROW_JSON.
		$row_value_parts = array();
		foreach ( $row_data as $sub_key => $sub_value ) {
			if ( 'acf_fc_layout' === $sub_key ) {
				continue;
			}
			$row_value_parts[] = is_scalar( $sub_value ) ? (string) $sub_value : (string) wp_json_encode( $sub_value );
		}
		$row_value_text = implode( ', ', $row_value_parts );

		return array_merge(
			$this->item_helpers->hydrate_trigger_post_id_tokens( $post_id ),
			array(
				'ACF_TRIGGER_FIELD_NAME' => isset( $field_object['label'] ) ? $field_object['label'] : $field_name,
				'ACF_TRIGGER_FIELD_KEY'  => isset( $field_object['key'] ) ? $field_object['key'] : '',
				'ACF_TRIGGER_FIELD_TYPE' => isset( $field_object['type'] ) ? $field_object['type'] : '',
				'ACF_TRIGGER_ROW_INDEX'  => $row_index,
				'ACF_TRIGGER_ROW_COUNT'  => $new_count,
				'ACF_TRIGGER_ROW_LAYOUT' => $row_layout,
				'ACF_TRIGGER_ROW_VALUE'  => $row_value_text,
				'ACF_TRIGGER_ROW_JSON'   => wp_json_encode( $row_data ),
			)
		);
	}
}
