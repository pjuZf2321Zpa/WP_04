<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Action;

/**
 * Class ACF_UPDATE_FIELD_ON_POST
 *
 * Updates an ACF field on a selected post.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_UPDATE_FIELD_ON_POST extends Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ACF' );
		$this->set_action_code( 'ACF_UPDATE_FIELD_ON_POST' );
		$this->set_action_meta( 'ACF_FIELD_LIST' );
		$this->set_is_pro( true );
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF update field on post action */
				esc_html_x( 'Update {{a field:%1$s}} on {{a post:%2$s}} of {{a post type:%3$s}} to {{a specific value:%4$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'ACF_WP_POSTS_OBJECT_LIST:' . $this->get_action_meta(),
				'ACF_WP_POSTS_LIST:' . $this->get_action_meta(),
				'ACF_FIELD_VALUE:' . $this->get_action_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( 'Update {{a field}} on {{a post}} to {{a specific value}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Per-item active check — ACF Free is sufficient.
	 *
	 * @return bool
	 */
	public function requirements_met() {
		return class_exists( 'ACF' );
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_LIST',
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'post_types_strict', 'wp' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_OBJECT_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'Post', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'posts_by_post_type_strict',
					array( 'ACF_WP_POSTS_LIST' )
				),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => $this->get_action_meta(),
				'required'        => true,
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'fields_strict',
					array( 'ACF_WP_POSTS_OBJECT_LIST' )
				),
			),
			array(
				'option_code' => 'ACF_FIELD_VALUE',
				'label'       => esc_html_x( 'Value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => true,
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'ACF_ACTION_FIELD_NAME' => array(
				'name' => esc_html_x( 'Field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_POST_ID'    => array(
				'name' => esc_html_x( 'Post ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_NEW_VALUE'  => array(
				'name' => esc_html_x( 'New value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_SUCCESS'    => array(
				'name' => esc_html_x( 'Success', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process the action.
	 *
	 * @param int   $user_id     The user ID.
	 * @param array $action_data Action metadata.
	 * @param int   $recipe_id   Recipe ID.
	 * @param array $args        Run args.
	 * @param array $parsed      Token-resolved option values.
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		unset( $user_id, $action_data, $recipe_id, $args );

		if ( ! function_exists( 'update_field' ) ) {
			$this->add_log_error( esc_html_x( 'ACF update_field() is not available.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$post_id  = isset( $parsed['ACF_WP_POSTS_OBJECT_LIST'] ) ? absint( $parsed['ACF_WP_POSTS_OBJECT_LIST'] ) : 0;
		$selector = isset( $parsed[ $this->get_action_meta() ] ) ? sanitize_text_field( $parsed[ $this->get_action_meta() ] ) : '';
		$value    = $parsed['ACF_FIELD_VALUE'] ?? '';

		if ( 0 === $post_id ) {
			$this->add_log_error( esc_html_x( 'A valid post is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		if ( '' === $selector ) {
			$this->add_log_error( esc_html_x( 'An ACF field is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$success = update_field( $selector, $value, $post_id );

		if ( false === $success ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: field selector, 2: post id */
					esc_html_x( 'Failed to update ACF field "%1$s" on post %2$d.', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
					$selector,
					$post_id
				)
			);
			return false;
		}

		$this->hydrate_tokens(
			array(
				'ACF_ACTION_FIELD_NAME' => $selector,
				'ACF_ACTION_POST_ID'    => $post_id,
				'ACF_ACTION_NEW_VALUE'  => is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value ),
				'ACF_ACTION_SUCCESS'    => '1',
			)
		);

		return true;
	}
}
