<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Action;

/**
 * Class ACF_ADD_ROW_TO_REPEATER_ON_POST
 *
 * Appends one or more rows to a repeater field on a selected post.
 *
 * Values are entered via a single-column repeater in the builder; each row adds
 * a new ACF row, with the value assigned to the repeater's first sub-field.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_ADD_ROW_TO_REPEATER_ON_POST extends Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ACF' );
		$this->set_action_code( 'ACF_ADD_ROW_TO_REPEATER_ON_POST' );
		$this->set_action_meta( 'ACF_REPEATER_FLEX_FIELD' );
		$this->set_is_pro( true );
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF add row action */
				esc_html_x( 'Add a row to {{a repeater/flex field:%1$s}} on {{a post:%2$s}} of {{a post type:%3$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'ACF_WP_POSTS_OBJECT_LIST:' . $this->get_action_meta(),
				'ACF_WP_POSTS_LIST:' . $this->get_action_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( 'Add a row to {{a repeater/flex field}} on {{a post}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Per-item active check — Repeater/Flex requires ACF Pro.
	 *
	 * @return bool
	 */
	public function requirements_met() {

		if ( ! class_exists( 'ACF' ) ) {
			return false;
		}

		return function_exists( 'acf_is_pro' ) && acf_is_pro();
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_LIST',
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'post_types_strict', 'wp' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_WP_POSTS_OBJECT_LIST',
				'required'        => true,
				'label'           => esc_html_x( 'Post', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'posts_by_post_type_strict',
					array( 'ACF_WP_POSTS_LIST' )
				),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => $this->get_action_meta(),
				'required'        => true,
				'label'           => esc_html_x( 'Repeater or flexible content field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'repeater_flex_fields_strict',
					array( 'ACF_WP_POSTS_OBJECT_LIST' )
				),
			),
			array(
				'option_code'       => 'ACF_ROWS',
				'input_type'        => 'repeater',
				'label'             => esc_html_x( 'Rows', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'description'       => esc_html_x( 'Each row adds a new row to the repeater. The value is saved to the repeater\'s first sub-field.', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'required'          => true,
				'fields'            => array(
					array(
						'option_code'     => 'ACF_ROW_VALUE',
						'label'           => esc_html_x( 'Value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
						'input_type'      => 'text',
						'supports_tokens' => true,
						'required'        => true,
					),
				),
				/* translators: Non-personal infinitive verb */
				'add_row_button'    => esc_attr_x( 'Add row', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				/* translators: Non-personal infinitive verb */
				'remove_row_button' => esc_attr_x( 'Remove row', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'ACF_ACTION_POST_ID'    => array(
				'name' => esc_html_x( 'Post ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_FIELD_NAME' => array(
				'name' => esc_html_x( 'Field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_ROW_INDEX'  => array(
				'name' => esc_html_x( 'New row index', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_ROW_COUNT'  => array(
				'name' => esc_html_x( 'Total row count', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_SUCCESS'    => array(
				'name' => esc_html_x( 'Success', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process the action.
	 *
	 * @param int   $user_id     The user ID.
	 * @param array $action_data Action metadata.
	 * @param int   $recipe_id   Recipe ID.
	 * @param array $args        Run args.
	 * @param array $parsed      Token-resolved option values.
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! function_exists( 'add_row' ) ) {
			$this->add_log_error( esc_html_x( 'ACF add_row() is not available. ACF Pro is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$post_id  = isset( $parsed['ACF_WP_POSTS_OBJECT_LIST'] ) ? absint( $parsed['ACF_WP_POSTS_OBJECT_LIST'] ) : 0;
		$selector = isset( $parsed[ $this->get_action_meta() ] ) ? sanitize_text_field( $parsed[ $this->get_action_meta() ] ) : '';

		if ( 0 === $post_id ) {
			$this->add_log_error( esc_html_x( 'A valid post is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		if ( '' === $selector ) {
			$this->add_log_error( esc_html_x( 'A repeater field is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		// Repeater sub-field values arrive as raw JSON in the action meta.
		$rows_raw = $action_data['meta']['ACF_ROWS'] ?? '';
		$rows     = is_string( $rows_raw ) ? json_decode( $rows_raw, true ) : $rows_raw;

		if ( empty( $rows ) || ! is_array( $rows ) ) {
			$this->add_log_error( esc_html_x( 'At least one row value is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		// Resolve the repeater's first sub-field (single sub-field mapping).
		$sub_field_name = $this->resolve_first_sub_field_name( $selector, $post_id );

		if ( '' === $sub_field_name ) {
			$this->add_log_error( esc_html_x( 'Could not resolve a sub-field for the selected field. This action supports repeater fields with at least one sub-field.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$row_count = 0;
		$added     = 0;

		foreach ( $rows as $row ) {

			$value = is_array( $row ) && isset( $row['ACF_ROW_VALUE'] ) ? (string) $row['ACF_ROW_VALUE'] : '';
			$value = Automator()->parse->text( $value, $recipe_id, $user_id, $args );

			$result = add_row( $selector, array( $sub_field_name => $value ), $post_id );

			if ( false === $result || ! is_numeric( $result ) ) {
				continue;
			}

			$row_count = (int) $result;
			++$added;
		}

		if ( 0 === $added ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: field selector, 2: post id */
					esc_html_x( 'Failed to add any rows to "%1$s" on post %2$d.', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
					$selector,
					$post_id
				)
			);
			return false;
		}

		$this->hydrate_tokens(
			array(
				'ACF_ACTION_POST_ID'    => $post_id,
				'ACF_ACTION_FIELD_NAME' => $selector,
				'ACF_ACTION_ROW_INDEX'  => max( 0, $row_count - 1 ),
				'ACF_ACTION_ROW_COUNT'  => $row_count,
				'ACF_ACTION_SUCCESS'    => '1',
			)
		);

		return true;
	}

	/**
	 * Resolve the first sub-field name of a repeater field by selector.
	 *
	 * Uses get_field_object() (resolves by name + post context, exposes
	 * sub_fields) with an acf_get_field() fallback.
	 *
	 * @param string $selector Repeater field name or key.
	 * @param int    $post_id  Post the field lives on.
	 *
	 * @return string Sub-field name, or '' when it cannot be resolved.
	 */
	private function resolve_first_sub_field_name( $selector, $post_id ) {

		$field_obj = function_exists( 'get_field_object' ) ? get_field_object( $selector, $post_id ) : false;

		if ( ! is_array( $field_obj ) && function_exists( 'acf_get_field' ) ) {
			$field_obj = acf_get_field( $selector );
		}

		if ( ! is_array( $field_obj ) || empty( $field_obj['sub_fields'] ) || ! is_array( $field_obj['sub_fields'] ) ) {
			return '';
		}

		$first_sub_field = reset( $field_obj['sub_fields'] );

		return is_array( $first_sub_field ) && ! empty( $first_sub_field['name'] ) ? (string) $first_sub_field['name'] : '';
	}
}
