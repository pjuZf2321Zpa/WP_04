<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Action;

/**
 * Class ACF_UPDATE_FIELD_ON_USER
 *
 * Updates an ACF field on the recipe's resolved user.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_UPDATE_FIELD_ON_USER extends Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ACF' );
		$this->set_action_code( 'ACF_UPDATE_FIELD_ON_USER' );
		$this->set_action_meta( 'ACF_USER_FIELD' );
		$this->set_is_pro( true );
		$this->set_requires_user( true );

		$this->set_sentence(
			sprintf(
				/* translators: ACF update user field action */
				esc_html_x( 'Update {{a field:%1$s}} on the user to {{a specific value:%2$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'ACF_FIELD_VALUE:' . $this->get_action_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( 'Update {{a field}} on the user to {{a specific value}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Per-item active check — ACF Free is sufficient.
	 *
	 * @return bool
	 */
	public function requirements_met() {
		return class_exists( 'ACF' );
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => $this->get_action_meta(),
				'options'         => array(),
				'required'        => true,
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'user_fields_strict' ),
			),
			array(
				'option_code' => 'ACF_FIELD_VALUE',
				'label'       => esc_html_x( 'Value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => true,
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'ACF_ACTION_FIELD_NAME' => array(
				'name' => esc_html_x( 'Field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_USER_ID'    => array(
				'name' => esc_html_x( 'User ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_NEW_VALUE'  => array(
				'name' => esc_html_x( 'New value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_SUCCESS'    => array(
				'name' => esc_html_x( 'Success', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process the action.
	 *
	 * @param int   $user_id     The user ID.
	 * @param array $action_data Action metadata.
	 * @param int   $recipe_id   Recipe ID.
	 * @param array $args        Run args.
	 * @param array $parsed      Token-resolved option values.
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		unset( $action_data, $recipe_id, $args );

		if ( ! function_exists( 'update_field' ) ) {
			$this->add_log_error( esc_html_x( 'ACF update_field() is not available.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$user_id = absint( $user_id );

		if ( 0 === $user_id ) {
			$this->add_log_error( esc_html_x( 'Action requires a logged-in user context.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$selector = isset( $parsed[ $this->get_action_meta() ] ) ? sanitize_text_field( $parsed[ $this->get_action_meta() ] ) : '';
		$value    = $parsed['ACF_FIELD_VALUE'] ?? '';

		if ( '' === $selector ) {
			$this->add_log_error( esc_html_x( 'An ACF field is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$success = update_field( $selector, $value, 'user_' . $user_id );

		if ( false === $success ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: field selector, 2: user id */
					esc_html_x( 'Failed to update ACF field "%1$s" on user %2$d.', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
					$selector,
					$user_id
				)
			);
			return false;
		}

		$this->hydrate_tokens(
			array(
				'ACF_ACTION_FIELD_NAME' => $selector,
				'ACF_ACTION_USER_ID'    => $user_id,
				'ACF_ACTION_NEW_VALUE'  => is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value ),
				'ACF_ACTION_SUCCESS'    => '1',
			)
		);

		return true;
	}
}
