<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator\Recipe\Action;

/**
 * Class ACF_UPDATE_FIELD_ON_OPTIONS_PAGE
 *
 * Updates an ACF field on a selected options page. Requires ACF Pro 6.1.7+.
 *
 * @property Acf_Helpers_Pro $item_helpers
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class ACF_UPDATE_FIELD_ON_OPTIONS_PAGE extends Action {

	/**
	 * Setup action.
	 *
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'ACF' );
		$this->set_action_code( 'ACF_UPDATE_FIELD_ON_OPTIONS_PAGE' );
		$this->set_action_meta( 'ACF_OPTIONS_PAGE_FIELD' );
		$this->set_is_pro( true );
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: ACF options-page update field action */
				esc_html_x( 'Update {{a field:%1$s}} on {{an options page:%2$s}} to {{a specific value:%3$s}}', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'ACF_OPTIONS_PAGE:' . $this->get_action_meta(),
				'ACF_FIELD_VALUE:' . $this->get_action_meta()
			)
		);

		$this->set_readable_sentence(
			esc_html_x( 'Update {{a field}} on {{an options page}} to {{a specific value}}', 'Advanced Custom Fields', 'uncanny-automator-pro' )
		);
	}

	/**
	 * Per-item active check — Options pages require ACF Pro 6.1.7+.
	 *
	 * @return bool
	 */
	public function requirements_met() {

		if ( ! class_exists( 'ACF' ) ) {
			return false;
		}

		if ( ! function_exists( 'acf_is_pro' ) || ! acf_is_pro() ) {
			return false;
		}

		return defined( 'ACF_VERSION' ) && version_compare( ACF_VERSION, '6.1.7', '>=' );
	}

	/**
	 * Options.
	 *
	 * @return array
	 */
	public function options() {
		return array(
			array(
				'input_type'      => 'select',
				'option_code'     => 'ACF_OPTIONS_PAGE',
				'required'        => true,
				'label'           => esc_html_x( 'Options page', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => false,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_load_config( 'options_pages_strict' ),
			),
			array(
				'input_type'      => 'select',
				'option_code'     => $this->get_action_meta(),
				'required'        => true,
				'label'           => esc_html_x( 'ACF field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'supports_tokens' => true,
				'relevant_tokens' => array(),
				'remote_data'     => $this->item_helpers->remote_data_parent_config(
					'options_page_fields_strict',
					array( 'ACF_OPTIONS_PAGE' )
				),
			),
			array(
				'option_code' => 'ACF_FIELD_VALUE',
				'label'       => esc_html_x( 'Value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => true,
				'description' => esc_html_x( 'If the ACF field is an image type, enter the WordPress Media Library ID to attach an image.', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Define tokens.
	 *
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'ACF_ACTION_OPTIONS_PAGE_SLUG'    => array(
				'name' => esc_html_x( 'Options page slug', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_OPTIONS_PAGE_POST_ID' => array(
				'name' => esc_html_x( 'Options page post ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_FIELD_NAME'           => array(
				'name' => esc_html_x( 'Field name', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_NEW_VALUE'            => array(
				'name' => esc_html_x( 'New value', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ACF_ACTION_SUCCESS'              => array(
				'name' => esc_html_x( 'Success', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * Process the action.
	 *
	 * @param int   $user_id     The user ID.
	 * @param array $action_data Action metadata.
	 * @param int   $recipe_id   Recipe ID.
	 * @param array $args        Run args.
	 * @param array $parsed      Token-resolved option values.
	 *
	 * @return bool
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		unset( $user_id, $action_data, $recipe_id, $args );

		if ( ! function_exists( 'update_field' ) || ! function_exists( 'acf_get_options_page' ) ) {
			$this->add_log_error( esc_html_x( 'Required ACF functions are not available. ACF Pro is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$menu_slug = isset( $parsed['ACF_OPTIONS_PAGE'] ) ? sanitize_text_field( $parsed['ACF_OPTIONS_PAGE'] ) : '';
		$selector  = isset( $parsed[ $this->get_action_meta() ] ) ? sanitize_text_field( $parsed[ $this->get_action_meta() ] ) : '';
		$value     = $parsed['ACF_FIELD_VALUE'] ?? '';

		if ( '' === $menu_slug ) {
			$this->add_log_error( esc_html_x( 'An options page is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		if ( '' === $selector ) {
			$this->add_log_error( esc_html_x( 'An ACF field is required.', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
			return false;
		}

		$page = acf_get_options_page( $menu_slug );

		if ( ! is_array( $page ) || empty( $page['post_id'] ) ) {
			$this->add_log_error(
				sprintf(
					/* translators: %s: options page slug */
					esc_html_x( 'Options page "%s" was not found.', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
					$menu_slug
				)
			);
			return false;
		}

		$options_post_id = (string) $page['post_id'];

		$success = update_field( $selector, $value, $options_post_id );

		if ( false === $success ) {
			$this->add_log_error(
				sprintf(
					/* translators: 1: field selector, 2: options page slug */
					esc_html_x( 'Failed to update ACF field "%1$s" on options page "%2$s".', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
					$selector,
					$menu_slug
				)
			);
			return false;
		}

		$this->hydrate_tokens(
			array(
				'ACF_ACTION_OPTIONS_PAGE_SLUG'    => $menu_slug,
				'ACF_ACTION_OPTIONS_PAGE_POST_ID' => $options_post_id,
				'ACF_ACTION_FIELD_NAME'           => $selector,
				'ACF_ACTION_NEW_VALUE'            => is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value ),
				'ACF_ACTION_SUCCESS'              => '1',
			)
		);

		return true;
	}
}
