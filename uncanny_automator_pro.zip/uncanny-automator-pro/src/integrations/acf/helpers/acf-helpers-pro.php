<?php

namespace Uncanny_Automator_Pro\Integrations\Acf;

use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;
use WP_Query;

/**
 * Class Acf_Helpers_Pro
 *
 * @package Uncanny_Automator_Pro\Integrations\Acf
 */
class Acf_Helpers_Pro extends Abstract_Pro_Helpers {

	/**
	 * Lazy-instantiated tokens helper.
	 *
	 * @var Acf_Tokens|null
	 */
	private $tokens = null;

	/**
	 * Get the shared tokens helper.
	 *
	 * @return Acf_Tokens
	 */
	public function tokens() {
		if ( null === $this->tokens ) {
			$this->tokens = new Acf_Tokens( $this );
		}
		return $this->tokens;
	}

	/**
	 * Remote-data handler: fetch posts under a given post type.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_posts_by_post_type( $request ): array {

		$selected_post_type = (string) $request->get_field_value( 'ACF_WP_POSTS_LIST' );
		$recipe_id          = $request->get_recipe_id();

		$args = array(
			'post_type'      => $selected_post_type,
			'posts_per_page' => apply_filters( 'automator_acf_post_type_posts_per_page', 9999, $selected_post_type, $recipe_id ),
			'orderby'        => 'title',
			'order'          => 'ASC',
		);

		$obj = get_post_type_object( $selected_post_type );

		$post_type_name = esc_html_x( 'post', 'Advanced Custom Fields', 'uncanny-automator-pro' );

		if ( isset( $obj->labels->singular_name ) ) {
			$post_type_name = $obj->labels->singular_name;
		}

		$list = array(
			array(
				'value' => $selected_post_type,
				/* translators: The post type singular label */
				'text'  => sprintf( esc_html_x( 'Any %s', 'Advanced Custom Fields', 'uncanny-automator-pro' ), strtolower( $post_type_name ) ),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$list[] = array(
					'value' => get_the_ID(),
					'text'  => get_the_title(),
				);
			}
			wp_reset_postdata();
		}

		return $this->remote_data_success( $list );
	}

	/**
	 * Remote-data handler: fetch ACF fields under a given post / post type.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_fields( $request ): array {

		$post_id = (string) $request->get_field_value( 'ACF_WP_POSTS_OBJECT_LIST' );

		$args = array(
			'post_id' => $post_id,
		);

		// Treat it as post type if its non-numeric.
		if ( ! is_numeric( $post_id ) ) {
			$args = array(
				'post_type' => $post_id,
			);
		}

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $this->remote_data_success( array() );
		}

		$field_groups_collection = acf_get_field_groups( $args );

		$field_groups = array();

		foreach ( $field_groups_collection as $field_group ) {
			$field_groups[] = acf_get_fields( $field_group['key'] );
		}

		$singular_fields = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			),
		);

		if ( ! empty( $field_groups ) && is_array( $field_groups ) ) {
			foreach ( $field_groups as $group_fields ) {
				if ( ! is_array( $group_fields ) ) {
					continue;
				}
				foreach ( $group_fields as $field_group ) {
					$singular_fields[] = array(
						'value' => $field_group['name'],
						'text'  => $field_group['label'],
					);
				}
			}
		}

		return $this->remote_data_success( $singular_fields );
	}

	/**
	 * Remote-data handler: fetch ACF group field names.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_group_fields( $request ): array {

		unset( $request );

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $this->remote_data_success( array() );
		}

		// Defaults to any group field.
		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any group field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			),
		);

		$field_groups = acf_get_field_groups();

		foreach ( $field_groups as $field_group ) {
			$fields = acf_get_fields( $field_group['key'] );
			if ( empty( $fields ) ) {
				continue;
			}
			foreach ( $fields as $field ) {
				if ( 'group' === $field['type'] && isset( $field['name'], $field['label'] ) ) {
					$options[] = array(
						'value' => $field['name'],
						'text'  => $field['label'],
					);
				}
			}
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Remote-data handler: fetch sub fields for a given group field.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_sub_fields( $request ): array {

		if ( ! function_exists( 'acf_get_field' ) ) {
			return $this->remote_data_error( esc_html_x( 'ACF is not active', 'Advanced Custom Fields', 'uncanny-automator-pro' ) );
		}

		$group_key = (string) $request->get_field_value( 'ACF_GROUP_FIELD' );

		$options = array(
			array(
				'text'  => esc_html_x( 'Any sub field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'value' => '-1',
			),
		);

		if ( '-1' === $group_key || '' === $group_key ) {
			return $this->remote_data_success( $options );
		}

		$group_field = acf_get_field( $group_key );

		if ( $group_field && isset( $group_field['sub_fields'] ) ) {
			foreach ( (array) $group_field['sub_fields'] as $sub_field ) {
				if ( ! isset( $sub_field['label'], $sub_field['name'] ) ) {
					continue;
				}
				$options[] = array(
					'value' => $sub_field['name'],
					'text'  => $sub_field['label'],
				);
			}
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Get post types eligible for ACF triggers.
	 *
	 * Returns { slug => label } pairs for non-builtin public post types,
	 * minus the disallowed list.
	 *
	 * @return array
	 */
	public function get_post_types() {

		$post_types = get_post_types(
			array(
				'public'   => true,
				'_builtin' => false,
			),
			'objects',
			'or'
		);

		$delivered_post_types = array();
		$disallowed           = self::get_disallowed_post_types();

		foreach ( $post_types as $key => $post_type ) {
			if ( ! in_array( $key, $disallowed, true ) ) {
				$delivered_post_types[ $key ] = $post_type->label;
			}
		}

		return $delivered_post_types;
	}

	/**
	 * Get disallowed post types.
	 *
	 * @return array
	 */
	public static function get_disallowed_post_types() {

		$disallowed_post_types = array(
			'attachment',
			'revision',
			'nav_menu_item',
			'custom_css',
			'customize_changeset',
			'oembed_cache',
			'user_request',
			'wp_block',
			'wp_template',
		);

		return apply_filters( 'uo_automator_acf_disallowed_post_types', $disallowed_post_types );
	}

	/**
	 * Get the ACF fields registered for the user_form / user_role location.
	 *
	 * @return array
	 */
	public function get_user_fields() {

		if ( ! function_exists( 'acf_get_fields' ) ) {
			return array();
		}

		$fields = array(
			'-1' => esc_html_x( 'Any field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
		);

		$field_groups = $this->get_user_form_field_groups();

		if ( empty( $field_groups ) ) {
			return array();
		}

		foreach ( $field_groups as $group ) {
			$group_fields = acf_get_fields( $group['key'] );
			if ( empty( $group_fields ) ) {
				continue;
			}
			foreach ( $group_fields as $field ) {
				$fields[ esc_attr( $field['name'] ) ] = esc_html( $field['label'] );
			}
		}

		return $fields;
	}

	/**
	 * Get all field groups whose location is user_form or user_role.
	 *
	 * @return array
	 */
	public function get_user_form_field_groups() {

		if ( ! function_exists( 'acf_get_field_groups' ) ) {
			return array();
		}

		$groups_user_form = array();
		$field_groups     = acf_get_field_groups();

		foreach ( $field_groups as $group ) {
			if ( empty( $group['location'] ) ) {
				continue;
			}
			foreach ( $group['location'] as $locations ) {
				foreach ( $locations as $location ) {
					if ( 'user_role' === $location['param'] || 'user_form' === $location['param'] ) {
						$groups_user_form[] = $group;
					}
				}
			}
		}

		return $groups_user_form;
	}

	/**
	 * Get flat array of ACF group field names.
	 *
	 * @return array
	 */
	public static function get_group_field_names() {

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return array();
		}

		$group_names  = array();
		$field_groups = acf_get_field_groups();

		foreach ( $field_groups as $field_group ) {
			$fields = acf_get_fields( $field_group['key'] );
			if ( empty( $fields ) ) {
				continue;
			}
			foreach ( $fields as $field ) {
				if ( 'group' === $field['type'] && isset( $field['name'] ) ) {
					$group_names[] = $field['name'];
				}
			}
		}

		return $group_names;
	}

	/**
	 * Get post types eligible for ACF actions (no "Any" sentinel).
	 *
	 * @return array
	 */
	public function get_post_types_strict() {
		return $this->get_post_types();
	}

	/**
	 * Get ACF fields registered for the user_form / user_role location, strict variant
	 * (no "Any field" sentinel) for actions.
	 *
	 * @return array
	 */
	public function get_user_fields_strict() {

		$fields = $this->get_user_fields();

		if ( isset( $fields['-1'] ) ) {
			unset( $fields['-1'] );
		}

		return $fields;
	}

	/**
	 * Remote-data handler: ACF user-form / user-role fields (with "Any field" sentinel).
	 *
	 * Reachable via POST /wp-json/uap/v2/remote-data/acf/user_fields.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_user_fields( $request ): array {

		unset( $request );

		return $this->remote_data_success( automator_array_as_options( $this->get_user_fields() ) );
	}

	/**
	 * Remote-data handler: ACF user fields, strict variant for actions (no "Any field" sentinel).
	 *
	 * Reachable via POST /wp-json/uap/v2/remote-data/acf/user_fields_strict.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_user_fields_strict( $request ): array {

		unset( $request );

		return $this->remote_data_success( automator_array_as_options( $this->get_user_fields_strict() ) );
	}

	/**
	 * Remote-data: posts under a given post type, strict variant for actions (no "Any post" sentinel).
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_posts_by_post_type_strict( $request ): array {

		$response = $this->remote_data_get_posts_by_post_type( $request );

		if ( ! isset( $response['options'] ) || ! is_array( $response['options'] ) ) {
			return $response;
		}

		$response['options'] = array_values(
			array_filter(
				$response['options'],
				static function ( $option ) {
					return ! is_numeric( $option['value'] ) ? false : true;
				}
			)
		);

		return $response;
	}

	/**
	 * Remote-data: ACF fields, strict variant for actions (no "Any field" sentinel).
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_fields_strict( $request ): array {

		$response = $this->remote_data_get_fields( $request );

		if ( ! isset( $response['options'] ) || ! is_array( $response['options'] ) ) {
			return $response;
		}

		$response['options'] = array_values(
			array_filter(
				$response['options'],
				static function ( $option ) {
					return '-1' !== (string) $option['value'];
				}
			)
		);

		return $response;
	}

	/**
	 * Remote-data: repeater/flexible-content fields on a post (trigger variant — includes "Any").
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_repeater_flex_fields( $request ): array {
		return $this->fetch_repeater_flex_fields( $request, true );
	}

	/**
	 * Remote-data: repeater/flexible-content fields on a post, strict (no "Any" sentinel).
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_repeater_flex_fields_strict( $request ): array {
		return $this->fetch_repeater_flex_fields( $request, false );
	}

	/**
	 * Build a repeater / flexible-content field list scoped to the selected post or post type.
	 *
	 * @param Remote_Data_Request $request     The remote-data request.
	 * @param bool                $include_any Whether to prepend the "Any" sentinel.
	 *
	 * @return array
	 */
	private function fetch_repeater_flex_fields( $request, $include_any ): array {

		$post_id = (string) $request->get_field_value( 'ACF_WP_POSTS_OBJECT_LIST' );

		$args = array( 'post_id' => $post_id );

		if ( ! is_numeric( $post_id ) ) {
			$args = array( 'post_type' => $post_id );
		}

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $this->remote_data_success( array() );
		}

		$field_groups = acf_get_field_groups( $args );

		$options = array();

		if ( $include_any ) {
			$options[] = array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any repeater or flexible content field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			);
		}

		foreach ( $field_groups as $field_group ) {
			$group_fields = acf_get_fields( $field_group['key'] );
			if ( empty( $group_fields ) ) {
				continue;
			}
			foreach ( $group_fields as $field ) {
				if ( ! isset( $field['type'], $field['name'], $field['label'] ) ) {
					continue;
				}
				if ( 'repeater' === $field['type'] || 'flexible_content' === $field['type'] ) {
					$options[] = array(
						'value' => $field['name'],
						'text'  => $field['label'],
					);
				}
			}
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Remote-data: fields that can actually fire acf/delete_value on a post.
	 *
	 * Only sub-fields of repeater / flexible-content / group fields are listed,
	 * because those are the fields ACF deletes through normal admin use — removing
	 * a repeater/flex row (or group teardown) calls acf_delete_value() per
	 * sub-field. Plain top-level fields emit acf/update_value('') when emptied,
	 * never delete, so they would be dead options. Values are field KEYS (stable
	 * across rows), matched against $field['key'] in the trigger's validate().
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_deletable_fields( $request ): array {

		$post_id = (string) $request->get_field_value( 'ACF_WP_POSTS_OBJECT_LIST' );

		$args = is_numeric( $post_id ) ? array( 'post_id' => $post_id ) : array( 'post_type' => $post_id );

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any field', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			),
		);

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $this->remote_data_success( $options );
		}

		foreach ( acf_get_field_groups( $args ) as $field_group ) {
			$group_fields = acf_get_fields( $field_group['key'] );
			if ( empty( $group_fields ) || ! is_array( $group_fields ) ) {
				continue;
			}
			$this->collect_deletable_fields( $group_fields, '', $options );
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Recursively collect deletable sub-fields (repeater / flexible-content / group).
	 *
	 * @param array  $fields       Field definitions to scan.
	 * @param string $parent_label Accumulated parent label for context.
	 * @param array  $options      Options list, appended by reference.
	 *
	 * @return void
	 */
	private function collect_deletable_fields( array $fields, $parent_label, array &$options ) {

		foreach ( $fields as $field ) {

			if ( ! isset( $field['type'] ) ) {
				continue;
			}

			$sub_fields = array();

			if ( in_array( $field['type'], array( 'repeater', 'group' ), true ) && ! empty( $field['sub_fields'] ) ) {
				$sub_fields = $field['sub_fields'];
			} elseif ( 'flexible_content' === $field['type'] && ! empty( $field['layouts'] ) ) {
				foreach ( (array) $field['layouts'] as $layout ) {
					if ( ! empty( $layout['sub_fields'] ) ) {
						$sub_fields = array_merge( $sub_fields, $layout['sub_fields'] );
					}
				}
			}

			if ( empty( $sub_fields ) ) {
				continue;
			}

			$field_label = isset( $field['label'] ) && '' !== $field['label'] ? $field['label'] : ( $field['name'] ?? '' );
			$prefix      = '' === $parent_label ? $field_label : $parent_label . ' → ' . $field_label;

			foreach ( $sub_fields as $sub ) {
				if ( ! isset( $sub['key'], $sub['label'] ) ) {
					continue;
				}
				$options[] = array(
					'value' => $sub['key'],
					'text'  => $prefix . ' → ' . $sub['label'],
				);
				// Recurse into nested repeater/flex/group sub-fields.
				$this->collect_deletable_fields( array( $sub ), $prefix, $options );
			}
		}
	}

	/**
	 * Remote-data: ACF options pages (trigger variant — includes "Any").
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_options_pages( $request ): array {
		unset( $request );
		return $this->fetch_options_pages( true );
	}

	/**
	 * Remote-data: ACF options pages, strict (no "Any" sentinel).
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_options_pages_strict( $request ): array {
		unset( $request );
		return $this->fetch_options_pages( false );
	}

	/**
	 * Build the options-page list.
	 *
	 * @param bool $include_any Whether to prepend the "Any" sentinel.
	 *
	 * @return array
	 */
	private function fetch_options_pages( $include_any ): array {

		$options = array();

		if ( $include_any ) {
			$options[] = array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any options page', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			);
		}

		if ( ! function_exists( 'acf_get_options_pages' ) ) {
			return $this->remote_data_success( $options );
		}

		$pages = acf_get_options_pages();

		if ( empty( $pages ) || ! is_array( $pages ) ) {
			return $this->remote_data_success( $options );
		}

		foreach ( $pages as $page ) {
			if ( ! isset( $page['menu_slug'], $page['page_title'] ) ) {
				continue;
			}
			$options[] = array(
				'value' => $page['menu_slug'],
				'text'  => $page['page_title'],
			);
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Remote-data: fields on a given ACF options page (strict — for actions).
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_options_page_fields_strict( $request ): array {

		$menu_slug = (string) $request->get_field_value( 'ACF_OPTIONS_PAGE' );

		if ( '' === $menu_slug || '-1' === $menu_slug ) {
			return $this->remote_data_success( array() );
		}

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $this->remote_data_success( array() );
		}

		$field_groups = acf_get_field_groups( array( 'options_page' => $menu_slug ) );

		$options = array();

		foreach ( $field_groups as $group ) {
			$group_fields = acf_get_fields( $group['key'] );
			if ( empty( $group_fields ) ) {
				continue;
			}
			foreach ( $group_fields as $field ) {
				if ( ! isset( $field['name'], $field['label'] ) ) {
					continue;
				}
				$options[] = array(
					'value' => $field['name'],
					'text'  => $field['label'],
				);
			}
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Remote-data: registered ACF forms (trigger variant — includes "Any").
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_acf_forms( $request ): array {
		unset( $request );

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any form', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
			),
		);

		if ( ! function_exists( 'acf_get_forms' ) ) {
			return $this->remote_data_success( $options );
		}

		$forms = acf_get_forms();

		if ( empty( $forms ) || ! is_array( $forms ) ) {
			return $this->remote_data_success( $options );
		}

		foreach ( $forms as $form ) {
			if ( ! isset( $form['id'] ) ) {
				continue;
			}
			$label     = isset( $form['name'] ) && '' !== $form['name'] ? $form['name'] : $form['id'];
			$options[] = array(
				'value' => $form['id'],
				'text'  => $label,
			);
		}

		return $this->remote_data_success( $options );
	}

	/**
	 * Token definitions for the new triggers + actions.
	 *
	 * @return array
	 */
	public function trigger_post_id_tokens() {
		return array(
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_ID',
				'tokenName' => esc_html_x( 'Post ID', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_TITLE',
				'tokenName' => esc_html_x( 'Post title', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_TYPE',
				'tokenName' => esc_html_x( 'Post type', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
			array(
				'tokenId'   => 'ACF_TRIGGER_POST_URL',
				'tokenName' => esc_html_x( 'Post URL', 'Advanced Custom Fields', 'uncanny-automator-pro' ),
				'tokenType' => 'text',
			),
		);
	}

	/**
	 * Hydrate the common post-id token set.
	 *
	 * @param int $post_id The post ID.
	 *
	 * @return array
	 */
	public function hydrate_trigger_post_id_tokens( $post_id ) {
		$post_id = absint( $post_id );
		return array(
			'ACF_TRIGGER_POST_ID'    => $post_id,
			'ACF_TRIGGER_POST_TITLE' => $post_id ? get_the_title( $post_id ) : '',
			'ACF_TRIGGER_POST_TYPE'  => $post_id ? (string) get_post_type( $post_id ) : '',
			'ACF_TRIGGER_POST_URL'   => $post_id ? (string) get_permalink( $post_id ) : '',
		);
	}
}
