<?php

namespace Uncanny_Automator_Pro\Integrations\Code_Snippets;

use Uncanny_Automator\Integrations\Code_Snippets\Code_Snippets_Helpers;
use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;

/**
 * Pro helpers for Code Snippets. Composes Free's helper and serves the scope
 * dropdown through remote_data, so no wp_ajax hook has to survive demand-driven
 * loading.
 *
 * @property Code_Snippets_Helpers $base
 */
class Code_Snippets_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * Compose Free's helper.
	 */
	public function __construct() {
		$this->base = new Code_Snippets_Helpers();
	}

	// Delegation to Free. This block is Pro's contract with Free.

	/**
	 * Delegates to Free's Code_Snippets_Helpers::get_code_types().
	 *
	 * @return array
	 */
	public function get_code_types() {
		return $this->base->get_code_types();
	}

	/**
	 * Delegates to Free's Code_Snippets_Helpers::get_all_code_snippet_tags().
	 *
	 * @return array
	 */
	public function get_all_code_snippet_tags() {
		return $this->base->get_all_code_snippet_tags();
	}

	/**
	 * Delegates to Free's Code_Snippets_Helpers::get_action_common_tokens().
	 *
	 * @return array
	 */
	public function get_action_common_tokens() {
		return $this->base->get_action_common_tokens();
	}

	/**
	 * Delegates to Free's Code_Snippets_Helpers::parse_action_tokens().
	 *
	 * @param object $snippet_obj The saved snippet.
	 *
	 * @return array
	 */
	public function parse_action_tokens( $snippet_obj ) {
		return $this->base->parse_action_tokens( $snippet_obj );
	}

	/**
	 * Scope options for the code type selected in CS_TYPE.
	 *
	 * @param Remote_Data_Request $request The remote-data request.
	 *
	 * @return array
	 */
	protected function remote_data_get_scopes( $request ): array {
		return $this->remote_data_success( $this->get_scope_options_by_type( $request->get_field_value( 'CS_TYPE' ) ) );
	}

	/**
	 * Scopes Code Snippets accepts for a code type, labelled the way the plugin
	 * labels them in php/Utils/i18n.php.
	 *
	 * @param string $type One of php, html, css, js.
	 *
	 * @return array<int, array{text: string, value: string}>
	 */
	protected function get_scope_options_by_type( string $type ): array {
		switch ( $type ) {
			case 'php':
				return array(
					array(
						'text'  => esc_attr_x( 'Run snippet everywhere', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'global',
					),
					array(
						'text'  => esc_attr_x( 'Only run in administration area', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'admin',
					),
					array(
						'text'  => esc_attr_x( 'Only run on site front-end', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'front-end',
					),
					array(
						'text'  => esc_attr_x( 'Only run once', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'single-use',
					),
				);
			case 'html':
				return array(
					array(
						'text'  => esc_attr_x( 'Only display when inserted into a post or page.', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'content',
					),
					array(
						'text'  => esc_attr_x( 'Display in the site head section.', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'head-content',
					),
					array(
						'text'  => esc_attr_x( 'Display at the end of the body section, in the footer.', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'footer-content',
					),
				);
			case 'css':
				return array(
					array(
						'text'  => esc_attr_x( 'Site front-end styles', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'site-css',
					),
					array(
						'text'  => esc_attr_x( 'Administration area styles', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'admin-css',
					),
				);
			case 'js':
				return array(
					array(
						'text'  => esc_attr_x( 'Load JS in the head section', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'site-head-js',
					),
					array(
						'text'  => esc_attr_x( 'Load JS at the end of the body section', 'Code Snippets', 'uncanny-automator-pro' ),
						'value' => 'site-footer-js',
					),
				);
		}

		return array();
	}
}
