<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Code_Snippets\Code_Snippets_Integration' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator\Integrations\Code_Snippets\Code_Snippets_Helpers' ) ) {
	return;
}


new Uncanny_Automator_Pro\Integrations\Code_Snippets\Code_Snippets_Integration();
