<?php

namespace Uncanny_Automator_Pro\Integrations\Easy_Digital_Downloads;

use Uncanny_Automator\App\Recipe_Runner\Exceptions\Action_Error_Exception;
use Uncanny_Automator\Recipe\Action;

/**
 * Class Edd_Set_Order_Status
 *
 * @property Edd_Pro_Helpers $item_helpers
 *
 * @package Uncanny_Automator_Pro
 */
class Edd_Set_Order_Status extends Action {

	/**
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'EDD' );
		$this->set_action_code( 'EDD_SET_ORDER_STATUS' );
		$this->set_action_meta( 'EDD_ORDER_ID' );
		$this->set_is_pro( true );
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: %1$s: Order, %2$s: Order status */
				esc_html_x( "Set {{an order's:%1\$s}} status to {{a specific status:%2\$s}}", 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				$this->get_action_meta(),
				'EDD_ORDER_STATUS:' . $this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( "Set {{an order's}} status to {{a specific status}}", 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action_Error_Exception arrived in Free 7.8.0; the action waits for it.
	 *
	 * @return bool
	 */
	public function requirements_met() {
		return class_exists( '\Uncanny_Automator\App\Recipe_Runner\Exceptions\Action_Error_Exception' );
	}

	/**
	 * @return string
	 */
	public function requirements_unmet_message(): string {
		return esc_html_x( 'Update Uncanny Automator to 7.8.0 or later to use this action.', 'Easy Digital Downloads', 'uncanny-automator-pro' );
	}

	/**
	 * @return array[]
	 */
	public function options() {
		return array(
			array(
				'option_code' => $this->get_action_meta(),
				'label'       => esc_html_x( 'Order ID', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => true,
			),
			array(
				'option_code'     => 'EDD_ORDER_STATUS',
				'label'           => esc_html_x( 'Status', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options_show_id' => false,
				'options'         => $this->item_helpers->get_order_status_options(),
				'description'     => esc_html_x( 'Completed runs the purchase like a paid checkout: licences, file access and receipts.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'ORDER_ID'        => array(
				'name' => esc_html_x( 'Order ID', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'ORDER_NUMBER'    => array(
				'name' => esc_html_x( 'Order number', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'PREVIOUS_STATUS' => array(
				'name' => esc_html_x( 'Previous status', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ORDER_STATUS'    => array(
				'name' => esc_html_x( 'Order status', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ORDER_TOTAL'     => array(
				'name' => esc_html_x( 'Order total', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'float',
			),
			'CUSTOMER_EMAIL'  => array(
				'name' => esc_html_x( 'Customer email', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'email',
			),
			'LICENSE_KEYS'    => array(
				'name' => esc_html_x( 'Licence keys', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 * @throws Action_Error_Exception When the input is invalid, the order is missing, or EDD left it in another status.
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! function_exists( 'edd_get_order' ) || ! function_exists( 'edd_update_order_status' ) ) {
			throw Action_Error_Exception::execution_failed( esc_html_x( 'Easy Digital Downloads is not active.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		$raw_id = trim( (string) ( $parsed[ $this->get_action_meta() ] ?? '' ) );

		if ( '' === $raw_id || ! ctype_digit( $raw_id ) || (int) $raw_id < 1 ) {
			throw Action_Error_Exception::validation_failed( esc_html_x( 'The order ID must be a whole number.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		$order_id = (int) $raw_id;
		$status   = $this->resolve_status( (string) ( $parsed['EDD_ORDER_STATUS'] ?? '' ) );
		$order    = edd_get_order( $order_id );

		if ( ! $order ) {
			throw Action_Error_Exception::not_found(
				sprintf(
					/* translators: %d: Order ID */
					esc_html_x( 'Order %d does not exist.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					absint( $order_id )
				)
			);
		}

		$previous_status = (string) $order->status;

		// edd_update_order_status() refuses an unchanged status; the end state is already right.
		if ( $previous_status !== $status ) {
			edd_update_order_status( $order_id, $status );

			$order = edd_get_order( $order_id );

			if ( ! $order || $status !== (string) $order->status ) {
				throw Action_Error_Exception::execution_failed(
					sprintf(
						/* translators: %1$d: Order ID, %2$s: Order status */
						esc_html_x( 'Order %1$d could not be set to %2$s.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
						absint( $order_id ),
						esc_html( $status )
					)
				);
			}
		}

		$this->hydrate_tokens(
			array(
				'ORDER_ID'        => (int) $order->id,
				'ORDER_NUMBER'    => (string) $order->get_number(),
				'PREVIOUS_STATUS' => $previous_status,
				'ORDER_STATUS'    => (string) $order->status,
				'ORDER_TOTAL'     => (float) $order->total,
				'CUSTOMER_EMAIL'  => (string) $order->email,
				'LICENSE_KEYS'    => (string) $this->item_helpers->get_licenses( $order_id ),
			)
		);

		return true;
	}

	/**
	 * A status EDD knows. "completed" and "publish" are the names EDD itself maps to "complete".
	 *
	 * @param string $status The selected status.
	 *
	 * @return string
	 * @throws Action_Error_Exception When the status is empty or not one of EDD's.
	 */
	private function resolve_status( $status ) {

		$status = sanitize_key( trim( $status ) );

		if ( in_array( $status, array( 'completed', 'publish' ), true ) ) {
			$status = 'complete';
		}

		if ( '' === $status || ! array_key_exists( $status, edd_get_payment_statuses() ) ) {
			throw Action_Error_Exception::validation_failed(
				sprintf(
					/* translators: %s: Order status */
					esc_html_x( '%s is not an order status Easy Digital Downloads recognizes.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					esc_html( $status )
				)
			);
		}

		return $status;
	}
}
