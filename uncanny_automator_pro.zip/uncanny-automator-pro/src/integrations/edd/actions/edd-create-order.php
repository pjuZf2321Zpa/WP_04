<?php

namespace Uncanny_Automator_Pro\Integrations\Easy_Digital_Downloads;

use Uncanny_Automator\App\Recipe_Runner\Exceptions\Action_Error_Exception;
use Uncanny_Automator\Recipe\Action;

/**
 * Class Edd_Create_Order
 *
 * Creates an order the way EDD's gateways do (edd_build_order), always as pending first:
 * EDD fires its completion hooks when a row first lands in a complete status, and an order
 * inserted as complete has no items yet, so nothing (licences included) is generated for it.
 * The chosen status is applied once the items exist.
 *
 * @property Edd_Pro_Helpers $item_helpers
 *
 * @package Uncanny_Automator_Pro
 */
class Edd_Create_Order extends Action {

	/**
	 * @return void
	 */
	protected function setup_action() {
		$this->set_integration( 'EDD' );
		$this->set_action_code( 'EDD_CREATE_ORDER' );
		$this->set_action_meta( 'EDD_CUSTOMER_EMAIL' );
		$this->set_is_pro( true );
		$this->set_requires_user( false );

		$this->set_sentence(
			sprintf(
				/* translators: %1$s: Customer */
				esc_html_x( 'Create an order for {{a customer:%1$s}}', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				$this->get_action_meta()
			)
		);
		$this->set_readable_sentence( esc_html_x( 'Create an order for {{a customer}}', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
	}

	/**
	 * Action_Error_Exception arrived in Free 7.8.0; the action waits for it.
	 *
	 * @return bool
	 */
	public function requirements_met() {
		return class_exists( '\Uncanny_Automator\App\Recipe_Runner\Exceptions\Action_Error_Exception' );
	}

	/**
	 * @return string
	 */
	public function requirements_unmet_message(): string {
		return esc_html_x( 'Update Uncanny Automator to 7.8.0 or later to use this action.', 'Easy Digital Downloads', 'uncanny-automator-pro' );
	}

	/**
	 * @return array[]
	 */
	public function options() {
		return array(
			array(
				'option_code'       => 'EDD_ORDER_ITEMS',
				'input_type'        => 'repeater',
				'label'             => esc_html_x( 'Order items', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'required'          => true,
				'relevant_tokens'   => array(),
				'fields'            => array(
					array(
						'option_code'     => 'EDD_ORDER_ITEM',
						'label'           => esc_html_x( 'Download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
						'input_type'      => 'select',
						'required'        => true,
						'options_show_id' => false,
						'options'         => $this->item_helpers->get_order_item_options(),
					),
					array(
						'option_code'     => 'EDD_ORDER_ITEM_QUANTITY',
						'label'           => esc_html_x( 'Quantity', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
						'input_type'      => 'int',
						'required'        => false,
						'default_value'   => 1,
						'min_number'      => 1,
						'supports_tokens' => true,
					),
					array(
						'option_code'     => 'EDD_ORDER_ITEM_PRICE',
						'label'           => esc_html_x( 'Price', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
						'input_type'      => 'float',
						'required'        => false,
						'min_number'      => 0,
						'supports_tokens' => true,
						'description'     => esc_html_x( "Leave empty to charge the download's price. Enter 0 for a free order.", 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					),
				),
				'add_row_button'    => esc_html_x( 'Add download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'remove_row_button' => esc_html_x( 'Remove download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
			array(
				'option_code' => $this->get_action_meta(),
				'label'       => esc_html_x( 'Customer email', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'  => 'email',
				'required'    => true,
				'description' => esc_html_x( 'The order is attached to the EDD customer with this email, or to a new customer. A WordPress account with this email is linked to the order.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
			array(
				'option_code' => 'EDD_CUSTOMER_FIRST_NAME',
				'label'       => esc_html_x( 'First name', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code' => 'EDD_CUSTOMER_LAST_NAME',
				'label'       => esc_html_x( 'Last name', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'  => 'text',
				'required'    => false,
			),
			array(
				'option_code'     => 'EDD_ORDER_STATUS',
				'label'           => esc_html_x( 'Order status', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => true,
				'options_show_id' => false,
				'default_value'   => 'pending',
				'options'         => $this->item_helpers->get_order_status_options(),
				'description'     => esc_html_x( 'Completed runs the purchase like a paid checkout: licences, file access and receipts.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
			array(
				'option_code'     => 'EDD_PAYMENT_GATEWAY',
				'label'           => esc_html_x( 'Payment gateway', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'      => 'select',
				'required'        => false,
				'options_show_id' => false,
				'default_value'   => 'manual',
				'options'         => $this->item_helpers->get_payment_gateway_options(),
			),
			array(
				'option_code' => 'EDD_ORDER_NOTE',
				'label'       => esc_html_x( 'Order note', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'  => 'textarea',
				'required'    => false,
			),
			array(
				'option_code' => 'EDD_SEND_RECEIPT',
				'label'       => esc_html_x( 'Send the purchase receipt', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'input_type'  => 'checkbox',
				'is_toggle'   => true,
				'required'    => false,
				'description' => esc_html_x( 'EDD emails the receipt when the order is completed.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * @return array
	 */
	public function define_tokens() {
		return array(
			'ORDER_ID'          => array(
				'name' => esc_html_x( 'Order ID', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'ORDER_NUMBER'      => array(
				'name' => esc_html_x( 'Order number', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ORDER_STATUS'      => array(
				'name' => esc_html_x( 'Order status', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ORDER_TOTAL'       => array(
				'name' => esc_html_x( 'Order total', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'float',
			),
			'ORDER_PAYMENT_KEY' => array(
				'name' => esc_html_x( 'Payment key', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
			'ORDER_ADMIN_URL'   => array(
				'name' => esc_html_x( 'Order admin URL', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'url',
			),
			'CUSTOMER_ID'       => array(
				'name' => esc_html_x( 'Customer ID', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'int',
			),
			'CUSTOMER_EMAIL'    => array(
				'name' => esc_html_x( 'Customer email', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'email',
			),
			'LICENSE_KEYS'      => array(
				'name' => esc_html_x( 'Licence keys', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'type' => 'text',
			),
		);
	}

	/**
	 * @param int   $user_id
	 * @param array $action_data
	 * @param int   $recipe_id
	 * @param array $args
	 * @param array $parsed
	 *
	 * @return bool
	 * @throws Action_Error_Exception When the input is invalid, a download is missing, or EDD did not create the order.
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {

		if ( ! function_exists( 'edd_build_order' ) || ! function_exists( 'edd_get_order' ) ) {
			throw Action_Error_Exception::execution_failed( esc_html_x( 'Easy Digital Downloads is not active.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		$email = sanitize_email( trim( (string) ( $parsed[ $this->get_action_meta() ] ?? '' ) ) );

		if ( ! is_email( $email ) ) {
			throw Action_Error_Exception::validation_failed( esc_html_x( 'A valid customer email address is required.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		$status  = $this->resolve_status( (string) ( $parsed['EDD_ORDER_STATUS'] ?? 'pending' ) );
		$gateway = $this->resolve_gateway( (string) ( $parsed['EDD_PAYMENT_GATEWAY'] ?? 'manual' ) );
		$items   = $this->resolve_items( (string) ( $parsed['EDD_ORDER_ITEMS'] ?? '' ) );

		$wp_user = get_user_by( 'email', $email );

		$order_data = array(
			'status'       => 'pending',
			'gateway'      => $gateway,
			'currency'     => edd_get_currency(),
			'user_info'    => array(
				'id'         => $wp_user instanceof \WP_User ? (int) $wp_user->ID : 0,
				'email'      => $email,
				'first_name' => sanitize_text_field( (string) ( $parsed['EDD_CUSTOMER_FIRST_NAME'] ?? '' ) ),
				'last_name'  => sanitize_text_field( (string) ( $parsed['EDD_CUSTOMER_LAST_NAME'] ?? '' ) ),
			),
			'cart_details' => $items,
		);

		$order_id = $this->build_order( $order_data );

		if ( empty( $order_id ) ) {
			throw Action_Error_Exception::execution_failed( esc_html_x( 'Easy Digital Downloads did not create the order.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		$order = edd_get_order( $order_id );

		if ( ! $order || count( (array) $order->items ) !== count( $items ) ) {
			throw Action_Error_Exception::execution_failed(
				sprintf(
					/* translators: %d: Order ID */
					esc_html_x( 'Order %d was created without all of its items.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					absint( $order_id )
				)
			);
		}

		$note = sanitize_textarea_field( (string) ( $parsed['EDD_ORDER_NOTE'] ?? '' ) );

		if ( '' !== $note && function_exists( 'edd_add_note' ) ) {
			edd_add_note(
				array(
					'object_id'   => $order_id,
					'object_type' => 'order',
					'user_id'     => 0,
					'content'     => $note,
				)
			);
		}

		if ( 'pending' !== $status ) {
			$this->transition( $order_id, $status, $this->is_truthy( $parsed['EDD_SEND_RECEIPT'] ?? '' ) );
			$order = edd_get_order( $order_id );

			if ( ! $order || $status !== (string) $order->status ) {
				throw Action_Error_Exception::execution_failed(
					sprintf(
						/* translators: %1$d: Order ID, %2$s: Order status */
						esc_html_x( 'Order %1$d was created but could not be set to %2$s.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
						absint( $order_id ),
						esc_html( $status )
					)
				);
			}
		}

		$this->hydrate_tokens(
			array(
				'ORDER_ID'          => (int) $order->id,
				'ORDER_NUMBER'      => (string) $order->get_number(),
				'ORDER_STATUS'      => (string) $order->status,
				'ORDER_TOTAL'       => (float) $order->total,
				'ORDER_PAYMENT_KEY' => (string) $order->payment_key,
				'ORDER_ADMIN_URL'   => $this->admin_url( (int) $order->id ),
				'CUSTOMER_ID'       => (int) $order->customer_id,
				'CUSTOMER_EMAIL'    => (string) $order->email,
				'LICENSE_KEYS'      => (string) $this->item_helpers->get_licenses( (int) $order->id ),
			)
		);

		return true;
	}

	/**
	 * A status EDD knows. "completed" and "publish" are the names EDD itself maps to "complete".
	 *
	 * @param string $status The selected status.
	 *
	 * @return string
	 * @throws Action_Error_Exception When the status is not one of EDD's.
	 */
	private function resolve_status( $status ) {

		$status = sanitize_key( trim( $status ) );

		if ( '' === $status ) {
			return 'pending';
		}

		if ( in_array( $status, array( 'completed', 'publish' ), true ) ) {
			$status = 'complete';
		}

		if ( ! array_key_exists( $status, edd_get_payment_statuses() ) ) {
			throw Action_Error_Exception::validation_failed(
				sprintf(
					/* translators: %s: Order status */
					esc_html_x( '%s is not an order status Easy Digital Downloads recognizes.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					esc_html( $status )
				)
			);
		}

		return $status;
	}

	/**
	 * A registered gateway; "manual" when the field is empty.
	 *
	 * @param string $gateway The selected gateway.
	 *
	 * @return string
	 * @throws Action_Error_Exception When the gateway is not registered.
	 */
	private function resolve_gateway( $gateway ) {

		$gateway = sanitize_key( trim( $gateway ) );

		if ( '' === $gateway ) {
			return 'manual';
		}

		if ( ! array_key_exists( $gateway, edd_get_payment_gateways() ) ) {
			throw Action_Error_Exception::validation_failed(
				sprintf(
					/* translators: %s: Payment gateway */
					esc_html_x( '%s is not a registered payment gateway.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					esc_html( $gateway )
				)
			);
		}

		return $gateway;
	}

	/**
	 * The repeater rows as cart details in the shape edd_build_order() reads.
	 *
	 * @param string $json The parsed repeater value.
	 *
	 * @return array[]
	 * @throws Action_Error_Exception When a row is invalid or names a missing download.
	 */
	private function resolve_items( $json ) {

		$rows  = json_decode( $json, true );
		$items = array();

		if ( ! is_array( $rows ) || empty( $rows ) ) {
			throw Action_Error_Exception::validation_failed( esc_html_x( 'At least one order item is required.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		foreach ( array_values( $rows ) as $index => $row ) {

			if ( ! is_array( $row ) ) {
				continue;
			}

			$value = $row['EDD_ORDER_ITEM'] ?? '';

			if ( 'automator_custom_value' === $value ) {
				$value = $row['EDD_ORDER_ITEM_custom'] ?? '';
			}

			$item        = $this->item_helpers->parse_order_item_value( $value );
			$download_id = $item['download_id'];
			$price_id    = $item['price_id'];

			if ( empty( $download_id ) ) {
				throw Action_Error_Exception::validation_failed( esc_html_x( 'Each order item needs a download.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
			}

			$download = edd_get_download( $download_id );

			if ( empty( $download ) || 'download' !== $download->post_type ) {
				throw Action_Error_Exception::not_found(
					sprintf(
						/* translators: %d: Download ID */
						esc_html_x( 'Download %d does not exist.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
						absint( $download_id )
					)
				);
			}

			if ( edd_has_variable_prices( $download_id ) ) {
				$prices = (array) edd_get_variable_prices( $download_id );

				if ( null === $price_id || ! array_key_exists( $price_id, $prices ) ) {
					throw Action_Error_Exception::validation_failed(
						sprintf(
							/* translators: %s: Download title */
							esc_html_x( '%s has variable prices; pick one of its price options.', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
							esc_html( $download->post_title )
						)
					);
				}
			} else {
				$price_id = null;
			}

			$quantity = $this->resolve_quantity( $row['EDD_ORDER_ITEM_QUANTITY'] ?? '' );
			$price    = $this->resolve_price( $row['EDD_ORDER_ITEM_PRICE'] ?? '', $download_id, $price_id );
			$subtotal = round( $price * $quantity, edd_currency_decimal_filter() );

			// The plain title: edd_build_order() appends the price option's name itself.
			$items[] = array(
				'id'          => $download_id,
				'name'        => $download->post_title,
				'quantity'    => $quantity,
				'item_price'  => $price,
				'subtotal'    => $subtotal,
				'discount'    => 0.00,
				'tax'         => 0.00,
				'price'       => $subtotal,
				'item_number' => array(
					'id'       => $download_id,
					'quantity' => $quantity,
					'options'  => array(
						'price_id' => $price_id,
						'quantity' => $quantity,
					),
				),
			);
		}

		if ( empty( $items ) ) {
			throw Action_Error_Exception::validation_failed( esc_html_x( 'At least one order item is required.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		return $items;
	}

	/**
	 * @param mixed $quantity The row's quantity; empty means one.
	 *
	 * @return int
	 * @throws Action_Error_Exception When the quantity is not a whole number of at least one.
	 */
	private function resolve_quantity( $quantity ) {

		$quantity = trim( (string) $quantity );

		if ( '' === $quantity ) {
			return 1;
		}

		if ( ! ctype_digit( $quantity ) || (int) $quantity < 1 ) {
			throw Action_Error_Exception::validation_failed( esc_html_x( 'The quantity must be a whole number of at least 1.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		return (int) $quantity;
	}

	/**
	 * @param mixed    $price       The row's price; empty means the download's own price.
	 * @param int      $download_id The download ID.
	 * @param int|null $price_id    The price ID.
	 *
	 * @return float
	 * @throws Action_Error_Exception When the price is not a number of at least zero.
	 */
	private function resolve_price( $price, $download_id, $price_id ) {

		$price = trim( (string) $price );

		if ( '' === $price ) {
			return $this->item_helpers->get_order_item_price( $download_id, $price_id );
		}

		if ( ! is_numeric( $price ) || (float) $price < 0 ) {
			throw Action_Error_Exception::validation_failed( esc_html_x( 'The price must be a number of at least 0.', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );
		}

		return (float) $price;
	}

	/**
	 * Run edd_build_order() without touching the current visitor's checkout.
	 *
	 * edd_build_order() resumes the order stored in the session as edd_resume_payment and, when a
	 * purchase session exists, stores the new order there. This action may run on a visitor's
	 * request (a front-end trigger), so that slot is cleared for the call and restored after it.
	 *
	 * @param array $order_data The order data.
	 *
	 * @return int|false
	 */
	private function build_order( $order_data ) {

		$session = ( function_exists( 'EDD' ) && isset( EDD()->session ) && is_object( EDD()->session ) ) ? EDD()->session : null;
		$resume  = null;

		if ( $session && method_exists( $session, 'get' ) && method_exists( $session, 'set' ) ) {
			$resume = $session->get( 'edd_resume_payment' );
			$session->set( 'edd_resume_payment', '' );
		} else {
			$session = null;
		}

		try {
			return edd_build_order( $order_data );
		} finally {
			if ( $session ) {
				$session->set( 'edd_resume_payment', $resume );
			}
		}
	}

	/**
	 * Apply the chosen status; the receipt EDD sends on completion is held back unless asked for.
	 *
	 * @param int    $order_id     The order ID.
	 * @param string $status       The status.
	 * @param bool   $send_receipt Whether EDD may send the purchase receipt.
	 *
	 * @return void
	 */
	private function transition( $order_id, $status, $send_receipt ) {

		$held = false;

		if ( ! $send_receipt && 'complete' === $status ) {
			$held = remove_action( 'edd_complete_purchase', 'edd_trigger_purchase_receipt', 999 );
		}

		try {
			edd_update_order_status( $order_id, $status );
		} finally {
			if ( $held ) {
				add_action( 'edd_complete_purchase', 'edd_trigger_purchase_receipt', 999, 3 );
			}
		}
	}

	/**
	 * @param mixed $value A checkbox value.
	 *
	 * @return bool
	 */
	private function is_truthy( $value ) {
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'on' ), true );
	}

	/**
	 * @param int $order_id The order ID.
	 *
	 * @return string
	 */
	private function admin_url( $order_id ) {

		if ( ! function_exists( 'edd_get_admin_url' ) ) {
			return '';
		}

		return (string) edd_get_admin_url(
			array(
				'page' => 'edd-payment-history',
				'view' => 'view-order-details',
				'id'   => $order_id,
			)
		);
	}
}
