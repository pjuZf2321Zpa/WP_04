<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class EDD_HAS_USER_PURCHASED_PRICE_OPTION
 *
 * Loop filter: The user {{has/has not}} purchased {{a price option}} of {{a download}}.
 *
 * @package Uncanny_Automator_Pro
 */
class EDD_HAS_USER_PURCHASED_PRICE_OPTION extends Loop_Filter {

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function setup() {

		$this->register_hooks();

		$this->set_integration( 'EDD' );
		$this->set_meta( 'EDD_HAS_USER_PURCHASED_PRICE_OPTION' );

		$this->set_sentence( esc_html_x( 'The user {{has/has not}} purchased {{a price option}} of {{a download}}', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );

		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Price option, %3$s: Download */
				esc_html_x( 'The user {{has/has not:%1$s}} purchased {{a price option:%2$s}} of {{a download:%3$s}}', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'CRITERIA',
				'EDDPRICEOPTION',
				'EDDPRODUCT'
			)
		);

		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_users_purchased_price_option' ) );
		$this->set_loop_type( 'users' );
	}

	/**
	 * Check if EDD is active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return function_exists( 'EDD' );
	}

	/**
	 * Wire the AJAX endpoint that loads price options for the selected download.
	 *
	 * Guarded against double-registration because this filter is instantiated both
	 * by the auto-loader and by the integration's load() method.
	 *
	 * @return void
	 */
	protected function register_hooks() {
		if ( false !== has_action( 'wp_ajax_automator_pro_edd_loop_filter_price_options' ) ) {
			return;
		}
		add_action( 'wp_ajax_automator_pro_edd_loop_filter_price_options', array( $this, 'price_options_ajax_handler' ) );
	}

	/**
	 * AJAX handler: returns the price options for the selected EDD download,
	 * preceded by an "Any price option" entry.
	 *
	 * @return void
	 */
	public function price_options_ajax_handler() {

		Automator()->utilities->ajax_auth_check();

		$values      = filter_input( INPUT_POST, 'values', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$download_id = isset( $values['EDDPRODUCT']['value'] ) ? $values['EDDPRODUCT']['value'] : 0;

		wp_send_json(
			array(
				'success' => true,
				'options' => $this->get_price_options( $download_id ),
			)
		);
	}

	/**
	 * Build the price option dropdown list for a download.
	 *
	 * @param int|string $download_id
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_price_options( $download_id ) {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any price option', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
		);

		$download_id = absint( $download_id );

		if ( $download_id <= 0 || ! function_exists( 'edd_has_variable_prices' ) ) {
			return $options;
		}

		if ( ! edd_has_variable_prices( $download_id ) ) {
			return $options;
		}

		$variable_prices = edd_get_variable_prices( $download_id );

		if ( empty( $variable_prices ) ) {
			return $options;
		}

		foreach ( $variable_prices as $price_id => $price ) {
			$name = isset( $price['name'] ) ? esc_html( $price['name'] ) : sprintf(
				/* translators: %d is the price option ID */
				esc_html_x( 'Price option %d', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				$price_id
			);
			$options[] = array(
				'value' => (string) $price_id,
				'text'  => $name,
			);
		}

		return $options;
	}

	/**
	 * @return mixed[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					'options'               => array(
						array(
							'text'  => esc_html_x( 'has', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
							'value' => 'has',
						),
						array(
							'text'  => esc_html_x( 'has not', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
							'value' => 'has-not',
						),
					),
				),
				array(
					'option_code'           => 'EDDPRODUCT',
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					'options'               => $this->get_download_options(),
					'supports_custom_value' => false,
				),
				array(
					'option_code'           => 'EDDPRICEOPTION',
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Price option', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					'options'               => array(),
					'supports_custom_value' => false,
					'ajax'                  => array(
						'event'         => 'parent_fields_change',
						'endpoint'      => 'automator_pro_edd_loop_filter_price_options',
						'listen_fields' => array( 'EDDPRODUCT' ),
					),
				),
			),
		);
	}

	/**
	 * Build the list of EDD downloads.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_download_options() {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
		);

		$downloads = get_posts(
			array(
				'post_type'      => 'download',
				'posts_per_page' => 9999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
			)
		);

		foreach ( $downloads as $download ) {
			$options[] = array(
				'value' => (string) $download->ID,
				'text'  => $download->post_title,
			);
		}

		return $options;
	}

	/**
	 * @param array{EDDPRODUCT:string,EDDPRICEOPTION:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_users_purchased_price_option( $fields ) {

		$criteria        = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$download_id     = isset( $fields['EDDPRODUCT'] ) ? $fields['EDDPRODUCT'] : '';
		$price_option_id = isset( $fields['EDDPRICEOPTION'] ) ? $fields['EDDPRICEOPTION'] : '';

		if ( empty( $criteria ) || '' === $download_id || '' === $price_option_id ) {
			return array();
		}

		$buyer_ids = $this->get_buyer_ids( $download_id, $price_option_id );

		if ( 'has-not' === $criteria ) {
			return $this->get_users_without_purchase( $buyer_ids );
		}

		return $buyer_ids;
	}

	/**
	 * Resolve the user IDs that purchased the given download / price option.
	 *
	 * @param int|string $download_id Download ID or -1 for any.
	 * @param int|string $price_option_id Price option ID or -1 for any.
	 *
	 * @return int[]
	 */
	private function get_buyer_ids( $download_id, $price_option_id ) {

		global $wpdb;

		$any_download = -1 === intval( $download_id );
		$any_price    = -1 === intval( $price_option_id );

		$status_values       = array_values( edd_get_complete_order_statuses() );
		$status_placeholders = implode( ', ', array_fill( 0, count( $status_values ), '%s' ) );

		$where  = array( 'o.status IN ( ' . $status_placeholders . ' )' );
		$values = $status_values;

		if ( ! $any_download ) {
			$where[]  = 'oi.product_id = %d';
			$values[] = absint( $download_id );
		}

		if ( ! $any_price ) {
			$where[]  = 'oi.price_id = %d';
			$values[] = absint( $price_option_id );
		}

		$sql = "SELECT DISTINCT o.user_id
				FROM {$wpdb->edd_orders} o
				INNER JOIN {$wpdb->edd_order_items} oi ON oi.order_id = o.id
				WHERE " . implode( ' AND ', $where );

		$user_ids = $wpdb->get_col( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$user_ids = array_filter( array_map( 'absint', (array) $user_ids ) );

		return array_values( array_unique( $user_ids ) );
	}

	/**
	 * @param int[] $buyer_ids
	 *
	 * @return int[]
	 */
	private function get_users_without_purchase( $buyer_ids ) {

		$all_users = new \WP_User_Query(
			array(
				'cache_results' => false,
				'fields'        => 'ID',
			)
		);

		$all_user_ids = $all_users->get_results();

		if ( empty( $buyer_ids ) ) {
			return $all_user_ids;
		}

		return array_values( array_diff( $all_user_ids, $buyer_ids ) );
	}
}
