<?php

namespace Uncanny_Automator_Pro\Loop_Filters;

use Uncanny_Automator_Pro\Loops\Filter\Base\Loop_Filter;

/**
 * Class EDD_HAS_USER_PURCHASED_DOWNLOAD
 *
 * Loop filter: The user {{has/has not}} purchased {{a download}}.
 *
 * @package Uncanny_Automator_Pro
 */
class EDD_HAS_USER_PURCHASED_DOWNLOAD extends Loop_Filter {

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function setup() {

		$this->set_integration( 'EDD' );
		$this->set_meta( 'EDD_HAS_USER_PURCHASED_DOWNLOAD' );

		$this->set_sentence( esc_html_x( 'The user {{has/has not}} purchased {{a download}}', 'Easy Digital Downloads', 'uncanny-automator-pro' ) );

		$this->set_sentence_readable(
			sprintf(
				/* translators: %1$s: Criteria, %2$s: Download */
				esc_html_x( 'The user {{has/has not:%1$s}} purchased {{a download:%2$s}}', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
				'CRITERIA',
				$this->get_meta()
			)
		);

		$this->set_fields( array( $this, 'load_options' ) );
		$this->set_entities( array( $this, 'retrieve_users_purchased_download' ) );
		$this->set_loop_type( 'users' );
	}

	/**
	 * Check if EDD is active.
	 *
	 * @return bool
	 */
	protected function is_dependency_active() {
		return function_exists( 'EDD' );
	}

	/**
	 * @return mixed[]
	 */
	public function load_options() {

		return array(
			$this->get_meta() => array(
				array(
					'option_code'           => 'CRITERIA',
					'type'                  => 'select',
					'supports_custom_value' => false,
					'label'                 => esc_html_x( 'Criteria', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					'options'               => array(
						array(
							'text'  => esc_html_x( 'has', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
							'value' => 'has',
						),
						array(
							'text'  => esc_html_x( 'has not', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
							'value' => 'has-not',
						),
					),
				),
				array(
					'option_code'           => $this->get_meta(),
					'type'                  => 'select',
					'label'                 => esc_html_x( 'Download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
					'options'               => $this->get_download_options(),
					'supports_custom_value' => false,
				),
			),
		);
	}

	/**
	 * Build the list of EDD downloads.
	 *
	 * @return array{array{text:string,value:string}}
	 */
	private function get_download_options() {

		$options = array(
			array(
				'value' => '-1',
				'text'  => esc_html_x( 'Any download', 'Easy Digital Downloads', 'uncanny-automator-pro' ),
			),
		);

		$downloads = get_posts(
			array(
				'post_type'      => 'download',
				'posts_per_page' => 9999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
			)
		);

		foreach ( $downloads as $download ) {
			$options[] = array(
				'value' => (string) $download->ID,
				'text'  => $download->post_title,
			);
		}

		return $options;
	}

	/**
	 * @param array{EDD_HAS_USER_PURCHASED_DOWNLOAD:string,CRITERIA:string} $fields
	 *
	 * @return int[]
	 */
	public function retrieve_users_purchased_download( $fields ) {

		$criteria    = isset( $fields['CRITERIA'] ) ? $fields['CRITERIA'] : '';
		$download_id = isset( $fields[ $this->get_meta() ] ) ? $fields[ $this->get_meta() ] : '';

		if ( empty( $criteria ) || '' === $download_id ) {
			return array();
		}

		$buyer_ids = $this->get_buyer_ids( $download_id );

		if ( 'has-not' === $criteria ) {
			return $this->get_users_without_purchase( $buyer_ids );
		}

		return $buyer_ids;
	}

	/**
	 * Resolve the user IDs that purchased the given download.
	 *
	 * @param int|string $download_id Download ID or -1 for any download.
	 *
	 * @return int[]
	 */
	private function get_buyer_ids( $download_id ) {

		global $wpdb;

		$any_download = -1 === intval( $download_id );

		$status_values       = array_values( edd_get_complete_order_statuses() );
		$status_placeholders = implode( ', ', array_fill( 0, count( $status_values ), '%s' ) );

		$where  = array( 'o.status IN ( ' . $status_placeholders . ' )' );
		$values = $status_values;

		if ( ! $any_download ) {
			$where[]  = 'oi.product_id = %d';
			$values[] = absint( $download_id );
		}

		$sql = "SELECT DISTINCT o.user_id
				FROM {$wpdb->edd_orders} o
				INNER JOIN {$wpdb->edd_order_items} oi ON oi.order_id = o.id
				WHERE " . implode( ' AND ', $where );

		$user_ids = $wpdb->get_col( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$user_ids = array_filter( array_map( 'absint', (array) $user_ids ) );

		return array_values( array_unique( $user_ids ) );
	}

	/**
	 * @param int[] $buyer_ids
	 *
	 * @return int[]
	 */
	private function get_users_without_purchase( $buyer_ids ) {

		$all_users = new \WP_User_Query(
			array(
				'cache_results' => false,
				'fields'        => 'ID',
			)
		);

		$all_user_ids = $all_users->get_results();

		if ( empty( $buyer_ids ) ) {
			return $all_user_ids;
		}

		return array_values( array_diff( $all_user_ids, $buyer_ids ) );
	}
}
