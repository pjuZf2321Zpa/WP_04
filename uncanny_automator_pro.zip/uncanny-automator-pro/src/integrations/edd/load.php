<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Easy_Digital_Downloads\Edd_Integration' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator\Integrations\Easy_Digital_Downloads\Edd_Helpers' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\Easy_Digital_Downloads\Edd_Integration();
