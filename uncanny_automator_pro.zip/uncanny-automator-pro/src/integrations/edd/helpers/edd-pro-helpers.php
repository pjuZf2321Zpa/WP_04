<?php

namespace Uncanny_Automator_Pro\Integrations\Easy_Digital_Downloads;

use Uncanny_Automator\Integrations\Easy_Digital_Downloads\Edd_Helpers;
use Uncanny_Automator_Pro\Recipe\Abstract_Pro_Helpers;

/**
 * Class Edd_Pro_Helpers
 *
 * Composes Free's helper: one wrapper per public Free method, Pro-only
 * methods live here and only here.
 *
 * @property Edd_Helpers $base
 *
 * @package Uncanny_Automator_Pro
 */
class Edd_Pro_Helpers extends Abstract_Pro_Helpers {

	/**
	 * Edd_Pro_Helpers constructor.
	 */
	public function __construct() {
		$this->base = new Edd_Helpers();
	}

	// ----- One wrapper per public Free method, Free's exact signature, no logic. -----

	/**
	 * Carry EDD's hook-argument objects through the trigger loopback.
	 *
	 * @param array $adapters Adapters keyed by class name.
	 *
	 * @return array
	 */
	public static function register_codec_adapters( $adapters ) {
		return Edd_Helpers::register_codec_adapters( $adapters );
	}

	/**
	 * Get user address data from EDD with standardized format.
	 *
	 * @param int $user_id The user ID.
	 *
	 * @return array
	 */
	public function get_user_address_data( $user_id ) {
		return $this->base->get_user_address_data( $user_id );
	}

	/**
	 * All EDD downloads.
	 *
	 * @param string $label
	 * @param string $option_code
	 * @param bool   $any_option
	 * @param bool   $is_relevant_tokens
	 * @param bool   $is_recurring
	 *
	 * @return array
	 */
	public function all_edd_downloads( $label = null, $option_code = 'EDDPRODUCTS', $any_option = true, $is_relevant_tokens = true, $is_recurring = false ) {
		return $this->base->all_edd_downloads( $label, $option_code, $any_option, $is_relevant_tokens, $is_recurring );
	}

	/**
	 * Get price options for a specific download.
	 *
	 * @param int|string $download_id The download ID or -1 for any download.
	 * @param bool       $include_any Whether to include "Any price option".
	 *
	 * @return array
	 */
	public function get_download_price_options( $download_id, $include_any = true ) {
		return $this->base->get_download_price_options( $download_id, $include_any );
	}

	/**
	 * AJAX handler for price options.
	 *
	 * @return void
	 */
	public function get_download_price_options_ajax_handler() {
		$this->base->get_download_price_options_ajax_handler();
	}

	/**
	 * Get the licenses of the order.
	 *
	 * @param int $order_id The payment ID.
	 *
	 * @return string
	 */
	public function get_licenses( $order_id = 0 ) {
		return $this->base->get_licenses( $order_id );
	}

	// ----- Pro-only methods. -----

	/**
	 * All EDD discount codes.
	 *
	 * @param string $label
	 * @param string $option_code
	 * @param bool   $any_option
	 *
	 * @return mixed
	 */
	public function all_edd_discount_codes( $label = null, $option_code = 'EDDDISCOUNTCODES', $any_option = true ) {
		if ( ! $label ) {
			$label = esc_attr_x( 'Discount code', 'Edd', 'uncanny-automator' );
		}

		$all_discount_codes = array();

		if ( true === $any_option ) {
			$all_discount_codes[] = array(
				'text'  => esc_attr_x( 'Any discount code', 'Edd', 'uncanny-automator' ),
				'value' => '-1',
			);
		}

		$discounts = edd_get_discounts();

		if ( isset( $discounts ) && ! empty( $discounts ) ) {
			foreach ( $discounts as $discount ) {
				$title = $discount->post_title;
				// set up a descriptive title for posts with no title.
				if ( empty( $title ) ) {
					/* translators: ID of recipe, trigger or action  */
					$title = sprintf( esc_attr_x( 'ID: %1$s (no title)', 'Edd', 'uncanny-automator' ), $discount->ID );
				}
				// add post as an option.
				$all_discount_codes[] = array(
					'text'  => $title,
					'value' => $discount->ID,
				);
			}
		}

		$option = array(
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			// to setup example, lets define the value the child will be based on
			'current_value'   => false,
			'validation_type' => 'text',
			'options'         => $all_discount_codes,
			'relevant_tokens' => array(),
		);

		return apply_filters( 'uap_option_all_edd_discount_codes', $option );
	}

	/**
	 * less_greater_options
	 *
	 * @return array
	 */
	public function less_greater_options() {

		$amount_conditions = Automator()->helpers->recipe->field->less_or_greater_than();
		$options           = array();
		foreach ( $amount_conditions['options'] as $value => $text ) {
			$options[] = array(
				'text'  => $text,
				'value' => $value,
			);
		}

		return $options;
	}

	/**
	 * All EDD downloads options (not required, no tokens).
	 *
	 * @param string $label
	 * @param string $option_code
	 * @param bool   $any_option
	 * @param bool   $is_recurring
	 *
	 * @return mixed
	 */
	public function all_edd_downloads_not_required( $label = null, $option_code = 'EDDPRODUCTS', $any_option = true, $is_recurring = false ) {

		if ( ! $label ) {
			$label = esc_html_x( 'Download', 'Easy Digital Downloads', 'uncanny-automator' );
		}

		$args = array(
			'post_type'      => 'download',
			'posts_per_page' => 9999, //phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
			'orderby'        => 'title',
			'order'          => 'ASC',
			'post_status'    => 'publish',
		);

		$downloads = get_posts( $args );

		$all_downloads = array();

		if ( $any_option ) {
			$all_downloads[] = array(
				'text'  => esc_html_x( 'Any download', 'Easy Digital Downloads', 'uncanny-automator' ),
				'value' => '-1',
			);
		}

		if ( $downloads ) {
			foreach ( $downloads as $download ) {
				$download_id = $download->ID;

				// Just list everything
				if ( ! $is_recurring ) {
					$all_downloads[] = array(
						'text'  => $download->post_title,
						'value' => $download_id,
					);
					continue;
				}

				// Check if the product has a recurring option
				if ( edd_recurring()->is_recurring( $download_id ) ) {
					$all_downloads[] = array(
						'text'  => $download->post_title,
						'value' => $download_id,
					);
					continue;
				}

				if ( ! edd_has_variable_prices( $download_id ) ) {
					continue;
				}

				$variable_prices = edd_get_variable_prices( $download_id );

				if ( $variable_prices ) {
					foreach ( $variable_prices as $price ) {
						if ( ! isset( $price['recurring'] ) || 'yes' !== $price['recurring'] ) {
							continue;
						}
						$all_downloads[] = array(
							'text'  => $download->post_title,
							'value' => $download_id,
						);
					}
				}
			}
		}

		$option = array(
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => false,
			'options'         => $all_downloads,
			'relevant_tokens' => array(), // empty
		);

		return apply_filters( 'uap_option_all_edd_downloads_simple', $option );
	}

	/**
	 * Order status options, from EDD's own list.
	 *
	 * @return array[]
	 */
	public function get_order_status_options() {

		$options = array();

		foreach ( edd_get_payment_statuses() as $status => $label ) {
			$options[] = array(
				'text'  => $label,
				'value' => (string) $status,
			);
		}

		return $options;
	}

	/**
	 * Payment gateway options, every registered gateway whether or not it is enabled at checkout.
	 *
	 * @return array[]
	 */
	public function get_payment_gateway_options() {

		$options = array();

		foreach ( edd_get_payment_gateways() as $gateway_id => $gateway ) {
			$label = '';
			if ( is_array( $gateway ) ) {
				$label = $gateway['admin_label'] ?? ( $gateway['checkout_label'] ?? '' );
			}

			$options[] = array(
				'text'  => '' !== $label ? $label : (string) $gateway_id,
				'value' => (string) $gateway_id,
			);
		}

		return $options;
	}

	/**
	 * Order item options: one per single-price download, one per price option of a variable-priced download.
	 *
	 * The value is the download ID, or "{download ID}:{price ID}" for a price option; parse_order_item_value() reads it back.
	 *
	 * @return array[]
	 */
	public function get_order_item_options() {

		$downloads = get_posts(
			array(
				'post_type'      => 'download',
				'posts_per_page' => 9999, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
			)
		);

		$options = array();

		foreach ( $downloads as $download ) {

			if ( ! edd_has_variable_prices( $download->ID ) ) {
				$options[] = array(
					'text'  => $download->post_title,
					'value' => (string) $download->ID,
				);
				continue;
			}

			$prices = edd_get_variable_prices( $download->ID );

			if ( empty( $prices ) || ! is_array( $prices ) ) {
				continue;
			}

			foreach ( $prices as $price_id => $price ) {
				$options[] = array(
					'text'  => sprintf( '%1$s — %2$s', $download->post_title, edd_get_price_option_name( $download->ID, $price_id ) ),
					'value' => $download->ID . ':' . $price_id,
				);
			}
		}

		return $options;
	}

	/**
	 * Split an order item option value into its download ID and price ID.
	 *
	 * @param mixed $value The saved value: a download ID, or "{download ID}:{price ID}".
	 *
	 * @return array{download_id: int, price_id: int|null}
	 */
	public function parse_order_item_value( $value ) {

		$parts = explode( ':', trim( (string) $value ), 2 );

		$download_id = is_numeric( $parts[0] ) ? absint( $parts[0] ) : 0;
		$price_id    = isset( $parts[1] ) && is_numeric( $parts[1] ) ? absint( $parts[1] ) : null;

		return array(
			'download_id' => $download_id,
			'price_id'    => $price_id,
		);
	}

	/**
	 * The price EDD charges for a download, or for one of its price options.
	 *
	 * @param int      $download_id The download ID.
	 * @param int|null $price_id    The price ID, null for a single-price download.
	 *
	 * @return float
	 */
	public function get_order_item_price( $download_id, $price_id = null ) {

		if ( null !== $price_id && edd_has_variable_prices( $download_id ) ) {
			return (float) edd_get_price_option_amount( $download_id, $price_id );
		}

		return (float) edd_get_download_price( $download_id );
	}
}
