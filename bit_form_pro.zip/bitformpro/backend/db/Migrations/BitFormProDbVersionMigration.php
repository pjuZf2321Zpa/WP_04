<?php

use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Records Pro's schema as current. Always last in DB::migrations(): every
 * VersionGate migration before it reads the version stored before this upgrade.
 */
final class BitFormProDbVersionMigration extends Migration
{
    public function up()
    {
        global $bitformspro_db_version;
        update_option(
            'bitformspro_db_version',
            $bitformspro_db_version,
        );
    }

    public function down()
    {
    }
}
