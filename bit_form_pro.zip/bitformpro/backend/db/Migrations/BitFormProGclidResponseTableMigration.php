<?php

use BitApps\BitFormPro\Database\Migrations\DbDeltaTable;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * `{prefix}bitforms_gclid_response` — Google Ads GCLID responses.
 */
final class BitFormProGclidResponseTableMigration extends Migration
{
    use DbDeltaTable;

    protected function table()
    {
        return 'bitforms_gclid_response';
    }

    protected function schema($prefix, $collate)
    {
        return "CREATE TABLE IF NOT EXISTS `{$prefix}bitforms_gclid_response` (
                `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `gclid_id` LONGTEXT NOT NULL,
                `gclid_response` LONGTEXT NOT NULL,
                `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) $collate;";
    }
}
