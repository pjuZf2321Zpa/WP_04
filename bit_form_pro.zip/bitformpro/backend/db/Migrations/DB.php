<?php

/**
 * Class For Database Migration
 *
 * @category Database
 * @author   BitCode Developer <developer@bitcode.pro>
 */

namespace BitApps\BitFormPro\Database\Migrations;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\MigrationHelper;

/**
 * Database Migration
 */
final class DB
{
    /**
     * Idempotently add the pdf_template `pdf_config` column.
     *
     * Safe to run on every request (check-then-add); touches no version option.
     *
     * @return void
     */
    public static function ensurePdfConfigColumn()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'bitforms_pdf_template';
        // Bail if the table itself does not exist yet. On the non-gated init path an old
        // install (predating the pdf_template table) can reach here before the admin-gated
        // migrate() creates it; touching a missing table would log needless DB errors.
        if ($table_name !== $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)))) {
            return;
        }
        if (null === $wpdb->get_var("SHOW COLUMNS FROM `{$table_name}` LIKE 'pdf_config'")) {
            // Schema migration: table name interpolation only (no user input). $wpdb->prepare() cannot parameterize DDL.
            $wpdb->query(
                "ALTER TABLE `{$table_name}`
                        ADD COLUMN `pdf_config` LONGTEXT NULL AFTER `setting`",
            );
        }
    }

    /**
     * Create or update every Pro table, run the changes the stored
     * `bitformspro_db_version` still needs, then record the new version.
     *
     * Called on activation (bitformpro.php, which loads Pro's autoloader first) and
     * by InstallerProvider::migrateIfNeeded() on the first admin request after an
     * upgrade. Like the original, an exception is not caught here.
     *
     * @return void
     */
    public static function migrate()
    {
        MigrationHelper::migrate(self::migrations());
    }

    /**
     * The migrations, in run order, in the shape wp-kit's MigrationHelper reads.
     * Tables first, then version-gated changes, then the version bump — last,
     * because every VersionGate migration reads the pre-upgrade version.
     *
     * @return array{path: string, migrations: string[]}
     */
    public static function migrations()
    {
        return [
            'path'       => __DIR__ . DIRECTORY_SEPARATOR,
            'migrations' => [
                'BitFormProPaymentsTableMigration',
                'BitFormProGclidResponseTableMigration',
                'BitFormProAppLogTableMigration',
                'BitFormProPdfTemplateTableMigration',
                'BitFormProFrontendViewsTableMigration',
                'BitFormProPdfTemplateAddPdfConfigMigration',
                'BitFormProDbVersionMigration',
            ],
        ];
    }
}
