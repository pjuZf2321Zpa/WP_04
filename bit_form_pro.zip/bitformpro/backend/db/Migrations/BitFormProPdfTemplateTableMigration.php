<?php

use BitApps\BitFormPro\Database\Migrations\DbDeltaTable;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * `{prefix}bitforms_pdf_template` — PDF templates.
 */
final class BitFormProPdfTemplateTableMigration extends Migration
{
    use DbDeltaTable;

    protected function table()
    {
        return 'bitforms_pdf_template';
    }

    protected function schema($prefix, $collate)
    {
        return "CREATE TABLE IF NOT EXISTS `{$prefix}bitforms_pdf_template` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `title` text DEFAULT NULL,
                `setting` longtext DEFAULT NULL,
                `pdf_config` longtext DEFAULT NULL,
                `body` longtext DEFAULT NULL,
                `form_id` bigint(20) unsigned DEFAULT NULL,
                `user_id` bigint(20) unsigned DEFAULT NULL,
                `user_ip` int(11) unsigned DEFAULT NULL,
                `created_at` datetime DEFAULT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) $collate;";
    }
}
