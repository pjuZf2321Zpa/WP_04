<?php

use BitApps\BitFormPro\Database\Migrations\DbDeltaTable;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * `{prefix}bitforms_payments` — Payment records (Stripe, PayPal, Razorpay, Mollie).
 */
final class BitFormProPaymentsTableMigration extends Migration
{
    use DbDeltaTable;

    protected function table()
    {
        return 'bitforms_payments';
    }

    protected function schema($prefix, $collate)
    {
        return "CREATE TABLE IF NOT EXISTS `{$prefix}bitforms_payments` (
                `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `payment_name` VARCHAR(50) NOT NULL,
                `payment_type` VARCHAR(50) NOT NULL,
                `payment_response` LONGTEXT NOT NULL,
                `form_id` BIGINT(20) UNSIGNED NOT NULL,
                `transaction_id` VARCHAR(255)  NOT NULL,
                `user_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL,
                `user_ip` INT(11) UNSIGNED NULL DEFAULT NULL,
                `status` INT(1) UNSIGNED NOT NULL DEFAULT '1',
                `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `form_id` (`form_id`)
            ) $collate;";
    }
}
