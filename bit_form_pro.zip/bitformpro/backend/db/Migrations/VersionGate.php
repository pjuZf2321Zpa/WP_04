<?php

namespace BitApps\BitFormPro\Database\Migrations;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Mixed into a wp-kit Migration: a schema change for sites upgrading from an old enough `bitformspro_db_version`.
 *
 * The gate DB::migrate() always used: run when a version is stored and the gate
 * is at or above it. A fresh install stores none yet and skips every change. All
 * of them read the same pre-upgrade value: only BitFormProDbVersionMigration,
 * last in DB::migrations(), writes it.
 */
trait VersionGate
{
    /**
     * @return string the highest installed DB version this change applies to
     */
    abstract protected function upToVersion();

    /**
     * @return void
     */
    abstract protected function apply();

    public function up()
    {
        if (self::installedAtOrBelow($this->upToVersion())) {
            $this->apply();
        }
    }

    /** Column changes are not reverted. */
    public function down()
    {
    }

    /**
     * @param string $gate
     *
     * @return bool
     */
    public static function installedAtOrBelow($gate)
    {
        $installed = get_option('bitformspro_db_version');

        return $installed && version_compare($gate, $installed, '>=');
    }
}
