<?php

use BitApps\BitFormPro\Database\Migrations\DbDeltaTable;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * `{prefix}bitforms_frontend_views` — Frontend entry-table views.
 */
final class BitFormProFrontendViewsTableMigration extends Migration
{
    use DbDeltaTable;

    protected function table()
    {
        return 'bitforms_frontend_views';
    }

    protected function schema($prefix, $collate)
    {
        return "CREATE TABLE IF NOT EXISTS `{$prefix}bitforms_frontend_views` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `form_id` bigint(20) unsigned DEFAULT NULL,
                `table_name` text DEFAULT NULL,
                `table_config` longtext DEFAULT NULL,
                `table_styles` longtext DEFAULT NULL,
                `single_entry_view_config` longtext DEFAULT NULL,
                `access_control` longtext DEFAULT NULL,
                `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `form_id` (`form_id`)
            ) $collate;";
    }
}
