<?php

namespace BitApps\BitFormPro\Database\Migrations;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Mixed into a wp-kit Migration: creates one Pro table on a fresh install, with the original
 * CREATE TABLE SQL (not a Schema/Blueprint rewrite), so new and existing installs keep one schema.
 *
 * It never alters an existing table: dbDelta() reads `CREATE TABLE IF NOT EXISTS` as a table
 * named `IF`, so the CREATE is a no-op once the table exists. A column added here reaches fresh
 * installs only — upgrades need a VersionGate migration (and a frontend guard such as
 * DB::ensurePdfConfigColumn(), since the migration is admin-gated). tests/Compat/SchemaMigrationEquivalenceTest pins every
 * statement this sends.
 */
trait DbDeltaTable
{
    /**
     * Table name without the WordPress prefix.
     *
     * @return string
     */
    abstract protected function table();

    /**
     * @param string $prefix  WordPress table prefix
     * @param string $collate charset/collation clause
     *
     * @return string the CREATE TABLE statement
     */
    abstract protected function schema($prefix, $collate);

    public function up()
    {
        global $wpdb;
        include_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($this->schema($wpdb->prefix, self::collate()));
    }

    /**
     * Drops the table. Not wired to anything: uninstall is
     * bitformpro_single_site_uninstall() in bitformpro.php, and nothing calls
     * wp-kit's MigrationHelper::drop().
     */
    public function down()
    {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS `{$wpdb->prefix}{$this->table()}`");
    }

    /**
     * @return string
     */
    public static function collate()
    {
        global $wpdb;
        $collate = '';

        if ($wpdb->has_cap('collation')) {
            if (!empty($wpdb->charset)) {
                $collate .= "DEFAULT CHARACTER SET $wpdb->charset";
            }
            if (!empty($wpdb->collate)) {
                $collate .= " COLLATE $wpdb->collate";
            }
        }

        return $collate;
    }
}
