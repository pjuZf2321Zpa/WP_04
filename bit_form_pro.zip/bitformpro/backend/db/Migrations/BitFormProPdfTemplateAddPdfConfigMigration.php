<?php

use BitApps\BitFormPro\Database\Migrations\DB;
use BitApps\BitFormPro\Database\Migrations\VersionGate;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_pdf_template: add pdf_config.
 *
 * Applies to sites upgrading from Pro DB version 3.2 or older. The frontend read
 * path also runs DB::ensurePdfConfigColumn() on its own (Plugin::handleVersionUpdateFallback),
 * before any admin request reaches this.
 */
final class BitFormProPdfTemplateAddPdfConfigMigration extends Migration
{
    use VersionGate;

    protected function upToVersion()
    {
        return '3.2';
    }

    protected function apply()
    {
        DB::ensurePdfConfigColumn();
    }
}
