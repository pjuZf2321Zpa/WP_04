<?php

use BitApps\BitFormPro\Database\Migrations\DbDeltaTable;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * `{prefix}bitforms_app_log` — Pro app-level log.
 */
final class BitFormProAppLogTableMigration extends Migration
{
    use DbDeltaTable;

    protected function table()
    {
        return 'bitforms_app_log';
    }

    protected function schema($prefix, $collate)
    {
        return "CREATE TABLE IF NOT EXISTS `{$prefix}bitforms_app_log` (
                `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `log_type` VARCHAR(50) NOT NULL,
                `response_type` VARCHAR(50) NOT NULL,
                `response_obj` LONGTEXT NOT NULL,
                `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) $collate;";
    }
}
