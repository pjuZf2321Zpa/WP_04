<?php

/**
 * Theme gallery AJAX routes.
 *
 * These eight actions were shipped as `wp_ajax_bitform_*` — `bitform_`, without
 * the `s` every other Pro action carries — so they get a router of their own
 * with that prefix (see Providers\HookProvider::TABLES). The names are what the theme
 * gallery calls; do not "fix" the prefix.
 *
 * Each handler required manage_options, not the usual manage_bitform, and still
 * does, through `isAdmin:manage_options`. Data-changing routes are `Route::post`.
 */

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Http\Controller\ThemeController;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Route;

// Changes data: POST only (Route::post), nonce and manage_options.
Route::group(function (): void {
    Route::post('delete_custom_theme', [ThemeController::class, 'destroy']);
    Route::post('duplicate_theme', [ThemeController::class, 'duplicate']);
    Route::post('export_theme', [ThemeController::class, 'export']);
    Route::post('import_theme', [ThemeController::class, 'import']);
    Route::post('rename_theme', [ThemeController::class, 'rename']);
    Route::post('save_custom_theme', [ThemeController::class, 'store']);
    Route::post('set_default_theme', [ThemeController::class, 'setDefault']);
})->middleware('nonce', 'isAdmin:manage_options');

// Read-only listing: nonce and manage_options.
Route::match(['get', 'post'], 'get_custom_themes', [ThemeController::class, 'index'])->middleware('nonce', 'isAdmin:manage_options');
