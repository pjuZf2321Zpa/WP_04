<?php

/**
 * Bit Form Pro integration AJAX routes registered under the `bitform_` prefix
 * (not `bitforms_`), so each keeps its exact legacy action name. POST only,
 * behind the `nonce` and `isAdmin` middleware; see ajax-integrations.php.
 */

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\BitFormPro\Http\Controller\Integrations\GclidController;

Route::group(function (): void {
    // Gclid
    Route::post('google_adword_config', [GclidController::class, 'getGoogleAdwordConfig']);
})->middleware('nonce', 'isAdmin');
