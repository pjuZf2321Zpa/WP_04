<?php

/**
 * Pro admin AJAX routes.
 *
 * Every `wp_ajax_bitforms_*` action Pro's admin screens call. Providers\HookProvider
 * builds this table's router with `bitforms_` as its prefix, so
 * `Route::match([...], 'save_report', ...)` registers `wp_ajax_bitforms_save_report`
 * — the exact names the React admin has always called. Those names are a shipped
 * contract; renaming a path here breaks a screen.
 *
 * Routes follow the Bit Apps boilerplate (bit-pi): a route that changes data is
 * `Route::post`, so a GET is never registered and WordPress answers it with its
 * bare `0`; reads accept GET and POST. Guards are route middleware that return a
 * wp-kit Response on refusal, and controllers return Responses too — the admin
 * reads the `{status, data}` envelope through Free's normalizeAjaxReply.js,
 * which is why Pro requires Free API level 2 (Compat\FreeCompat).
 *
 * Routes marked "shadowed" are also registered by Free, whose handler runs first
 * and ends the request. They are carried over unchanged so a Free+Pro site
 * behaves exactly as before; see docs/obsolete-backend-code.md.
 *
 * Not routed: `bitforms_get_user_customfields`. AdminAjax registered it against a
 * method that never existed, so every call was a fatal error; it now falls
 * through to WordPress' `0`.
 */

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Http\Controller\AuthSettingsController;
use BitApps\BitFormPro\Http\Controller\DoubleOptInController;
use BitApps\BitFormPro\Http\Controller\AcfController;
use BitApps\BitFormPro\Http\Controller\MetaBoxController;
use BitApps\BitFormPro\Http\Controller\PodsController;
use BitApps\BitFormPro\Http\Controller\WpPostController;
use BitApps\BitFormPro\Http\Controller\WpUserController;
use BitApps\BitFormPro\Http\Controller\FormSettingsController;
use BitApps\BitFormPro\Http\Controller\FrontendViewController;
use BitApps\BitFormPro\Http\Controller\IntegrationController;
use BitApps\BitFormPro\Http\Controller\NoteController;
use BitApps\BitFormPro\Http\Controller\PaymentSettingsController;
use BitApps\BitFormPro\Http\Controller\PdfController;
use BitApps\BitFormPro\Http\Controller\PostTypeController;
use BitApps\BitFormPro\Http\Controller\ReportController;
use BitApps\BitFormPro\Http\Controller\SettingsController;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Route;

// Changes data: POST only (Route::post), nonce and capability.
Route::group(function (): void {
    Route::post('add_post_type', [PostTypeController::class, 'store']);
    Route::post('api_key', [SettingsController::class, 'saveApiKey']);  // shadowed: Free registers this action too and answers first
    Route::post('bulk_table_delete_form', [FrontendViewController::class, 'bulkDestroy']);
    Route::post('clone_integration', [IntegrationController::class, 'duplicate']);
    Route::post('create_new_view', [FrontendViewController::class, 'store']);
    Route::post('delete_atable', [FrontendViewController::class, 'destroy']);
    Route::post('delete_pdf_template', [PdfController::class, 'destroyTemplate']);
    Route::post('delete_post_type', [PostTypeController::class, 'destroy']);
    Route::post('delete_report', [ReportController::class, 'destroy']);
    Route::post('download_pdf_font', [PdfController::class, 'downloadFont']);
    Route::post('form_entry_delete_note', [NoteController::class, 'destroy']);
    Route::post('form_entry_get_notes', [NoteController::class, 'index']);
    Route::post('get_auth_set', [AuthSettingsController::class, 'show']);
    Route::post('get_custom_field', [AcfController::class, 'customField']);  // shadowed: Free registers this action too and answers first
    Route::post('get_double_opt_in', [DoubleOptInController::class, 'show']);
    Route::post('abandonment_entry', [FormSettingsController::class, 'abandonmentEntry']);
    Route::post('get_form_abandonment_config', [FormSettingsController::class, 'abandonmentConfig']);
    Route::post('get_form_template', [FormSettingsController::class, 'template']);
    Route::post('get_metabox_fields', [MetaBoxController::class, 'fields']);  // shadowed: Free registers this action too and answers first
    Route::post('get_pod_field', [PodsController::class, 'fields']);  // shadowed: Free registers this action too and answers first
    Route::post('get_views', [FrontendViewController::class, 'index']);
    Route::post('payment_details', [PaymentSettingsController::class, 'show']);
    Route::post('razorpay_transaction_info', [PaymentSettingsController::class, 'razorpayTransaction']);
    Route::post('save_auth_settings', [AuthSettingsController::class, 'store']);
    Route::post('save_double_opt_in', [DoubleOptInController::class, 'store']);
    Route::post('save_payment_setting', [PaymentSettingsController::class, 'saveSettings']);
    Route::post('save_pdf_setting', [PdfController::class, 'saveSettings']);
    Route::post('save_report', [ReportController::class, 'store']);
    Route::post('save_standalone_css', [FormSettingsController::class, 'saveStandaloneCss']);
    Route::post('update_post_type', [PostTypeController::class, 'update']);
    Route::post('update_view', [FrontendViewController::class, 'update']);
})->middleware('nonce', 'isAdmin', 'jsonBody');

// Reads: GET and POST — several admin screens fetch with query parameters.
Route::group(function (): void {
    Route::match(['get', 'post'], 'form_entry_create_note', [NoteController::class, 'store']);
    Route::match(['get', 'post'], 'form_entry_update_note', [NoteController::class, 'update']);
    Route::match(['get', 'post'], 'getAll_post_type', [PostTypeController::class, 'index']);
    Route::match(['get', 'post'], 'get_pdf_setting', [PdfController::class, 'settings']);
    Route::match(['get', 'post'], 'get_pod_type', [PodsController::class, 'types']);  // shadowed: Free registers this action too and answers first
    Route::match(['get', 'post'], 'get_post_type', [WpPostController::class, 'postTypes']);  // shadowed: Free registers this action too and answers first
    Route::match(['get', 'post'], 'get_term_posts', [WpPostController::class, 'termPosts']);
    Route::match(['get', 'post'], 'get_wp_posts', [WpPostController::class, 'posts']);
    Route::match(['get', 'post'], 'get_wp_roles', [WpUserController::class, 'roles']);
    Route::match(['get', 'post'], 'get_wp_taxonomy', [WpPostController::class, 'taxonomies']);
    Route::match(['get', 'post'], 'get_wp_users', [WpUserController::class, 'users']);  // shadowed: Free registers this action too and answers first
})->middleware('nonce', 'isAdmin', 'jsonBody');

// Address-field API keys: administrators only (manage_options), as before.
Route::match(['get', 'post'], 'get_address_api_keys', [SettingsController::class, 'addressApiKeys'])->middleware('nonce', 'isAdmin:manage_options');
Route::post('save_address_api_keys', [SettingsController::class, 'saveAddressApiKeys'])->middleware('nonce', 'isAdmin:manage_options');
