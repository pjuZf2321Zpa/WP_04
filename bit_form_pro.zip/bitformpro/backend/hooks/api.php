<?php

/**
 * Pro's `bitform/v1` REST routes: the data API (forms, fields, workflows,
 * entries, notes — API-key guarded), the Google/OneDrive/Zoho OAuth returns and
 * the payment gateway callbacks.
 *
 * Included on `rest_api_init` by HookProvider::loadAppApiHooks(), inside a wp-kit
 * Router for `bitform`/`v1`, as bit-connect includes its hooks/api.php.
 *
 * - The OAuth returns are wp-kit Routes (Http\Controller\OAuthController), as in
 *   Free: their success path is a redirect, and a refusal is a wp-kit error reply.
 * - The data API and the payment gateway callbacks are registered with WordPress
 *   directly: their success replies are read by API-key clients and payment
 *   gateways, and wp-kit would wrap every one of them as {status, code, data}.
 *   The data-API guard is Http\Middleware\ApiKeyMiddleware.
 */

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\BitFormPro\Http\Controller\EntryApiController;
use BitApps\BitFormPro\Http\Controller\NoteApiController;
use BitApps\BitFormPro\Http\Controller\OAuthController;
use BitApps\BitFormPro\Http\Controller\PaymentApiController;
use BitApps\BitFormPro\Http\Middleware\ApiKeyMiddleware;

$bitformproEntryApi = new EntryApiController();
$bitformproNoteApi = new NoteApiController();
$bitformproPaymentApi = new PaymentApiController();
$bitformproApiKey = new ApiKeyMiddleware();

/* form routes */
register_rest_route(
    'bitform',
    'v1/forms/',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproEntryApi, 'get_forms'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
        'schema' => [$bitformproEntryApi, 'get_item_schema'],
    ],
);
register_rest_route(
    'bitform',
    'v1/fields/(?P<form_id>[\d]+)',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproEntryApi, 'get_fields'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
/**
 * get workflow with form id
 */
register_rest_route(
    'bitform',
    'v1/workflow/(?P<form_id>[\d]+)',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproEntryApi, 'get_workflow'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
/* form routes*/

/* entry routes*/
register_rest_route(
    'bitform',
    'v1/entry/(?P<form_id>[\d]+)',
    [
        [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$bitformproEntryApi, 'entry_store'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
register_rest_route(
    'bitform',
    'v1/form/response/(?P<id>[\d]+)',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproEntryApi, 'getEntryResponse'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
register_rest_route(
    'bitform',
    'v1/entry/(?P<entry_id>[\d]+)',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproEntryApi, 'entry_view'],
            'permission_callback' => [$bitformproApiKey, 'handle'],

        ],
        [
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => [$bitformproEntryApi, 'entry_delete'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);

register_rest_route(
    'bitform',
    'v1/entry_update/(?P<entry_id>[\d]+)/',
    [
        [
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => [$bitformproEntryApi, 'entry_update'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
/* entry routes*/

/* note routes*/
register_rest_route(
    'bitform',
    'v1/notes/',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproNoteApi, 'get_notes'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
register_rest_route(
    'bitform',
    'v1/create-note/',
    [
        [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$bitformproNoteApi, 'create_note'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
register_rest_route(
    'bitform',
    'v1/note/(?P<id>[\d]+)',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproNoteApi, 'note_edit'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
            'args' => $bitformproEntryApi->get_endpoint_args_for_item_schema(WP_REST_Server::EDITABLE),
        ],
        [
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => [$bitformproNoteApi, 'note_update'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
        [
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => [$bitformproNoteApi, 'note_delete'],
            'permission_callback' => [$bitformproApiKey, 'handle'],
        ],
    ],
);
/* note routes*/

// payment
register_rest_route(
    'bitform',
    'v1/payments/(?P<payment_type>[\w]+)/',
    [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$bitformproPaymentApi, 'handleTransactionCallback'],
            'permission_callback' => '__return_true',
        ],
        [
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => [$bitformproPaymentApi, 'handleTransactionCallback'],
            'permission_callback' => '__return_true',
        ],
    ],
);

// OAuth returns, on wp-kit's Route (the Router is built by HookProvider::loadAppApiHooks()).
// Public: the provider redirects the browser here; OAuthController only redirects back to this site.
Route::get('google', [OAuthController::class, 'googleAuth']);
Route::get('oneDrive', [OAuthController::class, 'oneDriveAuth']);
Route::get('zoho', [OAuthController::class, 'authRedirect']);
