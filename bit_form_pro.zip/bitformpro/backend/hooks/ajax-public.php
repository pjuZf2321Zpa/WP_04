<?php

/**
 * Pro public AJAX routes — requests a published form makes for a visitor.
 *
 * No route middleware, on purpose. Each handler checks a nonce issued per form
 * (`bitforms_{formID}`, with the id read from the request body) or, for table
 * rows, the view's own access setting. A static middleware cannot express
 * either, so the checks stay inline, exactly as they were.
 *
 * Each route declares only the method the form runtime sends (POST), plus DELETE
 * for file_delete: FilePond's revert removes an uploaded file with
 * `xhr.open('DELETE', …)` (frontend-dev/packages/bit-advanced-file-up-field). Any
 * other method is never registered and gets WordPress' bare `0`.
 */

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Http\Controller\FileController;
use BitApps\BitFormPro\Http\Controller\FormController;
use BitApps\BitFormPro\Http\Controller\PaymentController;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Route;

// Logged-in and logged-out visitors.
Route::noAuth()->group(function (): void {
    Route::post('create_razorpay_order', [PaymentController::class, 'createRazorpayOrder']);
    Route::post('draft_resume_link', [FormController::class, 'draftResumeLink']);
    Route::match(['post', 'delete'], 'file_delete', [FileController::class, 'destroy']);
    Route::post('file_upload', [FileController::class, 'upload']);
    Route::post('get_stripe_secret_key', [PaymentController::class, 'stripeSecretKey']);
    Route::post('mollie_create_payment', [PaymentController::class, 'createMolliePayment']);
    Route::post('payment_insert', [PaymentController::class, 'insertPayment']);
    Route::post('save_partial_form_progress', [FormController::class, 'savePartialProgress']);
    Route::post('save_razorpay_details', [PaymentController::class, 'saveRazorpayDetails']);
    Route::post('send_email_otp', [FormController::class, 'sendEmailOtp']);
    Route::post('verify_email_otp', [FormController::class, 'verifyEmailOtp']);
});

// Logged-in visitors only (never registered for wp_ajax_nopriv_).
Route::post('get_table_rows', [FormController::class, 'tableRows']);
