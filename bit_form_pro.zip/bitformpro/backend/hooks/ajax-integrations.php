<?php

/**
 * Bit Form Pro integration AJAX routes — the admin screens that authorize a
 * third-party service and fetch its data.
 *
 * Built with the `bitforms_` prefix so each path keeps its exact legacy action
 * name, POST only, behind the `nonce` and `isAdmin` middleware. The handlers
 * keep their `wp_send_json_*` replies, which the admin reads through
 * frontend-dev/src/Utils/normalizeAjaxReply.js like everything else.
 *
 * Only Pro-only integrations are routed here. Pro used to carry its own copy of
 * 37 integrations Bit Form (free) also has; Free's routes answered first and
 * Free's handlers ran at submission, so those copies never ran and were removed
 * in 3.4.0 (see bitform/docs/obsolete-backend-code.md).
 */

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\BitFormPro\Http\Controller\Integrations\GclidController;

Route::group(function (): void {
    // Gclid
    Route::post('google_generate_token', [GclidController::class, 'generateTokens']);
    Route::post('save_google_refresh_token', [GclidController::class, '_saveRefreshedToken']);
    Route::post('get_gclid_info', [GclidController::class, 'getGclidInfo']);
})->middleware('nonce', 'isAdmin');
