<?php

namespace BitApps\BitFormPro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Pro bootstrap: constants, autoloading, kernel.
 *
 * Required directly by bitformpro.php, as in bit-pi (includes/loader.php is an
 * unused shim kept for anything that included it by path). By
 * the time this runs the Free-version gate in bitformpro.php has already passed,
 * so Free is known to be new enough for everything below.
 */

// Autoload vendor files.
$bitformproAutoload = \dirname(__DIR__) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
if (file_exists($bitformproAutoload)) {
    require_once $bitformproAutoload;
}

// The constants Pro has always defined; Free and site code read them. Config is
// where each value is worked out — new code should ask Config instead.
define('BITFORMPRO_PLUGIN_BASENAME', Config::get('BASENAME'));
define('BITFORMPRO_PLUGIN_DIR_PATH', Config::get('ROOT_DIR'));
define('BITFORMPRO_ROOT_URI', Config::get('ROOT_URI'));
define('BITFORMPRO_ASSET_URI', Config::get('ASSET_URI'));

// Legacy FQCN aliases. aliases.php is the contract Free depends on (it reaches
// into Pro by string, behind class_exists(), so a moved class would silently stop
// existing). relocations.php covers every other class the restructure moved, so
// site code written against the old layout does not fatal on update.
// Every class moved from BitCode\BitFormPro to BitApps\BitFormPro in 3.4.0, and
// the Strauss-prefixed dependencies from BitCode\BitFormPro\Dependencies to
// BitApps\BitFormPro\Deps: the old names keep resolving — Free reaches into Pro
// by string, and site code names Pro classes too.
Compat\AliasLoader::registerPrefix('BitApps\\BitFormPro\\Deps\\', 'BitApps\\BitFormPro\\Deps\\');
Compat\AliasLoader::registerPrefix('BitCode\\BitFormPro\\', 'BitApps\\BitFormPro\\');

foreach (['aliases.php', 'relocations.php'] as $bitformproAliasFile) {
    $bitformproAliasMap = __DIR__ . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'Compat' . DIRECTORY_SEPARATOR . $bitformproAliasFile;
    if (is_readable($bitformproAliasMap)) {
        Compat\AliasLoader::register((array) require $bitformproAliasMap);
    }
}

// Initialize the plugin.
Plugin::load(BITFORMPRO_PLUGIN_MAIN_FILE);
