<?php

namespace BitApps\BitFormPro\Http;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Providers\HookProvider;

/**
 * @deprecated 3.4.0 Pro's AJAX route tables are loaded by Providers\HookProvider,
 *             as in the Bit Apps boilerplate (bit-pi, bit-crm), which has no
 *             AjaxService. This class keeps its released name
 *             (`BitCode\BitFormPro\Core\Ajax\AjaxService`) answering — Free's
 *             shared test harness still constructs it for a released Pro
 *             (tests/Compat/ProSurfaceTest::REFERENCED_BY_FREE). Every member logs a
 *             deprecation notice and calls HookProvider. Use
 *             HookProvider::loadAppAjaxHooks() instead.
 */
class AjaxService
{
    public function __construct()
    {
        self::deprecated(__METHOD__, 'loadAppAjaxHooks()');
        HookProvider::loadAppAjaxHooks();
    }

    public function loadAdminAjax()
    {
        self::deprecated(__METHOD__, 'registerTable()');
        HookProvider::registerTable('ajax.php');
        HookProvider::registerTable('ajax-theme.php');
    }

    protected function loadPublicAjax()
    {
        self::deprecated(__METHOD__, 'registerTable()');
        HookProvider::registerTable('ajax-public.php');
    }

    public function loadIntegrationsAjax()
    {
        self::deprecated(__METHOD__, 'registerTable()');
        HookProvider::registerTable('ajax-integrations.php');
        HookProvider::registerTable('ajax-integrations-bitform.php');
    }

    /**
     * @param string $method      the deprecated member
     * @param string $replacement the HookProvider method to call instead
     */
    private static function deprecated($method, $replacement)
    {
        _deprecated_function(esc_html($method), '3.4.0', esc_html(HookProvider::class . '::' . $replacement));
    }
}
