<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetPodFieldsRequest;

/**
 * Pods sources for dynamic field options.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class PodsController
{
    /** Was AdminAjax::getPodsField(). */
    public function fields(GetPodFieldsRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $input = json_decode($inputJSON);

        $input = $request->decodedOr400();

        $podsAdminExists = is_plugin_active('pods/init.php');

        $podField = [];
        if ($podsAdminExists) {
            $pods = pods($input->pod_type);
            $i = 0;
            foreach ($pods->fields as $field) {
                $i++;
                $podField[$i]['key'] = $field['name'];
                $podField[$i]['name'] = $field['label'];
                $podField[$i]['required'] = $field['options']['required'] == 1 ? true : false;
            }
        }

        if (is_wp_error($podField)) {
            return Response::error($podField, 411);
        } else {
            return Response::success($podField);
        }
    }

    /** Was AdminAjax::getPodsType(). */
    public function types()
    {
        $users = get_users(['fields' => ['ID', 'display_name']]);
        $pods = [];
        $podsAdminExists = is_plugin_active('pods/init.php');
        if ($podsAdminExists) {
            $allPods = pods_api()->load_pods();
            foreach ($allPods as $key => $pod) {
                $pods[$key]['name'] = $pod['name'];
                $pods[$key]['label'] = $pod['label'];
            }
        }
        $data = ['users' => $users, 'post_types' => $pods];
        return Response::success($data);
    }
}
