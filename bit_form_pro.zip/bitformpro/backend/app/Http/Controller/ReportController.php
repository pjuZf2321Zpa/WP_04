<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\DeleteReportRequest;
use BitApps\BitFormPro\Http\Requests\SaveReportRequest;
use BitApps\BitForm\Model\Report;

/**
 * Saved entry reports.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class ReportController
{
    /** Was AdminAjax::saveReport(). */
    public function store(SaveReportRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);

        $requestsParams = $request->decodedOr400();

        $reportDetails = $requestsParams->report;
        $formId = $requestsParams->formId;
        $reportId = $requestsParams->reportId;
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();

        $reportData = [
            "type" => 'table',
            "category" => 'form',
            "context" => $formId,
            "details" => is_string($reportDetails) ? $reportDetails : JSON::encode($reportDetails),
            "isDefault" => 0,
            "user_id" => $user_details['id'],
            "user_ip" => $user_details['ip'],
            "user_device" => $user_details['device'],

        ];

        $existRprtId = Report::readWhere(['id' => $reportId, 'context' => $formId], ['id']);

        if (!is_wp_error($existRprtId)) {
            $reportData['updated_at'] = $user_details['time'];
            $updated = Report::updateWhere(['id' => $reportId], $reportData);

            if ($updated && !is_wp_error($updated)) {
                return Response::success([
                    'report_id' => $reportId,
                    'message' => __('Filter updated.', 'bitformpro'),
                ]);
            } else {
                return Response::error([
                    'report_id' => $reportId,
                    'message' => __('The filter could not be updated.', 'bitformpro'),
                ], 411);
            }
        } else {
            $reportData['created_at'] = $user_details['time'];
            $insertedId = Report::insertRow($reportData);

            if ($insertedId && !is_wp_error($insertedId)) {
                return Response::success([
                    'report_id' => $insertedId,
                    'message' => __('Filter saved.', 'bitformpro'),
                ]);
            } elseif ($insertedId && is_wp_error($insertedId)) {
                return Response::error([
                    'message' => $insertedId->get_error_message(),
                ], 411);
            }
        }
    }

    /** Was AdminAjax::deleteReport(). */
    public function destroy(DeleteReportRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);

        $requestsParams = $request->decodedOr400();

        $reportId = $requestsParams->report_id;
        $deletedId = Report::deleteWhere(['id' => $reportId]);
        if (!is_wp_error($deletedId)) {
            return Response::success([
                'message' => 'Report deleted successfully !',
            ]);
        } else {
            return Response::error($deletedId->get_error_message(), 411);
        }
    }
}
