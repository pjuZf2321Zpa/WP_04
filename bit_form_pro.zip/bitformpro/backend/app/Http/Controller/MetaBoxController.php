<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetMetaBoxFieldsRequest;

/**
 * Meta Box sources for dynamic field options.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class MetaBoxController
{
    /** Was AdminAjax::getMetaboxFields(). */
    public function fields(GetMetaBoxFieldsRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $input = json_decode($inputJSON);
        $input = $request->decodedOr400();

        $metaboxFields = [];
        $metaboxFile = [];

        $filterTypes = [
            'file_input',
            'group',
            'tab',
            'osm',
            'heading',
            'key_value',
            'map',
            'custom_html',
            'background',
            'fieldset_text',
            'taxonomy',
            'taxonomy_advanced',
        ];

        $fileTypes = [
            "image",
            "image_upload",
            "file_advanced",
            "file_upload",
            "single_image",
            "file",
            "image_advanced",
            "video",
        ];

        if (function_exists('rwmb_meta')) {
            $fields = rwmb_get_object_fields($input->post_type);
            foreach ($fields as $index => $field) {
                if (!in_array($field['type'], $fileTypes)) {
                    if (!in_array($field['type'], $filterTypes)) {
                        $metaboxFields[$index]['name'] = $field['name'];
                    }

                    $metaboxFields[$index]['key'] = $field['id'];
                    $metaboxFields[$index]['required'] = $field['required'];
                } else {
                    $metaboxFile[$index]['name'] = $field['name'];
                    $metaboxFile[$index]['key'] = $field['id'];
                    $metaboxFile[$index]['required'] = $field['required'];
                }
            }
        }
        return Response::success([
                'metaboxFields' => array_values($metaboxFields),
                'metaboxFile' => array_values($metaboxFile),
            ]);
    }
}
