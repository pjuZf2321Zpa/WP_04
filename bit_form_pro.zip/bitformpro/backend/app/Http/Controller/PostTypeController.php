<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\CreatePostTypeRequest;
use BitApps\BitFormPro\Http\Requests\UpdatePostTypeRequest;
use BitApps\BitFormPro\Http\Requests\DeletePostTypeRequest;

/**
 * Custom post types registered through Bit Form.
 *
 * Handlers moved from CptAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class PostTypeController
{
    /** Was CptAjax::getAllPost(). */
    public function index()
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action']);
        $cpts = $cpts = get_option('bitform_custom_post_types');
        if ($cpts != null) {
            $data = [];
            $post_types = [];
            foreach ($cpts as $key => $cpt) {
                if (!empty($cpt->name)) {
                    $post_types[$key] = $cpt->name;
                }
            }
            $data['all_cpt'] = $cpts;
            $data['types'] = $post_types;
            return Response::success($data);
        }
    }

    /** Was CptAjax::addPostType(). */
    public function store(CreatePostTypeRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action']);
        $get_cpt = get_option('bitform_custom_post_types');

        $input = $request->decodedOr400();

        $input->slug = $this->sanitizePostTypeKey($input->slug ?? '');
        $slugError   = $this->validatePostTypeKey($input->slug);
        if ($slugError !== null) {
            return Response::error($slugError, 400);
        }

        if ($get_cpt == '') {
            $option = (object) [];
            $option->name = $input->slug;
            $option->public_queryable = isset($input->public_queryable) ? 1 : 0;
            $option->show_in_rest = isset($input->show_in_rest) ? 1 : 0;
            $option->menu_name = $input->menu_name;
            $option->singular_label = $input->singular_label;
            $option->public = isset($input->public) ? 1 : 0;
            $option->rewrite = true;
            $option->show_ui = isset($input->show_ui) ? 1 : 0;
            $option->show_in_menu = isset($input->show_in_menu) ? 1 : 0;
            $option->menu_icon = $input->menu_icon;
            $result = update_option('bitform_custom_post_types', [$option]);
        } else {
            $key = count($get_cpt);
            $get_cpt[$key] = new \stdClass();
            $get_cpt[$key]->name = $input->slug;
            $get_cpt[$key]->public_queryable = isset($input->public_queryable) ? 1 : 0;
            $get_cpt[$key]->show_in_rest = isset($input->show_in_rest) ? 1 : 0;
            $get_cpt[$key]->menu_name = $input->menu_name;
            $get_cpt[$key]->singular_label = $input->singular_label;
            $get_cpt[$key]->public = isset($input->public) ? 1 : 0;
            $get_cpt[$key]->rewrite = true;
            $get_cpt[$key]->show_ui = isset($input->show_ui) ? 1 : 0;
            $get_cpt[$key]->show_in_menu = isset($input->show_in_menu) ? 1 : 0;
            $get_cpt[$key]->menu_icon = $input->menu_icon;
            $result = update_option('bitform_custom_post_types', $get_cpt);
        }
        if ($result) {
            return Response::success($result);
        }
    }

    /** Was CptAjax::updatePostType(). */
    public function update(UpdatePostTypeRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action']);
        $cpts = get_option('bitform_custom_post_types');

        $input = $request->decodedOr400();

        $input->name = $this->sanitizePostTypeKey($input->name ?? '');
        $nameError   = $this->validatePostTypeKey($input->name);
        if ($nameError !== null) {
            return Response::error($nameError, 400);
        }

        $id = $this->searchForType($input->name, $cpts);
        if ($id !== null) {

            if (!is_object($cpts[$id])) {
                $cpts[$id] = new \stdClass();
            }
            $cpts[$id]->name = $input->name;
            $cpts[$id]->public_queryable = isset($input->public_queryable) ? 1 : 0;
            $cpts[$id]->show_in_rest = isset($input->show_in_rest) ? 1 : 0;
            $cpts[$id]->menu_name = $input->menu_name;
            $cpts[$id]->singular_label = $input->singular_label;
            $cpts[$id]->public = isset($input->public) ? 1 : 0;
            $cpts[$id]->rewrite = true;
            $cpts[$id]->show_ui = isset($input->show_ui) ? 1 : 0;
            $cpts[$id]->show_in_menu = isset($input->show_in_menu) ? 1 : 0;
            $cpts[$id]->menu_icon = $input->menu_icon;
            update_option('bitform_custom_post_types', $cpts);
            return Response::success($cpts[$id]);
        }
    }

    /** Was CptAjax::deletePostType(). */
    public function destroy(DeletePostTypeRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action']);
        $queryParams = $request->decodedOr400();
        update_option('bitform_custom_post_types', $queryParams->postData);
        return Response::success($queryParams->postData);
    }

    /** Was CptAjax::sanitizePostTypeKey(). */
    private function sanitizePostTypeKey($slug)
    {
        return sanitize_key((string) $slug);
    }

    /** Was CptAjax::searchForType(). */
    private function searchForType($slug, $cpts)
    {
        foreach ($cpts as $key => $val) {
            if ($val->name === $slug) {
                return $key;
            }
        }
    }

    /** Was CptAjax::validatePostTypeKey(). */
    private function validatePostTypeKey($slug)
    {
        $length = strlen($slug);
        if ($length < 1) {
            return __('Post type slug is required.', 'bitformpro');
        }
        if ($length > 20) {
            return __('Post type slug must be 20 characters or fewer.', 'bitformpro');
        }

        return null;
    }
}
