<?php

namespace BitApps\BitFormPro\Http\Controller\Integrations;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Integration\Gclid\GclidHandler;

/**
 * Gclid's admin AJAX actions (backend/hooks/ajax-integrations.php).
 *
 * Thin by design: the nonce, capability and POST checks each handler method
 * used to repeat are route middleware now, and the handler keeps its logic
 * and its replies.
 */
final class GclidController
{
    /** bitforms_google_generate_token */
    public function generateTokens()
    {
        GclidHandler::generateTokens();
    }

    /** bitforms_save_google_refresh_token */
    public function _saveRefreshedToken()
    {
        GclidHandler::_saveRefreshedToken();
    }

    /** bitforms_get_gclid_info */
    public function getGclidInfo()
    {
        GclidHandler::getGclidInfo();
    }

    /** bitform_google_adword_config */
    public function getGoogleAdwordConfig()
    {
        GclidHandler::getGoogleAdwordConfig();
    }
}
