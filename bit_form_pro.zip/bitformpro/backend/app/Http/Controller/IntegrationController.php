<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\DuplicateIntegrationRequest;

/**
 * Pro-only integration actions.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class IntegrationController
{
    /** Was AdminAjax::cloneIntegration(). */
    public function duplicate(DuplicateIntegrationRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);

        $requestsParams = $request->decodedOr400();

        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();

        $integrationHandler = new IntegrationHandler($requestsParams->formID, $user_details);
        $existInteg = $integrationHandler->getAllIntegration(null, null, 1, $requestsParams->id);
        if (!is_wp_error($existInteg) && count($existInteg) > 0) {
            $inetegDetails = $existInteg[0];

            $integName = 'Duplicate of' . $inetegDetails->integration_name;
            $save = $integrationHandler->saveIntegration(
                $integName,
                $inetegDetails->integration_type,
                $inetegDetails->integration_details,
                'form',
                $inetegDetails->status,
            );

            if (!is_wp_error($save)) {
                // wp_send_json_success($inetegDetails, 200);
                return Response::success($save);
            }
            return Response::error($save->get_error_message(), 411);
        }
        return Response::error(__('No Integration Found', 'bitformpro'), 404);
    }
}
