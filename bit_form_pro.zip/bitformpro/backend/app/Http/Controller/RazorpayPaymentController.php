<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitForm\Helpers\Log;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

class RazorpayPaymentController extends PaymentServices
{
    protected $paymentName = 'razorpay';
    protected $paymentType = 'order';

    public function handlePayment()
    {
        $razorpayDataString = file_get_contents('php://input');
        $razorpayData = JSON::decode($razorpayDataString);

        // The webhook body is attacker-controllable, so the event string is only a
        // cheap pre-filter — never proof of payment.
        if (($razorpayData->event ?? '') !== 'payment.captured') {
            Log::debug_log('[Razorpay] Unhandled event: ' . ($razorpayData->event ?? 'unknown'));
            return;
        }

        // Trust only the payment id from the webhook (used to re-fetch), plus form
        // id + field key which merely select the merchant credentials to verify with.
        $entity = $razorpayData->payload->payment->entity ?? null;
        $paymentId = isset($entity->id) ? $this->sanitize($entity->id) : '';
        $formId = isset($entity->notes->formID) ? $this->sanitize($entity->notes->formID) : '';
        $fieldKey = isset($entity->notes->fieldKey) ? $this->sanitize($entity->notes->fieldKey) : '';

        if (empty($paymentId) || empty($formId) || empty($fieldKey)) {
            Log::debug_log('[Razorpay] Webhook missing payment id / routing notes.');
            return;
        }

        $integrationDetails = $this->resolvePaymentIntegrationDetails($formId, $fieldKey);
        $apiKey = $integrationDetails->apiKey ?? '';
        $apiSecret = $integrationDetails->apiSecret ?? '';
        if (empty($apiKey) || empty($apiSecret)) {
            Log::debug_log('[Razorpay] Could not resolve merchant credentials for the webhook.');
            return;
        }

        // Out-of-band verification: re-fetch the payment from Razorpay with the
        // merchant's own credentials. A forged/unpaid transaction cannot pass this.
        $verified = HttpHelper::get(
            "https://api.razorpay.com/v1/payments/{$paymentId}",
            null,
            ['Authorization' => 'Basic ' . base64_encode("{$apiKey}:{$apiSecret}")],
        );

        if (empty($verified->id) || ($verified->status ?? '') !== 'captured') {
            Log::debug_log("[Razorpay] Verification failed for payment {$paymentId}.");
            return;
        }

        // Routing metadata is taken from the verified provider response, not the webhook.
        $this->formId = $this->sanitize($verified->notes->formID ?? $formId);
        $this->entryId = isset($verified->notes->entryID) ? $this->sanitize($verified->notes->entryID) : '';
        $this->fieldKey = $this->sanitize($verified->notes->fieldKey ?? $fieldKey);
        $this->transactionId = $this->sanitize($verified->id);
        $this->apiResponseData = $verified;

        $this->savePaymentInfo();

        wp_send_json_success(__('Razorpay payment captured and processed.', 'bitformpro'), 200);
    }
}
