<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Services\Admin\AppSetting\Pdf;
use BitApps\BitFormPro\Services\Messages\PdfTemplateHandler;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\DeletePdfTemplateRequest;
use BitApps\BitFormPro\Http\Requests\DownloadPdfFontRequest;
use BitApps\BitFormPro\Http\Requests\SavePdfSettingsRequest;

/**
 * PDF templates and settings.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class PdfController
{
    /** Was AdminAjax::savePdfSetting(). */
    public function saveSettings(SavePdfSettingsRequest $request)
    {
        $inputData = $request->decodedOr400();

        $status = Pdf::getInstance()->savePdfSetting($inputData->pdfSetting);

        if (is_wp_error($status)) {
            return Response::error($status->get_error_message(), 411);
        } else {
            return Response::success($status);
        }
    }

    /** Was AdminAjax::getPdfSetting(). */
    public function settings()
    {
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action']);
        $pdfSetting = Pdf::getInstance()->getPdfSetting();
        return Response::success($pdfSetting);
    }

    /** Was AdminAjax::deletePdfTemplate(). */
    public function destroyTemplate(DeletePdfTemplateRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $input = json_decode($inputJSON);

        $input = $request->decodedOr400();

        $formID = $input->formID;
        $id = $input->id;
        $emailTemplateHandler = new PdfTemplateHandler($formID);
        $delete_status = $emailTemplateHandler->delete($id);
        if (is_wp_error($delete_status)) {
            return Response::error($delete_status->get_error_message(), 411);
        } else {
            return Response::success($delete_status);
        }
    }

    /** Was AdminAjax::pdfFontDownload(). */
    public function downloadFont(DownloadPdfFontRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $input = json_decode($inputJSON);

        $input = $request->decodedOr400();
        $fonts = $input->fontName;
        $status = Pdf::getInstance()->downloadPdfFont($fonts);

        if (is_wp_error($status)) {
            return Response::error($status->get_error_message(), 411);
        } else {
            return Response::success($status);
        }
    }
}
