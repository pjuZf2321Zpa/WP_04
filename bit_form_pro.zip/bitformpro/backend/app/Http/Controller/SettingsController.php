<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Http\Requests\SaveApiKeyRequest;
use BitApps\BitFormPro\Helpers\AddressApiKeysHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\SaveAddressApiKeysRequest;

/**
 * Plugin-wide Pro settings.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class SettingsController
{
    /**
     * Mints/returns the secret that authenticates the whole bitform/v1 data API
     * (see Routes::get_items_permissions_check).
     *
     * Free registers this action too and answers first on a Free+Pro site, but this
     * copy must hold the same guarantees: it runs when Free is a version behind.
     *
     * Was AdminAjax::saveApiKey().
     */
    public function saveApiKey(SaveApiKeyRequest $request)
    {
        // A malformed `data` body is still answered with the 400 it always got.
        $request->decodedOr400();
        $requested = $request->validated()['api_key'] ?? '';

        if (empty($requested)) {
            $api_key = get_option('bitform_secret_api_key');
        } else {
            update_option('bitform_secret_api_key', $requested);
            $api_key = $requested;
        }
        if (!$api_key) {
            // wp_generate_uuid4() draws from mt_rand(), not a CSPRNG — wrong source
            // for a bearer credential. Stored keys are left alone; rotating one
            // would break every live consumer.
            $api_key = wp_generate_password(64, false, false);
            update_option('bitform_secret_api_key', $api_key);
        }
        return Response::success($api_key);
    }

    /** Was AdminAjax::getAddressApiKeys(). */
    public function addressApiKeys()
    {
        return Response::success(AddressApiKeysHelper::getKeys());
    }

    /** Was AdminAjax::saveAddressApiKeys(). */
    public function saveAddressApiKeys(SaveAddressApiKeysRequest $request)
    {
        $input = $request->decodedOr400();

        $keys = AddressApiKeysHelper::saveKeys(
            isset($input->google_maps_api_key) ? sanitize_text_field($input->google_maps_api_key) : '',
            isset($input->mapbox_token) ? sanitize_text_field($input->mapbox_token) : '',
        );

        return Response::success($keys);
    }
}
