<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitForm\Helpers\Log;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

class StripePaymentController extends PaymentServices
{
    protected $paymentName = 'stripe';
    protected $paymentType = 'order';

    private const STRIPE_PAYMENT_INTENT_ENDPOINT = 'https://api.stripe.com/v1/payment_intents';

    public function handlePayment()
    {
        $stripeDataString = file_get_contents('php://input');
        $stripeData = JSON::decode($stripeDataString);

        // Trust only the PaymentIntent id from the webhook (used to re-fetch), plus
        // form id + field key which merely select the merchant credentials to verify with.
        $object = $stripeData->data->object ?? null;
        $paymentIntentId = isset($object->id) ? $this->sanitize($object->id) : '';
        $formId = isset($object->metadata->formID) ? $this->sanitize($object->metadata->formID) : '';
        $fieldKey = isset($object->metadata->fieldKey) ? $this->sanitize($object->metadata->fieldKey) : '';

        if (empty($paymentIntentId) || empty($formId) || empty($fieldKey)) {
            Log::debug_log('[Stripe] Webhook missing payment intent id / routing metadata.');
            return;
        }

        $integrationDetails = $this->resolvePaymentIntegrationDetails($formId, $fieldKey);
        $secretKey = $integrationDetails->clientSecret ?? '';
        if (empty($secretKey)) {
            Log::debug_log('[Stripe] Could not resolve merchant credentials for the webhook.');
            return;
        }

        // Out-of-band verification: re-fetch the PaymentIntent from Stripe with the
        // merchant's own secret key. A forged/unpaid transaction cannot pass this.
        $verified = HttpHelper::get(
            self::STRIPE_PAYMENT_INTENT_ENDPOINT . '/' . $paymentIntentId,
            null,
            ['Authorization' => "Bearer {$secretKey}"],
        );

        if (empty($verified->id) || ($verified->status ?? '') !== 'succeeded') {
            Log::debug_log("[Stripe] Verification failed for payment intent {$paymentIntentId}.");
            return;
        }

        // Routing metadata is taken from the verified provider response, not the webhook.
        $this->formId = $this->sanitize($verified->metadata->formID ?? $formId);
        $this->entryId = isset($verified->metadata->entryID) ? $this->sanitize($verified->metadata->entryID) : '';
        $this->fieldKey = $this->sanitize($verified->metadata->fieldKey ?? $fieldKey);
        $this->transactionId = $this->sanitize($verified->id);
        $this->apiResponseData = $verified;

        $this->savePaymentInfo();

        wp_send_json_success(__('Stripe payment succeeded and processed.', 'bitformpro'), 200);
    }
}
