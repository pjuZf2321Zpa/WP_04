<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;

/**
 * Pro's OAuth returns (`bitform/v1/google`, `oneDrive`, `zoho`), on wp-kit's Route
 * as Free's are.
 *
 * Public by necessity: the provider redirects the browser here after
 * authorization, so the paths are redirect URIs registered with Google,
 * Microsoft and Zoho. Each only ever redirects back to this site, checked
 * against the `state` parameter's origin. Moved from EntryApiController.
 */
class OAuthController
{
    public function googleAuth(Request $request)
    {
        $this->redirectWithCode($request);
    }

    public function oneDriveAuth(Request $request)
    {
        $this->redirectWithCode($request);
    }

    /**
     * Zoho's return: every provider parameter but `state` goes back to the page that started it.
     *
     * @return Response|void
     */
    public function authRedirect(Request $request)
    {
        $state = $request->get('state');
        if (!self::isSameSiteUrl($state)) {
            return Response::error([], 400)->code('invalid_redirect_url')->message('Invalid redirect URL');
        }
        $params = $request->all();
        unset($params['rest_route'], $params['state']);
        if (wp_safe_redirect($state . '&' . http_build_query($params), 302)) {
            exit;
        }
    }

    /**
     * Google and OneDrive return only `code`; a foreign `state` goes to the home page instead.
     */
    private function redirectWithCode(Request $request)
    {
        $state = esc_url_raw((string) $request->get('state', ''));
        $code = urlencode(sanitize_text_field((string) $request->get('code', '')));
        if (!self::isSameSiteUrl($state)) {
            wp_safe_redirect(home_url(), 302);
            exit;
        }
        if (wp_safe_redirect($state . '&code=' . $code, 302)) {
            exit;
        }
    }

    /**
     * True only when $url resolves to the exact same scheme://host[:port] as this
     * site — an origin-equality check rather than a bypassable substring match.
     *
     * @param mixed $url
     * @return bool
     */
    private static function isSameSiteUrl($url)
    {
        $target = self::getDomain($url);
        return '' !== $target && $target === self::getDomain(get_site_url());
    }

    /**
     * @param mixed $url
     * @return string
     */
    private static function getDomain($url)
    {
        $parsed = wp_parse_url((string) $url);
        if (empty($parsed['scheme']) || empty($parsed['host'])) {
            return '';
        }
        $domain = $parsed['scheme'] . '://' . $parsed['host'];
        $domain .= empty($parsed['port']) ? '' : ':' . $parsed['port'];
        return $domain;
    }
}
