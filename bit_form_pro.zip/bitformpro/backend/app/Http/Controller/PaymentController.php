<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitFormPro\Model\PaymentInfoModel;
use BitApps\BitFormPro\Services\Payment\RazorpayPaymentGuard;
use BitApps\BitFormPro\Services\Payment\StripePaymentIntent;
use BitApps\BitForm\Helpers\Log;
use BitApps\BitForm\Services\Form\FormManager;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitForm\Helpers\GlobalHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Http\Middleware\FormNonceCheckerMiddleware;
use BitApps\BitForm\Model\FormLogDetail;
use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitForm\Model\FormEntry;

/**
 * Payment steps a visitor's browser drives while filling a form.
 *
 * Handlers moved verbatim from FrontendAjax. Their guards stay inline:
 * the nonce is issued per form (`bitforms_{formID}`, with the id read from
 * the request), which a static route middleware cannot express.
 */
final class PaymentController
{
    /** Was FrontendAjax::getStripeSecretKey(). */
    public function stripeSecretKey()
    {
        $request = file_get_contents('php://input');
        $description = "";
        $shipping = null;

        if ($request) {
            $data = is_string($request) ? JSON::decode($request) : $request;
            $payIntegID = $data->payIntegID;
            $amount = $data->amount;
            $currency = $data->currency;
            $meta = $data->metadata;
            $paymentMethodType = $data->payment_method_types;
            $description = $data->description ?? "";
            $shipping = $data->shipping ?? null;
        }

        $verifyFormID = $meta->formID ?? 0;
        if (!FormNonceCheckerMiddleware::allows($verifyFormID)) {
            wp_send_json_error(__('Token expired', 'bitformpro'), 401);
        }

        $integrationHandler = new IntegrationHandler(0);
        $integrationDetails = $integrationHandler->getAllIntegration('app', 'payments', '', $payIntegID);
        $integrationRow = Utility::firstRow($integrationDetails);
        $integrationDetails = Utility::jsonObj($integrationRow->integration_details ?? '');
        $clientSecret = $integrationDetails->clientSecret ?? '';

        $data = [
            'amount' => $amount,
            'currency' => $currency,
            'payment_method_types' => $paymentMethodType,
            'metadata' => [
                "formID" => $meta->formID,
                "entryID" => $meta->entryID,
                "fieldKey" => $meta->fieldKey,
            ],
            'description' => $description,
        ];
        if (!is_null($shipping)) {
            $data['shipping'] = $shipping;
        }
        if (empty($paymentMethodType)) {
            unset($data['payment_method_types']);
            $data['automatic_payment_methods'] = ['enabled' => 'true'];
        }

        $result = (new StripePaymentIntent($clientSecret))->clientSecretFor($data);

        if (is_string($result) && '' !== $result) {
            wp_send_json_success((object) ['clientSecret' => $result], 200);
        }
        if (is_wp_error($result)) {
            $errorData = $result->get_error_data();
            wp_send_json_error(
                ['error' => ['code' => $result->get_error_code(), 'message' => $result->get_error_message()]],
                isset($errorData['status']) ? (int) $errorData['status'] : 400,
            );
        }
        if (is_object($result) && !empty($result->error)) {
            wp_send_json_error($result, 400);
        }
        wp_send_json_error(['error' => ['message' => __('Could not start the Stripe payment. Please try again.', 'bitformpro')]], 502);
    }

    /** Was FrontendAjax::createMolliePayment(). */
    public function createMolliePayment()
    {
        $request = file_get_contents('php://input');
        $data = $request ? (is_string($request) ? JSON::decode($request) : $request) : null;
        $verifyFormID = $data->metadata->formID ?? 0;
        if (!FormNonceCheckerMiddleware::allows($verifyFormID)) {
            wp_send_json_error(__('Token expired', 'bitformpro'), 401);
        }

        (new MolliePaymentController())->createPayment($request);
    }

    /** Was FrontendAjax::createRazorpayOrder(). */
    public function createRazorpayOrder()
    {
        $request = file_get_contents('php://input');
        if ($request) {
            $data = is_string($request) ? JSON::decode($request) : $request;
            $payIntegID = $data->payIntegID;
            $amount = $data->amount;
            $currency = $data->currency;
            $notes = $data->notes ?? (object) [];
        }

        $verifyFormID = $notes->formID ?? 0;
        if (!FormNonceCheckerMiddleware::allows($verifyFormID)) {
            wp_send_json_error(__('Token expired', 'bitformpro'), 401);
        }

        $integrationHandler = new IntegrationHandler(0);
        $integrationDetails = $integrationHandler->getAllIntegration('app', 'payments', '', $payIntegID);
        $integrationRow = Utility::firstRow($integrationDetails);
        $integrationDetails = Utility::jsonObj($integrationRow->integration_details ?? '');
        $apiEndPoint = 'https://api.razorpay.com/v1/orders';
        $keyId = $integrationDetails->apiKey ?? '';
        $keySecret = $integrationDetails->apiSecret ?? '';

        if ((new RazorpayPaymentGuard($keyId, $keySecret))->isEntryPaid($notes->formID ?? 0, $notes->entryID ?? 0, $notes->fieldKey ?? '')) {
            wp_send_json_error(RazorpayPaymentGuard::alreadyPaidResponse(), 409);
        }

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => "Basic" . base64_encode("{$keyId}:{$keySecret}"),
        ];
        $data = [
            'amount' => $amount,
            'currency' => $currency,
            'notes' => $notes,
        ];
        $apiResponse = HttpHelper::post($apiEndPoint, json_encode($data), $headers);

        if (isset($apiResponse->error) && $apiResponse->error) {
            wp_send_json_error($apiResponse, 400);
        } else {
            wp_send_json_success($apiResponse, 200);
        }
    }

    /** Was FrontendAjax::saveRazorpayDetails(). */
    public function saveRazorpayDetails()
    {
        $inputJSON = file_get_contents('php://input');
        $queryParams = JSON::decode($inputJSON);

        // GlobalHelper::requirePostMethod();

        // try {
        //     $queryParams = GlobalHelper::formatRequestData();
        // } catch (\InvalidArgumentException $e) {
        //     wp_send_json_error($e->getMessage(), 400);
        // }

        if (!is_object($queryParams) || !isset($queryParams->formID)) {
            wp_send_json_error(__('Invalid request', 'bitformpro'), 400);
        }

        if (
            FormNonceCheckerMiddleware::allows($queryParams->formID)
        ) {
            // The nonce is public (see validatePaymentContext) — re-establish that this entry,
            // form and field actually belong together before touching the transient or the DB.
            $context = $this->validatePaymentContext($queryParams);
            if (is_wp_error($context)) {
                wp_send_json_error($context->get_error_message(), 403);
            }
            if ('razorpay' !== $context['fieldType']) {
                wp_send_json_error(__('Not a Razorpay field', 'bitformpro'), 403);
            }
            // Razorpay payment ids are `pay_<alnum>`; anything else would be interpolated into the
            // API path below.
            if (1 !== preg_match('/^[A-Za-z0-9_]+$/', $context['transactionID'])) {
                wp_send_json_error(__('Invalid transaction id', 'bitformpro'), 400);
            }

            $formManager = FormManager::getInstance($context['formID']);
            $integrationHandler = new IntegrationHandler(0);
            $allFields = $formManager->getFormContent();
            $razorpayField = $allFields->fields->{$context['fieldKey']};
            $payIntegId = $razorpayField->payIntegID ?? $razorpayField->options->payIntegID;
            $integration = $integrationHandler->getAIntegration($payIntegId, 'app', 'payments');
            $integrationRow = Utility::firstRow($integration);
            $integration_details = Utility::jsonObj($integrationRow->integration_details ?? '');
            $defaultHeader = [];
            $token = base64_encode(($integration_details->apiKey ?? '') . ':' . ($integration_details->apiSecret ?? ''));
            $defaultHeader['Authorization'] = "Basic {$token}";

            // Confirm the transaction exists on Razorpay's side before recording anything —
            // the posted transactionID is attacker-supplied until this returns.
            $requestEndpoint = "https://api.razorpay.com/v1/payments/{$context['transactionID']}";
            $razorpayResponse = HttpHelper::get($requestEndpoint, null, $defaultHeader);
            if (!is_object($razorpayResponse) || !isset($razorpayResponse->id) || isset($razorpayResponse->error)) {
                wp_send_json_error(__('Transaction could not be verified', 'bitformpro'), 402);
            }

            // Left uncaptured, a repeat payment for an already-paid entry is voided by Razorpay.
            $guard = new RazorpayPaymentGuard($integration_details->apiKey ?? '', $integration_details->apiSecret ?? '');
            if ($context['entryId'] && $guard->isEntryPaid($context['formID'], $context['entryId'], $context['fieldKey'], $context['transactionID'])) {
                Log::debug_log("[Razorpay] Entry {$context['entryId']} already paid; payment {$context['transactionID']} left uncaptured.");
                wp_send_json_error(RazorpayPaymentGuard::alreadyPaidResponse(), 409);
            }

            // The Razorpay field posts entry_id as null, so this block normally does not run;
            // guarded rather than required so the capture and the payment log still happen.
            if ($context['entryId']) {
                $this->saveTransactionToTriggerData($context['entryId'], $context['fieldKey'], $context['transactionID']);
            }

            $captureRequestEndpoint = "https://api.razorpay.com/v1/payments/{$context['transactionID']}/capture?amount={$razorpayResponse->amount}&currency={$razorpayResponse->currency}";
            HttpHelper::post($captureRequestEndpoint, null, $defaultHeader);

            // invoice
            // if (isset($razorpayField->options->invoice) && $razorpayField->options->invoice->generate) {
            //     $data = [
            //         'type' => 'invoice',
            //         'currency' => $razorpayResponse->currency,
            //         'customer' => [
            //             'contact' => $razorpayResponse->contact,
            //             'email' => $razorpayResponse->email,
            //             'name' => ''
            //         ],
            //         'line_items'=> [
            //             (object) [
            //                 'name' => !empty($razorpayField->options->invoice->itemName) ? $razorpayField->options->invoice->itemName : 'Due Amount',
            //                 'description' => !empty($razorpayField->options->invoice->description) ?$razorpayField->options->invoice->description : '',
            //                 'amount' => $razorpayResponse->amount,
            //                 'currency' => $razorpayResponse->currency,
            //                 'quantity' => 1
            //             ]
            //         ]
            //     ];

            //     if (!isset($razorpayField->options->invoice->sendSMS)) {
            //         $data['sms_notify'] = 0;
            //     }
            //     if (!isset($razorpayField->options->invoice->sendEmail)) {
            //         $data['email_notify'] = 0;
            //     }
            //     $invoiceEndpoint = 'https://api.razorpay.com/v1/invoices?' . http_build_query($data);
            //     HttpHelper::post($invoiceEndpoint, null, $defaultHeader);
            // }

            $queryParams->payment_name = 'razorpay';
            $queryParams->payment_response = $razorpayResponse;
            if ($context['entryId']) {
                $this->saveMetaData($context);
            }
            $this->savePaymentLog($queryParams, $context);
        }
    }

    /** Was FrontendAjax::insertPayment(). */
    public function insertPayment()
    {
        Utility::ignoreUserAbort();
        $inputJSON = file_get_contents('php://input');
        $queryParams = JSON::decode($inputJSON);
        if (!is_object($queryParams) || !isset($queryParams->formID)) {
            wp_send_json_error(__('Invalid request', 'bitformpro'), 400);
        }
        if (!FormNonceCheckerMiddleware::allows($queryParams->formID)) {
            wp_send_json_error(
                __(
                    'Token expired',
                    'bitformpro',
                ),
                401,
            );
        }

        if (!isset($queryParams->transactionID)) {
            wp_send_json_error(__('FormId & EntryId is required', 'bitformpro'), 400);
        }

        $context = $this->validatePaymentContext($queryParams);
        if (is_wp_error($context)) {
            wp_send_json_error($context->get_error_message(), 403);
        }

        // entry_id is optional: the Razorpay field never sets one and PayPal only sets it when the
        // partial-save returned it, so requiring it here would reject those payments outright. The
        // meta write and the workflow transient are the only parts that need an entry, and
        // validatePaymentContext() has already proven the entry belongs to this form when present.
        if ($context['entryId']) {
            $this->saveMetaData($context);
            $this->saveTransactionToTriggerData($context['entryId'], $context['fieldKey'], $context['transactionID']);
        }

        $result = $this->savePaymentLog($queryParams, $context);
        wp_send_json_success($result, 200);
    }

    /** Was FrontendAjax::saveMetaData(). */
    private function saveMetaData(array $context)
    {
        $entyData = [
            'bitforms_form_entry_id' => $context['entryId'],
            'meta_key' => $context['fieldKey'],
            'meta_value' => $context['transactionID'],
        ];
        if (!FormEntryMeta::existsWhere($entyData)) {
            FormEntryMeta::insertRow($entyData);
        }
    }

    /** Was FrontendAjax::savePaymentLog(). */
    private function savePaymentLog($data, array $context)
    {
        $formID = $context['formID'];
        $transactionID = $context['transactionID'];
        $paymentType = isset($data->payment_type) && is_scalar($data->payment_type)
            ? sanitize_text_field((string) $data->payment_type)
            : '';
        // The gateway is whatever the form's field is configured as, not whatever was posted.
        $paymentName = $context['fieldType'];
        $response = JSON::encode($data->payment_response ?? null);
        $paymentModel = new PaymentInfoModel();
        return $paymentModel->paymentInsert($formID, $transactionID, $paymentName, $paymentType, $response);
    }

    /** Was FrontendAjax::saveTransactionToTriggerData(). */
    private function saveTransactionToTriggerData($entryId, $fieldKey, $transactionID)
    {
        $entryId = absint($entryId);
        $transientKey = "bitform_trigger_transient_{$entryId}";
        $cached = get_transient($transientKey);
        $triggerData = is_string($cached) ? JSON::decode($cached, true) : $cached;
        if (is_object($triggerData)) {
            $triggerData = (array) $triggerData;
        }

        if (is_array($triggerData) && !empty($triggerData)) {
            $triggerData['fields'][$fieldKey] = $transactionID;
            set_transient($transientKey, $triggerData, HOUR_IN_SECONDS);
            return;
        }

        // Free owns the queue row (API level 3, which FreeCompat requires).
        $queuedRow = FormLogDetail::latestQueuedOfEntry($entryId);
        if (empty($queuedRow->response_obj)) {
            return;
        }
        $responseObj = JSON::decode($queuedRow->response_obj, true);
        if (empty($responseObj['trigger'])) {
            return;
        }
        $responseObj['trigger']['fields'][$fieldKey] = $transactionID;
        FormLogDetail::updateQueuedResponse($queuedRow->id, $responseObj);
    }

    /** Was FrontendAjax::validatePaymentContext(). */
    private function validatePaymentContext($queryParams)
    {
        $formID = absint($queryParams->formID ?? 0);
        $entryId = absint($queryParams->entry_id ?? 0);
        $fieldKey = isset($queryParams->fieldKey) && is_string($queryParams->fieldKey)
            ? sanitize_text_field($queryParams->fieldKey)
            : '';
        $transactionID = isset($queryParams->transactionID) && is_scalar($queryParams->transactionID)
            ? sanitize_text_field((string) $queryParams->transactionID)
            : '';

        if (empty($formID) || '' === $fieldKey || '' === $transactionID) {
            return new \WP_Error('bitform_invalid_payment_request', __('Invalid payment request', 'bitformpro'));
        }

        // entry_id is optional (see insertPayment) — but when one is supplied it must belong to
        // the posted form, otherwise a crafted request could attach meta to any entry on the site.
        if ($entryId) {
            if (!FormEntry::existsWhere(['id' => $entryId, 'form_id' => $formID])) {
                return new \WP_Error('bitform_entry_mismatch', __('Entry does not belong to this form', 'bitformpro'));
            }
        }

        $formContent = FormManager::getInstance($formID)->getFormContent();
        $field = $formContent->fields->{$fieldKey} ?? null;
        $fieldType = is_object($field) && isset($field->typ) ? $field->typ : '';
        if (!in_array($fieldType, ['paypal', 'stripe', 'razorpay', 'mollie'], true)) {
            return new \WP_Error('bitform_not_payment_field', __('Not a payment field', 'bitformpro'));
        }

        return [
            'formID'        => $formID,
            'entryId'       => $entryId,
            'fieldKey'      => $fieldKey,
            'transactionID' => $transactionID,
            'fieldType'     => $fieldType,
        ];
    }
}
