<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetAuthSettingsRequest;
use BitApps\BitFormPro\Http\Requests\SaveAuthSettingsRequest;

/**
 * WP user registration / login form settings.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class AuthSettingsController
{
    /** Was AdminAjax::saveAuthSettings(). */
    public function store(SaveAuthSettingsRequest $request)
    {
        Utility::ignoreUserAbort();

        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);

        $requestsParams = $request->decodedOr400();
        $formId = $requestsParams->formId;
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $integrationHandler = new IntegrationHandler($formId, $user_details);
        $integrationName = $requestsParams->type;
        $status = $requestsParams->status;
        unset($requestsParams->type);
        unset($requestsParams->formId);
        unset($requestsParams->status);
        $integrationDetails = json_encode($requestsParams->$integrationName);
        $formIntegrations = $integrationHandler->getAllIntegration('wp_user_auth', 'wp_auth');
        if (isset($formIntegrations->errors['result_empty'])) {
            $result = $integrationHandler->saveIntegration($integrationName, 'wp_auth', $integrationDetails, 'wp_user_auth', $status);
        } else {
            $result = $integrationHandler->updateIntegration($formIntegrations[0]->id, $integrationName, 'wp_auth', $integrationDetails, 'wp_user_auth', $status);
        }
        return Response::success($result);
    }

    /** Was AdminAjax::getAuthSetting(). */
    public function show(GetAuthSettingsRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);

        $requestsParams = $request->decodedOr400();
        $formId = $requestsParams->formID;
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $integrationHandler = new IntegrationHandler($formId, $user_details);
        $formIntegrations = $integrationHandler->getAllIntegration('wp_user_auth', 'wp_auth');
        return Response::success($formIntegrations);
    }
}
