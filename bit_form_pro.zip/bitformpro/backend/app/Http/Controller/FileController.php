<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Services\Form\FormManager;
use BitApps\BitForm\Helpers\FileHandler;
use BitApps\BitForm\Services\Upgrade\AppStructureFallback;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;
use BitApps\BitFormPro\Http\Middleware\FormNonceCheckerMiddleware;

/**
 * Advanced file-upload field: temp upload and removal.
 *
 * Handlers moved verbatim from FrontendAjax. Their guards stay inline:
 * the nonce is issued per form (`bitforms_{formID}`, with the id read from
 * the request), which a static route middleware cannot express.
 */
final class FileController
{
    /** Was FrontendAjax::instandFileUpload(). */
    public function upload()
    {
        $formID = sanitize_text_field($_REQUEST['formID'] ?? '');
        $user = wp_get_current_user();
        if (FormNonceCheckerMiddleware::allows($formID) || in_array('administrator', $user->roles) || Capabilities::check('manage_bitform')) {
            $uploadDirInfo = wp_upload_dir();
            $wpUploadbaseDir = $uploadDirInfo['basedir'];
            $tmpDir = $wpUploadbaseDir . DIRECTORY_SEPARATOR . 'bitforms' . DIRECTORY_SEPARATOR . 'temp';
            // The folder sits beside Free's uploads folder, outside its .htaccess: give it its own
            // index.php and script-refusing .htaccess (Free 3.4.0 methods).
            FileHandler::createIndexFile($tmpDir);
            if (is_dir($tmpDir) && !file_exists($tmpDir . DIRECTORY_SEPARATOR . '.htaccess')) {
                (new AppStructureFallback())->ensureUploadDirHtaccess($tmpDir);
            }

            $fieldKey = sanitize_text_field($_REQUEST['fieldKey'] ?? '');

            if ('' === $formID || '' === $fieldKey || !isset($_FILES[$fieldKey])) {
                wp_send_json_error(__('Invalid upload request', 'bitformpro'), 400);
            }

            $formContent = FormManager::getInstance($formID)->getFormContent();
            $field = $formContent->fields->{$fieldKey} ?? null;
            $fieldType = is_object($field) && isset($field->typ) ? $field->typ : '';
            if (!in_array($fieldType, ['file-up', 'advanced-file-up'], true)) {
                wp_send_json_error(__('Not a file upload field', 'bitformpro'), 400);
            }

            $file_details = $_FILES[$fieldKey];

            $fileHandler = new FileHandler();
            $validation = $fileHandler->validation($fieldKey, $file_details, $formID);

            if (!empty($validation['error_type']) && !empty($validation['message'])) {
                wp_send_json_error(
                    __(
                        $validation['message'],
                        'bitformpro',
                    ),
                    411,
                );
            }

            // Random, unguessable prefix instead of time()
            $fileName = wp_generate_password(20, false, false) . '-' . sanitize_file_name($file_details['name']);
            $src = $file_details['tmp_name'];
            $destination = $tmpDir . DIRECTORY_SEPARATOR . $fileName;

            $uploaded = \move_uploaded_file($src, $destination);
            if ($uploaded) {
                $data = [
                    'file_name' => $fileName,
                    // 'path' => $destination,
                ];
                wp_send_json_success($data, 200);
            } else {
                $errorMsg = FileHandler::getFileUploadError($file_details['error']);
                // getFileUploadError() already returns a translated string
                wp_send_json_error($errorMsg, 411);
            }
        } else {
            wp_send_json_error(
                __(
                    'Token expired',
                    'bitformpro',
                ),
                401,
            );
        }
    }

    /** Was FrontendAjax::fileRemove(). */
    public function destroy()
    {
        $formID = sanitize_text_field($_REQUEST['formID'] ?? '');
        $user = wp_get_current_user();
        if (FormNonceCheckerMiddleware::allows($formID) || in_array('administrator', $user->roles) || Capabilities::check('manage_bitform')) {
            $fileName = isset($_GET['file_name']) && is_string($_GET['file_name'])
                ? sanitize_file_name(wp_unslash($_GET['file_name']))
                : '';

            if ($fileName === '') {
                wp_send_json_error(__('File name is required', 'bitformpro'), 411);
            }
            if (strpos($fileName, '..') !== false) {
                wp_send_json_error(__('Invalid file name', 'bitformpro'), 411);
            }

            $uploadDirInfo = wp_upload_dir();
            $wpUploadbaseDir = $uploadDirInfo['basedir'];

            $tempDir = $wpUploadbaseDir . DIRECTORY_SEPARATOR . 'bitforms' . DIRECTORY_SEPARATOR . 'temp';
            $tempFile = $tempDir . DIRECTORY_SEPARATOR . $fileName;

            $tempBase = realpath($tempDir);
            $resolved = realpath($tempFile);
            if (false === $tempBase || false === $resolved
                || 0 !== strpos($resolved, $tempBase . DIRECTORY_SEPARATOR)
                || !is_file($resolved)
            ) {
                wp_send_json_error(__('File not found', 'bitformpro'), 411);
            }

            if (unlink($resolved) !== true) {
                // never echo the resolved server path back to an unauthenticated caller
                wp_send_json_error(__('Could not delete file', 'bitformpro'), 411);
            }
            wp_send_json_success(__('File deleted successfully', 'bitformpro'), 200);
        } else {
            wp_send_json_error(__('Token expired', 'bitformpro'), 401);
        }
    }
}
