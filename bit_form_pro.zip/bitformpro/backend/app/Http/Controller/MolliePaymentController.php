<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitFormPro\Services\Payment\MolliePaymentSession;
use WP_Error;
use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitForm\Model\FormEntryMeta;

class MolliePaymentController extends PaymentServices
{
    protected $paymentName = 'mollie';
    protected $paymentType = 'order';

    private const MOLLIE_API_ENDPOINT = 'https://api.mollie.com/v2/payments';

    public function handlePayment()
    {
        $mollieDataString = file_get_contents('php://input');
        $data = JSON::decode($mollieDataString);
        // Mollie posts the webhook form-encoded ("id=tr_..."), not as JSON.
        $transactionId = $data->id ?? ($_POST['id'] ?? '');
        $transactionId = sanitize_text_field(wp_unslash((string) $transactionId));
        $paymentIntegId = isset($_GET['integID']) ? sanitize_text_field(wp_unslash($_GET['integID'])) : '';

        if (!$paymentIntegId || 0 !== strpos($transactionId, 'tr_')) {
            return new WP_Error('no_id', __('Payment Integration ID parameter is missing', 'bitformpro'), ['status' => 400]);
        }

        $mollieData = $this->getMolliePaymentInfo($paymentIntegId, $transactionId);

        if (is_object($mollieData) && !is_wp_error($mollieData) && ($mollieData->status ?? '') === 'paid') {
            $this->saveMolliePaymentInfo($mollieData);
        }

    }

    private function getIntegrationDetails($paymentIntegId)
    {
        $integrationHandler = new IntegrationHandler(0);
        $integrationDetails = $integrationHandler->getAllIntegration('app', 'payments', '', $paymentIntegId);
        $integrationRow = Utility::firstRow($integrationDetails);
        $integrationDetails = Utility::jsonObj($integrationRow->integration_details ?? '');
        return $integrationDetails;
    }

    public function createPayment($request)
    {
        if (!$request) {
            wp_send_json_error(__('Request is required', 'bitformpro'), 400);
        }
        $data = is_string($request) ? JSON::decode($request) : $request;
        $payIntegID = $data->payIntegID;
        $amount = $data->amount;
        $currency = $data->currency;
        $meta = $data->metadata;
        $method = $data->method;
        $description = $data->description;
        $redirectUrl = $data->redirectUrl;
        $entryID = $meta->entryID;

        $integrationDetails = $this->getIntegrationDetails($payIntegID);
        $apiKey = $integrationDetails->apiKey ?? '';
        $redirectUrl = add_query_arg('integID', $payIntegID, (string) $redirectUrl);
        $webhook_url = get_rest_url() . 'bitform/v1/payments/mollie' . '?integID=' . $payIntegID;

        // get file value
        $submittedValue = $this->getSubmittedValue($entryID);
        $replaceDescription = FieldValueHandler::replaceFieldWithValue($description, $submittedValue);

        $data = [
            'amount' => [
                'currency' => $currency,
                'value' => $amount,
            ],
            'description' => $replaceDescription,
            'redirectUrl' => $redirectUrl,
            'webhookUrl' => $webhook_url,
            'metadata' => (array) $meta,
            'method' => $method,
        ];

        $apiResponse = (new MolliePaymentSession($apiKey))->paymentFor($data, $payIntegID);

        if (is_wp_error($apiResponse)) {
            $errorData = $apiResponse->get_error_data();
            wp_send_json_error(
                ['code' => $apiResponse->get_error_code(), 'detail' => $apiResponse->get_error_message()],
                isset($errorData['status']) ? (int) $errorData['status'] : 400,
            );
        }
        if (isset($apiResponse->status) && is_int($apiResponse->status) && $apiResponse->status >= 400) {
            wp_send_json_error($apiResponse, $apiResponse->status);
        }
        if (!is_object($apiResponse) || empty($apiResponse->id)) {
            wp_send_json_error(['detail' => __('Could not start the Mollie payment. Please try again.', 'bitformpro')], 502);
        }
        wp_send_json_success($apiResponse, 200);
    }


    public function saveMolliePaymentInfo($data)
    {
        $this->transactionId = $this->sanitize($data->id);
        $this->formId = $this->sanitize($data->metadata->formID);
        $this->entryId = $this->sanitize($data->metadata->entryID);
        $this->fieldKey = $this->sanitize($data->metadata->fieldKey);
        $this->apiResponseData = $data;

        return $this->savePaymentInfo();
    }

    public function getMolliePaymentInfo($paymentIntegId, $transactionID)
    {
        $endpoint = self::MOLLIE_API_ENDPOINT . '/' . $transactionID;

        $integrationDetails = $this->getIntegrationDetails($paymentIntegId);

        $apiKey = $integrationDetails->apiKey ?? '';

        $headers = [
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ];

        $apiResponse = HttpHelper::get($endpoint, '', $headers);

        if (isset($apiResponse->status) && is_int($apiResponse->status) && $apiResponse->status >= 400) {
            return new WP_Error('api_error', $apiResponse->detail, ['status' => $apiResponse->status]);
        } else {
            return $apiResponse;
        }
    }


    public function getSubmittedValue($entryId)
    {
        return FormEntryMeta::valuesOfEntry($entryId);
    }

}
