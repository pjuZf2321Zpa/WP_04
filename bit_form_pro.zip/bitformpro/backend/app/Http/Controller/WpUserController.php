<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;

/**
 * WordPress users and roles for dynamic field options.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class WpUserController
{
    /** Was AdminAjax::getAllUsers(). */
    public function users()
    {
        $users = get_users();
        $usersData = [];

        foreach ($users as $key => $user) {
            $usersData[$key]['ID'] = $user->ID;
            $usersData[$key]['display_name'] = $user->display_name;
            $usersData[$key]['user_login'] = $user->user_login;
            $usersData[$key]['user_email'] = $user->user_email;
            $usersData[$key]['user_nicename'] = $user->user_nicename;
            $usersData[$key]['role'] = $user->roles;
        }
        return Response::success(['users' => $usersData]);
    }

    /** Was AdminAjax::getUserRoles(). */
    public function roles()
    {
        global $wp_roles;
        $roles = [];
        $key = 0;
        foreach ($wp_roles->get_names() as $index => $role) {
            $key++;
            $roles[$key]['key'] = $index;
            $roles[$key]['name'] = $role;
        }
        return Response::success($roles);
    }
}
