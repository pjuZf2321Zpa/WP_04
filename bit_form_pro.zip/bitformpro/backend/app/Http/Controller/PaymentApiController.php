<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Helpers\Log;
use WP_REST_Controller;
use WP_REST_Request;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

class PaymentApiController extends WP_REST_Controller
{
    /**
     * Dispatch a provider payment webhook to its gateway controller.
     *
     */
    public function handleTransactionCallback(WP_REST_Request $request)
    {
        $payment_type = $request['payment_type'];
        if ($payment_type === 'paypal') {
            (new PayPalPaymentController())->handlePayment();
        } elseif ($payment_type === 'stripe') {
            (new StripePaymentController())->handlePayment();
        } elseif ($payment_type === 'mollie') {
            (new MolliePaymentController())->handlePayment();
        } elseif ($payment_type === 'razorpay') {
            (new RazorpayPaymentController())->handlePayment();
        } elseif ($payment_type === 'custom_payment') {
            $dataString = file_get_contents('php://input');
            $data = JSON::decode($dataString);
            // There is no provider to re-fetch from and no shared secret stored for a
            // custom gateway, so raw unauthenticated input is NOT handed to a
            // success-writing action by default. A site implementing a custom gateway
            // must opt in by returning true from its own verifier filter.
            if (true === apply_filters('bitform_custom_payment_verify', false, $data)) {
                do_action('bitform_custom_payment_transaction_success', $data);
            } else {
                Log::debug_log('[custom_payment] Rejected unverified custom payment callback.');
            }
        } else {
            Log::debug_log('Payment type not found');
        }
    }
}
