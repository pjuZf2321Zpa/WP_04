<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Services\Admin\BfTable\Table;
use BitApps\BitFormPro\Services\Admin\FormSettings\DraftResume;
use BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment;
use BitApps\BitFormPro\Services\Frontend\EmailOtp\EmailOtpHandler;

/**
 * Requests a published form makes on a visitor's behalf: email OTP, partial
 * (abandoned) progress, and the rows of a frontend entry table.
 *
 * The logic stays in its owning classes, and so do the guards: the OTP and
 * partial-save nonces are issued per form, and the table rows are gated by the
 * view's own access settings — neither is a static route middleware.
 */
final class FormController
{
    /** Was EmailOtpHandler::sendOtp(). */
    public function sendEmailOtp()
    {
        EmailOtpHandler::sendOtp();
    }

    /** Was EmailOtpHandler::verifyOtp(). */
    public function verifyEmailOtp()
    {
        EmailOtpHandler::verifyOtp();
    }

    /** Was FormAbandonment::savePartialFormProgress(). */
    public function savePartialProgress()
    {
        FormAbandonment::savePartialFormProgress();
    }

    /** A Save & Resume link for the visitor's draft (DraftResume::createResumeLink()). */
    public function draftResumeLink()
    {
        DraftResume::createResumeLink();
    }

    /** Was Table::getEntriesByLimit(). */
    public function tableRows()
    {
        Table::getEntriesByLimit();
    }
}
