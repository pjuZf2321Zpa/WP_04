<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetDoubleOptInRequest;
use BitApps\BitFormPro\Http\Requests\SaveDoubleOptInRequest;

/**
 * Double opt-in settings.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class DoubleOptInController
{
    /** Was AdminAjax::saveDoubleOptIn(). */
    public function store(SaveDoubleOptInRequest $request)
    {
        Utility::ignoreUserAbort();

        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);
        $requestsParams = $request->decodedOr400();

        $formId = $requestsParams->formId;
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $integrationHandler = new IntegrationHandler($formId, $user_details);
        $status = $requestsParams->status;
        unset($requestsParams->formId);
        unset($requestsParams->status);
        $integrationDetails = json_encode($requestsParams);

        $formIntegrations = $integrationHandler->getAllIntegration('double-opt-in', 'double-opt-in');
        if (isset($formIntegrations->errors['result_empty'])) {
            $result = $integrationHandler->saveIntegration('entry confirmation', 'double-opt-in', $integrationDetails, 'double-opt-in', $status);
        } else {
            $result = $integrationHandler->updateIntegration($formIntegrations[0]->id, 'entry confirmation', 'double-opt-in', $integrationDetails, 'double-opt-in', $status);
        }
        return Response::success($result);
    }

    /** Was AdminAjax::getDblOptin(). */
    public function show(GetDoubleOptInRequest $request)
    {
        Utility::ignoreUserAbort();
        unset($_REQUEST['_ajax_nonce'], $_REQUEST['action'], $_REQUEST['status']);
        // $inputJSON = wp_unslash($_POST['data']);
        // $requestsParams = json_decode($inputJSON);

        $requestsParams = $request->decodedOr400();

        $formId = $requestsParams->formID;
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $integrationHandler = new IntegrationHandler($formId, $user_details);
        $formIntegrations = $integrationHandler->getAllIntegration('double-opt-in', 'double-opt-in');
        return Response::success($formIntegrations);
    }
}
