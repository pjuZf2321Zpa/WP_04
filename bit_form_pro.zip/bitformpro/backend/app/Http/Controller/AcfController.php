<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetAcfFieldsRequest;

/**
 * ACF sources for dynamic field options.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class AcfController
{
    /** Was AdminAjax::getCustomField(). */
    public function customField(GetAcfFieldsRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $input = json_decode($inputJSON);

        $input = $request->decodedOr400();

        $acfFields = [];
        $acfFile = [];

        $filterTypes = [
            "text",
            "textarea",
            "password",
            "wysiwyg",
            "number",
            "radio",
            "color_picker",
            "oembed",
            "email",
            "url",
            "date_picker",
            "true_false",
            "date_time_picker",
            "time_picker",
            "message",
            "checkbox",
            "select",
            "post_object",
            "user",
        ];
        $filterFile = ['file', 'image', 'gallery'];

        $field_groups = get_posts(['post_type' => 'acf-field-group']);
        if ($field_groups) {
            $groups = acf_get_field_groups(['post_type' => $input->post_type]);

            foreach ($groups as $group) {
                foreach (acf_get_fields($group['key']) as $acfField) {
                    if (in_array($acfField['type'], $filterTypes)) {
                        array_push($acfFields, [
                            'key' => $acfField['key'],
                            'name' => $acfField['label'],
                            'required' => $acfField['required'],
                        ]);
                    } elseif (in_array($acfField['type'], $filterFile)) {
                        array_push($acfFile, [
                            'key' => $acfField['key'],
                            'name' => $acfField['label'],
                            'required' => $acfField['required'],
                        ]);
                    }
                }
            }
        }
        return Response::success(['acfFields' => $acfFields, 'acfFile' => $acfFile]);
    }
}
