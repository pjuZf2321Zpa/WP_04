<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\BulkDeleteViewsRequest;
use BitApps\BitFormPro\Http\Requests\CreateViewRequest;
use BitApps\BitFormPro\Http\Requests\DeleteViewRequest;
use BitApps\BitFormPro\Http\Requests\GetViewsRequest;
use BitApps\BitFormPro\Http\Requests\UpdateViewRequest;
use BitApps\BitFormPro\Services\Admin\BfTable\Table;

/**
 * Frontend entry-table views (the `[bitform-table]` builder).
 *
 * As in bit-connect: each method reads its validated input and hands Table plain
 * values; Table no longer reads the request or replies. The view document
 * (create, update) goes whole, as decoded, so its empty `{}` configs are stored
 * as objects. Status codes are the ones the handlers always sent.
 */
final class FrontendViewController
{
    /** Was Table::getAllViews(). */
    public function index(GetViewsRequest $request)
    {
        $views = Table::getAllViews($request->validatedInt('formID'));
        if (is_wp_error($views)) {
            return Response::error($views->get_error_message(), 401);
        }

        return Response::success($views);
    }

    /** Was Table::createView(). */
    public function store(CreateViewRequest $request)
    {
        return Response::success(Table::createView($request->decodedOr400()));
    }

    /** Was Table::updateView(). */
    public function update(UpdateViewRequest $request)
    {
        $result = Table::updateView($request->decodedOr400());
        if (is_wp_error($result)) {
            return Response::error($result->get_error_message(), 500);
        }

        return Response::success($result);
    }

    /** Was Table::deleteTable(). */
    public function destroy(DeleteViewRequest $request)
    {
        return $this->answerDelete(Table::deleteTable($request->validatedInt('id')));
    }

    /** Was Table::deleteBulkTable(). */
    public function bulkDestroy(BulkDeleteViewsRequest $request)
    {
        $validated = $request->validated();

        return $this->answerDelete(Table::deleteBulkTable($validated['tblId'] ?? null));
    }

    /**
     * @param true|\WP_Error $status
     *
     * @return Response
     */
    private function answerDelete($status)
    {
        if (is_wp_error($status)) {
            return Response::error($status->get_error_message(), 411);
        }

        return Response::success(__('Table deleted successfully.', 'bitformpro'));
    }
}
