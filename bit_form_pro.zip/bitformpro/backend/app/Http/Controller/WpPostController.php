<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Model\PostInfoModel;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetTermPostsRequest;

/**
 * WordPress posts, post types and taxonomies for dynamic field options.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class WpPostController
{
    /** Was AdminAjax::postTypebyUser(). */
    public function postTypes()
    {
        $users = get_users(
            [
                'fields' => ['ID', 'display_name', 'user_login', 'user_email', 'user_nicename'],
            ],
        );

        $postTypes = $this->getPostTypes();

        $data = ['post_types' => $postTypes, 'users' => $users];
        return Response::success($data);
    }

    /** Was AdminAjax::getAllPosts(). */
    public function posts()
    {
        $postTypes = $this->getPostTypes();

        $postInfoModel = new PostInfoModel();

        $allPosts = $postInfoModel->getAllPosts();

        return Response::success(['posts' => $allPosts, 'postTypes' => $postTypes]);
    }

    /** Was AdminAjax::getTaxonomies(). */
    public function taxonomies()
    {
        $allCategoreis = get_terms(
            [
                'hide_empty' => false,
            ],
        );

        $getTaxanomies = get_taxonomies($args = [], $output = 'label', $operator = 'and');
        $taxonomies = [];

        foreach ($getTaxanomies as $index => $taxanomy) {
            $taxonomies[$index]['label'] = $taxanomy->label;
            $taxonomies[$index]['name'] = $taxanomy->name;
            $taxonomies[$index]['singular_name'] = $taxanomy->labels->singular_name;
            $taxonomies[$index]['object_type'] = $taxanomy->object_type;
            $taxonomies[$index]['hierarchical'] = $taxanomy->hierarchical;
        }

        return Response::success(['taxonomies' => array_values($taxonomies), 'allCategoreis' => $allCategoreis]);
    }

    /**
     * Post IDs assigned to one taxonomy term, for the Posts import "Filter by Term" preview.
     *
     * Was AdminAjax::getTermPosts().
     */
    public function termPosts(GetTermPostsRequest $request)
    {
        $taxonomy = isset($_REQUEST['taxonomy']) ? sanitize_key($_REQUEST['taxonomy']) : '';
        $termId = isset($_REQUEST['termId']) ? intval($_REQUEST['termId']) : 0;
        if (empty($taxonomy) || !taxonomy_exists($taxonomy) || $termId <= 0) {
            return Response::error(__('Invalid taxonomy or term', 'bitformpro'), 400);
        }

        $postIds = get_objects_in_term($termId, $taxonomy);
        if (is_wp_error($postIds)) {
            return Response::error($postIds->get_error_message(), 400);
        }

        return Response::success(['postIds' => array_map('intval', $postIds)]);
    }

    /** Was AdminAjax::getPostTypes(). */
    private function getPostTypes()
    {
        $all_cpt = get_post_types(
            [
                'public' => true,
                'exclude_from_search' => false,
                '_builtin' => false,
                'capability_type' => 'post',

            ],
            'objects',
        );
        $cpt = [];

        foreach ($all_cpt as $key => $post_type) {
            $cpt[$key]['name'] = $post_type->name;
            $cpt[$key]['label'] = $post_type->label;
        }
        $wp_post_types = get_post_types(
            [
                'public' => true,
                '_builtin' => true,
            ],
        );

        $wp_all_post_types = [];

        foreach ($wp_post_types as $key => $post_type) {
            if ($post_type !== 'attachment') {
                $wp_all_post_types[$key]['name'] = $post_type;
                $wp_all_post_types[$key]['label'] = ucwords($post_type);
            }
        }
        return array_merge($wp_all_post_types, $cpt);
    }
}
