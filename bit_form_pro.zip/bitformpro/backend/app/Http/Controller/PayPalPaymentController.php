<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitForm\Helpers\Log;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

class PayPalPaymentController extends PaymentServices
{
    protected $paymentName = 'paypal';
    protected $paymentType = 'order';

    public function handlePayment()
    {
        $paypalDataString = file_get_contents('php://input');
        $paypalData = JSON::decode($paypalDataString);

        // The webhook body is attacker-controllable, so the event string is only a
        // cheap pre-filter — never proof of payment.
        if (($paypalData->event_type ?? '') !== 'CHECKOUT.ORDER.APPROVED') {
            Log::debug_log('[PayPal] Unhandled event: ' . ($paypalData->event_type ?? 'unknown'));
            return;
        }

        // Trust only the order id from the webhook (used to re-fetch), plus form id +
        // field key which merely select the merchant credentials to verify with.
        $orderId = isset($paypalData->resource->id) ? $this->sanitize($paypalData->resource->id) : '';
        $routing = $this->parseCustomId($paypalData->resource->purchase_units[0]->custom_id ?? '');
        $formId = $routing['form-id'] ?? '';
        $fieldKey = $routing['field-key'] ?? '';

        if (empty($orderId) || empty($formId) || empty($fieldKey)) {
            Log::debug_log('[PayPal] Webhook missing order id / routing custom_id.');
            return;
        }

        $integrationDetails = $this->resolvePaymentIntegrationDetails($formId, $fieldKey);
        $clientId = $integrationDetails->clientID ?? '';
        $clientSecret = $integrationDetails->clientSecret ?? '';
        $mode = ($integrationDetails->mode ?? '') === 'live' ? 'live' : 'sandbox';
        if (empty($clientId) || empty($clientSecret)) {
            Log::debug_log('[PayPal] Could not resolve merchant credentials for the webhook.');
            return;
        }

        $baseUrl = 'live' === $mode ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

        $accessToken = $this->getAccessToken($baseUrl, $clientId, $clientSecret);
        if (empty($accessToken)) {
            Log::debug_log('[PayPal] Failed to obtain access token for verification.');
            return;
        }

        // Out-of-band verification: re-fetch the order from PayPal with a token minted
        // from the merchant's own credentials. A forged/unpaid order cannot pass this.
        $verified = HttpHelper::get(
            "{$baseUrl}/v2/checkout/orders/{$orderId}",
            null,
            [
                'Authorization' => "Bearer {$accessToken}",
                'Content-Type'  => 'application/json',
            ],
        );

        $capture = $verified->purchase_units[0]->payments->captures[0] ?? null;
        $orderCompleted = ($verified->status ?? '') === 'COMPLETED'
            || (isset($capture->status) && $capture->status === 'COMPLETED');

        if (empty($verified->id) || !$orderCompleted) {
            Log::debug_log("[PayPal] Verification failed for order {$orderId}.");
            return;
        }

        // Routing metadata is taken from the verified provider response, not the webhook.
        $verifiedRouting = $this->parseCustomId($verified->purchase_units[0]->custom_id ?? '');
        $transactionId = isset($capture->id) ? $capture->id : $verified->id;

        $this->formId = $this->sanitize($verifiedRouting['form-id'] ?? $formId);
        $this->entryId = isset($verifiedRouting['entry-id']) ? $this->sanitize($verifiedRouting['entry-id']) : '';
        $this->fieldKey = $this->sanitize($verifiedRouting['field-key'] ?? $fieldKey);
        $this->transactionId = $this->sanitize($transactionId);
        $this->apiResponseData = $verified;

        $this->savePaymentInfo();

        wp_send_json_success(__('PayPal order completed and processed.', 'bitformpro'), 200);
    }

    /**
     * Mint an OAuth2 access token from the merchant's client credentials.
     *
     * @param string $baseUrl
     * @param string $clientId
     * @param string $clientSecret
     * @return string
     */
    private function getAccessToken($baseUrl, $clientId, $clientSecret)
    {
        $response = HttpHelper::post(
            "{$baseUrl}/v1/oauth2/token",
            'grant_type=client_credentials',
            [
                'Authorization' => 'Basic ' . base64_encode("{$clientId}:{$clientSecret}"),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
        );

        return $response->access_token ?? '';
    }

    /**
     * Parse a PayPal custom_id of the form "form-id:1;entry-id:2;field-key:abc"
     * into an associative array.
     *
     * @param string $customId
     * @return array
     */
    private function parseCustomId($customId)
    {
        $result = [];
        if (!is_string($customId) || '' === $customId) {
            return $result;
        }
        foreach (explode(';', $customId) as $pair) {
            $parts = explode(':', $pair);
            if (count($parts) === 2) {
                $result[$parts[0]] = $parts[1];
            }
        }
        return $result;
    }
}
