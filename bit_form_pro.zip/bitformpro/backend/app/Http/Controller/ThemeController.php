<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Services\ThemeManager;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\DeleteThemeRequest;
use BitApps\BitFormPro\Http\Requests\DuplicateThemeRequest;
use BitApps\BitFormPro\Http\Requests\ExportThemeRequest;
use BitApps\BitFormPro\Http\Requests\ImportThemeRequest;
use BitApps\BitFormPro\Http\Requests\RenameThemeRequest;
use BitApps\BitFormPro\Http\Requests\SaveThemeRequest;
use BitApps\BitFormPro\Http\Requests\SetDefaultThemeRequest;

/**
 * Custom form themes (the theme gallery).
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class ThemeController
{
    /** Was AdminAjax::get_custom_themes(). */
    public function index()
    {
        $themes = ThemeManager::get_custom_themes();
        $default_theme = ThemeManager::get_default_theme();

        return Response::success([
            'themes'        => $themes,
            'default_theme' => $default_theme,
        ]);
    }

    /** Was AdminAjax::save_custom_theme(). */
    public function store(SaveThemeRequest $request)
    {
        $theme_data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $theme_data = JSON::decode(json_encode($theme_data), true);

        $result = ThemeManager::save_theme($theme_data);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success($result);
    }

    /** Was AdminAjax::delete_custom_theme(). */
    public function destroy(DeleteThemeRequest $request)
    {
        $data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $data = JSON::decode(json_encode($data), true);
        $theme_slug = $data['theme_slug'] ?? '';

        $result = ThemeManager::delete_theme($theme_slug);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success($result);
    }

    /** Was AdminAjax::duplicate_theme(). */
    public function duplicate(DuplicateThemeRequest $request)
    {
        $data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $data = JSON::decode(json_encode($data), true);
        $source_slug = $data['source_slug'] ?? '';
        $new_name = $data['new_name'] ?? '';

        $result = ThemeManager::duplicate_theme($source_slug, $new_name);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success($result);
    }

    /** Was AdminAjax::set_default_theme(). */
    public function setDefault(SetDefaultThemeRequest $request)
    {
        $data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $data = JSON::decode(json_encode($data), true);
        $theme_slug = $data['theme_slug'] ?? '';

        $result = ThemeManager::set_default_theme($theme_slug);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success($result);
    }

    /** Was AdminAjax::rename_theme(). */
    public function rename(RenameThemeRequest $request)
    {
        $data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $data = JSON::decode(json_encode($data), true);
        $theme_slug = $data['theme_slug'] ?? '';
        $new_name = $data['new_name'] ?? '';

        $result = ThemeManager::rename_theme($theme_slug, $new_name);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success($result);
    }

    /** Was AdminAjax::export_theme(). */
    public function export(ExportThemeRequest $request)
    {
        $data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $data = JSON::decode(json_encode($data), true);
        $theme_slug = $data['theme_slug'] ?? '';

        $result = ThemeManager::export_theme($theme_slug);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success(['json' => $result]);
    }

    /** Was AdminAjax::import_theme(). */
    public function import(ImportThemeRequest $request)
    {
        $data = $request->decodedOr400();
        // Convert object to array for ThemeManager
        $data = JSON::decode(json_encode($data), true);
        $json_data = $data['json_data'] ?? '';
        $new_name = $data['new_name'] ?? null;

        $result = ThemeManager::import_theme($json_data, $new_name);

        if (is_wp_error($result)) {
            return Response::error($result->get_error_message());
        }

        return Response::success($result);
    }
}
