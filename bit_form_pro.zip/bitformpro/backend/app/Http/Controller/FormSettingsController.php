<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\AbandonmentEntryRequest;
use BitApps\BitFormPro\Http\Requests\GetFormAbandonmentConfigRequest;
use BitApps\BitFormPro\Http\Requests\GetFormTemplateRequest;
use BitApps\BitFormPro\Http\Requests\SaveStandaloneCssRequest;
use BitApps\BitFormPro\Services\Abandonment\AbandonmentAdmin;
use BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment;
use BitApps\BitFormPro\Services\Admin\FormSettings\StandaloneForm;
use BitApps\BitFormPro\Services\Template\TemplateProvider;

/**
 * Per-form Pro settings: form abandonment, standalone page CSS, and the Pro
 * form templates offered when creating a form.
 *
 * The logic stays in its owning classes; the nonce and POST guards each one
 * used to open with now run as route middleware.
 */
final class FormSettingsController
{
    /** Was FormAbandonment::getFormAbandonmentConfig(). */
    public function abandonmentConfig(GetFormAbandonmentConfigRequest $request)
    {
        $settings = FormAbandonment::getFormAbandonmentConfig($request->validatedInt('formID'));
        if (empty($settings)) {
            return Response::error(__('Nothing found', 'bitformpro'), 401);
        }

        return Response::success($settings);
    }

    /** The entry page's partial-entry panel: its state, and send now / stop / resume link. */
    public function abandonmentEntry(AbandonmentEntryRequest $request)
    {
        $formId = (int) $request->validatedInt('formID');
        $entryId = (int) $request->validatedInt('entryID');
        $input = $request->validated();
        $task = isset($input['task']) ? sanitize_key($input['task']) : 'state';
        if ($formId < 1 || $entryId < 1 || !AbandonmentAdmin::entryOfForm($formId, $entryId)) {
            return Response::error(__('Entry not found.', 'bitformpro'), 404);
        }

        $result = AbandonmentAdmin::run($task, $formId, $entryId);
        if (is_wp_error($result)) {
            return Response::error($result->get_error_message(), 422);
        }

        return Response::success($result);
    }

    /** Was StandaloneForm::saveStandaloneCSS(). */
    public function saveStandaloneCss(SaveStandaloneCssRequest $request)
    {
        StandaloneForm::saveStandaloneCSS();
    }

    /** Was TemplateProvider::getTemplate(). */
    public function template(GetFormTemplateRequest $request)
    {
        (new TemplateProvider())->getTemplate();
    }
}
