<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Services\Admin\AdminFormHandler;
use BitApps\BitForm\Services\Admin\Helpers;
use BitApps\BitFormPro\Services\Messages\PdfTemplateHandler;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Helpers\FrontendHelpers;
use BitApps\BitForm\Helpers\Log;
use BitApps\BitForm\Model\FormEntry;
use BitApps\BitFormPro\Services\Admin\AppSetting\Pdf;
use BitApps\BitFormPro\Helpers\LicenseHelper;
use BitApps\BitFormPro\Helpers\Utility;
use WP_Error;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Http\Middleware\EntryEditorCheckerMiddleware;

class EntryDownloadPageController
{
    public function __construct() {}

    public static function download()
    {
        if (!LicenseHelper::hasValidLicense()) {
            wp_send_json_error(__('This feature not available!', 'bitformpro'), 401);
        }
        $requestUri = $_SERVER['REQUEST_URI'];

        if (self::parse_url($requestUri)) {
            $params = self::parse_url($requestUri);

            $formID = Helpers::sanitizeUrlParam($params['formID']);
            $templateID = Helpers::sanitizeUrlParam($params['templateID']);
            $entryID = Helpers::sanitizeUrlParam($params['entryID']);
            $GLOBALS['bitform_entry_id'] = $entryID;

            if (is_wp_error($formID) || is_wp_error($templateID) || is_wp_error($entryID)) {
                wp_send_json_error(__('Maybe missing some parameter!', 'bitformpro'), 400);
                return;
            }
            $result = self::downloadPDF($formID, $templateID, $entryID, false);

            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message(), 411);
            }
            return $result;
        } else {
            return new WP_Error('Parameter_error', __('Maybe missing some parameter!', 'bitformpro'));
        }
    }

    /**
     * Parse the URL and extract the form ID, entry ID and file ID
     *
     * @param string $url
     * @return array|json
     */
    private static function parse_url($url)
    {
        $url_parse = wp_parse_url($url);
        if (isset($url_parse['query'])) {
            parse_str($url_parse['query'], $query);

            if (isset($query['token'])) {
                $token = Helpers::sanitizeUrlParam($query['token']);

                $decryptEntryId = Helpers::decryptBinaryData($token);

                if (is_wp_error($decryptEntryId)) {
                    wp_send_json_error(__('Decryption Failled!', 'bitformpro'), 400);
                }

                $valuesArr = explode(BITFORMS_BF_SEPARATOR, $decryptEntryId);
                if (3 === count($valuesArr)) {
                    $arrIndex = ['formID', 'templateID', 'entryID'];
                    $result = array_combine($arrIndex, $valuesArr);
                    return $result;
                }
                wp_send_json_error(__('Maybe your token is wrong!', 'bitformpro'), 400);
            }
            wp_send_json_error(__('Token dose not exist in URL', 'bitformpro'), 400);
        }
        wp_send_json_error(__('Query param dose not exist in URL', 'bitformpro'), 400);
    }

    public static function adminDownloadPDF()
    {
        if (!LicenseHelper::hasValidLicense()) {
            wp_send_json_error(__('This feature not available!', 'bitformpro'), 401);
        }
        $requestUri = $_SERVER['REQUEST_URI'];

        $url_parse = wp_parse_url($requestUri);

        if (isset($url_parse['query'])) {
            parse_str($url_parse['query'], $query);
            if (isset($query['formID'], $query['pdftemp'], $query['entryId'])) {
                $formID = Helpers::sanitizeUrlParam($query['formID']);
                $templateID = Helpers::sanitizeUrlParam($query['pdftemp']);
                $entryID = Helpers::sanitizeUrlParam($query['entryId']);
                $GLOBALS['bitform_entry_id'] = $entryID;

                if (is_wp_error($formID) || is_wp_error($templateID) || is_wp_error($entryID)) {
                    Log::debug_log('Maybe missing some parameter!');
                    wp_send_json_error(__('Maybe missing some parameter!', 'bitformpro'), 400);
                }
                $result = self::downloadPDF($formID, $templateID, $entryID);

                if (is_wp_error($result)) {
                    wp_send_json_error($result->get_error_message(), 411);
                }
                return $result;
            }
            wp_send_json_error(__('Maybe missing some parameter!', 'bitformpro'), 400);
        } else {
            wp_send_json_error(__('Query param dose not exist in URL', 'bitformpro'), 400);
        }
    }

    private static function downloadPDF($formID, $templateID, $entryID, $requireAccessCheck = true)
    {
        $pdfTemplateHandler = new PdfTemplateHandler($formID);
        $pdfTemplate = $pdfTemplateHandler->getById($templateID);


        if (is_wp_error($pdfTemplate)) {
            return $pdfTemplate;
        }

        $pdfTemplateRow = Utility::firstRow($pdfTemplate);
        if (!$pdfTemplateRow) {
            return new WP_Error('pdf_template_error', __('PDF template not found.', 'bitformpro'));
        }

        if (!PdfTemplateHandler::isEnabled($pdfTemplateRow->pdf_config ?? null)) {
            return new WP_Error('pdf_template_disabled', __('PDF template is disabled.', 'bitformpro'));
        }

        $rawPdfSetting = $pdfTemplateRow->setting ?? '';
        if (is_string($rawPdfSetting) && '' !== $rawPdfSetting) {
            JSON::decode($rawPdfSetting);
            if (json_last_error() !== JSON_ERROR_NONE) {
                Log::debug_log('Invalid PDF settings JSON.');
                return new WP_Error('json_error', __('Invalid PDF settings JSON.', 'bitformpro'));
            }
        }

        // Templates saved without settings hold `""`; the property reads below
        // (password, pdfFileName, header/footer) fatal on a string.
        $pdfSetting = PdfTemplateHandler::normalizeSetting($rawPdfSetting);

        $allowDownload = $pdfSetting->allowDownload ?? '';

        // Token links (emails, confirmation messages) carry no session check of their own.
        if (!$requireAccessCheck && 'loggedIn' === $allowDownload && !EntryEditorCheckerMiddleware::allows()) {
            self::denyDownload();
            return;
        }
        $body = $pdfTemplateRow->body ?? '';

        $adminFormHandler = new AdminFormHandler();
        $entry = $adminFormHandler->getSingleEntry($formID, $entryID);

        if (is_wp_error($entry)) {
            Log::debug_log('Entry fetch error => ' . $entry->get_error_message());
            return $entry;
        }

        // getSingleEntry() reads by entry id alone: another form's entry would come back.
        if (empty($entry) || !FormEntry::existsWhere(['id' => (int) $entryID, 'form_id' => (int) $formID])) {
            return new WP_Error('entry_not_found', __('Entry not found.', 'bitformpro'));
        }
        $entry = (array) $entry;

        if ($requireAccessCheck && !self::canDownloadWithSession($formID, $allowDownload, $entry)) {
            self::denyDownload();
            return;
        }
        $serverPath = Helpers::getFullPathWithEncryptedEntryId($formID, $entryID);
        $webPath = Helpers::getWebPathWithEncryptedEntryId($formID, $entryID);
        // TODO: this password only for user, don't need to admin, so, we need to check the user role
        // Remember: before implement this feature, need to discuss with team
        if (isset($pdfSetting->password->static) && $pdfSetting->password->static && !empty($pdfSetting->password->pass)) {
            $pass = FieldValueHandler::replaceFieldWithValue($pdfSetting->password->pass, $entry);
            $pdfSetting->password->pass = $pass;
        }
        // dynamic password are temporary disabled
        // elseif (isset($pdfSetting->password->dynamic)) {
        //   $pass = Helpers::PDFPassHash($entryID);
        //   $pdfSetting->password->pass = $pass;
        // }
        // Resolve smart tags in the file name like the email-attachment path does; the
        // generator strips any filesystem-hostile chars the field values bring in.
        if (isset($pdfSetting->pdfFileName) && !empty($pdfSetting->pdfFileName)) {
            $pdfSetting->pdfFileName = FieldValueHandler::replaceFieldWithValue($pdfSetting->pdfFileName, $entry);
            // allow developers to modify PDF filename
            $pdfSetting->pdfFileName = apply_filters(
                'bitform_filter_pdf_filename',
                $pdfSetting->pdfFileName,
                [
                    'form_id'      => $formID,
                    'entry_id'     => $entryID,
                    'field_values' => $entry,
                    'pdf_setting'  => $pdfSetting,
                    'template'     => $pdfTemplateRow,
                ],
            );
        }
        $pdfBody = FieldValueHandler::replaceFieldWithValue($body, $entry, $formID);
        $pdfBody = FieldValueHandler::changeImagePathInHTMLString($pdfBody, $serverPath);
        $pdfBody = FieldValueHandler::changeHrefPathInHTMLString($pdfBody, $webPath); //replace anchor tag href with constructed url

        // Same filter contract as the email-attachment path in PdfMailHandler.
        $pdfBody = apply_filters(
            'bitform_filter_pdf_body',
            $pdfBody,
            [
                'form_id'      => $formID,
                'entry_id'     => $entryID,
                'field_values' => $entry,
                'pdf_setting'  => $pdfSetting,
                'template'     => $pdfTemplateRow,
            ],
        );

        $headerFooter = PdfTemplateHandler::resolveHeaderFooter($pdfTemplateRow->pdf_config ?? null, $entry, $formID, $serverPath, $webPath);
        $pdfSetting->header = $headerFooter['header'];
        $pdfSetting->footer = $headerFooter['footer'];

        $pdfResult = Pdf::getInstance()->generator($pdfSetting, $pdfBody, '', $entry['entry_id'], 'I');

        if (is_wp_error($pdfResult)) {
            Log::debug_log('PDF download error => ' . $pdfResult->get_error_message());
            return $pdfResult;
        }

        return true;


        // try {
        //     Pdf::getInstance()->generator($pdfSetting, $pdfBody, '', $entry['entry_id'], 'I');
        // } catch (\Exception $e) {
        //     Log::debug_log('PDF download error => ' . $e->getMessage());
        //     wp_send_json_error($e->getMessage(), 411);
        // }

        // wp_send_json_error(__('Failed to generate or download PDF.'), 411);
    }

    /**
     * The plain-id link: the admin's entry screen and Data View. Nothing in the URL
     * authorises it, so the template's download setting and the viewer's own entry
     * access decide.
     *
     * @param int|string $formID
     * @param string     $allowDownload the template's setting: '' (None), 'all' or 'loggedIn'
     * @param array      $entry
     *
     * @return bool
     */
    private static function canDownloadWithSession($formID, $allowDownload, $entry)
    {
        if (EntryEditorCheckerMiddleware::allows()) {
            return true;
        }
        if (empty($allowDownload) || ('loggedIn' === $allowDownload && !is_user_logged_in())) {
            return false;
        }

        return FrontendHelpers::is_current_user_can_access($formID, 'entryViewAccess', '', $entry['__user_id'] ?? null);
    }

    /**
     * auth_redirect() is only for visitors: the auth cookie is not sent on front-end URLs,
     * so it sends a logged-in user to wp-login with reauth=1, which logs them out.
     *
     * @return void
     */
    private static function denyDownload()
    {
        if (is_user_logged_in()) {
            wp_die(esc_html__('You do not have permission to view this entry', 'bitformpro'), '', ['response' => 403]);
        }
        auth_redirect();
    }

    /**
     * Data View's single entry page. Unlike an email's link this one is opened by the
     * viewer of that page, so it asks their session rather than carrying a token.
     *
     * @param string     $content
     * @param int|string $formID
     * @param int|string $entryID
     *
     * @return string
     */
    public function replacePdfShortCodeToViewLink($content, $formID, $entryID)
    {
        return preg_replace_callback(
            '/\${bf_pdf_download\.(\d+)}/',
            function ($matches) use ($formID, $entryID) {
                return site_url('/?bitform-download-pdf=1&formID=' . (int) $formID . '&pdftemp=' . (int) $matches[1] . '&entryId=' . (int) $entryID);
            },
            $content,
        );
    }

    public function generateDownloadPdfLink($formID, $templateID, $entryID)
    {
        $combinedIdentifier = (int) $formID . BITFORMS_BF_SEPARATOR . (int) $templateID . BITFORMS_BF_SEPARATOR . (int) $entryID;
        $token = Helpers::encryptBinaryData($combinedIdentifier);
        return site_url('/?bitform-download-file=1&token=' . $token);
    }

    public function replacePdfShortCodeToLink($content, $formID, $entryID)
    {
        $pattern = '/\${bf_pdf_download\.(\d+)}/';
        preg_match_all($pattern, $content, $matches);

        if (!empty($matches)) {
            foreach ($matches[1] as $id) {
                $pdfLink = $this->generateDownloadPdfLink($formID, $id, $entryID);
                $content = str_replace('${bf_pdf_download.' . $id . '}', $pdfLink, $content);
            }
        }
        return $content;
    }

    public function replaceShortCodeToPdfPassword($content, $formID, $entryID)
    {
        $pattern = '/\${bf_pdf_password\.(\d+)}/';
        preg_match_all($pattern, $content, $matches);

        if (!empty($matches[1])) {
            try {
                $pdfTemplateHandler = new PdfTemplateHandler($formID);
                $adminFormHandler = new AdminFormHandler();
                $entry = (array) $adminFormHandler->getSingleEntry($formID, $entryID);

                foreach ($matches[1] as $templateID) {
                    $pdfTemplate = $pdfTemplateHandler->getById($templateID);
                    $pdfRow = Utility::firstRow($pdfTemplate);
                    $pdfSetting = Utility::jsonObj($pdfRow->setting ?? '');

                    if (isset($pdfSetting->password->static) && $pdfSetting->password->static && !empty($pdfSetting->password->pass)) {
                        $pdfPassword = FieldValueHandler::replaceFieldWithValue($pdfSetting->password->pass, $entry);
                    }
                    // dynamic password are temporary disabled
                    elseif (isset($pdfSetting->password->dynamic)) {
                        $pdfPassword = self::generatePassword($formID, $entryID);
                    }

                    $content = str_replace('${bf_pdf_password.' . $templateID . '}', $pdfPassword, $content);
                }
            } catch (\Exception $e) {
                Log::debug_log('PDF password generate error => ' . $e->getMessage());
                wp_send_json_error($e->getMessage(), 411);
            }
        }

        return $content;
    }

    private static function generatePassword($formID, $entryID)
    {
        return Helpers::PDFPassHash($entryID);
    }
}
