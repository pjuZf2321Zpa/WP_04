<?php

namespace BitApps\BitFormPro\Http\Controller;

use BitApps\BitForm\Services\Admin\AdminFormManager;
use BitApps\BitForm\Services\Form\Validator\FormFieldValidator;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Helpers\FileHandler;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Workflow\WorkFlow;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Services\Admin\Helpers;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitForm\Model\Workflow as WorkflowRow;
use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitForm\Model\FormEntryLog;
use BitApps\BitForm\Model\FormEntry;
use BitApps\BitForm\Model\Form;
use BitApps\BitForm\Model\EntryTableQuery;

class EntryApiController extends WP_REST_Controller
{
    protected static $form;
    protected $form_id;
    private $_has_upload;
    private $_field_label;
    private $_fields;

    public function form_content($formID)
    {
        $form = Form::readWhere(['id' => $formID], ['id', 'form_content', 'form_name', 'created_at', 'views', 'entries', 'status']);
        return $form;
    }

    public function get_forms()
    {
        $forms = Form::rowsWhere(['status' => 1], ['form_name', 'id'], 'created_at', 'desc');
        if (count($forms) > 0) {
            return rest_ensure_response(['forms' => $forms, 'status' => 200, 'code' => 4000, 'success' => true]);
        } else {
            return rest_ensure_response(['forms' => [], 'status' => 200, 'code' => 3910, 'message' => 'No forms available.', 'success' => true]);
        }
    }
    public function get_workflow($request)
    {
        $formID = $request['form_id'];
        $formManager = new AdminFormManager($formID);
        if (!$formManager->isExist()) {
            $data = ['message' => 'No Form with ID "<form_id>".', 'code' => '3200'];
            wp_send_json_error($data, 404);
        }
        $workFlows = WorkflowRow::rowsWhere(
            ['form_id' => (int) $formID, 'workflow_type' => 'onsubmit'],
            ['id', 'workflow_name', 'workflow_type', 'workflow_run', 'workflow_behaviour', 'workflow_status'],
            'id',
            'desc',
        );
        if (count($workFlows) > 0) {
            return rest_ensure_response(['workflow' => $workFlows, 'status' => 200, 'code' => 4000, 'success' => true]);
        } else {
            return rest_ensure_response(['workflow' => [], 'status' => 200, 'code' => 3910, 'message' => 'No workflow available.', 'success' => true]);
        }
    }

    public function get_fields($request)
    {
        if (!empty($request['form_id'])) {
            $formManager = new AdminFormManager($request['form_id']);
            if (!$formManager->isExist()) {
                $error = ['message' => 'No Form with ID "<form_id>".', 'code' => '3200'];
                wp_send_json_error($error, 404);
            }
            $fields = Form::rowsWhere(['status' => 1, 'id' => (int) $request['form_id']], ['form_content', 'id']);
            $workFlows = WorkflowRow::rowsWhere(['form_id' => (int) $request['form_id']], ['workflow_name', 'id']);
            $fieldsKey = $formManager->getFieldsKey();
            $unset_types = ['razorpay', 'paypal', 'recaptcha', 'hcaptcha', 'turnstile'];
            $fieldsRow = Utility::firstRow($fields);
            if ($fieldsRow) {
                $filedsData = Utility::jsonObj($fieldsRow->form_content ?? '');
                foreach (($filedsData->fields ?? []) as $key => $field) {
                    if (in_array($field->typ, $unset_types)) {
                        unset($filedsData->fields->$key, $fieldsKey[$key]);
                    }
                }
                $data = ['fields' => $filedsData->fields ?? [], 'fieldkeys' => $fieldsKey, 'workflows' => $workFlows, 'workflow_key_name' => 'workflow'];
                return rest_ensure_response(['fields' => $data, 'status' => 200, 'code' => 4000, 'success' => true]);
            } else {
                return rest_ensure_response(['fields' => [], 'status' => 200, 'code' => 3920, 'message' => 'No fields available', 'success' => true]);
            }
        }
    }

    private function fieldSanitize($form_fields, $data, $fieldKey)
    {
        $submitted_data = [];
        $message = [];
        unset($data['workflow']);
        foreach ($data as $key => $da) {
            if (!in_array($key, $fieldKey)) {
                $message[$key] = 'No field named ' . $key . ' found.';
            }
        }
        if ([] !== $message) {
            $data = ['message' => $message, 'code' => 3710];
            wp_send_json_success($data, 200);
        }

        foreach ($form_fields as $key => $field) {
            if (array_key_exists($field['key'], $data) && 'file-up' !== $field['type']) {

                if (is_array($data[$field['key']])) {
                    $submitted_data[$field['key']] = array_map('sanitize_text_field', $data[$field['key']]);
                } else {
                    $submitted_data[$field['key']] = sanitize_text_field($data[$field['key']]);
                }
            } elseif (!array_key_exists($field['key'], $data) && 'file-up' !== $field['type']) {
                $submitted_data[$field['key']] = '';
            }
        }
        return $submitted_data;
    }

    private function fieldTypeValidation($form_fields, $data)
    {
        $message = [];
        $string_types = ['text', 'textarea', 'radio', 'color', 'email', 'decision-box', 'gdpr'];
        foreach ($form_fields as $key => $field) {
            if (isset($data[$field['key']])) {
                if ('file-up' === $field['type'] && 'array' !== gettype($data[$field['key']])) {
                    $message[$field['key']] = 'Data type mismatch. Value for the ' . $field['key'] . ' field must be of type FILE';
                } elseif (in_array($field['type'], $string_types) && 'string' !== gettype($data[$field['key']])) {
                    $message[$field['key']] = 'Data type mismatch. Value for the ' . $field['key'] . ' field must be of type STRING';
                } elseif ('check' === $field['type'] && 'array' !== gettype($data[$field['key']])) {
                    $message[$field['key']] = 'Data type mismatch. Value for the ' . $field['key'] . ' field must be of type Array';
                }
            }
        }
        if ([] !== $message) {
            $data = ['message' => $message, 'code' => 3120];
            wp_send_json_success($data, 200);
        }
        return $message;
    }

    public function entry_store($request)
    {
        $formID = $request['form_id'];
        $formManager = new AdminFormManager($request['form_id']);
        if (!$formManager->isExist()) {
            $data = ['message' => 'No Form with ID "<form_id>"', 'code' => '3200'];
            wp_send_json_error($data, 400);
        }
        $requestData = self::getRequestData($request);
        unset($requestData['form_id']);

        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $form_fields = $this->getFields($formID);
        $fieldsKey = $formManager->getFieldsKey();
        $this->fieldTypeValidation($form_fields, $requestData);
        $submitted_data = $this->fieldSanitize($form_fields, $requestData, $fieldsKey);
        $formFieldValidator = new FormFieldValidator($form_fields, $submitted_data, $_FILES);
        $validateField = $formFieldValidator->validate('create', $formID);
        if (!$validateField) {
            $errorMessage = count($formFieldValidator->getMessage()) > 0
                ? $formFieldValidator->getMessage() : __('Internal error occured!!!', 'bitformpro');
            $error = ['errors' => $errorMessage, 'code' => 3070];
            wp_send_json_error($error, 422);
        }
        $entry_id = FormEntry::insertRow(
            [
                'form_id' => $formID,
                'user_id' => $user_details['id'],
                'user_ip' => $user_details['ip'],
                'user_device' => $user_details['device'],
                'referer' => $user_details['page'],
                'status' => 0,
                'created_at' => $user_details['time'],
            ],
        );

        if ($entry_id) {
            $logID =  $formManager->submisionLog($user_details, $entry_id, 'create');
        }
        $submitted_fields = $this->getFormContentWithValue($submitted_data, $formID)->fields;
        $formManageer = new AdminFormManager($formID);
        $file_fields = $formManageer->getUploadFields($formID);
        $fileHandler = new FileHandler();
        $workFlow = new WorkFlow($formID);


        if (!empty($workFlowreturnedOnSubmit['fields'])) {
            $submitted_data = $workFlowreturnedOnSubmit['fields'];
            unset($workFlowreturnedOnSubmit['fields']);
        }
        unset($submitted_data['workflow']);
        foreach ($_FILES as $file_name => $file_details) {
            if ($file_fields && in_array($file_name, $file_fields)) {
                $filePath = $fileHandler->moveUploadedFiles($file_details, $formID, $entry_id);
                if (!empty($filePath)) {
                    $submitted_data[$file_name] = $filePath;
                }
            }
        }
        $submitted_data = self::maskPasswordValues($submitted_data, self::passwordFieldKeys($form_fields));
        foreach ($submitted_data as $key => $value) {
            FormEntryMeta::insertRow(
                [
                    'bitforms_form_entry_id' => $entry_id,
                    'meta_key' => $key,
                    'meta_value' => is_string($submitted_data[$key])
                        ? $submitted_data[$key]
                        : JSON::encode($submitted_data[$key]),
                ],
            );
        }


        if (isset($requestData['workflow'])) {
            $workFlowIds = self::decodeIfJson($requestData['workflow']);
            $workFlowIds = is_array($requestData['workflow'])
                ? array_map('intval', $requestData['workflow'])
                : array_map('intval', explode(',', $requestData['workflow']));

            $workFlowreturnedOnSubmit = $workFlow->executeOnSubmit(
                'create',
                $submitted_fields,
                $submitted_data,
                $entry_id,
                $logID,
                $workFlowIds,
            );
            $response = IntegrationHandler::maybeSetCronForIntegration($workFlowreturnedOnSubmit, 'create', false);
            unset($workFlowreturnedOnSubmit['data']);
        }
        return rest_ensure_response(['status' => 200, 'code' => 4000, 'message' => 'Data Added Successfully!!', 'success' => true]);
    }

    public function getFormContentWithValue($defaultValues, $formID)
    {
        $formContentRow = Utility::firstRow($this->form_content($formID));
        $form_content = Utility::jsonObj($formContentRow->form_content ?? '');
        if (!is_array($defaultValues)) {
            return $form_content;
        }
        foreach (($form_content->fields ?? []) as $fieldKey => $fieldDetails) {
            // $field_name = empty($fieldDetails->lbl) ? null : \preg_replace('/[\`\~\!\@\#\$\'\.\s\?\+\-\*\&\|\/\\!]/', '_', $fieldDetails->lbl);
            if ((isset($fieldDetails->mul) || 'check' === $fieldDetails->typ) && isset($defaultValues[$fieldKey])) {
                if (is_array($defaultValues[$fieldKey])) {
                    $fieldDetails->val
                        = JSON::encode(
                            array_map('sanitize_text_field', $defaultValues[$fieldKey]),
                        );
                } else {
                    $fieldDetails->val = sanitize_text_field($defaultValues[$fieldKey]);
                }
            } elseif (isset($defaultValues[$fieldKey])) {
                $fieldDetails->val = is_string($defaultValues[$fieldKey])
                    ? sanitize_text_field($defaultValues[$fieldKey])
                    : sanitize_text_field($defaultValues[$fieldKey][count($defaultValues[$fieldKey]) - 1]);
            }
        }
        return $form_content;
    }

    public function getFields($formID)
    {
        if (!is_null($this->_fields)) {
            return $this->_fields;
        }
        $formContentRow = Utility::firstRow($this->form_content($formID));
        $form_content = Utility::jsonObj($formContentRow->form_content ?? '');
        $fields = $form_content->fields ?? [];
        $field_details = [];
        foreach ($fields as $key => $field) {
            if ('recaptcha' === $field->typ || 'hcaptcha' === $field->typ || 'turnstile' === $field->typ) {
                continue;
            }
            $field_type = $field->typ;
            $field_details[$key]['label'] = empty($field->lbl) ? null : $field->lbl;
            $field_details[$key]['type'] = $field_type;
            $field_details[$key]['key'] = $key;
            if (isset($field->mul)) {
                $field_details[$key]['mul'] = $field->mul;
            }
            if ('file-up' === $field_type && isset($field->exts)) {
                $field_details[$key]['valid']['type'] = $field->exts;
            }
            if (isset($field->valid) && !is_null($field->valid)) {
                if (isset($field->valid->req)) {
                    $field_details[$key]['valid']['req'] = $field->valid->req;
                }
                if (isset($field->valid->reqMsg)) {
                    $field_details[$key]['valid']['reqMsg'] = $field->valid->reqMsg;
                }
                if (isset($field->valid->typMsg)) {
                    $field_details[$key]['valid']['typMsg'] = $field->valid->typMsg;
                }
            }
        }
        $unset_types = ['razorpay', 'paypal', 'recaptcha', 'hcaptcha', 'turnstile'];

        foreach ($field_details as $key => $field) {
            if (in_array($field['type'], $unset_types)) {
                unset($field_details[$key]);
            }
        }
        $this->_fields = $field_details;
        return $field_details;
    }

    public function entry_update($request)
    {
        $entryID = $request['entry_id'];
        if ('PUT' === $_SERVER['REQUEST_METHOD']) {
            $requestData = $request->get_params();
            unset($requestData['entry_id']);
        } else {
            $requestData = $_POST;
        }
        $forms = FormEntry::rowsWhere(['id' => (int) $entryID], ['form_id']);
        if ([] === $forms) {
            $data = ['message' => 'No record with ID "<entry_id>".', 'code' => '3100'];
            wp_send_json_error($data, 404);
        }
        $formID = $forms[0]->form_id;
        $formOldData = FormEntryMeta::rowsWhere(['bitforms_form_entry_id' => (int) $entryID], ['meta_key', 'meta_value']);
        $key = null;
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $form_fields = $this->getFields($formID);
        $field_map = [];
        foreach ($formOldData as $data) {
            foreach ($form_fields as $field_key => $field) {
                if ($data->meta_key === $field['key']) {
                    $field_map[$field_key] = $field['key'];
                }
            }
        }
        $this->fieldTypeValidation($form_fields, $requestData);
        $formManageer = new AdminFormManager($formID);
        $fieldsKey = $formManageer->getFieldsKey();
        $updatedValue = $this->fieldSanitize($form_fields, $requestData, $fieldsKey);
        $passwordKeys = self::passwordFieldKeys($form_fields);
        $changedPasswordKeys = [];
        foreach ($passwordKeys as $passwordKey) {
            // Blank or masked keeps the stored password; a new one is stored masked.
            if (isset($updatedValue[$passwordKey]) && is_string($updatedValue[$passwordKey]) && '' !== $updatedValue[$passwordKey] && self::PASSWORD_MASK !== $updatedValue[$passwordKey]) {
                $changedPasswordKeys[] = $passwordKey;
            } else {
                unset($updatedValue[$passwordKey]);
            }
        }
        $updatedValue = self::maskPasswordValues($updatedValue, $changedPasswordKeys);
        $formFieldValidator = new FormFieldValidator($form_fields, $requestData, $_FILES);
        $validateField = $formFieldValidator->validate('edit', $formID);
        if (!$validateField) {
            $errorMessage = count($formFieldValidator->getMessage()) > 0
                ? $formFieldValidator->getMessage() : __('Internal error occured !!!', 'bitformpro');
            $error = ['errors' => $errorMessage, 'code' => 3070];
            wp_send_json_error($error, 422);
        }
        $formEntry = FormEntry::updateWhere(
            ['form_id' => $formID, 'id' => $entryID],
            [
                'user_id' => $user_details['id'],
                'user_ip' => $user_details['ip'],
                'user_device' => $user_details['device'],
                'status' => 0,
                'updated_at' => $user_details['time'],
            ],
        );
        $log_id = null;
        if ($formEntry) {
            // The device array is stored as JSON; the legacy insert could not bind an
            // array and stored an empty string, losing the device.
            $log_id = FormEntryLog::insertRow(
                [
                    'user_id' => $user_details['id'],
                    'action_type' => 'update',
                    'log_type' => 'entry',
                    'ip' => $user_details['ip'],
                    'form_entry_id' => $entryID,
                    'form_id' => $formID,
                    'content' => ['user_device' => $user_details['device']],
                    'created_at' => $user_details['time'],
                ],
            );
        }
        if (is_wp_error($formEntry) || !$formEntry) {
            $data = ['message' => 'No record with ID "<entry_id>', 'code' => '3100'];
            wp_send_json_error($data, 404);
        }
        $file_fields = $this->getUploadFields($formID);
        if (count($file_fields) > 0) {
            $fileHandler = new FileHandler();
            foreach ($file_fields as $file_name) {
                if (!empty($_FILES[$file_name]['name'])) {
                    $meta_value = $fileHandler->moveUploadedFiles($_FILES[$file_name], $formID, $entryID);
                    if (!empty($meta_value)) {
                        $updatedValue[$file_name] = JSON::encode($meta_value);
                    }
                }
            }
        }
        unset($updatedValue['_ajax_nonce'], $_REQUEST['g-recaptcha-response']);

        $workFlow = new WorkFlow($formID);
        if (isset($requestData['workflow'])) {
            $workFlowIds = is_array($requestData['workflow'])
                ? array_map('intval', $requestData['workflow'])
                : array_map('intval', explode(',', $requestData['workflow']));
            $workFlowreturnedOnSubmit = $workFlow->executeOnSubmit(
                'edit',
                $this->getFormContentWithValue($updatedValue, $formID)->fields,
                $updatedValue,
                $entryID,
                $log_id,
                $workFlowIds,
            );
            if (!empty($workFlowreturnedOnSubmit['fields'])) {
                $updatedValue = $workFlowreturnedOnSubmit['fields'];
                unset($workFlowreturnedOnSubmit['fields']);
            }
        }
        $formEntryMetaUpdateStatus = FormEntryMeta::updateValuesOfEntry($entryID, $updatedValue);
        if (is_wp_error($formEntryMetaUpdateStatus)) {
            return $formEntryMetaUpdateStatus;
        }
        $updatedValue = array_merge($formEntryMetaUpdateStatus, ['entry_id' => $entryID]);
        if (empty($workFlowreturnedOnSubmit['message'])) {
            $workFlowreturnedOnSubmit['message'] = __('Entry Updated Successfully', 'bitformpro');
        }
        $workFlowreturnedOnSubmit['updatedData'] = $updatedValue;
        $counter = 0;
        for ($i = 0; $i < count($formOldData); $i++) {
            if (array_key_exists($formOldData[$i]->meta_key . '_old', $updatedValue)) {
                unset($updatedValue[$formOldData[$i]->meta_key . '_old']);
            }
            if (in_array($formOldData[$i]->meta_key, $file_fields)) {
                if (
                    empty($_FILES[$formOldData[$i]->meta_key]['name'])
                    || (is_array($_FILES[$formOldData[$i]->meta_key]['name'])
                        && 1 === count($_FILES[$formOldData[$i]->meta_key]['name'])
                        && empty($_FILES[$formOldData[$i]->meta_key]['name'][0]))
                ) {
                    unset($updatedValue[$formOldData[$i]->meta_key]);
                    continue;
                }
                if (is_array($_FILES[$formOldData[$i]->meta_key]['name']) && !in_array($_FILES[$formOldData[$i]->meta_key]['name'], JSON::decode($formOldData[$i]->meta_value))) {
                    $key[$i] = '${' . $formOldData[$i]->meta_key . '} file was Updated  To ' . json_encode($_FILES[$formOldData[$i]->meta_key]['name']);
                } elseif (!is_array($_FILES[$formOldData[$i]->meta_key]['name']) && !in_array($_FILES[$formOldData[$i]->meta_key]['name'], JSON::decode($formOldData[$i]->meta_value))) {
                    $key[$i] = '${' . $formOldData[$i]->meta_key . '} file was Updated  To ' . $_FILES[$formOldData[$i]->meta_key]['name'];
                }
                unset($updatedValue[$formOldData[$i]->meta_key]);
            } elseif (in_array($formOldData[$i]->meta_key, $passwordKeys, true)) {
                // Log that a password changed, never the old or new value.
                if (in_array($formOldData[$i]->meta_key, $changedPasswordKeys, true)) {
                    $key[$i] = '${' . $formOldData[$i]->meta_key . '} was Updated';
                }
            } else {
                if (isset($updatedValue[$formOldData[$i]->meta_key])) {
                    if (is_array($updatedValue[$formOldData[$i]->meta_key])) {
                        if (JSON::decode($formOldData[$i]->meta_value) !== $updatedValue[$formOldData[$i]->meta_key]) {
                            $key[$i] = '${' . $formOldData[$i]->meta_key . '} was Updated From ' . implode(',', JSON::decode($formOldData[$i]->meta_value)) . ' To ' . implode(',', $updatedValue[$formOldData[$i]->meta_key]);
                        }
                    } elseif (is_string($updatedValue[$formOldData[$i]->meta_key]) && !FieldValueHandler::isEmpty($updatedValue[$formOldData[$i]->meta_key])) {
                        if ($formOldData[$i]->meta_value !== $updatedValue[$formOldData[$i]->meta_key]) {
                            $key[$i] = '${' . $formOldData[$i]->meta_key . '} was Updated' . ($formOldData[$i]->meta_value ? ' From ' . $formOldData[$i]->meta_value : '') . ' To ' . $updatedValue[$formOldData[$i]->meta_key];
                        }
                    }
                }
            }
            $counter++;
        }
        $newField = array_keys(array_diff_key($formEntryMetaUpdateStatus, $field_map));
        for ($i = 0; $i < count($newField); $i++) {
            if (in_array($newField[$i], $passwordKeys, true)) {
                $key[$counter + $i] = '${' . $newField[$i] . '} Updated';
            } elseif (is_array($updatedValue[$newField[$i]]) && !FieldValueHandler::isEmpty($updatedValue[$newField[$i]])) {
                $key[$counter + $i] = '${' . $newField[$i] . '} Updated To ' . implode(',', $updatedValue[$newField[$i]]);
            } elseif (is_string($newField[$i]) && !FieldValueHandler::isEmpty($updatedValue[$newField[$i]])) {
                $key[$counter + $i] = '${' . $newField[$i] . '} Updated To ' . $updatedValue[$newField[$i]];
            }
        }
        if (null !== $key) {
            $logUpdate = implode('b::f', (array) $key);
            FormEntryLog::updateContent($log_id, $logUpdate);
        }
        return rest_ensure_response(['status' => 200, 'code' => 4000, 'message' => 'Data Updated Successfully', 'success' => true]);
    }

    /**
     * Same text Free stores for passwords. Kept here, not read from Free, because Pro
     * can run against an older Free.
     */
    private const PASSWORD_MASK = '**** (encrypted)';

    /**
     * @param array $form_fields Fields from getFields()
     * @return string[]
     */
    private static function passwordFieldKeys($form_fields)
    {
        $keys = [];
        foreach ((array) $form_fields as $field) {
            if (isset($field['type'], $field['key']) && 'password' === $field['type']) {
                $keys[] = $field['key'];
            }
        }
        return $keys;
    }

    /**
     * Masks password values (leaf by leaf for repeated rows) so the REST API never stores one.
     *
     * @param mixed    $data         the entry values; anything but an array is returned as it is
     * @param string[] $passwordKeys
     * @return mixed
     */
    private static function maskPasswordValues($data, $passwordKeys)
    {
        if (!is_array($data)) {
            return $data;
        }
        $mask = static function ($value) use (&$mask) {
            if (is_array($value)) {
                return array_map($mask, $value);
            }
            return (null === $value || '' === $value) ? $value : self::PASSWORD_MASK;
        };
        foreach ($passwordKeys as $passwordKey) {
            if (array_key_exists($passwordKey, $data)) {
                $data[$passwordKey] = $mask($data[$passwordKey]);
            }
        }
        return $data;
    }

    public function getUploadFields($formID)
    {
        if (!is_null($this->_has_upload)) {
            return $this->_has_upload;
        }
        $upload_fields = [];
        $form_field_details = $this->getFields($formID);
        foreach ($form_field_details as $field_name => $__field_detail) {
            if (isset($__field_detail['type']) && 'file-up' === $__field_detail['type']) {
                $upload_fields[] = $field_name;
            }
        }
        $this->_has_upload = $upload_fields;
        return $upload_fields;
    }

    public function entry_delete($request)
    {
        $entries = [];
        $entries['entry_id'] = $request['entry_id'];
        $forms = FormEntry::rowsWhere(['id' => (int) $entries['entry_id']], ['form_id']);
        if ([] === $forms) {
            $data = ['message' => 'No record with ID "<entry_id>".', 'code' => '3100'];
            wp_send_json_error($data, 404);
        }
        $formID = $forms[0]->form_id;
        $formManager = new AdminFormManager($formID);
        if (!$formManager->isExist()) {
            $data = ['message' => 'No form found. Please check and try again', 'code' => '3130'];
            wp_send_json_error($data, 404);
        }
        $workFlow = new WorkFlow($formID);
        $workFlowreturnedOnDelete = $workFlow->executeOnDelete(
            $formManager,
            $formID,
            $entries,
        );
        $result = [];
        if (isset($workFlowreturnedOnDelete['entries'])) {
            if (0 === count($workFlowreturnedOnDelete['entries'])) {
                return ['message' => __('Entry Deletetion prevented by  workflow', 'bitformpro')];
            } elseif (count($workFlowreturnedOnDelete['entries']) === count($entries)) {
                $message = __('Entry Deleted successfully', 'bitformpro');
            } else {
                $result['prevented'] = array_diff($entries, $workFlowreturnedOnDelete['entries']);
                $entries = $workFlowreturnedOnDelete['entries'];
                $message = __('Entry Deleted successfully, Some prevented by workflow', 'bitformpro');
            }
        } else {
            $message = __('Entry Deleted successfully', 'bitformpro');
        }
        $deleted = FormEntry::deleteEntries($formID, $entries);
        if ($deleted) {
            FormEntry::deleteRelatedRowsOfEntries($entries);
        }
        if (file_exists(BITFORMS_UPLOAD_DIR . DIRECTORY_SEPARATOR . $formID)) {
            $fileHandler = new FileHandler();
            foreach ($entries as $entryID) {
                // Upload dirs are named by an encrypted entry id; the resolver also finds legacy plain-id dirs.
                $fileEntries = FileHandler::getEntriesFileUploadDir($formID, $entryID);
                if (file_exists($fileEntries)) {
                    $fileHandler->rmrf($fileEntries);
                }
            }
        }
        $formManager->resetSubmissionCount(FormEntry::countOfForm($formID));
        // No entry deleted (or a failed query) is answered as a failure, as before.
        if (!$deleted) {
            return new WP_Error('entry_not_exists', __('Form entry deletion failed', 'bitformpro'));
        }
        $result['message'] = $message;
        return rest_ensure_response(['status' => 200, 'code' => 4000, 'message' => $message, 'success' => true]);
    }

    public function entry_view($request)
    {
        $entryID = $request['entry_id'];
        $forms = FormEntry::rowsWhere(['id' => (int) $entryID], ['form_id']);
        if ([] === $forms) {
            $data = ['message' => 'No record with ID "<entry_id>".', 'code' => '3100'];
            wp_send_json_error($data, 404);
        }
        $formID = $forms[0]->form_id;
        $formManager = new AdminFormManager($formID);
        if (!$formManager->isExist()) {
            $data = ['message' => 'No form was found. Please check and try again', 'code' => 3130];
            wp_send_json_error($data, 404);
        }
        $formEntry = FormEntry::readWhere(['form_id' => $formID, 'id' => $entryID]);
        if (!$formEntry) {
            $data = ['message' => 'No Entry with ID"', 'code' => 3100];
            wp_send_json_error($data, 404);
        }
        $formEntryMeta = FormEntryMeta::readWhere(['bitforms_form_entry_id' => $entryID], ['meta_key', 'meta_value']);
        $formContent = $formManager->getFormContent();
        $fieldsKey = $formManager->getFieldsKey();
        $form_fields = $formContent->fields;
        $entries = [];
        $webPath = Helpers::getWebPathWithEncryptedEntryId($formID, $entryID);
        foreach ($formEntryMeta as $key => $value) {
            $entries[$value->meta_key] = $value->meta_value;
        }


        foreach ($form_fields as $key => $value) {
            // $field_name = preg_replace('/[\`\~\!\@\#\$\'\.\s\?\+\-\*\&\|\/\\!]/', '_', $value->lbl);
            if (isset($entries[$key])) {
                $fldType = $form_fields->{$key}->typ;
                if (in_array($fldType, ['file-up', 'advanced-file-up', 'signature'])) {
                    $raw =  $entries[$key];
                    $value = self::decodeIfJson($raw);
                    if (is_array($value)) {
                        $fileUrls = [];
                        foreach ($value as $file) {
                            $fileUrls[] =  rtrim($webPath, '/') . DIRECTORY_SEPARATOR . ltrim($file, '/');
                        }
                        $form_fields->{$key}->val = $fileUrls;
                    } else {
                        $form_fields->{$key}->val = rtrim($webPath, '/') . DIRECTORY_SEPARATOR . ltrim($value, '/');
                    }
                } elseif ($fldType === 'repeater') {
                    $repeaterFldValue = self::decodeIfJson($entries[$key]);

                    $repeaterFldValue = self::handleRepeaterFileUrl($form_fields, $repeaterFldValue, $webPath);
                    $form_fields->{$key}->val = json_encode($repeaterFldValue);
                } else {
                    $form_fields->{$key}->val = $entries[$key];
                }
                $form_fields->{$key}->name = $key;
            }
        }

        $formData = [
            'fields' => $form_fields,
            'fieldsKey' => $fieldsKey,
        ];
        return rest_ensure_response(['data' => $formData, 'status' => 200, 'success' => true]);
    }



    public function getEntryResponse($request)
    {
        $formId = wp_unslash($request['id']);
        $limit = !empty($request['per_page']) ? wp_unslash($request['per_page']) : 200;
        if ($limit > 200) {
            $data = ['message' => 'A maximum of 200 records can be fetched per request', 'code' => 3970];
            wp_send_json_success($data, 200);
        }
        $offset = !empty($request['page']) ? wp_unslash($request['page']) : null;
        $formManager = new AdminFormManager($formId);
        if (!$formManager->isExist()) {
            $data = ['message' => 'No form was found. Please check and try again', 'code' => 3130];
            wp_send_json_error($data, 404);
        }
        // Trashed entries are left out here as well as in the pivot below. The
        // pivot already filtered them, so the rows were right; the ids were not,
        // which made this fetch — and the paging over it — larger than the result.
        $entries = EntryTableQuery::entryIds(['form_id' => $formId], ['trash' => 'active']);
        if (is_wp_error($entries)) {
            if ('result_empty' === $entries->get_error_code()) {
                return rest_ensure_response(['data' => [], 'status' => 200, 'message' => 'form is empty', 'success' => true]);
            }
            return $entries;
        }
        $formFields = $formManager->getFieldLabel(true);
        $formEntries = EntryTableQuery::entryRows($formFields, $entries, $limit, $offset);
        foreach ($formFields as $field) {
            foreach ($formEntries['entries'] as $entry) {
                if (isset($field['key']) &&  in_array($field['type'], ['file-up', 'advanced-file-up', 'signature'])) {

                    $entryID = $entry->entry_id;
                    $webPath = Helpers::getWebPathWithEncryptedEntryId($formId, $entryID);
                    $key = $field['key'];
                    if (!isset($entry->$key)) {
                        continue;
                    }
                    if (is_array(JSON::decode($entry->$key))) {
                        $fileData = [];
                        foreach (JSON::decode($entry->$key) as $file) {
                            $path = rtrim($webPath, '/') . DIRECTORY_SEPARATOR . ltrim($file, '/');
                            $fileData[] = $path;
                        }
                        $entry->$key = JSON::encode($fileData, JSON_UNESCAPED_SLASHES);
                    } elseif ($entry->$key) {
                        $entry->$key = rtrim($webPath, '/') . DIRECTORY_SEPARATOR . ltrim($entry->$key, '/');
                    }
                } elseif (isset($field['key']) && 'repeater' === $field['type']) {
                    $entryID = $entry->entry_id;
                    $webPath = Helpers::getWebPathWithEncryptedEntryId($formId, $entryID);
                    $key = $field['key'];
                    if (!isset($entry->$key)) {
                        continue;
                    }
                    $repeaterFldValue = JSON::decode($entry->$key, true);
                    $repeaterFldValue = self::handleRepeaterFileUrl($formManager->getFormContent()->fields, $repeaterFldValue, $webPath);
                    $entry->$key = json_encode($repeaterFldValue, JSON_UNESCAPED_SLASHES);
                }
            }
        }
        return rest_ensure_response(['data' => $formEntries, 'status' => 200, 'success' => true]);
    }


    private static function handleRepeaterFileUrl($form_fields, $repeaterFldValue, $webPath)
    {
        if (is_array($repeaterFldValue)) {
            foreach ($repeaterFldValue as $rowIndex => $rowData) {
                foreach ($rowData as $fieldKey => $fieldValue) {
                    if (isset($form_fields->{$fieldKey})) {
                        $repeatedFldType = $form_fields->{$fieldKey}->typ;
                        if (in_array($repeatedFldType, ['file-up', 'advanced-file-up', 'signature'])) {
                            if (is_array($fieldValue)) {
                                $fileUrls = [];
                                foreach ($fieldValue as $file) {
                                    $fileUrls[] = rtrim($webPath, '/') . DIRECTORY_SEPARATOR . ltrim($file, '/');
                                }
                                $repeaterFldValue[$rowIndex][$fieldKey] = $fileUrls;
                            } else {
                                $repeaterFldValue[$rowIndex][$fieldKey] = rtrim($webPath, '/') . DIRECTORY_SEPARATOR . ltrim($fieldValue, '/');
                            }
                        }
                    }
                }
            }
        }
        return $repeaterFldValue;
    }

    private static function decodeIfJson($data)
    {
        if (!is_string($data)) {
            return $data;
        }

        $decoded = JSON::decode($data, true);

        return (JSON_ERROR_NONE === json_last_error()) ? $decoded : $data;
    }


    private static function getRequestData($request)
    {
        $contentType = $request->get_content_type()['value'] ?? '';

        if (strpos($contentType, 'application/json') !== false) {
            return $request->get_json_params();
        } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false || strpos($contentType, 'multipart/form-data') !== false) {
            return $request->get_body_params();
        } else {
            return $request->get_params();
        }
    }
}
