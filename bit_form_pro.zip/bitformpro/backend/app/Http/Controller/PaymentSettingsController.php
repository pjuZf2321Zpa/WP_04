<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Model\PaymentInfoModel;
use BitApps\BitForm\Services\Form\FormHandler;
use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetPaymentDetailsRequest;
use BitApps\BitFormPro\Http\Requests\GetRazorpayTransactionRequest;
use BitApps\BitFormPro\Http\Requests\SavePaymentSettingsRequest;

/**
 * Payment records and gateway settings.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class PaymentSettingsController
{
    private $paymentModel;

    public function __construct()
    {
        $this->paymentModel = new PaymentInfoModel();
    }

    /** Was AdminAjax::paymentDetails(). */
    public function show(GetPaymentDetailsRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $queryParams = json_decode($inputJSON);

        $queryParams = $request->decodedOr400();

        if (isset($queryParams->formID) && isset($queryParams->transactionID)) {
            $formID = wp_unslash($queryParams->formID);
            $transactionID = wp_unslash($queryParams->transactionID);
            $paymentDetail = $this->paymentModel->paymentDetail($formID, $transactionID);

            if (is_wp_error($paymentDetail)) {
                return Response::error($paymentDetail->get_error_message(), 411);
            } else {
                return Response::success($paymentDetail);
                return $paymentDetail;
            }
        }
    }

    /** Was AdminAjax::getRazorpayTransactionInfo(). */
    public function razorpayTransaction(GetRazorpayTransactionRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $queryParams = json_decode($inputJSON);

        $queryParams = $request->decodedOr400();

        if (isset($queryParams->formID) && isset($queryParams->transactionID)) {
            $defaultHeader = [];
            $transactionID = wp_unslash($queryParams->transactionID);
            $razorpaySettings = $queryParams->razorpaySettings;

            $token = base64_encode("{$razorpaySettings->apiKey}:{$razorpaySettings->apiSecret}");
            $defaultHeader['Authorization'] = "Basic {$token}";
            $requestEndpoint = "https://api.razorpay.com/v1/payments/{$transactionID}";
            $razorpayResponse = HttpHelper::get($requestEndpoint, null, $defaultHeader);

            if (!is_wp_error($razorpayResponse) && $razorpayResponse->error_code == null && !isset($razorpayResponse->error)) {
                return Response::success($razorpayResponse);
            } else {
                return Response::error($razorpayResponse, 411);
            }
        }
    }

    /** Was AdminAjax::savePaymentSetting(). */
    public function saveSettings(SavePaymentSettingsRequest $request)
    {
        $input = $request->decodedOr400();

        $formHandler = FormHandler::getInstance();
        $status = $formHandler->admin->savePaymentSetting($_REQUEST, $input);
        if (is_wp_error($status)) {
            return Response::error($status->get_error_message(), 411);
        } else {
            return Response::success($status);
        }
    }
}
