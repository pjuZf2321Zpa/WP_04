<?php

namespace BitApps\BitFormPro\Http\Controller;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitFormPro\Model\EntryRelatedInfoModel;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Http\Requests\GetEntryNotesRequest;
use BitApps\BitFormPro\Http\Requests\CreateEntryNoteRequest;
use BitApps\BitFormPro\Http\Requests\UpdateEntryNoteRequest;
use BitApps\BitFormPro\Http\Requests\DeleteEntryNoteRequest;

/**
 * Entry notes on the admin entry view.
 *
 * Handlers moved from AdminAjax. The nonce, capability and
 * POST-only preamble each repeated is declared per route in
 * backend/hooks/ and applied by the middleware pipeline.
 */
final class NoteController
{
    private $infoModel;

    public function __construct()
    {
        $this->infoModel = new EntryRelatedInfoModel();
    }

    /** Was AdminAjax::getNotes(). */
    public function index(GetEntryNotesRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $queryParams = json_decode($inputJSON);

        $queryParams = $request->decodedOr400();

        if (isset($queryParams->formID) && isset($queryParams->entryID)) {
            $formID = wp_unslash($queryParams->formID);
            $entryID = wp_unslash($queryParams->entryID);
        }
        $allNotes = $this->infoModel->getAllNotes($formID, $entryID);
        if (is_wp_error($allNotes)) {
            return Response::error($allNotes->get_error_message(), 411);
        }

        return Response::success($this->withAuthorNames($allNotes));
    }

    /**
     * Resolve who wrote and who last edited each note to display names.
     *
     * `user_id` is the author (set on insert). The editor is kept inside
     * `info_details` as `updated_by`, because the table has no column for it
     * and a schema change for one display string is not worth a migration.
     * One get_users() call for the whole list, not one per note.
     *
     * @param array $notes stdClass rows
     *
     * @return array the same rows with `author` and `editor` added ('' when unknown)
     */
    private function withAuthorNames(array $notes)
    {
        $ids = [];
        foreach ($notes as $note) {
            $ids[] = (int) ($note->user_id ?? 0);
            $details = json_decode((string) ($note->info_details ?? ''), true);
            $ids[] = (int) ($details['updated_by'] ?? 0);
        }
        $ids = array_values(array_unique(array_filter($ids)));
        $names = [];
        if ($ids) {
            foreach (get_users(['include' => $ids, 'fields' => ['ID', 'display_name']]) as $user) {
                $names[(int) $user->ID] = (string) $user->display_name;
            }
        }
        foreach ($notes as $note) {
            $details = json_decode((string) ($note->info_details ?? ''), true);
            $note->author = $names[(int) ($note->user_id ?? 0)] ?? '';
            $note->editor = $names[(int) ($details['updated_by'] ?? 0)] ?? '';
        }

        return $notes;
    }

    /** Was AdminAjax::insertNote(). */
    public function store(CreateEntryNoteRequest $request)
    {
        Utility::ignoreUserAbort();
        if (isset($_REQUEST['formID']) && isset($_REQUEST['entryID'])) {
            $formID = sanitize_text_field(wp_unslash($_REQUEST['formID']));
            $entryID = sanitize_text_field(wp_unslash($_REQUEST['entryID']));
            $details = [];
            $details['title'] = sanitize_text_field(wp_unslash($_REQUEST['title']));
            $details['content'] = sanitize_text_field(wp_unslash($_REQUEST['content']));
            $note_details = json_encode(wp_unslash($details));
        }
        $details = $this->infoModel->insertNote($formID, $entryID, $note_details);
        return Response::success($details);
    }

    /** Was AdminAjax::updateNote(). */
    public function update(UpdateEntryNoteRequest $request)
    {
        Utility::ignoreUserAbort();
        if (isset($_REQUEST['noteID'])) {
            $noteID = sanitize_text_field(wp_unslash($_REQUEST['noteID']));
            $formID = sanitize_text_field(wp_unslash($_REQUEST['formID']));
            $entryID = sanitize_text_field(wp_unslash($_REQUEST['entryID']));
            $details = [];
            $details['title'] = sanitize_text_field(wp_unslash($_REQUEST['title']));
            $details['content'] = sanitize_text_field(wp_unslash($_REQUEST['content']));
            // Who edited, for the note's byline; the author stays in `user_id`.
            $details['updated_by'] = get_current_user_id();
            $note_details = json_encode(wp_unslash($details));
        }
        $details = $this->infoModel->updateNote($noteID, $formID, $entryID, $note_details);
        return Response::success($details);
    }

    /** Was AdminAjax::deleteNote(). */
    public function destroy(DeleteEntryNoteRequest $request)
    {
        // $inputJSON = wp_unslash($_POST['data']);
        // $queryParams = json_decode($inputJSON);

        $queryParams = $request->decodedOr400();

        if (isset($queryParams->noteID)) {
            $noteID = wp_unslash($queryParams->noteID);
            $formID = wp_unslash($queryParams->formID);
            $entryID = wp_unslash($queryParams->entryID);
        }
        $details = $this->infoModel->deleteNote($noteID, $formID, $entryID);
        return Response::success($details);
    }
}
