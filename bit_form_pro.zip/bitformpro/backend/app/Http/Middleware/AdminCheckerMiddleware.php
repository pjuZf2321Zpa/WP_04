<?php

namespace BitApps\BitFormPro\Http\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;

/**
 * Only someone who may manage Bit Form gets through — `manage_bitform`, or
 * `manage_options` for a site administrator without the plugin's own capability.
 * As in bit-connect, and the one definition of that rule in Pro: the route
 * tables run it as `isAdmin`, HookProvider asks allows() before binding them.
 *
 * On a route it is the second gate, not the first: HookProvider only builds the
 * admin route tables for a user who already passes allows(). This catches the
 * capability being lost between registration and dispatch, and enforces the
 * narrower `manage_options` the theme and address-key routes require
 * (`isAdmin:manage_options`).
 */
final class AdminCheckerMiddleware
{
    /**
     * @param string|null $capability
     *
     * @return true|Response
     */
    public function handle($request = null, $capability = null)
    {
        $allowed = null !== $capability ? Capabilities::check($capability) : self::allows();

        if ($allowed) {
            return true;
        }

        return Response::error(__('Insufficient permissions.', 'bitformpro'), 403)->code('FORBIDDEN');
    }

    /**
     * Whether the current user may manage Bit Form.
     *
     * @return bool
     */
    public static function allows()
    {
        return Capabilities::check('manage_bitform') || Capabilities::check('manage_options');
    }
}
