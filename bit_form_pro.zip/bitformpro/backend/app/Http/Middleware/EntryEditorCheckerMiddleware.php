<?php

namespace BitApps\BitFormPro\Http\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;

/**
 * Only someone who may edit submitted entries gets through: a Bit Form
 * administrator (AdminCheckerMiddleware), or a user granted `bitform_entry_edit`.
 * Guards the entry PDF download; as route middleware it is `isEntryEditor`.
 */
final class EntryEditorCheckerMiddleware
{
    /**
     * @param mixed $request the wp-kit request (unused; part of the contract)
     *
     * @return true|Response
     */
    public function handle($request = null)
    {
        if (self::allows()) {
            return true;
        }

        return Response::error(__('Insufficient permissions.', 'bitformpro'), 403)->code('FORBIDDEN');
    }

    /**
     * @return bool
     */
    public static function allows()
    {
        return AdminCheckerMiddleware::allows() || Capabilities::check('bitform_entry_edit');
    }
}
