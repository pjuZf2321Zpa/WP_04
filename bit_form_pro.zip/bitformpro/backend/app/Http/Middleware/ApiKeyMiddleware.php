<?php

namespace BitApps\BitFormPro\Http\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Helpers\LicenseHelper;
use WP_Error;

/**
 * The `bitform/v1` data API's guard: a licensed Pro, and the site's secret API
 * key in the `Bitform-Api-Key` header.
 *
 * Used as the `permission_callback` of the API routes in backend/hooks/api.php,
 * so it answers the way WordPress expects there — `true` or a 401 WP_Error —
 * rather than with a wp-kit Response: those routes are registered natively and
 * their replies are external contracts (API-key clients, Bit Integrations).
 */
final class ApiKeyMiddleware
{
    /**
     * @param \WP_REST_Request $request
     *
     * @return true|WP_Error
     */
    public function handle($request)
    {
        $integrateData = LicenseHelper::getLicenseData();
        $header = $request->get_header('Bitform-Api-Key');
        $api_key = get_option('bitform_secret_api_key');
        $error = '';

        if (empty($header)) {
            $error = 'Api Key is required to access this resource';
        } elseif (!is_array($integrateData) && !isset($integrateData['key'])) {
            $error = 'Bitform pro License Key is Invalid';
        } elseif (!is_string($api_key) || '' === $api_key || !hash_equals($api_key, $header)) {
            $error = 'Invalid API key';
        }

        if (!empty($error)) {
            return new WP_Error('bitform_rest_forbidden', $error, ['status' => 401]);
        }

        return true;
    }
}
