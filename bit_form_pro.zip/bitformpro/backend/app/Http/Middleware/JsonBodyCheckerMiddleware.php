<?php

namespace BitApps\BitFormPro\Http\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;

/**
 * The admin's request body, when it sends one, must be readable.
 *
 * The admin posts one `data` field holding a JSON document. Controllers that read
 * their input from validated() do not decode it themselves, so a malformed one is
 * refused here — `jsonBody` on Pro's admin groups — with the 400 every handler
 * used to send. A request without `data` (file uploads, GET reads) passes.
 * Bit Form (free) has the same middleware for its own routes.
 */
final class JsonBodyCheckerMiddleware
{
    /**
     * @return true|Response
     */
    public function handle(Request $request)
    {
        if (!$request->has('data')) {
            return true;
        }

        $data = $request->get('data');
        if (!\is_string($data)) {
            return true; // already decoded: a JSON request body
        }

        JSON::decode($data);
        if (JSON_ERROR_NONE === json_last_error()) {
            return true;
        }

        return Response::error('Invalid JSON provided in data.', 400)->code('INVALID_JSON');
    }
}
