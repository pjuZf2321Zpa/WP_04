<?php

namespace BitApps\BitFormPro\Http\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Response;

/**
 * The `_ajax_nonce` check every Pro admin handler used to repeat inline.
 *
 * wp-kit middleware contract: return `true` to let the request through; any
 * Response returned instead is sent as the reply and the handler never runs.
 * The admin reads the `{status:"error", data:"Token expired"}` envelope through
 * Free's frontend-dev/src/Utils/normalizeAjaxReply.js.
 *
 * Pro's own class rather than Free's: Pro supports Free releases that predate
 * Free's middleware, and it routes through its own Strauss-prefixed wp-kit.
 *
 * Declared in the route table as `nonce` (default action `bitforms_save`) or
 * `nonce:<action>`.
 */
final class NonceCheckerMiddleware
{
    /**
     * @param string|null $action nonce action
     *
     * @return true|Response
     */
    public function handle(Request $request, $action = null)
    {
        $action = $action ?: 'bitforms_save';

        $nonce = isset($_REQUEST['_ajax_nonce'])
            ? sanitize_text_field(wp_unslash($_REQUEST['_ajax_nonce']))
            : '';

        if ('' !== $nonce && wp_verify_nonce($nonce, $action)) {
            return true;
        }

        return Response::error(__('Token expired', 'bitformpro'), 401)->code('UNAUTHORIZED');
    }
}
