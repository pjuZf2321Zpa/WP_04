<?php

namespace BitApps\BitFormPro\Http\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * The per-form nonce a published form ships in `bf_globals` (`bitforms_{formId}`).
 *
 * Pro's public form endpoints — file uploads, payments, email OTP — prove a
 * request came from the form with it. They are not behind route middleware: each
 * checks it after reading which form the request is for, and answers a refusal
 * with its own released reply, so they ask allows() in place. This is the one
 * definition of the check.
 */
final class FormNonceCheckerMiddleware
{
    /**
     * @param int|string  $formId
     * @param string|null $nonce  defaults to the request's `_ajax_nonce`
     *
     * @return bool
     */
    public static function allows($formId, $nonce = null)
    {
        if (null === $nonce) {
            $nonce = isset($_REQUEST['_ajax_nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['_ajax_nonce'])) : '';
        }

        return '' !== (string) $nonce && false !== wp_verify_nonce($nonce, 'bitforms_' . $formId);
    }
}
