<?php

namespace BitApps\BitFormPro\Http;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Router;
use BitApps\BitFormPro\Http\Requests\AdminRequest;

/**
 * Keeps the reply of a handler that answers nothing exactly what it always was.
 *
 * Before the route tables, admin-ajax.php ran the handler and, if it returned
 * without sending anything, ended the request with `wp_die('0')` — a bare `0`,
 * HTTP 200. wp-kit instead sends its own `{"status":"success","code":"SUCCESS",
 * "data":null}` envelope after the handler returns. That is a different reply,
 * and existing callers parse the old one, so the route being dispatched is
 * wrapped: the controller runs exactly as wp-kit would run it, and if it comes
 * back without having replied, the request ends the way admin-ajax.php ended it.
 * A handler that does reply (wp_send_json_*) ends the request itself and never
 * reaches the fallback.
 *
 * Applied to the public route table only — the requests published forms make,
 * which must not change. Only the route matching `$_REQUEST['action']` is
 * wrapped — the one wp-kit is about to bind — so no other controller class is
 * loaded or reflected. Pro's own copy of Free's class of the same name: each is
 * bound to its plugin's wp-kit.
 */
final class LegacyAjaxReply
{
    /**
     * @param Router $router a router whose table has been included, not yet registered
     * @param string $prefix the action prefix the router was built with
     *
     * @return void
     */
    public static function applyToRequestedRoute(Router $router, $prefix)
    {
        $requested = isset($_REQUEST['action']) ? sanitize_text_field(wp_unslash($_REQUEST['action'])) : '';
        if ('' === $requested) {
            return;
        }

        foreach ($router->getRoutes() as $route) {
            if ($prefix . $route->getRoutePrefix() . $route->getPath() !== $requested) {
                continue;
            }
            $wrapped = self::wrap($route->getAction());
            if (null !== $wrapped) {
                $route->action($wrapped);
            }
        }
    }

    /**
     * The same controller call, followed by admin-ajax.php's terminal `0`.
     *
     * Controllers take either nothing or an AdminRequest; the closure declares
     * the same parameter so wp-kit still builds (and validates) that request.
     * Any other shape is left to wp-kit untouched.
     *
     * @param mixed $action
     *
     * @return \Closure|null
     */
    private static function wrap($action)
    {
        if (!\is_array($action) || 2 !== \count($action) || !method_exists($action[0], $action[1])) {
            return null;
        }
        [$class, $method] = $action;

        $params = (new \ReflectionMethod($class, $method))->getParameters();
        if ([] === $params) {
            return function () use ($class, $method) {
                (new $class())->{$method}();
                wp_die('0');
            };
        }

        $type = $params[0]->getType();
        if (1 === \count($params) && $type instanceof \ReflectionNamedType && AdminRequest::class === $type->getName()) {
            return function (AdminRequest $request) use ($class, $method) {
                (new $class())->{$method}($request);
                wp_die('0');
            };
        }

        return null;
    }
}
