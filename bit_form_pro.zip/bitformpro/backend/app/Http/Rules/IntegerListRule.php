<?php

namespace BitApps\BitFormPro\Http\Rules;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPValidator\Rule;

/**
 * A list of integer ids — what the bulk endpoints take.
 *
 * Not `'ids' => ['array'], 'ids.*' => ['integer']`: wp-validator expands a
 * wildcard key by indexing into the value, and a string where the list should
 * be throws a TypeError (a fatal, not a 422). Bit Form (free) has the same rule
 * on its own validator copy.
 */
final class IntegerListRule extends Rule
{
    public function validate($value)
    {
        if (!\is_array($value)) {
            return false;
        }
        foreach ($value as $item) {
            if (false === filter_var($item, FILTER_VALIDATE_INT)) {
                return false;
            }
        }

        return true;
    }

    public function message()
    {
        return __('The :attribute must be a list of ids.', 'bitformpro');
    }

    public function setRuleName($ruleName): void
    {
        parent::setRuleName('integer_list');
    }

    public function getParamKeys()
    {
        return [];
    }

    public function setParameterValues($paramKeys, $paramValues): void {}
}
