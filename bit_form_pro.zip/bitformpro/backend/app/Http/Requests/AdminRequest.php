<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * A request on Pro's admin AJAX surface.
 *
 * Type-hinting this on a controller method is what asks wp-kit to build it. The
 * nonce, capability and POST guards have already run as route middleware by
 * then; they live there rather than in authorize() because their replies
 * (`Token expired` 401, `Insufficient permissions.` 403) are the ones the admin
 * UI expects, and wp-kit's own authorize() failure reply is different.
 */
class AdminRequest extends BaseRequest {}
