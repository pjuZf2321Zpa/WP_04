<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_get_pod_field — Pods fields for a pod.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetPodFieldsRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'pod_type' => ['nullable', 'string'],
        ];
    }
}
