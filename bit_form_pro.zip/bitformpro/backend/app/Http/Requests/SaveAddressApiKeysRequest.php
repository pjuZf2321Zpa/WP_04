<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_save_address_api_keys — Save the address autocomplete keys.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class SaveAddressApiKeysRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'google_maps_api_key' => ['nullable', 'string'],
            'mapbox_token'        => ['nullable', 'string'],
        ];
    }
}
