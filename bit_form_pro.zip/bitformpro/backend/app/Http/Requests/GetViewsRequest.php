<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_get_views — List the frontend views.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetViewsRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID' => ['nullable', 'integer'],
        ];
    }
}
