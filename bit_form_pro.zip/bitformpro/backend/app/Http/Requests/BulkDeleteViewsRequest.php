<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Http\Rules\IntegerListRule;

/**
 * bitforms_bulk_table_delete_form — Delete several frontend views.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class BulkDeleteViewsRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'tblId' => ['nullable', new IntegerListRule()],
        ];
    }
}
