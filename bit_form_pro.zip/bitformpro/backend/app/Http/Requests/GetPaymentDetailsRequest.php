<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_payment_details — An entry's payment details.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetPaymentDetailsRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID' => ['nullable', 'integer'],
        ];
    }
}
