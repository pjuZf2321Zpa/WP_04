<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_download_pdf_font — Download a font for PDF generation.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class DownloadPdfFontRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'fontName' => ['nullable', 'string'],
        ];
    }
}
