<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_delete_report — Delete a saved entries report.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class DeleteReportRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'report_id' => ['nullable', 'integer'],
        ];
    }
}
