<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_clone_integration — Copy one of a form's integrations.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class DuplicateIntegrationRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID' => ['nullable', 'integer'],
            'id'     => ['nullable', 'integer'],
        ];
    }
}
