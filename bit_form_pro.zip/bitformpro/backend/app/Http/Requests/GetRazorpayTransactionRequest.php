<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_razorpay_transaction_info — A Razorpay transaction.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetRazorpayTransactionRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID' => ['nullable', 'integer'],
        ];
    }
}
