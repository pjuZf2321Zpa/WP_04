<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_get_metabox_fields — Meta Box fields for a post type.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetMetaBoxFieldsRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'post_type' => ['nullable', 'string'],
        ];
    }
}
