<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_update_post_type — Change a custom post type.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 *
 * No field is constrained yet: the handler reads and checks the payload
 * itself. Add rules here as fields gain a contract.
 */
final class UpdatePostTypeRequest extends AdminRequest
{
    public function rules()
    {
        return [];
    }
}
