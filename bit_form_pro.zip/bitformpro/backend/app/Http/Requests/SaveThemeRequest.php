<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_save_custom_theme — Save a custom theme.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 *
 * No field is constrained yet: the handler reads and checks the payload
 * itself. Add rules here as fields gain a contract.
 */
final class SaveThemeRequest extends AdminRequest
{
    public function rules()
    {
        return [];
    }
}
