<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_form_entry_update_note — Change one of an entry's notes.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class UpdateEntryNoteRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID'  => ['nullable', 'integer'],
            'entryID' => ['nullable', 'integer'],
            'noteID'  => ['nullable', 'integer'],
        ];
    }
}
