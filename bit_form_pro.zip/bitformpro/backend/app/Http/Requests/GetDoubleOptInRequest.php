<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_get_double_opt_in — A form's double opt-in settings.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetDoubleOptInRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID' => ['nullable', 'integer'],
        ];
    }
}
