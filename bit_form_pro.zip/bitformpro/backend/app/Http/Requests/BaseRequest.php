<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Helpers\GlobalHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\RouteRegister;

/**
 * The request every Bit Form Pro controller receives.
 *
 * wp-kit builds one of these for any controller parameter type-hinted with it,
 * then calls authorize() and validate() before the controller runs.
 *
 * The admin posts multipart form-data whose `data` field holds a JSON document.
 * Decoding is delegated to Free's GlobalHelper::formatRequestData() — the call
 * every Pro handler made inline before the route tables — rather than a copy of
 * it, so the unslashing, error messages and "not an object becomes an empty
 * object" fallback stay exactly what they were, on every Free Pro supports.
 */
class BaseRequest extends Request
{
    /** @var object|null */
    private $payload;

    /**
     * Expose the fields of the `data` JSON document as request attributes, so a
     * subclass's rules() — run by wp-kit before the controller — can validate
     * them by name, and the controller can read the sanitized result from
     * validated(). Real request fields win over a same-named key inside `data`.
     */
    public function __construct(?RouteRegister $route = null)
    {
        parent::__construct($route);

        $data = $this->attributes['data'] ?? null;
        if (!\is_string($data) || '' === $data) {
            return;
        }
        $fields = JSON::decode($data, true);
        if (!\is_array($fields)) {
            return; // malformed or scalar: payload()/decodedOr400() report it
        }
        foreach ($fields as $key => $value) {
            if (\is_string($key) && !\array_key_exists($key, $this->attributes)) {
                $this->setAttribute($key, $value);
            }
        }
    }

    /**
     * Guards run as middleware before this object exists, so nothing further to
     * decide here. Subclasses for new endpoints can tighten it.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * wp-validator rules, applied automatically by wp-kit before the controller
     * runs. Empty here: an endpoint opts in with its own Request subclass (as in
     * bit-pi, e.g. Http\Requests\SaveApiKeyRequest), because each rule tightens
     * what that endpoint accepts. Note wp-validator applies `sanitize:*` before
     * the validation rules.
     *
     * @return array<string,array>
     */
    public function rules()
    {
        return [];
    }

    /**
     * One validated field as an int, or null when the request did not send it.
     *
     * @param string $key
     *
     * @return int|null
     */
    public function validatedInt($key)
    {
        $validated = $this->validated();

        return isset($validated[$key]) ? (int) $validated[$key] : null;
    }

    /**
     * validated(), with each nested value as the JSON decoded it.
     *
     * The validator reads the document decoded to arrays, where a JSON `{}` and
     * `[]` both become `[]`; a field holding an array or object is therefore
     * returned from payload(), decoded to objects. As in Bit Form (free).
     *
     * @return array<string, mixed>
     */
    public function validatedInput()
    {
        $validated = $this->validated();
        try {
            $payload = $this->payload();
        } catch (\InvalidArgumentException $e) {
            return $validated;
        }
        foreach ($validated as $key => $value) {
            if (\is_array($value) && property_exists($payload, $key)) {
                $validated[$key] = $payload->{$key};
            }
        }

        return $validated;
    }

    /**
     * The decoded `data` document.
     *
     * @throws \InvalidArgumentException on a missing or malformed body
     *
     * @return object
     */
    public function payload()
    {
        if (null === $this->payload) {
            $this->payload = GlobalHelper::formatRequestData();
        }

        return $this->payload;
    }

    /**
     * payload(), answering a malformed body with the same 400 each handler sent
     * from its own try/catch. Controllers call this first.
     *
     * @return object
     */
    public function decodedOr400()
    {
        try {
            return $this->payload();
        } catch (\InvalidArgumentException $e) {
            wp_send_json_error($e->getMessage(), 400);
        }

        // wp_send_json_error() ended the request; this satisfies the return type
        // only if a swapped wp_die handler let execution continue.
        // @phpstan-ignore-next-line deadCode.unreachable
        return new \stdClass();
    }
}
