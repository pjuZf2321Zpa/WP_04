<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_api_key — read, set or mint the bitform/v1 API secret.
 *
 * `api_key` is optional: absent or empty returns the stored key (minting one if
 * none exists); present, it replaces it. wp-validator sanitizes it before the
 * controller sees it, replacing the handler's own checks.
 */
class SaveApiKeyRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'api_key' => ['nullable', 'string', 'sanitize:text'],
        ];
    }
}
