<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_form_entry_create_note — Add a note to an entry.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class CreateEntryNoteRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID'  => ['nullable', 'integer'],
            'entryID' => ['nullable', 'integer'],
        ];
    }
}
