<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_create_new_view — Create a frontend view.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 *
 * The view document itself (configs, styles, access control) goes to Table
 * whole, as decoded: only its ids are validated here.
 */
final class CreateViewRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'id'      => ['nullable', 'integer'],
            'form_id' => ['nullable', 'integer'],
        ];
    }
}
