<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_get_form_template — A Pro form template.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 *
 * No field is constrained yet: the handler reads and checks the payload
 * itself. Add rules here as fields gain a contract.
 */
final class GetFormTemplateRequest extends AdminRequest
{
    public function rules()
    {
        return [];
    }
}
