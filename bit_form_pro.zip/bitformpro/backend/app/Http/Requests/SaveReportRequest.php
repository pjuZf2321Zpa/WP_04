<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_save_report — Save an entries report.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class SaveReportRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formId'   => ['nullable', 'integer'],
            'reportId' => ['nullable', 'integer'],
        ];
    }
}
