<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_abandonment_entry — What the entry page can do with a partial entry
 * (task: state | send_now | stop | resume_link).
 *
 * Every field is nullable: the controller answers a missing one with its own
 * message, which the admin shows as it is.
 */
final class AbandonmentEntryRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID'  => ['nullable', 'integer'],
            'entryID' => ['nullable', 'integer'],
            'task'    => ['nullable', 'string'],
        ];
    }
}
