<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_form_entry_get_notes — An entry's notes.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetEntryNotesRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'formID'  => ['nullable', 'integer'],
            'entryID' => ['nullable', 'integer'],
        ];
    }
}
