<?php

namespace BitApps\BitFormPro\Http\Requests;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * bitforms_get_term_posts — Posts in a taxonomy term.
 *
 * Rules mirror what the handler already assumes, so a request the handler
 * would accept always passes; they turn bad input into a 422 before it runs.
 */
final class GetTermPostsRequest extends AdminRequest
{
    public function rules()
    {
        return [
            'taxonomy' => ['nullable', 'string'],
            'termId'   => ['nullable', 'integer'],
        ];
    }
}
