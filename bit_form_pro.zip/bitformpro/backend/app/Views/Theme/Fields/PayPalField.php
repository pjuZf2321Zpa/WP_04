<?php

namespace BitApps\BitFormPro\Views\Theme\Fields;

use BitApps\BitForm\Contracts\FieldRendererInterface;
use BitApps\BitForm\Views\Theme\Fields\ClassicFieldHelpers;
use BitApps\BitForm\Views\Theme\Fields\ClassicInputWrapper;

class PayPalField implements FieldRendererInterface
{
    public static function init($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error = null, $value = null)
    {
        $inputWrapper = new ClassicInputWrapper($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error, $value);
        $input = self::field($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error, $value);
        return $inputWrapper->wrapper($input, true);
    }

    private static function field($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error = null, $value = null)
    {
        $fieldHelpers = new ClassicFieldHelpers($field, $rowID, $form_atomic_Cls_map);

        return sprintf(
            '<div class="%1$s"></div>',
            $fieldHelpers->getAtomicCls('paypal-wrp'),
        );
    }
}
