<?php

namespace BitApps\BitFormPro\Views\Theme\Fields;

use BitApps\BitForm\Contracts\FieldRendererInterface;
use BitApps\BitForm\Views\Theme\Fields\ClassicFieldHelpers;
use BitApps\BitForm\Views\Theme\Fields\ClassicInputWrapper;

class EmailOtpField implements FieldRendererInterface
{
    public static function init($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error = null, $value = null)
    {
        $inputWrapper = new ClassicInputWrapper($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error, $value);
        $input = self::field($field, $rowID, $form_atomic_Cls_map, $formID);
        return $inputWrapper->wrapper($input);
    }

    private static function field($field, $rowID, $form_atomic_Cls_map, $formID)
    {
        $fieldHelpers = new ClassicFieldHelpers($field, $rowID, $form_atomic_Cls_map);

        $nameForAttr = !empty($field->fieldName)
            ? str_replace(['.', ' '], '_', $field->fieldName)
            : $rowID;

        $config       = $field->config ?? (object) [];
        $otpLength    = isset($config->otpLength) ? max(4, min(8, (int) $config->otpLength)) : 6;
        $resendDelay  = isset($config->resendDelay) ? (int) $config->resendDelay : 60;
        $sendBtnTxt   = isset($config->sendBtnTxt) ? esc_html($config->sendBtnTxt) : 'Send OTP';
        $verifyBtnTxt = isset($config->verifyBtnTxt) ? esc_html($config->verifyBtnTxt) : 'Verify OTP';

        $waitTxtRaw   = isset($config->waitTxt) && '' !== $config->waitTxt
            ? esc_html($config->waitTxt)
            : 'Wait ${bf_resend_countdown}s to Resend';
        $countdownSpan = '<span class="' . esc_attr($rowID) . '-countdown">' . $resendDelay . '</span>';
        $waitTxtParts  = explode('${bf_resend_countdown}', $waitTxtRaw, 2);
        $waitTxtHtml   = 2 === count($waitTxtParts)
            ? $waitTxtParts[0] . $countdownSpan . $waitTxtParts[1]
            : $waitTxtRaw . $countdownSpan;

        $sessionIdName = esc_attr($nameForAttr) . '_session_id';
        $otpTokenCls   = esc_attr($rowID) . '-otp-token';
        $sessionIdCls  = esc_attr($rowID) . '-otp-session-id';

        // Build individual OTP input boxes
        $otpBoxes = '';
        for ($i = 0; $i < $otpLength; $i++) {
            $digit     = $i + 1;
            $otpBoxes
                .= '<input'
                . ' type="text"'
                . ' inputmode="numeric"'
                . ' pattern="[0-9]"'
                . ' maxlength="1"'
                . ' class="' . $fieldHelpers->getAtomicCls('otp-box') . ' ' . $fieldHelpers->getCustomClasses('otp-box') . '"'
                . ' ' . $fieldHelpers->getCustomAttributes('otp-box')
                . ' aria-label="OTP digit ' . $digit . '"'
                . ' autocomplete="one-time-code"'
                . ' />';
        }

        $spinner = '<span class="bf-spinner d-none" aria-hidden="true"></span>';

        return sprintf(
            '<div
              %1$s
              class="%2$s %3$s"
            >
              <div
                class="%4$s %5$s"
                role="group"
                aria-label="OTP digit inputs"
                aria-live="polite"
                aria-atomic="false"
              >
                %6$s
              </div>
              <div class="%7$s %8$s">
                <button
                  type="button"
                  class="%9$s %10$s"
                  %11$s
                  aria-label="Send OTP verification code"
                >
                  %12$s
                  %13$s
                </button>
                <div
                  class="%14$s %15$s"
                  style="display:none"
                  aria-live="polite"
                  aria-atomic="true"
                >
                  <span class="%16$s %17$s">%18$s</span>
                </div>
                <button
                  type="button"
                  class="%19$s %20$s"
                  %21$s
                  style="display:none"
                  aria-label="Verify OTP code"
                >
                  %22$s
                  %23$s
                </button>
              </div>
              <div
                class="%24$s %25$s"
                style="display:none"
                role="status"
                aria-live="polite"
                aria-atomic="true"
              ></div>
              <div
                class="%26$s %27$s"
                style="display:none"
                role="alert"
                aria-live="assertive"
                aria-atomic="true"
              ></div>
              <input type="hidden" name="%28$s" class="%29$s" value="" />
              <input type="hidden" name="%30$s" class="%31$s" value="" />
            </div>',
            $fieldHelpers->getCustomAttributes('inp-fld-wrp'),   // 1
            $fieldHelpers->getAtomicCls('inp-fld-wrp'),          // 2
            $fieldHelpers->getCustomClasses('inp-fld-wrp'),      // 3
            $fieldHelpers->getAtomicCls('otp-boxes-wrp'),        // 4
            $fieldHelpers->getCustomClasses('otp-boxes-wrp'),    // 5
            $otpBoxes,                                           // 6
            $fieldHelpers->getAtomicCls('otp-actions-wrp'),      // 7
            $fieldHelpers->getCustomClasses('otp-actions-wrp'),  // 8
            $fieldHelpers->getAtomicCls('send-otp-btn'),         // 9
            $fieldHelpers->getCustomClasses('send-otp-btn'),     // 10
            $fieldHelpers->getCustomAttributes('send-otp-btn'),  // 11
            $sendBtnTxt,                                         // 12
            $spinner,                                            // 13
            $fieldHelpers->getAtomicCls('resend-wrp'),           // 14
            $fieldHelpers->getCustomClasses('resend-wrp'),       // 15
            $fieldHelpers->getAtomicCls('wait-txt'),             // 16
            $fieldHelpers->getCustomClasses('wait-txt'),         // 17
            $waitTxtHtml,                                        // 18
            $fieldHelpers->getAtomicCls('verify-btn'),           // 19
            $fieldHelpers->getCustomClasses('verify-btn'),       // 20
            $fieldHelpers->getCustomAttributes('verify-btn'),    // 21
            $verifyBtnTxt,                                       // 22
            $spinner,                                            // 23
            $fieldHelpers->getAtomicCls('otp-success-msg'),      // 24
            $fieldHelpers->getCustomClasses('otp-success-msg'),  // 25
            $fieldHelpers->getAtomicCls('otp-error-msg'),        // 26
            $fieldHelpers->getCustomClasses('otp-error-msg'),    // 27
            esc_attr($nameForAttr),                              // 28
            $otpTokenCls,                                        // 29
            $sessionIdName,                                      // 30
            $sessionIdCls,                                        // 31
        );
    }
}
