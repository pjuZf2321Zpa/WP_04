<?php

namespace BitApps\BitFormPro\Views\Theme\Fields;

use BitApps\BitForm\Contracts\FieldRendererInterface;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Views\Theme\Fields\ClassicFieldHelpers;

class ShortcodeField implements FieldRendererInterface
{
    public static function init($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error = null, $value = null)
    {
        $fieldHelpers = new ClassicFieldHelpers($field, $rowID, $form_atomic_Cls_map);

        $content = '';
        if (isset($field->content) && !empty($field->content)) {
            $content = $field->content;
        } elseif ($fieldHelpers->property_exists_nested($field, 'info->content') && !empty($field->info->content)) {
            $content = $field->info->content;
        }

        $content = wp_kses_post(FieldValueHandler::replaceSmartTagWithValue($content));
        $content = do_shortcode($content);

        $content = self::filterShortCodeContent($content, $formID, $rowID);

        return sprintf(
            '<div
      %1$s
      class="%2$s %3$s"
    >
      %4$s
    </div>',
            $fieldHelpers->getCustomAttributes('fld-wrp'),
            $fieldHelpers->getAtomicCls('fld-wrp'),
            $fieldHelpers->getCustomClasses('fld-wrp'),
            $content,
        );
    }

    /**
     * Filters the rendered Shortcode field content.
     *
     * The misspelled `bitform_filter_sortcode_content` hook still fires after the correct one so
     * existing customisations keep working; it is deprecated in favour of `bitform_filter_shortcode_content`.
     *
     * @param string $content  Rendered field content.
     * @param int    $formID   Form ID.
     * @param string $fieldKey Field key.
     *
     * @return string
     */
    private static function filterShortCodeContent($content, $formID, $fieldKey)
    {
        $content = apply_filters('bitform_filter_shortcode_content', $content, $formID, $fieldKey);

        return apply_filters_deprecated(
            'bitform_filter_sortcode_content',
            [$content, $formID, $fieldKey],
            '3.3.2',
            'bitform_filter_shortcode_content',
        );
    }
}
