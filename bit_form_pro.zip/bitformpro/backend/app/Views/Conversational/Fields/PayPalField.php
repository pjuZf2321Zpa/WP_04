<?php

namespace BitApps\BitFormPro\Views\Conversational\Fields;

use BitApps\BitForm\Contracts\FieldRendererInterface;
use BitApps\BitForm\Views\Conversational\Fields\ConversationalFieldHelpers;
use BitApps\BitForm\Views\Conversational\Fields\ConversationalInputWrapper;

class PayPalField implements FieldRendererInterface
{
    public static function init($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error = null, $value = null)
    {
        $inputWrapper = new ConversationalInputWrapper($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error, $value);
        $input = self::field($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error, $value);
        return $inputWrapper->wrapper($input, true);
    }

    private static function field($field, $rowID, $field_name, $form_atomic_Cls_map, $formID, $error = null, $value = null)
    {
        $fieldHelpers = new ConversationalFieldHelpers($formID, $field, $rowID, $form_atomic_Cls_map);

        return sprintf(
            '<div class="%1$s"></div>',
            $fieldHelpers->getConversationalCls('paypal-wrp'),
        );
    }
}
