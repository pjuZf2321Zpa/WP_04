<?php

namespace BitApps\BitFormPro\Workflow;

use BitApps\BitForm\Services\Messages\EmailTemplateHandler;
use BitApps\BitForm\Helpers\Utilities;
use BitApps\BitForm\Workflow\Actions;
use BitApps\BitForm\Workflow\ConditionalLogic;
use BitApps\BitForm\Workflow\Helper;
use BitApps\BitForm\Workflow\WorkFlow;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Compat\ReleasedName;
use BitApps\BitForm\Model\Workflow as WorkflowRow;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Advanced (Pro) conditional logic processor.
 *
 * Free's getWorkFlow() only ever returns non-advanced rows (classic/basic), so Free never
 * evaluates or executes advanced conditional logic. This class runs the dedicated advanced pass
 * for every workflow lifecycle stage: it fetches the category 'advanced' rows and runs them
 * through the SAME evaluation/action pipeline Free uses (the extracted runXxx methods on
 * WorkFlow), then merges the result back into the response. With Pro inactive these filters have
 * no listener and the advanced rows stay completely inert.
 *
 * Note: executeOnDelete executes its actions inline (no mergeable return), so advanced delete
 * routing is intentionally not wired here; the category exclusion in getWorkFlow already keeps
 * Free from touching advanced delete rows.
 */
final class AdvancedConditionalLogic
{
    private const FREE_WORKFLOW = 'BitApps\BitForm\Workflow\WorkFlow';

    public static function register()
    {
        add_filter('bitform_default_submit_confirmation_excluded_action_ids', [ReleasedName::of(self::class), 'getAdvancedConditionalActionIds'], 10, 3);
        add_filter('bitform_process_advanced_workflows', [ReleasedName::of(self::class), 'processOnSubmit'], 10, 7);
        add_filter('bitform_process_advanced_workflows_onload', [ReleasedName::of(self::class), 'processOnLoad'], 10, 4);
        add_filter('bitform_advanced_oninput_conditions', [ReleasedName::of(self::class), 'processOnUserInput'], 10, 3);
        add_filter('bitform_process_advanced_workflows_onvalidate', [ReleasedName::of(self::class), 'processOnValidate'], 10, 5);
        add_filter('bitform_email_conditional_routing', [ReleasedName::of(self::class), 'resolveEmailRouting'], 10, 4);
    }

    /**
     * Add confirmation record IDs controlled by active inline Advanced Conditional Logic.
     *
     * @param array       $actionIds   Existing exclusions keyed by confirmation storage type.
     * @param int         $formID      Form ID.
     * @param string|null $workFlowRun Submission operation (create or edit).
     *
     * @return array IDs keyed by confirmation storage type
     */
    public static function getAdvancedConditionalActionIds($actionIds, $formID, $workFlowRun = null)
    {
        static $cache = [];

        $actionIds = is_array($actionIds) ? $actionIds : [];
        foreach (['successMsg', 'redirectPage', 'mailNotify', 'integrations'] as $type) {
            if (empty($actionIds[$type]) || !is_array($actionIds[$type])) {
                $actionIds[$type] = [];
            }
        }

        $cacheKey = (string) $formID . ':' . (string) $workFlowRun;
        if (!isset($cache[$cacheKey])) {
            $condition = [
                'form_id'           => $formID,
                'workflow_type'     => 'onsubmit',
                'workflow_status'   => 1,
                'workflow_category' => 'advanced',
            ];
            if (!empty($workFlowRun)) {
                $condition['workflow_run'] = ['create_edit', $workFlowRun];
            }

            $workFlows = WorkflowRow::readWhere($condition, ['workflow_info']);
            $cache[$cacheKey] = [
                'successMsg'   => [],
                'redirectPage' => [],
                'mailNotify'   => [],
                'integrations' => [],
            ];
            if (!empty($workFlows) && !is_wp_error($workFlows)) {
                $actionTypeMap = [
                    'confirmation' => 'successMsg',
                    'redirect'     => 'redirectPage',
                    'email'        => 'mailNotify',
                    'integration'  => 'integrations',
                ];
                foreach ($workFlows as $workFlow) {
                    $info = Utilities::jsonObj($workFlow->workflow_info ?? '');
                    if (empty($info->action) || !isset($info->targetId, $actionTypeMap[$info->action])) {
                        continue;
                    }
                    $cache[$cacheKey][$actionTypeMap[$info->action]][(string) $info->targetId] = true;
                }
            }
        }

        foreach ($cache[$cacheKey] as $type => $ids) {
            $actionIds[$type] = array_replace($actionIds[$type], $ids);
        }

        return $actionIds;
    }

    /**
     * Conditional email routing: add recipients whose value-based rule (field operator value) matches
     * the submission. Rules live in the email template config.routing = [{to, field, operator, value}].
     *
     * @return array recipient list
     */
    public static function resolveEmailRouting($mailTo, $template, $fieldValue, $formID)
    {
        if (empty($template) || empty($template->config)) {
            return $mailTo;
        }
        $config = is_string($template->config) ? JSON::decode($template->config) : $template->config;
        if (empty($config->routing) || !is_array($config->routing)) {
            return $mailTo;
        }
        $mailTo = is_array($mailTo) ? $mailTo : (empty($mailTo) ? [] : [$mailTo]);
        foreach ($config->routing as $rule) {
            if (empty($rule->to) || empty($rule->field)) {
                continue;
            }
            $fieldVal = $fieldValue[$rule->field] ?? '';
            $operator = $rule->operator ?? 'equal';
            $value = $rule->value ?? '';
            if (self::routeMatches($fieldVal, $operator, $value) && !in_array($rule->to, $mailTo, true)) {
                $mailTo[] = $rule->to;
            }
        }
        return $mailTo;
    }

    private static function routeMatches($fieldVal, $operator, $value)
    {
        $fieldVal = is_array($fieldVal) ? implode(',', $fieldVal) : (string) $fieldVal;
        $value = (string) $value;
        switch ($operator) {
            case 'not_equal':
                return $fieldVal !== $value;
            case 'contain':
                return '' !== $value && false !== strpos($fieldVal, $value);
            case 'not_contain':
                return '' === $value || false === strpos($fieldVal, $value);
            case 'equal':
            default:
                return $fieldVal === $value;
        }
    }

    /**
     * onsubmit (create + edit): merge advanced confirmation, redirect, mail and integrations.
     *
     * @return array merged submission result
     */
    public static function processOnSubmit($workFlowReturnable, $workFlowRun, $fields, $fieldValue, $entryID, $logID, $formID)
    {
        if (!self::freeWorkflowReady('runSubmitWorkflowActions')) {
            return $workFlowReturnable;
        }

        $workFlow = new WorkFlow($formID);
        $advancedRows = $workFlow->getWorkFlow(['create_edit', $workFlowRun], ['onsubmit'], null, 'workflow_order', 1, ['advanced']);
        if (empty($advancedRows) || is_wp_error($advancedRows)) {
            return $workFlowReturnable;
        }

        $fieldData = Helper::getFieldData($fields);

        // Two flavours of advanced rows share the 'advanced' category:
        //  - per-feature inline rows: info.action set + info.effect (show/hide) gating one feature record
        //  - standalone advanced-builder rows: full success-action workflows (reuse Free's pipeline)
        $featureRows = [];
        $builderRows = [];
        foreach ($advancedRows as $row) {
            $info = !empty($row->workflow_info) ? JSON::decode($row->workflow_info) : null;
            if ($info && !empty($info->action)) {
                $featureRows[] = [$row, $info];
            } else {
                $builderRows[] = $row;
            }
        }

        if (!empty($builderRows)) {
            $workFlowReturnable = self::runBuilderRows($workFlow, $builderRows, $workFlowReturnable, $fieldData, $fieldValue, $entryID);
        }

        foreach ($featureRows as $featureRow) {
            [$row, $info] = $featureRow;
            $conditions = JSON::decode($row->workflow_condition);
            $logics = $conditions[0]->logics ?? [];
            $condition = $conditions[0] ?? null;
            $matched = self::evaluateLogics($logics, $fieldData, $condition, $formID);
            $effect = $info->effect ?? 'show';
            $targetId = $info->targetId ?? null;
            // Unmatched rules are NOT skipped: a 'show' rule that targets Free's baseline message
            // must still gate it off when its condition does not match.
            $workFlowReturnable = self::applyFeatureEffect($workFlowReturnable, $info->action, $effect, $targetId, $matched, $formID, $fieldValue, $entryID);
        }

        return $workFlowReturnable;
    }

    /**
     * Standalone advanced-builder rows reuse Free's generic success-action pipeline.
     */
    private static function runBuilderRows($workFlow, $builderRows, $workFlowReturnable, $fieldData, $fieldValue, $entryID)
    {
        $triggerData = $workFlowReturnable['triggerData'] ?? [];
        $accumulator = [
            'workFlowReturnable' => $workFlowReturnable,
            'mailData'           => $triggerData['mail'] ?? [],
            'dblOptin'           => $triggerData['dblOptin'] ?? [],
            'integrationsToExc'  => $triggerData['integrations'] ?? [],
            'isWebHookQueued'    => false,
        ];
        $accumulator = $workFlow->runSubmitWorkflowActions($builderRows, $accumulator, $fieldData, $fieldValue, $entryID);
        $merged = $accumulator['workFlowReturnable'];
        $merged['triggerData'] = array_merge($triggerData, [
            'mail'         => $accumulator['mailData'],
            'dblOptin'     => $accumulator['dblOptin'],
            'integrations' => $accumulator['integrationsToExc'],
        ]);
        return $merged;
    }

    /**
     * Evaluate a per-feature rule's conditions. Honors the public condition-status filter.
     */
    private static function evaluateLogics($logics, $fieldData, $condition, $formID)
    {
        if (empty($logics)) {
            $status = true;
        } else {
            $fieldData = Helper::smartFldMargeFormFld($logics, $fieldData);
            $status = (new ConditionalLogic($logics, $fieldData))->getConditionStatus();
        }
        return apply_filters('bitform_filter_workflow_condition_status', $status, $condition, $fieldData, $formID);
    }

    /**
     * Apply a per-feature rule. The effect polarity + match decide whether the feature is "active":
     *   'show' (positive: Show / Send / Redirect / Execute) -> active when the condition MATCHES
     *   'hide' (negative: Don't ...)                         -> active when the condition does NOT match
     *                                                           (i.e. do it always EXCEPT when matched)
     * active  => perform the feature for $targetId; !active => ensure it is NOT performed.
     *
     * @param bool $matched whether the rule's condition matched this submission
     */
    private static function applyFeatureEffect($workFlowReturnable, $action, $effect, $targetId, $matched, $formID, $fieldValue, $entryID)
    {
        $targetId = null !== $targetId ? (string) $targetId : '';
        if ('' === $targetId) {
            return $workFlowReturnable;
        }
        $active = ('show' === $effect) ? (bool) $matched : !$matched;

        switch ($action) {
            case 'confirmation':
                return self::applyConfirmation($workFlowReturnable, $active, $targetId, $formID, $fieldValue, $entryID);
            case 'redirect':
                return self::applyRedirect($workFlowReturnable, $active, $targetId, $formID, $fieldValue, $effect, $matched);
            case 'email':
                return self::applyEmail($workFlowReturnable, $active, $targetId, $formID);
            case 'integration':
                return self::applyIntegration($workFlowReturnable, $active, $targetId);
            default:
                return $workFlowReturnable;
        }
    }

    private static function applyConfirmation($workFlowReturnable, $active, $targetId, $formID, $fieldValue, $entryID)
    {
        $currentMsgId = isset($workFlowReturnable['msg_id']) ? (string) $workFlowReturnable['msg_id'] : '0';
        if ($active) {
            // Show this specific message (overrides Free's baseline).
            $actions = new Actions($formID);
            $workFlowReturnable = $actions->confirmationMessage($workFlowReturnable, JSON::encode(['id' => $targetId]), $fieldValue, $entryID);
            $workFlowReturnable['dflt_message'] = false;
            unset($workFlowReturnable['suppressConfirmation']);
        } elseif ($targetId === $currentMsgId) {
            // This message must not show and it is the one Free resolved -> suppress it.
            $workFlowReturnable = self::suppressConfirmation($workFlowReturnable);
        }
        return $workFlowReturnable;
    }

    private static function applyRedirect($workFlowReturnable, $active, $targetId, $formID, $fieldValue, $effect, $matched)
    {
        if ($active) {
            $actions = new Actions($formID);
            $workFlowReturnable = $actions->redirectPage($workFlowReturnable, JSON::encode(['id' => $targetId]), $fieldValue);
        } elseif ('hide' === $effect && $matched) {
            // hide + match: explicitly suppress redirect
            $workFlowReturnable['redirectPage'] = '';
        }
        // show + no-match: leave existing redirect (standalone default) untouched
        return $workFlowReturnable;
    }

    /**
     * Send / Don't Send. Mail queued in triggerData['mail'] (each entry a notify-details object).
     */
    private static function applyEmail($workFlowReturnable, $active, $targetId, $formID)
    {
        $triggerData = $workFlowReturnable['triggerData'] ?? [];
        $mail = $triggerData['mail'] ?? [];
        $idOf = static function ($entry) {
            $decoded = (is_object($entry) && isset($entry->id)) ? JSON::decode($entry->id) : null;
            return isset($decoded->id) ? (string) $decoded->id : '';
        };
        $queued = false;
        foreach ($mail as $entry) {
            if ($idOf($entry) === $targetId) {
                $queued = true;
                break;
            }
        }
        if ($active && !$queued) {
            $mail[] = self::buildEmailDetails($formID, $targetId);
        } elseif (!$active && $queued) {
            $mail = array_values(array_filter($mail, static function ($entry) use ($idOf, $targetId) {
                return $idOf($entry) !== $targetId;
            }));
        }
        $triggerData['mail'] = $mail;
        $workFlowReturnable['triggerData'] = $triggerData;
        return $workFlowReturnable;
    }

    /**
     * Execute / Don't Execute an integration. triggerData['integrations'] holds JSON id strings.
     */
    /**
     * triggerData['integrations'] is a list of GROUPS. Each group is an array of JSON id strings
     * (e.g. ['{"id":15}']) — Actions::setOnFormSuccess pushes `details->id`, which is itself an array,
     * and Integrations::integrationExecutionHelper passes each GROUP to executeIntegrations() (which
     * requires is_array() and string members). So we must add/remove groups, never bare strings.
     */
    private static function applyIntegration($workFlowReturnable, $active, $targetId)
    {
        $triggerData = $workFlowReturnable['triggerData'] ?? [];
        $integrations = $triggerData['integrations'] ?? [];

        // Ids contained in one group (tolerates a bare string group).
        $idsOfGroup = static function ($group) {
            $group = is_array($group) ? $group : [$group];
            $ids = [];
            foreach ($group as $entry) {
                if (!is_string($entry)) {
                    continue;
                }
                $decoded = JSON::decode($entry);
                if (isset($decoded->id)) {
                    $ids[] = (string) $decoded->id;
                }
            }
            return $ids;
        };

        $present = false;
        foreach ($integrations as $group) {
            if (in_array($targetId, $idsOfGroup($group), true)) {
                $present = true;
                break;
            }
        }

        if ($active && !$present) {
            // Append as a group (array of one JSON id string) to match the expected shape.
            $integrations[] = [JSON::encode(['id' => $targetId])];
        } elseif (!$active && $present) {
            $filtered = [];
            foreach ($integrations as $group) {
                $groupArr = is_array($group) ? $group : [$group];
                $kept = [];
                foreach ($groupArr as $entry) {
                    $decoded = is_string($entry) ? JSON::decode($entry) : null;
                    $id = isset($decoded->id) ? (string) $decoded->id : '';
                    if ($id !== $targetId) {
                        $kept[] = $entry;
                    }
                }
                if (!empty($kept)) {
                    $filtered[] = $kept;
                }
            }
            $integrations = array_values($filtered);
        }

        $triggerData['integrations'] = $integrations;
        $workFlowReturnable['triggerData'] = $triggerData;
        return $workFlowReturnable;
    }

    /**
     * Build a notify-details object for a template from its stored config (SendTo / From / CC / BCC / etc.).
     */
    private static function buildEmailDetails($formID, $templateId)
    {
        $details = new \stdClass();
        $details->id = JSON::encode(['id' => (string) $templateId]);
        $details->to = [];
        $details->from = '';
        $details->from_name = '';
        $details->cc = [];
        $details->bcc = [];
        $details->replyto = [];
        $details->attachment = [];
        $details->mediaAttachment = [];
        $details->pdfId = '';
        $details->pdfIds = [];

        $handler = new EmailTemplateHandler($formID);
        $template = $handler->getATemplate($templateId);
        if (!is_wp_error($template) && !empty($template[0]->config)) {
            $config = JSON::decode($template[0]->config);
            foreach (['to', 'from', 'from_name', 'cc', 'bcc', 'replyto', 'attachment', 'mediaAttachment', 'pdfId', 'pdfIds'] as $key) {
                if (isset($config->$key)) {
                    $details->$key = $config->$key;
                }
            }
        }
        return $details;
    }

    private static function suppressConfirmation($workFlowReturnable)
    {
        $workFlowReturnable['message'] = '';
        $workFlowReturnable['msg_id'] = 0;
        $workFlowReturnable['suppressConfirmation'] = true;
        unset($workFlowReturnable['afterSubmit']);
        return $workFlowReturnable;
    }

    /**
     * onload: apply advanced field show/hide on top of whatever Free already resolved.
     *
     * @return array $workFlowReturnable with ['fields']
     */
    public static function processOnLoad($workFlowReturnable, $workFlowRun, $fields, $formID)
    {
        if (!self::freeWorkflowReady('runLoadWorkflowFields')) {
            return $workFlowReturnable;
        }

        $workFlow = new WorkFlow($formID);
        $advancedRows = $workFlow->getWorkFlow(['create_edit', $workFlowRun], ['always', 'onload'], null, 'workflow_order', 1, ['advanced']);
        if (empty($advancedRows) || is_wp_error($advancedRows)) {
            return $workFlowReturnable;
        }
        $advancedRows = array_reverse($advancedRows);

        $startFields = $workFlowReturnable['fields'] ?? $fields;
        $fieldData = Helper::getFieldData($startFields);
        $result = $workFlow->runLoadWorkflowFields($advancedRows, $startFields, $fieldData);
        $workFlowReturnable['fields'] = $result[0];

        return $workFlowReturnable;
    }

    /**
     * oninput: append advanced on-input conditions (client-side field visibility data) after Free's.
     *
     * @return array $workFlowReturnable
     */
    public static function processOnUserInput($workFlowReturnable, $workFlowRun, $formID)
    {
        if (!self::freeWorkflowReady()) {
            return $workFlowReturnable;
        }

        $workFlow = new WorkFlow($formID);
        $advancedRows = $workFlow->getWorkFlow(['create_edit', $workFlowRun], ['always', 'oninput'], null, 'workflow_order', 1, ['advanced']);
        if (empty($advancedRows) || is_wp_error($advancedRows)) {
            return $workFlowReturnable;
        }

        $conditionsList = $workFlowReturnable['onfield_input_conditions'] ?? [];
        $offset = count($conditionsList);
        foreach (array_values($advancedRows) as $i => $value) {
            $conditionsList[$offset + $i] = [
                'event_type' => 'on_input',
                'conditions' => JSON::decode($value->workflow_condition),
            ];
        }
        $workFlowReturnable['onfield_input_conditions'] = $conditionsList;

        return $workFlowReturnable;
    }

    /**
     * onvalidate: resolve an advanced validation message only if Free/basic did not already set one.
     *
     * @return array $workFlowReturnable
     */
    public static function processOnValidate($workFlowReturnable, $workFlowRun, $fieldData, $fieldValue, $formID)
    {
        if (!self::freeWorkflowReady('runValidateWorkflow')) {
            return $workFlowReturnable;
        }
        // Free/basic validation takes precedence: a submit already blocked stays blocked.
        if (!empty($workFlowReturnable['message'])) {
            return $workFlowReturnable;
        }

        $workFlow = new WorkFlow($formID);
        $advancedRows = $workFlow->getWorkFlow(['create_edit', $workFlowRun], 'onvalidate', null, 'workflow_order', 1, ['advanced']);
        if (empty($advancedRows) || is_wp_error($advancedRows)) {
            return $workFlowReturnable;
        }

        return $workFlow->runValidateWorkflow($advancedRows, $workFlowReturnable, $fieldData, $fieldValue);
    }

    private static function freeWorkflowReady($method = null)
    {
        if (!class_exists(self::FREE_WORKFLOW)) {
            return false;
        }
        if (null !== $method && !method_exists(self::FREE_WORKFLOW, $method)) {
            return false;
        }
        return true;
    }
}
