<?php

namespace BitApps\BitFormPro\Compat;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Model\FormEntry;

/**
 * The trash predicate, for Pro's own entry queries.
 *
 * Free soft-deletes entries with a `trashed_at` column instead of removing the
 * row. Every Free read already filters on it; Pro's own queries have to do the
 * same or a trashed entry stays live for double opt-in, form abandonment and the
 * REST list.
 *
 * FormEntry::hasTriageColumns() and the IS NULL legacy condition are Free API
 * level 4, which FreeCompat requires. The guard is not about Free's version but
 * its schema: the migration is admin-gated, so the column can still be missing
 * on a site that has updated but has no administrator visit yet.
 */
final class EntryTrash
{
    /**
     * Add "not in the trash" to a legacy condition array (FormEntry::readWhere() & co).
     *
     * @param array $condition
     *
     * @return array
     */
    public static function activeOnly(array $condition = [])
    {
        if (!FormEntry::hasTriageColumns()) {
            return $condition;
        }

        $condition['trashed_at'] = ['operator' => 'IS', 'raw' => 'NULL'];

        return $condition;
    }

    /**
     * The same predicate as a SQL fragment, for hand-written queries.
     *
     * @param string $alias table alias, or '' for an unaliased table
     *
     * @return string '' when the column does not exist yet
     */
    public static function sqlClause($alias = '')
    {
        if (!FormEntry::hasTriageColumns()) {
            return '';
        }
        $prefix = '' === $alias ? '' : $alias . '.';

        return " AND {$prefix}trashed_at IS NULL ";
    }
}
