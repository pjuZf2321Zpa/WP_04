<?php

/**
 * Legacy FQCN => current FQCN, for Pro classes that have moved.
 *
 * Bit Form (free) names Pro classes by string — see
 * tests/Compat/ProSurfaceTest::REFERENCED_BY_FREE for the list it depends on.
 * A moved class needs a line here or that feature silently renders nothing,
 * because Free's call sites are all `class_exists()`-guarded and simply skip.
 *
 * Also consumed by phpstan-bootstrap.php so static analysis resolves both names.
 */
return [
    'BitCode\\BitFormPro\\Core\\Ajax\\AjaxService' => 'BitApps\\BitFormPro\\Http\\AjaxService',
    'BitCode\\BitFormPro\\Core\\Database\\PdfTemplateModel' => 'BitApps\\BitFormPro\\Model\\PdfTemplateModel',
    'BitCode\\BitFormPro\\Core\\Messages\\PdfTemplateHandler' => 'BitApps\\BitFormPro\\Services\\Messages\\PdfTemplateHandler',
    'BitCode\\BitFormPro\\Core\\Util\\LicenseHelper' => 'BitApps\\BitFormPro\\Helpers\\LicenseHelper',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Conversational\\Fields\\AdvanceFileUpField' => 'BitApps\\BitFormPro\\Views\\Conversational\\Fields\\AdvanceFileUpField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Conversational\\Fields\\PayPalField' => 'BitApps\\BitFormPro\\Views\\Conversational\\Fields\\PayPalField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Conversational\\Fields\\RazorPayField' => 'BitApps\\BitFormPro\\Views\\Conversational\\Fields\\RazorPayField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Conversational\\Fields\\SignatureField' => 'BitApps\\BitFormPro\\Views\\Conversational\\Fields\\SignatureField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Conversational\\Fields\\StripeField' => 'BitApps\\BitFormPro\\Views\\Conversational\\Fields\\StripeField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\AdvanceDateTimeField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\AdvanceDateTimeField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\AdvanceFileUpField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\AdvanceFileUpField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\EmailOtpField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\EmailOtpField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\MollieField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\MollieField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\PayPalField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\PayPalField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\RazorPayField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\RazorPayField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\ShortcodeField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\ShortcodeField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\SignatureField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\SignatureField',
    'BitCode\\BitFormPro\\Frontend\\Form\\View\\Theme\\Fields\\StripeField' => 'BitApps\\BitFormPro\\Views\\Theme\\Fields\\StripeField',
    'BitCode\\BitFormPro\\Admin\\DownloadFile' => 'BitApps\\BitFormPro\\Http\\Controller\\EntryDownloadPageController',
    'BitCode\\BitFormPro\\Frontend\\PaymentHandler' => 'BitApps\\BitFormPro\\Services\\Frontend\\PaymentHandler',
    'BitCode\\BitFormPro\\Admin\\AppSetting\\Pdf' => 'BitApps\\BitFormPro\\Services\\Admin\\AppSetting\\Pdf',
    'BitCode\\BitFormPro\\Admin\\BfTable\\Table' => 'BitApps\\BitFormPro\\Services\\Admin\\BfTable\\Table',
];
