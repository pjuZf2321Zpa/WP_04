<?php

namespace BitApps\BitFormPro\Compat;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Lazy class_alias registry for relocated Pro classes.
 *
 * The mirror of Free's loader, and needed for the same reason in the opposite
 * direction: Bit Form (free) reaches into Pro by string — nine field renderers
 * dispatched as `{Type}Field::init(...)`, the PDF and download handlers, the
 * PaymentHandler that replaces Free's frontend handler — all behind
 * `class_exists()`. Those names are Free's side of the contract, so a Pro class
 * that moves must keep answering to the name Free knows.
 *
 * Registered from backend/bootstrap.php before Pro's own kernel, so a legacy
 * name resolves no matter who asks first.
 */
final class AliasLoader
{
    /** @var array<string,string> old FQCN => new FQCN */
    private static $map = [];

    /** @var array<string,string> lower-cased old FQCN => new FQCN (PHP class names are case-insensitive) */
    private static $lowerMap = [];

    /** @var array<string,string> legacy namespace prefix => current prefix, longest first */
    private static $prefixes = [];

    /** @var array<string,string[]> lower-cased current FQCN => legacy FQCNs the explicit maps give it */
    private static $reverse = [];

    /** @var bool */
    private static $registered = false;

    /**
     * @param array<string,string> $map old FQCN => new FQCN
     *
     * @return void
     */
    public static function register(array $map)
    {
        self::$map = $map + self::$map;
        foreach ($map as $legacy => $current) {
            if (!isset(self::$lowerMap[strtolower($legacy)])) {
                self::$lowerMap[strtolower($legacy)] = $current;
                self::$reverse[strtolower($current)][] = $legacy;
            }
        }
        self::listen();
    }

    /**
     * Resolve every class under a legacy namespace prefix to the same name under
     * the current one — `BitCode\BitFormPro\X` to `BitApps\BitFormPro\X` — for anything
     * the explicit maps do not name. Explicit entries win, so a class that both
     * moved and was renamed resolves to where it is now.
     *
     * @param string $legacy  namespace prefix, with the trailing backslash
     * @param string $current namespace prefix, with the trailing backslash
     *
     * @return void
     */
    public static function registerPrefix($legacy, $current)
    {
        self::$prefixes[$legacy] = $current;
        uksort(self::$prefixes, function ($a, $b) {
            return \strlen($b) - \strlen($a);
        });
        self::listen();
    }

    /**
     * spl_autoload callback.
     *
     * A legacy name is aliased to the class it now stands for. A current name is
     * loaded through the other autoloaders and then given its legacy names at
     * once: `instanceof` and is_subclass_of() never autoload, so without this an
     * object of a moved class would fail `instanceof <old name>` until something
     * happened to mention the old name first.
     *
     * @param string $class
     *
     * @return void
     */
    public static function load($class)
    {
        $class = ltrim($class, '\\');
        $target = self::resolve($class);
        if (null !== $target) {
            if ((class_exists($target) || interface_exists($target) || trait_exists($target)) && !self::declared($class)) {
                class_alias($target, $class);
            }

            return;
        }

        if (!self::isCurrentName($class)) {
            return;
        }
        foreach (spl_autoload_functions() as $loader) {
            if (\is_array($loader) && self::class === $loader[0]) {
                continue;
            }
            if (!self::canCall($loader)) {
                continue;
            }
            $loader($class);
            if (self::declared($class)) {
                break;
            }
        }
        if (self::declared($class)) {
            self::aliasLegacyNames($class);
        }
    }

    /**
     * Give a loaded current class every legacy name that resolves to it.
     *
     * @param string $class
     *
     * @return void
     */
    public static function aliasLegacyNames($class)
    {
        $legacyNames = self::$reverse[strtolower($class)] ?? [];
        foreach (self::$prefixes as $legacy => $current) {
            if (0 === strncasecmp($class, $current, \strlen($current))) {
                $legacyNames[] = $legacy . substr($class, \strlen($current));
                break;
            }
        }
        foreach ($legacyNames as $legacyName) {
            // a legacy name the explicit maps send elsewhere is not this class's
            if (!self::declared($legacyName) && 0 === strcasecmp((string) self::resolve($legacyName), $class)) {
                class_alias($class, $legacyName);
            }
        }
    }

    /**
     * The current name a legacy FQCN stands for, or null when it is not a legacy name.
     *
     * @param string $class
     *
     * @return string|null
     */
    public static function resolve($class)
    {
        $class = ltrim($class, '\\');
        $lower = strtolower($class);
        if (isset(self::$lowerMap[$lower])) {
            return self::$lowerMap[$lower];
        }
        foreach (self::$prefixes as $legacy => $current) {
            if (0 === strncasecmp($class, $legacy, \strlen($legacy))) {
                return $current . substr($class, \strlen($legacy));
            }
        }

        return null;
    }

    /**
     * @return array<string,string>
     */
    public static function map()
    {
        return self::$map;
    }

    /**
     * @return array<string,string>
     */
    public static function prefixes()
    {
        return self::$prefixes;
    }

    /**
     * Whether a legacy FQCN is named by the explicit maps.
     *
     * @param string $class
     *
     * @return bool
     */
    public static function has($class)
    {
        return isset(self::$lowerMap[strtolower(ltrim($class, '\\'))]);
    }

    /**
     * @param string $class
     *
     * @return bool
     */
    private static function declared($class)
    {
        return class_exists($class, false) || interface_exists($class, false) || trait_exists($class, false);
    }

    /**
     * Whether this class may call an SPL loader. SPL also holds loaders only their
     * own class can call (Elementor registers a private static method), and calling
     * one from here is a fatal Error. Checked by visibility, not is_callable(): the
     * stubs type spl_autoload_functions() as callables, so static analysis reads that
     * check as always true.
     *
     * @param callable $loader
     *
     * @return bool
     */
    private static function canCall($loader)
    {
        if (!\is_array($loader)) {
            return true;
        }

        try {
            return (new \ReflectionMethod($loader[0], $loader[1]))->isPublic();
        } catch (\ReflectionException $e) {
            // No such method: the call goes through __call()/__callStatic().
            return true;
        }
    }

    /**
     * @param string $class
     *
     * @return bool
     */
    private static function isCurrentName($class)
    {
        foreach (self::$prefixes as $current) {
            if (0 === strncasecmp($class, $current, \strlen($current))) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return void
     */
    private static function listen()
    {
        if (!self::$registered) {
            // Prepended so a legacy name is resolved here before Composer looks for a
            // file that no longer exists.
            spl_autoload_register([self::class, 'load'], true, true);
            self::$registered = true;
        }
    }
}
