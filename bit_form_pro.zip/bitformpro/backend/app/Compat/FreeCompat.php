<?php

namespace BitApps\BitFormPro\Compat;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * The single Free-version gate for Bit Form Pro.
 *
 * Free and Pro upgrade independently, so a site can run a newer Pro against an
 * older Free. Historically Pro warned about that and loaded anyway — and every
 * production fatal from version skew came from exactly that path (a Free class,
 * method or constant that did not exist yet). This class replaces that with a
 * hard decision made once, in bitformpro.php, before Pro's autoloader, hooks,
 * AJAX handlers, fields or cron callbacks exist:
 *
 *   FreeCompat::satisfied() === false  →  Pro registers an admin notice and returns.
 *
 * The site then runs exactly as if Pro were deactivated, which is a state every
 * form already handles. No scattered class_exists()/method_exists() guards are
 * needed anywhere else in Pro: once the gate passes, the whole surface listed in
 * Free's Api\Compat::publicClasses() is guaranteed to exist with the pinned
 * signatures.
 *
 * When Pro starts depending on something new in Free, raise the constants below
 * in the same Pro release. That is the whole procedure.
 *
 * Deliberately dependency-free: required with require_once from the plugin main
 * file, so it works when the autoloader cannot be trusted to.
 */
final class FreeCompat
{
    /**
     * Oldest Bit Form (free) this Pro build runs against. Must equal
     * BITFORMPRO_REQUIRED_BITFORM_VERSION in bitformpro.php (the updater reads that).
     *
     * 3.5.0: Free took over usage reporting, and the App Settings toggle of an older
     * Free calls a route Pro no longer serves.
     */
    public const REQUIRED_FREE_VERSION = '3.5.0';

    /**
     * Oldest BITFORMS_API_LEVEL this Pro build runs against. Free builds that
     * predate the constant report level 0.
     *
     * Raise to 1 the moment Pro code relies on anything Free 3.4 introduced
     * (backend/app contracts, alias-resolved names, Api\Compat).
     */
    // 2: Pro's admin controllers return wp-kit Responses, which only a Free whose
    // admin normalizes them (normalizeAjaxReply.js, API level 2) can read. An older
    // Free would take every successful Pro admin reply for a failure.
    // 3: Pro reads and writes Free's tables through Free's ORM models
    // (BitApps\BitForm\Model\Form, FormEntry, …), published at level 3.
    // 4: Pro's own entry queries leave Free's trash out (Compat\EntryTrash), through
    // FormEntry::hasTriageColumns() and the IS NULL legacy condition, published at 4.
    // 5: Form Abandonment v2 listens to Free's draft and badge hooks and purges stale
    // drafts through EntryTrashService::purgeExpiredDrafts(), published at 5.
    // 6: Pro adds AI/MCP tools through Free's facade (BitApps\BitForm\Ai\ToolProvider,
    // Ai\Tools) and the `bitform_ai_tool_providers` filter, published at level 6.
    public const REQUIRED_FREE_API_LEVEL = 6;

    /**
     * @param string|null $freeVersion  defaults to BITFORMS_VERSION
     * @param int|null    $freeApiLevel defaults to BITFORMS_API_LEVEL (0 when undefined)
     *
     * @return bool
     */
    public static function satisfied($freeVersion = null, $freeApiLevel = null)
    {
        return '' === self::reason($freeVersion, $freeApiLevel);
    }

    /**
     * Why the installed Free is not acceptable, or '' when it is.
     *
     * @param string|null $freeVersion
     * @param int|null    $freeApiLevel
     *
     * @return string
     */
    public static function reason($freeVersion = null, $freeApiLevel = null)
    {
        if (null === $freeVersion) {
            if (!\defined('BITFORMS_VERSION')) {
                return 'missing';
            }
            $freeVersion = BITFORMS_VERSION;
        }
        if (null === $freeApiLevel) {
            $freeApiLevel = \defined('BITFORMS_API_LEVEL') ? (int) BITFORMS_API_LEVEL : 0;
        }

        if (version_compare((string) $freeVersion, self::REQUIRED_FREE_VERSION, '<')) {
            return 'version';
        }
        if ((int) $freeApiLevel < self::REQUIRED_FREE_API_LEVEL) {
            return 'api-level';
        }

        return '';
    }

    /**
     * Installed Free version as far as the gate can tell.
     *
     * @return string
     */
    public static function installedFreeVersion()
    {
        return \defined('BITFORMS_VERSION') ? BITFORMS_VERSION : '';
    }
}
