<?php

/**
 * Back-compat aliases for classes relocated by the backend restructure.
 *
 * Not the Free<->Pro contract — that is Compat/aliases.php, which is frozen and
 * snapshot-pinned. This map exists for a different audience: site code. A plugin
 * this old accumulates custom PHP that names internal classes directly, and
 * moving a file would otherwise turn that into a fatal on update. The classes
 * here are still internal and still not a supported API — they simply keep
 * answering to the name they had.
 *
 * Resolution is lazy (one array lookup in a prepended autoloader), so an entry
 * costs nothing until something actually asks for the old name.
 *
 * Generated from the relocation itself. Safe to shrink once the deprecation
 * window in docs/compat-surface.md has passed.
 */
return [
    'BitCode\\BitFormPro\\API\\Controller\\EntryController' => 'BitApps\\BitFormPro\\Http\\Controller\\EntryApiController',
    'BitCode\\BitFormPro\\API\\Controller\\MolliePaymentController' => 'BitApps\\BitFormPro\\Http\\Controller\\MolliePaymentController',
    'BitCode\\BitFormPro\\API\\Controller\\NoteController' => 'BitApps\\BitFormPro\\Http\\Controller\\NoteApiController',
    'BitCode\\BitFormPro\\API\\Controller\\PayPalPaymentController' => 'BitApps\\BitFormPro\\Http\\Controller\\PayPalPaymentController',
    'BitCode\\BitFormPro\\API\\Controller\\PaymentController' => 'BitApps\\BitFormPro\\Http\\Controller\\PaymentApiController',
    'BitCode\\BitFormPro\\API\\Controller\\PaymentServices' => 'BitApps\\BitFormPro\\Http\\Controller\\PaymentServices',
    'BitCode\\BitFormPro\\API\\Controller\\RazorpayPaymentController' => 'BitApps\\BitFormPro\\Http\\Controller\\RazorpayPaymentController',
    'BitCode\\BitFormPro\\API\\Controller\\StripePaymentController' => 'BitApps\\BitFormPro\\Http\\Controller\\StripePaymentController',
    'BitCode\\BitFormPro\\Admin\\Form\\ScriptFilePriorityManager' => 'BitApps\\BitFormPro\\Services\\ScriptFilePriorityManager',
    'BitCode\\BitFormPro\\Core\\Database\\DB' => 'BitApps\\BitFormPro\\Database\\Migrations\\DB',
    'BitCode\\BitFormPro\\Models\\DB' => 'BitApps\\BitFormPro\\Database\\Migrations\\DB',
    'BitCode\\BitFormPro\\Core\\Database\\EntryRelatedInfoModel' => 'BitApps\\BitFormPro\\Model\\EntryRelatedInfoModel',
    'BitCode\\BitFormPro\\Core\\Database\\FrontendViewModel' => 'BitApps\\BitFormPro\\Model\\FrontendViewModel',
    'BitCode\\BitFormPro\\Core\\Database\\GclidInfoModel' => 'BitApps\\BitFormPro\\Model\\GclidInfoModel',
    'BitCode\\BitFormPro\\Core\\Database\\LogModel' => 'BitApps\\BitFormPro\\Model\\LogModel',
    'BitCode\\BitFormPro\\Core\\Database\\PaymentInfoModel' => 'BitApps\\BitFormPro\\Model\\PaymentInfoModel',
    'BitCode\\BitFormPro\\Core\\Payment\\EntryPaymentLookup' => 'BitApps\\BitFormPro\\Services\\Payment\\EntryPaymentLookup',
    'BitCode\\BitFormPro\\Core\\Payment\\MolliePaymentSession' => 'BitApps\\BitFormPro\\Services\\Payment\\MolliePaymentSession',
    'BitCode\\BitFormPro\\Core\\Payment\\RazorpayPaymentGuard' => 'BitApps\\BitFormPro\\Services\\Payment\\RazorpayPaymentGuard',
    'BitCode\\BitFormPro\\Core\\Payment\\StripePaymentIntent' => 'BitApps\\BitFormPro\\Services\\Payment\\StripePaymentIntent',
    'BitCode\\BitFormPro\\Core\\Database\\PostInfoModel' => 'BitApps\\BitFormPro\\Model\\PostInfoModel',
    'BitCode\\BitFormPro\\Core\\Messages\\PdfMailHandler' => 'BitApps\\BitFormPro\\Services\\Messages\\PdfMailHandler',
    'BitCode\\BitFormPro\\Core\\Theme\\ThemeManager' => 'BitApps\\BitFormPro\\Services\\ThemeManager',
    'BitCode\\BitFormPro\\Core\\Update\\API' => 'BitApps\\BitFormPro\\Services\\Update\\API',
    'BitCode\\BitFormPro\\Core\\Update\\Updater' => 'BitApps\\BitFormPro\\Services\\Update\\Updater',
    'BitCode\\BitFormPro\\Core\\Util\\AddressApiKeysHelper' => 'BitApps\\BitFormPro\\Helpers\\AddressApiKeysHelper',
    'BitCode\\BitFormPro\\Core\\Util\\EntryLimitHelper' => 'BitApps\\BitFormPro\\Helpers\\EntryLimitHelper',
    'BitCode\\BitFormPro\\Core\\Util\\FormDuplicateEntry' => 'BitApps\\BitFormPro\\Helpers\\FormDuplicateEntry',
    'BitCode\\BitFormPro\\Core\\Util\\Utility' => 'BitApps\\BitFormPro\\Helpers\\Utility',
    'BitCode\\BitFormPro\\Core\\Util\\WpFileHandler' => 'BitApps\\BitFormPro\\Helpers\\WpFileHandler',
    'BitCode\\BitFormPro\\Core\\WorkFlow\\AdvancedConditionalLogic' => 'BitApps\\BitFormPro\\Workflow\\AdvancedConditionalLogic',
    'BitCode\\BitFormPro\\Core\\CronSchedule' => 'BitApps\\BitFormPro\\Providers\\CronProvider',
    'BitCode\\BitFormPro\\Core\\ProFeatureHooks' => 'BitApps\\BitFormPro\\Services\\ProFeatureHooks',
    'BitCode\\BitFormPro\\Core\\ProFieldConfigPropertiesHandler' => 'BitApps\\BitFormPro\\Services\\ProFieldConfigPropertiesHandler',
    'BitCode\\BitFormPro\\Core\\ProRestrictionHandler' => 'BitApps\\BitFormPro\\Services\\ProRestrictionHandler',
    'BitCode\\BitFormPro\\Template\\TemplateProvider' => 'BitApps\\BitFormPro\\Services\\Template\\TemplateProvider',
    'BitCode\\BitFormPro\\Admin\\Admin_Bar' => 'BitApps\\BitFormPro\\Views\\Head',
    'BitCode\\BitFormPro\\Auth\\Auth' => 'BitApps\\BitFormPro\\Services\\Auth\\Auth',
    'BitCode\\BitFormPro\\Auth\\ForgotResetPassword' => 'BitApps\\BitFormPro\\Services\\Auth\\ForgotResetPassword',
    'BitCode\\BitFormPro\\Auth\\Login' => 'BitApps\\BitFormPro\\Services\\Auth\\Login',
    'BitCode\\BitFormPro\\Auth\\Registration' => 'BitApps\\BitFormPro\\Services\\Auth\\Registration',
    'BitCode\\BitFormPro\\Auth\\UserRowAction' => 'BitApps\\BitFormPro\\Services\\Auth\\UserRowAction',
    'BitCode\\BitFormPro\\Frontend\\DoubleOptin' => 'BitApps\\BitFormPro\\Services\\Frontend\\DoubleOptin',
    'BitCode\\BitFormPro\\Frontend\\EmailOtp\\EmailOtpHandler' => 'BitApps\\BitFormPro\\Services\\Frontend\\EmailOtp\\EmailOtpHandler',
    'BitCode\\BitFormPro\\Frontend\\UserActivation' => 'BitApps\\BitFormPro\\Services\\Frontend\\UserActivation',
    'BitCode\\BitFormPro\\Admin\\BfAnalytics' => 'BitApps\\BitFormPro\\Services\\Admin\\BfAnalytics',
    'BitCode\\BitFormPro\\Admin\\BfTable\\FrontendViewHandler' => 'BitApps\\BitFormPro\\Services\\Admin\\BfTable\\FrontendViewHandler',
    'BitCode\\BitFormPro\\Admin\\BfTable\\TableMarkUp' => 'BitApps\\BitFormPro\\Services\\Admin\\BfTable\\TableMarkUp',
    'BitCode\\BitFormPro\\Admin\\DblOptin' => 'BitApps\\BitFormPro\\Services\\Admin\\DblOptin',
    'BitCode\\BitFormPro\\Admin\\FormSettings\\FormAbandonment' => 'BitApps\\BitFormPro\\Services\\Admin\\FormSettings\\FormAbandonment',
    'BitCode\\BitFormPro\\Admin\\FormSettings\\StandaloneForm' => 'BitApps\\BitFormPro\\Services\\Admin\\FormSettings\\StandaloneForm',
];
