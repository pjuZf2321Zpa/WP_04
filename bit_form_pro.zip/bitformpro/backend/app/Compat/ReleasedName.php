<?php

namespace BitApps\BitFormPro\Compat;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Services\ProFeatureHooks;
use BitApps\BitFormPro\Services\ProFieldConfigPropertiesHandler;
use BitApps\BitFormPro\Services\ProRestrictionHandler;
use BitApps\BitFormPro\Services\Frontend\EmailOtp\EmailOtpHandler;
use BitApps\BitFormPro\Workflow\AdvancedConditionalLogic;

/**
 * The class name a hook callback was registered under in released Bit Form Pro.
 *
 * WordPress keys a `[Class, 'method']` registration by the class string exactly
 * as written, so `remove_filter()` in site code only finds a callback registered
 * under the same string. Every callback a release registered with a static class
 * callable is still registered under its released name, which resolves to the
 * current class through the alias maps; the class itself is free to move.
 *
 * Keys are current classes (a move updates them); values are frozen strings from
 * the last release and must never be edited. Mirrors Free's Compat\ReleasedName.
 */
final class ReleasedName
{
    private const NAMES = [
        ProFeatureHooks::class                 => 'BitCode\BitFormPro\Core\ProFeatureHooks',
        ProFieldConfigPropertiesHandler::class => 'BitCode\BitFormPro\Core\ProFieldConfigPropertiesHandler',
        ProRestrictionHandler::class           => 'BitCode\BitFormPro\Core\ProRestrictionHandler',
        AdvancedConditionalLogic::class        => 'BitCode\BitFormPro\Core\WorkFlow\AdvancedConditionalLogic',
        EmailOtpHandler::class                 => 'BitCode\BitFormPro\Frontend\EmailOtp\EmailOtpHandler',
    ];

    /**
     * @param class-string $class
     *
     * @return string
     */
    public static function of($class)
    {
        return self::NAMES[ltrim($class, '\\')] ?? $class;
    }

    /**
     * @return array<string,string> current class => released name
     */
    public static function all()
    {
        return self::NAMES;
    }
}
