<?php

namespace BitApps\BitFormPro\Helpers;

use BitApps\BitForm\Model\FormEntry;

/**
 * Entry Limit Helper Class
 * This class handles all advanced entry limit functionality
 */
class EntryLimitHelper
{
    private $formId;
    private $settings;
    private $enabled;

    public function __construct($formId, $settings, $enabled)
    {
        $this->formId = $formId;
        $this->settings = $settings;
        $this->enabled = $enabled;
    }

    /**
     * Check all entry limits and return restriction messages
     */
    public function checkAllLimits($ipAddress, $currentUserId)
    {
        $restrictionMessages = [];

        // Check submission count limits
        if ($this->isEnabled('entry_limit')) {
            $message = $this->checkSubmissionCountLimit();
            if ($message) {
                $restrictionMessages[] = $message;
            }
        }

        // Check per user limits
        if ($this->isEnabled('entry_limit_by_user')) {
            $message = $this->checkPerUserLimit($ipAddress, $currentUserId);
            if ($message) {
                $restrictionMessages[] = $message;
            }
        }
        return $restrictionMessages;
    }

    /**
     * Check submission count limit
     */
    private function checkSubmissionCountLimit()
    {
        $limit = intval($this->getSetting('entry_limit'));
        $type = $this->normalizeTimeframe($this->getSetting('entry_limit_count_type', 'total'));
        $message = $this->getSettingMessages('entry_limit_message', __('Sorry! Submission limit exceeded.', 'bitformpro'));

        if (!$limit) {
            return null;
        }

        $count = $this->getSubmissionCountByType($type);

        if ($count >= $limit) {
            return apply_filters(
                'bitform_filter_restriction_entry_limit_message',
                $message,
                $this->formId,
            );
        }

        return null;
    }

    /**
     * Check per user limit
     */
    private function checkPerUserLimit($ipAddress, $currentUserId)
    {
        $limit = intval($this->getSetting('entry_limit_by_user'));
        $userType = $this->normalizeUserType($this->getSetting('entry_limit_by_user_type', 'per_user_ip'));
        $timeframe = $this->normalizeTimeframe($this->getSetting('entry_limit_by_user_count_type', 'total'));
        $message = $this->getSettingMessages('entry_limit_per_user_message', __('Sorry! You have exceeded the submission limit.', 'bitformpro'));

        if (!$limit) {
            return null;
        }

        $count = 0;
        if ('per_user_ip' === $userType) {
            $count = $this->getSubmissionCountByUserAndType('per_user_ip', $ipAddress, $timeframe);
        } elseif ('per_user_id' === $userType && $currentUserId > 0) {
            $count = $this->getSubmissionCountByUserAndType('per_user_id', $currentUserId, $timeframe);
        } elseif ('per_user_id' === $userType && 0 === $currentUserId) {
            // Skip check for guests when logged-in user restriction is selected.
            return null;
        }

        if ($count >= $limit) {
            return apply_filters(
                'bitform_filter_restriction_entry_limit_message',
                $message,
                $this->formId,
            );
        }

        return null;
    }

    /**
     * Get submission count by type
     */
    private function getSubmissionCountByType($type)
    {
        $condition = ['form_id' => $this->formId];
        $this->addTimeCondition($condition, $type);

        // A failed count reads as 0, as the legacy count's error did here.
        return FormEntry::countWhere($condition);
    }

    /**
     * Get submission count by user and timeframe
     */
    private function getSubmissionCountByUserAndType($userType, $userValue, $timeframe)
    {
        $condition = ['form_id' => $this->formId];

        if ('per_user_ip' === $userType) {
            $userIp = Utility::ipStorageValue($userValue);
            if ('' === $userIp) {
                return 0;
            }
            $condition['user_ip'] = $userIp;
        } elseif ('per_user_id' === $userType) {
            $condition['user_id'] = $userValue;
        } else {
            return 0;
        }

        $this->addTimeCondition($condition, $timeframe);

        // A failed count reads as 0, as the legacy count's error did here.
        return FormEntry::countWhere($condition);
    }

    /**
     * Add time-based condition
     */
    private function addTimeCondition(&$condition, $timeframe)
    {
        if ('total' === $timeframe) {
            return;
        }

        $intervals = [
            'per_minute' => '-1 minute',
            'per_hour'   => '-1 hour',
            'per_day'    => '-1 day',
            'per_week'   => '-1 week',
            'per_month'  => '-1 month',
            'per_year'   => '-1 year',
        ];

        if (isset($intervals[$timeframe])) {
            $condition['created_at'] = [
                'operator' => '>=',
                'value'    => self::windowStart($intervals[$timeframe]),
            ];
        }
    }

    /**
     * Window start in site time, matching created_at (MySQL NOW() uses the DB timezone).
     *
     * @param string $modifier DateTime modifier, e.g. "-1 day"
     *
     * @return string Y-m-d H:i:s
     */
    private static function windowStart($modifier)
    {
        return (new \DateTimeImmutable('now', wp_timezone()))->modify($modifier)->format('Y-m-d H:i:s');
    }

    private function normalizeUserType($userType)
    {
        if ('per_user_id' === $userType) {
            return 'per_user_id';
        }

        return in_array($userType, ['per_user_ip', 'per_user_id'], true) ? $userType : 'per_user_ip';
    }

    private function normalizeTimeframe($timeframe)
    {
        $allowed = ['total', 'per_minute', 'per_hour', 'per_day', 'per_week', 'per_month', 'per_year'];

        return in_array($timeframe, $allowed, true) ? $timeframe : 'total';
    }

    private function isEnabled($key)
    {
        return isset($this->enabled->{$key}) && $this->enabled->{$key};
    }

    private function getSetting($key, $default = null)
    {
        return $this->settings->{$key}
            ?? $default;
    }

    private function getSettingMessages($key, $default = null)
    {
        return $this->settings->messages->{$key}
            ?? $default;
    }
}
