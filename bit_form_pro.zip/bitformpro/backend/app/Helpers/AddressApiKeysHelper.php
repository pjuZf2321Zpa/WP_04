<?php

namespace BitApps\BitFormPro\Helpers;

/**
 * Single source of truth for the global address field API keys
 * (Google Maps / Mapbox) stored under one wp_options row.
 */
class AddressApiKeysHelper
{
    public const OPTION_NAME = 'bitforms_address_api_keys';

    /**
     * @return array{google_maps_api_key:string, mapbox_token:string}
     */
    public static function getKeys(): array
    {
        $keys = get_option(self::OPTION_NAME, []);
        if (!is_array($keys)) {
            $keys = [];
        }
        return [
            'google_maps_api_key' => isset($keys['google_maps_api_key']) ? $keys['google_maps_api_key'] : '',
            'mapbox_token'        => isset($keys['mapbox_token']) ? $keys['mapbox_token'] : '',
        ];
    }

    public static function saveKeys(string $googleApiKey, string $mapboxToken): array
    {
        $keys = [
            'google_maps_api_key' => $googleApiKey,
            'mapbox_token'        => $mapboxToken,
        ];
        update_option(self::OPTION_NAME, $keys);
        return $keys;
    }

    public static function getGoogleApiKey(): string
    {
        return self::getKeys()['google_maps_api_key'];
    }

    public static function getMapboxToken(): string
    {
        return self::getKeys()['mapbox_token'];
    }
}
