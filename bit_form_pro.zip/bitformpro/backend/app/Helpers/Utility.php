<?php

namespace BitApps\BitFormPro\Helpers;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

class Utility
{
    public static function loadFile($path, $data)
    {
        $file = BITFORMPRO_PLUGIN_DIR_PATH . $path . '.php';

        extract($data);

        ob_start();

        include($file);

        return ob_get_clean();

    }

    public static function view($path, $data = [])
    {

        status_header(200);

        echo self::loadFile($path, $data);

        exit(200);

    }

    /**
     * First row of a Model/get() style result, or null when the lookup failed
     * (WP_Error), returned an empty set, or has no index 0. Prevents
     * "Attempt to read property on null" when dereferencing $result[0]->col.
     *
     * Defined here (not reused from the free plugin's Utilities) so the Pro
     * addon never hard-depends on a method that may be absent if Pro is
     * updated before the free plugin.
     *
     * @param mixed $result
     * @return object|null
     */
    public static function firstRow($result)
    {
        if (is_wp_error($result) || empty($result) || !isset($result[0])) {
            return null;
        }
        return $result[0];
    }

    /**
     * Decode a JSON string to an object, guaranteed object|null so downstream
     * `$obj->prop ?? default` reads never emit an undefined-property warning.
     * Returns null for non-strings, empty strings and malformed JSON.
     *
     * @param mixed $json
     * @return object|null
     */
    public static function jsonObj($json)
    {
        if (!is_string($json) || '' === $json) {
            return null;
        }
        $decoded = JSON::decode($json);
        return is_object($decoded) ? $decoded : null;
    }

    /**
     * Copy of the Free guard (skew): hosts disable ignore_user_abort in php.ini, PHP 8 then fatals on the call.
     *
     * @param bool $ignore
     * @return void
     */
    public static function ignoreUserAbort($ignore = true)
    {
        if (\function_exists('ignore_user_abort')) {
            \ignore_user_abort($ignore);
        }
    }

    /**
     * Copy of Free's IpTool::storageValue() (Pro may ship first).
     *
     * @param mixed $ip IP address
     *
     * @return string '' when $ip is not a valid address
     */
    public static function ipStorageValue($ip)
    {
        if (!is_string($ip) || false === filter_var($ip, FILTER_VALIDATE_IP)) {
            return '';
        }
        if (false !== filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return sprintf('%u', ip2long($ip));
        }
        $packed = inet_pton($ip);

        return false === $packed ? '' : (string) inet_ntop($packed);
    }
}
