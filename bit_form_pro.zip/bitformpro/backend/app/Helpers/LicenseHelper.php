<?php

namespace BitApps\BitFormPro\Helpers;

class LicenseHelper
{
    public static function getLicenseData()
    {
        if (is_multisite() && !is_main_site()) {
            $data = get_option('bitformpro_integrate_key_data');
            if (!empty($data) && is_array($data)) {
                return $data;
            }
            return get_blog_option(get_main_site_id(), 'bitformpro_integrate_key_data');
        }
        return get_option('bitformpro_integrate_key_data');
    }

    /**
     * Whole calendar days left on the license, counted in the site timezone.
     *
     * `expireIn` is a date with no time part (`Y-m-d`) and the license stays valid through
     * the end of that day, so dates are compared rather than timestamps: timestamp math
     * floors to 0 at midnight and reports the final day as already expired.
     *
     * @param string|null $expireIn expiry date; read from the stored license data when null
     *
     * @return int|null days left (0 on the expiry day, negative once past), null if unknown
     */
    public static function daysUntilExpiry($expireIn = null)
    {
        if (null === $expireIn) {
            $licenseData = self::getLicenseData();
            $expireIn = (is_array($licenseData) && !empty($licenseData['expireIn'])) ? $licenseData['expireIn'] : '';
        }

        if (empty($expireIn) || !is_string($expireIn)) {
            return null;
        }

        try {
            $expiryDay = (new \DateTimeImmutable($expireIn, wp_timezone()))->setTime(0, 0, 0);
        } catch (\Exception $e) {
            return null;
        }

        $today = current_datetime()->setTime(0, 0, 0);

        return (int) $today->diff($expiryDay)->format('%r%a');
    }

    public static function hasValidLicense(): bool
    {
        $integrateData = self::getLicenseData();

        return !empty($integrateData)
            && is_array($integrateData)
            && !empty($integrateData['status'])
            && 'success' === $integrateData['status'];
    }
}
