<?php

namespace BitApps\BitFormPro\Providers;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Ai\AiTools;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitFormPro\Views\Head;
use BitApps\BitFormPro\Services\Admin\BfAnalytics;
use BitApps\BitFormPro\Services\Admin\BfTable\FrontendViewHandler;
use BitApps\BitFormPro\Services\Admin\DblOptin;
use BitApps\BitFormPro\Http\Controller\MolliePaymentController;
use BitApps\BitFormPro\Services\Auth\Auth;
use BitApps\BitFormPro\Services\Auth\UserRowAction;
use BitApps\BitFormPro\Services\Messages\PdfMailHandler;
use BitApps\BitFormPro\Services\ProFeatureHooks;
use BitApps\BitFormPro\Services\ProFieldConfigPropertiesHandler;
use BitApps\BitFormPro\Services\ProRestrictionHandler;
use BitApps\BitFormPro\Services\Update\Updater;
use BitApps\BitFormPro\Helpers\FormDuplicateEntry;
use BitApps\BitFormPro\Workflow\AdvancedConditionalLogic;
use BitApps\BitFormPro\Services\Frontend\DoubleOptin;
use BitApps\BitFormPro\Services\Entry\EntryTimelineEvents;
use BitApps\BitFormPro\Services\Abandonment\AbandonmentHooks;
use BitApps\BitFormPro\Services\Frontend\UserActivation;
use BitApps\BitFormPro\Integration\Integrations;
use BitApps\BitFormPro\Plugin;
// Deliberately the LEGACY Free FQCN, not BitApps\BitForm\Http\RequestType: Pro
// supports Free down to FreeCompat::REQUIRED_FREE_VERSION, and the relocated name
// only exists in Free 3.4+. Newer Free answers this name through its AliasLoader.
// The rule is: Pro may only name symbols present in the OLDEST supported Free.
use BitApps\BitForm\Http\RequestType;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\RequestType as KitRequestType;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Router;
use BitApps\BitFormPro\Services\Frontend\EmailOtp\EmailOtpHandler;
use BitApps\BitFormPro\Http\LegacyAjaxReply;
use BitApps\BitFormPro\Http\Middleware\AdminCheckerMiddleware;
use BitApps\BitFormPro\Config;
use BitApps\BitFormPro\Compat\ReleasedName;

/**
 * Every hook Bit Form Pro registers, in one place.
 *
 * Called once from Plugin::initialize(). Reaching this file at all means the
 * Free-version gate in bitformpro.php passed, so Free is at least
 * FreeCompat::REQUIRED_FREE_VERSION — but that floor is currently the same 3.2.1
 * Pro already required, so the two pre-existing skew guards below stay until the
 * floor is raised to a Free that is known to carry those symbols. See
 * Support\FreeCompat and bitform/docs/compat-surface.md.
 *
 * The Plugin instance is passed in rather than reached for statically: several
 * callbacks are bound as `[$plugin, 'method']`, and WordPress keys a registration
 * by its callable, so binding them to the same object keeps `remove_action()`
 * working exactly as before the restructure.
 */
final class HookProvider
{
    /** @var Plugin */
    private $plugin;

    public function __construct(Plugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function register()
    {
        // Pro Features Hooks registration
        ProRestrictionHandler::register();
        ProFeatureHooks::register();
        ProFieldConfigPropertiesHandler::register();
        AdvancedConditionalLogic::register();
        // Free fires bitform_entry_timeline_events and never reads a Pro table;
        // this is the other half of that contract.
        EntryTimelineEvents::register();
        AbandonmentHooks::register();

        add_action('wp_initialize_site', [$this->plugin, 'initializeNewSite']);
        add_action('init', [$this->plugin, 'localization_setup']);
        // Bound to the Plugin instance, not self: that is the callable this hook
        // carried before the restructure, and remove_action() keys on it.
        // Plugin::init_classes() delegates straight back here.
        add_action('init', [$this->plugin, 'init_classes'], 10);
        add_action('init', [$this->plugin, 'handleVersionUpdateFallback']);
        add_filter('plugin_action_links_' . plugin_basename(BITFORMPRO_PLUGIN_MAIN_FILE), [$this->plugin, 'plugin_action_links']);
        add_filter('bitform_dynamic_field_filter', [$this->plugin, 'dynamicFieldValues'], 10, 8);
        add_action('rest_api_init', [$this->plugin, 'register_api'], 10);
        add_action('bitform_double_optin_confirmation', [new DblOptin(), 'sendEntryMailConfirmation'], 10, 2);
        add_filter('bitform_email_body_text', [new DblOptin(), 'updatedEmailBodyMessage'], 10, 2);
        add_filter('bitform_generate_pdf_attachment', [new PdfMailHandler(), 'generateAttachment'], 10, 4);
        // Bit Form owns usage reporting; Pro fills in the data of its own tables.
        add_filter(BITFORMS_PREFIX . 'telemetry_additional_data', [new BfAnalytics(), 'addProUsageData'], 10, 1);
        // AI & MCP: entry tools through Free's facade (Free API level 6).
        add_filter('bitform_ai_tool_providers', [AiTools::class, 'providers'], 10, 1);

        if (version_compare(BITFORMS_VERSION, '2.13.2', '>=') && class_exists('\BitApps\BitForm\Config')) {
            add_filter(\BitApps\BitForm\Config::VAR_PREFIX . 'telemetry_data', [Plugin::class, 'telemetryProStatus'], 10, 1);
        }

        // form run workflow after mollie payment success
        add_action('bitform_deferred_mollie_payment_workflow', function ($paymentDetails) {
            wp_schedule_single_event(time(), 'bitform_run_mollie_payment_workflow', [$paymentDetails], true);
        });

        add_action('bitform_run_mollie_payment_workflow', function ($paymentDetails) {
            $service = new MolliePaymentController();
            $service->saveMolliePaymentInfo($paymentDetails);
        });
    }

    /**
     * Per-request wiring, on `init`.
     *
     * @return void
     */
    public static function init_classes()
    {
        if (!empty($_GET['bf_activation_key']) && !empty($_GET['bf_f_id']) && !empty($_GET['bf_user_id'])) {
            (new UserActivation($_GET['bf_activation_key'], $_GET['bf_f_id'], $_GET['bf_user_id']))->emailVerified();
        }
        if (!empty($_GET['bf_user_approve_key']) && !empty($_GET['bf_f_id']) && !empty($_GET['bf_user_id'])) {
            (new UserActivation($_GET['bf_user_approve_key'], $_GET['bf_f_id'], $_GET['bf_user_id']))->userApproveByAdmin();
        }
        if (!empty($_GET['bf_user_reject_key']) && !empty($_GET['bf_f_id']) && !empty($_GET['bf_user_id'])) {
            (new UserActivation($_GET['bf_user_reject_key'], $_GET['bf_f_id'], $_GET['bf_user_id']))->userRejectByAdmin();
        }
        if (!empty($_GET['token']) && !empty($_GET['entry_id'])) {
            // Confirming runs the deferred integrations, so it must wait until every plugin
            // has finished init — Bit CRM Pro wires its custom-field hooks at init:11 and
            // leads created earlier silently lose their custom field values.
            add_action('wp_loaded', [self::class, 'confirmDoubleOptinEntry']);
        }

        // Guard the Free request-context router: if an out-of-date/absent Free build lacks
        // this class, degrade gracefully instead of fataling (Pro loads warn-only on skew).
        if (class_exists(RequestType::class)) {
            if (RequestType::Check('admin')) {
                (new Head())->register();
                new Updater();
            }
            if (RequestType::Check('frontend')) {
                new FrontendViewHandler();
            }
            if (RequestType::Check('ajax')) {
                self::loadAppAjaxHooks();
            }
        }

        (new Integrations())->registerHooks();
        (new CronProvider())->cron_schedule();
        (new FormDuplicateEntry())->register();
        (new Auth())->register();
        (new DblOptin())->deletedUnconfirmedEntries();

        if (method_exists('BitApps\BitForm\Integrations\IntegrationHandler', 'getIntegrationWithoutFormId')) {
            $existAuth = (new IntegrationHandler(0))->getIntegrationWithoutFormId('wp_user_auth', 'wp_auth', 1);
            if (!is_wp_error($existAuth) && !isset($existAuth->errors['result_empty'])) {
                (new UserRowAction())->userRowAction();
            }
        }
    }

    /**
     * Confirm a double opt-in entry from the email link, then run its deferred
     * mails and integrations.
     *
     * @return void
     */
    public static function confirmDoubleOptinEntry()
    {
        (new DoubleOptin($_GET['entry_id'], $_GET['token']))->approvedEntryByEmail();
    }

    /** Route tables under backend/hooks/ and the action prefix each is built with. */
    public const TABLES = [
        'ajax-public.php'               => 'bitforms_',
        'ajax.php'                      => 'bitforms_',
        'ajax-theme.php'                => 'bitform_',
        'ajax-integrations.php'         => 'bitforms_',
        'ajax-integrations-bitform.php' => 'bitform_',
    ];

    /**
     * Registers Pro's `bitform/v1` REST routes from backend/hooks/api.php, on
     * `rest_api_init` (reached through Plugin::register_api(), the callback
     * released Pro bound there).
     *
     * @return void
     */
    public static function loadAppApiHooks()
    {
        $table = self::hooksFile('api.php');
        if (!is_readable($table)) {
            return;
        }
        // The OAuth returns are wp-kit Routes on this Router; the data API and the
        // payment callbacks in the same file stay native register_rest_route.
        $router = new Router(KitRequestType::API, 'bitform', 'v1');
        $router->setMiddlewares(Plugin::middlewares());
        include $table;
        $router->register();
    }

    /**
     * Builds Pro's AJAX surface for the current request from the route tables,
     * as in the boilerplate (bit-pi, bit-crm) and Free's HookProvider: one wp-kit
     * Router per table that tablesForCurrentRequest() names.
     *
     * @return void
     */
    public static function loadAppAjaxHooks()
    {
        foreach (self::tablesForCurrentRequest() as $table) {
            self::registerTable($table);
        }
        if (RequestType::Check('ajax')) {
            // The email-OTP checks on submit go with the public table's OTP routes.
            add_filter('bitform_filter_form_validation', [ReleasedName::of(EmailOtpHandler::class), 'validateOnSubmit'], 10, 2);
            add_filter('bitform_filter_save_form_entry', [ReleasedName::of(EmailOtpHandler::class), 'stripOtpFromSaveEntry'], 10, 2);
            add_filter('bitform_filter_update_form_entry', [ReleasedName::of(EmailOtpHandler::class), 'stripOtpFromUpdateEntry'], 10, 2);
        }
    }

    /**
     * Which route tables apply to the current request: the public table for any
     * AJAX request, the admin, theme and integration tables only for a user who
     * may manage Bit Form.
     *
     * @return string[] table basenames
     */
    public static function tablesForCurrentRequest()
    {
        $tables = [];
        if (RequestType::Check('ajax')) {
            $tables[] = 'ajax-public.php';
        }
        if (self::servesAdminRoutes()) {
            $tables[] = 'ajax.php';
            $tables[] = 'ajax-theme.php';
            $tables[] = 'ajax-integrations.php';
            $tables[] = 'ajax-integrations-bitform.php';
        }

        return $tables;
    }

    /**
     * The routes a table declares, without binding any of them.
     *
     * @param string $file basename under backend/hooks/
     *
     * @return array<string,bool> action name => registered for logged-out visitors
     */
    public static function declaredRoutes($file)
    {
        return array_map(
            function ($route) {
                return $route['noAuth'];
            },
            self::describeRoutes($file),
        );
    }

    public static function describeRoutes($file)
    {
        $prefix = self::TABLES[$file];
        $router = new Router(KitRequestType::AJAX, $prefix, '');
        self::includeTable($file);

        $routes = [];
        foreach ($router->getRoutes() as $route) {
            $routes[$prefix . $route->getRoutePrefix() . $route->getPath()] = [
                'noAuth'     => (bool) $route->isNoAuth(),
                'methods'    => array_values($route->getMethods()),
                'middleware' => array_values((array) $route->getMiddleware()),
            ];
        }

        return $routes;
    }

    /**
     * Include a route table into a fresh Router and bind its routes.
     *
     * @param string $file basename under backend/hooks/
     *
     * @return Router
     */
    public static function registerTable($file)
    {
        $router = new Router(KitRequestType::AJAX, self::TABLES[$file], '');
        $router->setMiddlewares(Plugin::middlewares());
        self::includeTable($file);
        // Public routes serve published forms: a handler that replies nothing must
        // keep answering admin-ajax.php's `0`. Admin routes follow the boilerplate
        // and answer with wp-kit Responses.
        if ('ajax-public.php' === $file) {
            LegacyAjaxReply::applyToRequestedRoute($router, self::TABLES[$file]);
        }
        if (self::isCanonicalAction(self::TABLES[$file])) {
            $router->register();
        }

        return $router;
    }

    public static function isCanonicalAction($prefix)
    {
        $action = isset($_REQUEST['action']) ? sanitize_text_field(wp_unslash($_REQUEST['action'])) : '';

        return 0 === strpos($action, $prefix) && false === strpos($action, $prefix, strlen($prefix));
    }

    /**
     * @return bool
     */
    private static function servesAdminRoutes()
    {
        return RequestType::Check('admin') && AdminCheckerMiddleware::allows();
    }

    /**
     * Plain `include`, not wp-kit's registerFile(): that uses include_once, so a
     * second Router built in the same process (every test dispatch) would see an
     * empty table.
     *
     * @param string $file
     *
     * @return void
     */
    private static function includeTable($file)
    {
        $table = self::hooksFile($file);
        if (is_readable($table)) {
            include $table;
        }
    }

    /**
     * @param string $file basename under backend/hooks/
     *
     * @return string
     */
    private static function hooksFile($file)
    {
        return Config::get('BASEDIR') . DIRECTORY_SEPARATOR . 'hooks' . DIRECTORY_SEPARATOR . $file;
    }
}
