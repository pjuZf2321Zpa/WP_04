<?php

namespace BitApps\BitFormPro\Providers;

if (!defined('ABSPATH')) {
    exit;
}


use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitFormPro\Integration\Gclid\ApiHelper;
use BitApps\BitFormPro\Model\GclidInfoModel;
use BitApps\BitFormPro\Helpers\LicenseHelper;
use BitApps\BitFormPro\Integration\Gclid\GclidHandler;
use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

/**
 * Class handling plugin activation.
 *
 * @since 1.0.0
 */
final class CronProvider
{
    public function cron_schedule()
    {
        add_action('gclid_cron_event', [$this, 'get_gclid_info']);
    }

    public function get_gclid_info()
    {
        $license = LicenseHelper::getLicenseData();
        $licenseKey = (is_array($license) && !empty($license['key'])) ? $license['key'] : '';
        $integrationHandler = new IntegrationHandler(0, IpTool::getUserDetail());
        $googleDetails = $integrationHandler->getAllIntegration('app', 'Google');
        $gclidModel = new GclidInfoModel();
        $googleDetailsRow = Utility::firstRow($googleDetails);
        if (!isset($googleDetails->errors['result_empty']) && $googleDetailsRow) {
            $newDetails = Utility::jsonObj($googleDetailsRow->integration_details ?? '');
            $requiredParams = [];
            $requiredParams['clientId'] = $newDetails->clientId ?? '';
            $requiredParams['clientSecret'] = $newDetails->clientSecret ?? '';
            $requiredParams['tokenDetails'] = $newDetails->tokenDetails ?? '';
            $newTokenDetails = GclidHandler::_refreshAccessToken((object) $requiredParams);
            $apiHelper = new ApiHelper($newTokenDetails, $newDetails->clientCustomerId ?? '', $licenseKey);
            $response = $apiHelper->getGclidInfo();
            $xml_data = simplexml_load_string($response->data);
            $json = json_encode($xml_data);
            $gclidReports = JSON::decode($json, true);
            if (isset($gclidReports['ApiError'])) {
                $apiType = "error";
                $responseObj = $gclidReports['ApiError']['type'];
                $gclidModel->gclidApiLogInsert(['log_type' => 'gclid', 'response_type' => $apiType, 'response_obj' => $responseObj]);
            } else {
                $gclidModel->gclidApiLogInsert(['log_type' => 'gclid', 'response_type' => 'success', 'response_obj' => 'success']);
                foreach ($gclidReports['table']['row'] as $report) {
                    $gclidModel->gclidResponseInsert($report['@attributes']['googleClickID'], json_encode($report));
                }
            }
        }
    }
}
