<?php

namespace BitApps\BitFormPro\Providers;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Database\Migrations\DB;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;

/**
 * Pro's schema migrations, run through wp-kit as in Free and bit-pi.
 *
 * Activation itself stays in bitformpro.php: it runs before Pro's loader, so it
 * loads Pro's Composer autoloader itself and calls DB::migrate() directly.
 */
final class InstallerProvider
{
    /**
     * Run the schema migration when the stored schema version is behind.
     *
     * Admin-gated, as it always was: an upgrade runs on the first admin request.
     * The frontend read path's own guard (DB::ensurePdfConfigColumn, run from
     * Plugin::handleVersionUpdateFallback) covers requests before that.
     *
     * @return void
     */
    public static function migrateIfNeeded()
    {
        if (!Capabilities::check('manage_options')) {
            return;
        }

        global $bitformspro_db_version;
        if (get_option('bitformspro_db_version') != $bitformspro_db_version) {
            DB::migrate();
        }
    }

    /**
     * The schema migrations wp-kit runs, in order — see DB::migrations().
     *
     * @return array{path: string, migrations: string[]}
     */
    public static function migrations()
    {
        return DB::migrations();
    }
}
