<?php

namespace BitApps\BitFormPro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides app configuration — the one place a path, URL, prefix or version is
 * worked out, as in bit-connect's Config.
 *
 * The `BITFORMPRO_*` constants are still defined (backend/bootstrap.php) because
 * Free and site code read them; they are set *from* this class. The version and
 * main-file constants come from bitformpro.php, which needs them before the
 * autoloader to evaluate the Free compatibility gate.
 */
final class Config
{
    public const SLUG = 'bitformpro';

    public const TITLE = 'Bit Form Pro';

    public const VAR_PREFIX = 'bitformpro_';

    public const VERSION = BITFORMPRO_VERSION;

    public const DB_VERSION = BITFORMPRO_DB_VERSION;

    public const REQUIRED_FREE_VERSION = BITFORMPRO_REQUIRED_BITFORM_VERSION;

    /** The plugin main file, relative to this directory. */
    public const APP_BASE = '../../bitformpro.php';

    /**
     * Provides configuration for plugin.
     *
     * @param string $type    Type of conf
     * @param mixed  $default Default value
     *
     * @return mixed
     */
    public static function get($type, $default = null)
    {
        switch ($type) {
            case 'MAIN_FILE':
                return realpath(__DIR__ . DIRECTORY_SEPARATOR . self::APP_BASE);

            case 'BASENAME':
                return plugin_basename(self::get('MAIN_FILE'));

            case 'ROOT_DIR':
                return plugin_dir_path(self::get('MAIN_FILE'));

            case 'BASEDIR':
                return self::get('ROOT_DIR') . 'backend';

            case 'ROOT_URI':
                return set_url_scheme(plugins_url('', self::get('MAIN_FILE')), wp_parse_url(home_url())['scheme']);

            case 'ASSET_URI':
                return self::get('ROOT_URI') . '/assets';

            default:
                return $default;
        }
    }

    /**
     * Prefixed variable name with prefix.
     *
     * @param string $option Variable name
     *
     * @return string
     */
    public static function withPrefix($option)
    {
        return self::VAR_PREFIX . $option;
    }

    /**
     * Retrieves options from option table.
     *
     * @param string $option  Option name
     * @param mixed  $default default value
     *
     * @return mixed
     */
    public static function getOption($option, $default = false)
    {
        return get_option(self::withPrefix($option), $default);
    }

    /**
     * Save or update option to option table.
     *
     * @param string $option Option name
     * @param mixed  $value  Option value
     *
     * @return bool
     */
    public static function updateOption($option, $value)
    {
        return update_option(self::withPrefix($option), $value);
    }
}
