<?php

namespace BitApps\BitFormPro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main class for the plugin.
 *
 * @since 1.0.0-alpha
 */

use BitApps\BitFormPro\Http\Middleware\AdminCheckerMiddleware;
use BitApps\BitFormPro\Http\Middleware\EntryEditorCheckerMiddleware;
use BitApps\BitFormPro\Http\Middleware\JsonBodyCheckerMiddleware;
use BitApps\BitFormPro\Http\Middleware\NonceCheckerMiddleware;
use BitApps\BitFormPro\Http\Controller\MolliePaymentController;
use BitApps\BitFormPro\Providers\HookProvider;
use BitApps\BitFormPro\Providers\InstallerProvider;
use BitApps\BitFormPro\Database\Migrations\DB;
use BitApps\BitFormPro\Model\PostInfoModel;
use BitApps\BitFormPro\Helpers\LicenseHelper;
use WP_Error;
use WP_Site;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;
use BitApps\BitForm\Model\Form;

final class Plugin
{
    /**
     * Main instance of the plugin.
     *
     * @since 1.0.0-alpha
     * @var   Plugin|null
     */
    private static $instance = null;

    /**
     * The middleware registry Pro's route tables refer to by name.
     *
     * wp-kit resolves `->middleware('nonce', 'isAdmin:manage_options')` through this
     * map: the part before the colon is the key, the rest is passed to handle().
     *
     * @return array<string,class-string>
     */
    public static function middlewares()
    {
        return [
            'nonce'         => NonceCheckerMiddleware::class,
            'isAdmin'       => AdminCheckerMiddleware::class,
            'isEntryEditor' => EntryEditorCheckerMiddleware::class,
            'jsonBody'      => JsonBodyCheckerMiddleware::class,
        ];
    }

    /**
     * Initialize the hooks
     *
     * @return void
     */
    public function initialize()
    {
        (new HookProvider($this))->register();
    }

    /**
     * Registers the bundled translations directory for the `bitformpro` text domain.
     *
     * WordPress only searches WP_LANG_DIR/plugins and WP_LANG_DIR/themes when
     * loading a text domain just in time; a plugin's own /languages directory is
     * consulted only after load_plugin_textdomain() has registered it as a custom
     * path. That matters more here than in Free: Pro ships outside wordpress.org,
     * so there are no language packs to fall back on and this call is the only
     * way any of the bundled catalogs ever load.
     *
     * Runs on `init` — earlier triggers the "loaded too early" notice added in 6.7.
     *
     * @return void
     */
    public function localization_setup()
    {
        /**
         * Filters whether Bit Form Pro loads its bundled translations at all.
         *
         * Returning false leaves every Pro string untranslated. Deliberately the
         * same filter the free plugin uses, not a `bitformpro_`-prefixed twin: a
         * site that opts out of Bit Form's bundled catalogs wants the Pro ones
         * gone too, and one switch is the whole contract. Anything that needs to
         * tell the two apart can read the current text domain.
         *
         * @param bool $allow Whether to load translations. Default true.
         */
        if (!apply_filters('bitform_filter_allow_translation', true)) {
            return;
        }

        load_plugin_textdomain('bitformpro', false, \dirname(BITFORMPRO_PLUGIN_BASENAME) . '/languages');
    }

    /**
     * Initialize the new site in multisite
     *
     * @param WP_Site $site Site object
     *
     * @return void
     */
    public function initializeNewSite(WP_Site $site)
    {
        switch_to_blog($site->blog_id);
        $plugin = plugin_basename(BITFORMPRO_PLUGIN_MAIN_FILE);
        if (!is_plugin_active_for_network($plugin)) {
            bitformpro_single_site_activation();
        }
        restore_current_blog();
    }

    /**
     * Instantiate the required classes
     *
     * @deprecated Registration moved to Providers\HookProvider::init_classes();
     *             kept because it was public and reachable before the restructure.
     *
     * @return void
     */
    public function init_classes()
    {
        HookProvider::init_classes();
    }

    /**
     * `rest_api_init` callback, bound to this instance as released Pro bound it;
     * the route table is backend/hooks/api.php.
     *
     * @return void
     */
    public function register_api()
    {
        HookProvider::loadAppApiHooks();
    }

    public function handleVersionUpdateFallback()
    {
        $installed = get_option('bitformpro_installed');
        $oldversion = null;
        if ($installed) {
            $oldversion = get_option('bitformpro_version');
        }
        if (!$oldversion) {
            update_option('bitformpro_version', BITFORMPRO_VERSION);
            $this->changeValidationErrObjectOfIsUnique();
            return;
        }
        if (version_compare($oldversion, BITFORMPRO_VERSION, '!=')) {
            // Non-gated, idempotent schema guard for the FRONTEND read path (pdf_config),
            // mirroring Free's SchemaFallback. This runs the DB migration once after a plugin
            // update for ANY request without the manage_options gate on update_tables()/migrate();
            // the SHOW COLUMNS check self-limits and the version bump closes the window.
            DB::ensurePdfConfigColumn();
            update_option('bitformpro_version', BITFORMPRO_VERSION);
        }
    }

    private function changeValidationErrObjectOfIsUnique()
    {
        if (!class_exists(Form::class)) {
            return;
        }
        $forms = Form::readWhere([], ['id', 'form_content']);
        if (!is_wp_error($forms)) {
            foreach ($forms as $form) {
                $formID = $form->id;
                $formContent = JSON::decode($form->form_content);
                $fields = $formContent->fields;

                foreach ($fields as $fldKey => $fldData) {
                    if (isset($fldData->err) && isset($fldData->err->entryUnique)) {
                        if (isset($fldData->err->entryUnique->isEntryUnique)) {
                            unset($fldData->err->entryUnique->isEntryUnique);
                            $fldData->err->entryUnique->show = true;
                        } else {
                            $fldData->err->entryUnique->show = false;
                        }

                        if (isset($fldData->err->userUnique->isUserUnique)) {
                            unset($fldData->err->userUnique->isUserUnique);
                            $fldData->err->userUnique->show = true;
                        } else {
                            $fldData->err->userUnique->show = false;
                        }
                    }

                    if (isset($fldData->{"entryUnique:"})) {
                        unset($fldData->{"entryUnique:"});
                    }

                    $fields->{$fldKey} = $fldData;
                }

                $formContent->fields = $fields;

                Form::updateWhere(['id' => $formID], ['form_content' => JSON::encode($formContent)]);
            }
        }
    }

    private function dynamicTaxanomyFields($taxonomy, $order, $orderBy)
    {
        $allCategoreis = get_terms(
            [
                'taxonomy' => $taxonomy,
                'hide_empty' => false,
                'orderby' => $orderBy,
                'order' => $order,
            ],
        );
        return $allCategoreis;
    }
    private function userDynamicFieldsData($role, $order, $orderBy)
    {
        $args = [
            'orderby' => $orderBy,
            'order' => $order,
            'fields' => ['ID', 'display_name', 'user_login', 'user_email', 'user_nicename'],
        ];
        if ($role != 'all') {
            $args['role'] = $role;
        }
        $users = get_users($args);
        return $users;
    }

    private function postDynamicFildData($postType, $order, $orderBy, $postStatus, $taxonomy = null, $termId = null)
    {
        $postModel = new PostInfoModel();
        $posts = $postModel->getAllPosts($postType, $orderBy, $order, $postStatus);

        if (empty($taxonomy) || empty($termId) || !is_array($posts)) {
            return $posts;
        }

        // Fail closed: a term filter is configured, so a broken lookup (e.g. the
        // taxonomy was unregistered) must not leak every post into the options.
        $termPostIds = get_objects_in_term((int) $termId, $taxonomy);
        if (is_wp_error($termPostIds)) {
            return [];
        }
        $termPostIds = array_map('intval', $termPostIds);

        return array_values(array_filter($posts, function ($post) use ($termPostIds) {
            return isset($post->ID) && in_array((int) $post->ID, $termPostIds, true);
        }));
    }

    private function acfDynamicOptions($fieldKey)
    {
        $options = [];
        $types = ['select', 'checkbox', 'radio'];
        $groups = acf_get_field_groups();
        foreach ($groups as $group) {
            foreach (acf_get_fields($group['key']) as $acfField) {
                if (in_array($acfField['type'], $types) && $acfField['key'] === $fieldKey) {
                    $options = $acfField['choices'];
                }
            }
        }
        return $options;
    }

    public function dynamicFieldValues($fields)
    {
        $dynamicOptionFieldTypes = ['check', 'radio', 'select', 'html-select'];
        $isMigratedToV2 = get_option('bitforms_migrated_to_v2');
        foreach ($fields as $key => $field) {
            if (in_array($field->typ, $dynamicOptionFieldTypes)) {
                $optionLbl = 'lbl';
                $optionVal = 'val';

                // this logis is for V1 Select field
                if ($field->typ == 'select' && !$isMigratedToV2) {
                    $optionLbl = 'label';
                    $optionVal = 'value';
                } elseif ($field->typ == 'select') {
                    foreach ($field->optionsList as $keyIndex => $optionListObj) {
                        if (property_exists($field, 'customTypeList') && !empty($field->customTypeList[$keyIndex])) {
                            $listArray = (array) $optionListObj;
                            $listName = array_keys($listArray)[0];
                            $field->optionsList[$keyIndex]->$listName = $this->getDynamicOptions($optionLbl, $optionVal, $field->customTypeList[$keyIndex]);
                        }
                    }
                }
                if (property_exists($field, 'customType') && !empty($field->customType)) {
                    $field->opt = $this->getDynamicOptions($optionLbl, $optionVal, $field->customType);
                }
                $fields->$key = $field;
                //$field->opt = array_merge($field->opt, $field->customType->oldOpt);
            }
        }
        return $fields;
    }

    private function getDynamicOptions($optLbl, $optVal, $customType)
    {
        $options = [];
        $opt = [];

        $filter = $customType->filter;
        if ($customType->fieldType === 'user_field') {
            $options = $this->userDynamicFieldsData($filter->role, $filter->order, $filter->orderBy);
        } elseif ($customType->fieldType === 'taxanomy_field') {
            $options = $this->dynamicTaxanomyFields($filter->taxanomy, $filter->order, $filter->orderBy);
        } elseif ($customType->fieldType === 'post_field') {
            $options = $this->postDynamicFildData(
                $filter->postType,
                $filter->order,
                $filter->orderBy,
                $filter->postStatus,
                isset($filter->taxonomy) ? sanitize_key($filter->taxonomy) : null,
                isset($filter->termId) ? (int) $filter->termId : null,
            );
            // Lets site owners narrow/reshape the synced post list (e.g. custom meta rules)
            // without re-filtering whole field objects on the onload hooks.
            $options = apply_filters('bitform_dynamic_post_options', $options, $filter);
        } elseif ($customType->fieldType === 'acf_options') {
            $data = $this->acfDynamicOptions($filter->fieldkey);
            if (!empty($data)) {
                foreach (array_values($data) as $key => $option) {
                    $opt[$key] = (object) [];
                    $opt[$key]->$optLbl = (string) $option;
                }
                foreach (array_keys($data) as $key => $option) {
                    $opt[$key]->$optVal = (string) $option;
                }
            }
        }
        if (!empty($options) && !is_wp_error($options)) {
            $lebel = $customType->lebel;
            $value = empty($customType->hiddenValue) ? $customType->value : $customType->hiddenValue;

            foreach ($options as $key => $option) {
                if (!empty($lebel) && !empty($value)) {
                    $opt[$key] = (object) [];
                    $opt[$key]->$optLbl = (string) $option->$lebel;
                    $opt[$key]->$optVal = (string) str_replace(',', '_', $option->$value);
                }
            }
        }
        return $opt;
    }

    /**
     * Plugin action links
     *
     * @param  array $links
     *
     * @return array
     */
    public function plugin_action_links($links)
    {
        $links[] = '<a href="https://bitapps.pro/docs/bit-form/" target="_blank">' . __('Docs', 'bitformpro') . '</a>';

        return $links;
    }

    /**
     * Retrieves the main instance of the plugin.
     *
     * @since 1.0.0-alpha
     *
     * @return BITFORMPRO Plugin main instance.
     */
    public static function instance()
    {
        return static::$instance;
    }

    /**
     * Kept public and static: it was reachable here before the restructure.
     * The work is InstallerProvider's.
     *
     * @return void
     */
    public static function update_tables()
    {
        InstallerProvider::migrateIfNeeded();
    }
    /**
     * Loads the plugin main instance and initializes it.
     *
     * @since 1.0.0-alpha
     *
     * @param string $main_file Absolute path to the plugin main file.
     * @return bool True if the plugin main instance could be loaded, false otherwise./
     */
    public static function load($main_file)
    {
        if (null !== static::$instance) {
            return false;
        }
        static::update_tables();
        static::$instance = new static($main_file);
        static::$instance->initialize();
        return true;
    }

    public static function telemetryProStatus($data)
    {
        if (!\is_array($data)) {
            return $data;
        }

        // False on a site never licensed.
        $integrateData = LicenseHelper::getLicenseData();
        $integrateData = \is_array($integrateData) ? $integrateData : [];
        $hasLicense = !empty($integrateData['key']);

        $data['pro'] = [
            'version' => BITFORMPRO_VERSION,
            'hasLicense' => $hasLicense,
        ];

        // Never the license key itself: Bit Form's opt-in list promises status and expiry only.
        if ($hasLicense) {
            $data['pro']['status'] = $integrateData['status'] ?? '';
            $data['pro']['expireAt'] = $integrateData['expireIn'] ?? '';
        }
        return $data;
    }
}
