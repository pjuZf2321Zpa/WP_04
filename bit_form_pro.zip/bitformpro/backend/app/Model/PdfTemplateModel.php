<?php

/**
 * Provides PDF Template Model Class
 */

namespace BitApps\BitFormPro\Model;

use BitApps\BitForm\Model\Model;

/**
 * Model for the `bitforms_pdf_template` table (PDF is a Pro-only feature).
 */
class PdfTemplateModel extends Model
{
    protected static $table = 'bitforms_pdf_template';
}
