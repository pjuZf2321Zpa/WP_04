<?php

namespace BitApps\BitFormPro\Model;

use BitApps\BitForm\Model\Model;
use BitApps\BitForm\Helpers\IpTool;

class PaymentInfoModel extends Model
{
    protected static $table = 'bitforms_payments';
    public function paymentInsert($formID, $transactionID, $paymentName, $paymentType, $response)
    {
        $ipTool = new IpTool();
        $user_details = $ipTool->getUserDetail();
        $result = $this->insert([
            'payment_name' => $paymentName,
            'payment_type' => $paymentType,
            'payment_response' => $response,
            'form_id' => $formID,
            'transaction_id' => $transactionID,
            'user_id' => $user_details['id'],
            'user_ip' => $user_details['ip'],
            'created_at' => $user_details['time'],
        ]);
        return $result;
    }

    /**
     * Payment rows for a transaction, newest first.
     *
     * paymentDetail() calls wp_send_json() from inside the model when the
     * result is empty, which terminates the request — fine for the one AJAX
     * handler it was written for, fatal for anything else. This returns data.
     *
     * @param int    $formID
     * @param string $transactionID
     *
     * @return array
     */
    public function findByTransaction($formID, $transactionID)
    {
        $transactionID = trim((string) $transactionID);
        if ('' === $transactionID) {
            return [];
        }

        $result = $this->get(
            [
                'id',
                'payment_name',
                'payment_type',
                'payment_response',
                'transaction_id',
                'created_at',
            ],
            [
                'form_id' => $formID,
                'transaction_id' => $transactionID,
                'status' => 1,
            ],
            null,
            null,
            'id',
            'DESC',
        );

        return is_wp_error($result) || !is_array($result) ? [] : $result;
    }

    public function paymentDetail($formID, $transactionID)
    {
        $result = $this->get(
            [
                'id',
                'payment_name',
                'payment_type',
                'payment_response',
                'created_at',
            ],
            [
                'form_id' => $formID,
                'transaction_id' => $transactionID,
                'status' => 1,
            ],
            null,
            null,
            'id',
            'DESC',
        );
        $response = ['success' => true, 'data' => []];
        if (isset($result->errors['result_empty'])) {
            wp_send_json($response);
        }
        return $result;
    }
}
