<?php

namespace BitApps\BitFormPro\Model;

use BitApps\BitForm\Model\Model;

class FrontendViewModel extends Model
{
    protected static $table = 'bitforms_frontend_views';
}
