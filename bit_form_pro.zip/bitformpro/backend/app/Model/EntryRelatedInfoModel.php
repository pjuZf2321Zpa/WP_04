<?php

namespace BitApps\BitFormPro\Model;

use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitForm\Model\FormEntryLog;
use BitApps\BitForm\Model\FormEntryRelatedInfo;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Services\Abandonment\RecoveryRow;

/**
 * Pro's rows in Free's related-info table: notes, Save & Resume tokens
 * (draft_resume) and Form Abandonment state (draft_recovery).
 *
 * No SQL here: the table belongs to Free, and Free's model FormEntryRelatedInfo
 * (API level 5) owns it. This class reads and writes through that model's published
 * methods. The note methods answer exactly as they did on the legacy Model:
 * legacy rows, ids, counts and `result_empty` WP_Errors.
 */
class EntryRelatedInfoModel
{
    public const RECOVERY_INFO_TYPE = 'draft_recovery';

    private const RESUME_INFO_TYPE = 'draft_resume';

    public function getAllNotes($formID, $entryID)
    {
        $result = FormEntryRelatedInfo::readWhere(
            ['info_type' => 'note', 'form_id' => $formID, 'entry_id' => $entryID, 'status' => 1],
            ['id', 'info_details', 'user_id', 'created_at', 'updated_at'],
            'id',
            'desc'
        );
        if (isset($result->errors['result_empty'])) {
            wp_send_json(['success' => true, 'data' => []]);
        }
        return $result;
    }

    public function insertNote($formID, $entryID, $note_details)
    {
        $user_details = (new IpTool())->getUserDetail();
        $result = FormEntryRelatedInfo::insertRow([
            'info_type'    => 'note',
            'info_details' => $note_details,
            'form_id'      => $formID,
            'entry_id'     => $entryID,
            'user_id'      => $user_details['id'],
            'user_ip'      => $user_details['ip'],
            'created_at'   => $user_details['time'],
        ]);
        if (!is_wp_error($result)) {
            self::logNote('create', $note_details, $formID, $entryID, $user_details);
        }
        return $result;
    }

    public function updateNote($noteID, $formID, $entryID, $note_details)
    {
        $user_details = (new IpTool())->getUserDetail();
        $conditions = self::noteConditions($noteID, $formID, $entryID);
        $old_note = FormEntryRelatedInfo::rowsWhere($conditions, ['info_details']);
        $result = FormEntryRelatedInfo::updateWhere($conditions, [
            'info_details' => $note_details,
            'updated_at'   => $user_details['time'],
        ]);
        // An unchanged note is logged with no content, as before.
        $log_details = isset($old_note[0]) && $old_note[0]->info_details == $note_details ? null : $note_details;
        if (!is_wp_error($result)) {
            self::logNote('update', $log_details, $formID, $entryID, $user_details);
        }
        return $result;
    }

    public function deleteNote($noteID, $formID, $entryID)
    {
        $user_details = (new IpTool())->getUserDetail();
        $conditions = self::noteConditions($noteID, $formID, $entryID);
        $old_note = FormEntryRelatedInfo::rowsWhere($conditions, ['info_details']);
        $result = FormEntryRelatedInfo::deleteWhere($conditions);
        if (!is_wp_error($result)) {
            self::logNote('delete', isset($old_note[0]) ? $old_note[0]->info_details : null, $formID, $entryID, $user_details);
        }
        return $result;
    }

    /**
     * @param int    $formID
     * @param int    $entryID
     * @param string $tokenHash sha256 of the link secret; the secret itself is never stored
     * @param int    $expires   unix timestamp
     *
     * @return int|\WP_Error the new row id
     */
    public function insertDraftResumeToken($formID, $entryID, $tokenHash, $expires)
    {
        return FormEntryRelatedInfo::insertRow([
            'info_type'    => self::RESUME_INFO_TYPE,
            'info_details' => JSON::encode(['hash' => $tokenHash, 'expires' => (int) $expires]),
            'form_id'      => (int) $formID,
            'entry_id'     => (int) $entryID,
            'status'       => 1,
            'created_at'   => current_time('mysql'),
        ]);
    }

    /**
     * @param int $formID
     * @param int $entryID
     *
     * @return array<int, array{id:int, hash:string, expires:int}> newest first
     */
    public function getDraftResumeTokens($formID, $entryID)
    {
        $rows = FormEntryRelatedInfo::rowsWhere(
            ['info_type' => self::RESUME_INFO_TYPE, 'form_id' => (int) $formID, 'entry_id' => (int) $entryID],
            ['id', 'info_details'],
            'id',
            'desc'
        );
        $tokens = [];
        foreach ($rows as $row) {
            $details = JSON::decode((string) $row->info_details, true);
            if (!is_array($details) || empty($details['hash']) || !is_string($details['hash'])) {
                continue;
            }
            $tokens[] = [
                'id'      => (int) $row->id,
                'hash'    => $details['hash'],
                'expires' => isset($details['expires']) ? (int) $details['expires'] : 0,
            ];
        }
        return $tokens;
    }

    /**
     * @param int[] $ids
     */
    public function deleteDraftResumeTokens(array $ids)
    {
        $ids = array_values(array_filter(array_map('intval', $ids)));
        if ([] !== $ids) {
            FormEntryRelatedInfo::deleteWhere(['id' => $ids, 'info_type' => self::RESUME_INFO_TYPE]);
        }
    }

    /**
     * The Form Abandonment recovery row of one entry.
     *
     * @param int $entryID
     *
     * @return RecoveryRow|null
     */
    public function getRecovery($entryID)
    {
        $rows = $this->getRecoveries([(int) $entryID]);

        return $rows[(int) $entryID] ?? null;
    }

    /**
     * @param int[] $entryIDs
     *
     * @return array<int, RecoveryRow> keyed by entry id
     */
    public function getRecoveries(array $entryIDs)
    {
        $entryIDs = array_values(array_filter(array_map('intval', $entryIDs)));
        if (empty($entryIDs)) {
            return [];
        }
        $rows = FormEntryRelatedInfo::rowsWhere(
            ['info_type' => self::RECOVERY_INFO_TYPE, 'entry_id' => $entryIDs],
            ['id', 'form_id', 'entry_id', 'status', 'info_details'],
            'id',
            'asc'
        );

        $byEntry = [];
        foreach ($rows as $row) {
            $byEntry[(int) $row->entry_id] = RecoveryRow::fromRow($row);
        }
        return $byEntry;
    }

    /**
     * @param int   $formID
     * @param int   $entryID
     * @param int   $status
     * @param array $details
     *
     * @return int new row id, 0 on failure
     */
    public function insertRecovery($formID, $entryID, $status, array $details)
    {
        $id = FormEntryRelatedInfo::insertRow([
            'info_type'    => self::RECOVERY_INFO_TYPE,
            'info_details' => JSON::encode($details),
            'form_id'      => (int) $formID,
            'entry_id'     => (int) $entryID,
            'status'       => (int) $status,
            'created_at'   => current_time('mysql'),
        ]);
        return is_wp_error($id) ? 0 : (int) $id;
    }

    /**
     * Compare-and-set: writes only when the row still holds what the caller read,
     * so two overlapping cron runs (or a cron run and an admin click) cannot both
     * act on one draft.
     *
     * @param RecoveryRow $row  as read by getRecovery()/getRecoveries()
     * @param int    $newStatus
     * @param array  $newDetails
     *
     * @return bool true when this caller won
     */
    public function swapRecovery($row, $newStatus, array $newDetails)
    {
        $updated = FormEntryRelatedInfo::updateWhere(
            ['id' => (int) $row->id, 'status' => (int) $row->status, 'info_details' => (string) $row->raw],
            ['status' => (int) $newStatus, 'info_details' => JSON::encode($newDetails)]
        );
        return 1 === $updated;
    }

    /**
     * Untrashed drafts of a form whose recovery row is in $status and that have had
     * no activity since $before.
     *
     * @param int    $formID
     * @param int    $status
     * @param string $before  mysql datetime (site time, like updated_at); '' for no age limit
     * @param int    $limit
     * @param int    $afterId cursor: the last row id the previous page ended on
     *
     * @return RecoveryRow[] each with ->entry_updated_at
     */
    public function recoveriesOfDrafts($formID, $status, $before, $limit, $afterId = 0)
    {
        $rows = FormEntryRelatedInfo::ofInactiveDrafts(self::RECOVERY_INFO_TYPE, $formID, $status, $before, $limit, $afterId);

        return array_map([RecoveryRow::class, 'fromRow'], $rows);
    }

    /**
     * Expired Save & Resume tokens, site-wide, one batch after $afterId.
     *
     * @param int $afterId cursor: the last id the previous batch looked at
     * @param int $limit
     *
     * @return array{deleted:int, last:int} last = 0 when the table was exhausted
     */
    public function pruneExpiredDraftResumeTokens($afterId = 0, $limit = 500)
    {
        $limit = max(1, (int) $limit);
        $rows = FormEntryRelatedInfo::batchOfType(self::RESUME_INFO_TYPE, (int) $afterId, $limit);
        $expired = [];
        foreach ($rows as $row) {
            $details = JSON::decode((string) $row->info_details, true);
            if (!is_array($details) || empty($details['expires']) || (int) $details['expires'] < time()) {
                $expired[] = (int) $row->id;
            }
        }
        $this->deleteDraftResumeTokens($expired);
        $last = count($rows) < $limit ? 0 : (int) end($rows)->id;

        return ['deleted' => count($expired), 'last' => $last];
    }

    /**
     * @param int $id
     *
     * @return int|\WP_Error rows deleted
     */
    public function deleteRecovery($id)
    {
        return FormEntryRelatedInfo::deleteWhere(['id' => (int) $id, 'info_type' => self::RECOVERY_INFO_TYPE]);
    }

    /**
     * A note of that entry only: the table also holds resume tokens and recovery
     * state, which a note id from the request must never reach.
     */
    private static function noteConditions($noteID, $formID, $entryID)
    {
        return ['id' => $noteID, 'info_type' => 'note', 'form_id' => $formID, 'entry_id' => $entryID];
    }

    private static function logNote($action, $content, $formID, $entryID, array $user_details)
    {
        FormEntryLog::insertRow([
            'log_type'      => 'note',
            'action_type'   => $action,
            'content'       => $content,
            'form_id'       => $formID,
            'form_entry_id' => $entryID,
            'user_id'       => $user_details['id'],
            'ip'            => $user_details['ip'],
            'created_at'    => $user_details['time'],
        ]);
    }
}
