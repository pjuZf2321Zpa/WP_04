<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Model\EntryRelatedInfoModel;

/**
 * Every hook Form Abandonment v2 hangs on. Callbacks take untyped arguments on
 * purpose: a filter value can be anything, and a TypeError there takes the
 * whole request down.
 */
final class AbandonmentHooks
{
    public static function register()
    {
        add_filter('cron_schedules', [AbandonmentJob::class, 'addInterval']);
        add_action(AbandonmentJob::HOOK, [AbandonmentJob::class, 'run']);
        add_action('bitform_form_abandonment_saved', [AbandonmentJob::class, 'onSettingsSaved'], 10, 2);
        add_action('admin_init', [AbandonmentJob::class, 'selfHeal']);

        add_action('bitform_update_success', [self::class, 'onEntryUpdated'], 10, 2);
        add_filter('bitform_default_submit_confirmation_excluded_action_ids', [self::class, 'excludeReminderTemplates'], 20, 2);
        add_filter('bitform_entry_timeline_events', [self::class, 'timelineEvents'], 10, 3);
        add_filter('bitform_entry_list_badges', [self::class, 'listBadges'], 10, 2);
        add_action('template_redirect', [self::class, 'handleStopLink']);
        add_filter('bitform_draft_resume_step', [self::class, 'resumeStep'], 10, 3);
    }

    /**
     * The multi-step position saved with the draft being restored.
     *
     * @param mixed $step
     * @param mixed $formId
     * @param mixed $entryId
     *
     * @return mixed
     */
    public static function resumeStep($step, $formId = null, $entryId = null)
    {
        if (!is_numeric($entryId)) {
            return $step;
        }
        $row = (new EntryRelatedInfoModel())->getRecovery((int) $entryId);
        return null !== $row && $row->step() ? $row->step() : $step;
    }

    /**
     * The visitor submitted (bitforms_update_form_entry is how a draft is finished).
     *
     * @param mixed $formId
     * @param mixed $entryId
     */
    public static function onEntryUpdated($formId, $entryId = null)
    {
        if (is_numeric($formId) && is_numeric($entryId)) {
            RecoveryState::completed((int) $formId, (int) $entryId);
        }
    }

    /**
     * Reminder templates belong to the reminders: never send them on submit.
     *
     * @param mixed $actionIds
     * @param mixed $formId
     *
     * @return mixed
     */
    public static function excludeReminderTemplates($actionIds, $formId = null)
    {
        if (!is_array($actionIds) || !is_numeric($formId)) {
            return $actionIds;
        }
        $settings = AbandonmentSettings::forForm((int) $formId);
        if (null === $settings) {
            return $actionIds;
        }
        $ids = [];
        foreach ($settings->ownTemplateIds() as $templateId) {
            $ids[(string) $templateId] = true;
        }
        if ($ids) {
            $current = isset($actionIds['mailNotify']) && is_array($actionIds['mailNotify']) ? $actionIds['mailNotify'] : [];
            $actionIds['mailNotify'] = $current + $ids;
        }
        return $actionIds;
    }

    /**
     * Abandoned / recovered / stopped / failed, from the draft's recovery row.
     * Reminder sends need nothing here: each has its own log envelope and mail row.
     *
     * @param mixed $events
     * @param mixed $formId
     * @param mixed $entryId
     *
     * @return mixed
     */
    public static function timelineEvents($events, $formId = null, $entryId = null)
    {
        if (!is_array($events) || !is_numeric($entryId)) {
            return $events;
        }
        $row = (new EntryRelatedInfoModel())->getRecovery((int) $entryId);
        if (null === $row) {
            return $events;
        }
        $add = static function ($key, $at, $status, $actorKind = 'system') use (&$events, $row) {
            $events[] = [
                'id'          => 'abandonment:' . $row->id . ':' . $key,
                'type'        => 'abandonment',
                'occurred_at' => wp_date('Y-m-d H:i:s', (int) $at),
                'actor'       => ['kind' => $actorKind, 'id' => null, 'name' => null],
                'titleKey'    => 'timeline.abandonment.' . $key,
                'params'      => [],
                'status'      => $status,
                'summary'     => null,
                'detail'      => [],
                'replayable'  => false,
                'replay'      => null,
                'related'     => [],
            ];
        };
        if ($row->abandonedAt()) {
            $add('abandoned', $row->abandonedAt(), 'warning');
        }
        if ($row->recoveredAt()) {
            $add('recovered', $row->recoveredAt(), 'success');
        }
        if ($row->stoppedAt()) {
            $add('stopped', $row->stoppedAt(), 'info', $row->stoppedByAdmin() ? 'user' : 'guest');
        }
        if ($row->failedAt()) {
            $add('failed', $row->failedAt(), 'error');
        }
        return $events;
    }

    /**
     * @param mixed $badges
     * @param mixed $entryIds
     *
     * @return mixed
     */
    public static function listBadges($badges, $entryIds = null)
    {
        if (!is_array($badges) || !is_array($entryIds) || empty($entryIds)) {
            return $badges;
        }
        foreach ((new EntryRelatedInfoModel())->getRecoveries($entryIds) as $entryId => $row) {
            $list = self::badgesFor($row);
            if ($list) {
                $badges[$entryId] = array_merge(isset($badges[$entryId]) && is_array($badges[$entryId]) ? $badges[$entryId] : [], $list);
            }
        }
        return $badges;
    }

    /**
     * @param RecoveryRow $row
     *
     * @return array
     */
    public static function badgesFor(RecoveryRow $row)
    {
        $sent = $row->sent();
        $step = $row->step();
        $progress = $row->progress();
        $badges = [];
        switch ($row->status) {
            case RecoveryState::ACTIVE:
                $label = null !== $progress ? sprintf(__('In progress · %d%%', 'bitformpro'), $progress) : __('In progress', 'bitformpro');
                $badges[] = ['label' => $label, 'variant' => 'info', 'tooltip' => null !== $step ? sprintf(__('Last saved on step %d', 'bitformpro'), $step) : ''];
                break;
            case RecoveryState::ABANDONED:
                $badges[] = ['label' => __('Abandoned', 'bitformpro'), 'variant' => 'warning', 'tooltip' => null !== $progress ? sprintf(__('%d%% filled in', 'bitformpro'), $progress) : ''];
                break;
            case RecoveryState::RECOVERED:
                $badges[] = ['label' => __('Recovered', 'bitformpro'), 'variant' => 'success', 'tooltip' => __('Submitted after the visitor had left the form', 'bitformpro')];
                return $badges;
            case RecoveryState::STOPPED:
                $badges[] = ['label' => __('Reminders stopped', 'bitformpro'), 'variant' => 'neutral', 'tooltip' => ''];
                break;
            case RecoveryState::FAILED:
                $badges[] = ['label' => __('Reminders failed', 'bitformpro'), 'variant' => 'danger', 'tooltip' => __('Sending failed three times. See the activity log.', 'bitformpro')];
                break;
        }
        if ($sent > 0) {
            $badges[] = ['label' => sprintf(_n('%d reminder sent', '%d reminders sent', $sent, 'bitformpro'), $sent), 'variant' => 'neutral', 'tooltip' => ''];
        }
        return $badges;
    }

    /**
     * The "stop these reminders" link in a reminder email.
     */
    public static function handleStopLink()
    {
        $raw = isset($_GET[RecoveryMailer::STOP_QUERY_ARG]) ? wp_unslash($_GET[RecoveryMailer::STOP_QUERY_ARG]) : null;
        if (!is_string($raw)) {
            return;
        }
        $token = sanitize_text_field($raw);
        nocache_headers();
        $stopped = self::stopByToken($token);
        wp_die(
            esc_html($stopped
                ? __('You will not receive any more reminders about this form.', 'bitformpro')
                : __('This link has expired or was already used. No more reminders will be sent for a finished or deleted form.', 'bitformpro')),
            esc_html__('Reminders', 'bitformpro'),
            ['response' => 200]
        );
    }

    /**
     * @param mixed $token `<entryId>.<secret>`; anything else is refused
     *
     * @return bool
     */
    public static function stopByToken($token)
    {
        if (!is_string($token) || 1 !== preg_match('/^(\d{1,20})\.([a-f0-9]{32})$/', $token, $match)) {
            return false;
        }
        $row = (new EntryRelatedInfoModel())->getRecovery((int) $match[1]);
        if (null === $row || !$row->hasStopSecret($match[2])) {
            return false;
        }
        return RecoveryState::stop($row, 'visitor') || RecoveryState::STOPPED === $row->status;
    }
}
