<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

/**
 * One form's Form Abandonment settings, read once and normalised.
 *
 * The settings are a free-form JSON object saved by the builder, and forms saved
 * before a key existed simply lack it. Every reader goes through here so a
 * missing or malformed key always means "today's behaviour", never a notice or
 * a surprise default. The two exceptions want the whole stored object, not its
 * meaning: FormAbandonment::getFormAbandonmentSettings() answers Free's
 * bitform_form_abandonment_settings filter, and getStoredSettings() fills the builder.
 */
final class AbandonmentSettings
{
    public const MAX_REMINDERS = 3;

    private const UNIT_SECONDS = ['minutes' => MINUTE_IN_SECONDS, 'hours' => HOUR_IN_SECONDS, 'days' => DAY_IN_SECONDS];

    private const MIN_ABANDON_SECONDS = 15 * MINUTE_IN_SECONDS;

    private const MAX_ABANDON_SECONDS = 7 * DAY_IN_SECONDS;

    private const DEFAULT_ABANDON_SECONDS = HOUR_IN_SECONDS;

    private const MAX_STEP_SECONDS = 30 * DAY_IN_SECONDS;

    private const DEFAULT_RESUME_LINK_DAYS = 30;

    /** @var int */
    private $formId;

    /** @var object */
    private $raw;

    private function __construct($formId, $raw)
    {
        $this->formId = (int) $formId;
        $this->raw = $raw;
    }

    /**
     * @param object|array|null $raw the stored JSON, decoded
     */
    public static function fromRaw($formId, $raw)
    {
        if (is_array($raw)) {
            $raw = JSON::decode(JSON::encode($raw));
        }
        return new self($formId, is_object($raw) ? $raw : new \stdClass());
    }

    /** @var array<int, self|null> request-scoped: the submit path asks several times per form */
    private static $cache = [];

    /**
     * @return self|null null when the form has no active Form Abandonment
     */
    public static function forForm($formId)
    {
        $formId = (int) $formId;
        if (!array_key_exists($formId, self::$cache)) {
            $rows = (new IntegrationHandler($formId))->getAllIntegration('formAbandonment', 'formAbandonment');
            $settings = is_wp_error($rows) || empty($rows[0]->integration_details) ? null : self::fromRaw($formId, JSON::decode($rows[0]->integration_details));
            self::$cache[$formId] = null !== $settings && $settings->active() ? $settings : null;
        }
        return self::$cache[$formId];
    }

    /** Settings were saved in this request (or a test changed them). */
    public static function flushCache()
    {
        self::$cache = [];
    }

    /**
     * Every form with Form Abandonment on, in one query.
     *
     * @return array<int, self> keyed by form id
     */
    public static function allActive()
    {
        $rows = (new IntegrationHandler(0))->getIntegrationWithoutFormId('formAbandonment', 'formAbandonment');
        if (is_wp_error($rows) || !is_array($rows)) {
            return [];
        }
        $all = [];
        foreach ($rows as $row) {
            if (empty($row->form_id) || empty($row->integration_details)) {
                continue;
            }
            $settings = self::fromRaw($row->form_id, JSON::decode($row->integration_details));
            if ($settings->active()) {
                $all[(int) $row->form_id] = $settings;
            }
        }
        return $all;
    }

    public function formId()
    {
        return $this->formId;
    }

    public function active()
    {
        return !empty($this->raw->active);
    }

    /** Seconds without activity before a draft counts as abandoned. */
    public function abandonAfterSeconds()
    {
        $seconds = self::duration($this->raw->abandonAfter ?? null, self::DEFAULT_ABANDON_SECONDS);
        return max(self::MIN_ABANDON_SECONDS, min(self::MAX_ABANDON_SECONDS, $seconds));
    }

    public function remindersOn()
    {
        return !empty($this->raw->recovery->active) && !empty($this->reminderSteps());
    }

    /**
     * @return array<int, array{delay:int, templateId:string}> delay = seconds after the draft was marked abandoned
     */
    public function reminderSteps()
    {
        $steps = isset($this->raw->recovery->steps) && is_array($this->raw->recovery->steps) ? $this->raw->recovery->steps : [];
        $out = [];
        foreach (array_slice($steps, 0, self::MAX_REMINDERS) as $step) {
            $templateId = isset($step->templateId) ? (string) $step->templateId : '';
            if ('' === $templateId) {
                continue;
            }
            $delay = (object) [
                'value' => $step->delay ?? null,
                'unit'  => $step->unit ?? 'hours',
            ];
            $out[] = [
                'delay'      => max(0, min(self::MAX_STEP_SECONDS, self::duration($delay, 0))),
                'templateId' => $templateId,
            ];
        }
        // Later reminders never fire before earlier ones.
        usort($out, static function ($a, $b) {
            return $a['delay'] - $b['delay'];
        });
        return $out;
    }

    /** @return int[]|string[] template ids used by reminders, for the submit-mail exclusion */
    public function reminderTemplateIds()
    {
        return array_column($this->reminderSteps(), 'templateId');
    }

    /** The template emailed to the site team when an entry is first marked abandoned, or ''. */
    public function notifyTemplateId()
    {
        if (empty($this->raw->abandonNotify->active) || !isset($this->raw->abandonNotify->templateId)) {
            return '';
        }
        $templateId = (string) $this->raw->abandonNotify->templateId;
        return ctype_digit($templateId) ? $templateId : '';
    }

    /** Templates only this feature sends: the reminders and the team notice. */
    public function ownTemplateIds()
    {
        $ids = $this->reminderTemplateIds();
        if ('' !== $this->notifyTemplateId()) {
            $ids[] = $this->notifyTemplateId();
        }
        return array_values(array_unique($ids));
    }

    public function emailFieldKey()
    {
        return isset($this->raw->recovery->emailField) && is_string($this->raw->recovery->emailField) ? $this->raw->recovery->emailField : '';
    }

    public function consentFieldKey()
    {
        return isset($this->raw->recovery->consentField) && is_string($this->raw->recovery->consentField) ? $this->raw->recovery->consentField : '';
    }

    /** Days a draft is kept; 0 = forever (the default for forms saved before this setting). */
    public function retentionDays()
    {
        return isset($this->raw->retentionDays) && is_numeric($this->raw->retentionDays) ? max(0, min(365, (int) $this->raw->retentionDays)) : 0;
    }

    public function resumeLinksOn()
    {
        return !empty($this->raw->resumeLink);
    }

    /** May a visitor have their resume link emailed to them? */
    public function resumeEmailOn()
    {
        return !empty($this->raw->resumeEmail);
    }

    /** @return string '' when the default wording applies */
    public function resumeEmailSubject()
    {
        return $this->text('resumeEmailSubject');
    }

    /** @return string '' when the default wording applies */
    public function resumeEmailBody()
    {
        return $this->text('resumeEmailBody');
    }

    /** @return int days a resume link stays valid, before the expiry filter and its limits */
    public function resumeLinkExpiryDays()
    {
        return isset($this->raw->resumeLinkExpiry) ? (int) $this->raw->resumeLinkExpiry : self::DEFAULT_RESUME_LINK_DAYS;
    }

    /** Refill the form for a visitor returning to their draft. */
    public function repopulatesForm()
    {
        return !empty($this->raw->repopulateForm);
    }

    /**
     * Save a draft even when nothing is filled in yet. Any stored value counts, false
     * too: the builder only writes this key to turn it on.
     */
    public function savesEmptyDrafts()
    {
        return isset($this->raw->saveEmptyFromDraft);
    }

    public function onlyLoggedInUsers()
    {
        return !empty($this->raw->onlyLoggedInUsers);
    }

    /** Save the draft as the visitor types, rather than only from a Save Draft button. */
    public function autoSavesDrafts()
    {
        return !empty($this->raw->saveFormDraft);
    }

    /** @return string the notice shown above the form, '' when none is configured */
    public function warningMessage()
    {
        return !empty($this->raw->showWarningMsg) ? $this->text('warningMsg') : '';
    }

    /** Does this form need the background job at all? */
    public function needsJob()
    {
        return $this->active();
    }

    private function text($key)
    {
        return !empty($this->raw->$key) && is_string($this->raw->$key) ? $this->raw->$key : '';
    }

    /**
     * {value, unit} → seconds.
     *
     * @param mixed $spec
     * @param int   $default
     */
    private static function duration($spec, $default)
    {
        if (!is_object($spec) || !isset($spec->value) || !is_numeric($spec->value)) {
            return (int) $default;
        }
        $unit = isset($spec->unit) && isset(self::UNIT_SECONDS[$spec->unit]) ? $spec->unit : 'hours';
        return (int) round((float) $spec->value * self::UNIT_SECONDS[$unit]);
    }
}
