<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Services\Admin\AdminFormManager;
use BitApps\BitForm\Model\FormEntry;
use BitApps\BitForm\Model\FormEntryLog;
use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitForm\Services\Messages\EmailTemplateHandler;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Services\Notification\MailNotifier;
use BitApps\BitFormPro\Services\Admin\FormSettings\DraftResume;

/**
 * Sends one reminder email for an abandoned draft.
 *
 * The content is one of the form's own Email Templates, sent through Free's
 * MailNotifier, so field smart tags, ${bf_if} blocks, logging and the entry
 * timeline all work as for any notification. Three things differ:
 * - it always goes to the visitor (the configured email field), never to the
 *   template's own To/CC/BCC;
 * - ${bf_resume_link}, ${bf_resume_expiry} and ${bf_recovery_stop_link} are
 *   filled for this one send (a fresh resume link each time);
 * - no PDF is generated from a draft.
 *
 * A reminder goes to an address typed into a public form, so it is capped per
 * recipient on each form, per recipient across the site, and per form each day:
 * a bot cannot turn the site into a relay.
 */
final class RecoveryMailer
{
    public const STOP_QUERY_ARG = 'bf_reminders_stop';

    /** One address on one form: a full three-step sequence. */
    private const PER_RECIPIENT_DAILY = 3;

    /** One address on every form together, so other forms' sequences still get through. */
    private const PER_RECIPIENT_SITE_DAILY = 10;

    private const PER_FORM_DAILY = 200;

    /**
     * @param AbandonmentSettings $settings
     * @param int                 $entryId
     * @param string              $templateId
     * @param string              $stopSecret the secret whose hash the caller stored on the recovery row
     *
     * @return array{result:string, reason?:string} result: sent | failed | skipped
     */
    public static function send(AbandonmentSettings $settings, $entryId, $templateId, $stopSecret)
    {
        $formId = $settings->formId();
        $entryId = (int) $entryId;
        $values = self::entryValues($entryId);

        $recipient = self::recipient($settings, $entryId, $values);
        if ('' === $recipient) {
            return ['result' => 'skipped', 'reason' => 'no_recipient'];
        }
        $consentKey = $settings->consentFieldKey();
        if ('' !== $consentKey && self::isBlank($values[$consentKey] ?? '')) {
            return ['result' => 'skipped', 'reason' => 'no_consent'];
        }
        if (!self::templateUsable($formId, $templateId)) {
            return ['result' => 'skipped', 'reason' => 'no_template'];
        }
        if (!self::consumeDailyAllowance($formId, $recipient)) {
            return ['result' => 'skipped', 'reason' => 'rate_limited'];
        }

        $resume = DraftResume::issueLink($formId, $entryId, self::linkBase($entryId), $settings);
        // Handed to the template as extra "field values": MailNotifier blanks any
        // ${tag} it cannot resolve before a filter would see it, and these keys
        // never collide with field keys (b1-2 …) or reach ${bf_all_data}.
        $tags = [
            'bf_resume_link'        => $resume ? esc_url($resume['url']) : '',
            'bf_resume_expiry'      => $resume ? esc_html(wp_date((string) get_option('date_format', 'F j, Y'), (int) $resume['expires'])) : '',
            'bf_recovery_stop_link' => esc_url(add_query_arg(self::STOP_QUERY_ARG, $entryId . '.' . $stopSecret, home_url('/'))),
        ];

        $logId = self::openLog($formId, $entryId, $templateId);
        $formContent = (new AdminFormManager($formId))->getFormContent();
        $forMail = array_merge(FieldValueHandler::formatFieldValueForMail($formContent->fields, $values), $tags);

        return self::deliver($formId, $entryId, $templateId, $recipient, $forMail, $logId);
    }

    /**
     * The "an entry was abandoned" email to the site team: the chosen template, sent
     * as a submission sends it, to its own To/CC/BCC. Never the visitor's resume or
     * stop link: this goes to people other than the visitor.
     *
     * @return bool whether WordPress accepted the mail
     */
    public static function notifyTeam(AbandonmentSettings $settings, $entryId)
    {
        $formId = $settings->formId();
        $templateId = $settings->notifyTemplateId();
        if ('' === $templateId || !self::templateUsable($formId, $templateId)) {
            return false;
        }
        $entryId = (int) $entryId;
        $values = self::entryValues($entryId);
        $tags = ['bf_resume_link' => '', 'bf_resume_expiry' => '', 'bf_recovery_stop_link' => ''];
        $formContent = (new AdminFormManager($formId))->getFormContent();
        $forMail = array_merge(FieldValueHandler::formatFieldValueForMail($formContent->fields, $values), $tags);
        $logId = self::openLog($formId, $entryId, $templateId, 'abandon_notify');

        $sent = false;
        $onSuccess = static function () use (&$sent) {
            $sent = true;
        };
        add_action('wp_mail_succeeded', $onSuccess);
        $previousEntry = $GLOBALS['bitform_entry_id'] ?? null;
        $GLOBALS['bitform_entry_id'] = $entryId;
        try {
            MailNotifier::notify(self::teamNotifyDetails($formId, $templateId), $formId, $forMail, $entryId, false, $logId);
        } catch (\Throwable $e) {
            $sent = false;
        } finally {
            remove_action('wp_mail_succeeded', $onSuccess);
            $GLOBALS['bitform_entry_id'] = $previousEntry;
        }
        return $sent;
    }

    /** The template's own recipients and attachments, as a submission would send it; no PDF of a draft. */
    private static function teamNotifyDetails($formId, $templateId)
    {
        $details = new \stdClass();
        $details->id = JSON::encode(['id' => (string) $templateId]);
        $arrayKeys = ['to', 'cc', 'bcc', 'replyto', 'attachment', 'mediaAttachment', 'pdfIds'];
        foreach (['to', 'from', 'from_name', 'cc', 'bcc', 'replyto', 'attachment', 'mediaAttachment', 'pdfId', 'pdfIds'] as $key) {
            $details->$key = in_array($key, $arrayKeys, true) ? [] : '';
        }
        $template = (new EmailTemplateHandler($formId))->getATemplate($templateId);
        if (!is_wp_error($template) && !empty($template[0]->config)) {
            $config = JSON::decode($template[0]->config);
            // Not `attachment`: those are the draft's own uploads, sent before anyone vetted them.
            foreach (['to', 'from', 'from_name', 'cc', 'bcc', 'replyto', 'mediaAttachment'] as $key) {
                if (is_object($config) && isset($config->$key)) {
                    $details->$key = $config->$key;
                }
            }
        }
        return $details;
    }

    /**
     * MailNotifier reports nothing back, so the outcome is read from WordPress's
     * own wp_mail_succeeded / wp_mail_failed for this one call.
     */
    private static function deliver($formId, $entryId, $templateId, $recipient, array $forMail, $logId)
    {
        $outcome = null;
        $onSuccess = static function () use (&$outcome) {
            $outcome = 'sent';
        };
        $onFailure = static function () use (&$outcome) {
            $outcome = 'failed';
        };
        $isThisSend = static function ($context) use ($entryId) {
            return is_array($context) && (int) ($context['entry_id'] ?? 0) === (int) $entryId;
        };
        $recipients = static function ($mailTo, $context) use ($isThisSend, $recipient) {
            return $isThisSend($context) ? [$recipient] : $mailTo;
        };

        add_action('wp_mail_succeeded', $onSuccess);
        add_action('wp_mail_failed', $onFailure);
        add_filter('bitform_filter_mail_recipients', $recipients, 99, 2);
        $previousEntry = $GLOBALS['bitform_entry_id'] ?? null;
        $GLOBALS['bitform_entry_id'] = $entryId;

        try {
            MailNotifier::notify(self::notifyDetails($formId, $templateId), $formId, $forMail, $entryId, false, $logId);
        } catch (\Throwable $e) {
            $outcome = 'failed';
        } finally {
            remove_action('wp_mail_succeeded', $onSuccess);
            remove_action('wp_mail_failed', $onFailure);
            remove_filter('bitform_filter_mail_recipients', $recipients, 99);
            $GLOBALS['bitform_entry_id'] = $previousEntry;
        }

        // Neither hook fired: the template was checked usable above, so a plugin
        // short-circuited wp_mail() or MailNotifier found nobody to send to. Count it
        // as a failure so the retry limit applies instead of retrying forever.
        return ['result' => null === $outcome ? 'failed' : $outcome];
    }

    /**
     * The template's own config, with the recipients and PDFs taken out: they are
     * decided here, and a draft has no business producing a PDF.
     */
    private static function notifyDetails($formId, $templateId)
    {
        $details = new \stdClass();
        $details->id = JSON::encode(['id' => (string) $templateId]);
        foreach (['from', 'from_name', 'pdfId'] as $key) {
            $details->$key = '';
        }
        foreach (['to', 'cc', 'bcc', 'replyto', 'attachment', 'mediaAttachment', 'pdfIds'] as $key) {
            $details->$key = [];
        }
        $template = (new EmailTemplateHandler($formId))->getATemplate($templateId);
        if (!is_wp_error($template) && !empty($template[0]->config)) {
            $config = JSON::decode($template[0]->config);
            // Not `attachment`: those are the draft's own uploads. A reminder goes to any
            // address the visitor typed, so it would carry their files to a stranger.
            foreach (['from', 'from_name', 'replyto', 'mediaAttachment'] as $key) {
                if (is_object($config) && isset($config->$key)) {
                    $details->$key = $config->$key;
                }
            }
        }
        return $details;
    }

    private static function templateUsable($formId, $templateId)
    {
        $template = (new EmailTemplateHandler($formId))->getATemplate($templateId);
        return !is_wp_error($template) && !empty($template[0]) && (!isset($template[0]->status) || (int) $template[0]->status === 1);
    }

    /**
     * @return array<string,string> field key => stored value
     */
    public static function entryValues($entryId)
    {
        // rowsWhere(): [] for none and on failure.
        $values = [];
        foreach (FormEntryMeta::rowsWhere(['bitforms_form_entry_id' => (int) $entryId], ['meta_key', 'meta_value']) as $row) {
            $values[(string) $row->meta_key] = $row->meta_value;
        }
        return $values;
    }

    /**
     * The address typed into the chosen email field, or the account's email for a
     * logged-in visitor's draft.
     */
    public static function recipient(AbandonmentSettings $settings, $entryId, array $values)
    {
        $key = $settings->emailFieldKey();
        $candidate = '' !== $key && isset($values[$key]) && is_string($values[$key]) ? trim($values[$key]) : '';
        if ('' === $candidate) {
            $entry = FormEntry::rowsWhere(['id' => (int) $entryId], ['user_id']);
            $userId = !empty($entry[0]->user_id) ? (int) $entry[0]->user_id : 0;
            $user = $userId ? get_userdata($userId) : null;
            $candidate = $user ? (string) $user->user_email : '';
        }
        $candidate = sanitize_email($candidate);
        return is_email($candidate) ? $candidate : '';
    }

    /** The page the draft was started on, when it is this site's own; else the home page. */
    public static function linkBase($entryId)
    {
        $entry = FormEntry::rowsWhere(['id' => (int) $entryId], ['referer']);
        $referer = !empty($entry[0]->referer) ? (string) $entry[0]->referer : '';
        $base = '' === $referer ? '' : wp_validate_redirect($referer, '');
        return '' === $base ? home_url('/') : remove_query_arg([DraftResume::QUERY_ARG, self::STOP_QUERY_ARG], $base);
    }

    private static function consumeDailyAllowance($formId, $recipient)
    {
        $formId = (int) $formId;
        $address = md5(strtolower($recipient));
        $limits = [
            'bitformpro_rem_to_' . $formId . '_' . $address => apply_filters('bitform_abandonment_reminder_recipient_daily_limit', self::PER_RECIPIENT_DAILY, $formId),
            'bitformpro_rem_to_' . $address                  => apply_filters('bitform_abandonment_reminder_recipient_site_daily_limit', self::PER_RECIPIENT_SITE_DAILY),
            'bitformpro_rem_form_' . $formId                 => apply_filters('bitform_abandonment_reminder_daily_limit', self::PER_FORM_DAILY, $formId),
        ];
        $now = time();
        $windows = [];
        foreach ($limits as $key => $limit) {
            $window = self::dailyWindow($key, $now);
            if ($window['count'] >= max(1, (int) $limit)) {
                return false;
            }
            $windows[$key] = $window;
        }
        foreach ($windows as $key => $window) {
            // The day runs from the window's first send. Re-arming a plain counter for a full day on
            // every send kept it alive as long as sends came less than a day apart, so it never reset.
            $window['count']++;
            set_transient($key, $window, max(1, $window['start'] + DAY_IN_SECONDS - $now));
        }
        return true;
    }

    /**
     * @return array{count:int,start:int} the sends in the current day-long window for $key
     */
    private static function dailyWindow($key, $now)
    {
        $stored = get_transient($key);
        if (is_array($stored) && isset($stored['count'], $stored['start']) && (int) $stored['start'] + DAY_IN_SECONDS > $now) {
            return ['count' => (int) $stored['count'], 'start' => (int) $stored['start']];
        }
        return ['count' => 0, 'start' => $now];
    }

    /** The reminder's own envelope; MailNotifier's outcome row hangs off it. */
    private static function openLog($formId, $entryId, $templateId, $logType = 'reminder')
    {
        $logId = FormEntryLog::insertRow([
            'user_id'       => 0,
            'log_type'      => $logType,
            'ip'            => 0,
            'action_type'   => 'create',
            'form_entry_id' => (int) $entryId,
            'form_id'       => (int) $formId,
            'content'       => JSON::encode(['template_id' => (string) $templateId]),
            'created_at'    => current_time('mysql'),
        ]);
        return is_wp_error($logId) ? 0 : $logId;
    }

    private static function isBlank($value)
    {
        if (is_array($value)) {
            return empty(array_filter($value, static function ($v) {
                return '' !== trim((string) $v);
            }));
        }
        return '' === trim((string) $value) || '[]' === trim((string) $value);
    }
}
