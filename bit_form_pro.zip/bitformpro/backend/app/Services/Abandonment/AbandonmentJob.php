<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Services\Entry\EntryTrashService;
use BitApps\BitFormPro\Model\EntryRelatedInfoModel;

/**
 * The one background job behind Form Abandonment, every 15 minutes while at
 * least one form has the feature on.
 *
 * There are no per-email scheduled events. Each run reads what is due from the
 * drafts' recovery rows and re-checks the live state before acting, so a
 * submitted, trashed, deleted or stopped draft simply stops qualifying:
 *  1. detect  — drafts idle past the form's threshold become "abandoned"
 *               (bitform_entry_abandoned fires once per draft);
 *  2. remind  — the next reminder goes out once it is due, in order: one per
 *               run and at least RecoveryRow::MIN_GAP_SECONDS apart, so a late run never
 *               skips one and never sends two at once;
 *  3. cleanup — once a day: drafts past the retention window, expired resume links.
 *
 * Only drafts saved while the feature was on have a recovery row, so turning
 * reminders on never emails visitors with years-old drafts.
 */
final class AbandonmentJob
{
    public const HOOK = 'bitformpro_abandonment_tick';

    public const INTERVAL = 'bitformpro_every_15_minutes';

    private const BATCH = 50;

    private const TIME_BUDGET = 20;

    private const LOCK_SECONDS = 600;

    /** Drafts deleted per form before re-checking the time budget. */
    private const CLEANUP_BATCH = 100;

    private const CLEANUP_TRANSIENT = 'bitformpro_abandonment_cleanup';

    private const REMIND_CURSOR_TRANSIENT = 'bitformpro_abandonment_remind_';

    private const HEAL_TRANSIENT = 'bitformpro_abandonment_heal';

    private const TOKEN_CURSOR = 'bitformpro_resume_token_cursor';

    /** @param mixed $schedules */
    public static function addInterval($schedules)
    {
        if (is_array($schedules) && !isset($schedules[self::INTERVAL])) {
            $schedules[self::INTERVAL] = ['interval' => 15 * MINUTE_IN_SECONDS, 'display' => __('Every 15 minutes', 'bitformpro')];
        }
        return $schedules;
    }

    public static function ensureScheduled()
    {
        if (!wp_next_scheduled(self::HOOK)) {
            wp_schedule_event(time() + MINUTE_IN_SECONDS, self::INTERVAL, self::HOOK);
        }
    }

    public static function unschedule()
    {
        wp_clear_scheduled_hook(self::HOOK);
    }

    /**
     * bitform_form_abandonment_saved — untyped: filter/action arguments can be anything.
     *
     * @param mixed $formId
     * @param mixed $settings
     */
    public static function onSettingsSaved($formId, $settings = null)
    {
        AbandonmentSettings::flushCache();
        if (is_object($settings) && !empty($settings->active)) {
            self::ensureScheduled();
        }
    }

    /**
     * admin_init, at most hourly: reschedule after a cron reset, a migration, or a
     * Free build too old to fire bitform_form_abandonment_saved.
     */
    public static function selfHeal()
    {
        if (wp_next_scheduled(self::HOOK) || get_transient(self::HEAL_TRANSIENT)) {
            return;
        }
        set_transient(self::HEAL_TRANSIENT, 1, HOUR_IN_SECONDS);
        if (!empty(AbandonmentSettings::allActive())) {
            self::ensureScheduled();
        }
    }

    public static function run()
    {
        $configs = AbandonmentSettings::allActive();
        if (empty($configs)) {
            self::unschedule();
            return;
        }
        $deadline = microtime(true) + self::TIME_BUDGET;

        foreach ($configs as $settings) {
            self::detect($settings, $deadline);
        }
        foreach ($configs as $settings) {
            if ($settings->remindersOn()) {
                self::remind($settings, $deadline);
            }
        }
        // Marked done only once it finishes, so a backlog carries on at the next run.
        if (!get_transient(self::CLEANUP_TRANSIENT) && microtime(true) < $deadline && self::cleanup($configs, $deadline)) {
            set_transient(self::CLEANUP_TRANSIENT, 1, DAY_IN_SECONDS);
        }
    }

    public static function detect(AbandonmentSettings $settings, $deadline)
    {
        $model = new EntryRelatedInfoModel();
        $cutoff = gmdate('Y-m-d H:i:s', current_time('timestamp') - $settings->abandonAfterSeconds());
        $rows = $model->recoveriesOfDrafts($settings->formId(), RecoveryState::ACTIVE, $cutoff, self::BATCH);

        foreach ($rows as $row) {
            if (microtime(true) > $deadline) {
                return;
            }
            if ($model->swapRecovery($row, RecoveryState::ABANDONED, $row->afterAbandoned(time())) && !$row->abandonEventFired()) {
                if ('' !== $settings->notifyTemplateId()) {
                    RecoveryMailer::notifyTeam($settings, $row->entry_id);
                }
                do_action(
                    'bitform_entry_abandoned',
                    $settings->formId(),
                    $row->entry_id,
                    RecoveryMailer::entryValues($row->entry_id),
                    [
                        'step'     => $row->step(),
                        'progress' => $row->progress(),
                    ]
                );
            }
        }
    }

    /**
     * Walks every abandoned draft of the form, a page at a time. Drafts stay
     * abandoned after their last reminder, and while they wait for a later one or
     * have no address to send to, so reading only the oldest page would let those
     * drafts block every newer one for good. A run that hits the deadline leaves a
     * cursor, and the next run carries on from it.
     */
    public static function remind(AbandonmentSettings $settings, $deadline)
    {
        if (!$settings->remindersOn()) {
            return;
        }
        $steps = $settings->reminderSteps();
        $model = new EntryRelatedInfoModel();
        $cursorKey = self::REMIND_CURSOR_TRANSIENT . $settings->formId();
        $resumedFrom = (int) get_transient($cursorKey);
        $afterId = $resumedFrom;

        do {
            $rows = $model->recoveriesOfDrafts($settings->formId(), RecoveryState::ABANDONED, '', self::BATCH, $afterId);
            foreach ($rows as $row) {
                if (microtime(true) > $deadline) {
                    if ($afterId > 0) {
                        set_transient($cursorKey, $afterId, DAY_IN_SECONDS);
                    }
                    return;
                }
                $afterId = $row->id;
                $due = $row->dueStep($steps, time());
                if (null !== $due) {
                    self::sendStep($settings, $row, $due, $steps);
                }
            }
        } while (count($rows) === self::BATCH);

        if ($resumedFrom > 0) {
            delete_transient($cursorKey);
        }
    }

    /**
     * Claim the row, send, record the outcome. Also used by the admin "Send reminder now".
     *
     * @param AbandonmentSettings $settings
     * @param RecoveryRow         $row
     * @param int                 $stepIndex
     * @param array               $steps
     *
     * @return array{result:string, reason?:string}
     */
    public static function sendStep(AbandonmentSettings $settings, $row, $stepIndex, array $steps)
    {
        $model = new EntryRelatedInfoModel();
        $now = time();
        $secret = bin2hex(random_bytes(16));
        $claim = $row->afterClaimed(hash('sha256', $secret), $now + self::LOCK_SECONDS);
        if (!$model->swapRecovery($row, $row->status, $claim)) {
            return ['result' => 'skipped', 'reason' => 'busy'];
        }
        $claimed = $row->withDetails($claim);

        $outcome = RecoveryMailer::send($settings, $row->entry_id, $steps[$stepIndex]['templateId'], $secret);

        [$status, $after] = $claimed->afterSend($outcome, $stepIndex, $now);
        $model->swapRecovery($claimed, $status, $after);

        return $outcome;
    }

    /**
     * Each form gets at least one batch, so one form's backlog cannot starve the rest.
     * A batch that deletes less than a full one means nothing is left for that form,
     * or the delete failed; either way it waits for tomorrow rather than retrying now.
     *
     * @param array<int, AbandonmentSettings> $configs
     * @param float                           $deadline
     *
     * @return bool whether every form's expired drafts are gone
     */
    public static function cleanup(array $configs, $deadline)
    {
        $finished = true;
        if (method_exists(EntryTrashService::class, 'purgeExpiredDrafts')) {
            $trash = new EntryTrashService();
            foreach ($configs as $settings) {
                if ($settings->retentionDays() < 1) {
                    continue;
                }
                do {
                    $purged = $trash->purgeExpiredDrafts($settings->formId(), $settings->retentionDays(), self::CLEANUP_BATCH);
                    $backlog = $purged >= self::CLEANUP_BATCH;
                } while ($backlog && microtime(true) < $deadline);
                $finished = $finished && !$backlog;
            }
        }
        $result = (new EntryRelatedInfoModel())->pruneExpiredDraftResumeTokens((int) get_option(self::TOKEN_CURSOR, 0), 500);
        update_option(self::TOKEN_CURSOR, (int) $result['last'], false);

        return $finished;
    }
}
