<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

/**
 * One draft's recovery row, and the only code that knows the keys of its JSON.
 *
 * Reads tolerate anything, because the details are a stored blob. The after*()
 * methods work out the next state without saving it: pass what they return to
 * EntryRelatedInfoModel::swapRecovery(), which compares against $raw, so a row
 * read before someone else's write cannot overwrite it.
 */
final class RecoveryRow
{
    /** Least time between two reminders to one entry, whatever the configured delays. */
    public const MIN_GAP_SECONDS = 10 * MINUTE_IN_SECONDS;

    /** Send failures in a row before the reminders give up. */
    private const MAX_ATTEMPTS = 3;

    /** The visitor fixes these by saving the draft again, so they wait for that. */
    private const STICKY_SKIPS = ['no_recipient', 'no_consent'];

    /** Reminder emails whose stop link keeps working. */
    private const LIVE_STOP_HASHES = 3;

    /** @var int */
    public $id;

    /** @var int */
    public $form_id;

    /** @var int */
    public $entry_id;

    /** @var int a RecoveryState constant */
    public $status;

    /** @var array the decoded details */
    public $details;

    /** @var string the stored JSON, what a compare-and-set compares against */
    public $raw;

    /** @var string the entry's last activity, when the query joined the entry */
    public $entry_updated_at;

    /**
     * @param object $row id, form_id, entry_id, status and info_details, with entry_updated_at when joined
     */
    public static function fromRow($row)
    {
        $details = JSON::decode((string) $row->info_details, true);
        $recovery = new self();
        $recovery->id = (int) $row->id;
        $recovery->form_id = (int) $row->form_id;
        $recovery->entry_id = (int) $row->entry_id;
        $recovery->status = (int) $row->status;
        $recovery->details = is_array($details) ? $details : [];
        $recovery->raw = (string) $row->info_details;
        $recovery->entry_updated_at = isset($row->entry_updated_at) ? (string) $row->entry_updated_at : '';
        return $recovery;
    }

    /**
     * This row as it reads once $details are stored.
     *
     * @param array $details
     *
     * @return self
     */
    public function withDetails(array $details)
    {
        $row = clone $this;
        $row->details = $details;
        $row->raw = JSON::encode($details);
        return $row;
    }

    /** Still collecting reminders: not finished, not stopped by anyone. */
    public function isCollecting()
    {
        return in_array($this->status, [RecoveryState::ACTIVE, RecoveryState::ABANDONED, RecoveryState::FAILED], true);
    }

    /** @return int reminders sent so far */
    public function sent()
    {
        return $this->intDetail('sent');
    }

    /** @return int|null 1-based multi-step position, null when not a multi-step form */
    public function step()
    {
        return isset($this->details['step']) ? (int) $this->details['step'] : null;
    }

    /** @return int|null 0-100 */
    public function progress()
    {
        return isset($this->details['progress']) ? (int) $this->details['progress'] : null;
    }

    /** @return string why the last send was skipped, or '' */
    public function skipped()
    {
        return !empty($this->details['skipped']) && is_string($this->details['skipped']) ? $this->details['skipped'] : '';
    }

    /** @return int unix seconds, 0 when it has not happened */
    public function abandonedAt()
    {
        return $this->intDetail('abandonedAt');
    }

    /** @return int unix seconds, 0 when it has not happened */
    public function lastSentAt()
    {
        return $this->intDetail('lastSentAt');
    }

    /** @return int unix seconds, 0 when it has not happened */
    public function recoveredAt()
    {
        return $this->intDetail('recoveredAt');
    }

    /** @return int unix seconds, 0 when it has not happened */
    public function stoppedAt()
    {
        return $this->intDetail('stoppedAt');
    }

    /** @return int unix seconds, 0 when it has not happened */
    public function failedAt()
    {
        return $this->intDetail('failedAt');
    }

    public function stoppedByAdmin()
    {
        return 'admin' === ($this->details['stoppedBy'] ?? '');
    }

    /** Whether bitform_entry_abandoned has already fired for this draft. */
    public function abandonEventFired()
    {
        return !empty($this->details['eventFired']);
    }

    /** Whether the feature ever acted on this draft, which is what makes a submission a recovery. */
    public function everAbandoned()
    {
        return !empty($this->details['firstAbandonedAt']) || !empty($this->details['sent']);
    }

    /**
     * @param string $secret from a reminder's stop link
     *
     * @return bool
     */
    public function hasStopSecret($secret)
    {
        $hashes = $this->details['stopHashes'] ?? null;
        if (!is_array($hashes)) {
            return false;
        }
        $hash = hash('sha256', $secret);
        foreach ($hashes as $stored) {
            if (is_string($stored) && hash_equals($stored, $hash)) {
                return true;
            }
        }
        return false;
    }

    /**
     * When the next reminder falls due on its own: its delay from the moment the
     * draft was marked abandoned, never sooner than the minimum gap after the
     * previous send.
     *
     * @param array $steps AbandonmentSettings::reminderSteps()
     *
     * @return int unix seconds, 0 when nothing is left to send or the draft was never abandoned
     */
    public function nextDueAt(array $steps)
    {
        $sent = $this->sent();
        if (!$this->abandonedAt() || $sent >= count($steps)) {
            return 0;
        }
        $dueAt = $this->abandonedAt() + (int) $steps[$sent]['delay'];
        if ($sent > 0 && $this->lastSentAt()) {
            $dueAt = max($dueAt, $this->lastSentAt() + self::MIN_GAP_SECONDS);
        }
        return $dueAt;
    }

    /**
     * Which reminder the job should send now, or null.
     *
     * @param array $steps
     * @param int   $now
     *
     * @return int|null
     */
    public function dueStep(array $steps, $now)
    {
        if (in_array($this->skipped(), self::STICKY_SKIPS, true) || $this->intDetail('lockUntil') > $now) {
            return null;
        }
        $dueAt = $this->nextDueAt($steps);
        return $dueAt && $now >= $dueAt ? $this->sent() : null;
    }

    /**
     * @param int $now
     *
     * @return array the details once the draft counts as abandoned
     */
    public function afterAbandoned($now)
    {
        $details = $this->details;
        $details['abandonedAt'] = $now;
        if (empty($details['firstAbandonedAt'])) {
            $details['firstAbandonedAt'] = $now;
        }
        $details['eventFired'] = true;
        return $details;
    }

    /**
     * @param array{step?:int, progress?:int} $progress
     *
     * @return array the details after a partial save. The reminder count stays.
     */
    public function afterSave(array $progress)
    {
        $details = array_merge($this->details, $progress);
        unset($details['skipped'], $details['lockUntil']);
        $details['attempts'] = 0;
        return $details;
    }

    /**
     * @param int $now
     *
     * @return array the details once the draft was submitted
     */
    public function afterRecovered($now)
    {
        $details = $this->details;
        $details['recoveredAt'] = $now;
        unset($details['lockUntil'], $details['stopHashes']);
        return $details;
    }

    /**
     * @param string $by 'visitor' | 'admin'
     * @param int    $now
     *
     * @return array the details once reminders are stopped
     */
    public function afterStopped($by, $now)
    {
        $details = $this->details;
        $details['stoppedAt'] = $now;
        $details['stoppedBy'] = 'admin' === $by ? 'admin' : 'visitor';
        unset($details['lockUntil']);
        return $details;
    }

    /**
     * @param string $stopHash  sha256 of the stop secret going out in this reminder
     * @param int    $lockUntil
     *
     * @return array the details while one process holds the row to send a reminder
     */
    public function afterClaimed($stopHash, $lockUntil)
    {
        $details = $this->details;
        $details['lockUntil'] = $lockUntil;
        $existing = isset($details['stopHashes']) && is_array($details['stopHashes']) ? $details['stopHashes'] : [];
        $details['stopHashes'] = array_slice(array_merge([$stopHash], $existing), 0, self::LIVE_STOP_HASHES);
        return $details;
    }

    /**
     * @param array{result:string, reason?:string} $outcome   RecoveryMailer::send()
     * @param int                                  $stepIndex
     * @param int                                  $now
     *
     * @return array{0:int, 1:array} the status and details once the send is over
     */
    public function afterSend(array $outcome, $stepIndex, $now)
    {
        $details = $this->details;
        unset($details['lockUntil']);
        $status = $this->status;
        if ('sent' === $outcome['result']) {
            $details['sent'] = $stepIndex + 1;
            $details['lastSentAt'] = $now;
            $details['attempts'] = 0;
            unset($details['skipped']);
        } elseif ('failed' === $outcome['result']) {
            $details['attempts'] = (isset($details['attempts']) ? (int) $details['attempts'] : 0) + 1;
            if ($details['attempts'] >= self::MAX_ATTEMPTS) {
                $status = RecoveryState::FAILED;
                $details['failedAt'] = $now;
            }
        } elseif (isset($outcome['reason']) && in_array($outcome['reason'], self::STICKY_SKIPS, true)) {
            $details['skipped'] = $outcome['reason'];
        }
        return [$status, $details];
    }

    private function intDetail($key)
    {
        return isset($this->details[$key]) ? (int) $this->details[$key] : 0;
    }
}
