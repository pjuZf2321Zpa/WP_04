<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Model\FormEntry;
use BitApps\BitFormPro\Services\Admin\FormSettings\DraftResume;
use BitApps\BitFormPro\Compat\EntryTrash;
use BitApps\BitFormPro\Model\EntryRelatedInfoModel;

/**
 * bitforms_abandonment_entry — what the entry page can do with a partial entry.
 *
 * Answered by FormSettingsController::abandonmentEntry(), behind the admin route
 * table's nonce and capability middleware.
 *
 * Tasks: state | send_now | stop | resume_link
 */
final class AbandonmentAdmin
{
    /**
     * @return array|\WP_Error
     */
    public static function run($task, $formId, $entryId)
    {
        $settings = AbandonmentSettings::forForm($formId);
        $row = (new EntryRelatedInfoModel())->getRecovery($entryId);

        switch ($task) {
            case 'send_now':
                if (null === $settings || !$settings->remindersOn()) {
                    return new \WP_Error('off', __('Reminder emails are turned off for this form.', 'bitformpro'));
                }
                if (null === $row || !$row->isCollecting() || !self::isDraft($entryId)) {
                    return new \WP_Error('state', __('Reminders can only be sent for an unfinished entry that is still collecting reminders.', 'bitformpro'));
                }
                $steps = $settings->reminderSteps();
                $next = $row->sent();
                if ($next >= count($steps)) {
                    return new \WP_Error('done', __('Every reminder has already been sent.', 'bitformpro'));
                }
                $outcome = AbandonmentJob::sendStep($settings, $row, $next, $steps);
                if ('sent' !== $outcome['result']) {
                    return new \WP_Error('send', self::reasonText($outcome['reason'] ?? 'failed'));
                }
                break;

            case 'stop':
                if (null === $row || !RecoveryState::stop($row, 'admin')) {
                    return new \WP_Error('state', __('There are no reminders to stop for this entry.', 'bitformpro'));
                }
                break;

            case 'resume_link':
                if (null === $settings || !self::isDraft($entryId)) {
                    return new \WP_Error('state', __('A resume link exists only for an unfinished entry of a form with Form Abandonment on.', 'bitformpro'));
                }
                $link = DraftResume::issueLink($formId, $entryId, RecoveryMailer::linkBase($entryId), $settings);
                if (empty($link)) {
                    return new \WP_Error('link', __('Could not create a resume link. Please try again.', 'bitformpro'));
                }
                return ['url' => $link['url'], 'expires' => $link['expires']] + self::state($settings, $entryId);
        }

        return self::state($settings, $entryId);
    }

    /**
     * Timestamps are unix seconds, 0 when unknown. `sendBlockedReason` is set
     * when the entry is still collecting reminders but "send now" cannot run, so
     * the panel can show a disabled button that says why instead of nothing.
     *
     * @return array{state:string|null, badges:array, sent:int, steps:int, canSendNow:bool, canStop:bool, canCopyLink:bool, remindersOn:bool, abandonedAt:int, lastSentAt:int, nextDueAt:int, sendBlockedReason:string}
     */
    public static function state($settings, $entryId)
    {
        $row = (new EntryRelatedInfoModel())->getRecovery($entryId);
        $isDraft = self::isDraft($entryId);
        $stepList = null !== $settings ? $settings->reminderSteps() : [];
        $steps = count($stepList);
        $sent = null !== $row ? $row->sent() : 0;
        $collecting = null !== $row && $row->isCollecting();
        $remindersOn = null !== $settings && $settings->remindersOn();
        $skipped = null !== $row ? $row->skipped() : '';
        $nextDueAt = null !== $row && $remindersOn && $collecting && $isDraft ? $row->nextDueAt($stepList) : 0;

        $blocked = '';
        if ($isDraft && $collecting && $steps > 0 && $sent >= $steps) {
            $blocked = __('Every reminder has already been sent.', 'bitformpro');
        } elseif ($isDraft && $collecting && !$remindersOn) {
            $blocked = __('Reminder emails are turned off for this form.', 'bitformpro');
        } elseif ($isDraft && $collecting && '' !== $skipped) {
            $blocked = self::reasonText($skipped);
        }
        $names = [
            RecoveryState::ACTIVE    => 'active',
            RecoveryState::ABANDONED => 'abandoned',
            RecoveryState::RECOVERED => 'recovered',
            RecoveryState::STOPPED   => 'stopped',
            RecoveryState::FAILED    => 'failed',
        ];

        return [
            'state'       => null !== $row && isset($names[$row->status]) ? $names[$row->status] : null,
            'badges'      => null !== $row ? AbandonmentHooks::badgesFor($row) : [],
            'sent'        => $sent,
            'steps'       => $steps,
            'canSendNow'  => $isDraft && $collecting && $remindersOn && $sent < $steps,
            'canStop'     => $isDraft && $collecting,
            'canCopyLink' => $isDraft && null !== $settings,
            'remindersOn' => $remindersOn,
            'abandonedAt' => null !== $row ? $row->abandonedAt() : 0,
            'lastSentAt'  => null !== $row ? $row->lastSentAt() : 0,
            'nextDueAt'   => $nextDueAt,
            'sendBlockedReason' => $blocked,
        ];
    }

    public static function entryOfForm($formId, $entryId)
    {
        return FormEntry::existsWhere(['id' => (int) $entryId, 'form_id' => (int) $formId]);
    }

    private static function isDraft($entryId)
    {
        return FormEntry::existsWhere(EntryTrash::activeOnly(['id' => (int) $entryId, 'status' => 9]));
    }

    private static function reasonText($reason)
    {
        $texts = [
            'no_recipient' => __('This entry has no valid email address to send to.', 'bitformpro'),
            'no_consent'   => __('The visitor has not ticked the consent field required for reminders.', 'bitformpro'),
            'no_template'  => __('The reminder\'s email template is missing or turned off.', 'bitformpro'),
            'rate_limited' => __('The daily reminder limit for this address or form has been reached.', 'bitformpro'),
            'busy'         => __('A reminder for this entry is being sent right now.', 'bitformpro'),
        ];
        return $texts[$reason] ?? __('The email could not be sent. See the activity log.', 'bitformpro');
    }
}
