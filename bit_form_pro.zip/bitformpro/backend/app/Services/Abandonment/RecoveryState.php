<?php

namespace BitApps\BitFormPro\Services\Abandonment;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitFormPro\Model\EntryRelatedInfoModel;

/**
 * Where a Form Abandonment draft is in its life, kept beside the entry.
 *
 * The entry's own status stays 9 (Partial) until the visitor submits; this row
 * says what the abandonment feature has done with it. One row per draft in
 * bitforms_form_entry_relatedinfo (info_type draft_recovery), deleted with the
 * entry. Every change is a compare-and-set, so overlapping cron runs, admin
 * clicks and visitor saves cannot act on a draft twice.
 */
final class RecoveryState
{
    /** Being filled in; no inactivity long enough to call it abandoned. */
    public const ACTIVE = 1;

    /** Inactive past the form's threshold; reminders may go out. */
    public const ABANDONED = 2;

    /** Submitted after it had been abandoned. The entry itself is no longer a draft. */
    public const RECOVERED = 3;

    /** Reminders stopped by the visitor's link or an admin. */
    public const STOPPED = 4;

    /** Reminders gave up after repeated send failures. */
    public const FAILED = 5;

    /**
     * A partial save: create the row or refresh its progress. Activity after an
     * abandonment puts the draft back in progress; the reminder count is kept,
     * so a visitor who leaves again continues the sequence instead of restarting it.
     *
     * @param int      $formId
     * @param int      $entryId
     * @param int|null $step     1-based multi-step position, null when not a multi-step form
     * @param int|null $progress 0-100
     */
    public static function touch($formId, $entryId, $step, $progress)
    {
        $model = new EntryRelatedInfoModel();
        $progressDetails = array_filter(['step' => $step, 'progress' => $progress], static function ($v) {
            return null !== $v;
        });

        for ($attempt = 0; $attempt < 2; $attempt++) {
            $row = $model->getRecovery($entryId);
            if (null === $row) {
                $model->insertRecovery($formId, $entryId, self::ACTIVE, $progressDetails + ['sent' => 0]);
                return;
            }
            if (self::RECOVERED === $row->status) {
                return;
            }
            $status = in_array($row->status, [self::ABANDONED, self::FAILED], true) ? self::ACTIVE : $row->status;
            if ($model->swapRecovery($row, $status, $row->afterSave($progressDetails))) {
                return;
            }
        }
    }

    /**
     * The draft was submitted. Only a draft that had been abandoned (or reminded)
     * counts as recovered; any other draft just finished normally and its row goes.
     *
     * @param int $formId
     * @param int $entryId
     */
    public static function completed($formId, $entryId)
    {
        $model = new EntryRelatedInfoModel();
        $row = $model->getRecovery($entryId);
        if (null === $row || self::RECOVERED === $row->status) {
            return;
        }
        if (!$row->everAbandoned()) {
            $model->deleteRecovery($row->id);
            return;
        }
        if ($model->swapRecovery($row, self::RECOVERED, $row->afterRecovered(time()))) {
            do_action('bitform_entry_recovered', (int) $formId, (int) $entryId);
        }
    }

    /**
     * @param RecoveryRow $row
     * @param string      $by 'visitor' | 'admin'
     *
     * @return bool
     */
    public static function stop(RecoveryRow $row, $by)
    {
        if (!$row->isCollecting()) {
            return false;
        }
        return (new EntryRelatedInfoModel())->swapRecovery($row, self::STOPPED, $row->afterStopped($by, time()));
    }
}
