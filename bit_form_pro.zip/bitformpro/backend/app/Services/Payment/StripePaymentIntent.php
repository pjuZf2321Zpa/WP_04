<?php

namespace BitApps\BitFormPro\Services\Payment;

use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use WP_Error;

/**
 * Hands the Stripe field a client secret, keeping one PaymentIntent per form entry.
 *
 * The browser asks for a client secret every time "Pay with Stripe" is clicked. Creating
 * a fresh PaymentIntent on each ask let a customer pay twice for one entry: the card is
 * charged before the final form submit, and when that submit failed the customer paid
 * again on a brand-new intent. So an entry that already holds a paid intent is refused,
 * and an unpaid one is reused instead of replaced.
 */
class StripePaymentIntent
{
    private const ENDPOINT = 'https://api.stripe.com/v1/payment_intents';

    /** Charged, or charging; a second intent for the entry would be a second charge. */
    private const PAID_STATUSES = ['succeeded', 'processing', 'requires_capture'];

    private const REUSABLE_STATUSES = ['requires_payment_method', 'requires_confirmation', 'requires_action'];

    public const ALREADY_PAID = 'bitform_stripe_already_paid';

    private $secretKey;

    /**
     * @param string $secretKey merchant's Stripe secret key
     */
    public function __construct($secretKey)
    {
        $this->secretKey = (string) $secretKey;
    }

    /**
     * @param array $intentData create params (amount, currency, metadata, ...), metadata holds formID/entryID/fieldKey
     *
     * @return string|WP_Error|object client secret; WP_Error when refused; Stripe's error object as-is
     */
    public function clientSecretFor(array $intentData)
    {
        $metadata = isset($intentData['metadata']) ? (array) $intentData['metadata'] : [];
        $formId = absint($metadata['formID'] ?? 0);
        $entryId = absint($metadata['entryID'] ?? 0);
        $fieldKey = sanitize_text_field((string) ($metadata['fieldKey'] ?? ''));

        // No saved entry to key on (older front end): nothing to dedupe against.
        if (!$formId || !$entryId || '' === $fieldKey) {
            return $this->create($intentData, null);
        }

        if (!EntryPaymentLookup::entryBelongsToForm($entryId, $formId)) {
            return new WP_Error('bitform_stripe_entry_mismatch', __('Entry does not belong to this form', 'bitformpro'), ['status' => 403]);
        }

        if ($this->findPaidIntent($formId, $entryId, $fieldKey)) {
            return $this->alreadyPaidError();
        }

        $cacheKey = $this->cacheKey($formId, $entryId, $fieldKey);
        $cachedId = get_transient($cacheKey);
        if (is_string($cachedId) && '' !== $cachedId) {
            $intent = $this->retrieve($cachedId);
            if ($this->isIntentFor($intent, $formId, $entryId, $fieldKey)) {
                if (in_array($intent->status, self::PAID_STATUSES, true)) {
                    return $this->alreadyPaidError();
                }
                if (in_array($intent->status, self::REUSABLE_STATUSES, true)) {
                    // Re-apply the current request so an amount changed on the form since the
                    // first click — or a value planted by another caller — is what gets charged.
                    $updated = $this->update($intent->id, $this->updatableParams($intentData));
                    if (is_object($updated) && !empty($updated->client_secret)) {
                        return $updated->client_secret;
                    }
                    return $updated;
                }
            }
        }

        $intent = $this->create($intentData, $this->idempotencyKey($formId, $entryId, $fieldKey, $intentData));
        if (is_object($intent) && !empty($intent->id) && !empty($intent->client_secret)) {
            set_transient($cacheKey, $intent->id, DAY_IN_SECONDS);
            return $intent->client_secret;
        }
        return $intent;
    }

    /**
     * Entry meta survives the transient being evicted, so it is checked first.
     *
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     *
     * @return bool
     */
    private function findPaidIntent($formId, $entryId, $fieldKey)
    {
        foreach (EntryPaymentLookup::transactionIds($entryId, $fieldKey, 'pi_') as $intentId) {
            $intent = $this->retrieve($intentId);
            if ($this->isIntentFor($intent, $formId, $entryId, $fieldKey)
                && in_array($intent->status, self::PAID_STATUSES, true)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param mixed  $intent
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     *
     * @return bool
     *
     * @phpstan-assert-if-true object $intent
     */
    private function isIntentFor($intent, $formId, $entryId, $fieldKey)
    {
        if (!is_object($intent) || empty($intent->id) || empty($intent->status) || !isset($intent->metadata)) {
            return false;
        }
        return EntryPaymentLookup::metadataMatches($intent->metadata, $formId, $entryId, $fieldKey);
    }

    /**
     * Payment method settings are fixed at creation (automatic_payment_methods cannot be
     * updated), so only the values the customer can change on the form are re-sent.
     *
     * @param array $intentData
     *
     * @return array
     */
    private function updatableParams(array $intentData)
    {
        return array_intersect_key($intentData, array_flip(['amount', 'currency', 'description', 'metadata', 'shipping']));
    }

    /**
     * Two requests racing for the same entry (a double click before the transient is
     * written) send the same key, so Stripe returns one intent instead of two. Any change
     * to the request yields a new key, which Stripe requires for different parameters.
     *
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     * @param array  $intentData
     *
     * @return string
     */
    private function idempotencyKey($formId, $entryId, $fieldKey, array $intentData)
    {
        return 'bitform-' . hash('sha256', JSON::encode([home_url(), $formId, $entryId, $fieldKey, $intentData]));
    }

    /**
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     *
     * @return string
     */
    private function cacheKey($formId, $entryId, $fieldKey)
    {
        return 'bitform_stripe_pi_' . md5("{$formId}|{$entryId}|{$fieldKey}");
    }

    /**
     * Same shape as a Stripe error, which the field already knows how to display.
     *
     * @return WP_Error
     */
    private function alreadyPaidError()
    {
        return new WP_Error(
            self::ALREADY_PAID,
            __('Your payment has already been received. Please submit the form to finish.', 'bitformpro'),
            ['status' => 409],
        );
    }

    /**
     * @param array       $intentData
     * @param string|null $idempotencyKey
     *
     * @return object|string|WP_Error
     */
    private function create(array $intentData, $idempotencyKey)
    {
        $headers = $this->headers();
        if ($idempotencyKey) {
            $headers['Idempotency-Key'] = $idempotencyKey;
        }
        return HttpHelper::post(self::ENDPOINT, $intentData, $headers);
    }

    /**
     * @param string $intentId
     * @param array  $params
     *
     * @return object|string|WP_Error
     */
    private function update($intentId, array $params)
    {
        return HttpHelper::post(self::ENDPOINT . '/' . rawurlencode($intentId), $params, $this->headers());
    }

    /**
     * @param string $intentId
     *
     * @return object|string|WP_Error
     */
    private function retrieve($intentId)
    {
        return HttpHelper::get(self::ENDPOINT . '/' . rawurlencode($intentId), null, $this->headers());
    }

    /**
     * @return array
     */
    private function headers()
    {
        return [
            'Content-Type'  => 'application/x-www-form-urlencoded',
            'Authorization' => "Bearer {$this->secretKey}",
        ];
    }
}
