<?php

namespace BitApps\BitFormPro\Services\Payment;

use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitForm\Model\FormEntry;

/**
 * Where a gateway's earlier payment for an entry can be found.
 *
 * insertPayment, saveRazorpayDetails and the webhooks record a paid transaction id as the
 * payment field's entry meta. Those rows are leads only — insertPayment writes whatever id
 * it is given — so callers confirm each one with the gateway before trusting it.
 */
final class EntryPaymentLookup
{
    /**
     * @param int $entryId
     * @param int $formId
     *
     * @return bool
     */
    public static function entryBelongsToForm($entryId, $formId)
    {
        if (!$entryId || !$formId) {
            return false;
        }
        return FormEntry::existsWhere(['id' => (int) $entryId, 'form_id' => (int) $formId]);
    }

    /**
     * @param int    $entryId
     * @param string $fieldKey
     * @param string $prefix   gateway id prefix, e.g. "pi_", "pay_", "tr_"
     *
     * @return string[]
     */
    public static function transactionIds($entryId, $fieldKey, $prefix)
    {
        if (!$entryId || '' === (string) $fieldKey) {
            return [];
        }
        $rows = FormEntryMeta::rowsWhere(['bitforms_form_entry_id' => (int) $entryId, 'meta_key' => (string) $fieldKey], ['meta_value']);

        $ids = [];
        foreach ($rows as $row) {
            $value = isset($row->meta_value) ? (string) $row->meta_value : '';
            if (0 === strpos($value, $prefix)) {
                $ids[] = $value;
            }
        }
        return array_values(array_unique($ids));
    }

    /**
     * Gateways echo back the routing metadata we attached at creation; a paid transaction
     * only counts for the entry it was created for.
     *
     * @param mixed  $metadata gateway metadata/notes object
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     *
     * @return bool
     */
    public static function metadataMatches($metadata, $formId, $entryId, $fieldKey)
    {
        if (!is_object($metadata) && !is_array($metadata)) {
            return false;
        }
        $metadata = (object) $metadata;

        return (int) ($metadata->formID ?? 0) === (int) $formId
            && (int) ($metadata->entryID ?? 0) === (int) $entryId
            && (string) ($metadata->fieldKey ?? '') === (string) $fieldKey;
    }
}
