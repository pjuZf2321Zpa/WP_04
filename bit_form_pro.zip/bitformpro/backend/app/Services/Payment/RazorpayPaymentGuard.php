<?php

namespace BitApps\BitFormPro\Services\Payment;

use BitApps\BitForm\Helpers\HttpHelper;

/**
 * Stops a second Razorpay payment from being taken for one form entry.
 *
 * The field charges before the final form submit. When that submit failed the customer
 * paid again, and saveRazorpayDetails captured the second payment too. An entry whose
 * earlier payment is already captured now gets no new order and no second capture; an
 * uncaptured payment is voided by Razorpay instead of being kept.
 */
class RazorpayPaymentGuard
{
    public const ALREADY_PAID = 'bitform_razorpay_already_paid';

    private $keyId;

    private $keySecret;

    /**
     * @param string $keyId
     * @param string $keySecret
     */
    public function __construct($keyId, $keySecret)
    {
        $this->keyId = (string) $keyId;
        $this->keySecret = (string) $keySecret;
    }

    /**
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     * @param string $exceptPaymentId the payment being recorded now, which must not count against itself
     *
     * @return bool
     */
    public function isEntryPaid($formId, $entryId, $fieldKey, $exceptPaymentId = '')
    {
        $formId = absint($formId);
        $entryId = absint($entryId);
        $fieldKey = sanitize_text_field((string) $fieldKey);
        if (!EntryPaymentLookup::entryBelongsToForm($entryId, $formId) || '' === $fieldKey) {
            return false;
        }

        foreach (EntryPaymentLookup::transactionIds($entryId, $fieldKey, 'pay_') as $paymentId) {
            if ($paymentId === $exceptPaymentId || 1 !== preg_match('/^[A-Za-z0-9_]+$/', $paymentId)) {
                continue;
            }
            $payment = HttpHelper::get(
                "https://api.razorpay.com/v1/payments/{$paymentId}",
                null,
                ['Authorization' => 'Basic ' . base64_encode("{$this->keyId}:{$this->keySecret}")],
            );
            if (is_object($payment)
                && 'captured' === ($payment->status ?? '')
                && EntryPaymentLookup::metadataMatches($payment->notes ?? null, $formId, $entryId, $fieldKey)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Shaped like Razorpay's own error body, which the field already reads.
     *
     * @return array
     */
    public static function alreadyPaidResponse()
    {
        return [
            'error' => [
                'code'        => self::ALREADY_PAID,
                'description' => __('Your payment has already been received. Please submit the form to finish.', 'bitformpro'),
            ],
        ];
    }
}
