<?php

namespace BitApps\BitFormPro\Services\Payment;

use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use WP_Error;

/**
 * Creates the Mollie payment for a form entry — once — and remembers which payment a
 * return visit belongs to.
 *
 * Every "Pay with Mollie" click used to create a new payment, so an entry could be paid
 * twice. The return page also read the id of the last payment created on the whole site
 * from one option, so two customers paying at once could see — and process — each
 * other's payment. Each payment now carries its own reference in the return URL.
 */
class MolliePaymentSession
{
    private const ENDPOINT = 'https://api.mollie.com/v2/payments';

    /** Paid, or settling; a new payment for the entry would be a second charge. */
    private const PAID_STATUSES = ['paid', 'authorized', 'pending'];

    public const ALREADY_PAID = 'bitform_mollie_already_paid';

    private $apiKey;

    /**
     * @param string $apiKey merchant's Mollie API key
     */
    public function __construct($apiKey)
    {
        $this->apiKey = (string) $apiKey;
    }

    /**
     * @param array      $paymentData Mollie create body; metadata holds formID/entryID/fieldKey
     * @param int|string $integId     payment integration id, needed again on the return page
     *
     * @return object|string|WP_Error Mollie payment (or Mollie's error body); WP_Error when refused
     */
    public function paymentFor(array $paymentData, $integId)
    {
        $metadata = isset($paymentData['metadata']) ? (array) $paymentData['metadata'] : [];
        $formId = absint($metadata['formID'] ?? 0);
        $entryId = absint($metadata['entryID'] ?? 0);
        $fieldKey = sanitize_text_field((string) ($metadata['fieldKey'] ?? ''));

        if (!$formId || !$entryId || '' === $fieldKey) {
            return $this->create($paymentData, $integId);
        }
        if (!EntryPaymentLookup::entryBelongsToForm($entryId, $formId)) {
            return new WP_Error('bitform_mollie_entry_mismatch', __('Entry does not belong to this form', 'bitformpro'), ['status' => 403]);
        }

        foreach (EntryPaymentLookup::transactionIds($entryId, $fieldKey, 'tr_') as $paymentId) {
            $payment = $this->retrieve($paymentId);
            if ($this->isPaymentFor($payment, $formId, $entryId, $fieldKey) && in_array($payment->status, self::PAID_STATUSES, true)) {
                return $this->alreadyPaidError();
            }
        }

        $cacheKey = 'bitform_mollie_tr_' . md5("{$formId}|{$entryId}|{$fieldKey}");
        $cachedId = get_transient($cacheKey);
        if (is_string($cachedId) && '' !== $cachedId) {
            $payment = $this->retrieve($cachedId);
            if ($this->isPaymentFor($payment, $formId, $entryId, $fieldKey)) {
                if (in_array($payment->status, self::PAID_STATUSES, true)) {
                    return $this->alreadyPaidError();
                }
                // Mollie cannot change an open payment's amount, so it is only reused unchanged.
                if ('open' === $payment->status && $this->sameAmount($payment, $paymentData) && !empty($payment->_links->checkout->href)) {
                    return $payment;
                }
            }
        }

        $payment = $this->create($paymentData, $integId);
        if (is_object($payment) && !empty($payment->id) && is_string($payment->id)) {
            set_transient($cacheKey, $payment->id, DAY_IN_SECONDS);
        }
        return $payment;
    }

    /**
     * @param string $ref value of the bf_ref query arg on the return URL
     *
     * @return array|null {paymentId, integId}
     */
    public static function paymentForReturn($ref)
    {
        $ref = sanitize_key((string) $ref);
        if ('' === $ref) {
            return null;
        }
        $session = get_transient('bitform_mollie_ref_' . $ref);

        return is_array($session) && !empty($session['paymentId']) ? $session : null;
    }

    /**
     * @param array      $paymentData
     * @param int|string $integId
     *
     * @return object|string|WP_Error
     */
    private function create(array $paymentData, $integId)
    {
        $ref = strtolower(wp_generate_password(24, false, false));
        $paymentData['redirectUrl'] = add_query_arg('bf_ref', $ref, (string) ($paymentData['redirectUrl'] ?? ''));

        $payment = HttpHelper::post(self::ENDPOINT, JSON::encode($paymentData), $this->headers());
        if (is_object($payment) && !empty($payment->id) && is_string($payment->id)) {
            set_transient('bitform_mollie_ref_' . $ref, ['paymentId' => $payment->id, 'integId' => $integId], DAY_IN_SECONDS);
        }
        return $payment;
    }

    /**
     * @param string $paymentId
     *
     * @return object|string|WP_Error
     */
    private function retrieve($paymentId)
    {
        return HttpHelper::get(self::ENDPOINT . '/' . rawurlencode($paymentId), '', $this->headers());
    }

    /**
     * @param mixed  $payment
     * @param int    $formId
     * @param int    $entryId
     * @param string $fieldKey
     *
     * @return bool
     *
     * @phpstan-assert-if-true object $payment
     */
    private function isPaymentFor($payment, $formId, $entryId, $fieldKey)
    {
        return is_object($payment)
            && !empty($payment->id)
            && !empty($payment->status)
            && EntryPaymentLookup::metadataMatches($payment->metadata ?? null, $formId, $entryId, $fieldKey);
    }

    /**
     * @param object $payment
     * @param array  $paymentData
     *
     * @return bool
     */
    private function sameAmount($payment, array $paymentData)
    {
        $wanted = (array) ($paymentData['amount'] ?? []);

        return isset($payment->amount->value, $payment->amount->currency)
            && (string) $payment->amount->value === (string) ($wanted['value'] ?? '')
            && strtoupper((string) $payment->amount->currency) === strtoupper((string) ($wanted['currency'] ?? ''));
    }

    /**
     * @return WP_Error
     */
    private function alreadyPaidError()
    {
        return new WP_Error(
            self::ALREADY_PAID,
            __('Your payment has already been received for this submission.', 'bitformpro'),
            ['status' => 409],
        );
    }

    /**
     * @return array
     */
    private function headers()
    {
        return [
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type'  => 'application/json',
        ];
    }
}
