<?php

/**
 * Bit Form Pro Theme Manager
 * Handles custom theme CRUD operations
 */

namespace BitApps\BitFormPro\Services;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use WP_Error;

class ThemeManager
{
    private static $option_name = 'bitform_custom_themes';
    private static $default_theme_option = 'bitformDefault';

    /**
     * Get all custom themes
     *
     * @return array
     */
    public static function get_custom_themes()
    {
        $themes = get_option(self::$option_name, []);
        return is_array($themes) ? $themes : [];
    }

    /**
     * Get a specific theme by slug
     *
     * @param string $theme_slug
     * @return array|null
     */
    public static function get_theme($theme_slug)
    {
        $themes = self::get_custom_themes();
        return isset($themes[$theme_slug]) ? $themes[$theme_slug] : null;
    }

    /**
     * Save or update a custom theme
     *
     * @param array $theme_data
     * @return array|WP_Error
     */
    public static function save_theme($theme_data)
    {
        try {
            // Validate required fields
            if (empty($theme_data['id']) || empty($theme_data['name'])) {
                return new \WP_Error('invalid_data', 'Theme ID and name are required');
            }

            $themes = self::get_custom_themes();
            $theme_id = sanitize_title($theme_data['id']);
            $theme_slug = sanitize_title($theme_data['id']);

            // Prepare theme data
            $theme = [
                'id'          => $theme_id,
                'slug'        => $theme_slug,
                'name'        => sanitize_text_field($theme_data['name']),
                'type'        => 'custom',
                'basedOn'     => sanitize_text_field($theme_data['basedOn'] ?? 'bitformDefault'),
                'created_at'  => isset($themes[$theme_slug]) ? $themes[$theme_slug]['created_at'] : current_time('timestamp'),
                'updated_at'  => current_time('timestamp'),
                'thumbnail'   => $theme_data['thumbnail'] ?? '',
                'is_default'  => $theme_data['is_default'] ?? false,
                'font'        => $theme_data['font'] ?? [],
                'themeColors' => $theme_data['themeColors'] ?? [],
                'themeVars'   => $theme_data['themeVars'] ?? [],
                'styles'      => $theme_data['styles'] ?? [],
            ];

            $themes[$theme_slug] = $theme;

            $updated = update_option(self::$option_name, $themes);

            if (!$updated && !isset($themes[$theme_slug])) {
                return new \WP_Error('save_failed', 'Failed to save theme');
            }

            return [
                'success' => true,
                'message' => 'Theme saved successfully',
                'theme'   => $theme,
            ];
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }

    /**
     * Delete a custom theme
     *
     * @param string $theme_slug
     * @return array|WP_Error
     */
    public static function delete_theme($theme_slug)
    {
        try {
            $themes = self::get_custom_themes();

            if (!isset($themes[$theme_slug])) {
                return new \WP_Error('not_found', 'Theme not found');
            }

            // Prevent deleting default theme
            if ($themes[$theme_slug]['is_default'] ?? false) {
                return new \WP_Error('is_default', 'Cannot delete default theme. Set another theme as default first.');
            }

            unset($themes[$theme_slug]);
            update_option(self::$option_name, $themes);

            return [
                'success' => true,
                'message' => 'Theme deleted successfully',
            ];
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }

    /**
     * Duplicate a theme
     *
     * @param string $source_slug
     * @param string $new_name
     * @return array|WP_Error
     */
    public static function duplicate_theme($source_slug, $new_name)
    {
        try {
            $themes = self::get_custom_themes();

            // Check if source exists in custom themes
            $source_theme = null;
            if (isset($themes[$source_slug])) {
                $source_theme = $themes[$source_slug];
            } else {
                // Source might be a built-in theme, we'll handle this in JS
                return new \WP_Error('not_found', 'Source theme not found in custom themes');
            }

            $new_slug = sanitize_title($new_name) . '_' . time();

            $new_theme = $source_theme;
            $new_theme['id'] = $new_slug;
            $new_theme['name'] = $new_name;
            $new_theme['type'] = 'custom';
            $new_theme['created_at'] = current_time('timestamp');
            $new_theme['updated_at'] = current_time('timestamp');
            $new_theme['is_default'] = false;

            return self::save_theme($new_theme);
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }

    /**
     * Set default theme
     *
     * @param string $theme_slug
     * @return array|WP_Error
     */
    public static function set_default_theme($theme_slug)
    {
        try {
            $themes = self::get_custom_themes();

            // Remove default from all themes
            foreach ($themes as $slug => &$theme) {
                $theme['is_default'] = false;
            }

            // Set new default
            if (isset($themes[$theme_slug])) {
                $themes[$theme_slug]['is_default'] = true;
                update_option(self::$option_name, $themes);
                update_option(self::$default_theme_option, $theme_slug);
            } else {
                // It's a built-in theme
                update_option(self::$default_theme_option, $theme_slug);
            }

            return [
                'success'    => true,
                'message'    => 'Default theme set successfully',
                'theme_slug' => $theme_slug,
            ];
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }

    /**
     * Get default theme slug
     *
     * @return string
     */
    public static function get_default_theme()
    {
        return get_option(self::$default_theme_option, 'bitformDefault');
    }

    /**
     * Rename a custom theme
     *
     * @param string $theme_slug
     * @param string $new_name
     * @return array|WP_Error
     */
    public static function rename_theme($theme_slug, $new_name)
    {
        try {
            $themes = self::get_custom_themes();

            if (!isset($themes[$theme_slug])) {
                return new \WP_Error('not_found', 'Theme not found');
            }

            $themes[$theme_slug]['name'] = sanitize_text_field($new_name);
            $themes[$theme_slug]['updated_at'] = current_time('timestamp');

            update_option(self::$option_name, $themes);

            return [
                'success' => true,
                'message' => 'Theme renamed successfully',
                'theme'   => $themes[$theme_slug],
            ];
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }

    /**
     * Export theme as JSON
     *
     * @param string $theme_slug
     * @return string|WP_Error
     */
    public static function export_theme($theme_slug)
    {
        try {
            $themes = self::get_custom_themes();

            if (!isset($themes[$theme_slug])) {
                return new \WP_Error('not_found', 'Theme not found');
            }

            $theme = $themes[$theme_slug];
            $theme['exported_at'] = current_time('timestamp');
            $theme['exported_from'] = get_site_url();

            return json_encode($theme, JSON_PRETTY_PRINT);
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }

    /**
     * Import theme from JSON
     *
     * @param string $json_data
     * @param string $new_name (optional)
     * @return array|WP_Error
     */
    public static function import_theme($json_data, $new_name = null)
    {
        try {
            $theme_data = JSON::decode($json_data, true);

            if (JSON_ERROR_NONE !== json_last_error()) {
                return new \WP_Error('invalid_json', 'Invalid JSON data');
            }

            // Generate new slug to avoid conflicts
            $theme_data['id'] = sanitize_title($new_name ?? $theme_data['name']) . '_' . time();
            $theme_data['name'] = $new_name ?? $theme_data['name'] . ' (Imported)';
            $theme_data['type'] = 'custom';
            $theme_data['is_default'] = false;

            return self::save_theme($theme_data);
        } catch (\Exception $e) {
            return new \WP_Error('exception', $e->getMessage());
        }
    }
}
