<?php

namespace BitApps\BitFormPro\Services;

if (!defined('ABSPATH')) {
    exit;
}

class ScriptFilePriorityManager
{
    public static function formAbandonmentNeededFiles($abandonType = null)
    {
        $files = [
            'autoSave' => [
                ['priority' => 201, 'filename' => 'bit-page-lifecycle.min.js'],
                ['priority' => 402, 'filename' => 'autoSavePartial.min.js'],
            ],
        ];

        $required = [
            ['priority' => 402, 'filename' => 'bit-form-abandonment.min.js'],
            ['priority' => 401, 'filename' => 'saveFormProgress.min.js'],
            ['priority' => 701, 'filename' => 'setFieldValues.min.js'],
        ];

        return isset($files[$abandonType]) ? array_merge($files[$abandonType], $required) : $required;
    }

    public static function scriptFilePriorityList(): array
    {
        return [
            'paypal' => [
                ['priority' => 201, 'filename' => 'isFormValidatedWithoutError.min.js'],
                ['priority' => 202, 'filename' => 'saveFormProgress.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 301, 'filename' => 'bit-paypal-field.min.js'],
                ['priority' => 302, 'filename' => 'scriptLoader.min.js'],
                ['priority' => 303, 'filename' => 'initPaypalFld.min.js'],
            ],
            'stripe' => [
                ['priority' => 201, 'filename' => 'bitsFetchFront.min.js'],
                ['priority' => 201, 'filename' => 'isFormValidatedWithoutError.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 202, 'filename' => 'saveFormProgress.min.js'],
                ['priority' => 301, 'filename' => 'bit-stripe-field.min.js'],
                ['priority' => 302, 'filename' => 'scriptLoader.min.js'],
                ['priority' => 303, 'filename' => 'initStripeFld.min.js'],
            ],
            'mollie' => [
                ['priority' => 201, 'filename' => 'bitsFetchFront.min.js'],
                ['priority' => 201, 'filename' => 'isFormValidatedWithoutError.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 202, 'filename' => 'saveFormProgress.min.js'],
                ['priority' => 301, 'filename' => 'bit-mollie-field.min.js'],
                ['priority' => 302, 'filename' => 'scriptLoader.min.js'],
                ['priority' => 303, 'filename' => 'initStripeFld.min.js'],
            ],
            'razorpay' => [
                ['priority' => 201, 'filename' => 'replaceFieldAndSmartValues.min.js'],
                ['priority' => 201, 'filename' => 'isFormValidatedWithoutError.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 202, 'filename' => 'saveFormProgress.min.js'],
                ['priority' => 301, 'filename' => 'bit-razorpay-field.min.js'],
                ['priority' => 302, 'filename' => 'scriptLoader.min.js'],
                ['priority' => 303, 'filename' => 'initRazorpayFld.min.js'],
            ],
            'radio' => [
                ['priority' => 301, 'filename' => 'initAddOtherOpt.min.js', 'path' => 'addOtherOpt'],
                ['priority' => 301, 'filename' => 'resetOtherOpt.min.js', 'path' => 'addOtherOpt'],
            ],
            'check' => [
                ['priority' => 301, 'filename' => 'initAddOtherOpt.min.js', 'path' => 'addOtherOpt'],
                ['priority' => 301, 'filename' => 'resetOtherOpt.min.js', 'path' => 'addOtherOpt'],
                ['priority' => 302, 'filename' => 'initCheckDisableOnMax.min.js', 'path' => 'valid->disableOnMax'],
            ],
            'image-select' => [
                ['priority' => 302, 'filename' => 'initCheckDisableOnMax.min.js', 'path' => 'valid->disableOnMax'],
            ],
            'signature' => [
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 301, 'filename' => 'bit-signature-field.min.js'],
            ],
            'advanced-file-up' => [
                ['priority' => 101, 'filename' => 'observeElm.min.js'],
                ['priority' => 202, 'filename' => 'bit-filepond.min.js'],
                ['priority' => 301, 'filename' => 'bit-advanced-file-up-field.min.js'],
                ['priority' => 101, 'filename' => 'advancedFileHandle.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
            ],
            'advanced-datetime' => [
                ['priority' => 101, 'filename' => 'observeElm.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 301, 'filename' => 'bit-advanced-datetime-field.min.js'],
                ['priority' => 301, 'filename' => 'bfDatetimeFldValidation.min.js'],
                ['priority' => 301, 'filename' => 'bfDateFieldsLogicCheck.min.js'],
                ['priority' => 301, 'filename' => 'bfCalculateDateTimeDifference.min.js'],
                ['priority' => 301, 'filename' => 'bfAddOrSubtractDateTime.min.js'],
                ['priority' => 301, 'filename' => 'bfParseDateTime.min.js'],
                ['priority' => 301, 'filename' => 'bfParseSpecialDateFormat.min.js'],
                ['priority' => 301, 'filename' => 'bfSetDateTimeConfigOption.min.js'],
                ['priority' => 301, 'filename' => 'bfFormatDateTime.min.js'],
            ],
            'email-otp' => [
                ['priority' => 201, 'filename' => 'bitsFetchFront.min.js'],
                ['priority' => 201, 'filename' => 'customFieldsReset.min.js'],
                ['priority' => 301, 'filename' => 'bit-email-otp-field.min.js'],
            ],
        ];
    }

    public static function filePondPluginsList()
    {
        $plugins = [
            'allowFileSizeValidation' => ['priority' => 201, 'filename' => 'bit-filepond-plugin-file-validate-size.min.js'],
            'allowFileTypeValidation' => ['priority' => 201, 'filename' => 'bit-filepond-plugin-file-validate-type.min.js'],
            'allowImageCrop'          => ['priority' => 201, 'filename' => 'bit-filepond-plugin-image-crop.min.js'],
            'allowImagePreview'       => ['priority' => 201, 'filename' => 'bit-filepond-plugin-image-preview.min.js'],
            'allowImageResize'        => ['priority' => 201, 'filename' => 'bit-filepond-plugin-image-resize.min.js'],
            'allowImageTransform'     => ['priority' => 201, 'filename' => 'bit-filepond-plugin-image-transform.min.js'],
            'allowImageValidateSize'  => ['priority' => 201, 'filename' => 'bit-filepond-plugin-image-validate-size.min.js'],
            'allowPreview'            => ['priority' => 201, 'filename' => 'bit-filepond-plugin-media-preview.min.js'],
        ];

        return $plugins;
    }
}
