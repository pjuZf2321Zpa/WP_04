<?php

namespace BitApps\BitFormPro\Services\Update;

use WP_Error;
use BitApps\BitForm\Helpers\HttpHelper;
use BitApps\BitForm\Helpers\DateTimeHelper;
use BitApps\BitFormPro\Helpers\LicenseHelper;

final class API
{
    /**
     * Per-request memo of /update responses, keyed by the licence key sent.
     *
     * getUpdatedInfo() and checkLicenseStatus() both query the same endpoint, so a single
     * page load (e.g. the licence screen's "Recheck") would otherwise issue two identical
     * requests. Reusing the first response keeps it to one call per request.
     *
     * @var array
     */
    private static $updateResponseMemo = [];

    public static function getAPiEndPoint()
    {
        return 'https://wp-api.bitapps.pro';
    }

    /**
     * Query the update endpoint, reusing an identical response already fetched this request.
     *
     * @param string|false $licenseKey
     */
    private static function requestUpdateEndpoint($licenseKey)
    {
        $memoKey = is_string($licenseKey) ? $licenseKey : '';
        if (!array_key_exists($memoKey, self::$updateResponseMemo)) {
            self::$updateResponseMemo[$memoKey] = HttpHelper::get(
                self::getAPiEndPoint() . '/update/bitformpro',
                null,
                ['licKey' => $licenseKey, 'domain' => self::siteUrl()],
            );
        }

        $response = self::$updateResponseMemo[$memoKey];

        // Hand back an independent copy. getUpdatedInfo() rewrites ->data (date formatting,
        // sections, downloadLink); sharing the instance would let a second caller re-parse an
        // already-formatted date. serialize() is used so WP_Error keeps its class identity.
        return is_object($response) ? unserialize(serialize($response)) : $response;
    }

    /**
     * Drop the per-request memo so a later call in the same request re-queries.
     */
    public static function flushUpdateResponseMemo()
    {
        self::$updateResponseMemo = [];
    }
    public static function getUpdatedInfo()
    {
        // Depends on Free's HTTP/date helpers. If an out-of-date/absent Free build lacks
        // them, return a WP_Error (cached briefly) instead of a fatal during the update check.
        if (!class_exists(HttpHelper::class) || !class_exists(DateTimeHelper::class)) {
            return new WP_Error('DEP_MISSING', __('Bit Form (free) needs to be updated before Bit Form Pro can check for updates.', 'bitformpro'));
        }
        $licenseKey = self::getKey();
        $pluginInfoResponse = self::requestUpdateEndpoint($licenseKey);
        if (is_wp_error($verifyStatus = self::verifyUpdaterResponse($pluginInfoResponse))) {
            return $verifyStatus;
        }
        $pluginData = $pluginInfoResponse->data;
        $dateTimeHelper = new DateTimeHelper();
        $pluginData->updatedAt = $dateTimeHelper->getFormated($pluginData->updatedAt, 'Y-m-d\TH:i:s.u\Z', DateTimeHelper::wp_timezone(), 'Y-m-d H:i:s', null);
        if (!empty($pluginData->details)) {
            $pluginData->sections['description'] = $pluginData->details;
        } else {
            $pluginData->sections['description'] = '';
        }
        if (!empty($pluginData->changelog)) {
            $pluginData->sections['changelog'] = $pluginData->changelog;
        } else {
            $pluginData->sections['changelog'] = '';
        }
        if ($licenseKey) {
            $pluginData->downloadLink = self::getAPiEndPoint() . '/download/' . $licenseKey;
        } else {
            $pluginData->downloadLink = '';
        }
        return $pluginData;
    }

    public static function checkLicenseStatus()
    {
        if (!class_exists(HttpHelper::class)) {
            return ['status' => 'NETWORK_ERROR', 'message' => __('Bit Form (free) needs to be updated.', 'bitformpro')];
        }
        if (is_multisite() && !is_main_site()) {
            $integrateData = LicenseHelper::getLicenseData();
            if (empty($integrateData) || !is_array($integrateData) || empty($integrateData['key'])) {
                return ['status' => 'not_connected'];
            }
            return ['status' => $integrateData['status'] === 'success' ? 'active' : $integrateData['status']];
        }

        $licenseKey = self::getRawKey();
        if (!$licenseKey) {
            return ['status' => 'not_connected'];
        }

        $response = self::requestUpdateEndpoint($licenseKey);
        $verified  = self::verifyUpdaterResponse($response);

        if (is_wp_error($verified)) {
            $errorCode = $verified->get_error_code();
            if ($errorCode === 'LICENSE_INVALID') {
                self::markLicenseInvalid();
            }
            return [
                'status'  => $errorCode,
                'message' => $verified->get_error_message(),
            ];
        }

        self::restoreLicense();
        return ['status' => 'active'];
    }

    public static function markLicenseInvalid()
    {
        $integrateData = LicenseHelper::getLicenseData();
        if (!empty($integrateData) && is_array($integrateData)) {
            $integrateData['status'] = 'INVALID';
            if (is_multisite() && !is_main_site()) {
                update_blog_option(get_main_site_id(), 'bitformpro_integrate_key_data', $integrateData);
            } else {
                update_option('bitformpro_integrate_key_data', $integrateData, 'yes');
            }
        }
    }

    public static function restoreLicense()
    {
        $integrateData = LicenseHelper::getLicenseData();
        if (!empty($integrateData) && is_array($integrateData) && $integrateData['status'] !== 'success') {
            $integrateData['status'] = 'success';
            if (is_multisite() && !is_main_site()) {
                update_blog_option(get_main_site_id(), 'bitformpro_integrate_key_data', $integrateData);
            } else {
                update_option('bitformpro_integrate_key_data', $integrateData, 'yes');
            }
        }
    }

    private static function siteUrl()
    {
        return rtrim(site_url(), '/');
    }

    private static function getRawKey()
    {
        $integrateData = LicenseHelper::getLicenseData();
        return (!empty($integrateData) && is_array($integrateData) && !empty($integrateData['key']))
            ? $integrateData['key']
            : false;
    }

    public static function activateLicense($licenseKey)
    {
        $data = [];
        $data['licenseKey'] = $licenseKey;
        $data['domain'] = self::siteUrl();
        $data['slug'] = 'bitformpro';
        $activateResponse = HttpHelper::post(self::getAPiEndPoint() . '/activate', json_encode($data), ['content-type' => 'application/json']);
        if (!is_wp_error($activateResponse) && $activateResponse->status === 'success') {
            self::setKeyData($licenseKey, $activateResponse);
            return true;
        }
        return empty($activateResponse->message) ? __('Unknow error occured', 'bitformpro') : $activateResponse->message;
    }

    public static function disconnectLicense()
    {
        $data = null;
        $licenseKey = self::getRawKey();
        if ($licenseKey) {
            $data['licenseKey'] = $licenseKey;
            $data['domain'] = self::siteUrl();
            $data['slug'] = 'bitformpro';
            $deactivateResponse = HttpHelper::post(self::getAPiEndPoint() . '/deactivate', json_encode($data), ['content-type' => 'application/json']);
            if (!is_wp_error($deactivateResponse) && ($deactivateResponse->status === 'success' || $deactivateResponse->code === 'INVALID_LICENSE')) {
                self::removeKeyData();
                return true;
            }
            return empty($deactivateResponse->message) ? __('Unknown error occurred', 'bitformpro') : $deactivateResponse->message;
        }
        return __('License data is missing', 'bitformpro');
    }

    public static function setKeyData($licenseKey, $licData)
    {
        $data['key'] = $licenseKey;
        $data['status'] = $licData->status;
        $data['expireIn'] = $licData->expireIn;
        self::clearTransients();
        return update_option('bitformpro_integrate_key_data', $data, 'yes');
    }

    public static function getKey()
    {
        $integrateData = LicenseHelper::getLicenseData();
        $licenseKey = false;
        if (!empty($integrateData) && is_array($integrateData) && $integrateData['status'] === 'success') {
            $licenseKey = $integrateData['key'];
        }
        return $licenseKey;
    }
    public static function removeKeyData()
    {
        self::clearTransients();
        return delete_option('bitformpro_integrate_key_data');
    }

    private static function clearTransients()
    {
        delete_transient('bitformpro_license_status_check');
        delete_transient('bitformpro_admin_version_info');
        self::clearUpdateCache();
    }

    /**
     * Bust the real update caches so a license connect/renew/disconnect or a manual
     * "Check for updates" immediately re-checks instead of serving a stale (possibly
     * errored) entry. Keys mirror Updater: option md5(sanitize_key('bitformpro') .
     * '_plugin_info') and site-transient 'bitformpro_api_request_' . md5(serialize('bitformpro')).
     */
    public static function clearUpdateCache()
    {
        self::flushUpdateResponseMemo();
        delete_option(md5(sanitize_key('bitformpro') . '_plugin_info'));
        delete_site_transient('bitformpro_api_request_' . md5(serialize('bitformpro')));
        delete_site_transient('update_plugins');
    }

    private static function verifyUpdaterResponse($response)
    {
        if (is_wp_error($response)) {
            return new WP_Error('NETWORK_ERROR', __('Could not reach the license server. Please check your internet connection.', 'bitformpro'));
        }

        if (!empty($response->code) && $response->code === 'INVALID') {
            return new WP_Error('LICENSE_INVALID', $response->message ?? __('License is no longer valid.', 'bitformpro'));
        }

        if (empty($response->data)) {
            return new WP_Error('API_ERROR', $response->message ?? __('Unexpected response from license server.', 'bitformpro'));
        }

        return $response;
    }
}
