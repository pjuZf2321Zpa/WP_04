<?php

namespace BitApps\BitFormPro\Services\Update;

if (!defined('ABSPATH')) {
    exit;
}

use stdClass;
use BitApps\BitFormPro\Helpers\LicenseHelper;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;

/**
 * Helps to update plugin
 */
final class Updater
{
    private $_name;
    private $_slug;
    private $_version;
    private $_label;
    private $_author;
    private $_homepage;
    private $_freeVersion;
    private $_cacheKey;

    /**
     * Constructor of Updater class
     */
    public function __construct()
    {
        $this->_slug = 'bitformpro';
        $this->_name = plugin_basename(BITFORMPRO_PLUGIN_MAIN_FILE);
        $this->_version =  BITFORMPRO_VERSION;
        $this->_label =  'Bit Form Pro';
        $this->_author = '<a href="https://bitapps.pro">Bit Apps</a>';
        $this->_homepage =  "https://bitapps.pro";
        $this->_freeVersion =  BITFORMS_VERSION;
        $this->_cacheKey = md5(sanitize_key('bitformpro') . '_plugin_info');
        $this->registerHooks();
        $this->removeCache();
        add_action('admin_notices', [$this, 'licenseExpirationNotice']);
        add_action('admin_notices', [$this, 'blockedUpdateNotice']);
    }

    private function registerHooks()
    {
        add_action('admin_menu', [$this, 'lincenseMenu']);
        add_filter('pre_set_site_transient_update_plugins', [$this, 'checkUpdate']);
        add_action('delete_site_transient_update_plugins', [$this, 'removeCache']);
        add_filter('plugins_api', [$this, 'shortCircuitPluginsApi'], 10, 3);
        // Let WordPress core render the inline "update available" row (wp_plugin_update_row)
        // from the update_plugins transient in every context (single-site + multisite network admin).
    }

    public function lincenseMenu()
    {
        if (!Capabilities::check('manage_options')) {
            return;
        }
        add_submenu_page(
            'bitform',
            'Bit Form pro license page',
            'License',
            'manage_options',
            'bitform-license',
            function () {
                $integrateStatus = LicenseHelper::getLicenseData();
                if (!empty($integrateStatus) && is_array($integrateStatus) && !empty($integrateStatus['key'])) {
                    include_once BITFORMPRO_PLUGIN_DIR_PATH . '/views/license/status.php';
                } else {
                    include_once BITFORMPRO_PLUGIN_DIR_PATH . '/views/license/add.php';
                }
            },
        );
    }
    public function licenseExpirationNotice()
    {
        if (!Capabilities::check('manage_options')) {
            return;
        }
        global $pagenow;
        if ('plugins.php' !== $pagenow) {
            return;
        }
        // Whole calendar days: the license is valid through the end of `expireIn`,
        // so 0 means "expires today".
        $expireInDays = LicenseHelper::daysUntilExpiry();
        if (null !== $expireInDays && $expireInDays < 25) {
            if ($expireInDays < 0) {
                $notice = __("Bit Form Pro License is expired", "bitformpro");
            } elseif (0 === $expireInDays) {
                $notice = __("Bit Form Pro License expires today", "bitformpro");
            } elseif (1 === $expireInDays) {
                $notice = __("Bit Form Pro License expires tomorrow", "bitformpro");
            } else {
                $notice = sprintf(__("Bit Form Pro License will expire in %s days", "bitformpro"), $expireInDays);
            } ?>
            <div class="notice notice-error is-dismissible">
                <p><?php echo esc_html($notice); ?></p>
            </div>
<?php
        }
    }
    private function checkCacheData($cacheData)
    {
        if (!is_object($cacheData)) {
            $cacheData = new \stdClass();
        }

        if (empty($cacheData->checked)) {
            return $cacheData;
        }

        $versionInfo = $this->getCache();
        if (is_null($versionInfo) || $versionInfo === false) {
            $versionInfo = API::getUpdatedInfo();

            if (is_wp_error($versionInfo)) {
                $versionInfo = new \stdClass();
                $versionInfo->error = true;
                // Cache failures briefly so a transient network/license error does not
                // blackout the update notice for the full 12h success window.
                $this->setCache($versionInfo, 30 * MINUTE_IN_SECONDS);
            } else {
                $this->setCache($versionInfo);
            }
        }
        if (!empty($versionInfo->error)) {
            return $cacheData;
        }

        // An update may exist but be gated by an environment requirement (WP/Free too old).
        // Stage a real update only when it exists AND is not gated; otherwise register the
        // plugin as "no update" so the row does not vanish. The gate reason itself is NOT
        // cached here — blockedUpdateNotice() recomputes it live from the current Free/WP
        // versions so it disappears the moment the user updates Free (see getBlockedReason()).
        if (version_compare($this->_version, $versionInfo->version, '<') && '' === $this->getBlockedReason($versionInfo)) {
            $cacheData->response[$this->_name] = $this->formatApiData($versionInfo);
        } else {
            $cacheData->no_update[$this->_name] = $this->noUpdateInfo();
        }

        $cacheData->last_checked = current_time('timestamp');
        $cacheData->checked[$this->_name] = $this->_version;
        return $cacheData;
    }

    /**
     * Compute the "update gated" reason from CURRENT environment versions.
     * Returns '' when no update exists or nothing gates it. Reads live so the notice
     * clears immediately after the user updates Free/WordPress (no stale transient).
     *
     * @param object|null $versionInfo cached remote info; falls back to getCache()
     */
    private function getBlockedReason($versionInfo = null)
    {
        if (null === $versionInfo) {
            $versionInfo = $this->getCache();
        }
        return self::updateGateReason($versionInfo);
    }

    /**
     * Public, instance-free variant so other admin screens (e.g. the license page) can
     * surface the same "update gated" reason. Reads the cached remote info when none is
     * passed and computes against the CURRENT Pro/Free/WP versions (no stale state).
     * Returns '' when no update exists or nothing gates it.
     *
     * @param object|null $versionInfo cached remote info; loaded from cache when null
     */
    public static function updateGateReason($versionInfo = null)
    {
        if (null === $versionInfo) {
            $cache = get_option(md5(sanitize_key('bitformpro') . '_plugin_info'));
            if (empty($cache['timeout']) || current_time('timestamp') > $cache['timeout']) {
                return '';
            }
            $versionInfo = $cache['value'];
        }
        if (empty($versionInfo) || !is_object($versionInfo) || !empty($versionInfo->error) || empty($versionInfo->version)) {
            return '';
        }

        $proVersion  = defined('BITFORMPRO_VERSION') ? BITFORMPRO_VERSION : '';
        $freeVersion = defined('BITFORMS_VERSION') ? BITFORMS_VERSION : '';

        // Only meaningful if a newer version actually exists.
        if (empty($proVersion) || !version_compare($proVersion, $versionInfo->version, '<')) {
            return '';
        }

        // include an unmodified $wp_version
        include ABSPATH . WPINC . '/version.php';

        if (!empty($versionInfo->requireWP) && version_compare($wp_version, $versionInfo->requireWP, '<')) {
            return sprintf(
                /* translators: 1: Pro version, 2: required WordPress version */
                __('Bit Form Pro %1$s is available but requires WordPress %2$s or higher. Please update WordPress to receive it.', 'bitformpro'),
                $versionInfo->version,
                $versionInfo->requireWP,
            );
        }
        if (!empty($freeVersion) && !empty($versionInfo->requiresFree)
            && version_compare($freeVersion, $versionInfo->requiresFree, '<')) {
            return sprintf(
                /* translators: 1: Pro version, 2: required Bit Form (free) version */
                __('Bit Form Pro %1$s is available but requires Bit Form %2$s or higher. Please update Bit Form first to receive it.', 'bitformpro'),
                $versionInfo->version,
                $versionInfo->requiresFree,
            );
        }
        return '';
    }

    /**
     * Return the cached remote version-info for an installable (not gated) update, or null.
     * Lets admin screens (license page) render an "update available" card from our own 12h
     * cache without a network call. Object carries version, updatedAt, tested, sections, etc.
     *
     * @return object|null
     */
    public static function getAvailableUpdate()
    {
        $cache = get_option(md5(sanitize_key('bitformpro') . '_plugin_info'));
        if (empty($cache['timeout']) || current_time('timestamp') > $cache['timeout']) {
            return null;
        }
        $info = $cache['value'];
        if (empty($info) || !is_object($info) || !empty($info->error) || empty($info->version)) {
            return null;
        }
        if (!defined('BITFORMPRO_VERSION') || !version_compare(BITFORMPRO_VERSION, $info->version, '<')) {
            return null;
        }
        if ('' !== self::updateGateReason($info)) {
            return null;
        }
        return $info;
    }

    /**
     * Whether the update cache has been populated at least once (valid, non-error).
     * Used to distinguish "up to date" from "never checked" on the license screen.
     */
    public static function hasUpdateCache()
    {
        $cache = get_option(md5(sanitize_key('bitformpro') . '_plugin_info'));
        if (empty($cache['timeout']) || current_time('timestamp') > $cache['timeout']) {
            return false;
        }
        $info = $cache['value'];
        return !empty($info) && is_object($info) && empty($info->error) && !empty($info->version);
    }

    private function noUpdateInfo()
    {
        return (object) [
            'id'            => $this->_name,
            'slug'          => $this->_slug,
            'plugin'        => $this->_name,
            'new_version'   => $this->_version,
            'url'           => '',
            'package'       => '',
            'banners'       => [
                "high" => "https://ps.w.org/bit-form/assets/banner-772x250.png?rev=2376427",
            ],
            'banners_rtl'   => [],
            'tested'        => '',
            'requires_php'  => '',
            'compatibility' => new stdClass(),
        ];
    }

    public function blockedUpdateNotice()
    {
        global $pagenow;
        if ('plugins.php' !== $pagenow || !Capabilities::check('update_plugins')) {
            return;
        }
        $reason = $this->getBlockedReason();
        if ('' === $reason) {
            return;
        }
        printf('<div class="notice notice-warning"><p>%s</p></div>', esc_html($reason));
    }

    public function checkUpdate($cacheData)
    {
        if (!is_object($cacheData)) {
            $cacheData = new \stdClass();
        }
        return $this->checkCacheData($cacheData);
    }

    public function shortCircuitPluginsApi($_data, $_action = '', $_args = null)
    {
        if ('plugin_information' !== $_action) {
            return $_data;
        };
        if (!isset($_args->slug) || ($_args->slug !== $this->_slug)) {
            return $_data;
        }

        $cacheKey = $this->_slug . '_api_request_' . md5(serialize($this->_slug));

        $apiResponseCache = get_site_transient($cacheKey);
        if (empty($apiResponseCache)) {
            $apiResponse = API::getUpdatedInfo();
            $apiResponseCache = $this->formatApiData($apiResponse);
            set_site_transient($cacheKey, $apiResponseCache, DAY_IN_SECONDS);
        }
        return $apiResponseCache;
    }

    private function getCache()
    {
        $cacheData = get_option($this->_cacheKey);

        if (empty($cacheData['timeout']) || current_time('timestamp') > $cacheData['timeout']) {
            return false;
        }

        return $cacheData['value'];
    }

    private function setCache($cacheValue, $ttl = null)
    {
        if (null === $ttl) {
            $ttl = 12 * HOUR_IN_SECONDS;
        }
        $data = [
            'timeout' => current_time('timestamp') + $ttl,
            'value'   => $cacheValue,
        ];

        update_option($this->_cacheKey, $data, 'yes');
    }

    public function removeCache()
    {
        global $pagenow;
        if ('update-core.php' === $pagenow && isset($_GET['force-check'])) {
            delete_option($this->_cacheKey);
            delete_site_transient($this->_slug . '_api_request_' . md5(serialize($this->_slug)));
        }
    }

    private function formatApiData($apiResponse)
    {
        $formattedData = new \stdClass();
        $formattedData->name = $this->_label;
        $formattedData->slug = $this->_slug;
        $formattedData->plugin = $this->_name;
        $formattedData->id = $this->_name;
        $formattedData->author = $this->_author;
        $formattedData->homepage = $this->_homepage;
        if (is_wp_error($apiResponse)) {
            $formattedData->requires = '';
            $formattedData->tested = '';
            $formattedData->new_version = $this->_version;
            $formattedData->last_updated = '';
            $formattedData->download_link = '';
            $formattedData->banners = [
                "high" => "https://ps.w.org/bit-form/assets/banner-772x250.png?rev=2376427",
            ];
            $formattedData->sections = null;
            return $formattedData;
        }
        $formattedData->requires = $apiResponse->requireWP;
        $formattedData->tested = $apiResponse->tested;

        $formattedData->new_version = $apiResponse->version;
        $formattedData->last_updated = $apiResponse->updatedAt;
        $formattedData->download_link = !empty($apiResponse->downloadLink) ? $apiResponse->downloadLink . "/" . $this->_slug . ".zip" : '';
        $formattedData->package = !empty($apiResponse->downloadLink) ? $apiResponse->downloadLink . "/" . $this->_slug . ".zip" : '';
        $formattedData->banners = [
            "high" => "https://ps.w.org/bit-form/assets/banner-772x250.png?rev=2376427",
        ];
        $formattedData->sections = $apiResponse->sections;
        return $formattedData;
    }
}
