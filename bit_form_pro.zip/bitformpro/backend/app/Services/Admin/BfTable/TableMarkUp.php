<?php

namespace BitApps\BitFormPro\Services\Admin\BfTable;

use BitApps\BitForm\Services\Admin\AdminFormHandler;
use BitApps\BitForm\Services\Form\FormManager;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Helpers\EscapingHelper;
use BitApps\BitForm\Helpers\FileHandler;
use BitApps\BitForm\Helpers\FrontendHelpers;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Utils\Capabilities;

final class TableMarkUp
{
    private $_table;

    private $_tableId;
    private $_tableConfig;
    private $_formID;

    private $_actionsBtn;
    private $_accessControl;

    private $_fromPermission;

    private $_current_user_id;
    private $_current_user_roles;

    private $_uploadUrl = BITFORMS_UPLOAD_BASE_URL . '/' . 'uploads';

    // private $
    public function __construct($tableId)
    {
        $this->_tableId = $tableId;
        $this->_table = Table::gatATable(['id' => $tableId], null);
        $this->_tableConfig = JSON::decode($this->_table->table_config);
        $this->_formID = $this->_table->form_id;
        $this->_accessControl = JSON::decode($this->_table->access_control);
        $this->getCurrentUserInfo();
    }

    public function getFormId()
    {
        return $this->_formID;
    }

    public function setFormPermission($formPermission)
    {
        $this->_fromPermission = $formPermission;
    }

    private function getFormFields()
    {
        $adminFormHandler = new AdminFormHandler();
        $post = new \stdClass();
        $post = (object) [
            'id' => $this->_formID,
        ];
        $getForm = $adminFormHandler->getAForm('', $post);
        $formContainer = $getForm['form_content'];

        return $formContainer['fields'];
    }

    private function getCurrentUserInfo()
    {
        $current_user_id = get_current_user_id();
        $current_user = get_userdata($current_user_id);
        $this->_current_user_roles = isset($current_user->roles) ? $current_user->roles : [];
        $this->_current_user_id = $current_user_id;
    }
    public function tableViewer()
    {
        // if (!$this->_accessControl->allowViewToPublic && !$this->_current_user_id) {
        //     $messageMarkup = sprintf(__('Yor cannot access #%s no. Table View', 'bitformpro'), $this->_tableId);
        //     $messageMarkup = apply_filters('bitform_filter_data_view_error_message', $messageMarkup, 'allowViewToPublic');
        //     return $messageMarkup;
        // }

        // if ($this->_current_user_id && (current_user_can('prevent_bitform_data_view') || !(current_user_can('read') || current_user_can('bitform_data_view')))) {
        //     $messageMarkup = sprintf(__('You do not have permission to access #%s no. Table View', 'bitformpro'), $this->_tableId);
        //     $messageMarkup = apply_filters('bitform_filter_data_view_error_message', $messageMarkup, 'checkViewCapability');
        //     return $messageMarkup;
        // }

        $tableConfig = $this->_tableConfig;
        $formID = $this->_formID;
        $tableId = $this->_tableId;

        $captionHTML = '';
        $theadHTML = '';
        $theadActionsHTML = '';
        $searchBarHTML = '';
        $paginationHTML = '';

        $columnsMap = $tableConfig->columnsMap;
        $this->_actionsBtn = $tableConfig->actionsBtn;
        $head = $this->_actionsBtn->head;

        $obj = new \stdClass();
        $obj->id = $formID;

        $entryRow = '';
        $canViewOthers = FrontendHelpers::is_current_user_can_access($formID, 'entryViewAccess', 'othersEntries');
        if (!$canViewOthers) {
            $obj->queryCondition = [
                'form_id' => $formID,
                'user_id' => get_current_user_id(),
            ];
        }
        $adminFormHandler = new AdminFormHandler();
        $getEntries = $adminFormHandler->getFormEntry('', $obj);
        if (is_wp_error($getEntries)) {
            return $getEntries->get_error_message();
        }
        $entries = $getEntries['entries'];
        $totalEntries = $getEntries['count'];

        // $search = 'K';
        // $filterArray = array_filter($entries, function ($entry) use ($search) {
        //   foreach ((array) $entry as $key => $value) {
        //     // partially match the search string regex, case insensitive search, return the row
        //     if (preg_match("/{$search}/i", $value)) {
        //       return $entry;
        //     }
        //   }
        // });


        $this->rowMarkup($entries, $columnsMap, $entryRow, $formID);

        $this->captionMarkup($captionHTML);

        $this->searchBarMarkup($searchBarHTML);

        $this->pagination($totalEntries, $paginationHTML);

        if (
            isset($head->show)
            && $head->show
            && ($this->isUserAllowedToEdit() || $this->isUserAllowedToView())
        ) {
            $theadActionsHTML = '<th width="' . esc_attr($head->w) . '">' . "\n"
                . '  ' . $head->thead . "\n"
                . '</th>';
        }

        foreach ($columnsMap as $column) {
            $theadHTML .= '<th width="' . esc_attr($column->w) . '">' . "\n"
                . '  ' . $column->thead . "\n"
                . '</th>';
        }

        $tableHTML = '<div class="bf' . (int) $formID . '-' . (int) $tableId . '-tbl-wrp bf-tbl-wrp">' . "\n"
            . '  ' . $captionHTML . "\n"
            . '  ' . $searchBarHTML . "\n"
            . '  <div class="bf' . (int) $formID . '-' . (int) $tableId . '-tbl-cntnr">' . "\n"
            . '    <table class="bf' . (int) $formID . '-' . (int) $tableId . '-tbl bf-tbl">' . "\n"
            . '      <thead class="bf' . (int) $formID . '-' . (int) $tableId . '-thead bf-thead">' . "\n"
            . '        <tr>' . "\n"
            . '          ' . $theadHTML . "\n"
            . '          ' . $theadActionsHTML . "\n"
            . '        </tr>' . "\n"
            . '      </thead>' . "\n"
            . '      <tbody class="bf' . (int) $formID . '-' . (int) $tableId . '-tbody bf-tbody">' . "\n"
            . '        ' . $entryRow . "\n"
            . '      </tbody>' . "\n"
            . '    </table>' . "\n"
            . '  </div>' . "\n"
            . '  ' . $paginationHTML . "\n"
            . '</div>';

        return $tableHTML;
    }

    public function paginatedRows($offset = 0, $pageSize = 10, $search = '')
    {
        $formID = $this->_formID;
        $tableConfig = $this->_tableConfig;
        $columnsMap = $tableConfig->columnsMap;
        $entryRow = '';
        $entryData = [];

        $obj = new \stdClass();
        $obj->id = $formID;
        $obj->offset = absint($offset);
        $obj->pageSize = absint($pageSize);
        $obj->globalFilter = sanitize_text_field($search);

        $canViewOthers = FrontendHelpers::is_current_user_can_access($formID, 'entryViewAccess', 'othersEntries');
        if (!$canViewOthers) {
            $obj->queryCondition = [
                'form_id' => $formID,
                'user_id' => get_current_user_id(),
            ];
        }

        $adminFormHandler = new AdminFormHandler();
        $getEntries = $adminFormHandler->getFormEntry('', $obj);

        if (is_wp_error($getEntries)) {
            return $getEntries;
        }

        $entries = $getEntries['entries'];
        $totalEntries = $getEntries['count'];

        $this->_actionsBtn = $tableConfig->actionsBtn;
        $this->rowMarkup($entries, $columnsMap, $entryRow, $formID);

        return [
            'rows' => $entryRow,
            'totalRecords' => (int) $totalEntries,
            'totalPages' => $pageSize ? (int) ceil($totalEntries / $pageSize) : 0,
        ];
    }

    private function getResolvedFormPermission()
    {
        if (!empty($this->_fromPermission)) {
            return $this->_fromPermission;
        }

        $formManager = FormManager::getInstance($this->_formID);
        $this->_fromPermission = $formManager->getFormPermission();

        return $this->_fromPermission;
    }

    private function hasCurrentUserRoleAccess($roles)
    {
        if (!$this->_current_user_id || empty($roles) || !is_string($roles)) {
            return false;
        }

        $allowedRoles = array_filter(array_map('trim', explode(',', $roles)));
        if (empty($allowedRoles)) {
            return false;
        }

        if (in_array('all_logged_in_users', $allowedRoles, true)) {
            return true;
        }

        return !empty(array_intersect($this->_current_user_roles, $allowedRoles));
    }

    private function isEntryOwner($entryUserId)
    {
        return (string) $this->_current_user_id === (string) $entryUserId;
    }

    private function hasEntryAccessByRole($action, $entryUserId = null)
    {

        if (in_array('administrator', $this->_current_user_roles, true)) {
            return true;
        }

        if ($this->_current_user_id && Capabilities::check($action === 'entryViewAccess' ? 'prevent_bitform_data_view' : 'prevent_bitform_data_edit')) {
            return false;
        }

        if (Capabilities::check($action === 'entryViewAccess' ? 'bitform_data_view' : 'bitform_data_edit')) {
            return true;
        }

        $formPermission = $this->getResolvedFormPermission();
        $accessPermission = isset($formPermission->{$action}) ? $formPermission->{$action} : null;

        if (empty($accessPermission)) {
            return false;
        }

        if ('entryViewAccess' === $action && (!isset($accessPermission->preventPublicAccess) || !$accessPermission->preventPublicAccess)) {
            return true;
        }

        if ('entryEditAccess' === $action && !(isset($accessPermission->allowEntriesEdit) && $accessPermission->allowEntriesEdit)) {
            return false;
        }

        $hasOwnEntryAccess = isset($accessPermission->ownEntries)
            && $this->hasCurrentUserRoleAccess($accessPermission->ownEntries);
        $hasOthersEntryAccess = isset($accessPermission->othersEntries)
            && $this->hasCurrentUserRoleAccess($accessPermission->othersEntries);

        if (null === $entryUserId) {
            return $hasOwnEntryAccess || $hasOthersEntryAccess;
        }

        return $this->isEntryOwner($entryUserId) ? $hasOwnEntryAccess : $hasOthersEntryAccess;
    }

    private function isUserAllowedToEdit($entryUserId = null)
    {
        return $this->hasEntryAccessByRole('entryEditAccess', $entryUserId);
    }

    private function isUserAllowedToView($entryUserId = null)
    {
        return $this->hasEntryAccessByRole('entryViewAccess', $entryUserId);
    }

    private function actionHadrShowOrNotForAll()
    {
        $accessControl = $this->_accessControl;
        if (
            $accessControl->accessFor === 'all'
            && in_array($this->_current_user_roles[0], $accessControl->all->entryEdit)
        ) {
            return true;
        }
        return false;
    }

    private function actionHadrShowOrNotForUserIds()
    {
        $accessControl = $this->_accessControl;
        if (
            $accessControl->accessFor === 'user'
            && in_array($this->_current_user_id, $accessControl->user->ids)
        ) {
            return true;
        }
        return false;
    }

    private function getCleanedFieldKey($key)
    {
        return preg_replace('/\${([a-zA-Z0-9]+-\d+)}/', '$1', $key);
    }

    public function rowMarkup($entries, $columnsMap, &$entryRow, $formID)
    {
        $formContent = FormManager::getInstance($this->_formID)->getFormContent();

        foreach ($entries as $entry) {

            $entryRow .= "<tr>";

            $resourceUrl = $this->createResourceUrl($entry->entry_id);
            foreach ($columnsMap as $column) {

                $v = FieldValueHandler::replaceFieldWithValue($column->fk, (array) $entry, $formID);
                $v = FieldValueHandler::changeImagePathInHTMLString($v, $resourceUrl);
                $v = FieldValueHandler::changeHrefPathInHTMLString($v, $resourceUrl);
                $v = EscapingHelper::ksesFormOutput($v, $formContent);

                $td = "<td>";
                $td .= $v;

                $td .= "</td>";
                $entryRow .= $td;
            }
            $entryUserId = isset($entry->__user_id) ? $entry->__user_id : null;
            $entryRow .= $this->actionButtonMarkup($entry->entry_id, $entryUserId);
            $entryRow .= "</tr>";
        }
    }

    public function actionButtonMarkup($entryId, $entryUserId = null)
    {
        $actionsBtn = $this->_actionsBtn;
        $canEditEntry = $this->isUserAllowedToEdit($entryUserId);
        $canViewEntry = $this->isUserAllowedToView($entryUserId);

        if (!isset($actionsBtn->head->show) || !$actionsBtn->head->show) {
            return '';
        }

        $html = '';
        if ($canEditEntry || $canViewEntry) {
            $html .= "<td><div class='bf{$this->_formID}-{$this->_tableId}-tbl-action-btns bf-tbl-action-btns'>";
            $editButton = $actionsBtn->editButton;
            $viewButton = $actionsBtn->viewButton;

            if (
                $editButton->show
                && $canEditEntry
            ) {
                $html .= ' <a class="bf' . (int) $this->_formID . '-' . (int) $this->_tableId . '-tbl-edit-btn bf-tbl-edit-btn" href="' . esc_url($editButton->slug . '?bf_entry_id=' . $entryId) . '">'
                    . esc_html($actionsBtn->editButton->btnTxt)
                    . '</a>';
            }

            if (
                $viewButton->show
                && $canViewEntry
            ) {
                $html .= ' <a class="bf' . (int) $this->_formID . '-' . (int) $this->_tableId . '-tbl-view-btn bf-tbl-view-btn" href="' . esc_url($viewButton->slug . '?bf_entry_id=' . $entryId) . '">'
                    . esc_html($actionsBtn->viewButton->btnTxt)
                    . '</a>';
            }
            //       if (
            //         $editButton->show
            //         && $accessControl->accessFor === 'all' &&
            //         in_array($this->_current_user_roles[0], $accessControl->all->entryEdit)
            //       ) {
            //         $html .= <<<EDIT_BTN
            //         <a class="bf{$this->_formID}-{$this->_tableId}-tbl-edit-btn bf-tbl-edit-btn" href="{$editButton->slug}?bf_entry_id={$entryId}">
            //           {$actionsBtn->editButton->btnTxt}
            //         </a>
            // EDIT_BTN;
            //       }
            //             if (
            //                 $viewButton->show
            //                 && $accessControl->accessFor === 'all' &&
            //                 in_array($this->_current_user_roles[0], $accessControl->all->singleEntryDetailsView)
            //             ) {
            //                 $html .= <<<VIEW_BTN
            //         <a class="bf{$this->_formID}-{$this->_tableId}-tbl-view-btn bf-tbl-view-btn" href="{$viewButton->slug}?bf_entry_id={$entryId}">
            //           {$actionsBtn->viewButton->btnTxt}
            //         </a>
            // VIEW_BTN;
            //             }
            $html .= '</div></td>';
        }
        return $html ?: '<td></td>';
    }

    private function captionMarkup(&$captionHTML)
    {
        $tableConfig = $this->_tableConfig;
        if (isset($tableConfig->caption)) {
            $caption = $tableConfig->caption;
            $captionHTML = '<div class="bf' . (int) $this->_formID . '-' . (int) $this->_tableId . '-tbl-caption bt-tbl-caption">' . "\n"
                . '  ' . $caption . "\n"
                . '</div>';
        }
    }

    private function searchBarMarkup(&$searchBarHTML)
    {
        $formId = (int) $this->_formID;
        $tableId = (int) $this->_tableId;
        $searchBarHTML = '<div class="bf' . $formId . '-' . $tableId . '-tbl-top-bar bf-tbl-top-bar">' . "\n"
            . '  <label aria-label="search-bar" htmlFor="search-box bf-tbl-serc-lbl">' . "\n"
            . '    Search' . "\n"
            . '    <input id="search-box" class="bf' . $formId . '-' . $tableId . '-serc-bx -bf-tbl-serc-bx" type="text" name="search" />' . "\n"
            . '  </label>' . "\n"
            . '</div>';
    }

    private function pagination($totalEntries, &$paginationHTML)
    {
        $formID = (int) $this->_formID;
        $tableId = (int) $this->_tableId;
        $totalEsc = esc_html((string) $totalEntries);

        $paginationHTML = '<div class="bf' . $formID . '-' . $tableId . '-tbl-footer bf-tbl-footer">' . "\n"
            . '  <span>Total Response ' . $totalEsc . '</span>' . "\n"
            . '  <div class="gn">' . "\n"
            . '    <button class="bf' . $formID . '-' . $tableId . '-pgn-btn bf-tbl-pgn-btn" data-page="start" type="button">&#171;</button>' . "\n"
            . '    <button class="bf' . $formID . '-' . $tableId . '-pgn-btn bf-tbl-pgn-btn" data-page="previous" type="button">&#8249;</button>' . "\n"
            . '    <button class="bf' . $formID . '-' . $tableId . '-pgn-btn bf-tbl-pgn-btn" data-page="next" type="button">&#8250;</button>' . "\n"
            . '    <button class="bf' . $formID . '-' . $tableId . '-pgn-btn bf-tbl-pgn-btn" data-page="end" type="button">&#187;</button>' . "\n"
            . '    <span>Page <span class="bf' . $formID . '-' . $tableId . '-curr-page bf-tbl-curr-page">1</span> of '
            . '<span class="bf' . $formID . '-' . $tableId . '-total-page bf-tbl-total-page">10</span></span>' . "\n"
            . '    <select class="bf' . $formID . '-' . $tableId . '-tbl-pgn-slt bf-tbl-pgn-slt" name="limit" id="limit">' . "\n"
            . '      <option value="10">10</option>' . "\n"
            . '      <option value="20">20</option>' . "\n"
            . '      <option value="30">30</option>' . "\n"
            . '      <option value="40">40</option>' . "\n"
            . '      <option value="50">50</option>' . "\n"
            . '    </select>' . "\n"
            . '  </div>' . "\n"
            . '</div>';
    }

    private function createResourceUrl($entry_id)
    {
        $resourceUrl = '';
        if (method_exists(FileHandler::class, 'getEntriesFileUploadURL')) {
            $resourceUrl = FileHandler::getEntriesFileUploadURL($this->_formID, $entry_id) . '/';
        } else {
            $resourceUrl = $this->_uploadUrl . '/' . $this->_formID . '/' . $entry_id . '/';
        }
        return $resourceUrl;
    }
}
