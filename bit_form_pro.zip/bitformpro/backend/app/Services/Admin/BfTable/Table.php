<?php

namespace BitApps\BitFormPro\Services\Admin\BfTable;

use BitApps\BitForm\Helpers\Log;
use BitApps\BitFormPro\Model\FrontendViewModel;
use BitApps\BitForm\Services\Admin\Helpers;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitForm\Helpers\FrontendHelpers;
use WP_Error;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

final class Table
{
    private $_formId;

    private $_tableId;

    private static $table;

    private $tableModel;

    public function __construct($_tableId, $_formId = null)
    {
        $this->_formId = $_formId;
        $this->_tableId = $_tableId;
        $this->tableModel = new FrontendViewModel();
    }

    private static function getTable($condition = [])
    {
        $tableModel = new FrontendViewModel();
        $result = $tableModel->get(
            [
                'id',
                'form_id',
                'table_name',
                'table_config',
                'table_styles',
                'single_entry_view_config',
                'access_control',
                'created_at',
                'updated_at',
            ],
            $condition,
        );

        return $result;
    }
    /**
     * Save a new view and its stylesheet.
     *
     * @param object $view the view builder's document: id, form_id, table_name, table_config,
     *                     table_styles, single_entry_view_config, access_control — as decoded
     *                     from JSON, so an empty `{}` is re-encoded as one
     *
     * @return array{table: mixed, messages: string}
     */
    public static function createView($view)
    {
        $user_details = IpTool::getUserDetail();
        $data = [
            'id' => $view->id,
            'form_id' => $view->form_id,
            'table_name' => $view->table_name,
            'table_config' => JSON::encode($view->table_config),
            'table_styles' => JSON::encode($view->table_styles),
            'single_entry_view_config' => JSON::encode($view->single_entry_view_config) ?? '',
            'access_control' => JSON::encode($view->access_control) ?? '',
            'created_at' => $user_details['time'],
            'updated_at' => $user_details['time'],
        ];

        $tableModel = new FrontendViewModel();
        $savedTableId = $tableModel->insert($data);

        self::saveScript($savedTableId, self::styleGenerator($view->table_styles->style, true));

        return [
            'table' => self::gatATable(['id' => $savedTableId], null),
            'messages' => __('Table Saved successfully', 'bitformpro'),
        ];
    }
    /**
     * Save a view over the stored one, and regenerate its stylesheet.
     *
     * @param object $view the view builder's document: id, form_id, table_name, table_config,
     *                     table_styles, single_entry_view_config, access_control — as decoded
     *                     from JSON, so an empty `{}` is re-encoded as one
     *
     * @return array{table: mixed, message: string}|WP_Error
     */
    public static function updateView($view)
    {
        $tableId = $view->id;
        $user_details = IpTool::getUserDetail();
        $data = [
            'form_id' => $view->form_id,
            'table_name' => $view->table_name,
            'table_config' => JSON::encode($view->table_config),
            'table_styles' => JSON::encode($view->table_styles),
            'single_entry_view_config' => JSON::encode($view->single_entry_view_config) ?? '',
            'access_control' => JSON::encode($view->access_control) ?? '',
            'updated_at' => $user_details['time'],
        ];
        $tableModel = new FrontendViewModel();
        $updated = $tableModel->update($data, ['id' => $tableId]);

        self::saveScript($tableId, self::styleGenerator($view->table_styles->style, true));

        if (!$updated) {
            return new WP_Error('update_failed', __('Table update failed.', 'bitformpro'));
        }

        return [
            'table' => self::gatATable(['id' => $tableId], null),
            'message' => __('Table Update successfully', 'bitformpro'),
        ];
    }

    private static function saveScript($tableId, $contain)
    {
        $path = 'form-styles';
        $fileName = 'bitform-view-' . $tableId . '.css';
        Helpers::saveFile($path, $fileName, $contain, 'w');
    }

    private static function deleteScript($tableId)
    {
        $cssPath = BITFORMS_CONTENT_DIR . DIRECTORY_SEPARATOR . 'form-styles' . DIRECTORY_SEPARATOR;
        $fileName = 'bitform-view-' . $tableId . '.css';

        $link = $cssPath . $fileName;

        if (file_exists($link)) {
            unlink($link);
        }
    }

    public static function gatATable($request, $post)
    {
        if (!empty($request['id'])) {
            $tableID = wp_unslash($request['id']);
        } else {
            $tableID = wp_unslash($post->id);
        }

        if (is_null($tableID)) {
            return new WP_Error('empty_table', __('Table id is empty.', 'bitformpro'));
        }

        $result = self::getTable(['id' => $tableID])[0];

        if (is_wp_error($result)) {
            return new WP_Error('result_empty', __('Table not found.', 'bitformpro'));
        }

        return $result;
    }

    /**
     * @param int|null $formId
     *
     * @return array|WP_Error the form's views
     */
    public static function getAllViews($formId)
    {
        if (!filter_var($formId, FILTER_VALIDATE_INT)) {
            return new WP_Error('invalid_form', __('Form id is invalid.', 'bitformpro'));
        }

        $allTable = self::getTable(['form_id' => $formId]);
        if (is_wp_error($allTable)) {
            return new WP_Error('no_views', __('No Data View found', 'bitformpro'));
        }

        return $allTable;
    }

    /**
     * Get last inserted id
     *
     * @return int
     */
    public static function lastId(): int
    {
        $tableModel = new FrontendViewModel();
        return $tableModel->lastId();
    }

    /**
     * Delete one view and its stylesheet.
     *
     * @param int|null $tableId
     *
     * @return true|WP_Error
     */
    public static function deleteTable($tableId)
    {
        if (is_null($tableId)) {
            return new WP_Error('empty_form', __('table id is empty.', 'bitformpro'));
        }
        $tableModel = new FrontendViewModel();
        $delete_status = $tableModel->delete(['id' => $tableId]);
        if (is_wp_error($delete_status)) {
            return $delete_status;
        }
        self::deleteScript($tableId);

        return true;
    }

    /**
     * Delete several views.
     *
     * @param mixed $tableIds view ids
     *
     * @return true|WP_Error
     */
    public static function deleteBulkTable($tableIds)
    {
        $tableModel = new FrontendViewModel();
        $delete_status = $tableModel->bulkDelete(['id' => $tableIds]);

        return is_wp_error($delete_status) ? $delete_status : true;
    }

    // table find
    public static function find($tableId)
    {

        $tableModel = new FrontendViewModel();

        $table = $tableModel->get(
            ['id'],
            [
                'id' => $tableId,
            ],
        );
        if (!is_wp_error($table)) {
            return true;
        }
        return false;
    }

    private static function styleGenerator($styleObj, $important = false)
    {
        $important = $important ? '!important' : '';
        $classes = array_keys((array) $styleObj);
        $css = '';
        foreach ($classes as $class) {
            $css .= $class;
            $props = (array) $styleObj->{$class};
            $propsKeys = array_keys($props);
            $styleObject = '{';
            foreach ($propsKeys as $property) {
                $value = $props[$property];
                if (empty($value)) {
                    continue;
                }
                $styleObject .= "{$property}:{$value}{$important};";
            }
            $styleObject = rtrim($styleObject, ';');
            $styleObject .= '}';
            $css .= $styleObject;
        }

        return $css;
    }

    public static function getEntriesByLimit()
    {
        $inputJSON = file_get_contents('php://input');
        $requestsParams = JSON::decode($inputJSON);

        // GlobalHelper::requirePostMethod();

        // try {
        //     $requestsParams = GlobalHelper::formatRequestData();
        // } catch (\InvalidArgumentException $e) {
        //     wp_send_json_error($e->getMessage(), 400);
        // }
        $formId = isset($requestsParams->formId) ? absint($requestsParams->formId) : 0;
        $tableId = isset($requestsParams->tableId) ? absint($requestsParams->tableId) : 0;
        $offset = isset($requestsParams->offset) ? absint($requestsParams->offset) : 0;
        $pageSize = isset($requestsParams->pageSize) ? absint($requestsParams->pageSize) : 10;
        $search = isset($requestsParams->search) ? sanitize_text_field($requestsParams->search) : '';
        $pageSize = max(1, min($pageSize, 100));

        if (!$formId || !$tableId) {
            wp_send_json_error(__('Form ID and Table ID are required.', 'bitformpro'), 400);
        }

        $tableMarkup = new TableMarkUp($tableId);
        $viewFormId = absint($tableMarkup->getFormId());

        if ($formId !== $viewFormId) {
            wp_send_json_error(__('Form ID does not match this table view.', 'bitformpro'), 400);
        }

        if (!FrontendHelpers::is_current_user_can_access($viewFormId, 'entryViewAccess')) {
            wp_send_json_error(__('You do not have permission to access this table view.', 'bitformpro'), 403);
        }

        $rowsData = $tableMarkup->paginatedRows($offset, $pageSize, $search);

        if (is_wp_error($rowsData)) {
            wp_send_json_error($rowsData->get_error_message(), 400);
        }

        wp_send_json_success($rowsData, 200);
    }

    public static function deleteTableByFormId($formId)
    {
        $tableModel = new FrontendViewModel();

        $getTable = $tableModel->get([
            'id',
        ], [
            'form_id' => $formId,
        ]);

        $delete_status = $tableModel->delete(
            [
                'form_id' => $formId,
            ],
        );

        // A form without views reads back a WP_Error, not an empty list.
        if (!is_wp_error($delete_status) && \is_array($getTable)) {
            foreach ($getTable as $table) {
                self::deleteScript($table->id);
            }
        }
        return $delete_status;
    }

    /**
     * Delete every view of the given forms; Free calls it when forms are bulk-deleted.
     *
     * @param array $formIDs
     *
     * @return mixed the last form's delete status
     */
    public static function deleteTableByBulkFormId(array $formIDs)
    {
        $delete_status = true;
        foreach ($formIDs as $formId) {
            // Every form: this once returned after the first, leaving the rest's views behind.
            $delete_status = self::deleteTableByFormId($formId);
        }

        return $delete_status;
    }
}
