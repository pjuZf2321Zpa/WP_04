<?php

namespace BitApps\BitFormPro\Services\Admin\FormSettings;

use BitApps\BitForm\Helpers\Cryptography\Cryptography;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Model\FormEntry;
use BitApps\BitForm\Services\Admin\Helpers;
use BitApps\BitForm\Services\Frontend\FrontendFormManager;
use BitApps\BitFormPro\Compat\EntryTrash;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitFormPro\Services\Abandonment\AbandonmentSettings;
use BitApps\BitFormPro\Services\Abandonment\RecoveryState;

final class FormAbandonment
{
    private $_formId;

    public function __construct($formId)
    {
        $this->_formId = $formId;
    }

    /**
     * The active settings as stored, for Free's bitform_form_abandonment_settings
     * filter. Pro's own code reads AbandonmentSettings.
     *
     * @param int $formId
     *
     * @return object|false
     */
    public static function getFormAbandonmentSettings($formId)
    {
        $integrationHandler = new IntegrationHandler($formId);
        $formIntegrations = $integrationHandler->getAllIntegration('formAbandonment', 'formAbandonment');
        if (!is_wp_error($formIntegrations) && !empty($formIntegrations)) {
            $data = $formIntegrations[0];
            $details = JSON::decode($data->integration_details);
            if (!empty($details->active)) {
                return $details;
            }
        }
        return false;
    }

    /**
     * The saved settings, active or not.
     *
     * @param int|null $formId
     *
     * @return object|false
     */
    public static function getStoredSettings($formId)
    {
        $formIntegrations = (new IntegrationHandler($formId))->getAllIntegration('formAbandonment', 'formAbandonment');
        if (is_wp_error($formIntegrations) || empty($formIntegrations[0]->integration_details)) {
            return false;
        }
        $details = JSON::decode($formIntegrations[0]->integration_details);
        return is_object($details) ? $details : false;
    }

    /**
     * The form-abandonment settings the admin edits: the stored ones even when the
     * feature is off. Answering "nothing" for an inactive config made the builder
     * start from an empty object, and the next save wiped every other key.
     *
     * @param int|null $formId
     *
     * @return object|false
     */
    public static function getFormAbandonmentConfig($formId)
    {
        return self::getStoredSettings($formId);
    }

    public static function savePartialFormProgress()
    {
        Utility::ignoreUserAbort();
        $formId = isset($_POST['bitforms_id']) ? (int) str_replace('bitforms_', '', sanitize_text_field(wp_unslash($_POST['bitforms_id']))) : 0;
        if ($formId <= 0) {
            wp_send_json_error(__('Invalid form ID.', 'bitformpro'), 400);
        }

        // CSRF: the draft/partial-save endpoint is nopriv and was previously unauthenticated,
        // letting bots create unlimited drafts and bypass final-submission CAPTCHA. Require the
        // per-form nonce (bitforms_<formId>) the client ships in bf_globals on every save.
        if (!check_ajax_referer('bitforms_' . $formId, '_ajax_nonce', false)) {
            wp_send_json_error(__('Security check failed. Please reload the page.', 'bitformpro'), 403);
        }

        $FrontendFormManager = FrontendFormManager::getInstance($formId);
        $settings = AbandonmentSettings::forForm($formId);

        if (null === $settings || !$settings->savesEmptyDrafts()) {
            $FrontendFormManager->fieldNameReplaceOfPost();
            $isEmpty = $FrontendFormManager->checkEmptySubmission($_POST, $_FILES);

            if ($isEmpty) {
                wp_send_json_error(
                    __('Form is empty.', 'bitformpro'),
                    400,
                );
            }
        }

        $FrontendFormManager->setSaveFormAsDraft();
        $FrontendFormManager->fieldNameReplaceOfPost();
        $isEntryRestricted = $FrontendFormManager->checkSubmissionRestriction(false);
        if (!empty($isEntryRestricted)) {
            return;
        }
        $userId = get_current_user_id();
        if (null !== $settings && $settings->onlyLoggedInUsers() && $userId == 0) {
            return;
        }
        $entryId = $_REQUEST['entryID'] ?? '';
        $entryId = sanitize_text_field(wp_unslash($entryId));
        // Digits only: MySQL casts '5/../..' to 5, so a traversal string would pass the draft
        // lookup and ownership check below, then reach the entry's upload path verbatim.
        if ('' !== $entryId && !ctype_digit($entryId)) {
            wp_send_json_error(__('Entry ID is invalid.', 'bitformpro'), 400);
        }
        $entryToken = $_REQUEST['entryToken'] ?? '';
        $entryToken = sanitize_text_field(wp_unslash($entryToken));
        // A logged-in visitor keeps one draft per form. The page only knows the draft
        // when "Refill the form" brought it back; without that, every visit would
        // start another one. The owner check in validateEntryTokenAndUser() lets
        // the update through without a token.
        if (empty($entryId) && $userId > 0) {
            $ownDraft = FormEntry::rowsWhere(
                EntryTrash::activeOnly(['form_id' => $formId, 'user_id' => $userId, 'status' => 9]),
                ['id'],
                'id',
                'desc',
            );
            if (!empty($ownDraft[0]->id)) {
                $entryId = (string) $ownDraft[0]->id;
            }
        }
        // A trashed draft is not one the submitter may resume: the admin put it in
        // the bin, and resuming it would quietly bring it back.
        $formEntry = empty($entryId) ? [] : FormEntry::readWhere(EntryTrash::activeOnly(['id' => $entryId, 'form_id' => $formId, 'status' => 9]), ['id']);
        $isEntryUpdate = false;
        if (empty($entryId) || is_wp_error($formEntry) || empty($formEntry)) {
            // A remembered draft that was since submitted or deleted starts a new draft;
            // otherwise every later save would report success and store nothing.
            $entryId = '';
            $submitStatus = $FrontendFormManager->saveFormEntry($_POST);
        } else {
            if (Helpers::validateEntryTokenAndUser($entryToken, $entryId)) {
                $submitStatus = $FrontendFormManager->updateFormEntry($_POST, $formId, $entryId);
                $isEntryUpdate = true;
            } else {
                wp_send_json_error(__('Entry Token is not Authorized', 'bitformpro'), 401);
            }
        }
        if (!empty($submitStatus) && is_wp_error($submitStatus)) {
            wp_send_json_error($submitStatus->get_error_message(), 400);
        }
        // check if entry id in submitStatus is empty
        if (empty($submitStatus['entry_id'])) {
            $submitStatus['entry_id'] = $entryId;
        }
        if ($isEntryUpdate) {
            self::recordProgress($formId, $submitStatus, $settings);
            $submitStatus = self::addGuestDraftData($submitStatus, $userId, $settings);
            wp_send_json_success(self::filterPartialSaveResponse($submitStatus), 200);
        }

        // A logged-in visitor's draft is found again by user id (checkAbandonedFormEntryId),
        // so nothing else needs recording here.
        self::recordProgress($formId, $submitStatus, $settings);
        $submitStatus = self::addGuestDraftData($submitStatus, $userId, $settings);
        wp_send_json_success(self::filterPartialSaveResponse($submitStatus), 200);
    }

    /**
     * Where the visitor is, for the entries list and multi-step resume. Only while the
     * feature is on: a Save Draft button or payment field on a form without it saves a
     * draft too, and those must not start reminders.
     *
     * @param int                      $formId
     * @param mixed                    $submitStatus
     * @param AbandonmentSettings|null $settings
     */
    private static function recordProgress($formId, $submitStatus, $settings)
    {
        if (null === $settings || !is_array($submitStatus) || empty($submitStatus['entry_id'])) {
            return;
        }
        $step = isset($_POST['bf_step']) && is_numeric($_POST['bf_step']) ? max(1, (int) $_POST['bf_step']) : null;
        $progress = isset($_POST['bf_progress']) && is_numeric($_POST['bf_progress']) ? max(0, min(100, (int) $_POST['bf_progress'])) : null;
        RecoveryState::touch((int) $formId, (int) $submitStatus['entry_id'], $step, $progress);
    }

    /**
     * Adds what the browser needs to keep a guest's draft copy current: `user_id` 0 tells
     * it to write localStorage, `entry_token` lets the next visit update the same entry.
     * Both the first save and every later update must carry them, or the stored copy
     * stays frozen at the first autosave and repopulates mostly empty fields.
     *
     * @param mixed                    $submitStatus saveFormEntry/updateFormEntry result
     * @param int                      $userId
     * @param AbandonmentSettings|null $settings
     *
     * @return mixed
     */
    private static function addGuestDraftData($submitStatus, $userId, $settings)
    {
        if (!is_array($submitStatus) || empty($submitStatus['entry_id'])) {
            return $submitStatus;
        }
        if (!$userId && null !== $settings && $settings->repopulatesForm()) {
            $submitStatus['user_id'] = 0;
        }
        $entryToken = Cryptography::encrypt($submitStatus['entry_id'], Helpers::getBitformSalt());
        if (is_string($entryToken)) {
            $submitStatus['entry_token'] = $entryToken;
        }
        return $submitStatus;
    }

    /**
     * Remove the sensitive payload from the partial-save response.
     *
     * The raw saveFormEntry/updateFormEntry result carries `triggerData` — mail recipient
     * addresses (to/cc/bcc/replyto), integration configs, and internal logID/formID — that
     * the draft-restore client never reads, leaking recipient emails and internal structure
     * to anyone who triggers a partial save.
     *
     * @param mixed $submitStatus
     * @return mixed
     */
    private static function filterPartialSaveResponse($submitStatus)
    {
        if (is_array($submitStatus)) {
            unset($submitStatus['triggerData']);
        } elseif (is_object($submitStatus)) {
            unset($submitStatus->triggerData);
        }
        return $submitStatus;
    }

    /**
     * The logged-in visitor's newest draft of this form, on any page it is embedded in.
     *
     * Drafts used to be tracked in the autoloaded option bitform_abandonment_entries,
     * keyed by post id, which grew on every new draft and missed a form shown on a
     * different page. The entry row already carries the user id.
     *
     * @return int|false
     */
    public function checkAbandonedFormEntryId()
    {
        if (false !== get_option('bitform_abandonment_entries', false)) {
            delete_option('bitform_abandonment_entries');
        }
        $settings = AbandonmentSettings::forForm($this->_formId);
        if (null === $settings || !$settings->repopulatesForm()) {
            return false;
        }
        $userId = get_current_user_id();
        if (!$userId) {
            return false;
        }
        $draft = FormEntry::readWhere(
            EntryTrash::activeOnly(['form_id' => (int) $this->_formId, 'user_id' => $userId, 'status' => 9]),
            ['id'],
            'id',
            'desc',
        );
        return !is_wp_error($draft) && !empty($draft[0]->id) ? (int) $draft[0]->id : false;
    }
}
