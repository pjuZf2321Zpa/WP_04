<?php

namespace BitApps\BitFormPro\Services\Admin\FormSettings;

use BitApps\BitForm\Services\Admin\Helpers;
use BitApps\BitForm\Model\Form;
use BitApps\BitForm\Model\FormEntry;
use BitApps\BitForm\Model\FormEntryLog;
use BitApps\BitForm\Services\Notification\MailConfig;
use BitApps\BitFormPro\Compat\EntryTrash;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Model\EntryRelatedInfoModel;
use BitApps\BitFormPro\Services\Abandonment\AbandonmentSettings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Save & Resume: a secret link that reopens a guest's Form Abandonment draft on any
 * browser or device. The link carries `<entryId>.<secret>`; only sha256(secret) is
 * stored, in bitforms_form_entry_relatedinfo (info_type draft_resume).
 */
final class DraftResume
{
    public const QUERY_ARG = 'bf_resume';

    private const MAX_EXPIRY_DAYS = 365;

    // Each copy/email request mints a link; older ones stay valid up to this many.
    private const MAX_LIVE_TOKENS = 5;

    private const EMAIL_LIMIT_PER_IP = 10;

    private const EMAIL_LIMIT_PER_DRAFT = 3;

    // Backstop when many addresses share one IP or a botnet rotates them.
    private const EMAIL_LIMIT_PER_FORM = 50;

    private const DRAFT_STATUS = 9;

    /**
     * AJAX bitforms_draft_resume_link: mint a resume link for the visitor's own draft and
     * optionally email it to them.
     */
    public static function createResumeLink()
    {
        $formId = isset($_POST['bitforms_id']) ? (int) str_replace('bitforms_', '', sanitize_text_field(wp_unslash($_POST['bitforms_id']))) : 0;
        if ($formId <= 0) {
            wp_send_json_error(__('Invalid form ID.', 'bitformpro'), 400);
        }
        if (!check_ajax_referer('bitforms_' . $formId, '_ajax_nonce', false)) {
            wp_send_json_error(__('Security check failed. Please reload the page.', 'bitformpro'), 403);
        }

        $settings = AbandonmentSettings::forForm($formId);
        if (null === $settings || !$settings->resumeLinksOn()) {
            wp_send_json_error(__('Resume links are turned off for this form.', 'bitformpro'), 403);
        }

        $entryId = isset($_POST['entryID']) ? sanitize_text_field(wp_unslash($_POST['entryID'])) : '';
        $entryToken = isset($_POST['entryToken']) ? sanitize_text_field(wp_unslash($_POST['entryToken'])) : '';
        if (!ctype_digit($entryId) || !self::isDraftOfForm((int) $entryId, $formId)
            || !Helpers::validateEntryTokenAndUser($entryToken, $entryId)) {
            wp_send_json_error(__('Save your progress first, then ask for the link again.', 'bitformpro'), 403);
        }
        $entryId = (int) $entryId;

        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $wantsEmail = isset($_POST['email']) && '' !== trim((string) wp_unslash($_POST['email']));
        if ($wantsEmail) {
            if (!$settings->resumeEmailOn()) {
                wp_send_json_error(__('Emailing the link is turned off for this form.', 'bitformpro'), 403);
            }
            if (!is_email($email)) {
                wp_send_json_error(__('Please enter a valid email address.', 'bitformpro'), 422);
            }
            if (!self::consumeEmailAllowance($formId, $entryId)) {
                wp_send_json_error(__('Too many emails were sent for this draft. Please try again later.', 'bitformpro'), 429);
            }
        }

        $pageUrl = isset($_POST['pageUrl']) ? esc_url_raw(wp_unslash($_POST['pageUrl'])) : '';
        $link = self::issueLink($formId, $entryId, self::linkBaseUrl($pageUrl), $settings);
        if (empty($link)) {
            wp_send_json_error(__('Could not create a resume link. Please try again.', 'bitformpro'), 500);
        }

        $response = [
            'url'         => $link['url'],
            'expires'     => $link['expires'],
            'expiresText' => self::formatExpiry($link['expires']),
        ];
        if ($wantsEmail) {
            if (!self::sendLinkEmail($email, $formId, $entryId, $link, $settings)) {
                wp_send_json_error(__('The email could not be sent. Copy the link instead.', 'bitformpro'), 500);
            }
            $response['emailed'] = true;
        }
        wp_send_json_success($response, 200);
    }

    /**
     * The draft a `?bf_resume=` link on this request opens for $formId, or 0.
     *
     * @param int $formId
     *
     * @return int
     */
    public static function entryIdFromRequest($formId)
    {
        if (!isset($_GET[self::QUERY_ARG]) || !is_string($_GET[self::QUERY_ARG])) {
            return 0;
        }
        return self::resolveToken($formId, sanitize_text_field(wp_unslash($_GET[self::QUERY_ARG])));
    }

    /**
     * @param int    $formId
     * @param mixed  $token  `<entryId>.<secret>`; anything else resolves to 0
     *
     * @return int the draft's entry id, 0 when the link is unknown, expired, tampered with,
     *             for another form, or its draft was submitted or deleted
     */
    public static function resolveToken($formId, $token)
    {
        $formId = (int) $formId;
        if ($formId <= 0 || !is_string($token) || 1 !== preg_match('/^(\d{1,20})\.([a-f0-9]{64})$/', $token, $match)) {
            return 0;
        }
        $entryId = (int) $match[1];
        $hash = hash('sha256', $match[2]);
        $infoModel = new EntryRelatedInfoModel();
        $tokens = $infoModel->getDraftResumeTokens($formId, $entryId);

        $matched = null;
        foreach ($tokens as $stored) {
            if (hash_equals($stored['hash'], $hash)) {
                $matched = $stored;
                break;
            }
        }
        if (null === $matched || $matched['expires'] < time()) {
            return 0;
        }
        if (!self::isDraftOfForm($entryId, $formId)) {
            // Submitted or deleted: none of its links can open anything any more.
            $infoModel->deleteDraftResumeTokens(array_column($tokens, 'id'));
            return 0;
        }
        return $entryId;
    }

    /**
     * Keeps the secret out of Referer headers and shared caches on the page a link opens.
     */
    public static function sendResumePageHeaders()
    {
        if (!isset($_GET[self::QUERY_ARG]) || headers_sent()) {
            return;
        }
        header('Referrer-Policy: no-referrer');
        nocache_headers();
    }

    /**
     * @param int                 $formId
     * @param int                 $entryId
     * @param string              $baseUrl
     * @param AbandonmentSettings $settings
     *
     * @return array{url:string, expires:int, token:string}|null
     */
    public static function issueLink($formId, $entryId, $baseUrl, AbandonmentSettings $settings)
    {
        $days = (int) apply_filters('bitform_draft_resume_link_expiry_days', $settings->resumeLinkExpiryDays(), $formId);
        $days = max(1, min(self::MAX_EXPIRY_DAYS, $days));
        $expires = time() + $days * DAY_IN_SECONDS;

        $secret = bin2hex(random_bytes(32));
        $infoModel = new EntryRelatedInfoModel();
        $inserted = $infoModel->insertDraftResumeToken($formId, $entryId, hash('sha256', $secret), $expires);
        if (is_wp_error($inserted) || empty($inserted)) {
            return null;
        }
        self::pruneTokens($infoModel, $formId, $entryId);

        $token = $entryId . '.' . $secret;
        return [
            'url'     => add_query_arg(self::QUERY_ARG, $token, $baseUrl),
            'expires' => $expires,
            'token'   => $token,
        ];
    }

    private static function pruneTokens(EntryRelatedInfoModel $infoModel, $formId, $entryId)
    {
        $stale = [];
        $live = 0;
        foreach ($infoModel->getDraftResumeTokens($formId, $entryId) as $stored) {
            if ($stored['expires'] < time() || $live >= self::MAX_LIVE_TOKENS) {
                $stale[] = $stored['id'];
                continue;
            }
            $live++;
        }
        if ($stale) {
            $infoModel->deleteDraftResumeTokens($stale);
        }
    }

    private static function isDraftOfForm($entryId, $formId)
    {
        // A trashed draft stays closed: the admin binned it.
        return FormEntry::existsWhere(EntryTrash::activeOnly([
            'id'      => (int) $entryId,
            'form_id' => (int) $formId,
            'status'  => self::DRAFT_STATUS,
        ]));
    }

    /**
     * The page the form is on, so the link reopens the same page. Only this site's own
     * URLs are accepted; the endpoint must not mint links that point elsewhere.
     *
     * @param string $pageUrl
     *
     * @return string
     */
    private static function linkBaseUrl($pageUrl)
    {
        foreach ([$pageUrl, wp_get_referer()] as $candidate) {
            if (!is_string($candidate) || '' === $candidate) {
                continue;
            }
            $candidate = wp_validate_redirect($candidate, '');
            if ('' !== $candidate) {
                return remove_query_arg(self::QUERY_ARG, $candidate);
            }
        }
        return home_url('/');
    }

    /**
     * Counts this email against both limits; false when either is used up.
     */
    private static function consumeEmailAllowance($formId, $entryId)
    {
        // REMOTE_ADDR, not IpTool::getIP(): that trusts Client-IP / X-Forwarded-For, which a
        // sender can rotate to slip past the limit.
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        $keys = [
            'bitform_resume_rl_ip_' . md5($ip . '|' . $formId) => self::EMAIL_LIMIT_PER_IP,
            'bitform_resume_rl_entry_' . (int) $entryId        => self::EMAIL_LIMIT_PER_DRAFT,
            'bitform_resume_rl_form_' . (int) $formId          => self::EMAIL_LIMIT_PER_FORM,
        ];
        foreach ($keys as $key => $limit) {
            $count = get_transient($key);
            if (is_numeric($count) && (int) $count >= $limit) {
                return false;
            }
        }
        foreach ($keys as $key => $limit) {
            $count = get_transient($key);
            set_transient($key, (is_numeric($count) ? (int) $count : 0) + 1, HOUR_IN_SECONDS);
        }
        return true;
    }

    /**
     * The message is the admin's template plus the link: nothing the visitor typed goes
     * in, so the email box cannot relay someone else's content.
     */
    private static function sendLinkEmail($to, $formId, $entryId, array $link, AbandonmentSettings $settings)
    {
        $formName = self::formName($formId);
        $subject = $settings->resumeEmailSubject() ?: __('Continue your form: ${form_name}', 'bitformpro');
        $body = $settings->resumeEmailBody() ?: self::defaultEmailBody();

        $expiryText = self::formatExpiry($link['expires']);
        $subject = wp_strip_all_tags(str_replace(
            ['${form_name}', '${bf_resume_expiry}'],
            [$formName, $expiryText],
            $subject
        ));
        $body = str_replace(
            ['${bf_resume_link}', '${form_name}', '${bf_resume_expiry}'],
            [esc_url($link['url']), esc_html($formName), esc_html($expiryText)],
            wp_kses_post($body)
        );

        $mail = apply_filters('bitform_draft_resume_email', [
            'to'      => $to,
            'subject' => $subject,
            'body'    => $body,
            'headers' => ['Content-Type: text/html; charset=UTF-8'],
        ], $formId, $entryId);
        if (!is_array($mail) || empty($mail['to'])) {
            return false;
        }

        (new MailConfig())->sendMail();
        $sent = (bool) wp_mail(
            $mail['to'],
            $mail['subject'] ?? $subject,
            $mail['body'] ?? $body,
            $mail['headers'] ?? []
        );
        if ($sent) {
            self::logEmailed($formId, $entryId, $mail['to']);
        }
        return $sent;
    }

    /**
     * Put the send on the entry's timeline: this email bypasses MailNotifier, so
     * nothing else records it, and the admin would never know the link went out.
     */
    private static function logEmailed($formId, $entryId, $to)
    {
        FormEntryLog::insertRow([
            'user_id'       => get_current_user_id(),
            'log_type'      => 'resume_email',
            'ip'            => 0,
            'action_type'   => 'create',
            'form_entry_id' => (int) $entryId,
            'form_id'       => (int) $formId,
            'content'       => JSON::encode(['to' => is_array($to) ? implode(', ', $to) : (string) $to]),
            'created_at'    => current_time('mysql'),
        ]);
    }

    public static function defaultEmailBody()
    {
        return '<p>' . __('You saved your progress on ${form_name}.', 'bitformpro') . '</p>'
            . '<p><a href="${bf_resume_link}">' . __('Continue where you left off', 'bitformpro') . '</a></p>'
            . '<p>' . __('This link works until ${bf_resume_expiry}. Anyone with the link can open your answers, so do not share it.', 'bitformpro') . '</p>';
    }

    private static function formName($formId)
    {
        $form = Form::rowsWhere(['id' => (int) $formId], ['form_name']);
        if (empty($form[0]->form_name)) {
            return get_bloginfo('name');
        }
        return (string) $form[0]->form_name;
    }

    private static function formatExpiry($timestamp)
    {
        return wp_date((string) get_option('date_format', 'F j, Y'), (int) $timestamp);
    }
}
