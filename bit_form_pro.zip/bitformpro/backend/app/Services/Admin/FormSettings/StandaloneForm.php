<?php

namespace BitApps\BitFormPro\Services\Admin\FormSettings;

use BitApps\BitForm\Services\Admin\FrontEndScriptGenerator;
use BitApps\BitForm\Helpers\GlobalHelper;

final class StandaloneForm
{
    public static function saveStandaloneCSS()
    {
        try {
            $requestsParams = GlobalHelper::formatRequestData();
        } catch (\InvalidArgumentException $e) {
            wp_send_json_error($e->getMessage(), 400);
        }

        $formId = $requestsParams->formID;
        $css = $requestsParams->css;

        $path = 'form-styles';
        $fileName = "bitform-standalone-$formId.css";
        FrontEndScriptGenerator::customCodeFileSaveOrDelete($css, $path, $fileName);
        wp_send_json_success(__('CSS Saved Successfully!', 'bitformpro'), 200);
    }
}
