<?php

namespace BitApps\BitFormPro\Services\Admin;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Helpers\FileHandler;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Model\FormEntry;
use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitForm\Services\Notification\MailConfig;
use BitApps\BitFormPro\Compat\EntryTrash;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Model\LogModel;

class DblOptin
{
    public function init()
    {
        add_action('bitform_unconfirmed_entries_deleted', [$this, 'deletedUnconfirmedEntries']);
    }

    public function sendEntryMailConfirmation($detail, $workFlowReturnedData)
    {
        $dblOptin = JSON::decode($detail->integration_details);

        $fldData = $workFlowReturnedData['fields'];

        $formID = $workFlowReturnedData['formID'];

        $emailFld = $dblOptin->fldkey;

        if (isset($fldData[$emailFld]) && !empty($fldData[$emailFld]) && isset($workFlowReturnedData['entryID'])) {

            $mailSubject = $dblOptin->sub;
            $mailBody = $dblOptin->body;
            $token = wp_generate_uuid4();
            $entryId = $workFlowReturnedData['entryID'];
            $urlParams = $workFlowReturnedData['formID'] . '_' . $workFlowReturnedData['entryID'] . '_' . $workFlowReturnedData['logID'];
            $mailBody = FieldValueHandler::replaceFieldWithValue($mailBody, $fldData, $formID);
            $tokenURL = home_url() . '?token=' . $token . '&entry_id=' . $urlParams;
            $mailBody = preg_replace("/{entry_confirmation_url}/", $tokenURL, $mailBody);
            add_filter('wp_mail_content_type', [$this, 'filterMailContentType']);

            (new MailConfig())->sendMail();
            $mailSendSuccss = wp_mail($fldData[$emailFld], $mailSubject, $mailBody);

            if ($mailSendSuccss) {
                $this->insertActivationKey($entryId, $token);
            }

            remove_filter('wp_mail_content_type', [$this, 'filterMailContentType']);

        }
    }



    public function updatedEmailBodyMessage($mailBody, $urlParams)
    {
        $token = wp_generate_uuid4();

        $mailBody = preg_replace("/{entry_confirmation_url}/", home_url() . '?token=' . $token . '&entry_id=' . $urlParams, $mailBody);

        return ['token' => $token, 'mailbody' => $mailBody];
    }

    public function insertActivationKey($entryId, $token)
    {
        FormEntryMeta::insertRow(
            [
                'bitforms_form_entry_id' => $entryId,
                'meta_key' => 'entry_confirm_activation',
                'meta_value' => $token,
            ],
        );
    }

    public function deletedUnconfirmedEntries()
    {
        $doubleOptins = (new IntegrationHandler(0))->getIntegrationWithoutFormId('double-opt-in', 'double-opt-in');
        global $wpdb;

        if (!is_wp_error($doubleOptins) && count($doubleOptins) > 0) {
            foreach ($doubleOptins as $dblOptin) {

                $details = JSON::decode($dblOptin->integration_details);

                if (
                    isset($details->auto_unconfirmed_deleted)
                ) {
                    $entryTable = $wpdb->prefix . 'bitforms_form_entries'; // $metaTable = $wpdb->prefix.static::$entry_meta_table;
                    $formId = isset($dblOptin->form_id) ? (int) $dblOptin->form_id : 0;
                    $days = isset($details->day) ? (int) $details->day : 0;
                    if ($formId > 0 && $days > 0) {
                        // Entries already in the trash are not swept up: they
                        // are restorable, and this routine deletes for good.
                        $trashClause = EntryTrash::sqlClause('entries');
                        $sql = $wpdb->prepare(
                            "SELECT entries.id FROM {$entryTable} as entries WHERE entries.form_id=%d AND DATE_ADD(date(entries.created_at), INTERVAL %d DAY) < CURRENT_DATE AND entries.status=2{$trashClause}",
                            $formId,
                            $days,
                        );
                        $result = $wpdb->get_results($sql, OBJECT_K);
                    } else {
                        $result = [];
                    }
                    $entries = array_column($result, 'id');

                    $formLogModel = new LogModel();

                    if (count($entries) > 0) {

                        FormEntry::deleteEntries($dblOptin->form_id, $entries);

                        $formLogModel->logDelete([
                            "`{$wpdb->prefix}bitforms_form_entry_log`.`id`" => $entries,
                            "`{$wpdb->prefix}bitforms_form_entry_log`.`form_id`" => $dblOptin->form_id,
                        ]);

                        if (file_exists(BITFORMS_UPLOAD_DIR . DIRECTORY_SEPARATOR . $dblOptin->form_id)) {
                            $fileHandler = new FileHandler();

                            foreach ($entries as $entryID) {
                                $fileEntries = BITFORMS_UPLOAD_DIR . DIRECTORY_SEPARATOR . $dblOptin->form_id . DIRECTORY_SEPARATOR . $entryID;
                                if (file_exists($fileEntries)) {
                                    $fileHandler->rmrf($fileEntries);
                                }
                            }
                        }

                    }
                }
            }

        }
    }

    public function filterMailContentType()
    {
        return 'text/html; charset=UTF-8';
    }
}
