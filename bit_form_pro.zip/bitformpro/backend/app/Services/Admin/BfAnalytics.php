<?php

namespace BitApps\BitFormPro\Services\Admin;

use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Model\FrontendViewModel;
use BitApps\BitFormPro\Model\PaymentInfoModel;
use BitApps\BitFormPro\Model\PdfTemplateModel;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Bit Form Pro's part of Bit Form's usage report: the data of Pro's own tables.
 *
 * Bit Form owns usage reporting (consent, the report, the "What we collect"
 * list, which already lists what this adds). Free sends `pdfTemplate`,
 * `tableView` and `paymentInfo` empty and this fills them. Nothing runs unless
 * the admin opted in, since the filter only fires while a report is built.
 */
class BfAnalytics
{
    /**
     * `bitforms_telemetry_additional_data` filter, after Bit Form's own (priority 5).
     *
     * @param mixed $additionalData not type-hinted, as no filter callback is
     *
     * @return mixed
     */
    public function addProUsageData($additionalData)
    {
        if (!\is_array($additionalData)) {
            return $additionalData;
        }

        if (isset($additionalData['forms']) && \is_array($additionalData['forms'])) {
            $pdfTemplates = $this->countPerForm(new PdfTemplateModel());
            $tableViews = $this->countPerForm(new FrontendViewModel());

            foreach ($additionalData['forms'] as $index => $form) {
                if (!\is_array($form) || !isset($form['id'])) {
                    continue;
                }
                $formId = (int) $form['id'];
                $additionalData['forms'][$index]['pdfTemplate'] = $pdfTemplates[$formId] ?? 0;
                $additionalData['forms'][$index]['tableView'] = $tableViews[$formId] ?? 0;
            }
        }

        $additionalData['paymentInfo'] = $this->getPaymentInfo();

        return $additionalData;
    }

    /**
     * @param PdfTemplateModel|FrontendViewModel $model
     *
     * @return array<int, int>
     */
    private function countPerForm($model)
    {
        $rows = $model->get(['form_id']);
        $count = [];
        if (!\is_array($rows)) {
            return $count;
        }
        foreach ($rows as $row) {
            $formId = (int) $row->form_id;
            $count[$formId] = ($count[$formId] ?? 0) + 1;
        }

        return $count;
    }

    /**
     * Live payments per gateway, each with its amount and currency only.
     *
     * @return array
     */
    private function getPaymentInfo()
    {
        $allTransactions = (new PaymentInfoModel())->get(['form_id', 'payment_name', 'payment_response']);

        if (!\is_array($allTransactions) || empty($allTransactions)) {
            return [];
        }

        $result = [
            'totalPaymentFormEntries' => 0,
            'payments'                => [],
            'totalForm'               => 0,
        ];

        $tempTotalForms = [];

        foreach ($allTransactions as $trx) {
            $gateway = strtolower((string) $trx->payment_name);

            $paymentResponse = JSON::decode((string) $trx->payment_response, true);
            $paymentResponse = \is_array($paymentResponse) ? $paymentResponse : [];

            if (false === \in_array($trx->form_id, $tempTotalForms)) {
                $tempTotalForms[] = $trx->form_id;
            }

            if (!isset($result['payments'][$gateway])) {
                $result['payments'][$gateway] = [
                    'totalTransaction'   => 0,
                    'transactionDetails' => [],
                ];
            }

            if (!$this->isLiveMode($gateway, $paymentResponse)) {
                continue;
            }

            [$amount, $currency] = $this->extractAmountAndCurrency($gateway, $paymentResponse);

            $result['payments'][$gateway]['totalTransaction'] += 1;
            $result['payments'][$gateway]['transactionDetails'][] = [
                'amount'   => $amount,
                'currency' => $currency,
            ];
            $result['totalPaymentFormEntries'] += 1;
        }

        $result['totalForm'] = \count($tempTotalForms);

        return $result;
    }

    /**
     * Extracts amount and currency from a payment response for any gateway
     */
    private function extractAmountAndCurrency($gateway, $response)
    {
        $amount = 0;
        $currency = 'unknown';

        switch ($gateway) {
            case 'stripe':
                $amount = isset($response['amount']) && is_numeric($response['amount'])
                    ? $response['amount'] / 100
                    : 0;
                $currency = strtolower($response['currency'] ?? 'usd');
                break;

            case 'razorpay':
                $amount = isset($response['amount']) && is_numeric($response['amount'])
                    ? $response['amount'] / 100
                    : 0;
                $currency = strtolower($response['currency'] ?? 'inr');
                break;

            case 'paypal':
                $unit = $response['purchase_units'][0]['amount'] ?? [];
                $amount = floatval($unit['value'] ?? 0);
                $currency = strtolower($unit['currency_code'] ?? 'usd');
                break;

            case 'mollie':
                $amount = floatval($response['amount']['value'] ?? 0);
                $currency = strtolower($response['amount']['currency'] ?? 'eur');
                break;
        }

        return [$amount, $currency];
    }

    private function isLiveMode(string $gateway, array $response): bool
    {
        switch ($gateway) {
            case 'stripe':
                return !empty($response['livemode']);

            case 'razorpay':
                return isset($response['status']) && 'captured' === $response['status'];

            case 'paypal':
                return isset($response['status']) && 'COMPLETED' === $response['status'];

            case 'mollie':
                return isset($response['mode']) && 'live' === $response['mode'];

            default:
                return false;
        }
    }
}
