<?php

namespace BitApps\BitFormPro\Services;

use BitApps\BitFormPro\Helpers\AddressApiKeysHelper;
use BitApps\BitFormPro\Helpers\LicenseHelper;
use BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment;
use BitApps\BitFormPro\Compat\ReleasedName;
use BitApps\BitForm\Workflow\WorkFlowHandler;
use BitApps\BitFormPro\Services\Admin\FormSettings\DraftResume;
use BitApps\BitFormPro\Services\Abandonment\AbandonmentSettings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Registers Pro-only behavior into the free plugin via filters/actions.
 *
 * This keeps Pro feature implementations out of the wp.org (free) package.
 */
final class ProFeatureHooks
{
    public static function register(): void
    {
        add_filter('bitform_validation_and_other_script_files', [ReleasedName::of(self::class), 'extendValidationFiles'], 10, 1);
        add_filter('bitform_field_validation_script_file_mapping', [ReleasedName::of(self::class), 'extendFieldValidationFileMapping'], 10, 2);
        add_filter('bitform_script_file_priority_list', [ReleasedName::of(self::class), 'extendScriptFilePriorityList'], 10, 1);
        add_filter('bitform_form_abandonment_script_files', [ReleasedName::of(self::class), 'formAbandonmentScripts'], 10, 3);
        add_filter('bitform_form_abandonment_settings', [ReleasedName::of(self::class), 'getFormAbandonmentSettings'], 10, 2);
        add_filter('bitform_form_abandonment_warning_markup', [ReleasedName::of(self::class), 'getFormAbandonmentWarningMarkup'], 10, 2);
        add_filter('bitform_is_abandoned_entry', [ReleasedName::of(self::class), 'isAbandonedEntry'], 10, 4);
        // Not a released callback: DraftResume is new, so no ReleasedName.
        add_action('send_headers', [DraftResume::class, 'sendResumePageHeaders']);
        add_filter('bitform_field_config_paths', [ReleasedName::of(self::class), 'extendFieldConfigPaths'], 10, 1);

        add_filter('bitform_filepond_plugins_list', [ReleasedName::of(self::class), 'filePondPluginsList'], 10, 1);
        add_filter('bitform_repeater_repeated_rows', [ReleasedName::of(self::class), 'repeaterRepeatedRows'], 10, 2);
    }

    public static function extendValidationFiles($files): array
    {
        // Filter-callback params must tolerate anything the hook chain passes
        // (null/garbage from other callbacks or older free-plugin versions).
        $files = is_array($files) ? $files : [];
        // if (!LicenseHelper::hasValidLicense()) {
        //     return $files;
        // }
        $files['checkMinMaxOptions'] = ['priority' => 702, 'filename' => 'checkMinMaxOptions.min.js'];
        $files['regexPatternValidation'] = ['priority' => 701, 'filename' => 'regexPatternValidation.min.js'];
        $files['nmbrFldValidation'] = ['priority' => 702, 'filename' => 'nmbrFldValidation.min.js'];
        $files['bfDatetimeFldValidation'] = ['priority' => 702, 'filename' => 'bfDatetimeFldValidation.min.js'];
        return $files;
    }

    public static function extendFieldValidationFileMapping($mapping, $fieldType): array
    {
        $mapping = is_array($mapping) ? $mapping : [];
        if (!LicenseHelper::hasValidLicense() || !is_string($fieldType) || '' === $fieldType) {
            return $mapping;
        }

        // Normalize like free plugin does (textTypeField maps to "text").
        $textTypeField = ['text', 'password', 'username', 'color'];
        if (in_array($fieldType, $textTypeField, true)) {
            $fieldType = 'text';
        }

        if ('text' === $fieldType) {
            $mapping['regexPatternValidation'] = [
                'paths'        => ['valid->regexr'],
                'dependencies' => ['generateBackslashPattern'],
            ];
        }

        if ('number' === $fieldType) {
            $mapping['nmbrFldValidation'] = [
                'paths' => ['mn', 'mx'],
            ];
        }

        if ('textarea' === $fieldType) {
            $mapping['regexPatternValidation'] = [
                'paths'        => ['valid->regexr'],
                'dependencies' => ['generateBackslashPattern'],
            ];
        }

        if ('url' === $fieldType) {
            $mapping['regexPatternValidation'] = [
                'paths'        => ['valid->regexr'],
                'dependencies' => ['generateBackslashPattern'],
            ];
        }

        if ('radio' === $fieldType) {
            $mapping['customOptionValidation'] = [
                'paths' => ['valid->otherOptReq'],
            ];
        }

        if ('check' === $fieldType) {
            $mapping['checkMinMaxOptions'] = [
                'paths' => ['mn', 'mx'],
                'dependencies' => ['checkFldValidation'],
            ];
            $mapping['customOptionValidation'] = [
                'paths' => ['valid->otherOptReq'],
            ];
        }

        if ('select' === $fieldType) {
            $mapping['checkMinMaxOptions'] = [
                'paths' => ['mn', 'mx'],
                'dependencies' => ['checkFldValidation'],
            ];
        }

        if ('image-select' === $fieldType) {
            $mapping['checkMinMaxOptions'] = [
                'paths' => ['mn', 'mx'],
                'dependencies' => ['checkFldValidation'],
            ];
        }

        if ('advanced-file-up' === $fieldType) {
            $mapping['advanceFileupFldValidation'] = [
                'paths' => ['valid->req'],
            ];
        }

        if ('currency' === $fieldType) {
            $mapping['currencyFldValidation'] = [
                'paths'        => ['err->minValue->show', 'err->maxValue->show'],
            ];
        }

        if ('date' === $fieldType) {
            $mapping['bfDatetimeFldValidation'] = [
                'paths'        => ['mn', 'mx'],
                'dependencies' => [
                    'bfParseDateTime',
                ],
            ];
        }

        if ('time' === $fieldType) {
            $mapping['bfDatetimeFldValidation'] = [
                'paths'        => ['mn', 'mx'],
                'dependencies' => [
                    'bfParseDateTime',
                ],
            ];
        }

        if ('week' === $fieldType) {
            $mapping['bfDatetimeFldValidation'] = [
                'paths'        => ['mn', 'mx'],
                'dependencies' => [
                    'bfParseDateTime',
                ],
            ];
        }

        if ('month' === $fieldType) {
            $mapping['bfDatetimeFldValidation'] = [
                'paths'        => ['mn', 'mx'],
                'dependencies' => [
                    'bfParseDateTime',
                ],
            ];
        }

        if ('datetime-local' === $fieldType) {
            $mapping['bfDatetimeFldValidation'] = [
                'paths'        => ['mn', 'mx'],
                'dependencies' => [
                    'bfParseDateTime',
                ],
            ];
        }

        return $mapping;
    }

    public static function extendScriptFilePriorityList($files): array
    {
        $files = is_array($files) ? $files : [];
        // if (!LicenseHelper::hasValidLicense()) {
        //     return $files;
        // }

        $proFiles = ScriptFilePriorityManager::scriptFilePriorityList();
        foreach ($proFiles as $key => $items) {
            if (isset($files[$key]) && is_array($files[$key])) {
                $files[$key] = array_merge($files[$key], $items);
            } else {
                $files[$key] = $items;
            }
        }

        return $files;
    }

    public static function formAbandonmentScripts($files, $formContents, $fields): array
    {
        $files = is_array($files) ? $files : [];
        $formContents = is_array($formContents) ? $formContents : [];
        $fields = is_array($fields) ? $fields : [];
        if (!LicenseHelper::hasValidLicense() || !class_exists('\BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment')) {
            return $files;
        }

        // Use the Pro helper to build the file list.
        $allFiles = [];
        foreach ($formContents as $formContent) {
            $abandonment = AbandonmentSettings::forForm($formContent->formId);
            if (null !== $abandonment && $abandonment->autoSavesDrafts()) {
                $neededFiles = ScriptFilePriorityManager::formAbandonmentNeededFiles('autoSave');
                $allFiles = array_merge($allFiles, $neededFiles);
            }

            $workflowHandler = new WorkFlowHandler($formContent->formId);
            $allWorkflows = $workflowHandler->getAllworkFlow();
            foreach ($allWorkflows as $workflow) {
                foreach ($workflow['conditions'] as $cond) {
                    if (!empty($cond->actions) && !empty($cond->actions->fields)) {
                        foreach ($cond->actions->fields as $fldAction) {
                            if (empty($fldAction->field) || empty($fldAction->action)) {
                                continue;
                            }
                            if ('_bf_form' === $fldAction->field && 'save_draft' === $fldAction->action) {
                                $neededFiles = ScriptFilePriorityManager::formAbandonmentNeededFiles();
                                $allFiles = array_merge($allFiles, $neededFiles);
                                break 3;
                            }
                        }
                    }
                }
            }
        }

        if (isset($fields['button'])) {
            foreach ($fields['button'] as $button) {
                if (!empty($button['field']) && 'save-draft' === ($button['field']->btnTyp ?? null)) {
                    $neededFiles = ScriptFilePriorityManager::formAbandonmentNeededFiles();
                    $allFiles = array_merge($allFiles, $neededFiles);
                    break;
                }
            }
        }

        return array_values(array_merge($files, $allFiles));
    }

    public static function getFormAbandonmentSettings($settings, $formId)
    {
        if (!LicenseHelper::hasValidLicense() || !class_exists('\BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment') || !is_numeric($formId)) {
            return $settings;
        }

        return FormAbandonment::getFormAbandonmentSettings((int) $formId);
    }

    public static function getFormAbandonmentWarningMarkup($markup, $formId): string
    {
        if (!LicenseHelper::hasValidLicense() || !class_exists('\BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment') || !is_numeric($formId)) {
            return (string) $markup;
        }

        $settings = AbandonmentSettings::forForm((int) $formId);
        $message = null !== $settings ? $settings->warningMessage() : '';

        return '' !== $message ? '<div class="bf-form-msg active warning">' . wp_kses_post($message) . '</div>' : '';
    }

    /**
     * Returns the id of the abandoned entry the current visitor can resume, so Free
     * loads that entry's values. A bool here made Free load entry #1.
     *
     * @return int|false
     */
    public static function isAbandonedEntry($result, $formId, $entryId, $atts)
    {
        if (!LicenseHelper::hasValidLicense() || !class_exists('\BitApps\BitFormPro\Services\Admin\FormSettings\FormAbandonment') || !is_numeric($formId)) {
            return $result;
        }

        // Only attempt when no explicit entry id was requested.
        if (!empty($entryId)) {
            return $result;
        }

        // A Save & Resume link names its draft explicitly; it wins over the visitor's own.
        // Reminder emails carry one too, even when visitors cannot copy links themselves.
        $abandonment = AbandonmentSettings::forForm($formId);
        if (null !== $abandonment && ($abandonment->resumeLinksOn() || $abandonment->remindersOn())) {
            $resumeEntryId = DraftResume::entryIdFromRequest($formId);
            if ($resumeEntryId > 0) {
                return $resumeEntryId;
            }
        }

        $formAbandonment = new FormAbandonment($formId);
        $abandonedEntryId = $formAbandonment->checkAbandonedFormEntryId();
        return is_numeric($abandonedEntryId) && (int) $abandonedEntryId > 0 ? (int) $abandonedEntryId : false;
    }

    /**
     * Injects Pro-specific field config paths into the free plugin's JS config mapping.
     * Without these paths, Pro field configs (e.g. detectByIP) are not passed to the JS constructor.
     *
     * @param array $configs
     * @return array
     */
    public static function extendFieldConfigPaths($configs): array
    {
        $configs = is_array($configs) ? $configs : [];
        // if (!LicenseHelper::hasValidLicense()) {
        //     return $configs;
        // }

        // ── Select (dropdown) field ────────────────────────────────────────────
        $configs['select']['closeOnSelect']         = ['path' => 'config->closeOnSelect',   'val' => false];
        $configs['select']['selectedOptImage']      = ['path' => 'config->selectedOptImage','val' => false];
        $configs['select']['optionIcon']            = ['path' => 'config->optionIcon',      'val' => false];
        $configs['select']['allowCustomOption']     = ['path' => 'config->allowCustomOption','val' => false];
        $configs['select']['maxHeight']             = ['path' => 'config->maxHeight',       'val' => 370];
        $configs['select']['mn']                    = ['path' => 'mn',                      'val' => 0];
        $configs['select']['mx']                    = ['path' => 'mx',                      'val' => 0];
        $configs['select']['disableOnMax']          = ['path' => 'valid->disableOnMax',     'val' => false];

        // ── Country field ──────────────────────────────────────────────────────
        // NOTE: key names match what bit-country-field.js reads from config.
        $configs['country']['detectCountryByIp']        = ['path' => 'config->detectCountryByIp',       'val' => false];
        $configs['country']['detectCountryByGeo']       = ['path' => 'config->detectCountryByGeo',      'val' => false];
        $configs['country']['selectedFlagImage']        = ['path' => 'config->selectedFlagImage',       'val' => false];
        $configs['country']['optionFlagImage']          = ['path' => 'config->optionFlagImage',         'val' => false];
        $configs['country']['noCountryFoundText']       = ['path' => 'config->noCountryFoundText',      'val' => ''];
        $configs['country']['maxHeight']                = ['path' => 'config->maxHeight',               'val' => 370];

        // ── Address field ──────────────────────────────────────────────────────
        $configs['address']['autocomplete']             = ['path' => 'config->autocomplete',            'val' => 'none'];
        $configs['address']['autocompleteApiKey']       = ['path' => 'config->autocompleteApiKey',      'val' => ''];
        $configs['address']['autoLocate']               = ['path' => 'config->autoLocate',              'val' => 'disable'];
        $configs['address']['showMap']                  = ['path' => 'config->showMap',                 'val' => 'none'];
        $configs['address']['saveCoordinates']          = ['path' => 'config->saveCoordinates',         'val' => false];
        $configs['address']['globalGoogleApiKey']       = ['val' => AddressApiKeysHelper::getGoogleApiKey()];
        $configs['address']['globalMapboxToken']        = ['val' => AddressApiKeysHelper::getMapboxToken()];

        // ── Currency field ─────────────────────────────────────────────────────
        $configs['currency']['inputFormatOptions']      = ['path' => 'inputFormatOptions'];
        $configs['currency']['valueFormatOptions']      = ['path' => 'valueFormatOptions'];
        $configs['currency']['selectedFlagImage']       = ['path' => 'config->selectedFlagImage',       'val' => false];
        $configs['currency']['optionFlagImage']         = ['path' => 'config->optionFlagImage',         'val' => false];
        $configs['currency']['noCurrencyFoundText']     = ['path' => 'config->noCurrencyFoundText',     'val' => ''];
        $configs['currency']['minValue']                = ['path' => 'config->minValue',                'val' => ''];
        $configs['currency']['maxValue']                = ['path' => 'config->maxValue',                'val' => ''];
        $configs['currency']['maxHeight']               = ['path' => 'config->maxHeight',               'val' => 370];

        // ── Phone Number field ─────────────────────────────────────────────────
        $configs['phone-number']['inputFormat']         = ['path' => 'config->inputFormat',             'val' => ''];
        $configs['phone-number']['valueFormat']         = ['path' => 'config->valueFormat',             'val' => ''];
        $configs['phone-number']['selectedFlagImage']   = ['path' => 'config->selectedFlagImage',       'val' => false];
        $configs['phone-number']['hideCountryList']     = ['path' => 'config->hideCountryList',         'val' => false];
        $configs['phone-number']['optionFlagImage']     = ['path' => 'config->optionFlagImage',         'val' => false];
        $configs['phone-number']['detectCountryByIp']   = ['path' => 'config->detectCountryByIp',       'val' => false];
        $configs['phone-number']['detectCountryByGeo']  = ['path' => 'config->detectCountryByGeo',      'val' => false];
        $configs['phone-number']['noCountryFoundText']  = ['path' => 'config->noCountryFoundText',      'val' => ''];
        $configs['phone-number']['maxHeight']           = ['path' => 'config->maxHeight',               'val' => 370];

        // ── File Upload (file-up) field ────────────────────────────────────────
        // Overrides the static false defaults set in the free plugin's getAllFldConfs().
        $configs['file-up']['showMaxSize']      = ['path' => 'config->showMaxSize',      'val' => false];
        $configs['file-up']['maxSizeLabel']     = ['path' => 'config->maxSizeLabel',     'val' => ''];
        $configs['file-up']['showFileList']     = ['path' => 'config->showFileList',     'val' => false];
        $configs['file-up']['showFilePreview']  = ['path' => 'config->showFilePreview',  'val' => false];
        $configs['file-up']['showFileSize']     = ['path' => 'config->showFileSize',     'val' => false];
        $configs['file-up']['fileExistMsg']     = ['path' => 'config->fileExistMsg',     'val' => 'A file already exist'];

        // ── Repeater field ─────────────────────────────────────────────────────
        // Overrides the static defaults set in the free plugin's getAllFldConfs() with actual paths.
        $configs['repeater']['defaultRow']      = ['path' => 'defaultRow',      'val' => 1];
        $configs['repeater']['minimumRow']      = ['path' => 'minRow',          'val' => 0];
        $configs['repeater']['maximumRow']      = ['path' => 'maxRow',          'val' => 0];
        $configs['repeater']['btnPosition']     = ['path' => 'btnPosition',     'val' => 'column'];
        // Matches the builder's new-field default (the Add To End button's own alignment is separate).
        $configs['repeater']['btnAlignment']    = ['path' => 'btnAlignment',    'val' => 'center'];
        $configs['repeater']['btnView']         = ['path' => 'btnView',         'val' => 'row'];

        $configs['rating']['showReviewLblOnHover']         = ['path' => 'showReviewLblOnHover'];
        $configs['rating']['showReviewLblOnSelect']        = ['path' => 'showReviewLblOnSelect'];

        // Payment fields
        $configs['paypal'] = [
            'payIntegID'     => ['path' => 'payIntegID'],
            'style'          => ['path' => 'style'],
            'currency'       => ['path' => 'currency', 'val' => 'USD'],
            'amount'         => ['path' => 'amount', 'val' => 0],
            'amountFld'      => ['path' => 'amountFld', 'val' => ''],
            'shipping'       => ['path' => 'shipping', 'val' => 0],
            'shippingVal'    => ['path' => 'shippingFld', 'val' => ''],
            'tax'            => ['path' => 'tax', 'val' => 0],
            'taxVal'         => ['path' => 'taxFld', 'val' => ''],
            'description'    => ['path' => 'description', 'val' => ''],
            'descFld'        => ['path' => 'descFld', 'val' => ''],
            'payType'        => ['path' => 'payType', 'val' => 'payment'],
            'planId'         => ['path' => 'planId', 'val' => ''],
            'locale'         => ['path' => 'locale', 'val' => 'en_US'],
            'disableFunding' => ['path' => 'disableFunding', 'val' => ''],
            'fieldKey'       => ['var' => 'fieldKey'],
            'clientId'       => ['path' => 'clientId'],
            'contentId'      => ['var' => 'contentId'],
            'namespace'      => ['val' => 'bit-paypal-__$contentId__'],
        ];
        $configs['stripe'] = [
            'payIntegID'     => ['path' => 'payIntegID'],
            'locale'         => ['path' => 'config->options->locale', 'val' => 'en'],
            'amountType'     => ['path' => 'config->amountType', 'val' => 'fixed'],
            'fieldKey'       => ['var' => 'fieldKey'],
            'contentId'      => ['var' => 'contentId'],
            'publishableKey' => ['path' => 'publishableKey'],
        ];
        $configs['mollie'] = [
            'payIntegID'     => ['path' => 'payIntegID'],
            'locale'         => ['path' => 'config->locale', 'val' => 'en'],
            'amountType'     => ['path' => 'config->amountType', 'val' => 'fixed'],
            'fieldKey'       => ['var' => 'fieldKey'],
            'contentId'      => ['var' => 'contentId'],
            'apiKey'         => ['path' => 'apiKey'],
            'payment_method' => ['path' => 'config->payment_method', 'val' => ['creditcard']],
            'description'    => ['path' => 'config->description', 'val' => ''],
            'amount'         => ['path' => 'config->amount', 'val' => 0],
            'currency'       => ['path' => 'config->currency', 'val' => 'EUR'],
        ];

        // Pro field configs
        $configs['advanced-file-up'] = [
            'fieldKey'           => ['var' => 'fieldKey'],
            'formID'             => ['var' => 'formId'],
            'configSetting'      => ['path' => 'config'],
            'ajaxURL'            => ['val' => admin_url('admin-ajax.php')],
            'nonce'              => ['val' => wp_create_nonce('bitforms_save')],
            'uploadFileToServer' => ['val' => 1],
            'fieldName'          => ['path' => 'fieldName'],
            'contentId'          => ['var' => 'contentId'],
            // Default for the field's Max Files Exceeded label; {max} is filled in by the browser.
            'labelMaxFilesExceeded' => ['val' => __('Maximum number of files allowed: {max}', 'bitformpro')],
        ];
        $configs['advanced-datetime'] = [
            'fieldKey'      => ['var' => 'fieldKey'],
            'formID'        => ['var' => 'formId'],
            'configSetting' => ['path' => 'config'],
            'fieldName'     => ['path' => 'fieldName'],
            'contentId'     => ['var' => 'contentId'],
        ];
        $configs['razorpay'] = [
            'fieldKey'       => ['var' => 'fieldKey'],
            'options'        => ['path' => 'options'],
            'payIntegID'     => ['path' => 'payIntegID'],
            'payType'        => ['path' => 'payType', 'val' => ''],
            'clientId'       => ['path' => 'clientId'],
            'contentId'      => ['var' => 'contentId'],
            'includeOrderId' => ['path' => 'includeOrderId', 'val' => false],
            'newOrderId'     => ['path' => 'newOrderId', 'val' => false],
            'orderIdFld'     => ['path' => 'orderIdFld', 'val' => ''],
            'formID'         => ['var' => 'formId'],
        ];

        $configs['signature'] = [
            'fieldKey'        => ['var' => 'fieldKey'],
            'contentId'       => ['var' => 'contentId'],
            // Same pen width the builder seeds for a new Signature field.
            'maxWidth'        => ['path' => 'config->maxWidth', 'val' => 2.5],
            'penColor'        => ['path' => 'config->penColor', 'val' => '#000000'],
            'backgroundColor' => ['path' => 'config->backgroundColor', 'val' => '#ffffff'],
            'imgTyp'          => ['path' => 'config->imgTyp', 'val' => 'image/png'],
            'assetsURL'       => ['val' => BITFORMS_ROOT_URI . '/static/signature/'],
        ];

        $configs['email-otp'] = [
            'fieldKey'          => ['var' => 'fieldKey'],
            'formID'            => ['var' => 'formId'],
            'contentId'         => ['var' => 'contentId'],
            'otpLength'         => ['path' => 'config->otpLength',      'val' => 6],
            'resendDelay'       => ['path' => 'config->resendDelay',    'val' => 60],
            'expiryDelay'       => ['path' => 'config->expiryDelay',    'val' => 15],
            'maxAttempts'       => ['path' => 'config->maxAttempts',    'val' => 5],
            'sendBtnTxt'        => ['path' => 'config->sendBtnTxt',     'val' => 'Send OTP'],
            'resendBtnTxt'      => ['path' => 'config->resendBtnTxt',   'val' => 'Resend OTP'],
            'verifyBtnTxt'      => ['path' => 'config->verifyBtnTxt',   'val' => 'Verify OTP'],
            'waitTxt'           => ['path' => 'config->waitTxt',        'val' => 'Wait ${bf_resend_countdown}s to Resend'],
            'receiverEmailType' => ['path' => 'config->receiverEmailType', 'val' => 'dynamic'],
            'receiverEmail'     => ['path' => 'config->receiverEmail',  'val' => ''],
            'receiverEmailFld'  => ['path' => 'config->receiverEmailFld', 'val' => ''],
            'sendOnValidate'    => ['path' => 'config->sendOnValidate',   'val' => false],
            'autoVerifyOnInput' => ['path' => 'config->autoVerifyOnInput', 'val' => false],
            'ajaxUrl'           => ['val' => admin_url('admin-ajax.php')],
        ];

        return $configs;
    }

    public static function filePondPluginsList($defaultList = [])
    {
        // if (!LicenseHelper::hasValidLicense()) {
        //     return $defaultList;
        // }

        return ScriptFilePriorityManager::filePondPluginsList();
    }

    public static function repeaterRepeatedRows($repeatedRow, $field): string
    {
        $repeatedRow = is_string($repeatedRow) ? $repeatedRow : '';
        $defaultRow = isset($field->defaultRow) ? intval($field->defaultRow) : 1;
        // A Maximum Row of 0 means no limit, as in the runtime; it must not cut the rows to one.
        if (isset($field->maxRow) && intval($field->maxRow) > 0 && $defaultRow > intval($field->maxRow)) {
            $defaultRow = intval($field->maxRow);
        }
        if (isset($field->minRow) && $defaultRow < intval($field->minRow)) {
            $defaultRow = intval($field->minRow);
        }
        $singleRow = $repeatedRow;
        while ($defaultRow > 1) {
            $repeatedRow .= $singleRow;
            $defaultRow--;
        }
        return $repeatedRow;
    }
}
