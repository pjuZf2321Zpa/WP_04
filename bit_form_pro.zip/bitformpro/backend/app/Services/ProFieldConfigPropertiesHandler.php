<?php

namespace BitApps\BitFormPro\Services;

use BitApps\BitFormPro\Helpers\LicenseHelper;
use BitApps\BitForm\Views\FieldHelpers;
use BitApps\BitFormPro\Compat\ReleasedName;

class ProFieldConfigPropertiesHandler
{
    public static function register(): void
    {
        // Field rendering Pro features
        add_filter('bitform_field_max_attr', [ReleasedName::of(self::class), 'fieldMaxAttr'], 10, 2);
        add_filter('bitform_field_min_attr', [ReleasedName::of(self::class), 'fieldMinAttr'], 10, 2);
        add_filter('bitform_field_inputmode_attr', [ReleasedName::of(self::class), 'fieldInputMode'], 10, 2);
        add_filter('bitform_field_suggestions_datalist', [ReleasedName::of(self::class), 'suggestionsDatalist'], 10, 4);
        add_filter('bitform_file_max_size_section', [ReleasedName::of(self::class), 'fileMaxSizeSection'], 10, 3);

        // Dropdown Pro features
        add_filter('bitform_dropdown_selected_opt_image', [ReleasedName::of(self::class), 'dropdownSelectedImage'], 10, 3);
        add_filter('bitform_dropdown_allow_custom_option', [ReleasedName::of(self::class), 'dropdownCustomOption'], 10, 2);
    }


    public static function fieldMinAttr($attr, $field)
    {
        if (is_object($field) && property_exists($field, 'mn') && '' !== $field->mn) {
            $escapedValue = esc_attr($field->mn);
            return "min='{$escapedValue}'";
        }
        return $attr;
    }

    public static function fieldMaxAttr($attr, $field)
    {
        if (is_object($field) && property_exists($field, 'mx') && '' !== $field->mx) {
            $escapedValue = esc_attr($field->mx);
            return "max='{$escapedValue}'";
        }
        return $attr;
    }

    public static function fieldInputMode($attr, $field)
    {
        if (is_object($field) && property_exists($field, 'inputMode') && '' !== $field->inputMode) {
            $escapedValue = esc_attr($field->inputMode);
            return "inputmode='{$escapedValue}'";
        }
        return $attr;
    }

    public static function suggestionsDatalist($datalist, $field, $rowID, $contentCount)
    {
        if (is_object($field) && property_exists($field, 'suggestions') && count($field->suggestions) > 0) {
            $suggDataList = "<datalist id='{$rowID}-{$contentCount}-datalist'>";
            foreach ($field->suggestions as $suggestion) {
                $escapedValue = esc_attr((isset($suggestion->val) && !empty($suggestion->val)) ? $suggestion->val : $suggestion->lbl);
                $escapedLabel = esc_html($suggestion->lbl);
                $suggDataList .= "<option value='{$escapedValue}'>{$escapedLabel}</option>";
            }
            $suggDataList .= '</datalist>';

            return $suggDataList;
        }

        return $datalist;
    }


    public static function fileMaxSizeSection($html, $field, $fh)
    {
        // if (!LicenseHelper::hasValidLicense()) {
        //     return $html;
        // }
        if (
            !$fh->property_exists_nested($field, 'config->allowMaxSize', true)
            || !$fh->property_exists_nested($field, 'config->showMaxSize', true)
            || !$fh->property_exists_nested($field, 'config->maxSize')
            || 0 === $field->config->maxSize
        ) {
            return $html;
        }
        $maxSize = $field->config->maxSize;
        $sizeUnit = isset($field->config->sizeUnit) ? $field->config->sizeUnit : '';
        $maxSizeLbl = $fh->property_exists_nested($field, 'config->maxSizeLabel', '', 1)
            ? $field->config->maxSizeLabel
            : "(Max {$maxSize} {$sizeUnit})";
        return sprintf(
            '<small
              %1$s
              class="%2$s %3$s"
            >
              %4$s
            </small>',
            $fh->getCustomAttributes('max-size-lbl'),
            $fh->getAtomicCls('max-size-lbl'),
            $fh->getCustomClasses('max-size-lbl'),
            $fh->esc_html($maxSizeLbl),
        );
    }

    public static function dropdownSelectedImage($default, $field, $fh)
    {
        if (!$fh->property_exists_nested($field, 'config->selectedOptImage', true)) {
            return $default;
        }
        $img = htmlentities("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'/>");
        return sprintf(
            '<img
              %1$s
              class="%2$s placeholder-img %3$s"
              aria-hidden="true"
              alt="selected option icon"
              src="%4$s"
            >',
            $fh->getCustomAttributes('selected-opt-img'),
            $fh->getAtomicCls('selected-opt-img'),
            $fh->getCustomClasses('selected-opt-img'),
            $img,
        );
    }

    public static function dropdownCustomOption($default, $field)
    {
        return isset($field->config->allowCustomOption) ? (bool) $field->config->allowCustomOption : $default;
    }
}
