<?php

namespace BitApps\BitFormPro\Services\Messages;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Helpers\IpTool;
use BitApps\BitFormPro\Database\Migrations\DB;
use BitApps\BitFormPro\Model\PdfTemplateModel;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

final class PdfTemplateHandler
{
    private static $_formID;
    private static $_pdfTemplateModel;
    private $_user_details;

    public function __construct($formID)
    {
        static::$_formID = $formID;
        static::$_pdfTemplateModel = new PdfTemplateModel();
        $this->_user_details = (new IpTool())->getUserDetail();
    }

    public function getAll($templateID = null, $userID = null)
    {
        $condition = [
            'form_id' => static::$_formID,
        ];
        if (!is_null($templateID)) {
            $condition = array_merge($condition, ['id' => $templateID]);
        }
        if (!is_null($userID)) {
            $condition = array_merge($condition, ['user_id' => $userID]);
        }
        // `pdf_config` is added by a migration gated behind an admin request; on a frontend/cron
        // request that runs before it, selecting the column would fail the whole query (PDF then
        // silently missing). Only select it when present (self-healing the schema first).
        $columns = ['id', 'title', 'setting', 'body'];
        if (self::hasPdfConfigColumn()) {
            $columns[] = 'pdf_config';
        }
        return  static::$_pdfTemplateModel->get(
            $columns,
            $condition,
        );
    }

    /**
     * Whether the `pdf_config` column exists. Runs the Pro schema migration once if it does not,
     * so the read path does not depend on an admin having visited first.
     */
    private static function hasPdfConfigColumn()
    {
        static $exists = null;
        if (null !== $exists) {
            return $exists;
        }
        // Fast path (steady state): the schema-version option is autoloaded (in-memory, no query).
        // `pdf_config` ships in db version 3.0, so once migrated the column is guaranteed present —
        // skip the metadata query entirely on healthy installs.
        if (version_compare(get_option('bitformspro_db_version', '0'), '3.2', '>=')) {
            return $exists = true;
        }
        // Slow path (only during the pre-migration window): confirm the column and self-heal.
        global $wpdb;
        $table = $wpdb->prefix . 'bitforms_pdf_template';
        // Table/column name interpolation only — SHOW COLUMNS cannot be parameterized via prepare().
        $check = static function () use ($wpdb, $table) {
            return null !== $wpdb->get_var("SHOW COLUMNS FROM `{$table}` LIKE 'pdf_config'");
        };
        if ($check()) {
            return $exists = true;
        }
        DB::migrate();
        return $exists = $check();
    }

    public function getById($templateID)
    {
        return $this->getAll($templateID);
    }

    public function save($templateDetail)
    {
        return static::$_pdfTemplateModel->insert(
            [
                'title'         => $templateDetail->title,
                'setting'       => $this->encodeJsonValue($templateDetail->setting ?? ''),
                'pdf_config'    => $this->encodeJsonValue($templateDetail->pdf_config ?? null, self::defaultPdfConfig()),
                'body'          => $templateDetail->body,
                'form_id'       => static::$_formID,
                'user_id'       => $this->_user_details['id'],
                'user_ip'       => $this->_user_details['ip'],
                'created_at'    => $this->_user_details['time'],
                'updated_at'    => $this->_user_details['time'],
            ],
        );
    }

    public function update($templateDetail)
    {
        return static::$_pdfTemplateModel->update(
            [
                'title'         => $templateDetail->title,
                'setting'       => $this->encodeJsonValue($templateDetail->setting ?? ''),
                'pdf_config'    => $this->encodeJsonValue($templateDetail->pdf_config ?? null, self::defaultPdfConfig()),
                'body'          => $templateDetail->body,
                'form_id'       => static::$_formID,
                'user_id'       => $this->_user_details['id'],
                'user_ip'       => $this->_user_details['ip'],
                'updated_at'    => $this->_user_details['time'],
            ],
            [
                'id' => $templateDetail->id,
            ],
        );
    }

    public function saveOrUpdate($templateDetail)
    {
        if (isset($templateDetail->id) && !empty($templateDetail->id)) {
            return $this->update($templateDetail);
        }
        return $this->save($templateDetail);
    }

    public function delete($templateID)
    {
        return static::$_pdfTemplateModel->delete(
            [
                'id'      => $templateID,
                'form_id' => static::$_formID,
            ],
        );
    }

    public function duplicateTemplate($templateID)
    {
        $templateDetail = static::$_pdfTemplateModel->get(
            [
                'id'      => $templateID,
                'form_id' => static::$_formID,
            ],
        );

        if (is_wp_error($templateDetail) || empty($templateDetail)) {
            return $templateDetail;
        }

        $title = empty($templateDetail[0]->title)
                ? "Duplicate of Template #{$templateID}"
                : "Duplicate of {$templateDetail[0]->title}";

        $templateDetail[0]->title = $title;
        return $this->save($templateDetail);
    }

    public function duplicateAllTempInAForm($oldFromId)
    {
        $allCols = ['title', 'setting', 'pdf_config', 'body', 'form_id', 'user_id', 'user_ip', 'created_at', 'updated_at'];
        $dupData = [
            'title',
            'setting',
            'pdf_config',
            'body',
            static::$_formID,
            $this->_user_details['id'],
            $this->_user_details['ip'],
            $this->_user_details['time'],
            $this->_user_details['time'],
        ];
        return static::$_pdfTemplateModel->duplicate(
            $allCols,
            $dupData,
            ['form_id' => $oldFromId],
        );
    }

    public static function defaultPdfConfig()
    {
        return [
            'status' => 1,
            'header' => '',
            'footer' => '',
        ];
    }

    /**
     * Coerce a raw `setting` column value to an object.
     *
     * Templates saved without settings store `""`; legacy rows may hold NULL or malformed
     * JSON. Callers assign properties on the decoded value (pdfFileName, header, footer),
     * so anything non-object must become an empty object or PHP 8 fatals.
     *
     * @param mixed $rawSetting raw `setting` column value (JSON string/object/array/null)
     *
     * @return object
     */
    public static function normalizeSetting($rawSetting)
    {
        if (is_string($rawSetting)) {
            $decoded = JSON::decode($rawSetting);
            $rawSetting = JSON_ERROR_NONE === json_last_error() ? $decoded : null;
        }

        if (is_array($rawSetting)) {
            $rawSetting = (object) $rawSetting;
        }

        return is_object($rawSetting) ? $rawSetting : (object) [];
    }

    public static function normalizePdfConfig($pdfConfig)
    {
        if (is_string($pdfConfig)) {
            $decodedConfig = JSON::decode($pdfConfig);
            $pdfConfig = JSON_ERROR_NONE === json_last_error() && is_object($decodedConfig) ? $decodedConfig : (object) [];
        }

        if (is_array($pdfConfig)) {
            $pdfConfig = (object) $pdfConfig;
        }

        if (!is_object($pdfConfig)) {
            $pdfConfig = (object) [];
        }

        $defaultConfig = (object) self::defaultPdfConfig();

        return (object) array_merge(
            (array) $defaultConfig,
            (array) $pdfConfig,
            [
                'status' => isset($pdfConfig->status) && 0 === (int) $pdfConfig->status ? 0 : 1,
                // header/footer are HTML strings (TinyMCE); legacy rows saved `(object)[]` — they never
                // held content, so anything non-string normalizes to ''.
                'header' => isset($pdfConfig->header) && is_string($pdfConfig->header) ? $pdfConfig->header : '',
                'footer' => isset($pdfConfig->footer) && is_string($pdfConfig->footer) ? $pdfConfig->footer : '',
            ],
        );
    }

    /**
     * Resolve a template's header/footer HTML for PDF generation: normalizes `pdf_config`,
     * then runs each non-empty part through the same pipeline as the PDF body
     * (smart-tag replacement + image/href path rewriting).
     *
     * @param mixed  $rawPdfConfig raw `pdf_config` column value (JSON string/object/null)
     * @param array  $fieldValue   entry field values for smart-tag replacement
     * @param int    $formID
     * @param string $serverPath   entry files server path (for <img src>)
     * @param string $webPath      entry files web path (for <a href>)
     *
     * @return array ['header' => string, 'footer' => string]
     */
    public static function resolveHeaderFooter($rawPdfConfig, $fieldValue, $formID, $serverPath, $webPath)
    {
        $pdfConfig = self::normalizePdfConfig($rawPdfConfig);
        $resolved = ['header' => '', 'footer' => ''];
        foreach ($resolved as $part => $_) {
            $html = $pdfConfig->{$part};
            if ('' === trim($html)) {
                continue;
            }
            $html = FieldValueHandler::replaceFieldWithValue($html, $fieldValue, $formID);
            $html = FieldValueHandler::changeImagePathInHTMLString($html, $serverPath);
            $html = FieldValueHandler::changeHrefPathInHTMLString($html, $webPath);
            $resolved[$part] = $html;
        }
        return $resolved;
    }

    public static function isEnabled($pdfConfig)
    {
        return 1 === self::normalizePdfConfig($pdfConfig)->status;
    }

    private function encodeJsonValue($value, $default = null)
    {
        if (is_string($value) && '' !== $value) {
            JSON::decode($value);
            if (JSON_ERROR_NONE === json_last_error()) {
                return $value;
            }
        }

        if ((is_null($value) || '' === $value) && !is_null($default)) {
            $value = $default;
        }

        // Store an object, never `""`: readers (PdfMailHandler, DownloadFile) assign
        // properties on the decoded value and fatal on a string.
        if (!is_array($value) && !is_object($value)) {
            $value = (object) [];
        }

        return JSON::encode($value);
    }
}
