<?php

namespace BitApps\BitFormPro\Services\Messages;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Services\Admin\Helpers;
use BitApps\BitForm\Helpers\ApiResponse;
use BitApps\BitForm\Helpers\FieldValueHandler;
use BitApps\BitForm\Helpers\Log;
use BitApps\BitFormPro\Services\Admin\AppSetting\Pdf;
use BitApps\BitFormPro\Helpers\Utility;

/**
 * Generates the PDF attachment(s) for an outgoing notification email.
 *
 * Hooked to the `bitform_generate_pdf_attachment` filter emitted by the free plugin's
 * MailNotifier. PDF is a Pro-only feature, so all generation logic lives here. Returns
 * the generated file paths as an array (one per configured template); the caller
 * attaches them and deletes the temp files after the mail is sent.
 *
 * Version-skew note: the free caller also accepts a plain string path, because Pro
 * versions that predate multi-PDF return a single path from this same filter.
 */
final class PdfMailHandler
{
    /**
     * Generates one PDF per configured template (multi-select `pdfIds`, falling back to
     * the legacy single `pdfId`).
     *
     * @param array|string $default       filter default
     * @param object       $notifyDetails notification config (may carry pdfIds and/or pdfId)
     * @param array        $entryDetails  ['formId' => int, 'entryId' => int, 'fieldValues' => array]
     * @param string       $logId
     *
     * @return array|string generated PDF paths, or $default when nothing was generated
     */
    public function generateAttachment($default, $notifyDetails, $entryDetails, $logId = '')
    {
        $templateIds = $this->resolveTemplateIds($notifyDetails);
        if (empty($templateIds)) {
            return $default;
        }

        $generatedPaths = [];
        $usedFileNames = [];
        foreach ($templateIds as $pdfTemplateID) {
            $generatedPdf = $this->generateForTemplate($pdfTemplateID, $notifyDetails, $entryDetails, $logId, $usedFileNames);
            if (!empty($generatedPdf)) {
                $generatedPaths[] = $generatedPdf;
            }
        }

        return empty($generatedPaths) ? $default : $generatedPaths;
    }

    /**
     * Resolve the configured PDF template ids from notifyDetails. Prefers the multi-select
     * `pdfIds` (array of '{"id":"N"}' JSON strings); falls back to the legacy single `pdfId`.
     * Unsaved-template placeholders ('{"index":"N"}' that missed the save-time remap) decode
     * to no id and are skipped.
     *
     * @param object $notifyDetails
     *
     * @return array unique template ids, in configured order
     */
    private function resolveTemplateIds($notifyDetails)
    {
        $rawIds = [];
        if (!empty($notifyDetails->pdfIds) && is_array($notifyDetails->pdfIds)) {
            $rawIds = $notifyDetails->pdfIds;
        } elseif (!empty($notifyDetails->pdfId) && is_string($notifyDetails->pdfId)) {
            $rawIds = [$notifyDetails->pdfId];
        }

        $templateIds = [];
        foreach ($rawIds as $rawId) {
            $templateID = null;
            if (is_string($rawId)) {
                $templateID = Utility::jsonObj($rawId)->id ?? null;
            } elseif (is_object($rawId)) {
                $templateID = $rawId->id ?? null;
            }
            if (empty($templateID)) {
                Log::debug_log([
                    'status'  => 'error',
                    'code'    => 'pdf_template_id_unresolved',
                    'message' => 'Skipping PDF attachment item with unresolved template id',
                    'inputDetails' => ['rawId' => $rawId],
                ]);
                continue;
            }
            if (!in_array($templateID, $templateIds, false)) {
                $templateIds[] = $templateID;
            }
        }

        return $templateIds;
    }

    /**
     * Generate the PDF for a single template. A failure here must never kill the email or
     * the other templates' PDFs, so everything is guarded and null is returned on failure.
     *
     * @param int|string $pdfTemplateID
     * @param object     $notifyDetails
     * @param array      $entryDetails  ['formId' => int, 'entryId' => int, 'fieldValues' => array]
     * @param string     $logId
     * @param array      $usedFileNames file names already taken in this batch (collision guard)
     *
     * @return string|null generated PDF path, or null when nothing was generated
     */
    private function generateForTemplate($pdfTemplateID, $notifyDetails, $entryDetails, $logId, array &$usedFileNames)
    {
        try {
            $formID     = $entryDetails['formId'];
            $entryID    = $entryDetails['entryId'];
            $fieldValue = $entryDetails['fieldValues'];

            $apiResponse = new ApiResponse();

            $pdfTemplateHandler = new PdfTemplateHandler($formID);

            $pdfTemplate = $pdfTemplateHandler->getById($pdfTemplateID);
            $pdfRow = Utility::firstRow($pdfTemplate);

            // Free 3.4 logs an `action_key` per row so the entry timeline can
            // say *which* PDF ran. Without this every template's rows are
            // indistinguishable — the exact problem the envelope was added to
            // fix — so the id goes in before the first log write, and the name
            // follows once the row has been read.
            $entryDetails['action'] = [
                'kind' => 'pdf',
                'id'   => $pdfTemplateID,
            ];
            if ($pdfRow) {
                $entryDetails['action']['name'] = $pdfRow->title ?? '';
            }

            // Bail out if the template lookup failed (WP_Error) or returned no row.
            // Without this guard the PDF setting decode fatals and the whole email is lost.
            // An empty `setting` is not a bail-out reason: normalizeSetting() supplies
            // an empty object and the defaults apply.
            if (!$pdfRow) {
                $apiResponse->apiResponse($logId, '', ['type' => 'record', 'type_name' => 'pdf'], 'errors', 'PDF template not found, skipping PDF attachment.', $entryDetails);
                Log::debug_log([
                    'status'          => 'error',
                    'code'            => 'pdf_template_not_found',
                    'message'         => 'PDF template not found, skipping PDF attachment',
                    'inputDetails'    => [
                        'notifyDetails' => $notifyDetails,
                        'formID'        => $formID,
                        'entryID'       => $entryID,
                        'pdfTemplateID' => $pdfTemplateID,
                    ],
                    'responseDetails' => is_wp_error($pdfTemplate) ? $pdfTemplate->get_error_message() : 'empty result',
                ]);

                return null;
            }

            if (!PdfTemplateHandler::isEnabled($pdfRow->pdf_config ?? null)) {
                $apiResponse->apiResponse($logId, '', ['type' => 'record', 'type_name' => 'pdf'], 'success', 'PDF template disabled, skipping PDF attachment.', $entryDetails);
                Log::debug_log([
                    'status'          => 'success',
                    'code'            => 'pdf_template_disabled',
                    'message'         => 'PDF template disabled, skipping PDF attachment',
                    'inputDetails'    => [
                        'notifyDetails' => $notifyDetails,
                        'formID'        => $formID,
                        'entryID'       => $entryID,
                        'pdfTemplateID' => $pdfTemplateID,
                    ],
                ]);

                return null;
            }

            // Rows saved without settings hold `""` or legacy NULL/malformed JSON; a raw
            // decode fatals on the property reads below and kills the whole attachment.
            $pdfSetting = PdfTemplateHandler::normalizeSetting($pdfRow->setting ?? '');

            $path = BITFORMS_CONTENT_DIR . DIRECTORY_SEPARATOR . 'pdf';

            if (!is_dir($path)) {
                wp_mkdir_p($path);
            }

            $serverPath = Helpers::getFullPathWithEncryptedEntryId($formID, $entryID);
            $webPath = Helpers::getWebPathWithEncryptedEntryId($formID, $entryID);

            if (isset($pdfSetting->password)) {
                if (isset($pdfSetting->password->static) && $pdfSetting->password->static && !empty($pdfSetting->password->pass)) {
                    $pass = FieldValueHandler::replaceFieldWithValue($pdfSetting->password->pass, $fieldValue);
                    $pdfSetting->password->pass = $pass;
                } elseif (isset($pdfSetting->password->dynamic)) {
                    $pass = Helpers::PDFPassHash($entryID);
                    $pdfSetting->password->pass = $pass;
                }
            }
            if (isset($pdfSetting->pdfFileName) && !empty($pdfSetting->pdfFileName)) {
                $pdfSetting->pdfFileName = FieldValueHandler::replaceFieldWithValue($pdfSetting->pdfFileName, $fieldValue);
                // allow developers to modify PDF filename
                $pdfSetting->pdfFileName = apply_filters(
                    'bitform_filter_pdf_filename',
                    $pdfSetting->pdfFileName,
                    [
                        'form_id'      => $formID,
                        'entry_id'     => $entryID,
                        'field_values' => $fieldValue,
                        'pdf_setting'  => $pdfSetting,
                        'template'     => $pdfRow,
                    ],
                );
            }
            // Multiple templates in one batch may resolve to the same file name (identical
            // explicit names, or the generator's shared bit-form-{entryId} default) — the later
            // PDF would overwrite the earlier one. Suffix with the template id on collision.
            $resolvedFileName = !empty($pdfSetting->pdfFileName) ? $pdfSetting->pdfFileName : 'bit-form-' . $entryID;
            // Smart-tag values (and the filename filter) can inject path separators — e.g. a
            // date field rendered as 01/01/2023 — which break the output path in mpdf.
            $resolvedFileName = preg_replace('/[\/\\\\:*?"<>|]/', '-', $resolvedFileName);
            if (in_array($resolvedFileName, $usedFileNames, true)) {
                $resolvedFileName .= '-' . $pdfTemplateID;
            }
            $usedFileNames[] = $resolvedFileName;
            $pdfSetting->pdfFileName = $resolvedFileName;

            $fieldValue['entry_id'] = $entryID;

            $pdfBody = FieldValueHandler::replaceFieldWithValue($pdfRow->body ?? '', $fieldValue, $formID);
            $pdfBody = FieldValueHandler::changeImagePathInHTMLString($pdfBody, $serverPath);
            $pdfBody = FieldValueHandler::changeHrefPathInHTMLString($pdfBody, $webPath);  // replace anchor tag href with constructed weburl

            // allow developers to modify PDF body
            $pdfBody = apply_filters(
                'bitform_filter_pdf_body',
                $pdfBody,
                [
                    'form_id'      => $formID,
                    'entry_id'     => $entryID,
                    'field_values' => $fieldValue,
                    'pdf_setting'  => $pdfSetting,
                    'template'     => $pdfRow,
                ],
            );

            $headerFooter = PdfTemplateHandler::resolveHeaderFooter($pdfRow->pdf_config ?? null, $fieldValue, $formID, $serverPath, $webPath);
            $pdfSetting->header = $headerFooter['header'];
            $pdfSetting->footer = $headerFooter['footer'];

            $generatedPdf = Pdf::getInstance()->generator($pdfSetting, $pdfBody, $path, $entryID, 'F');

            if (!is_wp_error($generatedPdf) && file_exists($generatedPdf)) {
                $apiResponse->apiResponse($logId, '', ['type' =>  'record', 'type_name' => 'pdf'], 'success', 'PDF successfully generated.', $entryDetails);
                Log::debug_log([
                    'status'          => 'success',
                    'code'            => 'pdf_generated',
                    'message'         => 'PDF successfully generated',
                    'inputDetails'    => [
                        'notifyDetails' => $notifyDetails,
                        'formID'        => $formID,
                        'entryID'       => $entryID,
                        'pdfTemplateID' => $pdfTemplateID,
                        'logId'         => $logId,
                    ],
                    'responseDetails' => $generatedPdf,
                ]);

                return $generatedPdf;
            }

            $apiResponse->apiResponse($logId, '', ['type' =>  'record', 'type_name' => 'pdf'], 'errors', 'Error in generating PDF.', $entryDetails);
            Log::debug_log([
                'status'          => 'error',
                'code'            => 'pdf_generation_error',
                'message'         => 'Error in generating PDF',
                'inputDetails'    => [
                    'notifyDetails' => $notifyDetails,
                    'formID'        => $formID,
                    'entryID'       => $entryID,
                    'pdfTemplateID' => $pdfTemplateID,
                    'logId'         => $logId,
                ],
                'responseDetails' => is_wp_error($generatedPdf) ? $generatedPdf->get_error_message() : 'unknown error',
            ]);

            return null;
        } catch (\Throwable $e) {
            Log::debug_log([
                'status'          => 'error',
                'code'            => 'pdf_generation_exception',
                'message'         => 'Unexpected error while generating PDF attachment',
                'inputDetails'    => [
                    'pdfTemplateID' => $pdfTemplateID,
                    'logId'         => $logId,
                ],
                'responseDetails' => $e->getMessage(),
            ]);

            return null;
        }
    }
}
