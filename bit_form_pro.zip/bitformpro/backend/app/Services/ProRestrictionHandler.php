<?php

namespace BitApps\BitFormPro\Services;

use BitApps\BitFormPro\Helpers\EntryLimitHelper;
use BitApps\BitFormPro\Helpers\LicenseHelper;
use BitApps\BitFormPro\Compat\ReleasedName;
use BitApps\BitForm\Helpers\DateTimeHelper;
use BitApps\BitForm\Services\Form\FormManager;

class ProRestrictionHandler
{
    public static function register()
    {
        // New (wp.org-friendly) hooks: free plugin delegates Pro-only logic to add-ons.
        add_filter('bitform_submission_restriction', [ReleasedName::of(self::class), 'handleFormRestriction'], 10, 7);
        add_filter('bitform_check_honeypot', [ReleasedName::of(self::class), 'handleHoneypot'], 10, 3);

        add_filter('bitform_is_honeypot_active', [ReleasedName::of(self::class), 'isHoneypotActive'], 10, 3);


    }

    public static function isHoneypotActive($result, $formId, $formContents)
    {
        // Callers may pass null form contents; fetch by form id so the check still works.
        if (!is_object($formContents) && !empty($formId) && class_exists('\BitApps\BitForm\Services\Form\FormManager')) {
            $formContents = FormManager::getInstance($formId)->getFormContent();
        }
        $enabled = empty($formContents->additional->enabled) ? null : $formContents->additional->enabled;
        return !empty($enabled->honeypot);
    }

    public static function handleFormRestriction($result, $key, $formId, $enabled, $settings, $ipAddress = null, $userId = null)
    {
        switch ($key) {
            case 'entry_limit':
            case 'entry_limit_by_user':
                return self::checkEntryLimit($formId, $enabled, $settings, $ipAddress, $userId);
            case 'blocked_ip':
                return self::checkBlockedIp($settings, $ipAddress);
            case 'private_ip':
                return self::checkPrivateIp($settings, $ipAddress);
            case 'restrict_form':
                return self::checkRestrictForm($settings);
        }

        return $result;
    }

    public static function handleHoneypot($result, $formId, $postData)
    {
        if (!self::isHoneypotActive($result, $formId, null)) {
            return $result;
        }
        if (empty($postData) || !is_array($postData)) {
            return false;
        }

        $token = isset($postData['b_h_t']) ? sanitize_text_field(wp_unslash($postData['b_h_t'])) : '';
        if (empty($token)) {
            return false;
        }

        $pattern = '/^([a-zA-Z0-9]*_[a-zA-Z0-9]*){4}$/';
        $decryptedToken = base64_decode(base64_decode($token));
        preg_match($pattern, $decryptedToken, $validToken);

        if ($validToken) {
            if (isset($postData[$token]) && empty($postData[$token])) {
                return false;
            }
            return true;
        }

        return true;
    }

    private static function checkEntryLimit($formId, $enabled, $settings, $ipAddress, $userId)
    {
        if (empty($settings)) {
            return null;
        }

        // Backward-compatible fallback for older callers that may still embed enabled flags inside settings.
        if (empty($enabled) && !empty($settings->enabled)) {
            $enabled = $settings->enabled;
        }

        if (empty($enabled)) {
            return null;
        }

        $entryLimitHelper = new EntryLimitHelper($formId, $settings, $enabled);
        $messages = $entryLimitHelper->checkAllLimits($ipAddress, $userId);

        return !empty($messages) ? $messages[0] : null;
    }

    private static function checkBlockedIp($settings, $ipAddress)
    {
        if (empty($settings) || empty($settings->blocked_ip) || !is_iterable($settings->blocked_ip)) {
            return null;
        }

        foreach ($settings->blocked_ip as $ipDetails) {
            if (is_object($ipDetails) && !empty($ipDetails->status) && !empty($ipDetails->ip) && $ipDetails->ip === $ipAddress) {
                return self::blockedIpMessage($ipAddress);
            }
        }

        return null;
    }

    private static function checkPrivateIp($settings, $ipAddress)
    {
        if (empty($settings) || empty($settings->private_ip) || !is_iterable($settings->private_ip)) {
            return null;
        }

        $isIpWhiteListed = false;

        foreach ($settings->private_ip as $ipDetails) {
            if (is_object($ipDetails) && !empty($ipDetails->status) && !empty($ipDetails->ip) && $ipDetails->ip === $ipAddress) {
                $isIpWhiteListed = true;
                break;
            }
        }

        if (!$isIpWhiteListed) {
            return self::blockedIpMessage($ipAddress);
        }

        return null;
    }

    /** IP may be unvalidated on older Free builds, so escape it. */
    private static function blockedIpMessage($ipAddress)
    {
        return sprintf(
            __('Sorry!! Your IP address is %s, Blocked from submitting the form', 'bitformpro'),
            esc_html($ipAddress),
        );
    }

    private static function checkRestrictForm($settings)
    {
        if (empty($settings) || empty($settings->restrict_form)) {
            return null;
        }

        $restriction = $settings->restrict_form;

        $day = empty($restriction->day) ? null : $restriction->day;
        $date = empty($restriction->date) ? null : $restriction->date;
        $time = empty($restriction->time) ? null : $restriction->time;

        $isdayOk = $isdateOk = $istimeOk = true;
        $dayNotOkMsg = $dateNotOkMsg = $timeNotOkMsg = '';

        $dateTimeHelper = new DateTimeHelper();
        $hasCustomDateRange = !empty($date->from) || !empty($date->to);

        if (!empty($day) && is_array($day)) {
            $allowedDays = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
            $selectedWeekDays = array_intersect($allowedDays, $day);

            if (!empty($selectedWeekDays) && !in_array('Everyday', $day, true) && !in_array($dateTimeHelper->getDay('full-name'), $day, true)) {
                $isdayOk = false;
                $dayNotOkMsg = sprintf(__('in %s', 'bitformpro'), implode(', ', $day));
            }
        }

        // Range applies only with "Custom" (or legacy settings without days); otherwise it's hidden/stale.
        $dateRangeApplies = is_array($day) ? in_array('Custom', $day, true) : $hasCustomDateRange;
        if ($dateRangeApplies) {
            $startDate = (!is_object($date) || empty($date->from) || !is_string($date->from)) ? '' : $date->from;
            $endDate = (!is_object($date) || empty($date->to) || !is_string($date->to)) ? '' : $date->to;

            // Only enforce when a range is actually set; missing bound = open-ended.
            if ('' !== $startDate || '' !== $endDate) {
                $startYmd = self::toComparableDate($startDate, $dateTimeHelper, '0000-00-00');
                $endYmd = self::toComparableDate($endDate, $dateTimeHelper, '9999-12-31');
                $currentYmd = $dateTimeHelper->getDate(null, null, null, 'Y-m-d');

                if (!($currentYmd >= $startYmd && $currentYmd <= $endYmd)) {
                    $isdateOk = false;
                    $dateNotOkMsg = sprintf(__('within %1$s to %2$s', 'bitformpro'), $startDate ?: $startYmd, $endDate ?: $endYmd);
                }
            }
        }

        if (!empty($time)) {
            $startTime = empty($time->from) ? '00:00' : $time->from;
            $endTime = empty($time->to) ? '23:59.999' : $time->to;
            $currentTime = $dateTimeHelper->getTime(null, null, null, 'H:i');
            if (!($currentTime >= $startTime && $currentTime <= $endTime)) {
                $istimeOk = false;
                $timeNotOkMsg = sprintf(__('%1$s to %2$s', 'bitformpro'), $startTime, $endTime);
            }
        }

        if (!($isdateOk && $isdayOk && $istimeOk)) {
            if (!$isdayOk) {
                return !empty($timeNotOkMsg) ? sprintf(__('Form is available %1$s From %2$s', 'bitformpro'), $dayNotOkMsg, $timeNotOkMsg) : sprintf(__('Form is available %1$s', 'bitformpro'), $dayNotOkMsg);
            }
            if (!$isdateOk) {
                return !empty($timeNotOkMsg) ? sprintf(__('Form is available %1$s From %2$s', 'bitformpro'), $dateNotOkMsg, $timeNotOkMsg) : sprintf(__('Form is available %1$s', 'bitformpro'), $dateNotOkMsg);
            }
            if (!$istimeOk) {
                return sprintf(__('Form is available on %s', 'bitformpro'), $timeNotOkMsg);
            }
        }

        return null;
    }

    /**
     * Normalize a stored restriction date (Y-m-d, m-d-Y, or ISO with 'T') to Y-m-d
     * so string comparison is chronologically correct across year boundaries.
     */
    private static function toComparableDate($dateStr, $dateTimeHelper, $fallback)
    {
        if ('' === $dateStr) {
            return $fallback;
        }
        if (false !== strpos($dateStr, 'T')) {
            $dateStr = $dateTimeHelper->getDate($dateStr, false, null, 'Y-m-d');
        }
        if (preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', (string) $dateStr)) {
            return $dateStr;
        }
        $dt = \DateTime::createFromFormat('m-d-Y', (string) $dateStr);
        return $dt ? $dt->format('Y-m-d') : $fallback;
    }
}
