<?php

namespace BitApps\BitFormPro\Services\Frontend;

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Services\Admin\AdminFormManager;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitForm\Services\Notification\MailNotifier;
use BitApps\BitForm\Workflow\WorkFlow;
use BitApps\BitForm\Model\FormLogDetail;
use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitForm\Model\FormEntry;

class DoubleOptin
{
    protected $formId;

    protected $entryId;

    protected $token;

    protected $idendifer;

    protected $logId;

    public function __construct($idendifer, $token)
    {

        $this->idendifer = $idendifer;

        $this->token = $token;
    }

    public function approvedEntryByEmail()
    {
        $invalid = false;

        $strToArr = explode("_", $this->idendifer);

        if (is_array($strToArr) && count($strToArr) == 3) {

            $this->formId = $strToArr[0];

            $this->entryId = $strToArr[1];

            $this->logId = $strToArr[2];
        } else {
            $invalid = true;
            return;
        }

        $dblOptin = (new IntegrationHandler($this->formId))->getAllIntegration('double-opt-in', 'double-opt-in', 1);
        if (is_wp_error($dblOptin)) {
            wp_redirect(home_url());
            exit();
        }

        $dblOptinRow = Utility::firstRow($dblOptin);
        $dblConfig = Utility::jsonObj($dblOptinRow->integration_details ?? '');

        $formManager = new AdminFormManager($this->formId);

        if (!$formManager->isExist()) {
            $invalid = true;
            $this->redirect($dblConfig, 0);
        }

        $formEntry = FormEntry::readWhere(['form_id' => $this->formId, 'id' => $this->entryId], ['status']);

        if (is_wp_error($formEntry)) {
            $invalid = true;
            $this->redirect($dblConfig, 0);
        }

        $entry = Utility::firstRow($formEntry);
        if ($entry && $entry->status == 3) {
            $this->redirect($dblConfig, 2);
        }

        $formEntryMeta = FormEntryMeta::readWhere(['bitforms_form_entry_id' => $this->entryId], ['meta_key', 'meta_value']);

        $tokenExist = '';

        $entries = [];

        foreach ($formEntryMeta as $key => $value) {

            if ($value->meta_key == 'entry_confirm_activation') {
                $tokenExist = $value->meta_value;
            }

            $entries[$value->meta_key] = $value->meta_value;
        }

        if (!hash_equals((string) $tokenExist, (string) $this->token)) {
            $invalid = true;
            $this->redirect($dblConfig, 0);
        }

        $formContent = $formManager->getFormContent();

        $submitted_fields = $formContent->fields;

        foreach ($submitted_fields as $key => $value) {
            if (isset($entries[$key])) {
                $submitted_fields->{$key}->val = $entries[$key];
                $submitted_fields->{$key}->name = $key;
            }
        }

        $workFlow = new WorkFlow($this->formId);
        $workFlowreturnedOnSubmit = $workFlow->executeOnSubmit(
            'create',
            $submitted_fields,
            $entries,
            $this->entryId,
            $this->logId,
        );

        $triggerData = $workFlowreturnedOnSubmit['triggerData'] ?? null;

        if (isset($triggerData['dblOptin'])) {
            unset($triggerData['dblOptin']);
        }

        $triggerData['fields'] = $entries;

        if (!empty($triggerData) && !$invalid) {

            if (isset($triggerData['mail'])) {
                foreach ($triggerData['mail'] as $value) {
                    MailNotifier::notify($value, $triggerData['formID'], $triggerData['fields'], $this->entryId);
                }
            }

            do_action("bitforms_exec_integrations", $triggerData['integrations'], $triggerData['fields'], $triggerData['formID'], $triggerData['entryID'], $triggerData['logID']);

            FormEntry::updateWhere(
                ['form_id' => $this->formId, 'id' => $this->entryId],
                ['status' => 3, 'updated_at' => current_time('mysql')],
            );

            FormEntryMeta::deleteWhere([
                'meta_key'               => 'entry_confirm_activation',
                'meta_value'             => $this->token,
                'bitforms_form_entry_id' => $this->entryId,
            ]);
            if (isset($cronNotOk[2]) && \is_int($cronNotOk[2])) {
                FormLogDetail::updateWhere(['id' => $cronNotOk[2]], ['response_type' => 'success', 'response_obj' => json_encode(['status' => 'processed'])]);
            }
            $this->redirect($dblConfig, 1);
        }
    }

    public function redirect($config, $index)
    {
        $redirectPages = [
            (isset($config->invalid_key_url)) ? $config->invalid_key_url : '',
            (isset($config->succ_url)) ? $config->succ_url : '',
            (isset($config->already_activated_url)) ? $config->already_activated_url : '',
        ];

        $customMessages = [
            (isset($config->invalid_key_msg)) ? $config->invalid_key_msg : 'Sorry! Your URL Is Invalid!',
            (isset($config->acti_succ_msg)) ? $config->acti_succ_msg : 'Thanks for the confirmation',
            (isset($config->already_activated_msg)) ? $config->already_activated_msg : 'Your mail is already confirmed!',
        ];

        if (isset($redirectPages[$index])) {
            if (isset($config->custom_redirect) && (string) $config->custom_redirect === '1') {
                wp_redirect($redirectPages[$index]);
                exit();
            } else {
                Utility::view('views/confirmation/email_confirmation', ['data' => [
                    'title'   => 'Entry Confirmation',
                    'message' => $customMessages[$index],
                ]]);
            }
        }
    }
}
