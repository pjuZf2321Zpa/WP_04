<?php

namespace BitApps\BitFormPro\Services\Frontend;

use BitApps\BitFormPro\Http\Controller\MolliePaymentController;
use BitApps\BitFormPro\Services\Payment\MolliePaymentSession;
use Exception;

class PaymentHandler
{
    public function __construct()
    {
        add_shortcode('bitform_payments', [$this, 'paymentFrontendRender']);
    }

    public function paymentFrontendRender()
    {
        $getParams = $_GET;
        if (!isset($getParams['integID'])) {
            return sprintf(__('Payment integration Id missing', 'bitformpro'));
        }

        if (!is_numeric($getParams['integID'])) {
            return sprintf(__('Payment integration Id must be numeric', 'bitformpro'));
        }
        $integID = sanitize_text_field($getParams['integID']);

        $session = MolliePaymentSession::paymentForReturn(isset($getParams['bf_ref']) ? wp_unslash($getParams['bf_ref']) : '');
        if ($session) {
            $transactionID = $session['paymentId'];
            $integID = sanitize_text_field((string) $session['integId']);
        } else {
            // Return URLs issued before bf_ref existed. This option is site-wide — the last
            // payment anyone started — so it is only a fallback for those in-flight payments.
            $transactionID = get_option('bf_mollie_transaction_id');
        }
        if (!is_string($transactionID) || 0 !== strpos($transactionID, 'tr_')) {
            return $this->style() . $this->paymentFailedMarkup();
        }

        $molliePaymentController = new MolliePaymentController();
        $transactionDetails = $molliePaymentController->getMolliePaymentInfo($integID, $transactionID);
        if (is_wp_error($transactionDetails) || !is_object($transactionDetails) || empty($transactionDetails->status)) {
            return $this->style() . $this->paymentFailedMarkup();
        }

        ob_start();
        $output = $this->style();
        switch ($transactionDetails->status) {
            case 'paid':
                try {
                    do_action('bitform_deferred_mollie_payment_workflow', $transactionDetails);
                    $successMarkup = $this->paymentSuccessMarkup($transactionDetails->id);
                    $output .= $successMarkup;

                } catch (Exception $e) {
                    error_log('render issue' . print_r($e, true));
                }
                break;

            case 'canceled':
                $output .= $this->paymentCanceledMarkup($transactionDetails->id);
                break;
            case 'failed':
                $output .= $this->paymentFailedMarkup();
                break;
            default:
                $output .= $this->paymentStatusDefaultMarkup($transactionDetails);
        }
        echo $output;
        return ob_get_clean();

    }

    private function paymentSuccessMarkup($transactionID)
    {
        $txId = esc_html($transactionID);
        return '<div class="bf-container">' . "\n"
            . '  <div class="bf-payment-box">' . "\n"
            . '    <div class="bf-icon-box">' . "\n"
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24">' . "\n"
            . '        <path fill="currentColor" d="m10.562 15.908l6.396-6.396l-.708-.708l-5.688 5.688l-2.85-2.85l-.708.708zM12.003 21q-1.866 0-3.51-.708q-1.643-.709-2.859-1.924t-1.925-2.856T3 12.003t.709-3.51Q4.417 6.85 5.63 5.634t2.857-1.925T11.997 3t3.51.709q1.643.708 2.859 1.922t1.925 2.857t.709 3.509t-.708 3.51t-1.924 2.859t-2.856 1.925t-3.509.709M12 20q3.35 0 5.675-2.325T20 12t-2.325-5.675T12 4T6.325 6.325T4 12t2.325 5.675T12 20m0-8"/>' . "\n"
            . '      </svg>' . "\n"
            . '    </div>' . "\n"
            . '    <h1 class="bf-payment-status">Payment Successful!</h1>' . "\n"
            . '    <p class="bf-status-msg">Thank you for your purchase. Your transaction has been completed successfully.</p>' . "\n"
            . '    <p>Transaction ID: <strong>' . $txId . '</strong></p>' . "\n"
            . '  </div>' . "\n"
            . '</div>';
    }

    private function paymentFailedMarkup()
    {
        return '<div class="bf-container">' . "\n"
            . '  <div class="bf-payment-box">' . "\n"
            . '    <div class="bf-icon-box">' . "\n"
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 21 21">' . "\n"
            . '        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" transform="translate(2 2)">' . "\n"
            . '          <circle cx="8.5" cy="8.5" r="8"/>' . "\n"
            . '          <path d="m5.5 5.5l6 6m0-6l-6 6"/>' . "\n"
            . '        </g>' . "\n"
            . '      </svg>' . "\n"
            . '    </div>' . "\n"
            . '    <h1 class="bf-payment-status">Payment Failed!</h1>' . "\n"
            . '    <p class="bf-status-msg">Sorry, your transaction has been failed. Please try again.</p>' . "\n"
            . '  </div>' . "\n"
            . '</div>';
    }
    private function paymentStatusDefaultMarkup($transactionDetails)
    {
        $status = esc_html($transactionDetails->status);
        $txId = esc_html($transactionDetails->id);
        return '<div class="bf-container">' . "\n"
            . '  <div class="bf-payment-box">' . "\n"
            . '    <div class="bf-icon-box">' . "\n"
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 21 21">' . "\n"
            . '        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" transform="translate(2 2)">' . "\n"
            . '          <circle cx="8.5" cy="8.5" r="8"/>' . "\n"
            . '          <path d="m5.5 5.5l6 6m0-6l-6 6"/>' . "\n"
            . '        </g>' . "\n"
            . '      </svg>' . "\n"
            . '    </div>' . "\n"
            . '    <h1 class="bf-payment-status">Payment ' . $status . '</h1>' . "\n"
            . '    <p class="bf-status-msg">Sorry, your transaction has been ' . $status . '. Please try again.</p>' . "\n"
            . '    <p>Transaction ID: <strong>' . $txId . '</strong></p>' . "\n"
            . '  </div>' . "\n"
            . '</div>';
    }
    private function paymentCanceledMarkup($transactionID)
    {
        $txId = esc_html($transactionID);
        return '<div class="bf-container">' . "\n"
            . '  <div class="bf-payment-box">' . "\n"
            . '    <div class="bf-icon-box">' . "\n"
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 21 21">' . "\n"
            . '        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" transform="translate(2 2)">' . "\n"
            . '          <circle cx="8.5" cy="8.5" r="8"/>' . "\n"
            . '          <path d="m5.5 5.5l6 6m0-6l-6 6"/>' . "\n"
            . '        </g>' . "\n"
            . '      </svg>' . "\n"
            . '    </div>' . "\n"
            . '    <h1 class="bf-payment-status">Payment Canceled!</h1>' . "\n"
            . '    <p class="bf-status-msg">Sorry, your transaction has been canceled. Please try again.</p>' . "\n"
            . '    <p>Transaction ID: <strong>' . $txId . '</strong></p>' . "\n"
            . '  </div>' . "\n"
            . '</div>';
    }

    public function style()
    {
        return '<style>' . "\n"
            . '.bf-container {' . "\n"
            . '    text-align: center;' . "\n"
            . '    background: #fff;' . "\n"
            . '    padding: 40px 20px;' . "\n"
            . '    border-radius: 10px;' . "\n"
            . '    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);' . "\n"
            . '    max-width: 400px;' . "\n"
            . '    width: 100%;' . "\n"
            . '}' . "\n"
            . '' . "\n"
            . '.bf-payment-box {' . "\n"
            . '    display: flex;' . "\n"
            . '    flex-direction: column;' . "\n"
            . '    align-items: center;' . "\n"
            . '}' . "\n"
            . '' . "\n"
            . '.bf-icon-box {' . "\n"
            . '    color: #0062ff;' . "\n"
            . '}' . "\n"
            . '' . "\n"
            . '.bf-payment-status {' . "\n"
            . '    font-size: 24px;' . "\n"
            . '    margin-bottom: 10px;' . "\n"
            . '    color: #333;' . "\n"
            . '}' . "\n"
            . '' . "\n"
            . '.bf-status-msg {' . "\n"
            . '    font-size: 16px;' . "\n"
            . '    margin-bottom: 20px;' . "\n"
            . '    color: #666;' . "\n"
            . '}' . "\n"
            . '</style>';
    }

}
