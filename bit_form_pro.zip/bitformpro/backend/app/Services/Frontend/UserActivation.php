<?php

namespace BitApps\BitFormPro\Services\Frontend;

use BitApps\BitFormPro\Helpers\Utility;
use BitApps\BitForm\Integrations\IntegrationHandler;
use BitApps\BitFormPro\Services\Auth\Registration;
use BitApps\BitForm\Helpers\Log;

class UserActivation
{
    protected $formId;

    protected $userId;

    protected $token;

    public function __construct($token, $formId, $userId)
    {

        $this->token = $token;
        $this->userId = $userId;
        $this->formId = $formId;
    }

    protected function getActivationDetails()
    {
        $exist = (new IntegrationHandler($this->formId))->getAllIntegration('wp_user_auth', 'wp_auth', 1);

        if (is_wp_error($exist)) {
            Log::debug_log('Error: Failed to retrieve integration details for formId ' . $this->formId);
            wp_redirect(home_url());
            exit();
        }

        $code = '';
        if (metadata_exists('user', $this->userId, 'bf_activation_code')) {
            $code = get_user_meta($this->userId, 'bf_activation_code', true);
        }

        $existRow = Utility::firstRow($exist);
        $intDetails = Utility::jsonObj($existRow->integration_details ?? '');
        return [$code, $intDetails];
    }

    public function emailVerified()
    {
        list($code, $intDetails) = $this->getActivationDetails();

        $activation = (bool) get_user_meta($this->userId, 'bf_activation', true);

        if (hash_equals((string) $code, (string) $this->token)) {
            update_user_meta($this->userId, 'bf_activation', 1);
            delete_user_meta($this->userId, 'bf_activation_code');
            Registration::notification($intDetails, $this->userId);
            $this->redirect((object) $intDetails, 1);
        } elseif (empty($code) && $activation === true) {
            $this->redirect((object) $intDetails, 2);
        } elseif ($activation === false || !hash_equals((string) $code, (string) $this->token)) {
            $this->redirect((object) $intDetails, 0);
        }
    }

    public function userApproveByAdmin()
    {
        list($code, $intDetails) = $this->getActivationDetails();

        $activation = (bool) get_user_meta($this->userId, 'bf_activation', true);
        if (hash_equals((string) $code, (string) $this->token)) {
            $this->requireDecisionConfirmation('approve');
            update_user_meta($this->userId, 'bf_activation', 1);
            delete_user_meta($this->userId, 'bf_activation_code');
            Registration::notification($intDetails, $this->userId);
            $this->redirect((object) $intDetails, 1);
        } elseif (empty($code) && $activation === true) {
            $this->redirect((object) $intDetails, 2);
        } elseif ($activation === false || !hash_equals((string) $code, (string) $this->token)) {
            $this->redirect((object) $intDetails, 0);
        }
    }

    // User Reject by Admin (New function)
    public function userRejectByAdmin()
    {
        list($code, $intDetails) = $this->getActivationDetails();

        if (hash_equals((string) $code, (string) $this->token)) {
            $this->requireDecisionConfirmation('reject');
            delete_user_meta($this->userId, 'bf_activation_code');
            // Mark the user as rejected (deactivate the user)
            update_user_meta($this->userId, 'bf_activation', 0);

            // Send a rejection notification to the user
            Registration::sendRejectionEmailToUser($intDetails, $this->userId);
            $this->redirect((object) $intDetails, 3);
        } else {
            // Redirect Invalied Key URL
            $this->redirect((object) $intDetails, 0);
        }

    }

    /**
     * Approve/reject links arrive by email, and mail security scanners open every link in a
     * message. A GET therefore only shows a confirmation page; the decision runs when the
     * admin submits that page (POST to the same URL, which still carries the key).
     *
     * @param string $decision approve|reject
     *
     * @return void Returns only for a confirmed POST; otherwise renders the page and exits.
     */
    protected function requireDecisionConfirmation($decision)
    {
        if ($this->isDecisionConfirmed($decision)) {
            return;
        }

        $user = get_userdata((int) $this->userId);
        nocache_headers();
        Utility::view('views/confirmation/approval_decision', ['data' => [
            'decision' => $decision,
            'username' => $user ? $user->user_login : '',
            'email'    => $user ? $user->user_email : '',
        ]]);
    }

    /**
     * @param string $decision approve|reject
     *
     * @return bool true only for a POST from the confirmation page for this same decision
     */
    protected function isDecisionConfirmed($decision)
    {
        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper(sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD']))) : 'GET';
        $posted = isset($_POST['bf_auth_decision']) ? sanitize_key(wp_unslash($_POST['bf_auth_decision'])) : '';
        return 'POST' === $method && '' !== $posted && $posted === $decision;
    }

    /**
     * A result left without a page falls back to its message; wp_redirect('') sent a blank page.
     *
     * @param object $config registration integration details
     * @param string $page   redirect page set for this result
     *
     * @return string the URL to redirect to, or '' to show the message instead
     */
    protected function redirectTarget($config, $page)
    {
        $redirectMode = isset($config->custom_redirect) && '1' === (string) $config->custom_redirect;
        return $redirectMode && !empty($page) ? (string) $page : '';
    }

    public function redirect($config, $index)
    {
        $redirectPages = [
            (isset($config->invalid_key_url)) ? $config->invalid_key_url : '',
            (isset($config->succ_url)) ? $config->succ_url : '',
            (isset($config->already_activated_url)) ? $config->already_activated_url : '',
            (isset($config->reject_success_url)) ? $config->reject_success_url : '',
        ];

        $customMessages = [
            (isset($config->invalid_key_msg)) ? $config->invalid_key_msg : __('Sorry! Your URL Is Invalid!', 'bitformpro'),
            (isset($config->acti_succ_msg)) ? $config->acti_succ_msg : __('Your account has been activated successfully, You can now login.', 'bitformpro'),
            (isset($config->already_activated_msg)) ? $config->already_activated_msg : __('Your account is already activated!', 'bitformpro'),
            (isset($config->reject_success_msg)) ? $config->reject_success_msg : __('Requested account has been rejected successfully.', 'bitformpro'),
        ];

        if (!empty($redirectPages[$index]) || !empty($customMessages[$index])) {
            $target = $this->redirectTarget($config, $redirectPages[$index]);
            if ('' !== $target) {
                wp_redirect($target);
                exit();
            } else {
                Utility::view('views/confirmation/email_confirmation', ['data' => [
                    'title'   => 'Account Activation',
                    'message' => $customMessages[$index],
                ]]);
            }
        } else {
            // Fallback URL or error message
            wp_redirect(home_url());
            exit();
        }
    }
}
