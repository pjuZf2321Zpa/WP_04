<?php

namespace BitApps\BitFormPro\Services\Frontend\EmailOtp;

use BitApps\BitForm\Services\Form\FormManager;
use BitApps\BitForm\Services\Notification\MailConfig;
use BitApps\BitForm\Services\Frontend\FrontendFormManager;
use BitApps\BitFormPro\Http\Middleware\FormNonceCheckerMiddleware;

/**
 * EmailOtpHandler
 *
 * Handles the Email OTP field feature for Bit Form Pro.
 *
 * Flow:
 *   1. User clicks "Send OTP"  → JS calls bitforms_send_email_otp  → sendOtp()
 *   2. User enters code + clicks "Verify OTP" → JS calls bitforms_verify_email_otp → verifyOtp()
 *   3. On final form submission → bitform_filter_form_validation filter → validateOnSubmit()
 *
 * Transient keys (no user meta — works for guests too):
 *   bf_otp_<md5(formId.sessionId)>          → serialized { hash, timestamp, attempts }
 *   bf_otp_verified_<md5(formId.sessionId)>  → serialized { token_hash, timestamp }
 */
class EmailOtpHandler
{
    private const OTP_TRANSIENT_PREFIX      = 'bitform_otp_';
    private const VERIFIED_TRANSIENT_PREFIX = 'bitform_otp_verified_';
    private const RATE_LIMIT_PREFIX         = 'bitform_otp_rl_';
    private const SUBMIT_NONCE_SALT         = 'bitform_otp_submit';

    /** Max OTP send requests per IP per form/field within the rate-limit window. */
    private const RATE_LIMIT_MAX            = 5;

    /** Rate-limit window in seconds. */
    private const RATE_LIMIT_WINDOW         = 60;

    // -------------------------------------------------------------------------
    // AJAX: Send OTP
    // -------------------------------------------------------------------------

    public static function sendOtp(): void
    {
        // Basic nonce / flood protection — re-use the form nonce from bf_globals
        $formId   = isset($_POST['form_id']) ? (int) sanitize_text_field($_POST['form_id']) : 0;
        $fieldKey = isset($_POST['field_key']) ? sanitize_text_field($_POST['field_key']) : '';
        $email    = isset($_POST['receiver_email']) ? sanitize_email($_POST['receiver_email']) : '';
        $nonce    = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';

        if (!$formId || !$fieldKey) {
            wp_send_json_error(__('Invalid request parameters.', 'bitformpro'), 400);
        }

        if (!FormNonceCheckerMiddleware::allows($formId, $nonce)) {
            wp_send_json_error(__('Security check failed.', 'bitformpro'), 401);
        }

        // Rate limiting: max RATE_LIMIT_MAX requests per IP/form/field per window
        self::checkRateLimit($formId, $fieldKey);

        // Retrieve OTP field config from form definition
        $fieldConfig = self::getFieldConfig($formId, $fieldKey);
        if (!$fieldConfig) {
            wp_send_json_error(__('OTP field configuration not found.', 'bitformpro'), 404);
        }

        // Resolve receiver email
        if (empty($email)) {
            wp_send_json_error(__('Receiver email is required.', 'bitformpro'), 422);
        }

        if (!is_email($email)) {
            wp_send_json_error(__('Invalid receiver email address.', 'bitformpro'), 422);
        }

        $expiryMinutes = isset($fieldConfig->expiryDelay) ? (int) $fieldConfig->expiryDelay : 15;
        $otpLength     = isset($fieldConfig->otpLength) ? (int) $fieldConfig->otpLength : 6;

        $code      = self::generateCode($otpLength);
        $sessionId = wp_generate_uuid4();

        // Store hashed OTP in a transient
        $transientKey = self::otpTransientKey($formId, $sessionId);
        set_transient($transientKey, [
            'hash'      => wp_hash($code),
            'timestamp' => time(),
            'formId'    => $formId,
            'fieldKey'  => $fieldKey,
            'email'     => strtolower($email),
        ], $expiryMinutes * MINUTE_IN_SECONDS);

        $context = [
            'form_id'        => $formId,
            'field_key'      => $fieldKey,
            'email'          => $email,
            'expiry_minutes' => $expiryMinutes,
            'is_resend'      => !empty($_POST['is_resend']),
        ];

        $delivery = self::deliverOtp($code, $context, $fieldConfig);
        if (is_wp_error($delivery)) {
            delete_transient($transientKey);
            wp_send_json_error($delivery->get_error_message(), 500);
        }

        /**
         * Fires after an OTP was delivered, e.g. to also forward it to a webhook.
         *
         * @param string $code        Plain OTP code.
         * @param array  $context     form_id, field_key, email, expiry_minutes, is_resend.
         * @param object $fieldConfig email-otp field config.
         */
        do_action('bitform_email_otp_sent', $code, $context, $fieldConfig);

        wp_send_json_success([
            'session_id' => $sessionId,
            'message'    => __('OTP sent successfully. Please check your email.', 'bitformpro'),
        ]);
    }

    // -------------------------------------------------------------------------
    // AJAX: Verify OTP
    // -------------------------------------------------------------------------

    public static function verifyOtp(): void
    {
        $formId    = isset($_POST['form_id']) ? (int) sanitize_text_field($_POST['form_id']) : 0;
        $fieldKey  = isset($_POST['field_key']) ? sanitize_text_field($_POST['field_key']) : '';
        $code      = isset($_POST['otp_code']) ? sanitize_text_field($_POST['otp_code']) : '';
        $sessionId = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $nonce     = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';

        if (!$formId || !$fieldKey || !$code || !$sessionId) {
            wp_send_json_error(__('Invalid request parameters.', 'bitformpro'), 400);
        }

        if (!FormNonceCheckerMiddleware::allows($formId, $nonce)) {
            wp_send_json_error(__('Security check failed.', 'bitformpro'), 401);
        }

        $fieldConfig   = self::getFieldConfig($formId, $fieldKey);
        $expiryMinutes = isset($fieldConfig->expiryDelay) ? (int) $fieldConfig->expiryDelay : 15;

        $transientKey = self::otpTransientKey($formId, $sessionId);
        $stored       = get_transient($transientKey);

        if (!$stored || !is_array($stored)) {
            wp_send_json_error(__('OTP has expired or was not found. Please request a new code.', 'bitformpro'), 410);
        }

        // Expiry double-check (transient TTL covers this, but belt + suspenders)
        if (isset($stored['timestamp']) && (time() - $stored['timestamp']) > ($expiryMinutes * MINUTE_IN_SECONDS)) {
            delete_transient($transientKey);
            wp_send_json_error(__('OTP has expired. Please request a new code.', 'bitformpro'), 410);
        }

        // Constant-time comparison
        if (!hash_equals($stored['hash'], wp_hash($code))) {
            wp_send_json_error(__('The OTP code you entered is incorrect.', 'bitformpro'), 422);
        }

        // OTP is valid — consume it (one-time use)
        delete_transient($transientKey);

        // Issue verification token
        $verifyToken     = wp_generate_uuid4();
        $verifiedKey     = self::verifiedTransientKey($formId, $sessionId);
        set_transient($verifiedKey, [
            'token_hash' => wp_hash($verifyToken),
            'timestamp'  => time(),
            'formId'     => $formId,
            'fieldKey'   => $fieldKey,
            'email'      => isset($stored['email']) ? $stored['email'] : '',
        ], $expiryMinutes * MINUTE_IN_SECONDS);

        wp_send_json_success([
            'verify_token' => $verifyToken,
            'session_id'   => $sessionId,
            'message'      => __('OTP verified successfully!', 'bitformpro'),
        ]);
    }

    // -------------------------------------------------------------------------
    // Filter: Validate on form submission
    // -------------------------------------------------------------------------

    /**
     * Hooked to bitform_filter_form_validation.
     *
     * @param  bool|string $validated  Current validation state (true = valid).
     * @param  int         $formId     The form being submitted.
     * @return bool|string
     */
    public static function validateOnSubmit($validated, $formId)
    {
        // If already failed validation, short-circuit
        if (true !== $validated) {
            return $validated;
        }

        $formContent = self::getFormFields($formId);
        if (!$formContent) {
            return $validated;
        }

        foreach ($formContent as $fieldKey => $field) {
            if (!isset($field->typ) || 'email-otp' !== $field->typ) {
                continue;
            }

            $verifyToken = isset($_POST[$fieldKey]) ? sanitize_text_field($_POST[$fieldKey]) : '';
            $sessionId   = isset($_POST[$fieldKey . '_session_id']) ? sanitize_text_field($_POST[$fieldKey . '_session_id']) : '';

            if (!$verifyToken || !$sessionId) {
                return __('OTP verification is required before submitting the form.', 'bitformpro');
            }

            $expiryMinutes = isset($field->config->expiryDelay) ? (int) $field->config->expiryDelay : 15;
            $verifiedKey   = self::verifiedTransientKey($formId, $sessionId);
            $stored        = get_transient($verifiedKey);

            if (!$stored || !is_array($stored)) {
                return __('OTP verification has expired. Please verify the OTP again.', 'bitformpro');
            }

            // Expiry check
            if (isset($stored['timestamp']) && (time() - $stored['timestamp']) > ($expiryMinutes * MINUTE_IN_SECONDS)) {
                delete_transient($verifiedKey);
                return __('OTP verification has expired. Please verify the OTP again.', 'bitformpro');
            }

            // Token integrity check
            if (!hash_equals($stored['token_hash'], wp_hash($verifyToken))) {
                return __('OTP verification token is invalid.', 'bitformpro');
            }

            $boundEmail     = isset($stored['email']) ? strtolower($stored['email']) : '';
            $submittedEmail = strtolower(self::resolveSubmittedOtpEmail($field));
            if ('' === $boundEmail || '' === $submittedEmail || !hash_equals($boundEmail, $submittedEmail)) {
                return __('The verified email does not match the email being submitted. Please verify the OTP for the correct email address.', 'bitformpro');
            }

            // Consume verification token (one-time use)
            delete_transient($verifiedKey);
        }

        return $validated;
    }

    // -------------------------------------------------------------------------
    // Filters: Exclude OTP from entry storage
    // -------------------------------------------------------------------------

    /**
     * Hooked to bitform_filter_save_form_entry.
     * Removes OTP field values so they are not stored in form entries.
     *
     * @param  array $data    Submitted form data.
     * @param  int   $formId  Form ID.
     * @return array
     */
    public static function stripOtpFromSaveEntry(array $data, $formId)
    {
        return self::stripOtpFromEntryData($data, $formId);
    }

    /**
     * Hooked to bitform_filter_update_form_entry.
     * Removes OTP field values so they are not stored when updating entries.
     *
     * @param  array $data    Updated form data.
     * @param  int   $formId  Form ID.
     * @return array
     */
    public static function stripOtpFromUpdateEntry(array $data, $formId)
    {
        return self::stripOtpFromEntryData($data, $formId);
    }

    /**
     * Removes email-otp field keys and their _session_id from entry data.
     *
     * @param  array $data    Entry data (submitted or updated).
     * @param  int   $formId  Form ID.
     * @return array
     */
    private static function stripOtpFromEntryData(array $data, $formId)
    {
        $formManager = FrontendFormManager::getInstance($formId);
        $formFields  = $formManager->getFields();

        foreach ($formFields as $fieldKey => $field) {
            if (isset($field['type']) && 'email-otp' === $field['type']) {
                unset($data[$fieldKey]);
                unset($data[$fieldKey . '_session_id']);
            }
        }

        return $data;
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    /**
     * Resolve the email address an email-otp field validates at submit time, so it
     * can be compared against the OTP-verified address. Static config returns the
     * fixed address; dynamic config reads the referenced email field's submitted
     * value ($_POST is already remapped to internal field keys at this point).
     *
     * @param object $field email-otp field definition from the form content.
     * @return string
     */
    private static function resolveSubmittedOtpEmail($field): string
    {
        $config = isset($field->config) ? $field->config : null;
        if (!$config) {
            return '';
        }

        if (isset($config->receiverEmailType) && 'static' === $config->receiverEmailType) {
            return isset($config->receiverEmail) ? sanitize_email($config->receiverEmail) : '';
        }

        $emailFldKey = isset($config->receiverEmailFld) ? $config->receiverEmailFld : '';
        if ($emailFldKey && isset($_POST[$emailFldKey])) {
            return sanitize_email(wp_unslash($_POST[$emailFldKey]));
        }

        return '';
    }

    /**
     * Enforce IP-based rate limiting for OTP send requests.
     * Terminates the request with a 429 error if the limit is exceeded.
     */
    private static function checkRateLimit(int $formId, string $fieldKey): void
    {
        $ip  = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : 'unknown';
        $key = self::RATE_LIMIT_PREFIX . md5($ip . '|' . $formId . '|' . $fieldKey);

        $data = get_transient($key);

        if ($data && is_array($data)) {
            if ((int) $data['count'] >= self::RATE_LIMIT_MAX) {
                wp_send_json_error(
                    __('Too many OTP requests. Please wait a moment before trying again.', 'bitformpro'),
                    429,
                );
            }
            set_transient($key, ['count' => (int) $data['count'] + 1], self::RATE_LIMIT_WINDOW);
        } else {
            set_transient($key, ['count' => 1], self::RATE_LIMIT_WINDOW);
        }
    }

    private static function generateCode(int $length = 6): string
    {
        $length = max(4, min(8, $length));
        $code   = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= (string) wp_rand(0, 9);
        }
        return $code;
    }

    /**
     * Deliver the OTP through bitform_email_otp_send, falling back to the default email.
     *
     * @param string $code        Plain OTP code.
     * @param array  $context     Delivery context passed to the hooks.
     * @param object $fieldConfig email-otp field config.
     * @return true|\WP_Error
     */
    private static function deliverOtp(string $code, array $context, $fieldConfig)
    {
        /**
         * Replaces the OTP email, e.g. to send it by WhatsApp or SMS instead.
         *
         * Return null to keep the default email, true once delivered, or false /
         * WP_Error on failure (a WP_Error message is shown under the field).
         *
         * @param null|bool|\WP_Error $delivered   Delivery result; null = not handled.
         * @param string              $code        Plain OTP code.
         * @param array               $context     form_id, field_key, email, expiry_minutes, is_resend.
         * @param object              $fieldConfig email-otp field config.
         */
        $delivered = apply_filters('bitform_email_otp_send', null, $code, $context, $fieldConfig);

        if (null === $delivered) {
            $delivered = self::sendOtpEmail($context['email'], $code, $fieldConfig, $context['expiry_minutes']);
            if (!$delivered) {
                return new \WP_Error('bitform_otp_email_failed', __('Failed to send OTP email. Please try again.', 'bitformpro'));
            }
            return true;
        }

        if (is_wp_error($delivered)) {
            return $delivered;
        }

        if (!$delivered) {
            return new \WP_Error('bitform_otp_send_failed', __('Failed to send OTP. Please try again.', 'bitformpro'));
        }

        return true;
    }

    private static function sendOtpEmail(string $to, string $code, $config, int $expiryMinutes): bool
    {
        $template = isset($config->emailTemplate) ? $config->emailTemplate : '';
        if (empty($template)) {
            $template = '<p>Your verification code is: <strong>${bf_otp_code}</strong></p>'
                . '<p>This code expires in ${bf_expiry_minutes} minutes.</p>';
        }

        $body = str_replace(
            ['${bf_otp_code}', '${bf_expiry_minutes}'],
            [esc_html($code), esc_html((string) $expiryMinutes)],
            $template,
        );

        $subject = __('Your OTP Verification Code', 'bitformpro');
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        (new MailConfig())->sendMail();
        return wp_mail($to, $subject, $body, $headers);
    }

    private static function getFieldConfig(int $formId, string $fieldKey): ?object
    {
        try {
            $formManager  = new FormManager($formId);
            $formContent  = $formManager->getFormContent();
            $fields       = $formContent->fields ?? null;

            if (!$fields) {
                return null;
            }

            foreach ($fields as $field) {
                if (isset($field->key) && $field->key === $fieldKey) {
                    return $field->config ?? null;
                }
            }

            // Fallback: form fields may be indexed by key
            if (isset($fields->{$fieldKey})) {
                return $fields->{$fieldKey}->config ?? null;
            }
        } catch (\Throwable $e) {
            // Silently return null — caller handles the null check
        }

        return null;
    }

    private static function getFormFields(int $formId): ?object
    {
        try {
            $formManager = new FormManager($formId);
            $formContent = $formManager->getFormContent();
            $fields      = $formContent->fields ?? null;

            if (!$fields) {
                return null;
            }

            // Normalize to key-indexed object if it's a plain array
            if (is_array($fields)) {
                $indexed = new \stdClass();
                foreach ($fields as $field) {
                    if (isset($field->key)) {
                        $indexed->{$field->key} = $field;
                    }
                }
                return $indexed;
            }

            return $fields;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private static function otpTransientKey(int $formId, string $sessionId): string
    {
        return self::OTP_TRANSIENT_PREFIX . md5($formId . '.' . $sessionId);
    }

    private static function verifiedTransientKey(int $formId, string $sessionId): string
    {
        return self::VERIFIED_TRANSIENT_PREFIX . md5($formId . '.' . $sessionId);
    }
}
