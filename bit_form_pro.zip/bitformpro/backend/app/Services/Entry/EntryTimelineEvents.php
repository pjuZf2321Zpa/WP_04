<?php

namespace BitApps\BitFormPro\Services\Entry;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BitForm\Model\FormEntryMeta;
use BitApps\BitForm\Services\Admin\AdminFormManager;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\BitFormPro\Model\PaymentInfoModel;

/**
 * Pro's contribution to an entry's activity stream.
 *
 * Free fires `bitform_entry_timeline_events` and never reads a Pro table; this
 * is the other side of that contract.
 *
 * **Payments only, deliberately.** Notes already appear, because Pro writes a
 * `bitforms_form_entry_log` row for every note create/update/delete and Free
 * classifies those from its own `log_type` column. Appending them again here
 * would double every note. What Free genuinely cannot see is
 * `bitforms_payments`, which is keyed by transaction id rather than entry id.
 *
 * The raw gateway response is **not** attached. It is a third-party payload
 * that can carry customer and card metadata, and a timeline needs four facts:
 * which gateway, how much, what state, when. The full record stays behind the
 * existing payment panel.
 */
final class EntryTimelineEvents
{
    /** Field types whose stored value is a transaction id. */
    private const PAYMENT_FIELD_TYPES = ['paypal', 'stripe', 'razorpay', 'mollie'];

    /** Gateway status strings, normalised to the timeline's vocabulary. */
    private const SUCCESS_STATES = ['succeeded', 'success', 'paid', 'completed', 'captured', 'authorized', 'approved', 'active'];

    private const ERROR_STATES = ['failed', 'failure', 'canceled', 'cancelled', 'denied', 'expired', 'declined'];

    /**
     * @return void
     */
    public static function register()
    {
        add_filter('bitform_entry_timeline_events', [new self(), 'append'], 10, 3);
    }

    /**
     * `$events` is typed loosely on purpose: it is a filter value, so another
     * plugin can hand this callback anything at all, and a filter that fatals
     * takes the whole timeline request with it.
     *
     * @param mixed $events
     * @param int   $formId
     * @param int   $entryId
     *
     * @return mixed the value it was given, with Pro's events appended
     */
    public function append($events, $formId, $entryId)
    {
        if (!is_array($events)) {
            return $events;
        }

        foreach ($this->transactionIds($formId, $entryId) as $fieldKey => $transactionId) {
            foreach ((new PaymentInfoModel())->findByTransaction($formId, $transactionId) as $row) {
                $events[] = $this->event($row, $fieldKey);
            }
        }

        return $events;
    }

    /**
     * The transaction id stored in each of the entry's payment fields.
     *
     * The value can carry more than the id — the admin UI reads the first
     * comma-separated segment, and this has to agree with it or the lookup
     * silently finds nothing.
     *
     * @param int $formId
     * @param int $entryId
     *
     * @return array<string,string> field key => transaction id
     */
    private function transactionIds($formId, $entryId)
    {
        $formManager = new AdminFormManager($formId);
        if (!$formManager->isExist()) {
            return [];
        }

        $paymentKeys = [];
        foreach ((array) $formManager->getFieldLabel(true) as $field) {
            if (isset($field['key'], $field['type']) && in_array($field['type'], self::PAYMENT_FIELD_TYPES, true)) {
                $paymentKeys[] = $field['key'];
            }
        }
        if (empty($paymentKeys)) {
            return [];
        }

        // rowsWhere(): [] for none and on failure.
        $meta = FormEntryMeta::rowsWhere(
            ['bitforms_form_entry_id' => $entryId, 'meta_key' => $paymentKeys],
            ['meta_key', 'meta_value'],
        );

        $ids = [];
        foreach ($meta as $row) {
            $value = trim((string) $row->meta_value);
            if ('' === $value) {
                continue;
            }
            $ids[(string) $row->meta_key] = trim(explode(',', $value)[0]);
        }

        return $ids;
    }

    /**
     * @param object $row
     * @param string $fieldKey
     *
     * @return array
     */
    private function event($row, $fieldKey)
    {
        $response = JSON::decode((string) $row->payment_response, true);
        $response = is_array($response) ? $response : [];

        $state = $this->pick($response, ['status', 'state', 'payment_status']);
        $status = $this->normalizeState($state);

        return [
            'id'          => 'payment:' . (int) $row->id,
            'type'        => 'payment',
            'occurred_at' => (string) $row->created_at,
            // A gateway callback has no logged-in user behind it.
            'actor'       => ['kind' => 'system', 'id' => null, 'name' => null],
            'titleKey'    => 'timeline.payment.' . $status,
            'params'      => ['name' => (string) $row->payment_name],
            'status'      => $status,
            'summary'     => $this->summary($response, $state),
            // Four facts, not the gateway's whole payload — see the class note.
            'detail'      => [
                'gateway'        => (string) $row->payment_name,
                'type'           => (string) $row->payment_type,
                'transaction_id' => (string) $row->transaction_id,
                'amount'         => $this->pick($response, ['amount', 'value', 'grand_total']),
                'currency'       => $this->pick($response, ['currency', 'currency_code']),
                'state'          => $state,
            ],
            'replayable'  => false,
            'replay'      => null,
            'related'     => ['field_key' => $fieldKey, 'transaction_id' => (string) $row->transaction_id],
        ];
    }

    /**
     * @param array $response
     * @param string $state
     *
     * @return null|string
     */
    private function summary(array $response, $state)
    {
        $amount = $this->pick($response, ['amount', 'value', 'grand_total']);
        $currency = $this->pick($response, ['currency', 'currency_code']);

        $parts = array_filter([
            '' === $amount ? '' : trim($currency . ' ' . $amount),
            $state,
        ]);

        return empty($parts) ? null : implode(' · ', $parts);
    }

    /**
     * A shallow lookup over the keys gateways actually use.
     *
     * Nested shapes (Stripe's `amount` inside `data.object`, Mollie's
     * `amount.value`) are handled one level down, which covers every gateway
     * Pro ships without pretending to understand each payload in full.
     *
     * @param array    $response
     * @param string[] $keys
     *
     * @return string
     */
    private function pick(array $response, array $keys)
    {
        foreach ($keys as $key) {
            if (!isset($response[$key])) {
                continue;
            }
            $value = $response[$key];
            if (is_scalar($value)) {
                return (string) $value;
            }
            if (is_array($value)) {
                foreach (['value', 'amount', 'currency'] as $inner) {
                    if (isset($value[$inner]) && is_scalar($value[$inner])) {
                        return (string) $value[$inner];
                    }
                }
            }
        }

        return '';
    }

    /**
     * @param string $state
     *
     * @return string one of success|error|info
     */
    private function normalizeState($state)
    {
        $state = strtolower(trim((string) $state));
        if ('' === $state) {
            // A stored payment row with no readable state still happened; it is
            // just not a claim about whether the money moved.
            return 'info';
        }
        if (in_array($state, self::SUCCESS_STATES, true)) {
            return 'success';
        }

        return in_array($state, self::ERROR_STATES, true) ? 'error' : 'info';
    }
}
