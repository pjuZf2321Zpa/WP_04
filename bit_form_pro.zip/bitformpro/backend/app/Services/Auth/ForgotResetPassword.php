<?php

namespace BitApps\BitFormPro\Services\Auth;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * User Login
 *
 */


use BitApps\BitForm\Services\Notification\MailConfig;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

/**
 * Provide functionality for Login
 */
class ForgotResetPassword
{
    private $_wpdb;

    public function __construct()
    {
        global $wpdb;
        $this->_wpdb = $wpdb;
    }

    public function sendEmailVerification($intDetails, $postData)
    {
        $data = [];
        $decode = JSON::decode($intDetails->integration_details);
        $userKey = $decode->forgot_map[0]->forgotField;
        $key = $decode->forgot_map[0]->formField;
        $user = get_user_by($userKey, $postData[$key]);

        if (empty($user)) {
            $user = get_user_by('email', $postData[$key]);
        }

        if (!empty($user)) {
            $mailSubject = $decode->sub;
            $mailBody = $decode->body;
            $userLogin = $user->data->user_login;
            $key = get_password_reset_key($user);
            if (is_wp_error($key)) {
                $data['success'] = false;
                $data['message'] = $key->get_error_message();
                return $data;
            }
            // add_query_arg() keeps a Link that already has a query string (?page_id=12,
            // ?lang=fr) valid; plain concatenation produced a second "?" and lost the token.
            $resetUrl = add_query_arg(
                [
                    'token' => $key,
                    'id'    => $user->data->ID,
                ],
                !empty($decode->redirect_url) ? $decode->redirect_url : home_url('/'),
            );
            $mailBody = str_replace('{customer_name}', $userLogin, $mailBody);
            $mailBody = str_replace('{reset_password_url}', esc_url($resetUrl), $mailBody);
            $mailBody = str_replace('{site_url}', home_url(), $mailBody);
            add_filter('wp_mail_content_type', [$this, 'filterMailContentType']);
            (new MailConfig())->sendMail();
            $mailStaus = wp_mail($user->data->user_email, $mailSubject, $mailBody);
            remove_filter('wp_mail_content_type', [$this, 'filterMailContentType']);

            if ($mailStaus == false) {
                $data['success'] = false;
                $data['message'] = "Error Mail Sending !! ";
                return $data;
            }

            $data['message'] = $this->forgotSuccessMessage($decode);
            $data['success'] = true;
        } else {
            // Answer exactly like a sent email so the form cannot be used to probe which
            // usernames or email addresses have accounts (user enumeration).
            $data['message'] = $this->forgotSuccessMessage($decode);
            $data['success'] = true;
        }
        return $data;
    }

    /**
     * Shown whether or not an account matched, so it must not claim an email was sent.
     *
     * @param object $config forgot-password integration details
     *
     * @return string
     */
    private function forgotSuccessMessage($config)
    {
        if (!empty($config->succ_msg)) {
            return $config->succ_msg;
        }
        return __("If an account exists for that username or email, we've emailed a reset link.", 'bitformpro');
    }

    public function filterMailContentType()
    {
        return 'text/html; charset=UTF-8';
    }

    private function resetFieldMapping($resetMap, $fieldValues)
    {
        $fieldData = [];
        foreach ((array) $resetMap as $fieldPair) {
            if (is_object($fieldPair) && !empty($fieldPair->resetField) && !empty($fieldPair->formField)) {
                if ($fieldPair->formField === 'custom' && isset($fieldPair->customValue)) {
                    $fieldData[$fieldPair->resetField] = $fieldPair->customValue;
                } elseif (isset($fieldValues[$fieldPair->formField])) {
                    $fieldData[$fieldPair->resetField] = $fieldValues[$fieldPair->formField];
                }
            }
        }
        return $fieldData;
    }

    public function resetPassword($intDetails, $postData, $params)
    {
        $data = [];
        $intDetails = is_string($intDetails) ? JSON::decode($intDetails) : $intDetails;
        $mapping = $this->resetFieldMapping($intDetails->reset_map, $postData);
        $data['success'] = false;
        if (isset($params['id']) && isset($params['token'])) {

            $user = get_user_by("ID", $params['id']);

            if ($user !== false) {

                $validToken = check_password_reset_key($params['token'], $user->user_login);

                if (is_wp_error($validToken)) {
                    $data['message'] = __('This password reset link is invalid or has expired. Please request a new one.', 'bitformpro');
                    return $data;
                }
                if (empty($mapping['conf_password']) || empty($mapping['new_password'])) {
                    $data['message'] = __('The password field cannot be empty.', 'bitformpro');
                    return $data;
                }

                if ($mapping['conf_password'] != $mapping['new_password']) {
                    $data['message'] = __('The password and confirmation password do not match.', 'bitformpro');
                    return $data;
                }

                $result = reset_password($user, $mapping['new_password']);

                if ($result === null) {
                    $data['message'] = $intDetails->succ_msg;
                    $data['success'] = true;
                    $data['redirectPage'] = !empty($intDetails->redirect_url) ? $intDetails->redirect_url : '';
                } else {
                    $data['message'] = __('Your password could not be reset. Please try again.', 'bitformpro');
                }
            } else {
                $data['message'] = __('This password reset link is invalid or has expired. Please request a new one.', 'bitformpro');
            }
        } else {
            $data['message'] = __('This password reset link is invalid or has expired. Please request a new one.', 'bitformpro');
        }
        return $data;
    }
}
