<?php

namespace BitApps\BitFormPro\Ai;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Adds Bit Form Pro's AI/MCP tools to Free's registry (`bitform_ai_tool_providers`).
 */
final class AiTools
{
    /**
     * @param mixed $providers
     *
     * @return array<int, mixed>
     */
    public static function providers($providers = [])
    {
        $providers = is_array($providers) ? $providers : [];
        $providers[] = new EntryTools();
        $providers[] = new PdfTools();

        return $providers;
    }
}
