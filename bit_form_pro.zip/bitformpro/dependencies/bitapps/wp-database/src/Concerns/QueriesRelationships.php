<?php

/**
 * Relation querying for the QueryBuilder: eager loading, existence filters and
 * relation aggregates. Kept separate from core query building (SRP).
 *
 * @license GPL-2.0-or-later
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPDatabase\Concerns;

use BitApps\BitFormPro\Deps\BitApps\WPDatabase\Model;
use BitApps\BitFormPro\Deps\BitApps\WPDatabase\QueryBuilder;
use Closure;
use RuntimeException;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * Partial of {@see QueryBuilder} (relies on its structured select state, the
 * bound $_model, and the identifier/raw-predicate boundaries).
 *
 * @mixin \BitApps\BitFormPro\Deps\BitApps\WPDatabase\QueryBuilder
 */
trait QueriesRelationships
{
    /**
     * Eager loads the given relation(s) onto the bound model.
     *
     * @param string|array $relation
     * @param null|Closure $callback
     *
     * @return $this
     */
    public function with($relation, $callback = null)
    {
        $this->_model->addRelation($this->resolveRelations($relation, $callback));

        return $this;
    }

    /**
     * Selects extra pivot-table columns for a pivot belongsToMany relation.
     * They surface flat on each related model as `pivot_<column>` attributes.
     *
     * @param array|string $columns
     *
     * @return $this
     */
    public function withPivot($columns)
    {
        $this->_model->addPivotColumns(\is_array($columns) ? $columns : \func_get_args());

        return $this;
    }

    /**
     * Adds a relation count sub query to this query.
     *
     * @param string|array $relation
     *
     * @return $this
     */
    public function withCount($relation)
    {
        return $this->withAggregate($relation, '*', 'count');
    }

    /**
     * Adds a relation min sub query to this query.
     *
     * @param string|array $relation
     *
     * @return $this
     */
    public function withMin($relation)
    {
        return $this->withAggregate($relation, '*', 'min');
    }

    /**
     * Adds a relation max sub query to this query.
     *
     * @param string|array $relation
     *
     * @return $this
     */
    public function withMax($relation)
    {
        return $this->withAggregate($relation, '*', 'max');
    }

    /**
     * Adds a relation avg sub query to this query.
     *
     * @param string|array $relation
     *
     * @return $this
     */
    public function withAvg($relation)
    {
        return $this->withAggregate($relation, '*', 'avg');
    }

    /**
     * Adds a relation sum sub query to this query.
     *
     * @param string|array $relation
     *
     * @return $this
     */
    public function withSum($relation)
    {
        return $this->withAggregate($relation, '*', 'sum');
    }

    /**
     * Adds a relation exists sub query to this query.
     *
     * @param string|array $relation
     *
     * @return $this
     */
    public function withExists($relation)
    {
        return $this->withAggregate($relation, '*', 'exists');
    }

    /**
     * Adds an aggregate sub query for the given relation(s) to this query.
     *
     * The aggregated column may be expressed inline as `relation.column`
     * (e.g. `withSum('posts.amount')`); otherwise the `$column` fallback is used.
     *
     * @param string|array $relation
     * @param mixed        $column   fallback column when a token carries none
     * @param string       $function
     *
     * @return $this
     */
    public function withAggregate($relation, $column, $function)
    {
        if (empty($relation)) {
            return $this;
        }

        $this->assertSafeAggregateFunction($function);

        if (empty($this->select)) {
            $this->select = [$this->_model->getTable() . '.*'];
        }

        [$relations, $columns] = $this->normalizeAggregateRelations((array) $relation, $column);

        foreach ($this->_model->prepareRelation($relations) as $relationName => $relationalQuery) {
            [$name, $alias] = $this->_model->prepareRelationName($relationName);
            if (\is_null($alias)) {
                $alias = strtolower($name . '_' . $function);
            }

            $aggregateColumn = $columns[$relationName];

            $this->correlate($relationalQuery);

            if ($function === 'exists') {
                $relationalQuery->select($aggregateColumn);
                $this->addSubquerySelect($relationalQuery, $alias, true)->withCast([$alias => 'bool']);
            } else {
                $relationalQuery->addAggregateSelect($function, $aggregateColumn);
                $this->addSubquerySelect($relationalQuery, $alias);
            }
        }

        return $this;
    }

    /**
     * Filters the query to models having the given relation.
     *
     * @param string|array $relation
     * @param null|Closure $callback
     *
     * @return $this
     */
    public function whereHas($relation, $callback = null)
    {
        foreach ($this->resolveRelations($relation, $callback) as $relationalQuery) {
            $this->correlate($relationalQuery);
            $this->whereRaw('exists(' . $relationalQuery->select('*')->prepare() . ')');
        }

        return $this;
    }

    /**
     * Filters by relation existence and eager loads the same relation.
     *
     * @param string|array $relation
     * @param null|Closure $callback
     *
     * @return $this
     */
    public function withWhereHas($relation, $callback = null)
    {
        $relations = $this->resolveRelations($relation, $callback);

        foreach ($relations as $relationalQuery) {
            $existsQuery = $this->correlate($relationalQuery->newQuery());
            $this->whereRaw('exists(' . $existsQuery->select('*')->prepare() . ')');
        }

        $this->_model->addRelation($relations);

        return $this;
    }

    /**
     * Splits relation tokens into the relation expression (kept for resolution,
     * including any `as <alias>`) and the column to aggregate, preserving the
     * int-keyed-string vs string-keyed-closure shapes that prepareRelation expects.
     *
     * @param array $relation
     * @param mixed $defaultColumn
     *
     * @return array{0: array, 1: array<string, mixed>}
     */
    private function normalizeAggregateRelations(array $relation, $defaultColumn)
    {
        $relations = [];
        $columns   = [];

        foreach ($relation as $key => $value) {
            $positional              = \is_int($key) && \is_string($value);
            [$relationExpr, $column] = $this->splitAggregateColumn($positional ? $value : (string) $key, $defaultColumn);

            $columns[$relationExpr] = $column;
            if ($positional) {
                $relations[] = $relationExpr;
            } else {
                $relations[$relationExpr] = $value;
            }
        }

        return [$relations, $columns];
    }

    /**
     * Parses a `relation[.column][ as alias]` token.
     *
     * @param string $expr
     * @param mixed  $defaultColumn used when the token carries no `.column`
     *
     * @return array{0: string, 1: mixed} [relationExpr, column]
     */
    private function splitAggregateColumn($expr, $defaultColumn)
    {
        $alias = '';
        $body  = $expr;
        if (preg_match('/^(.*?)\s+as\s+(.*)$/i', $expr, $matches)) {
            $body  = $matches[1];
            $alias = trim($matches[2]);
        }

        if (strpos($body, '.') !== false) {
            [$relation, $column] = explode('.', $body, 2);
            $column              = trim($column);
        } else {
            $relation = $body;
            $column   = $defaultColumn;
        }

        $relation     = trim($relation);
        $relationExpr = $alias !== '' ? $relation . ' as ' . $alias : $relation;

        return [$relationExpr, $column];
    }

    /**
     * Resolves relation names (and an optional constraint) into prepared
     * relational queries.
     *
     * @param string|array $relation
     * @param null|Closure $callback
     *
     * @return array<string, QueryBuilder>
     */
    private function resolveRelations($relation, $callback)
    {
        if (\is_string($relation)) {
            return $this->_model->prepareRelation([$relation => $callback]);
        }

        return $this->_model->prepareRelation((array) $relation);
    }

    /**
     * Adds the parent/child key correlation predicate to a relational query.
     *
     * @return QueryBuilder
     */
    private function correlate(QueryBuilder $relationalQuery)
    {
        if ($relationalQuery->getModel()->getRelateAs() === Model::RELATE_AS_PIVOT) {
            throw new RuntimeException('Relation aggregates and whereHas are not supported for pivot belongsToMany relations.');
        }

        $relationKey = $relationalQuery->getModel()->getActiveRelationKey();

        $relationalQuery->whereRaw(
            $this->prepareColumnName($relationKey['localKey'])
            . '=' . $relationalQuery->prepareColumnName($relationKey['foreignKey'])
        );

        return $relationalQuery;
    }
}
