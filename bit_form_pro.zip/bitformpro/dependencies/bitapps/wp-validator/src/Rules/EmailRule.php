<?php
/**
 * @license MIT
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */
namespace BitApps\BitFormPro\Deps\BitApps\WPValidator\Rules;

use BitApps\BitFormPro\Deps\BitApps\WPValidator\Rule;

class EmailRule extends Rule
{
    private $message = "The :attribute must be a valid email address";

    public function validate($value): bool
    {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    public function message()
    {
        return $this->message;
    }
}
