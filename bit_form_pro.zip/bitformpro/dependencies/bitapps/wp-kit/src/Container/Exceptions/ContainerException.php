<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Container\Exceptions;

use Exception;

/**
 * Base exception for all container resolution and binding errors.
 */
class ContainerException extends Exception
{
}
