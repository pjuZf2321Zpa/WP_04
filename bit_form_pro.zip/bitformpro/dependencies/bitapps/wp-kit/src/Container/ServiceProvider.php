<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Container;

/**
 * Base class for service providers: registers bindings on the container and optionally boots them.
 */
abstract class ServiceProvider
{
    protected Container $app;

    public function __construct(Container $app)
    {
        $this->app = $app;
    }

    /**
     * Register bindings on the container.
     */
    abstract public function register(): void;

    /**
     * Run after all providers are registered; override to perform post-registration setup.
     */
    public function boot(): void
    {
    }
}
