<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Utils;

use BitApps\BitFormPro\Deps\BitApps\WPKit\Hooks\Hooks;

final class Capabilities
{
    public static function check($cap, ...$args)
    {
        return current_user_can($cap, ...$args);
    }

    public static function filter($cap, $default = 'manage_options'): bool
    {
        return static::check($cap) || static::check(Hooks::applyFilter($cap, $default));
    }
}
