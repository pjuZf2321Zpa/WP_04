<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Configs;

final class JsonConfig
{
    protected static $decodeAsArray = true;

    public static function setDecodeAsArray($value): void
    {
        static::$decodeAsArray = $value;
    }

    public static function decodeAsArray()
    {
        return static::$decodeAsArray;
    }
}
