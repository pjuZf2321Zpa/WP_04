<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Client;

use BadMethodCallException;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Helpers\JSON;

use InvalidArgumentException;
use WP_Error;

final class HttpClient
{
    private array $_headers = [];

    private $_body;

    private bool $_hasBody = false;

    private $_formParams = [];

    private bool $_hasFormParams = false;

    private $_multipart = [];

    private $_json = [];

    private bool $_hasJson = false;

    private $_queryParams = [];

    private $_params = [];

    private $_baseUri;

    private ?string $_boundary = null;

    private ?string $_method = null;

    private $_responseHeaders = [];

    private $_requestResponse;

    private array $_options = [];

    private bool $_allowUnsafeUrls = false;

    private array $_allowedUnsafeHosts = [];

    /**
     * Undocumented function.
     *
     * @param array $config
     */
    public function __construct(array $config = [])
    {
        $this->setDefault($config);
    }

    public function __call(string $method, array $params)
    {
        $method = strtolower($method);
        if (\in_array($method, ['post', 'get', 'put', 'patch', 'delete', 'head', 'option', 'options'], true)) {
            $this->_method = $method;
            $url           = $this->buildUrl((string) ($params[0] ?? ''));

            $data    = $this->getPreparedPayload();
            $headers = $this->getHeaders();
            $options = $this->getOptions();

            return $this->request($url, $method, $data, $headers, $options);
        }

        throw new BadMethodCallException($method . ' Method not found in ' . self::class);
    }

    public function setBaseUri($uri): self
    {
        $this->_baseUri = $uri;

        return $this;
    }

    public function getBaseUri()
    {
        return $this->_baseUri;
    }

    public function setHeaders(array $headers): self
    {
        if (empty($this->_headers)) {
            $this->_headers = $headers;
        } else {
            foreach ($headers as $key => $value) {
                $this->setHeader($key, $value);
            }
        }

        return $this;
    }

    /**
     * @return mixed[]
     */
    public function getHeaders(): array
    {
        $headers = [];
        foreach ($this->_headers as $key => $value) {
            $headers[$key] = \is_array($value) ? implode(';', $value) : $value;
        }

        return $headers;
    }

    public function getHeader($key)
    {
        return $this->_headers[$key] ?? false;
    }

    public function setHeader($key, $value)
    {
        return $this->_headers[ucwords($key)][] = $value;
    }

    public function getOptions(): array
    {
        return $this->_options;
    }

    public function setOptions(array $options): self
    {
        $this->_options = $options;

        return $this;
    }

    public function allowUnsafeUrls($allow = true, array $allowedHosts = []): self
    {
        $this->_allowUnsafeUrls = (bool) $allow;
        $this->setAllowedUnsafeHosts($allowedHosts);

        return $this;
    }

    public function getAllowedUnsafeHosts(): array
    {
        return $this->_allowedUnsafeHosts;
    }

    public function setAllowedUnsafeHosts(array $hosts): self
    {
        $this->_allowedUnsafeHosts = array_values(array_unique(array_filter(array_map(
            [$this, 'normalizeHost'],
            $hosts,
        ))));

        return $this;
    }

    public function setBoundary($boundary): self
    {
        $boundary = $this->validateMultipartMetadata($boundary);
        if ($boundary === '' || \strlen($boundary) > 63 || preg_match('/^[!#$%&\'*+\-.^_`|~0-9A-Za-z]+$/D', $boundary) !== 1) {
            throw new InvalidArgumentException('Invalid multipart boundary.');
        }

        $this->_boundary = '-------' . $boundary;
        if (!empty($this->_multipart)) {
            $this->_headers['Content-Type'] = ['multipart/form-data; boundary=' . $this->_boundary];
        }

        return $this;
    }

    public function getBoundary(): string
    {
        if (!isset($this->_boundary)) {
            $this->setBoundary(wp_generate_password(24, false, false));
        }

        return $this->_boundary;
    }

    public function setContentType($contentType): self
    {
        $this->setHeader('Content-Type', $contentType);

        return $this;
    }

    public function getContentType($type)
    {
        return $this->_headers[$type] ?? '';
    }

    public function setParams($data): self
    {
        $this->_params = $data;

        return $this;
    }

    public function getParams()
    {
        return $this->_params;
    }

    public function getParam($key)
    {
        return $this->_params[$key] ?? false;
    }

    public function setParam($key, $value)
    {
        return $this->_params[$key] = $value;
    }

    public function setQueryParams($data): self
    {
        $this->_queryParams = $data;

        return $this;
    }

    public function getQueryParams()
    {
        return $this->_queryParams;
    }

    public function getQueryParam($key)
    {
        return $this->_queryParams[$key] ?? false;
    }

    public function setQueryParam($key, $value): self
    {
        if (isset($this->_queryParams[$key])) {
            if (!\is_array($this->_queryParams[$key])) {
                $this->_queryParams[$key] = [$this->_queryParams[$key]];
            }

            $this->_queryParams[$key][] = $value;
        } else {
            $this->_queryParams[$key] = $value;
        }

        return $this;
    }

    public function setBody($body): self
    {
        $this->_body    = $body;
        $this->_hasBody = true;

        return $this;
    }

    public function getBody()
    {
        return $this->_body;
    }

    public function request($url, $type, $data, $headers = null, $options = null)
    {
        $this->_responseHeaders = [];

        $defaultOptions = [
            'method'  => strtoupper($type),
            'headers' => empty($headers) ? $this->getHeaders() : $headers,
            'body'    => $data,
            'timeout' => 30,

        ];
        $options = wp_parse_args($options, $defaultOptions);

        if ($this->_allowUnsafeUrls) {
            if (!$this->isUnsafeUrlAllowed($url)) {
                $this->_requestResponse = new WP_Error('unsafe_url_not_allowed', 'Unsafe URL host is not allowlisted.');

                return $this->_requestResponse;
            }

            $options['redirection'] = 0;
            $requestResponse        = wp_remote_request($url, $options);
        } else {
            $requestResponse = wp_safe_remote_request($url, $options);
        }

        $this->_requestResponse = $requestResponse;

        if (is_wp_error($requestResponse)) {
            return $requestResponse;
        }

        $responseBody = wp_remote_retrieve_body($requestResponse);

        $decodedData = JSON::decode($responseBody);

        $this->_responseHeaders = wp_remote_retrieve_headers($requestResponse);

        return empty($decodedData) ? $responseBody : $decodedData;
    }

    public function getResponseHeaders()
    {
        return $this->_responseHeaders;
    }

    public function getResponseCode()
    {
        return wp_remote_retrieve_response_code($this->_requestResponse);
    }

    public function setDefault(array $config): void
    {
        if (isset($config['base_uri'])) {
            $this->setBaseUri($config['base_uri']);
        }

        if (isset($config['content_type'])) {
            $this->setContentType($config['content_type']);
        }

        if (isset($config['headers'])) {
            $this->setHeaders($config['headers']);
        }

        if (isset($config['body'])) {
            $this->setBody($config['body']);
        }

        if (isset($config['form_params'])) {
            $this->setFormParams($config['form_params']);
        }

        if (isset($config['json'])) {
            $this->setJson($config['json']);
        }

        if (isset($config['multipart'])) {
            $this->setMultipart($config['multipart']);
        }

        $this->allowUnsafeUrls(
            $config['allow_unsafe_urls']    ?? false,
            $config['allowed_unsafe_hosts'] ?? [],
        );
    }

    public function setJson($data): self
    {
        $this->setContentType('application/json');
        $this->_json    = $data;
        $this->_hasJson = true;

        return $this;
    }

    public function getJson()
    {
        return $this->_json;
    }

    public function setFormParams($data): self
    {
        $this->setContentType('application/x-www-form-urlencoded');
        $this->_formParams    = $data;
        $this->_hasFormParams = true;

        return $this;
    }

    public function getFormParams()
    {
        return $this->_formParams;
    }

    public function setMultipart($data): self
    {
        $this->_multipart = $data;
        $this->setMultipartContentType();

        return $this;
    }

    public function getMultipart()
    {
        return $this->_multipart;
    }

    public function getPreparedPayload()
    {
        $payload = null;
        if (!empty($this->_multipart)) {
            if ($this->_hasBody || $this->_hasFormParams || $this->_hasJson) {
                throw new InvalidArgumentException('Do not use multipart with json, params or body');
            }

            $payload = $this->getPreparedMultipart();
        } elseif (\is_string($this->getBody())) {
            $payload = $this->getBody();
        } else {
            $merged = array_merge(
                (array) $this->getBody(),
                (array) $this->getJson(),
                (array) $this->getFormParams()
            );
            if (!isset($this->_method) || $this->_method != 'get') {
                $payload = JSON::maybeEncode($merged);
            } else {
                $payload = $merged;
            }
        }

        return $payload;
    }

    public function getPreparedMultipart(): string
    {
        $multipart = '';
        $boundary  = $this->getBoundary();
        $this->setMultipartContentType();
        if (!empty($this->getMultipart()) && \is_array($this->getMultipart())) {
            foreach ($this->getMultipart() as $part) {
                if (\is_array($part) && isset($part['name'], $part['contents'])) {
                    $multipart .= '--' . $boundary . "\r\n";
                    $multipart .= 'Content-Disposition: form-data; name="' . $this->quoteMultipartValue($part['name']) . '"';
                    if (isset($part['filename'])) {
                        $multipart .= '; filename="' . $this->quoteMultipartValue($part['filename']) . '"';
                    }

                    $multipart .= "\r\n";
                    if (isset($part['headers'])) {
                        if (\is_array($part['headers'])) {
                            foreach ($part['headers'] as $key => $value) {
                                $multipart .= $this->validateMultipartHeaderName($key) . ': ';
                                $multipart .= $this->validateMultipartHeaderValue($value);
                                $multipart .= "\r\n";
                            }
                        } elseif (\is_string($part['headers'])) {
                            $multipart .= $this->validateMultipartMetadata($part['headers']) . "\r\n";
                        } else {
                            throw new InvalidArgumentException('Invalid multipart headers.');
                        }
                    }

                    $multipart .= "\r\n";
                    $multipart .= $part['contents'];
                    $multipart .= "\r\n";
                } else {
                    throw new InvalidArgumentException('Multipart must contain name, contents');
                }
            }
        }

        $multipart .= '--' . $boundary . "--\r\n";

        return $multipart;
    }

    private function buildUrl(string $path): string
    {
        $baseUri = (string) $this->_baseUri;
        $url     = $baseUri === '' ? $path : rtrim($baseUri, '/') . '/' . ltrim($path, '/');
        $query   = http_build_query($this->getQueryParams());
        if ($query === '') {
            return $url;
        }

        $fragment = '';
        if (($fragmentPosition = strpos($url, '#')) !== false) {
            $fragment = substr($url, $fragmentPosition);
            $url      = substr($url, 0, $fragmentPosition);
        }

        return $url . (str_contains($url, '?') ? '&' : '?') . $query . $fragment;
    }

    private function setMultipartContentType(): void
    {
        $this->_headers['Content-Type'] = ['multipart/form-data; boundary=' . $this->getBoundary()];
    }

    private function quoteMultipartValue($value): string
    {
        return addcslashes($this->validateMultipartMetadata($value), '\\"');
    }

    private function validateMultipartMetadata($value): string
    {
        if (!\is_scalar($value) || preg_match('/[\r\n\0]/', (string) $value)) {
            throw new InvalidArgumentException('Invalid multipart metadata.');
        }

        return (string) $value;
    }

    private function validateMultipartHeaderName(int|string $name): string
    {
        if (!\is_string($name) || preg_match('/^[!#$%&\'*+\-.^_`|~0-9A-Za-z]+$/D', $name) !== 1) {
            throw new InvalidArgumentException('Invalid multipart header name.');
        }

        return $name;
    }

    private function validateMultipartHeaderValue($value): string
    {
        if (\is_array($value)) {
            $value = array_map([$this, 'validateMultipartMetadata'], $value);

            return implode(';', $value);
        }

        return $this->validateMultipartMetadata($value);
    }

    private function normalizeHost($host): string
    {
        if (!\is_string($host)) {
            return '';
        }

        $host = trim($host);
        if ($host === '') {
            return '';
        }

        if (str_starts_with($host, '[') && str_ends_with($host, ']')) {
            $host = substr($host, 1, -1);
            if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false) {
                return '';
            }
        }

        if ($host === '' || filter_var($host, FILTER_VALIDATE_IP) !== false) {
            return strtolower($host);
        }

        $host = strtolower($host);
        if (str_ends_with($host, '.')) {
            $host = substr($host, 0, -1);
        }

        if ($host === '' || filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) === false) {
            return '';
        }

        return $host;
    }

    private function isUnsafeUrlAllowed($url): bool
    {
        $urlParts = wp_parse_url($url);
        if (!\is_array($urlParts) || !isset($urlParts['scheme'], $urlParts['host'])) {
            return false;
        }

        $scheme = strtolower($urlParts['scheme']);
        $host   = $this->normalizeHost($urlParts['host']);

        return \in_array($scheme, ['http', 'https'], true)
            && $host !== ''
            && \in_array($host, $this->_allowedUnsafeHosts, true);
    }
}
