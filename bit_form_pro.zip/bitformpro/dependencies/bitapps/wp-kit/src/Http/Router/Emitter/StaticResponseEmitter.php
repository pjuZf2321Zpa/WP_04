<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Emitter;

use Stringable;
use UnexpectedValueException;

final class StaticResponseEmitter implements ResponseEmitter
{
    public function emit(array $response): string
    {
        $data = $response['data']['data'] ?? null;
        if ($data === null) {
            return '';
        }

        if (\is_string($data)) {
            return $data;
        }

        if (\is_scalar($data) || $data instanceof Stringable) {
            return (string) $data;
        }

        throw new UnexpectedValueException('Static route actions must return string-compatible content.');
    }
}
