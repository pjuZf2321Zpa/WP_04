<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router;

use RuntimeException;

final class MiddlewareConfigurationException extends RuntimeException
{
}
