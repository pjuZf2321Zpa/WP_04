<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Emitter;

final class AjaxResponseEmitter implements ResponseEmitter
{
    public function emit(array $response): void
    {
        if (!headers_sent() && $response['headers']) {
            foreach ($response['headers'] as $key => $value) {
                header("{$key}: {$value}");
            }
        }

        wp_send_json($response['data'], $response['http_status']);
    }
}
