<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Router\Emitter;

interface ResponseEmitter
{
    /**
     * Formats and/or sends the response snapshot for one transport.
     *
     * @param array $response ['data' => array, 'http_status' => int, 'headers' => array]
     *
     * @return mixed
     */
    public function emit(array $response);
}
