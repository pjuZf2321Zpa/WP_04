<?php

/**
 * Provides IP related functionality.
 *
 * @license GPL-2.0-or-later
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\BitApps\WPKit\Http;

use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Detection\ClientIpResolver;
use BitApps\BitFormPro\Deps\BitApps\WPKit\Http\Detection\UserAgent;

trait IpTool
{
    /**
     * Provide user details.
     *
     * @return array user details array
     */
    public static function getUserDetail()
    {
        return self::setUserDetail();
    }

    /**
     * Provide user IP address.
     *
     * @return string|false IP address of current visitor
     */
    public static function ip()
    {
        return ClientIpResolver::checkIP();
    }

    /**
     * Set proxy addresses or CIDR ranges that may supply X-Forwarded-For.
     *
     * @param array $proxies
     */
    public static function setTrustedProxies(array $proxies)
    {
        ClientIpResolver::setTrustedProxies($proxies);
    }

    public function device()
    {
        return UserAgent::checkDevice();
    }

    public function user()
    {
        if (is_user_logged_in()) {
            return wp_get_current_user();
        }

        return false;
    }

    /**
     * Set user details ip,cdevice, user_id, user's visited page, current mysql formatted time.
     *
     * @return array of user details
     */
    private static function setUserDetail(): array
    {
        $userDetails['ip']     = ip2long(ClientIpResolver::checkIP());
        $userDetails['device'] = UserAgent::checkDevice();
        $userDetails['id']     = get_current_user_id();
        $userDetails['page']   = \is_object(get_post()) ? get_permalink(get_post()->ID) : null;
        $userDetails['time']   = current_time('mysql');

        return $userDetails;
    }
}
