<?php
/**
 * @license GPL-2.0-only
 *
 * Modified on 05-November-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitApps\BitFormPro\Deps\Mpdf\Barcode;

class BarcodeException extends \BitApps\BitFormPro\Deps\Mpdf\MpdfException
{

}
