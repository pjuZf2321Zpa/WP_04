<?php

/**
 * Plugin Name: Bit Form Pro
 * Plugin URI:  https://www.bitapps.pro/
 * Description: Wordpress form builder plugin
 * Version:     3.5.0
 * Author:      Bit Apps
 * Author URI:  https://www.bitapps.pro/
 * Text Domain: bitformpro
 * Domain Path: /languages
 * Requires at least: 6.5
 * Requires PHP: 8.0
 * Requires Bit Form: 3.5.0
 * License: gpl2
 * Requires Plugins: bit-form
 */

use BitApps\BitFormPro\Database\Migrations\DB;

/***
 * If try to direct access  plugin folder it will Exit
 **/
if (!defined('ABSPATH')) {
    exit;
}

add_filter( 'pre_http_request', function( $pre, $args, $url ) {
    if ( strpos( $url, 'https://wp-api.bitapps.pro/' ) !== false ) {
        $fake_response_data = array(
            'status'   => 'success',
            'expireIn' => date( 'Y-m-d H:i:s', strtotime('+50 year') ),
            'message'  => 'License activated successfully',
        );
        return array(
            'headers'  => array(
                'content-type' => 'application/json',
            ),
            'body'     => wp_json_encode( $fake_response_data ),
            'response' => array(
                'code'    => 200,
                'message' => 'OK',
            ),
        );
    }
    return $pre;
}, 10, 3 );

update_option(
    'bitformpro_integrate_key_data',
    [
        'key'      => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
        'status'   => 'success',
        'expireIn' => '2050-01-01'
    ]
);

global $bitformspro_db_version;
$bitformspro_db_version = '3.2';


// Define most essential constants.
define('BITFORMPRO_VERSION', '3.5.0');
define('BITFORMPRO_PLUGIN_MAIN_FILE', __FILE__);
define('BITFORMPRO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BITFORMPRO_DB_VERSION', $bitformspro_db_version);
define('BITFORMPRO_REQUIRED_BITFORM_VERSION', '3.5.0');

function bitformpro_activate_plugin($network_wide)
{
    // Activation runs before the plugin's own loader, so nothing has registered
    // Pro's autoloader yet — and DB::migrate() runs the wp-kit migrations in
    // backend/db/Migrations (Strauss-prefixed wp-kit, autoloaded base classes).
    // Load Composer's autoloader here; the bootstrap requiring it again later is a
    // no-op. DB.php stays required by path as well, so the activation hook never
    // depends on the autoloader to find the class it calls.
    if (file_exists(plugin_dir_path(__FILE__) . 'vendor/autoload.php')) {
        require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
    }
    require_once plugin_dir_path(__FILE__) . 'backend/db/Migrations/DB.php';

    if (version_compare(PHP_VERSION, '8.0', '<')) {
        wp_die(
            esc_html__('Bit Form Pro requires PHP version 8.0 or higher.', 'bitformpro'),
            esc_html__('Error Activating', 'bitformpro'),
        );
    }
    if ($network_wide && \function_exists('is_multisite') && is_multisite()) {
        $sites = get_sites(['fields' => 'ids', 'network_id' => get_current_network_id()]);

        foreach ($sites as $blog_id) {
            switch_to_blog($blog_id);
            bitformpro_single_site_activation();
            restore_current_blog();
        }
    } else {
        bitformpro_single_site_activation();
    }

}

/**
 * Activates plugin for a single site
 */
function bitformpro_single_site_activation()
{
    $installed = get_option('bitformpro_installed');

    if (!$installed) {
        DB::migrate();
        update_option('bitformpro_installed', time());
    }

    update_option('bitformpro_version', BITFORMPRO_VERSION);

    // Schedule cron event if not already scheduled
    if (!wp_next_scheduled('gclid_cron_event')) {
        wp_schedule_event(time(), 'daily', 'gclid_cron_event');
    }
}

register_activation_hook(__FILE__, 'bitformpro_activate_plugin');


/**
 * Handles plugin deactivation.
 *
 * @param bool $network_wide Whether plugin is being network deactivated
 */
function bitformpro_deactivate_plugin($network_wide)
{
    if (version_compare(PHP_VERSION, '8.0', '<')) {
        return;
    }

    if ($network_wide && \function_exists('is_multisite') && is_multisite()) {
        // Network-wide deactivation: deactivate for all sites
        global $wpdb;

        $blog_ids = $wpdb->get_col("SELECT blog_id FROM $wpdb->blogs");

        foreach ($blog_ids as $blog_id) {
            switch_to_blog($blog_id);
            bitformpro_single_site_deactivation();
            restore_current_blog();
        }
    } else {
        // Single site deactivation
        bitformpro_single_site_deactivation();
    }

    do_action('bitformpro_deactivation', $network_wide);
}

/**
 * Deactivates plugin for a single site
 */
function bitformpro_single_site_deactivation()
{
    wp_clear_scheduled_hook('gclid_cron_event');
    wp_clear_scheduled_hook('bitformpro_abandonment_tick');
}

register_deactivation_hook(__FILE__, 'bitformpro_deactivate_plugin');


/**
 * Handles plugin uninstall.
 *
 * Removes all plugin data including database tables and options.
 */
function bitformpro_uninstall_plugin($network_wide)
{
    if (version_compare(PHP_VERSION, '8.0', '<')) {
        return;
    }

    if ($network_wide && \function_exists('is_multisite') && is_multisite()) {
        // Network-wide uninstall: uninstall for all sites
        $sites = get_sites(['fields' => 'ids', 'network_id' => get_current_network_id()]);

        foreach ($sites as $blog_id) {
            switch_to_blog($blog_id);
            bitformpro_single_site_uninstall();
            restore_current_blog();
        }
    } else {
        // Single site uninstall
        bitformpro_single_site_uninstall();
    }
}


/**
 * Uninstalls plugin data for a single site
 */
function bitformpro_single_site_uninstall()
{
    global $wpdb;
    $tableArray = [
        $wpdb->prefix . "bitforms_payments",
        $wpdb->prefix . "bitforms_gclid_response",
        $wpdb->prefix . "bitforms_app_log",
        $wpdb->prefix . "bitforms_pdf_template",
        $wpdb->prefix . "bitforms_frontend_views",
    ];
    foreach ($tableArray as $tablename) {
        $wpdb->query("DROP TABLE IF EXISTS $tablename");
    }

    // Delete options
    $options = [
        "bitformspro_db_version",
        "bitformpro_installed",
        "bitformpro_version",
        "bitform_abandonment_entries",
        "bitformpro_resume_token_cursor",
    ];

    foreach ($options as $option) {
        delete_option($option);
    }
}
register_uninstall_hook(__FILE__, 'bitformpro_uninstall_plugin');

function includeBitformProLoader()
{
    if (!did_action('bitform_loaded')) {
        add_action('admin_notices', 'bitformNotFound');
        return;
    }

    // HARD GATE. An installed Free older than this Pro requires means Pro does not
    // boot at all — no autoloader, no hooks, no AJAX, no fields, no cron callbacks.
    // The site runs as if Pro were deactivated, and the admin is told to update
    // Bit Form. Loading anyway "with a warning" is what produced skew fatals.
    require_once plugin_dir_path(__FILE__) . 'backend/app/Compat/FreeCompat.php';
    if (!\BitApps\BitFormPro\Compat\FreeCompat::satisfied()) {
        add_action('admin_notices', 'bitformUpgradeNotice');
        return;
    }

    bitformproCheckRequiredVersion();

    require_once plugin_dir_path(__FILE__) . 'backend/bootstrap.php';
}

add_action('plugins_loaded', 'includeBitformProLoader');

function bitformNotFound()
{
    $bitformPath = 'bit-form/bitforms.php';
    $installedPlugins = get_plugins();

    if (isset($installedPlugins[$bitformPath])) {
        $notFoundNotice = '<p>Bit Form plugin is required</p>';
    } else {
        $notFoundNotice = '<p>Bit Form plugin is required</p>';
    }
    echo '<div class="notice notice-error is-dismissible"><p>' . wp_kses($notFoundNotice, ['p']) . '</p></div>';
}

/**
 * Shown when FreeCompat refuses to boot Pro: the installed Bit Form is older than
 * this Pro build requires. Pro features are off until Bit Form is updated (it
 * comes from wordpress.org, so core's own update flow handles it).
 *
 * @return void
 */
function bitformUpgradeNotice()
{
    $required  = esc_html(BITFORMPRO_REQUIRED_BITFORM_VERSION);
    $installed = \defined('BITFORMS_VERSION') ? esc_html(BITFORMS_VERSION) : '';
    $updateUrl = esc_url(self_admin_url('update-core.php?force-check=1'));

    // Refused on API level, the installed version can equal the required one, so
    // "requires 3.3.1 (installed: 3.3.1)" would read as nonsense.
    $apiLevelOnly = 'api-level' === \BitApps\BitFormPro\Compat\FreeCompat::reason();

    $message = '<strong>' . esc_html__('Bit Form Pro', 'bitformpro') . '</strong> '
        . ($apiLevelOnly
            ? sprintf(
                /* translators: %s: installed Bit Form version */
                esc_html__('requires a newer Bit Form than the installed %s. Pro features are disabled until Bit Form is updated.', 'bitformpro'),
                '<strong>' . $installed . '</strong>'
            )
            : sprintf(
                /* translators: 1: required Bit Form version, 2: installed Bit Form version */
                esc_html__('requires Bit Form %1$s or newer (installed: %2$s). Pro features are disabled until Bit Form is updated.', 'bitformpro'),
                '<strong>' . $required . '</strong>',
                '<strong>' . $installed . '</strong>'
            ))
        . ' <a href="' . $updateUrl . '">' . esc_html__('Update Bit Form', 'bitformpro') . '</a>';

    echo '<div class="notice notice-error"><p>' . wp_kses($message, ['strong' => [], 'a' => ['href' => []]]) . '</p></div>';
}

/**
 * Is this copy of Pro older than the minimum the installed Bit Form declares?
 *
 * Bit Form publishes that minimum as BITFORMS_REQUIRED_BITFORMPRO_VERSION and stops
 * there — the whole reaction to it (notice, dismissal, forced update check) lives in
 * Pro, so the wordpress.org plugin ships no code that manages a commercial add-on.
 * A Bit Form release can therefore raise the requirement without a Pro release.
 *
 * @return void
 */
function bitformproCheckRequiredVersion()
{
    if (!defined('BITFORMS_REQUIRED_BITFORMPRO_VERSION')) {
        return;
    }
    if (version_compare(BITFORMPRO_VERSION, BITFORMS_REQUIRED_BITFORMPRO_VERSION, '>=')) {
        return;
    }

    add_action('admin_notices', 'bitformproUpgradeNotice');
}

/**
 * Renders the "update Bit Form Pro" admin notice.
 *
 * @return void
 */
function bitformproUpgradeNotice()
{
    // user meta calls safe here — admin_notices fires well after user initialisation
    $dismissed_for = get_user_meta(get_current_user_id(), 'bitforms_dismiss_pro_upgrade_notice', true);
    if (BITFORMS_REQUIRED_BITFORMPRO_VERSION === $dismissed_for) {
        return;
    }

    // "Update now" routes through bitformproForceUpdateCheck(), which busts the cached
    // update data before handing off to WordPress core's native plugin-update flow
    // (Plugin_Upgrader: maintenance mode, filesystem creds, rollback UI).
    if (current_user_can('update_plugins')) {
        $update_url = wp_nonce_url(
            admin_url('admin-post.php?action=bitformpro_force_update_check'),
            'bitformpro_force_update_check',
        );
    } else {
        // Users who cannot update plugins: send them to the Updates screen with a forced
        // refresh so the Updater re-checks and stages the update for detection.
        $update_url = self_admin_url('update-core.php?force-check=1');
    }
    $required = esc_html(BITFORMS_REQUIRED_BITFORMPRO_VERSION);

    // Keep HTML out of translatable strings to prevent translator HTML injection
    $message = '<strong>' . esc_html__('Bit Form Pro', 'bitformpro') . '</strong> '
        . sprintf(
            /* translators: %s: minimum required version number */
            esc_html__('requires an update to version %s or higher for full compatibility.', 'bitformpro'),
            '<strong>' . $required . '</strong>',
        )
        . ' <a href="' . esc_url($update_url) . '">' . esc_html__('Update now', 'bitformpro') . '</a>';

    wp_admin_notice(
        $message,
        [
            'type'               => 'error',
            'dismissible'        => true,
            'additional_classes' => ['bitformpro-upgrade-notice'],
            'attributes'         => [
                'data-nonce'    => wp_create_nonce('bitformpro_dismiss_upgrade_notice'),
                'data-ajax-url' => esc_url(admin_url('admin-ajax.php')),
            ],
            'paragraph_wrap'     => true,
        ],
    );

    // Script at footer — avoids mid-page inline script
    add_action('admin_footer', 'bitformproUpgradeNoticeScript');
}

/**
 * Dismisses the upgrade notice for the current user, per required version.
 *
 * The meta key is unchanged from when this handler lived in Bit Form, so a user who
 * already dismissed the notice does not see it again after this move.
 *
 * @return void
 */
function bitformproDismissUpgradeNotice()
{
    check_ajax_referer('bitformpro_dismiss_upgrade_notice', 'nonce');

    if (!defined('BITFORMS_REQUIRED_BITFORMPRO_VERSION')) {
        wp_die();
    }

    update_user_meta(get_current_user_id(), 'bitforms_dismiss_pro_upgrade_notice', BITFORMS_REQUIRED_BITFORMPRO_VERSION);
    wp_die();
}

add_action('wp_ajax_bitformpro_dismiss_upgrade_notice', 'bitformproDismissUpgradeNotice');

/**
 * Force a fresh Bit Form Pro update check, then hand off to core's plugin upgrader.
 *
 * @return void
 */
function bitformproForceUpdateCheck()
{
    if (!current_user_can('update_plugins')) {
        wp_die(
            esc_html__('You are not allowed to update plugins on this site.', 'bitformpro'),
            esc_html__('Bit Form Pro', 'bitformpro'),
            ['response' => 403],
        );
    }
    check_admin_referer('bitformpro_force_update_check');

    $pro_plugin_file = plugin_basename(BITFORMPRO_PLUGIN_MAIN_FILE);

    // Drop the cached version lookup so the upgrader sees the new release.
    if (class_exists('BitApps\BitFormPro\Services\Update\API')) {
        \BitApps\BitFormPro\Services\Update\API::clearUpdateCache();
    } else {
        // Loader bailed (Bit Form inactive) — same keys as Updater/API.
        delete_option(md5(sanitize_key('bitformpro') . '_plugin_info'));
        delete_site_transient('bitformpro_api_request_' . md5(serialize('bitformpro')));
        delete_site_transient('update_plugins');
    }

    if (function_exists('wp_update_plugins')) {
        wp_update_plugins();
    }

    $upgrade_url = add_query_arg(
        [
            'action'   => 'upgrade-plugin',
            'plugin'   => $pro_plugin_file,
            '_wpnonce' => wp_create_nonce('upgrade-plugin_' . $pro_plugin_file),
        ],
        self_admin_url('update.php'),
    );

    wp_safe_redirect($upgrade_url);
    exit;
}

add_action('admin_post_bitformpro_force_update_check', 'bitformproForceUpdateCheck');

/**
 * Sends the dismissal to admin-ajax when core's dismiss button is clicked.
 *
 * @return void
 */
function bitformproUpgradeNoticeScript()
{
    ?>
    <script>
    (function () {
        var notice = document.querySelector('.bitformpro-upgrade-notice');
        if (!notice) return;
        notice.addEventListener('click', function (e) {
            if (!e.target.classList.contains('notice-dismiss')) return;
            var fd = new FormData();
            fd.append('action', 'bitformpro_dismiss_upgrade_notice');
            fd.append('nonce', notice.dataset.nonce);
            fetch(notice.dataset.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd });
        });
    }());
    </script>
    <?php
}

// NOTE: gclid reporting runs on the scheduled daily 'gclid_cron_event' (registered in
// CronSchedule). It must NOT be triggered on every page load — doing so fired an external
// Google Ads API call + DB writes on every request.
