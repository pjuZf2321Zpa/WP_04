<?php
/**
 * Uninstall SigmaForms
 *
 * @package SigmaForms
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Access the database via SQL
global $wpdb;

// Get option from the database - check if we should delete data on uninstall
// Try new prefix first, fallback to old prefix for backward compatibility
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local variables in uninstall script, not global
$delete_data = get_option('sf_delete_data_on_uninstall', get_option('saigf_delete_data_on_uninstall', false));

if ($delete_data) {
    // Define tables to be dropped
    $tables = [
        $wpdb->prefix . 'sigmaforms',
        $wpdb->prefix . 'sigmaforms_abandoned_forms',
        $wpdb->prefix . 'sigmaforms_referrers',
        $wpdb->prefix . 'sigmaforms_submissions',
        $wpdb->prefix . 'sigmaforms_views',
    ];
    
    foreach ($tables as $table) {
        // Sanitize table name just for extra safety (optional if hardcoded)
        $table = esc_sql( $table );
    
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
        $wpdb->query("DROP TABLE IF EXISTS `$table`");
    }

    // Delete the plugin's options and transients. The "_" in a LIKE pattern
    // matches any character, so it is escaped with esc_like(): a bare
    // 'sf_%' also matched other plugins' options such as sfsi_* and sfwd-*.
    // "sigmaforms_" covers sigmaforms_settings and the license options
    // (SigmaForms_lic_*); LIKE is case-insensitive here. The sigmaforms_
    // transients come from the license updater.
    $sf_prefixes = ['sf_', 'saigf_', 'sigmaforms_', '_transient_sf_', '_transient_timeout_sf_', '_transient_sigmaforms_', '_transient_timeout_sigmaforms_'];

    foreach ($sf_prefixes as $sf_prefix) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like($sf_prefix) . '%'));
    }
}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
