<?php

/**
 * Plugin Name: SigmaForms Pro – AI Generated Forms
 * Plugin URI: https://bdthemes.com/plugin/sigma-forms/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro
 * Description: A lightweight, AI-powered form builder plugin for WordPress. Generate and manage contact or lead forms easily using natural language. Visit <a href="https://bdthemes.com/plugin/sigma-forms/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro">SigmaForms Pro</a> for more information.
 * Version: 1.7.0
 * Author: bdthemes
 * Author URI: https://bdthemes.com
 * Text Domain: sigmaforms-pro
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Requires at least: 6.0
 * Tested up to: 7.1
 * Requires PHP: 7.4
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('SF_VERSION', '1.7.0');
define('SF_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SF_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('SF_PROXY_URL', 'https://callback.bdthemes.com');

/**
 * GPL Vault: licences this install locally -- the plugin's own activation flow is
 * answered in-process, so nothing reaches the vendor's licence server. Match the
 * host exactly: callback.bdthemes.com is the live cloud-storage OAuth broker and
 * must keep working. Remove down to "END GPL Vault" to restore upstream behaviour.
 */
function sigmaforms_pro_gv_crypt($data, $password, $decrypt = false) {
    $cipher = 'aes-256-cbc';
    $key    = substr(hash('sha256', $password, true), 0, 32);
    $iv     = substr(strtoupper(md5($password)), 0, 16);

    if ($decrypt) {
        return substr(openssl_decrypt(base64_decode($data), $cipher, $key, OPENSSL_RAW_DATA, $iv), 2, -2);
    }

    $rand_func = function_exists('wp_rand') ? 'wp_rand' : 'rand';
    $data      = $rand_func(10, 99) . $data . $rand_func(10, 99);

    return base64_encode(openssl_encrypt($data, $cipher, $key, OPENSSL_RAW_DATA, $iv));
}

function sigmaforms_pro_gv_license_response($pre, $args, $url) {
    if ('licenses.bdthemes.co' !== wp_parse_url($url, PHP_URL_HOST)) {
        return $pre;
    }

    $path       = (string) wp_parse_url($url, PHP_URL_PATH);
    $class_vars = get_class_vars('\SigmaForms\License\Base');
    $key        = !empty($class_vars['key']) ? $class_vars['key'] : '826FCBE2B785472A';

    if (false !== strpos($path, '/product/update/')) {
        $body = wp_json_encode(array('status' => false));
    } elseif (false !== strpos($path, '/product/deactive/')) {
        $body = sigmaforms_pro_gv_crypt(wp_json_encode(array(
            'status' => true,
            'msg'    => 'License deactivated successfully',
        )), $key);
    } else {
        $param   = json_decode(sigmaforms_pro_gv_crypt(isset($args['body']) ? $args['body'] : '', $key, true));
        $domain  = (is_object($param) && !empty($param->domain)) ? $param->domain : site_url();
        $license = (object) array(
            'is_valid'         => true,
            'request_duration' => 8760,
            'expire_date'      => 'No Expiry',
            'support_end'      => 'Unlimited',
            'license_title'    => 'Agency Lifetime',
            'renew_link'       => '',
            'other_param'      => array('WL'),
        );

        $body = sigmaforms_pro_gv_crypt(wp_json_encode(array(
            'status' => true,
            'msg'    => 'License activated successfully',
            'data'   => sigmaforms_pro_gv_crypt(serialize($license), $domain),
        )), $key);
    }

    return array(
        'headers'  => array(),
        'body'     => $body,
        'response' => array('code' => 200, 'message' => 'OK'),
        'cookies'  => array(),
        'filename' => null,
    );
}

function sigmaforms_pro_gv_cache_blob() {
    static $blob = null;
    if (null !== $blob) {
        return $blob;
    }

    $domain = sigmaforms_pro_gv_domain();
    $record = (object) array(
        'is_valid'           => true,
        'next_request'       => time() + 3153600000,
        'expire_date'        => 'No Expiry',
        'support_end'        => 'Unlimited',
        'license_title'      => 'Agency Lifetime',
        'license_key'        => '1415B451BE1A13C283BA771EA52D38BB',
        'msg'                => 'Active',
        'renew_link'         => '',
        'expire_renew_link'  => '',
        'support_renew_link' => '',
        'other_param'        => array('WL'),
    );

    $blob = sigmaforms_pro_gv_crypt(serialize($record), $domain);
    return $blob;
}

function sigmaforms_pro_gv_domain() {
    if (function_exists('is_multisite') && is_multisite()
        && is_callable(array('\SigmaForms\License\Base', 'is_network_activated')) && \SigmaForms\License\Base::is_network_activated()
        && function_exists('get_main_site_id')) {
        return get_site_url(get_main_site_id());
    }
    return site_url();
}

require_once plugin_dir_path(__FILE__) . 'includes/License/Base.php';

if (class_exists('\SigmaForms\License\Base')) {
    // Callbacks are registered as closures, not name strings: this main file may
    // declare a namespace, in which case a bare 'func' string would resolve in the
    // global namespace and fatal ("function not found"). Closures capture the
    // correct (namespaced) sibling functions.
    add_filter('pre_http_request', function ($pre, $args, $url) {
        return sigmaforms_pro_gv_license_response($pre, $args, $url);
    }, 10, 3);

    // Force the framework's encrypted licence record to read valid. Every gate
    // funnels through get_register_info() -> this option, and pre_option wins over
    // the vendor's own empty-key cache wipe, so no salted-key matching is needed.
    // product_id/product_base/key are private, so they are baked in here rather
    // than read via get_class_vars() (which only sees public properties).
    $sigmaforms_pro_gv_key_name = hash(
        'crc32b',
        sigmaforms_pro_gv_domain() . __FILE__ . '13' . 'sigmaforms' . '826FCBE2B785472A' . 'LIC'
    );
    $sigmaforms_pro_gv_blob = function () { return sigmaforms_pro_gv_cache_blob(); };
    add_filter('pre_option_' . $sigmaforms_pro_gv_key_name, $sigmaforms_pro_gv_blob);
    add_filter('pre_site_option_' . $sigmaforms_pro_gv_key_name, $sigmaforms_pro_gv_blob);
    unset($sigmaforms_pro_gv_key_name, $sigmaforms_pro_gv_blob);

    // Seed the licence-key option under BOTH the salted name (what most gates read)
    // and the plain base name (what some free-companion gates read, e.g. Store Kit's
    // usk_license_validation()), plus the email, so no gate fast-fails on an empty key.
    foreach (array(\SigmaForms\License\Base::get_lic_key_param('SigmaForms_lic_Key'), 'SigmaForms_lic_Key') as $sigmaforms_pro_gv_opt) {
        if ('' === trim((string) get_option($sigmaforms_pro_gv_opt, ''))) {
            update_option($sigmaforms_pro_gv_opt, '1415B451BE1A13C283BA771EA52D38BB');
        }
    }
    if ('' === trim((string) get_option('SigmaForms_lic_email', ''))) {
        update_option('SigmaForms_lic_email', 'license@example.com');
    }
    unset($sigmaforms_pro_gv_opt);
}
// END GPL Vault.

require_once SF_PLUGIN_DIR . 'includes/sigmaforms-white-label-bootstrap.php';

// Autoloader
spl_autoload_register(function ($class) {
    // Project-specific namespace prefix
    $prefix = 'SigmaForms\\';

    // Base directory for the namespace prefix
    $base_dir = SF_PLUGIN_DIR . 'includes/';

    // Check if the class uses the namespace prefix
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    // Get the relative class name
    $relative_class = substr($class, $len);

    // Replace the namespace prefix with the base directory, replace namespace
    // separators with directory separators in the relative class name, append
    // with .php
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    // If the file exists, require it
    if (file_exists($file)) {
        require $file;
    }
});

// Plugin activation
register_activation_hook(__FILE__, function () {
    require_once SF_PLUGIN_DIR . 'includes/Activation.php';
    \SigmaForms\Activation::activate();
});

// Plugin deactivation
register_deactivation_hook(__FILE__, function () {
    require_once SF_PLUGIN_DIR . 'includes/Deactivation.php';
    \SigmaForms\Deactivation::deactivate();
});

// Initialize plugin
add_action('plugins_loaded', function () {
    require_once SF_PLUGIN_DIR . 'includes/Plugin.php';
    $plugin = new \SigmaForms\Plugin();
    $plugin->init();

    // Make plugin instance globally available for widgets
    global $sigmaforms_plugin;
    $sigmaforms_plugin = $plugin;
});

// Initialize License Management System
if (class_exists('SigmaForms\License\Base')) {
    \SigmaForms\License\Base::get_instance(SF_PLUGIN_DIR . 'sigmaforms-pro.php');
}

