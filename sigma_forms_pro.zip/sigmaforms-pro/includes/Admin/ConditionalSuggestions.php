<?php
/**
 * Conditional Suggestions class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

class ConditionalSuggestions {
    
    /**
     * Generate condition suggestions based on field type
     *
     * @param string $field_type Type of the field
     * @param string $field_id ID of the field
     * @return array Array of condition suggestions
     */
    public function get_field_condition_suggestions($field_type, $field_id) {
        $suggestions = [];
        
        // Common suggestions based on field type
        switch ($field_type) {
            case 'text':
            case 'email':
            case 'textarea':
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'logged_in',
                                    'operator' => '=',
                                    'value' => 'true'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show only for logged-in users',
                    'description' => 'Display this field only when a user is logged into the website.'
                ];
                
                $suggestions[] = [
                    'action' => 'hide',
                    'logic_type' => 'any',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '=',
                                    'value' => 'subscriber'
                                ],
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '=',
                                    'value' => 'customer'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Hide from subscribers and customers',
                    'description' => 'Hide this field from users with subscriber or customer roles.'
                ];
                
                $suggestions[] = [
                    'action' => 'disable',
                    'logic_type' => 'any',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_day',
                                    'operator' => '=',
                                    'value' => 'Saturday'
                                ],
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_day',
                                    'operator' => '=',
                                    'value' => 'Sunday'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Disable on weekends',
                    'description' => 'Disable this field on Saturday and Sunday.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_time',
                                    'operator' => '>',
                                    'value' => '09:00'
                                ],
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_time',
                                    'operator' => '<',
                                    'value' => '17:00'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show during business hours only',
                    'description' => 'Display this field only during business hours (9 AM - 5 PM).'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'country',
                                    'operator' => '=',
                                    'value' => 'United States'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for US residents only',
                    'description' => 'Display this field only when country is set to United States.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'any',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'contact_preference',
                                    'operator' => '=',
                                    'value' => 'email'
                                ],
                                [
                                    'source_type' => 'field',
                                    'field' => 'newsletter_signup',
                                    'operator' => 'is_checked',
                                    'value' => ''
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show when email contact is preferred',
                    'description' => 'Display when user prefers email contact or signs up for newsletter.'
                ];
                break;
                
            case 'number':
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'age',
                                    'operator' => '>=',
                                    'value' => '18'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for adults only',
                    'description' => 'Display this field only when age is 18 or older.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'income',
                                    'operator' => '>',
                                    'value' => '50000'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for high-income users',
                    'description' => 'Display this field only when income exceeds $50,000.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'quantity',
                                    'operator' => '>=',
                                    'value' => '10'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for bulk orders',
                    'description' => 'Display this field only when quantity is 10 or more.'
                ];
                break;
                
            case 'checkbox':
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'age',
                                    'operator' => '>=',
                                    'value' => '18'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for adults only',
                    'description' => 'Display this checkbox only when age is 18 or older.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'account_type',
                                    'operator' => '=',
                                    'value' => 'premium'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for premium accounts',
                    'description' => 'Display this checkbox only for premium account holders.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '!=',
                                    'value' => 'guest'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Hide from guests',
                    'description' => 'Display this checkbox only for registered users.'
                ];
                break;
                
            case 'select':
            case 'radio':
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '=',
                                    'value' => 'administrator'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show only for administrators',
                    'description' => 'Display this field only for users with administrator role.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'any',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '=',
                                    'value' => 'editor'
                                ],
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '=',
                                    'value' => 'administrator'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for editors and admins',
                    'description' => 'Display this field for users with editor or administrator roles.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'membership_level',
                                    'operator' => '!=',
                                    'value' => 'basic'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for non-basic members',
                    'description' => 'Display this field for all membership levels except basic.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'region',
                                    'operator' => 'contains',
                                    'value' => 'Europe'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for European regions',
                    'description' => 'Display this field when region contains "Europe".'
                ];
                break;
                
            case 'date':
                $suggestions[] = [
                    'action' => 'enable',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_date',
                                    'operator' => 'before_date',
                                    'value' => gmdate('Y-m-d', strtotime('+30 days'))
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Enable for next 30 days only',
                    'description' => 'Enable this field only if current date is within the next 30 days.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'event_type',
                                    'operator' => '=',
                                    'value' => 'scheduled'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for scheduled events',
                    'description' => 'Display this date field only when event type is scheduled.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_date',
                                    'operator' => 'after_date',
                                    'value' => gmdate('Y-m-d')
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Enable for future dates only',
                    'description' => 'Enable this field only for dates in the future.'
                ];
                break;
                
            case 'file':
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'logged_in',
                                    'operator' => '=',
                                    'value' => 'true'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show only for logged-in users',
                    'description' => 'Display file upload field only for authenticated users.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'application_type',
                                    'operator' => '=',
                                    'value' => 'job_application'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for job applications',
                    'description' => 'Display file upload when application type is job application.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'has_documents',
                                    'operator' => 'is_checked',
                                    'value' => ''
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show when documents are needed',
                    'description' => 'Display file upload when "has documents" checkbox is checked.'
                ];
                break;
                
            case 'phone':
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'contact_method',
                                    'operator' => '=',
                                    'value' => 'phone'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show when phone contact preferred',
                    'description' => 'Display phone field when phone is the preferred contact method.'
                ];
                
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'field',
                                    'field' => 'emergency_contact',
                                    'operator' => 'is_checked',
                                    'value' => ''
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show for emergency contact',
                    'description' => 'Display phone field when emergency contact is needed.'
                ];
                break;
                
            default:
                // Generic advanced suggestions for any field type
                $suggestions[] = [
                    'action' => 'show',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_time',
                                    'operator' => '>',
                                    'value' => '09:00'
                                ],
                                [
                                    'source_type' => 'date',
                                    'field' => 'current_time',
                                    'operator' => '<',
                                    'value' => '17:00'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Show during business hours',
                    'description' => 'Display this field only during business hours (9 AM - 5 PM).'
                ];
                
                $suggestions[] = [
                    'action' => 'hide',
                    'logic_type' => 'all',
                    'groups' => [
                        [
                            'rules' => [
                                [
                                    'source_type' => 'user',
                                    'field' => 'user_role',
                                    'operator' => '=',
                                    'value' => 'subscriber'
                                ]
                            ]
                        ]
                    ],
                    'label' => 'Hide from subscribers',
                    'description' => 'Hide this field from users with subscriber role.'
                ];
                break;
        }
        
        // Add some universal advanced suggestions that work for all field types
        $universal_suggestions = [
            [
                'action' => 'show',
                'logic_type' => 'any',
                'groups' => [
                    [
                        'rules' => [
                            [
                                'source_type' => 'user',
                                'field' => 'user_role',
                                'operator' => '=',
                                'value' => 'administrator'
                            ],
                            [
                                'source_type' => 'user',
                                'field' => 'user_role',
                                'operator' => '=',
                                'value' => 'editor'
                            ]
                        ]
                    ]
                ],
                'label' => 'Show for admins and editors only',
                'description' => 'Display this field only for users with admin or editor privileges.'
            ],
            [
                'action' => 'disable',
                'logic_type' => 'any',
                'groups' => [
                    [
                        'rules' => [
                            [
                                'source_type' => 'date',
                                'field' => 'current_day',
                                'operator' => '=',
                                'value' => 'Saturday'
                            ]
                        ]
                    ],
                    [
                        'rules' => [
                            [
                                'source_type' => 'date',
                                'field' => 'current_day',
                                'operator' => '=',
                                'value' => 'Sunday'
                            ]
                        ]
                    ]
                ],
                'label' => 'Disable on weekends (OR logic)',
                'description' => 'Disable this field on Saturday OR Sunday using separate condition groups.'
            ],
            [
                'action' => 'show',
                'logic_type' => 'all',
                'groups' => [
                    [
                        'rules' => [
                            [
                                'source_type' => 'user',
                                'field' => 'logged_in',
                                'operator' => '=',
                                'value' => 'true'
                            ],
                            [
                                'source_type' => 'date',
                                'field' => 'current_day',
                                'operator' => '!=',
                                'value' => 'Sunday'
                            ]
                        ]
                    ]
                ],
                'label' => 'Show for logged users except Sundays',
                'description' => 'Display this field for logged-in users, but not on Sundays.'
            ],
            [
                'action' => 'show',
                'logic_type' => 'all',
                'groups' => [
                    [
                        'rules' => [
                            [
                                'source_type' => 'field',
                                'field' => 'form_step',
                                'operator' => '>',
                                'value' => '1'
                            ]
                        ]
                    ]
                ],
                'label' => 'Show in multi-step forms (step 2+)',
                'description' => 'Display this field only after the first step in multi-step forms.'
            ],
            [
                'action' => 'show',
                'logic_type' => 'all',
                'groups' => [
                    [
                        'rules' => [
                            [
                                'source_type' => 'field',
                                'field' => 'opt_in',
                                'operator' => 'is_checked',
                                'value' => ''
                            ]
                        ]
                    ]
                ],
                'label' => 'Show when user opts in',
                'description' => 'Display this field only when the opt-in checkbox is checked.'
            ]
        ];
        
        // Merge field-specific and universal suggestions
        $suggestions = array_merge($suggestions, $universal_suggestions);
        
        return $suggestions;
    }
} 