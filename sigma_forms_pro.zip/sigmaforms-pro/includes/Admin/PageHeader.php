<?php

/**
 * Shared admin page header (masthead) for every SigmaForms screen.
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\WhiteLabel\WhiteLabel;

class PageHeader {

    /**
     * Parent menu slug the plugin registers its screens under.
     */
    const MENU_SLUG = 'sigmaforms';

    /**
     * Render the shared masthead. Identical on every plugin screen.
     *
     * @return void
     */
    public static function render() {
        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template scope.
        $license_active = class_exists('SigmaForms\\Plugin') ? \SigmaForms\Plugin::is_license_valid() : false;
        $docs_url       = 'https://bdthemes.com/all-knowledge-base-of-sigma-forms/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro';
        $nav_items      = self::nav_items();
        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

        include SF_PLUGIN_DIR . 'admin/views/partials/admin-masthead.php';
    }

    /**
     * Inline SVG icon markup.
     *
     * Self contained, so the admin chrome does not depend on the dashicons font.
     *
     * @param string $name Icon name.
     * @return string SVG markup, or an empty string when the name is unknown.
     */
    public static function icon($name) {
        $paths = array(
            'forms'      => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h5"/>',
            'plus'       => '<path d="M12 5v14"/><path d="M5 12h14"/>',
            'inbox'      => '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
            'clock'      => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
            'chart'      => '<path d="M3 21h18"/><path d="M6 21v-7"/><path d="M12 21V6"/><path d="M18 21v-10"/>',
            'settings'   => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
            'key'        => '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3 21 2"/><path d="m16.5 6.5 3 3"/>',
            'palette'    => '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 0 0 0 20c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01a1.5 1.5 0 0 1 1.12-2.49H16a6 6 0 0 0 6-6c0-5.52-4.48-10-10-10z"/>',
            'book'       => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
            'arrow-left' => '<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',
            'x-circle'   => '<circle cx="12" cy="12" r="9"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
            'check-circle' => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/>',
            'trend'      => '<path d="m3 17 6-6 4 4 7-7"/><path d="M14 8h6v6"/>',
            'info'       => '<circle cx="12" cy="12" r="9"/><path d="M12 11.5v4.5"/><path d="M12 8h.01"/>',
            'filter'     => '<path d="M3 5h18l-7 8.5V19l-4 2v-7.5z"/>',
            'eye'        => '<path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
            'arrow-up'   => '<path d="M12 19V5"/><path d="m5 12 7-7 7 7"/>',
            'arrow-down' => '<path d="M12 5v14"/><path d="m19 12-7 7-7-7"/>',
            'calendar'   => '<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18"/><path d="M8 3v4"/><path d="M16 3v4"/>',
            'list'       => '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
            'brush'      => '<path d="M18.4 2.6a2.2 2.2 0 0 1 3 3L13 14l-4 1 1-4z"/><path d="M8.5 15.5c-2.5 0-4.5 2-4.5 4.5 0 .9-.6 1.5-1.5 1.5 1.5 1.2 3.7 1.5 5.5.5 1.6-.9 2.4-2.7 2-4.2"/>',
            'shield'     => '<path d="M12 2.5 4.5 5.5v6c0 5 3.3 8.6 7.5 10 4.2-1.4 7.5-5 7.5-10v-6z"/>',
            'mail'       => '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3 7 9 6 9-6"/>',
            'cloud'      => '<path d="M17.5 19a4.5 4.5 0 0 0 .5-9 7 7 0 0 0-13.4 2A4 4 0 0 0 6 19z"/>',
            'tool'       => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
            'link'       => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
            'check'      => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
            'download'   => '<path d="M12 4v12"/><path d="m7 11 5 5 5-5"/><path d="M4 20h16"/>',
            'upload'     => '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 20h16"/>',
            'external'   => '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/>',
            'warning'    => '<path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
            'lock'       => '<rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
            'pen'        => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
            'image'      => '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="m21 16-5-5-9 9"/>',
            'trash'      => '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m6 6 1 14h10l1-14"/><path d="M10 11v6"/><path d="M14 11v6"/>',
            'eye-off'    => '<path d="m3 3 18 18"/><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.1A10.5 10.5 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.2"/><path d="M6.6 6.6C3.9 8.4 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.3-1"/>',
            'arrow-right' => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
            'refresh'    => '<path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-7.5-4"/><path d="M3 12a9 9 0 0 1 9-9 9 9 0 0 1 7.5 4"/><path d="M19.5 3v4H15"/><path d="M4.5 21v-4H9"/>',
            'close'      => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
            'copy'       => '<rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
            'more'       => '<circle cx="5" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.6" fill="currentColor" stroke="none"/>',
            'chevron'    => '<path d="m6 9 6 6 6-6"/>',
            'dot'        => '<circle cx="12" cy="12" r="4"/>',
        );

        if (!isset($paths[$name])) {
            return '';
        }

        return '<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
    }

    /**
     * Render the screen's own title, description and buttons.
     *
     * @param array $args {
     *     @type string $title          Heading text.
     *     @type string $title_template Heading text with %s where the brand goes.
     *     @type string $description    Optional line under the heading.
     *     @type string $after_title    Optional escaped HTML appended to the heading.
     *     @type array  $actions        Optional links: url, label, icon, target, primary.
     * }
     * @return void
     */
    public static function intro($args = array()) {
        $defaults = array(
            'title'          => '',
            'title_template' => '',
            'description'    => '',
            'after_title'    => '',
            'actions'        => array(),
        );
        $args = wp_parse_args($args, $defaults);

        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template scope.
        $title          = (string) $args['title'];
        $title_template = (string) $args['title_template'];
        $description    = (string) $args['description'];
        $after_title    = (string) $args['after_title'];
        $actions        = is_array($args['actions']) ? $args['actions'] : array();
        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

        include SF_PLUGIN_DIR . 'admin/views/partials/admin-page-intro.php';
    }

    /**
     * The plugin's registered submenu, as nav items.
     *
     * Reading the registered submenu keeps labels, capabilities and white-label
     * visibility in step with whatever wp-admin is already showing.
     *
     * @return array
     */
    public static function nav_items() {
        global $submenu;

        if (empty($submenu[self::MENU_SLUG]) || !is_array($submenu[self::MENU_SLUG])) {
            return array();
        }

        $icons = array(
            'sigmaforms'             => 'forms',
            'sigmaforms-new'         => 'plus',
            'sigmaforms-submissions' => 'inbox',
            'sigmaforms-abandoned'   => 'clock',
            'sigmaforms-analytics'   => 'chart',
            'sigmaforms-settings'    => 'settings',
            'sigmaforms-white-label' => 'palette',
            'sigmaforms_license'     => 'key',
        );

        $current = self::current_slug();
        $items   = array();

        foreach ($submenu[self::MENU_SLUG] as $item) {
            if (empty($item[0]) || empty($item[2])) {
                continue;
            }

            if (!empty($item[1]) && !current_user_can($item[1])) {
                continue;
            }

            $slug  = $item[2];
            $label = wp_strip_all_tags($item[0]);

            if ('' === trim($label)) {
                continue;
            }

            $items[] = array(
                'label'   => $label,
                'url'     => (false !== strpos($slug, '.php')) ? admin_url($slug) : admin_url('admin.php?page=' . $slug),
                'icon'    => isset($icons[$slug]) ? $icons[$slug] : 'dot',
                'current' => ($slug === $current),
            );
        }

        return $items;
    }

    /**
     * The screen currently being viewed.
     *
     * @return string
     */
    private static function current_slug() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading the page slug to highlight a nav item, no data is processed.
        return isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
    }
}
