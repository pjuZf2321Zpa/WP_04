<?php
/**
 * Dashboard Widget class
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\Utils\Analytics;
use SigmaForms\WhiteLabel\WhiteLabel;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Dashboard Widget class
 */
class DashboardWidget {
    /**
     * Plugin instance
     *
     * @var \SigmaForms\Plugin
     */
    private $plugin;

    /**
     * Constructor
     *
     * @param \SigmaForms\Plugin $plugin Plugin instance.
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        
        add_action('wp_dashboard_setup', [$this, 'register_dashboard_widget']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_styles']);
    }

    /**
     * Load the widget styles on the Dashboard only.
     *
     * The plugin's admin bundle is not loaded on the Dashboard, so the widget
     * carries its own small stylesheet instead of relying on it.
     *
     * @param string $hook_suffix Current admin page.
     */
    public function enqueue_styles($hook_suffix) {
        if ('index.php' !== $hook_suffix || !\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            return;
        }

        wp_enqueue_style(
            'sf-dashboard-widget',
            SF_PLUGIN_URL . 'assets/css/dashboard-widget.css',
            [],
            SF_VERSION
        );
    }

    /**
     * Register dashboard widget
     */
    public function register_dashboard_widget() {
        if (\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_add_dashboard_widget(
                'sf_dashboard_widget',
                sprintf(
                    /* translators: %s: plugin name, or the white label brand when one is set */
                    __('%s Analytics', 'sigmaforms-pro'),
                    WhiteLabel::get_display_name()
                ),
                [$this, 'render_dashboard_widget']
            );
        }
    }

    /**
     * Render dashboard widget
     */
    public function render_dashboard_widget() {
        // Get stats
        $total_submissions = Analytics::get_submission_count();
        $total_forms = Analytics::get_form_count();
        $unread_count = self::get_unread_count();
        $submissions = Analytics::get_recent_submissions(5);

        // Render the dashboard widget
        include SF_PLUGIN_DIR . 'admin/views/dashboard-widget.php';
    }

    /**
     * Get unread submissions count
     *
     * @return int
     */
    public static function get_unread_count() {
        $status_counts = Analytics::get_submissions_by_status();
        return isset($status_counts['unread']) ? $status_counts['unread'] : 0;
    }

}
