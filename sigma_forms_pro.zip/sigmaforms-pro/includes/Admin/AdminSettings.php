<?php
/**
 * Admin Settings class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\Utils\Helper;

class AdminSettings {
    
    /**
     * Process settings form submission
     *
     * @return void
     */
    public function process_settings_form() {
        if (
            !isset($_POST['sf_settings_nonce']) ||
            !wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sf_settings_nonce'] ) ), 'sf_save_settings' )
        ) {        
            return;
        }

        // The Settings screen is admin only; the nonce alone does not say who may save.
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Validate and sanitize inputs
        $api_key = isset($_POST['ai_api_key']) ? sanitize_text_field(wp_unslash($_POST['ai_api_key'])) : '';
        
        // Save settings
        update_option('sf_ai_api_key', $api_key);
        
        // Rest of the settings...
        // phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Helper::sanitize_email_list() runs sanitize_email()/is_email() over every address.
        $admin_email = isset($_POST['admin_email']) ? Helper::sanitize_email_list(wp_unslash($_POST['admin_email'])) : '';
        $admin_email_cc = isset($_POST['admin_email_cc']) ? Helper::sanitize_email_list(wp_unslash($_POST['admin_email_cc'])) : '';
        $admin_email_bcc = isset($_POST['admin_email_bcc']) ? Helper::sanitize_email_list(wp_unslash($_POST['admin_email_bcc'])) : '';
        // phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $app_name = isset($_POST['app_name']) ? sanitize_text_field(wp_unslash($_POST['app_name'])) : get_bloginfo('name');
        
        // Default email template settings
        // translators: %s is the blog name.
        $default_email_subject = isset($_POST['default_email_subject']) ? sanitize_text_field(wp_unslash($_POST['default_email_subject'])) : sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name'));
        $default_email_message = isset($_POST['default_email_message']) ? wp_kses_post(wp_unslash($_POST['default_email_message'])) : __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro');
        $default_confirmation_subject = isset($_POST['default_confirmation_subject']) ? sanitize_text_field(wp_unslash($_POST['default_confirmation_subject'])) : __('Thank you for your submission', 'sigmaforms-pro');
        $default_confirmation_message = isset($_POST['default_confirmation_message']) ? wp_kses_post(wp_unslash($_POST['default_confirmation_message'])) : __('We have received your submission and will get back to you soon.', 'sigmaforms-pro');

        // Get the selected theme
        $form_theme = isset($_POST['form_theme']) ? sanitize_text_field(wp_unslash($_POST['form_theme'])) : 'minimal';
        
        $form_styling = [
            'theme' => $form_theme,
            'button_color' => isset($_POST['button_color']) ? sanitize_hex_color(wp_unslash($_POST['button_color'])) : '#2271b1',
            'button_text_color' => isset($_POST['button_text_color']) ? sanitize_hex_color(wp_unslash($_POST['button_text_color'])) : '#ffffff',
            'field_border' => isset($_POST['field_border']) ? sanitize_hex_color(wp_unslash($_POST['field_border'])) : '#dcdcde',
            'field_background' => isset($_POST['field_background']) ? sanitize_hex_color(wp_unslash($_POST['field_background'])) : '#ffffff',
            'label_color' => isset($_POST['label_color']) ? sanitize_hex_color(wp_unslash($_POST['label_color'])) : '#333333',
            'font_family' => isset($_POST['font_family']) ? sanitize_text_field(wp_unslash($_POST['font_family'])) : 'inherit',
            'font_size' => isset($_POST['font_size']) ? min(max(absint($_POST['font_size']), 10), 50) : 16,
            'form_padding' => isset($_POST['form_padding']) ? absint($_POST['form_padding']) : 20,
            'field_spacing' => isset($_POST['field_spacing']) ? absint($_POST['field_spacing']) : 15,
            'button_border_radius' => isset($_POST['button_border_radius']) ? min(absint($_POST['button_border_radius']), 50) : 4,
            'input_border_radius' => isset($_POST['input_border_radius']) ? min(absint($_POST['input_border_radius']), 50) : 4,
            'placeholder_color' => isset($_POST['placeholder_color']) ? sanitize_hex_color(wp_unslash($_POST['placeholder_color'])) : '#888888',
            'input_text_color' => isset($_POST['input_text_color']) ? sanitize_hex_color(wp_unslash($_POST['input_text_color'])) : '#333333',
            'button_hover_bg_color' => isset($_POST['button_hover_bg_color']) ? sanitize_hex_color(wp_unslash($_POST['button_hover_bg_color'])) : '#1a5a96',
            'button_hover_text_color' => isset($_POST['button_hover_text_color']) ? sanitize_hex_color(wp_unslash($_POST['button_hover_text_color'])) : '#ffffff',
        ];

        // SMTP Configuration
        $smtp_config = [
            'enabled' => isset($_POST['smtp_enabled']),
            'host' => isset($_POST['smtp_host']) ? sanitize_text_field(wp_unslash($_POST['smtp_host'])) : '',
            'port' => isset($_POST['smtp_port']) ? absint($_POST['smtp_port']) : 587,
            'encryption' => isset($_POST['smtp_encryption']) ? sanitize_text_field(wp_unslash($_POST['smtp_encryption'])) : 'tls',
            'username' => isset($_POST['smtp_username']) ? sanitize_text_field(wp_unslash($_POST['smtp_username'])) : '',
        ];

        // An empty field keeps the saved password; "Remove saved password" clears it.
        // Compared with '' rather than empty(), so a password of "0" can be saved.
        if (!empty($_POST['smtp_password_clear'])) {
            $smtp_config['password'] = '';
        } elseif (isset($_POST['smtp_password']) && (string) wp_unslash($_POST['smtp_password']) !== '') { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only compared with ''.
            // Stored as typed: sanitize_text_field() strips tags, %xx sequences and
            // edge spaces, which silently changed passwords and broke SMTP login.
            $smtp_config['password'] = (string) wp_unslash($_POST['smtp_password']); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Password is used verbatim for SMTP auth and only ever printed escaped.
        } else {
            // Get existing password
            $existing_config = get_option('sf_smtp_config', []);
            $smtp_config['password'] = isset($existing_config['password']) ? $existing_config['password'] : '';
        }
        
        // Process CAPTCHA settings
        $captcha_settings = [
            // reCAPTCHA
            'recaptcha_enabled' => isset($_POST['recaptcha_enabled']),
            'recaptcha_use_v3' => isset($_POST['recaptcha_use_v3']),
            'recaptcha_site_key' => isset($_POST['recaptcha_site_key']) ? sanitize_text_field(wp_unslash($_POST['recaptcha_site_key'])) : '',
            'recaptcha_secret_key' => isset($_POST['recaptcha_secret_key']) ? sanitize_text_field(wp_unslash($_POST['recaptcha_secret_key'])) : '',
            'recaptcha_v3_score_threshold' => isset($_POST['recaptcha_v3_score_threshold']) ? floatval($_POST['recaptcha_v3_score_threshold']) : 0.5,
            
            // hCaptcha
            'hcaptcha_enabled' => isset($_POST['hcaptcha_enabled']),
            'hcaptcha_site_key' => isset($_POST['hcaptcha_site_key']) ? sanitize_text_field(wp_unslash($_POST['hcaptcha_site_key'])) : '',
            'hcaptcha_secret_key' => isset($_POST['hcaptcha_secret_key']) ? sanitize_text_field(wp_unslash($_POST['hcaptcha_secret_key'])) : '',
            
            // Turnstile
            'turnstile_enabled' => isset($_POST['turnstile_enabled']),
            'turnstile_site_key' => isset($_POST['turnstile_site_key']) ? sanitize_text_field(wp_unslash($_POST['turnstile_site_key'])) : '',
            'turnstile_secret_key' => isset($_POST['turnstile_secret_key']) ? sanitize_text_field(wp_unslash($_POST['turnstile_secret_key'])) : '',
            
            // CleanTalk
            'cleantalk_enabled' => isset($_POST['cleantalk_enabled']),
            'cleantalk_access_key' => isset($_POST['cleantalk_access_key']) ? sanitize_text_field(wp_unslash($_POST['cleantalk_access_key'])) : '',

            // mTCaptcha
            'mtcaptcha_enabled' => isset($_POST['mtcaptcha_enabled']),
            'mtcaptcha_site_key' => isset($_POST['mtcaptcha_site_key']) ? sanitize_text_field(wp_unslash($_POST['mtcaptcha_site_key'])) : '',
            'mtcaptcha_private_key' => isset($_POST['mtcaptcha_private_key']) ? sanitize_text_field(wp_unslash($_POST['mtcaptcha_private_key'])) : '',
        ];
        
        // Process webhook settings
        $webhook_settings = [
            // Webhook enable/disable settings
            'webhook_google_sheets_enabled' => isset($_POST['webhook_google_sheets_enabled']),

            'webhook_slack_enabled' => isset($_POST['webhook_slack_enabled']),
            'webhook_discord_enabled' => isset($_POST['webhook_discord_enabled']),
            'webhook_telegram_enabled' => isset($_POST['webhook_telegram_enabled']),
            'webhook_custom_enabled' => isset($_POST['webhook_custom_enabled']),
            
            // Google Sheets
            'webhook_google_sheets_url' => isset($_POST['webhook_google_sheets_url']) ? esc_url_raw(wp_unslash($_POST['webhook_google_sheets_url'])) : '',
            

            
            // Slack
            'webhook_slack_url' => isset($_POST['webhook_slack_url']) ? esc_url_raw(wp_unslash($_POST['webhook_slack_url'])) : '',
            'webhook_slack_channel' => isset($_POST['webhook_slack_channel']) ? sanitize_text_field(wp_unslash($_POST['webhook_slack_channel'])) : '',
            
            // Discord
            'webhook_discord_url' => isset($_POST['webhook_discord_url']) ? esc_url_raw(wp_unslash($_POST['webhook_discord_url'])) : '',
            
            // Telegram
            'webhook_telegram_bot_token' => isset($_POST['webhook_telegram_bot_token']) ? sanitize_text_field(wp_unslash($_POST['webhook_telegram_bot_token'])) : '',
            'webhook_telegram_chat_id' => isset($_POST['webhook_telegram_chat_id']) ? sanitize_text_field(wp_unslash($_POST['webhook_telegram_chat_id'])) : '',
            
            // Custom Webhook
            'webhook_custom_url' => isset($_POST['webhook_custom_url']) ? esc_url_raw(wp_unslash($_POST['webhook_custom_url'])) : '',
            'webhook_custom_method' => isset($_POST['webhook_custom_method']) ? sanitize_text_field(wp_unslash($_POST['webhook_custom_method'])) : 'POST',
        ];
        
        // Process advanced settings
        $cleanup_days = isset($_POST['cleanup_days']) ? max(0, min(365, absint($_POST['cleanup_days']))) : 90;
        $views_retention_days = isset($_POST['views_retention_days']) ? max(0, min(365, absint($_POST['views_retention_days']))) : 60;

        // Process storage settings
        $storage_settings = [
            // Google Drive (always uses Master Mode via proxy)
            'storage_google_drive_enabled' => isset($_POST['storage_google_drive_enabled']),
            'storage_google_drive_folder_structure' => isset($_POST['storage_google_drive_folder_structure']) ? sanitize_text_field(wp_unslash($_POST['storage_google_drive_folder_structure'])) : 'year_month',
            'storage_google_drive_custom_folder' => isset($_POST['storage_google_drive_custom_folder']) ? sanitize_text_field(wp_unslash($_POST['storage_google_drive_custom_folder'])) : 'sigmaforms/{year}/{month}',
            // OneDrive (always uses Master Mode via proxy)
            'storage_onedrive_enabled' => isset($_POST['storage_onedrive_enabled']),
            'storage_onedrive_folder_structure' => isset($_POST['storage_onedrive_folder_structure']) ? sanitize_text_field(wp_unslash($_POST['storage_onedrive_folder_structure'])) : 'year_month',
            'storage_onedrive_custom_folder' => isset($_POST['storage_onedrive_custom_folder']) ? sanitize_text_field(wp_unslash($_POST['storage_onedrive_custom_folder'])) : 'sigmaforms/{year}/{month}',
        ];
        
        // Save the rest of the settings
        update_option('sf_admin_email', $admin_email);
        update_option('sf_admin_email_cc', $admin_email_cc);
        update_option('sf_admin_email_bcc', $admin_email_bcc);
        update_option('sf_app_name', $app_name);
        update_option('sf_default_email_subject', $default_email_subject);
        update_option('sf_default_email_message', $default_email_message);
        update_option('sf_default_confirmation_subject', $default_confirmation_subject);
        update_option('sf_default_confirmation_message', $default_confirmation_message);
        update_option('sf_form_styling', $form_styling);
        update_option('sf_form_theme', $form_theme);

        // "Apply to all existing forms": every form follows the global theme.
        if (!empty($_POST['apply_theme_to_all_forms'])) {
            $this->apply_global_theme_to_all_forms();
        }
        update_option('sf_smtp_config', $smtp_config);
        update_option('sf_cleanup_days', $cleanup_days);
        update_option('sf_views_retention_days', $views_retention_days);

        // Merge CAPTCHA, webhook, and storage settings into one global settings array
        $global_settings = array_merge($captcha_settings, $webhook_settings, $storage_settings);
        update_option('sigmaforms_settings', $global_settings);
        
        // Add success notice
        add_settings_error(
            'sf_settings',
            'settings_updated',
            __('Settings saved successfully.', 'sigmaforms-pro'),
            'updated'
        );
    }


    /**
     * Point every form at the global theme ("Global default").
     *
     * Forms created before 1.6.0 saved a copy of the theme they were made
     * with, so changing the theme in Settings had no effect on them.
     *
     * @return void
     */
    private function apply_global_theme_to_all_forms() {
        global $wpdb;

        $table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Table name built from $wpdb->prefix.
        $forms = $wpdb->get_results("SELECT id, form_settings FROM {$table}", ARRAY_A);

        foreach ((array) $forms as $form) {
            $settings = json_decode((string) $form['form_settings'], true);
            if (!is_array($settings) || (isset($settings['form_theme']) && $settings['form_theme'] === '')) {
                continue;
            }
            $settings['form_theme'] = '';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One update per form, admin action.
            $wpdb->update($table, ['form_settings' => wp_json_encode($settings)], ['id' => (int) $form['id']], ['%s'], ['%d']);
        }
    }

    /**
     * Test SMTP Connection
     *
     * @return void
     */
    public function test_smtp_connection() {
        check_ajax_referer('sf_test_smtp', 'nonce');

        // Opens a connection to any host and port given, so admins only.
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')], 403);
        }

        // Get SMTP settings from form data
        $smtp_enabled = isset($_POST['smtp_enabled']) && $_POST['smtp_enabled'] === 'true';
        if (!$smtp_enabled) {
            wp_send_json_error(['message' => __('SMTP is not enabled.', 'sigmaforms-pro')]);
        }

        // Get form data
        $smtp_host = isset($_POST['smtp_host']) ? sanitize_text_field(wp_unslash($_POST['smtp_host'])) : '';
        $smtp_port = isset($_POST['smtp_port']) ? absint($_POST['smtp_port']) : 587;
        $smtp_encryption = isset($_POST['smtp_encryption']) ? sanitize_text_field(wp_unslash($_POST['smtp_encryption'])) : 'tls';
        $smtp_username = isset($_POST['smtp_username']) ? sanitize_text_field(wp_unslash($_POST['smtp_username'])) : '';
        $smtp_password = isset($_POST['smtp_password']) ? (string) wp_unslash($_POST['smtp_password']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Password is used verbatim for SMTP auth.

        // The settings screen no longer prints the saved password, so an empty
        // field means "test with the saved one".
        if ($smtp_password === '') {
            $saved_smtp = get_option('sf_smtp_config', []);
            $smtp_password = isset($saved_smtp['password']) ? (string) $saved_smtp['password'] : '';
        }

        // Validate required fields with specific messages
        if (empty($smtp_host)) {
            wp_send_json_error(['message' => __('SMTP Host is required.', 'sigmaforms-pro')]);
        }
        
        if (empty($smtp_username)) {
            wp_send_json_error(['message' => __('SMTP Username is required.', 'sigmaforms-pro')]);
        }
        
        if (empty($smtp_password)) {
            wp_send_json_error(['message' => __('SMTP Password is required.', 'sigmaforms-pro')]);
        }

        // Set up PHPMailer
        global $phpmailer;
        if (!is_object($phpmailer)) {
            require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
            require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
            require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
            $phpmailer = new \PHPMailer\PHPMailer\PHPMailer(true);
        }

        try {
            // Configure SMTP
            $phpmailer->isSMTP();
            $phpmailer->Host = $smtp_host;
            $phpmailer->SMTPAuth = true;
            $phpmailer->Port = $smtp_port;
            $phpmailer->Username = $smtp_username;
            $phpmailer->Password = $smtp_password;
            
            // Set encryption
            if ($smtp_encryption === 'none') {
                $phpmailer->SMTPSecure = '';
                $phpmailer->SMTPAutoTLS = false;
            } else {
                $phpmailer->SMTPSecure = $smtp_encryption;
            }

            // Get admin email for testing
            $admin_email = get_option('admin_email');
            if (empty($admin_email)) {
                wp_send_json_error(['message' => __('Admin email is not configured.', 'sigmaforms-pro')]);
            }

            // Set up test email
            $phpmailer->clearAddresses();
            $phpmailer->clearReplyTos();
            $phpmailer->setFrom($admin_email, get_option('sf_app_name', get_bloginfo('name')));
            $phpmailer->addAddress($admin_email);
            $phpmailer->Subject = 'SMTP Test Email';
            $phpmailer->Body = 'This is a test email to verify SMTP configuration.';
            $phpmailer->isHTML(true);

            // Send test email
            $phpmailer->send();
            wp_send_json_success(['message' => __('SMTP test successful! Test email sent.', 'sigmaforms-pro')]);
        } catch (\Exception $e) {
            $error_message = $e->getMessage();
            
            // Add common error solutions
            $help_message = '';
            if (strpos($error_message, 'Could not connect to SMTP host') !== false) {
                $help_message = __(' Please check: 1) Host address is correct, 2) Port is correct (587 for TLS, 465 for SSL), 3) Your hosting provider allows outbound SMTP connections, 4) Server firewall settings', 'sigmaforms-pro');
            } elseif (strpos($error_message, 'Authentication failed') !== false) {
                $help_message = __(' Please verify your username and password are correct', 'sigmaforms-pro');
            } elseif (strpos($error_message, 'SSL/TLS required') !== false) {
                $help_message = __(' Please enable SSL/TLS encryption or use the correct port (587 for TLS, 465 for SSL)', 'sigmaforms-pro');
            }

            wp_send_json_error(['message' => __('SMTP test failed: ', 'sigmaforms-pro') . $error_message . $help_message]);
        }
    }
} 