<?php
/**
 * Admin AJAX class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\Plugin;
use SigmaForms\Utils\GoogleDriveOAuth;
use SigmaForms\Utils\OneDriveOAuth;

class AdminAjax {
    /**
     * Plugin instance
     *
     * @var Plugin
     */
    private $plugin;
    
    /**
     * Conditional suggestions instance
     *
     * @var ConditionalSuggestions
     */
    private $conditional_suggestions;
    
    /**
     * Constructor
     *
     * @param Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->conditional_suggestions = new ConditionalSuggestions();
    }
    
    /**
     * AJAX handler for generating a form
     *
     * @return void
     */
    public function ajax_generate_form() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : '';
        
        if (empty($prompt)) {
            wp_send_json_error(['message' => __('Please provide a valid prompt.', 'sigmaforms-pro')]);
            return;
        }
        
        $form_structure = $this->plugin->ai->generate_form_from_prompt($prompt);
        
        if (is_wp_error($form_structure)) {
            wp_send_json_error([
                'message' => $form_structure->get_error_message(),
                'code' => $form_structure->get_error_code(),
            ]);
            return;
        }
        
        wp_send_json_success([
            'form' => $form_structure,
        ]);
    }
    
    /**
     * AJAX handler for saving a form
     *
     * @return void
     */
    public function ajax_save_form() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        // Don't sanitize the JSON string itself - let Helper::sanitize_form_fields() handle field-level sanitization
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON payload; every field is sanitized by Helper::sanitize_form_fields()/sanitize_form_settings() in create_form()/update_form().
        $form_data = isset($_POST['form_data']) ? json_decode(wp_unslash($_POST['form_data']), true) : null;
        $form_id = isset($_POST['form_id']) ? (int) $_POST['form_id'] : 0;
        
        if (!is_array($form_data)) {
            wp_send_json_error(['message' => __('Invalid form data.', 'sigmaforms-pro')]);
            return;
        }

        $form_data = \SigmaForms\Forms\FormsManager::strip_restricted_settings($form_data);
        
        // Save form
        if ($form_id > 0) {
            // Update existing form
            $result = $this->plugin->forms->update_form($form_id, $form_data);
            
            if (is_wp_error($result)) {
                
                wp_send_json_error(['message' => $result->get_error_message()]);
                return;
            }
            
            wp_send_json_success([
                'message' => __('Form updated successfully.', 'sigmaforms-pro'),
                'form_id' => $form_id,
                'edit_nonce' => wp_create_nonce('edit_form_' . $form_id),
            ]);
        } else {
            // Create new form
            $form_id = $this->plugin->forms->create_form($form_data);
            
            if (is_wp_error($form_id)) {
                
                wp_send_json_error(['message' => $form_id->get_error_message()]);
                return;
            }
            
            wp_send_json_success([
                'message' => __('Form created successfully.', 'sigmaforms-pro'),
                'form_id' => $form_id,
                'edit_nonce' => wp_create_nonce('edit_form_' . $form_id),
            ]);
        }
    }
    
    /**
     * AJAX handler for deleting a form
     *
     * @return void
     */
    public function ajax_delete_form() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $form_id = isset($_POST['form_id']) ? (int) $_POST['form_id'] : 0;
        
        if ($form_id <= 0) {
            wp_send_json_error(['message' => __('Invalid form ID.', 'sigmaforms-pro')]);
            return;
        }
        
        $result = $this->plugin->forms->delete_form($form_id);
        
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
            return;
        }
        
        wp_send_json_success([
            'message' => __('Form deleted successfully.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * AJAX handler for duplicating a form
     *
     * @return void
     */
    public function ajax_duplicate_form() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $form_id = isset($_POST['form_id']) ? (int) $_POST['form_id'] : 0;
        
        if ($form_id <= 0) {
            wp_send_json_error(['message' => __('Invalid form ID.', 'sigmaforms-pro')]);
            return;
        }
        
        $new_form_id = $this->plugin->forms->duplicate_form($form_id);
        
        if (is_wp_error($new_form_id)) {
            wp_send_json_error(['message' => $new_form_id->get_error_message()]);
            return;
        }
        
        wp_send_json_success([
            'message' => __('Form duplicated successfully.', 'sigmaforms-pro'),
            'new_form_id' => $new_form_id,
        ]);
    }
    
    /**
     * AJAX handler for deleting a submission
     *
     * @return void
     */
    public function ajax_delete_submission() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $submission_id = isset($_POST['submission_id']) ? (int) $_POST['submission_id'] : 0;
        
        if ($submission_id <= 0) {
            wp_send_json_error(['message' => __('Invalid submission ID.', 'sigmaforms-pro')]);
            return;
        }
        
        global $wpdb;
        
        // Delete uploaded files before deleting the submission
        $this->delete_submission_files($submission_id);
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->delete($table,['id' => $submission_id],['%d']);
        
        if ($result === false) {
            wp_send_json_error(['message' => __('Failed to delete submission.', 'sigmaforms-pro')]);
            return;
        }
        
        wp_send_json_success([
            'message' => __('Submission deleted successfully.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * Delete uploaded files from a submission
     *
     * @param int $submission_id Submission ID
     * @return void
     */
    private function delete_submission_files($submission_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Get submission data
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the ID is prepared with %d.
        $submission = $wpdb->get_row($wpdb->prepare("SELECT field_values, form_id FROM {$table} WHERE id = %d", $submission_id), ARRAY_A);
        
        if (!$submission) {
            return;
        }
        
        // Decode field values
        $field_values = json_decode($submission['field_values'], true);
        if (!is_array($field_values)) {
            return;
        }
        
        // Get form fields to identify file/signature fields
        $forms_table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the ID is prepared with %d.
        $form = $wpdb->get_row($wpdb->prepare("SELECT form_fields FROM {$forms_table} WHERE id = %d", $submission['form_id']), ARRAY_A);
        
        if (!$form) {
            return;
        }
        
        $form_fields = json_decode($form['form_fields'], true);
        if (!is_array($form_fields)) {
            return;
        }
        
        // Find file and signature fields that use site storage
        foreach ($form_fields as $field) {
            if (!isset($field['id']) || !isset($field['type'])) {
                continue;
            }
            
            // Check if it's a file or signature field with site storage
            if (in_array($field['type'], ['file', 'signature'])) {
                $storage_location = isset($field['storage_location']) ? $field['storage_location'] : 'site';
                
                // Only delete if storage is 'site' (not cloud storage)
                if ($storage_location === 'site' && isset($field_values[$field['id']])) {
                    $file_url = $field_values[$field['id']];
                    
                    // Handle array of files (multiple file uploads)
                    if (is_array($file_url)) {
                        $file_urls = $file_url;
                    } elseif (is_string($file_url) && strpos($file_url, ',') !== false) {
                        // Handle comma-separated URLs from multiple file uploads
                        $file_urls = array_map('trim', explode(',', $file_url));
                    } else {
                        $file_urls = [$file_url];
                    }
                    
                    foreach ($file_urls as $url) {
                        if (empty($url) || !is_string($url)) {
                            continue;
                        }

                        // The stored value came from a public submission, so never
                        // build a path from it directly. resolve_managed_upload_path()
                        // returns false unless the URL canonicalises to a real file
                        // inside wp-content/uploads.
                        $file_path = \SigmaForms\Utils\Helper::resolve_managed_upload_path($url);

                        if (false !== $file_path) {
                            wp_delete_file($file_path);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * AJAX handler for getting AI suggested conditions
     * 
     * @return void
     */
    public function ajax_get_suggested_conditions() {
        // Check nonce for security
        if (
            !isset($_POST['nonce']) ||
            !wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'sf_admin_nonce' )
        ) {
            wp_send_json_error('Invalid nonce');
        }

        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(__('You do not have permission to perform this action.', 'sigmaforms-pro'));
        }

        // Get field data
        $field_id = isset($_POST['field_id']) ? sanitize_text_field(wp_unslash($_POST['field_id'])) : '';
        $field_type = isset($_POST['field_type']) ? sanitize_text_field(wp_unslash($_POST['field_type'])) : '';
        
        if (empty($field_id) || empty($field_type)) {
            wp_send_json_error('Missing field information');
        }
        
        // Generate suggestions based on field type
        $suggestions = $this->conditional_suggestions->get_field_condition_suggestions($field_type, $field_id);
        
        if (empty($suggestions)) {
            wp_send_json_error('Could not generate suggestions');
        }
        
        wp_send_json_success([
            'suggestions' => $suggestions
        ]);
    }
    
    /**
     * AJAX handler for processing settings form
     *
     * @return void
     */
    public function ajax_process_settings() {
        check_ajax_referer('sf_save_settings', 'sf_settings_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        // Call the settings processing method from AdminSettings
        $admin_settings = new AdminSettings();
        $admin_settings->process_settings_form();
        
        wp_send_json_success([
            'message' => __('Settings saved successfully.', 'sigmaforms-pro'),
        ]);
    }

    /**
     * AJAX handler for bulk delete submissions
     *
     * @return void
     */
    public function ajax_bulk_delete_submissions() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $submission_ids = isset($_POST['submission_ids']) ? array_map('intval', $_POST['submission_ids']) : [];
        
        if (empty($submission_ids)) {
            wp_send_json_error(['message' => __('No submissions selected.', 'sigmaforms-pro')]);
            return;
        }
        
        $forms_manager = new \SigmaForms\Forms\FormsManager();
        $deleted_count = $forms_manager->bulk_delete_submissions($submission_ids);
        
        if ($deleted_count === false) {
            wp_send_json_error(['message' => __('Failed to delete submissions.', 'sigmaforms-pro')]);
            return;
        }
        
        wp_send_json_success([
            'message' => sprintf(
                /* translators: %d: Number of submissions deleted */
                _n('%d submission deleted successfully.', '%d submissions deleted successfully.', $deleted_count, 'sigmaforms-pro'),
                $deleted_count
            ),
            'deleted_count' => $deleted_count,
        ]);
    }

    /**
     * AJAX handler for bulk mark submissions as read
     *
     * @return void
     */
    public function ajax_bulk_mark_submissions_as_read() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $submission_ids = isset($_POST['submission_ids']) ? array_map('intval', $_POST['submission_ids']) : [];
        
        if (empty($submission_ids)) {
            wp_send_json_error(['message' => __('No submissions selected.', 'sigmaforms-pro')]);
            return;
        }
        
        $forms_manager = new \SigmaForms\Forms\FormsManager();
        $updated_count = $forms_manager->bulk_mark_submissions_as_read($submission_ids);
        
        if ($updated_count === false) {
            wp_send_json_error(['message' => __('Failed to mark submissions as read.', 'sigmaforms-pro')]);
            return;
        }
        
        wp_send_json_success([
            'message' => sprintf(
                /* translators: %d: Number of submissions marked as read */
                _n('%d submission marked as read.', '%d submissions marked as read.', $updated_count, 'sigmaforms-pro'),
                $updated_count
            ),
            'updated_count' => $updated_count,
        ]);
    }

    /**
     * AJAX handler for bulk mark submissions as unread
     *
     * @return void
     */
    public function ajax_bulk_mark_submissions_as_unread() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $submission_ids = isset($_POST['submission_ids']) ? array_map('intval', $_POST['submission_ids']) : [];
        
        if (empty($submission_ids)) {
            wp_send_json_error(['message' => __('No submissions selected.', 'sigmaforms-pro')]);
            return;
        }
        
        $forms_manager = new \SigmaForms\Forms\FormsManager();
        $updated_count = $forms_manager->bulk_mark_submissions_as_unread($submission_ids);
        
        if ($updated_count === false) {
            wp_send_json_error(['message' => __('Failed to mark submissions as unread.', 'sigmaforms-pro')]);
            return;
        }
        
        wp_send_json_success([
            'message' => sprintf(
                /* translators: %d: Number of submissions marked as unread */
                _n('%d submission marked as unread.', '%d submissions marked as unread.', $updated_count, 'sigmaforms-pro'),
                $updated_count
            ),
            'updated_count' => $updated_count,
        ]);
    }

    /**
     * AJAX handler for deleting an abandoned form
     *
     * @return void
     */
    public function ajax_delete_abandoned_form() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $abandoned_id = isset($_POST['abandoned_id']) ? (int) $_POST['abandoned_id'] : 0;
        
        if ($abandoned_id <= 0) {
            wp_send_json_error(['message' => __('Invalid abandoned form ID.', 'sigmaforms-pro')]);
            return;
        }
        
        $result = $this->plugin->abandoned_forms->delete_abandoned_form($abandoned_id);
        
        if (!$result) {
            wp_send_json_error(['message' => __('Failed to delete abandoned form record.', 'sigmaforms-pro')]);
            return;
        }
        
        wp_send_json_success([
            'message' => __('Abandoned form record deleted successfully.', 'sigmaforms-pro'),
        ]);
    }

    /**
     * AJAX handler for bulk delete abandoned forms
     *
     * @return void
     */
    public function ajax_bulk_delete_abandoned_forms() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }
        
        $abandoned_form_ids = isset($_POST['abandoned_form_ids']) ? array_map('intval', $_POST['abandoned_form_ids']) : [];
        
        if (empty($abandoned_form_ids)) {
            wp_send_json_error(['message' => __('No abandoned forms selected.', 'sigmaforms-pro')]);
            return;
        }
        
        $deleted_count = $this->plugin->abandoned_forms->delete_abandoned_forms($abandoned_form_ids);
        
        if ($deleted_count === false) {
            wp_send_json_error(['message' => __('Failed to delete abandoned forms.', 'sigmaforms-pro')]);
            return;
        }
        
        wp_send_json_success([
            'message' => sprintf(
                /* translators: %d: Number of abandoned forms deleted */
                _n('%d abandoned form deleted successfully.', '%d abandoned forms deleted successfully.', $deleted_count, 'sigmaforms-pro'),
                $deleted_count
            ),
            'deleted_count' => $deleted_count,
        ]);
    }

    /**
     * AJAX handler for connecting to Google Drive
     *
     * @return void
     */
    public function ajax_connect_google_drive() {
        // Verify nonce.
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'sf_storage_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'sigmaforms-pro')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }

        // Generate OAuth URL using the OAuth handler.
        $state = wp_create_nonce('sf_google_oauth');
        $auth_url = GoogleDriveOAuth::get_auth_url($state);

        // Store state in transient for verification.
        set_transient('sf_google_oauth_state', $state, 600);

        wp_send_json_success(['auth_url' => $auth_url]);
    }

    /**
     * AJAX handler for disconnecting Google Drive
     *
     * @return void
     */
    public function ajax_disconnect_google_drive() {
        // Verify nonce.
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'sf_storage_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'sigmaforms-pro')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }

        // Remove Google Drive tokens from database.
        delete_option('sf_google_drive_access_token');
        delete_option('sf_google_drive_refresh_token');
        delete_option('sf_google_drive_token_expiry');

        wp_send_json_success(['message' => __('Google Drive disconnected successfully.', 'sigmaforms-pro')]);
    }

    /**
     * AJAX handler for connecting to OneDrive
     *
     * @return void
     */
    public function ajax_connect_onedrive() {
        // Verify nonce.
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'sf_storage_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'sigmaforms-pro')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }

        // Generate OAuth URL using the OAuth handler.
        $state = wp_create_nonce('sf_onedrive_oauth');
        $auth_url = OneDriveOAuth::get_auth_url($state);

        // Store state in transient for verification.
        set_transient('sf_onedrive_oauth_state', $state, 600);

        wp_send_json_success(['auth_url' => $auth_url]);
    }

    /**
     * AJAX handler for disconnecting OneDrive
     *
     * @return void
     */
    public function ajax_disconnect_onedrive() {
        // Verify nonce.
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'sf_storage_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'sigmaforms-pro')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }

        // Remove OneDrive tokens from database.
        delete_option('sf_onedrive_access_token');
        delete_option('sf_onedrive_refresh_token');
        delete_option('sf_onedrive_token_expiry');

        wp_send_json_success(['message' => __('OneDrive disconnected successfully.', 'sigmaforms-pro')]);
    }

    /**
     * AJAX handler for exporting settings
     *
     * @return void
     */
    public function ajax_export_settings() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }

        // Check if forms should be included
        $include_forms = isset($_POST['include_forms']) && $_POST['include_forms'] === '1';

        // Gather all SigmaForms settings
        $settings = [
            'ai_api_key' => get_option('sf_ai_api_key', ''),
            'admin_email' => get_option('sf_admin_email', ''),
            'admin_email_cc' => get_option('sf_admin_email_cc', ''),
            'admin_email_bcc' => get_option('sf_admin_email_bcc', ''),
            'app_name' => get_option('sf_app_name', get_bloginfo('name')),
            'default_email_subject' => get_option('sf_default_email_subject', ''),
            'default_email_message' => get_option('sf_default_email_message', ''),
            'default_confirmation_subject' => get_option('sf_default_confirmation_subject', ''),
            'default_confirmation_message' => get_option('sf_default_confirmation_message', ''),
            'form_styling' => get_option('sf_form_styling', []),
            'form_theme' => get_option('sf_form_theme', 'minimal'),
            'smtp_config' => get_option('sf_smtp_config', []),
            'cleanup_days' => get_option('sf_cleanup_days', 90),
            'views_retention_days' => get_option('sf_views_retention_days', 60),
            'sigmaforms_settings' => get_option('sigmaforms_settings', []),
        ];

        // Include forms if requested
        if ($include_forms) {
            global $wpdb;
            $table = $wpdb->prefix . 'sigmaforms';
            
            // Get all forms with their complete data
            $forms_query = "SELECT id, title, form_fields, form_settings, date_created, date_modified, status FROM {$table} ORDER BY date_created ASC";
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Static query; the table name is built from $wpdb->prefix and there is no user input.
            $forms = $wpdb->get_results($forms_query, ARRAY_A);
            
            if ($forms) {
                // Decode JSON fields for each form
                foreach ($forms as &$form) {
                    $form['form_fields'] = json_decode($form['form_fields'], true) ?: [];
                    $form['form_settings'] = json_decode($form['form_settings'], true) ?: [];
                }
                
                $settings['forms'] = $forms;
            }
        }

        // Generate filename with timestamp
        $filename_suffix = $include_forms ? 'with-forms' : 'settings';
        $filename = 'sigmaforms-' . $filename_suffix . '-' . gmdate('Y-m-d-His') . '.json';

        wp_send_json_success([
            'settings' => $settings,
            'filename' => $filename,
        ]);
    }

    /**
     * AJAX handler for importing settings
     *
     * @return void
     */
    public function ajax_import_settings() {
        check_ajax_referer('sf-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'sigmaforms-pro')]);
            return;
        }

        // Get settings from POST data
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON payload; every imported value is sanitized individually below.
        $settings_json = isset($_POST['settings']) ? wp_unslash($_POST['settings']) : '';
        
        if (empty($settings_json)) {
            wp_send_json_error(['message' => __('No settings data provided.', 'sigmaforms-pro')]);
            return;
        }

        // Check if forms should be imported
        $include_forms = isset($_POST['include_forms']) && $_POST['include_forms'] === '1';

        // Decode JSON
        $settings = json_decode($settings_json, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(['message' => __('Invalid JSON format.', 'sigmaforms-pro')]);
            return;
        }

        // Validate and import settings
        try {
            $imported_forms_count = 0;
            $skipped_forms_count = 0;
            
            // Import AI API key
            if (isset($settings['ai_api_key'])) {
                update_option('sf_ai_api_key', sanitize_text_field($settings['ai_api_key']));
            }

            // Import email settings
            if (isset($settings['admin_email'])) {
                update_option('sf_admin_email', \SigmaForms\Utils\Helper::sanitize_email_list($settings['admin_email']));
            }
            if (isset($settings['admin_email_cc'])) {
                update_option('sf_admin_email_cc', \SigmaForms\Utils\Helper::sanitize_email_list($settings['admin_email_cc']));
            }
            if (isset($settings['admin_email_bcc'])) {
                update_option('sf_admin_email_bcc', \SigmaForms\Utils\Helper::sanitize_email_list($settings['admin_email_bcc']));
            }
            if (isset($settings['app_name'])) {
                update_option('sf_app_name', sanitize_text_field($settings['app_name']));
            }
            if (isset($settings['default_email_subject'])) {
                update_option('sf_default_email_subject', sanitize_text_field($settings['default_email_subject']));
            }
            if (isset($settings['default_email_message'])) {
                update_option('sf_default_email_message', wp_kses_post($settings['default_email_message']));
            }
            if (isset($settings['default_confirmation_subject'])) {
                update_option('sf_default_confirmation_subject', sanitize_text_field($settings['default_confirmation_subject']));
            }
            if (isset($settings['default_confirmation_message'])) {
                update_option('sf_default_confirmation_message', wp_kses_post($settings['default_confirmation_message']));
            }

            // Import form styling
            if (isset($settings['form_styling']) && is_array($settings['form_styling'])) {
                $form_styling = [];
                foreach ($settings['form_styling'] as $key => $value) {
                    if (in_array($key, ['button_color', 'button_text_color', 'field_border', 'field_background', 'label_color', 'placeholder_color', 'input_text_color', 'button_hover_bg_color', 'button_hover_text_color'])) {
                        $form_styling[$key] = sanitize_hex_color($value);
                    } elseif (in_array($key, ['font_size', 'form_padding', 'field_spacing', 'button_border_radius', 'input_border_radius'])) {
                        $form_styling[$key] = absint($value);
                    } else {
                        $form_styling[$key] = sanitize_text_field($value);
                    }
                }
                update_option('sf_form_styling', $form_styling);
            }

            // Import form theme
            if (isset($settings['form_theme'])) {
                update_option('sf_form_theme', sanitize_text_field($settings['form_theme']));
            }

            // Import SMTP config
            if (isset($settings['smtp_config']) && is_array($settings['smtp_config'])) {
                $smtp_config = [];
                $smtp_config['enabled'] = isset($settings['smtp_config']['enabled']) ? (bool) $settings['smtp_config']['enabled'] : false;
                $smtp_config['host'] = isset($settings['smtp_config']['host']) ? sanitize_text_field($settings['smtp_config']['host']) : '';
                $smtp_config['port'] = isset($settings['smtp_config']['port']) ? absint($settings['smtp_config']['port']) : 587;
                $smtp_config['encryption'] = isset($settings['smtp_config']['encryption']) ? sanitize_text_field($settings['smtp_config']['encryption']) : 'tls';
                $smtp_config['username'] = isset($settings['smtp_config']['username']) ? sanitize_text_field($settings['smtp_config']['username']) : '';
                $smtp_config['password'] = isset($settings['smtp_config']['password']) ? sanitize_text_field($settings['smtp_config']['password']) : '';
                update_option('sf_smtp_config', $smtp_config);
            }

            // Import cleanup days
            if (isset($settings['cleanup_days'])) {
                update_option('sf_cleanup_days', absint($settings['cleanup_days']));
            }

            // Import view log retention
            if (isset($settings['views_retention_days'])) {
                update_option('sf_views_retention_days', max(0, min(365, absint($settings['views_retention_days']))));
            }

            // Import global settings (CAPTCHA, webhooks, storage)
            if (isset($settings['sigmaforms_settings']) && is_array($settings['sigmaforms_settings'])) {
                $global_settings = [];
                foreach ($settings['sigmaforms_settings'] as $key => $value) {
                    if (is_bool($value)) {
                        $global_settings[$key] = (bool) $value;
                    } elseif (is_numeric($value)) {
                        $global_settings[$key] = is_float($value) ? floatval($value) : absint($value);
                    } elseif (strpos($key, '_url') !== false) {
                        $global_settings[$key] = esc_url_raw($value);
                    } else {
                        $global_settings[$key] = sanitize_text_field($value);
                    }
                }
                update_option('sigmaforms_settings', $global_settings);
            }

            // Import forms if available AND if the toggle is enabled
            // IMPORTANT: Forms are ALWAYS created as NEW forms, never updating existing ones.
            // The exported form ID is completely ignored - new IDs are auto-generated by the database.
            if ($include_forms && isset($settings['forms']) && is_array($settings['forms']) && !empty($settings['forms'])) {
                global $wpdb;
                $table = $wpdb->prefix . 'sigmaforms';
                
                foreach ($settings['forms'] as $form) {
                    // Validate form data
                    if (!isset($form['title']) || !isset($form['form_fields']) || !isset($form['form_settings'])) {
                        $skipped_forms_count++;
                        continue;
                    }
                    
                    // Sanitize form data
                    // NOTE: The 'id' field from exported form is intentionally NOT used
                    $title = sanitize_text_field($form['title']);
                    $form_fields = is_array($form['form_fields']) ? $form['form_fields'] : [];
                    $form_settings = is_array($form['form_settings']) ? $form['form_settings'] : [];
                    $status = isset($form['status']) ? sanitize_text_field($form['status']) : 'publish';
                    
                    // Use Helper class to sanitize fields and settings
                    $form_fields = \SigmaForms\Utils\Helper::sanitize_form_fields($form_fields);
                    $form_settings = \SigmaForms\Utils\Helper::sanitize_form_settings($form_settings);
                    
                    // ALWAYS INSERT as a new form - never update existing forms
                    // The database will auto-generate a new ID regardless of the exported form's ID
                    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $result = $wpdb->insert(
                        $table,
                        [
                            'title' => $title,
                            'form_fields' => wp_json_encode($form_fields),
                            'form_settings' => wp_json_encode($form_settings),
                            'date_created' => current_time('mysql'),
                            'date_modified' => current_time('mysql'),
                            'status' => $status,
                        ],
                        ['%s', '%s', '%s', '%s', '%s', '%s']
                    );
                    
                    if ($result !== false) {
                        $imported_forms_count++;
                        
                        // Trigger action hook for form creation with the NEW auto-generated ID
                        $new_form_id = $wpdb->insert_id;
                        do_action('sigmaforms_created', $new_form_id, [
                            'title' => $title,
                            'fields' => $form_fields,
                            'settings' => $form_settings,
                        ]);
                    } else {
                        $skipped_forms_count++;
                    }
                }
            }

            // Build success message
            $message = __('Settings imported successfully.', 'sigmaforms-pro');
            
            // Add forms import info if toggle was enabled
            if ($include_forms) {
                if ($imported_forms_count > 0) {
                    $message .= ' ' . sprintf(
                        /* translators: %d: number of forms imported */
                        _n('%d form imported.', '%d forms imported.', $imported_forms_count, 'sigmaforms-pro'),
                        $imported_forms_count
                    );
                }
                if ($skipped_forms_count > 0) {
                    $message .= ' ' . sprintf(
                        /* translators: %d: number of forms skipped */
                        _n('%d form skipped due to invalid data.', '%d forms skipped due to invalid data.', $skipped_forms_count, 'sigmaforms-pro'),
                        $skipped_forms_count
                    );
                }
                // If forms were in the JSON but none imported
                if (isset($settings['forms']) && !empty($settings['forms']) && $imported_forms_count === 0 && $skipped_forms_count === 0) {
                    // This shouldn't happen, but just in case
                }
            } else {
                // If toggle was disabled but forms exist in JSON
                if (isset($settings['forms']) && !empty($settings['forms'])) {
                    $forms_count = count($settings['forms']);
                    $message .= ' ' . sprintf(
                        /* translators: %d: number of forms skipped */
                        _n('%d form was skipped (import forms toggle disabled).', '%d forms were skipped (import forms toggle disabled).', $forms_count, 'sigmaforms-pro'),
                        $forms_count
                    );
                }
            }

            wp_send_json_success([
                'message' => $message,
                'imported_forms' => $imported_forms_count,
                'skipped_forms' => $skipped_forms_count,
            ]);
        } catch (\Exception $e) {
            wp_send_json_error([
                'message' => __('Failed to import settings: ', 'sigmaforms-pro') . $e->getMessage(),
            ]);
        }
    }

    /**
     * Crop a label or option image and store the result as a new attachment.
     *
     * Driven by wp.media.controller.Cropper in the field settings popup. The
     * original attachment is never modified - the crop is saved alongside it so
     * the same source image can be cropped differently per field.
     *
     * @return void
     */
    public function ajax_crop_image()
    {
        check_ajax_referer('sf-admin-nonce', 'nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error([
                'message' => __('You are not allowed to edit images.', 'sigmaforms-pro'),
            ]);
        }

        $attachment_id = isset($_POST['id']) ? absint($_POST['id']) : 0;

        if (!$attachment_id || get_post_type($attachment_id) !== 'attachment' || !wp_attachment_is_image($attachment_id)) {
            wp_send_json_error([
                'message' => __('That image could not be found.', 'sigmaforms-pro'),
            ]);
        }

        // Same rule as WordPress core's own crop handler.
        if (!current_user_can('edit_post', $attachment_id)) {
            wp_send_json_error([
                'message' => __('You do not have permission to edit this image.', 'sigmaforms-pro'),
            ], 403);
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each key is cast with absint() below
        $raw_crop = isset($_POST['cropDetails']) && is_array($_POST['cropDetails']) ? wp_unslash($_POST['cropDetails']) : [];
        $crop = [];

        foreach (['x1', 'y1', 'width', 'height', 'dst_width', 'dst_height'] as $key) {
            $crop[$key] = isset($raw_crop[$key]) ? absint($raw_crop[$key]) : 0;
        }

        if ($crop['width'] < 1 || $crop['height'] < 1) {
            wp_send_json_error([
                'message' => __('Please select an area to crop.', 'sigmaforms-pro'),
            ]);
        }

        if ($crop['dst_width'] < 1 || $crop['dst_height'] < 1) {
            $crop['dst_width'] = $crop['width'];
            $crop['dst_height'] = $crop['height'];
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';

        $cropped = wp_crop_image(
            $attachment_id,
            $crop['x1'],
            $crop['y1'],
            $crop['width'],
            $crop['height'],
            $crop['dst_width'],
            $crop['dst_height']
        );

        if (!$cropped || is_wp_error($cropped)) {
            wp_send_json_error([
                'message' => __('The image could not be cropped.', 'sigmaforms-pro'),
            ]);
        }

        $cropped = wp_normalize_path($cropped);

        // Derive the public URL of the cropped file from its source attachment.
        $parent_url = wp_get_attachment_url($attachment_id);
        $cropped_url = str_replace(wp_basename($parent_url), wp_basename($cropped), $parent_url);

        $size = @getimagesize($cropped); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a failed read falls back to the parent mime type
        $mime_type = ($size && !empty($size['mime'])) ? $size['mime'] : get_post_mime_type($attachment_id);

        $new_attachment_id = wp_insert_attachment(
            [
                'post_title'     => wp_basename($cropped),
                'post_mime_type' => $mime_type,
                'post_content'   => '',
                'post_status'    => 'inherit',
                'guid'           => $cropped_url,
            ],
            $cropped
        );

        if (!$new_attachment_id || is_wp_error($new_attachment_id)) {
            wp_send_json_error([
                'message' => __('The cropped image could not be saved.', 'sigmaforms-pro'),
            ]);
        }

        wp_update_attachment_metadata(
            $new_attachment_id,
            wp_generate_attachment_metadata($new_attachment_id, $cropped)
        );

        wp_send_json_success(wp_prepare_attachment_for_js($new_attachment_id));
    }
} 
