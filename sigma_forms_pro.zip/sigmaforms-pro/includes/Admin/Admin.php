<?php
/**
 * Admin class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\Plugin;
use SigmaForms\Utils\GoogleDriveOAuth;
use SigmaForms\Utils\OneDriveOAuth;

class Admin {
    
    /**
     * Plugin instance
     *
     * @var Plugin
     */
    private $plugin;
    
    /**
     * Admin menus instance
     *
     * @var AdminMenus
     */
    private $menus;
    
    /**
     * Admin AJAX instance
     *
     * @var AdminAjax
     */
    private $ajax;
    
    /**
     * Admin settings instance
     *
     * @var AdminSettings
     */
    private $settings;
    
    /**
     * Admin notices instance
     *
     * @var AdminNotices
     */
    private $notices;
    
    /**
     * Constructor
     *
     * @param Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        
        // Initialize sub-modules
        $this->init_modules();
        
        // Register hooks
        $this->register_hooks();
        
        // Initialize dashboard widget
        new DashboardWidget($plugin);
    }
    
    /**
     * Initialize sub-modules
     *
     * @return void
     */
    private function init_modules() {
        $this->menus = new AdminMenus($this->plugin);
        $this->ajax = new AdminAjax($this->plugin);
        $this->settings = new AdminSettings();
        $this->notices = new AdminNotices();
    }
    
    /**
     * Register hooks
     *
     * @return void
     */
    private function register_hooks() {
        // Menu hooks
        add_action('admin_menu', [$this->menus, 'register_admin_menu']);
        
        // AJAX hooks
        add_action('wp_ajax_sf_generate_form', [$this->ajax, 'ajax_generate_form']);
        add_action('wp_ajax_sf_save_form', [$this->ajax, 'ajax_save_form']);
        add_action('wp_ajax_sf_delete_form', [$this->ajax, 'ajax_delete_form']);
        add_action('wp_ajax_sf_duplicate_form', [$this->ajax, 'ajax_duplicate_form']);
        add_action('wp_ajax_sf_delete_submission', [$this->ajax, 'ajax_delete_submission']);
        add_action('wp_ajax_sf_get_suggested_conditions', [$this->ajax, 'ajax_get_suggested_conditions']);
        add_action('wp_ajax_sf_test_smtp', [$this->settings, 'test_smtp_connection']);
        add_action('wp_ajax_sf_process_settings', [$this->ajax, 'ajax_process_settings']);
        add_action('wp_ajax_sf_bulk_delete_submissions', [$this->ajax, 'ajax_bulk_delete_submissions']);
        add_action('wp_ajax_sf_bulk_mark_submissions_as_read', [$this->ajax, 'ajax_bulk_mark_submissions_as_read']);
        add_action('wp_ajax_sf_bulk_mark_submissions_as_unread', [$this->ajax, 'ajax_bulk_mark_submissions_as_unread']);
        add_action('wp_ajax_sf_delete_abandoned_form', [$this->ajax, 'ajax_delete_abandoned_form']);
        add_action('wp_ajax_sf_bulk_delete_abandoned_forms', [$this->ajax, 'ajax_bulk_delete_abandoned_forms']);
        add_action('wp_ajax_sf_connect_google_drive', [$this->ajax, 'ajax_connect_google_drive']);
        add_action('wp_ajax_sf_disconnect_google_drive', [$this->ajax, 'ajax_disconnect_google_drive']);
        add_action('wp_ajax_sf_connect_onedrive', [$this->ajax, 'ajax_connect_onedrive']);
        add_action('wp_ajax_sf_disconnect_onedrive', [$this->ajax, 'ajax_disconnect_onedrive']);
        add_action('wp_ajax_sf_export_settings', [$this->ajax, 'ajax_export_settings']);
        add_action('wp_ajax_sf_import_settings', [$this->ajax, 'ajax_import_settings']);
        add_action('wp_ajax_sf_crop_image', [$this->ajax, 'ajax_crop_image']);
        
        // Handle admin actions early to prevent headers already sent issues
        add_action('admin_init', [$this, 'handle_admin_actions']);

        
        // Action hooks for exports
        add_action('admin_action_export_abandoned_forms', [$this, 'handle_export_abandoned_forms']);
        add_action('admin_action_export_submissions', [$this, 'handle_export_submissions']);
        
        // Notice hooks
        add_action('admin_notices', [$this->notices, 'admin_notices']);

        // Enqueue scripts and styles
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    }
    
    /**
     * Get menus instance for external access
     *
     * @return AdminMenus
     */
    public function get_menus() {
        return $this->menus;
    }
    
    /**
     * Get AJAX instance for external access
     *
     * @return AdminAjax
     */
    public function get_ajax() {
        return $this->ajax;
    }
    
    /**
     * Get settings instance for external access
     *
     * @return AdminSettings
     */
    public function get_settings() {
        return $this->settings;
    }
    
    /**
     * Get notices instance for external access
     *
     * @return AdminNotices
     */
    public function get_notices() {
        return $this->notices;
    }

    public function add_menu_pages() {
        // ... existing code ...
    }

    public function enqueue_admin_assets($hook) {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Reading page parameter for conditional asset loading
        $current_page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        
        // Add the hook for the "Add New" form page
        $allowed_hooks = [
            'toplevel_page_sigmaforms',
            'sigmaforms_page_sigmaforms-settings',
            'sigmaforms_page_sigmaforms-new',
            'sigmaforms_page_sigmaforms-submissions',
            'sigmaforms_page_sigmaforms-abandoned',
            'sigmaforms_page_sigmaforms-analytics',
            'sigmaforms_page_sigmaforms-white-label',
            'sigmaforms_page_sigmaforms_license',
        ];
        
        // Also allow by page parameter (for language compatibility)
        $allowed_pages = [
            'sigmaforms',
            'sigmaforms-settings',
            'sigmaforms-new',
            'sigmaforms-submissions',
            'sigmaforms-abandoned',
            'sigmaforms-analytics',
            'sigmaforms-white-label',
            'sigmaforms_license',
        ];
        
        if (!in_array($hook, $allowed_hooks) && !in_array($current_page, $allowed_pages)) {
            return;
        }

        // Enqueue main admin styles/scripts
        wp_enqueue_style('sf-admin-styles');
        // admin.js is registered as sf-admin-script (with its modules and the
        // sfAdmin data) in Plugin::register_admin_assets(). It used to be
        // enqueued a second time here as "sf-admin", so it ran twice per page.
        wp_enqueue_script('sf-admin-script');
        wp_enqueue_script('sf-admin-nav', SF_PLUGIN_URL . 'assets/js/admin-nav.js', [], SF_VERSION, true);
        wp_localize_script('sf-admin-nav', 'sfAdminNav', array(
            'unsavedChanges' => __('You have unsaved changes. Leave this page anyway?', 'sigmaforms-pro'),
        ));

        if ($current_page === 'sigmaforms-white-label') {
            wp_enqueue_script('wp-api-fetch');
            wp_enqueue_style('sf-white-label-styles');
            wp_enqueue_script('sf-white-label');
            wp_enqueue_media();
        }

        // Enqueue wizard styles/scripts for the "Add New" form page
        if ($hook === 'sigmaforms_page_sigmaforms-new') {
            wp_enqueue_style('sf-wizard-styles', SF_PLUGIN_URL . 'assets/css/wizard.css', ['sf-admin-styles'], SF_VERSION);
            wp_enqueue_script('sf-wizard-script', SF_PLUGIN_URL . 'assets/js/wizard.js', ['jquery', 'sf-admin-script'], SF_VERSION, true);
        }

        // Add settings-specific assets and localization
        // Check both exact hook match and page parameter for better compatibility across languages
        $is_settings_page = ($hook === 'sigmaforms_page_sigmaforms-settings') || ($current_page === 'sigmaforms-settings');
        
        if ($is_settings_page) {
                        
            $settings_data = [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('sf-admin-nonce'),
                'test_smtp_nonce' => wp_create_nonce('sf_test_smtp'),
                'storage_nonce' => wp_create_nonce('sf_storage_nonce'),
                'show_text' => __('Show', 'sigmaforms-pro'),
                'hide_text' => __('Hide', 'sigmaforms-pro'),
                'test_text' => __('Test SMTP Connection', 'sigmaforms-pro'),
                'testing_text' => __('Testing...', 'sigmaforms-pro'),
                'test_smtp_text' => __('Test SMTP Connection', 'sigmaforms-pro'),
                'connection_error_text' => __('Connection error occurred. Please try again.', 'sigmaforms-pro'),
                'saving_text' => __('Saving...', 'sigmaforms-pro'),
                'save_text' => __('Save Settings', 'sigmaforms-pro'),
                'save_success_text' => __('Settings saved successfully!', 'sigmaforms-pro'),
                'save_error_text' => __('Error saving settings. Please try again.', 'sigmaforms-pro'),
                'google_connect_text' => __('Sign in with Google', 'sigmaforms-pro'),
                'onedrive_connect_text' => __('Sign in with Microsoft', 'sigmaforms-pro'),
                'connecting_text' => __('Connecting...', 'sigmaforms-pro'),
                'disconnecting_text' => __('Disconnecting...', 'sigmaforms-pro'),
            ];

            wp_enqueue_script('sf-settings', SF_PLUGIN_URL . 'assets/js/modules/settings.js', ['jquery'], SF_VERSION, true);
            wp_localize_script('sf-settings', 'sf_settings', $settings_data);
        }

    }
    
    /**
     * Handle export of abandoned forms to CSV
     *
     * @return void
     */
    public function handle_export_abandoned_forms() {
        // Verify nonce
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'export_abandoned_forms')) {
            wp_die(esc_html__('Security check failed.', 'sigmaforms-pro'), '', array('back_link' => true));
        }

        // Check permissions
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'sigmaforms-pro'), '', array('back_link' => true));
        }
        
        // Get filters
        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        $status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : 'all';
        
        // Build filters array
        $filters = [];
        if ($form_id > 0) {
            $filters['form_id'] = $form_id;
        }
        if ($status === 'converted') {
            $filters['is_converted'] = true;
        } elseif ($status === 'abandoned') {
            $filters['is_converted'] = false;
        }
        
        // Get all abandoned forms (no pagination for export)
        $abandoned_forms_manager = $this->plugin->abandoned_forms;
        $abandoned_forms = $abandoned_forms_manager->get_abandoned_forms(1, 9999, $filters);
        
        // Get forms for title lookup
        $forms_manager = $this->plugin->forms;
        $forms = $forms_manager->get_forms();
        $forms_lookup = [];
        foreach ($forms as $form) {
            $forms_lookup[$form['id']] = $form['title'];
        }
        
        // Set headers for CSV download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="abandoned-forms-' . gmdate('Y-m-d') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Create output stream
        $output = fopen('php://output', 'w');
        
        // Add BOM for UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // CSV headers - including all available fields
        $headers = [
            __('Abandoned Form ID', 'sigmaforms-pro'),
            __('Form ID', 'sigmaforms-pro'),
            __('Form Name', 'sigmaforms-pro'),
            __('Session ID', 'sigmaforms-pro'),
            __('User ID', 'sigmaforms-pro'),
            __('Progress (%)', 'sigmaforms-pro'),
            __('Fields Filled', 'sigmaforms-pro'),
            __('Time Spent (minutes)', 'sigmaforms-pro'),
            __('Start Time', 'sigmaforms-pro'),
            __('Last Activity', 'sigmaforms-pro'),
            __('Status', 'sigmaforms-pro'),
            __('Abandonment Type', 'sigmaforms-pro'),
            __('Field Values (JSON)', 'sigmaforms-pro'),
            __('IP Address', 'sigmaforms-pro'),
            __('User Agent', 'sigmaforms-pro'),
        ];
        
        // Field labels and stored keys become header cells, so escape formulas here too.
        fputcsv($output, \SigmaForms\Utils\Helper::sanitize_csv_row($headers), ',', '"', ''); // RFC 4180: no backslash escape
        
        // Add data rows
        foreach ($abandoned_forms as $abandoned_form) {
            $form_title = isset($forms_lookup[$abandoned_form->get_form_id()]) 
                ? $forms_lookup[$abandoned_form->get_form_id()] 
                : __('Unknown Form', 'sigmaforms-pro');
            
            $status = $abandoned_form->is_converted() 
                ? __('Converted', 'sigmaforms-pro') 
                : __('Abandoned', 'sigmaforms-pro');
            
            $abandonment_type = $abandoned_form->is_converted() 
                ? '' 
                : ucfirst(str_replace('_', ' ', $abandoned_form->get_abandonment_type()));
            
            $row = [
                $abandoned_form->get_id(), // Abandoned Form ID
                $abandoned_form->get_form_id(), // Form ID
                $form_title, // Form Name
                $abandoned_form->get_session_id(), // Session ID
                $abandoned_form->get_user_id(), // User ID
                $abandoned_form->get_completion_percentage(), // Progress (%)
                $abandoned_form->get_filled_fields_count(), // Fields Filled
                $abandoned_form->get_time_spent(), // Time Spent (minutes)
                $abandoned_form->get_formatted_start_time(), // Start Time
                $abandoned_form->get_formatted_last_activity(), // Last Activity
                $status, // Status
                $abandonment_type, // Abandonment Type
                wp_json_encode($abandoned_form->get_field_values()), // Field Values (JSON)
                $abandoned_form->get_ip_address(), // IP Address
                $abandoned_form->get_user_agent(), // User Agent
            ];

            fputcsv($output, \SigmaForms\Utils\Helper::sanitize_csv_row($row), ',', '"', ''); // RFC 4180: a \" in the JSON column broke the row
        }
        
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($output);
        exit;
    }
    
    /**
     * Field columns for a submissions export, keyed by field id.
     *
     * Labels come from the forms' field definitions, in form order. Values
     * stored under ids no longer on the form (deleted fields) get a column
     * named after the id, so nothing is dropped.
     *
     * @param array $submissions Submission rows.
     * @return array<string, string> Field id => column label.
     */
    private function get_submission_export_columns($submissions) {
        $columns = [];
        $form_ids = array_unique(array_map('intval', array_column($submissions, 'form_id')));

        foreach ($form_ids as $export_form_id) {
            $form = $this->plugin->forms->get_form($export_form_id);
            if (!$form || empty($form['form_fields'])) {
                continue;
            }

            foreach ((array) $form['form_fields'] as $field) {
                if (empty($field['id']) || (isset($field['type']) && in_array($field['type'], ['section_heading', 'page_break'], true))) {
                    continue;
                }
                if (!isset($columns[$field['id']])) {
                    $columns[$field['id']] = !empty($field['label']) ? $field['label'] : $field['id'];
                }
            }
        }

        foreach ($submissions as $submission) {
            $values = json_decode($submission['field_values'], true);
            foreach (array_keys(is_array($values) ? $values : []) as $field_id) {
                if (!isset($columns[$field_id])) {
                    $columns[$field_id] = $field_id;
                }
            }
        }

        // Two fields with the same label would give two identical headers.
        $seen = [];
        foreach ($columns as $field_id => $header) {
            $seen[$header] = isset($seen[$header]) ? $seen[$header] + 1 : 1;
            if ($seen[$header] > 1) {
                $columns[$field_id] = $header . ' (' . $seen[$header] . ')';
            }
        }

        return $columns;
    }

    /**
     * A submitted value as a single spreadsheet cell.
     *
     * @param mixed $value Stored value.
     * @return string
     */
    private function format_export_value($value) {
        if (is_array($value)) {
            return implode(', ', array_map(function ($item) {
                return is_scalar($item) ? (string) $item : wp_json_encode($item);
            }, $value));
        }

        $value = (string) $value;

        // Base64 signatures can run to megabytes; a cell cannot usefully hold one.
        if (strpos($value, 'data:image/') === 0) {
            return __('[signature image]', 'sigmaforms-pro');
        }

        return $value;
    }

    /**
     * Handle export of submissions to CSV
     *
     * @return void
     */
    public function handle_export_submissions() {
        // Verify nonce
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'export_submissions')) {
            wp_die(esc_html__('Security check failed.', 'sigmaforms-pro'), '', array('back_link' => true));
        }

        // Check permissions
        if (!\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'sigmaforms-pro'), '', array('back_link' => true));
        }
        
        // Get form_id filter
        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        
        // Get submissions from database
        global $wpdb;
        $submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
        $forms_table = $wpdb->prefix . 'sigmaforms';
        
        $where = '';
        $params = [];
        
        if ($form_id > 0) {
            $where = 'WHERE s.form_id = %d';
            $params[] = $form_id;
        }
        
        $query = "
            SELECT s.*, f.title as form_title 
            FROM {$submissions_table} s 
            LEFT JOIN {$forms_table} f ON s.form_id = f.id 
            {$where}
            ORDER BY s.date_created DESC
        ";
        
        if (!empty($params)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $submissions = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
        } else {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $submissions = $wpdb->get_results($query, ARRAY_A);
        }
        
        // Set headers for CSV download
        $filename = $form_id > 0 ? 'submissions-form-' . $form_id . '-' . gmdate('Y-m-d') . '.csv' : 'submissions-all-' . gmdate('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Create output stream
        $output = fopen('php://output', 'w');
        
        // Add BOM for UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // CSV headers - matching abandoned forms format
        $headers = [
            __('Submission ID', 'sigmaforms-pro'),
            __('Form ID', 'sigmaforms-pro'),
            __('Form Name', 'sigmaforms-pro'),
            __('User ID', 'sigmaforms-pro'),
            __('Status', 'sigmaforms-pro'),
            __('Date Submitted', 'sigmaforms-pro'),
            __('Field Values (JSON)', 'sigmaforms-pro'),
            __('IP Address', 'sigmaforms-pro'),
            __('User Agent', 'sigmaforms-pro'),
        ];

        // One column per form field, appended after the original columns so
        // anything that reads the JSON column by position keeps working.
        $field_columns = $this->get_submission_export_columns($submissions);
        foreach ($field_columns as $column_label) {
            $headers[] = $column_label;
        }
        
        // Field labels and stored keys become header cells, so escape formulas here too.
        fputcsv($output, \SigmaForms\Utils\Helper::sanitize_csv_row($headers), ',', '"', ''); // RFC 4180: no backslash escape
        
        // Add data rows
        foreach ($submissions as $submission) {
            // Format date
            $date_created = mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $submission['date_created']);
            
            // Decode and re-encode field values to ensure clean JSON without HTML entities
            $field_values = json_decode($submission['field_values'], true) ?: [];
            $clean_field_values = wp_json_encode($field_values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            
            $row = [
                $submission['id'], // Submission ID
                $submission['form_id'], // Form ID
                $submission['form_title'], // Form Name
                $submission['user_id'] ?: __('Guest', 'sigmaforms-pro'), // User ID
                ucfirst($submission['status']), // Status
                $date_created, // Date Submitted
                $clean_field_values, // Field Values (JSON)
                isset($submission['user_ip']) ? $submission['user_ip'] : '', // IP Address
                isset($submission['user_agent']) ? $submission['user_agent'] : '', // User Agent
            ];

            foreach (array_keys($field_columns) as $field_id) {
                $row[] = $this->format_export_value(isset($field_values[$field_id]) ? $field_values[$field_id] : '');
            }

            fputcsv($output, \SigmaForms\Utils\Helper::sanitize_csv_row($row), ',', '"', ''); // RFC 4180: a \" in the JSON column broke the row
        }
        
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($output);
        exit;
    }
    
    /**
     * Handle admin actions early to prevent headers already sent issues
     *
     * @return void
     */
    public function handle_admin_actions() {
        if (!is_admin() || !\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
            return;
        }
        
        // Handle OAuth callbacks for cloud storage (a settings task, admins only)
        if (current_user_can('manage_options')) {
            $this->handle_oauth_callbacks();
        }
        
        // Only process on our admin pages
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        if ($page !== 'sigmaforms-abandoned') {
            return;
        }
        
        // Handle delete action
        $action = isset($_GET['action']) ? sanitize_text_field(wp_unslash($_GET['action'])) : '';
        if ($action === 'delete') {
            $abandoned_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
            $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
            
            if (!wp_verify_nonce(wp_unslash($nonce), 'delete_abandoned_form')) {
                wp_die(
                    esc_html__('Invalid or missing nonce for deleting abandoned form.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
            }
            
            if ($abandoned_id > 0) {
                $result = $this->plugin->abandoned_forms->delete_abandoned_form($abandoned_id);
                
                if ($result) {
                    wp_safe_redirect(add_query_arg([
                        'page' => 'sigmaforms-abandoned',
                        'message' => 'deleted'
                    ], admin_url('admin.php')));
                    exit;
                } else {
                    wp_die(esc_html__('Failed to delete abandoned form record.', 'sigmaforms-pro'), '', array('back_link' => true));
                }
            } else {
                wp_die(esc_html__('Invalid abandoned form ID.', 'sigmaforms-pro'), '', array('back_link' => true));
            }
        }
    }

    /**
     * Handle OAuth callbacks for cloud storage providers
     *
     * @return void
     */
    private function handle_oauth_callbacks() {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- OAuth callback parameters from external providers (Google/Microsoft), security verified via state parameter
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        $tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : '';
        $provider = isset($_GET['provider']) ? sanitize_text_field(wp_unslash($_GET['provider'])) : '';
        $code = isset($_GET['code']) ? sanitize_text_field(wp_unslash($_GET['code'])) : '';
        $state = isset($_GET['state']) ? sanitize_text_field(wp_unslash($_GET['state'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ($page !== 'sigmaforms-settings' || $tab !== 'storage' || empty($provider) || empty($code)) {
            return;
        }

        if ($provider === 'google') {
            $this->handle_google_oauth_callback($code, $state);
        } elseif ($provider === 'onedrive') {
            $this->handle_onedrive_oauth_callback($code, $state);
        }
    }

    /**
     * Handle Google Drive OAuth callback
     *
     * @param string $code Authorization code from Google.
     * @param string $state State parameter for CSRF protection.
     * @return void
     */
    private function handle_google_oauth_callback($code, $state) {
        // Verify state to prevent CSRF.
        $stored_state = get_transient('sf_google_oauth_state');
        if (!$stored_state || $state !== $stored_state) {
            wp_die(esc_html__('Invalid state parameter. Please try connecting again.', 'sigmaforms-pro'), '', array('back_link' => true));
        }

        // Delete the state transient.
        delete_transient('sf_google_oauth_state');

        // Exchange code for tokens using the OAuth handler.
        $result = GoogleDriveOAuth::exchange_code_for_tokens($code);

        if (is_wp_error($result)) {
            wp_die(esc_html__('Failed to connect to Google Drive: ', 'sigmaforms-pro') . esc_html($result->get_error_message()));
        }

        // Store tokens.
        update_option('sf_google_drive_access_token', $result['access_token']);
        if (!empty($result['refresh_token'])) {
            update_option('sf_google_drive_refresh_token', $result['refresh_token']);
        }
        update_option('sf_google_drive_token_expiry', time() + $result['expires_in']);

        // Auto-enable Google Drive storage after successful connection
        $settings = get_option('sigmaforms_settings', []);
        $settings['storage_google_drive_enabled'] = true;
        update_option('sigmaforms_settings', $settings);

        // Redirect back to settings page with success message.
        wp_safe_redirect(add_query_arg([
            'page' => 'sigmaforms-settings',
            'tab' => 'storage',
            'google_connected' => '1',
        ], admin_url('admin.php')));
        exit;
    }

    /**
     * Handle OneDrive OAuth callback
     *
     * @param string $code Authorization code from OneDrive.
     * @param string $state State parameter for CSRF protection.
     * @return void
     */
    private function handle_onedrive_oauth_callback($code, $state) {
        // Verify state to prevent CSRF.
        $stored_state = get_transient('sf_onedrive_oauth_state');
        if (!$stored_state || $state !== $stored_state) {
            wp_die(esc_html__('Invalid state parameter. Please try connecting again.', 'sigmaforms-pro'), '', array('back_link' => true));
        }

        // Delete the state transient.
        delete_transient('sf_onedrive_oauth_state');

        // Exchange code for tokens using the OAuth handler.
        $result = OneDriveOAuth::exchange_code_for_tokens($code);

        if (is_wp_error($result)) {
            wp_die(esc_html__('Failed to connect to OneDrive: ', 'sigmaforms-pro') . esc_html($result->get_error_message()));
        }

        // Store tokens.
        update_option('sf_onedrive_access_token', $result['access_token']);
        if (!empty($result['refresh_token'])) {
            update_option('sf_onedrive_refresh_token', $result['refresh_token']);
        }
        update_option('sf_onedrive_token_expiry', time() + $result['expires_in']);

        // Auto-enable OneDrive storage after successful connection
        $settings = get_option('sigmaforms_settings', []);
        $settings['storage_onedrive_enabled'] = true;
        update_option('sigmaforms_settings', $settings);

        // Redirect back to settings page with success message.
        wp_safe_redirect(add_query_arg([
            'page' => 'sigmaforms-settings',
            'tab' => 'storage',
            'onedrive_connected' => '1',
        ], admin_url('admin.php')));
        exit;
    }
}
