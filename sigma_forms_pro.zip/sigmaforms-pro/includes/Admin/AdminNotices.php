<?php
/**
 * Admin Notices class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\Utils\Helper;

class AdminNotices {
    
    /**
     * Show admin notices
     *
     * @return void
     */
    public function admin_notices() {
        // ... existing code ...
    }
} 