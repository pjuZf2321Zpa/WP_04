<?php

/**
 * Admin Menus class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Admin;

use SigmaForms\Plugin;
use SigmaForms\License\Forms;
use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\WhiteLabel\WhiteLabelAdmin;

class AdminMenus {
    /**
     * Plugin instance
     *
     * @var Plugin
     */
    private $plugin;

    /**
     * Admin settings instance
     *
     * @var AdminSettings
     */
    private $settings;

    /**
     * Constructor
     *
     * @param Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->settings = new AdminSettings();
        add_action('admin_menu', [$this, 'add_toplevel_menu_li_class'], 999);
    }

    /**
     * Append class on the top-level admin menu li.
     *
     * @return void
     */
    public function add_toplevel_menu_li_class() {
        global $menu;
        if (!is_array($menu)) {
            return;
        }
        foreach ($menu as $key => $item) {
            if (isset($item[2], $item[4]) && $item[2] === 'sigmaforms') {
                $menu[$key][4] .= ' sf-admin-root-menu';
                break;
            }
        }
    }

    /**
     * Menu icon (custom WL image URL or default dashicon).
     *
     * @return string
     */
    private function get_menu_page_icon_url() {
        if (get_option(WhiteLabel::OPTION_ENABLED, false)) {
            $icon = trim((string) get_option(WhiteLabel::OPTION_ICON, ''));
            if ($icon !== '') {
                return esc_url($icon);
            }
        }

        return 'dashicons-feedback';
    }

    /**
     * Register admin menu
     *
     * @return void
     */
    public function register_admin_menu() {
        $menu_title = WhiteLabel::get_display_name();

        // Main menu
        add_menu_page(
            $menu_title,
            $menu_title,
            \SigmaForms\Utils\Helper::get_manage_forms_capability(),
            'sigmaforms',
            [$this, 'render_main_page'],
            $this->get_menu_page_icon_url(),
            25
        );

        // Forms subpage
        add_submenu_page(
            'sigmaforms',
            __('Forms', 'sigmaforms-pro'),
            __('Forms', 'sigmaforms-pro'),
            \SigmaForms\Utils\Helper::get_manage_forms_capability(),
            'sigmaforms',
            [$this, 'render_main_page']
        );

        // Add form subpage
        add_submenu_page(
            'sigmaforms',
            __('Add New', 'sigmaforms-pro'),
            __('Add New', 'sigmaforms-pro'),
            \SigmaForms\Utils\Helper::get_manage_forms_capability(),
            'sigmaforms-new',
            [$this, 'render_add_form_page']
        );

        // Submissions subpage
        add_submenu_page(
            'sigmaforms',
            __('Submissions', 'sigmaforms-pro'),
            __('Submissions', 'sigmaforms-pro'),
            \SigmaForms\Utils\Helper::get_manage_forms_capability(),
            'sigmaforms-submissions',
            [$this, 'render_submissions_page']
        );

        // Abandoned Forms subpage
        add_submenu_page(
            'sigmaforms',
            __('Abandoned Forms', 'sigmaforms-pro'),
            __('Abandoned Forms', 'sigmaforms-pro'),
            \SigmaForms\Utils\Helper::get_manage_forms_capability(),
            'sigmaforms-abandoned',
            [$this, 'render_abandoned_forms_page']
        );

        // Analytics subpage
        add_submenu_page(
            'sigmaforms',
            __('Analytics', 'sigmaforms-pro'),
            __('Analytics', 'sigmaforms-pro'),
            \SigmaForms\Utils\Helper::get_manage_forms_capability(),
            'sigmaforms-analytics',
            [$this, 'render_analytics_page']
        );

        // Settings subpage
        add_submenu_page(
            'sigmaforms',
            __('Settings', 'sigmaforms-pro'),
            __('Settings', 'sigmaforms-pro'),
            'manage_options',
            'sigmaforms-settings',
            [$this, 'render_settings_page']
        );

        if (WhiteLabel::is_white_label_license()) {
            add_submenu_page(
                'sigmaforms',
                __('White Label', 'sigmaforms-pro'),
                __('White Label', 'sigmaforms-pro'),
                'manage_options',
                'sigmaforms-white-label',
                [$this, 'render_white_label_page']
            );
        }
    }

    /**
     * Render white label settings page.
     *
     * @return void
     */
    public function render_white_label_page() {
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_style('sf-white-label-styles');
        wp_enqueue_script('wp-api-fetch');
        wp_enqueue_script('sf-admin-script');
        wp_enqueue_script('sf-white-label');
        wp_enqueue_media();

        include SF_PLUGIN_DIR . 'admin/views/white-label.php';
    }

    /**
     * Render main admin page
     *
     * @return void
     */
    public function render_main_page() {
        // Enqueue admin assets
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_script('sf-admin-script');

        // Get forms
        $forms_manager = $this->plugin->forms;
        $forms = $forms_manager->get_forms();

        include SF_PLUGIN_DIR . 'admin/views/forms-list.php';
    }

    /**
     * Render add form page
     *
     * @return void
     */
    public function render_add_form_page() {
        // Enqueue admin assets
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_style('sf-wizard-styles');
        wp_enqueue_script('sf-admin-script');
        wp_enqueue_script('sf-wizard-script');

        // Handle form ID parameter for editing
        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        $form = null;

        if ($form_id > 0) {
            $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
            if (!wp_verify_nonce(wp_unslash($nonce), 'edit_form_' . $form_id)) {
                wp_die(
                    esc_html__('Invalid or missing nonce for editing form.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
            }
            $forms_manager = $this->plugin->forms;
            $form = $forms_manager->get_form($form_id);
        }

        include SF_PLUGIN_DIR . 'admin/views/form-editor.php';
    }

    /**
     * Render submissions page
     *
     * @return void
     */
    public function render_submissions_page() {
        // Enqueue admin assets
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_script('sf-admin-script');

        // Get forms for filter
        $forms_manager = $this->plugin->forms;
        $forms = $forms_manager->get_forms();

        // Handle form ID parameter for filtering
        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        if ($form_id > 0 && isset($_GET['_wpnonce'])) {
            $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce']));
            if (!wp_verify_nonce(wp_unslash($nonce), 'view_submissions_form_' . $form_id)) {
                wp_die(
                    esc_html__('Invalid or missing nonce for viewing submissions.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
            }
        }

        // Handle individual submission view
        $submission_id = isset($_GET['submission_id']) ? (int) $_GET['submission_id'] : 0;
        if ($submission_id > 0) {
            $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
            if (!wp_verify_nonce(wp_unslash($nonce), 'view_submission_' . $submission_id)) {
                wp_die(
                    esc_html__('Invalid or missing nonce for viewing submission.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
            }
            // View single submission
            include SF_PLUGIN_DIR . 'admin/views/submission-view.php';
        } else {
            // List submissions
            include SF_PLUGIN_DIR . 'admin/views/submissions-list.php';
        }
    }

    /**
     * Render analytics page
     *
     * @return void
     */
    public function render_analytics_page() {
        // Enqueue admin assets
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_script('sf-admin-script');

        // Enqueue Chart.js for analytics
        wp_enqueue_script('sf-chart-js', plugin_dir_url(dirname(__FILE__, 2)) . 'assets/js/chart/chart.min.js', [], '3.9.1', true);

        // Get forms manager
        $forms_manager = $this->plugin->forms;

        include SF_PLUGIN_DIR . 'admin/views/analytics.php';
    }

    /**
     * Render abandoned forms page
     *
     * @return void
     */
    public function render_abandoned_forms_page() {
        // Enqueue admin assets
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_script('sf-admin-script');

        // Enqueue Chart.js for analytics
        wp_enqueue_script('sf-chart-js', plugin_dir_url(dirname(__FILE__, 2)) . 'assets/js/chart/chart.min.js', [], '3.9.1', true);

        // Get forms for filter
        $forms_manager = $this->plugin->forms;
        $forms = $forms_manager->get_forms();

        // Get abandoned forms manager
        $abandoned_forms_manager = $this->plugin->abandoned_forms;

        // Handle form ID parameter for filtering
        $form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
        // Only validate nonce if there's a filter action
        if ($form_id > 0 && isset($_GET['filter_action']) && $_GET['filter_action'] === 'Filter' && isset($_GET['_wpnonce'])) {
            $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce']));
            if (!wp_verify_nonce(wp_unslash($nonce), 'abandoned_forms_filter')) {
                wp_die(
                    esc_html__('Invalid or missing nonce for viewing abandoned forms.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
            }
        }

        // Handle individual abandoned form view
        $abandoned_id = isset($_GET['abandoned_id']) ? (int) $_GET['abandoned_id'] : 0;
        if ($abandoned_id > 0) {
            $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
            if (!wp_verify_nonce(wp_unslash($nonce), 'view_abandoned_form_' . $abandoned_id)) {
                wp_die(
                    esc_html__('Invalid or missing nonce for viewing abandoned form.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
            }
            // View single abandoned form
            include SF_PLUGIN_DIR . 'admin/views/abandoned-form-view.php';
        } else {
            // List abandoned forms
            include SF_PLUGIN_DIR . 'admin/views/abandoned-forms-list.php';
        }
    }

    /**
     * Render settings page
     *
     * @return void
     */
    public function render_settings_page() {
        // Enqueue admin assets
        wp_enqueue_style('sf-admin-styles');
        wp_enqueue_script('sf-admin-script');

        // Process form submission
        $this->settings->process_settings_form();

        // Get current settings
        $settings = [
            'ai_api_key' => get_option('sf_ai_api_key', ''),
            'admin_email' => get_option('sf_admin_email', get_option('admin_email')),
            'admin_email_cc' => get_option('sf_admin_email_cc', ''),
            'admin_email_bcc' => get_option('sf_admin_email_bcc', ''),
            'app_name' => get_option('sf_app_name', get_bloginfo('name')),
            // translators: %s is the blog name.
            'default_email_subject' => get_option('sf_default_email_subject', sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name'))),
            'default_email_message' => get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro')),
            'default_confirmation_subject' => get_option('sf_default_confirmation_subject', __('Thank you for your submission', 'sigmaforms-pro')),
            'default_confirmation_message' => get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro')),
            'form_styling' => get_option('sf_form_styling', [
                'theme' => 'minimal',
                'button_color' => '#2271b1',
                'field_border' => '#dcdcde',
                'field_background' => '#ffffff',
                'font_family' => 'inherit',
            ]),
            // CAPTCHA settings are now loaded from global settings below
            'smtp_config' => get_option('sf_smtp_config', [
                'enabled' => false,
                'host' => '',
                'port' => 587,
                'encryption' => 'tls',
                'username' => '',
                'password' => '',
            ]),
            'cleanup_days' => get_option('sf_cleanup_days', 90),
            'views_retention_days' => get_option('sf_views_retention_days', 60),
        ];

        // Get webhook settings
        $webhook_settings = get_option('sigmaforms_settings', []);
        $settings = array_merge($settings, $webhook_settings);

        include SF_PLUGIN_DIR . 'admin/views/settings.php';
    }
}
