<?php
/**
 * Form Submission class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Forms;

class FormSubmission {
    /**
     * Submission ID
     *
     * @var int
     */
    private $id;
    
    /**
     * Associated form ID
     *
     * @var int
     */
    private $form_id;
    
    /**
     * Submission field values
     *
     * @var array
     */
    private $field_values;
    
    /**
     * Submitter user ID (if logged in)
     *
     * @var int
     */
    private $user_id;
    
    /**
     * Submitter IP address
     *
     * @var string
     */
    private $user_ip;
    
    /**
     * Submitter user agent
     *
     * @var string
     */
    private $user_agent;
    
    /**
     * Submission date
     *
     * @var string
     */
    private $date_created;
    
    /**
     * Submission status
     *
     * @var string
     */
    private $status;
    
    /**
     * Constructor
     *
     * @param array $submission_data Submission data
     */
    public function __construct($submission_data = []) {
        $this->id = isset($submission_data['id']) ? (int) $submission_data['id'] : 0;
        $this->form_id = isset($submission_data['form_id']) ? (int) $submission_data['form_id'] : 0;
        
        // Handle field values from database or direct array
        if (isset($submission_data['field_values'])) {
            if (is_string($submission_data['field_values'])) {
                $this->field_values = json_decode($submission_data['field_values'], true) ?: [];
            } else {
                $this->field_values = $submission_data['field_values'];
            }
        } else {
            $this->field_values = [];
        }
        
        $this->user_id = isset($submission_data['user_id']) ? (int) $submission_data['user_id'] : 0;
        $this->user_ip = isset($submission_data['user_ip']) ? $submission_data['user_ip'] : '';
        $this->user_agent = isset($submission_data['user_agent']) ? $submission_data['user_agent'] : '';
        $this->date_created = isset($submission_data['date_created']) ? $submission_data['date_created'] : '';
        $this->status = isset($submission_data['status']) ? $submission_data['status'] : 'unread';
    }
    
    /**
     * Get submission data as array
     *
     * @return array Submission data
     */
    public function to_array() {
        return [
            'id' => $this->id,
            'form_id' => $this->form_id,
            'field_values' => $this->field_values,
            'user_id' => $this->user_id,
            'user_ip' => $this->user_ip,
            'user_agent' => $this->user_agent,
            'date_created' => $this->date_created,
            'status' => $this->status,
        ];
    }
    
    /**
     * Get submission ID
     *
     * @return int Submission ID
     */
    public function get_id() {
        return $this->id;
    }
    
    /**
     * Get form ID
     *
     * @return int Form ID
     */
    public function get_form_id() {
        return $this->form_id;
    }
    
    /**
     * Get field values
     *
     * @return array Field values
     */
    public function get_field_values() {
        return $this->field_values;
    }
    
    /**
     * Get a specific field value
     *
     * @param string $field_id Field ID
     * @param mixed $default Default value if field not found
     * @return mixed Field value
     */
    public function get_field_value($field_id, $default = '') {
        return isset($this->field_values[$field_id]) ? $this->field_values[$field_id] : $default;
    }
    
    /**
     * Get user ID
     *
     * @return int User ID
     */
    public function get_user_id() {
        return $this->user_id;
    }
    
    /**
     * Get user IP
     *
     * @return string User IP
     */
    public function get_user_ip() {
        return $this->user_ip;
    }
    
    /**
     * Get user agent
     *
     * @return string User agent
     */
    public function get_user_agent() {
        return $this->user_agent;
    }
    
    /**
     * Get date created
     *
     * @return string Date created
     */
    public function get_date_created() {
        return $this->date_created;
    }
    
    /**
     * Get formatted date
     *
     * @param string $format Date format
     * @return string Formatted date
     */
    public function get_formatted_date($format = '') {
        if (empty($format)) {
            $format = get_option('date_format') . ' ' . get_option('time_format');
        }
        
        return mysql2date($format, $this->date_created);
    }
    
    /**
     * Get status
     *
     * @return string Status
     */
    public function get_status() {
        return $this->status;
    }
    
    /**
     * Mark submission as read
     *
     * @return bool True on success
     */
    public function mark_as_read() {
        if ($this->id <= 0) {
            return false;
        }
        
        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update($table,['status' => 'read'],['id' => $this->id],['%s'],['%d']);
        
        if ($result) {
            $this->status = 'read';
        }
        
        return (bool) $result;
    }
    
    /**
     * Delete submission
     *
     * @return bool True on success
     */
    public function delete() {
        if ($this->id <= 0) {
            return false;
        }
        
        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->delete($table,['id' => $this->id],['%d']);
        
        return (bool) $result;
    }
    
    /**
     * Get submission data in HTML format
     *
     * @return string HTML output of submission data
     */
    public function get_html() {
        if (empty($this->field_values)) {
            return '<p>' . __('No data found.', 'sigmaforms-pro') . '</p>';
        }
        
        $html = '<div class="sf-submission-details">';
        
        // Get form to access field labels
        $form_manager = new FormsManager();
        $form = $form_manager->get_form($this->form_id);
        $fields = [];
        
        if ($form && !empty($form['form_fields'])) {
            foreach ($form['form_fields'] as $field) {
                if (isset($field['id']) && isset($field['label'])) {
                    $fields[$field['id']] = $field;
                }
            }
        }
        
        // Build HTML table of field values
        $html .= '<table class="widefat striped">';
        $html .= '<thead><tr><th>' . __('Field', 'sigmaforms-pro') . '</th><th>' . __('Value', 'sigmaforms-pro') . '</th></tr></thead>';
        $html .= '<tbody>';
        
        foreach ($this->field_values as $field_id => $value) {
            // Skip internal fields
            if (substr($field_id, 0, 1) === '_') {
                continue;
            }
            
            $label = isset($fields[$field_id]['label']) ? $fields[$field_id]['label'] : $field_id;
            
            $html .= '<tr>';
            $html .= '<td><strong>' . esc_html($label) . '</strong></td>';
            
            // Format value based on field type
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            
            $html .= '<td>' . esc_html($value) . '</td>';
            $html .= '</tr>';
        }
        
        $html .= '</tbody></table>';
        
        // Add meta information
        $html .= '<div class="sf-submission-meta">';
        $html .= '<p><strong>' . __('Date:', 'sigmaforms-pro') . '</strong> ' . esc_html($this->get_formatted_date()) . '</p>';

        if ($this->user_id > 0) {
            $user = get_userdata($this->user_id);
            if ($user) {
                $html .= '<p><strong>' . __('User:', 'sigmaforms-pro') . '</strong> ' . esc_html($user->display_name) . ' (' . esc_html($user->user_email) . ')</p>';
            }
        }
        
        $html .= '<p><strong>' . __('IP Address:', 'sigmaforms-pro') . '</strong> ' . esc_html($this->user_ip) . '</p>';
        $html .= '</div>'; // .sf-submission-meta
        
        $html .= '</div>'; // .sf-submission-details
        
        return $html;
    }
}
