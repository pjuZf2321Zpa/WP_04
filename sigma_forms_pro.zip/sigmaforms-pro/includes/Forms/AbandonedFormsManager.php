<?php
/**
 * Abandoned Forms Manager for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Forms;

class AbandonedFormsManager {
    /**
     * Abandonment types the frontend tracker sends.
     */
    const ABANDONMENT_TYPES = ['auto_save', 'timeout', 'page_unload', 'page_hidden'];

    /**
     * Most fields kept from one progress save.
     */
    const MAX_FIELDS = 100;

    /**
     * Longest value kept for a single field, in bytes.
     */
    const MAX_VALUE_LENGTH = 10000;

    /**
     * New tracking sessions allowed per client in one window.
     */
    const NEW_SESSION_LIMIT = 300;

    /**
     * Window for NEW_SESSION_LIMIT, in seconds.
     */
    const NEW_SESSION_WINDOW = 600;

    
    /**
     * Initialize hooks and actions
     *
     * @return void
     */
    public function init() {
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_tracking_scripts']);
		// When a form is deleted, remove its abandoned form records as well
		add_action('sigmaforms_deleted', [$this, 'handle_form_deleted'], 10, 1);
    }
    
    /**
     * Register REST API routes for abandoned forms tracking
     *
     * @return void
     */
    public function register_rest_routes() {
        // Save form progress
        register_rest_route('sigmaforms/v1', '/abandoned/save', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_save_progress'],
            'permission_callback' => '__return_true',
        ]);
        
        // Mark as converted
        register_rest_route('sigmaforms/v1', '/abandoned/convert', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_mark_converted'],
            'permission_callback' => '__return_true',
        ]);
        
        // Get abandoned forms (admin only)
        register_rest_route('sigmaforms/v1', '/abandoned', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_abandoned_forms'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Get abandoned form analytics (admin only)
        register_rest_route('sigmaforms/v1', '/abandoned/analytics/(?P<form_id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_analytics'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Delete abandoned form
        register_rest_route('sigmaforms/v1', '/abandoned/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$this, 'rest_delete_abandoned'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
    }
    
    /**
     * Enqueue tracking scripts on frontend
     *
     * @return void
     */
    public function enqueue_tracking_scripts() {
        // Only enqueue if abandonment tracking is enabled
        $tracking_enabled = get_option('sf_abandonment_tracking_enabled', true);
        
        if (!$tracking_enabled) {
            return;
        }
        
        // Registered on every page but only enqueued by a form that stores
        // abandoned entries (see enqueue_tracker()), so pages without such a
        // form no longer load this script and jQuery.
        wp_register_script(
            'sf-abandonment-tracker',
            SF_PLUGIN_URL . 'assets/js/abandonment-tracker.js',
            ['jquery'],
            SF_VERSION,
            true
        );
        
        wp_localize_script('sf-abandonment-tracker', 'sfAbandonmentTracker', [
            'ajaxUrl' => rest_url('sigmaforms/v1/'),
            // Visitors get no nonce: the endpoint is public, and a stale nonce
            // from a cached page makes WordPress reject the request with 403.
            'nonce' => is_user_logged_in() ? wp_create_nonce('wp_rest') : '',
            'restNonce' => is_user_logged_in() ? wp_create_nonce('wp_rest') : '',
            'settings' => [
                'saveInterval' => get_option('sf_abandonment_save_interval', 10), // seconds
                'inactivityTimeout' => get_option('sf_abandonment_timeout', 300), // seconds (5 minutes)
                'minFieldsRequired' => get_option('sf_abandonment_min_fields', 1),
            ]
        ]);
    }
    
    /**
     * Enqueue the tracker for a form being rendered, when it stores abandoned entries.
     *
     * @param array $form_settings Settings of the form being rendered.
     * @return void
     */
    public static function enqueue_tracker($form_settings) {
        // No "is registered" check: block themes render the form before
        // wp_enqueue_scripts registers the script. A handle queued early is
        // still printed once it is registered, and never if tracking is off.
        if (!empty($form_settings['store_abandoned_forms'])) {
            wp_enqueue_script('sf-abandonment-tracker');
        }
    }

    /**
     * REST endpoint to save form progress
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_save_progress($request) {
        // Handle both JSON and form data
        $json_params = $request->get_json_params();
        if (!empty($json_params)) {
            $form_id = (int) ($json_params['form_id'] ?? 0);
            $session_id = sanitize_text_field($json_params['session_id'] ?? '');
            $field_values = $json_params['field_values'] ?? [];
            $abandonment_type = sanitize_text_field($json_params['abandonment_type'] ?? 'timeout');
        } else {
            $form_id = (int) $request->get_param('form_id');
            $session_id = sanitize_text_field($request->get_param('session_id'));
            $field_values = $request->get_param('field_values');
            $abandonment_type = sanitize_text_field($request->get_param('abandonment_type')) ?: 'timeout';
            
            // Handle JSON encoded field_values from FormData
            if (is_string($field_values)) {
                $decoded = json_decode($field_values, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $field_values = $decoded;
                }
            }
        }
        
        
        if ($form_id <= 0 || empty($session_id) || !is_array($field_values)) {
           
            return new \WP_Error('invalid_data', __('Invalid form data.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $result = $this->save_abandoned_form_progress($form_id, $session_id, $field_values, $abandonment_type);
        
        if (is_wp_error($result)) {
            
            return $result;
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => __('Progress saved.', 'sigmaforms-pro'),
            'id' => $result,
        ]);
    }
    
    /**
     * REST endpoint to mark abandoned form as converted
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_mark_converted($request) {
        $session_id = sanitize_text_field($request->get_param('session_id'));
        $form_id = (int) $request->get_param('form_id');
        
        if (empty($session_id) || $form_id <= 0) {
            return new \WP_Error('invalid_data', __('Invalid data.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $result = $this->mark_as_converted($session_id, $form_id);
        
        return rest_ensure_response([
            'success' => $result,
            'message' => $result ? __('Marked as converted.', 'sigmaforms-pro') : __('Failed to mark as converted.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * REST endpoint to get abandoned forms
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function rest_get_abandoned_forms($request) {
        $page = (int) $request->get_param('page') ?: 1;
        $per_page = (int) $request->get_param('per_page') ?: 20;
        $form_id = (int) $request->get_param('form_id') ?: 0;
        $is_converted = $request->get_param('is_converted');
        
        $filters = [];
        if ($form_id > 0) {
            $filters['form_id'] = $form_id;
        }
        if ($is_converted !== null) {
            $filters['is_converted'] = (bool) $is_converted;
        }
        
        $abandoned_forms = $this->get_abandoned_forms($page, $per_page, $filters);
        $total_count = $this->get_abandoned_forms_count($filters);
        
        return rest_ensure_response([
            'success' => true,
            'abandoned_forms' => $abandoned_forms,
            'total_count' => $total_count,
            'page' => $page,
            'per_page' => $per_page,
        ]);
    }
    
    /**
     * REST endpoint to get analytics
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function rest_get_analytics($request) {
        $form_id = (int) $request->get_param('form_id');
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $analytics = $this->get_form_analytics($form_id);
        
        return rest_ensure_response([
            'success' => true,
            'analytics' => $analytics,
        ]);
    }
    
    /**
     * REST endpoint to delete abandoned form
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_delete_abandoned($request) {
        $id = (int) $request->get_param('id');
        
        if ($id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $result = $this->delete_abandoned_form($id);
        
        return rest_ensure_response([
            'success' => $result,
            'message' => $result ? __('Deleted successfully.', 'sigmaforms-pro') : __('Failed to delete.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * Save abandoned form progress
     *
     * @param int $form_id
     * @param string $session_id
     * @param array $field_values
     * @param string $abandonment_type
     * @return int|bool|\WP_Error
     */
    public function save_abandoned_form_progress($form_id, $session_id, $field_values, $abandonment_type = 'timeout') {
        global $wpdb;
        
        // Check if license is valid - abandoned forms is a Pro feature
        if (!\SigmaForms\Plugin::is_license_valid()) {
            return new \WP_Error('license_invalid', __('Valid license required for abandoned forms tracking.', 'sigmaforms-pro'), ['status' => 403]);
        }
        
        // Check if form has abandoned forms tracking enabled
        $forms_manager = new FormsManager();
        $form = $forms_manager->get_form($form_id);
        
        if (!$form) {
            return new \WP_Error('invalid_form', __('Form not found.', 'sigmaforms-pro'), ['status' => 404]);
        }
        
        $form_settings = $form['form_settings'] ?? [];
        
        // Only save if store_abandoned_forms is enabled for this form
        if (empty($form_settings['store_abandoned_forms'])) {
            return new \WP_Error('tracking_disabled', __('Abandoned forms tracking is disabled for this form.', 'sigmaforms-pro'), ['status' => 403]);
        }

        // The tracker sends ids like "sf_1790243103108_3fj"; anything else is not ours.
        if (!is_string($session_id) || !preg_match('/^[A-Za-z0-9_-]{8,64}$/', $session_id)) {
            return new \WP_Error('invalid_session', __('Invalid session.', 'sigmaforms-pro'), ['status' => 400]);
        }

        if (!in_array($abandonment_type, self::ABANDONMENT_TYPES, true)) {
            $abandonment_type = 'timeout';
        }
        
        // Validate inputs
        if (empty($field_values) || !is_array($field_values)) {
            return new \WP_Error('invalid_field_values', __('Field values must be a non-empty array.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        // Clean field values - remove empty and whitespace-only values
        $cleaned_field_values = $this->clean_field_values($field_values);
        
        // Validate that cleaned field values contain meaningful content
        if (empty($cleaned_field_values) || !$this->has_meaningful_content($cleaned_field_values)) {
            return new \WP_Error('no_meaningful_content', __('No meaningful content to save.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        // Use cleaned values for saving
        $field_values = $cleaned_field_values;
        
        // Calculate completion percentage
        $completion_percentage = $this->calculate_completion_percentage($form_id, $field_values);
        
        // Get user info
        $user_id = get_current_user_id();
        $user_ip = $this->get_user_ip();
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        $current_time = current_time('mysql');
        
        // Check if record already exists for this session
        $sessionCheckQuery = "SELECT id FROM {$table_name} WHERE session_id = %s AND form_id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $existing = $wpdb->get_var($wpdb->prepare($sessionCheckQuery,$session_id,$form_id));
        
        if (!$existing && !$this->allow_new_session()) {
            return new \WP_Error('rate_limited', __('Too many requests. Please try again later.', 'sigmaforms-pro'), ['status' => 429]);
        }

        if ($existing) {
            // Update existing record
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $result = $wpdb->update($table_name,['field_values' => wp_json_encode($field_values),'last_activity' => $current_time,'abandonment_type' => $abandonment_type,'completion_percentage' => $completion_percentage,],['id' => $existing],['%s', '%s', '%s', '%f'],['%d']);
            
            if ($result === false) {

                return new \WP_Error('db_update_failed', __('Failed to update abandoned form progress.', 'sigmaforms-pro'));
            }
            
            return $existing;
        } else {
            // Insert new record
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $result = $wpdb->insert($table_name,['form_id' => $form_id,'session_id' => $session_id,'field_values' => wp_json_encode($field_values),'user_id' => $user_id ?: null,'user_ip' => $user_ip,'user_agent' => $user_agent,'start_time' => $current_time,'last_activity' => $current_time,'abandonment_type' => $abandonment_type,'completion_percentage' => $completion_percentage,],['%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%f']);
            
            if ($result === false) {

                return new \WP_Error('db_insert_failed', __('Failed to save abandoned form progress.', 'sigmaforms-pro'));
            }
            
            return $wpdb->insert_id;
        }
    }
    
    /**
     * Mark abandoned form as converted
     *
     * @param string $session_id
     * @param int $form_id
     * @return bool
     */
    public function mark_as_converted($session_id, $form_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update($table_name,['is_converted' => 1],['session_id' => $session_id,'form_id' => $form_id,],['%d'],['%s', '%d']);
        
        return $result !== false;
    }
    
    /**
     * Delete multiple abandoned form records
     *
     * @param array $ids Array of abandoned form IDs
     * @return int|false Number of deleted forms or false on error
     */
    public function delete_abandoned_forms($ids) {
        global $wpdb;
        
        if (empty($ids) || !is_array($ids)) {
            return 0;
        }
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        $deleted_count = 0;
        
        foreach ($ids as $id) {
            $id = intval($id);
            if ($id <= 0) {
                continue;
            }
            
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $result = $wpdb->delete(
                $table_name,
                ['id' => $id],
                ['%d']
            );
            
            if ($result !== false) {
                $deleted_count++;
            }
        }
        
        return $deleted_count;
    }
    
    /**
     * Get abandoned forms
     *
     * @param int $page
     * @param int $per_page
     * @param array $filters
     * @return array
     */
    public function get_abandoned_forms($page = 1, $per_page = 20, $filters = []) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        $forms_table = $wpdb->prefix . 'sigmaforms';
        
        $where_conditions = ['1=1'];
        $values = [];
        
        if (isset($filters['form_id']) && $filters['form_id'] > 0) {
            $where_conditions[] = 'af.form_id = %d';
            $values[] = $filters['form_id'];
        }
        
        if (isset($filters['is_converted'])) {
            $where_conditions[] = 'af.is_converted = %d';
            $values[] = $filters['is_converted'] ? 1 : 0;
        }
        
        $offset = ($page - 1) * $per_page;
        
        $query = "
            SELECT af.*, f.title as form_title
            FROM {$table_name} af
            LEFT JOIN {$forms_table} f ON af.form_id = f.id
            WHERE " . implode(' AND ', $where_conditions) . "
            ORDER BY af.last_activity DESC
            LIMIT %d OFFSET %d
        ";
        
        $values[] = $per_page;
        $values[] = $offset;
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $results = $wpdb->get_results($wpdb->prepare($query, $values), ARRAY_A);
        
        $abandoned_forms = [];
        foreach ($results as $result) {
            $abandoned_forms[] = new AbandonedForm($result);
        }
        
        return $abandoned_forms;
    }
    
    /**
     * Get a specific abandoned form by ID
     *
     * @param int $id
     * @return AbandonedForm|null
     */
    public function get_abandoned_form($id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        $forms_table = $wpdb->prefix . 'sigmaforms';
        
        $query = "
            SELECT af.*, f.title as form_title
            FROM {$table_name} af
            LEFT JOIN {$forms_table} f ON af.form_id = f.id
            WHERE af.id = %d
        ";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->get_row($wpdb->prepare($query, $id), ARRAY_A);
        
        if (!$result) {
            return null;
        }
        
        return new AbandonedForm($result);
    }
    
    /**
     * Get abandoned forms count
     *
     * @param array $filters
     * @return int
     */
    public function get_abandoned_forms_count($filters = []) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        
        $where_conditions = ['1=1'];
        $values = [];
        
        if (isset($filters['form_id']) && $filters['form_id'] > 0) {
            $where_conditions[] = 'form_id = %d';
            $values[] = $filters['form_id'];
        }
        
        if (isset($filters['is_converted'])) {
            $where_conditions[] = 'is_converted = %d';
            $values[] = $filters['is_converted'] ? 1 : 0;
        }
        
        $query = "SELECT COUNT(*) FROM {$table_name} WHERE " . implode(' AND ', $where_conditions);
        
        if (!empty($values)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            return (int) $wpdb->get_var($wpdb->prepare($query, $values));
        }

        // Without filters the query carries no placeholders, and prepare()
        // warns when it is called with nothing to prepare. The query is built
        // from $wpdb->prefix and fixed SQL only.
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        return (int) $wpdb->get_var($query);
    }
    
    /**
     * Get form analytics
     *
     * @param int $form_id
     * @return array
     */
    public function get_form_analytics($form_id) {
        global $wpdb;
        
        $abandoned_table = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        $submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Get abandonment statistics
        $abandonedGetQuery = "SELECT COUNT(*) FROM {$abandoned_table} WHERE form_id = %d AND is_converted = 0";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $abandoned_count = $wpdb->get_var($wpdb->prepare($abandonedGetQuery,$form_id));
        $convertedGetQuery = "SELECT COUNT(*) FROM {$abandoned_table} WHERE form_id = %d AND is_converted = 1";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $converted_count = $wpdb->get_var($wpdb->prepare($convertedGetQuery,$form_id ));
        $totalSubmissionsGetQuery = "SELECT COUNT(*) FROM {$submissions_table} WHERE form_id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $total_submissions = $wpdb->get_var($wpdb->prepare($totalSubmissionsGetQuery,$form_id));
        $avgCompletionGetQuery = "SELECT AVG(completion_percentage) FROM {$abandoned_table} WHERE form_id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $avg_completion = $wpdb->get_var($wpdb->prepare($avgCompletionGetQuery,$form_id));
        $avgTimeSpentGetQuery = "SELECT AVG(TIMESTAMPDIFF(SECOND, start_time, last_activity)) FROM {$abandoned_table} 
             WHERE form_id = %d AND start_time IS NOT NULL AND last_activity IS NOT NULL";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $avg_time_spent = $wpdb->get_var($wpdb->prepare($avgTimeSpentGetQuery,$form_id));
        
        // Abandonment by type
        $abandonmentTypesGetQuery =  "SELECT abandonment_type, COUNT(*) as count FROM {$abandoned_table} WHERE form_id = %d AND is_converted = 0 GROUP BY abandonment_type";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $abandonment_types = $wpdb->get_results($wpdb->prepare($abandonmentTypesGetQuery,$form_id), ARRAY_A);
        
        $total_interactions = $abandoned_count + $converted_count + $total_submissions;
        $abandonment_rate = $total_interactions > 0 ? round(($abandoned_count / $total_interactions) * 100, 2) : 0;
        $conversion_rate = $total_interactions > 0 ? round(($total_submissions / $total_interactions) * 100, 2) : 0;
        
        return [
            'form_id' => $form_id,
            'abandoned_count' => (int) $abandoned_count,
            'converted_count' => (int) $converted_count,
            'total_submissions' => (int) $total_submissions,
            'total_interactions' => $total_interactions,
            'abandonment_rate' => $abandonment_rate,
            'conversion_rate' => $conversion_rate,
            'avg_completion_percentage' => round((float) $avg_completion, 2),
            'avg_time_spent_seconds' => round((float) $avg_time_spent, 2),
            'abandonment_types' => $abandonment_types,
        ];
    }
    
    /**
     * Calculate completion percentage
     *
     * @param int $form_id
     * @param array $field_values
     * @return float
     */
    private function calculate_completion_percentage($form_id, $field_values) {
        // Get form fields
        $forms_manager = new FormsManager();
        $form = $forms_manager->get_form($form_id);
        
        if (!$form) {
            return 0;
        }
        
        $form_fields = $form['form_fields'] ?? [];
        $total_fields = count($form_fields);
        
        if ($total_fields === 0) {
            return 0;
        }
        
        $filled_fields = 0;
        foreach ($form_fields as $field) {
            $field_id = $field['id'] ?? '';
            if (!empty($field_id)) {
                $value = $field_values[$field_id] ?? '';
                if (!empty($value) && $value !== '') {
                    $filled_fields++;
                }
            }
        }
        
        return round(($filled_fields / $total_fields) * 100, 2);
    }
    
    /**
     * Clean field values by removing empty and whitespace-only values
     *
     * @param array $field_values
     * @return array
     */
    private function clean_field_values($field_values) {
        if (!is_array($field_values)) {
            return [];
        }
        
        $cleaned = [];

        foreach ($field_values as $key => $value) {
            // The endpoint is public: cap how much one request can store.
            if (count($cleaned) >= self::MAX_FIELDS) {
                break;
            }

            // Skip non-string values
            if (!is_string($value)) {
                continue;
            }

            // Cut by characters: a byte cut can split a multibyte character,
            // and the sanitizer then drops the whole value as invalid UTF-8.
            if (mb_strlen($value, 'UTF-8') > self::MAX_VALUE_LENGTH) {
                $value = mb_substr($value, 0, self::MAX_VALUE_LENGTH, 'UTF-8');
            }

            // Skip session ID fields
            if (strpos($key, 'sf-session-id-') === 0) {
                continue;
            }

            // This data arrives from a public, unauthenticated endpoint and is later rendered
            // in the admin, so sanitize both the key and the value on the way in.
            $key = substr(sanitize_text_field((string) $key), 0, 191);

            if ($key === '') {
                continue;
            }

            // Trim whitespace. sanitize_textarea_field() strips tags but keeps line breaks,
            // so multi-line partial answers survive intact.
            $trimmed = trim(sanitize_textarea_field($value));

            // Only include if there's actual content
            if (!empty($trimmed) && strlen($trimmed) > 0) {
                $cleaned[$key] = $trimmed;
            }
        }

        return $cleaned;
    }
    
    /**
     * Check if field values contain meaningful content
     *
     * @param array $field_values
     * @return bool
     */
    private function has_meaningful_content($field_values) {
        if (empty($field_values) || !is_array($field_values)) {
            return false;
        }
        
        // Check if at least one field has non-empty, non-whitespace content
        foreach ($field_values as $value) {
            // Skip if not a string or is empty
            if (!is_string($value)) {
                continue;
            }
            
            // Trim whitespace and check if there's actual content
            $trimmed = trim($value);
            if (!empty($trimmed) && strlen($trimmed) > 0) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Delete abandoned form record
     *
     * @param int $id
     * @return bool
     */
    public function delete_abandoned_form($id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->delete($table_name,['id' => $id],['%d']);
        
        return $result !== false;
    }

	/**
	 * Handle cascade delete when a form is deleted
	 *
	 * @param int $form_id
	 * @param string $original_title
	 * @return void
	 */
	public function handle_form_deleted($form_id, $original_title = '') {
		$form_id = (int) $form_id;
		if ($form_id <= 0) {
			return;
		}

		// Don't delete abandoned forms, just keep them with the original form title
		// They will show as "Deleted Form - [Original Name]" in the UI
		// No action needed here since we're preserving the data
	}

	/**
	 * Delete all abandoned form records for a given form
	 * This method is kept for backwards compatibility but not used by default
	 *
	 * @param int $form_id
	 * @return int Number of records deleted
	 */
	private function delete_abandoned_forms_by_form($form_id) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
		$deleteByFormQuery = "DELETE FROM {$table_name} WHERE form_id = %d";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$result = $wpdb->query($wpdb->prepare($deleteByFormQuery, $form_id));

		return $result !== false ? (int) $result : 0;
	}
    
    /**
     * Throttle how many new tracking sessions one client can open.
     *
     * Updates to an existing session are not counted. Uses REMOTE_ADDR, which
     * the client cannot spoof, rather than the forwarding headers. Sites where
     * every visitor shares one address (some proxies) can raise the limit, or
     * turn it off with 0, through the sigmaforms_abandoned_session_limit filter.
     *
     * @return bool True when another session may be created.
     */
    private function allow_new_session() {
        $limit = (int) apply_filters('sigmaforms_abandoned_session_limit', self::NEW_SESSION_LIMIT);
        $client = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

        if ($limit <= 0 || $client === '') {
            return true;
        }

        $key = 'sf_abandon_rl_' . md5($client);
        $window = get_transient($key);
        $now = time();

        // Fixed window: the count resets NEW_SESSION_WINDOW seconds after the
        // first session, instead of every new session extending the expiry.
        if (!is_array($window) || !isset($window['start'], $window['count']) || $now - (int) $window['start'] >= self::NEW_SESSION_WINDOW) {
            $window = ['start' => $now, 'count' => 0];
        }

        if ((int) $window['count'] >= $limit) {
            return false;
        }

        $window['count'] = (int) $window['count'] + 1;
        set_transient($key, $window, max(1, self::NEW_SESSION_WINDOW - ($now - (int) $window['start'])));

        return true;
    }

    /**
     * Get user IP address
     *
     * @return string
     */
    private function get_user_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return isset($_SERVER['HTTP_CLIENT_IP']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_CLIENT_IP'] ) ) : '';
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) : '';
        } else {
            return isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
        }
    }
    
    /**
     * Cleanup old abandoned forms
     *
     * @param int $days
     * @return int Number of deleted records
     */
    public function cleanup_old_abandoned_forms($days = 90) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        $deleteGetQuery = "DELETE FROM {$table_name} WHERE last_activity < DATE_SUB(NOW(), INTERVAL %d DAY)";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->query($wpdb->prepare($deleteGetQuery,$days));
        
        return $result ?: 0;
    }
} 