<?php
/**
 * Form class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Forms;

use SigmaForms\Utils\Helper;

class Form
{
    /**
     * Form ID
     *
     * @var int
     */
    private $id;

    /**
     * Form name
     *
     * @var string
     */
    private $title;

    /**
     * Form fields
     *
     * @var array
     */
    private $fields;

    /**
     * Form settings
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor
     *
     * @param array $form_data Form data
     */
    public function __construct($form_data = [])
    {
        $this->id = isset($form_data['id']) ? (int) $form_data['id'] : 0;
        $this->title = isset($form_data['title']) ? $form_data['title'] : '';

        // Handle fields from database or direct array
        if (isset($form_data['form_fields'])) {
            if (is_string($form_data['form_fields'])) {
                $this->fields = json_decode($form_data['form_fields'], true) ?: [];
            } else {
                $this->fields = $form_data['form_fields'];
            }
        } elseif (isset($form_data['fields'])) {
            $this->fields = $form_data['fields'];
        } else {
            $this->fields = [];
        }

        // Handle settings from database or direct array
        if (isset($form_data['form_settings'])) {
            if (is_string($form_data['form_settings'])) {
                $this->settings = json_decode($form_data['form_settings'], true) ?: [];
            } else {
                $this->settings = $form_data['form_settings'];
            }
        } elseif (isset($form_data['settings'])) {
            $this->settings = $form_data['settings'];
        } else {
            $this->settings = Helper::get_default_form_settings();
        }
    }

    /**
     * Get form data as array
     *
     * @return array Form data
     */
    public function to_array()
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'fields' => $this->fields,
            'settings' => $this->settings,
        ];
    }

    /**
     * Get form ID
     *
     * @return int Form ID
     */
    public function get_id()
    {
        return $this->id;
    }

    /**
     * Get form name
     *
     * @return string Form name
     */
    public function get_title()
    {
        return $this->title;
    }

    /**
     * Get form fields
     *
     * @return array Form fields
     */
    public function get_fields()
    {
        return $this->fields;
    }

    /**
     * Get form settings
     *
     * @return array Form settings
     */
    public function get_settings()
    {
        return $this->settings;
    }

    /**
     * Get a specific form setting
     *
     * @param string $key Setting key
     * @param mixed $default Default value if setting not found
     * @return mixed Setting value
     */
    public function get_setting($key, $default = null)
    {
        return isset($this->settings[$key]) ? $this->settings[$key] : $default;
    }

    /**
     * Render form HTML
     *
     * @param string $theme The theme to use for styling the form
     * @return string Form HTML
     */
    public function render($theme = 'minimal')
    {
        ob_start();

        // Apply filter before form render
        do_action('sigmaforms_before_render_form', $this->id, $this);

        // Check if scheduling is enabled
        if (!empty($this->settings['enable_scheduling'])) {
            // Get current time as MySQL datetime in WordPress timezone
            $current_mysql = current_time('mysql');
            
            // Convert schedule times to MySQL datetime format
            // datetime-local input: "2025-12-21T11:02" 
            $schedule_start = null;
            $schedule_end = null;
            
            if (!empty($this->settings['schedule_start'])) {
                // Convert "2025-12-21T11:02" to "2025-12-21 11:02:00"
                $schedule_start = str_replace('T', ' ', $this->settings['schedule_start']) . ':00';
            }
            
            if (!empty($this->settings['schedule_end'])) {
                // Convert "2025-12-21T11:05" to "2025-12-21 11:05:00"
                $schedule_end = str_replace('T', ' ', $this->settings['schedule_end']) . ':00';
            }

            // Check if form is not yet available (before start time)
            if ($schedule_start && $current_mysql < $schedule_start) {
                // Convert to timestamp for countdown timer (JavaScript needs timestamp)
                $schedule_start_timestamp = strtotime($schedule_start) - (get_option('gmt_offset') * HOUR_IN_SECONDS);
                $message = !empty($this->settings['schedule_message_before']) 
                    ? $this->settings['schedule_message_before'] 
                    : __('This form will be available soon. Please check back later.', 'sigmaforms-pro');
                
                echo '<div class="sf-scheduled-form sf-scheduled-before" data-form-id="' . esc_attr($this->id) . '" data-start-time="' . esc_attr($schedule_start_timestamp) . '">';
                echo '<div class="sf-schedule-message">' . wp_kses_post($message) . '</div>';
                echo '<div class="sf-countdown-timer" data-target="' . esc_attr($schedule_start_timestamp) . '"></div>';
                echo '</div>';
                return ob_get_clean();
            }

            // Check if form is no longer available (after end time)
            if ($schedule_end && $current_mysql > $schedule_end) {
                $message = !empty($this->settings['schedule_message_after']) 
                    ? $this->settings['schedule_message_after'] 
                    : __('This form is no longer accepting submissions.', 'sigmaforms-pro');
                
                echo '<div class="sf-scheduled-form sf-scheduled-after">';
                echo '<div class="sf-schedule-message">' . wp_kses_post($message) . '</div>';
                echo '</div>';
                return ob_get_clean();
            }
        }

        // Unique form identifier
        $form_id = 'sf-form-' . $this->id;
        $nonce = wp_create_nonce('sf_submit_form_' . $this->id);

        $has_file_field = false;
        foreach ($this->fields as $field) {
            if (isset($field['type']) && $field['type'] === 'file') {
                $has_file_field = true;
                break;
            }
        }

        // Inject custom theme styles if custom theme is selected
        if ($theme === 'custom') {
            // Get global styling as defaults
            $global_styling = get_option('sf_form_styling', []);

            // A form's own colours apply only when the form itself picked Custom.
            // Forms that follow the global theme use the global colours; the
            // editor keeps a copy in every form, which used to override them.
            $form_styling = (($this->settings['form_theme'] ?? '') === 'custom' && isset($this->settings['form_styling']))
                ? (array) $this->settings['form_styling']
                : [];
            $styling = array_merge($global_styling, $form_styling);

            // Extract styling values with fallbacks
            $button_color = $styling['button_color'] ?? '#2271b1';
            $button_text_color = $styling['button_text_color'] ?? '#ffffff';
            $field_border = $styling['field_border'] ?? '#dcdcde';
            $field_background = $styling['field_background'] ?? '#ffffff';
            $label_color = $styling['label_color'] ?? '#333333';
            $font_family = $styling['font_family'] ?? 'inherit';
            $font_size = isset($styling['font_size']) ? intval($styling['font_size']) : 16;
            $form_padding = isset($styling['form_padding']) ? intval($styling['form_padding']) : 20;
            $field_spacing = isset($styling['field_spacing']) ? intval($styling['field_spacing']) : 15;
            $input_border_radius = isset($styling['input_border_radius']) ? intval($styling['input_border_radius']) : 4;
            $placeholder_color = $styling['placeholder_color'] ?? '#888888';
            $input_text_color = $styling['input_text_color'] ?? '#333333';
            $button_hover_bg_color = $styling['button_hover_bg_color'] ?? '#1a5a96';
            $button_border_radius = isset($styling['button_border_radius']) ? intval($styling['button_border_radius']) : 4;
            $button_hover_text_color = $styling['button_hover_text_color'] ?? '#ffffff';
            echo '<style type="text/css">';
            echo '.sf-theme-custom .sf-form-container {';
            echo '  font-family: ' . esc_attr($font_family) . ';';
            echo '  font-size: ' . intval($font_size) . 'px;';
            echo '  border-radius: ' . intval($input_border_radius) . 'px;';
            echo '  background: #fff;';
            echo '}';
            echo '.sf-theme-custom .sf-field-container label {';
            echo '  color: ' . esc_attr($label_color) . ';';
            echo '  font-family: ' . esc_attr($font_family) . ';';
            echo '  font-size: ' . intval($font_size) . 'px;';
            echo '}';
            echo '.sf-theme-custom .sf-field-container {';
            echo '  margin-bottom: ' . intval($field_spacing) . 'px !important;';
            echo '}';
            echo '.sf-theme-custom .sf-field-container input[type="text"],
                  .sf-theme-custom .sf-field-container input[type="email"],
                  .sf-theme-custom .sf-field-container input[type="number"],
                  .sf-theme-custom .sf-field-container input[type="tel"],
                  .sf-theme-custom .sf-field-container input[type="date"],
                  .sf-theme-custom .sf-field-container input[type="url"],
                  .sf-theme-custom .sf-field-container select,
                  .sf-theme-custom .sf-field-container textarea {
                border: 1px solid ' . esc_attr($field_border) . ';
                background: ' . esc_attr($field_background) . ';
                color: ' . esc_attr($input_text_color) . '; /* Input value text color */
                border-radius: ' . intval($input_border_radius) . 'px;
                font-family: ' . esc_attr($font_family) . ';
                font-size: ' . intval($font_size) . 'px;
                padding: ' . intval($form_padding) . 'px !important;
                appearance: auto !important;
                height: auto !important;
            }';
            // Placeholder color for all browsers
            echo '.sf-theme-custom .sf-field-container input::placeholder,
                  .sf-theme-custom .sf-field-container textarea::placeholder {
                color: ' . esc_attr($placeholder_color) . ';
                opacity: 1;
            }
';
            echo '.sf-theme-custom .sf-submit-button {
                background: ' . esc_attr($button_color) . ';
                color: ' . esc_attr($button_text_color) . ';
                border-radius: ' . intval($button_border_radius) . 'px;
                font-family: ' . esc_attr($font_family) . ';
                font-size: ' . intval($font_size) . 'px;
            }
';
            echo '.sf-theme-custom .sf-submit-button:hover {
                background: ' . esc_attr($button_hover_bg_color) . '!important; /* Button hover background color */
                color: ' . esc_attr($button_hover_text_color) . '; /* Button hover text color */
            }
';
            echo '</style>';
        }

        ?>
        <div class="sf-form-container sf-theme-<?php echo esc_attr($theme); ?>"
            id="<?php echo esc_attr($form_id); ?>-container">
            
            <?php 
            // Display countdown timer if end time is set
            if (!empty($this->settings['enable_scheduling']) && !empty($this->settings['schedule_end'])) {
                // Convert to timestamp for JavaScript countdown
                $schedule_end_str = str_replace('T', ' ', $this->settings['schedule_end']) . ':00';
                $schedule_end_timestamp = strtotime($schedule_end_str) - (get_option('gmt_offset') * HOUR_IN_SECONDS);
                ?>
                <div class="sf-form-countdown-header" data-target="<?php echo esc_attr($schedule_end_timestamp); ?>">
                    <div class="sf-countdown-label"><?php esc_html_e('Time Remaining:', 'sigmaforms-pro'); ?></div>
                    <div class="sf-countdown-timer-live"></div>
                </div>
                <?php
            }
            ?>
            
            <form id="<?php echo esc_attr($form_id); ?>" class="sf-form" method="post" data-form-id="<?php echo esc_attr($this->id); ?>" data-store-abandoned="<?php echo esc_attr($this->settings['store_abandoned_forms'] ?? false ? '1' : '0'); ?>" <?php echo $has_file_field ? ' enctype="multipart/form-data"' : ''; ?>>
                <div class="sf-form-fields">
                    <div class="sf-form-fields-wrapper">
                        <?php
                        if (!empty($this->fields)) {
                            // If license is invalid, skip rendering Pro fields
                            $license_valid = \SigmaForms\Plugin::is_license_valid();
                            $pro_types = ['file', 'phone_international', 'signature', 'rating', 'section_heading', 'select', 'radio', 'checkbox', 'date', 'country', 'rich_text', 'range', 'page_break'];
                            foreach ($this->fields as $field) {
                                if (!$license_valid && isset($field['type']) && in_array($field['type'], $pro_types, true)) {
                                    continue;
                                }
                                $this->render_field($field);
                            }
                        } else {
                            echo '<p>' . esc_html__('No fields found for this form.', 'sigmaforms-pro') . '</p>';
                        }
                        ?>
                    </div>
                </div>

                <?php
                // Render CAPTCHA if enabled and license is valid
                if (\SigmaForms\Plugin::is_license_valid()) {
                    $captcha_html = \SigmaForms\Utils\CaptchaHandler::render_captcha($this->settings);
                    if (!empty($captcha_html)): ?>
                        <div class="sf-captcha-container">
                            <?php 
                            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Captcha HTML is already escaped in CaptchaHandler
                            echo $captcha_html; 
                            ?>
                        </div>
                        <?php
                    endif;
                }
                ?>

                <?php
                $button_align = $this->get_setting('submit_button_align', 'left');
                $button_align_class = 'sf-button-align-' . esc_attr($button_align);
                ?>

                <div class="sf-form-actions <?php echo esc_attr($button_align_class); ?>"
                    data-width="<?php echo esc_attr($this->get_setting('submit_button_width', 'auto')); ?>"
                    style="<?php echo $this->get_setting('submit_button_width', 'auto') !== 'auto' && $this->get_setting('submit_button_width', 'auto') !== '100' ? '--sf-button-width: ' . esc_attr($this->get_setting('submit_button_width', 'auto')) . '%;' : ''; ?>">
                    <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>">
                    <input type="hidden" name="form_id" value="<?php echo esc_attr($this->id); ?>">
                    <input type="hidden" name="session_id" value="" id="sigmaform-session-id-<?php echo esc_attr($this->id); ?>">
                    <button type="submit" class="sf-submit-button">
                        <?php echo esc_html($this->get_setting('submit_button_text', __('Submit', 'sigmaforms-pro'))); ?>
                    </button>
                </div>

                <div class="sf-form-messages" style="display: none;">
                    <div class="sf-message sf-error-message sf-error-list" style="display: none;"></div>
                    <div class="sf-message sf-success-message" style="display: none;"></div>
                </div>
            </form>
        </div>
        <?php

        // Apply filter after form render
        do_action('sigmaforms_after_render_form', $this->id, $this);

        // Load required assets
        wp_enqueue_style('sf-frontend-styles');
        wp_enqueue_script('sf-frontend-script');
        wp_enqueue_script('sf-auto-save');

        // Abandonment tracking only runs for forms that store abandoned entries,
        // and saving them requires a valid license.
        if (\SigmaForms\Plugin::is_license_valid()) {
            AbandonedFormsManager::enqueue_tracker($this->settings);
        }

        // Load CAPTCHA scripts if enabled and license is valid
        if (\SigmaForms\Plugin::is_license_valid()) {
            $captcha_type = $this->settings['captcha_type'] ?? '';
            if (!empty($captcha_type)) {
                // Check if captcha is properly configured before loading scripts
                $config_check = \SigmaForms\Utils\CaptchaHandler::check_captcha_configuration($captcha_type);
                if ($config_check['valid']) {
                    switch ($captcha_type) {
                        case 'recaptcha':
                            // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Google reCAPTCHA is a legitimate third-party CAPTCHA service
                            wp_enqueue_script('sf-recaptcha', 'https://www.google.com/recaptcha/api.js', [], SF_VERSION, true);
                            break;
                        case 'hcaptcha':
                            // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- hCaptcha is a legitimate third-party CAPTCHA service
                            wp_enqueue_script('sf-hcaptcha', 'https://js.hcaptcha.com/1/api.js', [], SF_VERSION, true);
                            break;
                        case 'turnstile':
                            // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Cloudflare Turnstile is a legitimate third-party CAPTCHA service
                            wp_enqueue_script('sf-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', [], SF_VERSION, true);
                            break;
                        case 'mtcaptcha':
                            // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- mTCaptcha is a legitimate third-party CAPTCHA service
                            wp_enqueue_script('sf-mtcaptcha', 'https://service.mtcaptcha.com/mtcv1/client/mtcaptcha.min.js', [], SF_VERSION, true);
                            break;
                    }
                }
            }
        }

        return ob_get_clean();
    }

    /**
     * Render a single field
     *
     * @param array $field Field data
     * @return void
     */
    private function render_field($field)
    {
        if (!isset($field['id']) || !isset($field['type'])) {
            return;
        }

        $field_id = esc_attr($field['id']);
        $field_name = isset($field['name']) ? esc_attr($field['name']) : esc_attr($field['id']);
        $field_type = esc_attr($field['type']);
        $field_label = isset($field['label']) ? esc_html($field['label']) : '';
        $field_placeholder = isset($field['placeholder']) ? esc_attr($field['placeholder']) : '';
        $field_default_value = isset($field['default_value']) ? esc_attr($field['default_value']) : '';
        $required = isset($field['required']) && $field['required'] ? 'required' : '';
        $required_mark = isset($field['required']) && $field['required'] ? '<span class="sf-required">*</span>' : '';

        // Get column width class
        $column_width = isset($field['column_width']) ? $field['column_width'] : '100';
        $label_position = isset($field['label_position']) ? $field['label_position'] : 'left';
        $field_position = isset($field['field_position']) ? $field['field_position'] : 'left';

        $container_class = 'sf-field-container sf-column-' . esc_attr($column_width) . ' sf-label-' . esc_attr($label_position) . ' sf-field-position-' . esc_attr($field_position);

        // Label visibility - text and image toggle independently
        $show_label_text = !isset($field['show_label']) || $field['show_label'] !== false;
        $show_label_image = !isset($field['show_label_image']) || $field['show_label_image'] !== false;

        // Label image settings
        $label_image = ($show_label_image && isset($field['label_image'])) ? $field['label_image'] : '';
        $label_image_position = isset($field['label_image_position']) ? $field['label_image_position'] : 'left';
        $label_image_width = isset($field['label_image_width']) ? absint($field['label_image_width']) : 0;
        $label_image_height = isset($field['label_image_height']) ? absint($field['label_image_height']) : 0;
        $label_image_full_width = !empty($field['label_image_full_width']);
        $label_image_width_unit = (isset($field['label_image_width_unit']) && $field['label_image_width_unit'] === '%') ? '%' : 'px';

        if (!empty($label_image)) {
            $container_class .= ' sf-has-label-image sf-label-img-' . esc_attr($label_image_position);
        }

        // Option image settings (radio, checkbox, select, country)
        $option_image_position = isset($field['option_image_position']) ? $field['option_image_position'] : 'top';
        $option_image_size = isset($field['option_image_size']) ? absint($field['option_image_size']) : 0;

        // Add custom CSS classes if provided
        if (!empty($field['css_class'])) {
            $container_class .= ' ' . esc_attr($field['css_class']);
        }

        // Add error class if field has errorgic with data attributes
        $conditional_attrs = '';
        $conditional_class = '';

        if (isset($field['conditional']) && !empty($field['conditional'])) {
            $conditional = $field['conditional'];

            // Check if we have the new advanced conditional logic structure
            if (isset($conditional['action']) && isset($conditional['groups']) && is_array($conditional['groups'])) {
                // Advanced conditional logic
                $conditional_attrs = ' data-conditional="1"';
                $conditional_attrs .= ' data-conditional-advanced="1"';

                // Encode the conditional data as JSON for the frontend
                $conditional_json = wp_json_encode($conditional);
                $conditional_attrs .= ' data-conditional-data=\'' . esc_attr($conditional_json) . '\'';
                $conditional_class = ' sf-conditional-field sf-advanced-conditional';

            }
        }

        // Handle math function data attributes
        $math_attrs = '';
        $math_disabled = '';
        if (isset($field['math']) && !empty($field['math']) && isset($field['math']['enabled']) && $field['math']['enabled']) {
            $math_data = $field['math'];
            $math_json = wp_json_encode($math_data);
            $math_attrs = ' data-math-function=\'' . esc_attr($math_json) . '\'';
            $math_disabled = ' readonly';
        }

        // Field wrapper
        echo '<div class="' . esc_attr($container_class) . ' sf-field-' . esc_attr($field_type) . esc_attr($conditional_class) . '"' . $conditional_attrs . $math_attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $conditional_attrs and $math_attrs contain pre-escaped data attributes

        // Field label - text and image are independently toggleable, and neither
        // applies to the structural field types.
        $is_structural_field = ($field_type === 'section_heading' || $field_type === 'page_break');
        $render_label_text = $show_label_text && !empty($field_label);
        $render_label_image = !empty($label_image);

        if (!$is_structural_field && ($render_label_text || $render_label_image)) {
            echo '<label for="' . esc_attr($field_id) . '">';

            if ($render_label_image) {
                echo '<span class="sf-label-inner">';
                echo $this->get_image_markup($label_image, $label_image_width, 'sf-label-image', $label_image_height, $label_image_full_width, $label_image_width_unit); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper

                // The required marker belongs to the label text, so it hides with it
                if ($render_label_text) {
                    echo '<span class="sf-label-text">' . esc_html($field_label) . wp_kses_post($required_mark) . '</span>';
                }

                echo '</span>';
            } else {
                echo esc_html($field_label) . wp_kses_post($required_mark);
            }

            echo '</label>';
        }

        // Render field based on type
        switch ($field_type) {
            case 'text':
            case 'email':
            case 'url':
            case 'number':
            case 'date':
                echo '<input type="' . esc_attr($field_type) . '" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" placeholder="' . esc_attr($field_placeholder) . '"';
                if (!empty($field_default_value)) {
                    echo ' value="' . esc_attr($field_default_value) . '"';
                }
                echo ' ' . esc_attr($required) . esc_attr($math_attrs) . esc_attr($math_disabled) . '>';
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'phone':
                // Use tel type for phone fields for proper HTML5 validation and mobile keyboards
                echo '<input type="tel" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" placeholder="' . esc_attr($field_placeholder) . '"';
                if (!empty($field_default_value)) {
                    echo ' value="' . esc_attr($field_default_value) . '"';
                }
                echo ' ' . esc_attr($required) . esc_attr($math_attrs) . esc_attr($math_disabled) . '>';
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'textarea':
                $textarea_min_height = (!empty($field['textarea_height']) && is_numeric($field['textarea_height']))
                    ? absint($field['textarea_height'])
                    : 0;
                echo '<textarea id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" placeholder="' . esc_attr($field_placeholder) . '"';
                if ($textarea_min_height > 0) {
                    echo ' style="min-height:' . esc_attr($textarea_min_height) . 'px"';
                }
                echo ' ' . esc_attr($required) . esc_attr($math_attrs) . esc_attr($math_disabled) . '>';
                if (!empty($field_default_value)) {
                    echo esc_html($field_default_value);
                }
                echo '</textarea>';
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'rich_text':
                $editor_settings = array(
                    'media_buttons' => false,
                    'textarea_name' => esc_attr($field_name),
                    'textarea_rows' => 10,
                    'teeny'         => true,
                    'quicktags'     => false,
                );
                // Ensure ID is valid for wp_editor (no hyphens)
                $editor_id = str_replace('-', '_', $field_id);
                wp_editor($field_default_value, $editor_id, $editor_settings);
                
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'range':
                echo '<div class="sf-range-wrapper" style="display: flex; align-items: center; gap: 10px;">';
                echo '<input type="range" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '"';
                
                if (isset($field['range_min'])) {
                    echo ' min="' . esc_attr($field['range_min']) . '"';
                }
                if (isset($field['range_max'])) {
                    echo ' max="' . esc_attr($field['range_max']) . '"';
                }
                if (isset($field['range_step'])) {
                    echo ' step="' . esc_attr($field['range_step']) . '"';
                }
                
                $range_default = isset($field['range_default']) && $field['range_default'] !== '' ? $field['range_default'] : (isset($field['range_min']) ? $field['range_min'] : 0);
                
                echo ' value="' . esc_attr($range_default) . '"';
                
                echo ' ' . esc_attr($required) . esc_attr($math_attrs) . esc_attr($math_disabled) . ' class="sf-range-input" style="flex: 1;" oninput="this.nextElementSibling.textContent = this.value">';
                
                echo '<span class="sf-range-value">' . esc_html($range_default) . '</span>';
                
                echo '</div>';
                
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'phone_international':
                echo '<div class="sf-phone-international-wrapper">';

                // Country code dropdown
                $default_country = isset($field['default_country']) ? $field['default_country'] : 'BD';
                echo '<select class="sf-country-code-select" name="' . esc_attr($field_name . '_country') . '" data-field-id="' . esc_attr($field_id) . '">';

                // Get countries list from a helper method or define it here
                $countries = $this->get_countries_list();

                // Filter countries based on selected_phone_countries or available_countries
                $selected_phone_countries = [];
                if (isset($field['selected_phone_countries']) && is_array($field['selected_phone_countries']) && count($field['selected_phone_countries']) > 0) {
                    $selected_phone_countries = $field['selected_phone_countries'];
                } elseif (isset($field['available_countries']) && is_array($field['available_countries']) && count($field['available_countries']) > 0) {
                    $selected_phone_countries = $field['available_countries'];
                }

                // If specific countries are selected, filter the countries list
                if (count($selected_phone_countries) > 0) {
                    $countries = array_filter($countries, function ($country) use ($selected_phone_countries) {
                        return in_array($country['code'], $selected_phone_countries);
                    });
                }

                // Country flag icons are opt-out per field (default: shown)
                $show_country_flags = !isset($field['show_country_flags']) || $field['show_country_flags'] !== false;

                foreach ($countries as $country) {
                    $selected = ($country['code'] === $default_country) ? ' selected' : '';
                    $option_text = $show_country_flags
                        ? $country['flag'] . ' ' . $country['phoneCode']
                        : $country['phoneCode'];
                    echo '<option value="' . esc_attr($country['code']) . '"' . $selected . '>' . esc_html($option_text) . '</option>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $selected is a safe boolean attribute
                }

                echo '</select>';

                // Phone number input
                echo '<input type="tel" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '"';
                if (!empty($field_placeholder)) {
                    echo ' placeholder="' . esc_attr($field_placeholder) . '"';
                }
                if (!empty($field_default_value)) {
                    echo ' value="' . esc_attr($field_default_value) . '"';
                }
                echo ' ' . esc_attr($required) . ' class="sf-phone-number">';

                echo '</div>';
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'select':
            case 'country':
                $is_country_field = ($field_type === 'country');
                // Country flag icons are opt-out per field (default: shown)
                $show_country_flags = !isset($field['show_country_flags']) || $field['show_country_flags'] !== false;

                $select_options = (isset($field['options']) && is_array($field['options'])) ? $field['options'] : [];

                // Normalise every option into value / text / flag / image up front so the
                // native <select> and the visual dropdown stay in sync.
                $prepared_options = [];
                $has_option_images = false;

                foreach ($select_options as $option) {
                    if (!isset($option['value']) || !isset($option['label'])) {
                        continue;
                    }

                    $option_text = $option['label'];
                    $option_flag = '';

                    if ($is_country_field) {
                        // Older saved forms bake the flag emoji into the label; split it
                        // back out so the flag can be toggled at render time.
                        $split = $this->split_country_flag($option_text);
                        $option_flag = $split['flag'];
                        $option_text = $split['label'];

                        if (empty($option_flag)) {
                            $flag_source = !empty($option['country_code']) ? $option['country_code'] : $option['value'];
                            $option_flag = $this->country_code_to_flag($flag_source);
                        }
                    }

                    $option_image = !empty($option['image']) ? $option['image'] : '';
                    if (!empty($option_image)) {
                        $has_option_images = true;
                    }

                    $prepared_options[] = [
                        'value' => $option['value'],
                        'text'  => $option_text,
                        'flag'  => ($is_country_field && $show_country_flags) ? $option_flag : '',
                        'image' => $option_image,
                    ];
                }

                // Only swap in the JS-driven dropdown when there is artwork to show.
                $use_visual_select = $has_option_images;

                if ($use_visual_select) {
                    echo '<div class="sf-select-wrapper sf-options-img-' . esc_attr($option_image_position) . '" data-field-id="' . esc_attr($field_id) . '">';
                }

                echo '<select id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '"' . ($use_visual_select ? ' class="sf-visual-select-native"' : '') . ' ' . esc_attr($required) . esc_attr($math_attrs) . esc_attr($math_disabled) . '>';

                if (!empty($field_placeholder)) {
                    echo '<option value="">' . esc_html($field_placeholder) . '</option>';
                }

                foreach ($prepared_options as $option) {
                    $native_label = !empty($option['flag']) ? $option['flag'] . ' ' . $option['text'] : $option['text'];
                    echo '<option value="' . esc_attr($option['value']) . '" ' . selected(!empty($field_default_value) && $option['value'] === $field_default_value, true, false) . '>' . esc_html($native_label) . '</option>';
                }

                echo '</select>';

                if ($use_visual_select) {
                    $listbox_id = $field_id . '-sf-listbox';
                    $selected_option = null;

                    foreach ($prepared_options as $option) {
                        if (!empty($field_default_value) && $option['value'] === $field_default_value) {
                            $selected_option = $option;
                            break;
                        }
                    }

                    echo '<div class="sf-select-display" tabindex="0" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="' . esc_attr($listbox_id) . '">';
                    if ($selected_option) {
                        echo $this->get_option_visual_markup($selected_option, $option_image_size); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper
                        echo '<span class="sf-select-current">' . esc_html($selected_option['text']) . '</span>';
                    } else {
                        $placeholder_text = !empty($field_placeholder) ? $field_placeholder : __('Select an option', 'sigmaforms-pro');
                        echo '<span class="sf-select-current sf-select-placeholder">' . esc_html($placeholder_text) . '</span>';
                    }
                    echo '</div>';

                    echo '<ul class="sf-select-dropdown" id="' . esc_attr($listbox_id) . '" role="listbox">';
                    foreach ($prepared_options as $option) {
                        $is_selected = ($selected_option && $option['value'] === $selected_option['value']);
                        echo '<li class="sf-select-item' . ($is_selected ? ' sf-selected' : '') . '" role="option" aria-selected="' . ($is_selected ? 'true' : 'false') . '" data-value="' . esc_attr($option['value']) . '">';
                        echo $this->get_option_visual_markup($option, $option_image_size); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper
                        echo '<span class="sf-select-item-text">' . esc_html($option['text']) . '</span>';
                        echo '</li>';
                    }
                    echo '</ul>';

                    echo '</div>';
                }

                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'radio':
                if (isset($field['options']) && is_array($field['options'])) {
                    $columns = isset($field['options_columns']) ? intval($field['options_columns']) : 1;
                    echo '<div class="sf-radio-options sf-columns-' . intval($columns) . ' sf-options-img-' . esc_attr($option_image_position) . '">';

                    foreach ($field['options'] as $option) {
                        if (isset($option['value']) && isset($option['label'])) {
                            $option_id = $field_id . '-' . sanitize_title($option['value']);
                            $option_image = !empty($option['image']) ? $option['image'] : '';

                            echo '<div class="sf-radio-option' . (!empty($option_image) ? ' sf-has-option-image' : '') . '">';
                            echo '<input type="radio" id="' . esc_attr($option_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" value="' . esc_attr($option['value']) . '" ' . checked(!empty($field_default_value) && $option['value'] === $field_default_value, true, false) . ' ' . esc_attr($required) . '>';
                            echo '<label for="' . esc_attr($option_id) . '">';
                            echo $this->get_image_markup($option_image, $option_image_size, 'sf-option-image'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper
                            echo '<span class="sf-option-text">' . wp_kses_post($option['label']) . '</span>';
                            echo '</label>';
                            echo '</div>';
                        }
                    }

                    echo '</div>';
                }
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'checkbox':
                if (isset($field['options']) && is_array($field['options'])) {
                    $columns = isset($field['options_columns']) ? intval($field['options_columns']) : 1;
                    echo '<div class="sf-checkbox-options sf-columns-' . intval($columns) . ' sf-options-img-' . esc_attr($option_image_position) . '">';

                    // Add hidden input to indicate if this checkbox group is required
                    if (!empty($field['required']) && $field['required']) {
                        echo '<input type="hidden" name="' . esc_attr($field_name . '_required') . '" value="1" class="sf-field-required">';
                    }

                    foreach ($field['options'] as $option) {
                        if (isset($option['value']) && isset($option['label'])) {
                            $option_id = $field_id . '-' . sanitize_title($option['value']);
                            $option_image = !empty($option['image']) ? $option['image'] : '';

                            echo '<div class="sf-checkbox-option' . (!empty($option_image) ? ' sf-has-option-image' : '') . '">';
                            echo '<input type="checkbox" id="' . esc_attr($option_id) . '" name="' . esc_attr($field_name) . '[]" data-field-id="' . esc_attr($field_id) . '" value="' . esc_attr($option['value']) . '" ' . checked(!empty($field_default_value) && is_array($field_default_value) && in_array($option['value'], $field_default_value), true, false) . '>';
                            echo '<label for="' . esc_attr($option_id) . '">';
                            echo $this->get_image_markup($option_image, $option_image_size, 'sf-option-image'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper
                            echo '<span class="sf-option-text">' . wp_kses_post($option['label']) . '</span>';
                            echo '</label>';
                            echo '</div>';
                        }
                    }

                    echo '</div>';
                } else {
                    echo '<div class="sf-checkbox-single">';
                    echo '<input type="checkbox" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" value="1" ' . checked(!empty($field_default_value) && ($field_default_value === '1' || $field_default_value === true), true, false) . ' ' . esc_attr($required) . '>';
                    echo '<label for="' . esc_attr($field_id) . '">' . esc_attr($field_label) . '</label>';
                    echo '</div>';
                }
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'file':
                // Build accept attribute from allowed file types and custom extensions
                $accept_attr = '';
                $accept_types = [];
                
                // Add allowed file types
                if (isset($field['allowed_file_types']) && is_array($field['allowed_file_types']) && !empty($field['allowed_file_types'])) {
                    $accept_types = array_merge($accept_types, $field['allowed_file_types']);
                }
                
                // Add custom file extensions
                if (isset($field['custom_file_extensions']) && !empty($field['custom_file_extensions'])) {
                    $custom_exts = array_map('trim', explode(',', $field['custom_file_extensions']));
                    $accept_types = array_merge($accept_types, $custom_exts);
                }
                
                // Generate accept attribute
                if (!empty($accept_types)) {
                    $accept_attr = ' accept="' . esc_attr(implode(',', $accept_types)) . '"';
                }
                
                // Check if multiple files are allowed
                $multiple_attr = '';
                $name_attr = $field_name;
                $max_files_attr = '';
                if (isset($field['allow_multiple']) && $field['allow_multiple']) {
                    $multiple_attr = ' multiple';
                    $name_attr = $field_name . '[]'; // Add array notation for multiple files
                    if (!empty($field['max_files'])) {
                        $max_files_attr = ' data-max-files="' . absint($field['max_files']) . '"';
                    }
                }
                
                echo '<div class="sf-file-upload">';
                echo '<div class="sf-file-upload-icon">';
                echo '<span class="dashicons dashicons-upload"></span>';
                
                // Use custom button text if set, otherwise use default based on multiple files setting
                if (isset($field['upload_button_text']) && !empty($field['upload_button_text'])) {
                    $upload_text = $field['upload_button_text'];
                } else {
                    $upload_text = isset($field['allow_multiple']) && $field['allow_multiple'] ? __('Choose files', 'sigmaforms-pro') : __('Choose a file', 'sigmaforms-pro');
                }
                
                echo '<span class="sf-file-upload-text">' . esc_html($upload_text) . '</span>';
                echo '</div>';
                // The same extension list the server checks, so a wrong type is
                // reported when the file is picked instead of after submitting.
                $allowed_ext_attr = ' data-allowed-ext="' . esc_attr(implode(',', \SigmaForms\Utils\Helper::get_allowed_extensions_from_field($field))) . '"';
                if (!empty($field['file_type_error_message'])) {
                    $allowed_ext_attr .= ' data-type-error="' . esc_attr($field['file_type_error_message']) . '"';
                }
                echo '<input type="file" id="' . esc_attr($field_id) . '" name="' . esc_attr($name_attr) . '" data-field-id="' . esc_attr($field_id) . '"' . $accept_attr . $allowed_ext_attr . $multiple_attr . $max_files_attr . ' ' . esc_attr($required) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $accept_attr, $multiple_attr and $max_files_attr are properly escaped above
                echo '</div>';
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'signature':
                // Check if mobile/QR signature is enabled (default: true)
                $enable_qr = isset($field['enable_qr_signature']) ? $field['enable_qr_signature'] : true;
                $qr_attr = $enable_qr ? ' data-qr-enabled="true"' : '';

                echo '<div class="sf-signature-wrapper"' . $qr_attr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $qr_attr is a safe boolean data attribute
                echo '<canvas class="sf-signature-pad" id="' . esc_attr($field_id) . '_canvas" width="500" height="200"></canvas>';
                echo '<input type="hidden" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" class="sf-signature-data" ' . esc_attr($required) . '>';
                echo '<div class="sf-signature-actions">';
                echo '<button type="button" class="sf-btn sf-btn-sm sf-clear-signature" data-canvas-id="' . esc_attr($field_id) . '_canvas">' . esc_html__('Clear', 'sigmaforms-pro') . '</button>';

                // Add QR code button if enabled
                if ($enable_qr) {
                    echo '<button type="button" class="sf-btn sf-btn-sm sf-btn-primary sf-show-qr-btn">';
                    echo '<span class="dashicons dashicons-smartphone"></span> ';
                    echo esc_html__('Sign on Phone', 'sigmaforms-pro');
                    echo '</button>';
                }

                echo '</div>';

                // QR Code container (hidden by default)
                if ($enable_qr) {
                    echo '<div class="sf-qr-container" style="display: none;">';
                    echo '<div class="sf-qr-header">';
                    echo '<h4>' . esc_html__('Scan to Sign on Mobile', 'sigmaforms-pro') . '</h4>';
                    echo '<button type="button" class="sf-qr-close sf-hide-qr-btn">&times;</button>';
                    echo '</div>';
                    echo '<div class="sf-qr-code"></div>';
                    echo '<p class="sf-qr-status">' . esc_html__('Generating QR code...', 'sigmaforms-pro') . '</p>';
                    echo '<p class="sf-qr-instruction">' . esc_html__('Scan this code with your phone camera to sign using your finger.', 'sigmaforms-pro') . '</p>';
                    echo '</div>';
                }

                echo '</div>';
                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'rating':
                // Rating field with 5 gold stars
                $max_rating = 5;
                $current_rating = isset($field_default_value) && is_numeric($field_default_value) ? intval($field_default_value) : 0;

                echo '<div class="sf-rating-wrapper">';
                echo '<div class="sf-rating-stars" data-rating="' . esc_attr($current_rating) . '">';

                for ($i = 1; $i <= $max_rating; $i++) {
                    $filled_class = $i <= $current_rating ? ' sf-star-filled' : '';
                    echo '<span class="sf-rating-star' . esc_attr($filled_class) . '" data-value="' . esc_attr($i) . '">★</span>';
                }

                echo '</div>';
                echo '<input type="hidden" id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" data-field-id="' . esc_attr($field_id) . '" value="' . esc_attr($current_rating > 0 ? $current_rating : '') . '" class="sf-field sf-rating-value" ' . esc_attr($required) . '>';
                echo '</div>';

                if (isset($field['help_text']) && !empty($field['help_text'])) {
                    echo '<div class="sf-field-help-text">' . esc_html($field['help_text']) . '</div>';
                }
                break;

            case 'section_heading':
                // Section heading is just a visual divider/heading, no input
                $show_underline = isset($field['show_underline']) ? $field['show_underline'] : true;
                $underline_color = isset($field['underline_color']) ? $field['underline_color'] : '#3b82f6';
                $underline_thickness = isset($field['underline_thickness']) ? $field['underline_thickness'] : '3';
                $underline_style = isset($field['underline_style']) ? $field['underline_style'] : 'solid';
                
                $heading_style = '';
                if ($show_underline) {
                    $heading_style = sprintf(
                        'style="border-bottom: %spx %s %s;"',
                        esc_attr($underline_thickness),
                        esc_attr($underline_style),
                        esc_attr($underline_color)
                    );
                } else {
                    $heading_style = 'style="border-bottom: none;"';
                }
                
                echo '<div class="sf-section-heading">';
                echo '<h3 ' . $heading_style . '>' . esc_html($field_label) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $heading_style is properly escaped above
                echo '</div>';
                break;
                
            case 'page_break':
                // Page break creates a new step/page in multi-step forms
                // Just output a marker div - JavaScript will handle the step wrapping and navigation
                $next_text = isset($field['next_button_text']) ? $field['next_button_text'] : 'Next';
                $prev_text = isset($field['previous_button_text']) ? $field['previous_button_text'] : 'Previous';
                $step_format = isset($field['step_indicator_format']) ? $field['step_indicator_format'] : 'Step {current} of {total}';
                $validation_message = isset($field['validation_message']) ? $field['validation_message'] : 'Please fill in all required fields before proceeding.';
                
                // Color settings
                $next_bg_color = isset($field['next_button_bg_color']) ? $field['next_button_bg_color'] : '#6366f1';
                $next_text_color = isset($field['next_button_text_color']) ? $field['next_button_text_color'] : '#ffffff';
                $prev_bg_color = isset($field['prev_button_bg_color']) ? $field['prev_button_bg_color'] : '#ffffff';
                $prev_text_color = isset($field['prev_button_text_color']) ? $field['prev_button_text_color'] : '#374151';
                $step_text_color = isset($field['step_indicator_text_color']) ? $field['step_indicator_text_color'] : '#6b7280';
                
                echo '<div class="sf-page-break" data-step-break="true" ';
                echo 'data-next-text="' . esc_attr($next_text) . '" ';
                echo 'data-prev-text="' . esc_attr($prev_text) . '" ';
                echo 'data-step-format="' . esc_attr($step_format) . '" ';
                echo 'data-validation-message="' . esc_attr($validation_message) . '" ';
                echo 'data-next-bg-color="' . esc_attr($next_bg_color) . '" ';
                echo 'data-next-text-color="' . esc_attr($next_text_color) . '" ';
                echo 'data-prev-bg-color="' . esc_attr($prev_bg_color) . '" ';
                echo 'data-prev-text-color="' . esc_attr($prev_text_color) . '" ';
                echo 'data-step-text-color="' . esc_attr($step_text_color) . '"';
                echo '></div>';
                break;
        }

        echo '</div>';
    }

    /**
     * Build the markup for a label or option image.
     *
     * @param string $url   Image URL. An empty value returns an empty string.
     * @param int    $width Optional pixel width. 0 leaves sizing to CSS.
     * @param string $class Image CSS class (sf-label-image or sf-option-image).
     * @return string Escaped image markup.
     */
    private function get_image_markup($url, $width = 0, $class = 'sf-option-image', $height = 0, $full_width = false, $width_unit = 'px')
    {
        if (empty($url)) {
            return '';
        }

        $width = absint($width);
        $height = absint($height);
        $width_unit = ($width_unit === '%') ? '%' : 'px';

        // A percentage (or full) width has to sit on the wrapper: a percentage on
        // the image itself would resolve against a shrink-to-fit wrapper, which
        // depends on the image - circular, so the browser falls back to auto.
        $relative_width = $full_width || ($width_unit === '%' && $width > 0);

        $wrap_rules = [];
        $image_rules = [];

        if ($full_width) {
            $wrap_rules[] = 'width:100%';
        } elseif ($width > 0 && $width_unit === '%') {
            $wrap_rules[] = 'width:' . min(100, $width) . '%';
        } elseif ($width > 0) {
            $image_rules[] = 'width:' . $width . 'px';
        }

        if ($relative_width) {
            $image_rules[] = 'width:100%';
        }

        if ($height > 0) {
            $image_rules[] = 'height:' . $height . 'px';
            // The base rule uses object-fit:contain, which would letterbox the
            // image inside an explicit height instead of stretching to it.
            $image_rules[] = 'object-fit:fill';
        }

        $wrap_class = ($class === 'sf-label-image') ? 'sf-label-image-wrap' : 'sf-option-image-wrap';

        if ($relative_width) {
            $wrap_class .= ' sf-image-relative-width';
        }

        if ($full_width) {
            $wrap_class .= ' sf-image-full-width';
        }

        $wrap_style = !empty($wrap_rules) ? ' style="' . esc_attr(implode(';', $wrap_rules)) . '"' : '';
        $image_style = !empty($image_rules) ? ' style="' . esc_attr(implode(';', $image_rules)) . '"' : '';

        return '<span class="' . esc_attr($wrap_class) . '"' . $wrap_style . '>'
            . '<img class="' . esc_attr($class) . '" src="' . esc_url($url) . '" alt=""' . $image_style . ' loading="lazy" />'
            . '</span>';
    }

    /**
     * Build the leading visual (image or flag) for a visual select option.
     *
     * @param array $option Prepared option with image/flag/text keys.
     * @param int   $size   Optional pixel width for the image.
     * @return string Escaped markup, or an empty string when there is nothing to show.
     */
    private function get_option_visual_markup($option, $size = 0)
    {
        if (!empty($option['image'])) {
            return $this->get_image_markup($option['image'], $size, 'sf-option-image');
        }

        if (!empty($option['flag'])) {
            return '<span class="sf-country-flag">' . esc_html($option['flag']) . '</span>';
        }

        return '';
    }

    /**
     * Split a leading flag emoji off a country label.
     *
     * Country options saved by older plugin versions store the flag inside the
     * label itself, so it has to be separated before it can be toggled.
     *
     * @param string $label Raw option label.
     * @return array{flag:string,label:string}
     */
    private function split_country_flag($label)
    {
        $pattern = '/^([\x{1F1E6}-\x{1F1FF}]{2})[\s\x{FE0F}]*/u';

        if (preg_match($pattern, $label, $matches)) {
            return array(
                'flag'  => $matches[1],
                'label' => preg_replace($pattern, '', $label),
            );
        }

        return array('flag' => '', 'label' => $label);
    }

    /**
     * Convert an ISO 3166-1 alpha-2 code into its regional indicator flag emoji.
     *
     * @param string $code Two letter country code.
     * @return string Flag emoji, or an empty string for an invalid code.
     */
    private function country_code_to_flag($code)
    {
        $code = strtoupper(trim((string) $code));

        if (strlen($code) !== 2 || !ctype_alpha($code)) {
            return '';
        }

        $flag = '';
        for ($i = 0; $i < 2; $i++) {
            $codepoint = 0x1F1E6 + (ord($code[$i]) - 65);
            // Regional indicators always land in the 4-byte UTF-8 range.
            $flag .= chr(0xF0 | ($codepoint >> 18))
                . chr(0x80 | (($codepoint >> 12) & 0x3F))
                . chr(0x80 | (($codepoint >> 6) & 0x3F))
                . chr(0x80 | ($codepoint & 0x3F));
        }

        return $flag;
    }

    /**
     * Get countries list with phone codes
     *
     * @return array Countries list
     */
    private function get_countries_list()
    {
        return array(
            array('code' => 'AF', 'name' => 'Afghanistan', 'flag' => '🇦🇫', 'phoneCode' => '+93'),
            array('code' => 'AL', 'name' => 'Albania', 'flag' => '🇦🇱', 'phoneCode' => '+355'),
            array('code' => 'DZ', 'name' => 'Algeria', 'flag' => '🇩🇿', 'phoneCode' => '+213'),
            array('code' => 'AD', 'name' => 'Andorra', 'flag' => '🇦🇩', 'phoneCode' => '+376'),
            array('code' => 'AO', 'name' => 'Angola', 'flag' => '🇦🇴', 'phoneCode' => '+244'),
            array('code' => 'AG', 'name' => 'Antigua and Barbuda', 'flag' => '🇦🇬', 'phoneCode' => '+1-268'),
            array('code' => 'AR', 'name' => 'Argentina', 'flag' => '🇦🇷', 'phoneCode' => '+54'),
            array('code' => 'AM', 'name' => 'Armenia', 'flag' => '🇦🇲', 'phoneCode' => '+374'),
            array('code' => 'AU', 'name' => 'Australia', 'flag' => '🇦🇺', 'phoneCode' => '+61'),
            array('code' => 'AT', 'name' => 'Austria', 'flag' => '🇦🇹', 'phoneCode' => '+43'),
            array('code' => 'AZ', 'name' => 'Azerbaijan', 'flag' => '🇦🇿', 'phoneCode' => '+994'),
            array('code' => 'BS', 'name' => 'Bahamas', 'flag' => '🇧🇸', 'phoneCode' => '+1-242'),
            array('code' => 'BH', 'name' => 'Bahrain', 'flag' => '🇧🇭', 'phoneCode' => '+973'),
            array('code' => 'BD', 'name' => 'Bangladesh', 'flag' => '🇧🇩', 'phoneCode' => '+880'),
            array('code' => 'BB', 'name' => 'Barbados', 'flag' => '🇧🇧', 'phoneCode' => '+1-246'),
            array('code' => 'BY', 'name' => 'Belarus', 'flag' => '🇧🇾', 'phoneCode' => '+375'),
            array('code' => 'BE', 'name' => 'Belgium', 'flag' => '🇧🇪', 'phoneCode' => '+32'),
            array('code' => 'BZ', 'name' => 'Belize', 'flag' => '🇧🇿', 'phoneCode' => '+501'),
            array('code' => 'BJ', 'name' => 'Benin', 'flag' => '🇧🇯', 'phoneCode' => '+229'),
            array('code' => 'BT', 'name' => 'Bhutan', 'flag' => '🇧🇹', 'phoneCode' => '+975'),
            array('code' => 'BO', 'name' => 'Bolivia', 'flag' => '🇧🇴', 'phoneCode' => '+591'),
            array('code' => 'BA', 'name' => 'Bosnia and Herzegovina', 'flag' => '🇧🇦', 'phoneCode' => '+387'),
            array('code' => 'BW', 'name' => 'Botswana', 'flag' => '🇧🇼', 'phoneCode' => '+267'),
            array('code' => 'BR', 'name' => 'Brazil', 'flag' => '🇧🇷', 'phoneCode' => '+55'),
            array('code' => 'BN', 'name' => 'Brunei', 'flag' => '🇧🇳', 'phoneCode' => '+673'),
            array('code' => 'BG', 'name' => 'Bulgaria', 'flag' => '🇧🇬', 'phoneCode' => '+359'),
            array('code' => 'BF', 'name' => 'Burkina Faso', 'flag' => '🇧🇫', 'phoneCode' => '+226'),
            array('code' => 'BI', 'name' => 'Burundi', 'flag' => '🇧🇮', 'phoneCode' => '+257'),
            array('code' => 'KH', 'name' => 'Cambodia', 'flag' => '🇰🇭', 'phoneCode' => '+855'),
            array('code' => 'CM', 'name' => 'Cameroon', 'flag' => '🇨🇲', 'phoneCode' => '+237'),
            array('code' => 'CA', 'name' => 'Canada', 'flag' => '🇨🇦', 'phoneCode' => '+1'),
            array('code' => 'CV', 'name' => 'Cape Verde', 'flag' => '🇨🇻', 'phoneCode' => '+238'),
            array('code' => 'CF', 'name' => 'Central African Republic', 'flag' => '🇨🇫', 'phoneCode' => '+236'),
            array('code' => 'TD', 'name' => 'Chad', 'flag' => '🇹🇩', 'phoneCode' => '+235'),
            array('code' => 'CL', 'name' => 'Chile', 'flag' => '🇨🇱', 'phoneCode' => '+56'),
            array('code' => 'CN', 'name' => 'China', 'flag' => '🇨🇳', 'phoneCode' => '+86'),
            array('code' => 'CO', 'name' => 'Colombia', 'flag' => '🇨🇴', 'phoneCode' => '+57'),
            array('code' => 'KM', 'name' => 'Comoros', 'flag' => '🇰🇲', 'phoneCode' => '+269'),
            array('code' => 'CG', 'name' => 'Congo', 'flag' => '🇨🇬', 'phoneCode' => '+242'),
            array('code' => 'CR', 'name' => 'Costa Rica', 'flag' => '🇨🇷', 'phoneCode' => '+506'),
            array('code' => 'CI', 'name' => 'Côte d\'Ivoire', 'flag' => '🇨🇮', 'phoneCode' => '+225'),
            array('code' => 'HR', 'name' => 'Croatia', 'flag' => '🇭🇷', 'phoneCode' => '+385'),
            array('code' => 'CU', 'name' => 'Cuba', 'flag' => '🇨🇺', 'phoneCode' => '+53'),
            array('code' => 'CY', 'name' => 'Cyprus', 'flag' => '🇨🇾', 'phoneCode' => '+357'),
            array('code' => 'CZ', 'name' => 'Czech Republic', 'flag' => '🇨🇿', 'phoneCode' => '+420'),
            array('code' => 'DK', 'name' => 'Denmark', 'flag' => '🇩🇰', 'phoneCode' => '+45'),
            array('code' => 'DJ', 'name' => 'Djibouti', 'flag' => '🇩🇯', 'phoneCode' => '+253'),
            array('code' => 'DM', 'name' => 'Dominica', 'flag' => '🇩🇲', 'phoneCode' => '+1-767'),
            array('code' => 'DO', 'name' => 'Dominican Republic', 'flag' => '🇩🇴', 'phoneCode' => '+1-809'),
            array('code' => 'EC', 'name' => 'Ecuador', 'flag' => '🇪🇨', 'phoneCode' => '+593'),
            array('code' => 'EG', 'name' => 'Egypt', 'flag' => '🇪🇬', 'phoneCode' => '+20'),
            array('code' => 'SV', 'name' => 'El Salvador', 'flag' => '🇸🇻', 'phoneCode' => '+503'),
            array('code' => 'GQ', 'name' => 'Equatorial Guinea', 'flag' => '🇬🇶', 'phoneCode' => '+240'),
            array('code' => 'ER', 'name' => 'Eritrea', 'flag' => '🇪🇷', 'phoneCode' => '+291'),
            array('code' => 'EE', 'name' => 'Estonia', 'flag' => '🇪🇪', 'phoneCode' => '+372'),
            array('code' => 'ET', 'name' => 'Ethiopia', 'flag' => '🇪🇹', 'phoneCode' => '+251'),
            array('code' => 'FJ', 'name' => 'Fiji', 'flag' => '🇫🇯', 'phoneCode' => '+679'),
            array('code' => 'FI', 'name' => 'Finland', 'flag' => '🇫🇮', 'phoneCode' => '+358'),
            array('code' => 'FR', 'name' => 'France', 'flag' => '🇫🇷', 'phoneCode' => '+33'),
            array('code' => 'GA', 'name' => 'Gabon', 'flag' => '🇬🇦', 'phoneCode' => '+241'),
            array('code' => 'GM', 'name' => 'Gambia', 'flag' => '🇬🇲', 'phoneCode' => '+220'),
            array('code' => 'GE', 'name' => 'Georgia', 'flag' => '🇬🇪', 'phoneCode' => '+995'),
            array('code' => 'DE', 'name' => 'Germany', 'flag' => '🇩🇪', 'phoneCode' => '+49'),
            array('code' => 'GH', 'name' => 'Ghana', 'flag' => '🇬🇭', 'phoneCode' => '+233'),
            array('code' => 'GR', 'name' => 'Greece', 'flag' => '🇬🇷', 'phoneCode' => '+30'),
            array('code' => 'GD', 'name' => 'Grenada', 'flag' => '🇬🇩', 'phoneCode' => '+1-473'),
            array('code' => 'GT', 'name' => 'Guatemala', 'flag' => '🇬🇹', 'phoneCode' => '+502'),
            array('code' => 'GN', 'name' => 'Guinea', 'flag' => '🇬🇳', 'phoneCode' => '+224'),
            array('code' => 'GW', 'name' => 'Guinea-Bissau', 'flag' => '🇬🇼', 'phoneCode' => '+245'),
            array('code' => 'GY', 'name' => 'Guyana', 'flag' => '🇬🇾', 'phoneCode' => '+592'),
            array('code' => 'HT', 'name' => 'Haiti', 'flag' => '🇭🇹', 'phoneCode' => '+509'),
            array('code' => 'HN', 'name' => 'Honduras', 'flag' => '🇭🇳', 'phoneCode' => '+504'),
            array('code' => 'HU', 'name' => 'Hungary', 'flag' => '🇭🇺', 'phoneCode' => '+36'),
            array('code' => 'IS', 'name' => 'Iceland', 'flag' => '🇮🇸', 'phoneCode' => '+354'),
            array('code' => 'IN', 'name' => 'India', 'flag' => '🇮🇳', 'phoneCode' => '+91'),
            array('code' => 'ID', 'name' => 'Indonesia', 'flag' => '🇮🇩', 'phoneCode' => '+62'),
            array('code' => 'IR', 'name' => 'Iran', 'flag' => '🇮🇷', 'phoneCode' => '+98'),
            array('code' => 'IQ', 'name' => 'Iraq', 'flag' => '🇮🇶', 'phoneCode' => '+964'),
            array('code' => 'IE', 'name' => 'Ireland', 'flag' => '🇮🇪', 'phoneCode' => '+353'),
            array('code' => 'IL', 'name' => 'Israel', 'flag' => '🇮🇱', 'phoneCode' => '+972'),
            array('code' => 'IT', 'name' => 'Italy', 'flag' => '🇮🇹', 'phoneCode' => '+39'),
            array('code' => 'JM', 'name' => 'Jamaica', 'flag' => '🇯🇲', 'phoneCode' => '+1-876'),
            array('code' => 'JP', 'name' => 'Japan', 'flag' => '🇯🇵', 'phoneCode' => '+81'),
            array('code' => 'JO', 'name' => 'Jordan', 'flag' => '🇯🇴', 'phoneCode' => '+962'),
            array('code' => 'KZ', 'name' => 'Kazakhstan', 'flag' => '🇰🇿', 'phoneCode' => '+7'),
            array('code' => 'KE', 'name' => 'Kenya', 'flag' => '🇰🇪', 'phoneCode' => '+254'),
            array('code' => 'KI', 'name' => 'Kiribati', 'flag' => '🇰🇮', 'phoneCode' => '+686'),
            array('code' => 'KW', 'name' => 'Kuwait', 'flag' => '🇰🇼', 'phoneCode' => '+965'),
            array('code' => 'KG', 'name' => 'Kyrgyzstan', 'flag' => '🇰🇬', 'phoneCode' => '+996'),
            array('code' => 'LA', 'name' => 'Laos', 'flag' => '🇱🇦', 'phoneCode' => '+856'),
            array('code' => 'LV', 'name' => 'Latvia', 'flag' => '🇱🇻', 'phoneCode' => '+371'),
            array('code' => 'LB', 'name' => 'Lebanon', 'flag' => '🇱🇧', 'phoneCode' => '+961'),
            array('code' => 'LS', 'name' => 'Lesotho', 'flag' => '🇱🇸', 'phoneCode' => '+266'),
            array('code' => 'LR', 'name' => 'Liberia', 'flag' => '🇱🇷', 'phoneCode' => '+231'),
            array('code' => 'LY', 'name' => 'Libya', 'flag' => '🇱🇾', 'phoneCode' => '+218'),
            array('code' => 'LI', 'name' => 'Liechtenstein', 'flag' => '🇱🇮', 'phoneCode' => '+423'),
            array('code' => 'LT', 'name' => 'Lithuania', 'flag' => '🇱🇹', 'phoneCode' => '+370'),
            array('code' => 'LU', 'name' => 'Luxembourg', 'flag' => '🇱🇺', 'phoneCode' => '+352'),
            array('code' => 'MK', 'name' => 'Macedonia', 'flag' => '🇲🇰', 'phoneCode' => '+389'),
            array('code' => 'MG', 'name' => 'Madagascar', 'flag' => '🇲🇬', 'phoneCode' => '+261'),
            array('code' => 'MW', 'name' => 'Malawi', 'flag' => '🇲🇼', 'phoneCode' => '+265'),
            array('code' => 'MY', 'name' => 'Malaysia', 'flag' => '🇲🇾', 'phoneCode' => '+60'),
            array('code' => 'MV', 'name' => 'Maldives', 'flag' => '🇲🇻', 'phoneCode' => '+960'),
            array('code' => 'ML', 'name' => 'Mali', 'flag' => '🇲🇱', 'phoneCode' => '+223'),
            array('code' => 'MT', 'name' => 'Malta', 'flag' => '🇲🇹', 'phoneCode' => '+356'),
            array('code' => 'MH', 'name' => 'Marshall Islands', 'flag' => '🇲🇭', 'phoneCode' => '+692'),
            array('code' => 'MR', 'name' => 'Mauritania', 'flag' => '🇲🇷', 'phoneCode' => '+222'),
            array('code' => 'MU', 'name' => 'Mauritius', 'flag' => '🇲🇺', 'phoneCode' => '+230'),
            array('code' => 'MX', 'name' => 'Mexico', 'flag' => '🇲🇽', 'phoneCode' => '+52'),
            array('code' => 'FM', 'name' => 'Micronesia', 'flag' => '🇫🇲', 'phoneCode' => '+691'),
            array('code' => 'MD', 'name' => 'Moldova', 'flag' => '🇲🇩', 'phoneCode' => '+373'),
            array('code' => 'MC', 'name' => 'Monaco', 'flag' => '🇲🇨', 'phoneCode' => '+377'),
            array('code' => 'MN', 'name' => 'Mongolia', 'flag' => '🇲🇳', 'phoneCode' => '+976'),
            array('code' => 'ME', 'name' => 'Montenegro', 'flag' => '🇲🇪', 'phoneCode' => '+382'),
            array('code' => 'MA', 'name' => 'Morocco', 'flag' => '🇲🇦', 'phoneCode' => '+212'),
            array('code' => 'MZ', 'name' => 'Mozambique', 'flag' => '🇲🇿', 'phoneCode' => '+258'),
            array('code' => 'MM', 'name' => 'Myanmar', 'flag' => '🇲🇲', 'phoneCode' => '+95'),
            array('code' => 'NA', 'name' => 'Namibia', 'flag' => '🇳🇦', 'phoneCode' => '+264'),
            array('code' => 'NR', 'name' => 'Nauru', 'flag' => '🇳🇷', 'phoneCode' => '+674'),
            array('code' => 'NP', 'name' => 'Nepal', 'flag' => '🇳🇵', 'phoneCode' => '+977'),
            array('code' => 'NL', 'name' => 'Netherlands', 'flag' => '🇳🇱', 'phoneCode' => '+31'),
            array('code' => 'NZ', 'name' => 'New Zealand', 'flag' => '🇳🇿', 'phoneCode' => '+64'),
            array('code' => 'NI', 'name' => 'Nicaragua', 'flag' => '🇳🇮', 'phoneCode' => '+505'),
            array('code' => 'NE', 'name' => 'Niger', 'flag' => '🇳🇪', 'phoneCode' => '+227'),
            array('code' => 'NG', 'name' => 'Nigeria', 'flag' => '🇳🇬', 'phoneCode' => '+234'),
            array('code' => 'KP', 'name' => 'North Korea', 'flag' => '🇰🇵', 'phoneCode' => '+850'),
            array('code' => 'NO', 'name' => 'Norway', 'flag' => '🇳🇴', 'phoneCode' => '+47'),
            array('code' => 'OM', 'name' => 'Oman', 'flag' => '🇴🇲', 'phoneCode' => '+968'),
            array('code' => 'PK', 'name' => 'Pakistan', 'flag' => '🇵🇰', 'phoneCode' => '+92'),
            array('code' => 'PW', 'name' => 'Palau', 'flag' => '🇵🇼', 'phoneCode' => '+680'),
            array('code' => 'PA', 'name' => 'Panama', 'flag' => '🇵🇦', 'phoneCode' => '+507'),
            array('code' => 'PG', 'name' => 'Papua New Guinea', 'flag' => '🇵🇬', 'phoneCode' => '+675'),
            array('code' => 'PY', 'name' => 'Paraguay', 'flag' => '🇵🇾', 'phoneCode' => '+595'),
            array('code' => 'PE', 'name' => 'Peru', 'flag' => '🇵🇪', 'phoneCode' => '+51'),
            array('code' => 'PH', 'name' => 'Philippines', 'flag' => '🇵🇭', 'phoneCode' => '+63'),
            array('code' => 'PL', 'name' => 'Poland', 'flag' => '🇵🇱', 'phoneCode' => '+48'),
            array('code' => 'PT', 'name' => 'Portugal', 'flag' => '🇵🇹', 'phoneCode' => '+351'),
            array('code' => 'QA', 'name' => 'Qatar', 'flag' => '🇶🇦', 'phoneCode' => '+974'),
            array('code' => 'RO', 'name' => 'Romania', 'flag' => '🇷🇴', 'phoneCode' => '+40'),
            array('code' => 'RU', 'name' => 'Russia', 'flag' => '🇷🇺', 'phoneCode' => '+7'),
            array('code' => 'RW', 'name' => 'Rwanda', 'flag' => '🇷🇼', 'phoneCode' => '+250'),
            array('code' => 'KN', 'name' => 'Saint Kitts and Nevis', 'flag' => '🇰🇳', 'phoneCode' => '+1-869'),
            array('code' => 'LC', 'name' => 'Saint Lucia', 'flag' => '🇱🇨', 'phoneCode' => '+1-758'),
            array('code' => 'VC', 'name' => 'Saint Vincent and the Grenadines', 'flag' => '🇻🇨', 'phoneCode' => '+1-784'),
            array('code' => 'WS', 'name' => 'Samoa', 'flag' => '🇼🇸', 'phoneCode' => '+685'),
            array('code' => 'SM', 'name' => 'San Marino', 'flag' => '🇸🇲', 'phoneCode' => '+378'),
            array('code' => 'ST', 'name' => 'Sao Tome and Principe', 'flag' => '🇸🇹', 'phoneCode' => '+239'),
            array('code' => 'SA', 'name' => 'Saudi Arabia', 'flag' => '🇸🇦', 'phoneCode' => '+966'),
            array('code' => 'SN', 'name' => 'Senegal', 'flag' => '🇸🇳', 'phoneCode' => '+221'),
            array('code' => 'RS', 'name' => 'Serbia', 'flag' => '🇷🇸', 'phoneCode' => '+381'),
            array('code' => 'SC', 'name' => 'Seychelles', 'flag' => '🇸🇨', 'phoneCode' => '+248'),
            array('code' => 'SL', 'name' => 'Sierra Leone', 'flag' => '🇸🇱', 'phoneCode' => '+232'),
            array('code' => 'SG', 'name' => 'Singapore', 'flag' => '🇸🇬', 'phoneCode' => '+65'),
            array('code' => 'SK', 'name' => 'Slovakia', 'flag' => '🇸🇰', 'phoneCode' => '+421'),
            array('code' => 'SI', 'name' => 'Slovenia', 'flag' => '🇸🇮', 'phoneCode' => '+386'),
            array('code' => 'SB', 'name' => 'Solomon Islands', 'flag' => '🇸🇧', 'phoneCode' => '+677'),
            array('code' => 'SO', 'name' => 'Somalia', 'flag' => '🇸🇴', 'phoneCode' => '+252'),
            array('code' => 'ZA', 'name' => 'South Africa', 'flag' => '🇿🇦', 'phoneCode' => '+27'),
            array('code' => 'KR', 'name' => 'South Korea', 'flag' => '🇰🇷', 'phoneCode' => '+82'),
            array('code' => 'SS', 'name' => 'South Sudan', 'flag' => '🇸🇸', 'phoneCode' => '+211'),
            array('code' => 'ES', 'name' => 'Spain', 'flag' => '🇪🇸', 'phoneCode' => '+34'),
            array('code' => 'LK', 'name' => 'Sri Lanka', 'flag' => '🇱🇰', 'phoneCode' => '+94'),
            array('code' => 'SD', 'name' => 'Sudan', 'flag' => '🇸🇩', 'phoneCode' => '+249'),
            array('code' => 'SR', 'name' => 'Suriname', 'flag' => '🇸🇷', 'phoneCode' => '+597'),
            array('code' => 'SZ', 'name' => 'Swaziland', 'flag' => '🇸🇿', 'phoneCode' => '+268'),
            array('code' => 'SE', 'name' => 'Sweden', 'flag' => '🇸🇪', 'phoneCode' => '+46'),
            array('code' => 'CH', 'name' => 'Switzerland', 'flag' => '🇨🇭', 'phoneCode' => '+41'),
            array('code' => 'SY', 'name' => 'Syria', 'flag' => '🇸🇾', 'phoneCode' => '+963'),
            array('code' => 'TW', 'name' => 'Taiwan', 'flag' => '🇹🇼', 'phoneCode' => '+886'),
            array('code' => 'TJ', 'name' => 'Tajikistan', 'flag' => '🇹🇯', 'phoneCode' => '+992'),
            array('code' => 'TZ', 'name' => 'Tanzania', 'flag' => '🇹🇿', 'phoneCode' => '+255'),
            array('code' => 'TH', 'name' => 'Thailand', 'flag' => '🇹🇭', 'phoneCode' => '+66'),
            array('code' => 'TL', 'name' => 'Timor-Leste', 'flag' => '🇹🇱', 'phoneCode' => '+670'),
            array('code' => 'TG', 'name' => 'Togo', 'flag' => '🇹🇬', 'phoneCode' => '+228'),
            array('code' => 'TO', 'name' => 'Tonga', 'flag' => '🇹🇴', 'phoneCode' => '+676'),
            array('code' => 'TT', 'name' => 'Trinidad and Tobago', 'flag' => '🇹🇹', 'phoneCode' => '+1-868'),
            array('code' => 'TN', 'name' => 'Tunisia', 'flag' => '🇹🇳', 'phoneCode' => '+216'),
            array('code' => 'TR', 'name' => 'Turkey', 'flag' => '🇹🇷', 'phoneCode' => '+90'),
            array('code' => 'TM', 'name' => 'Turkmenistan', 'flag' => '🇹🇲', 'phoneCode' => '+993'),
            array('code' => 'TV', 'name' => 'Tuvalu', 'flag' => '🇹🇻', 'phoneCode' => '+688'),
            array('code' => 'UG', 'name' => 'Uganda', 'flag' => '🇺🇬', 'phoneCode' => '+256'),
            array('code' => 'UA', 'name' => 'Ukraine', 'flag' => '🇺🇦', 'phoneCode' => '+380'),
            array('code' => 'AE', 'name' => 'United Arab Emirates', 'flag' => '🇦🇪', 'phoneCode' => '+971'),
            array('code' => 'GB', 'name' => 'United Kingdom', 'flag' => '🇬🇧', 'phoneCode' => '+44'),
            array('code' => 'US', 'name' => 'United States', 'flag' => '🇺🇸', 'phoneCode' => '+1'),
            array('code' => 'UY', 'name' => 'Uruguay', 'flag' => '🇺🇾', 'phoneCode' => '+598'),
            array('code' => 'UZ', 'name' => 'Uzbekistan', 'flag' => '🇺🇿', 'phoneCode' => '+998'),
            array('code' => 'VU', 'name' => 'Vanuatu', 'flag' => '🇻🇺', 'phoneCode' => '+678'),
            array('code' => 'VA', 'name' => 'Vatican City', 'flag' => '🇻🇦', 'phoneCode' => '+379'),
            array('code' => 'VE', 'name' => 'Venezuela', 'flag' => '🇻🇪', 'phoneCode' => '+58'),
            array('code' => 'VN', 'name' => 'Vietnam', 'flag' => '🇻🇳', 'phoneCode' => '+84'),
            array('code' => 'YE', 'name' => 'Yemen', 'flag' => '🇾🇪', 'phoneCode' => '+967'),
            array('code' => 'ZM', 'name' => 'Zambia', 'flag' => '🇿🇲', 'phoneCode' => '+260'),
            array('code' => 'ZW', 'name' => 'Zimbabwe', 'flag' => '🇿🇼', 'phoneCode' => '+263')
        );
    }
}
