<?php
/**
 * Form Field class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Forms;

class FormField {
    /**
     * Field ID
     *
     * @var string
     */
    private $id;
    
    /**
     * Field name
     *
     * @var string
     */
    private $name;
    
    /**
     * Field type
     *
     * @var string
     */
    private $type;
    
    /**
     * Field label
     *
     * @var string
     */
    private $label;
    
    /**
     * Field placeholder
     *
     * @var string
     */
    private $placeholder;
    
    /**
     * Field default value
     *
     * @var string
     */
    private $default_value;
    
    /**
     * Whether field is required
     *
     * @var bool
     */
    private $required;
    
    /**
     * Field options (for select, radio, checkbox)
     *
     * @var array
     */
    private $options;
    
    /**
     * Conditional display rules
     *
     * @var array
     */
    private $conditional;
    
    /**
     * Help text for the field
     *
     * @var string
     */
    private $help_text;
    
    /**
     * Range min value
     *
     * @var float|string
     */
    private $range_min;

    /**
     * Range max value
     *
     * @var float|string
     */
    private $range_max;

    /**
     * Range step value
     *
     * @var float|string
     */
    private $range_step;
    
    /**
     * Constructor
     *
     * @param array $field_data Field data
     */
    public function __construct($field_data = []) {
        $this->id = isset($field_data['id']) ? str_replace(' ', '_', sanitize_text_field(trim($field_data['id']))) : '';
        $this->name = isset($field_data['name']) ? sanitize_text_field($field_data['name']) : '';
        $this->type = isset($field_data['type']) ? sanitize_text_field($field_data['type']) : 'text';
        $this->label = isset($field_data['label']) ? sanitize_text_field($field_data['label']) : '';
        $this->placeholder = isset($field_data['placeholder']) ? sanitize_text_field($field_data['placeholder']) : '';
        $this->default_value = isset($field_data['default_value']) ? sanitize_text_field($field_data['default_value']) : '';
        $this->required = isset($field_data['required']) ? (bool) $field_data['required'] : false;
        $this->options = isset($field_data['options']) && is_array($field_data['options']) ? $field_data['options'] : [];
        $this->conditional = isset($field_data['conditional']) && is_array($field_data['conditional']) ? $field_data['conditional'] : [];
        $this->help_text = isset($field_data['help_text']) ? sanitize_text_field($field_data['help_text']) : '';
        $this->range_min = isset($field_data['range_min']) ? $field_data['range_min'] : null;
        $this->range_max = isset($field_data['range_max']) ? $field_data['range_max'] : null;
        $this->range_step = isset($field_data['range_step']) ? $field_data['range_step'] : null;
    }
    
    /**
     * Get field data as array
     *
     * @return array Field data
     */
    public function to_array() {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'type' => $this->type,
            'label' => $this->label,
            'placeholder' => $this->placeholder,
            'default_value' => $this->default_value,
            'required' => $this->required,
            'options' => $this->options,
            'conditional' => $this->conditional,
            'help_text' => $this->help_text,
        ];
    }
    
    /**
     * Get field ID
     *
     * @return string Field ID
     */
    public function get_id() {
        return $this->id;
    }
    
    /**
     * Get field name
     *
     * @return string Field name
     */
    public function get_name() {
        return $this->name;
    }
    
    /**
     * Get field type
     *
     * @return string Field type
     */
    public function get_type() {
        return $this->type;
    }
    
    /**
     * Get field label
     *
     * @return string Field label
     */
    public function get_label() {
        return $this->label;
    }
    
    /**
     * Get field placeholder
     *
     * @return string Field placeholder
     */
    public function get_placeholder() {
        return $this->placeholder;
    }
    
    /**
     * Get field default value
     *
     * @return string Field default value
     */
    public function get_default_value() {
        return $this->default_value;
    }
    
    /**
     * Check if field is required
     *
     * @return bool Whether field is required
     */
    public function is_required() {
        return $this->required;
    }
    
    /**
     * Get field options
     *
     * @return array Field options
     */
    public function get_options() {
        return $this->options;
    }
    
    /**
     * Get conditional rules
     *
     * @return array Conditional rules
     */
    public function get_conditional() {
        return $this->conditional;
    }
    
    /**
     * Check if field has conditional logic
     *
     * @return bool Whether field has conditional logic
     */
    public function has_conditional() {
        return !empty($this->conditional) && isset($this->conditional['show']) && isset($this->conditional['field']);
    }
    
    /**
     * Validate field value
     *
     * @param mixed $value Field value
     * @return array Validation result with 'valid' and 'message' keys
     */
    public function validate($value) {
        $result = [
            'valid' => true,
            'message' => '',
        ];
        
        // Section headings don't need validation
        if ($this->type === 'section_heading') {
            return $result;
        }
        
        // Check required
        if ($this->required && empty($value)) {
            $result['valid'] = false;
            // translators: %s is the field label.
            $result['message'] = sprintf(__('%s is required.', 'sigmaforms-pro'), $this->label);
            return $result;
        }
        
        // Skip further validation if empty and not required
        if (empty($value) && !$this->required) {
            return $result;
        }
        
        // Validate based on field type
        switch ($this->type) {
            case 'email':
                if (!is_email($value)) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('%s must be a valid email address.', 'sigmaforms-pro'), $this->label);
                }
                break;
                
            case 'number':
                if (!is_numeric($value)) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('%s must be a number.', 'sigmaforms-pro'), $this->label);
                }
                break;
                
            case 'phone':
                if (!preg_match('/^[0-9()+\-\s]*$/', $value)) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('%s must be a valid phone number.', 'sigmaforms-pro'), $this->label);
                }
                break;
                
            case 'select':
            case 'radio':
                $valid_option = false;
                
                foreach ($this->options as $option) {
                    if (isset($option['value']) && $option['value'] === $value) {
                        $valid_option = true;
                        break;
                    }
                }
                
                if (!$valid_option) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('Invalid option selected for %s.', 'sigmaforms-pro'), $this->label);
                }
                break;
                
            case 'checkbox':
                if (is_array($value)) {
                    // Multiple checkboxes
                    foreach ($value as $checkbox_value) {
                        $valid_option = false;
                        
                        foreach ($this->options as $option) {
                            if (isset($option['value']) && $option['value'] === $checkbox_value) {
                                $valid_option = true;
                                break;
                            }
                        }
                        
                        if (!$valid_option) {
                            $result['valid'] = false;
                            // translators: %s is the field label.
                            $result['message'] = sprintf(__('Invalid option selected for %s.', 'sigmaforms-pro'), $this->label);
                            break;
                        }
                    }
                } else {
                    // Single checkbox
                    if ($value !== '1' && $value !== 1 && $value !== 'on' && $value !== true) {
                        $result['valid'] = false;
                        // translators: %s is the field label.
                        $result['message'] = sprintf(__('Invalid value for %s.', 'sigmaforms-pro'), $this->label);
                    }
                }
                break;
        }
        
        return $result;
    }
    
    /**
     * Sanitize field value based on type
     *
     * @param mixed $value Field value
     * @return mixed Sanitized value
     */
    public function sanitize($value) {
        if (is_array($value)) {
            // For checkbox arrays
            $sanitized = [];
            
            foreach ($value as $item) {
                $sanitized[] = sanitize_text_field($item);
            }
            
            return $sanitized;
        }
        
        switch ($this->type) {
            case 'email':
                return sanitize_email($value);
                
            case 'number':
                return floatval($value);
                
            case 'range':
                return floatval($value);
                
            case 'textarea':
                return sanitize_textarea_field($value);
                
            case 'rich_text':
                return wp_kses_post($value);
                
            default:
                return sanitize_text_field($value);
        }
    }
    
    /**
     * Get help text for the field
     *
     * @return string Help text for the field
     */
    public function get_help_text() {
        return $this->help_text;
    }
}
