<?php
/**
 * Abandoned Form class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Forms;

class AbandonedForm {
    /**
     * Abandoned form ID
     *
     * @var int
     */
    private $id;
    
    /**
     * Associated form ID
     *
     * @var int
     */
    private $form_id;
    
    /**
     * Session ID for tracking
     *
     * @var string
     */
    private $session_id;
    
    /**
     * Partial field values
     *
     * @var array
     */
    private $field_values;
    
    /**
     * User ID (if logged in)
     *
     * @var int
     */
    private $user_id;
    
    /**
     * User IP address
     *
     * @var string
     */
    private $user_ip;
    
    /**
     * User agent
     *
     * @var string
     */
    private $user_agent;
    
    /**
     * Start time when user began filling
     *
     * @var string
     */
    private $start_time;
    
    /**
     * Last activity time
     *
     * @var string
     */
    private $last_activity;
    
    /**
     * Abandonment type
     *
     * @var string
     */
    private $abandonment_type;
    
    /**
     * Whether form was eventually submitted
     *
     * @var bool
     */
    private $is_converted;
    
    /**
     * Completion percentage
     *
     * @var float
     */
    private $completion_percentage;
    
    /**
     * Form title (from LEFT JOIN, may be null if form is deleted)
     *
     * @var string|null
     */
    private $form_title;
    
    /**
     * Constructor
     *
     * @param array $abandoned_data Abandoned form data
     */
    public function __construct($abandoned_data = []) {
        $this->id = isset($abandoned_data['id']) ? (int) $abandoned_data['id'] : 0;
        $this->form_id = isset($abandoned_data['form_id']) ? (int) $abandoned_data['form_id'] : 0;
        $this->session_id = isset($abandoned_data['session_id']) ? $abandoned_data['session_id'] : '';
        
        // Handle field values from database or direct array
        if (isset($abandoned_data['field_values'])) {
            if (is_string($abandoned_data['field_values'])) {
                $this->field_values = json_decode($abandoned_data['field_values'], true) ?: [];
            } else {
                $this->field_values = $abandoned_data['field_values'];
            }
        } else {
            $this->field_values = [];
        }
        
        $this->user_id = isset($abandoned_data['user_id']) ? (int) $abandoned_data['user_id'] : 0;
        $this->user_ip = isset($abandoned_data['user_ip']) ? $abandoned_data['user_ip'] : '';
        $this->user_agent = isset($abandoned_data['user_agent']) ? $abandoned_data['user_agent'] : '';
        $this->start_time = isset($abandoned_data['start_time']) ? $abandoned_data['start_time'] : '';
        $this->last_activity = isset($abandoned_data['last_activity']) ? $abandoned_data['last_activity'] : '';
        $this->abandonment_type = isset($abandoned_data['abandonment_type']) ? $abandoned_data['abandonment_type'] : 'timeout';
        $this->is_converted = isset($abandoned_data['is_converted']) ? (bool) $abandoned_data['is_converted'] : false;
        $this->completion_percentage = isset($abandoned_data['completion_percentage']) ? (float) $abandoned_data['completion_percentage'] : 0.0;
        $this->form_title = isset($abandoned_data['form_title']) ? $abandoned_data['form_title'] : null;
    }
    
    /**
     * Get abandoned form data as array
     *
     * @return array Abandoned form data
     */
    public function to_array() {
        return [
            'id' => $this->id,
            'form_id' => $this->form_id,
            'session_id' => $this->session_id,
            'field_values' => $this->field_values,
            'user_id' => $this->user_id,
            'user_ip' => $this->user_ip,
            'user_agent' => $this->user_agent,
            'start_time' => $this->start_time,
            'last_activity' => $this->last_activity,
            'abandonment_type' => $this->abandonment_type,
            'is_converted' => $this->is_converted,
            'completion_percentage' => $this->completion_percentage,
        ];
    }
    
    /**
     * Get form ID
     *
     * @return int Form ID
     */
    public function get_form_id() {
        return $this->form_id;
    }
    
    /**
     * Get abandoned form ID
     *
     * @return int Abandoned form ID
     */
    public function get_id() {
        return $this->id;
    }
    
    /**
     * Get user ID
     *
     * @return int User ID
     */
    public function get_user_id() {
        return $this->user_id;
    }
    
    /**
     * Get session ID
     *
     * @return string Session ID
     */
    public function get_session_id() {
        return $this->session_id;
    }
    
    /**
     * Get field values
     *
     * @return array Field values
     */
    public function get_field_values() {
        return $this->field_values;
    }
    
    /**
     * Get completion percentage
     *
     * @return float Completion percentage
     */
    public function get_completion_percentage() {
        return $this->completion_percentage;
    }
    
    /**
     * Get start time
     *
     * @return string Start time
     */
    public function get_start_time() {
        return $this->start_time;
    }
    
    /**
     * Get last activity time
     *
     * @return string Last activity time
     */
    public function get_last_activity() {
        return $this->last_activity;
    }
    
    /**
     * Get abandonment type
     *
     * @return string Abandonment type
     */
    public function get_abandonment_type() {
        return $this->abandonment_type;
    }
    
    /**
     * Check if converted
     *
     * @return bool Is converted
     */
    public function is_converted() {
        return $this->is_converted;
    }
    
    /**
     * Get formatted start time
     *
     * @param string $format Date format
     * @return string Formatted date
     */
    public function get_formatted_start_time($format = '') {
        if (empty($format)) {
            $format = get_option('date_format') . ' ' . get_option('time_format');
        }
        
        return mysql2date($format, $this->start_time);
    }
    
    /**
     * Get time spent on form in minutes
     *
     * @return float Time spent in minutes
     */
    public function get_time_spent() {
        if (empty($this->start_time) || empty($this->last_activity)) {
            return 0;
        }
        
        $start = strtotime($this->start_time);
        $end = strtotime($this->last_activity);
        
        return round(($end - $start) / 60, 2);
    }
    
    /**
     * Mark as converted
     *
     * @return bool Success
     */
    public function mark_as_converted() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update($table_name,['is_converted' => 1],['id' => $this->id],['%d'],['%d']);
        
        if ($result !== false) {
            $this->is_converted = true;
            return true;
        }
        
        return false;
    }
    
    /**
     * Delete abandoned form record
     *
     * @return bool Success
     */
    public function delete() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->delete($table_name,['id' => $this->id],['%d']);
        
        return $result !== false;
    }
    
    /**
     * Get filled fields count
     *
     * @return int Number of filled fields
     */
    public function get_filled_fields_count() {
        $count = 0;
        
        foreach ($this->field_values as $value) {
            if (!empty($value) && $value !== '') {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Get formatted last activity time
     *
     * @param string $format Date format
     * @return string Formatted date
     */
    public function get_formatted_last_activity($format = '') {
        if (empty($format)) {
            $format = get_option('date_format') . ' ' . get_option('time_format');
        }
        
        return mysql2date($format, $this->last_activity);
    }
    
    /**
     * Get IP address
     *
     * @return string IP address
     */
    public function get_ip_address() {
        return $this->user_ip;
    }
    
    /**
     * Get user agent
     *
     * @return string User agent
     */
    public function get_user_agent() {
        return $this->user_agent;
    }
    
    /**
     * Get form title with deleted form handling
     *
     * @return string Form title or "Deleted Form - [ID]"
     */
    public function get_form_title() {
        if ($this->form_title !== null && $this->form_title !== '') {
            return $this->form_title;
        }
        
        // Form was deleted, show a friendly message
        /* translators: %d is the form ID */
        return sprintf(__('Deleted Form - #%d', 'sigmaforms-pro'), $this->form_id);
    }
} 