<?php
/**
 * Forms Manager for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Forms;

use SigmaForms\Utils\Helper;

class FormsManager {
    /**
     * Register REST API routes
     *
     * @return void
     */
    public function register_rest_routes() {
        // Get all forms
        register_rest_route('sigmaforms/v1', '/forms', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_forms'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Get single form
        register_rest_route('sigmaforms/v1', '/forms/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_form'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Create form
        register_rest_route('sigmaforms/v1', '/forms', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_create_form'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Update form
        register_rest_route('sigmaforms/v1', '/forms/(?P<id>\d+)', [
            'methods' => 'PUT',
            'callback' => [$this, 'rest_update_form'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Delete form
        register_rest_route('sigmaforms/v1', '/forms/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$this, 'rest_delete_form'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Get form submissions
        register_rest_route('sigmaforms/v1', '/forms/(?P<id>\d+)/submissions', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_submissions'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
        
        // Submit form frontend (public, no permissions needed)
        register_rest_route('sigmaforms/v1', '/submit/(?P<id>\d+)', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_submit_form'],
            'permission_callback' => '__return_true',
        ]);
    }
    
    /**
     * REST API endpoint to get all forms
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response
     */
    public function rest_get_forms($request) {
        $forms = $this->get_forms();
        
        return rest_ensure_response([
            'success' => true,
            'forms' => $forms,
        ]);
    }
    
    /**
     * REST API endpoint to get a single form
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_get_form($request) {
        $form_id = (int) $request->get_param('id');
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $form = $this->get_form($form_id);
        
        if (!$form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'), ['status' => 404]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'form' => $form,
        ]);
    }
    
    /**
     * Drop settings only administrators may change from a form save.
     *
     * Form editing can be delegated (sigmaforms_manage_forms_capability), but
     * webhook URLs make the server send requests anywhere. Without these keys,
     * an update keeps the stored values and a new form gets the disabled
     * defaults. Used by the AJAX save and the REST create/update routes.
     *
     * @param array $form_data Form data from the request.
     * @return array
     */
    public static function strip_restricted_settings($form_data) {
        if (current_user_can('manage_options') || empty($form_data['settings']) || !is_array($form_data['settings'])) {
            return $form_data;
        }

        foreach (array_keys($form_data['settings']) as $setting_key) {
            if (strpos((string) $setting_key, 'webhook_') === 0) {
                unset($form_data['settings'][$setting_key]);
            }
        }

        return $form_data;
    }

    /**
     * REST API endpoint to create a form
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_create_form($request) {
        $form_data = $request->get_json_params();
        
        if (!is_array($form_data)) {
            return new \WP_Error('invalid_data', __('Invalid form data.', 'sigmaforms-pro'), ['status' => 400]);
        }

        $form_data = self::strip_restricted_settings($form_data);
        
        $form_id = $this->create_form($form_data);
        
        if (is_wp_error($form_id)) {
            return $form_id;
        }
        
        return rest_ensure_response([
            'success' => true,
            'form_id' => $form_id,
            'message' => __('Form created successfully.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * REST API endpoint to update a form
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_update_form($request) {
        $form_id = (int) $request->get_param('id');
        $form_data = $request->get_json_params();
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        if (!is_array($form_data)) {
            return new \WP_Error('invalid_data', __('Invalid form data.', 'sigmaforms-pro'), ['status' => 400]);
        }

        $form_data = self::strip_restricted_settings($form_data);
        
        $result = $this->update_form($form_id, $form_data);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => __('Form updated successfully.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * REST API endpoint to delete a form
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_delete_form($request) {
        $form_id = (int) $request->get_param('id');
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $result = $this->delete_form($form_id);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => __('Form deleted successfully.', 'sigmaforms-pro'),
        ]);
    }
    
    /**
     * REST API endpoint to get form submissions
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_get_submissions($request) {
        $form_id = (int) $request->get_param('id');
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        $page = (int) $request->get_param('page') ?: 1;
        $per_page = (int) $request->get_param('per_page') ?: 10;
        
        $submissions = $this->get_submissions($form_id, $page, $per_page);
        $total = $this->get_submissions_count($form_id);
        
        return rest_ensure_response([
            'success' => true,
            'submissions' => $submissions,
            'total' => $total,
            'pages' => ceil($total / $per_page),
        ]);
    }
    
    /**
     * Message explaining why a scheduled form is closed, or '' when it is open.
     *
     * Shared by the AJAX and REST submission paths so both honour the schedule.
     *
     * @param array $form_settings Form settings.
     * @return string
     */
    public static function get_schedule_error($form_settings) {
        if (empty($form_settings['enable_scheduling'])) {
            return '';
        }

        // Stored as datetime-local values (Y-m-d\TH:i) in the site timezone.
        $now = current_time('mysql');

        if (!empty($form_settings['schedule_start'])) {
            $start = str_replace('T', ' ', $form_settings['schedule_start']) . ':00';
            if ($now < $start) {
                return __('This form is not yet available. Please try again later.', 'sigmaforms-pro');
            }
        }

        if (!empty($form_settings['schedule_end'])) {
            $end = str_replace('T', ' ', $form_settings['schedule_end']) . ':00';
            if ($now > $end) {
                return __('This form is no longer accepting submissions.', 'sigmaforms-pro');
            }
        }

        return '';
    }

    /**
     * Keep only the values of fields defined on the form, sanitized per type.
     *
     * The REST route used to store every request parameter as-is. It cannot
     * receive uploads, so file values are dropped (as the AJAX path does for
     * values that did not arrive as a real upload), and signatures must be a
     * plain png/jpeg data URI.
     *
     * @param array $form   Form data from get_form().
     * @param array $params Request parameters.
     * @return array
     */
    private function sanitize_rest_submission($form, $params) {
        $clean = [];

        foreach ((array) $form['form_fields'] as $field_data) {
            if (empty($field_data['id']) || empty($field_data['type'])) {
                continue;
            }

            $type = $field_data['type'];
            $id = $field_data['id'];

            if (in_array($type, ['section_heading', 'page_break', 'file'], true)) {
                continue;
            }

            $value = isset($params[$id]) ? $params[$id] : '';

            if ($type === 'signature') {
                $clean[$id] = \SigmaForms\Utils\Helper::is_safe_image_data_uri($value) ? $value : '';
                continue;
            }

            if (is_array($value) || is_object($value)) {
                $value = array_map('strval', array_filter((array) $value, 'is_scalar'));
            } elseif (!is_scalar($value)) {
                $value = '';
            }

            $clean[$id] = (new FormField($field_data))->sanitize($value);
        }

        return $clean;
    }

    /**
     * REST API endpoint to submit a form (frontend)
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_submit_form($request) {
        $form_id = (int) $request->get_param('id');
        $form_data = $request->get_params();
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        // Verify nonce
        if (!isset($form_data['_wpnonce']) || !wp_verify_nonce($form_data['_wpnonce'], 'sf_submit_form_' . $form_id)) {
            return new \WP_Error('invalid_nonce', __('Security check failed.', 'sigmaforms-pro'), ['status' => 400]);
        }
        
        // Check configured CAPTCHA
        $form = $this->get_form($form_id);
        
        if (!$form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'), ['status' => 404]);
        }
        
        $schedule_error = self::get_schedule_error(isset($form['form_settings']) ? $form['form_settings'] : []);
        if ($schedule_error !== '') {
            return new \WP_Error('form_closed', $schedule_error, ['status' => 403]);
        }

        $captcha_result = \SigmaForms\Utils\CaptchaHandler::validate_captcha($form['form_settings'], $form_data);
        if (!$captcha_result['valid']) {
            return new \WP_Error(
                'captcha_failed',
                $captcha_result['message'],
                ['status' => 400]
            );
        }
        
        // Remove WordPress specific fields
        unset($form_data['_wpnonce']);
        unset($form_data['_wp_http_referer']);
        $captcha_field_name = \SigmaForms\Utils\CaptchaHandler::get_captcha_field_name($form['form_settings']);
        if (!empty($captcha_field_name)) {
            unset($form_data[$captcha_field_name]);
        }
        
        $session_id = isset($form_data['session_id']) ? sanitize_text_field((string) $form_data['session_id']) : '';
        $form_data = $this->sanitize_rest_submission($form, $form_data);

        // Validate submission
        $validation_result = $this->validate_submission($form_id, $form_data);
        
        if (is_wp_error($validation_result)) {
            return $validation_result;
        }
        
        // Process submission
        $submission_id = $this->process_submission($form_id, $form_data);
        
        if (is_wp_error($submission_id)) {
            return $submission_id;
        }
        
        // Mark any abandoned form as converted if session ID is provided
        if ($session_id !== '') {
            $this->mark_abandoned_as_converted($form_id, $session_id);
        }
        
        // Apply action hook for after submission
        do_action('sigmaforms_after_submit', $form_id, $form_data, $submission_id);
        
        return rest_ensure_response([
            'success' => true,
            'message' => isset($form['form_settings']['success_message']) && $form['form_settings']['success_message'] !== ''
                ? $form['form_settings']['success_message']
                : __('Thank you for your submission!', 'sigmaforms-pro'),
            'submission_id' => $submission_id,
        ]);
    }
    
    /**
     * Get all forms
     *
     * @return array List of forms
     */
    public function get_forms() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms';
        $formsGetQuery = "SELECT id, title, date_created, date_modified, status FROM {$table} WHERE status = 'publish' ORDER BY date_modified DESC";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $forms = $wpdb->get_results($formsGetQuery,ARRAY_A);
        
        return $forms ?: [];
    }
    
    /**
     * Get a specific form
     *
     * @param int $form_id Form ID
     * @return array|false Form data or false if not found
     */
    public function get_form($form_id) {
        global $wpdb;
        
        $form_id = (int) $form_id;
        
        if ($form_id <= 0) {
            return false;
        }
        
        $table = $wpdb->prefix . 'sigmaforms';
        $formGetQuery = "SELECT * FROM {$table} WHERE id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $form = $wpdb->get_row($wpdb->prepare($formGetQuery, $form_id),ARRAY_A);
        
        if (!$form) {
            return false;
        }
        
        // Decode JSON fields
        $form['form_fields'] = json_decode($form['form_fields'], true) ?: [];
        $form['form_settings'] = json_decode($form['form_settings'], true) ?: [];
        
        return $form;
    }
    
    /**
     * Create a new form
     *
     * @param array $form_data Form data
     * @return int|\WP_Error New form ID or error
     */
    public function create_form($form_data) {
        global $wpdb;
        
        // Enforce free limit when license is not valid: allow up to 5 forms total
        if (!\SigmaForms\Plugin::is_license_valid() && !\SigmaForms\Plugin::can_create_more_forms()) {
            $form_limit = 5;
            $license_url = admin_url('admin.php?page=sigmaforms_license');
            return new \WP_Error(
                'license_limit_reached',
                sprintf(
                    /* translators: 1: number of forms allowed, 2: license activation URL */
                    __( 'You\'ve reached the free limit of %1$d forms. Please <a href="%2$s" target="_blank">activate your license</a> to create more.', 'sigmaforms-pro' ),
                    $form_limit,
                    esc_url( $license_url )
                )
            );
        }
        
        $title = isset($form_data['title']) ? sanitize_text_field($form_data['title']) : __('New Form', 'sigmaforms-pro');
        $fields = isset($form_data['fields']) ? Helper::sanitize_form_fields($form_data['fields']) : [];
        
        // Merge settings with defaults to ensure all required fields are present
        $default_settings = Helper::get_default_form_settings();
        $new_settings = isset($form_data['settings']) ? $form_data['settings'] : [];
        
        
        // Merge settings: new settings override defaults (correct order)
        $settings = array_merge($default_settings, $new_settings);
        $settings = Helper::sanitize_form_settings($settings);
        
        $table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->insert($table,['title' => $title,'form_fields' => wp_json_encode($fields),'form_settings' => wp_json_encode($settings),'date_created' => current_time('mysql'),'date_modified' => current_time('mysql'),'status' => 'publish',],['%s','%s','%s','%s','%s','%s',]);
        
        if ($result === false) {
            return new \WP_Error('db_error', __('Failed to create form.', 'sigmaforms-pro'));
        }
        
        $form_id = $wpdb->insert_id;
        
        // Apply filter for after form creation
        do_action('sigmaforms_created', $form_id, $form_data);

        return $form_id;
    }
    
    /**
     * Update an existing form
     *
     * @param int $form_id Form ID
     * @param array $form_data Form data
     * @return bool|\WP_Error True on success or error
     */
    public function update_form($form_id, $form_data) {
        global $wpdb;
        
        $form_id = (int) $form_id;
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'));
        }
        
        $existing_form = $this->get_form($form_id);
        
        if (!$existing_form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'));
        }
        
        $title = isset($form_data['title']) ? sanitize_text_field($form_data['title']) : $existing_form['title'];
        $fields = isset($form_data['fields']) ? Helper::sanitize_form_fields($form_data['fields']) : $existing_form['form_fields'];
        
        // Merge settings with defaults to ensure all required fields are present
        $default_settings = Helper::get_default_form_settings();
        $new_settings = isset($form_data['settings']) ? $form_data['settings'] : [];
        $existing_settings = $existing_form['form_settings'];
        
        
        // Merge settings: new settings override existing, defaults fill in missing
        $settings = array_merge($default_settings, $existing_settings, $new_settings);
        $settings = Helper::sanitize_form_settings($settings);
        
        $table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update($table,['title' => $title,'form_fields' => wp_json_encode($fields),'form_settings' => wp_json_encode($settings),'date_modified' => current_time('mysql'),],['id' => $form_id],['%s','%s','%s','%s',],['%d']);
        
        if ($result === false) {

            return new \WP_Error('db_error', __('Failed to update form.', 'sigmaforms-pro'));
        }
        
        // Apply filter for after form update
        do_action('sigmaforms_updated', $form_id, $form_data);
        
        return true;
    }
    
    /**
     * Delete a form
     *
     * @param int $form_id Form ID
     * @return bool|\WP_Error True on success or error
     */
    public function delete_form($form_id) {
        global $wpdb;
        
        $form_id = (int) $form_id;
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'));
        }
        
        $table = $wpdb->prefix . 'sigmaforms';
        
        // First check if the form exists and get its title
        $formGetQuery = "SELECT id, title FROM {$table} WHERE id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $form = $wpdb->get_row($wpdb->prepare($formGetQuery, $form_id));
        
        if (!$form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'));
        }
        
        // Store original title before deletion
        $original_title = $form->title;
        
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->delete($table,['id' => $form_id],['%d']);
        
        if ($result === false) {
            return new \WP_Error('db_error', __('Failed to delete form.', 'sigmaforms-pro'));
        }
        
        // Apply action hook for form deletion - pass both form_id and original_title
        do_action('sigmaforms_deleted', $form_id, $original_title);

        return true;
    }
    
    /**
     * Duplicate a form
     *
     * @param int $form_id Form ID to duplicate
     * @return int|\WP_Error New form ID or error
     */
    public function duplicate_form($form_id) {
        global $wpdb;
        
        $form_id = (int) $form_id;
        
        if ($form_id <= 0) {
            return new \WP_Error('invalid_id', __('Invalid form ID.', 'sigmaforms-pro'));
        }
        
        // Get the original form
        $original_form = $this->get_form($form_id);
        
        if (!$original_form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'));
        }
        
        // Enforce free limit when license is not valid
        if (!\SigmaForms\Plugin::is_license_valid() && !\SigmaForms\Plugin::can_create_more_forms()) {
            $form_limit = 5;
            $license_url = admin_url('admin.php?page=sigmaforms_license');
            return new \WP_Error(
                'license_limit_reached',
                sprintf(
                    /* translators: 1: number of forms allowed, 2: license activation URL */
                    __( 'You\'ve reached the free limit of %1$d forms. Please <a href="%2$s" target="_blank">activate your license</a> to create more.', 'sigmaforms-pro' ),
                    $form_limit,
                    esc_url( $license_url )
                )
            );
        }
        
        // Create new form with duplicated data
        $new_title = $original_form['title'] . ' ' . __('(Copy)', 'sigmaforms-pro');
        
        $table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->insert(
            $table,
            [
                'title' => $new_title,
                'form_fields' => wp_json_encode($original_form['form_fields']), // Re-encode array to JSON
                'form_settings' => wp_json_encode($original_form['form_settings']), // Re-encode array to JSON
                'date_created' => current_time('mysql'),
                'date_modified' => current_time('mysql'),
                'status' => 'publish',
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            return new \WP_Error('db_error', __('Failed to duplicate form.', 'sigmaforms-pro'));
        }
        
        $new_form_id = $wpdb->insert_id;
        
        // Apply action hook for form duplication
        do_action('sigmaforms_duplicated', $new_form_id, $form_id);
        
        return $new_form_id;
    }
    
    /**
     * Get form submissions
     *
     * @param int $form_id Form ID
     * @param int $page Page number
     * @param int $per_page Items per page
     * @return array List of submissions
     */
    public function get_submissions($form_id, $page = 1, $per_page = 10) {
        global $wpdb;
        
        $form_id = (int) $form_id;
        $page = max(1, (int) $page);
        $per_page = max(1, (int) $per_page);
        $offset = ($page - 1) * $per_page;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        $submissionsGetQuery = "SELECT * FROM {$table} WHERE form_id = %d ORDER BY date_created DESC LIMIT %d OFFSET %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $submissions = $wpdb->get_results($wpdb->prepare($submissionsGetQuery,$form_id,$per_page,$offset),ARRAY_A);
        
        if (!$submissions) {
            return [];
        }
        
        // Decode field values
        foreach ($submissions as &$submission) {
            $submission['field_values'] = json_decode($submission['field_values'], true) ?: [];
        }
        
        return $submissions;
    }
    
    /**
     * Get total submissions count for a form
     *
     * @param int $form_id Form ID
     * @return int Total submissions
     */
    public function get_submissions_count($form_id) {
        global $wpdb;
        
        $form_id = (int) $form_id;
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        $formCountGetQuery = "SELECT COUNT(*) FROM {$table} WHERE form_id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        return (int) $wpdb->get_var($wpdb->prepare($formCountGetQuery, $form_id));
    }
    
    /**
     * Validate form submission
     *
     * @param int $form_id Form ID
     * @param array $submission_data Submission data
     * @return true|\WP_Error True if valid or error
     */
    private function validate_submission($form_id, $submission_data) {
        $form = $this->get_form($form_id);
        
        if (!$form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'));
        }
        
        $fields = $form['form_fields'];
        $validation_errors = [];
        
        foreach ($fields as $field) {
            // Skip if field has conditional logic and is not shown
            if (!empty($field['conditional']) && isset($field['conditional']['show']) && isset($field['conditional']['field']) && isset($field['conditional']['operator']) && isset($field['conditional']['value'])) {
                $show = $field['conditional']['show'];
                $dependent_field = $field['conditional']['field'];
                $operator = $field['conditional']['operator'];
                $expected_value = $field['conditional']['value'];
                $actual_value = isset($submission_data[$dependent_field]) ? $submission_data[$dependent_field] : '';
                
                $should_show = false;
                
                switch ($operator) {
                    case '=':
                        $should_show = ($actual_value == $expected_value);
                        break;
                    case '!=':
                        $should_show = ($actual_value != $expected_value);
                        break;
                    case '>':
                        $should_show = ($actual_value > $expected_value);
                        break;
                    case '<':
                        $should_show = ($actual_value < $expected_value);
                        break;
                    case 'contains':
                        $should_show = (strpos($actual_value, $expected_value) !== false);
                        break;
                }
                
                if ($show !== $should_show) {
                    continue;
                }
            }
            
            $field_id = $field['id'];
            $field_value = isset($submission_data[$field_id]) ? $submission_data[$field_id] : '';
            
            $validation = Helper::validate_field($field_value, $field);
            
            if (!$validation['valid']) {
                $validation_errors[] = $validation['message'];
            }
        }
        
        if (!empty($validation_errors)) {
            return new \WP_Error(
                'validation_failed',
                __('Validation failed.', 'sigmaforms-pro'),
                ['errors' => $validation_errors]
            );
        }
        
        return true;
    }
    
    /**
     * Process form submission
     *
     * @param int $form_id Form ID
     * @param array $submission_data Submission data
     * @return int|\WP_Error Submission ID or error
     */
    private function process_submission($form_id, $submission_data) {
        $form = $this->get_form($form_id);
        
        if (!$form) {
            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'));
        }
        
        // Store submission in database if enabled
        $submission_id = 0;
        
        if (isset($form['form_settings']['store_submissions']) && $form['form_settings']['store_submissions']) {
            $submission_id = $this->store_submission($form_id, $submission_data);
            
            if (is_wp_error($submission_id)) {
                return $submission_id;
            }
        }
        
        // Send email notification
        $email_result = $this->send_email_notification($form, $submission_data);
        
        // Sent after the response; queue() checks the license like the AJAX path.
        \SigmaForms\Utils\WebhookHandler::queue($form_id, $submission_data, $form);
        
        return $submission_id;
    }
    
    /**
     * Store submission in database
     *
     * @param int $form_id Form ID
     * @param array $submission_data Submission data
     * @return int|\WP_Error Submission ID or error
     */
    private function store_submission($form_id, $submission_data) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->insert($table,['form_id' => $form_id,'field_values' => wp_json_encode($submission_data),'user_id' => is_user_logged_in() ? get_current_user_id() : 0,'user_ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '','user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '','date_created' => current_time('mysql'),'status' => 'unread',],['%d','%s','%d','%s','%s','%s','%s',]);
        
        if ($result === false) {
            return new \WP_Error('db_error', __('Failed to store submission.', 'sigmaforms-pro'));
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Send email notification
     *
     * @param array $form Form data
     * @param array $submission_data Submission data
     * @return bool True if email sent successfully
     */
    private function send_email_notification($form, $submission_data) {
        $settings = $form['form_settings'];
        
        // Check if email override is enabled
        $override_email_settings = !empty($settings['override_email_settings']);
        
        // Get email settings - use form settings if override is enabled, otherwise use defaults
        if ($override_email_settings) {
            $to_email = $settings['to_email'] ?? '';
            $cc_email = $settings['cc_email'] ?? get_option('sf_admin_email_cc', '');
            $bcc_email = $settings['bcc_email'] ?? get_option('sf_admin_email_bcc', '');
        } else {
            $to_email = get_option('sf_admin_email', get_option('admin_email'));
            $cc_email = get_option('sf_admin_email_cc', '');
            $bcc_email = get_option('sf_admin_email_bcc', '');
        }
        $to_email = Helper::sanitize_email_list($to_email);
        $cc_email = Helper::sanitize_email_list($cc_email);
        $bcc_email = Helper::sanitize_email_list($bcc_email);
        // translators: %s is the blog name.
        $email_subject = $override_email_settings ? ($settings['email_subject'] ?? '') : get_option('sf_default_email_subject', sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name')));
        $email_message = $override_email_settings ? ($settings['email_message'] ?? '') : get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro'));

        // Confirmation email settings - should work independently of override toggle
        $send_confirmation_email = !empty($settings['send_confirmation_email']);
        
        // Get confirmation subject - use form setting if not empty, otherwise use default
        $confirmation_subject = '';
        if (isset($settings['confirmation_subject']) && trim($settings['confirmation_subject']) !== '') {
            $confirmation_subject = $settings['confirmation_subject'];
        } else {
            $confirmation_subject = get_option('sf_default_confirmation_subject', __('Thank you for your submission', 'sigmaforms-pro'));
        }
        
        // Get confirmation message - use form setting if not empty, otherwise use default
        $confirmation_message = '';
        if (isset($settings['confirmation_message']) && trim($settings['confirmation_message']) !== '') {
            $confirmation_message = $settings['confirmation_message'];
        } else {
            $confirmation_message = get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro'));
        }

        if (empty($to_email)) {
            
            return false;
        }
        
        // Get SMTP configuration
        $smtp_config = get_option('sf_smtp_config', []);
        
        // Determine from email and name
        $from_email = Helper::get_email_from_address($smtp_config);
        $from_name = Helper::get_email_from_name();
        
        // Replace placeholders in subject and message
        $form_fields = isset($form['form_fields']) ? $form['form_fields'] : [];
        $subject = Helper::replace_placeholders($email_subject, $submission_data, $form_fields);
        $message = Helper::replace_placeholders($email_message, $submission_data, $form_fields);
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];
        // Replying to the notification answers the person who submitted the form.
        $headers = array_merge($headers, Helper::get_email_reply_to_header(Helper::find_submitter_email($submission_data, $form_fields)));
        $headers = array_merge($headers, Helper::get_email_cc_bcc_headers($cc_email, $bcc_email));
        
        $result = wp_mail($to_email, $subject, nl2br($message), $headers);
        
        // Send confirmation email if enabled
        if ($send_confirmation_email) {
            $this->send_confirmation_email($form, $submission_data, $from_email, $from_name, $confirmation_subject, $confirmation_message);
        }
        
        // Apply action hook for email sent
        do_action('sigmaforms_email_sent', $form['id'], $submission_data, $result);

        return $result;
    }
    
    /**
     * Send confirmation email to user
     *
     * @param array $form Form data
     * @param array $submission_data Submission data
     * @param string $from_email From email address
     * @param string $from_name From name
     * @param string $confirmation_subject Confirmation subject
     * @param string $confirmation_message Confirmation message
     * @return bool True if email sent successfully
     */
    private function send_confirmation_email($form, $submission_data, $from_email, $from_name, $confirmation_subject, $confirmation_message) {
        $settings = $form['form_settings'];
        
        // Find user email from submission data
        $user_email = '';
        foreach ($submission_data as $field_id => $value) {
            if (strpos($field_id, 'email') !== false || strpos($field_id, 'Email') !== false) {
                $user_email = sanitize_email($value);
                break;
            }
        }
        
        if (empty($user_email)) {
            return false;
        }
        
        // Replace placeholders in confirmation subject and message
        $form_fields = isset($form['form_fields']) ? $form['form_fields'] : [];
        $subject = Helper::replace_placeholders($confirmation_subject, $submission_data, $form_fields);
        $message = Helper::replace_placeholders($confirmation_message, $submission_data, $form_fields);
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];
        
        // Replies from the visitor go to the site, not to the sending address.
        $headers = array_merge($headers, Helper::get_email_reply_to_header(Helper::get_site_contact_email()));

        $result = wp_mail($user_email, $subject, nl2br($message), $headers);
        
        // Apply action hook for confirmation email sent
        do_action('sigmaforms_confirmation_email_sent', $form['id'], $submission_data, $result);

        return $result;
    }
    
    /**
     * Clean up old submissions
     *
     * @param int $days Number of days to keep submissions
     * @return int Number of submissions deleted
     */
    public function cleanup_old_submissions($days = 90) {
        global $wpdb;
        
        $days = (int) $days;
        
        if ($days <= 0) {
            return 0;
        }
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        $date = gmdate('Y-m-d H:i:s', strtotime("-{$days} days"));
        $deleteTableGetQuery = "DELETE FROM {$table} WHERE date_created < %s";              
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->query($wpdb->prepare($deleteTableGetQuery, $date));        
        return $result;
    }
    
    /**
     * Mark any abandoned form as converted if session ID is provided
     *
     * @param int $form_id Form ID
     * @param string $session_id Session ID
     * @return void
     */
    private function mark_abandoned_as_converted($form_id, $session_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_abandoned_forms';
        
        // Update any abandoned form entry for this session and form
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update($table_name,['is_converted' => 1],['session_id' => $session_id,'form_id' => $form_id,],['%d'],['%s', '%d']);
    }

    /**
     * Delete uploaded files from a submission
     *
     * @param int $submission_id Submission ID
     * @return void
     */
    private function delete_submission_files($submission_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Get submission data
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the ID is prepared with %d.
        $submission = $wpdb->get_row($wpdb->prepare("SELECT field_values, form_id FROM {$table} WHERE id = %d", $submission_id), ARRAY_A);
        
        if (!$submission) {
            return;
        }
        
        // Decode field values
        $field_values = json_decode($submission['field_values'], true);
        if (!is_array($field_values)) {
            return;
        }
        
        // Get form fields to identify file/signature fields
        $forms_table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the ID is prepared with %d.
        $form = $wpdb->get_row($wpdb->prepare("SELECT form_fields FROM {$forms_table} WHERE id = %d", $submission['form_id']), ARRAY_A);
        
        if (!$form) {
            return;
        }
        
        $form_fields = json_decode($form['form_fields'], true);
        if (!is_array($form_fields)) {
            return;
        }
        
        // Find file and signature fields that use site storage
        foreach ($form_fields as $field) {
            if (!isset($field['id']) || !isset($field['type'])) {
                continue;
            }
            
            // Check if it's a file or signature field with site storage
            if (in_array($field['type'], ['file', 'signature'])) {
                $storage_location = isset($field['storage_location']) ? $field['storage_location'] : 'site';
                
                // Only delete if storage is 'site' (not cloud storage)
                if ($storage_location === 'site' && isset($field_values[$field['id']])) {
                    $file_url = $field_values[$field['id']];
                    
                    // Handle array of files (multiple file uploads)
                    if (is_array($file_url)) {
                        $file_urls = $file_url;
                    } elseif (is_string($file_url) && strpos($file_url, ',') !== false) {
                        // Handle comma-separated URLs from multiple file uploads
                        $file_urls = array_map('trim', explode(',', $file_url));
                    } else {
                        $file_urls = [$file_url];
                    }
                    
                    foreach ($file_urls as $url) {
                        if (empty($url) || !is_string($url)) {
                            continue;
                        }

                        // The stored value came from a public submission, so never
                        // build a path from it directly. resolve_managed_upload_path()
                        // returns false unless the URL canonicalises to a real file
                        // inside wp-content/uploads.
                        $file_path = \SigmaForms\Utils\Helper::resolve_managed_upload_path($url);

                        if (false !== $file_path) {
                            wp_delete_file($file_path);
                        }
                    }
                }
            }
        }
    }

    /**
     * Bulk delete submissions
     *
     * @param array $submission_ids Array of submission IDs to delete
     * @return int Number of submissions deleted
     */
    public function bulk_delete_submissions($submission_ids) {
        if (empty($submission_ids) || !is_array($submission_ids)) {
            return 0;
        }

        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Sanitize submission IDs
        $submission_ids = array_map('intval', $submission_ids);
        $submission_ids = array_filter($submission_ids, function($id) { return $id > 0; });
        
        if (empty($submission_ids)) {
            return 0;
        }

        // Delete files for each submission before deleting the submission record
        foreach ($submission_ids as $submission_id) {
            $this->delete_submission_files($submission_id);
        }

        $placeholders = implode(',', array_fill(0, count($submission_ids), '%d'));
        $query = "DELETE FROM {$table} WHERE id IN ({$placeholders})";
        
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->query($wpdb->prepare($query, ...$submission_ids));
        
        return $result !== false ? $result : 0;
    }

    /**
     * Bulk mark submissions as read
     *
     * @param array $submission_ids Array of submission IDs to mark as read
     * @return int Number of submissions updated
     */
    public function bulk_mark_submissions_as_read($submission_ids) {
        if (empty($submission_ids) || !is_array($submission_ids)) {
            return 0;
        }

        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Sanitize submission IDs
        $submission_ids = array_map('intval', $submission_ids);
        $submission_ids = array_filter($submission_ids, function($id) { return $id > 0; });
        
        if (empty($submission_ids)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($submission_ids), '%d'));
        $query = "UPDATE {$table} SET status = 'read' WHERE id IN ({$placeholders})";
        
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->query($wpdb->prepare($query, ...$submission_ids));
        
        return $result !== false ? $result : 0;
    }

    /**
     * Bulk mark submissions as unread
     *
     * @param array $submission_ids Array of submission IDs to mark as unread
     * @return int Number of submissions updated
     */
    public function bulk_mark_submissions_as_unread($submission_ids) {
        if (empty($submission_ids) || !is_array($submission_ids)) {
            return 0;
        }

        global $wpdb;
        
        $table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Sanitize submission IDs
        $submission_ids = array_map('intval', $submission_ids);
        $submission_ids = array_filter($submission_ids, function($id) { return $id > 0; });
        
        if (empty($submission_ids)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($submission_ids), '%d'));
        $query = "UPDATE {$table} SET status = 'unread' WHERE id IN ({$placeholders})";
        
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->query($wpdb->prepare($query, ...$submission_ids));
        
        return $result !== false ? $result : 0;
    }
}
