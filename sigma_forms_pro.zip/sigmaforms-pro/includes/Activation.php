<?php

/**
 * Activation class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms;

class Activation {
    /**
     * Run activation tasks
     *
     * @return void
     */
    public static function activate() {
        // Create database tables
        self::create_tables();

        // Run migrations for existing installations
        self::run_migrations();

        // Set default options
        self::set_default_options();
        // Set flag to show license activation notice
        add_option('sigmaforms_show_license_notice', true);

        // Set redirect flag for license page
        add_option('sigmaforms_activation_redirect', true);
        // Flush rewrite rules
        flush_rewrite_rules();

        $upload_dir = wp_upload_dir();
        if (!empty($upload_dir['basedir'])) {
            \SigmaForms\Utils\Helper::ensure_sigmaforms_upload_hardening($upload_dir['basedir'] . '/sigmaforms');
        }
    }

    

    /**
     * Create required database tables
     *
     * @return void
     */
    private static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Forms table
        $table_forms = $wpdb->prefix . 'sigmaforms';
        $table_views = $wpdb->prefix . 'sigmaforms_views';
        $table_referrers = $wpdb->prefix . 'sigmaforms_referrers';

        $sql = "CREATE TABLE $table_forms (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            form_fields longtext NOT NULL,
            form_settings longtext NOT NULL,
            date_created datetime NOT NULL,
            date_modified datetime NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'publish',
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // Submissions table
        $table_submissions = $wpdb->prefix . 'sigmaforms_submissions';

        $sql .= "CREATE TABLE $table_submissions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            form_id bigint(20) NOT NULL,
            field_values longtext NOT NULL,
            user_id bigint(20),
            user_ip varchar(100),
            user_agent text,
            date_created datetime NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'unread',
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY status (status),
            KEY date_created (date_created)
        ) $charset_collate;";

        // Abandoned forms table
        $table_abandoned = $wpdb->prefix . 'sigmaforms_abandoned_forms';

        $sql .= "CREATE TABLE $table_abandoned (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            form_id bigint(20) NOT NULL,
            session_id varchar(255) NOT NULL,
            field_values longtext NOT NULL,
            user_id bigint(20),
            user_ip varchar(100),
            user_agent text,
            start_time datetime NOT NULL,
            last_activity datetime NOT NULL,
            abandonment_type varchar(50) NOT NULL DEFAULT 'timeout',
            is_converted tinyint(1) NOT NULL DEFAULT 0,
            completion_percentage decimal(5,2) NOT NULL DEFAULT 0.00,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY session_id (session_id),
            KEY is_converted (is_converted)
        ) $charset_collate;";

        // Views table
        $table_views = $wpdb->prefix . 'sigmaforms_views';
        $sql .= "CREATE TABLE $table_views (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            form_id bigint(20) NOT NULL,
            page_url text,
            referrer_url text,
            user_ip varchar(100),
            user_agent text,
            date_created datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY date_created (date_created)
        ) $charset_collate;";

        // Referrers table (submissions context)
        $table_referrers = $wpdb->prefix . 'sigmaforms_referrers';
        $sql .= "CREATE TABLE $table_referrers (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            form_id bigint(20) NOT NULL,
            submission_id bigint(20) DEFAULT 0,
            page_url text,
            referrer_url text,
            date_created datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY submission_id (submission_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Run database migrations for existing installations
     *
     * @return void
     */
    private static function run_migrations() {
        global $wpdb;

        $table_forms = $wpdb->prefix . 'sigmaforms';
        // These were previously undefined here, which made the "does the table
        // already exist" checks below always fail.
        $table_views = $wpdb->prefix . 'sigmaforms_views';
        $table_referrers = $wpdb->prefix . 'sigmaforms_referrers';

        // Migrate option prefix from saigf_ to sf_
        self::migrate_option_prefix();

        // Check if description column exists and remove it
        $columnExistsQuery = "SHOW COLUMNS FROM {$table_forms} LIKE 'description'";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $column_exists = $wpdb->get_results($columnExistsQuery);
        $columnAlterQuery = "ALTER TABLE {$table_forms} DROP COLUMN description";
        if (!empty($column_exists)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $wpdb->query($columnAlterQuery);
        }

        // Ensure new tables exist for existing installs
        $charset_collate = $wpdb->get_charset_collate();
        $sql = '';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time migration check during activation
        $viewsCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_views));
        if ($viewsCheck !== $table_views) {
            $sql .= "CREATE TABLE $table_views (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                form_id bigint(20) NOT NULL,
                page_url text,
                referrer_url text,
                user_ip varchar(100),
                user_agent text,
                date_created datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY form_id (form_id),
                KEY date_created (date_created)
            ) $charset_collate;";
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time migration check during activation
        $refCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_referrers));
        if ($refCheck !== $table_referrers) {
            $sql .= "CREATE TABLE $table_referrers (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                form_id bigint(20) NOT NULL,
                submission_id bigint(20) DEFAULT 0,
                page_url text,
                referrer_url text,
                date_created datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY form_id (form_id),
                KEY submission_id (submission_id)
            ) $charset_collate;";
        }
        if (!empty($sql)) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }

        self::maybe_add_analytics_indexes();
        self::maybe_add_submission_indexes();
    }

    /**
     * Add the date_created index to the analytics tables.
     *
     * The views table is written to on every form render, so on a busy site it
     * grows into the millions. Without this index both the analytics date-range
     * queries and the retention cleanup have to scan the whole table.
     *
     * Migrations otherwise only run on activation, so this is also called from
     * the daily maintenance task to reach installs that simply updated. It
     * guards on an option so the SHOW INDEX check does not run repeatedly.
     *
     * @return void
     */
    public static function maybe_add_analytics_indexes() {
        if (get_option('sf_analytics_date_index_added')) {
            return;
        }

        global $wpdb;

        $tables = [
            $wpdb->prefix . 'sigmaforms_views',
            $wpdb->prefix . 'sigmaforms_referrers',
        ];

        foreach ($tables as $table) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema migration
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
                continue;
            }

            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Table name is built from $wpdb->prefix and identifiers cannot be prepared.
            $has_index = $wpdb->get_results("SHOW INDEX FROM {$table} WHERE Key_name = 'date_created'");

            if (empty($has_index)) {
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Index added during activation/upgrade; table name is built from $wpdb->prefix and identifiers cannot be prepared.
                $wpdb->query("ALTER TABLE {$table} ADD INDEX date_created (date_created)");
            }
        }

        update_option('sf_analytics_date_index_added', 1, false);
    }

    /**
     * Index the submissions table on status and date.
     *
     * The unread counts (admin menu, Dashboard widget, Analytics), the recent
     * submissions lists and the date-range reports all filter or sort on these
     * columns, which scanned the whole table. Runs from activation and the
     * daily maintenance task, guarded by its own option.
     *
     * @return void
     */
    public static function maybe_add_submission_indexes() {
        if (get_option('sf_submission_indexes_added')) {
            return;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'sigmaforms_submissions';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time schema migration
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
            return;
        }

        $complete = true;

        foreach (['status', 'date_created'] as $column) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the column comes from the fixed list above.
            $has_index = $wpdb->get_results("SHOW INDEX FROM {$table} WHERE Key_name = '{$column}'");

            if (empty($has_index)) {
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter -- One-time index; identifiers cannot be prepared.
                if ($wpdb->query("ALTER TABLE {$table} ADD INDEX {$column} ({$column})") === false) {
                    $complete = false;
                }
            }
        }

        // A failed ALTER (lock timeout, missing privilege) is retried by the
        // next daily maintenance run.
        if ($complete) {
            update_option('sf_submission_indexes_added', 1, false);
        }
    }

    /**
     * Migrate option prefix from saigf_ to sf_
     * Runs during plugin activation to convert old prefix to new
     *
     * @return void
     */
    private static function migrate_option_prefix() {
        global $wpdb;

        // Check if migration has already been completed
        if (get_option('sf_prefix_migration_completed')) {
            return;
        }

        // Get all options with old prefix saigf_
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $old_options = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s",
                'saigf\_%'
            ),
            ARRAY_A
        );

        if (!empty($old_options)) {
            foreach ($old_options as $option) {
                $old_name = $option['option_name'];
                $new_name = str_replace('saigf_', 'sf_', $old_name);
                
                // Copy to new option name (only if it doesn't exist)
                if (get_option($new_name) === false) {
                    $success = add_option($new_name, maybe_unserialize($option['option_value']));
                    
                    // Delete old option only after successful migration
                    if ($success) {
                        delete_option($old_name);
                    }
                } else {
                    // New option already exists, safe to delete old one
                    delete_option($old_name);
                }
            }
        }

        // Mark migration as complete
        add_option('sf_prefix_migration_completed', true);
    }

    /**
     * Set default plugin options
     *
     * @return void
     */
    private static function set_default_options() {
        $default_options = [
            'api_key' => '',
            'admin_email' => get_option('admin_email'),
            'app_name' => get_bloginfo('name'),
            'form_styling' => [
                'button_color' => '#2271b1',
                'field_border' => '#dcdcde',
                'field_background' => '#ffffff',
                'font_family' => 'inherit',
            ],
            'recaptcha_enabled' => false,
            'recaptcha_site_key' => '',
            'recaptcha_secret_key' => '',
            'email_template' => "Hello {name},\n\nThank you for your submission.\n\nRegards,\n" . get_bloginfo('name'),
            'abandonment_tracking_enabled' => true,
            'abandonment_save_interval' => 10, // seconds
            'abandonment_timeout' => 300, // seconds (5 minutes)
            'abandonment_min_fields' => 1,
            'cleanup_days' => 90, // days
            'views_retention_days' => 60, // days of form view logs to keep
        ];

        foreach ($default_options as $option_name => $option_value) {
            add_option('sf_' . $option_name, $option_value);
        }
    }
}
