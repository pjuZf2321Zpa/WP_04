<?php
/**
 * Frontend class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Frontend;

use SigmaForms\Plugin;
use SigmaForms\Forms\Form;
use SigmaForms\Utils\Helper;
use SigmaForms\Forms\AbandonedFormsManager;
use SigmaForms\Utils\GoogleDriveOAuth;
use SigmaForms\Utils\OneDriveOAuth;
use Exception;

class Frontend {
    /**
     * Plugin instance
     *
     * @var Plugin
     */
    private $plugin;
    
    /**
     * Constructor
     *
     * @param Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        
        // Register hooks
        $this->register_hooks();
    }
    
    /**
     * Register hooks
     *
     * @return void
     */
    private function register_hooks() {
        // Register shortcode
        add_shortcode('sigmaforms', [$this, 'render_form_shortcode']);
        
        // Register AJAX handler for form submissions
        add_action('wp_ajax_sf_submit_form', [$this, 'handle_form_submission']);
        add_action('wp_ajax_nopriv_sf_submit_form', [$this, 'handle_form_submission']);

        // Fresh submission nonce for pages served from a cache (see frontend.js).
        add_action('wp_ajax_sf_refresh_nonce', [$this, 'refresh_submission_nonce']);
        add_action('wp_ajax_nopriv_sf_refresh_nonce', [$this, 'refresh_submission_nonce']);
    }

    /**
     * Return a new form submission nonce.
     *
     * A cached page can outlive the nonce it was rendered with. The nonce is
     * tied to the requesting user, and another site cannot read this response,
     * so handing out a fresh one does not weaken the CSRF check.
     *
     * @return void
     */
    public function refresh_submission_nonce() {
        nocache_headers();
        wp_send_json_success(['nonce' => wp_create_nonce('sf-frontend-nonce')]);
    }
    
    /**
     * File name for a visitor upload: the original name plus a random suffix.
     *
     * Used as wp_handle_upload()'s unique_filename_callback, so the extension
     * WordPress validated is kept.
     *
     * @param string $dir  Target directory.
     * @param string $name Sanitized file name.
     * @param string $ext  Extension including the dot.
     * @return string
     */
    public static function random_upload_filename($dir, $name, $ext) {
        $base = $ext !== '' && substr($name, -strlen($ext)) === $ext ? substr($name, 0, -strlen($ext)) : $name;

        do {
            $filename = $base . '-' . strtolower(wp_generate_password(10, false)) . $ext;
        } while (file_exists(trailingslashit($dir) . $filename));

        return $filename;
    }

    /**
     * Set custom upload directory for SigmaForms files
     *
     * @param array $upload Upload directory information
     * @return array Modified upload directory information
     */
    public function set_sigmaforms_upload_dir($upload) {
        $upload['subdir'] = '/sigmaforms' . gmdate('/Y/m');
        $upload['path'] = $upload['basedir'] . $upload['subdir'];
        $upload['url'] = $upload['baseurl'] . $upload['subdir'];

        Helper::ensure_sigmaforms_upload_hardening($upload['basedir'] . '/sigmaforms');

        return $upload;
    }
    
    /**
     * Set temporary upload directory for email attachment files
     *
     * @param array $upload Upload directory data
     * @return array Modified upload directory data
     */
    public function set_sigmaforms_temp_upload_dir($upload) {
        $upload['subdir'] = '/sigmaforms/temp';
        $upload['path'] = $upload['basedir'] . $upload['subdir'];
        $upload['url'] = $upload['baseurl'] . $upload['subdir'];

        Helper::ensure_sigmaforms_upload_hardening($upload['basedir'] . '/sigmaforms');

        return $upload;
    }
    
    /**
     * Grant the upload capability for anonymous form submissions.
     *
     * Only ever attached for the duration of a single wp_handle_upload() call, from
     * handle_form_submission() and after the nonce has been verified — see
     * begin_form_upload_context(). It must never be registered for a whole request:
     * as a 'user_has_cap' filter it would make every unrelated upload_files check in
     * that request pass for an anonymous visitor.
     *
     * @param array $allcaps All capabilities for the user
     * @return array Modified capabilities
     */
    public function grant_upload_capability_for_forms($allcaps) {
        $allcaps['upload_files'] = true;

        return $allcaps;
    }

    /**
     * Start a narrowly scoped upload context for a verified form submission.
     *
     * @return void
     */
    private function begin_form_upload_context() {
        add_filter('user_has_cap', [$this, 'grant_upload_capability_for_forms'], 10, 1);
    }

    /**
     * End the upload context opened by begin_form_upload_context().
     *
     * @return void
     */
    private function end_form_upload_context() {
        remove_filter('user_has_cap', [$this, 'grant_upload_capability_for_forms'], 10);
    }

    /**
     * Validate uploaded file before processing
     *
     * @param array $file File data from $_FILES
     * @param array $field Field configuration
     * @return array|bool Returns error array if invalid, false if valid
     */
    private function validate_uploaded_file($file, $field) {
        return Helper::validate_uploaded_file($file, $field);
    }
    
    /**
     * Get or create Google Drive folder structure (sigmaforms/YYYY/MM/)
     *
     * @param string $access_token Google Drive access token
     * @param string $base_folder_id Base folder ID (optional)
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return string|false Folder ID on success, false on failure
     */
    private function get_or_create_google_drive_folder_structure($access_token, $base_folder_id = '', $form_id = 0, $form_name = '') {
        $settings = get_option('sigmaforms_settings', []);
        $structure = $settings['storage_google_drive_folder_structure'] ?? 'year_month';
        
        // Start with base folder or root
        $parent_id = !empty($base_folder_id) ? $base_folder_id : 'root';
        
        // Determine folder path based on structure type
        if ($structure === 'form_id') {
            // sigmaforms/form-{id}/
            $sigmaforms_folder = $this->get_or_create_google_drive_folder($access_token, 'sigmaforms', $parent_id);
            if (!$sigmaforms_folder) {
                return false;
            }
            
            $form_folder = $this->get_or_create_google_drive_folder($access_token, 'form-' . $form_id, $sigmaforms_folder);
            return $form_folder;
            
        } elseif ($structure === 'custom') {
            // Custom folder structure with placeholders
            $custom_path = $settings['storage_google_drive_custom_folder'] ?? 'sigmaforms/{year}/{month}';
            return $this->create_google_drive_custom_folder_structure($access_token, $custom_path, $parent_id, $form_id, $form_name);
            
        } else {
            // Default: year_month - sigmaforms/YYYY/MM/
            $year = gmdate('Y');
            $month = gmdate('m');
            
            // Create/get sigmaforms folder
            $sigmaforms_folder = $this->get_or_create_google_drive_folder($access_token, 'sigmaforms', $parent_id);
            if (!$sigmaforms_folder) {
                return false;
            }
            
            // Create/get year folder
            $year_folder = $this->get_or_create_google_drive_folder($access_token, $year, $sigmaforms_folder);
            if (!$year_folder) {
                return false;
            }
            
            // Create/get month folder
            $month_folder = $this->get_or_create_google_drive_folder($access_token, $month, $year_folder);
            
            return $month_folder;
        }
    }
    
    /**
     * Create Google Drive folder structure from custom path with placeholders
     *
     * @param string $access_token Google Drive access token
     * @param string $custom_path Custom path with placeholders
     * @param string $parent_id Parent folder ID
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return string|false Folder ID on success, false on failure
     */
    private function create_google_drive_custom_folder_structure($access_token, $custom_path, $parent_id, $form_id, $form_name) {
        // Replace placeholders
        $replacements = [
            '{year}' => gmdate('Y'),
            '{month}' => gmdate('m'),
            '{day}' => gmdate('d'),
            '{form_id}' => $form_id,
            '{form_name}' => sanitize_file_name($form_name),
        ];
        
        $path = str_replace(array_keys($replacements), array_values($replacements), $custom_path);
        
        // Split path into folder names
        $folders = array_filter(explode('/', trim($path, '/')));
        
        // Create each folder in the hierarchy
        $current_parent = $parent_id;
        foreach ($folders as $folder_name) {
            $folder_id = $this->get_or_create_google_drive_folder($access_token, $folder_name, $current_parent);
            if (!$folder_id) {
                return false;
            }
            $current_parent = $folder_id;
        }
        
        return $current_parent;
    }
    
    /**
     * Get or create a Google Drive folder
     *
     * @param string $access_token Google Drive access token
     * @param string $folder_name Folder name
     * @param string $parent_id Parent folder ID
     * @return string|false Folder ID on success, false on failure
     */
    private function get_or_create_google_drive_folder($access_token, $folder_name, $parent_id) {
        // Search for existing folder
        $query = "name='" . addslashes($folder_name) . "' and mimeType='application/vnd.google-apps.folder' and '" . addslashes($parent_id) . "' in parents and trashed=false";
        
        $response = wp_remote_get(
            'https://www.googleapis.com/drive/v3/files?' . http_build_query(array(
                'q' => $query,
                'fields' => 'files(id, name)',
            )),
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                ),
                'timeout' => 30,
            )
        );
        
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['files']) && !empty($body['files'][0]['id'])) {
                return $body['files'][0]['id'];
            }
        }
        
        // Create folder if it doesn't exist
        $metadata = array(
            'name' => $folder_name,
            'mimeType' => 'application/vnd.google-apps.folder',
            'parents' => array($parent_id),
        );
        
        $response = wp_remote_post(
            'https://www.googleapis.com/drive/v3/files',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode($metadata),
                'timeout' => 30,
            )
        );
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        return !empty($body['id']) ? $body['id'] : false;
    }
    
    /**
     * Upload file to cloud storage
     *
     * @param array $file File array from $_FILES
     * @param string $storage_location Storage location (google_drive, onedrive)
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return array|false Upload result with URL on success, false on failure
     */
    private function upload_file_to_cloud($file, $storage_location, $form_id = 0, $form_name = '') {
        // Validate file array
        if (empty($file['tmp_name']) || empty($file['name'])) {
            return false;
        }
        
        // Check if license is valid
        if (!\SigmaForms\Plugin::is_license_valid()) {
            return false; // License required for cloud storage
        }
        
        // Check if global storage is enabled
        $settings = get_option('sigmaforms_settings', []);
        
        // Google Drive
        if ($storage_location === 'google_drive') {
            // Check if Google Drive is globally enabled
            if (empty($settings['storage_google_drive_enabled'])) {
                return false; // Google Drive is disabled globally
            }
            
            return $this->upload_to_google_drive($file, $form_id, $form_name);
        }

        // OneDrive
        if ($storage_location === 'onedrive') {
            // Check if OneDrive is globally enabled
            if (empty($settings['storage_onedrive_enabled'])) {
                return false; // OneDrive is disabled globally
            }
            
            return $this->upload_to_onedrive($file, $form_id, $form_name);
        }
        
        return false;
    }
    
    /**
     * Generate unique filename with timestamp to prevent naming conflicts
     *
     * @param string $filename Original filename
     * @return string Unique filename with timestamp (e.g., abc_1735470123.jpg)
     */
    private function generate_unique_filename($filename) {
        // Get file extension
        $file_info = pathinfo($filename);
        $extension = isset($file_info['extension']) ? '.' . $file_info['extension'] : '';
        $basename = isset($file_info['filename']) ? $file_info['filename'] : $filename;
        
        // Check if filename already has a timestamp (e.g., signature files: signature-field_id-1234567890.png)
        // Pattern: ends with dash or underscore followed by 10 digits (Unix timestamp)
        if (preg_match('/[-_]\d{10}$/', $basename)) {
            // Already has timestamp, return as-is
            return $filename;
        }
        
        // Generate timestamp
        $timestamp = time();
        
        // Create unique filename: basename_timestamp.extension
        return $basename . '_' . $timestamp . $extension;
    }
    
    /**
     * Upload file to Google Drive
     *
     * @param array $file File array from $_FILES
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return array|false Upload result with URL on success, false on failure
     */
    private function upload_to_google_drive($file, $form_id = 0, $form_name = '') {
        // Get valid access token (will refresh if needed)
        $access_token = GoogleDriveOAuth::get_valid_access_token();
        
        if (is_wp_error($access_token)) {
            return false;
        }
        
        // Read file content
        $file_content = file_get_contents($file['tmp_name']);
        if ($file_content === false) {
            return false;
        }
        
        // Create folder structure based on settings (always in root)
        $folder_id = $this->get_or_create_google_drive_folder_structure($access_token, '', $form_id, $form_name);
        
        // Generate unique filename with timestamp to avoid conflicts
        $unique_filename = $this->generate_unique_filename($file['name']);
        
        // Prepare metadata
        $metadata = array(
            'name' => sanitize_file_name($unique_filename),
        );
        
        // Add folder if specified
        if (!empty($folder_id)) {
            $metadata['parents'] = array($folder_id);
        }
        
        // Upload to Google Drive using multipart upload
        $boundary = wp_generate_password(24, false);
        
        $multipart_body = "--{$boundary}\r\n";
        $multipart_body .= "Content-Type: application/json; charset=UTF-8\r\n\r\n";
        $multipart_body .= wp_json_encode($metadata) . "\r\n";
        $multipart_body .= "--{$boundary}\r\n";
        $multipart_body .= "Content-Type: {$file['type']}\r\n\r\n";
        $multipart_body .= $file_content . "\r\n";
        $multipart_body .= "--{$boundary}--";
        
        $response = wp_remote_post(
            'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'multipart/related; boundary=' . $boundary,
                ),
                'body' => $multipart_body,
                'timeout' => 30,
            )
        );
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (empty($body['id'])) {
            return false;
        }
        
        // Make the file publicly accessible for images
        $file_id = $body['id'];
        $is_image = strpos($file['type'], 'image/') === 0;
        
        if ($is_image) {
            $this->set_google_drive_file_public($access_token, $file_id);
        }
        
        // Return file info with appropriate URL
        // For images, use thumbnail/preview URL that works without authentication
        $file_url = $is_image 
            ? 'https://drive.google.com/thumbnail?id=' . $file_id . '&sz=w1000'
            : 'https://drive.google.com/file/d/' . $file_id . '/view';
        
        return array(
            'url' => $file_url,
            'file' => $body['name'],
            'type' => $file['type'],
        );
    }
    
    /**
     * Make a Google Drive file publicly accessible
     *
     * @param string $access_token Google Drive access token
     * @param string $file_id File ID
     * @return bool Success status
     */
    private function set_google_drive_file_public($access_token, $file_id) {
        $response = wp_remote_post(
            'https://www.googleapis.com/drive/v3/files/' . $file_id . '/permissions',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(array(
                    'role' => 'reader',
                    'type' => 'anyone',
                )),
                'timeout' => 15,
            )
        );
        
        return !is_wp_error($response);
    }

    /**
     * Upload file to OneDrive
     *
     * @param array $file File array from $_FILES
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return array|false Upload result with URL on success, false on failure
     */
    private function upload_to_onedrive($file, $form_id = 0, $form_name = '') {
        // Get valid access token (will refresh if needed)
        $access_token = OneDriveOAuth::get_valid_access_token();
        
        if (is_wp_error($access_token)) {
            return false;
        }
        
        // Read file content
        $file_content = file_get_contents($file['tmp_name']);
        if ($file_content === false) {
            return false;
        }
        
        // Create folder structure based on settings
        $folder_path = $this->get_or_create_onedrive_folder_structure($access_token, $form_id, $form_name);
        
        if ($folder_path === false) {
            return false;
        }
        
        // Generate unique filename with timestamp to avoid conflicts and replacement
        $unique_filename = $this->generate_unique_filename($file['name']);
        
        // Prepare file path - encode only the filename, not the path separators
        $file_name = sanitize_file_name($unique_filename);
        $upload_path = $folder_path . '/' . rawurlencode($file_name);
        
        // Determine content type - use application/octet-stream as fallback
        $content_type = !empty($file['type']) ? $file['type'] : 'application/octet-stream';
        
        // Upload to OneDrive using simple upload (files < 4MB)
        $response = wp_remote_request(
            'https://graph.microsoft.com/v1.0/me/drive/root:' . $upload_path . ':/content',
            array(
                'method' => 'PUT',
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => $content_type,
                ),
                'body' => $file_content,
                'timeout' => 60,
            )
        );
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        // Check for successful upload (200 or 201)
        if ($response_code !== 200 && $response_code !== 201) {
            $error_message = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown error';
            return false;
        }
        
        if (empty($body['id'])) {
            return false;
        }
        
        // Get sharing link for the file
        $file_id = $body['id'];
        $is_image = strpos($file['type'], 'image/') === 0;
        
        // Create a sharing link
        $share_response = wp_remote_post(
            'https://graph.microsoft.com/v1.0/me/drive/items/' . $file_id . '/createLink',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(array(
                    'type' => 'view',
                    'scope' => 'anonymous',
                )),
                'timeout' => 15,
            )
        );
        
        $file_url = '';
        if (!is_wp_error($share_response)) {
            $share_body = json_decode(wp_remote_retrieve_body($share_response), true);
            if (!empty($share_body['link']['webUrl'])) {
                $file_url = $share_body['link']['webUrl'];
            }
        }
        
        // Fallback to webUrl from original response
        if (empty($file_url) && !empty($body['webUrl'])) {
            $file_url = $body['webUrl'];
        }
        
        return array(
            'url' => $file_url,
            'file' => $body['name'],
            'type' => $file['type'],
        );
    }
    
    /**
     * Get or create OneDrive folder structure (sigmaforms/YYYY/MM/)
     *
     * @param string $access_token OneDrive access token
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return string Folder path
     */
    private function get_or_create_onedrive_folder_structure($access_token, $form_id = 0, $form_name = '') {
        $settings = get_option('sigmaforms_settings', []);
        $structure = $settings['storage_onedrive_folder_structure'] ?? 'year_month';
        
        // Determine folder path based on structure type
        if ($structure === 'form_id') {
            // sigmaforms/form-{id}/
            $base_path = '/sigmaforms';
            $form_path = $base_path . '/form-' . $form_id;
            
            // Create sigmaforms folder if it doesn't exist
            if (!$this->create_onedrive_folder_if_not_exists($access_token, 'sigmaforms', '')) {
                return false;
            }
            
            // Create form folder
            if (!$this->create_onedrive_folder_if_not_exists($access_token, 'form-' . $form_id, $base_path)) {
                return false;
            }
            
            return $form_path;
            
        } elseif ($structure === 'custom') {
            // Custom folder structure with placeholders
            $custom_path = $settings['storage_onedrive_custom_folder'] ?? 'sigmaforms/{year}/{month}';
            return $this->create_onedrive_custom_folder_structure($access_token, $custom_path, $form_id, $form_name);
            
        } else {
            // Default: year_month - sigmaforms/YYYY/MM/
            $year = gmdate('Y');
            $month = gmdate('m');
            
            // Create path: /sigmaforms/YYYY/MM
            $base_path = '/sigmaforms';
            $year_path = $base_path . '/' . $year;
            $month_path = $year_path . '/' . $month;
            
            // Create sigmaforms folder if it doesn't exist
            if (!$this->create_onedrive_folder_if_not_exists($access_token, 'sigmaforms', '')) {
                return false;
            }
            
            // Create year folder
            if (!$this->create_onedrive_folder_if_not_exists($access_token, $year, $base_path)) {
                return false;
            }
            
            // Create month folder
            if (!$this->create_onedrive_folder_if_not_exists($access_token, $month, $year_path)) {
                return false;
            }
            
            return $month_path;
        }
    }
    
    /**
     * Create OneDrive folder structure from custom path with placeholders
     *
     * @param string $access_token OneDrive access token
     * @param string $custom_path Custom path with placeholders
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return string|false Folder path on success, false on failure
     */
    private function create_onedrive_custom_folder_structure($access_token, $custom_path, $form_id, $form_name) {
        // Replace placeholders
        $replacements = [
            '{year}' => gmdate('Y'),
            '{month}' => gmdate('m'),
            '{day}' => gmdate('d'),
            '{form_id}' => $form_id,
            '{form_name}' => sanitize_file_name($form_name),
        ];
        
        $path = str_replace(array_keys($replacements), array_values($replacements), $custom_path);
        
        // Split path into folder names
        $folders = array_filter(explode('/', trim($path, '/')));
        
        // Create each folder in the hierarchy
        $current_path = '';
        foreach ($folders as $folder_name) {
            $parent_path = $current_path;
            $current_path = $current_path . '/' . $folder_name;
            
            if (!$this->create_onedrive_folder_if_not_exists($access_token, $folder_name, $parent_path)) {
                return false;
            }
        }
        
        return $current_path;
    }
    
    /**
     * Create OneDrive folder if it doesn't exist
     *
     * @param string $access_token OneDrive access token
     * @param string $folder_name Folder name
     * @param string $parent_path Parent folder path (empty for root)
     * @return bool Success status
     */
    private function create_onedrive_folder_if_not_exists($access_token, $folder_name, $parent_path) {
        $folder_path = empty($parent_path) ? '/' . $folder_name : $parent_path . '/' . $folder_name;
        
        // Try to get the folder first
        $response = wp_remote_get(
            'https://graph.microsoft.com/v1.0/me/drive/root:' . $folder_path,
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                ),
                'timeout' => 15,
            )
        );
        
        // If folder exists, return true
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            return true;
        }
        
        // Create the folder
        $parent_endpoint = empty($parent_path) 
            ? 'https://graph.microsoft.com/v1.0/me/drive/root/children'
            : 'https://graph.microsoft.com/v1.0/me/drive/root:' . $parent_path . ':/children';
        
        $create_response = wp_remote_post(
            $parent_endpoint,
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(array(
                    'name' => $folder_name,
                    'folder' => new \stdClass(),
                    '@microsoft.graph.conflictBehavior' => 'fail',
                )),
                'timeout' => 15,
            )
        );
        
        if (is_wp_error($create_response)) {
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($create_response);
        
        // Success codes: 201 (created), or 409 (conflict - folder already exists)
        if ($response_code === 201 || $response_code === 409) {
            return true;
        }
        
        $body = json_decode(wp_remote_retrieve_body($create_response), true);
        $error_message = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown error';
        
        return false;
    }
    
    /**
     * Save signature base64 data as an image file
     *
     * @param string $base64_data Base64 encoded image data
     * @param string $field_id Field ID for unique filename
     * @param array $field Field configuration
     * @param int $form_id Form ID
     * @param string $form_name Form name
     * @return string|bool File URL on success, false on failure
     */
    private function save_signature_as_file($base64_data, $field_id, $field = array(), $form_id = 0, $form_name = '', &$email_attachments = []) {
        // Extract the image data from the data URI
        if (!preg_match('/^data:image\/(png|jpeg|jpg);base64,(.+)$/', $base64_data, $matches)) {
            return false;
        }
        
        $image_type = $matches[1];
        $image_data = base64_decode($matches[2]);
        
        if ($image_data === false) {
            return false;
        }
        
        // Generate unique filename
        // The random part keeps the public URL from being guessed from the time.
        $filename = 'signature-' . sanitize_file_name($field_id) . '-' . time() . '-' . wp_generate_password(8, false) . '.' . ($image_type === 'jpeg' ? 'jpg' : $image_type);
        
        // Check storage location
        $storage_location = !empty($field['storage_location']) ? $field['storage_location'] : 'site';
        
        // Handle email attachment storage
        if ($storage_location === 'email_attachment') {
            // Set custom upload directory to temp folder
            add_filter('upload_dir', [$this, 'set_sigmaforms_temp_upload_dir']);
            
            // Get upload directory
            $upload_dir = wp_upload_dir();
            
            // Remove custom upload directory filter
            remove_filter('upload_dir', [$this, 'set_sigmaforms_temp_upload_dir']);
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir['path'])) {
                wp_mkdir_p($upload_dir['path']);
            }
            
            // Save file to temp location
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_saved = file_put_contents($file_path, $image_data);
            
            if ($file_saved !== false) {
                // Add to email attachments
                $email_attachments[] = $file_path;
                // Return description for submission data
                return $filename . ' (Email Attachment)';
            }
            
            return false;
        }
        
        // Try cloud storage first if configured
        if ($storage_location !== 'site') {
            $temp_file = wp_tempnam($filename);
            if ($temp_file && file_put_contents($temp_file, $image_data) !== false) {
                // Create a file array similar to $_FILES structure
                $file_array = array(
                    'name' => $filename,
                    'type' => 'image/' . $image_type,
                    'tmp_name' => $temp_file,
                    'size' => strlen($image_data),
                );
                
                $cloud_upload = $this->upload_file_to_cloud($file_array, $storage_location, $form_id, $form_name);
                
                // Clean up temp file
                wp_delete_file($temp_file);
                
                if ($cloud_upload && !empty($cloud_upload['url'])) {
                    return $cloud_upload['url'];
                }
                
                // Fallback to site storage if cloud upload fails
                $storage_location = 'site';
            }
        }
        
        // Upload to site storage (default or fallback)
        if ($storage_location === 'site') {
            // Set custom upload directory
            add_filter('upload_dir', [$this, 'set_sigmaforms_upload_dir']);
            
            // Get upload directory
            $upload_dir = wp_upload_dir();
            
            // Remove custom upload directory filter
            remove_filter('upload_dir', [$this, 'set_sigmaforms_upload_dir']);
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir['path'])) {
                wp_mkdir_p($upload_dir['path']);
            }
            
            // Save file
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_saved = file_put_contents($file_path, $image_data);
            
            if ($file_saved === false) {
                return false;
            }
            
            // Return file URL
            return $upload_dir['url'] . '/' . $filename;
        }
        
        return false;
    }
    
    /**
     * Render form shortcode
     *
     * @param array $atts Shortcode attributes
     * @return string Form HTML
     */
    public function render_form_shortcode($atts) {
        $atts = shortcode_atts(
            [
                'id' => 0,
                'theme' => '', // Allow theme override via shortcode
            ],
            $atts,
            'sigmaforms'
        );
        
        $form_id = (int) $atts['id'];
        
        if ($form_id <= 0) {
            return '<p class="sf-error">' . __('Form ID is required.', 'sigmaforms-pro') . '</p>';
        }
        
        $form_data = $this->plugin->forms->get_form($form_id);
        
        if (!$form_data) {
            return '<p class="sf-error">' . __('Form not found.', 'sigmaforms-pro') . '</p>';
        }

        // Enforce license limit for frontend rendering
        if (!Plugin::is_license_valid() && !Plugin::is_form_allowed($form_id)) {
            $license_url = esc_url(admin_url('admin.php?page=sigmaforms_license'));
            // Friendly message for site admins, generic for visitors
            if (current_user_can('manage_options')) {
                return '<p class="sf-error">' . sprintf(
                    /* translators: 1: number 2: link */
                    __('This form cannot be displayed because you\'ve reached the free limit of %1$d forms. Please <a href="%2$s" target="_blank">activate your license</a> to unlock all forms.', 'sigmaforms-pro'),
                    5,
                    $license_url
                ) . '</p>';
            }
            return '<p class="sf-error">' . __('This form is currently unavailable.', 'sigmaforms-pro') . '</p>';
        }
        
        $form = new Form($form_data);
        
        // Check for theme: shortcode attribute > form setting > global setting
        $theme = !empty($atts['theme']) ? $atts['theme'] : 
                 (!empty($form_data['form_settings']['form_theme']) ? $form_data['form_settings']['form_theme'] : 
                 get_option('sf_form_theme', 'minimal'));
        
        // Enqueue required assets
        wp_enqueue_style('sf-frontend-styles');
        
        // Enqueue theme-specific stylesheet (for preset themes only)
        // Custom theme uses inline styles generated in Form.php
        if (!empty($theme) && in_array($theme, ['minimal', 'classic', 'modern', 'transition', 'soft'], true)) {
            wp_enqueue_style(
                'sf-theme-' . $theme,
                SF_PLUGIN_URL . 'assets/css/themes/' . $theme . '.css',
                ['sf-frontend-styles'],
                SF_VERSION
            );
        }
        
        wp_enqueue_script('sf-frontend-script');
        
        // Field-specific scripts load only when the form has those fields.
        $field_types = array_column(isset($form_data['form_fields']) ? (array) $form_data['form_fields'] : [], 'type');

        if (in_array('page_break', $field_types, true)) {
            wp_enqueue_script('sf-multistep');
        }

        if (in_array('signature', $field_types, true)) {
            wp_enqueue_script('sf-qrcode');
            wp_enqueue_script('sf-mobile-signature');
        }

        // File and signature fields use dashicons, which WordPress only loads
        // for logged-in users; visitors saw empty icons.
        if (array_intersect(['file', 'signature'], $field_types)) {
            wp_enqueue_style('dashicons');
        }
        
        // User meta used by this form's "User Data" conditions, and only that.
        if (is_user_logged_in()) {
            $meta_values = [];
            foreach ((array) ($form_data['form_fields'] ?? []) as $conditional_field) {
                foreach ((array) ($conditional_field['conditional']['groups'] ?? []) as $group) {
                    foreach ((array) ($group['rules'] ?? []) as $rule) {
                        if (($rule['source_type'] ?? '') === 'user' && ($rule['field'] ?? '') === 'user_meta' && !empty($rule['meta_key'])) {
                            $meta = get_user_meta(get_current_user_id(), (string) $rule['meta_key'], true);
                            $meta_values[(string) $rule['meta_key']] = is_scalar($meta) ? (string) $meta : '';
                        }
                    }
                }
            }
            if ($meta_values) {
                wp_add_inline_script('sf-frontend-script', 'sfData.user_data.meta = Object.assign({}, sfData.user_data.meta, ' . wp_json_encode($meta_values) . ');');
            }
        }

        // Pass the theme to the render method
        $html = $form->render($theme);

        // Log a view for analytics. Feeds, REST (the block editor loads post
        // content through it) and admin screens are not visitor views.
        $is_visitor_view = !is_feed() && !is_admin() && !(defined('REST_REQUEST') && REST_REQUEST);

        if ($is_visitor_view) try {
            global $wpdb;
            $table = $wpdb->prefix . 'sigmaforms_views';

            // Only attempt if the table exists. Cached for the request so a page
            // with several forms does not repeat this query per render.
            static $views_table_exists = null;
            if ($views_table_exists === null) {
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $views_table_exists = ($wpdb->get_var("SHOW TABLES LIKE '" . esc_sql($table) . "'") === $table);
            }

            if ($views_table_exists) {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via esc_url_raw and home_url
                $page_url = isset($_SERVER['REQUEST_URI']) ? esc_url_raw(home_url(wp_unslash($_SERVER['REQUEST_URI']))) : '';
                $referrer_url = wp_get_referer();
                $user_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
                $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->insert($table, [
                    'form_id' => $form_id,
                    'page_url' => $page_url,
                    'referrer_url' => $referrer_url,
                    'user_ip' => $user_ip,
                    'user_agent' => $user_agent,
                    'date_created' => current_time('mysql'),
                ], ['%d','%s','%s','%s','%s','%s']);
            }
        } catch (\Exception $e) {
            // Silently fail to avoid breaking frontend
        }

        return $html;
    }
    
    /**
     * Handle form submission
     *
     * @return void
     */
    public function handle_form_submission() {

        
        check_ajax_referer('sf-frontend-nonce', 'nonce');
        
        $form_id = isset($_POST['form_id']) ? (int) $_POST['form_id'] : 0;
        
        if ($form_id <= 0) {
            
            wp_send_json_error([
                'message' => __('Invalid form ID.', 'sigmaforms-pro'),
            ]);
            return;
        }
       
        
        // Get form data
        $form_data = $this->plugin->forms->get_form($form_id);
        
        if (!$form_data) {
            
            wp_send_json_error([
                'message' => __('Form not found.', 'sigmaforms-pro'),
            ]);
            return;
        }
        
        // Validate form scheduling - check if submission is within allowed time window
        $form_settings = isset($form_data['form_settings']) ? $form_data['form_settings'] : [];
        $schedule_error = \SigmaForms\Forms\FormsManager::get_schedule_error($form_settings);
        if ($schedule_error !== '') {
            wp_send_json_error([
                'message' => $schedule_error,
            ]);
            return;
        }
        
        // Validate CAPTCHA if enabled and license is valid
        $recaptcha_score = null;
        if (\SigmaForms\Plugin::is_license_valid()) {
            $captcha_result = \SigmaForms\Utils\CaptchaHandler::validate_captcha($form_data['form_settings'], $_POST);
            if (!$captcha_result['valid']) {
                wp_send_json_error([
                    'message' => $captcha_result['message'],
                ]);
                return;
            }
            // Store score if available (for v3)
            if (isset($captcha_result['score'])) {
                $recaptcha_score = $captcha_result['score'];
            }
        }
        
        // Prepare form submission data
        $submission_data = [];
        $email_attachments = []; // Store file paths for email attachments
        
        foreach ($form_data['form_fields'] as $field) {
            if (!isset($field['id'])) {
                continue;
            }
            
            // Skip section headings and page breaks - they don't have input values
            if (isset($field['type']) && ($field['type'] === 'section_heading' || $field['type'] === 'page_break')) {
                continue;
            }
            
            $field_id = $field['id'];
            // FIX: Always treat checkbox values as arrays
            if ($field['type'] === 'checkbox') {
                if (!isset($_POST[$field_id])) {
                    $field_value = [];
                } else {
                    // Checkboxes submit as arrays, so get the raw array first
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Sanitized in array_map below
                    $field_value = isset($_POST[$field_id]) ? wp_unslash($_POST[$field_id]) : [];
                    // Ensure it's an array
                    if (!is_array($field_value)) {
                        $field_value = [$field_value];
                    }
                }
            } else {
                if ($field['type'] === 'rich_text') {
                    // For rich text, use wp_kses_post to allow safe HTML
                    $field_value = isset($_POST[$field_id]) ? wp_kses_post(wp_unslash($_POST[$field_id])) : '';
                } else {
                    $field_value = isset($_POST[$field_id]) ? sanitize_text_field(wp_unslash($_POST[$field_id])) : '';
                }
            }
            
            // Handle file uploads - allows any file type under 10MB
            if ($field['type'] === 'file' && isset($_FILES[$field_id]) && !empty($_FILES[$field_id]['name'])) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
                
                $storage_location = !empty($field['storage_location']) ? $field['storage_location'] : 'site';
                $allow_multiple = isset($field['allow_multiple']) && $field['allow_multiple'];
                $uploaded_files = [];
                
                // Enforce max files limit when allow multiple is enabled
                if ($allow_multiple && !empty($field['max_files']) && is_array($_FILES[$field_id]['name'])) {
                    $max_files = (int) $field['max_files'];
                    if (count($_FILES[$field_id]['name']) > $max_files) {
                        wp_send_json_error([
                            /* translators: %d: maximum number of files allowed */
                            'message' => sprintf(__('You can upload a maximum of %d files.', 'sigmaforms-pro'), $max_files),
                        ]);
                        return;
                    }
                }
                
                // Check if multiple files were uploaded (array structure)
                $is_multiple_upload = is_array($_FILES[$field_id]['name']);
                
                // Convert single file to array format for unified processing.
                // phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- Normalising the $_FILES structure only; each entry is checked by validate_uploaded_file() and wp_handle_upload() below.
                if (!$is_multiple_upload) {
                    $files_to_process = [
                        [
                            'name' => $_FILES[$field_id]['name'],
                            'type' => $_FILES[$field_id]['type'],
                            'tmp_name' => $_FILES[$field_id]['tmp_name'],
                            'error' => $_FILES[$field_id]['error'],
                            'size' => $_FILES[$field_id]['size'],
                        ]
                    ];
                } else {
                    // Restructure multiple files array
                    $files_to_process = [];
                    $file_count = count($_FILES[$field_id]['name']);
                    for ($i = 0; $i < $file_count; $i++) {
                        $files_to_process[] = [
                            'name' => $_FILES[$field_id]['name'][$i],
                            'type' => $_FILES[$field_id]['type'][$i],
                            'tmp_name' => $_FILES[$field_id]['tmp_name'][$i],
                            'error' => $_FILES[$field_id]['error'][$i],
                            'size' => $_FILES[$field_id]['size'][$i],
                        ];
                    }
                }
                // phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
                
                // Process each file
                foreach ($files_to_process as $file) {
                    // Check for upload errors
                    if (isset($file['error']) && $file['error'] !== UPLOAD_ERR_OK) {
                        // No file provided for this slot — skip silently for optional fields.
                        // This happens with multiple-file inputs (name="field[]") when the
                        // browser includes an empty entry in $_FILES even if no file was chosen.
                        if ($file['error'] === UPLOAD_ERR_NO_FILE && empty($field['required'])) {
                            continue;
                        }

                        $error_messages = [
                            UPLOAD_ERR_INI_SIZE => __('The uploaded file exceeds the upload_max_filesize directive in php.ini.', 'sigmaforms-pro'),
                            UPLOAD_ERR_FORM_SIZE => __('The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.', 'sigmaforms-pro'),
                            UPLOAD_ERR_PARTIAL => __('The uploaded file was only partially uploaded.', 'sigmaforms-pro'),
                            UPLOAD_ERR_NO_FILE => __('No file was uploaded.', 'sigmaforms-pro'),
                            UPLOAD_ERR_NO_TMP_DIR => __('Missing a temporary folder.', 'sigmaforms-pro'),
                            UPLOAD_ERR_CANT_WRITE => __('Failed to write file to disk.', 'sigmaforms-pro'),
                            UPLOAD_ERR_EXTENSION => __('File upload stopped by extension.', 'sigmaforms-pro'),
                        ];
                        
                        $error_msg = isset($error_messages[$file['error']]) ? $error_messages[$file['error']] : __('Unknown upload error.', 'sigmaforms-pro');
                        
                        wp_send_json_error([
                            'message' => $error_msg,
                        ]);
                        return;
                    }
                    
                    // Validate the file before processing
                    $validation_error = $this->validate_uploaded_file($file, $field);
                    if ($validation_error) {
                        wp_send_json_error([
                            'message' => $validation_error['error'],
                        ]);
                        return;
                    }
                    
                    // Handle email attachment storage
                    if ($storage_location === 'email_attachment') {
                        $upload_overrides = [
                            'test_form' => false,
                            'test_type' => true,
                            'test_size' => true,
                        ];
                        
                        add_filter('upload_dir', [$this, 'set_sigmaforms_temp_upload_dir']);
                        $upload_dir = wp_upload_dir();
                        if (!file_exists($upload_dir['path'])) {
                            wp_mkdir_p($upload_dir['path']);
                        }

                        $this->begin_form_upload_context();
                        $uploaded = wp_handle_upload($file, $upload_overrides);
                        $this->end_form_upload_context();
                        remove_filter('upload_dir', [$this, 'set_sigmaforms_temp_upload_dir']);
                        
                        if (!isset($uploaded['error'])) {
                            if (file_exists($uploaded['file']) && is_readable($uploaded['file'])) {
                                $email_attachments[] = $uploaded['file'];
                                $uploaded_files[] = basename($uploaded['file']) . ' (Email Attachment)';
                            }
                        } else {
                            wp_send_json_error([
                                'message' => $uploaded['error'],
                            ]);
                            return;
                        }
                        continue;
                    }
                    
                    // Handle cloud storage
                    if ($storage_location !== 'site') {
                        $cloud_upload = $this->upload_file_to_cloud($file, $storage_location, $form_id, $form_data['title'] ?? '');
                        
                        if ($cloud_upload && !empty($cloud_upload['url'])) {
                            $uploaded_files[] = $cloud_upload['url'];
                        } else {
                            $storage_name = $storage_location === 'google_drive' ? 'Google Drive' : 'OneDrive';
                            $msg = !empty($field['cloud_upload_error_message'])
                                ? $field['cloud_upload_error_message']
                                /* translators: %s: cloud storage provider name, e.g. Google Drive or OneDrive */
                                : sprintf(__('Unable to upload to %s. Please check your connection and try again.', 'sigmaforms-pro'), $storage_name);
                            wp_send_json_error([
                                'message' => $msg,
                            ]);
                            return;
                        }
                        continue;
                    }
                    
                    // Handle site storage
                    if ($storage_location === 'site') {
                        $upload_overrides = [
                            'test_form' => false,
                            'test_type' => true,
                            'test_size' => true,
                            // Uploads are public; a random suffix keeps their URLs
                            // from being guessed from the original file name.
                            'unique_filename_callback' => [__CLASS__, 'random_upload_filename'],
                        ];
                        
                        add_filter('upload_dir', [$this, 'set_sigmaforms_upload_dir']);
                        $this->begin_form_upload_context();
                        $uploaded = wp_handle_upload($file, $upload_overrides);
                        $this->end_form_upload_context();
                        remove_filter('upload_dir', [$this, 'set_sigmaforms_upload_dir']);
                        
                        if (!isset($uploaded['error'])) {
                            $uploaded_files[] = $uploaded['url'];
                        } else {
                            wp_send_json_error([
                                'message' => $uploaded['error'],
                            ]);
                            return;
                        }
                    }
                }
                
                // Store uploaded file URLs/paths
                if (!empty($uploaded_files)) {
                    // For multiple files, store as comma-separated URLs or as array
                    $submission_data[$field_id] = count($uploaded_files) > 1 ? implode(', ', $uploaded_files) : $uploaded_files[0];
                }
                
                continue;
            }
            
            // Handle phone_international field - combine country code with phone number
            if ($field['type'] === 'phone_international') {
                $country_field = $field_id . '_country';
                $country_code = isset($_POST[$country_field]) ? sanitize_text_field( wp_unslash( $_POST[$country_field] ) ) : '';
                $phone_number = $field_value;
                
                // Get the phone code for the selected country
                $phone_code = $this->get_phone_code_for_country($country_code);
                
                // Combine phone code with phone number
                if (!empty($phone_code) && !empty($phone_number)) {
                    $submission_data[$field_id] = $phone_code . ' ' . $phone_number;
                } else {
                    $submission_data[$field_id] = $phone_number;
                }
                continue;
            }
            
            // Handle arrays (checkboxes)
            if (is_array($field_value)) {
                $sanitized_values = [];
                
                foreach ($field_value as $value) {
                    // For checkboxes, use wp_unslash to remove slashes but don't sanitize further
                    // as sanitize_text_field might modify the value in a way that breaks validation
                    if ($field['type'] === 'checkbox') {
                        $sanitized_values[] = wp_unslash($value);
                    } else {
                        $sanitized_values[] = sanitize_text_field($value);
                    }
                }
                
                $submission_data[$field_id] = $sanitized_values;
            } else {
                // Handle field based on type
                switch ($field['type']) {
                    case 'email':
                        $submission_data[$field_id] = sanitize_email($field_value);
                        break;
                    
                    case 'url':
                        $submission_data[$field_id] = esc_url_raw($field_value);
                        break;
                    
                    case 'file':
                        // A file field only ever holds a URL produced by the upload
                        // handler above, and that branch continues before reaching
                        // this switch. Reaching here means no valid upload arrived,
                        // so discard whatever the client sent: the stored value later
                        // drives file deletion when the submission is removed.
                        $submission_data[$field_id] = '';
                        break;

                    case 'signature':
                        // Convert signature base64 to uploaded file
                        if (!empty($field_value) && preg_match('/^data:image\/(png|jpeg|jpg);base64,/', $field_value)) {
                            $signature_url = $this->save_signature_as_file($field_value, $field_id, $field, $form_id, $form_data['title'] ?? '', $email_attachments);
                            if ($signature_url) {
                                $submission_data[$field_id] = $signature_url;
                            } else {
                                $submission_data[$field_id] = '';
                            }
                        } else {
                            $submission_data[$field_id] = '';
                        }
                        break;
                        
                    case 'textarea':
                        $submission_data[$field_id] = sanitize_textarea_field($field_value);
                        break;

                    case 'rich_text':
                        $submission_data[$field_id] = wp_kses_post($field_value);
                        break;
                        
                    default:
                        $submission_data[$field_id] = sanitize_text_field($field_value);
                        break;
                }
            }
        }
        
        // Process math functions for fields that have them enabled
        $this->process_math_functions($form_data, $submission_data);
        
        // Validate submission
        $validation_result = $this->validate_submission($form_data, $submission_data);
        
        if (is_wp_error($validation_result)) {
            wp_send_json_error([
                'message' => $validation_result->get_error_message(),
                'errors' => $validation_result->get_error_data('validation_failed'),
            ]);
            return;
        }
        
        // Process submission
        $submission_id = $this->process_submission($form_id, $submission_data, $email_attachments);
        
        if (is_wp_error($submission_id)) {
            wp_send_json_error([
                'message' => $submission_id->get_error_message(),
            ]);
            return;
        }
        
        // Server-side safeguard: mark abandoned session as converted if session_id provided
        $session_id = isset($_POST['session_id']) ? sanitize_text_field( wp_unslash( $_POST['session_id'] ) ) : '';
        if (!empty($session_id)) {
            try {
                $abManager = new AbandonedFormsManager();
                // Best-effort; ignore result if it fails
                $abManager->mark_as_converted($session_id, $form_id);
            } catch (\Exception $e) {
                // ignore
            }
        }

        // Log page/referrer for analytics (submission context)
        try {
            global $wpdb;
            $table = $wpdb->prefix . 'sigmaforms_referrers';
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $exists = $wpdb->get_var("SHOW TABLES LIKE '" . esc_sql($table) . "'");
            if ($exists === $table) {
                $page_url = wp_get_referer(); // The page where the form was displayed
                $referrer_url = isset($_SERVER['HTTP_REFERER']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->insert($table, [
                    'form_id' => $form_id,
                    'submission_id' => $submission_id,
                    'page_url' => $page_url,
                    'referrer_url' => $referrer_url,
                    'date_created' => current_time('mysql'),
                ], ['%d','%d','%s','%s','%s']);
            }
        } catch (\Exception $e) {
            // Silently ignore
        }

        // Apply action hook for after submission
        do_action('sigmaforms_after_submit', $form_id, $submission_data, $submission_id);
        
        // Return success
        $response_data = [
            'message' => isset($form_data['form_settings']['success_message']) ? $form_data['form_settings']['success_message'] : __('Thank you for your submission!', 'sigmaforms-pro'),
            'submission_id' => $submission_id,
        ];
        
        // Include reCAPTCHA score if available
        if ($recaptcha_score !== null) {
            $response_data['recaptcha_score'] = $recaptcha_score;
        }
        
        wp_send_json_success($response_data);
    }
    
    /**
     * Validate form submission
     *
     * @param array $form_data Form data
     * @param array $submission_data Submission data
     * @return true|\WP_Error True if valid or error
     */
    private function validate_submission($form_data, $submission_data) {
        $fields = $form_data['form_fields'];
        $validation_errors = [];
        
        foreach ($fields as $field) {
            // Advanced conditional logic (what the editor saves): a field hidden
            // or disabled by its conditions is not validated, as in the browser.
            // Only the legacy format below was handled, so a hidden required
            // field made the whole form impossible to submit.
            if (!empty($field['conditional']) && !empty($field['id'])) {
                // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Called from handle_form_submission() after its nonce check; only presence is read.
                $field_was_sent = isset($_POST[$field['id']]) || isset($_FILES[$field['id']]);
                $active = Helper::is_conditional_field_active($field['conditional'], $submission_data, $field_was_sent);
                if ($active === false) {
                    continue;
                }
            }

            // Skip if field has conditional logic and is not shown
            if (!empty($field['conditional']) && isset($field['conditional']['show']) && isset($field['conditional']['field']) && isset($field['conditional']['operator']) && isset($field['conditional']['value'])) {
                $show = $field['conditional']['show'];
                $dependent_field = $field['conditional']['field'];
                $operator = $field['conditional']['operator'];
                $expected_value = $field['conditional']['value'];
                $actual_value = isset($submission_data[$dependent_field]) ? $submission_data[$dependent_field] : '';
                
                $should_show = false;
                
                switch ($operator) {
                    case '=':
                        $should_show = ($actual_value == $expected_value);
                        break;
                    case '!=':
                        $should_show = ($actual_value != $expected_value);
                        break;
                    case '>':
                        $should_show = ($actual_value > $expected_value);
                        break;
                    case '<':
                        $should_show = ($actual_value < $expected_value);
                        break;
                    case 'contains':
                        $should_show = (strpos($actual_value, $expected_value) !== false);
                        break;
                }
                
                if ($show !== $should_show) {
                    continue;
                }
            }
            
            $field_id = $field['id'];
            $field_value = isset($submission_data[$field_id]) ? $submission_data[$field_id] : '';
            
            // Check required fields
            if (isset($field['required']) && $field['required']) {
                $field_label = !empty($field['label']) ? $field['label'] : __('Field', 'sigmaforms-pro');
                $custom_required_msg = !empty($field['required_message']) ? $field['required_message'] : '';
                
                if ($field['type'] === 'checkbox' && is_array($field_value)) {
                    // For checkboxes, check if at least one option is selected
                    if (empty($field_value)) {
                        // translators: %s is the field label.
                        $validation_errors[] = $custom_required_msg ?: sprintf(__('%s is required.', 'sigmaforms-pro'), $field_label);
                        continue;
                    }
                } elseif (empty($field_value)) {
                    // For other field types, check if value is empty
                    // translators: %s is the field label.
                    $validation_errors[] = $custom_required_msg ?: sprintf(__('%s is required.', 'sigmaforms-pro'), $field_label);
                    continue;
                }
            }
            
            // Skip further validation if empty and not required
            if (empty($field_value) && (!isset($field['required']) || !$field['required'])) {
                continue;
            }
            
            // Validate based on field type
            switch ($field['type']) {
                case 'email':
                    if (!is_email($field_value)) {
                        $validation_errors[] = !empty($field['validation_message'])
                            ? $field['validation_message']
                            // translators: %s is the field label.
                            : sprintf(__('%s must be a valid email address.', 'sigmaforms-pro'), $field['label']);
                    }
                    break;
                
                case 'url':
                    if (!filter_var($field_value, FILTER_VALIDATE_URL)) {
                        $validation_errors[] = !empty($field['validation_message'])
                            ? $field['validation_message']
                            // translators: %s is the field label.
                            : sprintf(__('%s must be a valid URL.', 'sigmaforms-pro'), $field['label']);
                    }
                    break;
                    
                case 'number':
                    if (!is_numeric($field_value)) {
                        $validation_errors[] = !empty($field['validation_message'])
                            ? $field['validation_message']
                            // translators: %s is the field label.
                            : sprintf(__('%s must be a number.', 'sigmaforms-pro'), $field['label']);
                    }
                    break;
                    
                case 'phone':
                    if (!preg_match('/^[0-9()+\-\s]*$/', $field_value)) {
                        $validation_errors[] = !empty($field['validation_message'])
                            ? $field['validation_message']
                            // translators: %s is the field label.
                            : sprintf(__('%s must be a valid phone number.', 'sigmaforms-pro'), $field['label']);
                    }
                    break;
                
                case 'signature':
                    // Validate signature data (base64 encoded image or uploaded file URL)
                    if (!empty($field_value)) {
                        $is_base64 = preg_match('/^data:image\/(png|jpeg|jpg);base64,/', $field_value);
                        $is_url = filter_var($field_value, FILTER_VALIDATE_URL);
                        $is_email_attachment = strpos($field_value, '(Email Attachment)') !== false;
                        
                        if (!$is_base64 && !$is_url && !$is_email_attachment) {
                            // translators: %s is the field label.
                            $validation_errors[] = sprintf(__('%s must be a valid signature.', 'sigmaforms-pro'), $field['label']);
                        }
                    }
                    break;
                    
                case 'select':
                case 'country':
                case 'radio':
                    if (!empty($field['options']) && is_array($field['options'])) {
                        $valid_option = false;
                        
                        foreach ($field['options'] as $option) {
                            if (isset($option['value']) && $option['value'] === $field_value) {
                                $valid_option = true;
                                break;
                            }
                        }
                        if (!$valid_option) {
                            // translators: %s is the field label.
                            $validation_errors[] = sprintf(__('Invalid option selected for %s.', 'sigmaforms-pro'), $field['label']);
                        }
                    }
                    break;
                    
                case 'checkbox':
                    if (is_array($field_value) && !empty($field['options']) && is_array($field['options'])) {
                        foreach ($field_value as $checkbox_value) {
                            $valid_option = false;
                            
                            foreach ($field['options'] as $option) {
                                if (isset($option['value']) && $option['value'] === $checkbox_value) {
                                    $valid_option = true;
                                    break;
                                }
                            }
                            
                            if (!$valid_option) {
                                $field_label = !empty($field['label']) ? $field['label'] : __('Checkbox Options', 'sigmaforms-pro');
                                /* translators: %s is the field label */
                                $validation_errors[] = sprintf(__('Invalid option selected for %s.', 'sigmaforms-pro'), $field_label);
                                break;
                            }
                        }
                    }
                    break;
            }
        }
        
        if (!empty($validation_errors)) {
            $failed_msg = !empty($form_data['form_settings']['validation_failed_message'])
                ? $form_data['form_settings']['validation_failed_message']
                : __('Please submit the required fields.', 'sigmaforms-pro');
            return new \WP_Error(
                'validation_failed',
                $failed_msg,
                $validation_errors
            );
        }
        
        return true;
    }
    
    /**
     * Process form submission
     *
     * @param int $form_id Form ID
     * @param array $submission_data Submission data
     * @return int|\WP_Error Submission ID or error
     */
    private function process_submission($form_id, $submission_data, $email_attachments = []) {
        
        $form_data = $this->plugin->forms->get_form($form_id);
        
        if (!$form_data) {

            return new \WP_Error('form_not_found', __('Form not found.', 'sigmaforms-pro'));
        }
        
        // Store submission in database if enabled
        $submission_id = 0;
        
        if (isset($form_data['form_settings']['store_submissions']) && $form_data['form_settings']['store_submissions']) {
            global $wpdb;
            
            $table = $wpdb->prefix . 'sigmaforms_submissions';
            
            // Use json_encode with JSON_UNESCAPED_SLASHES to preserve base64 data integrity
            $field_values_json = json_encode($submission_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $result = $wpdb->insert($table,['form_id' => $form_id,'field_values' => $field_values_json,'user_id' => is_user_logged_in() ? get_current_user_id() : 0,'user_ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '','user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '','date_created' => current_time('mysql'),'status' => 'unread',],['%d','%s','%d','%s','%s','%s','%s',]);
            
            if ($result === false) {

                return new \WP_Error('db_error', __('Failed to store submission.', 'sigmaforms-pro'));
            }
            
            $submission_id = $wpdb->insert_id;
            
        }
        
        // Send email notification only when license is valid
        if (\SigmaForms\Plugin::is_license_valid()) {
            $email_result = $this->send_email_notification($form_data, $submission_data, $email_attachments);
        }
        
        // Clean up temp files after email sent
        if (!empty($email_attachments)) {
            foreach ($email_attachments as $file_path) {
                if (file_exists($file_path)) {
                    $deleted = wp_delete_file($file_path);
                } 
            }
        }
        
        // Sent after the response; queue() checks the license.
        \SigmaForms\Utils\WebhookHandler::queue($form_id, $submission_data, $form_data);
        
        return $submission_id;
    }
    
    /**
     * Send email notification
     *
     * @param array $form_data Form data
     * @param array $submission_data Submission data
     * @param array $email_attachments Optional. Array of file paths for email attachments
     * @return bool True if email sent successfully
     */
    private function send_email_notification($form_data, $submission_data, $email_attachments = []) {
        
        $settings = $form_data['form_settings'];
        
        // Check if email override is enabled
        $override_email_settings = !empty($settings['override_email_settings']);
        
        // Get email settings - use form settings if override is enabled, otherwise use defaults
        if ($override_email_settings) {
            $to_email = $settings['to_email'] ?? '';
            $cc_email = $settings['cc_email'] ?? get_option('sf_admin_email_cc', '');
            $bcc_email = $settings['bcc_email'] ?? get_option('sf_admin_email_bcc', '');
        } else {
            $to_email = get_option('sf_admin_email', get_option('admin_email'));
            $cc_email = get_option('sf_admin_email_cc', '');
            $bcc_email = get_option('sf_admin_email_bcc', '');
        }
        $to_email = Helper::sanitize_email_list($to_email);
        $cc_email = Helper::sanitize_email_list($cc_email);
        $bcc_email = Helper::sanitize_email_list($bcc_email);
        // translators: %s is the blog name.
        $email_subject = $override_email_settings ? ($settings['email_subject'] ?? '') : get_option('sf_default_email_subject', sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name')));
        $email_message = $override_email_settings ? ($settings['email_message'] ?? '') : get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro'));

        // Confirmation email settings - should work independently of override toggle
        $send_confirmation_email = !empty($settings['send_confirmation_email']);
        
        // Get confirmation subject - use form setting if not empty, otherwise use default
        $confirmation_subject = '';
        if (isset($settings['confirmation_subject']) && trim($settings['confirmation_subject']) !== '') {
            $confirmation_subject = $settings['confirmation_subject'];
        } else {
            $confirmation_subject = get_option('sf_default_confirmation_subject', __('Thank you for your submission', 'sigmaforms-pro'));
        }
        
        // Get confirmation message - use form setting if not empty, otherwise use default
        $confirmation_message = '';
        if (isset($settings['confirmation_message']) && trim($settings['confirmation_message']) !== '') {
            $confirmation_message = $settings['confirmation_message'];
        } else {
            $confirmation_message = get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro'));
        }

        // Check if email sending is enabled
        if (empty($to_email)) {
        
            return false;
        }
        
        // Check if email subject and message are set
        if (empty($email_subject) || empty($email_message)) {
       
            return false;
        }
        
        // Get SMTP configuration
        $smtp_config = get_option('sf_smtp_config', []);
        $external_smtp = $this->is_external_smtp_configured();
       
        // Configure SMTP if plugin SMTP is enabled and all fields are filled
        if (!empty($smtp_config['enabled']) && !empty($smtp_config['host']) && !empty($smtp_config['port']) && !empty($smtp_config['username']) && !empty($smtp_config['password'])) {
            add_action('phpmailer_init', function($phpmailer) use ($smtp_config) {
                $phpmailer->isSMTP();
                $phpmailer->Host = $smtp_config['host'];
                $phpmailer->SMTPAuth = true;
                $phpmailer->Port = $smtp_config['port'];
                $phpmailer->Username = $smtp_config['username'];
                $phpmailer->Password = $smtp_config['password'];
                // Set encryption
                if ($smtp_config['encryption'] === 'none') {
                    $phpmailer->SMTPSecure = '';
                    $phpmailer->SMTPAutoTLS = false;
                } else {
                    $phpmailer->SMTPSecure = $smtp_config['encryption'];
                }
                
            });
        }
        
        // Determine from email and name
        $from_email = Helper::get_email_from_address($smtp_config);
        $from_name = Helper::get_email_from_name();
        
        // Replace placeholders in subject and message
        $form_fields = isset($form_data['form_fields']) ? $form_data['form_fields'] : [];
        $subject = Helper::replace_placeholders($email_subject, $submission_data, $form_fields);
        $message = Helper::replace_placeholders($email_message, $submission_data, $form_fields);
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];
        // Replying to the notification answers the person who submitted the form.
        $headers = array_merge($headers, Helper::get_email_reply_to_header(Helper::find_submitter_email($submission_data, $form_fields)));
        $headers = array_merge($headers, Helper::get_email_cc_bcc_headers($cc_email, $bcc_email));
      
        $result = wp_mail($to_email, $subject, nl2br($message), $headers, $email_attachments);
        
        if ($result) {
            
        } else {
            
            // Check for common WordPress mail issues
            global $phpmailer;
            if (isset($phpmailer)) {
               
            }
        }
        
        // Send confirmation email if enabled
        if (!empty($send_confirmation_email)) {
            
            $this->send_confirmation_email($form_data, $submission_data, $from_email, $from_name, $confirmation_subject, $confirmation_message, $email_attachments);
        } else {
           
        }
        
        // Apply action hook for email sent
        do_action('sigmaforms_email_sent', $form_data['id'], $submission_data, $result);

        return $result;
    }
    
    /**
     * Send confirmation email to user
     *
     * @param array $form_data Form data
     * @param array $submission_data Submission data
     * @param string $from_email From email address
     * @param string $from_name From name
     * @param string $confirmation_subject Confirmation subject
     * @param string $confirmation_message Confirmation message
     * @param array $email_attachments Optional. Array of file paths for email attachments
     * @return bool True if email sent successfully
     */
    private function send_confirmation_email($form_data, $submission_data, $from_email, $from_name, $confirmation_subject, $confirmation_message, $email_attachments = []) {
        $settings = $form_data['form_settings'];
        
        // Check if confirmation email settings are complete - use defaults if empty
        if (empty($confirmation_subject)) {
            $confirmation_subject = get_option('sf_default_confirmation_subject', __('Thank you for your submission', 'sigmaforms-pro'));
        }
        if (empty($confirmation_message)) {
            $confirmation_message = get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro'));
        }
        
        // Find user email from submission data by checking field type
        $user_email = '';
        $form_fields = isset($form_data['form_fields']) ? $form_data['form_fields'] : [];
        
        // First, try to find email field by field type
        foreach ($form_fields as $field) {
            if (isset($field['type']) && $field['type'] === 'email' && isset($field['id'])) {
                $field_id = $field['id'];
                if (isset($submission_data[$field_id]) && !empty($submission_data[$field_id])) {
                    $user_email = sanitize_email($submission_data[$field_id]);
                    break;
                }
            }
        }
        
        // Fallback: check field IDs containing "email" (for backward compatibility)
        if (empty($user_email)) {
            foreach ($submission_data as $field_id => $value) {
                if (strpos($field_id, 'email') !== false || strpos($field_id, 'Email') !== false) {
                    $user_email = sanitize_email($value);
                    break;
                }
            }
        }
        
        if (empty($user_email)) {
            
            return false;
        }
        
        // Get SMTP configuration and apply it
        $smtp_config = get_option('sf_smtp_config', []);
        $external_smtp = $this->is_external_smtp_configured();
        
        // Configure SMTP if plugin SMTP is enabled and all fields are filled
        if (!empty($smtp_config['enabled']) && !empty($smtp_config['host']) && !empty($smtp_config['port']) && !empty($smtp_config['username']) && !empty($smtp_config['password'])) {
            add_action('phpmailer_init', function($phpmailer) use ($smtp_config) {
                $phpmailer->isSMTP();
                $phpmailer->Host = $smtp_config['host'];
                $phpmailer->SMTPAuth = true;
                $phpmailer->Port = $smtp_config['port'];
                $phpmailer->Username = $smtp_config['username'];
                $phpmailer->Password = $smtp_config['password'];
                // Set encryption
                if ($smtp_config['encryption'] === 'none') {
                    $phpmailer->SMTPSecure = '';
                    $phpmailer->SMTPAutoTLS = false;
                } else {
                    $phpmailer->SMTPSecure = $smtp_config['encryption'];
                }
                
            });
        }
        
        // Replace placeholders in confirmation subject and message
        $form_fields = isset($form_data['form_fields']) ? $form_data['form_fields'] : [];
        $subject = Helper::replace_placeholders($confirmation_subject, $submission_data, $form_fields);
        $message = Helper::replace_placeholders($confirmation_message, $submission_data, $form_fields);
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];
        // Replies from the visitor go to the site, not to the sending address.
        $headers = array_merge($headers, Helper::get_email_reply_to_header(Helper::get_site_contact_email()));
        
        $result = wp_mail($user_email, $subject, nl2br($message), $headers, $email_attachments);
        
        if ($result) {
            
        } else {
            
            // Check for common WordPress mail issues
            global $phpmailer;
            if (isset($phpmailer)) {
                
            }
        }
        
        // Apply action hook for confirmation email sent
        do_action('sigmaforms_confirmation_email_sent', $form_data['id'], $submission_data, $result);

        return $result;
    }
    
    /**
     * Check if SMTP is configured outside the plugin
     *
     * @return bool
     */
    private function is_external_smtp_configured() {
        // Check for common SMTP constants
        if (defined('WP_MAIL_SMTP_HOST') || defined('SMTP_HOST')) {
            return true;
        }
        // Check for popular SMTP plugins
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');
        if (function_exists('is_plugin_active')) {
            if (is_plugin_active('wp-mail-smtp/wp_mail_smtp.php') || is_plugin_active('easy-wp-smtp/easy-wp-smtp.php')) {
                return true;
            }
        }
        // Could add more checks for other plugins if needed
        return false;
    }
    
    
    /**
     * Process math functions for fields that have them enabled
     *
     * @param array $form_data Form data
     * @param array $submission_data Submission data (passed by reference)
     * @return void
     */
    private function process_math_functions($form_data, &$submission_data) {
        foreach ($form_data['form_fields'] as $field) {
            if (!isset($field['id']) || !isset($field['math']) || !isset($field['math']['enabled']) || !$field['math']['enabled']) {
                continue;
            }
            
            $field_id = $field['id'];
            $math_config = $field['math'];
            
            try {
                $result = $this->calculate_math_field($math_config, $submission_data);
                
                // Apply rounding if enabled
                if (isset($math_config['round_result']) && $math_config['round_result'] && isset($math_config['decimal_places'])) {
                    $decimal_places = intval($math_config['decimal_places']);
                    $result = round($result, $decimal_places);
                }
                
                // Update the submission data with the calculated result
                $submission_data[$field_id] = $result;
                
            } catch (Exception $e) {
               
            }
        }
    }
    
    /**
     * Calculate the result for a math function field
     *
     * @param array $math_config Math configuration
     * @param array $submission_data Current submission data
     * @return float|int The calculated result
     * @throws Exception If calculation fails
     */
    private function calculate_math_field($math_config, $submission_data) {
        $calculation_type = $math_config['calculation_type'];
        
        if ($calculation_type === 'custom') {
            return $this->evaluate_custom_formula($math_config['formula'], $submission_data);
        }
        
        // Handle predefined calculation types
        $selected_fields = isset($math_config['fields']) ? $math_config['fields'] : [];
        $field_values = [];
        
        // Get values from selected fields
        foreach ($selected_fields as $field_id) {
            if (isset($submission_data[$field_id])) {
                $value = $submission_data[$field_id];
                // Handle array values (checkboxes)
                if (is_array($value)) {
                    $value = implode(',', $value);
                }
                if ($value !== '' && is_numeric($value)) {
                    $field_values[] = floatval($value);
                }
            }
        }
        
        if (empty($field_values)) {
            return 0;
        }
        
        // Perform calculation based on type
        switch ($calculation_type) {
            case 'sum':
                return array_sum($field_values);
                
            case 'subtract':
                $result = $field_values[0];
                for ($i = 1; $i < count($field_values); $i++) {
                    $result -= $field_values[$i];
                }
                return $result;
                
            case 'multiply':
                return array_product($field_values);
                
            case 'divide':
                $result = $field_values[0];
                for ($i = 1; $i < count($field_values); $i++) {
                    if ($field_values[$i] == 0) {
                        throw new Exception('Division by zero');
                    }
                    $result /= $field_values[$i];
                }
                return $result;
                
            case 'percentage':
                if (count($field_values) >= 2) {
                    return ($field_values[0] / $field_values[1]) * 100;
                }
                return 0;
                
            case 'average':
                return array_sum($field_values) / count($field_values);
                
            default:
                throw new Exception('Unknown calculation type: ' . esc_html($calculation_type));
        }
    }
    
    /**
     * Evaluate a custom formula
     *
     * @param string $formula The custom formula string
     * @param array $submission_data Current submission data
     * @return float|int The calculated result
     * @throws Exception If formula evaluation fails
     */
    private function evaluate_custom_formula($formula, $submission_data) {
        if (empty($formula) || !is_string($formula)) {
            return 0;
        }
        
        // Replace field references [field_name] with actual values
        $processed_formula = preg_replace_callback('/\[([^\]]+)\]/', function($matches) use ($submission_data) {
            $field_id = $matches[1];
            if (isset($submission_data[$field_id])) {
                $value = $submission_data[$field_id];
                // Handle array values (checkboxes)
                if (is_array($value)) {
                    $value = implode(',', $value);
                }
                if ($value !== '' && is_numeric($value)) {
                    return floatval($value);
                }
            }
            return 0;
        }, $formula);
        
        // Replace mathematical operators with PHP equivalents
        $processed_formula = str_replace(['^', '%'], ['**', '/100'], $processed_formula);
        
        // Validate the formula contains only safe characters
        if (!preg_match('/^[0-9+\-*\/\s\(\)\.]+$/', $processed_formula)) {
            throw new Exception('Invalid characters in formula');
        }
        
        // Evaluate the formula safely
        // $result = eval('return ' . $processed_formula . ';');
        $result = (new \MathParser\StdMathParser())->parse($processed_formula)->accept(new \MathParser\Interpreting\Evaluator());
        
        if (!is_finite($result)) {
            throw new Exception('Formula result is not finite');
        }
        
        return $result;
    }
    
    /**
     * Get phone code for a country
     *
     * @param string $country_code Two-letter country code
     * @return string Phone code (e.g., '+880')
     */
    private function get_phone_code_for_country($country_code) {
        $phone_codes = array(
            'AF' => '+93', 'AL' => '+355', 'DZ' => '+213', 'AD' => '+376', 'AO' => '+244',
            'AG' => '+1-268', 'AR' => '+54', 'AM' => '+374', 'AU' => '+61', 'AT' => '+43',
            'AZ' => '+994', 'BS' => '+1-242', 'BH' => '+973', 'BD' => '+880', 'BB' => '+1-246',
            'BY' => '+375', 'BE' => '+32', 'BZ' => '+501', 'BJ' => '+229', 'BT' => '+975',
            'BO' => '+591', 'BA' => '+387', 'BW' => '+267', 'BR' => '+55', 'BN' => '+673',
            'BG' => '+359', 'BF' => '+226', 'BI' => '+257', 'CV' => '+238', 'KH' => '+855',
            'CM' => '+237', 'CA' => '+1', 'CF' => '+236', 'TD' => '+235', 'CL' => '+56',
            'CN' => '+86', 'CO' => '+57', 'KM' => '+269', 'CG' => '+242', 'CR' => '+506',
            'CI' => '+225', 'HR' => '+385', 'CU' => '+53', 'CY' => '+357', 'CZ' => '+420',
            'DK' => '+45', 'DJ' => '+253', 'DM' => '+1-767', 'DO' => '+1-809', 'EC' => '+593',
            'EG' => '+20', 'SV' => '+503', 'GQ' => '+240', 'ER' => '+291', 'EE' => '+372',
            'ET' => '+251', 'FJ' => '+679', 'FI' => '+358', 'FR' => '+33', 'GA' => '+241',
            'GM' => '+220', 'GE' => '+995', 'DE' => '+49', 'GH' => '+233', 'GR' => '+30',
            'GD' => '+1-473', 'GT' => '+502', 'GN' => '+224', 'GW' => '+245', 'GY' => '+592',
            'HT' => '+509', 'HN' => '+504', 'HU' => '+36', 'IS' => '+354', 'IN' => '+91',
            'ID' => '+62', 'IR' => '+98', 'IQ' => '+964', 'IE' => '+353', 'IL' => '+972',
            'IT' => '+39', 'JM' => '+1-876', 'JP' => '+81', 'JO' => '+962', 'KZ' => '+7',
            'KE' => '+254', 'KI' => '+686', 'KW' => '+965', 'KG' => '+996', 'LA' => '+856',
            'LV' => '+371', 'LB' => '+961', 'LS' => '+266', 'LR' => '+231', 'LY' => '+218',
            'LI' => '+423', 'LT' => '+370', 'LU' => '+352', 'MK' => '+389', 'MG' => '+261',
            'MW' => '+265', 'MY' => '+60', 'MV' => '+960', 'ML' => '+223', 'MT' => '+356',
            'MH' => '+692', 'MR' => '+222', 'MU' => '+230', 'MX' => '+52', 'FM' => '+691',
            'MD' => '+373', 'MC' => '+377', 'MN' => '+976', 'ME' => '+382', 'MA' => '+212',
            'MZ' => '+258', 'MM' => '+95', 'NA' => '+264', 'NR' => '+674', 'NP' => '+977',
            'NL' => '+31', 'NZ' => '+64', 'NI' => '+505', 'NE' => '+227', 'NG' => '+234',
            'KP' => '+850', 'NO' => '+47', 'OM' => '+968', 'PK' => '+92', 'PW' => '+680',
            'PA' => '+507', 'PG' => '+675', 'PY' => '+595', 'PE' => '+51', 'PH' => '+63',
            'PL' => '+48', 'PT' => '+351', 'QA' => '+974', 'RO' => '+40', 'RU' => '+7',
            'RW' => '+250', 'KN' => '+1-869', 'LC' => '+1-758', 'VC' => '+1-784', 'WS' => '+685',
            'SM' => '+378', 'ST' => '+239', 'SA' => '+966', 'SN' => '+221', 'RS' => '+381',
            'SC' => '+248', 'SL' => '+232', 'SG' => '+65', 'SK' => '+421', 'SI' => '+386',
            'SB' => '+677', 'SO' => '+252', 'ZA' => '+27', 'KR' => '+82', 'SS' => '+211',
            'ES' => '+34', 'LK' => '+94', 'SD' => '+249', 'SR' => '+597', 'SZ' => '+268',
            'SE' => '+46', 'CH' => '+41', 'SY' => '+963', 'TW' => '+886', 'TJ' => '+992',
            'TZ' => '+255', 'TH' => '+66', 'TL' => '+670', 'TG' => '+228', 'TO' => '+676',
            'TT' => '+1-868', 'TN' => '+216', 'TR' => '+90', 'TM' => '+993', 'TV' => '+688',
            'UG' => '+256', 'UA' => '+380', 'AE' => '+971', 'GB' => '+44', 'US' => '+1',
            'UY' => '+598', 'UZ' => '+998', 'VU' => '+678', 'VA' => '+379', 'VE' => '+58',
            'VN' => '+84', 'YE' => '+967', 'ZM' => '+260', 'ZW' => '+263'
        );
        
        return isset($phone_codes[$country_code]) ? $phone_codes[$country_code] : '';
    }
}
