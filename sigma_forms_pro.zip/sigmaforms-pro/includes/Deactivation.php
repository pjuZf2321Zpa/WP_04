<?php
/**
 * Deactivation class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms;

class Deactivation {
    /**
     * Run deactivation tasks
     *
     * @return void
     */
    public static function deactivate() {
        // Clear any scheduled hooks
        wp_clear_scheduled_hook('sf_daily_maintenance');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
