<?php
/**
 * Form Block class for SigmaForms
 *
 * Server side registration of the original "sigmaforms/form" block. The block
 * inserted from the editor today is "sigmaforms/form-block"
 * (see Widgets/GutenbergWidget.php); this one stays registered so content that
 * already contains it keeps rendering. Its editor script was uncompiled JSX
 * that never loaded, so it is no longer registered.
 *
 * @package SigmaForms
 */

namespace SigmaForms\Blocks;

class FormBlock {
    /**
     * Constructor
     */
    public function __construct() {
        // Register hooks
        add_action('init', [$this, 'register_block']);
    }

    /**
     * Register the Gutenberg block
     *
     * @return void
     */
    public function register_block() {
        // Skip if Gutenberg is not available
        if (!function_exists('register_block_type')) {
            return;
        }

        // Register block frontend style
        wp_register_style(
            'sf-block-style',
            SF_PLUGIN_URL . 'assets/css/blocks.css',
            [],
            SF_VERSION
        );

        // Register the block
        register_block_type('sigmaforms/form', [
            'style' => 'sf-block-style',
            'attributes' => [
                'formId' => [
                    'type' => 'number',
                    'default' => 0,
                ],
                'className' => [
                    'type' => 'string',
                    'default' => '',
                ],
            ],
            'render_callback' => [$this, 'render_block'],
        ]);
    }

    /**
     * Render the block on the frontend
     *
     * Goes through the [sigmaforms] shortcode, like the current block and the
     * Elementor widget, so the license check, theme stylesheet, field scripts
     * and view logging all apply here too.
     *
     * @param array $attributes Block attributes
     * @return string Block HTML
     */
    public function render_block($attributes) {
        $form_id = isset($attributes['formId']) ? (int) $attributes['formId'] : 0;
        $class_name = isset($attributes['className']) ? $attributes['className'] : '';

        // Bail if no form ID
        if ($form_id <= 0) {
            if (\SigmaForms\Utils\Helper::current_user_can_manage_forms()) {
                return '<div class="sf-block-notice">' .
                       wp_kses_post(sprintf(
                           // translators: %s is the URL to the form creation page.
                           __('Please select a form in the block settings. If you don\'t have any forms, please <a href="%s">create one</a>.', 'sigmaforms-pro'),
                           esc_url(admin_url('admin.php?page=sigmaforms-new'))
                       )) .
                       '</div>';
            }
            return '';
        }

        // A block pointing at a deleted form rendered nothing for visitors
        // before; keep that instead of the shortcode's "Form not found".
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One indexed lookup per legacy block render.
        $form_exists = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}sigmaforms WHERE id = %d", $form_id));

        if (!$form_exists) {
            return \SigmaForms\Utils\Helper::current_user_can_manage_forms()
                ? '<div class="sf-block-notice">' . esc_html__('The form selected in this block no longer exists.', 'sigmaforms-pro') . '</div>'
                : '';
        }

        // Add wrapper with class
        $wrapper_classes = 'sf-block-form-wrapper';
        if (!empty($class_name)) {
            $wrapper_classes .= ' ' . $class_name;
        }

        return '<div class="' . esc_attr($wrapper_classes) . '">' . do_shortcode('[sigmaforms id="' . $form_id . '"]') . '</div>';
    }
}
