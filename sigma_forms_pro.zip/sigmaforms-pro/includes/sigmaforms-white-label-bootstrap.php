<?php
/**
 * White-label constants when sf_white_label_enabled is on.
 *
 * @package SigmaForms
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Bootstrap-local variables, only used to define the constants below.
$wl_enabled = (bool) get_option('sf_white_label_enabled', false);

if (!defined('SIGMAFORMS_WHITE_LABEL_BRAND')) {
    $wl_title = $wl_enabled ? get_option('sf_white_label_title', '') : '';
    define('SIGMAFORMS_WHITE_LABEL_BRAND', is_string($wl_title) ? $wl_title : '');
}

if (!defined('SIGMAFORMS_LO')) {
    if ($wl_enabled && get_option('sf_white_label_hide_license', false)) {
        define('SIGMAFORMS_LO', true);
    }
}

if (!defined('SIGMAFORMS_HIDE_SETTINGS_MENU')) {
    if ($wl_enabled && get_option('sf_white_label_hide_admin', false)) {
        define('SIGMAFORMS_HIDE_SETTINGS_MENU', true);
    }
}

if (!defined('SIGMAFORMS_HIDE_WL_MENU')) {
    define('SIGMAFORMS_HIDE_WL_MENU', defined('SIGMAFORMS_HIDE_SETTINGS_MENU') && SIGMAFORMS_HIDE_SETTINGS_MENU);
}
