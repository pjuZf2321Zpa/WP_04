<?php
/**
 * AI Generator class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\AI;

use SigmaForms\Utils\Helper;

class AIGenerator {
    /**
     * API endpoint for OpenAI
     *
     * @var string
     */
    // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Calls the provider the site owner configured with their own API key; wp_ai_client_prompt() requires WP 7.0 and this plugin supports 6.0+.
    private $api_endpoint = 'https://api.openai.com/v1/chat/completions';

    /**
     * API model to use
     *
     * @var string
     */
    private $api_model = 'gpt-3.5-turbo';

    /**
     * Register REST API routes
     *
     * @return void
     */
    public function register_rest_routes() {
        register_rest_route('sigmaforms/v1', '/generate-form', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_generate_form'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
    }

    /**
     * REST API endpoint for generating a form
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_generate_form($request) {
        $prompt = sanitize_textarea_field($request->get_param('prompt'));

        if (empty($prompt)) {
            return new \WP_Error('invalid_prompt', __('Please provide a valid prompt.', 'sigmaforms-pro'), ['status' => 400]);
        }

        // Get the provider from the request or fallback to default
        $ai_provider = $request->get_param('ai_provider') ? sanitize_text_field($request->get_param('ai_provider')) : get_option('sf_ai_provider', 'openai');

        // Check if API key is configured for the specific provider
        $api_key = '';
        if ($ai_provider === 'openai') {
            $api_key = get_option('sf_api_key_openai', '');
        } elseif ($ai_provider === 'gemini') {
            $api_key = get_option('sf_api_key_gemini', '');
        } elseif ($ai_provider === 'claude') {
            $api_key = get_option('sf_api_key_claude', '');
        }

        if (empty($api_key)) {
            $provider_names = [
                'openai' => 'OpenAI',
                'gemini' => 'Gemini',
                'claude' => 'Claude'
            ];
            $provider_name = isset($provider_names[$ai_provider]) ? $provider_names[$ai_provider] : $ai_provider;
            // translators: %s is the name of the provider (e.g., OpenAI, Claude, etc.).
            return new \WP_Error('api_key_missing', sprintf(__('%s API key is not configured. Please set it in the plugin settings.', 'sigmaforms-pro'), $provider_name), ['status' => 400]);
        }

        $form_structure = $this->generate_form_from_prompt($prompt, $request);

        if (is_wp_error($form_structure)) {
            return $form_structure;
        }

        return rest_ensure_response([
            'success' => true,
            'form' => $form_structure,
        ]);
    }

    /**
     * Generate form structure from natural language prompt
     *
     * @param string $prompt User prompt
     * @param \WP_REST_Request|null $request REST API request
     * @return array|\WP_Error Form structure or error
     */
    public function generate_form_from_prompt($prompt, $request = null) {
        // Prefer REST request params if available, otherwise fallback to options
        if ($request instanceof \WP_REST_Request) {
            $ai_provider = $request->get_param('ai_provider') ? sanitize_text_field($request->get_param('ai_provider')) : get_option('sf_ai_provider', 'openai');
            $model = $request->get_param('ai_model') ? sanitize_text_field($request->get_param('ai_model')) : get_option('sf_ai_model_' . $ai_provider, 'gpt-3.5-turbo');
        } elseif (is_object($request) && isset($request->ai_provider)) {
            // Handle mock request object from AJAX
            $ai_provider = sanitize_text_field($request->ai_provider);
            $model = isset($request->ai_model) ? sanitize_text_field($request->ai_model) : get_option('sf_ai_model_' . $ai_provider, 'gpt-3.5-turbo');
        } else {
            $ai_provider = get_option('sf_ai_provider', 'openai');
            $model = get_option('sf_ai_model_' . $ai_provider, 'gpt-3.5-turbo');
        }

        $api_key_openai = get_option('sf_api_key_openai', '');
        $api_key_gemini = get_option('sf_api_key_gemini', '');
        $api_key_claude = get_option('sf_api_key_claude', '');

        $provider = $ai_provider;
        $api_key = '';
        $endpoint = '';
        $headers = [];
        $body = [];
        $parse_response = null;


        // Enhance the prompt with specific instructions for form generation
        $enhanced_prompt = $this->prepare_ai_prompt($prompt);

        if ($provider === 'openai') {
            $api_key = $api_key_openai;
            // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Calls the provider the site owner configured with their own API key; wp_ai_client_prompt() requires WP 7.0 and this plugin supports 6.0+.
            $endpoint = 'https://api.openai.com/v1/chat/completions';
            if (empty($api_key)) {
                return new \WP_Error('api_key_missing', __('AI generation is unavailable because your OpenAI API key is not configured. You can still create your form manually.', 'sigmaforms-pro'));
            }
            $headers = [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ];
            $body = [
                'model' => $model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'You are a form generation assistant that helps create web form structures. Respond only with valid JSON representing the form structure. The form structure should include fields, validations, and settings.',
                    ],
                    [
                        'role' => 'user',
                        'content' => $enhanced_prompt,
                    ],
                ],
                'temperature' => 0.7,
                'max_tokens' => 2048,
            ];
            $parse_response = function ($response_body) {
                $data = json_decode($response_body, true);
                if (!isset($data['choices'][0]['message']['content'])) {
                    return new \WP_Error('invalid_response', __('Invalid response from OpenAI API.', 'sigmaforms-pro'));
                }
                $content = $data['choices'][0]['message']['content'];
                if (preg_match('/```(?:json)?\s*([\s\S]*?)\s*```/m', $content, $matches)) {
                    $content = $matches[1];
                }
                $form_structure = json_decode($content, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    return new \WP_Error('json_error', __('Error parsing generated form structure.', 'sigmaforms-pro'));
                }
                return $form_structure;
            };
        } elseif ($provider === 'gemini') {
            $api_key = $api_key_gemini;
            // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Calls the provider the site owner configured with their own API key; wp_ai_client_prompt() requires WP 7.0 and this plugin supports 6.0+.
            $endpoint = 'https://generativelanguage.googleapis.com/v1/models/' . $model . ':generateContent?key=' . $api_key;
            if (empty($api_key)) {
                return new \WP_Error('api_key_missing', __('AI generation is unavailable because your Gemini API key is not configured. You can still create your form manually.', 'sigmaforms-pro'));
            }
            $headers = [
                'Content-Type' => 'application/json',
            ];
            $body = [
                'contents' => [
                    [
                        'role' => 'user',
                        'parts' => [
                            ['text' => $enhanced_prompt],
                        ],
                    ],
                ],
                'generationConfig' => [
                    'temperature' => 0.7,
                    'maxOutputTokens' => 2048,
                ],
            ];
            $parse_response = function ($response_body) {
                $data = json_decode($response_body, true);
                if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                    return new \WP_Error('invalid_response', __('Invalid response from Gemini API.', 'sigmaforms-pro'));
                }
                $content = $data['candidates'][0]['content']['parts'][0]['text'];
                if (preg_match('/```(?:json)?\s*([\s\S]*?)\s*```/m', $content, $matches)) {
                    $content = $matches[1];
                }
                $form_structure = json_decode($content, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    return new \WP_Error('json_error', __('Error parsing generated form structure.', 'sigmaforms-pro'));
                }
                return $form_structure;
            };
        } elseif ($provider === 'claude') {
            $api_key = $api_key_claude;
            // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Calls the provider the site owner configured with their own API key; wp_ai_client_prompt() requires WP 7.0 and this plugin supports 6.0+.
            $endpoint = 'https://api.anthropic.com/v1/messages';
            if (empty($api_key)) {
                return new \WP_Error('api_key_missing', __('AI generation is unavailable because your Claude API key is not configured. You can still create your form manually.', 'sigmaforms-pro'));
            }
            $headers = [
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type' => 'application/json',
            ];
            $body = [
                'model' => $model,
                'max_tokens' => 2048,
                'temperature' => 0.7,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $enhanced_prompt,
                    ],
                ],
            ];
            $parse_response = function ($response_body) {
                $data = json_decode($response_body, true);
                if (!isset($data['content'][0]['text'])) {
                    return new \WP_Error('invalid_response', __('Invalid response from Claude API.', 'sigmaforms-pro'));
                }
                $content = $data['content'][0]['text'];
                if (preg_match('/```(?:json)?\s*([\s\S]*?)\s*```/m', $content, $matches)) {
                    $content = $matches[1];
                }
                $form_structure = json_decode($content, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    return new \WP_Error('json_error', __('Error parsing generated form structure.', 'sigmaforms-pro'));
                }
                return $form_structure;
            };
        } else {
            return new \WP_Error('provider_not_supported', __('Selected AI provider is not supported.', 'sigmaforms-pro'));
        }

        $response = wp_remote_post($endpoint, [
            'headers' => $headers,
            'timeout' => 30,
            'body' => json_encode($body),
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        if ($response_code !== 200) {
            $error_message = __('AI generation is unavailable due to an API error. You can still create your form manually.', 'sigmaforms-pro');
            $data = json_decode($response_body, true);
            if (isset($data['error']['message'])) {
                $error_message .= ' (' . esc_html($data['error']['message']) . ')';
            }
            return new \WP_Error('api_error', $error_message, ['status' => $response_code]);
        }

        $form_structure = $parse_response($response_body);
        if (is_wp_error($form_structure)) {
            return $form_structure;
        }

        // Validate and normalize the form structure
        return $this->normalize_form_structure($form_structure);
    }

    /**
     * Prepare AI prompt with specific instructions
     *
     * @param string $user_prompt User's prompt
     * @return string Enhanced prompt with instructions
     */
    private function prepare_ai_prompt($user_prompt) {
        return "Generate a web form structure based on this request: \"{$user_prompt}\".

The response must be a valid JSON object with the following structure:
{
  \"title\": \"Form Name\",
  \"description\": \"Form description\",
  \"fields\": [
    {
      \"id\": \"unique_field_id\",
      \"type\": \"text|email|number|phone|textarea|select|checkbox|radio|date|file\",
      \"label\": \"Field Label\",
      \"placeholder\": \"Placeholder text\",
      \"required\": true|false,
      \"column_width\": \"100|75|66|50|33|25\",
      \"options\": [
        {\"value\": \"option_value\", \"label\": \"Option Label\"}
      ],
      \"validation\": {
        \"type\": \"text|email|number|phone|etc\",
        \"message\": \"Validation error message\"
      },
      \"conditional\": {
        \"show\": true|false,
        \"field\": \"dependent_field_id\",
        \"operator\": \"=|!=|>|<|contains\",
        \"value\": \"trigger_value\"
      }
    }
  ],
  \"settings\": {
    \"submit_button_text\": \"Submit\",
    \"success_message\": \"Thank you for your submission!\",
    \"email_subject\": \"New Form Submission\",
    \"store_submissions\": true
  }
}

Based on the form's purpose, suggest:
1. Appropriate field types (text, email, number, etc.)
2. Required validations
3. Clear labels and placeholders
4. Logical field order
5. Column layout options using column_width property (100=Full Width, 75=Three Quarters, 66=Two Thirds, 50=Half Width, 33=One Third, 25=One Quarter)
6. Conditional logic where appropriate

Important notes about column layout and conditional logic:
- If the user mentions fields being in the same row, set appropriate column_width values (usually 50% for two columns, 33% for three columns)
- If the prompt mentions that certain fields should only appear based on other field values, implement conditional logic
- For multi-column layouts, make sure the column_width values in each row add up to 100 or less
- Fields with conditional logic should have the relevant conditional settings configured

Return ONLY the JSON object with no additional text or explanations.";
    }

    /**
     * Normalize form structure to ensure all required fields are present
     *
     * @param array $form_structure Form structure from AI
     * @return array Normalized form structure
     */
    private function normalize_form_structure($form_structure) {
        if (!is_array($form_structure)) {
            return [
                'title' => __('New Form', 'sigmaforms-pro'),
                'fields' => [],
                'settings' => Helper::get_default_form_settings(),
            ];
        }

        $normalized = [
            'title' => isset($form_structure['title']) ? sanitize_text_field($form_structure['title']) : __('New Form', 'sigmaforms-pro'),
            'fields' => [],
            'settings' => Helper::get_default_form_settings(),
        ];

        // Normalize fields
        if (isset($form_structure['fields']) && is_array($form_structure['fields'])) {
            $normalized['fields'] = Helper::sanitize_form_fields($form_structure['fields']);
        }

        // Normalize settings
        if (isset($form_structure['settings']) && is_array($form_structure['settings'])) {
            $normalized['settings'] = Helper::sanitize_form_settings($form_structure['settings']);
        }

        return $normalized;
    }
}
