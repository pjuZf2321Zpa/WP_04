<?php

/**
 * AI Generator class for Sigma Forms
 *
 * @package SigmaForms
 */

namespace SigmaForms\AI;

use SigmaForms\Utils\Helper;

class SigmaAI {
    /**
     * API endpoint for OpenAI
     *
     * @var string
     */
    private $api_endpoint = 'https://ai.sigmative.com/api/prompt/v1/generation/chat/completions';

    /**
     * Register REST API routes
     *
     * @return void
     */
    public function register_rest_routes() {
        register_rest_route('sigmaforms/v1', '/generate-form', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_generate_form'],
            'permission_callback' => function () {
                return \SigmaForms\Utils\Helper::current_user_can_manage_forms();
            },
        ]);
    }

    /**
     * REST API endpoint for generating a form
     *
     * @param \WP_REST_Request $request REST API request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_generate_form($request) {
        $prompt = sanitize_textarea_field($request->get_param('prompt'));

        if (empty($prompt)) {
            return new \WP_Error('invalid_prompt', __('Please provide a valid prompt.', 'sigmaforms-pro'), ['status' => 400]);
        }

        $form_structure = $this->generate_form_from_prompt($prompt, $request);

        if (is_wp_error($form_structure)) {
            return $form_structure;
        }

        return rest_ensure_response([
            'success' => true,
            'form' => $form_structure,
        ]);
    }

    /**
     * Generate form structure from natural language prompt
     *
     * @param string $prompt User prompt
     * @param \WP_REST_Request|null $request REST API request
     * @return array|\WP_Error Form structure or error
     */
    public function generate_form_from_prompt($prompt, $request = null) {
        // Get API key from settings
        $api_key = get_option('sf_ai_api_key', '');
        
        if (empty($api_key)) {
            return new \WP_Error('api_key_missing', __('AI API key is not configured. Please set it in the plugin settings.', 'sigmaforms-pro'));
        }

        // Enhance the prompt with specific instructions for form generation
        $enhanced_prompt = $this->prepare_ai_prompt($prompt);

        $body = [
            'command' => $prompt,
            'context'     => $enhanced_prompt,
        ];

        $response = wp_remote_post(
            $this->api_endpoint,
            [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ],
                'body'    => wp_json_encode($body),
                'timeout' => 30,
                'sslverify' => false, // Disable SSL verification

            ]
        );


        if (is_wp_error($response)) {
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);

        if ($response_code !== 200) {
            $error_message = __('AI generation is unavailable due to an API error. You can still create your form manually.', 'sigmaforms-pro');
            $data = json_decode($response_body, true);
            if (isset($data['error']['message'])) {
                $error_message .= ' (' . esc_html($data['error']['message']) . ')';
            }
            return new \WP_Error('api_error', $error_message, ['status' => $response_code]);
        }

        $form_structure = $data['content'];

        if (is_wp_error($form_structure)) {
            return $form_structure;
        }

        // var_dump($form_structure);

        // Validate and normalize the form structure
        $normalized_structure = $this->normalize_form_structure($form_structure);
        
        // Include usage/token data if available
        if (isset($data['usage'])) {
            $normalized_structure['usage'] = $data['usage'];
        }
        
        return $normalized_structure;
    }

    /**
     * Prepare AI prompt with specific instructions
     *
     * @param string $user_prompt User's prompt
     * @return string Enhanced prompt with instructions
     */
    private function prepare_ai_prompt($user_prompt) {
        return "Generate a web form structure based on this request: \"{$user_prompt}\".

The response must be a valid JSON object with the following structure:
{
  \"title\": \"Form Name\",
  \"description\": \"Form description\",
  \"fields\": [
    {
      \"id\": \"unique_field_id\",
      \"type\": \"text|email|url|number|phone|phone_international|textarea|rich_text|range|select|country|radio|checkbox|date|file|signature|rating|section_heading|page_break\",
      \"label\": \"Field Label\",
      \"placeholder\": \"Placeholder text\",
      \"required\": true|false,
      \"column_width\": \"100|75|66|50|33|25\",
      \"options\": [
        {\"value\": \"option_value\", \"label\": \"Option Label\"}
      ],
      \"validation\": {
        \"type\": \"text|email|number|phone|etc\",
        \"message\": \"Validation error message\"
      },
      \"conditional\": {
        \"show\": true|false,
        \"field\": \"dependent_field_id\",
        \"operator\": \"=|!=|>|<|contains\",
        \"value\": \"trigger_value\"
      },
      \"show_underline\": true|false,
      \"underline_color\": \"#3b82f6\",
      \"underline_thickness\": \"3\",
      \"underline_style\": \"solid|dashed|dotted|double\",
      \"range_min\": \"0\",
      \"range_max\": \"100\",
      \"range_step\": \"1\",
      \"range_default\": \"50\",
      \"selected_countries\": [],
      \"default_country\": \"US\",
      \"selected_phone_countries\": [],
      \"allowed_file_types\": [\".pdf\", \".doc\", \".docx\", \".jpg\", \".jpeg\", \".png\"],
      \"storage_location\": \"site|email_attachment|google_drive|onedrive\"
    }
  ],
  \"settings\": {
    \"submit_button_text\": \"Submit\",
    \"success_message\": \"Thank you for your submission!\",
    \"email_subject\": \"New Form Submission\",
    \"store_submissions\": true
  }
}

Based on the form's purpose, suggest:
1. Appropriate field types:
   - text: Single-line text input
   - email: Email address with validation
   - url: Website URL with validation
   - number: Numeric input
   - phone: Basic phone number
   - phone_international: International phone with country selector
   - textarea: Multi-line text
   - rich_text: WYSIWYG editor for formatted text
   - range: Slider for numeric selection (requires range_min, range_max, range_step, range_default)
   - select: Dropdown selection (requires options array)
   - country: Country selector with flags (use selected_countries array to limit choices)
   - radio: Single choice from options (requires options array)
   - checkbox: Multiple choice from options (requires options array)
   - date: Date picker
   - file: File upload (always set allowed_file_types to a safe allow-list such as .pdf, .doc, .docx, .jpg, .jpeg, .png; never leave it empty)
   - signature: Digital signature capture (use storage_location)
   - rating: Star rating (1-5 stars)
   - section_heading: Visual heading to organize form sections
   - page_break: Split form into multiple pages/steps

2. Required validations
3. Clear labels and placeholders
4. Logical field order
5. Column layout options using column_width property (100=Full Width, 75=Three Quarters, 66=Two Thirds, 50=Half Width, 33=One Third, 25=One Quarter)
6. Conditional logic where appropriate
7. Section headings to organize form sections

Important notes about field types and properties:
- If the user mentions fields being in the same row, set appropriate column_width values (usually 50% for two columns, 33% for three columns)
- If the prompt mentions that certain fields should only appear based on other field values, implement conditional logic
- For multi-column layouts, make sure the column_width values in each row add up to 100 or less
- Use section_heading fields to organize forms into logical sections
- Section heading underline properties (show_underline, underline_color, underline_thickness, underline_style) are only for section_heading type
- Range fields require: range_min, range_max, range_step, range_default
- Country fields can use selected_countries array to limit available countries
- Phone international fields can use selected_phone_countries and default_country
- File and signature fields can specify storage_location (site, email_attachment, google_drive, onedrive)
- email_attachment: Files sent as email attachments only, not stored permanently anywhere
- Page breaks create multi-step forms

Return ONLY the JSON object with no additional text or explanations.";
    }

    /**
     * Normalize form structure to ensure all required fields are present
     *
     * @param array $form_structure Form structure from AI
     * @return array Normalized form structure
     */
    private function normalize_form_structure($form_structure) {
        if (is_string($form_structure)) {
            $form_structure = json_decode($form_structure, true);
        }

        if (! is_array($form_structure)) {
            return [
                'title'    => __('New Form', 'sigmaforms-pro'),
                'fields'   => [],
                'settings' => Helper::get_default_form_settings(),
            ];
        }

        $title = isset($form_structure['title'])
            ? sanitize_text_field($form_structure['title'])
            : __('New Form', 'sigmaforms-pro');

        $fields = [];
        if (isset($form_structure['fields']) && is_array($form_structure['fields'])) {
            $fields = Helper::sanitize_form_fields($form_structure['fields']);
        }

        $settings = Helper::get_default_form_settings();
        if (isset($form_structure['settings']) && is_array($form_structure['settings'])) {
            $settings = Helper::sanitize_form_settings($form_structure['settings']);
        }

        $normalized = [
            'title'    => $title,
            'fields'   => $fields,
            'settings' => $settings,
        ];

        return $normalized;
    }
}
