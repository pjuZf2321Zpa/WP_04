<?php

namespace SigmaForms\License;

use \SigmaForms\License\Base;
use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\WhiteLabel\WhiteLabelAdmin;
use SigmaForms\Admin\PageHeader;

class Forms extends Base {
    public $plugin_file = __FILE__;
    public $response_obj;
    public $license_message;
    public $show_message = false;
    public $slug = "sigmaforms";
    public $plugin_version = '';
    public $text_domain = '';
    function __construct() {
        add_action('admin_print_styles', [$this, 'set_admin_style']);
        $this->set_plugin_data();
        $main_lic_key = "SigmaForms_lic_Key";
        $lic_key_name = $this->get_lic_key_param($main_lic_key);
        $license_key = get_option($lic_key_name, "");
        if (empty($license_key)) {
            $license_key = get_option($main_lic_key, "");
            if (!empty($license_key)) {
                update_option($lic_key_name, $license_key) || add_option($lic_key_name, $license_key);
                update_option($main_lic_key, '');
            }
        }
        $lice_email = get_option("SigmaForms_lic_email", "");
        $this->add_on_delete(function () {
            update_option("SigmaForms_lic_Key", "");
        });
        if ($this->check_wp_plugin($license_key, $lice_email, $this->license_message, $this->response_obj, __FILE__)) {
            add_action('admin_menu', [$this, 'active_admin_menu'], 99999);
            add_action('admin_post_SigmaForms_el_deactivate_license', [$this, 'action_deactivate_license']);
            //$this->licenselMessage=$this->mess;
            //***Write you plugin's code here***

        } else {
            if (!empty($license_key) && !empty($this->license_message)) {
                $this->show_message = true;
            }
            update_option($license_key, "") || add_option($license_key, "");
            add_action('admin_post_SigmaForms_el_activate_license', [$this, 'action_activate_license']);
            add_action('admin_menu', [$this, 'inactive_menu'], 99999);
        }
    }
    public function set_plugin_data() {
        if (! function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        if (function_exists('get_plugin_data')) {
            $data = get_plugin_data($this->plugin_file, false, false);
            if (isset($data['Version'])) {
                $this->plugin_version = $data['Version'];
            }
            if (isset($data['TextDomain'])) {
                $this->text_domain = $data['TextDomain'];
            }
        }
    }
    private static function &get_server_array() {
        return $_SERVER;
    }
    private static function get_raw_domain() {
        if (function_exists("site_url")) {
            return site_url();
        }
        if (defined("WPINC") && function_exists("get_bloginfo")) {
            return get_bloginfo('url');
        } else {
            $server = self::get_server_array();
            if (! empty($server['HTTP_HOST']) && ! empty($server['SCRIPT_NAME'])) {
                $base_url  = ((isset($server['HTTPS']) && $server['HTTPS'] == 'on') ? 'https' : 'http');
                $base_url .= '://' . $server['HTTP_HOST'];
                $base_url .= str_replace(basename($server['SCRIPT_NAME']), '', $server['SCRIPT_NAME']);

                return $base_url;
            }
        }
        return '';
    }
    private static function get_raw_wp() {
        $domain = self::get_raw_domain();
        return preg_replace("(^https?://)", "", $domain);
    }
    public static function get_lic_key_param($key) {
        $raw_url = self::get_raw_wp();
        return $key . "_s" . hash('crc32b', $raw_url . "vtpbdapps");
    }
    public function set_admin_style() {
        wp_register_style("SigmaFormsLic", plugins_url("_lic_style.css", $this->plugin_file), 10, time());
        wp_enqueue_style("SigmaFormsLic");
    }
    public function active_admin_menu() {
        if (WhiteLabel::should_hide_license_nav() && !WhiteLabelAdmin::is_recovery_session()) {
            return;
        }

        $brand = WhiteLabel::get_display_name();

        add_submenu_page(
            $this->slug,
            sprintf(/* translators: %s brand name */ __('%s License', 'sigmaforms-pro'), $brand),
            __('License', 'sigmaforms-pro'),
            'activate_plugins',
            $this->slug . "_license",
            [$this, "activated"]
        );
    }
    public function inactive_menu() {
        if (WhiteLabel::should_hide_license_nav() && !WhiteLabelAdmin::is_recovery_session()) {
            return;
        }

        $brand = WhiteLabel::get_display_name();

        add_submenu_page(
            $this->slug,
            sprintf(/* translators: %s brand name */ __('%s License', 'sigmaforms-pro'), $brand),
            __('License', 'sigmaforms-pro'),
            'activate_plugins',
            $this->slug . "_license",
            [$this, 'license_form']
        );
    }
    function action_activate_license() {
        check_admin_referer('el-license');
        // Same capability as the License screen; admin-post runs for any logged-in user.
        if (!current_user_can('activate_plugins')) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'sigmaforms-pro'), '', array('back_link' => true, 'response' => 403));
        }
        $license_key = !empty($_POST['el_license_key']) ? sanitize_text_field(wp_unslash($_POST['el_license_key'])) : "";
        $license_email = !empty($_POST['el_license_email']) ? sanitize_email(wp_unslash($_POST['el_license_email'])) : "";
        $main_lic_key = "SigmaForms_lic_Key";
        $lic_key_name = $this->get_lic_key_param($main_lic_key);
        update_option($lic_key_name, $license_key) || add_option($lic_key_name, $license_key);
        update_option("SigmaForms_lic_email", $license_email) || add_option("SigmaForms_lic_email", $license_email);
        update_option('_site_transient_update_plugins', '');
        wp_safe_redirect(admin_url('admin.php?page=sigmaforms_license'));
        exit;
    }
    function action_deactivate_license() {
        check_admin_referer('el-license');
        // Same capability as the License screen; admin-post runs for any logged-in user.
        if (!current_user_can('activate_plugins')) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'sigmaforms-pro'), '', array('back_link' => true, 'response' => 403));
        }
        $message = "";
        $main_lic_key = "SigmaForms_lic_Key";
        $lic_key_name = $this->get_lic_key_param($main_lic_key);
        if ($this->remove_license_key(__FILE__, $message)) {
            update_option($lic_key_name, "") || add_option($lic_key_name, "");
            update_option('_site_transient_update_plugins', '');
        }
        wp_safe_redirect(admin_url('admin.php?page=sigmaforms_license'));
        exit;
    }
    function activated() {
        $brand = WhiteLabel::get_display_name();
?>
    <div class="sf-admin-wrap sf-license-page">
        <?php
        PageHeader::render();
        PageHeader::intro(
            array(
                'title'       => __('License', 'sigmaforms-pro'),
                'description' => sprintf(/* translators: %s brand name */ __('Your license is active. You can use all features of %s.', 'sigmaforms-pro'), $brand),
            )
        );
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="SigmaForms_el_deactivate_license" />
            <div class="sf-license-body">
                <ul class="sf-license-cards">
                    <li>
                        <div>
                            <span class="sf-license-card__label"><?php esc_html_e("Status", "sigmaforms-pro"); ?></span>

                            <?php if ($this->response_obj->is_valid) : ?>
                                <span class="sf-license-badge sf-license-badge--on"><?php esc_html_e("Valid", "sigmaforms-pro"); ?></span>
                            <?php else : ?>
                                <span class="sf-license-badge sf-license-badge--off"><?php esc_html_e("Invalid", "sigmaforms-pro"); ?></span>
                            <?php endif; ?>
                        </div>
                    </li>

                    <li>
                        <div>
                            <span class="sf-license-card__label"><?php esc_html_e("License Type", "sigmaforms-pro"); ?></span>
                            <span class="sf-license-card__value"><?php echo esc_html($this->response_obj->license_title); ?></span>
                        </div>
                    </li>

                    <li>
                        <div>
                            <span class="sf-license-card__label"><?php esc_html_e("License Expired on", "sigmaforms-pro"); ?></span>
                            <span class="sf-license-card__value">
                                <span class="sf-license-card__text"><?php echo esc_html($this->response_obj->expire_date); ?></span>
                                <?php if (!empty($this->response_obj->expire_renew_link)) : ?>
                                    <a target="_blank" class="sf-license-renew" href="<?php echo esc_url($this->response_obj->expire_renew_link); ?>"><?php esc_html_e('Renew', 'sigmaforms-pro'); ?></a>
                                <?php endif; ?>
                            </span>
                        </div>
                    </li>

                    <li>
                        <div>
                            <span class="sf-license-card__label"><?php esc_html_e("Support Expired on", "sigmaforms-pro"); ?></span>
                            <span class="sf-license-card__value">
                                <span class="sf-license-card__text"><?php echo esc_html($this->response_obj->support_end); ?></span>
                                <?php if (!empty($this->response_obj->support_renew_link)) : ?>
                                    <a target="_blank" class="sf-license-renew" href="<?php echo esc_url($this->response_obj->support_renew_link); ?>"><?php esc_html_e('Renew', 'sigmaforms-pro'); ?></a>
                                <?php endif; ?>
                            </span>
                        </div>
                    </li>

                    <li class="sf-license-card--key">
                        <div>
                            <span class="sf-license-card__label"><?php esc_html_e("Your License Key", "sigmaforms-pro"); ?></span>
                            <span class="sf-license-key"><?php echo esc_attr(substr($this->response_obj->license_key, 0, 9) . "XXXXXXXX-XXXXXXXX" . substr($this->response_obj->license_key, -9)); ?></span>
                        </div>
                        <div class="sf-license-actions sf-license-actions--danger">
                            <?php wp_nonce_field('el-license'); ?>
                            <?php submit_button(__('Deactivate License', 'sigmaforms-pro')); ?>
                        </div>
                    </li>
                </ul>
            </div>
        </form>
    </div>
    <?php
    }

    function license_form() {
        $brand = WhiteLabel::get_display_name();
    ?>
    <div class="sf-admin-wrap sf-license-page">
        <?php
        PageHeader::render();
        PageHeader::intro(
            array(
                'title'       => __('License', 'sigmaforms-pro'),
                'description' => sprintf(/* translators: %s brand name */ __('Activate your %s license to unlock all features.', 'sigmaforms-pro'), $brand),
            )
        );
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="SigmaForms_el_activate_license" />
            <div class="sf-license-body sf-license-body--form">
                <div class="sf-license-panel">
                    <?php
                    if (!empty($this->show_message) && !empty($this->license_message)) {
                    ?>
                        <div class="notice notice-error is-dismissible">
                            <p><?php echo esc_html($this->license_message); ?></p>
                        </div>
                    <?php
                    }
                    ?>
                    <div class="sf-license-lead">
                        <span class="sf-license-lead__icon"><?php echo PageHeader::icon('key'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <p class="sf-license-intro"><?php esc_html_e("Enter your license key here, to activate the product, and get full feature updates and premium support.", "sigmaforms-pro"); ?></p>
                    </div>
                    <div class="sf-license-fields">
                        <div class="sf-license-field">
                            <label for="el_license_email"><?php esc_html_e("Email Address", "sigmaforms-pro"); ?></label>
                            <?php
                            $purchase_email   = get_option("SigmaForms_lic_email", get_bloginfo('admin_email'));
                            ?>
                            <input type="text" id="el_license_email" class="regular-text code" name="el_license_email" size="50" value="<?php echo esc_attr($purchase_email); ?>" placeholder="" required="required">
                        </div>
                        <div class="sf-license-field">
                            <label for="el_license_key"><?php esc_html_e("License Key", "sigmaforms-pro"); ?></label>
                            <input type="text" id="el_license_key" class="regular-text code" name="el_license_key" size="50" placeholder="xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx" required="required">
                        </div>
                    </div>
                    <p class="sf-license-help"><?php esc_html_e("You can find your license key in your account dashboard or purchase confirmation email.", "sigmaforms-pro"); ?></p>
                </div>
                <div class="sf-license-actions">
                    <?php wp_nonce_field('el-license'); ?>
                    <?php submit_button(__('Activate License', 'sigmaforms-pro')); ?>
                </div>
            </div>
        </form>
    </div>
<?php
    }
}
