<?php
/**
 * REST: White label configuration (tier-gated).
 *
 * @package SigmaForms
 */

namespace SigmaForms\Rest;

use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\WhiteLabel\WhiteLabelAdmin;
use WP_REST_Request;
use WP_REST_Server;

if (!defined('ABSPATH')) {
    exit;
}

class WhiteLabelController {

    /**
     * @return void
     */
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    /**
     * @return void
     */
    public function register_routes() {
        register_rest_route(
            'sigmaforms/v1',
            '/white-label',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_white_label'),
                    'permission_callback' => array($this, 'check_manage_options'),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'save_white_label'),
                    'permission_callback' => array($this, 'check_eligible_manage'),
                ),
            )
        );

        register_rest_route(
            'sigmaforms/v1',
            '/white-label/revoke-token',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'revoke_token'),
                    'permission_callback' => array($this, 'check_eligible_manage'),
                ),
            )
        );
    }

    /**
     * @return bool
     */
    public function check_manage_options() {
        return current_user_can('manage_options');
    }

    /**
     * @return bool|\WP_Error
     */
    public function check_eligible_manage() {
        if (!current_user_can('manage_options')) {
            return new \WP_Error('forbidden', __('Permission denied.', 'sigmaforms-pro'), array('status' => 403));
        }
        if (!WhiteLabel::is_white_label_license()) {
            return new \WP_Error(
                'sf_wl_not_eligible',
                __('Your license does not include white label features.', 'sigmaforms-pro'),
                array('status' => 403)
            );
        }
        return true;
    }

    /**
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response
     */
    public function get_white_label($request) {
        $token_row = get_option(WhiteLabel::OPTION_ACCESS_TOKEN, array());

        $localhost = get_option(WhiteLabel::OPTION_LOCALHOST_EMAIL, null);
        $localhost_preview = null;
        $hide_admin = (bool) get_option(WhiteLabel::OPTION_HIDE_ADMIN, false);
        if ($hide_admin && is_array($localhost) && !empty($localhost['access_url'])) {
            $localhost_preview = array(
                'access_url' => (string) $localhost['access_url'],
                'message'    => isset($localhost['message']) ? (string) $localhost['message'] : '',
            );
        }

        return rest_ensure_response(
            array(
                'success'           => true,
                'eligible'          => WhiteLabel::is_white_label_license(),
                'enabled'           => (bool) get_option(WhiteLabel::OPTION_ENABLED, false),
                'hide_license'      => (bool) get_option(WhiteLabel::OPTION_HIDE_LICENSE, false),
                'hide_admin'        => (bool) get_option(WhiteLabel::OPTION_HIDE_ADMIN, false),
                'title'             => (string) get_option(WhiteLabel::OPTION_TITLE, ''),
                'icon'              => (string) get_option(WhiteLabel::OPTION_ICON, ''),
                'icon_id'           => (int) get_option(WhiteLabel::OPTION_ICON_ID, 0),
                'logo'              => (string) get_option(WhiteLabel::OPTION_LOGO, ''),
                'logo_id'           => (int) get_option(WhiteLabel::OPTION_LOGO_ID, 0),
                'has_access_token'  => !empty($token_row) && is_array($token_row) && !empty($token_row['token']),
                'localhost_preview' => $localhost_preview,
            )
        );
    }

    /**
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response|\WP_Error
     */
    public function save_white_label($request) {
        $params = $request->get_json_params();
        if (!is_array($params)) {
            $params = array();
        }

        $enabled      = !empty($params['enabled']);
        $hide_license = !empty($params['hide_license']);
        $hide_admin   = !empty($params['hide_admin']);
        $title        = isset($params['title']) ? sanitize_text_field($params['title']) : '';
        $icon         = isset($params['icon']) ? esc_url_raw($params['icon']) : '';
        $icon_id      = isset($params['icon_id']) ? absint($params['icon_id']) : 0;
        $logo         = isset($params['logo']) ? esc_url_raw($params['logo']) : '';
        $logo_id      = isset($params['logo_id']) ? absint($params['logo_id']) : 0;

        update_option(WhiteLabel::OPTION_ENABLED, $enabled);
        update_option(WhiteLabel::OPTION_HIDE_LICENSE, $hide_license);
        update_option(WhiteLabel::OPTION_HIDE_ADMIN, $hide_admin);
        update_option(WhiteLabel::OPTION_TITLE, $title);
        update_option(WhiteLabel::OPTION_ICON, $icon);
        update_option(WhiteLabel::OPTION_ICON_ID, $icon_id);
        update_option(WhiteLabel::OPTION_LOGO, $logo);
        update_option(WhiteLabel::OPTION_LOGO_ID, $logo_id);

        if ($enabled) {
            update_option(WhiteLabel::OPTION_LICENSE_TITLE_STATUS, true);
        } else {
            delete_option(WhiteLabel::OPTION_LICENSE_TITLE_STATUS);
            delete_option(WhiteLabel::OPTION_ACCESS_TOKEN);
            delete_option(WhiteLabel::OPTION_LOCALHOST_EMAIL);
        }

        $email_sent = false;
        if ($enabled && $hide_admin) {
            $email_sent = WhiteLabelAdmin::send_recovery_email();
        }

        return rest_ensure_response(
            array(
                'success'    => true,
                'message'    => __('White label settings saved.', 'sigmaforms-pro'),
                'email_sent' => $email_sent,
                'settings'   => $this->get_white_label($request)->get_data(),
            )
        );
    }

    /**
     * @param WP_REST_Request $request Request.
     * @return \WP_REST_Response|\WP_Error
     */
    public function revoke_token($request) {
        if (!WhiteLabel::revoke_access_token()) {
            return new \WP_Error(
                'sf_no_token',
                __('No active recovery token found.', 'sigmaforms-pro'),
                array('status' => 400)
            );
        }

        return rest_ensure_response(
            array(
                'success' => true,
                'message' => __('Recovery token revoked.', 'sigmaforms-pro'),
            )
        );
    }
}
