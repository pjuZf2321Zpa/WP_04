<?php
/**
 * Webhook Handler for SigmaForms
 * 
 * Handles sending form submissions to various webhook services
 */

namespace SigmaForms\Utils;

class WebhookHandler {
    
    /**
     * Webhooks waiting to be sent once the response has gone out.
     *
     * @var array
     */
    private static $queue = [];

    /**
     * Send a submission's webhooks after the visitor has their response.
     *
     * Webhooks used to be sent one after another while the visitor waited
     * for the submission to finish. On PHP-FPM, fastcgi_finish_request()
     * closes the connection first; elsewhere they still run at the end of
     * the same request, as before. Requires a valid license, on every path.
     *
     * @param int   $form_id            Form ID.
     * @param array $form_data          Submitted values.
     * @param array $form_data_complete Full form data (title, settings).
     * @return void
     */
    public static function queue($form_id, $form_data, $form_data_complete) {
        if (!\SigmaForms\Plugin::is_license_valid()) {
            return;
        }

        if (empty(self::$queue)) {
            // After WordPress flushes output buffers on shutdown (priority 1).
            add_action('shutdown', [__CLASS__, 'send_queued'], 20);
        }

        self::$queue[] = [$form_id, $form_data, $form_data_complete];
    }

    /**
     * Shutdown callback: release the visitor's connection, then send.
     *
     * @return void
     */
    public static function send_queued() {
        $queue = self::$queue;
        self::$queue = [];

        if (empty($queue)) {
            return;
        }

        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }

        foreach ($queue as $item) {
            self::process_webhooks($item[0], $item[1], $item[2]);
        }
    }

    /**
     * Process webhooks for a form submission
     * 
     * @param int $form_id The form ID
     * @param array $form_data The submitted form data
     * @param array $form_data_complete The complete form data including title and settings
     * @return array Results of webhook processing
     */
    public static function process_webhooks($form_id, $form_data, $form_data_complete) {
        $results = [];
        
        // Get global webhook settings
        $global_settings = get_option('sigmaforms_settings', []);
        
        // Extract form settings and title from complete form data
        $form_settings = isset($form_data_complete['form_settings']) ? $form_data_complete['form_settings'] : [];
        $form_title = isset($form_data_complete['title']) ? $form_data_complete['title'] : 'Unknown Form';
        $form_fields = isset($form_data_complete['form_fields']) ? $form_data_complete['form_fields'] : [];
        
        // Process form data to convert signatures to URLs for webhooks
        $processed_form_data = \SigmaForms\Utils\Helper::process_form_data_for_webhooks($form_data, $form_fields);
        
        // Format data with field labels for display (used by Slack, Discord, Telegram)
        $formatted_form_data = \SigmaForms\Utils\Helper::format_data_with_labels($processed_form_data, $form_fields);
        
        // Process each webhook type
        $webhook_types = [
            'google_sheets' => 'Google Sheets',
            'slack' => 'Slack',
            'discord' => 'Discord',
            'telegram' => 'Telegram',
            'custom' => 'Custom Webhook'
        ];
        
        foreach ($webhook_types as $webhook_key => $webhook_name) {
            $use_key = "webhook_{$webhook_key}_use";
            $global_enabled_key = "webhook_{$webhook_key}_enabled";
            
            // Check if webhook is enabled for this specific form
            $form_enabled = isset($form_settings[$use_key]) && $form_settings[$use_key] === true;
            
            // Process webhook ONLY if it's enabled for this specific form
            if ($form_enabled) {
                try {
                    // Google Sheets needs field IDs for column mapping, others use labels
                    $data_to_send = ($webhook_key === 'google_sheets') ? $processed_form_data : $formatted_form_data;
                    $results[$webhook_key] = self::send_webhook($webhook_key, $form_id, $data_to_send, $form_settings, $global_settings);

                } catch (Exception $e) {
                    $results[$webhook_key] = [
                        'success' => false,
                        'message' => 'Exception: ' . $e->getMessage(),
                        'response' => null
                    ];
                }
            }
        }
        return $results;
    }
    
    /**
     * Send webhook to specific service
     * 
     * @param string $webhook_type The webhook type
     * @param int $form_id The form ID
     * @param array $form_data The form data
     * @param array $form_settings The form settings
     * @param array $global_settings The global settings
     * @return array Result of webhook sending
     */
    private static function send_webhook($webhook_type, $form_id, $form_data, $form_settings, $global_settings) {
        $result = [
            'success' => false,
            'message' => '',
            'response' => null
        ];
        
        try {
            switch ($webhook_type) {
                case 'google_sheets':
                    $result = self::send_google_sheets_webhook($form_id, $form_data, $form_settings, $global_settings);
                    break;
                    

                    
                case 'slack':
                    $result = self::send_slack_webhook($form_id, $form_data, $form_settings, $global_settings);
                    break;
                    
                case 'discord':
                    $result = self::send_discord_webhook($form_id, $form_data, $form_settings, $global_settings);
                    break;
                    
                case 'telegram':
                    $result = self::send_telegram_webhook($form_id, $form_data, $form_settings, $global_settings);
                    break;
                    
                case 'custom':
                    $result = self::send_custom_webhook($form_id, $form_data, $form_settings, $global_settings);
                    break;
            }
        } catch (Exception $e) {
            $result['message'] = 'Error: ' . $e->getMessage();
        }
        
        return $result;
    }
    
    /**
     * Send webhook to Google Sheets
     */
    private static function send_google_sheets_webhook($form_id, $form_data, $form_settings, $global_settings) {
        $url = self::get_webhook_url('google_sheets', $form_settings, $global_settings);
        
        if (empty($url)) {
            return ['success' => false, 'message' => 'Google Sheets webhook URL not configured'];
        }
        
        // Get form title from the complete form data
        $form_title = self::get_form_title($form_id);
        
        // For Google Sheets, send form data at the top level so it can be mapped directly to columns
        $payload = array_merge($form_data, [
            'form_id' => $form_id,
            'form_title' => $form_title,
            'data' => $form_data,
            'submission_time' => current_time('mysql')
        ]);
        
        return self::make_webhook_request($url, $payload, 'POST');
    }
    

    
    /**
     * Send webhook to Slack
     */
    private static function send_slack_webhook($form_id, $form_data, $form_settings, $global_settings) {
        $url = self::get_webhook_url('slack', $form_settings, $global_settings);
        
        if (empty($url)) {
            return ['success' => false, 'message' => 'Slack webhook URL not configured'];
        }
        
        $channel = self::get_webhook_setting('slack', 'channel', $form_settings, $global_settings);
        
        // Get form title
        $form_title = self::get_form_title($form_id);
        
        $message = "New form submission from: *{$form_title}*\n";
        $message .= "Form ID: `{$form_id}`\n";
        $message .= "Submitted: " . current_time('mysql') . "\n\n";
        
        foreach ($form_data as $field => $value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            
            $value = self::format_value_for_platform($value, 'slack');
            $message .= "*{$field}:* {$value}\n";
        }
        
        $payload = [
            'text' => $message,
            'channel' => $channel ?: '#general'
        ];
        
        return self::make_webhook_request($url, $payload, 'POST');
    }
    
    /**
     * Send webhook to Discord
     */
    private static function send_discord_webhook($form_id, $form_data, $form_settings, $global_settings) {
        $url = self::get_webhook_url('discord', $form_settings, $global_settings);
        
        if (empty($url)) {
            return ['success' => false, 'message' => 'Discord webhook URL not configured'];
        }
        
        // Get form title
        $form_title = self::get_form_title($form_id);
        
        $message = "**New form submission from: {$form_title}**\n";
        $message .= "Form ID: `{$form_id}`\n";
        $message .= "Submitted: " . current_time('mysql') . "\n\n";
        
        foreach ($form_data as $field => $value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            
            $value = self::format_value_for_platform($value, 'discord');
            $message .= "**{$field}:** {$value}\n";
        }
        
        $payload = [
            'content' => $message
        ];
        
        return self::make_webhook_request($url, $payload, 'POST');
    }
    
    /**
     * Send webhook to Telegram
     */
    private static function send_telegram_webhook($form_id, $form_data, $form_settings, $global_settings) {
        $bot_token = self::get_webhook_setting('telegram', 'bot_token', $form_settings, $global_settings);
        $chat_id = self::get_webhook_setting('telegram', 'chat_id', $form_settings, $global_settings);
        
        if (empty($bot_token) || empty($chat_id)) {
            return ['success' => false, 'message' => 'Telegram bot token or chat ID not configured'];
        }
        
        // Get form title
        $form_title = self::get_form_title($form_id);
        
        $message = "🆕 *New form submission*\n\n";
        $message .= "*Form:* {$form_title}\n";
        $message .= "*Form ID:* `{$form_id}`\n";
        $message .= "*Submitted:* " . current_time('mysql') . "\n\n";
        
        foreach ($form_data as $field => $value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            
            $value = self::format_value_for_platform($value, 'telegram');
            $message .= "*{$field}:* {$value}\n";
        }
        
        $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
        $payload = [
            'chat_id' => $chat_id,
            'text' => $message,
            'parse_mode' => 'Markdown'
        ];
        
        return self::make_webhook_request($url, $payload, 'POST');
    }
    
    /**
     * Send custom webhook
     */
    private static function send_custom_webhook($form_id, $form_data, $form_settings, $global_settings) {
        $url = self::get_webhook_url('custom', $form_settings, $global_settings);
        $method = self::get_webhook_setting('custom', 'method', $form_settings, $global_settings) ?: 'POST';
        
        if (empty($url)) {
            return ['success' => false, 'message' => 'Custom webhook URL not configured'];
        }
        
        // Get form title
        $form_title = self::get_form_title($form_id);
        
        $payload = [
            'form_id' => $form_id,
            'form_title' => $form_title,
            'submission_time' => current_time('mysql'),
            'data' => $form_data
        ];
        
        return self::make_webhook_request($url, $payload, strtoupper($method));
    }
    
    /**
     * Get webhook URL from form settings (only called when webhook is enabled for this form)
     */
    private static function get_webhook_url($webhook_type, $form_settings, $global_settings) {
        $form_key = "webhook_{$webhook_type}_url";
        
        // Return form-specific URL if set, otherwise empty (no fallback to global)
        return $form_settings[$form_key] ?? '';
    }
    
    /**
     * Get form title by form ID
     */
    private static function get_form_title($form_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'sigmaforms';
        $getFormTitleQuery = "SELECT title FROM {$table} WHERE id = %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $title = $wpdb->get_var($wpdb->prepare($getFormTitleQuery, $form_id));
        return $title ?: 'Unknown Form';
    }
    
    /**
     * Get webhook setting from form settings (only called when webhook is enabled for this form)
     */
    private static function get_webhook_setting($webhook_type, $setting, $form_settings, $global_settings) {
        $form_key = "webhook_{$webhook_type}_{$setting}";
        
        // Return form-specific setting if set, otherwise empty (no fallback to global)
        return $form_settings[$form_key] ?? '';
    }
    
    /**
     * Make HTTP request to webhook URL
     */
    private static function make_webhook_request($url, $payload, $method = 'POST') {
        $args = [
            'method' => $method,
            // Sent after the response (see queue()), but still in a PHP worker,
            // once per enabled webhook, so a hung endpoint must not hold it long.
            'timeout' => 15,
            'headers' => [
                'Content-Type' => 'application/json',
                'User-Agent' => 'SigmaForms/1.0'
            ],
            'body' => json_encode($payload)
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            
            // Provide more user-friendly error messages
            if (strpos($error_message, 'cURL error 6') !== false) {
                $error_message = 'Could not resolve host. Please check if the URL is correct and accessible.';
            } elseif (strpos($error_message, 'cURL error 28') !== false) {
                $error_message = 'Request timeout. The webhook server took too long to respond.';
            } elseif (strpos($error_message, 'cURL error 7') !== false) {
                $error_message = 'Failed to connect to the webhook server. Please check the URL and try again.';
            } elseif (strpos($error_message, 'cURL error 35') !== false) {
                $error_message = 'SSL/TLS connection failed. Please check if the URL uses the correct protocol (http:// or https://).';
            }
            
            return [
                'success' => false,
                'message' => $error_message,
                'response' => null
            ];
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code >= 200 && $status_code < 300) {
            return [
                'success' => true,
                'message' => 'Webhook test successful! The connection is working properly.',
                'response' => [
                    'status_code' => $status_code,
                    'body' => $body
                ]
            ];
        } else {
            // Provide more specific error messages based on status codes
            $status_message = self::get_http_status_message($status_code);
            $error_message = "HTTP {$status_code}: {$status_message}";
            
            if (!empty($body)) {
                $error_message .= " - " . substr($body, 0, 100) . (strlen($body) > 100 ? '...' : '');
            }
            
            return [
                'success' => false,
                'message' => $error_message,
                'response' => [
                    'status_code' => $status_code,
                    'body' => $body
                ]
            ];
        }
    }
    
    /**
     * Get user-friendly HTTP status messages
     */
    private static function get_http_status_message($status_code) {
        $messages = [
            400 => 'Bad Request - The webhook server could not understand the request',
            401 => 'Unauthorized - Authentication is required',
            403 => 'Forbidden - Access to the webhook is denied',
            404 => 'Not Found - The webhook URL does not exist',
            405 => 'Method Not Allowed - The HTTP method is not supported',
            408 => 'Request Timeout - The webhook server took too long to respond',
            429 => 'Too Many Requests - Rate limit exceeded',
            500 => 'Internal Server Error - The webhook server encountered an error',
            502 => 'Bad Gateway - The webhook server is temporarily unavailable',
            503 => 'Service Unavailable - The webhook server is temporarily down',
            504 => 'Gateway Timeout - The webhook server took too long to respond'
        ];
        
        return $messages[$status_code] ?? 'Unknown error occurred';
    }
    

    
    /**
     * Format value for specific platform (handling HTML content)
     * 
     * @param mixed $value The value to format
     * @param string $platform The target platform (slack, discord, telegram)
     * @return mixed Formatted value
     */
    private static function format_value_for_platform($value, $platform) {
        // wp_strip_all_tags() trims, so compare against the trimmed original to detect markup only.
        if (!is_string($value) || wp_strip_all_tags($value) === trim($value)) {
            return $value;
        }

        // Basic HTML to Markdown conversion
        $markdown = $value;
        
        // Pre-process underline styles to <u> tags
        $markdown = preg_replace('/<span[^>]*style=["\'][^"\']*text-decoration:\s*underline[^"\']*["\'][^>]*>(.*?)<\/span>/is', '<u>$1</u>', $markdown);
        
        // Replace <br> and <p> with newlines
        $markdown = preg_replace('/<br\s*\/?>/i', "\n", $markdown);
        $markdown = preg_replace('/<\/p>/i', "\n\n", $markdown);
        $markdown = preg_replace('/<\/div>/i', "\n", $markdown);
        
        // Blockquotes
        $markdown = preg_replace('/<blockquote[^>]*>(.*?)<\/blockquote>/is', "> $1\n\n", $markdown);
        
        // Handle ordered lists by replacing <li> inside <ol> with "1. "
        // Note: Simple regex can't count, so we use "1." for all items and let markdown renderers handle it
        // or just use it as a simple list.
        if (preg_match_all('/<ol[^>]*>(.*?)<\/ol>/is', $markdown, $matches)) {
            foreach ($matches[1] as $key => $content) {
                // Replace <li> with "1. " inside the ordered list content
                $converted_list = preg_replace('/<li[^>]*>(.*?)<\/li>/is', "1. $1\n", $content);
                // Replace the original <ol> block with the converted content
                $markdown = str_replace($matches[0][$key], $converted_list . "\n", $markdown);
            }
        }

        // Platform specific formatting
        switch ($platform) {
            case 'slack':
                // Bold
                $markdown = preg_replace('/<(strong|b)>(.*?)<\/\1>/is', '*$2*', $markdown);
                // Italic
                $markdown = preg_replace('/<(em|i)>(.*?)<\/\1>/is', '_$2_', $markdown);
                // Strike
                $markdown = preg_replace('/<(del|s|strike)>(.*?)<\/\1>/is', '~$2~', $markdown);
                // Links
                $markdown = preg_replace('/<a href="(.*?)">(.*?)<\/a>/is', '<$1|$2>', $markdown);
                // Lists
                $markdown = preg_replace('/<li>(.*?)<\/li>/is', "• $1\n", $markdown);
                break;
                
            case 'discord':
                // Bold
                $markdown = preg_replace('/<(strong|b)>(.*?)<\/\1>/is', '**$2**', $markdown);
                // Italic
                $markdown = preg_replace('/<(em|i)>(.*?)<\/\1>/is', '*$2*', $markdown);
                // Strike
                $markdown = preg_replace('/<(del|s|strike)>(.*?)<\/\1>/is', '~~$2~~', $markdown);
                // Underline
                $markdown = preg_replace('/<u.*?>(.*?)<\/u>/is', '__$1__', $markdown);
                // Lists
                $markdown = preg_replace('/<li>(.*?)<\/li>/is', "• $1\n", $markdown);
                break;
                
            case 'telegram':
                // Bold
                $markdown = preg_replace('/<(strong|b)>(.*?)<\/\1>/is', '*$2*', $markdown);
                // Italic
                $markdown = preg_replace('/<(em|i)>(.*?)<\/\1>/is', '_$2_', $markdown);
                // Links
                $markdown = preg_replace('/<a href="(.*?)">(.*?)<\/a>/is', '[$2]($1)', $markdown);
                // Lists
                $markdown = preg_replace('/<li>(.*?)<\/li>/is', "• $1\n", $markdown);
                break;
        }
        
        // Strip remaining tags
        $markdown = wp_strip_all_tags($markdown);
        
        // Clean up excessive newlines
        $markdown = preg_replace('/\n{3,}/', "\n\n", $markdown);
        
        return trim($markdown);
    }
    
    /**
     * Validate webhook settings
     */
    public static function validate_webhook_settings($webhook_type, $settings) {
        $errors = [];
        
        switch ($webhook_type) {
            case 'google_sheets':
            case 'slack':
            case 'discord':
            case 'custom':
                $url_key = "webhook_{$webhook_type}_url";
                if (empty($settings[$url_key])) {
                    $errors[] = "Webhook URL is required";
                } elseif (!filter_var($settings[$url_key], FILTER_VALIDATE_URL)) {
                    $errors[] = "Invalid webhook URL format";
                }
                break;
                
            case 'telegram':
                if (empty($settings['webhook_telegram_bot_token'])) {
                    $errors[] = "Telegram bot token is required";
                }
                if (empty($settings['webhook_telegram_chat_id'])) {
                    $errors[] = "Telegram chat ID is required";
                }
                break;
        }
        
        return $errors;
    }
} 