<?php
/**
 * CAPTCHA Handler for SigmaForms
 * 
 * Handles different CAPTCHA services: reCAPTCHA, hCaptcha, Turnstile, CleanTalk, and mTCaptcha
 */

namespace SigmaForms\Utils;

class CaptchaHandler {
    
    /**
     * Validate CAPTCHA based on form settings
     * 
     * @param array $form_settings Form settings
     * @param array $submission_data Submission data
     * @return array Validation result
     */
    public static function validate_captcha($form_settings, $submission_data) {
        $result = [
            'valid' => true,
            'message' => '',
        ];
        
        // Check which CAPTCHA service is enabled
        $captcha_type = $form_settings['captcha_type'] ?? '';
        
        if (empty($captcha_type)) {
            // No CAPTCHA enabled
            return $result;
        }
        
        // First check if the captcha is properly configured
        $config_check = self::check_captcha_configuration($captcha_type);
        if (!$config_check['valid']) {
            return $config_check;
        }
        
        $validation_result = null;
        
        switch ($captcha_type) {
            case 'recaptcha':
                $validation_result = self::validate_recaptcha($submission_data);
                break;
            case 'hcaptcha':
                $validation_result = self::validate_hcaptcha($submission_data);
                break;
            case 'turnstile':
                $validation_result = self::validate_turnstile($submission_data);
                break;
            case 'cleantalk':
                $validation_result = self::validate_cleantalk($submission_data);
                break;
            case 'mtcaptcha':
                $validation_result = self::validate_mtcaptcha($submission_data);
                break;
            default:
                return [
                    'valid' => false,
                    'message' => __('Unknown CAPTCHA type.', 'sigmaforms-pro'),
                ];
        }
        
        return $validation_result ?: $result;
    }
    
    /**
     * Check if a captcha service is properly configured
     * 
     * @param string $captcha_type Captcha type
     * @return array Configuration check result
     */
    public static function check_captcha_configuration($captcha_type) {
        $global_settings = get_option('sigmaforms_settings', []);
        
        switch ($captcha_type) {
            case 'recaptcha':
                return self::check_recaptcha_configuration($global_settings);
            case 'hcaptcha':
                return self::check_hcaptcha_configuration($global_settings);
            case 'turnstile':
                return self::check_turnstile_configuration($global_settings);
            case 'cleantalk':
                return self::check_cleantalk_configuration($global_settings);
            case 'mtcaptcha':
                return self::check_mtcaptcha_configuration($global_settings);
            default:
                return [
                    'valid' => false,
                    'message' => __('Unknown CAPTCHA type.', 'sigmaforms-pro'),
                ];
        }
    }
    
    /**
     * Check reCAPTCHA configuration
     */
    private static function check_recaptcha_configuration($global_settings) {
        if (empty($global_settings['recaptcha_enabled'])) {
            return [
                'valid' => false,
                'message' => __('reCAPTCHA is not enabled in settings.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['recaptcha_site_key'])) {
            return [
                'valid' => false,
                'message' => __('reCAPTCHA site key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['recaptcha_secret_key'])) {
            return [
                'valid' => false,
                'message' => __('reCAPTCHA secret key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        return ['valid' => true, 'message' => ''];
    }
    
    /**
     * Check hCaptcha configuration
     */
    private static function check_hcaptcha_configuration($global_settings) {
        if (empty($global_settings['hcaptcha_enabled'])) {
            return [
                'valid' => false,
                'message' => __('hCaptcha is not enabled in settings.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['hcaptcha_site_key'])) {
            return [
                'valid' => false,
                'message' => __('hCaptcha site key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['hcaptcha_secret_key'])) {
            return [
                'valid' => false,
                'message' => __('hCaptcha secret key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        return ['valid' => true, 'message' => ''];
    }
    
    /**
     * Check Turnstile configuration
     */
    private static function check_turnstile_configuration($global_settings) {
        if (empty($global_settings['turnstile_enabled'])) {
            return [
                'valid' => false,
                'message' => __('Turnstile is not enabled in settings.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['turnstile_site_key'])) {
            return [
                'valid' => false,
                'message' => __('Turnstile site key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['turnstile_secret_key'])) {
            return [
                'valid' => false,
                'message' => __('Turnstile secret key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        return ['valid' => true, 'message' => ''];
    }
    
    /**
     * Check CleanTalk configuration
     */
    private static function check_cleantalk_configuration($global_settings) {
        if (empty($global_settings['cleantalk_enabled'])) {
            return [
                'valid' => false,
                'message' => __('CleanTalk is not enabled in settings.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($global_settings['cleantalk_access_key'])) {
            return [
                'valid' => false,
                'message' => __('CleanTalk access key is not configured.', 'sigmaforms-pro'),
            ];
        }
        
        return ['valid' => true, 'message' => ''];
    }

    /**
     * Check mTCaptcha configuration
     */
    private static function check_mtcaptcha_configuration($global_settings) {
        if (empty($global_settings['mtcaptcha_enabled'])) {
            return [
                'valid' => false,
                'message' => __('mTCaptcha is not enabled in settings.', 'sigmaforms-pro'),
            ];
        }

        if (empty($global_settings['mtcaptcha_site_key'])) {
            return [
                'valid' => false,
                'message' => __('mTCaptcha site key is not configured.', 'sigmaforms-pro'),
            ];
        }

        if (empty($global_settings['mtcaptcha_private_key'])) {
            return [
                'valid' => false,
                'message' => __('mTCaptcha private key is not configured.', 'sigmaforms-pro'),
            ];
        }

        return ['valid' => true, 'message' => ''];
    }
    
    /**
     * Validate Google reCAPTCHA
     */
    private static function validate_recaptcha($submission_data) {
        $global_settings = get_option('sigmaforms_settings', []);
        $use_v3 = $global_settings['recaptcha_use_v3'] ?? false;
       
        // Check for v3 or v2 response token
        $recaptcha_response = '';
        if ($use_v3) {
            $recaptcha_response = isset($submission_data['recaptcha_v3_token']) ? sanitize_text_field($submission_data['recaptcha_v3_token']) : '';
        } else {
            $recaptcha_response = isset($submission_data['g-recaptcha-response']) ? sanitize_text_field($submission_data['g-recaptcha-response']) : '';
        }
        
        $recaptcha_secret = $global_settings['recaptcha_secret_key'] ?? '';
        
        
        if (empty($recaptcha_response)) {
            $error_message = $use_v3 
                ? __('reCAPTCHA v3 verification failed. Please refresh the page and try again.', 'sigmaforms-pro')
                : __('Please complete the reCAPTCHA verification.', 'sigmaforms-pro');
            return [
                'valid' => false,
                'message' => $error_message,
            ];
        }
        
        if (empty($recaptcha_secret)) {
            return [
                'valid' => false,
                'message' => __('reCAPTCHA is not properly configured.', 'sigmaforms-pro'),
            ];
        }
        
        // Log the actual request being made
        $request_body = [
            'secret' => $recaptcha_secret,
            'response' => $recaptcha_response,
            'remoteip' => self::get_user_ip(),
        ];
        
        $recaptcha_verify = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', [
            'body' => $request_body,
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
        ]);
        
        if (is_wp_error($recaptcha_verify)) {
            return [
                'valid'  => false,
                /* translators: %s: The error message returned by reCAPTCHA verification */
                'message' => sprintf(__('Failed to verify reCAPTCHA: %s', 'sigmaforms-pro'),$recaptcha_verify->get_error_message()),
            ];
        }
        
        
        $response_code = wp_remote_retrieve_response_code($recaptcha_verify);
        $response_body = wp_remote_retrieve_body($recaptcha_verify);
        
        $recaptcha_data = json_decode($response_body, true);
        
        if (!isset($recaptcha_data['success']) || !$recaptcha_data['success']) {
            $error_codes = isset($recaptcha_data['error-codes']) ? implode(', ', $recaptcha_data['error-codes']) : 'unknown';
            return [
                'valid' => false,
                /* translators: %s: The reCAPTCHA error codes */
                'message' => sprintf(__('reCAPTCHA verification failed. Error codes: %s', 'sigmaforms-pro'),$error_codes),
            ];
        }
        
        // For v3, check the score
        if ($use_v3) {
            $score_threshold = floatval($global_settings['recaptcha_v3_score_threshold'] ?? 0.5);
            $score = floatval($recaptcha_data['score'] ?? 0);
            
            if ($score < $score_threshold) {
                return [
                    'valid' => false,
                    /* translators: %.2f: reCAPTCHA v3 score returned for the submission, between 0.00 and 1.00 */
                    'message' => sprintf(__('reCAPTCHA v3 score too low (%.2f). This submission appears to be spam.', 'sigmaforms-pro'), $score),
                    'score' => $score,
                ];
            }
            
            return [
                'valid' => true,
                'message' => '',
                'score' => $score,
            ];
        }
        
        return [
            'valid' => true,
            'message' => '',
        ];
    }
    
    /**
     * Validate hCaptcha
     */
    private static function validate_hcaptcha($submission_data) {
        $hcaptcha_response = isset($submission_data['h-captcha-response']) ? sanitize_text_field($submission_data['h-captcha-response']) : '';
        $global_settings = get_option('sigmaforms_settings', []);
        $hcaptcha_secret = $global_settings['hcaptcha_secret_key'] ?? '';
        
        if (empty($hcaptcha_response)) {
            return [
                'valid' => false,
                'message' => __('Please complete the hCaptcha verification.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($hcaptcha_secret)) {
            return [
                'valid' => false,
                'message' => __('hCaptcha is not properly configured.', 'sigmaforms-pro'),
            ];
        }
        
        // Log the actual request being made
        $request_body = [
            'secret' => $hcaptcha_secret,
            'response' => $hcaptcha_response,
            'remoteip' => self::get_user_ip(),
        ];
        
        $hcaptcha_verify = wp_remote_post('https://hcaptcha.com/siteverify', [
            'body' => $request_body,
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
        ]);
        
        if (is_wp_error($hcaptcha_verify)) {
            return [
                'valid' => false,
                /* translators: %s: The error message returned by hCaptcha verification */
                'message' => sprintf(__('Failed to verify hCaptcha: %s', 'sigmaforms-pro'),$hcaptcha_verify->get_error_message()),
            ];
        }
        
        $response_code = wp_remote_retrieve_response_code($hcaptcha_verify);
        $response_body = wp_remote_retrieve_body($hcaptcha_verify);
        
        $hcaptcha_data = json_decode($response_body, true);
        
        if (!isset($hcaptcha_data['success']) || !$hcaptcha_data['success']) {
            $error_codes = isset($hcaptcha_data['error-codes']) ? implode(', ', $hcaptcha_data['error-codes']) : 'unknown';
            return [
                'valid' => false,
                /* translators: %s: The error message returned by hCaptcha verification */
                'message' => sprintf(__('hCaptcha verification failed. Error codes: %s', 'sigmaforms-pro'),$error_codes),
            ];
        }
        
        return [
            'valid' => true,
            'message' => '',
        ];
    }
    
    /**
     * Validate Cloudflare Turnstile
     */
    private static function validate_turnstile($submission_data) {
        $turnstile_response = isset($submission_data['cf-turnstile-response']) ? sanitize_text_field($submission_data['cf-turnstile-response']) : '';
        $global_settings = get_option('sigmaforms_settings', []);
        $turnstile_secret = $global_settings['turnstile_secret_key'] ?? '';
        
        if (empty($turnstile_response)) {
            return [
                'valid' => false,
                'message' => __('Please complete the Turnstile verification.', 'sigmaforms-pro'),
            ];
        }
        
        if (empty($turnstile_secret)) {
            return [
                'valid' => false,
                'message' => __('Turnstile is not properly configured.', 'sigmaforms-pro'),
            ];
        }
        
        // Log the actual request being made
        $request_body = [
            'secret' => $turnstile_secret,
            'response' => $turnstile_response,
            'remoteip' => self::get_user_ip(),
        ];
        
        // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- Server-side CAPTCHA token verification against Cloudflare's API, not asset offloading.
        $turnstile_verify = wp_remote_post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
            'body' => $request_body,
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
        ]);
        
        if (is_wp_error($turnstile_verify)) {
            return [
                'valid' => false,
                /* translators: %s: The error message returned by failing to verify Turnstile */
                'message' => sprintf(__('Failed to verify Turnstile: %s', 'sigmaforms-pro'),$turnstile_verify->get_error_message()),   
            ];
        }
        
        $response_code = wp_remote_retrieve_response_code($turnstile_verify);
        $response_body = wp_remote_retrieve_body($turnstile_verify);
        
        $turnstile_data = json_decode($response_body, true);
        
        if (!isset($turnstile_data['success']) || !$turnstile_data['success']) {
            $error_codes = isset($turnstile_data['error-codes']) ? implode(', ', $turnstile_data['error-codes']) : 'unknown';
            return [
                'valid' => false,
                /* translators: %s: The error message returned by Turnstile verification failure */
                'message' => sprintf(__('Turnstile verification failed. Error codes: %s', 'sigmaforms-pro'),$error_codes),   
            ];
        }
        return [
            'valid' => true,
            'message' => '',
        ];
    }
    
    /**
     * Validate CleanTalk
     */
    private static function validate_cleantalk($submission_data) {
        $global_settings = get_option('sigmaforms_settings', []);
        $cleantalk_access_key = $global_settings['cleantalk_access_key'] ?? '';
        
        if (empty($cleantalk_access_key)) {
            return [
                'valid' => false,
                'message' => __('CleanTalk is not properly configured.', 'sigmaforms-pro'),
            ];
        }
        
        // CleanTalk API endpoint
        $api_url = 'https://moderate.cleantalk.org/api2.0';
        
        // Get user IP address (handle various server configurations)
        $user_ip = self::get_user_ip();
        
        // Prepare data for CleanTalk
        $ct_data = [
            'auth_key' => $cleantalk_access_key,
            'method_name' => 'check_message',
            'sender_email' => isset($submission_data['email']) ? sanitize_email($submission_data['email']) : '',
            'sender_ip' => $user_ip,
            'sender_nickname' => isset($submission_data['name']) ? sanitize_text_field($submission_data['name']) : '',
            'message' => self::prepare_cleantalk_message($submission_data),
            'example' => '', // Empty for form submissions
            'agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
            'js_on' => 1, // Assume JavaScript is enabled
            'submit_time' => time(),
            'post_info' => json_encode([
                'post_url' => isset($_SERVER['HTTP_REFERER']) ? sanitize_url( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '',
                'post_method' => 'POST',
            ]),
        ];
        
        $cleantalk_verify = wp_remote_post($api_url, [
            'body' => $ct_data,
            'timeout' => 15,
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
        ]);
        
        if (is_wp_error($cleantalk_verify)) {
            return [
                'valid' => false,
                /* translators: %s: The error message returned by failing to verify with CleanTalk */
                'message' => sprintf(__('Failed to verify with CleanTalk: %s', 'sigmaforms-pro'),$cleantalk_verify->get_error_message()),   
            ];
        }
        
        $response_code = wp_remote_retrieve_response_code($cleantalk_verify);
        $response_body = wp_remote_retrieve_body($cleantalk_verify);
        
        $cleantalk_data = json_decode($response_body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'valid' => false,
                'message' => __('Invalid response from CleanTalk service.', 'sigmaforms-pro'),
            ];
        }
        
        // Check if the message is allowed
        if (!isset($cleantalk_data['allow']) || $cleantalk_data['allow'] != 1) {
            $block_reason = isset($cleantalk_data['comment']) ? $cleantalk_data['comment'] : 'Unknown reason';
            return [
                'valid' => false,
                /* translators: %s: The error message returned by blocking message by CleanTalk spam protection */
                'message' => sprintf(__('Message blocked by CleanTalk spam protection: %s', 'sigmaforms-pro'),$block_reason),  
            ];
        }
        return [
            'valid' => true,
            'message' => '',
        ];
    }

    /**
     * Validate mTCaptcha
     */
    private static function validate_mtcaptcha($submission_data) {
        $mtcaptcha_response = isset($submission_data['mtcaptcha-verifiedtoken']) ? sanitize_text_field($submission_data['mtcaptcha-verifiedtoken']) : '';
        $global_settings = get_option('sigmaforms_settings', []);
        $mtcaptcha_private_key = $global_settings['mtcaptcha_private_key'] ?? '';

        if (empty($mtcaptcha_response)) {
            return [
                'valid' => false,
                'message' => __('Please complete the mTCaptcha verification.', 'sigmaforms-pro'),
            ];
        }

        if (empty($mtcaptcha_private_key)) {
            return [
                'valid' => false,
                'message' => __('mTCaptcha is not properly configured.', 'sigmaforms-pro'),
            ];
        }

        $query_args = [
            'privatekey' => $mtcaptcha_private_key,
            'token' => $mtcaptcha_response,
        ];

        $request_url = add_query_arg($query_args, 'https://service.mtcaptcha.com/mtcv1/api/checktoken');
        $mtcaptcha_verify = wp_remote_get($request_url, [
            'timeout' => 30,
        ]);

        if (is_wp_error($mtcaptcha_verify)) {
            return [
                'valid' => false,
                /* translators: %s: The error message returned by mTCaptcha verification */
                'message' => sprintf(__('Failed to verify mTCaptcha: %s', 'sigmaforms-pro'), $mtcaptcha_verify->get_error_message()),
            ];
        }

        $response_body = wp_remote_retrieve_body($mtcaptcha_verify);
        $mtcaptcha_data = json_decode($response_body, true);

        if (!is_array($mtcaptcha_data)) {
            $fallback_url = add_query_arg($query_args, 'https://service2.mtcaptcha.com/mtcv1/api/checktoken');
            $fallback_response = wp_remote_get($fallback_url, [
                'timeout' => 30,
            ]);

            if (is_wp_error($fallback_response)) {
                return [
                    'valid' => false,
                    /* translators: %s: The error message returned by the fallback mTCaptcha verification */
                    'message' => sprintf(__('Invalid response from mTCaptcha service. Fallback error: %s', 'sigmaforms-pro'), $fallback_response->get_error_message()),
                ];
            }

            $response_body = wp_remote_retrieve_body($fallback_response);
            $mtcaptcha_data = json_decode($response_body, true);

            if (!is_array($mtcaptcha_data)) {
                return [
                    'valid' => false,
                    'message' => __('Invalid response from mTCaptcha service.', 'sigmaforms-pro'),
                ];
            }
        }

        if (empty($mtcaptcha_data['success'])) {
            $error_codes = [];

            if (!empty($mtcaptcha_data['fail_codes']) && is_array($mtcaptcha_data['fail_codes'])) {
                $error_codes = $mtcaptcha_data['fail_codes'];
            } elseif (!empty($mtcaptcha_data['error'])) {
                $error_codes = [(string) $mtcaptcha_data['error']];
            }

            return [
                'valid' => false,
                /* translators: %s: The mTCaptcha error details */
                'message' => sprintf(__('mTCaptcha verification failed. Details: %s', 'sigmaforms-pro'), !empty($error_codes) ? implode(', ', $error_codes) : 'unknown'),
            ];
        }

        return [
            'valid' => true,
            'message' => '',
        ];
    }
    
    /**
     * Get user IP address
     */
    private static function get_user_ip() {
        $ip_keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) ) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
    }
    
    /**
     * Prepare message for CleanTalk
     */
    private static function prepare_cleantalk_message($submission_data) {
        // Create a readable message from form data
        $message_parts = [];
        
        foreach ($submission_data as $field => $value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            $message_parts[] = $field . ': ' . $value;
        }
        
        return implode("\n", $message_parts);
    }
    
    /**
     * Render CAPTCHA HTML based on form settings
     * 
     * @param array $form_settings Form settings
     * @return string CAPTCHA HTML
     */
    public static function render_captcha($form_settings) {
        $html = '';
        $global_settings = get_option('sigmaforms_settings', []);
        
        $captcha_type = $form_settings['captcha_type'] ?? '';
        
        if (empty($captcha_type)) {
            return $html;
        }
        
        // First check if captcha is properly configured before rendering
        $config_check = self::check_captcha_configuration($captcha_type);
        if (!$config_check['valid']) {
            return $html; // Skip this captcha if not properly configured
        }
        
        switch ($captcha_type) {
            case 'recaptcha':
                $site_key = $global_settings['recaptcha_site_key'] ?? '';
                $use_v3 = $global_settings['recaptcha_use_v3'] ?? false;
                
                if (!empty($site_key)) {
                    if ($use_v3) {
                        // reCAPTCHA v3 - invisible, no visible widget
                        $html .= '<input type="hidden" name="recaptcha_v3_token" class="recaptcha-v3-token" data-sitekey="' . esc_attr($site_key) . '" value="">';
                        // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Google reCAPTCHA is a legitimate third-party CAPTCHA service
                        wp_enqueue_script(
                            'sf-recaptcha-v3',
                            'https://www.google.com/recaptcha/api.js?render=' . esc_attr($site_key),
                            [],
                            SF_VERSION,
                            true
                        );
                    } else {
                        // reCAPTCHA v2 - visible checkbox
                        $html .= '<div class="g-recaptcha" data-sitekey="' . esc_attr($site_key) . '"></div>';
                        // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Google reCAPTCHA is a legitimate third-party CAPTCHA service
                        wp_enqueue_script(
                            'sf-recaptcha',
                            'https://www.google.com/recaptcha/api.js',
                            [],
                            SF_VERSION,
                            true
                        );
                    }
                } 
                break;
                    
            case 'hcaptcha':
                $site_key = $global_settings['hcaptcha_site_key'] ?? '';
                if (!empty($site_key)) {
                    $html .= '<div class="h-captcha" data-sitekey="' . esc_attr($site_key) . '"></div>';
                    // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- hCaptcha is a legitimate third-party CAPTCHA service
                    wp_enqueue_script(
                        'sf-hcaptcha',
                        'https://js.hcaptcha.com/1/api.js',
                        [],
                        SF_VERSION,
                        true
                    );
                } 
                break;
                    
            case 'turnstile':
                $site_key = $global_settings['turnstile_site_key'] ?? '';
                if (!empty($site_key)) {
                    $html .= '<div class="cf-turnstile" data-sitekey="' . esc_attr($site_key) . '"></div>';
                    // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Cloudflare Turnstile is a legitimate third-party CAPTCHA service
                    wp_enqueue_script('sf-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', [], SF_VERSION, true);
                }
                break;
                    
            case 'cleantalk':
                // CleanTalk doesn't require frontend rendering, it's handled server-side
                break;

            case 'mtcaptcha':
                $site_key = $global_settings['mtcaptcha_site_key'] ?? '';
                if (!empty($site_key)) {
                    $html .= '<div class="mtcaptcha" data-sitekey="' . esc_attr($site_key) . '"></div>';
                    // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- mTCaptcha is a legitimate third-party CAPTCHA service
                    wp_enqueue_script('sf-mtcaptcha', 'https://service.mtcaptcha.com/mtcv1/client/mtcaptcha.min.js', [], SF_VERSION, true);
                }
                break;
        }
        
        return $html;
    }
    
    /**
     * Get CAPTCHA field name based on service
     * 
     * @param array $form_settings Form settings
     * @return string Field name
     */
    public static function get_captcha_field_name($form_settings) {
        $captcha_type = $form_settings['captcha_type'] ?? '';
        
        if (empty($captcha_type)) {
            return '';
        }
        
        switch ($captcha_type) {
            case 'recaptcha':
                $global_settings = get_option('sigmaforms_settings', []);
                $use_v3 = $global_settings['recaptcha_use_v3'] ?? false;
                return $use_v3 ? 'recaptcha_v3_token' : 'g-recaptcha-response';
            case 'hcaptcha':
                return 'h-captcha-response';
            case 'turnstile':
                return 'cf-turnstile-response';
            case 'mtcaptcha':
                return 'mtcaptcha-verifiedtoken';
        }
        
        return '';
    }
} 