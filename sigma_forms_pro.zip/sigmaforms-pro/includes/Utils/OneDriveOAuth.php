<?php
/**
 * OneDrive OAuth Handler for SigmaForms
 * Uses Master Mode (proxy server) for OAuth authentication
 *
 * @package SigmaForms
 */

namespace SigmaForms\Utils;

class OneDriveOAuth {
    /**
     * Get authorization URL
     *
     * @param string $state Nonce for verification
     * @return string
     */
    public static function get_auth_url($state) {
        $redirect_uri = self::get_redirect_uri();
        $proxy_auth_url = SF_PROXY_URL . '/auth/onedrive';
        
        return add_query_arg([
            'return_url' => urlencode($redirect_uri),
            'state' => $state,
        ], $proxy_auth_url);
    }

    /**
     * Get redirect URI
     *
     * @return string
     */
    public static function get_redirect_uri() {
        return admin_url('admin.php?page=sigmaforms-settings&tab=storage&provider=onedrive');
    }

    /**
     * Exchange authorization code for tokens
     *
     * @param string $code Authorization code
     * @return array|WP_Error Array with access_token, refresh_token, expires_in or WP_Error
     */
    public static function exchange_code_for_tokens($code) {
        $response = wp_remote_post(SF_PROXY_URL . '/auth/onedrive/token', [
            'body' => [
                'code' => $code,
                'action' => 'exchange',
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['access_token'])) {
            return new \WP_Error(
                'token_exchange_failed',
                __('Failed to exchange authorization code for tokens.', 'sigmaforms-pro')
            );
        }

        return [
            'access_token' => $data['access_token'],
            'refresh_token' => $data['refresh_token'] ?? '',
            'expires_in' => $data['expires_in'] ?? 3600,
        ];
    }

    /**
     * Refresh access token
     *
     * @param string $refresh_token Refresh token
     * @return array|WP_Error Array with access_token, expires_in or WP_Error
     */
    public static function refresh_access_token($refresh_token) {
        $response = wp_remote_post(SF_PROXY_URL . '/auth/onedrive/refresh', [
            'body' => [
                'refresh_token' => $refresh_token,
                'action' => 'refresh',
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($response_code !== 200 || empty($data['access_token'])) {
            $error_message = isset($data['details']) ? $data['details'] : (isset($data['error']) ? $data['error'] : 'Unknown error');
            return new \WP_Error(
                'token_refresh_failed',
                __('Failed to refresh access token: ', 'sigmaforms-pro') . $error_message
            );
        }

        return [
            'access_token' => $data['access_token'],
            'refresh_token' => $data['refresh_token'] ?? '',
            'expires_in' => $data['expires_in'] ?? 3600,
        ];
    }

    /**
     * Get valid access token (refresh if needed)
     *
     * @return string|WP_Error Access token or WP_Error
     */
    public static function get_valid_access_token() {
        $access_token = get_option('sf_onedrive_access_token', '');
        $refresh_token = get_option('sf_onedrive_refresh_token', '');
        $token_expiry = get_option('sf_onedrive_token_expiry', 0);

        // Check if token is still valid
        if (!empty($access_token) && $token_expiry > time()) {
            return $access_token;
        }

        // Token expired, try to refresh
        if (empty($refresh_token)) {
            return new \WP_Error(
                'no_refresh_token',
                __('No refresh token available. Please reconnect to OneDrive.', 'sigmaforms-pro')
            );
        }

        $result = self::refresh_access_token($refresh_token);

        if (is_wp_error($result)) {
            return $result;
        }

        // Save new access token
        update_option('sf_onedrive_access_token', $result['access_token']);
        update_option('sf_onedrive_token_expiry', time() + $result['expires_in']);
        
        // Save new refresh token if provided (Microsoft may rotate refresh tokens)
        if (!empty($result['refresh_token'])) {
            update_option('sf_onedrive_refresh_token', $result['refresh_token']);
        }

        return $result['access_token'];
    }
}
