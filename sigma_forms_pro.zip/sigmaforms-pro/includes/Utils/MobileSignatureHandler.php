<?php
/**
 * Mobile Signature Handler
 * 
 * Handles QR code generation and signature data transmission for mobile signing
 *
 * @package SigmaForms
 */

namespace SigmaForms\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class MobileSignatureHandler {

    /**
     * Largest accepted signature data URI, in bytes.
     */
    const MAX_SIGNATURE_BYTES = 2097152; // 2 MB

    /**
     * Requests allowed per client, per rate limit window.
     */
    const RATE_LIMIT_MAX = 30;

    /**
     * Rate limit window, in seconds.
     */
    const RATE_LIMIT_WINDOW = 300; // 5 minutes

    /**
     * Store for pending signature sessions
     *
     * @var array
     */
    private static $sessions = [];

    /**
     * Simple per-client throttle for the public signature endpoints.
     *
     * @param string $bucket Name of the action being throttled.
     * @return bool True when the request is within the limit.
     */
    private static function check_rate_limit($bucket) {
        $client = isset($_SERVER['REMOTE_ADDR'])
            ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']))
            : '';

        if ($client === '') {
            return true;
        }

        $key = 'sf_sig_rl_' . $bucket . '_' . md5($client);
        $hits = (int) get_transient($key);

        if ($hits >= self::RATE_LIMIT_MAX) {
            return false;
        }

        set_transient($key, $hits + 1, self::RATE_LIMIT_WINDOW);

        return true;
    }
    
    /**
     * Initialize the handler
     */
    public static function init() {
        add_action('wp_ajax_sf_create_signature_session', [__CLASS__, 'create_signature_session']);
        add_action('wp_ajax_nopriv_sf_create_signature_session', [__CLASS__, 'create_signature_session']);
        
        add_action('wp_ajax_sf_save_mobile_signature', [__CLASS__, 'save_mobile_signature']);
        add_action('wp_ajax_nopriv_sf_save_mobile_signature', [__CLASS__, 'save_mobile_signature']);
        
        add_action('wp_ajax_sf_check_signature_status', [__CLASS__, 'check_signature_status']);
        add_action('wp_ajax_nopriv_sf_check_signature_status', [__CLASS__, 'check_signature_status']);
        
        // Clean up old sessions periodically
        add_action('init', [__CLASS__, 'cleanup_old_sessions']);
    }
    
    /**
     * Create a new signature session
     */
    public static function create_signature_session() {
        // This endpoint is public and each call writes a transient, so throttle per client
        // to keep it from being used to flood the options table.
        if (!self::check_rate_limit('create')) {
            wp_send_json_error(['message' => __('Too many requests. Please wait a moment and try again.', 'sigmaforms-pro')], 429);
        }

        // Generate unique session ID
        $session_id = wp_generate_password(32, false);
        
        // Store session data in transient (expires in 10 minutes)
        $session_data = [
            'created' => time(),
            'status' => 'pending',
            'signature_data' => null,
            'field_id' => isset($_POST['field_id']) ? sanitize_text_field(wp_unslash($_POST['field_id'])) : '', // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Public AJAX endpoint, session-based security
            'form_id' => isset($_POST['form_id']) ? sanitize_text_field(wp_unslash($_POST['form_id'])) : '' // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Public AJAX endpoint, session-based security
        ];
        
        set_transient('sf_signature_session_' . $session_id, $session_data, 600); // 10 minutes
        
        // Generate mobile signature URL
        $mobile_url = add_query_arg([
            'sf_mobile_signature' => '1',
            'session_id' => $session_id
        ], home_url());
        
        wp_send_json_success([
            'session_id' => $session_id,
            'mobile_url' => $mobile_url,
            'qr_data' => $mobile_url
        ]);
    }
    
    /**
     * Save signature data from mobile device
     */
    public static function save_mobile_signature() {
        $session_id = isset($_POST['session_id']) ? sanitize_text_field(wp_unslash($_POST['session_id'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Public AJAX endpoint, session-based security
        $signature_data = isset($_POST['signature_data']) ? wp_unslash($_POST['signature_data']) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Base64 data validated below
        
        if (empty($session_id) || empty($signature_data)) {
            wp_send_json_error(['message' => __('Invalid data', 'sigmaforms-pro')]);
            return;
        }

        // Cap the payload before anything else so a public endpoint cannot be used to
        // push arbitrarily large blobs into the options table.
        if (strlen($signature_data) > self::MAX_SIGNATURE_BYTES) {
            wp_send_json_error(['message' => __('Signature image is too large.', 'sigmaforms-pro')]);
            return;
        }

        // Validate signature data format. The whole string must be a base64 image data URI:
        // a prefix-only check would let quotes and event handlers through to the admin screens.
        if (!\SigmaForms\Utils\Helper::is_safe_image_data_uri($signature_data)) {
            wp_send_json_error(['message' => __('Invalid signature format', 'sigmaforms-pro')]);
            return;
        }
        
        // Get session data
        $session_data = get_transient('sf_signature_session_' . $session_id);
        
        if (!$session_data) {
            wp_send_json_error(['message' => __('Session expired', 'sigmaforms-pro')]);
            return;
        }
        
        // Update session with signature data
        $session_data['status'] = 'completed';
        $session_data['signature_data'] = $signature_data;
        $session_data['completed'] = time();
        
        set_transient('sf_signature_session_' . $session_id, $session_data, 600);
        
        wp_send_json_success([
            'message' => __('Signature saved successfully', 'sigmaforms-pro')
        ]);
    }
    
    /**
     * Check signature session status (polling from browser)
     */
    public static function check_signature_status() {
        $session_id = isset($_POST['session_id']) ? sanitize_text_field(wp_unslash($_POST['session_id'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Public AJAX endpoint, session-based security
        
        if (empty($session_id)) {
            wp_send_json_error(['message' => __('Invalid session', 'sigmaforms-pro')]);
            return;
        }
        
        $session_data = get_transient('sf_signature_session_' . $session_id);
        
        if (!$session_data) {
            wp_send_json_error(['message' => __('Session expired', 'sigmaforms-pro')]);
            return;
        }
        
        if ($session_data['status'] === 'completed') {
            wp_send_json_success([
                'status' => 'completed',
                'signature_data' => $session_data['signature_data']
            ]);
        } else {
            wp_send_json_success([
                'status' => 'pending'
            ]);
        }
    }
    
    /**
     * Render mobile signature capture page
     */
    public static function render_mobile_signature_page() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public page, session-based security
        if (!isset($_GET['sf_mobile_signature']) || !isset($_GET['session_id'])) {
            return;
        }
        
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public page, session-based security
        $session_id = sanitize_text_field(wp_unslash($_GET['session_id']));
        $session_data = get_transient('sf_signature_session_' . $session_id);
        
        if (!$session_data) {
            wp_die(esc_html__('This signature session has expired. Please scan the QR code again.', 'sigmaforms-pro'));
        }
        
        // Load mobile signature template
        include_once SF_PLUGIN_DIR . 'admin/views/mobile-signature-capture.php';
        exit;
    }
    
    /**
     * Clean up old signature sessions
     */
    public static function cleanup_old_sessions() {
        // WordPress automatically handles transient cleanup
        // This is just a placeholder for any additional cleanup logic
    }
    
    /**
     * Get session data
     * 
     * @param string $session_id Session ID
     * @return array|false Session data or false if not found
     */
    public static function get_session($session_id) {
        return get_transient('sf_signature_session_' . $session_id);
    }
    
    /**
     * Delete session
     * 
     * @param string $session_id Session ID
     */
    public static function delete_session($session_id) {
        delete_transient('sf_signature_session_' . $session_id);
    }
}

// Initialize the handler
MobileSignatureHandler::init();
