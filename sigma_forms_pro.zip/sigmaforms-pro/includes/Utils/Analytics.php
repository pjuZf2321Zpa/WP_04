<?php
/**
 * Analytics utility class
 *
 * @package SigmaForms
 */

namespace SigmaForms\Utils;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Analytics class to handle form submission analytics
 */
class Analytics {
    /**
     * Get form submission count
     *
     * @param int|null $form_id Optional form ID to filter by
     * @param array    $args Optional arguments
     * @return int
     */
    public static function get_submission_count($form_id = null, $args = []) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Check if table exists
        if (!self::table_exists($table_name)) {
            return 0;
        }
        
        $where = '';
        $prepare_args = [];
        
        if (!is_null($form_id)) {
            $where = 'WHERE form_id = %d';
            $prepare_args[] = $form_id;
        }
        
        // Add date filtering if provided
        if (!empty($args['date_from'])) {
            $where .= $where ? ' AND ' : 'WHERE ';
            $where .= 'date_created >= %s';
            $prepare_args[] = $args['date_from'];
        }
        
        if (!empty($args['date_to'])) {
            $where .= $where ? ' AND ' : 'WHERE ';
            $where .= 'date_created <= %s';
            $prepare_args[] = $args['date_to'];
        }
        
        $query = "SELECT COUNT(*) FROM $table_name $where";
        
        if (!empty($prepare_args)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $query = $wpdb->prepare($query, $prepare_args);
        }
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        return (int) $wpdb->get_var($query);
    }
    
    /**
     * Get recent form submissions
     *
     * @param int $limit Number of submissions to return
     * @param int|null $form_id Optional form ID to filter by
     * @return array
     */
    public static function get_recent_submissions($limit = 5, $form_id = null) {
        global $wpdb;
        
        $submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
        $forms_table = $wpdb->prefix . 'sigmaforms';
        
        // Check if tables exist
        if (!self::table_exists($submissions_table) || !self::table_exists($forms_table)) {
            return [];
        }
        
        $where = '';
        $prepare_args = [];
        
        if (!is_null($form_id)) {
            $where = 'WHERE s.form_id = %d';
            $prepare_args[] = $form_id;
        }
        
        $query = "
            SELECT 
                s.id, 
                s.form_id, 
                s.date_created, 
                s.status,
                f.title as form_title
            FROM 
                $submissions_table s
            LEFT JOIN
                $forms_table f ON s.form_id = f.id
            $where
            ORDER BY 
                s.date_created DESC
            LIMIT %d
        ";
        
        $prepare_args[] = $limit;
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $query = $wpdb->prepare($query, $prepare_args);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    /**
     * Get form count
     *
     * @return int
     */
    public static function get_form_count() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'sigmaforms';
        
        // Check if table exists
        if (!self::table_exists($table_name)) {
            return 0;
        }
        
        $query = "SELECT COUNT(*) FROM $table_name";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        return (int) $wpdb->get_var($query);
    }
    
    /**
     * Get submission rate for a form
     *
     * @param int $form_id Form ID
     * @param int $days Number of days to calculate rate for
     * @return array
     */
    public static function get_submission_rate($form_id, $days = 30) {
        global $wpdb;
        
        $submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Check if table exists
        if (!self::table_exists($submissions_table)) {
            return [
                'dates' => [],
                'counts' => [],
                'total' => 0,
                'average' => 0,
                'hour_distribution' => [],
                'day_distribution' => [],
            ];
        }
        
        $date_from = gmdate('Y-m-d H:i:s', strtotime("-$days days"));
        $submissionRateGetQuery = "SELECT DATE(date_created) as submission_date, COUNT(*) as count FROM $submissions_table WHERE form_id = %d AND date_created >= %s GROUP BY DATE(date_created) ORDER BY submission_date ASC";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $query = $wpdb->prepare($submissionRateGetQuery,$form_id,$date_from);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $results = $wpdb->get_results($query, ARRAY_A);
        
        // Format for chart data
        $dates = [];
        $counts = [];
        
        foreach ($results as $row) {
            $dates[] = $row['submission_date'];
            $counts[] = (int) $row['count'];
        }
        // Build hourly distribution (0-23)
        $hour_distribution = array_fill(0, 24, 0);
        $hourQuery = "SELECT HOUR(date_created) AS hour, COUNT(*) AS count FROM $submissions_table WHERE form_id = %d AND date_created >= %s GROUP BY HOUR(date_created) ORDER BY hour ASC";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $hourPrepared = $wpdb->prepare($hourQuery, $form_id, $date_from);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $hourRows = $wpdb->get_results($hourPrepared, ARRAY_A);
        if (is_array($hourRows)) {
            foreach ($hourRows as $row) {
                $h = (int) $row['hour'];
                if ($h >= 0 && $h <= 23) {
                    $hour_distribution[$h] = (int) $row['count'];
                }
            }
        }

        // Build weekday distribution (0=Sunday..6=Saturday)
        $day_distribution = array_fill(0, 7, 0);
        $dayQuery = "SELECT (DAYOFWEEK(date_created) - 1) AS wday, COUNT(*) AS count FROM $submissions_table WHERE form_id = %d AND date_created >= %s GROUP BY (DAYOFWEEK(date_created) - 1) ORDER BY wday ASC";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $dayPrepared = $wpdb->prepare($dayQuery, $form_id, $date_from);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $dayRows = $wpdb->get_results($dayPrepared, ARRAY_A);
        if (is_array($dayRows)) {
            foreach ($dayRows as $row) {
                $d = (int) $row['wday'];
                if ($d >= 0 && $d <= 6) {
                    $day_distribution[$d] = (int) $row['count'];
                }
            }
        }

        return [
            'dates' => $dates,
            'counts' => $counts,
            'total' => array_sum($counts),
            'average' => count($counts) > 0 ? array_sum($counts) / count($counts) : 0,
            'hour_distribution' => $hour_distribution,
            'day_distribution' => $day_distribution,
        ];
    }

    /**
     * Get form views (stub). Returns 0 until view tracking is implemented.
     *
     * @param int $form_id Form ID
     * @param array $args Optional date range args: date_from, date_to
     * @return int
     */
    public static function get_form_views($form_id, $args = []) {
        global $wpdb;
        $views_table = $wpdb->prefix . 'sigmaforms_views';
        if (!self::table_exists($views_table)) {
            return 0;
        }
        $where = 'WHERE form_id = %d';
        $params = [$form_id];
        if (!empty($args['date_from'])) {
            $where .= ' AND date_created >= %s';
            $params[] = $args['date_from'];
        }
        if (!empty($args['date_to'])) {
            $where .= ' AND date_created <= %s';
            $params[] = $args['date_to'];
        }
        $sql = "SELECT COUNT(*) FROM $views_table $where";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $prepared = $wpdb->prepare($sql, $params);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        return (int) $wpdb->get_var($prepared);
    }

    /**
     * Get popular referring pages (stub).
     *
     * @param int $form_id Form ID
     * @param int $limit Number of pages to return
     * @return array Array of ['url' => string, 'title' => string|null, 'count' => int]
     */
    public static function get_popular_referring_pages($form_id, $limit = 5) {
        global $wpdb;
        $ref_table = $wpdb->prefix . 'sigmaforms_referrers';
        if (!self::table_exists($ref_table)) {
            return [];
        }
        $sql = "SELECT page_url, COUNT(*) AS count FROM $ref_table WHERE form_id = %d AND page_url IS NOT NULL AND page_url <> '' GROUP BY page_url ORDER BY count DESC LIMIT %d";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $prepared = $wpdb->prepare($sql, $form_id, $limit);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $rows = $wpdb->get_results($prepared, ARRAY_A);
        if (empty($rows)) {
            return [];
        }
        $out = [];
        foreach ($rows as $row) {
            $out[] = [
                'url' => $row['page_url'],
                'title' => self::get_title_from_url($row['page_url']),
                'count' => (int) $row['count'],
            ];
        }
        return $out;
    }

    /**
     * Resolve a URL to a WP post title when possible.
     *
     * @param string $url
     * @return string|null
     */
    private static function get_title_from_url($url) {
        if (empty($url)) {
            return null;
        }
        $post_id = url_to_postid($url);
        if ($post_id) {
            $title = get_the_title($post_id);
            return $title ?: null;
        }
        return null;
    }

    /**
     * Get field analytics (stub).
     *
     * @param int $form_id Form ID
     * @return array Keys used by views: completion_rate, field_stats, most_skipped, most_errors, avg_completion_time, abandonment_rate
     */
    public static function get_field_analytics($form_id) {
        global $wpdb;

        $forms_table = $wpdb->prefix . 'sigmaforms';
        $subs_table = $wpdb->prefix . 'sigmaforms_submissions';
        $abandoned_table = $wpdb->prefix . 'sigmaforms_abandoned_forms';

        // Defaults
        $result = [
            'completion_rate' => null,
            'field_stats' => [],
            'most_skipped' => [],
            'most_errors' => [],
            'avg_completion_time' => null,
            'abandonment_rate' => null,
        ];

        // Ensure submissions table exists
        if (!self::table_exists($subs_table) || !self::table_exists($forms_table)) {
            return $result;
        }

        // Get form schema (fields and labels)
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is prefixed
        $form_row = $wpdb->get_row($wpdb->prepare("SELECT form_fields FROM $forms_table WHERE id = %d", $form_id), ARRAY_A);
        if (!$form_row) {
            return $result;
        }
        $form_fields = [];
        $decoded = json_decode($form_row['form_fields'], true);
        if (is_array($decoded)) {
            foreach ($decoded as $field) {
                if (!empty($field['id'])) {
                    $form_fields[$field['id']] = [
                        'label' => isset($field['label']) ? $field['label'] : $field['id'],
                        'type' => isset($field['type']) ? $field['type'] : '',
                    ];
                }
            }
        }

        // Tally filled vs empty by field from recent submissions (limit window for performance)
        $per_field = [];
        foreach ($form_fields as $fid => $meta) {
            $per_field[$fid] = [
                'label' => $meta['label'],
                'filled' => 0,
                'empty' => 0,
            ];
        }

        // Fetch recent submissions for this form
        $subs_sql = "SELECT field_values FROM $subs_table WHERE form_id = %d ORDER BY date_created DESC LIMIT 200";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $subs_rows = $wpdb->get_results($wpdb->prepare($subs_sql, $form_id), ARRAY_A);
        $total_submissions = 0;
        if (is_array($subs_rows)) {
            foreach ($subs_rows as $row) {
                $total_submissions++;
                $values = json_decode($row['field_values'], true);
                if (!is_array($values)) {
                    continue;
                }
                foreach ($form_fields as $fid => $meta) {
                    $v = $values[$fid] ?? '';
                    $is_empty = (is_array($v) ? count(array_filter($v, function($x){ return $x !== '' && $x !== null; })) === 0 : ($v === '' || $v === null));
                    if ($is_empty) {
                        $per_field[$fid]['empty']++;
                    } else {
                        $per_field[$fid]['filled']++;
                    }
                }
            }
        }

        // Compute skip rates and pick most_skipped
        $field_stats = [];
        $most_skipped = ['label' => '', 'skip_rate' => 0.0];
        foreach ($per_field as $fid => $stat) {
            $total = $stat['filled'] + $stat['empty'];
            $skip_rate = $total > 0 ? ($stat['empty'] / $total) * 100.0 : 0.0;
            $entry = [
                'id' => $fid,
                'label' => $stat['label'],
                'filled' => $stat['filled'],
                'empty' => $stat['empty'],
                'skip_rate' => $skip_rate,
            ];
            $field_stats[] = $entry;
            if ($skip_rate > $most_skipped['skip_rate']) {
                $most_skipped = ['label' => $stat['label'], 'skip_rate' => $skip_rate];
            }
        }

        // Completion and abandonment rates using abandoned forms table (if exists)
        $completion_rate = null;
        $abandonment_rate = null;
        $avg_completion_time = null;
        if (self::table_exists($abandoned_table)) {
            // Count unconverted abandoned interactions
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is prefixed
            $abandoned_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $abandoned_table WHERE form_id = %d AND is_converted = 0", $form_id));
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is prefixed
            $converted_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $abandoned_table WHERE form_id = %d AND is_converted = 1", $form_id));
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is prefixed
            $submitted_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $subs_table WHERE form_id = %d", $form_id));
            $interactions = $abandoned_count + $converted_count + $submitted_count;
            if ($interactions > 0) {
                $completion_rate = ($submitted_count / $interactions) * 100.0;
                $abandonment_rate = ($abandoned_count / $interactions) * 100.0;
            } else {
                $completion_rate = 0.0;
                $abandonment_rate = 0.0;
            }

            // Average completion time (seconds) for converted sessions
            // Uses start_time to last_activity recorded by the tracker
            $avg_time_sql = "SELECT AVG(TIMESTAMPDIFF(SECOND, start_time, last_activity)) FROM $abandoned_table WHERE form_id = %d AND is_converted = 1 AND start_time IS NOT NULL AND last_activity IS NOT NULL";
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $avg_seconds = $wpdb->get_var($wpdb->prepare($avg_time_sql, $form_id));
            if ($avg_seconds !== null) {
                $avg_completion_time = (int) round((float) $avg_seconds);
            }
        }

        $result['completion_rate'] = is_null($completion_rate) ? null : round($completion_rate, 2);
        $result['abandonment_rate'] = is_null($abandonment_rate) ? null : round($abandonment_rate, 2);
        $result['field_stats'] = $field_stats;
        $result['most_skipped'] = !empty($most_skipped['label']) ? ['label' => $most_skipped['label'], 'skip_rate' => round($most_skipped['skip_rate'], 2)] : [];
        // most_errors remains untracked for now
        $result['avg_completion_time'] = $avg_completion_time;

        return $result;
    }

    /**
     * Format duration in seconds to a human-readable string (e.g., 1h 2m 5s or 2m 30s).
     *
     * @param int|float|null $seconds
     * @return string
     */
    public static function format_duration($seconds) {
        if ($seconds === null) {
            return '';
        }
        $seconds = (int) round($seconds);
        $h = intdiv($seconds, 3600);
        $m = intdiv($seconds % 3600, 60);
        $s = $seconds % 60;
        $parts = [];
        if ($h > 0) { $parts[] = $h . 'h'; }
        if ($m > 0) { $parts[] = $m . 'm'; }
        if ($s > 0 || empty($parts)) { $parts[] = $s . 's'; }
        return implode(' ', $parts);
    }
    
    /**
     * Get submissions count by status
     *
     * @param int|null $form_id Optional form ID to filter by
     * @return array
     */
    public static function get_submissions_by_status($form_id = null) {
        global $wpdb;
        
        $submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
        
        // Check if table exists
        if (!self::table_exists($submissions_table)) {
            return [
                'read' => 0,
                'unread' => 0,
            ];
        }
        
        $where = '';
        $prepare_args = [];
        
        if (!is_null($form_id)) {
            $where = 'WHERE form_id = %d';
            $prepare_args[] = $form_id;
        }
        
        $query = "
            SELECT 
                status, 
                COUNT(*) as count 
            FROM 
                $submissions_table 
            $where
            GROUP BY 
                status
        ";
        
        if (!empty($prepare_args)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $query = $wpdb->prepare($query, $prepare_args);
        }
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $results = $wpdb->get_results($query, ARRAY_A);
        
        $status_counts = [
            'read' => 0,
            'unread' => 0,
        ];
        
        foreach ($results as $row) {
            $status_counts[$row['status']] = (int) $row['count'];
        }
        
        return $status_counts;
    }
    
    /**
     * Check if a table exists in the database
     *
     * @param string $table_name Table name to check
     * @return bool True if exists, false otherwise
     */
    private static function table_exists($table_name) {
        global $wpdb;
        $tableExistsQuery = "SHOW TABLES LIKE '$table_name'";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $result = $wpdb->get_var($tableExistsQuery);

        return $result === $table_name;
    }

    /**
     * Delete view log rows older than the retention period.
     *
     * A row is written on every form render, so this table is the fastest
     * growing one in the plugin - high traffic sites have reported it reaching
     * millions of rows and hundreds of megabytes, which slows the whole site.
     *
     * Deleting is done in small batches inside a time budget rather than as one
     * statement, so clearing a large backlog never holds a long lock or exceeds
     * the PHP time limit. Anything left over is picked up by the next daily run.
     *
     * @param int $days        Days of view history to keep. 0 disables cleanup.
     * @param int $time_budget Seconds to spend deleting before stopping.
     * @return int Number of rows deleted.
     */
    public static function cleanup_old_views($days = 60, $time_budget = 20) {
        global $wpdb;

        $days = (int) $days;

        if ($days <= 0) {
            return 0;
        }

        $table = $wpdb->prefix . 'sigmaforms_views';

        if (!self::table_exists($table)) {
            return 0;
        }

        // Rows are stored with current_time('mysql'), so the cutoff has to be
        // in site local time too, not server/UTC time.
        $cutoff = gmdate('Y-m-d H:i:s', strtotime("-{$days} days", strtotime(current_time('mysql'))));

        $batch_size = 2000;
        $deleted = 0;
        $started = microtime(true);

        do {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the cutoff and batch size are prepared with %s and %d.
            $rows = $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE date_created < %s LIMIT %d", $cutoff, $batch_size));

            if ($rows === false) {
                break;
            }

            $deleted += (int) $rows;
        } while ($rows >= $batch_size && (microtime(true) - $started) < $time_budget);

        return $deleted;
    }

    /**
     * Count view log rows older than the retention period.
     *
     * Used by the settings screen to show how much is queued for deletion.
     *
     * @param int $days Days of view history to keep.
     * @return int Number of rows currently eligible for cleanup.
     */
    public static function count_expired_views($days = 60) {
        global $wpdb;

        $days = (int) $days;
        $table = $wpdb->prefix . 'sigmaforms_views';

        if ($days <= 0 || !self::table_exists($table)) {
            return 0;
        }

        $cutoff = gmdate('Y-m-d H:i:s', strtotime("-{$days} days", strtotime(current_time('mysql'))));

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; the cutoff is prepared with %s.
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE date_created < %s", $cutoff));
    }
}
