<?php
/**
 * Helper utilities for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Utils;

class Helper
{
    /**
     * Restrict an image position value to the four supported sides.
     *
     * @param string $position Raw position value.
     * @param string $default  Fallback when the value is not recognised.
     * @return string One of top, bottom, left, right.
     */
    private static function sanitize_image_position($position, $default = 'top')
    {
        $allowed = array('top', 'bottom', 'left', 'right');
        $position = sanitize_text_field((string) $position);

        return in_array($position, $allowed, true) ? $position : $default;
    }

    /**
     * Sanitize form fields array
     *
     * @param array $fields Form fields data
     * @return array Sanitized form fields
     */
    public static function sanitize_form_fields($fields)
    {
        if (!is_array($fields)) {
            return [];
        }

        $sanitized = [];

        foreach ($fields as $field) {
            if (!isset($field['id']) || !isset($field['type'])) {
                continue;
            }

            $sanitized_field = [
                'id' => str_replace(' ', '_', sanitize_text_field(trim($field['id']))),
                'name' => isset($field['name']) ? str_replace(' ', '_', sanitize_text_field(trim($field['name']))) : str_replace(' ', '_', sanitize_text_field(trim($field['id']))),
                'type' => sanitize_text_field($field['type']),
                'label' => isset($field['label']) ? sanitize_text_field($field['label']) : '',
                'placeholder' => isset($field['placeholder']) ? sanitize_text_field($field['placeholder']) : '',
                'default_value' => isset($field['default_value']) ? sanitize_text_field($field['default_value']) : '',
                'required' => isset($field['required']) ? (bool) $field['required'] : false,
                'required_message' => isset($field['required_message']) ? sanitize_text_field($field['required_message']) : '',
                'validation_message' => isset($field['validation_message']) ? sanitize_text_field($field['validation_message']) : '',
                'file_size_error_message' => isset($field['file_size_error_message']) ? sanitize_text_field($field['file_size_error_message']) : '',
                'file_type_error_message' => isset($field['file_type_error_message']) ? sanitize_text_field($field['file_type_error_message']) : '',
                'cloud_upload_error_message' => isset($field['cloud_upload_error_message']) ? sanitize_text_field($field['cloud_upload_error_message']) : '',
                'column_width' => isset($field['column_width']) ? sanitize_text_field($field['column_width']) : '100',
                'label_position' => isset($field['label_position']) ? sanitize_text_field($field['label_position']) : 'left',
                'field_position' => isset($field['field_position']) ? sanitize_text_field($field['field_position']) : 'left',
                'options_columns' => isset($field['options_columns']) ? intval($field['options_columns']) : 1,
                'show_label' => isset($field['show_label']) ? (bool) $field['show_label'] : true,
                'show_label_image' => isset($field['show_label_image']) ? (bool) $field['show_label_image'] : true,
                'options' => [],
                'conditional' => [],
                'help_text' => isset($field['help_text']) ? sanitize_text_field($field['help_text']) : '',
                'css_class' => isset($field['css_class']) ? sanitize_text_field($field['css_class']) : '',
                // Label image
                'label_image' => isset($field['label_image']) ? esc_url_raw($field['label_image']) : '',
                'label_image_id' => isset($field['label_image_id']) ? absint($field['label_image_id']) : 0,
                // Attachment the crop tool re-opens, so repeated crops never compound
                'label_image_source_id' => isset($field['label_image_source_id']) ? absint($field['label_image_source_id']) : 0,
                'label_image_position' => self::sanitize_image_position($field['label_image_position'] ?? '', 'left'),
                'label_image_width' => isset($field['label_image_width']) ? absint($field['label_image_width']) : 0,
                'label_image_height' => isset($field['label_image_height']) ? absint($field['label_image_height']) : 0,
                'label_image_full_width' => !empty($field['label_image_full_width']),
                // Percent keeps the image the same relative size in the builder
                // preview and on the frontend, whatever each container's width is
                'label_image_width_unit' => (isset($field['label_image_width_unit']) && $field['label_image_width_unit'] === '%') ? '%' : 'px',
                // Option images
                'option_image_position' => self::sanitize_image_position($field['option_image_position'] ?? '', 'top'),
                'option_image_size' => isset($field['option_image_size']) ? absint($field['option_image_size']) : 0,
                // Country / international phone flag icons (opt-out, default on)
                'show_country_flags' => isset($field['show_country_flags']) ? (bool) $field['show_country_flags'] : true,
            ];

            // Handle selected countries for country field type
            if (isset($field['selected_countries']) && is_array($field['selected_countries'])) {
                $sanitized_field['selected_countries'] = array_map('sanitize_text_field', $field['selected_countries']);
            }

            // Handle file upload field properties
            if ($sanitized_field['type'] === 'file') {
                // Handle allowed file types
                if (isset($field['allowed_file_types']) && is_array($field['allowed_file_types'])) {
                    $sanitized_field['allowed_file_types'] = self::filter_allowed_file_types($field['allowed_file_types']);
                } else {
                    $sanitized_field['allowed_file_types'] = [];
                }

                // Handle custom file extensions
                if (isset($field['custom_file_extensions'])) {
                    $sanitized_field['custom_file_extensions'] = self::sanitize_custom_file_extensions($field['custom_file_extensions']);
                } else {
                    $sanitized_field['custom_file_extensions'] = '';
                }

                // Require explicit allow-list; fall back to safe defaults when none configured.
                if (empty($sanitized_field['allowed_file_types']) && empty($sanitized_field['custom_file_extensions'])) {
                    $sanitized_field['allowed_file_types'] = self::get_default_allowed_file_types();
                }

                // Handle file size limit
                if (isset($field['max_file_size_value']) && !empty($field['max_file_size_value'])) {
                    $sanitized_field['max_file_size_value'] = intval($field['max_file_size_value']);
                } else {
                    $sanitized_field['max_file_size_value'] = '';
                }

                if (isset($field['max_file_size_unit'])) {
                    $sanitized_field['max_file_size_unit'] = sanitize_text_field($field['max_file_size_unit']);
                } else {
                    $sanitized_field['max_file_size_unit'] = 'MB';
                }

                // Handle storage location
                if (isset($field['storage_location'])) {
                    $allowed_locations = array('site', 'email_attachment', 'google_drive', 'onedrive');
                    $storage_location = sanitize_text_field($field['storage_location']);
                    $sanitized_field['storage_location'] = in_array($storage_location, $allowed_locations, true) ? $storage_location : 'site';
                } else {
                    $sanitized_field['storage_location'] = 'site';
                }

                // Handle allow multiple files
                if (isset($field['allow_multiple'])) {
                    $sanitized_field['allow_multiple'] = (bool) $field['allow_multiple'];
                } else {
                    $sanitized_field['allow_multiple'] = false;
                }

                // Handle max files count
                if (isset($field['max_files']) && $field['max_files'] !== '') {
                    $sanitized_field['max_files'] = absint($field['max_files']);
                    if ($sanitized_field['max_files'] < 2) {
                        $sanitized_field['max_files'] = '';
                    }
                } else {
                    $sanitized_field['max_files'] = '';
                }

                // Handle upload button text
                if (isset($field['upload_button_text'])) {
                    $sanitized_field['upload_button_text'] = sanitize_text_field($field['upload_button_text']);
                } else {
                    $sanitized_field['upload_button_text'] = 'Choose a file';
                }
            }

            // Handle signature field properties
            if ($sanitized_field['type'] === 'signature') {
                // Handle storage location
                if (isset($field['storage_location'])) {
                    $allowed_locations = array('site', 'email_attachment', 'google_drive', 'onedrive');
                    $storage_location = sanitize_text_field($field['storage_location']);
                    $sanitized_field['storage_location'] = in_array($storage_location, $allowed_locations, true) ? $storage_location : 'site';
                } else {
                    $sanitized_field['storage_location'] = 'site';
                }
            }

            // Handle textarea height property
            if ($sanitized_field['type'] === 'textarea') {
                if (isset($field['textarea_height']) && $field['textarea_height'] !== '') {
                    $sanitized_field['textarea_height'] = absint($field['textarea_height']);
                }
            }

            // Handle range field properties
            if ($sanitized_field['type'] === 'range') {
                if (isset($field['range_min'])) {
                    $sanitized_field['range_min'] = sanitize_text_field($field['range_min']);
                }
                if (isset($field['range_max'])) {
                    $sanitized_field['range_max'] = sanitize_text_field($field['range_max']);
                }
                if (isset($field['range_step'])) {
                    $sanitized_field['range_step'] = sanitize_text_field($field['range_step']);
                }
                if (isset($field['range_default'])) {
                    $sanitized_field['range_default'] = sanitize_text_field($field['range_default']);
                }
            }

            // Handle section heading underline properties
            if ($sanitized_field['type'] === 'section_heading') {
                if (isset($field['show_underline'])) {
                    $sanitized_field['show_underline'] = (bool) $field['show_underline'];
                } else {
                    $sanitized_field['show_underline'] = true; // Default to true
                }
                
                if (isset($field['underline_color'])) {
                    $sanitized_field['underline_color'] = sanitize_hex_color($field['underline_color']);
                } else {
                    $sanitized_field['underline_color'] = '#3b82f6'; // Default blue
                }
                
                if (isset($field['underline_thickness'])) {
                    $sanitized_field['underline_thickness'] = sanitize_text_field($field['underline_thickness']);
                } else {
                    $sanitized_field['underline_thickness'] = '3'; // Default 3px
                }
                
                if (isset($field['underline_style'])) {
                    $allowed_styles = array('solid', 'dashed', 'dotted', 'double');
                    $style = sanitize_text_field($field['underline_style']);
                    $sanitized_field['underline_style'] = in_array($style, $allowed_styles, true) ? $style : 'solid';
                } else {
                    $sanitized_field['underline_style'] = 'solid'; // Default solid
                }
            }

            // Handle page break button text and step indicator properties
            if ($sanitized_field['type'] === 'page_break') {
                if (isset($field['next_button_text'])) {
                    $sanitized_field['next_button_text'] = sanitize_text_field($field['next_button_text']);
                } else {
                    $sanitized_field['next_button_text'] = 'Next';
                }
                
                if (isset($field['previous_button_text'])) {
                    $sanitized_field['previous_button_text'] = sanitize_text_field($field['previous_button_text']);
                } else {
                    $sanitized_field['previous_button_text'] = 'Previous';
                }
                
                if (isset($field['step_indicator_format'])) {
                    $sanitized_field['step_indicator_format'] = sanitize_text_field($field['step_indicator_format']);
                } else {
                    $sanitized_field['step_indicator_format'] = 'Step {current} of {total}';
                }
                
                if (isset($field['validation_message'])) {
                    $sanitized_field['validation_message'] = sanitize_text_field($field['validation_message']);
                } else {
                    $sanitized_field['validation_message'] = 'Please fill in all required fields before proceeding.';
                }
                
                // Handle color customization for multi-step navigation
                if (isset($field['next_button_bg_color'])) {
                    $sanitized_field['next_button_bg_color'] = sanitize_hex_color($field['next_button_bg_color']);
                } else {
                    $sanitized_field['next_button_bg_color'] = '#6366f1';
                }
                
                if (isset($field['next_button_text_color'])) {
                    $sanitized_field['next_button_text_color'] = sanitize_hex_color($field['next_button_text_color']);
                } else {
                    $sanitized_field['next_button_text_color'] = '#ffffff';
                }
                
                if (isset($field['prev_button_bg_color'])) {
                    $sanitized_field['prev_button_bg_color'] = sanitize_hex_color($field['prev_button_bg_color']);
                } else {
                    $sanitized_field['prev_button_bg_color'] = '#ffffff';
                }
                
                if (isset($field['prev_button_text_color'])) {
                    $sanitized_field['prev_button_text_color'] = sanitize_hex_color($field['prev_button_text_color']);
                } else {
                    $sanitized_field['prev_button_text_color'] = '#374151';
                }
                
                if (isset($field['step_indicator_text_color'])) {
                    $sanitized_field['step_indicator_text_color'] = sanitize_hex_color($field['step_indicator_text_color']);
                } else {
                    $sanitized_field['step_indicator_text_color'] = '#6b7280';
                }
            }

            // Handle selected phone countries for phone_international field type
            // Always set for phone_international fields, even if empty array
            if ($sanitized_field['type'] === 'phone_international') {
                // Always set default_country for phone_international fields
                if (isset($field['default_country'])) {
                    $sanitized_field['default_country'] = sanitize_text_field($field['default_country']);
                } else {
                    $sanitized_field['default_country'] = 'BD'; // Default to Bangladesh
                }

                if (isset($field['selected_phone_countries']) && is_array($field['selected_phone_countries'])) {
                    $sanitized_field['selected_phone_countries'] = array_map('sanitize_text_field', $field['selected_phone_countries']);
                } else {
                    $sanitized_field['selected_phone_countries'] = [];
                }

                if (isset($field['available_countries']) && is_array($field['available_countries'])) {
                    $sanitized_field['available_countries'] = array_map('sanitize_text_field', $field['available_countries']);
                } else {
                    $sanitized_field['available_countries'] = [];
                }
            } else {
                // For non-phone_international fields
                if (isset($field['default_country'])) {
                    $sanitized_field['default_country'] = sanitize_text_field($field['default_country']);
                }

                // Only set if explicitly provided
                if (isset($field['selected_phone_countries']) && is_array($field['selected_phone_countries'])) {
                    $sanitized_field['selected_phone_countries'] = array_map('sanitize_text_field', $field['selected_phone_countries']);
                }

                if (isset($field['available_countries']) && is_array($field['available_countries'])) {
                    $sanitized_field['available_countries'] = array_map('sanitize_text_field', $field['available_countries']);
                }
            }

            // Handle options for select, radio, checkbox
            if (isset($field['options']) && is_array($field['options'])) {
                foreach ($field['options'] as $option) {
                    if (isset($option['value']) && isset($option['label'])) {
                        $sanitized_option = [
                            'value' => sanitize_text_field($option['value']),
                            'label' => wp_kses_post($option['label']),
                        ];

                        // Per-option image shown in radio/checkbox cards and the visual dropdown
                        if (!empty($option['image'])) {
                            $sanitized_option['image'] = esc_url_raw($option['image']);
                            $sanitized_option['image_id'] = isset($option['image_id']) ? absint($option['image_id']) : 0;
                            $sanitized_option['image_source_id'] = isset($option['image_source_id'])
                                ? absint($option['image_source_id'])
                                : $sanitized_option['image_id'];
                        }

                        // Country options keep their ISO code so the flag can be rebuilt at render time
                        if (!empty($option['country_code'])) {
                            $sanitized_option['country_code'] = sanitize_text_field($option['country_code']);
                        }

                        $sanitized_field['options'][] = $sanitized_option;
                    }
                }
            }

            // Handle conditional logic - support both basic and advanced structures
            if (isset($field['conditional']) && is_array($field['conditional'])) {
                // Check if it's the advanced conditional logic structure
                if (isset($field['conditional']['action']) && isset($field['conditional']['groups']) && is_array($field['conditional']['groups'])) {
                    // Advanced conditional logic - sanitize the entire structure
                    $sanitized_field['conditional'] = [
                        'action' => sanitize_text_field($field['conditional']['action']),
                        'logic_type' => isset($field['conditional']['logic_type']) ? sanitize_text_field($field['conditional']['logic_type']) : 'all',
                        'groups' => []
                    ];

                    // Sanitize each group
                    foreach ($field['conditional']['groups'] as $group) {
                        if (isset($group['rules']) && is_array($group['rules'])) {
                            $sanitized_group = ['rules' => []];

                            // Sanitize each rule in the group
                            foreach ($group['rules'] as $rule) {
                                $sanitized_rule = [
                                    'source_type' => isset($rule['source_type']) ? sanitize_text_field($rule['source_type']) : 'field',
                                    'field' => isset($rule['field']) ? sanitize_text_field($rule['field']) : '',
                                    'operator' => isset($rule['operator']) ? sanitize_text_field($rule['operator']) : '=',
                                    'value' => isset($rule['value']) ? sanitize_text_field($rule['value']) : ''
                                ];

                                // Add meta_key for user meta rules
                                if (isset($rule['meta_key'])) {
                                    // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
                                    $sanitized_rule['meta_key'] = sanitize_text_field($rule['meta_key']);
                                }

                                $sanitized_group['rules'][] = $sanitized_rule;
                            }

                            $sanitized_field['conditional']['groups'][] = $sanitized_group;
                        }
                    }
                } elseif (isset($field['conditional']['show']) && isset($field['conditional']['field']) && isset($field['conditional']['operator']) && isset($field['conditional']['value'])) {
                    // Basic conditional logic - preserve existing structure
                    $sanitized_field['conditional'] = [
                        'show' => (bool) $field['conditional']['show'],
                        'field' => sanitize_text_field($field['conditional']['field']),
                        'operator' => sanitize_text_field($field['conditional']['operator']),
                        'value' => sanitize_text_field($field['conditional']['value']),
                    ];
                } elseif (isset($field['conditional']['field']) && isset($field['conditional']['operator']) && isset($field['conditional']['value'])) {
                    // Basic conditional logic without 'show' property (new format)
                    $sanitized_field['conditional'] = [
                        'field' => sanitize_text_field($field['conditional']['field']),
                        'operator' => sanitize_text_field($field['conditional']['operator']),
                        'value' => sanitize_text_field($field['conditional']['value']),
                    ];
                }
            }

            // Handle math function data
            if (isset($field['math']) && is_array($field['math'])) {

                $sanitized_field['math'] = [
                    'enabled' => isset($field['math']['enabled']) ? (bool) $field['math']['enabled'] : false,
                    'calculation_type' => isset($field['math']['calculation_type']) ? sanitize_text_field($field['math']['calculation_type']) : 'sum',
                    'round_result' => isset($field['math']['round_result']) ? (bool) $field['math']['round_result'] : false,
                    'decimal_places' => isset($field['math']['decimal_places']) ? intval($field['math']['decimal_places']) : 2
                ];

                // Handle custom formula
                if (isset($field['math']['formula']) && $field['math']['calculation_type'] === 'custom') {
                    $sanitized_field['math']['formula'] = sanitize_textarea_field($field['math']['formula']);
                }

                // Handle selected fields for calculations
                if (isset($field['math']['fields']) && is_array($field['math']['fields'])) {
                    $sanitized_field['math']['fields'] = array_map('sanitize_text_field', $field['math']['fields']);
                }
            }

            $sanitized[] = $sanitized_field;
        }

        return $sanitized;
    }

    /**
     * Sanitize form settings
     *
     * @param array $settings Form settings data
     * @return array Sanitized form settings
     */
    public static function sanitize_form_settings($settings)
    {
        if (!is_array($settings)) {
            return self::get_default_form_settings();
        }

        $default_settings = self::get_default_form_settings();
        $sanitized = [];

        foreach ($default_settings as $key => $default_value) {
            $sanitized[$key] = isset($settings[$key]) ? $settings[$key] : $default_value;
        }

        // Special handling for specific settings
        $sanitized['success_message'] = wp_kses_post($sanitized['success_message']);
        $sanitized['validation_failed_message'] = sanitize_text_field($sanitized['validation_failed_message']);
        $sanitized['email_subject'] = sanitize_text_field($sanitized['email_subject']);
        $sanitized['email_message'] = wp_kses_post($sanitized['email_message']);
        $sanitized['to_email'] = self::sanitize_email_list($sanitized['to_email']);
        $sanitized['cc_email'] = self::sanitize_email_list($sanitized['cc_email'] ?? '');
        $sanitized['bcc_email'] = self::sanitize_email_list($sanitized['bcc_email'] ?? '');

        // Handle boolean values properly - check if they are explicitly set
        if (isset($settings['override_email_settings'])) {
            $sanitized['override_email_settings'] = (bool) $settings['override_email_settings'];
        }
        if (isset($settings['send_confirmation_email'])) {
            $sanitized['send_confirmation_email'] = (bool) $settings['send_confirmation_email'];
        }

        // Handle captcha type setting
        if (isset($settings['captcha_type'])) {
            $sanitized['captcha_type'] = sanitize_text_field($settings['captcha_type']);
        }

        if (isset($settings['store_submissions'])) {
            $sanitized['store_submissions'] = (bool) $settings['store_submissions'];
        }

        if (isset($settings['store_abandoned_forms'])) {
            $sanitized['store_abandoned_forms'] = (bool) $settings['store_abandoned_forms'];
        }

        if (isset($settings['enable_scheduling'])) {
            $sanitized['enable_scheduling'] = (bool) $settings['enable_scheduling'];
        }

        // Handle webhook boolean settings
        $webhook_use_settings = [
            'webhook_google_sheets_use',
            'webhook_slack_use',
            'webhook_discord_use',
            'webhook_telegram_use',
            'webhook_custom_use'
        ];

        foreach ($webhook_use_settings as $webhook_setting) {
            if (isset($settings[$webhook_setting])) {
                $sanitized[$webhook_setting] = (bool) $settings[$webhook_setting];
            }
        }

        // Handle webhook URL and text settings
        $webhook_url_settings = [
            'webhook_google_sheets_url',
            'webhook_slack_url',
            'webhook_discord_url',
            'webhook_custom_url'
        ];

        foreach ($webhook_url_settings as $webhook_setting) {
            if (isset($settings[$webhook_setting])) {
                $sanitized[$webhook_setting] = esc_url_raw($settings[$webhook_setting]);
            }
        }

        // Handle webhook text settings
        $webhook_text_settings = [
            'webhook_slack_channel',
            'webhook_telegram_bot_token',
            'webhook_telegram_chat_id',
            'webhook_custom_method'
        ];

        foreach ($webhook_text_settings as $webhook_setting) {
            if (isset($settings[$webhook_setting])) {
                $sanitized[$webhook_setting] = sanitize_text_field($settings[$webhook_setting]);
            }
        }

        $sanitized['confirmation_subject'] = sanitize_text_field($sanitized['confirmation_subject']);
        $sanitized['confirmation_message'] = wp_kses_post($sanitized['confirmation_message']);
        $sanitized['submit_button_text'] = sanitize_text_field($sanitized['submit_button_text']);
        $sanitized['submit_button_width'] = sanitize_text_field($sanitized['submit_button_width']);
        $sanitized['submit_button_align'] = sanitize_text_field($sanitized['submit_button_align']);
        $sanitized['form_theme'] = sanitize_text_field($sanitized['form_theme']);

        // Handle scheduling settings
        if (isset($settings['schedule_start'])) {
            $sanitized['schedule_start'] = sanitize_text_field($settings['schedule_start']);
        }
        if (isset($settings['schedule_end'])) {
            $sanitized['schedule_end'] = sanitize_text_field($settings['schedule_end']);
        }
        if (isset($settings['schedule_message_before'])) {
            $sanitized['schedule_message_before'] = wp_kses_post($settings['schedule_message_before']);
        }
        if (isset($settings['schedule_message_after'])) {
            $sanitized['schedule_message_after'] = wp_kses_post($settings['schedule_message_after']);
        }

        // Handle form_styling array
        if (isset($settings['form_styling']) && is_array($settings['form_styling'])) {
            $sanitized['form_styling'] = [];
            $allowed_styling_keys = [
                'label_color',
                'field_background',
                'input_text_color',
                'placeholder_color',
                'field_border',
                'input_border_radius',
                'form_padding',
                'field_spacing',
                'button_color',
                'button_text_color',
                'button_hover_bg_color',
                'button_hover_text_color',
                'button_border_radius',
                'font_family',
                'font_size'
            ];

            foreach ($allowed_styling_keys as $key) {
                if (isset($settings['form_styling'][$key])) {
                    // Sanitize color values
                    if (strpos($key, 'color') !== false) {
                        $sanitized['form_styling'][$key] = sanitize_hex_color($settings['form_styling'][$key]);
                    }
                    // Sanitize numeric values (border radius, padding, spacing, font size)
                    elseif (in_array($key, ['input_border_radius', 'form_padding', 'field_spacing', 'button_border_radius', 'font_size'])) {
                        $sanitized['form_styling'][$key] = absint($settings['form_styling'][$key]);
                    }
                    // Sanitize font family
                    elseif ($key === 'font_family') {
                        $sanitized['form_styling'][$key] = sanitize_text_field($settings['form_styling'][$key]);
                    } else {
                        $sanitized['form_styling'][$key] = sanitize_text_field($settings['form_styling'][$key]);
                    }
                }
            }
        } elseif (!isset($sanitized['form_styling'])) {
            $sanitized['form_styling'] = [];
        }

        return $sanitized;
    }

    /**
     * Get default form settings
     *
     * @return array Default form settings
     */
    public static function get_default_form_settings()
    {
        return [
            'success_message' => __('Thank you for your submission!', 'sigmaforms-pro'),
            'validation_failed_message' => '',
            'override_email_settings' => false,
            // translators: %s is the blog name.
            'email_subject' => get_option('sf_default_email_subject', sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name'))),
            'email_message' => get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro')),
            'to_email' => get_option('sf_admin_email', get_option('admin_email')),
            'cc_email' => get_option('sf_admin_email_cc', ''),
            'bcc_email' => get_option('sf_admin_email_bcc', ''),
            'send_confirmation_email' => false,
            'confirmation_subject' => get_option('sf_default_confirmation_subject', __('Thank you for your submission', 'sigmaforms-pro')),
            'confirmation_message' => get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro')),
            'captcha_type' => '',
            'store_submissions' => true,
            'store_abandoned_forms' => false,
            'submit_button_text' => __('Submit', 'sigmaforms-pro'),
            'submit_button_width' => 'auto',
            'submit_button_align' => 'left',
            // Empty follows the global theme setting (Settings > Form Styling).
            'form_theme' => '',
            'form_styling' => [], // Per-form custom styling (empty array means use global defaults)

            // Webhook settings - default to false
            'webhook_google_sheets_use' => false,
            'webhook_slack_use' => false,
            'webhook_discord_use' => false,
            'webhook_telegram_use' => false,
            'webhook_custom_use' => false,

            // Webhook URLs and settings - default to empty
            'webhook_google_sheets_url' => '',
            'webhook_slack_url' => '',
            'webhook_slack_channel' => '',
            'webhook_discord_url' => '',
            'webhook_telegram_bot_token' => '',
            'webhook_telegram_chat_id' => '',
            'webhook_custom_url' => '',
            'webhook_custom_method' => 'POST',

            // Scheduling settings
            'enable_scheduling' => false,
            'schedule_start' => '',
            'schedule_end' => '',
            'schedule_message_before' => __('This form will be available soon. Please check back later.', 'sigmaforms-pro'),
            'schedule_message_after' => __('This form is no longer accepting submissions.', 'sigmaforms-pro')
        ];
    }

    /**
     * Extensions that must never be accepted via public form uploads.
     *
     * @return array<int, string>
     */
    public static function get_blocked_upload_extensions() {
        return [
            'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar', 'phps', 'pht',
            'shtml', 'htaccess', 'htpasswd', 'pl', 'py', 'rb', 'sh', 'bash', 'cgi', 'asp',
            'aspx', 'jsp', 'jspx', 'js', 'mjs', 'cjs', 'jar', 'com', 'bat', 'cmd', 'exe',
            'msi', 'dll', 'so', 'dylib', 'vbs', 'vbe', 'jse', 'ws', 'wsf', 'wsh', 'scr',
            'inf', 'reg', 'cpl', 'msc', 'app', 'deb', 'rpm', 'dmg', 'apk', 'ipa', 'war',
            'cfml', 'cfm', 'swf',
        ];
    }

    /**
     * Safe default allow-list for file upload fields.
     *
     * @return array<int, string>
     */
    public static function get_default_allowed_file_types() {
        return ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.jpg', '.jpeg', '.png', '.gif', '.webp'];
    }

    /**
     * @param string $extension File extension with or without leading dot.
     * @return bool
     */
    public static function is_blocked_upload_extension($extension) {
        $extension = strtolower(ltrim((string) $extension, '.'));

        return $extension !== '' && in_array($extension, self::get_blocked_upload_extensions(), true);
    }

    /**
     * @param string $filename Uploaded file name.
     * @return string
     */
    public static function normalize_upload_extension($filename) {
        return strtolower(pathinfo(sanitize_file_name((string) $filename), PATHINFO_EXTENSION));
    }

    /**
     * @param array<int, string> $extensions
     * @return array<int, string>
     */
    public static function filter_allowed_file_types($extensions) {
        if (!is_array($extensions)) {
            return [];
        }

        $allowed = [];

        foreach ($extensions as $extension) {
            $clean = strtolower(ltrim(sanitize_text_field((string) $extension), '.'));

            if ($clean !== '' && !self::is_blocked_upload_extension($clean)) {
                $allowed[] = '.' . $clean;
            }
        }

        return array_values(array_unique($allowed));
    }

    /**
     * @param string $extensions Comma-separated custom extensions.
     * @return string
     */
    public static function sanitize_custom_file_extensions($extensions) {
        $parts = array_map('trim', explode(',', sanitize_text_field((string) $extensions)));
        $safe = [];

        foreach ($parts as $extension) {
            $clean = strtolower(ltrim($extension, '.'));

            if ($clean !== '' && !self::is_blocked_upload_extension($clean)) {
                $safe[] = $clean;
            }
        }

        return implode(', ', array_unique($safe));
    }

    /**
     * Resolve the effective allow-list for a file field.
     *
     * @param array $field Field configuration.
     * @return array<int, string>
     */
    public static function get_allowed_extensions_from_field($field) {
        $allowed = [];

        if (!empty($field['allowed_file_types']) && is_array($field['allowed_file_types'])) {
            foreach ($field['allowed_file_types'] as $extension) {
                $clean = strtolower(ltrim((string) $extension, '.'));

                if ($clean !== '' && !self::is_blocked_upload_extension($clean)) {
                    $allowed[] = $clean;
                }
            }
        }

        if (!empty($field['custom_file_extensions'])) {
            $custom_extensions = array_map('trim', explode(',', (string) $field['custom_file_extensions']));

            foreach ($custom_extensions as $extension) {
                $clean = strtolower(ltrim($extension, '.'));

                if ($clean !== '' && !self::is_blocked_upload_extension($clean)) {
                    $allowed[] = $clean;
                }
            }
        }

        if (empty($allowed)) {
            foreach (self::get_default_allowed_file_types() as $extension) {
                $allowed[] = strtolower(ltrim($extension, '.'));
            }
        }

        return array_values(array_unique($allowed));
    }

    /**
     * Validate an uploaded file against field rules and global security policy.
     *
     * @param array $file  $_FILES-style file array.
     * @param array $field Field configuration.
     * @return array{error: string}|false
     */
    public static function validate_uploaded_file($file, $field) {
        $max_file_size = 10 * 1024 * 1024;

        if (!empty($field['max_file_size_value']) && !empty($field['max_file_size_unit'])) {
            $size_value = (int) $field['max_file_size_value'];
            $size_unit = $field['max_file_size_unit'];

            if ($size_value > 0) {
                if ($size_unit === 'KB') {
                    $max_file_size = $size_value * 1024;
                } else {
                    $max_file_size = $size_value * 1024 * 1024;
                }
            }
        }

        if (!empty($file['size']) && (int) $file['size'] > $max_file_size) {
            $message = !empty($field['file_size_error_message'])
                ? $field['file_size_error_message']
                : sprintf(
                    /* translators: %s is the maximum file size */
                    __('File size exceeds the maximum allowed size of %s.', 'sigmaforms-pro'),
                    size_format($max_file_size)
                );

            return ['error' => $message];
        }

        $file_extension = self::normalize_upload_extension($file['name'] ?? '');

        if ($file_extension === '' || self::is_blocked_upload_extension($file_extension)) {
            return [
                'error' => !empty($field['file_type_error_message'])
                    ? $field['file_type_error_message']
                    : __('This file type is not permitted for security reasons.', 'sigmaforms-pro'),
            ];
        }

        $allowed_extensions = self::get_allowed_extensions_from_field($field);

        if (!in_array($file_extension, $allowed_extensions, true)) {
            $message = !empty($field['file_type_error_message'])
                ? $field['file_type_error_message']
                : sprintf(
                    /* translators: 1: uploaded extension, 2: allowed extensions */
                    __('File type ".%1$s" is not allowed. Allowed types: %2$s', 'sigmaforms-pro'),
                    $file_extension,
                    implode(', ', array_map(
                        static function ($extension) {
                            return '.' . $extension;
                        },
                        $allowed_extensions
                    ))
                );

            return ['error' => $message];
        }

        return false;
    }

    /**
     * Neutralise a CSV cell so spreadsheet software cannot treat it as a formula.
     *
     * Exported cells carry visitor-supplied text (field values, user agents), and a cell
     * beginning with =, +, -, @ or a control character is executed by Excel and Google
     * Sheets when the export is opened. Prefixing with a single quote keeps the value
     * readable while forcing it to be treated as text.
     *
     * @param mixed $value Cell value.
     * @return mixed
     */
    public static function sanitize_csv_cell($value) {
        if (!is_string($value) || $value === '') {
            return $value;
        }

        if (preg_match('/^[=+\-@\t\r]/', $value)) {
            return "'" . $value;
        }

        return $value;
    }

    /**
     * Neutralise every cell of a CSV row.
     *
     * @param array $row Row values.
     * @return array
     */
    public static function sanitize_csv_row($row) {
        return array_map([__CLASS__, 'sanitize_csv_cell'], $row);
    }

    /**
     * Whether the current user may read or manage forms, submissions and abandoned forms.
     *
     * The admin screens are registered under 'manage_options', so the REST routes use the
     * same bar instead of 'edit_posts' — submissions hold personal data and should not be
     * readable by every Contributor. Sites that deliberately delegate form management to a
     * lower role can opt in through the filter.
     *
     * @return bool
     */
    public static function current_user_can_manage_forms() {
        return current_user_can(self::get_manage_forms_capability());
    }

    /**
     * Capability for forms, submissions, abandoned forms and analytics.
     *
     * Used by the admin menus, the AJAX handlers and the REST routes alike, so
     * the sigmaforms_manage_forms_capability filter delegates the whole forms
     * area. Settings, white label and license stay with manage_options.
     *
     * @return string
     */
    public static function get_manage_forms_capability() {
        $capability = apply_filters('sigmaforms_manage_forms_capability', 'manage_options');

        return is_string($capability) && $capability !== '' ? $capability : 'manage_options';
    }

    /**
     * Check that a value is a strict base64 image data URI and nothing else.
     *
     * Signature values reach the admin screens from unauthenticated endpoints, so a
     * prefix check such as strpos($value, 'data:image') === 0 is not enough: the tail
     * of the string can carry quotes and event handlers that break out of an HTML
     * attribute. Only png/jpeg payloads made of base64 characters are accepted here.
     *
     * @param mixed $value Candidate data URI.
     * @return bool
     */
    public static function is_safe_image_data_uri($value) {
        if (!is_string($value) || $value === '') {
            return false;
        }

        return (bool) preg_match('#^data:image/(?:png|jpeg|jpg);base64,[A-Za-z0-9+/]+={0,2}$#', $value);
    }

    /**
     * Write Apache hardening files to the SigmaForms uploads root.
     *
     * @param string $directory Absolute path to wp-content/uploads/sigmaforms.
     * @return void
     */
    public static function ensure_sigmaforms_upload_hardening($directory) {
        if (empty($directory)) {
            return;
        }

        if (!file_exists($directory)) {
            wp_mkdir_p($directory);
        }

        $index_file = trailingslashit($directory) . 'index.php';

        if (!file_exists($index_file)) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Creating protective index.php in uploads.
            file_put_contents($index_file, "<?php\n// Silence is golden.\n");
        }

        $htaccess_file = trailingslashit($directory) . '.htaccess';

        if (!file_exists($htaccess_file)) {
            $rules = "# SigmaForms upload hardening\n";
            $rules .= "Options -Indexes\n";
            $rules .= "<FilesMatch \"\\.(?:" . implode('|', self::get_blocked_upload_extensions()) . ")$\">\n";
            $rules .= "    <IfModule mod_authz_core.c>\n";
            $rules .= "        Require all denied\n";
            $rules .= "    </IfModule>\n";
            $rules .= "    <IfModule !mod_authz_core.c>\n";
            $rules .= "        Order allow,deny\n";
            $rules .= "        Deny from all\n";
            $rules .= "    </IfModule>\n";
            $rules .= "</FilesMatch>\n";

            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Creating protective .htaccess in uploads.
            file_put_contents($htaccess_file, $rules);
        }
    }

    /**
     * Validate field value based on type
     *
     * @param string $value Field value
     * @param array $field Field configuration
     * @return array Validation result with 'valid' and 'message' keys
     */
    public static function validate_field($value, $field)
    {
        $result = [
            'valid' => true,
            'message' => '',
        ];

        // Check required fields
        if (isset($field['required']) && $field['required'] && empty($value)) {
            $result['valid'] = false;
            // translators: %s is the field label.
            $result['message'] = sprintf(__('%s is required.', 'sigmaforms-pro'), $field['label']);
            return $result;
        }

        // Validate based on field type
        switch ($field['type']) {
            case 'email':
                if (!empty($value) && !is_email($value)) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('%s must be a valid email address.', 'sigmaforms-pro'), $field['label']);
                }
                break;

            case 'number':
                if (!empty($value) && !is_numeric($value)) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('%s must be a number.', 'sigmaforms-pro'), $field['label']);
                }
                break;

            case 'phone':
                if (!empty($value) && !preg_match('/^[0-9()+\-\s]*$/', $value)) {
                    $result['valid'] = false;
                    // translators: %s is the field label.
                    $result['message'] = sprintf(__('%s must be a valid phone number.', 'sigmaforms-pro'), $field['label']);
                }
                break;

            case 'file':
                // File validation is handled during upload process
                // This case is here for completeness - validation happens in Frontend::validate_uploaded_file
                break;
        }

        return $result;
    }

    /**
     * Sanitize a comma-separated list of email addresses.
     *
     * @param string $email_list Comma-separated email addresses.
     * @return string Sanitized comma-separated email addresses.
     */
    public static function sanitize_email_list($email_list) {
        if (empty($email_list) || !is_string($email_list)) {
            return '';
        }

        $emails = array_map('trim', explode(',', $email_list));
        $valid = [];

        foreach ($emails as $email) {
            if ($email === '') {
                continue;
            }

            $sanitized = sanitize_email($email);
            if (!empty($sanitized) && is_email($sanitized)) {
                $valid[] = $sanitized;
            }
        }

        return implode(', ', $valid);
    }

    /**
     * Address to send plugin email from.
     *
     * The SMTP username when it is an email address. Otherwise the site admin
     * email, but only when it belongs to the site's own domain: sending
     * "From: someone@gmail.com" from another server fails DMARC, so those
     * messages were rejected or filed as spam. In that case it falls back to
     * wordpress@<site domain>, the same default wp_mail() uses.
     *
     * @param array $smtp_config Saved SMTP settings.
     * @return string
     */
    public static function get_email_from_address($smtp_config = []) {
        $from = self::resolve_email_from_address((array) $smtp_config);

        /**
         * Filters the From address of SigmaForms email.
         *
         * For example to keep the admin email on a site whose mail provider
         * only accepts that verified sender.
         *
         * @param string $from        Address chosen by SigmaForms.
         * @param array  $smtp_config Saved SMTP settings.
         */
        $filtered = apply_filters('sigmaforms_email_from_address', $from, (array) $smtp_config);

        return is_email($filtered) ? $filtered : $from;
    }

    /**
     * The address get_email_from_address() picks before filtering.
     *
     * @param array $smtp_config Saved SMTP settings.
     * @return string
     */
    private static function resolve_email_from_address($smtp_config) {
        if (!empty($smtp_config['enabled']) && !empty($smtp_config['username']) && is_email($smtp_config['username'])) {
            return $smtp_config['username'];
        }

        $admin_email = (string) get_option('admin_email');
        // This site's own domain: on a domain-mapped multisite the network
        // domain would be the wrong sender.
        $site_host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
        $site_host = preg_replace('/^www\./', '', $site_host);

        // No usable domain (localhost, a bare IP and the like): keep the old
        // behaviour. "wordpress@203.0.113.5" is rejected by PHPMailer.
        if ($site_host === '' || strpos($site_host, '.') === false || filter_var($site_host, FILTER_VALIDATE_IP)) {
            return $admin_email;
        }

        $at = strrchr($admin_email, '@');
        $admin_host = $at ? strtolower(substr($at, 1)) : '';

        if ($admin_host !== '' && ($admin_host === $site_host || substr($site_host, -strlen('.' . $admin_host)) === '.' . $admin_host)) {
            return $admin_email;
        }

        $from = 'wordpress@' . $site_host;

        return is_email($from) ? $from : $admin_email;
    }

    /**
     * Sender name for plugin email, with characters that could break the header removed.
     *
     * @return string
     */
    public static function get_email_from_name() {
        $name = (string) get_option('sf_app_name', get_bloginfo('name'));

        return trim(str_replace(["\r", "\n", '<', '>', '"'], '', $name));
    }

    /**
     * Whether a field with advanced conditional logic is active (shown and
     * enabled) for a submission, mirroring processAdvancedConditionalLogic()
     * in frontend.js: rules inside a group must all match, and groups combine
     * with the logic type ("all" or "any").
     *
     * Date/time rules depend on the visitor's clock, so for those the field
     * counts as active only when the browser actually sent it (hidden and
     * disabled fields are not posted).
     *
     * @param array $conditional   The field's conditional settings.
     * @param array $values        Submitted values keyed by field id.
     * @param bool  $field_was_sent Whether the request contained the field.
     * @return bool|null Null when the field has no advanced conditional logic.
     */
    public static function is_conditional_field_active($conditional, $values, $field_was_sent) {
        if (!is_array($conditional) || empty($conditional['action']) || empty($conditional['groups']) || !is_array($conditional['groups'])) {
            return null;
        }

        $group_results = [];
        foreach ($conditional['groups'] as $group) {
            $rules = isset($group['rules']) && is_array($group['rules']) ? $group['rules'] : [];
            $group_met = true;
            foreach ($rules as $rule) {
                $source = $rule['source_type'] ?? 'field';
                if ($source === 'date') {
                    return (bool) $field_was_sent;
                }
                if (!self::conditional_rule_matches($rule, $values)) {
                    $group_met = false;
                    break;
                }
            }
            $group_results[] = $group_met;
        }

        $met = ($conditional['logic_type'] ?? 'all') === 'any'
            ? in_array(true, $group_results, true)
            : !in_array(false, $group_results, true);

        switch ($conditional['action']) {
            case 'hide':
            case 'disable':
                return !$met;
            default: // show, enable
                return $met;
        }
    }

    /**
     * Evaluate one conditional rule (field or user source) like compareValues() in frontend.js.
     *
     * @param array $rule   Rule settings.
     * @param array $values Submitted values keyed by field id.
     * @return bool
     */
    private static function conditional_rule_matches($rule, $values) {
        $source = $rule['source_type'] ?? 'field';
        $key = (string) ($rule['field'] ?? '');

        if ($source === 'user') {
            $user = wp_get_current_user();
            if ($key === 'logged_in') {
                $actual = is_user_logged_in() ? '1' : '';
            } elseif ($key === 'user_role') {
                $actual = !empty($user->roles) ? (string) reset($user->roles) : '';
            } elseif ($key === 'user_meta' && !empty($rule['meta_key']) && is_user_logged_in()) {
                $meta = get_user_meta($user->ID, (string) $rule['meta_key'], true);
                $actual = is_scalar($meta) ? (string) $meta : '';
            } else {
                $actual = '';
            }
        } else {
            $value = $values[$key] ?? '';
            $actual = is_array($value) ? implode(',', array_map('strval', $value)) : (string) $value;
        }

        $expected = (string) ($rule['value'] ?? '');

        switch ($rule['operator'] ?? '=') {
            case '=':            return $actual == $expected; // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Matches the loose == in frontend.js.
            case '!=':           return $actual != $expected; // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual -- Matches frontend.js.
            case '>':            return (float) $actual > (float) $expected;
            case '<':            return (float) $actual < (float) $expected;
            case '>=':           return (float) $actual >= (float) $expected;
            case '<=':           return (float) $actual <= (float) $expected;
            case 'contains':     return $expected === '' || strpos($actual, $expected) !== false;
            case 'starts_with':  return strpos($actual, $expected) === 0;
            case 'ends_with':    return $expected === '' || substr($actual, -strlen($expected)) === $expected;
            case 'is_checked':   return $actual === '1';
            case 'is_not_checked': return $actual !== '1';
            case 'is_empty':     return $actual === '';
            case 'is_not_empty': return $actual !== '';
            default:             return false;
        }
    }

    /**
     * The submitter's email address, if the submission has one.
     *
     * Prefers fields of type "email", then any field whose id mentions email.
     *
     * @param array $submission_data Submitted values keyed by field id.
     * @param array $form_fields     Form field definitions.
     * @return string Valid address or ''.
     */
    public static function find_submitter_email($submission_data, $form_fields) {
        foreach ((array) $form_fields as $field) {
            if (isset($field['type'], $field['id']) && $field['type'] === 'email' && !empty($submission_data[$field['id']])) {
                $email = sanitize_email((string) $submission_data[$field['id']]);
                if (is_email($email)) {
                    return $email;
                }
            }
        }

        foreach ((array) $submission_data as $field_id => $value) {
            if (is_string($value) && stripos((string) $field_id, 'email') !== false) {
                $email = sanitize_email($value);
                if (is_email($email)) {
                    return $email;
                }
            }
        }

        return '';
    }

    /**
     * Reply-To header for a valid address, or nothing.
     *
     * @param string $email Address replies should go to.
     * @return array
     */
    public static function get_email_reply_to_header($email) {
        $email = sanitize_email((string) $email);

        return is_email($email) ? ['Reply-To: ' . $email] : [];
    }

    /**
     * First valid address from the "Default Admin Email" setting (may be a list).
     *
     * @return string
     */
    public static function get_site_contact_email() {
        foreach (array_map('trim', explode(',', (string) get_option('sf_admin_email', ''))) as $email) {
            if (is_email($email)) {
                return $email;
            }
        }

        return (string) get_option('admin_email');
    }

    /**
     * Build CC and BCC email headers.
     *
     * @param string $cc Comma-separated CC addresses.
     * @param string $bcc Comma-separated BCC addresses.
     * @return array Email headers for CC and BCC.
     */
    public static function get_email_cc_bcc_headers($cc = '', $bcc = '') {
        $headers = [];
        $cc = self::sanitize_email_list($cc);
        $bcc = self::sanitize_email_list($bcc);

        if (!empty($cc)) {
            $headers[] = 'Cc: ' . $cc;
        }

        if (!empty($bcc)) {
            $headers[] = 'Bcc: ' . $bcc;
        }

        return $headers;
    }

    /**
     * Replace placeholders in a string with actual field values
     *
     * @param string $content Content with placeholders
     * @param array $fields Field values
     * @param array $field_definitions Optional field definitions to identify signature fields
     * @return string Content with replaced placeholders
     */
    public static function replace_placeholders($content, $fields, $field_definitions = [])
    {
        // Create a map of field IDs to their types for quick lookup
        $field_types = [];
        if (!empty($field_definitions)) {
            foreach ($field_definitions as $field_def) {
                if (isset($field_def['id']) && isset($field_def['type'])) {
                    $field_types[$field_def['id']] = $field_def['type'];
                }
            }
        }

        // Replace {field_id} with field value
        foreach ($fields as $id => $value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }

            // Special handling for signature fields - convert long data URIs to clickable links
            if (isset($field_types[$id]) && $field_types[$id] === 'signature') {
                $value = self::process_signature_for_display($value, $id);
            }

            // Special handling for file upload fields - convert URLs to clickable links on separate lines
            if (isset($field_types[$id]) && $field_types[$id] === 'file') {
                $value = self::process_file_upload_for_display($value);
            }

            $content = str_replace('{' . $id . '}', $value, $content);
        }

        // Replace {all_fields} with formatted list of all fields
        if (strpos($content, '{all_fields}') !== false) {
            $all_fields = '';

            foreach ($fields as $id => $value) {
                if (is_array($value)) {
                    $value = implode(', ', $value);
                }

                // Special handling for signature fields in all_fields
                if (isset($field_types[$id]) && $field_types[$id] === 'signature') {
                    $value = self::process_signature_for_display($value, $id);
                }

                // Special handling for file upload fields in all_fields
                if (isset($field_types[$id]) && $field_types[$id] === 'file') {
                    $value = self::process_file_upload_for_display($value);
                }

                // Use actual field label if available, otherwise format the ID
                $field_name = '';
                foreach ($field_definitions as $field_def) {
                    if (isset($field_def['id']) && $field_def['id'] === $id) {
                        $field_name = isset($field_def['label']) ? $field_def['label'] : ucwords(str_replace(['_', '-'], ' ', $id));
                        break;
                    }
                }
                if (empty($field_name)) {
                    $field_name = ucwords(str_replace(['_', '-'], ' ', $id));
                }
                $all_fields .= $field_name . ': ' . $value . "\n";
            }

            $content = str_replace('{all_fields}', $all_fields, $content);
        }

        // Replace {date} with current date and time
        if (strpos($content, '{date}') !== false) {
            $current_date = current_time('F j, Y \a\t g:i a');
            $content = str_replace('{date}', $current_date, $content);
        }

        // Replace {name} with first name field found
        if (strpos($content, '{name}') !== false) {
            $name = '';
            foreach ($fields as $id => $value) {
                if (strpos($id, 'name') !== false || strpos($id, 'Name') !== false) {
                    $name = $value;
                    break;
                }
            }
            $content = str_replace('{name}', $name, $content);
        }

        // Replace {email} with first email field found
        if (strpos($content, '{email}') !== false) {
            $email = '';
            foreach ($fields as $id => $value) {
                if (strpos($id, 'email') !== false || strpos($id, 'Email') !== false) {
                    $email = $value;
                    break;
                }
            }
            $content = str_replace('{email}', $email, $content);
        }

        return $content;
    }

    /**
     * Process form data for webhooks, converting signatures to URLs
     *
     * @param array $form_data The form submission data
     * @param array $field_definitions Field definitions to identify signature fields
     * @return array Processed form data with signature URLs
     */
    public static function process_form_data_for_webhooks($form_data, $field_definitions = [])
    {
        // Create a map of field IDs to their types for quick lookup
        $field_types = [];
        if (!empty($field_definitions)) {
            foreach ($field_definitions as $field_def) {
                if (isset($field_def['id']) && isset($field_def['type'])) {
                    $field_types[$field_def['id']] = $field_def['type'];
                }
            }
        }

        $processed_data = [];

        foreach ($form_data as $field_id => $value) {
            if (isset($field_types[$field_id]) && $field_types[$field_id] === 'signature') {
                // For signatures, convert to just the URL (not HTML link)
                $signature_url = self::convert_signature_to_url($value, $field_id);
                $processed_data[$field_id] = $signature_url ?: 'No signature provided';
            } else {
                $processed_data[$field_id] = $value;
            }
        }

        return $processed_data;
    }

    /**
     * Format form data with field labels instead of IDs
     *
     * @param array $form_data The form submission data (field_id => value)
     * @param array $field_definitions Field definitions
     * @return array Formatted data (field_label => value)
     */
    public static function format_data_with_labels($form_data, $field_definitions = [])
    {
        // Create a map of field IDs to labels
        $id_to_label = [];
        if (!empty($field_definitions)) {
            foreach ($field_definitions as $field_def) {
                if (isset($field_def['id']) && isset($field_def['label'])) {
                    $id_to_label[$field_def['id']] = $field_def['label'];
                }
            }
        }

        $formatted_data = [];
        foreach ($form_data as $field_id => $value) {
            $label = isset($id_to_label[$field_id])
                ? $id_to_label[$field_id]
                : ucwords(str_replace(['_', '-'], ' ', $field_id));
            $formatted_data[$label] = $value;
        }

        return $formatted_data;
    }

    /**
     * Convert signature data URI to just a URL (for webhooks)
     *
     * @param string $signature_data The base64 signature data URI or already converted URL
     * @param string $field_name The field name for naming the file
     * @return string|null The URL to the signature image or null on error
     */
    public static function convert_signature_to_url($signature_data, $field_name = 'signature')
    {
        // If it's already a URL, just return it
        if (!empty($signature_data) && (filter_var($signature_data, FILTER_VALIDATE_URL) || strpos($signature_data, 'http') === 0)) {
            return $signature_data;
        }
        
        // Handle base64 data (for backward compatibility with old submissions)
        return self::save_signature_from_base64($signature_data, $field_name);
    }

    /**
     * Convert signature data URI to a clickable link
     *
     * @param string $signature_data The base64 signature data URI or already converted URL
     * @param string $field_name The field name for naming the file
     * @return string Clickable link or error message
     */
    public static function process_signature_for_display($signature_data, $field_name = 'signature')
    {
        // If it's already a URL, return it as a clickable link
        if (!empty($signature_data) && (filter_var($signature_data, FILTER_VALIDATE_URL) || strpos($signature_data, 'http') === 0)) {
            return '<a href="' . esc_url($signature_data) . '" target="_blank">' . __('View Signature', 'sigmaforms-pro') . '</a>';
        }
        
        // Handle email attachment format (e.g., "signature-field_123.png (Email Attachment)")
        if (!empty($signature_data) && strpos($signature_data, '(Email Attachment)') !== false) {
            // Extract just the filename
            $filename = trim(str_replace('(Email Attachment)', '', $signature_data));
            return $filename . ' ' . __('(Email Attachment)', 'sigmaforms-pro');
        }
        
        // Handle base64 data (for backward compatibility with old submissions)
        $url = self::save_signature_from_base64($signature_data, $field_name);
        
        if ($url) {
            return sprintf(
                '<a href="%s" target="_blank" style="color: #0073aa; text-decoration: underline;">%s</a>',
                esc_url($url),
                __('Click to view signature', 'sigmaforms-pro')
            );
        }
        
        return __('No signature provided', 'sigmaforms-pro');
    }

    /**
     * Process file upload value for display in emails
     *
     * @param string $file_data The file URL(s) or attachment info
     * @return string Formatted file links
     */
    public static function process_file_upload_for_display($file_data)
    {
        if (empty($file_data)) {
            return __('No files uploaded', 'sigmaforms-pro');
        }

        // Check if multiple files (comma-separated)
        if (strpos($file_data, ', ') !== false) {
            $file_urls = explode(', ', $file_data);
            $file_links = [];
            
            foreach ($file_urls as $file_url) {
                $file_url = trim($file_url);
                
                // Check if it's an email attachment format
                if (strpos($file_url, '(Email Attachment)') !== false) {
                    $filename = trim(str_replace('(Email Attachment)', '', $file_url));
                    $file_links[] = $filename . ' ' . __('(Email Attachment)', 'sigmaforms-pro');
                } elseif (filter_var($file_url, FILTER_VALIDATE_URL) || strpos($file_url, 'http') === 0) {
                    // URL - extract filename and create clickable link
                    $filename = basename(wp_parse_url($file_url, PHP_URL_PATH));
                    $file_links[] = sprintf(
                        '<a href="%s" target="_blank" style="color: #0073aa; text-decoration: underline;">%s</a>',
                        esc_url($file_url),
                        esc_html($filename)
                    );
                } else {
                    $file_links[] = esc_html($file_url);
                }
            }
            
            // Join with line breaks for email display
            return implode("\n", $file_links);
        }
        
        // Single file
        // Check if it's an email attachment format
        if (strpos($file_data, '(Email Attachment)') !== false) {
            $filename = trim(str_replace('(Email Attachment)', '', $file_data));
            return $filename . ' ' . __('(Email Attachment)', 'sigmaforms-pro');
        } elseif (filter_var($file_data, FILTER_VALIDATE_URL) || strpos($file_data, 'http') === 0) {
            // URL - extract filename and create clickable link
            $filename = basename(wp_parse_url($file_data, PHP_URL_PATH));
            return sprintf(
                '<a href="%s" target="_blank" style="color: #0073aa; text-decoration: underline;">%s</a>',
                esc_url($file_data),
                esc_html($filename)
            );
        }
        
        return esc_html($file_data);
    }

    /**
     * Save signature from base64 data to file system
     *
     * @param string $signature_data Base64 signature data URI
     * @param string $field_name Field name for filename
     * @return string|null URL to saved file or null on error
     */
    private static function save_signature_from_base64($signature_data, $field_name = 'signature')
    {
        // Validate base64 data
        if (empty($signature_data) || !preg_match('/^data:image\/(png|jpeg|jpg);base64,/', $signature_data)) {
            return null;
        }

        // Extract and decode base64 data
        $parts = explode(',', $signature_data, 2);
        if (count($parts) !== 2) {
            return null;
        }

        $decoded_image = base64_decode($parts[1]);
        if ($decoded_image === false) {
            return null;
        }

        // Get image type and extension
        preg_match('/data:image\/([^;]+)/', $signature_data, $matches);
        $image_type = isset($matches[1]) ? $matches[1] : 'png';
        $extension = $image_type === 'jpeg' ? 'jpg' : $image_type;

        // Generate unique filename
        $filename = sanitize_file_name('signature-' . $field_name . '-' . time() . '-' . wp_generate_password(8, false) . '.' . $extension);

        // Get upload directory with sigmaforms structure
        $upload_dir = wp_upload_dir();
        if ($upload_dir['error']) {
            return null;
        }

        // Use the same directory structure as site storage: /sigmaforms/Y/m
        $subdir = '/sigmaforms' . gmdate('/Y/m');
        $dir_path = $upload_dir['basedir'] . $subdir;
        $dir_url = $upload_dir['baseurl'] . $subdir;

        // Create directory if it doesn't exist
        if (!file_exists($dir_path)) {
            wp_mkdir_p($dir_path);
        }

        // Save file
        $file_path = $dir_path . '/' . $filename;
        if (file_put_contents($file_path, $decoded_image) === false) {
            return null;
        }

        return $dir_url . '/' . $filename;
    }

    /**
     * Resolve a stored upload URL to a real path inside the uploads directory.
     *
     * Stored field values are attacker controlled: a form submission can put an
     * arbitrary string into a file field, so a value that looks like an upload URL
     * may carry traversal sequences. Only a path that canonicalises to a regular
     * file strictly inside the uploads base directory is ever returned.
     *
     * @param string $url Stored file URL.
     * @return string|false Absolute path inside the uploads directory, or false.
     */
    public static function resolve_managed_upload_path($url) {
        if (!is_string($url) || '' === $url) {
            return false;
        }

        $upload_dir = wp_upload_dir();
        if (!empty($upload_dir['error'])) {
            return false;
        }

        $baseurl = untrailingslashit($upload_dir['baseurl']);
        $basedir = wp_normalize_path(untrailingslashit($upload_dir['basedir']));

        // Only files served from our own uploads directory are ours to delete.
        if (strpos($url, $baseurl . '/') !== 0) {
            return false;
        }

        // Drop any query string or fragment before touching the filesystem.
        $relative = wp_parse_url(substr($url, strlen($baseurl)), PHP_URL_PATH);
        if (!is_string($relative) || '' === $relative) {
            return false;
        }

        $candidate = wp_normalize_path($basedir . rawurldecode($relative));

        $real_path = realpath($candidate);
        $real_base = realpath($basedir);
        if (false === $real_path || false === $real_base) {
            return false;
        }

        $real_path = wp_normalize_path($real_path);
        $real_base = wp_normalize_path($real_base);

        // Containment is checked after canonicalisation, so traversal sequences and
        // symlinks that escape the uploads directory are both rejected here.
        if (strpos($real_path, $real_base . '/') !== 0 || !is_file($real_path)) {
            return false;
        }

        return $real_path;
    }

    /**
     * Check if a valid API key is configured for the selected provider
     *
     * @return bool True if API key is configured, false otherwise
     */
    public static function is_api_key_configured()
    {
        $api_key = get_option('sf_ai_api_key', '');
        return !empty($api_key);
    }
}
