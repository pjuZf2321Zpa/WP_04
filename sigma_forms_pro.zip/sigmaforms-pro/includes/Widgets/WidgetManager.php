<?php
/**
 * Widget Manager
 * 
 * Manages page builder widgets (Gutenberg, Elementor, etc.)
 *
 * @package SigmaForms
 */

namespace SigmaForms\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Widget Manager Class
 */
class WidgetManager {
    
    /**
     * Plugin instance
     *
     * @var \SigmaForms\Plugin
     */
    private $plugin;
    
    /**
     * Gutenberg Widget instance
     *
     * @var GutenbergWidget
     */
    private $gutenberg_widget;
    
    /**
     * Elementor Widget instance
     *
     * @var ElementorWidget
     */
    private $elementor_widget;
    
    /**
     * Constructor
     *
     * @param \SigmaForms\Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->init();
    }
    
    /**
     * Initialize widgets
     */
    private function init() {
        // Initialize Gutenberg Widget
        if ($this->is_gutenberg_active()) {
            require_once __DIR__ . '/GutenbergWidget.php';
            $this->gutenberg_widget = new GutenbergWidget($this->plugin);
        }
        
        // Initialize Elementor Widget
        if ($this->is_elementor_active()) {
            require_once __DIR__ . '/ElementorWidget.php';
            $this->elementor_widget = new ElementorWidget($this->plugin);
        }
    }
    
    /**
     * Check if Gutenberg is active
     *
     * @return bool
     */
    private function is_gutenberg_active() {
        return function_exists('register_block_type');
    }
    
    /**
     * Check if Elementor is active
     *
     * @return bool
     */
    private function is_elementor_active() {
        return did_action('elementor/loaded');
    }
    
    /**
     * Get Gutenberg widget instance
     *
     * @return GutenbergWidget|null
     */
    public function get_gutenberg_widget() {
        return $this->gutenberg_widget;
    }
    
    /**
     * Get Elementor widget instance
     *
     * @return ElementorWidget|null
     */
    public function get_elementor_widget() {
        return $this->elementor_widget;
    }
}
