<?php
/**
 * Gutenberg Block Widget
 * 
 * Provides a Gutenberg block for embedding forms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Gutenberg Widget Class
 */
class GutenbergWidget {
    
    /**
     * Plugin instance
     *
     * @var \SigmaForms\Plugin
     */
    private $plugin;
    
    /**
     * Block name
     *
     * @var string
     */
    private $block_name = 'sigmaforms/form-block';
    
    /**
     * Constructor
     *
     * @param \SigmaForms\Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->init();
    }
    
    /**
     * Initialize Gutenberg block
     */
    private function init() {
        // Enqueue block editor assets first
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_block_editor_assets']);
        
        // Register block after assets
        add_action('init', [$this, 'register_block'], 20);
    }
    
    /**
     * Register Gutenberg block
     */
    public function register_block() {
        // Skip if function doesn't exist
        if (!function_exists('register_block_type')) {
            return;
        }
        
        // Editor styles: the block's own, plus the front-end form and theme
        // styles for the preview. As editor_style they are loaded inside the
        // iframed editor; styles enqueued on enqueue_block_editor_assets only
        // reach the outer admin page, so the preview was unstyled.
        wp_register_style(
            'sigmaforms-gutenberg-block-editor',
            SF_PLUGIN_URL . 'assets/css/gutenberg-block-editor.css',
            ['wp-edit-blocks'],
            SF_VERSION
        );
        wp_register_style('sf-frontend-styles-editor', SF_PLUGIN_URL . 'assets/css/frontend.css', [], SF_VERSION);

        $editor_styles = ['sigmaforms-gutenberg-block-editor', 'sf-frontend-styles-editor'];
        foreach (['minimal', 'modern', 'classic', 'transition', 'soft'] as $theme) {
            wp_register_style('sf-' . $theme . '-theme-editor', SF_PLUGIN_URL . 'assets/css/themes/' . $theme . '.css', ['sf-frontend-styles-editor'], SF_VERSION);
            $editor_styles[] = 'sf-' . $theme . '-theme-editor';
        }

        // Register block with editor script
        register_block_type($this->block_name, [
            'attributes' => [
                'formId' => [
                    'type' => 'string',
                    'default' => '',
                ],
                'formTitle' => [
                    'type' => 'string',
                    'default' => '',
                ],
            ],
            'render_callback' => [$this, 'render_block'],
            'editor_script' => 'sigmaforms-gutenberg-block',
            'editor_style' => $editor_styles,
        ]);
    }
    
    /**
     * Render block on frontend
     *
     * @param array $attributes Block attributes
     * @return string
     */
    public function render_block($attributes) {
        $form_id = isset($attributes['formId']) ? intval($attributes['formId']) : 0;
        
        if (empty($form_id)) {
            return '<div class="sf-block-placeholder" style="text-align: center; padding: 60px 30px; background: #f9f9f9; border: 2px dashed #ddd; border-radius: 4px;">' . 
                   '<p style="margin: 0; color: #555; font-size: 16px;">' . esc_html__('Please select a form to display.', 'sigmaforms-pro') . '</p>' .
                   '</div>';
        }
        
        // Build shortcode
        $shortcode = '[sigmaforms id="' . esc_attr($form_id) . '"]';
        
        // Return rendered shortcode
        return do_shortcode($shortcode);
    }
    
    /**
     * Enqueue block editor assets
     */
    public function enqueue_block_editor_assets() {
        // Register block editor script
        wp_register_script(
            'sigmaforms-gutenberg-block',
            plugins_url('../../assets/js/gutenberg-block.js', __FILE__),
            ['wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n', 'wp-data'],
            SF_VERSION,
            true
        );
        
        // Get all forms for the dropdown
        $forms = $this->plugin->forms->get_forms();
        $forms_list = [];
        
        if (!empty($forms)) {
            foreach ($forms as $form) {
                $forms_list[] = [
                    'value' => (string) $form['id'],
                    'label' => $form['title'],
                ];
            }
        }
        
        // Localize script with forms data
        wp_localize_script('sigmaforms-gutenberg-block', 'sigmaformsGutenberg', [
            'forms' => $forms_list,
            'blockName' => $this->block_name,
            'i18n' => [
                'title' => __('SigmaForms', 'sigmaforms-pro'),
                'description' => __('Embed a SigmaForms form', 'sigmaforms-pro'),
                'selectForm' => __('Select Form', 'sigmaforms-pro'),
                'formPlaceholder' => __('Choose a form...', 'sigmaforms-pro'),
                'noFormSelected' => __('No form selected', 'sigmaforms-pro'),
                'formPreview' => __('Form Preview', 'sigmaforms-pro'),
                'selectFormMessage' => __('Please select a form from the block settings in the sidebar.', 'sigmaforms-pro'),
            ],
        ]);
        
        // Enqueue the script
        wp_enqueue_script('sigmaforms-gutenberg-block');
        // Enqueue the script
        wp_enqueue_script('sigmaforms-gutenberg-block');

        // Styles are the block's editor_style (see register_block()), so the
        // block editor loads them into its iframe as well.
    }
}
