<?php
/**
 * Elementor Widget
 * 
 * Provides an Elementor widget for embedding forms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Elementor Widget Class
 */
class ElementorWidget {
    
    /**
     * Plugin instance
     *
     * @var \SigmaForms\Plugin
     */
    private $plugin;
    
    /**
     * Constructor
     *
     * @param \SigmaForms\Plugin $plugin Plugin instance
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->init();
    }
    
    /**
     * Initialize Elementor widget
     */
    private function init() {
        // Register widget
        add_action('elementor/widgets/register', [$this, 'register_widget']);
        
        // Register widget category
        add_action('elementor/elements/categories_registered', [$this, 'register_category']);
        
        // Enqueue frontend styles in Elementor editor
        add_action('elementor/editor/after_enqueue_styles', [$this, 'enqueue_editor_styles']);
        
        // Enqueue frontend scripts in Elementor preview
        add_action('elementor/preview/enqueue_styles', [$this, 'enqueue_preview_styles']);
    }
    
    /**
     * Register widget category
     *
     * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager
     */
    public function register_category($elements_manager) {
        $elements_manager->add_category('sigmaforms', [
            'title' => __('SigmaForms', 'sigmaforms-pro'),
            'icon' => 'fa fa-plug',
        ]);
    }
    
    /**
     * Register Elementor widget
     *
     * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager
     */
    public function register_widget($widgets_manager) {
        require_once __DIR__ . '/ElementorFormWidget.php';
        
        // Pass plugin instance to widget
        $widget = new ElementorFormWidget([], null, $this->plugin);
        $widgets_manager->register($widget);
    }
    
    /**
     * Enqueue editor styles
     */
    public function enqueue_editor_styles() {
        // Enqueue frontend form styles
        wp_enqueue_style(
            'sf-frontend-styles-elementor',
            SF_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            SF_VERSION
        );
        
        // Enqueue all theme styles
        wp_enqueue_style(
            'sf-minimal-theme-elementor',
            SF_PLUGIN_URL . 'assets/css/themes/minimal.css',
            ['sf-frontend-styles-elementor'],
            SF_VERSION
        );
        
        wp_enqueue_style(
            'sf-modern-theme-elementor',
            SF_PLUGIN_URL . 'assets/css/themes/modern.css',
            ['sf-frontend-styles-elementor'],
            SF_VERSION
        );
        
        wp_enqueue_style(
            'sf-classic-theme-elementor',
            SF_PLUGIN_URL . 'assets/css/themes/classic.css',
            ['sf-frontend-styles-elementor'],
            SF_VERSION
        );

        wp_enqueue_style(
            'sf-transition-theme-elementor',
            SF_PLUGIN_URL . 'assets/css/themes/transition.css',
            ['sf-frontend-styles-elementor'],
            SF_VERSION
        );

        wp_enqueue_style(
            'sf-soft-theme-elementor',
            SF_PLUGIN_URL . 'assets/css/themes/soft.css',
            ['sf-frontend-styles-elementor'],
            SF_VERSION
        );
    }
    
    /**
     * Enqueue preview styles
     */
    public function enqueue_preview_styles() {
        // Same as editor styles
        $this->enqueue_editor_styles();
    }
}
