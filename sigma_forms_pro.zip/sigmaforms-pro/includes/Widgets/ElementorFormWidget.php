<?php
/**
 * Elementor Form Widget
 * 
 * The actual Elementor widget for forms
 *
 * @package SigmaForms
 */

namespace SigmaForms\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Elementor Form Widget Class
 */
class ElementorFormWidget extends Widget_Base {
    
    /**
     * Plugin instance
     *
     * @var \SigmaForms\Plugin
     */
    private $plugin;
    
    /**
     * Constructor
     *
     * @param array $data Widget data
     * @param array $args Widget arguments
     * @param \SigmaForms\Plugin $plugin Plugin instance
     */
    public function __construct($data = [], $args = null, $plugin = null) {
        parent::__construct($data, $args);
        
        if ($plugin) {
            $this->plugin = $plugin;
        } else {
            // Fallback to get plugin instance
            global $sigmaforms_plugin;
            $this->plugin = $sigmaforms_plugin;
        }
    }
    
    /**
     * Get widget name
     *
     * @return string
     */
    public function get_name() {
        return 'sigmaforms-form';
    }
    
    /**
     * Get widget title
     *
     * @return string
     */
    public function get_title() {
        return __('SigmaForms', 'sigmaforms-pro');
    }
    
    /**
     * Get widget icon
     *
     * @return string
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    
    /**
     * Get widget categories
     *
     * @return array
     */
    public function get_categories() {
        return ['sigmaforms', 'general'];
    }
    
    /**
     * Get widget keywords
     *
     * @return array
     */
    public function get_keywords() {
        return ['form', 'contact', 'sigmaforms', 'sigma'];
    }
    
    /**
     * Register widget controls
     */
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_form',
            [
                'label' => __('Form Settings', 'sigmaforms-pro'),
            ]
        );
        
        // Get all forms
        $forms = $this->get_forms_list();
        
        $this->add_control(
            'form_id',
            [
                'label' => __('Select Form', 'sigmaforms-pro'),
                'type' => Controls_Manager::SELECT,
                'options' => $forms,
                'default' => '',
                'description' => __('Choose which form to display', 'sigmaforms-pro'),
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Style', 'sigmaforms-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'form_alignment',
            [
                'label' => __('Alignment', 'sigmaforms-pro'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'sigmaforms-pro'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'sigmaforms-pro'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'sigmaforms-pro'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .sf-form-container' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'form_width',
            [
                'label' => __('Form Width', 'sigmaforms-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 200,
                        'max' => 1200,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-form-container' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'form_padding',
            [
                'label' => __('Padding', 'sigmaforms-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sf-form-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'form_margin',
            [
                'label' => __('Margin', 'sigmaforms-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sf-form-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    /**
     * Render widget output on the frontend
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $form_id = !empty($settings['form_id']) ? intval($settings['form_id']) : 0;
        
        if (empty($form_id)) {
            // Show placeholder in both editor and frontend
            ?>
            <div class="sf-block-placeholder" style="text-align: center; padding: 60px 30px; background: #f9f9f9; border: 2px dashed #ddd; border-radius: 4px;">
                <p style="margin: 0; color: #555; font-size: 16px;">
                    <?php esc_html_e('Please select a form to display.', 'sigmaforms-pro'); ?>
                </p>
            </div>
            <?php
            return;
        }
        
        // Build shortcode
        $shortcode = '[sigmaforms id="' . esc_attr($form_id) . '"]';
        
        // Render shortcode (works in both frontend and editor)
        echo do_shortcode($shortcode);
        
        // Add CSS to disable form submission in editor
        if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
            echo '<style>
                .elementor-element .sf-form button[type="submit"] {
                    pointer-events: none;
                    cursor: not-allowed;
                    opacity: 0.7;
                }
            </style>';
        }
    }
    
    /**
     * Get forms list for dropdown
     *
     * @return array
     */
    private function get_forms_list() {
        $forms_list = ['' => __('Select a form...', 'sigmaforms-pro')];
        
        if (!$this->plugin) {
            return $forms_list;
        }
        
        $forms = $this->plugin->forms->get_forms();
        
        if (!empty($forms)) {
            foreach ($forms as $form) {
                $forms_list[$form['id']] = $form['title'];
            }
        }
        
        return $forms_list;
    }
}
