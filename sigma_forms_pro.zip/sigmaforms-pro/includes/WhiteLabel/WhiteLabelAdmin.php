<?php
/**
 * White label admin hooks: recovery links, menu icon CSS, recovery email.
 *
 * @package SigmaForms
 */

namespace SigmaForms\WhiteLabel;

if (!defined('ABSPATH')) {
    exit;
}

class WhiteLabelAdmin {

    /**
     * @var bool
     */
    private static $recovery_session = false;

    /**
     * @var self|null
     */
    private static $instance = null;

    /**
     * @return self
     */
    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @return bool
     */
    public static function is_recovery_session() {
        return self::$recovery_session;
    }

    /**
     * @return bool
     */
    public static function should_hide_settings_menu() {
        return WhiteLabel::should_hide_settings_menu() && !self::$recovery_session;
    }

    /**
     * @return bool
     */
    public static function should_hide_white_label_menu() {
        return self::should_hide_settings_menu();
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'maybe_process_recovery_link'), 1);
        add_action('admin_init', array($this, 'maybe_redirect_hidden_submenus'));
        add_action('admin_head', array($this, 'inject_admin_styles'));
        add_action('admin_footer', array($this, 'print_admin_menu_title_sync'), 20);
        add_filter('admin_title', array($this, 'filter_admin_title'), 10, 2);
    }

    /**
     * @return void
     */
    public function maybe_process_recovery_link() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!isset($_GET['sigmaforms_wl']) || !isset($_GET['token'])) {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(
                esc_html__('You do not have sufficient permissions to access this page.', 'sigmaforms-pro'),
                esc_html__('Access denied', 'sigmaforms-pro'),
                array('response' => 403)
            );
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $wl_flag = sanitize_text_field(wp_unslash($_GET['sigmaforms_wl']));
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $token   = sanitize_text_field(wp_unslash($_GET['token']));

        if ($wl_flag !== '1') {
            $this->die_recovery_error(
                esc_html__('Invalid access parameter. Use the link from your recovery email.', 'sigmaforms-pro')
            );
        }

        if (!WhiteLabel::validate_access_token($token)) {
            $this->die_recovery_error(
                esc_html__('Invalid or outdated recovery link. Request a new one from the site owner or support.', 'sigmaforms-pro')
            );
        }

        self::$recovery_session = true;

        add_action(
            'admin_notices',
            static function () {
                echo '<div class="notice notice-success is-dismissible"><p><strong>';
                esc_html_e('Settings menu recovery access granted. You can open Settings and White Label again.', 'sigmaforms-pro');
                echo '</strong></p></div>';
            }
        );
    }

    /**
     * @param string $message Message.
     * @return void
     */
    private function die_recovery_error($message) {
        wp_die(
            '<h1>' . esc_html__('SigmaForms — recovery link', 'sigmaforms-pro') . '</h1>'
            . '<p><strong>' . esc_html__('Access denied:', 'sigmaforms-pro') . '</strong> ' . esc_html($message) . '</p>'
            . '<p><a class="button button-primary" href="' . esc_url(admin_url()) . '">' . esc_html__('Return to dashboard', 'sigmaforms-pro') . '</a></p>',
            esc_html__('Access denied', 'sigmaforms-pro'),
            array('response' => 403)
        );
    }

    /**
     * Redirect direct visits to hidden submenu pages.
     *
     * @return void
     */
    public function maybe_redirect_hidden_submenus() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['sigmaforms_wl'], $_GET['token'])) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        if ($page === 'sigmaforms_license' && WhiteLabel::should_hide_license_nav() && !self::$recovery_session) {
            wp_safe_redirect(admin_url('admin.php?page=sigmaforms'));
            exit;
        }

        if (
            in_array($page, array('sigmaforms-settings', 'sigmaforms-white-label'), true)
            && self::should_hide_settings_menu()
        ) {
            wp_safe_redirect(admin_url('admin.php?page=sigmaforms'));
            exit;
        }
    }

    /**
     * @param string $admin_title Full admin title.
     * @param string $title       Page segment.
     * @return string
     */
    public function filter_admin_title($admin_title, $title) {
        if (!get_option(WhiteLabel::OPTION_ENABLED, false)) {
            return $admin_title;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page === '' || strpos($page, 'sigmaforms') !== 0) {
            return $admin_title;
        }

        $default = __('SigmaForms', 'sigmaforms-pro');
        $brand   = WhiteLabel::get_display_name();

        if ($brand === $default) {
            return $admin_title;
        }

        return str_replace($default, $brand, $admin_title);
    }

    /**
     * Menu icon + hide-license CSS.
     *
     * @return void
     */
    public function inject_admin_styles() {
        if (WhiteLabel::should_hide_license_nav() && !self::$recovery_session) {
            echo '<style type="text/css" id="sf-wl-hide-license-submenu">
                #adminmenu a[href*="page=sigmaforms_license"],
                #adminmenu li.sf-admin-root-menu ul.wp-submenu li a[href*="page=sigmaforms_license"] {
                    display: none !important;
                }
            </style>';
        }

        if (self::should_hide_settings_menu()) {
            echo '<style type="text/css" id="sf-wl-hide-settings-submenu">
                #adminmenu a[href*="page=sigmaforms-settings"],
                #adminmenu a[href*="page=sigmaforms-white-label"],
                #adminmenu li.sf-admin-root-menu ul.wp-submenu li a[href*="page=sigmaforms-settings"],
                #adminmenu li.sf-admin-root-menu ul.wp-submenu li a[href*="page=sigmaforms-white-label"],
                #adminmenu li.sf-admin-root-menu ul.wp-submenu li.bdt-promo-menu-item,
                #toplevel_page_sigmaforms .wp-submenu li.bdt-promo-menu-item {
                    display: none !important;
                }
            </style>';
        }

        if (!get_option(WhiteLabel::OPTION_ENABLED, false)) {
            return;
        }

        $icon = get_option(WhiteLabel::OPTION_ICON, '');
        if (empty($icon)) {
            return;
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS output: the rule set is a static literal and the only dynamic part is the icon URL, escaped with esc_url() and stripped of CSS delimiters inside build_menu_icon_css().
        echo '<style type="text/css" id="sf-wl-admin-menu-icon-php">' . self::build_menu_icon_css($icon) . '</style>';
    }

    /**
     * @return void
     */
    public function print_admin_menu_title_sync() {
        if (!get_option(WhiteLabel::OPTION_ENABLED, false)) {
            return;
        }

        $boot = array(
            'enabled'      => true,
            'title'        => (string) get_option(WhiteLabel::OPTION_TITLE, ''),
            'icon'         => (string) get_option(WhiteLabel::OPTION_ICON, ''),
            'hide_admin'   => (bool) get_option(WhiteLabel::OPTION_HIDE_ADMIN, false),
            'hide_license' => (bool) get_option(WhiteLabel::OPTION_HIDE_LICENSE, false),
        );

        if ($boot['title'] === '' && $boot['icon'] === '' && !$boot['hide_admin'] && !$boot['hide_license']) {
            return;
        }

        $default  = __('SigmaForms', 'sigmaforms-pro');
        $icon_css = !empty($boot['icon']) ? self::build_menu_icon_css($boot['icon']) : '';
        ?>
        <?php if ($icon_css !== '') : ?>
        <style type="text/css" id="sf-wl-admin-menu-icon-footer"><?php echo $icon_css; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS output: static rule set plus an icon URL escaped with esc_url() and stripped of CSS delimiters in build_menu_icon_css(). ?></style>
        <?php endif; ?>
        <script id="sf-wl-admin-menu-sync">
        (function () {
            var boot = <?php echo wp_json_encode($boot); ?>;
            var base = <?php echo wp_json_encode($default); ?>;
            if (!boot || !boot.enabled) { return; }
            var title = (boot.title && String(boot.title).trim()) || base;
            var top = document.querySelector('#adminmenu a.toplevel_page_sigmaforms');
            var root = document.querySelector('#adminmenu li.sf-admin-root-menu') || (top ? top.closest('li') : null);
            if (root && !root.classList.contains('sf-admin-root-menu')) {
                root.classList.add('sf-admin-root-menu');
            }
            if (top) {
                var label = top.querySelector('.wp-menu-name');
                if (label) { label.textContent = title; }
                top.setAttribute('aria-label', title);
            }
            if (root) {
                root.querySelectorAll('.wp-submenu-head').forEach(function (head) {
                    head.textContent = title;
                });
            }
            if (boot.hide_license) {
                document.querySelectorAll('#adminmenu a[href*="page=sigmaforms_license"]').forEach(function (anchor) {
                    var li = anchor.closest('li');
                    if (li) { li.style.display = 'none'; }
                });
            }
            if (boot.hide_admin) {
                document.querySelectorAll('#adminmenu a[href*="page=sigmaforms-settings"], #adminmenu a[href*="page=sigmaforms-white-label"]').forEach(function (anchor) {
                    var li = anchor.closest('li');
                    if (li) { li.style.display = 'none'; }
                });
                document.querySelectorAll('#toplevel_page_sigmaforms .wp-submenu li.bdt-promo-menu-item').forEach(function (li) {
                    li.style.display = 'none';
                });
            }
            if (window.sfWhiteLabelData && window.sfWhiteLabelData.syncWhiteLabelMenu) {
                window.sfWhiteLabelData.syncWhiteLabelMenu(boot);
            }
        })();
        </script>
        <?php
    }

    /**
     * @param string $url Icon URL.
     * @return string
     */
    public static function build_menu_icon_css($url) {
        // esc_url() leaves parentheses and quotes intact — both are legal URL characters —
        // so an icon URL containing ")" would close url(...) early and let the remainder of
        // the string land in the stylesheet as raw CSS declarations. Strip those characters
        // and quote the value so it can only ever be read as a single URL token.
        $safe = str_replace(array('(', ')', '"', "'", ' ', "\t", "\r", "\n"), '', esc_url($url));

        if ($safe === '') {
            return '';
        }

        return '
            #adminmenu li.sf-admin-root-menu .wp-menu-image,
            #adminmenu .sf-admin-root-menu .wp-menu-image {
                position: relative !important;
                background-image: url(\'' . $safe . '\') !important;
                background-size: 20px 20px !important;
                background-repeat: no-repeat !important;
                background-position: center center !important;
            }
            #adminmenu li.sf-admin-root-menu.current .wp-menu-image,
            #adminmenu li.sf-admin-root-menu.wp-has-current-submenu .wp-menu-image {
                background-image: url(\'' . $safe . '\') !important;
            }
            #adminmenu .sf-admin-root-menu .wp-menu-image::before,
            #adminmenu .sf-admin-root-menu .wp-menu-image::after {
                display: none !important;
                content: none !important;
            }
            #adminmenu .sf-admin-root-menu .wp-menu-image img {
                opacity: 0 !important;
                visibility: hidden !important;
                width: 0 !important;
                height: 0 !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        ';
    }

    /**
     * @return bool
     */
    public static function send_recovery_email() {
        $license_email = WhiteLabel::get_license_email_for_recovery();
        $admin_email   = get_bloginfo('admin_email');
        $license_key   = WhiteLabel::get_bound_license_key();
        $site_name     = get_bloginfo('name');
        $site_url      = get_bloginfo('url');

        if ($license_key === '') {
            return false;
        }

        $access_token = wp_hash($license_key . time() . wp_salt() . wp_generate_password(32, false));

        update_option(
            WhiteLabel::OPTION_ACCESS_TOKEN,
            array(
                'token'       => $access_token,
                'license_key' => $license_key,
                'created_at'  => current_time('timestamp'),
                'user_id'     => get_current_user_id(),
            )
        );

        $access_url = admin_url(
            'admin.php?page=sigmaforms-white-label&sigmaforms_wl=1&token=' . rawurlencode($access_token)
        );

        $subject = sprintf(
            /* translators: %s: site name */
            __('[%s] SigmaForms — settings menu recovery link', 'sigmaforms-pro'),
            $site_name
        );

        $message = self::build_email_html($site_name, $site_url, $access_url, $license_key);
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $site_name . ' <' . $admin_email . '>',
        );

        $sent = false;
        if (!empty($license_email) && is_email($license_email)) {
            $sent = (bool) wp_mail($license_email, $subject, $message, $headers);
        }

        if (!$sent || self::is_localhost()) {
            update_option(
                WhiteLabel::OPTION_LOCALHOST_EMAIL,
                array(
                    'access_url'      => $access_url,
                    'email_content'   => $message,
                    'recipient_email' => $license_email,
                    'message'         => __('Mail may not work on localhost. Save this recovery URL:', 'sigmaforms-pro'),
                )
            );
        }

        return $sent;
    }

    /**
     * @return bool
     */
    private static function is_localhost() {
        $server_name = isset($_SERVER['SERVER_NAME']) ? sanitize_text_field(wp_unslash($_SERVER['SERVER_NAME'])) : '';
        $server_addr = isset($_SERVER['SERVER_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['SERVER_ADDR'])) : '';

        foreach (array('localhost', '127.0.0.1', '::1', '.local', '.test', '.dev') as $needle) {
            if ($needle !== '' && (strpos($server_name, $needle) !== false || strpos($server_addr, $needle) !== false)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param string $site_name  Site name.
     * @param string $site_url   Site URL.
     * @param string $access_url Recovery URL.
     * @param string $license_key License key.
     * @return string
     */
    private static function build_email_html($site_name, $site_url, $access_url, $license_key) {
        $masked = strlen($license_key) > 13
            ? substr($license_key, 0, 8) . '****-****-****-' . substr($license_key, -4)
            : '****';

        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family:Arial,sans-serif;line-height:1.6;color:#333;">
            <div style="max-width:600px;margin:0 auto;padding:20px;">
                <h2 style="color:#007bff;"><?php esc_html_e('SigmaForms — Settings menu recovery', 'sigmaforms-pro'); ?></h2>
                <p><?php esc_html_e('The Settings and White Label menus were hidden from wp-admin. Keep this email — it contains your private recovery link.', 'sigmaforms-pro'); ?></p>
                <p><strong><?php esc_html_e('Site:', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($site_name); ?> — <?php echo esc_html($site_url); ?></p>
                <p><strong><?php esc_html_e('License (masked):', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($masked); ?></p>
                <p style="text-align:center;margin:28px 0;">
                    <a href="<?php echo esc_url($access_url); ?>" style="background:#007bff;color:#fff;padding:14px 22px;text-decoration:none;border-radius:4px;display:inline-block;">
                        <?php esc_html_e('Open settings & white label', 'sigmaforms-pro'); ?>
                    </a>
                </p>
                <p style="word-break:break-all;font-size:13px;">
                    <strong><?php esc_html_e('Direct link:', 'sigmaforms-pro'); ?></strong><br>
                    <a href="<?php echo esc_url($access_url); ?>"><?php echo esc_html($access_url); ?></a>
                </p>
            </div>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }
}
