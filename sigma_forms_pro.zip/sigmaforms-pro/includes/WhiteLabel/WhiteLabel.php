<?php
/**
 * White label eligibility and helpers (tier-gated; mirrors SMM / One Accessibility).
 *
 * @package SigmaForms
 */

namespace SigmaForms\WhiteLabel;

use SigmaForms\License\Base as License_Base;
use SigmaForms\License\Forms as License_Forms;
use SigmaForms\Plugin;

if (!defined('ABSPATH')) {
    exit;
}

class WhiteLabel {

    public const OPTION_ENABLED = 'sf_white_label_enabled';

    public const OPTION_LICENSE_TITLE_STATUS = 'sf_white_label_license_title_status';

    public const OPTION_ACCESS_TOKEN = 'sf_white_label_access_token';

    public const OPTION_LOCALHOST_EMAIL = 'sf_white_label_localhost_email_data';

    public const OPTION_HIDE_LICENSE = 'sf_white_label_hide_license';

    public const OPTION_HIDE_ADMIN = 'sf_white_label_hide_admin';

    public const OPTION_TITLE = 'sf_white_label_title';

    public const OPTION_ICON = 'sf_white_label_icon';

    public const OPTION_ICON_ID = 'sf_white_label_icon_id';

    public const OPTION_LOGO = 'sf_white_label_logo';

    public const OPTION_LOGO_ID = 'sf_white_label_logo_id';

    /**
     * @return array<string, mixed>
     */
    public static function get_localized_script_data() {
        return array(
            'whiteLabelEligible'      => self::is_white_label_license(),
            'hideLicenseNav'          => self::should_hide_license_nav(),
            'hideSettingsMenu'        => self::should_hide_settings_menu(),
            'hideWhiteLabelMenu'      => self::should_hide_settings_menu(),
            'whiteLabelRecovery'      => class_exists(WhiteLabelAdmin::class)
                && WhiteLabelAdmin::is_recovery_session(),
            'brandDisplayName'        => self::get_display_name(),
            'defaultBrandDisplayName' => __('SigmaForms', 'sigmaforms-pro'),
            'defaultBrandLogoUrl'     => self::get_default_admin_logo_url(),
            'brandLogoUrl'            => self::get_admin_logo_url(),
            'whiteLabelBoot'          => array(
                'enabled'      => (bool) get_option(self::OPTION_ENABLED, false),
                'hide_license' => (bool) get_option(self::OPTION_HIDE_LICENSE, false),
                'hide_admin'   => (bool) get_option(self::OPTION_HIDE_ADMIN, false),
                'title'        => (string) get_option(self::OPTION_TITLE, ''),
                'icon'         => (string) get_option(self::OPTION_ICON, ''),
                'logo'         => (string) get_option(self::OPTION_LOGO, ''),
            ),
        );
    }

    /**
     * @return string
     */
    public static function get_display_name() {
        if (defined('SIGMAFORMS_WHITE_LABEL_BRAND') && SIGMAFORMS_WHITE_LABEL_BRAND !== '') {
            return SIGMAFORMS_WHITE_LABEL_BRAND;
        }

        if (get_option(self::OPTION_ENABLED, false)) {
            $saved = trim((string) get_option(self::OPTION_TITLE, ''));
            if ($saved !== '') {
                return $saved;
            }
        }

        return __('SigmaForms', 'sigmaforms-pro');
    }

    /**
     * Default admin header logo (SigmaForms branding).
     *
     * @return string
     */
    public static function get_default_admin_logo_url() {
        return SF_PLUGIN_URL . 'assets/images/logo.png';
    }

    /**
     * Logo shown in admin page headers (white-label override when enabled).
     *
     * @return string
     */
    public static function get_admin_logo_url() {
        if (get_option(self::OPTION_ENABLED, false)) {
            $custom = trim((string) get_option(self::OPTION_LOGO, ''));
            if ($custom !== '') {
                return $custom;
            }
        }

        return self::get_default_admin_logo_url();
    }

    /**
     * Render logo + title for admin headers.
     *
     * @param array<string, mixed> $args {
     *     @type string $title          Visible title text.
     *     @type string $title_template Optional data-sf-brand-title template with %s.
     *     @type string $heading_tag    h1, h2, or h3.
     *     @type string $heading_class  Extra classes on the heading element.
     *     @type bool   $show_logo      Whether to output the logo image.
     *     @type string $logo_url       Logo URL override.
     *     @type string $after_title    Optional HTML after the title (must be escaped).
     * }
     * @return void
     */
    public static function render_admin_brand($args = array()) {
        $defaults = array(
            'title'          => self::get_display_name(),
            'title_template' => '',
            'heading_tag'    => 'h1',
            'heading_class'  => '',
            'show_logo'      => true,
            'logo_url'       => self::get_admin_logo_url(),
            'after_title'    => '',
        );
        $args = wp_parse_args($args, $defaults);

        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template scope.
        $title          = (string) $args['title'];
        $title_template = (string) $args['title_template'];
        $heading_tag    = (string) $args['heading_tag'];
        $heading_class  = (string) $args['heading_class'];
        $show_logo      = (bool) $args['show_logo'];
        $logo_url       = (string) $args['logo_url'];
        $after_title    = (string) $args['after_title'];
        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

        include SF_PLUGIN_DIR . 'admin/views/partials/admin-brand.php';
    }

    /**
     * Whether Settings and White Label submenus should be hidden in wp-admin.
     *
     * @return bool
     */
    public static function should_hide_settings_menu() {
        if (!get_option(self::OPTION_ENABLED, false)) {
            return false;
        }

        return (bool) get_option(self::OPTION_HIDE_ADMIN, false);
    }

    /**
     * @return bool
     */
    public static function should_hide_white_label_menu() {
        return self::should_hide_settings_menu();
    }

    /**
     * @return bool
     */
    public static function should_hide_license_nav() {
        if (!get_option(self::OPTION_ENABLED, false)) {
            return false;
        }

        return (bool) get_option(self::OPTION_HIDE_LICENSE, false);
    }

    /**
     * @return bool
     */
    public static function license_wl_status() {
        return (bool) get_option(self::OPTION_LICENSE_TITLE_STATUS, false);
    }

    /**
     * @return array<string, string>
     */
    public static function get_white_label_allowed_license_types() {
        return array(
            'agency'    => 'c4b2af4722ee54e317672875b2d8cf49aa884bf5820ec6091114fea5ec6560e4',
            'extended'  => '4d7120eb6c796b04273577476eb2e20c34c51d7fa1025ec19c3414448abc241e',
            'developer' => '88fa0d759f845b47c044c2cd44e29082cf6fea665c30c146374ec7c8f3d699e3',
        );
    }

    /**
     * @return bool
     */
    public static function is_white_label_license() {
        if (!Plugin::is_license_valid()) {
            return false;
        }

        $response_obj = License_Base::get_register_info();

        if (
            empty($response_obj)
            || !is_object($response_obj)
            || empty($response_obj->license_title)
            || empty($response_obj->is_valid)
        ) {
            return false;
        }

        if (property_exists($response_obj, 'other_param') && !empty($response_obj->other_param)) {
            if (is_array($response_obj->other_param) && in_array('WL', $response_obj->other_param, true)) {
                return true;
            }
            if (is_string($response_obj->other_param) && strpos($response_obj->other_param, 'WL') !== false) {
                return true;
            }
        }

        $license_title  = sanitize_text_field(strtolower($response_obj->license_title));
        $allowed_hashes = array_values(self::get_white_label_allowed_license_types());
        $words          = preg_split('/\s+/', $license_title, -1, PREG_SPLIT_NO_EMPTY);

        if (!is_array($words)) {
            return false;
        }

        foreach ($words as $word) {
            $word = trim($word);
            if ($word === '' || strlen($word) > 50) {
                continue;
            }
            if (in_array(hash('sha256', $word), $allowed_hashes, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param string $token Raw token.
     * @return bool
     */
    public static function validate_access_token($token) {
        $stored = get_option(self::OPTION_ACCESS_TOKEN, array());
        if (empty($stored) || !is_array($stored) || empty($stored['token'])) {
            return false;
        }
        // Constant-time comparison for a secret token.
        if (!is_string($token) || !hash_equals((string) $stored['token'], $token)) {
            return false;
        }

        $current_key = self::get_bound_license_key();
        if (empty($stored['license_key']) || $stored['license_key'] !== $current_key) {
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    public static function revoke_access_token() {
        $data = get_option(self::OPTION_ACCESS_TOKEN, array());
        if (!empty($data)) {
            delete_option(self::OPTION_ACCESS_TOKEN);
            return true;
        }
        return false;
    }

    /**
     * @return string
     */
    public static function get_bound_license_key() {
        $main_lic_key = 'SigmaForms_lic_Key';
        if (class_exists(License_Forms::class)) {
            $lic_key_name = License_Forms::get_lic_key_param($main_lic_key);
            return trim((string) get_option($lic_key_name, ''));
        }
        return trim((string) get_option($main_lic_key, ''));
    }

    /**
     * @return string
     */
    public static function get_license_email_for_recovery() {
        return trim((string) get_option('SigmaForms_lic_email', ''));
    }

    /**
     * Default gray admin menu icon (#a7aaad data URI).
     *
     * @return string
     */
    public static function get_default_menu_icon_url() {
        $path = 'M24.0557 37.04C24.4857 40.37 25.3357 43.4902 26.5557 46.1602H21.5557C22.7757 43.4902 23.6257 40.37 24.0557 37.04ZM31.3262 2C32.0661 2.00014 32.7257 2.46026 32.9756 3.16016L46.0459 43.8096L46.0362 43.7803C46.4459 44.9202 45.5957 46.1299 44.3858 46.1299H31.9659C31.9459 46.0799 31.9255 46.0402 31.8955 45.9902C30.0356 42.8902 28.8257 38.45 28.5957 33.79C28.5157 32.02 28.5561 30.2698 28.7461 28.5898C31.026 28.2898 33.1961 27.7602 35.1661 27.0303C36.4159 26.5703 37.0457 25.1903 36.586 23.9404C36.126 22.6906 34.746 22.0598 33.4961 22.5195C30.6961 23.5595 27.3658 24.1104 23.8858 24.1104C20.4058 24.1103 17.156 23.5696 14.376 22.5596C13.1261 22.1096 11.7462 22.7501 11.2862 24C10.8362 25.2499 11.4758 26.6297 12.7256 27.0898C14.7556 27.8298 17.016 28.3504 19.376 28.6504C19.556 30.3201 19.6056 32.0499 19.5157 33.8096C19.2857 38.4695 18.0758 42.9098 16.2159 46.0098L16.1455 46.1504H3.7559C2.55594 46.1504 1.70583 44.97 2.09574 43.8301L14.5362 3.19043C14.7762 2.48043 15.4463 2 16.1963 2H31.3262ZM27.7559 18.3301C27.5559 16.3001 25.7458 14.8196 23.7159 15.0195C21.686 15.2195 20.2065 17.0297 20.4063 19.0596C20.6063 21.0896 22.4163 22.5701 24.4463 22.3701C26.4761 22.1699 27.9558 20.3599 27.7559 18.3301Z';
        $svg  = '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="#a7aaad">'
            . '<path d="' . $path . '" fill="#a7aaad"/></svg>';

        return esc_url('data:image/svg+xml;base64,' . base64_encode($svg), array('data'));
    }

    /**
     * @param string $fill SVG fill color.
     * @return string
     */
    public static function build_menu_icon_data_uri($fill) {
        $path = 'M24.0557 37.04C24.4857 40.37 25.3357 43.4902 26.5557 46.1602H21.5557C22.7757 43.4902 23.6257 40.37 24.0557 37.04ZM31.3262 2C32.0661 2.00014 32.7257 2.46026 32.9756 3.16016L46.0459 43.8096L46.0362 43.7803C46.4459 44.9202 45.5957 46.1299 44.3858 46.1299H31.9659C31.9459 46.0799 31.9255 46.0402 31.8955 45.9902C30.0356 42.8902 28.8257 38.45 28.5957 33.79C28.5157 32.02 28.5561 30.2698 28.7461 28.5898C31.026 28.2898 33.1961 27.7602 35.1661 27.0303C36.4159 26.5703 37.0457 25.1903 36.586 23.9404C36.126 22.6906 34.746 22.0598 33.4961 22.5195C30.6961 23.5595 27.3658 24.1104 23.8858 24.1104C20.4058 24.1103 17.156 23.5696 14.376 22.5596C13.1261 22.1096 11.7462 22.7501 11.2862 24C10.8362 25.2499 11.4758 26.6297 12.7256 27.0898C14.7556 27.8298 17.016 28.3504 19.376 28.6504C19.556 30.3201 19.6056 32.0499 19.5157 33.8096C19.2857 38.4695 18.0758 42.9098 16.2159 46.0098L16.1455 46.1504H3.7559C2.55594 46.1504 1.70583 44.97 2.09574 43.8301L14.5362 3.19043C14.7762 2.48043 15.4463 2 16.1963 2H31.3262ZM27.7559 18.3301C27.5559 16.3001 25.7458 14.8196 23.7159 15.0195C21.686 15.2195 20.2065 17.0297 20.4063 19.0596C20.6063 21.0896 22.4163 22.5701 24.4463 22.3701C26.4761 22.1699 27.9558 20.3599 27.7559 18.3301Z';
        $svg  = '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="' . esc_attr($fill) . '">'
            . '<path d="' . $path . '" fill="' . esc_attr($fill) . '"/></svg>';

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }
}
