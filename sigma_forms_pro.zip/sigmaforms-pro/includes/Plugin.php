<?php

/**
 * Main Plugin class for SigmaForms
 *
 * @package SigmaForms
 */

namespace SigmaForms;

use SigmaForms\License\Base as License_Base;
use SigmaForms\Rest\WhiteLabelController;
use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\WhiteLabel\WhiteLabelAdmin;

class Plugin {
    /**
     * Plugin instance
     *
     * @var Plugin
     */
    private static $instance = null;

    /**
     * Admin module instance
     *
     * @var Admin\Admin
     */
    public $admin;

    /**
     * Forms module instance
     *
     * @var Forms\FormsManager
     */
    public $forms;

    /**
     * Abandoned Forms module instance
     *
     * @var Forms\AbandonedFormsManager
     */
    public $abandoned_forms;

    /**
     * AI module instance
     *
     * @var AI\AIGenerator
     */
    public $ai;

    /**
     * Frontend module instance
     *
     * @var Frontend\Frontend
     */
    public $frontend;

    /**
     * Blocks module instance
     *
     * @var Blocks\FormBlock
     */
    public $blocks;

    /**
     * License module instance
     *
     * @var License\Forms
     */
    public $license;

    /**
     * Widgets module instance
     *
     * @var Widgets\WidgetManager
     */
    public $widgets;

    /**
     * Init plugin functionality
     *
     * @return void
     */
    public function init() {
        // Load text domain for translations
        $this->load_textdomain();

        // Initialize components
        $this->init_components();

        // Register hooks
        $this->register_hooks();
        $this->initilize_license_system();
    }

    /**
     * Load plugin text domain for translations
     * 
     * Note: As of WordPress 4.6+, this is automatically handled by WordPress.org
     * for plugins hosted there. Keeping this for backwards compatibility and
     * for installations not using WordPress.org language packs.
     *
     * @return void
     */
    private function load_textdomain() {
        // phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Needed for backwards compatibility
        load_plugin_textdomain(
            'sigmaforms-pro',
            false,
            dirname(plugin_basename(SF_PLUGIN_DIR . 'sigmaforms-pro.php')) . '/languages'
        );
    }

    /**
     * Initialize license system
     *
     * @return void
     */
    private function initilize_license_system() {
        add_action('admin_init', array($this, 'handle_activation_redirect'));
    }


    /**
     * Handle redirect to license page after activation
     */
    public function handle_activation_redirect() {
        // Check if we should redirect to license page
        if (get_option('sigmaforms_activation_redirect', false)) {
            delete_option('sigmaforms_activation_redirect');

            // Only redirect if not already on the license page and user can manage options
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Activation redirect, not user-submitted form
            if (!class_exists('Config_Playground') && current_user_can('manage_options') && (!isset($_GET['page']) || $_GET['page'] !== 'launchguard')) {
                wp_safe_redirect(admin_url('admin.php?page=sigmaforms_license'));
                exit;
            } else {
                wp_safe_redirect(admin_url('admin.php?page=sigmaforms-new'));
                exit;
            }
        }
    }
    /**
     * Admin notices for license activation required
     */
    public function admin_notices() {
        $current_screen = get_current_screen();
        
        // Don't show on license page itself
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checking current admin page, not processing form data
        if ($current_screen && isset($_GET['page']) && $_GET['page'] === 'sigmaforms_license') {
            return;
        }

        // Check if we're on the plugins page
        $is_plugins_page = ($current_screen && $current_screen->id === 'plugins');
        
        // Show license activation notice if flag is set (on non-plugins pages)
        if (get_option('sigmaforms_show_license_notice', false) && !self::is_license_valid() && !$is_plugins_page) {
            // Check if notice was dismissed
            $dismissed_until = get_option('sigmaforms_license_notice_dismissed', 0);
            if ($dismissed_until > time()) {
                return;
            }

            $license_url = admin_url('admin.php?page=sigmaforms_license');
            echo '<div class="notice sigmaforms-license-notice is-dismissible">';
            echo '<div class="sf-notice">';
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map.
            echo '<span class="sf-notice__icon">' . Admin\PageHeader::icon('key') . '</span>';
            echo '<div class="sf-notice__body">';
            echo '<p class="sf-notice__title">' . esc_html__('SigmaForms License Required', 'sigmaforms-pro') . '</p>';
            echo '<p class="sf-notice__text">' . esc_html__('Please activate your license to unlock all SigmaForms features and receive updates.', 'sigmaforms-pro') . '</p>';
            echo '<a class="sf-notice__action" href="' . esc_url($license_url) . '">' . esc_html__('Activate License', 'sigmaforms-pro') . '</a>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    }

    /**
     * Check if license is valid
     *
     * @return bool
     */
    public static function is_license_valid(): bool {
        $is_valid = false;

        // Try to use License\Base if available
        if (class_exists(License_Base::class)) {
            $license_info = License_Base::get_register_info();
            if (!empty($license_info) && !empty($license_info->is_valid)) {
                $is_valid = true;
            }
        }

        // Fallback: check if license key exists and is not empty
        if (!$is_valid) {
            $license_key = get_option('SigmaForms_lic_Key', '');
            if (!empty($license_key) && strlen($license_key) > 10) {
                $is_valid = true;
            }
        }

        return $is_valid;
    }

    /**
     * Check if user can use plugin features
     *
     * @return bool
     */
    public static function can_use_features(): bool {
        // Administrators can always access settings to configure license
        if (current_user_can('manage_options')) {
            return true;
        }

        // For non-admin users, license is required
        $license_valid = self::is_license_valid();
        return (bool) $license_valid;
    }
    /**
     * Initialize components
     *
     * @return void
     */
    private function init_components() {

        // Initialize forms module
        $this->forms = new Forms\FormsManager();

        // Initialize abandoned forms module
        $this->abandoned_forms = new Forms\AbandonedFormsManager();
        $this->abandoned_forms->init();

        // Initialize AI module
        // $this->ai = new AI\AIGenerator();
        $this->ai = new AI\SigmaAI();

        // Initialize Admin module
        $this->admin = new Admin\Admin($this);

        // Initialize Frontend module
        $this->frontend = new Frontend\Frontend($this);

        // Initialize blocks
        $this->blocks = new Blocks\FormBlock();
        $this->license = new License\Forms();
        
        // Initialize widgets
        $this->widgets = new Widgets\WidgetManager($this);
        
        // Initialize Mobile Signature Handler
        Utils\MobileSignatureHandler::init();

        WhiteLabelAdmin::init();
        new WhiteLabelController();
    }

    /**
     * Register hooks
     *
     * @return void
     */
    private function register_hooks() {
        // Register assets
        add_action('wp_enqueue_scripts', [$this, 'register_frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'register_admin_assets'], 5);

        // Register shortcode
        add_shortcode('sigmaforms', [$this->frontend, 'render_form_shortcode']);

        // Register REST API
        add_action('rest_api_init', [$this, 'register_rest_routes']);

        // Run schema migrations once after an update. Updating (or replacing the
        // files) does not fire the activation hook, so without this the new
        // indexes waited for the next daily maintenance run.
        add_action('admin_init', [$this, 'maybe_run_upgrade_migrations']);

        // Register maintenance tasks
        add_action('sf_daily_maintenance', [$this, 'daily_maintenance']);

        // Schedule maintenance if not already scheduled
        if (!wp_next_scheduled('sf_daily_maintenance')) {
            wp_schedule_event(time(), 'daily', 'sf_daily_maintenance');
        }

        // Add plugin action links
        add_filter('plugin_action_links_' . SF_PLUGIN_BASENAME, [$this, 'add_plugin_action_links']);
        
        // Mobile signature template redirect - priority 5 to run early
        add_action('template_redirect', [Utils\MobileSignatureHandler::class, 'render_mobile_signature_page'], 5);
        
        // Disable auto-updates for unlicensed plugin
        add_filter('auto_update_plugin', [$this, 'disable_auto_update'], 10, 2);
        add_filter('plugin_auto_update_setting_html', [$this, 'auto_update_message'], 10, 3);
        
        // Admin notices for license and updates
        add_action('admin_notices', [$this, 'admin_notices']);
    }

    /**
     * Register frontend assets
     *
     * @return void
     */
    public function register_frontend_assets() {
        // Register and enqueue CSS
        wp_register_style(
            'sf-frontend-styles',
            SF_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            SF_VERSION
        );

        // Register QR Code library
        wp_register_script(
            'sf-qrcode',
            SF_PLUGIN_URL . 'assets/js/qrcode.min.js',
            [],
            SF_VERSION,
            true
        );

        // Register mobile signature script
        wp_register_script(
            'sf-mobile-signature',
            SF_PLUGIN_URL . 'assets/js/mobile-signature.js',
            ['jquery', 'sf-qrcode'],
            SF_VERSION,
            true
        );

        // Register JS
        wp_register_script(
            'sf-frontend-script',
            SF_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery'],
            SF_VERSION,
            true
        );

        // Register multi-step form script
        wp_register_script(
            'sf-multistep',
            SF_PLUGIN_URL . 'assets/js/multistep.js',
            ['jquery'],
            SF_VERSION,
            true
        );

        // Register auto-save script
        wp_register_script(
            'sf-auto-save',
            SF_PLUGIN_URL . 'assets/js/auto-save.js',
            ['jquery', 'sf-frontend-script'],
            SF_VERSION,
            true
        );

        // Localize script
        wp_localize_script('sf-frontend-script', 'sfData', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sf-frontend-nonce'),
            // For "User Data" conditional rules; user meta values are added per
            // form, only for the keys its rules use (see Frontend).
            'user_data' => [
                'logged_in' => is_user_logged_in(),
                'role' => is_user_logged_in() && !empty(wp_get_current_user()->roles) ? (string) reset(wp_get_current_user()->roles) : '',
                'meta' => new \stdClass(),
            ],
            'strings' => [
                'submitting' => __('Submitting...', 'sigmaforms-pro'),
                'success' => __('Thank you for your submission!', 'sigmaforms-pro'),
                'error' => __('An error occurred. Please try again.', 'sigmaforms-pro'),
                /* translators: %d: maximum number of files allowed */
                'maxFilesError' => __('You can upload a maximum of %d files.', 'sigmaforms-pro'),
                /* translators: %s: file extension, e.g. ".exe" */
                'fileTypeError' => __('File type "%s" is not allowed.', 'sigmaforms-pro'),
                /* translators: %d: upload progress percentage. Keep "%d%" as is. */
                'uploading' => __('Uploading... %d%', 'sigmaforms-pro'),
                'uploaded' => __('Uploaded successfully', 'sigmaforms-pro'),
                'validation_failed' => __('Please fill in all required fields.', 'sigmaforms-pro'),
            ],
        ]);
        
        // Localize mobile signature script
        wp_localize_script('sf-mobile-signature', 'sfParams', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sf-mobile-signature-nonce'),
        ]);
    }

    /**
     * Register admin assets
     *
     * @param string $hook Current admin page hook
     * @return void
     */
    public function register_admin_assets($hook) {
        // The field settings popup picks label/option images from the media library
        if (is_string($hook) && strpos($hook, 'sigmaforms') !== false) {
            wp_enqueue_media();
            // Required by wp.media.view.Cropper for the label/option image crop tool
            wp_enqueue_script('imgareaselect');
            wp_enqueue_style('imgareaselect');
        }

        // Register modular CSS files in dependency order
        wp_register_style(
            'sf-base-styles',
            SF_PLUGIN_URL . 'assets/css/base.css',
            [],
            SF_VERSION
        );

        wp_register_style(
            'sf-form-editor-styles',
            SF_PLUGIN_URL . 'assets/css/form-editor.css',
            ['sf-base-styles'],
            SF_VERSION
        );

        wp_register_style(
            'sf-modals-styles',
            SF_PLUGIN_URL . 'assets/css/modals.css',
            ['sf-base-styles'],
            SF_VERSION
        );

        wp_register_style(
            'sf-dashboard-styles',
            SF_PLUGIN_URL . 'assets/css/dashboard.css',
            ['sf-base-styles'],
            SF_VERSION
        );

        wp_register_style(
            'sf-navigation-styles',
            SF_PLUGIN_URL . 'assets/css/navigation.css',
            ['sf-base-styles'],
            SF_VERSION
        );

        wp_register_style(
            'sf-settings-styles',
            SF_PLUGIN_URL . 'assets/css/settings.css',
            ['sf-base-styles'],
            SF_VERSION
        );

        wp_register_style(
            'sf-conditional-logic-styles',
            SF_PLUGIN_URL . 'assets/css/conditional-logic.css',
            ['sf-base-styles'],
            SF_VERSION
        );

        wp_register_style(
            'sf-responsive-styles',
            SF_PLUGIN_URL . 'assets/css/responsive.css',
            ['sf-base-styles', 'sf-form-editor-styles', 'sf-settings-styles', 'sf-navigation-styles'],
            SF_VERSION
        );

        // Register main admin styles bundle that includes all modules
        wp_register_style(
            'sf-admin-styles',
            SF_PLUGIN_URL . 'assets/css/admin.css',
            [
                'sf-base-styles',
                'sf-form-editor-styles',
                'sf-modals-styles',
                'sf-dashboard-styles',
                'sf-navigation-styles',
                'sf-settings-styles',
                'sf-conditional-logic-styles',
                'sf-responsive-styles'
            ],
            SF_VERSION
        );

        // Register wizard styles
        wp_register_style(
            'sf-wizard-styles',
            SF_PLUGIN_URL . 'assets/css/wizard.css',
            ['sf-admin-styles'],
            SF_VERSION
        );

        // Register modular JS files in dependency order
        wp_register_script(
            'sf-utils',
            SF_PLUGIN_URL . 'assets/js/modules/utils.js',
            ['jquery'],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-ai-generator',
            SF_PLUGIN_URL . 'assets/js/modules/ai-generator.js',
            ['jquery', 'sf-utils'],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-conditional-logic',
            SF_PLUGIN_URL . 'assets/js/modules/conditional-logic.js',
            ['jquery', 'sf-utils'],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-visual-editor',
            SF_PLUGIN_URL . 'assets/js/modules/visual-editor.js',
            ['jquery', 'jquery-ui-sortable', 'sf-utils'],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-submissions',
            SF_PLUGIN_URL . 'assets/js/modules/submissions.js',
            ['jquery'],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-settings',
            SF_PLUGIN_URL . 'assets/js/modules/settings.js',
            ['jquery'],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-white-label-data',
            SF_PLUGIN_URL . 'assets/js/sf-white-label-data.js',
            [],
            SF_VERSION,
            true
        );

        wp_register_script(
            'sf-white-label',
            SF_PLUGIN_URL . 'assets/js/modules/white-label.js',
            ['jquery', 'wp-api-fetch', 'sf-white-label-data'],
            SF_VERSION,
            true
        );

        wp_register_style(
            'sf-white-label-styles',
            SF_PLUGIN_URL . 'assets/css/white-label.css',
            ['sf-admin-styles'],
            SF_VERSION
        );

        // Register main admin script that coordinates all modules
        wp_register_script(
            'sf-admin-script',
            SF_PLUGIN_URL . 'assets/js/admin.js',
            // React (wp-element), wp-components, wp-api-fetch and jquery-ui-draggable
            // were listed here but nothing in this bundle uses them; they added
            // around 1 MB of script to every SigmaForms screen. white-label.js
            // and visual-editor.js declare the dependencies they do use.
            ['jquery', 'sf-utils', 'sf-ai-generator', 'sf-visual-editor', 'sf-conditional-logic', 'sf-submissions', 'sf-settings', 'sf-white-label-data'],
            SF_VERSION,
            true
        );

        // Register wizard JS
        wp_register_script(
            'sf-wizard-script',
            SF_PLUGIN_URL . 'assets/js/wizard.js',
            ['jquery', 'sf-admin-script'],
            SF_VERSION,
            true
        );

        $sf_admin_data = array_merge(
            [
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('sf-admin-nonce'),
                'restBase' => esc_url_raw(rest_url('sigmaforms/v1')),
                'strings' => [
                    'generating' => __('Generating form...', 'sigmaforms-pro'),
                    'success' => __('Form generated successfully!', 'sigmaforms-pro'),
                    'error' => __('An error occurred. Please try again.', 'sigmaforms-pro'),
                    'saving' => __('Saving...', 'sigmaforms-pro'),
                    'sessionExpired' => __('Your session has expired, so this action could not be completed. Reload the page and try again.', 'sigmaforms-pro'),
                    'reload' => __('Reload', 'sigmaforms-pro'),
                    'cancel' => __('Cancel', 'sigmaforms-pro'),
                    'confirm' => __('Confirm', 'sigmaforms-pro'),
                    'delete' => __('Delete', 'sigmaforms-pro'),
                    'confirmTitle' => __('Are you sure?', 'sigmaforms-pro'),
                    'dismiss' => __('Dismiss', 'sigmaforms-pro'),
                    'enterFormName' => __('Please enter a form name.', 'sigmaforms-pro'),
                    'addOneField' => __('Please add at least one field to your form.', 'sigmaforms-pro'),
                    'selectSubmission' => __('Please select at least one submission.', 'sigmaforms-pro'),
                    'confirmDeleteSubmissions' => __('Are you sure you want to delete the selected submissions?', 'sigmaforms-pro'),
                    'confirmDeleteSubmission' => __('Are you sure you want to delete this submission?', 'sigmaforms-pro'),
                    'errorDeletingSubmissions' => __('Error deleting submissions.', 'sigmaforms-pro'),
                    'errorUpdatingSubmissions' => __('Error updating submissions.', 'sigmaforms-pro'),
                    'aiFieldUnknown' => __('Unable to determine field information for AI suggestions. Please ensure you have opened field settings first.', 'sigmaforms-pro'),
                    'aiNoFieldSettings' => __('Could not find field settings to apply suggestion.', 'sigmaforms-pro'),
                    'aiNoConditionGroups' => __('Could not find the condition groups to apply this suggestion.', 'sigmaforms-pro'),
                    'confirmDisconnectGoogleDrive' => __('Are you sure you want to disconnect Google Drive? This will remove access to your Google Drive account.', 'sigmaforms-pro'),
                    'confirmDisconnectOneDrive' => __('Are you sure you want to disconnect OneDrive? This will remove access to your OneDrive account.', 'sigmaforms-pro'),
                    'disconnect' => __('Disconnect', 'sigmaforms-pro'),
                    'confirmRevokeToken' => __('Revoke the active recovery token?', 'sigmaforms-pro'),
                    'revoke' => __('Revoke', 'sigmaforms-pro'),
                    'confirmHideMenus' => __('Hide the Settings and White Label menus from wp-admin? A recovery link will be emailed so you can open them again.', 'sigmaforms-pro'),
                    'hideMenus' => __('Hide menus', 'sigmaforms-pro'),
                    'fieldNeedsLicense' => __('This field requires an active SigmaForms Pro license.', 'sigmaforms-pro'),
                    'proFieldLocked' => __('This is a Pro field and is locked until you activate your license.', 'sigmaforms-pro'),
                    'mediaUnavailable' => __('The WordPress media library is not available on this screen.', 'sigmaforms-pro'),
                    'mediaFailed' => __('The media window could not be opened. Please reload the page and try again.', 'sigmaforms-pro'),
                    'cropperUnavailable' => __('The WordPress image cropper is not available on this screen.', 'sigmaforms-pro'),
                    'cropScriptMissing' => __('The image cropping script (imgAreaSelect) did not load. Please reload the page and try again.', 'sigmaforms-pro'),
                    'cropFailed' => __('The image could not be cropped. Please try a different selection.', 'sigmaforms-pro'),
                    'confirmDeleteField' => __('Are you sure you want to delete this field?', 'sigmaforms-pro'),
                ],
            ],
            WhiteLabel::get_localized_script_data()
        );

        // Localize script for general admin functions
        wp_localize_script('sf-admin-script', 'sfAdmin', $sf_admin_data);
        wp_localize_script('sf-white-label-data', 'sfAdmin', $sf_admin_data);

        if (current_user_can('manage_options')) {
            wp_enqueue_script('sf-white-label-data');
            wp_add_inline_script(
                'sf-white-label-data',
                'window.sfWhiteLabelData&&window.sfWhiteLabelData.bootWhiteLabelChrome();',
                'after'
            );
        }

        // Localize script for conditional logic variables
        wp_localize_script('sf-admin-script', 'sf_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sf_admin_nonce'),
            // Text strings for operators and messages
            'text_equals' => __('equals', 'sigmaforms-pro'),
            'text_not_equals' => __('does not equal', 'sigmaforms-pro'),
            'text_contains' => __('contains', 'sigmaforms-pro'),
            'text_starts_with' => __('starts with', 'sigmaforms-pro'),
            'text_ends_with' => __('ends with', 'sigmaforms-pro'),
            'text_greater_than' => __('is greater than', 'sigmaforms-pro'),
            'text_less_than' => __('is less than', 'sigmaforms-pro'),
            'text_greater_equal' => __('is greater than or equal to', 'sigmaforms-pro'),
            'text_less_equal' => __('is less than or equal to', 'sigmaforms-pro'),
            'text_is_checked' => __('is checked', 'sigmaforms-pro'),
            // AI suggestion text strings
            'text_ai_suggest_conditions' => __('AI: Suggest Smart Conditions', 'sigmaforms-pro'),
            'text_apply_suggestion' => __('Apply', 'sigmaforms-pro'),
            'text_generating_suggestions' => __('Generating suggestions...', 'sigmaforms-pro'),
            'text_no_suggestions' => __('No suggestions available for this field type.', 'sigmaforms-pro'),
            'text_suggestion_error' => __('Could not get AI suggestions at this time.', 'sigmaforms-pro'),
            'text_select_field' => __('Select a field', 'sigmaforms-pro'),
            'text_user_logged_in' => __('User is logged in', 'sigmaforms-pro'),
            'text_user_role' => __('User role', 'sigmaforms-pro'),
            'text_user_meta' => __('User meta field', 'sigmaforms-pro'),
            'text_meta_key' => __('Meta key', 'sigmaforms-pro'),
            'text_current_date' => __('Current date', 'sigmaforms-pro'),
            'text_current_time' => __('Current time', 'sigmaforms-pro'),
            'text_current_day' => __('Current day of week', 'sigmaforms-pro'),
            'text_is_not_checked' => __('is not checked', 'sigmaforms-pro'),
            'text_is_empty' => __('is empty', 'sigmaforms-pro'),
            'text_is_not_empty' => __('is not empty', 'sigmaforms-pro'),
            'text_before_date' => __('is before date', 'sigmaforms-pro'),
            'text_after_date' => __('is after date', 'sigmaforms-pro'),
            'text_is_date' => __('is same date', 'sigmaforms-pro'),
            'text_or' => __('OR', 'sigmaforms-pro'),
            'text_and' => __('AND', 'sigmaforms-pro'),
            'text_add_condition' => __('Add condition', 'sigmaforms-pro'),
            'text_remove_condition' => __('Remove condition', 'sigmaforms-pro'),
            'text_loading' => __('Loading...', 'sigmaforms-pro'),
            'text_ai_suggest' => __('AI: Suggest Smart Conditions', 'sigmaforms-pro'),
            'text_ai_error' => __('Could not get AI suggestions at this time.', 'sigmaforms-pro'),
            'text_apply' => __('Apply', 'sigmaforms-pro'),
            'text_form_field' => __('Form Field', 'sigmaforms-pro'),
            'text_user_data' => __('User Data', 'sigmaforms-pro'),
            'text_date_time' => __('Date/Time', 'sigmaforms-pro'),
            'text_value' => __('Value', 'sigmaforms-pro'),
            // WordPress user roles for conditional logic dropdown
            'user_roles' => $this->get_wordpress_user_roles(),
            // User data for frontend conditional logic
            'user_data' => [
                'logged_in' => is_user_logged_in(),
                'role' => is_user_logged_in() ? wp_get_current_user()->roles[0] : '',
                // Add more user data as needed
            ]
        ]);
    }

    /**
     * Register REST API routes
     *
     * @return void
     */
    public function register_rest_routes() {
        // Register forms endpoints
        $this->forms->register_rest_routes();

        // Register abandoned forms endpoints
        $this->abandoned_forms->register_rest_routes();

        // Register AI endpoints
        $this->ai->register_rest_routes();
    }

    /**
     * Run the idempotent schema migrations when the installed version changes.
     *
     * One option read per admin request; the migrations themselves only run
     * once per version.
     *
     * @return void
     */
    public function maybe_run_upgrade_migrations() {
        if (get_option('sf_migrated_version') === SF_VERSION) {
            return;
        }

        Activation::maybe_add_analytics_indexes();
        Activation::maybe_add_submission_indexes();

        update_option('sf_migrated_version', SF_VERSION, true);
    }

    /**
     * Daily maintenance tasks
     *
     * @return void
     */
    public function daily_maintenance() {
        // Make sure the analytics tables are indexed before deleting from them.
        // Installs that updated rather than reactivated never ran the migration.
        Activation::maybe_add_analytics_indexes();
        Activation::maybe_add_submission_indexes();

        // Clean up old submissions using the saved setting
        $cleanup_days = get_option('sf_cleanup_days', 90);
        $this->forms->cleanup_old_submissions($cleanup_days);

        // Trim the view log, which gains a row on every single form render
        $views_retention_days = get_option('sf_views_retention_days', 60);
        Utils\Analytics::cleanup_old_views($views_retention_days);
    }

    /**
     * Add plugin action links
     *
     * @param array $links Existing plugin action links
     * @return array Modified plugin action links
     */
    public function add_plugin_action_links($links) {
        $plugin_links = [
            '<a href="' . esc_url(admin_url('admin.php?page=sigmaforms-settings')) . '">' . __('Settings', 'sigmaforms-pro') . '</a>',
        ];

        return array_merge($plugin_links, $links);
    }
    /**
     * Get total number of published forms
     *
     * @return int
     */
    public static function get_forms_count(): int {
        global $wpdb;

        $table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is prefixed, status is hardcoded
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'publish'");
        return $count;
    }

    /**
     * Get IDs of forms allowed under free limit (top 5 most recently modified)
     * Only used when license is invalid.
     *
     * @return array<int>
     */
    public static function get_allowed_form_ids(): array {
        if (self::is_license_valid()) {
            // When license is valid, all forms are allowed
            return [];
        }

        global $wpdb;
        $table = $wpdb->prefix . 'sigmaforms';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is prefixed, status is hardcoded
        $results = $wpdb->get_col("SELECT id FROM {$table} WHERE status = 'publish' ORDER BY date_modified DESC LIMIT 5");
        if (!is_array($results)) {
            return [];
        }
        return array_map('intval', $results);
    }

    /**
     * Check if a specific form is allowed to be used (rendered) under current license state
     *
     * @param int $form_id
     * @return bool
     */
    public static function is_form_allowed(int $form_id): bool {
        if (self::is_license_valid()) {
            return true;
        }
        $allowed = self::get_allowed_form_ids();
        // If there are no forms yet, allowed array might be empty but usage should be false unless count < 5 and the form is among allowed.
        return in_array((int) $form_id, $allowed, true);
    }

    /**
     * Determine if the user can create more forms under current license state
     *
     * @return bool
     */
    public static function can_create_more_forms(): bool {
        if (self::is_license_valid()) {
            return true;
        }
        return self::get_forms_count() < 5;
    }
    /**
     * Get WordPress user roles
     *
     * @return array WordPress user roles
     */
    private function get_wordpress_user_roles() {
        $roles = [];
        $wp_roles = wp_roles();

        foreach ($wp_roles->roles as $role => $details) {
            $roles[] = $role;
        }

        return $roles;
    }
    
    /**
     * Disable auto-update if license is not valid
     *
     * @param bool $update Whether to update
     * @param object $item Plugin update item
     * @return bool
     */
    public function disable_auto_update($update, $item) {
        // Check if this is our plugin
        if (isset($item->plugin) && SF_PLUGIN_BASENAME === $item->plugin) {
            // Disable auto-update if license is not valid
            if (!self::is_license_valid()) {
                return false;
            }
        }
        return $update;
    }
    
    /**
     * Show custom message for auto-update setting
     *
     * @param string $html Current HTML
     * @param string $plugin_file Plugin file
     * @param array $plugin_data Plugin data
     * @return string Modified HTML
     */
    public function auto_update_message($html, $plugin_file, $plugin_data) {
        // Check if this is our plugin
        if (SF_PLUGIN_BASENAME === $plugin_file) {
            if (!self::is_license_valid()) {
                $license_url = admin_url('admin.php?page=sigmaforms_license');
                $html = '<em>' . __('Automatic update is unavailable for this plugin.', 'sigmaforms-pro') . '</em> ';
                $html .= '<a href="' . esc_url($license_url) . '">' . __('Activate License', 'sigmaforms-pro') . '</a>';
                return $html;
            }
        }
        return $html;
    }
    
    /**
     * Check if plugin update is available
     *
     * @return bool
     */
    private function check_if_update_available() {
        // Get update transients
        $update_plugins = get_site_transient('update_plugins');
        
        if (!empty($update_plugins) && !empty($update_plugins->response)) {
            // Check if our plugin has an update
            if (isset($update_plugins->response[SF_PLUGIN_BASENAME])) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get update information
     *
     * @return object|null
     */
    private function get_update_info() {
        $update_plugins = get_site_transient('update_plugins');
        
        if (!empty($update_plugins) && !empty($update_plugins->response)) {
            if (isset($update_plugins->response[SF_PLUGIN_BASENAME])) {
                return $update_plugins->response[SF_PLUGIN_BASENAME];
            }
        }
        
        return null;
    }
}
