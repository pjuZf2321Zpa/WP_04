/**
 * SigmaForms - Auto Save Module
 * Handles saving form values to localStorage and restoring them on page load
 */
(function($) {
    'use strict';

    // Only run on frontend
    if ($('body').hasClass('wp-admin')) {
        return;
    }

    const AutoSave = {
        /**
         * Initialize auto-save functionality
         */
        init: function() {
            this.bindEvents();
            this.restoreSavedValues();
        },

        /**
         * Bind necessary events
         */
        bindEvents: function() {
            const self = this;

            // Save values on input/change
            $(document).on('input change', '.sf-form input, .sf-form textarea, .sf-form select', function() {
                const $form = $(this).closest('.sf-form');
                const formId = self.getFormId($form);
                if (formId) {
                    self.saveFormValues($form, formId);
                }
            });

            // Handle TinyMCE changes
            if (typeof tinymce !== 'undefined') {
                tinymce.on('AddEditor', function(e) {
                    e.editor.on('Change KeyUp', function() {
                        e.editor.save(); // Update the textarea
                        const $textarea = $(e.editor.getElement());
                        const $form = $textarea.closest('.sf-form');
                        const formId = self.getFormId($form);
                        if (formId) {
                            self.saveFormValues($form, formId);
                        }
                    });
                });
                
                // Bind to existing editors
                setTimeout(function() {
                    tinymce.editors.forEach(function(editor) {
                        editor.on('Change KeyUp', function() {
                            editor.save(); // Update the textarea
                            const $textarea = $(editor.getElement());
                            const $form = $textarea.closest('.sf-form');
                            const formId = self.getFormId($form);
                            if (formId) {
                                self.saveFormValues($form, formId);
                            }
                        });
                    });
                }, 1000);
            }

            // Handle form submission
            $(document).on('submit', '.sf-form', function(e) {
                const $form = $(this);
                const formId = self.getFormId($form);
                
                // Store the form ID for later use
                $form.data('form-id', formId);

                // Store original button text
                const $submitButton = $form.find('.sf-submit-button');
                if (!$submitButton.data('original-text')) {
                    $submitButton.data('original-text', $submitButton.html());
                }
            });

            // Listen for successful form submission event (triggered by frontend.js)
            $(document).on('sf:form_submitted', '.sf-form', function(e, responseData) {
                const $form = $(this);
                const formId = self.getFormId($form);
                
                if (formId) {
                    // Clear saved values on successful submission
                    self.clearSavedValues(formId);
                }
            });

            // Listen for AJAX success
            $(document).ajaxSuccess(function(event, xhr, settings) {
                // Check if this is our form submission by looking at the URL
                if (settings.url && settings.url.indexOf('admin-ajax.php') !== -1) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        // Find the form that was submitted
                        const $form = $('.sf-form').filter(function() {
                            return $(this).data('form-id');
                        });
                        
                        if ($form.length) {
                            const formId = $form.data('form-id');
                            
                            // Always clear localStorage for this form
                            if (response.success) {
                               self.clearSavedValues(formId);
                            }
                            
                            // Reset submit button
                            const $submitButton = $form.find('.sf-submit-button');
                            if ($submitButton.length) {
                                $submitButton.prop('disabled', false)
                                    .html($submitButton.data('original-text') || 'Submit');
                            }
                        }
                    } catch (e) {
                    }
                }
            });

            // Listen for AJAX error
            $(document).ajaxError(function(event, xhr, settings) {
                // Check if this is our form submission by looking at the URL
                if (settings.url && settings.url.indexOf('admin-ajax.php') !== -1) {
                    // Find the form that was submitted
                    const $form = $('.sf-form').filter(function() {
                        return $(this).data('form-id');
                    });
                    
                    if ($form.length) {
                        // Reset submit button
                        const $submitButton = $form.find('.sf-submit-button');
                        if ($submitButton.length) {
                            $submitButton.prop('disabled', false)
                                .html($submitButton.data('original-text') || 'Submit');
                        }
                    }
                }
            });
        },

        /**
         * Get form ID from form element
         */
        getFormId: function($form) {
            const formId = $form.attr('id');
            if (formId && formId.startsWith('sf-form-')) {
                return parseInt(formId.replace('sf-form-', ''), 10);
            }
            return null;
        },

        /**
         * Save form values to localStorage
         */
        saveFormValues: function($form, formId) {
            // Update TinyMCE instances if present
            if (typeof tinymce !== 'undefined') {
                tinymce.triggerSave();
            }

            const formData = {};
            
            // Get all form field values
            $form.find('input, textarea, select').each(function() {
                const $field = $(this);
                const name = $field.attr('name');
                const type = $field.attr('type');
                
                // Skip file inputs and password fields for security
                if (type === 'file' || type === 'password') {
                    return;
                }
                
                if (name) {
                    if ($field.is(':checkbox')) {
                        // Handle checkbox groups (name ends with [])
                        if (name.endsWith('[]')) {
                            // Only process once per group
                            if (!formData.hasOwnProperty(name)) {
                                // Get all checked values for this group
                                const checkedValues = [];
                                $form.find('input[name="' + name + '"]:checked').each(function() {
                                    checkedValues.push($(this).val());
                                });
                                formData[name] = checkedValues;
                            }
                        } else {
                            // Single checkbox
                            formData[name] = $field.is(':checked') ? ($field.val() || '1') : '';
                        }
                    } else if ($field.is(':radio')) {
                        if ($field.is(':checked')) {
                            formData[name] = $field.val();
                        }
                    } else {
                        formData[name] = $field.val();
                    }
                }
            });

            // Save to localStorage with error handling
            try {
                localStorage.setItem('sigma_form_' + formId, JSON.stringify(formData));
            } catch (e) {
                // Handle localStorage errors (quota exceeded, disabled, etc.)
                if (e.name === 'QuotaExceededError') {
                    // Clear old form data if storage is full
                    this.clearOldFormData();
                    try {
                        localStorage.setItem('sigma_form_' + formId, JSON.stringify(formData));
                    } catch (e2) {
                        // If still failing, just skip saving
                    }
                }
            }
        },

        /**
         * Restore saved form values
         */
        restoreSavedValues: function() {
            const self = this;
            
            $('.sf-form').each(function() {
                const $form = $(this);
                const formId = self.getFormId($form);
                
                if (formId) {
                    const savedData = localStorage.getItem('sigma_form_' + formId);
                    
                    if (savedData) {
                        try {
                            const formData = JSON.parse(savedData);
                            
                            // Restore each field value
                            Object.keys(formData).forEach(function(name) {
                                const $field = $form.find('[name="' + name + '"]');
                                if ($field.length) {
                                    if ($field.is(':checkbox')) {
                                        if (name.endsWith('[]') && Array.isArray(formData[name])) {
                                            // Multiple checkboxes
                                            $field.each(function() {
                                                $(this).prop('checked', formData[name].includes($(this).val()));
                                            });
                                        } else {
                                            // Single checkbox
                                            $field.prop('checked', formData[name] === '1' || formData[name] === true || formData[name] === $field.val());
                                        }
                                    } else if ($field.is(':radio')) {
                                        $field.filter('[value="' + formData[name] + '"]').prop('checked', true);
                                    } else {
                                        $field.val(formData[name]);
                                        // For range inputs, trigger input event to update the display value
                                        if ($field.attr('type') === 'range') {
                                            $field.trigger('input');
                                        }
                                        
                                        // Update TinyMCE if exists for this field
                                        if (typeof tinymce !== 'undefined') {
                                            // ID usually has replaced hyphens with underscores
                                            const editorId = $field.attr('id').replace(/-/g, '_');
                                            const editor = tinymce.get(editorId);
                                            if (editor) {
                                                editor.setContent(formData[name]);
                                            }
                                        }
                                    }
                                }
                            });
                        } catch (e) {
                        }
                    }
                }
            });
        },

        /**
         * Clear saved form values
         */
        clearSavedValues: function(formId) {
            try {
                localStorage.removeItem('sigma_form_' + formId);
            } catch (e) {
                // Handle errors silently
            }
        },

        /**
         * Clear old form data to make space
         */
        clearOldFormData: function() {
            try {
                // Remove all stored form data to make space
                for (let i = 0; i < localStorage.length; i++) {
                    const key = localStorage.key(i);
                    if (key && key.startsWith('sigma_form_')) {
                        localStorage.removeItem(key);
                        i--; // Adjust index since we removed an item
                    }
                }
            } catch (e) {
                // Handle errors silently
            }
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        AutoSave.init();
    });

})(jQuery); 