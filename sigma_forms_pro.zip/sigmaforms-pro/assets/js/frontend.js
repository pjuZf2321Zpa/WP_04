/**
 * SigmaForms - Frontend Scripts
 */
(function($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function() {
        initializeForms();
    });

    /**
     * Initialize all forms on the page
     */
    function initializeForms() {
        // Find all forms with our class
        $('.sf-form').each(function() {
            initForm($(this));
        });
    }

    /**
     * Initialize form functionality
     * 
     * @param {jQuery} $form Form element
     */
    function initForm($form) {
        const formId = $form.find('input[name="form_id"]').val();
        
        // Initialize conditional logic
        initConditionalFields($form);
        
        // Initialize math functions
        initMathFunctions($form);
        
        // Initialize file uploads
        initFileUploads($form);
        
        // Initialize signature pads
        initSignaturePads($form);
        
        // Initialize rating fields
        initRatingFields($form);
        
        // Initialize international phone fields with auto country detection
        initInternationalPhoneFields($form);
        
        // Initialize country fields with auto country detection
        initCountryFields($form);

        // Mark fields that hold a value (floating labels in the Soft theme)
        initFilledState($form);
        
        // Handle form submission
        $form.on('submit', function(e) {
            e.preventDefault();
            submitForm($form);
        });
    }
    
    /**
     * Keep an "sf-filled" class on each text-like field container that holds
     * a value. CSS cannot tell an empty field from a filled one without a
     * placeholder, and the Soft theme's floating labels need to know.
     *
     * @param {jQuery} $form Form element
     */
    function initFilledState($form) {
        const selector = '.sf-field-container input[type="text"], .sf-field-container input[type="email"], .sf-field-container input[type="number"], .sf-field-container input[type="tel"], .sf-field-container input[type="url"], .sf-field-container textarea';
        const update = function(field) {
            $(field).closest('.sf-field-container').toggleClass('sf-filled', String(field.value || '') !== '');
        };

        $form.find(selector).each(function() { update(this); });
        $form.on('input change blur', selector, function() { update(this); });

        // Browser autofill and form.reset() do not fire input events.
        $form.on('reset', function() {
            setTimeout(function() { $form.find(selector).each(function() { update(this); }); }, 0);
        });
        setTimeout(function() { $form.find(selector).each(function() { update(this); }); }, 600);
    }

    /**
     * Initialize file upload functionality
     * 
     * @param {jQuery} $form Form element
     */
    function initFileUploads($form) {
        $form.find('input[type="file"]').each(function() {
            const $fileInput = $(this);
            const $wrapper = $fileInput.closest('.sf-file-upload');
            
            // Create upload status container if it doesn't exist
            if ($wrapper.find('.sf-file-status').length === 0) {
                $wrapper.append('<div class="sf-file-status"></div>');
            }

            // Show max files hint in the upload icon area when a limit is set
            const maxFilesHint = parseInt($fileInput.data('max-files'), 10) || 0;
            if (maxFilesHint && $wrapper.find('.sf-max-files-hint').length === 0) {
                const hintText = (sfData.strings.maxFilesError || 'You can upload a maximum of %d files.').replace('%d', maxFilesHint);
                $wrapper.find('.sf-file-upload-icon').append('<p class="sf-max-files-hint">' + hintText + '</p>');
            }
            
            $fileInput.on('change', function() {
                handleFileSelection($fileInput, $wrapper);
            });
        });
    }
    
    /**
     * Initialize signature pad functionality
     * 
     * @param {jQuery} $form Form element
     */
    function initSignaturePads($form) {
        $form.find('.sf-signature-pad').each(function() {
            const canvas = this;
            const $canvas = $(canvas);
            const $hiddenInput = $canvas.siblings('.sf-signature-data');
            const ctx = canvas.getContext('2d');
            let isDrawing = false;
            let lastX = 0;
            let lastY = 0;
            
            // Set canvas size to match CSS dimensions
            canvas.width = $canvas.width();
            canvas.height = $canvas.height();
            
            // Set drawing style
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 2;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            
            // Mouse events
            $canvas.on('mousedown', function(e) {
                isDrawing = true;
                const rect = canvas.getBoundingClientRect();
                lastX = e.clientX - rect.left;
                lastY = e.clientY - rect.top;
            });
            
            $canvas.on('mousemove', function(e) {
                if (!isDrawing) return;
                
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                ctx.beginPath();
                ctx.moveTo(lastX, lastY);
                ctx.lineTo(x, y);
                ctx.stroke();
                
                lastX = x;
                lastY = y;
                
                // Update hidden input with canvas data
                $hiddenInput.val(canvas.toDataURL());
            });
            
            $canvas.on('mouseup mouseleave', function() {
                isDrawing = false;
            });
            
            // Touch events for mobile
            $canvas.on('touchstart', function(e) {
                e.preventDefault();
                isDrawing = true;
                const rect = canvas.getBoundingClientRect();
                const touch = e.originalEvent.touches[0];
                lastX = touch.clientX - rect.left;
                lastY = touch.clientY - rect.top;
            });
            
            $canvas.on('touchmove', function(e) {
                if (!isDrawing) return;
                e.preventDefault();
                
                const rect = canvas.getBoundingClientRect();
                const touch = e.originalEvent.touches[0];
                const x = touch.clientX - rect.left;
                const y = touch.clientY - rect.top;
                
                ctx.beginPath();
                ctx.moveTo(lastX, lastY);
                ctx.lineTo(x, y);
                ctx.stroke();
                
                lastX = x;
                lastY = y;
                
                // Update hidden input with canvas data
                $hiddenInput.val(canvas.toDataURL());
            });
            
            $canvas.on('touchend', function(e) {
                e.preventDefault();
                isDrawing = false;
            });
            
            // Clear button handler
            $canvas.siblings('.sf-signature-actions').find('.sf-clear-signature').on('click', function() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                $hiddenInput.val('');
            });
        });
    }
    
    /**
     * Initialize rating field functionality
     * 
     * @param {jQuery} $form Form element
     */
    function initRatingFields($form) {
        $form.find('.sf-rating-stars').each(function() {
            const $starsContainer = $(this);
            const $stars = $starsContainer.find('.sf-rating-star');
            const $hiddenInput = $starsContainer.siblings('.sf-rating-value');
            
            // Click handler to set rating
            $stars.on('click', function() {
                const rating = $(this).data('value');
                $hiddenInput.val(rating);
                $starsContainer.attr('data-rating', rating);
                updateStars($stars, rating);
            });
            
            // Hover effect
            $stars.on('mouseenter', function() {
                const hoverValue = $(this).data('value');
                $stars.each(function(index) {
                    if (index < hoverValue) {
                        $(this).addClass('sf-star-hover');
                    } else {
                        $(this).removeClass('sf-star-hover');
                    }
                });
            });
            
            // Remove hover effect
            $starsContainer.on('mouseleave', function() {
                $stars.removeClass('sf-star-hover');
            });
            
            // Initialize stars based on current rating
            const currentRating = parseInt($starsContainer.attr('data-rating')) || 0;
            if (currentRating > 0) {
                updateStars($stars, currentRating);
            }
        });
    }
    
    /**
     * Initialize international phone fields with auto country detection
     * 
     * @param {jQuery} $form Form element
     */
    function initInternationalPhoneFields($form) {
        const $phoneSelects = $form.find('.sf-country-code-select');
        
        if ($phoneSelects.length === 0) {
            return;
        }
        
        // Auto-detect user's country and preselect it
        detectUserCountry(function(countryCode) {
            if (countryCode) {
                $phoneSelects.each(function() {
                    const $select = $(this);
                    
                    // Check if the detected country is available in the dropdown options
                    const $option = $select.find('option[value="' + countryCode + '"]');
                    
                    if ($option.length > 0) {
                        // Only update if user hasn't already selected a different country
                        if (!$select.data('user-selected')) {
                            $select.val(countryCode);
                        }
                    }
                });
            }
        });
        
        // Mark as user-selected when user manually changes the country
        $phoneSelects.on('change', function() {
            $(this).data('user-selected', true);
        });
    }
    
    /**
     * Initialize country fields with auto country detection
     * 
     * @param {jQuery} $form Form element
     */
    function initCountryFields($form) {
        // Find country select fields by their parent container class
        const $countrySelects = $form.find('.sf-field-country select');
        
        if ($countrySelects.length === 0) {
            return;
        }
        
        // Auto-detect user's country and preselect it
        detectUserCountry(function(countryCode) {
            if (countryCode) {
                $countrySelects.each(function() {
                    const $select = $(this);
                    
                    // Check if the detected country is available in the dropdown options
                    const $option = $select.find('option[value="' + countryCode + '"]');
                    
                    if ($option.length > 0) {
                        // Only update if user hasn't already selected a different country
                        // and if no default value is already selected
                        if (!$select.data('user-selected') && !$select.val()) {
                            $select.val(countryCode);
                        }
                    }
                });
            }
        });
        
        // Mark as user-selected when user manually changes the country
        $countrySelects.on('change', function() {
            $(this).data('user-selected', true);
        });
    }
    
    /**
     * Detect user's country based on IP address
     * Uses IP geolocation API with sessionStorage caching
     * 
     * @param {Function} callback Callback function to receive country code
     */
    function detectUserCountry(callback) {
        // Check if country is already cached in sessionStorage
        const cachedCountry = getCachedCountry();
        
        if (cachedCountry) {
            callback(cachedCountry);
            return;
        }
        
        // Use ipapi.co free API for geolocation (no API key required for basic usage)
        // Alternative: https://ipapi.co/json/ or https://api.country.is/
        fetch('https://ipapi.co/json/')
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(function(data) {
                if (data && data.country_code) {
                    const countryCode = data.country_code.toUpperCase();
                    
                    // Cache the country code for current session
                    cacheCountry(countryCode);
                    
                    callback(countryCode);
                }
            })
            .catch(function(error) {
                // If the primary API fails, try fallback API
                fetch('https://api.country.is/')
                    .then(function(response) {
                        if (!response.ok) {
                            throw new Error('Fallback API failed');
                        }
                        return response.json();
                    })
                    .then(function(data) {
                        if (data && data.country) {
                            const countryCode = data.country.toUpperCase();
                            
                            // Cache the country code for current session
                            cacheCountry(countryCode);
                            
                            callback(countryCode);
                        }
                    })
                    .catch(function(fallbackError) {
                        // If both APIs fail, silently fail and use default country
                        // The form will use the default country set by the admin
                    });
            });
    }
    
    /**
     * Get cached country from sessionStorage
     * 
     * @return {string|null} Cached country code or null
     */
    function getCachedCountry() {
        if (!window.sessionStorage) {
            return null;
        }
        
        try {
            const cached = sessionStorage.getItem('sf_user_country');
            
            if (cached) {
                return cached;
            }
        } catch (e) {
            // Handle errors silently
        }
        
        return null;
    }
    
    /**
     * Cache country code in sessionStorage
     * 
     * @param {string} countryCode Country code to cache
     */
    function cacheCountry(countryCode) {
        if (!window.sessionStorage) {
            return;
        }
        
        try {
            sessionStorage.setItem('sf_user_country', countryCode);
        } catch (e) {
            // Handle errors silently
        }
    }
    
    /**
     * Update star display based on rating
     * 
     * @param {jQuery} $stars Star elements
     * @param {number} rating Rating value
     */
    function updateStars($stars, rating) {
        $stars.each(function(index) {
            if (index < rating) {
                $(this).addClass('sf-star-filled');
            } else {
                $(this).removeClass('sf-star-filled');
            }
        });
    }
    
    /**
     * Handle file selection
     * 
     * @param {jQuery} $fileInput File input element
     * @param {jQuery} $wrapper File upload wrapper
     */
    function handleFileSelection($fileInput, $wrapper) {
        let newFiles = Array.from($fileInput[0].files);
        const maxFiles = parseInt($fileInput.data('max-files'), 10) || 0;
        const $status = $wrapper.find('.sf-file-status');

        // Reject types the server would refuse now, not after submitting.
        // "accept" only filters the picker; "All files" and drag-and-drop skip it.
        $wrapper.siblings('.sf-file-error').remove();
        const allowed = String($fileInput.attr('data-allowed-ext') || '').split(',').filter(Boolean);
        if (allowed.length && newFiles.length) {
            const rejected = newFiles.filter(function(f) {
                const dot = f.name.lastIndexOf('.');
                return dot < 1 || allowed.indexOf(f.name.slice(dot + 1).toLowerCase()) === -1;
            });
            if (rejected.length) {
                const name = rejected[0].name;
                const ext = name.lastIndexOf('.') > 0 ? name.slice(name.lastIndexOf('.')) : name;
                const message = $fileInput.attr('data-type-error')
                    || (sfData.strings.fileTypeError || 'File type "%s" is not allowed.').replace('%s', ext);
                $('<div class="sf-file-error" role="alert"></div>').text(message).insertAfter($wrapper);
                newFiles = newFiles.filter(function(f) { return rejected.indexOf(f) === -1; });
                if (!newFiles.length) {
                    // Keep whatever was selected before; drop the rejected pick.
                    const keep = new DataTransfer();
                    ($wrapper.data('sf-files') || []).forEach(function(f) { keep.items.add(f); });
                    $fileInput[0].files = keep.files;
                    return;
                }
            }
        }

        if (newFiles.length === 0) return;

        // Accumulate files across selections when a max limit is set
        const prevFiles = $wrapper.data('sf-files') || [];
        let allFiles;
        if (maxFiles) {
            const slotsLeft = maxFiles - prevFiles.length;
            allFiles = prevFiles.concat(newFiles.slice(0, slotsLeft));
        } else {
            allFiles = newFiles;
        }
        $wrapper.data('sf-files', allFiles);

        // Sync the actual input FileList with all accumulated files
        const dtSync = new DataTransfer();
        allFiles.forEach(function(f) { dtSync.items.add(f); });
        $fileInput[0].files = dtSync.files;

        const actuallyAdded = allFiles.length - prevFiles.length;
        renderFileList($fileInput, $wrapper, $status, allFiles, maxFiles, actuallyAdded);
    }

    /**
     * Render the accumulated file list and manage add-more / remove interactions
     */
    function renderFileList($fileInput, $wrapper, $status, files, maxFiles, newCount) {
        $status.empty();
        const startNewIdx = Math.max(0, files.length - newCount);

        files.forEach(function(file, index) {
            const isNew = index >= startNewIdx;
            const fileHtml = `
                <div class="sf-file-info" data-file-index="${index}">
                    <div class="sf-file-icon">
                        <span class="dashicons dashicons-media-document"></span>
                    </div>
                    <div class="sf-file-details">
                        <div class="sf-file-name">${escapeHtml(file.name)}</div>
                        <div class="sf-file-size">${formatFileSize(file.size)}</div>
                        <div class="sf-file-progress">
                            <div class="sf-progress-bar">
                                <div class="sf-progress-fill${isNew ? '' : ' complete'}" style="${isNew ? '' : 'width:100%'}"></div>
                            </div>
                            <div class="sf-progress-text">${isNew ? 'Ready to upload...' : '<span class="dashicons dashicons-yes-alt"></span> Ready'}</div>
                        </div>
                    </div>
                    <div class="sf-file-actions">
                        <button type="button" class="sf-file-remove" data-file-index="${index}" title="Remove file">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                    </div>
                </div>
            `;
            $status.append(fileHtml);
        });

        // Show "Add more files" label-button when below the max limit
        if (maxFiles && files.length < maxFiles) {
            const remaining = maxFiles - files.length;
            const inputId = $fileInput.attr('id');
            $status.append(`
                <label for="${escapeHtml(inputId)}" class="sf-add-more-files-btn">
                    <span class="dashicons dashicons-plus-alt2"></span>
                    Add more files <span class="sf-remaining-count">(${remaining} remaining)</span>
                </label>
            `);
        }

        $wrapper.addClass('has-file');

        // Animate progress only for newly added files
        $status.find('.sf-file-info').each(function(index) {
            if (index >= startNewIdx) {
                const $fileInfo = $(this);
                animateProgress($fileInfo.find('.sf-progress-fill'), $fileInfo.find('.sf-progress-text'));
            }
        });

        // Remove handler
        $status.find('.sf-file-remove').on('click', function() {
            const removeIdx = parseInt($(this).data('file-index'));
            const updatedFiles = files.filter(function(_, i) { return i !== removeIdx; });
            $wrapper.data('sf-files', updatedFiles);

            if (updatedFiles.length === 0) {
                $fileInput.val('');
                $status.empty();
                $wrapper.removeClass('has-file');
            } else {
                const dtRemove = new DataTransfer();
                updatedFiles.forEach(function(f) { dtRemove.items.add(f); });
                $fileInput[0].files = dtRemove.files;
                renderFileList($fileInput, $wrapper, $status, updatedFiles, maxFiles, 0);
            }
        });
    }
    
    /**
     * Animate upload progress
     * 
     * @param {jQuery} $progressBar Progress bar element
     * @param {jQuery} $progressText Progress text element
     */
    function animateProgress($progressBar, $progressText) {
        $progressBar.css('width', '0%');
        $progressText.text('Ready to upload...');
        
        // Simulate progress animation
        let progress = 0;
        const interval = setInterval(function() {
            progress += Math.random() * 30;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                $progressBar.css('width', '100%');
                $progressText.html('<span class="dashicons dashicons-yes-alt"></span> Ready');
                $progressBar.addClass('complete');
            } else {
                $progressBar.css('width', progress + '%');
                $progressText.text('Preparing... ' + Math.round(progress) + '%');
            }
        }, 200);
    }
    
    /**
     * Format file size to human readable format
     * 
     * @param {number} bytes File size in bytes
     * @return {string} Formatted file size
     */
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
    
    /**
     * Escape HTML to prevent XSS
     * 
     * @param {string} text Text to escape
     * @return {string} Escaped text
     */
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }

    /**
     * Initialize conditional fields logic
     * 
     * @param {jQuery} $form Form element
     */
    function initConditionalFields($form) {
        // Find all conditional fields in this form
        // Look for any field container with data-conditional attribute
        const $conditionalFields = $form.find('[data-conditional]');
        
        if ($conditionalFields.length === 0) {
            // No conditional fields found in this form
            return;
        }
        
        // Process conditional fields initially
        $conditionalFields.each(function() {
            processConditionalField($(this), $form);
        });
        
        // Add change event listeners to all form fields
        $form.find('input, select, textarea').on('change', function() {
            // When any field changes, update all conditional fields
            $conditionalFields.each(function() {
                processConditionalField($(this), $form);
            });
        });
        
        // Force evaluation on page load
        setTimeout(function() {
            $form.find('input, select, textarea').first().trigger('change');
            
            // Second attempt with direct processing after everything is fully loaded
            $conditionalFields.each(function() {
                processConditionalField($(this), $form);
            });
        }, 300);
    }

    /**
     * Process a single conditional field
     * 
     * @param {jQuery} $field Conditional field container
     * @param {jQuery} $form Parent form
     */
    function processConditionalField($field, $form) {
        // Get conditional data from the field
        const conditionalData = $field.data('conditional-data');
        
        // Check if we have valid conditional data
        if (!conditionalData || !conditionalData.action || !conditionalData.groups) {
            return;
        }

        // Process the advanced conditional logic
        processAdvancedConditionalLogic($field, $form);
    }
    
    /**
     * Process advanced conditional logic with multiple conditions and groups
     * 
     * @param {jQuery} $field Conditional field container
     * @param {jQuery} $form Parent form
     */
    function processAdvancedConditionalLogic($field, $form) {
        // Get the conditional logic data
        const conditionalData = $field.data('conditional-data');
        
        if (!conditionalData || !conditionalData.action || !conditionalData.groups) {
            return;
        }
        
        // Determine if the conditions are met
        let conditionsMet = false;
        
        if (conditionalData.logic_type === 'any') {
            // ANY logic (OR between groups) - at least one group must be true
            conditionsMet = processAnyLogic(conditionalData.groups, $form);
        } else {
            // ALL logic (AND between groups) - all groups must be true
            conditionsMet = processAllLogic(conditionalData.groups, $form);
        }
        
        // Apply the appropriate action based on the conditions
        applyConditionalAction($field, conditionalData.action, conditionsMet);
    }
    
    /**
     * Process ANY logic - at least one group must be true (OR between groups)
     * 
     * @param {Array} groups Array of condition groups
     * @param {jQuery} $form Parent form
     * @return {boolean} Whether any group's conditions are met
     */
    function processAnyLogic(groups, $form) {
        for (let i = 0; i < groups.length; i++) {
            // For each group, ALL rules must be true (AND within group)
            if (processGroupRules(groups[i].rules, $form, 'all')) {
                return true; // If any group is true, return true immediately
            }
        }
        return false; // No group was true
    }
    
    /**
     * Process ALL logic - all groups must be true (AND between groups)
     * 
     * @param {Array} groups Array of condition groups
     * @param {jQuery} $form Parent form
     * @return {boolean} Whether all group's conditions are met
     */
    function processAllLogic(groups, $form) {
        for (let i = 0; i < groups.length; i++) {
            // For each group, ALL rules must be true (AND within group)
            if (!processGroupRules(groups[i].rules, $form, 'all')) {
                return false; // If any group is false, return false immediately
            }
        }
        return true; // All groups were true
    }
    
    /**
     * Process rules within a group
     * 
     * @param {Array} rules Array of rules within a group
     * @param {jQuery} $form Parent form
     * @param {string} logicType The logic type within the group ('all' or 'any')
     * @return {boolean} Whether the group's conditions are met
     */
    function processGroupRules(rules, $form, logicType) {
        if (!rules || rules.length === 0) {
            return true; // Empty rules are always true
        }
        
        if (logicType === 'any') {
            // ANY logic - at least one rule must be true
            for (let i = 0; i < rules.length; i++) {
                if (evaluateRule(rules[i], $form)) {
                    return true; // If any rule is true, return true immediately
                }
            }
            return false; // No rule was true
        } else {
            // ALL logic - all rules must be true
            for (let i = 0; i < rules.length; i++) {
                if (!evaluateRule(rules[i], $form)) {
                    return false; // If any rule is false, return false immediately
                }
            }
            return true; // All rules were true
        }
    }
    
    /**
     * Evaluate a single conditional rule
     * 
     * @param {Object} rule The rule to evaluate
     * @param {jQuery} $form Parent form
     * @return {boolean} Whether the rule condition is met
     */
    function evaluateRule(rule, $form) {
        let actualValue;
        
        // Get the actual value based on source type
        switch (rule.source_type) {
            case 'field':
                actualValue = getFieldValue(rule.field, $form);
                break;
            case 'user':
                actualValue = getUserValue(rule.field, rule.meta_key);
                break;
            case 'date':
                actualValue = getDateValue(rule.field);
                break;
            default:
                return false;
        }
        
        // Compare values based on operator
        return compareValues(actualValue, rule.value, rule.operator);
    }
    
    /**
     * Get value from a form field
     * 
     * @param {string} fieldId The field ID to get value from
     * @param {jQuery} $form Parent form
     * @return {string} The field value
     */
    function getFieldValue(fieldId, $form) {
        // Find the field by name
        let $field = $form.find('[name="' + fieldId + '"]');
        if ($field.length === 0) {
            // Try array notation for checkboxes/multi-select
            $field = $form.find('[name="' + fieldId + '\[\]"]');
        }
        
        if ($field.length === 0) {
            // Field not found
            return '';
        }
        
        // Different handling based on field type
        if ($field.is('select[multiple]')) {
            // Multi-select
            const selectedValues = [];
            $field.find('option:selected').each(function() {
                selectedValues.push($(this).val());
            });
            return selectedValues.join(',');
        } else if ($field.is(':radio')) {
            // Radio buttons
            return $form.find('[name="' + fieldId + '"]:checked').val() || '';
        } else if ($field.is(':checkbox')) {
            if ($field.length === 1) {
                // Single checkbox
                return $field.is(':checked') ? '1' : '';
            } else {
                // Multiple checkboxes
                const selectedValues = [];
                $form.find('[name="' + fieldId + '\[\]"]:checked').each(function() {
                    selectedValues.push($(this).val());
                });
                return selectedValues.join(',');
            }
        } else {
            // Text, email, number, etc.
            return $field.val() || '';
        }
    }
    
    /**
     * Get value from user data
     * 
     * @param {string} dataType The type of user data
     * @param {string} metaKey The meta key (if applicable)
     * @return {string} The user data value
     */
    function getUserValue(dataType, metaKey) {
        // sfData.user_data on the front end; sf_vars only exists in the admin,
        // so "User Data" conditions used to never match for visitors.
        const userData = (typeof sfData !== 'undefined' && sfData.user_data)
            || (typeof sf_vars !== 'undefined' && sf_vars.user_data)
            || null;
        if (userData) {
            switch (dataType) {
                case 'logged_in':
                    return userData.logged_in ? '1' : '';
                case 'user_role':
                    return userData.role || '';
                case 'user_meta':
                    if (metaKey && userData.meta && userData.meta[metaKey] !== undefined) {
                        return String(userData.meta[metaKey]);
                    }
                    break;
            }
        }
        return '';
    }
    
    /**
     * Get value from date/time
     * 
     * @param {string} dateType The type of date/time
     * @return {string} The date/time value
     */
    function getDateValue(dateType) {
        const now = new Date();
        
        switch (dateType) {
            case 'current_date':
                return now.toISOString().split('T')[0]; // YYYY-MM-DD
            case 'current_time':
                return now.getHours() + ':' + now.getMinutes(); // HH:MM
            case 'current_day':
                return now.getDay().toString(); // 0-6 (Sunday-Saturday)
            default:
                return '';
        }
    }
    
    /**
     * Compare values based on operator
     * 
     * @param {string} actualValue The actual value
     * @param {string} expectedValue The expected value
     * @param {string} operator The comparison operator
     * @return {boolean} Whether the comparison is true
     */
    function compareValues(actualValue, expectedValue, operator) {
        // Convert to strings for comparison
        actualValue = actualValue.toString();
        expectedValue = expectedValue.toString();
        
        switch (operator) {
            case '=':
                return actualValue == expectedValue;
            case '!=':
                return actualValue != expectedValue;
            case '>':
                return parseFloat(actualValue) > parseFloat(expectedValue);
            case '<':
                return parseFloat(actualValue) < parseFloat(expectedValue);
            case '>=':
                return parseFloat(actualValue) >= parseFloat(expectedValue);
            case '<=':
                return parseFloat(actualValue) <= parseFloat(expectedValue);
            case 'contains':
                return actualValue.indexOf(expectedValue) !== -1;
            case 'starts_with':
                return actualValue.startsWith(expectedValue);
            case 'ends_with':
                return actualValue.endsWith(expectedValue);
            case 'is_checked':
                return actualValue === '1';
            case 'is_not_checked':
                return actualValue !== '1';
            case 'is_empty':
                return actualValue === '';
            case 'is_not_empty':
                return actualValue !== '';
            case 'before_date':
                return new Date(actualValue) < new Date(expectedValue);
            case 'after_date':
                return new Date(actualValue) > new Date(expectedValue);
            case 'is_date':
                return new Date(actualValue).toDateString() === new Date(expectedValue).toDateString();
            default:
                return false;
        }
    }
    
    /**
     * Apply the conditional action to the field
     * 
     * @param {jQuery} $field The field container
     * @param {string} action The action to apply (show, hide, enable, disable)
     * @param {boolean} conditionsMet Whether the conditions are met
     */
    function applyConditionalAction($field, action, conditionsMet) {
        switch (action) {
            case 'show':
                if (conditionsMet) {
                    $field.addClass('sf-show').slideDown(200);
                    $field.find('input, select, textarea').prop('disabled', false);
                } else {
                    $field.removeClass('sf-show').slideUp(200);
                    $field.find('input, select, textarea').prop('disabled', true);
                }
                break;
                
            case 'hide':
                if (conditionsMet) {
                    $field.removeClass('sf-show').slideUp(200);
                    $field.find('input, select, textarea').prop('disabled', true);
                } else {
                    $field.addClass('sf-show').slideDown(200);
                    $field.find('input, select, textarea').prop('disabled', false);
                }
                break;
                
            case 'enable':
                if (conditionsMet) {
                    $field.removeClass('sf-disabled');
                    $field.find('input, select, textarea').prop('disabled', false);
                } else {
                    $field.addClass('sf-disabled');
                    $field.find('input, select, textarea').prop('disabled', true);
                }
                break;
                
            case 'disable':
                if (conditionsMet) {
                    $field.addClass('sf-disabled');
                    $field.find('input, select, textarea').prop('disabled', true);
                } else {
                    $field.removeClass('sf-disabled');
                    $field.find('input, select, textarea').prop('disabled', false);
                }
                break;
        }
    }
    
    /**
     * Validate form before submission
     * 
     * @param {jQuery} $form Form element
     * @return {boolean} Whether form is valid
     */
    function validateForm($form) {
        let isValid = true;
        
        // Check required fields (that are not disabled by conditional logic)
        $form.find('input[required]:not(:disabled), select[required]:not(:disabled), textarea[required]:not(:disabled)').each(function() {
            const $field = $(this);
            const fieldType = $field.attr('type');
            
            if (fieldType === 'checkbox') {
                // For single checkboxes, check if checked
                if (!$field.is(':checked')) {
                    isValid = false;
                    $field.addClass('sf-error');
                } else {
                    $field.removeClass('sf-error');
                }
            } else {
                // For other input types, check if value is empty
                if ($field.val() === '') {
                    isValid = false;
                    $field.addClass('sf-error');
                } else {
                    $field.removeClass('sf-error');
                }
            }
        });
        
        // Check required checkbox groups (fields with name ending in [])
        $form.find('input[type="checkbox"][name*="[]"]').each(function() {
            const $field = $(this);
            const fieldName = $field.attr('name');
            const fieldId = $field.data('field-id');
            
            // Check if this field group is required by looking for the hidden required indicator
            const $fieldGroup = $form.find('input[name="' + fieldName + '"]');
            const isRequired = $form.find('input[name="' + fieldName.replace('[]', '_required') + '"]').length > 0;
            
            if (isRequired) {
                // Check if at least one checkbox in the group is checked
                const hasChecked = $fieldGroup.filter(':checked').length > 0;
                
                if (!hasChecked) {
                    isValid = false;
                    $fieldGroup.addClass('sf-error');
                } else {
                    $fieldGroup.removeClass('sf-error');
                }
            }
        });
        
        // Validate email fields
        $form.find('input[type="email"]:not(:disabled)').each(function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if ($(this).val() !== '' && !emailRegex.test($(this).val())) {
                isValid = false;
                $(this).addClass('sf-error');
            }
        });
        
        return isValid;
    }

    /**
     * Submit form via AJAX
     * 
     * @param {jQuery} $form Form element
     */
    function submitForm($form) {
        // Check if reCAPTCHA v3 is enabled
        const $v3Token = $form.find('.recaptcha-v3-token');
        
        if ($v3Token.length) {
            const siteKey = $v3Token.data('sitekey');
            
            if (siteKey && typeof grecaptcha !== 'undefined') {
                // Generate reCAPTCHA v3 token before proceeding
                grecaptcha.ready(function() {
                    grecaptcha.execute(siteKey, {action: 'submit'}).then(function(token) {
                        // Set the token
                        $v3Token.val(token);
                        // Continue with form submission
                        proceedWithSubmission($form);
                    }).catch(function(error) {
                        // Show error to user
                        const $messagesContainer = $form.find('.sf-form-messages');
                        const $errorMessage = $messagesContainer.find('.sf-error-message');
                        $errorMessage.html('reCAPTCHA verification failed. Please refresh the page and try again.').show();
                        $messagesContainer.show();
                    });
                });
                return;
            } else if (!grecaptcha) {
                // grecaptcha not loaded, show error
                const $messagesContainer = $form.find('.sf-form-messages');
                const $errorMessage = $messagesContainer.find('.sf-error-message');
                $errorMessage.html('reCAPTCHA script not loaded. Please refresh the page and try again.').show();
                $messagesContainer.show();
                return;
            }
        }
        
        proceedWithSubmission($form);
    }
    
    /**
     * Proceed with form submission after captcha checks
     * 
     * @param {jQuery} $form Form element
     */
    function proceedWithSubmission($form) {
        // One submission at a time. The disabled button stops repeat clicks, but
        // a submit triggered by script or a second handler went through again.
        if ($form.data('sfSubmitting')) {
            return;
        }

        // Validate form before submission
        if (!validateForm($form)) {
            // Show error message for validation failure
            const $messagesContainer = $form.find('.sf-form-messages');
            const $errorMessage = $messagesContainer.find('.sf-error-message');
            
            $errorMessage.html(sfData.strings.validation_failed || 'Please fill in all required fields.').show();
            $messagesContainer.show();
            
            // Scroll to first error field
            const $firstError = $form.find('.sf-error').first();
            if ($firstError.length) {
                $('html, body').animate({
                    scrollTop: $firstError.offset().top - 100
                }, 300);
            }
            
            return;
        }
        
        const $submitButton = $form.find('.sf-submit-button');
        const $messagesContainer = $form.find('.sf-form-messages');
        const $errorMessage = $messagesContainer.find('.sf-error-message');
        const $successMessage = $messagesContainer.find('.sf-success-message');
        
        // Clear previous messages
        $errorMessage.html('').hide();
        $successMessage.html('').hide();
        $messagesContainer.show();
        
        // Save original button text if not already saved
        if (!$submitButton.data('original-text')) {
            $submitButton.data('original-text', $submitButton.html());
        }
        
        // Add loading indicator
        $form.data('sfSubmitting', true);
        $submitButton.prop('disabled', true).html(sfData.strings.submitting + ' <span class="sf-loading"></span>');
        
        // Prepare form data
        const formData = new FormData($form[0]);
        formData.append('action', 'sf_submit_form');
        formData.append('nonce', sfData.nonce);
        
        // Check if form has file uploads
        const $fileInputs = $form.find('input[type="file"]');
        const hasFiles = $fileInputs.filter(function() {
            return this.files.length > 0;
        }).length > 0;
        
        const strings = sfData.strings || {};
        let nonceRetried = false;

        // Restore the button and bring the result into view.
        const finish = function() {
            $form.removeData('sfSubmitting');
            $submitButton.prop('disabled', false).html($submitButton.data('original-text') || strings.submit);
            scrollToMessages($messagesContainer, $errorMessage, $successMessage);
        };

        const showError = function() {
            $errorMessage.html(strings.error).show();
            finish();
        };

        // A page served from a cache can carry a security token older than
        // WordPress accepts (about a day), and every submission then failed.
        // When the server rejects the token, fetch a fresh one and retry once.
        const retryWithFreshNonce = function(status, body, send) {
            if (nonceRetried || status !== 403 || $.trim(body || '') !== '-1') {
                return false;
            }

            nonceRetried = true;

            $.post(sfData.ajaxurl, { action: 'sf_refresh_nonce' })
                .done(function(response) {
                    if (response && response.success && response.data && response.data.nonce) {
                        sfData.nonce = response.data.nonce;
                        formData.set('nonce', sfData.nonce);
                        send();
                    } else {
                        showError();
                    }
                })
                .fail(showError);

            return true;
        };

        if (hasFiles) {
            // Use XMLHttpRequest for upload progress tracking
            const sendWithUploads = function() {
                const xhr = new XMLHttpRequest();

                // Track upload progress
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        const uploadingText = (strings.uploading || 'Uploading... %d%').replace('%d', percent);

                        // Update all file progress bars
                        $fileInputs.each(function() {
                            if (this.files.length > 0) {
                                const $wrapper = $(this).closest('.sf-file-upload');
                                const $status = $wrapper.find('.sf-file-status');
                                const $progressBar = $status.find('.sf-progress-fill');
                                const $progressText = $status.find('.sf-progress-text');

                                if ($progressBar.length && $progressText.length) {
                                    $progressBar.css('width', percent + '%');
                                    $progressText.text(uploadingText);

                                    if (percent === 100) {
                                        $progressBar.addClass('complete');
                                        $progressText.html('<span class="dashicons dashicons-yes-alt"></span> ').append(document.createTextNode(strings.uploaded || 'Uploaded successfully'));
                                    }
                                }
                            }
                        });

                        // Update submit button text
                        if (percent < 100) {
                            $submitButton.text(uploadingText);
                        } else {
                            // Once upload is complete, show processing message
                            $submitButton.html(strings.submitting + ' <span class="sf-loading"></span>');
                        }
                    }
                });

                // Handle response
                xhr.addEventListener('load', function() {
                    if (retryWithFreshNonce(xhr.status, xhr.responseText, sendWithUploads)) {
                        return;
                    }

                    if (xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            handleFormResponse(response, $form, $submitButton, $successMessage, $errorMessage, $messagesContainer, $fileInputs);
                        } catch (e) {
                            $errorMessage.html(strings.error).show();
                        }
                    } else {
                        $errorMessage.html(strings.error).show();
                    }

                    finish();
                });

                xhr.addEventListener('error', showError);

                // Send request
                xhr.open('POST', sfData.ajaxurl);
                xhr.send(formData);
            };

            sendWithUploads();
        } else {
            // Use jQuery AJAX for non-file submissions
            const send = function() {
                $.ajax({
                    url: sfData.ajaxurl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        try {
                            handleFormResponse(response, $form, $submitButton, $successMessage, $errorMessage, $messagesContainer, $fileInputs);
                        } finally {
                            // An error in a response handler must not leave the form locked.
                            finish();
                        }
                    },
                    error: function(xhr) {
                        if (!retryWithFreshNonce(xhr.status, xhr.responseText, send)) {
                            showError();
                        }
                    }
                });
            };

            send();
        }
    }
    
    /**
     * Handle form submission response
     */
    function handleFormResponse(response, $form, $submitButton, $successMessage, $errorMessage, $messagesContainer, $fileInputs) {
        if (response.success) {
            // Show success message
            $successMessage.html(response.data.message).show();
            
            // Get form ID for localStorage cleanup
            const formId = getFormId($form);
            
            // Clear localStorage for this form (important for file uploads)
            if (formId && localStorage) {
                try {
                    localStorage.removeItem('sigma_form_' + formId);
                } catch (e) {
                    // Handle errors silently
                }
            }
            
            // Clear sessionStorage for abandonment tracking
            if (formId && sessionStorage) {
                try {
                    sessionStorage.removeItem('sf_session_' + formId);
                } catch (e) {
                    // Handle errors silently
                }
            }
            
            // Reset form if configured
            $form[0].reset();
            
            // Restore auto-detected country for international phone fields and country fields after reset
            const detectedCountry = getCachedCountry();
            if (detectedCountry) {
                // Restore international phone country
                $form.find('.sf-country-code-select').each(function() {
                    const $select = $(this);
                    const $option = $select.find('option[value="' + detectedCountry + '"]');
                    
                    if ($option.length > 0) {
                        $select.val(detectedCountry);
                        // Reset the user-selected flag so auto-detection works again
                        $select.data('user-selected', false);
                    }
                });
                
                // Restore country field
                $form.find('.sf-field-country select').each(function() {
                    const $select = $(this);
                    const $option = $select.find('option[value="' + detectedCountry + '"]');
                    
                    if ($option.length > 0) {
                        $select.val(detectedCountry);
                        // Reset the user-selected flag so auto-detection works again
                        $select.data('user-selected', false);
                    }
                });
            }
            
            // Reset multi-step form to step 1 if it's a multi-step form
            if ($form.hasClass('sf-multistep-initialized')) {
                // Hide all steps
                $form.find('.sf-form-step').removeClass('active');
                // Show first step
                $form.find('.sf-form-step[data-step="0"]').addClass('active');
                // Scroll to top of form
                $('html, body').animate({
                    scrollTop: $form.offset().top - 50
                }, 300);
            }
            
            // Clear file uploads
            $fileInputs.each(function() {
                const $wrapper = $(this).closest('.sf-file-upload');
                $(this).val('');
                $wrapper.find('.sf-file-status').empty();
                $wrapper.removeClass('has-file');
            });
            
            // Clear signature pads
            $form.find('.sf-signature-pad').each(function() {
                const canvas = this;
                const $canvas = $(canvas);
                const $hiddenInput = $canvas.siblings('.sf-signature-data');
                const ctx = canvas.getContext('2d');
                
                // Clear the canvas
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                // Clear the hidden input value
                $hiddenInput.val('');
            });
            
            // Reset all CAPTCHA types if present
            if (typeof grecaptcha !== 'undefined' && grecaptcha) {
                // Reset v2 if present
                if ($form.find('.g-recaptcha').length) {
                    grecaptcha.reset();
                }
            }
            
            // Clear reCAPTCHA v3 token if present
            if ($form.find('.recaptcha-v3-token').length) {
                $form.find('.recaptcha-v3-token').val('');
            }
            
            // Reset Turnstile if present
            if (typeof turnstile !== 'undefined' && turnstile) {
                turnstile.reset();
            }

            // Reset mTCaptcha if present
            if ($form.find('.mtcaptcha').length > 0 && typeof window.mtcaptcha !== 'undefined' && window.mtcaptcha && typeof window.mtcaptcha.resetUI === 'function') {
                window.mtcaptcha.resetUI();
            }

            if ($form.find('input[name="mtcaptcha-verifiedtoken"]').length > 0) {
                $form.find('input[name="mtcaptcha-verifiedtoken"]').val('');
            }
            
            // Trigger form submitted event for developers
            $form.trigger('sf:form_submitted', [response.data]);
        } else {
            // Show error message
            let errorMsg = response.data.message || sfData.strings.error;
            
            // Add specific field errors if available
            if (response.data.errors && response.data.errors.length) {
                errorMsg += '<ul>';
                
                response.data.errors.forEach(function(error) {
                    errorMsg += '<li>' + error + '</li>';
                });
                
                errorMsg += '</ul>';
            }
            
            $errorMessage.html(errorMsg).show();
        }
    }
    
    /**
     * Get form ID from form element
     */
    function getFormId($form) {
        const formId = $form.attr('id');
        if (formId && formId.startsWith('sf-form-')) {
            return parseInt(formId.replace('sf-form-', ''), 10);
        }
        
        // Fallback: look for data attribute
        const dataFormId = $form.data('form-id');
        if (dataFormId) {
            return parseInt(dataFormId, 10);
        }
        
        return null;
    }
    
    /**
     * Scroll to messages container
     */
    function scrollToMessages($messagesContainer, $errorMessage, $successMessage) {
        // Scroll to messages if there are any
        if ($errorMessage.is(':visible') || $successMessage.is(':visible')) {
            $('html, body').animate({
                scrollTop: $messagesContainer.offset().top - 100
            }, 300);
        }
    }

    /**
     * Initialize math functions for fields
     * 
     * @param {jQuery} $form Form element
     */
    function initMathFunctions($form) {
        // Find all fields with math functions enabled
        const $mathFields = $form.find('[data-math-function]');
        
        if ($mathFields.length === 0) {
            return;
        }
        
        // Debug: Log each math field details
        $mathFields.each(function(index) {
            const $field = $(this);
            const mathData = $field.data('math-function');
        });
        
        // Create a debounced update function for better performance
        let updateTimeout;
        const debouncedUpdate = function() {
            clearTimeout(updateTimeout);
            
            // Show calculating state on all math fields
            $mathFields.each(function() {
                $(this).addClass('calculating').removeClass('calculated');
            });
            
            updateTimeout = setTimeout(function() {
                $mathFields.each(function() {
                    updateMathField($(this), $form);
                });
            }, 50); // 50ms delay for better performance
        };
        
        // Add real-time event listeners to all form fields that might affect calculations
        $form.find('input, select, textarea').on('change input keyup paste', function() {
            const fieldName = $(this).attr('name');
            // When any field changes, update all math function fields with debouncing
            debouncedUpdate();
        });
        
        // Also listen for focus/blur events to ensure calculations happen
        $form.find('input, select, textarea').on('focus blur', function() {
            // Update math fields when fields gain/lose focus
            debouncedUpdate();
        });
        
        // Add immediate feedback for better user experience
        $form.find('input, select, textarea').on('input', function() {
            // Show immediate calculating state without debouncing for better UX
            $mathFields.each(function() {
                $(this).addClass('calculating').removeClass('calculated');
            });
        });
        
        // Initial calculation on page load
        setTimeout(function() {
            $mathFields.each(function() {
                updateMathField($(this), $form);
            });
        }, 300);
        
        // Additional calculation after a short delay to catch any late-loading content
        setTimeout(function() {
            $mathFields.each(function() {
                updateMathField($(this), $form);
            });
        }, 1000);
    }

    /**
     * Update a math function field with calculated value
     * 
     * @param {jQuery} $mathField The math function field element
     * @param {jQuery} $form Parent form
     */
    function updateMathField($mathField, $form) {
        try {
            const mathData = $mathField.data('math-function');
            if (!mathData || !mathData.enabled) {
                return;
            }
            
            const calculationType = mathData.calculation_type;
            let result = 0;
            let calculationDetails = '';
            
            if (calculationType === 'custom') {
                // Handle custom formula
                result = evaluateCustomFormula(mathData.formula, $form);
                calculationDetails = `Custom formula: ${mathData.formula}`;
            } else {
                // Handle predefined calculation types
                const selectedFields = mathData.fields || [];
                const fieldValues = [];
                const fieldDetails = [];
                
                // Get values from selected fields
                selectedFields.forEach(fieldId => {
                    const value = getFieldValue(fieldId, $form);
                    const numValue = parseFloat(value);
                    if (value !== '' && !isNaN(numValue)) {
                        fieldValues.push(numValue);
                        fieldDetails.push(`${fieldId}: ${numValue}`);
                    } else {
                        fieldDetails.push(`${fieldId}: 0`);
                    }
                });
                
                if (fieldValues.length === 0) {
                    $mathField.val('');
                    return;
                }
                
                // Perform calculation based on type
                switch (calculationType) {
                    case 'sum':
                        result = fieldValues.reduce((sum, val) => sum + val, 0);
                        calculationDetails = `Sum of ${fieldDetails.join(' + ')} = ${result}`;
                        break;
                    case 'subtract':
                        result = fieldValues.reduce((diff, val, index) => {
                            return index === 0 ? val : diff - val;
                        });
                        calculationDetails = `Subtract ${fieldDetails.slice(1).join(' - ')} from ${fieldDetails[0]} = ${result}`;
                        break;
                    case 'multiply':
                        result = fieldValues.reduce((product, val) => product * val, 1);
                        calculationDetails = `Multiply ${fieldDetails.join(' × ')} = ${result}`;
                        break;
                    case 'divide':
                        result = fieldValues.reduce((quotient, val, index) => {
                            if (index === 0) return val;
                            if (val === 0) return quotient; // Avoid division by zero
                            return quotient / val;
                        });
                        calculationDetails = `Divide ${fieldDetails[0]} by ${fieldDetails.slice(1).join(' ÷ ')} = ${result}`;
                        break;
                    case 'percentage':
                        if (fieldValues.length >= 2) {
                            result = (fieldValues[0] / fieldValues[1]) * 100;
                            calculationDetails = `${fieldDetails[0]} is ${result.toFixed(2)}% of ${fieldDetails[1]}`;
                        }
                        break;
                    case 'average':
                        result = fieldValues.reduce((sum, val) => sum + val, 0) / fieldValues.length;
                        calculationDetails = `Average of ${fieldDetails.join(', ')} = ${result.toFixed(2)}`;
                        break;
                }
            }
            
            // Apply rounding if enabled
            if (mathData.round_result && mathData.decimal_places !== undefined) {
                const decimalPlaces = parseInt(mathData.decimal_places);
                const originalResult = result;
                result = Math.round(result * Math.pow(10, decimalPlaces)) / Math.pow(10, decimalPlaces);
                if (originalResult !== result) {
                    calculationDetails += ` (rounded to ${decimalPlaces} decimal places)`;
                }
            }
            
            // Update the field value
            $mathField.val(result);
            
            // Make the field read-only/disabled so users can't edit it
            $mathField.prop('readonly', true).addClass('sf-math-field-disabled');
            
            // Add a title attribute to show the calculation details on hover
            $mathField.attr('title', calculationDetails);
            
            // Show calculated state and remove calculating state
            $mathField.removeClass('calculating').addClass('calculated');
            
            // Trigger change event to update any dependent fields
            $mathField.trigger('change');
            
        } catch (error) {
            $mathField.val('');
            
            // Remove calculating state on error
            $mathField.removeClass('calculating calculated');
        }
    }

    /**
     * Evaluate a custom formula
     * 
     * @param {string} formula The custom formula string
     * @param {jQuery} $form Parent form
     * @return {number} The calculated result
     */
    function evaluateCustomFormula(formula, $form) {
        if (!formula || typeof formula !== 'string') {
            return 0;
        }
        
        try {
            // Replace field references [field_name] with actual values
            let processedFormula = formula;
            const fieldRegex = /\[([^\]]+)\]/g;
            
            processedFormula = processedFormula.replace(fieldRegex, function(match, fieldId) {
                const value = getFieldValue(fieldId, $form);
                if (value === '' || isNaN(parseFloat(value))) {
                    return '0';
                }
                return parseFloat(value);
            });
            
            // Replace mathematical operators with JavaScript equivalents
            processedFormula = processedFormula
                .replace(/\^/g, '**') // Replace ^ with ** for exponentiation
                .replace(/%/g, '/100'); // Replace % with /100 for percentage
            
            // Evaluate the formula safely
            // Note: This is a basic implementation. For production, consider using a math expression parser library
            const result = Function('"use strict"; return (' + processedFormula + ')')();
            
            return isFinite(result) ? result : 0;
            
        } catch (error) {
            return 0;
        }
    }

    /**
     * Initialize countdown timers for scheduled forms
     */
    $(document).ready(function() {
        // Initialize countdown timers for forms that haven't started
        $('.sf-countdown-timer').each(function() {
            const $timer = $(this);
            const targetTime = parseInt($timer.data('target')) * 1000; // Convert to milliseconds
            
            updateCountdown($timer, targetTime, true);
            
            // Update every second
            const interval = setInterval(function() {
                const shouldContinue = updateCountdown($timer, targetTime, true);
                if (!shouldContinue) {
                    clearInterval(interval);
                    // Hide countdown and show "Form is now available" message
                    $('.sf-countdown-label').hide();
                    $timer.html('<div class="sf-countdown-expired">Form is now available!</div>');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }
            }, 1000);
        });
        
        // Initialize countdown timers for forms with end time
        $('.sf-form-countdown-header').each(function() {
            const $header = $(this);
            const $timer = $header.find('.sf-countdown-timer-live');
            const targetTime = parseInt($header.data('target')) * 1000; // Convert to milliseconds
            
            updateCountdown($timer, targetTime, false);
            
            // Update every second
            const interval = setInterval(function() {
                const shouldContinue = updateCountdown($timer, targetTime, false);
                if (!shouldContinue) {
                    clearInterval(interval);
                    // Remove countdown and show "Submission time has ended" message
                    $header.html('<div class="sf-countdown-label">Submission time has ended</div>');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }
            }, 1000);
        });
    });

    /**
     * Update countdown timer display
     * 
     * @param {jQuery} $timer Timer element
     * @param {number} targetTime Target timestamp in milliseconds
     * @param {boolean} showText Whether to show "Available in" text
     * @return {boolean} Whether to continue the countdown
     */
    function updateCountdown($timer, targetTime, showText) {
        const now = Date.now();
        const diff = targetTime - now;
        
        if (diff <= 0) {
            return false;
        }
        
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        
        let html = '<div class="sf-countdown-display">';
        
        if (showText) {
            html += '<div class="sf-countdown-label">Available in:</div>';
        }
        
        html += '<div class="sf-countdown-units">';
        
        // Always show days with leading zero
        html += '<div class="sf-countdown-unit">';
        html += '<span class="sf-countdown-number">' + String(days).padStart(2, '0') + '</span>';
        html += '<span class="sf-countdown-text">' + (days === 1 ? 'Day' : 'Days') + '</span>';
        html += '</div>';
        
        // Always show hours with leading zero
        html += '<div class="sf-countdown-unit">';
        html += '<span class="sf-countdown-number">' + String(hours).padStart(2, '0') + '</span>';
        html += '<span class="sf-countdown-text">' + (hours === 1 ? 'Hour' : 'Hours') + '</span>';
        html += '</div>';
        
        html += '<div class="sf-countdown-unit">';
        html += '<span class="sf-countdown-number">' + String(minutes).padStart(2, '0') + '</span>';
        html += '<span class="sf-countdown-text">' + (minutes === 1 ? 'Minute' : 'Minutes') + '</span>';
        html += '</div>';
        
        html += '<div class="sf-countdown-unit">';
        html += '<span class="sf-countdown-number">' + String(seconds).padStart(2, '0') + '</span>';
        html += '<span class="sf-countdown-text">' + (seconds === 1 ? 'Second' : 'Seconds') + '</span>';
        html += '</div>';
        
        html += '</div></div>';
        
        $timer.html(html);
        return true;
    }

    /* ---------------------------------------------------------------------
     * Visual select
     *
     * Select fields whose options carry images render a native <select>
     * (kept for submission, validation and conditional logic) plus a styled
     * listbox on top of it. Everything below just keeps the two in sync.
     * ------------------------------------------------------------------ */

    $(document).on('click', '.sf-select-display', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggleVisualSelect($(this).closest('.sf-select-wrapper'));
    });

    $(document).on('click', '.sf-select-item', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $item = $(this);
        const $wrapper = $item.closest('.sf-select-wrapper');

        selectVisualOption($wrapper, $item);
        closeVisualSelect($wrapper);
        $wrapper.find('.sf-select-display').trigger('focus');
    });

    // Any click outside closes every open dropdown
    $(document).on('click', function () {
        closeVisualSelect($('.sf-select-wrapper.sf-open'));
    });

    $(document).on('keydown', '.sf-select-display', function (e) {
        const $wrapper = $(this).closest('.sf-select-wrapper');
        const isOpen = $wrapper.hasClass('sf-open');

        switch (e.key) {
            case 'Enter':
            case ' ':
                e.preventDefault();
                toggleVisualSelect($wrapper);
                break;

            case 'Escape':
                closeVisualSelect($wrapper);
                break;

            case 'ArrowDown':
            case 'ArrowUp': {
                e.preventDefault();

                if (!isOpen) {
                    toggleVisualSelect($wrapper);
                    return;
                }

                const $items = $wrapper.find('.sf-select-item');
                const currentIndex = $items.index($wrapper.find('.sf-select-item.sf-active'));
                const step = e.key === 'ArrowDown' ? 1 : -1;
                let nextIndex = currentIndex + step;

                if (nextIndex < 0) {
                    nextIndex = $items.length - 1;
                } else if (nextIndex >= $items.length) {
                    nextIndex = 0;
                }

                $items.removeClass('sf-active');
                const $next = $items.eq(nextIndex).addClass('sf-active');
                selectVisualOption($wrapper, $next);

                if ($next.length) {
                    $next[0].scrollIntoView({ block: 'nearest' });
                }
                break;
            }

            default:
                break;
        }
    });

    /**
     * Open or close a visual select.
     *
     * @param {jQuery} $wrapper The .sf-select-wrapper element.
     */
    function toggleVisualSelect($wrapper) {
        if (!$wrapper.length) {
            return;
        }

        const willOpen = !$wrapper.hasClass('sf-open');

        // Only one dropdown open at a time
        closeVisualSelect($('.sf-select-wrapper.sf-open').not($wrapper));

        if (willOpen) {
            $wrapper.addClass('sf-open');
            $wrapper.find('.sf-select-display').attr('aria-expanded', 'true');
            $wrapper.find('.sf-select-item').removeClass('sf-active')
                .filter('.sf-selected').addClass('sf-active');
        } else {
            closeVisualSelect($wrapper);
        }
    }

    /**
     * Close one or more visual selects.
     *
     * @param {jQuery} $wrappers One or more .sf-select-wrapper elements.
     */
    function closeVisualSelect($wrappers) {
        if (!$wrappers || !$wrappers.length) {
            return;
        }

        $wrappers.removeClass('sf-open');
        $wrappers.find('.sf-select-display').attr('aria-expanded', 'false');
        $wrappers.find('.sf-select-item').removeClass('sf-active');
    }

    /**
     * Apply an option to both the native select and the visual display.
     *
     * @param {jQuery} $wrapper The .sf-select-wrapper element.
     * @param {jQuery} $item    The chosen .sf-select-item element.
     */
    function selectVisualOption($wrapper, $item) {
        if (!$item.length) {
            return;
        }

        const value = $item.data('value');
        const $native = $wrapper.find('select');

        $wrapper.find('.sf-select-item').removeClass('sf-selected').attr('aria-selected', 'false');
        $item.addClass('sf-selected').attr('aria-selected', 'true');

        // Rebuild the closed state from the chosen row so the image comes along
        const $display = $wrapper.find('.sf-select-display');
        $display.find('.sf-option-image-wrap, .sf-country-flag, .sf-select-current').remove();

        const $visual = $item.find('.sf-option-image-wrap, .sf-country-flag').first().clone();
        if ($visual.length) {
            $display.append($visual);
        }

        $display.append(
            $('<span class="sf-select-current"></span>').text($item.find('.sf-select-item-text').text())
        );

        // Native change drives validation, conditional logic and submission.
        // The error outline is mirrored onto the display purely in CSS via
        // `select.sf-error + .sf-select-display`, so nothing to clear here.
        $native.val(value).trigger('change');
    }

})(jQuery);
