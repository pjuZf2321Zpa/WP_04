/**
 * SigmaForms - Mobile Signature via QR Code
 * 
 * Handles QR code generation and real-time signature updates
 */
(function($) {
    'use strict';

    // QR Code generation using QRCode.js library
    window.SF = window.SF || {};
    window.SF.MobileSignature = {
        
        /**
         * Initialize mobile signature for a field
         * 
         * @param {string} fieldId Field ID
         * @param {jQuery} $container Container element
         */
        init: function(fieldId, $container) {
            const self = this;
            const $qrContainer = $container.find('.sf-qr-container');
            const $qrCode = $container.find('.sf-qr-code');
            const $qrStatus = $container.find('.sf-qr-status');
            const $showQrBtn = $container.find('.sf-show-qr-btn');
            const $hideQrBtn = $container.find('.sf-hide-qr-btn');
            const $canvas = $container.find('.sf-signature-pad');
            const $hiddenInput = $container.find('.sf-signature-data');
            const formId = $container.closest('form').find('input[name="form_id"]').val();
            
            let sessionId = null;
            let pollInterval = null;
            
            // Show QR code button
            $showQrBtn.on('click', function() {
                self.createSession(fieldId, formId, function(data) {
                    sessionId = data.session_id;
                    self.generateQRCode($qrCode[0], data.qr_data);
                    $qrContainer.slideDown();
                    $showQrBtn.hide();
                    $qrStatus.text('Waiting for signature...');
                    
                    // Start polling for signature
                    self.startPolling(sessionId, function(signatureData) {
                        // Update the signature field
                        $hiddenInput.val(signatureData);
                        
                        // Display signature on canvas
                        self.displaySignatureOnCanvas($canvas[0], signatureData);
                        
                        // Update status
                        $qrStatus.html('<span style="color: #10b981;">✓ Signature received!</span>');
                        
                        // Stop polling
                        self.stopPolling();
                        
                        // Hide QR code after 2 seconds
                        setTimeout(function() {
                            $qrContainer.slideUp();
                            $showQrBtn.show();
                        }, 2000);
                    });
                });
            });
            
            // Hide QR code button
            $hideQrBtn.on('click', function() {
                $qrContainer.slideUp();
                $showQrBtn.show();
                self.stopPolling();
            });
            
            // Store polling interval reference
            this.pollInterval = pollInterval;
        },
        
        /**
         * Create signature session
         * 
         * @param {string} fieldId Field ID
         * @param {string} formId Form ID
         * @param {function} callback Success callback
         */
        createSession: function(fieldId, formId, callback) {
            $.ajax({
                url: sfParams.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'sf_create_signature_session',
                    field_id: fieldId,
                    form_id: formId
                },
                success: function(response) {
                    if (response.success) {
                        callback(response.data);
                    } else {
                        alert('Failed to create signature session');
                    }
                },
                error: function() {
                    alert('Network error. Please try again.');
                }
            });
        },
        
        /**
         * Generate QR code
         * 
         * @param {HTMLElement} element Element to render QR code
         * @param {string} data Data to encode
         */
        generateQRCode: function(element, data) {
            // Clear existing QR code
            element.innerHTML = '';
            
            // Use QRCode library if available, otherwise create a simple text link
            if (typeof QRCode !== 'undefined') {
                new QRCode(element, {
                    text: data,
                    width: 200,
                    height: 200,
                    colorDark: '#000000',
                    colorLight: '#ffffff',
                    correctLevel: QRCode.CorrectLevel.H
                });
            } else {
                // Fallback: display link
                element.innerHTML = '<div style="padding: 20px; text-align: center;">' +
                    '<p style="margin-bottom: 10px;">Scan this QR code or click the link:</p>' +
                    '<a href="' + data + '" target="_blank" style="word-break: break-all; color: #667eea;">' + data + '</a>' +
                    '</div>';
            }
        },
        
        /**
         * Start polling for signature updates
         * 
         * @param {string} sessionId Session ID
         * @param {function} callback Success callback when signature is received
         */
        startPolling: function(sessionId, callback) {
            const self = this;
            
            this.pollInterval = setInterval(function() {
                $.ajax({
                    url: sfParams.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'sf_check_signature_status',
                        session_id: sessionId
                    },
                    success: function(response) {
                        if (response.success && response.data.status === 'completed') {
                            callback(response.data.signature_data);
                            self.stopPolling();
                        }
                    }
                });
            }, 2000); // Poll every 2 seconds
        },
        
        /**
         * Stop polling
         */
        stopPolling: function() {
            if (this.pollInterval) {
                clearInterval(this.pollInterval);
                this.pollInterval = null;
            }
        },
        
        /**
         * Display signature on canvas
         * 
         * @param {HTMLCanvasElement} canvas Canvas element
         * @param {string} signatureData Base64 signature data
         */
        displaySignatureOnCanvas: function(canvas, signatureData) {
            const ctx = canvas.getContext('2d');
            const img = new Image();
            
            img.onload = function() {
                // Clear canvas
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                
                // Draw image
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            };
            
            img.src = signatureData;
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        // Auto-initialize signature fields with QR option
        $('.sf-signature-wrapper[data-qr-enabled="true"]').each(function() {
            const $wrapper = $(this);
            const fieldId = $wrapper.find('.sf-signature-data').attr('id');
            
            if (fieldId) {
                window.SF.MobileSignature.init(fieldId, $wrapper);
            }
        });
    });
    
})(jQuery);
