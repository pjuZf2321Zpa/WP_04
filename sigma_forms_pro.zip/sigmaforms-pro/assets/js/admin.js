/**
 * SigmaForms - Main Admin Scripts
 * 
 * This file coordinates all the modular components.
 */

// Define global namespace for shared functions
window.SF = window.SF || {};

(function($) {
    'use strict';

    // Initialise the components present on the current page. Runs on the
    // first load and again after admin-nav.js swaps in a page without a reload.
    function bootPage() {
        // Initialize components based on page elements
        if ($('.sf-ai-generator-wrapper').length > 0) {
            if (window.SF.AIGenerator && window.SF.AIGenerator.init) {
                window.SF.AIGenerator.init();
            }
        }
        
        if ($('.sf-submissions-table').length > 0) {
            if (window.SF.Submissions && window.SF.Submissions.init) {
                window.SF.Submissions.init();
            }
        }
        
        if ($('.sf-settings-page').length > 0) {
            if (window.SF.Settings && window.SF.Settings.init) {
                window.SF.Settings.init();
            }
        }

        // Initialize visual form editor and conditional logic
        if ($('#sf-visual-form-preview').length > 0 || $('.sf-form-editor').length > 0) {
            if (window.SF.VisualEditor && window.SF.VisualEditor.init) {
                window.SF.VisualEditor.init();
            }
            
            // Initialize advanced conditional logic
            if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.initAdvancedConditionalLogic) {
                window.SF.ConditionalLogic.initAdvancedConditionalLogic();
            }
            if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateConditionalFieldOptions) {
                window.SF.ConditionalLogic.updateConditionalFieldOptions();
            }
        }
    }

    $(document).ready(function() {
        bootPage();

        // The WordPress admin menu is not replaced by in-page navigation, so
        // the white label menu sync only needs to run once.
        if (window.sfWhiteLabelData && window.sfWhiteLabelData.bootWhiteLabelChrome) {
            window.sfWhiteLabelData.bootWhiteLabelChrome();
        }
    });

    $(document).on('sf:page-load', bootPage);

    // A security token (nonce) expires if a SigmaForms screen stays open for
    // about a day. WordPress then answers admin-ajax requests with "-1" (or
    // "0" once logged out) and each screen showed only a generic failure.
    // Say what actually happened and offer a reload instead.
    $(document).ajaxError(function(event, xhr, settings) {
        if (!settings || typeof settings.url !== 'string' || settings.url.indexOf('admin-ajax.php') === -1) {
            return;
        }

        var body = $.trim(xhr.responseText || '');

        if (xhr.status === 403 && body === '-1') {
            showSessionExpired();
        } else if (xhr.status === 400 && body === '0') {
            // Also what an unhooked action returns, so ask WordPress whether
            // the user is really logged out before saying so.
            // global: false keeps this probe out of ajaxError, so a heartbeat
            // that also fails cannot trigger another probe.
            $.ajax({
                url: settings.url,
                type: 'POST',
                global: false,
                data: { action: 'heartbeat', data: { 'wp-auth-check': true } }
            }).done(function(response) {
                if (response && response['wp-auth-check'] === false) {
                    showSessionExpired();
                }
            });
        }
    });

    /**
     * A translated admin string from sfAdmin.strings, or the English fallback.
     *
     * @param {string} key
     * @param {string} fallback
     * @return {string}
     */
    window.SF.t = function(key, fallback) {
        var strings = (window.sfAdmin && window.sfAdmin.strings) || {};
        return strings[key] || fallback;
    };

    /**
     * Confirmation dialog in the plugin's own style, replacing window.confirm().
     *
     * Resolves true when confirmed, false when cancelled (button, Escape or a
     * click on the backdrop). Focus stays inside the dialog while it is open
     * and returns to the element that opened it.
     *
     * @param {string} message
     * @param {{title?: string, confirmLabel?: string, danger?: boolean}} [options]
     * @return {Promise<boolean>}
     */
    window.SF.confirm = function(message, options) {
        options = options || {};
        var strings = (window.sfAdmin && window.sfAdmin.strings) || {};
        var opener = document.activeElement;

        return new Promise(function(resolve) {
            var $backdrop = $('<div class="sf-dialog-backdrop"></div>');
            var $dialog = $('<div class="sf-dialog" role="alertdialog" aria-modal="true"></div>')
                .attr('aria-labelledby', 'sf-dialog-title')
                .attr('aria-describedby', 'sf-dialog-message');
            $('<h2 class="sf-dialog__title" id="sf-dialog-title"></h2>')
                .text(options.title || strings.confirmTitle || 'Are you sure?')
                .appendTo($dialog);
            $('<p class="sf-dialog__message" id="sf-dialog-message"></p>').text(message).appendTo($dialog);

            var $actions = $('<div class="sf-dialog__actions"></div>').appendTo($dialog);
            var $cancel = $('<button type="button" class="sf-dialog__button"></button>')
                .text(strings.cancel || 'Cancel')
                .appendTo($actions);
            var $ok = $('<button type="button" class="sf-dialog__button is-primary"></button>')
                .toggleClass('is-danger', !!options.danger)
                .text(options.confirmLabel || (options.danger ? (strings.delete || 'Delete') : (strings.confirm || 'Confirm')))
                .appendTo($actions);

            function close(result) {
                $(document).off('keydown.sfDialog');
                $backdrop.remove();
                if (opener && typeof opener.focus === 'function') {
                    opener.focus();
                }
                resolve(result);
            }

            $cancel.on('click', function() { close(false); });
            $ok.on('click', function() { close(true); });
            $backdrop.on('click', function(event) {
                if (event.target === $backdrop[0]) {
                    close(false);
                }
            });

            $(document).on('keydown.sfDialog', function(event) {
                if (event.key === 'Escape') {
                    event.preventDefault();
                    close(false);
                } else if (event.key === 'Tab') {
                    // Keep focus on the two buttons.
                    event.preventDefault();
                    (document.activeElement === $ok[0] ? $cancel : $ok).trigger('focus');
                }
            });

            $backdrop.append($dialog).appendTo('body');
            // Destructive actions start on Cancel so Enter does not delete.
            (options.danger ? $cancel : $ok).trigger('focus');
        });
    };

    /**
     * Non-blocking message in the toast style, replacing window.alert().
     *
     * @param {string} message
     * @param {string} [type] 'error' (default), 'success' or 'info'.
     */
    window.SF.notify = function(message, type) {
        type = type || 'error';
        // One notice at a time: they share a fixed position, so a second one
        // would cover the first. The session notice stays for its Reload button.
        $('.sf-settings-save-message').not('.is-session').remove();

        var $notice = $('<div class="sf-settings-save-message" role="status"></div>')
            .addClass('is-' + type)
            .text(message);

        if (type === 'error') {
            // Errors stay until dismissed; they are often the only explanation.
            $notice.addClass('is-sticky').attr('role', 'alert');
            $('<button type="button" class="sf-btn sf-btn-secondary sf-btn-sm"></button>')
                .text((window.sfAdmin && window.sfAdmin.strings && window.sfAdmin.strings.dismiss) || 'Dismiss')
                .on('click', function() { $notice.remove(); })
                .appendTo($notice);
        }

        $('body').append($notice);
        window.setTimeout(function() { $notice.addClass('active'); }, 20);

        if (type !== 'error') {
            window.setTimeout(function() { $notice.remove(); }, 3500);
        }
    };

    // Links that delete something: <a href="..." data-sf-confirm="Message">.
    $(document).on('click', 'a[data-sf-confirm]', function(e) {
        var href = this.href;
        e.preventDefault();
        window.SF.confirm($(this).attr('data-sf-confirm'), { danger: true }).then(function(confirmed) {
            if (confirmed) {
                window.location.href = href;
            }
        });
    });

    function showSessionExpired() {
        var strings = (window.sfAdmin && window.sfAdmin.strings) || {};
        var message = strings.sessionExpired || 'Your session has expired. Reload the page and try again.';

        // Replace whatever generic error the screen just showed.
        $('.sf-settings-save-message').remove();
        $('.sf-save-message.active').removeClass('active');

        var $notice = $('<div class="sf-settings-save-message is-error is-sticky is-session" role="alert"></div>');
        $notice.append($('<span></span>').text(message));
        $('<button type="button" class="sf-btn sf-btn-secondary sf-btn-sm"></button>')
            .text(strings.reload || 'Reload')
            .on('click', function() {
                window.location.reload();
            })
            .appendTo($notice);

        $('body').append($notice);
        window.setTimeout(function() {
            $notice.addClass('active');
        }, 20);
    }

    // Expose functions for backward compatibility and external use
    window.SF.generateForm = function(prompt) {
        if (window.SF.AIGenerator && window.SF.AIGenerator.generateFormFromPrompt) {
            window.SF.AIGenerator.generateFormFromPrompt(prompt);
        }
    };
    
    window.SF.generateFormFromPrompt = function(prompt, callback) {
        if (window.SF.AIGenerator && window.SF.AIGenerator.generateFormFromPrompt) {
            return window.SF.AIGenerator.generateFormFromPrompt(prompt, callback);
        }
    };
    
    window.SF.updateFormEditor = function(formData) {
        if (window.SF.AIGenerator && window.SF.AIGenerator.updateFormEditor) {
            return window.SF.AIGenerator.updateFormEditor(formData);
        }
    };
    
    window.SF.saveForm = function() {
        if (window.SF.VisualEditor && window.SF.VisualEditor.saveForm) {
            return window.SF.VisualEditor.saveForm();
        }
    };

})(jQuery); 