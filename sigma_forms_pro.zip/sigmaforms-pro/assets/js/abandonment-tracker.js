/**
 * Form Abandonment Tracker for SigmaForms
 * 
 * Tracks user behavior on forms and saves abandoned form data
 */

(function ($) {
    'use strict';

    // Check if tracking config is available
    if (typeof sfAbandonmentTracker === 'undefined') {
        return;
    }

    var AbandonmentTracker = {
        // Configuration
        settings: sfAbandonmentTracker.settings,
        ajaxUrl: sfAbandonmentTracker.ajaxUrl,
        nonce: sfAbandonmentTracker.nonce,

        // Tracking data
        trackedForms: {},
        saveTimer: null,
        inactivityTimer: null,

        /**
         * Initialize the tracker
         */
        init: function () {
            this.bindEvents();
            this.setupTracking();
        },

        /**
         * Bind necessary events
         */
        bindEvents: function () {
            var self = this;

            // Track form interactions
            $(document).on('focus input change', '.sf-form input, .sf-form textarea, .sf-form select', function () {
                var form = $(this).closest('.sf-form');
                self.onFormInteraction(form);
            });

            // Track form submissions
            $(document).on('submit', '.sf-form', function () {
                var form = $(this);
                self.onFormSubmit(form);
            });

            // Track page visibility changes
            $(document).on('visibilitychange', function () {
                if (document.visibilityState === 'hidden') {
                    self.onPageHidden();
                }
            });

            // Track page beforeunload
            $(window).on('beforeunload', function () {
                self.onPageUnload();
            });

            // Track inactivity
            $(document).on('mousemove keypress scroll', function () {
                self.resetInactivityTimer();
            });
        },

        /**
         * Setup initial tracking for all forms
         */
        setupTracking: function () {
            var self = this;

            $('.sf-form').each(function () {
                var form = $(this);
                var formId = self.getFormId(form);

                // Only forms with "Store Abandoned Forms" on. Tracking the others
                // sent a save request every few seconds that the server rejected.
                if (formId && String(form.attr('data-store-abandoned')) === '1') {
                    self.initializeFormTracking(form, formId);
                }
            });
        },

        /**
         * Initialize tracking for a specific form
         */
        initializeFormTracking: function (form, formId) {
            var sessionId = this.generateSessionId();

            this.trackedForms[formId] = {
                element: form,
                sessionId: sessionId,
                startTime: new Date(),
                lastActivity: new Date(),
                hasInteracted: false,
                fieldValues: {},
                saveScheduled: false
            };

            // Store session ID for recovery
            sessionStorage.setItem('sf_session_' + formId, sessionId);

            // Set session ID in the form's hidden field
            var sessionField = form.find('#sigmaform-session-id-' + formId);
            if (sessionField.length) {
                sessionField.val(sessionId);
            }

        },

        /**
         * Handle form interaction
         */
        onFormInteraction: function (form) {
            var formId = this.getFormId(form);

            if (!formId || !this.trackedForms[formId]) {
                return;
            }

            var tracking = this.trackedForms[formId];
            tracking.hasInteracted = true;
            tracking.lastActivity = new Date();

            // Collect current field values
            this.collectFieldValues(form, formId);

            // Debug logging for first interaction
            if (!tracking.firstInteractionLogged) {
                tracking.firstInteractionLogged = true;
            }

            // Schedule save if not already scheduled
            this.scheduleSave(formId);

            // Reset inactivity timer
            this.resetInactivityTimer();
        },

        /**
         * Handle form submission
         */
        onFormSubmit: function (form) {
            var formId = this.getFormId(form);

            if (!formId || !this.trackedForms[formId]) {
                return;
            }

            var tracking = this.trackedForms[formId];

            // Mark as converted
            this.markAsConverted(tracking.sessionId, formId);

            // Clean up tracking
            delete this.trackedForms[formId];
            sessionStorage.removeItem('sf_session_' + formId);
        },

        /**
         * Handle page hidden (tab switch, minimize, etc.)
         */
        onPageHidden: function () {
            this.saveAllProgress('page_hidden');
        },

        /**
         * Handle page unload
         */
        onPageUnload: function () {
            this.saveAllProgress('page_unload');
        },

        /**
         * Handle inactivity timeout
         */
        onInactivityTimeout: function () {
            this.saveAllProgress('timeout');
        },

        /**
         * Collect field values from form
         */
        collectFieldValues: function (form, formId) {
            var tracking = this.trackedForms[formId];
            var fieldValues = {};

            form.find('input, textarea, select').each(function () {
                var field = $(this);
                var fieldId = field.data('field-id') || field.attr('id');
                var fieldType = field.attr('type');

                // Skip if no field ID
                if (!fieldId) {
                    return;
                }

                // Skip file inputs and password fields for security and size reasons
                if (fieldType === 'file' || fieldType === 'password') {
                    return;
                }

                // Skip session ID fields
                if (fieldId.indexOf('sigmaform-session-id-') === 0) {
                    return;
                }

                var value = field.val();

                // Handle different field types
                if (field.is(':checkbox')) {
                    value = field.is(':checked') ? value : '';
                } else if (field.is(':radio')) {
                    if (field.is(':checked')) {
                        value = field.val();
                    } else {
                        return; // Skip unchecked radio buttons
                    }
                }

                fieldValues[fieldId] = value;
            });

            tracking.fieldValues = fieldValues;
        },

        /**
         * Schedule save operation
         */
        scheduleSave: function (formId) {
            var self = this;
            var tracking = this.trackedForms[formId];

            if (tracking.saveScheduled) {
                return;
            }

            tracking.saveScheduled = true;

            // Clear existing timer
            if (this.saveTimer) {
                clearTimeout(this.saveTimer);
            }

            // Schedule save
            this.saveTimer = setTimeout(function () {
                self.saveProgress(formId);
                tracking.saveScheduled = false;
            }, this.settings.saveInterval * 1000);
        },

        /**
         * Save progress for a specific form
         */
        saveProgress: function (formId, abandonmentType) {
            var tracking = this.trackedForms[formId];

            if (!tracking || !tracking.hasInteracted) {
                return;
            }

            // Check minimum fields requirement
            var filledFieldsCount = Object.keys(tracking.fieldValues).length;
            if (filledFieldsCount < this.settings.minFieldsRequired) {
                return;
            }

            abandonmentType = abandonmentType || 'auto_save';

            var data = {
                form_id: formId,
                session_id: tracking.sessionId,
                field_values: tracking.fieldValues,
                abandonment_type: abandonmentType
            };

            // Send data to server
            this.sendToServer('abandoned/save', data);
        },

        /**
         * Save progress for all tracked forms
         */
        saveAllProgress: function (abandonmentType) {
            for (var formId in this.trackedForms) {
                this.saveProgress(formId, abandonmentType);
            }
        },

        /**
         * Mark abandoned form as converted
         */
        markAsConverted: function (sessionId, formId) {
            var data = {
                session_id: sessionId,
                form_id: formId
            };

            this.sendToServer('abandoned/convert', data);
        },

        /**
         * Send data to server
         */
        sendToServer: function (endpoint, data) {
            var self = this;
            var url = this.ajaxUrl + endpoint;

            // Use sendBeacon for better reliability during page unload
            if (navigator.sendBeacon && (endpoint.includes('convert') || data.abandonment_type !== 'auto_save')) {
                var formData = new FormData();
                if (this.nonce) {
                    formData.append('_wpnonce', this.nonce);
                }

                for (var key in data) {
                    if (typeof data[key] === 'object') {
                        formData.append(key, JSON.stringify(data[key]));
                    } else {
                        formData.append(key, data[key]);
                    }
                }

                return navigator.sendBeacon(url, formData);
            } else {
                // Use fetch API for better performance
                if (window.fetch) {
                    var fetchHeaders = { 'Content-Type': 'application/json' };
                    if (this.nonce) {
                        fetchHeaders['X-WP-Nonce'] = this.nonce;
                    }
                    var fetchData = {
                        method: 'POST',
                        headers: fetchHeaders,
                        body: JSON.stringify(data)
                    };

                    // Don't wait for response during page unload
                    if (data.abandonment_type === 'page_unload' || data.abandonment_type === 'page_hidden') {
                        fetch(url, fetchData).catch(function () {
                            // Ignore errors during page unload
                        });
                    } else {
                        return fetch(url, fetchData)
                            .then(function (response) {
                                return response.json();
                            })
                            .catch(function (error) {
                            });
                    }
                } else {
                    // Fallback to jQuery AJAX (asynchronous)
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: data,
                        headers: this.nonce ? { 'X-WP-Nonce': this.nonce } : {},
                        async: true, // Always async to prevent blocking
                        timeout: 5000, // 5 second timeout
                        success: function (response) {
                            // Handle success silently for auto-save
                        },
                        error: function (xhr, status, error) {
                            if (data.abandonment_type === 'auto_save') {
                            }
                        }
                    });
                }
            }
        },

        /**
         * Reset inactivity timer
         */
        resetInactivityTimer: function () {
            var self = this;

            if (this.inactivityTimer) {
                clearTimeout(this.inactivityTimer);
            }

            this.inactivityTimer = setTimeout(function () {
                self.onInactivityTimeout();
            }, this.settings.inactivityTimeout * 1000);
        },

        /**
         * Generate unique session ID
         */
        generateSessionId: function () {
            return 'sf_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        },

        /**
         * Extract form ID from form element
         */
        getFormId: function (form) {
            var formId = form.attr('id');

            if (formId && formId.startsWith('sf-form-')) {
                return parseInt(formId.replace('sf-form-', ''), 10);
            }

            // Fallback: look for data attribute
            var dataFormId = form.data('form-id');
            if (dataFormId) {
                return parseInt(dataFormId, 10);
            }

            return null;
        }
    };

    // Initialize when document is ready
    $(document).ready(function () {
        AbandonmentTracker.init();
    });

})(jQuery); 