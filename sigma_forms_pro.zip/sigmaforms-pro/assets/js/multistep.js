/**
 * Multi-Step Form Navigation
 * 
 * @package SigmaForms
 */
(function($) {
    'use strict';

    // Immediately hide field containers if page breaks are present (prevent FOUC)
    $('.sf-form').each(function() {
        const $form = $(this);
        if ($form.find('.sf-page-break').length > 0) {
            $form.addClass('sf-multistep-loading');
        }
    });

    $(document).ready(function() {
        initializeMultiStepForms();
    });

    function initializeMultiStepForms() {
        $('.sf-form').each(function() {
            const $form = $(this);
            
            // Check if already initialized
            if ($form.hasClass('sf-multistep-initialized')) {
                return;
            }
            
            const $pageBreaks = $form.find('.sf-page-break');
            
            if ($pageBreaks.length === 0) {
                return; // Not a multi-step form
            }

            // Mark as initialized
            $form.addClass('sf-multistep-initialized');

            const $submitButton = $form.find('.sf-submit-button').first();
            const $fieldsWrapper = $form.find('.sf-form-fields-wrapper').first();
            const $allFieldContainers = [];
            
            // Collect all field containers in order and store page break settings
            const pageBreakSettings = [];
            $fieldsWrapper.children('.sf-field-container').each(function() {
                const $field = $(this);
                $allFieldContainers.push($field);
                
                // Store page break settings for later use
                if ($field.find('.sf-page-break').length > 0) {
                    const $pageBreak = $field.find('.sf-page-break');
                    pageBreakSettings.push({
                        nextText: $pageBreak.data('next-text') || 'Next',
                        prevText: $pageBreak.data('prev-text') || 'Previous',
                        stepFormat: $pageBreak.data('step-format') || 'Step {current} of {total}',
                        nextBgColor: $pageBreak.data('next-bg-color') || '#6366f1',
                        nextTextColor: $pageBreak.data('next-text-color') || '#ffffff',
                        prevBgColor: $pageBreak.data('prev-bg-color') || '#ffffff',
                        prevTextColor: $pageBreak.data('prev-text-color') || '#374151',
                        stepTextColor: $pageBreak.data('step-text-color') || '#6b7280',
                        validationMessage: $pageBreak.data('validation-message') || 'Please fill in all required fields before proceeding.'
                    });
                }
            });
            
            let steps = [];
            let currentStepFields = [];
            let currentPageBreakIndex = 0;
            
            // Group fields by page breaks
            $allFieldContainers.forEach(function($field) {
                if ($field.find('.sf-page-break').length > 0) {
                    // This is a page break
                    if (currentStepFields.length > 0) {
                        steps.push({
                            fields: currentStepFields,
                            settings: pageBreakSettings[currentPageBreakIndex] || {
                                nextText: 'Next',
                                prevText: 'Previous',
                                stepFormat: 'Step {current} of {total}',
                                nextBgColor: '#6366f1',
                                nextTextColor: '#ffffff',
                                prevBgColor: '#ffffff',
                                prevTextColor: '#374151',
                                stepTextColor: '#6b7280',
                                validationMessage: 'Please fill in all required fields before proceeding.'
                            }
                        });
                        currentStepFields = [];
                        currentPageBreakIndex++;
                    }
                    // Remove the page break container
                    $field.remove();
                } else {
                    currentStepFields.push($field);
                }
            });
            
            // Add last step if it has fields (use the last page break settings if available)
            if (currentStepFields.length > 0) {
                steps.push({
                    fields: currentStepFields,
                    settings: pageBreakSettings[currentPageBreakIndex - 1] || pageBreakSettings[pageBreakSettings.length - 1] || {
                        nextText: 'Next',
                        prevText: 'Previous',
                        stepFormat: 'Step {current} of {total}',
                        nextBgColor: '#6366f1',
                        nextTextColor: '#ffffff',
                        prevBgColor: '#ffffff',
                        prevTextColor: '#374151',
                        stepTextColor: '#6b7280',
                        validationMessage: 'Please fill in all required fields before proceeding.'
                    }
                });
            }

            const totalSteps = steps.length;
            
            if (totalSteps <= 1) {
                // A page break with no fields after it (it is added at the end
                // of the form) leaves one step: show the form as a single page.
                // Returning with the loading class left every field hidden.
                $form.removeClass('sf-multistep-loading');
                return;
            }

            // Get submit button container and CAPTCHA container
            const $submitButtonContainer = $form.find('.sf-form-actions').first();
            const $captchaContainer = $form.find('.sf-captcha-container').first();

            // Create step containers and wrap fields
            for (let i = 0; i < steps.length; i++) {
                const step = steps[i];
                const stepFields = step.fields;
                const stepSettings = step.settings;
                const validationMessage = stepSettings.validationMessage || 'Please fill in all required fields before proceeding.';
                const $stepContainer = $('<div class="sf-form-step" data-step="' + i + '" data-validation-message="' + $('<div>').text(validationMessage).html() + '"></div>');

                // Progress bar - hidden by default, themes opt in via CSS
                const stepPercent = Math.round(((i + 1) / totalSteps) * 100);
                $stepContainer.append(
                    '<div class="sf-step-progress-bar" style="--sf-step-progress: ' + stepPercent + '%;" data-progress="' + stepPercent + '" role="progressbar" aria-valuenow="' + stepPercent + '" aria-valuemin="0" aria-valuemax="100">' +
                    '<span class="sf-step-progress-label">' + stepPercent + '%</span>' +
                    '<span class="sf-step-progress-fill"></span>' +
                    '</div>'
                );

                // Append fields to step container
                for (let j = 0; j < stepFields.length; j++) {
                    $stepContainer.append(stepFields[j]);
                }
                
                // On last step, add CAPTCHA and submit button before navigation
                if (i === totalSteps - 1) {
                    if ($captchaContainer.length > 0) {
                        $stepContainer.append($captchaContainer);
                    }
                    $stepContainer.append($submitButtonContainer);
                }
                
                // Add navigation buttons with step indicator in the middle
                const $navigation = $('<div class="sf-step-navigation"></div>');
                
                if (i > 0) {
                    const prevText = stepSettings.prevText || 'Previous';
                    const prevBgColor = stepSettings.prevBgColor || '#ffffff';
                    const prevTextColor = stepSettings.prevTextColor || '#374151';
                    $navigation.append('<button type="button" class="sf-prev-step-btn" style="background-color: ' + prevBgColor + '; color: ' + prevTextColor + ';">' + prevText + '</button>');
                }
                
                // Add step indicator in the middle with custom format
                const stepFormat = stepSettings.stepFormat || 'Step {current} of {total}';
                const stepTextColor = stepSettings.stepTextColor || '#6b7280';
                const stepIndicatorText = stepFormat.replace('{current}', '<span class="sf-step-number">' + (i + 1) + '</span>').replace('{total}', totalSteps);
                $navigation.append('<div class="sf-step-progress"><span class="sf-step-indicator" style="color: ' + stepTextColor + ';">' + stepIndicatorText + '</span></div>');
                
                if (i < totalSteps - 1) {
                    const nextText = stepSettings.nextText || 'Next';
                    const nextBgColor = stepSettings.nextBgColor || '#6366f1';
                    const nextTextColor = stepSettings.nextTextColor || '#ffffff';
                    $navigation.append('<button type="button" class="sf-next-step-btn" style="background: ' + nextBgColor + '; color: ' + nextTextColor + ';">' + nextText + '</button>');
                }
                
                $stepContainer.append($navigation);
                
                // Append step container to fields wrapper
                $fieldsWrapper.append($stepContainer);
            }

            // Show only first step initially
            $form.find('.sf-form-step').removeClass('active').first().addClass('active');

            // Remove loading class to show the form
            $form.removeClass('sf-multistep-loading');

            // Handle next button clicks
            $form.on('click', '.sf-next-step-btn', function(e) {
                e.preventDefault();
                const $currentStep = $form.find('.sf-form-step.active');
                const currentStepIndex = parseInt($currentStep.data('step'));
                
                // Validate current step before proceeding
                if (!validateStep($currentStep)) {
                    return false;
                }

                $currentStep.removeClass('active');
                const $nextStep = $form.find('.sf-form-step[data-step="' + (currentStepIndex + 1) + '"]');
                $nextStep.addClass('active');

                scrollToStep($nextStep);
            });

            // Handle previous button clicks
            $form.on('click', '.sf-prev-step-btn', function(e) {
                e.preventDefault();
                const $currentStep = $form.find('.sf-form-step.active');
                const currentStepIndex = parseInt($currentStep.data('step'));
                
                $currentStep.removeClass('active');
                const $prevStep = $form.find('.sf-form-step[data-step="' + (currentStepIndex - 1) + '"]');
                $prevStep.addClass('active');

                scrollToStep($prevStep);
            });
        });
    }

    /**
     * Bring the top of a newly shown step into view.
     *
     * Steps swap in place, so after a long step the viewport can be left partway
     * down the next one. Scroll back to the start of the new step, clearing any
     * fixed admin bar or sticky theme header that would otherwise cover it.
     *
     * @param {jQuery} $step The step that just became active.
     */
    function scrollToStep($step) {
        if (!$step || !$step.length) {
            return;
        }

        let offset = 20;

        const $adminBar = $('#wpadminbar');
        if ($adminBar.length && $adminBar.css('position') === 'fixed') {
            offset += $adminBar.outerHeight();
        }

        const target = Math.max(0, Math.round($step.offset().top - offset));

        // Already there - do not fight the user's scroll position
        if (Math.abs(window.pageYOffset - target) < 4) {
            return;
        }

        const reduceMotion = window.matchMedia
            && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        const before = window.pageYOffset;

        try {
            window.scrollTo({ top: target, behavior: reduceMotion ? 'auto' : 'smooth' });
        } catch (error) {
            // Older browsers reject the options object
            window.scrollTo(0, target);
            return;
        }

        // Some environments accept the smooth option but never actually scroll.
        // If nothing has moved at all by now, jump. The equality check means a
        // user who scrolled manually in the meantime is left alone.
        window.setTimeout(function () {
            if (window.pageYOffset === before && Math.abs(before - target) > 8) {
                window.scrollTo(0, target);
            }
        }, 600);
    }

    function validateStep($step) {
        const $errorFields = [];
        const seenRadioGroups = {};

        // Same rules as validateForm() in frontend.js: fields hidden by
        // conditional logic are disabled and skipped.
        $step.find('input[required]:not(:disabled), textarea[required]:not(:disabled), select[required]:not(:disabled)').each(function() {
            const $field = $(this);
            const type = ($field.attr('type') || '').toLowerCase();
            let empty;

            if (type === 'radio') {
                // .val() returns the option value even when nothing is
                // picked, so check the group instead.
                if (seenRadioGroups[this.name]) {
                    return;
                }
                seenRadioGroups[this.name] = true;
                const name = this.name;
                const $group = $step.find('input[type="radio"]').filter(function() {
                    return this.name === name;
                });
                empty = $group.filter(':checked').length === 0;
                $group.toggleClass('sf-error', empty);
            } else if (type === 'checkbox') {
                empty = !$field.is(':checked');
                $field.toggleClass('sf-error', empty);
            } else {
                const value = $field.val();
                empty = Array.isArray(value) ? value.length === 0 : !value || String(value).trim() === '';
                $field.toggleClass('sf-error', empty);
            }

            if (empty) {
                $errorFields.push($field);
            }
        });

        // Required checkbox groups carry a hidden "<name>_required" marker.
        const seenCheckboxGroups = {};
        $step.find('input[type="checkbox"][name$="[]"]:not(:disabled)').each(function() {
            const name = this.name;
            if (seenCheckboxGroups[name]) {
                return;
            }
            seenCheckboxGroups[name] = true;
            if (!$step.closest('form').find('input[name="' + name.replace('[]', '_required') + '"]').length) {
                return;
            }
            const $group = $step.find('input[type="checkbox"]').filter(function() {
                return this.name === name;
            });
            const empty = $group.filter(':checked').length === 0;
            $group.toggleClass('sf-error', empty);
            if (empty) {
                $errorFields.push($group.first());
            }
        });

        // Filled-in values the browser rejects (an invalid email or URL, a
        // number out of range). Left for the final step, the browser blocked
        // the submit without a message because the field was on a hidden step.
        let $invalidField = null;
        if (!$errorFields.length) {
            $step.find('input:not(:disabled), textarea:not(:disabled), select:not(:disabled)').each(function() {
                if (this.type !== 'hidden' && this.checkValidity && !this.checkValidity()) {
                    $invalidField = $(this);
                    $invalidField.addClass('sf-error');
                    return false;
                }
            });
            if ($invalidField) {
                $errorFields.push($invalidField);
            }
        }

        const isValid = $errorFields.length === 0;
        let $message = $step.children('.sf-step-error');

        if (!isValid) {
            const strings = (window.sfData && window.sfData.strings) || {};
            const validationMessage = $invalidField
                ? $invalidField[0].validationMessage
                : ($step.data('validation-message') || strings.validation_failed || 'Please fill in all required fields before proceeding.');

            // Shown inline; alert() blocked the page and hid which fields were missing.
            if (!$message.length) {
                $message = $('<div class="sf-message sf-error-message sf-step-error" role="alert"></div>');
                const $navigation = $step.children('.sf-step-navigation');
                if ($navigation.length) {
                    $message.insertBefore($navigation);
                } else {
                    $step.append($message);
                }
            }
            $message.text(validationMessage);
            $errorFields[0].trigger('focus');
        } else {
            $message.remove();
        }

        return isValid;
    }

    // Clear a field's error state as soon as it is answered.
    $(document).on('input change', '.sf-form-step .sf-error', function() {
        const $field = $(this);
        const $step = $field.closest('.sf-form-step');

        if ($field.is(':radio, :checkbox')) {
            const name = this.name;
            $step.find('input').filter(function() {
                return this.name === name;
            }).removeClass('sf-error');
        } else {
            $field.removeClass('sf-error');
        }

        if (!$step.find('.sf-error').length) {
            $step.children('.sf-step-error').remove();
        }
    });

})(jQuery);
