/**
 * SigmaForms - Settings Module
 */

(function ($) {
    'use strict';

    // Ensure SF namespace exists
    window.SF = window.SF || {};
    window.SF.Settings = {};

    /**
     * Initialize settings page
     */
    function initSettingsPage() {
        const $settingsPage = $('.sf-settings-page');

        if ($settingsPage.length === 0) {
            return;
        }

        // Tab navigation functionality
        $('.sf-settings-tabs-nav a').on('click', function (e) {
            e.preventDefault();
            const $this = $(this);
            const tabId = $this.attr('href');
            const tabName = $this.data('tab');

            // Update active states
            $('.sf-settings-tabs-nav a').removeClass('active');
            $('.sf-tab-content').removeClass('active');
            $this.addClass('active');
            $(tabId).addClass('active');

            // Update URL with tab parameter
            if (history.pushState && tabName) {
                const url = new URL(window.location);
                url.searchParams.set('tab', tabName);
                url.hash = '';
                window.history.pushState({ path: url.href }, '', url.href);
            }
        });

        // Handle theme selection
        $('input[name="form_theme"]').on('change', function () {
            var selectedTheme = $(this).val();

            // Update active class on theme options
            $('.sf-theme-option').removeClass('active');
            $(this).closest('.sf-theme-option').addClass('active');

            // Show/hide custom styling section
            if (selectedTheme === 'custom') {
                $('#sf-custom-styling').addClass('active');
            } else {
                $('#sf-custom-styling').removeClass('active');
            }
        });

        // Check for hash in URL to activate correct tab
        if (window.location.hash) {
            const hash = window.location.hash.substring(1);
            const $tabLink = $('.sf-settings-tabs-nav a[data-tab="' + hash + '"]');

            if ($tabLink.length) {
                $tabLink.trigger('click');
            }
        }

        // Link color inputs functionality
        $('.sf-color-field').each(function () {
            const $colorPicker = $(this).find('input[type="color"]');
            const $textInput = $(this).find('input[type="text"]');

            $colorPicker.on('input', function () {
                $textInput.val($(this).val());
            });

            $textInput.on('input', function () {
                $colorPicker.val($(this).val());
            });
        });

        // Add smooth scroll animation when clicking submit button
        $('.sf-settings-form').on('submit', function (e) {
            e.preventDefault();
            saveSettings();
        });

        // Initialize SMTP toggle functionality
        initSMTPToggle();
        initPasswordToggles();
        initSMTPTest();
        initRecaptchaToggle();
        initCaptchaToggles();
        initCloudStorageToggles();
        initCloudStorageConnections();
        initGoogleOAuthModeToggle();
    }

    /**
     * Save settings via AJAX
     */
    function saveSettings() {
        const $form = $('#sf-settings-form');
        const $saveButton = $('#sf-save-settings-btn');
        // Keep the button's own markup (icon included) to restore afterwards.
        const saveButtonHtml = $saveButton.html();

        // Disable button and show loading state
        $saveButton.prop('disabled', true).html('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> ' + (sf_settings.saving_text || 'Saving...'));

        // Collect form data
        const formData = new FormData($form[0]);
        formData.append('action', 'sf_process_settings');
        formData.append('sf_settings_nonce', $form.find('#sf_settings_nonce').val());

        // Send AJAX request
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.success) {
                    // Show success message using the same style as form editor
                    showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg> ' + response.data.message, 'success');
                } else {
                    // Show error message
                    showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || sf_settings.save_error_text), 'error');
                }
            },
            error: function (xhr, status, error) {
                // Show error message
                showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + sf_settings.save_error_text + ' (' + error + ')', 'error');
            },
            complete: function () {
                // Reset button state
                $saveButton.prop('disabled', false).html(saveButtonHtml);
            }
        });
    }

    /**
     * Show settings message using the same style as form editor
     */
    function showSettingsMessage(message, type) {
        // Remove any existing message
        $('.sf-settings-save-message').remove();

        // Create message element
        const $message = $('<div class="sf-settings-save-message"></div>');
        // Carry the message type so errors are not styled as successes.
        $message.addClass('is-' + (type || 'success'));
        $message.html(message);

        // Add to body
        $('body').append($message);

        // Show message
        setTimeout(function () {
            $message.addClass('active');
        }, 100);

        // Auto-hide after 3 seconds
        setTimeout(function () {
            $message.removeClass('active');
            setTimeout(function () {
                $message.remove();
            }, 300);
        }, 3000);
    }

    // Initialize SMTP toggle functionality
    function initSMTPToggle() {
        const $smtpToggle = $('#smtp_enabled');
        const $smtpSettings = $('#smtp-settings');

        $smtpToggle.on('change', function () {
            $smtpSettings.toggle(this.checked);
        });
    }

    // Initialize password toggle buttons
    function initPasswordToggles() {
        // Unbind previous handlers to prevent double binding
        $('.sf-api-key-toggle').off('click').on('click', function (e) {
            e.preventDefault();
            const $button = $(this);
            const $wrapper = $button.closest('.sf-input-wrapper');
            // Find the input regardless of type (password or text)
            const $input = $wrapper.find('input');
            // Toggle input type
            const isPassword = $input.attr('type') === 'password';
            $input.attr('type', isPassword ? 'text' : 'password');
            // Update button text
            $button.text(isPassword ? sf_settings.hide_text : sf_settings.show_text);
        });
    }

    // Initialize SMTP test functionality
    function initSMTPTest() {
        // Unbind any previous click handlers to prevent multiple AJAX calls
        $('#test_smtp').off('click').on('click', function () {
            const $button = $(this);
            const $result = $('#smtp-test-result');

            // Disable button and show loading state
            $button.prop('disabled', true).text(sf_settings.testing_text);
            $result.hide();

            // Get current SMTP settings from form
            const smtpData = {
                action: 'sf_test_smtp',
                nonce: sf_settings.test_smtp_nonce,
                smtp_enabled: $('#smtp_enabled').is(':checked'),
                smtp_host: $('#smtp_host').val(),
                smtp_port: $('#smtp_port').val(),
                smtp_encryption: $('#smtp_encryption').val(),
                smtp_username: $('#smtp_username').val(),
                smtp_password: $('#smtp_password').val()
            };

            // Send AJAX request
            $.post(ajaxurl, smtpData, function (response) {
                if (response.success) {
                    $result.removeClass('error').addClass('success').html(response.data.message).show();
                } else {
                    $result.removeClass('success').addClass('error').html(response.data.message).show();
                }
            }).fail(function (xhr, status, error) {
                $result.removeClass('success').addClass('error').html(sf_settings.test_error_text + ' (' + error + ')').show();
            }).always(function () {
                $button.prop('disabled', false).text(sf_settings.test_text);
                setTimeout(() => {
                    $result.hide();
                }, 3000);
            });
        });
    }

    // Initialize reCAPTCHA toggle functionality
    function initRecaptchaToggle() {
        const $recaptchaToggle = $('#recaptcha_enabled');
        const $recaptchaSettings = $('#recaptcha-settings');

        $recaptchaToggle.on('change', function () {
            $recaptchaSettings.toggle(this.checked);
        });
    }

    // Initialize CAPTCHA toggle functionality
    function initCaptchaToggles() {
        // reCAPTCHA
        const $recaptchaToggle = $('#recaptcha_enabled');
        const $recaptchaSettings = $('#recaptcha-settings');

        $recaptchaToggle.on('change', function () {
            $recaptchaSettings.toggle(this.checked);
        });

        // reCAPTCHA v3 toggle
        const $recaptchaV3Toggle = $('#recaptcha_use_v3');
        const $recaptchaV3ScoreField = $('#recaptcha-v3-score-field');

        $recaptchaV3Toggle.on('change', function () {
            $recaptchaV3ScoreField.toggle(this.checked);
        });

        // hCaptcha
        const $hcaptchaToggle = $('#hcaptcha_enabled');
        const $hcaptchaSettings = $('#hcaptcha-settings');

        $hcaptchaToggle.on('change', function () {
            $hcaptchaSettings.toggle(this.checked);
        });

        // Turnstile
        const $turnstileToggle = $('#turnstile_enabled');
        const $turnstileSettings = $('#turnstile-settings');

        $turnstileToggle.on('change', function () {
            $turnstileSettings.toggle(this.checked);
        });

        // CleanTalk
        const $cleantalkToggle = $('#cleantalk_enabled');
        const $cleantalkSettings = $('#cleantalk-settings');

        $cleantalkToggle.on('change', function () {
            $cleantalkSettings.toggle(this.checked);
        });

        // mTCaptcha
        const $mtcaptchaToggle = $('#mtcaptcha_enabled');
        const $mtcaptchaSettings = $('#mtcaptcha-settings');

        $mtcaptchaToggle.on('change', function () {
            $mtcaptchaSettings.toggle(this.checked);
        });
    }

    // Initialize Cloud Storage toggle functionality
    function initCloudStorageToggles() {
        // Google Drive toggle
        const $googleDriveToggle = $('input[name="storage_google_drive_enabled"]');
        const $googleDriveConnection = $('#google-drive-connection');

        $googleDriveToggle.on('change', function () {
            $googleDriveConnection.toggle(this.checked);
        });

        // OneDrive toggle
        const $oneDriveToggle = $('input[name="storage_onedrive_enabled"]');
        const $oneDriveConnection = $('#onedrive-connection');

        $oneDriveToggle.on('change', function () {
            $oneDriveConnection.toggle(this.checked);
        });
    }

    // Initialize Cloud Storage connection handlers
    function initCloudStorageConnections() {
        // Check if sf_settings is defined
        if (typeof sf_settings === 'undefined') {
            console.error('SigmaForms: sf_settings is not defined. Cloud storage connections may not work.');
            return;
        }

        // Google Drive connection
        $('.sf-connect-google-drive').on('click', function (e) {
            e.preventDefault();
            const $button = $(this);

            // Disable button and show loading state
            $button.prop('disabled', true).html('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> Connecting...');

            // Send AJAX request to initiate OAuth
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'sf_connect_google_drive',
                    nonce: sf_settings.storage_nonce || ''
                },
                success: function (response) {
                    if (response.success && response.data.auth_url) {
                        // Redirect to Google OAuth
                        window.location.href = response.data.auth_url;
                    } else {
                        showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || 'Failed to initiate Google Drive connection'), 'error');
                        $button.prop('disabled', false).html('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 8h4"/><path d="M16 8v4a4 4 0 1 1-1.2-2.9"/></svg> Sign in with Google');
                    }
                },
                error: function () {
                    showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> Connection failed. Please try again.', 'error');
                    $button.prop('disabled', false).html('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 8h4"/><path d="M16 8v4a4 4 0 1 1-1.2-2.9"/></svg> Sign in with Google');
                }
            });
        });

        // Google Drive disconnection
        $('.sf-disconnect-google-drive').on('click', function (e) {
            e.preventDefault();

            const $button = $(this);

            window.SF.confirm(window.SF.t('confirmDisconnectGoogleDrive', 'Are you sure you want to disconnect Google Drive? This will remove access to your Google Drive account.'), { danger: true, confirmLabel: window.SF.t('disconnect', 'Disconnect') }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }

                // Disable button and show loading state
                $button.prop('disabled', true).html('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> Disconnecting...');

                // Send AJAX request to disconnect
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_disconnect_google_drive',
                        nonce: sf_settings.storage_nonce || ''
                    },
                    success: function (response) {
                        if (response.success) {
                            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg> Google Drive disconnected successfully', 'success');
                            // Reload page to update UI
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || 'Failed to disconnect Google Drive'), 'error');
                            $button.prop('disabled', false).html('Disconnect');
                        }
                    },
                    error: function () {
                        showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> Disconnection failed. Please try again.', 'error');
                        $button.prop('disabled', false).html('Disconnect');
                    }
                });
            });
        });

        // OneDrive connection
        $('.sf-connect-onedrive').on('click', function (e) {
            e.preventDefault();
            const $button = $(this);

            // Disable button and show loading state
            $button.prop('disabled', true).html('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> Connecting...');

            // Send AJAX request to initiate OAuth
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'sf_connect_onedrive',
                    nonce: sf_settings.storage_nonce || ''
                },
                success: function (response) {
                    if (response.success && response.data.auth_url) {
                        // Redirect to OneDrive OAuth
                        window.location.href = response.data.auth_url;
                    } else {
                        showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || 'Failed to initiate OneDrive connection'), 'error');
                        $button.prop('disabled', false).html('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 4h7v7H4z"/><path d="M13 4h7v7h-7z"/><path d="M4 13h7v7H4z"/><path d="M13 13h7v7h-7z"/></svg> Sign in with Microsoft');
                    }
                },
                error: function () {
                    showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> Connection failed. Please try again.', 'error');
                    $button.prop('disabled', false).html('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 4h7v7H4z"/><path d="M13 4h7v7h-7z"/><path d="M4 13h7v7H4z"/><path d="M13 13h7v7h-7z"/></svg> Sign in with Microsoft');
                }
            });
        });

        // OneDrive disconnection
        $('.sf-disconnect-onedrive').on('click', function (e) {
            e.preventDefault();

            const $button = $(this);

            window.SF.confirm(window.SF.t('confirmDisconnectOneDrive', 'Are you sure you want to disconnect OneDrive? This will remove access to your OneDrive account.'), { danger: true, confirmLabel: window.SF.t('disconnect', 'Disconnect') }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }

                // Disable button and show loading state
                $button.prop('disabled', true).html('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> Disconnecting...');

                // Send AJAX request to disconnect
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_disconnect_onedrive',
                        nonce: sf_settings.storage_nonce || ''
                    },
                    success: function (response) {
                        if (response.success) {
                            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg> OneDrive disconnected successfully', 'success');
                            // Reload page to update UI
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || 'Failed to disconnect OneDrive'), 'error');
                            $button.prop('disabled', false).html('Disconnect');
                        }
                    },
                    error: function () {
                        showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> Disconnection failed. Please try again.', 'error');
                        $button.prop('disabled', false).html('Disconnect');
                    }
                });
            });
        });
    }

    /**
     * Initialize Google OAuth mode toggle
     */
    function initGoogleOAuthModeToggle() {
        const $modeSelect = $('#google_oauth_mode');
        const $customCredentials = $('#google-custom-credentials');

        // Handle mode change
        $modeSelect.on('change', function () {
            const mode = $(this).val();

            if (mode === 'custom') {
                $customCredentials.slideDown(300);
            } else {
                $customCredentials.slideUp(300);
            }

            // Show info message
            if (mode === 'custom') {
                showSettingsMessage(
                    '<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg> Custom Mode requires your own Google OAuth credentials. Make sure to save settings after entering your credentials.',
                    'info'
                );
            }
        });
    }

    /**
     * Initialize folder structure selection toggles
     */
    function initFolderStructureToggles() {
        // Google Drive folder structure
        $('#storage_google_drive_folder_structure').on('change', function () {
            const structure = $(this).val();
            const $customFolder = $('.sf-google-custom-folder');

            if (structure === 'custom') {
                $customFolder.slideDown(300);
            } else {
                $customFolder.slideUp(300);
            }
        });

        // OneDrive folder structure
        $('#storage_onedrive_folder_structure').on('change', function () {
            const structure = $(this).val();
            const $customFolder = $('.sf-onedrive-custom-folder');

            if (structure === 'custom') {
                $customFolder.slideDown(300);
            } else {
                $customFolder.slideUp(300);
            }
        });
    }


    // Runs on the first load and after admin-nav.js swaps the page in. The
    // flag on the page element stops a second pass binding every handler
    // twice when this file is itself loaded during that swap.
    function bootSettings() {
        const $page = $('.sf-settings-page');

        if (!$page.length || $page.data('sfSettingsReady')) {
            return;
        }

        $page.data('sfSettingsReady', true);
        initSettingsPage();
        initFolderStructureToggles();
    }

    $(document).ready(bootSettings);
    $(document).on('sf:page-load', bootSettings);

})(jQuery); 