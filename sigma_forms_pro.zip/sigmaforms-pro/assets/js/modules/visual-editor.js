/**
 * SigmaForms - Visual Editor Module
 */

(function ($) {
    'use strict';

    // Ensure SF namespace exists
    window.SF = window.SF || {};
    window.SF.VisualEditor = {};

    // Inline SVG icons, matching the set PageHeader::icon() renders in PHP so
    // the editor chrome does not fall back to the dashicons font.
    const SF_ICON_PATHS = {
        edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
        copy: '<rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
        trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m6 6 1 14h10l1-14"/><path d="M10 11v6"/><path d="M14 11v6"/>',
        check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
        refresh: '<path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-7.5-4"/><path d="M3 12a9 9 0 0 1 9-9 9 9 0 0 1 7.5 4"/><path d="M19.5 3v4H15"/><path d="M4.5 21v-4H9"/>',
        warning: '<path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>'
    };

    function sfIcon(name) {
        const paths = SF_ICON_PATHS[name];

        if (!paths) {
            return '';
        }

        return '<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" ' +
            'stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" ' +
            'aria-hidden="true" focusable="false">' + paths + '</svg>';
    }

    // Country list with flags and phone codes (emoji flags)
    const COUNTRIES_LIST = [
        { code: 'AF', name: 'Afghanistan', flag: '🇦🇫', phoneCode: '+93' },
        { code: 'AL', name: 'Albania', flag: '🇦🇱', phoneCode: '+355' },
        { code: 'DZ', name: 'Algeria', flag: '🇩🇿', phoneCode: '+213' },
        { code: 'AD', name: 'Andorra', flag: '🇦🇩', phoneCode: '+376' },
        { code: 'AO', name: 'Angola', flag: '🇦🇴', phoneCode: '+244' },
        { code: 'AG', name: 'Antigua and Barbuda', flag: '🇦🇬', phoneCode: '+1-268' },
        { code: 'AR', name: 'Argentina', flag: '🇦🇷', phoneCode: '+54' },
        { code: 'AM', name: 'Armenia', flag: '🇦🇲', phoneCode: '+374' },
        { code: 'AU', name: 'Australia', flag: '🇦🇺', phoneCode: '+61' },
        { code: 'AT', name: 'Austria', flag: '🇦🇹', phoneCode: '+43' },
        { code: 'AZ', name: 'Azerbaijan', flag: '🇦🇿', phoneCode: '+994' },
        { code: 'BS', name: 'Bahamas', flag: '🇧🇸', phoneCode: '+1-242' },
        { code: 'BH', name: 'Bahrain', flag: '🇧🇭', phoneCode: '+973' },
        { code: 'BD', name: 'Bangladesh', flag: '🇧🇩', phoneCode: '+880' },
        { code: 'BB', name: 'Barbados', flag: '🇧🇧', phoneCode: '+1-246' },
        { code: 'BY', name: 'Belarus', flag: '🇧🇾', phoneCode: '+375' },
        { code: 'BE', name: 'Belgium', flag: '🇧🇪', phoneCode: '+32' },
        { code: 'BZ', name: 'Belize', flag: '🇧🇿', phoneCode: '+501' },
        { code: 'BJ', name: 'Benin', flag: '🇧🇯', phoneCode: '+229' },
        { code: 'BT', name: 'Bhutan', flag: '🇧🇹', phoneCode: '+975' },
        { code: 'BO', name: 'Bolivia', flag: '🇧🇴', phoneCode: '+591' },
        { code: 'BA', name: 'Bosnia and Herzegovina', flag: '🇧🇦', phoneCode: '+387' },
        { code: 'BW', name: 'Botswana', flag: '🇧🇼', phoneCode: '+267' },
        { code: 'BR', name: 'Brazil', flag: '🇧🇷', phoneCode: '+55' },
        { code: 'BN', name: 'Brunei', flag: '🇧🇳', phoneCode: '+673' },
        { code: 'BG', name: 'Bulgaria', flag: '🇧🇬', phoneCode: '+359' },
        { code: 'BF', name: 'Burkina Faso', flag: '🇧🇫', phoneCode: '+226' },
        { code: 'BI', name: 'Burundi', flag: '🇧🇮', phoneCode: '+257' },
        { code: 'CV', name: 'Cabo Verde', flag: '🇨🇻', phoneCode: '+238' },
        { code: 'KH', name: 'Cambodia', flag: '🇰🇭', phoneCode: '+855' },
        { code: 'CM', name: 'Cameroon', flag: '🇨🇲', phoneCode: '+237' },
        { code: 'CA', name: 'Canada', flag: '🇨🇦', phoneCode: '+1' },
        { code: 'CF', name: 'Central African Republic', flag: '🇨🇫', phoneCode: '+236' },
        { code: 'TD', name: 'Chad', flag: '🇹🇩', phoneCode: '+235' },
        { code: 'CL', name: 'Chile', flag: '🇨🇱', phoneCode: '+56' },
        { code: 'CN', name: 'China', flag: '🇨🇳', phoneCode: '+86' },
        { code: 'CO', name: 'Colombia', flag: '🇨🇴', phoneCode: '+57' },
        { code: 'KM', name: 'Comoros', flag: '🇰🇲', phoneCode: '+269' },
        { code: 'CG', name: 'Congo', flag: '🇨🇬', phoneCode: '+242' },
        { code: 'CD', name: 'Congo (Democratic Republic)', flag: '🇨🇩', phoneCode: '+243' },
        { code: 'CR', name: 'Costa Rica', flag: '🇨🇷', phoneCode: '+506' },
        { code: 'HR', name: 'Croatia', flag: '🇭🇷', phoneCode: '+385' },
        { code: 'CU', name: 'Cuba', flag: '🇨🇺', phoneCode: '+53' },
        { code: 'CY', name: 'Cyprus', flag: '🇨🇾', phoneCode: '+357' },
        { code: 'CZ', name: 'Czech Republic', flag: '🇨🇿', phoneCode: '+420' },
        { code: 'DK', name: 'Denmark', flag: '🇩🇰', phoneCode: '+45' },
        { code: 'DJ', name: 'Djibouti', flag: '🇩🇯', phoneCode: '+253' },
        { code: 'DM', name: 'Dominica', flag: '🇩🇲', phoneCode: '+1-767' },
        { code: 'DO', name: 'Dominican Republic', flag: '🇩🇴', phoneCode: '+1-809' },
        { code: 'EC', name: 'Ecuador', flag: '🇪🇨', phoneCode: '+593' },
        { code: 'EG', name: 'Egypt', flag: '🇪🇬', phoneCode: '+20' },
        { code: 'SV', name: 'El Salvador', flag: '🇸🇻', phoneCode: '+503' },
        { code: 'GQ', name: 'Equatorial Guinea', flag: '🇬🇶', phoneCode: '+240' },
        { code: 'ER', name: 'Eritrea', flag: '🇪🇷', phoneCode: '+291' },
        { code: 'EE', name: 'Estonia', flag: '🇪🇪', phoneCode: '+372' },
        { code: 'SZ', name: 'Eswatini', flag: '🇸🇿', phoneCode: '+268' },
        { code: 'ET', name: 'Ethiopia', flag: '🇪🇹', phoneCode: '+251' },
        { code: 'FJ', name: 'Fiji', flag: '🇫🇯', phoneCode: '+679' },
        { code: 'FI', name: 'Finland', flag: '🇫🇮', phoneCode: '+358' },
        { code: 'FR', name: 'France', flag: '🇫🇷', phoneCode: '+33' },
        { code: 'GA', name: 'Gabon', flag: '🇬🇦', phoneCode: '+241' },
        { code: 'GM', name: 'Gambia', flag: '🇬🇲', phoneCode: '+220' },
        { code: 'GE', name: 'Georgia', flag: '🇬🇪', phoneCode: '+995' },
        { code: 'DE', name: 'Germany', flag: '🇩🇪', phoneCode: '+49' },
        { code: 'GH', name: 'Ghana', flag: '🇬🇭', phoneCode: '+233' },
        { code: 'GR', name: 'Greece', flag: '🇬🇷', phoneCode: '+30' },
        { code: 'GD', name: 'Grenada', flag: '🇬🇩', phoneCode: '+1-473' },
        { code: 'GT', name: 'Guatemala', flag: '🇬🇹', phoneCode: '+502' },
        { code: 'GN', name: 'Guinea', flag: '🇬🇳', phoneCode: '+224' },
        { code: 'GW', name: 'Guinea-Bissau', flag: '🇬🇼', phoneCode: '+245' },
        { code: 'GY', name: 'Guyana', flag: '🇬🇾', phoneCode: '+592' },
        { code: 'HT', name: 'Haiti', flag: '🇭🇹', phoneCode: '+509' },
        { code: 'HN', name: 'Honduras', flag: '🇭🇳', phoneCode: '+504' },
        { code: 'HK', name: 'Hong Kong', flag: '🇭🇰', phoneCode: '+852' },
        { code: 'HU', name: 'Hungary', flag: '🇭🇺', phoneCode: '+36' },
        { code: 'IS', name: 'Iceland', flag: '🇮🇸', phoneCode: '+354' },
        { code: 'IN', name: 'India', flag: '🇮🇳', phoneCode: '+91' },
        { code: 'ID', name: 'Indonesia', flag: '🇮🇩', phoneCode: '+62' },
        { code: 'IR', name: 'Iran', flag: '🇮🇷', phoneCode: '+98' },
        { code: 'IQ', name: 'Iraq', flag: '🇮🇶', phoneCode: '+964' },
        { code: 'IE', name: 'Ireland', flag: '🇮🇪', phoneCode: '+353' },
        { code: 'IL', name: 'Israel', flag: '🇮🇱', phoneCode: '+972' },
        { code: 'IT', name: 'Italy', flag: '🇮🇹', phoneCode: '+39' },
        { code: 'CI', name: "Côte d'Ivoire", flag: '🇨🇮', phoneCode: '+225' },
        { code: 'JM', name: 'Jamaica', flag: '🇯🇲', phoneCode: '+1-876' },
        { code: 'JP', name: 'Japan', flag: '🇯🇵', phoneCode: '+81' },
        { code: 'JO', name: 'Jordan', flag: '🇯🇴', phoneCode: '+962' },
        { code: 'KZ', name: 'Kazakhstan', flag: '🇰🇿', phoneCode: '+7' },
        { code: 'KE', name: 'Kenya', flag: '🇰🇪', phoneCode: '+254' },
        { code: 'KI', name: 'Kiribati', flag: '🇰🇮', phoneCode: '+686' },
        { code: 'KR', name: 'South Korea', flag: '🇰🇷', phoneCode: '+82' },
        { code: 'KW', name: 'Kuwait', flag: '🇰🇼', phoneCode: '+965' },
        { code: 'KG', name: 'Kyrgyzstan', flag: '🇰🇬', phoneCode: '+996' },
        { code: 'LA', name: 'Laos', flag: '🇱🇦', phoneCode: '+856' },
        { code: 'LV', name: 'Latvia', flag: '🇱🇻', phoneCode: '+371' },
        { code: 'LB', name: 'Lebanon', flag: '🇱🇧', phoneCode: '+961' },
        { code: 'LS', name: 'Lesotho', flag: '🇱🇸', phoneCode: '+266' },
        { code: 'LR', name: 'Liberia', flag: '🇱🇷', phoneCode: '+231' },
        { code: 'LY', name: 'Libya', flag: '🇱🇾', phoneCode: '+218' },
        { code: 'LI', name: 'Liechtenstein', flag: '🇱🇮', phoneCode: '+423' },
        { code: 'LT', name: 'Lithuania', flag: '🇱🇹', phoneCode: '+370' },
        { code: 'LU', name: 'Luxembourg', flag: '🇱🇺', phoneCode: '+352' },
        { code: 'MG', name: 'Madagascar', flag: '🇲🇬', phoneCode: '+261' },
        { code: 'MW', name: 'Malawi', flag: '🇲🇼', phoneCode: '+265' },
        { code: 'MY', name: 'Malaysia', flag: '🇲🇾', phoneCode: '+60' },
        { code: 'MV', name: 'Maldives', flag: '🇲🇻', phoneCode: '+960' },
        { code: 'ML', name: 'Mali', flag: '🇲🇱', phoneCode: '+223' },
        { code: 'MT', name: 'Malta', flag: '🇲🇹', phoneCode: '+356' },
        { code: 'MH', name: 'Marshall Islands', flag: '🇲🇭', phoneCode: '+692' },
        { code: 'MR', name: 'Mauritania', flag: '🇲🇷', phoneCode: '+222' },
        { code: 'MU', name: 'Mauritius', flag: '🇲🇺', phoneCode: '+230' },
        { code: 'MX', name: 'Mexico', flag: '🇲🇽', phoneCode: '+52' },
        { code: 'FM', name: 'Micronesia', flag: '🇫🇲', phoneCode: '+691' },
        { code: 'MD', name: 'Moldova', flag: '🇲🇩', phoneCode: '+373' },
        { code: 'MC', name: 'Monaco', flag: '🇲🇨', phoneCode: '+377' },
        { code: 'MN', name: 'Mongolia', flag: '🇲🇳', phoneCode: '+976' },
        { code: 'ME', name: 'Montenegro', flag: '🇲🇪', phoneCode: '+382' },
        { code: 'MA', name: 'Morocco', flag: '🇲🇦', phoneCode: '+212' },
        { code: 'MZ', name: 'Mozambique', flag: '🇲🇿', phoneCode: '+258' },
        { code: 'MM', name: 'Myanmar', flag: '🇲🇲', phoneCode: '+95' },
        { code: 'NA', name: 'Namibia', flag: '🇳🇦', phoneCode: '+264' },
        { code: 'NR', name: 'Nauru', flag: '🇳🇷', phoneCode: '+674' },
        { code: 'NP', name: 'Nepal', flag: '🇳🇵', phoneCode: '+977' },
        { code: 'NL', name: 'Netherlands', flag: '🇳🇱', phoneCode: '+31' },
        { code: 'NZ', name: 'New Zealand', flag: '🇳🇿', phoneCode: '+64' },
        { code: 'NI', name: 'Nicaragua', flag: '🇳🇮', phoneCode: '+505' },
        { code: 'NE', name: 'Niger', flag: '🇳🇪', phoneCode: '+227' },
        { code: 'NG', name: 'Nigeria', flag: '🇳🇬', phoneCode: '+234' },
        { code: 'NO', name: 'Norway', flag: '🇳🇴', phoneCode: '+47' },
        { code: 'OM', name: 'Oman', flag: '🇴🇲', phoneCode: '+968' },
        { code: 'PK', name: 'Pakistan', flag: '🇵🇰', phoneCode: '+92' },
        { code: 'PW', name: 'Palau', flag: '🇵🇼', phoneCode: '+680' },
        { code: 'PS', name: 'Palestine', flag: '🇵🇸', phoneCode: '+970' },
        { code: 'PA', name: 'Panama', flag: '🇵🇦', phoneCode: '+507' },
        { code: 'PG', name: 'Papua New Guinea', flag: '🇵🇬', phoneCode: '+675' },
        { code: 'PY', name: 'Paraguay', flag: '🇵🇾', phoneCode: '+595' },
        { code: 'PE', name: 'Peru', flag: '🇵🇪', phoneCode: '+51' },
        { code: 'PH', name: 'Philippines', flag: '🇵🇭', phoneCode: '+63' },
        { code: 'PL', name: 'Poland', flag: '🇵🇱', phoneCode: '+48' },
        { code: 'PT', name: 'Portugal', flag: '🇵🇹', phoneCode: '+351' },
        { code: 'QA', name: 'Qatar', flag: '🇶🇦', phoneCode: '+974' },
        { code: 'RO', name: 'Romania', flag: '🇷🇴', phoneCode: '+40' },
        { code: 'RU', name: 'Russia', flag: '🇷🇺', phoneCode: '+7' },
        { code: 'RW', name: 'Rwanda', flag: '🇷🇼', phoneCode: '+250' },
        { code: 'KN', name: 'Saint Kitts and Nevis', flag: '🇰🇳', phoneCode: '+1-869' },
        { code: 'LC', name: 'Saint Lucia', flag: '🇱🇨', phoneCode: '+1-758' },
        { code: 'VC', name: 'Saint Vincent and the Grenadines', flag: '🇻🇨', phoneCode: '+1-784' },
        { code: 'WS', name: 'Samoa', flag: '🇼🇸', phoneCode: '+685' },
        { code: 'SM', name: 'San Marino', flag: '🇸🇲', phoneCode: '+378' },
        { code: 'ST', name: 'Sao Tome and Principe', flag: '🇸🇹', phoneCode: '+239' },
        { code: 'SA', name: 'Saudi Arabia', flag: '🇸🇦', phoneCode: '+966' },
        { code: 'SN', name: 'Senegal', flag: '🇸🇳', phoneCode: '+221' },
        { code: 'RS', name: 'Serbia', flag: '🇷🇸', phoneCode: '+381' },
        { code: 'SC', name: 'Seychelles', flag: '🇸🇨', phoneCode: '+248' },
        { code: 'SL', name: 'Sierra Leone', flag: '🇸🇱', phoneCode: '+232' },
        { code: 'SG', name: 'Singapore', flag: '🇸🇬', phoneCode: '+65' },
        { code: 'SK', name: 'Slovakia', flag: '🇸🇰', phoneCode: '+421' },
        { code: 'SI', name: 'Slovenia', flag: '🇸🇮', phoneCode: '+386' },
        { code: 'SB', name: 'Solomon Islands', flag: '🇸🇧', phoneCode: '+677' },
        { code: 'SO', name: 'Somalia', flag: '🇸🇴', phoneCode: '+252' },
        { code: 'ZA', name: 'South Africa', flag: '🇿🇦', phoneCode: '+27' },
        { code: 'SS', name: 'South Sudan', flag: '🇸🇸', phoneCode: '+211' },
        { code: 'ES', name: 'Spain', flag: '🇪🇸', phoneCode: '+34' },
        { code: 'LK', name: 'Sri Lanka', flag: '🇱🇰', phoneCode: '+94' },
        { code: 'SD', name: 'Sudan', flag: '🇸🇩', phoneCode: '+249' },
        { code: 'SR', name: 'Suriname', flag: '🇸🇷', phoneCode: '+597' },
        { code: 'SE', name: 'Sweden', flag: '🇸🇪', phoneCode: '+46' },
        { code: 'CH', name: 'Switzerland', flag: '🇨🇭', phoneCode: '+41' },
        { code: 'SY', name: 'Syria', flag: '🇸🇾', phoneCode: '+963' },
        { code: 'TW', name: 'Taiwan', flag: '🇹🇼', phoneCode: '+886' },
        { code: 'TJ', name: 'Tajikistan', flag: '🇹🇯', phoneCode: '+992' },
        { code: 'TZ', name: 'Tanzania', flag: '🇹🇿', phoneCode: '+255' },
        { code: 'TH', name: 'Thailand', flag: '🇹🇭', phoneCode: '+66' },
        { code: 'TL', name: 'Timor-Leste', flag: '🇹🇱', phoneCode: '+670' },
        { code: 'TG', name: 'Togo', flag: '🇹🇬', phoneCode: '+228' },
        { code: 'TO', name: 'Tonga', flag: '🇹🇴', phoneCode: '+676' },
        { code: 'TT', name: 'Trinidad and Tobago', flag: '🇹🇹', phoneCode: '+1-868' },
        { code: 'TN', name: 'Tunisia', flag: '🇹🇳', phoneCode: '+216' },
        { code: 'TR', name: 'Turkey', flag: '🇹🇷', phoneCode: '+90' },
        { code: 'TM', name: 'Turkmenistan', flag: '🇹🇲', phoneCode: '+993' },
        { code: 'TV', name: 'Tuvalu', flag: '🇹🇻', phoneCode: '+688' },
        { code: 'UG', name: 'Uganda', flag: '🇺🇬', phoneCode: '+256' },
        { code: 'UA', name: 'Ukraine', flag: '🇺🇦', phoneCode: '+380' },
        { code: 'AE', name: 'United Arab Emirates', flag: '🇦🇪', phoneCode: '+971' },
        { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', phoneCode: '+44' },
        { code: 'US', name: 'United States', flag: '🇺🇸', phoneCode: '+1' },
        { code: 'UY', name: 'Uruguay', flag: '🇺🇾', phoneCode: '+598' },
        { code: 'UZ', name: 'Uzbekistan', flag: '🇺🇿', phoneCode: '+998' },
        { code: 'VU', name: 'Vanuatu', flag: '🇻🇺', phoneCode: '+678' },
        { code: 'VA', name: 'Vatican City', flag: '🇻🇦', phoneCode: '+379' },
        { code: 'VE', name: 'Venezuela', flag: '🇻🇪', phoneCode: '+58' },
        { code: 'VN', name: 'Vietnam', flag: '🇻🇳', phoneCode: '+84' },
        { code: 'YE', name: 'Yemen', flag: '🇾🇪', phoneCode: '+967' },
        { code: 'ZM', name: 'Zambia', flag: '🇿🇲', phoneCode: '+260' },
        { code: 'ZW', name: 'Zimbabwe', flag: '🇿🇼', phoneCode: '+263' }
    ];

    // File types list with common file extensions
    const FILE_TYPES_LIST = [
        { ext: '.jpg', name: 'JPEG Image', icon: '🖼️', category: 'image', mime: 'image/jpeg' },
        { ext: '.jpeg', name: 'JPEG Image', icon: '🖼️', category: 'image', mime: 'image/jpeg' },
        { ext: '.png', name: 'PNG Image', icon: '🖼️', category: 'image', mime: 'image/png' },
        { ext: '.gif', name: 'GIF Image', icon: '🖼️', category: 'image', mime: 'image/gif' },
        { ext: '.webp', name: 'WebP Image', icon: '🖼️', category: 'image', mime: 'image/webp' },
        { ext: '.svg', name: 'SVG Image', icon: '🖼️', category: 'image', mime: 'image/svg+xml' },
        { ext: '.bmp', name: 'Bitmap Image', icon: '🖼️', category: 'image', mime: 'image/bmp' },
        { ext: '.ico', name: 'Icon', icon: '🖼️', category: 'image', mime: 'image/x-icon' },
        { ext: '.pdf', name: 'PDF Document', icon: '📄', category: 'document', mime: 'application/pdf' },
        { ext: '.doc', name: 'Word Document', icon: '📝', category: 'document', mime: 'application/msword' },
        { ext: '.docx', name: 'Word Document (Office 2007+)', icon: '📝', category: 'document', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' },
        { ext: '.xls', name: 'Excel Spreadsheet', icon: '📊', category: 'document', mime: 'application/vnd.ms-excel' },
        { ext: '.xlsx', name: 'Excel Spreadsheet (Office 2007+)', icon: '📊', category: 'document', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' },
        { ext: '.ppt', name: 'PowerPoint Presentation', icon: '📽️', category: 'document', mime: 'application/vnd.ms-powerpoint' },
        { ext: '.pptx', name: 'PowerPoint (Office 2007+)', icon: '📽️', category: 'document', mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' },
        { ext: '.txt', name: 'Text File', icon: '📄', category: 'document', mime: 'text/plain' },
        { ext: '.rtf', name: 'Rich Text Format', icon: '📄', category: 'document', mime: 'application/rtf' },
        { ext: '.odt', name: 'OpenDocument Text', icon: '📝', category: 'document', mime: 'application/vnd.oasis.opendocument.text' },
        { ext: '.ods', name: 'OpenDocument Spreadsheet', icon: '📊', category: 'document', mime: 'application/vnd.oasis.opendocument.spreadsheet' },
        { ext: '.zip', name: 'ZIP Archive', icon: '🗜️', category: 'archive', mime: 'application/zip' },
        { ext: '.rar', name: 'RAR Archive', icon: '🗜️', category: 'archive', mime: 'application/x-rar-compressed' },
        { ext: '.7z', name: '7-Zip Archive', icon: '🗜️', category: 'archive', mime: 'application/x-7z-compressed' },
        { ext: '.tar', name: 'TAR Archive', icon: '🗜️', category: 'archive', mime: 'application/x-tar' },
        { ext: '.gz', name: 'GZIP Archive', icon: '🗜️', category: 'archive', mime: 'application/gzip' },
        { ext: '.mp3', name: 'MP3 Audio', icon: '🎵', category: 'audio', mime: 'audio/mpeg' },
        { ext: '.wav', name: 'WAV Audio', icon: '🎵', category: 'audio', mime: 'audio/wav' },
        { ext: '.ogg', name: 'OGG Audio', icon: '🎵', category: 'audio', mime: 'audio/ogg' },
        { ext: '.m4a', name: 'M4A Audio', icon: '🎵', category: 'audio', mime: 'audio/mp4' },
        { ext: '.flac', name: 'FLAC Audio', icon: '🎵', category: 'audio', mime: 'audio/flac' },
        { ext: '.mp4', name: 'MP4 Video', icon: '🎬', category: 'video', mime: 'video/mp4' },
        { ext: '.avi', name: 'AVI Video', icon: '🎬', category: 'video', mime: 'video/x-msvideo' },
        { ext: '.mov', name: 'QuickTime Video', icon: '🎬', category: 'video', mime: 'video/quicktime' },
        { ext: '.wmv', name: 'WMV Video', icon: '🎬', category: 'video', mime: 'video/x-ms-wmv' },
        { ext: '.webm', name: 'WebM Video', icon: '🎬', category: 'video', mime: 'video/webm' },
        { ext: '.mkv', name: 'Matroska Video', icon: '🎬', category: 'video', mime: 'video/x-matroska' },
        { ext: '.csv', name: 'CSV File', icon: '📊', category: 'data', mime: 'text/csv' },
        { ext: '.json', name: 'JSON File', icon: '📋', category: 'data', mime: 'application/json' },
        { ext: '.xml', name: 'XML File', icon: '📋', category: 'data', mime: 'application/xml' },
        { ext: '.html', name: 'HTML File', icon: '🌐', category: 'code', mime: 'text/html' },
        { ext: '.css', name: 'CSS File', icon: '🎨', category: 'code', mime: 'text/css' },
        { ext: '.js', name: 'JavaScript File', icon: '⚙️', category: 'code', mime: 'application/javascript' },
        { ext: '.php', name: 'PHP File', icon: '⚙️', category: 'code', mime: 'application/x-httpd-php' },
        { ext: '.py', name: 'Python File', icon: '⚙️', category: 'code', mime: 'text/x-python' }
    ];


    /**
     * Initialize visual form editor with WYSIWYG preview and popup settings
     */
    function initVisualFormEditor() {
        // Prevent multiple initializations
        if (window.SF && window.SF.VisualEditor && window.SF.VisualEditor.initialized) {
            return;
        }

        // Check if we're in the visual form editor
        const $visualPreview = $('#sf-visual-form-preview');
        if ($visualPreview.length === 0) {
            return;
        }

        // Initialize field data
        let fieldsData = [];

        // Check if we're in edit mode with existing fields
        if (typeof sfFieldsData !== 'undefined') {

            // Ensure it's an array
            if (!Array.isArray(sfFieldsData)) {
                sfFieldsData = [];
            }

            // Process the field data to ensure all required properties
            fieldsData = sfFieldsData.map(function (field) {
                // Start with complete field to preserve all properties
                const processedField = Object.assign({}, field);

                // Ensure required properties have defaults
                processedField.id = field.name || field.id || ('field_' + Date.now() + '_' + Math.floor(Math.random() * 1000));
                processedField.type = field.type || 'text';
                processedField.name = field.name || field.id;
                processedField.default_value = field.default_value || '';
                processedField.label = field.label || 'Field';
                processedField.placeholder = field.placeholder || '';
                processedField.required = field.required || false;
                processedField.column_width = field.column_width || '100';
                processedField.options = Array.isArray(field.options) ? field.options : [];
                processedField.conditional = typeof field.conditional === 'object' ? field.conditional : {};
                processedField.math = typeof field.math === 'object' ? field.math : {};
                processedField.show_label = field.show_label !== false;
                processedField.help_text = field.help_text || '';
                processedField.options_columns = field.options_columns || '1';

                // Explicitly preserve country and phone field properties (already in processedField from Object.assign, but being explicit)
                return processedField;
            });

        } else if (field.type === 'range') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').hide();
            $popup.find('.sf-field-row.sf-custom-extensions-row').hide();
            $popup.find('.sf-field-row.sf-file-size-limit-row').hide();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').hide();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').hide();
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').hide();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').hide();
            $popup.find('.sf-field-row.sf-max-files-row').hide();
            $popup.find('.sf-field-row.sf-storage-location-row').hide();
            
            // Populate range settings
            $popup.find('.sf-range-min').val(field.range_min || '0');
            $popup.find('.sf-range-max').val(field.range_max || '100');
            $popup.find('.sf-range-step').val(field.range_step || '1');
            $popup.find('.sf-range-default').val(field.range_default || '50');
        } else {
            // Initialize global field data array if it doesn't exist
            window.sfFieldsData = [];
        }

        // Render the form preview immediately with available data
        renderVisualFormPreview(fieldsData);

        // Initialize form name and settings for edit mode
        if (window.sfFormSettings && window.sfFormSettings.title) {
            // Populate the form name input field in step 3
            $('#form-title-input').val(window.sfFormSettings.title);
            // Also ensure the hidden field is set
            $('#form-title').val(window.sfFormSettings.title);
        }

        // Remove any existing event handlers to prevent duplicates
        $('.sf-add-field-button').off('click');
        $(document).off('click', '.sf-field-type-item');
        $('.sf-close-modal').off('click');
        $(document).off('click', '.sf-field-type-modal');
        $(document).off('click', '.sf-preview-field');
        $(document).off('click', '.sf-add-option');
        $(document).off('click', '.sf-remove-option');
        $(document).off('click', '.sf-delete-field');
        $(document).off('click', '.sf-duplicate-field');
        $(document).off('click', '.sf-edit-field');
        $(document).off('click', '.sf-edit-submit-button');
        $(document).off('click', '.sf-preview-submit-button .sf-edit-field');
        $(document).off('click', '.sf-form-settings-button');
        $(document).off('click', '.sf-close-form-settings, .sf-cancel-form-settings');
        $(document).off('click', '.sf-save-form-settings');
        $(document).off('click', '.sf-form-settings-modal');
        $(document).off('input', '#form-submit-button-text-input');
        $(document).off('change', '#submit-button-width-input');
        $(document).off('input', '#submit-button-text-input');
        $(document).off('DOMSubtreeModified', '.sf-save-form');
        $(document).off('change', '.sf-field-options-columns');
        $(document).off('change', '.sf-field-type');
        $('.sf-close-settings').off('click');
        $('.sf-settings-tab').off('click');
        $('.sf-field-has-conditional').off('change');
        $('.sf-save-settings').off('click');
        $('.sf-cancel-settings').off('click');

        // Clean up math function event handlers
        $(document).off('change', '.sf-field-has-math');
        $(document).off('change', '.sf-math-calculation-type');
        $(document).off('change', '.sf-math-round-result');
        $(document).off('click', '.sf-add-math-field');
        $(document).off('click', '.sf-remove-math-field');
        $(document).off('change', '.sf-math-field-select');
        $(document).off('input', '.sf-math-formula');

        // Open field type selection modal when Add Field button is clicked
        $('.sf-add-field-button').on('click', function () {
            openFieldTypeModal();
        });

        // AI Chat Widget handlers
        initAIChatWidget();

        // Handle field type selection
        $(document).on('click', '.sf-field-type-item', function () {
            const fieldType = $(this).data('type');
            // License guard: block specific pro fields when license is invalid
            const proTypes = ['file', 'phone_international', 'signature', 'rating', 'section_heading', 'select', 'radio', 'checkbox', 'date', 'country', 'rich_text', 'range', 'page_break'];
            if (proTypes.includes(fieldType) && !(window.sfLicenseValid === true)) {
                window.SF.notify(window.SF.t('fieldNeedsLicense', 'This field requires an active SigmaForms Pro license.'));
                return;
            }
            addNewField(fieldType);
            closeFieldTypeModal();
        });

        // Close field type modal when clicking close button
        $('.sf-close-modal').on('click', function () {
            closeFieldTypeModal();
        });

        // Close field type modal when clicking outside
        $(document).on('click', '.sf-field-type-modal', function (e) {
            if ($(e.target).hasClass('sf-field-type-modal')) {
                closeFieldTypeModal();
            }
        });

        // Handle field settings edit button
        $(document).on('click', '.sf-edit-field', function (e) {
            e.stopPropagation();
            const $field = $(this).closest('.sf-preview-field');
            if ($field.data('locked') === true || $field.attr('data-locked') === 'true') {
                window.SF.notify(window.SF.t('proFieldLocked', 'This is a Pro field and is locked until you activate your license.'));
                return;
            }
            const fieldId = $field.data('field-id');

            if (fieldId) {
                openFieldSettings(fieldId);
            }
        });

        // Handle field duplicate button
        $(document).on('click', '.sf-duplicate-field', function (e) {
            e.stopPropagation();
            const $field = $(this).closest('.sf-preview-field');
            if ($field.data('locked') === true || $field.attr('data-locked') === 'true') {
                window.SF.notify(window.SF.t('proFieldLocked', 'This is a Pro field and is locked until you activate your license.'));
                return;
            }
            const fieldId = $field.data('field-id');
            duplicateField(fieldId);
        });

        // Handle field delete button
        $(document).on('click', '.sf-delete-field', function (e) {
            e.stopPropagation();
            const $field = $(this).closest('.sf-preview-field');
            if ($field.data('locked') === true || $field.attr('data-locked') === 'true') {
                window.SF.notify(window.SF.t('proFieldLocked', 'This is a Pro field and is locked until you activate your license.'));
                return;
            }
            const fieldId = $field.data('field-id');
            deleteField(fieldId);
        });

        // Close field settings when clicking close button
        $('.sf-close-settings').on('click', function () {
            cancelFieldSettings();
        });

        // Switch tabs in field settings
        $('.sf-settings-tab').on('click', function () {
            const tab = $(this).data('tab');
            switchSettingsTab(tab);
        });

        // Toggle conditional logic settings
        $('.sf-field-has-conditional').on('change', function () {
            $('.sf-conditional-rules').toggle($(this).is(':checked'));
        });

        // Toggle section heading underline options visibility
        $(document).on('change', '.sf-section-show-underline', function () {
            const isChecked = $(this).is(':checked');
            $('.sf-underline-options').toggle(isChecked);
        });

        // Toggle max files row based on allow multiple checkbox
        $(document).on('change', '.sf-allow-multiple-files', function () {
            const isChecked = $(this).is(':checked');
            const $maxFilesRow = $(this).closest('.sf-field-settings-popup').find('.sf-field-row.sf-max-files-row');
            if (isChecked) {
                $maxFilesRow.slideDown(200);
            } else {
                $maxFilesRow.slideUp(200);
                $maxFilesRow.find('.sf-max-files').val('');
            }
        });

        // Toggle math function settings
        $('.sf-field-has-math').on('change', function () {
            const isChecked = $(this).is(':checked');

            if (isChecked) {
                $('.sf-math-rules').show();
            } else {
                $('.sf-math-rules').hide();
            }
        });

        // Handle math calculation type change
        $(document).on('change', '.sf-math-calculation-type', function () {
            const calculationType = $(this).val();
            const $customFormula = $('.sf-math-custom-formula');
            const $fieldsContainer = $('.sf-math-fields-container');

            if (calculationType === 'custom') {
                $customFormula.show();
                $fieldsContainer.hide();
            } else {
                $customFormula.hide();
                $fieldsContainer.show();
            }

            updateMathPreview();

            // Calculate and display result immediately
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 100);
        });

        // Handle math round result toggle
        $(document).on('change', '.sf-math-round-result', function () {
            $('.sf-math-round-options').toggle($(this).is(':checked'));

            // Recalculate with new rounding settings
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 100);
        });

        // Handle decimal places change
        $(document).on('change', '.sf-math-decimal-places', function () {
            // Recalculate with new decimal places
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 100);
        });

        // Add math field
        $(document).on('click', '.sf-add-math-field', function (e) {
            e.preventDefault();
            e.stopPropagation();

            // Prevent multiple rapid clicks
            if ($(this).data('adding')) {
                return;
            }

            // Check current field count
            const currentFieldCount = $('.sf-math-fields-list .sf-math-field-item').length;

            // Limit to reasonable number of fields (e.g., 10)
            if (currentFieldCount >= 10) {
                return;
            }

            $(this).data('adding', true);
            setTimeout(() => {
                $(this).removeData('adding');
            }, 500);

            addMathField();

            // Recalculate after adding field
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 200);
        });

        // Remove math field
        $(document).on('click', '.sf-remove-math-field', function (e) {
            e.preventDefault();
            e.stopPropagation();

            const $fieldItem = $(this).closest('.sf-math-field-item');

            if ($fieldItem.length) {
                const fieldId = $fieldItem.data('field-id');
                $fieldItem.remove();
                updateMathPreview();

                // Log remaining fields
                const remainingFields = $('.sf-math-fields-list .sf-math-field-item').length;

                // Recalculate after removing field
                setTimeout(function () {
                    calculateMathFieldInEditor();
                }, 100);
            }
        });

        // Handle math field selection change
        $(document).on('change', '.sf-math-field-select', function () {
            updateMathPreview();

            // Calculate and display result immediately
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 100);
        });

        // Handle custom formula input
        $(document).on('input', '.sf-math-formula', function () {
            updateMathPreview();

            // Calculate and display result immediately for custom formulas
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 100);
        });

        // Save field settings
        $('.sf-save-settings').on('click', function (e) {
            e.preventDefault();

            // Add a tiny delay to ensure DOM is fully updated before reading checkbox states
            setTimeout(function () {
                saveFieldSettings();
            }, 50);
        });

        // Cancel field settings
        $('.sf-cancel-settings').on('click', function () {
            cancelFieldSettings();
        });

        // Add option to select/radio/checkbox
        $(document).on('click', '.sf-add-option', function () {
            addFieldOption();
        });

        // Remove option from select/radio/checkbox
        $(document).on('click', '.sf-remove-option', function () {
            $(this).closest('.sf-field-option').remove();
        });

        // Full width and an explicit pixel width are mutually exclusive
        $(document).on('change', '.sf-field-label-image-full-width', function () {
            $('.sf-field-label-image-width, .sf-field-label-image-width-unit')
                .prop('disabled', $(this).is(':checked'));
        });

        // Drag a handle to stretch the image. Handles are always in the markup
        // and revealed on hover, so there is no separate "arm it first" step.
        $(document).on('mousedown', '.sf-image-resize-handle', function (e) {
            e.preventDefault();
            // Keep the drag away from jQuery UI sortable on the parent field
            e.stopPropagation();

            const $handle = $(this);
            const direction = String($handle.data('dir'));
            const $wrap = $handle.closest('.sf-label-image-wrap');
            const $image = $wrap.find('.sf-label-image');

            const startX = e.pageX;
            const startY = e.pageY;
            const startWidth = $wrap.outerWidth();
            const startHeight = $image.outerHeight();
            const aspectRatio = startWidth > 0 ? (startHeight / startWidth) : 1;
            // Dragging can always reach the edge of the field, whatever its width
            const availableWidth = getImageAvailableWidth($wrap);

            // Width lives on the wrapper (percent widths have to resolve against
            // the label box), so pin it there before the drag starts - otherwise
            // the wrapper keeps its old size and clamps the image inside it.
            $wrap.css('width', startWidth + 'px').removeClass('sf-image-full-width');
            $image.css('width', '100%');

            // Marks the one image being dragged - the body class only handles
            // page-wide concerns like the cursor and text selection.
            $wrap.addClass('sf-is-resizing');
            $('body').addClass('sf-resizing-image');

            $(document).on('mousemove.sfImageResize', function (moveEvent) {
                let width = startWidth;
                let height = startHeight;

                if (direction.indexOf('e') !== -1) {
                    width = startWidth + (moveEvent.pageX - startX);
                }

                if (direction.indexOf('s') !== -1) {
                    height = startHeight + (moveEvent.pageY - startY);
                }

                // Hold Shift on the corner handle to keep the aspect ratio
                if (direction === 'se' && moveEvent.shiftKey) {
                    height = width * aspectRatio;
                }

                if (direction.indexOf('e') !== -1) {
                    // Near the edge, snap to a real 100% width so the frontend
                    // fills its field too instead of using a fixed pixel size.
                    if (width >= availableWidth - SF_IMAGE_SNAP_DISTANCE) {
                        $wrap.addClass('sf-image-full-width').css('width', '100%');
                    } else {
                        $wrap.removeClass('sf-image-full-width')
                            .css('width', clampImageSize(width, availableWidth) + 'px');
                    }
                }

                if (direction.indexOf('s') !== -1) {
                    // Stretch to the dragged box rather than letterboxing inside it
                    $image.css({ height: clampImageSize(height) + 'px', 'object-fit': 'fill' });
                }

                updateImageResizeBadge($wrap);
            });

            $(document).on('mouseup.sfImageResize', function () {
                $(document).off('mousemove.sfImageResize mouseup.sfImageResize');
                $wrap.removeClass('sf-is-resizing');
                $('body').removeClass('sf-resizing-image');
                persistImageResize($wrap);
            });
        });

        // Pick a label image via the WordPress media library
        $(document).on('click', '.sf-image-picker .sf-select-image', function (e) {
            e.preventDefault();
            const $picker = $(this).closest('.sf-image-picker');
            openMediaPicker(function (url, attachment) {
                const id = attachment ? attachment.id : '';
                $picker.find('.sf-field-label-image').val(url);
                $picker.find('.sf-field-label-image-id').val(id);
                // A fresh pick becomes the new crop source
                $picker.find('.sf-field-label-image-source-id').val(id);
                renderImagePickerPreview($picker);
                toggleLabelImageOptions();
            });
        });

        // Crop the label image into a new attachment
        $(document).on('click', '.sf-image-picker .sf-crop-image', function (e) {
            e.preventDefault();
            const $picker = $(this).closest('.sf-image-picker');
            // Always crop the originally selected image, never a previous crop
            const sourceId = parseInt($picker.find('.sf-field-label-image-source-id').val(), 10)
                || parseInt($picker.find('.sf-field-label-image-id').val(), 10)
                || 0;

            openImageCropper(sourceId, function (url, attachment) {
                $picker.find('.sf-field-label-image').val(url);
                $picker.find('.sf-field-label-image-id').val(attachment ? attachment.id : '');
                renderImagePickerPreview($picker);
                toggleLabelImageOptions();
            });
        });

        $(document).on('click', '.sf-image-picker .sf-remove-image', function (e) {
            e.preventDefault();
            const $picker = $(this).closest('.sf-image-picker');
            $picker.find('.sf-field-label-image, .sf-field-label-image-id, .sf-field-label-image-source-id').val('');
            renderImagePickerPreview($picker);
            toggleLabelImageOptions();
        });

        // Pick a per-option image
        $(document).on('click', '.sf-option-image-btn', function (e) {
            e.preventDefault();
            const $option = $(this).closest('.sf-field-option');
            openMediaPicker(function (url, attachment) {
                const id = attachment ? attachment.id : '';
                $option.find('.sf-option-image-value').val(url);
                $option.find('.sf-option-image-id').val(id);
                $option.find('.sf-option-image-source-id').val(id);
                renderOptionImagePreview($option);
            });
        });

        // Crop a per-option image
        $(document).on('click', '.sf-option-image-crop', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const $option = $(this).closest('.sf-field-option');
            // Always crop the originally selected image, never a previous crop
            const sourceId = parseInt($option.find('.sf-option-image-source-id').val(), 10)
                || parseInt($option.find('.sf-option-image-id').val(), 10)
                || 0;

            openImageCropper(sourceId, function (url, attachment) {
                $option.find('.sf-option-image-value').val(url);
                $option.find('.sf-option-image-id').val(attachment ? attachment.id : '');
                renderOptionImagePreview($option);
            });
        });

        $(document).on('click', '.sf-option-image-clear', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const $option = $(this).closest('.sf-field-option');
            $option.find('.sf-option-image-value, .sf-option-image-id, .sf-option-image-source-id').val('');
            renderOptionImagePreview($option);
        });

        // Update field type display in settings
        $(document).on('change', '.sf-field-type', function () {
            const fieldType = $(this).val();
            updateFieldTypeSpecificSettings(fieldType);
        });

        // Handle submit button edit
        $(document).on('click', '.sf-edit-submit-button', function (e) {
            e.preventDefault();
            e.stopPropagation();
            openFormElementSettings('submit');
        });

        // Handle edit icon click for submit button
        $(document).on('click', '.sf-preview-submit-button .sf-edit-field', function (e) {
            e.preventDefault();
            e.stopPropagation();
            openFormElementSettings('submit');
        });

        // Handle form settings button
        $(document).on('click', '.sf-form-settings-button', function (e) {
            e.preventDefault();
            openFormSettingsModal();
        });

        // Handle form settings modal close
        $(document).on('click', '.sf-close-form-settings, .sf-cancel-form-settings', function (e) {
            e.preventDefault();
            closeFormSettingsModal();
        });

        // Handle form settings modal save
        $(document).on('click', '.sf-save-form-settings', function (e) {
            e.preventDefault();
            saveFormSettings();
        });

        // Close form settings modal when clicking outside
        $(document).on('click', '.sf-form-settings-modal', function (e) {
            if ($(e.target).hasClass('sf-form-settings-modal')) {
                closeFormSettingsModal();
            }
        });

        // Handle toggle switches in form settings modal
        // Note: Form name settings are now handled in step 3

        // Handle input changes in form settings modal
        // Real-time preview updates for submit button have been disabled
        // Changes now only apply when clicking "Save Changes" in the modal

        /* DISABLED - Real-time updates
        $(document).on('input', '#form-submit-button-text-input', function () {
            updateFormSettingsPreview();
        });

        // Handle submit button width changes in real-time
        $(document).on('change', '#submit-button-width-input', function () {
            const submitWidth = $(this).val();
            const submitText = $('#submit-button-text-input').val().trim() || 'Submit';

            // Update button text
            $('.sf-edit-submit-button').html(`${sfIcon('check')} ${submitText}`);

            // Update button width styling in real-time
            if (submitWidth === '100') {
                $('.sf-preview-submit-button').css('justify-content', 'stretch');
                $('.sf-edit-submit-button').css('width', '100%');
            } else if (submitWidth === 'auto') {
                $('.sf-preview-submit-button').css('justify-content', 'flex-start');
                $('.sf-edit-submit-button').css('width', 'auto');
            } else {
                $('.sf-preview-submit-button').css('justify-content', 'flex-start');
                $('.sf-edit-submit-button').css('width', submitWidth + '%');
            }
        });

        // Handle submit button text changes in real-time
        $(document).on('input', '#submit-button-text-input', function () {
            const submitText = $(this).val().trim() || 'Submit';
            $('.sf-edit-submit-button').html(`${sfIcon('check')} ${submitText}`);
        });

        // Handle submit button alignment changes in real-time
        $(document).on('change', '#submit-button-align-input', function () {
            const submitAlign = $(this).val();
            // Remove existing alignment classes
            $('.sf-preview-submit-button').removeClass('sf-button-align-left sf-button-align-center sf-button-align-right');
            // Add new alignment class
            $('.sf-preview-submit-button').addClass('sf-button-align-' + submitAlign);
        });
        */

        // Global protection for published form buttons
        // This prevents any other code from re-enabling buttons that have been marked as published
        $(document).on('DOMSubtreeModified', '.sf-save-form', function () {
            const $button = $(this);
            if ($button.data('form-published') && !$button.prop('disabled')) {
                // If the button is marked as published but somehow got enabled, disable it again
                $button.prop('disabled', true).html(sfIcon('check') + ' Published Form');
            }
        });

        // Additional protection: monitor for any attempts to enable published buttons
        const originalProp = $.fn.prop;
        $.fn.prop = function (name, value) {
            if (name === 'disabled' && value === false) {
                // Check if this is a published form button
                if (this.hasClass('sf-save-form') && this.data('form-published')) {
                    // Don't allow enabling published buttons
                    return this;
                }
            }
            return originalProp.apply(this, arguments);
        };

        // Track if user has manually set columns
        let userSetColumns = false;

        // When user changes the columns dropdown, set flag
        $(document).on('change', '.sf-field-options-columns', function () {
            userSetColumns = true;
        });

        // When options are added/removed, auto-set columns if not manually set
        function autoSetOptionsColumns() {
            const $popup = $('.sf-field-settings-popup');
            const fieldType = $popup.find('.sf-field-type').val();
            if (['checkbox', 'radio'].includes(fieldType) && !userSetColumns) {
                const optionCount = $popup.find('.sf-field-options-list .sf-field-option').length;
                let columns = 1;
                if (optionCount >= 11) columns = 6;
                else if (optionCount >= 9) columns = 5;
                else if (optionCount >= 7) columns = 4;
                else if (optionCount >= 5) columns = 3;
                else if (optionCount >= 3) columns = 2;
                $popup.find('.sf-field-options-columns').val(columns);
            }
        }

        // Hook autoSetOptionsColumns to add/remove option events
        $(document).on('click', '.sf-add-option, .sf-remove-option', function () {
            setTimeout(autoSetOptionsColumns, 100);
        });

        // Also call on field type change
        $(document).on('change', '.sf-field-type', function () {
            userSetColumns = false;
            setTimeout(autoSetOptionsColumns, 100);
        });

        // Country search functionality (for country field)
        $(document).on('input', '.sf-country-search', function () {
            const searchTerm = $(this).val().toLowerCase();
            let visibleItems = 0;

            // Clear any previous empty state messages
            $('.sf-countries-empty').remove();
            $('.sf-countries-search-info').remove();

            // Reset all sections to visible first
            $('.sf-selected-countries-section').show();
            $('.sf-unselected-countries-section').show();

            // If search is empty, show all countries
            if (searchTerm === '') {
                $('.sf-country-item').removeClass('hidden sf-search-dimmed').show();
                return;
            }

            let visibleInUnselectedSection = 0;

            $('.sf-country-item').each(function () {
                const $item = $(this);
                const countryName = $item.find('.sf-country-name').text().toLowerCase();
                const countryCode = $item.find('.sf-country-code').text().toLowerCase();
                const isSelected = $item.hasClass('sf-country-selected');
                const isInUnselectedSection = $item.closest('.sf-unselected-countries-section').length > 0;

                if (countryName.includes(searchTerm) || countryCode.includes(searchTerm)) {
                    $item.removeClass('hidden sf-search-dimmed').show();
                    visibleItems++;
                    if (isInUnselectedSection) {
                        visibleInUnselectedSection++;
                    }
                } else if (isSelected) {
                    // Keep selected countries visible but dimmed during search
                    $item.removeClass('hidden').show().addClass('sf-search-dimmed');
                    visibleItems++;
                } else {
                    $item.addClass('hidden').hide().removeClass('sf-search-dimmed');
                }
            });

            // Hide unselected section only if no items are visible in it
            if (visibleInUnselectedSection === 0) {
                $('.sf-unselected-countries-section').hide();
            }

            // Show/hide empty state only if no countries match and no selected countries exist
            const selectedCountriesCount = $('.sf-selected-countries-section .sf-country-item').length;
            if (visibleItems === selectedCountriesCount && selectedCountriesCount > 0) {
                // Only selected countries are visible (dimmed), show a helpful message
                $('.sf-countries-list').append('<div class="sf-countries-search-info"><span class="dashicons dashicons-info"></span><br>No other countries match your search. Selected countries remain visible above.</div>');
            } else if (visibleItems === 0) {
                $('.sf-countries-list').append('<div class="sf-countries-empty"><span class="dashicons dashicons-search"></span><br>No countries found</div>');
            }
        });

        // Phone countries search functionality (for phone_international field)
        $(document).on('input', '.sf-phone-countries-search', function () {
            const searchTerm = $(this).val().toLowerCase();
            let visibleItems = 0;

            // Clear any previous empty state messages
            $('.sf-phone-countries-empty').remove();
            $('.sf-phone-countries-search-info').remove();

            // Reset all sections to visible first
            $('.sf-selected-phone-countries-section').show();
            $('.sf-unselected-phone-countries-section').show();

            // If search is empty, show all countries
            if (searchTerm === '') {
                $('.sf-phone-country-item').removeClass('hidden sf-search-dimmed').show();
                return;
            }

            let visibleInUnselectedSection = 0;

            $('.sf-phone-country-item').each(function () {
                const $item = $(this);
                const countryName = $item.find('.sf-phone-country-name').text().toLowerCase();
                const countryCode = $item.find('.sf-phone-country-code').text().toLowerCase();
                const phoneCode = $item.find('.sf-phone-country-phone-code').text().toLowerCase();
                const isSelected = $item.hasClass('sf-phone-country-selected');
                const isInUnselectedSection = $item.closest('.sf-unselected-phone-countries-section').length > 0;

                if (countryName.includes(searchTerm) || countryCode.includes(searchTerm) || phoneCode.includes(searchTerm)) {
                    $item.removeClass('hidden sf-search-dimmed').show();
                    visibleItems++;
                    if (isInUnselectedSection) {
                        visibleInUnselectedSection++;
                    }
                } else if (isSelected) {
                    // Keep selected countries visible but dimmed during search
                    $item.removeClass('hidden').show().addClass('sf-search-dimmed');
                    visibleItems++;
                } else {
                    $item.addClass('hidden').hide().removeClass('sf-search-dimmed');
                }
            });

            // Hide unselected section only if no items are visible in it
            if (visibleInUnselectedSection === 0) {
                $('.sf-unselected-phone-countries-section').hide();
            }

            // Show/hide empty state only if no phone countries match and no selected phone countries exist
            const selectedPhoneCountriesCount = $('.sf-selected-phone-countries-section .sf-phone-country-item').length;
            if (visibleItems === selectedPhoneCountriesCount && selectedPhoneCountriesCount > 0) {
                // Only selected phone countries are visible (dimmed), show a helpful message
                $('.sf-phone-countries-list').append('<div class="sf-phone-countries-search-info"><span class="dashicons dashicons-info"></span><br>No other countries match your search. Selected countries remain visible above.</div>');
            } else if (visibleItems === 0) {
                $('.sf-phone-countries-list').append('<div class="sf-phone-countries-empty"><span class="dashicons dashicons-search"></span><br>No countries found</div>');
            }
        });

        // Country checkbox click handler
        $(document).on('click', '.sf-country-item', function (e) {
            e.preventDefault();
            const $item = $(this);
            const $checkbox = $item.find('.sf-country-checkbox');
            const countryCode = $checkbox.data('code');
            const isCurrentlySelected = $checkbox.hasClass('checked');

            // Toggle selection
            $checkbox.toggleClass('checked');

            // Move item to appropriate section
            if (!isCurrentlySelected) {
                // Moving from unselected to selected
                $item.addClass('sf-country-selected');
                moveCountryToSelectedSection($item);
            } else {
                // Moving from selected to unselected
                $item.removeClass('sf-country-selected');
                moveCountryToUnselectedSection($item);
            }

            updateSelectedCountriesCount();
        });

        // Prevent checkbox click from bubbling
        $(document).on('click', '.sf-country-checkbox', function (e) {
            e.stopPropagation();
            $(this).toggleClass('checked');
            updateSelectedCountriesCount();
        });

        // Select all countries
        $(document).on('click', '.sf-select-all-countries', function (e) {
            e.preventDefault();
            $('.sf-country-item:visible').each(function () {
                const $item = $(this);
                const $checkbox = $item.find('.sf-country-checkbox');

                if (!$checkbox.hasClass('checked')) {
                    $checkbox.addClass('checked');
                    $item.addClass('sf-country-selected');
                    moveCountryToSelectedSection($item);
                }
            });
            updateSelectedCountriesCount();
        });

        // Deselect all countries
        $(document).on('click', '.sf-deselect-all-countries', function (e) {
            e.preventDefault();
            $('.sf-country-checkbox.checked').each(function () {
                const $checkbox = $(this);
                const $item = $checkbox.closest('.sf-country-item');

                $checkbox.removeClass('checked');
                $item.removeClass('sf-country-selected');
                moveCountryToUnselectedSection($item);
            });
            updateSelectedCountriesCount();
        });

        // Phone country checkbox click handler
        $(document).on('click', '.sf-phone-country-item', function (e) {
            e.preventDefault();
            const $item = $(this);
            const $checkbox = $item.find('.sf-phone-country-checkbox');
            const countryCode = $checkbox.data('code');
            const isCurrentlySelected = $checkbox.hasClass('checked');

            // Toggle selection
            $checkbox.toggleClass('checked');

            // Move item to appropriate section
            if (!isCurrentlySelected) {
                // Moving from unselected to selected
                $item.addClass('sf-phone-country-selected');
                movePhoneCountryToSelectedSection($item);
            } else {
                // Moving from selected to unselected
                $item.removeClass('sf-phone-country-selected');
                movePhoneCountryToUnselectedSection($item);
            }

            updateSelectedPhoneCountriesCount();
        });

        // Prevent phone checkbox click from bubbling
        $(document).on('click', '.sf-phone-country-checkbox', function (e) {
            e.stopPropagation();
            $(this).toggleClass('checked');
            updateSelectedPhoneCountriesCount();
        });

        // Select all phone countries
        $(document).on('click', '.sf-select-all-phone-countries', function (e) {
            e.preventDefault();
            $('.sf-phone-country-item:visible').each(function () {
                const $item = $(this);
                const $checkbox = $item.find('.sf-phone-country-checkbox');

                if (!$checkbox.hasClass('checked')) {
                    $checkbox.addClass('checked');
                    $item.addClass('sf-phone-country-selected');
                    movePhoneCountryToSelectedSection($item);
                }
            });
            updateSelectedPhoneCountriesCount();
        });

        // Deselect all phone countries
        $(document).on('click', '.sf-deselect-all-phone-countries', function (e) {
            e.preventDefault();
            $('.sf-phone-country-checkbox.checked').each(function () {
                const $checkbox = $(this);
                const $item = $checkbox.closest('.sf-phone-country-item');

                $checkbox.removeClass('checked');
                $item.removeClass('sf-phone-country-selected');
                movePhoneCountryToUnselectedSection($item);
            });
            updateSelectedPhoneCountriesCount();
        });

        // File type checkbox click handler
        $(document).on('click', '.sf-file-type-item', function(e) {
            e.preventDefault();
            const $item = $(this);
            const $checkbox = $item.find('.sf-file-type-checkbox');
            const ext = $checkbox.data('ext');
            const isCurrentlySelected = $checkbox.hasClass('checked');
            const category = $item.closest('.sf-file-types-section').data('category');

            // Toggle selection
            $checkbox.toggleClass('checked');

            // Move item to appropriate section
            if (!isCurrentlySelected) {
                // Moving from unselected to selected
                $item.addClass('sf-file-type-selected');
                moveFileTypeToSelectedSection($item, category);
            } else {
                // Moving from selected to unselected
                $item.removeClass('sf-file-type-selected');
                moveFileTypeToUnselectedSection($item, category);
            }

            updateSelectedFileTypesCount();
        });

        // Prevent checkbox click from bubbling
        $(document).on('click', '.sf-file-type-checkbox', function(e) {
            e.stopPropagation();
            $(this).toggleClass('checked');
            updateSelectedFileTypesCount();
        });

        // Select all file types
        $(document).on('click', '.sf-select-all-file-types', function(e) {
            e.preventDefault();
            $('.sf-file-type-item:visible').each(function() {
                const $item = $(this);
                const $checkbox = $item.find('.sf-file-type-checkbox');
                const category = $item.closest('.sf-file-types-section').data('category');

                if (!$checkbox.hasClass('checked')) {
                    $checkbox.addClass('checked');
                    $item.addClass('sf-file-type-selected');
                    moveFileTypeToSelectedSection($item, category);
                }
            });
            updateSelectedFileTypesCount();
        });

        // Deselect all file types
        $(document).on('click', '.sf-deselect-all-file-types', function(e) {
            e.preventDefault();
            $('.sf-file-type-checkbox.checked').each(function() {
                const $checkbox = $(this);
                const $item = $checkbox.closest('.sf-file-type-item');
                const category = $item.closest('.sf-file-types-section').data('category');

                $checkbox.removeClass('checked');
                $item.removeClass('sf-file-type-selected');
                moveFileTypeToUnselectedSection($item, category);
            });
            updateSelectedFileTypesCount();
        });

        // File types search
        $(document).on('input', '.sf-file-types-search', function() {
            const searchTerm = $(this).val().toLowerCase();
            
            $('.sf-file-type-item').each(function() {
                const $item = $(this);
                const name = $item.find('.sf-file-type-name').text().toLowerCase();
                const ext = $item.find('.sf-file-type-ext').text().toLowerCase();
                
                if (name.includes(searchTerm) || ext.includes(searchTerm)) {
                    $item.show();
                } else {
                    $item.hide();
                }
            });

            // Hide empty sections
            $('.sf-file-types-section').each(function() {
                const $section = $(this);
                const visibleItems = $section.find('.sf-file-type-item:visible').length;
                
                if (visibleItems === 0) {
                    $section.hide();
                } else {
                    $section.show();
                }
            });
        });

        // Mark as initialized to prevent duplicate initialization
        if (window.SF && window.SF.VisualEditor) {
            window.SF.VisualEditor.initialized = true;
        }
    }

    /**
     * Render the visual form preview for the WYSIWYG editor
     * 
     * @param {Array} fieldsData Array of field data objects
     */
    function renderVisualFormPreview(fieldsData) {
        const $previewArea = $('#sf-visual-form-preview');

        if ($previewArea.length === 0) {
            return;
        }

        // Clear the preview area
        $previewArea.empty();

        // Ensure fieldsData is an array
        if (!Array.isArray(fieldsData)) {
            fieldsData = [];
        }

        // Ensure each field has required properties
        fieldsData = fieldsData.map(function (field) {
            // Skip if not a valid field object
            if (!field || typeof field !== 'object') {
                return null;
            }

            // Start with the complete existing field to preserve all properties
            const preservedField = Object.assign({}, field);

            // Ensure required properties have default values
            preservedField.id = field.name || field.id || ('field_' + Date.now() + '_' + Math.floor(Math.random() * 1000));
            preservedField.type = field.type || 'text';
            preservedField.name = field.name || field.id;
            preservedField.default_value = field.default_value || '';
            preservedField.label = field.label || 'Field';
            preservedField.placeholder = field.placeholder || '';
            preservedField.required = !!field.required;
            preservedField.column_width = field.column_width || '100';
            preservedField.options = Array.isArray(field.options) ? field.options : [];
            preservedField.conditional = typeof field.conditional === 'object' ? field.conditional : {};
            preservedField.math = typeof field.math === 'object' ? field.math : {};
            preservedField.show_label = field.show_label !== false;
            preservedField.show_label_image = field.show_label_image !== false;
            preservedField.label_position = field.label_position || 'left';
            preservedField.help_text = field.help_text || '';
            preservedField.options_columns = field.options_columns || '1';
            preservedField.field_position = field.field_position || 'left';
            preservedField.label_image = field.label_image || '';
            preservedField.label_image_id = field.label_image_id || 0;
            preservedField.label_image_source_id = field.label_image_source_id || field.label_image_id || 0;
            preservedField.label_image_position = field.label_image_position || 'left';
            preservedField.label_image_width = field.label_image_width || 0;
            preservedField.label_image_height = field.label_image_height || 0;
            preservedField.label_image_full_width = !!field.label_image_full_width;
            preservedField.label_image_width_unit = field.label_image_width_unit === 'px' ? 'px' : '%';
            preservedField.option_image_position = field.option_image_position || 'top';
            preservedField.option_image_size = field.option_image_size || 0;
            preservedField.show_country_flags = field.show_country_flags !== false;

            // Preserve country field specific properties
            if (field.selected_countries) {
                preservedField.selected_countries = field.selected_countries;
            }

            // Preserve phone_international field specific properties
            if (field.selected_phone_countries) {
                preservedField.selected_phone_countries = field.selected_phone_countries;
            }
            if (field.available_countries) {
                preservedField.available_countries = field.available_countries;
            }
            if (field.default_country) {
                preservedField.default_country = field.default_country;
            }

            return preservedField;
        }).filter(Boolean); // Remove any null entries

        // Store the global field data
        window.sfFieldsData = fieldsData;

        if (fieldsData.length === 0) {
            $previewArea.html('<div class="sf-empty-form-message"><p>Your form is empty. Click "Add Field" to get started.</p></div>');
            return;
        }

        // Start building the form preview
        let previewHtml = '';

        // Process each field
        fieldsData.forEach(function (field) {
            // Skip if field has no ID or type
            if (!field.id || !field.type) {
                return;
            }

            // Get column width class - ensure it's properly formatted and applied
            const columnWidth = field.column_width || '100';
            const labelPosition = field.label_position || 'left';
            const fieldPosition = field.field_position || 'left';
            // Label text and image toggle independently
            const showLabelText = field.show_label !== false;
            const labelImage = (field.show_label_image !== false) ? (field.label_image || '') : '';
            const labelImagePosition = field.label_image_position || 'left';
            const labelImageClass = labelImage ? ` sf-has-label-image sf-label-img-${labelImagePosition}` : '';
            const columnClass = ` sf-column-${columnWidth} sf-label-${labelPosition} sf-field-position-${fieldPosition}${labelImageClass}`;

            // Option image layout, shared by radio / checkbox / select previews
            const optionImagePosition = field.option_image_position || 'top';
            const optionImageSize = parseInt(field.option_image_size, 10) || 0;
            const optionImageMarkup = function (option) {
                if (!option || !option.image) {
                    return '';
                }
                const sizeStyle = optionImageSize > 0 ? ` style="width:${optionImageSize}px"` : '';
                return `<span class="sf-option-image-wrap"><img class="sf-option-image" src="${window.SF.Utils.escapeHTML(option.image)}" alt=""${sizeStyle}></span>`;
            };

            // Determine if this is a Pro field and license is invalid
            const proTypes = ['file', 'phone_international', 'signature', 'rating', 'section_heading', 'select', 'radio', 'checkbox', 'date', 'country', 'page_break'];
            const isLockedPro = (proTypes.includes(field.type) && !(window.sfLicenseValid === true));
            const lockedAttr = isLockedPro ? ' data-locked="true" style="opacity:0.5; pointer-events:none;" title="Pro field (locked)"' : '';
            const lockedClass = isLockedPro ? ' sf-locked-field' : '';

            // Start field container with the proper column width class
            previewHtml += `<div class="sf-preview-field${columnClass}${lockedClass}" data-field-id="${window.SF.Utils.escapeHTML(field.id)}" data-column-width="${columnWidth}"${lockedAttr}>`;

            // Add field controls overlay (will be non-interactive if locked due to pointer-events:none)
            previewHtml += `
                <div class="sf-field-controls-overlay">
                    <button type="button" class="sf-edit-field sf-field-control" title="Edit field" aria-label="Edit field">${sfIcon('edit')}</button>
                    <button type="button" class="sf-duplicate-field sf-field-control" title="Duplicate field" aria-label="Duplicate field">${sfIcon('copy')}</button>
                    <button type="button" class="sf-delete-field sf-field-control" title="Delete field" aria-label="Delete field">${sfIcon('trash')}</button>
                </div>
            `;

            // Add label if available and show_label is not false (but skip for section headings and page breaks)
            const isStructuralField = (field.type === 'section_heading' || field.type === 'page_break');
            const renderLabelText = showLabelText && !!field.label;

            if (!isStructuralField && (renderLabelText || labelImage)) {
                const requiredMark = field.required ? ' <span class="sf-required">*</span>' : '';
                previewHtml += `<label for="${window.SF.Utils.escapeHTML(field.id)}">`;

                if (labelImage) {
                    const labelImageWidth = parseInt(field.label_image_width, 10) || 0;
                    const labelImageHeight = parseInt(field.label_image_height, 10) || 0;
                    const labelImageFullWidth = !!field.label_image_full_width;
                    const labelImageUnit = field.label_image_width_unit === '%' ? '%' : 'px';
                    // Percent widths live on the wrapper - see get_image_markup()
                    const relativeWidth = labelImageFullWidth || (labelImageUnit === '%' && labelImageWidth > 0);
                    const wrapRules = [];
                    const imageRules = [];

                    if (labelImageFullWidth) {
                        wrapRules.push('width:100%');
                    } else if (labelImageWidth > 0 && labelImageUnit === '%') {
                        wrapRules.push(`width:${Math.min(100, labelImageWidth)}%`);
                    } else if (labelImageWidth > 0) {
                        imageRules.push(`width:${labelImageWidth}px`);
                    }

                    if (relativeWidth) { imageRules.push('width:100%'); }

                    if (labelImageHeight > 0) {
                        // object-fit:contain would letterbox instead of stretching
                        imageRules.push(`height:${labelImageHeight}px`, 'object-fit:fill');
                    }

                    const wrapStyle = wrapRules.length ? ` style="${wrapRules.join(';')}"` : '';
                    const labelSizeStyle = imageRules.length ? ` style="${imageRules.join(';')}"` : '';
                    const wrapSizeClass = (relativeWidth ? ' sf-image-relative-width' : '') + (labelImageFullWidth ? ' sf-image-full-width' : '');
                    previewHtml += '<span class="sf-label-inner">';
                    previewHtml += `<span class="sf-label-image-wrap sf-image-resizable${wrapSizeClass}"${wrapStyle}>` +
                        `<img class="sf-label-image" src="${window.SF.Utils.escapeHTML(labelImage)}" alt=""${labelSizeStyle}>` +
                        getImageResizeHandles() +
                        '</span>';
                    // The required marker belongs to the label text, so it hides with it
                    if (renderLabelText) {
                        previewHtml += `<span class="sf-label-text">${window.SF.Utils.escapeHTML(field.label)}${requiredMark}</span>`;
                    }
                    previewHtml += '</span>';
                } else {
                    previewHtml += `${window.SF.Utils.escapeHTML(field.label)}${requiredMark}`;
                }

                previewHtml += '</label>';
            }

            // Render different field types
            switch (field.type) {
                case 'text':
                case 'email':
                case 'url':
                case 'tel':
                case 'phone': // Handle phone as tel type
                case 'number':
                case 'date':
                    // Use 'tel' HTML type for phone fields
                    const inputType = field.type === 'phone' ? 'tel' : field.type;
                    previewHtml += `<input type="${inputType}" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.placeholder) {
                        previewHtml += ` placeholder="${window.SF.Utils.escapeHTML(field.placeholder)}"`;
                    }
                    if (field.default_value) {
                        previewHtml += ` value="${window.SF.Utils.escapeHTML(field.default_value)}"`;
                    }
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field">';
                    break;

                case 'textarea':
                    previewHtml += `<textarea id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.placeholder) {
                        previewHtml += ` placeholder="${window.SF.Utils.escapeHTML(field.placeholder)}"`;
                    }
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    if (field.textarea_height) {
                        previewHtml += ` style="min-height:${parseInt(field.textarea_height, 10)}px"`;
                    }
                    previewHtml += ' class="sf-field sf-textarea">';
                    if (field.default_value) {
                        previewHtml += window.SF.Utils.escapeHTML(field.default_value);
                    }
                    previewHtml += '</textarea>';
                    break;

                case 'rich_text':
                    previewHtml += '<div class="sf-rich-text-preview">';
                    previewHtml += '<div class="sf-rich-text-toolbar" style="background:#f0f0f1; border:1px solid #ccc; border-bottom:none; padding:5px; display:flex; gap:5px;">';
                    previewHtml += '<span class="dashicons dashicons-editor-bold" style="color:#555;"></span>';
                    previewHtml += '<span class="dashicons dashicons-editor-italic" style="color:#555;"></span>';
                    previewHtml += '<span class="dashicons dashicons-editor-ul" style="color:#555;"></span>';
                    previewHtml += '<span class="dashicons dashicons-editor-ol" style="color:#555;"></span>';
                    previewHtml += '</div>';
                    previewHtml += `<textarea id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.placeholder) {
                        previewHtml += ` placeholder="${window.SF.Utils.escapeHTML(field.placeholder)}"`;
                    }
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field sf-textarea" style="margin-top:0; border-top-left-radius:0; border-top-right-radius:0;">';
                    if (field.default_value) {
                        previewHtml += window.SF.Utils.escapeHTML(field.default_value);
                    }
                    previewHtml += '</textarea></div>';
                    break;

                case 'range':
                    previewHtml += '<div class="sf-range-wrapper" style="display: flex; align-items: center; gap: 10px;">';
                    previewHtml += `<input type="range" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.range_min !== undefined) previewHtml += ` min="${field.range_min}"`;
                    if (field.range_max !== undefined) previewHtml += ` max="${field.range_max}"`;
                    if (field.range_step !== undefined) previewHtml += ` step="${field.range_step}"`;
                    
                    const rangeDefault = field.range_default !== undefined && field.range_default !== '' ? field.range_default : (field.range_min || 0);
                    previewHtml += ` value="${window.SF.Utils.escapeHTML(rangeDefault)}"`;
                    
                    previewHtml += ' class="sf-field sf-range" style="flex: 1;" oninput="this.nextElementSibling.textContent = this.value">';
                    previewHtml += `<span class="sf-range-value">${window.SF.Utils.escapeHTML(rangeDefault)}</span>`;
                    previewHtml += '</div>';
                    break;
                    
                case 'select': {
                    const selectOptions = field.options || [];
                    const selectHasImages = selectOptions.some(function (option) {
                        return !!option.image;
                    });

                    previewHtml += `<select id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field sf-select">';

                    // Add placeholder option
                    if (field.placeholder) {
                        previewHtml += `<option value="">${window.SF.Utils.escapeHTML(field.placeholder)}</option>`;
                    }

                    // Add options
                    selectOptions.forEach(function (option) {
                        const isSelected = field.default_value && option.value === field.default_value ? ' selected' : '';
                        previewHtml += `<option value="${window.SF.Utils.escapeHTML(option.value)}"${isSelected}>${window.SF.Utils.escapeHTML(option.label)}</option>`;
                    });

                    previewHtml += '</select>';

                    // Native <option> cannot render an image, so show the artwork
                    // underneath as a hint of the frontend visual dropdown.
                    if (selectHasImages) {
                        previewHtml += `<div class="sf-select-image-hint sf-options-img-${optionImagePosition}">`;
                        selectOptions.forEach(function (option) {
                            if (option.image) {
                                previewHtml += `<span class="sf-select-image-hint-item">${optionImageMarkup(option)}<span>${window.SF.Utils.escapeHTML(option.label)}</span></span>`;
                            }
                        });
                        previewHtml += '</div>';
                    }
                    break;
                }

                case 'phone_international':
                    previewHtml += '<div class="sf-phone-international-wrapper">';

                    // Country code dropdown - use selected countries if available
                    previewHtml += '<select class="sf-field sf-country-code-select" name="' + window.SF.Utils.escapeHTML(field.name || field.id) + '_country">';

                    // Determine which countries to show
                    let phoneCountriesToShow = COUNTRIES_LIST;
                    if (field.selected_phone_countries && field.selected_phone_countries.length > 0) {
                        phoneCountriesToShow = COUNTRIES_LIST.filter(function (country) {
                            return field.selected_phone_countries.includes(country.code);
                        });
                    } else if (field.available_countries && field.available_countries.length > 0) {
                        phoneCountriesToShow = COUNTRIES_LIST.filter(function (country) {
                            return field.available_countries.includes(country.code);
                        });
                    }

                    const showPhoneFlags = field.show_country_flags !== false;
                    phoneCountriesToShow.forEach(function (country) {
                        const isSelected = (field.default_country && field.default_country === country.code) ? ' selected' : '';
                        const phoneOptionText = showPhoneFlags
                            ? `${country.flag} ${country.phoneCode}`
                            : country.phoneCode;
                        previewHtml += `<option value="${window.SF.Utils.escapeHTML(country.code)}"${isSelected}>${window.SF.Utils.escapeHTML(phoneOptionText)}</option>`;
                    });

                    previewHtml += '</select>';

                    // Phone number input
                    previewHtml += `<input type="tel" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;

                    if (field.placeholder) {
                        previewHtml += ` placeholder="${window.SF.Utils.escapeHTML(field.placeholder)}"`;
                    }

                    if (field.default_value) {
                        previewHtml += ` value="${window.SF.Utils.escapeHTML(field.default_value)}"`;
                    }

                    if (field.required) {
                        previewHtml += ' required';
                    }

                    previewHtml += ' class="sf-field sf-phone-number">';
                    previewHtml += '</div>';
                    break;

                case 'country':
                    previewHtml += `<select id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field sf-select sf-country-select">';

                    // Add placeholder option
                    if (field.placeholder) {
                        previewHtml += `<option value="">${window.SF.Utils.escapeHTML(field.placeholder)}</option>`;
                    } else {
                        previewHtml += `<option value="">Select a country</option>`;
                    }

                    // Add country options
                    if (field.options && field.options.length > 0) {
                        const showFlags = field.show_country_flags !== false;
                        field.options.forEach(function (option) {
                            const isSelected = field.default_value && option.value === field.default_value ? ' selected' : '';
                            const optionText = showFlags
                                ? `${getCountryFlag(option.country_code || option.value)} ${stripCountryFlag(option.label)}`.trim()
                                : stripCountryFlag(option.label);
                            previewHtml += `<option value="${window.SF.Utils.escapeHTML(option.value)}"${isSelected}>${window.SF.Utils.escapeHTML(optionText)}</option>`;
                        });
                    }

                    previewHtml += '</select>';
                    break;

                case 'radio':
                    if (field.options && field.options.length > 0) {
                        previewHtml += `<div class="sf-radio-options sf-columns-${field.options_columns || 1} sf-options-img-${optionImagePosition}">`;
                        field.options.forEach(function (option, index) {
                            const isChecked = field.default_value && option.value === field.default_value ? ' checked' : '';
                            const hasImageClass = option.image ? ' sf-has-option-image' : '';
                            previewHtml += `<div class="sf-radio-option${hasImageClass}">
                                <input type="radio" id="${window.SF.Utils.escapeHTML(field.id + '_' + index)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}" value="${window.SF.Utils.escapeHTML(option.value)}"${isChecked}`;
                            if (field.required) {
                                previewHtml += ' required';
                            }
                            previewHtml += ` class="sf-field sf-radio">
                                <label for="${window.SF.Utils.escapeHTML(field.id + '_' + index)}">${optionImageMarkup(option)}<span class="sf-option-text">${option.label}</span></label>
                            </div>`;
                        });
                        previewHtml += '</div>';
                    }
                    break;

                case 'checkbox':
                    if (field.options && field.options.length > 0) {
                        previewHtml += `<div class="sf-checkbox-options sf-columns-${field.options_columns || 1} sf-options-img-${optionImagePosition}">`;
                        field.options.forEach(function (option, index) {
                            const isChecked = field.default_value && Array.isArray(field.default_value) && field.default_value.includes(option.value) ? ' checked' : '';
                            const hasImageClass = option.image ? ' sf-has-option-image' : '';
                            previewHtml += `<div class="sf-checkbox-option${hasImageClass}">
                                <input type="checkbox" id="${window.SF.Utils.escapeHTML(field.id + '_' + index)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}[]" value="${window.SF.Utils.escapeHTML(option.value)}"${isChecked}`;
                            if (field.required) {
                                previewHtml += ' required';
                            }
                            previewHtml += ` class="sf-field sf-checkbox">
                                <label for="${window.SF.Utils.escapeHTML(field.id + '_' + index)}">${optionImageMarkup(option)}<span class="sf-option-text">${option.label}</span></label>
                            </div>`;
                        });
                        previewHtml += '</div>';
                    }
                    break;

                case 'file':
                    const buttonText = field.upload_button_text || 'Choose a file';
                    previewHtml += `<div class="sf-file-upload-wrapper">
                        <div class="sf-file-upload-content">
                            <div class="sf-file-upload-icon-wrap">
                                <span class="dashicons dashicons-upload sf-file-upload-icon"></span>
                            </div>
                            <div class="sf-file-upload-text-wrap">
                                <div class="sf-file-upload-text">${window.SF.Utils.escapeHTML(buttonText)}</div>
                            </div>
                        </div>
                        <input type="file" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field sf-file" onclick="document.getElementById(\'${window.SF.Utils.escapeHTML(field.id)}\').click()">';
                    previewHtml += '</div>';
                    break;

                case 'signature':
                    previewHtml += `<div class="sf-signature-wrapper">
                        <canvas class="sf-signature-pad" id="${window.SF.Utils.escapeHTML(field.id)}_canvas" width="500" height="200"></canvas>
                        <input type="hidden" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ` class="sf-field sf-signature-data">
                        <div class="sf-signature-actions">
                            <button type="button" class="sf-btn sf-btn-sm sf-clear-signature">Clear</button>
                        </div>
                    </div>`;
                    break;

                case 'rating':
                    // Rating field with 5 gold stars
                    const maxRating = 5;
                    const currentRating = field.default_value ? parseInt(field.default_value) : 0;
                    previewHtml += `<div class="sf-rating-wrapper">`;
                    previewHtml += `<div class="sf-rating-stars" data-rating="${currentRating}">`;
                    for (let i = 1; i <= maxRating; i++) {
                        const filled = i <= currentRating ? ' sf-star-filled' : '';
                        previewHtml += `<span class="sf-rating-star${filled}" data-value="${i}">★</span>`;
                    }
                    previewHtml += `</div>`;
                    previewHtml += `<input type="hidden" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}" value="${currentRating}"`;
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field sf-rating-value">';
                    previewHtml += `</div>`;
                    break;

                case 'section_heading':
                    // Section heading is just a visual divider/heading
                    const showUnderline = field.show_underline !== false;
                    const underlineColor = field.underline_color || '#3b82f6';
                    const underlineThickness = field.underline_thickness || '3';
                    const underlineStyle = field.underline_style || 'solid';
                    
                    let headingStyle = '';
                    if (showUnderline) {
                        headingStyle = `style="border-bottom: ${underlineThickness}px ${underlineStyle} ${underlineColor};"`;
                    } else {
                        headingStyle = `style="border-bottom: none;"`;
                    }
                    
                    previewHtml += `<div class="sf-section-heading">
                        <h3 ${headingStyle}>${window.SF.Utils.escapeHTML(field.label || 'Section Heading')}</h3>
                    </div>`;
                    break;

                case 'page_break':
                    // Page break creates a new step/page in multi-step forms
                    previewHtml += `<div class="sf-page-break">
                        <div class="sf-page-break-line"></div>
                        <div class="sf-page-break-label">
                            <span class="dashicons dashicons-media-document"></span>
                            ${window.SF.Utils.escapeHTML(field.label || 'Page Break')}
                        </div>
                        <div class="sf-page-break-line"></div>
                    </div>`;
                    break;

                default:
                    previewHtml += `<input type="text" id="${window.SF.Utils.escapeHTML(field.id)}" name="${window.SF.Utils.escapeHTML(field.name || field.id)}"`;
                    if (field.placeholder) {
                        previewHtml += ` placeholder="${window.SF.Utils.escapeHTML(field.placeholder)}"`;
                    }
                    if (field.default_value) {
                        previewHtml += ` value="${window.SF.Utils.escapeHTML(field.default_value)}"`;
                    }
                    if (field.required) {
                        previewHtml += ' required';
                    }
                    previewHtml += ' class="sf-field">';
            }

            // Add help text if present
            if (field.help_text) {
                previewHtml += `<div class="sf-field-help-text">${window.SF.Utils.escapeHTML(field.help_text)}</div>`;
            }

            previewHtml += '</div>'; // Close field container
        });

        // Add the submit button at the end of the preview
        const submitText = (window.sfFormSettings && window.sfFormSettings.submit_button_text) ? window.sfFormSettings.submit_button_text : 'Submit';
        const submitWidth = (window.sfFormSettings && window.sfFormSettings.submit_button_width) ? window.sfFormSettings.submit_button_width : 'auto';
        const submitAlign = (window.sfFormSettings && window.sfFormSettings.submit_button_align) ? window.sfFormSettings.submit_button_align : 'left';
        const alignClass = 'sf-button-align-' + submitAlign;

        previewHtml += `
            <div class="sf-preview-submit-button ${alignClass}">
                <button type="button" class="sf-edit-submit-button sf-btn sf-btn-primary">
                    ${sfIcon('check')} ${submitText}
                </button>
                <div class="sf-field-controls-overlay">
                    <button type="button" class="sf-edit-field sf-field-control" title="Edit Submit Button" aria-label="Edit Submit Button">${sfIcon('edit')}</button>
                </div>
            </div>
        `;

        // Add the preview HTML to the preview area
        $previewArea.html(previewHtml);

        // Set submit button width and data attribute
        const $submitBtn = $('.sf-edit-submit-button');
        $submitBtn.data('width', submitWidth);
        if (submitWidth === '100') {
            $submitBtn.css('width', '100%');
        } else if (submitWidth === 'auto') {
            $submitBtn.css('width', 'auto');
        } else {
            $submitBtn.css('width', submitWidth + '%');
        }

        // Make fields sortable
        $previewArea.sortable({
            items: '.sf-preview-field',
            placeholder: 'sf-field-sortable-placeholder',
            tolerance: 'pointer',
            cursor: 'move',
            // Dragging a resize handle must not start a field re-order
            cancel: 'input,textarea,button,select,option,.sf-image-resize-handle',
            update: function () {
                // Update the order of fields in the data
                updateFieldsOrder();
            }
        });
    }

    // Resizer functionality removed

    /**
     * Open the field type selection modal
     */
    function openFieldTypeModal() {
        $('.sf-field-type-modal').fadeIn(200);
    }

    /**
     * Close the field type selection modal
     */
    function closeFieldTypeModal() {
        $('.sf-field-type-modal').fadeOut(200);
    }

    /**
     * Initialize AI Chat Widget
     */
    function initAIChatWidget() {
        const $chatButton = $('.sf-ai-chat-button');
        const $chatWindow = $('.sf-ai-chat-window');
        const $chatInput = $('.sf-ai-chat-input');
        const $sendButton = $('.sf-ai-chat-send');
        const $minimizeButton = $('.sf-ai-chat-minimize');

        // Toggle chat window
        $chatButton.on('click', function () {
            $chatWindow.toggle();
            $chatButton.toggleClass('active');

            if ($chatWindow.is(':visible')) {
                $chatInput.focus();
                scrollChatToBottom();
            }
        });

        // Minimize chat
        $minimizeButton.on('click', function () {
            $chatWindow.hide();
            $chatButton.removeClass('active');
        });

        // Send message on button click
        $sendButton.on('click', function () {
            sendChatMessage();
        });

        // Send message on Enter key (Shift+Enter for new line)
        $chatInput.on('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendChatMessage();
            }
        });

        // Auto-resize textarea
        $chatInput.on('input', function () {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });

        // Handle suggestion chips
        $(document).on('click', '.sf-ai-suggestion-chip', function () {
            const suggestion = $(this).data('suggestion');
            $chatInput.val(suggestion).trigger('input');
            $chatInput.focus();
        });
    }

    /**
     * Send chat message
     */
    function sendChatMessage() {
        const $chatInput = $('.sf-ai-chat-input');
        const $sendButton = $('.sf-ai-chat-send');
        const message = $chatInput.val().trim();

        if (!message) return;

        // Add user message to chat
        addChatMessage(message, 'user');

        // Clear input
        $chatInput.val('').trigger('input');

        // Disable send button
        $sendButton.prop('disabled', true);

        // Show typing indicator
        showTypingIndicator();

        // Process with AI
        processAIChatMessage(message);
    }

    /**
     * Add message to chat
     */
    function addChatMessage(message, sender) {
        const $messagesContainer = $('.sf-ai-chat-messages');
        const currentTime = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

        const isUser = sender === 'user';
        const avatarIcon = isUser ?
            '<svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/></svg>' :
            '<svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>';

        const messageHTML = `
            <div class="sf-ai-chat-message ${isUser ? 'sf-user-message' : 'sf-ai-message'}">
                <div class="sf-ai-message-avatar">
                    ${avatarIcon}
                </div>
                <div class="sf-ai-message-content">
                    <div class="sf-ai-message-bubble">
                        ${escapeHtml(message)}
                    </div>
                    <div class="sf-ai-message-time">${currentTime}</div>
                </div>
            </div>
        `;

        $messagesContainer.append(messageHTML);
        scrollChatToBottom();
    }

    /**
     * Show typing indicator
     */
    function showTypingIndicator() {
        const $messagesContainer = $('.sf-ai-chat-messages');
        const typingHTML = `
            <div class="sf-ai-chat-message sf-ai-message sf-typing-message">
                <div class="sf-ai-message-avatar">
                    <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                    </svg>
                </div>
                <div class="sf-ai-message-content">
                    <div class="sf-ai-message-bubble">
                        <div class="sf-ai-typing-indicator">
                            <div class="sf-ai-typing-dot"></div>
                            <div class="sf-ai-typing-dot"></div>
                            <div class="sf-ai-typing-dot"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $messagesContainer.append(typingHTML);
        scrollChatToBottom();
    }

    /**
     * Remove typing indicator
     */
    function removeTypingIndicator() {
        $('.sf-typing-message').remove();
    }

    /**
     * Process AI chat message
     */
    function processAIChatMessage(userMessage) {
        const $sendButton = $('.sf-ai-chat-send');

        // Ensure sfFieldsData exists
        if (typeof window.sfFieldsData === 'undefined' || !Array.isArray(window.sfFieldsData)) {
            window.sfFieldsData = [];
        }

        // Call AI API to generate new fields
        $.ajax({
            url: sfAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_generate_form',
                nonce: sfAdmin.nonce,
                prompt: userMessage
            },
            success: function (response) {
                removeTypingIndicator();

                if (response.success && response.data && response.data.form && response.data.form.fields) {
                    const newFields = response.data.form.fields;

                    // Add the generated fields to the existing form
                    newFields.forEach(function (field) {
                        // Generate unique ID for new field
                        field.id = 'field_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
                        field.name = field.id;

                        // Add to fields data
                        window.sfFieldsData.push(field);
                    });

                    // Re-render the form
                    renderVisualFormPreview(window.sfFieldsData);

                    // Add success message to chat
                    const successMsg = `Great! I've added ${newFields.length} field${newFields.length > 1 ? 's' : ''} to your form. You can see ${newFields.length > 1 ? 'them' : 'it'} in the preview. Want to add more fields?`;
                    addChatMessage(successMsg, 'ai');
                } else {
                    const errorMsg = (response.data && response.data.message) ? response.data.message : 'I couldn\'t generate those fields. Could you try rephrasing your request?';
                    addChatMessage(errorMsg, 'ai');
                }

                // Re-enable send button
                $sendButton.prop('disabled', false);
            },
            error: function (xhr, status, error) {
                removeTypingIndicator();
                addChatMessage('Something went wrong. Please check your connection and try again.', 'ai');

                // Re-enable send button
                $sendButton.prop('disabled', false);
            }
        });
    }

    /**
     * Scroll chat to bottom
     */
    function scrollChatToBottom() {
        const $messagesContainer = $('.sf-ai-chat-messages');
        $messagesContainer.scrollTop($messagesContainer[0].scrollHeight);
    }

    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function (m) { return map[m]; });
    }

    /**
     * Open AI Expand Modal (Legacy - kept for compatibility)
     */
    function openAIExpandModal() {
        $('.sf-ai-expand-modal').fadeIn(200);
        $('#sf-ai-expand-prompt').focus();
    }

    /**
     * Close AI Expand Modal (Legacy - kept for compatibility)
     */
    function closeAIExpandModal() {
        $('.sf-ai-expand-modal').fadeOut(200);
        $('#sf-ai-expand-prompt').val('');
        $('.sf-ai-result-message').hide();
    }

    /**
     * Show AI Expand Message (Legacy - kept for compatibility)
     */
    function showAIExpandMessage(message, type) {
        const $message = $('.sf-ai-expand-modal .sf-ai-result-message');
        $message
            .removeClass('success error')
            .addClass(type)
            .html(message)
            .fadeIn(200);
    }

    /**
     * Generate expanded fields using AI (Legacy - kept for compatibility)
     */
    function generateExpandedFields(prompt) {
        const $generateBtn = $('.sf-ai-expand-generate-button');
        const originalText = $generateBtn.html();

        // Disable button and show loading state
        $generateBtn.prop('disabled', true).html('Generating...');
        showAIExpandMessage('AI is analyzing your request and generating fields...', 'success');

        // Ensure sfFieldsData exists
        if (typeof window.sfFieldsData === 'undefined' || !Array.isArray(window.sfFieldsData)) {
            window.sfFieldsData = [];
        }

        // Call AI API to generate new fields
        $.ajax({
            url: sfAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_generate_form',
                nonce: sfAdmin.nonce,
                prompt: prompt
            },
            success: function (response) {
                if (response.success && response.data && response.data.form && response.data.form.fields) {
                    const newFields = response.data.form.fields;

                    // Add the generated fields to the existing form
                    newFields.forEach(function (field) {
                        // Generate unique ID for new field
                        field.id = 'field_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
                        field.name = field.id;

                        // Add to fields data
                        window.sfFieldsData.push(field);
                    });

                    // Re-render the form
                    renderVisualFormPreview(window.sfFieldsData);

                    // Show success message
                    showAIExpandMessage('Successfully added ' + newFields.length + ' new field(s)!', 'success');

                    // Close modal after short delay
                    setTimeout(function () {
                        closeAIExpandModal();
                    }, 1500);
                } else {
                    const errorMsg = (response.data && response.data.message) ? response.data.message : 'Failed to generate fields. Please try again.';
                    showAIExpandMessage(errorMsg, 'error');
                }

                // Re-enable button
                $generateBtn.prop('disabled', false).html(originalText);
            },
            error: function (xhr, status, error) {
                showAIExpandMessage('Something went wrong. Please check your connection and try again.', 'error');

                // Re-enable button
                $generateBtn.prop('disabled', false).html(originalText);
            }
        });
    }

    /**
     * Get default placeholder text based on field type
     * 
     * @param {string} fieldType The type of field
     * @return {string} Default placeholder text
     */
    function getDefaultPlaceholderForType(fieldType) {
        const placeholders = {
            'text': 'Enter your text here',
            'email': 'Enter your email address',
            'phone': 'Enter your phone number',
            'phone_international': 'Enter phone number',
            'number': 'Enter a number',
            'date': 'Select a date',
            'textarea': 'Enter your message here',
            'select': 'Select an option',
            'country': 'Select a country',
            'radio': '',
            'checkbox': '',
            'file': '',
            'section_heading': '',
            'page_break': ''
        };

        return placeholders[fieldType] || 'Enter your text here';
    }

    /**
     * Add a new field of the specified type
     * 
     * @param {string} fieldType The type of field to add
     */
    function addNewField(fieldType) {

        // Generate a unique ID for the field with random component to ensure uniqueness
        const randomId = Math.floor(Math.random() * 100000);
        const fieldId = 'field_' + Date.now() + '_' + randomId;

        // Get default placeholder based on field type
        const defaultPlaceholder = getDefaultPlaceholderForType(fieldType);

        // Create a new field object
        const newField = {
            id: fieldId,
            name: fieldId, // Add name property with same value as ID initially
            type: fieldType,
            label: window.SF.Utils.getDefaultLabelForType(fieldType),
            placeholder: defaultPlaceholder,
            default_value: '', // Add default_value property
            required: false,
            column_width: '100',
            show_label: true,
            help_text: '',
            options_columns: '1',
            field_position: 'left', // Default field position
            unsaved: true // mark as unsaved until settings are saved
        };

        // Add options if field type needs them
        if (['select', 'radio', 'checkbox'].includes(fieldType)) {
            newField.options = [
                { value: 'option1', label: 'Option 1' },
                { value: 'option2', label: 'Option 2' }
            ];
        }

        // Add country options for country field type
        if (fieldType === 'country') {
            newField.selected_countries = []; // No countries selected by default
            newField.options = COUNTRIES_LIST.map(function (country) {
                return {
                    value: country.code,
                    label: country.flag + ' ' + country.name
                };
            });
        }

        // Add phone_international field specific properties
        if (fieldType === 'phone_international') {
            newField.default_country = 'BD'; // Default to Bangladesh
            newField.selected_phone_countries = []; // No countries selected by default
            newField.available_countries = []; // Will be populated when user selects countries
        }

        // Add file upload field specific properties with default allowed types
        if (fieldType === 'file') {
            newField.allowed_file_types = ['.pdf', '.doc', '.docx', '.jpg', '.jpeg', '.png']; // Safe document/image defaults
            newField.custom_file_extensions = ''; // No custom extensions by default
            newField.upload_button_text = 'Choose a file'; // Default button text
            newField.storage_location = 'site'; // Default to site storage
        }

        // Add signature field specific properties
        if (fieldType === 'signature') {
            newField.storage_location = 'site'; // Default to site storage
        }

        // Add section heading field specific properties
        if (fieldType === 'section_heading') {
            newField.show_underline = true; // Show underline by default
            newField.underline_color = '#3b82f6'; // Default blue color
            newField.underline_thickness = '3'; // Default 3px thickness
            newField.underline_style = 'solid'; // Default solid style
        }

        // Ensure sfFieldsData is initialized
        if (typeof sfFieldsData === 'undefined' || !Array.isArray(sfFieldsData)) {
            window.sfFieldsData = [];
        }

        // Add field to data array
        sfFieldsData.push(newField);

        // Update the form preview
        renderVisualFormPreview(sfFieldsData);

        // Trigger field added event
        $(document).trigger('sf:field_added');

        // Open field settings for the new field
        setTimeout(function () {
            openFieldSettings(fieldId);
        }, 100);
    }

    /**
     * Open the field settings popup for editing a field
     * 
     * @param {string} fieldId Field ID
     */
    function openFieldSettings(fieldId) {

        if (typeof sfFieldsData === 'undefined') {
            return;
        }

        const field = sfFieldsData.find(f => {
            return f.id === fieldId;
        });

        if (!field) {
            return;
        }

        // Check if this field has math function data
        const hasMath = field.math && field.math.enabled === true;

        const $popup = $('.sf-field-settings-popup');

        // --- Consolidated Logic ---
        // 1. Reset popup state for a standard field
        $popup.removeData('form-element-type');
        $popup.find('.sf-settings-group').hide();
        $popup.find('.sf-settings-group-field').show();
        $popup.find('.sf-settings-tab').show();

        // 2. Store current field ID and update title
        $popup.data('field-id', fieldId);
        $popup.find('.sf-field-settings-title').text('Edit ' + field.label);

        // 3. Fill in basic settings
        $popup.find('.sf-field-type').val(field.type);
        $popup.find('.sf-field-id').val(field.id);
        $popup.find('.sf-field-name').val(field.name || field.id);
        $popup.find('.sf-field-label').val(field.label);
        $popup.find('.sf-field-placeholder').val(field.placeholder || '');
        $popup.find('.sf-textarea-height').val(field.textarea_height || '');
        $popup.find('.sf-field-default').val(field.default_value || '');
        $popup.find('.sf-field-required').prop('checked', field.required || false);
        $popup.find('.sf-field-required-message').val(field.required_message || '');
        $popup.find('.sf-field-help-text').val(field.help_text || '');
        $popup.find('.sf-field-css-class').val(field.css_class || '');
        $popup.find('.sf-field-validation-message').val(field.validation_message || '');
        // Show format validation message row only for types that have format validation
        const typesWithFormatValidation = ['email', 'url', 'number', 'phone'];
        if (typesWithFormatValidation.includes(field.type)) {
            $popup.find('.sf-validation-message-row').show();
        } else {
            $popup.find('.sf-validation-message-row').hide();
        }

        // 4. Fill in advanced settings
        $popup.find('.sf-field-column-width').val(field.column_width || '100');
        $popup.find('.sf-field-label-position').val(field.label_position || 'left');
        $popup.find('.sf-field-position').val(field.field_position || 'left');
        $popup.find('.sf-field-show-label').prop('checked', field.show_label !== false);
        $popup.find('.sf-field-show-label-image').prop('checked', field.show_label_image !== false);
        $popup.find('.sf-field-options-columns').val(field.options_columns || '1');

        // Label image
        $popup.find('.sf-field-label-image').val(field.label_image || '');
        $popup.find('.sf-field-label-image-id').val(field.label_image_id || '');
        $popup.find('.sf-field-label-image-source-id').val(field.label_image_source_id || field.label_image_id || '');
        $popup.find('.sf-field-label-image-position').val(field.label_image_position || 'left');
        $popup.find('.sf-field-label-image-width').val(field.label_image_width || '');
        $popup.find('.sf-field-label-image-height').val(field.label_image_height || '');
        $popup.find('.sf-field-label-image-width-unit').val(field.label_image_width_unit === 'px' ? 'px' : '%');
        $popup.find('.sf-field-label-image-full-width').prop('checked', !!field.label_image_full_width);
        $popup.find('.sf-field-label-image-width, .sf-field-label-image-width-unit')
            .prop('disabled', !!field.label_image_full_width);
        renderImagePickerPreview($popup.find('.sf-image-picker[data-target="sf-field-label-image"]'));
        toggleLabelImageOptions();

        // Option images
        $popup.find('.sf-field-option-image-position').val(field.option_image_position || 'top');
        $popup.find('.sf-field-option-image-size').val(field.option_image_size || '');
        $popup.find('.sf-option-image-options-row').toggle(['select', 'radio', 'checkbox'].includes(field.type));

        // Country flag icons
        $popup.find('.sf-field-show-country-flags').prop('checked', field.show_country_flags !== false);
        $popup.find('.sf-country-flags-row').toggle(['country', 'phone_international'].includes(field.type));
        if (['checkbox', 'radio'].includes(field.type)) {
            $popup.find('.sf-options-columns-row').show();
        } else {
            $popup.find('.sf-options-columns-row').hide();
        }

        // 5. Handle options for select, radio, checkbox, country, phone_international
        if (['select', 'radio', 'checkbox'].includes(field.type)) {
            $popup.find('.sf-field-row.sf-options-row').show();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-section-underline-settings').hide();
            $popup.find('.sf-field-options-list').empty();

            if (field.options && field.options.length > 0) {
                field.options.forEach(function (option) {
                    addOptionToSettings(option.value, option.label, option.image || '', option.image_id || '', option.image_source_id || '');
                });
            }
        } else if (field.type === 'country') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').show();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-section-underline-settings').hide();

            // Determine selected countries with multiple fallback strategies
            let selectedCountries = [];

            // Strategy 1: Check for selected_countries property (primary)
            if (field.selected_countries && Array.isArray(field.selected_countries) && field.selected_countries.length > 0) {
                selectedCountries = field.selected_countries;
            }
            // Strategy 2: Check options array (secondary)
            else if (field.options && Array.isArray(field.options) && field.options.length > 0 && field.options.length < COUNTRIES_LIST.length) {
                selectedCountries = field.options.map(option => option.value);
            }
            // Strategy 3: Check if this is a newly created field vs saved field
            else if (field.options && Array.isArray(field.options) && field.options.length === COUNTRIES_LIST.length) {
                selectedCountries = [];
            }
            else {
                selectedCountries = [];
            }

            // Initialize country selection interface with pre-selected countries
            initCountrySelectionInterface(selectedCountries);
        } else if (field.type === 'phone_international') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').show();
            $popup.find('.sf-section-underline-settings').hide();

            // Determine selected phone countries with multiple fallback strategies
            let selectedPhoneCountries = [];

            // Strategy 1: Check for selected_phone_countries property (primary)
            if (field.selected_phone_countries && Array.isArray(field.selected_phone_countries) && field.selected_phone_countries.length > 0) {
                selectedPhoneCountries = field.selected_phone_countries;
            }
            // Strategy 2: Check available_countries array (secondary)
            else if (field.available_countries && Array.isArray(field.available_countries) && field.available_countries.length > 0 && field.available_countries.length < COUNTRIES_LIST.length) {
                selectedPhoneCountries = field.available_countries;
            }
            // Strategy 3: Check if this is a newly created field vs saved field
            else if (field.available_countries && Array.isArray(field.available_countries) && field.available_countries.length === COUNTRIES_LIST.length) {
                selectedPhoneCountries = [];
            }
            else {
                selectedPhoneCountries = [];
            }

            // Initialize phone country selection interface with pre-selected countries
            initPhoneCountrySelectionInterface(selectedPhoneCountries);
        } else if (field.type === 'file') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-section-underline-settings').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').show();
            $popup.find('.sf-field-row.sf-custom-extensions-row').show();
            $popup.find('.sf-field-row.sf-file-size-limit-row').show();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').show();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').show();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').show();
            $popup.find('.sf-field-row.sf-upload-button-text-row').show();
            $popup.find('.sf-field-row.sf-storage-location-row').show();

            // Get selected file types and custom extensions
            const selectedFileTypes = field.allowed_file_types || [];
            const customExtensions = field.custom_file_extensions || '';

            // Get file size limit values
            const fileSizeValue = field.max_file_size_value || '';
            const fileSizeUnit = field.max_file_size_unit || 'MB';

            // Get allow multiple setting
            const allowMultiple = field.allow_multiple || false;

            // Get max files
            const maxFiles = field.max_files || '';

            // Get button text
            const uploadButtonText = field.upload_button_text || 'Choose a file';

            // Get storage location
            const storageLocation = field.storage_location || 'site';

            // Populate file size limit fields
            $popup.find('.sf-file-size-value').val(fileSizeValue);
            $popup.find('.sf-file-size-unit').val(fileSizeUnit);

            // Populate custom error messages
            $popup.find('.sf-file-size-error-message').val(field.file_size_error_message || '');
            $popup.find('.sf-file-type-error-message').val(field.file_type_error_message || '');
            $popup.find('.sf-cloud-upload-error-message').val(field.cloud_upload_error_message || '');
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').show();

            // Populate allow multiple checkbox
            $popup.find('.sf-allow-multiple-files').prop('checked', allowMultiple);

            // Populate max files and show/hide based on allow multiple
            $popup.find('.sf-max-files').val(maxFiles);
            if (allowMultiple) {
                $popup.find('.sf-field-row.sf-max-files-row').show();
            } else {
                $popup.find('.sf-field-row.sf-max-files-row').hide();
            }

            // Populate button text
            $popup.find('.sf-upload-button-text').val(uploadButtonText);

            // Populate storage location - check if option exists, fallback to 'site' if not
            const $storageSelect = $popup.find('.sf-storage-location');
            const optionExists = $storageSelect.find('option[value="' + storageLocation + '"]').length > 0;
            $storageSelect.val(optionExists ? storageLocation : 'site');

            // Initialize file types selection interface
            initFileTypesSelectionInterface(selectedFileTypes, customExtensions);
        } else if (field.type === 'signature') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-section-underline-settings').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').hide();
            $popup.find('.sf-field-row.sf-custom-extensions-row').hide();
            $popup.find('.sf-field-row.sf-file-size-limit-row').hide();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').hide();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').hide();
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').hide();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').hide();
            $popup.find('.sf-field-row.sf-max-files-row').hide();
            $popup.find('.sf-field-row.sf-upload-button-text-row').hide();
            $popup.find('.sf-field-row.sf-storage-location-row').show();

            // Get storage location
            const signatureStorageLocation = field.storage_location || 'site';

            // Populate storage location - check if option exists, fallback to 'site' if not
            const $storageSelect = $popup.find('.sf-storage-location');
            const optionExists = $storageSelect.find('option[value="' + signatureStorageLocation + '"]').length > 0;
            $storageSelect.val(optionExists ? signatureStorageLocation : 'site');
        } else if (field.type === 'range') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').hide();
            $popup.find('.sf-field-row.sf-custom-extensions-row').hide();
            $popup.find('.sf-field-row.sf-file-size-limit-row').hide();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').hide();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').hide();
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').hide();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').hide();
            $popup.find('.sf-field-row.sf-max-files-row').hide();
            $popup.find('.sf-field-row.sf-upload-button-text-row').hide();
            $popup.find('.sf-field-row.sf-storage-location-row').hide();
            $popup.find('.sf-section-underline-settings').hide();
            
            // Show range settings row
            $popup.find('.sf-range-settings-row').show();
            
            // Populate range settings
            $popup.find('.sf-range-min').val(field.range_min || '0');
            $popup.find('.sf-range-max').val(field.range_max || '100');
            $popup.find('.sf-range-step').val(field.range_step || '1');
            $popup.find('.sf-range-default').val(field.range_default || '50');
        } else if (field.type === 'section_heading') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').hide();
            $popup.find('.sf-field-row.sf-custom-extensions-row').hide();
            $popup.find('.sf-field-row.sf-file-size-limit-row').hide();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').hide();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').hide();
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').hide();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').hide();
            $popup.find('.sf-field-row.sf-max-files-row').hide();
            $popup.find('.sf-field-row.sf-upload-button-text-row').hide();
            $popup.find('.sf-field-row.sf-storage-location-row').hide();
            $popup.find('.sf-range-settings-row').hide();
            
            // Show section underline settings row
            $popup.find('.sf-section-underline-settings').show();
            
            // Populate underline settings with defaults
            $popup.find('.sf-section-show-underline').prop('checked', field.show_underline !== false);
            $popup.find('.sf-section-underline-color').val(field.underline_color || '#3b82f6');
            $popup.find('.sf-section-underline-thickness').val(field.underline_thickness || '3');
            $popup.find('.sf-section-underline-style').val(field.underline_style || 'solid');
            
            // Show/hide underline options based on show_underline toggle
            if (field.show_underline === false) {
                $popup.find('.sf-underline-options').hide();
            } else {
                $popup.find('.sf-underline-options').show();
            }
        } else if (field.type === 'page_break') {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').hide();
            $popup.find('.sf-field-row.sf-custom-extensions-row').hide();
            $popup.find('.sf-field-row.sf-file-size-limit-row').hide();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').hide();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').hide();
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').hide();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').hide();
            $popup.find('.sf-field-row.sf-max-files-row').hide();
            $popup.find('.sf-field-row.sf-upload-button-text-row').hide();
            $popup.find('.sf-field-row.sf-storage-location-row').hide();
            $popup.find('.sf-range-settings-row').hide();
            $popup.find('.sf-section-underline-settings').hide();
            
            // Show page break settings
            $popup.find('.sf-page-break-settings').show();
            
            // Populate page break settings with defaults
            $popup.find('.sf-page-break-next-text').val(field.next_button_text || 'Next');
            $popup.find('.sf-page-break-previous-text').val(field.previous_button_text || 'Previous');
            $popup.find('.sf-page-break-step-format').val(field.step_indicator_format || 'Step {current} of {total}');
            $popup.find('.sf-page-break-validation-message').val(field.validation_message || 'Please fill in all required fields before proceeding.');
            
            // Populate page break color settings
            $popup.find('.sf-page-break-next-bg-color').val(field.next_button_bg_color || '#6366f1');
            $popup.find('.sf-page-break-next-text-color').val(field.next_button_text_color || '#ffffff');
            $popup.find('.sf-page-break-prev-bg-color').val(field.prev_button_bg_color || '#ffffff');
            $popup.find('.sf-page-break-prev-text-color').val(field.prev_button_text_color || '#374151');
            $popup.find('.sf-page-break-step-text-color').val(field.step_indicator_text_color || '#6b7280');
        } else {
            $popup.find('.sf-field-row.sf-options-row').hide();
            $popup.find('.sf-field-row.sf-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-phone-country-selection-row').hide();
            $popup.find('.sf-field-row.sf-file-types-selection-row').hide();
            $popup.find('.sf-field-row.sf-custom-extensions-row').hide();
            $popup.find('.sf-field-row.sf-file-size-limit-row').hide();
            $popup.find('.sf-field-row.sf-file-size-error-message-row').hide();
            $popup.find('.sf-field-row.sf-file-type-error-message-row').hide();
            $popup.find('.sf-field-row.sf-cloud-upload-error-message-row').hide();
            $popup.find('.sf-field-row.sf-allow-multiple-files-row').hide();
            $popup.find('.sf-field-row.sf-max-files-row').hide();
            $popup.find('.sf-field-row.sf-upload-button-text-row').hide();
            $popup.find('.sf-field-row.sf-storage-location-row').hide();
            $popup.find('.sf-section-underline-settings').hide();
        }

        // 6. Handle conditional logic
        const hasConditional = field.conditional && Object.keys(field.conditional).length > 0;

        if (hasConditional) {
            $popup.find('.sf-field-has-conditional').prop('checked', true);
            $popup.find('.sf-conditional-rules').show();

            if (field.conditional.action && field.conditional.groups) {
                $popup.find('.sf-conditional-action').val(field.conditional.action || 'show');
                $popup.find('.sf-conditional-logic-type').val(field.conditional.logic_type || 'all');
                $popup.find('.sf-condition-groups').empty();

                if (field.conditional.groups && field.conditional.groups.length > 0) {
                    field.conditional.groups.forEach(function (group, groupIndex) {
                        const $group = $(`<div class="sf-condition-group" data-group-id="${groupIndex}"></div>`);
                        if (groupIndex > 0) {
                            $popup.find('.sf-condition-groups').append('<div class="sf-group-separator"><span>OR</span></div>');
                        }
                        if (group.rules && group.rules.length > 0) {
                            group.rules.forEach(function (rule, ruleIndex) {
                                const $rule = createAdvancedRuleElement(rule, ruleIndex);
                                $group.append($rule);
                            });
                        }
                        $popup.find('.sf-condition-groups').append($group);
                    });
                } else {
                    createDefaultConditionalRule();
                }
            } else if (field.conditional.field && field.conditional.operator && field.conditional.value !== undefined) {
                $popup.find('.sf-conditional-action').val(field.conditional.show !== false ? 'show' : 'hide');
                $popup.find('.sf-conditional-logic-type').val('all');
                $popup.find('.sf-condition-groups').empty();
                const $group = $('<div class="sf-condition-group" data-group-id="0"></div>');
                const rule = {
                    source_type: 'field',
                    field: field.conditional.field,
                    operator: field.conditional.operator,
                    value: field.conditional.value
                };
                const $rule = createAdvancedRuleElement(rule, 0);
                $group.append($rule);
                $popup.find('.sf-condition-groups').append($group);
            } else {
                $popup.find('.sf-field-has-conditional').prop('checked', false);
                $popup.find('.sf-conditional-rules').hide();
                createDefaultConditionalRule();
            }
        } else {
            $popup.find('.sf-field-has-conditional').prop('checked', false);
            $popup.find('.sf-conditional-rules').hide();
            createDefaultConditionalRule();
        }

        updateSettingsConditionalFields(fieldId);

        setTimeout(function () {
            $popup.find('.sf-condition-groups .sf-condition-rule').each(function () {
                const $rule = $(this);
                const sourceType = $rule.find('.sf-rule-source-type').val();
                const currentOperator = $rule.find('.sf-conditional-operator').val();

                if (window.SF.ConditionalLogic) {
                    if (sourceType === 'field') {
                        const $fieldSelect = $rule.find('.sf-conditional-field');
                        const selectedField = $fieldSelect.val();
                        if (selectedField) {
                            const $selectedOption = $fieldSelect.find('option:selected');
                            const fieldType = $selectedOption.data('field-type');
                            if (fieldType && window.SF.ConditionalLogic.updateOperatorsForFieldType) {
                                window.SF.ConditionalLogic.updateOperatorsForFieldType($rule, fieldType, currentOperator);
                            } else if (window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                                window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, 'field', currentOperator);
                            }
                        } else if (window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                            window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, 'field', currentOperator);
                        }
                    } else if (sourceType === 'user') {
                        const userDataType = $rule.find('.sf-conditional-user-data').val();
                        if (window.SF.ConditionalLogic.updateOperatorsForUserDataType) {
                            window.SF.ConditionalLogic.updateOperatorsForUserDataType($rule, userDataType, currentOperator);

                            // Also update value input type for user data
                            if (window.SF.ConditionalLogic.updateValueInputForUserDataType) {
                                window.SF.ConditionalLogic.updateValueInputForUserDataType($rule, userDataType);
                            }
                        }
                    } else if (sourceType === 'date') {
                        if (window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                            window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, 'date', currentOperator);
                        }
                    }

                    if (currentOperator) {
                        setTimeout(function () {
                            $rule.find('.sf-conditional-operator').val(currentOperator);
                        }, 50);
                    }
                }
            });
        }, 200);

        // 7. Handle math function
        if (hasMath) {
            $popup.find('.sf-field-has-math').prop('checked', true);
            $popup.find('.sf-math-rules').show();

            if (field.math.calculation_type) {
                $popup.find('.sf-math-calculation-type').val(field.math.calculation_type);

                if (field.math.calculation_type === 'custom') {
                    $('.sf-math-custom-formula').show();
                    $('.sf-math-fields-container').hide();
                    if (field.math.formula) {
                        $('.sf-math-formula').val(field.math.formula);
                    }
                } else {
                    $('.sf-math-custom-formula').hide();
                    $('.sf-math-fields-container').show();

                    // Populate math fields
                    const $mathFieldsList = $('.sf-math-fields-list');
                    $mathFieldsList.empty();

                    if (field.math.fields && field.math.fields.length > 0) {

                        // First create all the field containers
                        field.math.fields.forEach(function (fieldId, index) {
                            addMathField(); // Create without selectedFieldId first
                        });

                        // Then set the values on each field
                        $mathFieldsList.find('.sf-math-field-select').each(function (index) {
                            if (field.math.fields[index]) {
                                const fieldId = field.math.fields[index];
                                $(this).val(fieldId);
                            }
                        });

                    } else {
                        addMathField(); // Add at least one field
                    }
                }

                // Set other math options
                if (field.math.round_result !== undefined) {
                    $('.sf-math-round-result').prop('checked', field.math.round_result);
                    $('.sf-math-round-options').toggle(field.math.round_result);
                }

                if (field.math.decimal_places !== undefined) {
                    $('.sf-math-decimal-places').val(field.math.decimal_places);
                }
            }
        } else {
            $popup.find('.sf-field-has-math').prop('checked', false);
            $popup.find('.sf-math-rules').hide();
            const $mathFieldsList = $('.sf-math-fields-list');
            $mathFieldsList.empty();
            addMathField(); // Add default field
        }

        // Update math preview
        updateMathPreview();

        // Calculate and display the math result immediately if math function is enabled
        if (hasMath && field.math && field.math.enabled) {
            setTimeout(function () {
                calculateMathFieldInEditor();
            }, 200);
        }

        // Update field type specific settings (hide/show fields based on type)
        updateFieldTypeSpecificSettings(field.type);

        // 8. Switch to the basic tab and show the popup
        switchSettingsTab('basic');
        $popup.fadeIn(200);
    }

    /**
     * Close the field settings popup
     */
    function closeFieldSettings() {
        const $popup = $('.sf-field-settings-popup');
        $popup.fadeOut(200);
        // Clear data attributes to prevent conflicts
        $popup.removeData('field-id');
        $popup.removeData('form-element-type');
    }

    // Cancel field settings: if the field was just added and not saved yet, remove it
    function cancelFieldSettings() {
        const $popup = $('.sf-field-settings-popup');
        const fieldId = $popup.data('field-id');
        if (!fieldId) {
            closeFieldSettings();
            return;
        }
        const fieldIndex = Array.isArray(sfFieldsData) ? sfFieldsData.findIndex(f => f.id === fieldId) : -1;
        if (fieldIndex > -1 && sfFieldsData[fieldIndex] && sfFieldsData[fieldIndex].unsaved === true) {
            // Remove the unsaved field
            sfFieldsData.splice(fieldIndex, 1);
            renderVisualFormPreview(sfFieldsData);
        }
        closeFieldSettings();
    }

    /**
     * Switch the active tab in the field settings popup
     * 
     * @param {string} tab The tab to switch to
     */
    function switchSettingsTab(tab) {
        $('.sf-settings-tab').removeClass('active');
        $('.sf-settings-tab[data-tab="' + tab + '"]').addClass('active');

        $('.sf-settings-tab-panel').removeClass('active').hide();
        $('.sf-settings-tab-panel[data-tab="' + tab + '"]').addClass('active').show();

        // Start each tab at the top; carrying the previous tab's scroll offset
        // over hides the first field label behind the tab bar.
        $('.sf-field-settings-content').scrollTop(0);
    }

    /**
     * Save the current field settings
     */
    function saveFieldSettings() {
        const fieldId = $('.sf-field-settings-popup').data('field-id');
        const formElementType = $('.sf-field-settings-popup').data('form-element-type');

        // Handle form elements (title, description, submit button)
        if (formElementType) {
            saveFormElementSettings(formElementType);
            return;
        }

        // Find the field index
        const fieldIndex = sfFieldsData.findIndex(f => f.id === fieldId);

        if (fieldIndex === -1) {
            return;
        }

        // Get the existing field data to preserve advanced conditional logic
        const existingField = sfFieldsData[fieldIndex];

        // Get field data from settings
        const $popup = $('.sf-field-settings-popup');
        const fieldData = {
            id: $popup.find('.sf-field-id').val(),
            name: $popup.find('.sf-field-name').val(),
            type: $popup.find('.sf-field-type').val(),
            label: $popup.find('.sf-field-label').val(),
            placeholder: $popup.find('.sf-field-placeholder').val(),
            default_value: $popup.find('.sf-field-default').val(),
            textarea_height: $popup.find('.sf-textarea-height').val(),
            required: $popup.find('.sf-field-required').is(':checked'),
            required_message: $popup.find('.sf-field-required-message').val(),
            validation_message: $popup.find('.sf-field-validation-message').val(),
            column_width: $popup.find('.sf-field-column-width').val(),
            label_position: $popup.find('.sf-field-label-position').val(),
            field_position: $popup.find('.sf-field-position').val(),
            show_label: $popup.find('.sf-field-show-label').is(':checked'),
            show_label_image: $popup.find('.sf-field-show-label-image').is(':checked'),
            help_text: $popup.find('.sf-field-help-text').val(),
            css_class: $popup.find('.sf-field-css-class').val(),
            options_columns: $popup.find('.sf-field-options-columns').val() || '1',
            // Label image
            label_image: $popup.find('.sf-field-label-image').val() || '',
            label_image_id: parseInt($popup.find('.sf-field-label-image-id').val(), 10) || 0,
            label_image_source_id: parseInt($popup.find('.sf-field-label-image-source-id').val(), 10)
                || parseInt($popup.find('.sf-field-label-image-id').val(), 10) || 0,
            label_image_position: $popup.find('.sf-field-label-image-position').val() || 'left',
            label_image_width: parseInt($popup.find('.sf-field-label-image-width').val(), 10) || 0,
            label_image_height: parseInt($popup.find('.sf-field-label-image-height').val(), 10) || 0,
            label_image_full_width: $popup.find('.sf-field-label-image-full-width').is(':checked'),
            label_image_width_unit: $popup.find('.sf-field-label-image-width-unit').val() === 'px' ? 'px' : '%',
            // Option images
            option_image_position: $popup.find('.sf-field-option-image-position').val() || 'top',
            option_image_size: parseInt($popup.find('.sf-field-option-image-size').val(), 10) || 0,
            // Country flag icons
            show_country_flags: $popup.find('.sf-field-show-country-flags').is(':checked'),
            // Range settings
            range_min: $popup.find('.sf-range-min').val(),
            range_max: $popup.find('.sf-range-max').val(),
            range_step: $popup.find('.sf-range-step').val(),
            range_default: $popup.find('.sf-range-default').val()
        };

        // Add options if needed
        if (['select', 'radio', 'checkbox'].includes(fieldData.type)) {
            fieldData.options = [];

            $popup.find('.sf-field-options-list .sf-field-option').each(function () {
                const $option = $(this);
                const optionData = {
                    value: $option.find('.sf-option-value').val(),
                    label: $option.find('.sf-option-label').val()
                };

                const optionImage = $option.find('.sf-option-image-value').val();
                if (optionImage) {
                    optionData.image = optionImage;
                    optionData.image_id = parseInt($option.find('.sf-option-image-id').val(), 10) || 0;
                    optionData.image_source_id = parseInt($option.find('.sf-option-image-source-id').val(), 10) || optionData.image_id;
                }

                fieldData.options.push(optionData);
            });
        } else if (fieldData.type === 'country') {
            // For country fields, save selected countries and generate options
            const selectedCodes = getSelectedCountries();
            fieldData.selected_countries = selectedCodes;

            // The flag is stored separately from the label so it can be toggled at
            // render time rather than being baked into the option text.
            const toCountryOption = function (country) {
                return {
                    value: country.code,
                    label: country.name,
                    country_code: country.code
                };
            };

            // Generate options based on selected countries or all countries if none selected
            if (selectedCodes.length > 0) {
                fieldData.options = COUNTRIES_LIST.filter(function (country) {
                    return selectedCodes.includes(country.code);
                }).map(toCountryOption);
            } else {
                // If no countries selected, include all countries
                fieldData.options = COUNTRIES_LIST.map(toCountryOption);
            }
        } else if (fieldData.type === 'phone_international') {
            // For phone_international fields, save selected phone countries
            const selectedPhoneCodes = getSelectedPhoneCountries();

            // ALWAYS set these properties, even if empty
            fieldData.selected_phone_countries = selectedPhoneCodes;
            fieldData.available_countries = selectedPhoneCodes;

            // Preserve default_country if it exists, otherwise set default
            if (existingField && existingField.default_country) {
                fieldData.default_country = existingField.default_country;
            } else {
                fieldData.default_country = 'BD'; // Default to Bangladesh
            }
        } else if (fieldData.type === 'file') {
            // For file fields, save selected file types and custom extensions
            const selectedFileTypes = getSelectedFileTypes();
            const customExtensions = getCustomFileExtensions();

            fieldData.allowed_file_types = selectedFileTypes;
            fieldData.custom_file_extensions = customExtensions;

            // Save file size limit
            const fileSizeValue = $popup.find('.sf-file-size-value').val();
            const fileSizeUnit = $popup.find('.sf-file-size-unit').val();
            fieldData.max_file_size_value = fileSizeValue ? parseInt(fileSizeValue) : '';
            fieldData.max_file_size_unit = fileSizeUnit || 'MB';

            // Save custom error messages
            fieldData.file_size_error_message = $popup.find('.sf-file-size-error-message').val();
            fieldData.file_type_error_message = $popup.find('.sf-file-type-error-message').val();
            fieldData.cloud_upload_error_message = $popup.find('.sf-cloud-upload-error-message').val();

            // Save allow multiple files setting
            fieldData.allow_multiple = $popup.find('.sf-allow-multiple-files').is(':checked');

            // Save max files count
            const maxFilesVal = $popup.find('.sf-max-files').val();
            fieldData.max_files = maxFilesVal ? parseInt(maxFilesVal, 10) : '';

            // Save button text
            const buttonText = $popup.find('.sf-upload-button-text').val();
            fieldData.upload_button_text = buttonText || 'Choose a file';

            // Save storage location
            const storageLocation = $popup.find('.sf-storage-location').val();
            fieldData.storage_location = storageLocation || 'site';
        } else if (fieldData.type === 'signature') {
            // For signature fields, save storage location
            const signatureStorageLocation = $popup.find('.sf-storage-location').val();
            fieldData.storage_location = signatureStorageLocation || 'site';
        } else if (fieldData.type === 'section_heading') {
            // For section heading fields, save underline settings
            fieldData.show_underline = $popup.find('.sf-section-show-underline').is(':checked');
            fieldData.underline_color = $popup.find('.sf-section-underline-color').val() || '#3b82f6';
            fieldData.underline_thickness = $popup.find('.sf-section-underline-thickness').val() || '3';
            fieldData.underline_style = $popup.find('.sf-section-underline-style').val() || 'solid';
        } else if (fieldData.type === 'page_break') {
            // For page break fields, save button text and step indicator settings
            fieldData.next_button_text = $popup.find('.sf-page-break-next-text').val() || 'Next';
            fieldData.previous_button_text = $popup.find('.sf-page-break-previous-text').val() || 'Previous';
            fieldData.step_indicator_format = $popup.find('.sf-page-break-step-format').val() || 'Step {current} of {total}';
            fieldData.validation_message = $popup.find('.sf-page-break-validation-message').val() || 'Please fill in all required fields before proceeding.';
            
            // Save page break color settings
            fieldData.next_button_bg_color = $popup.find('.sf-page-break-next-bg-color').val() || '#6366f1';
            fieldData.next_button_text_color = $popup.find('.sf-page-break-next-text-color').val() || '#ffffff';
            fieldData.prev_button_bg_color = $popup.find('.sf-page-break-prev-bg-color').val() || '#ffffff';
            fieldData.prev_button_text_color = $popup.find('.sf-page-break-prev-text-color').val() || '#374151';
            fieldData.step_indicator_text_color = $popup.find('.sf-page-break-step-text-color').val() || '#6b7280';
        }

        // Handle conditional logic - preserve advanced structure if it exists
        const hasConditionalEnabled = $popup.find('.sf-field-has-conditional').is(':checked');

        if (hasConditionalEnabled) {
            // Get advanced conditional logic from the conditional tab
            const action = $popup.find('.sf-conditional-action').val() || 'show';
            const logicType = $popup.find('.sf-conditional-logic-type').val() || 'all';

            // Build groups from the UI
            const groups = [];
            $popup.find('.sf-condition-groups .sf-condition-group').each(function () {
                const $group = $(this);
                const groupRules = [];

                $group.find('.sf-condition-rule').each(function () {
                    const $rule = $(this);
                    const sourceType = $rule.find('.sf-rule-source-type').val() || 'field';

                    let rule = {
                        source_type: sourceType,
                        operator: $rule.find('.sf-conditional-operator').val() || '=',
                        value: $rule.find('.sf-conditional-value').val() || ''
                    };

                    // Get field based on source type
                    if (sourceType === 'field') {
                        rule.field = $rule.find('.sf-conditional-field').val() || '';
                    } else if (sourceType === 'user') {
                        rule.field = $rule.find('.sf-conditional-user-data').val() || '';
                        const metaKey = $rule.find('.sf-conditional-user-meta-key').val();
                        if (metaKey) {
                            rule.meta_key = metaKey;
                        }
                    } else if (sourceType === 'date') {
                        rule.field = $rule.find('.sf-conditional-date-type').val() || '';
                    }
                    groupRules.push(rule);
                });

                if (groupRules.length > 0) {
                    groups.push({ rules: groupRules });
                }
            });

            // Create the advanced conditional logic structure
            fieldData.conditional = {
                action: action,
                logic_type: logicType,
                groups: groups
            };
        } else {
            fieldData.conditional = {};
        }

        // Handle math function - preserve structure if it exists
        const hasMathEnabled = $popup.find('.sf-field-has-math').is(':checked');

        if (hasMathEnabled) {
            const calculationType = $popup.find('.sf-math-calculation-type').val() || 'sum';
            const roundResult = $popup.find('.sf-math-round-result').is(':checked');
            const decimalPlaces = $popup.find('.sf-math-decimal-places').val() || '2';

            // Start with existing math data if it exists, then merge with new data
            let mathData = existingField.math || {};
            mathData = {
                ...mathData,
                enabled: true,
                calculation_type: calculationType,
                round_result: roundResult,
                decimal_places: decimalPlaces
            };

            if (calculationType === 'custom') {
                const formula = $popup.find('.sf-math-formula').val().trim();
                mathData.formula = formula;
            } else {
                const mathFields = [];

                $popup.find('.sf-math-fields-list .sf-math-field-select').each(function (index) {
                    const fieldId = $(this).val();
                    if (fieldId) {
                        mathFields.push(fieldId);
                    }
                });
                mathData.fields = mathFields;
            }

            fieldData.math = mathData;
        } else {
            // Clear math data but preserve the structure
            fieldData.math = {
                enabled: false
            };
        }
        sfFieldsData[fieldIndex] = Object.assign({}, sfFieldsData[fieldIndex], fieldData);
        // Mark field as saved
        sfFieldsData[fieldIndex].unsaved = false;

        // Update the form preview
        renderVisualFormPreview(sfFieldsData);

        // Trigger field updated event
        $(document).trigger('sf:field_updated');

        // Close the settings popup
        closeFieldSettings();
    }

    /**
     * Save form element settings (title, submit button)
     * 
     * @param {string} elementType Type of form element
     */
    function saveFormElementSettings(elementType) {
        if (elementType === 'submit') {
            // Get values from the modal inputs
            const submitText = $('#submit-button-text-input').val().trim();
            const submitWidth = $('#submit-button-width-input').val();
            const submitAlign = $('#submit-button-align-input').val();

            // Update submit button in preview
            $('.sf-edit-submit-button').html(`${sfIcon('check')} ${submitText || 'Submit'}`);
            $('.sf-edit-submit-button').data('width', submitWidth);
            $('.sf-edit-submit-button').data('align', submitAlign);

            // Remove existing alignment classes
            $('.sf-preview-submit-button').removeClass('sf-button-align-left sf-button-align-center sf-button-align-right');

            // Add new alignment class
            $('.sf-preview-submit-button').addClass('sf-button-align-' + submitAlign);

            // Update button width styling
            if (submitWidth === '100') {
                $('.sf-edit-submit-button').css('width', '100%');
            } else if (submitWidth === 'auto') {
                $('.sf-edit-submit-button').css('width', 'auto');
            } else {
                $('.sf-edit-submit-button').css('width', submitWidth + '%');
            }

            // Update hidden fields for step 3
            $('#form-submit-button-text').val(submitText);

            // Store in global settings
            if (!window.sfFormSettings) {
                window.sfFormSettings = {};
            }
            window.sfFormSettings.submit_button_text = submitText;
            window.sfFormSettings.submit_button_width = submitWidth;
            window.sfFormSettings.submit_button_align = submitAlign;

            // Close the settings popup
            closeFieldSettings();

            // Show success message
            const $message = $('<div class="sf-settings-saved-message">Settings saved successfully!</div>');
            $('.sf-visual-form-builder').append($message);
            setTimeout(() => {
                $message.fadeOut(300, function () {
                    $(this).remove();
                });
            }, 2000);

            // Trigger custom event for form settings saved
            $(document).trigger('sf:form_settings_saved');
            return;
        }

        // Close the settings popup
        closeFieldSettings();

        // Show success message
        const $message = $('<div class="sf-settings-saved-message">Settings saved successfully!</div>');
        $('.sf-visual-form-builder').append($message);
        setTimeout(() => {
            $message.fadeOut(300, function () {
                $(this).remove();
            });
        }, 2000);

        // Trigger custom event for form settings saved
        $(document).trigger('sf:form_settings_saved');
    }

    /**
     * Add an option to the field settings
     * 
     * @param {string} value Option value
     * @param {string} label Option label
     */
    function addOptionToSettings(value = '', label = '', image = '', imageId = '', imageSourceId = '') {
        const $option = $(`
            <div class="sf-field-option">
                <div class="sf-option-image-preview"></div>
                <input type="text" class="sf-option-label" placeholder="Label">
                 <input type="text" class="sf-option-value" placeholder="Value">
                <input type="hidden" class="sf-option-image-value">
                <input type="hidden" class="sf-option-image-id">
                <input type="hidden" class="sf-option-image-source-id">
                <button type="button" class="sf-option-image-btn dashicons dashicons-format-image" title="Set option image"></button>
                <button type="button" class="sf-option-image-crop dashicons dashicons-image-crop" title="Crop option image"></button>
                <button type="button" class="sf-remove-option dashicons dashicons-no-alt"></button>
            </div>
        `);

        // Set values using jQuery to avoid HTML escaping issues
        $option.find('.sf-option-label').val(label);
        $option.find('.sf-option-value').val(value);
        $option.find('.sf-option-image-value').val(image || '');
        $option.find('.sf-option-image-id').val(imageId || '');
        $option.find('.sf-option-image-source-id').val(imageSourceId || imageId || '');

        $('.sf-field-options-list').append($option);
        renderOptionImagePreview($option);
    }

    /* ---------------------------------------------------------------------
     * Label image resizing in the form preview
     * ------------------------------------------------------------------ */

    const SF_IMAGE_MIN_SIZE = 20;
    const SF_IMAGE_MAX_SIZE = 2000;
    // Dragging within this many pixels of the field edge snaps to full width
    const SF_IMAGE_SNAP_DISTANCE = 14;

    /**
     * Clamp a dragged dimension.
     *
     * @param {number} value Pixel value.
     * @param {number} [max] Optional upper bound, e.g. the field width.
     * @returns {number} Clamped pixel value.
     */
    function clampImageSize(value, max) {
        const upper = (typeof max === 'number' && max > SF_IMAGE_MIN_SIZE) ? max : SF_IMAGE_MAX_SIZE;
        return Math.max(SF_IMAGE_MIN_SIZE, Math.min(upper, Math.round(value)));
    }

    /**
     * Width the label image can occupy before it overflows its field.
     *
     * @param {jQuery} $wrap The .sf-label-image-wrap element.
     * @returns {number} Available pixel width.
     */
    function getImageAvailableWidth($wrap) {
        const $inner = $wrap.closest('.sf-label-inner');
        const $label = $wrap.closest('label');
        const $field = $wrap.closest('.sf-preview-field');

        return Math.round($inner.width() || $label.width() || $field.width() || SF_IMAGE_MAX_SIZE);
    }

    /**
     * Convert a dragged pixel width into a percentage of the field.
     *
     * Sizes are stored relative rather than absolute so the same value renders
     * the same proportion in the builder preview and on the frontend, even
     * though the two containers are different widths.
     *
     * @param {number} pixels    Dragged width.
     * @param {number} available Width of the label box.
     * @returns {number} Percentage between 1 and 100.
     */
    function toImageWidthPercent(pixels, available) {
        if (!available) {
            return 100;
        }

        return Math.max(1, Math.min(100, Math.round((pixels / available) * 100)));
    }

    /**
     * Markup for the always-present resize handles.
     *
     * They live in the preview markup rather than being injected on click:
     * hovering the image reveals them, so resizing is one gesture instead of
     * "click to arm, then find a handle".
     *
     * @returns {string} Handle and badge markup.
     */
    function getImageResizeHandles() {
        return '<span class="sf-image-resize-badge"></span>' +
            '<span class="sf-image-resize-handle sf-image-resize-e" data-dir="e" title="Drag to change width"></span>' +
            '<span class="sf-image-resize-handle sf-image-resize-s" data-dir="s" title="Drag to change height"></span>' +
            '<span class="sf-image-resize-handle sf-image-resize-se" data-dir="se" title="Drag to resize both - hold Shift to keep the aspect ratio"></span>';
    }

    /**
     * Refresh the "W x H" readout shown while resizing.
     *
     * @param {jQuery} $wrap The .sf-label-image-wrap element.
     */
    function updateImageResizeBadge($wrap) {
        const $image = $wrap.find('.sf-label-image');
        let width;

        if ($wrap.hasClass('sf-image-full-width')) {
            width = 'Full width';
        } else {
            // The wrapper is the sized box once a drag starts
            const percent = toImageWidthPercent($wrap.outerWidth(), getImageAvailableWidth($wrap));
            width = percent + '% wide';
        }

        $wrap.find('.sf-image-resize-badge').text(width + ', ' + Math.round($image.outerHeight()) + 'px tall');
    }

    /**
     * Write the dragged size back to the field data and re-render the preview.
     *
     * @param {jQuery} $wrap The .sf-label-image-wrap element.
     */
    function persistImageResize($wrap) {
        const $image = $wrap.find('.sf-label-image');
        const fieldId = $wrap.closest('.sf-preview-field').data('field-id');
        const fields = window.sfFieldsData;

        if (!fieldId || !Array.isArray(fields)) {
            return;
        }

        const index = fields.findIndex(function (field) {
            return field.id === fieldId;
        });

        if (index === -1) {
            return;
        }

        const isFullWidth = $wrap.hasClass('sf-image-full-width');

        fields[index].label_image_full_width = isFullWidth;
        // Store the width relative to the field so the frontend shows the same
        // proportion even though its container is a different width
        fields[index].label_image_width_unit = '%';
        fields[index].label_image_width = isFullWidth
            ? 100
            : toImageWidthPercent($wrap.outerWidth(), getImageAvailableWidth($wrap));
        fields[index].label_image_height = clampImageSize($image.outerHeight());

        // Re-rendering drops the handles, which is the right end state for a drag
        renderVisualFormPreview(fields);
        $(document).trigger('sf:field_updated');
    }

    /**
     * Build a flag emoji from an ISO 3166-1 alpha-2 country code.
     *
     * @param {string} code Two letter country code.
     * @returns {string} Flag emoji, or an empty string for an invalid code.
     */
    function getCountryFlag(code) {
        const upper = String(code || '').trim().toUpperCase();

        if (!/^[A-Z]{2}$/.test(upper)) {
            return '';
        }

        return String.fromCodePoint(
            0x1F1E6 + (upper.charCodeAt(0) - 65),
            0x1F1E6 + (upper.charCodeAt(1) - 65)
        );
    }

    /**
     * Remove a leading flag emoji from a country label.
     *
     * Options saved by older plugin versions store the flag inside the label.
     *
     * @param {string} label Raw option label.
     * @returns {string} Label without its leading flag.
     */
    function stripCountryFlag(label) {
        return String(label || '').replace(/^[\u{1F1E6}-\u{1F1FF}]{2}[\s\u{FE0F}]*/u, '');
    }

    /**
     * Open the WordPress media library and hand the chosen image URL back.
     *
     * @param {Function} onSelect Receives the selected image URL.
     */
    function openMediaPicker(onSelect) {
        if (!window.wp || !window.wp.media) {
            window.SF.notify(window.SF.t('mediaUnavailable', 'The WordPress media library is not available on this screen.'));
            return;
        }

        const frame = window.wp.media({
            title: 'Select or Upload an Image',
            button: { text: 'Use this image' },
            library: { type: 'image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            // Prefer a mid-size file when one exists - option cards are small.
            const url = (attachment.sizes && attachment.sizes.medium)
                ? attachment.sizes.medium.url
                : attachment.url;
            onSelect(url, attachment);
        });

        watchMediaFrame(frame);
    }

    /**
     * Keep the field settings popup out of the way while a media frame is open.
     *
     * The popup sits at z-index 999999 and the WordPress media modal at 160000,
     * so without this the popup covers the image picker.
     *
     * @param {Object} frame A wp.media frame.
     */
    function watchMediaFrame(frame, extraClass) {
        const bodyClass = 'sf-media-frame-open' + (extraClass ? ' ' + extraClass : '');

        $('body').addClass(bodyClass);

        frame.on('close', function () {
            $('body').removeClass(bodyClass);
        });

        frame.on('escape', function () {
            $('body').removeClass(bodyClass);
        });

        // A frame that throws while opening would otherwise leave the settings
        // popup hidden with no way to get it back.
        try {
            frame.open();
        } catch (error) {
            $('body').removeClass(bodyClass);
            window.console && window.console.error('SigmaForms: media frame failed to open', error);
            window.SF.notify(window.SF.t('mediaFailed', 'The media window could not be opened. Please reload the page and try again.'));
            return false;
        }

        return true;
    }

    /**
     * Scale the crop preview to fill the crop area while keeping its aspect ratio.
     *
     * Small images are enlarged up to 3x so there is something workable to drag
     * on; large ones are shrunk to fit. Called before imgAreaSelect initialises.
     *
     * @param {number} width  Natural image width.
     * @param {number} height Natural image height.
     */
    function fitCropImage(width, height) {
        const $image = $('.media-frame-content .crop-content .crop-image');

        if (!width || !height || !$image.length) {
            return;
        }

        // The crop container can still report zero before the modal has laid
        // out, so fall back to the frame and finally the viewport.
        const $area = $image.closest('.crop-content');
        const $frame = $image.closest('.media-frame-content');

        const availWidth = $area.width() || $frame.width() || $(window).width();
        const availHeight = $area.height() || $frame.height() || $(window).height();

        const boxWidth = Math.max(availWidth - 56, 160);
        const boxHeight = Math.max(availHeight - 56, 160);
        const scale = Math.min(boxWidth / width, boxHeight / height, 3);

        if (scale > 0) {
            $image.css({
                width: Math.round(width * scale) + 'px',
                height: Math.round(height * scale) + 'px'
            });
        }
    }

    /**
     * Open the WordPress cropper on an existing attachment.
     *
     * Uses core's Library -> Cropper state pair, with the crop itself posted to
     * the plugin's own sf_crop_image endpoint so the source image is left intact.
     *
     * @param {number}   attachmentId Attachment to pre-select for cropping.
     * @param {Function} onCropped    Receives (url, attachment) for the new crop.
     */
    function openImageCropper(attachmentId, onCropped) {
        const media = window.wp && window.wp.media;

        if (!media || !media.controller || !media.controller.Cropper) {
            window.SF.notify(window.SF.t('cropperUnavailable', 'The WordPress image cropper is not available on this screen.'));
            return;
        }

        if (!$.fn.imgAreaSelect) {
            window.SF.notify(window.SF.t('cropScriptMissing', 'The image cropping script (imgAreaSelect) did not load. Please reload the page and try again.'));
            return;
        }

        const CropState = media.controller.Cropper.extend({
            doCrop: function (attachment) {
                const cropDetails = attachment.get('cropDetails');

                // Keep the cropped output at its selected pixel size
                cropDetails.dst_width = cropDetails.width;
                cropDetails.dst_height = cropDetails.height;

                return window.wp.ajax.post('sf_crop_image', {
                    nonce: (window.sfAdmin && window.sfAdmin.nonce) || '',
                    id: attachment.get('id'),
                    cropDetails: cropDetails
                });
            }
        });

        const frame = media({
            button: {
                text: 'Select and crop',
                // wp.media.view.Toolbar.Select#clickSelect closes the frame before
                // it fires "select". Without close:false the modal would shut and
                // the switch to the cropper state would happen on a dead frame.
                close: false
            },
            states: [
                new media.controller.Library({
                    id: 'library',
                    title: 'Choose the image to crop',
                    library: media.query({ type: 'image' }),
                    multiple: false,
                    date: false,
                    priority: 20
                }),
                new CropState({
                    // Let the user bail out and keep the original image
                    canSkipCrop: true,
                    imgSelectOptions: function (attachment) {
                        const width = parseInt(attachment.get('width'), 10) || 0;
                        const height = parseInt(attachment.get('height'), 10) || 0;

                        // Core only caps the preview (max-width/max-height), so a
                        // small image renders postage-stamp sized in a large modal.
                        // Size it to the crop area first - imgAreaSelect reads the
                        // rendered box on init, and imageWidth/imageHeight below
                        // keep the returned coordinates in original-image space.
                        fitCropImage(width, height);

                        const options = {
                            handles: true,
                            keys: true,
                            instance: true,
                            persistent: true
                        };

                        // Without real dimensions (some SVGs) imgAreaSelect falls
                        // back to the rendered size, which is what we want anyway.
                        if (width && height) {
                            options.imageWidth = width;
                            options.imageHeight = height;
                            options.x1 = 0;
                            options.y1 = 0;
                            options.x2 = width;
                            options.y2 = height;
                        }

                        return options;
                    }
                })
            ]
        });

        // Library -> Cropper once an image is chosen
        frame.on('select', function () {
            frame.setState('cropper');
        });

        frame.on('cropped', function (attachment) {
            onCropped(attachment.url, attachment);
        });

        // "Skip cropping" keeps the original image
        frame.on('skippedcrop', function (selection) {
            const attachment = selection.toJSON();
            onCropped(attachment.url, attachment);
        });

        frame.on('content:error:crop', function () {
            window.SF.notify(window.SF.t('cropFailed', 'The image could not be cropped. Please try a different selection.'));
        });

        if (!watchMediaFrame(frame, 'sf-crop-frame-open')) {
            return;
        }

        // Jump straight to cropping the image already on the field.
        if (attachmentId) {
            const attachment = media.attachment(attachmentId);

            attachment.fetch().done(function () {
                if (!attachment.get('url')) {
                    return;
                }

                const selection = frame.state('library').get('selection');

                selection.reset([attachment]);

                // wp.media.controller.Cropper reads frame._selection.single, which
                // is only populated from selection._single when the library state
                // deactivates. Resetting the collection alone does not set it, so
                // the cropper would open with no image at all.
                selection.single(attachment);

                frame.setState('cropper');
            });
        }
    }

    /**
     * Refresh the thumbnail + button state of a label image picker.
     *
     * @param {jQuery} $picker The .sf-image-picker wrapper.
     */
    function renderImagePickerPreview($picker) {
        const url = $picker.find('.sf-field-label-image').val();
        const $card = $picker.find('.sf-image-picker-card');
        const $empty = $picker.find('.sf-image-picker-empty');

        if (!url) {
            $card.hide();
            $empty.show();
            $picker.removeClass('has-image');
            return;
        }

        $picker.addClass('has-image');
        $empty.hide();
        $card.css('display', '');

        $picker.find('.sf-image-picker-thumb').html($('<img>').attr('src', url).attr('alt', ''));
        $picker.find('.sf-image-picker-name').text(url.split('/').pop().split('?')[0]);

        // Dimensions are only known once the browser has the file
        const $dims = $picker.find('.sf-image-picker-dims').text('');
        const probe = new Image();
        probe.onload = function () {
            $dims.text(probe.naturalWidth + ' x ' + probe.naturalHeight + ' px');
        };
        probe.src = url;

        // Cropping needs an attachment ID, which externally-set URLs will not have
        $picker.find('.sf-crop-image').prop('disabled', !$picker.find('.sf-field-label-image-id').val());
    }

    /**
     * Refresh the thumbnail of a single option row.
     *
     * @param {jQuery} $option The .sf-field-option row.
     */
    function renderOptionImagePreview($option) {
        const url = $option.find('.sf-option-image-value').val();
        const $preview = $option.find('.sf-option-image-preview');

        if (url) {
            $preview.html(
                $('<img>').attr('src', url).attr('alt', '')
            ).append('<button type="button" class="sf-option-image-clear dashicons dashicons-no-alt" title="Remove image"></button>').show();
            $option.addClass('has-option-image');
        } else {
            $preview.empty().hide();
            $option.removeClass('has-option-image');
        }

        // Cropping needs an attachment ID
        $option.find('.sf-option-image-crop').prop('disabled', !$option.find('.sf-option-image-id').val());
    }

    /**
     * Show the label image position/width controls only when an image is set.
     */
    function toggleLabelImageOptions() {
        const $popup = $('.sf-field-settings-popup');
        const hasImage = !!$popup.find('.sf-field-label-image').val();
        $popup.find('.sf-label-image-options-row').toggle(hasImage);
        // The "Show Field Label Image" toggle is meaningless without an image
        $popup.find('.sf-show-label-image-row').toggle(hasImage);
    }

    /**
     * Add a new option to the field settings
     */
    function addFieldOption() {
        addOptionToSettings('', '');
    }

    /**
     * Update field type specific settings
     * 
     * @param {string} fieldType Field type
     */
    /**
     * Update field type specific settings
     * 
     * @param {string} fieldType Field type
     */
    function updateFieldTypeSpecificSettings(fieldType) {
        // Option image layout only applies where per-option images can be set
        $('.sf-option-image-options-row').toggle(['select', 'radio', 'checkbox'].includes(fieldType));

        // Country flag toggle only applies to the two country-driven field types
        $('.sf-country-flags-row').toggle(['country', 'phone_international'].includes(fieldType));

        // Label images are not rendered for structural fields
        const structuralField = (fieldType === 'section_heading' || fieldType === 'page_break');
        $('.sf-label-image-row').toggle(!structuralField);
        if (structuralField) {
            $('.sf-label-image-options-row, .sf-show-label-image-row').hide();
        } else {
            toggleLabelImageOptions();
        }

        // Show/hide options row for select, radio, checkbox, country
        if (['select', 'radio', 'checkbox'].includes(fieldType)) {
            $('.sf-field-row.sf-options-row').slideDown(200);
            $('.sf-field-row.sf-country-selection-row').slideUp(200);
            $('.sf-options-columns-row').show();
            $('.sf-field-options-list input').prop('readonly', false).css('opacity', '1');
            $('.sf-add-option').show();
            $('.sf-remove-option').show();
        } else if (fieldType === 'country') {
            $('.sf-field-row.sf-options-row').slideUp(200);
            $('.sf-field-row.sf-country-selection-row').slideDown(200);
            $('.sf-options-columns-row').hide();

            // Only initialize if the container is empty (i.e., field type was just changed)
            // If container has content, it means we already initialized it properly in openFieldSettings
            if ($('.sf-countries-list').children().length === 0) {
                initCountrySelectionInterface();
            }
        } else {
            $('.sf-field-row.sf-options-row').slideUp(200);
            $('.sf-field-row.sf-country-selection-row').slideUp(200);
            $('.sf-field-row.sf-file-types-selection-row').slideUp(200);
            $('.sf-field-row.sf-custom-extensions-row').slideUp(200);
            $('.sf-options-columns-row').hide();
        }
        
        if (fieldType === 'range') {
             $('.sf-field-row.sf-range-settings-row').slideDown(200);
        } else {
             $('.sf-field-row.sf-range-settings-row').slideUp(200);
        }

        // Show/hide page break settings
        if (fieldType === 'page_break') {
            $('.sf-page-break-settings').slideDown(200);
        } else {
            $('.sf-page-break-settings').slideUp(200);
        }

        // Hide unnecessary fields for section headings and page breaks
        if (fieldType === 'section_heading' || fieldType === 'page_break') {
            // Hide name, placeholder, default value, required, help text
            $('.sf-field-row').has('.sf-field-name').hide();
            $('.sf-field-row').has('.sf-field-placeholder').hide();
            $('.sf-field-row').has('.sf-field-default').hide();
            $('.sf-field-row').has('.sf-field-required').hide();
            $('.sf-field-row').has('.sf-field-help-text').hide();
            $('.sf-field-row').has('.sf-field-show-label').hide();
            // Hide advanced tab and conditional/math tabs
            $('.sf-settings-tab[data-tab="advanced"]').hide();
            $('.sf-settings-tab[data-tab="conditional"]').hide();
            $('.sf-settings-tab[data-tab="math"]').hide();
        } else if (fieldType === 'file') {
            // Hide placeholder and default value for file upload fields
            $('.sf-field-row').has('.sf-field-placeholder').hide();
            $('.sf-field-row').has('.sf-field-default').hide();
            // Show file type selection
            $('.sf-field-row.sf-file-types-selection-row').slideDown(200);
            $('.sf-field-row.sf-custom-extensions-row').slideDown(200);
            $('.sf-field-row.sf-file-size-limit-row').slideDown(200);
            $('.sf-field-row.sf-allow-multiple-files-row').slideDown(200);
            // Show max-files-row only if allow multiple is already checked
            if ($('.sf-allow-multiple-files').is(':checked')) {
                $('.sf-field-row.sf-max-files-row').slideDown(200);
            }
            $('.sf-field-row.sf-upload-button-text-row').slideDown(200);
            $('.sf-field-row.sf-storage-location-row').slideDown(200);
            // Only initialize if the container is empty
            if ($('.sf-file-types-list').children().length === 0) {
                initFileTypesSelectionInterface();
            }
            // Show all other fields
            $('.sf-field-row').has('.sf-field-name').show();
            $('.sf-field-row').has('.sf-field-required').show();
            $('.sf-field-row').has('.sf-field-help-text').show();
            $('.sf-field-row').has('.sf-field-show-label').show();
            $('.sf-field-row.sf-textarea-height-row').hide();
            // Show tabs except math
            $('.sf-settings-tab[data-tab="advanced"]').show();
            $('.sf-settings-tab[data-tab="conditional"]').show();
            $('.sf-settings-tab[data-tab="math"]').hide();
        } else if (fieldType === 'signature') {
            // Hide placeholder and default value for signature fields
            $('.sf-field-row').has('.sf-field-placeholder').hide();
            $('.sf-field-row').has('.sf-field-default').hide();
            // Hide file-specific rows
            $('.sf-field-row.sf-file-types-selection-row').hide();
            $('.sf-field-row.sf-custom-extensions-row').hide();
            $('.sf-field-row.sf-file-size-limit-row').hide();
            $('.sf-field-row.sf-allow-multiple-files-row').hide();
            $('.sf-field-row.sf-max-files-row').hide();
            $('.sf-field-row.sf-upload-button-text-row').hide();
            // Show storage location
            $('.sf-field-row.sf-storage-location-row').slideDown(200);
            // Show all other fields
            $('.sf-field-row').has('.sf-field-name').show();
            $('.sf-field-row').has('.sf-field-required').show();
            $('.sf-field-row').has('.sf-field-help-text').show();
            $('.sf-field-row').has('.sf-field-show-label').show();
            $('.sf-field-row.sf-textarea-height-row').hide();
            // Show tabs except math
            $('.sf-settings-tab[data-tab="advanced"]').show();
            $('.sf-settings-tab[data-tab="conditional"]').show();
            $('.sf-settings-tab[data-tab="math"]').hide();
        } else if (fieldType === 'range') {
            // Hide placeholder and default value for range fields
            $('.sf-field-row').has('.sf-field-placeholder').hide();
            $('.sf-field-row').has('.sf-field-default').hide();
            // Show all other fields
            $('.sf-field-row').has('.sf-field-name').show();
            $('.sf-field-row').has('.sf-field-required').show();
            $('.sf-field-row').has('.sf-field-help-text').show();
            $('.sf-field-row').has('.sf-field-show-label').show();
            $('.sf-field-row.sf-textarea-height-row').hide();
             // Show tabs except math
            $('.sf-settings-tab[data-tab="advanced"]').show();
            $('.sf-settings-tab[data-tab="conditional"]').show();
            $('.sf-settings-tab[data-tab="math"]').hide();
        } else if (fieldType === 'rich_text') {
            // Hide placeholder and default value for rich text fields
            $('.sf-field-row').has('.sf-field-placeholder').hide();
            $('.sf-field-row').has('.sf-field-default').show();
            // Show all other fields for rich text
            $('.sf-field-row').has('.sf-field-name').show();
            $('.sf-field-row').has('.sf-field-required').show();
            $('.sf-field-row').has('.sf-field-help-text').show();
            $('.sf-field-row').has('.sf-field-show-label').show();
            $('.sf-field-row.sf-textarea-height-row').hide();
            // Show tabs except math
            $('.sf-settings-tab[data-tab="advanced"]').show();
            $('.sf-settings-tab[data-tab="conditional"]').show();
            $('.sf-settings-tab[data-tab="math"]').hide();
        } else {
            // Show all fields for other types
            $('.sf-field-row').has('.sf-field-name').show();
            $('.sf-field-row').has('.sf-field-placeholder').show();
            $('.sf-field-row').has('.sf-field-default').show();
            $('.sf-field-row').has('.sf-field-required').show();
            $('.sf-field-row').has('.sf-field-help-text').show();
            $('.sf-field-row').has('.sf-field-show-label').show();
            // Hide file/signature-specific rows for other field types
            $('.sf-field-row.sf-file-types-selection-row').hide();
            $('.sf-field-row.sf-custom-extensions-row').hide();
            $('.sf-field-row.sf-file-size-limit-row').hide();
            $('.sf-field-row.sf-allow-multiple-files-row').hide();
            $('.sf-field-row.sf-max-files-row').hide();
            $('.sf-field-row.sf-upload-button-text-row').hide();
            $('.sf-field-row.sf-storage-location-row').hide();
            // Show textarea height row only for textarea type
            if (fieldType === 'textarea') {
                $('.sf-field-row.sf-textarea-height-row').show();
            } else {
                $('.sf-field-row.sf-textarea-height-row').hide();
            }
            // Show tabs
            $('.sf-settings-tab[data-tab="advanced"]').show();
            $('.sf-settings-tab[data-tab="conditional"]').show();

            // Only show math tab for text and number fields
            if (fieldType === 'text' || fieldType === 'number') {
                $('.sf-settings-tab[data-tab="math"]').show();
            } else {
                $('.sf-settings-tab[data-tab="math"]').hide();
            }
        }
    }

    /**
     * Update the conditional field options in settings
     * 
     * @param {string} currentFieldId Current field ID
     */
    function updateSettingsConditionalFields(currentFieldId) {
        // Update both basic and advanced conditional field selectors
        const $conditionalFields = $('.sf-conditional-field');

        $conditionalFields.each(function () {
            const $conditionalField = $(this);
            const selectedValue = $conditionalField.val();

            // Clear existing options
            $conditionalField.empty();

            // Add default option
            $conditionalField.append('<option value="">Select a field</option>');

            // Add field options
            sfFieldsData.forEach(function (field) {
                // Don't include the current field as a dependency
                if (field.id === currentFieldId) {
                    return;
                }

                $conditionalField.append(`<option value="${window.SF.Utils.escapeHTML(field.id)}" data-field-type="${field.type}">${window.SF.Utils.escapeHTML(field.label)}</option>`);
            });

            // Restore selected value if it exists
            if (selectedValue) {
                $conditionalField.val(selectedValue);
            }
        });
    }

    /**
     * Duplicate a field
     * 
     * @param {string} fieldId Field ID to duplicate
     */
    function duplicateField(fieldId) {

        // Find the field
        const field = sfFieldsData.find(f => f.id === fieldId);

        if (!field) {
            return;
        }

        // Create a clone of the field
        const clonedField = JSON.parse(JSON.stringify(field));

        // Generate new unique ID
        const newId = 'field_' + Date.now() + '_' + Math.floor(Math.random() * 1000);

        // Update ID, name, and label
        clonedField.id = newId;
        clonedField.name = newId; // Important: Update name to match new ID
        clonedField.label = field.label + ' (Copy)';

        // Insert right after the original. Appending put the copy at the end
        // of the form, after any page break, so on another step.
        sfFieldsData.splice(sfFieldsData.indexOf(field) + 1, 0, clonedField);

        // Update preview
        renderVisualFormPreview(sfFieldsData);
    }

    /**
     * Delete a field
     * 
     * @param {string} fieldId Field ID to delete
     */
    function deleteField(fieldId) {
        window.SF.confirm(window.SF.t('confirmDeleteField', 'Are you sure you want to delete this field?'), { danger: true }).then(function (sfConfirmed) {
            if (!sfConfirmed) {
                return;
            }
            // Remove field from data
            sfFieldsData = sfFieldsData.filter(f => f.id !== fieldId);

            // Update preview
            renderVisualFormPreview(sfFieldsData);

            // Trigger field removed event
            $(document).trigger('sf:field_removed');
        });
    }

    /**
     * Update fields order based on the visual preview order
     */
    function updateFieldsOrder() {
        const newOrder = [];

        // Get field IDs in their new order
        $('.sf-preview-field').each(function () {
            const fieldId = $(this).data('field-id');
            const field = sfFieldsData.find(f => f.id === fieldId);

            if (field) {
                newOrder.push(field);
            }
        });

        // Update fields data with new order
        if (newOrder.length > 0) {
            sfFieldsData = newOrder;
        }
    }

    /**
     * Create an advanced rule element from rule data
     * 
     * @param {Object} rule Rule data
     * @param {number} ruleId Rule ID
     * @return {jQuery} Rule element
     */
    function createAdvancedRuleElement(rule, ruleId) {
        const valueInputType = rule.source_type === 'date' ? 'datetime-local' : 'text';
        const $rule = $(`
            <div class="sf-condition-rule" data-rule-id="${ruleId}">
                <div class="sf-rule-field-container">
                    <select class="sf-rule-source-type">
                        <option value="field" ${rule.source_type === 'field' ? 'selected' : ''}>Form Field</option>
                        <option value="user" ${rule.source_type === 'user' ? 'selected' : ''}>User Data</option>
                        <option value="date" ${rule.source_type === 'date' ? 'selected' : ''}>Date/Time</option>
                    </select>
                    <!-- Field selector for form fields -->
                    <div class="sf-rule-field-selector sf-field-source-field" ${rule.source_type === 'field' ? '' : 'style="display: none;"'}>
                        <select class="sf-conditional-field">
                            <option value="">Select a field</option>
                            <!-- Fields will be populated by updateSettingsConditionalFields -->
                        </select>
                    </div>
                    <!-- User data selector -->
                    <div class="sf-rule-field-selector sf-field-source-user" ${rule.source_type === 'user' ? '' : 'style="display: none;"'}>
                        <select class="sf-conditional-user-data">
                            <option value="logged_in" ${rule.field === 'logged_in' ? 'selected' : ''}>User is logged in</option>
                            <option value="user_role" ${rule.field === 'user_role' ? 'selected' : ''}>User role</option>
                            <option value="user_meta" ${rule.field === 'user_meta' ? 'selected' : ''}>User meta field</option>
                        </select>
                        <input type="text" class="sf-conditional-user-meta-key" value="${rule.meta_key || ''}" placeholder="Meta key" ${rule.field === 'user_meta' ? '' : 'style="display: none;"'}>
                    </div>
                    <!-- Date/Time selector -->
                    <div class="sf-rule-field-selector sf-field-source-date" ${rule.source_type === 'date' ? '' : 'style="display: none;"'}>
                        <select class="sf-conditional-date-type">
                            <option value="current_date" ${rule.field === 'current_date' ? 'selected' : ''}>Current date</option>
                            <option value="current_time" ${rule.field === 'current_time' ? 'selected' : ''}>Current time</option>
                            <option value="current_day" ${rule.field === 'current_day' ? 'selected' : ''}>Current day of week</option>
                        </select>
                    </div>
                </div>
                <div class="sf-rule-field-container-inner">
                    <!-- Operator selector -->
                    <div class="sf-rule-operator-container">
                        <select class="sf-conditional-operator" data-current-value="${rule.operator || '='}">
                            <option value="=" ${rule.operator === '=' ? 'selected' : ''}>equals</option>
                            <option value="!=" ${rule.operator === '!=' ? 'selected' : ''}>does not equal</option>
                            <option value="contains" ${rule.operator === 'contains' ? 'selected' : ''}>contains</option>
                            <option value=">" ${rule.operator === '>' ? 'selected' : ''}>is greater than</option>
                            <option value="<" ${rule.operator === '<' ? 'selected' : ''}>is less than</option>
                        </select>
                    </div>
                    <!-- Value input -->
                    <div class="sf-rule-value-container">
                        <input type="${valueInputType}" class="sf-conditional-value" value="${rule.value || ''}" placeholder="Value">
                    </div>
                </div>
                <!-- Rule controls -->
                <div class="sf-rule-controls">
                    <button type="button" class="sf-add-rule" title="Add another condition">
                        <span class="dashicons dashicons-plus-alt"></span>
                    </button>
                    <button type="button" class="sf-remove-rule" title="Remove this condition">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            </div>
        `);

        // Set the field value if it's a field source type
        if (rule.source_type === 'field' && rule.field) {
            setTimeout(function () {
                $rule.find('.sf-conditional-field').val(rule.field);

                // Trigger operator update based on field type
                const $fieldSelect = $rule.find('.sf-conditional-field');
                const $selectedOption = $fieldSelect.find('option:selected');
                const fieldType = $selectedOption.data('field-type');
                if (fieldType && window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateOperatorsForFieldType) {
                    window.SF.ConditionalLogic.updateOperatorsForFieldType($rule, fieldType, rule.operator);
                } else if (window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                    window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, 'field', rule.operator);
                }

                // Choice fields pick the value from their options.
                if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateValueInputForField) {
                    window.SF.ConditionalLogic.updateValueInputForField($rule, rule.field);
                }
            }, 100);
        } else {
            // For non-field source types, update operators immediately
            if (window.SF.ConditionalLogic) {
                if (rule.source_type === 'user' && window.SF.ConditionalLogic.updateOperatorsForUserDataType) {
                    window.SF.ConditionalLogic.updateOperatorsForUserDataType($rule, rule.field, rule.operator);

                    // Also update value input type for user data
                    if (window.SF.ConditionalLogic.updateValueInputForUserDataType) {
                        window.SF.ConditionalLogic.updateValueInputForUserDataType($rule, rule.field);
                    }
                } else if (rule.source_type === 'date' && window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                    window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, 'date', rule.operator);
                } else if (window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                    window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, rule.source_type, rule.operator);
                }
            }
        }

        // Add event handler to change value input type when source type changes
        $rule.find('.sf-rule-source-type').on('focus', function () {
            // Store the previous value before change
            $(this).data('prev-value', $(this).val());
        });
        $rule.find('.sf-rule-source-type').on('change', function () {
            const selectedType = $(this).val();
            const prevType = $(this).data('prev-value');
            const $valueInput = $rule.find('.sf-conditional-value');
            if (selectedType === 'date') {
                $valueInput.attr('type', 'datetime-local');
            } else {
                $valueInput.attr('type', 'text');
            }
            // Only reset the right-side field selector if switching from non-field to field
            if (selectedType === 'field' && prevType !== 'field') {
                const $fieldSelect = $rule.find('.sf-conditional-field');
                $fieldSelect.val(''); // Reset to default option
            }
            // Update the previous value
            $(this).data('prev-value', selectedType);
        });

        // Add event handler for user data type changes
        $rule.find('.sf-conditional-user-data').on('change', function () {
            const userDataType = $(this).val();
            if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateValueInputForUserDataType) {
                window.SF.ConditionalLogic.updateValueInputForUserDataType($rule, userDataType);
            }
        });

        return $rule;
    }

    /**
     * Create default conditional rule structure
     */
    function createDefaultConditionalRule() {
        $('.sf-condition-groups').empty();
        const $group = $('<div class="sf-condition-group" data-group-id="0"></div>');
        const defaultRule = {
            source_type: 'field',
            field: '',
            operator: '=',
            value: ''
        };
        const $rule = createAdvancedRuleElement(defaultRule, 0);
        $group.append($rule);
        $('.sf-condition-groups').append($group);

        // Initialize operators for the default field source type
        setTimeout(function () {
            if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                window.SF.ConditionalLogic.updateOperatorsForSourceType($rule, 'field', '=');
            }
        }, 100);
    }

    /**
     * Save form data
     */
    /**
     * Show the save result toast long enough to read: 3s for a success, 6s
     * for an error. It used to disappear after one second.
     */
    let saveMessageTimer = null;

    function showSaveMessage($message, html, isError) {
        clearTimeout(saveMessageTimer);
        $message.html(html).toggleClass('is-error', !!isError).addClass('active');
        saveMessageTimer = setTimeout(function () {
            $message.removeClass('active');
        }, isError ? 6000 : 3000);
    }

    function saveForm() {
        const formId = $('#form-id').val();
        const formData = window.SF.Utils.getFormData();
        const $saveButton = $('#sf-save-form');
        const $saveMessage = $('.sf-save-message');
        const $saveMessageBox = $('.sf-card-footer');

        // Validate form
        if (!formData.title) {
            window.SF.notify(window.SF.t('enterFormName', 'Please enter a form name.'));
            return;
        }

        // Check if we have sfFieldsData but no DOM elements
        if (formData.fields.length === 0 && window.sfFieldsData && window.sfFieldsData.length > 0) {
            formData.fields = window.sfFieldsData;
        } else if (formData.fields.length === 0) {
            window.SF.notify(window.SF.t('addOneField', 'Please add at least one field to your form.'));
            return;
        }

        // Show loading state
        if (formId !== '0') {
            $saveButton.prop('disabled', true).html('Updating... <span class="sf-loading-spinner"></span>');
            $saveMessage.html('').removeClass('active');
        } else {
            $saveButton.prop('disabled', true).html('Publishing... <span class="sf-loading-spinner"></span>');
            $saveMessage.html('').removeClass('active');
        }

        // Save form
        $.ajax({
            url: sfAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_save_form',
                nonce: sfAdmin.nonce,
                form_id: formId,
                form_data: JSON.stringify(formData)
            },
            beforeSend: function () {
            },
            success: function (response) {

                if (response.success) {
                    // Show success message
                    $saveMessageBox.show();
                    showSaveMessage($saveMessage, sfIcon('check') + ' ' + (response.data.message || 'Form saved successfully!'), false);

                    // For new forms, ensure the button stays disabled permanently
                    if (formId === '0') {
                        $saveButton.prop('disabled', true).html(sfIcon('check') + ' Published Form');
                        $saveButton.data('form-published', true);
                        $saveButton.addClass('sf-form-published');

                        // Update form ID in the hidden field
                        if (response.data.form_id) {
                            $('#form-id').val(response.data.form_id);
                        }

                        // Show shortcode section
                        $('#sf-form-success-shortcode-section').show();
                        $('#sf-shortcode').val('[sigmaforms id="' + response.data.form_id + '"]');
                        $('.copy-shortcode').data('clipboard-text', '[sigmaforms id="' + response.data.form_id + '"]');

                        // Update URL to include form ID
                        if (response.data.form_id) {
                            const nonce = response.data.edit_nonce || '';
                            const newUrl = window.location.href + '&form_id=' + response.data.form_id + '&_wpnonce=' + nonce;
                            window.history.replaceState({}, document.title, newUrl);
                        }
                    } else {
                        $('.sf-wizard-step.sf-wizard-step-edit.active[data-step="4"]').attr('class', 'sf-wizard-step sf-wizard-step-edit completed');

                    }
                } else {
                    // Show error message
                    $saveMessageBox.show();
                    showSaveMessage($saveMessage, sfIcon('warning') + ' ' + (response.data.message || 'Error saving form.'), true);
                }
            },
            error: function (xhr, status, error) {
                // Show error message
                showSaveMessage($saveMessage, sfIcon('warning') + ' Error saving form.', true);
            },
            complete: function () {
                // Remove loading state
                if (formId !== '0') {
                    $saveButton.prop('disabled', false).html(sfIcon('refresh') + ' Update Form');
                } else {
                    // For new forms, keep the button permanently disabled after successful publication
                    $saveButton.prop('disabled', true).html(sfIcon('check') + ' Published Form');
                    $('.sf-wizard-step[data-step="4"]').removeClass('active').addClass('completed');
                    $('button.sf-btn.sf-prev-step[data-goto="3"]').prop('disabled', true);
                    $('button.sf-btn.sf-prev-step[data-goto="3"]').remove()
                    $('.sf-wizard-navigation').prepend(`
                        <button type="button" class="sf-btn sf-btn-secondary sf-update-step"> 
                            <span class="dashicons dashicons-arrow-left-alt"></span> 
                            Back to Configure
                        </button>
                    `);
                    // Restore reload behavior, but set a flag before reload
                    $('.sf-wizard-navigation').off('click', '.sf-update-step').on('click', '.sf-update-step', function (e) {
                        e.preventDefault();
                        try {
                            sessionStorage.setItem('sfGoToStep', '3');
                        } catch (err) { }
                        location.reload();
                    });

                    // Set a flag to prevent the button from being re-enabled
                    $saveButton.data('form-published', true);

                    // Add a class to make it visually clear the form is published
                    $saveButton.addClass('sf-form-published');
                }
            }
        });
    }

    /**
     * Open form element settings (title, submit button)
     * 
     * @param {string} elementType Type of form element ('header', 'submit')
     */
    function openFormElementSettings(elementType) {
        const $popup = $('.sf-field-settings-popup');

        // --- Refactored Logic ---
        // 1. Reset popup state
        $popup.removeData('field-id');
        $popup.data('form-element-type', elementType);
        $popup.find('.sf-settings-group').hide();

        // 2. Hide irrelevant tabs
        $popup.find('.sf-settings-tab[data-tab="advanced"]').hide();
        $popup.find('.sf-settings-tab[data-tab="conditional"]').hide();
        $popup.find('.sf-settings-tab[data-tab="math"]').hide();
        switchSettingsTab('basic'); // Ensure basic tab is active

        // 3. Populate and show relevant group
        if (elementType === 'submit') {
            $popup.find('.sf-field-settings-title').text('Submit Button Settings');

            // Get current values
            const text = window.sfFormSettings?.submit_button_text || $('#form-submit-button-text').val() || 'Submit';
            const width = window.sfFormSettings?.submit_button_width || 'auto';
            const align = window.sfFormSettings?.submit_button_align || 'left';

            // Populate inputs
            $('#submit-button-text-input').val(text);
            $('#submit-button-width-input').val(width);
            $('#submit-button-align-input').val(align);

            $popup.find('.sf-settings-group-submit').show();
        }

        // 4. Show the popup
        $popup.fadeIn(200);
    }

    /**
     * Open the form settings modal
     */
    function openFormSettingsModal() {
        // Populate modal with current values
        const currentSubmitText = $('#sf-preview-submit-button').text();

        $('#form-submit-button-text-input').val(currentSubmitText);

        // Show modal
        $('#sf-form-settings-modal').addClass('show');
    }

    /**
     * Close the form settings modal
     */
    function closeFormSettingsModal() {
        $('#sf-form-settings-modal').removeClass('show');
    }

    /**
     * Save form settings from modal
     */
    function saveFormSettings() {
        const submitText = $('#form-submit-button-text-input').val().trim();

        // Update preview
        $('#sf-preview-submit-button').text(submitText || 'Submit');

        // Update hidden form fields for step 3
        $('#form-submit-button-text').val(submitText);

        // Store in global settings
        if (!window.sfFormSettings) {
            window.sfFormSettings = {};
        }
        window.sfFormSettings.submit_button_text = submitText;

        // Close modal
        closeFormSettingsModal();

        // Show success message
        const $message = $('<div class="sf-settings-saved-message">Settings saved successfully!</div>');
        $('.sf-visual-form-builder').append($message);
        setTimeout(() => {
            $message.fadeOut(300, function () {
                $(this).remove();
            });
        }, 2000);

        // Trigger custom event for form settings saved
        $(document).trigger('sf:form_settings_saved');
    }

    /**
     * Update form settings preview in real-time
     */
    function updateFormSettingsPreview() {
        const submitText = $('#form-submit-button-text-input').val().trim();

        // Update preview in real-time
        $('#sf-preview-submit-button').text(submitText || 'Submit');
    }

    /**
     * Add a new math field to the math function settings
     */
    function addMathField(selectedFieldId = null) {
        // Use a more unique ID to prevent conflicts
        const fieldId = 'math_field_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        const availableFields = getAvailableFieldsForMath();

        const fieldHtml = `
            <div class="sf-math-field-item" data-field-id="${fieldId}">
                <select class="sf-math-field-select">
                    <option value="">Select a field</option>
                    ${availableFields}
                </select>
                <button type="button" class="sf-remove-math-field" title="Remove field" style="background: #ef4444; color: white; border: none; border-radius: 6px; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 16px; font-weight: bold; line-height: 1; padding: 0; min-width: 24px; min-height: 24px; opacity: 1; visibility: visible; position: relative; z-index: 10;" onmouseover="this.style.background='#dc2626'" onmouseout="this.style.background='#ef4444'">
                    ×
                </button>
            </div>
        `;

        $('.sf-math-fields-list').append(fieldHtml);

        // Debug: Check if the button was added
        const $addedField = $('.sf-math-fields-list .sf-math-field-item:last');
        const $removeButton = $addedField.find('.sf-remove-math-field');

        // If a field ID was provided, select it
        if (selectedFieldId) {
            const $currentField = $('.sf-math-fields-list .sf-math-field-item:last');
            $currentField.find('.sf-math-field-select').val(selectedFieldId);
        }

        updateMathPreview();

        // Return the field ID for debugging
        return fieldId;
    }

    /**
     * Get available fields for math calculations (only text and number fields)
     */
    function getAvailableFieldsForMath() {
        const currentFieldId = $('.sf-field-settings-popup').data('field-id');
        let options = '';

        if (window.sfFieldsData) {
            window.sfFieldsData.forEach(field => {
                // Skip current field
                if (field.id === currentFieldId) {
                    return;
                }

                // Only include text and number fields for math calculations
                const allowedTypes = ['text', 'number'];
                if (!allowedTypes.includes(field.type)) {
                    return;
                }

                const fieldLabel = field.label || `Field ${field.id}`;
                options += `<option value="${field.id}">${fieldLabel}</option>`;
            });
        }

        return options;
    }

    /**
     * Update the math preview based on current settings
     */
    function updateMathPreview() {
        const calculationType = $('.sf-math-calculation-type').val();
        const $previewResult = $('.sf-math-preview-result');
        const $previewText = $('.sf-math-preview-text');

        if (calculationType === 'custom') {
            const formula = $('.sf-math-formula').val().trim();
            if (formula) {
                $previewText.text(`Formula: ${formula}`);
                $previewResult.addClass('has-formula');
            } else {
                $previewText.text('Enter a custom formula');
                $previewResult.removeClass('has-formula');
            }
        } else {
            const selectedFields = [];
            $('.sf-math-field-select').each(function () {
                const fieldId = $(this).val();
                if (fieldId) {
                    // Get the field label for display
                    const field = window.sfFieldsData.find(f => f.id === fieldId);
                    const fieldLabel = field ? field.label : fieldId;
                    selectedFields.push(fieldLabel);
                }
            });

            if (selectedFields.length > 0) {
                let previewText = '';
                switch (calculationType) {
                    case 'sum':
                        previewText = `Sum of: ${selectedFields.join(' + ')}`;
                        break;
                    case 'subtract':
                        previewText = `Subtract: ${selectedFields.join(' - ')}`;
                        break;
                    case 'multiply':
                        previewText = `Multiply: ${selectedFields.join(' × ')}`;
                        break;
                    case 'divide':
                        previewText = `Divide: ${selectedFields.join(' ÷ ')}`;
                        break;
                    case 'percentage':
                        previewText = `Percentage: ${selectedFields[0]}% of ${selectedFields[1] || 'total'}`;
                        break;
                    case 'average':
                        previewText = `Average of: ${selectedFields.join(', ')}`;
                        break;
                }
                $previewText.text(previewText);
                $previewResult.addClass('has-formula');
            } else {
                $previewText.text('Select fields for calculation');
                $previewResult.removeClass('has-formula');
            }
        }
    }

    /**
     * Calculate and display the math field result in the editor
     */
    function calculateMathFieldInEditor() {
        const calculationType = $('.sf-math-calculation-type').val();
        const $previewResult = $('.sf-math-preview-result');
        const $previewText = $('.sf-math-preview-text');

        if (!calculationType) {
            $previewText.text('Select a calculation type to see preview');
            return;
        }

        if (calculationType === 'custom') {
            const formula = $('.sf-math-formula').val();
            if (formula) {
                $previewText.text(`Formula: ${formula}`);
                $previewResult.addClass('has-formula');
            } else {
                $previewText.text('Enter a custom formula');
                $previewResult.removeClass('has-formula');
            }
            return;
        }

        // Get selected fields
        const selectedFields = $('.sf-math-fields-list .sf-math-field-select').map(function () {
            return $(this).val();
        }).get().filter(Boolean);

        if (selectedFields.length === 0) {
            $previewText.text('Select fields for calculation');
            $previewResult.removeClass('has-formula');
            return;
        }

        // Get current field values from the form preview
        let result = 0;
        let calculationText = '';

        try {
            switch (calculationType) {
                case 'sum':
                    result = selectedFields.reduce((sum, fieldId) => {
                        const fieldValue = getFieldValueFromPreview(fieldId);
                        return sum + (parseFloat(fieldValue) || 0);
                    }, 0);
                    calculationText = `Sum: ${selectedFields.join(' + ')} = ${result}`;
                    break;

                case 'subtract':
                    if (selectedFields.length >= 2) {
                        const firstValue = parseFloat(getFieldValueFromPreview(selectedFields[0])) || 0;
                        const secondValue = parseFloat(getFieldValueFromPreview(selectedFields[1])) || 0;
                        result = firstValue - secondValue;
                        calculationText = `Subtract: ${selectedFields[0]} - ${selectedFields[1]} = ${result}`;
                    }
                    break;

                case 'multiply':
                    result = selectedFields.reduce((product, fieldId) => {
                        const fieldValue = getFieldValueFromPreview(fieldId);
                        return product * (parseFloat(fieldValue) || 1);
                    }, 1);
                    calculationText = `Multiply: ${selectedFields.join(' × ')} = ${result}`;
                    break;

                case 'divide':
                    if (selectedFields.length >= 2) {
                        const firstValue = parseFloat(getFieldValueFromPreview(selectedFields[0])) || 0;
                        const secondValue = parseFloat(getFieldValueFromPreview(selectedFields[1])) || 1;
                        result = secondValue !== 0 ? firstValue / secondValue : 0;
                        calculationText = `Divide: ${selectedFields[0]} ÷ ${selectedFields[1]} = ${result}`;
                    }
                    break;

                case 'percentage':
                    if (selectedFields.length >= 2) {
                        const part = parseFloat(getFieldValueFromPreview(selectedFields[0])) || 0;
                        const whole = parseFloat(getFieldValueFromPreview(selectedFields[1])) || 1;
                        result = whole !== 0 ? (part / whole) * 100 : 0;
                        calculationText = `Percentage: ${selectedFields[0]} is ${result.toFixed(2)}% of ${selectedFields[1]}`;
                    }
                    break;

                case 'average':
                    const values = selectedFields.map(fieldId => parseFloat(getFieldValueFromPreview(fieldId)) || 0);
                    result = values.reduce((sum, val) => sum + val, 0) / values.length;
                    calculationText = `Average of ${selectedFields.join(', ')} = ${result.toFixed(2)}`;
                    break;
            }

            // Apply rounding if enabled
            const roundResult = $('.sf-math-round-result').is(':checked');
            if (roundResult) {
                const decimalPlaces = parseInt($('.sf-math-decimal-places').val()) || 0;
                result = Math.round(result * Math.pow(10, decimalPlaces)) / Math.pow(10, decimalPlaces);
            }

            // Display the result
            $previewText.text(calculationText);
            $previewResult.removeClass('has-formula');

            // Also update the preview result with the calculated value
            $('.sf-math-preview-result').html(`
                <span class="sf-math-preview-text">${calculationText}</span>
                <div class="sf-math-preview-value">Result: <strong>${result}</strong></div>
            `);

        } catch (error) {
            $previewText.text('Error calculating result');
        }
    }

    /**
     * Get field value from the form preview
     */
    function getFieldValueFromPreview(fieldId) {
        // Look for the field in the preview
        const $field = $(`.sf-preview-field[data-field-id="${fieldId}"]`);
        if ($field.length === 0) return '0';

        // Get the input value
        const $input = $field.find('input, textarea, select');
        if ($input.length === 0) return '0';

        let value = $input.val();
        if (!value || value === '') {
            // If no value, try to get placeholder or default
            value = $input.attr('placeholder') || '0';
        }

        // Convert to number, default to 0 if invalid
        const numValue = parseFloat(value);
        return isNaN(numValue) ? 0 : numValue;
    }

    /**
     * Initialize country selection interface
     */
    function initCountrySelectionInterface(preSelectedCountries) {

        const $container = $('.sf-countries-list');
        $container.empty();

        // Ensure preSelectedCountries is an array
        preSelectedCountries = preSelectedCountries || [];

        // Separate countries into selected and unselected
        const selectedCountries = [];
        const unselectedCountries = [];

        COUNTRIES_LIST.forEach(function (country) {
            if (preSelectedCountries.includes(country.code)) {
                selectedCountries.push(country);
            } else {
                unselectedCountries.push(country);
            }
        });

        // Add selected countries first (if any)
        if (selectedCountries.length > 0) {
            const $selectedSection = $('<div class="sf-countries-section sf-selected-countries-section"><div class="sf-countries-section-title">Selected Countries</div></div>');
            selectedCountries.forEach(function (country) {
                const $countryItem = $(`
                    <div class="sf-country-item sf-country-selected" data-country-code="${country.code}">
                        <div class="sf-country-checkbox checked" data-code="${country.code}"></div>
                        <span class="sf-country-flag">${country.flag}</span>
                        <span class="sf-country-name">${country.name}</span>
                        <span class="sf-country-code">${country.code}</span>
                    </div>
                `);
                $selectedSection.append($countryItem);
            });
            $container.append($selectedSection);
        }

        // Add unselected countries
        if (unselectedCountries.length > 0) {
            const sectionTitle = selectedCountries.length > 0 ? 'Other Countries' : 'All Countries';
            const $unselectedSection = $(`<div class="sf-countries-section sf-unselected-countries-section"><div class="sf-countries-section-title">${sectionTitle}</div></div>`);
            unselectedCountries.forEach(function (country) {
                const $countryItem = $(`
                    <div class="sf-country-item" data-country-code="${country.code}">
                        <div class="sf-country-checkbox" data-code="${country.code}"></div>
                        <span class="sf-country-flag">${country.flag}</span>
                        <span class="sf-country-name">${country.name}</span>
                        <span class="sf-country-code">${country.code}</span>
                    </div>
                `);
                $unselectedSection.append($countryItem);
            });
            $container.append($unselectedSection);
        }

        // Update selected count
        updateSelectedCountriesCount();
    }

    /**
     * Initialize phone country selection interface
     */
    function initPhoneCountrySelectionInterface(preSelectedCountries) {

        const $container = $('.sf-phone-countries-list');
        $container.empty();

        // Ensure preSelectedCountries is an array
        preSelectedCountries = preSelectedCountries || [];

        // Separate countries into selected and unselected
        const selectedCountries = [];
        const unselectedCountries = [];

        COUNTRIES_LIST.forEach(function (country) {
            if (preSelectedCountries.includes(country.code)) {
                selectedCountries.push(country);
            } else {
                unselectedCountries.push(country);
            }
        });

        // Add selected countries first (if any)
        if (selectedCountries.length > 0) {
            const $selectedSection = $('<div class="sf-phone-countries-section sf-selected-phone-countries-section"><div class="sf-phone-countries-section-title">Selected Countries</div></div>');
            selectedCountries.forEach(function (country) {
                const $countryItem = $(`
                    <div class="sf-phone-country-item sf-phone-country-selected" data-country-code="${country.code}">
                        <div class="sf-phone-country-checkbox checked" data-code="${country.code}"></div>
                        <span class="sf-phone-country-flag">${country.flag}</span>
                        <span class="sf-phone-country-name">${country.name}</span>
                        <span class="sf-phone-country-phone-code">${country.phoneCode}</span>
                        <span class="sf-phone-country-code">${country.code}</span>
                    </div>
                `);
                $selectedSection.append($countryItem);
            });
            $container.append($selectedSection);
        }

        // Add unselected countries
        if (unselectedCountries.length > 0) {
            const sectionTitle = selectedCountries.length > 0 ? 'Other Countries' : 'All Countries';
            const $unselectedSection = $(`<div class="sf-phone-countries-section sf-unselected-phone-countries-section"><div class="sf-phone-countries-section-title">${sectionTitle}</div></div>`);
            unselectedCountries.forEach(function (country) {
                const $countryItem = $(`
                    <div class="sf-phone-country-item" data-country-code="${country.code}">
                        <div class="sf-phone-country-checkbox" data-code="${country.code}"></div>
                        <span class="sf-phone-country-flag">${country.flag}</span>
                        <span class="sf-phone-country-name">${country.name}</span>
                        <span class="sf-phone-country-phone-code">${country.phoneCode}</span>
                        <span class="sf-phone-country-code">${country.code}</span>
                    </div>
                `);
                $unselectedSection.append($countryItem);
            });
            $container.append($unselectedSection);
        }

        // Update selected count
        updateSelectedPhoneCountriesCount();
    }

    /**
     * Update selected countries count
     */
    function updateSelectedCountriesCount() {
        const selectedCount = $('.sf-country-checkbox.checked').length;
        $('.sf-selected-count').text(`${selectedCount} selected`);

        // Update section titles
        updateSectionTitles();
    }

    /**
     * Update section titles based on current selection
     */
    function updateSectionTitles() {
        const $selectedSection = $('.sf-selected-countries-section');
        const $unselectedSection = $('.sf-unselected-countries-section');
        const selectedCount = $('.sf-country-checkbox.checked').length;

        if (selectedCount > 0) {
            if ($selectedSection.length === 0) {
                // Create selected section if it doesn't exist
                const $newSelectedSection = $('<div class="sf-countries-section sf-selected-countries-section"><div class="sf-countries-section-title">Selected Countries</div></div>');
                $('.sf-countries-list').prepend($newSelectedSection);
            }
            $unselectedSection.find('.sf-countries-section-title').text('Other Countries');
        } else {
            // Remove selected section if no countries are selected
            $selectedSection.remove();
            $unselectedSection.find('.sf-countries-section-title').text('All Countries');
        }
    }

    /**
     * Move country item to selected section
     */
    function moveCountryToSelectedSection($item) {
        let $selectedSection = $('.sf-selected-countries-section');

        // Create selected section if it doesn't exist
        if ($selectedSection.length === 0) {
            $selectedSection = $('<div class="sf-countries-section sf-selected-countries-section"><div class="sf-countries-section-title">Selected Countries</div></div>');
            $('.sf-countries-list').prepend($selectedSection);
        }

        // Move item to selected section
        $selectedSection.append($item);
        updateSectionTitles();
    }

    /**
     * Move country item to unselected section
     */
    function moveCountryToUnselectedSection($item) {
        const $unselectedSection = $('.sf-unselected-countries-section');

        // Move item to unselected section
        $unselectedSection.append($item);
        updateSectionTitles();
    }

    /**
     * Get selected countries for a field
     */
    function getSelectedCountries() {
        const selectedCodes = [];
        // Make sure we're looking in the visible popup
        const $popup = $('.sf-field-settings-popup:visible');
        $popup.find('.sf-country-checkbox.checked').each(function () {
            selectedCodes.push($(this).data('code'));
        });
        return selectedCodes;
    }

    /**
     * Set selected countries for a field
     */
    function setSelectedCountries(selectedCodes) {
        // Ensure the countries list is loaded
        const $countryCheckboxes = $('.sf-country-checkbox');

        if ($countryCheckboxes.length === 0) {
            return;
        }

        // Clear all selections first
        $countryCheckboxes.removeClass('checked');

        if (selectedCodes && selectedCodes.length > 0) {
            selectedCodes.forEach(function (code) {
                const $checkbox = $(`.sf-country-checkbox[data-code="${code}"]`);
                if ($checkbox.length > 0) {
                    $checkbox.addClass('checked');
                }
            });
        }
        updateSelectedCountriesCount();
    }

    /**
     * Update selected phone countries count
     */
    function updateSelectedPhoneCountriesCount() {
        const selectedCount = $('.sf-phone-country-checkbox.checked').length;
        $('.sf-phone-selected-count').text(`${selectedCount} selected`);

        // Update section titles
        updatePhoneSectionTitles();
    }

    /**
     * Update phone section titles based on current selection
     */
    function updatePhoneSectionTitles() {
        const $selectedSection = $('.sf-selected-phone-countries-section');
        const $unselectedSection = $('.sf-unselected-phone-countries-section');
        const selectedCount = $('.sf-phone-country-checkbox.checked').length;

        if (selectedCount > 0) {
            if ($selectedSection.length === 0) {
                // Create selected section if it doesn't exist
                const $newSelectedSection = $('<div class="sf-phone-countries-section sf-selected-phone-countries-section"><div class="sf-phone-countries-section-title">Selected Countries</div></div>');
                $('.sf-phone-countries-list').prepend($newSelectedSection);
            }
            $unselectedSection.find('.sf-phone-countries-section-title').text('Other Countries');
        } else {
            // Remove selected section if no countries are selected
            $selectedSection.remove();
            $unselectedSection.find('.sf-phone-countries-section-title').text('All Countries');
        }
    }

    /**
     * Move phone country item to selected section
     */
    function movePhoneCountryToSelectedSection($item) {
        let $selectedSection = $('.sf-selected-phone-countries-section');

        // Create selected section if it doesn't exist
        if ($selectedSection.length === 0) {
            $selectedSection = $('<div class="sf-phone-countries-section sf-selected-phone-countries-section"><div class="sf-phone-countries-section-title">Selected Countries</div></div>');
            $('.sf-phone-countries-list').prepend($selectedSection);
        }

        // Move item to selected section
        $selectedSection.append($item);
        updatePhoneSectionTitles();
    }

    /**
     * Move phone country item to unselected section
     */
    function movePhoneCountryToUnselectedSection($item) {
        const $unselectedSection = $('.sf-unselected-phone-countries-section');

        // Move item to unselected section
        $unselectedSection.append($item);
        updatePhoneSectionTitles();
    }

    /**
     * Get selected phone countries for a field
     */
    function getSelectedPhoneCountries() {
        const selectedCodes = [];
        // Make sure we're looking in the visible popup
        const $popup = $('.sf-field-settings-popup:visible');
        const $checkboxes = $popup.find('.sf-phone-country-checkbox.checked');

        $checkboxes.each(function () {
            const code = $(this).data('code');
            selectedCodes.push(code);
        });

        // Additional debugging - check if ANY phone country checkboxes exist at all
        const $allPhoneCheckboxes = $popup.find('.sf-phone-country-checkbox');

        return selectedCodes;
    }

    /**
     * Set selected phone countries for a field
     */
    function setSelectedPhoneCountries(selectedCodes) {
        // Ensure the phone countries list is loaded
        const $phoneCountryCheckboxes = $('.sf-phone-country-checkbox');

        if ($phoneCountryCheckboxes.length === 0) {
            return;
        }

        // Clear all selections first
        $phoneCountryCheckboxes.removeClass('checked');

        if (selectedCodes && selectedCodes.length > 0) {
            selectedCodes.forEach(function (code) {
                const $checkbox = $(`.sf-phone-country-checkbox[data-code="${code}"]`);
                if ($checkbox.length > 0) {
                    $checkbox.addClass('checked');
                }
            });
        }
        updateSelectedPhoneCountriesCount();
    }

    /**
     * Initialize file types selection interface
     */
    function initFileTypesSelectionInterface(preSelectedTypes, customExtensions) {
        const $container = $('.sf-file-types-list');
        $container.empty();

        // Ensure preSelectedTypes is an array
        preSelectedTypes = preSelectedTypes || [];

        // Group file types by category
        const categories = {
            'image': { title: 'Images', types: [] },
            'document': { title: 'Documents', types: [] },
            'archive': { title: 'Archives', types: [] },
            'audio': { title: 'Audio', types: [] },
            'video': { title: 'Video', types: [] },
            'data': { title: 'Data Files', types: [] },
            'code': { title: 'Code Files', types: [] }
        };

        // Separate file types into selected and unselected within categories
        FILE_TYPES_LIST.forEach(function(fileType) {
            const isSelected = preSelectedTypes.includes(fileType.ext);
            const typeWithSelection = Object.assign({}, fileType, { selected: isSelected });
            
            if (categories[fileType.category]) {
                categories[fileType.category].types.push(typeWithSelection);
            }
        });

        // Create sections for each category
        Object.keys(categories).forEach(function(categoryKey) {
            const category = categories[categoryKey];
            if (category.types.length === 0) return;

            // Separate selected and unselected within category
            const selectedTypes = category.types.filter(t => t.selected);
            const unselectedTypes = category.types.filter(t => !t.selected);

            // Add selected types first
            if (selectedTypes.length > 0) {
                const $selectedSection = $(`<div class="sf-file-types-section sf-selected-file-types-section" data-category="${categoryKey}">
                    <div class="sf-file-types-section-title">${category.title} (Selected)</div>
                </div>`);
                
                selectedTypes.forEach(function(fileType) {
                    const $typeItem = $(`
                        <div class="sf-file-type-item sf-file-type-selected" data-ext="${fileType.ext}">
                            <div class="sf-file-type-checkbox checked" data-ext="${fileType.ext}"></div>
                            <span class="sf-file-type-icon">${fileType.icon}</span>
                            <span class="sf-file-type-name">${fileType.name}</span>
                            <span class="sf-file-type-ext">${fileType.ext}</span>
                        </div>
                    `);
                    $selectedSection.append($typeItem);
                });
                $container.append($selectedSection);
            }

            // Add unselected types
            if (unselectedTypes.length > 0) {
                const sectionTitle = selectedTypes.length > 0 ? category.title : category.title;
                const $unselectedSection = $(`<div class="sf-file-types-section sf-unselected-file-types-section" data-category="${categoryKey}">
                    <div class="sf-file-types-section-title">${sectionTitle}</div>
                </div>`);
                
                unselectedTypes.forEach(function(fileType) {
                    const $typeItem = $(`
                        <div class="sf-file-type-item" data-ext="${fileType.ext}">
                            <div class="sf-file-type-checkbox" data-ext="${fileType.ext}"></div>
                            <span class="sf-file-type-icon">${fileType.icon}</span>
                            <span class="sf-file-type-name">${fileType.name}</span>
                            <span class="sf-file-type-ext">${fileType.ext}</span>
                        </div>
                    `);
                    $unselectedSection.append($typeItem);
                });
                $container.append($unselectedSection);
            }
        });

        // Set custom extensions if provided
        if (customExtensions) {
            $('.sf-custom-file-extensions').val(customExtensions);
        }

        // Update selected count
        updateSelectedFileTypesCount();
    }

    /**
     * Update selected file types count
     */
    function updateSelectedFileTypesCount() {
        const selectedCount = $('.sf-file-type-checkbox.checked').length;
        $('.sf-file-types-selected-count').text(`${selectedCount} selected`);
    }

    /**
     * Move file type item to selected section
     */
    function moveFileTypeToSelectedSection($item, category) {
        // Category titles mapping
        const categoryTitles = {
            'image': 'Images',
            'document': 'Documents',
            'archive': 'Archives',
            'audio': 'Audio',
            'video': 'Video',
            'data': 'Data Files',
            'code': 'Code Files'
        };

        let $selectedSection = $(`.sf-selected-file-types-section[data-category="${category}"]`);

        // Create selected section if it doesn't exist
        if ($selectedSection.length === 0) {
            const categoryTitle = categoryTitles[category] || 'Selected';
            $selectedSection = $(`<div class="sf-file-types-section sf-selected-file-types-section" data-category="${category}">
                <div class="sf-file-types-section-title">${categoryTitle} (Selected)</div>
            </div>`);
            
            // Insert before the unselected section of the same category
            const $unselectedSection = $(`.sf-unselected-file-types-section[data-category="${category}"]`);
            if ($unselectedSection.length > 0) {
                $selectedSection.insertBefore($unselectedSection);
            } else {
                $('.sf-file-types-list').append($selectedSection);
            }
        }

        // Move item to selected section
        $selectedSection.append($item);
    }

    /**
     * Move file type item to unselected section
     */
    function moveFileTypeToUnselectedSection($item, category) {
        const $unselectedSection = $(`.sf-unselected-file-types-section[data-category="${category}"]`);

        if ($unselectedSection.length > 0) {
            // Move item to unselected section
            $unselectedSection.append($item);
        }

        // Remove selected section if empty
        const $selectedSection = $(`.sf-selected-file-types-section[data-category="${category}"]`);
        if ($selectedSection.find('.sf-file-type-item').length === 0) {
            $selectedSection.remove();
        }
    }

    /**
     * Get selected file types for a field
     */
    function getSelectedFileTypes() {
        const selectedExts = [];
        const $popup = $('.sf-field-settings-popup:visible');
        $popup.find('.sf-file-type-checkbox.checked').each(function() {
            selectedExts.push($(this).data('ext'));
        });
        return selectedExts;
    }

    /**
     * Get custom file extensions
     */
    function getCustomFileExtensions() {
        const $input = $('.sf-custom-file-extensions');
        return $input.val().trim();
    }

    /**
     * Set selected file types for a field
     */
    function setSelectedFileTypes(selectedExts) {
        const $fileTypeCheckboxes = $('.sf-file-type-checkbox');

        if ($fileTypeCheckboxes.length === 0) {
            return;
        }

        // Clear all selections first
        $fileTypeCheckboxes.removeClass('checked');

        if (selectedExts && selectedExts.length > 0) {
            selectedExts.forEach(function(ext) {
                const $checkbox = $(`.sf-file-type-checkbox[data-ext="${ext}"]`);
                if ($checkbox.length > 0) {
                    $checkbox.addClass('checked');
                }
            });
        }
        updateSelectedFileTypesCount();
    }

    // Expose functions to SF.VisualEditor namespace
    window.SF.VisualEditor = {
        init: initVisualFormEditor,
        renderVisualFormPreview: renderVisualFormPreview,
        openFieldTypeModal: openFieldTypeModal,
        closeFieldTypeModal: closeFieldTypeModal,
        addNewField: addNewField,
        openFieldSettings: openFieldSettings,
        closeFieldSettings: closeFieldSettings,
        switchSettingsTab: switchSettingsTab,
        saveFieldSettings: saveFieldSettings,
        duplicateField: duplicateField,
        deleteField: deleteField,
        updateFieldsOrder: updateFieldsOrder,
        saveForm: saveForm,
        openFormElementSettings: openFormElementSettings,
        saveFormElementSettings: saveFormElementSettings,
        initCountrySelectionInterface: initCountrySelectionInterface,
        updateSelectedCountriesCount: updateSelectedCountriesCount,
        getSelectedCountries: getSelectedCountries,
        setSelectedCountries: setSelectedCountries,
        moveCountryToSelectedSection: moveCountryToSelectedSection,
        moveCountryToUnselectedSection: moveCountryToUnselectedSection,
        updateSectionTitles: updateSectionTitles,
        initPhoneCountrySelectionInterface: initPhoneCountrySelectionInterface,
        updateSelectedPhoneCountriesCount: updateSelectedPhoneCountriesCount,
        getSelectedPhoneCountries: getSelectedPhoneCountries,
        setSelectedPhoneCountries: setSelectedPhoneCountries,
        movePhoneCountryToSelectedSection: movePhoneCountryToSelectedSection,
        movePhoneCountryToUnselectedSection: movePhoneCountryToUnselectedSection,
        updatePhoneSectionTitles: updatePhoneSectionTitles
    };

})(jQuery); 