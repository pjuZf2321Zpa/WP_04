/**
 * SigmaForms - Conditional Logic Module
 */

(function($) {
    'use strict';

    // Ensure SF namespace exists
    window.SF = window.SF || {};
    window.SF.ConditionalLogic = {};

    // Flag to prevent multiple initializations
    let isConditionalLogicInitialized = false;

    /**
     * Update conditional field options for all fields
     */
    function updateConditionalFieldOptions() {
        const $allFields = $('.sf-fields-container .sf-field-item');
        
        // For each field with conditional logic enabled
        $allFields.each(function() {
            const $fieldItem = $(this);
            const $conditionalFieldSelectors = $fieldItem.find('.sf-conditional-field');
            const currentFieldId = $fieldItem.find('.sf-field-id').val();
            
            // Skip if not using conditional logic
            if (!$fieldItem.find('.sf-field-has-conditional').is(':checked')) {
                return;
            }
            
            // Process each conditional field selector
            $conditionalFieldSelectors.each(function() {
                const $conditionalField = $(this);
                const selectedField = $conditionalField.val();
                
                // Clear existing options and keep first one
                $conditionalField.find('option:not(:first)').remove();
                
                // Add options for each field (except current one)
                $allFields.each(function() {
                    const fieldId = $(this).find('.sf-field-id').val();
                    const fieldLabel = $(this).find('.sf-field-label').val();
                    const fieldType = $(this).find('.sf-field-type').val();
                    
                    // Don't include the field itself as a dependency
                    if (fieldId !== currentFieldId) {
                        const $option = $(`<option value="${fieldId}" data-field-type="${fieldType}">${fieldLabel}</option>`);
                        $conditionalField.append($option);
                        
                        // Re-select previously selected option if it exists
                        if (selectedField === fieldId) {
                            $option.prop('selected', true);
                        }
                    }
                });
            });
        });
    }
    
    /**
     * Initialize advanced conditional logic UI
     */
    function initAdvancedConditionalLogic() {
        // Prevent multiple initializations
        if (isConditionalLogicInitialized) {
            return;
        }
        
        isConditionalLogicInitialized = true;
        
        // Toggle conditional logic settings visibility
        $(document).on('change', '.sf-field-has-conditional', function() {
            const $checkbox = $(this);
            const $rulesContainer = $checkbox.closest('.sf-settings-tab-panel').find('.sf-conditional-rules');
            
            // For compatibility with both old and new UI
            const $oldUIContainer = $checkbox.closest('.sf-settings-tab-panel').find('.sf-conditional-settings');
            
            if ($checkbox.is(':checked')) {
                $rulesContainer.slideDown(200);
                $oldUIContainer.slideDown(200);
            } else {
                $rulesContainer.slideUp(200);
                $oldUIContainer.slideUp(200);
            }
        });
        
        // Handle rule source type change
        $(document).on('change', '.sf-rule-source-type', function() {
            const $select = $(this);
            const sourceType = $select.val();
            const $rule = $select.closest('.sf-condition-rule');
            
            // Hide all field selectors
            $rule.find('.sf-rule-field-selector').hide();
            
            // Show the appropriate field selector
            $rule.find(`.sf-field-source-${sourceType}`).show();
            
            // Special case for user meta
            if (sourceType === 'user') {
                const userDataType = $rule.find('.sf-conditional-user-data').val();
                $rule.find('.sf-conditional-user-meta-key').toggle(userDataType === 'user_meta');
                
                // Handle value input type for user data
                updateValueInputForUserDataType($rule, userDataType);
            } else {
                // Set value input type for date or reset to text for others
                setValueInputForSourceType($rule, sourceType);
            }
            
            // Get the current operator if set
            const selectedOperator = $rule.find('.sf-conditional-operator').val();
            updateOperatorsForSourceType($rule, sourceType, selectedOperator);
        });
        
        // Handle user data type change
        $(document).on('change', '.sf-conditional-user-data', function() {
            const $select = $(this);
            const userDataType = $select.val();
            const $rule = $select.closest('.sf-condition-rule');
            
            // Show/hide meta key input
            $rule.find('.sf-conditional-user-meta-key').toggle(userDataType === 'user_meta');
            
            // Handle value input type for user role
            updateValueInputForUserDataType($rule, userDataType);
            
            // Get the current operator if set
            const selectedOperator = $rule.find('.sf-conditional-operator').val();
            updateOperatorsForUserDataType($rule, userDataType, selectedOperator);
        });
        
        // Handle field selection change
        $(document).on('change', '.sf-conditional-field', function() {
            const $select = $(this);
            const $selectedOption = $select.find('option:selected');
            const fieldType = $selectedOption.data('field-type');
            const $rule = $select.closest('.sf-condition-rule');
            // Get the current operator if set
            const selectedOperator = $rule.find('.sf-conditional-operator').val();
            // Update operators based on field type
            updateOperatorsForFieldType($rule, fieldType, selectedOperator);
            updateValueInputForField($rule, $select.val());
        });
        
        // Add rule button
        $(document).on('click', '.sf-add-rule', function() {
            const $button = $(this);
            const $ruleGroup = $button.closest('.sf-condition-group');
            const $lastRule = $ruleGroup.find('.sf-condition-rule').last();
            const newRuleId = parseInt($lastRule.data('rule-id')) + 1;
            
            // Clone the first rule template
            const $newRule = $ruleGroup.find('.sf-condition-rule').first().clone();
            
            // Update IDs and clear values appropriately
            $newRule.attr('data-rule-id', newRuleId);
            
            // Set default values instead of clearing everything
            $newRule.find('.sf-rule-source-type').val('field'); // Default to field
            $newRule.find('.sf-conditional-field').val(''); // Clear field selection
            $newRule.find('.sf-conditional-user-data').val('logged_in'); // Default user data
            $newRule.find('.sf-conditional-date-type').val('current_date'); // Default date type
            $newRule.find('.sf-conditional-value').val(''); // Clear value
            $newRule.find('.sf-conditional-user-meta-key').val(''); // Clear meta key
            
            // Hide all field selectors except the default (field)
            $newRule.find('.sf-rule-field-selector').hide();
            $newRule.find('.sf-field-source-field').show();
            
            // Set default operators for field source type
            const $operatorSelect = $newRule.find('.sf-conditional-operator');
            $operatorSelect.empty();
            $operatorSelect.append('<option value="=" selected>equals</option>');
            $operatorSelect.append('<option value="!=">does not equal</option>');
            
            // Append the new rule
            $lastRule.after($newRule);
            
            // Update conditional field options
            updateConditionalFieldOptions();
            
            // Initialize operators for the new rule
            setTimeout(function() {
                if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                    window.SF.ConditionalLogic.updateOperatorsForSourceType($newRule, 'field');
                }
            }, 100);
        });
        
        // Remove rule button
        $(document).on('click', '.sf-remove-rule', function() {
            const $button = $(this);
            const $rule = $button.closest('.sf-condition-rule');
            const $ruleGroup = $rule.closest('.sf-condition-group');
            const $conditionGroups = $rule.closest('.sf-condition-groups');
            const ruleCount = $ruleGroup.find('.sf-condition-rule').length;
            const groupCount = $conditionGroups.find('.sf-condition-group').length;
            
            if (ruleCount > 1) {
                // Multiple rules in group - just remove this rule
                $rule.remove();
            } else if (groupCount > 1) {
                // Last rule in group and multiple groups exist - remove entire group and its separator
                const $groupSeparator = $ruleGroup.prev('.sf-group-separator');
                if ($groupSeparator.length > 0) {
                    $groupSeparator.remove();
                } else {
                    // If no separator before, check after
                    const $nextSeparator = $ruleGroup.next('.sf-group-separator');
                    if ($nextSeparator.length > 0) {
                        $nextSeparator.remove();
                    }
                }
                $ruleGroup.remove();
            } else {
                // Last rule in the only group - just reset it
                $rule.find('.sf-rule-source-type').val('field');
                $rule.find('.sf-conditional-field').val('');
                $rule.find('.sf-conditional-user-data').val('logged_in');
                $rule.find('.sf-conditional-date-type').val('current_date');
                $rule.find('.sf-conditional-value').val('');
                $rule.find('.sf-conditional-user-meta-key').val('');
                
                // Reset operators to default field operators
                const $operatorSelect = $rule.find('.sf-conditional-operator');
                $operatorSelect.empty();
                $operatorSelect.append('<option value="=" selected>equals</option>');
                $operatorSelect.append('<option value="!=">does not equal</option>');
                
                // Show field selector, hide others
                $rule.find('.sf-rule-field-selector').hide();
                $rule.find('.sf-field-source-field').show();
            }
        });
        
        // Add condition group button (for OR logic)
        $(document).on('click', '.sf-add-condition-group', function() {
            const $button = $(this);
            const $conditionGroups = $button.closest('.sf-conditional-rules').find('.sf-condition-groups');
            const $lastGroup = $conditionGroups.find('.sf-condition-group').last();
            const newGroupId = parseInt($lastGroup.data('group-id')) + 1;
            
            // Clone the first group template
            const $newGroup = $lastGroup.clone();
            
            // Update group ID
            $newGroup.attr('data-group-id', newGroupId);
            
            // Keep only one rule in the new group
            const $firstRule = $newGroup.find('.sf-condition-rule').first();
            $newGroup.find('.sf-condition-rule:not(:first)').remove();
            
            // Reset values in the first rule with proper defaults
            $firstRule.attr('data-rule-id', 0);
            $firstRule.find('.sf-rule-source-type').val('field'); // Default to field
            $firstRule.find('.sf-conditional-field').val(''); // Clear field selection
            $firstRule.find('.sf-conditional-user-data').val('logged_in'); // Default user data
            $firstRule.find('.sf-conditional-date-type').val('current_date'); // Default date type
            $firstRule.find('.sf-conditional-value').val(''); // Clear value
            $firstRule.find('.sf-conditional-user-meta-key').val(''); // Clear meta key
            
            // Set default operators for field source type
            const $operatorSelect = $firstRule.find('.sf-conditional-operator');
            $operatorSelect.empty();
            $operatorSelect.append('<option value="=" selected>equals</option>');
            $operatorSelect.append('<option value="!=">does not equal</option>');
            
            // Show field selector, hide others
            $firstRule.find('.sf-rule-field-selector').hide();
            $firstRule.find('.sf-field-source-field').show();
            
            // Add the group separator
            const $separator = $('<div class="sf-group-separator"><span>' + sf_vars.text_or + '</span></div>');
            $conditionGroups.append($separator);
            
            // Append the new group
            $conditionGroups.append($newGroup);
            
            // Update conditional field options
            updateConditionalFieldOptions();
            
            // Initialize operators for the new rule
            setTimeout(function() {
                if (window.SF.ConditionalLogic && window.SF.ConditionalLogic.updateOperatorsForSourceType) {
                    window.SF.ConditionalLogic.updateOperatorsForSourceType($firstRule, 'field');
                }
            }, 100);
        });
        
        // AI suggestion button
        $(document).on('click', '.sf-ai-suggest-conditions', function() {
            const $button = $(this);
            const $suggestions = $button.next('.sf-ai-suggestions');
            
            // Find field ID and type from the settings popup (visual editor) or panel (legacy editor)
            let fieldId, fieldType;
            const $settingsPopup = $button.closest('.sf-field-settings-popup');
            const $settingsPanel = $button.closest('.sf-field-settings-panel');
            
            if ($settingsPopup.length > 0) {
                // Visual editor - get from popup
                fieldId = $settingsPopup.find('.sf-field-id').val();
                fieldType = $settingsPopup.find('.sf-field-type').val();
            } else if ($settingsPanel.length > 0) {
                // Legacy editor - get from panel
                fieldId = $settingsPanel.find('.sf-field-id').val();
                fieldType = $settingsPanel.find('.sf-field-type').val();
            } else {
                // Fallback - try to find anywhere in the document
                fieldId = $('.sf-field-id:visible').val();
                fieldType = $('.sf-field-type:visible').val();
            }
            
            if (!fieldId || !fieldType) {
                window.SF.notify(window.SF.t('aiFieldUnknown', 'Unable to determine field information for AI suggestions. Please ensure you have opened field settings first.'), 'error');
                return;
            }
            
            // Show loading state
            $button.prop('disabled', true).text(sf_vars.text_loading);
            
            // Get AI suggestions
            getSuggestedConditions(fieldId, fieldType).done(function(response) {
                
                if (response.success && response.data && response.data.suggestions) {
                    // Display suggestions
                    displayAiSuggestions($suggestions, response.data.suggestions);
                    $suggestions.slideDown(200);
                } else {
                    window.SF.notify((response && response.data && response.data.message) || sf_vars.text_ai_error, 'error');
                }
            }).fail(function(xhr, status, error) {
                window.SF.notify(sf_vars.text_ai_error, 'error');
            }).always(function() {
                // Reset button state
                $button.prop('disabled', false).html('<span class="dashicons dashicons-admin-customizer"></span> ' + sf_vars.text_ai_suggest);
            });
        });

        // Toggle conditional logic settings
        $(document).on('change', '.sf-field-has-conditional', function() {
            const $fieldItem = $(this).closest('.sf-field-item');
            const $conditionalSettings = $fieldItem.find('.sf-conditional-settings');
            
            if ($(this).is(':checked')) {
                $conditionalSettings.slideDown(200);
                
                // Update field options when a field is selected
                const $allFields = $('.sf-fields-container .sf-field-item');
                const currentFieldId = $fieldItem.find('.sf-field-id').val();
                const $conditionalField = $fieldItem.find('.sf-conditional-field');
                
                // Clear existing options and add current fields
                $conditionalField.find('option:not(:first)').remove();
                
                $allFields.each(function() {
                    const fieldId = $(this).find('.sf-field-id').val();
                    const fieldLabel = $(this).find('.sf-field-label').val();
                    
                    // Don't include the field itself as a dependency
                    if (fieldId !== currentFieldId) {
                        $conditionalField.append(`<option value="${fieldId}">${fieldLabel}</option>`);
                    }
                });
            } else {
                $conditionalSettings.slideUp(200);
            }
        });
    }
    
    /**
     * Update available operators based on source type
     */
    function updateOperatorsForSourceType($rule, sourceType, selectedOperator = null) {
        const $operatorSelect = $rule.find('.sf-conditional-operator');
        $operatorSelect.empty();
        let operators = [];
        switch (sourceType) {
            case 'field':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals }
                ];
                break;
            case 'user':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals }
                ];
                break;
            case 'date':
                operators = [
                    { value: 'is_date', label: sf_vars.text_is_date },
                    { value: 'before_date', label: sf_vars.text_before_date },
                    { value: 'after_date', label: sf_vars.text_after_date }
                ];
                break;
        }
        operators.forEach(function(op) {
            $operatorSelect.append(`<option value="${op.value}">${op.label}</option>`);
        });
        if (selectedOperator) {
            $operatorSelect.val(selectedOperator);
        }
    }
    
    /**
     * Update available operators based on user data type
     */
    function updateOperatorsForUserDataType($rule, userDataType, selectedOperator = null) {
        const $operatorSelect = $rule.find('.sf-conditional-operator');
        $operatorSelect.empty();
        let operators = [];
        switch (userDataType) {
            case 'logged_in':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals }
                ];
                break;
            case 'user_role':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals }
                ];
                break;
            case 'user_meta':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals },
                    { value: 'contains', label: sf_vars.text_contains },
                    { value: '>', label: sf_vars.text_greater_than },
                    { value: '<', label: sf_vars.text_less_than },
                    { value: 'is_empty', label: sf_vars.text_is_empty },
                    { value: 'is_not_empty', label: sf_vars.text_is_not_empty }
                ];
                break;
        }
        operators.forEach(function(op) {
            $operatorSelect.append(`<option value="${op.value}">${op.label}</option>`);
        });
        if (selectedOperator) {
            $operatorSelect.val(selectedOperator);
        }
    }
    
    /**
     * Update available operators based on field type
     */
    function updateOperatorsForFieldType($rule, fieldType, selectedOperator = null) {
        const $operatorSelect = $rule.find('.sf-conditional-operator');
        $operatorSelect.empty();
        
        let operators = [];
        
        switch (fieldType) {
            case 'text':
            case 'textarea':
            case 'email':
            case 'phone':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals },
                    { value: 'contains', label: sf_vars.text_contains },
                    { value: 'starts_with', label: sf_vars.text_starts_with },
                    { value: 'ends_with', label: sf_vars.text_ends_with },
                    { value: 'is_empty', label: sf_vars.text_is_empty },
                    { value: 'is_not_empty', label: sf_vars.text_is_not_empty }
                ];
                break;
                
            case 'number':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals },
                    { value: '>', label: sf_vars.text_greater_than },
                    { value: '<', label: sf_vars.text_less_than },
                    { value: '>=', label: sf_vars.text_greater_equal },
                    { value: '<=', label: sf_vars.text_less_equal },
                    { value: 'is_empty', label: sf_vars.text_is_empty },
                    { value: 'is_not_empty', label: sf_vars.text_is_not_empty }
                ];
                break;
                
            case 'date':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals },
                    { value: 'before_date', label: sf_vars.text_before_date },
                    { value: 'after_date', label: sf_vars.text_after_date },
                    { value: 'is_empty', label: sf_vars.text_is_empty },
                    { value: 'is_not_empty', label: sf_vars.text_is_not_empty }
                ];
                break;
                
            case 'checkbox':
                operators = [
                    { value: 'is_checked', label: sf_vars.text_is_checked },
                    { value: 'is_not_checked', label: sf_vars.text_is_not_checked }
                ];
                break;
                
            case 'radio':
            case 'select':
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals }
                ];
                break;
                
            default:
                operators = [
                    { value: '=', label: sf_vars.text_equals },
                    { value: '!=', label: sf_vars.text_not_equals }
                ];
        }
        
        // Add operators to select
        operators.forEach(function(op) {
            $operatorSelect.append(`<option value="${op.value}">${op.label}</option>`);
        });
        // Set the selected value if provided
        if (selectedOperator) {
            $operatorSelect.val(selectedOperator);
        }
    }
    
    /**
     * Update value input type for user data type
     */
    function updateValueInputForUserDataType($rule, userDataType) {
        const $valueContainer = $rule.find('.sf-rule-value-container');
        const currentValue = $rule.find('.sf-conditional-value').val();
        
        if (userDataType === 'user_role') {
            // Create dropdown for user roles
            const $dropdown = $('<select class="sf-conditional-value"></select>');
            $dropdown.append('<option value="">' + sf_vars.text_select_field + '</option>');
            
            // Add user roles from localized data
            if (sf_vars.user_roles && sf_vars.user_roles.length > 0) {
                sf_vars.user_roles.forEach(function(role) {
                    const $option = $('<option value="' + role + '">' + role + '</option>');
                    if (currentValue === role) {
                        $option.prop('selected', true);
                    }
                    $dropdown.append($option);
                });
            }
            
            // Replace the input with dropdown
            $valueContainer.empty().append($dropdown);
        } else {
            // Reset to text input for other user data types
            resetValueInputToText($rule, currentValue);
        }
    }
    
    /**
     * Offer a field's options as the rule value for choice fields.
     *
     * Radio, select, checkbox and country fields match on the stored option
     * value ("option1"), not the label people see ("Option 1"), so a typed
     * label never matched.
     */
    function updateValueInputForField($rule, fieldId) {
        const fields = Array.isArray(window.sfFieldsData) ? window.sfFieldsData : [];
        const field = fields.find(function(f) { return f.id === fieldId; });
        const currentValue = $rule.find('.sf-conditional-value').val() || '';

        if (!field || ['radio', 'select', 'checkbox', 'country'].indexOf(field.type) === -1 || !Array.isArray(field.options) || !field.options.length) {
            resetValueInputToText($rule, currentValue);
            return;
        }

        const $dropdown = $('<select class="sf-conditional-value"></select>');
        $dropdown.append($('<option value=""></option>').text(sf_vars.text_value || 'Value'));

        field.options.forEach(function(option) {
            const value = (option && typeof option === 'object') ? String(option.value !== undefined && option.value !== '' ? option.value : option.label) : String(option);
            const label = (option && typeof option === 'object') ? String(option.label || option.value) : String(option);
            $dropdown.append($('<option></option>').val(value).text(label));
        });

        // Keep a saved value even if that option was since removed.
        if (currentValue && !$dropdown.find('option').filter(function() { return this.value === currentValue; }).length) {
            $dropdown.append($('<option></option>').val(currentValue).text(currentValue));
        }
        $dropdown.val(currentValue);

        $rule.find('.sf-rule-value-container').empty().append($dropdown);
    }

    /**
     * Reset value input to text type
     */
    function resetValueInputToText($rule, currentValue = '') {
        const $valueContainer = $rule.find('.sf-rule-value-container');
        
        // Check if it's already a text input
        const $existingInput = $valueContainer.find('.sf-conditional-value');
        if ($existingInput.length > 0 && $existingInput.is('input[type="text"]')) {
            return; // Already a text input, no need to change
        }
        
        // Create text input
        const $textInput = $('<input type="text" class="sf-conditional-value" placeholder="' + sf_vars.text_value + '">');
        if (currentValue) {
            $textInput.val(currentValue);
        }
        
        // Replace the current input with text input
        $valueContainer.empty().append($textInput);
    }
    
    /**
     * Display AI suggestions
     */
    function displayAiSuggestions($container, suggestions) {
        $container.empty();
        
        // Create suggestion list
        const $list = $('<ul class="sf-ai-suggestion-list"></ul>');
        
        suggestions.forEach(function(suggestion, index) {
            const $item = $(`
                <li class="sf-ai-suggestion-item">
                    <div class="sf-ai-suggestion-content">
                        <strong>${suggestion.label}</strong>
                        <p>${suggestion.description}</p>
                    </div>
                    <div class="sf-ai-suggestion-action">
                        <button type="button" class="button sf-apply-suggestion" data-suggestion-id="${index}">
                            ${sf_vars.text_apply}
                        </button>
                    </div>
                </li>
            `);
            
            $list.append($item);
        });
        
        $container.append($list);
        
        // Remove any existing handlers and add new one
        $container.off('click', '.sf-apply-suggestion');
        $container.on('click', '.sf-apply-suggestion', function(e) {
            e.preventDefault();
            const suggestionId = $(this).data('suggestion-id');
            applySuggestion(suggestions[suggestionId]);
        });
        
    }
    
    /**
     * Apply an AI suggestion
     */
    function applySuggestion(suggestion) {
        
        // Find the settings container - try popup first (visual editor), then panel (legacy editor)
        let $fieldSettings = $('.sf-field-settings-popup:visible');
        if ($fieldSettings.length === 0) {
            $fieldSettings = $('.sf-field-settings-panel:visible');
        }
        
        if ($fieldSettings.length === 0) {
            window.SF.notify(window.SF.t('aiNoFieldSettings', 'Could not find field settings to apply suggestion.'), 'error');
            return;
        }
        
        const $conditionGroups = $fieldSettings.find('.sf-condition-groups');
        
        if ($conditionGroups.length === 0) {
            window.SF.notify(window.SF.t('aiNoConditionGroups', 'Could not find the condition groups to apply this suggestion.'), 'error');
            return;
        }
        
        // Clear existing conditions
        $conditionGroups.empty();
        
        // Enable conditional logic checkbox and show rules
        const $hasConditional = $fieldSettings.find('.sf-field-has-conditional');
        if ($hasConditional.length > 0 && !$hasConditional.is(':checked')) {
            $hasConditional.prop('checked', true).trigger('change');
        }
        
        // Show conditional rules if hidden
        const $conditionalRules = $fieldSettings.find('.sf-conditional-rules');
        if ($conditionalRules.length > 0) {
            $conditionalRules.show();
        }
        
        // Set action
        const $conditionalAction = $fieldSettings.find('.sf-conditional-action');
        if ($conditionalAction.length > 0) {
            $conditionalAction.val(suggestion.action);
        }
        
        // Set logic type
        const $conditionalLogicType = $fieldSettings.find('.sf-conditional-logic-type');
        if ($conditionalLogicType.length > 0) {
            $conditionalLogicType.val(suggestion.logic_type || 'all');
        }
        
        // Add each condition group
        suggestion.groups.forEach(function(group, groupIndex) {
            // Create group
            const $group = $(`<div class="sf-condition-group" data-group-id="${groupIndex}"></div>`);
            
            // Add OR separator if not the first group
            if (groupIndex > 0) {
                $conditionGroups.append('<div class="sf-group-separator"><span>' + sf_vars.text_or + '</span></div>');
            }
            
            // Add each rule
            group.rules.forEach(function(rule, ruleIndex) {
                let $rule;
                
                // Try to use visual editor's function if available
                if (window.SF.VisualEditor && typeof window.SF.VisualEditor.createAdvancedRuleElement === 'function') {
                    // Use visual editor's function (not available publicly, so we'll create manually)
                    $rule = createAdvancedRuleElement(rule, ruleIndex);
                } else {
                    // Use conditional logic's function
                    $rule = createRuleFromSuggestion(rule, ruleIndex);
                }
                
                $group.append($rule);
            });
            
            $conditionGroups.append($group);
        });
        
        // Update conditional field options
        updateConditionalFieldOptions();
        
        // Hide the suggestions
        $('.sf-ai-suggestions').slideUp(200);
        
    }
    
    /**
     * Create a simplified advanced rule element that works with visual editor
     * 
     * @param {Object} rule Rule data
     * @param {number} ruleId Rule ID
     * @return {jQuery} Rule element
     */
    function createAdvancedRuleElement(rule, ruleId) {
        const $rule = $(`
            <div class="sf-condition-rule" data-rule-id="${ruleId}">
                <div class="sf-rule-field-container">
                    <select class="sf-rule-source-type">
                        <option value="field" ${rule.source_type === 'field' ? 'selected' : ''}>Form Field</option>
                        <option value="user" ${rule.source_type === 'user' ? 'selected' : ''}>User Data</option>
                        <option value="date" ${rule.source_type === 'date' ? 'selected' : ''}>Date/Time</option>
                    </select>
                    
                    <!-- Field selector for form fields -->
                    <div class="sf-rule-field-selector sf-field-source-field" ${rule.source_type === 'field' ? '' : 'style="display: none;"'}>
                        <select class="sf-conditional-field">
                            <option value="">Select a field</option>
                            <!-- Fields will be populated by updateConditionalFieldOptions -->
                        </select>
                    </div>
                    
                    <!-- User data selector -->
                    <div class="sf-rule-field-selector sf-field-source-user" ${rule.source_type === 'user' ? '' : 'style="display: none;"'}>
                        <select class="sf-conditional-user-data">
                            <option value="logged_in" ${rule.field === 'logged_in' ? 'selected' : ''}>User is logged in</option>
                            <option value="user_role" ${rule.field === 'user_role' ? 'selected' : ''}>User role</option>
                            <option value="user_meta" ${rule.field === 'user_meta' ? 'selected' : ''}>User meta field</option>
                        </select>
                        
                        <input type="text" class="sf-conditional-user-meta-key" value="${rule.meta_key || ''}" placeholder="Meta key" ${rule.field === 'user_meta' ? '' : 'style="display: none;"'}>
                    </div>
                    
                    <!-- Date/Time selector -->
                    <div class="sf-rule-field-selector sf-field-source-date" ${rule.source_type === 'date' ? '' : 'style="display: none;"'}>
                        <select class="sf-conditional-date-type">
                            <option value="current_date" ${rule.field === 'current_date' ? 'selected' : ''}>Current date</option>
                            <option value="current_time" ${rule.field === 'current_time' ? 'selected' : ''}>Current time</option>
                            <option value="current_day" ${rule.field === 'current_day' ? 'selected' : ''}>Current day of week</option>
                        </select>
                    </div>
                </div>
                
                <div class="sf-rule-field-container-inner">
                    <!-- Operator selector -->
                    <div class="sf-rule-operator-container">
                        <select class="sf-conditional-operator" data-current-value="${rule.operator || '='}">
                            <!-- Operators will be populated dynamically by JavaScript -->
                        </select>
                    </div>
                    
                    <!-- Value input -->
                    <div class="sf-rule-value-container">
                        <input type="text" class="sf-conditional-value" value="${rule.value || ''}" placeholder="Value">
                    </div>
                </div>
                
                <!-- Rule controls -->
                <div class="sf-rule-controls">
                    <button type="button" class="sf-add-rule" title="Add another condition">
                        <span class="dashicons dashicons-plus-alt"></span>
                    </button>
                    <button type="button" class="sf-remove-rule" title="Remove this condition">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            </div>
        `);
        
        // Set up operators based on source type
        setTimeout(function() {
            updateOperatorsForSourceType($rule, rule.source_type);
            
            // For user data, also update based on user data type
            if (rule.source_type === 'user') {
                updateOperatorsForUserDataType($rule, rule.field);
            }
            
            // Set the operator value after operators are updated
            setTimeout(function() {
                $rule.find('.sf-conditional-operator').val(rule.operator);
            }, 50);
        }, 100);
        
        // Set field value if it's a field source type
        if (rule.source_type === 'field' && rule.field) {
            setTimeout(function() {
                $rule.find('.sf-conditional-field').val(rule.field);
                updateValueInputForField($rule, rule.field);
            }, 150);
        }
        
        return $rule;
    }
    
    /**
     * Create a rule element from a suggestion
     */
    function createRuleFromSuggestion(rule, ruleId) {
        const $rule = $(`
            <div class="sf-condition-rule" data-rule-id="${ruleId}">
                <div class="sf-rule-field-container">
                    <select class="sf-rule-source-type">
                        <option value="field" ${rule.source_type === 'field' ? 'selected' : ''}>${sf_vars.text_form_field}</option>
                        <option value="user" ${rule.source_type === 'user' ? 'selected' : ''}>${sf_vars.text_user_data}</option>
                        <option value="date" ${rule.source_type === 'date' ? 'selected' : ''}>${sf_vars.text_date_time}</option>
                    </select>
                    
                    <!-- Field selector containers will be added here -->
                </div>
                
                <div class="sf-rule-operator-container">
                    <select class="sf-conditional-operator"></select>
                </div>
                
                <div class="sf-rule-value-container">
                    <input type="text" class="sf-conditional-value" value="${rule.value || ''}" placeholder="${sf_vars.text_value}">
                </div>
                
                <div class="sf-rule-controls">
                    <button type="button" class="sf-add-rule" title="${sf_vars.text_add_condition}">
                        <span class="dashicons dashicons-plus-alt"></span>
                    </button>
                    <button type="button" class="sf-remove-rule" title="${sf_vars.text_remove_condition}">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            </div>
        `);
        
        // Add appropriate field selectors based on source type
        const fieldSelectors = {
            field: `
                <div class="sf-rule-field-selector sf-field-source-field" ${rule.source_type === 'field' ? '' : 'style="display: none;"'}>
                    <select class="sf-conditional-field">
                        <option value="">${sf_vars.text_select_field}</option>
                        <!-- Will be populated by updateConditionalFieldOptions -->
                    </select>
                </div>
            `,
            user: `
                <div class="sf-rule-field-selector sf-field-source-user" ${rule.source_type === 'user' ? '' : 'style="display: none;"'}>
                    <select class="sf-conditional-user-data">
                        <option value="logged_in" ${rule.field === 'logged_in' ? 'selected' : ''}>${sf_vars.text_user_logged_in}</option>
                        <option value="user_role" ${rule.field === 'user_role' ? 'selected' : ''}>${sf_vars.text_user_role}</option>
                        <option value="user_meta" ${rule.field === 'user_meta' ? 'selected' : ''}>${sf_vars.text_user_meta}</option>
                    </select>
                    
                    <input type="text" class="sf-conditional-user-meta-key" value="${rule.meta_key || ''}" placeholder="${sf_vars.text_meta_key}" ${rule.field === 'user_meta' ? '' : 'style="display: none;"'}>
                </div>
            `,
            date: `
                <div class="sf-rule-field-selector sf-field-source-date" ${rule.source_type === 'date' ? '' : 'style="display: none;"'}>
                    <select class="sf-conditional-date-type">
                        <option value="current_date" ${rule.field === 'current_date' ? 'selected' : ''}>${sf_vars.text_current_date}</option>
                        <option value="current_time" ${rule.field === 'current_time' ? 'selected' : ''}>${sf_vars.text_current_time}</option>
                        <option value="current_day" ${rule.field === 'current_day' ? 'selected' : ''}>${sf_vars.text_current_day}</option>
                    </select>
                </div>
            `
        };
        
        // Add field selectors to the rule
        const $fieldContainer = $rule.find('.sf-rule-field-container');
        $fieldContainer.append(fieldSelectors.field);
        $fieldContainer.append(fieldSelectors.user);
        $fieldContainer.append(fieldSelectors.date);
        
        // Set up operators based on source type
        updateOperatorsForSourceType($rule, rule.source_type);
        
        // If it's a field source type, we need to wait until fields are populated
        // This will be handled later in updateConditionalFieldOptions
        
        // For user or date, we can set operators now
        if (rule.source_type === 'user') {
            updateOperatorsForUserDataType($rule, rule.field);
        }
        
        // Set operator value
        setTimeout(function() {
            $rule.find('.sf-conditional-operator').val(rule.operator);
        }, 100);
        
        return $rule;
    }
    
    /**
     * Get AI-suggested conditions for a field
     */
    function getSuggestedConditions(fieldId, fieldType) {
        // Determine which nonce to use - prioritize sf_vars.nonce as it matches backend expectation
        let nonce;
        if (typeof sf_vars !== 'undefined' && sf_vars.nonce) {
            nonce = sf_vars.nonce;
        } else if (typeof sfAdmin !== 'undefined' && sfAdmin.nonce) {
            nonce = sfAdmin.nonce;
        } else {
            return $.Deferred().reject('No nonce available');
        }
        
        return $.ajax({
            url: sf_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'sf_get_suggested_conditions',
                field_id: fieldId,
                field_type: fieldType,
                nonce: nonce
            },
            timeout: 10000 // 10 second timeout
        });
    }

    /**
     * Set value input type based on source type
     */
    function setValueInputForSourceType($rule, sourceType) {
        const $valueContainer = $rule.find('.sf-rule-value-container');
        const currentValue = $rule.find('.sf-conditional-value').val();
        if (sourceType === 'date') {
            // Only replace if not already datetime-local
            const $existingInput = $valueContainer.find('.sf-conditional-value');
            if ($existingInput.length > 0 && $existingInput.is('input[type="datetime-local"]')) {
                return;
            }
            const $dateInput = $('<input type="datetime-local" class="sf-conditional-value" placeholder="' + sf_vars.text_value + '">');
            if (currentValue) {
                $dateInput.val(currentValue);
            }
            $valueContainer.empty().append($dateInput);
        } else {
            resetValueInputToText($rule, currentValue);
        }
    }

    // Expose functions to SF.ConditionalLogic namespace
    window.SF.ConditionalLogic = {
        updateConditionalFieldOptions: updateConditionalFieldOptions,
        initAdvancedConditionalLogic: initAdvancedConditionalLogic,
        updateOperatorsForSourceType: updateOperatorsForSourceType,
        updateOperatorsForUserDataType: updateOperatorsForUserDataType,
        updateOperatorsForFieldType: updateOperatorsForFieldType,
        updateValueInputForUserDataType: updateValueInputForUserDataType,
        updateValueInputForField: updateValueInputForField,
        resetValueInputToText: resetValueInputToText,
        displayAiSuggestions: displayAiSuggestions,
        applySuggestion: applySuggestion,
        createRuleFromSuggestion: createRuleFromSuggestion,
        createAdvancedRuleElement: createAdvancedRuleElement,
        getSuggestedConditions: getSuggestedConditions,
        setValueInputForSourceType: setValueInputForSourceType
    };

})(jQuery);