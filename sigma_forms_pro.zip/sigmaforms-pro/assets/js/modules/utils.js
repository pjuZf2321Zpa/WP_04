/**
 * SigmaForms - Utility Functions
 */

(function ($) {
    'use strict';

    // Ensure SF namespace exists
    window.SF = window.SF || {};
    window.SF.Utils = {};

    /**
     * Escape HTML special characters
     * 
     * @param {string} str String to escape
     * @return {string} Escaped string
     */
    function escapeHTML(str) {
        if (!str) return '';

        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    /**
     * Get a default label for a field type
     * 
     * @param {string} fieldType The type of field
     * @return {string} Default label
     */
    function getDefaultLabelForType(fieldType) {
        const labels = {
            'text': 'Text Field',
            'email': 'Email Address',
            'url': 'Website URL',
            'phone': 'Phone Number',
            'phone_international': 'International Phone',
            'number': 'Number Field',
            'textarea': 'Text Area',
            'select': 'Select Field',
            'radio': 'Radio Options',
            'checkbox': 'Checkbox Options',
            'date': 'Date Field',
            'file': 'File Upload',
            'country': 'Country',
            'signature': 'Digital Signature',
            'section_heading': 'Section Heading',
            'rating': 'Rating',
            'range': 'Range Slider',
            'rich_text': 'Rich Text Editor',
            'page_break': 'Page Break'
        };

        return labels[fieldType] || 'New Field';
    }

    /**
     * Generate HTML options for field selection
     * 
     * @param {string} currentFieldId Current field ID to exclude
     * @param {string} selectedField Currently selected field
     * @return {string} HTML options
     */
    function getFieldOptionsHTML(currentFieldId, selectedField) {
        let html = '';

        $('.sf-field-item').each(function () {
            const fieldId = $(this).find('.sf-field-id').val();
            const fieldLabel = $(this).find('.sf-field-label').val();

            // Don't include the current field itself
            if (fieldId !== currentFieldId) {
                html += `<option value="${escapeHTML(fieldId)}" ${selectedField === fieldId ? 'selected' : ''}>${escapeHTML(fieldLabel)}</option>`;
            }
        });

        return html;
    }

    /**
     * Get field data from a field item
     * 
     * @param {jQuery} $fieldItem Field item element
     * @return {Object} Field data
     */
    function getFieldData($fieldItem) {
        const id = $fieldItem.find('.sf-field-id').val();
        const name = $fieldItem.find('.sf-field-name').val();
        const type = $fieldItem.find('.sf-field-type').val();
        const label = $fieldItem.find('.sf-field-label').val();
        const placeholder = $fieldItem.find('.sf-field-placeholder').val();
        const default_value = $fieldItem.find('.sf-field-default').val();
        const required = $fieldItem.find('.sf-field-required').is(':checked');
        const column_width = $fieldItem.find('.sf-field-column-width').val();
        const options = [];
        const conditional = {};

        // Get options for select/radio/checkbox
        if (['select', 'radio', 'checkbox'].includes(type)) {
            $fieldItem.find('.sf-field-option').each(function () {
                const value = $(this).find('.sf-option-value').val();
                const label = $(this).find('.sf-option-label').val();

                if (value && label) {
                    options.push({
                        value: value,
                        label: label
                    });
                }
            });
        }

        // Get conditional logic
        const $conditional = $fieldItem.find('.sf-field-has-conditional');

        if ($conditional.is(':checked')) {
            conditional.show = true;
            conditional.field = $fieldItem.find('.sf-conditional-field').val();
            conditional.operator = $fieldItem.find('.sf-conditional-operator').val();
            conditional.value = $fieldItem.find('.sf-conditional-value').val();
        }

        const fieldData = {
            id: id,
            name: name,
            type: type,
            label: label,
            placeholder: placeholder,
            default_value: default_value,
            required: required,
            column_width: column_width,
            options: options,
            conditional: conditional,
            help_text: $fieldItem.find('.sf-field-help-text').val() || ''
        };

        return fieldData;
    }

    /**
     * Initialize confirmation email toggle functionality
     */
    function initConfirmationEmailToggle() {
        $('#form-send-confirmation-email').on('change', function () {
            $('.sf-confirmation-email-settings').toggle($(this).is(':checked'));
        });
    }

    /**
     * Initialize email override toggle functionality
     */
    function initEmailOverrideToggle() {
        $('#form-override-email-settings').on('change', function () {
            $('.sf-custom-email-settings').toggle($(this).is(':checked'));
            // Sync with global settings
            syncFormSettings();
        });
    }

    /**
     * Initialize form settings synchronization
     */
    function initFormSettingsSync() {
        // Initialize global settings object if it doesn't exist
        if (!window.sfFormSettings) {
            window.sfFormSettings = {};
        }

        // Add event listeners for all form settings fields
        $('#form-override-email-settings').on('change', function () {
            syncFormSettings();
        });

        $('#form-to-email').on('input', function () {
            syncFormSettings();
        });

        $('#form-cc-email, #form-bcc-email').on('input', function () {
            syncFormSettings();
        });

        $('#form-email-subject').on('input', function () {
            syncFormSettings();
        });

        $('#form-email-message').on('input', function () {
            syncFormSettings();
        });

        $('#form-send-confirmation-email').on('change', function () {
            syncFormSettings();
        });

        $('#form-confirmation-subject').on('input', function () {
            syncFormSettings();
        });

        $('#form-confirmation-message').on('input', function () {
            syncFormSettings();
        });

        $('#form-enable-recaptcha').on('change', function () {
            syncFormSettings();
        });

        $('#form-store-submissions').on('change', function () {
            syncFormSettings();
        });

        $('#form-success-message').on('input', function () {
            syncFormSettings();
        });

        $('#form-theme').on('change', function () {
            syncFormSettings();
        });

        // Scheduling toggle
        $('#form-enable-scheduling').on('change', function () {
            if ($(this).is(':checked')) {
                $('.sf-scheduling-settings').slideDown(200);
            } else {
                $('.sf-scheduling-settings').slideUp(200);
            }
            syncFormSettings();
        });

        $('#form-schedule-start, #form-schedule-end').on('change', function () {
            syncFormSettings();
        });

        $('#form-schedule-message-before, #form-schedule-message-after').on('input', function () {
            syncFormSettings();
        });

        // Initial sync
        syncFormSettings();
    }

    /**
     * Sync form settings with global settings object
     */
    function syncFormSettings() {
        if (!window.sfFormSettings) {
            window.sfFormSettings = {};
        }

        // Update global settings with current form values
        window.sfFormSettings.override_email_settings = $('#form-override-email-settings').is(':checked');
        window.sfFormSettings.to_email = $('#form-to-email').val() || '';
        window.sfFormSettings.cc_email = $('#form-cc-email').val() || '';
        window.sfFormSettings.bcc_email = $('#form-bcc-email').val() || '';
        window.sfFormSettings.email_subject = $('#form-email-subject').val() || '';
        window.sfFormSettings.email_message = $('#form-email-message').val() || '';
        window.sfFormSettings.send_confirmation_email = $('#form-send-confirmation-email').is(':checked');
        window.sfFormSettings.confirmation_subject = $('#form-confirmation-subject').val() || '';
        window.sfFormSettings.confirmation_message = $('#form-confirmation-message').val() || '';
        window.sfFormSettings.captcha_type = $('#form-captcha-type').val() || '';
        window.sfFormSettings.store_submissions = $('#form-store-submissions').is(':checked');
        window.sfFormSettings.store_abandoned_forms = $('#form-store-abandoned-forms').is(':checked');
        window.sfFormSettings.success_message = $('#form-success-message').val() || 'Thank you for your submission!';
        // '' = use the global theme.
        window.sfFormSettings.form_theme = $('#form-theme').val() || '';

        // Sync scheduling settings
        window.sfFormSettings.enable_scheduling = $('#form-enable-scheduling').is(':checked');
        window.sfFormSettings.schedule_start = $('#form-schedule-start').val() || '';
        window.sfFormSettings.schedule_end = $('#form-schedule-end').val() || '';
        window.sfFormSettings.schedule_message_before = $('#form-schedule-message-before').val() || '';
        window.sfFormSettings.schedule_message_after = $('#form-schedule-message-after').val() || '';

        // Sync webhook settings
        window.sfFormSettings.webhook_google_sheets_use = $('#form-webhook-google-sheets-use').is(':checked');

        window.sfFormSettings.webhook_slack_use = $('#form-webhook-slack-use').is(':checked');
        window.sfFormSettings.webhook_discord_use = $('#form-webhook-discord-use').is(':checked');
        window.sfFormSettings.webhook_telegram_use = $('#form-webhook-telegram-use').is(':checked');
        window.sfFormSettings.webhook_custom_use = $('#form-webhook-custom-use').is(':checked');

        window.sfFormSettings.webhook_google_sheets_url = $('#form-webhook-google-sheets-url').val() || '';

        window.sfFormSettings.webhook_slack_url = $('#form-webhook-slack-url').val() || '';
        window.sfFormSettings.webhook_slack_channel = $('#form-webhook-slack-channel').val() || '';
        window.sfFormSettings.webhook_discord_url = $('#form-webhook-discord-url').val() || '';
        window.sfFormSettings.webhook_telegram_bot_token = $('#form-webhook-telegram-bot-token').val() || '';
        window.sfFormSettings.webhook_telegram_chat_id = $('#form-webhook-telegram-chat-id').val() || '';
        window.sfFormSettings.webhook_custom_url = $('#form-webhook-custom-url').val() || '';
        window.sfFormSettings.webhook_custom_method = $('#form-webhook-custom-method').val() || 'POST';

    }

    /**
     * Get all form data from the editor
     * 
     * @return {Object} Form data
     */
    function getFormData() {
        // Get form settings from multiple sources (modal inputs, DOM elements, global settings)
        const titleInput = $('#form-title-input').val();
        const titleHidden = $('#form-title').val();
        const titleSetting = window.sfFormSettings && window.sfFormSettings.title;
        const title = titleInput && titleInput.trim() !== '' ? titleInput
            : titleHidden && titleHidden.trim() !== '' ? titleHidden
                : titleSetting && titleSetting.trim() !== '' ? titleSetting
                    : '';

        const submitButtonText = $('#form-submit-button-text-input').val() ||
            $('#form-submit-button-text').val() ||
            (window.sfFormSettings && window.sfFormSettings.submit_button_text) ||
            'Submit';

        // Form settings - Read actual values from DOM elements
        const formSettings = {
            submit_button_text: submitButtonText,
            submit_button_width: window.sfFormSettings && window.sfFormSettings.submit_button_width ? window.sfFormSettings.submit_button_width : 'auto',
            submit_button_align: window.sfFormSettings && window.sfFormSettings.submit_button_align ? window.sfFormSettings.submit_button_align : 'left',
            success_message: $('#form-success-message').val() || 'Thank you for your submission!',
            validation_failed_message: $('#form-validation-failed-message').val() || '',

            // Email settings - Read from actual form fields
            override_email_settings: $('#form-override-email-settings').is(':checked'),
            email_subject: $('#form-email-subject').val() || '',
            email_message: $('#form-email-message').val() || '',
            to_email: $('#form-to-email').val() || '',
            cc_email: $('#form-cc-email').val() || '',
            bcc_email: $('#form-bcc-email').val() || '',
            send_confirmation_email: $('#form-send-confirmation-email').is(':checked'),
            confirmation_subject: $('#form-confirmation-subject').val() || '',
            confirmation_message: $('#form-confirmation-message').val() || '',

            // Security settings - Read from actual form fields
            captcha_type: $('#form-captcha-type').val() || '',

            // Store submissions setting
            store_submissions: $('#form-store-submissions').is(':checked'),

            // Store abandoned forms setting
            store_abandoned_forms: $('#form-store-abandoned-forms').is(':checked'),

            // Form theme setting
            form_theme: $('#form-theme').val() || '',

            // Scheduling settings
            enable_scheduling: $('#form-enable-scheduling').is(':checked'),
            schedule_start: $('#form-schedule-start').val() || '',
            schedule_end: $('#form-schedule-end').val() || '',
            schedule_message_before: $('#form-schedule-message-before').val() || '',
            schedule_message_after: $('#form-schedule-message-after').val() || '',

            // Custom styling settings (only collected if custom theme is selected)
            form_styling: {
                label_color: $('#form-label-color').val() || $('input[name="form_label_color"]').val() || '#333333',
                field_background: $('#form-field-background').val() || $('input[name="form_field_background"]').val() || '#ffffff',
                input_text_color: $('#form-input-text-color').val() || $('input[name="form_input_text_color"]').val() || '#333333',
                placeholder_color: $('#form-placeholder-color').val() || $('input[name="form_placeholder_color"]').val() || '#888888',
                field_border: $('#form-field-border').val() || $('input[name="form_field_border"]').val() || '#dcdcde',
                input_border_radius: $('input[name="form_input_border_radius"]').val() || $('#form-input-border-radius').val() || '4',
                form_padding: $('input[name="form_padding"]').val() || $('#form-padding').val() || '20',
                field_spacing: $('input[name="form_field_spacing"]').val() || $('#form-field-spacing').val() || '15',
                button_color: $('#form-button-color').val() || $('input[name="form_button_color"]').val() || '#2271b1',
                button_text_color: $('#form-button-text-color').val() || $('input[name="form_button_text_color"]').val() || '#ffffff',
                button_hover_bg_color: $('#form-button-hover-bg-color').val() || $('input[name="form_button_hover_bg_color"]').val() || '#1a5a96',
                button_hover_text_color: $('#form-button-hover-text-color').val() || $('input[name="form_button_hover_text_color"]').val() || '#ffffff',
                button_border_radius: $('input[name="form_button_border_radius"]').val() || $('#form-button-border-radius').val() || '4',
                font_family: $('#form-font-family').val() || $('select[name="form_font_family"]').val() || 'inherit',
                font_size: $('#form-font-size').val() || $('input[name="form_font_size"]').val() || '16'
            },
        };

        // Add webhook settings to formSettings object
        formSettings.webhook_google_sheets_use = $('#form-webhook-google-sheets-use').is(':checked');
        formSettings.webhook_slack_use = $('#form-webhook-slack-use').is(':checked');
        formSettings.webhook_discord_use = $('#form-webhook-discord-use').is(':checked');
        formSettings.webhook_telegram_use = $('#form-webhook-telegram-use').is(':checked');
        formSettings.webhook_custom_use = $('#form-webhook-custom-use').is(':checked');

        // Webhook URLs and settings
        formSettings.webhook_google_sheets_url = $('#form-webhook-google-sheets-url').val() || '';
        formSettings.webhook_slack_url = $('#form-webhook-slack-url').val() || '';
        formSettings.webhook_slack_channel = $('#form-webhook-slack-channel').val() || '';
        formSettings.webhook_discord_url = $('#form-webhook-discord-url').val() || '';
        formSettings.webhook_telegram_bot_token = $('#form-webhook-telegram-bot-token').val() || '';
        formSettings.webhook_telegram_chat_id = $('#form-webhook-telegram-chat-id').val() || '';
        formSettings.webhook_custom_url = $('#form-webhook-custom-url').val() || '';
        formSettings.webhook_custom_method = $('#form-webhook-custom-method').val() || 'POST';

        const formData = {
            title: title,
            fields: [],
            settings: formSettings
        };

        // Check if we're using the visual editor (sfFieldsData exists and has data)
        if (window.sfFieldsData && Array.isArray(window.sfFieldsData) && window.sfFieldsData.length > 0) {
            // Use the visual editor's field data directly
            formData.fields = window.sfFieldsData;
        } else {
            // Fall back to DOM-based field extraction (legacy editor)
            $('.sf-field-item').each(function () {
                const fieldData = getFieldData($(this));
                formData.fields.push(fieldData);
            });
        }

        return formData;
    }

    // Expose functions to SF.Utils namespace
    window.SF.Utils = {
        escapeHTML: escapeHTML,
        getDefaultLabelForType: getDefaultLabelForType,
        getFieldOptionsHTML: getFieldOptionsHTML,
        getFieldData: getFieldData,
        getFormData: getFormData,
        initConfirmationEmailToggle: initConfirmationEmailToggle,
        initEmailOverrideToggle: initEmailOverrideToggle,
        initFormSettingsSync: initFormSettingsSync,
        syncFormSettings: syncFormSettings
    };

})(jQuery); 