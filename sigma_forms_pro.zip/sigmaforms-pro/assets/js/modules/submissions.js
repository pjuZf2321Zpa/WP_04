/**
 * SigmaForms - Submissions Module
 */

(function($) {
    'use strict';

    // Ensure SF namespace exists
    window.SF = window.SF || {};
    window.SF.Submissions = {};

    /**
     * Initialize form submissions page
     */
    function initFormSubmissions() {
        const $submissionsPage = $('.sf-submissions-page');
        
        if ($submissionsPage.length === 0) {
            return;
        }
        
        // Handle form filter
        $('#submissions-filter-form').on('change', function() {
            this.submit();
        });
        
        // Handle bulk actions
        $('#doaction').on('click', function(e) {
            e.preventDefault();
            
            const action = $('#bulk-action-selector-top').val();
            
            if (action === '-1') {
                return;
            }
            
            const selectedIds = [];
            
            $('input[name="submission[]"]:checked').each(function() {
                selectedIds.push($(this).val());
            });
            
            if (selectedIds.length === 0) {
                window.SF.notify(window.SF.t('selectSubmission', 'Please select at least one submission.'));
                return;
            }
            
            if (action === 'delete') {
                window.SF.confirm(window.SF.t('confirmDeleteSubmissions', 'Are you sure you want to delete the selected submissions?'), { danger: true }).then(function (sfConfirmed) {
                    if (!sfConfirmed) {
                        return;
                    }
                    deleteSubmissions(selectedIds);
                });
            } else if (action === 'mark-read') {
                markSubmissionsAsRead(selectedIds);
            }
        });
        
        // Handle submission delete
        $('.sf-delete-submission').on('click', function(e) {
            e.preventDefault();
            
            const $sfTrigger = $(this);
            window.SF.confirm(window.SF.t('confirmDeleteSubmission', 'Are you sure you want to delete this submission?'), { danger: true }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                const submissionId = $sfTrigger.data('id');
                deleteSubmissions([submissionId]);
            });
        });
    }

    /**
     * Delete submissions
     * 
     * @param {Array} ids Submission IDs
     */
    function deleteSubmissions(ids) {
        $.ajax({
            url: sfAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_delete_submission',
                nonce: sfAdmin.nonce,
                submission_id: ids.join(',')
            },
            success: function(response) {
                if (response.success) {
                    window.location.reload();
                } else {
                    window.SF.notify(response.data.message || window.SF.t('errorDeletingSubmissions', 'Error deleting submissions.'));
                }
            },
            error: function() {
                window.SF.notify(window.SF.t('errorDeletingSubmissions', 'Error deleting submissions.'));
            }
        });
    }

    /**
     * Mark submissions as read
     * 
     * @param {Array} ids Submission IDs
     */
    function markSubmissionsAsRead(ids) {
        $.ajax({
            url: sfAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_mark_submissions_read',
                nonce: sfAdmin.nonce,
                submission_id: ids.join(',')
            },
            success: function(response) {
                if (response.success) {
                    window.location.reload();
                } else {
                    window.SF.notify(response.data.message || window.SF.t('errorUpdatingSubmissions', 'Error updating submissions.'));
                }
            },
            error: function() {
                window.SF.notify(window.SF.t('errorUpdatingSubmissions', 'Error updating submissions.'));
            }
        });
    }

    // Expose functions to SF.Submissions namespace
    window.SF.Submissions = {
        init: initFormSubmissions,
        deleteSubmissions: deleteSubmissions,
        markSubmissionsAsRead: markSubmissionsAsRead
    };

})(jQuery); 