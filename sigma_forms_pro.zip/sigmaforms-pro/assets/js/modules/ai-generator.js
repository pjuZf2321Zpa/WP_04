/**
 * SigmaForms - AI Generator Module
 */
// comment
(function($) {
    'use strict';

    // Ensure SF namespace exists
    window.SF = window.SF || {};
    window.SF.AIGenerator = {};

    /**
     * Initialize AI generator functionality
     */
    function initAIGenerator() {
        const $generator = $('.sf-ai-generator-wrapper');
        const $prebuiltTemplates = $('.sf-prebuilt-templates');
        const $aiInputSection = $generator.find('.sf-ai-input-section');
        const $aiExamplesSection = $generator.find('.sf-ai-examples-section');
        const $aiActions = $generator.find('.sf-ai-actions');
        const $fallbackMsg = $prebuiltTemplates.find('.sf-prebuilt-fallback-message');
        const $createManualBtn = $('#sf-create-manual-btn');
        
        if ($generator.length === 0) {
            return;
        }
        
        const $generateButton = $generator.find('.sf-ai-generate-button');
        const $promptTextarea = $generator.find('.sf-ai-prompt-textarea');
        const $resultMessage = $generator.find('.sf-ai-result-message');
        
        // Use example prompt - Remove any existing handlers to prevent duplicates
        $generator.find('.sf-ai-example-item').off('click').on('click', function() {
            const examplePrompt = $(this).data('prompt');
            $promptTextarea.val(examplePrompt);
            $promptTextarea.focus();
            
            // Add a nice focus effect
            $promptTextarea.addClass('highlighted');
            setTimeout(() => {
                $promptTextarea.removeClass('highlighted');
            }, 1000);
        });
        
        // Generate form from prompt - Remove any existing handlers to prevent duplicates
        $generateButton.off('click').on('click', function() {
            const prompt = $promptTextarea.val().trim();
            
            if (!prompt) {
                showMessage('Please describe the form you want to create.', 'error');
                $promptTextarea.focus();
                return;
            }
            
            generateFormFromPrompt(prompt);
        });
        
        // Show pre-built templates if API key is missing
        if ($generator.hasClass('sf-no-api-key')) {
            $aiInputSection.hide();
            $aiExamplesSection.hide();
            $prebuiltTemplates.show();
            if ($fallbackMsg.length) {
                $fallbackMsg.show();
            }
        }
        
        // Template selection handler
        $prebuiltTemplates.on('click', '.sf-select-template', function() {
            const template = $(this).closest('.sf-prebuilt-template-card').data('template');
            let formData = {};
            if (template === 'contact') {
                formData = {
                    title: 'Contact Form',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Name', placeholder: 'Enter your name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email', placeholder: 'Enter your email', required: true },
                        { id: 'message', name: 'message', default_value: '', type: 'textarea', label: 'Message',  placeholder: 'Enter your message', required: true }
                    ],
                    settings: { submit_button_text: 'Send Message', success_message: 'Thank you for contacting us!', submit_button_width: '100' }
                };
            } else if (template === 'job') {
                formData = {
                    title: 'Job Application',
                    fields: [
                        { id: 'fullname', name: 'fullname', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email', placeholder: 'Enter your email', required: true },
                        { id: 'experience', name: 'experience', default_value: '', type: 'number', label: 'Experience', placeholder: 'Enter your experience number of years', required: true },
                        { id: 'resume', name: 'resume', type: 'file', label: 'Resume', required: true, allowed_file_types: ['.pdf', '.doc', '.docx'] }
                    ],
                    settings: { submit_button_text: 'Apply Now', success_message: 'Your application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'survey') {
                formData = {
                    title: 'Survey',
                    fields: [
                        { id: 'satisfaction', name: 'satisfaction', default_value: '', type: 'radio', label: 'How satisfied are you?', options: [ { value: '1', label: '1' }, { value: '2', label: '2' }, { value: '3', label: '3' }, { value: '4', label: '4' }, { value: '5', label: '5' } ], required: true },
                        { id: 'feedback', name: 'feedback', default_value: '', type: 'textarea', label: 'Additional Comments',  placeholder: 'Enter your feedback', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Survey', success_message: 'Thank you for your feedback!', submit_button_width: '100' }
                };
            } else if (template === 'event') {
                formData = {
                    title: 'Event Registration',
                    fields: [
                        { id: 'attendee', name: 'attendee', default_value: '', type: 'text', label: 'Attendee Name', placeholder: 'Enter your attendee name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email', placeholder: 'Enter your email', required: true },
                        { id: 'ticket', name: 'ticket', default_value: '', type: 'select', label: 'Ticket Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select a ticket type', label: 'Select a ticket type'}, { value: 'standard', label: 'Standard' }, { value: 'vip', label: 'VIP' } ], required: true },
                        { id: 'diet', name: 'diet', default_value: '', type: 'text', label: 'Dietary Restrictions', placeholder: 'Enter your diet restriction', required: false }
                    ],
                    settings: { submit_button_text: 'Register', success_message: 'Thank you for registering!', submit_button_width: '100' }
                };
            } else if (template === 'product') {
                formData = {
                    title: 'Product Order Form',
                    fields: [
                        { id: 'product', name: 'product', default_value: '', type: 'text', label: 'Product Name', placeholder: 'Enter your product name', required: true },
                        { id: 'quantity', name: 'quantity', default_value: '', type: 'number', label: 'Quantity', placeholder: 'Enter your product quantity', required: true },
                        { id: 'shipping', name: 'shipping', default_value: '', type: 'textarea', label: 'Shipping Address', placeholder: 'Enter your shipping address', required: true }
                    ],
                    settings: { submit_button_text: 'Place Order', success_message: 'Your order has been placed!', submit_button_width: '100' }
                };
            } else if (template === 'appointment') {
                formData = {
                    title: 'Appointment Booking',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email', placeholder: 'Enter your email', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'service', name: 'service', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select a service', label: 'Select a service'}, { value: 'consultation', label: 'Consultation' }, { value: 'treatment', label: 'Treatment' }, { value: 'followup', label: 'Follow-up' } ], required: true },
                        { id: 'date', name: 'date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'time', name: 'time', default_value: '', type: 'time', label: 'Preferred Time', placeholder: 'Select your preferred time', required: true },
                        { id: 'notes', name: 'notes', default_value: '', type: 'textarea', label: 'Additional Notes', placeholder: 'Any special requirements or notes', required: false }
                    ],
                    settings: { submit_button_text: 'Book Appointment', success_message: 'Your appointment has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'membership') {
                formData = {
                    title: 'Membership Application',
                    fields: [
                        { id: 'fullname', name: 'fullname', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email', placeholder: 'Enter your email', required: true },
                        { id: 'membership_type', name: 'membership_type', default_value: '', type: 'select', label: 'Membership Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select membership type', label: 'Select membership type'}, { value: 'basic', label: 'Basic' }, { value: 'premium', label: 'Premium' }, { value: 'vip', label: 'VIP' } ], required: true },
                        { id: 'company', name: 'company', default_value: '', type: 'text', label: 'Company/Organization', placeholder: 'Enter your company name', required: false },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'address', name: 'address', default_value: '', type: 'textarea', label: 'Address', placeholder: 'Enter your address', required: true }
                    ],
                    settings: { submit_button_text: 'Apply for Membership', success_message: 'Your membership application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'newsletter') {
                formData = {
                    title: 'Newsletter Signup',
                    fields: [
                        { id: 'firstname', name: 'firstname', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'lastname', name: 'lastname', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'interests', name: 'interests', default_value: '', type: 'checkbox', label: 'Areas of Interest', options: [ { value: 'technology', label: 'Technology' }, { value: 'business', label: 'Business' }, { value: 'health', label: 'Health & Wellness' }, { value: 'lifestyle', label: 'Lifestyle' } ], required: false },
                        { id: 'frequency', name: 'frequency', default_value: '', type: 'radio', label: 'Newsletter Frequency', options: [ { value: 'weekly', label: 'Weekly' }, { value: 'biweekly', label: 'Bi-weekly' }, { value: 'monthly', label: 'Monthly' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Subscribe', success_message: 'Thank you for subscribing to our newsletter!', submit_button_width: '100' }
                };
            } else if (template === 'feedback') {
                formData = {
                    title: 'Customer Feedback',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Your Name', placeholder: 'Enter your name', required: false },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: false },
                        { id: 'service_rating', name: 'service_rating', default_value: '', type: 'radio', label: 'Service Rating', options: [ { value: '1', label: '1 - Poor' }, { value: '2', label: '2 - Fair' }, { value: '3', label: '3 - Good' }, { value: '4', label: '4 - Very Good' }, { value: '5', label: '5 - Excellent' } ], required: true },
                        { id: 'service_category', name: 'service_category', default_value: '', type: 'select', label: 'Service Category', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select category', label: 'Select category'}, { value: 'customer_service', label: 'Customer Service' }, { value: 'product_quality', label: 'Product Quality' }, { value: 'delivery', label: 'Delivery' }, { value: 'website', label: 'Website Experience' } ], required: true },
                        { id: 'comments', name: 'comments', default_value: '', type: 'textarea', label: 'Additional Comments', placeholder: 'Please share your experience and suggestions', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Feedback', success_message: 'Thank you for your feedback!', submit_button_width: '100' }
                };
            } else if (template === 'quote') {
                formData = {
                    title: 'Quote Request',
                    fields: [
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter contact person name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'project_description', name: 'project_description', default_value: '', type: 'textarea', label: 'Project Description', placeholder: 'Please describe your project requirements', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget range', label: 'Select budget range'}, { value: 'under_5k', label: 'Under $5,000' }, { value: '5k_10k', label: '$5,000 - $10,000' }, { value: '10k_25k', label: '$10,000 - $25,000' }, { value: 'over_25k', label: 'Over $25,000' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_3_months', label: '1-3 months' }, { value: '3_6_months', label: '3-6 months' }, { value: '6_months_plus', label: '6+ months' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Request Quote', success_message: 'Your quote request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'support') {
                formData = {
                    title: 'Support Ticket',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'subject', name: 'subject', default_value: '', type: 'text', label: 'Issue Subject', placeholder: 'Brief description of the issue', required: true },
                        { id: 'priority', name: 'priority', default_value: '', type: 'select', label: 'Priority Level', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select priority', label: 'Select priority'}, { value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }, { value: 'urgent', label: 'Urgent' } ], required: true },
                        { id: 'issue_type', name: 'issue_type', default_value: '', type: 'select', label: 'Issue Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select issue type', label: 'Select issue type'}, { value: 'technical', label: 'Technical Problem' }, { value: 'billing', label: 'Billing Issue' }, { value: 'feature_request', label: 'Feature Request' }, { value: 'general', label: 'General Inquiry' } ], required: true },
                        { id: 'description', name: 'description', default_value: '', type: 'textarea', label: 'Issue Description', placeholder: 'Please provide detailed description of the issue', required: true },
                        { id: 'attachments', name: 'attachments', type: 'file', label: 'Attachments', required: false, allowed_file_types: ['.pdf', '.doc', '.docx', '.jpg', '.jpeg', '.png', '.gif', '.txt'] }
                    ],
                    settings: { submit_button_text: 'Submit Ticket', success_message: 'Your support ticket has been created!', submit_button_width: '100' }
                };
            } else if (template === 'donation') {
                formData = {
                    title: 'Donation Form',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'donation_amount', name: 'donation_amount', default_value: '', type: 'select', label: 'Donation Amount', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select amount', label: 'Select amount'}, { value: '25', label: '$25' }, { value: '50', label: '$50' }, { value: '100', label: '$100' }, { value: '250', label: '$250' }, { value: '500', label: '$500' }, { value: 'custom', label: 'Custom Amount' } ], required: true },
                        { id: 'custom_amount', name: 'custom_amount', default_value: '', type: 'number', label: 'Custom Amount', placeholder: 'Enter custom amount', required: false },
                        { id: 'payment_method', name: 'payment_method', default_value: '', type: 'radio', label: 'Payment Method', options: [ { value: 'credit_card', label: 'Credit Card' }, { value: 'paypal', label: 'PayPal' }, { value: 'bank_transfer', label: 'Bank Transfer' } ], required: true },
                        { id: 'tax_receipt', name: 'tax_receipt', default_value: '', type: 'checkbox', label: 'Send Tax Receipt', options: [ { value: 'yes', label: 'Yes, please send me a tax receipt' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Donate Now', success_message: 'Thank you for your donation!', submit_button_width: '100' }
                };
            } else if (template === 'volunteer') {
                formData = {
                    title: 'Volunteer Registration',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'skills', name: 'skills', default_value: '', type: 'checkbox', label: 'Skills & Experience', options: [ { value: 'teaching', label: 'Teaching' }, { value: 'administration', label: 'Administration' }, { value: 'technical', label: 'Technical' }, { value: 'creative', label: 'Creative' }, { value: 'physical', label: 'Physical Labor' } ], required: false },
                        { id: 'availability', name: 'availability', default_value: '', type: 'select', label: 'Availability', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select availability', label: 'Select availability'}, { value: 'weekdays', label: 'Weekdays' }, { value: 'weekends', label: 'Weekends' }, { value: 'evenings', label: 'Evenings' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'areas_of_interest', name: 'areas_of_interest', default_value: '', type: 'textarea', label: 'Areas of Interest', placeholder: 'Describe what causes or activities interest you', required: false }
                    ],
                    settings: { submit_button_text: 'Register as Volunteer', success_message: 'Thank you for volunteering!', submit_button_width: '100' }
                };
            } else if (template === 'workshop') {
                formData = {
                    title: 'Workshop Registration',
                    fields: [
                        { id: 'full_name', name: 'full_name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'workshop_selection', name: 'workshop_selection', default_value: '', type: 'select', label: 'Workshop Selection', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select workshop', label: 'Select workshop'}, { value: 'beginner', label: 'Beginner Level' }, { value: 'intermediate', label: 'Intermediate Level' }, { value: 'advanced', label: 'Advanced Level' } ], required: true },
                        { id: 'skill_level', name: 'skill_level', default_value: '', type: 'radio', label: 'Current Skill Level', options: [ { value: 'beginner', label: 'Beginner' }, { value: 'intermediate', label: 'Intermediate' }, { value: 'advanced', label: 'Advanced' } ], required: true },
                        { id: 'experience', name: 'experience', default_value: '', type: 'textarea', label: 'Previous Experience', placeholder: 'Describe your relevant experience', required: false },
                        { id: 'dietary_restrictions', name: 'dietary_restrictions', default_value: '', type: 'text', label: 'Dietary Restrictions', placeholder: 'Any food allergies or restrictions', required: false }
                    ],
                    settings: { submit_button_text: 'Register for Workshop', success_message: 'Your workshop registration is confirmed!', submit_button_width: '100' }
                };
            } else if (template === 'consultation') {
                formData = {
                    title: 'Consultation Booking',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'business', label: 'Business Strategy' }, { value: 'marketing', label: 'Marketing' }, { value: 'financial', label: 'Financial Planning' }, { value: 'legal', label: 'Legal Advice' } ], required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (9 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (1 PM - 4 PM)' }, { value: 'evening', label: 'Evening (5 PM - 7 PM)' } ], required: true },
                        { id: 'consultation_notes', name: 'consultation_notes', default_value: '', type: 'textarea', label: 'Consultation Notes', placeholder: 'Brief description of what you need help with', required: true }
                    ],
                    settings: { submit_button_text: 'Book Consultation', success_message: 'Your consultation has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'testimonial') {
                formData = {
                    title: 'Testimonial Submission',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Your Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'company', name: 'company', default_value: '', type: 'text', label: 'Company/Organization', placeholder: 'Enter your company name (optional)', required: false },
                        { id: 'rating', name: 'rating', default_value: '', type: 'radio', label: 'Rating', options: [ { value: '1', label: '1 Star' }, { value: '2', label: '2 Stars' }, { value: '3', label: '3 Stars' }, { value: '4', label: '4 Stars' }, { value: '5', label: '5 Stars' } ], required: true },
                        { id: 'review_text', name: 'review_text', default_value: '', type: 'textarea', label: 'Your Review', placeholder: 'Please share your experience and feedback', required: true },
                        { id: 'permission_to_publish', name: 'permission_to_publish', default_value: '', type: 'checkbox', label: 'Permission to Publish', options: [ { value: 'yes', label: 'Yes, you may publish my testimonial' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Submit Testimonial', success_message: 'Thank you for your testimonial!', submit_button_width: '100' }
                };
            } else if (template === 'partnership') {
                formData = {
                    title: 'Partnership Inquiry',
                    fields: [
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'contact_person', name: 'contact_person', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter contact person name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'website', name: 'website', default_value: '', type: 'url', label: 'Website', placeholder: 'Enter your website URL', required: false },
                        { id: 'partnership_goals', name: 'partnership_goals', default_value: '', type: 'textarea', label: 'Partnership Goals', placeholder: 'Describe what you hope to achieve through this partnership', required: true },
                        { id: 'company_description', name: 'company_description', default_value: '', type: 'textarea', label: 'Company Description', placeholder: 'Brief description of your company and services', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Partnership Inquiry', success_message: 'Your partnership inquiry has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'wholesale') {
                formData = {
                    title: 'Wholesale Application',
                    fields: [
                        { id: 'business_name', name: 'business_name', default_value: '', type: 'text', label: 'Business Name', placeholder: 'Enter your business name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter contact person name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'business_license', name: 'business_license', type: 'file', label: 'Business License', required: true, allowed_file_types: ['.pdf', '.jpg', '.jpeg', '.png'] },
                        { id: 'tax_id', name: 'tax_id', default_value: '', type: 'text', label: 'Tax ID/EIN', placeholder: 'Enter your Tax ID or EIN', required: true },
                        { id: 'order_volume', name: 'order_volume', default_value: '', type: 'select', label: 'Expected Order Volume', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select volume', label: 'Select volume'}, { value: 'small', label: 'Small (Under $1,000/month)' }, { value: 'medium', label: 'Medium ($1,000 - $5,000/month)' }, { value: 'large', label: 'Large (Over $5,000/month)' } ], required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'retail', label: 'Retail Store' }, { value: 'online', label: 'Online Store' }, { value: 'distributor', label: 'Distributor' }, { value: 'other', label: 'Other' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Submit Application', success_message: 'Your wholesale application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'affiliate') {
                formData = {
                    title: 'Affiliate Program',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'website', name: 'website', default_value: '', type: 'url', label: 'Website URL', placeholder: 'Enter your website URL', required: true },
                        { id: 'traffic_stats', name: 'traffic_stats', default_value: '', type: 'select', label: 'Monthly Traffic', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select traffic', label: 'Select traffic'}, { value: 'under_1k', label: 'Under 1,000 visitors' }, { value: '1k_5k', label: '1,000 - 5,000 visitors' }, { value: '5k_10k', label: '5,000 - 10,000 visitors' }, { value: 'over_10k', label: 'Over 10,000 visitors' } ], required: true },
                        { id: 'marketing_channels', name: 'marketing_channels', default_value: '', type: 'checkbox', label: 'Marketing Channels', options: [ { value: 'social_media', label: 'Social Media' }, { value: 'email', label: 'Email Marketing' }, { value: 'content', label: 'Content Marketing' }, { value: 'seo', label: 'SEO' }, { value: 'paid_ads', label: 'Paid Advertising' } ], required: false },
                        { id: 'experience', name: 'experience', default_value: '', type: 'textarea', label: 'Affiliate Experience', placeholder: 'Describe your experience with affiliate marketing', required: false }
                    ],
                    settings: { submit_button_text: 'Apply for Affiliate Program', success_message: 'Your affiliate application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'beta') {
                formData = {
                    title: 'Beta Testing',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'device_type', name: 'device_type', default_value: '', type: 'select', label: 'Primary Device Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select device', label: 'Select device'}, { value: 'desktop', label: 'Desktop/Laptop' }, { value: 'mobile', label: 'Mobile Phone' }, { value: 'tablet', label: 'Tablet' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'operating_system', name: 'operating_system', default_value: '', type: 'select', label: 'Operating System', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select OS', label: 'Select OS'}, { value: 'windows', label: 'Windows' }, { value: 'mac', label: 'macOS' }, { value: 'linux', label: 'Linux' }, { value: 'ios', label: 'iOS' }, { value: 'android', label: 'Android' } ], required: true },
                        { id: 'use_cases', name: 'use_cases', default_value: '', type: 'textarea', label: 'How Will You Use This Product?', placeholder: 'Describe your intended use cases', required: true },
                        { id: 'feedback_preferences', name: 'feedback_preferences', default_value: '', type: 'checkbox', label: 'Feedback Preferences', options: [ { value: 'email', label: 'Email Updates' }, { value: 'surveys', label: 'Surveys' }, { value: 'interviews', label: 'User Interviews' }, { value: 'bug_reports', label: 'Bug Reports' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Join Beta Testing', success_message: 'Welcome to our beta testing program!', submit_button_width: '100' }
                };
            } else if (template === 'referral') {
                formData = {
                    title: 'Referral Program',
                    fields: [
                        { id: 'referrer_name', name: 'referrer_name', default_value: '', type: 'text', label: 'Your Name', placeholder: 'Enter your full name', required: true },
                        { id: 'referrer_email', name: 'referrer_email', default_value: '', type: 'email', label: 'Your Email', placeholder: 'Enter your email address', required: true },
                        { id: 'referred_name', name: 'referred_name', default_value: '', type: 'text', label: 'Referred Person Name', placeholder: 'Enter the name of person you are referring', required: true },
                        { id: 'referred_email', name: 'referred_email', default_value: '', type: 'email', label: 'Referred Person Email', placeholder: 'Enter their email address', required: true },
                        { id: 'referred_phone', name: 'referred_phone', default_value: '', type: 'number', label: 'Referred Person Phone', placeholder: 'Enter their phone number', required: false },
                        { id: 'relationship', name: 'relationship', default_value: '', type: 'select', label: 'Your Relationship', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select relationship', label: 'Select relationship'}, { value: 'friend', label: 'Friend' }, { value: 'family', label: 'Family' }, { value: 'colleague', label: 'Colleague' }, { value: 'client', label: 'Client' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'why_refer', name: 'why_refer', default_value: '', type: 'textarea', label: 'Why Are You Referring Them?', placeholder: 'Tell us why you think they would benefit from our services', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Referral', success_message: 'Thank you for your referral!', submit_button_width: '100' }
                };
            } else if (template === 'waitlist') {
                formData = {
                    title: 'Waitlist Signup',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'product_interest', name: 'product_interest', default_value: '', type: 'select', label: 'Product Interest', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select product', label: 'Select product'}, { value: 'software', label: 'Software Solution' }, { value: 'hardware', label: 'Hardware Device' }, { value: 'service', label: 'Service Package' }, { value: 'course', label: 'Online Course' } ], required: true },
                        { id: 'launch_preferences', name: 'launch_preferences', default_value: '', type: 'checkbox', label: 'Launch Preferences', options: [ { value: 'early_access', label: 'Early Access' }, { value: 'beta_testing', label: 'Beta Testing' }, { value: 'discount', label: 'Launch Discount' }, { value: 'updates', label: 'Product Updates' } ], required: false },
                        { id: 'use_case', name: 'use_case', default_value: '', type: 'textarea', label: 'How Will You Use This Product?', placeholder: 'Briefly describe your intended use case', required: false }
                    ],
                    settings: { submit_button_text: 'Join Waitlist', success_message: 'You have been added to our waitlist!', submit_button_width: '100' }
                };
            } else if (template === 'contest') {
                formData = {
                    title: 'Contest Entry',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Age', placeholder: 'Enter your age', required: true },
                        { id: 'entry_details', name: 'entry_details', default_value: '', type: 'textarea', label: 'Entry Details', placeholder: 'Describe your contest entry or answer the question', required: true },
                        { id: 'age_verification', name: 'age_verification', default_value: '', type: 'checkbox', label: 'Age Verification', options: [ { value: 'yes', label: 'I confirm I am 18 years or older' } ], required: true },
                        { id: 'terms_acceptance', name: 'terms_acceptance', default_value: '', type: 'checkbox', label: 'Terms Acceptance', options: [ { value: 'yes', label: 'I accept the contest terms and conditions' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Submit Entry', success_message: 'Your contest entry has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'webinar') {
                formData = {
                    title: 'Webinar Registration',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'company', name: 'company', default_value: '', type: 'text', label: 'Company/Organization', placeholder: 'Enter your company name (optional)', required: false },
                        { id: 'job_title', name: 'job_title', default_value: '', type: 'text', label: 'Job Title', placeholder: 'Enter your job title (optional)', required: false },
                        { id: 'webinar_topic', name: 'webinar_topic', default_value: '', type: 'select', label: 'Webinar Topic', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select topic', label: 'Select topic'}, { value: 'marketing', label: 'Digital Marketing' }, { value: 'sales', label: 'Sales Strategy' }, { value: 'technology', label: 'Technology Trends' }, { value: 'leadership', label: 'Leadership Skills' } ], required: true },
                        { id: 'experience_level', name: 'experience_level', default_value: '', type: 'radio', label: 'Experience Level', options: [ { value: 'beginner', label: 'Beginner' }, { value: 'intermediate', label: 'Intermediate' }, { value: 'advanced', label: 'Advanced' } ], required: true },
                        { id: 'questions', name: 'questions', default_value: '', type: 'textarea', label: 'Questions for Presenter', placeholder: 'Any specific questions you would like answered (optional)', required: false }
                    ],
                    settings: { submit_button_text: 'Register for Webinar', success_message: 'Your webinar registration is confirmed!', submit_button_width: '100' }
                };
            } else if (template === 'demo') {
                formData = {
                    title: 'Demo Request',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'company_size', name: 'company_size', default_value: '', type: 'select', label: 'Company Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select size', label: 'Select size'}, { value: '1_10', label: '1-10 employees' }, { value: '11_50', label: '11-50 employees' }, { value: '51_200', label: '51-200 employees' }, { value: '201_500', label: '201-500 employees' }, { value: 'over_500', label: 'Over 500 employees' } ], required: true },
                        { id: 'use_case', name: 'use_case', default_value: '', type: 'textarea', label: 'Use Case', placeholder: 'Describe how you plan to use our product/service', required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Demo Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (9 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (1 PM - 4 PM)' }, { value: 'evening', label: 'Evening (5 PM - 7 PM)' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Request Demo', success_message: 'Your demo request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'trial') {
                formData = {
                    title: 'Free Trial Signup',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'company_size', name: 'company_size', default_value: '', type: 'select', label: 'Company Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select size', label: 'Select size'}, { value: '1_10', label: '1-10 employees' }, { value: '11_50', label: '11-50 employees' }, { value: '51_200', label: '51-200 employees' }, { value: '201_500', label: '201-500 employees' }, { value: 'over_500', label: 'Over 500 employees' } ], required: true },
                        { id: 'use_case', name: 'use_case', default_value: '', type: 'textarea', label: 'How Will You Use This Product?', placeholder: 'Describe your intended use case', required: true },
                        { id: 'credit_card', name: 'credit_card', default_value: '', type: 'checkbox', label: 'Credit Card (Optional)', options: [ { value: 'yes', label: 'I understand a credit card is required for the trial' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Start Free Trial', success_message: 'Your free trial has been activated!', submit_button_width: '100' }
                };
            } else if (template === 'custom') {
                formData = {
                    title: 'Custom Project',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company', name: 'company', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: false },
                        { id: 'project_requirements', name: 'project_requirements', default_value: '', type: 'textarea', label: 'Project Requirements', placeholder: 'Please describe your project in detail', required: true },
                        { id: 'budget', name: 'budget', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_5k', label: 'Under $5,000' }, { value: '5k_15k', label: '$5,000 - $15,000' }, { value: '15k_50k', label: '$15,000 - $50,000' }, { value: 'over_50k', label: 'Over $50,000' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_3_months', label: '1-3 months' }, { value: '3_6_months', label: '3-6 months' }, { value: '6_months_plus', label: '6+ months' } ], required: true },
                        { id: 'additional_info', name: 'additional_info', default_value: '', type: 'textarea', label: 'Additional Information', placeholder: 'Any other details or questions', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Project Request', success_message: 'Your project request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'invoice') {
                formData = {
                    title: 'Invoice Request',
                    fields: [
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter contact person name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'billing_address', name: 'billing_address', default_value: '', type: 'textarea', label: 'Billing Address', placeholder: 'Enter your complete billing address', required: true },
                        { id: 'po_number', name: 'po_number', default_value: '', type: 'text', label: 'Purchase Order Number', placeholder: 'Enter PO number if applicable', required: false },
                        { id: 'services_description', name: 'services_description', default_value: '', type: 'textarea', label: 'Services Description', placeholder: 'Describe the services or products provided', required: true },
                        { id: 'amount', name: 'amount', default_value: '', type: 'number', label: 'Invoice Amount', placeholder: 'Enter the total amount', required: true },
                        { id: 'payment_terms', name: 'payment_terms', default_value: '', type: 'select', label: 'Payment Terms', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select terms', label: 'Select terms'}, { value: 'net_30', label: 'Net 30' }, { value: 'net_15', label: 'Net 15' }, { value: 'due_on_receipt', label: 'Due on Receipt' }, { value: 'custom', label: 'Custom Terms' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Request Invoice', success_message: 'Your invoice request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'refund') {
                formData = {
                    title: 'Refund Request',
                    fields: [
                        { id: 'order_number', name: 'order_number', default_value: '', type: 'text', label: 'Order Number', placeholder: 'Enter your order number', required: true },
                        { id: 'customer_name', name: 'customer_name', default_value: '', type: 'text', label: 'Customer Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'purchase_date', name: 'purchase_date', default_value: '', type: 'date', label: 'Purchase Date', placeholder: 'Select the purchase date', required: true },
                        { id: 'refund_reason', name: 'refund_reason', default_value: '', type: 'select', label: 'Reason for Refund', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select reason', label: 'Select reason'}, { value: 'defective', label: 'Defective Product' }, { value: 'wrong_item', label: 'Wrong Item Received' }, { value: 'not_as_described', label: 'Not as Described' }, { value: 'changed_mind', label: 'Changed Mind' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'description', name: 'description', default_value: '', type: 'textarea', label: 'Detailed Description', placeholder: 'Please describe the issue in detail', required: true },
                        { id: 'refund_method', name: 'refund_method', default_value: '', type: 'radio', label: 'Preferred Refund Method', options: [ { value: 'original_payment', label: 'Original Payment Method' }, { value: 'store_credit', label: 'Store Credit' }, { value: 'check', label: 'Check' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Submit Refund Request', success_message: 'Your refund request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'warranty') {
                formData = {
                    title: 'Warranty Claim',
                    fields: [
                        { id: 'customer_name', name: 'customer_name', default_value: '', type: 'text', label: 'Customer Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'product_name', name: 'product_name', default_value: '', type: 'text', label: 'Product Name', placeholder: 'Enter the product name', required: true },
                        { id: 'serial_number', name: 'serial_number', default_value: '', type: 'text', label: 'Serial Number', placeholder: 'Enter the product serial number', required: true },
                        { id: 'purchase_date', name: 'purchase_date', default_value: '', type: 'date', label: 'Purchase Date', placeholder: 'Select the purchase date', required: true },
                        { id: 'warranty_type', name: 'warranty_type', default_value: '', type: 'select', label: 'Warranty Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select warranty', label: 'Select warranty'}, { value: 'manufacturer', label: 'Manufacturer Warranty' }, { value: 'extended', label: 'Extended Warranty' }, { value: 'store', label: 'Store Warranty' } ], required: true },
                        { id: 'issue_description', name: 'issue_description', default_value: '', type: 'textarea', label: 'Issue Description', placeholder: 'Describe the problem you are experiencing', required: true },
                        { id: 'proof_of_purchase', name: 'proof_of_purchase', type: 'file', label: 'Proof of Purchase', required: true, allowed_file_types: ['.pdf', '.jpg', '.jpeg', '.png'] }
                    ],
                    settings: { submit_button_text: 'Submit Warranty Claim', success_message: 'Your warranty claim has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'course_enrollment') {
                formData = {
                    title: 'Course Enrollment',
                    fields: [
                        { id: 'student_name', name: 'student_name', default_value: '', type: 'text', label: 'Student Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'course_selection', name: 'course_selection', default_value: '', type: 'select', label: 'Course Selection', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select course', label: 'Select course'}, { value: 'beginner', label: 'Beginner Level' }, { value: 'intermediate', label: 'Intermediate Level' }, { value: 'advanced', label: 'Advanced Level' }, { value: 'certification', label: 'Certification Course' } ], required: true },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'Preferred Start Date', placeholder: 'Select your preferred start date', required: true },
                        { id: 'learning_goals', name: 'learning_goals', default_value: '', type: 'textarea', label: 'Learning Goals', placeholder: 'What do you hope to achieve from this course?', required: false },
                        { id: 'previous_experience', name: 'previous_experience', default_value: '', type: 'select', label: 'Previous Experience', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select experience', label: 'Select experience'}, { value: 'none', label: 'No Experience' }, { value: 'beginner', label: 'Beginner' }, { value: 'intermediate', label: 'Intermediate' }, { value: 'advanced', label: 'Advanced' } ], required: true },
                        { id: 'payment_plan', name: 'payment_plan', default_value: '', type: 'radio', label: 'Payment Plan', options: [ { value: 'full_payment', label: 'Full Payment' }, { value: 'monthly', label: 'Monthly Installments' }, { value: 'quarterly', label: 'Quarterly Installments' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Enroll Now', success_message: 'Your course enrollment has been confirmed!', submit_button_width: '100' }
                };
            } else if (template === 'mentorship') {
                formData = {
                    title: 'Mentorship Application',
                    fields: [
                        { id: 'mentee_name', name: 'mentee_name', default_value: '', type: 'text', label: 'Your Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'current_role', name: 'current_role', default_value: '', type: 'text', label: 'Current Role/Position', placeholder: 'Enter your current job title', required: true },
                        { id: 'company', name: 'company', default_value: '', type: 'text', label: 'Company/Organization', placeholder: 'Enter your company name', required: true },
                        { id: 'years_experience', name: 'years_experience', default_value: '', type: 'select', label: 'Years of Experience', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select experience', label: 'Select experience'}, { value: '0_2', label: '0-2 years' }, { value: '3_5', label: '3-5 years' }, { value: '6_10', label: '6-10 years' }, { value: 'over_10', label: 'Over 10 years' } ], required: true },
                        { id: 'mentorship_goals', name: 'mentorship_goals', default_value: '', type: 'textarea', label: 'Mentorship Goals', placeholder: 'What specific areas do you want to develop?', required: true },
                        { id: 'preferred_mentor', name: 'preferred_mentor', default_value: '', type: 'select', label: 'Preferred Mentor Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'industry_expert', label: 'Industry Expert' }, { value: 'career_coach', label: 'Career Coach' }, { value: 'business_leader', label: 'Business Leader' }, { value: 'technical_specialist', label: 'Technical Specialist' } ], required: true },
                        { id: 'availability', name: 'availability', default_value: '', type: 'checkbox', label: 'Preferred Meeting Times', options: [ { value: 'weekday_morning', label: 'Weekday Mornings' }, { value: 'weekday_afternoon', label: 'Weekday Afternoons' }, { value: 'weekday_evening', label: 'Weekday Evenings' }, { value: 'weekends', label: 'Weekends' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Apply for Mentorship', success_message: 'Your mentorship application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'networking') {
                formData = {
                    title: 'Networking Event Registration',
                    fields: [
                        { id: 'first_name', name: 'first_name', default_value: '', type: 'text', label: 'First Name', placeholder: 'Enter your first name', required: true },
                        { id: 'last_name', name: 'last_name', default_value: '', type: 'text', label: 'Last Name', placeholder: 'Enter your last name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company', name: 'company', default_value: '', type: 'text', label: 'Company/Organization', placeholder: 'Enter your company name', required: true },
                        { id: 'job_title', name: 'job_title', default_value: '', type: 'text', label: 'Job Title', placeholder: 'Enter your job title', required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select industry', label: 'Select industry'}, { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'education', label: 'Education' }, { value: 'retail', label: 'Retail' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'networking_goals', name: 'networking_goals', default_value: '', type: 'checkbox', label: 'Networking Goals', options: [ { value: 'job_opportunities', label: 'Job Opportunities' }, { value: 'business_partnerships', label: 'Business Partnerships' }, { value: 'industry_connections', label: 'Industry Connections' }, { value: 'knowledge_sharing', label: 'Knowledge Sharing' }, { value: 'mentorship', label: 'Mentorship' } ], required: false },
                        { id: 'dietary_restrictions', name: 'dietary_restrictions', default_value: '', type: 'text', label: 'Dietary Restrictions', placeholder: 'Any food allergies or restrictions', required: false }
                    ],
                    settings: { submit_button_text: 'Register for Event', success_message: 'Your networking event registration is confirmed!', submit_button_width: '100' }
                };
            } else if (template === 'health_appointment') {
                formData = {
                    title: 'Health Appointment Booking',
                    fields: [
                        { id: 'patient_name', name: 'patient_name', default_value: '', type: 'text', label: 'Patient Name', placeholder: 'Enter patient full name', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select date of birth', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'appointment_type', name: 'appointment_type', default_value: '', type: 'select', label: 'Appointment Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'consultation', label: 'Consultation' }, { value: 'follow_up', label: 'Follow-up' }, { value: 'emergency', label: 'Emergency' }, { value: 'routine_checkup', label: 'Routine Checkup' }, { value: 'specialist', label: 'Specialist Visit' } ], required: true },
                        { id: 'preferred_date', name: 'preferred_date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (9 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (1 PM - 4 PM)' }, { value: 'evening', label: 'Evening (5 PM - 7 PM)' } ], required: true },
                        { id: 'symptoms', name: 'symptoms', default_value: '', type: 'textarea', label: 'Symptoms/Reason for Visit', placeholder: 'Describe your symptoms or reason for the appointment', required: false },
                        { id: 'insurance_info', name: 'insurance_info', default_value: '', type: 'text', label: 'Insurance Provider', placeholder: 'Enter your insurance provider (if applicable)', required: false }
                    ],
                    settings: { submit_button_text: 'Book Appointment', success_message: 'Your health appointment has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'legal_consultation') {
                formData = {
                    title: 'Legal Consultation Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'legal_issue', name: 'legal_issue', default_value: '', type: 'select', label: 'Legal Issue Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select issue', label: 'Select issue'}, { value: 'family_law', label: 'Family Law' }, { value: 'criminal_law', label: 'Criminal Law' }, { value: 'civil_law', label: 'Civil Law' }, { value: 'business_law', label: 'Business Law' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'employment', label: 'Employment Law' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'urgency', name: 'urgency', default_value: '', type: 'radio', label: 'Urgency Level', options: [ { value: 'low', label: 'Low - Can wait a few weeks' }, { value: 'medium', label: 'Medium - Need within 1-2 weeks' }, { value: 'high', label: 'High - Need within days' }, { value: 'urgent', label: 'Urgent - Need immediately' } ], required: true },
                        { id: 'case_description', name: 'case_description', default_value: '', type: 'textarea', label: 'Case Description', placeholder: 'Please describe your legal situation in detail', required: true },
                        { id: 'previous_legal_action', name: 'previous_legal_action', default_value: '', type: 'checkbox', label: 'Previous Legal Action', options: [ { value: 'yes', label: 'I have taken previous legal action' }, { value: 'no', label: 'This is my first time seeking legal help' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_1k', label: 'Under $1,000' }, { value: '1k_5k', label: '$1,000 - $5,000' }, { value: '5k_10k', label: '$5,000 - $10,000' }, { value: 'over_10k', label: 'Over $10,000' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Request Consultation', success_message: 'Your legal consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'community_service') {
                formData = {
                    title: 'Community Service Request',
                    fields: [
                        { id: 'requester_name', name: 'requester_name', default_value: '', type: 'text', label: 'Requester Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'organization', name: 'organization', default_value: '', type: 'text', label: 'Organization/Group', placeholder: 'Enter your organization name (if applicable)', required: false },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'cleanup', label: 'Community Cleanup' }, { value: 'fundraising', label: 'Fundraising Event' }, { value: 'volunteer_coordination', label: 'Volunteer Coordination' }, { value: 'event_planning', label: 'Event Planning' }, { value: 'awareness_campaign', label: 'Awareness Campaign' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'location', name: 'location', default_value: '', type: 'text', label: 'Service Location', placeholder: 'Enter the location where service is needed', required: true },
                        { id: 'date_needed', name: 'date_needed', default_value: '', type: 'date', label: 'Date Needed', placeholder: 'Select when the service is needed', required: true },
                        { id: 'description', name: 'description', default_value: '', type: 'textarea', label: 'Service Description', placeholder: 'Describe the community service needed in detail', required: true },
                        { id: 'volunteers_needed', name: 'volunteers_needed', default_value: '', type: 'number', label: 'Number of Volunteers Needed', placeholder: 'Enter the number of volunteers needed', required: false },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any special skills or equipment needed', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Service Request', success_message: 'Your community service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'real_estate') {
                formData = {
                    title: 'Real Estate Inquiry',
                    fields: [
                        { id: 'buyer_name', name: 'buyer_name', default_value: '', type: 'text', label: 'Buyer Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'property_type', name: 'property_type', default_value: '', type: 'select', label: 'Property Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'house', label: 'House' }, { value: 'condo', label: 'Condo' }, { value: 'townhouse', label: 'Townhouse' }, { value: 'land', label: 'Land' }, { value: 'commercial', label: 'Commercial' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_200k', label: 'Under $200,000' }, { value: '200k_400k', label: '$200,000 - $400,000' }, { value: '400k_600k', label: '$400,000 - $600,000' }, { value: '600k_800k', label: '$600,000 - $800,000' }, { value: 'over_800k', label: 'Over $800,000' } ], required: true },
                        { id: 'location_preferences', name: 'location_preferences', default_value: '', type: 'textarea', label: 'Location Preferences', placeholder: 'Describe your preferred neighborhoods or areas', required: true },
                        { id: 'bedrooms', name: 'bedrooms', default_value: '', type: 'select', label: 'Number of Bedrooms', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select bedrooms', label: 'Select bedrooms'}, { value: '1', label: '1' }, { value: '2', label: '2' }, { value: '3', label: '3' }, { value: '4', label: '4' }, { value: '5_plus', label: '5+' } ], required: true },
                        { id: 'bathrooms', name: 'bathrooms', default_value: '', type: 'select', label: 'Number of Bathrooms', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select bathrooms', label: 'Select bathrooms'}, { value: '1', label: '1' }, { value: '2', label: '2' }, { value: '3', label: '3' }, { value: '4_plus', label: '4+' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Timeline to Buy', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_3_months', label: '1-3 months' }, { value: '3_6_months', label: '3-6 months' }, { value: '6_months_plus', label: '6+ months' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Submit Inquiry', success_message: 'Your real estate inquiry has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'travel_booking') {
                formData = {
                    title: 'Travel Booking Request',
                    fields: [
                        { id: 'traveler_name', name: 'traveler_name', default_value: '', type: 'text', label: 'Traveler Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'destination', name: 'destination', default_value: '', type: 'text', label: 'Destination', placeholder: 'Enter your desired destination', required: true },
                        { id: 'departure_date', name: 'departure_date', default_value: '', type: 'date', label: 'Departure Date', placeholder: 'Select departure date', required: true },
                        { id: 'return_date', name: 'return_date', default_value: '', type: 'date', label: 'Return Date', placeholder: 'Select return date', required: true },
                        { id: 'travelers', name: 'travelers', default_value: '', type: 'number', label: 'Number of Travelers', placeholder: 'Enter number of travelers', required: true },
                        { id: 'accommodation_type', name: 'accommodation_type', default_value: '', type: 'select', label: 'Accommodation Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'hotel', label: 'Hotel' }, { value: 'resort', label: 'Resort' }, { value: 'vacation_rental', label: 'Vacation Rental' }, { value: 'hostel', label: 'Hostel' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'budget', label: 'Budget' }, { value: 'moderate', label: 'Moderate' }, { value: 'luxury', label: 'Luxury' } ], required: true },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any special requirements or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Travel Request', success_message: 'Your travel booking request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'restaurant_reservation') {
                formData = {
                    title: 'Restaurant Reservation',
                    fields: [
                        { id: 'guest_name', name: 'guest_name', default_value: '', type: 'text', label: 'Guest Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'reservation_date', name: 'reservation_date', default_value: '', type: 'date', label: 'Reservation Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'reservation_time', name: 'reservation_time', default_value: '', type: 'select', label: 'Reservation Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'lunch', label: 'Lunch (11 AM - 2 PM)' }, { value: 'dinner', label: 'Dinner (5 PM - 9 PM)' }, { value: 'late_dinner', label: 'Late Dinner (9 PM - 11 PM)' } ], required: true },
                        { id: 'party_size', name: 'party_size', default_value: '', type: 'select', label: 'Party Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select size', label: 'Select size'}, { value: '1_2', label: '1-2 people' }, { value: '3_4', label: '3-4 people' }, { value: '5_6', label: '5-6 people' }, { value: '7_8', label: '7-8 people' }, { value: '9_plus', label: '9+ people' } ], required: true },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any special requests or dietary restrictions', required: false },
                        { id: 'occasion', name: 'occasion', default_value: '', type: 'select', label: 'Special Occasion', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select occasion', label: 'Select occasion'}, { value: 'none', label: 'No special occasion' }, { value: 'birthday', label: 'Birthday' }, { value: 'anniversary', label: 'Anniversary' }, { value: 'business', label: 'Business Meeting' }, { value: 'other', label: 'Other' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Make Reservation', success_message: 'Your restaurant reservation has been confirmed!', submit_button_width: '100' }
                };
            } else if (template === 'pet_sitting') {
                formData = {
                    title: 'Pet Sitting Service Request',
                    fields: [
                        { id: 'owner_name', name: 'owner_name', default_value: '', type: 'text', label: 'Owner Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'pet_name', name: 'pet_name', default_value: '', type: 'text', label: 'Pet Name', placeholder: 'Enter your pet\'s name', required: true },
                        { id: 'pet_type', name: 'pet_type', default_value: '', type: 'select', label: 'Pet Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'dog', label: 'Dog' }, { value: 'cat', label: 'Cat' }, { value: 'bird', label: 'Bird' }, { value: 'fish', label: 'Fish' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'service_dates', name: 'service_dates', default_value: '', type: 'text', label: 'Service Dates', placeholder: 'Enter the dates you need pet sitting', required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'drop_in', label: 'Drop-in Visits' }, { value: 'overnight', label: 'Overnight Care' }, { value: 'dog_walking', label: 'Dog Walking' }, { value: 'pet_taxi', label: 'Pet Taxi' } ], required: true },
                        { id: 'special_needs', name: 'special_needs', default_value: '', type: 'textarea', label: 'Special Needs', placeholder: 'Any special care instructions or medical needs', required: false },
                        { id: 'address', name: 'address', default_value: '', type: 'textarea', label: 'Service Address', placeholder: 'Enter the address where pet sitting is needed', required: true }
                    ],
                    settings: { submit_button_text: 'Request Pet Sitting', success_message: 'Your pet sitting request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'house_cleaning') {
                formData = {
                    title: 'House Cleaning Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'regular_cleaning', label: 'Regular Cleaning' }, { value: 'deep_cleaning', label: 'Deep Cleaning' }, { value: 'move_in_out', label: 'Move In/Out Cleaning' }, { value: 'post_construction', label: 'Post Construction' }, { value: 'one_time', label: 'One Time Cleaning' } ], required: true },
                        { id: 'home_size', name: 'home_size', default_value: '', type: 'select', label: 'Home Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select size', label: 'Select size'}, { value: 'studio', label: 'Studio (Under 500 sq ft)' }, { value: '1_bedroom', label: '1 Bedroom (500-800 sq ft)' }, { value: '2_bedroom', label: '2 Bedroom (800-1200 sq ft)' }, { value: '3_bedroom', label: '3 Bedroom (1200-1800 sq ft)' }, { value: '4_plus_bedroom', label: '4+ Bedroom (1800+ sq ft)' } ], required: true },
                        { id: 'bedrooms', name: 'bedrooms', default_value: '', type: 'number', label: 'Number of Bedrooms', placeholder: 'Enter number of bedrooms', required: true },
                        { id: 'bathrooms', name: 'bathrooms', default_value: '', type: 'number', label: 'Number of Bathrooms', placeholder: 'Enter number of bathrooms', required: true },
                        { id: 'preferred_date', name: 'preferred_date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (8 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (12 PM - 4 PM)' }, { value: 'evening', label: 'Evening (4 PM - 8 PM)' } ], required: true },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any specific areas or special cleaning needs', required: false },
                        { id: 'address', name: 'address', default_value: '', type: 'textarea', label: 'Service Address', placeholder: 'Enter your complete address', required: true }
                    ],
                    settings: { submit_button_text: 'Request Cleaning Service', success_message: 'Your house cleaning request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'landscaping') {
                formData = {
                    title: 'Landscaping Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'lawn_maintenance', label: 'Lawn Maintenance' }, { value: 'landscape_design', label: 'Landscape Design' }, { value: 'tree_trimming', label: 'Tree Trimming' }, { value: 'irrigation', label: 'Irrigation System' }, { value: 'hardscaping', label: 'Hardscaping' }, { value: 'seasonal_cleanup', label: 'Seasonal Cleanup' } ], required: true },
                        { id: 'property_size', name: 'property_size', default_value: '', type: 'select', label: 'Property Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select size', label: 'Select size'}, { value: 'small', label: 'Small (Under 0.25 acres)' }, { value: 'medium', label: 'Medium (0.25 - 0.5 acres)' }, { value: 'large', label: 'Large (0.5 - 1 acre)' }, { value: 'very_large', label: 'Very Large (1+ acres)' } ], required: true },
                        { id: 'current_landscape', name: 'current_landscape', default_value: '', type: 'select', label: 'Current Landscape', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select landscape', label: 'Select landscape'}, { value: 'new_construction', label: 'New Construction' }, { value: 'existing_landscape', label: 'Existing Landscape' }, { value: 'overgrown', label: 'Overgrown/Needs Work' }, { value: 'minimal', label: 'Minimal/Empty' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_2_weeks', label: '1-2 weeks' }, { value: '1_month', label: '1 month' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_1k', label: 'Under $1,000' }, { value: '1k_3k', label: '$1,000 - $3,000' }, { value: '3k_5k', label: '$3,000 - $5,000' }, { value: '5k_10k', label: '$5,000 - $10,000' }, { value: 'over_10k', label: 'Over $10,000' } ], required: true },
                        { id: 'project_description', name: 'project_description', default_value: '', type: 'textarea', label: 'Project Description', placeholder: 'Describe what you want to achieve with your landscape', required: true },
                        { id: 'address', name: 'address', default_value: '', type: 'textarea', label: 'Property Address', placeholder: 'Enter your complete property address', required: true }
                    ],
                    settings: { submit_button_text: 'Request Landscaping Service', success_message: 'Your landscaping service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'catering') {
                formData = {
                    title: 'Catering Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'event_type', name: 'event_type', default_value: '', type: 'select', label: 'Event Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select event', label: 'Select event'}, { value: 'wedding', label: 'Wedding' }, { value: 'corporate', label: 'Corporate Event' }, { value: 'birthday', label: 'Birthday Party' }, { value: 'anniversary', label: 'Anniversary' }, { value: 'holiday', label: 'Holiday Party' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'guest_count', name: 'guest_count', default_value: '', type: 'number', label: 'Number of Guests', placeholder: 'Enter expected number of guests', required: true },
                        { id: 'event_date', name: 'event_date', default_value: '', type: 'date', label: 'Event Date', placeholder: 'Select your event date', required: true },
                        { id: 'event_time', name: 'event_time', default_value: '', type: 'select', label: 'Event Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'breakfast', label: 'Breakfast (7 AM - 10 AM)' }, { value: 'lunch', label: 'Lunch (11 AM - 2 PM)' }, { value: 'dinner', label: 'Dinner (5 PM - 9 PM)' }, { value: 'late_night', label: 'Late Night (9 PM - 12 AM)' } ], required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'full_service', label: 'Full Service (Setup, Serve, Cleanup)' }, { value: 'delivery_only', label: 'Delivery Only' }, { value: 'drop_off', label: 'Drop Off & Pickup' }, { value: 'staffed', label: 'Staffed Service' } ], required: true },
                        { id: 'dietary_restrictions', name: 'dietary_restrictions', default_value: '', type: 'checkbox', label: 'Dietary Restrictions', options: [ { value: 'vegetarian', label: 'Vegetarian' }, { value: 'vegan', label: 'Vegan' }, { value: 'gluten_free', label: 'Gluten Free' }, { value: 'dairy_free', label: 'Dairy Free' }, { value: 'nut_free', label: 'Nut Free' }, { value: 'none', label: 'No Restrictions' } ], required: false },
                        { id: 'menu_preferences', name: 'menu_preferences', default_value: '', type: 'textarea', label: 'Menu Preferences', placeholder: 'Describe your preferred cuisine or specific dishes', required: false },
                        { id: 'event_location', name: 'event_location', default_value: '', type: 'textarea', label: 'Event Location', placeholder: 'Enter your event location and address', required: true }
                    ],
                    settings: { submit_button_text: 'Request Catering Quote', success_message: 'Your catering request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'photography') {
                formData = {
                    title: 'Photography Session Booking',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'session_type', name: 'session_type', default_value: '', type: 'select', label: 'Session Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'portrait', label: 'Portrait' }, { value: 'family', label: 'Family' }, { value: 'wedding', label: 'Wedding' }, { value: 'engagement', label: 'Engagement' }, { value: 'maternity', label: 'Maternity' }, { value: 'newborn', label: 'Newborn' }, { value: 'senior', label: 'Senior Photos' }, { value: 'event', label: 'Event' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'session_date', name: 'session_date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'session_time', name: 'session_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'sunrise', label: 'Sunrise (6 AM - 8 AM)' }, { value: 'morning', label: 'Morning (9 AM - 11 AM)' }, { value: 'afternoon', label: 'Afternoon (2 PM - 4 PM)' }, { value: 'sunset', label: 'Sunset (5 PM - 7 PM)' }, { value: 'evening', label: 'Evening (7 PM - 9 PM)' } ], required: true },
                        { id: 'location_preference', name: 'location_preference', default_value: '', type: 'select', label: 'Location Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select location', label: 'Select location'}, { value: 'studio', label: 'Studio' }, { value: 'outdoor', label: 'Outdoor' }, { value: 'client_home', label: 'Client Home' }, { value: 'specific_location', label: 'Specific Location' } ], required: true },
                        { id: 'number_of_people', name: 'number_of_people', default_value: '', type: 'number', label: 'Number of People', placeholder: 'Enter number of people in the session', required: true },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any specific poses, props, or special requirements', required: false },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_100', label: 'Under $100' }, { value: '100_200', label: '$100 - $200' }, { value: '200_300', label: '$200 - $300' }, { value: '300_500', label: '$300 - $500' }, { value: 'over_500', label: 'Over $500' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Book Photography Session', success_message: 'Your photography session has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'music_lessons') {
                formData = {
                    title: 'Music Lessons Registration',
                    fields: [
                        { id: 'student_name', name: 'student_name', default_value: '', type: 'text', label: 'Student Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Age', placeholder: 'Enter your age', required: true },
                        { id: 'instrument', name: 'instrument', default_value: '', type: 'select', label: 'Instrument', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select instrument', label: 'Select instrument'}, { value: 'piano', label: 'Piano' }, { value: 'guitar', label: 'Guitar' }, { value: 'violin', label: 'Violin' }, { value: 'drums', label: 'Drums' }, { value: 'voice', label: 'Voice' }, { value: 'bass', label: 'Bass' }, { value: 'saxophone', label: 'Saxophone' }, { value: 'flute', label: 'Flute' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'skill_level', name: 'skill_level', default_value: '', type: 'select', label: 'Skill Level', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select level', label: 'Select level'}, { value: 'beginner', label: 'Beginner (No experience)' }, { value: 'elementary', label: 'Elementary (Some experience)' }, { value: 'intermediate', label: 'Intermediate' }, { value: 'advanced', label: 'Advanced' } ], required: true },
                        { id: 'lesson_type', name: 'lesson_type', default_value: '', type: 'select', label: 'Lesson Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'private', label: 'Private Lessons' }, { value: 'group', label: 'Group Lessons' }, { value: 'online', label: 'Online Lessons' }, { value: 'in_person', label: 'In-Person Lessons' } ], required: true },
                        { id: 'preferred_schedule', name: 'preferred_schedule', default_value: '', type: 'checkbox', label: 'Preferred Schedule', options: [ { value: 'weekday_morning', label: 'Weekday Mornings' }, { value: 'weekday_afternoon', label: 'Weekday Afternoons' }, { value: 'weekday_evening', label: 'Weekday Evenings' }, { value: 'weekends', label: 'Weekends' } ], required: false },
                        { id: 'goals', name: 'goals', default_value: '', type: 'textarea', label: 'Learning Goals', placeholder: 'What do you want to achieve with music lessons?', required: false },
                        { id: 'previous_experience', name: 'previous_experience', default_value: '', type: 'textarea', label: 'Previous Experience', placeholder: 'Describe any previous musical experience', required: false }
                    ],
                    settings: { submit_button_text: 'Register for Music Lessons', success_message: 'Your music lessons registration has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'fitness_training') {
                formData = {
                    title: 'Fitness Training Consultation',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Age', placeholder: 'Enter your age', required: true },
                        { id: 'current_weight', name: 'current_weight', default_value: '', type: 'number', label: 'Current Weight (lbs)', placeholder: 'Enter your current weight', required: true },
                        { id: 'height', name: 'height', default_value: '', type: 'number', label: 'Height (inches)', placeholder: 'Enter your height in inches', required: true },
                        { id: 'fitness_goals', name: 'fitness_goals', default_value: '', type: 'checkbox', label: 'Fitness Goals', options: [ { value: 'weight_loss', label: 'Weight Loss' }, { value: 'muscle_gain', label: 'Muscle Gain' }, { value: 'endurance', label: 'Improve Endurance' }, { value: 'flexibility', label: 'Increase Flexibility' }, { value: 'strength', label: 'Build Strength' }, { value: 'general_fitness', label: 'General Fitness' } ], required: true },
                        { id: 'experience_level', name: 'experience_level', default_value: '', type: 'select', label: 'Experience Level', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select level', label: 'Select level'}, { value: 'beginner', label: 'Beginner (No experience)' }, { value: 'intermediate', label: 'Intermediate (Some experience)' }, { value: 'advanced', label: 'Advanced (Regular exercise)' } ], required: true },
                        { id: 'preferred_schedule', name: 'preferred_schedule', default_value: '', type: 'checkbox', label: 'Preferred Schedule', options: [ { value: 'early_morning', label: 'Early Morning (5 AM - 8 AM)' }, { value: 'morning', label: 'Morning (8 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (12 PM - 5 PM)' }, { value: 'evening', label: 'Evening (5 PM - 9 PM)' } ], required: false },
                        { id: 'health_concerns', name: 'health_concerns', default_value: '', type: 'textarea', label: 'Health Concerns', placeholder: 'Any injuries, medical conditions, or limitations', required: false },
                        { id: 'training_preference', name: 'training_preference', default_value: '', type: 'select', label: 'Training Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select preference', label: 'Select preference'}, { value: 'one_on_one', label: 'One-on-One Training' }, { value: 'small_group', label: 'Small Group Training' }, { value: 'online', label: 'Online Training' }, { value: 'home_visits', label: 'Home Visits' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Request Fitness Consultation', success_message: 'Your fitness training consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'massage_therapy') {
                formData = {
                    title: 'Massage Therapy Appointment',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'massage_type', name: 'massage_type', default_value: '', type: 'select', label: 'Massage Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'swedish', label: 'Swedish' }, { value: 'deep_tissue', label: 'Deep Tissue' }, { value: 'hot_stone', label: 'Hot Stone' }, { value: 'sports', label: 'Sports Massage' }, { value: 'prenatal', label: 'Prenatal' }, { value: 'couples', label: 'Couples Massage' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'session_length', name: 'session_length', default_value: '', type: 'select', label: 'Session Length', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select length', label: 'Select length'}, { value: '30_min', label: '30 Minutes' }, { value: '60_min', label: '60 Minutes' }, { value: '90_min', label: '90 Minutes' }, { value: '120_min', label: '120 Minutes' } ], required: true },
                        { id: 'preferred_date', name: 'preferred_date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (9 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (12 PM - 5 PM)' }, { value: 'evening', label: 'Evening (5 PM - 8 PM)' } ], required: true },
                        { id: 'health_concerns', name: 'health_concerns', default_value: '', type: 'textarea', label: 'Health Concerns', placeholder: 'Any medical conditions, injuries, or areas of concern', required: false },
                        { id: 'pressure_preference', name: 'pressure_preference', default_value: '', type: 'radio', label: 'Pressure Preference', options: [ { value: 'light', label: 'Light' }, { value: 'medium', label: 'Medium' }, { value: 'firm', label: 'Firm' }, { value: 'very_firm', label: 'Very Firm' } ], required: true },
                        { id: 'focus_areas', name: 'focus_areas', default_value: '', type: 'checkbox', label: 'Focus Areas', options: [ { value: 'neck_shoulders', label: 'Neck & Shoulders' }, { value: 'back', label: 'Back' }, { value: 'legs', label: 'Legs' }, { value: 'arms', label: 'Arms' }, { value: 'feet', label: 'Feet' }, { value: 'full_body', label: 'Full Body' } ], required: false },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any specific requests or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Book Massage Appointment', success_message: 'Your massage therapy appointment has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'dental_appointment') {
                formData = {
                    title: 'Dental Appointment Booking',
                    fields: [
                        { id: 'patient_name', name: 'patient_name', default_value: '', type: 'text', label: 'Patient Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'select', label: 'Service Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select service', label: 'Select service'}, { value: 'cleaning', label: 'Cleaning & Checkup' }, { value: 'filling', label: 'Filling' }, { value: 'extraction', label: 'Extraction' }, { value: 'root_canal', label: 'Root Canal' }, { value: 'crown', label: 'Crown' }, { value: 'whitening', label: 'Teeth Whitening' }, { value: 'consultation', label: 'Consultation' }, { value: 'emergency', label: 'Emergency' } ], required: true },
                        { id: 'preferred_date', name: 'preferred_date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (9 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (1 PM - 4 PM)' }, { value: 'evening', label: 'Evening (5 PM - 7 PM)' } ], required: true },
                        { id: 'symptoms', name: 'symptoms', default_value: '', type: 'textarea', label: 'Symptoms/Reason for Visit', placeholder: 'Describe any symptoms or reason for the appointment', required: false },
                        { id: 'insurance_provider', name: 'insurance_provider', default_value: '', type: 'text', label: 'Insurance Provider', placeholder: 'Enter your insurance provider (if applicable)', required: false },
                        { id: 'insurance_id', name: 'insurance_id', default_value: '', type: 'text', label: 'Insurance ID Number', placeholder: 'Enter your insurance ID number (if applicable)', required: false },
                        { id: 'is_new_patient', name: 'is_new_patient', default_value: '', type: 'radio', label: 'New Patient?', options: [ { value: 'yes', label: 'Yes, I am a new patient' }, { value: 'no', label: 'No, I am an existing patient' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Book Dental Appointment', success_message: 'Your dental appointment has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'therapy_session') {
                formData = {
                    title: 'Therapy Session Booking',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'therapy_type', name: 'therapy_type', default_value: '', type: 'select', label: 'Therapy Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'individual', label: 'Individual Therapy' }, { value: 'couples', label: 'Couples Therapy' }, { value: 'family', label: 'Family Therapy' }, { value: 'group', label: 'Group Therapy' }, { value: 'online', label: 'Online Therapy' } ], required: true },
                        { id: 'therapist_preference', name: 'therapist_preference', default_value: '', type: 'select', label: 'Therapist Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select preference', label: 'Select preference'}, { value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }, { value: 'no_preference', label: 'No Preference' } ], required: true },
                        { id: 'session_type', name: 'session_type', default_value: '', type: 'select', label: 'Session Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select session', label: 'Select session'}, { value: 'initial', label: 'Initial Consultation' }, { value: 'regular', label: 'Regular Session' }, { value: 'emergency', label: 'Emergency Session' } ], required: true },
                        { id: 'preferred_date', name: 'preferred_date', default_value: '', type: 'date', label: 'Preferred Date', placeholder: 'Select your preferred date', required: true },
                        { id: 'preferred_time', name: 'preferred_time', default_value: '', type: 'select', label: 'Preferred Time', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select time', label: 'Select time'}, { value: 'morning', label: 'Morning (9 AM - 12 PM)' }, { value: 'afternoon', label: 'Afternoon (1 PM - 4 PM)' }, { value: 'evening', label: 'Evening (5 PM - 8 PM)' } ], required: true },
                        { id: 'concerns', name: 'concerns', default_value: '', type: 'textarea', label: 'Primary Concerns', placeholder: 'Briefly describe what you would like to work on', required: true },
                        { id: 'previous_therapy', name: 'previous_therapy', default_value: '', type: 'radio', label: 'Previous Therapy Experience', options: [ { value: 'yes', label: 'Yes, I have had therapy before' }, { value: 'no', label: 'No, this is my first time' } ], required: true },
                        { id: 'insurance_provider', name: 'insurance_provider', default_value: '', type: 'text', label: 'Insurance Provider', placeholder: 'Enter your insurance provider (if applicable)', required: false }
                    ],
                    settings: { submit_button_text: 'Book Therapy Session', success_message: 'Your therapy session has been booked!', submit_button_width: '100' }
                };
            } else if (template === 'financial_planning') {
                formData = {
                    title: 'Financial Planning Consultation',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Age', placeholder: 'Enter your age', required: true },
                        { id: 'annual_income', name: 'annual_income', default_value: '', type: 'select', label: 'Annual Income', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select income', label: 'Select income'}, { value: 'under_50k', label: 'Under $50,000' }, { value: '50k_75k', label: '$50,000 - $75,000' }, { value: '75k_100k', label: '$75,000 - $100,000' }, { value: '100k_150k', label: '$100,000 - $150,000' }, { value: 'over_150k', label: 'Over $150,000' } ], required: true },
                        { id: 'financial_goals', name: 'financial_goals', default_value: '', type: 'checkbox', label: 'Financial Goals', options: [ { value: 'retirement', label: 'Retirement Planning' }, { value: 'debt_reduction', label: 'Debt Reduction' }, { value: 'investment', label: 'Investment Planning' }, { value: 'tax_planning', label: 'Tax Planning' }, { value: 'estate_planning', label: 'Estate Planning' }, { value: 'college_funding', label: 'College Funding' }, { value: 'emergency_fund', label: 'Emergency Fund' } ], required: true },
                        { id: 'current_situation', name: 'current_situation', default_value: '', type: 'select', label: 'Current Financial Situation', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select situation', label: 'Select situation'}, { value: 'just_starting', label: 'Just Starting Out' }, { value: 'building_wealth', label: 'Building Wealth' }, { value: 'established', label: 'Established' }, { value: 'near_retirement', label: 'Near Retirement' }, { value: 'retired', label: 'Retired' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Planning Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'short_term', label: 'Short Term (1-3 years)' }, { value: 'medium_term', label: 'Medium Term (3-10 years)' }, { value: 'long_term', label: 'Long Term (10+ years)' } ], required: true },
                        { id: 'risk_tolerance', name: 'risk_tolerance', default_value: '', type: 'radio', label: 'Risk Tolerance', options: [ { value: 'conservative', label: 'Conservative' }, { value: 'moderate', label: 'Moderate' }, { value: 'aggressive', label: 'Aggressive' } ], required: true },
                        { id: 'specific_concerns', name: 'specific_concerns', default_value: '', type: 'textarea', label: 'Specific Financial Concerns', placeholder: 'Describe any specific financial challenges or questions', required: false }
                    ],
                    settings: { submit_button_text: 'Request Financial Consultation', success_message: 'Your financial planning consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'tax_preparation') {
                formData = {
                    title: 'Tax Preparation Service',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'tax_year', name: 'tax_year', default_value: '', type: 'select', label: 'Tax Year', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select year', label: 'Select year'}, { value: '2024', label: '2024' }, { value: '2023', label: '2023' }, { value: '2022', label: '2022' }, { value: 'previous', label: 'Previous Years' } ], required: true },
                        { id: 'filing_status', name: 'filing_status', default_value: '', type: 'select', label: 'Filing Status', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select status', label: 'Select status'}, { value: 'single', label: 'Single' }, { value: 'married_filing_jointly', label: 'Married Filing Jointly' }, { value: 'married_filing_separately', label: 'Married Filing Separately' }, { value: 'head_of_household', label: 'Head of Household' }, { value: 'qualifying_widow', label: 'Qualifying Widow(er)' } ], required: true },
                        { id: 'income_sources', name: 'income_sources', default_value: '', type: 'checkbox', label: 'Income Sources', options: [ { value: 'w2_employment', label: 'W-2 Employment' }, { value: 'self_employment', label: 'Self-Employment' }, { value: 'investment_income', label: 'Investment Income' }, { value: 'rental_income', label: 'Rental Income' }, { value: 'retirement_income', label: 'Retirement Income' }, { value: 'other', label: 'Other Income' } ], required: true },
                        { id: 'deductions', name: 'deductions', default_value: '', type: 'checkbox', label: 'Potential Deductions', options: [ { value: 'mortgage_interest', label: 'Mortgage Interest' }, { value: 'property_taxes', label: 'Property Taxes' }, { value: 'charitable_contributions', label: 'Charitable Contributions' }, { value: 'medical_expenses', label: 'Medical Expenses' }, { value: 'business_expenses', label: 'Business Expenses' }, { value: 'student_loan_interest', label: 'Student Loan Interest' } ], required: false },
                        { id: 'complexity_level', name: 'complexity_level', default_value: '', type: 'select', label: 'Tax Complexity', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select complexity', label: 'Select complexity'}, { value: 'simple', label: 'Simple (W-2 only)' }, { value: 'moderate', label: 'Moderate (Some deductions)' }, { value: 'complex', label: 'Complex (Business, investments)' }, { value: 'very_complex', label: 'Very Complex (Multiple businesses, international)' } ], required: true },
                        { id: 'previous_tax_issues', name: 'previous_tax_issues', default_value: '', type: 'textarea', label: 'Previous Tax Issues', placeholder: 'Any previous tax problems or audits', required: false },
                        { id: 'documents_available', name: 'documents_available', default_value: '', type: 'checkbox', label: 'Documents Available', options: [ { value: 'w2_forms', label: 'W-2 Forms' }, { value: '1099_forms', label: '1099 Forms' }, { value: 'receipts', label: 'Receipts & Records' }, { value: 'previous_returns', label: 'Previous Tax Returns' }, { value: 'none_yet', label: 'None Yet' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Request Tax Preparation', success_message: 'Your tax preparation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'insurance_quote') {
                formData = {
                    title: 'Insurance Quote Request',
                    fields: [
                        { id: 'applicant_name', name: 'applicant_name', default_value: '', type: 'text', label: 'Applicant Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'insurance_type', name: 'insurance_type', default_value: '', type: 'select', label: 'Insurance Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'auto', label: 'Auto Insurance' }, { value: 'home', label: 'Home Insurance' }, { value: 'life', label: 'Life Insurance' }, { value: 'health', label: 'Health Insurance' }, { value: 'business', label: 'Business Insurance' }, { value: 'umbrella', label: 'Umbrella Policy' } ], required: true },
                        { id: 'coverage_needs', name: 'coverage_needs', default_value: '', type: 'textarea', label: 'Coverage Needs', placeholder: 'Describe what you need coverage for', required: true },
                        { id: 'current_insurance', name: 'current_insurance', default_value: '', type: 'radio', label: 'Current Insurance', options: [ { value: 'yes', label: 'Yes, I have current insurance' }, { value: 'no', label: 'No, I need new insurance' } ], required: true },
                        { id: 'current_provider', name: 'current_provider', default_value: '', type: 'text', label: 'Current Provider', placeholder: 'Enter your current insurance provider (if applicable)', required: false },
                        { id: 'coverage_amount', name: 'coverage_amount', default_value: '', type: 'select', label: 'Desired Coverage Amount', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select amount', label: 'Select amount'}, { value: 'basic', label: 'Basic Coverage' }, { value: 'standard', label: 'Standard Coverage' }, { value: 'comprehensive', label: 'Comprehensive Coverage' }, { value: 'maximum', label: 'Maximum Coverage' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Monthly Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_100', label: 'Under $100' }, { value: '100_200', label: '$100 - $200' }, { value: '200_300', label: '$200 - $300' }, { value: '300_500', label: '$300 - $500' }, { value: 'over_500', label: 'Over $500' } ], required: true },
                        { id: 'additional_info', name: 'additional_info', default_value: '', type: 'textarea', label: 'Additional Information', placeholder: 'Any other details that might affect your quote', required: false }
                    ],
                    settings: { submit_button_text: 'Request Insurance Quote', success_message: 'Your insurance quote request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'loan_application') {
                formData = {
                    title: 'Loan Application',
                    fields: [
                        { id: 'applicant_name', name: 'applicant_name', default_value: '', type: 'text', label: 'Applicant Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'ssn', name: 'ssn', default_value: '', type: 'text', label: 'Social Security Number', placeholder: 'Enter your SSN (XXX-XX-XXXX)', required: true },
                        { id: 'loan_type', name: 'loan_type', default_value: '', type: 'select', label: 'Loan Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'personal', label: 'Personal Loan' }, { value: 'auto', label: 'Auto Loan' }, { value: 'home', label: 'Home Loan' }, { value: 'business', label: 'Business Loan' }, { value: 'student', label: 'Student Loan' }, { value: 'debt_consolidation', label: 'Debt Consolidation' } ], required: true },
                        { id: 'loan_amount', name: 'loan_amount', default_value: '', type: 'number', label: 'Loan Amount Requested', placeholder: 'Enter the amount you need', required: true },
                        { id: 'loan_purpose', name: 'loan_purpose', default_value: '', type: 'textarea', label: 'Loan Purpose', placeholder: 'Explain what you need the loan for', required: true },
                        { id: 'employment_status', name: 'employment_status', default_value: '', type: 'select', label: 'Employment Status', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select status', label: 'Select status'}, { value: 'employed', label: 'Employed' }, { value: 'self_employed', label: 'Self-Employed' }, { value: 'unemployed', label: 'Unemployed' }, { value: 'retired', label: 'Retired' }, { value: 'student', label: 'Student' } ], required: true },
                        { id: 'employer_name', name: 'employer_name', default_value: '', type: 'text', label: 'Employer Name', placeholder: 'Enter your employer name', required: false },
                        { id: 'monthly_income', name: 'monthly_income', default_value: '', type: 'number', label: 'Monthly Income', placeholder: 'Enter your monthly income', required: true },
                        { id: 'credit_score', name: 'credit_score', default_value: '', type: 'select', label: 'Credit Score Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select score', label: 'Select score'}, { value: 'excellent', label: 'Excellent (750-850)' }, { value: 'good', label: 'Good (700-749)' }, { value: 'fair', label: 'Fair (650-699)' }, { value: 'poor', label: 'Poor (300-649)' }, { value: 'unknown', label: 'I don\'t know' } ], required: true },
                        { id: 'existing_debts', name: 'existing_debts', default_value: '', type: 'number', label: 'Monthly Debt Payments', placeholder: 'Enter your monthly debt payments', required: true },
                        { id: 'collateral', name: 'collateral', default_value: '', type: 'radio', label: 'Do you have collateral?', options: [ { value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Submit Loan Application', success_message: 'Your loan application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'credit_repair') {
                formData = {
                    title: 'Credit Repair Service Consultation',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'current_credit_score', name: 'current_credit_score', default_value: '', type: 'select', label: 'Current Credit Score', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select score', label: 'Select score'}, { value: 'excellent', label: 'Excellent (750-850)' }, { value: 'good', label: 'Good (700-749)' }, { value: 'fair', label: 'Fair (650-699)' }, { value: 'poor', label: 'Poor (300-649)' }, { value: 'unknown', label: 'I don\'t know' } ], required: true },
                        { id: 'credit_goals', name: 'credit_goals', default_value: '', type: 'select', label: 'Credit Goals', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select goals', label: 'Select goals'}, { value: 'improve_score', label: 'Improve Credit Score' }, { value: 'remove_negative_items', label: 'Remove Negative Items' }, { value: 'increase_credit_limit', label: 'Increase Credit Limits' }, { value: 'qualify_for_loan', label: 'Qualify for Better Loans' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'credit_issues', name: 'credit_issues', default_value: '', type: 'checkbox', label: 'Credit Issues', options: [ { value: 'late_payments', label: 'Late Payments' }, { value: 'collections', label: 'Collections' }, { value: 'charge_offs', label: 'Charge-offs' }, { value: 'bankruptcies', label: 'Bankruptcies' }, { value: 'foreclosures', label: 'Foreclosures' }, { value: 'tax_liens', label: 'Tax Liens' }, { value: 'none', label: 'None' } ], required: false },
                        { id: 'timeline_goals', name: 'timeline_goals', default_value: '', type: 'select', label: 'Timeline Goals', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: '3_months', label: '3 months' }, { value: '6_months', label: '6 months' }, { value: '1_year', label: '1 year' }, { value: '2_years', label: '2 years' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'current_situation', name: 'current_situation', default_value: '', type: 'textarea', label: 'Current Financial Situation', placeholder: 'Describe your current financial situation and challenges', required: true },
                        { id: 'previous_attempts', name: 'previous_attempts', default_value: '', type: 'radio', label: 'Previous Credit Repair Attempts', options: [ { value: 'yes', label: 'Yes, I have tried before' }, { value: 'no', label: 'No, this is my first time' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_100', label: 'Under $100/month' }, { value: '100_200', label: '$100 - $200/month' }, { value: '200_300', label: '$200 - $300/month' }, { value: 'over_300', label: 'Over $300/month' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Request Credit Repair Consultation', success_message: 'Your credit repair consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'investment_consultation') {
                formData = {
                    title: 'Investment Consultation Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Age', placeholder: 'Enter your age', required: true },
                        { id: 'investment_goals', name: 'investment_goals', default_value: '', type: 'checkbox', label: 'Investment Goals', options: [ { value: 'retirement', label: 'Retirement Planning' }, { value: 'wealth_building', label: 'Wealth Building' }, { value: 'income_generation', label: 'Income Generation' }, { value: 'tax_efficiency', label: 'Tax Efficiency' }, { value: 'college_funding', label: 'College Funding' }, { value: 'real_estate', label: 'Real Estate Investment' }, { value: 'business_ownership', label: 'Business Ownership' } ], required: true },
                        { id: 'risk_tolerance', name: 'risk_tolerance', default_value: '', type: 'radio', label: 'Risk Tolerance', options: [ { value: 'conservative', label: 'Conservative (Low risk, stable returns)' }, { value: 'moderate', label: 'Moderate (Balanced risk and return)' }, { value: 'aggressive', label: 'Aggressive (Higher risk, potential for higher returns)' } ], required: true },
                        { id: 'investment_timeline', name: 'investment_timeline', default_value: '', type: 'select', label: 'Investment Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'short_term', label: 'Short Term (1-3 years)' }, { value: 'medium_term', label: 'Medium Term (3-10 years)' }, { value: 'long_term', label: 'Long Term (10+ years)' } ], required: true },
                        { id: 'current_investments', name: 'current_investments', default_value: '', type: 'checkbox', label: 'Current Investments', options: [ { value: 'stocks', label: 'Stocks' }, { value: 'bonds', label: 'Bonds' }, { value: 'mutual_funds', label: 'Mutual Funds' }, { value: 'etfs', label: 'ETFs' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'retirement_accounts', label: 'Retirement Accounts' }, { value: 'none', label: 'None' } ], required: false },
                        { id: 'investment_amount', name: 'investment_amount', default_value: '', type: 'select', label: 'Investment Amount', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select amount', label: 'Select amount'}, { value: 'under_10k', label: 'Under $10,000' }, { value: '10k_25k', label: '$10,000 - $25,000' }, { value: '25k_50k', label: '$25,000 - $50,000' }, { value: '50k_100k', label: '$50,000 - $100,000' }, { value: 'over_100k', label: 'Over $100,000' } ], required: true },
                        { id: 'monthly_contribution', name: 'monthly_contribution', default_value: '', type: 'select', label: 'Monthly Contribution', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select contribution', label: 'Select contribution'}, { value: 'under_500', label: 'Under $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: '1000_2000', label: '$1,000 - $2,000' }, { value: 'over_2000', label: 'Over $2,000' } ], required: true },
                        { id: 'specific_questions', name: 'specific_questions', default_value: '', type: 'textarea', label: 'Specific Questions', placeholder: 'What specific investment questions do you have?', required: false }
                    ],
                    settings: { submit_button_text: 'Request Investment Consultation', success_message: 'Your investment consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'estate_planning') {
                formData = {
                    title: 'Estate Planning Consultation',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Age', placeholder: 'Enter your age', required: true },
                        { id: 'marital_status', name: 'marital_status', default_value: '', type: 'select', label: 'Marital Status', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select status', label: 'Select status'}, { value: 'single', label: 'Single' }, { value: 'married', label: 'Married' }, { value: 'divorced', label: 'Divorced' }, { value: 'widowed', label: 'Widowed' } ], required: true },
                        { id: 'children', name: 'children', default_value: '', type: 'radio', label: 'Do you have children?', options: [ { value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' } ], required: true },
                        { id: 'number_of_children', name: 'number_of_children', default_value: '', type: 'number', label: 'Number of Children', placeholder: 'Enter number of children (if applicable)', required: false },
                        { id: 'estate_planning_needs', name: 'estate_planning_needs', default_value: '', type: 'checkbox', label: 'Estate Planning Needs', options: [ { value: 'will', label: 'Last Will & Testament' }, { value: 'trust', label: 'Living Trust' }, { value: 'power_of_attorney', label: 'Power of Attorney' }, { value: 'health_care_proxy', label: 'Healthcare Proxy' }, { value: 'beneficiary_designations', label: 'Beneficiary Designations' }, { value: 'business_succession', label: 'Business Succession' }, { value: 'charitable_giving', label: 'Charitable Giving' } ], required: true },
                        { id: 'estate_value', name: 'estate_value', default_value: '', type: 'select', label: 'Estimated Estate Value', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select value', label: 'Select value'}, { value: 'under_100k', label: 'Under $100,000' }, { value: '100k_500k', label: '$100,000 - $500,000' }, { value: '500k_1m', label: '$500,000 - $1,000,000' }, { value: '1m_5m', label: '$1,000,000 - $5,000,000' }, { value: 'over_5m', label: 'Over $5,000,000' } ], required: true },
                        { id: 'urgency', name: 'urgency', default_value: '', type: 'select', label: 'Urgency Level', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select urgency', label: 'Select urgency'}, { value: 'low', label: 'Low (Planning ahead)' }, { value: 'medium', label: 'Medium (Within 1 year)' }, { value: 'high', label: 'High (Immediate need)' } ], required: true },
                        { id: 'specific_concerns', name: 'specific_concerns', default_value: '', type: 'textarea', label: 'Specific Concerns', placeholder: 'Any specific estate planning concerns or questions', required: false }
                    ],
                    settings: { submit_button_text: 'Request Estate Planning Consultation', success_message: 'Your estate planning consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'retirement_planning') {
                formData = {
                    title: 'Retirement Planning Consultation',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'age', name: 'age', default_value: '', type: 'number', label: 'Current Age', placeholder: 'Enter your current age', required: true },
                        { id: 'retirement_age', name: 'retirement_age', default_value: '', type: 'number', label: 'Target Retirement Age', placeholder: 'Enter your target retirement age', required: true },
                        { id: 'current_savings', name: 'current_savings', default_value: '', type: 'select', label: 'Current Retirement Savings', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select savings', label: 'Select savings'}, { value: 'under_50k', label: 'Under $50,000' }, { value: '50k_100k', label: '$50,000 - $100,000' }, { value: '100k_250k', label: '$100,000 - $250,000' }, { value: '250k_500k', label: '$250,000 - $500,000' }, { value: 'over_500k', label: 'Over $500,000' } ], required: true },
                        { id: 'monthly_contribution', name: 'monthly_contribution', default_value: '', type: 'select', label: 'Monthly Contribution', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select contribution', label: 'Select contribution'}, { value: 'under_500', label: 'Under $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: '1000_2000', label: '$1,000 - $2,000' }, { value: 'over_2000', label: 'Over $2,000' } ], required: true },
                        { id: 'retirement_income_goal', name: 'retirement_income_goal', default_value: '', type: 'select', label: 'Desired Annual Retirement Income', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select income', label: 'Select income'}, { value: 'under_50k', label: 'Under $50,000' }, { value: '50k_75k', label: '$50,000 - $75,000' }, { value: '75k_100k', label: '$75,000 - $100,000' }, { value: '100k_150k', label: '$100,000 - $150,000' }, { value: 'over_150k', label: 'Over $150,000' } ], required: true },
                        { id: 'retirement_lifestyle', name: 'retirement_lifestyle', default_value: '', type: 'select', label: 'Retirement Lifestyle', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select lifestyle', label: 'Select lifestyle'}, { value: 'minimal', label: 'Minimal (Basic needs)' }, { value: 'comfortable', label: 'Comfortable (Current standard)' }, { value: 'luxury', label: 'Luxury (Enhanced lifestyle)' }, { value: 'very_luxury', label: 'Very Luxury (Premium lifestyle)' } ], required: true },
                        { id: 'risk_tolerance', name: 'risk_tolerance', default_value: '', type: 'radio', label: 'Risk Tolerance', options: [ { value: 'conservative', label: 'Conservative' }, { value: 'moderate', label: 'Moderate' }, { value: 'aggressive', label: 'Aggressive' } ], required: true },
                        { id: 'health_concerns', name: 'health_concerns', default_value: '', type: 'textarea', label: 'Health Concerns', placeholder: 'Any health concerns that might affect retirement planning', required: false },
                        { id: 'specific_goals', name: 'specific_goals', default_value: '', type: 'textarea', label: 'Specific Retirement Goals', placeholder: 'Describe your specific retirement goals and dreams', required: false }
                    ],
                    settings: { submit_button_text: 'Request Retirement Planning Consultation', success_message: 'Your retirement planning consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'college_planning') {
                formData = {
                    title: 'College Planning Consultation',
                    fields: [
                        { id: 'parent_name', name: 'parent_name', default_value: '', type: 'text', label: 'Parent/Guardian Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'student_name', name: 'student_name', default_value: '', type: 'text', label: 'Student Name', placeholder: 'Enter student\'s full name', required: true },
                        { id: 'student_age', name: 'student_age', default_value: '', type: 'number', label: 'Student Age', placeholder: 'Enter student\'s current age', required: true },
                        { id: 'years_to_college', name: 'years_to_college', default_value: '', type: 'select', label: 'Years Until College', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select years', label: 'Select years'}, { value: '1_2', label: '1-2 years' }, { value: '3_5', label: '3-5 years' }, { value: '6_8', label: '6-8 years' }, { value: '9_12', label: '9-12 years' }, { value: '13_plus', label: '13+ years' } ], required: true },
                        { id: 'college_type_preference', name: 'college_type_preference', default_value: '', type: 'checkbox', label: 'College Type Preferences', options: [ { value: 'public_in_state', label: 'Public In-State' }, { value: 'public_out_state', label: 'Public Out-of-State' }, { value: 'private', label: 'Private' }, { value: 'community_college', label: 'Community College' }, { value: 'trade_school', label: 'Trade School' }, { value: 'online', label: 'Online' } ], required: false },
                        { id: 'estimated_college_cost', name: 'estimated_college_cost', default_value: '', type: 'select', label: 'Estimated Annual College Cost', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select cost', label: 'Select cost'}, { value: 'under_10k', label: 'Under $10,000' }, { value: '10k_20k', label: '$10,000 - $20,000' }, { value: '20k_30k', label: '$20,000 - $30,000' }, { value: '30k_50k', label: '$30,000 - $50,000' }, { value: 'over_50k', label: 'Over $50,000' } ], required: true },
                        { id: 'current_savings', name: 'current_savings', default_value: '', type: 'select', label: 'Current College Savings', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select savings', label: 'Select savings'}, { value: 'under_5k', label: 'Under $5,000' }, { value: '5k_15k', label: '$5,000 - $15,000' }, { value: '15k_30k', label: '$15,000 - $30,000' }, { value: '30k_50k', label: '$30,000 - $50,000' }, { value: 'over_50k', label: 'Over $50,000' } ], required: true },
                        { id: 'monthly_contribution', name: 'monthly_contribution', default_value: '', type: 'select', label: 'Monthly Contribution Goal', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select contribution', label: 'Select contribution'}, { value: 'under_200', label: 'Under $200' }, { value: '200_500', label: '$200 - $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: 'over_1000', label: 'Over $1,000' } ], required: true },
                        { id: 'financial_aid_interest', name: 'financial_aid_interest', default_value: '', type: 'checkbox', label: 'Financial Aid Interest', options: [ { value: 'scholarships', label: 'Scholarships' }, { value: 'grants', label: 'Grants' }, { value: 'work_study', label: 'Work Study' }, { value: 'student_loans', label: 'Student Loans' }, { value: 'parent_loans', label: 'Parent Loans' } ], required: false },
                        { id: 'specific_questions', name: 'specific_questions', default_value: '', type: 'textarea', label: 'Specific Questions', placeholder: 'Any specific questions about college planning', required: false }
                    ],
                    settings: { submit_button_text: 'Request College Planning Consultation', success_message: 'Your college planning consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'scholarship_application') {
                formData = {
                    title: 'Scholarship Application',
                    fields: [
                        { id: 'student_name', name: 'student_name', default_value: '', type: 'text', label: 'Student Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'high_school', name: 'high_school', default_value: '', type: 'text', label: 'High School Name', placeholder: 'Enter your high school name', required: true },
                        { id: 'graduation_year', name: 'graduation_year', default_value: '', type: 'select', label: 'High School Graduation Year', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select year', label: 'Select year'}, { value: '2024', label: '2024' }, { value: '2025', label: '2025' }, { value: '2026', label: '2026' }, { value: '2027', label: '2027' } ], required: true },
                        { id: 'gpa', name: 'gpa', default_value: '', type: 'number', label: 'GPA (Grade Point Average)', placeholder: 'Enter your GPA (e.g., 3.5)', required: true },
                        { id: 'sat_score', name: 'sat_score', default_value: '', type: 'number', label: 'SAT Score (if applicable)', placeholder: 'Enter your SAT score (e.g., 1200)', required: false },
                        { id: 'act_score', name: 'act_score', default_value: '', type: 'number', label: 'ACT Score (if applicable)', placeholder: 'Enter your ACT score (e.g., 25)', required: false },
                        { id: 'intended_major', name: 'intended_major', default_value: '', type: 'text', label: 'Intended College Major', placeholder: 'Enter your intended major', required: true },
                        { id: 'college_choice', name: 'college_choice', default_value: '', type: 'text', label: 'Preferred College/University', placeholder: 'Enter your preferred college', required: true },
                        { id: 'extracurricular_activities', name: 'extracurricular_activities', default_value: '', type: 'textarea', label: 'Extracurricular Activities', placeholder: 'List your extracurricular activities, clubs, sports, etc.', required: true },
                        { id: 'community_service', name: 'community_service', default_value: '', type: 'textarea', label: 'Community Service/Volunteer Work', placeholder: 'Describe your community service and volunteer experience', required: false },
                        { id: 'leadership_experience', name: 'leadership_experience', default_value: '', type: 'textarea', label: 'Leadership Experience', placeholder: 'Describe any leadership roles or experiences', required: false },
                        { id: 'financial_need', name: 'financial_need', default_value: '', type: 'radio', label: 'Financial Need', options: [ { value: 'high', label: 'High Need' }, { value: 'medium', label: 'Medium Need' }, { value: 'low', label: 'Low Need' } ], required: true },
                        { id: 'essay', name: 'essay', default_value: '', type: 'textarea', label: 'Personal Statement/Essay', placeholder: 'Write a brief personal statement about why you deserve this scholarship', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Scholarship Application', success_message: 'Your scholarship application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'student_loan') {
                formData = {
                    title: 'Student Loan Application',
                    fields: [
                        { id: 'student_name', name: 'student_name', default_value: '', type: 'text', label: 'Student Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'ssn', name: 'ssn', default_value: '', type: 'text', label: 'Social Security Number', placeholder: 'Enter your SSN (XXX-XX-XXXX)', required: true },
                        { id: 'loan_type', name: 'loan_type', default_value: '', type: 'select', label: 'Loan Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'federal_subsidized', label: 'Federal Subsidized' }, { value: 'federal_unsubsidized', label: 'Federal Unsubsidized' }, { value: 'federal_plus', label: 'Federal PLUS Loan' }, { value: 'private', label: 'Private Student Loan' }, { value: 'refinance', label: 'Student Loan Refinance' } ], required: true },
                        { id: 'college_name', name: 'college_name', default_value: '', type: 'text', label: 'College/University Name', placeholder: 'Enter your college or university name', required: true },
                        { id: 'enrollment_status', name: 'enrollment_status', default_value: '', type: 'select', label: 'Enrollment Status', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select status', label: 'Select status'}, { value: 'full_time', label: 'Full-Time Student' }, { value: 'part_time', label: 'Part-Time Student' }, { value: 'graduate', label: 'Graduate Student' }, { value: 'professional', label: 'Professional Student' } ], required: true },
                        { id: 'academic_year', name: 'academic_year', default_value: '', type: 'select', label: 'Academic Year', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select year', label: 'Select year'}, { value: 'freshman', label: 'Freshman' }, { value: 'sophomore', label: 'Sophomore' }, { value: 'junior', label: 'Junior' }, { value: 'senior', label: 'Senior' }, { value: 'graduate', label: 'Graduate' } ], required: true },
                        { id: 'loan_amount', name: 'loan_amount', default_value: '', type: 'number', label: 'Loan Amount Requested', placeholder: 'Enter the amount you need', required: true },
                        { id: 'loan_purpose', name: 'loan_purpose', default_value: '', type: 'checkbox', label: 'Loan Purpose', options: [ { value: 'tuition', label: 'Tuition' }, { value: 'room_board', label: 'Room & Board' }, { value: 'books_supplies', label: 'Books & Supplies' }, { value: 'fees', label: 'Fees' }, { value: 'other', label: 'Other Expenses' } ], required: true },
                        { id: 'cosigner_available', name: 'cosigner_available', default_value: '', type: 'radio', label: 'Do you have a cosigner?', options: [ { value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' } ], required: true },
                        { id: 'cosigner_name', name: 'cosigner_name', default_value: '', type: 'text', label: 'Cosigner Name (if applicable)', placeholder: 'Enter cosigner\'s full name', required: false },
                        { id: 'employment_status', name: 'employment_status', default_value: '', type: 'select', label: 'Employment Status', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select status', label: 'Select status'}, { value: 'employed', label: 'Employed' }, { value: 'part_time', label: 'Part-Time' }, { value: 'unemployed', label: 'Unemployed' }, { value: 'student', label: 'Full-Time Student' } ], required: true },
                        { id: 'monthly_income', name: 'monthly_income', default_value: '', type: 'number', label: 'Monthly Income (if employed)', placeholder: 'Enter your monthly income', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Student Loan Application', success_message: 'Your student loan application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'grad_school') {
                formData = {
                    title: 'Graduate School Application',
                    fields: [
                        { id: 'applicant_name', name: 'applicant_name', default_value: '', type: 'text', label: 'Applicant Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'undergraduate_degree', name: 'undergraduate_degree', default_value: '', type: 'text', label: 'Undergraduate Degree', placeholder: 'Enter your undergraduate degree', required: true },
                        { id: 'undergraduate_gpa', name: 'undergraduate_gpa', default_value: '', type: 'number', label: 'Undergraduate GPA', placeholder: 'Enter your undergraduate GPA', required: true },
                        { id: 'undergraduate_school', name: 'undergraduate_school', default_value: '', type: 'text', label: 'Undergraduate Institution', placeholder: 'Enter your undergraduate school name', required: true },
                        { id: 'graduation_year', name: 'graduation_year', default_value: '', type: 'select', label: 'Undergraduate Graduation Year', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select year', label: 'Select year'}, { value: '2020', label: '2020' }, { value: '2021', label: '2021' }, { value: '2022', label: '2022' }, { value: '2023', label: '2023' }, { value: '2024', label: '2024' } ], required: true },
                        { id: 'graduate_program', name: 'graduate_program', default_value: '', type: 'text', label: 'Graduate Program of Interest', placeholder: 'Enter the graduate program you\'re interested in', required: true },
                        { id: 'degree_type', name: 'degree_type', default_value: '', type: 'select', label: 'Degree Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select degree', label: 'Select degree'}, { value: 'masters', label: 'Master\'s Degree' }, { value: 'phd', label: 'Ph.D.' }, { value: 'professional', label: 'Professional Degree' }, { value: 'certificate', label: 'Certificate Program' } ], required: true },
                        { id: 'gre_score', name: 'gre_score', default_value: '', type: 'number', label: 'GRE Score (if applicable)', placeholder: 'Enter your GRE score', required: false },
                        { id: 'gmat_score', name: 'gmat_score', default_value: '', type: 'number', label: 'GMAT Score (if applicable)', placeholder: 'Enter your GMAT score', required: false },
                        { id: 'lsat_score', name: 'lsat_score', default_value: '', type: 'number', label: 'LSAT Score (if applicable)', placeholder: 'Enter your LSAT score', required: false },
                        { id: 'mcat_score', name: 'mcat_score', default_value: '', type: 'number', label: 'MCAT Score (if applicable)', placeholder: 'Enter your MCAT score', required: false },
                        { id: 'research_experience', name: 'research_experience', default_value: '', type: 'textarea', label: 'Research Experience', placeholder: 'Describe any research experience you have', required: false },
                        { id: 'work_experience', name: 'work_experience', default_value: '', type: 'textarea', label: 'Work Experience', placeholder: 'Describe your relevant work experience', required: false },
                        { id: 'statement_of_purpose', name: 'statement_of_purpose', default_value: '', type: 'textarea', label: 'Statement of Purpose', placeholder: 'Briefly describe your goals and why you want to pursue this program', required: true },
                        { id: 'preferred_start_term', name: 'preferred_start_term', default_value: '', type: 'select', label: 'Preferred Start Term', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select term', label: 'Select term'}, { value: 'fall_2025', label: 'Fall 2025' }, { value: 'spring_2026', label: 'Spring 2026' }, { value: 'fall_2026', label: 'Fall 2026' }, { value: 'spring_2027', label: 'Spring 2027' } ], required: true }
                    ],
                    settings: { submit_button_text: 'Submit Graduate School Application', success_message: 'Your graduate school application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'study_abroad') {
                formData = {
                    title: 'Study Abroad Program Application',
                    fields: [
                        { id: 'student_name', name: 'student_name', default_value: '', type: 'text', label: 'Student Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'passport_number', name: 'passport_number', default_value: '', type: 'text', label: 'Passport Number', placeholder: 'Enter your passport number', required: true },
                        { id: 'passport_expiry', name: 'passport_expiry', default_value: '', type: 'date', label: 'Passport Expiry Date', placeholder: 'Select your passport expiry date', required: true },
                        { id: 'home_university', name: 'home_university', default_value: '', type: 'text', label: 'Home University', placeholder: 'Enter your home university name', required: true },
                        { id: 'academic_year', name: 'academic_year', default_value: '', type: 'select', label: 'Academic Year', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select year', label: 'Select year'}, { value: 'freshman', label: 'Freshman' }, { value: 'sophomore', label: 'Sophomore' }, { value: 'junior', label: 'Junior' }, { value: 'senior', label: 'Senior' }, { value: 'graduate', label: 'Graduate Student' } ], required: true },
                        { id: 'major', name: 'major', default_value: '', type: 'text', label: 'Major/Field of Study', placeholder: 'Enter your major or field of study', required: true },
                        { id: 'gpa', name: 'gpa', default_value: '', type: 'number', label: 'Current GPA', placeholder: 'Enter your current GPA', required: true },
                        { id: 'destination_country', name: 'destination_country', default_value: '', type: 'select', label: 'Destination Country', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select country', label: 'Select country'}, { value: 'uk', label: 'United Kingdom' }, { value: 'france', label: 'France' }, { value: 'germany', label: 'Germany' }, { value: 'spain', label: 'Spain' }, { value: 'italy', label: 'Italy' }, { value: 'australia', label: 'Australia' }, { value: 'japan', label: 'Japan' }, { value: 'south_korea', label: 'South Korea' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'program_duration', name: 'program_duration', default_value: '', type: 'select', label: 'Program Duration', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select duration', label: 'Select duration'}, { value: 'summer', label: 'Summer (2-3 months)' }, { value: 'semester', label: 'Semester (4-5 months)' }, { value: 'academic_year', label: 'Academic Year (9-10 months)' }, { value: 'full_degree', label: 'Full Degree Program' } ], required: true },
                        { id: 'start_term', name: 'start_term', default_value: '', type: 'select', label: 'Preferred Start Term', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select term', label: 'Select term'}, { value: 'fall_2025', label: 'Fall 2025' }, { value: 'spring_2026', label: 'Spring 2026' }, { value: 'summer_2026', label: 'Summer 2026' }, { value: 'fall_2026', label: 'Fall 2026' } ], required: true },
                        { id: 'language_skills', name: 'language_skills', default_value: '', type: 'select', label: 'Language Skills', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select skills', label: 'Select skills'}, { value: 'beginner', label: 'Beginner' }, { value: 'intermediate', label: 'Intermediate' }, { value: 'advanced', label: 'Advanced' }, { value: 'native', label: 'Native/Fluent' } ], required: true },
                        { id: 'financial_support', name: 'financial_support', default_value: '', type: 'radio', label: 'Financial Support Available', options: [ { value: 'yes', label: 'Yes, I have financial support' }, { value: 'no', label: 'No, I need financial assistance' } ], required: true },
                        { id: 'motivation', name: 'motivation', default_value: '', type: 'textarea', label: 'Motivation for Study Abroad', placeholder: 'Explain why you want to study abroad and what you hope to gain', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Study Abroad Application', success_message: 'Your study abroad application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'internship') {
                formData = {
                    title: 'Internship Application',
                    fields: [
                        { id: 'applicant_name', name: 'applicant_name', default_value: '', type: 'text', label: 'Applicant Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'university', name: 'university', default_value: '', type: 'text', label: 'University/College', placeholder: 'Enter your university or college name', required: true },
                        { id: 'major', name: 'major', default_value: '', type: 'text', label: 'Major/Field of Study', placeholder: 'Enter your major or field of study', required: true },
                        { id: 'academic_year', name: 'academic_year', default_value: '', type: 'select', label: 'Academic Year', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select year', label: 'Select year'}, { value: 'freshman', label: 'Freshman' }, { value: 'sophomore', label: 'Sophomore' }, { value: 'junior', label: 'Junior' }, { value: 'senior', label: 'Senior' }, { value: 'graduate', label: 'Graduate Student' } ], required: true },
                        { id: 'graduation_date', name: 'graduation_date', default_value: '', type: 'date', label: 'Expected Graduation Date', placeholder: 'Select your expected graduation date', required: true },
                        { id: 'gpa', name: 'gpa', default_value: '', type: 'number', label: 'Current GPA', placeholder: 'Enter your current GPA', required: true },
                        { id: 'internship_position', name: 'internship_position', default_value: '', type: 'text', label: 'Internship Position', placeholder: 'Enter the internship position you\'re applying for', required: true },
                        { id: 'internship_type', name: 'internship_type', default_value: '', type: 'select', label: 'Internship Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'summer', label: 'Summer Internship' }, { value: 'fall', label: 'Fall Internship' }, { value: 'spring', label: 'Spring Internship' }, { value: 'academic_year', label: 'Academic Year Internship' }, { value: 'virtual', label: 'Virtual/Remote Internship' } ], required: true },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'Preferred Start Date', placeholder: 'Select your preferred start date', required: true },
                        { id: 'duration', name: 'duration', default_value: '', type: 'select', label: 'Internship Duration', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select duration', label: 'Select duration'}, { value: '8_weeks', label: '8 weeks' }, { value: '10_weeks', label: '10 weeks' }, { value: '12_weeks', label: '12 weeks' }, { value: '16_weeks', label: '16 weeks' }, { value: 'semester', label: 'Full Semester' } ], required: true },
                        { id: 'work_authorization', name: 'work_authorization', default_value: '', type: 'radio', label: 'Work Authorization', options: [ { value: 'us_citizen', label: 'U.S. Citizen' }, { value: 'permanent_resident', label: 'Permanent Resident' }, { value: 'student_visa', label: 'Student Visa (F-1)' }, { value: 'other_visa', label: 'Other Visa' }, { value: 'no_authorization', label: 'No Work Authorization' } ], required: true },
                        { id: 'relevant_coursework', name: 'relevant_coursework', default_value: '', type: 'textarea', label: 'Relevant Coursework', placeholder: 'List relevant courses you have taken', required: false },
                        { id: 'skills', name: 'skills', default_value: '', type: 'textarea', label: 'Skills & Certifications', placeholder: 'List your relevant skills, software knowledge, and certifications', required: true },
                        { id: 'experience', name: 'experience', default_value: '', type: 'textarea', label: 'Relevant Experience', placeholder: 'Describe any relevant work, volunteer, or project experience', required: false },
                        { id: 'why_interested', name: 'why_interested', default_value: '', type: 'textarea', label: 'Why are you interested in this internship?', placeholder: 'Explain your interest in this position and company', required: true },
                        { id: 'career_goals', name: 'career_goals', default_value: '', type: 'textarea', label: 'Career Goals', placeholder: 'How does this internship align with your career goals?', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Internship Application', success_message: 'Your internship application has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'freelance_project') {
                formData = {
                    title: 'Freelance Project Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name (if applicable)', placeholder: 'Enter your company name', required: false },
                        { id: 'project_type', name: 'project_type', default_value: '', type: 'select', label: 'Project Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'web_design', label: 'Web Design' }, { value: 'web_development', label: 'Web Development' }, { value: 'graphic_design', label: 'Graphic Design' }, { value: 'content_writing', label: 'Content Writing' }, { value: 'digital_marketing', label: 'Digital Marketing' }, { value: 'seo', label: 'SEO' }, { value: 'social_media', label: 'Social Media Management' }, { value: 'video_editing', label: 'Video Editing' }, { value: 'translation', label: 'Translation' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'project_title', name: 'project_title', default_value: '', type: 'text', label: 'Project Title', placeholder: 'Enter a brief title for your project', required: true },
                        { id: 'project_description', name: 'project_description', default_value: '', type: 'textarea', label: 'Project Description', placeholder: 'Describe your project in detail', required: true },
                        { id: 'project_scope', name: 'project_scope', default_value: '', type: 'select', label: 'Project Scope', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select scope', label: 'Select scope'}, { value: 'small', label: 'Small (1-2 weeks)' }, { value: 'medium', label: 'Medium (2-4 weeks)' }, { value: 'large', label: 'Large (1-3 months)' }, { value: 'ongoing', label: 'Ongoing/Recurring' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_500', label: 'Under $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: '1000_2500', label: '$1,000 - $2,500' }, { value: '2500_5000', label: '$2,500 - $5,000' }, { value: 'over_5000', label: 'Over $5,000' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_2_weeks', label: '1-2 weeks' }, { value: '1_month', label: '1 month' }, { value: '2_3_months', label: '2-3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'required_skills', name: 'required_skills', default_value: '', type: 'textarea', label: 'Required Skills', placeholder: 'List specific skills or technologies required', required: false },
                        { id: 'reference_examples', name: 'reference_examples', default_value: '', type: 'textarea', label: 'Reference Examples', placeholder: 'Provide examples of similar projects or websites you like', required: false },
                        { id: 'additional_requirements', name: 'additional_requirements', default_value: '', type: 'textarea', label: 'Additional Requirements', placeholder: 'Any other specific requirements or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Project Request', success_message: 'Your freelance project request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'virtual_assistant') {
                formData = {
                    title: 'Virtual Assistant Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name (if applicable)', placeholder: 'Enter your company name', required: false },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'checkbox', label: 'Service Type Needed', options: [ { value: 'administrative', label: 'Administrative Tasks' }, { value: 'email_management', label: 'Email Management' }, { value: 'calendar_management', label: 'Calendar Management' }, { value: 'data_entry', label: 'Data Entry' }, { value: 'research', label: 'Research' }, { value: 'social_media', label: 'Social Media Management' }, { value: 'content_creation', label: 'Content Creation' }, { value: 'customer_service', label: 'Customer Service' }, { value: 'bookkeeping', label: 'Bookkeeping' }, { value: 'travel_arrangements', label: 'Travel Arrangements' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'hours_needed', name: 'hours_needed', default_value: '', type: 'select', label: 'Hours Needed Per Week', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select hours', label: 'Select hours'}, { value: '5_10', label: '5-10 hours' }, { value: '10_20', label: '10-20 hours' }, { value: '20_30', label: '20-30 hours' }, { value: '30_40', label: '30-40 hours' }, { value: '40_plus', label: '40+ hours' } ], required: true },
                        { id: 'schedule_preference', name: 'schedule_preference', default_value: '', type: 'select', label: 'Schedule Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select schedule', label: 'Select schedule'}, { value: 'business_hours', label: 'Business Hours (9 AM - 5 PM)' }, { value: 'flexible', label: 'Flexible Hours' }, { value: 'weekends', label: 'Weekend Availability' }, { value: 'overnight', label: 'Overnight/Off-hours' }, { value: 'as_needed', label: 'As Needed/On-demand' } ], required: true },
                        { id: 'timezone', name: 'timezone', default_value: '', type: 'select', label: 'Preferred Timezone', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timezone', label: 'Select timezone'}, { value: 'est', label: 'Eastern Time (EST/EDT)' }, { value: 'cst', label: 'Central Time (CST/CDT)' }, { value: 'mst', label: 'Mountain Time (MST/MDT)' }, { value: 'pst', label: 'Pacific Time (PST/PDT)' }, { value: 'gmt', label: 'Greenwich Mean Time (GMT)' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'Preferred Start Date', placeholder: 'Select your preferred start date', required: true },
                        { id: 'duration', name: 'duration', default_value: '', type: 'select', label: 'Duration of Service', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select duration', label: 'Select duration'}, { value: 'one_time', label: 'One-time Project' }, { value: '1_month', label: '1 Month' }, { value: '3_months', label: '3 Months' }, { value: '6_months', label: '6 Months' }, { value: 'ongoing', label: 'Ongoing' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range (per hour)', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_15', label: 'Under $15/hour' }, { value: '15_25', label: '$15 - $25/hour' }, { value: '25_35', label: '$25 - $35/hour' }, { value: '35_50', label: '$35 - $50/hour' }, { value: 'over_50', label: 'Over $50/hour' } ], required: true },
                        { id: 'specific_tasks', name: 'specific_tasks', default_value: '', type: 'textarea', label: 'Specific Tasks', placeholder: 'Describe the specific tasks you need help with', required: true },
                        { id: 'required_skills', name: 'required_skills', default_value: '', type: 'textarea', label: 'Required Skills', placeholder: 'List any specific skills or software knowledge required', required: false },
                        { id: 'communication_preference', name: 'communication_preference', default_value: '', type: 'checkbox', label: 'Communication Preference', options: [ { value: 'email', label: 'Email' }, { value: 'phone', label: 'Phone' }, { value: 'video_call', label: 'Video Call' }, { value: 'chat', label: 'Chat/Messaging' }, { value: 'project_management', label: 'Project Management Tools' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Request Virtual Assistant Service', success_message: 'Your virtual assistant service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'social_media') {
                formData = {
                    title: 'Social Media Management Service',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'ecommerce', label: 'E-commerce' }, { value: 'service_business', label: 'Service Business' }, { value: 'restaurant', label: 'Restaurant/Food' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'consulting', label: 'Consulting' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'social_media_platforms', name: 'social_media_platforms', default_value: '', type: 'checkbox', label: 'Social Media Platforms', options: [ { value: 'facebook', label: 'Facebook' }, { value: 'instagram', label: 'Instagram' }, { value: 'twitter', label: 'Twitter/X' }, { value: 'linkedin', label: 'LinkedIn' }, { value: 'tiktok', label: 'TikTok' }, { value: 'youtube', label: 'YouTube' }, { value: 'pinterest', label: 'Pinterest' }, { value: 'snapchat', label: 'Snapchat' } ], required: true },
                        { id: 'service_type', name: 'service_type', default_value: '', type: 'checkbox', label: 'Service Type', options: [ { value: 'content_creation', label: 'Content Creation' }, { value: 'content_scheduling', label: 'Content Scheduling' }, { value: 'community_management', label: 'Community Management' }, { value: 'paid_advertising', label: 'Paid Advertising' }, { value: 'analytics_reporting', label: 'Analytics & Reporting' }, { value: 'influencer_collaborations', label: 'Influencer Collaborations' }, { value: 'crisis_management', label: 'Crisis Management' }, { value: 'strategy_consulting', label: 'Strategy Consulting' } ], required: true },
                        { id: 'content_frequency', name: 'content_frequency', default_value: '', type: 'select', label: 'Content Frequency', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select frequency', label: 'Select frequency'}, { value: 'daily', label: 'Daily' }, { value: '2_3_per_week', label: '2-3 times per week' }, { value: 'weekly', label: 'Weekly' }, { value: 'bi_weekly', label: 'Bi-weekly' }, { value: 'monthly', label: 'Monthly' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Monthly Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_500', label: 'Under $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: '1000_2000', label: '$1,000 - $2,000' }, { value: '2000_5000', label: '$2,000 - $5,000' }, { value: 'over_5000', label: 'Over $5,000' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '3_months', label: '3 months' }, { value: '6_months', label: '6 months' }, { value: 'ongoing', label: 'Ongoing' } ], required: true },
                        { id: 'current_social_media', name: 'current_social_media', default_value: '', type: 'radio', label: 'Current Social Media Presence', options: [ { value: 'none', label: 'None - Starting from scratch' }, { value: 'basic', label: 'Basic - Some accounts exist' }, { value: 'established', label: 'Established - Active accounts' }, { value: 'growing', label: 'Growing - Good engagement' } ], required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience and demographics', required: true },
                        { id: 'goals', name: 'goals', default_value: '', type: 'textarea', label: 'Social Media Goals', placeholder: 'What do you want to achieve with social media?', required: true },
                        { id: 'competitors', name: 'competitors', default_value: '', type: 'textarea', label: 'Competitors', placeholder: 'List 2-3 main competitors or similar businesses', required: false }
                    ],
                    settings: { submit_button_text: 'Request Social Media Service', success_message: 'Your social media management service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'seo_consultation') {
                formData = {
                    title: 'SEO Consultation Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'website_url', name: 'website_url', default_value: '', type: 'url', label: 'Website URL', placeholder: 'Enter your website URL', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'ecommerce', label: 'E-commerce' }, { value: 'service_business', label: 'Service Business' }, { value: 'restaurant', label: 'Restaurant/Food' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'consulting', label: 'Consulting' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_location', name: 'target_location', default_value: '', type: 'text', label: 'Target Location', placeholder: 'Enter your target city, state, or region', required: true },
                        { id: 'primary_keywords', name: 'primary_keywords', default_value: '', type: 'textarea', label: 'Primary Keywords', placeholder: 'List 3-5 main keywords you want to rank for', required: true },
                        { id: 'competitor_websites', name: 'competitor_websites', default_value: '', type: 'textarea', label: 'Competitor Websites', placeholder: 'List 2-3 main competitor websites', required: false },
                        { id: 'current_seo_efforts', name: 'current_seo_efforts', default_value: '', type: 'radio', label: 'Current SEO Efforts', options: [ { value: 'none', label: 'None - Starting from scratch' }, { value: 'basic', label: 'Basic - Some optimization done' }, { value: 'moderate', label: 'Moderate - Regular optimization' }, { value: 'advanced', label: 'Advanced - Comprehensive SEO strategy' } ], required: true },
                        { id: 'seo_goals', name: 'seo_goals', default_value: '', type: 'checkbox', label: 'SEO Goals', options: [ { value: 'increase_traffic', label: 'Increase Organic Traffic' }, { value: 'improve_rankings', label: 'Improve Search Rankings' }, { value: 'local_seo', label: 'Local SEO Optimization' }, { value: 'technical_seo', label: 'Technical SEO Issues' }, { value: 'content_optimization', label: 'Content Optimization' }, { value: 'link_building', label: 'Link Building' }, { value: 'mobile_optimization', label: 'Mobile Optimization' }, { value: 'conversion_optimization', label: 'Conversion Rate Optimization' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Monthly Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_500', label: 'Under $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: '1000_2000', label: '$1,000 - $2,000' }, { value: '2000_5000', label: '$2,000 - $5,000' }, { value: 'over_5000', label: 'Over $5,000' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '3_months', label: '3 months' }, { value: '6_months', label: '6 months' }, { value: 'ongoing', label: 'Ongoing' } ], required: true },
                        { id: 'specific_concerns', name: 'specific_concerns', default_value: '', type: 'textarea', label: 'Specific SEO Concerns', placeholder: 'Describe any specific SEO issues or concerns you have', required: false }
                    ],
                    settings: { submit_button_text: 'Request SEO Consultation', success_message: 'Your SEO consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'content_writing') {
                formData = {
                    title: 'Content Writing Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: false },
                        { id: 'content_type', name: 'content_type', default_value: '', type: 'checkbox', label: 'Content Type Needed', options: [ { value: 'blog_posts', label: 'Blog Posts' }, { value: 'website_content', label: 'Website Content' }, { value: 'product_descriptions', label: 'Product Descriptions' }, { value: 'email_newsletters', label: 'Email Newsletters' }, { value: 'social_media_posts', label: 'Social Media Posts' }, { value: 'case_studies', label: 'Case Studies' }, { value: 'white_papers', label: 'White Papers' }, { value: 'press_releases', label: 'Press Releases' }, { value: 'brochures', label: 'Brochures' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select industry', label: 'Select industry'}, { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'education', label: 'Education' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'retail', label: 'Retail' }, { value: 'food_beverage', label: 'Food & Beverage' }, { value: '10', label: 'Fitness/Wellness' }, { value: 'consulting', label: 'Consulting' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience and their characteristics', required: true },
                        { id: 'content_tone', name: 'content_tone', default_value: '', type: 'select', label: 'Content Tone', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select tone', label: 'Select tone'}, { value: 'professional', label: 'Professional/Formal' }, { value: 'casual', label: 'Casual/Friendly' }, { value: 'conversational', label: 'Conversational' }, { value: 'technical', label: 'Technical/Expert' }, { value: 'creative', label: 'Creative/Engaging' }, { value: 'authoritative', label: 'Authoritative/Trustworthy' } ], required: true },
                        { id: 'word_count', name: 'word_count', default_value: '', type: 'select', label: 'Word Count Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select count', label: 'Select count'}, { value: 'under_500', label: 'Under 500 words' }, { value: '500_1000', label: '500 - 1,000 words' }, { value: '1000_2000', label: '1,000 - 2,000 words' }, { value: '2000_5000', label: '2,000 - 5,000 words' }, { value: 'over_5000', label: 'Over 5,000 words' } ], required: true },
                        { id: 'quantity', name: 'quantity', default_value: '', type: 'number', label: 'Number of Pieces', placeholder: 'Enter the number of content pieces needed', required: true },
                        { id: 'deadline', name: 'deadline', default_value: '', type: 'date', label: 'Deadline', placeholder: 'Select your deadline', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_100', label: 'Under $100' }, { value: '100_300', label: '$100 - $300' }, { value: '500_500', label: '$300 - $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: 'over_1000', label: 'Over $1,000' } ], required: true },
                        { id: 'content_topics', name: 'content_topics', default_value: '', type: 'textarea', label: 'Content Topics', placeholder: 'Describe the specific topics or themes you want covered', required: true },
                        { id: 'reference_materials', name: 'reference_materials', default_value: '', type: 'textarea', label: 'Reference Materials', placeholder: 'Any existing content, brand guidelines, or reference materials', required: false },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific requirements, keywords, or SEO considerations', required: false }
                    ],
                    settings: { submit_button_text: 'Request Content Writing Service', success_message: 'Your content writing service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'graphic_design') {
                formData = {
                    title: 'Graphic Design Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: false },
                        { id: 'design_type', name: 'design_type', default_value: '', type: 'checkbox', label: 'Design Type Needed', options: [ { value: 'logo', label: 'Logo Design' }, { value: 'business_cards', label: 'Business Cards' }, { value: 'brochures', label: 'Brochures' }, { value: 'flyers', label: 'Flyers' }, { value: 'posters', label: 'Posters' }, { value: 'banners', label: 'Banners' }, { value: 'social_media_graphics', label: 'Social Media Graphics' }, { value: 'website_graphics', label: 'Website Graphics' }, { value: 'packaging', label: 'Packaging Design' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select industry', label: 'Select industry'}, { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'education', label: 'Education' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'retail', label: 'Retail' }, { value: 'food_beverage', label: 'Food & Beverage' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'consulting', label: 'Consulting' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'design_style', name: 'design_style', default_value: '', type: 'select', label: 'Design Style Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select style', label: 'Select style'}, { value: 'modern', label: 'Modern/Minimalist' }, { value: 'classic', label: 'Classic/Traditional' }, { value: 'playful', label: 'Playful/Fun' }, { value: 'elegant', label: 'Elegant/Sophisticated' }, { value: 'bold', label: 'Bold/Dramatic' }, { value: 'vintage', label: 'Vintage/Retro' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'color_preferences', name: 'color_preferences', default_value: '', type: 'textarea', label: 'Color Preferences', placeholder: 'Describe your preferred colors or brand colors', required: false },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience', required: true },
                        { id: 'project_description', name: 'project_description', default_value: '', type: 'textarea', label: 'Project Description', placeholder: 'Describe what you need designed and any specific requirements', required: true },
                        { id: 'quantity', name: 'quantity', default_value: '', type: 'number', label: 'Quantity Needed', placeholder: 'Enter the quantity needed', required: true },
                        { id: 'deadline', name: 'deadline', default_value: '', type: 'date', label: 'Deadline', placeholder: 'Select your deadline', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_100', label: 'Under $100' }, { value: '100_300', label: '$100 - $300' }, { value: '300_500', label: '$300 - $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: 'over_1000', label: 'Over $1,000' } ], required: true },
                        { id: 'reference_examples', name: 'reference_examples', default_value: '', type: 'textarea', label: 'Reference Examples', placeholder: 'Provide examples of designs you like or similar work', required: false },
                        { id: 'brand_guidelines', name: 'brand_guidelines', default_value: '', type: 'textarea', label: 'Brand Guidelines', placeholder: 'Any existing brand guidelines or requirements', required: false },
                        { id: 'file_format', name: 'file_format', default_value: '', type: 'checkbox', label: 'File Format Needed', options: [ { value: 'jpg', label: 'JPG' }, { value: 'png', label: 'PNG' }, { value: 'pdf', label: 'PDF' }, { value: 'ai', label: 'Adobe Illustrator (AI)' }, { value: 'psd', label: 'Adobe Photoshop (PSD)' }, { value: 'svg', label: 'SVG' } ], required: false }
                    ],
                    settings: { submit_button_text: 'Request Graphic Design Service', success_message: 'Your graphic design service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'web_development') {
                formData = {
                    title: 'Web Development Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: false },
                        { id: 'project_type', name: 'project_type', default_value: '', type: 'select', label: 'Project Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'new_website', label: 'New Website' }, { value: 'website_redesign', label: 'Website Redesign' }, { value: 'ecommerce_website', label: 'E-commerce Website' }, { value: 'web_application', label: 'Web Application' }, { value: 'landing_page', label: 'Landing Page' }, { value: 'blog', label: 'Blog' }, { value: 'portfolio', label: 'Portfolio' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'ecommerce', label: 'E-commerce' }, { value: 'service_business', label: 'Service Business' }, { value: 'restaurant', label: 'Restaurant/Food' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'consulting', label: 'Consulting' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'website_pages', name: 'website_pages', default_value: '', type: 'checkbox', label: 'Website Pages Needed', options: [ { value: 'home', label: 'Home Page' }, { value: 'about', label: 'About Us' }, { value: 'services', label: 'Services' }, { value: 'products', label: 'Products' }, { value: 'contact', label: 'Contact' }, { value: 'blog', label: 'Blog' }, { value: 'portfolio', label: 'Portfolio' }, { value: 'testimonials', label: 'Testimonials' }, { value: 'faq', label: 'FAQ' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'features_needed', name: 'features_needed', default_value: '', type: 'checkbox', label: 'Features Needed', options: [ { value: 'contact_form', label: 'Contact Form' }, { value: 'newsletter_signup', label: 'Newsletter Signup' }, { value: 'blog_system', label: 'Blog System' }, { value: 'ecommerce_functionality', label: 'E-commerce Functionality' }, { value: 'user_registration', label: 'User Registration/Login' }, { value: 'payment_processing', label: 'Payment Processing' }, { value: 'booking_system', label: 'Booking System' }, { value: 'search_functionality', label: 'Search Functionality' }, { value: 'social_media_integration', label: 'Social Media Integration' }, { value: 'other', label: 'Other' } ], required: false },
                        { id: 'design_preference', name: 'design_preference', default_value: '', type: 'select', label: 'Design Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select preference', label: 'Select preference'}, { value: 'modern', label: 'Modern/Minimalist' }, { value: 'classic', label: 'Classic/Traditional' }, { value: 'creative', label: 'Creative/Unique' }, { value: 'professional', label: 'Professional/Corporate' }, { value: 'playful', label: 'Playful/Fun' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience', required: true },
                        { id: 'project_description', name: 'project_description', default_value: '', type: 'textarea', label: 'Project Description', placeholder: 'Describe your website project in detail', required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_1000', label: 'Under $1,000' }, { value: '1000_3000', label: '$1,000 - $3,000' }, { value: '3000_5000', label: '$3,000 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: 'over_10000', label: 'Over $10,000' } ], required: true },
                        { id: 'reference_websites', name: 'reference_websites', default_value: '', type: 'textarea', label: 'Reference Websites', placeholder: 'List websites you like or want to use as inspiration', required: false },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific technical requirements or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Request Web Development Service', success_message: 'Your web development service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'mobile_app') {
                formData = {
                    title: 'Mobile App Development Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: false },
                        { id: 'app_type', name: 'app_type', default_value: '', type: 'select', label: 'App Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'ios', label: 'iOS App' }, { value: 'android', label: 'Android App' }, { value: 'cross_platform', label: 'Cross-Platform App' }, { value: 'hybrid', label: 'Hybrid App' }, { value: 'progressive_web_app', label: 'Progressive Web App (PWA)' } ], required: true },
                        { id: 'app_category', name: 'app_category', default_value: '', type: 'select', label: 'App Category', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select category', label: 'Select category'}, { value: 'business', label: 'Business/Productivity' }, { value: 'ecommerce', label: 'E-commerce' }, { value: 'social_media', label: 'Social Media' }, { value: 'entertainment', label: 'Entertainment' }, { value: 'education', label: 'Education' }, { value: 'health_fitness', label: 'Health & Fitness' }, { value: 'food_delivery', label: 'Food Delivery' }, { value: 'travel', label: 'Travel' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'app_purpose', name: 'app_purpose', default_value: '', type: 'textarea', label: 'App Purpose', placeholder: 'Describe what your app will do and its main purpose', required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target users', required: true },
                        { id: 'key_features', name: 'key_features', default_value: '', type: 'textarea', label: 'Key Features', placeholder: 'List the main features your app needs', required: true },
                        { id: 'user_authentication', name: 'user_authentication', default_value: '', type: 'radio', label: 'User Authentication', options: [ { value: 'yes', label: 'Yes, users need to login' }, { value: 'no', label: 'No, app is open to all' }, { value: 'optional', label: 'Optional login' } ], required: true },
                        { id: 'payment_integration', name: 'payment_integration', default_value: '', type: 'radio', label: 'Payment Integration', options: [ { value: 'yes', label: 'Yes, in-app purchases or payments' }, { value: 'no', label: 'No payment needed' } ], required: true },
                        { id: 'push_notifications', name: 'push_notifications', default_value: '', type: 'radio', label: 'Push Notifications', options: [ { value: 'yes', label: 'Yes, for user engagement' }, { value: 'no', label: 'No notifications needed' } ], required: true },
                        { id: 'offline_functionality', name: 'offline_functionality', default_value: '', type: 'radio', label: 'Offline Functionality', options: [ { value: 'yes', label: 'Yes, app works offline' }, { value: 'no', label: 'No, requires internet' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_5000', label: 'Under $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: '10000_25000', label: '$10,000 - $25,000' }, { value: '25000_50000', label: '$25,000 - $50,000' }, { value: 'over_50000', label: 'Over $50,000' } ], required: true },
                        { id: 'reference_apps', name: 'reference_apps', default_value: '', type: 'textarea', label: 'Reference Apps', placeholder: 'List similar apps you like or want to use as inspiration', required: false },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific technical requirements or integrations', required: false }
                    ],
                    settings: { submit_button_text: 'Request Mobile App Development', success_message: 'Your mobile app development request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'ecommerce_setup') {
                formData = {
                    title: 'E-commerce Setup Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'retail', label: 'Retail Store' }, { value: 'wholesale', label: 'Wholesale' }, { value: 'dropshipping', label: 'Dropshipping' }, { value: 'subscription', label: 'Subscription Service' }, { value: 'digital_products', label: 'Digital Products' }, { value: 'services', label: 'Services' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'product_categories', name: 'product_categories', default_value: '', type: 'textarea', label: 'Product Categories', placeholder: 'List the main categories of products you sell', required: true },
                        { id: 'estimated_products', name: 'estimated_products', default_value: '', type: 'select', label: 'Estimated Number of Products', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select count', label: 'Select count'}, { value: 'under_50', label: 'Under 50 products' }, { value: '50_200', label: '50 - 200 products' }, { value: '200_500', label: '200 - 500 products' }, { value: '500_1000', label: '500 - 1,000 products' }, { value: 'over_1000', label: 'Over 1,000 products' } ], required: true },
                        { id: 'platform_preference', name: 'platform_preference', default_value: '', type: 'select', label: 'Platform Preference', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select platform', label: 'Select platform'}, { value: 'shopify', label: 'Shopify' }, { value: 'woocommerce', label: 'WooCommerce' }, { value: 'magento', label: 'Magento' }, { value: 'bigcommerce', label: 'BigCommerce' }, { value: 'custom', label: 'Custom Solution' }, { value: 'no_preference', label: 'No Preference' } ], required: true },
                        { id: 'payment_methods', name: 'payment_methods', default_value: '', type: 'checkbox', label: 'Payment Methods Needed', options: [ { value: 'credit_cards', label: 'Credit Cards' }, { value: 'paypal', label: 'PayPal' }, { value: 'apple_pay', label: 'Apple Pay' }, { value: 'google_pay', label: 'Google Pay' }, { value: 'bank_transfer', label: 'Bank Transfer' }, { value: 'cryptocurrency', label: 'Cryptocurrency' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'shipping_options', name: 'shipping_options', default_value: '', type: 'checkbox', label: 'Shipping Options Needed', options: [ { value: 'free_shipping', label: 'Free Shipping' }, { value: 'flat_rate', label: 'Flat Rate' }, { value: 'weight_based', label: 'Weight-Based' }, { value: 'real_time_calculator', label: 'Real-Time Calculator' }, { value: 'local_pickup', label: 'Local Pickup' }, { value: 'international', label: 'International Shipping' } ], required: true },
                        { id: 'inventory_management', name: 'inventory_management', default_value: '', type: 'radio', label: 'Inventory Management', options: [ { value: 'yes', label: 'Yes, track inventory levels' }, { value: 'no', label: 'No, unlimited stock' } ], required: true },
                        { id: 'customer_accounts', name: 'customer_accounts', default_value: '', type: 'radio', label: 'Customer Accounts', options: [ { value: 'yes', label: 'Yes, customers can create accounts' }, { value: 'no', label: 'No, guest checkout only' } ], required: true },
                        { id: 'marketing_features', name: 'marketing_features', default_value: '', type: 'checkbox', label: 'Marketing Features Needed', options: [ { value: 'email_marketing', label: 'Email Marketing' }, { value: 'loyalty_program', label: 'Loyalty Program' }, { value: 'coupons_discounts', label: 'Coupons & Discounts' }, { value: 'ab_testing', label: 'A/B Testing' }, { value: 'analytics', label: 'Analytics & Reporting' }, { value: 'seo', label: 'SEO Optimization' } ], required: false },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_2000', label: 'Under $2,000' }, { value: '2000_5000', label: '$2,000 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: '10000_25000', label: '$10,000 - $25,000' }, { value: 'over_25000', label: 'Over $25,000' } ], required: true },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific features or integrations you need', required: false }
                    ],
                    settings: { submit_button_text: 'Request E-commerce Setup', success_message: 'Your e-commerce setup request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'email_marketing') {
                formData = {
                    title: 'Email Marketing Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'ecommerce', label: 'E-commerce' }, { value: 'service_business', label: 'Service Business' }, { value: 'restaurant', label: 'Restaurant/Food' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'consulting', label: 'Consulting' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'current_email_list', name: 'current_email_list', default_value: '', type: 'select', label: 'Current Email List Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select size', label: 'Select size'}, { value: 'none', label: 'No list yet' }, { value: 'under_100', label: 'Under 100 subscribers' }, { value: '100_500', label: '100 - 500 subscribers' }, { value: '500_1000', label: '500 - 1,000 subscribers' }, { value: '1000_5000', label: '1,000 - 5,000 subscribers' }, { value: 'over_5000', label: 'Over 5,000 subscribers' } ], required: true },
                        { id: 'email_platform', name: 'email_platform', default_value: '', type: 'select', label: 'Current Email Platform', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select platform', label: 'Select platform'}, { value: 'none', label: 'No platform yet' }, { value: 'mailchimp', label: 'Mailchimp' }, { value: 'constant_contact', label: 'Constant Contact' }, { value: 'convertkit', label: 'ConvertKit' }, { value: 'active_campaign', label: 'ActiveCampaign' }, { value: 'klaviyo', label: 'Klaviyo' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'email_goals', name: 'email_goals', default_value: '', type: 'checkbox', label: 'Email Marketing Goals', options: [ { value: 'increase_sales', label: 'Increase Sales' }, { value: 'build_relationships', label: 'Build Customer Relationships' }, { value: 'drive_traffic', label: 'Drive Website Traffic' }, { value: 'promote_products', label: 'Promote Products/Services' }, { value: 'newsletter', label: 'Newsletter/Updates' }, { value: 'abandoned_cart', label: 'Abandoned Cart Recovery' }, { value: 'customer_retention', label: 'Customer Retention' }, { value: 'lead_generation', label: 'Lead Generation' } ], required: true },
                        { id: 'email_types', name: 'email_types', default_value: '', type: 'checkbox', label: 'Email Types Needed', options: [ { value: 'welcome_series', label: 'Welcome Series' }, { value: 'newsletter', label: 'Newsletter' }, { value: 'promotional', label: 'Promotional Emails' }, { value: 'abandoned_cart', label: 'Abandoned Cart' }, { value: 'product_launches', label: 'Product Launches' }, { value: 'seasonal_campaigns', label: 'Seasonal Campaigns' }, { value: 're_engagement', label: 'Re-engagement Campaigns' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience and their characteristics', required: true },
                        { id: 'email_frequency', name: 'email_frequency', default_value: '', type: 'select', label: 'Preferred Email Frequency', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select frequency', label: 'Select frequency'}, { value: 'weekly', label: 'Weekly' }, { value: 'bi_weekly', label: 'Bi-weekly' }, { value: 'monthly', label: 'Monthly' }, { value: 'quarterly', label: 'Quarterly' }, { value: 'as_needed', label: 'As Needed' } ], required: true },
                        { id: 'content_creation', name: 'content_creation', default_value: '', type: 'radio', label: 'Content Creation', options: [ { value: 'yes', label: 'Yes, create email content' }, { value: 'no', label: 'No, just strategy and setup' } ], required: true },
                        { id: 'design_templates', name: 'design_templates', default_value: '', type: 'radio', label: 'Design Templates', options: [ { value: 'yes', label: 'Yes, create custom templates' }, { value: 'no', label: 'No, use existing templates' } ], required: true },
                        { id: 'automation_setup', name: 'automation_setup', default_value: '', type: 'radio', label: 'Automation Setup', options: [ { value: 'yes', label: 'Yes, set up email automation' }, { value: 'no', label: 'No, manual sending only' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Monthly Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_500', label: 'Under $500' }, { value: '500_1000', label: '$500 - $1,000' }, { value: '1000_2000', label: '$1,000 - $2,000' }, { value: '2000_5000', label: '$2,000 - $5,000' }, { value: 'over_5000', label: 'Over $5,000' } ], required: true },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific requirements or integrations you need', required: false }
                    ],
                    settings: { submit_button_text: 'Request Email Marketing Service', success_message: 'Your email marketing service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'ppc_campaign') {
                formData = {
                    title: 'PPC Campaign Management Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'ecommerce', label: 'E-commerce' }, { value: 'service_business', label: 'Service Business' }, { value: 'restaurant', label: 'Restaurant/Food' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'consulting', label: 'Consulting' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'website_url', name: 'website_url', default_value: '', type: 'url', label: 'Website URL', placeholder: 'Enter your website URL', required: true },
                        { id: 'ppc_platforms', name: 'ppc_platforms', default_value: '', type: 'checkbox', label: 'PPC Platforms', options: [ { value: 'google_ads', label: 'Google Ads' }, { value: 'facebook_ads', label: 'Facebook Ads' }, { value: 'instagram_ads', label: 'Instagram Ads' }, { value: 'linkedin_ads', label: 'LinkedIn Ads' }, { value: 'bing_ads', label: 'Bing Ads' }, { value: 'tiktok_ads', label: 'TikTok Ads' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'campaign_goals', name: 'campaign_goals', default_value: '', type: 'checkbox', label: 'Campaign Goals', options: [ { value: 'increase_sales', label: 'Increase Sales' }, { value: 'generate_leads', label: 'Generate Leads' }, { value: 'increase_traffic', label: 'Increase Website Traffic' }, { value: 'brand_awareness', label: 'Brand Awareness' }, { value: 'product_launches', label: 'Product Launches' }, { value: 'local_promotion', label: 'Local Promotion' }, { value: 'app_installs', label: 'App Installs' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience and demographics', required: true },
                        { id: 'geographic_targeting', name: 'geographic_targeting', default_value: '', type: 'textarea', label: 'Geographic Targeting', placeholder: 'List target cities, states, or countries', required: true },
                        { id: 'keywords', name: 'keywords', default_value: '', type: 'textarea', label: 'Target Keywords', placeholder: 'List relevant keywords for your business', required: true },
                        { id: 'monthly_budget', name: 'monthly_budget', default_value: '', type: 'select', label: 'Monthly Ad Spend Budget', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_1000', label: 'Under $1,000' }, { value: '1000_2500', label: '$1,000 - $2,500' }, { value: '2500_5000', label: '$2,500 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: 'over_10000', label: 'Over $10,000' } ], required: true },
                        { id: 'campaign_duration', name: 'campaign_duration', default_value: '', type: 'select', label: 'Campaign Duration', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select duration', label: 'Select duration'}, { value: '1_month', label: '1 month' }, { value: '3_months', label: '3 months' }, { value: '6_months', label: '6 months' }, { value: 'ongoing', label: 'Ongoing' } ], required: true },
                        { id: 'current_ppc', name: 'current_ppc', default_value: '', type: 'radio', label: 'Current PPC Experience', options: [ { value: 'none', label: 'None - Starting from scratch' }, { value: 'basic', label: 'Basic - Some experience' }, { value: 'moderate', label: 'Moderate - Regular campaigns' }, { value: 'advanced', label: 'Advanced - Complex campaigns' } ], required: true },
                        { id: 'competitors', name: 'competitors', default_value: '', type: 'textarea', label: 'Main Competitors', placeholder: 'List 2-3 main competitors', required: false },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific requirements or goals', required: false }
                    ],
                    settings: { submit_button_text: 'Request PPC Campaign Management', success_message: 'Your PPC campaign management request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'brand_consultation') {
                formData = {
                    title: 'Brand Consultation Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'startup', label: 'Startup' }, { value: 'small_business', label: 'Small Business' }, { value: 'medium_business', label: 'Medium Business' }, { value: 'enterprise', label: 'Enterprise' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select industry', label: 'Select industry'}, { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'education', label: 'Education' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'retail', label: 'Retail' }, { value: 'food_beverage', label: 'Food & Beverage' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'consulting', label: 'Consulting' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'branding_needs', name: 'branding_needs', default_value: '', type: 'checkbox', label: 'Branding Needs', options: [ { value: 'brand_strategy', label: 'Brand Strategy' }, { value: 'brand_identity', label: 'Brand Identity' }, { value: 'logo_design', label: 'Logo Design' }, { value: 'brand_guidelines', label: 'Brand Guidelines' }, { value: 'messaging', label: 'Brand Messaging' }, { value: 'positioning', label: 'Brand Positioning' }, { value: 'rebranding', label: 'Rebranding' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_audience', name: 'target_audience', default_value: '', type: 'textarea', label: 'Target Audience', placeholder: 'Describe your target audience and their characteristics', required: true },
                        { id: 'brand_values', name: 'brand_values', default_value: '', type: 'textarea', label: 'Brand Values', placeholder: 'What values and principles does your brand represent?', required: true },
                        { id: 'brand_personality', name: 'brand_personality', default_value: '', type: 'select', label: 'Desired Brand Personality', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select personality', label: 'Select personality'}, { value: 'professional', label: 'Professional/Corporate' }, { value: 'friendly', label: 'Friendly/Approachable' }, { value: 'innovative', label: 'Innovative/Creative' }, { value: 'trustworthy', label: 'Trustworthy/Reliable' }, { value: 'luxury', label: 'Luxury/Premium' }, { value: 'playful', label: 'Playful/Fun' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'competitors', name: 'competitors', default_value: '', type: 'textarea', label: 'Main Competitors', placeholder: 'List 2-3 main competitors', required: true },
                        { id: 'current_brand', name: 'current_brand', default_value: '', type: 'radio', label: 'Current Brand Status', options: [ { value: 'new_brand', label: 'New brand - Starting from scratch' }, { value: 'existing_brand', label: 'Existing brand - Need improvement' }, { value: 'rebrand', label: 'Rebranding - Major change needed' } ], required: true },
                        { id: 'brand_goals', name: 'brand_goals', default_value: '', type: 'textarea', label: 'Brand Goals', placeholder: 'What do you want to achieve with your brand?', required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_1000', label: 'Under $1,000' }, { value: '1000_3000', label: '$1,000 - $3,000' }, { value: '3000_5000', label: '$3,000 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: 'over_10000', label: 'Over $10,000' } ], required: true },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific requirements or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Request Brand Consultation', success_message: 'Your brand consultation request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'market_research') {
                formData = {
                    title: 'Market Research Service Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'startup', label: 'Startup' }, { value: 'small_business', label: 'Small Business' }, { value: 'medium_business', label: 'Medium Business' }, { value: 'enterprise', label: 'Enterprise' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select industry', label: 'Select industry'}, { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'education', label: 'Education' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'retail', label: 'Retail' }, { value: 'food_beverage', label: 'Food & Beverage' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'consulting', label: 'Consulting' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'research_type', name: 'research_type', default_value: '', type: 'checkbox', label: 'Research Type Needed', options: [ { value: 'market_analysis', label: 'Market Analysis' }, { value: 'competitor_analysis', label: 'Competitor Analysis' }, { value: 'customer_research', label: 'Customer Research' }, { value: 'product_research', label: 'Product Research' }, { value: 'industry_trends', label: 'Industry Trends' }, { value: 'feasibility_study', label: 'Feasibility Study' }, { value: 'swot_analysis', label: 'SWOT Analysis' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'target_market', name: 'target_market', default_value: '', type: 'textarea', label: 'Target Market', placeholder: 'Describe your target market and demographics', required: true },
                        { id: 'geographic_scope', name: 'geographic_scope', default_value: '', type: 'select', label: 'Geographic Scope', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select scope', label: 'Select scope'}, { value: 'local', label: 'Local (City/Region)' }, { value: 'national', label: 'National' }, { value: 'international', label: 'International' }, { value: 'global', label: 'Global' } ], required: true },
                        { id: 'research_goals', name: 'research_goals', default_value: '', type: 'textarea', label: 'Research Goals', placeholder: 'What do you want to learn from this research?', required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_2000', label: 'Under $2,000' }, { value: '2000_5000', label: '$2,000 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: '10000_25000', label: '$10,000 - $25,000' }, { value: 'over_25000', label: 'Over $25,000' } ], required: true },
                        { id: 'deliverables', name: 'deliverables', default_value: '', type: 'checkbox', label: 'Deliverables Needed', options: [ { value: 'report', label: 'Written Report' }, { value: 'presentation', label: 'Presentation' }, { value: 'data_analysis', label: 'Data Analysis' }, { value: 'recommendations', label: 'Strategic Recommendations' }, { value: 'visuals', label: 'Charts & Visuals' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific requirements or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Request Market Research Service', success_message: 'Your market research service request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'business_plan') {
                formData = {
                    title: 'Business Plan Development Request',
                    fields: [
                        { id: 'client_name', name: 'client_name', default_value: '', type: 'text', label: 'Client Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company/Business Name', placeholder: 'Enter your company or business name', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select type', label: 'Select type'}, { value: 'startup', label: 'Startup' }, { value: 'small_business', label: 'Small Business' }, { value: 'medium_business', label: 'Medium Business' }, { value: 'enterprise', label: 'Enterprise' }, { value: 'nonprofit', label: 'Non-profit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select industry', label: 'Select industry'}, { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'education', label: 'Education' }, { value: 'real_estate', label: 'Real Estate' }, { value: 'retail', label: 'Retail' }, { value: 'food_beverage', label: 'Food & Beverage' }, { value: 'fitness', label: 'Fitness/Wellness' }, { value: 'consulting', label: 'Consulting' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'business_stage', name: 'business_stage', default_value: '', type: 'select', label: 'Business Stage', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select stage', label: 'Select stage'}, { value: 'idea', label: 'Just an Idea' }, { value: 'planning', label: 'Planning Phase' }, { value: 'startup', label: 'Startup' }, { value: 'operating', label: 'Operating Business' }, { value: 'expanding', label: 'Expanding Business' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'plan_purpose', name: 'plan_purpose', default_value: '', type: 'checkbox', label: 'Plan Purpose', options: [ { value: 'funding', label: 'Funding/Investment' }, { value: 'bank_loan', label: 'Bank Loan' }, { value: 'partnership', label: 'Partnership' }, { value: 'internal_planning', label: 'Internal Planning' }, { value: 'franchise', label: 'Franchise' }, { value: 'exit_strategy', label: 'Exit Strategy' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'business_concept', name: 'business_concept', default_value: '', type: 'textarea', label: 'Business Concept', placeholder: 'Describe your business idea or concept', required: true },
                        { id: 'target_market', name: 'target_market', default_value: '', type: 'textarea', label: 'Target Market', placeholder: 'Describe your target market and customers', required: true },
                        { id: 'competitive_advantage', name: 'competitive_advantage', default_value: '', type: 'textarea', label: 'Competitive Advantage', placeholder: 'What makes your business unique?', required: true },
                        { id: 'financial_projections', name: 'financial_projections', default_value: '', type: 'radio', label: 'Financial Projections Needed', options: [ { value: 'yes', label: 'Yes, include financial projections' }, { value: 'no', label: 'No, just business plan structure' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '1_month', label: '1 month' }, { value: '2_months', label: '2 months' }, { value: '3_months', label: '3 months' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select budget', label: 'Select budget'}, { value: 'under_1000', label: 'Under $1,000' }, { value: '1000_3000', label: '$1,000 - $3,000' }, { value: '3000_5000', label: '$3,000 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: 'over_10000', label: 'Over $10,000' } ], required: true },
                        { id: 'special_requirements', name: 'special_requirements', default_value: '', type: 'textarea', label: 'Special Requirements', placeholder: 'Any specific requirements or preferences', required: false }
                    ],
                    settings: { submit_button_text: 'Request Business Plan Development', success_message: 'Your business plan development request has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'franchise_inquiry') {
                formData = {
                    title: 'Franchise Inquiry Form',
                    fields: [
                        { id: 'applicant_name', name: 'applicant_name', default_value: '', type: 'text', label: 'Applicant Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'date_of_birth', name: 'date_of_birth', default_value: '', type: 'date', label: 'Date of Birth', placeholder: 'Select your date of birth', required: true },
                        { id: 'address', name: 'address', default_value: '', type: 'textarea', label: 'Address', placeholder: 'Enter your full address', required: true },
                        { id: 'city', name: 'city', default_value: '', type: 'text', label: 'City', placeholder: 'Enter your city', required: true },
                        { id: 'state', name: 'state', default_value: '', type: 'text', label: 'State/Province', placeholder: 'Enter your state or province', required: true },
                        { id: 'zip_code', name: 'zip_code', default_value: '', type: 'text', label: 'ZIP/Postal Code', placeholder: 'Enter your ZIP or postal code', required: true },
                        { id: 'country', name: 'country', default_value: '', type: 'text', label: 'Country', placeholder: 'Enter your country', required: true },
                        { id: 'franchise_interest', name: 'franchise_interest', default_value: '', type: 'select', label: 'Franchise Interest', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select interest', label: 'Select interest'}, { value: 'food_restaurant', label: 'Food & Restaurant' }, { value: 'retail', label: 'Retail' }, { value: 'health_fitness', label: 'Health & Fitness' }, { value: 'automotive', label: 'Automotive' }, { value: 'cleaning', label: 'Cleaning Services' }, { value: 'education', label: 'Education' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'investment_range', name: 'investment_range', default_value: '', type: 'select', label: 'Investment Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select range', label: 'Select range'}, { value: 'under_50k', label: 'Under $50,000' }, { value: '50k_100k', label: '$50,000 - $100,000' }, { value: '100k_250k', label: '$100,000 - $250,000' }, { value: '250k_500k', label: '$250,000 - $500,000' }, { value: 'over_500k', label: 'Over $500,000' } ], required: true },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Timeline to Start', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'Select timeline', label: 'Select timeline'}, { value: 'asap', label: 'ASAP' }, { value: '3_months', label: '3 months' }, { value: '6_months', label: '6 months' }, { value: '1_year', label: '1 year' }, { value: 'flexible', label: 'Flexible' } ], required: true },
                        { id: 'business_experience', name: 'business_experience', default_value: '', type: 'radio', label: 'Business Experience', options: [ { value: 'none', label: 'None' }, { value: 'some', label: 'Some experience' }, { value: 'extensive', label: 'Extensive experience' } ], required: true },
                        { id: 'franchise_experience', name: 'franchise_experience', default_value: '', type: 'radio', label: 'Franchise Experience', options: [ { value: 'none', label: 'None' }, { value: 'some', label: 'Some experience' }, { value: 'extensive', label: 'Extensive experience' } ], required: true },
                        { id: 'why_franchise', name: 'why_franchise', default_value: '', type: 'textarea', label: 'Why Franchising?', placeholder: 'Why are you interested in franchising?', required: true },
                        { id: 'additional_info', name: 'additional_info', default_value: '', type: 'textarea', label: 'Additional Information', placeholder: 'Any other information you would like to share', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Franchise Inquiry', success_message: 'Your franchise inquiry has been submitted!', submit_button_width: '100' }
                };
            } else if (template === 'real_estate') {
                formData = {
                    title: 'Real Estate Inquiry Form',
                    fields: [
                        { id: 'property_type', name: 'property_type', default_value: '', type: 'select', label: 'Property Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'house', label: 'House' }, { value: 'condo', label: 'Condo' }, { value: 'apartment', label: 'Apartment' }, { value: 'townhouse', label: 'Townhouse' }, { value: 'land', label: 'Land' }, { value: 'commercial', label: 'Commercial' } ], required: true },
                        { id: 'full_name', name: 'full_name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_200k', label: 'Under $200,000' }, { value: '200k_400k', label: '$200,000 - $400,000' }, { value: '400k_600k', label: '$400,000 - $600,000' }, { value: '600k_1m', label: '$600,000 - $1,000,000' }, { value: 'over_1m', label: 'Over $1,000,000' } ], required: true },
                        { id: 'location', name: 'location', default_value: '', type: 'text', label: 'Desired Location', placeholder: 'City, neighborhood, or area', required: true },
                        { id: 'bedrooms', name: 'bedrooms', default_value: '', type: 'select', label: 'Number of Bedrooms', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: '1', label: '1' }, { value: '2', label: '2' }, { value: '3', label: '3' }, { value: '4', label: '4' }, { value: '5+', label: '5+' } ], required: false },
                        { id: 'bathrooms', name: 'bathrooms', default_value: '', type: 'select', label: 'Number of Bathrooms', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: '1', label: '1' }, { value: '1.5', label: '1.5' }, { value: '2', label: '2' }, { value: '2.5', label: '2.5' }, { value: '3+', label: '3+' } ], required: false },
                        { id: 'timeline', name: 'timeline', default_value: '', type: 'select', label: 'Timeline to Buy', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'immediate', label: 'Immediate (0-3 months)' }, { value: '3_6_months', label: '3-6 months' }, { value: '6_12_months', label: '6-12 months' }, { value: 'over_1_year', label: 'Over 1 year' } ], required: true },
                        { id: 'additional_requirements', name: 'additional_requirements', default_value: '', type: 'textarea', label: 'Additional Requirements', placeholder: 'Any specific features or requirements?', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Real Estate Inquiry', success_message: 'Thank you for your real estate inquiry! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'travel_booking') {
                formData = {
                    title: 'Travel Booking Form',
                    fields: [
                        { id: 'trip_type', name: 'trip_type', default_value: '', type: 'select', label: 'Trip Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'leisure', label: 'Leisure/Vacation' }, { value: 'business', label: 'Business' }, { value: 'family', label: 'Family Trip' }, { value: 'romantic', label: 'Romantic Getaway' }, { value: 'adventure', label: 'Adventure' } ], required: true },
                        { id: 'full_name', name: 'full_name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'destination', name: 'destination', default_value: '', type: 'text', label: 'Destination', placeholder: 'Where would you like to go?', required: true },
                        { id: 'departure_date', name: 'departure_date', default_value: '', type: 'date', label: 'Departure Date', placeholder: 'Select departure date', required: true },
                        { id: 'return_date', name: 'return_date', default_value: '', type: 'date', label: 'Return Date', placeholder: 'Select return date', required: true },
                        { id: 'travelers', name: 'travelers', default_value: '', type: 'number', label: 'Number of Travelers', placeholder: 'How many people?', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_1k', label: 'Under $1,000' }, { value: '1000_3000', label: '$1,000 - $3,000' }, { value: '3000_5000', label: '$3,000 - $5,000' }, { value: '5000_10000', label: '$5,000 - $10,000' }, { value: 'over_10000', label: 'Over $10,000' } ], required: true },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any special requirements or preferences?', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Travel Request', success_message: 'Thank you for your travel request! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'restaurant_reservation') {
                formData = {
                    title: 'Restaurant Reservation Form',
                    fields: [
                        { id: 'full_name', name: 'full_name', default_value: '', type: 'text', label: 'Full Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'reservation_date', name: 'reservation_date', default_value: '', type: 'date', label: 'Reservation Date', placeholder: 'Select reservation date', required: true },
                        { id: 'reservation_time', name: 'reservation_time', default_value: '', type: 'time', label: 'Reservation Time', placeholder: 'Select reservation time', required: true },
                        { id: 'party_size', name: 'party_size', default_value: '', type: 'number', label: 'Party Size', placeholder: 'How many people?', required: true },
                        { id: 'occasion', name: 'occasion', default_value: '', type: 'select', label: 'Special Occasion', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'none', label: 'No special occasion' }, { value: 'birthday', label: 'Birthday' }, { value: 'anniversary', label: 'Anniversary' }, { value: 'business', label: 'Business' }, { value: 'date', label: 'Date' }, { value: 'other', label: 'Other' } ], required: false },
                        { id: 'special_requests', name: 'special_requests', default_value: '', type: 'textarea', label: 'Special Requests', placeholder: 'Any special dietary requirements or requests?', required: false }
                    ],
                    settings: { submit_button_text: 'Make Reservation', success_message: 'Your reservation request has been submitted! We\'ll confirm shortly.', submit_button_width: '100' }
                };
            } else if (template === 'pet_sitting') {
                formData = {
                    title: 'Pet Sitting Request Form',
                    fields: [
                        { id: 'owner_name', name: 'owner_name', default_value: '', type: 'text', label: 'Pet Owner Name', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'pet_name', name: 'pet_name', default_value: '', type: 'text', label: 'Pet Name', placeholder: 'Enter your pet\'s name', required: true },
                        { id: 'pet_type', name: 'pet_type', default_value: '', type: 'select', label: 'Pet Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'dog', label: 'Dog' }, { value: 'cat', label: 'Cat' }, { value: 'bird', label: 'Bird' }, { value: 'fish', label: 'Fish' }, { value: 'reptile', label: 'Reptile' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'pet_age', name: 'pet_age', default_value: '', type: 'number', label: 'Pet Age', placeholder: 'Age in years', required: false },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'Start Date', placeholder: 'When do you need pet sitting?', required: true },
                        { id: 'end_date', name: 'end_date', default_value: '', type: 'date', label: 'End Date', placeholder: 'When will you return?', required: true },
                        { id: 'services_needed', name: 'services_needed', default_value: '', type: 'checkbox', label: 'Services Needed', options: [ { value: 'feeding', label: 'Feeding' }, { value: 'walking', label: 'Walking' }, { value: 'playtime', label: 'Playtime' }, { value: 'medication', label: 'Medication' }, { value: 'grooming', label: 'Grooming' } ], required: true },
                        { id: 'special_instructions', name: 'special_instructions', default_value: '', type: 'textarea', label: 'Special Instructions', placeholder: 'Any special care instructions for your pet?', required: false }
                    ],
                    settings: { submit_button_text: 'Submit Pet Sitting Request', success_message: 'Your pet sitting request has been submitted! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'business_consulting') {
                formData = {
                    title: 'Business Consulting Request Form',
                    fields: [
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'industry', name: 'industry', default_value: '', type: 'select', label: 'Industry', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'technology', label: 'Technology' }, { value: 'healthcare', label: 'Healthcare' }, { value: 'finance', label: 'Finance' }, { value: 'retail', label: 'Retail' }, { value: 'manufacturing', label: 'Manufacturing' }, { value: 'education', label: 'Education' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'company_size', name: 'company_size', default_value: '', type: 'select', label: 'Company Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: '1_10', label: '1-10 employees' }, { value: '11_50', label: '11-50 employees' }, { value: '51_200', label: '51-200 employees' }, { value: '201_1000', label: '201-1000 employees' }, { value: 'over_1000', label: 'Over 1000 employees' } ], required: true },
                        { id: 'consulting_area', name: 'consulting_area', default_value: '', type: 'select', label: 'Consulting Area', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'strategy', label: 'Business Strategy' }, { value: 'operations', label: 'Operations' }, { value: 'marketing', label: 'Marketing' }, { value: 'finance', label: 'Finance' }, { value: 'hr', label: 'Human Resources' }, { value: 'technology', label: 'Technology' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'project_timeline', name: 'project_timeline', default_value: '', type: 'select', label: 'Project Timeline', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'immediate', label: 'Immediate (0-1 month)' }, { value: '1_3_months', label: '1-3 months' }, { value: '3_6_months', label: '3-6 months' }, { value: '6_12_months', label: '6-12 months' }, { value: 'over_1_year', label: 'Over 1 year' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_10k', label: 'Under $10,000' }, { value: '10k_25k', label: '$10,000 - $25,000' }, { value: '25k_50k', label: '$25,000 - $50,000' }, { value: '50k_100k', label: '$50,000 - $100,000' }, { value: 'over_100k', label: 'Over $100,000' } ], required: true },
                        { id: 'current_challenges', name: 'current_challenges', default_value: '', type: 'textarea', label: 'Current Challenges', placeholder: 'Describe the main challenges your business is facing', required: true },
                        { id: 'desired_outcomes', name: 'desired_outcomes', label: 'Desired Outcomes', placeholder: 'What outcomes do you hope to achieve?', required: true, type: 'textarea', default_value: '' }
                    ],
                    settings: { submit_button_text: 'Submit Consulting Request', success_message: 'Your business consulting request has been submitted! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'hr_consulting') {
                formData = {
                    title: 'HR Consulting Request Form',
                    fields: [
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_size', name: 'company_size', default_value: '', type: 'select', label: 'Company Size', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: '1_10', label: '1-10 employees' }, { value: '11_50', label: '11-50 employees' }, { value: '51_200', label: '51-200 employees' }, { value: '201_1000', label: '201-1000 employees' }, { value: 'over_1000', label: 'Over 1000 employees' } ], required: true },
                        { id: 'hr_services_needed', name: 'hr_services_needed', default_value: '', type: 'checkbox', label: 'HR Services Needed', options: [ { value: 'recruitment', label: 'Recruitment & Hiring' }, { value: 'employee_handbook', label: 'Employee Handbook' }, { value: 'performance_management', label: 'Performance Management' }, { value: 'compensation', label: 'Compensation & Benefits' }, { value: 'training', label: 'Training & Development' }, { value: 'compliance', label: 'HR Compliance' }, { value: 'employee_relations', label: 'Employee Relations' } ], required: true },
                        { id: 'urgency_level', name: 'urgency_level', default_value: '', type: 'select', label: 'Urgency Level', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'low', label: 'Low - Planning phase' }, { value: 'medium', label: 'Medium - Need within 3 months' }, { value: 'high', label: 'High - Need immediately' } ], required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_5k', label: 'Under $5,000' }, { value: '5k_15k', label: '$5,000 - $15,000' }, { value: '15k_30k', label: '$15,000 - $30,000' }, { value: '30k_50k', label: '$30,000 - $50,000' }, { value: 'over_50k', label: 'Over $50,000' } ], required: true },
                        { id: 'current_hr_issues', name: 'current_hr_issues', default_value: '', type: 'textarea', label: 'Current HR Issues', placeholder: 'Describe the HR challenges you\'re facing', required: true },
                        { id: 'additional_details', name: 'additional_details', default_value: '', type: 'textarea', label: 'Additional Details', placeholder: 'Any other information about your HR needs?', required: false }
                    ],
                    settings: { submit_button_text: 'Submit HR Consulting Request', success_message: 'Your HR consulting request has been submitted! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'accounting_service') {
                formData = {
                    title: 'Accounting Service Request Form',
                    fields: [
                        { id: 'business_name', name: 'business_name', default_value: '', type: 'text', label: 'Business Name', placeholder: 'Enter your business name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'sole_proprietorship', label: 'Sole Proprietorship' }, { value: 'partnership', label: 'Partnership' }, { value: 'llc', label: 'LLC' }, { value: 'corporation', label: 'Corporation' }, { value: 'nonprofit', label: 'Nonprofit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'accounting_services', name: 'accounting_services', default_value: '', type: 'checkbox', label: 'Accounting Services Needed', options: [ { value: 'bookkeeping', label: 'Bookkeeping' }, { value: 'tax_preparation', label: 'Tax Preparation' }, { value: 'financial_statements', label: 'Financial Statements' }, { value: 'payroll', label: 'Payroll Processing' }, { value: 'audit_preparation', label: 'Audit Preparation' }, { value: 'consulting', label: 'Financial Consulting' } ], required: true },
                        { id: 'frequency', name: 'frequency', default_value: '', type: 'select', label: 'Service Frequency', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'monthly', label: 'Monthly' }, { value: 'quarterly', label: 'Quarterly' }, { value: 'annually', label: 'Annually' }, { value: 'as_needed', label: 'As Needed' } ], required: true },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'When to Start', placeholder: 'When do you need services to begin?', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_500', label: 'Under $500/month' }, { value: '500_1000', label: '$500 - $1,000/month' }, { value: '1000_2000', label: '$1,000 - $2,000/month' }, { value: '2000_5000', label: '$2,000 - $5,000/month' }, { value: 'over_5000', label: 'Over $5,000/month' } ], required: true },
                        { id: 'current_accounting', name: 'current_accounting', default_value: '', type: 'textarea', label: 'Current Accounting Situation', placeholder: 'Describe your current accounting setup and challenges', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Accounting Service Request', success_message: 'Your accounting service request has been submitted! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'bookkeeping') {
                formData = {
                    title: 'Bookkeeping Service Request Form',
                    fields: [
                        { id: 'business_name', name: 'business_name', default_value: '', type: 'text', label: 'Business Name', placeholder: 'Enter your business name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'business_type', name: 'business_type', default_value: '', type: 'select', label: 'Business Type', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'sole_proprietorship', label: 'Sole Proprietorship' }, { value: 'partnership', label: 'Partnership' }, { value: 'llc', label: 'LLC' }, { value: 'corporation', label: 'Corporation' }, { value: 'nonprofit', label: 'Nonprofit' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'bookkeeping_services', name: 'bookkeeping_services', default_value: '', type: 'checkbox', label: 'Bookkeeping Services Needed', options: [ { value: 'data_entry', label: 'Data Entry' }, { value: 'bank_reconciliation', label: 'Bank Reconciliation' }, { value: 'accounts_payable', label: 'Accounts Payable' }, { value: 'accounts_receivable', label: 'Accounts Receivable' }, { value: 'payroll', label: 'Payroll Processing' }, { value: 'financial_reports', label: 'Financial Reports' }, { value: 'tax_preparation', label: 'Tax Preparation Support' } ], required: true },
                        { id: 'transaction_volume', name: 'transaction_volume', default_value: '', type: 'select', label: 'Monthly Transaction Volume', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_100', label: 'Under 100 transactions' }, { value: '100_500', label: '100-500 transactions' }, { value: '500_1000', label: '500-1,000 transactions' }, { value: '1000_5000', label: '1,000-5,000 transactions' }, { value: 'over_5000', label: 'Over 5,000 transactions' } ], required: true },
                        { id: 'software_preference', name: 'software_preference', default_value: '', type: 'select', label: 'Accounting Software', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'quickbooks', label: 'QuickBooks' }, { value: 'xero', label: 'Xero' }, { value: 'freshbooks', label: 'FreshBooks' }, { value: 'wave', label: 'Wave' }, { value: 'other', label: 'Other' }, { value: 'none', label: 'No preference' } ], required: false },
                        { id: 'frequency', name: 'frequency', default_value: '', type: 'select', label: 'Service Frequency', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'weekly', label: 'Weekly' }, { value: 'biweekly', label: 'Bi-weekly' }, { value: 'monthly', label: 'Monthly' }, { value: 'quarterly', label: 'Quarterly' }, { value: 'as_needed', label: 'As Needed' } ], required: true },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'When to Start', placeholder: 'When do you need services to begin?', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_300', label: 'Under $300/month' }, { value: '300_600', label: '$300 - $600/month' }, { value: '600_1000', label: '$600 - $1,000/month' }, { value: '1000_2000', label: '$1,000 - $2,000/month' }, { value: 'over_2000', label: 'Over $2,000/month' } ], required: true },
                        { id: 'current_bookkeeping', name: 'current_bookkeeping', default_value: '', type: 'textarea', label: 'Current Bookkeeping Situation', placeholder: 'Describe your current bookkeeping setup and challenges', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Bookkeeping Request', success_message: 'Your bookkeeping service request has been submitted! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else if (template === 'payroll_service') {
                formData = {
                    title: 'Payroll Service Request Form',
                    fields: [
                        { id: 'company_name', name: 'company_name', default_value: '', type: 'text', label: 'Company Name', placeholder: 'Enter your company name', required: true },
                        { id: 'contact_name', name: 'contact_name', default_value: '', type: 'text', label: 'Contact Person', placeholder: 'Enter your full name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email Address', placeholder: 'Enter your email address', required: true },
                        { id: 'phone', name: 'phone', default_value: '', type: 'number', label: 'Phone Number', placeholder: 'Enter your phone number', required: true },
                        { id: 'company_size', name: 'company_size', default_value: '', type: 'select', label: 'Number of Employees', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: '1_10', label: '1-10 employees' }, { value: '11_25', label: '11-25 employees' }, { value: '26_50', label: '26-50 employees' }, { value: '51_100', label: '51-100 employees' }, { value: 'over_100', label: 'Over 100 employees' } ], required: true },
                        { id: 'payroll_frequency', name: 'payroll_frequency', default_value: '', type: 'select', label: 'Current Payroll Frequency', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'weekly', label: 'Weekly' }, { value: 'biweekly', label: 'Bi-weekly' }, { value: 'semimonthly', label: 'Semi-monthly' }, { value: 'monthly', label: 'Monthly' }, { value: 'other', label: 'Other' } ], required: true },
                        { id: 'payroll_services', name: 'payroll_services', default_value: '', type: 'checkbox', label: 'Payroll Services Needed', options: [ { value: 'payroll_processing', label: 'Payroll Processing' }, { value: 'tax_filing', label: 'Tax Filing & Deposits' }, { value: 'w2_1099', label: 'W-2 & 1099 Forms' }, { value: 'direct_deposit', label: 'Direct Deposit' }, { value: 'payroll_reports', label: 'Payroll Reports' }, { value: 'garnishment', label: 'Garnishment Processing' }, { value: 'time_tracking', label: 'Time Tracking Integration' } ], required: true },
                        { id: 'software_integration', name: 'software_integration', default_value: '', type: 'select', label: 'Software Integration', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'quickbooks', label: 'QuickBooks' }, { value: 'xero', label: 'Xero' }, { value: 'adp', label: 'ADP' }, { value: 'paychex', label: 'Paychex' }, { value: 'other', label: 'Other' }, { value: 'none', label: 'No integration needed' } ], required: false },
                        { id: 'start_date', name: 'start_date', default_value: '', type: 'date', label: 'When to Start', placeholder: 'When do you need services to begin?', required: true },
                        { id: 'budget_range', name: 'budget_range', default_value: '', type: 'select', label: 'Budget Range', placeholder: getDefaultPlaceholderForType('select'), options: [ { value: 'under_100', label: 'Under $100/month' }, { value: '100_250', label: '$100 - $250/month' }, { value: '250_500', label: '$250 - $500/month' }, { value: '500_1000', label: '$500 - $1,000/month' }, { value: 'over_1000', label: 'Over $1,000/month' } ], required: true },
                        { id: 'current_payroll', name: 'current_payroll', default_value: '', type: 'textarea', label: 'Current Payroll Situation', placeholder: 'Describe your current payroll setup and challenges', required: true }
                    ],
                    settings: { submit_button_text: 'Submit Payroll Service Request', success_message: 'Your payroll service request has been submitted! We\'ll contact you soon.', submit_button_width: '100' }
                };
            } else {
                // Default template - create a basic contact form
                formData = {
                    title: 'Contact Form',
                    fields: [
                        { id: 'name', name: 'name', default_value: '', type: 'text', label: 'Name', placeholder: 'Enter your name', required: true },
                        { id: 'email', name: 'email', default_value: '', type: 'email', label: 'Email', placeholder: 'Enter your email', required: true },
                        { id: 'message', name: 'message', default_value: '', type: 'textarea', label: 'Message', placeholder: 'Enter your message', required: true }
                    ],
                    settings: { submit_button_text: 'Send Message', success_message: 'Thank you for contacting us!', submit_button_width: '100' }
                };
            }
            // Clear previous data
            if (typeof window.sfFieldsData !== 'undefined') {
                window.sfFieldsData = [];
            }
            if (typeof window.sfFormSettings !== 'undefined') {
                window.sfFormSettings = {};
            }
            // Load template into editor and go to step 2
            if (typeof updateFormEditor === 'function') {
                updateFormEditor(formData);
                // Immediately update the submit button text in the preview
                if (formData.settings && formData.settings.submit_button_text) {
                    $('#form-submit-button-text').val(formData.settings.submit_button_text);
                    $('#form-submit-button-width').val(formData.settings.submit_button_width);
                    if (window.sfFormSettings) {
                        window.sfFormSettings.submit_button_text = formData.settings.submit_button_text;
                        window.sfFormSettings.submit_button_width = formData.settings.submit_button_width;
                    }
                    // Re-render the preview to reflect the new button text
                    if (window.SF.VisualEditor && window.SF.VisualEditor.renderVisualFormPreview && window.sfFieldsData) {
                        window.SF.VisualEditor.renderVisualFormPreview(window.sfFieldsData);
                    }
                }
            }
            // Move to step 2
            $('.sf-wizard-step-content').removeClass('active');
            $('.sf-wizard-step-content[data-step="2"]').addClass('active');
            $('.sf-wizard-step').removeClass('active completed');
            $('.sf-wizard-step[data-step="2"]').addClass('active');
            $('.sf-wizard-step[data-step="1"]').addClass('completed');
        });
        
        // Function to reset form to empty state
        function resetFormToEmpty() {
            // Set flag if pre-built templates are visible (indicating API key missing or error)
            if ($('.sf-prebuilt-templates').is(':visible')) {
                window.sfCameFromPrebuiltTemplates = true;
            }
            
            // Hide AI input and examples, but DO NOT hide prebuilt templates
            $aiInputSection.hide();
            $aiExamplesSection.hide();
            // $prebuiltTemplates.hide(); // <-- Do not hide templates
            $fallbackMsg.hide();
            
            // Switch to step 2
            $('.sf-wizard-step-content').removeClass('active');
            $('.sf-wizard-step-content[data-step="2"]').addClass('active');
            $('.sf-wizard-step').removeClass('active completed');
            $('.sf-wizard-step[data-step="2"]').addClass('active');
            $('.sf-wizard-step[data-step="1"]').addClass('completed');

            // Reset form fields and settings
            $('#form-title').val('');
            $('#form-title-input').val('');
            
            // Reset form settings
            if (typeof window.sfFormSettings !== 'undefined') {
                window.sfFormSettings = {
                    submit_button_text: 'Submit',
                    submit_button_width: 'auto',
                    success_message: 'Thank you for your submission!',
                    override_email_settings: false,
                    email_subject: '',
                    email_message: '',
                    to_email: '',
                    cc_email: '',
                    bcc_email: '',
                    send_confirmation_email: false,
                    confirmation_subject: '',
                    confirmation_message: '',
                    enable_recaptcha: false,
                    store_submissions: true
                };
            }
            
            // Reset fields data
            window.sfFieldsData = [];
            
            // Reset visual form preview
            if (window.SF.VisualEditor && window.SF.VisualEditor.renderVisualFormPreview) {
                window.SF.VisualEditor.renderVisualFormPreview([]);
            }
            
            // Reset submit button
            $('.sf-edit-submit-button').html('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg> Submit').data('width', 'auto');
            $('.sf-preview-submit-button').css({
                'justify-content': 'flex-start',
                'width': 'auto'
            });
            
            // Update the "Continue to Configure" button state to disabled
            const $continueBtn = $('#sf-continue-to-configure-btn');
            const $updateBtn = $('#sf-save-form-step2');
            if ($continueBtn.length) {
                $continueBtn.prop('disabled', true).addClass('disabled');
            }
            if ($updateBtn.length) {
                $updateBtn.prop('disabled', true).addClass('disabled');
            }
            
            // Disable wizard steps that require fields
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="2"]').css('pointer-events', 'none');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="3"]').css('pointer-events', 'none');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="4"]').css('pointer-events', 'none');
            
            $resultMessage.hide();
        }

        // Attach reset logic to all existing Create Manually buttons
        $(document).off('click.sfManualCreate').on('click.sfManualCreate', '.sf-direct-manual-btn', function(e) {
            e.preventDefault();
            resetFormToEmpty();
        });
        
        // Handle "Click here for Pre-built Templates" button
        $generator.find('.sf-manual-create-btn').on('click', function(e) {
            e.preventDefault();
            $aiInputSection.hide();
            $aiExamplesSection.hide();
            $prebuiltTemplates.show();
        });
        
        // Helper function to show messages
        function showMessage(message, type = 'success') {
            $resultMessage.removeClass('success error').addClass(type);
            $resultMessage.html(message).show();
            
            if (type === 'success') {
                setTimeout(() => {
                    $resultMessage.fadeOut();
                }, 5000);
            }
        }
    }

    /**
     * Generate form structure from AI based on prompt
     * 
     * @param {string} prompt User prompt
     * @param {Function} callback Optional callback function
     */
    function generateFormFromPrompt(prompt, callback) {
        const $generator = $('.sf-ai-generator-wrapper');
        const $generateButton = $generator.find('.sf-ai-generate-button');
        const $resultMessage = $generator.find('.sf-ai-result-message');
        const $loadingState = $generator.find('.sf-ai-loading-state');
        const $mainCard = $generator.find('.sf-ai-generator-card');
        const $actions = $generator.find('.sf-ai-actions');
        
        // Show loading state
        $generateButton.prop('disabled', true);
        $generateButton.find('.sf-btn-text').text('Generating...');
        $generateButton.addClass('loading');
        $resultMessage.hide();
        $loadingState.show();
        $mainCard.css('opacity', '0.7');
        $mainCard.hide();
        $actions.css('opacity', '0.5');
        $actions.hide();
        
        // Call API
        $.ajax({
            url: sfAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_generate_form',
                nonce: sfAdmin.nonce,
            prompt: prompt
            },
            success: function(response) {
                if (response.success && response.data.form) {
                    // Log token usage if available
                    if (response.data.form.usage) {
                        console.log('=== AI Token Usage ===');
                        console.log('Prompt Tokens:', response.data.form.usage.prompt_tokens);
                        console.log('Completion Tokens:', response.data.form.usage.completion_tokens);
                        console.log('Total Tokens:', response.data.form.usage.total_tokens);
                        console.log('=====================');
                    }
                    
                    // Update form data in editor
                    updateFormEditor(response.data.form);
                    
                    // Show success message
                    showSuccessMessage('🎉 Your form has been generated successfully! You can now customize it further.');
                    
                    // Call callback if provided
                    if (typeof callback === 'function') {
                        callback(true);
                    }
                } else {
                    // Show error message with manual fallback options
                    showManualFallbackMessage('There is a problem with your API key. It may be invalid, unpaid, or fake. Please check your key and try again.' || (response.data?.message || ''));          
                    $generateButton.prop('disabled', true);
                    // Call callback if provided
                    if (typeof callback === 'function') {
                        callback(false);
                    }
                }
            },
            error: function(xhr, status, error) {
                
                // Show error message
                showErrorMessage('Something went wrong. Please check your connection and try again.');
                
                // Call callback if provided
                if (typeof callback === 'function') {
                    callback(false);
                }
            },
            complete: function() {
                // Remove loading state
                // $generateButton.prop('disabled', false);
                $generateButton.find('.sf-btn-text').text('Generate Form with AI');
                $generateButton.removeClass('loading');
                $loadingState.hide();
                $mainCard.css('opacity', '1');
                $mainCard.show();
                $actions.css('opacity', '1');
                $actions.show();
            }
        });
        
        // Helper functions for messages
        function showSuccessMessage(message) {
            $resultMessage.removeClass('error').addClass('success');
            $resultMessage.html(message).show();
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                $resultMessage.fadeOut();
            }, 5000);
        }
        
        function showErrorMessage(message) {
            $resultMessage.removeClass('success').addClass('error');
            $resultMessage.html(message).show();
        }

        // Add this helper function after showErrorMessage
        function showManualFallbackMessage(message) {
            $resultMessage.removeClass('success').addClass('error');
            $resultMessage.html(message).show();
        }
    }

    /**
     * Update summary values in the publish step
     */
    function updateSummaryValues() {
        // Update form name
        const formTitle = $('#form-title').val() || 'Untitled Form';
        $('#summary-form-title').text(formTitle);
        
        // Update field count - use sfFieldsData if available
        const fieldCount = window.sfFieldsData && Array.isArray(window.sfFieldsData) ? window.sfFieldsData.length : 0;
        $('#summary-field-count').text(fieldCount + ' fields');
    }

    /**
     * Get default placeholder text based on field type
     * 
     * @param {string} fieldType The type of field
     * @return {string} Default placeholder text
     */
    function getDefaultPlaceholderForType(fieldType) {
        const placeholders = {
            'text': 'Enter your text here',
            'email': 'Enter your email address',
            'phone': 'Enter your phone number',
            'number': 'Enter a number',
            'date': 'Select a date',
            'textarea': 'Enter your message here',
            'select': 'Select an option',
            'radio': '',
            'checkbox': '',
            'file': 'Choose a file'
        };
        
        return placeholders[fieldType] || 'Enter your text here';
    }

    /**
     * Update form editor with generated form data
     * 
     * @param {Object} formData Generated form data
     */
    function updateFormEditor(formData) {
        
        // Update form name
        if (formData.title) {
            $('#form-title').val(formData.title);
            // Also update the input field in step 3
            $('#form-title-input').val(formData.title);
            // Also update the preview elements in customize step
            $('#sf-preview-title').text(formData.title);
        }
        
        // Store in global settings for persistence
        if (!window.sfFormSettings) {
            window.sfFormSettings = {};
        }
        if (formData.title) {
            window.sfFormSettings.title = formData.title;
        }
        
        // Initialize sfFieldsData if it doesn't exist
        if (typeof window.sfFieldsData === 'undefined' || !Array.isArray(window.sfFieldsData)) {
            window.sfFieldsData = [];
        }
        
        // Clear existing fields
        window.sfFieldsData = [];
        
        // Process and add new fields to the visual editor
        if (formData.fields && formData.fields.length) {
            
            // Map the AI generated fields to our internal format
            formData.fields.forEach(function(field) {
                // Create a new field object with proper structure
                const newField = {
                    id: field.id || ('field_' + Date.now() + '_' + Math.floor(Math.random() * 10000)),
                    name: field.name || field.id,
                    default_value: field.default_value || '',
                    type: field.type || 'text',
                    label: field.label || 'Field',
                    placeholder: field.placeholder || getDefaultPlaceholderForType(field.type),
                    required: !!field.required,
                    column_width: field.column_width || '100',
                    show_label: field.show_label !== false, // Default to true if not specified
                    options: Array.isArray(field.options) ? field.options : []
                };
                
                // Add the field to our global array
                window.sfFieldsData.push(newField);
            });
            
            // Render the visual form preview with the new fields
            if (window.SF.VisualEditor && window.SF.VisualEditor.renderVisualFormPreview) {
                window.SF.VisualEditor.renderVisualFormPreview(window.sfFieldsData);
            }
            
            // Trigger fields updated event for button state update
            $(document).trigger('sf:fields_updated');
            
            // Show the next step button
            $('.sf-next-step').show();
            
            // Add click handler for the next step button
            $('.sf-next-step').off('click').on('click', function() {
                const targetStep = $(this).data('goto');
                if (targetStep === 2) {
                    $('.sf-progress-indicator').css('width', 33.33 + '%');
                } else if (targetStep === 3) {
                    $('.sf-progress-indicator').css('width', 66.67 + '%');
                    updateSummaryValues();
                } else if (targetStep === 4) {
                    $('.sf-progress-indicator').css('width', 100 + '%');
                }
                
                // Hide all steps
                $('.sf-wizard-step-content').removeClass('active');
                
                // Show target step
                $('.sf-wizard-step-content[data-step="' + targetStep + '"]').addClass('active');
                
                // Update progress
                $('.sf-wizard-step').removeClass('active completed');
                $('.sf-wizard-step[data-step="' + targetStep + '"]').addClass('active');
                
                // Mark previous steps as completed
                for (let i = 1; i < targetStep; i++) {
                    $('.sf-wizard-step[data-step="' + i + '"]').addClass('completed');
                }
                
                // Re-render the visual form preview in the customize step
                setTimeout(function() {
                    if (window.SF.VisualEditor && window.SF.VisualEditor.renderVisualFormPreview) {
                        window.SF.VisualEditor.renderVisualFormPreview(window.sfFieldsData);
                    }
                }, 100);
            });
        }
        
        // Update form settings
        if (formData.settings) {
            // New forms store submissions unless the generated settings say otherwise
            if (typeof formData.settings.store_submissions === 'undefined') {
                formData.settings.store_submissions = true;
            }
            updateFormSettings(formData.settings);
        }
    }

    /**
     * Update form settings fields
     * 
     * @param {Object} settings Form settings
     */
    function updateFormSettings(settings) {
        if (settings.success_message) {
            $('#form-success-message').val(settings.success_message);
        }
        
        if (settings.override_email_settings !== undefined) {
            $('#form-override-email-settings').prop('checked', settings.override_email_settings);
            $('.sf-custom-email-settings').toggle(settings.override_email_settings);
        }
        
        if (settings.email_subject) {
            $('#form-email-subject').val(settings.email_subject);
        }
        
        if (settings.email_message) {
            $('#form-email-message').val(settings.email_message);
        }
        
        if (settings.to_email) {
            $('#form-to-email').val(settings.to_email);
        }

        if (settings.cc_email) {
            $('#form-cc-email').val(settings.cc_email);
        }

        if (settings.bcc_email) {
            $('#form-bcc-email').val(settings.bcc_email);
        }
        
        if (settings.send_confirmation_email !== undefined) {
            $('#form-send-confirmation-email').prop('checked', settings.send_confirmation_email);
            $('.sf-confirmation-email-settings').toggle(settings.send_confirmation_email);
        }
        
        if (settings.confirmation_subject) {
            $('#form-confirmation-subject').val(settings.confirmation_subject);
        }
        
        if (settings.confirmation_message) {
            $('#form-confirmation-message').val(settings.confirmation_message);
        }
        
        if (settings.enable_recaptcha !== undefined) {
            $('#form-enable-recaptcha').prop('checked', settings.enable_recaptcha);
        }
        
        // Only set store_submissions if it's explicitly provided in settings
        if (settings.store_submissions !== undefined) {
            $('#form-store-submissions').prop('checked', settings.store_submissions);
        }
        
        if (settings.submit_button_text) {
            $('#form-submit-button-text').val(settings.submit_button_text);
        }
        
        // Sync settings with global object after updating
        if (window.SF.Utils && window.SF.Utils.syncFormSettings) {
            window.SF.Utils.syncFormSettings();
        }
    }

    // Expose functions to SF.AIGenerator namespace
    window.SF.AIGenerator = {
        init: initAIGenerator,
        generateFormFromPrompt: generateFormFromPrompt,
        updateFormEditor: updateFormEditor,
        updateFormSettings: updateFormSettings
    };

    // Note: Initialization is handled by admin.js to prevent duplicate initialization
    // Do not initialize here to avoid double event handlers

})(jQuery); 