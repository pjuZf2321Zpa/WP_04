(function ($, window) {
  "use strict";

  var apiFetch = window.wp && window.wp.apiFetch;
  var defaultBrand = (window.sfAdmin && window.sfAdmin.defaultBrandDisplayName) || "SigmaForms";
  var defaultLogo = (window.sfAdmin && window.sfAdmin.defaultBrandLogoUrl) || "";
  var recoveryUrlCache = "";
  var hasAccessToken = false;

  function getData() {
    return window.sfWhiteLabelData || {};
  }

  function showNotice(type, message) {
    var icons = { success: "yes", error: "dismiss", warning: "warning" };
    var $wrap = $(".sf-wl-notices");
    if (!$wrap.length) return;

    var $toast = $(
      '<div class="sf-wl-toast sf-wl-toast--' +
        type +
        '" role="status">' +
        '<span class="dashicons dashicons-' +
        (icons[type] || "info") +
        '"></span>' +
        "<span></span></div>"
    );
    $toast.find("span:last").text(message);
    $wrap.empty().append($toast);

    setTimeout(function () {
      $toast.fadeOut(300, function () {
        $(this).remove();
      });
    }, 7000);
  }

  function openMediaPicker(onSelect) {
    if (!window.wp || !window.wp.media) {
      showNotice("error", "WordPress media library is not available.");
      return;
    }
    var frame = window.wp.media({
      title: "Choose image",
      button: { text: "Use image" },
      library: { type: "image" },
      multiple: false,
    });
    frame.on("select", function () {
      var attachment = frame.state().get("selection").first();
      if (attachment) onSelect(attachment.toJSON());
    });
    frame.open();
  }

  function readForm($form) {
    return {
      enabled: $form.find('[name="enabled"]').is(":checked"),
      hide_license: $form.find('[name="hide_license"]').is(":checked"),
      hide_admin: $form.find('[name="hide_admin"]').is(":checked"),
      title: $form.find('[name="title"]').val() || "",
      icon: $form.find('[name="icon"]').val() || "",
      icon_id: parseInt($form.find('[name="icon_id"]').val(), 10) || 0,
      logo: $form.find('[name="logo"]').val() || "",
      logo_id: parseInt($form.find('[name="logo_id"]').val(), 10) || 0,
    };
  }

  function emptyPreviewHtml(type) {
    var icon = type === "logo" ? "format-image" : "admin-appearance";
    return '<span class="sf-wl-preview__empty"><span class="dashicons dashicons-' + icon + '"></span></span>';
  }

  function updatePreview($form, type, url) {
    var $preview = $form.find('.sf-wl-preview[data-type="' + type + '"]');
    if (url) {
      $preview.html('<img src="' + url + '" alt="" />');
    } else {
      $preview.html(emptyPreviewHtml(type));
    }
    updateLivePreview($form);
  }

  function syncFormSections($form) {
    var enabled = $form.find('[name="enabled"]').is(":checked");
    $form.find('[data-wl-section="branding"]').toggleClass("sf-wl-section--disabled", !enabled);
    $form.find(".sf-wl-mock").toggleClass("is-wl-disabled", !enabled);
  }

  function syncMasterToggleLabel($form) {
    var enabled = $form.find('[name="enabled"]').is(":checked");
    $form.find(".sf-wl-toggle-master .sf-wl-toggle-text").text(enabled ? "Enabled" : "Disabled");
  }

  function getPreviewBrand($form) {
    var enabled = $form.find('[name="enabled"]').is(":checked");
    var title = ($form.find('[name="title"]').val() || "").trim();
    if (!enabled) return defaultBrand;
    return title || defaultBrand;
  }

  function updateLivePreview($form) {
    var enabled = $form.find('[name="enabled"]').is(":checked");
    var brand = getPreviewBrand($form);
    var icon = enabled ? ($form.find('[name="icon"]').val() || "").trim() : "";
    var customLogo = enabled ? ($form.find('[name="logo"]').val() || "").trim() : "";
    var logo = customLogo || defaultLogo;
    var hideLicense = $form.find('[name="hide_license"]').is(":checked") && enabled;
    var hideSettingsMenu = $form.find('[name="hide_admin"]').is(":checked") && enabled;

    $("#sf-wl-preview-menu-label, #sf-wl-preview-page-title").text(brand);

    var $iconWrap = $("#sf-wl-preview-icon");
    if (icon) {
      $iconWrap.css("background-image", 'url("' + icon + '")');
      $iconWrap.find(".dashicons").hide();
    } else {
      $iconWrap.css("background-image", "");
      $iconWrap.find(".dashicons").show();
    }

    var $logoEl = $("#sf-wl-preview-logo");
    if (logo) {
      $logoEl.attr("src", logo).prop("hidden", false);
    } else {
      $logoEl.attr("src", "").prop("hidden", true);
    }

    $("#sf-wl-preview-license").toggleClass("sf-wl-mock__menu-item--hidden", hideLicense);
    $("#sf-wl-preview-settings, #sf-wl-preview-wl-menu").toggleClass("sf-wl-mock__menu-item--hidden", hideSettingsMenu);
  }

  function fillForm($form, data) {
    $form.find('[name="enabled"]').prop("checked", !!data.enabled);
    $form.find('[name="hide_license"]').prop("checked", !!data.hide_license);
    $form.find('[name="hide_admin"]').prop("checked", !!data.hide_admin);
    $form.find('[name="title"]').val(data.title || "");
    $form.find('[name="icon"]').val(data.icon || "");
    $form.find('[name="icon_id"]').val(data.icon_id || 0);
    $form.find('[name="logo"]').val(data.logo || "");
    $form.find('[name="logo_id"]').val(data.logo_id || 0);
    updatePreview($form, "icon", data.icon);
    updatePreview($form, "logo", data.logo);
    syncFormSections($form);
    syncMasterToggleLabel($form);
    updateLivePreview($form);
    syncRecoveryVisibility($form);
    syncRevokeButtonVisibility($form);
  }

  function setRecoveryUrl(url) {
    recoveryUrlCache = url || "";
    var $link = $(".sf-wl-localhost-preview").find(".sf-wl-recovery__link");
    if (recoveryUrlCache) {
      $link.attr("href", recoveryUrlCache).text(recoveryUrlCache);
    } else {
      $link.attr("href", "#").text("");
    }
  }

  function syncRecoveryVisibility($form) {
    var enabled = $form.find('[name="enabled"]').is(":checked");
    var hideWlMenu = $form.find('[name="hide_admin"]').is(":checked");
    var shouldShow = enabled && hideWlMenu && recoveryUrlCache !== "";
    $(".sf-wl-localhost-preview").toggle(shouldShow);
  }

  function setHasAccessToken(value) {
    hasAccessToken = !!value;
  }

  function syncRevokeButtonVisibility($form) {
    var enabled = $form.find('[name="enabled"]').is(":checked");
    var hideWlMenu = $form.find('[name="hide_admin"]').is(":checked");
    var shouldShow = enabled && hideWlMenu && hasAccessToken;
    var $btn = $form.find(".sf-wl-revoke-token");
    if (shouldShow) {
      $btn.removeAttr("hidden");
    } else {
      $btn.attr("hidden", "hidden");
    }
  }

  function loadSettings($form) {
    if (!apiFetch) return;
    $form.addClass("is-loading");
    apiFetch({ path: "/sigmaforms/v1/white-label" })
      .then(function (res) {
        if (res.localhost_preview && res.localhost_preview.access_url) {
          setRecoveryUrl(res.localhost_preview.access_url);
        } else {
          setRecoveryUrl("");
        }
        setHasAccessToken(res.has_access_token);
        fillForm($form, res);
      })
      .catch(function () {
        showNotice("error", "Failed to load white label settings.");
      })
      .finally(function () {
        $form.removeClass("is-loading");
      });
  }

  function saveSettings($form) {
    if (!apiFetch) return;
    var payload = readForm($form);
    var $btn = $form.find(".sf-wl-save");
    $btn.prop("disabled", true).addClass("loading");

    apiFetch({
      path: "/sigmaforms/v1/white-label",
      method: "POST",
      data: payload,
    })
      .then(function (res) {
        var wl = res.settings || payload;
        wl.enabled = wl.enabled ?? payload.enabled;
        wl.hide_license = wl.hide_license ?? payload.hide_license;
        wl.hide_admin = wl.hide_admin ?? payload.hide_admin;
        wl.title = wl.title ?? payload.title;
        wl.icon = wl.icon ?? payload.icon;
        wl.logo = wl.logo ?? payload.logo;

        if (getData().applyWhiteLabelPatch) {
          getData().applyWhiteLabelPatch(wl);
        }

        showNotice("success", res.message || "White label settings saved.");
        fillForm($form, wl);

        if (res.settings && res.settings.localhost_preview && res.settings.localhost_preview.access_url) {
          setRecoveryUrl(res.settings.localhost_preview.access_url);
        } else if (!payload.hide_admin || !payload.enabled) {
          setRecoveryUrl("");
        }
        if (res.settings) {
          setHasAccessToken(res.settings.has_access_token);
        }
        syncRecoveryVisibility($form);
        syncRevokeButtonVisibility($form);
        if (res.email_sent === false && payload.hide_admin && payload.enabled) {
          showNotice("warning", "Recovery email could not be sent. Check the recovery URL below.");
        }

        if (getData().updateBrandTitles && getData().getBrandDisplayName) {
          getData().updateBrandTitles(getData().getBrandDisplayName());
        }
      })
      .catch(function (err) {
        showNotice("error", (err && err.message) || "Save failed.");
      })
      .finally(function () {
        $btn.prop("disabled", false).removeClass("loading");
      });
  }

  function revokeToken($form) {
    if (!apiFetch) return;
    window.SF.confirm(window.SF.t('confirmRevokeToken', 'Revoke the active recovery token?'), { danger: true, confirmLabel: window.SF.t('revoke', 'Revoke') }).then(function (confirmed) {
      if (!confirmed) return;
      apiFetch({ path: "/sigmaforms/v1/white-label/revoke-token", method: "POST" })
        .then(function (res) {
          showNotice("success", res.message || "Token revoked.");
          setRecoveryUrl("");
          setHasAccessToken(false);
          syncRecoveryVisibility($form);
          syncRevokeButtonVisibility($form);
          loadSettings($form);
        })
        .catch(function (err) {
          showNotice("error", (err && err.message) || "Revoke failed.");
        });
    });
  }

  // Runs on the first load and after admin-nav.js swaps the page in; the flag
  // keeps a second pass from binding every handler twice.
  function bootWhiteLabelPage() {
    var $page = $(".sf-white-label-page");
    if (!$page.length) return;

    var $form = $page.find("#sf-white-label-form");
    if (!$form.length || $form.data("sfWlReady")) return;
    $form.data("sfWlReady", true);

    loadSettings($form);

    $form.on("submit", function (e) {
      e.preventDefault();
      saveSettings($form);
    });

    $form.on("click", ".sf-wl-pick", function () {
      var type = $(this).data("type");
      openMediaPicker(function (attachment) {
        var url = attachment.url || "";
        var id = attachment.id || 0;
        $form.find('[name="' + type + '"]').val(url);
        $form.find('[name="' + type + '_id"]').val(id);
        updatePreview($form, type, url);
      });
    });

    $form.on("click", ".sf-wl-remove", function () {
      var type = $(this).data("type");
      $form.find('[name="' + type + '"]').val("");
      $form.find('[name="' + type + '_id"]').val(0);
      updatePreview($form, type, "");
    });

    $form.on("click", ".sf-wl-revoke-token", function () {
      revokeToken($form);
    });

    $form.on("change", '[name="enabled"]', function () {
      syncFormSections($form);
      syncMasterToggleLabel($form);
      updateLivePreview($form);
      syncRecoveryVisibility($form);
      syncRevokeButtonVisibility($form);
    });

    $form.on("input", '[name="title"]', function () {
      if ($form.find('[name="enabled"]').is(":checked")) {
        updateLivePreview($form);
      }
    });

    $form.on("change", '[name="hide_license"], [name="hide_admin"]', function () {
      updateLivePreview($form);
      syncRecoveryVisibility($form);
      syncRevokeButtonVisibility($form);
    });

    $form.on("change", '[name="hide_admin"]', function () {
      if (!this.checked) return;
      var $checkbox = $(this);
      // Unchecked until confirmed, so a closed dialog leaves the menus visible.
      $checkbox.prop("checked", false);
      updateLivePreview($form);
      syncRecoveryVisibility($form);
      syncRevokeButtonVisibility($form);
      window.SF.confirm(window.SF.t('confirmHideMenus', 'Hide the Settings and White Label menus from wp-admin? A recovery link will be emailed so you can open them again.'), { confirmLabel: window.SF.t('hideMenus', 'Hide menus') }).then(function (confirmed) {
        if (!confirmed) return;
        $checkbox.prop("checked", true);
        updateLivePreview($form);
        syncRecoveryVisibility($form);
        syncRevokeButtonVisibility($form);
      });
    });

  }

  // Registered once, not per page visit.
  window.addEventListener("sigmaforms-white-label-changed", function () {
    if (getData().updateBrandTitles && getData().getBrandDisplayName) {
      getData().updateBrandTitles(getData().getBrandDisplayName());
    }
  });

  $(bootWhiteLabelPage);
  $(document).on("sf:page-load", bootWhiteLabelPage);
})(jQuery, window);
