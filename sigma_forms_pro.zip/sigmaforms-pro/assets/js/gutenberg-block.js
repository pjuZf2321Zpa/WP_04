/**
 * Gutenberg Block for SigmaForms
 */

(function (wp) {
    const { registerBlockType } = wp.blocks;
    const { SelectControl } = wp.components;
    const { InspectorControls } = wp.blockEditor || wp.editor;
    const { Fragment } = wp.element;
    const { __ } = wp.i18n;
    const { PanelBody, Placeholder, Spinner } = wp.components;
    const el = wp.element.createElement;

    // Try to get ServerSideRender from different possible locations
    const ServerSideRender = wp.serverSideRender || (wp.components && wp.components.ServerSideRender) || null;

    // Get data from localized script
    const { forms, blockName, i18n } = sigmaformsGutenberg;

    registerBlockType(blockName, {
        title: i18n.title,
        description: i18n.description,
        icon: 'feedback',
        category: 'widgets',
        keywords: ['form', 'contact', 'sigmaforms'],

        attributes: {
            formId: {
                type: 'string',
                default: '',
            },
            formTitle: {
                type: 'string',
                default: '',
            },
        },

        edit: function (props) {
            const { attributes, setAttributes } = props;
            const { formId } = attributes;

            // Handle form selection change
            const onChangeForm = function (newFormId) {
                // Find the selected form to get its title
                const selectedForm = forms.find(form => form.value === newFormId);
                const formTitle = selectedForm ? selectedForm.label : '';

                setAttributes({
                    formId: newFormId,
                    formTitle: formTitle
                });
            };

            // Prepare forms options
            const formOptions = [
                { label: i18n.formPlaceholder, value: '' },
                ...forms
            ];

            return el(
                Fragment,
                {},
                // Inspector Controls (Sidebar)
                el(
                    InspectorControls,
                    {},
                    el(
                        PanelBody,
                        {
                            title: i18n.title,
                            initialOpen: true,
                        },
                        el(SelectControl, {
                            label: i18n.selectForm,
                            value: formId,
                            options: formOptions,
                            onChange: onChangeForm,
                        })
                    )
                ),
                // Block Content (Editor View)
                formId && ServerSideRender
                    ? el(ServerSideRender, {
                        block: blockName,
                        attributes: attributes,
                    })
                    : formId && !ServerSideRender
                        ? el(
                            'div',
                            {
                                className: 'sigmaforms-block-preview',
                            },
                            el('div', {
                                className: 'sigmaforms-block-icon',
                            }, '📝'),
                            el('h3', {}, __('Form Preview', 'sigmaforms-pro')),
                            el('p', {}, attributes.formTitle || __('No form selected', 'sigmaforms-pro')),
                            el('p', {
                                className: 'description',
                                style: { fontSize: '12px', color: '#666', marginTop: '10px' }
                            }, __('The actual form will be displayed here on the frontend.', 'sigmaforms-pro'))
                        )
                        : el(
                            'div',
                            {
                                className: 'sigmaforms-block-placeholder',
                            },
                            el('div', {
                                className: 'sigmaforms-block-icon',
                            }, '📝'),
                            el('p', {}, i18n.noFormSelected),
                            el('p', { className: 'description' },
                                i18n.selectFormMessage
                            )
                        )
            );
        },

        save: function () {
            // Dynamic block - rendered on server side
            return null;
        },
    });
})(window.wp);
