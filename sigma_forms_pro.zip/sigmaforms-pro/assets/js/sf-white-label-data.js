(function (window) {
  "use strict";

  function getSfAdmin() {
    return window.sfAdmin || null;
  }

  function getBrandDisplayName() {
    var admin = getSfAdmin();
    if (admin && typeof admin.brandDisplayName === "string" && admin.brandDisplayName.trim()) {
      return admin.brandDisplayName.trim();
    }
    var boot = admin && admin.whiteLabelBoot;
    if (boot && boot.enabled && typeof boot.title === "string" && boot.title.trim()) {
      return boot.title.trim();
    }
    return (admin && admin.defaultBrandDisplayName) || "SigmaForms";
  }

  var WL_ICON_SYNC = "sf-wl-admin-menu-icon-sync";
  var WL_ICON_PHP = "sf-wl-admin-menu-icon-php";
  var WL_ICON_FOOTER = "sf-wl-admin-menu-icon-footer";
  var WL_HIDE_LICENSE_SYNC = "sf-wl-hide-license-submenu-sync";
  var WL_HIDE_LICENSE_PHP = "sf-wl-hide-license-submenu";
  var WL_HIDE_SETTINGS_SYNC = "sf-wl-hide-settings-submenu-sync";
  var WL_HIDE_SETTINGS_PHP = "sf-wl-hide-settings-submenu";
  var MENU_ROOT = "#adminmenu li.sf-admin-root-menu";
  var MENU_ICON = MENU_ROOT + " .wp-menu-image";
  var MENU_LINK = "#adminmenu a.toplevel_page_sigmaforms";

  function ensureMenuRootClass() {
    var anchor = document.querySelector(MENU_LINK);
    if (!anchor) return null;
    var li = anchor.closest("li");
    if (li && !li.classList.contains("sf-admin-root-menu")) {
      li.classList.add("sf-admin-root-menu");
    }
    return li;
  }

  function removeWlIconStyles() {
    [WL_ICON_PHP, WL_ICON_SYNC, WL_ICON_FOOTER].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.remove();
    });
  }

  function removeHideLicenseStyles() {
    [WL_HIDE_LICENSE_PHP, WL_HIDE_LICENSE_SYNC].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.remove();
    });
  }

  function removeHideSettingsMenuStyles() {
    [WL_HIDE_SETTINGS_PHP, WL_HIDE_SETTINGS_SYNC, "sf-wl-hide-wl-submenu", "sf-wl-hide-wl-submenu-sync"].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.remove();
    });
  }

  function getMenuIconWrap() {
    ensureMenuRootClass();
    return document.querySelector(MENU_ICON);
  }

  function hasCustomArtifacts() {
    if (document.getElementById(WL_ICON_PHP) || document.getElementById(WL_ICON_SYNC) || document.getElementById(WL_ICON_FOOTER)) {
      return true;
    }
    var wrap = getMenuIconWrap();
    if (!wrap) return false;
    return wrap.classList.contains("sf-wl-has-custom-icon") || !!wrap.style.backgroundImage || !!wrap.querySelector("img[style]");
  }

  function restoreDefaultMenuIcon() {
    removeWlIconStyles();
    var wrap = getMenuIconWrap();
    if (!wrap) return;
    wrap.removeAttribute("style");
    wrap.classList.remove("sf-wl-has-custom-icon");
    var img = wrap.querySelector("img");
    if (img) img.removeAttribute("style");
  }

  function buildMenuIconCssText(imageUrl) {
    var safe = imageUrl.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    return (
      "#adminmenu li.sf-admin-root-menu .wp-menu-image,#adminmenu .sf-admin-root-menu .wp-menu-image{position:relative!important;background-image:url(\"" +
      safe +
      "\")!important;background-size:20px 20px!important;background-repeat:no-repeat!important;background-position:center center!important;}" +
      "#adminmenu li.sf-admin-root-menu.current .wp-menu-image,#adminmenu li.sf-admin-root-menu.wp-has-current-submenu .wp-menu-image{background-image:url(\"" +
      safe +
      "\")!important;}" +
      "#adminmenu li.sf-admin-root-menu .wp-menu-image::before,#adminmenu li.sf-admin-root-menu .wp-menu-image::after{display:none!important;content:none!important;}" +
      "#adminmenu li.sf-admin-root-menu .wp-menu-image img{opacity:0!important;visibility:hidden!important;width:0!important;height:0!important;padding:0!important;margin:0!important;}" +
      ".folded #adminmenu li.sf-admin-root-menu .wp-menu-image{background-position:center center!important;}"
    );
  }

  function applyCustomMenuIcon(imageUrl) {
    removeWlIconStyles();
    var wrap = getMenuIconWrap();
    if (wrap) {
      wrap.classList.add("sf-wl-has-custom-icon");
      wrap.style.backgroundImage = 'url("' + imageUrl + '")';
      wrap.style.backgroundSize = "20px 20px";
      wrap.style.backgroundRepeat = "no-repeat";
      wrap.style.backgroundPosition = "center center";
      var img = wrap.querySelector("img");
      if (img) {
        img.style.opacity = "0";
        img.style.visibility = "hidden";
        img.style.width = "0";
        img.style.height = "0";
      }
    }
    var el = document.createElement("style");
    el.id = WL_ICON_SYNC;
    el.textContent = buildMenuIconCssText(imageUrl);
    document.head.appendChild(el);
  }

  function syncMenuIcon(imageUrl, forceRestore) {
    if (imageUrl) {
      applyCustomMenuIcon(imageUrl);
      return;
    }
    if (forceRestore || hasCustomArtifacts()) {
      restoreDefaultMenuIcon();
    }
  }

  function syncHideLicense(hide, isRecovery) {
    removeHideLicenseStyles();

    document.querySelectorAll('#adminmenu a[href*="page=sigmaforms_license"]').forEach(function (anchor) {
      var li = anchor.closest("li");
      if (li) li.style.display = hide && !isRecovery ? "none" : "";
    });

    if (!hide || isRecovery) return;

    var el = document.createElement("style");
    el.id = WL_HIDE_LICENSE_SYNC;
    el.textContent =
      '#adminmenu a[href*="page=sigmaforms_license"],' +
      '#adminmenu li.sf-admin-root-menu ul.wp-submenu li a[href*="page=sigmaforms_license"]{display:none!important;}';
    document.head.appendChild(el);
  }

  var SETTINGS_MENU_SELECTORS =
    '#adminmenu a[href*="page=sigmaforms-settings"],' +
    '#adminmenu a[href*="page=sigmaforms-white-label"],' +
    '#adminmenu li.sf-admin-root-menu ul.wp-submenu li a[href*="page=sigmaforms-settings"],' +
    '#adminmenu li.sf-admin-root-menu ul.wp-submenu li a[href*="page=sigmaforms-white-label"]';

  function shouldHideSettingsMenu(state, admin) {
    if (admin && (admin.hideSettingsMenu || admin.hideWhiteLabelMenu)) return true;
    return !!(state.enabled && state.hide_admin);
  }

  function syncHideSettingsMenu(hide, isRecovery) {
    removeHideSettingsMenuStyles();

    document.querySelectorAll('#adminmenu a[href*="page=sigmaforms-settings"], #adminmenu a[href*="page=sigmaforms-white-label"]').forEach(function (anchor) {
      var li = anchor.closest("li");
      if (li) li.style.display = hide && !isRecovery ? "none" : "";
    });

    document.querySelectorAll('#toplevel_page_sigmaforms .wp-submenu li.bdt-promo-menu-item').forEach(function (li) {
      li.style.display = hide && !isRecovery ? "none" : "";
    });

    if (!hide || isRecovery) return;

    var el = document.createElement("style");
    el.id = WL_HIDE_SETTINGS_SYNC;
    el.textContent = SETTINGS_MENU_SELECTORS +
      ",#toplevel_page_sigmaforms .wp-submenu li.bdt-promo-menu-item" +
      "{display:none!important;}";
    document.head.appendChild(el);
  }

  function applyTopLevelLabel(title) {
    ensureMenuRootClass();

    var root = document.querySelector(MENU_ROOT);
    if (root) {
      var top = root.querySelector("a.menu-top");
      if (top) {
        var label = top.querySelector(".wp-menu-name");
        if (label) label.textContent = title;
        top.setAttribute("aria-label", title);
      }
      root.querySelectorAll(".wp-submenu-head").forEach(function (head) {
        head.textContent = title;
      });
    }

    var fallback = document.querySelector(MENU_LINK);
    if (fallback) {
      var fallbackLabel = fallback.querySelector(".wp-menu-name");
      if (fallbackLabel) fallbackLabel.textContent = title;
      fallback.setAttribute("aria-label", title);
    }
  }

  function syncDocumentTitle(title, baseBrand) {
    if (!document.title || !title || !baseBrand) return;
    if (document.title.indexOf(baseBrand) !== -1) {
      document.title = document.title.split(baseBrand).join(title);
    }
  }

  function getBrandLogoUrl() {
    var admin = getSfAdmin();
    if (!admin) return "";
    if (admin.brandLogoUrl) return admin.brandLogoUrl;
    return admin.defaultBrandLogoUrl || "";
  }

  function syncBrandLogos() {
    var url = getBrandLogoUrl();
    document.querySelectorAll("[data-sf-brand-logo]").forEach(function (img) {
      if (url) {
        img.src = url;
        img.hidden = false;
      } else {
        img.removeAttribute("src");
        img.hidden = true;
      }
    });
  }

  function updateBrandTitles(name) {
    if (!name) return;
    document.querySelectorAll("[data-sf-brand-title]").forEach(function (el) {
      var template = el.getAttribute("data-sf-brand-title");
      if (!template) return;
      var text = template.replace(/%s/g, name);
      var titleEl = el.querySelector(".sf-admin-brand__title");
      if (titleEl) {
        titleEl.textContent = text;
      } else {
        el.textContent = text;
      }
    });
  }

  function normalizeWl(source) {
    if (!source || typeof source !== "object") return { enabled: false };
    return {
      enabled: !!source.enabled,
      hide_license: !!source.hide_license,
      hide_admin: !!source.hide_admin,
      title: typeof source.title === "string" ? source.title : "",
      icon: typeof source.icon === "string" ? source.icon : "",
      logo: typeof source.logo === "string" ? source.logo : "",
    };
  }

  function shouldHideLicense(state, admin) {
    if (admin && admin.hideLicenseNav) return true;
    return !!(state.enabled && state.hide_license);
  }

  function syncWhiteLabelMenu(wl, options) {
    options = options || {};
    if (typeof document === "undefined") return;

    var state = normalizeWl(wl);
    var admin = getSfAdmin();
    var base = (admin && admin.defaultBrandDisplayName) || "SigmaForms";
    var isRecovery = !!(admin && admin.whiteLabelRecovery);

    syncHideLicense(shouldHideLicense(state, admin), isRecovery);
    syncHideSettingsMenu(shouldHideSettingsMenu(state, admin), isRecovery);

    if (!state.enabled) {
      applyTopLevelLabel(base);
      syncDocumentTitle(base, base);
      updateBrandTitles(base);
      syncBrandLogos();
      syncMenuIcon("", true);
      return;
    }

    var title = state.title.trim() || base;
    applyTopLevelLabel(title);
    syncDocumentTitle(title, base);
    updateBrandTitles(title);
    syncBrandLogos();

    syncMenuIcon(state.icon.trim(), !!options.forceIconRestore);
  }

  function applyWhiteLabelPatch(wl) {
    if (!window.sfAdmin || !wl) return;

    var state = normalizeWl(wl);
    var base = window.sfAdmin.defaultBrandDisplayName || "SigmaForms";

    var defaultLogo = window.sfAdmin.defaultBrandLogoUrl || "";

    if (!state.enabled) {
      window.sfAdmin.brandDisplayName = base;
      window.sfAdmin.brandLogoUrl = defaultLogo;
      window.sfAdmin.hideLicenseNav = false;
      window.sfAdmin.hideSettingsMenu = false;
      window.sfAdmin.hideWhiteLabelMenu = false;
      window.sfAdmin.whiteLabelBoot = { enabled: false, hide_license: false, hide_admin: false, title: "", icon: "", logo: "" };
    } else {
      window.sfAdmin.brandDisplayName = state.title.trim() || base;
      window.sfAdmin.brandLogoUrl = state.logo.trim() || defaultLogo;
      window.sfAdmin.hideLicenseNav = !!state.hide_license;
      window.sfAdmin.hideSettingsMenu = !!state.hide_admin;
      window.sfAdmin.hideWhiteLabelMenu = !!state.hide_admin;
      window.sfAdmin.whiteLabelBoot = Object.assign({}, state);
    }

    syncWhiteLabelMenu(state, { forceIconRestore: true });
    syncBrandLogos();
    window.requestAnimationFrame(function () {
      syncWhiteLabelMenu(state, { forceIconRestore: true });
    });

    window.dispatchEvent(new CustomEvent("sigmaforms-white-label-changed"));
  }

  function bootWhiteLabelChrome() {
    var admin = getSfAdmin();
    if (!admin || !admin.whiteLabelBoot) return;

    var run = function () {
      syncWhiteLabelMenu(admin.whiteLabelBoot);
      window.requestAnimationFrame(function () {
        syncWhiteLabelMenu(admin.whiteLabelBoot);
      });
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", run, { once: true });
    } else {
      run();
    }
  }

  window.sfWhiteLabelData = {
    getBrandDisplayName: getBrandDisplayName,
    applyWhiteLabelPatch: applyWhiteLabelPatch,
    bootWhiteLabelChrome: bootWhiteLabelChrome,
    syncWhiteLabelMenu: syncWhiteLabelMenu,
    syncBrandLogos: syncBrandLogos,
    normalizeWl: normalizeWl,
    updateBrandTitles: updateBrandTitles,
  };
})(window);
