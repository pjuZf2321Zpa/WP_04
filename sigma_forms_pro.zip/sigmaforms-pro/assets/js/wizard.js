/**
 * SigmaForms - Wizard JavaScript
 */
(function($) {
    'use strict';

    // Initialize on document ready
    $(document).ready(function() {
        initWizard(); // Always initialize wizard and handlers

        // After handlers are set, check for reload-to-step flag
        var stepToGo = null;
        try {
            stepToGo = sessionStorage.getItem('sfGoToStep');
        } catch (err) {}
        if (stepToGo) {
            goToStep(parseInt(stepToGo, 10));
            try { sessionStorage.removeItem('sfGoToStep'); } catch (err) {}
        }
    });

    $('.sf-wizard-step-edit').on('click', function () {
        const step = $(this).data('step'); // dynamically get step value
        goToStep(step); // call your step function
    }); 

    /**
     * Initialize the form wizard
     */
    function initWizard() {
        // Determine if we're in edit mode
        const isEditMode = $('#form-id').val() !== '0';
        
        // Set starting step based on mode
        if (isEditMode) {
            // For edit mode, start at step 2 (Customize)
            updateWizardProgress(2);
        }

        $('.sf-prev-step').each(function() {
            $(this).on('click', function() {
                const prevStep = $(this).data('goto');
                
                // Special handling for back button in step 2
                if (prevStep === 1 && window.sfCameFromPrebuiltTemplates) {
                    // User came from pre-built templates due to API error, go back there
                    $('.sf-wizard-step-content').removeClass('active');
                    $('.sf-wizard-step-content[data-step="1"]').addClass('active');
                    $('.sf-wizard-step').removeClass('active completed');
                    $('.sf-wizard-step[data-step="1"]').addClass('active');
                    
                    // Show pre-built templates and hide AI input
                    $('.sf-ai-input-section').hide();
                    $('.sf-ai-examples-section').hide();
                    $('.sf-prebuilt-templates').show();
                    
                    // Update progress
                    updateWizardProgress(1);
                    
                    // Scroll to top
                    $('html, body').animate({
                        scrollTop: $('.sf-wizard-progress').offset().top - 50
                    }, 300);
                } else {
                    // Normal navigation
                    // Reset the flag if going to step 1 normally (not from pre-built templates)
                    if (prevStep === 1) {
                        window.sfCameFromPrebuiltTemplates = false;
                    }
                    goToStep(prevStep);
                }
            });
        });

        $('.sf-next-step').each(function() {
            $(this).on('click', function() {
                const nextStep = $(this).data('goto');
                
                // Special handling for "Create Form Manually" button when API key is missing
                if (nextStep === 2 && $(this).hasClass('sf-direct-manual-btn') && $('.sf-ai-generator-wrapper').hasClass('sf-no-api-key')) {
                    // User clicked "Create Form Manually" when API key is missing
                    window.sfCameFromPrebuiltTemplates = true;
                }
                
                goToStep(nextStep);
            });
        });

        // Settings tab navigation
        $('.sf-settings-tab-button').on('click', function() {
            const tab = $(this).data('tab');
            switchSettingsTab(tab);
        });

        // AI Examples toggle
        $('.sf-ai-examples-button').on('click', function() {
            $('.sf-ai-examples').slideToggle(200);
        });

        // Example prompt click
        $('.sf-ai-examples-list li').on('click', function() {
            const exampleText = $(this).text();
            $('.sf-ai-prompt-textarea').val(exampleText);
            $('.sf-ai-examples').slideUp(200);
        });

        // Generate button click - Only handle if the button is inside wizard context
        // Check if we're in wizard mode (has wizard-specific classes)
        if ($('.sf-wizard-container').length > 0) {
            $('.sf-ai-generate-button').off('click').on('click', function() {
                generateForm();
            });
        }

        // Update summary values in step 4
        updateSummaryValues();
        
        // Initialize the continue button state
        updateContinueButtonState();

        // Add event listeners for form field changes
        $('#form-title').on('input', function() {
            updateSummaryValues();
        });

        // Listen for field changes from the visual editor
        $(document).on('sf:field_added sf:field_removed sf:field_updated', function() {
            updateSummaryValues();
            updateContinueButtonState();
        });
        
        // Also listen for field changes from the AI generator
        $(document).on('sf:fields_updated', function() {
            updateContinueButtonState();
        });

        // Integrate with existing editor functionality
        integrateWithExistingEditor();
        
        // Initialize confirmation email toggle
        if (window.SF.Utils && window.SF.Utils.initConfirmationEmailToggle) {
            window.SF.Utils.initConfirmationEmailToggle();
        }
        
        // Initialize email override toggle
        if (window.SF.Utils && window.SF.Utils.initEmailOverrideToggle) {
            window.SF.Utils.initEmailOverrideToggle();
        }
        
        // Initialize form settings synchronization
        if (window.SF.Utils && window.SF.Utils.initFormSettingsSync) {
            window.SF.Utils.initFormSettingsSync();
        }
        
        // Initialize captcha selection functionality
        initCaptchaSelection();
        
        // Initialize security tab handling
        initSecurityTabHandling();
    }

    /**
     * Initialize captcha selection functionality
     */
    function initCaptchaSelection() {
        // Handle captcha type selection (checkboxes with radio button behavior)
        $('input[name="form_captcha_type"]').on('change', function(e) {
            const captchaType = $(this).val();
            const isChecked = $(this).is(':checked');
            const currentSelectedCaptcha = $('#form-captcha-type').val();
            
            if (isChecked) {
                // Uncheck all other checkboxes
                $('input[name="form_captcha_type"]').not(this).prop('checked', false);
                
                // Set the selected captcha
                $('#form-captcha-type').val(captchaType);
                
                // Update visual selection state
                $('.sf-captcha-selection .sf-field-row').removeClass('selected');
                $(this).closest('.sf-field-row').addClass('selected');
                
                // Force update the toggle slider visual state
                $('.sf-captcha-selection .sf-toggle-slider').removeClass('checked');
                $(this).siblings('.sf-toggle-slider').addClass('checked');
            } else {
                // If unchecking the currently selected captcha, clear the selection
                if (currentSelectedCaptcha === captchaType) {
                    $('#form-captcha-type').val('');
                    
                    // Remove visual selection state
                    $('.sf-captcha-selection .sf-field-row').removeClass('selected');
                    
                    // Force update the toggle slider visual state
                    $('.sf-captcha-selection .sf-toggle-slider').removeClass('checked');
                }
            }
            
            // Update form settings
            if (window.SF.Utils && window.SF.Utils.syncFormSettings) {
                window.SF.Utils.syncFormSettings();
            }
        });
        
        // Initialize captcha selection on page load
        const selectedCaptcha = $('#form-captcha-type').val();
        if (selectedCaptcha) {
            $(`#form-enable-${selectedCaptcha}`).closest('.sf-field-row').addClass('selected');
            $(`#form-enable-${selectedCaptcha}`).siblings('.sf-toggle-slider').addClass('checked');
        }
    }

    /**
     * Initialize security tab handling
     */
    function initSecurityTabHandling() {
        // Check if security tab is hidden (no captchas available)
        const $securityTabButton = $('.sf-settings-tab-button[data-tab="security"]');
        const $securityTabContent = $('.sf-settings-tab-content[data-tab="security"]');
        
        if ($securityTabButton.length === 0 || $securityTabContent.length === 0) {
            // Security tab is hidden, ensure we're not on it
            const $activeTabButton = $('.sf-settings-tab-button.active');
            const activeTab = $activeTabButton.data('tab');
            
            // If the active tab is security (which shouldn't happen, but just in case), switch to first available tab
            if (activeTab === 'security') {
                const $firstAvailableTab = $('.sf-settings-tab-button').first();
                if ($firstAvailableTab.length > 0) {
                    switchSettingsTab($firstAvailableTab.data('tab'));
                }
            }
        }
    }

    /**
     * Go to specific wizard step
     * 
     * @param {number} step Step number to navigate to
     */
    function goToStep(step) {
        // Reset the flag if going to step 1 normally (not from pre-built templates context)
        if (step === 1 && !window.sfCameFromPrebuiltTemplates) {
            window.sfCameFromPrebuiltTemplates = false;
        }
        
        // Hide all steps
        $('.sf-wizard-step-content').removeClass('active');
        
        // Show the target step
        $(`.sf-wizard-step-content[data-step="${step}"]`).addClass('active');
        
        // Update wizard progress
        updateWizardProgress(step);
        
        // Scroll to top
        $('html, body').animate({
            scrollTop: $('.sf-wizard-progress').offset().top - 50
        }, 300);
        
        // If going to step 4, update summary values
        if (step === 4) {
            updateSummaryValues();
        }
        
        // If going to step 2, update continue button state
        if (step === 2) {
            updateContinueButtonState();
        }
    }

    /**
     * Update wizard progress indicator
     * 
     * @param {number} currentStep Current step number
     */
    function updateWizardProgress(currentStep) {
        // Determine if we're in edit mode
        const isEditMode = $('#form-id').val() !== '0';
        
        // Update step indicators
        $('.sf-wizard-step').removeClass('active completed');
        
        // Mark current step as active
        $(`.sf-wizard-step[data-step="${currentStep}"]`).addClass('active');
        
        // Mark previous steps as completed
        for (let i = isEditMode ? 2 : 1; i < currentStep; i++) {
            $(`.sf-wizard-step[data-step="${i}"]`).addClass('completed');
        }
        
        // Update progress bar
        let progressPercentage;
        
        if (isEditMode) {
            // For edit mode (3 steps total)
            progressPercentage = ((currentStep - 2) / 2) * 100;
        } else {
            // For new form mode (4 steps total)
            progressPercentage = ((currentStep - 1) / 3) * 100;
        }
        
        $('.sf-progress-indicator').css('width', progressPercentage + '%');
    }

    /**
     * Switch between settings tabs in step 3
     * 
     * @param {string} tab Tab ID to switch to
     */
    function switchSettingsTab(tab) {
        // Check if the requested tab exists
        const $tabButton = $(`.sf-settings-tab-button[data-tab="${tab}"]`);
        const $tabContent = $(`.sf-settings-tab-content[data-tab="${tab}"]`);
        
        // If the requested tab doesn't exist, switch to the first available tab
        if ($tabButton.length === 0 || $tabContent.length === 0) {
            const $firstAvailableTab = $('.sf-settings-tab-button').first();
            if ($firstAvailableTab.length > 0) {
                tab = $firstAvailableTab.data('tab');
            }
        }
        
        // Update tab buttons
        $('.sf-settings-tab-button').removeClass('active');
        $(`.sf-settings-tab-button[data-tab="${tab}"]`).addClass('active');
        
        // Update tab content
        $('.sf-settings-tab-content').removeClass('active');
        $(`.sf-settings-tab-content[data-tab="${tab}"]`).addClass('active');
    }

    /**
     * Generate form from AI
     */
    function generateForm() {
        const prompt = $('.sf-ai-prompt-textarea').val().trim();
        
        if (!prompt) {
            $('.sf-ai-result-message').addClass('error').html('Please enter a form description.').fadeIn();
            return;
        }
        
        // Show loading state
        $('.sf-ai-generate-button').prop('disabled', true);
        $('.sf-loading-state').fadeIn();
        $('.sf-ai-result-message').removeClass('error').hide();
        
        // Call the existing AI generation function from the global SF namespace
        if (typeof window.SF.generateFormFromPrompt === 'function') {
            window.SF.generateFormFromPrompt(prompt, function(success) {
                // Hide loading state                
                if (success) {
                    // Hide step 1 immediately
                    // Automatically go to step 2
                    $(`.sf-settings-tab-content[data-step="1"]`).removeClass('active').empty();
                    goToStep(2);
                    setTimeout(function() {
                        $('.sf-loading-state').fadeOut();
                        $('.sf-ai-generate-button').prop('disabled', false);
                    }, 1500);

                    // Show success message and continue button
                    $('.sf-ai-result-message').html('Form generated successfully! You can now customize it.').fadeIn();
                    $('.sf-next-step[data-goto="2"]').fadeIn();
                    
                    // Automatically go to step 2 after a delay
                    // setTimeout(function() {
                    //     goToStep(2);
                    // }, 1500);
                }
            });
        } else {
            $('.sf-loading-state').fadeOut();
            $('.sf-ai-generate-button').prop('disabled', false);
            $('.sf-ai-result-message').addClass('error').html('Error: Could not generate form. Please try again.').fadeIn();
        }
    }

    /**
     * Update summary values in step 4
     */
    function updateSummaryValues() {
        // Update form name - check multiple sources
        let formTitle = $('#form-title').val() || 
                       $('#form-title-input').val() || 
                       (window.sfFormSettings && window.sfFormSettings.title) ||
                       'Untitled Form';
        $('#summary-form-title').text(formTitle);
        
        // Update field count - use sfFieldsData if available
        const fieldCount = window.sfFieldsData && Array.isArray(window.sfFieldsData) ? window.sfFieldsData.length : 0;
        $('#summary-field-count').text(fieldCount + ' fields');
        
        // Update the "Continue to Configure" button state
        updateContinueButtonState();
    }
    
    /**
     * Update the "Continue to Configure" button state based on field count
     */
    function updateContinueButtonState() {
        const $continueBtn = $('#sf-continue-to-configure-btn');
        const $updateBtn = $('#sf-save-form-step2');
        const fieldCount = window.sfFieldsData && Array.isArray(window.sfFieldsData) ? window.sfFieldsData.length : 0;
        
        if (fieldCount === 0) {
            // Disable button when no fields
            $continueBtn.prop('disabled', true).addClass('disabled');
            $updateBtn.prop('disabled', true).addClass('disabled');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="2"]').css('pointer-events', 'none');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="3"]').css('pointer-events', 'none');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="4"]').css('pointer-events', 'none');
            
        } else {
            // Enable button when there are fields
            $continueBtn.prop('disabled', false).removeClass('disabled');
            $updateBtn.prop('disabled', false).removeClass('disabled');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="2"]').css('pointer-events', 'auto');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="3"]').css('pointer-events', 'auto');
            $('.sf-wizard-step.sf-wizard-step-edit[data-step="4"]').css('pointer-events', 'auto');
        }
    }

    /**
     * Integrate wizard with existing editor functionality
     */
    function integrateWithExistingEditor() {
        // When a field is added or removed, update the summary
        $(document).on('sf:field_added sf:field_removed', function() {
            updateSummaryValues();
        });
        
        // When form name changes, update the summary
        $('#form-title, #form-title-input').on('input', function() {
            updateSummaryValues();
        });
        
        // When form settings are saved, update the summary
        $(document).on('sf:form_settings_saved', function() {
            updateSummaryValues();
        });
        
        // Override the save form button to show a loading state
        $('.sf-save-form').on('click', function() {
            const $button = $(this);
            const originalText = $button.html();
            
            // Get form name from multiple sources
            const formTitle = $('#form-title').val() || 
                             $('#form-title-input').val() || 
                             (window.sfFormSettings && window.sfFormSettings.title) ||
                             '';
            
            if (!formTitle.trim()) {
                window.SF.notify(window.SF.t('enterFormName', 'Please enter a form name.'));
                return;
            }
            
            // Get form field count from multiple sources
            const fieldCount = window.sfFieldsData && Array.isArray(window.sfFieldsData) ? window.sfFieldsData.length : 0;
            
            if (fieldCount === 0) {
                window.SF.notify(window.SF.t('addOneField', 'Please add at least one field to your form.'));
                return;
            }
            
            // Disable button and show loading state
            $button.prop('disabled', true);
            
            // Update button text based on whether it's publish or update
            if ($button.attr('id') === 'sf-save-form') {
                // Main publish/update button
                const isEdit = $('#form-id').val() !== '0';
                if (isEdit) {
                    $button.html('<svg class=\"sf-icon\" viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M21 12a9 9 0 0 1-9 9 9 9 0 0 1-7.5-4\"/><path d=\"M3 12a9 9 0 0 1 9-9 9 9 0 0 1 7.5 4\"/><path d=\"M19.5 3v4H15\"/><path d=\"M4.5 21v-4H9\"/></svg> Updating...');
                } else {
                    $button.html('<svg class=\"sf-icon\" viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M21 12a9 9 0 0 1-9 9 9 9 0 0 1-7.5-4\"/><path d=\"M3 12a9 9 0 0 1 9-9 9 9 0 0 1 7.5 4\"/><path d=\"M19.5 3v4H15\"/><path d=\"M4.5 21v-4H9\"/></svg> Publishing...');
                }
            } else {
                // Step-specific update buttons
                $button.html('<svg class=\"sf-icon\" viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M21 12a9 9 0 0 1-9 9 9 9 0 0 1-7.5-4\"/><path d=\"M3 12a9 9 0 0 1 9-9 9 9 0 0 1 7.5 4\"/><path d=\"M19.5 3v4H15\"/><path d=\"M4.5 21v-4H9\"/></svg> Updating...');
            }
            
            // Call the existing save function from the global SF namespace
            if (typeof window.SF.saveForm === 'function') {
                window.SF.saveForm();
            }

            // Handle AJAX success specifically for this button
            const $buttonInstance = $button;
            const isEditMode = $('#form-id').val() !== '0';
            
            $(document).one('ajaxSuccess', function(event, xhr, settings) {
                if (settings.url && settings.url.indexOf('admin-ajax.php') !== -1) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        // Check if the button has been marked as published (should not be re-enabled)
                        if ($buttonInstance.data('form-published')) {
                            return; // Don't re-enable if form is published
                        }
                        
                        // Only re-enable button for edit operations, not for new form publications
                        if (response.success && isEditMode) {
                            $buttonInstance.prop('disabled', false).html(originalText);
                        } else if (!response.success) {
                            // Re-enable button on error for both edit and new forms
                            $buttonInstance.prop('disabled', false).html(originalText);
                        }
                        // For successful new form publications, keep the button disabled
                        // The visual editor's saveForm function will handle this properly
                    } catch (e) {
                        // Re-enable button on parsing error only if not published
                        if (!$buttonInstance.data('form-published')) {
                            $buttonInstance.prop('disabled', false).html(originalText);
                        }
                    }
                }
            });
        });
    }

})(jQuery);
