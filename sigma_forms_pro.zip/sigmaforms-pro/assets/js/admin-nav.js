/**
 * Masthead nav.
 *
 * 1. Overflow: keeps the nav on a single row. Whatever does not fit is moved
 *    into a "More" dropdown, and moved back when the viewport grows again.
 * 2. In-page navigation: switching between SigmaForms screens fetches the
 *    target admin page and swaps the content under the masthead instead of
 *    reloading the whole page. The URL, tab title, admin menu highlight and
 *    browser history follow along, and anything unexpected falls back to a
 *    normal page load.
 */
(function () {
    'use strict';

    function init(nav) {
        var more = nav.querySelector('[data-sf-nav-more]');
        var toggle = nav.querySelector('[data-sf-nav-toggle]');
        var panel = nav.querySelector('[data-sf-nav-panel]');
        var items = Array.prototype.slice.call(nav.querySelectorAll('[data-sf-nav-item]'));

        if (!more || !toggle || !panel || !items.length) {
            return;
        }

        function closePanel() {
            more.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
            panel.hidden = true;
        }

        function openPanel() {
            more.classList.add('is-open');
            toggle.setAttribute('aria-expanded', 'true');
            panel.hidden = false;
        }

        function layout() {
            closePanel();

            // Start from everything on the row so the measurements are the
            // items' natural widths.
            items.forEach(function (item) {
                if (item.parentNode !== nav) {
                    nav.insertBefore(item, more);
                }
            });
            more.hidden = true;
            more.classList.remove('is-current');

            var styles = window.getComputedStyle(nav);
            var gap = parseFloat(styles.columnGap) || parseFloat(styles.gap) || 0;
            var available = nav.clientWidth
                - (parseFloat(styles.paddingLeft) || 0)
                - (parseFloat(styles.paddingRight) || 0);

            var widths = items.map(function (item) {
                return item.getBoundingClientRect().width;
            });

            var total = widths.reduce(function (sum, width, index) {
                return sum + width + (index ? gap : 0);
            }, 0);

            // A pixel of slack, so sub-pixel rounding does not collapse an
            // item that actually fits.
            if (total <= available + 1) {
                return;
            }

            more.hidden = false;

            var reserved = more.getBoundingClientRect().width + gap;
            var used = 0;
            var overflow = [];

            items.forEach(function (item, index) {
                used += widths[index] + (index ? gap : 0);

                if (used + reserved > available) {
                    overflow.push(item);
                }
            });

            if (!overflow.length) {
                more.hidden = true;
                return;
            }

            overflow.forEach(function (item) {
                panel.appendChild(item);

                if (item.classList.contains('is-current')) {
                    more.classList.add('is-current');
                }
            });
        }

        toggle.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();

            if (panel.hidden) {
                openPanel();
            } else {
                closePanel();
            }
        });

        document.addEventListener('click', function (event) {
            if (!panel.hidden && !more.contains(event.target)) {
                closePanel();
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !panel.hidden) {
                closePanel();
                toggle.focus();
            }
        });

        var frame = null;

        function schedule() {
            if (frame) {
                window.cancelAnimationFrame(frame);
            }

            frame = window.requestAnimationFrame(function () {
                frame = null;
                layout();
            });
        }

        if (window.ResizeObserver) {
            new window.ResizeObserver(schedule).observe(nav);
        } else {
            window.addEventListener('resize', schedule);
        }

        // Lets in-page navigation re-run the layout after the current item
        // changes, so "More" is highlighted when it holds that item.
        nav.sfRelayout = schedule;

        layout();
        nav.classList.add('is-ready');
    }

    /* In-page navigation ------------------------------------------------ */

    // Screens that can be swapped in without a reload. The form editor
    // (sigmaforms-new) keeps a lot of state and always loads normally, both
    // when opening it and when leaving it.
    var SOFT_PAGES = [
        'sigmaforms',
        'sigmaforms-submissions',
        'sigmaforms-abandoned',
        'sigmaforms-analytics',
        'sigmaforms-settings',
        'sigmaforms-white-label',
        'sigmaforms_license'
    ];

    var JS_TYPES = ['', 'text/javascript', 'application/javascript', 'module'];
    var STYLE_TIMEOUT = 4000;

    var strings = window.sfAdminNav || {};
    var displayedUrl = window.location.href;
    var requestId = 0;
    var controller = null;
    var dirty = false;

    function pageOf(url) {
        var parsed;

        try {
            parsed = new URL(url, window.location.href);
        } catch (e) {
            return null;
        }

        if (parsed.origin !== window.location.origin || !/\/wp-admin\/admin\.php$/.test(parsed.pathname)) {
            return null;
        }

        return parsed.searchParams.get('page');
    }

    function isSoftPage(url) {
        return SOFT_PAGES.indexOf(pageOf(url)) !== -1;
    }

    function supported() {
        return !!(window.fetch && window.DOMParser && window.Promise && window.history && window.history.pushState);
    }

    function canSoftNavigate(url) {
        return supported()
            && !!document.getElementById('wpbody-content')
            && isSoftPage(displayedUrl)
            && isSoftPage(url);
    }

    function isJs(script) {
        return JS_TYPES.indexOf((script.getAttribute('type') || '').toLowerCase()) !== -1;
    }

    function copyAttributes(from, to) {
        Array.prototype.slice.call(from.attributes).forEach(function (attr) {
            to.setAttribute(attr.name, attr.value);
        });
    }

    function setLoading(on) {
        document.documentElement.classList.toggle('sf-is-navigating', on);

        var body = document.getElementById('wpbody-content');

        if (body) {
            body.setAttribute('aria-busy', on ? 'true' : 'false');
        }
    }

    // Stylesheets the new page needs that this one has not loaded yet. The
    // swap waits for them so the new content never renders unstyled.
    function loadStyles(doc, baseUrl) {
        var pending = [];

        Array.prototype.slice.call(doc.querySelectorAll('link[rel="stylesheet"][href]')).forEach(function (link) {
            var href = new URL(link.getAttribute('href'), baseUrl).href;
            var exists = link.id
                ? document.getElementById(link.id)
                : Array.prototype.slice.call(document.querySelectorAll('link[rel="stylesheet"]')).some(function (el) {
                    return el.href === href;
                });

            if (exists) {
                return;
            }

            var el = document.createElement('link');
            copyAttributes(link, el);
            el.href = href;

            pending.push(new Promise(function (resolve) {
                el.onload = resolve;
                el.onerror = resolve;
                window.setTimeout(resolve, STYLE_TIMEOUT);
            }));

            document.head.appendChild(el);
        });

        // Inline CSS added with wp_add_inline_style().
        Array.prototype.slice.call(doc.querySelectorAll('head style[id]')).forEach(function (style) {
            var existing = document.getElementById(style.id);

            if (existing) {
                if (existing.textContent !== style.textContent) {
                    existing.textContent = style.textContent;
                }
                return;
            }

            var el = document.createElement('style');
            copyAttributes(style, el);
            el.textContent = style.textContent;
            document.head.appendChild(el);
        });

        return Promise.all(pending);
    }

    function runScript(source, parent, before) {
        return new Promise(function (resolve) {
            var el = document.createElement('script');
            copyAttributes(source, el);

            if (source.src) {
                el.async = false;
                el.onload = resolve;
                el.onerror = resolve;
            } else {
                el.textContent = source.textContent;
            }

            parent.insertBefore(el, before || null);

            if (!source.src) {
                resolve();
            }
        });
    }

    // Scripts outside the page content: new handles are loaded in order,
    // together with their localized data and inline before/after code.
    // Localized data that changed between pages is refreshed.
    function loadScripts(doc, baseUrl) {
        var newBody = doc.getElementById('wpbody-content');
        var scripts = Array.prototype.slice.call(doc.querySelectorAll('script')).filter(function (script) {
            return !newBody.contains(script);
        });

        return scripts.reduce(function (chain, script) {
            return chain.then(function () {
                var id = script.id;
                var src = script.getAttribute('src');
                var existing = id ? document.getElementById(id) : null;

                // Templates such as the media modal's tmpl-* blocks.
                if (!isJs(script)) {
                    if (id && !existing) {
                        document.body.appendChild(document.importNode(script, true));
                    }
                    return null;
                }

                if (src) {
                    var href = new URL(src, baseUrl).href;
                    var loaded = existing || Array.prototype.slice.call(document.scripts).some(function (el) {
                        return el.src === href;
                    });

                    if (loaded) {
                        return null;
                    }

                    var copy = script.cloneNode(false);
                    copy.setAttribute('src', href);
                    return runScript(copy, document.body);
                }

                // Inline code without an id cannot be matched against this page,
                // so it is never run twice.
                if (!id) {
                    return null;
                }

                if (existing) {
                    if (/-js-extra$/.test(id) && existing.textContent !== script.textContent) {
                        existing.parentNode.removeChild(existing);
                        return runScript(script, document.body);
                    }
                    return null;
                }

                return runScript(script, document.body);
            });
        }, Promise.resolve());
    }

    // Inline <script> blocks inside the page markup. Scripts parsed by
    // DOMParser never run on their own, so each one is recreated.
    function activateInlineScripts(body) {
        Array.prototype.slice.call(body.querySelectorAll('script')).forEach(function (script) {
            if (isJs(script) && !script.src && !script.closest('#screen-meta')) {
                var el = document.createElement('script');
                copyAttributes(script, el);
                el.textContent = script.textContent;
                script.parentNode.replaceChild(el, script);
            }
        });
    }

    function destroyCharts() {
        if (window.Chart && window.Chart.instances) {
            Object.keys(window.Chart.instances).forEach(function (key) {
                var chart = window.Chart.instances[key];

                if (chart && chart.destroy) {
                    chart.destroy();
                }
            });
        }
    }

    function syncBodyClasses(doc) {
        // WordPress adds a class per admin page (toplevel_page_*, *_page_*).
        var isPageClass = function (name) {
            return /_page_/.test(name);
        };
        var kept = document.body.className.split(/\s+/).filter(function (name) {
            return name && !isPageClass(name);
        });
        var added = doc.body.className.split(/\s+/).filter(isPageClass);

        document.body.className = kept.concat(added).join(' ');
    }

    function syncWpGlobals(html) {
        ['pagenow', 'adminpage'].forEach(function (name) {
            var match = html.match(new RegExp('\\b' + name + "\\s*=\\s*'([^']*)'"));

            if (match) {
                window[name] = match[1];
            }
        });
    }

    function syncAdminMenu(url) {
        var target = pageOf(url);
        var menu = document.querySelector('#adminmenu #toplevel_page_sigmaforms .wp-submenu');

        if (!menu) {
            return;
        }

        Array.prototype.slice.call(menu.querySelectorAll('li')).forEach(function (li) {
            var link = li.querySelector('a');
            var current = !!link && pageOf(link.href) === target;

            li.classList.toggle('current', current);

            if (link) {
                link.classList.toggle('current', current);

                if (current) {
                    link.setAttribute('aria-current', 'page');
                } else {
                    link.removeAttribute('aria-current');
                }
            }
        });
    }

    // Keep the live masthead (its listeners and resize observer) and only
    // update what can differ between pages.
    function syncMasthead(liveMasthead, newMasthead) {
        var newCurrent = newMasthead.querySelector('[data-sf-nav-item].is-current');
        var currentHref = newCurrent ? newCurrent.getAttribute('href') : null;

        Array.prototype.slice.call(liveMasthead.querySelectorAll('[data-sf-nav-item]')).forEach(function (item) {
            var current = item.getAttribute('href') === currentHref;

            item.classList.toggle('is-current', current);

            if (current) {
                item.setAttribute('aria-current', 'page');
            } else {
                item.removeAttribute('aria-current');
            }
        });

        var liveStatus = liveMasthead.querySelector('.sf-masthead__status');
        var newStatus = newMasthead.querySelector('.sf-masthead__status');

        if (liveStatus && newStatus) {
            liveStatus.className = newStatus.className;
            liveStatus.innerHTML = newStatus.innerHTML;
        }

        var nav = liveMasthead.querySelector('[data-sf-nav]');

        if (nav && nav.sfRelayout) {
            nav.sfRelayout();
        }
    }

    function swapContent(doc) {
        var body = document.getElementById('wpbody-content');
        var newBody = doc.getElementById('wpbody-content');
        var liveMasthead = body.querySelector('.sf-masthead');
        var keep = function (node) {
            return node.nodeType === 1 && (node.id === 'screen-meta' || node.id === 'screen-meta-links');
        };

        destroyCharts();

        Array.prototype.slice.call(body.childNodes).forEach(function (node) {
            if (!keep(node)) {
                body.removeChild(node);
            }
        });

        Array.prototype.slice.call(newBody.childNodes).forEach(function (node) {
            if (!keep(node)) {
                body.appendChild(document.importNode(node, true));
            }
        });

        var newMasthead = body.querySelector('.sf-masthead');

        if (liveMasthead && newMasthead) {
            syncMasthead(liveMasthead, newMasthead);
            newMasthead.parentNode.replaceChild(liveMasthead, newMasthead);
        }

        return body;
    }

    function focusHeading(body) {
        var heading = body.querySelector('.sf-page-intro h1, .sf-page-intro h2, .sf-admin-wrap h1');

        if (heading) {
            heading.setAttribute('tabindex', '-1');
            heading.focus({ preventScroll: true });
        }
    }

    function navigate(url, mode) {
        var id = ++requestId;

        if (controller) {
            controller.abort();
        }

        controller = window.AbortController ? new window.AbortController() : null;
        setLoading(true);

        fetch(url, {
            credentials: 'same-origin',
            signal: controller ? controller.signal : undefined
        })
            .then(function (response) {
                // A 403 nonce page, an expired login redirect or anything that
                // is not a SigmaForms screen gets a normal page load instead.
                if (!response.ok || !isSoftPage(response.url)) {
                    throw new Error('sf-soft-nav: unexpected response');
                }

                return response.text().then(function (html) {
                    return { html: html, url: response.url };
                });
            })
            .then(function (result) {
                if (id !== requestId) {
                    return null;
                }

                var doc = new window.DOMParser().parseFromString(result.html, 'text/html');

                if (!doc.querySelector('#wpbody-content .sf-admin-wrap')) {
                    throw new Error('sf-soft-nav: unexpected markup');
                }

                return loadStyles(doc, result.url).then(function () {
                    if (id !== requestId) {
                        return null;
                    }

                    var body = swapContent(doc);
                    var finalUrl = result.url;

                    displayedUrl = finalUrl;
                    dirty = false;
                    document.title = doc.title;
                    syncBodyClasses(doc);
                    syncWpGlobals(result.html);
                    syncAdminMenu(finalUrl);

                    if (mode === 'push') {
                        window.history.pushState({ sfSoftNav: true }, '', finalUrl);
                    } else if (mode === 'replace') {
                        window.history.replaceState({ sfSoftNav: true }, '', finalUrl);
                    }

                    if (mode !== 'pop') {
                        window.scrollTo(0, 0);
                    }

                    return loadScripts(doc, finalUrl).then(function () {
                        if (id !== requestId) {
                            return;
                        }

                        activateInlineScripts(body);

                        // Queued behind the page's own jQuery ready handlers,
                        // so modules initialise in the same order as on a
                        // full load.
                        var announce = function () {
                            document.dispatchEvent(new window.CustomEvent('sf:page-load', { detail: { url: finalUrl } }));

                            if (window.jQuery) {
                                window.jQuery(document).trigger('wp-updates-notice-added');
                            }

                            setLoading(false);
                            focusHeading(body);
                        };

                        if (window.jQuery) {
                            window.jQuery(announce);
                        } else {
                            announce();
                        }
                    });
                });
            })
            .catch(function (error) {
                if (error && error.name === 'AbortError') {
                    return;
                }

                if (window.console && window.console.warn) {
                    window.console.warn('SigmaForms: in-page navigation failed, loading the page normally.', error);
                }

                window.location.href = url;
            });
    }

    function confirmLeave() {
        return !dirty || window.confirm(strings.unsavedChanges || 'You have unsaved changes. Leave this page anyway?');
    }

    function bootSoftNav() {
        if (!supported() || !isSoftPage(displayedUrl)) {
            return;
        }

        // Mark the entry WordPress loaded so Back can return to it in-page.
        window.history.replaceState(Object.assign({}, window.history.state, { sfSoftNav: true }), '');

        document.addEventListener('click', function (event) {
            if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                return;
            }

            var link = event.target.closest ? event.target.closest('a[data-sf-nav-item]') : null;

            if (!link || (link.target && link.target !== '_self') || link.hasAttribute('download')) {
                return;
            }

            if (!canSoftNavigate(link.href)) {
                return;
            }

            event.preventDefault();

            if (!confirmLeave()) {
                return;
            }

            navigate(link.href, pageOf(link.href) === pageOf(displayedUrl) ? 'replace' : 'push');
        });

        // Back/Forward. History entries within one screen (the settings tabs
        // push ?tab=) are left to that screen, as before; an entry for another
        // screen is swapped in, or reloaded when it cannot be.
        window.addEventListener('popstate', function () {
            if (pageOf(window.location.href) === pageOf(displayedUrl)) {
                return;
            }

            if (canSoftNavigate(window.location.href)) {
                navigate(window.location.href, 'pop');
            } else {
                window.location.reload();
            }
        });

        // Unsaved edits in the settings and white label forms.
        document.addEventListener('input', markDirty, true);
        document.addEventListener('change', markDirty, true);
        document.addEventListener('submit', function () {
            dirty = false;
        }, true);
    }

    function markDirty(event) {
        if (event.target.closest && event.target.closest('#sf-settings-form, #sf-white-label-form')) {
            dirty = true;
        }
    }

    function boot() {
        Array.prototype.slice.call(document.querySelectorAll('[data-sf-nav]')).forEach(init);
        bootSoftNav();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
}());
