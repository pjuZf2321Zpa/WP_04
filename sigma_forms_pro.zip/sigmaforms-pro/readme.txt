===SigmaForms Pro – AI Generated Forms ===
Contributors: bdthemes, selimmw, abutalib, muhammadasik, arafatakashakku
Donate link: http://bdthemes.com/
Tags: forms, ai forms, form builder, form generator, sigmaforms
Requires at least: 6.0
Tested up to: 7.1
Stable tag: 1.7.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create professional WordPress forms in seconds using AI-powered form generation technology.

== Description ==

SigmaForms Pro is the ultimate AI-powered form builder for WordPress. Create complex, professional forms in seconds using our advanced AI generation technology. Whether you need a simple contact form or a multi-step application, SigmaForms Pro handles it all with ease.

**Key Features:**

*   **AI Form Generator:** Describe your form, and let AI build it for you.
*   **Drag & Drop Builder:** Intuitive visual editor for manual adjustments.
*   **Abandoned Forms Tracking:** Capture partial submissions and recover lost leads.
*   **Advanced Analytics:** Gain insights into form performance and conversion rates.
*   **Seamless Integrations:** Connect with your favorite tools via Webhooks and SMTP.
*   **Spam Protection:** Built-in CAPTCHA support to keep your submissions clean.
*   **Elementor & Gutenberg Ready:** Works perfectly with your favorite page builders.

Experience the future of form building with SigmaForms Pro.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `sigmaforms-pro.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Admin Dashboard > SigmaForms > Configure your forms settings

== Changelog ==

= 1.7.0 [8th November 2026] =

### Added

* New "Soft" form theme: outlined fields with floating labels and field icons, pill-style choices, compact sizing; marked "New" and listed first in Settings and the form editor

= 1.6.0 [19th October 2026] =

### Security

* Hardened public form endpoints, hid the saved SMTP password, tightened permission checks and randomised upload file names

### Added

* Per-field columns in the submissions CSV export
* Styled confirm dialogs and notices in the admin
* `sigmaforms_abandoned_session_limit` filter
* `sigmaforms_email_from_address` filter
* Option to remove the saved SMTP password
* "Global default" form theme for new forms, and an "Apply to all existing forms" option in Form Styling

### Improved

* `sigmaforms_manage_forms_capability` now covers admin menus and AJAX
* Webhooks are sent after the response; emails use the site's From address and reply to the submitter
* Form scripts and the abandonment tracker load only where needed; about 30 fewer scripts on admin screens
* Submission indexes on status and date, added right after updating
* Form editor: choice options as condition values, duplicates placed after the original, form IDs in filters
* Wrong file types are reported when the file is picked
* New forms store submissions by default

### Fixed

* Expired nonces broke submissions, and a double-click could submit twice
* Multi-step forms: blocking alert, skipped required radios and invalid emails, hidden required fields blocking Next, and a page break at the end hiding the form
* Required fields hidden by conditional logic blocked the submission; "User Data" conditions never matched on the front end
* CSV rows broke on quotes; SMTP passwords with special characters or "0" were not saved as typed
* Abandoned tracking failed on cached pages and returned 500 for invalid requests
* Admin: `admin.js` loaded twice, vague session-expired error, raw AI debug output, untranslatable messages and `&#039;` in translations
* Block editor preview was unstyled and the legacy block loaded a broken script
* Choosing a theme in Settings had no effect on existing forms, and forms on the global Custom theme kept their old colours
* REST submissions ignored the form's success message, unrated Ratings saved as 0, missed radios showed no error, and uninstall left license transients

= 1.5.0 [27th September 2026] =

### Added

* Shared admin header with a "More" menu, and screen switching without a page reload
* SVG icons throughout the admin, replacing Dashicons

### Improved

* All admin screens and the Dashboard widget redesigned
* License screen protected from other plugins' CSS
* Expired links now show a "Back" link instead of an empty page

### Fixed

* Failed settings saves showed as successful
* Dashboard widget links opened a "Link expired" page, and its title ignored the white label brand
* Analytics listed all 24 hours for forms with no submissions
* Expired Analytics filter links ended on an empty page
* The form editor showed "Add New" when editing a form
* The form editor's save message vanished after one second
* Tables broke on small screens and split dates mid-word
* Icon-only buttons had no accessible labels
* `wpdb::prepare()` was called without placeholders

= 1.4.12 [25th August 2026] =

### Security

* Fixed an arbitrary file deletion vulnerability in the submission delete handlers (CVE-2026-78657)
* File upload fields now ignore values that did not arrive as a real upload
* Stored upload URLs are deleted only when they resolve to a file inside the uploads directory

= 1.4.11 [22nd August 2026] =

### Security

* Fixed a stored cross site scripting issue where signature values submitted to the public abandoned form endpoint were rendered unescaped in the admin submission and abandoned form screens
* Signature data URIs are now validated in full, instead of by prefix only, everywhere they are accepted or displayed
* Field values received by the public abandoned form tracking endpoint are sanitised on the way in
* Form, submission, abandoned form and AI generation REST routes now require the same capability as the admin screens, so submission data is no longer readable by lower roles. Sites that delegate form management can adjust this with the `sigmaforms_manage_forms_capability` filter
* The temporary upload capability used for anonymous form submissions is now granted only for the duration of the upload itself, after the nonce check, instead of for the whole request
* License data is unserialised with a class allow list, closing a PHP object injection path
* Exported CSV cells beginning with a formula character are escaped, so submission exports cannot execute in spreadsheet software
* Added a capability check to the conditional suggestions AJAX handler
* Added a payload size limit and a per client rate limit to the public mobile signature endpoints

### Fixed

* Plugin Check compliance: replaced `date()`, `strip_tags()` and `parse_url()` with `gmdate()`, `wp_strip_all_tags()` and `wp_parse_url()`, and documented the remaining sanitisation and template variable notices
* Declared compatibility with WordPress 7.1

= 1.4.10 [10th August 2026] =

### Removed

* Promotion notice feature and all of its assets, AJAX handler, and dismissal logic
* Dashboard feed widget and its remote feed requests, transients, and styles


= 1.4.9 [9th August 2026] =

### Added

* New "Transition" form theme - a card driven quiz/funnel style with selectable image cards, animated states and a multi-step progress bar
* Field label images on every field type, with the image positioned above, below, left or right of the label text
* Label image sizing by percentage of the field (stays proportional on any screen) or by fixed pixels, plus an optional height and a Full Width option
* Drag to resize label images directly in the form preview - edge handles for width and height, corner handle for both, hold Shift to keep the aspect ratio
* Built in image cropper for label and option images, using the WordPress media cropper. Crops always start from the original upload and are saved as a new attachment, so the source file is never modified
* Per option images for Radio, Checkbox and Dropdown fields, with a shared position and size per field. Dropdowns with images render an image capable listbox while keeping the native select for validation and conditional logic
* "Show Country Flag Icons" toggle for Country and International Phone fields, to show or hide flag icons on the frontend
* Separate "Show Field Label Text" and "Show Field Label Image" toggles, so the text and the image can be hidden independently
* Automatic retention policy for form view logs - set how many days of view history to keep (default 60) from Settings > Advanced > Data Cleanup, with a live count of entries queued for deletion

### Improved

* View log cleanup runs in small batches inside a time budget, so clearing a large backlog never holds a long database lock or exceeds the PHP time limit

= 1.4.8 [15th July 2026] =

### Updated

* System improved


= 1.4.7 [13th July 2026] =

### Added 

* CC and BCC email fields for form submission notifications in global settings and per-form email overrides
* Support for multiple email addresses (comma-separated) in To, CC, and BCC fields


= 1.4.6 [6th July 2026] =

### Fixed

* Fixed critical security vulnerability that allowed unauthenticated arbitrary file upload and remote code execution via public form file fields


= 1.4.5 [3rd June 2026] =

= Fixed =

* White label issue for AppSumo License


= 1.4.4 [25th May 2026] =

= Updated =

* Made compatible with WordPress version 7.0

= Improved =

* Button icon alignment across admin screens


= 1.4.3 [24th May 2026] =

= Added =

* White label branding for Agency, Extended, Developer, and special WL licenses


= 1.4.2 [14th May 2026] =

* Fixed: Admin notice styling and handling


= 1.4.1 [29th April 2026] =

= Added =

* Export/Import Settings feature in Advanced Settings tab
* Export all SigmaForms settings to JSON file with timestamp
* Import settings from previously exported JSON file with automatic saving
* Settings validation and sanitization on import for security

= Fixed =

* Plugins list "Settings" link now opens SigmaForms Settings (`sigmaforms-settings`) instead of the Forms list


= 1.4.0 [9th April 2026] =

= Added =

* Google reCAPTCHA v3 support with invisible spam protection
* Toggle switch to enable reCAPTCHA v3 (invisible) or v2 (checkbox) modes
* Configurable score threshold for v3 (0.0 - 1.0) with recommended default of 0.5
* Real-time score-based spam detection without user interaction
* Automatic token generation and validation for v3 submissions
* Backward compatibility with existing reCAPTCHA v2 implementations
* mTCaptcha support as an additional CAPTCHA provider
* mTCaptcha global settings (enable toggle, site key, and private key)
* mTCaptcha availability in Form Editor Security tab when configured
* Frontend mTCaptcha widget rendering and server-side token verification
* Customizable Page Break settings for multi-step forms
* Custom "Next Button Text" for page breaks — supports any language for translation
* Custom "Previous Button Text" for page breaks — supports any language for translation
* Custom "Step Indicator Format" with {current} and {total} placeholders for multilingual support
* Color customization for multi-step navigation — background and text colors for Next/Previous buttons, text color for step indicator
* Customizable validation message for page breaks — define the alert shown when required fields are not filled before advancing to the next step, with full multilingual support
* Textarea field height option — define a custom pixel height for any Textarea field that is applied on frontend render
* Maximum file count option for File Upload fields — set a numeric limit on how many files can be uploaded when "Allow Multiple Files" is enabled
* "Add more files" button on the frontend — after uploading files, users can incrementally add more until the maximum limit is reached
* Remaining file count indicator shown alongside the "Add more files" button
* Maximum file limit hint displayed inside the upload area before any files are selected

= Fixed =

* CAPTCHA now properly appears only on the last step of multi-step forms before the submit button


= 1.3.1 [31st March 2026] =

= Updated =

* Migrated plugin option prefix from `saigf_` to `sf_` for improved consistency and brevity
* All plugin settings and configurations now use the new `sf_` prefix throughout the codebase


= 1.3.0 [24th March 2026] =

= Added =

* Multiple file upload support for File Upload fields
* "Allow Multiple Files" toggle in file field settings
* Individual file preview and removal for multiple uploads
* Customizable upload button text for File Upload fields
* Page Break field type for multi-step forms
* Multi-step form navigation with Next/Previous buttons
* Step progress indicator (Step X of Y) 
* Form field validation between steps
* Customizable multi-step form layouts
* Responsive multi-step form design
* Smooth step transitions with animations
* Automatic file deletion when submissions are removed (site storage only)
* Email Attachment Only storage option for file uploads and signatures
* Files sent as email attachments without permanent storage (privacy-focused)
* Custom "Required Error Message" per field — supports any language
* Custom "Validation Error Message" per field for format errors (email, url, number, phone)
* Custom "File Size Error Message" per file field
* Custom "File Type Error Message" per file field
* Custom "Cloud Upload Error Message" per file field
* Form-level "Validation Error Heading" to customize the heading shown above field errors on failed submission
* Dashboard feed widget with styled RSS posts, banner image, badges, and footer links on the WordPress dashboard

= Updated =

* Section Heading underline customization (color, thickness, style, visibility toggle)
* HTML link support in checkbox and radio button option labels
* AI prompt support for all 19 field types (previously only 10 supported)
* File handling with automatic cleanup after submission form gets deleted

= Fixed =

* Confirmation email now properly detects email fields regardless of field ID/name
* File upload links in emails are now properly formatted and clickable


= 1.2.1 [3rd March 2026] =

= Fixed =

* Admin API notification system with countdown timers


= 1.2.0 [1st February 2026] =

= Added =

* Rich text editor form field
* Range/Slider form field


= 1.1.4 [12th January 2026] =

= Fixed =

* Admin Notice


= 1.1.3 [30th December 2025] =

= Fixed =

* File Naming Issue on Cloud Storage Upload


= 1.1.2 [22th December 2025] =

= Added =

* Scheduled Form 

= Fixed =

* Classic & Minimal Theme Dropdown Field Style Issue
* Cloud Storage Connect Issue on Changing Site Language


= 1.1.1 [18th December 2025] =

= Added =

* File Upload Accept Extensions
* File Upload Size Declaration
* Upload Storage Options 
* Google Drive Cloud Storage Option
* Microsoft One Drive Cloud Storage Option


= 1.1.0 [2nd December 2025] =

= Updated =

* Made compatible with WordPress version 6.9
* Form Field Dropdown Style Issue


= 1.0.9 [28th November 2025] =

= Fixed =

* Form Field Name Label Special Character Issue

= Added =

* Form Duplicate with same configurations 
* Font Size Field Added on Custom Theme Style 
* Abandoned Form Deletion Bulk Action and Row Action

= Updated =

* SigmaForms Language Pot files 
* Form Submission Error Message 
* Abandoned Form Store System


= 1.0.8 [24th November 2025] =

= Fixed =

* Plugin Update Checker 
* Admin Notice 
* Text Domain 

= Added =

* Field Label Horizontal Alignment Position 
* Button Horizontal Alignment Position 
* Form Field Horizontal Alignment Position 
* Button Position Field 

= Updated =

* Admin Notice for Plugin Update 
* Updated Form Field Based on Theme 
* License Validation System on Whole Plugin 
* Enhanced Classic and Modern styles for Form Presets 


= 1.0.7 [16th November 2025] = 

= Fixed =

* Plugin Update Checker 
* Form Deletion Functionality 


= 1.0.6 [11th November 2025] = 

= Fixed =

* Black Friday Admin Notice 


= 1.0.5 [11th November 2025] = 

= Fixed =

* Black Friday Admin Notice 


= 1.0.4 [10th November 2025] = 

= Added =

* Widget support on Elementor & Gutenberg 
* Sigma AI Assistant chat support on expanding forms 
* Added individual form styles 
* Country Field with Flag Emoji 
* International Phone Number form section 
* Heading Section Added on form field 
* Submission Forms download as CSV 
* Digital Signature Field 
* Star Rating Field 
* Black Friday Admin Notice 

= Updated =

* File uploading system animation 
* Drag and Drop smooth design  
* Abandoned Form Deletion 
* Abandoned Form Field Looks 
* LocalStorage clean up on success submit  
* Email confirmation message settings 
* Upload Files Issue Solve 
* Math Function Filter to use only numbers 
* Field Copy Issue 


= 1.0.3 [7th October 2025] = 

= Fixed =

* Responsive width issue with the Form Button 
* Long label text causing line height break in the modal header 


= 1.0.2 [6th October 2025] = 

= Fixed =

* Form submission loading state animation issue 
* Radio button alignment in responsive view 

= Added =

* New CSS classes for better form styling control 
* Custom validation messages for file upload fields 

= Updated =

* Form field spacing and margins for better visual hierarchy 
* Error message styling and positioning 
* Documentation with new CSS customization options 


= 1.0.1 [1st October 2025] = 

= Updated =

* Improved spacing for form labels, checkboxes, and radio buttons 


= 1.0.0 [29h September 2025] = 

= Added =

* AI Configurations 
* Webhook Integrations 
* SMTP Support for Email Sending 
* CAPTCHA Protection 
* 80+ Pre-built Form Templates 
* 80+ AI Prompts Suggested Templates 
* Customizable Form Creation 
* 10 Form Field Support 
* Abandoned Forms Tracking 
* Analytics Dashboard 
* Shortcode support 


== Upgrade Notice ==

- Click on the update plugin button and install the new updated version of your plugin, simple.

== Frequently Asked Questions ==

### What is SigmaForms Pro?

SigmaForms Pro is a powerful WordPress form builder that uses AI to generate forms, fields, and configurations automatically. It simplifies the form creation process while offering advanced features like abandonment tracking and analytics.

### Do I need an API key for the AI features?

Yes, you will need to configure your AI settings in the plugin dashboard to enable the AI-powered form generation and assistance features.

### Can I export my form submissions?

Yes, SigmaForms Pro supports exporting form submissions to CSV format for easy data analysis and management.

### Is it compatible with Elementor?

Yes, SigmaForms Pro provides a dedicated widget for Elementor, allowing you to easily embed and style your forms within the Elementor builder.

### How does the Abandoned Forms tracking work?

The plugin automatically tracks user interactions with your forms. If a user starts filling out a form but doesn't submit it, the data is captured (excluding sensitive information) so you can analyze drop-off rates and recover potential leads.