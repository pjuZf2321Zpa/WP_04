<?php
/**
 * Admin view for analytics
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Include initialization file with analytics data
require_once __DIR__ . '/analytics/init.php';

// Load CSS styles
include_once __DIR__ . '/analytics/analytics-styles.php';
?>

<div class="sf-wrap sf-admin-wrap">
    <?php 
    // Include header with title and filters
    include_once __DIR__ . '/analytics/header.php';
    
    // Include overview dashboard
    include_once __DIR__ . '/analytics/overview-dashboard.php';
    
    // Include detailed insights
    include_once __DIR__ . '/analytics/detailed-insights.php';
    
    // Include chart visualization
    include_once __DIR__ . '/analytics/chart-visualization.php';
    
    // Include recent submissions
    include_once __DIR__ . '/analytics/recent-submissions.php';
    ?>
</div>
