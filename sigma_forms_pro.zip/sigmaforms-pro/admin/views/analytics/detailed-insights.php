<?php
/**
 * Analytics detailed insights
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Only show detailed insights for a specific form
if (!$form_id) {
    return;
}
?>

<div class="sf-analytics-insights">
    <h2>
        <?php echo \SigmaForms\Admin\PageHeader::icon('eye'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        <?php esc_html_e('Form Insights', 'sigmaforms-pro'); ?>
    </h2>
    
    <div class="sf-insights-grid">
        <!-- Submission behavior -->
        <div class="sf-insight-card">
            <h3><?php esc_html_e('Submission Patterns', 'sigmaforms-pro'); ?></h3>
            
            <?php 
            // Initialize hour_distribution if it doesn't exist
            // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
            if (!isset($chart_data['hour_distribution'])) {
                $chart_data['hour_distribution'] = [];
            }
            // The distributions are pre-filled with a zero per hour/day, so a
            // non-empty array does not mean there is anything to report yet.
            $has_hour_data = !empty($chart_data['hour_distribution']) && array_sum($chart_data['hour_distribution']) > 0;
            if ($has_hour_data) : ?>
                <div class="sf-insight-item">
                    <div class="sf-insight-label"><?php esc_html_e('Most Active Hours', 'sigmaforms-pro'); ?></div>
                    <div class="sf-insight-value">
                        <?php
                        // Cap the list so a wide tie does not print every hour of the day.
                        $peak_hours = array_slice(array_keys($chart_data['hour_distribution'], max($chart_data['hour_distribution'])), 0, 3);
                        $formatted_hours = array_map(function($hour) {
                            return date_i18n(get_option('time_format'), strtotime("$hour:00"));
                        }, $peak_hours);
                        echo esc_html(implode(', ', $formatted_hours));
                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                        ?>
                    </div>
                </div>
                
                <div class="sf-insight-item">
                    <div class="sf-insight-label"><?php esc_html_e('Most Active Day', 'sigmaforms-pro'); ?></div>
                    <div class="sf-insight-value">
                        <?php
                        // Initialize day_distribution if it doesn't exist
                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
                        if (!isset($chart_data['day_distribution'])) {
                            $chart_data['day_distribution'] = [];
                        }
                        if (!empty($chart_data['day_distribution']) && array_sum($chart_data['day_distribution']) > 0) {
                            $days_map = [
                                0 => __('Sunday', 'sigmaforms-pro'),
                                1 => __('Monday', 'sigmaforms-pro'),
                                2 => __('Tuesday', 'sigmaforms-pro'),
                                3 => __('Wednesday', 'sigmaforms-pro'),
                                4 => __('Thursday', 'sigmaforms-pro'),
                                5 => __('Friday', 'sigmaforms-pro'),
                                6 => __('Saturday', 'sigmaforms-pro'),
                            ];
                            $peak_day_num = array_keys($chart_data['day_distribution'], max($chart_data['day_distribution']))[0];
                            echo esc_html($days_map[$peak_day_num]);
                        } else {
                            esc_html_e('Not enough data', 'sigmaforms-pro');
                        }
                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                        ?>
                    </div>
                </div>
            <?php else : ?>
                <p class="sf-no-data"><?php esc_html_e('Not enough data available', 'sigmaforms-pro'); ?></p>
            <?php endif; ?>
        </div>
                
        <!-- User Sources -->
        <div class="sf-insight-card">
            <h3><?php esc_html_e('Traffic Sources', 'sigmaforms-pro'); ?></h3>

            <?php if (!empty($popular_pages)) : ?>
                <div class="sf-insight-item">
                    <div class="sf-insight-label"><?php esc_html_e('Top Pages', 'sigmaforms-pro'); ?></div>
                    <div class="sf-insight-value sf-pages-list">
                        <ul>
                            <?php foreach ($popular_pages as $page) : ?>
                                <li>
                                    <span class="sf-page-title">
                                        <?php echo esc_html($page['title'] ? $page['title'] : $page['url']); ?>
                                    </span>
                                    <span class="sf-page-count"><?php echo esc_html($page['count']); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php else : ?>
                <p class="sf-no-data"><?php esc_html_e('No referrer data available', 'sigmaforms-pro'); ?></p>
            <?php endif; ?>
        </div>
        
        <!-- Form Performance -->
        <div class="sf-insight-card">
            <h3><?php esc_html_e('Form Performance', 'sigmaforms-pro'); ?></h3>

            <div class="sf-insight-item">
                <div class="sf-insight-label"><?php esc_html_e('Average Completion Time', 'sigmaforms-pro'); ?></div>
                <div class="sf-insight-value">
                    <?php 
                    // Initialize avg_completion_time if it doesn't exist
                    // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
                    if (!isset($field_analytics['avg_completion_time'])) {
                        $field_analytics['avg_completion_time'] = null;
                    }
                    if (!empty($field_analytics['avg_completion_time'])) {
                        // translators: %s is the number of seconds.
                        echo esc_html(sprintf( _n(
                                '%s second',
                                '%s seconds',
                                $field_analytics['avg_completion_time'],
                                'sigmaforms-pro'
                            ),
                            number_format($field_analytics['avg_completion_time'], 1)
                        ));
                    } else {
                        esc_html_e('Not tracked', 'sigmaforms-pro');
                    }
                    ?>
                </div>
            </div>
            
            <div class="sf-insight-item">
                <div class="sf-insight-label"><?php esc_html_e('Abandonment Rate', 'sigmaforms-pro'); ?></div>
                <div class="sf-insight-value">
                    <?php 
                    // Initialize abandonment_rate if it doesn't exist
                    if (!isset($field_analytics['abandonment_rate'])) {
                        $field_analytics['abandonment_rate'] = null;
                    }
                    // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                    if (isset($field_analytics['abandonment_rate']) && $field_analytics['abandonment_rate'] !== null) {
                        echo esc_html(number_format($field_analytics['abandonment_rate'], 1) . '%'); 
                    } else {
                        esc_html_e('Not tracked', 'sigmaforms-pro');
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
