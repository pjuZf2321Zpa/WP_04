<?php
/**
 * Analytics chart visualization
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Only show charts if we have form-specific data
if (!$form_id || !$chart_data) {
    return;
}
?>

<div class="sf-analytics-charts-wrapper">
    <!-- Submission Trend Chart -->
    <div class="sf-analytics-chart-section">
        <h2>
            <?php echo \SigmaForms\Admin\PageHeader::icon('trend'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            <?php esc_html_e('Submission Trend', 'sigmaforms-pro'); ?>
        </h2>
        <div class="sf-analytics-chart-container">
            <canvas id="sf-submissions-chart"></canvas>
        </div>
    </div>
    
    <!-- Dual Charts Section -->
    <div class="sf-analytics-dual-charts">
        <!-- Time Distribution Chart -->
        <div class="sf-analytics-chart-section sf-chart-half">
            <h2>
                <?php echo \SigmaForms\Admin\PageHeader::icon('clock'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                <?php esc_html_e('Time Distribution', 'sigmaforms-pro'); ?>
            </h2>
            <div class="sf-analytics-chart-container">
                <canvas id="sf-time-distribution-chart"></canvas>
            </div>
        </div>
        
        <!-- Weekly Distribution Chart -->
        <div class="sf-analytics-chart-section sf-chart-half">
            <h2>
                <?php echo \SigmaForms\Admin\PageHeader::icon('calendar'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                <?php esc_html_e('Weekly Distribution', 'sigmaforms-pro'); ?>
            </h2>
            <div class="sf-analytics-chart-container">
                <canvas id="sf-weekly-distribution-chart"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
// Runs straight away when the page is swapped in by admin-nav.js, where
// DOMContentLoaded has already fired.
(function (run) {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }
})(function() {
    // Line chart for submission trend
    var trendCtx = document.getElementById('sf-submissions-chart').getContext('2d');
    var trendData = {
        labels: <?php echo json_encode($chart_data['dates']); ?>,
        datasets: [{
            label: '<?php echo esc_js(__('Submissions', 'sigmaforms-pro')); ?>',
            data: <?php echo json_encode($chart_data['counts']); ?>,
            backgroundColor: 'rgba(33, 113, 177, 0.2)',
            borderColor: 'rgba(33, 113, 177, 1)',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(33, 113, 177, 1)',
            pointBorderColor: '#fff',
            pointRadius: 4,
            tension: 0.1,
            fill: true
        }]
    };
    
    var trendChart = new Chart(trendCtx, {
        type: 'line',
        data: trendData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        title: function(tooltipItems) {
                            // Format the date in a more readable way
                            return new Date(tooltipItems[0].label).toLocaleDateString();
                        }
                    }
                }
            }
        }
    });
    
    // Bar chart for time distribution (by hour)
    <?php 
    // Initialize hour_distribution if it doesn't exist
    // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
    if (!isset($chart_data['hour_distribution'])) {
        $chart_data['hour_distribution'] = [];
    }
    if (!empty($chart_data['hour_distribution'])) : ?>
    var timeCtx = document.getElementById('sf-time-distribution-chart').getContext('2d');
    var timeLabels = [];
    var timeData = [];
    
    <?php 
    // Generate time labels and data
    $hour_data = [];
    for ($i = 0; $i < 24; $i++) {
        $label = date_i18n(get_option('time_format'), strtotime("$i:00"));
        $count = isset($chart_data['hour_distribution'][$i]) ? $chart_data['hour_distribution'][$i] : 0;
        $hour_data[] = [
            'label' => $label,
            'count' => $count
        ];
    }
    // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    ?>
    
    var hourData = <?php echo json_encode($hour_data); ?>;
    hourData.forEach(function(item) {
        timeLabels.push(item.label);
        timeData.push(item.count);
    });
    
    var timeChart = new Chart(timeCtx, {
        type: 'bar',
        data: {
            labels: timeLabels,
            datasets: [{
                label: '<?php echo esc_js(__('Submissions', 'sigmaforms-pro')); ?>',
                data: timeData,
                backgroundColor: 'rgba(142, 68, 173, 0.7)',
                borderColor: 'rgba(142, 68, 173, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                },
                x: {
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
    <?php endif; ?>
    
    // Doughnut chart for weekly distribution
    <?php 
    // Initialize day_distribution if it doesn't exist
    // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
    if (!isset($chart_data['day_distribution'])) {
        $chart_data['day_distribution'] = [];
    }
    if (!empty($chart_data['day_distribution'])) : ?>
    var weeklyCtx = document.getElementById('sf-weekly-distribution-chart').getContext('2d');
    var dayLabels = [
        '<?php echo esc_js(__('Sunday', 'sigmaforms-pro')); ?>',
        '<?php echo esc_js(__('Monday', 'sigmaforms-pro')); ?>',
        '<?php echo esc_js(__('Tuesday', 'sigmaforms-pro')); ?>',
        '<?php echo esc_js(__('Wednesday', 'sigmaforms-pro')); ?>',
        '<?php echo esc_js(__('Thursday', 'sigmaforms-pro')); ?>',
        '<?php echo esc_js(__('Friday', 'sigmaforms-pro')); ?>',
        '<?php echo esc_js(__('Saturday', 'sigmaforms-pro')); ?>'
    ];
    
    var dayData = [0, 0, 0, 0, 0, 0, 0];
    <?php
    foreach ($chart_data['day_distribution'] as $day => $count) {
        // Escape both $day and $count safely for JS output
        echo 'dayData[' . wp_json_encode($day) . '] = ' . wp_json_encode($count) . ';';
    }
    // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    ?>
    
    var weeklyChart = new Chart(weeklyCtx, {
        type: 'doughnut',
        data: {
            labels: dayLabels,
            datasets: [{
                data: dayData,
                backgroundColor: [
                    'rgba(231, 76, 60, 0.7)',
                    'rgba(46, 204, 113, 0.7)',
                    'rgba(52, 152, 219, 0.7)',
                    'rgba(155, 89, 182, 0.7)',
                    'rgba(241, 196, 15, 0.7)',
                    'rgba(230, 126, 34, 0.7)',
                    'rgba(149, 165, 166, 0.7)'
                ],
                borderColor: '#ffffff',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });
    <?php endif; ?>
});
</script>
