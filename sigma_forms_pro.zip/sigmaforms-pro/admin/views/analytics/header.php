<?php
/**
 * Analytics header
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;
?>

<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
if ($form_id) {
    $form_title = '';
    foreach ($forms as $form) {
        if ($form['id'] == $form_id) {
            $form_title = $form['title'];
            break;
        }
    }
    // translators: 1: Form title, 2: Period label.
    $analytics_description = sprintf(__('Viewing statistics for "%1$s" over the %2$s', 'sigmaforms-pro'), $form_title, $period_label);
} else {
    // translators: %s is the period label.
    $analytics_description = sprintf(__('Viewing statistics for all forms over the %s', 'sigmaforms-pro'), $period_label);
}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

PageHeader::render();
PageHeader::intro(
    array(
        'title'       => __('Analytics', 'sigmaforms-pro'),
        'description' => $analytics_description,
    )
);
?>

<?php if (!empty($sf_filter_rejected)) : ?>
    <div class="sf-analytics-filter-notice">
        <?php echo PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        <span><?php esc_html_e('That filter link has expired, so the full report is shown. Pick a form and period below to filter again.', 'sigmaforms-pro'); ?></span>
    </div>
<?php endif; ?>

<div class="sf-analytics-header">
    <div class="sf-analytics-filters">
        <form method="get" action="">
            <div class="sf-form-wrap">
                <?php wp_nonce_field('analytics_filter'); ?>
                <input type="hidden" name="page" value="sigmaforms-analytics">
                
                <div class="sf-filter-group">
                    <label for="sf-form-filter"><?php esc_html_e('Form', 'sigmaforms-pro'); ?></label>
                    <select name="form_id" id="sf-form-filter">
                        <option value=""><?php esc_html_e('All Forms', 'sigmaforms-pro'); ?></option>
                        <?php
                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
                        foreach ($forms as $form) :
                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                        ?>
                            <option value="<?php echo esc_attr($form['id']); ?>" <?php selected($form_id, $form['id']); ?>>
                                <?php
                                /* translators: 1: form title, 2: form ID */
                                echo esc_html(sprintf(__('%1$s (#%2$d)', 'sigmaforms-pro'), $form['title'], $form['id']));
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="sf-filter-group">
                    <label for="sf-date-range"><?php esc_html_e('Period', 'sigmaforms-pro'); ?></label>
                    <select name="date_range" id="sf-date-range">
                        <option value="7days" <?php selected($date_range, '7days'); ?>>
                            <?php esc_html_e('Last 7 Days', 'sigmaforms-pro'); ?>
                        </option>
                        <option value="30days" <?php selected($date_range, '30days'); ?>>
                            <?php esc_html_e('Last 30 Days', 'sigmaforms-pro'); ?>
                        </option>
                        <option value="90days" <?php selected($date_range, '90days'); ?>>
                            <?php esc_html_e('Last 90 Days', 'sigmaforms-pro'); ?>
                        </option>
                        <option value="year" <?php selected($date_range, 'year'); ?>>
                            <?php esc_html_e('Last Year', 'sigmaforms-pro'); ?>
                        </option>
                    </select>
                </div>
            </div>
            
            <div class="sf-filter-group">
                <button type="submit" class="button sf-btn sf-btn-primary">
                    <?php echo \SigmaForms\Admin\PageHeader::icon('filter'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <span><?php esc_html_e('Apply Filters', 'sigmaforms-pro'); ?></span>
                </button>
            </div>
        </form>
    </div>
</div>
