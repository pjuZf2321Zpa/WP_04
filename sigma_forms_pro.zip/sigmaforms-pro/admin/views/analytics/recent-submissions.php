<?php
/**
 * Analytics recent submissions
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global
?>

<div class="sf-analytics-recent-section">
    <h2>
        <?php echo \SigmaForms\Admin\PageHeader::icon('list'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        <?php esc_html_e('Recent Submissions', 'sigmaforms-pro'); ?>
    </h2>
    
    <?php if (empty($recent_submissions) && SigmaForms\Plugin::is_license_valid()) : ?>
        <div class="sf-no-data-message is-empty">
            <span class="sf-no-data-icon"><?php echo \SigmaForms\Admin\PageHeader::icon('inbox'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
            <p><?php esc_html_e('No submissions found in the selected period.', 'sigmaforms-pro'); ?></p>
        </div>
    <?php elseif (empty($recent_submissions)) : ?>
        <div class="sf-no-data-message">
            <span class="sf-no-data-icon"><?php echo \SigmaForms\Admin\PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
            <p><?php esc_html_e('Please activate your license to unlock this feature.', 'sigmaforms-pro'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms_license')); ?>" class="button button-primary"><?php esc_html_e('Activate License', 'sigmaforms-pro'); ?></a>
        </div>
    <?php elseif (SigmaForms\Plugin::is_license_valid()): ?>
        <div class="sf-table-responsive sf-form-list">
            <table class="sf-data-table widefat">
                <thead>
                    <tr>
                        <th class="sf-col-id"><?php esc_html_e('ID', 'sigmaforms-pro'); ?></th>
                        <th class="sf-col-date"><?php esc_html_e('Date', 'sigmaforms-pro'); ?></th>
                        <?php if (!$form_id) : ?>
                            <th class="sf-col-form"><?php esc_html_e('Form', 'sigmaforms-pro'); ?></th>
                        <?php endif; ?>
                        <th class="sf-col-status"><?php esc_html_e('Status', 'sigmaforms-pro'); ?></th>
                        <th class="sf-col-actions"><?php esc_html_e('Actions', 'sigmaforms-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_submissions as $submission) : 
                        // Format date
                        $date_created = mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $submission['date_created']);
                        
                        // Submission URL
                        $submission_url = add_query_arg([
                            'page' => 'sigmaforms-submissions',
                            'submission_id' => $submission['id'],
                            '_wpnonce' => wp_create_nonce('view_submission_' . $submission['id']),
                        ], admin_url('admin.php'));
                        
                        // Get form name if showing all forms
                        $submission_form_title = '';
                        if (!$form_id && isset($submission['form_id'])) {
                            // Use form_title from database query (LEFT JOIN)
                            if (isset($submission['form_title']) && $submission['form_title'] !== null && $submission['form_title'] !== '') {
                                $submission_form_title = $submission['form_title'];
                            } else {
                                // Form was deleted
                                /* translators: %d is the form ID */
                                $submission_form_title = sprintf(__('Deleted Form - #%d', 'sigmaforms-pro'), (int) $submission['form_id']);
                            }
                        }
                    ?>
                        <tr>
                            <td class="sf-col-id">
                                <span class="sf-submission-id">#<?php echo esc_html($submission['id']); ?></span>
                            </td>
                            <td class="sf-col-date">
                                <?php echo esc_html($date_created); ?>
                            </td>
                            <?php if (!$form_id) : ?>
                                <td class="sf-col-form">
                                    <?php echo esc_html($submission_form_title); ?>
                                </td>
                            <?php endif; ?>
                            <td class="sf-col-status">
                                <?php if ($submission['status'] === 'unread') : ?>
                                    <span class="sf-status sf-status-unread"><?php esc_html_e('Unread', 'sigmaforms-pro'); ?></span>
                                <?php else : ?>
                                    <span class="sf-status sf-status-read"><?php esc_html_e('Read', 'sigmaforms-pro'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="sf-col-actions">
                                <div class="sf-action-buttons">
                                    <a href="<?php echo esc_url($submission_url); ?>" class="sf-btn sf-btn-xs sf-action-btn">
                                        <?php echo \SigmaForms\Admin\PageHeader::icon('eye'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('View', 'sigmaforms-pro'); ?>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="sf-view-all-link">
            <?php 
            $view_all_url = add_query_arg(
                ['page' => 'sigmaforms-submissions'] + ($form_id ? ['form_id' => $form_id] : []),
                admin_url('admin.php')
            );
            ?>
            <a href="<?php echo esc_url($view_all_url); ?>" class="button sf-btn sf-btn-primary">
                <?php echo \SigmaForms\Admin\PageHeader::icon('list'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                <span><?php esc_html_e('View All Submissions', 'sigmaforms-pro'); ?></span>
            </a>
        </div>
    <?php else: ?>
        <div class="sf-no-data-message">
        <span class="sf-no-data-icon"><?php echo \SigmaForms\Admin\PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
            <p><?php esc_html_e('Please activate your license to unlock this feature.', 'sigmaforms-pro'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms_license')); ?>" class="button button-primary"><?php esc_html_e('Activate License', 'sigmaforms-pro'); ?></a>
        </div>
    <?php endif; ?>
</div>
