<?php
/**
 * Analytics initialization
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Get form filter if set. The filter only narrows a read-only report, so an
// expired or missing nonce falls back to the unfiltered view with a notice
// rather than killing the page on a bookmarked or refreshed URL.
$sf_filter_rejected = false;
if (isset($_GET['form_id']) || isset($_GET['date_range'])) {
    $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
    if (!wp_verify_nonce(wp_unslash($nonce), 'analytics_filter')) {
        $sf_filter_rejected = true;
    }
}
$form_id = (!$sf_filter_rejected && isset($_GET['form_id'])) ? intval($_GET['form_id']) : null;
$date_range = (!$sf_filter_rejected && isset($_GET['date_range'])) ? sanitize_text_field(wp_unslash($_GET['date_range'])) : '30days';

// Calculate date range
$date_to = current_time('mysql');
switch ($date_range) {
    case '7days':
        $date_from = gmdate('Y-m-d H:i:s', strtotime('-7 days'));
        $period_label = __('Last 7 Days', 'sigmaforms-pro');
        break;
    case '90days':
        $date_from = gmdate('Y-m-d H:i:s', strtotime('-90 days'));
        $period_label = __('Last 90 Days', 'sigmaforms-pro');
        break;
    case 'year':
        $date_from = gmdate('Y-m-d H:i:s', strtotime('-1 year'));
        $period_label = __('Last Year', 'sigmaforms-pro');
        break;
    default: // 30days
        $date_from = gmdate('Y-m-d H:i:s', strtotime('-30 days'));
        $period_label = __('Last 30 Days', 'sigmaforms-pro');
        break;
}

// Get base analytics data
$analytics = [
    'total_submissions' => \SigmaForms\Utils\Analytics::get_submission_count($form_id, [
        'date_from' => $date_from,
        'date_to' => $date_to,
    ]),
    'total_forms' => \SigmaForms\Utils\Analytics::get_form_count(),
    'status_counts' => \SigmaForms\Utils\Analytics::get_submissions_by_status($form_id),
];

// Enhanced analytics metrics
$days = 30;
if ($date_range === '7days') {
    $days = 7;
} elseif ($date_range === '90days') {
    $days = 90;
} elseif ($date_range === 'year') {
    $days = 365;
}

// Get forms for filter
$forms = $forms_manager->get_forms();

// Get submission rate data
$chart_data = null;
$conversion_rate = 0;
$growth_rate = 0;
$peak_day = ['date' => '', 'count' => 0];
$popular_pages = [];
$field_analytics = [];

if ($form_id) {
    // Submission trend data
    $chart_data = \SigmaForms\Utils\Analytics::get_submission_rate($form_id, $days);

    // Add more insights for selected form
    // Get previous period for comparison
    $prev_date_from = gmdate('Y-m-d H:i:s', strtotime($date_from . ' -' . $days . ' days'));
    $prev_date_to = gmdate('Y-m-d H:i:s', strtotime($date_to . ' -' . $days . ' days'));

    $prev_submissions = \SigmaForms\Utils\Analytics::get_submission_count($form_id, [
        'date_from' => $prev_date_from,
        'date_to' => $prev_date_to,
    ]);
    
    // Calculate growth rate (prevent division by zero)
    if ($prev_submissions > 0) {
        $growth_rate = (($analytics['total_submissions'] - $prev_submissions) / $prev_submissions) * 100;
    }
    
    // Get form views (if available)
    $form_views = 0;
    // Check if the method exists to avoid errors
    if (method_exists('\SigmaForms\Utils\Analytics', 'get_form_views')) {
        $form_views = \SigmaForms\Utils\Analytics::get_form_views($form_id, [
            'date_from' => $date_from,
            'date_to' => $date_to,
        ]);
    }
    
    // Calculate conversion rate
    if ($form_views > 0) {
        $conversion_rate = ($analytics['total_submissions'] / $form_views) * 100;
    }
    
    // Find peak day (day with most submissions)
    if (!empty($chart_data['counts']) && !empty($chart_data['dates'])) {
        $max_index = array_keys($chart_data['counts'], max($chart_data['counts']))[0];
        $peak_day = [
            'date' => $chart_data['dates'][$max_index],
            'count' => $chart_data['counts'][$max_index]
        ];
    }
    
    // Get referring pages (where the form was submitted from)
    $popular_pages = [];
    // Check if the method exists to avoid errors
    if (method_exists('\SigmaForms\Utils\Analytics', 'get_popular_referring_pages')) {
        $popular_pages = \SigmaForms\Utils\Analytics::get_popular_referring_pages($form_id, 5);
    }
    
    // Get field-specific analytics (most filled fields, error-prone fields)
    $field_analytics = [];
    // Check if the method exists to avoid errors
    if (method_exists('\SigmaForms\Utils\Analytics', 'get_field_analytics')) {
        $field_analytics = \SigmaForms\Utils\Analytics::get_field_analytics($form_id);
    }
}

// Get recent submissions
$recent_submissions = $form_id ? 
    \SigmaForms\Utils\Analytics::get_recent_submissions(10, $form_id) : 
    \SigmaForms\Utils\Analytics::get_recent_submissions(10);
