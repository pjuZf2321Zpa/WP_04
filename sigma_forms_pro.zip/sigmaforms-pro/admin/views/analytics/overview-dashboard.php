<?php
/**
 * Analytics overview dashboard
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="sf-analytics-overview">
    <!-- Primary stats -->
    <div class="sf-analytics-card sf-card-submissions">
        <div class="sf-card-icon">
            <?php echo \SigmaForms\Admin\PageHeader::icon('inbox'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        </div>
        <div class="sf-card-content">
            <h3 class="sf-card-value"><?php echo esc_html($analytics['total_submissions']); ?></h3>
            <p class="sf-card-label"><?php esc_html_e('Total Submissions', 'sigmaforms-pro'); ?></p>
            <?php if ($form_id && isset($growth_rate)) : ?>
                <p class="sf-card-trend <?php echo $growth_rate >= 0 ? 'sf-trend-up' : 'sf-trend-down'; ?>">
                    <?php echo \SigmaForms\Admin\PageHeader::icon($growth_rate >= 0 ? 'arrow-up' : 'arrow-down'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <?php echo esc_html(abs(round($growth_rate, 1)) . '%'); ?>
                    <span class="sf-trend-period"><?php esc_html_e('vs previous period', 'sigmaforms-pro'); ?></span>
                </p>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if (!$form_id) : ?>
        <div class="sf-analytics-card sf-card-forms">
            <div class="sf-card-icon">
                <?php echo \SigmaForms\Admin\PageHeader::icon('forms'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            </div>
            <div class="sf-card-content">
                <h3 class="sf-card-value"><?php echo esc_html($analytics['total_forms']); ?></h3>
                <p class="sf-card-label"><?php esc_html_e('Active Forms', 'sigmaforms-pro'); ?></p>
            </div>
        </div>
    <?php else : ?>
        <!-- Conversion rate card -->
        <div class="sf-analytics-card sf-card-conversion">
            <div class="sf-card-icon">
                <?php echo \SigmaForms\Admin\PageHeader::icon('chart'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            </div>
            <div class="sf-card-content">
                <h3 class="sf-card-value"><?php echo (isset($conversion_rate) && $conversion_rate > 0) ? number_format($conversion_rate, 1) . '%' : 'N/A'; ?></h3>
                <p class="sf-card-label"><?php esc_html_e('Conversion Rate', 'sigmaforms-pro'); ?></p>
                <p class="sf-card-context"><?php esc_html_e('Form submissions vs views', 'sigmaforms-pro'); ?></p>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="sf-analytics-card sf-card-unread">
        <div class="sf-card-icon">
            <?php echo \SigmaForms\Admin\PageHeader::icon('eye'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        </div>
        <div class="sf-card-content">
            <h3 class="sf-card-value"><?php echo esc_html($analytics['status_counts']['unread']); ?></h3>
            <p class="sf-card-label"><?php esc_html_e('Unread Submissions', 'sigmaforms-pro'); ?></p>
            <?php if ($analytics['total_submissions'] > 0) : ?>
                <p class="sf-card-context">
                    <?php 
                    // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
                    $unread_percentage = ($analytics['status_counts']['unread'] / $analytics['total_submissions']) * 100;
                    // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                    echo esc_html(round($unread_percentage) . '% ' . __('of total', 'sigmaforms-pro')); 
                    ?>
                </p>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($form_id && $chart_data) : ?>
        <div class="sf-analytics-card sf-card-average">
            <div class="sf-card-icon">
                <?php echo \SigmaForms\Admin\PageHeader::icon('trend'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            </div>
            <div class="sf-card-content">
                <h3 class="sf-card-value"><?php echo isset($chart_data['average']) ? number_format($chart_data['average'], 1) : 'N/A'; ?></h3>
                <p class="sf-card-label"><?php esc_html_e('Daily Average', 'sigmaforms-pro'); ?></p>
                <?php 
                // Check if peak_day is properly initialized
                // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
                if (!isset($peak_day) || !is_array($peak_day)) {
                    $peak_day = ['date' => '', 'count' => 0];
                }
                // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                if (!empty($peak_day) && !empty($peak_day['date'])) : ?>
                    <p class="sf-card-context">
                        <?php 
                        // translators: 1: Date, 2: Number of submissions.
                        printf(esc_html__('Peak: %1$s (%2$s)', 'sigmaforms-pro'),
                            esc_html(date_i18n(get_option('date_format'), strtotime($peak_day['date']))),
                            esc_html($peak_day['count'])
                        ); 
                        ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if ($form_id && !empty($field_analytics)) : ?>
        <div class="sf-analytics-card sf-card-completion">
            <div class="sf-card-icon">
                <?php echo \SigmaForms\Admin\PageHeader::icon('check-circle'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            </div>
            <div class="sf-card-content">
                <h3 class="sf-card-value"><?php echo (isset($field_analytics) && isset($field_analytics['completion_rate'])) ? number_format($field_analytics['completion_rate'], 1) . '%' : 'N/A'; ?></h3>
                <p class="sf-card-label"><?php esc_html_e('Form Completion Rate', 'sigmaforms-pro'); ?></p>
                <p class="sf-card-context"><?php esc_html_e('Successfully completed submissions', 'sigmaforms-pro'); ?></p>
            </div>
        </div>
    <?php endif; ?>
</div>
