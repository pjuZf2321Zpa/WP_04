<?php
/**
 * Analytics styles
 *
 * Page specific rules only; the shell, masthead, tables and empty states
 * come from assets/css/admin.css. This block prints after admin.css.
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<style>
    /* Expired filter link ------------------------------------------------ */

    .sf-analytics-filter-notice {
        display: flex;
        align-items: center;
        gap: 10px;
        margin: 20px 0 0;
        padding: 12px 18px;
        background: var(--sf-primary-50);
        border: 1px solid var(--sf-primary-200);
        border-radius: 12px;
        color: var(--sf-gray-800);
        font-size: 13px;
        line-height: 1.5;
    }

    .sf-analytics-filter-notice .sf-icon {
        flex-shrink: 0;
        color: var(--sf-primary-600);
    }

    /* Filters ------------------------------------------------------------ */

    .sf-analytics-filters {
        margin: 20px 0 0;
        padding: 14px 20px;
        background: var(--sf-white);
        border: 1px solid var(--sf-gray-200);
        border-radius: 14px;
    }

    .sf-analytics-filters form {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 14px 20px;
    }

    .sf-form-wrap {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px 20px;
    }

    .sf-filter-group {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .sf-filter-group label {
        color: var(--sf-gray-600);
        font-size: 13px;
        font-weight: 600;
        white-space: nowrap;
    }

    .sf-admin-wrap .sf-analytics-filters select {
        min-width: 170px;
        height: 40px;
        min-height: 40px;
        padding: 0 32px 0 12px;
        background-color: var(--sf-white);
        border: 1px solid var(--sf-gray-300);
        border-radius: 8px;
        color: var(--sf-gray-800);
        font-size: 13px;
        font-weight: 500;
        line-height: 38px;
    }

    .sf-admin-wrap .sf-analytics-filters select:focus {
        border-color: var(--sf-primary-500);
        box-shadow: 0 0 0 3px var(--sf-primary-100);
        outline: none;
    }

    .sf-admin-wrap .sf-analytics-filters .sf-btn-primary {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        height: 40px;
        padding: 0 18px !important;
        background: var(--sf-primary-500);
        border: 1px solid var(--sf-primary-500);
        border-radius: 8px;
        box-shadow: none;
        color: var(--sf-white);
        font-size: 13px;
        font-weight: 600;
        line-height: 1;
        transition: background-color .15s ease;
    }

    .sf-admin-wrap .sf-analytics-filters .sf-btn-primary:hover,
    .sf-admin-wrap .sf-analytics-filters .sf-btn-primary:focus {
        background: var(--sf-primary-600);
        border-color: var(--sf-primary-600);
        box-shadow: none;
        color: var(--sf-white);
        transform: none;
    }

    /* Overview tiles ----------------------------------------------------- */

    /* 170px keeps the five per-form tiles on one row down to ~900px of
       content; narrower screens get 3 + 2 rather than a lone fifth tile. */
    .sf-analytics-overview {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
        gap: 14px;
        margin: 20px 0 0;
    }

    .sf-analytics-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 18px 20px;
        background: var(--sf-white);
        border: 1px solid var(--sf-gray-200);
        border-radius: 12px;
    }

    .sf-card-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        width: 40px;
        height: 40px;
        margin: 0;
        padding: 0;
        background: var(--sf-gray-100);
        border-radius: 10px;
        color: var(--sf-gray-500);
    }

    .sf-card-icon .sf-icon {
        width: 19px;
        height: 19px;
    }

    .sf-card-submissions .sf-card-icon { background: var(--sf-primary-50); color: var(--sf-primary-600); }
    .sf-card-forms .sf-card-icon       { background: var(--sf-success-50); color: var(--sf-success-600); }
    .sf-card-unread .sf-card-icon      { background: var(--sf-warning-50); color: var(--sf-warning-600); }
    .sf-card-conversion .sf-card-icon,
    .sf-card-average .sf-card-icon     { background: var(--sf-purple-100); color: var(--sf-purple-700); }
    .sf-card-completion .sf-card-icon  { background: var(--sf-success-50); color: var(--sf-success-600); }

    .sf-card-content {
        flex: 1;
        min-width: 0;
    }

    .sf-admin-wrap .sf-card-value {
        margin: 0;
        padding: 0;
        color: var(--sf-gray-900);
        font-size: 22px;
        font-weight: 700;
        line-height: 1.2;
        letter-spacing: -.02em;
    }

    .sf-card-label {
        margin: 3px 0 0;
        color: var(--sf-gray-500);
        font-size: 12px;
        font-weight: 600;
    }

    .sf-card-context,
    .sf-card-trend {
        display: flex;
        align-items: center;
        gap: 4px;
        margin: 6px 0 0;
        color: var(--sf-gray-400);
        font-size: 12px;
        font-weight: 500;
    }

    .sf-card-trend .sf-icon {
        width: 13px;
        height: 13px;
    }

    .sf-trend-up { color: var(--sf-success-600); }
    .sf-trend-down { color: var(--sf-danger-600); }

    .sf-trend-period {
        color: var(--sf-gray-400);
        font-weight: 500;
    }

    /* Section headings --------------------------------------------------- */

    .sf-analytics-insights h2,
    .sf-analytics-chart-section h2,
    .sf-analytics-recent-section h2 {
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 28px 0 12px;
        padding: 0;
        color: var(--sf-gray-900);
        font-size: 15px;
        font-weight: 700;
        letter-spacing: -.01em;
    }

    .sf-analytics-insights h2 .sf-icon,
    .sf-analytics-chart-section h2 .sf-icon,
    .sf-analytics-recent-section h2 .sf-icon {
        color: var(--sf-primary-500);
    }

    /* Insights ----------------------------------------------------------- */

    .sf-insights-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 14px;
    }

    .sf-insight-card {
        padding: 20px 22px;
        background: var(--sf-white);
        border: 1px solid var(--sf-gray-200);
        border-radius: 12px;
    }

    .sf-insight-card h3 {
        margin: 0 0 14px;
        padding: 0 0 12px;
        border-bottom: 1px solid var(--sf-gray-100);
        color: var(--sf-gray-900);
        font-size: 14px;
        font-weight: 700;
    }

    .sf-insight-item {
        margin: 0 0 14px;
    }

    .sf-insight-item:last-child {
        margin-bottom: 0;
    }

    .sf-insight-label {
        margin: 0 0 3px;
        color: var(--sf-gray-500);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: .05em;
        text-transform: uppercase;
    }

    .sf-insight-value {
        color: var(--sf-gray-800);
        font-size: 14px;
        font-weight: 600;
    }

    .sf-pages-list ul {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .sf-pages-list li {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 7px 0;
        border-bottom: 1px solid var(--sf-gray-100);
        font-size: 13px;
        font-weight: 500;
    }

    .sf-pages-list li:last-child {
        border-bottom: 0;
    }

    /* base.css styles .sf-page-title as a 30px page heading; this is a list
       item that shares the class name, so reset it here. */
    .sf-pages-list .sf-page-title {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        color: var(--sf-gray-800);
        font-size: 13px;
        font-weight: 500;
        line-height: 1.5;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .sf-page-count {
        flex-shrink: 0;
        padding: 2px 9px;
        background: var(--sf-gray-100);
        border-radius: 999px;
        color: var(--sf-gray-600);
        font-size: 11px;
        font-weight: 700;
    }

    .sf-no-data {
        margin: 0;
        color: var(--sf-gray-500);
        font-size: 13px;
    }

    /* Charts ------------------------------------------------------------- */

    .sf-analytics-chart-section {
        padding: 20px 24px 24px;
        background: var(--sf-white);
        border: 1px solid var(--sf-gray-200);
        border-radius: 14px;
    }

    .sf-analytics-charts-wrapper .sf-analytics-chart-section h2 {
        margin: 0 0 16px;
    }

    .sf-analytics-charts-wrapper > .sf-analytics-chart-section {
        margin-top: 28px;
    }

    .sf-analytics-chart-container {
        position: relative;
        height: 320px;
    }

    .sf-analytics-dual-charts {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
        gap: 14px;
        margin-top: 14px;
    }

    .sf-chart-half .sf-analytics-chart-container {
        height: 280px;
    }

    /* Recent submissions ------------------------------------------------- */

    .sf-analytics-recent-section .sf-table-responsive {
        display: block !important;
        overflow-x: auto;
        margin: 0;
        background: var(--sf-white);
        border: 1px solid var(--sf-gray-200);
        border-radius: 14px;
    }

    .sf-data-table {
        width: 100%;
        margin: 0;
        border-collapse: collapse;
    }

    .sf-data-table th {
        padding: 12px 16px;
        background: var(--sf-gray-50);
        border-bottom: 1px solid var(--sf-gray-200);
        color: var(--sf-gray-500);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: .06em;
        text-align: left;
        text-transform: uppercase;
    }

    .sf-data-table td {
        padding: 14px 16px;
        border-bottom: 1px solid var(--sf-gray-100);
        color: var(--sf-gray-700);
        font-size: 14px;
        vertical-align: middle;
    }

    .sf-data-table th:first-child,
    .sf-data-table td:first-child {
        padding-inline-start: 24px;
    }

    .sf-data-table th:last-child,
    .sf-data-table td:last-child {
        padding-inline-end: 24px;
    }

    .sf-data-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .sf-data-table tbody tr:hover td {
        background: rgba(79, 70, 229, .035);
    }

    .sf-col-id { width: 80px; }
    .sf-col-date { width: 200px; }
    .sf-col-form { width: 25%; }
    .sf-col-status { width: 110px; }
    .sf-col-actions { width: 120px; text-align: right; }

    .sf-submission-id {
        color: var(--sf-gray-900);
        font-weight: 600;
    }

    .sf-status {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 600;
        line-height: 1.4;
    }

    .sf-status-unread {
        background: var(--sf-primary-50);
        color: var(--sf-primary-600);
    }

    .sf-status-read {
        background: var(--sf-gray-100);
        color: var(--sf-gray-600);
    }

    .sf-action-buttons {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
    }

    .sf-admin-wrap .sf-action-buttons .sf-action-btn .sf-icon {
        width: 14px;
        height: 14px;
    }

    .sf-view-all-link {
        margin: 14px 0 0;
        text-align: right;
    }

    .sf-admin-wrap .sf-view-all-link .sf-btn-primary {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 18px !important;
        background: var(--sf-primary-500);
        border: 1px solid var(--sf-primary-500);
        border-radius: 8px;
        box-shadow: none;
        color: var(--sf-white);
        font-size: 13px;
        font-weight: 600;
        line-height: 1;
    }

    .sf-admin-wrap .sf-view-all-link .sf-btn-primary:hover,
    .sf-admin-wrap .sf-view-all-link .sf-btn-primary:focus {
        background: var(--sf-primary-600);
        border-color: var(--sf-primary-600);
        box-shadow: none;
        color: var(--sf-white);
        transform: none;
    }

    /* The empty and locked states sit in their own panel here, since the
       recent section has no card of its own. */
    .sf-analytics-recent-section > .sf-no-data-message {
        background: var(--sf-white);
        border: 1px solid var(--sf-gray-200);
        border-radius: 14px;
    }

    /* Responsive --------------------------------------------------------- */

    @media screen and (max-width: 782px) {
        .sf-analytics-filters form,
        .sf-form-wrap,
        .sf-filter-group {
            align-items: stretch;
            flex-direction: column;
        }

        .sf-filter-group {
            gap: 6px;
        }

        .sf-admin-wrap .sf-analytics-filters select,
        .sf-admin-wrap .sf-analytics-filters .sf-btn-primary {
            width: 100%;
            justify-content: center;
        }

        .sf-analytics-dual-charts {
            grid-template-columns: 1fr;
        }

        .sf-col-actions {
            width: auto;
        }
    }
</style>
