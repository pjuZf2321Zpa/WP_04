<?php
/**
 * Field Settings Popup Dialog
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- Field Settings Popup Dialog -->
<div class="sf-field-settings-popup" style="display: none;">
    <div class="sf-field-settings-header">
        <h3 class="sf-field-settings-title"><?php esc_html_e('Field Settings', 'sigmaforms-pro'); ?></h3>
        <button type="button" class="sf-close-settings" aria-label="<?php esc_attr_e('Close', 'sigmaforms-pro'); ?>"><?php echo \SigmaForms\Admin\PageHeader::icon('close'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></button>
    </div>
    <div class="sf-field-settings-tabs">
        <button type="button" class="sf-settings-tab active"
            data-tab="basic"><?php esc_html_e('Basic', 'sigmaforms-pro'); ?></button>
        <button type="button" class="sf-settings-tab"
            data-tab="advanced"><?php esc_html_e('Advanced', 'sigmaforms-pro'); ?></button>
        <button type="button" class="sf-settings-tab"
            data-tab="conditional"><?php esc_html_e('Conditional Logic', 'sigmaforms-pro'); ?></button>
        <button type="button" class="sf-settings-tab"
            data-tab="math"><?php esc_html_e('Math Function', 'sigmaforms-pro'); ?></button>
    </div>
    <div class="sf-field-settings-content">
        <!-- Basic Tab -->
        <div class="sf-settings-tab-panel active" data-tab="basic">
            <!-- Hidden field for field ID -->
            <input type="hidden" class="sf-field-id">

            <!-- Group for Standard Field Settings -->
            <div class="sf-settings-group sf-settings-group-field">
                <div class="sf-field-row">
                    <label><?php esc_html_e('Field Type', 'sigmaforms-pro'); ?></label>
                    <select class="sf-field-type">
                        <option value="text"><?php esc_html_e('Text', 'sigmaforms-pro'); ?></option>
                        <option value="email"><?php esc_html_e('Email', 'sigmaforms-pro'); ?></option>
                        <option value="url"><?php esc_html_e('URL', 'sigmaforms-pro'); ?></option>
                        <option value="number"><?php esc_html_e('Number', 'sigmaforms-pro'); ?></option>
                        <option value="phone"><?php esc_html_e('Phone', 'sigmaforms-pro'); ?></option>
                        <option value="phone_international"><?php esc_html_e('Phone (International)', 'sigmaforms-pro'); ?>
                        </option>
                        <option value="textarea"><?php esc_html_e('Textarea', 'sigmaforms-pro'); ?></option>
                        <option value="rich_text"><?php esc_html_e('Rich Text', 'sigmaforms-pro'); ?></option>
            <option value="range"><?php esc_html_e('Range / Slider', 'sigmaforms-pro'); ?></option>
                        <option value="select"><?php esc_html_e('Select', 'sigmaforms-pro'); ?></option>
                        <option value="country"><?php esc_html_e('Country', 'sigmaforms-pro'); ?></option>
                        <option value="radio"><?php esc_html_e('Radio', 'sigmaforms-pro'); ?></option>
                        <option value="checkbox"><?php esc_html_e('Checkbox', 'sigmaforms-pro'); ?></option>
                        <option value="date"><?php esc_html_e('Date', 'sigmaforms-pro'); ?></option>
                        <option value="file"><?php esc_html_e('File Upload', 'sigmaforms-pro'); ?></option>
                        <option value="signature"><?php esc_html_e('Digital Signature', 'sigmaforms-pro'); ?></option>
                        <option value="rating"><?php esc_html_e('Rating', 'sigmaforms-pro'); ?></option>
                        <option value="section_heading"><?php esc_html_e('Section Heading', 'sigmaforms-pro'); ?></option>
                        <option value="page_break"><?php esc_html_e('Page Break', 'sigmaforms-pro'); ?></option>
                    </select>
                </div>
                <div class="sf-field-row">
                    <label><?php esc_html_e('Label', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-field-label"
                        placeholder="<?php esc_attr_e('Field Label', 'sigmaforms-pro'); ?>">
                </div>
                <div class="sf-field-row">
                    <label><?php esc_html_e('Name', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-field-name"
                        placeholder="<?php esc_attr_e('Field Name (no spaces)', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('The field name should be unique and contain only letters, numbers, and underscores.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Label Image -->
                <div class="sf-field-row sf-label-image-row">
                    <label><?php esc_html_e('Label Image', 'sigmaforms-pro'); ?></label>

                    <div class="sf-image-picker" data-target="sf-field-label-image">
                        <input type="hidden" class="sf-field-label-image" value="">
                        <input type="hidden" class="sf-field-label-image-id" value="">
                        <!-- The attachment originally picked. Cropping always starts
                             from this one so repeated crops never compound. -->
                        <input type="hidden" class="sf-field-label-image-source-id" value="">

                        <!-- Empty state: whole tile is the trigger -->
                        <button type="button" class="sf-image-picker-empty sf-select-image">
                            <span class="dashicons dashicons-format-image"></span>
                            <span class="sf-image-picker-empty-title"><?php esc_html_e('Select Image', 'sigmaforms-pro'); ?></span>
                            <span class="sf-image-picker-empty-hint"><?php esc_html_e('Choose from the media library or upload a new one', 'sigmaforms-pro'); ?></span>
                        </button>

                        <!-- Filled state -->
                        <div class="sf-image-picker-card" style="display:none;">
                            <div class="sf-image-picker-thumb"></div>
                            <div class="sf-image-picker-meta">
                                <span class="sf-image-picker-name"></span>
                                <span class="sf-image-picker-dims"></span>
                                <div class="sf-image-picker-actions">
                                    <button type="button" class="sf-image-action sf-select-image">
                                        <span class="dashicons dashicons-update-alt"></span>
                                        <?php esc_html_e('Replace', 'sigmaforms-pro'); ?>
                                    </button>
                                    <button type="button" class="sf-image-action sf-crop-image">
                                        <span class="dashicons dashicons-image-crop"></span>
                                        <?php esc_html_e('Crop', 'sigmaforms-pro'); ?>
                                    </button>
                                    <button type="button" class="sf-image-action sf-image-action-danger sf-remove-image">
                                        <span class="dashicons dashicons-trash"></span>
                                        <?php esc_html_e('Remove', 'sigmaforms-pro'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <p class="sf-field-description">
                        <?php esc_html_e('Show an image next to this field label. Works with every field type.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-field-row sf-label-image-options-row" style="display:none;">
                    <div class="sf-image-settings-grid">
                        <div class="sf-image-setting">
                            <label><?php esc_html_e('Label Image Position', 'sigmaforms-pro'); ?></label>
                            <select class="sf-field-label-image-position">
                                <option value="top"><?php esc_html_e('Up (above the text)', 'sigmaforms-pro'); ?></option>
                                <option value="bottom"><?php esc_html_e('Down (below the text)', 'sigmaforms-pro'); ?></option>
                                <option value="left"><?php esc_html_e('Left of the text', 'sigmaforms-pro'); ?></option>
                                <option value="right"><?php esc_html_e('Right of the text', 'sigmaforms-pro'); ?></option>
                            </select>
                        </div>
                        <div class="sf-image-setting">
                            <label><?php esc_html_e('Label Image Width', 'sigmaforms-pro'); ?></label>
                            <div class="sf-image-width-group">
                                <input type="number" class="sf-field-label-image-width" min="0" max="2000" step="1"
                                    placeholder="<?php esc_attr_e('Auto', 'sigmaforms-pro'); ?>">
                                <select class="sf-field-label-image-width-unit"
                                    title="<?php esc_attr_e('% keeps the image the same proportion of the field; px is a fixed size', 'sigmaforms-pro'); ?>">
                                    <option value="%">%</option>
                                    <option value="px">px</option>
                                </select>
                            </div>
                        </div>
                        <div class="sf-image-setting">
                            <label><?php esc_html_e('Label Image Height', 'sigmaforms-pro'); ?></label>
                            <input type="number" class="sf-field-label-image-height" min="0" max="2000" step="1"
                                placeholder="<?php esc_attr_e('Auto', 'sigmaforms-pro'); ?>">
                        </div>
                    </div>
                    <div class="sf-image-full-width-row">
                        <label class="sf-toggle-label">
                            <span class="sf-toggle-switch">
                                <input type="checkbox" class="sf-field-label-image-full-width">
                                <span class="sf-toggle-slider"></span>
                            </span>
                            <?php esc_html_e('Full Width', 'sigmaforms-pro'); ?>
                        </label>
                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Leave empty to keep the image at its natural size. A % width stays the same proportion of the field on any screen, so the form preview matches the frontend. You can also drag the image in the form preview to resize it.', 'sigmaforms-pro'); ?>
                    </p>
                </div>
                <div class="sf-field-row sf-options-row" style="display: none;">
                    <label><?php esc_html_e('Options', 'sigmaforms-pro'); ?></label>
                    <div class="sf-field-options-container">
                        <div class="sf-field-options-list">
                            <!-- Options will be added dynamically here -->
                        </div>
                        <button type="button" class="sf-btn sf-btn-primary sf-btn-sm sf-add-option">
                            <span class="dashicons dashicons-plus-alt2"></span>
                            <?php esc_html_e('Add Option', 'sigmaforms-pro'); ?>
                        </button>
                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Each option can carry its own image - use the image button on the option row.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Option image layout (radio / checkbox / select) -->
                <div class="sf-field-row sf-option-image-options-row" style="display:none;">
                    <div class="sf-image-settings-grid">
                        <div class="sf-image-setting">
                            <label><?php esc_html_e('Option Image Position', 'sigmaforms-pro'); ?></label>
                            <select class="sf-field-option-image-position">
                                <option value="top"><?php esc_html_e('Up (above the text)', 'sigmaforms-pro'); ?></option>
                                <option value="bottom"><?php esc_html_e('Down (below the text)', 'sigmaforms-pro'); ?></option>
                                <option value="left"><?php esc_html_e('Left of the text', 'sigmaforms-pro'); ?></option>
                                <option value="right"><?php esc_html_e('Right of the text', 'sigmaforms-pro'); ?></option>
                            </select>
                        </div>
                        <div class="sf-image-setting">
                            <label><?php esc_html_e('Option Image Width', 'sigmaforms-pro'); ?></label>
                            <input type="number" class="sf-field-option-image-size" min="0" max="600" step="1"
                                placeholder="<?php esc_attr_e('Auto', 'sigmaforms-pro'); ?>">
                        </div>
                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Applies to every option image in this field. Leave the width empty for the natural size.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Country flag icons (country + international phone) -->
                <div class="sf-field-row sf-country-flags-row" style="display:none;">
                    <label class="sf-toggle-label">
                        <span class="sf-toggle-switch">
                            <input type="checkbox" class="sf-field-show-country-flags" checked>
                            <span class="sf-toggle-slider"></span>
                        </span>
                        <?php esc_html_e('Show Country Flag Icons', 'sigmaforms-pro'); ?>
                    </label>
                    <p class="sf-field-description">
                        <?php esc_html_e('Display each country flag icon next to the country name or dial code on the frontend.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Country Selection Interface -->
                <div class="sf-field-row sf-country-selection-row" style="display: none;">
                    <label><?php esc_html_e('Country Selection', 'sigmaforms-pro'); ?></label>
                    <div class="sf-country-selection-container">
                        <div class="sf-country-search-wrapper">
                            <input type="text" class="sf-country-search"
                                placeholder="<?php esc_attr_e('Search countries...', 'sigmaforms-pro'); ?>">
                            <span class="dashicons dashicons-search sf-search-icon"></span>
                        </div>

                        <div class="sf-country-actions">
                            <button type="button" class="sf-btn sf-btn-small sf-select-all-countries">
                                <?php esc_html_e('Select All', 'sigmaforms-pro'); ?>
                            </button>
                            <button type="button" class="sf-btn sf-btn-small sf-deselect-all-countries">
                                <?php esc_html_e('Deselect All', 'sigmaforms-pro'); ?>
                            </button>
                            <span class="sf-selected-count">0 <?php esc_html_e('selected', 'sigmaforms-pro'); ?></span>
                        </div>

                        <div class="sf-countries-list-container">
                            <div class="sf-countries-list">
                                <!-- Countries will be populated by JavaScript -->
                            </div>
                        </div>

                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Select specific countries to show in the dropdown. If none are selected, all countries will be available.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Phone Country Selection Interface -->
                <div class="sf-field-row sf-phone-country-selection-row" style="display: none;">
                    <label><?php esc_html_e('Country Selection', 'sigmaforms-pro'); ?></label>
                    <div class="sf-phone-country-selection-container">
                        <div class="sf-phone-country-search-wrapper">
                            <input type="text" class="sf-phone-countries-search"
                                placeholder="<?php esc_attr_e('Search countries...', 'sigmaforms-pro'); ?>">
                            <span class="dashicons dashicons-search sf-search-icon"></span>
                        </div>

                        <div class="sf-phone-country-actions">
                            <button type="button" class="sf-btn sf-btn-small sf-select-all-phone-countries">
                                <?php esc_html_e('Select All', 'sigmaforms-pro'); ?>
                            </button>
                            <button type="button" class="sf-btn sf-btn-small sf-deselect-all-phone-countries">
                                <?php esc_html_e('Deselect All', 'sigmaforms-pro'); ?>
                            </button>
                            <span class="sf-phone-selected-count">0
                                <?php esc_html_e('selected', 'sigmaforms-pro'); ?></span>
                        </div>

                        <div class="sf-phone-countries-list-container">
                            <div class="sf-phone-countries-list">
                                <!-- Phone countries will be populated by JavaScript -->
                            </div>
                        </div>

                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Select specific countries to show in the phone country dropdown. If none are selected, all countries will be available.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Upload Button Text -->
                <div class="sf-field-row sf-upload-button-text-row" style="display: none;">
                    <label><?php esc_html_e('Button Text', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-upload-button-text"
                        placeholder="<?php esc_attr_e('Choose a file', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Customize the text displayed on the file upload button.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- File Type Selection Interface -->
                <div class="sf-field-row sf-file-types-selection-row" style="display: none;">
                    <label><?php esc_html_e('Allowed File Types', 'sigmaforms-pro'); ?></label>
                    <div class="sf-file-types-selection-container">
                        <div class="sf-file-types-search-wrapper">
                            <input type="text" class="sf-file-types-search"
                                placeholder="<?php esc_attr_e('Search file types...', 'sigmaforms-pro'); ?>">
                            <span class="dashicons dashicons-search sf-search-icon"></span>
                        </div>

                        <div class="sf-file-types-actions">
                            <button type="button" class="sf-btn sf-btn-small sf-select-all-file-types">
                                <?php esc_html_e('Select All', 'sigmaforms-pro'); ?>
                            </button>
                            <button type="button" class="sf-btn sf-btn-small sf-deselect-all-file-types">
                                <?php esc_html_e('Deselect All', 'sigmaforms-pro'); ?>
                            </button>
                            <span class="sf-file-types-selected-count">0 <?php esc_html_e('selected', 'sigmaforms-pro'); ?></span>
                        </div>

                        <div class="sf-file-types-list-container">
                            <div class="sf-file-types-list">
                                <!-- File types will be populated by JavaScript -->
                            </div>
                        </div>

                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Select specific file types to allow for upload. If none are selected, all file types will be accepted.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Custom File Extensions -->
                <div class="sf-field-row sf-custom-extensions-row" style="display: none;">
                    <label><?php esc_html_e('Custom File Extensions', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-custom-file-extensions"
                        placeholder="<?php esc_attr_e('e.g., .psd, .ai, .sketch', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Add custom file extensions separated by commas. Include the dot (e.g., .psd, .ai)', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- File Size Limit -->
                <div class="sf-field-row sf-file-size-limit-row" style="display: none;">
                    <label><?php esc_html_e('Maximum File Size', 'sigmaforms-pro'); ?></label>
                    <div class="sf-file-size-limit-wrapper" style="display: flex; gap: 10px;">
                        <input type="number" class="sf-file-size-value" 
                            placeholder="10" 
                            min="1" 
                            step="1"
                            style="flex: 1;">
                        <select class="sf-file-size-unit" style="flex: 0 0 80px;">
                            <option value="KB"><?php esc_html_e('KB', 'sigmaforms-pro'); ?></option>
                            <option value="MB" selected><?php esc_html_e('MB', 'sigmaforms-pro'); ?></option>
                        </select>
                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Set the maximum file size allowed for upload. Leave empty for default (10 MB).', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- File Size Error Message -->
                <div class="sf-field-row sf-file-size-error-message-row" style="display: none;">
                    <label><?php esc_html_e('File Size Error Message', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-file-size-error-message"
                        placeholder="<?php esc_attr_e('File size exceeds the maximum allowed size.', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Custom message when uploaded file is too large. Supports any language.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- File Type Error Message -->
                <div class="sf-field-row sf-file-type-error-message-row" style="display: none;">
                    <label><?php esc_html_e('File Type Error Message', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-file-type-error-message"
                        placeholder="<?php esc_attr_e('This file type is not allowed.', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Custom message when an invalid file type is uploaded. Supports any language.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Cloud Upload Error Message -->
                <div class="sf-field-row sf-cloud-upload-error-message-row" style="display: none;">
                    <label><?php esc_html_e('Cloud Upload Error Message', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-cloud-upload-error-message"
                        placeholder="<?php esc_attr_e('Unable to upload to cloud storage. Please check your connection and try again.', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Custom message when cloud storage upload fails. Supports any language.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Allow Multiple Files -->
                <div class="sf-field-row sf-allow-multiple-files-row" style="display: none;">
                    <label class="sf-toggle-label">
                        <div class="sf-toggle-switch">
                            <input type="checkbox" class="sf-allow-multiple-files">
                            <span class="sf-toggle-slider"></span>
                        </div>
                        <?php esc_html_e('Allow Multiple Files', 'sigmaforms-pro'); ?>
                    </label>
                    <p class="sf-field-description">
                        <?php esc_html_e('Enable this to allow users to upload multiple files at once.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Maximum Files Count -->
                <div class="sf-field-row sf-max-files-row" style="display: none;">
                    <label><?php esc_html_e('Maximum Number of Files', 'sigmaforms-pro'); ?></label>
                    <input type="number" class="sf-max-files" min="2" step="1"
                        placeholder="<?php esc_attr_e('e.g. 5', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Maximum number of files a user can upload. Leave empty for no limit.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Storage Location -->
                <div class="sf-field-row sf-storage-location-row" style="display: none;">
                    <label><?php esc_html_e('Storage Location', 'sigmaforms-pro'); ?></label>
                    <select class="sf-storage-location">
                        <option value="site"><?php esc_html_e('Site Storage', 'sigmaforms-pro'); ?></option>
                        <option value="email_attachment"><?php esc_html_e('Email Attachment Only (Don\'t Store)', 'sigmaforms-pro'); ?></option>
                        <?php
                        // Check if license is valid and cloud storage is configured and connected
                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables
                        $settings = get_option('sigmaforms_settings', array());
                        $google_connected = get_option('sf_google_drive_access_token');
                        $onedrive_connected = get_option('sf_onedrive_access_token');
                        $license_valid = \SigmaForms\Plugin::is_license_valid();
                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                        
                        if ($license_valid && $google_connected && !empty($settings['storage_google_drive_enabled'])) {
                            echo '<option value="google_drive">' . esc_html__('Google Drive', 'sigmaforms-pro') . '</option>';
                        }

                        if ($license_valid && $onedrive_connected && !empty($settings['storage_onedrive_enabled'])) {
                            echo '<option value="onedrive">' . esc_html__('OneDrive', 'sigmaforms-pro') . '</option>';
                        }
                        ?>
                    </select>
                    <p class="sf-field-description">
                        <?php 
                        if (!$license_valid) {
                            printf(
                                /* translators: %s: Link to license page */
                                esc_html__('Files will be uploaded to your site storage. To enable cloud storage, please %s.', 'sigmaforms-pro'),
                                '<a href="' . esc_url(admin_url('admin.php?page=sigmaforms_license')) . '" target="_blank">' . esc_html__('activate your license', 'sigmaforms-pro') . '</a>'
                            );
                        } elseif (!$google_connected && !$onedrive_connected) {
                            esc_html_e('Files will be uploaded to your site storage. To enable cloud storage, configure and connect Google Drive or OneDrive in Settings > Storage.', 'sigmaforms-pro');
                        } else {
                            esc_html_e('Choose where to store uploaded files. Site storage saves files on your server, while cloud storage uploads to the selected service.', 'sigmaforms-pro');
                        }
                        ?>
                    </p>
                </div>

                <!-- Textarea Height (only for textarea field type) -->
                <div class="sf-field-row sf-textarea-height-row" style="display: none;">
                    <label><?php esc_html_e('Height (px)', 'sigmaforms-pro'); ?></label>
                    <input type="number" class="sf-textarea-height" min="50" step="1"
                        placeholder="<?php esc_attr_e('e.g. 150', 'sigmaforms-pro'); ?>">
                    <p class="sf-field-description">
                        <?php esc_html_e('Set the height of the textarea in pixels. Leave empty for default height.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-field-row">
                    <label><?php esc_html_e('Placeholder', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-field-placeholder"
                        placeholder="<?php esc_attr_e('Placeholder text', 'sigmaforms-pro'); ?>">
                </div>
                <div class="sf-field-row">
                    <label><?php esc_html_e('Default Value', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-field-default"
                        placeholder="<?php esc_attr_e('Default value', 'sigmaforms-pro'); ?>">
                </div>

                <!-- Section Heading Underline Settings -->
                <div class="sf-field-row sf-section-underline-settings" style="display: none;">
                    <h4 style="margin: 20px 0 10px 0; font-size: 14px; color: #1d2327; border-top: 1px solid #ddd; padding-top: 15px;"><?php esc_html_e('Underline Style', 'sigmaforms-pro'); ?></h4>
                    
                    <div class="sf-field-row">
                        <label class="sf-toggle-label">
                            <span class="sf-toggle-switch">
                                <input type="checkbox" class="sf-section-show-underline" checked>
                                <span class="sf-toggle-slider"></span>
                            </span>
                            <?php esc_html_e('Show Underline', 'sigmaforms-pro'); ?>
                        </label>
                        <p class="sf-field-description">
                            <?php esc_html_e('Display an underline below the section heading.', 'sigmaforms-pro'); ?>
                        </p>
                    </div>

                    <div class="sf-underline-options">
                        <div style="display: flex; gap: 15px; align-items: flex-start;">
                            <div style="flex: 1;">
                                <label><?php esc_html_e('Underline Color', 'sigmaforms-pro'); ?></label>
                                <input type="color" class="sf-section-underline-color" value="#3b82f6" style="width: 100%; height: 38px; cursor: pointer;">
                            </div>

                            <div style="flex: 1;">
                                <label><?php esc_html_e('Thickness (px)', 'sigmaforms-pro'); ?></label>
                                <input type="number" class="sf-section-underline-thickness" min="0" max="20" step="1" value="3" placeholder="3">
                            </div>

                            <div style="flex: 1;">
                                <label><?php esc_html_e('Style', 'sigmaforms-pro'); ?></label>
                                <select class="sf-section-underline-style">
                                    <option value="solid"><?php esc_html_e('Solid', 'sigmaforms-pro'); ?></option>
                                    <option value="dashed"><?php esc_html_e('Dashed', 'sigmaforms-pro'); ?></option>
                                    <option value="dotted"><?php esc_html_e('Dotted', 'sigmaforms-pro'); ?></option>
                                    <option value="double"><?php esc_html_e('Double', 'sigmaforms-pro'); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Page Break Settings -->
                <div class="sf-field-row sf-page-break-settings" style="display: none;">
                    <label><?php esc_html_e('Next Button Text', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-page-break-next-text" placeholder="<?php esc_attr_e('Next', 'sigmaforms-pro'); ?>" value="Next">
                    <p class="sf-field-description">
                        <?php esc_html_e('Customize the text for the next button. Supports any language for translation.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-field-row sf-page-break-settings" style="display: none;">
                    <label><?php esc_html_e('Previous Button Text', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-page-break-previous-text" placeholder="<?php esc_attr_e('Previous', 'sigmaforms-pro'); ?>" value="Previous">
                    <p class="sf-field-description">
                        <?php esc_html_e('Customize the text for the previous button. Supports any language for translation.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-field-row sf-page-break-settings" style="display: none;">
                    <label><?php esc_html_e('Step Indicator Format', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-page-break-step-format" placeholder="<?php esc_attr_e('Step {current} of {total}', 'sigmaforms-pro'); ?>" value="Step {current} of {total}">
                    <p class="sf-field-description">
                        <?php esc_html_e('Customize the step indicator text. Use {current} for current step and {total} for total steps. Supports any language.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-field-row sf-page-break-settings" style="display: none;">
                    <label><?php esc_html_e('Validation Message', 'sigmaforms-pro'); ?></label>
                    <input type="text" class="sf-page-break-validation-message" placeholder="<?php esc_attr_e('Please fill in all required fields before proceeding.', 'sigmaforms-pro'); ?>" value="Please fill in all required fields before proceeding.">
                    <p class="sf-field-description">
                        <?php esc_html_e('Message shown when required fields are not filled before going to the next step. Supports any language for translation.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-field-row sf-page-break-settings" style="display: none;">
                    <label><?php esc_html_e('Button & Step Colors', 'sigmaforms-pro'); ?></label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 10px;">
                        <div>
                            <label style="font-size: 13px; color: #6b7280; margin-bottom: 5px; display: block;"><?php esc_html_e('Next Button Background', 'sigmaforms-pro'); ?></label>
                            <input type="color" class="sf-page-break-next-bg-color" value="#6366f1" style="width: 100%; height: 38px; cursor: pointer;">
                        </div>
                        <div>
                            <label style="font-size: 13px; color: #6b7280; margin-bottom: 5px; display: block;"><?php esc_html_e('Next Button Text', 'sigmaforms-pro'); ?></label>
                            <input type="color" class="sf-page-break-next-text-color" value="#ffffff" style="width: 100%; height: 38px; cursor: pointer;">
                        </div>
                        <div>
                            <label style="font-size: 13px; color: #6b7280; margin-bottom: 5px; display: block;"><?php esc_html_e('Prev Button Background', 'sigmaforms-pro'); ?></label>
                            <input type="color" class="sf-page-break-prev-bg-color" value="#ffffff" style="width: 100%; height: 38px; cursor: pointer;">
                        </div>
                        <div>
                            <label style="font-size: 13px; color: #6b7280; margin-bottom: 5px; display: block;"><?php esc_html_e('Prev Button Text', 'sigmaforms-pro'); ?></label>
                            <input type="color" class="sf-page-break-prev-text-color" value="#374151" style="width: 100%; height: 38px; cursor: pointer;">
                        </div>
                        <div style="grid-column: 1 / -1;">
                            <label style="font-size: 13px; color: #6b7280; margin-bottom: 5px; display: block;"><?php esc_html_e('Step Indicator Text', 'sigmaforms-pro'); ?></label>
                            <input type="color" class="sf-page-break-step-text-color" value="#6b7280" style="width: 100%; height: 38px; cursor: pointer;">
                        </div>
                    </div>
                    <p class="sf-field-description">
                        <?php esc_html_e('Customize the colors for navigation buttons and step indicator.', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <!-- Range Settings -->
                <div class="sf-field-row sf-range-settings-row" style="display: none;">
                    <div style="display: flex; gap: 10px;">
                        <div style="flex: 1;">
                            <label><?php esc_html_e('Min Value', 'sigmaforms-pro'); ?></label>
                            <input type="number" class="sf-range-min" placeholder="0" value="0">
                        </div>
                        <div style="flex: 1;">
                            <label><?php esc_html_e('Max Value', 'sigmaforms-pro'); ?></label>
                            <input type="number" class="sf-range-max" placeholder="100" value="100">
                        </div>
                        <div style="flex: 1;">
                            <label><?php esc_html_e('Step', 'sigmaforms-pro'); ?></label>
                            <input type="number" class="sf-range-step" placeholder="1" value="1">
                        </div>
                        <div style="flex: 1;">
                            <label><?php esc_html_e('Default', 'sigmaforms-pro'); ?></label>
                            <input type="number" class="sf-range-default" placeholder="50">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Group for Submit Button Settings -->
            <div class="sf-settings-group sf-settings-group-submit" style="display: none;">
                <div class="sf-field-row">
                    <label for="submit-button-text-input"><?php esc_html_e('Button Text', 'sigmaforms-pro'); ?></label>
                    <input type="text" id="submit-button-text-input" class="sf-submit-button-text-input">
                </div>
                <div class="sf-field-row">
                    <label for="submit-button-width-input"><?php esc_html_e('Button Width', 'sigmaforms-pro'); ?></label>
                    <select id="submit-button-width-input" class="sf-submit-button-width-input">
                        <option value="auto"><?php esc_html_e('Auto', 'sigmaforms-pro'); ?></option>
                        <option value="25"><?php esc_html_e('Quarter Width (25%)', 'sigmaforms-pro'); ?></option>
                        <option value="50"><?php esc_html_e('Half Width (50%)', 'sigmaforms-pro'); ?></option>
                        <option value="75"><?php esc_html_e('Three Quarter Width (75%)', 'sigmaforms-pro'); ?></option>
                        <option value="100"><?php esc_html_e('Full Width (100%)', 'sigmaforms-pro'); ?></option>
                    </select>
                </div>
                <div class="sf-field-row">
                    <label
                        for="submit-button-align-input"><?php esc_html_e('Button Alignment', 'sigmaforms-pro'); ?></label>
                    <select id="submit-button-align-input" class="sf-submit-button-align-input">
                        <option value="left"><?php esc_html_e('Left', 'sigmaforms-pro'); ?></option>
                        <option value="center"><?php esc_html_e('Center', 'sigmaforms-pro'); ?></option>
                        <option value="right"><?php esc_html_e('Right', 'sigmaforms-pro'); ?></option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Advanced Tab -->
        <div class="sf-settings-tab-panel" data-tab="advanced">
            <div class="sf-field-row">
                <label><?php esc_html_e('Column Width', 'sigmaforms-pro'); ?></label>
                <select class="sf-field-column-width">
                    <option value="100"><?php esc_html_e('Full Width (100%)', 'sigmaforms-pro'); ?></option>
                    <option value="75"><?php esc_html_e('Three Quarter (75%)', 'sigmaforms-pro'); ?></option>
                    <option value="66"><?php esc_html_e('Two Thirds (66%)', 'sigmaforms-pro'); ?></option>
                    <option value="50"><?php esc_html_e('Half Width (50%)', 'sigmaforms-pro'); ?></option>
                    <option value="33"><?php esc_html_e('One Third (33%)', 'sigmaforms-pro'); ?></option>
                    <option value="25"><?php esc_html_e('Quarter (25%)', 'sigmaforms-pro'); ?></option>
                </select>
            </div>
            <div class="sf-field-row">
                <label><?php esc_html_e('Label Position', 'sigmaforms-pro'); ?></label>
                <select class="sf-field-label-position">
                    <option value="left"><?php esc_html_e('Left', 'sigmaforms-pro'); ?></option>
                    <option value="center"><?php esc_html_e('Center', 'sigmaforms-pro'); ?></option>
                    <option value="right"><?php esc_html_e('Right', 'sigmaforms-pro'); ?></option>
                </select>
            </div>
            <div class="sf-field-row">
                <label><?php esc_html_e('Field Position', 'sigmaforms-pro'); ?></label>
                <select class="sf-field-position">
                    <option value="left"><?php esc_html_e('Left', 'sigmaforms-pro'); ?></option>
                    <option value="center"><?php esc_html_e('Center', 'sigmaforms-pro'); ?></option>
                    <option value="right"><?php esc_html_e('Right', 'sigmaforms-pro'); ?></option>
                </select>
            </div>
            <div class="sf-field-row sf-options-columns-row" style="display:none;">
                <label><?php esc_html_e('Options Columns', 'sigmaforms-pro'); ?></label>
                <select class="sf-field-options-columns">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                </select>
                <p class="sf-field-description">
                    <?php esc_html_e('Number of columns to display options in (for Checkbox/Radio fields).', 'sigmaforms-pro'); ?>
                </p>
            </div>
            <div class="sf-field-row">
                <label class="sf-toggle-label">
                    <span class="sf-toggle-switch">
                        <input type="checkbox" class="sf-field-required">
                        <span class="sf-toggle-slider"></span>
                    </span>
                    <?php esc_html_e('Required Field', 'sigmaforms-pro'); ?>
                </label>
            </div>
            <div class="sf-field-row">
                <label><?php esc_html_e('Required Error Message', 'sigmaforms-pro'); ?></label>
                <input type="text" class="sf-field-required-message"
                    placeholder="<?php esc_attr_e('e.g. This field is required', 'sigmaforms-pro'); ?>">
                <p class="sf-field-description">
                    <?php esc_html_e('Custom message shown when this required field is left empty. You can write it in any language.', 'sigmaforms-pro'); ?>
                </p>
            </div>
            <div class="sf-field-row sf-show-label-image-row" style="display:none;">
                <label class="sf-toggle-label">
                    <span class="sf-toggle-switch">
                        <input type="checkbox" class="sf-field-show-label-image" checked>
                        <span class="sf-toggle-slider"></span>
                    </span>
                    <?php esc_html_e('Show Field Label Image', 'sigmaforms-pro'); ?>
                </label>
                <p class="sf-field-description">
                    <?php esc_html_e('Display the label image on the frontend. Turn this off to keep the image saved but hidden.', 'sigmaforms-pro'); ?>
                </p>
            </div>
            <div class="sf-field-row">
                <label class="sf-toggle-label">
                    <span class="sf-toggle-switch">
                        <input type="checkbox" class="sf-field-show-label" checked>
                        <span class="sf-toggle-slider"></span>
                    </span>
                    <?php esc_html_e('Show Field Label Text', 'sigmaforms-pro'); ?>
                </label>
                <p class="sf-field-description">
                    <?php esc_html_e('Display the field label text on the frontend.', 'sigmaforms-pro'); ?>
                </p>
            </div>
            <div class="sf-field-row">
                <label><?php esc_html_e('CSS Classes', 'sigmaforms-pro'); ?></label>
                <input type="text" class="sf-field-css-class"
                    placeholder="<?php esc_attr_e('Additional CSS classes', 'sigmaforms-pro'); ?>">
            </div>
            <div class="sf-field-row sf-validation-message-row" style="display: none;">
                <label><?php esc_html_e('Format Validation Message', 'sigmaforms-pro'); ?></label>
                <input type="text" class="sf-field-validation-message"
                    placeholder="<?php esc_attr_e('e.g. Please enter a valid email address', 'sigmaforms-pro'); ?>">
                <p class="sf-field-description">
                    <?php esc_html_e('Custom message shown when the field value has an invalid format. Supports any language.', 'sigmaforms-pro'); ?>
                </p>
            </div>
            <div class="sf-field-row">
                <label><?php esc_html_e('Help Text', 'sigmaforms-pro'); ?></label>
                <textarea class="sf-field-help-text"
                    placeholder="<?php esc_attr_e('Help text to display below the field', 'sigmaforms-pro'); ?>"></textarea>
            </div>
        </div>

        <!-- Conditional Tab -->
        <div class="sf-settings-tab-panel" data-tab="conditional">
            <div class="sf-field-row">
                <label class="sf-toggle-label">
                    <span class="sf-toggle-switch">
                        <input type="checkbox" class="sf-field-has-conditional">
                        <span class="sf-toggle-slider"></span>
                    </span>
                    <?php esc_html_e('Enable Conditional Logic', 'sigmaforms-pro'); ?>
                </label>
                <p class="sf-field-description">
                    <?php esc_html_e('Control when this field appears or becomes active based on various conditions.', 'sigmaforms-pro'); ?>
                </p>
            </div>

            <div class="sf-conditional-rules" style="display: none;">
                <div class="sf-conditional-action-row">
                    <label><?php esc_html_e('Action:', 'sigmaforms-pro'); ?></label>
                    <select class="sf-conditional-action">
                        <option value="show"><?php esc_html_e('Show this field', 'sigmaforms-pro'); ?></option>
                        <option value="hide"><?php esc_html_e('Hide this field', 'sigmaforms-pro'); ?></option>
                        <option value="enable"><?php esc_html_e('Enable this field', 'sigmaforms-pro'); ?></option>
                        <option value="disable"><?php esc_html_e('Disable this field', 'sigmaforms-pro'); ?></option>
                    </select>

                    <select class="sf-conditional-logic-type">
                        <option value="all"><?php esc_html_e('if ALL conditions match (AND)', 'sigmaforms-pro'); ?></option>
                        <option value="any"><?php esc_html_e('if ANY condition matches (OR)', 'sigmaforms-pro'); ?></option>
                    </select>
                </div>

                <!-- Condition rule groups container -->
                <div class="sf-condition-groups">
                    <div class="sf-condition-group" data-group-id="0">
                        <!-- Individual rule -->
                        <div class="sf-condition-rule" data-rule-id="0">
                            <div class="sf-rule-field-container">
                                <select class="sf-rule-source-type">
                                    <option value="field"><?php esc_html_e('Form Field', 'sigmaforms-pro'); ?></option>
                                    <option value="user"><?php esc_html_e('User Data', 'sigmaforms-pro'); ?></option>
                                    <option value="date"><?php esc_html_e('Date/Time', 'sigmaforms-pro'); ?></option>
                                </select>

                                <!-- Field selector for form fields -->
                                <div class="sf-rule-field-selector sf-field-source-field">
                                    <select class="sf-conditional-field">
                                        <option value=""><?php esc_html_e('Select a field', 'sigmaforms-pro'); ?></option>
                                        <!-- Fields will be populated dynamically -->
                                    </select>
                                </div>

                                <!-- User data selector -->
                                <div class="sf-rule-field-selector sf-field-source-user" style="display: none;">
                                    <select class="sf-conditional-user-data">
                                        <option value="logged_in">
                                            <?php esc_html_e('User is logged in', 'sigmaforms-pro'); ?>
                                        </option>
                                        <option value="user_role"><?php esc_html_e('User role', 'sigmaforms-pro'); ?>
                                        </option>
                                        <option value="user_meta"><?php esc_html_e('User meta field', 'sigmaforms-pro'); ?>
                                        </option>
                                    </select>

                                    <input type="text" class="sf-conditional-user-meta-key"
                                        placeholder="<?php esc_attr_e('Meta key', 'sigmaforms-pro'); ?>"
                                        style="display: none;">
                                </div>

                                <!-- Date/Time selector -->
                                <div class="sf-rule-field-selector sf-field-source-date" style="display: none;">
                                    <select class="sf-conditional-date-type">
                                        <option value="current_date"><?php esc_html_e('Current date', 'sigmaforms-pro'); ?>
                                        </option>
                                        <option value="current_time"><?php esc_html_e('Current time', 'sigmaforms-pro'); ?>
                                        </option>
                                        <option value="current_day">
                                            <?php esc_html_e('Current day of week', 'sigmaforms-pro'); ?>
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="sf-rule-field-container-inner">

                                <!-- Operator selector -->
                                <div class="sf-rule-operator-container">
                                    <select class="sf-conditional-operator">
                                        <!-- Operators will be populated dynamically by JavaScript -->
                                    </select>
                                </div>

                                <!-- Value input -->
                                <div class="sf-rule-value-container">
                                    <input type="text" class="sf-conditional-value"
                                        placeholder="<?php esc_attr_e('Value', 'sigmaforms-pro'); ?>">
                                </div>
                            </div>

                            <!-- Rule controls -->
                            <div class="sf-rule-controls">
                                <button type="button" class="sf-add-rule"
                                    title="<?php esc_attr_e('Add another condition', 'sigmaforms-pro'); ?>">
                                    <span class="dashicons dashicons-plus-alt"></span>
                                </button>
                                <button type="button" class="sf-remove-rule"
                                    title="<?php esc_attr_e('Remove this condition', 'sigmaforms-pro'); ?>">
                                    <span class="dashicons dashicons-no-alt"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Add condition group button (for OR logic between groups) -->
                <div class="sf-add-condition-group-row">
                    <button type="button" class="sf-btn sf-btn-secondary sf-add-condition-group">
                        <span class="dashicons dashicons-plus-alt2"></span>
                        <?php esc_html_e('Add OR Group', 'sigmaforms-pro'); ?>
                    </button>
                </div>

                <!-- AI Suggestion -->
                <div class="sf-ai-suggestion-row" style="display: none;">
                    <button type="button" class="sf-btn sf-btn-primary sf-ai-suggest-conditions">
                        <span class="dashicons dashicons-admin-customizer"></span>
                        <?php esc_html_e('AI: Suggest Smart Conditions', 'sigmaforms-pro'); ?>
                    </button>
                    <div class="sf-ai-suggestions" style="display: none;">
                        <!-- AI suggestions will appear here -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Math Function Tab -->
        <div class="sf-settings-tab-panel" data-tab="math">
            <div class="sf-field-row">
                <label class="sf-toggle-label">
                    <span class="sf-toggle-switch">
                        <input type="checkbox" class="sf-field-has-math">
                        <span class="sf-toggle-slider"></span>
                    </span>
                    <?php esc_html_e('Enable Math Function', 'sigmaforms-pro'); ?>
                </label>
                <p class="sf-field-description">
                    <?php esc_html_e('Enable mathematical calculations for this field.', 'sigmaforms-pro'); ?>
                </p>
            </div>

            <div class="sf-math-rules" style="display: none;">
                <div class="sf-math-action-row">
                    <label><?php esc_html_e('Calculation Type:', 'sigmaforms-pro'); ?></label>
                    <select class="sf-math-calculation-type">
                        <option value="sum"><?php esc_html_e('Sum', 'sigmaforms-pro'); ?></option>
                        <option value="subtract"><?php esc_html_e('Subtract', 'sigmaforms-pro'); ?></option>
                        <option value="multiply"><?php esc_html_e('Multiply', 'sigmaforms-pro'); ?></option>
                        <option value="divide"><?php esc_html_e('Divide', 'sigmaforms-pro'); ?></option>
                        <option value="percentage"><?php esc_html_e('Percentage', 'sigmaforms-pro'); ?></option>
                        <option value="average"><?php esc_html_e('Average', 'sigmaforms-pro'); ?></option>
                        <option value="custom"><?php esc_html_e('Custom Formula', 'sigmaforms-pro'); ?></option>
                    </select>
                </div>

                <div class="sf-math-fields-container">
                    <label><?php esc_html_e('Select Fields for Calculation:', 'sigmaforms-pro'); ?></label>
                    <div class="sf-math-fields-list">
                        <!-- Math fields will be populated dynamically -->
                    </div>
                    <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-add-math-field">
                        <span class="dashicons dashicons-plus-alt2"></span>
                        <?php esc_html_e('Add Field', 'sigmaforms-pro'); ?>
                    </button>
                    <div class="sf-math-field-info">
                        <strong><?php esc_html_e('Note:', 'sigmaforms-pro'); ?></strong>
                        <?php esc_html_e('Math function fields are automatically disabled (read-only) on the frontend so users can see calculated results without editing them.', 'sigmaforms-pro'); ?>
                    </div>
                </div>

                <div class="sf-math-custom-formula" style="display: none;">
                    <label><?php esc_html_e('Custom Formula:', 'sigmaforms-pro'); ?></label>
                    <textarea class="sf-math-formula"
                        placeholder="<?php esc_attr_e('Enter custom formula (e.g., field1 + field2 * 0.1)', 'sigmaforms-pro'); ?>"></textarea>
                    <p class="sf-field-description">
                        <?php esc_html_e('Use field names in square brackets [field_name] and standard mathematical operators (+, -, *, /, %, ^).', 'sigmaforms-pro'); ?>
                    </p>
                </div>

                <div class="sf-math-options">
                    <label class="sf-toggle-label">
                        <span class="sf-toggle-switch">
                            <input type="checkbox" class="sf-math-round-result">
                            <span class="sf-toggle-slider"></span>
                        </span>
                        <?php esc_html_e('Round Result', 'sigmaforms-pro'); ?>
                    </label>

                    <div class="sf-math-round-options" style="display: none;">
                        <label><?php esc_html_e('Decimal Places:', 'sigmaforms-pro'); ?></label>
                        <select class="sf-math-decimal-places">
                            <option value="0">0 (Whole number)</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                        </select>
                    </div>
                </div>

                <div class="sf-math-preview">
                    <label><?php esc_html_e('Preview:', 'sigmaforms-pro'); ?></label>
                    <div class="sf-math-preview-result">
                        <span
                            class="sf-math-preview-text"><?php esc_html_e('Formula preview will appear here', 'sigmaforms-pro'); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sf-field-settings-footer">
        <button type="button"
            class="sf-btn sf-btn-secondary sf-cancel-settings"><?php esc_html_e('Cancel', 'sigmaforms-pro'); ?></button>
        <button type="button"
            class="sf-btn sf-btn-primary sf-save-settings"><?php esc_html_e('Save Changes', 'sigmaforms-pro'); ?></button>
    </div>
</div>