<?php
/**
 * Form data initialization for JavaScript
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- Hidden container to store field data for JavaScript -->
<div id="sf-fields-data" class="sf-hidden-data">
    <?php if ($is_edit) : ?>
        <script type="text/javascript">
            // Pre-process form fields to ensure they're valid
            <?php 
            // Ensure form fields is properly formatted for JavaScript
            // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
            $js_form_fields = array_map(function($field) {
                // Make sure options is always an array
                if (!isset($field['options']) || !is_array($field['options'])) {
                    $field['options'] = [];
                }
                // Ensure other required properties are set
                if (!isset($field['id'])) {
                    $field['id'] = 'field_' . uniqid();
                }
                if (!isset($field['column_width'])) {
                    $field['column_width'] = '100';
                }
                // Migration: Add name property if not present (use id as fallback)
                if (!isset($field['name'])) {
                    $field['name'] = $field['id'];
                }
                // Migration: Add default_value property if not present
                if (!isset($field['default_value'])) {
                    $field['default_value'] = '';
                }
                // Preserve selected_countries for country fields
                if (isset($field['selected_countries']) && is_array($field['selected_countries'])) {
                    // Keep the selected_countries property as is
                }
                // Preserve default_country for phone_international fields
                if (isset($field['default_country'])) {
                    // Keep the default_country property as is
                }
                // Preserve selected_phone_countries for phone_international fields
                if (isset($field['selected_phone_countries']) && is_array($field['selected_phone_countries'])) {
                    // Keep the selected_phone_countries property as is
                }
                // Preserve available_countries for phone_international fields
                if (isset($field['available_countries']) && is_array($field['available_countries'])) {
                    // Keep the available_countries property as is
                }
                return $field;
            }, $form_fields);
            // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
            ?>
            
            // Initialize the form fields global variable
            var sfFieldsData = <?php echo json_encode($js_form_fields); ?>;
            
            // Initialize form settings
            window.sfFormSettings = <?php echo json_encode($form_settings); ?>;
            
            // Add form name to settings for JavaScript access
            window.sfFormSettings.title = <?php echo json_encode($form_title); ?>;
            
            // Add initialization complete flag
            window.sfEditorInitialized = true;
        </script>
    <?php else : ?>
        <script type="text/javascript">
            var sfFieldsData = [];
            
            // Initialize form settings with defaults for new forms
            window.sfFormSettings = {
                submit_button_text: 'Submit',
                submit_button_width: 'auto',
                success_message: 'Thank you for your submission!',
                override_email_settings: false,
                email_subject: '',
                email_message: '',
                to_email: '',
                send_confirmation_email: false,
                confirmation_subject: '',
                confirmation_message: '',
                enable_recaptcha: false,
                enable_hcaptcha: false,
                enable_turnstile: false,
                enable_cleantalk: false,
                enable_mtcaptcha: false,
                store_submissions: true,
                // Webhook settings - default to false
                webhook_google_sheets_use: false,

                webhook_slack_use: false,
                webhook_discord_use: false,
                webhook_telegram_use: false,
                webhook_custom_use: false,
                // Webhook URLs and settings - default to empty
                webhook_google_sheets_url: '',

                webhook_slack_url: '',
                webhook_slack_channel: '',
                webhook_discord_url: '',
                webhook_telegram_bot_token: '',
                webhook_telegram_chat_id: '',
                webhook_custom_url: '',
                webhook_custom_method: 'POST'
            };
            
            window.sfEditorInitialized = true;
        </script>
    <?php endif; ?>
</div>
