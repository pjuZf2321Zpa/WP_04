<?php
/**
 * Step 1: AI Form Generation
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
$api_key = get_option('sf_ai_api_key', '');
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>

<!-- Step 1: AI Form Generation (Only for new forms) -->
<div class="sf-wizard-step-content active" data-step="1">
    <div
        class="sf-ai-generator-page sf-ai-generator-wrapper<?php if (empty($api_key))
            echo ' sf-no-api-key'; ?>">


        <!-- Main Content Card -->
        <div class="sf-card sf-ai-generator-card">
            <div class="">
                <!-- Input Section -->
                <div class="sf-ai-input-section">
                    <label for="sf-ai-prompt" class="sf-ai-input-label">
                        <span
                            class="sf-ai-label-text"><?php esc_html_e('Describe your form', 'sigmaforms-pro'); ?></span>
                        <span
                            class="sf-ai-label-hint"><?php esc_html_e('Be specific about fields, layout, and functionality you need', 'sigmaforms-pro'); ?></span>
                    </label>
                    <div class="sf-ai-prompt-container">
                        <textarea id="sf-ai-prompt" class="sf-ai-prompt-textarea"
                            placeholder="<?php esc_attr_e('e.g., Create a contact form with name and email in the first row, phone and subject in the second row, and a full-width message field. Include validation and send confirmation emails.', 'sigmaforms-pro'); ?>"></textarea>
                        <div class="sf-ai-prompt-features">
                            <div class="sf-ai-feature">
                                <span class="sf-ai-feature-icon">✨</span>
                                <span><?php esc_html_e('Smart field detection', 'sigmaforms-pro'); ?></span>
                            </div>
                            <div class="sf-ai-feature">
                                <span class="sf-ai-feature-icon">🎯</span>
                                <span><?php esc_html_e('Automatic validation rules', 'sigmaforms-pro'); ?></span>
                            </div>
                            <div class="sf-ai-feature">
                                <span class="sf-ai-feature-icon">📱</span>
                                <span><?php esc_html_e('Responsive layout', 'sigmaforms-pro'); ?></span>
                            </div>
                        </div>
                    </div>
                    <!-- Result Message -->
                    <div class="sf-ai-result-message" style="display: none;"></div>
                    <!-- Action Buttons -->
                    <div class="sf-ai-actions">
                        <?php if (SigmaForms\Plugin::is_license_valid()): ?>
                            <button type="button" class="sf-btn sf-btn-primary sf-btn-lg sf-ai-generate-button">
                                <span class="sf-btn-icon">
                                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                                        <path
                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                </span>
                                <span
                                    class="sf-btn-text"><?php esc_html_e('Generate Form with AI', 'sigmaforms-pro'); ?></span>
                            </button>
                            <button type="button" class="sf-btn sf-btn-success sf-btn-lg sf-next-step"
                                data-goto="2" style="display: none;">
                                <span class="sf-btn-icon">
                                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd"
                                            d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </span>
                                <span
                                    class="sf-btn-text"><?php esc_html_e('Continue to Customize', 'sigmaforms-pro'); ?></span>
                            </button>
                        <?php else: ?>
                            <?php if ($api_key == ''): ?>
                                <a class="sf-btn sf-btn-primary sf-btn-lg"
                                    style="background: linear-gradient(135deg, #d63638 0%, #7b6868 100%); color: white;"
                                    href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-settings')); ?>">
                                    <span
                                        class="sf-btn-text"><?php esc_html_e('SigmaForms AI License Required', 'sigmaforms-pro'); ?></span>
                                </a>
                            <?php else: ?>
                                <a class="sf-btn sf-btn-primary sf-btn-lg"
                                    style="background: linear-gradient(135deg, #d63638 0%, #7b6868 100%); color: white;"
                                    href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms_license')); ?>">
                                    <span
                                        class="sf-btn-text"><?php esc_html_e('SigmaForms License Required', 'sigmaforms-pro'); ?></span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Examples Section -->
                <div class="sf-ai-examples-section">
                    <div class="sf-ai-examples-content">
                        <div
                            style="display: flex; justify-content:space-between;align-items: baseline; margin-bottom: 15px;">
                            <h4><?php esc_html_e('Popular form prompt types:', 'sigmaforms-pro'); ?></h4>
                            <?php if (SigmaForms\Plugin::is_license_valid() || SigmaForms\Plugin::can_create_more_forms()): ?>
                                <button type="button" class="sf-manual-create-btn sf-btn sf-btn-primary">
                                    <span class="sf-btn-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" />
                                        </svg>
                                    </span>
                                    <span><?php esc_html_e('Click here for Pre-built Templates', 'sigmaforms-pro'); ?></span>
                                </button>
                            <?php else: ?>
                                <span
                                    style="color: #d63638; font-weight: bold; font-size: 15px;"><?php esc_html_e('You have reached the maximum number of creating free forms.', 'sigmaforms-pro'); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="sf-ai-examples-grid">
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a contact form that includes fields for name, email, phone number, and message. All fields should be marked as required.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📧</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Contact Form', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Basic contact form with essential fields', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a job application form with personal details, experience, and file upload for resume', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💼</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Job Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Comprehensive form for job applications', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a registration form with conditional shipping address fields that appear when shipping is required', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📝</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Registration Form', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Smart registration with conditional logic', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Make a survey form with rating scales, multiple choice questions, and optional comment fields', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📊</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Survey Form', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Detailed survey with various field types', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create an event registration form with conditional ticket type pricing, dietary restrictions that show only when catering is selected, and group booking options', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎫</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Event Registration', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Complex event form with pricing and conditional fields', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a product order form with conditional fields: size and color options that change based on product selection, shipping calculator based on location, and quantity discounts', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🛒</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Product Order Form', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('E-commerce form with dynamic product options', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a multi-step appointment booking form: service selection shows available staff, date picker shows only available slots, and additional services appear based on main service selection', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📅</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Appointment Booking', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Smart booking with staff and time availability', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a membership application form with conditional logic: membership type determines visible benefits and pricing, payment frequency affects total cost, and additional family member fields appear for family plans', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">👥</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Membership Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Dynamic membership form with pricing logic', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a newsletter signup form with fields for name, email, and frequency preferences. Include GDPR consent checkbox.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📰</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Newsletter Signup', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Simple opt-in with consent', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a customer feedback form with rating scales, service categories, and optional comments.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💬</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Customer Feedback', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Ratings and comments for service', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a quote request form for services with project details, budget range, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💰</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Quote Request', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Project details and budget', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a support ticket form with issue description, priority selection, and contact information.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🆘</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Support Ticket', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Issue reporting with priority', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a donation form with amount selection, payment method, and option for tax receipt.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">❤️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Donation Form', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Flexible donation with receipt', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a volunteer registration form with skills, availability, and areas of interest.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🤝</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Volunteer Registration', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Skills and availability for volunteers', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a workshop registration form with session selection, skill level, and experience.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🔧</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Workshop Registration', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Session and skill-based registration', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a consultation booking form with service type, preferred time, and notes.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎯</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Consultation Booking', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Book a service with notes', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a testimonial submission form with rating, review text, and permission to publish.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">⭐</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Testimonial Submission', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Collect reviews and ratings', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a partnership inquiry form with company info, partnership goals, and contact details.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🤝</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Partnership Inquiry', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Business partnership requests', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a wholesale application form with business license, order volume, and tax ID fields.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📦</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Wholesale Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('For bulk buyers and resellers', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build an affiliate program signup form with website info, traffic stats, and marketing channels.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🔗</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Affiliate Program', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Recruit affiliates for your brand', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a beta testing application form with device info, use cases, and feedback preferences.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🧪</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Beta Testing', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Collect beta tester details', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a referral program form with referrer info, referred contact, and relationship.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📞</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Referral Program', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Track referrals and rewards', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a waitlist signup form with product interest, launch preferences, and contact info.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">⏳</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Waitlist Signup', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Join waitlists for new products', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a contest entry form with entry details, age verification, and terms acceptance.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏆</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Contest Entry', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Enter competitions and giveaways', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a webinar registration form with topic selection, experience level, and questions.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💻</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Webinar Registration', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Sign up for online events', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a demo request form with company size, use case, and preferred time.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎬</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Demo Request', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Request a product demonstration', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a free trial signup form with company info, use case, and optional credit card field.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🚀</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Free Trial Signup', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Start a free trial easily', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a custom project inquiry form with project requirements, budget, timeline, and contact info.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">⚙️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Custom Project', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Tailored project requests', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a invoice request form with company info, services, amount, and payment terms.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🧾</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Invoice Request', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Company info, Services, Amount, Payment terms', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a refund request form with order details, reason, and refund method.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💸</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Refund Request', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Order details, Reason, Refund method', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a warranty claim form with product info, issue description, and proof of purchase.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🔧</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Warranty Claim', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Product info, Issue description, Proof of purchase', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a course enrollment form with course selection, learning goals, and payment plan.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📚</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Course Enrollment', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Course selection, Learning goals, Payment plan', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a mentorship application form with experience level, goals, and preferred mentor type.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎯</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Mentorship Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Experience level, Goals, Preferred mentor type', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a networking event form with company info, industry, and networking goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🤝</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Networking Event', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Company info, Industry, Networking goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a health appointment form with patient info, appointment type, and symptoms.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏥</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Health Appointment', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Patient info, Appointment type, Symptoms', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a legal consultation form with legal issue type, urgency, and case description.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">⚖️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Legal Consultation', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Legal issue type, Urgency, Case description', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a community service form with service type, location, and volunteers needed.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏘️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Community Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Service type, Location, Volunteers needed', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a real estate inquiry form with property type, budget, and location preferences.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏠</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Real Estate Inquiry', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Property type, Budget, Location preferences', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a travel booking form with destination, dates, and travel preferences.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">✈️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Travel Booking', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Destination, Dates, Travel preferences', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a restaurant reservation form with date, time, party size, and special requests.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🍽️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Restaurant Reservation', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Date, Time, Party size, Special requests', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a pet sitting service form with pet details, service dates, and special needs.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🐕</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Pet Sitting Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Pet details, Service dates, Special needs', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a house cleaning form with service type, schedule, and home details.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🧹</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('House Cleaning', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Service type, Schedule, Home details', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a landscaping service form with service type, property size, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🌿</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Landscaping Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Service type, Property size, Timeline', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a catering request form with event type, guest count, and dietary needs.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🍰</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Catering Request', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Event type, Guest count, Dietary needs', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a photography session form with session type, location, and date preferences.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📸</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Photography Session', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Session type, Location, Date preferences', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a music lessons form with instrument, skill level, and schedule.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎵</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Music Lessons', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Instrument, Skill level, Schedule', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a fitness training form with goals, experience level, and schedule.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💪</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Fitness Training', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Goals, Experience level, Schedule', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a massage therapy form with massage type, health concerns, and schedule.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💆</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Massage Therapy', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Massage type, Health concerns, Schedule', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a dental appointment form with service type, symptoms, and insurance info.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🦷</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Dental Appointment', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Service type, Symptoms, Insurance info', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a therapy session form with therapy type, concerns, and schedule.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🧠</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Therapy Session', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Therapy type, Concerns, Schedule', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a financial planning form with financial goals, current situation, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📊</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Financial Planning', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Financial goals, Current situation, Timeline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a tax preparation form with tax year, income sources, and deductions.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📋</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Tax Preparation', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Tax year, Income sources, Deductions', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create an insurance quote form with insurance type, coverage needs, and personal info.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🛡️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Insurance Quote', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Insurance type, Coverage needs, Personal info', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a loan application form with loan type, amount, and income verification.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💳</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Loan Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Loan type, Amount, Income verification', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a credit repair service form with credit issues, goals, and current situation.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🔧</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Credit Repair Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Credit issues, Goals, Current situation', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build an investment consultation form with investment goals, risk tolerance, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📈</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Investment Consultation', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Investment goals, Risk tolerance, Timeline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create an estate planning form with assets, beneficiaries, and legal documents.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏛️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Estate Planning', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Assets, Beneficiaries, Legal documents', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a retirement planning form with current age, retirement goals, and savings.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🌅</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Retirement Planning', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Current age, Retirement goals, Savings', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a college planning form with student info, college preferences, and financial aid.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎓</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('College Planning', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Student info, College preferences, Financial aid', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a scholarship application form with academic info, achievements, and financial need.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏆</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Scholarship Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Academic info, Achievements, Financial need', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a student loan application form with school info, loan amount, and co-signer.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📚</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Student Loan Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('School info, Loan amount, Co-signer', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a graduate school application form with program info, academic background, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎯</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Graduate School Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Program info, Academic background, Goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a study abroad program form with destination, program type, and language skills.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🌍</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Study Abroad Program', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Destination, Program type, Language skills', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build an internship application form with position, skills, availability, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💼</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Internship Application', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Position, Skills, Availability, Goals', 'sigmaforms-pro'); ?></p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a freelance project form with project scope, skills needed, budget, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💻</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Freelance Project', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Project scope, Skills needed, Budget, Timeline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a virtual assistant service form with service type, hours needed, and skills required.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">👩‍💼</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Virtual Assistant Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Service type, Hours needed, Skills required', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a social media management form with platforms, content type, frequency, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📱</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Social Media Management', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Platforms, Content type, Frequency, Goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build an SEO consultation form with website info, current performance, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🔍</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('SEO Consultation', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Website info, Current performance, Goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a content writing service form with content type, word count, topic, and deadline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">✍️</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Content Writing Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Content type, Word count, Topic, Deadline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a graphic design project form with design type, style preferences, usage, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎨</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Graphic Design Project', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Design type, Style preferences, Usage, Timeline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a web development form with website type, features, design preferences, and budget.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🌐</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Web Development', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Website type, Features, Design preferences, Budget', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a mobile app development form with app type, platform, features, and target audience.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📱</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Mobile App Development', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('App type, Platform, Features, Target audience', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create an e-commerce setup form with product type, payment methods, shipping, and features.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🛒</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('E-commerce Setup', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Product type, Payment methods, Shipping, Features', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build an email marketing setup form with audience size, email frequency, content type, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📧</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Email Marketing Setup', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Audience size, Email frequency, Content type, Goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a PPC campaign setup form with platform, budget, target audience, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💰</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('PPC Campaign Setup', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Platform, Budget, Target audience, Goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a brand consultation form with business type, target audience, brand goals, and current status.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🎯</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Brand Consultation', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Business type, Target audience, Brand goals, Current status', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a market research form with industry, target market, research goals, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📊</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Market Research', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Industry, Target market, Research goals, Timeline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a business plan development form with business concept, market analysis, and financial projections.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📋</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Business Plan Development', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Business concept, Market analysis, Financial projections', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a franchise inquiry form with franchise interest, location, investment range, and experience.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🏢</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Franchise Inquiry', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Franchise interest, Location, Investment range, Experience', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a business consulting form with business challenges, industry, company size, and goals.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💼</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Business Consulting', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Business challenges, Industry, Company size, Goals', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create an HR consulting form with HR challenges, company size, industry, and specific needs.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">👥</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('HR Consulting', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('HR challenges, Company size, Industry, Specific needs', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build an accounting service form with service type, business size, industry, and timeline.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">🧮</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Accounting Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Service type, Business size, Industry, Timeline', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Create a bookkeeping service form with transaction volume, frequency, and software preferences.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">📚</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Bookkeeping Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Transaction volume, Frequency, Software preferences', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="sf-ai-example-item"
                                data-prompt="<?php esc_attr_e('Build a payroll service form with employee count, pay frequency, and tax filing needs.', 'sigmaforms-pro'); ?>">
                                <div class="sf-ai-example-icon">💵</div>
                                <div class="sf-ai-example-content">
                                    <h5><?php esc_html_e('Payroll Service', 'sigmaforms-pro'); ?></h5>
                                    <p><?php esc_html_e('Employee count, Pay frequency, Tax filing needs', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Remove unified alert, restore original warning and fallback messages -->
        <!-- Loading State -->
        <div class="sf-ai-loading-state" style="display: none;">
            <div class="sf-ai-loading-content">
                <div class="sf-ai-loading-animation">
                    <div class="sf-ai-loading-dot"></div>
                    <div class="sf-ai-loading-dot"></div>
                    <div class="sf-ai-loading-dot"></div>
                </div>
                <h3><?php esc_html_e('AI is creating your form...', 'sigmaforms-pro'); ?></h3>
                <p><?php esc_html_e('This usually takes just a few seconds', 'sigmaforms-pro'); ?></p>
            </div>
        </div>
    </div>
    <!-- Pre-built Templates Picker (hidden by default, shown on AI error or no key) -->
    <div class="sf-prebuilt-templates" style="display:none; margin-top:32px;">
        <div class="sf-prebuilt-templates-header">
            <h3><?php esc_html_e('Choose a Pre-built Template', 'sigmaforms-pro'); ?></h3>
            <?php
            // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
            $can_create = SigmaForms\Plugin::is_license_valid() || SigmaForms\Plugin::can_create_more_forms();
            // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
            if (!$can_create):
                ?>
                <span
                    style="color: #d63638; font-weight: bold; font-size: 15px;"><?php esc_html_e('You have reached the maximum number of creating free forms.', 'sigmaforms-pro'); ?></span>
            <?php endif; ?>
            <div class="sf-prebuilt-templates-actions">
                <button type="button" class="sf-direct-manual-btn sf-btn sf-btn-primary" <?php echo !$can_create ? 'disabled style="opacity: 0.5; cursor: not-allowed;"' : ''; ?>>
                    <?php echo \SigmaForms\Admin\PageHeader::icon('pen'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <?php esc_html_e('Create Manually', 'sigmaforms-pro'); ?>
                </button>
            </div>
        </div>
        <div class="sf-prebuilt-templates-grid" <?php echo !$can_create ? 'style="pointer-events: none; opacity: 0.5;"' : ''; ?>>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="contact">
                <div class="sf-ai-example-icon">📧</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Contact Form', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Basic contact form with essential fields', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="job">
                <div class="sf-ai-example-icon">💼</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Job Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Comprehensive form for job applications', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="survey">
                <div class="sf-ai-example-icon">📊</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Survey', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Multiple choice, Ratings, Comments', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="event">
                <div class="sf-ai-example-icon">🎫</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Event Registration', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Attendee info, Ticket type, Dietary restrictions', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="product">
                <div class="sf-ai-example-icon">🛒</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Product Order Form', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Product selection, Quantity, Shipping address', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="appointment">
                <div class="sf-ai-example-icon">📅</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Appointment Booking', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service selection, Staff availability, Date picker', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="membership">
                <div class="sf-ai-example-icon">👥</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Membership Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Membership type, Pricing, Payment frequency', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="newsletter">
                <div class="sf-ai-example-icon">📰</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Newsletter Signup', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Email, Name, Interests, Frequency preferences', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="feedback">
                <div class="sf-ai-example-icon">💬</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Customer Feedback', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Rating scales, Comments, Service categories', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="quote">
                <div class="sf-ai-example-icon">💰</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Quote Request', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Project details, Budget range, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="support">
                <div class="sf-ai-example-icon">🆘</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Support Ticket', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Issue description, Priority, Contact info', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="donation">
                <div class="sf-ai-example-icon">❤️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Donation Form', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Amount selection, Payment method, Tax receipt', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="volunteer">
                <div class="sf-ai-example-icon">🤝</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Volunteer Registration', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Skills, Availability, Areas of interest', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="workshop">
                <div class="sf-ai-example-icon">🔧</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Workshop Registration', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Workshop selection, Skill level, Experience', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="consultation">
                <div class="sf-ai-example-icon">🎯</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Consultation Booking', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Preferred time, Consultation notes', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="testimonial">
                <div class="sf-ai-example-icon">⭐</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Testimonial Submission', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Rating, Review text, Permission to publish', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="partnership">
                <div class="sf-ai-example-icon">🤝</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Partnership Inquiry', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Company info, Partnership goals, Contact details', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="wholesale">
                <div class="sf-ai-example-icon">📦</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Wholesale Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Business license, Order volume, Tax ID', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="affiliate">
                <div class="sf-ai-example-icon">🔗</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Affiliate Program', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Website info, Traffic stats, Marketing channels', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="beta">
                <div class="sf-ai-example-icon">🧪</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Beta Testing', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Device info, Use cases, Feedback preferences', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="referral">
                <div class="sf-ai-example-icon">📞</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Referral Program', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Referrer info, Referred contact, Relationship', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="waitlist">
                <div class="sf-ai-example-icon">⏳</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Waitlist Signup', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Product interest, Launch preferences, Contact info', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="contest">
                <div class="sf-ai-example-icon">🏆</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Contest Entry', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Entry details, Age verification, Terms acceptance', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="webinar">
                <div class="sf-ai-example-icon">💻</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Webinar Registration', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Webinar topic, Experience level, Questions', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="demo">
                <div class="sf-ai-example-icon">🎬</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Demo Request', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Company size, Use case, Preferred time', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="trial">
                <div class="sf-ai-example-icon">🚀</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Free Trial Signup', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Company info, Use case, Credit card (optional)', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="custom">
                <div class="sf-ai-example-icon">⚙️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Custom Project', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Project requirements, Budget, Timeline, Contact', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="invoice">
                <div class="sf-ai-example-icon">🧾</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Invoice Request', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Company info, Services, Amount, Payment terms', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="refund">
                <div class="sf-ai-example-icon">💸</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Refund Request', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Order details, Reason, Refund method', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="warranty">
                <div class="sf-ai-example-icon">🔧</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Warranty Claim', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Product info, Issue description, Proof of purchase', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="course_enrollment">
                <div class="sf-ai-example-icon">📚</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Course Enrollment', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Course selection, Learning goals, Payment plan', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="mentorship">
                <div class="sf-ai-example-icon">🎯</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Mentorship Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Experience level, Goals, Preferred mentor type', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="networking">
                <div class="sf-ai-example-icon">🤝</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Networking Event', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Company info, Industry, Networking goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="health_appointment">
                <div class="sf-ai-example-icon">🏥</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Health Appointment', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Patient info, Appointment type, Symptoms', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="legal_consultation">
                <div class="sf-ai-example-icon">⚖️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Legal Consultation', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Legal issue type, Urgency, Case description', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="community_service">
                <div class="sf-ai-example-icon">🏘️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Community Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Location, Volunteers needed', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="real_estate">
                <div class="sf-ai-example-icon">🏠</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Real Estate Inquiry', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Property type, Budget, Location preferences', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="travel_booking">
                <div class="sf-ai-example-icon">✈️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Travel Booking', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Destination, Dates, Travel preferences', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="restaurant_reservation">
                <div class="sf-ai-example-icon">🍽️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Restaurant Reservation', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Date, Time, Party size, Special requests', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="pet_sitting">
                <div class="sf-ai-example-icon">🐕</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Pet Sitting Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Pet details, Service dates, Special needs', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="house_cleaning">
                <div class="sf-ai-example-icon">🧹</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('House Cleaning', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Schedule, Home details', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="landscaping">
                <div class="sf-ai-example-icon">🌿</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Landscaping Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Property size, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="catering">
                <div class="sf-ai-example-icon">🍰</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Catering Request', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Event type, Guest count, Dietary needs', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="photography">
                <div class="sf-ai-example-icon">📸</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Photography Session', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Session type, Location, Date preferences', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="music_lessons">
                <div class="sf-ai-example-icon">🎵</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Music Lessons', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Instrument, Skill level, Schedule', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="fitness_training">
                <div class="sf-ai-example-icon">💪</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Fitness Training', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Goals, Experience level, Schedule', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="massage_therapy">
                <div class="sf-ai-example-icon">💆</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Massage Therapy', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Massage type, Health concerns, Schedule', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="dental_appointment">
                <div class="sf-ai-example-icon">🦷</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Dental Appointment', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Symptoms, Insurance info', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="therapy_session">
                <div class="sf-ai-example-icon">🧠</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Therapy Session', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Therapy type, Concerns, Schedule', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="financial_planning">
                <div class="sf-ai-example-icon">📊</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Financial Planning', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Financial goals, Current situation, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="tax_preparation">
                <div class="sf-ai-example-icon">📋</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Tax Preparation', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Tax year, Income sources, Deductions', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="insurance_quote">
                <div class="sf-ai-example-icon">🛡️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Insurance Quote', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Insurance type, Coverage needs, Personal info', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="loan_application">
                <div class="sf-ai-example-icon">💳</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Loan Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Loan type, Amount, Income verification', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="credit_repair">
                <div class="sf-ai-example-icon">🔧</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Credit Repair Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Credit issues, Goals, Current situation', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="investment_consultation">
                <div class="sf-ai-example-icon">📈</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Investment Consultation', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Investment goals, Risk tolerance, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="estate_planning">
                <div class="sf-ai-example-icon">🏛️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Estate Planning', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Assets, Beneficiaries, Legal documents', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="retirement_planning">
                <div class="sf-ai-example-icon">🌅</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Retirement Planning', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Current age, Retirement goals, Savings', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="college_planning">
                <div class="sf-ai-example-icon">🎓</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('College Planning', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Student info, College preferences, Financial aid', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="scholarship_application">
                <div class="sf-ai-example-icon">🏆</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Scholarship Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Academic info, Achievements, Financial need', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="student_loan">
                <div class="sf-ai-example-icon">📚</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Student Loan Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('School info, Loan amount, Co-signer', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="grad_school">
                <div class="sf-ai-example-icon">🎯</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Graduate School Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Program info, Academic background, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="study_abroad">
                <div class="sf-ai-example-icon">🌍</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Study Abroad Program', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Destination, Program type, Language skills', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="internship">
                <div class="sf-ai-example-icon">💼</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Internship Application', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Position, Skills, Availability, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="freelance_project">
                <div class="sf-ai-example-icon">💻</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Freelance Project', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Project scope, Skills needed, Budget, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="virtual_assistant">
                <div class="sf-ai-example-icon">👩‍💼</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Virtual Assistant Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Hours needed, Skills required', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="social_media">
                <div class="sf-ai-example-icon">📱</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Social Media Management', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Platforms, Content type, Frequency, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="seo_consultation">
                <div class="sf-ai-example-icon">🔍</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('SEO Consultation', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Website info, Current performance, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="content_writing">
                <div class="sf-ai-example-icon">✍️</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Content Writing Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Content type, Word count, Topic, Deadline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="graphic_design">
                <div class="sf-ai-example-icon">🎨</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Graphic Design Project', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Design type, Style preferences, Usage, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="web_development">
                <div class="sf-ai-example-icon">🌐</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Web Development', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Website type, Features, Design preferences, Budget', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="mobile_app">
                <div class="sf-ai-example-icon">📱</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Mobile App Development', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('App type, Platform, Features, Target audience', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="ecommerce_setup">
                <div class="sf-ai-example-icon">🛒</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('E-commerce Setup', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Product type, Payment methods, Shipping, Features', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="email_marketing">
                <div class="sf-ai-example-icon">📧</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Email Marketing Setup', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Audience size, Email frequency, Content type, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="ppc_campaign">
                <div class="sf-ai-example-icon">💰</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('PPC Campaign Setup', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Platform, Budget, Target audience, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="brand_consultation">
                <div class="sf-ai-example-icon">🎯</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Brand Consultation', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Business type, Target audience, Brand goals, Current status', 'sigmaforms-pro'); ?>
                    </p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="market_research">
                <div class="sf-ai-example-icon">📊</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Market Research', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Industry, Target market, Research goals, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="business_plan">
                <div class="sf-ai-example-icon">📋</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Business Plan Development', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Business concept, Market analysis, Financial projections', 'sigmaforms-pro'); ?>
                    </p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="franchise_inquiry">
                <div class="sf-ai-example-icon">🏢</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Franchise Inquiry', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Franchise interest, Location, Investment range, Experience', 'sigmaforms-pro'); ?>
                    </p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="business_consulting">
                <div class="sf-ai-example-icon">💼</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Business Consulting', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Business challenges, Industry, Company size, Goals', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="hr_consulting">
                <div class="sf-ai-example-icon">👥</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('HR Consulting', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('HR challenges, Company size, Industry, Specific needs', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="accounting_service">
                <div class="sf-ai-example-icon">🧮</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Accounting Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Service type, Business size, Industry, Timeline', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="bookkeeping">
                <div class="sf-ai-example-icon">📚</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Bookkeeping Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Transaction volume, Frequency, Software preferences', 'sigmaforms-pro'); ?></p>
                </div>
            </div>
            <div class="sf-prebuilt-template-card sf-select-template" data-template="payroll_service">
                <div class="sf-ai-example-icon">💵</div>
                <div class="sf-prebuilt-template-content">
                    <h4><?php esc_html_e('Payroll Service', 'sigmaforms-pro'); ?></h4>
                    <p><?php esc_html_e('Employee count, Pay frequency, Tax filing needs', 'sigmaforms-pro'); ?></p>
                </div>
            </div>


        </div>
    </div>
</div>


<script>
    document.querySelectorAll('.sf-manual-create-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.sf-ai-generator-page').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.sf-prebuilt-templates').forEach(el => el.style.display = 'block');
        });
    });
</script>