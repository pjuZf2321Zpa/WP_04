<?php
/**
 * Field Type Selection Modal
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- Field Type Selection Modal for Add Field -->
<div class="sf-field-type-modal" style="display: none;">
    <div class="sf-field-type-modal-content">
        <div class="sf-field-type-modal-header">
            <h3><?php esc_html_e('Select Field Type', 'sigmaforms-pro'); ?></h3>
            <button type="button" class="sf-close-modal" aria-label="<?php esc_attr_e('Close', 'sigmaforms-pro'); ?>"><?php echo \SigmaForms\Admin\PageHeader::icon('close'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></button>
        </div>
        <div class="sf-field-type-grid">
            <div class="sf-field-type-item" data-type="text">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-editor-textcolor"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Text', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-field-type-item" data-type="email">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-email"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Email', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-field-type-item" data-type="url">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-admin-links"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('URL', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-field-type-item" data-type="number">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-calculator"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Number', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-field-type-item" data-type="phone">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-phone"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Phone', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-field-type-item" data-type="textarea">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-editor-paragraph"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Textarea', 'sigmaforms-pro'); ?></div>
            </div>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="phone_international">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-smartphone"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Phone (International)', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="phone_international" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-smartphone"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Phone (International)', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="select">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-menu-alt"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Dropdown', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="select" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-menu-alt"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Dropdown', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="radio">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-marker"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Radio', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="radio" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-marker"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Radio', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="checkbox">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-yes"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Checkbox', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="checkbox" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-yes"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Checkbox', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="date">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-calendar-alt"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Date', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="date" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-calendar-alt"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Date', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="file">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-media-document"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('File Upload', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="file" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-media-document"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('File Upload', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="country">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-admin-site"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Country', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="country" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-admin-site"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Country', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="signature">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Digital Signature', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="signature" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Digital Signature', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="rating">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-star-filled"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Rating', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="rating" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-star-filled"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Rating', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="range">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-leftright"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Range / Slider', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="range" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-leftright"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Range / Slider', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="rich_text">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-editor-kitchensink"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Rich Text', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="rich_text" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-editor-kitchensink"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Rich Text', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="section_heading">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-heading"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Section Heading', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="section_heading" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-heading"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Section Heading', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
            <?php if (SigmaForms\Plugin::is_license_valid()) : ?>
            <div class="sf-field-type-item" data-type="page_break">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-media-document"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Page Break', 'sigmaforms-pro'); ?></div>
            </div>
            <?php else : ?>
            <div class="sf-field-type-item sf-disabled" data-type="page_break" title="<?php esc_attr_e('Requires active license', 'sigmaforms-pro'); ?>" style="opacity:0.5; pointer-events:none;">
                <div class="sf-field-icon">
                    <span class="dashicons dashicons-media-document"></span>
                </div>
                <div class="sf-field-type-name"><?php esc_html_e('Page Break', 'sigmaforms-pro'); ?> (<?php esc_html_e('Pro', 'sigmaforms-pro'); ?>)</div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>