<?php
/**
 * Form editor wizard steps
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;
?>

<?php
PageHeader::render();

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
if ($is_edit) {
    $sf_editor_title = !empty($form_title)
        ? sprintf(
            /* translators: %s: form name */
            __('Edit: %s', 'sigmaforms-pro'),
            $form_title
        )
        : __('Edit Form', 'sigmaforms-pro');
    $sf_editor_description = __('Adjust the fields, settings and notifications, then update the form.', 'sigmaforms-pro');
} else {
    $sf_editor_title = __('Add New', 'sigmaforms-pro');
    $sf_editor_description = __('Describe your form in natural language and let AI create the perfect structure for you.', 'sigmaforms-pro');
}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

PageHeader::intro(
    array(
        'title'       => $sf_editor_title,
        'description' => $sf_editor_description,
    )
);
?>

<!-- Wizard steps indicator -->
<div class="sf-wizard-steps-container">
    <div class="sf-wizard-steps">
        <?php if (!$is_edit) : ?>
            <div class="sf-wizard-step active" data-step="1">
                <div class="sf-step-number">1</div>
                <div class="sf-step-label"><?php esc_html_e('Generate', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-wizard-step" data-step="2">
                <div class="sf-step-number">2</div>
                <div class="sf-step-label"><?php esc_html_e('Customize', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-wizard-step" data-step="3">
                <div class="sf-step-number">3</div>
                <div class="sf-step-label"><?php esc_html_e('Configure', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-wizard-step" data-step="4">
                <div class="sf-step-number">4</div>
                <div class="sf-step-label"><?php esc_html_e('Publish', 'sigmaforms-pro'); ?></div>
            </div>
        <?php else : ?>
            <div class="sf-wizard-step active sf-wizard-step-edit" data-step="2">
                <div class="sf-step-number">1</div>
                <div class="sf-step-label"><?php esc_html_e('Customize', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-wizard-step sf-wizard-step-edit" data-step="3">
                <div class="sf-step-number">2</div>
                <div class="sf-step-label"><?php esc_html_e('Configure', 'sigmaforms-pro'); ?></div>
            </div>
            <div class="sf-wizard-step sf-wizard-step-edit" data-step="4">
                <div class="sf-step-number">3</div>
                <div class="sf-step-label"><?php echo esc_html__('Update', 'sigmaforms-pro'); ?></div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Wizard progress indicator -->
    <div class="sf-wizard-progress">
        <div class="sf-progress-indicator"></div>
    </div>
</div>