<?php
/**
 * Main initialization file for form editor
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Determine if editing or creating new form
$is_edit = isset($form) && !empty($form);
$form_id = $is_edit ? $form['id'] : 0;
$form_title = $is_edit ? $form['title'] : '';

// Get AI API key for checking if AI features are available
$api_key = get_option('sf_api_key_openai', '') ?: get_option('sf_api_key_gemini', '') ?: get_option('sf_api_key_claude', '');

// Make sure form fields is an array, not a JSON string
if ($is_edit) {
    if (is_string($form['form_fields'])) {
        $form_fields = json_decode($form['form_fields'], true) ?: [];
    } else {
        $form_fields = $form['form_fields'];
    }
} else {
    $form_fields = [];
}

// Make sure form settings is decoded if needed
$form_settings = $is_edit ? $form['form_settings'] : [];

// Default settings if new form
if (!$is_edit) {
    $form_settings = \SigmaForms\Utils\Helper::get_default_form_settings();
}
