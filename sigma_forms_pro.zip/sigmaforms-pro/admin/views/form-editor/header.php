<?php
/**
 * Form editor header
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div>
    <div class="sf-admin-wrap">
        <!-- <div class="sf-admin-header">
            <h1 class="wp-heading-inline">
                <?php echo $is_edit ? esc_html__('Edit Form', 'sigmaforms-pro') : esc_html__('Add New Form', 'sigmaforms-pro'); ?>
            </h1>
            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms')); ?>" class="page-title-action">
                <?php esc_html_e('Back to Forms', 'sigmaforms-pro'); ?>
            </a>
        </div> -->
