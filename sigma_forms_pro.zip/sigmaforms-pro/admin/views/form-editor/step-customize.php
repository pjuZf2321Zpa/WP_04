<?php
/**
 * Step 2: Customize Form Fields
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- Step 2: Customize Form Fields -->
<div class="sf-wizard-step-content<?php echo $is_edit ? ' active' : ''; ?>" data-step="2">
    <div class="sf-card">

        <div class="sf-visual-form-builder">
            <!-- Visual Form Preview Area -->
            <div class="sf-visual-form-preview">
                <div class="sf-preview-header">
                    <h3><?php esc_html_e('Customize Your Form', 'sigmaforms-pro'); ?></h3>
                    <div class="sf-preview-header-actions">
                        <button type="button" class="sf-btn sf-btn-primary sf-add-field-button">
                            <?php echo \SigmaForms\Admin\PageHeader::icon('plus'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Add Field', 'sigmaforms-pro'); ?>
                        </button>
                    </div>
                </div>
                
                <div class="sf-form-preview-area" id="sf-visual-form-preview">
                    <?php if ($is_edit && !empty($form_fields)) : ?>
                        <!-- Fields will be rendered by JavaScript, this is just a fallback -->
                        <div class="sf-form-fields-wrapper">
                        </div>
                    <?php else : ?>
                        <div class="sf-empty-form-message">
                            <p><?php esc_html_e('Your form is empty. Add fields to get started.', 'sigmaforms-pro'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Include field settings popup here -->
            <?php include_once __DIR__ . '/field-settings-popup.php'; ?>
            
            <!-- Expose license flag to JS -->
            <script type="text/javascript">
                window.sfLicenseValid = <?php echo SigmaForms\Plugin::is_license_valid() ? 'true' : 'false'; ?>;
            </script>
            
            <!-- Include field type modal here -->
            <?php include_once __DIR__ . '/field-type-modal.php'; ?>
            
            <!-- AI Chat Widget -->
            <?php if (SigmaForms\Plugin::is_license_valid() && !empty($api_key)) : ?>
            <div class="sf-ai-chat-widget">
                <!-- Chat Button -->
                <button type="button" class="sf-ai-chat-button" title="<?php esc_attr_e('Sigma Assistant', 'sigmaforms-pro'); ?>">
                    <svg class="sf-ai-chat-icon" width="24" height="24" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                    </svg>
                    <svg class="sf-ai-chat-close-icon" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: none;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>

                <!-- Chat Window -->
                <div class="sf-ai-chat-window" style="display: none;">
                    <!-- Chat Header -->
                    <div class="sf-ai-chat-header">
                        <div class="sf-ai-chat-header-info">
                            <div class="sf-ai-chat-avatar">
                                <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                </svg>
                            </div>
                            <div class="sf-ai-chat-header-text">
                                <div class="sf-ai-chat-title"><?php esc_html_e('Sigma Assistant', 'sigmaforms-pro'); ?></div>
                                <div class="sf-ai-chat-status">
                                    <span class="sf-ai-status-dot"></span>
                                    <?php esc_html_e('Online', 'sigmaforms-pro'); ?>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="sf-ai-chat-minimize" title="<?php esc_attr_e('Minimize', 'sigmaforms-pro'); ?>">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>
                    </div>

                    <!-- Chat Messages -->
                    <div class="sf-ai-chat-messages">
                        <div class="sf-ai-chat-message sf-ai-message">
                            <div class="sf-ai-message-avatar">
                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                </svg>
                            </div>
                            <div class="sf-ai-message-content">
                                <div class="sf-ai-message-bubble">
                                    <?php esc_html_e('Hi! I\'m your Sigma assistant. Tell me what fields you\'d like to add to your form, and I\'ll help you create them.', 'sigmaforms-pro'); ?>
                                </div>
                                <div class="sf-ai-message-time"><?php echo esc_html(current_time('g:i A')); ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Chat Input -->
                    <div class="sf-ai-chat-input-container">
                        <div class="sf-ai-chat-input-wrapper">
                            <textarea 
                                class="sf-ai-chat-input" 
                                placeholder="<?php esc_attr_e('Type your message...', 'sigmaforms-pro'); ?>"
                                rows="1"
                            ></textarea>
                            <button type="button" class="sf-ai-chat-send" title="<?php esc_attr_e('Send', 'sigmaforms-pro'); ?>">
                                <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/>
                                </svg>
                            </button>
                        </div>
                        <div class="sf-ai-chat-suggestions">
                            <button type="button" class="sf-ai-suggestion-chip" data-suggestion="Add email and phone number fields">
                                <?php esc_html_e('Add contact fields', 'sigmaforms-pro'); ?>
                            </button>
                            <button type="button" class="sf-ai-suggestion-chip" data-suggestion="Add address fields with street, city, state, and zip code">
                                <?php esc_html_e('Add address section', 'sigmaforms-pro'); ?>
                            </button>
                            <button type="button" class="sf-ai-suggestion-chip" data-suggestion="Add payment fields with amount and method">
                                <?php esc_html_e('Add payment fields', 'sigmaforms-pro'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div id="sf-fields-data" class="sf-hidden-data">
                <?php if ($is_edit) : ?>
                    <script type="text/javascript">
                        // Pre-process form fields to ensure they're valid
                        <?php 
                        if (!empty($form_fields)) {
                            echo 'var sfFormFields = ' . json_encode($form_fields) . ';';
                        } else {
                            echo 'var sfFormFields = [];';
                        }
                        ?>
                    </script>
                <?php else : ?>
                    <script type="text/javascript">
                        var sfFormFields = [];
                    </script>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="sf-wizard-navigation">
        <?php if ($is_edit) : ?>
            <div class="sf-save-message"></div>
        <?php endif; ?>
        
        <?php if (!$is_edit) : ?>
            <button type="button" class="sf-btn sf-btn-secondary sf-prev-step" data-goto="1" id="sf-back-to-generate-btn">
                <?php echo \SigmaForms\Admin\PageHeader::icon('arrow-left'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Back to Generate', 'sigmaforms-pro'); ?>
            </button>
        <?php endif; ?>
        <button type="button" class="sf-btn sf-btn-primary sf-next-step" data-goto="3" id="sf-continue-to-configure-btn">
            <?php esc_html_e('Continue to Configure', 'sigmaforms-pro'); ?> <?php echo \SigmaForms\Admin\PageHeader::icon('arrow-right'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        </button>
        
        <?php if ($is_edit) : ?>
            <div class="sf-save-actions">
                <button type="button" class="sf-btn sf-btn-success sf-save-form" id="sf-save-form-step2">
                    <?php echo \SigmaForms\Admin\PageHeader::icon('refresh'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Update Form', 'sigmaforms-pro'); ?>
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
