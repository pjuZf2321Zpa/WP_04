<?php
/**
 * Form editor footer
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

    </div>
</div>
