<?php
/**
 * Form editor wrapper container
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<form id="sf-form-editor" class="sf-form-editor">
    <input type="hidden" id="form-id" value="<?php echo esc_attr($form_id); ?>">
    
    <!-- Wizard container -->
    <div class="sf-wizard-container">
        <?php 
        // Include the step files based on edit mode
        if (!$is_edit) {
            // Step 1: Generate (only for new forms)
            require_once SF_PLUGIN_DIR . 'admin/views/form-editor/step-generate.php';
        }
        
        // Step 2: Customize
        require_once SF_PLUGIN_DIR . 'admin/views/form-editor/step-customize.php';
        
        // Step 3: Configure
        require_once SF_PLUGIN_DIR . 'admin/views/form-editor/step-configure.php';
        
        // Step 4: Publish/Update
        require_once SF_PLUGIN_DIR . 'admin/views/form-editor/step-publish.php';
        ?>
    </div>
</form>
