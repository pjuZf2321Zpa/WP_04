<?php
/**
 * Step 3: Configure Form Settings
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Helper functions are local to this template
?>

<!-- Step 3: Configure Form Settings -->
<div class="sf-wizard-step-content" data-step="3">
    <div class="sf-card">
        <div class="sf-card-header">
            <h2><?php esc_html_e('Configure Form Settings', 'sigmaforms-pro'); ?></h2>
        </div>
        <div class="sf-step-content">
            <p class="sf-step-description">
                <?php esc_html_e('Configure submission settings, email notifications, and security options.', 'sigmaforms-pro'); ?>
                <?php if (empty($available_captchas)): ?>
                    <br><small><?php esc_html_e('Note: Security tab is hidden because no CAPTCHA services are configured. Configure CAPTCHA services in the plugin settings to enable security options.', 'sigmaforms-pro'); ?></small>
                <?php endif; ?>
            </p>
            
            <?php 
            // Get global captcha settings
            $global_settings = get_option('sigmaforms_settings', []);
            
            // Helper function to check if reCAPTCHA is properly configured
            function is_recaptcha_configured($settings) {
                return !empty($settings['recaptcha_enabled']) && 
                       !empty($settings['recaptcha_site_key']) && 
                       !empty($settings['recaptcha_secret_key']);
            }
            
            // Helper function to check if hCaptcha is properly configured
            function is_hcaptcha_configured($settings) {
                return !empty($settings['hcaptcha_enabled']) && 
                       !empty($settings['hcaptcha_site_key']) && 
                       !empty($settings['hcaptcha_secret_key']);
            }
            
            // Helper function to check if Turnstile is properly configured
            function is_turnstile_configured($settings) {
                return !empty($settings['turnstile_enabled']) && 
                       !empty($settings['turnstile_site_key']) && 
                       !empty($settings['turnstile_secret_key']);
            }
            
            // Helper function to check if CleanTalk is properly configured
            function is_cleantalk_configured($settings) {
                return !empty($settings['cleantalk_enabled']) && 
                       !empty($settings['cleantalk_access_key']);
            }

            // Helper function to check if mTCaptcha is properly configured
            function is_mtcaptcha_configured($settings) {
                return !empty($settings['mtcaptcha_enabled']) && 
                       !empty($settings['mtcaptcha_site_key']) && 
                       !empty($settings['mtcaptcha_private_key']);
            }
            
            // Check which captchas are properly configured
            $available_captchas = [];
            
            // Check reCAPTCHA
            if (is_recaptcha_configured($global_settings)) {
                $available_captchas['recaptcha'] = [
                    'name' => __('Google reCAPTCHA', 'sigmaforms-pro'),
                    'description' => __('Google\'s free CAPTCHA service that helps protect websites from spam and abuse.', 'sigmaforms-pro'),
                    'site_key' => $global_settings['recaptcha_site_key'] ?? ''
                ];
            }
            
            // Check hCaptcha
            if (is_hcaptcha_configured($global_settings)) {
                $available_captchas['hcaptcha'] = [
                    'name' => __('hCaptcha', 'sigmaforms-pro'),
                    'description' => __('Privacy-focused CAPTCHA service that respects user privacy and GDPR compliance.', 'sigmaforms-pro'),
                    'site_key' => $global_settings['hcaptcha_site_key'] ?? ''
                ];
            }
            
            // Check Turnstile
            if (is_turnstile_configured($global_settings)) {
                $available_captchas['turnstile'] = [
                    'name' => __('Cloudflare Turnstile', 'sigmaforms-pro'),
                    'description' => __('Privacy-first CAPTCHA alternative that\'s invisible to users and free to use.', 'sigmaforms-pro'),
                    'site_key' => $global_settings['turnstile_site_key'] ?? ''
                ];
            }
            
            // Check CleanTalk
            if (is_cleantalk_configured($global_settings)) {
                $available_captchas['cleantalk'] = [
                    'name' => __('CleanTalk', 'sigmaforms-pro'),
                    'description' => __('Advanced spam protection service that blocks spam without CAPTCHA challenges.', 'sigmaforms-pro'),
                    'access_key' => $global_settings['cleantalk_access_key'] ?? ''
                ];
            }

            // Check mTCaptcha
            if (is_mtcaptcha_configured($global_settings)) {
                $available_captchas['mtcaptcha'] = [
                    'name' => __('mTCaptcha', 'sigmaforms-pro'),
                    'description' => __('Visible challenge CAPTCHA that must be completed by the user before submission.', 'sigmaforms-pro'),
                    'site_key' => $global_settings['mtcaptcha_site_key'] ?? ''
                ];
            }
            ?>
            
            <div class="sf-settings-tabs">
                <div class="sf-settings-tab-nav">
                    <button type="button" class="sf-settings-tab-button active" data-tab="submission">
                        <?php echo \SigmaForms\Admin\PageHeader::icon('forms'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                        <?php esc_html_e('Form Details', 'sigmaforms-pro'); ?>
                    </button>
                    <?php if (SigmaForms\Plugin::is_license_valid()): ?>
                    <button type="button" class="sf-settings-tab-button" data-tab="email">
                        <?php echo \SigmaForms\Admin\PageHeader::icon('mail'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                        <?php esc_html_e('Email', 'sigmaforms-pro'); ?>
                    </button>
                    <button type="button" class="sf-settings-tab-button" data-tab="style">
                        <?php echo \SigmaForms\Admin\PageHeader::icon('brush'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                        <?php esc_html_e('Form Style', 'sigmaforms-pro'); ?>
                    </button>
                    <?php if (!empty($available_captchas)): ?>
                    <button type="button" class="sf-settings-tab-button" data-tab="security">
                        <?php echo \SigmaForms\Admin\PageHeader::icon('shield'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                        <?php esc_html_e('Security', 'sigmaforms-pro'); ?>
                    </button>
                    <?php endif; ?>
                    <button type="button" class="sf-settings-tab-button" data-tab="webhooks">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" height="16" width="16"><path d="M208 128c0-44.2 35.8-80 80-80s80 35.8 80 80c0 10.7-2.1 20.8-5.8 30l44.5 18c6-14.9 9.3-31.1 9.3-48.1C416 57.3 358.7 0 288 0S160 57.3 160 128c0 37.1 15.8 70.5 41 93.9L129.7 336c-.6 0-1.1 0-1.7 0c-26.5 0-48 21.5-48 48s21.5 48 48 48s48-21.5 48-48c0-8.1-2-15.8-5.6-22.5l82.8-132.5 12.7-20.3-20.3-12.7C223 181.7 208 156.6 208 128zm81.7 48l82.8 132.5 12.7 20.4 20.4-12.8c12.3-7.7 26.8-12.1 42.4-12.1c44.2 0 80 35.8 80 80s-35.8 80-80 80c-22.2 0-42.2-9-56.8-23.6l-34.1 33.8C380.3 497.5 412.5 512 448 512c70.7 0 128-57.3 128-128s-57.3-128-128-128c-16.3 0-31.9 3.1-46.3 8.6L330.4 150.5c3.6-6.7 5.6-14.4 5.6-22.5c0-26.5-21.5-48-48-48s-48 21.5-48 48s21.5 48 48 48c.6 0 1.1 0 1.7 0zM448 432c26.5 0 48-21.5 48-48s-21.5-48-48-48c-17.8 0-33.3 9.7-41.6 24L232 360l-24 0 0 24c0 44.2-35.8 80-80 80s-80-35.8-80-80c0-39.7 28.9-72.7 66.8-78.9L107 257.7C46.3 267.7 0 320.4 0 384c0 70.7 57.3 128 128 128c62.5 0 114.5-44.8 125.8-104l152.7 0c8.3 14.3 23.8 24 41.6 24z"/></svg>
                        <?php esc_html_e('Webhooks', 'sigmaforms-pro'); ?>
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="sf-settings-tab-content active" data-tab="submission">
                    <div class="sf-settings-group">
                        <!-- Hidden fields to store form settings from customize step -->
                        <input type="hidden" id="form-title" value="<?php echo esc_attr($form_title); ?>">
                        <input type="hidden" id="form-submit-button-text" value="<?php echo esc_attr($form_settings['submit_button_text'] ?? __('Submit', 'sigmaforms-pro')); ?>">

                        <div class="sf-field-row">
                            <label for="form-title-input"><?php esc_html_e('Form Name', 'sigmaforms-pro'); ?></label>
                            <input type="text" id="form-title-input" value="<?php echo esc_attr($form_title ?: __('Untitled Form', 'sigmaforms-pro')); ?>">
                        </div>
                        
                        <div class="sf-field-row">
                            <label for="form-success-message"><?php esc_html_e('Success Message', 'sigmaforms-pro'); ?></label>
                            <textarea id="form-success-message"><?php echo esc_textarea($form_settings['success_message'] ?? __('Thank you for your submission!', 'sigmaforms-pro')); ?></textarea>
                        </div>

                        <div class="sf-field-row">
                            <label for="form-validation-failed-message"><?php esc_html_e('Validation Error Heading', 'sigmaforms-pro'); ?></label>
                            <input type="text" id="form-validation-failed-message" value="<?php echo esc_attr($form_settings['validation_failed_message'] ?? ''); ?>" placeholder="<?php esc_attr_e('Please submit the required fields.', 'sigmaforms-pro'); ?>">
                            <p class="sf-field-description"><?php esc_html_e('Heading shown above field errors when submission fails. Supports any language.', 'sigmaforms-pro'); ?></p>
                        </div>
                        
                        <div class="sf-field-row">
                            <label class="sf-toggle-label">
                                <span class="sf-toggle-switch">
                                    <?php // New forms store submissions by default; existing forms keep their saved choice. ?>
                                    <input type="checkbox" id="form-store-submissions" <?php checked($is_edit ? !empty($form_settings['store_submissions']) : true); ?>>
                                    <span class="sf-toggle-slider"></span>
                                </span>
                                <?php esc_html_e('Store Submissions in Database', 'sigmaforms-pro'); ?>
                            </label>
                            <p class="sf-field-description"><?php esc_html_e('Save form submissions to the database for viewing in the admin dashboard.', 'sigmaforms-pro'); ?></p>
                        </div>
                        
                        <?php if (SigmaForms\Plugin::is_license_valid()): ?>
                        <div class="sf-field-row">
                            <label class="sf-toggle-label">
                                <span class="sf-toggle-switch">
                                    <input type="checkbox" id="form-store-abandoned-forms" <?php echo $is_edit ? checked(isset($form_settings['store_abandoned_forms']) ? $form_settings['store_abandoned_forms'] : false, true, false) : ''; ?>>
                                    <span class="sf-toggle-slider"></span>
                                </span>
                                <?php esc_html_e('Store Abandoned Forms in Database', 'sigmaforms-pro'); ?>
                            </label>
                            <p class="sf-field-description"><?php esc_html_e('Track and save abandoned form submissions when users start filling the form but don\'t complete it. Only saves forms with meaningful content (non-empty values).', 'sigmaforms-pro'); ?></p>
                        </div>
                        
                        <div class="sf-field-row">
                            <label class="sf-toggle-label">
                                <span class="sf-toggle-switch">
                                    <input type="checkbox" id="form-enable-scheduling" <?php echo $is_edit ? checked(isset($form_settings['enable_scheduling']) ? $form_settings['enable_scheduling'] : false, true, false) : ''; ?>>
                                    <span class="sf-toggle-slider"></span>
                                </span>
                                <?php esc_html_e('Enable Form Scheduling', 'sigmaforms-pro'); ?>
                            </label>
                            <p class="sf-field-description"><?php esc_html_e('Schedule when the form should be available to users. Show countdown timers for start and end times.', 'sigmaforms-pro'); ?></p>
                        </div>
                        
                        <div class="sf-scheduling-settings" style="<?php echo empty($form_settings['enable_scheduling']) ? 'display: none;' : ''; ?>">
                            <div class="sf-field-row">
                                <label for="form-schedule-start"><?php esc_html_e('Start Time (Optional)', 'sigmaforms-pro'); ?></label>
                                <input type="datetime-local" id="form-schedule-start" value="<?php echo esc_attr($form_settings['schedule_start'] ?? ''); ?>">
                                <p class="sf-field-description"><?php esc_html_e('Form will show a countdown timer until this time. Leave empty to make form available immediately.', 'sigmaforms-pro'); ?></p>
                            </div>
                            
                            <div class="sf-field-row">
                                <label for="form-schedule-end"><?php esc_html_e('End Time (Optional)', 'sigmaforms-pro'); ?></label>
                                <input type="datetime-local" id="form-schedule-end" value="<?php echo esc_attr($form_settings['schedule_end'] ?? ''); ?>">
                                <p class="sf-field-description"><?php esc_html_e('Form will be hidden after this time. If set, a live countdown timer will be shown at the top of the form.', 'sigmaforms-pro'); ?></p>
                            </div>
                            
                            <div class="sf-field-row">
                                <label for="form-schedule-message-before"><?php esc_html_e('Message Before Start Time', 'sigmaforms-pro'); ?></label>
                                <textarea id="form-schedule-message-before" rows="3"><?php echo esc_textarea($form_settings['schedule_message_before'] ?? __('This form will be available soon. Please check back later.', 'sigmaforms-pro')); ?></textarea>
                                <p class="sf-field-description"><?php esc_html_e('Message to display before the start time.', 'sigmaforms-pro'); ?></p>
                            </div>
                            
                            <div class="sf-field-row">
                                <label for="form-schedule-message-after"><?php esc_html_e('Message After End Time', 'sigmaforms-pro'); ?></label>
                                <textarea id="form-schedule-message-after" rows="3"><?php echo esc_textarea($form_settings['schedule_message_after'] ?? __('This form is no longer accepting submissions.', 'sigmaforms-pro')); ?></textarea>
                                <p class="sf-field-description"><?php esc_html_e('Message to display after the end time.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="sf-settings-tab-content" data-tab="email">
                    <div class="sf-settings-group">
                        <div class="sf-field-row">
                            <label class="sf-toggle-label">
                                <span class="sf-toggle-switch">
                                    <input type="checkbox" id="form-override-email-settings" <?php checked(!empty($form_settings['override_email_settings'])); ?>>
                                    <span class="sf-toggle-slider"></span>
                                </span>
                                <?php esc_html_e('Override Default Email Settings', 'sigmaforms-pro'); ?>
                            </label>
                            <p class="sf-field-description"><?php esc_html_e('Enable to customize email settings for this form. If disabled, default settings from the plugin settings will be used.', 'sigmaforms-pro'); ?></p>
                        </div>
                        
                        <div class="sf-custom-email-settings" style="<?php echo empty($form_settings['override_email_settings']) ? 'display: none;' : ''; ?>">
                            <div class="sf-field-row">
                                <label for="form-to-email"><?php esc_html_e('To Email', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="form-to-email" value="<?php echo esc_attr($form_settings['to_email'] ?? get_option('sf_admin_email', get_option('admin_email'))); ?>">
                                <p class="sf-field-description"><?php esc_html_e('Email address(es) where form submissions will be sent. Separate multiple addresses with commas.', 'sigmaforms-pro'); ?></p>
                            </div>

                            <div class="sf-field-row">
                                <label for="form-cc-email"><?php esc_html_e('CC Email', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="form-cc-email" value="<?php echo esc_attr($form_settings['cc_email'] ?? get_option('sf_admin_email_cc', '')); ?>">
                                <p class="sf-field-description"><?php esc_html_e('CC email address(es) for notification emails. Separate multiple addresses with commas.', 'sigmaforms-pro'); ?></p>
                            </div>

                            <div class="sf-field-row">
                                <label for="form-bcc-email"><?php esc_html_e('BCC Email', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="form-bcc-email" value="<?php echo esc_attr($form_settings['bcc_email'] ?? get_option('sf_admin_email_bcc', '')); ?>">
                                <p class="sf-field-description"><?php esc_html_e('BCC email address(es) for notification emails. Separate multiple addresses with commas.', 'sigmaforms-pro'); ?></p>
                            </div>
                            
                            <div class="sf-field-row">
                                <label for="form-email-subject"><?php esc_html_e('Email Subject', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="form-email-subject" value="<?php echo esc_attr($form_settings['email_subject'] ?? get_option('sf_default_email_subject', 
                                // translators: %s is the blog name.
                                sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name')))); ?>">
                                <p class="sf-field-description"><?php esc_html_e('Subject line for the notification email.', 'sigmaforms-pro'); ?></p>
                            </div>
                            
                            <div class="sf-field-row">
                                <label for="form-email-message"><?php esc_html_e('Email Message', 'sigmaforms-pro'); ?></label>
                                <textarea id="form-email-message" rows="6"><?php echo esc_textarea($form_settings['email_message'] ?? get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro'))); ?></textarea>
                                <p class="sf-field-description"><?php esc_html_e('Message content for the notification email. Available placeholders: {name}, {email}, {all_fields}, {date}', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                        
                        <div class="sf-field-row">
                            <label class="sf-toggle-label">
                                <span class="sf-toggle-switch">
                                    <input type="checkbox" id="form-send-confirmation-email" <?php checked(!empty($form_settings['send_confirmation_email'])); ?>>
                                    <span class="sf-toggle-slider"></span>
                                </span>
                                <?php esc_html_e('Send Confirmation Email to User', 'sigmaforms-pro'); ?>
                            </label>
                            <p class="sf-field-description"><?php esc_html_e('Send an automatic confirmation email to the user who submitted the form.', 'sigmaforms-pro'); ?></p>
                        </div>
                        
                        <div class="sf-confirmation-email-settings" style="<?php echo empty($form_settings['send_confirmation_email']) ? 'display: none;' : ''; ?>">
                            <div class="sf-field-row">
                                <label for="form-confirmation-subject"><?php esc_html_e('Confirmation Subject', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="form-confirmation-subject" value="<?php echo esc_attr($form_settings['confirmation_subject'] ?? get_option('sf_default_confirmation_subject', __('Thank you for your submission', 'sigmaforms-pro'))); ?>">
                            </div>
                            
                            <div class="sf-field-row">
                                <label for="form-confirmation-message"><?php esc_html_e('Confirmation Message', 'sigmaforms-pro'); ?></label>
                                <textarea id="form-confirmation-message" rows="6"><?php echo esc_textarea($form_settings['confirmation_message'] ?? get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro'))); ?></textarea>
                                <p class="sf-field-description"><?php esc_html_e('Message content for the confirmation email. Available placeholders: {name}, {email}, {all_fields}, {date}', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                        
                        <div class="sf-field-row">
                            <div class="sf-info-box">
                                <?php echo \SigmaForms\Admin\PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                <p><?php esc_html_e('Email settings will use the default values from the plugin settings unless overridden above. SMTP configuration is managed in the plugin settings.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="sf-settings-tab-content" data-tab="style">
                    <div class="sf-settings-group">
                        <h3><?php esc_html_e('Form Theme', 'sigmaforms-pro'); ?></h3>
                        <p class="sf-field-description"><?php esc_html_e('Choose a theme for this specific form. This will only affect this form and will not change the appearance of other forms.', 'sigmaforms-pro'); ?></p>
                        
                        <div class="sf-field-row">
                            <label for="form-theme"><?php esc_html_e('Select Theme', 'sigmaforms-pro'); ?></label>
                            <?php $default_theme = get_option('sf_form_theme', 'minimal'); ?>
                            <select id="form-theme">
                                <option value="" <?php selected($form_settings['form_theme'], ''); ?>><?php
                                    /* translators: %s: theme name chosen in the global settings, e.g. Minimal */
                                    echo esc_html(sprintf(__('Global default (%s)', 'sigmaforms-pro'), ucfirst($default_theme)));
                                ?></option>
                                <option value="soft" <?php selected($form_settings['form_theme'], 'soft'); ?>><?php esc_html_e('Soft (New)', 'sigmaforms-pro'); ?></option>
                                <option value="minimal" <?php selected($form_settings['form_theme'], 'minimal'); ?>><?php esc_html_e('Minimal', 'sigmaforms-pro'); ?></option>
                                <option value="modern" <?php selected($form_settings['form_theme'], 'modern'); ?>><?php esc_html_e('Modern', 'sigmaforms-pro'); ?></option>
                                <option value="classic" <?php selected($form_settings['form_theme'], 'classic'); ?>><?php esc_html_e('Classic', 'sigmaforms-pro'); ?></option>
                                <option value="transition" <?php selected($form_settings['form_theme'], 'transition'); ?>><?php esc_html_e('Transition', 'sigmaforms-pro'); ?></option>
                                <option value="custom" <?php selected($form_settings['form_theme'], 'custom'); ?>><?php esc_html_e('Custom', 'sigmaforms-pro'); ?></option>
                            </select>
                            <p class="sf-field-description">
                                <?php 
                                // translators: %s is the default theme name from global settings.
                                printf(esc_html__('The default theme from global settings is: %s. Choose "Global default" to follow it, or pick a theme for this form only.', 'sigmaforms-pro'), '<strong>' . esc_html(ucfirst($default_theme)) . '</strong>'); 
                                ?>
                            </p>
                        </div>
                        
                        <?php 
                        // Get global form styling settings
                        $global_styling = get_option('sf_form_styling', []);
                        // Merge with form-specific styling (if any)
                        $form_styling = isset($form_settings['form_styling']) ? array_merge($global_styling, $form_settings['form_styling']) : $global_styling;
                        ?>
                        
                        <!-- Custom Style Options - Show only when Custom theme is selected -->
                        <div id="sf-custom-styling-options" style="display: <?php echo ($form_settings['form_theme'] === 'custom') ? 'block' : 'none'; ?>;">
                            <h3><?php esc_html_e('Custom Style Options', 'sigmaforms-pro'); ?></h3>
                            <p class="description">
                                <h4><?php esc_html_e('These options will only apply when using the Custom theme.', 'sigmaforms-pro'); ?></h4>
                            </p>

                            <div class="sf-settings-label-separator">
                                <h4><?php esc_html_e('Input Fields', 'sigmaforms-pro'); ?></h4>
                            </div>
                            <div class="sf-settings-row">
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-label-color"><?php esc_html_e('Label Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-label-color" value="<?php echo esc_attr($form_styling['label_color'] ?? '#333333'); ?>">
                                        <input type="text" name="form_label_color" value="<?php echo esc_attr($form_styling['label_color'] ?? '#333333'); ?>">
                                    </div>
                                </div>
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-field-background"><?php esc_html_e('Background Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-field-background" value="<?php echo esc_attr($form_styling['field_background'] ?? '#ffffff'); ?>">
                                        <input type="text" name="form_field_background" value="<?php echo esc_attr($form_styling['field_background'] ?? '#ffffff'); ?>">
                                    </div>
                                </div>
                            </div>

                            <!-- New custom theme color options -->
                            <div class="sf-settings-row">
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-input-text-color"><?php esc_html_e('Value Text Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-input-text-color" value="<?php echo esc_attr($form_styling['input_text_color'] ?? '#333333'); ?>">
                                        <input type="text" name="form_input_text_color" value="<?php echo esc_attr($form_styling['input_text_color'] ?? '#333333'); ?>">
                                    </div>
                                </div>
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-placeholder-color"><?php esc_html_e('Placeholder Text Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-placeholder-color" value="<?php echo esc_attr($form_styling['placeholder_color'] ?? '#888888'); ?>">
                                        <input type="text" name="form_placeholder_color" value="<?php echo esc_attr($form_styling['placeholder_color'] ?? '#888888'); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="sf-settings-row">
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-field-border"><?php esc_html_e('Field Border Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-field-border" value="<?php echo esc_attr($form_styling['field_border'] ?? '#dcdcde'); ?>">
                                        <input type="text" name="form_field_border" value="<?php echo esc_attr($form_styling['field_border'] ?? '#dcdcde'); ?>">
                                    </div>
                                </div>
                                <div class="sf-settings-field">
                                    <label for="form-input-border-radius"><?php esc_html_e('Border Radius', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-input-number-wrapper">
                                        <input type="number" id="form-input-border-radius" name="form_input_border_radius" value="<?php echo esc_attr($form_styling['input_border_radius'] ?? '4'); ?>" min="0" max="50">
                                        <span class="sf-unit">px</span>
                                    </div>
                                </div>
                            </div>

                            <div class="sf-settings-row">
                                <div class="sf-settings-field">
                                    <label for="form-padding"><?php esc_html_e('Padding', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-input-number-wrapper">
                                        <input type="number" id="form-padding" name="form_padding" value="<?php echo esc_attr($form_styling['form_padding'] ?? '20'); ?>" min="0" max="50">
                                        <span class="sf-unit">px</span>
                                    </div>
                                </div>
                                <div class="sf-settings-field">
                                    <label for="form-field-spacing"><?php esc_html_e('Spacing', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-input-number-wrapper">
                                        <input type="number" id="form-field-spacing" name="form_field_spacing" value="<?php echo esc_attr($form_styling['field_spacing'] ?? '15'); ?>" min="5" max="30">
                                        <span class="sf-unit">px</span>
                                    </div>
                                </div>
                            </div>

                            <div class="sf-settings-label-separator">
                                <h4><?php esc_html_e('Submit Button', 'sigmaforms-pro'); ?></h4>
                            </div>
                            <div class="sf-settings-row">
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-button-color"><?php esc_html_e('Background Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-button-color" value="<?php echo esc_attr($form_styling['button_color'] ?? '#2271b1'); ?>">
                                        <input type="text" name="form_button_color" value="<?php echo esc_attr($form_styling['button_color'] ?? '#2271b1'); ?>">
                                    </div>
                                </div>
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-button-text-color"><?php esc_html_e('Button Text Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-button-text-color" value="<?php echo esc_attr($form_styling['button_text_color'] ?? '#ffffff'); ?>">
                                        <input type="text" name="form_button_text_color" value="<?php echo esc_attr($form_styling['button_text_color'] ?? '#ffffff'); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="sf-settings-row">
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-button-hover-bg-color"><?php esc_html_e('Hover Background Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-button-hover-bg-color" value="<?php echo esc_attr($form_styling['button_hover_bg_color'] ?? '#1a5a96'); ?>">
                                        <input type="text" name="form_button_hover_bg_color" value="<?php echo esc_attr($form_styling['button_hover_bg_color'] ?? '#1a5a96'); ?>">
                                    </div>
                                </div>
                                <div class="sf-settings-field sf-color-field">
                                    <label for="form-button-hover-text-color"><?php esc_html_e('Hover Text Color', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-color-picker-wrapper">
                                        <input type="color" id="form-button-hover-text-color" value="<?php echo esc_attr($form_styling['button_hover_text_color'] ?? '#ffffff'); ?>">
                                        <input type="text" name="form_button_hover_text_color" value="<?php echo esc_attr($form_styling['button_hover_text_color'] ?? '#ffffff'); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="sf-settings-field">
                                <label for="form-button-border-radius"><?php esc_html_e('Border Radius', 'sigmaforms-pro'); ?></label>
                                <div class="sf-input-number-wrapper">
                                    <input type="number" id="form-button-border-radius" name="form_button_border_radius" value="<?php echo esc_attr($form_styling['button_border_radius'] ?? '4'); ?>" min="0" max="50">
                                    <span class="sf-unit">px</span>
                                </div>
                            </div>

                            <div class="sf-settings-label-separator" style="margin-top: 20px;">
                                <h4><?php esc_html_e('Common Settings', 'sigmaforms-pro'); ?></h4>
                            </div>
                            <div class="sf-settings-row">
                                <div class="sf-settings-field">
                                    <label for="form-font-family"><?php esc_html_e('Font Family', 'sigmaforms-pro'); ?></label>
                                    <select id="form-font-family" name="form_font_family">
                                        <option value="inherit" <?php selected($form_styling['font_family'] ?? 'inherit', 'inherit'); ?>><?php esc_html_e('Theme Default', 'sigmaforms-pro'); ?></option>
                                        <option value="Arial, sans-serif" <?php selected($form_styling['font_family'] ?? 'inherit', 'Arial, sans-serif'); ?>>Arial</option>
                                        <option value="Helvetica, Arial, sans-serif" <?php selected($form_styling['font_family'] ?? 'inherit', 'Helvetica, Arial, sans-serif'); ?>>Helvetica</option>
                                        <option value="Georgia, serif" <?php selected($form_styling['font_family'] ?? 'inherit', 'Georgia, serif'); ?>>Georgia</option>
                                        <option value="'Times New Roman', Times, serif" <?php selected($form_styling['font_family'] ?? 'inherit', "'Times New Roman', Times, serif"); ?>>Times New Roman</option>
                                        <option value="Verdana, Geneva, sans-serif" <?php selected($form_styling['font_family'] ?? 'inherit', 'Verdana, Geneva, sans-serif'); ?>>Verdana</option>
                                    </select>
                                </div>
                                <div class="sf-settings-field">
                                    <label for="form-font-size"><?php esc_html_e('Font Size', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-input-number-wrapper">
                                        <input type="number" id="form-font-size" name="form_font_size" value="<?php echo esc_attr($form_styling['font_size'] ?? '16'); ?>" min="10" max="50">
                                        <span class="sf-unit">px</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="sf-field-row">
                            <div class="sf-info-box">
                                <?php echo \SigmaForms\Admin\PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                <p><?php esc_html_e('Forms on "Global default" follow the theme chosen in the plugin settings. Pick a theme here to give this form its own look instead.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($available_captchas)): ?>
                <div class="sf-settings-tab-content" data-tab="security">
                    <div class="sf-settings-group">
                        <h3><?php esc_html_e('CAPTCHA Protection', 'sigmaforms-pro'); ?></h3>
                        <p class="sf-field-description"><?php esc_html_e('Choose a CAPTCHA service to protect your form from spam and bots. Only one CAPTCHA service can be active at a time.', 'sigmaforms-pro'); ?></p>

                        <div class="sf-captcha-selection">
                            <p class="sf-field-description"><?php esc_html_e('Select one CAPTCHA service to enable for this form (click again to deselect):', 'sigmaforms-pro'); ?></p>

                            <?php foreach ($available_captchas as $captcha_type => $captcha_info): ?>
                                <div class="sf-field-row">
                                    <label class="sf-toggle-label">
                                        <span class="sf-toggle-switch">
                                            <input type="checkbox" name="form_captcha_type" id="form-enable-<?php echo esc_attr($captcha_type); ?>" 
                                                   value="<?php echo esc_attr($captcha_type); ?>" 
                                                   <?php checked($form_settings['captcha_type'] ?? '', $captcha_type); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </span>
                                        <?php echo esc_html($captcha_info['name']); ?>
                                    </label>
                                    <p class="sf-field-description"><?php echo esc_html($captcha_info['description']); ?></p>
                                </div>
                            <?php endforeach; ?>
                            
                            <!-- Hidden field to store the selected captcha type -->
                            <input type="hidden" id="form-captcha-type" value="<?php echo esc_attr($form_settings['captcha_type'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="sf-settings-tab-content" data-tab="webhooks">
                    <div class="sf-settings-group">
                        <div class="sf-field-row">
                            <label for="form-webhook-selection"><?php esc_html_e('Enable Webhooks for This Form', 'sigmaforms-pro'); ?></label>
                            <p class="sf-field-description"><?php esc_html_e('Enable the webhooks you want to use for this form. Each webhook will use global settings unless you override them.', 'sigmaforms-pro'); ?></p>

                            <?php
                            // Get global webhook settings to check which are configured
                            $global_webhook_settings = get_option('sigmaforms_settings', []);
                            
                            // Helper function to check if webhook is configured globally
                            function is_webhook_configured_globally($webhook_type, $global_settings) {
                                switch ($webhook_type) {
                                    case 'google_sheets':
                                        return !empty($global_settings['webhook_google_sheets_enabled']) && !empty($global_settings['webhook_google_sheets_url']);

                                    case 'slack':
                                        return !empty($global_settings['webhook_slack_enabled']) && !empty($global_settings['webhook_slack_url']);
                                    case 'discord':
                                        return !empty($global_settings['webhook_discord_enabled']) && !empty($global_settings['webhook_discord_url']);
                                    case 'telegram':
                                        return !empty($global_settings['webhook_telegram_enabled']) && !empty($global_settings['webhook_telegram_bot_token']) && !empty($global_settings['webhook_telegram_chat_id']);
                                    case 'custom':
                                        return !empty($global_settings['webhook_custom_enabled']) && !empty($global_settings['webhook_custom_url']);
                                    default:
                                        return false;
                                }
                            }
                            ?>
                            
                            <div class="sf-webhook-list">
                                <!-- Google Sheets -->
                                <div class="sf-webhook-item">
                                    <div class="sf-webhook-info">
                                        <div class="sf-webhook-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-details">
                                            <span class="sf-webhook-name"><?php esc_html_e('Google Sheets', 'sigmaforms-pro'); ?></span>
                                            <span class="sf-webhook-desc"><?php esc_html_e('Send form submissions to Google Sheets', 'sigmaforms-pro'); ?></span>
                                            <?php if (!is_webhook_configured_globally('google_sheets', $global_webhook_settings)): ?>
                                                <div class="sf-webhook-warning">
                                                    <?php echo \SigmaForms\Admin\PageHeader::icon('warning'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                    <?php esc_html_e('Not configured in global settings. Please override settings below.', 'sigmaforms-pro'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-actions">
                                        <label class="sf-toggle-switch">
                                            <input type="checkbox" id="form-webhook-google-sheets-use" <?php checked(!empty($form_settings['webhook_google_sheets_use'])); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Google Sheets Override Settings - Always Visible -->
                                <div class="sf-webhook-config-inline" id="webhook-config-google-sheets" style="display: <?php echo !empty($form_settings['webhook_google_sheets_use']) ? 'block' : 'none'; ?>;">
                                    <div class="sf-webhook-config-content">
                                        <div class="sf-webhook-config-header">
                                            <h4><?php esc_html_e('Google Sheets Settings', 'sigmaforms-pro'); ?></h4>
                                            <p><?php esc_html_e('Configure Google Sheets settings for this form. These settings will override global settings.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-config-fields">
                                            <div class="sf-field-row">
                                                <label for="form-webhook-google-sheets-url"><?php esc_html_e('Google Apps Script Web App URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="form-webhook-google-sheets-url" name="form_webhook_google_sheets_url" value="<?php echo esc_attr($form_settings['webhook_google_sheets_url'] ?? ''); ?>" placeholder="https://script.google.com/macros/s/...">
                                                <p class="sf-field-description"><?php esc_html_e('Enter the URL of your Google Apps Script web app that handles form submissions.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://developers.google.com/apps-script/guides/web" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Google Apps Script web app', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                

                                
                                <!-- Slack -->
                                <div class="sf-webhook-item">
                                    <div class="sf-webhook-info">
                                        <div class="sf-webhook-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M6 18c0 .55.45 1 1 1h1v-4H6v3zm0-5h4v-1H6v1zm0-2h4V9H6v2zm0-4h4V5H6v2zm5 12h1c.55 0 1-.45 1-1v-4h-2v4zm0-5h4v-1h-4v1zm0-2h4V9h-4v2zm0-4h4V5h-4v2z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-details">
                                            <span class="sf-webhook-name"><?php esc_html_e('Slack', 'sigmaforms-pro'); ?></span>
                                            <span class="sf-webhook-desc"><?php esc_html_e('Send notifications to Slack channels', 'sigmaforms-pro'); ?></span>
                                            <?php if (!is_webhook_configured_globally('slack', $global_webhook_settings)): ?>
                                                <div class="sf-webhook-warning">
                                                    <?php echo \SigmaForms\Admin\PageHeader::icon('warning'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                    <?php esc_html_e('Not configured in global settings. Please override settings below.', 'sigmaforms-pro'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-actions">
                                        <label class="sf-toggle-switch">
                                            <input type="checkbox" id="form-webhook-slack-use" <?php checked(!empty($form_settings['webhook_slack_use'])); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Slack Override Settings - Always Visible -->
                                <div class="sf-webhook-config-inline" id="webhook-config-slack" style="display: <?php echo !empty($form_settings['webhook_slack_use']) ? 'block' : 'none'; ?>;">
                                    <div class="sf-webhook-config-content">
                                        <div class="sf-webhook-config-header">
                                            <h4><?php esc_html_e('Slack Settings', 'sigmaforms-pro'); ?></h4>
                                            <p><?php esc_html_e('Configure Slack settings for this form. These settings will override global settings.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-config-fields">
                                            <div class="sf-field-row">
                                                <label for="form-webhook-slack-url"><?php esc_html_e('Slack Webhook URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="form-webhook-slack-url" name="form_webhook_slack_url" value="<?php echo esc_attr($form_settings['webhook_slack_url'] ?? ''); ?>" placeholder="https://hooks.slack.com/services/...">
                                                <p class="sf-field-description"><?php esc_html_e('Enter your Slack webhook URL to send notifications to your channel.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-field-row">
                                                <label for="form-webhook-slack-channel"><?php esc_html_e('Slack Channel', 'sigmaforms-pro'); ?></label>
                                                <input type="text" id="form-webhook-slack-channel" name="form_webhook_slack_channel" value="<?php echo esc_attr($form_settings['webhook_slack_channel'] ?? ''); ?>" placeholder="#general">
                                                <p class="sf-field-description"><?php esc_html_e('Enter the channel name where you want to send notifications (e.g., #general).', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://api.slack.com/messaging/webhooks" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Slack webhook', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Discord -->
                                <div class="sf-webhook-item">
                                    <div class="sf-webhook-info">
                                        <div class="sf-webhook-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-details">
                                            <span class="sf-webhook-name"><?php esc_html_e('Discord', 'sigmaforms-pro'); ?></span>
                                            <span class="sf-webhook-desc"><?php esc_html_e('Send messages to Discord channels', 'sigmaforms-pro'); ?></span>
                                            <?php if (!is_webhook_configured_globally('discord', $global_webhook_settings)): ?>
                                                <div class="sf-webhook-warning">
                                                    <?php echo \SigmaForms\Admin\PageHeader::icon('warning'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                    <?php esc_html_e('Not configured in global settings. Please override settings below.', 'sigmaforms-pro'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-actions">
                                        <label class="sf-toggle-switch">
                                            <input type="checkbox" id="form-webhook-discord-use" <?php checked(!empty($form_settings['webhook_discord_use'])); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Discord Override Settings - Always Visible -->
                                <div class="sf-webhook-config-inline" id="webhook-config-discord" style="display: <?php echo !empty($form_settings['webhook_discord_use']) ? 'block' : 'none'; ?>;">
                                    <div class="sf-webhook-config-content">
                                        <div class="sf-webhook-config-header">
                                            <h4><?php esc_html_e('Discord Settings', 'sigmaforms-pro'); ?></h4>
                                            <p><?php esc_html_e('Configure Discord settings for this form. These settings will override global settings.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-config-fields">
                                            <div class="sf-field-row">
                                                <label for="form-webhook-discord-url"><?php esc_html_e('Discord Webhook URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="form-webhook-discord-url" name="form_webhook_discord_url" value="<?php echo esc_attr($form_settings['webhook_discord_url'] ?? ''); ?>" placeholder="https://discord.com/api/webhooks/...">
                                                <p class="sf-field-description"><?php esc_html_e('Enter your Discord webhook URL to send messages to your channel.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://support.discord.com/hc/en-us/articles/228383668-Intro-to-Webhooks" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Discord webhook', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Telegram -->
                                <div class="sf-webhook-item">
                                    <div class="sf-webhook-info">
                                        <div class="sf-webhook-icon" style="background-color: #007cba;">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.02-1.96 1.25-5.54 3.69-.52.36-1 .53-1.42.52-.47-.01-1.37-.26-2.03-.48-.82-.27-1.47-.42-1.42-.88.03-.24.27-.48.74-.74 2.87-1.25 4.79-2.08 5.76-2.5 2.78-1.17 3.36-1.37 3.75-1.38.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-details">
                                            <span class="sf-webhook-name"><?php esc_html_e('Telegram', 'sigmaforms-pro'); ?></span>
                                            <span class="sf-webhook-desc"><?php esc_html_e('Send notifications to Telegram chats', 'sigmaforms-pro'); ?></span>
                                            <?php if (!is_webhook_configured_globally('telegram', $global_webhook_settings)): ?>
                                                <div class="sf-webhook-warning">
                                                    <?php echo \SigmaForms\Admin\PageHeader::icon('warning'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                    <?php esc_html_e('Not configured in global settings. Please override settings below.', 'sigmaforms-pro'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-actions">
                                        <label class="sf-toggle-switch">
                                            <input type="checkbox" id="form-webhook-telegram-use" <?php checked(!empty($form_settings['webhook_telegram_use'])); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Telegram Override Settings - Always Visible -->
                                <div class="sf-webhook-config-inline" id="webhook-config-telegram" style="display: <?php echo !empty($form_settings['webhook_telegram_use']) ? 'block' : 'none'; ?>;">
                                    <div class="sf-webhook-config-content">
                                        <div class="sf-webhook-config-header">
                                            <h4><?php esc_html_e('Telegram Settings', 'sigmaforms-pro'); ?></h4>
                                            <p><?php esc_html_e('Configure Telegram settings for this form. These settings will override global settings.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-config-fields">
                                            <div class="sf-field-row">
                                                <label for="form-webhook-telegram-bot-token"><?php esc_html_e('Telegram Bot Token', 'sigmaforms-pro'); ?></label>
                                                <input type="text" id="form-webhook-telegram-bot-token" name="form_webhook_telegram_bot_token" value="<?php echo esc_attr($form_settings['webhook_telegram_bot_token'] ?? ''); ?>" placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz">
                                                <p class="sf-field-description"><?php esc_html_e('Enter your Telegram bot token to send notifications.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-field-row">
                                                <label for="form-webhook-telegram-chat-id"><?php esc_html_e('Telegram Chat ID', 'sigmaforms-pro'); ?></label>
                                                <input type="text" id="form-webhook-telegram-chat-id" name="form_webhook_telegram_chat_id" value="<?php echo esc_attr($form_settings['webhook_telegram_chat_id'] ?? ''); ?>" placeholder="123456789">
                                                <p class="sf-field-description"><?php esc_html_e('Enter the chat ID where you want to send notifications.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://core.telegram.org/bots/api#sendmessage" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Telegram bot and get chat ID', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Custom Webhook -->
                                <div class="sf-webhook-item">
                                    <div class="sf-webhook-info">
                                        <div class="sf-webhook-icon" style="background-color: #6366F1;">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-details">
                                            <span class="sf-webhook-name"><?php esc_html_e('Custom Webhook', 'sigmaforms-pro'); ?></span>
                                            <span class="sf-webhook-desc"><?php esc_html_e('Send data to any custom endpoint', 'sigmaforms-pro'); ?></span>
                                            <?php if (!is_webhook_configured_globally('custom', $global_webhook_settings)): ?>
                                                <div class="sf-webhook-warning">
                                                    <?php echo \SigmaForms\Admin\PageHeader::icon('warning'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                    <?php esc_html_e('Not configured in global settings. Please override settings below.', 'sigmaforms-pro'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-actions">
                                        <label class="sf-toggle-switch">
                                            <input type="checkbox" id="form-webhook-custom-use" <?php checked(!empty($form_settings['webhook_custom_use'])); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Custom Webhook Override Settings - Always Visible -->
                                <div class="sf-webhook-config-inline" id="webhook-config-custom" style="display: <?php echo !empty($form_settings['webhook_custom_use']) ? 'block' : 'none'; ?>;">
                                    <div class="sf-webhook-config-content">
                                        <div class="sf-webhook-config-header">
                                            <h4><?php esc_html_e('Custom Webhook Settings', 'sigmaforms-pro'); ?></h4>
                                            <p><?php esc_html_e('Configure custom webhook settings for this form. These settings will override global settings.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-config-fields">
                                            <div class="sf-field-row">
                                                <label for="form-webhook-custom-url"><?php esc_html_e('Custom Webhook URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="form-webhook-custom-url" name="form_webhook_custom_url" value="<?php echo esc_attr($form_settings['webhook_custom_url'] ?? ''); ?>" placeholder="https://your-domain.com/webhook">
                                                <p class="sf-field-description"><?php esc_html_e('Enter the URL where you want to send form data.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-field-row">
                                                <label for="form-webhook-custom-method"><?php esc_html_e('HTTP Method', 'sigmaforms-pro'); ?></label>
                                                <select id="form-webhook-custom-method" name="form_webhook_custom_method">
                                                    <option value="POST" <?php selected($form_settings['webhook_custom_method'] ?? 'POST', 'POST'); ?>><?php esc_html_e('POST', 'sigmaforms-pro'); ?></option>
                                                    <option value="GET" <?php selected($form_settings['webhook_custom_method'] ?? 'POST', 'GET'); ?>><?php esc_html_e('GET', 'sigmaforms-pro'); ?></option>
                                                    <option value="PUT" <?php selected($form_settings['webhook_custom_method'] ?? 'POST', 'PUT'); ?>><?php esc_html_e('PUT', 'sigmaforms-pro'); ?></option>
                                                </select>
                                                <p class="sf-field-description"><?php esc_html_e('Select the HTTP method for sending data.', 'sigmaforms-pro'); ?></p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sf-field-row">
                            <div class="sf-info-box">
                                <?php echo \SigmaForms\Admin\PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                <p><?php esc_html_e('Webhook System: Enable the webhooks you want to use for this form. Each webhook will use the global settings by default. If a webhook is not configured globally, you must provide the settings below. Override settings are always available for customization.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="sf-wizard-navigation">
        <?php if ($is_edit) : ?>
            <div class="sf-save-message"></div>
        <?php endif; ?>
        
        <button type="button" class="sf-btn sf-btn-secondary sf-prev-step" data-goto="2">
            <?php echo \SigmaForms\Admin\PageHeader::icon('arrow-left'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Back to Customize', 'sigmaforms-pro'); ?>
        </button>
        <button type="button" class="sf-btn sf-btn-primary sf-next-step" data-goto="4">
            <?php $is_edit ? esc_html_e('Continue to Update', 'sigmaforms-pro') : esc_html_e('Continue to Publish', 'sigmaforms-pro'); ?> <?php echo \SigmaForms\Admin\PageHeader::icon('arrow-right'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
        </button>
        
        <?php if ($is_edit) : ?>
            <div class="sf-save-actions">
                <button type="button" class="sf-btn sf-btn-success sf-save-form" id="sf-save-form-step3">
                    <?php echo \SigmaForms\Admin\PageHeader::icon('refresh'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Update Form', 'sigmaforms-pro'); ?>
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>

<script type="text/javascript">
    // Sync title input with form settings
    jQuery(document).ready(function($) {
        if (!$('#form-id').val() || $('#form-id').val() === '0') {
            
            // Check if any code sets the checkbox to checked
            const originalProp = $.fn.prop;
            $.fn.prop = function(name, value) {
                return originalProp.apply(this, arguments);
            };
        }
        
        // Sync title input with hidden field
        $('#form-title-input').on('input', function() {
            $('#form-title').val($(this).val());
            if (window.sfFormSettings) {
                window.sfFormSettings.title = $(this).val();
            }
        });
        
        // Update hidden fields when form settings are saved from other steps
        $(document).on('sf:form_settings_saved', function() {
            if (window.sfFormSettings) {
                $('#form-title').val(window.sfFormSettings.title || '');
                $('#form-title-input').val(window.sfFormSettings.title || '');
                $('#form-submit-button-text').val(window.sfFormSettings.submit_button_text || 'Submit');
            }
        });
        
        // Webhook enable/disable functionality
        $('input[id^="form-webhook-"][id$="-use"]').on('change', function() {
            var webhookType = $(this).attr('id').replace('form-webhook-', '').replace('-use', '');
            var isChecked = $(this).is(':checked');
            
            // Show/hide the config section
            var configSection = $('#webhook-config-' + webhookType);
            if (isChecked) {
                configSection.slideDown();
            } else {
                configSection.slideUp();
            }
        });
        

        
        // Sync webhook settings when they change
        $('input[id^="form-webhook-"][id$="-use"]').on('change', function() {
            if (window.SF && window.SF.Utils && window.SF.Utils.syncFormSettings) {
                window.SF.Utils.syncFormSettings();
            }
        });
        
        // Sync webhook input fields when they change
        $('input[id^="form-webhook-"], select[id^="form-webhook-"]').on('input change', function() {
            if (window.SF && window.SF.Utils && window.SF.Utils.syncFormSettings) {
                window.SF.Utils.syncFormSettings();
            }
        });
        
        // Show/hide custom styling options based on theme selection
        $('#form-theme').on('change', function() {
            var selectedTheme = $(this).val();
            if (selectedTheme === 'custom') {
                $('#sf-custom-styling-options').slideDown();
            } else {
                $('#sf-custom-styling-options').slideUp();
            }
            
            // Sync form settings
            if (window.SF && window.SF.Utils && window.SF.Utils.syncFormSettings) {
                window.SF.Utils.syncFormSettings();
            }
        });
        
        // Sync custom styling fields when they change
        $('#sf-custom-styling-options input, #sf-custom-styling-options select').on('input change', function() {
            if (window.SF && window.SF.Utils && window.SF.Utils.syncFormSettings) {
                window.SF.Utils.syncFormSettings();
            }
        });
        
        // Color picker synchronization for custom styling
        $('#sf-custom-styling-options input[type="color"]').on('input change', function() {
            var $colorInput = $(this);
            var $textInput = $colorInput.siblings('input[type="text"]');
            if ($textInput.length) {
                $textInput.val($colorInput.val());
            }
        });
        
        $('#sf-custom-styling-options input[type="text"][name^="form_"]').on('input change', function() {
            var $textInput = $(this);
            var $colorInput = $textInput.siblings('input[type="color"]');
            if ($colorInput.length) {
                $colorInput.val($textInput.val());
            }
        });
    });
</script>
