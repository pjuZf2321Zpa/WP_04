<?php
/**
 * Step 4: Publish Form
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- Step 4: Publish Form -->
<div class="sf-wizard-step-content" data-step="4">
    <div class="sf-card">
        <div class="sf-card-header">
            <h2><?php echo $is_edit ? esc_html__('Update Your Form', 'sigmaforms-pro') : esc_html__('Publish Your Form', 'sigmaforms-pro'); ?></h2>
        </div>
        <div class="sf-step-content">
            <p class="sf-step-description">
                <?php if ($is_edit) : ?>
                    <?php esc_html_e('Your form is ready to be updated! Review the information below and click the Update button.', 'sigmaforms-pro'); ?>
                <?php else : ?>
                    <?php esc_html_e('Your form is ready to be published! Review the information below and click the Publish button.', 'sigmaforms-pro'); ?>
                <?php endif; ?>
            </p>
            
            <div class="sf-form-summary">
                <div class="sf-summary-section">
                    <h3><?php esc_html_e('Form Details', 'sigmaforms-pro'); ?></h3>
                    <div class="sf-summary-item">
                        <div class="sf-summary-label"><?php esc_html_e('Name:', 'sigmaforms-pro'); ?></div>
                        <div class="sf-summary-value" id="summary-form-title"></div>
                    </div>
                    <div class="sf-summary-item">
                        <div class="sf-summary-label"><?php esc_html_e('Fields:', 'sigmaforms-pro'); ?></div>
                        <div class="sf-summary-value" id="summary-field-count"></div>
                    </div>
                </div>
                <?php if ($is_edit) : ?>
                <div class="sf-summary-section" style="margin-top: 20px;">
                    <h3><?php esc_html_e('Shortcode', 'sigmaforms-pro'); ?></h3>
                    <p><?php esc_html_e('Use this shortcode to display your form on any page or post:', 'sigmaforms-pro'); ?></p>

                    <div class="sf-shortcode-container">
                        <div class="sf-shortcode-display">
                            <div class="sf-shortcode-copy-row">
                                <label for="sf-shortcode"><?php esc_html_e('Shortcode:', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="sf-shortcode" value='<?php echo esc_attr("[sigmaforms id=\"$form_id\"]"); ?>' readonly>
                                <button type="button" class="sf-btn sf-btn-sm sf-btn-secondary copy-shortcode" data-clipboard-text='<?php echo esc_attr("[sigmaforms id=\"$form_id\"]"); ?>'>
                                    <?php echo \SigmaForms\Admin\PageHeader::icon('copy'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <p class="sf-shortcode-instructions">
                        <?php esc_html_e('After publishing, you can copy this shortcode and paste it into any page or post where you want the form to appear.', 'sigmaforms-pro'); ?>
                    </p>
                </div>
                <?php endif; ?>
                 <div class="sf-summary-section" id="sf-form-success-shortcode-section" style="margin-top: 20px; display:none;">
                    <h3><?php esc_html_e('Shortcode', 'sigmaforms-pro'); ?></h3>
                    <p><?php esc_html_e('Use this shortcode to display your form on any page or post:', 'sigmaforms-pro'); ?></p>

                    <div class="sf-shortcode-container">
                        <div class="sf-shortcode-display">
                            <div class="sf-shortcode-copy-row">
                                <label for="sf-shortcode"><?php esc_html_e('Shortcode:', 'sigmaforms-pro'); ?></label>
                                <input type="text" id="sf-shortcode" value='' readonly>
                                <button type="button" class="sf-btn sf-btn-sm sf-btn-secondary copy-shortcode">
                                    <?php echo \SigmaForms\Admin\PageHeader::icon('copy'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <p class="sf-shortcode-instructions">
                        <?php esc_html_e('After publishing, you can copy this shortcode and paste it into any page or post where you want the form to appear.', 'sigmaforms-pro'); ?>
                    </p>
                </div>
            </div>
            
        </div>
        
        <div class="sf-card-footer" style="display:none">
            <div class="sf-save-message"></div>
        </div>
    </div>
    
    <div class="sf-wizard-navigation">
        <button type="button" class="sf-btn sf-btn-secondary sf-prev-step" data-goto="3">
            <?php echo \SigmaForms\Admin\PageHeader::icon('arrow-left'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Back to Configure', 'sigmaforms-pro'); ?>
        </button>
        <button type="button" class="sf-btn sf-btn-primary sf-save-form" id="sf-save-form">
            <?php if ($is_edit) : ?>
                <?php echo \SigmaForms\Admin\PageHeader::icon('refresh'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Update Form', 'sigmaforms-pro'); ?>
            <?php else : ?>
                <?php echo \SigmaForms\Admin\PageHeader::icon('check'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Publish Form', 'sigmaforms-pro'); ?>
            <?php endif; ?>
        </button>
    </div>
</div>
<script>
    jQuery(document).ready(function($) {
        // Copy shortcode
        $('.copy-shortcode').on('click', function() {
            const shortcode = $(this).data('clipboard-text');
            
            // Create temporary textarea to copy from
            const $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val(shortcode).select();
            document.execCommand('copy');
            $temp.remove();
            
            // Show copied text, then put the button's own markup (icon included) back
            const $this = $(this);
            const originalHtml = $this.html();

            $this.text('<?php echo esc_js(__('Copied!', 'sigmaforms-pro')); ?>');

            setTimeout(function() {
                $this.html(originalHtml);
            }, 2000);
        });
    });
</script>
