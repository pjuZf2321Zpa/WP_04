<?php
/**
 * White label settings page.
 *
 * @package SigmaForms
 */

if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\Admin\PageHeader;
use SigmaForms\WhiteLabel\WhiteLabelAdmin;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global
$eligible       = WhiteLabel::is_white_label_license();
$wl_enabled     = (bool) get_option(WhiteLabel::OPTION_ENABLED, false);
$brand          = WhiteLabel::get_display_name();
$logo_url           = $wl_enabled ? trim((string) get_option(WhiteLabel::OPTION_LOGO, '')) : '';
$preview_logo_url   = $logo_url !== '' ? $logo_url : WhiteLabel::get_default_admin_logo_url();
$wl_toggle_text     = $wl_enabled ? __('Enabled', 'sigmaforms-pro') : __('Disabled', 'sigmaforms-pro');
?>
<div class="sf-admin-wrap sf-white-label-page">
    <?php
    PageHeader::render();
    PageHeader::intro(
        array(
            'title'       => __('White Label', 'sigmaforms-pro'),
            'description' => __('Replace plugin branding across admin menu, page headers, and license screens — for a fully white labeled client experience.', 'sigmaforms-pro'),
        )
    );
    ?>

    <div class="sf-wl-notices" aria-live="polite"></div>

    <?php if (!$eligible) : ?>
        <div class="sf-wl-upgrade">
            <div class="sf-wl-upgrade__icon" aria-hidden="true">
                <?php echo \SigmaForms\Admin\PageHeader::icon('lock'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            </div>
            <h2><?php esc_html_e('White label requires an eligible license', 'sigmaforms-pro'); ?></h2>
            <p><?php esc_html_e('Upgrade to Agency, Extended, Developer, or a special WL license with an active SigmaForms license to unlock full white label controls.', 'sigmaforms-pro'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms_license')); ?>" class="sf-btn sf-btn-primary">
                <?php esc_html_e('View license', 'sigmaforms-pro'); ?>
            </a>
        </div>
    <?php else : ?>
        <form id="sf-white-label-form" class="sf-wl-form">
            <div class="sf-wl-layout">
                <div class="sf-wl-main">
                    <section class="sf-wl-section sf-wl-section--master">
                        <div class="sf-wl-section__head">
                            <div>
                                <h2><?php esc_html_e('White Label Mode', 'sigmaforms-pro'); ?></h2>
                                <p><?php esc_html_e('Turn on to apply your brand across all SigmaForms admin screens.', 'sigmaforms-pro'); ?></p>
                            </div>
                            <label class="sf-toggle-label sf-wl-toggle-master">
                                <span class="sf-toggle-switch">
                                    <input type="checkbox" name="enabled" value="1" id="sf-wl-enabled" />
                                    <span class="sf-toggle-slider"></span>
                                </span>
                                <span class="sf-wl-toggle-text"><?php echo esc_html($wl_toggle_text); ?></span>
                            </label>
                        </div>
                    </section>

                    <section class="sf-wl-section sf-wl-branding" data-wl-section="branding">
                        <div class="sf-wl-section__title">
                            <span class="sf-wl-section__icon"><?php echo \SigmaForms\Admin\PageHeader::icon('pen'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                            <div>
                                <h2><?php esc_html_e('Brand Identity', 'sigmaforms-pro'); ?></h2>
                                <p><?php esc_html_e('The name shown in menus, page titles, and admin headers.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                        <div class="sf-wl-field">
                            <label for="sf-wl-title"><?php esc_html_e('Brand title', 'sigmaforms-pro'); ?></label>
                            <input type="text" id="sf-wl-title" name="title" placeholder="<?php esc_attr_e('SigmaForms', 'sigmaforms-pro'); ?>" autocomplete="off" />
                            <p class="sf-wl-field__hint"><?php esc_html_e('Leave empty to keep the default plugin name.', 'sigmaforms-pro'); ?></p>
                        </div>
                    </section>

                    <section class="sf-wl-section sf-wl-section--assets sf-wl-branding" data-wl-section="branding">
                        <div class="sf-wl-section__title sf-wl-section__title--compact">
                            <span class="sf-wl-section__icon"><?php echo \SigmaForms\Admin\PageHeader::icon('image'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                            <div>
                                <h2><?php esc_html_e('Visual Assets', 'sigmaforms-pro'); ?></h2>
                                <p><?php esc_html_e('Icon for admin menu · logo for page headers.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                        <div class="sf-wl-assets">
                            <div class="sf-wl-asset" data-type="icon">
                                <div class="sf-wl-asset__preview sf-wl-preview sf-wl-preview--icon" data-type="icon">
                                    <span class="sf-wl-preview__empty">
                                        <span class="dashicons dashicons-admin-appearance"></span>
                                    </span>
                                </div>
                                <div class="sf-wl-asset__body">
                                    <div class="sf-wl-asset__info">
                                        <h3><?php esc_html_e('Menu icon', 'sigmaforms-pro'); ?></h3>
                                        <p><?php esc_html_e('20×20px · square', 'sigmaforms-pro'); ?></p>
                                    </div>
                                    <input type="hidden" name="icon" value="" />
                                    <input type="hidden" name="icon_id" value="0" />
                                    <div class="sf-wl-asset__actions">
                                        <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-wl-pick" data-type="icon">
                                            <?php echo \SigmaForms\Admin\PageHeader::icon('upload'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                            <?php esc_html_e('Upload', 'sigmaforms-pro'); ?>
                                        </button>
                                        <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-wl-remove" data-type="icon">
                                            <?php echo \SigmaForms\Admin\PageHeader::icon('trash'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                            <?php esc_html_e('Remove', 'sigmaforms-pro'); ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="sf-wl-asset" data-type="logo">
                                <div class="sf-wl-asset__preview sf-wl-preview sf-wl-preview--logo" data-type="logo">
                                    <span class="sf-wl-preview__empty">
                                        <span class="dashicons dashicons-format-image"></span>
                                    </span>
                                </div>
                                <div class="sf-wl-asset__body">
                                    <div class="sf-wl-asset__info">
                                        <h3><?php esc_html_e('Admin logo', 'sigmaforms-pro'); ?></h3>
                                        <p><?php esc_html_e('PNG or SVG · page headers', 'sigmaforms-pro'); ?></p>
                                    </div>
                                    <input type="hidden" name="logo" value="" />
                                    <input type="hidden" name="logo_id" value="0" />
                                    <div class="sf-wl-asset__actions">
                                        <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-wl-pick" data-type="logo">
                                            <?php echo \SigmaForms\Admin\PageHeader::icon('upload'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                            <?php esc_html_e('Upload', 'sigmaforms-pro'); ?>
                                        </button>
                                        <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-wl-remove" data-type="logo">
                                            <?php echo \SigmaForms\Admin\PageHeader::icon('trash'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                            <?php esc_html_e('Remove', 'sigmaforms-pro'); ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="sf-wl-section sf-wl-branding" data-wl-section="branding">
                        <div class="sf-wl-section__title">
                            <span class="sf-wl-section__icon"><?php echo \SigmaForms\Admin\PageHeader::icon('eye-off'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                            <div>
                                <h2><?php esc_html_e('Visibility', 'sigmaforms-pro'); ?></h2>
                                <p><?php esc_html_e('Control what clients see in the WordPress admin menu.', 'sigmaforms-pro'); ?></p>
                            </div>
                        </div>
                        <div class="sf-wl-toggles">
                            <div class="sf-wl-toggle-row">
                                <div class="sf-wl-toggle-row__text">
                                    <strong><?php esc_html_e('Hide License Menu', 'sigmaforms-pro'); ?></strong>
                                    <span><?php esc_html_e('Remove the License submenu from Admin Dashboard navigation.', 'sigmaforms-pro'); ?></span>
                                </div>
                                <label class="sf-toggle-label sf-wl-toggle-row__control">
                                    <span class="sf-toggle-switch">
                                        <input type="checkbox" name="hide_license" value="1" id="sf-wl-hide-license" />
                                        <span class="sf-toggle-slider"></span>
                                    </span>
                                </label>
                            </div>
                            <div class="sf-wl-toggle-row">
                                <div class="sf-wl-toggle-row__text">
                                    <strong><?php esc_html_e('Hide Settings Menu', 'sigmaforms-pro'); ?></strong>
                                    <span><?php esc_html_e('Removes the Settings and White Label submenus. SigmaForms stays visible. A recovery link is emailed to the license holder.', 'sigmaforms-pro'); ?></span>
                                </div>
                                <label class="sf-toggle-label sf-wl-toggle-row__control">
                                    <span class="sf-toggle-switch">
                                        <input type="checkbox" name="hide_admin" value="1" id="sf-wl-hide-settings-menu" />
                                        <span class="sf-toggle-slider"></span>
                                    </span>
                                </label>
                            </div>
                        </div>
                        <div class="sf-wl-recovery sf-wl-localhost-preview" style="display:none;">
                            <?php echo \SigmaForms\Admin\PageHeader::icon('link'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                            <div>
                                <strong><?php esc_html_e('Recovery URL', 'sigmaforms-pro'); ?></strong>
                                <p><?php esc_html_e('Save this link if the recovery email could not be delivered.', 'sigmaforms-pro'); ?></p>
                                <a href="#" target="_blank" rel="noopener noreferrer" class="sf-wl-recovery__link"></a>
                            </div>
                        </div>
                    </section>
                </div>

                <aside class="sf-wl-sidebar">
                    <div class="sf-wl-preview-panel">
                        <div class="sf-wl-preview-panel__label"><?php esc_html_e('Live preview', 'sigmaforms-pro'); ?></div>
                        <div class="sf-wl-mock<?php echo $wl_enabled ? '' : ' is-wl-disabled'; ?>">
                            <div class="sf-wl-mock__chrome">
                                <span></span><span></span><span></span>
                            </div>
                            <div class="sf-wl-mock__body">
                                <div class="sf-wl-mock__menu-wrap" id="sf-wl-preview-menu-wrap">
                                    <div class="sf-wl-mock__menu" id="sf-wl-preview-menu">
                                        <div class="sf-wl-mock__menu-item sf-wl-mock__menu-item--active">
                                            <span class="sf-wl-mock__menu-icon" id="sf-wl-preview-icon">
                                                <span class="dashicons dashicons-feedback"></span>
                                            </span>
                                            <span class="sf-wl-mock__menu-label" id="sf-wl-preview-menu-label"><?php echo esc_html($brand); ?></span>
                                        </div>
                                        <div class="sf-wl-mock__menu-item sf-wl-mock__menu-item--sub"><?php esc_html_e('Forms', 'sigmaforms-pro'); ?></div>
                                        <div class="sf-wl-mock__menu-item sf-wl-mock__menu-item--sub sf-wl-mock__menu-item--settings" id="sf-wl-preview-settings"><?php esc_html_e('Settings', 'sigmaforms-pro'); ?></div>
                                        <div class="sf-wl-mock__menu-item sf-wl-mock__menu-item--sub sf-wl-mock__menu-item--wl" id="sf-wl-preview-wl-menu"><?php esc_html_e('White Label', 'sigmaforms-pro'); ?></div>
                                        <div class="sf-wl-mock__menu-item sf-wl-mock__menu-item--sub sf-wl-mock__menu-item--license" id="sf-wl-preview-license"><?php esc_html_e('License', 'sigmaforms-pro'); ?></div>
                                    </div>
                                </div>
                                <div class="sf-wl-mock__content">
                                    <div class="sf-wl-mock__header">
                                        <img src="<?php echo esc_url($preview_logo_url); ?>" alt="" class="sf-wl-mock__header-logo" id="sf-wl-preview-logo" />
                                        <h3 id="sf-wl-preview-page-title"><?php echo esc_html($brand); ?></h3>
                                    </div>
                                    <div class="sf-wl-mock__skeleton">
                                        <span></span><span></span><span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p class="sf-wl-preview-panel__note"><?php esc_html_e('Preview updates as you edit. Save to apply across wp-admin.', 'sigmaforms-pro'); ?></p>
                    </div>
                </aside>
            </div>

            <div class="sf-wl-footer">
                <button type="button" class="sf-btn sf-btn-outline-secondary sf-wl-revoke-token" hidden>
                    <?php echo \SigmaForms\Admin\PageHeader::icon('x-circle'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <?php esc_html_e('Revoke recovery token', 'sigmaforms-pro'); ?>
                </button>
                <button type="submit" class="sf-btn sf-btn-primary sf-wl-save">
                    <?php echo \SigmaForms\Admin\PageHeader::icon('check'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <?php esc_html_e('Save white label', 'sigmaforms-pro'); ?>
                </button>
            </div>
        </form>
    <?php endif; ?>
</div>
