<?php
/**
 * Admin view for submissions list
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Get form_id from URL only if nonce is verified
if (
    isset($_GET['form_id'], $_GET['sf_filter_nonce']) &&
    wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['sf_filter_nonce'])), 'sf_filter')
) {
    $form_id = intval($_GET['form_id']);
} else {
    $form_id = 0;
}
// Get pagination parameters
$page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 20;

// Get submissions for the selected form or all forms
global $wpdb;
$submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
$forms_table = $wpdb->prefix . 'sigmaforms';

$where = '';
$params = [];

if ($form_id > 0) {
    $where = 'WHERE s.form_id = %d';
    $params[] = $form_id;
}

// Count total submissions
$total_query = "SELECT COUNT(s.id) FROM {$submissions_table} s {$where}";
if (!empty($params)) {
    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $total_items = $wpdb->get_var($wpdb->prepare($total_query, ...$params));
} else {
    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $total_items = $wpdb->get_var($total_query);
}

// Calculate pagination
$total_pages = ceil($total_items / $per_page);
$offset = ($page - 1) * $per_page;

// Get submissions
$query = "
    SELECT s.*, f.title as form_title 
    FROM {$submissions_table} s 
    LEFT JOIN {$forms_table} f ON s.form_id = f.id 
    {$where}
    ORDER BY s.date_created DESC 
    LIMIT %d OFFSET %d
";

$params[] = $per_page;
$params[] = $offset;

if (!empty($params)) {
    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $submissions = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
} else {
    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $submissions = $wpdb->get_results($wpdb->prepare($query, $per_page, $offset), ARRAY_A);
}

// Get all forms for the filter dropdown
$forms_query = "SELECT id, title FROM {$forms_table} ORDER BY title ASC";
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
$forms = $wpdb->get_results($forms_query, ARRAY_A);
?>

<div class="sf-admin-wrap sf-submissions-page">
    <?php
    $submissions_after = '';
    if ($form_id > 0 && isset($forms[$form_id])) {
        $submissions_after = ': ' . esc_html($forms[$form_id]['title']);
    }
    PageHeader::render();
    PageHeader::intro(
        array(
            'title'       => __('Submissions', 'sigmaforms-pro'),
            'after_title' => $submissions_after,
            'actions'        => array(
                array(
                    'url'   => admin_url('admin.php?page=sigmaforms'),
                    'label' => __('Back to Forms', 'sigmaforms-pro'),
                    'icon'  => 'arrow-left',
                ),
            ),
        )
    );
    ?>

    <div class="sf-card">
        <div class="sf-submission-filter">
            <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" id="submissions-filter-form">
                <input type="hidden" name="page" value="sigmaforms-submissions">
                <input type="hidden" name="sf_filter_nonce"
                    value="<?php echo esc_attr(wp_create_nonce('sf_filter')); ?>">
                <select name="form_id" id="filter-by-form">
                    <option value=""><?php esc_html_e('All Forms', 'sigmaforms-pro'); ?></option>
                    <?php foreach ($forms as $form): ?>
                        <option value="<?php echo esc_attr($form['id']); ?>" <?php selected($form_id, $form['id']); ?>>
                            <?php
                                /* translators: 1: form title, 2: form ID */
                                echo esc_html(sprintf(__('%1$s (#%2$d)', 'sigmaforms-pro'), $form['title'], $form['id']));
                                ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <?php if (empty($submissions)): ?>
            <div class="sf-no-data-message is-empty">
                <span class="sf-no-data-icon"><?php echo PageHeader::icon('inbox'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                <p><?php esc_html_e('No submissions found.', 'sigmaforms-pro'); ?></p>
            </div>
        <?php else: ?>
            <form method="post">
                <div class="tablenav top">
                    <div class="alignleft actions bulkactions">
                        <label for="bulk-action-selector-top"
                            class="screen-reader-text"><?php esc_html_e('Select bulk action', 'sigmaforms-pro'); ?></label>
                        <select name="action" id="bulk-action-selector-top">
                            <option value="-1"><?php esc_html_e('Bulk Actions', 'sigmaforms-pro'); ?></option>
                            <option value="delete"><?php esc_html_e('Delete', 'sigmaforms-pro'); ?></option>
                            <option value="mark-read"><?php esc_html_e('Mark as Read', 'sigmaforms-pro'); ?></option>
                            <option value="mark-unread"><?php esc_html_e('Mark as Unread', 'sigmaforms-pro'); ?></option>
                        </select>
                        <input type="submit" id="doaction" class="button action"
                            value="<?php esc_attr_e('Apply', 'sigmaforms-pro'); ?>">
                    </div>
                    <div class="tablenav-pages">
                        <span class="displaying-num">
                            <?php
                            printf(
                                esc_html(
                                    sprintf(
                                        /* translators: %s: Number of items */
                                        _n('%s item', '%s items', $total_items, 'sigmaforms-pro'),
                                        number_format_i18n($total_items)
                                    )
                                )
                            );
                            ?>
                        </span>
                        <?php if ($total_pages > 1): ?>
                            <span class="sf-pagination-links">
                                <?php
                                echo wp_kses_post(paginate_links([
                                    'base' => add_query_arg('paged', '%#%'),
                                    'format' => '',
                                    'prev_text' => __('Previous', 'sigmaforms-pro'),
                                    'next_text' => __('Next', 'sigmaforms-pro'),
                                    'total' => $total_pages,
                                    'current' => $page,
                                    'mid_size' => 2,
                                    'end_size' => 1,
                                ]));
                                ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="sf-form-list">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <td id="cb" class="manage-column column-cb check-column">
                                    <input id="cb-select-all-1" type="checkbox">
                                </td>
                                <th scope="col" class="manage-column column-status">
                                    <?php esc_html_e('Status', 'sigmaforms-pro'); ?></th>
                                <th scope="col" class="manage-column column-form"><?php esc_html_e('Form', 'sigmaforms-pro'); ?>
                                </th>
                                <th scope="col" class="manage-column column-submitted-by">
                                    <?php esc_html_e('Submitted By', 'sigmaforms-pro'); ?></th>
                                <th scope="col" class="manage-column column-date"><?php esc_html_e('Date', 'sigmaforms-pro'); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($submissions as $submission):
                                // Convert field values from JSON
                                $field_values = json_decode($submission['field_values'], true) ?: [];

                                // Get submitter info (name and email if available)
                                $submitter_name = '';
                                $submitter_email = '';

                                foreach ($field_values as $field_id => $field_value) {
                                    if (preg_match('/(name|full[-_]?name|first[-_]?name)/i', $field_id) && empty($submitter_name)) {
                                        $submitter_name = $field_value;
                                    }

                                    if (preg_match('/email/i', $field_id) && empty($submitter_email)) {
                                        $submitter_email = $field_value;
                                    }
                                }

                                // Format date
                                $date_created = mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $submission['date_created']);

                                // Get user info if submission is by logged-in user
                                $user_info = '';
                                if (!empty($submission['user_id'])) {
                                    $user = get_userdata($submission['user_id']);
                                    if ($user) {
                                        $user_info = $user->display_name . ' (' . $user->user_email . ')';
                                    }
                                }

                                // Submission URL
                                $submission_url = add_query_arg([
                                    'page' => 'sigmaforms-submissions',
                                    'submission_id' => $submission['id'],
                                    '_wpnonce' => wp_create_nonce('view_submission_' . $submission['id']),
                                ], admin_url('admin.php'));
                                ?>
                                <tr>
                                    <th scope="row" class="check-column">
                                        <input type="checkbox" name="submission[]"
                                            value="<?php echo esc_attr($submission['id']); ?>">
                                    </th>
                                    <td class="column-status">
                                        <?php if ($submission['status'] === 'unread'): ?>
                                            <span
                                                class="sf-status sf-status-unread"><?php esc_html_e('Unread', 'sigmaforms-pro'); ?></span>
                                        <?php else: ?>
                                            <span
                                                class="sf-status sf-status-read"><?php esc_html_e('Read', 'sigmaforms-pro'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-form">
                                        <a href="<?php echo esc_url($submission_url); ?>">
                                            <?php
                                            // Show deleted form message if form_title is null
                                            if ($submission['form_title'] !== null && $submission['form_title'] !== '') {
                                                echo esc_html($submission['form_title']);
                                            } else {
                                                printf(
                                                    /* translators: %d is the form ID */
                                                    esc_html__('Deleted Form - #%d', 'sigmaforms-pro'),
                                                    (int) $submission['form_id']
                                                );
                                            }
                                            ?>
                                        </a>
                                        <div class="row-actions">
                                            <span class="view">
                                                <a
                                                    href="<?php echo esc_url($submission_url); ?>"><?php esc_html_e('View', 'sigmaforms-pro'); ?></a>
                                                |
                                            </span>
                                            <span class="trash">
                                                <a href="#" class="submitdelete sf-delete-submission"
                                                    data-id="<?php echo esc_attr($submission['id']); ?>">
                                                    <?php esc_html_e('Delete', 'sigmaforms-pro'); ?>
                                                </a>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="column-submitted-by">
                                        <?php if (!empty($user_info)): ?>
                                            <?php echo esc_html($user_info); ?>
                                        <?php elseif (!empty($submitter_name) || !empty($submitter_email)): ?>
                                            <?php
                                            if (!empty($submitter_name)) {
                                                echo esc_html($submitter_name);

                                                if (!empty($submitter_email)) {
                                                    echo ' (' . esc_html($submitter_email) . ')';
                                                }
                                            } else {
                                                echo esc_html($submitter_email);
                                            }
                                            ?>
                                        <?php else: ?>
                                            <?php esc_html_e('Guest', 'sigmaforms-pro'); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-date">
                                        <?php echo esc_html($date_created); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td class="manage-column column-cb check-column">
                                    <input id="cb-select-all-2" type="checkbox">
                                </td>
                                <th scope="col" class="manage-column column-status">
                                    <?php esc_html_e('Status', 'sigmaforms-pro'); ?></th>
                                <th scope="col" class="manage-column column-form"><?php esc_html_e('Form', 'sigmaforms-pro'); ?>
                                </th>
                                <th scope="col" class="manage-column column-submitted-by">
                                    <?php esc_html_e('Submitted By', 'sigmaforms-pro'); ?></th>
                                <th scope="col" class="manage-column column-date"><?php esc_html_e('Date', 'sigmaforms-pro'); ?>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="tablenav bottom">
                    <div class="alignleft actions bulkactions">
                        <label for="bulk-action-selector-bottom"
                            class="screen-reader-text"><?php esc_html_e('Select bulk action', 'sigmaforms-pro'); ?></label>
                        <select name="action2" id="bulk-action-selector-bottom">
                            <option value="-1"><?php esc_html_e('Bulk Actions', 'sigmaforms-pro'); ?></option>
                            <option value="delete"><?php esc_html_e('Delete', 'sigmaforms-pro'); ?></option>
                            <option value="mark-read"><?php esc_html_e('Mark as Read', 'sigmaforms-pro'); ?></option>
                            <option value="mark-unread"><?php esc_html_e('Mark as Unread', 'sigmaforms-pro'); ?></option>
                        </select>
                        <input type="submit" id="doaction2" class="button action"
                            value="<?php esc_attr_e('Apply', 'sigmaforms-pro'); ?>">
                    </div>
                    <div class="tablenav-pages">
                        <span class="displaying-num">
                            <?php
                            printf(
                                esc_html(
                                    sprintf(
                                        /* translators: %s: Number of items */
                                        _n('%s item', '%s items', $total_items, 'sigmaforms-pro'),
                                        number_format_i18n($total_items)
                                    )
                                )
                            );
                            ?>
                        </span>
                        <?php if ($total_pages > 1): ?>
                            <span class="sf-pagination-links">
                                <?php
                                echo wp_kses_post(paginate_links([
                                    'base' => add_query_arg('paged', '%#%'),
                                    'format' => '',
                                    'prev_text' => __('Previous', 'sigmaforms-pro'),
                                    'next_text' => __('Next', 'sigmaforms-pro'),
                                    'total' => $total_pages,
                                    'current' => $page,
                                    'mid_size' => 2,
                                    'end_size' => 1,
                                ]));
                                ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        <?php endif; ?>

        <!-- Export Options -->
        <?php if (!empty($submissions) && SigmaForms\Plugin::is_license_valid()): ?>
            <div class="sf-export-options">
                <h3><?php esc_html_e('Export Data', 'sigmaforms-pro'); ?></h3>
                <p><?php esc_html_e('Export submissions data for further analysis.', 'sigmaforms-pro'); ?></p>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?action=export_submissions&form_id=' . $form_id), 'export_submissions')); ?>"
                    class="button button-secondary sf-btn sf-btn-secondary">
                    <?php echo PageHeader::icon('download'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <span><?php esc_html_e('Export to CSV', 'sigmaforms-pro'); ?></span>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    jQuery(document).ready(function ($) {
        // Auto-submit form when selecting a form filter
        $('#filter-by-form').on('change', function () {
            $('#submissions-filter-form').submit();
        });

        // Handle bulk actions form submission
        $('#doaction, #doaction2').on('click', function (e) {
            e.preventDefault();

            const isTopAction = $(this).attr('id') === 'doaction';
            const actionSelector = isTopAction ? '#bulk-action-selector-top' : '#bulk-action-selector-bottom';
            const action = $(actionSelector).val();
            const selectedSubmissions = $('input[name="submission[]"]:checked').map(function () {
                return $(this).val();
            }).get();

            if (action === '-1') {
                window.SF.notify('<?php echo esc_js(__('Please select a bulk action.', 'sigmaforms-pro')); ?>');
                return;
            }

            if (selectedSubmissions.length === 0) {
                window.SF.notify('<?php echo esc_js(__('Please select at least one submission.', 'sigmaforms-pro')); ?>');
                return;
            }

            let confirmMessage = '';
            let ajaxAction = '';

            switch (action) {
                case 'delete':
                    confirmMessage = '<?php echo esc_js(__('Are you sure you want to delete the selected submissions? This action cannot be undone.', 'sigmaforms-pro')); ?>';
                    ajaxAction = 'sf_bulk_delete_submissions';
                    break;
                case 'mark-read':
                    confirmMessage = '<?php echo esc_js(__('Are you sure you want to mark the selected submissions as read?', 'sigmaforms-pro')); ?>';
                    ajaxAction = 'sf_bulk_mark_submissions_as_read';
                    break;
                case 'mark-unread':
                    confirmMessage = '<?php echo esc_js(__('Are you sure you want to mark the selected submissions as unread?', 'sigmaforms-pro')); ?>';
                    ajaxAction = 'sf_bulk_mark_submissions_as_unread';
                    break;
                default:
                    return;
            }

            window.SF.confirm(confirmMessage, { danger: action === 'delete' }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                // Show loading state on both buttons
                $('#doaction, #doaction2').prop('disabled', true).val('<?php echo esc_js(__('Processing...', 'sigmaforms-pro')); ?>');

                $.ajax({
                    url: sfAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: ajaxAction,
                        nonce: sfAdmin.nonce,
                        submission_ids: selectedSubmissions
                    },
                    success: function (response) {
                        if (response.success) {
                            window.SF.notify(response.data.message, 'success');
                            // Reload to reflect the changes once the message has been seen.
                            setTimeout(function () {
                                window.location.reload();
                            }, 1200);
                        } else {
                            window.SF.notify(response.data.message || '<?php echo esc_js(__('Error processing bulk action.', 'sigmaforms-pro')); ?>');
                        }
                    },
                    error: function () {
                        window.SF.notify('<?php echo esc_js(__('Error processing bulk action.', 'sigmaforms-pro')); ?>');
                    },
                    complete: function () {
                        // Reset button state on both buttons
                        $('#doaction, #doaction2').prop('disabled', false).val('<?php esc_attr_e('Apply', 'sigmaforms-pro'); ?>');
                    }
                });
            });
        });

        // Handle select all checkbox (top)
        $('#cb-select-all-1').on('change', function () {
            const isChecked = $(this).is(':checked');
            $('input[name="submission[]"]').prop('checked', isChecked);
            updateSelectAllCheckboxState();
        });

        // Handle select all checkbox (bottom) - add this if you want a bottom select all checkbox
        // $('#cb-select-all-2').on('change', function() {
        //     const isChecked = $(this).is(':checked');
        //     $('input[name="submission[]"]').prop('checked', isChecked);
        //     updateSelectAllCheckboxState();
        // });

        // Handle select all checkbox (bottom)
        $('#cb-select-all-2').on('change', function () {
            const isChecked = $(this).is(':checked');
            $('input[name="submission[]"]').prop('checked', isChecked);
            updateSelectAllCheckboxState();
        });

        // Update select all checkbox state when individual checkboxes change
        $('input[name="submission[]"]').on('change', function () {
            updateSelectAllCheckboxState();
        });

        // Function to update select all checkbox state
        function updateSelectAllCheckboxState() {
            const totalCheckboxes = $('input[name="submission[]"]').length;
            const checkedCheckboxes = $('input[name="submission[]"]:checked').length;

            if (checkedCheckboxes === 0) {
                $('#cb-select-all-1, #cb-select-all-2').prop('indeterminate', false).prop('checked', false);
            } else if (checkedCheckboxes === totalCheckboxes) {
                $('#cb-select-all-1, #cb-select-all-2').prop('indeterminate', false).prop('checked', true);
            } else {
                $('#cb-select-all-1, #cb-select-all-2').prop('indeterminate', true);
            }
        }

        // Synchronize bulk action selectors
        $('#bulk-action-selector-top, #bulk-action-selector-bottom').on('change', function () {
            const value = $(this).val();
            $('#bulk-action-selector-top, #bulk-action-selector-bottom').val(value);
        });

        // Delete submission
        $('.sf-delete-submission').on('click', function (e) {
            e.preventDefault();

            const $sfTrigger = $(this);
            window.SF.confirm('<?php echo esc_js(__('Are you sure you want to delete this submission? This action cannot be undone.', 'sigmaforms-pro')); ?>', { danger: true }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                const submissionId = $sfTrigger.data('id');

                $.ajax({
                    url: sfAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_delete_submission',
                        nonce: sfAdmin.nonce,
                        submission_id: submissionId
                    },
                    success: function (response) {
                        if (response.success) {
                            window.location.reload();
                        } else {
                            window.SF.notify(response.data.message || '<?php echo esc_js(__('Error deleting submission.', 'sigmaforms-pro')); ?>');
                        }
                    },
                    error: function () {
                        window.SF.notify('<?php echo esc_js(__('Error deleting submission.', 'sigmaforms-pro')); ?>');
                    }
                });
            });
        });
    });
</script>