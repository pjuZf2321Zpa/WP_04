<?php
/**
 * Abandoned Forms List View
 *
 * @package SigmaForms
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Handle filters
if (isset($_GET['filter_action']) && $_GET['filter_action'] === 'Filter') {
    $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
    if (!wp_verify_nonce(wp_unslash($nonce), 'abandoned_forms_filter')) {
        wp_die(
                    esc_html__('Invalid or missing nonce for abandoned forms filter.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
    }
}
$current_form_id = isset($_GET['form_id']) ? (int) $_GET['form_id'] : 0;
$current_status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : 'all';
$current_page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
$per_page = 20;

// Build filters array
$filters = [];
if ($current_form_id > 0) {
    $filters['form_id'] = $current_form_id;
}
if ($current_status === 'converted') {
    $filters['is_converted'] = true;
} elseif ($current_status === 'abandoned') {
    $filters['is_converted'] = false;
}

// Get abandoned forms
$abandoned_forms = $abandoned_forms_manager->get_abandoned_forms($current_page, $per_page, $filters);
$total_count = $abandoned_forms_manager->get_abandoned_forms_count($filters);
$total_pages = ceil($total_count / $per_page);

// Get analytics for all forms
$analytics_data = [];
foreach ($forms as $form) {
    $analytics_data[$form['id']] = $abandoned_forms_manager->get_form_analytics($form['id']);
}
?>

<div>
    <div class="sf-admin-wrap">
        <?php
        PageHeader::render();
        PageHeader::intro(
            array(
                'title' => __('Abandoned Forms', 'sigmaforms-pro'),
            )
        );
        ?>

        <!-- Success/Error Messages -->
        <?php
        $message = isset($_GET['message']) ? sanitize_text_field(wp_unslash($_GET['message'])) : '';
        if ($message === 'deleted') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Abandoned form record deleted successfully.', 'sigmaforms-pro') . '</p></div>';
        }
        ?>

        <!-- <hr class="wp-header-end"> -->

        <!-- Filters -->
        <div class="tablenav top">
            <div class="alignleft actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="sigmaforms-abandoned">
                    <?php wp_nonce_field('abandoned_forms_filter'); ?>

                    <select name="form_id" id="filter-by-form">
                        <option value="0"><?php esc_html_e('All Forms', 'sigmaforms-pro'); ?></option>
                        <?php foreach ($forms as $form): ?>
                            <option value="<?php echo esc_attr($form['id']); ?>" <?php selected($current_form_id, $form['id']); ?>>
                                <?php
                                /* translators: 1: form title, 2: form ID */
                                echo esc_html(sprintf(__('%1$s (#%2$d)', 'sigmaforms-pro'), $form['title'], $form['id']));
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <select name="status" id="filter-by-status">
                        <option value="all" <?php selected($current_status, 'all'); ?>>
                            <?php esc_html_e('All Statuses', 'sigmaforms-pro'); ?>
                        </option>
                        <option value="abandoned" <?php selected($current_status, 'abandoned'); ?>>
                            <?php esc_html_e('Abandoned', 'sigmaforms-pro'); ?>
                        </option>
                        <option value="converted" <?php selected($current_status, 'converted'); ?>>
                            <?php esc_html_e('Converted', 'sigmaforms-pro'); ?>
                        </option>
                    </select>

                    <?php submit_button(__('Filter', 'sigmaforms-pro'), 'secondary', 'filter_action', false); ?>
                </form>
            </div>

            <div class="alignright actions">
                <span class="displaying-num">
                    <?php
                     printf(
                    /* translators: %s: Number of items. */
                    esc_html(_n('%s item', '%s items', $total_count, 'sigmaforms-pro')),
                    esc_html(number_format_i18n($total_count))
                );
                    ?>
                </span>
            </div>
        </div>

        <!-- Analytics Summary -->
        <?php if (!empty($analytics_data)): ?>
            <div class="sf-analytics-summary">
                <h3><?php esc_html_e('Quick Analytics', 'sigmaforms-pro'); ?></h3>
                <div class="sf-analytics-grid">
                    <?php
                    $total_abandoned = 0;
                    $total_converted = 0;
                    $total_submissions = 0;

                    foreach ($analytics_data as $analytics) {
                        $total_abandoned += $analytics['abandoned_count'];
                        $total_converted += $analytics['converted_count'];
                        $total_submissions += $analytics['total_submissions'];
                    }

                    $total_interactions = $total_abandoned + $total_converted + $total_submissions;
                    $overall_abandonment_rate = $total_interactions > 0 ? round(($total_abandoned / $total_interactions) * 100, 2) : 0;
                    $overall_conversion_rate = $total_interactions > 0 ? round(($total_submissions / $total_interactions) * 100, 2) : 0;
                    ?>

                    <div class="sf-analytics-item">
                        <span class="sf-analytics-icon abandoned"><?php echo PageHeader::icon('x-circle'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <div class="sf-analytics-item-content">
                            <div class="sf-analytics-value abandoned"><?php echo esc_html($total_abandoned); ?></div>
                            <div class="sf-analytics-label"><?php esc_html_e('Total Abandoned', 'sigmaforms-pro'); ?></div>
                        </div>
                    </div>

                    <div class="sf-analytics-item">
                        <span class="sf-analytics-icon converted"><?php echo PageHeader::icon('check-circle'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <div class="sf-analytics-item-content">
                            <div class="sf-analytics-value converted"><?php echo esc_html($total_converted); ?></div>
                            <div class="sf-analytics-label"><?php esc_html_e('Later Converted', 'sigmaforms-pro'); ?></div>
                        </div>
                    </div>

                    <div class="sf-analytics-item">
                        <span class="sf-analytics-icon submissions"><?php echo PageHeader::icon('inbox'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <div class="sf-analytics-item-content">
                            <div class="sf-analytics-value submissions"><?php echo esc_html($total_submissions); ?></div>
                            <div class="sf-analytics-label"><?php esc_html_e('Direct Submissions', 'sigmaforms-pro'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="sf-analytics-item">
                        <span class="sf-analytics-icon rate"><?php echo PageHeader::icon('trend'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <div class="sf-analytics-item-content">
                            <div class="sf-analytics-value rate"><?php echo esc_html($overall_abandonment_rate); ?>%
                            </div>
                            <div class="sf-analytics-label"><?php esc_html_e('Abandonment Rate', 'sigmaforms-pro'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Abandoned Forms Table -->
        <div class="sf-form-list">
            <?php if (!empty($abandoned_forms) && SigmaForms\Plugin::is_license_valid()): ?>
                <form method="post" id="abandoned-forms-form">
                    <!-- Top Bulk Actions -->
                    <div class="tablenav top">
                        <div class="alignleft actions bulkactions">
                            <label for="bulk-action-selector-top" class="screen-reader-text"><?php esc_html_e('Select bulk action', 'sigmaforms-pro'); ?></label>
                            <select name="action" id="bulk-action-selector-top">
                                <option value="-1"><?php esc_html_e('Bulk Actions', 'sigmaforms-pro'); ?></option>
                                <option value="delete"><?php esc_html_e('Delete', 'sigmaforms-pro'); ?></option>
                            </select>
                            <input type="submit" id="doaction" class="button action" value="<?php esc_attr_e('Apply', 'sigmaforms-pro'); ?>">
                        </div>
                    </div>
                    
                    <table class="wp-list-table widefat fixed striped sf-abandoned-table">
                        <thead>
                            <tr>
                                <td id="cb" class="manage-column column-cb check-column">
                                    <input id="cb-select-all-1" type="checkbox">
                                </td>
                                <th scope="col" class="manage-column column-form"><?php esc_html_e('Form', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-progress">
                                <?php esc_html_e('Progress', 'sigmaforms-pro'); ?>
                            </th>
                            <th scope="col" class="manage-column column-fields-filled"><?php esc_html_e('Fields Filled', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-time-spent">
                                <?php esc_html_e('Time Spent', 'sigmaforms-pro'); ?>
                            </th>
                            <th scope="col" class="manage-column column-last-activity"><?php esc_html_e('Last Activity', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-status"><?php esc_html_e('Status', 'sigmaforms-pro'); ?>
                            </th>
                            <th scope="col" class="manage-column column-actions">
                                <?php esc_html_e('Actions', 'sigmaforms-pro'); ?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($abandoned_forms as $abandoned_form): ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="abandoned_form[]" value="<?php echo esc_attr($abandoned_form->get_id()); ?>">
                                </th>
                                <td>
                                    <strong>
                                        <?php
                                        echo esc_html($abandoned_form->get_form_title());
                                        ?>
                                    </strong>
                                    <div class="row-actions">
                                        <span class="view">
                                            <a
                                                href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=sigmaforms-abandoned&abandoned_id=' . $abandoned_form->get_id()), 'view_abandoned_form_' . $abandoned_form->get_id())); ?>">
                                                <?php esc_html_e('View Details', 'sigmaforms-pro'); ?>
                                            </a>
                                            |
                                        </span>
                                        <span class="trash">
                                            <a href="#" class="submitdelete sf-delete-abandoned-form"
                                                data-id="<?php echo esc_attr($abandoned_form->get_id()); ?>">
                                                <?php esc_html_e('Delete', 'sigmaforms-pro'); ?>
                                            </a>
                                        </span>
                                    </div>
                                </td>
                                <td class="column-progress">
                                    <div class="sf-progress-bar">
                                        <div class="sf-progress-fill"
                                            style="width: <?php echo esc_attr($abandoned_form->get_completion_percentage()); ?>%;">
                                        </div>
                                        <span class="sf-progress-text">
                                            <?php echo esc_html($abandoned_form->get_completion_percentage()); ?>%
                                        </span>
                                    </div>
                                </td>
                                <td><?php echo esc_html($abandoned_form->get_filled_fields_count()); ?></td>
                                <td>
                                    <?php
                                    $time_spent = $abandoned_form->get_time_spent();
                                    if ($time_spent < 1) {
                                        echo esc_html__('< 1 min', 'sigmaforms-pro');
                                    } else {
                                        // translators: %s is the number of minutes spent.
                                        printf(esc_html__('%s min', 'sigmaforms-pro'), number_format($time_spent, 1));
                                    }
                                    ?>
                                </td>
                                <td class="column-last-activity">
                                    <?php echo esc_html($abandoned_form->get_formatted_last_activity()); ?>
                                    <br>
                                    <small class="sf-time-ago">
                                        <?php
                                        echo esc_html(sprintf(
                                            // translators: %s is the human-readable time difference (e.g., "5 minutes").
                                            __('%s ago', 'sigmaforms-pro'),
                                            human_time_diff(strtotime($abandoned_form->get_last_activity()))
                                        ));
                                        ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if ($abandoned_form->is_converted()): ?>
                                        <span class="sf-status-converted">
                                            <?php esc_html_e('Converted', 'sigmaforms-pro'); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="sf-status-abandoned">
                                            <?php esc_html_e('Abandoned', 'sigmaforms-pro'); ?>
                                        </span>
                                        <br>
                                        <small class="sf-status-subtext">
                                            <?php
                                            $abandonment_type = $abandoned_form->get_abandonment_type();
                                            switch ($abandonment_type) {
                                                case 'timeout':
                                                    esc_html_e('Timeout', 'sigmaforms-pro');
                                                    break;
                                                case 'page_hidden':
                                                    esc_html_e('Page Hidden', 'sigmaforms-pro');
                                                    break;
                                                case 'page_unload':
                                                    esc_html_e('Page Unload', 'sigmaforms-pro');
                                                    break;
                                                default:
                                                    echo esc_html(ucfirst(str_replace('_', ' ', $abandonment_type)));
                                            }
                                            ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=sigmaforms-abandoned&abandoned_id=' . $abandoned_form->get_id()), 'view_abandoned_form_' . $abandoned_form->get_id())); ?>"
                                        class="button button-small sf-action-btn">
                                        <span class="dashicons dashicons-visibility"></span>
                                        <?php esc_html_e('View', 'sigmaforms-pro'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="manage-column column-cb check-column">
                                <input id="cb-select-all-2" type="checkbox">
                            </td>
                            <th scope="col" class="manage-column column-form"><?php esc_html_e('Form', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-progress"><?php esc_html_e('Progress', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-fields-filled"><?php esc_html_e('Fields Filled', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-time-spent"><?php esc_html_e('Time Spent', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-last-activity"><?php esc_html_e('Last Activity', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-status"><?php esc_html_e('Status', 'sigmaforms-pro'); ?></th>
                            <th scope="col" class="manage-column column-actions"><?php esc_html_e('Actions', 'sigmaforms-pro'); ?></th>
                        </tr>
                    </tfoot>
                </table>
                
                <!-- Bottom Bulk Actions -->
                <div class="tablenav bottom">
                    <div class="alignleft actions bulkactions">
                        <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php esc_html_e('Select bulk action', 'sigmaforms-pro'); ?></label>
                        <select name="action2" id="bulk-action-selector-bottom">
                            <option value="-1"><?php esc_html_e('Bulk Actions', 'sigmaforms-pro'); ?></option>
                            <option value="delete"><?php esc_html_e('Delete', 'sigmaforms-pro'); ?></option>
                        </select>
                        <input type="submit" id="doaction2" class="button action" value="<?php esc_attr_e('Apply', 'sigmaforms-pro'); ?>">
                    </div>
                </div>
            </form>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="sf-pagination-wrapper">
                        <div class="sf-pagination-info">
                            <span class="displaying-num">
                                <?php
                                echo esc_html(
                                    sprintf(
                                        /* translators: %s: Number of items. */
                                        _n('%s item', '%s items', $total_count, 'sigmaforms-pro'),
                                        number_format_i18n($total_count)
                                    )
                                );
                                ?>
                            </span>
                        </div>
                        <div class="sf-pagination-links">
                            <?php
                            $pagination_args = [
                                'base' => add_query_arg(['paged' => '%#%', 'form_id' => $current_form_id, 'status' => $current_status, '_wpnonce' => wp_create_nonce('abandoned_forms_filter')]),
                                'format' => '',
                                'prev_text' => __('Previous', 'sigmaforms-pro'),
                                'next_text' => __('Next', 'sigmaforms-pro'),
                                'total' => $total_pages,
                                'current' => $current_page,
                                'mid_size' => 2,
                                'end_size' => 1,
                                'type' => 'list',
                                'before_page_number' => '',
                                'after_page_number' => '',
                            ];

                            echo wp_kses_post(paginate_links($pagination_args));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>

            <?php else: ?>
                <?php if (SigmaForms\Plugin::is_license_valid()): ?>
                    <div class="sf-no-data-message is-empty">
                        <span class="sf-no-data-icon"><?php echo PageHeader::icon('clock'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <p><?php esc_html_e('No abandoned forms found.', 'sigmaforms-pro'); ?></p>
                    </div>
                <?php else: ?>
                    <div class="sf-no-data-message">
                        <span class="sf-no-data-icon"><?php echo PageHeader::icon('info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                        <p><?php esc_html_e('Please activate your license to unlock this feature.', 'sigmaforms-pro'); ?></p>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms_license')); ?>"
                            class="button button-primary"><?php esc_html_e('Activate License', 'sigmaforms-pro'); ?></a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Export Options -->
        <?php if (!empty($abandoned_forms) && SigmaForms\Plugin::is_license_valid()): ?>
            <div class="sf-export-options">
                <h3><?php esc_html_e('Export Data', 'sigmaforms-pro'); ?></h3>
                <p><?php esc_html_e('Export abandoned forms data for further analysis.', 'sigmaforms-pro'); ?></p>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?action=export_abandoned_forms&form_id=' . $current_form_id . '&status=' . $current_status), 'export_abandoned_forms')); ?>"
                    class="button button-secondary sf-btn sf-btn-secondary">
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e('Export to CSV', 'sigmaforms-pro'); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Handle bulk actions form submission
    $('#doaction, #doaction2').on('click', function(e) {
        e.preventDefault();
        
        const isTopAction = $(this).attr('id') === 'doaction';
        const actionSelector = isTopAction ? '#bulk-action-selector-top' : '#bulk-action-selector-bottom';
        const action = $(actionSelector).val();
        const selectedForms = $('input[name="abandoned_form[]"]:checked').map(function() {
            return $(this).val();
        }).get();
        
        if (action === '-1') {
            window.SF.notify('<?php echo esc_js(__('Please select a bulk action.', 'sigmaforms-pro')); ?>');
            return;
        }
        
        if (selectedForms.length === 0) {
            window.SF.notify('<?php echo esc_js(__('Please select at least one abandoned form.', 'sigmaforms-pro')); ?>');
            return;
        }
        
        if (action === 'delete') {
            window.SF.confirm('<?php echo esc_js(__('Are you sure you want to delete the selected abandoned forms? This action cannot be undone.', 'sigmaforms-pro')); ?>', { danger: true }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                // Show loading state on both buttons
                $('#doaction, #doaction2').prop('disabled', true).val('<?php echo esc_js(__('Processing...', 'sigmaforms-pro')); ?>');
                
                $.ajax({
                    url: sfAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_bulk_delete_abandoned_forms',
                        nonce: sfAdmin.nonce,
                        abandoned_form_ids: selectedForms
                    },
                    success: function(response) {
                        if (response.success) {
                            window.SF.notify(response.data.message, 'success');
                            // Reload to reflect the changes once the message has been seen.
                            setTimeout(function () {
                                window.location.reload();
                            }, 1200);
                        } else {
                            window.SF.notify(response.data.message || '<?php echo esc_js(__('Error processing bulk action.', 'sigmaforms-pro')); ?>');
                        }
                    },
                    error: function(xhr, status, error) {
                        window.SF.notify('<?php echo esc_js(__('Error processing bulk action.', 'sigmaforms-pro')); ?>' + ' ' + error);
                    },
                    complete: function() {
                        $('#doaction, #doaction2').prop('disabled', false).val('<?php esc_attr_e('Apply', 'sigmaforms-pro'); ?>');
                    }
                });
            });
        }
    });
    
    // Handle select all checkbox (top)
    $('#cb-select-all-1').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('input[name="abandoned_form[]"]').prop('checked', isChecked);
        updateSelectAllCheckboxState();
    });
    
    // Handle select all checkbox (bottom)
    $('#cb-select-all-2').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('input[name="abandoned_form[]"]').prop('checked', isChecked);
        updateSelectAllCheckboxState();
    });
    
    // Update select all checkbox state when individual checkboxes change
    $('input[name="abandoned_form[]"]').on('change', function() {
        updateSelectAllCheckboxState();
    });
    
    // Function to update select all checkbox state
    function updateSelectAllCheckboxState() {
        const totalCheckboxes = $('input[name="abandoned_form[]"]').length;
        const checkedCheckboxes = $('input[name="abandoned_form[]"]:checked').length;
        
        if (checkedCheckboxes === 0) {
            $('#cb-select-all-1, #cb-select-all-2').prop('indeterminate', false).prop('checked', false);
        } else if (checkedCheckboxes === totalCheckboxes) {
            $('#cb-select-all-1, #cb-select-all-2').prop('indeterminate', false).prop('checked', true);
        } else {
            $('#cb-select-all-1, #cb-select-all-2').prop('indeterminate', true);
        }
    }
    
    // Synchronize bulk action selectors
    $('#bulk-action-selector-top, #bulk-action-selector-bottom').on('change', function() {
        const value = $(this).val();
        $('#bulk-action-selector-top, #bulk-action-selector-bottom').val(value);
    });
    
    // Delete individual abandoned form
    $('.sf-delete-abandoned-form').on('click', function(e) {
        e.preventDefault();
        
        const $sfTrigger = $(this);
        window.SF.confirm('<?php echo esc_js(__('Are you sure you want to delete this abandoned form record? This action cannot be undone.', 'sigmaforms-pro')); ?>', { danger: true }).then(function (sfConfirmed) {
            if (!sfConfirmed) {
                return;
            }
            const abandonedId = $sfTrigger.data('id');
            
            $.ajax({
                url: sfAdmin.ajaxurl,
                type: 'POST',
                data: {
                    action: 'sf_delete_abandoned_form',
                    nonce: sfAdmin.nonce,
                    abandoned_id: abandonedId
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        window.SF.notify(response.data.message || '<?php echo esc_js(__('Error deleting abandoned form.', 'sigmaforms-pro')); ?>');
                    }
                },
                error: function(xhr, status, error) {
                    window.SF.notify('<?php echo esc_js(__('Error deleting abandoned form.', 'sigmaforms-pro')); ?>' + ' ' + error);
                }
            });
        });
    });
});
</script>