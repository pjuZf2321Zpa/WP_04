<?php
/**
 * Shared admin masthead — identical on every SigmaForms screen.
 *
 * Page specific titles, descriptions and buttons belong in the page intro
 * (admin-page-intro.php), not here.
 *
 * @package SigmaForms
 *
 * @var bool   $license_active
 * @var string $docs_url
 * @var array  $nav_items
 */

if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\Admin\PageHeader;

?>
<div class="sf-masthead">
    <div class="sf-masthead__bar">
        <div class="sf-masthead__brand">
            <?php
            WhiteLabel::render_admin_brand(
                array(
                    'title'          => WhiteLabel::get_display_name(),
                    'title_template' => '%s',
                    'heading_tag'    => 'h2',
                    'heading_class'  => 'sf-masthead__title',
                )
            );
            ?>
            <span class="sf-masthead__version"><?php echo esc_html('v' . SF_VERSION); ?></span>
        </div>

        <div class="sf-masthead__meta">
            <span class="sf-masthead__status<?php echo $license_active ? ' is-active' : ''; ?>">
                <?php
                echo $license_active
                    ? esc_html__('License active', 'sigmaforms-pro')
                    : esc_html__('License inactive', 'sigmaforms-pro');
                ?>
            </span>
            <a class="sf-masthead__action" href="<?php echo esc_url($docs_url); ?>" target="_blank" rel="noopener noreferrer">
                <?php echo PageHeader::icon('book'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                <span><?php esc_html_e('Documentation', 'sigmaforms-pro'); ?></span>
            </a>
        </div>
    </div>

    <?php if (!empty($nav_items)) : ?>
        <nav class="sf-masthead-nav" data-sf-nav>
            <?php foreach ($nav_items as $nav_item) : // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template variable scoped to PageHeader::render(). ?>
                <a class="sf-masthead-nav__item<?php echo $nav_item['current'] ? ' is-current' : ''; ?>"
                    data-sf-nav-item
                    href="<?php echo esc_url($nav_item['url']); ?>"
                    <?php echo $nav_item['current'] ? ' aria-current="page"' : ''; ?>>
                    <?php echo PageHeader::icon($nav_item['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <span class="sf-masthead-nav__label"><?php echo esc_html($nav_item['label']); ?></span>
                </a>
            <?php endforeach; ?>

            <div class="sf-masthead-nav__more" data-sf-nav-more hidden>
                <button type="button" class="sf-masthead-nav__item sf-masthead-nav__toggle" data-sf-nav-toggle aria-expanded="false">
                    <?php echo PageHeader::icon('more'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <span class="sf-masthead-nav__label"><?php esc_html_e('More', 'sigmaforms-pro'); ?></span>
                    <?php echo PageHeader::icon('chevron'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                </button>
                <div class="sf-masthead-nav__dropdown" data-sf-nav-panel hidden></div>
            </div>
        </nav>
    <?php endif; ?>
</div>
