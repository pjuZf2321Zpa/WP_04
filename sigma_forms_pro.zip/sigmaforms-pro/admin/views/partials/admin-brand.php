<?php
/**
 * Admin header brand block (logo + title).
 *
 * @package SigmaForms
 *
 * @var string $title
 * @var string $title_template
 * @var string $heading_tag
 * @var string $heading_class
 * @var bool   $show_logo
 * @var string $logo_url
 * @var string $after_title
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Partial template variables are local, not global
$allowed_tags = array('h1', 'h2', 'h3');
$tag          = in_array($heading_tag, $allowed_tags, true) ? $heading_tag : 'h1';

$class_attr    = $heading_class !== '' ? ' class="' . esc_attr($heading_class) . '"' : '';
$template_attr = $title_template !== '' ? ' data-sf-brand-title="' . esc_attr($title_template) . '"' : '';

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Tag name is whitelisted above.
echo '<' . $tag . $class_attr . $template_attr . '>';
echo '<span class="sf-admin-brand">';
if ($show_logo && $logo_url !== '') {
    printf(
        '<img src="%1$s" alt="" class="sf-admin-brand__logo" data-sf-brand-logo width="32" height="32" />',
        esc_url($logo_url)
    );
}
printf('<span class="sf-admin-brand__title">%s</span>', esc_html($title));
if ($after_title !== '') {
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Caller supplies escaped HTML.
    echo $after_title;
}
echo '</span>';
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Tag name is whitelisted above.
echo '</' . $tag . '>';
