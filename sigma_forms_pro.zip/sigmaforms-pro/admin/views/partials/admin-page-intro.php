<?php
/**
 * Page intro: the screen's own title, description and buttons.
 *
 * Sits in the content area, below the shared masthead.
 *
 * @package SigmaForms
 *
 * @var string $title
 * @var string $title_template
 * @var string $description
 * @var string $after_title
 * @var array  $actions
 */

if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\WhiteLabel\WhiteLabel;
use SigmaForms\Admin\PageHeader;

?>
<div class="sf-page-intro">
    <div class="sf-page-intro__text">
        <?php
        WhiteLabel::render_admin_brand(
            array(
                'title'          => $title,
                'title_template' => $title_template,
                'after_title'    => $after_title,
                'heading_class'  => 'sf-page-intro__title',
                'show_logo'      => false,
            )
        );
        ?>
        <?php if ($description !== '') : ?>
            <p class="sf-page-intro__desc"><?php echo wp_kses_post($description); ?></p>
        <?php endif; ?>
    </div>

    <?php if (!empty($actions)) : ?>
        <div class="sf-page-intro__actions">
            <?php foreach ($actions as $action) : ?>
                <?php if (empty($action['url']) || empty($action['label'])) { continue; } ?>
                <a class="sf-page-intro__action<?php echo !empty($action['primary']) ? ' sf-page-intro__action--primary' : ''; ?>"
                    href="<?php echo esc_url($action['url']); ?>"
                    <?php if (!empty($action['target'])) : ?>target="<?php echo esc_attr($action['target']); ?>" rel="noopener noreferrer"<?php endif; ?>>
                    <?php if (!empty($action['icon'])) : ?>
                        <?php echo PageHeader::icon($action['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                    <?php endif; ?>
                    <span><?php echo esc_html($action['label']); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
