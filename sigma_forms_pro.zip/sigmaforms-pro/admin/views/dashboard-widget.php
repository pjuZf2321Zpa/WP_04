<?php
/**
 * Admin view for dashboard widget
 *
 * Styles live in assets/css/dashboard-widget.css, which is enqueued on the
 * Dashboard only.
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

$stats = array(
    array(
        'class' => 'is-submissions',
        'icon'  => 'inbox',
        'value' => (int) $total_submissions,
        'label' => __('Submissions', 'sigmaforms-pro'),
    ),
    array(
        'class' => 'is-forms',
        'icon'  => 'forms',
        'value' => (int) $total_forms,
        'label' => __('Forms', 'sigmaforms-pro'),
    ),
    array(
        'class' => 'is-unread',
        'icon'  => 'eye',
        'value' => (int) $unread_count,
        'label' => __('Unread', 'sigmaforms-pro'),
    ),
);
?>

<div class="sf-dw">
    <div class="sf-dw-stats">
        <?php foreach ($stats as $stat) : ?>
            <div class="sf-dw-stat <?php echo esc_attr($stat['class']); ?>">
                <span class="sf-dw-stat__icon"><?php echo PageHeader::icon($stat['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
                <span class="sf-dw-stat__value"><?php echo esc_html(number_format_i18n($stat['value'])); ?></span>
                <span class="sf-dw-stat__label"><?php echo esc_html($stat['label']); ?></span>
            </div>
        <?php endforeach; ?>
    </div>

    <h3 class="sf-dw-heading"><?php esc_html_e('Recent Submissions', 'sigmaforms-pro'); ?></h3>

    <?php if (empty($submissions)) : ?>
        <div class="sf-dw-empty">
            <span class="sf-dw-empty__icon"><?php echo PageHeader::icon((int) $total_forms > 0 ? 'inbox' : 'forms'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?></span>
            <?php if ((int) $total_forms > 0) : ?>
                <p class="sf-dw-empty__title"><?php esc_html_e('No submissions yet', 'sigmaforms-pro'); ?></p>
                <p class="sf-dw-empty__text"><?php esc_html_e('Entries are saved here when "Store Submissions in Database" is turned on in a form\'s settings.', 'sigmaforms-pro'); ?></p>
            <?php else : ?>
                <p class="sf-dw-empty__title"><?php esc_html_e('No forms yet', 'sigmaforms-pro'); ?></p>
                <p class="sf-dw-empty__text"><?php esc_html_e('Create your first form to start collecting submissions.', 'sigmaforms-pro'); ?></p>
            <?php endif; ?>
        </div>
    <?php else : ?>
        <ul class="sf-dw-list">
            <?php
            foreach ($submissions as $submission) :
                // The single submission screen requires this nonce.
                $submission_url = add_query_arg(
                    array(
                        'page'          => 'sigmaforms-submissions',
                        'submission_id' => $submission['id'],
                        '_wpnonce'      => wp_create_nonce('view_submission_' . $submission['id']),
                    ),
                    admin_url('admin.php')
                );

                // Submissions are stored in site time; show recent ones as "3 hours ago".
                $created    = date_create($submission['date_created'], wp_timezone());
                $created_ts = $created ? $created->getTimestamp() : 0;
                $age        = time() - $created_ts;

                if (!$created_ts) {
                    $time_label = $submission['date_created'];
                } elseif ($age >= 0 && $age < WEEK_IN_SECONDS) {
                    /* translators: %s: human readable time difference, e.g. "3 hours" */
                    $time_label = sprintf(__('%s ago', 'sigmaforms-pro'), human_time_diff($created_ts, time()));
                } else {
                    $time_label = wp_date(get_option('date_format'), $created_ts);
                }

                $has_title = $submission['form_title'] !== null && $submission['form_title'] !== '';
                ?>
                <li class="sf-dw-item">
                    <a class="sf-dw-item__link" href="<?php echo esc_url($submission_url); ?>">
                        <span class="sf-dw-item__title<?php echo $has_title ? '' : ' is-deleted'; ?>">
                            <?php
                            if ($has_title) {
                                echo esc_html($submission['form_title']);
                            } else {
                                printf(
                                    /* translators: %d is the form ID */
                                    esc_html__('Deleted Form - #%d', 'sigmaforms-pro'),
                                    (int) $submission['form_id']
                                );
                            }
                            ?>
                        </span>
                        <?php if ($submission['status'] === 'unread') : ?>
                            <span class="sf-dw-badge"><?php esc_html_e('Unread', 'sigmaforms-pro'); ?></span>
                        <?php endif; ?>
                    </a>
                    <?php if ($created_ts) : ?>
                        <time class="sf-dw-item__time" datetime="<?php echo esc_attr($created->format(DATE_W3C)); ?>" title="<?php echo esc_attr(wp_date(get_option('date_format') . ' ' . get_option('time_format'), $created_ts)); ?>"><?php echo esc_html($time_label); ?></time>
                    <?php else : ?>
                        <span class="sf-dw-item__time"><?php echo esc_html($time_label); ?></span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <div class="sf-dw-footer">
        <a class="sf-dw-footer__link" href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-new')); ?>">
            <?php echo PageHeader::icon('plus'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            <?php esc_html_e('Create form', 'sigmaforms-pro'); ?>
        </a>
        <a class="sf-dw-footer__link" href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-submissions')); ?>">
            <?php echo PageHeader::icon('inbox'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            <?php esc_html_e('Submissions', 'sigmaforms-pro'); ?>
        </a>
        <a class="sf-dw-footer__link" href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-analytics')); ?>">
            <?php echo PageHeader::icon('chart'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
            <?php esc_html_e('Analytics', 'sigmaforms-pro'); ?>
        </a>
    </div>
</div>
<?php
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
