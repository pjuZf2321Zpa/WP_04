<?php
/**
 * Admin view for form editor
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Initialize form variables
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/init.php';

// Default settings if new form
if (!$is_edit) {
    $form_settings = [
        'submit_button_text' => __('Submit', 'sigmaforms-pro'),
        'success_message' => __('Thank you for your submission!', 'sigmaforms-pro'),
        'store_submissions' => true,
        'override_email_settings' => false,
        'send_email' => true,
        'to_email' => get_option('sf_admin_email', get_option('admin_email')),
        'cc_email' => get_option('sf_admin_email_cc', ''),
        'bcc_email' => get_option('sf_admin_email_bcc', ''),
        // translators: %s is the blog name.
        'email_subject' => get_option('sf_default_email_subject', sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name'))),
        'email_message' => get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro')),
        'send_confirmation_email' => false,
        'confirmation_subject' => get_option('sf_default_confirmation_subject', __('Thank You for Your Submission', 'sigmaforms-pro')),
        'confirmation_message' => get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro')),
        'captcha_type' => '',
        'submit_button_width' => 'auto',
        // Form style - empty follows the global theme setting
        'form_theme' => '',
        // Webhook settings - default to global settings
        'webhook_google_sheets_use' => false,

        'webhook_slack_use' => false,
        'webhook_discord_use' => false,
        'webhook_telegram_use' => false,
        'webhook_custom_use' => false,
    ];
    
    // Get global webhook settings and merge them
    $global_webhook_settings = get_option('sigmaforms_settings', []);
    $form_settings = array_merge($form_settings, $global_webhook_settings);
} else {
    // Ensure email settings are set for existing forms
    if (!isset($form_settings['override_email_settings'])) {
        $form_settings['override_email_settings'] = false;
    }
    if (!isset($form_settings['to_email']) || empty($form_settings['to_email'])) {
        $form_settings['to_email'] = get_option('sf_admin_email', get_option('admin_email'));
    }
    if (!isset($form_settings['email_subject']) || empty($form_settings['email_subject'])) {
        // translators: %s is the blog name.
        $form_settings['email_subject'] = get_option('sf_default_email_subject', sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name')));
    }
    if (!isset($form_settings['email_message']) || empty($form_settings['email_message'])) {
        $form_settings['email_message'] = get_option('sf_default_email_message', __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro'));
    }
    if (!isset($form_settings['send_confirmation_email'])) {
        $form_settings['send_confirmation_email'] = false;
    }
    if (!isset($form_settings['confirmation_subject']) || empty($form_settings['confirmation_subject'])) {
        $form_settings['confirmation_subject'] = get_option('sf_default_confirmation_subject', __('Thank You for Your Submission', 'sigmaforms-pro'));
    }
    if (!isset($form_settings['confirmation_message']) || empty($form_settings['confirmation_message'])) {
        $form_settings['confirmation_message'] = get_option('sf_default_confirmation_message', __('We have received your submission and will get back to you soon.', 'sigmaforms-pro'));
    }
    
    // An empty theme means "use the global theme" (the front end falls back to
    // it), so it is kept empty rather than copied from the global setting.
    if (!isset($form_settings['form_theme'])) {
        $form_settings['form_theme'] = '';
    }
    
    // Ensure webhook settings are set for existing forms
    $webhook_types = ['google_sheets', 'slack', 'discord', 'telegram', 'custom'];
    foreach ($webhook_types as $webhook_type) {
        $use_key = "webhook_{$webhook_type}_use";
        if (!isset($form_settings[$use_key])) {
            $form_settings[$use_key] = false;
        }
    }
    
    // Get global webhook settings and merge them if not already set
    $global_webhook_settings = get_option('sigmaforms_settings', []);
    foreach ($global_webhook_settings as $key => $value) {
        if (!isset($form_settings[$key])) {
            $form_settings[$key] = $value;
        }
    }
}

// Include the header template
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/header.php';

// Include the wizard steps
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/wizard-steps.php';

// Include the form wrapper (which includes all step templates)
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/form-wrapper.php';

// Include JavaScript initialization for form data
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/form-data-init.php';

// Include step 3 - configure form settings
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/step-configure.php';

// Include step 4 - publish form
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/step-publish.php';

// Include the field settings popup
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/field-settings-popup.php';

// Include the field type modal
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/field-type-modal.php';

// Include the footer template
require_once SF_PLUGIN_DIR . 'admin/views/form-editor/footer.php';
