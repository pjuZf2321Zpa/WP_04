<?php
/**
 * Abandoned Form Detail View
 *
 * @package SigmaForms
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Get abandoned form ID
$abandoned_id = isset($_GET['abandoned_id']) ? (int) $_GET['abandoned_id'] : 0;
$nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
if (!wp_verify_nonce(wp_unslash($nonce), 'view_abandoned_form_' . $abandoned_id)) {
    wp_die(
                    esc_html__('Invalid or missing nonce for abandoned form view.', 'sigmaforms-pro'),
                    esc_html__('Link expired', 'sigmaforms-pro'),
                    array('back_link' => true, 'response' => 403)
                );
}

if ($abandoned_id <= 0) {
    wp_die(esc_html__('Invalid abandoned form ID.', 'sigmaforms-pro'), '', array('back_link' => true));
}

// Get abandoned forms manager
$abandoned_forms_manager = $this->plugin->abandoned_forms;

// Get the specific abandoned form
$abandoned_form = $abandoned_forms_manager->get_abandoned_form($abandoned_id);

if (!$abandoned_form) {
    wp_die(esc_html__('Abandoned form not found.', 'sigmaforms-pro'), '', array('back_link' => true));
}

// Get the original form
$forms_manager = $this->plugin->forms;
$form = $forms_manager->get_form($abandoned_form->get_form_id());

// Form might be deleted, so we'll use the form_title from abandoned_form if available
$form_title = $abandoned_form->get_form_title();
$form_exists = ($form !== false && $form !== null);
?>

<div>
    <div class="sf-admin-wrap">
        <?php
        PageHeader::render();
        PageHeader::intro(
            array(
                'title'   => __('Abandoned Form Details', 'sigmaforms-pro'),
                'actions' => array(
                    array(
                        'url'   => admin_url('admin.php?page=sigmaforms-abandoned'),
                        'label' => __('Back to List', 'sigmaforms-pro'),
                        'icon'  => 'arrow-left',
                    ),
                ),
            )
        );
        ?>
        
        <!-- <hr class="wp-header-end"> -->
        
        <!-- Form Information -->
        <div class="postbox sf-form-detail-postbox">
            <div class="postbox-header sf-postbox-header">
                <h2 class="hndle"><?php esc_html_e('Form Information', 'sigmaforms-pro'); ?></h2>
            </div>
            <div class="inside">
                <table class="form-table sf-form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Abandoned Form ID', 'sigmaforms-pro'); ?></th>
                        <td><?php echo esc_html($abandoned_form->get_id()); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Form Name', 'sigmaforms-pro'); ?></th>
                        <td>
                            <strong><?php echo esc_html($form_title); ?></strong>
                            <?php if (!$form_exists): ?>
                                <span class="description" style="color: #d63638;">
                                    <?php esc_html_e('(This form has been deleted)', 'sigmaforms-pro'); ?>
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Form ID', 'sigmaforms-pro'); ?></th>
                        <td><?php echo esc_html($abandoned_form->get_form_id()); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Session ID', 'sigmaforms-pro'); ?></th>
                        <td><code><?php echo esc_html($abandoned_form->get_session_id()); ?></code></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('User ID', 'sigmaforms-pro'); ?></th>
                        <td><?php echo esc_html($abandoned_form->get_user_id() ?: __('Guest', 'sigmaforms-pro')); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- Abandonment Details -->
        <div class="postbox sf-postbox">
            <div class="postbox-header sf-postbox-header">
                <h2 class="hndle"><?php esc_html_e('Abandonment Details', 'sigmaforms-pro'); ?></h2>
            </div>
            <div class="inside">
                <table class="form-table sf-form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Status', 'sigmaforms-pro'); ?></th>
                        <td>
                            <?php if ($abandoned_form->is_converted()): ?>
                                <span class="sf-status-badge converted">
                                    ✓ <?php esc_html_e('Converted', 'sigmaforms-pro'); ?>
                                </span>
                                <p class="description"><?php esc_html_e('This user eventually completed and submitted the form.', 'sigmaforms-pro'); ?></p>
                            <?php else: ?>
                                <span class="sf-status-badge abandoned">
                                    ✗ <?php esc_html_e('Abandoned', 'sigmaforms-pro'); ?>
                                </span>
                                <p class="description"><?php esc_html_e('This user started filling the form but did not complete it.', 'sigmaforms-pro'); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Completion Progress', 'sigmaforms-pro'); ?></th>
                        <td>
                            <div class="sf-progress-bar-large">
                                <div class="sf-progress-fill-large" style="width: <?php echo esc_attr($abandoned_form->get_completion_percentage()); ?>%;"></div>
                                <span class="sf-progress-text-large">
                                    <?php echo esc_html($abandoned_form->get_completion_percentage()); ?>%
                                </span>
                            </div>
                            <p class="description">
                            <?php
                                $total_form_fields = $form_exists ? count($form['form_fields']) : 0;
                                if ($total_form_fields > 0) {
                                    // translators: 1: Number of filled fields, 2: Total number of fields.
                                    echo esc_html(sprintf(__('%1$d out of %2$d fields were filled.', 'sigmaforms-pro'),
                                        $abandoned_form->get_filled_fields_count(),
                                        $total_form_fields
                                    ));
                                } else {
                                    // translators: %d is the number of filled fields.
                                    echo esc_html(sprintf(__('%d fields were filled.', 'sigmaforms-pro'),
                                        $abandoned_form->get_filled_fields_count()
                                    ));
                                }
                            ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Time Spent', 'sigmaforms-pro'); ?></th>
                        <td>
                            <strong>
                                <?php
                                $time_spent = $abandoned_form->get_time_spent();
                                if ($time_spent < 1) {
                                    echo esc_html__('Less than 1 minute', 'sigmaforms-pro');
                                } else {
                                    // translators: %s is the number of minutes spent.
                                    printf(esc_html__('%s minutes', 'sigmaforms-pro'), number_format($time_spent, 1));
                                }
                                ?>
                            </strong>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Start Time', 'sigmaforms-pro'); ?></th>
                        <td><?php echo esc_html($abandoned_form->get_formatted_start_time()); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Last Activity', 'sigmaforms-pro'); ?></th>
                        <td>
                            <?php echo esc_html($abandoned_form->get_formatted_last_activity()); ?>
                            <span class="sf-time-ago-inline">
                            (<?php 
                                echo esc_html(sprintf(
                                    // translators: %s is the human-readable time difference (e.g., "5 minutes").
                                    __('%s ago', 'sigmaforms-pro'),
                                    human_time_diff(strtotime($abandoned_form->get_last_activity()))
                                ));
                            ?>)
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Abandonment Type', 'sigmaforms-pro'); ?></th>
                        <td>
                            <code>
                                <?php
                                    $abandonment_type = $abandoned_form->get_abandonment_type();
                                    switch ($abandonment_type) {
                                        case 'timeout':
                                            esc_html_e('Timeout', 'sigmaforms-pro');
                                            break;
                                        case 'page_hidden':
                                            esc_html_e('Page Hidden', 'sigmaforms-pro');
                                            break;
                                        case 'page_unload':
                                            esc_html_e('Page Unload', 'sigmaforms-pro');
                                            break;
                                        default:
                                            echo esc_html(ucfirst(str_replace('_', ' ', $abandonment_type)));
                                    }
                                ?>
                            </code>
                            <p class="description">
                                <?php
                                switch ($abandoned_form->get_abandonment_type()) {
                                    case 'timeout':
                                        esc_html_e('User became inactive for an extended period.', 'sigmaforms-pro');
                                        break;
                                    case 'page_hidden':
                                        esc_html_e('User switched to another tab or minimized the browser.', 'sigmaforms-pro');
                                        break;
                                    case 'page_unload':
                                        esc_html_e('User navigated away from the page or closed the browser.', 'sigmaforms-pro');
                                        break;
                                    default:
                                        esc_html_e('Form was automatically saved during user interaction.', 'sigmaforms-pro');
                                }
                                ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- Field Values -->
        <div class="postbox sf-postbox">
            <div class="postbox-header sf-postbox-header">
                <h2 class="hndle"><?php esc_html_e('Partial Field Values', 'sigmaforms-pro'); ?></h2>
            </div>
            <div class="inside">
                <?php 
                $field_values = $abandoned_form->get_field_values();
                $form_fields = $form_exists ? ($form['form_fields'] ?: []) : [];
                
                // Build field labels and types map
                $field_labels = [];
                $field_types = [];
                foreach ($form_fields as $field) {
                    if (isset($field['id'])) {
                        $field_labels[$field['id']] = isset($field['label']) ? $field['label'] : $field['id'];
                        $field_types[$field['id']] = isset($field['type']) ? $field['type'] : '';
                    }
                }
                ?>
                
                <?php if (!empty($field_values)): ?>
                    <table class="wp-list-table widefat fixed striped sf-field-table">
                        <thead>
                            <tr>
                                <th scope="col" class="sf-field-table"><?php esc_html_e('Field', 'sigmaforms-pro'); ?></th>
                                <th scope="col"><?php esc_html_e('Value', 'sigmaforms-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($field_values as $field_name => $field_value): 
                                // Skip internal fields
                                if (substr($field_name, 0, 1) === '_') {
                                    continue;
                                }
                                
                                $label = isset($field_labels[$field_name]) ? $field_labels[$field_name] : $field_name;
                                $field_type = isset($field_types[$field_name]) ? $field_types[$field_name] : '';
                                
                                // Format value for display based on field type
                                if (is_array($field_value)) {
                                    $display_value = '<ul>';
                                    foreach ($field_value as $value) {
                                        if (!empty($value) && filter_var($value, FILTER_VALIDATE_URL)) {
                                            $display_value .= '<li><a href="' . esc_url($value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($value) . '</a></li>';
                                        } else {
                                            $display_value .= '<li>' . esc_html($value) . '</li>';
                                        }
                                    }
                                    $display_value .= '</ul>';
                                } elseif ($field_type === 'url' && !empty($field_value) && filter_var($field_value, FILTER_VALIDATE_URL)) {
                                    // Make URLs clickable
                                    $display_value = '<a href="' . esc_url($field_value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($field_value) . '</a>';
                                } elseif ($field_type === 'file' && !empty($field_value)) {
                                    // Handle multiple files (comma-separated URLs) or single file
                                    if (strpos($field_value, ', ') !== false) {
                                        // Multiple files - split and display each on a separate line
                                        $file_urls = explode(', ', $field_value);
                                        $file_links = [];
                                        foreach ($file_urls as $file_url) {
                                            $file_url = trim($file_url);
                                            if (filter_var($file_url, FILTER_VALIDATE_URL)) {
                                                // Extract filename from URL for display
                                                $filename = basename(wp_parse_url($file_url, PHP_URL_PATH));
                                                $file_links[] = '<a href="' . esc_url($file_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($filename) . '</a>';
                                            } elseif (strpos($file_url, '(Email Attachment)') !== false) {
                                                // Email attachment format
                                                $file_links[] = esc_html($file_url);
                                            } else {
                                                $file_links[] = esc_html($file_url);
                                            }
                                        }
                                        $display_value = implode('<br>', $file_links);
                                    } elseif (filter_var($field_value, FILTER_VALIDATE_URL)) {
                                        // Single file URL - make it clickable with filename as text
                                        $filename = basename(wp_parse_url($field_value, PHP_URL_PATH));
                                        $display_value = '<a href="' . esc_url($field_value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($filename) . '</a>';
                                    } else {
                                        // Not a URL (e.g., email attachment format)
                                        $display_value = esc_html($field_value);
                                    }
                                } elseif ($field_type === 'signature' && \SigmaForms\Utils\Helper::is_safe_image_data_uri($field_value)) {
                                    // Display signature as image. The value is validated as a strict base64
                                    // image data URI above and escaped here, so it cannot break out of the attribute.
                                    $display_value = '<img src="' . esc_attr($field_value) . '" alt="Signature" style="max-width: 300px; max-height: 200px; border: 1px solid #ddd; padding: 5px; background: #fff; display: block;">';
                                } else {
                                    // Check if value looks like a URL (even if field type is not URL)
                                    if (!empty($field_value) && filter_var($field_value, FILTER_VALIDATE_URL)) {
                                        $display_value = '<a href="' . esc_url($field_value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($field_value) . '</a>';
                                    } else {
                                        $display_value = esc_html($field_value);
                                    }
                                }
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($label); ?></strong></td>
                                <td>
                                    <?php
                                    // For signature fields the markup is built from a validated data URI
                                    // escaped with esc_attr(), which wp_kses_post() would strip.
                                    if ($field_type === 'signature' && \SigmaForms\Utils\Helper::is_safe_image_data_uri($field_value)) {
                                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Value validated and escaped above.
                                        echo $display_value;
                                    } else {
                                        echo wp_kses_post($display_value);
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p><?php esc_html_e('No field values were captured.', 'sigmaforms-pro'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Actions -->
        <div class="postbox sf-postbox sf-actions-postbox">
            <div class="postbox-header sf-postbox-header">
                <h2 class="hndle"><?php esc_html_e('Actions', 'sigmaforms-pro'); ?></h2>
            </div>
            <div class="inside">
                <p><?php esc_html_e('What would you like to do with this abandoned form data?', 'sigmaforms-pro'); ?></p>

                <p class="sf-actions-row">
                    <a href="<?php echo esc_url(add_query_arg(['_wpnonce' => wp_create_nonce('edit_form_' . $abandoned_form->get_form_id())], admin_url('admin.php?page=sigmaforms-new&form_id=' . $abandoned_form->get_form_id()))); ?>" class="button sf-btn sf-btn-primary">
                        <?php esc_html_e('Edit Original Form', 'sigmaforms-pro'); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-submissions&form_id=' . $abandoned_form->get_form_id())); ?>" class="button sf-btn sf-btn-secondary">
                        <?php esc_html_e('View Form Submissions', 'sigmaforms-pro'); ?>
                    </a>

                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=sigmaforms-abandoned&action=delete&id=' . $abandoned_form->get_id()), 'delete_abandoned_form')); ?>" class="button button-link-delete sf-btn sf-btn-danger" data-sf-confirm="<?php esc_attr_e('Are you sure you want to delete this abandoned form record?', 'sigmaforms-pro'); ?>">
                        <?php esc_html_e('Delete Record', 'sigmaforms-pro'); ?>
                    </a>
                </p>
            </div>
        </div>
    </div>
</div> 