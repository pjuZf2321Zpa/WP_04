<?php
/**
 * Mobile Signature Capture Page
 * 
 * This page is displayed when user scans the QR code with their mobile device
 *
 * @package SigmaForms
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public page, session-based security
$session_id = isset($_GET['session_id']) ? sanitize_text_field(wp_unslash($_GET['session_id'])) : '';
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="robots" content="noindex, nofollow">
    <title><?php esc_html_e('Sign on Mobile', 'sigmaforms-pro'); ?> - <?php bloginfo('name'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .mobile-signature-container {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 100%;
            width: 100%;
            max-width: 600px;
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 24px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .header p {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .content {
            padding: 24px;
        }
        
        .signature-wrapper {
            margin-bottom: 20px;
        }
        
        .signature-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #333;
            margin-bottom: 12px;
        }
        
        .signature-canvas {
            border: 3px solid #e5e7eb;
            border-radius: 12px;
            cursor: crosshair;
            display: block;
            width: 100%;
            height: 300px;
            background: #fafafa;
            touch-action: none;
            transition: border-color 0.3s;
        }
        
        .signature-canvas:active,
        .signature-canvas:focus {
            border-color: #667eea;
            outline: none;
        }
        
        .signature-actions {
            display: flex;
            gap: 12px;
            margin-top: 16px;
        }
        
        .btn {
            flex: 1;
            padding: 14px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-clear {
            background: #f3f4f6;
            color: #374151;
        }
        
        .btn-clear:hover {
            background: #e5e7eb;
        }
        
        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .btn-submit:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .status-message {
            padding: 16px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 16px;
            display: none;
        }
        
        .status-message.success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #6ee7b7;
            display: block;
        }
        
        .status-message.error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
            display: block;
        }
        
        .icon {
            width: 20px;
            height: 20px;
        }
        
        .loading {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #fff;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .instruction {
            background: #f0f9ff;
            border-left: 4px solid #0284c7;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #0c4a6e;
        }
        
        .footer {
            background: #f9fafb;
            padding: 16px 24px;
            text-align: center;
            font-size: 12px;
            color: #6b7280;
        }
        
        @media (max-width: 480px) {
            body {
                padding: 0;
            }
            
            .mobile-signature-container {
                border-radius: 0;
                min-height: 100vh;
            }
            
            .signature-canvas {
                height: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="mobile-signature-container">
        <div class="header">
            <h1><?php esc_html_e('Digital Signature', 'sigmaforms-pro'); ?></h1>
            <p><?php esc_html_e('Sign using your finger or stylus', 'sigmaforms-pro'); ?></p>
        </div>
        
        <div class="content">
            <div class="instruction">
                <?php esc_html_e('Draw your signature in the box below. Once you submit, it will automatically appear in the form on your computer.', 'sigmaforms-pro'); ?>
            </div>
            
            <div id="statusMessage" class="status-message"></div>
            
            <div class="signature-wrapper">
                <label class="signature-label">
                    <?php esc_html_e('Your Signature', 'sigmaforms-pro'); ?>
                </label>
                <canvas id="signatureCanvas" class="signature-canvas"></canvas>
            </div>
            
            <div class="signature-actions">
                <button type="button" id="clearBtn" class="btn btn-clear">
                    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                    <?php esc_html_e('Clear', 'sigmaforms-pro'); ?>
                </button>
                <button type="button" id="submitBtn" class="btn btn-submit" disabled>
                    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    <?php esc_html_e('Submit Signature', 'sigmaforms-pro'); ?>
                </button>
            </div>
        </div>
        
        <div class="footer">
            <?php esc_html_e('Secured by', 'sigmaforms-pro'); ?> <?php bloginfo('name'); ?>
        </div>
    </div>

    <script>
        (function() {
            'use strict';
            
            const canvas = document.getElementById('signatureCanvas');
            const ctx = canvas.getContext('2d');
            const clearBtn = document.getElementById('clearBtn');
            const submitBtn = document.getElementById('submitBtn');
            const statusMessage = document.getElementById('statusMessage');
            const sessionId = '<?php echo esc_js($session_id); ?>';
            
            let isDrawing = false;
            let lastX = 0;
            let lastY = 0;
            let hasSignature = false;
            
            // Set canvas size
            function resizeCanvas() {
                const rect = canvas.getBoundingClientRect();
                canvas.width = rect.width;
                canvas.height = rect.height;
                
                // Reset drawing style after resize
                ctx.strokeStyle = '#000';
                ctx.lineWidth = 2;
                ctx.lineCap = 'round';
                ctx.lineJoin = 'round';
            }
            
            resizeCanvas();
            window.addEventListener('resize', resizeCanvas);
            
            // Drawing functions
            function startDrawing(x, y) {
                isDrawing = true;
                lastX = x;
                lastY = y;
            }
            
            function draw(x, y) {
                if (!isDrawing) return;
                
                ctx.beginPath();
                ctx.moveTo(lastX, lastY);
                ctx.lineTo(x, y);
                ctx.stroke();
                
                lastX = x;
                lastY = y;
                hasSignature = true;
                submitBtn.disabled = false;
            }
            
            function stopDrawing() {
                isDrawing = false;
            }
            
            // Mouse events
            canvas.addEventListener('mousedown', function(e) {
                const rect = canvas.getBoundingClientRect();
                startDrawing(e.clientX - rect.left, e.clientY - rect.top);
            });
            
            canvas.addEventListener('mousemove', function(e) {
                const rect = canvas.getBoundingClientRect();
                draw(e.clientX - rect.left, e.clientY - rect.top);
            });
            
            canvas.addEventListener('mouseup', stopDrawing);
            canvas.addEventListener('mouseleave', stopDrawing);
            
            // Touch events
            canvas.addEventListener('touchstart', function(e) {
                e.preventDefault();
                const rect = canvas.getBoundingClientRect();
                const touch = e.touches[0];
                startDrawing(touch.clientX - rect.left, touch.clientY - rect.top);
            });
            
            canvas.addEventListener('touchmove', function(e) {
                e.preventDefault();
                const rect = canvas.getBoundingClientRect();
                const touch = e.touches[0];
                draw(touch.clientX - rect.left, touch.clientY - rect.top);
            });
            
            canvas.addEventListener('touchend', function(e) {
                e.preventDefault();
                stopDrawing();
            });
            
            // Clear button
            clearBtn.addEventListener('click', function() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                hasSignature = false;
                submitBtn.disabled = true;
                hideMessage();
            });
            
            // Submit button
            submitBtn.addEventListener('click', function() {
                if (!hasSignature) return;
                
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="loading"></span> <?php esc_html_e('Submitting...', 'sigmaforms-pro'); ?>';
                
                const signatureData = canvas.toDataURL('image/png');
                
                // Send to server
                const formData = new FormData();
                formData.append('action', 'sf_save_mobile_signature');
                formData.append('session_id', sessionId);
                formData.append('signature_data', signatureData);
                
                fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update button to show success and keep it disabled
                        submitBtn.innerHTML = '<svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php esc_html_e('Submitted!', 'sigmaforms-pro'); ?>';
                        submitBtn.style.background = '#10b981';
                        showMessage('success', '<?php echo esc_js(__('Signature submitted successfully! You can close this window.', 'sigmaforms-pro')); ?>');
                        // Button stays disabled - one submission per session
                    } else {
                        showMessage('error', data.data.message || '<?php echo esc_js(__('Failed to submit signature', 'sigmaforms-pro')); ?>');
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = '<svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php esc_html_e('Submit Signature', 'sigmaforms-pro'); ?>';
                    }
                })
                .catch(error => {
                    showMessage('error', '<?php echo esc_js(__('Network error. Please try again.', 'sigmaforms-pro')); ?>');
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php esc_html_e('Submit Signature', 'sigmaforms-pro'); ?>';
                });
            });
            
            function showMessage(type, message) {
                statusMessage.className = 'status-message ' + type;
                statusMessage.textContent = message;
            }
            
            function hideMessage() {
                statusMessage.className = 'status-message';
                statusMessage.textContent = '';
            }
        })();
    </script>
</body>
</html>
