<?php
/**
 * Admin view for forms list
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;
?>

<div class="sf-admin-wrap sf-forms-page">
    <?php
    PageHeader::render();
    PageHeader::intro(
        array(
            'title' => __('Forms', 'sigmaforms-pro'),
            'actions'        => array(
                array(
                    'url'     => admin_url('admin.php?page=sigmaforms-new'),
                    'label'   => __('Create New Form', 'sigmaforms-pro'),
                    'icon'    => 'plus',
                    'primary' => true,
                ),
            ),
        )
    );
    ?>

    <?php if (empty($forms)) : ?>
        <div class="sf-card sf-empty-card">
            <h2><?php esc_html_e('No forms found.', 'sigmaforms-pro'); ?></h2>
            <p><?php esc_html_e('Get started by creating your first AI generated form.', 'sigmaforms-pro'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-new')); ?>" class="sf-page-intro__action sf-page-intro__action--primary">
                <?php echo PageHeader::icon('plus'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                <span><?php esc_html_e('Create New Form', 'sigmaforms-pro'); ?></span>
            </a>
        </div>
    <?php else : ?>
        <div class="sf-card sf-card--table">
            <div class="sf-form-list">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th scope="col" class="manage-column column-title column-primary">
                                <?php esc_html_e('Form Name', 'sigmaforms-pro'); ?>
                            </th>
                            <th scope="col" class="manage-column">
                                <?php esc_html_e('Shortcode', 'sigmaforms-pro'); ?>
                            </th>
                            <th scope="col" class="manage-column">
                                <?php esc_html_e('Submissions', 'sigmaforms-pro'); ?>
                            </th>
                            <th scope="col" class="manage-column">
                                <?php esc_html_e('Created', 'sigmaforms-pro'); ?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
                        foreach ($forms as $form) : 
                            // Get submission count
                            $submission_count = $forms_manager->get_submissions_count($form['id']);
                            
                            // Format date
                            $date_created = mysql2date(get_option('date_format'), $form['date_created']);
                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                        ?>
                            <tr>
                                <td class="title column-title has-row-actions column-primary">
                                    <strong>
                                        <a href="<?php echo esc_url(add_query_arg(['_wpnonce' => wp_create_nonce('edit_form_' . $form['id'])], admin_url('admin.php?page=sigmaforms-new&form_id=' . $form['id']))); ?>">
                                            <?php echo esc_html($form['title']); ?>
                                        </a>
                                    </strong>
                                    <div class="row-actions">
                                        <span class="edit">
                                            <a href="<?php echo esc_url(add_query_arg(['_wpnonce' => wp_create_nonce('edit_form_' . $form['id'])], admin_url('admin.php?page=sigmaforms-new&form_id=' . $form['id']))); ?>">
                                                <?php esc_html_e('Edit', 'sigmaforms-pro'); ?>
                                            </a> | 
                                        </span>
                                        <span class="submissions">
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-submissions&form_id=' . $form['id'])); ?>">
                                                <?php esc_html_e('View Submissions', 'sigmaforms-pro'); ?>
                                            </a> | 
                                        </span>
                                        <span class="duplicate">
                                            <a href="#" class="sf-duplicate-form" data-id="<?php echo esc_attr($form['id']); ?>">
                                                <?php esc_html_e('Duplicate', 'sigmaforms-pro'); ?>
                                            </a> | 
                                        </span>
                                        <span class="trash">
                                            <a href="#" class="submitdelete sf-delete-form" data-id="<?php echo esc_attr($form['id']); ?>">
                                                <?php esc_html_e('Delete', 'sigmaforms-pro'); ?>
                                            </a>
                                        </span>
                                    </div>
                                </td>
                                <td class="sf-cell-shortcode">
                                    <code>[sigmaforms id="<?php echo esc_attr($form['id']); ?>"]</code>
                                    <button type="button" class="copy-shortcode" data-clipboard-text='[sigmaforms id="<?php echo esc_attr($form['id']); ?>"]' aria-label="<?php esc_attr_e('Copy shortcode', 'sigmaforms-pro'); ?>">
                                        <?php echo PageHeader::icon('copy'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                    </button>
                                </td>
                                <td>
                                    <a class="sf-count-badge<?php echo $submission_count > 0 ? ' has-items' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-submissions&form_id=' . $form['id'])); ?>">
                                        <?php echo esc_html($submission_count); ?>
                                    </a>
                                </td>
                                <td class="sf-cell-muted">
                                    <?php echo esc_html($date_created); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
    jQuery(document).ready(function($) {
        // Delete form
        $('.sf-delete-form').on('click', function(e) {
            e.preventDefault();

            const $sfTrigger = $(this);
            window.SF.confirm('<?php echo esc_js(__('Are you sure you want to delete this form? This action cannot be undone.', 'sigmaforms-pro')); ?>', { danger: true }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                const formId = $sfTrigger.data('id');
                
                $.ajax({
                    url: sfAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_delete_form',
                        nonce: sfAdmin.nonce,
                        form_id: formId
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.reload();
                        } else {
                            window.SF.notify(response.data.message || '<?php echo esc_js(__('Error deleting form.', 'sigmaforms-pro')); ?>');
                        }
                    },
                    error: function() {
                        window.SF.notify('<?php echo esc_js(__('Error deleting form.', 'sigmaforms-pro')); ?>');
                    }
                });
            });
        });
        
        // Duplicate form
        $('.sf-duplicate-form').on('click', function(e) {
            e.preventDefault();

            const $sfTrigger = $(this);
            window.SF.confirm('<?php echo esc_js(__('Are you sure you want to duplicate this form? A copy will be created with all the same configuration.', 'sigmaforms-pro')); ?>').then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                const formId = $sfTrigger.data('id');
                const $button = $sfTrigger;
                const originalText = $button.text();
                
                // Disable button and show loading state
                $button.text('<?php echo esc_js(__('Duplicating...', 'sigmaforms-pro')); ?>');
                
                $.ajax({
                    url: sfAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_duplicate_form',
                        nonce: sfAdmin.nonce,
                        form_id: formId
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.reload();
                        } else {
                            window.SF.notify(response.data.message || '<?php echo esc_js(__('Error duplicating form.', 'sigmaforms-pro')); ?>');
                            $button.text(originalText);
                        }
                    },
                    error: function() {
                        window.SF.notify('<?php echo esc_js(__('Error duplicating form.', 'sigmaforms-pro')); ?>');
                        $button.text(originalText);
                    }
                });
            });
        });
        
        // Copy shortcode
        $('.copy-shortcode').on('click', function() {
            const shortcode = $(this).data('clipboard-text');
            
            // Create temporary textarea to copy from
            const $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val(shortcode).select();
            document.execCommand('copy');
            $temp.remove();
            
            // Flash a tick, then put the button's own markup back
            const $this = $(this);
            const originalHtml = $this.html();

            $this.attr('title', '<?php esc_attr_e('Copied!', 'sigmaforms-pro'); ?>')
                .addClass('is-copied')
                .html(`<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>`);

            setTimeout(function() {
                $this.removeClass('is-copied')
                    .attr('title', '<?php esc_attr_e('Copy shortcode', 'sigmaforms-pro'); ?>')
                    .html(originalHtml);
            }, 2000);
        });
    });
</script>
