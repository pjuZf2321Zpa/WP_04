<?php
/**
 * Admin view for single submission
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- View template variables are local, not global

// Get submission data
global $wpdb;
$submissions_table = $wpdb->prefix . 'sigmaforms_submissions';
$forms_table = $wpdb->prefix . 'sigmaforms';
$submissionQuery =  "SELECT s.*, f.title as form_title, f.form_fields FROM {$submissions_table} s LEFT JOIN {$forms_table} f ON s.form_id = f.id WHERE s.id = %d";
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
$submission = $wpdb->get_row($wpdb->prepare($submissionQuery,$submission_id),ARRAY_A);

if (!$submission) {
    wp_die(esc_html__('Submission not found.', 'sigmaforms-pro'), '', array('back_link' => true));
}

// Convert field values from JSON
$field_values = json_decode($submission['field_values'], true) ?: [];
$form_fields = json_decode($submission['form_fields'], true) ?: [];

// Format date
$date_created = mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $submission['date_created']);

// Mark as read if unread
if ($submission['status'] === 'unread') {
    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->update($submissions_table,['status' => 'read'],['id' => $submission_id],['%s'],['%d']);
}

// Build field labels map
$field_labels = [];
foreach ($form_fields as $field) {
    if (isset($field['id']) && isset($field['label'])) {
        $field_labels[$field['id']] = $field['label'];
    }
}
?>

<div class="sf-admin-wrap sf-submission-view-page">
    <?php
    PageHeader::render();
    PageHeader::intro(
        array(
            'title'   => __('Submission Details', 'sigmaforms-pro'),
            'actions' => array(
                array(
                    'url'   => admin_url('admin.php?page=sigmaforms-submissions' . ($form_id > 0 ? '&form_id=' . $form_id : '')),
                    'label' => __('Back to Submissions', 'sigmaforms-pro'),
                    'icon'  => 'arrow-left',
                ),
            ),
        )
    );
    ?>

    <div class="sf-card">
        <div class="sf-card-header">
            <h2><?php 
            $display_title = $submission['form_title'];
            if ($display_title === null || $display_title === '') {
                /* translators: %d is the ID of the deleted form */
                $display_title = sprintf(__('Deleted Form - #%d', 'sigmaforms-pro'), (int) $submission['form_id']);
            }
            /* translators: %s is the form title or deleted form message */
            echo esc_html(sprintf(__('Submission from %s', 'sigmaforms-pro'), $display_title)); 
            ?></h2>
        </div>
        
        <div class="sf-form-list">
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Field', 'sigmaforms-pro'); ?></th>
                        <th><?php esc_html_e('Value', 'sigmaforms-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($field_values as $field_id => $value) : 
                        // Skip internal fields
                        if (substr($field_id, 0, 1) === '_') {
                            continue;
                        }
                        
                        $label = isset($field_labels[$field_id]) ? $field_labels[$field_id] : $field_id;
                        
                        // Get field type
                        $field_type = '';
                        foreach ($form_fields as $field) {
                            if (isset($field['id']) && $field['id'] === $field_id) {
                                $field_type = isset($field['type']) ? $field['type'] : '';
                                break;
                            }
                        }
                        
                        // Format value for display based on field type
                        if (is_array($value)) {
                            $display_value = implode(', ', array_map('esc_html', $value));
                        } elseif ($field_type === 'url' && !empty($value) && filter_var($value, FILTER_VALIDATE_URL)) {
                            // Make URLs clickable
                            $display_value = '<a href="' . esc_url($value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($value) . '</a>';
                        } elseif ($field_type === 'file' && !empty($value)) {
                            // Handle multiple files (comma-separated URLs) or single file
                            if (strpos($value, ', ') !== false) {
                                // Multiple files - split and display each on a separate line
                                $file_urls = explode(', ', $value);
                                $file_links = [];
                                foreach ($file_urls as $file_url) {
                                    $file_url = trim($file_url);
                                    if (filter_var($file_url, FILTER_VALIDATE_URL)) {
                                        // Extract filename from URL for display
                                        $filename = basename(wp_parse_url($file_url, PHP_URL_PATH));
                                        $file_links[] = '<a href="' . esc_url($file_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($filename) . '</a>';
                                    } elseif (strpos($file_url, '(Email Attachment)') !== false) {
                                        // Email attachment format
                                        $file_links[] = esc_html($file_url);
                                    } else {
                                        $file_links[] = esc_html($file_url);
                                    }
                                }
                                $display_value = implode('<br>', $file_links);
                            } elseif (filter_var($value, FILTER_VALIDATE_URL)) {
                                // Single file URL - make it clickable with filename as text
                                $filename = basename(wp_parse_url($value, PHP_URL_PATH));
                                $display_value = '<a href="' . esc_url($value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($filename) . '</a>';
                            } else {
                                // Not a URL (e.g., email attachment format)
                                $display_value = esc_html($value);
                            }
                        } elseif ($field_type === 'signature' && !empty($value)) {
                            // Display signature as image - handle both base64 data URIs and file URLs
                            if (\SigmaForms\Utils\Helper::is_safe_image_data_uri($value)) {
                                // Old base64 format. Validated as a strict base64 image data URI and escaped,
                                // so it cannot break out of the src attribute.
                                $display_value = '<img src="' . esc_attr($value) . '" alt="Signature" style="max-width: 300px; max-height: 200px; border: 1px solid #ddd; padding: 5px; background: #fff; display: block;">';
                            } elseif (filter_var($value, FILTER_VALIDATE_URL)) {
                                // New file URL format
                                $display_value = '<img src="' . esc_url($value) . '" alt="Signature" style="max-width: 300px; max-height: 200px; border: 1px solid #ddd; padding: 5px; background: #fff; display: block;">';
                            } else {
                                $display_value = esc_html($value);
                            }
                        } elseif ($field_type === 'rich_text') {
                            $display_value = wp_kses_post($value);
                        } else {
                            // Check if value looks like a URL (even if field type is not URL)
                            if (!empty($value) && filter_var($value, FILTER_VALIDATE_URL)) {
                                $display_value = '<a href="' . esc_url($value) . '" target="_blank" rel="noopener noreferrer">' . esc_html($value) . '</a>';
                            } else {
                                $display_value = esc_html($value);
                            }
                        }
                    ?>
                        <tr>
                            <td><strong><?php echo esc_html($label); ?></strong></td>
                            <td><?php
                                // For signature fields the markup is built from a validated data URI or an
                                // escaped file URL, both of which wp_kses_post() would strip.
                                if ($field_type === 'signature' && !empty($value)) {
                                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Value validated and escaped above.
                                    echo $display_value;
                                } else {
                                    echo wp_kses_post($display_value);
                                }
                            ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="sf-submission-meta">
            <p><strong><?php esc_html_e('Submission ID:', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($submission_id); ?></p>
            <p><strong><?php esc_html_e('Date:', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($date_created); ?></p>
            
            <?php if (!empty($submission['user_id'])) : 
                $user = get_userdata($submission['user_id']);
                if ($user) :
            ?>
                <p><strong><?php esc_html_e('User:', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($user->display_name); ?> (<?php echo esc_html($user->user_email); ?>)</p>
            <?php 
                endif;
            endif; 
            ?>
            
            <p><strong><?php esc_html_e('IP Address:', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($submission['user_ip']); ?></p>
            
            <?php if (!empty($submission['user_agent'])) : ?>
                <p><strong><?php esc_html_e('User Agent:', 'sigmaforms-pro'); ?></strong> <?php echo esc_html($submission['user_agent']); ?></p>
            <?php endif; ?>
        </div>
        
        <div class="sf-card-footer">
            <a href="<?php echo esc_url(admin_url('admin.php?page=sigmaforms-submissions' . ($form_id > 0 ? '&form_id=' . $form_id : ''))); ?>" class="sf-btn sf-btn-secondary sf-span-link">
                <?php echo PageHeader::icon('arrow-left'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <span><?php esc_html_e('Back to Submissions', 'sigmaforms-pro'); ?></span>
            </a>
            <button type="button" class="sf-btn sf-btn-danger sf-delete-submission sf-span-link" data-id="<?php echo esc_attr($submission_id); ?>">
                <?php echo PageHeader::icon('trash'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <span><?php esc_html_e('Delete Submission', 'sigmaforms-pro'); ?></span>
            </button>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function($) {
        // Delete submission
        $('.sf-delete-submission').on('click', function(e) {
            e.preventDefault();

            const $sfTrigger = $(this);
            window.SF.confirm('<?php echo esc_js(__('Are you sure you want to delete this submission? This action cannot be undone.', 'sigmaforms-pro')); ?>', { danger: true }).then(function (sfConfirmed) {
                if (!sfConfirmed) {
                    return;
                }
                const submissionId = $sfTrigger.data('id');
                
                $.ajax({
                    url: sfAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_delete_submission',
                        nonce: sfAdmin.nonce,
                        submission_id: submissionId
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.href = '<?php echo esc_url(admin_url('admin.php?page=sigmaforms-submissions' . ($form_id > 0 ? '&form_id=' . $form_id : ''))); ?>';
                        } else {
                            window.SF.notify(response.data.message || '<?php echo esc_js(__('Error deleting submission.', 'sigmaforms-pro')); ?>');
                        }
                    },
                    error: function() {
                        window.SF.notify('<?php echo esc_js(__('Error deleting submission.', 'sigmaforms-pro')); ?>');
                    }
                });
            });
        });
    });
</script>
