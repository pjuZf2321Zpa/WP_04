<?php
/**
 * Admin view for settings page
 *
 * @package SigmaForms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use SigmaForms\Admin\PageHeader;

// Simple AI configuration
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables, not global
$api_key = $settings['ai_api_key'] ?? '';

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Reading tab parameter for UI display only, not processing form data
$active_tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'ai-config';
// phpcs:enable WordPress.Security.NonceVerification.Recommended
$valid_tabs = ['ai-config', 'email-settings', 'form-styling', 'recaptcha', 'webhooks', 'storage', 'advanced'];

// License-protected tabs
$license_required_tabs = ['recaptcha', 'email-settings', 'webhooks', 'storage'];
$is_license_valid = \SigmaForms\Plugin::is_license_valid();

// If accessing a license-protected tab without valid license, redirect to ai-config
if (!$is_license_valid && in_array($active_tab, $license_required_tabs)) {
    $active_tab = 'ai-config';
}

if (!in_array($active_tab, $valid_tabs)) {
    $active_tab = 'ai-config';
}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>

<div class="sf-admin-wrap sf-settings-page">
    <?php
    PageHeader::render();
    PageHeader::intro(
        array(
            'title' => __('Settings', 'sigmaforms-pro'),
        )
    );
    ?>

    <div class="sf-content-wrapper">
        <div class="sf-main-content">
            <div class="sf-card sf-settings-card">
                <!-- Tabs Navigation -->
                <div class="sf-settings-tabs-nav">
                    <ul>
                        <li><a href="#ai-config" class="<?php echo $active_tab === 'ai-config' ? 'active' : ''; ?>" data-tab="ai-config"><?php echo \SigmaForms\Admin\PageHeader::icon('settings'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('AI Configuration', 'sigmaforms-pro'); ?></a></li>
                        <li><a href="#form-styling" class="<?php echo $active_tab === 'form-styling' ? 'active' : ''; ?>" data-tab="form-styling"><?php echo \SigmaForms\Admin\PageHeader::icon('brush'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Form Styling', 'sigmaforms-pro'); ?></a></li>
                        <?php if ($is_license_valid): ?>
                        <li><a href="#recaptcha" class="<?php echo $active_tab === 'recaptcha' ? 'active' : ''; ?>" data-tab="recaptcha"><?php echo \SigmaForms\Admin\PageHeader::icon('shield'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('CAPTCHA', 'sigmaforms-pro'); ?></a></li>
                        <li><a href="#email-settings" class="<?php echo $active_tab === 'email-settings' ? 'active' : ''; ?>" data-tab="email-settings"><?php echo \SigmaForms\Admin\PageHeader::icon('mail'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Email Settings', 'sigmaforms-pro'); ?></a></li>
                        <li><a href="#webhooks" class="<?php echo $active_tab === 'webhooks' ? 'active' : ''; ?>" data-tab="webhooks"><?php echo \SigmaForms\Admin\PageHeader::icon('link'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Webhooks', 'sigmaforms-pro'); ?></a></li>
                        <li><a href="#storage" class="<?php echo $active_tab === 'storage' ? 'active' : ''; ?>" data-tab="storage"><?php echo \SigmaForms\Admin\PageHeader::icon('cloud'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Cloud Storage', 'sigmaforms-pro'); ?></a></li>
                        <li><a href="#advanced" class="<?php echo $active_tab === 'advanced' ? 'active' : ''; ?>" data-tab="advanced"><?php echo \SigmaForms\Admin\PageHeader::icon('tool'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Advanced', 'sigmaforms-pro'); ?></a></li>
                        <?php else: ?>
                        <li><a href="#advanced" class="<?php echo $active_tab === 'advanced' ? 'active' : ''; ?>" data-tab="advanced"><?php echo \SigmaForms\Admin\PageHeader::icon('tool'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <?php esc_html_e('Advanced', 'sigmaforms-pro'); ?></a></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Tabs Content -->
                <div class="sf-settings-content-layout">
                    <div class="sf-settings-tabs-content">
                        <form method="post" id="sf-settings-form" class="sf-settings-form">
                            <?php wp_nonce_field('sf_save_settings', 'sf_settings_nonce'); ?>
                            
                            <!-- AI Configuration Tab -->
                            <div id="ai-config" class="sf-tab-content <?php echo $active_tab === 'ai-config' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('API Configuration', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Configure your API key to enable AI form generation.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                                <div class="sf-settings-field">
                                    <label for="ai_api_key"><?php esc_html_e('SigmaForms API Key', 'sigmaforms-pro'); ?></label>
                                    <div class="sf-input-wrapper">
                                        <input type="password" id="ai_api_key" name="ai_api_key" value="<?php echo esc_attr($api_key); ?>">
                                        <button type="button" class="sf-api-key-toggle"><?php esc_html_e('Show', 'sigmaforms-pro'); ?></button>
                                    </div>
                                    <p class="description">
                                    <?php 
                                        // translators: %s is the URL to the OpenAI API key page.
                                        printf(wp_kses_post(__('You can get your SigmaForms API key from <a href="%s" target="_blank">Account Dashboard</a>.', 'sigmaforms-pro')),
                                            'https://account.bdthemes.com/prompt-ai-licenses'
                                        ); ?>
                                    </p>
                                    </p>
                                </div>
                            </div>
                            
                            <!-- Email Settings Tab -->
                            <div id="email-settings" class="sf-tab-content <?php echo $active_tab === 'email-settings' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('Default Email Settings', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Configure default email settings for new forms.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                                <div class="sf-settings-label-separator">
                                    <h4><?php esc_html_e('Recipients', 'sigmaforms-pro'); ?></h4>
                                </div>
                                <div class="sf-settings-field-group">

                                    <div class="sf-settings-field">
                                        <label for="admin_email"><?php esc_html_e('Default Admin Email', 'sigmaforms-pro'); ?></label>
                                        <input type="text" id="admin_email" name="admin_email" value="<?php echo esc_attr($settings['admin_email']); ?>">
                                        <p class="description"><?php esc_html_e('Default email address(es) where form submissions will be sent. Separate multiple addresses with commas.', 'sigmaforms-pro'); ?></p>
                                    </div>
    
                                    <div class="sf-settings-field">
                                        <label for="app_name"><?php esc_html_e('App Name', 'sigmaforms-pro'); ?></label>
                                        <input type="text" id="app_name" name="app_name" value="<?php echo esc_attr($settings['app_name'] ?? get_bloginfo('name')); ?>">
                                        <p class="description"><?php esc_html_e('This name will be used in email "From" field and other communications.', 'sigmaforms-pro'); ?></p>
                                    </div>
                                </div>

                                <div class="sf-settings-field-group">
                                    <div class="sf-settings-field">
                                        <label for="admin_email_cc"><?php esc_html_e('Default Admin CC Email', 'sigmaforms-pro'); ?></label>
                                        <input type="text" id="admin_email_cc" name="admin_email_cc" value="<?php echo esc_attr($settings['admin_email_cc'] ?? ''); ?>">
                                        <p class="description"><?php esc_html_e('CC email address(es) for notification emails. Separate multiple addresses with commas.', 'sigmaforms-pro'); ?></p>
                                    </div>

                                    <div class="sf-settings-field">
                                        <label for="admin_email_bcc"><?php esc_html_e('Default Admin BCC Email', 'sigmaforms-pro'); ?></label>
                                        <input type="text" id="admin_email_bcc" name="admin_email_bcc" value="<?php echo esc_attr($settings['admin_email_bcc'] ?? ''); ?>">
                                        <p class="description"><?php esc_html_e('BCC email address(es) for notification emails. Separate multiple addresses with commas.', 'sigmaforms-pro'); ?></p>
                                    </div>
                                </div>

                                <div class="sf-settings-label-separator">
                                    <h4><?php esc_html_e('Email Content', 'sigmaforms-pro'); ?></h4>
                                </div>
                                <div class="sf-settings-field-group">
                                    <div class="sf-settings-field">
                                        <label for="default_email_subject"><?php esc_html_e('Default Email Subject', 'sigmaforms-pro'); ?></label>
                                        <input type="text" id="default_email_subject" name="default_email_subject" value="<?php 
                                        // translators: %s is the blog name.
                                        echo esc_attr($settings['default_email_subject'] ?? sprintf(__('New submission from %s', 'sigmaforms-pro'), get_bloginfo('name'))); ?>">
                                        <p class="description"><?php esc_html_e('Default subject line for notification emails. Available placeholders: {name}, {email}, {date}', 'sigmaforms-pro'); ?></p>
                                    </div>
    
                                    <div class="sf-settings-field">
                                        <label for="default_confirmation_subject"><?php esc_html_e('Default Confirmation Subject', 'sigmaforms-pro'); ?></label>
                                        <input type="text" id="default_confirmation_subject" name="default_confirmation_subject" value="<?php echo esc_attr($settings['default_confirmation_subject'] ?? __('Thank you for your submission', 'sigmaforms-pro')); ?>">
                                        <p class="description"><?php esc_html_e('Default subject line for confirmation emails. Available placeholders: {name}, {email}, {date}', 'sigmaforms-pro'); ?></p>
                                    </div>
                                </div>

                                <div class="sf-settings-field">
                                    <label for="default_email_message"><?php esc_html_e('Default Email Message', 'sigmaforms-pro'); ?></label>
                                    <textarea id="default_email_message" name="default_email_message" rows="6"><?php echo esc_textarea($settings['default_email_message'] ?? __("New submission received.\n\n{all_fields}\n\nSubmitted on: {date}", 'sigmaforms-pro')); ?></textarea>
                                    <p class="description"><?php esc_html_e('Default message content for notification emails. Available placeholders: {name}, {email}, {all_fields}, {date}', 'sigmaforms-pro'); ?></p>
                                </div>

                                <div class="sf-settings-field">
                                    <label for="default_confirmation_message"><?php esc_html_e('Default Confirmation Message', 'sigmaforms-pro'); ?></label>
                                    <textarea id="default_confirmation_message" name="default_confirmation_message" rows="6"><?php echo esc_textarea($settings['default_confirmation_message'] ?? __('We have received your submission and will get back to you soon.', 'sigmaforms-pro')); ?></textarea>
                                    <p class="description"><?php esc_html_e('Default message content for confirmation emails. Available placeholders: {name}, {email}, {all_fields}, {date}', 'sigmaforms-pro'); ?></p>
                                </div>

                                <div class="sf-settings-label-separator">
                                    <h4><?php esc_html_e('SMTP', 'sigmaforms-pro'); ?></h4>
                                </div>
                                <div class="sf-settings-field">
                                    <label class="sf-toggle-label">
                                        <div class="sf-toggle-switch">
                                            <input type="checkbox" id="smtp_enabled" name="smtp_enabled" <?php checked(isset($settings['smtp_config']['enabled']) ? $settings['smtp_config']['enabled'] : false); ?>>
                                            <span class="sf-toggle-slider"></span>
                                        </div>
                                        <?php esc_html_e('Enable SMTP', 'sigmaforms-pro'); ?>
                                    </label>
                                    <p class="description">
                                        <?php esc_html_e('Enable SMTP to send emails through a custom SMTP server.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>

                                <div id="smtp-settings" class="sf-smtp-settings" style="display: <?php echo (isset($settings['smtp_config']['enabled']) && $settings['smtp_config']['enabled']) ? 'block' : 'none'; ?>">

                                    <div class="sf-settings-field-group">
                                        <div class="sf-settings-field">
                                            <label for="smtp_host"><?php esc_html_e('SMTP Host', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="smtp_host" name="smtp_host" value="<?php echo esc_attr($settings['smtp_config']['host'] ?? ''); ?>" placeholder="smtp.example.com">
                                        </div>

                                        <div class="sf-settings-field">
                                            <label for="smtp_port"><?php esc_html_e('SMTP Port', 'sigmaforms-pro'); ?></label>
                                            <input type="number" id="smtp_port" name="smtp_port" value="<?php echo esc_attr($settings['smtp_config']['port'] ?? '587'); ?>" placeholder="587">
                                        </div>
                                    </div>
                                    <div class="sf-settings-field-group">
                                        <div class="sf-settings-field">
                                            <label for="smtp_encryption"><?php esc_html_e('Encryption', 'sigmaforms-pro'); ?></label>
                                            <select id="smtp_encryption" name="smtp_encryption">
                                                <option value="tls" <?php selected($settings['smtp_config']['encryption'] ?? 'tls', 'tls'); ?>><?php esc_html_e('TLS', 'sigmaforms-pro'); ?></option>
                                                <option value="ssl" <?php selected($settings['smtp_config']['encryption'] ?? 'tls', 'ssl'); ?>><?php esc_html_e('SSL', 'sigmaforms-pro'); ?></option>
                                                <option value="none" <?php selected($settings['smtp_config']['encryption'] ?? 'tls', 'none'); ?>><?php esc_html_e('None', 'sigmaforms-pro'); ?></option>
                                            </select>
                                        </div>
    
                                        <div class="sf-settings-field">
                                            <label for="smtp_username"><?php esc_html_e('SMTP Username', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="smtp_username" name="smtp_username" value="<?php echo esc_attr($settings['smtp_config']['username'] ?? ''); ?>" placeholder="username@example.com">
                                        </div>
                                    </div>

                                    <div class="sf-settings-field">
                                        <label for="smtp_password"><?php esc_html_e('SMTP Password', 'sigmaforms-pro'); ?></label>
                                        <div class="sf-input-wrapper">
                                            <?php // The saved password is never printed into the page; leaving the field empty keeps it. ?>
                                            <input type="password" id="smtp_password" name="smtp_password" value="" autocomplete="new-password"
                                                placeholder="<?php echo !empty($settings['smtp_config']['password']) ? esc_attr__('Saved. Leave empty to keep it.', 'sigmaforms-pro') : ''; ?>">
                                            <button type="button" class="sf-api-key-toggle"><?php esc_html_e('Show', 'sigmaforms-pro'); ?></button>
                                        </div>
                                        <?php if (!empty($settings['smtp_config']['password'])) : ?>
                                            <label class="sf-smtp-password-clear">
                                                <input type="checkbox" name="smtp_password_clear" value="1">
                                                <?php esc_html_e('Remove saved password', 'sigmaforms-pro'); ?>
                                            </label>
                                        <?php endif; ?>
                                    </div>

                                    <div class="sf-settings-field sf-settings-smtp-btn">
                                        <button type="button" id="test_smtp" class="button sf-btn sf-btn-secondary">
                                            <?php esc_html_e('Test SMTP Connection', 'sigmaforms-pro'); ?>
                                        </button>
                                        <span id="smtp-test-result" class="sf-test-result" style="display: none;"></span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Form Styling Tab -->
                            <div id="form-styling" class="sf-tab-content <?php echo $active_tab === 'form-styling' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('Form Styling', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Customize the default appearance of forms.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                                
                                <div class="sf-theme-selector">
                                    <h3><?php esc_html_e('Select Theme Style', 'sigmaforms-pro'); ?></h3>
                                    <p class="description">
                                        <?php esc_html_e('Choose a pre-designed theme for your forms or customize colors individually.', 'sigmaforms-pro'); ?>
                                    </p>
                                    
                                    <div class="sf-theme-options">
                                        <?php
                                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not global
                                        $current_theme = isset($settings['form_styling']['theme']) ? $settings['form_styling']['theme'] : 'minimal';
                                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                                        ?>
                                        <div class="sf-theme-option <?php echo ($current_theme === 'soft') ? 'active' : ''; ?>">
                                            <label>
                                                <input type="radio" name="form_theme" value="soft" <?php checked($current_theme, 'soft'); ?>>
                                                <span class="sf-theme-preview sf-theme-soft-preview">
                                                    <span class="preview-header"></span>
                                                    <span class="preview-fields">
                                                        <span class="preview-field"></span>
                                                        <span class="preview-field is-focused"></span>
                                                    </span>
                                                    <span class="preview-button"></span>
                                                </span>
                                                <span class="sf-theme-title"><?php esc_html_e('Soft', 'sigmaforms-pro'); ?></span>
                                                <span class="sf-theme-badge"><?php esc_html_e('New', 'sigmaforms-pro'); ?></span>
                                            </label>
                                        </div>

                                        <div class="sf-theme-option <?php echo ($current_theme === 'minimal') ? 'active' : ''; ?>">
                                            <label>
                                                <input type="radio" name="form_theme" value="minimal" <?php checked($current_theme, 'minimal'); ?>>
                                                <span class="sf-theme-preview sf-theme-minimal">
                                                    <span class="preview-header"></span>
                                                    <span class="preview-fields">
                                                        <span class="preview-field"></span>
                                                        <span class="preview-field"></span>
                                                    </span>
                                                    <span class="preview-button"></span>
                                                </span>
                                                <span class="sf-theme-title"><?php esc_html_e('Minimal', 'sigmaforms-pro'); ?></span>
                                            </label>
                                        </div>

                                        <div class="sf-theme-option <?php echo ($current_theme === 'classic') ? 'active' : ''; ?>">
                                            <label>
                                                <input type="radio" name="form_theme" value="classic" <?php checked($current_theme, 'classic'); ?>>
                                                <span class="sf-theme-preview sf-theme-classic">
                                                    <span class="preview-header"></span>
                                                    <span class="preview-fields">
                                                        <span class="preview-field"></span>
                                                        <span class="preview-field"></span>
                                                    </span>
                                                    <span class="preview-button"></span>
                                                </span>
                                                <span class="sf-theme-title"><?php esc_html_e('Classic', 'sigmaforms-pro'); ?></span>
                                            </label>
                                        </div>

                                        <div class="sf-theme-option <?php echo ($current_theme === 'modern') ? 'active' : ''; ?>">
                                            <label>
                                                <input type="radio" name="form_theme" value="modern" <?php checked($current_theme, 'modern'); ?>>
                                                <span class="sf-theme-preview sf-theme-modern">
                                                    <span class="preview-header"></span>
                                                    <span class="preview-fields">
                                                        <span class="preview-field"></span>
                                                        <span class="preview-field"></span>
                                                    </span>
                                                    <span class="preview-button"></span>
                                                </span>
                                                <span class="sf-theme-title"><?php esc_html_e('Modern', 'sigmaforms-pro'); ?></span>
                                            </label>
                                        </div>

                                        <div class="sf-theme-option <?php echo ($current_theme === 'transition') ? 'active' : ''; ?>">
                                            <label>
                                                <input type="radio" name="form_theme" value="transition" <?php checked($current_theme, 'transition'); ?>>
                                                <span class="sf-theme-preview sf-theme-transition-preview">
                                                    <span class="preview-header"></span>
                                                    <span class="preview-cards">
                                                        <span class="preview-card"></span>
                                                        <span class="preview-card is-selected"></span>
                                                        <span class="preview-card"></span>
                                                        <span class="preview-card"></span>
                                                    </span>
                                                    <span class="preview-progress"></span>
                                                </span>
                                                <span class="sf-theme-title"><?php esc_html_e('Transition', 'sigmaforms-pro'); ?></span>
                                            </label>
                                        </div>

                                        <div class="sf-theme-option <?php echo ($current_theme === 'custom') ? 'active' : ''; ?>">
                                            <label>
                                                <input type="radio" name="form_theme" value="custom" <?php checked($current_theme, 'custom'); ?>>
                                                <span class="sf-theme-preview sf-theme-custom">
                                                    <span class="preview-header"></span>
                                                    <span class="preview-fields">
                                                        <span class="preview-field"></span>
                                                        <span class="preview-field"></span>
                                                    </span>
                                                    <span class="preview-button"></span>
                                                </span>
                                                <span class="sf-theme-title"><?php esc_html_e('Custom', 'sigmaforms-pro'); ?></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <label class="sf-apply-theme-all" for="sf_apply_theme_to_all_forms">
                                    <input type="checkbox" id="sf_apply_theme_to_all_forms" name="apply_theme_to_all_forms" value="1">
                                    <?php esc_html_e('Apply to all existing forms', 'sigmaforms-pro'); ?>
                                </label>
                                <p class="description"><?php esc_html_e('Forms on "Global default" always follow this theme. Check this to switch every other form to it as well; forms can still pick their own theme in the form editor.', 'sigmaforms-pro'); ?></p>

                                <div id="sf-custom-styling" class="<?php echo ($current_theme === 'custom') ? 'active' : ''; ?>">
                                    <h3><?php esc_html_e('Custom Style Options', 'sigmaforms-pro'); ?></h3>
                                    <p class="description">
                                       <h4><?php esc_html_e('These options will only apply when using the Custom theme.', 'sigmaforms-pro'); ?></h4>
                                    </p>

                                    <div class="sf-settings-label-separator">
                                        <h4><?php esc_html_e('Input Fields', 'sigmaforms-pro'); ?></h4>
                                    </div>
                                    <div class="sf-settings-row">
                                       <div class="sf-settings-field sf-color-field">
                                            <label for="label_color"><?php esc_html_e('Label Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="label_color" value="<?php echo esc_attr($settings['form_styling']['label_color'] ?? '#333333'); ?>">
                                                <input type="text" name="label_color" value="<?php echo esc_attr($settings['form_styling']['label_color'] ?? '#333333'); ?>">
                                            </div>
                                        </div>
                                        <div class="sf-settings-field sf-color-field">
                                            <label for="field_background"><?php esc_html_e('Background Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="field_background" value="<?php echo esc_attr($settings['form_styling']['field_background']); ?>">
                                                <input type="text" name="field_background" value="<?php echo esc_attr($settings['form_styling']['field_background']); ?>">
                                            </div>
                                        </div>
                                        
                                    </div>

                                    <!-- New custom theme color options -->
                                    <div class="sf-settings-row">

                                        <div class="sf-settings-field sf-color-field">
                                            <label for="input_text_color"><?php esc_html_e('Value Text Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="input_text_color" value="<?php echo esc_attr($settings['form_styling']['input_text_color'] ?? '#333333'); ?>">
                                                <input type="text" name="input_text_color" value="<?php echo esc_attr($settings['form_styling']['input_text_color'] ?? '#333333'); ?>">
                                            </div>
                                        </div>
                                        <div class="sf-settings-field sf-color-field">
                                            <label for="placeholder_color"><?php esc_html_e('Placeholder Text Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="placeholder_color" value="<?php echo esc_attr($settings['form_styling']['placeholder_color'] ?? '#888888'); ?>">
                                                <input type="text" name="placeholder_color" value="<?php echo esc_attr($settings['form_styling']['placeholder_color'] ?? '#888888'); ?>">
                                            </div>
                                        </div>
                                        
                                    </div>
                                    

                                    <div class="sf-settings-row">
                                        <div class="sf-settings-field sf-color-field">
                                            <label for="field_border"><?php esc_html_e('Field Border Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="field_border" value="<?php echo esc_attr($settings['form_styling']['field_border']); ?>">
                                                <input type="text" name="field_border" value="<?php echo esc_attr($settings['form_styling']['field_border']); ?>">
                                            </div>
                                        </div>
                                        <div class="sf-settings-field">
                                            <label for="input_border_radius"><?php esc_html_e('Border Radius', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-input-number-wrapper">
                                                <input type="number" id="input_border_radius" name="input_border_radius" value="<?php echo esc_attr($settings['form_styling']['input_border_radius'] ?? '4'); ?>" min="0" max="50">
                                                <span class="sf-unit">px</span>
                                            </div>
                                        </div>
                                    </div>

                                                                        
                                    <div class="sf-settings-row">
                                        <div class="sf-settings-field">
                                            <label for="form_padding"><?php esc_html_e('Padding', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-input-number-wrapper">
                                                <input type="number" id="form_padding" name="form_padding" value="<?php echo esc_attr($settings['form_styling']['form_padding'] ?? '20'); ?>" min="0" max="50">
                                                <span class="sf-unit">px</span>
                                            </div>
                                        </div>
                                        
                                        <div class="sf-settings-field">
                                            <label for="field_spacing"><?php esc_html_e('Spacing', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-input-number-wrapper">
                                                <input type="number" id="field_spacing" name="field_spacing" value="<?php echo esc_attr($settings['form_styling']['field_spacing'] ?? '15'); ?>" min="5" max="30">
                                                <span class="sf-unit">px</span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="sf-settings-label-separator">
                                        <h4><?php esc_html_e('Submit Button', 'sigmaforms-pro'); ?></h4>
                                    </div>
                                    <div class="sf-settings-row">
                                        <div class="sf-settings-field sf-color-field">
                                            <label for="button_color"><?php esc_html_e('Background Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="button_color" value="<?php echo esc_attr($settings['form_styling']['button_color']); ?>">
                                                <input type="text" name="button_color" value="<?php echo esc_attr($settings['form_styling']['button_color']); ?>">
                                            </div>
                                        </div>
                                        <div class="sf-settings-field sf-color-field">
                                            <label for="button_text_color"><?php esc_html_e('Button Text Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="button_text_color" value="<?php echo esc_attr($settings['form_styling']['button_text_color'] ?? '#ffffff'); ?>">
                                                <input type="text" name="button_text_color" value="<?php echo esc_attr($settings['form_styling']['button_text_color'] ?? '#ffffff'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="sf-settings-row">

                                        <div class="sf-settings-field sf-color-field">
                                            <label for="button_hover_bg_color"><?php esc_html_e('Hover Background Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="button_hover_bg_color" value="<?php echo esc_attr($settings['form_styling']['button_hover_bg_color'] ?? '#1a5a96'); ?>">
                                                <input type="text" name="button_hover_bg_color" value="<?php echo esc_attr($settings['form_styling']['button_hover_bg_color'] ?? '#1a5a96'); ?>">
                                            </div>
                                        </div>

                                        <div class="sf-settings-field sf-color-field">
                                            <label for="button_hover_text_color"><?php esc_html_e('Hover Text Color', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-color-picker-wrapper">
                                                <input type="color" id="button_hover_text_color" value="<?php echo esc_attr($settings['form_styling']['button_hover_text_color'] ?? '#ffffff'); ?>">
                                                <input type="text" name="button_hover_text_color" value="<?php echo esc_attr($settings['form_styling']['button_hover_text_color'] ?? '#ffffff'); ?>">
                                            </div>
                                        </div>

                                    </div>

                                    <div class="sf-settings-field">
                                            <label for="button_border_radius"><?php esc_html_e('Border Radius', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-input-number-wrapper">
                                                <input type="number" id="button_border_radius" name="button_border_radius" value="<?php echo esc_attr($settings['form_styling']['button_border_radius'] ?? '4'); ?>" min="0" max="50">
                                                <span class="sf-unit">px</span>
                                            </div>
                                        </div>

                                    <div class="sf-settings-label-separator" style="margin-top: 20px;">
                                        <h4><?php esc_html_e('Common Settings', 'sigmaforms-pro'); ?></h4>
                                    </div>
                                    <div class="sf-settings-row">
                                        <div class="sf-settings-field">
                                            <label for="font_family"><?php esc_html_e('Font Family', 'sigmaforms-pro'); ?></label>
                                            <select id="font_family" name="font_family">
                                                <option value="inherit" <?php selected($settings['form_styling']['font_family'], 'inherit'); ?>><?php esc_html_e('Theme Default', 'sigmaforms-pro'); ?></option>
                                                <option value="Arial, sans-serif" <?php selected($settings['form_styling']['font_family'], 'Arial, sans-serif'); ?>>Arial</option>
                                                <option value="Helvetica, Arial, sans-serif" <?php selected($settings['form_styling']['font_family'], 'Helvetica, Arial, sans-serif'); ?>>Helvetica</option>
                                                <option value="Georgia, serif" <?php selected($settings['form_styling']['font_family'], 'Georgia, serif'); ?>>Georgia</option>
                                                <option value="'Times New Roman', Times, serif" <?php selected($settings['form_styling']['font_family'], "'Times New Roman', Times, serif"); ?>>Times New Roman</option>
                                                <option value="Verdana, Geneva, sans-serif" <?php selected($settings['form_styling']['font_family'], 'Verdana, Geneva, sans-serif'); ?>>Verdana</option>
                                            </select>
                                        </div>
                                        <div class="sf-settings-field">
                                            <label for="font_size"><?php esc_html_e('Font Size', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-input-number-wrapper">
                                                <input type="number" id="font_size" name="font_size" value="<?php echo esc_attr($settings['form_styling']['font_size'] ?? '16'); ?>" min="10" max="50">
                                                <span class="sf-unit">px</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- CAPTCHA Tab -->
                            <div id="recaptcha" class="sf-tab-content <?php echo $active_tab === 'recaptcha' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('CAPTCHA Protection', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Configure CAPTCHA services to protect your forms from spam and bots.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                                
                                <!-- Google reCAPTCHA -->
                                <div class="sf-captcha-config is-recaptcha">
                                    <div class="sf-captcha-header">
                                        <div class="sf-captcha-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-1.06 14.54L7.4 12l1.41-1.41 2.13 2.12 4.24-4.24 1.41 1.41-5.65 5.66z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-captcha-info">
                                            <h3><?php esc_html_e('Google reCAPTCHA', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Google\'s free CAPTCHA service that helps protect websites from spam and abuse.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-captcha-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="recaptcha_enabled" id="recaptcha_enabled" <?php checked($settings['recaptcha_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div id="recaptcha-settings" class="sf-captcha-settings" style="display: <?php echo ($settings['recaptcha_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <div class="sf-settings-field">
                                            <label for="recaptcha_version"><?php esc_html_e('reCAPTCHA Version', 'sigmaforms-pro'); ?></label>
                                            <div class="sf-toggle-field">
                                                 <span class="sf-toggle-label">
                                                    <?php esc_html_e('Use v2', 'sigmaforms-pro'); ?>
                                                </span>
                                                <label class="sf-toggle-switch">
                                                    <input type="checkbox" name="recaptcha_use_v3" id="recaptcha_use_v3" <?php checked($settings['recaptcha_use_v3'] ?? false); ?>>
                                                    <span class="sf-toggle-slider"></span>
                                                </label>
                                                <span class="sf-toggle-label">
                                                    <?php esc_html_e('Use v3 (Invisible)', 'sigmaforms-pro'); ?>
                                                </span>
                                            </div>
                                            <p class="description">
                                                <?php esc_html_e('Enable to use reCAPTCHA v3 which runs in the background. Disable to use v2 checkbox.', 'sigmaforms-pro'); ?>
                                            </p>
                                        </div>
                                        
                                        <div class="sf-settings-field">
                                            <label for="recaptcha_site_key"><?php esc_html_e('Site Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="recaptcha_site_key" name="recaptcha_site_key" value="<?php echo esc_attr($settings['recaptcha_site_key'] ?? ''); ?>">
                                        </div>
                                        
                                        <div class="sf-settings-field">
                                            <label for="recaptcha_secret_key"><?php esc_html_e('Secret Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="recaptcha_secret_key" name="recaptcha_secret_key" value="<?php echo esc_attr($settings['recaptcha_secret_key'] ?? ''); ?>">
                                            <p class="description">
                                                <?php printf(
                                                    /* translators: %s: URL to Google reCAPTCHA */
                                                    wp_kses_post(__('Get your reCAPTCHA keys from <a href="%s" target="_blank">Google reCAPTCHA</a>.', 'sigmaforms-pro')),
                                                    'https://www.google.com/recaptcha/admin'
                                                ); ?>
                                            </p>
                                        </div>
                                        
                                        <div class="sf-settings-field" id="recaptcha-v3-score-field" style="display: <?php echo ($settings['recaptcha_use_v3'] ?? false) ? 'block' : 'none'; ?>">
                                            <label for="recaptcha_v3_score_threshold"><?php esc_html_e('v3 Score Threshold', 'sigmaforms-pro'); ?></label>
                                            <input type="number" id="recaptcha_v3_score_threshold" name="recaptcha_v3_score_threshold" value="<?php echo esc_attr($settings['recaptcha_v3_score_threshold'] ?? '0.5'); ?>" min="0" max="1" step="0.1">
                                            <p class="description">
                                                <?php esc_html_e('Minimum score required (0.0 - 0.9). Higher scores indicate bots. Recommended: 0.5', 'sigmaforms-pro'); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- hCaptcha -->
                                <div class="sf-captcha-config is-hcaptcha">
                                    <div class="sf-captcha-header">
                                        <div class="sf-captcha-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-captcha-info">
                                            <h3><?php esc_html_e('hCaptcha', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Privacy-focused CAPTCHA service that respects user privacy and GDPR compliance.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-captcha-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="hcaptcha_enabled" id="hcaptcha_enabled" <?php checked($settings['hcaptcha_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div id="hcaptcha-settings" class="sf-captcha-settings" style="display: <?php echo ($settings['hcaptcha_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <div class="sf-settings-field">
                                            <label for="hcaptcha_site_key"><?php esc_html_e('Site Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="hcaptcha_site_key" name="hcaptcha_site_key" value="<?php echo esc_attr($settings['hcaptcha_site_key'] ?? ''); ?>">
                                        </div>
                                        
                                        <div class="sf-settings-field">
                                            <label for="hcaptcha_secret_key"><?php esc_html_e('Secret Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="hcaptcha_secret_key" name="hcaptcha_secret_key" value="<?php echo esc_attr($settings['hcaptcha_secret_key'] ?? ''); ?>">
                                            <p class="description">
                                                <?php printf(
                                                    /* translators: %s: URL to hCaptcha */
                                                    wp_kses_post(__('Get your hCaptcha keys from <a href="%s" target="_blank">hCaptcha</a>.', 'sigmaforms-pro')),
                                                    'https://www.hcaptcha.com/'
                                                ); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Cloudflare Turnstile -->
                                <div class="sf-captcha-config is-turnstile">
                                    <div class="sf-captcha-header">
                                        <div class="sf-captcha-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-captcha-info">
                                            <h3><?php esc_html_e('Cloudflare Turnstile', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Privacy-first CAPTCHA alternative that\'s invisible to users and free to use.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-captcha-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="turnstile_enabled" id="turnstile_enabled" <?php checked($settings['turnstile_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div id="turnstile-settings" class="sf-captcha-settings" style="display: <?php echo ($settings['turnstile_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <div class="sf-settings-field">
                                            <label for="turnstile_site_key"><?php esc_html_e('Site Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="turnstile_site_key" name="turnstile_site_key" value="<?php echo esc_attr($settings['turnstile_site_key'] ?? ''); ?>">
                                        </div>
                                        
                                        <div class="sf-settings-field">
                                            <label for="turnstile_secret_key"><?php esc_html_e('Secret Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="turnstile_secret_key" name="turnstile_secret_key" value="<?php echo esc_attr($settings['turnstile_secret_key'] ?? ''); ?>">
                                            <p class="description">
                                                <?php printf(
                                                    /* translators: %s: URL to Cloudflare Turnstile */
                                                    wp_kses_post(__('Get your Turnstile keys from <a href="%s" target="_blank">Cloudflare Dashboard</a>.', 'sigmaforms-pro')),
                                                    // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- Informational link to the user's Cloudflare dashboard, not asset offloading.
                                                    'https://dash.cloudflare.com/?to=/:account/turnstile'
                                                ); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- mTCaptcha -->
                                <div class="sf-captcha-config is-mtcaptcha">
                                    <div class="sf-captcha-header">
                                        <div class="sf-captcha-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-captcha-info">
                                            <h3><?php esc_html_e('mTCaptcha', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Visible challenge CAPTCHA that must be completed by the user before submission.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-captcha-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="mtcaptcha_enabled" id="mtcaptcha_enabled" <?php checked($settings['mtcaptcha_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div id="mtcaptcha-settings" class="sf-captcha-settings" style="display: <?php echo ($settings['mtcaptcha_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <div class="sf-settings-field">
                                            <label for="mtcaptcha_site_key"><?php esc_html_e('Site Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="mtcaptcha_site_key" name="mtcaptcha_site_key" value="<?php echo esc_attr($settings['mtcaptcha_site_key'] ?? ''); ?>">
                                        </div>

                                        <div class="sf-settings-field">
                                            <label for="mtcaptcha_private_key"><?php esc_html_e('Private Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="mtcaptcha_private_key" name="mtcaptcha_private_key" value="<?php echo esc_attr($settings['mtcaptcha_private_key'] ?? ''); ?>">
                                            <p class="description">
                                                <?php printf(
                                                    /* translators: %s: URL to mTCaptcha */
                                                    wp_kses_post(__('Get your mTCaptcha keys from <a href="%s" target="_blank">mTCaptcha</a>.', 'sigmaforms-pro')),
                                                    'https://www.mtcaptcha.com/'
                                                ); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- CleanTalk -->
                                <div class="sf-captcha-config is-cleantalk">
                                    <div class="sf-captcha-header">
                                        <div class="sf-captcha-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-captcha-info">
                                            <h3><?php esc_html_e('CleanTalk', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Advanced spam protection service that blocks spam without CAPTCHA challenges.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-captcha-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="cleantalk_enabled" id="cleantalk_enabled" <?php checked($settings['cleantalk_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div id="cleantalk-settings" class="sf-captcha-settings" style="display: <?php echo ($settings['cleantalk_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <div class="sf-settings-field">
                                            <label for="cleantalk_access_key"><?php esc_html_e('Access Key', 'sigmaforms-pro'); ?></label>
                                            <input type="text" id="cleantalk_access_key" name="cleantalk_access_key" value="<?php echo esc_attr($settings['cleantalk_access_key'] ?? ''); ?>">
                                            <p class="description">
                                                <?php printf(
                                                    /* translators: %s: URL to CleanTalk */
                                                    wp_kses_post(__('Get your CleanTalk access key from <a href="%s" target="_blank">CleanTalk Dashboard</a>.', 'sigmaforms-pro')),
                                                    'https://cleantalk.org/my/'
                                                ); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Webhooks Tab -->
                            <div id="webhooks" class="sf-tab-content <?php echo $active_tab === 'webhooks' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('Webhook Integrations', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Configure global webhook settings for form submissions. These settings will be applied to all forms unless overridden in individual form settings.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>
                                
                                <div id="webhooks-settings" class="sf-webhooks-settings">
                                    
                                    <!-- Google Sheets -->
                                    <div class="sf-webhook-config">
                                        <div class="sf-webhook-header">
                                            <div class="sf-webhook-icon">
                                                <svg viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                                                </svg>
                                            </div>
                                            <div class="sf-webhook-info-settings">
                                                <h3><?php esc_html_e('Google Sheets', 'sigmaforms-pro'); ?></h3>
                                                <p><?php esc_html_e('Send form submissions to Google Sheets automatically.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-webhook-toggle">
                                                <label class="sf-toggle-switch">
                                                    <input type="checkbox" name="webhook_google_sheets_enabled" <?php checked($settings['webhook_google_sheets_enabled'] ?? false); ?>>
                                                    <span class="sf-toggle-slider"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="sf-webhook-fields" style="display: <?php echo ($settings['webhook_google_sheets_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                            <div class="sf-settings-field">
                                                <label for="webhook_google_sheets_url"><?php esc_html_e('Google Apps Script Web App URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="webhook_google_sheets_url" name="webhook_google_sheets_url" value="<?php echo esc_attr($settings['webhook_google_sheets_url'] ?? ''); ?>" placeholder="https://script.google.com/macros/s/...">
                                                <p class="description"><?php esc_html_e('Enter the URL of your Google Apps Script web app that handles form submissions.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://developers.google.com/apps-script/guides/web" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Google Apps Script web app', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    

                                    
                                    <!-- Slack -->
                                    <div class="sf-webhook-config">
                                        <div class="sf-webhook-header">
                                            <div class="sf-webhook-icon">
                                                <svg viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M6 18c0 .55.45 1 1 1h1v-4H6v3zm0-5h4v-1H6v1zm0-2h4V9H6v2zm0-4h4V5H6v2zm5 12h1c.55 0 1-.45 1-1v-4h-2v4zm0-5h4v-1h-4v1zm0-2h4V9h-4v2zm0-4h4V5h-4v2z"/>
                                                </svg>
                                            </div>
                                            <div class="sf-webhook-info-settings">
                                                <h3><?php esc_html_e('Slack', 'sigmaforms-pro'); ?></h3>
                                                <p><?php esc_html_e('Send form notifications to Slack channels.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-webhook-toggle">
                                                <label class="sf-toggle-switch">
                                                    <input type="checkbox" name="webhook_slack_enabled" <?php checked($settings['webhook_slack_enabled'] ?? false); ?>>
                                                    <span class="sf-toggle-slider"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="sf-webhook-fields" style="display: <?php echo ($settings['webhook_slack_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                            <div class="sf-settings-field">
                                                <label for="webhook_slack_url"><?php esc_html_e('Slack Webhook URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="webhook_slack_url" name="webhook_slack_url" value="<?php echo esc_attr($settings['webhook_slack_url'] ?? ''); ?>" placeholder="https://hooks.slack.com/services/...">
                                                <p class="description"><?php esc_html_e('Enter your Slack incoming webhook URL.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://api.slack.com/messaging/webhooks" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Slack webhook', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="sf-settings-field">
                                                <label for="webhook_slack_channel"><?php esc_html_e('Slack Channel', 'sigmaforms-pro'); ?></label>
                                                <input type="text" id="webhook_slack_channel" name="webhook_slack_channel" value="<?php echo esc_attr($settings['webhook_slack_channel'] ?? ''); ?>" placeholder="#general">
                                                <p class="description"><?php esc_html_e('Enter the channel name (e.g., #general) or leave empty for default.', 'sigmaforms-pro'); ?></p>
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <!-- Discord -->
                                    <div class="sf-webhook-config">
                                        <div class="sf-webhook-header">
                                            <div class="sf-webhook-icon">
                                                <svg viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                                                </svg>
                                            </div>
                                            <div class="sf-webhook-info-settings">
                                                <h3><?php esc_html_e('Discord', 'sigmaforms-pro'); ?></h3>
                                                <p><?php esc_html_e('Send form notifications to Discord channels.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-webhook-toggle">
                                                <label class="sf-toggle-switch">
                                                    <input type="checkbox" name="webhook_discord_enabled" <?php checked($settings['webhook_discord_enabled'] ?? false); ?>>
                                                    <span class="sf-toggle-slider"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="sf-webhook-fields" style="display: <?php echo ($settings['webhook_discord_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                            <div class="sf-settings-field">
                                                <label for="webhook_discord_url"><?php esc_html_e('Discord Webhook URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="webhook_discord_url" name="webhook_discord_url" value="<?php echo esc_attr($settings['webhook_discord_url'] ?? ''); ?>" placeholder="https://discord.com/api/webhooks/...">
                                                <p class="description"><?php esc_html_e('Enter your Discord webhook URL from the channel settings.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://support.discord.com/hc/en-us/articles/228383668-Intro-to-Webhooks" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Discord webhook', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <!-- Telegram -->
                                    <div class="sf-webhook-config">
                                        <div class="sf-webhook-header">
                                            <div class="sf-webhook-icon">
                                                <svg viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.02-1.96 1.25-5.54 3.69-.52.36-1 .53-1.42.52-.47-.01-1.37-.26-2.03-.48-.82-.27-1.47-.42-1.42-.88.03-.24.27-.48.74-.74 2.87-1.25 4.79-2.08 5.76-2.5 2.78-1.17 3.36-1.37 3.75-1.38.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z"/>
                                                </svg>
                                            </div>
                                            <div class="sf-webhook-info-settings">
                                                <h3><?php esc_html_e('Telegram', 'sigmaforms-pro'); ?></h3>
                                                <p><?php esc_html_e('Send form notifications to Telegram channels or groups.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-webhook-toggle">
                                                <label class="sf-toggle-switch">
                                                    <input type="checkbox" name="webhook_telegram_enabled" <?php checked($settings['webhook_telegram_enabled'] ?? false); ?>>
                                                    <span class="sf-toggle-slider"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="sf-webhook-fields" style="display: <?php echo ($settings['webhook_telegram_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                            <div class="sf-settings-field">
                                                <label for="webhook_telegram_bot_token"><?php esc_html_e('Telegram Bot Token', 'sigmaforms-pro'); ?></label>
                                                <input type="text" id="webhook_telegram_bot_token" name="webhook_telegram_bot_token" value="<?php echo esc_attr($settings['webhook_telegram_bot_token'] ?? ''); ?>" placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz">
                                                <p class="description"><?php esc_html_e('Enter your Telegram bot token from @BotFather.', 'sigmaforms-pro'); ?></p>
                                                <div class="sf-field-help">
                                                    <a href="https://core.telegram.org/bots/api#sendmessage" target="_blank" class="sf-help-link">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('external'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('How to create Telegram bot and get chat ID', 'sigmaforms-pro'); ?>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="sf-settings-field">
                                                <label for="webhook_telegram_chat_id"><?php esc_html_e('Chat ID', 'sigmaforms-pro'); ?></label>
                                                <input type="text" id="webhook_telegram_chat_id" name="webhook_telegram_chat_id" value="<?php echo esc_attr($settings['webhook_telegram_chat_id'] ?? ''); ?>" placeholder="-1001234567890">
                                                <p class="description"><?php esc_html_e('Enter the chat ID where you want to receive notifications.', 'sigmaforms-pro'); ?></p>
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <!-- Custom Webhook -->
                                    <div class="sf-webhook-config">
                                        <div class="sf-webhook-header">
                                            <div class="sf-webhook-icon">
                                                <svg viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                                </svg>
                                            </div>
                                            <div class="sf-webhook-info-settings">
                                                <h3><?php esc_html_e('Custom Webhook', 'sigmaforms-pro'); ?></h3>
                                                <p><?php esc_html_e('Send form data to any custom webhook endpoint.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-webhook-toggle">
                                                <label class="sf-toggle-switch">
                                                    <input type="checkbox" name="webhook_custom_enabled" <?php checked($settings['webhook_custom_enabled'] ?? false); ?>>
                                                    <span class="sf-toggle-slider"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="sf-webhook-fields" style="display: <?php echo ($settings['webhook_custom_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                            <div class="sf-settings-field">
                                                <label for="webhook_custom_url"><?php esc_html_e('Webhook URL', 'sigmaforms-pro'); ?></label>
                                                <input type="url" id="webhook_custom_url" name="webhook_custom_url" value="<?php echo esc_attr($settings['webhook_custom_url'] ?? ''); ?>" placeholder="https://your-domain.com/webhook">
                                                <p class="description"><?php esc_html_e('Enter the URL where you want to send form data.', 'sigmaforms-pro'); ?></p>
                                            </div>
                                            <div class="sf-settings-field">
                                                <label for="webhook_custom_method"><?php esc_html_e('HTTP Method', 'sigmaforms-pro'); ?></label>
                                                <select id="webhook_custom_method" name="webhook_custom_method">
                                                    <option value="POST" <?php selected($settings['webhook_custom_method'] ?? 'POST', 'POST'); ?>><?php esc_html_e('POST', 'sigmaforms-pro'); ?></option>
                                                    <option value="PUT" <?php selected($settings['webhook_custom_method'] ?? 'POST', 'PUT'); ?>><?php esc_html_e('PUT', 'sigmaforms-pro'); ?></option>
                                                    <option value="PATCH" <?php selected($settings['webhook_custom_method'] ?? 'POST', 'PATCH'); ?>><?php esc_html_e('PATCH', 'sigmaforms-pro'); ?></option>
                                                </select>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Cloud Storage Tab -->
                            <div id="storage" class="sf-tab-content <?php echo $active_tab === 'storage' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('Cloud Storage Integration', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Connect cloud storage services to automatically save uploaded files. Files will be organized in folders: sigmaforms/YYYY/MM/', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>

                                <?php if (\SigmaForms\Plugin::is_license_valid()) : ?>
                                <!-- Google Drive -->
                                <div class="sf-webhook-config">
                                    <div class="sf-webhook-header">
                                        <div class="sf-webhook-icon">
                                            <svg viewBox="0 0 24 24" fill="currentColor">
                                                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-info-settings">
                                            <h3><?php esc_html_e('Google Drive', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Automatically upload form files to Google Drive.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="storage_google_drive_enabled" <?php checked($settings['storage_google_drive_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-fields" id="google-drive-connection" style="display: <?php echo ($settings['storage_google_drive_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <?php
                                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable
                                        $google_connected = !empty(get_option('sf_google_drive_access_token'));
                                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                                        if ($google_connected): 
                                        ?>
                                            <div class="sf-settings-field" style="margin-bottom: 15px;">
                                                <div style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #f0f9ff; border-left: 3px solid #46b450; border-radius: 4px;">
                                                    <svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg>
                                                    <span style="flex: 1; color: #00712b; font-weight: 500;"><?php esc_html_e('Connected to Google Drive', 'sigmaforms-pro'); ?></span>
                                                    <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-disconnect-google-drive">
                                                        <?php esc_html_e('Disconnect', 'sigmaforms-pro'); ?>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <div class="sf-settings-field">
                                                <label for="storage_google_drive_folder_structure">
                                                    <?php esc_html_e('Folder Structure', 'sigmaforms-pro'); ?>
                                                </label>
                                                <select id="storage_google_drive_folder_structure" name="storage_google_drive_folder_structure" class="sf-folder-structure-select">
                                                    <option value="year_month" <?php selected($settings['storage_google_drive_folder_structure'] ?? 'year_month', 'year_month'); ?>>
                                                        <?php esc_html_e('Year/Month (sigmaforms/YYYY/MM/)', 'sigmaforms-pro'); ?>
                                                    </option>
                                                    <option value="form_id" <?php selected($settings['storage_google_drive_folder_structure'] ?? 'year_month', 'form_id'); ?>>
                                                        <?php esc_html_e('Form ID (sigmaforms/form-{id}/)', 'sigmaforms-pro'); ?>
                                                    </option>
                                                    <option value="custom" <?php selected($settings['storage_google_drive_folder_structure'] ?? 'year_month', 'custom'); ?>>
                                                        <?php esc_html_e('Custom Folder Structure', 'sigmaforms-pro'); ?>
                                                    </option>
                                                </select>
                                                <p class="description" style="margin-top: 8px;">
                                                    <strong><?php esc_html_e('Choose how files should be organized in Google Drive:', 'sigmaforms-pro'); ?></strong><br>
                                                    • <strong><?php esc_html_e('Year/Month:', 'sigmaforms-pro'); ?></strong> <?php esc_html_e('Organizes files by upload date in a chronological structure (e.g., sigmaforms/2025/12/). Best for time-based organization.', 'sigmaforms-pro'); ?><br>
                                                    • <strong><?php esc_html_e('Form ID:', 'sigmaforms-pro'); ?></strong> <?php esc_html_e('Separates files by form in dedicated folders (e.g., sigmaforms/form-123/). Best when you have multiple forms and want to keep their files separate.', 'sigmaforms-pro'); ?><br>
                                                    • <strong><?php esc_html_e('Custom:', 'sigmaforms-pro'); ?></strong> <?php esc_html_e('Create your own folder structure using placeholders like {form_name}, {year}, {month}, etc. Offers maximum flexibility for your organization needs.', 'sigmaforms-pro'); ?>
                                                </p>
                                            </div>
                                            
                                            <div class="sf-settings-field sf-google-custom-folder" style="display: <?php echo ($settings['storage_google_drive_folder_structure'] ?? 'year_month') === 'custom' ? 'block' : 'none'; ?>;">
                                                <label for="storage_google_drive_custom_folder">
                                                    <?php esc_html_e('Custom Folder Path', 'sigmaforms-pro'); ?>
                                                </label>
                                                <input type="text" 
                                                    id="storage_google_drive_custom_folder" 
                                                    name="storage_google_drive_custom_folder" 
                                                    value="<?php echo esc_attr($settings['storage_google_drive_custom_folder'] ?? 'sigmaforms/{year}/{month}'); ?>" 
                                                    placeholder="sigmaforms/{year}/{month}">
                                                <p class="description" style="margin-top: 8px;">
                                                    <strong><?php esc_html_e('Available placeholders:', 'sigmaforms-pro'); ?></strong><br>
                                                    <code>{year}</code> - <?php esc_html_e('Current year (e.g., 2025)', 'sigmaforms-pro'); ?><br>
                                                    <code>{month}</code> - <?php esc_html_e('Current month with leading zero (e.g., 01, 12)', 'sigmaforms-pro'); ?><br>
                                                    <code>{day}</code> - <?php esc_html_e('Current day with leading zero (e.g., 01, 31)', 'sigmaforms-pro'); ?><br>
                                                    <code>{form_id}</code> - <?php esc_html_e('Form ID number', 'sigmaforms-pro'); ?><br>
                                                    <code>{form_name}</code> - <?php esc_html_e('Form name (sanitized)', 'sigmaforms-pro'); ?><br>
                                                    <?php esc_html_e('Example:', 'sigmaforms-pro'); ?> <code>forms/{form_name}/{year}-{month}</code>
                                                </p>
                                            </div>
                                        <?php else: ?>
                                            <div class="sf-settings-field">
                                                <button type="button" class="sf-btn sf-btn-primary sf-connect-google-drive">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512" height="16" width="16" style="fill: currentColor; margin-right: 8px;">
                                                        <path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"/>
                                                    </svg>
                                                    <?php esc_html_e('Sign in with Google', 'sigmaforms-pro'); ?>
                                                </button>
                                                <p class="description">
                                                    <?php esc_html_e('Click to connect your Google Drive account and authorize file uploads.', 'sigmaforms-pro'); ?>
                                                </p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- OneDrive -->
                                <div class="sf-webhook-config">
                                    <div class="sf-webhook-header">
                                        <div class="sf-webhook-icon">
                                            <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect x="2" y="6" width="28" height="20" rx="2" fill="#0078D4"/>
                                                <path d="M20 12C18.5 8.5 15.5 6 12 6C7.5 6 4 9.5 4 14c0 .3 0 .6.1.9-1.8.9-3.1 2.8-3.1 5.1 0 3.1 2.5 5.6 5.6 5.6h17.8c3.1 0 5.6-2.5 5.6-5.6 0-2.9-2.2-5.3-5-5.6-.3-2.2-1.5-4.1-3.5-5.5-.6-.5-1.5-.3-2 .3-.5.6-.3 1.5.3 2 1.2 1 2 2.4 2 4.1 0 .4.3.8.8.8 2.2 0 4 1.8 4 4 0 2.2-1.8 4-4 4H6.6c-2.2 0-4-1.8-4-4 0-1.9 1.3-3.5 3.1-3.9.5-.1.8-.5.8-1 0-.3 0-.6 0-.9 0-3.6 2.9-6.5 6.5-6.5 2.9 0 5.4 1.9 6.2 4.7.1.5.6.8 1.1.7 2.9-.3 5.4 1.9 5.7 4.7 0 .4.3.8.8.8 2.2 0 4 1.8 4 4z" fill="white"/>
                                                <circle cx="23" cy="23" r="7" fill="#1490DF"/>
                                                <path d="M23 18c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm2.8 3.8l-3.3 3.3c-.2.2-.6.2-.8 0l-1.6-1.6c-.2-.2-.2-.6 0-.8.2-.2.6-.2.8 0l1.2 1.2 2.9-2.9c.2-.2.6-.2.8 0 .2.2.2.6 0 .8z" fill="white"/>
                                            </svg>
                                        </div>
                                        <div class="sf-webhook-info-settings">
                                            <h3><?php esc_html_e('Microsoft OneDrive', 'sigmaforms-pro'); ?></h3>
                                            <p><?php esc_html_e('Automatically upload form files to OneDrive.', 'sigmaforms-pro'); ?></p>
                                        </div>
                                        <div class="sf-webhook-toggle">
                                            <label class="sf-toggle-switch">
                                                <input type="checkbox" name="storage_onedrive_enabled" <?php checked($settings['storage_onedrive_enabled'] ?? false); ?>>
                                                <span class="sf-toggle-slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="sf-webhook-fields" id="onedrive-connection" style="display: <?php echo ($settings['storage_onedrive_enabled'] ?? false) ? 'block' : 'none'; ?>">
                                        <?php
                                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable
                                        $onedrive_connected = !empty(get_option('sf_onedrive_access_token'));
                                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                                        if ($onedrive_connected): 
                                        ?>
                                            <div class="sf-settings-field" style="margin-bottom: 15px;">
                                                <div style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #f0f9ff; border-left: 3px solid #46b450; border-radius: 4px;">
                                                    <svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg>
                                                    <span style="flex: 1; color: #00712b; font-weight: 500;"><?php esc_html_e('Connected to OneDrive', 'sigmaforms-pro'); ?></span>
                                                    <button type="button" class="sf-btn sf-btn-secondary sf-btn-sm sf-disconnect-onedrive">
                                                        <?php esc_html_e('Disconnect', 'sigmaforms-pro'); ?>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <div class="sf-settings-field">
                                                <label for="storage_onedrive_folder_structure">
                                                    <?php esc_html_e('Folder Structure', 'sigmaforms-pro'); ?>
                                                </label>
                                                <select id="storage_onedrive_folder_structure" name="storage_onedrive_folder_structure" class="sf-folder-structure-select">
                                                    <option value="year_month" <?php selected($settings['storage_onedrive_folder_structure'] ?? 'year_month', 'year_month'); ?>>
                                                        <?php esc_html_e('Year/Month (sigmaforms/YYYY/MM/)', 'sigmaforms-pro'); ?>
                                                    </option>
                                                    <option value="form_id" <?php selected($settings['storage_onedrive_folder_structure'] ?? 'year_month', 'form_id'); ?>>
                                                        <?php esc_html_e('Form ID (sigmaforms/form-{id}/)', 'sigmaforms-pro'); ?>
                                                    </option>
                                                    <option value="custom" <?php selected($settings['storage_onedrive_folder_structure'] ?? 'year_month', 'custom'); ?>>
                                                        <?php esc_html_e('Custom Folder Structure', 'sigmaforms-pro'); ?>
                                                    </option>
                                                </select>
                                                <p class="description" style="margin-top: 8px;">
                                                    <strong><?php esc_html_e('Choose how files should be organized in OneDrive:', 'sigmaforms-pro'); ?></strong><br>
                                                    • <strong><?php esc_html_e('Year/Month:', 'sigmaforms-pro'); ?></strong> <?php esc_html_e('Organizes files by upload date in a chronological structure (e.g., sigmaforms/2025/12/). Best for time-based organization.', 'sigmaforms-pro'); ?><br>
                                                    • <strong><?php esc_html_e('Form ID:', 'sigmaforms-pro'); ?></strong> <?php esc_html_e('Separates files by form in dedicated folders (e.g., sigmaforms/form-123/). Best when you have multiple forms and want to keep their files separate.', 'sigmaforms-pro'); ?><br>
                                                    • <strong><?php esc_html_e('Custom:', 'sigmaforms-pro'); ?></strong> <?php esc_html_e('Create your own folder structure using placeholders like {form_name}, {year}, {month}, etc. Offers maximum flexibility for your organization needs.', 'sigmaforms-pro'); ?>
                                                </p>
                                            </div>
                                            
                                            <div class="sf-settings-field sf-onedrive-custom-folder" style="display: <?php echo ($settings['storage_onedrive_folder_structure'] ?? 'year_month') === 'custom' ? 'block' : 'none'; ?>;">
                                                <label for="storage_onedrive_custom_folder">
                                                    <?php esc_html_e('Custom Folder Path', 'sigmaforms-pro'); ?>
                                                </label>
                                                <input type="text" 
                                                    id="storage_onedrive_custom_folder" 
                                                    name="storage_onedrive_custom_folder" 
                                                    value="<?php echo esc_attr($settings['storage_onedrive_custom_folder'] ?? 'sigmaforms/{year}/{month}'); ?>" 
                                                    placeholder="sigmaforms/{year}/{month}">
                                                <p class="description" style="margin-top: 8px;">
                                                    <strong><?php esc_html_e('Available placeholders:', 'sigmaforms-pro'); ?></strong><br>
                                                    <code>{year}</code> - <?php esc_html_e('Current year (e.g., 2025)', 'sigmaforms-pro'); ?><br>
                                                    <code>{month}</code> - <?php esc_html_e('Current month with leading zero (e.g., 01, 12)', 'sigmaforms-pro'); ?><br>
                                                    <code>{day}</code> - <?php esc_html_e('Current day with leading zero (e.g., 01, 31)', 'sigmaforms-pro'); ?><br>
                                                    <code>{form_id}</code> - <?php esc_html_e('Form ID number', 'sigmaforms-pro'); ?><br>
                                                    <code>{form_name}</code> - <?php esc_html_e('Form name (sanitized)', 'sigmaforms-pro'); ?><br>
                                                    <?php esc_html_e('Example:', 'sigmaforms-pro'); ?> <code>forms/{form_name}/{year}-{month}</code>
                                                </p>
                                            </div>
                                        <?php else: ?>
                                            <div class="sf-settings-field">
                                                <button type="button" class="sf-btn sf-btn-primary sf-connect-onedrive">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" height="16" width="16" style="fill: currentColor; margin-right: 8px;">
                                                        <path d="M13.8 4.7c-.1-.1-.2-.1-.3-.2h-.1c-.1 0-.2-.1-.2-.1h-.1c-.1 0-.2 0-.3-.1h-.1c-.1 0-.2 0-.4 0h-.1c-.1 0-.2 0-.4 0h-.2c-.1 0-.1 0-.2.1h-.1c-.1 0-.2.1-.2.1h-.1c-.1 0-.2.1-.2.1l-7.2 4.1c-.3.2-.5.5-.5.9v8.2c0 .4.2.7.5.9l7.2 4.1c.1 0 .1.1.2.1h.1c.1 0 .2.1.2.1h.1c.1 0 .1 0 .2.1h.2c.1 0 .2 0 .4 0h.1c.1 0 .2 0 .4 0h.1c.1 0 .2 0 .3-.1h.1c.1 0 .2-.1.2-.1h.1c.1 0 .2-.1.3-.2l7.2-4.1c.3-.2.5-.5.5-.9V9.7c0-.4-.2-.7-.5-.9l-7.2-4.1zm-1.7 14.5l-5.8-3.3v-6.6l5.8 3.3v6.6zm.9-7.5l-5.8-3.3 5.8-3.3 5.8 3.3-5.8 3.3zm6.7 4.2l-5.8 3.3v-6.6l5.8-3.3v6.6z"/>
                                                    </svg>
                                                    <?php esc_html_e('Sign in with Microsoft', 'sigmaforms-pro'); ?>
                                                </button>
                                                <p class="description">
                                                    <?php esc_html_e('Click to connect your OneDrive account and authorize file uploads.', 'sigmaforms-pro'); ?>
                                                </p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Advanced Settings Tab -->
                            <div id="advanced" class="sf-tab-content <?php echo $active_tab === 'advanced' ? 'active' : ''; ?>">
                                <div class="sf-tab-header">
                                    <h2><?php esc_html_e('Advanced Settings', 'sigmaforms-pro'); ?></h2>
                                    <p class="description">
                                        <?php esc_html_e('Configure advanced settings for your forms.', 'sigmaforms-pro'); ?>
                                    </p>
                                </div>

                                <!-- Master Mode OAuth - No user configuration needed -->

                                <div class="sf-settings-section">
                                    <h3><?php esc_html_e('Data Cleanup', 'sigmaforms-pro'); ?></h3>
                                    <div class="sf-settings-field">
                                        <label for="cleanup_days">
                                            <?php esc_html_e('Automatically clean up submissions older than', 'sigmaforms-pro'); ?>
                                        </label>
                                        <div class="sf-input-number-wrapper">
                                            <input type="number" id="cleanup_days" name="cleanup_days" value="<?php echo esc_attr($settings['cleanup_days'] ?? 90); ?>" min="0" max="365">
                                            <span class="sf-unit"><?php esc_html_e('days', 'sigmaforms-pro'); ?></span>
                                        </div>
                                        <p class="description">
                                            <?php esc_html_e('Set to 0 to disable automatic cleanup.', 'sigmaforms-pro'); ?>
                                        </p>
                                    </div>

                                    <div class="sf-settings-field">
                                        <label for="views_retention_days">
                                            <?php esc_html_e('Automatically delete form view logs older than', 'sigmaforms-pro'); ?>
                                        </label>
                                        <div class="sf-input-number-wrapper">
                                            <input type="number" id="views_retention_days" name="views_retention_days" value="<?php echo esc_attr($settings['views_retention_days'] ?? 60); ?>" min="0" max="365">
                                            <span class="sf-unit"><?php esc_html_e('days', 'sigmaforms-pro'); ?></span>
                                        </div>
                                        <p class="description">
                                            <?php esc_html_e('A view log row is recorded every time a form is displayed, so this table grows quickly on busy sites. Analytics for the retained period are unaffected. Common values are 7, 30 or 60 days. Set to 0 to keep everything (not recommended on high traffic sites).', 'sigmaforms-pro'); ?>
                                        </p>
                                        <?php
                                        // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variables
                                        $sf_views_retention = isset($settings['views_retention_days']) ? (int) $settings['views_retention_days'] : 60;
                                        $sf_expired_views = \SigmaForms\Utils\Analytics::count_expired_views($sf_views_retention);
                                        // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
                                        if ($sf_expired_views > 0) :
                                        ?>
                                            <p class="description">
                                                <strong>
                                                    <?php
                                                    printf(
                                                        /* translators: %s: number of view log rows queued for deletion */
                                                        esc_html__('%s view log entries are older than this and will be removed by the next daily cleanup.', 'sigmaforms-pro'),
                                                        esc_html(number_format_i18n($sf_expired_views))
                                                    );
                                                    ?>
                                                </strong>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Export/Import Settings -->
                                <div class="sf-settings-section">
                                    <h3><?php esc_html_e('Export/Import Settings', 'sigmaforms-pro'); ?></h3>
                                    <p class="description">
                                        <?php esc_html_e('Export your current settings to a JSON file or import settings from a previously exported file.', 'sigmaforms-pro'); ?>
                                    </p>
                                    
                                    <div class="sf-export-import-grid">
                                        <!-- Export Settings Column -->
                                        <div class="sf-export-import-column">
                                            <div class="sf-settings-field">
                                                <label><?php esc_html_e('Export Settings', 'sigmaforms-pro'); ?></label>
                                                
                                                <div class="sf-export-options" style="margin-bottom: 15px;">
                                                    <label class="sf-toggle-label">
                                                        <div class="sf-toggle-switch">
                                                            <input type="checkbox" id="sf-export-include-forms" name="sf_export_include_forms" checked>
                                                            <span class="sf-toggle-slider"></span>
                                                        </div>
                                                        <?php esc_html_e('Include Generated Forms', 'sigmaforms-pro'); ?>
                                                    </label>
                                                    <p class="description" style="margin-top: 5px;">
                                                        <?php esc_html_e('When enabled, all your generated forms and their settings will be included in the export.', 'sigmaforms-pro'); ?>
                                                    </p>
                                                </div>
                                                
                                                <button type="button" id="sf-export-settings" class="sf-btn sf-btn-secondary">
                                                    <?php echo \SigmaForms\Admin\PageHeader::icon('download'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                    <?php esc_html_e('Export Settings', 'sigmaforms-pro'); ?>
                                                </button>
                                                <p class="description">
                                                    <?php esc_html_e('Download all SigmaForms settings as a JSON file.', 'sigmaforms-pro'); ?>
                                                </p>
                                            </div>
                                        </div>

                                        <!-- Import Settings Column -->
                                        <div class="sf-export-import-column">
                                            <div class="sf-settings-field">
                                                <label><?php esc_html_e('Import Settings', 'sigmaforms-pro'); ?></label>
                                                
                                                <div class="sf-export-options" style="margin-bottom: 15px;">
                                                    <label class="sf-toggle-label">
                                                        <div class="sf-toggle-switch">
                                                            <input type="checkbox" id="sf-import-include-forms" name="sf_export_include_forms" checked>
                                                            <span class="sf-toggle-slider"></span>
                                                        </div>
                                                        <?php esc_html_e('Include Generated Forms', 'sigmaforms-pro'); ?>
                                                    </label>
                                                    <p class="description" style="margin-top: 5px;">
                                                        <?php esc_html_e('When enabled, all your generated forms and their settings will be included in the export.', 'sigmaforms-pro'); ?>
                                                    </p>
                                                </div>
                                                
                                                <input type="file" id="sf-import-settings-file" accept=".json" style="display: none;">
                                                    <button type="button" id="sf-import-settings-btn" class="sf-btn sf-btn-secondary">
                                                        <?php echo \SigmaForms\Admin\PageHeader::icon('upload'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?>
                                                        <?php esc_html_e('Choose File', 'sigmaforms-pro'); ?>
                                                    </button>

                                                     <div id="sf-import-filename-wrapper" style="margin-top: 10px; display: none;">
                                                    <span id="sf-import-filename" style="color: #666; font-size: 13px; font-style: italic;"></span>
                                                </div>
                                                <p class="description" style="margin-top: 10px;">
                                                    <?php esc_html_e('Upload a previously exported settings file. Settings will be imported and saved automatically.', 'sigmaforms-pro'); ?>
                                                </p>
                                            </div>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                            
                            <div class="sf-settings-footer">
                                <button type="submit" name="submit" id="sf-save-settings-btn" class="sf-btn sf-btn-primary sf-save-button">
                                    <?php echo \SigmaForms\Admin\PageHeader::icon('check'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup from a fixed icon map. ?> <span><?php esc_html_e('Save Settings', 'sigmaforms-pro'); ?></span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Plugin Footer -->
    <div class="sf-plugin-footer">
        <div class="sf-footer-links">
            <a href="https://sigmaforms.ai/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro" target="_blank"><?php esc_html_e('Plugin Page', 'sigmaforms-pro'); ?></a>
            <span class="sf-footer-divider">|</span>
            <a href="https://bdthemes.com/all-knowledge-base-of-sigma-forms/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro" target="_blank"><?php esc_html_e('Documentation', 'sigmaforms-pro'); ?></a>
            <span class="sf-footer-divider">|</span>
            <a href="https://bdthemes.com/contact/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro" target="_blank"><?php esc_html_e('Contact Us', 'sigmaforms-pro'); ?></a>
            <span class="sf-footer-divider">|</span>
            <a href="https://bdthemes.com/support/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_SigmaForms_Pro" target="_blank"><?php esc_html_e('Support', 'sigmaforms-pro'); ?></a>
        </div>
        <div class="sf-footer-credits">
            <p><?php printf(
                /* translators: %1$s: Plugin name, %2$s: Plugin version */
                esc_html__('%1$s - Version %2$s', 'sigmaforms-pro'),
                '<strong>SigmaForms</strong>',
                esc_html(SF_VERSION)
            ); ?></p>
            <p><?php printf(
                /* translators: %1$s: Heart icon, %2$s: Company name */
                esc_html__('Made with %1$s by %2$s', 'sigmaforms-pro'),
                '<span class="sf-heart" style="color: #ff0000;">♥</span>',
                '<a href="https://bdthemes.com/" target="_blank" style="text-decoration: none;">BdThemes</a>'
            ); ?></p>
        </div>
    </div>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {

    /**
     * Show settings message using the same style as form editor
     */
    function showSettingsMessage(message, type) {
        // Remove any existing message
        $('.sf-settings-save-message').remove();

        // Create message element
        const $message = $('<div class="sf-settings-save-message"></div>');
        // Carry the message type so errors are not styled as successes.
        $message.addClass('is-' + (type || 'success'));
        $message.html(message);

        // Add type-specific styling if needed
        if (type === 'error') {
            $message.css('background', '#dc3232');
        } else if (type === 'info') {
            $message.css('background', '#2271b1');
        } else {
            $message.css('background', '#4CAF50');
        }

        // Add to body
        $('body').append($message);

        // Show message
        setTimeout(function () {
            $message.addClass('active');
        }, 100);

        // Auto-hide after 3 seconds
        setTimeout(function () {
            $message.removeClass('active');
            setTimeout(function () {
                $message.remove();
            }, 300);
        }, 3000);
    }
    
    // Toggle webhook fields when individual webhooks are enabled/disabled
    $('input[name^="webhook_"][name$="_enabled"]').on('change', function() {
        var webhookType = $(this).attr('name').replace('webhook_', '').replace('_enabled', '');
        var fieldsContainer = $(this).closest('.sf-webhook-config').find('.sf-webhook-fields');
        
        if ($(this).is(':checked')) {
            fieldsContainer.slideDown();
        } else {
            fieldsContainer.slideUp();
        }
    });

    // Export Settings
    $('#sf-export-settings').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.html();
        var includeForms = $('#sf-export-include-forms').is(':checked');
        
        $btn.prop('disabled', true).html('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> <?php esc_html_e('Exporting...', 'sigmaforms-pro'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'sf_export_settings',
                nonce: '<?php echo esc_js(wp_create_nonce('sf-admin-nonce')); ?>',
                include_forms: includeForms ? '1' : '0'
            },
            success: function(response) {
                if (response.success) {
                    // Create download link
                    var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(response.data.settings, null, 2));
                    var downloadAnchorNode = document.createElement('a');
                    downloadAnchorNode.setAttribute("href", dataStr);
                    downloadAnchorNode.setAttribute("download", response.data.filename);
                    document.body.appendChild(downloadAnchorNode);
                    downloadAnchorNode.click();
                    downloadAnchorNode.remove();
                    
                    // Show success message using the same notification style
                    var successMsg = includeForms 
                        ? '<?php echo esc_js(__('Settings and forms exported successfully!', 'sigmaforms-pro')); ?>'
                        : '<?php echo esc_js(__('Settings exported successfully!', 'sigmaforms-pro')); ?>';
                    showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg> ' + successMsg, 'success');
                } else {
                    showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || '<?php echo esc_js(__('Failed to export settings.', 'sigmaforms-pro')); ?>'), 'error');
                }
            },
            error: function() {
                showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> <?php esc_html_e('An error occurred while exporting settings.', 'sigmaforms-pro'); ?>', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Import Settings - File selection
    $('#sf-import-settings-btn').on('click', function() {
        $('#sf-import-settings-file').click();
    });

    $('#sf-import-settings-file').on('change', function() {
        var file = this.files[0];
        if (!file) {
            $('#sf-import-filename-wrapper').hide();
            $('#sf-import-filename').text('');
            return;
        }

        // Validate file type
        if (file.type !== 'application/json' && !file.name.endsWith('.json')) {
            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> <?php esc_html_e('Please select a valid JSON file.', 'sigmaforms-pro'); ?>', 'error');
            $('#sf-import-filename-wrapper').hide();
            $('#sf-import-filename').text('');
            return;
        }

        // Show selected filename
        $('#sf-import-filename').text(file.name);
        $('#sf-import-filename-wrapper').show();

        var reader = new FileReader();
        reader.onload = function(e) {
            try {
                var settings = JSON.parse(e.target.result);
                var includeForms = $('#sf-import-include-forms').is(':checked');
                
                // Show loading message
                showSettingsMessage('<svg class="sf-icon sf-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg> <?php esc_html_e('Importing settings...', 'sigmaforms-pro'); ?>', 'info');
                
                // Send to server
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sf_import_settings',
                        nonce: '<?php echo esc_js(wp_create_nonce('sf-admin-nonce')); ?>',
                        settings: JSON.stringify(settings),
                        include_forms: includeForms ? '1' : '0'
                    },
                    success: function(response) {
                        if (response.success) {
                            var message = response.data.message || '<?php echo esc_js(__('Settings imported and saved successfully! Reloading page...', 'sigmaforms-pro')); ?>';
                            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.4 2.4 2.4 4.6-5.1"/></svg> ' + message, 'success');
                            
                            // Reload page after 1.5 seconds to show updated settings
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> ' + (response.data.message || '<?php echo esc_js(__('Failed to import settings.', 'sigmaforms-pro')); ?>'), 'error');
                        }
                    },
                    error: function() {
                        showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> <?php esc_html_e('An error occurred while importing settings.', 'sigmaforms-pro'); ?>', 'error');
                    }
                });
            } catch (error) {
                showSettingsMessage('<svg class="sf-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10.3 3.9 2.5 17.5A2 2 0 0 0 4.2 20.5h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg> <?php esc_html_e('Invalid JSON file. Please check the file format.', 'sigmaforms-pro'); ?>', 'error');
            }
        };
        reader.readAsText(file);
    });
});
</script>