# Soflyy Addon Installer SDK

A lightweight SDK for Soflyy Pro plugins to install and manage free plugin dependencies from WordPress.org.

## Features

* **Auto Install**: Installs required free addons from WordPress.org
* **Version Check**: Verifies and enforces minimum version
* **Auto Activation**: Activates addons after install
* **Deactivation Lock**: Optional protection against accidental deactivation
* **Import Blocking**: Prevents imports when dependencies are missing (WP All Import hooks)
* **CLI Support**: WP-CLI compatibility with immediate dependency resolution
* **Multisite Support**: Handles network installs and permissions
* **Auto-Update Sync**: Copies update settings from pro to free plugins
* **Silent Operation**: Non-intrusive install process
* **Flexible Detection**: Supports version checks via constants or plugin headers

## Installation

This SDK is distributed as a private Composer package with per-plugin namespace isolation via [Strauss](https://github.com/BrianHenryIE/strauss).

### 1. Add to your plugin's `composer.json`:

```json
{
    "repositories": [
        {
            "type": "vcs",
            "url": "git@github.com:soflyy/pmxi-addon-installer-sdk.git"
        }
    ],
    "require": {
        "soflyy/addon-installer-sdk": "1.3.0"
    },
    "require-dev": {
        "brianhenryie/strauss": "^0.26"
    },
    "autoload": {
        "classmap": [
            "vendor-prefixed/"
        ]
    },
    "extra": {
        "strauss": {
            "target_directory": "vendor-prefixed/",
            "namespace_prefix": "YOUR_PREFIX_Vendor\\",
            "classmap_prefix": "YOUR_PREFIX_Vendor_",
            "packages": [
                "soflyy/addon-installer-sdk"
            ]
        }
    },
    "scripts": {
        "strauss": "vendor/bin/strauss",
        "post-install-cmd": "@strauss",
        "post-update-cmd": "@strauss"
    }
}
```

Replace `YOUR_PREFIX` with your plugin's constant prefix (e.g., `PMAE`, `PMAI`, `PMXI`, `PMXE`) and pin the SDK to an **exact released version**. Never use a caret or range constraint: a range lets a routine build silently absorb a new SDK tag that nobody reviewed or tested against your plugin. Consumers ship the SDK inside their release artifact, so the version selection must only ever change in a deliberate, reviewed PR (see "Updating the SDK" below).

Also exclude the unprefixed copy of the SDK from your production autoloader so only the prefixed class ships:

```json
{
    "autoload": {
        "exclude-from-classmap": [
            "vendor/soflyy/addon-installer-sdk/"
        ]
    }
}
```

### 2. Run Composer:

```bash
composer install
composer dump-autoload
```

Strauss runs automatically, creating `vendor-prefixed/` with the namespace-isolated SDK. If the SDK was installed from source, make sure no `.git` directory ends up inside `vendor-prefixed/` (set `"preferred-install": {"soflyy/addon-installer-sdk": "dist"}` in your config).

### 3. Commit `vendor-prefixed/` and `composer.lock` to your repo.

Routine builds must be lock-based (`composer install --no-dev`), never `composer update`, so a build can never change the SDK version on its own.

## Basic Usage

```php
use YOUR_PREFIX_Vendor\Soflyy\AddonInstaller\AddonInstaller;

$addon_installer = new AddonInstaller([
    'addon_name'           => 'WP All Import - ACF Add-On Free',
    'addon_slug'           => 'csv-xml-import-for-acf',
    'addon_author'         => 'Soflyy',
    'minimum_version'      => '1.0.4',
    'pro_plugin_name'      => 'WP All Import - ACF Add-On Pro',
    'pro_plugin_file'      => __FILE__,
    'textdomain'           => 'wp_all_import_acf_add_on',
    'version_constant'     => 'PMAI_VERSION',
    'edition_constant'     => 'PMAI_EDITION',
    'expected_edition'     => 'free',
    'operation_type'       => 'import',
    'disable_deactivation' => true,
    'support_url'          => 'https://www.wpallimport.com/support/',
]);

$addon_installer->install_addon_from_repository();
```

## Namespace Prefix Convention

Each consuming plugin uses its own prefix to avoid class collisions when multiple plugins are active:

| Plugin | Prefix |
|--------|--------|
| WP All Import Pro | `PMXI_Vendor\` |
| WP All Export Pro | `PMXE_Vendor\` |
| ACF Import Add-On Pro | `PMAI_Vendor\` |
| ACF Export Add-On Pro | `PMAE_Vendor\` |
| User Import Add-On Pro | `PMUI_Vendor\` |
| User Export Add-On Pro | `PMUE_Vendor\` |
| WooCommerce Import Add-On Pro | `PMWI_Vendor\` |

## Configuration Options

| Option | Type | Required | Description |
|--------|------|----------|-------------|
| addon_name | string | Yes | Display name of the free addon (e.g., 'ACF Add-On Free') |
| addon_slug | string | Yes | WordPress.org plugin slug (e.g., 'csv-xml-import-for-acf') |
| addon_author | string | Yes | Plugin author name for identification (e.g., 'Soflyy') |
| minimum_version | string | Yes | Minimum required version (e.g., '1.0.4') |
| pro_plugin_name | string | Yes | Name of your pro plugin (e.g., 'WP All Import - ACF Add-On Pro') |
| pro_plugin_file | string | Yes | Path to your pro plugin's main file (usually __FILE__) |
| textdomain | string | Yes | Text domain for translations |
| operation_type | string | No | 'import' or 'export' (default: 'import'). Selects the WP All Import or WP All Export hook set, option prefixes, scheduled-run detection, and CLI indicators |
| version_constant | string | No | Constant name that holds the addon version (e.g., 'PMAI_VERSION') |
| edition_constant | string | No | Constant name that holds the edition type (e.g., 'PMAI_EDITION') |
| expected_edition | string | No | Expected edition value (default: 'free') |
| free_plugin_file | string | No | Free plugin filename if different from plugin.php |
| disable_deactivation | bool | No | Whether to prevent deactivation of the free plugin (default: false) |
| send_email_alert | bool | No | Whether to send email alerts for failures (default: true) |
| support_url | string | No | Support page linked from failure emails (default: '') |

## Advanced Usage

### Operation Blocking

With `operation_type` 'import' (the default), the SDK hooks `pmxi_before_xml_import` and `pmxi_before_post_import` to block WP All Import operations when dependencies are missing. With `operation_type` 'export', it hooks `pmxe_before_export` and blocks WP All Export operations instead. Scheduled runs and WP-CLI are covered in both modes. The hooks are harmless for plugins outside the selected product (they simply never fire).

### CLI Support

Full WP-CLI compatibility with automatic dependency resolution before operations.

### Check Addon Status

```php
if (!$addon_installer->is_addon_up_to_date()) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>Please update the required addon.</p></div>';
    });
}
```

### Version Detection Methods

**Option 1: Constants (recommended)**

```php
'version_constant' => 'PMAI_VERSION',
'edition_constant' => 'PMAI_EDITION',
'expected_edition' => 'free'
```

**Option 2: Plugin headers**
Omit constants and detection will fall back to plugin headers automatically.

### Prevent Deactivation

```php
'disable_deactivation' => true
```

Disables the deactivate link in plugin list and prevents CLI deactivation.

### Email Notifications

```php
'send_email_alert' => true  // Default
```

Sends admin email alerts when installation fails.

### Multisite Support

* Detects network activation
* Applies addon activation site-wide
* Adds appropriate notices and checks

### Auto-Update Sync

Inherits auto-update settings from the pro plugin to its addon.

## Updating the SDK

Updating a consumer to a new SDK version is always its own reviewed PR, never a side effect of a routine build:

1. In this repo: commit and tag the new version (e.g., `git tag v1.3.0`)
2. In the consuming plugin: `composer require soflyy/addon-installer-sdk:X.Y.Z` with the new exact version
3. `composer install` (Strauss regenerates `vendor-prefixed/`)
4. Commit `composer.json`, `composer.lock`, and the regenerated `vendor-prefixed/` together as one PR
5. Test the plugin before merging

Routine builds in consumers stay `composer install --no-dev` from the committed lock and are unaffected by new tags here.

## Requirements

* PHP 7.4+
* Composer autoloader
* `install_plugins` and `activate_plugins` capabilities for automatic installation

## Troubleshooting

### Addon not installing

* Check slug and version on WordPress.org
* Confirm write permissions
* Verify user has install_plugins capability

### Version not detected

* Verify constants or plugin header info
* Ensure addon is active
* Check if constants are defined correctly

### Import operations blocked

* Confirm dependency is properly installed and active
