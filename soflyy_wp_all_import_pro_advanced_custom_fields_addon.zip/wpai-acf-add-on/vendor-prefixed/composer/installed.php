<?php return array (
  'root' => 
  array (
    'name' => 'soflyy/wpai-acf-add-on',
    'pretty_version' => 'dev-master',
    'version' => 'dev-master',
    'reference' => '2f072ebb1b65d11c46d6cdd6358a81e528ccd4b0',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'soflyy/addon-installer-sdk' => 
    array (
      'pretty_version' => 'v1.3.1',
      'version' => '1.3.1.0',
      'reference' => '92d1fd605c0126f3e284bbdba394249a39319316',
      'type' => 'library',
      'install_path' => __DIR__ . '/../soflyy/addon-installer-sdk',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);