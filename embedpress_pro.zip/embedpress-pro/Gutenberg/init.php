<?php
/**
 * Blocks Initializer
 *
 * Enqueue CSS/JS of all the blocks.
 *
 * @since   1.0.0
 * @package CGB
 */


use \Embedpress\Pro\Providers\Vimeo as VimeoPlugin;
use \Embedpress\Pro\Providers\Youtube as YoutubePlugin;
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue Gutenberg block assets for both frontend + backend.
 *
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
function embedpress_pro_blocks_cgb_block_assets() { // phpcs:ignore
	wp_enqueue_style(
		'embedpress_pro-cgb-style-css',
		EMBEDPRESS_PRO_PLUGIN_URL.'Gutenberg/dist/blocks.style.build.css',
		array( 'wp-editor' ),
		null
	);
}

// Hook: Frontend assets.
add_action( 'enqueue_block_assets', 'embedpress_pro_blocks_cgb_block_assets' );

/**
 * Enqueue Gutenberg block assets for backend editor.
 *
 * @uses {wp-blocks} for block type registration & related functions.
 * @uses {wp-element} for WP Element abstraction — structure of blocks.
 * @uses {wp-i18n} to internationalize the block's text.
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
function embedpress_pro_blocks_cgb_editor_assets() { // phpcs:ignore
	// Register block editor script for backend.
	wp_enqueue_script(
		'embedpress_pro-cgb-block-js',
		EMBEDPRESS_PRO_PLUGIN_URL.'Gutenberg/dist/blocks.build.js',
		// wp-hooks: Pro registers addFilter() against the free blocks' applyFilters
		// extension slots (Google Reviews Pro controls, lazy-load, etc.).
		// embedpress-blocks-editor: load AFTER the free block bundle so the blocks
		// are registered and wp.hooks is ready before Pro's filters register.
		array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-api-fetch', 'wp-is-shallow-equal', 'wp-editor', 'wp-components', 'wp-hooks', 'embedpress-blocks-editor' ),
		null,
		true
	);

	// Register block editor styles for backend.
	wp_enqueue_style(
		'embedpress_pro-cgb-block-editor-css',
		EMBEDPRESS_PRO_PLUGIN_URL.'Gutenberg/dist/blocks.editor.build.css',
		array( 'wp-edit-blocks' ),
		null
	);

	// Dynamic Source Pro controls (fbs-81736). Hand-authored standalone
	// IIFE — see dynamic-source.build.js. Shipped separately because the
	// legacy cgb-scripts/node-sass toolchain for Gutenberg/src can't run on
	// modern Node; the rest of the bundle is unaffected.
	wp_enqueue_script(
		'embedpress_pro-dynamic-source-js',
		EMBEDPRESS_PRO_PLUGIN_URL.'Gutenberg/dist/dynamic-source.build.js',
		array( 'embedpress_pro-cgb-block-js', 'wp-hooks', 'wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n' ),
		null,
		true
	);

	$youtube_options = YoutubePlugin::getOptions();
	$youtube_params = YoutubePlugin::getParams($youtube_options);
	$vimeo_options  = VimeoPlugin::getOptions();
	$vimeo_params = VimeoPlugin::getParams($vimeo_options);
	$elements = (array) get_option( EMBEDPRESS_PLG_NAME.":elements", []);
	$active_blocks = isset( $elements['gutenberg']) ? (array) $elements['gutenberg'] : [];
	wp_localize_script(
		'embedpress_pro-cgb-block-js',
		'embedpressProObj', // Array containing dynamic data for a JS Global.
		[
			'pluginDirPath' => plugin_dir_path( __DIR__ ),
			'pluginDirUrl'  => plugin_dir_url( __DIR__ ),
			'youtubeParams'	=> $youtube_params,
			'vimeoParams'	=> $vimeo_params,
			'active_blocks' => $active_blocks,
		]
	);
}

// Hook: Editor assets.
add_action( 'enqueue_block_editor_assets', 'embedpress_pro_blocks_cgb_editor_assets' );

add_filter('embedpress_document_block_powered_by', function ($powered_by_default) {
	// Respect the global settings value
	// Only override if user hasn't explicitly enabled it
	// If the global setting is enabled (true), respect it
	// Otherwise, default to false for Pro users
	return $powered_by_default;
});
