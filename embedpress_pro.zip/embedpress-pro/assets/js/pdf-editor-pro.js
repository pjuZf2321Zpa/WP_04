/**
 * EmbedPress Pro — PDF block editor: Pro viewer options.
 *
 * Free's PDF block holds the viewer options only Pro unlocks (print/download,
 * copy text, draw, default selection tool, default scrolling) at their
 * defaults through the `embedpress.pdf.lockedViewerDefaults` filter. With Pro
 * active the inspector shows the real controls, so nothing is held.
 */
(function (wp) {
    'use strict';

    if (!wp || !wp.hooks) return;

    wp.hooks.addFilter(
        'embedpress.pdf.lockedViewerDefaults',
        'embedpress-pro/pdf-viewer-options',
        function () {
            return {};
        }
    );
})(window.wp);
