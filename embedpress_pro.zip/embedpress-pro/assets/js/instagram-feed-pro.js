/**
 * EmbedPress Pro — Instagram feed: Carousel layout, media-type tabs and the
 * popup like / comment counts.
 *
 * Free's front.js / instafeed.js render the feed, the popup and "Load more",
 * and expose two neutral extension points this file uses:
 *
 *   - window.EmbedPressInstagram.popupStats(postData, icons) → HTML string
 *     appended to the popup's stats row.
 *   - document event `embedpress:instagram:feed-ready`
 *     (detail: { feed, reason: 'init' | 'loadmore' | 'elementor' }).
 *
 * The carousel markup/data attributes and the tab markup are printed by
 * includes/Filters/Instagram_Feed_Pro.php.
 */
(function () {
    'use strict';

    var registry = window.EmbedPressInstagram = window.EmbedPressInstagram || {};

    /* -------------------------------------------------------------- */
    /* Popup like / comment counts                                    */
    /* -------------------------------------------------------------- */

    registry.popupStats = function (post, icons, context) {
        var html = '';
        icons = icons || {};

        // instafeed.js's popup has always shown both counts.
        if (context === 'instafeed') {
            return '<div class="embedpress-inline"><a target="_blank" href="' + post.permalink + '">' + (icons.likeIcon || '') + ' ' + (post.like_count || 0) + '</a></div> <div\n                                class="embedpress-inline"><a target="_blank" href="' + post.permalink + '">' + (icons.commentsIcon || '') + ' ' + (post.comments_count || 0) + '</a></div>';
        }

        if (post.show_likes_count == 'true') {
            html += '\n                    <div class="embedpress-inline popup-like-button"><a target="_blank" href="' + post.permalink + '">' + (icons.likeIcon || '') + ' ' + (post.like_count || 0) + '</a></div> \n                ';
        }
        if (post.show_comments_count == 'true') {
            html += '\n                    <div class="embedpress-inline"><a target="_blank" href="' + post.permalink + '">' + (icons.commentsIcon || '') + ' ' + (post.comments_count || 0) + '</a></div>\n                ';
        }

        return html;
    };

    /* -------------------------------------------------------------- */
    /* Carousel layout                                                */
    /* -------------------------------------------------------------- */

    function initCarousel(wrapper) {
        if (!wrapper || wrapper.getAttribute('data-ep-ig-carousel') === '1') return;
        if (typeof window.CgCarousel !== 'function') return;

        var carouselId = wrapper.getAttribute('data-carouselid');
        if (!carouselId) return;

        var options;
        try {
            options = JSON.parse(wrapper.getAttribute('data-carousel-options') || '{}');
        } catch (e) {
            return;
        }
        if (!options || options.layout !== 'insta-carousel') return;

        wrapper.setAttribute('data-ep-ig-carousel', '1');

        var scope = '[data-carouselid="' + carouselId + '"]';

        if (options.arrows) {
            var btns = document.querySelector(scope + ' .cg-carousel__btns');
            if (btns) btns.classList.remove('hidden');
        }

        var carousel = new window.CgCarousel(scope + ' .embedpress-insta-container', {
            slidesPerView: options.slideshow,
            spacing: options.spacing,
            loop: options.loop,
            autoplay: options.autoplay,
            transitionSpeed: options.transitionspeed,
            autoplaySpeed: options.autoplayspeed,
            arrows: options.arrows,
            breakpoints: {
                0: { slidesPerView: 1 },
                768: { slidesPerView: Math.max(1, parseInt(options.slideshow, 10) - 1) },
                1024: { slidesPerView: Math.max(1, parseInt(options.slideshow, 10)) }
            }
        }, {});

        var next = document.querySelector(scope + ' #js-carousel__next-1');
        if (next) next.addEventListener('click', function () { carousel.next(); });

        var prev = document.querySelector(scope + ' #js-carousel__prev-1');
        if (prev) prev.addEventListener('click', function () { carousel.prev(); });
    }

    function initAllCarousels() {
        var wrappers = document.querySelectorAll('.ep-embed-content-wraper[data-carouselid], .ep-embed-content-wrapper[data-carouselid]');
        for (var i = 0; i < wrappers.length; i++) {
            initCarousel(wrappers[i]);
        }
    }

    /* -------------------------------------------------------------- */
    /* Media-type tabs                                                */
    /* -------------------------------------------------------------- */

    function showItems(feed, mediaType) {
        var items = feed.getElementsByClassName('insta-gallery-item');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            item.style.display = (mediaType === 'ALL' || item.getAttribute('data-media-type') === mediaType) ? 'block' : 'none';
        }
    }

    function activeType(feed) {
        var active = feed.querySelector('.posts-tab-options .tabs li.active');
        return active ? (active.getAttribute('data-media-type') || 'ALL') : 'ALL';
    }

    function initTabs(feed) {
        if (!feed || !feed.querySelector('.posts-tab-options')) return;

        // Re-apply the selected tab (new "Load more" items included).
        showItems(feed, activeType(feed));

        if (feed.getAttribute('data-ep-ig-tabs') === '1') return;
        feed.setAttribute('data-ep-ig-tabs', '1');

        feed.addEventListener('click', function (event) {
            var el = event.target && event.target.closest ? event.target.closest('.tabs li') : null;
            if (!el || !feed.contains(el)) return;

            var type = el.getAttribute('data-media-type');
            var loadMore = feed.querySelector('.load-more-button-container');
            if (loadMore) {
                if (type === 'VIDEO' || type === 'CAROUSEL_ALBUM') {
                    loadMore.style.display = 'none';
                } else if (type === 'ALL') {
                    loadMore.style.display = 'flex';
                }
            }

            if (el.classList.contains('active')) return;

            showItems(feed, type);
            var tabs = feed.querySelectorAll('.tabs li');
            for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove('active');
            el.classList.add('active');
        });
    }

    function initAllTabs() {
        var feeds = document.querySelectorAll('.ose-instagram-feed');
        for (var i = 0; i < feeds.length; i++) initTabs(feeds[i]);
    }

    /* -------------------------------------------------------------- */
    /* Wiring                                                         */
    /* -------------------------------------------------------------- */

    document.addEventListener('embedpress:instagram:feed-ready', function (e) {
        var feed = e && e.detail ? e.detail.feed : null;
        if (!feed) return;

        var root = feed.classList && feed.classList.contains('ose-instagram-feed')
            ? feed
            : (feed.querySelector ? feed.querySelector('.ose-instagram-feed') : null) || feed;
        initTabs(root);

        if (e.detail.reason === 'elementor') {
            initCarousel(feed.closest ? feed.closest('[data-carouselid]') : null);
        }
    });

    function boot() {
        initAllTabs();
        initAllCarousels();
    }

    // Feeds already in the DOM (free announced them before this file ran).
    initAllTabs();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
