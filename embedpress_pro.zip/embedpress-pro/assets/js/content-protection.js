/**
 * EmbedPress Pro — Content Protection unlock flow.
 *
 * Submits the password lock form printed by
 * Embedpress\Pro\Filters\Content_Protection_Pro to the
 * `lock_content_form_handler` AJAX action and swaps the decrypted embed in.
 *
 * After a successful unlock it dispatches
 *   document  'embedpress:content-unlocked'
 *   detail    { clientId, context, container, wrapper }
 * so free's front.js can re-initialise what the new markup needs
 * (YouTube channel gallery, NFT load-more, custom player, ads).
 *
 * Plain ES5 IIFE — Pro's legacy Gutenberg toolchain does not build this file.
 */
(function ($) {
    'use strict';

    if (!$) {
        return;
    }

    var cfg = window.embedpressContentProtection || {};

    function ajaxUrl() {
        if (cfg.ajaxurl) {
            return cfg.ajaxurl;
        }
        if (window.embedpressFrontendData && window.embedpressFrontendData.ajaxurl) {
            return window.embedpressFrontendData.ajaxurl;
        }
        return '/wp-admin/admin-ajax.php';
    }

    function notifyUnlocked(detail) {
        var ev;
        try {
            ev = new CustomEvent('embedpress:content-unlocked', { detail: detail });
        } catch (e) {
            ev = document.createEvent('CustomEvent');
            ev.initCustomEvent('embedpress:content-unlocked', false, false, detail);
        }
        document.dispatchEvent(ev);
    }

    function unlock(parentSel, form) {
        var $form = $(form);
        var clientId = $form.find('input[name="ep_client_id"]').val();
        var $pass = $form.find('input[name="pass_' + clientId + '"]');
        var password = ($pass.length ? $pass : $('input[name="pass_' + clientId + '"]')).val();
        var $postId = $form.find('input[name="post_id"]');
        var postId = ($postId.length ? $postId : $('input[name="post_id"]')).val();
        var $container = $form.closest('.password-form-container');
        var buttonText = $container.find('input[type="submit"]').val();
        var unlockingText = $form.data('unlocking-text');
        var sel = '#' + parentSel + '-' + clientId;

        $(sel + ' .password-form input[type="submit"]').val(unlockingText);

        $.post(ajaxUrl(), {
            action: 'lock_content_form_handler',
            client_id: clientId,
            password: password,
            post_id: postId
        }, function (response) {
            if (!response || !response.success) {
                $('#password-error_' + clientId).html(response && response.form).show();
                return;
            }

            if (!response.embedHtml) {
                $(sel + ' .password-form input[type="submit"]').val(buttonText);
                $(sel + ' .password-form input[type="password"]').val('');
                $container.find('.error-message').removeClass('hidden');
                return;
            }

            var target;

            if (parentSel === 'ep-elementor-content') {
                if ($('.ep-content-locked').has(sel).length) {
                    $('.ep-content-locked').removeClass('ep-content-locked');
                }
                $(sel + ' .ep-embed-content-wraper').html(response.embedHtml);
                $(sel).removeClass('ep-content-protection-enabled');
                target = $(sel)[0];
            } else {
                // Replace the content inside the wrapper, keeping the wrapper itself.
                var $wrapper = $(sel);
                var $parentWrapper = $wrapper.parent('.ep-embed-content-wraper');

                if ($parentWrapper.length > 0) {
                    $parentWrapper.html(response.embedHtml);
                } else {
                    $wrapper.html(response.embedHtml);
                }
                target = $parentWrapper.length > 0 ? $parentWrapper[0] : $wrapper[0];
            }

            notifyUnlocked({
                clientId: clientId,
                context: parentSel,
                container: $(sel)[0] || null,
                wrapper: target || null
            });
        }, 'json');
    }

    $(document).on('submit', '.ep-gutenberg-content .password-form, .ep-shortcode-content .password-form, .ep-elementor-content .password-form', function (e) {
        e.preventDefault();
        var $form = $(this);
        var parentSel = 'ep-gutenberg-content';
        if ($form.closest('.ep-elementor-content').length) {
            parentSel = 'ep-elementor-content';
        } else if ($form.closest('.ep-shortcode-content').length) {
            parentSel = 'ep-shortcode-content';
        }
        unlock(parentSel, this);
    });
})(window.jQuery);
