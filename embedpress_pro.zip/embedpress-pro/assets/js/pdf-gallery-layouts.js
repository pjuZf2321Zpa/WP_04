/**
 * EmbedPress Pro — PDF Gallery Carousel and Bookshelf layouts.
 *
 * Free's static/js/pdf-gallery.js renders the gallery, thumbnails and the
 * popup viewer, and knows only the Grid and Masonry layouts. Any other layout
 * is looked up in the shared `window.EmbedPressPdfGalleryLayouts` registry
 * (name => init(galleryEl)); this file registers `carousel` and `bookshelf`
 * there. The registry is a plain object so load order does not matter.
 *
 * Each init accepts either markup shape: the carousel structure saved by the
 * block / printed by the Pro markup filter, or the plain grid free falls back
 * to while no layout is registered.
 */
(function () {
    'use strict';

    var registry = window.EmbedPressPdfGalleryLayouts = window.EmbedPressPdfGalleryLayouts || {};

    var PREV_ICON = '<svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>';
    var NEXT_ICON = '<svg viewBox="0 0 24 24"><path d="M8.59 16.59L10 18l6-6-6-6-1.41 1.41L13.17 12z"/></svg>';

    /**
     * Turn a plain `.ep-pdf-gallery__grid` into the carousel structure the
     * Carousel module drives. No-op when the carousel markup already exists.
     */
    function ensureCarouselMarkup(gallery) {
        if (gallery.querySelector('.ep-pdf-gallery__carousel')) return;

        var grid = gallery.querySelector('.ep-pdf-gallery__grid');
        if (!grid) return;

        var carousel = document.createElement('div');
        carousel.className = 'ep-pdf-gallery__carousel';
        var track = document.createElement('div');
        track.className = 'ep-pdf-gallery__carousel-track';

        Array.prototype.slice.call(grid.querySelectorAll('.ep-pdf-gallery__item')).forEach(function (item) {
            track.appendChild(item);
        });

        carousel.appendChild(track);

        var prev = document.createElement('button');
        prev.className = 'ep-pdf-gallery__carousel-prev';
        prev.setAttribute('aria-label', 'Previous');
        prev.innerHTML = PREV_ICON;
        var next = document.createElement('button');
        next.className = 'ep-pdf-gallery__carousel-next';
        next.setAttribute('aria-label', 'Next');
        next.innerHTML = NEXT_ICON;
        var dots = document.createElement('div');
        dots.className = 'ep-pdf-gallery__carousel-dots';

        carousel.appendChild(prev);
        carousel.appendChild(next);
        carousel.appendChild(dots);

        grid.parentNode.replaceChild(carousel, grid);
    }

    // =========================================
    // Carousel
    // =========================================
    var Carousel = {
        init: function (gallery) {
            var carouselEl = gallery.querySelector('.ep-pdf-gallery__carousel');
            if (!carouselEl) return;

            var track = carouselEl.querySelector('.ep-pdf-gallery__carousel-track');
            var items = carouselEl.querySelectorAll('.ep-pdf-gallery__item');
            var prevBtn = carouselEl.querySelector('.ep-pdf-gallery__carousel-prev');
            var nextBtn = carouselEl.querySelector('.ep-pdf-gallery__carousel-next');
            var dotsContainer = carouselEl.querySelector('.ep-pdf-gallery__carousel-dots');

            if (!track || !items.length) return;

            var options;
            try {
                options = JSON.parse(gallery.dataset.carouselOptions || '{}');
            } catch (e) {
                options = {};
            }

            var slidesPerView = options.slidesPerView || 3;
            var gap = parseInt(gallery.dataset.gap) || 20;
            var loop = options.loop !== false;
            var autoplay = options.autoplay || false;
            var autoplaySpeed = options.autoplaySpeed || 3000;
            var showDots = options.dots || false;
            var currentIndex = 0;
            var totalSlides = items.length;
            var autoplayTimer = null;

            // Responsive slides per view
            function getSlidesPerView() {
                var w = window.innerWidth;
                if (w <= 767) return 1;
                if (w <= 1024) return Math.min(slidesPerView, 2);
                return slidesPerView;
            }

            function updateLayout() {
                var spv = getSlidesPerView();
                var containerWidth = carouselEl.offsetWidth;
                var slideWidth = (containerWidth - gap * (spv - 1)) / spv;

                items.forEach(function (item) {
                    item.style.width = slideWidth + 'px';
                    item.style.marginRight = gap + 'px';
                });

                // Last item no margin
                if (items.length) {
                    items[items.length - 1].style.marginRight = '0';
                }

                goTo(currentIndex, false);
            }

            function goTo(index, animate) {
                var spv = getSlidesPerView();
                var maxIndex = Math.max(0, totalSlides - spv);

                if (loop) {
                    if (index > maxIndex) index = 0;
                    if (index < 0) index = maxIndex;
                } else {
                    index = Math.max(0, Math.min(index, maxIndex));
                }

                currentIndex = index;

                var containerWidth = carouselEl.offsetWidth;
                var slideWidth = (containerWidth - gap * (spv - 1)) / spv;
                var offset = index * (slideWidth + gap);

                track.style.transition = animate !== false ? 'transform 0.4s ease' : 'none';
                track.style.transform = 'translateX(-' + offset + 'px)';

                updateDots();
                updateArrows();
            }

            function updateArrows() {
                if (!prevBtn || !nextBtn) return;
                if (loop) return;
                var spv = getSlidesPerView();
                var maxIndex = Math.max(0, totalSlides - spv);
                prevBtn.classList.toggle('ep-hidden', currentIndex <= 0);
                nextBtn.classList.toggle('ep-hidden', currentIndex >= maxIndex);
            }

            function updateDots() {
                if (!dotsContainer || !showDots) return;
                var spv = getSlidesPerView();
                var totalDots = Math.max(1, totalSlides - spv + 1);

                dotsContainer.innerHTML = '';
                for (var i = 0; i < totalDots; i++) {
                    var dot = document.createElement('button');
                    dot.className = 'ep-pdf-gallery__carousel-dot' + (i === currentIndex ? ' active' : '');
                    dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
                    (function (idx) {
                        dot.addEventListener('click', function () { goTo(idx, true); });
                    })(i);
                    dotsContainer.appendChild(dot);
                }
            }

            function startAutoplay() {
                if (!autoplay) return;
                stopAutoplay();
                autoplayTimer = setInterval(function () {
                    goTo(currentIndex + 1, true);
                }, autoplaySpeed);
            }

            function stopAutoplay() {
                if (autoplayTimer) {
                    clearInterval(autoplayTimer);
                    autoplayTimer = null;
                }
            }

            // Event listeners
            if (prevBtn) {
                prevBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    goTo(currentIndex - 1, true);
                    stopAutoplay();
                    startAutoplay();
                });
            }
            if (nextBtn) {
                nextBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    goTo(currentIndex + 1, true);
                    stopAutoplay();
                    startAutoplay();
                });
            }

            // Touch/swipe support
            var touchStartX = 0;
            var touchDiff = 0;
            track.addEventListener('touchstart', function (e) {
                touchStartX = e.touches[0].clientX;
                stopAutoplay();
            }, { passive: true });
            track.addEventListener('touchmove', function (e) {
                touchDiff = e.touches[0].clientX - touchStartX;
            }, { passive: true });
            track.addEventListener('touchend', function () {
                if (Math.abs(touchDiff) > 50) {
                    if (touchDiff < 0) goTo(currentIndex + 1, true);
                    else goTo(currentIndex - 1, true);
                }
                touchDiff = 0;
                startAutoplay();
            });

            // Mouse drag support (desktop swipe)
            var mouseDown = false;
            var mouseStartX = 0;
            var mouseDiff = 0;
            track.addEventListener('mousedown', function (e) {
                mouseDown = true;
                mouseStartX = e.clientX;
                mouseDiff = 0;
                track.style.cursor = 'grabbing';
                stopAutoplay();
                e.preventDefault();
            });
            track.addEventListener('mousemove', function (e) {
                if (!mouseDown) return;
                mouseDiff = e.clientX - mouseStartX;
            });
            track.addEventListener('mouseup', function () {
                if (!mouseDown) return;
                mouseDown = false;
                track.style.cursor = '';
                if (Math.abs(mouseDiff) > 50) {
                    if (mouseDiff < 0) goTo(currentIndex + 1, true);
                    else goTo(currentIndex - 1, true);
                }
                mouseDiff = 0;
                startAutoplay();
            });
            track.addEventListener('mouseleave', function () {
                if (!mouseDown) return;
                mouseDown = false;
                track.style.cursor = '';
                if (Math.abs(mouseDiff) > 50) {
                    if (mouseDiff < 0) goTo(currentIndex + 1, true);
                    else goTo(currentIndex - 1, true);
                }
                mouseDiff = 0;
            });

            window.addEventListener('resize', function () { updateLayout(); });

            // Init
            updateLayout();
            if (showDots) updateDots();
            startAutoplay();
        }
    };

    // =========================================
    // Bookshelf — multi-row layout
    // =========================================
    var Bookshelf = {
        DEFAULT_BOOKS_PER_SHELF: 5,

        _getPerShelf: function (gallery) {
            var w = window.innerWidth;
            if (w <= 767) {
                return parseInt(gallery.dataset.columnsMobile, 10) || 1;
            } else if (w <= 1024) {
                return parseInt(gallery.dataset.columnsTablet, 10) || 2;
            }
            return parseInt(gallery.dataset.columns, 10) || this.DEFAULT_BOOKS_PER_SHELF;
        },

        _buildRows: function (gallery, container, items) {
            var perShelf = this._getPerShelf(gallery);

            // Store current perShelf to avoid unnecessary rebuilds
            if (container._lastPerShelf === perShelf) return;
            container._lastPerShelf = perShelf;

            // Clear existing rows
            container.innerHTML = '';

            // Chunk items into rows
            for (var i = 0; i < items.length; i += perShelf) {
                var row = document.createElement('div');
                row.className = 'ep-pdf-gallery__shelf-row';

                var chunk = items.slice(i, i + perShelf);
                for (var j = 0; j < chunk.length; j++) {
                    row.appendChild(chunk[j]);
                }

                container.appendChild(row);
            }
        },

        init: function (gallery) {
            var carousel = gallery.querySelector('.ep-pdf-gallery__carousel');
            var container = gallery.querySelector('.ep-pdf-gallery__bookshelf-container');
            var items;

            if (carousel) {
                var track = carousel.querySelector('.ep-pdf-gallery__carousel-track');
                if (!track) return;

                items = Array.prototype.slice.call(track.querySelectorAll('.ep-pdf-gallery__item'));
                if (!items.length) return;

                // Create bookshelf container replacing carousel
                container = document.createElement('div');
                container.className = 'ep-pdf-gallery__bookshelf-container';
                carousel.parentNode.replaceChild(container, carousel);
            } else if (container) {
                items = Array.prototype.slice.call(container.querySelectorAll('.ep-pdf-gallery__item'));
                if (!items.length) return;
            } else {
                return;
            }

            // Store items reference for resize rebuilds
            gallery._bookshelfItems = items;
            gallery._bookshelfContainer = container;

            var self = this;
            self._buildRows(gallery, container, items);

            // Rebuild rows on resize for responsive columns
            if (!gallery._bookshelfResizeListener) {
                var resizeTimer;
                gallery._bookshelfResizeListener = function () {
                    clearTimeout(resizeTimer);
                    resizeTimer = setTimeout(function () {
                        self._buildRows(gallery, gallery._bookshelfContainer, gallery._bookshelfItems);
                    }, 150);
                };
                window.addEventListener('resize', gallery._bookshelfResizeListener);
            }
        }
    };


    registry.carousel = function (gallery) {
        ensureCarouselMarkup(gallery);
        Carousel.init(gallery);
    };

    registry.bookshelf = function (gallery) {
        // Bookshelf builds its shelves from the carousel track's items.
        ensureCarouselMarkup(gallery);
        Bookshelf.init(gallery);
    };

    // Let free re-run layouts for galleries it already rendered as a grid
    // fallback (only happens if this file loaded after free initialised).
    try {
        document.dispatchEvent(new CustomEvent('embedpress:pdf-gallery-layouts'));
    } catch (e) { /* very old browsers: galleries keep the grid fallback */ }
})();
