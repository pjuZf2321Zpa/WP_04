/**
 * EmbedPress Pro — YouTube layouts (frontend, block editor, Elementor).
 *
 * 1. Playlist layouts Library / Spotlight / Cinema / Magazine. Registered on
 *    free's playlist engine (static/js/ep-yt-queue.js) through
 *    window.EmbedPressYoutubePlaylist.registerLayout(), which supplies
 *    click-to-swap, infinite scroll, loop / shuffle and auto-advance. This
 *    file adds each layout's selector table and its extras: hero title /
 *    description swap (Spotlight, Magazine), the Library modal player, the
 *    Cinema overlay queue + prev / next playback buttons, and Magazine's
 *    read-more toggle. Markup: includes/Filters/YoutubePlaylist.php.
 * 2. Channel Carousel slider + video popup for Grid / Carousel cards.
 *    Markup: includes/Filters/Youtube.php.
 *
 * Moved verbatim from the free plugin (static/js/ep-yt-queue.js and
 * static/js/front.js). Plain ES5 IIFE — no build step.
 */
(function () {
    'use strict';

    /* ------------------------------------------------------------------
     * 1. Playlist layouts
     * ------------------------------------------------------------------ */

    // Per-layout selector tables — keep markup contracts in one place.
    var SELECTORS = {
        // Library: no inline player. Clicking a card opens the modal.
        library: {
            iframe:     '.ep-yt-library__modal-iframe',
            list:       '.ep-yt-library__grid',
            item:       '.ep-yt-library__card',
            activeItem: '.ep-yt-library__card.is-active',
            loader:     '.ep-yt-library__loader',
            modal:      '.ep-yt-library__modal',
            modalClose: '.ep-yt-library__modal-close',
            posCurrent: '.ep-yt-library__position-current',
            scrollAxis: 'y'
        },
        spotlight: {
            iframe:     '.ep-yt-spotlight__iframe',
            list:       '.ep-yt-spotlight__rail',
            item:       '.ep-yt-spotlight__rail-card',
            activeItem: '.ep-yt-spotlight__rail-card.is-active',
            loader:     '.ep-yt-spotlight__loader',
            loopBtn:    '.ep-yt-spotlight__loop',
            shuffleBtn: '.ep-yt-spotlight__shuffle',
            posCurrent: '.ep-yt-spotlight__position-current',
            heroTitle:  '.ep-yt-spotlight__hero-title',
            heroDesc:   '.ep-yt-spotlight__hero-desc',
            scrollAxis: 'y'
        },
        cinema: {
            iframe:     '.ep-yt-cinema__iframe',
            list:       '.ep-yt-cinema__items',
            item:       '.ep-yt-cinema__item',
            activeItem: '.ep-yt-cinema__item.is-active',
            loader:     '.ep-yt-cinema__loader',
            loopBtn:    '.ep-yt-cinema__loop',
            shuffleBtn: '.ep-yt-cinema__shuffle',
            posCurrent: '.ep-yt-cinema__position-current',
            playPrev:     '.ep-yt-cinema__prev',
            playNext:     '.ep-yt-cinema__next',
            overlayOpen:  '.ep-yt-cinema__open-queue',
            overlayClose: '.ep-yt-cinema__close-queue',
            overlay:      '.ep-yt-cinema__overlay',
            scrollAxis: 'y'
        },
        magazine: {
            iframe:     '.ep-yt-magazine__iframe',
            list:       '.ep-yt-magazine__rail',
            item:       '.ep-yt-magazine__rail-item',
            activeItem: '.ep-yt-magazine__rail-item.is-active',
            loader:     '.ep-yt-magazine__loader',
            loopBtn:    '.ep-yt-magazine__loop',
            shuffleBtn: '.ep-yt-magazine__shuffle',
            posCurrent: '.ep-yt-magazine__position-current',
            heroTitle:  '.ep-yt-magazine__hero-title',
            heroDesc:   '.ep-yt-magazine__hero-desc',
            readMore:   '.ep-yt-magazine__readmore',
            scrollAxis: 'y'
        }
    };

    // Click-to-swap extras, run after free has swapped the video.
    function onItemClick(root, sel, state, item, h) {
        var $ = h.$;
        // Layouts that have a "hero" area (Spotlight, Magazine) promote
        // the clicked item's title + description into that area.
        if (sel.heroTitle || sel.heroDesc) {
            var titleEl = sel.heroTitle ? $(root, sel.heroTitle) : null;
            var descEl  = sel.heroDesc  ? $(root, sel.heroDesc)  : null;
            if (titleEl) {
                var t = item.getAttribute('data-title') || '';
                if (t) titleEl.textContent = t;
            }
            if (descEl) {
                var d = item.getAttribute('data-description') || '';
                if (d !== '') descEl.textContent = d;
            }
        }
        // Library: open the modal player on click.
        if (sel.modal && state.layout === 'library') {
            var modal = $(root, sel.modal);
            if (modal) modal.hidden = false;
        }
    }

    // Cinema overlay queue + Library modal close wiring.
    function attachLayoutExtras(root, sel, state, h) {
        var $ = h.$;
        if (state.layout === 'cinema') {
            var openBtn  = $(root, sel.overlayOpen);
            var closeBtn = $(root, sel.overlayClose);
            var overlay  = $(root, sel.overlay);
            if (openBtn && overlay) openBtn.addEventListener('click', function () { overlay.classList.add('is-open'); });
            if (closeBtn && overlay) closeBtn.addEventListener('click', function () { overlay.classList.remove('is-open'); });
        }
        if (state.layout === 'library') {
            var modal = $(root, sel.modal);
            var close = $(root, sel.modalClose);
            if (close && modal) close.addEventListener('click', function () { modal.hidden = true; });
            if (modal) modal.addEventListener('click', function (event) {
                if (event.target === modal) modal.hidden = true; // backdrop click
            });
        }
        if (state.layout === 'magazine') {
            var more = $(root, sel.readMore);
            var desc = $(root, sel.heroDesc);
            if (more && desc) more.addEventListener('click', function () {
                desc.classList.toggle('is-expanded');
                more.textContent = desc.classList.contains('is-expanded')
                    ? (more.getAttribute('data-collapse-label') || 'Show less')
                    : (more.getAttribute('data-expand-label')   || 'Read more');
            });
        }
    }

    // Playback prev/next buttons (cinema): step the active video backward /
    // forward through the playlist, reusing the same cursor model as auto-loop.
    // Distinct from theatre's nav buttons, which scroll the card strip.
    function attachPlaybackNavButtons(root, sel, state, h) {
        var $ = h.$, $$ = h.$$, visualIndex = h.visualIndex, playByIndex = h.playByIndex;
        var prev = sel.playPrev ? $(root, sel.playPrev) : null;
        var next = sel.playNext ? $(root, sel.playNext) : null;
        function step(delta) {
            var items = $$(root, sel.item);
            if (!items.length) return;
            var active = $(root, sel.activeItem);
            state.cursor = active ? visualIndex(root, sel, active) : state.cursor;
            var target = state.cursor + delta;
            if (target >= items.length) target = state.loop ? 0 : items.length - 1;
            if (target < 0) target = state.loop ? items.length - 1 : 0;
            state.cursor = target;
            playByIndex(root, sel, target, state);
        }
        if (prev) prev.addEventListener('click', function () { step(-1); });
        if (next) next.addEventListener('click', function () { step(1); });
    }

    function init(root, sel, state, h) {
        attachLayoutExtras(root, sel, state, h);
        attachPlaybackNavButtons(root, sel, state, h);
    }

    var api = window.EmbedPressYoutubePlaylist = window.EmbedPressYoutubePlaylist || {};
    Object.keys(SELECTORS).forEach(function (name) {
        var def = { selectors: SELECTORS[name], init: init, onItemClick: onItemClick };
        if (typeof api.registerLayout === 'function') {
            api.registerLayout(name, def);
        } else {
            // Free's engine not loaded yet — it adopts these when it runs.
            api.pending = api.pending || {};
            api.pending[name] = def;
        }
    });

    /* ------------------------------------------------------------------
     * 2. Channel Grid / Carousel
     * ------------------------------------------------------------------ */

    // Grid and Carousel cards open free's video popup (static/js/front.js).
    var channel = window.EmbedPressYoutubeChannel = window.EmbedPressYoutubeChannel || {};
    channel.popupItemSelectors = (channel.popupItemSelectors || []).concat(['.layout-grid .item', '.layout-carousel .item']);

    // Carousel slider.
    document.addEventListener('DOMContentLoaded', function () {
        var carousel = document.querySelector('.youtube-carousel');

        if (!carousel) {
            return;
        }

        var items = document.querySelectorAll('.item');
        var prevButton = document.querySelector('.preview');
        var nextButton = document.querySelector('.next');

        var itemsToShow = getItemsToShow(); // Determine items to show based on screen width

        var totalItems = items.length;
        var currentIndex = 0;

        function updateCarousel() {
            var offset = -currentIndex * (100 / itemsToShow);
            carousel.style.transform = 'translateX(' + offset + '%)';
        }

        function nextSlide() {
            var remainingItems = totalItems - (currentIndex + itemsToShow);
            if (remainingItems >= itemsToShow) {
                currentIndex += itemsToShow;
            } else if (remainingItems > 0) {
                currentIndex += remainingItems;
            } else {
                currentIndex = 0;
            }
            updateCarousel();
        }

        function prevSlide() {
            if (currentIndex > 0) {
                currentIndex -= itemsToShow;
                if (currentIndex < 0) {
                    currentIndex = 0;
                }
            } else {
                currentIndex = totalItems - itemsToShow;
            }
            updateCarousel();
        }

        if (nextButton) nextButton.addEventListener('click', nextSlide);
        if (prevButton) prevButton.addEventListener('click', prevSlide);

        // Optional: Autoplay
        var autoplay = false;
        var autoplayInterval = 3000; // Change the time as needed
        var autoplayId;

        function startAutoplay() {
            autoplayId = setInterval(nextSlide, autoplayInterval);
        }

        function stopAutoplay() {
            clearInterval(autoplayId);
        }

        if (autoplay) {
            startAutoplay();

            // Stop autoplay on mouseover, resume on mouseout
            carousel.addEventListener('mouseover', stopAutoplay);
            carousel.addEventListener('mouseout', startAutoplay);
        }

        // Handle responsive behavior
        window.addEventListener('resize', function () {
            itemsToShow = getItemsToShow();
            updateCarousel();

        });

        function getItemsToShow() {
            var width = window.innerWidth;
            if (width >= 1024) {
                return 3;
            } else if (width >= 768) {
                return 2;
            } else {
                return 1;
            }
        }
    });
})();
