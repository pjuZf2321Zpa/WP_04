/**
 * EmbedPress Pro — view/download count badge placement.
 *
 * Free's ep-view-count.js always places the badge below the embed. Each
 * embed carries its saved placement in `data-ep-count-position`
 * (below | below-center | below-right | above-left | above-center |
 * above-right); this script applies it:
 *
 *   - 'above-*' moves the badge before the embed (still outside it);
 *   - every non-default placement adds the `ep-view-count--pos-<position>`
 *     modifier class (styles live in free's embedpress.css).
 *
 * Free announces each new badge with an `embedpress:view-count:badge`
 * CustomEvent (detail: {embed, badge}) and keeps earlier ones in
 * window.EmbedPressViewCount.badges, so badges rendered before this script
 * loaded are handled too.
 *
 * Hand-written (no build step). Enqueued by
 * Embedpress\Pro\Filters\View_Count_Position_Pro after `embedpress-view-count`.
 */
(function () {
  'use strict';

  var POSITIONS = ['below-center', 'below-right', 'above-left', 'above-center', 'above-right'];

  function applyPosition(embed, badge) {
    if (!embed || !badge || badge.getAttribute('data-ep-pos-applied') === '1') return;
    badge.setAttribute('data-ep-pos-applied', '1');

    var pos = embed.getAttribute('data-ep-count-position');
    if (!pos || POSITIONS.indexOf(pos) === -1) return;

    if (pos.indexOf('above') === 0) {
      if (embed.tagName === 'IFRAME') {
        if (embed.parentNode) embed.parentNode.insertBefore(badge, embed);
      } else {
        embed.insertBefore(badge, embed.firstChild);
      }
    }
    badge.classList.add('ep-view-count--pos-' + pos);
  }

  document.addEventListener('embedpress:view-count:badge', function (e) {
    if (e && e.detail) applyPosition(e.detail.embed, e.detail.badge);
  });

  var api = window.EmbedPressViewCount;
  if (api && Array.isArray(api.badges)) {
    api.badges.forEach(function (entry) { applyPosition(entry.embed, entry.badge); });
  }
})();
