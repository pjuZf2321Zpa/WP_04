/**
 * EmbedPress Pro — Google Photos Grid / Masonry / Justify album modes and
 * their photo lightbox.
 *
 * Moved verbatim from the free plugin (front.js + gallery-justify.js), which
 * no longer renders these modes. The markup is printed by
 * includes/Filters/GooglePhotos.php (`embedpress/google_photos/gallery_html`).
 */

/* ---------------------------------------------------------------------- */
/* Photo lightbox                                                          */
/* ---------------------------------------------------------------------- */
jQuery(document).ready(function ($) {
    let currentIndex = 0;
    // Recomputed on each open so galleries rendered after this point
    // (e.g. inside an Elementor popup or loaded via AJAX) are handled too.
    let $photos = $();

    function createPopupGooglePhotos() {
        if ($('#ep-popup-overlay').length === 0) {
            const photoPopup = `
            <div class="popup-overlay" id="ep-popup-overlay" style="display: none!important">
               
                <div class="popup">
                    <span class="close-btn" id="close-btn">
                        <svg width="20" height="20" viewBox="0 0 0.6 0.6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M.132.132a.025.025 0 0 1 .035 0L.3.265.432.133a.025.025 0 1 1 .035.035L.335.3l.132.132a.025.025 0 0 1-.035.035L.3.335.168.467A.025.025 0 0 1 .133.432L.265.3.132.168a.025.025 0 0 1 0-.035" fill="#fff"/></svg>
                    </span>
                    <button type="button" class="prev-btn" id="prev-btn" aria-label="Previous">
                        <svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 0.6 0.6" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M.525.275h-.39L.268.143A.025.025 0 1 0 .233.108L.058.283a.025.025 0 0 0 0 .035l.175.175a.025.025 0 0 0 .035 0 .025.025 0 0 0 0-.035L.135.325h.39a.025.025 0 0 0 0-.05" style="fill:#fff"/></svg>
                    </button>
                    <div id="popup-content" class="loading">
                        <div class="photo-loader"></div>
                        <img id="popup-image" src="" style="display:none;" loading="lazy" />
                    </div>
                    <button type="button" class="next-btn" id="next-btn" aria-label="Next">
                        <svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 0.6 0.6" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M.543.282.368.107a.025.025 0 0 0-.035.035l.133.132H.075a.025.025 0 0 0 0 .05h.39L.332.456a.025.025 0 0 0 0 .035.025.025 0 0 0 .035 0L.542.316a.025.025 0 0 0 0-.035" style="fill:#fff"/></svg>
                    </button>
                </div>
            </div>`;
            $('body').append(photoPopup);

            // Loader spinner CSS (can be moved to your CSS file)
            const spinnerStyles = `
            <style>
                .popup #popup-content .photo-loader {
                    display: none;
                }
                .popup #popup-content.loading .photo-loader {
                    width: 40px;
                    height: 40px;
                    border: 4px solid #fff;
                    border-top: 4px solid transparent;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin: 40px auto;
                    display: block;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>`;
            $('head').append(spinnerStyles);

            // Events
            $('#ep-popup-overlay').on('click', function (e) {
                if ($(e.target).is('#ep-popup-overlay') || $(e.target).is('.popup')) {
                    $('#ep-popup-overlay').hide();
                }
            });

            $('#close-btn').on('click', function () {
                $('#ep-popup-overlay').hide();
            });

            $('#prev-btn').on('click', function () {
                currentIndex = (currentIndex - 1 + $photos.length) % $photos.length;
                updatePopupImage();
            });

            $('#next-btn').on('click', function () {
                currentIndex = (currentIndex + 1) % $photos.length;
                updatePopupImage();
            });
        }
    }

    function updatePopupImage() {
        const imgSrc = $photos.eq(currentIndex).find('img').attr('data-photo-src');
        const $popupImage = $('#popup-image');
        const $popupContent = $('#popup-content');

        $popupContent.addClass('loading');
        $popupImage.hide();

        const preload = new Image();
        preload.src = imgSrc;

        preload.onload = function () {
            $popupImage.attr('src', imgSrc);
            $popupContent.removeClass('loading');
            $popupImage.fadeIn();
        };
    }

    // Delegated binding: works for `.photo-item` elements that are added to the
    // DOM after page load — e.g. an EmbedPress gallery placed inside an Elementor
    // popup, which Elementor injects only when the popup is opened. A direct
    // `$('.photo-item').on('click', ...)` bound here would miss those elements.
    $(document).on('click', '.photo-item', function () {
        // Scope navigation (prev/next) to the gallery that was actually clicked,
        // so multiple galleries on the same page don't get mixed together.
        var $gallery = $(this).closest('.photos-gallery-grid, .photos-gallery-justify, .photos-gallery-masonary');
        $photos = $gallery.length ? $gallery.find('.photo-item') : $('.photo-item');
        currentIndex = $photos.index(this);
        createPopupGooglePhotos();
        updatePopupImage();
        $('#ep-popup-overlay').show();
    });
});


/* ---------------------------------------------------------------------- */
/* Justify layout                                                          */
/* ---------------------------------------------------------------------- */
(function () {
    var ROW_HEIGHT = Math.max(180, Math.round((window.screen && screen.height ? screen.height : 900) * 0.2));

    function sizeItem(item, image) {
        var w = image.naturalWidth;
        var h = image.naturalHeight;
        // naturalWidth is 0 while the image is still decoding (or a lazy
        // image that hasn't entered the viewport yet). Bail and let the
        // load handler size it later — never write a 0/NaN width, which is
        // what collapses the whole row in the editor preview.
        if (!w || !h) {
            return false;
        }
        var ratio = w / h;
        item.style.width = ROW_HEIGHT * ratio + 'px';
        item.style.flexGrow = ratio;
        return true;
    }

    function justifyGallery(root) {
        var scope = root && root.querySelectorAll ? root : document;
        var items = scope.querySelectorAll('.photos-gallery-justify .photo-item');

        items.forEach(function (item) {
            var image = item.querySelector('img');
            if (!image) return;

            // Lazy loading keeps off-screen images unloaded, so naturalWidth
            // stays 0 and the row collapses. The justify layout needs the real
            // ratio up front, so opt these images out of lazy loading.
            if (image.getAttribute('loading') === 'lazy') {
                image.removeAttribute('loading');
            }

            if (!sizeItem(item, image)) {
                // Not ready yet — size it once the bytes arrive. decode()
                // resolves on already-cached images too, with onload as a fallback.
                var onReady = function () { sizeItem(item, image); };
                image.addEventListener('load', onReady, { once: true });
                if (image.decode) {
                    image.decode().then(onReady).catch(function () { /* onload covers it */ });
                }
            }
        });
    }

    function init() {
        justifyGallery(document);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    window.addEventListener('load', init);

    // Elementor editor (and frontend) re-render widgets via AJAX after the
    // initial load events have already fired, so re-justify whenever a Google
    // Photos widget becomes ready.
    if (window.jQuery) {
        jQuery(window).on('elementor/frontend/init', function () {
            if (window.elementorFrontend && elementorFrontend.hooks) {
                elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
                    justifyGallery($scope && $scope[0] ? $scope[0] : document);
                });
            }
        });
    }

    // Catch any other late DOM injection (block editor preview, AJAX, etc.).
    if (window.MutationObserver) {
        var pending = false;
        var observer = new MutationObserver(function (mutations) {
            if (pending) return;
            for (var i = 0; i < mutations.length; i++) {
                if (mutations[i].addedNodes && mutations[i].addedNodes.length) {
                    pending = true;
                    window.requestAnimationFrame(function () {
                        pending = false;
                        justifyGallery(document);
                    });
                    break;
                }
            }
        });
        var startObserver = function () {
            if (document.body) {
                observer.observe(document.body, { childList: true, subtree: true });
            }
        };
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', startObserver);
        } else {
            startObserver();
        }
    }
})();
