/**
 * EmbedPress Pro — PDF Gallery block editor: Carousel and Bookshelf previews.
 *
 * Free's PDF Gallery block previews Grid and Masonry and asks for any other
 * layout through two wp.hooks filters:
 *   `embedpress.pdfGallery.layouts`      — layouts the editor can preview
 *   `embedpress.pdfGallery.editorLayout` — { containerStyle, children } for
 *                                          the preview, given { layout,
 *                                          attributes, pdfItems, renderItem,
 *                                          addButton }
 */
(function (wp) {
    'use strict';

    if (!wp || !wp.hooks || !wp.element) return;

    var el = wp.element.createElement;

    wp.hooks.addFilter(
        'embedpress.pdfGallery.layouts',
        'embedpress-pro/pdf-gallery-layouts',
        function (layouts) {
            layouts = Array.isArray(layouts) ? layouts.slice() : [];
            ['carousel', 'bookshelf'].forEach(function (layout) {
                if (layouts.indexOf(layout) === -1) layouts.push(layout);
            });
            return layouts;
        }
    );

    wp.hooks.addFilter(
        'embedpress.pdfGallery.editorLayout',
        'embedpress-pro/pdf-gallery-layouts',
        function (preview, ctx) {
            if (!ctx || !preview) return preview;
            var attributes = ctx.attributes || {};

            if (ctx.layout === 'carousel') {
                // Horizontal scroll strip; slide width mirrors the frontend.
                var spv = attributes.slidesPerView || 3;
                var gapPx = attributes.gap || 20;
                var style = Object.assign({}, preview.containerStyle);
                style['--ep-carousel-slide-width'] = 'calc((100% - ' + (gapPx * (spv - 1)) + 'px) / ' + spv + ')';
                return { containerStyle: style, children: preview.children };
            }

            if (ctx.layout === 'bookshelf') {
                var items = ctx.pdfItems || [];
                var perShelf = attributes.columns || 5;
                var rows = [];

                for (var i = 0; i < items.length; i += perShelf) {
                    var chunk = items.slice(i, i + perShelf);
                    rows.push(el(
                        'div',
                        { className: 'ep-pdf-gallery__shelf-row', key: 'shelf-' + i },
                        chunk.map(function (item, j) {
                            return ctx.renderItem(item, i + j);
                        })
                    ));
                }

                rows.push(el('div', { className: 'ep-pdf-gallery__shelf-add-row', key: 'shelf-add' }, ctx.addButton));

                return {
                    containerStyle: preview.containerStyle,
                    children: el('div', { className: 'ep-pdf-gallery__bookshelf-container' }, rows),
                };
            }

            return preview;
        }
    );
})(window.wp);
