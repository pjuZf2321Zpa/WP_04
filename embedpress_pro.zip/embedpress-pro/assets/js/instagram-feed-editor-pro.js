/**
 * EmbedPress Pro — Instagram Carousel preview in the block editor.
 *
 * Free's EmbedPress block fires the `embedpress.instagram.previewRendered`
 * action (clientId, attributes) after an Instagram feed preview is rendered.
 * For the Carousel layout, initialise CgCarousel on the preview the same way
 * the frontend does.
 */
(function (wp) {
    'use strict';

    if (!wp || !wp.hooks) return;

    wp.hooks.addAction('embedpress.instagram.previewRendered', 'embedpress-pro/instagram-carousel', function (clientId, attributes) {
        attributes = attributes || {};
        if (attributes.instaLayout !== 'insta-carousel') return;

        var options = {
            layout: attributes.instaLayout,
            slidesPerView: attributes.slidesShow,
            spacing: attributes.carouselSpacing,
            loop: attributes.carouselLoop,
            autoplay: attributes.carouselAutoplay,
            autoplaySpeed: attributes.autoplaySpeed,
            transitionSpeed: attributes.transitionSpeed,
            arrows: attributes.carouselArrows,
            breakpoints: {
                768: { slidesPerView: 2 },
                1024: { slidesPerView: 4 }
            }
        };

        var scope = '[data-carouselid="' + clientId + '"]';

        var intervalId = setInterval(function () {
            var container = document.querySelector(scope + ' .embedpress-insta-container');
            if (!container || typeof window.CgCarousel === 'undefined') return;

            clearInterval(intervalId);

            var carousel = new window.CgCarousel(scope + ' .embedpress-insta-container', options, {});

            var btns = document.querySelector(scope + ' .cg-carousel__btns');
            if (btns) {
                btns.classList[attributes.carouselArrows ? 'remove' : 'add']('hidden');
            }

            var next = document.querySelector(scope + ' #js-carousel__next-1');
            if (next) next.addEventListener('click', function () { carousel.next(); });

            var prev = document.querySelector(scope + ' #js-carousel__prev-1');
            if (prev) prev.addEventListener('click', function () { carousel.prev(); });
        }, 200);
    });
})(window.wp);
