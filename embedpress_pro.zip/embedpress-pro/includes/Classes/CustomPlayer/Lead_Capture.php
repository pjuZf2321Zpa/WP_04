<?php

namespace Embedpress\Pro\Classes\CustomPlayer;

defined('ABSPATH') or die("No direct script access allowed.");

/**
 * Lead Capture (Pro)
 *
 * Receives email-capture form submissions from the custom player and
 * stores them in the custom table `{prefix}embedpress_leads`. Adapter
 * plugins can listen on `embedpress_lead_captured` to forward to
 * FluentCRM, Mailchimp, webhooks, etc.
 *
 * Lives in Pro because Email Capture is a Pro feature (PRD #81243 §4.1).
 */
class Lead_Capture
{
    const TABLE          = 'embedpress_leads';
    const SCHEMA_OPTION  = 'embedpress_leads_schema_version';
    const SCHEMA_VERSION = 1;

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('init', [self::class, 'maybe_install_table'], 5);
        add_filter('wp_privacy_personal_data_exporters', [self::class, 'register_exporter']);
        add_filter('wp_privacy_personal_data_erasers', [self::class, 'register_eraser']);
    }

    public function register_routes()
    {
        register_rest_route('embedpress/v1', '/lead', [
            'methods'             => 'POST',
            'callback'            => [$this, 'handle_lead'],
            'permission_callback' => '__return_true',
            'args' => [
                'email' => [
                    'required' => true,
                    'type'     => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ],
                'name' => [
                    'required' => false,
                    'type'     => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'video_url' => [
                    'required' => false,
                    'type'     => 'string',
                    'sanitize_callback' => 'esc_url_raw',
                ],
                'page_url' => [
                    'required' => false,
                    'type'     => 'string',
                    'sanitize_callback' => 'esc_url_raw',
                ],
            ],
        ]);

        // Admin-only: list captured leads (used by the Custom Player React app).
        register_rest_route('embedpress/v1', '/leads', [
            'methods'             => 'GET',
            'callback'            => [$this, 'handle_list'],
            'permission_callback' => function () { return current_user_can('manage_options'); },
            'args' => [
                'from'     => ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field'],
                'to'       => ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field'],
                'q'        => ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field'],
                'page'     => ['type' => 'integer', 'default' => 1],
                'per_page' => ['type' => 'integer', 'default' => 25],
            ],
        ]);
    }

    public function handle_list(\WP_REST_Request $request)
    {
        global $wpdb;
        self::maybe_install_table();
        $table    = self::table_name();
        $from     = $request->get_param('from');
        $to       = $request->get_param('to');
        $q        = $request->get_param('q');
        $page     = max(1, (int) $request->get_param('page'));
        $per_page = max(1, min(100, (int) $request->get_param('per_page')));
        $offset   = ($page - 1) * $per_page;

        $where = ['1=1'];
        $args  = [];
        if ($from && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $where[] = 'created_at >= %s'; $args[] = $from . ' 00:00:00'; }
        if ($to   && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   { $where[] = 'created_at <= %s'; $args[] = $to . ' 23:59:59'; }
        if (!empty($q)) {
            $where[] = '(email LIKE %s OR video_url LIKE %s)';
            $like = '%' . $wpdb->esc_like($q) . '%';
            $args[] = $like;
            $args[] = $like;
        }
        $where_sql = implode(' AND ', $where);

        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        $total = (int) ($args ? $wpdb->get_var($wpdb->prepare($count_sql, $args)) : $wpdb->get_var($count_sql));

        $rows_sql = "SELECT id, email, name, video_url, page_url, created_at FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";
        $rows = $wpdb->get_results($wpdb->prepare($rows_sql, array_merge($args, [$per_page, $offset])), 'ARRAY_A');

        // Normalize legacy rows that stored the iframe `src` (e.g.
        // youtube.com/embed/ID) instead of the public source URL.
        if ($rows) {
            foreach ($rows as &$row) {
                $row['video_url'] = self::canonicalize_video_url($row['video_url']);
            }
            unset($row);
        }

        return new \WP_REST_Response([
            'data'        => $rows ?: [],
            'total'       => $total,
            'total_pages' => (int) ceil($total / $per_page),
            'page'        => $page,
            'per_page'    => $per_page,
        ], 200);
    }

    public function handle_lead(\WP_REST_Request $request)
    {
        global $wpdb;

        $email = $request->get_param('email');
        if (!is_email($email)) {
            return new \WP_REST_Response(['message' => 'Invalid email'], 400);
        }

        $lead = [
            'email'      => $email,
            'name'       => (string) $request->get_param('name'),
            'video_url'  => self::canonicalize_video_url((string) $request->get_param('video_url')),
            'page_url'   => (string) $request->get_param('page_url'),
            'ip'         => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
            'created_at' => current_time('mysql'),
        ];

        self::maybe_install_table();
        $wpdb->insert(self::table_name(), $lead, ['%s', '%s', '%s', '%s', '%s', '%s']);

        // Adapter plugins (FluentCRM, Mailchimp, webhook) hook here.
        do_action('embedpress_lead_captured', $lead);

        return new \WP_REST_Response(['message' => 'ok'], 200);
    }

    public static function table_name()
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    /**
     * Map a known iframe-embed URL back to its public source URL.
     *
     * The custom player's email-capture submission posts whatever the
     * iframe `src` attribute resolved to (e.g. `youtube.com/embed/ID`).
     * That's not the URL the editor pasted — the lead table should show
     * the recognizable public URL the user can click. Returns the input
     * unchanged when the host isn't a known embed surface.
     */
    public static function canonicalize_video_url($url)
    {
        $url = (string) $url;
        if ($url === '') return $url;

        // YouTube: youtube.com/embed/ID  or youtube-nocookie.com/embed/ID
        if (preg_match('#^(https?:)?//(?:www\.)?(?:youtube\.com|youtube-nocookie\.com)/embed/([A-Za-z0-9_-]{6,})#i', $url, $m)) {
            return 'https://www.youtube.com/watch?v=' . $m[2];
        }
        // Vimeo: player.vimeo.com/video/ID
        if (preg_match('#^(https?:)?//player\.vimeo\.com/video/(\d+)#i', $url, $m)) {
            return 'https://vimeo.com/' . $m[2];
        }
        // Dailymotion: dailymotion.com/embed/video/ID
        if (preg_match('#^(https?:)?//(?:www\.)?dailymotion\.com/embed/video/([A-Za-z0-9]+)#i', $url, $m)) {
            return 'https://www.dailymotion.com/video/' . $m[2];
        }
        // Wistia: fast.wistia.(net|com)/embed/iframe/HASH
        if (preg_match('#^(https?:)?//fast\.wistia\.(?:net|com)/embed/iframe/([A-Za-z0-9]+)#i', $url, $m)) {
            return 'https://fast.wistia.net/medias/' . $m[2];
        }
        // Twitch VOD: player.twitch.tv/?video=ID
        if (preg_match('#^(https?:)?//player\.twitch\.tv/\?[^"\']*\bvideo=v?(\d+)#i', $url, $m)) {
            return 'https://www.twitch.tv/videos/' . $m[2];
        }
        // Twitch channel: player.twitch.tv/?channel=NAME
        if (preg_match('#^(https?:)?//player\.twitch\.tv/\?[^"\']*\bchannel=([A-Za-z0-9_]+)#i', $url, $m)) {
            return 'https://www.twitch.tv/' . $m[2];
        }

        return $url;
    }

    /* -------------------------------------------------------------------- */
    /* GDPR — personal data exporter + eraser                               */
    /* -------------------------------------------------------------------- */

    public static function register_exporter($exporters)
    {
        $exporters['embedpress-leads'] = [
            'exporter_friendly_name' => __('EmbedPress captured leads', 'embedpress-pro'),
            'callback'               => [self::class, 'export_leads'],
        ];
        return $exporters;
    }

    public static function register_eraser($erasers)
    {
        $erasers['embedpress-leads'] = [
            'eraser_friendly_name' => __('EmbedPress captured leads', 'embedpress-pro'),
            'callback'             => [self::class, 'erase_leads'],
        ];
        return $erasers;
    }

    public static function export_leads($email_address, $page = 1)
    {
        global $wpdb;
        self::maybe_install_table();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::table_name() . " WHERE email = %s ORDER BY id ASC",
            $email_address
        ), 'ARRAY_A');

        $data = [];
        foreach ($rows as $row) {
            $data[] = [
                'group_id'    => 'embedpress-leads',
                'group_label' => __('EmbedPress captured leads', 'embedpress-pro'),
                'item_id'     => 'embedpress-lead-' . $row['id'],
                'data'        => [
                    ['name' => __('Email', 'embedpress-pro'),      'value' => $row['email']],
                    ['name' => __('Name', 'embedpress-pro'),       'value' => $row['name']],
                    ['name' => __('Video URL', 'embedpress-pro'),  'value' => self::canonicalize_video_url($row['video_url'])],
                    ['name' => __('Page URL', 'embedpress-pro'),   'value' => $row['page_url']],
                    ['name' => __('IP', 'embedpress-pro'),         'value' => $row['ip']],
                    ['name' => __('Captured at', 'embedpress-pro'), 'value' => $row['created_at']],
                ],
            ];
        }

        return ['data' => $data, 'done' => true];
    }

    public static function erase_leads($email_address, $page = 1)
    {
        global $wpdb;
        self::maybe_install_table();
        $deleted = (int) $wpdb->delete(self::table_name(), ['email' => $email_address], ['%s']);

        return [
            'items_removed'  => $deleted > 0,
            'items_retained' => false,
            'messages'       => $deleted > 0 ? [sprintf(
                /* translators: %d: number of removed rows */
                __('Removed %d EmbedPress lead record(s).', 'embedpress-pro'),
                $deleted
            )] : [],
            'done'           => true,
        ];
    }

    /** Idempotent — runs at most once per schema bump. */
    public static function maybe_install_table()
    {
        if ((int) get_option(self::SCHEMA_OPTION, 0) >= self::SCHEMA_VERSION) return;

        global $wpdb;
        $table = self::table_name();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            email VARCHAR(190) NOT NULL,
            name VARCHAR(190) NOT NULL DEFAULT '',
            video_url TEXT NOT NULL,
            page_url TEXT NOT NULL,
            ip VARCHAR(45) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY email (email),
            KEY created_at (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        update_option(self::SCHEMA_OPTION, self::SCHEMA_VERSION, false);
    }
}
