<?php

namespace Embedpress\Pro\Classes\CustomPlayer;

defined('ABSPATH') or die("No direct script access allowed.");

/**
 * Course Completion Tracker (Pro)
 *
 * Receives `video-completed` POST callbacks from the custom player and
 * fires `embedpress_video_completed` so LMS adapters (LearnDash,
 * TutorLMS, LifterLMS, etc.) can mark the corresponding lesson complete.
 *
 * Server-side anti-skip guard: rejects callbacks whose watched_seconds
 * is less than 85 % of total_seconds. Adapters should still verify
 * lesson ownership before crediting completion.
 *
 * Lives in Pro because Course Completion Tracking is a Pro feature
 * (PRD #81243 §4.11).
 */
class Completion_Tracker
{
    const MIN_WATCH_RATIO = 0.85;
    const FALLBACK_LOG_DAYS = 14;
    const FALLBACK_OPTION_PREFIX = 'embedpress_completion_log_';
    // Per-user progress map: video_url_md5 => {completed_at, max_watched_seconds, total_seconds}.
    // Lets the server be the single source of truth for "already credited"
    // (so client-side sessionStorage isn't needed) and stores actual watch
    // depth so the dashboard can show "watched 87%" instead of the
    // moment-of-completion snapshot.
    const USER_META_KEY = 'embedpress_video_progress';

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
        // Built-in LMS adapters — register here so a single Pro install can
        // light up LearnDash / TutorLMS / LifterLMS without each adapter
        // needing its own bootstrap file.
        add_action('embedpress_video_completed', [$this, 'mark_lms_lesson_complete'], 10, 1);
    }

    public function register_routes()
    {
        register_rest_route('embedpress/v1', '/completion', [
            'methods'             => 'POST',
            'callback'            => [$this, 'handle_completion'],
            'permission_callback' => '__return_true',
            'args' => [
                'video_url' => [
                    'required' => true,
                    'type'     => 'string',
                    'sanitize_callback' => 'esc_url_raw',
                ],
                'watched_seconds' => [
                    'required' => true,
                    'type'     => 'number',
                ],
                'total_seconds' => [
                    'required' => true,
                    'type'     => 'number',
                ],
                'video_title' => [
                    'required' => false,
                    'type'     => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'page_id' => [
                    'required' => false,
                    'type'     => 'integer',
                ],
                'threshold' => [
                    'required' => false,
                    'type'     => 'number',
                ],
                // Progress-only beacons (pause / ended / beforeunload) bypass
                // the threshold + LMS-fire path and just bump max_watched_seconds.
                'progress_only' => [
                    'required' => false,
                    'type'     => 'boolean',
                ],
            ],
        ]);

        // Admin-only: list recent completions from the fallback log.
        register_rest_route('embedpress/v1', '/completions', [
            'methods'             => 'GET',
            'callback'            => [$this, 'handle_list'],
            'permission_callback' => function () { return current_user_can('manage_options'); },
        ]);
    }

    public function handle_list(\WP_REST_Request $request)
    {
        $entries = self::read_fallback();
        usort($entries, function ($a, $b) { return strcmp($b['completed_at'] ?? '', $a['completed_at'] ?? ''); });
        // Enrich with user_login for the React table.
        foreach ($entries as &$e) {
            $user = !empty($e['user_id']) ? get_user_by('id', $e['user_id']) : null;
            $e['user_login'] = $user ? $user->user_login : '';
            // The frontend posts the rendered iframe `src` (e.g.
            // youtube.com/embed/ID); the dashboard should display the
            // public URL the editor pasted. Normalize at read time so
            // legacy rows fix themselves without a DB migration.
            if (!empty($e['video_url'])) {
                $e['video_url'] = Lead_Capture::canonicalize_video_url($e['video_url']);
            }
        }
        return new \WP_REST_Response([
            'data'  => $entries,
            'days'  => self::FALLBACK_LOG_DAYS,
            'total' => count($entries),
        ], 200);
    }

    public function handle_completion(\WP_REST_Request $request)
    {
        $watched       = (float) $request->get_param('watched_seconds');
        $total         = (float) $request->get_param('total_seconds');
        $threshold     = (float) $request->get_param('threshold');
        $progress_only = (bool) $request->get_param('progress_only');
        $video_url     = (string) $request->get_param('video_url');
        $user_id       = get_current_user_id();

        if ($total <= 0) {
            return new \WP_REST_Response(['message' => 'Invalid duration'], 400);
        }

        // Progress-only beacon: just bump max_watched_seconds, skip
        // threshold check + LMS hook. Sent on pause / ended / beforeunload
        // so the dashboard sees real watch depth even for non-completers.
        if ($progress_only) {
            self::bump_user_progress($user_id, $video_url, $watched, $total);
            return new \WP_REST_Response(['message' => 'progress', 'max_watched_seconds' => $watched], 200);
        }

        // Anti-skip floor is the lower of MIN_WATCH_RATIO and 90% of
        // the configured position threshold — a 50% threshold can't
        // require 85% watched (unsatisfiable), and even at the threshold
        // itself the client's `watched` lags `currentTime` by ~one tick
        // (first timeupdate just initializes lastT) plus any YouTube
        // ticks dropped by the delta<5 guard. The 0.9 multiplier matches
        // initplyr.js so a natural watch-through that the client accepts
        // doesn't get 422'd here.
        $floor = self::MIN_WATCH_RATIO;
        if ($threshold > 0 && $threshold < 1) {
            $floor = min($floor, $threshold * 0.9);
        }
        if ($watched / $total < $floor) {
            return new \WP_REST_Response(['message' => 'Insufficient watch time'], 422);
        }

        // Idempotency: per-(user,video) check via user meta. Anonymous
        // viewers (user_id=0) have no meta to dedup against — that's
        // fine, the LMS adapter early-returns on !$user_id anyway.
        $already_completed = $user_id ? self::has_user_completed($user_id, $video_url) : false;

        $payload = [
            'video_url'       => $video_url,
            'video_title'     => (string) $request->get_param('video_title'),
            'page_id'         => (int) $request->get_param('page_id'),
            'user_id'         => $user_id,
            'watched_seconds' => $watched,
            'total_seconds'   => $total,
            'page_url'        => isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '',
            'completed_at'    => current_time('mysql'),
        ];

        if (!$already_completed) {
            /**
             * Fires when a viewer completes a video.
             * LMS adapters hook here to mark the corresponding lesson complete.
             */
            do_action('embedpress_video_completed', $payload);

            // Fallback log — keyed by date, capped to FALLBACK_LOG_DAYS.
            // Ensures completion data survives even when no LMS adapter is loaded.
            self::write_fallback($payload);
        }

        // Always update the per-user progress map — even on a re-fire,
        // a viewer who originally completed at 50% and then watched to
        // 100% should have max_watched_seconds reflect the higher value.
        self::bump_user_progress($user_id, $video_url, $watched, $total, /*mark_completed=*/true);

        return new \WP_REST_Response([
            'message' => $already_completed ? 'already-completed' : 'ok',
        ], 200);
    }

    /**
     * Update the per-user progress map. Increments max_watched_seconds
     * monotonically and (optionally) stamps completed_at on first credit.
     * No-op for anonymous viewers (no user meta to write to).
     */
    public static function bump_user_progress($user_id, $video_url, $watched, $total, $mark_completed = false)
    {
        if (!$user_id || !$video_url) return;
        $map = get_user_meta($user_id, self::USER_META_KEY, true);
        if (!is_array($map)) $map = [];
        $key   = md5($video_url);
        $entry = isset($map[$key]) && is_array($map[$key]) ? $map[$key] : [];

        $entry['video_url']           = $video_url;
        $entry['total_seconds']       = $total;
        $entry['max_watched_seconds'] = max(
            isset($entry['max_watched_seconds']) ? (float) $entry['max_watched_seconds'] : 0,
            $watched
        );
        if ($mark_completed && empty($entry['completed_at'])) {
            $entry['completed_at'] = current_time('mysql');
        }
        $entry['updated_at'] = current_time('mysql');

        $map[$key] = $entry;
        update_user_meta($user_id, self::USER_META_KEY, $map);
    }

    /** True if the user has previously been credited completion for this video. */
    public static function has_user_completed($user_id, $video_url)
    {
        if (!$user_id || !$video_url) return false;
        $map = get_user_meta($user_id, self::USER_META_KEY, true);
        if (!is_array($map)) return false;
        $entry = $map[md5($video_url)] ?? null;
        return is_array($entry) && !empty($entry['completed_at']);
    }

    /**
     * Append the payload to today's option blob and prune anything older
     * than FALLBACK_LOG_DAYS. Bounded storage — at most ~14 options.
     */
    public static function write_fallback(array $payload)
    {
        $today = date('Y-m-d', current_time('timestamp'));
        $key   = self::FALLBACK_OPTION_PREFIX . $today;

        $log = get_option($key, []);
        if (!is_array($log)) $log = [];
        $log[] = $payload;
        update_option($key, $log, false);

        self::prune_fallback();
    }

    /** Remove fallback option blobs older than FALLBACK_LOG_DAYS days. */
    public static function prune_fallback()
    {
        global $wpdb;
        $cutoff = date('Y-m-d', strtotime('-' . self::FALLBACK_LOG_DAYS . ' days', current_time('timestamp')));
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            $wpdb->esc_like(self::FALLBACK_OPTION_PREFIX) . '%'
        ));
        foreach ($rows as $name) {
            $date = substr($name, strlen(self::FALLBACK_OPTION_PREFIX));
            if ($date < $cutoff) delete_option($name);
        }
    }

    /**
     * Built-in adapters for the three LMS plugins listed in the PRD.
     * Each adapter is best-effort: if the LMS isn't installed, or the
     * referring page isn't a lesson, it silently no-ops.
     *
     * Lesson is identified by the referring page_id (sent from the JS).
     * Site owners can short-circuit this with the
     * `embedpress_lms_lesson_id` filter to do their own mapping.
     */
    public function mark_lms_lesson_complete($payload)
    {
        $user_id = (int) ($payload['user_id'] ?? 0);
        if (!$user_id) return; // anonymous viewers — nothing to mark

        $lesson_id = (int) ($payload['page_id'] ?? 0);
        $lesson_id = (int) apply_filters('embedpress_lms_lesson_id', $lesson_id, $payload);
        if (!$lesson_id) return;

        // LearnDash
        if (function_exists('learndash_process_mark_complete')) {
            $post_type = get_post_type($lesson_id);
            if (in_array($post_type, ['sfwd-lessons', 'sfwd-topic'], true)) {
                learndash_process_mark_complete($user_id, $lesson_id);
                return;
            }
        }
        // TutorLMS
        if (function_exists('tutor_utils') && method_exists(tutor_utils(), 'mark_lesson_complete')) {
            if (get_post_type($lesson_id) === 'lesson') {
                tutor_utils()->mark_lesson_complete($lesson_id, $user_id);
                return;
            }
        }
        // LifterLMS
        if (function_exists('llms_mark_complete')) {
            $post_type = get_post_type($lesson_id);
            if (in_array($post_type, ['lesson', 'course'], true)) {
                llms_mark_complete($user_id, $lesson_id, $post_type, 'embedpress_video');
                return;
            }
        }
    }

    /** Used by the admin dashboard / Analytics React to read recent completions. */
    public static function read_fallback($days = self::FALLBACK_LOG_DAYS)
    {
        $entries = [];
        $now = current_time('timestamp');
        for ($i = 0; $i < $days; $i++) {
            $date = date('Y-m-d', strtotime("-$i days", $now));
            $log  = get_option(self::FALLBACK_OPTION_PREFIX . $date, []);
            if (is_array($log) && $log) {
                $entries = array_merge($entries, $log);
            }
        }
        return $entries;
    }
}
