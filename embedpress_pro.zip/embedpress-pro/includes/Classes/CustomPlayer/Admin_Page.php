<?php

namespace Embedpress\Pro\Classes\CustomPlayer;

defined('ABSPATH') or die("No direct script access allowed.");

/**
 * Custom Player admin page (Pro) — React mount.
 *
 * Surfaces Email Capture leads, Drop-off Heatmap, and LMS completion data
 * collected by the Pro custom-player features (PRD #81243). Distinct from
 * the Analytics dashboard, which covers passive view/click measurement.
 *
 * The UI is a React app (`src/CustomPlayer/` here, built by
 * vite.custom-player.config.js to `assets/js/custom-player-pro-admin.build.js`).
 * Free ships only an upgrade panel for this page. This file only:
 *   • registers the submenu page,
 *   • enqueues the bundle, mounts the React root + localizes runtime data,
 *   • streams the CSV export (multi-MB, easier as a direct admin-init handler
 *     than as a REST route).
 */
class Admin_Page
{
    const PARENT_SLUG = 'embedpress';
    const PAGE_SLUG   = 'embedpress-player-engagement';
    const NONCE       = 'embedpress_custom_player';
    const SCRIPT_HANDLE = 'embedpress-pro-custom-player-admin';

    public function __construct()
    {
        add_action('admin_menu', [$this, 'register_menu'], 25);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets'], 20);
        add_action('admin_init', [$this, 'maybe_export_csv']);

        // Admin notices from WordPress core and other plugins are deliberately
        // left in place on this screen (WP.org guideline 11, same as free's
        // pages since #315/#326) — they render above the React app.
    }

    public function register_menu()
    {
        add_submenu_page(
            self::PARENT_SLUG,
            __('EmbedPress Player & Engagement', 'embedpress-pro'),
            __('Player & Engagement', 'embedpress-pro'),
            'manage_options',
            self::PAGE_SLUG,
            [$this, 'render_page']
        );
    }

    public function render_page()
    {
        if (!current_user_can('manage_options')) return;

        $localized = [
            'restUrl'     => esc_url_raw(rest_url('embedpress/v1/')),
            'nonce'       => wp_create_nonce('wp_rest'),
            'adminUrl'    => esc_url_raw(admin_url('admin.php')),
            'exportNonce' => wp_create_nonce(self::NONCE),
            'assetsUrl'   => defined('EMBEDPRESS_URL_ASSETS') ? EMBEDPRESS_URL_ASSETS : '',
            'isProActive' => true,
        ];
        wp_localize_script(self::SCRIPT_HANDLE, 'embedpressCustomPlayerData', $localized);

        // Pro's own mount point. Free's upgrade-panel bundle (which free's
        // AssetManager enqueues for this page slug) looks for
        // #embedpress-custom-player-root, so it never mounts here.
        echo '<div class="embedpress-custom-player-wrapper">';
        echo '<div id="embedpress-pro-custom-player-root"></div>';
        echo '</div>';
    }

    /**
     * Enqueue the dashboard bundle (src/CustomPlayer, built by
     * vite.custom-player.config.js) and drop free's upgrade-panel bundle,
     * which free's AssetManager enqueues for the same page slug.
     */
    public function enqueue_assets()
    {
        if (!isset($_GET['page']) || $_GET['page'] !== self::PAGE_SLUG) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        wp_dequeue_script('embedpress-custom-player');
        wp_dequeue_style('embedpress-custom-player-css');

        $js  = 'assets/js/custom-player-pro-admin.build.js';
        $css = 'assets/css/custom-player-pro-admin.build.css';
        wp_enqueue_script(self::SCRIPT_HANDLE, EMBEDPRESS_PRO_PLUGIN_URL . $js, ['wp-element', 'wp-i18n'], self::asset_version($js), true);
        wp_enqueue_style(self::SCRIPT_HANDLE, EMBEDPRESS_PRO_PLUGIN_URL . $css, [], self::asset_version($css));
        if (defined('EMBEDPRESS_PRO_PLUGIN_PATH')) {
            wp_set_script_translations(self::SCRIPT_HANDLE, 'embedpress-pro', EMBEDPRESS_PRO_PLUGIN_PATH . '/languages');
        }
    }

    private static function asset_version($relative)
    {
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : '';
        $path = defined('EMBEDPRESS_PRO_PLUGIN_PATH') ? EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative : '';
        if ($path !== '' && file_exists($path)) {
            $version .= '.' . filemtime($path);
        }
        return $version;
    }

    /**
     * Stream a CSV of leads matching the current filter. Lives here (not as
     * a REST route) so the browser handles it as a file download rather than
     * an XHR response.
     */
    public function maybe_export_csv()
    {
        if (!isset($_GET['embedpress_export']) || $_GET['embedpress_export'] !== 'leads') return;
        if (!current_user_can('manage_options')) return;
        check_admin_referer(self::NONCE);

        global $wpdb;
        Lead_Capture::maybe_install_table();
        $table = Lead_Capture::table_name();

        $from = isset($_GET['from']) ? sanitize_text_field($_GET['from']) : '';
        $to   = isset($_GET['to'])   ? sanitize_text_field($_GET['to'])   : '';
        $q    = isset($_GET['q'])    ? sanitize_text_field($_GET['q'])    : '';

        $where = ['1=1'];
        $args  = [];
        if ($from && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $where[] = 'created_at >= %s'; $args[] = $from . ' 00:00:00'; }
        if ($to   && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   { $where[] = 'created_at <= %s'; $args[] = $to . ' 23:59:59'; }
        if ($q !== '') {
            $where[] = '(email LIKE %s OR video_url LIKE %s)';
            $like = '%' . $wpdb->esc_like($q) . '%';
            $args[] = $like; $args[] = $like;
        }
        $where_sql = implode(' AND ', $where);
        $sql = "SELECT email, name, video_url, page_url, ip, created_at FROM {$table} WHERE {$where_sql} ORDER BY id DESC";
        $rows = $args ? $wpdb->get_results($wpdb->prepare($sql, $args), 'ARRAY_A')
                      : $wpdb->get_results($sql, 'ARRAY_A');

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="embedpress-leads-' . date('Ymd-His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['email', 'name', 'video_url', 'page_url', 'ip', 'created_at']);
        foreach ($rows as $r) {
            fputcsv($out, [$r['email'], $r['name'], Lead_Capture::canonicalize_video_url($r['video_url']), $r['page_url'], $r['ip'], $r['created_at']]);
        }
        fclose($out);
        exit;
    }
}
