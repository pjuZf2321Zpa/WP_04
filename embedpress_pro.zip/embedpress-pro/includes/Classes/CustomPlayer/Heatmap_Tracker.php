<?php

namespace Embedpress\Pro\Classes\CustomPlayer;

defined('ABSPATH') or die("No direct script access allowed.");

/**
 * Drop-off Heatmap (Pro)
 *
 * Stores anonymous "viewer reached this 1-percent bucket" counts per
 * video. Storage is a single WP option per video URL hash
 * (`embedpress_heatmap_<md5>`) containing a 100-element integer array
 * — keeps the schema migration free for v1 and the per-video data
 * well under the option size limits.
 *
 * No IPs, cookies, or user IDs are recorded. Each sample write only
 * increments a counter for the bucket the viewer is currently in.
 *
 * Lives in Pro because Drop-off Heatmap is a Pro feature (PRD #81243 §4.7).
 */
class Heatmap_Tracker
{
    const BUCKETS = 100;

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes()
    {
        register_rest_route('embedpress/v1', '/heatmap/sample', [
            'methods'             => 'POST',
            'callback'            => [$this, 'handle_sample'],
            'permission_callback' => '__return_true',
            'args' => [
                'video_url' => [
                    'required' => true,
                    'type'     => 'string',
                    'sanitize_callback' => 'esc_url_raw',
                ],
                'video_title' => [
                    'required' => false,
                    'type'     => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'bucket' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
            ],
        ]);

        register_rest_route('embedpress/v1', '/heatmap/data', [
            'methods'             => 'GET',
            'callback'            => [$this, 'handle_data'],
            'permission_callback' => function () {
                return current_user_can('edit_posts');
            },
            'args' => [
                'video_url' => [
                    'required' => true,
                    'type'     => 'string',
                    'sanitize_callback' => 'esc_url_raw',
                ],
            ],
        ]);

        // Admin-only: list all videos with collected heatmap samples.
        register_rest_route('embedpress/v1', '/heatmap/list', [
            'methods'             => 'GET',
            'callback'            => [$this, 'handle_list'],
            'permission_callback' => function () { return current_user_can('manage_options'); },
        ]);
    }

    public function handle_list(\WP_REST_Request $request)
    {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE 'embedpress_heatmap_%'",
            'ARRAY_A'
        );
        $videos = [];
        foreach ($rows as $row) {
            $data = maybe_unserialize($row['option_value']);
            // Support both flat 100-element arrays and {url,title,samples,buckets} wrappers.
            $buckets = isset($data['buckets']) ? $data['buckets'] : (is_array($data) ? $data : []);
            if (!is_array($buckets)) continue;
            $samples = isset($data['samples']) ? (int) $data['samples'] : array_sum(array_map('intval', $buckets));
            $url     = isset($data['url']) ? $data['url'] : '';
            $title   = isset($data['title']) ? $data['title'] : '';
            $videos[] = [
                'key'     => $row['option_name'],
                'url'     => $url,
                'title'   => $title,
                'samples' => $samples,
                'buckets' => array_values(array_map('intval', $buckets)),
            ];
        }
        usort($videos, function ($a, $b) { return $b['samples'] - $a['samples']; });
        return new \WP_REST_Response(['data' => $videos, 'total' => count($videos)], 200);
    }

    public function handle_sample(\WP_REST_Request $request)
    {
        $video_url   = (string) $request->get_param('video_url');
        $video_title = (string) $request->get_param('video_title');
        $bucket      = (int) $request->get_param('bucket');
        if (!$video_url || $bucket < 0 || $bucket >= self::BUCKETS) {
            return new \WP_REST_Response(['message' => 'bad bucket'], 400);
        }

        $key   = self::option_key($video_url);
        $data  = get_option($key, null);
        // Migrate legacy flat 100-array on first write under the new schema.
        if (!is_array($data) || !isset($data['buckets'])) {
            $legacy = (is_array($data) && count($data) === self::BUCKETS) ? $data : array_fill(0, self::BUCKETS, 0);
            $data = [
                'url'     => $video_url,
                'title'   => $video_title,
                'samples' => array_sum(array_map('intval', $legacy)),
                'buckets' => $legacy,
            ];
        }
        if (empty($data['url']))   $data['url']   = $video_url;
        if (!empty($video_title))  $data['title'] = $video_title;
        $data['buckets'][$bucket] = ((int) $data['buckets'][$bucket]) + 1;
        $data['samples']          = ((int) ($data['samples'] ?? 0)) + 1;
        update_option($key, $data, false);

        return new \WP_REST_Response(['message' => 'ok'], 200);
    }

    public function handle_data(\WP_REST_Request $request)
    {
        $video_url = (string) $request->get_param('video_url');
        $key       = self::option_key($video_url);
        $data      = get_option($key, null);
        $buckets   = isset($data['buckets']) ? $data['buckets']
                   : (is_array($data) && count($data) === self::BUCKETS ? $data : array_fill(0, self::BUCKETS, 0));
        return new \WP_REST_Response([
            'video_url'   => $video_url,
            'video_title' => isset($data['title']) ? $data['title'] : '',
            'buckets'     => array_map('intval', $buckets),
        ], 200);
    }

    public static function option_key($video_url)
    {
        return 'embedpress_heatmap_' . md5($video_url);
    }
}
