<?php

namespace Embedpress\Pro\Classes;

use Embedpress\Pro\Dependencies\WPDeveloper\Licensing\Manager as LicenseManager;
use Embedpress\Pro\Elementor\Extender;
use Embedpress\Pro\Traits\Enqueue;
use Embedpress\Pro\Filters\Calendar;
use Embedpress\Pro\Filters\Calendly;
use Embedpress\Pro\Filters\Youtube;
use Embedpress\Pro\Filters\YoutubePlaylist;
use Embedpress\Pro\Filters\Utility;
use Embedpress\Pro\Filters\Feature_Enhancer_Pro;
use Embedpress\Pro\Filters\Elementor_Enhancer_Pro;
use Embedpress\Pro\Filters\GooglePhotos;
use Embedpress\Pro\Classes\CustomPlayer\Lead_Capture;
use Embedpress\Pro\Classes\CustomPlayer\Heatmap_Tracker;
use Embedpress\Pro\Classes\CustomPlayer\Completion_Tracker;
use Embedpress\Pro\Classes\CustomPlayer\CDN_Offloader;
use Embedpress\Pro\Classes\CustomPlayer\Admin_Page;
use Embedpress\Pro\Analytics\Broken_Embeds_API;
use Embedpress\Pro\Analytics\Dashboard_Assets;
use Embedpress\Pro\Filters\Analytics_Pro;
use Embedpress\Pro\Filters\Dynamic_Source_Pro;
use Embedpress\Pro\Filters\Pdf_Watermark_Pro;
use Embedpress\Pro\Gutenberg\AdvancedPlayerHandlers;

if (!defined('ABSPATH')) {
    exit;
}

// Exit if accessed directly

class Bootstrap
{
    use Enqueue;

    /**
     * @var LicenseManager $license_manager
     *
     * Handles license related operations.
     */
    private $license_manager;

    // instance container
    private static $instance = null;

    /**
     * Free ↔ Pro extension contract this Pro needs (see free's
     * `EMBEDPRESS_PRO_CONTRACT` in includes.php and
     * docs/architecture/free-pro-coupling.md). Not a version number.
     */
    const REQUIRED_FREE_CONTRACT = 2;

    /**
     * Whether the active EmbedPress (free) provides the contract this Pro is
     * built for: the neutral `embedpress/*` hooks the moved Pro features
     * register on, with the old in-free implementations removed.
     *
     * False with EmbedPress <= 4.6.8. Pro then runs in "legacy free" mode:
     * it registers only what Pro 3.9.1 registered (old free still ships the
     * moved features itself, so they keep working as before) and shows an
     * "Update EmbedPress" notice.
     *
     * @return bool
     */
    public static function free_has_contract()
    {
        return defined('EMBEDPRESS_PRO_CONTRACT') && (int) EMBEDPRESS_PRO_CONTRACT >= self::REQUIRED_FREE_CONTRACT;
    }

    /**
     * Admin notice for legacy-free mode (EmbedPress too old for this Pro).
     */
    public function outdated_free_notice()
    {
        static $printed = false;
        if ($printed || !current_user_can('activate_plugins')) {
            return;
        }
        $printed = true;
        ?>
        <div class="notice notice-warning embedpress-outdated-free-notice">
            <p>
                <strong><?php esc_html_e('Update EmbedPress to the latest version.', 'embedpress-pro'); ?></strong>
                <?php esc_html_e('This version of EmbedPress Pro needs a newer EmbedPress. Some Pro features keep running in compatibility mode until you update EmbedPress.', 'embedpress-pro'); ?>
            </p>
            <p><a class="button button-primary" href="<?php echo esc_url(self_admin_url('plugins.php')); ?>"><?php esc_html_e('Go to Plugins', 'embedpress-pro'); ?></a></p>
        </div>
        <?php
    }

    /**
     * Singleton instance
     *
     * @since 2.0.0
     */
    public static function instance()
    {
        if (self::$instance == null) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * Constructor of plugin class
     *
     * @since 2.0.0
     */
    private function __construct()
    {
        add_filter('ep_general_settings_before_save', [$this, 'save_general_pro_settings'], 10);
        // for document branding
        //add_action( 'after_embedpress_branding_save', [static::class, 'save_custom_logo_settings_for_document']);
        add_action('admin_enqueue_scripts', [$this, 'admin_enqueue_scripts']);

        $this->load_provider();

        // EmbedPress <= 4.6.8 still ships the moved Pro features itself and
        // lacks the hooks the new Pro classes need: run as Pro 3.9.1 did.
        $legacy_free = !self::free_has_contract();
        if ($legacy_free) {
            add_action('admin_notices', [$this, 'outdated_free_notice']);
            // Free's own settings / analytics screens only print `ep_admin_notices`.
            add_action('ep_admin_notices', [$this, 'outdated_free_notice']);
        }

        new Utility();
        new Calendar();
        new Youtube();
        new YoutubePlaylist();
        new Calendly();
        new Feature_Enhancer_Pro();
        new Elementor_Enhancer_Pro();
        new GooglePhotos();
        // Instagram feed Pro features (Masonry / Carousel layouts, like &
        // comment counts, tabs, hashtag feed) through free's
        // `embedpress/instagram/*` extension points.
        if (!$legacy_free) new \Embedpress\Pro\Filters\Instagram_Feed_Pro();
        new \Embedpress\Pro\Filters\Google_Reviews_Pro();
        new \Embedpress\Pro\Filters\Google_Reviews_Apify();

        // Custom Player Pro features (PRD #81243 — Email Capture, Heatmap,
        // LMS Completion, CDN Offloading, ...). The frontend implementations
        // (assets/js/custom-player-pro.js) register with free's player
        // extension registry; Custom_Player_Pro enqueues them.
        if (!$legacy_free) new \Embedpress\Pro\Filters\Custom_Player_Pro();
        // PDF/Document view-count badge placement (free always renders below).
        if (!$legacy_free) new \Embedpress\Pro\Filters\View_Count_Position_Pro();
        new Lead_Capture();
        new Heatmap_Tracker();
        new Completion_Tracker();
        new CDN_Offloader();
        AdvancedPlayerHandlers::register();
        if (is_admin()) new Admin_Page();

        (new Broken_Embeds_API())->init();

        if (!$legacy_free) {
            // Analytics dashboard extensions (geo map + export control). Free
            // renders these through wp.hooks slots; this loads the bundle that
            // fills them.
            (new Dashboard_Assets())->init();

            // Analytics Pro services (collector / exporter / email reports).
            // Free owns the dashboard, schema and REST surface and asks for these
            // implementations through filters; this fills them.
            new Analytics_Pro();

            // Dynamic Source resolution (ACF / MetaBox / Pods / Toolset /
            // JetEngine / raw meta). Free keeps a stub entry point that its
            // render surfaces and REST routes call; this supplies the real one.
            new Dynamic_Source_Pro();

            // PDF watermark. The renderer runs inside free's PDF.js viewer; this
            // registers it as a viewer extension and keeps the script in sync.
            new Pdf_Watermark_Pro();

            // Custom Branding (logo + CTA overlay), the Ad Manager playback
            // engine and lazy loading. Free keeps the controls and asks for these
            // through `embedpress/branding/*`, `embedpress/lazy_load/*` and the
            // block-editor JS filters; these supply the implementations.
            new \Embedpress\Pro\Filters\Branding_Pro();
            new \Embedpress\Pro\Filters\Ads_Pro();
            new \Embedpress\Pro\Filters\Lazy_Load_Pro();

            // PDF / Document viewer options (toolbar, download, copy text, draw,
            // selection tool, scrolling, RTL flip, watermark params). Free emits
            // defaults through `embedpress/pdf/viewer_params`; this applies the
            // site owner's choices.
            new \Embedpress\Pro\Filters\Pdf_Viewer_Pro();

            // PDF Gallery Carousel + Bookshelf layouts, registered through free's
            // `embedpress/pdf_gallery/*` hooks and JS layout registry.
            new \Embedpress\Pro\Filters\Pdf_Gallery_Layouts_Pro();

            // Content protection (password / user-role). Free asks
            // `embedpress/content_protection/is_locked` and
            // `embedpress/content_protection/gate`; this answers both and owns the
            // lock UI, unlock AJAX and unlock script.
            new \Embedpress\Pro\Filters\Content_Protection_Pro();
        } else {
            // Old free fires `embedpress/display_password_form` /
            // `embedpress/content_protection_content` and handles everything
            // else itself; answer only those two actions, as Pro 3.9.1 did.
            new \Embedpress\Pro\Filters\Content_Protection_Pro(true);
        }

        add_action('elementor/widget/embedpres_elementor/skins_init', [$this, 'elementor_setting_init']);
        add_filter('embedpress:onAfterEmbed', [$this, 'add_pro_feature']);
        add_filter('embedpress:onBeforeEmbed', [$this, 'apple_podcast'], 99, 2);

        add_filter('embedpress_boomplay_content_type', [$this, 'add_boomplay_album_playlists_support'], 10, 2);
        add_action('embedpress_pdf_gutenberg_after_embed', [Helper::class, 'print_cta_markup_for_gutenberg_document']);

        // add_action('init', [$this, 'embedpress_plugin_license']);
        if( is_admin() ) {
            $this->embedpress_plugin_license();
        }
    }

    public function embedpress_plugin_license()
    {
        $this->embedpress_plugin_licensing();
    }

    public function add_boomplay_album_playlists_support($endpoint_type, $type)
    {
        return in_array($type, ['albums', 'playlists']) ? 'COL' : 'MUSIC';
    }

    /**
     * Load Provider class
     *
     * @since  2.0.0
     */
    public function load_provider()
    {
        $provider_arr = apply_filters('emebedpress_pro_providers', ['Youtube', 'Vimeo', 'Wistia', 'Twitch', 'Dailymotion', 'Soundcloud', 'Document', 'Meetup']);
        $name_space   = '\Embedpress\Pro\Providers';
        array_walk($provider_arr, function ($value) use ($name_space) {
            $class_name = $name_space . '\\' . $value;
            $class_name::featureExtend();
        });
    }

    /**
     * @since  2.3.0
     */
    public function embedpress_plugin_licensing()
    {
        if (empty($this->license_manager)) {
            $this->license_manager = LicenseManager::get_instance([
                'plugin_file'    => EMBEDPRESS_PRO_PLUGIN_FILE,
                'version'        => EMBEDPRESS_PRO_PLUGIN_VERSION,
                'item_id'        => EMBEDPRESS_SL_ITEM_ID,
                'item_name'      => EMBEDPRESS_SL_ITEM_NAME,
                'item_slug'      => EMBEDPRESS_SL_ITEM_SLUG,
                'storeURL'       => EMBEDPRESS_STORE_URL,
                'db_prefix'      => EMBEDPRESS_SL_DB_PREFIX,
                'textdomain'     => 'embedpress-pro',
                'page_slug'      => 'embedpress&page_type=license',
                'scripts_handle' => 'embedpress-admin',
                'screen_id'      => "toplevel_page_embedpress",
                'api'            => 'ajax',
                'ajax'           => [
                    'textdomain'     => 'embedpress-pro',
                    'action_prefix'     => 'embedpress',
                ]
            ]);
        }

        if (is_admin()) {
            // Setup the settings page and validation
            new EmbedPress_Licensing(
                EMBEDPRESS_SL_ITEM_SLUG,
                EMBEDPRESS_SL_ITEM_NAME,
                'embedpress-pro',
                $this->license_manager
            );
        }
        return $this->license_manager;
    }

    /**
     * Load Elementor control
     *
     * @since  2.3.3
     */
    public function elementor_setting_init()
    {
        Extender::embedpress_elementor_init();
    }

    /**
     * @param object $embed_object it contains url, attributes, embed, provider name etc. @see line 247 in Shortcode.php
     *
     * @return object
     */
    public function add_pro_feature($embed_object)
    {
        if (empty($embed_object->embed)) {
            return $embed_object;
        }

        if (!class_exists('\simple_html_dom') && defined('EMBEDPRESS_PATH_CORE')) {
            include_once EMBEDPRESS_PATH_CORE . 'simple_html_dom.php';
        }
        if (function_exists('str_get_html')) {
            $dom = str_get_html($embed_object->embed);
            $ifDom = $dom->find('iframe', 0);
            if (!empty($ifDom) && is_object($ifDom)) {
                $ifDom->setAttribute('loading', 'lazy');
            }
            ob_start();
            echo $dom;
            $m = ob_get_clean();
            $dom = str_get_html($m);

            $imgDom = $dom->find('img', 0);
            if (!empty($imgDom) && is_object($imgDom)) {
                $imgDom->setAttribute('loading', 'lazy');
            }

            ob_start();
            echo $dom;
            $embed_object->embed = ob_get_clean();
        }


        return $embed_object;
    }

    public function apple_podcast($url_data, $url)
    {

        if (strpos($url, 'podcasts.apple.com')) {
            $iframe_url = str_replace('podcasts.apple.com', 'embed.podcasts.apple.com', $url);
            $html = '<iframe allow="autoplay *; encrypted-media *; fullscreen *" frameborder="0" height="175" style="width:100%;max-width:660px;overflow:hidden;background:transparent;" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-storage-access-by-user-activation allow-top-navigation-by-user-activation" src="' . esc_url($iframe_url) . '"></iframe>';
            $url_data = [
                'type'          => 'html',
                'provider_name' => 'Apple Podcast',
                'provider_url'  => 'https://podcasts.apple.com',
                'url'           => $url,
                'html'          => $html,
            ];
        }
        return $url_data;
    }

    public function save_general_pro_settings($settings)
    {
        $settings['g_lazyload'] = isset($_POST['g_lazyload']) ? intval($_POST['g_lazyload']) : 0;

        return $settings;
    }
    public static function save_custom_logo_settings_for_document()
    {
        Helper::save_custom_logo_settings('document', 'doc');
    }
}
