<?php

namespace Embedpress\Pro\Providers;

use EmbedPress\Plugins\Plugin;

(defined('ABSPATH') && defined('EMBEDPRESS_IS_LOADED')) or die("No direct script access allowed.");

/**
 * Entity that represents an EmbedPress Pro plugin dedicated to Meetup RSS feeds.
 *
 * @package     EmbedPress-pro\Meetup
 * @author      EmbedPress<help@embedpress.com>
 * @copyright   Copyright (C) 2023 WPDeveloper. All rights reserved.
 * @license     GPLv2 or later
 * @since       1.0.0
 */
class Meetup extends Plugin
{
    /**
     * Plugin's name.
     *
     * @since   1.0.0
     *
     * @const   NAME
     */
    const NAME = "Meetup";

    /**
     * Plugin's slug.
     *
     * @since   1.0.0
     *
     * @const   SLUG
     */
    const SLUG = 'meetup';

    /**
     * Return the plugin options schema.
     *
     * @return  array
     * @since   1.0.0
     * @static
     */
    public static function getOptionsSchema()
    {
        return [
            'rss_cache_duration' => [
                'type'        => 'number',
                'default'     => 21600, // 6 hours
                'description' => 'Cache duration for RSS feeds in seconds'
            ],
            'max_events' => [
                'type'        => 'number',
                'default'     => 10,
                'description' => 'Maximum number of events to display from RSS feed'
            ]
        ];
    }

    /**
     * Feature extend method to hook into EmbedPress
     *
     * @since   1.0.0
     * @static
     */
    public static function featureExtend()
    {
        add_filter('embedpress:onAfterEmbed', [static::class, 'onAfterEmbed'], 90);
        add_filter('embedpress:onBeforeEmbed', [static::class, 'onBeforeEmbed'], 90);
        add_filter('embedpress_meetup_rss_cache_duration', [static::class, 'filterCacheDuration'], 10);
        add_filter('embedpress_meetup_max_events', [static::class, 'filterMaxEvents'], 10);

        // Register AJAX handlers for load more
        add_action('wp_ajax_embedpress_meetup_load_more', [static::class, 'ajaxLoadMore']);
        add_action('wp_ajax_nopriv_embedpress_meetup_load_more', [static::class, 'ajaxLoadMore']);
    }

    /**
     * Filter to modify cache duration for RSS feeds
     *
     * @param int $duration Default cache duration
     * @return int Modified cache duration
     */
    public static function filterCacheDuration($duration)
    {
        $settings = get_option(EMBEDPRESS_PLG_NAME . ':meetup', []);
        return isset($settings['rss_cache_duration']) ? intval($settings['rss_cache_duration']) : $duration;
    }

    /**
     * Filter to modify max events for RSS feeds
     *
     * @param int $max_events Default max events
     * @return int Modified max events
     */
    public static function filterMaxEvents($max_events)
    {
        $settings = get_option(EMBEDPRESS_PLG_NAME . ':meetup', []);
        return isset($settings['max_events']) ? intval($settings['max_events']) : $max_events;
    }

    /**
     * Handle RSS feed URLs and parse events with cache expiration
     * This method extends the base Meetup provider to handle RSS feeds
     */
    public static function handleRssFeed($response, $filename, $url, $cache_duration = 3600, $attributes = [])
    {
        // Check if cached file exists and is still valid
        if (file_exists($filename)) {
            $file_age = time() - filemtime($filename);

            // If cache is expired, remove the file
            if ($file_age > $cache_duration) {
                unlink($filename);
            } else {
                $cached_content = file_get_contents($filename);
                // If cached content has old inline styles, regenerate it
                if (strpos($cached_content, '<style>') === false) {
                    $response['html'] = $cached_content;
                    return $response;
                } else {
                    // Remove old cached file with inline styles
                    unlink($filename);
                }
            }
        }

        // Fetch and parse RSS feed
        $rss_content = self::fetchRssFeed($url);
        if (!$rss_content) {
            $response['html'] = '<div class="ep-events-error">Unable to load RSS feed.</div>';
            return $response;
        }

        // Generate HTML for events with attributes
        $events_html = self::generateEventsHtml($rss_content, $attributes);

        // Cache the result
        if (!file_exists(dirname($filename))) {
            wp_mkdir_p(dirname($filename));
        }
        file_put_contents($filename, $events_html);

        // Schedule cache cleanup if function exists
        if (function_exists('embedpress_schedule_cache_cleanup')) {
            embedpress_schedule_cache_cleanup();
        }

        $response['html'] = $events_html;
        return $response;
    }

    /**
     * Fetch RSS feed content
     */
    private static function fetchRssFeed($url)
    {
        // Use WordPress built-in fetch_feed function
        if (!function_exists('fetch_feed')) {
            include_once(ABSPATH . WPINC . '/feed.php');
        }

        $feed = fetch_feed($url);

        if (is_wp_error($feed)) {
            return false;
        }

        return $feed;
    }

    /**
     * Generate HTML for multiple events from RSS feed
     */
    private static function generateEventsHtml($feed, $attributes = [])
    {
        $items = $feed->get_items();

        if (empty($items)) {
            return '<div class="ep-events-empty">No upcoming events found.</div>';
        }

        // Enqueue the CSS file if it exists
        if (wp_style_is('embedpress-meetup-events', 'registered')) {
            wp_enqueue_style('embedpress-meetup-events');
        }

        // Parse attributes
        $per_page = isset($attributes['per_page']) ? intval($attributes['per_page']) : apply_filters('embedpress_meetup_max_events', 10);
        $orderby = isset($attributes['orderby']) ? sanitize_text_field($attributes['orderby']) : 'date';
        $order = isset($attributes['order']) ? strtoupper(sanitize_text_field($attributes['order'])) : 'ASC';
        $page = isset($attributes['page']) ? intval($attributes['page']) : 1;
        $enable_pagination = isset($attributes['enable_pagination']) ? filter_var($attributes['enable_pagination'], FILTER_VALIDATE_BOOLEAN) : true;

        // Generate unique ID for this embed
        $embed_id = 'ep-meetup-' . md5($feed->get_link() . serialize($attributes));

        // Process ALL events and store in transient for load more functionality
        $all_events = self::processAllEventsWithIndividualData($items, $orderby, $order);

        // Store all processed events and attributes in transient (expires in 1 hour)
        $transient_data = [
            'events' => $all_events,
            'attributes' => $attributes
        ];
        set_transient('embedpress_meetup_events_' . $embed_id, $transient_data, HOUR_IN_SECONDS);

        // Get events for current page
        $offset = ($page - 1) * $per_page;
        $processed_events = array_slice($all_events, $offset, $per_page);

        ob_start();
        ?>
        <div class="embedpress-meetup-events" data-embed-id="<?php echo esc_attr($embed_id); ?>" data-per-page="<?php echo esc_attr($per_page); ?>" data-page="<?php echo esc_attr($page); ?>">
            <div class="ep-events-header">
                <h2 class="ep-events-title"><?php echo esc_html($feed->get_title()); ?></h2>
                <p class="ep-events-description"><?php echo esc_html($feed->get_description()); ?></p>
            </div>

            <div class="embedpress-meetup-events-list">
                <?php foreach ($processed_events as $event_data): ?>
                    <?php echo self::generateSingleEventHtmlFromData($event_data, $attributes); ?>
                <?php endforeach; ?>
            </div>

            <?php if ($enable_pagination && count($all_events) > ($page * $per_page)): ?>
                <div class="ep-events-load-more">
                    <button class="ep-load-more-button" data-embed-id="<?php echo esc_attr($embed_id); ?>">
                        <span class="ep-load-more-text"><?php esc_html_e('Load More Events', 'embedpress'); ?></span>
                        <span class="ep-load-more-spinner" style="display:none;">
                            <?php echo esc_html__('Loading...', 'embedpress'); ?>
                        </span>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Process ALL events by fetching individual event data (for initial load and caching)
     */
    private static function processAllEventsWithIndividualData($items, $orderby = 'date', $order = 'ASC')
    {
        $all_events = [];

        // Process all items first
        foreach ($items as $item) {
            $event_data = [
                'title' => $item->get_title(),
                'link' => $item->get_link(),
                'description' => $item->get_description(),
                'date' => null,
                'venue' => null,
                'hosts' => null,
                'image' => null,
                'attendees_count' => 0,
                'rss_date' => $item->get_date('U') // Get Unix timestamp for sorting
            ];

            // Fetch individual event page data
            $individual_data = self::fetchIndividualEventData($item->get_link());
            if ($individual_data) {
                $event_data = array_merge($event_data, $individual_data);
            }

            // If no clean description from individual page, clean the RSS description
            if (empty($event_data['description']) || $event_data['description'] === $item->get_description()) {
                $rss_description = strip_tags($item->get_description());
                $rss_description = html_entity_decode($rss_description);
                $event_data['description'] = self::cleanMarkdownDescription($rss_description);
            }

            $all_events[] = $event_data;
        }

        // Sort events based on orderby parameter
        $all_events = self::sortEvents($all_events, $orderby, $order);

        return $all_events;
    }

    /**
     * Sort events based on orderby and order parameters
     */
    private static function sortEvents($events, $orderby = 'date', $order = 'ASC')
    {
        usort($events, function($a, $b) use ($orderby, $order) {
            $result = 0;

            switch ($orderby) {
                case 'date':
                    $date_a = !empty($a['date']) ? strtotime($a['date']) : $a['rss_date'];
                    $date_b = !empty($b['date']) ? strtotime($b['date']) : $b['rss_date'];
                    $result = $date_a - $date_b;
                    break;

                case 'title':
                    $result = strcmp($a['title'], $b['title']);
                    break;

                case 'attendees':
                    $result = $a['attendees_count'] - $b['attendees_count'];
                    break;

                default:
                    $result = 0;
            }

            return ($order === 'DESC') ? -$result : $result;
        });

        return $events;
    }

    /**
     * Fetch individual event data from event page
     */
    private static function fetchIndividualEventData($event_url)
    {
        $response = wp_remote_get($event_url, ['timeout' => 10]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return false;
        }

        // Extract JSON data from the page
        $event_data = self::extractEventDataFromPage($body);

        return $event_data;
    }

    /**
     * Extract event data from individual event page
     */
    private static function extractEventDataFromPage($html)
    {
        // Look for JSON data in the page
        if (preg_match('/"dateTime":"([^"]+)"/', $html, $date_matches)) {
            $date_time = $date_matches[1];
        } else {
            return false;
        }

        // Extract venue information
        $venue = null;
        if (preg_match('/"venue":\s*{[^}]*"name":"([^"]+)"[^}]*"address":"([^"]+)"[^}]*"city":"([^"]+)"[^}]*"state":"([^"]+)"/', $html, $venue_matches)) {
            $venue = [
                'name' => $venue_matches[1],
                'address' => $venue_matches[2],
                'city' => $venue_matches[3],
                'state' => $venue_matches[4]
            ];
        }

        // Extract clean description (without markdown)
        $description = null;
        if (preg_match('/"description":"([^"]+)"/', $html, $desc_matches)) {
            $description = $desc_matches[1];
            // Decode JSON escaped characters
            $description = json_decode('"' . $description . '"');
            // Remove markdown formatting
            $description = self::cleanMarkdownDescription($description);
        }

        // Extract event image
        $image = null;
        // Try multiple patterns for image extraction
        if (preg_match('/"featuredEventPhoto":\s*{[^}]*"source":"([^"]+)"/', $html, $image_matches)) {
            $image = $image_matches[1];
        } elseif (preg_match('/"featuredEventPhoto":\s*{[^}]*"baseUrl":"([^"]+)"[^}]*"id":"([^"]+)"/', $html, $image_matches)) {
            $base_url = $image_matches[1];
            $image_id = $image_matches[2];
            $image = $base_url . $image_id . '/676x380.jpg';
        } elseif (preg_match('/"image":\s*\[\s*"([^"]+)"/', $html, $image_matches)) {
            $image = $image_matches[1];
        }

        // Extract attendees count
        $attendees_count = 0;
        if (preg_match('/"goingCount":\s*{[^}]*"totalCount":(\d+)/', $html, $attendees_matches)) {
            $attendees_count = intval($attendees_matches[1]);
        }

        return [
            'date' => $date_time,
            'venue' => $venue,
            'description' => $description,
            'image' => $image,
            'attendees_count' => $attendees_count
        ];
    }

    /**
     * Clean markdown formatting from description
     */
    private static function cleanMarkdownDescription($description)
    {
        // Return empty string if description is null or empty
        if (empty($description)) {
            return '';
        }

        // Remove markdown bold **text**
        $description = preg_replace('/\*\*(.*?)\*\*/', '$1', $description);

        // Remove markdown italic *text*
        $description = preg_replace('/\*(.*?)\*/', '$1', $description);

        // Remove markdown links [text](url)
        $description = preg_replace('/\[([^\]]+)\]\([^\)]+\)/', '$1', $description);

        // Remove markdown headers
        $description = preg_replace('/^#+\s*(.*)$/m', '$1', $description);

        // Clean up extra whitespace
        $description = preg_replace('/\s+/', ' ', $description);
        $description = trim($description);

        return $description;
    }

    /**
     * Format event date with timezone conversion and custom formatting
     *
     * @param string $date_string The date string to format
     * @param array $attributes Attributes containing timezone and format settings
     * @return string Formatted date string or HTML with data attributes for JS conversion
     */
    private static function formatEventDate($date_string, $attributes = [])
    {
        // Get timezone setting
        $timezone_setting = isset($attributes['timezone']) ? $attributes['timezone'] : 'visitor_timezone';

        // Get date and time format settings
        $date_format = isset($attributes['date_format']) ? $attributes['date_format'] : 'wp_date_format';
        $time_format = isset($attributes['time_format']) ? $attributes['time_format'] : 'wp_time_format';

        // Resolve WordPress format placeholders
        if ($date_format === 'wp_date_format') {
            $date_format = get_option('date_format', 'F j, Y');
        }
        if ($time_format === 'wp_time_format') {
            $time_format = get_option('time_format', 'g:i A');
        }

        // Parse the date string to timestamp
        $date_timestamp = strtotime($date_string);

        // If visitor timezone is selected, return HTML with data attributes for JS conversion
        if ($timezone_setting === 'visitor_timezone') {
            return sprintf(
                '<span class="ep-event-date" data-visitor-timezone="true" data-utc-timestamp="%d" data-date-format="%s" data-time-format="%s">%s</span>',
                $date_timestamp,
                esc_attr($date_format),
                esc_attr($time_format),
                esc_html(gmdate('M j, Y, g:i A', $date_timestamp) . ' UTC')
            );
        }

        // Get timezone object
        if ($timezone_setting === 'wp_timezone') {
            $timezone = wp_timezone();
        } else {
            try {
                $timezone = new \DateTimeZone($timezone_setting);
            } catch (\Exception $e) {
                // Fallback to WordPress timezone if invalid timezone provided
                $timezone = wp_timezone();
            }
        }

        // Create DateTime object in UTC (Meetup dates are in UTC)
        $date = new \DateTime('@' . $date_timestamp);

        // Convert to target timezone
        $date->setTimezone($timezone);

        // Format the date and time
        $formatted_date = wp_date($date_format, $date->getTimestamp(), $timezone);
        $formatted_time = wp_date($time_format, $date->getTimestamp(), $timezone);
        $timezone_abbr = $date->format('T');

        // Combine date, time, and timezone
        $full_date = $formatted_date . ', ' . $formatted_time . ' ' . $timezone_abbr;

        return $full_date;
    }

    /**
     * Generate HTML for a single event from processed data
     */
    private static function generateSingleEventHtmlFromData($event_data, $attributes = [])
    {
        $title = $event_data['title'];
        $link = $event_data['link'];
        $description = $event_data['description'];

        // Format the actual event date with timezone and format settings
        if (!empty($event_data['date'])) {
            $full_date = self::formatEventDate($event_data['date'], $attributes);
        } else {
            $full_date = 'DATE TBA';
        }

        // Limit description length for better display
        if (strlen($description) > 200) {
            $description = substr($description, 0, 200) . '...';
        }

        // Format venue information
        $venue_info = '';
        if (!empty($event_data['venue'])) {
            $venue = $event_data['venue'];
            $venue_info = $venue['name'];
            if (!empty($venue['city']) && !empty($venue['state'])) {
                $venue_info .= ', ' . $venue['city'] . ', ' . $venue['state'];
            }
        }

        // Get attendees count
        $attendees_count = !empty($event_data['attendees_count']) ? $event_data['attendees_count'] : 0;
        $attendees_text = $attendees_count . ' attendee' . ($attendees_count !== 1 ? 's' : '');

        ob_start();
        ?>
        <article class="ep-single-event">
            <div class="ep-event-content">
                <div class="ep-event-info">
                    <div class="ep-event-top-content">

                        <div class="event-content">
                            <div class="ep-event-date"><?php echo wp_kses_post($full_date); ?></div>
                            <h3 class="ep-event-title">
                                <a href="<?php echo esc_url($link); ?>" target="_blank" rel="noopener">
                                    <?php echo esc_html($title); ?>
                                </a>
                            </h3>
                            <?php if (!empty($venue_info)): ?>
                                <div class="ep-event-venue">
                                    <span class="ep-venue-icon">📍</span>
                                    <?php echo esc_html($venue_info); ?>
                                </div>
                            <?php endif; ?>
                            <div class="ep-event-description">
                                <?php echo wp_kses_post($description); ?>
                            </div>
                        </div>
                        <?php if (!empty($event_data['image'])): ?>
                            <div class="ep-event-image">
                                <img src="<?php echo esc_url($event_data['image']); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy">
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="ep-event-footer">
                        <div class="ep-event-attendees">

                            <span class="ep-attendees-count"><?php echo esc_html($attendees_text); ?></span>
                        </div>
                        <a href="<?php echo esc_url($link); ?>" class="ep-attend-button" target="_blank" rel="noopener">
                            Attend
                        </a>
                    </div>
                </div>

            </div>
        </article>
        <?php
        return ob_get_clean();
    }

    /**
     * Hook for onAfterEmbed filter
     */
    public static function onAfterEmbed($html)
    {
        // This can be used to modify the HTML after embedding
        return $html;
    }

    /**
     * Hook for onBeforeEmbed filter
     */
    public static function onBeforeEmbed($html)
    {
        // This can be used to modify the HTML before embedding
        return $html;
    }

    /**
     * AJAX handler for load more events
     */
    public static function ajaxLoadMore()
    {
        // Verify nonce
        check_ajax_referer('ep_nonce', 'nonce');

        // Get parameters
        $embed_id = isset($_POST['embed_id']) ? sanitize_text_field($_POST['embed_id']) : '';
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 10;

        if (empty($embed_id)) {
            wp_send_json_error(['message' => 'Invalid embed ID']);
            return;
        }

        // Get all events and attributes from transient
        $transient_data = get_transient('embedpress_meetup_events_' . $embed_id);

        if (false === $transient_data || empty($transient_data)) {
            wp_send_json_error(['message' => 'Events data not found. Please refresh the page.']);
            return;
        }

        // Extract events and attributes
        $all_events = isset($transient_data['events']) ? $transient_data['events'] : $transient_data;
        $attributes = isset($transient_data['attributes']) ? $transient_data['attributes'] : [];

        // Paginate - get events for the requested page
        $offset = ($page - 1) * $per_page;
        $processed_events = array_slice($all_events, $offset, $per_page);

        // Generate HTML for events with attributes for timezone/format
        $html = '';
        foreach ($processed_events as $event_data) {
            $html .= self::generateSingleEventHtmlFromData($event_data, $attributes);
        }

        // Calculate if there are more events
        $has_more = count($all_events) > ($page * $per_page);

        wp_send_json_success([
            'html' => $html,
            'has_more' => $has_more,
            'next_page' => $page + 1,
            'total_events' => count($all_events)
        ]);
    }
}