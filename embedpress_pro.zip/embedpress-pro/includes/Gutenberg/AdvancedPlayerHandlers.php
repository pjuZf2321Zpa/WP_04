<?php

namespace Embedpress\Pro\Gutenberg;

use EmbedPress\Gutenberg\EmbedPressBlockRenderer;

(defined('ABSPATH') && defined('EMBEDPRESS_IS_LOADED')) or die("No direct script access allowed.");

/**
 * Pro implementations for the Gutenberg block's Custom Player advanced
 * features (Card 81243). The block controls live in free (gated as upsell
 * via ProBadge / Pro inspector slots), but feature behavior is wired here
 * via filters so disabling Pro removes all behavior — Pro keys never enter
 * the data-options blob and the renderer's CDN / privacy / country
 * restriction filters become no-ops.
 *
 * Filters consumed:
 *   - embedpress/gutenberg/advanced_player_options    (array, $attributes)
 *   - embedpress/gutenberg/country_restriction_html   (false|string, $attributes)
 *   - embedpress/gutenberg/cdn_rewrite_html           (string|array, $attributes)
 *   - embedpress/gutenberg/privacy_mode_html          (string|array, $attributes)
 */
class AdvancedPlayerHandlers
{
    public static function register()
    {
        add_filter('embedpress/gutenberg/advanced_player_options',  [self::class, 'build_options'], 10, 2);
        add_filter('embedpress/gutenberg/country_restriction_html', [self::class, 'country_restriction_check'], 10, 2);
        add_filter('embedpress/gutenberg/cdn_rewrite_html',         [self::class, 'apply_cdn_rewriting'], 10, 2);
        add_filter('embedpress/gutenberg/privacy_mode_html',        [self::class, 'apply_privacy_mode'], 10, 2);
    }

    /**
     * Inject Pro keys into the player options array.
     */
    public static function build_options($options, $attributes)
    {
        if (!is_array($options)) $options = [];

        $options['auto_resume'] = !empty($attributes['playerAutoResume']);
        $options['auto_resume_threshold'] = isset($attributes['playerAutoResumeThreshold']) ? (int) $attributes['playerAutoResumeThreshold'] : 30;
        $options['timed_cta'] = self::sanitize_timed_cta_items($attributes);
        $options['chapters'] = self::sanitize_chapters($attributes);
        $options['email_capture'] = self::build_email_capture_options($attributes);
        $options['action_lock'] = self::build_action_lock_options($attributes);
        $options['adaptive_streaming'] = !empty($attributes['playerAdaptiveStreaming']);
        $options['heatmap'] = !empty($attributes['playerHeatmap']) ? [
            'rest_url' => esc_url_raw(rest_url('embedpress/v1/heatmap/sample')),
            'nonce'    => wp_create_nonce('wp_rest'),
            'interval' => 30,
        ] : false;
        $options['lms_tracking'] = !empty($attributes['playerLmsTracking']) ? [
            'threshold' => isset($attributes['playerLmsThreshold']) ? max(50, min(99, (int) $attributes['playerLmsThreshold'])) : 90,
            'rest_url'  => esc_url_raw(rest_url('embedpress/v1/completion')),
            'nonce'     => wp_create_nonce('wp_rest'),
        ] : false;
        $options['privacy_mode'] = !empty($attributes['playerPrivacyMode']);
        $options['privacy_message'] = isset($attributes['playerPrivacyMessage']) ? sanitize_text_field($attributes['playerPrivacyMessage']) : '';
        // Defaults must match attributes.js schema. Gutenberg omits attribute
        // keys that equal the schema default from the saved block delimiter,
        // so isset() returns false and the displayable text would be lost —
        // empty End Screen overlay on the front-end.
        $options['end_screen'] = !empty($attributes['playerEndScreen']) ? [
            'mode'         => !empty($attributes['playerEndScreenMode']) ? sanitize_key($attributes['playerEndScreenMode']) : 'message',
            'message'      => !empty($attributes['playerEndScreenMessage']) ? wp_kses_post($attributes['playerEndScreenMessage']) : 'Thanks for watching!',
            'button_text'  => !empty($attributes['playerEndScreenButtonText']) ? sanitize_text_field($attributes['playerEndScreenButtonText']) : 'Learn more',
            'button_url'   => isset($attributes['playerEndScreenButtonUrl']) ? esc_url_raw($attributes['playerEndScreenButtonUrl']) : '',
            'redirect_url' => isset($attributes['playerEndScreenRedirectUrl']) ? esc_url_raw($attributes['playerEndScreenRedirectUrl']) : '',
            'countdown'    => isset($attributes['playerEndScreenCountdown']) ? max(0, (int) $attributes['playerEndScreenCountdown']) : 5,
            'show_replay'  => !isset($attributes['playerEndScreenShowReplay']) || !empty($attributes['playerEndScreenShowReplay']),
        ] : false;

        return $options;
    }

    /**
     * Country Restriction. Returns the restricted-fallback HTML, or the
     * passed-through $result (false) to render normally.
     */
    public static function country_restriction_check($result, $attributes)
    {
        if ($result !== false) return $result;
        if (empty($attributes['playerCountryRestriction'])) return false;

        $list_raw = isset($attributes['playerCountryList']) ? $attributes['playerCountryList'] : '';
        $codes = array_filter(array_map(function ($c) {
            return strtoupper(trim($c));
        }, explode(',', (string) $list_raw)));
        if (!$codes) return false;

        $mode = isset($attributes['playerCountryMode']) ? sanitize_key($attributes['playerCountryMode']) : 'block';
        if (!in_array($mode, ['allow', 'block'], true)) $mode = 'block';

        // Geo helper stays in free as shared infrastructure — it's not a
        // Pro feature itself, just a generic visitor-country lookup.
        $country = EmbedPressBlockRenderer::resolve_visitor_country_public();
        if (!$country) return false;

        if (function_exists('header') && !headers_sent()) header('Vary: CF-IPCountry', false);

        $in_list = in_array($country, $codes, true);
        $blocked = ($mode === 'allow') ? !$in_list : $in_list;
        if (!$blocked) return false;

        $message = isset($attributes['playerCountryMessage'])
            ? sanitize_text_field($attributes['playerCountryMessage'])
            : 'This video is not available in your country.';

        return '<div class="ep-country-restricted" role="status">'
            . '<div class="ep-country-restricted__inner"><p>'
            . esc_html($message)
            . '</p></div></div>';
    }

    public static function apply_cdn_rewriting($embed, $attributes)
    {
        $enabled = !isset($attributes['playerCdnEnabled']) || !empty($attributes['playerCdnEnabled']);
        if (!$enabled) return $embed;
        if (!class_exists('\Embedpress\Pro\Classes\CustomPlayer\CDN_Offloader')) return $embed;

        $rewrite = function ($html) {
            return preg_replace_callback('#(<(?:video|source)[^>]*?\\ssrc=("|\'))((?:https?:)?//[^"\']+)(\\2)#i', function ($m) {
                $cdn = \Embedpress\Pro\Classes\CustomPlayer\CDN_Offloader::cdn_url_for($m[3]);
                if (!$cdn) return $m[0];
                return $m[1] . esc_url($cdn) . $m[4];
            }, $html);
        };

        if (is_array($embed) && isset($embed['html'])) {
            $embed['html'] = $rewrite($embed['html']);
            return $embed;
        }
        return is_string($embed) ? $rewrite($embed) : $embed;
    }

    public static function apply_privacy_mode($embed, $attributes)
    {
        $active = !empty($attributes['customPlayer']) && !empty($attributes['playerPrivacyMode']);
        if (!$active) return $embed;

        $rewrite = function ($html) {
            return preg_replace_callback('#<iframe([^>]*?)\\ssrc=("|\')(.*?)\\2([^>]*)>#i', function ($m) {
                $original = $m[3];
                $stashed  = $original;
                if (strpos($stashed, 'youtube.com') !== false) {
                    $stashed = str_replace('youtube.com', 'youtube-nocookie.com', $stashed);
                }
                return '<iframe' . $m[1]
                    . ' src="about:blank"'
                    . ' data-ep-privacy-src="' . esc_attr($stashed) . '"'
                    . $m[4] . '>';
            }, $html);
        };

        if (is_array($embed) && isset($embed['html'])) {
            $embed['html'] = $rewrite($embed['html']);
            return $embed;
        }
        return is_string($embed) ? $rewrite($embed) : $embed;
    }

    private static function sanitize_timed_cta_items($attributes)
    {
        if (empty($attributes['playerTimedCTA']) || empty($attributes['playerTimedCTAItems']) || !is_array($attributes['playerTimedCTAItems'])) {
            return [];
        }
        $clean = [];
        foreach ($attributes['playerTimedCTAItems'] as $item) {
            if (!is_array($item)) continue;
            $time = isset($item['time']) ? max(0, (float) $item['time']) : 0;
            $headline = isset($item['headline']) ? sanitize_text_field($item['headline']) : '';
            $button_text = isset($item['button_text']) ? sanitize_text_field($item['button_text']) : '';
            $button_url = isset($item['button_url']) ? esc_url_raw($item['button_url']) : '';
            $duration = isset($item['duration']) ? max(0, (int) $item['duration']) : 0;
            $dismissible = !isset($item['dismissible']) || !empty($item['dismissible']);
            if (!$headline && !$button_text) continue;
            $clean[] = [
                'time'        => $time,
                'headline'    => $headline,
                'button_text' => $button_text,
                'button_url'  => $button_url,
                'duration'    => $duration,
                'dismissible' => $dismissible,
            ];
        }
        return $clean;
    }

    private static function sanitize_chapters($attributes)
    {
        if (empty($attributes['playerChapters']) || empty($attributes['playerChaptersItems']) || !is_array($attributes['playerChaptersItems'])) {
            return false;
        }
        $items = [];
        foreach ($attributes['playerChaptersItems'] as $item) {
            if (!is_array($item)) continue;
            $time = isset($item['time']) ? max(0, (float) $item['time']) : 0;
            $title = isset($item['title']) ? sanitize_text_field($item['title']) : '';
            if (!$title) continue;
            $items[] = ['time' => $time, 'title' => $title];
        }
        if (!$items) return false;
        usort($items, function ($a, $b) { return $a['time'] <=> $b['time']; });
        return [
            'items'      => $items,
            'show_title' => !isset($attributes['playerChaptersShowTitle']) || !empty($attributes['playerChaptersShowTitle']),
        ];
    }

    private static function build_action_lock_options($attributes)
    {
        if (empty($attributes['playerActionLock'])) return false;

        $bypass_admins = !isset($attributes['playerActionLockBypassAdmins']) || !empty($attributes['playerActionLockBypassAdmins']);
        if ($bypass_admins && current_user_can('manage_options')) return false;

        $type = isset($attributes['playerActionLockType']) ? sanitize_key($attributes['playerActionLockType']) : 'share';
        if (!in_array($type, ['share', 'link', 'login'], true)) $type = 'share';

        if ($type === 'login' && is_user_logged_in()) return false;

        $share_networks = ['facebook', 'twitter', 'linkedin'];
        if (!empty($attributes['playerActionLockShareNetworks']) && is_array($attributes['playerActionLockShareNetworks'])) {
            $share_networks = array_values(array_intersect(['facebook', 'twitter', 'linkedin'], $attributes['playerActionLockShareNetworks']));
            if (!$share_networks) $share_networks = ['facebook'];
        }

        $share_url = isset($attributes['playerActionLockShareUrl']) ? esc_url_raw($attributes['playerActionLockShareUrl']) : '';
        if (!$share_url) {
            $share_url = function_exists('home_url') ? esc_url_raw(home_url(add_query_arg(null, null))) : '';
        }

        return [
            'type'           => $type,
            'headline'       => isset($attributes['playerActionLockHeadline']) ? sanitize_text_field($attributes['playerActionLockHeadline']) : '',
            'message'        => isset($attributes['playerActionLockMessage']) ? sanitize_text_field($attributes['playerActionLockMessage']) : '',
            'share_networks' => $share_networks,
            'share_url'      => $share_url,
            'link_url'       => isset($attributes['playerActionLockLinkUrl']) ? esc_url_raw($attributes['playerActionLockLinkUrl']) : '',
            'link_text'      => isset($attributes['playerActionLockLinkText']) ? sanitize_text_field($attributes['playerActionLockLinkText']) : 'Open link',
            'login_url'      => function_exists('wp_login_url') ? esc_url_raw(wp_login_url(home_url(add_query_arg(null, null)))) : '',
        ];
    }

    private static function build_email_capture_options($attributes)
    {
        if (empty($attributes['playerEmailCapture'])) return false;
        $unit = isset($attributes['playerEmailCaptureUnit']) ? sanitize_key($attributes['playerEmailCaptureUnit']) : 'seconds';
        if (!in_array($unit, ['seconds', 'percent'], true)) $unit = 'seconds';
        return [
            'time'         => isset($attributes['playerEmailCaptureTime']) ? max(0, (float) $attributes['playerEmailCaptureTime']) : 30,
            'unit'         => $unit,
            'headline'     => !empty($attributes['playerEmailCaptureHeadline']) ? sanitize_text_field($attributes['playerEmailCaptureHeadline']) : 'Enter your email to keep watching',
            'require_name' => !empty($attributes['playerEmailCaptureRequireName']),
            'allow_skip'   => !empty($attributes['playerEmailCaptureAllowSkip']),
            'button_text'  => isset($attributes['playerEmailCaptureButtonText']) ? sanitize_text_field($attributes['playerEmailCaptureButtonText']) : 'Continue',
            'rest_url'     => esc_url_raw(rest_url('embedpress/v1/lead')),
            'nonce'        => wp_create_nonce('wp_rest'),
        ];
    }
}
