<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — PDF watermark registration.
 *
 * The watermark renderer itself is assets/pdf/ep-watermark.js. It runs inside
 * free's PDF.js viewer, which is a standalone HTML document served in an
 * iframe — there is no wp_enqueue_script hook for it, and its own extension
 * loader only resolves scripts sitting beside it, on free's origin.
 *
 * So this class does two things:
 *
 *   1. Tells free to request the "watermark" extension, by hooking
 *      `embedpress/pdf/viewer_extensions`. Free adds that name to the viewer
 *      URL's `ext` hash param.
 *   2. Makes sure the script is present in free's viewer directory, copying
 *      it there when missing or stale. The copy is cheap and guarded, and
 *      keeps the file in step across Pro updates.
 *
 * Free never requests the extension on its own, and the watermark_* params
 * the script reads are only emitted by free's renderers when
 * EMBEDPRESS_SL_ITEM_SLUG is defined — so the feature stays Pro-only on both
 * sides of the boundary.
 *
 * @package Embedpress\Pro\Filters
 */
class Pdf_Watermark_Pro
{
    /** Name free requests; must match a key in free's ep-extensions.js allowlist. */
    const EXTENSION = 'watermark';

    /** Filename inside free's viewer directory; must match that allowlist's value. */
    const SCRIPT = 'ep-watermark.js';

    /** Set while the script could not be copied into free's viewer directory. */
    const SYNC_FAILED_OPTION = 'embedpress_pro_watermark_sync_failed';

    public function __construct()
    {
        add_filter('embedpress/pdf/viewer_extensions', [$this, 'register_extension'], 10, 2);
        add_action('init', [$this, 'maybe_sync_script']);
        add_action('admin_notices', [$this, 'maybe_show_sync_notice']);
    }

    /** Absolute path of the copy inside free's viewer directory. */
    private static function target_path()
    {
        return defined('EMBEDPRESS_PATH_BASE') ? EMBEDPRESS_PATH_BASE . 'assets/pdf/web/' . self::SCRIPT : '';
    }

    /**
     * @param array $extensions
     * @param array $params The embed's viewer params, passed by free as the
     *                      second filter arg. Empty from older free versions.
     * @return array
     */
    public function register_extension($extensions, $params = [])
    {
        $extensions = is_array($extensions) ? $extensions : [];

        // An embed with no watermark text has nothing to draw, so don't make
        // its viewer load the script. Only skip when free told us the params;
        // without them (older free) keep requesting it as before.
        if (is_array($params) && array_key_exists('watermark_text', $params) && trim((string) $params['watermark_text']) === '') {
            return $extensions;
        }

        // Only ask the viewer for the watermark when the script is really in
        // free's directory. Otherwise (read-only deploy, or the window right
        // after a free update wiped the copy) every PDF would request a file
        // that 404s and the viewer would silently skip it.
        $target = self::target_path();
        if ($target !== '' && file_exists($target)) {
            $extensions[] = self::EXTENSION;
        }

        return $extensions;
    }

    /**
     * Copy the watermark script into free's viewer directory when it is
     * missing or older than the one shipped here.
     *
     * Runs on `init` rather than on every render so a normal page view does
     * no filesystem work beyond one mtime comparison.
     */
    public function maybe_sync_script()
    {
        $source = EMBEDPRESS_PRO_PLUGIN_PATH . '/assets/pdf/' . self::SCRIPT;

        if (!defined('EMBEDPRESS_PATH_BASE') || !file_exists($source)) {
            return;
        }

        $target_dir = EMBEDPRESS_PATH_BASE . 'assets/pdf/web/';
        $target     = $target_dir . self::SCRIPT;

        if (file_exists($target) && filemtime($target) >= filemtime($source)) {
            delete_option(self::SYNC_FAILED_OPTION);
            return;
        }

        // WP_Filesystem is the correct API here, but this runs on a hot-ish
        // path and only ever writes a plugin-owned file into a plugin-owned
        // directory, both on local disk.
        $copied = is_dir($target_dir) && is_writable($target_dir) && @copy($source, $target);

        if ($copied) {
            delete_option(self::SYNC_FAILED_OPTION);
        } else {
            // Remembered so admins get told (see maybe_show_sync_notice()) —
            // the watermark is off until the directory is writable.
            update_option(self::SYNC_FAILED_OPTION, $target_dir, false);
        }
    }

    /**
     * Tell administrators the PDF watermark is off because its script could
     * not be copied into the EmbedPress viewer directory.
     */
    public function maybe_show_sync_notice()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $dir = get_option(self::SYNC_FAILED_OPTION);
        if (empty($dir)) {
            return;
        }

        printf(
            '<div class="notice notice-warning"><p>%s</p></div>',
            sprintf(
                /* translators: %s: directory path */
                esc_html__('EmbedPress Pro: the PDF watermark is turned off because its script could not be copied into %s. Make that directory writable by the web server, then reload this page.', 'embedpress-pro'),
                '<code>' . esc_html($dir) . '</code>'
            )
        );
    }

    /**
     * Remove the copied script when Pro is deactivated, so free stops
     * shipping a file it does not own.
     */
    public static function on_deactivate()
    {
        if (!defined('EMBEDPRESS_PATH_BASE')) {
            return;
        }

        $target = EMBEDPRESS_PATH_BASE . 'assets/pdf/web/' . self::SCRIPT;

        if (file_exists($target)) {
            @unlink($target);
        }

        delete_option(self::SYNC_FAILED_OPTION);
    }
}
