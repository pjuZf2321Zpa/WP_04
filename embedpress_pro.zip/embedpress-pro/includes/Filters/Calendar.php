<?php

namespace Embedpress\Pro\Filters;

use Embedpress_Google_Helper;


if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Private Google Calendar (OAuth) — Pro owner.
 *
 * Free ships only the public-calendar iframe embed and neutral hooks; the
 * whole private-calendar implementation (OAuth client, AJAX event endpoint,
 * admin-post handlers, FullCalendar assets, settings form + save) lives in
 * includes/ThirdParty/Googlecalendar and is wired up here:
 *
 * - `embedpress_google_helper_shortcode` (action, free Gutenberg + Elementor
 *   render sites): enqueue the FullCalendar bundle and print the calendar.
 * - `embedpress/calendar/elementor_script_depends` /
 *   `embedpress/calendar/elementor_style_depends` (filters, free Elementor
 *   widget): asset handles the widget needs.
 * - `embedpress/settings/google_calendar_tab` (action, free settings
 *   template): the real settings form.
 * - `before_save_gcalendar_settings` (action, free settings save dispatch):
 *   persist the OAuth client + cache time + selected calendars.
 */
class Calendar
{
    public function __construct()
    {
        if (!\Embedpress\Pro\Classes\Bootstrap::free_has_contract()) {
            // EmbedPress <= 4.6.8 ships its own Embedpress_Google_Helper (no
            // enqueue_calendar_assets()) plus the settings form and assets.
            add_action('embedpress_google_helper_shortcode', [$this, 'legacy_free_shortcode'], 10);
            return;
        }

        if (!class_exists('Embedpress_Google_Helper', false)) {
            require_once EMBEDPRESS_PRO_PLUGIN_PATH . 'includes/ThirdParty/Googlecalendar/Embedpress_Google_Helper.php';
        }

        add_action('embedpress_google_helper_shortcode', [$this, 'embedpress_google_helper_shortcode'], 10);
        add_filter('embedpress/calendar/elementor_script_depends', [$this, 'elementor_script_depends']);
        add_filter('embedpress/calendar/elementor_style_depends', [$this, 'elementor_style_depends']);
        add_action('embedpress/settings/google_calendar_tab', [$this, 'render_settings_tab']);
        add_action('before_save_gcalendar_settings', [$this, 'save_settings']);
    }

    public function embedpress_google_helper_shortcode()
    {
        Embedpress_Google_Helper::enqueue_calendar_assets();
        echo Embedpress_Google_Helper::shortcode(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- attributes escaped inside shortcode()
    }

    /**
     * Pro 3.9.1 behaviour, for EmbedPress <= 4.6.8 (legacy-free mode).
     */
    public function legacy_free_shortcode()
    {
        if (class_exists('Embedpress_Google_Helper')) {
            echo Embedpress_Google_Helper::shortcode(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- attributes escaped inside shortcode()
        }
    }

    public function elementor_script_depends($depends)
    {
        // Register the handles (+ localization) before Elementor enqueues them.
        Embedpress_Google_Helper::enqueue_scripts();
        return array_merge((array) $depends, ['popper', 'tippy', 'my_moment', 'my_moment_timezone', 'fullcalendar', 'fullcalendar_moment', 'fullcalendar_moment_timezone', 'fullcalendar_daygrid', 'fullcalendar_timegrid', 'fullcalendar_list', 'fullcalendar_locales', 'epgc']);
    }

    public function elementor_style_depends($depends)
    {
        Embedpress_Google_Helper::enqueue_scripts();
        return array_merge((array) $depends, ['fullcalendar', 'fullcalendar_daygrid', 'fullcalendar_list', 'epgc', 'tippy_light']);
    }

    /**
     * @param string $nonce_field Settings-page nonce markup from free.
     */
    public function render_settings_tab($nonce_field = '')
    {
        include EMBEDPRESS_PRO_PLUGIN_PATH . 'includes/ThirdParty/Googlecalendar/templates/settings.php';
    }

    /**
     * Persist the Google Calendar settings form. Free's dispatcher has already
     * verified the `ep_settings_nonce` before firing this action.
     */
    public function save_settings()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- verified by the free dispatcher.
        $epgc_cache_time            = !empty($_POST['epgc_cache_time']) ? absint($_POST['epgc_cache_time']) : 0;
        $epgc_selected_calendar_ids = !empty($_POST['epgc_selected_calendar_ids']) ? array_map('sanitize_text_field', wp_unslash((array) $_POST['epgc_selected_calendar_ids'])) : [];

        // Two-field form: Client ID + Client Secret. Legacy: full JSON pasted
        // into epgc_client_secret. Accept both so sites upgrading mid-stream still save.
        $posted_client_id     = isset($_POST['epgc_client_id'])           ? sanitize_text_field(wp_unslash($_POST['epgc_client_id']))     : '';
        $posted_client_secret = isset($_POST['epgc_client_secret_value']) ? trim(wp_unslash($_POST['epgc_client_secret_value']))          : '';
        $posted_legacy_json   = isset($_POST['epgc_client_secret'])       ? trim(wp_unslash($_POST['epgc_client_secret']))                : '';
        // phpcs:enable

        $pretty_client_secret = '';

        if ($posted_client_id !== '' || $posted_client_secret !== '') {
            // Preserve the existing secret if the field was left blank (the UI
            // surfaces "Stored — leave blank to keep").
            $existing = json_decode(get_option('epgc_client_secret', ''), true);
            $effective_secret = $posted_client_secret !== ''
                ? $posted_client_secret
                : (isset($existing['web']['client_secret']) ? $existing['web']['client_secret'] : '');

            if ($posted_client_id !== '' && $effective_secret !== '') {
                $pretty_client_secret = Embedpress_Google_Helper::getPrettyJSONString([
                    'web' => [
                        'client_id'     => $posted_client_id,
                        'client_secret' => $effective_secret,
                        'redirect_uris' => [admin_url('admin.php?page=embedpress&page_type=google-calendar')],
                    ],
                ]);
            }
        } elseif ($posted_legacy_json !== '') {
            // Legacy full-JSON path (kept for backward compatibility).
            $decoded = json_decode($posted_legacy_json, true);
            if (!empty($decoded)) {
                $pretty_client_secret = Embedpress_Google_Helper::getPrettyJSONString($decoded);
            }
        }

        update_option('epgc_client_secret', $pretty_client_secret);
        update_option('epgc_cache_time', $epgc_cache_time);
        update_option('epgc_selected_calendar_ids', $epgc_selected_calendar_ids);
    }
}
