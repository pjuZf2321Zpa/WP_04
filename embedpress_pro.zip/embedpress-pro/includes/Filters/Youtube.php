<?php

namespace Embedpress\Pro\Filters;
use EmbedPress\Includes\Classes\Helper;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — YouTube channel Grid / Carousel layouts, plus the assets
 * for every Pro YouTube layout (channel and playlist).
 *
 * Free renders the Gallery / List channel layouts. It asks
 * `embedpress/youtube/channel_layouts` which layouts have a renderer,
 * `embedpress/youtube/channel_layout_args` for the wrapper of the picked one,
 * and fires `embedpress/youtube_{layout}_layout` for its item markup.
 * Styles and behaviour live in assets/css/youtube-layouts-pro.css +
 * assets/js/youtube-layouts-pro.js, enqueued wherever free's YouTube scripts
 * (`embedpress-yt-queue` / `embedpress-front`) are.
 */
class Youtube
{
    const PRO_CHANNEL_LAYOUTS = ['grid', 'carousel'];

    /** Free's YouTube script handles (Core/AssetManager.php). */
    const FREE_SCRIPT_HANDLES = ['embedpress-yt-queue', 'embedpress-front'];

    /** Free's main stylesheet handle. */
    const FREE_STYLE_HANDLE = 'embedpress-css';

    const HANDLE = 'embedpress-youtube-layouts-pro';

    public function __construct()
    {
        add_action('embedpress/youtube_grid_layout', [$this, 'youtube_grid_layout'], 10, 6);
        add_action('embedpress/youtube_carousel_layout', [$this, 'youtube_carousel_layout'], 10, 6);

        // EmbedPress <= 4.6.8 ships the Grid / Carousel / playlist-layout
        // styles and scripts itself (legacy-free mode).
        if (!\Embedpress\Pro\Classes\Bootstrap::free_has_contract()) {
            return;
        }

        add_filter('embedpress/youtube/channel_layouts', [$this, 'channel_layouts']);
        add_filter('embedpress/youtube/channel_layout_args', [$this, 'channel_layout_args'], 10, 3);

        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_assets', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        // Free may enqueue its frontend scripts late (content-dependent).
        add_action('wp_footer', [$this, 'maybe_enqueue'], 1);
    }

    public function channel_layouts($layouts)
    {
        return array_values(array_unique(array_merge((array) $layouts, self::PRO_CHANNEL_LAYOUTS)));
    }

    /**
     * Carousel wrapper: slider track class + selector attribute, arrow
     * buttons, and no pagination strip.
     */
    public function channel_layout_args($args, $layout, $channel_id)
    {
        if ($layout !== 'carousel') {
            return $args;
        }

        $args['content_wrap_class'] = 'youtube-carousel';
        $args['block_attributes']   = 'data-youtube-channel-carousel="carousel-' . esc_attr(md5($channel_id)) . '"';
        $args['show_pagination']    = false;
        // The controls div is closed by the block's own closing tag (markup
        // kept as it always shipped).
        $args['after_body_html'] = '<div class="carousel-controls">
                            <button class="preview" type="button" aria-label="' . esc_attr__('Previous', 'embedpress') . '"><span aria-hidden="true">❮</span></button>
                            <button class="next" type="button" aria-label="' . esc_attr__('Next', 'embedpress') . '"><span aria-hidden="true">❯</span></button>
                     ';

        return $args;
    }

    /**
     * The stylesheet follows free's `embedpress-css`; the script follows
     * free's YouTube scripts and loads after them. (In the block editor the
     * iframed canvas copies both stylesheets in from the editor page, in page
     * order — see the note at the top of the CSS file.)
     */
    public function maybe_enqueue()
    {
        if (wp_style_is(self::FREE_STYLE_HANDLE, 'enqueued')) {
            if (!wp_style_is(self::HANDLE, 'registered')) {
                wp_register_style(
                    self::HANDLE,
                    EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/youtube-layouts-pro.css',
                    [self::FREE_STYLE_HANDLE],
                    self::version('assets/css/youtube-layouts-pro.css')
                );
            }
            wp_enqueue_style(self::HANDLE);
        }

        $deps = [];
        foreach (self::FREE_SCRIPT_HANDLES as $handle) {
            if (wp_script_is($handle, 'enqueued')) {
                $deps[] = $handle;
            }
        }
        if (empty($deps)) {
            return;
        }

        if (!wp_script_is(self::HANDLE, 'registered')) {
            wp_register_script(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/youtube-layouts-pro.js',
                $deps,
                self::version('assets/js/youtube-layouts-pro.js'),
                true
            );
        } else {
            // A free handle enqueued after the first call: keep loading after it.
            $script = wp_scripts()->query(self::HANDLE, 'registered');
            if ($script) {
                $script->deps = array_values(array_unique(array_merge($script->deps, $deps)));
            }
        }

        wp_enqueue_script(self::HANDLE);
    }

    /** Plugin version, plus the file's mtime so edits bust caches. */
    private static function version($relative)
    {
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : '';
        $path = defined('EMBEDPRESS_PRO_PLUGIN_PATH') ? EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative : '';
        if ($path !== '' && file_exists($path)) {
            $version .= '.' . filemtime($path);
        }
        return $version;
    }

    /**
     * `data-vid-sig` for a card that opens free's video description popup.
     * Free (embedpress#306) refuses the popup's logged-out request without
     * it; a free version without the signer has no check, so emit nothing.
     */
    private function video_sig_attr($vid)
    {
        if (!method_exists(Helper::class, 'yt_video_sig')) {
            return '';
        }
        return ' data-vid-sig="' . esc_attr(Helper::yt_video_sig($vid)) . '"';
    }

    public function youtube_grid_layout($jsonResult, $gallobj, $options, $data, $channelTitle, $channelThumb)
    {
        if(empty($channelTitle)){
            $channelTitle = isset($data['get_channel_info']['snippet']['title']) ? $data['get_channel_info']['snippet']['title'] : '';
            $channelThumb = isset($data['get_channel_info']['snippet']['thumbnails']['default']['url']) ? $data['get_channel_info']['snippet']['thumbnails']['default']['url'] : '';
        }

        foreach ($jsonResult->items as $item) : ?>
            <?php
            $privacyStatus = isset($item->status->privacyStatus) ? $item->status->privacyStatus : null;
            $thumbnail = Helper::get_thumbnail_url($item, $options['thumbnail'], $privacyStatus);
            $vid = Helper::get_id($item);
            $videoTitle = isset($item->snippet->title) ? $item->snippet->title : '';
            $publishedAt = isset($item->snippet->publishedAt) ? $item->snippet->publishedAt : '';

            if (empty($gallobj->first_vid)) {
                $gallobj->first_vid = $vid;
            }
            if ($privacyStatus == 'private' && $options['hideprivate']) {
                continue;
            }
            ?>
            <div class="item" data-vid="<?php echo esc_attr($vid); ?>"<?php echo $this->video_sig_attr($vid); ?>>
                <div class="thumb" style="background: <?php echo "url({$thumbnail}) no-repeat center"; ?>">
                    <div class="play-icon">
                        <img src="<?php echo esc_url(EMBEDPRESS_URL_ASSETS. 'images/youtube.svg'); ?>" alt="">
                    </div>
                </div>
                <div class="body youtube-body-content">
                    <div class="description-container">
                        <div class="thumbnail"><img src="<?php echo esc_url($channelThumb ); ?>"/></div>
                        <div class="details">
                            <div class="channel"><?php echo esc_html($channelTitle); ?></div>
                            <div class="title"><?php echo esc_html(Helper::trimTitle($videoTitle, 6)); ?></div>
                            
                            <div class="views-time">
                                 <span class="time"><?php echo esc_html(Helper::timeAgo($publishedAt)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>            
            </div>
        <?php endforeach;
    }

    public function youtube_carousel_layout($jsonResult, $gallobj, $options, $data, $channelTitle, $channelThumb)
    {
        $channelTitle = $data['get_channel_info']['snippet']['title'];
        $channelThumb = $data['get_channel_info']['snippet']['thumbnails']['default']['url'];

        foreach ($jsonResult->items as $item) : ?>
            <?php
            $privacyStatus = isset($item->status->privacyStatus) ? $item->status->privacyStatus : null;
            $thumbnail = Helper::get_thumbnail_url($item, $options['thumbnail'], $privacyStatus);
            $vid = Helper::get_id($item);
            $videoTitle = isset($item->snippet->title) ? $item->snippet->title : '';
            $publishedAt = isset($item->snippet->publishedAt) ? $item->snippet->publishedAt : '';

            if (empty($gallobj->first_vid)) {
                $gallobj->first_vid = $vid;
            }
            if ($privacyStatus == 'private' && $options['hideprivate']) {
                continue;
            }
            ?>
            <div class="item" data-vid="<?php echo esc_attr($vid); ?>"<?php echo $this->video_sig_attr($vid); ?>>
                <div class="thumb" style="background: <?php echo "url({$thumbnail}) no-repeat center"; ?>">
                    <div class="play-icon">
                        <img src="<?php echo esc_url(EMBEDPRESS_URL_ASSETS. 'images/youtube.svg'); ?>" alt="">
                    </div>
                </div>
                <div class="body youtube-body-content">
                    <div class="description-container">
                        <div class="thumbnail"><img src="<?php echo esc_url($channelThumb ); ?>"/></div>
                        <div class="details">
                            <div class="channel"><?php echo esc_html($channelTitle); ?></div>
                            <div class="title"><?php echo esc_html(Helper::trimTitle($videoTitle, 6)); ?></div>
                            
                            <div class="views-time">
                                 <span class="time"><?php echo esc_html(Helper::timeAgo($publishedAt)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>            
            </div>
        <?php endforeach;
    }

}
