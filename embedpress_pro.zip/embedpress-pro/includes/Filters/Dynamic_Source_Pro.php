<?php

namespace Embedpress\Pro\Filters;

use Embedpress\Pro\Classes\DynamicFieldResolver;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Dynamic Source resolver provider.
 *
 * Dynamic Source resolves an embed URL from a custom-field source (ACF,
 * MetaBox, Pods, Toolset, JetEngine, raw post meta). Free keeps a stub entry
 * point — EmbedPress\Includes\Classes\DynamicFieldResolver — because nine call
 * sites in the free render path reference it, two of them as REST string
 * callables that would break loudly if the class disappeared. That stub asks
 * for the real implementation through `embedpress/dynamic_source/resolver`,
 * and this class answers.
 *
 * The underlying Pro resolver is a static utility; this adapter wraps it so
 * free can call plain instance methods and stay agnostic about how Pro
 * implements it.
 *
 * @package Embedpress\Pro\Filters
 */
class Dynamic_Source_Pro
{
    public function __construct()
    {
        add_filter('embedpress/dynamic_source/resolver', [$this, 'provide_resolver']);
    }

    /**
     * @param object|null $resolver
     * @return object
     */
    public function provide_resolver($resolver)
    {
        return $this;
    }

    /**
     * @param string   $source
     * @param string   $field
     * @param int|null $post_id
     * @return string
     */
    public function resolve_field($source, $field, $post_id = null)
    {
        return DynamicFieldResolver::resolve_field($source, $field, $post_id);
    }

    /**
     * @param string $dynamic_value
     * @return string
     */
    public function resolve_elementor_dynamic($dynamic_value)
    {
        return DynamicFieldResolver::resolve_elementor_dynamic($dynamic_value);
    }

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function rest_list_fields(\WP_REST_Request $request)
    {
        return DynamicFieldResolver::rest_list_fields($request);
    }

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function rest_resolve_field(\WP_REST_Request $request)
    {
        return DynamicFieldResolver::rest_resolve_field($request);
    }
}
