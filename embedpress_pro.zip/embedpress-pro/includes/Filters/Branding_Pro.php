<?php

namespace Embedpress\Pro\Filters;

use EmbedPress\Includes\Classes\Elementor_Enhancer;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Custom Branding (logo + call-to-action overlay).
 *
 * Free renders no branding. It exposes two neutral filters and this class
 * answers them:
 *
 *   - `embedpress/branding/markup` — server-rendered Gutenberg blocks
 *     (EmbedPressBlockRenderer::build_custom_branding()). Receives
 *     ['html' => '', 'styles' => ''] plus the block attributes and returns the
 *     overlay markup and its CSS.
 *   - `embedpress/branding/elementor_markup` — Elementor widgets, through
 *     free's Elementor_Enhancer::apply_cta_markup() entry point. Receives the
 *     embed object and returns it with the overlay injected.
 *
 * Pro's own Elementor provider filters (Elementor_Enhancer_Pro) call
 * apply_cta_markup() here directly.
 *
 * @package Embedpress\Pro\Filters
 */
class Branding_Pro
{
    public function __construct()
    {
        add_filter('embedpress/branding/markup', [$this, 'block_markup'], 10, 3);
        add_filter('embedpress/branding/elementor_markup', [static::class, 'apply_cta_markup'], 10, 3);
    }

    /**
     * Custom logo overlay for a server-rendered Gutenberg block.
     *
     * @param array $custom_branding ['html' => string, 'styles' => string]
     * @param array $attributes      Block attributes.
     * @param array $context         ['surface' => 'gutenberg', 'client_id' => string]
     * @return array
     */
    public function block_markup($custom_branding, $attributes, $context = [])
    {
        $custom_branding = is_array($custom_branding) ? $custom_branding : [];
        $custom_branding += ['html' => '', 'styles' => ''];

        // Check if custom logo is enabled
        if (empty($attributes['customlogo'])) {
            return $custom_branding;
        }

        $client_id = isset($context['client_id']) ? $context['client_id'] : '';

        $logo_url = $attributes['customlogo'];
        $logo_x = $attributes['logoX'] ?? 5;
        $logo_y = $attributes['logoY'] ?? 10;
        $logo_opacity = $attributes['logoOpacity'] ?? 1;
        $custom_logo_url = $attributes['customlogoUrl'] ?? '';

        // Generate custom logo styles
        $custom_branding['styles'] = sprintf(
            '#ep-gutenberg-content-%s img.watermark {
                border: 0;
                position: absolute;
                bottom: %s%%;
                right: %s%%;
                max-width: 150px;
                max-height: 75px;
                -o-transition: opacity 0.5s ease-in-out;
                -moz-transition: opacity 0.5s ease-in-out;
                -webkit-transition: opacity 0.5s ease-in-out;
                transition: opacity 0.5s ease-in-out;
                z-index: 1;
                opacity: %s;
            }
            #ep-gutenberg-content-%s img.watermark:hover {
                opacity: 1;
            }',
            esc_attr($client_id),
            esc_attr($logo_y),
            esc_attr($logo_x),
            esc_attr($logo_opacity),
            esc_attr($client_id)
        );

        // Generate custom logo HTML
        $logo_html = sprintf(
            '<img decoding="async" src="%s" class="watermark ep-custom-logo" width="auto" height="auto" alt="">',
            esc_url($logo_url)
        );

        // Wrap with link if URL is provided
        if (!empty($custom_logo_url)) {
            $logo_html = sprintf(
                '<a href="%s" target="_blank">%s</a>',
                esc_url($custom_logo_url),
                $logo_html
            );
        }

        $custom_branding['html'] = $logo_html;

        return $custom_branding;
    }

    /**
     * Inject the logo / CTA overlay into an Elementor embed.
     *
     * @param object $embed         Embed object; $embed->embed holds the HTML.
     * @param array  $settings      Elementor widget settings.
     * @param string $provider_name Provider slug, e.g. 'youtube'.
     * @return object
     */
	public static function apply_cta_markup( $embed, $settings, $provider_name = '' ) {
		
		if ( empty( $settings["embedpress_pro_{$provider_name}_logo"] ) || empty( $settings["embedpress_pro_{$provider_name}_logo"]['url'] ) ) {
			return $embed;
		}
		$img = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, "embedpress_pro_{$provider_name}_logo" );
		if ( empty( $img ) ) {
			return $embed;
		}

		$cta    = '';
		$url    = '';
		$target = '';
		$x      = ! empty( $settings["embedpress_pro_{$provider_name}_logo_xpos"] ) && ! empty( $settings["embedpress_pro_{$provider_name}_logo_xpos"]['unit'] ) ? $settings["embedpress_pro_{$provider_name}_logo_xpos"]['size'] . $settings["embedpress_pro_{$provider_name}_logo_xpos"]['unit'] : '10%';

		$y        = ! empty( $settings["embedpress_pro_{$provider_name}_logo_ypos"] ) && ! empty( $settings["embedpress_pro_{$provider_name}_logo_ypos"]['unit'] ) ?  $settings["embedpress_pro_{$provider_name}_logo_ypos"]['size'] . $settings["embedpress_pro_{$provider_name}_logo_ypos"]['unit'] : '10%';
		$cssClass = isset( $embed->url ) ? '.ose-uid-' . md5( $embed->url ) : ".ose-{$provider_name}";
		ob_start();
		?>
        <style type="text/css">
            .ep-embed-content-wraper .watermark {
                text-align: left;
                position: relative;
            }
            .ep-embed-content-wraper .watermark {
                border: 0;
                position: absolute;
                bottom: 10%;
                right: 5%;
                max-width: 150px;
                max-height: 75px;
                opacity: 0.35!important;
                z-index: 5;
                -o-transition: opacity 0.5s ease-in-out;
                -moz-transition: opacity 0.5s ease-in-out;
                -webkit-transition: opacity 0.5s ease-in-out;
                transition: opacity 0.5s ease-in-out;
            }

			<?php echo esc_html($cssClass); ?> .watermark {
				bottom: <?php echo esc_html($y); ?>;
                right: <?php echo esc_html($x); ?>;
			}	

			.ep-embed-content-wraper .watermark:hover {
                opacity: 1!important;
            }
        </style>
		<?php
		$style = ob_get_clean();

		if ( ! class_exists( '\simple_html_dom' ) ) {
			include_once EMBEDPRESS_PATH_CORE . 'simple_html_dom.php';
		}

		if ( ! empty( $settings["embedpress_pro_{$provider_name}_cta"] ) && ! empty( $settings["embedpress_pro_{$provider_name}_cta"]['url'] ) ) {
			$url = $settings["embedpress_pro_{$provider_name}_cta"]['url'];
		}

		if ( $url ) {
			$atts       = Elementor_Enhancer::get_link_attributes( $settings["embedpress_pro_{$provider_name}_cta"] );
			$attributes = '';
			foreach ( $atts as $att => $value ) {
				$attributes .= $att . '="' . esc_attr( $value ) . '" ';
			}
			$cta .= sprintf( '<a %s>', trim( $attributes ) );
		}


		$imgDom = str_get_html( $img );
		$imgDom = $imgDom->find( 'img', 0 );
		$imgDom->setAttribute( 'class', 'watermark' );
		$imgDom->removeAttribute( 'style' );
		$imgDom->setAttribute( 'width', 'auto' );
		$imgDom->setAttribute( 'height', 'auto' );
		ob_start();
		echo $imgDom;
		$cta .= ob_get_clean();
		$imgDom->clear();
		unset( $img, $imgDom );

		if ( $url ) {
			$cta .= '</a>';
		}
		$dom     = str_get_html( $embed->embed );
		$wrapDiv = $dom->find( "div.ose-{$provider_name}", 0 );
		if ( ! empty( $wrapDiv ) && is_object( $wrapDiv ) ) {
			$wrapDiv->innertext .= $cta;
		}

		ob_start();
		echo $wrapDiv;
		$markup = ob_get_clean();
		$dom->clear();
		unset( $dom, $wrapDiv );

		$embed->embed = $style . $markup;

		return $embed;
	}
}
