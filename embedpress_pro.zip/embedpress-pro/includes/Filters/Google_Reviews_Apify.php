<?php

namespace Embedpress\Pro\Filters;

use EmbedPress\Includes\Classes\GoogleReviewsRenderer;
use EmbedPress\Includes\Classes\GoogleReviewsStore;
use EmbedPress\Includes\Classes\GoogleReviewsApify as FreeApify;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Background, batched Apify fetch for "Fetch all reviews".
 *
 * Fetching all reviews for a place can return hundreds of items — too slow for
 * one synchronous request (Apify run-sync hard-caps at 300s). So instead:
 *
 *   1. start_job(): POST an ASYNC Apify run (returns immediately with a run id),
 *      mark the place fetch_status=running.
 *   2. WP-cron (ep_gr_poll_apify) polls the run; once SUCCEEDED, it pages the
 *      dataset in BATCHES (PAGE_SIZE at a time), appending each batch to the DB
 *      store and updating fetched_so_far, then reschedules itself until the
 *      whole dataset is imported. status→done.
 *
 * The admin UI shows live progress ("fetching… N so far"); the block always
 * renders whatever is already stored (never blocked on the fetch).
 */
class Google_Reviews_Apify
{
    const ACTOR        = 'compass~google-maps-reviews-scraper';
    const CRON_HOOK    = 'ep_gr_poll_apify';
    const PAGE_SIZE    = 100;   // reviews imported per cron tick
    const MAX_TOTAL    = 1000;  // safety ceiling per place

    public function __construct()
    {
        // Cron callback + pre_fetch + start_fetch_job filters moved to free
        // (EmbedPress\Includes\Classes\GoogleReviewsApify) so refetch works
        // without Pro. This class is kept only so static call sites
        // (Google_Reviews_Apify::map_items / ::start_job) inside
        // Google_Reviews_Pro keep resolving on older builds; both now
        // delegate to the free class below.
    }

    public static function api_base(): string
    {
        return 'https://api.apify.com/v2';
    }

    /**
     * Kick off an async Apify run for a place and mark the job running.
     * Returns true if the run started, false (with a stored error) otherwise.
     */
    public static function start_job(string $place_id, array $args = []): bool
    {
        $token = GoogleReviewsRenderer::get_apify_token();
        if ($token === '' || $place_id === '') {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_FAILED, ['message' => __('No Apify token configured.', 'embedpress')]);
            return false;
        }

        // Ceiling is the hard safety cap; the user's chosen count (fetch_max)
        // lowers it so they control how many reviews — and thus how much Apify
        // cost — each refetch incurs. fetch_max = 0 (or unset) means "all up to
        // the ceiling".
        $ceiling   = (int) apply_filters('embedpress/google_reviews/apify_ceiling', self::MAX_TOTAL, $place_id, $args);
        $fetch_max = isset($args['fetch_max']) ? (int) $args['fetch_max'] : 0;
        $max       = ($fetch_max > 0) ? min($fetch_max, $ceiling) : $ceiling;

        $payload = [
            'startUrls'   => [['url' => 'https://www.google.com/maps/place/?q=place_id:' . $place_id]],
            'placeIds'    => [$place_id],
            'maxReviews'  => $max,
            'language'    => 'en',
            'reviewsSort' => self::sort_param($args),
        ];

        // Pin memory so the run fits Apify's free 8192MB plan. The reviews-scraper
        // defaults to 1024MB; we keep that explicit (filterable for paid plans
        // that want more for faster/bigger fetches). Without pinning, an actor
        // default bump or an overlapping run can trip "you will exceed the memory
        // limit". See embedpress/google_reviews/apify_search_memory (search side).
        $memory   = (int) apply_filters('embedpress/google_reviews/apify_fetch_memory', 1024, $place_id, $args);
        $endpoint = self::api_base() . '/acts/' . self::ACTOR . '/runs?token=' . rawurlencode($token);
        if ($memory > 0) {
            $endpoint .= '&memory=' . $memory;
        }
        $response = wp_remote_post($endpoint, [
            'timeout' => 20,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_FAILED, ['message' => $response->get_error_message()]);
            return false;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (($code !== 200 && $code !== 201) || empty($body['data']['id'])) {
            $msg = $body['error']['message'] ?? sprintf(__('Apify returned HTTP %d.', 'embedpress'), $code);
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_FAILED, ['message' => $msg]);
            return false;
        }

        // Fresh job → clear the stored set so this refresh REPLACES the reviews
        // (batches append as they import; without the reset they'd stack on top
        // of the previous fetch and inflate the count).
        GoogleReviewsStore::reset_reviews($place_id);

        $run_id = (string) $body['data']['id'];
        GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_RUNNING, [
            'run_id'  => $run_id,
            'message' => __('Starting…', 'embedpress'),
            'so_far'  => 0,
        ]);

        self::schedule_poll($place_id, 15);
        return true;
    }

    /** Schedule a one-off poll for a place after $delay seconds. */
    public static function schedule_poll(string $place_id, int $delay = 30): void
    {
        if (!wp_next_scheduled(self::CRON_HOOK, [$place_id])) {
            wp_schedule_single_event(time() + max(5, $delay), self::CRON_HOOK, [$place_id]);
        }
    }

    /**
     * Cron callback. Check the run; when finished, import one batch of dataset
     * items and reschedule until the whole dataset is in the DB.
     */
    public function poll_job($place_id)
    {
        $place_id = (string) $place_id;
        $row = GoogleReviewsStore::get($place_id);
        if (!$row || ($row['fetch_status'] ?? '') !== GoogleReviewsStore::STATUS_RUNNING) {
            return; // cancelled / already done
        }
        $token  = GoogleReviewsRenderer::get_apify_token();
        $run_id = (string) ($row['fetch_run_id'] ?? '');
        if ($token === '' || $run_id === '') {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_FAILED, ['message' => __('Lost run reference.', 'embedpress')]);
            return;
        }

        // 1) Check run status.
        $run = self::get_json(self::api_base() . '/actor-runs/' . rawurlencode($run_id) . '?token=' . rawurlencode($token));
        $status = $run['data']['status'] ?? 'UNKNOWN';

        if (in_array($status, ['READY', 'RUNNING'], true)) {
            // still working — check again shortly
            self::schedule_poll($place_id, 20);
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_RUNNING, ['message' => __('Fetching from Google…', 'embedpress')]);
            return;
        }
        if ($status !== 'SUCCEEDED') {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_FAILED, ['message' => sprintf(__('Apify run %s.', 'embedpress'), strtolower($status))]);
            return;
        }

        $dataset_id = $run['data']['defaultDatasetId'] ?? '';
        if ($dataset_id === '') {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_FAILED, ['message' => __('No dataset produced.', 'embedpress')]);
            return;
        }

        // 2) Import one batch starting at the current offset (fetched_so_far).
        $offset = (int) ($row['fetched_so_far'] ?? 0);
        $items  = self::get_json(
            self::api_base() . '/datasets/' . rawurlencode($dataset_id) . '/items'
            . '?clean=true&format=json&offset=' . $offset . '&limit=' . self::PAGE_SIZE
            . '&token=' . rawurlencode($token)
        );

        if (!is_array($items) || empty($items)) {
            // Nothing more → finalize.
            GoogleReviewsStore::append_reviews($place_id, [], [], 'apify', true);
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_DONE, ['message' => null, 'run_id' => null]);
            return;
        }

        $mapped = self::map_items($items);
        $meta   = !empty($row['meta']) && empty($row['meta']['name']) === false ? $row['meta'] : $mapped['meta'];

        // Append this batch; final if we got a short page (< PAGE_SIZE) or hit the ceiling.
        $reached_end = count($items) < self::PAGE_SIZE || ($offset + count($items)) >= self::MAX_TOTAL;
        GoogleReviewsStore::append_reviews($place_id, $mapped['reviews'], $meta, 'apify', $reached_end);

        if ($reached_end) {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_DONE, ['message' => null, 'run_id' => null]);
        } else {
            GoogleReviewsStore::set_job($place_id, GoogleReviewsStore::STATUS_RUNNING, [
                'message' => sprintf(__('Imported %d…', 'embedpress'), $offset + count($items)),
            ]);
            self::schedule_poll($place_id, 8);
        }
    }

    /* ── helpers ──────────────────────────────────────────────────────── */

    private static function get_json(string $url)
    {
        $res = wp_remote_get($url, ['timeout' => 30, 'headers' => ['Accept' => 'application/json']]);
        if (is_wp_error($res)) {
            return null;
        }
        return json_decode(wp_remote_retrieve_body($res), true);
    }

    private static function sort_param(array $args): string
    {
        switch (isset($args['sort']) ? (string) $args['sort'] : 'newest') {
            case 'highest':  return 'highestRanking';
            case 'lowest':   return 'lowestRanking';
            case 'relevant': return 'mostRelevant';
            default:         return 'newest';
        }
    }

    /**
     * Map Apify dataset items → {reviews, meta}, same shape EmbedPress uses.
     */
    public static function map_items(array $items): array
    {
        $reviews = [];
        $meta    = [];
        foreach ($items as $it) {
            if (!is_array($it)) {
                continue;
            }
            if (empty($meta)) {
                $meta = [
                    'name'    => (string) ($it['title'] ?? $it['placeName'] ?? ''),
                    'rating'  => isset($it['totalScore']) ? (float) $it['totalScore'] : 0.0,
                    'total'   => isset($it['reviewsCount']) ? (int) $it['reviewsCount'] : 0,
                    'address' => (string) ($it['address'] ?? ''),
                ];
            }
            $stars = isset($it['stars']) ? (int) $it['stars'] : 0;
            if ($stars < 1) {
                continue;
            }
            $time = 0;
            if (!empty($it['publishedAtDate'])) {
                $t = strtotime((string) $it['publishedAtDate']);
                $time = $t ? $t : 0;
            }
            // Rich fields (Apify-only — Google's official API never returns
            // these). Each is optional; the renderer renders them only when
            // present, so API-sourced reviews simply omit them.
            $images = [];
            if (!empty($it['reviewImageUrls']) && is_array($it['reviewImageUrls'])) {
                foreach ($it['reviewImageUrls'] as $img) {
                    $u = esc_url_raw((string) $img);
                    if ($u !== '') {
                        $images[] = $u;
                    }
                }
            }

            $reviews[] = [
                'author_name'          => (string) ($it['name'] ?? __('Google user', 'embedpress')),
                'rating'               => $stars,
                'text'                 => (string) ($it['text'] ?? $it['textTranslated'] ?? ''),
                'time'                 => $time,
                'relative_time'        => (string) ($it['publishAt'] ?? ''),
                'profile_photo_url'    => !empty($it['reviewerPhotoUrl']) ? esc_url_raw((string) $it['reviewerPhotoUrl']) : '',
                // Rich (Apify):
                'is_local_guide'       => !empty($it['isLocalGuide']),
                'reviewer_reviews'     => isset($it['reviewerNumberOfReviews']) ? (int) $it['reviewerNumberOfReviews'] : 0,
                'likes'                => isset($it['likesCount']) ? (int) $it['likesCount'] : 0,
                'images'               => $images,
                'owner_response'       => (string) ($it['responseFromOwnerText'] ?? ''),
                'owner_response_time'  => (string) ($it['responseFromOwnerDate'] ?? ''),
            ];
        }
        return ['reviews' => $reviews, 'meta' => $meta];
    }
}
