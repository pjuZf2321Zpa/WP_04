<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — PDF Gallery Carousel and Bookshelf layouts.
 *
 * Free's PDF Gallery (block, shortcode, Elementor widget) renders Grid and
 * Masonry itself and asks for any other layout through hooks:
 *
 *   PHP  `embedpress/pdf_gallery/layouts`        layouts this install renders
 *        `embedpress/pdf_gallery/layout_markup`  wrapper markup + attributes
 *   JS   window.EmbedPressPdfGalleryLayouts      frontend layout registry
 *        `embedpress.pdfGallery.layouts`         (wp.hooks) editor layouts
 *        `embedpress.pdfGallery.editorLayout`    (wp.hooks) editor preview
 *
 * This class registers Carousel and Bookshelf on all of them and enqueues
 * their implementation (assets/js/pdf-gallery-layouts.js,
 * assets/css/pdf-gallery-layouts.css, assets/js/pdf-gallery-layouts-editor.js)
 * wherever free loads its PDF Gallery assets.
 *
 * @package Embedpress\Pro\Filters
 */
class Pdf_Gallery_Layouts_Pro
{
    const LAYOUTS = ['carousel', 'bookshelf'];

    /** Free's PDF Gallery handles. */
    const FREE_SCRIPT = 'embedpress-pdf-gallery';
    const FREE_STYLE  = 'embedpress-pdf-gallery-css';

    const SCRIPT        = 'embedpress-pro-pdf-gallery-layouts';
    const STYLE         = 'embedpress-pro-pdf-gallery-layouts';
    const EDITOR_SCRIPT = 'embedpress-pro-pdf-gallery-layouts-editor';

    public function __construct()
    {
        add_filter('embedpress/pdf_gallery/layouts', [$this, 'register_layouts']);
        add_filter('embedpress/pdf_gallery/layout_markup', [$this, 'layout_markup'], 10, 4);

        // Free enqueues its gallery assets at priority 5 on these hooks.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets'], 20);
        add_action('enqueue_block_assets', [$this, 'enqueue_assets'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_assets'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_assets'], 20);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueue_assets'], 20);
        // Elementor enqueues widget dependencies while rendering the content.
        add_action('wp_footer', [$this, 'enqueue_assets'], 5);

        add_action('enqueue_block_editor_assets', [$this, 'enqueue_editor_script']);
    }

    /**
     * @param string[] $layouts
     * @return string[]
     */
    public function register_layouts($layouts)
    {
        $layouts = is_array($layouts) ? $layouts : [];

        return array_values(array_unique(array_merge($layouts, self::LAYOUTS)));
    }

    /**
     * Carousel markup (Bookshelf starts from the same markup; the frontend
     * script rebuilds it into shelves).
     *
     * @param array  $markup
     * @param string $layout
     * @param array  $attributes
     * @param string $context
     * @return array
     */
    public function layout_markup($markup, $layout, $attributes, $context)
    {
        if (!in_array($layout, self::LAYOUTS, true)) {
            return $markup;
        }

        $markup = is_array($markup) ? $markup : [];
        $a      = is_array($attributes) ? $attributes : [];

        $markup['attributes'] = 'data-carousel-options="' . esc_attr(wp_json_encode($this->carousel_options($a, $context))) . '"';
        $markup['open']       = '<div class="ep-pdf-gallery__carousel">' . "\n" . '                <div class="ep-pdf-gallery__carousel-track">';
        $markup['close']      = '</div>
                <button class="ep-pdf-gallery__carousel-prev" aria-label="Previous">
                    <svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>
                </button>
                <button class="ep-pdf-gallery__carousel-next" aria-label="Next">
                    <svg viewBox="0 0 24 24"><path d="M8.59 16.59L10 18l6-6-6-6-1.41 1.41L13.17 12z"/></svg>
                </button>
                <div class="ep-pdf-gallery__carousel-dots"></div>
            </div>';

        return $markup;
    }

    /**
     * Carousel options per surface, from that surface's attribute names.
     *
     * @param array  $a
     * @param string $context
     * @return array
     */
    private function carousel_options($a, $context)
    {
        if ($context === 'shortcode_gallery') {
            return [
                'autoplay'      => (isset($a['carousel_autoplay']) ? $a['carousel_autoplay'] : '') === 'true',
                'autoplaySpeed' => intval(isset($a['carousel_speed']) ? $a['carousel_speed'] : 0),
                'loop'          => (isset($a['carousel_loop']) ? $a['carousel_loop'] : '') !== 'false',
                'arrows'        => (isset($a['carousel_arrows']) ? $a['carousel_arrows'] : '') !== 'false',
                'dots'          => (isset($a['carousel_dots']) ? $a['carousel_dots'] : '') === 'true',
                'slidesPerView' => intval(isset($a['slides_per_view']) ? $a['slides_per_view'] : 0),
            ];
        }

        if ($context === 'elementor_gallery') {
            return [
                'autoplay'      => !empty($a['carousel_autoplay']),
                'autoplaySpeed' => !empty($a['carousel_speed']) ? intval($a['carousel_speed']) : 3000,
                'loop'          => (isset($a['carousel_loop']) ? $a['carousel_loop'] : null) !== '',
                'arrows'        => (isset($a['carousel_arrows']) ? $a['carousel_arrows'] : null) !== '',
                'dots'          => !empty($a['carousel_dots']),
                'slidesPerView' => !empty($a['slides_per_view']) ? intval($a['slides_per_view']) : 3,
            ];
        }

        // gutenberg_gallery (block attributes).
        return [
            'autoplay'      => !empty($a['carouselAutoplay']),
            'autoplaySpeed' => isset($a['carouselAutoplaySpeed']) ? intval($a['carouselAutoplaySpeed']) : 3000,
            'loop'          => isset($a['carouselLoop']) ? (bool) $a['carouselLoop'] : true,
            'arrows'        => isset($a['carouselArrows']) ? (bool) $a['carouselArrows'] : true,
            'dots'          => !empty($a['carouselDots']),
            'slidesPerView' => isset($a['slidesPerView']) ? intval($a['slidesPerView']) : 3,
        ];
    }

    /**
     * Load the layout script / styles wherever free's PDF Gallery script /
     * styles are enqueued, after them.
     */
    public function enqueue_assets()
    {
        if (wp_script_is(self::FREE_SCRIPT, 'enqueued') && !wp_script_is(self::SCRIPT, 'enqueued')) {
            wp_enqueue_script(
                self::SCRIPT,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/pdf-gallery-layouts.js',
                [self::FREE_SCRIPT],
                EMBEDPRESS_PRO_PLUGIN_VERSION,
                true
            );
        }

        if (wp_style_is(self::FREE_STYLE, 'enqueued') && !wp_style_is(self::STYLE, 'enqueued')) {
            wp_enqueue_style(
                self::STYLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/pdf-gallery-layouts.css',
                [self::FREE_STYLE],
                EMBEDPRESS_PRO_PLUGIN_VERSION
            );
        }
    }

    /** Block editor: Carousel / Bookshelf previews for the PDF Gallery block. */
    public function enqueue_editor_script()
    {
        wp_enqueue_script(
            self::EDITOR_SCRIPT,
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/pdf-gallery-layouts-editor.js',
            ['wp-hooks', 'wp-element'],
            EMBEDPRESS_PRO_PLUGIN_VERSION,
            true
        );
    }
}
