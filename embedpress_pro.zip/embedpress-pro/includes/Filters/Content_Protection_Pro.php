<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Content Protection (password / user-role gate).
 *
 * Free keeps the block / widget / shortcode attributes, the locked upsell
 * controls and two neutral hooks at its render sites:
 *
 *   - `embedpress/content_protection/is_locked` (bool) — asked by the
 *     Gutenberg renderer and the Elementor widgets. Free's default is
 *     `false`, so without Pro every embed renders. When this class answers
 *     `true`, free prints the lock UI through the actions
 *     `embedpress/display_password_form` / `embedpress/content_protection_content`,
 *     which are also answered here.
 *   - `embedpress/content_protection/gate` (string|null) — asked by the
 *     `[embedpress]` / `[embedpress_pdf]` shortcodes. Returning a string makes
 *     free output it instead of the embed.
 *
 * Everything that actually protects content lives here: the lock form, the
 * role message, the AES-128-CBC encryption of the embed into post meta, the
 * unlock AJAX endpoints, the cookie check, the role checks and the frontend
 * script that submits the form (assets/js/content-protection.js).
 *
 * Wire-compatible with the pre-split implementation: same AJAX action names,
 * form markup, CSS classes, post-meta keys (`ep_base_<client_id>`,
 * `hash_key_<client_id>`), hash option (`embedpress_hash_key`) and cookie
 * (`password_correct_<client_id>`), so already-unlocked visitors and saved
 * embeds keep working.
 *
 * @package Embedpress\Pro\Filters
 */
class Content_Protection_Pro
{
    const SCRIPT_HANDLE = 'embedpress-content-protection';

    /**
     * Legacy-free mode (EmbedPress <= 4.6.8, see Bootstrap::free_has_contract()):
     * old free decides locking, encrypts nothing itself, ships its own unlock
     * AJAX + script and only asks Pro to print the form / role message.
     *
     * @var bool
     */
    private $legacy_free = false;

    /**
     * @param bool $legacy_free Register only the two print actions (what
     *                          Pro 3.9.1's Utility class registered).
     */
    public function __construct($legacy_free = false)
    {
        $this->legacy_free = (bool) $legacy_free;

        add_action('embedpress/display_password_form', [$this, 'display_password_form'], 10, 4);
        add_action('embedpress/content_protection_content', [$this, 'content_protection_content'], 10, 3);

        if ($this->legacy_free) {
            return;
        }

        add_filter('embedpress/content_protection/is_locked', [$this, 'is_locked'], 10, 3);
        add_filter('embedpress/content_protection/gate', [$this, 'shortcode_gate'], 10, 5);

        add_action('wp_ajax_lock_content_form_handler', [$this, 'lock_content_form_handler']);
        add_action('wp_ajax_nopriv_lock_content_form_handler', [$this, 'lock_content_form_handler']);
        add_action('wp_ajax_embedpress_gutenberg_password_check', [$this, 'gutenberg_password_check']);
        add_action('wp_ajax_nopriv_embedpress_gutenberg_password_check', [$this, 'gutenberg_password_check']);

        add_action('wp_enqueue_scripts', [$this, 'register_assets'], 20);
        add_action('elementor/frontend/after_register_scripts', [$this, 'register_assets']);
    }

    /* ------------------------------------------------------------------
     * Assets
     * ------------------------------------------------------------------ */

    /**
     * Register the unlock script. It is enqueued only when a lock form is
     * actually printed (see enqueue_script()).
     */
    public function register_assets()
    {
        if (!wp_script_is(self::SCRIPT_HANDLE, 'registered')) {
            $file = EMBEDPRESS_PRO_PLUGIN_PATH . '/assets/js/content-protection.js';
            wp_register_script(
                self::SCRIPT_HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/content-protection.js',
                ['jquery'],
                file_exists($file) ? (string) filemtime($file) : (defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : false),
                true
            );
            wp_localize_script(self::SCRIPT_HANDLE, 'embedpressContentProtection', [
                'ajaxurl' => admin_url('admin-ajax.php'),
            ]);
        }

        $this->ensure_front_dependency();
    }

    /**
     * Print after free's front script so its `embedpress:content-unlocked`
     * listener (re-initialises galleries / player / ads) is in place. Block
     * themes render content — and so enqueue this script — before free has
     * registered its handle, so the dependency is (re)checked on every call.
     */
    private function ensure_front_dependency()
    {
        $script = wp_scripts()->query(self::SCRIPT_HANDLE, 'registered');
        if ($script && wp_script_is('embedpress-front', 'registered') && !in_array('embedpress-front', $script->deps, true)) {
            $script->deps[] = 'embedpress-front';
        }
    }

    private function enqueue_script()
    {
        // Legacy free ships (and enqueues) its own unlock script.
        if ($this->legacy_free || !did_action('init')) {
            return;
        }
        $this->register_assets();
        wp_enqueue_script(self::SCRIPT_HANDLE);
    }

    /* ------------------------------------------------------------------
     * Gate decisions
     * ------------------------------------------------------------------ */

    /**
     * Answer `embedpress/content_protection/is_locked`.
     *
     * @param bool   $locked  Incoming value (free default: false).
     * @param array  $data    lock_content, protection_type, content_password,
     *                        user_role, client_id.
     * @param string $context 'gutenberg' | 'elementor' | 'elementor_pdf' | 'elementor_document'.
     * @return bool True when the embed must stay hidden for this visitor.
     */
    public function is_locked($locked, $data, $context = 'gutenberg')
    {
        $data = is_array($data) ? $data : [];
        $lock_content = $data['lock_content'] ?? '';
        $type = $data['protection_type'] ?? '';
        $password = (string) ($data['content_password'] ?? '');
        $client_id = (string) ($data['client_id'] ?? '');
        $roles = $data['user_role'] ?? [];

        if (empty($lock_content) || $lock_content === 'no') {
            return false;
        }

        if ($type === 'password') {
            if ($password === '') {
                return false;
            }
            if ($this->is_password_cookie_valid($client_id, $password)) {
                return false;
            }
            return true;
        }

        if ($type === 'user-role') {
            $allowed = $context === 'gutenberg'
                ? self::has_content_allowed_roles($roles)
                : self::has_allowed_roles($roles);
            if ($allowed) {
                return false;
            }
        }

        return true;
    }

    /**
     * Answer `embedpress/content_protection/gate` for the shortcodes.
     *
     * @param string|null $gate       Incoming value (free default: null).
     * @param string      $client_id
     * @param array       $attributes Shortcode attributes.
     * @param string      $embed_html The embed markup that would be printed.
     * @param string      $context    'shortcode' | 'shortcode_pdf'.
     * @return string|null String to print instead of the embed, null to render it.
     */
    public function shortcode_gate($gate, $client_id, $attributes, $embed_html, $context = 'shortcode')
    {
        if (is_string($gate)) {
            return $gate;
        }

        $attributes = is_array($attributes) ? $attributes : [];

        $protection_type = $attributes['protection_type'] ?? 'user-role';
        $protection_password = $attributes['protection_password'] ?? '';
        $protection_content = isset($attributes['protection_content']) ? $attributes['protection_content'] === 'true' : false;
        $user_role = isset($attributes['user_roles']) ? explode(',', preg_replace('/\s*,\s*/', ',', $attributes['user_roles'])) : '';
        $protection_message = $attributes['protection_message'] ?? '';

        if (!$protection_content) {
            return $gate;
        }

        // [embedpress_pdf] from a free version that passes no client ID / markup
        // can't support the password form (nothing to encrypt or unlock), so
        // only user-role gating applies there.
        if ($context === 'shortcode_pdf' && ($client_id === '' || (string) $embed_html === '')) {
            if ($protection_type == 'user-role' && !self::has_allowed_roles($user_role)) {
                return (string) $this->shortcode_role_message($protection_message, $user_role);
            }
            return $gate;
        }

        $password_protected = $protection_type == 'password' && !empty($protection_password);
        $password_verified = $password_protected && $this->is_password_cookie_valid($client_id, $protection_password);

        if (($protection_type == 'password' && !$password_verified) || ($protection_type == 'user-role' && !self::has_allowed_roles($user_role))) {
            return $password_protected
                ? $this->shortcode_password_form($client_id, $embed_html, md5($protection_password), $attributes)
                : (string) $this->shortcode_role_message($protection_message, $user_role);
        }

        return $gate;
    }

    /* ------------------------------------------------------------------
     * Lock UI
     * ------------------------------------------------------------------ */

    /**
     * Encrypt the embed into post meta so the unlock endpoint can return it.
     *
     * @return void
     */
    private function store_encrypted_embed($client_id, $embedHtml, $pass_hash_key)
    {
        $key = self::get_hash();
        $salt = wp_salt(32);
        $wp_hash_key = hash('sha256', $salt . $pass_hash_key);
        $iv = substr($wp_hash_key, 0, 16);

        // Ensure $embedHtml is not null before encryption
        $embedHtml = $embedHtml ?? '';
        $cipher = openssl_encrypt($embedHtml, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);
        $encrypted_data = base64_encode($cipher);

        update_post_meta(get_the_ID(), 'ep_base_' . $client_id, $encrypted_data);
        update_post_meta(get_the_ID(), 'hash_key_' . $client_id, $wp_hash_key);
    }

    private static function lock_icon()
    {
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><g fill="#6354a5" class="color134563 svgShape"><path d="M46.3 28.7h-3v-6.4C43.3 16.1 38.2 11 32 11c-6.2 0-11.3 5.1-11.3 11.3v6.4h-3v-6.4C17.7 14.4 24.1 8 32 8s14.3 6.4 14.3 14.3v6.4" fill="#6354a5" class="color000000 svgShape"></path><path d="M44.8 55.9H19.2c-2.6 0-4.8-2.2-4.8-4.8V31.9c0-2.6 2.2-4.8 4.8-4.8h25.6c2.6 0 4.8 2.2 4.8 4.8v19.2c0 2.7-2.2 4.8-4.8 4.8zM19.2 30.3c-.9 0-1.6.7-1.6 1.6v19.2c0 .9.7 1.6 1.6 1.6h25.6c.9 0 1.6-.7 1.6-1.6V31.9c0-.9-.7-1.6-1.6-1.6H19.2z" fill="#6354a5" class="color000000 svgShape"></path><path d="M35.2 36.7c0 1.8-1.4 3.2-3.2 3.2s-3.2-1.4-3.2-3.2 1.4-3.2 3.2-3.2 3.2 1.5 3.2 3.2" fill="#6354a5" class="color000000 svgShape"></path><path d="M32.8 36.7h-1.6l-1.6 9.6h4.8l-1.6-9.6" fill="#6354a5" class="color000000 svgShape"></path></g></svg>';
    }

    /**
     * Lock form labels with their defaults.
     *
     * @return array
     */
    private static function form_labels($attributes)
    {
        return [
            'lock_heading' => !empty($attributes['lockHeading']) ? sanitize_text_field($attributes['lockHeading']) : 'Content Locked',
            'lock_subheading' => !empty($attributes['lockSubHeading']) ? sanitize_text_field($attributes['lockSubHeading']) : 'Content is locked and requires password to access it.',
            'lock_error_message' => !empty($attributes['lockErrorMessage']) ? sanitize_text_field($attributes['lockErrorMessage']) : "Oops, that wasn't the right password. Try again.",
            'footer_message' => !empty($attributes['footerMessage']) ? sanitize_text_field($attributes['footerMessage']) : "In case you don't have the password, kindly reach out to content owner or administrator to request access.",
            'password_placeholder' => !empty($attributes['passwordPlaceholder']) ? sanitize_text_field($attributes['passwordPlaceholder']) : 'Password',
            'button_text' => !empty($attributes['submitButtonText']) ? sanitize_text_field($attributes['submitButtonText']) : 'Unlock',
            'unlocking_text' => !empty($attributes['submitUnlockingText']) ? sanitize_text_field($attributes['submitUnlockingText']) : 'Unlocking',
            'enable_footer_message' => !empty($attributes['enableFooterMessage']),
        ];
    }

    /**
     * Action `embedpress/display_password_form` — Gutenberg / Elementor lock form.
     */
    public function display_password_form($client_id = '', $embedHtml = '', $pass_hash_key = '', $attributes = [])
    {
        $l = self::form_labels($attributes);

        $this->store_encrypted_embed($client_id, $embedHtml, $pass_hash_key);
        $this->enqueue_script();

        echo '
		<div class="password-form-container">
			<h2>' . esc_html($l['lock_heading']) . '</h2>
			<p>' . esc_html($l['lock_subheading']) . '</p>
			<form class="password-form" method="post" data-unlocking-text="' . esc_attr($l['unlocking_text']) . '">
				<div class="password-field">
					<span class="lock-icon">' . self::lock_icon() . '</span>
					<input type="password" name="pass_' . esc_attr($client_id) . '" placeholder="' . esc_attr($l['password_placeholder']) . '" required>
				</div>
				<input type="hidden" name="ep_client_id" value="' . esc_attr($client_id) . '">
				<input type="hidden" name="post_id" value="' . esc_attr(get_the_ID()) . '">
				<input type="submit" name="password_submit" value="' . esc_attr($l['button_text']) . '">
				<div class="error-message hidden">' . esc_html($l['lock_error_message']) . '</div>
			</form>
			' . ($l['enable_footer_message'] ? '<p class="need-access-message">' . esc_html($l['footer_message']) . '</p>' : '') . '
		</div>';
    }

    /**
     * Action `embedpress/content_protection_content` — Gutenberg / Elementor role message.
     */
    public function content_protection_content($client_id = '', $protection_message = '', $allowed_roles = [])
    {
        $default_message = "This content is protected. Please log in or contact the administrator for access.";
        $protection_message = $protection_message ?: $default_message;

        $current_user = wp_get_current_user();
        $user_roles = $current_user->roles;

        if (!empty($user_roles) && array_intersect($user_roles, (array) $allowed_roles)) {
            echo '';
            return;
        }

        if (strpos($protection_message, '[user_roles]') !== false) {
            $role_list = implode(', ', (array) $allowed_roles);
            $protection_message = str_replace('[user_roles]', $role_list, $protection_message);
        }

        echo sprintf('<div class="protected-message">%s</div>', esc_html($protection_message));
    }

    /**
     * Shortcode role message (returned, not echoed).
     *
     * @return string|null Null when the visitor already holds an allowed role.
     */
    private function shortcode_role_message($protection_message = '', $allowed_roles = [])
    {
        $default_message = "This content is protected. Please log in or contact the administrator for access.";
        $protection_message = $protection_message ?: $default_message;

        $current_user = wp_get_current_user();
        $user_roles = $current_user->roles;

        if (!empty($user_roles) && array_intersect($user_roles, (array) $allowed_roles)) {
            return null;
        }

        if (strpos($protection_message, '[user_roles]') !== false) {
            $role_list = implode(', ', (array) $allowed_roles);
            $protection_message = str_replace('[user_roles]', $role_list, $protection_message);
        }

        return sprintf('<div class="protected-message">%s</div>', esc_html($protection_message));
    }

    /**
     * Shortcode password form (returned, wrapped in the shortcode container).
     *
     * @return string
     */
    private function shortcode_password_form($client_id = '', $embedHtml = '', $pass_hash_key = '', $attributes = [])
    {
        $l = self::form_labels($attributes);

        $this->store_encrypted_embed($client_id, $embedHtml, $pass_hash_key);
        $this->enqueue_script();

        return '
        <div id="ep-shortcode-content-' . $client_id . '" class="ep-shortcode-content">' . "\t" . '
            <div class="ep-embed-content-wraper">
                <div class="password-form-container">
                    <h2>' . esc_html($l['lock_heading']) . '</h2>
                    <p>' . esc_html($l['lock_subheading']) . '</p>
                    <form class="password-form" method="post" data-unlocking-text="' . esc_attr($l['unlocking_text']) . '">
                        <div class="password-field">
                            <span class="lock-icon">' . self::lock_icon() . '</span>
                            <input type="password" name="pass_' . esc_attr($client_id) . '" placeholder="' . esc_attr($l['password_placeholder']) . '" required>
                        </div>
                        <input type="hidden" name="ep_client_id" value="' . esc_attr($client_id) . '">
                        <input type="hidden" name="post_id" value="' . esc_attr(get_the_ID()) . '">
                        <input type="submit" name="password_submit" value="' . esc_attr($l['button_text']) . '">
                        <div class="error-message hidden">' . esc_html($l['lock_error_message']) . '</div>
                    </form>
                    ' . ($l['enable_footer_message'] ? '<p class="need-access-message">' . esc_html($l['footer_message']) . '</p>' : '') . '
                </div>
            </div>
        </div>';
    }

    /* ------------------------------------------------------------------
     * AJAX unlock endpoints
     * ------------------------------------------------------------------ */

    /**
     * `lock_content_form_handler` — verify the password and return the
     * decrypted embed (plus the cookie-setting snippet) on success.
     */
    public function lock_content_form_handler()
    {
        $client_id = isset($_POST['client_id']) ? sanitize_text_field($_POST['client_id']) : '';
        $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;

        $epbase64 = get_post_meta($post_id, 'ep_base_' . $client_id, true);
        $hash_key = get_post_meta($post_id, 'hash_key_' . $client_id, true);

        // Decryption key; the IV comes from the password hash.
        $key = self::get_hash();

        $cipher = base64_decode($epbase64);

        $wp_pass_key = hash('sha256', wp_salt(32) . md5($password));
        $iv = substr($wp_pass_key, 0, 16);

        if ($wp_pass_key === $hash_key) {
            $embed = openssl_decrypt($cipher, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv) . '<script>
			var now = new Date();
			var time = now.getTime();
			var expireTime = time + 1000 * 60 * 60 * 24 * 30;
			now.setTime(expireTime);
			document.cookie = "password_correct_' . esc_js($client_id) . '=' . esc_js($hash_key) . '; expires=" + now.toUTCString() + "; path=/";
		</script>';
        } else {
            $embed = 0;
        }

        wp_send_json([
            'success' => true,
            'password' => $password,
            'embedHtml' => $embed,
            'post_id' => $post_id,
        ]);
    }

    /**
     * `embedpress_gutenberg_password_check` — legacy endpoint kept for
     * backwards compatibility; sets the unlock cookie when the two
     * submitted values match.
     */
    public function gutenberg_password_check()
    {
        $client_id = isset($_POST['client_id']) ? sanitize_text_field($_POST['client_id']) : '';
        $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';
        $content_password = isset($_POST['content_password']) ? sanitize_text_field($_POST['content_password']) : '';

        if ($password === $content_password) {
            $hash_pass = hash('sha256', wp_salt(32) . md5($password));
            setcookie("password_correct_" . $client_id, $hash_pass, time() + 3600, '/');

            $response = [
                'success' => true,
                'message' => 'Password correct',
            ];
        } else {
            $response = [
                'success' => false,
                'message' => 'Incorrect password',
            ];
        }

        wp_send_json($response);
    }

    /* ------------------------------------------------------------------
     * Helpers
     * ------------------------------------------------------------------ */

    /**
     * Site-wide AES key. Same option free used before the split, so content
     * encrypted earlier still decrypts.
     *
     * @return string
     */
    public static function get_hash()
    {
        $option = (defined('EMBEDPRESS_PLG_NAME') ? EMBEDPRESS_PLG_NAME : 'embedpress') . '_hash_key';
        $hash_key = get_option($option);
        if (!$hash_key) {
            $hash_key = wp_hash_password(wp_generate_password(30));
            update_option($option, $hash_key);
        }
        return $hash_key;
    }

    /**
     * Whether the visitor holds a valid unlock cookie for this embed.
     */
    private function is_password_cookie_valid($client_id, $password)
    {
        $cookie = isset($_COOKIE['password_correct_' . $client_id]) ? sanitize_text_field(wp_unslash($_COOKIE['password_correct_' . $client_id])) : '';
        if ($cookie === '') {
            return false;
        }
        return hash_equals(hash('sha256', wp_salt(32) . md5($password)), $cookie);
    }

    /**
     * Role check used by the shortcodes and Elementor widgets: an empty role
     * list allows everyone.
     *
     * @param array|string $allowed_roles
     * @return bool
     */
    public static function has_allowed_roles($allowed_roles = [])
    {
        if (empty($allowed_roles) || (count((array) $allowed_roles) == 1 && empty(((array) $allowed_roles)[0]))) {
            return true;
        }
        $current_user = wp_get_current_user();
        $user_roles = $current_user->roles;

        return !empty(array_intersect($user_roles, (array) $allowed_roles));
    }

    /**
     * Role check used by the Gutenberg block: an empty array denies, a
     * single empty entry allows (block attribute default).
     *
     * @param array|string $allowed_roles
     * @return bool
     */
    public static function has_content_allowed_roles($allowed_roles = [])
    {
        if (!is_array($allowed_roles)) {
            $allowed_roles = [];
        }

        if (count($allowed_roles) === 1 && empty($allowed_roles[0])) {
            return true;
        }

        $current_user = wp_get_current_user();
        $user_roles = $current_user->roles;

        return !empty(array_intersect($user_roles, $allowed_roles));
    }
}
