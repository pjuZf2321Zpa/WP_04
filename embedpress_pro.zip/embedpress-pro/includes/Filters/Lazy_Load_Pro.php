<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Lazy loading for embed iframes.
 *
 * Free keeps the lazy-load controls (the global `g_lazyload` setting, the
 * Elementor `enable_lazy_load` switch and the block `enableLazyLoad`
 * attribute) and always renders plain iframes. This class supplies the
 * feature through free's neutral hooks:
 *
 *   - `embedpress/lazy_load/html` — Elementor widgets (embed, PDF, document,
 *     calendar). Swaps each iframe for an `.ep-lazy-iframe-placeholder`.
 *   - `embedpress/lazy_load/block_html` — Gutenberg blocks whose saved markup
 *     holds placeholders. Free turns them back into iframes; Pro keeps the
 *     saved placeholders.
 *   - Gutenberg/dist/lazy-load-save.build.js — the block editor half: builds
 *     the placeholders in block save() through free's JS filters.
 *
 * and enqueues the loader (assets/js/lazy-load.js + assets/css/lazy-load.css)
 * that turns placeholders into iframes as they scroll into view.
 *
 * @package Embedpress\Pro\Filters
 */
class Lazy_Load_Pro
{
    public function __construct()
    {
        add_filter('embedpress/lazy_load/html', [$this, 'lazy_load_html'], 10, 3);
        add_filter('embedpress/lazy_load/block_html', [$this, 'keep_saved_placeholders'], 10, 3);

        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue_assets'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'maybe_enqueue_assets'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_editor_script'], 20);
    }

    /**
     * Elementor widgets: replace iframes with lazy-load placeholders.
     *
     * @param string $html
     * @param array  $settings Elementor widget settings.
     * @param array  $context  ['surface' => string, 'is_editor' => bool, 'dimension' => string (calendar)]
     * @return string
     */
    public function lazy_load_html($html, $settings, $context = [])
    {
        $settings = is_array($settings) ? $settings : [];
        $context  = is_array($context) ? $context : [];
        $surface  = isset($context['surface']) ? $context['surface'] : '';

        if (empty($settings['enable_lazy_load']) || $settings['enable_lazy_load'] !== 'yes' || !empty($context['is_editor'])) {
            return $html;
        }

        switch ($surface) {
            case 'elementor':
                // Disabled when the custom player is active.
                if (!empty($settings['emberpress_custom_player']) && $settings['emberpress_custom_player'] === 'yes') {
                    return $html;
                }
                return self::iframes_to_placeholders($html);

            case 'elementor-pdf':
                return self::iframes_to_placeholders($html);

            case 'elementor-document':
                return empty($html) ? $html : self::iframes_to_placeholders($html);

            case 'elementor-calendar':
                if (empty($settings['embedpress_public_cal_link'])) {
                    return $html;
                }
                $dimension = isset($context['dimension']) ? $context['dimension'] : '';
                return '<div class="ep-lazy-iframe-placeholder"'
                    . ' data-ep-lazy-src="' . esc_attr($settings['embedpress_public_cal_link']) . '"'
                    . ' data-ep-iframe-style="' . esc_attr($dimension) . '; max-width:100%; display: inline-block"'
                    . ' data-ep-iframe-frameborder="0"'
                    . ' style="' . esc_attr($dimension) . '; max-width:100%; display: inline-block"></div>';
        }

        return $html;
    }

    /**
     * Gutenberg: keep the placeholders the block saved; the loader fills them.
     *
     * @param string $html          Block HTML with plain iframes (free's rendering).
     * @param string $original_html Block HTML as saved.
     * @param array  $block
     * @return string
     */
    public function keep_saved_placeholders($html, $original_html, $block = [])
    {
        return is_string($original_html) ? $original_html : $html;
    }

    /**
     * Swap every iframe in $html for a lazy-load placeholder.
     *
     * @param string $html
     * @return string
     */
    public static function iframes_to_placeholders($html)
    {
        if (!is_string($html) || $html === '') {
            return $html;
        }

        return preg_replace_callback(
            '/<iframe([^>]*)src=["\']([^"\']+)["\']([^>]*)>/i',
            function ($matches) {
                $before = $matches[1];
                $src = $matches[2];
                $after = $matches[3];

                // Extract style attribute if exists
                $style = '';
                if (preg_match('/style=["\']([^"\']+)["\']/i', $before . $after, $style_match)) {
                    $style = $style_match[1];
                }

                return sprintf(
                    '<div class="ep-lazy-iframe-placeholder" data-ep-lazy-src="%s" data-ep-iframe-style="%s" %s %s style="%s"></div>',
                    esc_attr($src),
                    esc_attr($style),
                    $before,
                    $after,
                    esc_attr($style)
                );
            },
            $html
        );
    }

    /**
     * Enqueue the loader on the frontend / Elementor preview when the page
     * can contain lazy embeds.
     */
    public function maybe_enqueue_assets()
    {
        if (is_admin() || wp_script_is('embedpress-lazy-load', 'enqueued') || !$this->page_needs_lazy_load()) {
            return;
        }

        wp_enqueue_style(
            'embedpress-lazy-load-css',
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/lazy-load.css',
            [],
            EMBEDPRESS_PRO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'embedpress-lazy-load',
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/lazy-load.js',
            [],
            EMBEDPRESS_PRO_PLUGIN_VERSION,
            true
        );
    }

    /**
     * Block editor: register the save() half of lazy loading. Loads after
     * free's block bundle so its JS filters exist before blocks are parsed.
     */
    public function enqueue_editor_script()
    {
        wp_enqueue_script(
            'embedpress-pro-lazy-load-save',
            EMBEDPRESS_PRO_PLUGIN_URL . 'Gutenberg/dist/lazy-load-save.build.js',
            ['wp-hooks', 'wp-element', 'embedpress-blocks-editor'],
            EMBEDPRESS_PRO_PLUGIN_VERSION,
            true
        );
    }

    /**
     * Same rules free used for its `lazy_load` asset condition.
     *
     * @return bool
     */
    private function page_needs_lazy_load()
    {
        // Elementor editor: content is unsaved, always load.
        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::$instance;
            if (isset($elementor->editor) && $elementor->editor->is_edit_mode()) {
                return true;
            }
        }

        // Global setting: any page with EmbedPress content. Free's front
        // script loads exactly on those pages.
        $g_settings = get_option(EMBEDPRESS_PLG_NAME, []);
        if (isset($g_settings['g_lazyload']) && $g_settings['g_lazyload'] == 1) {
            return wp_script_is('embedpress-front', 'enqueued');
        }

        global $post;

        if (!$post) {
            return false;
        }

        $content = $post->post_content;

        if (function_exists('has_blocks') && has_blocks($content)) {
            if ($this->blocks_have_lazy_load(parse_blocks($content))) {
                return true;
            }
        }

        if (class_exists('\Elementor\Plugin')) {
            $document = \Elementor\Plugin::$instance->documents->get($post->ID);
            if ($document && method_exists($document, 'is_built_with_elementor') && $document->is_built_with_elementor()) {
                $elementor_data = get_post_meta($post->ID, '_elementor_data', true);
                if ($elementor_data && is_string($elementor_data) && strpos($elementor_data, '"enable_lazy_load":"yes"') !== false) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @param array $blocks
     * @return bool
     */
    private function blocks_have_lazy_load($blocks)
    {
        foreach ($blocks as $block) {
            $block_name = $block['blockName'] ?? '';
            if ($block_name && strpos($block_name, 'embedpress/') === 0 && !empty($block['attrs']['enableLazyLoad'])) {
                return true;
            }

            if (!empty($block['innerBlocks']) && $this->blocks_have_lazy_load($block['innerBlocks'])) {
                return true;
            }
        }

        return false;
    }
}
