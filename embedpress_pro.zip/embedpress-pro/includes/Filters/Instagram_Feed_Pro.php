<?php

namespace Embedpress\Pro\Filters;

use EmbedPress\Includes\Classes\Helper;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Instagram feed Pro features.
 *
 * The free plugin renders the Instagram feed with its Grid layout and the
 * permalink overlay only. It exposes neutral extension points that this class
 * answers:
 *
 *   embedpress/instagram/layout              → allow the Masonry / Carousel layouts
 *   embedpress/instagram/gallery_attributes  → Masonry column count / Carousel track
 *   embedpress/instagram/wrapper_attributes  → Carousel data attributes on the wrapper
 *   embedpress/instagram/after_gallery_html  → Carousel navigation buttons
 *   embedpress/instagram/item_info_html      → like / comment counts overlay
 *   embedpress/instagram/before_gallery      → media-type tabs (action)
 *   embedpress/instagram/hashtag_feed        → hashtag feed fetching
 *   embedpress/instagram/hashtag_header_html → hashtag feed header
 *   embedpress/instagram/loadmore_posts      → hashtag feed "Load more"
 *
 * Frontend behaviour (carousel init, tabs, popup counts) lives in
 * assets/js/instagram-feed-pro.js and the styles in
 * assets/css/instagram-feed-pro.css; both are enqueued wherever free's
 * frontend script (`embedpress-front`) is.
 *
 * @package Embedpress\Pro\Filters
 */
class Instagram_Feed_Pro
{
    /** Free's frontend script handle (Core/AssetManager.php). */
    const FREE_HANDLE = 'embedpress-front';

    const HANDLE = 'embedpress-instagram-feed-pro';

    const PRO_LAYOUTS = ['insta-masonry', 'insta-carousel'];

    public function __construct()
    {
        add_filter('embedpress/instagram/layout', [$this, 'layout'], 10, 2);
        add_filter('embedpress/instagram/gallery_attributes', [$this, 'gallery_attributes'], 10, 3);
        add_filter('embedpress/instagram/wrapper_attributes', [$this, 'wrapper_attributes'], 10, 5);
        add_filter('embedpress/instagram/after_gallery_html', [$this, 'after_gallery_html'], 10, 3);
        add_filter('embedpress/instagram/item_info_html', [$this, 'item_info_html'], 10, 5);
        add_action('embedpress/instagram/before_gallery', [$this, 'feed_tabs'], 10, 1);
        add_filter('embedpress/instagram/hashtag_feed', [$this, 'hashtag_feed'], 10, 5);
        add_filter('embedpress/instagram/hashtag_header_html', [$this, 'hashtag_header_html'], 10, 4);
        add_filter('embedpress/instagram/loadmore_posts', [$this, 'loadmore_posts'], 10, 3);

        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_assets', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        // Free may enqueue its frontend script late (content-dependent).
        add_action('wp_footer', [$this, 'maybe_enqueue'], 1);

        add_action('enqueue_block_editor_assets', [$this, 'enqueue_editor'], 20);
    }

    /**
     * Block editor: Carousel preview (hooks free's
     * `embedpress.instagram.previewRendered` action). Depends on wp-hooks and
     * free's block bundle so it registers before any preview renders.
     */
    public function enqueue_editor()
    {
        $deps = ['wp-hooks'];
        if (wp_script_is('embedpress-blocks-editor', 'registered')) {
            $deps[] = 'embedpress-blocks-editor';
        }

        wp_enqueue_script(
            self::HANDLE . '-editor',
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/instagram-feed-editor-pro.js',
            $deps,
            self::version('assets/js/instagram-feed-editor-pro.js'),
            true
        );
    }

    /* ------------------------------------------------------------------ */
    /* Layouts                                                             */
    /* ------------------------------------------------------------------ */

    public function layout($layout, $requested)
    {
        return in_array($requested, self::PRO_LAYOUTS, true) ? $requested : $layout;
    }

    public function gallery_attributes($gallery, $layout, $params)
    {
        if ($layout === 'insta-masonry') {
            $gallery['class'] = '';
            $gallery['style'] = 'style="column-count: ' . absint(isset($params['instafeedColumns']) ? $params['instafeedColumns'] : 0) . '; gap: ' . absint(isset($params['instafeedColumnsGap']) ? $params['instafeedColumnsGap'] : 0) . 'px;"';
        } elseif ($layout === 'insta-carousel') {
            $gallery['class'] = 'cg-carousel__track js-carousel__track';
            $gallery['style'] = '';
            $slides_show = isset($params['slidesShow']) ? absint($params['slidesShow']) : 0;
            if ($slides_show > 0) {
                $column = (100 / $slides_show);
                $space = isset($params['carouselSpacing']) ? absint($params['carouselSpacing']) : 0;
                $gallery['style'] = 'style="grid-auto-columns: calc(' . esc_attr($column) . '% - ' . $space . 'px); gap: ' . $space . 'px"';
            }
        }

        return $gallery;
    }

    /**
     * Carousel data attributes on the feed wrapper. The option defaults differ
     * per surface (they always have), so each context is built separately.
     */
    public function wrapper_attributes($attributes, $layout, $settings, $context, $id)
    {
        if ($layout !== 'insta-carousel') {
            return $attributes;
        }

        if ($context === 'shortcode') {
            $boolish = function ($v, $default) {
                if ($v === null) return $default;
                $v = is_string($v) ? strtolower($v) : $v;
                return in_array($v, ['true', '1', 1, true], true);
            };
            $options = [
                'layout'          => 'insta-carousel',
                'slideshow'       => isset($settings['slidesshow']) ? intval($settings['slidesshow']) : 3,
                'autoplay'        => $boolish($settings['carouselautoplay'] ?? null, false),
                'autoplayspeed'   => isset($settings['autoplayspeed']) ? intval($settings['autoplayspeed']) : 3000,
                'transitionspeed' => isset($settings['transitionspeed']) ? intval($settings['transitionspeed']) : 650,
                'loop'            => $boolish($settings['carouselloop'] ?? null, false),
                'arrows'          => $boolish($settings['carouselarrows'] ?? null, true),
                'spacing'         => isset($settings['carouselspacing']) ? intval($settings['carouselspacing']) : 10,
            ];

            return ' data-carouselid="' . esc_attr($id) . '" data-carousel-options="' . esc_attr(wp_json_encode($options)) . '"';
        }

        if ($context === 'gutenberg') {
            // Numeric / boolean only — cast rather than pass through.
            $options = [
                'layout'          => 'insta-carousel',
                'slideshow'       => !empty($settings['slidesShow']) ? absint($settings['slidesShow']) : 5,
                'autoplay'        => !empty($settings['carouselAutoplay']) ? 1 : 0,
                'autoplayspeed'   => !empty($settings['autoplaySpeed']) ? absint($settings['autoplaySpeed']) : 3000,
                'transitionspeed' => !empty($settings['transitionSpeed']) ? absint($settings['transitionSpeed']) : 1000,
                'loop'            => !empty($settings['carouselLoop']) ? 1 : 0,
                'arrows'          => !empty($settings['carouselArrows']) ? 1 : 0,
                'spacing'         => !empty($settings['carouselSpacing']) ? absint($settings['carouselSpacing']) : 0
            ];

            return 'data-carouselid="' . esc_attr($id) . '" data-carousel-options="' . esc_attr(wp_json_encode($options)) . '"';
        }

        if ($context === 'elementor') {
            $options = [
                'layout'          => 'insta-carousel',
                'slideshow'       => !empty($settings['embedpress_instafeed_slide_show']) ? absint($settings['embedpress_instafeed_slide_show']) : 5,
                'autoplay'        => !empty($settings['embedpress_carousel_autoplay']) ? 1 : 0,
                'autoplayspeed'   => !empty($settings['embedpress_carousel_autoplay_speed']) ? absint($settings['embedpress_carousel_autoplay_speed']) : 3000,
                'transitionspeed' => !empty($settings['embedpress_carousel_transition_speed']) ? absint($settings['embedpress_carousel_transition_speed']) : 1000,
                'loop'            => !empty($settings['embedpress_carousel_loop']) ? 1 : 0,
                'arrows'          => !empty($settings['embedpress_carousel_arrows']) ? 1 : 0,
                'spacing'         => !empty($settings['embedpress_carousel_spacing']) ? absint($settings['embedpress_carousel_spacing']) : 0
            ];

            return 'data-carouselid="' . esc_attr($id) . '" data-carousel-options="' . esc_attr(wp_json_encode($options)) . '"';
        }

        return $attributes;
    }

    /**
     * Carousel navigation buttons. Printed for every layout (hidden unless the
     * carousel script reveals them), exactly as the feed always did.
     */
    public function after_gallery_html($html, $layout, $params)
    {
        ob_start(); ?>
<div class="cg-carousel__btns hidden">
                        <button type="button" class="cg-carousel__btn" id="js-carousel__prev-1" aria-label="<?php esc_attr_e('Previous', 'embedpress-pro'); ?>"><svg aria-hidden="true" focusable="false" width="20" height="30" viewBox="-5 0 23 23" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11.24.29.361 10.742l-.06.054a.97.97 0 0 0-.301.642v.124a.97.97 0 0 0 .3.642l.054.044L11.239 22.71a1.061 1.061 0 0 0 1.459 0 .964.964 0 0 0 0-1.402l-10.15-9.746 10.15-9.87a.964.964 0 0 0 0-1.402 1.061 1.061 0 0 0-1.459 0Z" fill="#fff" />
                            </svg></button>

                        <button type="button" class="cg-carousel__btn" id="js-carousel__next-1" aria-label="<?php esc_attr_e('Next', 'embedpress-pro'); ?>"><svg aria-hidden="true" focusable="false" width="20" height="30" viewBox="-5 0 23 23" xmlns="http://www.w3.org/2000/svg">
                                <path d="m1.76.29 10.879 10.452.06.054a.97.97 0 0 1 .301.642v.124a.97.97 0 0 1-.3.642l-.054.044L1.761 22.71a1.061 1.061 0 0 1-1.459 0 .964.964 0 0 1 0-1.402l10.15-9.746-10.15-9.87a.964.964 0 0 1 0-1.402 1.061 1.061 0 0 1 1.459 0Z" fill="#fff" />
                            </svg></button>
                    </div>
<?php
        return $html . ob_get_clean();
    }

    /* ------------------------------------------------------------------ */
    /* Like / comment counts and tabs                                      */
    /* ------------------------------------------------------------------ */

    private static function is_on($params, $key)
    {
        return !empty($params[$key]) && $params[$key] !== 'false';
    }

    public function item_info_html($html, $like_count, $comments_count, $params, $context)
    {
        if ($context === 'loadmore') {
            // "Load more" items always carried both counts.
            return $this->reaction_markup($like_count, $comments_count, true, true);
        }

        $hashtag_or_likes = (isset($params['instafeedFeedType']) && $params['instafeedFeedType'] === 'hashtag_type')
            || (isset($params['instafeedLikesCount']) && $params['instafeedLikesCount'] !== 'false');
        $any_count = self::is_on($params, 'instafeedLikesCount') || self::is_on($params, 'instafeedCommentsCount');

        if (!$hashtag_or_likes || !$any_count) {
            return $html;
        }

        return $this->reaction_markup(
            $like_count,
            $comments_count,
            self::is_on($params, 'instafeedLikesCount'),
            self::is_on($params, 'instafeedCommentsCount')
        );
    }

    private function reaction_markup($like_count, $comments_count, $show_likes, $show_comments)
    {
        ob_start(); ?>
		<div class="insta-item-reaction-count">
				<?php if ($show_likes) : ?>
					<div class="insta-gallery-item-likes">
						<?php echo Helper::get_insta_like_icon();
										echo esc_html($like_count); ?>
					</div>
				<?php endif; ?>
				<?php if ($show_comments) : ?>
					<div class="insta-gallery-item-comments">
						<?php echo Helper::get_insta_comment_icon();
										echo esc_html($comments_count); ?>
					</div>
				<?php endif; ?>
			</div>
		<?php
        return ob_get_clean();
    }

    public function feed_tabs($params)
    {
        if (!self::is_on((array) $params, 'instafeedTab')) {
            return;
        }
        ?>
		<div class="posts-tab-options">
			<ul class="tabs">
				<li data-media-type="ALL" class="active"><svg class="_ab6-" color="#000" height="20" viewBox="5 5 30 30" width="20">
						<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.3333333333333335" d="M5 5h30v30H5zm10.025 0v30m9.95 -30v30M35 15.025H5m30 9.95H5" /></svg>Posts</li>
				<li data-media-type="VIDEO"><svg class="_ab6-" color="#000" height="20" viewBox="0 0 40 40" width="20">
						<path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="3.333" d="M3.415 11.67h33.168" />
						<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.333" d="m22.507 3.335 4.763 8.335M12.012 3.517l4.658 8.153M3.333 20.002v5.748c0 4.748 1.163 6.677 2.677 8.242 1.567 1.513 3.497 2.678 8.243 2.678h11.493c4.747 0 6.677-1.165 8.243-2.678 1.513-1.565 2.677-3.493 2.677-8.242V14.253c0-4.747-1.163-6.677-2.677-8.242-1.566-1.513-3.496-2.678-8.242-2.678H14.253c-4.747 0-6.677 1.165-8.243 2.678-1.513 1.566-2.677 3.496-2.677 8.242Z" />
						<path class="fill-color" d="M16.272 29.44a1.513 1.513 0 0 1-.757-1.312v-8.745a1.515 1.515 0 0 1 2.273-1.313l7.575 4.373a1.515 1.515 0 0 1 0 2.625l-7.575 4.373a1.517 1.517 0 0 1-1.517 0Z" fill-rule="evenodd" /></svg>Reels</li>
				<li data-media-type="CAROUSEL_ALBUM"><svg aria-label="Carousel" class="x1lliihq x1n2onr6" color="#000" height="20" viewBox="0 0 43.636 43.636" width="20">
						<path class="fill-color" d="M31.636 27V10a4.695 4.695 0 0 0-4.727-4.727H10A4.695 4.695 0 0 0 5.273 10v17A4.695 4.695 0 0 0 10 31.727h17c2.545-.091 4.636-2.182 4.636-4.727zm4-13.364v14.636c0 4.091-3.364 7.455-7.455 7.455H13.545c-.545 0-.818.636-.455 1 .909 1 2.182 1.636 3.727 1.636h12.182a9.35 9.35 0 0 0 9.364-9.364V16.818a5.076 5.076 0 0 0-1.636-3.727c-.455-.364-1.091 0-1.091.545z" /></svg>Album</li>
			</ul>
		</div>
		<?php
    }

    /* ------------------------------------------------------------------ */
    /* Hashtag feed                                                        */
    /* ------------------------------------------------------------------ */

    public function hashtag_feed($feed, $hashtag, $access_token, $user_id, $params)
    {
        $hashtag_id = $this->get_hashtag_id($access_token, $hashtag, $user_id);
        $posts = $this->get_hashtag_posts($access_token, $hashtag, $user_id);

        // Load more reads the feed back from this option.
        $option_key = 'ep_instagram_hashtag_feed';
        $hashtag_feed = get_option($option_key, array());
        $hashtag_feed[$hashtag_id] = $posts;
        update_option($option_key, $hashtag_feed);

        return [
            'id'    => $hashtag_id,
            'posts' => $posts,
        ];
    }

    public function loadmore_posts($feed_posts, $feed_type, $loadmore_key)
    {
        if ($feed_type !== 'hashtag_type') {
            return $feed_posts;
        }

        $feeds_data = get_option('ep_instagram_hashtag_feed');

        return isset($feeds_data[$loadmore_key]) ? $feeds_data[$loadmore_key] : ['error'];
    }

    public function hashtag_header_html($html, $hashtag, $avater_url, $params)
    {
        ob_start(); ?>
                <div class="hashtag-container">
                    <div class="embedpress-hashtag-header">

                        <?php if (!empty($params['instafeedProfileImage']) && $params['instafeedProfileImage'] !== 'false') : ?>

                            <div class="embedpress-hashtag-header-img"> <a target="_blank" href="<?php echo esc_url("https://www.instagram.com/explore/tags/$hashtag/"); ?>" class="embedpress-href"> <img decoding="async" loading="lazy" class="embedpress-hashtag-round" src="<?php echo esc_url($avater_url); ?>" width="30" height="30"> <span class="embedpress-hashtag-username"><?php echo esc_html("#$hashtag"); ?></span>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($params['instafeedFollowBtn']) && $params['instafeedFollowBtn'] !== 'false' && !empty($params['instafeedFollowBtnLabel']) && $params['instafeedFollowBtnLabel'] !== 'false') : ?>
                            <div class="insta-followbtn">
                                <a target="_new" href="<?php echo esc_url("https://www.instagram.com/explore/tags/$hashtag/"); ?>" type="button" class="btn btn-primary"><?php echo esc_html($params['instafeedFollowBtnLabel']); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
<?php
        return $html . ob_get_clean();
    }

    /**
     * Resolve a hashtag to its Graph API id (cached 30 days).
     */
    private function get_hashtag_id($access_token, $hashtag, $user_id)
    {
        $transient_key = 'hashtag_id_' . md5($access_token . $hashtag . $user_id);
        $transient_data = get_transient($transient_key);

        if (false === $transient_data) {
            $api_url = add_query_arg([
                'user_id'      => rawurlencode($user_id),
                'q'            => rawurlencode($hashtag),
                'access_token' => rawurlencode($access_token),
            ], 'https://graph.facebook.com/v17.0/ig_hashtag_search');

            $postsResponse = wp_remote_get($api_url);

            if (is_wp_error($postsResponse)) {
                echo 'Error: Unable to retrieve Instagram posts.';
            } else {
                $postsBody = wp_remote_retrieve_body($postsResponse);
                $hashtagId = json_decode($postsBody, true);

                if (empty($hashtagId['data'])) {
                    $transient_data = 'Please add Instagram Access Token';
                } elseif (isset($hashtagId['data'][0]['id'])) {
                    $transient_data = $hashtagId['data'][0]['id'];
                } else {
                    $transient_data = '';
                }

                set_transient($transient_key, $transient_data, 30 * DAY_IN_SECONDS);
            }
        }

        return $transient_data;
    }

    /**
     * Top media of a hashtag (cached 1 hour).
     *
     * @return array|string Posts, or an error message string.
     */
    private function get_hashtag_posts($access_token, $hashtag, $user_id)
    {
        $hashtag_id = $this->get_hashtag_id($access_token, $hashtag, $user_id);

        $transient_key = 'hashtag_posts_' . $hashtag_id;
        $cached_posts = get_transient($transient_key);

        if (isset($cached_posts[$hashtag_id])) {
            return $cached_posts[$hashtag_id];
        }

        $api_url = 'https://graph.facebook.com/' . rawurlencode($hashtag_id) . '/top_media?user_id=' . rawurlencode($user_id) . '&fields=id,media_url,media_type,comments_count,like_count,caption,children{media_url,id,media_type},permalink,timestamp&access_token=' . rawurlencode($access_token);

        $postsResponse = wp_remote_get($api_url, array('timeout' => 30));

        if (is_wp_error($postsResponse)) {
            echo 'Error: Unable to retrieve Hashtag Instagram posts.';
            return [];
        }

        $postsBody = wp_remote_retrieve_body($postsResponse);
        $posts = json_decode($postsBody, true);

        if (empty($posts['data'])) {
            return 'Please add Instagram Access Token';
        }

        if (!is_array($cached_posts)) {
            $cached_posts = [];
        }
        $cached_posts[$hashtag_id] = $posts['data'];
        set_transient($transient_key, $cached_posts, HOUR_IN_SECONDS);

        return $cached_posts[$hashtag_id];
    }

    /* ------------------------------------------------------------------ */
    /* Assets                                                              */
    /* ------------------------------------------------------------------ */

    public function maybe_enqueue()
    {
        if (!wp_script_is(self::FREE_HANDLE, 'enqueued')) {
            return;
        }

        if (!wp_script_is(self::HANDLE, 'registered')) {
            wp_register_script(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/instagram-feed-pro.js',
                [self::FREE_HANDLE],
                self::version('assets/js/instagram-feed-pro.js'),
                true
            );
            wp_register_style(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/instagram-feed-pro.css',
                [],
                self::version('assets/css/instagram-feed-pro.css')
            );
        }

        wp_enqueue_script(self::HANDLE);
        wp_enqueue_style(self::HANDLE);
    }

    /** Plugin version, plus the file's mtime so edits bust caches. */
    private static function version($relative)
    {
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : '';
        $path = defined('EMBEDPRESS_PRO_PLUGIN_PATH') ? EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative : '';
        if ($path !== '' && file_exists($path)) {
            $version .= '.' . filemtime($path);
        }
        return $version;
    }
}
