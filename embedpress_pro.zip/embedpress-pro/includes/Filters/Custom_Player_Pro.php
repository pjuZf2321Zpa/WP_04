<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Custom Player engagement & delivery features (frontend).
 *
 * Free's initplyr.js builds the Plyr player and exposes a neutral extension
 * registry (`window.EmbedPressPlayer.register()`). The Pro features — Auto
 * Resume, End Screen, Timed CTA, Chapters, Email Capture, Action Lock, LMS
 * Completion, Drop-off Heatmap, Adaptive Streaming and Privacy Mode — live in
 * assets/js/custom-player-pro.js (+ assets/css/custom-player-pro.css) and
 * register through it.
 *
 * Free decides per context (frontend, block editor canvas, Elementor) whether
 * the player script is needed and enqueues `embedpress-init-plyr` at
 * priority 5. This class follows it: wherever that handle is enqueued, the
 * Pro script is enqueued too, depending on it so it always prints after.
 *
 * @package Embedpress\Pro\Filters
 */
class Custom_Player_Pro
{
    /** Free's player init handle (Core/AssetManager.php). */
    const FREE_HANDLE = 'embedpress-init-plyr';

    const HANDLE = 'embedpress-custom-player-pro';

    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_assets', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'maybe_enqueue'], 20);
        add_action('admin_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
    }

    public function maybe_enqueue()
    {
        if (!wp_script_is(self::FREE_HANDLE, 'enqueued')) {
            return;
        }

        if (!wp_script_is(self::HANDLE, 'registered')) {
            wp_register_script(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/custom-player-pro.js',
                [self::FREE_HANDLE],
                self::version('assets/js/custom-player-pro.js'),
                true
            );
            wp_register_style(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/custom-player-pro.css',
                [],
                self::version('assets/css/custom-player-pro.css')
            );

            // Bundled streaming libraries (hls.js 1.7.3, dash.js 4.7.4).
            // The script loads them lazily, only for .m3u8 / .mpd sources.
            wp_localize_script(self::HANDLE, 'embedpressCustomPlayerPro', [
                'vendor' => [
                    'hls'  => EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/vendor/hls/hls.min.js?ver=1.7.3',
                    'dash' => EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/vendor/dashjs/dash.all.min.js?ver=4.7.4',
                ],
            ]);
        }

        wp_enqueue_script(self::HANDLE);
        wp_enqueue_style(self::HANDLE);
    }

    /** Plugin version, plus the file's mtime so edits bust caches. */
    private static function version($relative)
    {
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : '';
        $path = defined('EMBEDPRESS_PRO_PLUGIN_PATH') ? EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative : '';
        if ($path !== '' && file_exists($path)) {
            $version .= '.' . filemtime($path);
        }
        return $version;
    }
}
