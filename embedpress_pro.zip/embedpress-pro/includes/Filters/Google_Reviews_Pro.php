<?php

namespace Embedpress\Pro\Filters;

use EmbedPress\Includes\Classes\GoogleReviewsRenderer;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Pro server-side behaviour for the free Google Reviews block.
 *
 * Hooks the extension points the free GoogleReviewsRenderer exposes:
 *   - embedpress/google_reviews/reviews        → minimum-rating filter (min_rating)
 *   - embedpress/google_reviews/review_media   → per-review photo strip (show_images)
 *   - embedpress/google_reviews/pre_fetch      → multi-place merge
 *   - embedpress/google_reviews/cache_ttl      → per-block cache override
 *   - embedpress/google_reviews/wrapper_class  → style preset + theme classes
 *   - embedpress/google_reviews/wrapper_data   → slider autoplay data attr
 *   - embedpress/google_reviews/schema_jsonld  → AggregateRating + Review JSON-LD
 *
 * Every feature is gated by the free block's own attributes; the free plugin
 * ships the upsell UI, this class makes the attributes do something.
 */
class Google_Reviews_Pro
{
    public function __construct()
    {
        add_filter('embedpress/google_reviews/allowed_layouts', [$this, 'allowed_layouts']);
        // NOTE: the visible-count ceiling (max_reviews) is a neutral technical
        // bound in free now (50, or 500 with fetch_all) — Pro no longer lifts it.
        // Minimum-rating filter + review photo strip are implemented HERE; free
        // only carries the min_rating / show_images attributes.
        if (!\Embedpress\Pro\Classes\Bootstrap::free_has_contract()) {
            // EmbedPress <= 4.6.8 still caps reviews unless Pro lifts the
            // cap (legacy-free mode) — keep Pro 3.9.1's behaviour there.
            add_filter('embedpress/google_reviews/max_reviews', [$this, 'legacy_free_max_reviews'], 10, 2);
        }
        add_filter('embedpress/google_reviews/reviews', [$this, 'filter_min_rating'], 5, 2);
        add_filter('embedpress/google_reviews/review_media', [$this, 'review_media'], 10, 3);
        add_filter('embedpress/google_reviews/pre_fetch', [$this, 'pre_fetch'], 10, 3);
        add_filter('embedpress/google_reviews/cache_ttl', [$this, 'cache_ttl'], 10, 3);
        // NOTE: sort / keyword / hide-empty are now FREE (handled in the free
        // GoogleReviewsRenderer::apply_review_filters) — Pro no longer hooks the
        // `reviews` filter, which would double-apply (re-sort/re-filter).
        // Multi-place merge is still Pro, via the separate `pre_fetch` filter.
        add_filter('embedpress/google_reviews/wrapper_class', [$this, 'wrapper_class'], 10, 2);
        // NOTE: "Load more" + per-page pagination is now FREE — render_count, the
        // per-page data attr, and the Load-more button all live in the free
        // GoogleReviewsRenderer. Pro no longer hooks render_count / append_load_more.
        // NOTE: theme/accent/autoplay (wrapper_data) and JSON-LD schema are now
        // FREE too (free renderer builds them) — Pro no longer hooks wrapper_data
        // or schema_jsonld. Pro only ADDS premium-layout preset classes via
        // wrapper_class below.
        // Frontend: REGISTER Pro assets early (handle must exist before anything
        // depends on it), but only ENQUEUE when a GR block/shortcode actually
        // renders — the free renderer fires `embedpress/google_reviews/enqueue_assets`
        // at render time. This keeps Pro CSS/JS off pages with no Google Reviews.
        add_action('wp_enqueue_scripts', [$this, 'register_frontend_assets']);
        add_action('embedpress/google_reviews/enqueue_assets', [$this, 'enqueue_frontend_assets']);
        // Editor parity: the ServerSideRender preview always renders GR, so load
        // (register + enqueue) the Pro styles inside the block editor.
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_frontend_assets']);
        // Settings-page parity: the shortcode generator's live preview renders Pro
        // layouts (masonry/badge/spotlight/knowledge/marquee/bubble + dark theme),
        // so it needs the Pro CSS/JS too. Fired by GoogleReviewsAdminPage::render().
        add_action('embedpress/google_reviews/admin_preview_assets', [$this, 'enqueue_frontend_assets']);

        // "Fetch all" → start the background batched Apify job (avoids the 300s
        // sync timeout). Returns true so the REST layer skips the sync fetch.
        add_filter('embedpress/google_reviews/start_fetch_job', [$this, 'start_fetch_job'], 10, 3);

        // Elementor: the Pro CONTROLS now live in the FREE widget
        // (Embedpress_Google_Reviews::register_pro_*_controls), gated per-control
        // by $this->pro_class which Pro clears via the embedpress/pro_class
        // filters (Utility.php) — same as every other EP Elementor widget. So Pro
        // no longer registers control sections; it only MAPS those control values
        // onto the renderer args (and the behaviour filters above do the rest).
        add_filter('embedpress/google_reviews/elementor_render_args', [$this, 'elementor_render_args'], 10, 2);
    }

    /**
     * Map the (free-defined, Pro-unlocked) Elementor control values onto the
     * renderer args. Runs only when Pro is active, so free installs leave these
     * args unset and the free renderer ignores the Pro features.
     */
    public function elementor_render_args($args, $s)
    {
        // sort/keyword/hide-empty/theme/accent/autoplay/schema/cache_ttl/load_more
        // are now FREE — the free widget (Embedpress_Google_Reviews::render) maps
        // them onto $args directly. Pro only maps the remaining Pro control here:
        // multi-place merge.

        // Multi-place merge — the free widget ships a repeater of Place IDs;
        // flatten it to the flat string array pre_fetch() expects.
        $places = [];
        if (!empty($s['ep_gr_places']) && is_array($s['ep_gr_places'])) {
            foreach ($s['ep_gr_places'] as $row) {
                $pid = is_array($row) && isset($row['place_id']) ? sanitize_text_field($row['place_id']) : '';
                if ($pid !== '') {
                    $places[] = $pid;
                }
            }
        }
        $args['places'] = $places;

        return $args;
    }

    /**
     * Start a background batched Apify fetch for a place. Hooked by the settings
     * "Refresh" (when "fetch all" is on). Returns true if a job started.
     */
    public function start_fetch_job($started, $place_id, $args)
    {
        // Free's GoogleReviewsApify hooks this same filter at priority 10 and
        // returns true once it's started the job. Respect that — re-starting
        // would schedule the cron + the reset-and-poll handshake twice.
        if ($started) {
            return $started;
        }
        if (GoogleReviewsRenderer::get_apify_token() === '') {
            return false; // no token → let the caller do the sync ≤5 fallback
        }
        return Google_Reviews_Apify::start_job((string) $place_id, is_array($args) ? $args : []);
    }

    /**
     * Add the Pro layout arrangements to the free block's single Layout select.
     * masonry/slider/badge are CSS presets layered over the base markup.
     */
    public function allowed_layouts($layouts)
    {
        return array_merge((array) $layouts, ['masonry', 'badge', 'spotlight', 'knowledge', 'marquee', 'bubble']);
    }

    /**
     * Legacy-free mode only (EmbedPress <= 4.6.8, which still caps the
     * visible reviews at 10): Pro 3.9.1's ceiling, 50 (500 with fetch_all).
     */
    public function legacy_free_max_reviews($max, $args)
    {
        $ceiling   = !empty($args['fetch_all']) ? 500 : 50;
        $requested = isset($args['limit']) ? (int) $args['limit'] : (int) $max;
        return max(1, min($ceiling, $requested));
    }

    /* ── Minimum rating filter ("show only N★ and up") ─────────────────── */

    /**
     * Drop reviews below the block's `min_rating` (1-5; 0/empty = any). Hooked
     * on the free `embedpress/google_reviews/reviews` filter, which runs for
     * the first render AND every Load-more page, so paging stays consistent.
     */
    public function filter_min_rating($reviews, $args)
    {
        $min = isset($args['min_rating']) ? (int) $args['min_rating'] : 0;
        if ($min < 1 || !is_array($reviews)) {
            return $reviews;
        }
        return array_values(array_filter($reviews, static function ($r) use ($min) {
            return (int) ($r['rating'] ?? 0) >= $min;
        }));
    }

    /* ── Review photo strip ─────────────────────────────────────────────── */

    /**
     * Render the per-review attached-photo strip (horizontal thumbnails, "+N"
     * overlay on the last tile). Hooked on the free
     * `embedpress/google_reviews/review_media` filter. `show_images` is already
     * forced off by the free renderer for layouts that don't show images.
     * Styles: assets/css/google-reviews-pro.css (.ep-gr-photos / .ep-gr-photo).
     */
    public function review_media($html, $review, $args)
    {
        if (empty($args['show_images']) || !is_array($review)) {
            return $html;
        }
        $images = (isset($review['images']) && is_array($review['images'])) ? array_values($review['images']) : [];
        if (empty($images)) {
            return $html;
        }

        $max_thumbs = 4;
        $shown      = array_slice($images, 0, $max_thumbs);
        $overflow   = count($images) - count($shown);
        $last       = count($shown) - 1;

        $out = '<div class="ep-gr-photos" data-count="' . esc_attr((string) count($shown)) . '">';
        foreach ($shown as $idx => $img) {
            $more = ($idx === $last && $overflow > 0);
            $out .= '<span class="ep-gr-photo' . ($more ? ' ep-gr-photo--more' : '') . '"'
                . ($more ? ' data-more="+' . esc_attr((string) $overflow) . '"' : '') . '>'
                . '<img src="' . esc_url((string) $img) . '" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.parentNode.remove()" />'
                . '</span>';
        }
        $out .= '</div>';

        return $html . $out;
    }

    /* ── Features 1 + 4: fetch-all (Apify) + multi-place merge + caching ──
     *
     * pre_fetch overrides the free single-place API fetch when either Pro mode
     * is active. Each place is sourced via fetch_place() — Apify when fetch_all
     * is on + a token is set (gets past Google's 5-review cap), else the official
     * 5-review API. Sets are merged, deduped, and meta aggregated. Returns null
     * to fall through to the free single-place API path.
     */
    public function pre_fetch($pre, $place_id, $args)
    {
        // Single-place Apify "fetch all" is now handled by the FREE
        // GoogleReviewsApify::pre_fetch_filter (priority 10). Pro only kicks in
        // when there's actual multi-place merging to do — that stays Pro.
        $extra     = isset($args['places']) && is_array($args['places']) ? array_filter(array_map('trim', $args['places'])) : [];
        if (empty($extra)) {
            return $pre; // free handled (or chose not to handle) the single-place path
        }
        $fetch_all = !empty($args['fetch_all']) && GoogleReviewsRenderer::get_apify_token() !== '';

        $ids = array_values(array_unique(array_filter(array_merge([$place_id], $extra))));
        if (empty($ids)) {
            return $pre;
        }

        $all_reviews = [];
        $rating_sum  = 0.0;
        $rating_wgt  = 0;
        $total_sum   = 0;
        $names       = [];

        // FETCH count (how many to pull into the DB) is independent of a block's
        // DISPLAY count. When "fetch all" is on we pull everything (bounded only
        // by the run-sync ceiling); `fetch_max` lets the settings refresh tune
        // it. The block's `limit` only controls how many of the stored reviews a
        // given block shows — it must NOT cap what we fetch.
        $fetch_max = isset($args['fetch_max']) && (int) $args['fetch_max'] > 0
            ? (int) $args['fetch_max']
            : ($fetch_all ? 0 : 5); // 0 = "all" (provider applies its own ceiling)

        foreach ($ids as $id) {
            $res = $this->fetch_place($id, $fetch_all, $fetch_max, $args);
            if (is_wp_error($res) || !is_array($res) || empty($res['reviews'])) {
                continue;
            }
            foreach ($res['reviews'] as $r) {
                $all_reviews[] = $r;
            }
            $meta = $res['meta'] ?? [];
            if (!empty($meta['rating']) && !empty($meta['total'])) {
                $rating_sum += (float) $meta['rating'] * (int) $meta['total'];
                $rating_wgt += (int) $meta['total'];
            }
            $total_sum += (int) ($meta['total'] ?? 0);
            if (!empty($meta['name'])) {
                $names[] = (string) $meta['name'];
            }
        }

        if (empty($all_reviews)) {
            return $pre;
        }

        $all_reviews = $this->dedupe_reviews($all_reviews);

        return [
            'reviews' => $all_reviews,
            'meta'    => [
                'name'   => !empty($names) ? implode(' + ', array_unique(array_slice($names, 0, 3))) : '',
                'rating' => $rating_wgt > 0 ? round($rating_sum / $rating_wgt, 1) : 0.0,
                'total'  => $total_sum,
            ],
        ];
    }

    /**
     * Fetch one place's reviews. When $fetch_all, try Apify first (more than 5);
     * always fall back to the official 5-review API so a failure never blanks the
     * block.
     *
     * @return array|\WP_Error {reviews, meta}
     */
    private function fetch_place($place_id, $fetch_all, $limit, $args)
    {
        if ($fetch_all) {
            $apify = $this->fetch_via_apify($place_id, $limit, $args);
            if (is_array($apify) && !empty($apify['reviews'])) {
                return $apify;
            }
        }
        return GoogleReviewsRenderer::fetch_reviews($place_id); // API (cached, ≤5)
    }

    /* ── Apify provider: "Fetch all reviews" ──────────────────────────────
     *
     * Calls the compass/google-maps-reviews-scraper actor synchronously via
     * run-sync-get-dataset-items and maps the dataset to EmbedPress's review
     * shape. The Apify token is the user's (stored globally); usage is billed by
     * Apify. The sync endpoint hard-caps at 300s and returns 408 with no body on
     * overrun, so we cap maxReviews and cache aggressively. Any failure returns
     * null → caller falls back to the official 5-review API.
     *
     * @return array|null {reviews, meta}
     */
    private function fetch_via_apify($place_id, $limit, $args)
    {
        $token = GoogleReviewsRenderer::get_apify_token();
        if ($token === '' || !is_string($place_id) || $place_id === '') {
            return null;
        }

        // run-sync hard-caps at 300s, so bound the absolute fetch. $limit==0 (or
        // anything ≥ ceiling) means "all reviews up to the ceiling". This is the
        // FETCH count, not a block's display count.
        $ceiling = (int) apply_filters('embedpress/google_reviews/apify_ceiling', 200, $place_id, $args);
        $max     = ($limit <= 0) ? $ceiling : min((int) $limit, $ceiling);

        // No transient here — the DB places store is the cache. Fetching is an
        // explicit, deliberate action (settings refresh / one-time auto-fetch).
        // Pin memory to fit Apify's free 8192MB plan (see start_job()).
        $memory   = (int) apply_filters('embedpress/google_reviews/apify_fetch_memory', 1024, $place_id, $args);
        $endpoint = 'https://api.apify.com/v2/acts/compass~google-maps-reviews-scraper/run-sync-get-dataset-items?token=' . rawurlencode($token);
        if ($memory > 0) {
            $endpoint .= '&memory=' . $memory;
        }

        $payload = [
            'startUrls'  => [['url' => 'https://www.google.com/maps/place/?q=place_id:' . $place_id]],
            'placeIds'   => [$place_id],
            'maxReviews' => $max,
            'language'   => 'en',
            'reviewsSort' => $this->apify_sort($args),
        ];

        $response = wp_remote_post($endpoint, [
            'timeout' => 120, // generous, but the actor itself is capped at 300s server-side
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            return null;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200 && $code !== 201) {
            return null; // 408 timeout, 401 bad token, etc. → fall back
        }

        $items = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($items) || empty($items)) {
            return null;
        }

        $mapped = $this->map_apify_items($items);
        if (empty($mapped['reviews'])) {
            return null;
        }

        // No transient — the DB places store is the cache.
        return $mapped;
    }

    /** Map the block's sort attr to Apify's reviewsSort enum. */
    private function apify_sort($args)
    {
        switch (isset($args['sort']) ? (string) $args['sort'] : 'newest') {
            case 'highest': return 'highestRanking';
            case 'lowest':  return 'lowestRanking';
            case 'relevant': return 'mostRelevant';
            case 'newest':
            default: return 'newest';
        }
    }

    /**
     * Map Apify dataset items → {reviews, meta}. Delegates to the canonical
     * mapper in Google_Reviews_Apify so the sync ("fetch all" pre_fetch) and the
     * background (cron import) paths produce identical review shapes — including
     * the rich fields (images, owner response, local-guide, etc.).
     */
    private function map_apify_items(array $items)
    {
        return Google_Reviews_Apify::map_items($items);
    }

    /**
     * Honour a per-block cache TTL override (seconds). 0 → free default.
     */
    public function cache_ttl($ttl, $place_id, $args)
    {
        $override = isset($args['cache_ttl']) ? (int) $args['cache_ttl'] : 0;
        return $override > 0 ? $override : $ttl;
    }

    /** Dedup a review list by author + time + text fingerprint. */
    private function dedupe_reviews(array $reviews)
    {
        $seen = [];
        $out  = [];
        foreach ($reviews as $r) {
            $key = md5(($r['author_name'] ?? '') . '|' . ($r['time'] ?? '') . '|' . substr((string) ($r['text'] ?? ''), 0, 60));
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $out[] = $r;
        }
        return $out;
    }

    /* ── Sort / keyword / hide-empty are now FREE ──────────────────────────
     * Moved to the free GoogleReviewsRenderer::apply_review_filters() to mirror
     * Essential Addons' free Business Reviews widget. Pro no longer implements
     * filter_reviews (it would double-apply on top of the free pass). */

    /* ── Premium-layout preset classes (Pro) ─────────────────────────────── */

    public function wrapper_class($class, $args)
    {
        $classes = array_filter(explode(' ', (string) $class));

        // ONLY the premium-layout preset classes are Pro now. Theme (dark) +
        // autoplay class are FREE (the free GoogleReviewsRenderer adds them);
        // adding them here too would duplicate. The Pro layouts come through the
        // SINGLE layout attribute — emit the matching preset class the Pro CSS
        // targets.
        $layout = isset($args['layout']) ? sanitize_key($args['layout']) : 'list';
        if (in_array($layout, ['masonry', 'badge', 'spotlight', 'knowledge', 'marquee', 'bubble'], true)) {
            $classes[] = 'ep-gr--preset-' . $layout;
        }

        return implode(' ', array_unique($classes));
    }

    /* ── schema.org JSON-LD is now FREE ─────────────────────────────────────
     * Moved to the free GoogleReviewsRenderer::build_schema_jsonld(). Pro no
     * longer hooks the schema_jsonld filter. */

    /* ── Frontend assets (slider/masonry/dark presets) ─────────────────── */

    /**
     * REGISTER the Pro GR assets (no enqueue). Hooked on `wp_enqueue_scripts` so
     * the `embedpress-google-reviews-pro` handle exists early. Actual enqueue is
     * deferred to enqueue_frontend_assets(), fired only when GR content renders.
     *
     * The Pro style depends on the free base handle `embedpress-google-reviews`,
     * which the free AssetManager registers at priority 1 on the same hook. As a
     * safety net (older free without the manifest entry), register the base here
     * too, and drop the dep if it still isn't available — so WP 6.9.1's
     * "dependencies that are not registered" notice can never fire.
     */
    public function register_frontend_assets()
    {
        if (
            !wp_style_is('embedpress-google-reviews', 'registered')
            && class_exists('\\EmbedPress\\Includes\\Classes\\GoogleReviewsRenderer')
            && defined('EMBEDPRESS_URL_ASSETS')
        ) {
            wp_register_style(
                'embedpress-google-reviews',
                EMBEDPRESS_URL_ASSETS . 'css/google-reviews.css',
                [],
                defined('EMBEDPRESS_VERSION') ? EMBEDPRESS_VERSION : null
            );
        }

        $base_dep = wp_style_is('embedpress-google-reviews', 'registered')
            ? ['embedpress-google-reviews']
            : [];

        if (!wp_style_is('embedpress-google-reviews-pro', 'registered')) {
            wp_register_style(
                'embedpress-google-reviews-pro',
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/google-reviews-pro.css',
                $base_dep,
                defined('EMBEDPRESS_PRO_VERSION') ? EMBEDPRESS_PRO_VERSION : null
            );
        }

        if (!wp_script_is('embedpress-google-reviews-pro', 'registered')) {
            wp_register_script(
                'embedpress-google-reviews-pro',
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/google-reviews-pro.js',
                [],
                defined('EMBEDPRESS_PRO_VERSION') ? EMBEDPRESS_PRO_VERSION : null,
                true
            );
        }
    }

    /**
     * ENQUEUE the Pro GR assets. Fired only when Google Reviews content is
     * actually present — via the free renderer's render-time
     * `embedpress/google_reviews/enqueue_assets` action on the frontend, and
     * directly in the block editor / settings-preview contexts (which always
     * render GR). Ensures registration first for contexts where
     * register_frontend_assets() didn't run (editor/admin preview).
     */
    public function enqueue_frontend_assets()
    {
        if (
            !wp_style_is('embedpress-google-reviews-pro', 'registered')
            || !wp_script_is('embedpress-google-reviews-pro', 'registered')
        ) {
            $this->register_frontend_assets();
        }
        wp_enqueue_style('embedpress-google-reviews-pro');
        wp_enqueue_script('embedpress-google-reviews-pro');
    }
}
