<?php

namespace Embedpress\Pro\Filters;

use Embedpress\Pro\Analytics\Email_Reports;
use Embedpress\Pro\Analytics\Export_Manager;
use Embedpress\Pro\Analytics\Pro_Data_Collector;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — analytics service providers.
 *
 * The free plugin ships the analytics dashboard, schema and REST surface, but
 * none of the Pro-only implementations behind it. It asks for them through
 * three filters, and this class answers:
 *
 *   - embedpress/analytics/pro_collector  → geo / device / referral / per-embed
 *   - embedpress/analytics/exporter       → CSV / Excel / PDF export
 *   - embedpress/analytics/email_reports  → scheduled weekly + monthly reports
 *
 * With Pro absent every filter goes unanswered, free's callers see null and
 * each Pro-only branch degrades to its free behaviour. This mirrors the split
 * already used for Google Reviews (Google_Reviews_Pro) and the custom player.
 *
 * Instances are created once and reused, so repeated filter calls within a
 * request do not rebuild them.
 *
 * @package Embedpress\Pro\Filters
 */
class Analytics_Pro
{
    /** @var Pro_Data_Collector|null */
    private $collector;

    /** @var Export_Manager|null */
    private $exporter;

    /** @var Email_Reports|null */
    private $email_reports;

    public function __construct()
    {
        add_filter('embedpress/analytics/pro_collector', [$this, 'provide_collector']);
        add_filter('embedpress/analytics/exporter', [$this, 'provide_exporter']);
        add_filter('embedpress/analytics/email_reports', [$this, 'provide_email_reports']);
    }

    /**
     * @param object|null $collector
     * @return object
     */
    public function provide_collector($collector)
    {
        if ($this->collector === null) {
            $this->collector = new Pro_Data_Collector();
        }

        return $this->collector;
    }

    /**
     * @param object|null $exporter
     * @return object
     */
    public function provide_exporter($exporter)
    {
        if ($this->exporter === null) {
            $this->exporter = new Export_Manager();
        }

        return $this->exporter;
    }

    /**
     * @param object|null $reports
     * @return object
     */
    public function provide_email_reports($reports)
    {
        if ($this->email_reports === null) {
            $this->email_reports = new Email_Reports();
        }

        return $this->email_reports;
    }

    /**
     * Clear the report schedules when Pro is deactivated.
     *
     * The cron hooks travel with Email_Reports, so free no longer has a
     * listener for them once Pro is gone. Called from the plugin's
     * deactivation hook, alongside Broken_Embeds_API::on_deactivate().
     */
    public static function on_deactivate()
    {
        wp_clear_scheduled_hook('embedpress_weekly_analytics_report');
        wp_clear_scheduled_hook('embedpress_monthly_analytics_report');
    }
}
