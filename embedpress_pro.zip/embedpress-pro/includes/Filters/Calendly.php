<?php

namespace Embedpress\Pro\Filters;


if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Calendly dashboard — Pro owner.
 *
 * The Calendly inline/popup embed is free and needs no account connection.
 * The settings-page dashboard (Calendly OAuth connect/sync, event types,
 * scheduled events, invitees) is Pro: free's calendly.php template fires
 * `embedpress/settings/calendly_dashboard` and only prints a static upsell
 * preview when nothing is hooked. Everything that talks to api.calendly.com
 * lives here.
 *
 * Options (unchanged from when this shipped in free): calendly_tokens,
 * is_calendly_connected, calendly_user_info, calendly_event_types,
 * calendly_scheduled_events, calendly_invitees_list.
 */
class Calendly
{
    public function __construct()
    {
        // EmbedPress <= 4.6.8 renders the dashboard and handles the OAuth
        // round-trip itself (legacy-free mode): only add the 3.9.1 hooks below.
        if (\Embedpress\Pro\Classes\Bootstrap::free_has_contract()) {
            $this->register_dashboard();
        }

        // Add action hook for handling URLs
        add_action('embedpress/calendly_event_data', [$this, 'calendly_event_data'], 10, 3);
        add_action('embedpress/connected_text_label', [$this, 'connected_text_label'], 10, 2);

        add_action('embedpress/calendly_sync_button', [$this, 'calendly_sync_button'], 10, 2);
        add_action('embedpress/calendly_connect_text_label', [$this, 'calendly_connect_text_label'], 10, 2);
    }

    private function register_dashboard()
    {
        add_action('embedpress/settings/calendly_dashboard', [$this, 'render_dashboard']);

        if (!empty($_GET['page_type']) && $_GET['page_type'] == 'calendly') { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing only; handler verifies its nonce
            add_action('init', [$this, 'handle_calendly_data']);
        }
    }

    public function render_dashboard()
    {
        include EMBEDPRESS_PRO_PLUGIN_PATH . 'includes/Templates/calendly-dashboard.php';
    }

    /**
     * Store the tokens handed back by the api.embedpress.com Calendly OAuth
     * relay (or re-use the stored ones on connect/sync) and pull the account's
     * user info, event types, scheduled events and invitees.
     */
    public function handle_calendly_data()
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput -- nonce verified below
        if (empty($_GET['_nonce'])) {
            return false;
        }

        $verify = wp_verify_nonce($_GET['_nonce'], 'calendly_nonce');

        // Check if access_token or calendly_status is present and nonce is invalid
        if (!$verify) {
            echo esc_html__('Invalid nonce', 'embedpress');
            die;
        }

        if ((!empty($_GET['_nonce']) && $verify) && (!empty($_GET['access_token']) && isset($_GET['page_type']) && $_GET['page_type'] == 'calendly') || (isset($_GET['calendly_status']) && ($_GET['calendly_status'] == 'sync' || $_GET['calendly_status'] == 'connect'))) {

            if (isset($_GET['calendly_status']) && $_GET['calendly_status'] === 'connect') {
                update_option('is_calendly_connected', true);
            }

            if (isset($_GET['access_token']) && !empty($_GET['access_token'])) {
                $access_token = sanitize_text_field(wp_unslash($_GET['access_token']));
                $refresh_token = isset($_GET['refresh_token']) ? sanitize_text_field(wp_unslash($_GET['refresh_token'])) : '';
                $expires_in = isset($_GET['expires_in']) ? sanitize_text_field(wp_unslash($_GET['expires_in'])) : '';
                $created_at = isset($_GET['created_at']) ? sanitize_text_field(wp_unslash($_GET['created_at'])) : '';
            } else {
                $token_data = get_option('calendly_tokens');
                $access_token = isset($token_data['access_token']) ? $token_data['access_token'] : '';
                $refresh_token = isset($token_data['refresh_token']) ? $token_data['refresh_token'] : '';
                $expires_in = isset($token_data['expires_in']) ? $token_data['expires_in'] : '';
                $created_at = isset($token_data['created_at']) ? $token_data['created_at'] : '';
            }
            // phpcs:enable

            // Save the tokens and expiration time in a single option key
            update_option('calendly_tokens', array(
                'access_token' => $access_token,
                'refresh_token' => $refresh_token,
                'expires_in' => $expires_in,
                'created_at' => $created_at
            ));

            $user_info = json_decode((string) self::get_user_info($access_token), true);

            if (!empty($user_info['resource']['uri'])) {
                $event_types = self::get_event_types($user_info['resource']['uri'], $access_token);
                $scheduled_events = self::get_scheduled_events($user_info['resource']['uri'], $access_token);

                $invite_list = [];

                if (isset($scheduled_events['collection']) && is_array($scheduled_events['collection'])) {
                    foreach ($scheduled_events['collection'] as $event) :
                        $uuid = self::get_uuid($event['uri']);
                        $invite_list[$uuid] = self::get_event_invitees($uuid, $access_token);
                    endforeach;
                }

                update_option('calendly_user_info', $user_info);

                do_action('embedpress/calendly_event_data', $event_types, $scheduled_events, $invite_list);
            }

            wp_redirect(admin_url('admin.php?page=embedpress&page_type=calendly'), 302);
            exit();
        }
    }

    public function calendly_event_data($event_types, $scheduled_events, $invite_list)
    {
        if (empty($event_types['title'])) {
            update_option('calendly_event_types', $event_types);
            update_option('calendly_scheduled_events', $scheduled_events);
            update_option('calendly_invitees_list', $invite_list);
        }
    }

    public static function get_uuid($url)
    {
        $pattern = '/\/([0-9a-fA-F-]+)$/';
        if (preg_match($pattern, (string) $url, $matches)) {
            return $matches[1];
        }
        return '';
    }

    private static function api_get($endpoint, $access_token)
    {
        return wp_remote_get($endpoint, array(
            'headers' => array(
                'Authorization' => "Bearer $access_token",
                'Content-Type' => 'application/json',
            ),
        ));
    }

    public static function get_user_info($access_token)
    {
        $transient_name = 'calendly_user_info_' . $access_token;
        $user_info = get_transient($transient_name);
        if (false === $user_info) {
            $response = self::api_get('https://api.calendly.com/users/me', $access_token);
            if (!is_wp_error($response) && 200 === wp_remote_retrieve_response_code($response)) {
                $user_info = wp_remote_retrieve_body($response);
                set_transient($transient_name, $user_info, 3600);
            } else {
                return false;
            }
        }

        return $user_info;
    }

    public static function get_event_types($user_uri, $access_token)
    {
        $events_list = get_transient('calendly_events_list_' . md5($access_token));

        if (false === $events_list) {
            $response = self::api_get("https://api.calendly.com/event_types?user=$user_uri", $access_token);

            if (!is_wp_error($response)) {
                $events_list = json_decode(wp_remote_retrieve_body($response), true);
                set_transient('calendly_events_list', $events_list, HOUR_IN_SECONDS);
                return $events_list;
            }
        }

        return $events_list;
    }

    public static function get_event_invitees($uuid, $access_token)
    {
        $invitee_list = get_transient('calendly_invitee_list_' . md5($access_token));

        if (false === $invitee_list) {
            $response = self::api_get("https://api.calendly.com/scheduled_events/$uuid/invitees", $access_token);

            if (!is_wp_error($response)) {
                $invitee_list = json_decode(wp_remote_retrieve_body($response), true);
                set_transient('calendly_invitee_list', $invitee_list, HOUR_IN_SECONDS);
                return $invitee_list;
            }
        }

        return $invitee_list;
    }

    public static function get_scheduled_events($user_uri, $access_token)
    {
        $events_list = get_transient('calendly_events_list_' . md5($access_token));

        if (false === $events_list) {
            $response = self::api_get("https://api.calendly.com/scheduled_events?user=$user_uri", $access_token);

            if (!is_wp_error($response)) {
                $events_list = json_decode(wp_remote_retrieve_body($response), true);
                set_transient('calendly_events_list', $events_list, HOUR_IN_SECONDS);
                return $events_list;
            }
        }

        return $events_list;
    }

    public function connected_text_label($is_calendly_connected, $event_types)
    {
        if (!$is_calendly_connected) :
            echo esc_html__('Please connect with calendly.', 'embedpress-pro');
        elseif ($is_calendly_connected && isset($event_types) && count($event_types) < 1) :
            echo esc_html__('Calendly has no events.', 'embedpress-pro');
        endif;
    }

    public function calendly_sync_button($is_calendly_connected, $calendly_sync_url)
    {
        // Check if Calendly is connected and EmbedPress Pro is active
        if ($is_calendly_connected) : ?>
            <div class="calendly-sync-button">
                <a href="<?php echo esc_url($calendly_sync_url); ?>" class="calendly-connect-button" target="_self" title="<?php echo esc_attr__('Sync new Calendly data', 'embedpress'); ?>">
                    <span class="dashicons dashicons-update-alt emcs-dashicon"></span>
                    <?php echo esc_html__('Sync', 'embedpress'); ?>
                </a>
            </div>
<?php endif;
    }

    public function calendly_connect_text_label($is_calendly_connected, $sorted_events)
    {
        if (!$is_calendly_connected) :
            echo '<br>' . esc_html__('Please connect with calendly', 'embedpress');
        elseif ($is_calendly_connected && count($sorted_events) < 1) :
            echo esc_html__('Calendly has no schedule.', 'embedpress');
        endif;
    }
}
