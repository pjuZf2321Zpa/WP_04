<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — view/download count badge placement.
 *
 * Free's ep-view-count.js always renders the PDF/Document count badge below
 * the embed and announces every badge it places. The per-embed "Count
 * Position" control is Pro; assets/js/view-count-position-pro.js applies the
 * saved `data-ep-count-position` value to those badges.
 *
 * Free enqueues `embedpress-view-count` on wp_enqueue_scripts (priority 10)
 * only on pages with an opted-in embed; this follows it.
 *
 * @package Embedpress\Pro\Filters
 */
class View_Count_Position_Pro
{
    /** Free's badge script handle (View_Count_Display::enqueue_assets()). */
    const FREE_HANDLE = 'embedpress-view-count';

    const HANDLE = 'embedpress-view-count-position-pro';

    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
    }

    public function maybe_enqueue()
    {
        if (!wp_script_is(self::FREE_HANDLE, 'enqueued')) {
            return;
        }

        $relative = 'assets/js/view-count-position-pro.js';
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : '';
        if (defined('EMBEDPRESS_PRO_PLUGIN_PATH') && file_exists(EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative)) {
            $version .= '.' . filemtime(EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative);
        }

        wp_enqueue_script(
            self::HANDLE,
            EMBEDPRESS_PRO_PLUGIN_URL . $relative,
            [self::FREE_HANDLE],
            $version,
            true
        );
    }
}
