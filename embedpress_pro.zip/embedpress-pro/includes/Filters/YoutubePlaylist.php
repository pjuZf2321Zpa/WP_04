<?php

namespace Embedpress\Pro\Filters;

use EmbedPress\Includes\Classes\Helper;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Pro YouTube Playlist layouts — Library, Spotlight, Cinema, Magazine.
 *
 * Registers the layouts on free's `embedpress/youtube/playlist_layouts`
 * filter and hooks the `embedpress/youtube_{layout}_layout` actions dispatched
 * by \EmbedPress\Providers\TemplateLayouts\YoutubeLayout::create_youtube_layout()
 * for them. Each action echoes the complete .ep-yt-playlist shell —
 * selectors, data-attrs and per-item markup must match the SELECTORS table
 * in assets/js/youtube-layouts-pro.js, which registers the layouts on free's
 * playlist engine (static/js/ep-yt-queue.js: click-to-swap, infinite scroll,
 * loop/shuffle) and adds the layout-specific extras (library modal, cinema
 * overlay queue, magazine read-more). Styles: assets/css/youtube-layouts-pro.css.
 * Both are enqueued by Filters\Youtube.
 *
 * Without these handlers free renders `queue` instead.
 *
 * Infinite-scroll item HTML is produced by `render_*_items` and exposed to
 * the free REST endpoint via the `embedpress/youtube_playlist_pro_items_html`
 * filter so /youtube-playlist-items?layout=library returns the right shape.
 *
 * Signed pagination: /youtube-playlist-items only serves pages with a valid
 * `sig` (Helper::yt_page_sig()). Free signs every playlist shell — its own
 * and these — after rendering, by turning the first `<div class="ep-yt-playlist"`
 * into `<div data-ep-sig="…" class="ep-yt-playlist"` (YoutubeLayout,
 * free >= 4.6.8). So each shell must open with exactly that tag prefix and
 * must not print data-ep-sig itself (it would be duplicated).
 */
class YoutubePlaylist
{
    const PRO_PLAYLIST_LAYOUTS = ['library', 'spotlight', 'cinema', 'magazine'];

    public function __construct()
    {
        add_action('embedpress/youtube_library_layout',   [$this, 'render_library_layout'],   10, 7);
        add_action('embedpress/youtube_spotlight_layout', [$this, 'render_spotlight_layout'], 10, 7);
        add_action('embedpress/youtube_cinema_layout',    [$this, 'render_cinema_layout'],    10, 7);
        add_action('embedpress/youtube_magazine_layout',  [$this, 'render_magazine_layout'],  10, 7);

        add_filter('embedpress/youtube_playlist_pro_items_html', [$this, 'rest_items_html'], 10, 5);

        // Free only renders (and dispatches the actions above for) the
        // playlist layouts listed here; anything else falls back to Queue.
        add_filter('embedpress/youtube/playlist_layouts', [$this, 'playlist_layouts']);
    }

    public function playlist_layouts($layouts)
    {
        return array_values(array_unique(array_merge((array) $layouts, self::PRO_PLAYLIST_LAYOUTS)));
    }

    /* ----------------------------------------------------------------
     * Helpers
     * ---------------------------------------------------------------- */

    private function common_vars($options, $playlist_info, $first_vid)
    {
        $playlist_id   = isset($options['playlistId']) ? $options['playlistId'] : '';
        $title         = !empty($playlist_info['title']) ? $playlist_info['title'] : __('Playlist', 'embedpress');
        $channel_title = !empty($playlist_info['channel_title']) ? $playlist_info['channel_title'] : '';
        $item_count    = !empty($playlist_info['item_count']) ? (int) $playlist_info['item_count'] : 0;
        $playlist_url  = !empty($playlist_info['playlist_url'])
            ? $playlist_info['playlist_url']
            : 'https://www.youtube.com/playlist?list=' . rawurlencode($playlist_id);
        $start_vid   = !empty($playlist_info['start_vid']) ? $playlist_info['start_vid'] : '';
        $opening_vid = $start_vid ?: $first_vid;
        $first_src   = $opening_vid
            ? 'https://www.youtube.com/embed/' . $opening_vid . '?feature=oembed&enablejsapi=1'
            : 'about:blank';
        return [
            'playlist_id'   => $playlist_id,
            'title'         => $title,
            'channel_title' => $channel_title,
            'item_count'    => $item_count,
            'playlist_url'  => $playlist_url,
            'opening_vid'   => $opening_vid,
            'first_src'     => $first_src,
        ];
    }

    private function item_fields($item, $options)
    {
        $privacyStatus = isset($item->status->privacyStatus) ? $item->status->privacyStatus : null;
        return [
            'privacy'    => $privacyStatus,
            'vid'        => Helper::get_id($item),
            'title'      => isset($item->snippet->title) ? $item->snippet->title : '',
            'desc'       => isset($item->snippet->description) ? (string) $item->snippet->description : '',
            'channel'    => isset($item->snippet->videoOwnerChannelTitle)
                ? $item->snippet->videoOwnerChannelTitle
                : (isset($item->snippet->channelTitle) ? $item->snippet->channelTitle : ''),
            'thumb'      => Helper::get_thumbnail_url($item, !empty($options['thumbnail']) ? $options['thumbnail'] : 'medium', $privacyStatus),
            'publishedAt'=> isset($item->snippet->publishedAt) ? $item->snippet->publishedAt : '',
        ];
    }

    private function is_active($f, $active_vid, $auto_active, $i)
    {
        if ($active_vid && $f['vid'] === $active_vid) return ' is-active';
        if ($auto_active && $i === 1)                 return ' is-active';
        return '';
    }

    /* ----------------------------------------------------------------
     * Library — grid of cards, click opens modal player
     * ---------------------------------------------------------------- */

    public function render_library_layout($jsonResult, $gallobj, $options, $data, $playlist_info, $first_vid, $next_page_token)
    {
        $v = $this->common_vars($options, $playlist_info, $first_vid);
        ?>
        <div class="ep-yt-playlist" data-layout="library"
             data-playlist-id="<?php echo esc_attr($v['playlist_id']); ?>"
             data-pagesize="<?php echo intval($options['pagesize']); ?>"
             data-next-page-token="<?php echo esc_attr($next_page_token); ?>"
             data-total="<?php echo esc_attr($v['item_count']); ?>">
            <div class="ep-yt-library">
                <header class="ep-yt-library__header">
                    <a class="ep-yt-library__title" href="<?php echo esc_url($v['playlist_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($v['title']); ?></a>
                    <div class="ep-yt-library__meta">
                        <?php if ($v['channel_title']) : ?>
                            <span class="ep-yt-library__channel"><?php echo esc_html($v['channel_title']); ?></span>
                            <span class="ep-yt-library__sep">&middot;</span>
                        <?php endif; ?>
                        <span class="ep-yt-library__position"><span class="ep-yt-library__position-current">1</span> / <span class="ep-yt-library__position-total"><?php echo esc_html($v['item_count']); ?></span></span>
                    </div>
                </header>
                <div class="ep-yt-library__grid">
                    <?php echo $this->render_library_items($jsonResult, $options, 0, $v['opening_vid']); ?>
                </div>
                <div class="ep-yt-library__loader" hidden>
                    <span class="ep-yt-library__spinner" aria-hidden="true"></span>
                    <span class="ep-yt-library__loader-text"><?php esc_html_e('Loading more…', 'embedpress'); ?></span>
                </div>
            </div>
            <div class="ep-yt-library__modal" hidden role="dialog" aria-modal="true">
                <div class="ep-yt-library__modal-inner">
                    <button type="button" class="ep-yt-library__modal-close" aria-label="<?php echo esc_attr__('Close', 'embedpress'); ?>">&times;</button>
                    <iframe class="ep-yt-library__modal-iframe"
                            src="<?php echo esc_url($v['first_src']); ?>"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen
                            title="<?php echo esc_attr($v['title']); ?>"></iframe>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_library_items($jsonResult, $options, $offset = 0, $active_vid = '')
    {
        if (empty($jsonResult->items) || !is_array($jsonResult->items)) return '';
        ob_start();
        $i = (int) $offset;
        $auto_active = empty($active_vid) && $offset === 0;
        foreach ($jsonResult->items as $item) {
            $i++;
            $f = $this->item_fields($item, $options);
            if ($f['privacy'] === 'private' && !empty($options['hideprivate'])) continue;
            $active = $this->is_active($f, $active_vid, $auto_active, $i);
            ?>
            <button type="button"
                    class="ep-yt-library__card<?php echo $active; ?>"
                    data-vid="<?php echo esc_attr($f['vid']); ?>"
                    data-index="<?php echo esc_attr($i); ?>"
                    data-title="<?php echo esc_attr($f['title']); ?>"
                    data-description="<?php echo esc_attr($f['desc']); ?>">
                <span class="ep-yt-library__card-thumb-wrap">
                    <img class="ep-yt-library__card-thumb" src="<?php echo esc_url($f['thumb']); ?>" alt="" loading="lazy" />
                    <span class="ep-yt-library__card-play" aria-hidden="true">▶</span>
                </span>
                <span class="ep-yt-library__card-title"><?php echo esc_html($f['title']); ?></span>
                <?php if ($f['channel']) : ?>
                    <span class="ep-yt-library__card-channel"><?php echo esc_html($f['channel']); ?></span>
                <?php endif; ?>
            </button>
            <?php
        }
        return ob_get_clean();
    }

    /* ----------------------------------------------------------------
     * Spotlight — hero player, side rail of cards, hero title/desc swap
     * ---------------------------------------------------------------- */

    public function render_spotlight_layout($jsonResult, $gallobj, $options, $data, $playlist_info, $first_vid, $next_page_token)
    {
        $v = $this->common_vars($options, $playlist_info, $first_vid);
        $hero_title = '';
        $hero_desc  = '';
        if (!empty($jsonResult->items[0])) {
            $first = $this->item_fields($jsonResult->items[0], $options);
            $hero_title = $first['title'];
            $hero_desc  = $first['desc'];
        }
        ?>
        <div class="ep-yt-playlist" data-layout="spotlight"
             data-playlist-id="<?php echo esc_attr($v['playlist_id']); ?>"
             data-pagesize="<?php echo intval($options['pagesize']); ?>"
             data-next-page-token="<?php echo esc_attr($next_page_token); ?>"
             data-total="<?php echo esc_attr($v['item_count']); ?>">
            <div class="ep-yt-spotlight">
                <div class="ep-yt-spotlight__stage">
                    <div class="ep-yt-spotlight__player">
                        <iframe class="ep-yt-spotlight__iframe"
                                src="<?php echo esc_url($v['first_src']); ?>"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen
                                title="<?php echo esc_attr($v['title']); ?>"></iframe>
                    </div>
                    <div class="ep-yt-spotlight__hero">
                        <h3 class="ep-yt-spotlight__hero-title"><?php echo esc_html($hero_title); ?></h3>
                        <p class="ep-yt-spotlight__hero-desc"><?php echo esc_html($hero_desc); ?></p>
                        <div class="ep-yt-spotlight__hero-meta">
                            <?php if ($v['channel_title']) : ?>
                                <span class="ep-yt-spotlight__channel"><?php echo esc_html($v['channel_title']); ?></span>
                                <span class="ep-yt-spotlight__sep">&middot;</span>
                            <?php endif; ?>
                            <span class="ep-yt-spotlight__position"><span class="ep-yt-spotlight__position-current">1</span> / <span class="ep-yt-spotlight__position-total"><?php echo esc_html($v['item_count']); ?></span></span>
                            <div class="ep-yt-spotlight__controls">
                                <button type="button" class="ep-yt-spotlight__loop ep-yt-icon-btn" aria-pressed="false" aria-label="<?php echo esc_attr__('Loop', 'embedpress'); ?>" title="<?php echo esc_attr__('Loop', 'embedpress'); ?>">
                                    <span class="ep-yt-icon ep-yt-icon--loop" aria-hidden="true"></span>
                                </button>
                                <button type="button" class="ep-yt-spotlight__shuffle ep-yt-icon-btn" aria-pressed="false" aria-label="<?php echo esc_attr__('Shuffle', 'embedpress'); ?>" title="<?php echo esc_attr__('Shuffle', 'embedpress'); ?>">
                                    <span class="ep-yt-icon ep-yt-icon--shuffle" aria-hidden="true"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <aside class="ep-yt-spotlight__rail-wrap">
                    <header class="ep-yt-spotlight__rail-header">
                        <a class="ep-yt-spotlight__rail-title" href="<?php echo esc_url($v['playlist_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($v['title']); ?></a>
                    </header>
                    <ol class="ep-yt-spotlight__rail">
                        <?php echo $this->render_spotlight_items($jsonResult, $options, 0, $v['opening_vid']); ?>
                    </ol>
                    <div class="ep-yt-spotlight__loader" hidden>
                        <span class="ep-yt-spotlight__spinner" aria-hidden="true"></span>
                        <span class="ep-yt-spotlight__loader-text"><?php esc_html_e('Loading more…', 'embedpress'); ?></span>
                    </div>
                </aside>
            </div>
        </div>
        <?php
    }

    public function render_spotlight_items($jsonResult, $options, $offset = 0, $active_vid = '')
    {
        if (empty($jsonResult->items) || !is_array($jsonResult->items)) return '';
        ob_start();
        $i = (int) $offset;
        $auto_active = empty($active_vid) && $offset === 0;
        foreach ($jsonResult->items as $item) {
            $i++;
            $f = $this->item_fields($item, $options);
            if ($f['privacy'] === 'private' && !empty($options['hideprivate'])) continue;
            $active = $this->is_active($f, $active_vid, $auto_active, $i);
            ?>
            <li class="ep-yt-spotlight__rail-card<?php echo $active; ?>"
                data-vid="<?php echo esc_attr($f['vid']); ?>"
                data-index="<?php echo esc_attr($i); ?>"
                data-title="<?php echo esc_attr($f['title']); ?>"
                data-description="<?php echo esc_attr($f['desc']); ?>">
                <span class="ep-yt-spotlight__rail-thumb-wrap">
                    <img class="ep-yt-spotlight__rail-thumb" src="<?php echo esc_url($f['thumb']); ?>" alt="" loading="lazy" />
                    <span class="ep-yt-spotlight__rail-num"><?php echo esc_html($i); ?></span>
                </span>
                <span class="ep-yt-spotlight__rail-body">
                    <span class="ep-yt-spotlight__rail-card-title"><?php echo esc_html($f['title']); ?></span>
                    <?php if ($f['channel']) : ?>
                        <span class="ep-yt-spotlight__rail-card-channel"><?php echo esc_html($f['channel']); ?></span>
                    <?php endif; ?>
                </span>
            </li>
            <?php
        }
        return ob_get_clean();
    }

    /* ----------------------------------------------------------------
     * Cinema — immersive full-bleed player, slide-out queue overlay
     * ---------------------------------------------------------------- */

    public function render_cinema_layout($jsonResult, $gallobj, $options, $data, $playlist_info, $first_vid, $next_page_token)
    {
        $v = $this->common_vars($options, $playlist_info, $first_vid);
        ?>
        <div class="ep-yt-playlist" data-layout="cinema"
             data-playlist-id="<?php echo esc_attr($v['playlist_id']); ?>"
             data-pagesize="<?php echo intval($options['pagesize']); ?>"
             data-next-page-token="<?php echo esc_attr($next_page_token); ?>"
             data-total="<?php echo esc_attr($v['item_count']); ?>">
            <div class="ep-yt-cinema">
                <div class="ep-yt-cinema__player">
                    <iframe class="ep-yt-cinema__iframe"
                            src="<?php echo esc_url($v['first_src']); ?>"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen
                            title="<?php echo esc_attr($v['title']); ?>"></iframe>
                </div>
                <div class="ep-yt-cinema__bar">
                    <a class="ep-yt-cinema__title" href="<?php echo esc_url($v['playlist_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($v['title']); ?></a>
                    <div class="ep-yt-cinema__sub">
                        <?php if ($v['channel_title']) : ?>
                            <span class="ep-yt-cinema__channel"><?php echo esc_html($v['channel_title']); ?></span>
                            <span class="ep-yt-cinema__sep">&middot;</span>
                        <?php endif; ?>
                        <span class="ep-yt-cinema__position"><span class="ep-yt-cinema__position-current">1</span> / <span class="ep-yt-cinema__position-total"><?php echo esc_html($v['item_count']); ?></span></span>
                    </div>
                    <div class="ep-yt-cinema__controls">
                        <button type="button" class="ep-yt-cinema__loop ep-yt-icon-btn" aria-pressed="false" aria-label="<?php echo esc_attr__('Loop', 'embedpress'); ?>" title="<?php echo esc_attr__('Loop', 'embedpress'); ?>">
                            <span class="ep-yt-icon ep-yt-icon--loop" aria-hidden="true"></span>
                        </button>
                        <button type="button" class="ep-yt-cinema__shuffle ep-yt-icon-btn" aria-pressed="false" aria-label="<?php echo esc_attr__('Shuffle', 'embedpress'); ?>" title="<?php echo esc_attr__('Shuffle', 'embedpress'); ?>">
                            <span class="ep-yt-icon ep-yt-icon--shuffle" aria-hidden="true"></span>
                        </button>
                        <button type="button" class="ep-yt-cinema__open-queue ep-yt-icon-btn" aria-label="<?php echo esc_attr__('Open queue', 'embedpress'); ?>">
                            <?php esc_html_e('Queue', 'embedpress'); ?>
                        </button>
                    </div>
                </div>
                <div class="ep-yt-cinema__overlay">
                    <div class="ep-yt-cinema__overlay-inner">
                        <header class="ep-yt-cinema__overlay-header">
                            <span class="ep-yt-cinema__overlay-title"><?php esc_html_e('Up next', 'embedpress'); ?></span>
                            <button type="button" class="ep-yt-cinema__close-queue ep-yt-icon-btn" aria-label="<?php echo esc_attr__('Close queue', 'embedpress'); ?>">&times;</button>
                        </header>
                        <ol class="ep-yt-cinema__items">
                            <?php echo $this->render_cinema_items($jsonResult, $options, 0, $v['opening_vid']); ?>
                        </ol>
                        <div class="ep-yt-cinema__loader" hidden>
                            <span class="ep-yt-cinema__spinner" aria-hidden="true"></span>
                            <span class="ep-yt-cinema__loader-text"><?php esc_html_e('Loading more…', 'embedpress'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_cinema_items($jsonResult, $options, $offset = 0, $active_vid = '')
    {
        if (empty($jsonResult->items) || !is_array($jsonResult->items)) return '';
        ob_start();
        $i = (int) $offset;
        $auto_active = empty($active_vid) && $offset === 0;
        foreach ($jsonResult->items as $item) {
            $i++;
            $f = $this->item_fields($item, $options);
            if ($f['privacy'] === 'private' && !empty($options['hideprivate'])) continue;
            $active = $this->is_active($f, $active_vid, $auto_active, $i);
            ?>
            <li class="ep-yt-cinema__item<?php echo $active; ?>"
                data-vid="<?php echo esc_attr($f['vid']); ?>"
                data-index="<?php echo esc_attr($i); ?>">
                <span class="ep-yt-cinema__item-index"><?php echo esc_html($i); ?></span>
                <img class="ep-yt-cinema__item-thumb" src="<?php echo esc_url($f['thumb']); ?>" alt="" loading="lazy" />
                <span class="ep-yt-cinema__item-body">
                    <span class="ep-yt-cinema__item-title"><?php echo esc_html($f['title']); ?></span>
                    <?php if ($f['channel']) : ?>
                        <span class="ep-yt-cinema__item-channel"><?php echo esc_html($f['channel']); ?></span>
                    <?php endif; ?>
                </span>
            </li>
            <?php
        }
        return ob_get_clean();
    }

    /* ----------------------------------------------------------------
     * Magazine — editorial hero with description + read-more, rail of cards
     * ---------------------------------------------------------------- */

    public function render_magazine_layout($jsonResult, $gallobj, $options, $data, $playlist_info, $first_vid, $next_page_token)
    {
        $v = $this->common_vars($options, $playlist_info, $first_vid);
        $hero_title = '';
        $hero_desc  = '';
        if (!empty($jsonResult->items[0])) {
            $first = $this->item_fields($jsonResult->items[0], $options);
            $hero_title = $first['title'];
            $hero_desc  = $first['desc'];
        }
        ?>
        <div class="ep-yt-playlist" data-layout="magazine"
             data-playlist-id="<?php echo esc_attr($v['playlist_id']); ?>"
             data-pagesize="<?php echo intval($options['pagesize']); ?>"
             data-next-page-token="<?php echo esc_attr($next_page_token); ?>"
             data-total="<?php echo esc_attr($v['item_count']); ?>">
            <div class="ep-yt-magazine">
                <article class="ep-yt-magazine__hero">
                    <div class="ep-yt-magazine__player">
                        <iframe class="ep-yt-magazine__iframe"
                                src="<?php echo esc_url($v['first_src']); ?>"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen
                                title="<?php echo esc_attr($v['title']); ?>"></iframe>
                    </div>
                    <div class="ep-yt-magazine__hero-body">
                        <a class="ep-yt-magazine__hero-eyebrow" href="<?php echo esc_url($v['playlist_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($v['title']); ?></a>
                        <h2 class="ep-yt-magazine__hero-title"><?php echo esc_html($hero_title); ?></h2>
                        <p class="ep-yt-magazine__hero-desc"><?php echo esc_html($hero_desc); ?></p>
                        <button type="button" class="ep-yt-magazine__readmore"
                                data-expand-label="<?php echo esc_attr__('Read more', 'embedpress'); ?>"
                                data-collapse-label="<?php echo esc_attr__('Show less', 'embedpress'); ?>">
                            <?php esc_html_e('Read more', 'embedpress'); ?>
                        </button>
                        <div class="ep-yt-magazine__hero-meta">
                            <?php if ($v['channel_title']) : ?>
                                <span class="ep-yt-magazine__channel"><?php echo esc_html($v['channel_title']); ?></span>
                                <span class="ep-yt-magazine__sep">&middot;</span>
                            <?php endif; ?>
                            <span class="ep-yt-magazine__position"><span class="ep-yt-magazine__position-current">1</span> / <span class="ep-yt-magazine__position-total"><?php echo esc_html($v['item_count']); ?></span></span>
                            <div class="ep-yt-magazine__controls">
                                <button type="button" class="ep-yt-magazine__loop ep-yt-icon-btn" aria-pressed="false" aria-label="<?php echo esc_attr__('Loop', 'embedpress'); ?>" title="<?php echo esc_attr__('Loop', 'embedpress'); ?>">
                                    <span class="ep-yt-icon ep-yt-icon--loop" aria-hidden="true"></span>
                                </button>
                                <button type="button" class="ep-yt-magazine__shuffle ep-yt-icon-btn" aria-pressed="false" aria-label="<?php echo esc_attr__('Shuffle', 'embedpress'); ?>" title="<?php echo esc_attr__('Shuffle', 'embedpress'); ?>">
                                    <span class="ep-yt-icon ep-yt-icon--shuffle" aria-hidden="true"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </article>
                <section class="ep-yt-magazine__rail-wrap">
                    <header class="ep-yt-magazine__rail-header">
                        <span class="ep-yt-magazine__rail-label"><?php esc_html_e('More in this playlist', 'embedpress'); ?></span>
                    </header>
                    <ol class="ep-yt-magazine__rail">
                        <?php echo $this->render_magazine_items($jsonResult, $options, 0, $v['opening_vid']); ?>
                    </ol>
                    <div class="ep-yt-magazine__loader" hidden>
                        <span class="ep-yt-magazine__spinner" aria-hidden="true"></span>
                        <span class="ep-yt-magazine__loader-text"><?php esc_html_e('Loading more…', 'embedpress'); ?></span>
                    </div>
                </section>
            </div>
        </div>
        <?php
    }

    public function render_magazine_items($jsonResult, $options, $offset = 0, $active_vid = '')
    {
        if (empty($jsonResult->items) || !is_array($jsonResult->items)) return '';
        ob_start();
        $i = (int) $offset;
        $auto_active = empty($active_vid) && $offset === 0;
        foreach ($jsonResult->items as $item) {
            $i++;
            $f = $this->item_fields($item, $options);
            if ($f['privacy'] === 'private' && !empty($options['hideprivate'])) continue;
            $active = $this->is_active($f, $active_vid, $auto_active, $i);
            ?>
            <li class="ep-yt-magazine__rail-item<?php echo $active; ?>"
                data-vid="<?php echo esc_attr($f['vid']); ?>"
                data-index="<?php echo esc_attr($i); ?>"
                data-title="<?php echo esc_attr($f['title']); ?>"
                data-description="<?php echo esc_attr($f['desc']); ?>">
                <span class="ep-yt-magazine__rail-thumb-wrap">
                    <img class="ep-yt-magazine__rail-thumb" src="<?php echo esc_url($f['thumb']); ?>" alt="" loading="lazy" />
                </span>
                <span class="ep-yt-magazine__rail-body">
                    <span class="ep-yt-magazine__rail-card-title"><?php echo esc_html($f['title']); ?></span>
                    <?php if ($f['channel']) : ?>
                        <span class="ep-yt-magazine__rail-card-channel"><?php echo esc_html($f['channel']); ?></span>
                    <?php endif; ?>
                </span>
            </li>
            <?php
        }
        return ob_get_clean();
    }

    /* ----------------------------------------------------------------
     * REST infinite-scroll bridge — keep markup-contract logic for
     * library/spotlight/cinema/magazine in this file. Free RestAPI.php
     * applies this filter when ?layout matches a Pro layout.
     * ---------------------------------------------------------------- */

    public function rest_items_html($html, $layout, $json, $options, $offset)
    {
        switch ($layout) {
            case 'library':   return $this->render_library_items($json, $options, $offset, '');
            case 'spotlight': return $this->render_spotlight_items($json, $options, $offset, '');
            case 'cinema':    return $this->render_cinema_items($json, $options, $offset, '');
            case 'magazine':  return $this->render_magazine_items($json, $options, $offset, '');
        }
        return $html;
    }
}
