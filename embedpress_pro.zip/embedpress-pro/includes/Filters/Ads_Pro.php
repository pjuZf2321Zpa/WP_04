<?php

namespace Embedpress\Pro\Filters;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Ad Manager (Showcase Ads) playback engine loader.
 *
 * Free keeps the Ad Manager controls and emits the `[data-sponsored-id]`
 * wrapper with the block / widget attributes; Pro builds the ad overlay
 * (Utility::generate_ad_template()) and runs it with assets/js/sponsored.js,
 * which this class enqueues.
 *
 * The script loads wherever free's front script (`embedpress-front`) loads —
 * the same "any EmbedPress content" rule free used when it shipped the file —
 * on the frontend, in the Elementor preview and in the block editor.
 *
 * @package Embedpress\Pro\Filters
 */
class Ads_Pro
{
    const HANDLE = 'embedpress-ads';

    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'maybe_enqueue'], 20);
        // Elementor can enqueue free's front script late, while rendering a
        // widget. Footer scripts print on wp_footer priority 20, so a late
        // check here still makes it.
        add_action('wp_footer', [$this, 'maybe_enqueue'], 1);
    }

    public function maybe_enqueue()
    {
        if (wp_script_is(self::HANDLE, 'enqueued') || !wp_script_is('embedpress-front', 'enqueued')) {
            return;
        }

        if (!wp_script_is(self::HANDLE, 'registered')) {
            wp_register_script(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/sponsored.js',
                ['jquery', 'embedpress-front'],
                EMBEDPRESS_PRO_PLUGIN_VERSION,
                true
            );
        }

        wp_enqueue_script(self::HANDLE);
    }
}
