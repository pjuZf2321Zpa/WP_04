<?php

namespace Embedpress\Pro\Filters;

use EmbedPress\Includes\Classes\Helper as FreeHelper;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — PDF / Document viewer options.
 *
 * Free builds the PDF.js / flipbook viewer params (the base64 `key` blob)
 * with default values for the options the Pro add-on unlocks — toolbar,
 * print/download, copy text, draw, default selection tool, default
 * scrolling, RTL page flip and the watermark_* keys — and passes the array
 * through `embedpress/pdf/viewer_params` (see free's
 * Helper::pdf_viewer_params()). This class applies the site owner's chosen
 * values for those keys, exactly as free did itself before the split.
 *
 * It also releases the block editor's hold on those options
 * (`embedpress.pdf.lockedViewerDefaults`, assets/js/pdf-editor-pro.js).
 *
 * @package Embedpress\Pro\Filters
 */
class Pdf_Viewer_Pro
{
    public function __construct()
    {
        add_filter('embedpress/pdf/viewer_params', [$this, 'viewer_params'], 10, 3);
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_editor_script']);
    }

    /**
     * Block editor: stop free's PDF block from holding the Pro viewer options
     * at their defaults (free's `embedpress.pdf.lockedViewerDefaults` slot).
     */
    public function enqueue_editor_script()
    {
        wp_enqueue_script(
            'embedpress-pro-pdf-editor',
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/pdf-editor-pro.js',
            ['wp-hooks'],
            EMBEDPRESS_PRO_PLUGIN_VERSION,
            true
        );
    }

    /**
     * @param array  $params     Param array built by free.
     * @param array  $attributes Raw attributes / settings of the surface.
     * @param string $context    Render surface — see free's Helper::pdf_viewer_params().
     * @return array
     */
    public function viewer_params($params, $attributes, $context)
    {
        if (!is_array($params)) {
            return $params;
        }

        $a = is_array($attributes) ? $attributes : [];

        switch ($context) {
            case 'shortcode':
                $values = $this->shortcode($a);
                break;
            case 'shortcode_gallery':
                $values = $this->shortcode_gallery($a);
                break;
            case 'gutenberg':
                $values = $this->gutenberg($a);
                break;
            case 'gutenberg_gallery':
                $values = $this->gutenberg_gallery($a);
                break;
            case 'elementor':
                $values = $this->elementor($a);
                break;
            case 'elementor_wrapper':
                $values = [
                    'data-download' => esc_attr(isset($a['pdf_print_download']) ? $a['pdf_print_download'] : ''),
                    'data-copy'     => esc_attr(isset($a['pdf_text_copy']) ? $a['pdf_text_copy'] : ''),
                ];
                break;
            case 'elementor_gallery':
                $values = $this->elementor_gallery($a);
                break;
            case 'elementor_document':
                $values = [
                    'toolbar'  => !empty($a['doc_toolbar']) ? 'true' : 'false',
                    'download' => isset($a['doc_print_download']) ? $a['doc_print_download'] : null,
                ];
                break;
            default:
                return $params;
        }

        // Only overwrite keys free already emits, so the key order (and the
        // encoded blob) stays exactly what it was.
        foreach ($values as $key => $value) {
            if (array_key_exists($key, $params)) {
                $params[$key] = $value;
            }
        }

        return $params;
    }

    /** `[embedpress_pdf]` — attribute names as typed in the shortcode. */
    private function shortcode($a)
    {
        return [
            'toolbar'             => isset($a['toolbar']) ? esc_attr($a['toolbar']) : 'true',
            'download'            => isset($a['download']) ? esc_attr($a['download']) : 'true',
            'copy_text'           => isset($a['copy_text']) ? esc_attr($a['copy_text']) : 'true',
            'draw'                => isset($a['draw']) ? esc_attr($a['draw']) : 'true',
            'selection_tool'      => isset($a['selection_tool']) ? esc_attr($a['selection_tool']) : '0',
            'scrolling'           => isset($a['scrolling']) ? esc_attr($a['scrolling']) : '-1',
            'flipbook_rtl'        => $this->is_true_string($a, 'flipbook_rtl') ? 'true' : 'false',
            'watermark_text'      => isset($a['watermarkText']) ? esc_attr($a['watermarkText']) : '',
            'watermark_font_size' => isset($a['watermarkFontSize']) ? esc_attr($a['watermarkFontSize']) : '48',
            'watermark_color'     => isset($a['watermarkColor']) ? esc_attr($a['watermarkColor']) : '#000000',
            'watermark_opacity'   => isset($a['watermarkOpacity']) ? esc_attr($a['watermarkOpacity']) : '15',
            'watermark_style'     => isset($a['watermarkStyle']) ? esc_attr($a['watermarkStyle']) : 'center',
        ];
    }

    /** `[embedpress_pdf_gallery]` — attributes after shortcode_atts(). */
    private function shortcode_gallery($a)
    {
        return [
            'toolbar'             => isset($a['toolbar']) ? esc_attr($a['toolbar']) : 'true',
            'download'            => isset($a['download']) ? esc_attr($a['download']) : 'true',
            'copy_text'           => isset($a['copy_text']) ? esc_attr($a['copy_text']) : 'true',
            'draw'                => isset($a['draw']) ? esc_attr($a['draw']) : 'true',
            'flipbook_rtl'        => $this->is_true_string($a, 'flipbook_rtl') ? 'true' : 'false',
            'watermark_text'      => isset($a['watermark_text']) ? esc_attr($a['watermark_text']) : '',
            'watermark_font_size' => isset($a['watermark_font_size']) ? esc_attr($a['watermark_font_size']) : '48',
            'watermark_color'     => isset($a['watermark_color']) ? esc_attr($a['watermark_color']) : '#000000',
            'watermark_opacity'   => isset($a['watermark_opacity']) ? esc_attr($a['watermark_opacity']) : '15',
            'watermark_style'     => isset($a['watermark_style']) ? esc_attr($a['watermark_style']) : 'center',
        ];
    }

    /** PDF block (`embedpress/embedpress-pdf`) server render — camelCase block attributes. */
    private function gutenberg($a)
    {
        return [
            'toolbar'             => !empty($a['toolbar']) ? 'true' : 'false',
            'download'            => !empty($a['download']) ? 'true' : 'false',
            'copy_text'           => !empty($a['copy_text']) ? 'true' : 'false',
            'draw'                => !empty($a['draw']) ? 'true' : 'false',
            'flipbook_rtl'        => !empty($a['flipbookPageFlipRTL']) ? 'true' : 'false',
            'selection_tool'      => isset($a['selection_tool']) ? esc_attr($a['selection_tool']) : '0',
            'scrolling'           => isset($a['scrolling']) ? esc_attr($a['scrolling']) : '-1',
            'watermark_text'      => !empty($a['watermarkText']) ? esc_attr($a['watermarkText']) : '',
            'watermark_font_size' => !empty($a['watermarkFontSize']) ? esc_attr($a['watermarkFontSize']) : '48',
            'watermark_color'     => !empty($a['watermarkColor']) ? esc_attr($a['watermarkColor']) : '#000000',
            'watermark_opacity'   => isset($a['watermarkOpacity']) ? esc_attr($a['watermarkOpacity']) : '15',
            'watermark_style'     => !empty($a['watermarkStyle']) ? esc_attr($a['watermarkStyle']) : 'center',
        ];
    }

    /** PDF Gallery block (`embedpress/pdf-gallery`) server render. */
    private function gutenberg_gallery($a)
    {
        return [
            'toolbar'             => !empty($a['toolbar']) ? 'true' : 'false',
            'download'            => !empty($a['download']) ? 'true' : 'false',
            'copy_text'           => !empty($a['copy_text']) ? 'true' : 'false',
            'draw'                => !empty($a['draw']) ? 'true' : 'false',
            'flipbook_rtl'        => !empty($a['flipbookPageFlipRTL']) ? 'true' : 'false',
            'watermark_text'      => isset($a['watermarkText']) ? esc_attr($a['watermarkText']) : '',
            'watermark_font_size' => isset($a['watermarkFontSize']) ? intval($a['watermarkFontSize']) : 48,
            'watermark_color'     => isset($a['watermarkColor']) ? esc_attr($a['watermarkColor']) : '#000000',
            'watermark_opacity'   => isset($a['watermarkOpacity']) ? intval($a['watermarkOpacity']) : 15,
            'watermark_style'     => isset($a['watermarkStyle']) ? esc_attr($a['watermarkStyle']) : 'center',
        ];
    }

    /** Elementor PDF widget settings. */
    private function elementor($s)
    {
        return [
            'toolbar'             => !empty($s['pdf_toolbar']) ? 'true' : 'false',
            // Raw switcher values ('yes' / ''), as the widget always sent them.
            'download'            => isset($s['pdf_print_download']) ? $s['pdf_print_download'] : null,
            'copy_text'           => isset($s['pdf_text_copy']) ? $s['pdf_text_copy'] : null,
            'draw'                => isset($s['draw']) ? $s['draw'] : null,
            'flipbook_rtl'        => !empty($s['pdf_flipbook_rtl']) && $s['pdf_flipbook_rtl'] === 'yes' ? 'true' : 'false',
            'selection_tool'      => isset($s['selection_tool']) ? esc_attr($s['selection_tool']) : '0',
            'scrolling'           => isset($s['scrolling']) ? esc_attr($s['scrolling']) : '-1',
            'watermark_text'      => !empty($s['embedpress_watermark_text']) ? $s['embedpress_watermark_text'] : '',
            'watermark_font_size' => !empty($s['embedpress_watermark_font_size']) ? $s['embedpress_watermark_font_size'] : '48',
            'watermark_color'     => !empty($s['embedpress_watermark_color']) ? FreeHelper::get_elementor_global_color($s, 'embedpress_watermark_color') : '#000000',
            'watermark_opacity'   => isset($s['embedpress_watermark_opacity']) ? $s['embedpress_watermark_opacity'] : '15',
            'watermark_style'     => !empty($s['embedpress_watermark_style']) ? $s['embedpress_watermark_style'] : 'center',
        ];
    }

    /** Elementor PDF Gallery widget settings. */
    private function elementor_gallery($s)
    {
        return [
            'toolbar'             => !empty($s['pdf_toolbar']) ? 'true' : 'false',
            'download'            => !empty($s['download']) ? 'true' : 'false',
            'copy_text'           => !empty($s['copy_text']) ? 'true' : 'false',
            'draw'                => !empty($s['draw']) ? 'true' : 'false',
            'flipbook_rtl'        => !empty($s['flipbook_rtl']) && $s['flipbook_rtl'] === 'yes' ? 'true' : 'false',
            'watermark_text'      => !empty($s['watermark_text']) ? $s['watermark_text'] : '',
            'watermark_font_size' => !empty($s['watermark_font_size']) ? $s['watermark_font_size'] : '48',
            'watermark_color'     => !empty($s['watermark_color']) ? FreeHelper::get_elementor_global_color($s, 'watermark_color') : '#000000',
            'watermark_opacity'   => isset($s['watermark_opacity']) ? $s['watermark_opacity'] : '15',
            'watermark_style'     => !empty($s['watermark_style']) ? $s['watermark_style'] : 'center',
        ];
    }

    private function is_true_string($a, $key)
    {
        return isset($a[$key]) && ($a[$key] === 'true' || $a[$key] === true);
    }
}
