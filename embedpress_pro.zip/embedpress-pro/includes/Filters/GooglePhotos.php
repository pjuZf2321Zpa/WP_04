<?php

namespace Embedpress\Pro\Filters;

use Embedpress_Google_Helper;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — Google Photos.
 *
 * - Slideshow attributes for the free player modes
 *   (`embedpress_google_photos_attributes`).
 * - The Grid / Masonry / Justify album modes. Free renders only Carousel and
 *   Gallery Player; it asks `embedpress/google_photos/modes` which modes can be
 *   rendered and `embedpress/google_photos/gallery_html` for their markup.
 *   Their styles, lightbox and justify sizing live in
 *   assets/css/google-photos-pro.css + assets/js/google-photos-pro.js, enqueued
 *   wherever free's frontend script (`embedpress-front`) is.
 */
class GooglePhotos
{
    /** Free's frontend script handle (Core/AssetManager.php). */
    const FREE_HANDLE = 'embedpress-front';

    const HANDLE = 'embedpress-google-photos-pro';

    const PRO_MODES = ['gallery-grid', 'gallery-masonary', 'gallery-justify'];

    public function __construct()
    {
        // Add action hook for handling URLs
        add_filter('embedpress_google_photos_attributes', [$this, 'embedpress_google_photos_attributes'], 10, 2);

        // EmbedPress <= 4.6.8 renders Grid / Masonry / Justify (and loads
        // their script) itself (legacy-free mode).
        if (!\Embedpress\Pro\Classes\Bootstrap::free_has_contract()) {
            return;
        }

        add_filter('embedpress/google_photos/modes', [$this, 'modes']);
        add_filter('embedpress/google_photos/gallery_html', [$this, 'gallery_html'], 10, 4);

        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_assets', [$this, 'maybe_enqueue'], 20);
        add_action('enqueue_block_editor_assets', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/frontend/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'maybe_enqueue'], 20);
        // Free may enqueue its frontend script late (content-dependent).
        add_action('wp_footer', [$this, 'maybe_enqueue'], 1);
    }

    public function embedpress_google_photos_attributes($attributes, $props)
    {

        // Add or modify attributes as needed
        $attributes['data-autoplay'] = $props->slideshowAutoplay;
        $attributes['data-delay'] = $props->slideshowDelay > 0 ? $props->slideshowDelay : null;
        $attributes['data-repeat'] = $props->repeat;

        if($props->slideshowAutoplay === 'yes'){
            $attributes['data-autoplay'] == 'true';
        }
        if($props->slideshowAutoplay !== 'yes'){
            $attributes['data-autoplay'] == 'false';
        }
        if($props->repeat === 'yes'){
            $attributes['data-repeat'] == 'true';
        }
        if($props->repeat !== 'yes'){
            $attributes['data-repeat'] == 'false';
        }

        return $attributes;
    }

    /**
     * @param string[] $modes Modes free can render.
     * @return string[]
     */
    public function modes($modes)
    {
        return array_values(array_unique(array_merge((array) $modes, self::PRO_MODES)));
    }

    /**
     * Markup of a Grid / Masonry / Justify album.
     *
     * @param string    $html
     * @param \stdClass $props
     * @param string[]  $photos
     * @param string    $title
     * @return string
     */
    public function gallery_html($html, $props, $photos, $title)
    {
        if (!in_array($props->mode, self::PRO_MODES, true)) {
            return $html;
        }

        $items_code = sprintf('<div class="photos-%s">', esc_attr($props->mode));
        $counter = 0;

        foreach ((array) $photos as $photo) {
            $preview_src = sprintf('%s=w%d-h%d', $photo, $props->imageWidth, $props->imageHeight);
            $full_src = $photo . '=w2500';

            $items_code .= sprintf(
                '<div class="photo-item" data-item-number="%d" id="photo-%s">
                    <img data-photo-src="%s" src="%s" loading="lazy" alt="Photo"/>
                </div>',
                esc_attr($counter++),
                md5($preview_src),
                esc_url($full_src),
                esc_url($preview_src)
            );
        }

        $items_code .= '</div>';

        return sprintf(
            "<div class=\"google-photos-%s-widget\">%s%s</div>\n",
            esc_attr($props->mode),
            !empty($title) && (!isset($props->showTitle) || $props->showTitle) ? "<h3 style='text-align:left; margin: 22px 10px;'>" . esc_html($title) . "</h3>" : '',
            $items_code
        );
    }

    public function maybe_enqueue()
    {
        if (!wp_script_is(self::FREE_HANDLE, 'enqueued')) {
            return;
        }

        if (!wp_script_is(self::HANDLE, 'registered')) {
            wp_register_script(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/google-photos-pro.js',
                ['jquery', self::FREE_HANDLE],
                self::version('assets/js/google-photos-pro.js'),
                true
            );
            wp_register_style(
                self::HANDLE,
                EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/google-photos-pro.css',
                [],
                self::version('assets/css/google-photos-pro.css')
            );
        }

        wp_enqueue_script(self::HANDLE);
        wp_enqueue_style(self::HANDLE);
    }

    /** Plugin version, plus the file's mtime so edits bust caches. */
    private static function version($relative)
    {
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : '';
        $path = defined('EMBEDPRESS_PRO_PLUGIN_PATH') ? EMBEDPRESS_PRO_PLUGIN_PATH . '/' . $relative : '';
        if ($path !== '' && file_exists($path)) {
            $version .= '.' . filemtime($path);
        }
        return $version;
    }
}
