<?php

namespace Embedpress\Pro\Analytics;

use EmbedPress\Includes\Classes\Analytics\License_Manager;

defined('ABSPATH') or die("No direct script access allowed.");

/**
 * EmbedPress Pro — Broken Embeds REST API + cron registration
 *
 * Owns the lifecycle wiring for the Broken Embed Source URL Detection
 * feature: REST routes, scheduled scan, deactivation cleanup.
 *
 * @package Embedpress\Pro\Analytics
 * @since   3.9.0
 */
class Broken_Embeds_API
{
    const CRON_HOOK             = 'embedpress_pro_daily_broken_embed_scan';
    const LAST_SCAN_OPTION      = 'embedpress_pro_broken_embed_last_scan_at';
    const REST_NAMESPACE        = 'embedpress/v1';
    const ROUTE_LIST            = '/analytics/broken-embeds';
    const ROUTE_RECHECK         = '/analytics/broken-embeds/recheck';

    public function init()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('init', [$this, 'maybe_schedule_cron']);
        add_action(self::CRON_HOOK, [$this, 'run_scheduled_scan']);
    }

    /**
     * Static cleanup hook called from embedpress-pro.php deactivation hook.
     */
    public static function on_deactivate()
    {
        wp_clear_scheduled_hook(self::CRON_HOOK);
    }

    public function register_routes()
    {
        register_rest_route(self::REST_NAMESPACE, self::ROUTE_LIST, [
            'methods'             => 'GET',
            'callback'            => [$this, 'rest_list'],
            'permission_callback' => [$this, 'check_admin'],
            'args' => [
                'only_broken' => [
                    'required' => false,
                    'type'     => 'boolean',
                    'default'  => false,
                ],
                'limit' => [
                    'required'          => false,
                    'type'              => 'integer',
                    'default'           => 200,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);

        register_rest_route(self::REST_NAMESPACE, self::ROUTE_RECHECK, [
            'methods'             => 'POST',
            'callback'            => [$this, 'rest_recheck'],
            'permission_callback' => [$this, 'check_admin'],
            'args' => [
                'url' => [
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'esc_url_raw',
                ],
                'embed_type' => [
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'batch_size' => [
                    'required'          => false,
                    'type'              => 'integer',
                    'default'           => 50,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ]);
    }

    public function check_admin()
    {
        if (!current_user_can('manage_options')) {
            return new \WP_Error('forbidden', __('Insufficient permissions.', 'embedpress-pro'), ['status' => 403]);
        }
        if (!$this->has_pro_license()) {
            return new \WP_Error('license', __('A valid EmbedPress Pro license is required.', 'embedpress-pro'), ['status' => 403]);
        }
        return true;
    }

    public function rest_list($request)
    {
        $detector = new Broken_Embeds_Detector();

        $items = $detector->get_status_list([
            'only_broken' => (bool) $request->get_param('only_broken'),
            'limit'       => (int) ($request->get_param('limit') ?: 200),
        ]);

        $broken_count = 0;
        foreach ($items as $item) {
            if (($item['last_check_status'] ?? '') === Broken_Embeds_Detector::STATUS_BROKEN) {
                $broken_count++;
            }
        }

        return new \WP_REST_Response([
            'items'        => $items,
            'broken_count' => $broken_count,
            'total'        => count($items),
            'last_scan_at' => get_option(self::LAST_SCAN_OPTION) ?: null,
        ], 200);
    }

    public function rest_recheck($request)
    {
        $detector = new Broken_Embeds_Detector();
        $url      = $request->get_param('url');

        if (!empty($url)) {
            $result = $detector->recheck_url($url, (string) $request->get_param('embed_type'));
            return new \WP_REST_Response([
                'success' => true,
                'mode'    => 'single',
                'url'     => $url,
                'result'  => $result,
            ], 200);
        }

        $summary = $detector->scan_all([
            'batch_size' => (int) ($request->get_param('batch_size') ?: 50),
        ]);

        update_option(self::LAST_SCAN_OPTION, current_time('mysql'));

        return new \WP_REST_Response([
            'success' => empty($summary['error']),
            'mode'    => 'batch',
            'summary' => $summary,
        ], 200);
    }

    public function maybe_schedule_cron()
    {
        if (!$this->has_pro_license()) {
            // Pro plugin file is loaded but license isn't valid — make sure
            // we don't have a stale schedule.
            if (wp_next_scheduled(self::CRON_HOOK)) {
                wp_clear_scheduled_hook(self::CRON_HOOK);
            }
            return;
        }

        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK);
        }
    }

    public function run_scheduled_scan()
    {
        if (!$this->has_pro_license()) {
            return;
        }

        $detector = new Broken_Embeds_Detector();
        $detector->scan_all(['batch_size' => 50]);
        update_option(self::LAST_SCAN_OPTION, current_time('mysql'));
    }

    private function has_pro_license()
    {
        if (class_exists(License_Manager::class)) {
            return License_Manager::has_pro_license();
        }
        // Fallback: Pro plugin file is loaded, so the constant check is the
        // best signal available without Free's License_Manager.
        return defined('EMBEDPRESS_SL_ITEM_SLUG');
    }
}
