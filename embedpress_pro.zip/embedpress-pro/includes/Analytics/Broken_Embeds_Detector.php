<?php

namespace Embedpress\Pro\Analytics;

defined('ABSPATH') or die("No direct script access allowed.");

/**
 * EmbedPress Pro — Broken Embeds Detector
 *
 * Scans embed source URLs tracked in the analytics content table and flags
 * those that have become unreachable (HTTP error, removed video, revoked
 * access, etc.). Results are persisted on each row of the content table so
 * the admin dashboard can render them without making any network calls.
 *
 * Pro-only: instantiated and used by Broken_Embeds_API after a license
 * check passes.
 *
 * @package Embedpress\Pro\Analytics
 * @since   3.9.0
 */
class Broken_Embeds_Detector
{
    const STATUS_OK      = 'ok';
    const STATUS_BROKEN  = 'broken';
    const STATUS_UNKNOWN = 'unknown';

    const SCAN_LOCK_OPTION = 'embedpress_pro_broken_embed_scan_lock';
    const LOCK_TTL_SECONDS = 600;

    /** @var int Per-request HTTP timeout (seconds). */
    private $timeout = 5;

    /** @var int Default batch size for cron-driven scans. */
    private $batch_size = 50;

    /**
     * Return the list of distinct embed URLs and their last-known check status.
     *
     * @param array $args { only_broken?: bool, limit?: int }
     * @return array<int, array<string,mixed>>
     */
    public function get_status_list($args = [])
    {
        global $wpdb;
        $table = $wpdb->prefix . 'embedpress_analytics_content';

        $only_broken = !empty($args['only_broken']);
        $limit       = isset($args['limit']) ? max(1, (int) $args['limit']) : 200;

        $where = $only_broken ? "WHERE last_check_status = 'broken'" : '';

        $rows = $wpdb->get_results(
            "SELECT
                id,
                content_id,
                embed_type,
                embed_url,
                post_id,
                page_url,
                title,
                last_check_status,
                last_check_code,
                last_check_message,
                last_check_at
            FROM $table
            $where
            ORDER BY (last_check_status = 'broken') DESC, updated_at DESC
            LIMIT $limit",
            ARRAY_A
        );

        if (!$rows) {
            return [];
        }

        return array_map([$this, 'format_row'], $rows);
    }

    /**
     * Run a full scan across every distinct embed URL, persisting results.
     * Safe to call from a cron tick or an admin-triggered re-check.
     *
     * @param array $args { batch_size?: int, force?: bool }
     * @return array<string,mixed> Summary { scanned, broken, ok, skipped }
     */
    public function scan_all($args = [])
    {
        if ($this->is_external_blocked()) {
            return [
                'scanned' => 0,
                'broken'  => 0,
                'ok'      => 0,
                'skipped' => 0,
                'error'   => 'external_http_blocked',
            ];
        }

        if (!$this->acquire_lock() && empty($args['force'])) {
            return [
                'scanned' => 0,
                'broken'  => 0,
                'ok'      => 0,
                'skipped' => 0,
                'error'   => 'scan_in_progress',
            ];
        }

        try {
            global $wpdb;
            $table      = $wpdb->prefix . 'embedpress_analytics_content';
            $batch_size = isset($args['batch_size']) ? max(1, (int) $args['batch_size']) : $this->batch_size;

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT DISTINCT embed_url, embed_type
                     FROM $table
                     WHERE embed_url <> ''
                     ORDER BY (last_check_at IS NULL) DESC, last_check_at ASC
                     LIMIT %d",
                    $batch_size
                ),
                ARRAY_A
            );

            $summary = ['scanned' => 0, 'broken' => 0, 'ok' => 0, 'skipped' => 0];

            if (!$rows) {
                return $summary;
            }

            foreach ($rows as $row) {
                $url = $row['embed_url'];
                if (empty($url)) {
                    $summary['skipped']++;
                    continue;
                }

                $result = $this->check_url($url, $row['embed_type']);
                $this->persist_result($url, $result);

                $summary['scanned']++;
                $summary[$result['status'] === self::STATUS_BROKEN ? 'broken' : 'ok']++;
            }

            return $summary;
        } finally {
            $this->release_lock();
        }
    }

    /**
     * Check a single URL and return its status without persisting.
     */
    public function check_url($url, $embed_type = '')
    {
        $url = esc_url_raw(trim((string) $url));
        if (empty($url)) {
            return $this->result(self::STATUS_UNKNOWN, null, 'empty_url');
        }

        // Same-origin embeds (self-hosted PDF/video/doc on this site) can't
        // be checked over the network reliably — PHP often can't loopback to
        // the site's public host (docker, firewall, LB without hairpinning).
        // If WP can render the post, visitors can fetch the file.
        if ($this->is_same_origin($url)) {
            return $this->result(self::STATUS_OK, 200, 'self_hosted_skipped');
        }

        // SSRF guard. The embed URL is attacker-controllable (any Author can
        // plant one through an Elementor/Gutenberg embed), and this scanner
        // fetches it server-side from cron. Refuse anything that isn't a
        // plain http(s) URL pointing at a public, externally-resolvable host —
        // blocking loopback / private / link-local (cloud metadata) / reserved
        // ranges so the scanner can't be turned into an internal port-scan
        // oracle or a metadata-endpoint reader.
        if (!$this->is_fetchable_public_url($url)) {
            return $this->result(self::STATUS_UNKNOWN, null, 'blocked_non_public_host');
        }

        // oEmbed endpoints are far more reliable than HEAD/GET on the watch
        // page itself, which returns HTTP 200 even when a video has been
        // deleted, made private, or removed.
        $oembed_result = $this->oembed_check($url, $embed_type);
        if ($oembed_result !== null) {
            return $oembed_result;
        }

        $args = [
            'timeout'     => $this->timeout,
            'redirection' => 5,
            'user-agent'  => $this->user_agent(),
            'sslverify'   => true,
        ];

        // Use the wp_safe_remote_* variants: they run wp_http_validate_url()
        // on the target AND on every redirect hop, so a public URL that 30x-
        // redirects to an internal address (a redirect-based SSRF bypass our
        // up-front host check can't see) is still rejected by WP core.
        $response = wp_safe_remote_head($url, $args);

        if (is_wp_error($response)) {
            return $this->result(self::STATUS_UNKNOWN, null, $response->get_error_message());
        }

        $code = (int) wp_remote_retrieve_response_code($response);

        if ($code === 405 || $code === 0) {
            $args['timeout'] = max(3, $this->timeout - 2);
            $response = wp_safe_remote_get($url, $args);

            if (is_wp_error($response)) {
                return $this->result(self::STATUS_UNKNOWN, null, $response->get_error_message());
            }

            $code = (int) wp_remote_retrieve_response_code($response);

            $body_check = $this->provider_body_check($embed_type, wp_remote_retrieve_body($response));
            if ($body_check !== null) {
                return $body_check;
            }
        }

        // Only 404 and 410 are unambiguous "resource is gone". 401/403/405/
        // 406/429/5xx commonly mean the host is bot-hostile (Google Docs,
        // Cloudflare-fronted CDNs, etc.) or rate-limiting — flagging those
        // as broken produces false positives for URLs that work fine in a
        // real browser.
        if ($code === 404 || $code === 410) {
            return $this->result(self::STATUS_BROKEN, $code, sprintf('HTTP %d', $code));
        }

        if ($code >= 400 || $code === 0) {
            return $this->result(self::STATUS_UNKNOWN, $code ?: null, sprintf('HTTP %d inconclusive', $code));
        }

        return $this->result(self::STATUS_OK, $code, 'ok');
    }

    /**
     * Force a re-check for a single URL, bypassing batch ordering.
     */
    public function recheck_url($url, $embed_type = '')
    {
        $result = $this->check_url($url, $embed_type);
        $this->persist_result($url, $result);
        return $result;
    }

    private function oembed_check($url, $embed_type)
    {
        $provider = $this->detect_provider($url, $embed_type);
        if ($provider === null) {
            return null;
        }

        $resource_url = $this->normalize_for_oembed($url, $provider['key']);
        if ($resource_url === null) {
            return null;
        }

        $endpoint = $provider['endpoint'] . '?url=' . rawurlencode($resource_url) . '&format=json';

        $response = wp_safe_remote_get($endpoint, [
            'timeout'     => $this->timeout,
            'redirection' => 3,
            'user-agent'  => $this->user_agent(),
            'sslverify'   => true,
        ]);

        if (is_wp_error($response)) {
            return null;
        }

        $code = (int) wp_remote_retrieve_response_code($response);

        if (in_array($code, [401, 403, 404, 410], true)) {
            return $this->result(
                self::STATUS_BROKEN,
                $code,
                sprintf('%s_oembed_%d', $provider['key'], $code)
            );
        }

        if ($code >= 200 && $code < 300) {
            $body = wp_remote_retrieve_body($response);
            if (!empty($body) && $this->is_valid_oembed_payload($body)) {
                return $this->result(self::STATUS_OK, $code, 'oembed_ok');
            }
        }

        return null;
    }

    private function normalize_for_oembed($url, $provider_key)
    {
        $parts = wp_parse_url($url);
        if (empty($parts['host'])) {
            return null;
        }

        $host = strtolower($parts['host']);
        $path = isset($parts['path']) ? $parts['path'] : '';

        if ($provider_key === 'youtube') {
            if (strpos($host, 'youtu.be') !== false) {
                $id = ltrim($path, '/');
            } elseif (preg_match('#^/(embed|v|shorts|live)/([A-Za-z0-9_-]{6,})#', $path, $m)) {
                $id = $m[2];
            } elseif (!empty($parts['query'])) {
                parse_str($parts['query'], $q);
                $id = isset($q['v']) ? $q['v'] : null;
            } else {
                $id = null;
            }

            $id = $id ? preg_replace('/[^A-Za-z0-9_-]/', '', $id) : '';
            if ($id === '') {
                return null;
            }
            return 'https://www.youtube.com/watch?v=' . $id;
        }

        if ($provider_key === 'vimeo') {
            if (preg_match('#/(?:video/)?(\d+)#', $path, $m)) {
                return 'https://vimeo.com/' . $m[1];
            }
            return null;
        }

        return $url;
    }

    private function detect_provider($url, $embed_type)
    {
        $type = strtolower((string) $embed_type);
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));

        if (strpos($type, 'youtube') !== false ||
            strpos($host, 'youtube.com') !== false ||
            strpos($host, 'youtu.be') !== false) {
            return ['key' => 'youtube', 'endpoint' => 'https://www.youtube.com/oembed'];
        }

        if (strpos($type, 'vimeo') !== false || strpos($host, 'vimeo.com') !== false) {
            return ['key' => 'vimeo', 'endpoint' => 'https://vimeo.com/api/oembed.json'];
        }

        return null;
    }

    private function is_valid_oembed_payload($body)
    {
        $data = json_decode($body, true);
        return is_array($data) && (
            !empty($data['html']) ||
            !empty($data['title']) ||
            !empty($data['provider_name'])
        );
    }

    private function persist_result($url, $result)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'embedpress_analytics_content';

        $wpdb->update(
            $table,
            [
                'last_check_status'  => $result['status'],
                'last_check_code'    => $result['code'],
                'last_check_message' => mb_substr((string) $result['message'], 0, 255),
                'last_check_at'      => current_time('mysql'),
            ],
            ['embed_url' => $url],
            ['%s', '%d', '%s', '%s'],
            ['%s']
        );
    }

    private function provider_body_check($embed_type, $body)
    {
        if (empty($body)) {
            return null;
        }

        $type = strtolower((string) $embed_type);

        if (strpos($type, 'youtube') !== false) {
            if (stripos($body, 'Video unavailable') !== false ||
                stripos($body, '"status":"ERROR"') !== false ||
                stripos($body, 'This video isn\'t available') !== false) {
                return $this->result(self::STATUS_BROKEN, 200, 'youtube_video_unavailable');
            }
        }

        if (strpos($type, 'vimeo') !== false) {
            if (stripos($body, 'Sorry, we couldn') !== false ||
                stripos($body, 'Page not found') !== false) {
                return $this->result(self::STATUS_BROKEN, 200, 'vimeo_not_found');
            }
        }

        return null;
    }

    private function result($status, $code, $message)
    {
        return [
            'status'  => $status,
            'code'    => is_numeric($code) ? (int) $code : null,
            'message' => $message,
        ];
    }

    private function format_row($row)
    {
        $post_id   = (int) $row['post_id'];
        $edit_link = $post_id > 0 ? get_edit_post_link($post_id, 'raw') : null;

        $checked_at = $row['last_check_at'];
        $checked_ts = $checked_at ? strtotime($checked_at) : null;

        return [
            'id'                 => (int) $row['id'],
            'content_id'         => $row['content_id'],
            'embed_type'         => $row['embed_type'],
            'embed_url'          => $row['embed_url'],
            'post_id'            => $post_id ?: null,
            'page_url'           => $row['page_url'],
            'edit_link'          => $edit_link ?: null,
            'title'              => $row['title'] ?: $row['content_id'],
            'last_check_status'  => $row['last_check_status'] ?: self::STATUS_UNKNOWN,
            'last_check_code'    => $row['last_check_code'] !== null ? (int) $row['last_check_code'] : null,
            'last_check_message' => $row['last_check_message'],
            'last_check_at'      => $checked_at,
            'last_check_at_ts'   => $checked_ts,
        ];
    }

    private function user_agent()
    {
        $version = defined('EMBEDPRESS_PRO_PLUGIN_VERSION') ? EMBEDPRESS_PRO_PLUGIN_VERSION : 'dev';
        // Lead with a Mozilla token — many CDNs (Google, Cloudflare) serve
        // 403/404 to UAs that don't look browser-shaped, which would mark
        // perfectly valid embeds as broken.
        return sprintf(
            'Mozilla/5.0 (compatible; EmbedPress/%s; +%s)',
            $version,
            home_url('/')
        );
    }

    private function is_same_origin($url)
    {
        $url_host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if ($url_host === '') {
            return false;
        }

        $candidates = [home_url('/'), site_url('/')];
        foreach ($candidates as $candidate) {
            $host = strtolower((string) wp_parse_url($candidate, PHP_URL_HOST));
            if ($host !== '' && $host === $url_host) {
                return true;
            }
        }

        return false;
    }

    /**
     * SSRF gate: is this a plain http(s) URL pointing at a public host whose
     * every resolved IP is a routable, non-reserved address?
     *
     * Rejects: non-http(s) schemes, URLs carrying credentials, hosts that fail
     * to resolve, and any host that resolves (wholly or partially) to a
     * loopback / private / link-local / reserved / non-public IP. Resolving
     * up-front and checking every returned address also blunts DNS-rebinding
     * (a public name that answers with 127.0.0.1 / 169.254.169.254 / 10.x …).
     */
    private function is_fetchable_public_url($url)
    {
        $parts = wp_parse_url($url);
        if (empty($parts) || empty($parts['host'])) {
            return false;
        }

        // Only http/https. Blocks file://, gopher://, dict://, ftp://, etc.
        $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
        if ($scheme !== 'http' && $scheme !== 'https') {
            return false;
        }

        // Reject embedded credentials (http://user:pass@host) — a common SSRF
        // filter-bypass vector and never legitimate for an embed URL.
        if (isset($parts['user']) || isset($parts['pass'])) {
            return false;
        }

        $host = strtolower(trim($parts['host'], " \t\n\r\0\x0B[]"));
        if ($host === '') {
            return false;
        }

        // Collect the candidate IPs: a literal IP host, or every A/AAAA record
        // the name resolves to.
        $ips = [];
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $ips[] = $host;
        } else {
            $ips = $this->resolve_host_ips($host);
            if (empty($ips)) {
                // Can't resolve → can't prove it's public → refuse to fetch.
                return false;
            }
        }

        foreach ($ips as $ip) {
            if (!$this->is_public_ip($ip)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Resolve a hostname to its IPv4 + IPv6 addresses. Returns [] on failure.
     */
    private function resolve_host_ips($host)
    {
        $ips = [];

        $a = @gethostbynamel($host);
        if (is_array($a)) {
            $ips = array_merge($ips, $a);
        }

        if (function_exists('dns_get_record')) {
            $aaaa = @dns_get_record($host, DNS_AAAA);
            if (is_array($aaaa)) {
                foreach ($aaaa as $rec) {
                    if (!empty($rec['ipv6'])) {
                        $ips[] = $rec['ipv6'];
                    }
                }
            }
        }

        return array_values(array_unique(array_filter($ips)));
    }

    /**
     * True only for a globally-routable public IP. Rejects loopback, private,
     * link-local (incl. 169.254.169.254 cloud metadata), and reserved ranges
     * for both IPv4 and IPv6.
     */
    private function is_public_ip($ip)
    {
        $ip = trim((string) $ip, "[]");
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return false;
        }

        return (bool) filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
    }

    private function is_external_blocked()
    {
        return defined('WP_HTTP_BLOCK_EXTERNAL') && WP_HTTP_BLOCK_EXTERNAL;
    }

    private function acquire_lock()
    {
        $existing = get_transient(self::SCAN_LOCK_OPTION);
        if ($existing) {
            return false;
        }
        return set_transient(self::SCAN_LOCK_OPTION, time(), self::LOCK_TTL_SECONDS);
    }

    private function release_lock()
    {
        delete_transient(self::SCAN_LOCK_OPTION);
    }
}
