<?php

namespace Embedpress\Pro\Analytics;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * EmbedPress Pro — analytics dashboard assets.
 *
 * Free owns the analytics page and renders two Pro-only pieces through
 * wp.hooks extension slots (the geo map and the export control). This
 * enqueues the bundle that fills them.
 *
 * Load order — what actually makes the slots connect:
 * WP_Scripts prints dependencies first, so free's `embedpress-analytics` tag
 * comes *before* this one. That still works because free rewrites its own
 * tag to `type="module"` (EmbedPress\Analytics\Analytics, script_loader_tag),
 * and module scripts are deferred: this classic script runs at parse time,
 * registering its addFilter() calls before free's bundle executes and mounts
 * the dashboard. If free ever drops the module rewrite, these filters would
 * register after the first render and the map and export menu would vanish
 * without an error. The dependency itself is there so this only loads where
 * free's dashboard does.
 *
 * @package Embedpress\Pro\Analytics
 */
class Dashboard_Assets
{
    /** Free's analytics page hook suffix. */
    const SCREEN = 'embedpress_page_embedpress-analytics';

    const HANDLE = 'embedpress-analytics-pro';

    public function init()
    {
        // Priority 20: after free's own admin_enqueue_scripts callback has
        // registered the `embedpress-analytics` handle this depends on.
        add_action('admin_enqueue_scripts', [$this, 'enqueue'], 20);
    }

    /**
     * @param string $hook Current admin page hook suffix.
     * @return void
     */
    public function enqueue($hook)
    {
        if ($hook !== self::SCREEN) {
            return;
        }

        // If free's bundle is not on the page there is no dashboard to
        // extend, and no slots to fill.
        if (!wp_script_is('embedpress-analytics', 'enqueued')) {
            return;
        }

        wp_enqueue_script(
            self::HANDLE,
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/js/analytics-pro.build.js',
            ['wp-element', 'wp-hooks', 'wp-i18n', 'embedpress-analytics'],
            EMBEDPRESS_PRO_PLUGIN_VERSION,
            true
        );

        // Strings in this bundle use the `embedpress-pro` text domain.
        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations(self::HANDLE, 'embedpress-pro', EMBEDPRESS_PRO_PLUGIN_PATH . 'languages');
        }

        wp_enqueue_style(
            self::HANDLE,
            EMBEDPRESS_PRO_PLUGIN_URL . 'assets/css/analytics-pro.build.css',
            ['embedpress-analytics'],
            EMBEDPRESS_PRO_PLUGIN_VERSION
        );
    }
}
