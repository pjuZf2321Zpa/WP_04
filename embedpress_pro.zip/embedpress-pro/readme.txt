=== EmbedPress Pro ===
Contributors: wpdevteam
Tags: EmbedPress, vimeo, youtube, wistia
Requires at least: 4.6
Tested up to: 7.0
Stable tag: 3.10.1
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Extend flexibility from Vimeo, YouTube, Wistia embeds rendered by EmbedPress.

== Description ==
Extend flexibility from Vimeo, youtube, wistia embeds rendered by EmbedPress.

== Installation ==
There're two ways to install EmbedPress Pro plugin:

**Through your WordPress site's admin**

1. Go to your site's admin page;
2. Access the "Plugins" page;
3. Click on the "Add New" button;
4. Search for "EmbedPress Pro";
5. Install EmbedPress Pro plugin;
6. Activate the EmbedPress Pro plugin.

**Manually uploading the plugin to your repository**

1. Download the EmbedPress Pro plugin zip file;
2. Upload the plugin to your site's repository under the *"/wp-content/plugins/"* directory;
3. Go to your site's admin page;
4. Access the "Plugins" page;
5. Activate the EmbedPress pro plugin.

== Usage ==
- Make sure you have EmbedPress plugin installed and active;
- Go to EmbedPress Settings page, click on "Vimeo","Youtube","wistia", tab and customize its options at will;
- That's it.

== Changelog ==

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

= [3.10.1] - 2026-11-04 =
* Fixed: The private Google Calendar could be used to spend the site's Google Calendar API quota on any calendar (security fix).
* Fixed: The video description popup in the YouTube Grid and Carousel channel layouts keeps working with EmbedPress 4.7.2.
* Few minor bug fixes and improvements.

= [3.10.0] - 2026-10-19 =
* Improved: All Pro features now ship inside EmbedPress Pro instead of the free plugin: advanced analytics, content protection, PDF watermark, custom player extras, custom branding, ads, lazy load and the Pro layouts. Requires EmbedPress 4.7.0 or newer.
* Improved: HLS/DASH streaming libraries for the custom player are bundled with the plugin instead of loading from a CDN.
* Fixed: Password protection was ignored for the [embedpress_pdf] shortcode.
* Fixed: The PDF watermark script loaded on PDFs without watermark text.
* Few minor bug fixes and improvements.

= [3.9.1] - 2026-09-24 =
* Fixed: License manager not initializing correctly on some installs.
* Few minor bug fixes and improvements.

= [3.9.0] - 2026-07-08 =
* Added: Google Reviews embedding.
* Fixed: Improved security for the Broken Embeds URL scanner (SSRF).
* Few minor bug fixes and improvements.

= [3.8.12] - 2026-06-23 =
* Added: RTL page direction support for Presentation Mode PDFs and FlipBook.
* Few minor bug fixes and improvements.

= [3.8.11] - 2026-06-08 =
* Added: Dynamic source support for PDF and Document embeds.
* Added: New Library, Spotlight, Cinema, and Magazine layouts for YouTube Playlist Gallery.
* Few minor bug fixes and improvements.

= [3.8.10] - 2026-05-25 =
* Added: WPML and multilingual support for Admin Settings.
* Few minor bug fixes and improvements.

= [3.8.9] - 2026-05-07 =
* Added: Broken source URL detection in Analytics.
* Added: HLS and DASH support for self-hosted videos.
* Added: Email Capture in Custom Player to collect viewer emails.
* Added: Action Lock in Custom Player for interaction-based playback.
* Added: Timed CTA in Custom Player to show messages and buttons during playback.
* Added: Video Chapters in Custom Player for easier navigation.
* Added: Auto Resume Playback in Custom Player.
* Added: Custom End Screen in Custom Player for messages, offers, and redirects.
* Added: Drop-off Heatmap in Custom Player to track viewer engagement.
* Added: Adaptive Streaming in Custom Player for automatic video quality adjustment.
* Added: Country Restriction in Custom Player.
* Added: Advanced Privacy Mode in Custom Player for better privacy protection.
* Added: LMS Course Completion Tracking in Custom Player.
* Added: Built-in CDN Offloading in Custom Player for improved performance.
* Improved: Better organized Custom Player controls with collapsible sections in Gutenberg and Elementor.
* Few minor bug fixes and improvements.

= [3.8.8] - 2026-04-20 =
* Added: Twitch Gutenberg controls with overrides and chat toggle.
* Few minor bug fixes and improvements.

= [3.8.7] - 2026-04-06 =
* Added: PDF Gallery support via widget/block.
* Added: Watermark support for PDFs and PDF galleries.
* Few minor bug fixes and improvements.

= [3.8.6] - 2025-01-28 =
* Improved: UI/UX for YouTube embedding
* Fixed: Content protection issue with multiple password-protected items on one page
* Few minor bug fixes and improvements

= [3.8.5] - 2025-01-5 =
* Added: Flexible date & time controls for Meetup events.
* Few minor bug fixes and improvements

= [3.8.4] - 2025-12-15 =
* Improved: Lazy loading support for all embed sources.
* Few minor bug fixes and improvements.

= [3.8.3] - 2025-11-04 =
* Improved: Meetup group controls for all editors
* Few minor bug fixes and improvements.

= [3.8.2] - 2025-10-08 =
* Added: Meetup group events embedding.
* Fixed: Embedded Audio file wasn't showing properly.
* Few minor bug fixes & improvements

= [3.8.1] - 2025-09-17 =
* Improved: License activation flow for smoother setup
* Few minor bug fixes and improvements

= [3.8.0] - 2025-09-15 =
* Added: EmbedPress Analytics
* Revamped: Code structure for enhanced performance.
* Few minor bug fixes & improvements.

= [3.7.1] - 2025-06-03 =
* Fixed: Custom Ads weren’t displaying properly on Elementor
* Few minor bug fixes & improvements.

= [3.7.0] - 2025-04-24 =
* Fixed: Text domain error in WordPress 6.8
* Minor bug fixes and overall stability enhancements.

= [3.6.12] - 2025-03-04 =
* Fixed: Wistia captions not displaying issue
* Minor bug fixes and overall stability enhancements.

= [3.6.11] - 2025-01-22 =
* Added: User role-based content protection feature.
* Added: Content protection support for the Classic Editor.
* Minor bug fixes and overall stability enhancements.

= [3.6.10] - 2025-01-06 =
* Added: Google Photos embedding with advanced layout & controls.
* Few minor bug fix and improvements.

= [3.6.9] - 2024-11-25 =
* [Fixed]: Ads and content protection features were not working simultaneously.
* [Bug] Few minor bug fixes & improvements.

= [3.6.8] - 2024-11-07 =
* [Added]: Hand controls for zooming levels in Embedded PDF.
* [Improved]: YouTube embedding for better performance.
* [Bug] Few minor bug fixes & improvements.

= [3.6.7] - 2024-10-23 =
* [Added]: Spreaker embedding support with advanced controls.
* [Bug] Few minor bug fix and improvements.

= [3.6.6] - 2024-10-03 =
* [Fixed]: Twitch video embedding issue in Elementor. 
* [Bug] Few minor bug fix and improvements.

= [3.6.5] - 2024-09-10 =
* [Improved]: Refactored codebase for enhanced performance.  
* [Bug] Few minor bug fix and improvements.


= [3.6.4] - 2024-08-22 =
* [Improved]: License activation process. 
* [Bug] Few minor bug fix and improvements.

= [3.6.3] - 2024-07-07 =
* [Improved]: Security Enhancement.
* [Bug] Few minor bug fix and improvements.

= [3.6.2] - 2024-04-16 =
* [Improved]: Optimized codes for better performance.
* [Bug] Few minor bug fix and improvements.

= [3.6.1] - 2024-01-09 =
* [Fixed]: Deprecated issues with PHP 8.1
* [Bug] Few minor bug fix and improvements.

= [3.6.0] - 2023-12-27 =
* [Added] Custom ADs feature.
* [Bug] Few minor bug fix and improvements.

= [3.5.5] - 2023-11-23 =
* [Bug] Few minor bug fix and improvements.

= [3.5.4] - 2023-11-23 =
* [Improved] Security enhancement for better performance.
* [Bug] Few minor bug fix and improvements.

= [3.5.3] - 2023-09-21 =
* [Added] Calendly Event types and Scheduled Events
* [Fixed] PHP 8.2 deprecated issues.
* [Bug] Few minor bug fix and improvements.

= [3.5.2] - 2023-06-06 =
* [Bug] Few minor bug fix and improvements.

= [3.5.1] - 2023-05-08 =
* [Bug] Few minor bug fix and improvements.

= [3.5.0] - 2023-04-17 =
* [Added] Content Protection for all Embedded contents.
* [Bug] Few minor bug fix and improvements.

= [3.4.2] - 2023-02-06 =
* [Added] Load more pagination for OpenSea.
* [Bug] Few minor bug fix and improvements.

= [3.4.1] - 2023-01-11 =
* [Improved] Coding structure for better performance.
* [Bug] Few minor bug fix and improvements.

= [3.4.0] - 2022-02-14 =
* [Added] Apple Podcast Embed Support.
* [Bug] Few minor bug fix and improvements.

= [3.3.1] - 2022-01-20 =
* [Removed] Spotify Artist follow widget.
* [Bug] Few minor bug fix and improvements.

= [3.3.0] - 2021-11-17 =
* [Added] Google Calendar support for private calendar.
* [Bug] Few minor bug fix and improvements.

= [3.2.0] - 2021-10-06 =
* [Added] Custom branding for PDF.
* [Bug] Few minor bug fix and improvements.

= [3.1.3] - 2021-09-09 =
* [Added] Custom branding for DailyMotion.
* [Bug] Few minor bug fix and improvements.

= [3.1.2] - 2021-08-25 =
* [Added] Custom branding in PDF, DOC, PPT, etc.
* [Added] Live chat feature in youtube embed.
* [Bug] Few minor bug fix and improvements.

= [3.1.1] - 2021-08-05 =
* [Added] YouTube Subscription button for Elementor and Classic and Block Editor
* [Added] Language file for easy translation
* [Bug] Few minor bug fix and improvements.

= [3.1.0] - 2021-07-19 =
* [Bug] Few minor bug fix and improvements.

= [3.0.3] - 2021-06-23 =
* [Added] Boomplay album and playlist Embed
* [Added] Spotify follower widget
* [Bug] Few minor bug fix and improvements.

= [3.0.2] - 2021-06-08 =
* [Added] Branding controls for Vimeo
* [Added] Branding controls for Wistia
* [Added] Branding controls for Twitch
* [Bug] Few minor bug fix and improvements.

= [3.0.1] - 2021-05-27 =
* [Bug] Few minor bug fix and improvements.

= [3.0.0] - 2021-05-19 =

* [Added] Branding preview for Classic and Gutenberg editor
* [Added] Opacity control for custom logo.
* [Bug] Few minor bug fix and improvements.

= [2.4.6] - 2021-04-06 =

* [Added] Twitch live chat option.
* [Added] Youtube custom logo and CTA for Elementor, Gutenberg and Classic editor.
* [Fixed] Custom link attribute on Elementor.
* [Fixed] Wrong text domain on wistia domain.
* [Fixed] Dynamic test domain and translation issue on license page.
* [Bug] Few minor bug fix and improvements.

= [2.4.5] - 2021-03-23 =

* [Fixed] Settings tab broken issue.

= [2.4.4] - 2020-07-22 =

* [Fixed] Added control option  for Dailymotion (elementor)
* [New] New Document Upload Support

= [2.4.3] - 2020-05-10 =

* [Added] Enhanched Alighment Control for all Gutenberg Blocks
* [Added] Docs Link for all Gutenberg Blocks
* [Bug] Minor bug fix

= [2.4.2] - 2020-04-06 =

* [Bug] Fixed - Vimeo video not working in Gutenberg
* Add some control for Vimeo

= [2.4.1] - 2020-03-25 =

* Add SoundCloud control in EmbedPress Elementor widget

= [2.4.0] - 2020-03-15 =

* [Bug] Fixed - Youtube class not found issue
* Add more control in EmbedPress Elementor widget

= [2.3.2] - 2020-03-08 =

* [Bug] Fixed - Plugin does not have a valid header.

= [2.3.1] - 2020-03-04 =

* Add Youtube Gutenberg Block.
* Add Vimeo Gutenberg Block.

= [2.3.0] - 2020-03-02 =

* Initial release.
