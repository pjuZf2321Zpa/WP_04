<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title><?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--[if !mso]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <![endif]-->

    <?php do_action( 'viwec_email_header' ); ?>


    <!--[if (mso 16)]>
    <style type="text/css">
        span {
            vertical-align: middle;
        }
    </style>
    <![endif]-->

    <!--[if mso]>
    <xml>
        <o:OfficeDocumentSettings>
            <o:AllowPNG/>
        </o:OfficeDocumentSettings>
    </xml>
    <![endif]-->


    <!--[if mso | IE]>
    <style type="text/css">
        table {
            font-family: Helvetica, Arial, sans-serif;
        }
    </style>
    <![endif]-->

    <style type="text/css">
        <?php echo ( apply_filters('viwec_after_render_style','') );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>
        /* Fluid base — avoid min-width so Gmail mobile does not force desktop scroll when MQ fails */
        #viwec-responsive-wrap {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            width: 100% !important;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }
        #viwec-responsive-wrap * {
            color: inherit;
            box-sizing: border-box;
        }
        #viwec-responsive-min-width {
            width: 100% !important;
            max-width: <?php echo esc_attr( $width ); ?>px;
            min-width: 0 !important;
            margin: 0 auto;
        }
        #viwec-responsive-wrap #body_content {
            width: 100% !important;
        }
        #viwec-responsive-wrap #outlook a {
            padding: 0;
        }
        #viwec-responsive-wrap a {
            text-decoration: none;
            word-break: break-word;
        }
        td.viwec-row {
            background-repeat: no-repeat;
            background-size: cover;
            background-position: top;
        }
        table.viwec-responsive-padding {
            table-layout: fixed;
            width: 100% !important;
        }
        td.viwec-responsive.viwec-column {
            word-break: break-word;
            overflow-wrap: anywhere;
        }
        table.viwec-keep-table {
            width: 100% !important;
            max-width: 100% !important;
        }
        td.viwec-responsive * {
            max-width: 100%;
        }
        /* Order item name column must remain flexible on all clients (incl. Gmail app) */
        td.viwec-order-item-name {
            word-break: break-word;
            overflow-wrap: anywhere;
        }
        td.viwec-order-item-img img {
            display: block;
            width: 100%;
            max-width: 100%;
            height: auto;
        }
        div.viwec-responsive {
            display: inline-block;
        }
        #viwec-responsive-wrap img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
            -ms-interpolation-mode: bicubic;
            vertical-align: middle;
            background-color: transparent;
            max-width: 100%;
        }
        #viwec-responsive-wrap p {
            display: block;
            margin: 0;
            line-height: inherit;
        }
        #viwec-responsive-wrap small {
            display: block;
            font-size: 13px;
        }
        #viwec-transferred-content small {
            display: inline;
        }
        #viwec-transferred-content td {
            vertical-align: top;
        }

        @media screen and (max-width: <?php echo esc_attr( $responsive ); ?>px) {
        <?php echo ( apply_filters( 'viwec_mobile_render_style', '' ) );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>
            #viwec-responsive-min-width {
                width: 100% !important;
                max-width: 100% !important;
                min-width: 0 !important;
            }

            #viwec-responsive-wrap img {
                height: auto !important;
                max-width: 100% !important;
            }

            /* Stack layout columns only — do not flatten nested order/detail tables */
            td.viwec-responsive.viwec-column {
                display: block !important;
                width: 100% !important;
                max-width: 100% !important;
                min-width: 100% !important;
                box-sizing: border-box !important;
            }

            td.viwec-responsive.suggest-item,
            div.suggest-item {
                display: block !important;
                width: 100% !important;
                max-width: 100% !important;
                min-width: 0 !important;
                box-sizing: border-box !important;
                padding-left: 0 !important;
                padding-right: 0 !important;
            }

            /* Only layout columns / suggest products get forced full width */
            td.viwec-responsive.viwec-column,
            td.viwec-responsive.suggest-item,
            div.suggest-item {
                width: 100% !important;
                max-width: 100% !important;
            }

            /* Gmail app often skips MQ — keep button auto-sized like desktop; never clip label */
            .viwec-button-wrap {
                width: 100% !important;
            }

            .viwec-button-responsive {
                width: auto !important;
                max-width: 100% !important;
                min-width: 0 !important;
            }

            .viwec-mobile-button-padding {
                max-width: 100% !important;
            }

            /* Order detail styles 2/3: stack image / name / price, always centered */
            .order-detail .viwec-order-item-img,
            .order-detail .viwec-order-item-name,
            .order-detail .viwec-order-item-price,
            .order-detail td.viwec-order-item-img,
            .order-detail td.viwec-order-item-name,
            .order-detail td.viwec-order-item-price {
                display: block !important;
                width: 100% !important;
                max-width: 100% !important;
                min-width: 0 !important;
                box-sizing: border-box !important;
                text-align: center !important;
            }

            .order-detail .viwec-order-item-img img,
            .order-detail td.viwec-order-item-img img {
                width: 100% !important;
                max-width: 100% !important;
                height: auto !important;
                margin: 0 auto !important;
            }

            .order-detail .viwec-order-item-name,
            .order-detail .viwec-order-item-price,
            .order-detail .viwec-responsive-center,
            .order-detail .viwec-responsive-center p,
            .order-detail td.viwec-order-item-name,
            .order-detail td.viwec-order-item-price {
                text-align: center !important;
            }

            .viwec-no-full-width-on-mobile,
            table.viwec-no-full-width-on-mobile {
                min-width: 0 !important;
                width: auto !important;
                max-width: 100% !important;
            }

            /* Keep real tables as tables (order items, subtotals, social, hooks) */
            td.viwec-responsive.viwec-column > table {
                width: 100% !important;
                max-width: 100% !important;
            }

            td.viwec-responsive.viwec-column table.viwec-keep-table,
            td.viwec-responsive.viwec-column table.viwec-no-full-width-on-mobile,
            td.viwec-responsive.viwec-column table.html_wc_hook .html_wc_hook_default table,
            td.viwec-responsive.viwec-column table.html_wc_hook .html_wc_hook_default * table {
                display: table !important;
                width: 100% !important;
            }

            td.viwec-responsive.viwec-column table.viwec-keep-table tbody,
            td.viwec-responsive.viwec-column table.viwec-no-full-width-on-mobile tbody,
            td.viwec-responsive.viwec-column table.html_wc_hook .html_wc_hook_default tbody {
                display: table-row-group !important;
            }

            td.viwec-responsive.viwec-column table.viwec-keep-table tr,
            td.viwec-responsive.viwec-column table.viwec-no-full-width-on-mobile tr,
            td.viwec-responsive.viwec-column table.html_wc_hook .html_wc_hook_default tr {
                display: table-row !important;
            }

            td.viwec-responsive.viwec-column table.viwec-keep-table td,
            td.viwec-responsive.viwec-column table.viwec-no-full-width-on-mobile td,
            td.viwec-responsive.viwec-column table.html_wc_hook .html_wc_hook_default td {
                display: table-cell !important;
            }

            .viwec-responsive-padding {
                padding: 0 !important;
            }

            .viwec-mobile-hidden {
                display: none !important;
            }

            .viwec-responsive-center,
            .viwec-responsive-center td,
            .viwec-responsive-center p,
            .viwec-center-on-mobile,
            .viwec-center-on-mobile p {
                text-align: center !important;
            }

            /* Label / value pairs stay side-by-side on mobile */
            td.viwec-mobile-50,
            .viwec-mobile-50 {
                width: 50% !important;
                min-width: 50% !important;
                max-width: 50% !important;
                display: table-cell !important;
            }

            .viwec-mobile-50 .woocommerce-Price-amount {
                margin-right: 1px;
            }

            .html_menu td {
                display: block !important;
                width: 100% !important;
            }

            .viwec-fixed-width-mobile {
                width: 100% !important;
                max-width: 100% !important;
            }
        }
    </style>
</head>

<body dir="<?php echo esc_attr( $direction ); ?>" vlink="#FFFFFF" <?php echo $direction == 'rtl' ? 'rightmargin' : 'leftmargin'; ?>="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
