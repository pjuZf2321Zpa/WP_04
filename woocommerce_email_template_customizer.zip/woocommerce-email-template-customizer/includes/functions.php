<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! function_exists( 'villtheme_include_folder' ) ) {
	function villtheme_include_folder( $path, $prefix = '', $ext = array( 'php' ) ) {

		/*Include all files in payment folder*/
		if ( ! is_array( $ext ) ) {
			$ext = explode( ',', $ext );
			$ext = array_map( 'trim', $ext );
		}
		$sfiles = scandir( $path );
		foreach ( $sfiles as $sfile ) {
			if ( $sfile != '.' && $sfile != '..' ) {
				if ( is_file( $path . "/" . $sfile ) ) {
					$ext_file  = pathinfo( $path . "/" . $sfile );
					$file_name = $ext_file['filename'];
					if ( $ext_file['extension'] ) {
						if ( in_array( $ext_file['extension'], $ext ) ) {
							$class = preg_replace( '/\W/i', '_', $prefix . ucfirst( $file_name ) );

							if ( ! class_exists( $class ) ) {
								require_once $path . $sfile;
								if ( class_exists( $class ) ) {
									new $class;
								}
							}
						}
					}
				}
			}
		}
	}
}
/**
 * Plugin settings stored in option `viwec_settings`.
 *
 * @return array{mail_log?: int|string}
 */
function viwec_get_plugin_settings() {
	static $settings = null;

	if ( null !== $settings ) {
		return $settings;
	}

	$settings = get_option(
		'viwec_settings',
		array(
			'mail_log' => 0,
		)
	);

	$settings = apply_filters( 'viwec_plugin_settings', $settings );

	return $settings;
}

/**
 * Whether WooCommerce email debug logging is enabled.
 *
 * Off by default to avoid writing order/template metadata to WC logs.
 * Filter `viwec_enable_mail_log` can force enable/disable.
 *
 * @return bool
 */
function viwec_is_mail_log_enabled() {
	$settings = viwec_get_plugin_settings();
	$enabled  = ! empty( $settings['mail_log'] );

	return (bool) apply_filters( 'viwec_enable_mail_log', $enabled );
}

/**
 * Query email templates with request + transient cache.
 *
 * @param array $args get_posts() args.
 *
 * @return \WP_Post[]
 */
function viwec_query_templates( $args ) {
	static $request_cache = array();

	$args = wp_parse_args(
		$args,
		array(
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
		)
	);
	$args = apply_filters( 'viwec_query_templates_args', $args );

	$cache_key = md5( wp_json_encode( $args ) );
	if ( isset( $request_cache[ $cache_key ] ) ) {
		return $request_cache[ $cache_key ];
	}

	$use_cache = (bool) apply_filters( 'viwec_query_templates_use_cache', true, $args );
	$version   = (int) get_option( 'viwec_template_cache_ver', 1 );
	if ( $use_cache ) {
		$transient_key = 'viwec_tpls_' . $version . '_' . $cache_key;
		$cached        = get_transient( $transient_key );
		if ( false !== $cached && is_array( $cached ) ) {
			$request_cache[ $cache_key ] = $cached;

			return $cached;
		}
	}

	$posts = get_posts( $args );
	$posts = apply_filters( 'viwec_query_templates_posts', $posts, $args );
	if ( $use_cache ) {
		$ttl = (int) apply_filters( 'viwec_query_templates_cache_ttl', HOUR_IN_SECONDS, $args );
		set_transient( 'viwec_tpls_' . $version . '_' . $cache_key, $posts, max( 1, $ttl ) );
	}
	$request_cache[ $cache_key ] = $posts;

	return $posts;
}

/**
 * Invalidate cached template queries after templates change.
 */
function viwec_flush_template_cache() {
	$version = (int) get_option( 'viwec_template_cache_ver', 1 ) + 1;
	update_option( 'viwec_template_cache_ver', $version, false );
	do_action( 'viwec_flushed_template_cache', $version );
}

function viwec_get_emails_list( $type = '' ) {
	$args = array(
		'numberposts' => - 1,
		'post_type'   => 'viwec_template',
		'meta_key'    => 'viwec_settings_type',// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		'meta_value'  => $type,// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
	);
	$args = apply_filters( 'viwec_get_emails_list_args', $args, $type );

	return viwec_query_templates( $args );
}

function viwec_render_email_template( $id ) {
	do_action( 'viwec_before_render_email_template', $id );
	$email_template = VIWEC\INCLUDES\Email_Render::init( [ 'template_id' => $id ] );
	$data           = get_post_meta( $id, 'viwec_email_structure', true );
	$data           = json_decode( VIWEC\INCLUDES\Init::html_entity_decode( $data ), true );
	$data           = apply_filters( 'viwec_render_email_template_data', $data, $id );
	$email_template->render( $data );
	do_action( 'viwec_after_render_email_template', $id );
}

function viwec_parse_styles( $data ) {
	if ( empty( $data ) ) {
		return '';
	}

	$style = '';
	if ( is_array( $data ) ) {
		foreach ( $data as $key => $value ) {
			if ( $key === 'border-style' && isset( $data['border-width'] ) && $data['border-width'] == '0px' ) {
				continue;
			}
			$style .= "{$key}:{$value};";
		}

		$border_width = isset( $data['border-width'] ) && $data['border-width'] !== '0px' ? true : false;
		$border_style = isset( $data['border-style'] ) ? true : false;

		$style .= $border_width && ! $border_style ? 'border-style:solid;' : '';
	} else {
		$style = $data;
	}

	return $style;
}

function viwec_allowed_html() {
	$allow_html = wp_kses_allowed_html( 'post' );
	foreach ( $allow_html as $key => $value ) {
		if ( in_array( $key, [ 'div', 'span', 'a', 'input', 'form' ] ) ) {
			$allow_html[ $key ]['data-*'] = 1;
		}
	}

	$allow_html['div']['style'] = [ 'display' => 1 ];

	unset( $allow_html['ins'] );

	return apply_filters( 'viwec_allowed_html', array_merge( $allow_html, [
			'input'  => [
				'type'         => 1,
				'id'           => 1,
				'name'         => 1,
				'class'        => 1,
				'placeholder'  => 1,
				'autocomplete' => 1,
				'style'        => 1,
				'value'        => 1,
				'data-*'       => 1,
			],
			'option' => [ 'value' => 1 ],
			'style'  => [
				'type'  => 1,
				'id'    => 1,
				'name'  => 1,
				'class' => 1,
			],
			'meta'   => [ 'http-equiv' => 1, 'content' => 1, 'name' => 1 ]
		]
	) );
}

function viwec_safe_kses_styles( $styles ) {
	$styles[] = 'display';

	return $styles;
}

/**
 * Sanitize attachment IDs before attaching files to outgoing email.
 *
 * Each ID must reference an attachment post, use an allowed MIME type,
 * resolve to a readable file on disk, and (optionally) be readable by the
 * current user.
 *
 * @param mixed $attachment_ids Attachment ID list from POST/meta.
 * @param bool  $check_user_cap Verify current_user_can( 'read_post', $id ).
 *
 * @return int[] Valid attachment post IDs.
 */
function viwec_sanitize_email_attachment_ids( $attachment_ids, $check_user_cap = true ) {
	if ( empty( $attachment_ids ) || ! is_array( $attachment_ids ) ) {
		return array();
	}

	$allowed_mimes = apply_filters( 'viwec_allowed_attachment_mimes', array_values( get_allowed_mime_types() ) );
	$valid_ids     = array();

	foreach ( $attachment_ids as $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			continue;
		}

		if ( $check_user_cap && ! current_user_can( 'read_post', $attachment_id ) ) {
			continue;
		}

		$mime_type = get_post_mime_type( $attachment_id );
		if ( ! $mime_type || ! in_array( $mime_type, $allowed_mimes, true ) ) {
			continue;
		}

		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path || ! is_readable( $file_path ) ) {
			continue;
		}

		$valid_ids[] = $attachment_id;
	}

	return array_values( array_unique( $valid_ids ) );
}

function viwec_get_pro_version() {
	?>
    <a target="_blank" href="https://villatheme.com/extensions/woocommerce-email-template-customizer/" class="viwec-get-pro-version">
		<?php esc_html_e( 'Unlock this feature', 'viwec-email-template-customizer' ); ?>
    </a>
	<?php
}

if ( ! function_exists( 'viwec_fix_get_formatted_meta_data' ) ) {
	function viwec_fix_get_formatted_meta_data( $formatted_meta, \WC_Order_Item $object ) {
		remove_filter( 'woocommerce_order_item_get_formatted_meta_data', 'viwec_fix_get_formatted_meta_data' );

		return $object->get_formatted_meta_data();
	}
}
if ( ! function_exists( 'villatheme_remove_object_filter' ) ) {
    /**
     * Remove an object filter.
     *
     * @param string $tag Hook name.
     * @param string $class Class name. Use 'Closure' for anonymous functions.
     * @param string|void $method Method name. Leave empty for anonymous functions.
     * @param string|int|void $priority Priority
     *
     * @return void
     */
    function villatheme_remove_object_filter( $tag, $class, $method = null, $priority = null ) {
        global $wp_filter;
        $filters = $wp_filter[ $tag ] ?? '';
        if ( empty ( $filters ) ) {
            return;
        }
        foreach ( $filters as $p => $filter ) {

            if ( ! is_null( $priority ) && ( (int) $priority !== (int) $p ) ) {
                continue;
            }
            $remove = false;
            foreach ( $filter as $identifier => $function ) {
                $function = $function['function'];
                if (
                        is_array( $function )
                        && (
                                is_a( $function[0], $class )
                                || ( is_array( $function ) && $function[0] === $class )
                        )
                ) {
                    $remove = ( $method && ( $method === $function[1] ) );
                } elseif ( $function instanceof Closure && $class === 'Closure' ) {
                    $remove = true;
                }
                if ( $remove ) {
                    $temp = $wp_filter[ $tag ][ $p ];
                    unset( $temp[ $identifier ] );
                    $wp_filter[ $tag ][ $p ] = $temp;
                }
            }
        }
    }
}