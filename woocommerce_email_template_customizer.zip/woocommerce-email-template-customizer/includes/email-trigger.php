<?php

namespace VIWEC\INCLUDES;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Email_Trigger {

	protected static $instance = null;
	protected $object;
	protected $user;
	protected $use_default_temp = false;
	protected $class_email;
	protected $heading;
	protected $unique = [], $template_data = [];
	protected $clear_css;
	protected $disable_email_template;
	public static $cache=[], $plain_search = array(
		"/\r/",                                                  // Non-legal carriage return.
		'/&(nbsp|#0*160);/i',                                    // Non-breaking space.
		'/&(quot|rdquo|ldquo|#0*8220|#0*8221|#0*147|#0*148);/i', // Double quotes.
		'/&(apos|rsquo|lsquo|#0*8216|#0*8217);/i',               // Single quotes.
		'/&gt;/i',                                               // Greater-than.
		'/&lt;/i',                                               // Less-than.
		'/&#0*38;/i',                                            // Ampersand.
		'/&amp;/i',                                              // Ampersand.
		'/&(copy|#0*169);/i',                                    // Copyright.
		'/&(trade|#0*8482|#0*153);/i',                           // Trademark.
		'/&(reg|#0*174);/i',                                     // Registered.
		'/&(mdash|#0*151|#0*8212);/i',                           // mdash.
		'/&(ndash|minus|#0*8211|#0*8722);/i',                    // ndash.
		'/&(bull|#0*149|#0*8226);/i',                            // Bullet.
		'/&(pound|#0*163);/i',                                   // Pound sign.
		'/&(euro|#0*8364);/i',                                   // Euro sign.
		'/&(dollar|#0*36);/i',                                   // Dollar sign.
		'/&[^&\s;]+;/i',                                         // Unknown/unhandled entities.
		'/[ ]{2,}/',                                             // Runs of spaces, post-handling.
	);

	public static $plain_replace = array( '', ' ', '"', "'", '>', '<', '&', '&', '(c)', '(tm)', '(R)', '--', '-', '*', '£', 'EUR', '$', '', ' ', );
	protected $fix_default_thumbnail;

	private function __construct() {
		add_filter( 'wc_get_template', array( $this, 'replace_template_path' ), 10, 5 );
		add_action( 'viwec_email_template', array( $this, 'load_template' ), 10 );
		add_action( 'woocommerce_email', array( $this, 'get_email_template_id' ), 1 );
		add_filter( 'wp_new_user_notification_email', array( $this, 'replace_wp_new_user_email' ), 1, 3 );
		if ( !class_exists( 'EmTmpl\EMTMPL_Email_Templates_Designer' ) && !class_exists( 'EmTmplF\WP_Email_Templates_Designer' ) ) {
			add_filter( 'password_change_email', array( $this, 'replace_default_to_wp_email' ), 1, 1);
			add_filter( 'email_change_email', array( $this, 'replace_default_to_wp_email' ), 1, 1);
		}
		add_filter( 'wp_mail', [ $this, 'add_attachment_file_wp_mail' ], 100 );
		add_filter( 'retrieve_password_title', array( $this, 'replace_wp_reset_password_title' ), 1, 3 );

		$priority_retrieve_password_message = 1;
		/*Compatible with paid-memberships-pro */
		if ( function_exists( 'pmpro_gateways' ) ) {
			$priority_retrieve_password_message = 11;
		}
		add_filter( 'retrieve_password_message', array( $this, 'replace_wp_reset_password_email' ), $priority_retrieve_password_message, 4 );

		add_filter( 'woocommerce_email_styles', array( $this, 'remove_style' ), 99 );
		add_filter( 'woocommerce_email_styles', array( $this, 'custom_css' ), 99999, 2 );

		add_filter( 'woocommerce_mail_callback_params', array( $this, 'use_default_template_email' ), 999, 2 );
		add_filter( 'woocommerce_mail_callback_params', array( $this, 'add_attachment_file' ), 99999 );
		add_filter( 'woocommerce_mail_callback_params', array( $this, 'reset_template_id' ), 999999 );

//		Email with wc_mail
		add_action( 'woocommerce_email_header', array( $this, 'send_email_via_wc_mailer' ), 0, 2 );
		add_filter( 'woocommerce_email_get_option', [ $this, 'add_padding_for_addition_content' ], 10, 4 );

//		Minify email content
		add_filter( 'woocommerce_mail_callback_params', [ $this, 'minify_email_content' ], 99999 );

		add_shortcode( 'wec_order_meta_subject', [ $this, 'subject_shortcode' ] );
	}

	public static function init() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function remove_header_footer_hook( $bool ) {
		$remove = apply_filters( 'viwec_remove_origin_email_header_footer', $bool );
		if ( $remove ) {
			remove_all_actions( 'woocommerce_email_header' );
			remove_all_actions( 'woocommerce_email_footer' );
		}
	}

	public function get_email_template_id( $email_object ) {
		if ( is_array( $email_object->emails ) ) {
			foreach ( $email_object->emails as $email ) {
				add_filter( 'woocommerce_email_recipient_' . $email->id, array( $this, 'trigger_recipient' ), 10, 3 );
				add_filter( 'woocommerce_email_subject_' . $email->id, array( $this, 'replace_subject' ), PHP_INT_MAX, 2 );
			}
		}
		add_filter( 'woocommerce_email_recipient_customer_partially_refunded_order', array( $this, 'trigger_recipient' ), 10, 3 );
		add_filter( 'woocommerce_email_recipient_customer_invoice_pending', array( $this, 'trigger_recipient' ), 10, 3 );
		add_filter( 'woocommerce_email_subject_customer_invoice_paid', array( $this, 'replace_subject' ), PHP_INT_MAX, 3 );
	}

	public function get_template_id( $type, $order = '' ) {
		if ( ! isset( $this->template_data['disable'][ $type ] ) ) {
			if ( ! isset( $this->template_data['disable'] ) ) {
				$this->template_data['disable'] = [];
			}
			$status_options                               = get_option( 'viwec_emails_status', [] );
			$this->template_data['disable'][ $type ] = ! empty( $status_options[ $type ] ) && $status_options[ $type ] === 'disable';
		}
		if ( ! empty( $this->template_data['disable'][ $type ] ) ) {
			return 'disabled';
		}
		if ( ! isset( $this->template_data['template_id'] ) ) {
			$this->template_data['template_id'] = array();
		}
		if ( $order && is_a( $order, 'WC_Order' ) ) {
			$order_id = $order->get_id();
			if ( ! isset( $this->template_data['template_id'][ $type . '-' . $order_id ] ) ) {
				$this->template_data['template_id'][ $type . '-' . $order_id ] = $this->get_template_id_has_order( $type, $order );
			}
			$result = $this->template_data['template_id'][ $type . '-' . $order_id ];
		} else {
			if ( ! isset( $this->template_data['template_id'][ $type ] ) ) {
				$this->template_data['template_id'][ $type ] = $this->get_template_id_no_order( $type, $order );
			}
			$result = $this->template_data['template_id'][ $type ];
		}
		if ( $result && $result !== 'disabled' ) {
			$this->template_data['used_template_id'] = $result;
		}

		return apply_filters( 'viwec_get_template_id', $result, $type, $order, $this );
	}

	public function trigger_recipient( $recipient, $object, $class_email ) {
		if ( empty( $class_email->id ) ) {
			return $recipient;
		}

		if ( ! $object ) {
			$viwec_accept_email_type = apply_filters( 'viwec_accept_email_type', [] );
			if ( ! is_array( $viwec_accept_email_type ) || ! in_array( $class_email->id, $viwec_accept_email_type ) ) {
				return $recipient;
			}
		}

		$this->reset_template_id( [] );
		$template_id = $this->get_template_id( $class_email->id, $object );
		if ( $template_id === 'disabled' ) {
			$this->disable_email_template = true;

			return $recipient;
		}

		if ( ! $template_id ) {
			$this->use_default_temp = $this->get_default_template();
			$this->remove_header_footer_hook( $this->use_default_temp );
			add_filter( 'woocommerce_email_order_items_args', [ $this, 'show_image' ], PHP_INT_MAX, 1 );
		}

		$this->clear_css   = ( $template_id || $this->use_default_temp ) ? true : false;
		$this->object      = $object;
		$this->class_email = $class_email;

		return apply_filters( 'viwec_email_recipient', $recipient, $object, $class_email, $template_id, $this );
	}

	public function show_image( $args ) {
		if ( $this->use_default_temp ) {
			$show_image         = get_post_meta( $this->use_default_temp, 'viwec_enable_img_for_default_template', true )?:1;
			$args['show_image'] = $show_image && $show_image !== 'false'? true: false ;
			$size               = get_post_meta( $this->use_default_temp, 'viwec_img_size_for_default_template', true );
			$args['image_size'] = $size ? [ (int) $size, 300 ] : [ 80, 80 ];
		}

		return $args;
	}

	public function subject_shortcode( $args ) {
		$args                = wp_parse_args( $args, [ 'key' => '', 'meta_customer_order' => '', 'array_key' => '' ] );
		$meta_key            = $args['key'];
		$meta_customer_order = $args['meta_customer_order'];
		$array_key           = $args['array_key'];
		$meta_value          = '';
		if ( $this->object && $meta_key ) {
			if ( $meta_customer_order === 'yes' ) {
				$user = $this->object->get_user();
				if ( $user ) {
					$meta_value = get_user_meta( $user->ID, $meta_key, true );
				}
			} else {
				$meta_value = (array) $this->object->get_meta( $meta_key, true );
			}
		} elseif ( $this->user && $meta_key ) {
			$user = $this->user instanceof \WC_Email ? $this->user->object : $this->user;
			if ( $user && isset( $user->ID ) ) {
				$meta_value = get_user_meta( $user->ID, $meta_key, true );
			}
		}

		if ( is_array( $meta_value ) ) {
			switch ( $meta_key ) {
				case '_wc_shipment_tracking_items':
					$get_shipment_tracking = (array) $meta_value[0];

					if ( isset( $get_shipment_tracking[ $array_key ] ) ) {
						$meta_value = (array) $get_shipment_tracking[ $array_key ];
					} else {
						$meta_value = wp_json_encode( (array) $get_shipment_tracking );
					}
					break;
				default:
					if ( isset( $meta_value[ $array_key ] ) ) {
						$meta_value = (array) $meta_value[ $array_key ];
					} elseif ( count( $meta_value ) === 1 && is_string( $meta_value[0] ) ) {
						$meta_value = $meta_value[0];
					} else {
						$meta_value = wp_json_encode( $meta_value );
					}
					break;
			}
		}
		$meta_value = apply_filters( 'viwec_render_shortcode_order_meta', $meta_value, $meta_key );

		return wp_kses_post( $meta_value );
	}

	public function replace_subject( $subject, $object ) {
		$current_id  = str_replace( 'woocommerce_email_subject_', '', current_filter() );
		$template_id = $this->get_template_id( $current_id === 'customer_invoice_paid' ? 'customer_invoice' : $current_id, $object );
		if ( $template_id && $template_id !== 'disabled' ) {
			$template = get_post( $template_id );
			if ( ! $template ) {
				return $subject;
			}
			$_subject = $template->post_title;
			$subject  = $_subject ?: $subject;
			// Account emails pass WP_User as $object; prefer WC_Email for set_password_url / reset_key.
			$sc_object = $object;
			if ( is_a( $object, 'WP_User' ) && $this->class_email && is_a( $this->class_email->object ?? null, 'WP_User' )
				&& (int) $this->class_email->object->ID === (int) $object->ID ) {
				$sc_object = $this->class_email;
			}
			$subject = self::replace_subject_shortcode( $subject, $sc_object );
		}

		return apply_filters( 'viwec_replace_email_subject', $subject, $object, $template_id, $current_id );
	}
    public static function replace_subject_shortcode( $subject, $object){
        if (!$subject || !$object){
            return $subject;
        }
	    $subject    = Utils::replace_shortcode( $subject, [], $object );
	    $wc_symbols = get_woocommerce_currency_symbols();
	    $wc_symbol  = '';
	    if ( is_array( $wc_symbols ) && ! empty( $wc_symbols ) ) {
		    $wc_symbols_match = [];
		    foreach ( $wc_symbols as $v ) {
			    if ( strpos( $v, '&#' ) === 0 ) {
				    $wc_symbols_match[] = str_replace( [ '&#', '.', '/' ], [ '&#0*', '\.', '\/' ], $v );
			    }
		    }
		    $wc_symbols_match = '/(' . implode( '|', $wc_symbols_match ) . ')/i';
		    preg_match( $wc_symbols_match, $subject, $wc_symbols_match1 );
		    if ( ! empty( $wc_symbols_match1[1] ) ) {
			    $wc_symbol = $wc_symbols_match1[1];
		    }
	    }
	    if ( $wc_symbol ) {
		    $subject = str_replace( $wc_symbol, '{viwec_wc_symbol_tmp}', $subject );
	    }
	    $subject = preg_replace( self::$plain_search, self::$plain_replace, wp_strip_all_tags( $subject ) );
	    $subject = htmlspecialchars_decode( do_shortcode( $subject ), ENT_QUOTES );
	    if ( $wc_symbol ) {
		    $subject = str_replace( '{viwec_wc_symbol_tmp}', $wc_symbol, $subject );
	    }

	    return apply_filters( 'viwec_replace_subject_shortcode', $subject, $object );
    }

	public function replace_template_path( $located, $template_name, $args, $template_path, $default_path ) {
		if ( empty( $this->template_data ) ) {
			return $located;
		}

		if ( $template_name == 'emails/email-addresses.php' ) {
			return VIWEC_TEMPLATES . 'empty-file.php';
		}

		if ( $template_name == 'emails/email-styles.php' ) {
			return VIWEC_TEMPLATES . 'email-style.php';
		}
		if ( ! empty( $args['email']->id ) && in_array( $args['email']->id, $this->unique ) ) {
			return $located;
		}

		if ( ! isset( $args['email'] ) && isset( $args['order'] ) && isset( $args['email_heading'] ) ) {
			$WC_mailer = WC()->mailer();
			if ( isset( $WC_mailer->emails ) ) {
				foreach ( $WC_mailer->emails as $mailer ) {
					if ( ! empty( $mailer->object ) && $args['email_heading'] == $mailer->heading ) {
						$args['email'] = $mailer;
						break;
					} else if ( isset( $mailer->settings ) && ! empty( $mailer->settings ) ) {
						$settings = $mailer->settings;
						if ( isset( $settings['heading'] ) && $args['email_heading'] == $settings['heading'] ) {
							$args['email'] = $mailer;
							break;
						}
					}
				}
			}
		}
		if ( isset( $args['email'] ) && ! empty( $args['email']->id ) ) {
			$this->unique[] = $args['email']->id;
			if ( ! empty( $args['plain_text'] ) ) {
				return $located;
			}
			$template_id = $this->get_template_id( $args['email']->id, $args['order'] ?? '' );
			if ( $template_id && $template_id !== 'disabled' ) {
				$located = VIWEC_TEMPLATES . 'email-template.php';
			}
		}

		return apply_filters( 'viwec_replace_template_path', $located, $template_name, $args, $template_path, $default_path, $this );
	}

	public function load_template( $args ) {
		if ( empty( $args['email'] ) ) {
			return;
		}
		$template_id = $this->get_template_id( $args['email']->id ?? '', $args['order'] ?? '' );
		if ( ! $template_id || $template_id === 'disabled' ) {
			$template_id = $this->get_default_template();
		}
		if ( ! $template_id ) {
			return;
		}

		do_action( 'viwec_before_load_template', $template_id, $args, $this );

		$email_render = Email_Render::init( [ 'template_id' => $template_id ] );
		$email_render->set_object( $args['email'] );
		$this->user                  = $args['email'];
		$email_render->template_args = $args;

		$data = get_post_meta( $template_id, 'viwec_email_structure', true );
		$data = json_decode( Init::html_entity_decode( $data ), true );
		$data = apply_filters( 'viwec_template_structure', $data, $template_id, $args, $this );

		$email_render->render( $data );

		do_action( 'viwec_after_load_template', $template_id, $args, $this );
	}

	public function get_template_id_has_order( $type, \WC_Order $order ) {
		$country_code = $order->get_billing_country();
		$lang_code    = apply_filters( 'viwec_woocommerce_order_language', '', $order );

		$line_items     = $order->get_items( 'line_item' );
		$order_price    = $order->get_total();
		$order_currency = $order->get_currency();
		$order_payment  = $order->get_payment_method();

		$bought_ids = Utils::get_bought_ids( $line_items );
		$categories = Utils::get_categories_from_bought_id( $bought_ids );
		if ( $type == 'customer_invoice' &&(
				$order->get_status() == 'pending' ||
				$order->get_status() == 'failed'
			) ) {
			$type = 'customer_invoice_pending';
		}
        $mail_log = viwec_is_mail_log_enabled();
		$args = [
			'posts_per_page' => - 1,
			'post_type'      => 'viwec_template',
			'orderby'        => 'menu_order',
			'post_status'    => 'publish',
			'meta_key'       => 'viwec_settings_type',// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => $type,// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		];
		$args = apply_filters( 'viwec_get_template_query_args', $args, $type, $order );

		$posts = viwec_query_templates( $args );

		$filter_ids = $filter_lang_ids =[];
        if ($mail_log) {
	        ob_start();
	        var_dump( 'get_template_id_for_order : ' . $order->get_id() );
	        var_dump( 'email type :' );
	        var_dump( $type );
	        var_dump( 'language : ' . $lang_code );
	        $log_content = ob_get_clean();
        }
		foreach ( $posts as $post ) {
			$can_filter_lang = false;
			$rules           = get_post_meta( $post->ID, 'viwec_setting_rules', true );
			$rule_countries  = $rules['countries'] ?? [];
			$countries_exc  = $rules['countries_exc'] ?? [];
			$rule_categories = $rules['categories'] ?? [];
			$categories_exc = $rules['categories_exc'] ?? [];
			$rule_products   = $rules['products'] ?? [];
			$products_exc   = $rules['products_exc'] ?? [];
			$rule_languages  = $rules['languages'] ?? [];
			$rule_price_type = $rules['price_type'] ?? 'total';
			$rule_payment    = $rules['payment'] ?? [];

			if ( $rule_price_type == 'subtotal' ) {
				$order_price = $order->get_subtotal();
			}
			$min_price = $rules['min_price'] ?? '';
			$max_price = $rules['max_price'] ?? '';
			/*Compatible CURCY*/
			if ( class_exists( '\WOOMULTI_CURRENCY_Data' ) ) {
				$setting_curcy             = \WOOMULTI_CURRENCY_Data::get_ins();
				$get_list_currency         = $setting_curcy->get_list_currencies();
				$curcy_order_currency_data = $get_list_currency[ $order_currency ] ?? [];
				if ( isset( $curcy_order_currency_data['hide'] ) && ! $curcy_order_currency_data['hide'] ) {
					$order_price = round( floatval( $order_price ) / $curcy_order_currency_data['rate'], 2 );
				}
			} else if ( class_exists( '\WOOMULTI_CURRENCY_F_Data' ) ) {
				$setting_curcy             = \WOOMULTI_CURRENCY_F_Data::get_ins();
				$get_list_currency         = $setting_curcy->get_list_currencies();
				$curcy_order_currency_data = $get_list_currency[ $order_currency ] ?? [];
				if ( isset( $curcy_order_currency_data['hide'] ) && ! $curcy_order_currency_data['hide'] ) {
					$order_price = round( floatval( $order_price ) / $curcy_order_currency_data['rate'], 2 );
				}
			}
			$rule_categories_by_language = [];
            if ($lang_code){
                if ($mail_log) {
	                ob_start();
	                var_dump( '$rule_languages' );
	                var_dump( $rule_languages );
	                $log_content .= ob_get_clean();
                }
                if (!empty($rule_languages) && is_array($rule_languages)){
	                if (!in_array($lang_code, $rule_languages)){
		                continue;
                    }
	                $can_filter_lang = true;
                }
	            if ( ! empty( $rule_categories ) ) {
		            foreach ( $rule_categories as $item_id ) {
			            $termID = apply_filters( 'wpml_object_id', $item_id, 'product_cat', true, $lang_code );
			            if ( $termID ) {
				            $rule_categories_by_language[] = $termID;
			            }
		            }
                    if ( ! empty( $rule_categories_by_language ) ) {
                        $rule_categories = $rule_categories_by_language;
                    }
	            }
	            if ( ! empty( $categories_exc ) ) {
                    $rule_categories_by_language= [];
		            foreach ( $categories_exc as $item_id ) {
			            $termID = apply_filters( 'wpml_object_id', $item_id, 'product_cat', true, $lang_code );
			            if ( $termID ) {
				            $rule_categories_by_language[] = $termID;
			            }
		            }
                    if ( ! empty( $rule_categories_by_language ) ) {
                        $categories_exc = $rule_categories_by_language;
                    }
	            }
	            if ( ! empty( $products_exc ) ) {
                    $products_exc_by_language= [];
		            foreach ( $products_exc as $products_exc_id ) {
			            $termID = apply_filters( 'wpml_object_id', $products_exc_id, 'product', true, $lang_code );
			            if ( $termID ) {
                            $products_exc_by_language[] = $termID;
			            }
		            }
                    if ( ! empty( $products_exc_by_language ) ) {
                        $products_exc = $products_exc_by_language;
                    }
	            }
            }
            if ( ! empty( $countries_exc ) && is_array( $countries_exc ) ) {
                if ( in_array( $country_code, $countries_exc ) ) {
                    continue;
                }
            }
            if ( ! empty( $categories_exc ) && is_array( $categories_exc ) && !empty(array_intersect( $categories,  $categories_exc ) ) ) {
                continue;
            }

            if ( ! empty( $products_exc ) && is_array( $products_exc ) && !empty(array_intersect( $bought_ids,  $products_exc ) ) ) {
                continue;
            }

			if ( ! empty( $rule_countries ) && is_array( $rule_countries ) ) {
				if ( ! in_array( $country_code, $rule_countries ) ) {
					continue;
				}
			}
			/*Rule for product and product categories*/
			if ( ! empty( $rule_categories ) && ! empty( $rule_products ) ) {
				if (
					empty( array_intersect( $categories, (array) $rule_categories ) ) ||
					empty( array_intersect( $bought_ids, (array) $rule_products ) )
				) {
					continue;
				}
			} else if ( ! empty( $rule_categories ) || ! empty( $rule_products ) ) {
				if ( ! empty( $rule_categories ) ) {
					if ( ! empty( $rule_categories ) && count( array_intersect( $categories, (array) $rule_categories ) ) <= 0 ) {
						continue;
					}
				}
				if ( ! empty( $rule_products ) ) {
					if ( ! empty( $rule_products ) && count( array_intersect( $bought_ids, (array) $rule_products ) ) <= 0 ) {
						continue;
					}
				}
			}
			/*Rule for payment method*/
			if ( ! empty( $rule_payment ) && is_array( $rule_payment ) ) {
				if ( ! in_array( $order_payment, $rule_payment ) ) {
					continue;
				}
			}

			/*Rule compatible with 3rd*/
			$rule_3rd = true;
			$rule_3rd = apply_filters( 'viwec_add_rule_template_3rd', $rule_3rd, $rules, $order );
			if ( ! $rule_3rd ) {
				continue;
			}
            $can_filter = false;
			/*Rule for price*/
			if ( ! empty( $max_price ) || ! empty( $min_price ) ) {
				if ( empty( $max_price ) && ( $max_price === '' ) ) {
					if ( $order_price >= (float) $min_price ) {
						$can_filter = true;
					}
				} else {
					if ( ( $order_price >= (float) $min_price ) && ( $order_price <= (float) $max_price ) ) {
						$can_filter = true;
					}
				}
			} else {
				$can_filter = true;
			}
            if ($can_filter){
                if ($can_filter_lang){
                    $filter_lang_ids[] = $post->ID;
                }
	            $filter_ids[] = $post->ID;
            }
		}
        if ($mail_log) {
	        ob_start();
	        var_dump('$filter_lang_ids : ');
	        var_dump($filter_lang_ids);
	        var_dump('$filter_ids : ');
	        var_dump($filter_ids);
	        $log_content .=  ob_get_clean();
	        $log = wc_get_logger();
	        $log->log( 'DEBUG',
		        $log_content,
		        array(
			        'source' => 'VIWEC',
		        )
	        );
        }
		if (!empty($filter_lang_ids)){
			$filter_ids = $filter_lang_ids;
		}


		return apply_filters( 'viwec_find_email_template_id_with_rule_order', current( $filter_ids ), $posts, $country_code, $categories, $order_price, $order );
	}

	public function get_template_id_no_order( $type, $object = [] ) {
		if ( ! empty( $_POST['billing_country'] ) ) {// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$country_code = sanitize_text_field( $_POST['billing_country'] );// phpcs:ignore WordPress.Security.NonceVerification.Missing
		} else {
			$locate       = \WC_Geolocation::geolocate_ip();
			$country_code = $locate['country'];
		}

		$lang_code = defined( 'ICL_LANGUAGE_CODE' ) ? ICL_LANGUAGE_CODE : '';
		if ( class_exists( 'TRP_Translate_Press' ) ) {
			$lang_code_str = get_locale();
			$lang_code_arr = explode( "_", $lang_code_str );
			$lang_code     = $lang_code_arr[0];
		}
		$temp_id = '';

		$args = [
			'posts_per_page' => - 1,
			'post_type'      => 'viwec_template',
			'post_status'    => 'publish',
			'meta_key'       => 'viwec_settings_type',// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => $type,// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		];
		$args = apply_filters( 'viwec_get_template_query_args', $args, $type, $object );

		$posts = viwec_query_templates( $args );

		if ( $country_code ) {
			foreach ( $posts as $post ) {
				$rules          = get_post_meta( $post->ID, 'viwec_setting_rules', true );
				$rule_countries = $rules['countries'] ?? [];
				$rule_languages = $rules['languages'] ?? [];

				if ( function_exists( 'icl_get_languages' ) ) {
					if ( $lang_code !== 'all' && ! empty( $rule_languages ) && is_array( $rule_languages ) ) {
						if ( ! in_array( $lang_code, $rule_languages ) ) {
							continue;
						}
					}
				}

				if ( ! empty( $rule_countries ) && is_array( $rule_countries ) ) {
					if ( ! in_array( $country_code, $rule_countries ) ) {
						continue;
					}
				}
				/*Rule compatible with 3rd*/
				$rule_3rd = true;
				$rule_3rd = apply_filters( 'viwec_add_rule_template_3rd', $rule_3rd, $rules, $object );

				if ( ! $rule_3rd ) {
					continue;
				}
				$temp_id = $post->ID ?? '';
				break;
			}
		} else {
			$post = current( $posts );

			$temp_id = $post->ID ?? '';
		}

		return apply_filters( 'viwec_get_template_id_no_order', $temp_id, $type, $object, $this );
	}

	public function get_default_template() {
		if ( isset( $this->template_data['default_template'] ) ) {
			return $this->template_data['default_template'];
		}
		$id   = '';
		$args = [
			'posts_per_page' => - 1,
			'post_type'      => 'viwec_template',
			'post_status'    => 'publish',
			'meta_key'       => 'viwec_settings_type',// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => 'default',// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		];

		$posts = viwec_query_templates( $args );
		if ( ! empty( $posts ) ) {
			$ids = wp_list_pluck( $posts, 'ID' );
			$id  = current( $ids );
		}
		$this->template_data['default_template'] = $id;

		return apply_filters( 'viwec_get_default_template_id', $id, $this );
	}
    public function add_attachment_file_wp_mail($args){
	    $template_id = $this->template_data['used_template_id'] ?? '';
	    if ( ! $template_id && ! empty( $this->template_data['default_template'] ) ) {
		    $template_id = $this->template_data['default_template'];
	    }
	    if ( $template_id ) {
		    $files = get_post_meta( $template_id, 'viwec_attachments', true );
		    if ( ! empty( $files ) && is_array( $files ) ) {
			    foreach ( $files as $file_id ) {
				    $args['attachments'][] = get_attached_file( $file_id );
			    }
		    }
	    }

	    return apply_filters( 'viwec_wp_mail_args', $args, $template_id, $this );
    }

	public function replace_default_to_wp_email( $email) {
		$template_id = $this->get_default_template();
		if ( $template_id && get_post( $template_id ) ) {
			$email_render = Email_Render::init();
			$email_render->other_message_content = wpautop($email['message']);
			$email_render->recover_heading  = str_replace( '[%s]','', $email['subject'] );
			$email_render->use_default_template  = true;
			$data = get_post_meta( $template_id, 'viwec_email_structure', true );
			$data = json_decode( Init::html_entity_decode( $data ), true );
			$data['viwec_disable_wc_inline_style'] = false;
			ob_start();
			$email_render->render( $data );
			$email['message'] = ob_get_clean();

			$email['headers'] = [ "Content-Type: text/html" ];
		}
		return apply_filters( 'viwec_replace_default_wp_email', $email, $template_id, $this );
	}
	/**
	 * Whether to skip Mailonix New account styling on WordPress's wp_new_user_notification_email.
	 *
	 * WooCommerce customers already get account emails via WC_Email (customer_new_account,
	 * customer_verify_email, …). Forcing the New account template onto every WP new-user
	 * notification overrides the correct WC type when both paths fire.
	 *
	 * @param \WP_User $user User receiving the notification.
	 * @return bool
	 */
	protected function should_skip_wp_new_user_mailonix_template( $user ) {
		if ( ! $user instanceof \WP_User ) {
			return false;
		}

		if ( ! in_array( 'customer', (array) $user->roles, true ) ) {
			return false;
		}

		// Only skip when WC is already handling account mail in this request (not admin-created customers).
		$wc_handling = did_action( 'woocommerce_created_customer' ) > 0
			|| did_action( 'woocommerce_created_customer_notification' ) > 0
			|| did_action( 'woocommerce_customer_verify_email_notification' ) > 0;

		/**
		 * Filter whether to leave wp_new_user_notification_email untouched for this user.
		 *
		 * @param bool     $skip Whether to skip Mailonix New account replacement.
		 *                       Default: true for role customer when a WC account email action ran this request.
		 * @param \WP_User $user User receiving the notification.
		 */
		return (bool) apply_filters( 'viwec_skip_wp_new_user_email_for_customer', $wc_handling, $user );
	}

	public function replace_wp_new_user_email( $wp_new_user_notification_email, $user, $blogname ) {
		// Do not force customer_new_account onto WP notify for WC customers — WC mailer owns those types.
		if ( $this->should_skip_wp_new_user_mailonix_template( $user ) ) {
			return apply_filters( 'viwec_replace_wp_new_user_email', $wp_new_user_notification_email, $user, $blogname, 0, $this );
		}

		$template_id = $this->get_template_id( 'customer_new_account', $user );

		if ( $template_id && $template_id !== 'disabled' && get_post( $template_id ) ) {
			$register_data = [];
			if ( isset( $_POST['action'] ) && $_POST['action'] == 'uael_register_user' ) {// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$data = wc_clean( $_POST['data'] );// phpcs:ignore WordPress.Security.NonceVerification.Missing
			} else {
				$data = wc_clean( $_POST );// phpcs:ignore WordPress.Security.NonceVerification.Missing
			}

			if ( isset( $data['user_name'] ) ) {
				$register_data['user_name'] = wp_unslash( sanitize_text_field( $data['user_name'] ) );
			}

			if ( ! empty( $data['first_name'] ) ) {
				$register_data['first_name'] = sanitize_text_field( $data['first_name'] );
			}

			if ( ! empty( $data['last_name'] ) ) {
				$register_data['last_name'] = sanitize_text_field( $data['last_name'] );
			}

			if ( ! empty( $data['password'] ) ) {
				$register_data['password'] = wp_unslash( sanitize_text_field( $data['password'] ) );
			} else {
				$key = get_password_reset_key( $user );
				if ( ! is_wp_error( $key ) ) {
					$set_password_url                    = network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user->user_login ), 'login' );
					$register_data['set_password_url']   = $set_password_url;
					$register_data['reset_password_url'] = $set_password_url;
				}
			}

			$user->register_data = $register_data;

			$subject = get_post( $template_id )->post_title;
			if ( $subject ) {
				$wp_new_user_notification_email['subject'] = htmlspecialchars_decode( Utils::replace_shortcode( $subject, [], $user ), ENT_QUOTES );
			}

			$email_render = Email_Render::init();
			$email_render->set_user( $user );

			$data = get_post_meta( $template_id, 'viwec_email_structure', true );
			$data = json_decode( Init::html_entity_decode( $data ), true );
			ob_start();
			$email_render->render( $data );
			$email_body = ob_get_clean();

			if ( $email_body ) {
				$wp_new_user_notification_email['message'] = $email_body;
			}

			$wp_new_user_notification_email['headers'] = [ "Content-Type: text/html" ];
		}
		return apply_filters( 'viwec_replace_wp_new_user_email', $wp_new_user_notification_email, $user, $blogname, $template_id, $this );
	}

	public function replace_wp_reset_password_title( $title, $user_login, $user_data ) {
		$template_id = $this->get_template_id( 'customer_reset_password', $user_data );
		if ( $template_id && $template_id !== 'disabled' && get_post( $template_id ) ) {
			$subject = get_post( $template_id )->post_title;
			if ( $subject && is_a( $user_data, 'WP_User' ) ) {
				$user_data->register_data = array_merge(
					is_array( $user_data->register_data ?? null ) ? $user_data->register_data : [],
					[ 'user_name' => $user_login ]
				);
				$title = htmlspecialchars_decode( Utils::replace_shortcode( $subject, [], $user_data ), ENT_QUOTES );
			}
		}

		return apply_filters( 'viwec_replace_wp_reset_password_title', $title, $user_login, $user_data, $this );
	}

	public function replace_wp_reset_password_email( $message, $key, $user_login, $user_data ) {
		$template_id = $this->get_template_id( 'customer_reset_password', $user_data );
		if ( $template_id && $template_id !== 'disabled' && get_post( $template_id ) ) {
			$locale    = get_user_locale( $user_data );
			$reset_url = network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' ) . '&wp_lang=' . $locale;

			$user_data->register_data = [
				'user_name'          => $user_login,
				'reset_password_url' => $reset_url,
				'set_password_url'   => $reset_url,
			];

			$email_render = Email_Render::init();
			$email_render->set_user( $user_data );

			$data = get_post_meta( $template_id, 'viwec_email_structure', true );
			$data = json_decode( Init::html_entity_decode( $data ), true );
			ob_start();
			$email_render->render( $data );
			$email_body = ob_get_clean();

			if ( $email_body ) {
				$message = $email_body;
				add_filter( 'wp_mail_content_type', [ $this, 'replace_wp_email_type_to_html' ] );
			}
		}

		return apply_filters( 'viwec_replace_wp_reset_password_email', $message, $key, $user_login, $user_data, $this );
	}

	public function replace_wp_email_type_to_html() {
		return 'text/html';
	}

	public function remove_style( $style ) {
		return $this->clear_css ? '#viwec{}' : $style;
	}

	public function custom_css( $style, \WC_Email $email ) {
		$template_id = $this->get_template_id( $email->id, $email->object );
		if ( ( ! $template_id || $template_id === 'disabled' ) && $this->use_default_temp === false ) {
			$this->use_default_temp = $this->get_default_template();
		}
		if ( $this->use_default_temp || ( $template_id && $template_id !== 'disabled' ) ) {
			$id    = $template_id ?: $this->use_default_temp;
			$style .= get_post_meta( $id, 'viwec_custom_css', true );
		}

		return apply_filters( 'viwec_email_custom_css', $style, $email, $template_id, $this );
	}

	public function use_default_template_email( $args, $class_email ) {
		$template_id = $this->get_template_id( $class_email->id, $class_email->object );
		if ( $this->use_default_temp === false ) {
			$this->use_default_temp = $this->get_default_template();
		}
		if ( $this->use_default_temp && ( ! $template_id || $template_id === 'disabled' ) ) {
			add_filter( 'woocommerce_order_item_thumbnail', [ $this, 'item_thumbnail_start' ], PHP_INT_MAX );
			add_action( 'woocommerce_order_item_meta_end', [ $this, 'item_thumbnail_end' ], PHP_INT_MAX );

			$email_render = Email_Render::init();

			if ( ! $email_render->check_rendered ) {
				$email_render->set_object( $class_email );
				$this->user                          = $class_email;
				$email_render->class_email           = $this->class_email;
				$email_render->recover_heading       = $this->heading;
				$email_render->other_message_content = $args[2];
				$email_render->use_default_template  = true;
				$data                                = get_post_meta( $this->use_default_temp, 'viwec_email_structure', true );
				$data                                = json_decode( Init::html_entity_decode( $data ), true );
                $data['viwec_disable_wc_inline_style'] = false;
				ob_start();
				$email_render->render( $data );
				$message = ob_get_clean();
				$message = $class_email->style_inline( $message );
				$args[2] = $message;

				remove_filter( 'woocommerce_order_item_thumbnail', [ $this, 'item_thumbnail_start' ] );
				remove_action( 'woocommerce_order_item_name', [ $this, 'item_thumbnail_end' ] );
			}
		}

		return apply_filters( 'viwec_default_template_mail_args', $args, $class_email, $this );
	}

	public function item_thumbnail_start( $image ) {
		$this->fix_default_thumbnail = true;

		return '<table><tr><td valign="middle" style="vertical-align: middle;border: none;"> ' . $image . '</td><td valign="middle" style="vertical-align: middle;border: none;">';
	}

	public function item_thumbnail_end() {
		if ( $this->fix_default_thumbnail ) {
			?>
            </td>
            </tr>
            </table>
			<?php
			$this->fix_default_thumbnail = false;
		}
	}


	public function add_attachment_file( $args ) {
		$template_id = $this->template_data['used_template_id'] ?? '';
		if ( ! $template_id && ! empty( $this->class_email->id ) ) {
			$tid = $this->get_template_id( $this->class_email->id, $this->object );
			if ( $tid && $tid !== 'disabled' ) {
				$template_id = $tid;
			}
		}
		$id = $template_id ?: $this->use_default_temp;
		if ( $id && isset( $args[4] ) ) {
			$files = get_post_meta( $id, 'viwec_attachments', true );
			if ( ! empty( $files ) && is_array( $files ) ) {
				foreach ( $files as $file_id ) {
					$args[4][] = get_attached_file( $file_id );
				}
			}
		}

		return apply_filters( 'viwec_email_attachments', $args, $id, $this );
	}

	public function reset_template_id( $wp_mail ) {
		Email_Render::init()->reset_context();
		$this->template_data          = [];
		$this->use_default_temp       = false;
		$this->disable_email_template = '';
		$this->unique                 = [];
		$this->class_email            = null;
		$this->object                 = null;
		$this->user                   = null;

		return $wp_mail;
	}

	public function send_email_via_wc_mailer( $heading, $email ) {
		/*If email empty is template is preview*/
		if ( $this->disable_email_template || empty( $email ) ) {
			return;
		}
		if ( ! empty( $_REQUEST['preview_woocommerce_mail'] ) ) {
			return;
		}

		$this->heading          = $heading;
		$this->use_default_temp = $this->get_default_template();
		$this->remove_header_footer_hook( $this->use_default_temp );
		add_action( 'woocommerce_email_header', array( $this, 'send_email_via_wc_mailer' ), 0, 2 );
	}

	public function add_padding_for_addition_content( $value, \WC_Email $email, $_value, $key ) {
		if ( $this->use_default_temp === false ) {
			$template_id            = $this->get_template_id( $email->id, $email->object );
			$this->use_default_temp = $template_id && $template_id !== 'disabled' ? '' : $this->get_default_template();
		}
		if ( $this->use_default_temp ) {
			$value = $key == 'additional_content' ? "<div style='padding-top: 20px;'>{$value}</div>" : $value;
		}

		return $value;
	}

	public function minify_email_content( $args ) {
		$message = $args[2];
		$args[2] = apply_filters( 'viwec_minify_email_content', Utils::minify_html( $message ), $args, $this );

		return $args;
	}

}

