<?php
/**
 * Shared admin UI helper — add-on cards.
 *
 * Rendering helpers shared by the Add-Ons screen
 * (lib/admin/settings/essb-structure5-addons.php) and by the Add-Ons tab of
 * the advanced options panel (lib/admin/advanced-options/setup/ao-features.php).
 *
 * Both screens list the same add-ons and have to look the same, so the icon
 * rendering, the state resolution and the shared styles live here instead of
 * being copied into the two templates.
 *
 * @package EasySocialShareButtons
 */

include_once ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/ui-icon-frame.php';

if (!function_exists('essb_addons_color_to_rgb')) {
	/**
	 * Helper: convert a hex color into its rgb components.
	 * Returns null when the color cannot be parsed.
	 *
	 * @param string $color Hex color, with or without the leading '#'.
	 * @return array|null Array of red, green and blue values.
	 */
	function essb_addons_color_to_rgb($color)
	{
		$color = trim((string) $color);

		if ('' === $color) {
			return null;
		}

		$hex = ltrim($color, '#');

		if (3 === strlen($hex)) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}

		if (6 !== strlen($hex) || !ctype_xdigit($hex)) {
			return null;
		}

		return array(
			hexdec(substr($hex, 0, 2)),
			hexdec(substr($hex, 2, 2)),
			hexdec(substr($hex, 4, 2)),
		);
	}
}

if (!function_exists('essb_addons_color_to_rgba')) {
	/**
	 * Helper: build an rgba() string from a hex color.
	 *
	 * @param string $color Hex color.
	 * @param float  $alpha Alpha channel, 0 - 1.
	 * @return string Empty string when the color cannot be parsed.
	 */
	function essb_addons_color_to_rgba($color, $alpha = 1.0)
	{
		$rgb = essb_addons_color_to_rgb($color);

		if (null === $rgb) {
			return '';
		}

		return 'rgba(' . $rgb[0] . ',' . $rgb[1] . ',' . $rgb[2] . ',' . $alpha . ')';
	}
}

if (!function_exists('essb_addons_color_shade')) {
	/**
	 * Helper: darken a brand color when it is too light to stay legible as a
	 * glyph on the tinted icon frame.
	 *
	 * @param string $color  Hex color.
	 * @param float  $factor Multiplier applied when the color needs darkening.
	 * @return string Hex color.
	 */
	function essb_addons_color_shade($color, $factor = 0.55)
	{
		$rgb = essb_addons_color_to_rgb($color);

		if (null === $rgb) {
			return $color;
		}

		$luminance = (0.299 * $rgb[0] + 0.587 * $rgb[1] + 0.114 * $rgb[2]) / 255;

		if ($luminance < 0.68) {
			return $color;
		}

		return sprintf(
			'#%02x%02x%02x',
			(int) round($rgb[0] * $factor),
			(int) round($rgb[1] * $factor),
			(int) round($rgb[2] * $factor)
		);
	}
}

if (!function_exists('essb_addons_render_icon')) {
	/**
	 * Helper: render the hexagon icon frame for one add-on.
	 * The frame is tinted with the add-on brand color, the glyph keeps it too.
	 *
	 * @param array $data Add-on data as delivered by the add-ons API.
	 */
	function essb_addons_render_icon($data)
	{
		$svg        = isset($data['svg_icon'])       ? $data['svg_icon']       : '';
		$brand      = isset($data['color'])          ? $data['color']          : '';
		$color_type = isset($data['svg_color_type']) ? $data['svg_color_type'] : 'fill';

		if ('stroke' !== strtolower($color_type)) {
			$color_type = 'fill';
		}

		$frame_style = '';
		$frame_fill   = essb_addons_color_to_rgba($brand, 0.10);
		$frame_stroke = essb_addons_color_to_rgba($brand, 0.28);

		if ('' !== $frame_fill) {
			$frame_style = 'fill:' . $frame_fill . ';stroke:' . $frame_stroke . ';';
		}

		$icon_color = essb_addons_color_shade($brand, 0.55);

		if ('' === trim((string) $icon_color)) {
			$icon_color = '#1e2129';
		}

		essb_render_ui_icon_frame($svg, array(
			'icon_class'  => 'essb-addons-icon essb-icon-' . $color_type,
			'frame_style' => $frame_style,
			'icon_style'  => '--essb-icon-c:' . $icon_color . ';',
		));
	}
}

if (!function_exists('essb_addons_resolve_state')) {
	/**
	 * Helper: resolve install/activate/deactivate state for one add-on key.
	 * Returns array: url_command, command_text, command_class, not_compatible.
	 *
	 * @param string $key             Add-on slug.
	 * @param array  $data            Add-on data.
	 * @param array  $current_plugins Installed plugins lookup.
	 * @param string $redirect_url    Optional URL used after activate/deactivate.
	 */
	function essb_addons_resolve_state($key, $data, $current_plugins, $redirect_url = '')
	{
		$not_compatible = false;
		$pro_running = false;

		$requires = isset($data['requires']) ? $data['requires'] : '';

		if (!empty($requires) && version_compare(ESSB3_VERSION, $requires) < 0) {
			$not_compatible = true;
		}

		// ------------------------------------------------------------------
		// Pro Check
		// ------------------------------------------------------------------
		if (isset($data['pro_check'])) {

			$pro_check_param = isset($data['pro_check']['param']) ? $data['pro_check']['param'] : '';
			$pro_check_type  = isset($data['pro_check']['type']) ? $data['pro_check']['type'] : '';

			if (!empty($pro_check_type) && !empty($pro_check_param)) {

				if ($pro_check_type == 'param') {
					if (defined($pro_check_param)) {
						$pro_running = true;
					}
				}

				if ($pro_check_type == 'function') {
					if (function_exists($pro_check_param)) {
						$pro_running = true;
					}
				}

				if ($pro_check_type == 'class') {
					if (class_exists($pro_check_param)) {
						$pro_running = true;
					}
				}
			}

			if ($pro_running) {
				$not_compatible = true;
			}
		}

		// ------------------------------------------------------------------
		// Version Information
		// ------------------------------------------------------------------

		$remote_version    = isset($data['version']) ? trim($data['version']) : '';
		$installed_version = '';
		$has_update        = false;
		$update_url        = '';

		// ------------------------------------------------------------------
		// Default Install Action
		// ------------------------------------------------------------------

		$install_base = admin_url('admin.php?page=essb_redirect_addons');

		if (class_exists('ESSB_TGM_Plugin_Activation') && isset(ESSB_TGM_Plugin_Activation::$instance)) {
			$tgmpa_url = ESSB_TGM_Plugin_Activation::$instance->get_tgmpa_url();

			// TGMPA skips its own configuration during Ajax requests (DOING_AJAX),
			// so its URL is only usable when it really points to the ESSB add-ons
			// page — otherwise the install link would target a missing screen.
			if (false !== strpos($tgmpa_url, 'page=essb_redirect_addons')) {
				$install_base = $tgmpa_url;
			}
		}

		$url_install = wp_nonce_url(
			add_query_arg(
				array(
					'plugin'             => urlencode($key),
					'essb-tgmpa-install' => 'install-plugin',
				),
				$install_base
			),
			'essb-tgmpa-install',
			'essb-tgmpa-nonce'
		);

		$url_command   = $url_install;
		$command_text  = 'Install';
		$command_class = 'button-primary';

		$is_active = false;

		// ------------------------------------------------------------------
		// Installed Plugin State
		// ------------------------------------------------------------------

		if (isset($current_plugins[$key])) {

			$addon_slug = $current_plugins[$key]['path'];

			if (empty($redirect_url)) {
				$redirect_url = admin_url('admin.php?page=essb_redirect_addons');
			}

			$url_activate = wp_nonce_url(
				add_query_arg(
					array(
						'action'      => 'activate',
						'plugin'      => $addon_slug,
						'redirect_to' => urlencode($redirect_url),
					),
					admin_url('plugins.php')
				),
				"activate-plugin_{$addon_slug}"
			);

			$url_deactivate = wp_nonce_url(
				add_query_arg(
					array(
						'action'      => 'deactivate',
						'plugin'      => $addon_slug,
						'redirect_to' => urlencode($redirect_url),
					),
					admin_url('plugins.php')
				),
				"deactivate-plugin_{$addon_slug}"
			);

			$is_active = (bool) $current_plugins[$key]['active'];

			$url_command   = $is_active ? $url_deactivate : $url_activate;
			$command_text  = $is_active ? 'Deactivate' : 'Activate';
			$command_class = $is_active ? 'button-deactivate' : 'button-activate';

			$installed_version = isset($current_plugins[$key]['version'])
				? trim($current_plugins[$key]['version'])
				: '';

			// --------------------------------------------------------------
			// Update Check
			// --------------------------------------------------------------

			if (!empty($installed_version) && !empty($remote_version)) {

				$has_update = version_compare(
					$remote_version,
					$installed_version,
					'>'
				);
			}

			// --------------------------------------------------------------
			// Update URL
			// --------------------------------------------------------------

			if ($has_update) {

				$update_url = wp_nonce_url(
					add_query_arg(
						array(
							'plugin'            => urlencode($key),
							'essb-tgmpa-update' => 'update-plugin',
						),
						$install_base
					),
					'essb-tgmpa-update',
					'essb-tgmpa-nonce'
				);
			}
		}

		return array(
			'url_command'       => $url_command,
			'command_text'      => $command_text,
			'command_class'     => $command_class,
			'not_compatible'    => $not_compatible,
			'pro_running'       => $pro_running,
			'active'            => $is_active,
			'requires'          => $requires,

			'installed_version' => $installed_version,
			'remote_version'    => $remote_version,
			'has_update'        => $has_update,
			'update_url'        => $update_url,
		);
	}
}

if (!function_exists('essb_addons_render_styles')) {
	/**
	 * Print the styles shared by every screen that lists add-ons: the brand
	 * colored icon, the meta chips and the notice boxes. Printed once per
	 * request, no matter how many screens ask for it.
	 */
	function essb_addons_render_styles()
	{
		static $printed = false;

		if ($printed) {
			return;
		}

		$printed = true;
		?>
		<style>
			/* ============================================================
			   ESSB ADD-ONS — shared styles
			   Used by the Add-Ons screen and by the Add-Ons tab of the
			   advanced options panel so both look identical.
			   ============================================================ */

			/* ---- Hexagon icon frame ---- */
			.essb-addons-icon {
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				display: flex;
				align-items: center;
				justify-content: center;
				width: 32px;
				height: 32px;
			}

			.essb-addons-icon svg {
				width: 100% !important;
				height: 100% !important;
				display: block;
			}

			/* Remote add-on SVGs ship with hardcoded fills — force the brand color */
			.essb-addons-icon.essb-icon-fill svg path,
			.essb-addons-icon.essb-icon-fill svg rect,
			.essb-addons-icon.essb-icon-fill svg circle,
			.essb-addons-icon.essb-icon-fill svg polygon,
			.essb-addons-icon.essb-icon-fill svg ellipse {
				fill: var(--essb-icon-c, #1e2129);
			}

			.essb-addons-icon.essb-icon-stroke svg path,
			.essb-addons-icon.essb-icon-stroke svg rect,
			.essb-addons-icon.essb-icon-stroke svg circle,
			.essb-addons-icon.essb-icon-stroke svg polygon,
			.essb-addons-icon.essb-icon-stroke svg ellipse {
				stroke: var(--essb-icon-c, #1e2129);
				fill: none;
			}

			/* ---- Meta chips ---- */
			.essb-addons-chip {
				display: inline-flex;
				align-items: center;
				font-size: 10px;
				font-weight: 600;
				letter-spacing: .4px;
				text-transform: uppercase;
				color: var(--color-grey-600);
				background: var(--color-grey-100);
				border: 1px solid var(--color-grey-300);
				border-radius: 3px;
				padding: 2px 6px;
				line-height: 1.5;
			}

			/* ---- Notices ---- */
			.essb-addons-notice {
				display: flex;
				align-items: center;
				justify-content: center;
				gap: 5px;
				width: 100%;
				border-radius: 4px;
				padding: 6px 8px;
				font-size: 11.5px;
				font-weight: 600;
				text-align: center;
			}

			.essb-addons-notice svg {
				width: 12px;
				height: 12px;
				fill: currentColor;
				flex-shrink: 0;
			}

			.essb-addons-notice-update {
				background: #eff6ff;
				border: 1px solid #bfdbfe;
				color: #1d4ed8;
			}

			.essb-addons-notice-error {
				background: #fef2f2;
				border: 1px solid #fecaca;
				color: #dc2626;
			}
		</style>
		<?php
	}
}
