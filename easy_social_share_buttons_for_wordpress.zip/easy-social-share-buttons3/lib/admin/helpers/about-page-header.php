<!--  notifications -->
<script src="<?php echo esc_url(ESSB3_PLUGIN_URL); ?>/assets/admin/jquery.toast.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo esc_url(ESSB3_PLUGIN_URL); ?>/assets/admin/jquery.toast.css">
<!-- notifications -->

<div class="about-header">
	<div class="logo">
		<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" viewBox="0 0 44 44" enable-background="new 0 0 44 44" width="32px" height="32px">
			<g>
				<path d="m15,19c-1.1,0-2,0.9-2,2s0.9,2 2,2c0.6,0 1.2-0.3 1.6-0.8 0.2-0.2 0.4-0.6 0.4-1.2 0-0.3-0.1-0.5-0.2-0.8-0.3-0.7-1-1.2-1.8-1.2z" fill="#FFFFFF" />
				<path d="m26,31c1.1,0 2-0.9 2-2s-0.9-2-2-2c-0.6,0-1.2,0.3-1.6,0.8-0.2,0.2-0.4,0.6-0.4,1.2 0,1.1 0.9,2 2,2z" fill="#FFFFFF" />
				<path d="m22,0c-12.2,0-22,9.8-22,22s9.8,22 22,22 22-9.8 22-22-9.8-22-22-22zm7,21c-1.6,0-3.1-0.7-4.2-1.7-0.1-0.1-0.4-0.2-0.5-0.1l-3,1.3c-0.2,0.1-0.3,0.3-0.3,0.5 0,0.5-0.1,1-0.2,1.4 0,0.2 0,0.4 0.2,0.5l1.3,.9c0.2,0.1 0.4,0.1 0.6,0 0.9-0.5 2-0.9 3.1-0.9 3.3,0 6,2.7 6,6s-2.7,6-6,6-6-2.7-6-6c0-0.5 0.1-0.9 0.2-1.4 0-0.2 0-0.4-0.2-0.5l-1.3-1c-0.2-0.1-0.4-0.1-0.6,0-0.9,0.6-2,0.9-3.1,0.9-3.3,0-6-2.7-6-6s2.7-6 6-6c1.6,0 3.1,0.7 4.2,1.7 0.1,0.1 0.4,0.2 0.5,0.1l3-1.3c0.2-0.1 0.3-0.3 0.3-0.5 0,0 0,0 0-0.1 0-3.3 2.7-6 6-6s6,2.7 6,6-2.7,6.2-6,6.2z" fill="#FFFFFF" />
				<path d="m29,13c-1.1,0-2,0.9-2,2 0,0.3 0.1,0.5 0.2,0.8 0.3,0.7 1,1.2 1.8,1.2 1.1,0 2-0.9 2-2s-0.9-2-2-2z" fill="#FFFFFF" />
			</g>
		</svg>
	</div>
	<div class="logo-name">
		Easy Social Share Buttons for WordPress
		<span class="logo-version" style="display:inline-block;font-size:11px;font-weight:600;color:#fff;background:#3858E9;padding:2px 8px;border-radius:4px;vertical-align:middle;margin-left:8px;letter-spacing:.3px;"><?php echo esc_html(ESSB3_VERSION); ?></span>
	</div>

	<div class="usefull-links">
		<?php
		if (essb_is_envato_version()) {
			if (!ESSB_Envato_Activation_Manager::isActivated()) {
				echo '<a href="#activate" class="essb-control-btn essb-control-btn-activate"><i class="fa fa-ban"></i> ' . esc_html__('Not activated', 'essb') . '</a>';
			}
			else {
				echo '<a href="https://docs.socialsharingplugin.com/knowledgebase/migrating-your-easy-social-share-buttons-license-to-freemius/" target="_blank" class="essb-control-btn essb-control-btn-activate">' . esc_html__('Migrate License', 'essb') . '</a>';
			}
		}
		?>
		<a href="<?php echo esc_url(admin_url('admin.php?page=essb_redirect_addons')); ?>">Add-Ons</a>
		<a href="<?php echo esc_url(admin_url('admin.php?page=essb_redirect_tools')); ?>">Tools</a>
		<a href="https://docs.socialsharingplugin.com" target="_blank">Documentation</a>
		<a href="https://socialsharingplugin.com/account/" target="_blank">Get Support</a>
	</div>
</div>