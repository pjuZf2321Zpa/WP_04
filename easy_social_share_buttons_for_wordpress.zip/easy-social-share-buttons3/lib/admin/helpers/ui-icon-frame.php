<?php
/**
 * Shared admin UI helper — hexagonal icon frame.
 *
 * Renders the hexagon frame used by the plugin dashboard cards so that every
 * screen (dashboard, add-ons, ...) draws a byte-identical frame.
 *
 * @package EasySocialShareButtons
 */

if (! function_exists('essb_render_ui_icon_frame')) {
	/**
	 * Render the hexagonal icon frame with an icon centered inside it.
	 *
	 * @param string $icon_svg Raw SVG markup placed inside the frame.
	 * @param array  $options  Optional overrides:
	 *                          - frame_class  extra class for the frame <svg>
	 *                          - icon_class   extra class for the icon wrapper
	 *                          - frame_style  inline style for the frame <svg>
	 *                          - icon_style   inline style for the icon wrapper
	 *
	 * @return void
	 */
	function essb_render_ui_icon_frame($icon_svg = '', $options = array())
	{
		$defaults = array(
			'frame_class' => '',
			'icon_class'  => '',
			'frame_style' => '',
			'icon_style'  => '',
		);

		$options = array_merge($defaults, $options);

		$frame_classes = 'essb-ui-svg-frame';
		if (! empty($options['frame_class'])) {
			$frame_classes .= ' ' . $options['frame_class'];
		}

		$icon_classes = 'essb-ui-svg-icon';
		if (! empty($options['icon_class'])) {
			$icon_classes .= ' ' . $options['icon_class'];
		}

		echo '<div class="essb-ui-icon-frame64">';

		echo '<svg class="' . esc_attr($frame_classes) . '" fill="none" height="48" viewBox="0 0 44 48" width="44" xmlns="http://www.w3.org/2000/svg"'
			. ( '' !== $options['frame_style'] ? ' style="' . esc_attr($options['frame_style']) . '"' : '' ) . '>';
		echo '<path d="M16 2.4641C19.7128 0.320509 24.2872 0.320508 28 2.4641L37.6506 8.0359C41.3634 10.1795 43.6506 14.141 43.6506 18.4282V29.5718C43.6506 33.859 41.3634 37.8205 37.6506 39.9641L28 45.5359C24.2872 47.6795 19.7128 47.6795 16 45.5359L6.34937 39.9641C2.63655 37.8205 0.349365 33.859 0.349365 29.5718V18.4282C0.349365 14.141 2.63655 10.1795 6.34937 8.0359L16 2.4641Z"/>';
		echo '<path d="M16.25 2.89711C19.8081 0.842838 24.1919 0.842837 27.75 2.89711L37.4006 8.46891C40.9587 10.5232 43.1506 14.3196 43.1506 18.4282V29.5718C43.1506 33.6804 40.9587 37.4768 37.4006 39.5311L27.75 45.1029C24.1919 47.1572 19.8081 47.1572 16.25 45.1029L6.59937 39.5311C3.04125 37.4768 0.849365 33.6803 0.849365 29.5718V18.4282C0.849365 14.3196 3.04125 10.5232 6.59937 8.46891L16.25 2.89711Z"/>';
		echo '</svg>';

		echo '<i class="' . esc_attr($icon_classes) . '"'
			. ( '' !== $options['icon_style'] ? ' style="' . esc_attr($options['icon_style']) . '"' : '' ) . '>';
		echo $icon_svg; // Trusted plugin markup.
		echo '</i>';

		echo '</div>';
	}
}
