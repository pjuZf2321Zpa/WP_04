<?php
/**
 * Subscribe Form Customizer (replaces ao- popups for the optin tab).
 *
 * Single row-based UI with editor modal + live preview rendered by the
 * real plugin engines. Preset designs save through the main settings form
 * (essb_options[] inputs + Update Options). Custom forms save through the
 * existing advanced-options endpoint (group essb_options_forms).
 *
 * @package EasySocialShareButtons
 * @since 10.x
 */

if (!defined('ABSPATH')) {
	return;
}

if (!function_exists('essb5_sfc_preset_map')) {
	/**
	 * Exact field map mirroring lib/admin/advanced-options/setup/ao-subscribe-designN.php
	 * and lib/helpers/assets/customizer-subscribe-forms.php.
	 *
	 * Design 1 uses un-suffixed text/switch/custom keys (legacy), colors carry the 1 suffix.
	 */
	function essb5_sfc_preset_map() {
		$text_base = array(
			array('key' => 'title', 'label' => 'Heading'),
			array('key' => 'text', 'label' => 'Form custom content'),
			array('key' => 'name', 'label' => 'Name field placeholder text'),
			array('key' => 'email', 'label' => 'Email field placeholder text'),
			array('key' => 'button', 'label' => 'Subscribe button text'),
			array('key' => 'footer', 'label' => 'Footer text'),
			array('key' => 'success', 'label' => 'Success subscribe message'),
			array('key' => 'error', 'label' => 'Error message'),
		);

		$map = array();

		$color_sets = array(
			1 => array(
				array('key' => 'customizer_subscribe_bgcolor1', 'label' => 'Background color'),
				array('key' => 'customizer_subscribe_textcolor1', 'label' => 'Text color'),
				array('key' => 'customizer_subscribe_hovercolor1', 'label' => 'Accent color'),
				array('key' => 'customizer_subscribe_hovertextcolor1', 'label' => 'Accent text color'),
				array('key' => 'customizer_subscribe_emailcolor1', 'label' => 'Email/Name field background color'),
			),
			2 => array(
				array('key' => 'customizer_subscribe_bgcolor2', 'label' => 'Background color'),
				array('key' => 'customizer_subscribe_textcolor2', 'label' => 'Text color'),
				array('key' => 'customizer_subscribe_hovercolor2', 'label' => 'Accent color'),
				array('key' => 'customizer_subscribe_hovertextcolor2', 'label' => 'Accent text color'),
				array('key' => 'customizer_subscribe_emailcolor2', 'label' => 'Email/Name field background color'),
			),
		);

		$mid_colors = function ($n) {
			return array(
				array('key' => "customizer_subscribe_bgcolor{$n}", 'label' => 'Background color'),
				array('key' => "customizer_subscribe_textcolor{$n}", 'label' => 'Text color'),
				array('key' => "customizer_subscribe_bgcolor{$n}_bottom", 'label' => 'Bottom background color'),
				array('key' => "customizer_subscribe_textcolor{$n}_bottom", 'label' => 'Bottom text color'),
				array('key' => "customizer_subscribe_hovercolor{$n}", 'label' => 'Accent color'),
				array('key' => "customizer_subscribe_hovertextcolor{$n}", 'label' => 'Accent text color'),
				array('key' => "customizer_subscribe_emailcolor{$n}", 'label' => 'Email/Name field background color'),
			);
		};

		for ($n = 3; $n <= 7; $n++) {
			$color_sets[$n] = $mid_colors($n);
		}

		$color_sets[8] = array(
			array('key' => 'customizer_subscribe_bgcolor8', 'label' => 'Background color #1'),
			array('key' => 'customizer_subscribe_bgcolor82', 'label' => 'Background color #2'),
			array('key' => 'customizer_subscribe_textcolor8', 'label' => 'Text color'),
			array('key' => 'customizer_subscribe_bgcolor8_bottom', 'label' => 'Bottom background color'),
			array('key' => 'customizer_subscribe_textcolor8_bottom', 'label' => 'Bottom text color'),
			array('key' => 'customizer_subscribe_buttoncolor8', 'label' => 'Subscribe button color'),
			array('key' => 'customizer_subscribe_buttontextcolor8', 'label' => 'Subscribe button text color'),
		);

		$color_sets[9] = array(
			array('key' => 'customizer_subscribe_bgcolor9', 'label' => 'Background color'),
			array('key' => 'customizer_subscribe_textcolor9', 'label' => 'Text color'),
			array('key' => 'customizer_subscribe_accent9', 'label' => 'Accent color'),
			array('key' => 'customizer_subscribe_buttoncolor9', 'label' => 'Subscribe button text color'),
		);

		for ($n = 1; $n <= 9; $n++) {
			$suffix = ($n === 1) ? '' : (string) $n;

			$texts = array();
			foreach ($text_base as $t) {
				$opt = ($t['key'] === 'text' && $n === 1) ? 'subscribe_mc_text' : "subscribe_mc_{$t['key']}{$suffix}";
				// Design 1 legacy: subscribe_mc_title (no suffix) etc. The loop above already handles it via empty suffix.
				$texts[] = array('key' => $opt, 'label' => $t['label'], 'short' => $t['key']);
			}

			$switches = array(
				array('key' => "subscribe_mc_namefield{$suffix}", 'label' => 'Display name field'),
				array('key' => ($n === 1) ? 'activate_mailchimp_customizer' : "activate_mailchimp_customizer{$n}", 'label' => 'Enable color changing'),
			);

			if ($n === 1 || $n === 2 || $n === 7) {
				$noborder_key = ($n === 1) ? 'customizer_subscribe_noborder1' : "customizer_subscribe_noborder{$n}";
				$switches[] = array('key' => $noborder_key, 'label' => ($n === 2 ? 'Remove form border' : 'Remove form top border'));
			}

			$images = array();
			if (in_array($n, array(3, 4, 6), true)) {
				$images = array(
					array('key' => "subscribe_mc_image{$n}", 'label' => 'Choose image', 'type' => 'image'),
					array('key' => "subscribe_mc_imagealign{$n}", 'label' => 'Image placement', 'type' => 'imagealign'),
				);
			}

			$custom = array(
				array('key' => "subscribe_mc_customlist{$suffix}", 'label' => 'List ID'),
				array('key' => "subscribe_mc_customtags{$suffix}", 'label' => 'Tags (MailChimp)'),
			);

			$map[$n] = array(
				'texts' => $texts,
				'switches' => $switches,
				'colors' => $color_sets[$n],
				'images' => $images,
				'custom' => $custom,
			);
		}

		return $map;
	}
}

if (!function_exists('essb5_sfc_custom_field_map')) {
	function essb5_sfc_custom_field_map() {
		return array(
			'texts' => array(
				array('key' => 'title', 'label' => 'Heading'),
				array('key' => 'button_placeholder', 'label' => 'Subscribe button text'),
				array('key' => 'email_placeholder', 'label' => 'Email field text'),
				array('key' => 'name_placeholder', 'label' => 'Name field text'),
				array('key' => 'footer', 'label' => 'Footer text'),
				array('key' => 'ok_message', 'label' => 'Success subscribe message'),
				array('key' => 'error_message', 'label' => 'Error subscribe message'),
				array('key' => 'text', 'label' => 'Form custom content', 'type' => 'textarea'),
			),
			'colors' => array(
				array('key' => 'bgcolor', 'label' => 'Background color'),
				array('key' => 'bgcolor2', 'label' => 'Secondary background color'),
				array('key' => 'image_bgcolor', 'label' => 'Image area background color'),
				array('key' => 'textcolor', 'label' => 'Text color'),
				array('key' => 'headingcolor', 'label' => 'Heading color'),
				array('key' => 'footercolor', 'label' => 'Footer color'),
				array('key' => 'fields_bg', 'label' => 'Email/Name fields background color'),
				array('key' => 'fields_text', 'label' => 'Email/Name fields text color'),
				array('key' => 'button_bg', 'label' => 'Subscribe button background'),
				array('key' => 'button_text', 'label' => 'Subscribe button text'),
				array('key' => 'border_color', 'label' => 'Border color'),
				array('key' => 'glow_color', 'label' => 'Glow color'),
			),
		);
	}
}

if (!function_exists('essb5_subscribe_form_customizer')) {
	/**
	 * Component entry point used via ESSBOptionsStructureHelper::field_component().
	 */
	function essb5_subscribe_form_customizer($element_options = array()) {
		if (!function_exists('essb5_get_form_designs')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/formdesigner-helper.php');
		}

		wp_enqueue_media();
		wp_enqueue_style('essb-subscribe-forms-front', ESSB3_PLUGIN_URL . '/assets/modules/subscribe-forms.css', array(), ESSB3_VERSION);
		$sfc_js_ver = function_exists('essb_admin_asset_version') ? essb_admin_asset_version('assets/admin/essb-subscribe-form-customizer.js') : ESSB3_VERSION;
		$sfc_css_ver = function_exists('essb_admin_asset_version') ? essb_admin_asset_version('assets/admin/essb-subscribe-form-customizer.css') : ESSB3_VERSION;
		wp_enqueue_style('essb-sfc-customizer', ESSB3_PLUGIN_URL . '/assets/admin/essb-subscribe-form-customizer.css', array('essb-ui'), $sfc_css_ver);
		wp_enqueue_script('essb-sfc-customizer', ESSB3_PLUGIN_URL . '/assets/admin/essb-subscribe-form-customizer.js', array('jquery'), $sfc_js_ver, true);

		$preset_map = essb5_sfc_preset_map();
		$presets = array();
		$customized_flags = array();

		foreach ($preset_map as $n => $def) {
			$values = array();
			foreach (array_merge($def['texts'], $def['switches'], $def['colors'], $def['images'], $def['custom']) as $f) {
				$values[$f['key']] = essb_option_value($f['key']);
			}
			$presets[(string) $n] = $values;

			$check_keys = array();
			foreach (array_merge($def['texts'], $def['colors']) as $f) {
				$check_keys[] = $f['key'];
			}
			$customized_flags[(string) $n] = function_exists('essb5_has_setting_values') ? essb5_has_setting_values($check_keys) : false;
		}

		$custom_forms = essb5_get_form_designs();
		if (!is_array($custom_forms)) {
			$custom_forms = array();
		}

		$data = array(
			'presets' => $presets,
			'presetMap' => $preset_map,
			'customized' => $customized_flags,
			'customs' => array_values($custom_forms),
			'customKeys' => array_keys($custom_forms),
			'customMap' => essb5_sfc_custom_field_map(),
			'ajaxurl' => esc_url(admin_url('admin-ajax.php')),
		);

		echo '<div class="sfc-wrap" id="essb-sfc">';
		echo '<div class="essb-ui-card sfc-card">';
		echo '<div class="essb-ui-card-header"><div><div class="essb-ui-card-title">' . esc_html__('Form Designs', 'essb') . '</div>';
		echo '<div class="sfc-card-desc">' . esc_html__('Default designs first, then your custom designs. Click Customize/Edit to open the editor popup with live preview.', 'essb') . '</div></div>';
		echo '<button type="button" class="essb-ui-btn essb-ui-btn-primary" id="sfc-add-new">+ ' . esc_html__('Add new form design', 'essb') . '</button></div>';
		echo '<div class="essb-ui-card-content sfc-list" id="sfc-list"></div>';
		echo '</div>';
		echo '<div id="sfc-store" style="display:none"></div>';

		echo '<div class="sfc-modal-overlay" id="sfc-overlay"></div>';
		echo '<div class="sfc-modal essb-ui essb-options" id="sfc-modal" role="dialog" aria-modal="true">';
		echo '<div class="sfc-modal-header"><div class="sfc-modal-title" id="sfc-modal-title">' . esc_html__('Customize Form', 'essb') . '</div>';
		echo '<button type="button" class="sfc-modal-close" id="sfc-modal-close">&times;</button></div>';
		echo '<div class="sfc-modal-body"><div class="sfc-modal-left" id="sfc-modal-left"></div>';
		echo '<div class="sfc-modal-right"><div class="sfc-preview-head"><span class="sfc-preview-title">' . esc_html__('Live Preview', 'essb') . '</span>';
		echo '<span class="essb-ui-badge essb-ui-badge-sm" id="sfc-preview-badge">Form</span></div>';
		echo '<div class="sfc-preview-stage" id="sfc-preview"></div></div></div>';
		echo '<div class="sfc-modal-footer" id="sfc-modal-footer"></div>';
		echo '</div>';
		echo '</div>';

		echo '<script type="text/javascript">window.ESSB_SFC = ' . wp_json_encode($data) . ';</script>';
	}
}

if (!function_exists('essb_sfc_preview_handler')) {
	/**
	 * Server-side live preview using the real render engines.
	 * Routed through the existing advanced-options endpoint (cmd=subscribe_preview)
	 * so the same nonce/token is reused.
	 */
	function essb_sfc_preview_handler() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'denied'));
		}

		$mode = isset($_REQUEST['preview_mode']) ? sanitize_key($_REQUEST['preview_mode']) : 'preset';
		$raw_values = isset($_REQUEST['values']) ? wp_unslash($_REQUEST['values']) : array();
		if (!is_array($raw_values)) {
			$raw_values = array();
		}

		// Keep only scalar values.
		$values = array();
		foreach ($raw_values as $k => $v) {
			if (is_scalar($v)) {
				$values[sanitize_key($k)] = (string) $v;
			}
		}

		if (!class_exists('ESSBNetworks_Subscribe')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/modules/subscribe-forms/essb-subscribe.php');
		}
		if (!function_exists('essb_register_dynamic_subscribe_form_styles')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/helpers/assets/customizer-subscribe-forms.php');
		}
		if (!function_exists('essb5_get_form_designs')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/formdesigner-helper.php');
		}

		if ($mode === 'custom') {
			$design_key = '__sfc_preview__';
			$forms = essb5_get_form_designs();
			if (!is_array($forms)) {
				$forms = array();
			}
			$forms[$design_key] = $values;

			add_filter('option_' . ESSB_FORM_DESIGNS, function () use ($forms) {
				return $forms;
			});

			$html = ESSBNetworks_Subscribe::draw_user_subscribe_form('sfc-preview', 'userdesign-' . $design_key);
			wp_send_json_success(array('html' => $html, 'css' => ''));
		}

		// Preset mode.
		$design_num = isset($_REQUEST['design']) ? intval($_REQUEST['design']) : 1;
		if ($design_num < 1 || $design_num > 9) {
			$design_num = 1;
		}

		// Auto-enable color changing when any custom color value is provided,
		// so the chosen colors actually render in the live preview.
		$has_color = false;
		foreach ($values as $ck => $cv) {
			if (strpos($ck, 'customizer_subscribe_') === 0 && trim((string) $cv) !== '') {
				$has_color = true;
				break;
			}
		}
		if ($has_color) {
			$switch_key = ($design_num === 1) ? 'activate_mailchimp_customizer' : ('activate_mailchimp_customizer' . $design_num);
			$values[$switch_key] = 'true';
		}

		$stored = get_option(ESSB3_OPTIONS_NAME);
		if (!is_array($stored)) {
			$stored = array();
		}
		$merged = array_merge($stored, $values);

		global $essb_options;
		$essb_options = $merged;
		foreach ($values as $k => $v) {
			ESSB_Plugin_Options::set($k, $v);
		}

		$html = ESSBNetworks_Subscribe::draw_integrated_subscribe_form('sfc-preview', false, 'design' . $design_num);
		$css = '';
		if (function_exists('essb_register_dynamic_subscribe_form_styles')) {
			$css = essb_register_dynamic_subscribe_form_styles();
		}

		wp_send_json_success(array('html' => $html, 'css' => $css));
	}
}
