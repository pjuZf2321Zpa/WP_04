<?php
/**
 * Easy Social Share Buttons - Novashare data migration adapter.
 *
 * Moves per-post sharing customizations (social title/description/image,
 * Pinterest image/description/hidden images, hide/disable toggles, recovery
 * URLs) and per-attachment Pinterest attributes from a previous Novashare
 * install into the ESSB meta fields.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('essb_novashare_table_exists')) {
    function essb_novashare_table_exists() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $t = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}novashare_meta'");
        return !is_wp_error($t) && !is_null($t) && $t !== '';
    }
}

/**
 * Migrate Novashare per-post + per-attachment customizations into ESSB.
 *
 * @param bool $force When true, overwrite existing ESSB values.
 * @return array Stats.
 */
if (!function_exists('essb_data_migrate_novashare')) {
    function essb_data_migrate_novashare($force = false) {
        global $wpdb;

        $stats = array(
            'posts_scanned'             => 0,
            'posts_migrated'            => 0,
            'fields_written'            => 0,
            'attachments_scanned'       => 0,
            'attachments_migrated'      => 0,
            'attachment_fields_written' => 0,
            'errors'                    => array(),
        );

        if (!essb_novashare_table_exists()) {
            $stats['errors'][] = 'novashare_meta table not found';
            return $stats;
        }

        wp_raise_memory_limit('admin');
        @set_time_limit(0);

        // ---- post-level ----
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $post_ids = $wpdb->get_col(
            "SELECT DISTINCT post_id FROM {$wpdb->prefix}novashare_meta WHERE meta_key = 'details'"
        );

        foreach ($post_ids as $post_id) {
            $post_id = (int) $post_id;
            $stats['posts_scanned']++;

            // deterministic: latest row wins
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $raw = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->prefix}novashare_meta WHERE post_id = %d AND meta_key = 'details' ORDER BY id DESC LIMIT 1",
                $post_id
            ));
            $details = essb_safe_unserialize($raw);

            if (!is_array($details) || empty($details)) {
                continue;
            }

            $wrote = essb_novashare_migrate_post_details($post_id, $details, $force, $stats);
            if ($wrote) {
                $stats['posts_migrated']++;
            }

            // legacy separate recovery_urls row
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $legacy_ru = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->prefix}novashare_meta WHERE post_id = %d AND meta_key = 'recovery_urls' ORDER BY id DESC LIMIT 1",
                $post_id
            ));
            if (!empty($legacy_ru)) {
                $ru = essb_safe_unserialize($legacy_ru);
                if (is_array($ru) && !empty($ru)) {
                    if (!isset($details['recovery_urls']) || !is_array($details['recovery_urls'])) {
                        $details['recovery_urls'] = $ru;
                        if (essb_novashare_write_recovery_urls($post_id, $details['recovery_urls'], $force, $stats)) {
                            // counted inside helper via fields_written; mark post migrated
                            $stats['posts_migrated'] = $stats['posts_migrated']; // noop safety
                        }
                    }
                }
            }
        }

        // ---- attachment-level ----
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $attachment_ids = $wpdb->get_col(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key IN ('novashare_pin_title','novashare_pin_description','novashare_pin_repin_id','novashare_pin_nopin')"
        );

        foreach ($attachment_ids as $att_id) {
            $att_id = (int) $att_id;
            $stats['attachments_scanned']++;
            if (essb_novashare_migrate_attachment($att_id, $force, $stats)) {
                $stats['attachments_migrated']++;
            }
        }

        if (class_exists('ESSB_Plugin_Options')) {
            ESSB_Plugin_Options::set('essb_novashare_migrated', 'true');
            ESSB_Plugin_Options::save();
        }

        return $stats;
    }
}

if (!function_exists('essb_novashare_write_recovery_urls')) {
    function essb_novashare_write_recovery_urls($post_id, $urls, $force, &$stats) {
        $urls = array_values(array_unique(array_filter(array_map('esc_url_raw', (array) $urls))));
        if (empty($urls)) {
            return false;
        }
        $current = get_post_meta($post_id, 'essb_novashare_recovery_urls', true);
        if (!$force && $current !== '' && $current !== null && $current !== false) {
            return false;
        }
        update_post_meta($post_id, 'essb_novashare_recovery_urls', maybe_serialize($urls));
        $stats['fields_written']++;
        return true;
    }
}

if (!function_exists('essb_novashare_migrate_post_details')) {
    function essb_novashare_migrate_post_details($post_id, $details, $force, &$stats) {
        $wrote_any = false;

        $write_meta = function ($key, $value) use ($post_id, $force, &$stats, &$wrote_any) {
            if ($value === '' || $value === null || $value === false) {
                return;
            }
            $current = get_post_meta($post_id, $key, true);
            if (!$force && $current !== '' && $current !== null && $current !== false) {
                return;
            }
            update_post_meta($post_id, $key, $value);
            $stats['fields_written']++;
            $wrote_any = true;
        };

        // title
        if (!empty($details['social_title'])) {
            $t = sanitize_text_field($details['social_title']);
            $write_meta('essb_post_og_title', $t);
            $write_meta('essb_post_twitter_title', $t);
            $write_meta('essb_post_google_title', $t);
        }

        // description
        if (!empty($details['social_description'])) {
            $d = sanitize_textarea_field($details['social_description']);
            $write_meta('essb_post_og_desc', $d);
            $write_meta('essb_post_twitter_desc', $d);
            $write_meta('essb_post_google_desc', $d);
        }

        // social image (attachment ID -> URL)
        if (!empty($details['social_image'])) {
            $url = wp_get_attachment_url((int) $details['social_image']);
            if ($url) {
                $write_meta('essb_post_og_image', $url);
                $write_meta('essb_post_twitter_image', $url);
                $write_meta('essb_post_google_image', $url);
                $write_meta('essb_post_share_image', $url);
            }
        }

        // pinterest image
        if (!empty($details['pinterest_image'])) {
            $url = wp_get_attachment_url((int) $details['pinterest_image']);
            if ($url) {
                $write_meta('essb_post_pin_image', $url);
            }
        }

        // pinterest description
        if (!empty($details['pinterest_description'])) {
            $write_meta('essb_post_pin_desc', sanitize_textarea_field($details['pinterest_description']));
        }

        // pinterest hidden images (attachment IDs -> URLs)
        if (!empty($details['pinterest_hidden_images']) && is_array($details['pinterest_hidden_images'])) {
            $urls = array();
            foreach ($details['pinterest_hidden_images'] as $aid) {
                $u = wp_get_attachment_url((int) $aid);
                if ($u) {
                    $urls[] = $u;
                }
            }
            if (!empty($urls)) {
                $current = function_exists('essb_get_post_meta') ? essb_get_post_meta($post_id, 'pinterest_hidden') : get_post_meta($post_id, 'pinterest_hidden', true);
                if ($force || empty($current)) {
                    if (function_exists('essb_update_post_meta')) {
                        essb_update_post_meta($post_id, 'pinterest_hidden', $urls);
                    } else {
                        update_post_meta($post_id, 'pinterest_hidden', maybe_serialize($urls));
                    }
                    $stats['fields_written']++;
                    $wrote_any = true;
                }
            }
        }

        // hide flags
        $hide_inline   = !empty($details['hide_inline']) && $details['hide_inline'] === '1';
        $hide_floating = !empty($details['hide_floating']) && $details['hide_floating'] === '1';
        if ($hide_inline && $hide_floating) {
            $write_meta('essb_off', '1');
        } else {
            if ($hide_inline) {
                $write_meta('essb_novashare_hide_inline', '1');
            }
            if ($hide_floating) {
                $write_meta('essb_novashare_hide_floating', '1');
            }
        }

        if (!empty($details['disable_image_pins']) && $details['disable_image_pins'] === '1') {
            $write_meta('essb_novashare_disable_image_pins', '1');
        }
        if (!empty($details['disable_highlight']) && $details['disable_highlight'] === '1') {
            $write_meta('essb_novashare_disable_highlight', '1');
        }

        // recovery urls
        if (!empty($details['recovery_urls']) && is_array($details['recovery_urls'])) {
            if (essb_novashare_write_recovery_urls($post_id, $details['recovery_urls'], $force, $stats)) {
                $wrote_any = true;
            }
        }

        return $wrote_any;
    }
}

if (!function_exists('essb_novashare_migrate_attachment')) {
    function essb_novashare_migrate_attachment($att_id, $force, &$stats) {
        $map = array(
            'novashare_pin_title'       => 'essb_pin_title',
            'novashare_pin_description' => 'essb_pin_description',
            'novashare_pin_repin_id'    => 'essb_pin_id',
            'novashare_pin_nopin'       => 'essb_pin_nopin',
        );

        $wrote = false;
        foreach ($map as $from => $to) {
            $val = get_post_meta($att_id, $from, true);
            if ($val === '' || $val === null || $val === false) {
                continue;
            }

            if ($from === 'novashare_pin_title') {
                $val = mb_substr(sanitize_text_field($val), 0, 100);
            } elseif ($from === 'novashare_pin_description') {
                $val = sanitize_textarea_field($val);
            } elseif ($from === 'novashare_pin_repin_id') {
                $val = sanitize_text_field($val);
            } elseif ($from === 'novashare_pin_nopin') {
                if (!($val === '1' || $val === 1 || $val === true || $val === 'true')) {
                    continue; // only migrate an explicit "disable pinning" flag
                }
                $val = 'true';
            }

            $current = get_post_meta($att_id, $to, true);
            if (!$force && $current !== '' && $current !== null && $current !== false) {
                continue;
            }

            update_post_meta($att_id, $to, $val);
            $stats['attachment_fields_written']++;
            $wrote = true;
        }
        return $wrote;
    }
}

if (!function_exists('essb_data_migrate_novashare_clear')) {
    function essb_data_migrate_novashare_clear() {
        delete_option('essb_novashare_migrated');
        if (class_exists('ESSB_Plugin_Options')) {
            ESSB_Plugin_Options::set('essb_novashare_migrated', '');
            ESSB_Plugin_Options::save();
        }
    }
}
