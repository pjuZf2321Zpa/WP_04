<?php
/**
 * Easy Social Share Buttons - Tasty Pins data migration adapter.
 *
 * Migrates per-post Pinterest customizations (hidden images, default title/text,
 * force-pinning and banner-disable flags) and per-attachment Pinterest attributes
 * (title, description, repin ID) from a previous Tasty Pins install into ESSB.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('essb_tastypins_data_present')) {
    function essb_tastypins_data_present() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $v = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta}
             WHERE meta_key IN ('tp_pinterest_text','tp_pinterest_title','tp_pinterest_repin_id','tp_pinterest_hidden_image','tp_pinterest_default_title','tp_pinterest_default_text','tp_pinterest_force_pinning','tp_pinterest_disable_banner')"
        );
        return !is_wp_error($v) && (int) $v > 0;
    }
}

if (!function_exists('essb_data_migrate_tastypins')) {
    function essb_data_migrate_tastypins($force = false) {
        global $wpdb;

        $stats = array(
            'posts_scanned'             => 0,
            'posts_migrated'            => 0,
            'fields_written'            => 0,
            'attachments_scanned'       => 0,
            'attachments_migrated'      => 0,
            'attachment_fields_written' => 0,
            'errors'                    => array(),
        );

        wp_raise_memory_limit('admin');
        @set_time_limit(0);

        // ---- post-level ----
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $post_ids = $wpdb->get_col(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key IN ('tp_pinterest_hidden_image','tp_pinterest_default_title','tp_pinterest_default_text','tp_pinterest_force_pinning','tp_pinterest_disable_banner')"
        );

        foreach ($post_ids as $post_id) {
            $post_id = (int) $post_id;
            $stats['posts_scanned']++;

            $wrote = essb_tastypins_migrate_post($post_id, $force, $stats);
            if ($wrote) {
                $stats['posts_migrated']++;
            }
        }

        // ---- attachment-level ----
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $attachment_ids = $wpdb->get_col(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key IN ('tp_pinterest_text','tp_pinterest_title','tp_pinterest_repin_id')"
        );

        foreach ($attachment_ids as $att_id) {
            $att_id = (int) $att_id;
            $stats['attachments_scanned']++;
            if (essb_tastypins_migrate_attachment($att_id, $force, $stats)) {
                $stats['attachments_migrated']++;
            }
        }

        if (class_exists('ESSB_Plugin_Options')) {
            ESSB_Plugin_Options::set('essb_tastypins_migrated', 'true');
            ESSB_Plugin_Options::save();
        }

        return $stats;
    }
}

if (!function_exists('essb_tastypins_migrate_post')) {
    function essb_tastypins_migrate_post($post_id, $force, &$stats) {
        $wrote_any = false;

        $write_meta = function ($key, $value) use ($post_id, $force, &$stats, &$wrote_any) {
            if ($value === '' || $value === null || $value === false) {
                return;
            }
            $current = get_post_meta($post_id, $key, true);
            if (!$force && $current !== '' && $current !== null && $current !== false) {
                return;
            }
            update_post_meta($post_id, $key, $value);
            $stats['fields_written']++;
            $wrote_any = true;
        };

        // hidden images (attachment IDs -> URLs)
        $hidden = get_post_meta($post_id, 'tp_pinterest_hidden_image', true);
        if (!is_array($hidden)) {
            if ($hidden !== '' && $hidden !== null && $hidden !== false) {
                $hidden = array($hidden);
            } else {
                $hidden = array();
            }
        }
        if (!empty($hidden)) {
            $urls = array();
            foreach ($hidden as $aid) {
                $u = wp_get_attachment_url((int) $aid);
                if ($u) {
                    $urls[] = $u;
                }
            }
            if (!empty($urls)) {
                $current = function_exists('essb_get_post_meta') ? essb_get_post_meta($post_id, 'pinterest_hidden') : get_post_meta($post_id, 'pinterest_hidden', true);
                if ($force || empty($current)) {
                    if (function_exists('essb_update_post_meta')) {
                        essb_update_post_meta($post_id, 'pinterest_hidden', $urls);
                    } else {
                        update_post_meta($post_id, 'pinterest_hidden', maybe_serialize($urls));
                    }
                    $stats['fields_written']++;
                    $wrote_any = true;
                }
            }
        }

        // default title
        $dt = get_post_meta($post_id, 'tp_pinterest_default_title', true);
        if ($dt !== '' && $dt !== null && $dt !== false) {
            $write_meta('essb_post_pin_default_title', mb_substr(sanitize_text_field($dt), 0, 100));
        }

        // default text
        $dx = get_post_meta($post_id, 'tp_pinterest_default_text', true);
        if ($dx !== '' && $dx !== null && $dx !== false) {
            $write_meta('essb_post_pin_default_text', mb_substr(sanitize_textarea_field($dx), 0, 500));
        }

        // force pinning
        $fp = get_post_meta($post_id, 'tp_pinterest_force_pinning', true);
        if ($fp !== '' && $fp !== null && $fp !== false) {
            $write_meta('essb_tastypins_force_pinning', ($fp === '1' || $fp === 1 || $fp === true) ? '1' : '0');
        }

        // disable banner
        $db = get_post_meta($post_id, 'tp_pinterest_disable_banner', true);
        if ($db !== '' && $db !== null && $db !== false) {
            $write_meta('essb_tastypins_disable_banner', ($db === '1' || $db === 1 || $db === true) ? '1' : '0');
        }

        return $wrote_any;
    }
}

if (!function_exists('essb_tastypins_migrate_attachment')) {
    function essb_tastypins_migrate_attachment($att_id, $force, &$stats) {
        $map = array(
            'tp_pinterest_title'  => 'essb_pin_title',
            'tp_pinterest_text'   => 'essb_pin_description',
            'tp_pinterest_repin_id' => 'essb_pin_id',
        );

        $wrote = false;
        foreach ($map as $from => $to) {
            $val = get_post_meta($att_id, $from, true);
            if ($val === '' || $val === null || $val === false) {
                continue;
            }

            if ($from === 'tp_pinterest_title') {
                $val = mb_substr(sanitize_text_field($val), 0, 100);
            } elseif ($from === 'tp_pinterest_text') {
                $val = sanitize_textarea_field($val);
            } else {
                $val = sanitize_text_field($val);
            }

            $current = get_post_meta($att_id, $to, true);
            if (!$force && $current !== '' && $current !== null && $current !== false) {
                continue;
            }

            update_post_meta($att_id, $to, $val);
            $stats['attachment_fields_written']++;
            $wrote = true;
        }
        return $wrote;
    }
}

if (!function_exists('essb_data_migrate_tastypins_clear')) {
    function essb_data_migrate_tastypins_clear() {
        delete_option('essb_tastypins_migrated');
        if (class_exists('ESSB_Plugin_Options')) {
            ESSB_Plugin_Options::set('essb_tastypins_migrated', '');
            ESSB_Plugin_Options::save();
        }
    }
}
