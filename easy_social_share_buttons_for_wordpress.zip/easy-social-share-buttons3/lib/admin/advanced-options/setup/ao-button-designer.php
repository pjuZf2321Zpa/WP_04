<?php
/**
 * Create and manage new share buttons 
 */

$loadingOptions = isset($_REQUEST['loadingOptions']) ? $_REQUEST['loadingOptions'] : array();
$network = isset($loadingOptions['network']) ? $loadingOptions['network'] : '';
$network_setup = array();

if ($network != '') {
	$network_setup = essb_get_custom_button_settings($network);
	
	if (isset($network_setup['icon'])) {
		$network_setup['icon'] = base64_decode($network_setup['icon']);
	}
}

if (function_exists('essb_advancedopts_settings_group')) {
	essb_advancedopts_settings_group('essb_options_custom_networks');
}

echo '<input type="hidden" name="network_button_id" id="network_button_id" value="'.esc_attr($network).'"/>';

/**
 * Button parameters
 */

$button = '<br/><span class="ao-new-subscribe-design ao-import-svg-icon" data-for="essb_options_icon" data-picker="ao-svg-file"><span class="essb_icon fa fa-upload"></span><span>Upload</span></span>';
$button .= '<input type="file" name="ao-svg-file" id="ao-svg-file" class="ao-hidden" accept=".svg"/>';

essb5_draw_input_option('network_id', esc_html__('Network ID', 'essb'), esc_html__('Fill a custom unique ID for the network button. Use only lowercase Latin symbols (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb'), true, true, essb_array_value('network_id', $network_setup));
essb5_draw_input_option('name', esc_html__('Name', 'essb'), esc_html__('The name of the button. This will be the text you will see in the list of networks. It will also be the text that will appear when you add a button initially. Try to keep it short.', 'essb'), true, true, essb_array_value('name', $network_setup));
essb5_draw_input_option('url', esc_html__('Button URL', 'essb'), esc_html__('The URL can be a share command or a regular link to direct visitors; if using a share command, include the appropriate variables such as %%title%%, %%image%%, %%permalink%%, %%description%%, and %%siteurl%%.', 'essb'), true, true, essb_array_value('url', $network_setup));
essb5_draw_switch_option('counter', esc_html__('Enable internal share counter', 'essb'), esc_html__('Enables support for the internal share counter; to display it on your site, ensure the internal counter option is active in Share Counter Setup and that your selected design includes share values.', 'essb'), true, essb_array_value('counter', $network_setup));

essb5_draw_editor_option('icon', esc_html__('SVG Icon', 'essb'), esc_html__('Place the content of an SVG icon that will be used to show the buttons. To do this prepare a flat color SVG icon (or download such from a collection). Open that file with a text editor and copy content inside the field.', 'essb') . $button, 'htmlmixed', true, essb_array_value('icon', $network_setup));
essb5_draw_input_option('padding_top', esc_html__('Icon top padding', 'essb'), esc_html__('Correct the default value of padding for the icon. Numeric values only. The current default value is 10 (when nothing filled).', 'essb'), true, true, essb_array_value('padding_top', $network_setup));
essb5_draw_input_option('padding_left', esc_html__('Icon left padding', 'essb'), esc_html__('Correct the default value of padding for the icon. Numeric values only. The current default value is 8 (when nothing filled).', 'essb'), true, true, essb_array_value('padding_left', $network_setup));
essb5_draw_color_option('network_color', esc_html__('Network color', 'essb'), esc_html__('Fill out the network primary color to integrate within the default share button templates. In this case there is no need to fill the color fields below. The additional colors can be used if you wish the button styles be the same no matter of template you are using.', 'essb'), false, true, essb_array_value('network_color', $network_setup));

essb5_draw_heading(esc_html__('Colors', 'essb'), '5');
essb5_draw_color_option('bgcolor', esc_html__('Background color', 'essb'), '', false, true, essb_array_value('bgcolor', $network_setup));
essb5_draw_color_option('iconcolor', esc_html__('Icon color', 'essb'), '', false, true, essb_array_value('iconcolor', $network_setup));
essb5_draw_color_option('textcolor', esc_html__('Text color', 'essb'), '', false, true, essb_array_value('textcolor', $network_setup));

essb5_draw_heading(esc_html__('Colors on Hover', 'essb'), '5');
essb5_draw_color_option('bgcolor_hover', esc_html__('Background color', 'essb'), '', false, true, essb_array_value('bgcolor_hover', $network_setup));
essb5_draw_color_option('iconcolor_hover', esc_html__('Icon color', 'essb'), '', false, true, essb_array_value('iconcolor_hover', $network_setup));
essb5_draw_color_option('textcolor_hover', esc_html__('Text color', 'essb'), '', false, true, essb_array_value('textcolor_hover', $network_setup));