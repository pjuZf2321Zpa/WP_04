<?php
if (function_exists('essb_advancedopts_settings_group')) {
	essb_advancedopts_settings_group('essb_options');
}

// Shared add-on rendering helpers — icon, states and styles used by both the
// Add-Ons screen and the Add-Ons tab of this panel.
include_once ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/ui-addons.php';

function ao_generate_feature_badge($text = '', $type = '')
{
	$badge_class = 'essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline' . ($type != '' ? ' essb-ui-badge-' . $type : '');
	return '<span class="' . $badge_class . '">' . $text . '</span>';
}

function ao_generate_feature_group_panel_no_icon($title = '', $desc = '', $field = '', $deactivate_mode = false)
{
	$state = '';
	$field_value = essb_option_bool_value($field);
	$deactivation_tag = $deactivate_mode ? 'deactivation' : '';
	$value = '';

	if ($deactivate_mode) {
		if (!$field_value) {
			$state = 'active';
			$value = '';
		} else {
			$state = '';
			$value = 'true';
		}
	} else {
		if (!$field_value) {
			$state = '';
			$value = '';
		} else {
			$state = 'active';
			$value = 'true';
		}
	}

?>
	<div class="essb-ui-card-content essb-activate-additional-feature <?php echo esc_attr($state); ?> essb-activate-additional-feature-<?php echo $field; ?>" data-type="<?php echo esc_attr($deactivation_tag); ?>">
		<input type="hidden" name="essb_options[<?php echo esc_attr($field); ?>]" id="essb_<?php echo esc_attr($field); ?>" class="feature-value" value="<?php echo esc_attr($value); ?>" />

		<div class="essb-ui-flex essb-ui-flex100 essb-ui-align-center essb-ui-justify-between essb-ui-gap-4">

			<div class="essb-ui-flex essb-ui-align-center essb-ui-gap-4">

				<div class="essb-ui-flex essb-ui-flex-col essb-ui-gap-1.5">
					<div class="essb-ui-font-semibold essb-ui-line-height-sm essb-ui-text-lg essb-ui-flex essb-ui-align-center essb-ui-gap-1.5"><?php echo $title; ?></div>
					<?php if ($desc != '') { ?>
						<div class=" essb-ui-line-height-base"><?php echo $desc; ?></div>
					<?php } ?>

				</div>
			</div>

			<div class="essb-ui-flex essb-ui-align-center essb-ui-gap-2.5">
				<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-activation-status-notactive">Not active</span>
				<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary essb-activation-status-active">Active</span>
				<span class="essb-ui-switch essb-ui-switch-xl">
					<input class="essb-ui-switch-check" data-field="<?php echo $field; ?>" id="essb_ui_switch_<?php echo $field; ?>" type="checkbox" value="1" <?php if ($state == 'active') { ?>checked="checked" <?php } ?>>
				</span>
			</div>
		</div>

	</div>

<?php
}

function ao_generate_feature_panel_addon_module($title = '', $desc = '', $icon = '', $checks = array(), $link_url = '', $link_text = '', $install_slug = '')
{
	$state = '';

	$is_running = false;

	foreach ($checks as $check) {
		$check_param = isset($check['param']) ? $check['param'] : '';
		$check_type = isset($check['type']) ? $check['type'] : '';

		if (!empty($check_type) && !empty($check_param)) {
			if ($check_type == 'param') {
				if (defined($check_param)) {
					$is_running = true;
				}
			}
			if ($check_type == 'function') {
				if (function_exists($check_param)) {
					$is_running = true;
				}
			}
			if ($check_type == 'class') {
				if (class_exists($check_param)) {
					$is_running = true;
				}
			}
		}
	}

	if ($is_running) {
		$state = 'active';
	}

	if (empty($link_text)) {
		$link_text = esc_html__('Learn more', 'essb');
	}

?>
	<div class="essb-ui-card essb-ui-mb3 essb-activate-additional-feature <?php echo esc_attr($state); ?>">
		<div class="essb-ui-card-content">

			<div class="essb-ui-flex essb-ui-flex100 essb-ui-align-center essb-ui-justify-between essb-ui-gap-4">

				<div class="essb-ui-flex essb-ui-align-center essb-ui-gap-4">

					<div class="essb-ui-icon-frame64">
						<svg class="essb-ui-svg-frame essb-ui-svg-frame-grey" fill="none" height="48" viewBox="0 0 44 48" width="44" xmlns="http://www.w3.org/2000/svg">
							<path d="M16 2.4641C19.7128 0.320509 24.2872 0.320508 28 2.4641L37.6506 8.0359C41.3634 10.1795 43.6506 14.141 43.6506 
			18.4282V29.5718C43.6506 33.859 41.3634 37.8205 37.6506 39.9641L28 45.5359C24.2872 47.6795 19.7128 47.6795 16 45.5359L6.34937 
			39.9641C2.63655 37.8205 0.349365 33.859 0.349365 29.5718V18.4282C0.349365 14.141 2.63655 10.1795 6.34937 8.0359L16 2.4641Z" fill="">
							</path>
							<path d="M16.25 2.89711C19.8081 0.842838 24.1919 0.842837 27.75 2.89711L37.4006 8.46891C40.9587 10.5232 43.1506 14.3196 43.1506 
			18.4282V29.5718C43.1506 33.6804 40.9587 37.4768 37.4006 39.5311L27.75 45.1029C24.1919 47.1572 19.8081 47.1572 16.25 45.1029L6.59937 
			39.5311C3.04125 37.4768 0.849365 33.6803 0.849365 29.5718V18.4282C0.849365 14.3196 3.04125 10.5232 6.59937 8.46891L16.25 2.89711Z" stroke="">
							</path>
						</svg>
						<i class="essb-ui-svg-icon essb-ui-svg-dark-icon">
							<?php echo essb_ui_get_svg_icon($icon); ?>
						</i>
					</div>

					<div class="essb-ui-flex essb-ui-flex-col essb-ui-gap-1.5">
						<div class="essb-ui-font-semibold essb-ui-line-height-sm essb-ui-text-lg essb-ui-flex essb-ui-align-center essb-ui-gap-1.5"><?php echo $title; ?></div>
						<div class="essb-ui-line-height-base"><?php echo $desc; ?></div>
						<?php
						if (!empty($link_url)) {
							echo '<div class="essb-ui-line-height-base"><a class="essb-ui-btn essb-ui-btn-link" href="' . esc_url($link_url) . '" target="_blank">' . $link_text . '</a></div>';
						}
						if ($state != 'active' && !empty($install_slug)) {
							$addon_state = essb_addon_get_state($install_slug);
							$btn_text = ($addon_state === 'installed') ? esc_html__('Activate', 'essb') : esc_html__('Install', 'essb');
							$install_nonce = wp_create_nonce('essb_install_free_addon');
							echo '<div><button type="button" class="essb-ui-btn essb-ui-btn-link" data-install="' . esc_attr($install_slug) . '" data-install-nonce="' . esc_attr($install_nonce) . '">' . $btn_text . '</button></div>';
						} elseif ($state != 'active') {
							echo '<div><span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-activation-status-notactive">Install and activate from the Add-Ons tab</span></div>';
						}
						?>
					</div>
				</div>

				<div class="essb-ui-flex essb-ui-align-center essb-ui-gap-2.5">
					<?php if ($state == 'active') { ?>
						<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary essb-activation-status-active">Active</span>
					<?php } else { ?>
						<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-activation-status-notactive">Not active</span>
						<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary essb-activation-status-active" style="display:none;">Active</span>
					<?php } ?>
				</div>
			</div>

		</div>
	</div>
<?php
}

/**
 * Render one add-on as a horizontal row.
 *
 * The row mirrors the add-on cards of the Add-Ons screen
 * (lib/admin/settings/essb-structure5-addons.php) — same hexagon icon, same
 * chips, same notices, same badges and buttons — but keeps a single add-on
 * per row as this list requires.
 *
 * @param string $key             Add-on slug.
 * @param array  $data            Add-on data.
 * @param array  $current_plugins Installed plugins lookup.
 * @param string $redirect_url    URL used after activate/deactivate.
 */
function ao_render_addon_row($key, $data, $current_plugins, $redirect_url = '')
{
	$state       = essb_addons_resolve_state($key, $data, $current_plugins, $redirect_url);
	$is_featured = !empty($data['featured']);
	$is_active   = $state['active'];
	$not_compat  = $state['not_compatible'];
	$pro_running = $state['pro_running'];

	$name = isset($data['name'])        ? $data['name']        : $key;
	$desc = isset($data['description']) ? $data['description'] : '';
	$cat  = isset($data['category'])    ? trim($data['category']) : '';
	$docs = isset($data['docs'])        ? $data['docs']        : '';
	$page = isset($data['page'])        ? $data['page']        : '';

	$remote_version = $state['remote_version'];
	$has_update     = $state['has_update'];

	// ---- Row classes ----
	$row_classes = array('essb-al-row');
	if ($is_featured) $row_classes[] = 'essb-al-row-featured';
	if ($is_active)   $row_classes[] = 'essb-al-row-active';
	if ($not_compat)  $row_classes[] = 'essb-al-row-incompatible';

	$cat_attr = $cat !== '' ? ' data-addon-category="' . esc_attr(strtolower($cat)) . '"' : '';
	?>
	<div class="<?php echo implode(' ', $row_classes); ?>"<?php echo $cat_attr; ?>>

		<!-- Icon -->
		<div class="essb-al-icon-col">
			<?php essb_addons_render_icon($data); ?>
		</div>

		<!-- Content -->
		<div class="essb-al-content-col">

			<!-- Title row: name + category chip + version chip + featured badge -->
			<div class="essb-al-title-row">
				<span class="essb-al-title"><?php echo esc_html($name); ?></span>

				<?php if ($cat !== '') : ?>
					<span class="essb-addons-chip"><?php echo esc_html($cat); ?></span>
				<?php endif; ?>

				<?php if (!empty($remote_version)) : ?>
					<span class="essb-addons-chip essb-addons-chip-version">v<?php echo esc_html($remote_version); ?></span>
				<?php endif; ?>

				<?php if ($is_featured) : ?>
					<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-ui-badge-info"><?php esc_html_e('Featured', 'essb'); ?></span>
				<?php endif; ?>
			</div>

			<?php if (!empty($desc)) : ?>
				<p class="essb-al-desc"><?php echo esc_html($desc); ?></p>
			<?php endif; ?>

			<?php if ($has_update || $not_compat) : ?>
				<div class="essb-al-notices">

					<?php if ($has_update) : ?>
						<div class="essb-addons-notice essb-addons-notice-update">
							<svg viewBox="0 0 20 20">
								<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3a1 1 0 102 0V7zm-1 8a1.25 1.25 0 100-2.5A1.25 1.25 0 0010 15z" clip-rule="evenodd" />
							</svg>
							<?php echo sprintf(
								esc_html__('Update available: %1$s → %2$s', 'essb'),
								esc_html($state['installed_version']),
								esc_html($remote_version)
							); ?>
						</div>
					<?php endif; ?>

					<?php if ($not_compat && !$pro_running) : ?>
						<div class="essb-addons-notice essb-addons-notice-error">
							<svg viewBox="0 0 20 20">
								<path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
							</svg>
							<?php echo sprintf(esc_html__('Requires version %s', 'essb'), esc_html($state['requires'])); ?>
						</div>
					<?php endif; ?>

					<?php if ($not_compat && $pro_running) : ?>
						<div class="essb-addons-notice essb-addons-notice-error">
							<svg viewBox="0 0 20 20">
								<path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
							</svg>
							<?php esc_html_e('Pro version is currently active.', 'essb'); ?>
						</div>
					<?php endif; ?>

				</div>
			<?php endif; ?>

			<?php if (!empty($docs) || !empty($page)) : ?>
				<div class="essb-al-links">
					<?php if (!empty($docs)) : ?>
						<a href="<?php echo esc_url($docs); ?>" target="_blank" rel="noopener noreferrer" class="essb-ui-btn essb-ui-btn-link"><?php esc_html_e('Documentation', 'essb'); ?></a>
					<?php endif; ?>

					<?php if (!empty($page)) : ?>
						<a href="<?php echo esc_url($page); ?>" target="_blank" rel="noopener noreferrer" class="essb-ui-btn essb-ui-btn-link"><?php esc_html_e('Learn more', 'essb'); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

		</div><!-- /content col -->

		<!-- Divider -->
		<div class="essb-al-divider"></div>

		<!-- Action -->
		<div class="essb-al-action-col">

			<div class="essb-al-badges">
				<?php if ($is_active) : ?>
					<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary"><?php esc_html_e('Active', 'essb'); ?></span>
				<?php endif; ?>

				<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-ui-badge-success"><?php esc_html_e('Free', 'essb'); ?></span>
			</div>

			<?php if (!$not_compat) : ?>

				<?php if ($has_update) : ?>

					<?php $update_label = $is_active
						? esc_html__('Update & Activate', 'essb')
						: esc_html__('Update', 'essb'); ?>

					<a class="essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm essb-addon-update-btn" href="<?php echo esc_url($state['update_url']); ?>"><?php echo $update_label; ?></a>

				<?php else : ?>

					<?php
					$action_class = 'essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm';
					if ('button-deactivate' === $state['command_class']) {
						$action_class .= ' essb-al-btn-deactivate';
					}
					?>

					<a class="<?php echo esc_attr($action_class); ?>" href="<?php echo esc_url($state['url_command']); ?>"><?php echo esc_html($state['command_text']); ?></a>

				<?php endif; ?>

			<?php endif; ?>

		</div><!-- /action col -->

	</div><!-- /row -->
<?php
}


function ao_generate_feature_panel($title = '', $desc = '', $icon = '', $field = '', $deactivate_mode = false, $link_url = '', $link_text = '')
{
	$state = '';
	$field_value = essb_option_bool_value($field);
	$deactivation_tag = $deactivate_mode ? 'deactivation' : '';
	$value = '';

	if ($deactivate_mode) {
		if (!$field_value) {
			$state = 'active';
			$value = '';
		} else {
			$state = '';
			$value = 'true';
		}
	} else {
		if (!$field_value) {
			$state = '';
			$value = '';
		} else {
			$state = 'active';
			$value = 'true';
		}
	}

	if (empty($link_text)) {
		$link_text = esc_html__('Learn more', 'essb');
	}

?>
	<div class="essb-ui-card essb-ui-mb3 essb-activate-additional-feature <?php echo esc_attr($state); ?> essb-activate-additional-feature-<?php echo $field; ?>" data-type="<?php echo esc_attr($deactivation_tag); ?>">
		<input type="hidden" name="essb_options[<?php echo esc_attr($field); ?>]" id="essb_<?php echo esc_attr($field); ?>" class="feature-value" value="<?php echo esc_attr($value); ?>" />
		<div class="essb-ui-card-content">

			<div class="essb-ui-flex essb-ui-flex100 essb-ui-align-center essb-ui-justify-between essb-ui-gap-4">

				<div class="essb-ui-flex essb-ui-align-center essb-ui-gap-4">

					<div class="essb-ui-icon-frame64">
						<svg class="essb-ui-svg-frame essb-ui-svg-frame-grey" fill="none" height="48" viewBox="0 0 44 48" width="44" xmlns="http://www.w3.org/2000/svg">
							<path d="M16 2.4641C19.7128 0.320509 24.2872 0.320508 28 2.4641L37.6506 8.0359C41.3634 10.1795 43.6506 14.141 43.6506 
			18.4282V29.5718C43.6506 33.859 41.3634 37.8205 37.6506 39.9641L28 45.5359C24.2872 47.6795 19.7128 47.6795 16 45.5359L6.34937 
			39.9641C2.63655 37.8205 0.349365 33.859 0.349365 29.5718V18.4282C0.349365 14.141 2.63655 10.1795 6.34937 8.0359L16 2.4641Z" fill="">
							</path>
							<path d="M16.25 2.89711C19.8081 0.842838 24.1919 0.842837 27.75 2.89711L37.4006 8.46891C40.9587 10.5232 43.1506 14.3196 43.1506 
			18.4282V29.5718C43.1506 33.6804 40.9587 37.4768 37.4006 39.5311L27.75 45.1029C24.1919 47.1572 19.8081 47.1572 16.25 45.1029L6.59937 
			39.5311C3.04125 37.4768 0.849365 33.6803 0.849365 29.5718V18.4282C0.849365 14.3196 3.04125 10.5232 6.59937 8.46891L16.25 2.89711Z" stroke="">
							</path>
						</svg>
						<i class="essb-ui-svg-icon essb-ui-svg-dark-icon">
							<?php echo essb_ui_get_svg_icon($icon); ?>
						</i>
					</div>

					<div class="essb-ui-flex essb-ui-flex-col essb-ui-gap-1.5">
						<div class="essb-ui-font-semibold essb-ui-line-height-sm essb-ui-text-lg essb-ui-flex essb-ui-align-center essb-ui-gap-1.5"><?php echo $title; ?></div>
						<div class="essb-ui-line-height-base"><?php echo $desc; ?></div>
						<?php
						if (!empty($link_url)) {
							echo '<div class="essb-ui-line-height-base"><a class="essb-ui-btn essb-ui-btn-link" href="' . esc_url($link_url) . '" target="_blank">' . $link_text . '</a></div>';
						}
						?>
					</div>
				</div>

				<div class="essb-ui-flex essb-ui-align-center essb-ui-gap-2.5">
					<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-activation-status-notactive">Not active</span>
					<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary essb-activation-status-active">Active</span>
					<span class="essb-ui-switch essb-ui-switch-xl">
						<input class="essb-ui-switch-check" data-field="<?php echo $field; ?>" id="essb_ui_switch_<?php echo $field; ?>" type="checkbox" value="1" <?php if ($state == 'active') { ?>checked="checked" <?php } ?>>
					</span>
				</div>
			</div>

		</div>
	</div>
<?php
}


function ao_generate_feature_block($title = '', $desc = '', $icon = '', $field = '', $deactivate_mode = false)
{

	$state = '';
	$field_value = essb_option_bool_value($field);
	$deactivation_tag = $deactivate_mode ? 'deactivation' : '';
	$value = '';

	if ($deactivate_mode) {
		if (!$field_value) {
			$state = 'active';
			$value = '';
		} else {
			$state = '';
			$value = 'true';
		}
	} else {
		if (!$field_value) {
			$state = '';
			$value = '';
		} else {
			$state = 'active';
			$value = 'true';
		}
	}

?>
	<div class="single-feature <?php echo esc_attr($state); ?>" data-type="<?php echo esc_attr($deactivation_tag); ?>">
		<input type="hidden" name="essb_options[<?php echo esc_attr($field); ?>]" id="essb_<?php echo esc_attr($field); ?>" class="feature-value" value="<?php echo esc_attr($value); ?>" />
		<div class="header"><span class="tag tag-active">Active</span><span class="tag tag-notactive">Not Active</span></div>
		<i class="feature-icon <?php echo esc_attr($icon); ?>"></i>
		<h3><?php echo $title; ?></h3>
		<div class="desc"><?php echo $desc; ?></div>
		<div class="buttons">
			<a href="#" class="activate-btn feature-btn essb-btn"><i class="fa fa-check"></i>Activate</a><a href="#" class="deactivate-btn feature-btn essb-btn"><i class="fa fa-close"></i>Deactivate</a>
		</div>
	</div>
<?php
}

?>
<div class="features-container">
	<div class="navigation">
		<div class="navigation-menu">
			<a href="#" data-tab="sharing">Share Features <span class="small-tag essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">5/10</span></a>
			<a href="#" data-tab="display" <?php if (essb_option_value('css_mode') == 'light') { ?> style="display: none;" <?php } ?>>Share Display Methods <span class="small-tag essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">2/12</span></a>
			<a href="#" data-tab="social">Social Features <span class="small-tag essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">2/12</span></a>
			<a href="#" data-tab="advanced">Advanced Features <span class="small-tag essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">2/12</span></a>
			<a href="#" data-tab="addons">Add-Ons</a>
		</div>
	</div>
	<div class="content">
		<div class="content-tab tab-sharing">
			<div class="features-manage essb-ui-flex essb-ui-flex-col essb-ui-pt4 essb-ui-pb4">
				<?php
				ao_generate_feature_panel(
					esc_html__('Pinterest Pro', 'essb'),
					esc_html__('The Pinterest Pro feature in Easy Social Share Buttons adds hover-activated "Pin" buttons to images, allowing customization of positioning, text, and size criteria. It supports lazy-loaded images, page builders, grid-based sharing, hidden image sharing, and a Pinterest follow box.', 'essb'),
					'pinterest',
					'deactivate_module_pinterestpro',
					true,
					'https://socialsharingplugin.com/pinterest-pro-image-hover-pins/'
				);
				ao_generate_feature_panel(esc_html__('Sharable Quotes', 'essb'), esc_html__('Effortlessly boost X (formerly Twitter) shares with beautifully designed click-to-share quotes—no coding needed', 'essb'), 'twitter_x', 'deactivate_ctt', true, 'https://socialsharingplugin.com/click-to-tweet/');
ao_generate_feature_panel(esc_html__('Highlight Share', 'essb'), esc_html__('Show a floating share bar over text visitors highlight, supporting multiple networks.', 'essb'), 'share_events', 'deactivate_highlight_share', true);
				ao_generate_feature_panel(esc_html__('WooCommerce', 'essb'), esc_html__('Unlock additional WooCommerce display methods and seamless integrations to maximize your store\'s social sharing potential.', 'essb'), 'cart', 'deactivate_method_woocommerce', true, 'https://socialsharingplugin.com/woocommerce-social-sharing/');
				ao_generate_feature_panel(esc_html__('Share Optimizations', 'essb'), esc_html__('Add social share optimization tags for precise control over shared content.', 'essb'), 'share_optimization', 'deactivate_module_shareoptimize', true);
				ao_generate_feature_panel(esc_html__('Share Counters', 'essb'), esc_html__('Include functions to update and display the share counters. When turned off, it will also disable additional functions that use share values, such as Fake Share Counters, Avoid Negative Social Proof, Share Counter Recovery, etc', 'essb'), 'numbers', 'deactivate_share_counters', true);
				ao_generate_feature_panel(esc_html__('Internal Share Counters', 'essb'), esc_html__('The internal share counters are stored locally in the database and generated with each click on a share button. You can use those internal counters for all social networks that do not have API for reading shares. You can also converge the networks with API to track shares locally in the database.', 'essb'), 'database_reload', 'deactivate_postcount', true);
				ao_generate_feature_panel(esc_html__('Avoid Negative Social Proof', 'essb'), esc_html__('Hide social share counters until they reach a specified number of shares.', 'essb'), 'shield', 'deactivate_ansp', true);
				ao_generate_feature_panel(esc_html__('Social Shares Recovery', 'essb'), esc_html__('Recover number of shares from specific URL changes', 'essb'), 'data_recovery', 'deactivate_ssr', true);
				ao_generate_feature_panel(esc_html__('Fake Share Counters', 'essb'), esc_html__('Fake share counters let you boost numbers with a multiplier. Additionally, you can set custom values as internal counters across all networks.', 'essb'), 'fake_counter', 'deactivate_fakecounters', true);
				ao_generate_feature_panel(esc_html__('Plugin Analytics', 'essb'), esc_html__('Track social sharing performance with privacy-safe analytics for WordPress. Gain real-time insights to optimize buttons and forms effortlessly, enhancing engagement while respecting user privacy.', 'essb'), 'analytics', 'deactivate_module_analytics', true, 'https://socialsharingplugin.com/social-sharing/advanced-privacy-safe-analytics-for-wordpress-share-buttons/');
				ao_generate_feature_panel_addon_module(esc_html__('Shorty - Self Hosted Short URLs', 'essb'), esc_html__('Shorty is a powerful add-on for Easy Social Share Buttons that allows you to create, manage, and track your own self-hosted short URLs directly on your WordPress website. No more dependency on third-party services like bit.ly, rebrandly.com or tinyurl.com.', 'essb'), 'short_url', array(array('param' => 'SHORTY_VERSION', 'type' => 'param')), 'https://socialsharingplugin.com/addons/shorty-self-hosted-shorturls/', '', 'shorty');
				ao_generate_feature_panel(esc_html__('Short URL', 'essb'), esc_html__('Generate short URLs for sharing on social networks', 'essb'), 'short_url', 'deactivate_module_shorturl', true);
				ao_generate_feature_panel(esc_html__('Expert Share Counter Options', 'essb') . ao_generate_feature_badge('Expert', 'info'), esc_html__('Include expert level share counter update options for fine-tuning of the values and the update process.', 'essb'), 'options', 'deactivate_expertcounters', true);
				ao_generate_feature_panel(esc_html__('After Share Actions', 'essb'), esc_html__('Enhance user engagement by implementing after-share actions with Easy Social Share Buttons for WordPress. This feature allows you to present native social follow buttons, subscription forms, or custom messages immediately after a user shares your content, encouraging further interaction and fostering a deeper connection with your audience.', 'essb'), 'share_events', 'deactivate_module_aftershare', true, 'https://socialsharingplugin.com/after-share-actions-for-share-buttons/?aftershare=follow_profile');
				ao_generate_feature_panel(esc_html__('Google Analytics Tracking', 'essb'), esc_html__('Generate UTM tracking code to the outgoing shared URLs or track events of sharing in Google Analytics.', 'essb'), 'google_analytics', 'deactivate_module_google_analytics', true);
				ao_generate_feature_panel(esc_html__('Affiliate & Point Integration', 'essb'), esc_html__('Integrate plugin work with myCred, AffiliateWP, SliceWP', 'essb'), 'affiliate', 'deactivate_module_affiliate', true);
				ao_generate_feature_panel(esc_html__('Message Before Buttons', 'essb'), esc_html__('Add a custom message before or above share buttons "ex: Share this"', 'essb'), 'custom_share', 'deactivate_module_message', true);
				ao_generate_feature_panel(esc_html__('Custom Share', 'essb'), esc_html__('Custom share feature makes possible to change the share URL that plugin will use', 'essb'), 'custom_share', 'deactivate_module_customshare', true);
				?>
			</div>

		</div>
		<div class="content-tab tab-display">
			<div class="features-manage essb-ui-flex essb-ui-flex-col essb-ui-pt4 essb-ui-pb4">
				<div class="essb-ui-card essb-ui-card-group">
					<?php
					ao_generate_feature_group_panel_no_icon(esc_html__('Sidebar', 'essb'), '', 'deactivate_method_sidebar', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Float From Above The Content', 'essb'), '', 'deactivate_method_float', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Post Vertical Float', 'essb'), '', 'deactivate_method_postfloat', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Top Bar', 'essb'), '', 'deactivate_method_topbar', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Bottom Bar', 'essb'), '', 'deactivate_method_bottombar', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Pop Up', 'essb'), '', 'deactivate_method_popup', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Fly In', 'essb'), '', 'deactivate_method_flyin', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Hero Share', 'essb'), '', 'deactivate_method_heroshare', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Post Bar', 'essb'), '', 'deactivate_method_postbar', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Point', 'essb'), '', 'deactivate_method_point', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('On Media', 'essb'), '', 'deactivate_method_image', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Follow Me Bar', 'essb'), '', 'deactivate_method_followme', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Corner Share', 'essb'), '', 'deactivate_method_corner', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Share Booster', 'essb'), '', 'deactivate_method_booster', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Share Button', 'essb'), '', 'deactivate_method_sharebutton', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Excerpt', 'essb'), '', 'deactivate_method_except', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Widget', 'essb'), '', 'deactivate_method_widget', true);
					ao_generate_feature_group_panel_no_icon(esc_html__('Advanced Mobile Options', 'essb'), '', 'deactivate_method_advanced_mobile', true);
					?>
				</div>
			</div>


		</div>
		<div class="content-tab tab-social">
			<div class="features-manage essb-ui-flex essb-ui-flex-col essb-ui-pt4 essb-ui-pb4">
				<?php
				ao_generate_feature_panel_addon_module(esc_html__('Link in Bio Pages & Social Profile Cards Builder', 'essb'), esc_html__('Social Profile Card Studio turns your bio link into a branded page - and works as a card anywhere on your site. 72 presets, a smart style generator and scheduled blocks and more.', 'essb'), 'profile_card', array(array('param' => 'SPCAD_VERSION', 'type' => 'param')), 'https://socialsharingplugin.com/social-profile-card-studio/', '', 'social-profile-card-studio');
				ao_generate_feature_panel(esc_html__('Social Followers Counter', 'essb'), esc_html__('Show the number of followers for 30+ social networks', 'essb'), 'heart', 'deactivate_module_followers', true, 'https://socialsharingplugin.com/social-followers-counter/');
				ao_generate_feature_panel(esc_html__('Social Profile Links', 'essb'), esc_html__('Add plain buttons for your social profiles with shortcode, widget or sidebar', 'essb'), 'user_heart', 'deactivate_module_profiles', true, 'https://socialsharingplugin.com/social-profiles/');
				ao_generate_feature_panel(esc_html__('Subscribe Forms', 'essb'), esc_html__('Add easy to use subscribe to mail list forms', 'essb'), 'mail', 'deactivate_module_subscribe', true, 'https://socialsharingplugin.com/grow-your-mailing-list-subscribers/');
				ao_generate_feature_panel_addon_module(esc_html__('Social Chat', 'essb'), esc_html__('Add WhatsApp, Telegram, Viber, Signal, Line, and more chat buttons to your site.', 'essb'), 'chat', array(array('param' => 'ESSC_VERSION', 'type' => 'param')), 'https://socialsharingplugin.com/social-chat/', '', 'social-chat');
				ao_generate_feature_panel_addon_module(esc_html__('Social Contact', 'essb'), esc_html__('Add social contact buttons to your site - WhatsApp, Viber, Telegram, Line, Signal, SMS, iMessage, Phone and Email.', 'essb'), 'contact', array(array('param' => 'ESSB_SC_VERSION', 'type' => 'param')), 'https://socialsharingplugin.com/social-contact/', '', 'essb-social-contact');
				ao_generate_feature_panel(esc_html__('Instagram Feed', 'essb'), esc_html__('Enable generation of Instagram feed on site', 'essb'), 'instagram', 'deactivate_module_instagram', true, 'https://socialsharingplugin.com/instagram-feed-grow-your-instagram-followers/');
				ao_generate_feature_panel_addon_module(esc_html__('Proofly - Social Proof Notifications', 'essb'), esc_html__('Add FOMO-driven social proof notifications to your WordPress site in minutes. Show real purchase alerts, share counts, sharing activity, and custom messages — completely free, no account required.', 'essb'), 'notification', array(array('param' => 'PROOFLY_VERSION', 'type' => 'param')), 'https://socialsharingplugin.com/addons/proofly-social-proof-notifications/', '', 'proofly');

				?>
			</div>
		</div>
		<div class="content-tab tab-advanced">
			<div class="features-manage essb-ui-flex essb-ui-flex-col essb-ui-pt4 essb-ui-pb4">
				<?php
				ao_generate_feature_panel(esc_html__('Functions Translate', 'essb'), esc_html__('Allow to translate preset plugin texts on your language', 'essb'), 'translate', 'deactivate_module_translate', true);
				ao_generate_feature_panel(esc_html__('Custom Network Buttons', 'essb'), esc_html__('Enable the function to add custom network buttons in the sharing or following.', 'essb'), 'buttons', 'deactivate_custombuttons', true);
				ao_generate_feature_panel(esc_html__('Custom Display/Positions', 'essb'), esc_html__('The custom display/positions makes possible to create a custom position inside plugin. This position you can show with shortcode of functional call anywhere on site.', 'essb'), 'content', 'deactivate_custompositions', true);
				ao_generate_feature_panel(esc_html__('Custom Code in Display Methods for Share Buttons', 'essb'), esc_html__('Enable adding custom HTML or CSS code for the display methods. The custom code will be used only when the share display method is running.', 'essb'), 'custom_code', 'activate_customcode_share_methods');
				ao_generate_feature_panel(esc_html__('Conversion Tracking', 'essb'), esc_html__('Enable the tracking of share or subscribe conversions', 'essb'), 'dashboard', 'deactivate_module_conversions', true);
				ao_generate_feature_panel(esc_html__('Automatic Mobile Setup', 'essb'), esc_html__('Activate automatic responsive mobile setup of share buttons', 'essb'), 'mobile', 'activate_mobile_auto');
				ao_generate_feature_panel(esc_html__('Integrations With Plugins', 'essb'), esc_html__('Additional integrations available with BuddyPress, bbPress and etc.', 'essb'), 'plugin', 'deactivate_method_integrations', true);
				ao_generate_feature_panel(esc_html__('Settings by Post Type', 'essb'), esc_html__('Allow additional settings for different post types', 'essb'), 'check_list', 'deactivate_settings_post_type', true);

				ao_generate_feature_panel(esc_html__('Internal Share Counters', 'essb'), esc_html__('The internal share counter option allows to change the generated counters on site and track them internally for all networks.', 'essb'), 'content_numbers', 'activate_fake');
				ao_generate_feature_panel(esc_html__('Hooks Integration', 'essb'), esc_html__('Easy assign share buttons to theme or plugin actions/filters. You can also use it to create a custom display methods.', 'essb'), 'slider', 'activate_hooks');
				ao_generate_feature_panel(esc_html__('Minimal Share Counters', 'essb'), esc_html__('Set a minimal share value that will be shown till the official value become greater', 'essb'), 'order_number', 'activate_minimal');

				?>
			</div>
		</div>

		<div class="content-tab tab-addons">
			<div class="essb-addons-container">
				<!-- addons -->
				<?php if (essb_option_bool_value('deactivate_addons_remote')) : ?>

					<style>
						.essb-ao-addons-disabled-notice {
							background: #fff;
							border: 1px solid #e2e8f0;
							border-left: 4px solid #f59e0b;
							border-radius: 6px;
							padding: 24px 28px;
							margin: 20px 0;
						}
						.essb-ao-addons-disabled-notice p {
							margin: 0 0 10px;
							font-size: 14px;
							color: #334155;
							line-height: 1.6;
						}
						.essb-ao-addons-disabled-notice p:last-child {
							margin-bottom: 0;
						}
						.essb-ao-addons-disabled-notice a {
							color: #1b84ff;
							text-decoration: none;
							font-weight: 600;
						}
						.essb-ao-addons-disabled-notice a:hover {
							text-decoration: underline;
						}
					</style>

					<div class="essb-ao-addons-disabled-notice">
						<p><?php esc_html_e('Add-ons remote list update is currently disabled.', 'essb'); ?></p>
						<p>
							<?php echo sprintf(
								esc_html__('Visit %s to browse all available add-ons.', 'essb'),
								'<a href="https://socialsharingplugin.com/addons/" target="_blank" rel="noopener noreferrer">https://socialsharingplugin.com/addons/</a>'
							); ?>
						</p>
					</div>

				<?php else : ?>
				<?php
				/**
				 * ESSB Free Add-ons — Horizontal List
				 *
				 * Same design language as the Add-Ons page cards
				 * (lib/admin/settings/essb-structure5-addons.php), arranged
				 * horizontally with a single add-on per row.
				 *
				 * The icon, the states and the shared styles come from
				 * lib/admin/helpers/ui-addons.php so both screens stay identical.
				 */
				if (!function_exists('get_plugins')) {
					require_once wp_normalize_path(ABSPATH . 'wp-admin/includes/plugin.php');
				}

				$current_addon_list  = ESSB_MyAddons_API::get_free_addons_full();
				$current_plugin_list = essb_get_site_plugins();

				// After an activate/deactivate we come back to the settings page.
				$ao_addons_redirect = admin_url('admin.php?page=essb_options');

				// -----------------------------------------------------------------------
				// Collect all unique categories present in the list so we can build the
				// filter bar dynamically — no hard-coded category list needed.
				// -----------------------------------------------------------------------
				$all_categories = [];
				foreach ($current_addon_list as $key => $data) {
					$cat = isset($data['category']) ? trim($data['category']) : '';
					if ($cat !== '' && !in_array($cat, $all_categories, true)) {
						$all_categories[] = $cat;
					}
				}
				sort($all_categories);

				$total_addons = count($current_addon_list);
				?>

				<?php essb_addons_render_styles(); ?>

				<style>
					/* ============================================================
					   ESSB ADD-ONS — Advanced options list
					   Same design as the Add-Ons page cards, but arranged
					   horizontally with one add-on per row.
					   Prefix: essb-al-
					   ============================================================ */

					/* ---- Filter bar ---- */
					.essb-al-filter-bar {
						display: flex;
						align-items: center;
						gap: 10px;
						flex-wrap: wrap;
						background: #fff;
						border: 1px solid #e4e9f5;
						border-radius: 6px;
						padding: 10px 14px;
						margin-bottom: 18px;
						box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
					}

					.essb-al-filter-label {
						font-size: 11px;
						font-weight: 600;
						color: var(--color-grey-600);
						text-transform: uppercase;
						letter-spacing: .6px;
						white-space: nowrap;
					}

					.essb-al-filter-divider {
						width: 1px;
						height: 20px;
						background: var(--color-grey-300);
						flex-shrink: 0;
					}

					.essb-al-filter-group {
						display: flex;
						align-items: center;
						gap: 6px;
						flex-wrap: wrap;
					}

					.essb-al-filter-group-label {
						font-size: 11px;
						font-weight: 600;
						color: var(--color-grey-500);
						text-transform: uppercase;
						letter-spacing: .5px;
						margin-right: 2px;
						white-space: nowrap;
					}

					.essb-al-cat-btn {
						display: inline-flex;
						align-items: center;
						padding: 5px 10px;
						border-radius: 6px;
						border: 1px solid var(--color-grey-300);
						background: #fff;
						color: var(--color-grey-700);
						font-size: 12px;
						font-weight: 500;
						cursor: pointer;
						transition: all .15s ease;
						white-space: nowrap;
						font-family: inherit;
						line-height: 1.5;
					}

					.essb-al-cat-btn:hover {
						border-color: var(--primary);
						color: var(--primary);
						background: var(--primary-light);
					}

					.essb-al-cat-btn.essb-al-cat-active {
						border-color: var(--color-content-blue);
						background: var(--color-content-blue);
						color: #fff;
					}

					.essb-al-filter-count {
						margin-left: auto;
						font-size: 12px;
						color: var(--color-grey-600);
						white-space: nowrap;
					}

					.essb-al-filter-count strong {
						font-weight: 700;
						color: #172153;
					}

					/* ---- List ---- */
					.essb-al-list {
						display: flex;
						flex-direction: column;
						gap: 8px;
					}

					/* ---- Row ---- */
					.essb-al-row {
						background: #fff;
						border: 1px solid #e4e9f5;
						border-radius: 6px;
						display: flex;
						align-items: center;
						box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
						transition: box-shadow .16s ease, border-color .16s ease;
						position: relative;
						overflow: hidden;
					}

					.essb-al-row:hover {
						box-shadow: 0 6px 20px rgba(27, 132, 255, .08);
						border-color: rgba(27, 132, 255, .18);
					}

					.essb-al-row-active {
						border-color: rgba(27, 132, 255, .5);
						background-color: #f4f9ff;
					}

					.essb-al-row-incompatible {
						opacity: .72;
					}

					.essb-al-row-incompatible:hover {
						box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
						border-color: #e4e9f5;
					}

					.essb-al-row-hidden {
						display: none !important;
					}

					/* ---- Icon column ---- */
					.essb-al-icon-col {
						padding: 14px 4px 14px 16px;
						flex-shrink: 0;
						display: flex;
						align-items: center;
						justify-content: center;
					}

					/* The hexagon frame is shared with the Add-Ons page, here it is
					   scaled down so a full row still fits next to the content. */
					.essb-al-row .essb-ui-icon-frame64 {
						width: 48px;
						height: 48px;
					}

					.essb-al-row .essb-ui-icon-frame64 .essb-ui-svg-icon {
						width: 26px;
						height: 26px;
					}

					/* ---- Content column ---- */
					.essb-al-content-col {
						flex: 1;
						padding: 12px 14px;
						display: flex;
						flex-direction: column;
						gap: 4px;
						min-width: 0;
					}

					.essb-al-title-row {
						display: flex;
						align-items: center;
						gap: 8px;
						flex-wrap: wrap;
					}

					.essb-al-title {
						font-size: 15px;
						font-weight: 700;
						color: #172153;
						line-height: 1.3;
					}

					.essb-al-desc {
						font-size: 12px;
						color: #6b7280;
						line-height: 1.5;
						margin: 0;
						display: -webkit-box;
						-webkit-line-clamp: 2;
						-webkit-box-orient: vertical;
						overflow: hidden;
					}

					/* ---- Notices ---- */
					.essb-al-notices {
						display: flex;
						align-items: center;
						gap: 8px;
						flex-wrap: wrap;
					}

					.essb-al-row .essb-addons-notice {
						width: auto;
						justify-content: flex-start;
						text-align: left;
						padding: 4px 8px;
					}

					/* ---- Links ---- */
					.essb-al-links {
						display: flex;
						align-items: center;
						gap: 14px;
						flex-wrap: wrap;
						margin-top: 2px;
					}

					.essb-al-links .essb-ui-btn-link {
						font-size: 12px;
					}

					/* ---- Divider between content and action ---- */
					.essb-al-divider {
						width: 1px;
						align-self: stretch;
						background: #f0f3fa;
						flex-shrink: 0;
					}

					/* ---- Action column ---- */
					.essb-al-action-col {
						padding: 12px 16px;
						flex-shrink: 0;
						display: flex;
						align-items: center;
						justify-content: flex-end;
						gap: 10px;
						min-width: 200px;
					}

					.essb-al-badges {
						display: flex;
						align-items: center;
						gap: 6px;
						flex-wrap: wrap;
						justify-content: flex-end;
					}

					.essb-al-btn-deactivate {
						background: var(--color-grey-200) !important;
						color: var(--color-grey-700) !important;
						border-color: var(--color-grey-300) !important;
					}

					.essb-al-btn-deactivate:hover {
						background: var(--color-grey-300) !important;
						color: var(--color-content-blue) !important;
					}

					/* ---- No results ---- */
					.essb-al-no-results {
						display: none;
						text-align: center;
						padding: 40px 20px;
						color: var(--color-grey-600);
						font-size: 14px;
					}

					.essb-al-no-results svg {
						width: 36px;
						height: 36px;
						fill: var(--color-grey-300);
						display: block;
						margin: 0 auto 10px;
					}

					.essb-al-no-results-title {
						font-weight: 700;
						color: #172153;
						margin-bottom: 4px;
						font-size: 14px;
					}
				</style>

				<!-- Filter bar -->
				<div class="essb-al-filter-bar">
					<span class="essb-al-filter-label">Filter</span>
					<?php if (!empty($all_categories)) : ?>
						<span class="essb-al-filter-divider"></span>
						<div class="essb-al-filter-group" id="essb-al-cat-group">
							<span class="essb-al-filter-group-label">Category</span>
							<?php foreach ($all_categories as $cat) : ?>
								<button
									class="essb-al-cat-btn"
									type="button"
									data-filter-cat="<?php echo esc_attr(strtolower($cat)); ?>"><?php echo esc_html($cat); ?></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<span class="essb-al-filter-count">
						<strong id="essb-al-visible-count"><?php echo (int) $total_addons; ?></strong> add-ons
					</span>
				</div>

				<!-- List -->
				<div class="essb-al-list" id="essb-al-list">

					<?php foreach ($current_addon_list as $key => $data) : ?>
						<?php ao_render_addon_row($key, $data, $current_plugin_list, $ao_addons_redirect); ?>
					<?php endforeach; ?>

					<!-- No results placeholder -->
					<div class="essb-al-no-results" id="essb-al-no-results">
						<svg viewBox="0 0 24 24">
							<path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
						</svg>
						<div class="essb-al-no-results-title"><?php esc_html_e('No add-ons match your selection', 'essb'); ?></div>
						<div><?php esc_html_e('Try adjusting your category filter.', 'essb'); ?></div>
					</div>

				</div><!-- /essb-al-list -->

				<script>
					(function() {
						'use strict';

						/**
						 * ESSBAddonListFilter
						 * Category multi-select filter for the compact free add-ons list.
						 */
						class ESSBAddonListFilter {
							constructor(opts) {
								this.listId = opts.listId || 'essb-al-list';
								this.catGroupId = opts.catGroupId || 'essb-al-cat-group';
								this.countId = opts.countId || 'essb-al-visible-count';
								this.noResultsId = opts.noResultsId || 'essb-al-no-results';
								this.rowSel = opts.rowSel || '.essb-al-row';
								this.CLS_ACTIVE = 'essb-al-cat-active';
								this.CLS_HIDDEN = 'essb-al-row-hidden';
								this._cats = new Set();
								this._init();
							}

							_init() {
								this._list = document.getElementById(this.listId);
								this._countEl = document.getElementById(this.countId);
								this._noResults = document.getElementById(this.noResultsId);
								this._catGroup = document.getElementById(this.catGroupId);

								if (!this._list) return;

								if (this._catGroup) {
									this._catGroup.querySelectorAll('[data-filter-cat]').forEach(btn => {
										btn.addEventListener('click', () => this._toggleCat(btn));
									});
								}

								this._apply();
							}

							_toggleCat(btn) {
								const cat = btn.getAttribute('data-filter-cat');
								if (this._cats.has(cat)) {
									this._cats.delete(cat);
									btn.classList.remove(this.CLS_ACTIVE);
								} else {
									this._cats.add(cat);
									btn.classList.add(this.CLS_ACTIVE);
								}
								this._apply();
							}

							_apply() {
								const rows = this._list.querySelectorAll(this.rowSel);
								let visible = 0;

								rows.forEach(row => {
									if (row.id === this.noResultsId) return;
									const rowCat = (row.getAttribute('data-addon-category') || '').trim();
									const pass = this._cats.size === 0 || this._cats.has(rowCat);
									if (pass) {
										row.classList.remove(this.CLS_HIDDEN);
										visible++;
									} else {
										row.classList.add(this.CLS_HIDDEN);
									}
								});

								if (this._countEl) this._countEl.textContent = visible;
								if (this._noResults) this._noResults.style.display = visible === 0 ? 'block' : 'none';
							}

							/** Programmatically clear all active category filters */
							reset() {
								this._cats.clear();
								if (this._catGroup) {
									this._catGroup.querySelectorAll('[data-filter-cat]')
										.forEach(b => b.classList.remove(this.CLS_ACTIVE));
								}
								this._apply();
							}
						}

						// Boot — wait for DOM ready (script is inline so DOM may not be ready yet)
						if (document.readyState === 'loading') {
							document.addEventListener('DOMContentLoaded', boot);
						} else {
							boot();
						}

						function boot() {
							window.essbAddonListFilter = new ESSBAddonListFilter({
								listId: 'essb-al-list',
								catGroupId: 'essb-al-cat-group',
								countId: 'essb-al-visible-count',
								noResultsId: 'essb-al-no-results',
								rowSel: '.essb-al-row'
							});
						}
					}());
				</script>

				<!-- end: addons -->
				<?php endif; // deactivate_addons_remote ?>
			</div>
		</div>
	</div>

</div>

<style>
.essb-df-toast { position: fixed; bottom: 24px; right: 24px; padding: 12px 20px; border-radius: 6px; font-size: 13px; font-weight: 500; color: #fff; z-index: 999999; opacity: 0; transform: translateY(8px); transition: opacity .3s ease, transform .3s ease; pointer-events: none; }
.essb-df-toast-show { opacity: 1; transform: translateY(0); }
.essb-df-toast-success { background: #22c55e; }
.essb-df-toast-error { background: #ef4444; }
</style>
<script>
jQuery(function($) {
	$(document).on('click', '[data-install]', function(e) {
		e.preventDefault();
		var btn = this;
		var slug = btn.getAttribute('data-install');
		var nonce = btn.getAttribute('data-install-nonce') || '';
		var originalText = btn.textContent;

		btn.disabled = true;
		btn.textContent = 'Processing\u2026';

		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action: 'essb_install_free_addon',
				slug: slug,
				nonce: nonce
			},
			success: function(response) {
				if (response.success) {
					btn.textContent = 'Active';
					btn.className = 'essb-ui-btn essb-ui-btn-link';
					btn.disabled = true;
					$(btn).closest('.essb-ui-card').find('.essb-activation-status-active').show();
					$(btn).closest('.essb-ui-card').find('.essb-activation-status-notactive').hide();
					var $toast = $('<div class="essb-df-toast essb-df-toast-success">Plugin installed and activated</div>').appendTo('body');
					setTimeout(function() { $toast.addClass('essb-df-toast-show'); }, 10);
					setTimeout(function() { $toast.removeClass('essb-df-toast-show'); setTimeout(function() { $toast.remove(); }, 300); }, 2000);
				} else {
					var msg = response.data && response.data.message ? response.data.message : 'Installation failed';
					btn.textContent = originalText;
					btn.disabled = false;
					var $toast = $('<div class="essb-df-toast essb-df-toast-error">' + msg + '</div>').appendTo('body');
					setTimeout(function() { $toast.addClass('essb-df-toast-show'); }, 10);
					setTimeout(function() { $toast.removeClass('essb-df-toast-show'); setTimeout(function() { $toast.remove(); }, 300); }, 3000);
				}
			},
			error: function() {
				btn.textContent = originalText;
				btn.disabled = false;
				var $toast = $('<div class="essb-df-toast essb-df-toast-error">Connection error. Please try again.</div>').appendTo('body');
				setTimeout(function() { $toast.addClass('essb-df-toast-show'); }, 10);
				setTimeout(function() { $toast.removeClass('essb-df-toast-show'); setTimeout(function() { $toast.remove(); }, 300); }, 3000);
			}
		});
	});
});
</script>