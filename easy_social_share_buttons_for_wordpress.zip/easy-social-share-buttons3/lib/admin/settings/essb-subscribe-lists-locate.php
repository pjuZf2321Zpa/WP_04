<?php
// Generic list loader component for subscribe connectors.
if (!function_exists('essb5_subscribe_lists_locate')) {
    function essb5_subscribe_lists_locate($option = array()) {
        $element = isset($option['element_options']) ? $option['element_options'] : array();
        $connector = isset($element['connector']) ? $element['connector'] : '';
        $listkey = isset($element['listkey']) ? $element['listkey'] : '';
        $deps = isset($element['deps']) && is_array($element['deps']) ? $element['deps'] : array();
        $deps_json = htmlspecialchars(json_encode($deps), ENT_QUOTES, 'UTF-8');
        echo '<a href="#" class="essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm essb-subscribe-load-lists" data-connector="' . esc_attr($connector) . '" data-listkey="' . esc_attr($listkey) . '" data-deps="' . $deps_json . '" style="color:#ffffff; text-decoration:none;">' . esc_html__('Load Lists', 'essb') . '</a>';

        static $printed = false;
        if ($printed) return;
        $printed = true;
        ?>
        <script type="text/javascript">
        (function($){
            "use strict";
            function essbSubscribeFindListKey(connector) {
                var candidates = [
                    'subscribe_' + connector + '_list',
                    'subscribe_' + connector + '_list_id',
                    'subscribe_' + connector + '_listid'
                ];
                for (var i = 0; i < candidates.length; i++) {
                    if ($('#essb_options_' + candidates[i]).length) return candidates[i];
                }
                return candidates[0];
            }
            function essbSubscribeShowListModal(connector, listkey, items) {
                $('#essb-subscribe-list-modal').remove();
                var select = $('<select class="input-element stretched" style="width:100%;" />');
                $.each(items, function(id, name){
                    select.append($('<option/>').attr('value', id).text(name));
                });
                var modal = $(
                    '<div id="essb-subscribe-list-modal" class="essb-ui" style="position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.5);">' +
                    '<div style="background:#fff;padding:20px;border-radius:8px;max-width:420px;width:90%;box-shadow:0 10px 30px rgba(0,0,0,0.3);">' +
                    '<h3 style="margin-top:0;">' + <?php echo json_encode(esc_html__('Select List', 'essb')); ?> + '</h3>' +
                    '<div class="essb-subscribe-list-modal-body"></div>' +
                    '<div style="margin-top:15px;text-align:right;">' +
                    '<button type="button" class="essb-ui-btn essb-subscribe-list-cancel" style="margin-right:8px;">' + <?php echo json_encode(esc_html__('Cancel', 'essb')); ?> + '</button>' +
                    '<button type="button" class="essb-ui-btn essb-ui-btn-primary essb-subscribe-list-apply">' + <?php echo json_encode(esc_html__('Apply', 'essb')); ?> + '</button>' +
                    '</div>' +
                    '</div></div>'
                );
                modal.find('.essb-subscribe-list-modal-body').append(select);
                $('body').append(modal);
                modal.find('.essb-subscribe-list-cancel').on('click', function(){ modal.remove(); });
                modal.find('.essb-subscribe-list-apply').on('click', function(){
                    var key = listkey || essbSubscribeFindListKey(connector);
                    var field = $('#essb_options_' + key);
                    if (field.length) {
                        field.val(String(select.val()));
                    }
                    modal.remove();
                    if (typeof $.toast === 'function') {
                        $.toast({ heading: 'List selected', icon: 'success', position: 'bottom-right', hideAfter: 3000 });
                    }
                });
            }
            $(document).on('click', '.essb-subscribe-load-lists', function(e){
                e.preventDefault();
                var btn = $(this);
                var connector = btn.data('connector');
                var listkey = btn.data('listkey');
                var deps = btn.data('deps');
                if (!Array.isArray(deps)) { try { deps = JSON.parse(deps); } catch(err) { deps = []; } }
                var payload = { connector: connector };
                var missing = false;
                deps.forEach(function(key){
                    var val = $('#essb_options_' + key).val();
                    if (!val) missing = true;
                    payload[key] = val;
                });
                if (missing) {
                    if (typeof $.toast === 'function') {
                        $.toast({ heading: 'Required fields are empty', icon: 'error', position: 'bottom-right', hideAfter: 4000 });
                    }
                    return;
                }
                btn.prop('disabled', true).css('opacity', '0.6');
                if (typeof $.toast === 'function') {
                    $.toast({
                        heading: 'Loading lists...',
                        text: 'Fetching lists from the provider.',
                        showHideTransition: 'fade',
                        icon: 'info',
                        position: 'bottom-right',
                        hideAfter: 2500
                    });
                }
                $.ajax({
                    url: essb_advancedopts_ajaxurl + '?action=essb_advanced_options&essb_advancedoptions_token=' + $('#essb_advancedoptions_token').val() + '&cmd=subscribe_lists',
                    type: 'POST',
                    data: payload,
                    dataType: 'json',
                    success: function(result){
                        btn.prop('disabled', false).css('opacity', '1');
                        if (result && result.status === 'OK' && result.items) {
                            essbSubscribeShowListModal(connector, listkey, result.items);
                        } else {
                            if (typeof $.toast === 'function') {
                                $.toast({ heading: 'Cannot load lists', text: (result && result.message) ? result.message : '', icon: 'error', position: 'bottom-right', hideAfter: 5000 });
                            }
                        }
                    },
                    error: function(){
                        btn.prop('disabled', false).css('opacity', '1');
                        if (typeof $.toast === 'function') {
                            $.toast({ heading: 'Cannot load lists', icon: 'error', position: 'bottom-right', hideAfter: 5000 });
                        }
                    }
                });
            });
        })(jQuery);
        </script>
        <?php
    }
}
