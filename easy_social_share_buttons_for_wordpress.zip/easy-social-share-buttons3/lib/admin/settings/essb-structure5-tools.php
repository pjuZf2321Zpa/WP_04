<?php
/**
 * ESSB Tools Page
 *
 * Standalone tools page displayed below Add-Ons in the right menu.
 * Mirrors the home page UI (about-page-header top bar) and lists
 * available tools one per row with Problem → Solution copy.
 *
 * Bind icons, colors and install links from the add-ons feed when
 * available; marketing titles/descriptions are customized locally.
 */

include_once ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/about-page-header.php';

if (!function_exists('get_plugins')) {
	require_once wp_normalize_path(ABSPATH . 'wp-admin/includes/plugin.php');
}

include_once ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/ui-addons.php';

if (!class_exists('ESSB_MyAddons_API')) {
	include_once ESSB3_PLUGIN_ROOT . 'lib/classes/admin/class-my-api-addons.php';
}

essb_addons_render_styles();

// ------------------------------------------------------------------
// Tool definitions — marketing copy customized per the brief.
// Feed slugs are used to look up icon/color/install link from the API.
// ------------------------------------------------------------------
$essb_tools = array(
	'social-profile-card-studio' => array(
		'feed_slug'    => 'social-profile-card-studio',
		'title'        => 'Link in Bio & Social Profile Card Builder',
		'problem'      => 'Bio links look generic and visitors can’t find your social profiles.',
		'solution'     => 'Build branded link-in-bio pages and social profile cards visitors can click from Instagram, TikTok, or your posts. 72 presets included, no design skills needed.',
		'learn_more'   => 'https://socialsharingplugin.com/social-profile-card-studio/',
		'featured'     => true,
	),
	'essb-social-chat' => array(
		'feed_slug'    => 'essb-social-chat',
		'title'        => 'Social Chat',
		'problem'      => 'Visitors leave without asking questions because they can’t reach you.',
		'solution'     => 'Add floating WhatsApp, Telegram, Viber, Signal, and Line chat buttons so visitors can message you instantly — no contact form needed.',
		'learn_more'   => 'https://socialsharingplugin.com/social-chat/',
		'featured'     => false,
	),
	'essb-social-contact' => array(
		'feed_slug'    => 'essb-social-contact',
		'title'        => 'Social Contact',
		'problem'      => 'Customers can’t find how to contact you and abandon purchases.',
		'solution'     => 'Display social contact buttons on every page and WooCommerce product page so shoppers can ask questions before they buy.',
		'learn_more'   => 'https://socialsharingplugin.com/social-contact/',
		'featured'     => false,
	),
	'proofly' => array(
		'feed_slug'    => 'proofly',
		'title'        => 'Proofly',
		'problem'      => 'New visitors don’t trust your store yet, so they don’t buy.',
		'solution'     => 'Show real-time social proof notifications — recent purchases, on-sale products, share counts — that build trust and drive conversions automatically.',
		'learn_more'   => 'https://socialsharingplugin.com/addons/proofly-social-proof-notifications/',
		'featured'     => false,
	),
	'shorty-essb-addon' => array(
		'feed_slug'    => 'shorty-essb-addon',
		'title'        => 'Shorty — Self Hosted Short URLs',
		'problem'      => 'Third-party link shorteners cap your links, charge monthly fees, and you don’t own the data.',
		'solution'     => 'Create unlimited self-hosted short URLs on your own domain. Track clicks and manage redirects with no monthly fees and no third-party accounts.',
		'learn_more'   => 'https://socialsharingplugin.com/addons/shorty-self-hosted-shorturls/',
		'featured'     => false,
	),
	'appscreo-visual-css-customizer' => array(
		'feed_slug'    => 'simple-custom-code',
		'title'        => 'Simple Custom Code — CSS, JS, and HTML Snippets',
		'problem'      => 'Adding custom code means editing risky theme files that get overwritten on updates.',
		'solution'     => 'Add and manage unlimited CSS, JavaScript, and HTML snippets without touching theme files. Includes a visual CSS customizer and AI code generation.',
		'learn_more'   => 'https://wordpress.org/plugins/appscreo-visual-css-customizer/',
		'featured'     => false,
	),
);

// ------------------------------------------------------------------
// Resolve install/activate state for each tool.
// ------------------------------------------------------------------
$current_plugins = essb_get_site_plugins();

$install_base = admin_url('admin.php?page=essb_redirect_tools');
if (class_exists('ESSB_TGM_Plugin_Activation') && isset(ESSB_TGM_Plugin_Activation::$instance)) {
	$tgmpa_url = ESSB_TGM_Plugin_Activation::$instance->get_tgmpa_url();
	if (false !== strpos($tgmpa_url, 'page=essb_redirect_addons')) {
		$install_base = $tgmpa_url;
	}
}

$feed_addons = ESSB_MyAddons_API::get_addons();

foreach ($essb_tools as $key => &$tool) {
	$tool['is_active'] = false;
	$tool['is_installed'] = false;
	$tool['install_url'] = '';
	$tool['activate_url'] = '';
	$tool['icon_svg'] = '';
	$tool['brand_color'] = '';

	// --- Feed data (icon, color, download link) ---
	if (!empty($tool['feed_slug']) && isset($feed_addons[$tool['feed_slug']])) {
		$feed = $feed_addons[$tool['feed_slug']];
		$tool['icon_svg']    = isset($feed['svg_icon']) ? $feed['svg_icon'] : '';
		$tool['brand_color'] = isset($feed['color']) ? $feed['color'] : '';
		if (empty($tool['learn_more']) && !empty($feed['page'])) {
			$tool['learn_more'] = $feed['page'];
		}
	}

	// --- Install state via installed plugins ---
	if (isset($current_plugins[$key])) {
		$tool['is_installed'] = true;
		$tool['is_active']    = (bool) $current_plugins[$key]['active'];
		$addon_path           = $current_plugins[$key]['path'];
		$redirect_url         = admin_url('admin.php?page=essb_redirect_tools');

		$tool['activate_url'] = wp_nonce_url(
			add_query_arg(
				array(
					'action'      => 'activate',
					'plugin'      => $addon_path,
					'redirect_to' => urlencode($redirect_url),
				),
				admin_url('plugins.php')
			),
			"activate-plugin_{$addon_path}"
		);
	} else {
		// Not installed — build TGMPA install URL
		$tool['install_url'] = wp_nonce_url(
			add_query_arg(
				array(
					'plugin'             => urlencode($tool['feed_slug'] ?: $key),
					'essb-tgmpa-install' => 'install-plugin',
				),
				$install_base
			),
			'essb-tgmpa-install',
			'essb-tgmpa-nonce'
		);
	}
}
unset($tool);

?>
<style>
	.essb-control-content-fullwidth { width: 100% !important; }
	/* Reuse existing admin tokens so the page matches the home UI */
	.essb-tools-wrap {
		max-width: 1100px;
		margin: 0 auto;
		padding: 26px 20px 48px;
	}

	.essb-tools-hero {
		margin-bottom: 32px;
	}

	.essb-tools-hero-title {
		font-size: 22px;
		font-weight: 600;
		color: #172153;
		margin: 0 0 8px;
		letter-spacing: .2px;
	}

	.essb-tools-hero-desc {
		font-size: 14px;
		color: #6b7280;
		margin: 0;
		line-height: 1.6;
		max-width: 700px;
	}

	.essb-tools-section {
		margin-top: 8px;
	}

	.essb-tools-section-title {
		display: flex;
		align-items: center;
		gap: 9px;
		font-size: 18px;
		font-weight: 500;
		color: #172153;
		margin: 0 0 16px;
		padding: 0;
	}

	.essb-tools-section-count {
		font-size: 12px;
		font-weight: 600;
		color: #6b7280;
		background: #f0f3fa;
		border: 1px solid #e4e9f5;
		border-radius: 4px;
		padding: 1px 7px;
		line-height: 1.6;
	}

	/* One tool per row */
	.essb-tools-list {
		display: flex;
		flex-direction: column;
		gap: 12px;
	}

	.essb-tools-row {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 8px;
		display: grid;
		grid-template-columns: 64px 1fr 260px;
		gap: 18px;
		align-items: center;
		padding: 14px 18px;
		position: relative;
		transition: border-color .15s ease, box-shadow .15s ease;
	}

	.essb-tools-row:hover {
		border-color: rgba(27, 132, 255, .25);
		box-shadow: 0 6px 20px rgba(27, 132, 255, .06);
	}

	/* Featured row */
	.essb-tools-row--featured {
		border: 2px solid #1b84ff;
		background: linear-gradient(120deg, #f4f9ff 0%, #fff 70%);
	}

	.essb-tools-row--featured:hover {
		border-color: #1b84ff;
		box-shadow: 0 10px 30px rgba(27, 132, 255, .12);
	}

	.essb-tools-row-featured-badge {
		position: absolute;
		top: 12px;
		right: 12px;
		z-index: 2;
		font-size: 10px;
		font-weight: 700;
		letter-spacing: .08em;
		text-transform: uppercase;
		background: #eef2f7;
		color: #172153;
		padding: 3px 8px;
		border-radius: 4px;
		border: 1px solid #e4e9f5;
	}

	/* Icon cell */
	.essb-tools-row-icon {
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.essb-tools-icon-frame {
		width: 44px !important;
		height: 48px !important;
	}

	/* Body cell */
	.essb-tools-row-body {
		display: flex;
		flex-direction: column;
		gap: 4px;
		min-width: 0;
	}

	.essb-tools-row-title {
		font-size: 18px;
		font-weight: 700;
		color: #172153;
		line-height: 1.3;
		margin: 0;
		letter-spacing: .1px;
		margin-bottom: 0.5em;
	}

	.essb-tools-row-problem {
		font-size: 14px;
		font-weight: 500;
		color: #172153;
		margin: 0 0 4px;
		line-height: 1.5;
	}

	.essb-tools-row-solution {
		font-size: 14px;
		font-weight: 400;
		color: #6b7280;
		margin: 0;
		line-height: 1.5;
	}

	/* Actions cell */
	.essb-tools-row-actions {
		display: flex;
		align-items: center;
		gap: 10px;
		justify-content: flex-end;
		flex-wrap: wrap;
	}

	.essb-tools-btn {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		font-size: 13px;
		font-weight: 600;
		border-radius: 6px;
		border: 1px solid transparent;
		cursor: pointer;
		text-decoration: none;
		font-family: inherit;
		transition: background .15s ease, border-color .15s ease, color .15s ease;
		white-space: nowrap;
	}

	.essb-tools-btn-primary {
		background: #1b84ff;
		color: #fff;
		padding: 7px 16px;
	}

	.essb-tools-btn-primary:hover,
	.essb-tools-btn-primary:focus {
		background: #056ee9;
		color: #fff;
	}

	.essb-tools-btn-ghost {
		background: #fff;
		color: #6b7280;
		border-color: #e4e9f5;
		padding: 7px 14px;
	}

	.essb-tools-btn-ghost:hover,
	.essb-tools-btn-ghost:focus {
		background: #f0f3fa;
		color: #172153;
		border-color: #e4e9f5;
	}

	.essb-tools-badge-active {
		display: inline-flex;
		align-items: center;
		font-size: 11.5px;
		font-weight: 600;
		border-radius: 4px;
		padding: 4px 10px;
		background: #ecfdf5;
		color: #166534;
		border: 1px solid #bbf7d0;
		white-space: nowrap;
	}

	/* Responsive */
	@media (max-width: 782px) {
		.essb-tools-row {
			grid-template-columns: 56px 1fr auto;
			gap: 12px;
			padding: 12px 16px;
		}

		.essb-tools-row-actions {
			flex-direction: column;
			align-items: stretch;
			gap: 8px;
		}

		.essb-tools-row-actions .essb-tools-btn,
		.essb-tools-row-actions .essb-tools-btn-ghost,
		.essb-tools-row-actions .essb-tools-badge-active {
			width: 100%;
			justify-content: center;
		}

		.essb-tools-row-title {
			font-size: 14px;
		}

		.essb-tools-row-problem,
		.essb-tools-row-solution {
			font-size: 12px;
		}
	}
</style>

<div class="essb-tools-wrap essb-ui">

	<header class="essb-tools-hero">
		<h1 class="essb-tools-hero-title">Tools</h1>
		<p class="essb-tools-hero-desc">Add standalone tools from the Easy Social Share Buttons family. Each one solves a specific problem — install and activate with one click.</p>
	</header>

	<section class="essb-tools-section">
		<h2 class="essb-tools-section-title">
			Available tools
			<span class="essb-tools-section-count"><?php echo count($essb_tools); ?></span>
		</h2>

		<div class="essb-tools-list" id="essb-tools-list">
			<?php foreach ($essb_tools as $key => $tool) : ?>
				<div class="essb-tools-row<?php echo $tool['featured'] ? ' essb-tools-row--featured' : ''; ?>">
					<div class="essb-tools-row-cell essb-tools-row-icon">
						<?php if (!empty($tool['feed_slug']) && isset($feed_addons[$tool['feed_slug']])) : ?>
							<?php essb_addons_render_icon($feed_addons[$tool['feed_slug']]); ?>
						<?php else : ?>
							<div class="essb-tools-icon-frame" style="background:#eaf4ff;border-radius:10px;display:flex;align-items:center;justify-content:center;">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1b84ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:block;">
									<polyline points="16 18 22 12 16 6"></polyline>
									<polyline points="8 6 2 12 8 18"></polyline>
								</svg>
							</div>
						<?php endif; ?>
						<?php if ($tool['featured']) : ?>
							<span class="essb-tools-row-featured-badge">Featured</span>
						<?php endif; ?>
					</div>
					<div class="essb-tools-row-cell essb-tools-row-body">
						<h3 class="essb-tools-row-title"><?php echo esc_html($tool['title']); ?></h3>
						<p class="essb-tools-row-problem"><?php echo esc_html($tool['problem']); ?></p>
						<p class="essb-tools-row-solution"><?php echo esc_html($tool['solution']); ?></p>
					</div>
					<div class="essb-tools-row-cell essb-tools-row-actions">
						<?php if ($tool['is_active']) : ?>
							<span class="essb-tools-badge-active">Active</span>
						<?php elseif ($tool['is_installed']) : ?>
							<a href="<?php echo esc_url($tool['activate_url']); ?>" class="essb-tools-btn essb-tools-btn-primary">Activate</a>
						<?php else : ?>
							<a href="<?php echo esc_url($tool['install_url']); ?>" class="essb-tools-btn essb-tools-btn-primary">Install</a>
						<?php endif; ?>
						<?php if (!empty($tool['learn_more'])) : ?>
							<a href="<?php echo esc_url($tool['learn_more']); ?>" target="_blank" rel="noopener noreferrer" class="essb-tools-btn essb-tools-btn-ghost">Learn more</a>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</section>

</div>
