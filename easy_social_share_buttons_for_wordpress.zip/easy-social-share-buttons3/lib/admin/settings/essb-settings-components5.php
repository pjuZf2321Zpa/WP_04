<?php

function essb_component_network_selection($position = '', $options_group = 'essb_options', $show_all = false, $modern = false)
{
	$active_networks = array();
	$essb_networks = essb_available_social_networks($show_all);

	if ($position == '') {
		$active_networks = essb_option_value('networks');
	} else {
		$active_networks = essb_option_value($position . '_networks');
	}

	$external_bridge = false;
	if (ESSBOptionsFramework::option_keys_to_settings($options_group) != '') {
		$active_networks = ESSBOptionsFramework::external_options_value($options_group, $position . '_networks');
		$external_bridge = true;
	}

	$salt = mt_rand();

	if (!is_array($active_networks)) {
		$active_networks = array();
	}

	$svg_support = essb_using_svg_icons_sharing();

	// Modern redesigned list (currently only used on the global networks page).
	// It keeps the exact same saved options as the legacy markup below.
	if ($modern) {
		essb_component_network_selection_modern($position, $options_group, $active_networks, $essb_networks, $salt, $svg_support, $external_bridge);
		return;
	}

	echo '<ul class="essb-component-networkselect essb-sortable essb-componentkey-' . esc_attr($salt) . ' essb-component-networkselect-' . esc_attr($position) . ($svg_support ? ' essb-component-networkselect-svg' : '') . '" id="essb-componentkey-' . esc_attr($salt) . '" data-position="' . esc_attr($position) . '" data-group="' . esc_attr($options_group) . '">';

	foreach ($active_networks as $network) {

		$current_network_name = isset($essb_networks[$network]) ? $essb_networks[$network]["name"] : $network;
		if (isset($essb_networks[$network]["label"])) {
			$current_network_name = $essb_networks[$network]["label"];
		}

		if ($position == '') {
			$user_network_name = essb_option_value('user_network_name_' . $network);

			if ($user_network_name == '') {
				$user_network_name = $current_network_name;
			}
		} else {
			$user_network_name = essb_option_value($position . '_' . $network . '_name');
		}

		$custom_svg_icon = '';

		if ($svg_support) {
			if (!class_exists('ESSB_SVG_Icons')) {
				include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
			}

			$custom_svg_icon = ESSB_SVG_Icons::get_icon($network);
		}

		if ($external_bridge) {
			$user_network_name = ESSBOptionsFramework::external_options_value($options_group, $position . '_' . $network . '_name');
		}

		$additional_network_class = $network;

		if ($network == 'twitter') {
			$additional_network_class = 'twitter_x';
			if (!class_exists('ESSB_SVG_Icons')) {
				include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
			}

			$custom_svg_icon = ESSB_SVG_Icons::get_icon('twitter_x');
		}

		echo '<li class="essb-admin-networkselect-single essb-network-color-' . esc_attr($additional_network_class) . '" data-network="' . esc_attr($network) . '" data-key="' . esc_attr($salt) . '">';
		if ($position != '') {
			echo '<input type="hidden" name="' . esc_attr($options_group) . '[' . esc_attr($position) . '_networks][]" value="' . esc_attr($network) . '"/>';
		} else {
			echo '<input type="hidden" name="' . esc_attr($options_group) . '[networks][]" value="' . esc_attr($network) . '"/>';
		}
		echo '<span class="essb-icon-remove fa fa-times" onclick="essbSettingsHelper.removeNetwork(this); return false;"></span>';
		echo '<span class="essb_icon essb_icon_' . esc_attr($network) . ($svg_support ? ' essb_svg_icon_' . esc_attr($network) : '') . '">' . $custom_svg_icon . '</span>';
		echo '<span class="essb-sns-name">' . esc_html($current_network_name) . '</span>';
		echo '<span class="essb-single-network-name">';

		if ($position != '') {
			echo esc_html__('Personalize text on button:', 'essb') . '<br/><input type="text" class="input-element" name="' . esc_attr($options_group) . '[' . esc_attr($position) . '_' . esc_attr($network) . '_name]" value="' . esc_attr($user_network_name) . '"/>';
		} else {
			echo esc_html__('Personalize text on button:', 'essb') . '<br/><input type="text" class="input-element" name="essb_options_names[' . esc_attr($network) . ']" value="' . esc_attr($user_network_name) . '"/>';
		}
		echo '</span>';
		echo '</li>';
	}

	$network = 'add';
	echo '<li class="essb-admin-networkselect-single essb-network-color-' . esc_attr($network) . '" data-network="' . esc_attr($network) . '" data-key="' . esc_attr($salt) . '" onclick="essbSettingsHelper.startNetworkSelection(\'' . $salt . '\'); return false;">';
	echo '<span class="essb_icon fa fa-plus-square"></span>';
	echo '<span class="essb-sns-name">' . esc_html__('Add more networks', 'essb') . '</span>';
	echo '</li>';


	echo '</ul>';
}

/**
 * Very light tint of a brand color (mix toward white), used by the modern
 * network selection tiles.
 *
 * @param string $hex    Brand color (e.g. #0866FF or #333)
 * @param float  $amount 0..1 amount of white (0.93 = ~93% white)
 * @return string
 */
function essb_component_network_color_tint($hex, $amount = 0.93)
{
	$hex = ltrim($hex, '#');
	if (strlen($hex) == 3) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if (strlen($hex) != 6) {
		return '#ffffff';
	}

	$r = hexdec(substr($hex, 0, 2));
	$g = hexdec(substr($hex, 2, 2));
	$b = hexdec(substr($hex, 4, 2));

	$r = (int) round($r + (255 - $r) * $amount);
	$g = (int) round($g + (255 - $g) * $amount);
	$b = (int) round($b + (255 - $b) * $amount);

	return 'rgb(' . $r . ',' . $g . ',' . $b . ')';
}

/**
 * Returns the network color map used by the modern network selection.
 *
 * The base map (ESSB_Share_Button_Styles) does not include user-created custom
 * networks/buttons, so their stored color is merged in here.
 *
 * @return array
 */
function essb_network_selection_colors()
{
	if (!class_exists('ESSB_Share_Button_Styles')) {
		include_once(ESSB3_CLASS_PATH . 'assets/class-share-button-styles.php');
	}

	$colors = class_exists('ESSB_Share_Button_Styles') ? ESSB_Share_Button_Styles::get_network_colors() : array();

	if (!function_exists('essb_get_custom_buttons')) {
		include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/custombuttons-helper.php');
	}

	$buttons = function_exists('essb_get_custom_buttons') ? essb_get_custom_buttons() : array();
	if (is_array($buttons)) {
		foreach ($buttons as $id => $data) {
			if (isset($colors[$id]) && $colors[$id] != '') {
				continue;
			}

			$color = '';
			if (!empty($data['network_color'])) {
				$color = $data['network_color'];
			} else if (!empty($data['bgcolor'])) {
				$color = $data['bgcolor'];
			}

			if ($color != '') {
				$colors[$id] = $color;
			}
		}
	}

	return $colors;
}

/**
 * Modern (redesigned) active networks list used on the global networks page.
 *
 * It preserves the exact same saved options as the legacy component:
 *  - membership + order: hidden inputs named <group>[networks][]
 *  - custom button text: input named essb_options_names[<network>] (always
 *    populated, because the front-end returns the stored value even when empty)
 *
 * @param string $position
 * @param string $options_group
 * @param array  $active_networks
 * @param array  $essb_networks
 * @param int    $salt
 * @param bool   $svg_support
 * @param bool   $external_bridge
 */
function essb_component_network_selection_modern($position, $options_group, $active_networks, $essb_networks, $salt, $svg_support, $external_bridge = false)
{
	$colors = essb_network_selection_colors();

	$svg_handle = '<svg width="8" height="14" viewBox="0 0 8 14" fill="currentColor" aria-hidden="true"><circle cx="1.5" cy="2" r="1.2"/><circle cx="6.5" cy="2" r="1.2"/><circle cx="1.5" cy="7" r="1.2"/><circle cx="6.5" cy="7" r="1.2"/><circle cx="1.5" cy="12" r="1.2"/><circle cx="6.5" cy="12" r="1.2"/></svg>';
	$svg_pencil = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M11.5 2.5l2 2L5 13l-2.5.5L3 11l8.5-8.5z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>';
	$svg_times = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';
	$svg_reset = '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8a5 5 0 1 0 1.5-3.5M3 2.5V5h2.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
	$svg_plus = '<svg width="11" height="11" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M6 2.25v7.5M2.25 6h7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

	echo '<ul class="essb-component-networkselect essb-component-networkselect-new essb-componentkey-' . esc_attr($salt) . '" id="essb-componentkey-' . esc_attr($salt) . '" data-key="' . esc_attr($salt) . '" data-position="' . esc_attr($position) . '" data-group="' . esc_attr($options_group) . '">';

	foreach ($active_networks as $network) {

		$current_network_name = isset($essb_networks[$network]) ? $essb_networks[$network]["name"] : $network;
		if (isset($essb_networks[$network]["label"])) {
			$current_network_name = $essb_networks[$network]["label"];
		}

		if ($position == '') {
			$user_network_name = essb_option_value('user_network_name_' . $network);
		} else {
			$user_network_name = essb_option_value($position . '_' . $network . '_name');
		}

		if ($external_bridge) {
			$user_network_name = ESSBOptionsFramework::external_options_value($options_group, $position . '_' . $network . '_name');
		}

		// The field is always populated so "custom" is a comparison against the
		// network name (not emptiness).
		if ($user_network_name == '') {
			$user_network_name = $current_network_name;
		}

		$is_custom = ($user_network_name != '' && $user_network_name !== $current_network_name);

		if ($position == '') {
			$hidden_name = $options_group . '[networks][]';
			$name_field = 'essb_options_names[' . $network . ']';
		} else {
			$hidden_name = $options_group . '[' . $position . '_networks][]';
			$name_field = $options_group . '[' . $position . '_' . $network . '_name]';
		}

		$icon_network = ($network == 'twitter') ? 'twitter_x' : (($network == 'instgram') ? 'instagram' : $network);
		$custom_svg_icon = '';

		if ($svg_support) {
			if (!class_exists('ESSB_SVG_Icons')) {
				include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
			}

			$custom_svg_icon = ESSB_SVG_Icons::get_icon($icon_network);
		}

		// Letter fallback when a network has no icon (e.g. custom networks).
		$network_initial = '';
		if ($custom_svg_icon == '') {
			$network_initial = function_exists('mb_substr') ? mb_substr($current_network_name, 0, 1, 'UTF-8') : substr($current_network_name, 0, 1);
		}

		$brand = isset($colors[$icon_network]) ? $colors[$icon_network] : '#6b7280';
		$tint = essb_component_network_color_tint($brand, 0.93);

		echo '<li class="essb-admin-networkselect-single essb-ns-tile" data-network="' . esc_attr($network) . '" data-key="' . esc_attr($salt) . '" style="--brand:' . esc_attr($brand) . ';--brand-tint:' . esc_attr($tint) . '">';

		echo '<span class="essb-ns-handle" title="' . esc_attr__('Drag to reorder', 'essb') . '">' . $svg_handle . '</span>';
		echo '<span class="essb-ns-icon">' . ($custom_svg_icon != '' ? $custom_svg_icon : '<span class="essb-ns-icon-letter">' . esc_html($network_initial) . '</span>') . '</span>';
		echo '<span class="essb-ns-info">';
		echo '<span class="essb-sns-name essb-ns-name">' . esc_html($current_network_name) . '</span>';
		echo '<span class="essb-single-network-name essb-ns-text">';
		echo '<span class="essb-ns-text-line"><span class="essb-ns-text-label">' . esc_html__('Text', 'essb') . '</span><span class="essb-ns-tag ' . ($is_custom ? 'essb-ns-tag-custom' : 'essb-ns-tag-default') . '">' . ($is_custom ? esc_html__('custom', 'essb') : esc_html__('default', 'essb')) . '</span></span>';
		echo '<span class="essb-ns-text-value">' . esc_html($user_network_name) . '</span>';
		echo '<span class="essb-ns-edit-wrap">';
		echo '<input type="text" class="essb-ns-custom-input" name="' . esc_attr($name_field) . '" value="' . esc_attr($user_network_name) . '"/>';
		echo '<span class="essb-ns-edit-foot">';
		echo '<button type="button" class="essb-ns-reset" title="' . esc_attr__('Reset to network name', 'essb') . '">' . $svg_reset . ' ' . esc_html__('Reset', 'essb') . '</button></span>';
		echo '</span>';
		echo '</span>';
		echo '</span>';

		echo '<span class="essb-ns-actions">';
		echo '<button type="button" class="essb-ns-iconbtn essb-ns-edit" title="' . esc_attr__('Personalize button text', 'essb') . '">' . $svg_pencil . '</button>';
		echo '<button type="button" class="essb-ns-iconbtn essb-ns-remove" title="' . esc_attr__('Remove network', 'essb') . '">' . $svg_times . '</button>';
		echo '</span>';

		echo '<input type="hidden" name="' . esc_attr($hidden_name) . '" value="' . esc_attr($network) . '"/>';
		echo '</li>';
	}

	echo '<li class="essb-ns-add" data-network="add" role="button" tabindex="0">';
	echo '<span class="essb-ns-add-plus">' . $svg_plus . '</span>';
	echo '<span>' . esc_html__('Add networks', 'essb') . '</span>';
	echo '</li>';

	echo '</ul>';
}

/**
 * Profile networks selection — modern tile list with a Configure drawer.
 *
 * Renders only the selected profile networks (previously the checked networks of
 * the profile_networks checkbox list) in their saved order. Each tile opens a
 * right-aligned drawer with the network's fields (address, display text, count).
 * The drawer stages a draft; values are committed into the settings form and
 * saved together with the rest of the options (the pending state is JS-managed).
 *
 * @param string $position
 * @param string $options_group
 */
function essb_component_profile_network_selection($position = 'profile', $options_group = 'essb_options')
{
	static $drawer_rendered = false;

	$svg_support = essb_using_svg_icons_sharing();

	if (!class_exists('ESSB_SVG_Icons')) {
		include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
	}

	$active_networks = essb_option_value($position . '_networks');
	if (!is_array($active_networks)) {
		$active_networks = array();
	}

	$order = essb_option_value($position . '_networks_order');
	$order = is_array($order) ? ESSBSocialProfilesHelper::simplify_order_list($order) : array();

	// Build the ordered list of selected networks (saved order first, then any
	// network that is active but missing from the order list).
	$ordered_networks = array();
	foreach ($order as $network) {
		if (in_array($network, $active_networks) && !in_array($network, $ordered_networks)) {
			$ordered_networks[] = $network;
		}
	}
	foreach ($active_networks as $network) {
		if (!in_array($network, $ordered_networks)) {
			$ordered_networks[] = $network;
		}
	}

	$all_networks = essb_available_social_profiles();
	$colors = essb_network_selection_colors();
	$salt = mt_rand();

	$svg_handle = '<svg width="8" height="14" viewBox="0 0 8 14" fill="currentColor" aria-hidden="true"><circle cx="1.5" cy="2" r="1.2"/><circle cx="6.5" cy="2" r="1.2"/><circle cx="1.5" cy="7" r="1.2"/><circle cx="6.5" cy="7" r="1.2"/><circle cx="1.5" cy="12" r="1.2"/><circle cx="6.5" cy="12" r="1.2"/></svg>';
	$svg_cog = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
	$svg_times = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';
	$svg_plus = '<svg width="11" height="11" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M6 2.25v7.5M2.25 6h7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

	echo '<ul class="essb-component-networkselect essb-component-networkselect-new essb-componentkey-' . esc_attr($salt) . '" id="essb-componentkey-' . esc_attr($salt) . '" data-key="' . esc_attr($salt) . '" data-position="' . esc_attr($position) . '" data-group="' . esc_attr($options_group) . '">';

	foreach ($ordered_networks as $network) {

		$network_name = isset($all_networks[$network]) ? $all_networks[$network] : $network;

		$display_key = $network;
		if ($display_key == 'instgram') {
			$display_key = 'instagram';
		}
		if ($display_key == 'twitter') {
			$display_key = 'twitter-x';
		}

		$address = essb_option_value('profile_' . $network);
		$text = essb_option_value('profile_text_' . $network);
		$count = essb_option_value('profile_count_' . $network);

		$tile_value = ($address != '') ? $address : $text;

		$icon_network = ($network == 'twitter') ? 'twitter_x' : (($network == 'instgram') ? 'instagram' : $network);
		$custom_svg_icon = '';

		if ($svg_support) {
			$custom_svg_icon = ESSB_SVG_Icons::get_icon($display_key);
		}

		$network_initial = '';
		if ($custom_svg_icon == '') {
			$network_initial = function_exists('mb_substr') ? mb_substr($network_name, 0, 1, 'UTF-8') : substr($network_name, 0, 1);
		}

		$brand = isset($colors[$icon_network]) ? $colors[$icon_network] : '#6b7280';
		$tint = essb_component_network_color_tint($brand, 0.93);

		echo '<li class="essb-admin-networkselect-single essb-ns-tile" data-network="' . esc_attr($network) . '" data-key="' . esc_attr($salt) . '" style="--brand:' . esc_attr($brand) . ';--brand-tint:' . esc_attr($tint) . '">';

		echo '<span class="essb-ns-handle" title="' . esc_attr__('Drag to reorder', 'essb') . '">' . $svg_handle . '</span>';
		echo '<span class="essb-ns-icon">' . ($custom_svg_icon != '' ? $custom_svg_icon : '<span class="essb-ns-icon-letter">' . esc_html($network_initial) . '</span>') . '</span>';
		echo '<span class="essb-ns-info">';
		echo '<span class="essb-sns-name essb-ns-name">' . esc_html($network_name) . '</span>';
		echo '<span class="essb-single-network-name essb-ns-text">';
		echo '<span class="essb-ns-tag essb-ns-tag-pending" hidden>' . esc_html__('pending', 'essb') . '</span>';
		echo '<span class="essb-ns-text-value">' . esc_html($tile_value) . '</span>';
		echo '</span>';
		echo '</span>';

		echo '<span class="essb-ns-actions">';
		echo '<button type="button" class="essb-ns-iconbtn essb-ns-configure" title="' . esc_attr__('Configure network', 'essb') . '">' . $svg_cog . '</button>';
		echo '<button type="button" class="essb-ns-iconbtn essb-ns-remove" title="' . esc_attr__('Remove network', 'essb') . '">' . $svg_times . '</button>';
		echo '</span>';

		echo '<input type="hidden" name="' . esc_attr($options_group) . '[' . esc_attr($position) . '_networks][]" value="' . esc_attr($network) . '"/>';
		echo '<input type="hidden" name="' . esc_attr($options_group) . '[' . esc_attr($position) . '_networks_order][]" value="' . esc_attr($network) . '|' . esc_attr($network_name) . '"/>';
		echo '</li>';
	}

	echo '<li class="essb-ns-add" data-network="add" role="button" tabindex="0">';
	echo '<span class="essb-ns-add-plus">' . $svg_plus . '</span>';
	echo '<span>' . esc_html__('Add networks', 'essb') . '</span>';
	echo '</li>';

	echo '</ul>';

	// Staged hidden fields for every available network. Networks that are not
	// currently selected keep their stored values (nothing is lost on save); the
	// drawer commits its draft into the inputs of the network being configured.
	echo '<div class="essb-pn-staged" id="essb-pn-staged">';
	foreach ($all_networks as $network => $network_name) {
		$address = essb_option_value('profile_' . $network);
		$text = essb_option_value('profile_text_' . $network);
		$count = essb_option_value('profile_count_' . $network);

		echo '<div class="essb-pn-staged-network" data-network="' . esc_attr($network) . '">';
		echo '<input type="hidden" class="essb-pn-staged-address" name="' . esc_attr($options_group) . '[profile_' . esc_attr($network) . ']" value="' . esc_attr($address) . '"/>';
		echo '<input type="hidden" class="essb-pn-staged-text" name="' . esc_attr($options_group) . '[profile_text_' . esc_attr($network) . ']" value="' . esc_attr($text) . '"/>';
		echo '<input type="hidden" class="essb-pn-staged-count" name="' . esc_attr($options_group) . '[profile_count_' . esc_attr($network) . ']" value="' . esc_attr($count) . '"/>';
		echo '</div>';
	}
	echo '</div>';

	// The configure drawer is rendered once per page. It is emitted on
	// admin_footer so that it lives outside of any transformed ancestor
	// (e.g. .essb-flex-grid): a non-none transform on an ancestor makes it
	// the containing block for position: fixed descendants, which would
	// offset the drawer against the settings container instead of the
	// viewport and generate horizontal overflow.
	if (!$drawer_rendered) {
		$drawer_rendered = true;
		add_action('admin_footer', 'essb_component_profile_network_drawer');
	}
}

/**
 * Shared drawer used by the profile networks selection.
 */
function essb_component_profile_network_drawer()
{
	$designs = function_exists('essb_optin_designs') ? essb_optin_designs() : array();
	?>
	<div class="essb-dr-overlay" id="essb-pn-config-overlay"></div>
	<div class="essb-dr-drawer essb-ui" id="essb-pn-config-wrap">

		<div class="essb-dr-header">
			<div class="essb-dr-title"><?php esc_html_e('Configure Network', 'essb'); ?></div>
			<button type="button" class="essb-dr-close" id="essb-pn-config-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
		</div>

		<div class="essb-dr-body">
			<h2 class="essb-dr-pane-title" id="essb-pn-config-name"></h2>
			<p class="essb-dr-pane-desc"><?php esc_html_e('Set the details for this profile. Changes are staged and applied when you save the plugin settings.', 'essb'); ?></p>

			<div class="essb-dr-field" id="essb-pn-config-address-field">
				<label class="essb-dr-field-label" for="essb-pn-config-address"><?php esc_html_e('Full address to profile', 'essb'); ?></label>
				<input type="text" class="essb-dr-input" id="essb-pn-config-address" data-pn-field="address" />
				<span class="essb-dr-field-desc"><?php esc_html_e('Enter the address to your profile in the social network.', 'essb'); ?></span>
			</div>

			<div class="essb-dr-field" id="essb-pn-config-design-field" hidden>
				<label class="essb-dr-field-label" for="essb-pn-config-design"><?php esc_html_e('Form design', 'essb'); ?></label>
				<select class="essb-dr-select" id="essb-pn-config-design" data-pn-field="design">
					<?php foreach ($designs as $key => $label) : ?>
						<option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="essb-dr-field">
				<label class="essb-dr-field-label" for="essb-pn-config-text"><?php esc_html_e('Display text with icon', 'essb'); ?></label>
				<input type="text" class="essb-dr-input" id="essb-pn-config-text" data-pn-field="text" />
				<span class="essb-dr-field-desc"><?php esc_html_e('Custom text shown with the link to your social profile.', 'essb'); ?></span>
			</div>

			<div class="essb-dr-field">
				<label class="essb-dr-field-label" for="essb-pn-config-count"><?php esc_html_e('Display followers\' value', 'essb'); ?></label>
				<input type="text" class="essb-dr-input" id="essb-pn-config-count" data-pn-field="count" />
				<span class="essb-dr-field-desc"><?php esc_html_e('Manually input a number or a custom text. Leave empty to hide.', 'essb'); ?></span>
			</div>
		</div>

		<div class="essb-dr-footer">
			<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-pn-config-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
			<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-pn-config-save"><?php esc_html_e('Update', 'essb'); ?></button>
		</div>

	</div>
	<?php
}

/**
 * Modern multi-select component (replaces Select2).
 *
 * Behaves like the Select2 multi-selects: pick many values saved to
 * <group>[<field>][]. Renders chips, an inline search and a dropdown; the
 * JS (essb-multiselect.js) handles the interactions.
 *
 * @param string $field
 * @param array  $options         value => label
 * @param mixed  $value           array of selected values
 * @param string $group
 * @param array  $element_options
 */
function essb_component_multiselect($field, $options, $value, $group = 'essb_options', $element_options = array())
{
	if (!is_array($value)) {
		$value = ($value === '' || $value === null) ? array() : array($value);
	}

	$placeholder = isset($element_options['placeholder']) && $element_options['placeholder'] != '' ? $element_options['placeholder'] : esc_html__('Add…', 'essb');

	$colors = essb_network_selection_colors();

	$opts = array();
	$byValue = array();
	foreach ($options as $key => $label) {
		$key = (string) $key;
		$color = '';
		if (isset($colors[$key])) {
			$color = $colors[$key];
		} else if ($key == 'twitter' && isset($colors['twitter_x'])) {
			$color = $colors['twitter_x'];
		} else if ($key == 'instgram' && isset($colors['instagram'])) {
			$color = $colors['instagram'];
		}
		$opt = array('value' => $key, 'label' => $label, 'color' => $color);
		$opts[] = $opt;
		$byValue[$key] = $opt;
	}

	echo '<div class="essb-multiselect" data-name="' . esc_attr($group . '[' . $field . ']') . '" data-options="' . esc_attr(wp_json_encode($opts)) . '">';
	echo '<div class="essb-ms-control">';

	echo '<span class="essb-ms-chips">';
	foreach ($value as $v) {
		$v = (string) $v;
		$opt = isset($byValue[$v]) ? $byValue[$v] : array('label' => $v, 'color' => '');
		$dot = $opt['color'] != '' ? '<span class="essb-ms-dot" style="background:' . esc_attr($opt['color']) . '"></span>' : '';
		echo '<span class="essb-ms-chip" data-value="' . esc_attr($v) . '">' . $dot . '<span class="essb-ms-chip-label">' . esc_html($opt['label']) . '</span><button type="button" class="essb-ms-remove" data-value="' . esc_attr($v) . '" title="' . esc_attr__('Remove', 'essb') . '">&times;</button></span>';
	}
	echo '</span>';

	echo '<input type="text" class="essb-ms-search" placeholder="' . esc_attr($placeholder) . '"/>';
	echo '<span class="essb-ms-caret">&#9662;</span>';
	echo '<div class="essb-ms-menu" hidden></div>';

	echo '<span class="essb-ms-hidden">';
	foreach ($value as $v) {
		echo '<input type="hidden" name="' . esc_attr($group . '[' . $field . '][]') . '" value="' . esc_attr((string) $v) . '"/>';
	}
	echo '</span>';

	echo '</div>';
	echo '</div>';
}

function essb_component_base_dummy_share()
{
	return array(
		"url" => "",
		"title" => "",
		"image" => "",
		"description" => "",
		"twitter_user" => "",
		"twitter_hashtags" => "",
		"twitter_tweet" => "",
		"post_id" => 0,
		"user_image_url" => "",
		"title_plain" => "",
		'short_url_whatsapp' => '',
		'short_url_twitter' => '',
		'short_url' => '',
		'pinterest_image' => "",
		"full_url" => ""
	);
}

function essb_component_base_dummy_style($user_counter = false, $counter_pos = '', $total_counter_pos = '')
{
	$style = array("button_style" => "button", "align" => "left", "button_width" => "auto", "counters" => false);

	if ($user_counter) {
		$style['show_counter'] = 1;
		$style['counters'] = true;
		if ($counter_pos != '') {
			$style['counter_pos'] = $counter_pos;
		}

		if ($total_counter_pos != '') {
			$style['total_counter_pos'] = $total_counter_pos;
		}
		$style['demo_counter'] = "yes";
	} else {
		$style['show_counter'] = 0;
		$style['counter_pos'] = 'hidden';
		$style['total_counter_pos'] = 'hidden';
	}

	$style['button_align'] = 'left';
	$style['counter_pos'] = 'hidden';
	$style['total_counter_hidden_till'] = '';
	$style['nospace'] = false;
	$style['full_url'] = false;
	$style['message_share_buttons'] = '';
	$style['message_share_before_buttons'] = '';
	$style['is_mobile'] = false;
	$style['amp'] = false;
	$style['native'] = false;
	$style['total_counter_afterbefore_text'] = '';

	return $style;
}

function essb_component_advanced_select_with_picker($position = '', $options_group = 'essb_options', $options = array())
{
	$value_field_id = $options['field_id'];
	$value_text_id = '';

	if ($value_field_id == 'style' && $position != '') {
		$value_field_id = $position . '_template';
	}

	if ($value_field_id == 'button_style' && $position != '') {
		$value_field_id = $position . '_button_style';
	}

	if ($value_field_id == 'css_animations' && $position != '') {
		$value_field_id = $position . '_css_animations';
	}

	if ($value_field_id == 'counter_pos' && $position != '') {
		$value_field_id = $position . '_counter_pos';
	}

	if ($value_field_id == 'total_counter_pos' && $position != '') {
		$value_field_id = $position . '_total_counter_pos';
	}

	$selected = essb_option_value($value_field_id);
	$source = $options['source'];

	if (($options['field_id'] == 'counter_pos' || $options['field_id'] == 'total_counter_pos') && $selected == '') {
		$selected = 'hidden';
	}

	echo '<div class="essb-ui-flex essb-ui-gap-1.5">';
	echo '<select id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . ' input-element stretched" name="' . esc_attr($options_group) . '[' . esc_attr($value_field_id) . ']">';
	foreach ($source as $key => $name) {
		echo '<option value="' . esc_attr($key) . '"' . ($key == $selected ? ' selected' : '') . '>' . $name . '</option>';
	}
	echo '</select>';

	$show_buttons = isset($options['show_buttons']) ? $options['show_buttons'] : '';
	if (isset($options['pinterest_mode']) && $options['pinterest_mode']) {
		$show_buttons = 'pinterest';
	}

	if ($options['field_id'] == 'style') {
		$picker = $show_buttons == 'pinterest' ? '#essb-pintemplateselect' : '#essb-templateselect';
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="' . esc_attr($picker) . '" data-field-buttons="' . esc_attr($show_buttons) . '"><i class="fa fa-ellipsis-h"></i></button>';
	}

	if ($options['field_id'] == 'button_style') {
		$picker = $show_buttons == 'pinterest' ? '#essb-pinbuttonstyleselect' : '#essb-buttonstyleselect';
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="' . esc_attr($picker) . '" data-field-buttons="' . esc_attr($show_buttons) . '"><i class="fa fa-ellipsis-h"></i></button>';
	}

	if ($options['field_id'] == 'css_animations') {
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-animationsselect"><i class="fa fa-ellipsis-h"></i></button>';
	}

	if ($options['field_id'] == 'counter_pos') {
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-counterposselect"><i class="fa fa-ellipsis-h"></i></button>';
	}

	if ($options['field_id'] == 'total_counter_pos') {
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-totalcounterposselect"><i class="fa fa-ellipsis-h"></i></button>';
	}

	echo '</div>';
}

function essb_component_template_select_advanced($position = '', $options_group = 'essb_options', $show_buttons = '')
{
	$value_field_id = 'style';
	// position 
	if ($position != '') {
		$value_field_id = $position . '_template';
	}
	$value_text_id = $value_field_id . '_text';

	$selected = essb_option_value('style');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_template');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = '32';
	}
	$selected_name = '';

	$templates = essb_available_tempaltes4();
	foreach ($templates as $key => $name) {
		if ($key == $selected) {
			$selected_name = $name;
		}
	}
	echo '<div class="essb-ui-flex essb-ui-gap-1.5">';
	echo '<select id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . ' input-element stretched" name="' . esc_attr($options_group) . '[' . esc_attr($value_field_id) . ']">';
	foreach ($templates as $key => $name) {
		echo '<option value="' . esc_attr($key) . '"' . ($key == $selected ? ' selected' : '') . '>' . $name . '</option>';
	}
	echo '</select>';
	if ($show_buttons == 'pinterest') {
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-pintemplateselect" data-field-buttons="' . esc_attr($show_buttons) . '"><i class="fa fa-ellipsis-h"></i></button>';
	} else {
		echo '<button class="essb-ui-btn essb-ui-btn-outline essb-ui-btn-dark essb-ui-btn-sm essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '"  data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-templateselect" data-field-buttons="' . esc_attr($show_buttons) . '"><i class="fa fa-ellipsis-h"></i></button>';
	}
	echo '</div>';
}

function essb_component_template_select($position = '', $options_group = 'essb_options', $show_buttons = '')
{
	$value_field_id = 'style';
	// position 
	if ($position != '') {
		$value_field_id = $position . '_template';
	}
	$value_text_id = $value_field_id . '_text';

	// selected value
	$selected = essb_option_value('style');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_template');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = '32';
	}
	$selected_name = '';

	$templates = essb_available_tempaltes4();
	foreach ($templates as $key => $name) {
		if ($key == $selected) {
			$selected_name = $name;
		}
	}


	if ($show_buttons == 'pinterest') {
		echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-pintemplateselect" data-field-buttons="' . esc_attr($show_buttons) . '">';
	} else {
		echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-templateselect" data-field-buttons="' . esc_attr($show_buttons) . '">';
	}
	echo '<input type="hidden" id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . '" value="' . esc_attr($selected) . '" name="' . esc_attr($options_group) . '[' . esc_attr($value_field_id) . ']">';
	echo '<div class="inner" id="' . esc_attr($value_field_id) . '_text">';
	echo $selected_name;
	echo '</div>';
	echo '<div class="picker"><i class="fa fa-ellipsis-h"></i></div>';
	echo '</div>';
}

function essb_component_base_template_selection($position = '', $field_id = '', $field_text_id = '', $buttons = array(), $button_texts = array())
{
	$list_of_templates = essb_available_tempaltes4();

	$selected = essb_option_value('style');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_template');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = '32';
	}

	$order_buttons = $buttons;

	if (count($buttons) == 0) {
		$buttons = array('facebook', 'twitter');
		$order_buttons = $buttons;
	}

	if (count($button_texts) == 0) {
		$button_texts = array("facebook" => "Facebook", "twitter" => "Twitter", "google" => "Google");
	}

	$button_style = essb_component_base_dummy_style();

	echo '<div class="essb-component-clickholder" data-field="' . esc_attr($field_id) . '" data-field-text="' . esc_attr($field_text_id) . '">';

	foreach ($list_of_templates as $key => $name) {

		$button_style['template'] = $key;

		if (class_exists('ESSB_Short_URL')) {
			ESSB_Short_URL::deactivate();
		}

		echo '<div class="essb-component-clickselect' . ($selected == $key ? ' active' : '') . ' essb-template-select-' . esc_attr($key) . '" data-value="' . esc_attr($key) . '" data-text="' . esc_attr($name) . '">';
		echo '<div class="inner-title">' . $name . '</div>';
		echo '<div class="inner-content">' . ESSBButtonHelper::draw_share_buttons(essb_component_base_dummy_share(), $button_style, $buttons, $order_buttons, $button_texts, "shortcode", "1112233") . '</div>';
		echo '</div>';
	}

	echo '</div>';
}

function essb_component_base_button_style_selection($position = '', $pinterest_mode = false)
{
	$essb_available_buttons_style = array();
	$essb_available_buttons_style['button'] = esc_html__('Regular share buttons with icon & name/text', 'essb');
	$essb_available_buttons_style['button_name'] = esc_html__('Share button with name/text only (no icon)', 'essb');
	$essb_available_buttons_style['icon'] = esc_html__('Share button with icon only', 'essb');
	$essb_available_buttons_style['icon_hover'] = esc_html__('Share button with icon and name/text appearing on hover', 'essb');
	$essb_available_buttons_style['vertical'] = esc_html__('Vertical button', 'essb');

	$selected = essb_option_value('button_style');
	$template = essb_option_value('style');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_button_style');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = 'button';
	}

	$buttons = array('facebook', 'twitter');
	$buttons_text = array('facebook' => 'Facebook', 'twitter' => 'Twitter');

	if ($pinterest_mode) {
		$buttons = array('pinterest');
		$buttons_text = array('pinterest' => 'Pin');
	}

	$button_style = essb_component_base_dummy_style();

	echo '<div class="essb-component-clickholder" data-field="" data-field-text="">';

	foreach ($essb_available_buttons_style as $key => $name) {

		$button_style['template'] = $template;
		$button_style['button_style'] = $key;

		if (class_exists('ESSB_Short_URL')) {
			ESSB_Short_URL::deactivate();
		}

		echo '<div class="essb-component-clickselect' . ($selected == $key ? ' active' : '') . ' essb-template-select-' . esc_attr($key) . '" data-value="' . esc_attr($key) . '" data-text="' . esc_attr($name) . '">';
		echo '<div class="inner-title">' . $name . '</div>';
		echo '<div class="inner-content">' . ESSBButtonHelper::draw_share_buttons(essb_component_base_dummy_share(), $button_style, $buttons, $buttons, $buttons_text, "shortcode", "1112233") . '</div>';
		echo '</div>';
	}

	echo '</div>';
}

function essb_component_buttonstyle_select($position = '', $options_group = 'essb_options', $pinterest_mode = false)
{
	$value_field_id = 'button_style';
	// position
	if ($position != '') {
		$value_field_id = $position . '_button_style';
	}
	$value_text_id = $value_field_id . '_text';

	// selected value
	$selected = essb_option_value('button_style');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_button_style');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = 'button';
	}
	$selected_name = '';

	$essb_available_buttons_style = array();
	$essb_available_buttons_style['button'] = esc_html__('Regular share buttons with icon & name/text', 'essb');
	$essb_available_buttons_style['button_name'] = esc_html__('Share button with name/text only (no icon)', 'essb');
	$essb_available_buttons_style['icon'] = esc_html__('Share button with icon only', 'essb');
	$essb_available_buttons_style['icon_hover'] = esc_html__('Share button with icon and name/text appearing on hover', 'essb');
	$essb_available_buttons_style['vertical'] = esc_html__('Vertical button', 'essb');
	foreach ($essb_available_buttons_style as $key => $name) {
		if ($key == $selected) {
			$selected_name = $name;
		}
	}

	if ($pinterest_mode) {
		echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-pinbuttonstyleselect">';
	} else {
		echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-buttonstyleselect">';
	}
	echo '<input type="hidden" id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . '" value="' . esc_attr($selected) . '" name="' . esc_attr($options_group) . '[' . esc_attr($value_field_id) . ']">';
	echo '<div class="inner" id="' . esc_attr($value_field_id) . '_text">';
	echo $selected_name;
	echo '</div>';
	echo '<div class="picker"><i class="fa fa-ellipsis-h"></i></div>';
	echo '</div>';
}


function essb_component_base_counter_position_selection($position = '', $field_id = '', $field_text_id = '')
{
	$list_of_templates = essb_avaliable_counter_positions();

	$selected = essb_option_value('counter_pos');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_counter_pos');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	$template = essb_option_value('style');
	if ($selected == '') {
		$selected = 'hidden';
	}


	echo '<div class="essb-component-clickholder" data-field="' . esc_attr($field_id) . '" data-field-text="' . esc_attr($field_text_id) . '">';

	foreach ($list_of_templates as $key => $name) {

		$button_style = essb_component_base_dummy_style(true, $key, 'hidden');
		$button_style['template'] = $template;
		$button_style['counter_pos'] = $key;

		if (class_exists('ESSB_Short_URL')) {
			ESSB_Short_URL::deactivate();
		}

		echo '<div class="essb-component-clickselect' . ($selected == $key ? ' active' : '') . ' essb-counterpos-select-' . esc_attr($key) . '" data-value="' . esc_attr($key) . '" data-text="' . esc_attr($name) . '">';
		echo '<div class="inner-title">' . $name . '</div>';
		echo '<div class="inner-content">' . ESSBButtonHelper::draw_share_buttons(essb_component_base_dummy_share(), $button_style, array("facebook", "twitter"), array("facebook", "twitter", "google"), array("facebook" => "Facebook", "twitter" => "Twitter", "google" => "Google"), "shortcode", "1112233") . '</div>';
		echo '</div>';
	}

	echo '</div>';
}

function essb_component_counterpos_select($position = '', $options_group = 'essb_options')
{
	$value_field_id = 'counter_pos';
	// position
	if ($position != '') {
		$value_field_id = $position . '_counter_pos';
	}
	$value_text_id = $value_field_id . '_text';

	// selected value
	$selected = essb_option_value('counter_pos');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_counter_pos');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = 'hidden';
	}
	$selected_name = '';

	$list = essb_avaliable_counter_positions();
	foreach ($list as $key => $name) {
		if ($key == $selected) {
			$selected_name = $name;
		}
	}

	echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-counterposselect">';
	echo '<input type="hidden" id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . '" value="' . esc_attr($selected) . '" name="' . esc_attr($options_group) . '[' . esc_attr($value_field_id) . ']">';
	echo '<div class="inner" id="' . esc_attr($value_field_id) . '_text">';
	echo $selected_name;
	echo '</div>';
	echo '<div class="picker"><i class="fa fa-ellipsis-h"></i></div>';
	echo '</div>';
}

// Total Counter Position
function essb_component_base_total_counter_position_selection($position = '', $field_id = '', $field_text_id = '')
{
	$list_of_templates = essb_avaiable_total_counter_position();

	$selected = essb_option_value('total_counter_pos');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_total_counter_pos');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	$template = essb_option_value('style');
	if ($selected == '') {
		$selected = 'hidden';
	}


	echo '<div class="essb-component-clickholder" data-field="' . esc_attr($field_id) . '" data-field-text="' . esc_attr($field_text_id) . '">';

	foreach ($list_of_templates as $key => $name) {

		$button_style = essb_component_base_dummy_style(true, $key, 'hidden');
		$button_style['template'] = $template;
		$button_style['total_counter_pos'] = $key;

		if (class_exists('ESSB_Short_URL')) {
			ESSB_Short_URL::deactivate();
		}

		echo '<div class="essb-component-clickselect' . ($selected == $key ? ' active' : '') . ' essb-counterpos-select-' . esc_attr($key) . '" data-value="' . esc_attr($key) . '" data-text="' . esc_attr($name) . '">';
		echo '<div class="inner-title">' . $name . '</div>';
		echo '<div class="inner-content">' . ESSBButtonHelper::draw_share_buttons(essb_component_base_dummy_share(), $button_style, array("facebook", "twitter"), array("facebook", "twitter", "google"), array("facebook" => "Facebook", "twitter" => "Twitter", "google" => "Google"), "shortcode", "1112233") . '</div>';
		echo '</div>';
	}

	echo '</div>';
}

function essb_component_totalcounterpos_select($position = '', $options_group = 'essb_options')
{
	$value_field_id = 'total_counter_pos';
	// position
	if ($position != '') {
		$value_field_id = $position . '_total_counter_pos';
	}
	$value_text_id = $value_field_id . '_text';

	// selected value
	$selected = essb_option_value('total_counter_pos');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_total_counter_pos');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = 'hidden';
	}
	$selected_name = '';

	$list = essb_avaiable_total_counter_position();
	foreach ($list as $key => $name) {
		if ($key == $selected) {
			$selected_name = $name;
		}
	}

	echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-totalcounterposselect">';
	echo '<input type="hidden" id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . '" value="' . esc_attr($selected) . '" name="' . esc_attr($options_group) . '[' . esc_attr($value_field_id) . ']">';
	echo '<div class="inner" id="' . esc_attr($value_field_id) . '_text">';
	echo $selected_name;
	echo '</div>';
	echo '<div class="picker"><i class="fa fa-ellipsis-h"></i></div>';
	echo '</div>';
}

function essb_component_options_group_select($field = '', $values = array(), $size = '', $default_value = '', $options_group = 'essb_options', $custom_class = '')
{
	$value = essb_option_value($field);

	if ($default_value != '' && $value == '') {
		$value = $default_value;
	}

	if ($size != '') {
		$size = ' ' . $size;
	}

	if ($custom_class != '') {
		$custom_class = ' ' . $custom_class;
	}

	echo '<div class="essb-component-toggleselect essb-component-' . esc_attr($field) . esc_attr($size) . esc_attr($custom_class) . '">';
	echo '<input type="hidden" name="' . esc_attr($options_group) . '[' . esc_attr($field) . ']" id="essb_options_' . esc_attr($field) . '" value="' . esc_attr($value) . '" class="toggleselect-holder"/>';

	foreach ($values as $key => $data) {
		$title = isset($data['title']) ? $data['title'] : '';
		$content = isset($data['content']) ? $data['content'] : '';
		$isText = isset($data['isText']) ? true : false;
		$customPadding = isset($data['padding']) ? $data['padding'] : '';

		if ($customPadding != '') {
			$customPadding = ' style="padding:' . $customPadding . '"';
		}

		if ($isText) {
			$content = '<span class="text">' . $content . '</span>';
		}

		echo '<span class="toggleselect-item toggleselect-item-' . esc_attr($field) . esc_attr($key) . ($key == $value ? ' active' : '') . '" data-value="' . esc_attr($key) . '" title="' . esc_attr($title) . '"' . $customPadding . '>';
		echo $content;
		echo '</span>';
	}

	echo '</div>';
}

function essb_component_options_group_select_multiple($field = '', $values = array(), $size = '', $default_value = array(), $options_group = 'essb_options')
{
	$value = essb_option_value($field);

	if (!is_array($default_value)) {
		$default_value = array();
	}

	if ($size != '') {
		$size = ' ' . $size;
	}

	echo '<div class="essb-component-groupselect essb-component-' . esc_attr($field) . esc_attr($size) . '">';

	foreach ($values as $key => $data) {
		$title = isset($data['title']) ? $data['title'] : '';
		$content = isset($data['content']) ? $data['content'] : '';
		$isText = isset($data['isText']) ? true : false;
		$customPadding = isset($data['padding']) ? $data['padding'] : '';

		if ($customPadding != '') {
			$customPadding = ' style="padding:' . $customPadding . '"';
		}

		if ($isText) {
			$content = '<span class="text">' . $content . '</span>';
		}

		$isChecked = in_array($key, $default_value);

		echo '<span class="toggleselect-item' . ($isChecked ? ' active' : '') . '" data-value="' . esc_attr($key) . '" title="' . esc_attr($title) . '"' . $customPadding . '>';
		echo $content;
		echo '<input type="checkbox" name="' . esc_attr($options_group) . '[' . esc_attr($field) . '][]" id="essb_options_' . esc_attr($field) . '_' . esc_attr($key) . '" value="' . esc_attr($key) . '" class="toggleselect-holder" ' . ($isChecked ? 'checked="checked"' : '') . '/>';
		echo '</span>';
	}

	echo '</div>';
}

// Animations
function essb_component_base_animation_selection($position = '', $field_id = '', $field_text_id = '')
{
	$list_of_templates = essb_available_animations(true);

	$selected = essb_option_value('css_animations');

	$template = essb_option_value('style');
	if ($selected == '') {
		$selected = '';
	}


	echo '<div class="essb-component-clickholder" data-field="' . esc_attr($field_id) . '" data-field-text="' . esc_attr($field_text_id) . '">';

	foreach ($list_of_templates as $key => $name) {

		$button_style = essb_component_base_dummy_style(false, $key, 'hidden');
		$button_style['template'] = $template;
		$button_style['button_animation'] = $key;

		if (class_exists('ESSB_Short_URL')) {
			ESSB_Short_URL::deactivate();
		}

		echo '<div class="essb-component-clickselect' . ($selected == $key ? ' active' : '') . ' essb-counterpos-select-' . esc_attr($key) . '" data-value="' . esc_attr($key) . '" data-text="' . esc_attr($name) . '">';
		echo '<div class="inner-title">' . $name . '</div>';
		echo '<div class="inner-content">' . ESSBButtonHelper::draw_share_buttons(essb_component_base_dummy_share(), $button_style, array("facebook", "twitter"), array("facebook", "twitter", "google"), array("facebook" => "Facebook", "twitter" => "Twitter", "google" => "Google"), "shortcode", "1112233") . '</div>';
		echo '</div>';
	}

	echo '</div>';
}

function essb_component_animation_select($position = '', $options_group = 'essb_options')
{
	$value_field_id = 'css_animations';
	// position
	if ($position != '') {
		$value_field_id = $position . '_css_animations';
	}
	$value_text_id = $value_field_id . '_text';

	// selected value
	$selected = essb_option_value('css_animations');
	if ($position != '') {
		$position_selected = essb_option_value($position . '_css_animations');
		if ($position_selected != '') {
			$selected = $position_selected;
		}
	}

	if ($selected == '') {
		$selected = '';
	}
	$selected_name = '';

	$list = essb_available_animations(true);
	foreach ($list as $key => $name) {
		if ($key == $selected) {
			$selected_name = $name;
		}
	}

	echo '<div class="essb-popup-select essb-popup-select-' . esc_attr($value_field_id) . '" data-field="' . esc_attr($value_field_id) . '" data-field-text="' . esc_attr($value_text_id) . '" data-field-window="#essb-animationsselect">';
	echo '<input type="hidden" id="essb_field_' . esc_attr($value_field_id) . '" class="essb_field_' . esc_attr($value_field_id) . '" value="' . esc_attr($selected) . '" name="' . $options_group . '[' . $value_field_id . ']">';
	echo '<div class="inner" id="' . esc_attr($value_field_id) . '_text">';
	echo $selected_name;
	echo '</div>';
	echo '<div class="picker"><i class="fa fa-ellipsis-h"></i></div>';
	echo '</div>';
}

function essb_component_single_position_select($positions, $field_id = '', $options_group = 'essb_options')
{
	$value = essb_option_value($field_id);

	echo '<div class="essb-position-select essb-single-position-select">';

	foreach ($positions as $key => $data) {

		$image = isset($data['image']) ? $data['image'] : '';
		$label = isset($data['label']) ? $data['label'] : '';
		$desc = isset($data['desc']) ? $data['desc'] : '';
		$link = isset($data['link']) ? $data['link'] : '';

		$pathToImages = ESSB3_PLUGIN_URL . '/';
		if (strpos($image, 'http://') !== false || strpos($image, 'https://') !== false) {
			$pathToImages = '';
		}

		echo '<div class="essb-single essb-single-' . esc_attr($key) . ($key == $value ? ' active' : '') . '" data-value="' . esc_attr($key) . '">';
		echo '<div class="icon"><img src="' . esc_url($pathToImages . $image) . '" title="' . esc_attr($label) . '"/>';
		echo '<div class="active-mark" title="Active Position"><i class="ti-check-box"></i></div>';

		if ($link != '') {
			$link_parts = explode('|', $link);
			echo '<div class="customize" title="Personalize Display Options" data-menu="' . esc_attr($link_parts[0]) . '" data-sub-menu="' . esc_attr($link_parts[1]) . '" data-tab="' . esc_attr($link_parts[2]) . '"><i class="ti-settings"></i></div>';
		}



		echo '</div>';
		echo '<div class="title">' . $label;

		if ($desc != '') {
			echo '<div class="description">' . $desc . '</div>';
		}
		echo '</div>';

		echo '</div>';
	}

	echo '<input type="hidden" name="' . $options_group . '[' . $field_id . ']" id="essb_component_' . $field_id . '" value="' . esc_attr($value) . '" class="value-holder"/>';

	echo '</div>';
}

function essb_component_multi_position_select($positions, $field_id = '', $options_group = 'essb_options')
{
	$value = essb_option_value($field_id);
	if (!is_array($value)) {
		$value = array();
	}

	echo '<div class="essb-position-select essb-multi-position-select">';

	foreach ($positions as $key => $data) {

		$image = isset($data['image']) ? $data['image'] : '';
		$label = isset($data['label']) ? $data['label'] : '';
		$desc = isset($data['desc']) ? $data['desc'] : '';
		$link = isset($data['link']) ? $data['link'] : '';
		$active = in_array($key, $value);

		$pathToImages = ESSB3_PLUGIN_URL . '/';
		if (strpos($image, 'http://') !== false || strpos($image, 'https://') !== false) {
			$pathToImages = '';
		}

		echo '<div class="essb-single essb-single-' . esc_attr($key) . ($active ? ' active' : '') . '" data-value="' . esc_attr($key) . '">';
		echo '<div class="icon"><img src="' . esc_url($pathToImages . $image) . '" title="' . esc_attr($label) . '"/>';
		echo '<div class="active-mark" title="Active Position"><i class="ti-check-box"></i></div>';

		if ($link != '') {
			$link_parts = explode('|', $link);
			echo '<div class="customize" title="Personalize Display Options" data-menu="' . esc_attr($link_parts[0]) . '" data-sub-menu="' . esc_attr($link_parts[1]) . '" data-tab="' . esc_attr($link_parts[2]) . '"><i class="ti-settings"></i></div>';
		}


		echo '</div>';
		echo '<div class="title">' . $label;

		if ($desc != '') {
			echo '<div class="description">' . $desc . '</div>';
		}
		echo '</div>';

		echo '<input type="checkbox" name="' . $options_group . '[' . $field_id . '][]" id="essb_component_' . $field_id . '_' . $key . '" value="' . $key . '" class="value-holder" ' . ($active ? 'checked="checked"' : '') . '/>';

		echo '</div>';
	}

	echo '</div>';
}

/**
 * Register an advanced options small tile inside the menu
 * 
 * @param unknown_type $tab_id
 * @param unknown_type $menu_id
 * @param unknown_type $title
 * @param unknown_type $subtitle
 * @param unknown_type $description
 * @param unknown_type $center
 * @param unknown_type $button_center
 * @param unknown_type $icon
 * @param unknown_type $ao_option
 * @param unknown_type $ao_option_text
 * @param unknown_type $tag
 */
function essb5_menu_advanced_options_small_tile(
	$tab_id = '',
	$menu_id = '',
	$title = '',
	$subtitle = '',
	$description = '',
	$center = 'false',
	$button_center = 'false',
	$icon = '',
	$ao_option = '',
	$ao_option_text = '',
	$ao_window_text = '',
	$tag = '',
	$custom_buttons = ''
) {

	$callback_opts = array(
		'title' => $title,
		'subtitle' => $subtitle,
		'description' => $description,
		'center' => $center,
		'button_center' => $button_center,
		'icon' => $icon,
		'ao_option' => $ao_option,
		'ao_option_text' => $ao_option_text,
		'ao_window_text' => $ao_window_text,
		'tag' => $tag,
		'custom_buttons' => $custom_buttons
	);

	ESSBOptionsStructureHelper::field_component($tab_id, $menu_id, 'essb5_advanced_options_small_settings_tile', 'false', $callback_opts);
}

/**
 * Generate a small advanced options tile. The tile will have a title, description, icon and callback button
 * to open the advanced options screen.
 * 
 * @param {array} $options Component drawing options
 * @since 5.9
 * @author appscreo
 * @package EasySocialShareButtons
 */
function essb5_advanced_options_small_settings_tile($parameters = array())
{
	$options = isset($parameters['element_options']) ? $parameters['element_options'] : array();
	$title = isset($options['title']) ? $options['title'] : '';
	$subtitle = isset($options['subtitle']) ? $options['subtitle'] : '';
	$description = isset($options['description']) ? $options['description'] : '';
	$center = isset($options['center']) ? $options['center'] : 'false';
	$button_center = isset($options['button_center']) ? $options['button_center'] : '';
	$icon = isset($options['icon']) ? $options['icon'] : '';
	$ao_option = isset($options['ao_option']) ? $options['ao_option'] : '';
	$ao_option_text = isset($options['ao_option_text']) ? $options['ao_option_text'] : esc_html__('Configure', 'essb');
	$ao_window_text = isset($options['ao_window_text']) ? $options['ao_window_text'] : '';
	$tag = isset($options['tag']) ? $options['tag'] : '';
	$custom_buttons = isset($options['custom_buttons']) ? $options['custom_buttons'] : '';

	echo '<div class="advancedoptions-tile advancedoptions-smalltile' . ($center == 'true' ? ' center-c' : '') . '">';
	echo '<div class="advancedoptions-tile-head">'; // open head

	if ($title != '') {
		echo '<div class="advancedoptions-tile-head-title"><h3>' . $title . '</h3></div>';
	}

	if ($tag != '') {
		echo '<div class="advancedoptions-tile-head-tools"><span class="status tag">' . $tag . '</span></div>';
	}

	echo '</div>'; // closing head

	if ($icon != '') {
		echo '<div class="advnacedoptions-tile-icon"><i class="' . esc_attr($icon) . '"></i></div>';
	}

	if ($subtitle != '') {
		echo '<div class="advnacedoptions-tile-subtitle"><h3>' . $subtitle . '</h3></div>';
	}

	if ($description != '') {
		echo '<div class="advancedoptions-tile-body">' . $description . '</div>';
	}

	if ($ao_option != '') {
		echo '<div class="advancedoptions-tile-foot' . ($button_center == 'true' ? ' center-b' : '') . '">';
		echo '<a href="#" class="essb-btn tile-config ao-option-callback" data-option="' . esc_attr($ao_option) . '" data-window-title="' . esc_attr($ao_window_text) . '"><i class="fa fa-cog"></i>' . $ao_option_text . '</a>';
		if ($custom_buttons != '') {
			echo $custom_buttons;
		}
		echo '</div>';
	} else if ($custom_buttons != '') {
		echo '<div class="advancedoptions-tile-foot' . ($button_center == 'true' ? ' center-b' : '') . '">';
		echo $custom_buttons;
		echo '</div>';
	}

	echo '</div>'; // closing tile
}

/**
 * Function will check a list of options to find if a value is set in one of them. If so
 * the function will return a true result
 * 
 * @param unknown_type $value_fields
 * @param unknown_type $switch_fields
 * @return {boolean}
 */
function essb5_has_setting_values($value_fields = array(), $switch_fields = array())
{
	$r = false;

	foreach ($value_fields as $field) {
		if (essb_option_value($field) != '') {
			$r = true;
			break;
		}
	}

	if (!$r) {
		foreach ($switch_fields as $field) {
			if (essb_option_bool_value($field)) {
				$r = true;
				break;
			}
		}
	}

	return $r;
}

function essb5_has_not_setting_values($value_fields = array(), $switch_fields = array())
{
	$r = false;

	foreach ($value_fields as $field) {
		if (essb_option_value($field) == '') {
			$r = true;
			break;
		}
	}

	if (!$r) {
		$one_enabled = false;
		foreach ($switch_fields as $field) {
			if (essb_option_bool_value($field)) {
				$one_enabled = true;
				break;
			}
		}

		if (!$one_enabled && count($switch_fields) > 0) {
			$r = true;
		}
	}

	return $r;
}

/**
 * Generating settings row with editor field
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 * @param unknown_type $mode
 */
function essb5_draw_editor_option($field_id, $title = '', $description = '', $mode = 'htmlmixed', $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);

	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description);
	ESSBOptionsFramework::draw_editor_field($field_id, 'essb_options', $value, $mode);
	ESSBOptionsFramework::draw_options_row_end();
}

/**
 * Generating a settings row with input field
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 * @param unknown_type $full_width
 */
function essb5_draw_input_option($field_id, $title = '', $description = '', $full_width = false, $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);
	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description, 'essb_field_' . $field_id);
	ESSBOptionsFramework::draw_input_field($field_id, $full_width, 'essb_options', $value);
	ESSBOptionsFramework::draw_options_row_end();
}

/**
 * Generate textarea field
 * @param unknown $field_id
 * @param string $title
 * @param string $description
 * @param string $user_value
 * @param string $value
 */
function essb5_draw_textarea_option($field_id, $title = '', $description = '', $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);
	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description, 'essb_field_' . $field_id);
	ESSBOptionsFramework::draw_textarea_field($field_id, 'essb_options', $value);
	ESSBOptionsFramework::draw_options_row_end();
}

function essb5_draw_field_group_open($custom_class = '')
{
	echo '<div class="essb-related-heading7 essb-related-heading7ao' . ($custom_class != '' ? ' ' . $custom_class : '') . '">';
}

function essb5_draw_field_group_close()
{
	echo '</div>';
}

/**
 * Generating a settings row with switch field
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 */
function essb5_draw_switch_option($field_id, $title = '', $description = '', $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);
	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description, 'essb_field_' . $field_id);
	ESSBOptionsFramework::draw_switch_field($field_id, 'essb_options', $value);
	ESSBOptionsFramework::draw_options_row_end();
}

function essb5_draw_help($title = '', $description = '', $buttons = array(), $in_section = 'false')
{
	$element_options = array();
	$element_options['buttons'] = $buttons;

	ESSBOptionsFramework::draw_help($title, $description, $in_section, $element_options);
}

/**
 * Output a simple heading
 * 
 * @param unknown_type $title
 * @param unknown_type $level
 */
function essb5_draw_heading($title = '', $level = '5', $desc = '', $class = '', $icon = '')
{
	ESSBOptionsFramework::draw_heading($title, $level, '', $desc, $class, $icon);
}

function essb5_draw_hint($title = '', $description = '', $icon = '', $style = '', $in_section = 'false')
{
	ESSBOptionsFramework::draw_hint($title, $description, $icon, $style, $in_section);
}

function essb5_draw_network_select($id = '', $position = '', $all_networks = false)
{
	essb_component_network_selection($position, 'essb_options', $all_networks);
}

/**
 * Generate a color picker field
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 * @param unknown_type $alpha
 */
function essb5_draw_color_option($field_id, $title = '', $description = '', $alpha = false, $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);
	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description);
	if ($alpha) {
		ESSBOptionsFramework::draw_acolor_field($field_id, 'essb_options', $value);
	} else {
		ESSBOptionsFramework::draw_color_field($field_id, 'essb_options', $value);
	}
	ESSBOptionsFramework::draw_options_row_end();
}

/**
 * Generate file selecting field
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 */
function essb5_draw_file_option($field_id = '', $title = '', $description = '', $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);
	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description);
	ESSBOptionsFramework::draw_fileselect_field($field_id, 'essb_options', $value);
	ESSBOptionsFramework::draw_options_row_end();
}

/**
 * 
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 * @param unknown_type $user_value
 * @param unknown_type $value
 */
function essb5_draw_toggle_option($field_id = '', $title = '', $description = '', $values = array(), $user_value = false, $value = '')
{
	$value = $user_value ? $value : essb_option_value($field_id);
	$value = stripslashes($value);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description);
	ESSBOptionsFramework::draw_toggle_field($field_id, $values, 'essb_options', $value);
	ESSBOptionsFramework::draw_options_row_end();
}

/**
 * Generate select value field
 * 
 * @param unknown_type $field_id
 * @param unknown_type $title
 * @param unknown_type $description
 * @param unknown_type $values
 */
function essb5_draw_select_option($field_id = '', $title = '', $description = '', $values = array(), $user_value = false, $value = '', $multiple = false)
{
	$value = $user_value ? $value : essb_option_value($field_id);
	ESSBOptionsFramework::draw_options_row_start_advanced_panel($title, $description, 'essb_field_' . $field_id);

	if ($multiple) {
		ESSBOptionsFramework::draw_select_field($field_id, $values, false, 'essb_options', $value, array('multiple' => 'true'));
	} else {
		ESSBOptionsFramework::draw_select_field($field_id, $values, false, 'essb_options', $value);
	}
	ESSBOptionsFramework::draw_options_row_end();
}

function essb5_draw_panel_start($title = '', $description = '', $icon = '', $element_options = array())
{
	ESSBOptionsFramework::draw_panel_start($title, $description, $icon, $element_options, 'essb_options');
}

function essb5_draw_panel_end()
{
	ESSBOptionsFramework::draw_panel_end();
}

function essb5_generate_code_advanced_button(
	$text = '',
	$icon = '',
	$ao_option = '',
	$class = '',
	$title = '',
	$reload = '',
	$width = '',
	$hide_save = false
) {
	$code = '';
	$code .= '<button class="essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm ao-ui-options-btn ' . esc_attr($class) . '" data-option="' . esc_attr($ao_option) . '" data-reload="' . esc_attr($reload) . '" data-title="' . esc_attr($title) . '" data-width="' . esc_attr($width) . '" data-hidesave="' . ($hide_save ? 'yes' : 'no') . '">' . esc_html($text) . '</button>';

	return $code;
}

function essb5_generate_code_advanced_setting_panel_open($title = '', $desc = '', $class = '')
{
	$code = '';
	$code .= '<div class="ao-settings-section ao-settings-section-panel ' . esc_attr($class) . ' ao-settings-section-simple-panel">';

	if ($title != '' || $desc != '') {
		$code .= '<div class="panel-title">';
		if ($title != '') {
			$code .= '<span class="title">' . esc_html($title) . '</span>';
		}
		if ($desc != '') {
			$code .= '<span class="label">' . esc_html($desc) . '</span>';
		}
		$code .= '</div>';
	}

	$code .= '<div class="panel-content">';

	return $code;
}

function essb5_generate_code_advanced_setting_panel_close()
{
	$code = '</div></div>';

	return $code;
}

function essb5_generate_code_advanced_deactivate_panel($title = '', $desc = '', $field = '', $class = '', $button_text = '', $button_icon = '', $panel_icon = '')
{
	if ($class == '') {
		$class = 'ao-' . $field;
	}
	$panel_class = $class . '-panel';

	if ($panel_icon != '') {
		$panel_icon = '<i class="ao-panel-icon ' . esc_attr($panel_icon) . '"></i>';
	}

	$code = '';
	$code .= '<div class="ao-settings-section ao-settings-section-deactivate ' . esc_attr($panel_class) . '">';

	$code .= '<div class="title-col">';

	if ($panel_icon != '') {
		$code .= '<div class="icon-holder">' . $panel_icon . '</div>';
	}
	$code .= '<div class="content-holder">';

	if ($title != '') {
		$code .= '<span class="title">' . esc_html($title) . '</span>';
	}
	if ($desc != '') {
		$code .= '<span class="label">' . esc_html($desc) . '</span>';
	}
	$code .= '</div>';

	$code .= '</div>';
	$code .= '<div class="action-col">';
	$code .= '<a href="#" class="ao-options-ui-btn-deactivate essb-ui-btn essb-ui-btn-danger essb-ui-btn-sm" data-field="' . esc_attr($field) . '">' . esc_html($button_text) . '</a>';
	$code .= '</div>';
	$code .= '</div>';

	return $code;
}


/**
 * Render a modern switch panel that activates a plugin feature.
 *
 * Additional features are stored with a "deactivate" option (true = feature
 * deactivated), so the switch is inverted: ON means the feature is active.
 * The toggle saves the option and reloads the page.
 *
 * @since 11.x
 * @param string $feature Feature id from ESSBControlCenter::$feature_list
 */
function essb5_draw_activate_switch_panel($feature = '')
{
	if ($feature == '' || !class_exists('ESSBControlCenter')) {
		return;
	}

	$deactivate_option = ESSBControlCenter::get_feature_deactivate_option($feature);
	if ($deactivate_option == '') {
		return;
	}

	ESSBOptionsFramework::draw_panel_start(
		ESSBControlCenter::get_feature_title($feature),
		ESSBControlCenter::get_feature_long_description($feature),
		ESSBControlCenter::get_feature_icon($feature),
		array(
			'mode' => 'switch',
			'switch_id' => $deactivate_option,
			'switch_invert' => 'true',
			'switch_submit' => 'true',
			'switch_on' => esc_html__('Active', 'essb'),
			'switch_off' => esc_html__('Not active', 'essb')
		),
		'essb_options'
	);

	ESSBOptionsFramework::draw_panel_end();
}

function essb5_generate_help_link($help_link = '')
{
	$code = '';

	if ($help_link != '') {
		$code .= '<div class="essb-help-hint">';
		$code .= '<a href="' . esc_url($help_link) . '" target="_blank">' . esc_html__('Learn more', 'essb') . ' <i class="fa fa-external-link"></i></a>';
		$code .= '</div>';
	}

	return $code;
}

/**
 * Generate a settings panel with Advanced Options button
 * 
 * @param unknown_type $title
 * @param unknown_type $desc
 * @param unknown_type $ao_option
 * @param unknown_type $class
 * @param unknown_type $button_text
 * @param unknown_type $button_icon
 * @param unknown_type $reload
 * @return string
 */
function essb5_generate_code_advanced_settings_panel(
	$title = '',
	$desc = '',
	$ao_option = '',
	$class = '',
	$button_text = '',
	$button_icon = '',
	$reload = '',
	$width = '',
	$running_tag = '',
	$panel_icon = '',
	$window_title = '',
	$hide_save = false,
	$help_link = '',
	$automation_action = '',
	$automation_message = '',
	$help_link_external = false,
	$button_url = array(),
	$quick_action = array()
) {
	if ($class == '') {
		$class = 'ao-' . $ao_option;
	}
	$panel_class = $class . '-panel';

	if ($ao_option != '') {
		$panel_class .= ' ao-panel-' . sanitize_html_class($ao_option);
	}

	if ($panel_icon != '') {
		$panel_icon = '<i class="ao-panel-icon ' . esc_attr($panel_icon) . '"></i>';
	}

	/**
	 * Provide a check for the active state of the panel option
	 */

	$has_check_settings = essb5_advanced_settings_running_checks($ao_option);
	$has_disabled_settings = essb5_advanced_settings_disabled_checks($ao_option);
	$has_notrunning_settings = essb5_advanced_settings_notrunning_checks($ao_option);
	$has_notconfigured_settings = essb5_advanced_settings_notconfigured_checks($ao_option);

	$running_code_state = '';

	if ($has_check_settings['active']) {
		$advanced_option_running = essb5_has_setting_values($has_check_settings['value'], $has_check_settings['switch']);
		if ($advanced_option_running) {
			$running_code_state = '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">' . esc_html__('Running', 'essb') . '</span>';

			$panel_class .= ' ao-active-panel';

			if (!empty($running_tag)) {
				$running_code_state = '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">' . $running_tag . '</span>';
			}
		}
	}

	/**
	 * Not running
	 */

	if ($has_notrunning_settings['active']) {
		$advanced_option_running = essb5_has_not_setting_values($has_notrunning_settings['value'], $has_notrunning_settings['switch']);

		if ($advanced_option_running) {
			$running_code_state = '<span class="essb-ui-badge essb-ui-badge-sm">' . esc_html__('Not Running', 'essb') . '</span>';
		}
	}

	/**
	 * Disabled
	 */
	if ($has_disabled_settings['active']) {
		$advanced_option_running = essb5_has_setting_values($has_disabled_settings['value'], $has_disabled_settings['switch']);

		if ($advanced_option_running) {
			$running_code_state = '<span class="essb-ui-badge essb-ui-badge-sm">' . esc_html__('Disabled', 'essb') . '</span>';
		}
	}

	/**
	 * Not Configured
	 */
	if ($has_notconfigured_settings['active']) {
		$advanced_option_running = essb5_has_not_setting_values($has_notconfigured_settings['value'], $has_notconfigured_settings['switch']);


		if ($advanced_option_running) {
			$running_code_state = '<span class="essb-ui-badge essb-ui-badge-sm">' . esc_html__('Not Configured', 'essb') . '</span>';
		}
	}


	if ($desc == '') {
		$panel_class .= ' ao-settings-nodesc';
	}

	/**
	 * The status can be shown next to the panel quick control (toggle) instead
	 * of as a badge inside the title.
	 */
	if (!empty($quick_action) && !empty($quick_action['hide_status'])) {
		$running_code_state = '';
	}

	$code = '';
	$code .= '<div class="ao-settings-section ' . esc_attr($panel_class) . '">';
	$code .= '<div class="title-col">';

	if ($panel_icon != '') {
		$code .= '<div class="icon-holder">' . $panel_icon . '</div>';
	}

	$code .= '<div class="content-holder">';

	if ($title != '') {
		$code .= '<span class="title">' . essb_wp_kses_title($title) . $running_code_state . '</span>';
	}
	if ($desc != '') {
		$code .= '<span class="label">' . esc_html($desc) . '</span>';
	}

	if ($help_link != '' || $automation_action != '') {
		$code .= '<div class="help-hint">';
		if ($help_link != '') {
			$code .= '<a href="' . esc_url($help_link) . '" target="_blank" ' . (!$help_link_external ? 'class="ao-internal-help-hint"' : '') . '>' . esc_html__('Learn more', 'essb') . ' <i class="fa fa-external-link"></i></a>';
		}
		if ($automation_action != '') {
			$code .= '<a href="#' . esc_attr($automation_action) . '" class="ao-automation-action" data-automation="' . esc_attr($automation_action) . '">' . $automation_message . ' <i class="fa fa-bolt"></i></a>';
		}

		$code .= '</div>';
	}

	if ($window_title == '') {
		$window_title = $title;
	}
	$code .= '</div>'; // content-holder
	$code .= '</div>'; // title-col
	$action_col_class = 'action-col' . (!empty($quick_action) ? ' ao-action-col-quick' : '');
	if (!empty($quick_action) && isset($quick_action['type']) && $quick_action['type'] == 'switch' && !empty($quick_action['hide_button_when_off'])) {
		$action_col_class .= ' ao-conditional-button';
	}
	$code .= '<div class="' . esc_attr($action_col_class) . '">';
	if (!empty($quick_action) && isset($quick_action['type']) && $quick_action['type'] == 'switch') {
		$qa_key = isset($quick_action['key']) ? $quick_action['key'] : '';
		$qa_component = isset($quick_action['component']) ? $quick_action['component'] : '';
		$qa_panel = isset($quick_action['panel']) ? $quick_action['panel'] : '';
		$qa_title = isset($quick_action['title']) ? $quick_action['title'] : '';
		$qa_checked = !empty($quick_action['checked']);
		$qa_active_label = isset($quick_action['active_label']) ? $quick_action['active_label'] : esc_html__('Active', 'essb');
		$qa_inactive_label = isset($quick_action['inactive_label']) ? $quick_action['inactive_label'] : esc_html__('Not active', 'essb');
		$qa_save_form = !empty($quick_action['save_form']);

		$toggle_extra_attrs = '';
		if (!$qa_save_form) {
			$toggle_extra_attrs = ' data-toggle-component="' . esc_attr($qa_component) . '" data-toggle-panel="' . esc_attr($qa_panel) . '"';
		}

		$code .= '<div class="ao-panel-toggle-control' . ($qa_checked ? ' is-active' : '') . '" data-toggle-option="' . esc_attr($qa_key) . '"' . $toggle_extra_attrs . ($qa_title != '' ? ' title="' . esc_attr($qa_title) . '"' : '') . '>';
		$code .= '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary ao-toggle-status-on">' . esc_html($qa_active_label) . '</span>';
		$code .= '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline ao-toggle-status-off">' . esc_html($qa_inactive_label) . '</span>';
		$code .= '<span class="essb-ui-switch essb-ui-switch-xl essb-ui">';
		$code .= '<input type="checkbox" name="essb_options[' . esc_attr($qa_key) . ']" ' . ($qa_checked ? 'checked="checked"' : '') . '>';
		$code .= '</span>';
		$code .= '</div>';
	} else if (!empty($quick_action) && !empty($quick_action['options'])) {
		$qa_component = isset($quick_action['component']) ? $quick_action['component'] : '';
		$qa_selected = isset($quick_action['selected']) ? $quick_action['selected'] : '';
		$qa_label = isset($quick_action['label']) ? $quick_action['label'] : esc_html__('Quick action', 'essb');

		$code .= '<select class="input-element ao-panel-quick-action" data-quick-action="' . esc_attr($qa_component) . '" aria-label="' . esc_attr($qa_label) . '">';
		foreach ($quick_action['options'] as $qa_value => $qa_option_label) {
			$code .= '<option value="' . esc_attr($qa_value) . '"' . selected($qa_selected, $qa_value, false) . '>' . esc_html($qa_option_label) . '</option>';
		}
		$code .= '</select>';
	}
	if (!empty($button_text) && !empty($button_url) && isset($button_url['component']) && $button_url['component'] != '') {
		$code .= '<button type="button" class="essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm essb-component-open-btn" data-component="' . esc_attr($button_url['component']) . '">' . esc_html($button_text) . '</button>';
	} else if (!empty($button_text) && $ao_option != '') {
		$code .= essb5_generate_code_advanced_button($button_text, $button_icon, $ao_option, $class, $window_title, $reload, $width, $hide_save);
	} else {
		if (!empty($button_text) && !empty($button_url)) {
			$url = $button_url['url'];
			$target = isset($button_url['target']) ? $button_url['target'] : '_self';

			$code .= '<a class="essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm" href="' . esc_url($url) . '" target="' . esc_attr($target) . '">' . $button_text . '</a>';
		}
	}
	$code .= '</div>';
	$code .= '</div>';

	return $code;
}

function essb5_advanced_settings_notrunning_checks($ao_option = '')
{
	$has_settings = false;
	$value_checks = array();
	$switch_checks = array();

	if ($ao_option == 'internal-counter') {
		$has_settings = true;
		$switch_checks[] = 'active_internal_counters';
		$switch_checks[] = 'active_internal_counters_advanced';
	}

	if ($ao_option == 'avoid-negative-proof') {
		$has_settings = true;
		$switch_checks[] = 'social_proof_enable';
	}

	if ($ao_option == 'share-recovery') {
		$has_settings = true;
		$switch_checks[] = 'counter_recover_active';
	}

	if ($ao_option == 'share-fake') {
		$has_settings = true;
		$switch_checks[] = 'activate_fake_counters';
	}

	if ($ao_option == 'analytics') {
		$has_settings = true;
		$switch_checks[] = 'stats_active';
	}

	if ($ao_option == 'share-conversions') {
		$has_settings = true;
		$switch_checks[] = 'conversions_lite_run';
	}

	if ($ao_option == 'share-google-analytics') {
		$has_settings = true;
		$switch_checks[] = 'activate_ga_tracking';
		$switch_checks[] = 'activate_utm';
		$switch_checks[] = 'activate_ga_layers';
		$switch_checks[] = 'activate_ga_ntg_tracking';
	}

	if ($ao_option == 'integration-mycred') {
		$has_settings = true;
		$switch_checks[] = 'mycred_activate';
		$switch_checks[] = 'mycred_activate_custom';
		$switch_checks[] = 'mycred_referral_activate';
		$switch_checks[] = 'mycred_referral_activate_shortcode';
	}

	if ($ao_option == 'integration-affiliatewp') {
		$has_settings = true;
		$switch_checks[] = 'affwp_active';
	}

	if ($ao_option == 'integration-slicewp') {
		$has_settings = true;
		$switch_checks[] = 'slicewp_active';
	}

	if ($ao_option == 'integration-affiliates') {
		$has_settings = true;
		$switch_checks[] = 'affs_active';
	}

	if ($ao_option == 'advanced-networks') {
		$has_settings = true;
		$switch_checks[] = 'activate_networks_manage';
	}

	if ($ao_option == 'advanced-networks-visibility') {
		$has_settings = true;
		$switch_checks[] = 'activate_networks_responsive';
	}

	return array('active' => $has_settings, 'value' => $value_checks, 'switch' => $switch_checks);
}

function essb5_advanced_settings_notconfigured_checks($ao_option = '')
{
	$has_settings = false;
	$value_checks = array();
	$switch_checks = array();

	if ($ao_option == 'update-counter') {

		$api = essb_sanitize_option_value('facebook_counter_api');
		if ($api == 'sharedcount') {
			$value_checks[] = 'sharedcount_token';
		} else {
			$value_checks[] = 'facebook_counter_token';
		}

		$has_settings = true;
	}

	return array('active' => $has_settings, 'value' => $value_checks, 'switch' => $switch_checks);
}

function essb5_advanced_settings_disabled_checks($ao_option = '')
{
	$has_settings = false;
	$value_checks = array();
	$switch_checks = array();

	if ($ao_option == 'internal-counter') {
		$has_settings = true;
		$switch_checks[] = 'deactivate_postcount';
	}

	return array('active' => $has_settings, 'value' => $value_checks, 'switch' => $switch_checks);
}

function essb5_advanced_settings_running_checks($ao_option = '')
{
	$has_settings = false;
	$value_checks = array();
	$switch_checks = array();

	if ($ao_option == 'internal-counter') {
		$has_settings = true;
		$switch_checks[] = 'active_internal_counters';
		$switch_checks[] = 'active_internal_counters_advanced';
	}

	if ($ao_option == 'advanced-networks') {
		$has_settings = true;
		$switch_checks[] = 'activate_networks_manage';
	}

	if ($ao_option == 'advanced-networks-visibility') {
		$has_settings = true;
		$switch_checks[] = 'activate_networks_responsive';
	}

	if ($ao_option == 'avoid-negative-proof') {
		$has_settings = true;
		$switch_checks[] = 'social_proof_enable';
	}

	if ($ao_option == 'share-recovery') {
		$has_settings = true;
		$switch_checks[] = 'counter_recover_active';
	}

	if ($ao_option == 'adaptive-styles') {
		$has_settings = true;
		$switch_checks[] = 'activate_automatic_position';
		$switch_checks[] = 'activate_automatic_mobile';
		$switch_checks[] = 'activate_automatic_mobile_content';
	}

	if ($ao_option == 'share-fake') {
		$has_settings = true;
		$switch_checks[] = 'activate_fake_counters';
	}

	if ($ao_option == 'integration-mycred') {
		$has_settings = true;
		$switch_checks[] = 'mycred_activate';
		$switch_checks[] = 'mycred_activate_custom';
		$switch_checks[] = 'mycred_referral_activate';
		$switch_checks[] = 'mycred_referral_activate_shortcode';
	}

	if ($ao_option == 'integration-affiliatewp') {
		$has_settings = true;
		$switch_checks[] = 'affwp_active';
	}

	if ($ao_option == 'integration-slicewp') {
		$has_settings = true;
		$switch_checks[] = 'slicewp_active';
	}

	if ($ao_option == 'integration-affiliates') {
		$has_settings = true;
		$switch_checks[] = 'affs_active';
	}

	if ($ao_option == 'analytics') {
		$has_settings = true;
		$switch_checks[] = 'stats_active';
	}

	if ($ao_option == 'share-conversions') {
		$has_settings = true;
		$switch_checks[] = 'conversions_lite_run';
	}

	if ($ao_option == 'share-google-analytics') {
		$has_settings = true;
		$switch_checks[] = 'activate_ga_tracking';
		$switch_checks[] = 'activate_utm';
		$switch_checks[] = 'activate_ga_layers';
		$switch_checks[] = 'activate_ga_ntg_tracking';
	}

	if ($ao_option == 'excerpts') {
		$has_settings = true;
		$switch_checks[] = 'display_excerpt';
	}

	if ($ao_option == 'style-builder') {
		$has_settings = true;
		$switch_checks[] = 'use_stylebuilder';
	}

	if ($ao_option == 'update-counter') {

		$api = essb_sanitize_option_value('facebook_counter_api');
		if ($api == 'sharedcount') {
			$value_checks[] = 'sharedcount_token';
		} else {
			$value_checks[] = 'facebook_counter_token';
		}

		$has_settings = true;
	}

	return array('active' => $has_settings, 'value' => $value_checks, 'switch' => $switch_checks);
}

function essb_generate_performance_badge()
{
	$code = '<span class="essb-badge essb-badge-performance" title="Recommended option that improves the performance">' . esc_html__('Optimization', 'essb') . '</span>';
	return $code;
}

function essb_generate_expert_badge()
{
	$code = '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-ui-badge-danger">' . esc_html__('Expert', 'essb') . '</span>';
	return $code;
}

function essb_generate_running_badge()
{
	$code = '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">' . esc_html__('Running', 'essb') . '</span>';
	return $code;
}

function essb_generate_recommended_badge()
{
	$code = '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-success">' . esc_html__('Recommended', 'essb') . '</span>';
	return $code;
}

function essb_generate_server_side_mobile_badge()
{
	$code = '<span class="essb-badge essb-badge-server-mobile" data-microtip-size="large" data-microtip-position="top-left" title="The feature requires server-side mobile detection.  If you are using a cache plugin that does not store a separate mobile cache (example: Autoptimize, WP SuperCache, W3 Total Cache) the feature may not work properly."><i class="ti-server"></i>' . esc_html__('Server', 'essb') . '</span>';
	return $code;
}

function essb_generate_mobile_badge()
{
	$code = '<span class="essb-badge essb-badge-mobile">' . esc_html__('Mobile', 'essb') . '</span>';
	return $code;
}

function essb_generate_desktop_badge()
{
	$code = '<span class="essb-badge essb-badge-desktop">' . esc_html__('Desktop', 'essb') . '</span>';
	return $code;
}


/**
 * Create an advanced visibility control box
 * @param unknown $tab
 * @param unknown $menu_id
 * @param unknown $module
 * @param string $post_types
 * @param string $id_list
 * @param string $url_list
 */
function essb_create_exclude_display_on($tab, $menu_id, $module, $post_types = true, $id_list = true, $url_list = true, $homepage = false)
{
	ESSBOptionsStructureHelper::panel_start($tab, $menu_id, esc_html__('Exclude Display On', 'essb'), '', 'fa21 fa fa-eye-slash', array("mode" => "toggle", "state" => "closed", "css_class" => "essb-auto-open"));

	if ($homepage) {
		ESSBOptionsStructureHelper::field_switch($tab, $menu_id, 'home_deactivate_' . $module, esc_html__('Deactivate on homepage', 'essb'), '');
	}

	if ($post_types) {
		ESSBOptionsStructureHelper::field_select($tab, $menu_id, 'posttype_deactivate_' . $module, esc_html__('Post types', 'essb'), '', ESSB_Plugin_Loader::supported_post_types(), '', '', 'true');
	}

	if ($id_list) {
		ESSBOptionsStructureHelper::field_textbox_stretched($tab, $menu_id, 'deactivate_on_' . $module, esc_html__('Deactivate on the following post IDs', 'essb'), esc_html__('Comma-separated: "11, 15, 125".', 'essb'));
	}

	if ($url_list) {
		ESSBOptionsStructureHelper::field_textarea($tab, $menu_id, 'url_deactivate_' . $module, esc_html__('Deactivate on the following URLs ', 'essb'), esc_html__('One per line without the domain name. Use (.*) wildcards to address multiple URLs under a given path. Example: /profile/(.*)', 'essb'), '10');
	}

	ESSBOptionsStructureHelper::panel_end($tab, $menu_id);
}

function essb_heading_with_related_section_open($tab, $menu_id, $heading = '', $icon = '', $description = '', $top_space = false)
{
	if (!empty($heading)) {
		ESSBOptionsStructureHelper::field_heading($tab, $menu_id, 'heading7', $heading, '', 'pb0' . ($top_space ? ' mt40' : ''), $icon);
	}

	ESSBOptionsStructureHelper::holder_start($tab, $menu_id, 'essb-related-heading7', '');

	if (!empty($description)) {
		ESSBOptionsStructureHelper::hint($tab, $menu_id, '', $description, '', 'glowhint');
	}
}

function essb_heading_with_related_section_close($tab, $menu_id)
{
	ESSBOptionsStructureHelper::holder_end($tab, $menu_id);
}

function essb_options_function_output_missing_addon_message()
{
	//
	echo '<div class="essb-options-hint essb-options-hint-missing-addon">';
	echo '<div class="essb-options-hint-desc">';
	echo 'This function requires a free plugin add-on. You can install all free add-ons from the plugin. <a href="' . esc_url(admin_url('admin.php?page=essb_redirect_addons')) . '">Click here to visit the add-ons list.</a>';
	echo '</div>';
	echo '</div>';
}


function essb_options_function_output_custom_content($options = array())
{
	if (isset($options['element_options']) && isset($options['element_options']['notification'])) {
		echo '<div class="essb-options-hint">';
		echo '<div class="essb-options-hint-desc">';
		echo $options['element_options']['notification'];
		echo '</div>';
		echo '</div>';
	}
}
// Appended follower network component

function essb_component_follower_network_selection($position = 'follower', $options_group = 'essb_options_fans')
{
	static $drawer_rendered = false;

	$svg_support = essb_using_svg_icons_sharing();

	if (!class_exists('ESSB_SVG_Icons')) {
		include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
	}

	$active_networks = essb_followers_option('networks');
	if (!is_array($active_networks)) {
		$active_networks = array();
	}

	$order = essb_followers_option('networks_order');
	$order = is_array($order) ? ESSBSocialFollowersCounterHelper::simplify_order_list($order) : array();

	$ordered_networks = array();
	foreach ($order as $network) {
		if (in_array($network, $active_networks) && !in_array($network, $ordered_networks)) {
			$ordered_networks[] = $network;
		}
	}
	foreach ($active_networks as $network) {
		if (!in_array($network, $ordered_networks)) {
			$ordered_networks[] = $network;
		}
	}

	$all_networks = ESSBSocialFollowersCounterHelper::available_social_networks(false);
	$fields = ESSBSocialFollowersCounterHelper::options_structure();
	$colors = essb_network_selection_colors();
	$salt = mt_rand();

	$svg_handle = '<svg width="8" height="14" viewBox="0 0 8 14" fill="currentColor" aria-hidden="true"><circle cx="1.5" cy="2" r="1.2"/><circle cx="6.5" cy="2" r="1.2"/><circle cx="1.5" cy="7" r="1.2"/><circle cx="6.5" cy="7" r="1.2"/><circle cx="1.5" cy="12" r="1.2"/><circle cx="6.5" cy="12" r="1.2"/></svg>';
	$svg_cog = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
	$svg_times = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';
	$svg_plus = '<svg width="11" height="11" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M6 2.25v7.5M2.25 6h7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

	echo '<ul class="essb-component-networkselect essb-component-networkselect-new essb-componentkey-' . esc_attr($salt) . '" id="essb-componentkey-' . esc_attr($salt) . '" data-key="' . esc_attr($salt) . '" data-position="' . esc_attr($position) . '" data-group="' . esc_attr($options_group) . '">';

	foreach ($ordered_networks as $network) {
		if (!isset($all_networks[$network])) {
			continue;
		}

		$network_name = $all_networks[$network];

		$display_key = $network;
		if ($display_key == 'instgram') {
			$display_key = 'instagram';
		}
		if ($display_key == 'twitter') {
			$display_key = 'twitter-x';
		}

		$committed = array();
		if (isset($fields[$network])) {
			foreach ($fields[$network] as $fkey => $fdef) {
				$committed[$fkey] = essb_followers_option($network . '_' . $fkey);
				if ($committed[$fkey] === '' && isset($fdef['default'])) {
					$committed[$fkey] = $fdef['default'];
				}
			}
		}

		$tile_value = '';
		foreach (array('id', 'username', 'link', 'url') as $pk) {
			if (isset($committed[$pk]) && $committed[$pk] !== '') {
				$tile_value = $committed[$pk];
				break;
			}
		}
		if ($tile_value === '') {
			foreach ($committed as $v) {
				if ($v !== '') {
					$tile_value = $v;
					break;
				}
			}
		}

		$icon_network = ($network == 'twitter') ? 'twitter_x' : (($network == 'instgram') ? 'instagram' : $network);
		$custom_svg_icon = '';
		if ($svg_support) {
			$custom_svg_icon = ESSB_SVG_Icons::get_icon($display_key);
		}

		$network_initial = '';
		if ($custom_svg_icon == '') {
			$network_initial = function_exists('mb_substr') ? mb_substr($network_name, 0, 1, 'UTF-8') : substr($network_name, 0, 1);
		}

		$brand = isset($colors[$icon_network]) ? $colors[$icon_network] : '#6b7280';
		$tint = essb_component_network_color_tint($brand, 0.93);

		echo '<li class="essb-admin-networkselect-single essb-ns-tile" data-network="' . esc_attr($network) . '" data-key="' . esc_attr($salt) . '" style="--brand:' . esc_attr($brand) . ';--brand-tint:' . esc_attr($tint) . '">';

		echo '<span class="essb-ns-handle" title="' . esc_attr__('Drag to reorder', 'essb') . '">' . $svg_handle . '</span>';
		echo '<span class="essb-ns-icon">' . ($custom_svg_icon != '' ? $custom_svg_icon : '<span class="essb-ns-icon-letter">' . esc_html($network_initial) . '</span>') . '</span>';
		echo '<span class="essb-ns-info">';
		echo '<span class="essb-sns-name essb-ns-name">' . esc_html($network_name) . '</span>';
		echo '<span class="essb-single-network-name essb-ns-text">';
		echo '<span class="essb-ns-tag essb-ns-tag-pending" hidden>' . esc_html__('pending', 'essb') . '</span>';
		echo '<span class="essb-ns-text-value">' . esc_html($tile_value) . '</span>';
		echo '</span>';
		echo '</span>';

		echo '<span class="essb-ns-actions">';
		echo '<button type="button" class="essb-ns-iconbtn essb-ns-configure" title="' . esc_attr__('Configure network', 'essb') . '">' . $svg_cog . '</button>';
		echo '<button type="button" class="essb-ns-iconbtn essb-ns-remove" title="' . esc_attr__('Remove network', 'essb') . '">' . $svg_times . '</button>';
		echo '</span>';

		echo '<input type="hidden" name="' . esc_attr($options_group) . '[essb3fans_networks][]" value="' . esc_attr($network) . '"/>';
		echo '<input type="hidden" name="' . esc_attr($options_group) . '[essb3fans_networks_order][]" value="' . esc_attr($network) . '|' . esc_attr($network_name) . '"/>';
		echo '</li>';
	}

	echo '<li class="essb-ns-add" data-network="add" role="button" tabindex="0">';
	echo '<span class="essb-ns-add-plus">' . $svg_plus . '</span>';
	echo '<span>' . esc_html__('Add networks', 'essb') . '</span>';
	echo '</li>';

	echo '</ul>';

	echo '<div class="essb-fn-staged" id="essb-fn-staged">';
	foreach ($all_networks as $network => $network_name) {
		echo '<div class="essb-fn-staged-network" data-network="' . esc_attr($network) . '">';
		if (isset($fields[$network])) {
			foreach ($fields[$network] as $fkey => $fdef) {
				$val = essb_followers_option($network . '_' . $fkey);
				if ($val === '' && isset($fdef['default'])) {
					$val = $fdef['default'];
				}
				echo '<input type="hidden" class="essb-fn-staged-field" data-network="' . esc_attr($network) . '" data-field="' . esc_attr($fkey) . '" name="' . esc_attr($options_group) . '[essb3fans_' . esc_attr($network) . '_' . esc_attr($fkey) . ']" value="' . esc_attr($val) . '"/>';
			}
		}
		echo '</div>';
	}
	echo '</div>';

	if (!$drawer_rendered) {
		$drawer_rendered = true;
		add_action('admin_footer', 'essb_component_follower_network_drawer');
	}
}

function essb_component_follower_network_drawer()
{
	?>
	<div class="essb-dr-overlay" id="essb-fn-config-overlay"></div>
	<div class="essb-dr-drawer essb-ui" id="essb-fn-config-wrap">

		<div class="essb-dr-header">
			<div class="essb-dr-title"><?php esc_html_e('Configure Network', 'essb'); ?></div>
			<button type="button" class="essb-dr-close" id="essb-fn-config-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
		</div>

		<div class="essb-dr-body">
			<h2 class="essb-dr-pane-title" id="essb-fn-config-name"></h2>
			<p class="essb-dr-pane-desc"><?php esc_html_e('Set the details for this follower network. Changes are staged and applied when you save the plugin settings.', 'essb'); ?></p>
			<div id="essb-fn-config-fields"></div>
		</div>

		<div class="essb-dr-footer">
			<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-fn-config-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
			<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-fn-config-save"><?php esc_html_e('Update', 'essb'); ?></button>
		</div>

	</div>
	<?php
}

