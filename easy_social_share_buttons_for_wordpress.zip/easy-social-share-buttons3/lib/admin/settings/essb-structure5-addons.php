<?php include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/about-page-header.php'); ?>
<?php
/**
 * ESSB Add-ons Page — Feature Card Design
 *
 * Mirrors the dashboard feature cards (lib/admin/settings/essb-structure5-home.php):
 * centered hexagon icon, centered title/description, centered link row and a
 * footer holding the status badge (left) plus the primary action (right).
 *
 * Uses ESSB_MyAddons_API::get_split_addons() which returns:
 *   [ 'featured' => [...], 'addons' => [...] ]
 * Each add-on entry matches the same structure as get_free_addons_full().
 */

if (! function_exists('get_plugins')) {
	require_once wp_normalize_path(ABSPATH . 'wp-admin/includes/plugin.php');
}

include_once ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/ui-addons.php';

$split           = ESSB_MyAddons_API::get_split_addons();
$featured_list   = isset($split['featured']) ? $split['featured'] : array();
$all_list        = isset($split['addons'])   ? $split['addons']   : array();
$current_plugins = essb_get_site_plugins();

// Collect unique categories from all add-ons for the filter bar
$all_categories = array();
foreach ($all_list as $data) {
	$cat = isset($data['category']) ? trim($data['category']) : '';
	if ($cat !== '' && ! in_array($cat, $all_categories, true)) {
		$all_categories[] = $cat;
	}
}
sort($all_categories);

$count_featured = count($featured_list);
$count_all      = count($all_list);

/**
 * Helper: render a single add-on card.
 * $section = 'featured' | 'all'
 *
 * @param string $key             Add-on slug.
 * @param array  $data            Add-on data.
 * @param array  $current_plugins Installed plugins lookup.
 * @param string $section         Section the card is rendered in.
 */
function essb_addons_render_card($key, $data, $current_plugins, $section = 'all')
{
	$state        = essb_addons_resolve_state($key, $data, $current_plugins);
	$is_featured  = ! empty($data['featured']) || $section === 'featured';
	$is_free      = isset($data['type']) && strtolower($data['type']) === 'free';
	$not_compat   = $state['not_compatible'];
	$pro_running  = $state['pro_running'];
	$active_state = $state['active'];

	$name = isset($data['name'])        ? $data['name']        : $key;
	$desc = isset($data['description']) ? $data['description'] : '';
	$cat  = isset($data['category'])    ? trim($data['category']) : '';
	$docs = isset($data['docs'])        ? $data['docs']        : '';
	$page = isset($data['page'])        ? $data['page']        : '';

	// Card classes
	$card_classes = array('essb-addons-card');
	if ($is_featured)  $card_classes[] = 'essb-addons-card-featured';
	if ($is_free)      $card_classes[] = 'essb-addons-card-type-free';
	if (! $is_free)    $card_classes[] = 'essb-addons-card-type-premium';
	if ($not_compat)   $card_classes[] = 'essb-addons-card-incompatible';
	if ($active_state) $card_classes[] = 'essb-addons-card-active';

	$cat_attr    = $cat !== '' ? ' data-addon-category="' . esc_attr(strtolower($cat)) . '"' : '';
	$type_attr   = ' data-addon-type="' . esc_attr($is_free ? 'free' : 'premium') . '"';
	$update_attr = ' data-addon-update="' . esc_attr($state['has_update'] ? 'yes' : 'no') . '"';

	echo '<div class="' . implode(' ', $card_classes) . '"' . $cat_attr . $type_attr . $update_attr . '>';

	// ---- Featured flag ----
	if ($is_featured) {
		echo '<span class="essb-addons-card-flag essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-ui-badge-info">';
		echo esc_html__('Featured', 'essb');
		echo '</span>';
	}

	// ---- Body ----
	echo '<div class="essb-addons-card-body">';

	essb_addons_render_icon($data);

	// Title
	echo '<h3 class="essb-addons-card-title">' . esc_html($name) . '</h3>';

	// Description
	// Description and notices travel together in a block that absorbs the
	// spare card height, so the chips and links below stay aligned.
	$remote_version    = $state['remote_version'];
	$installed_version = $state['installed_version'];
	$has_update        = $state['has_update'];

	echo '<div class="essb-addons-card-text">';

	echo '<p class="essb-addons-card-desc">' . esc_html($desc) . '</p>';

	// Update notice
	if ($has_update) {

		echo '<div class="essb-addons-notice essb-addons-notice-update">';

		echo '<svg viewBox="0 0 20 20">';
		echo '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3a1 1 0 102 0V7zm-1 8a1.25 1.25 0 100-2.5A1.25 1.25 0 0010 15z" clip-rule="evenodd"/>';
		echo '</svg>';

		echo sprintf(
			esc_html__('Update available: %1$s → %2$s', 'essb'),
			esc_html($installed_version),
			esc_html($remote_version)
		);

		echo '</div>';
	}

	// Incompatible notice
	if ($not_compat && !$pro_running) {
		echo '<div class="essb-addons-notice essb-addons-notice-error">';
		echo '<svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>';
		echo sprintf(esc_html__('Requires version %s', 'essb'), esc_html($state['requires']));
		echo '</div>';
	}

	// Incompatible notice — pro version running
	if ($not_compat && $pro_running) {
		echo '<div class="essb-addons-notice essb-addons-notice-error">';
		echo '<svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>';
		echo esc_html__('Pro version is currently active.', 'essb');
		echo '</div>';
	}

	echo '</div>'; // card-text

	// Meta: category + version
	echo '<div class="essb-addons-card-meta">';

	if ($cat !== '') {
		echo '<span class="essb-addons-chip">' . esc_html($cat) . '</span>';
	}

	if (!empty($remote_version)) {
		echo '<span class="essb-addons-chip essb-addons-chip-version">v' . esc_html($remote_version) . '</span>';
	}

	echo '</div>'; // card-meta

	// Centered link row — documentation and (for free add-ons) learn more.
	// Premium add-ons get their "Learn more" call to action in the footer,
	// so it is not repeated here.
	$has_links = ! empty($docs) || (! empty($page) && $is_free);

	if ($has_links) {

		echo '<div class="essb-addons-card-links">';

		if (! empty($docs)) {
			echo '<a href="' . esc_url($docs) . '" target="_blank" rel="noopener noreferrer" class="essb-ui-btn essb-ui-btn-link">';
			echo esc_html__('Documentation', 'essb');
			echo '</a>';
		}

		if (! empty($page) && $is_free) {
			echo '<a href="' . esc_url($page) . '" target="_blank" rel="noopener noreferrer" class="essb-ui-btn essb-ui-btn-link">';
			echo esc_html__('Learn more', 'essb');
			echo '</a>';
		}

		echo '</div>'; // card-links
	}

	echo '</div>'; // card-body

	// ---- Footer ----
	echo '<div class="essb-addons-card-footer">';

	// Status badges
	echo '<div class="essb-addons-card-badges">';

	if ($active_state) {
		echo '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary">';
		echo esc_html__('Active', 'essb');
		echo '</span>';
	}

	if ($is_free) {
		echo '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-ui-badge-success">';
		echo esc_html__('Free', 'essb');
		echo '</span>';
	} else {
		echo '<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-ui-badge-warning">';
		echo esc_html__('Premium', 'essb');
		echo '</span>';
	}

	echo '</div>'; // card-badges

	// Primary action
	if (! $not_compat) {

		echo '<div class="essb-addons-card-actions">';

		if ($is_free) {

			if ($has_update) {

				$update_label = $active_state
					? esc_html__('Update & Activate', 'essb')
					: esc_html__('Update', 'essb');

				echo '<a class="essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm essb-addon-update-btn" href="' . esc_url($state['update_url']) . '">';
				echo $update_label;
				echo '</a>';
			} else {

				$action_class = 'essb-ui-btn essb-ui-btn-primary essb-ui-btn-sm';
				if ('button-deactivate' === $state['command_class']) {
					$action_class .= ' essb-addons-card-btn-deactivate';
				}

				echo '<a class="' . esc_attr($action_class) . '" href="' . esc_url($state['url_command']) . '">';
				echo esc_html($state['command_text']);
				echo '</a>';
			}
		} else {

			// Premium: always a "Learn more" action button
			$learn_href = ! empty($page) ? $page : (! empty($docs) ? $docs : '#');

			echo '<a href="' . esc_url($learn_href) . '" target="_blank" rel="noopener noreferrer" class="essb-ui-btn essb-ui-btn-dark essb-ui-btn-sm">';
			echo esc_html__('Learn more', 'essb');
			echo '</a>';
		}

		echo '</div>'; // card-actions
	}

	echo '</div>'; // card-footer

	echo '</div>'; // card
}
?>

<?php essb_addons_render_styles(); ?>

<style>
	/* ============================================================
   ESSB ADD-ONS PAGE — Feature cards
   Prefix: essb-addons-
   Mirrors the dashboard feature cards (essb-df-card).
   ============================================================ */

	.essb-control-content-fullwidth {
		width: 100% !important;
	}

	.essb-addons-wrap {
		box-sizing: border-box;
		max-width: 1100px;
		margin: 0 auto;
		padding: 26px 20px 40px;
	}

	.essb-addons-wrap *,
	.essb-addons-wrap *::before,
	.essb-addons-wrap *::after {
		box-sizing: inherit;
	}

	/* ---- Section ---- */
	.essb-addons-section {
		margin-bottom: 34px;
	}

	.essb-addons-section-title {
		display: flex;
		align-items: center;
		gap: 9px;
		font-size: 18px;
		font-weight: 500;
		color: #172153;
		margin: 0 0 14px;
		padding: 0;
	}

	.essb-addons-section-count {
		font-size: 12px;
		font-weight: 600;
		color: var(--color-grey-600);
		background: var(--color-grey-100);
		border: 1px solid var(--color-grey-300);
		border-radius: 4px;
		padding: 1px 7px;
		line-height: 1.6;
	}

	/* ---- Grid ---- */
	.essb-addons-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
	}

	/* ---- Card ---- */
	.essb-addons-card {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 6px;
		padding: 20px;
		display: flex;
		flex-direction: column;
		gap: 10px;
		position: relative;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
		transition: box-shadow .16s ease, border-color .16s ease;
	}

	.essb-addons-card:hover {
		box-shadow: 0 6px 20px rgba(27, 132, 255, .08);
		border-color: rgba(27, 132, 255, .18);
	}

	.essb-addons-card-active {
		border-color: rgba(27, 132, 255, .5);
		background-color: #f4f9ff;
	}

	.essb-addons-card-incompatible {
		opacity: .72;
	}

	.essb-addons-card-incompatible:hover {
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
		border-color: #e4e9f5;
	}

	/* Featured flag — same corner the dashboard card uses for its gear button */
	.essb-addons-card-flag {
		position: absolute;
		top: 12px;
		right: 12px;
		z-index: 1;
	}

	/* ---- Card body ---- */
	.essb-addons-card-body {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 8px;
		flex: 1;
		text-align: center;
	}

	/* Text block (description + notices) absorbs the spare height so that the
	   chips, links and footer stay aligned across a row of cards. */
	.essb-addons-card-text {
		width: 100%;
		flex: 1;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 8px;
	}

	/* ---- Hexagon icon frame ---- */
	.essb-addons-card .essb-ui-icon-frame64 {
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
		margin: 0 auto 8px;
	}

	/* ---- Title ---- */
	.essb-addons-card-title {
		font-size: 15px;
		font-weight: 700;
		color: #172153;
		line-height: 1.3;
		text-align: center;
		margin: 0;
		padding: 0;
	}

	/* ---- Description ---- */
	.essb-addons-card-desc {
		font-size: 12px;
		color: #6b7280;
		line-height: 1.5;
		text-align: center;
		margin: 0;
		padding: 0;
	}

	/* ---- Meta chips ---- */
	.essb-addons-card-meta {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 6px;
		flex-wrap: wrap;
	}

	/* ---- Link row ---- */
	.essb-addons-card-links {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 14px;
		flex-wrap: wrap;
	}

	.essb-addons-card .essb-ui-btn-link {
		font-size: 12px;
	}

	/* ---- Footer ---- */
	.essb-addons-card-footer {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 10px;
		padding-top: 10px;
		border-top: 1px solid #f0f3fa;
		margin-top: auto;
	}

	.essb-addons-card-badges {
		display: flex;
		align-items: center;
		gap: 6px;
		flex-wrap: wrap;
	}

	.essb-addons-card-actions {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		flex-shrink: 0;
	}

	.essb-addons-card-btn-deactivate {
		background: var(--color-grey-200) !important;
		color: var(--color-grey-700) !important;
		border-color: var(--color-grey-300) !important;
	}

	.essb-addons-card-btn-deactivate:hover {
		background: var(--color-grey-300) !important;
		color: var(--color-content-blue) !important;
	}

	/* ---- Filter bar ---- */
	.essb-addons-filter-bar {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 6px;
		padding: 10px 14px;
		margin-bottom: 18px;
		display: flex;
		align-items: center;
		gap: 10px;
		flex-wrap: wrap;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
	}

	.essb-addons-filter-label {
		font-size: 11px;
		font-weight: 600;
		color: var(--color-grey-600);
		text-transform: uppercase;
		letter-spacing: .6px;
		white-space: nowrap;
	}

	.essb-addons-filter-divider {
		width: 1px;
		height: 20px;
		background: var(--color-grey-300);
		flex-shrink: 0;
	}

	.essb-addons-filter-group {
		display: flex;
		align-items: center;
		gap: 6px;
		flex-wrap: wrap;
	}

	.essb-addons-filter-group-label {
		font-size: 11px;
		font-weight: 600;
		color: var(--color-grey-500);
		text-transform: uppercase;
		letter-spacing: .5px;
		margin-right: 2px;
		white-space: nowrap;
	}

	.essb-addons-filter-btn {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		padding: 5px 11px;
		border-radius: 6px;
		border: 1px solid var(--color-grey-300);
		background: #fff;
		color: var(--color-grey-700);
		font-size: 12px;
		font-weight: 500;
		cursor: pointer;
		transition: all .15s ease;
		white-space: nowrap;
		font-family: inherit;
		line-height: 1.5;
	}

	.essb-addons-filter-btn:hover {
		border-color: var(--primary);
		color: var(--primary);
		background: var(--primary-light);
	}

	.essb-addons-filter-btn.essb-filter-active {
		border-color: var(--primary);
		background: var(--primary);
		color: #fff;
	}

	.essb-addons-filter-btn-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		flex-shrink: 0;
	}

	.essb-addons-filter-btn-dot-free {
		background: var(--success);
	}

	.essb-addons-filter-btn-dot-premium {
		background: var(--warning);
	}

	.essb-addons-filter-btn-dot-update {
		background: var(--primary);
	}

	.essb-addons-filter-btn.essb-filter-active .essb-addons-filter-btn-dot {
		background: rgba(255, 255, 255, .8);
	}

	.essb-addons-filter-count {
		background: var(--color-grey-100);
		color: var(--color-grey-600);
		border-radius: 3px;
		padding: 0 5px;
		font-size: 10px;
		font-weight: 700;
		line-height: 1.6;
	}

	.essb-addons-filter-btn.essb-filter-active .essb-addons-filter-count {
		background: rgba(255, 255, 255, .22);
		color: #fff;
	}

	.essb-addons-filter-cat-btn {
		display: inline-flex;
		align-items: center;
		padding: 5px 10px;
		border-radius: 6px;
		border: 1px solid var(--color-grey-300);
		background: #fff;
		color: var(--color-grey-700);
		font-size: 12px;
		font-weight: 500;
		cursor: pointer;
		transition: all .15s ease;
		white-space: nowrap;
		font-family: inherit;
		line-height: 1.5;
	}

	.essb-addons-filter-cat-btn:hover {
		border-color: var(--primary);
		color: var(--primary);
		background: var(--primary-light);
	}

	.essb-addons-filter-cat-btn.essb-filter-cat-active {
		border-color: var(--color-content-blue);
		background: var(--color-content-blue);
		color: #fff;
	}

	/* ---- No results ---- */
	.essb-addons-no-results {
		text-align: center;
		padding: 40px 20px;
		color: var(--color-grey-600);
		font-size: 14px;
		display: none;
		grid-column: 1 / -1;
	}

	.essb-addons-no-results svg {
		width: 36px;
		height: 36px;
		fill: var(--color-grey-300);
		display: block;
		margin: 0 auto 10px;
	}

	.essb-addons-no-results-title {
		font-weight: 700;
		color: #172153;
		margin-bottom: 4px;
		font-size: 14px;
	}

	/* ---- Hidden by filter ---- */
	.essb-addons-card-hidden {
		display: none !important;
	}

	/* ---- Responsive ---- */
	@media (max-width: 1200px) {
		.essb-addons-grid {
			grid-template-columns: repeat(2, 1fr);
		}
	}

	@media (max-width: 782px) {
		.essb-addons-grid {
			grid-template-columns: 1fr;
		}
	}
</style>

<div class="essb-addons-wrap essb-ui">

<?php if (essb_option_bool_value('deactivate_addons_remote')) : ?>

	<style>
		.essb-addons-disabled-notice {
			background: #fff;
			border: 1px solid #e2e8f0;
			border-left: 4px solid #f6b100;
			border-radius: 6px;
			padding: 24px 28px;
			margin: 20px 0;
		}
		.essb-addons-disabled-notice p {
			margin: 0 0 10px;
			font-size: 14px;
			color: #334155;
			line-height: 1.6;
		}
		.essb-addons-disabled-notice p:last-child {
			margin-bottom: 0;
		}
		.essb-addons-disabled-notice a {
			color: #1b84ff;
			text-decoration: none;
			font-weight: 600;
		}
		.essb-addons-disabled-notice a:hover {
			text-decoration: underline;
		}
		.essb-addons-disabled-notice-icon {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			width: 24px;
			height: 24px;
			background: #fff8dd;
			border-radius: 50%;
			margin-right: 8px;
			vertical-align: middle;
		}
		.essb-addons-disabled-notice-icon svg {
			width: 14px;
			height: 14px;
			fill: #dfa000;
		}
	</style>

	<div class="essb-addons-disabled-notice">
		<p>
			<span class="essb-addons-disabled-notice-icon">
				<svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
			</span>
			<?php esc_html_e('Add-ons remote list update is currently disabled.', 'essb'); ?>
		</p>
		<p>
			<?php echo sprintf(
				esc_html__('Visit %s to browse all available add-ons.', 'essb'),
				'<a href="https://socialsharingplugin.com/addons/" target="_blank" rel="noopener noreferrer">https://socialsharingplugin.com/addons/</a>'
			); ?>
		</p>
	</div>

<?php else : ?>

	<?php if (! empty($featured_list)) : ?>
		<!-- ===================== FEATURED SECTION ===================== -->
		<div class="essb-addons-section essb-addons-section-featured">

			<h2 class="essb-addons-section-title">
				<?php esc_html_e('Featured Add-ons', 'essb'); ?>
				<span class="essb-addons-section-count"><?php echo (int) $count_featured; ?></span>
			</h2>

			<div class="essb-addons-grid">
				<?php foreach ($featured_list as $key => $data) : ?>
					<?php essb_addons_render_card($key, $data, $current_plugins, 'featured'); ?>
				<?php endforeach; ?>
			</div>

		</div>
	<?php endif; ?>

	<!-- ===================== ALL ADD-ONS SECTION ===================== -->
	<div class="essb-addons-section essb-addons-section-all">

		<h2 class="essb-addons-section-title">
			<?php esc_html_e('All Add-ons', 'essb'); ?>
			<span class="essb-addons-section-count" id="essb-addons-visible-count"><?php echo (int) $count_all; ?></span>
		</h2>

		<!-- Filter bar: type (free/premium) + category -->
		<div class="essb-addons-filter-bar">
			<span class="essb-addons-filter-label">
				<?php esc_html_e('Filter', 'essb'); ?>
			</span>

			<span class="essb-addons-filter-divider"></span>

			<div class="essb-addons-filter-group" id="essb-addons-type-group">
				<span class="essb-addons-filter-group-label"><?php esc_html_e('Type', 'essb'); ?></span>
				<button type="button" class="essb-addons-filter-btn essb-filter-active" data-filter-type="all">
					<?php esc_html_e('All', 'essb'); ?>
					<span class="essb-addons-filter-count"><?php echo (int) $count_all; ?></span>
				</button>
				<button type="button" class="essb-addons-filter-btn" data-filter-type="free">
					<span class="essb-addons-filter-btn-dot essb-addons-filter-btn-dot-free"></span>
					<?php esc_html_e('Free', 'essb'); ?>
				</button>
				<button type="button" class="essb-addons-filter-btn" data-filter-type="premium">
					<span class="essb-addons-filter-btn-dot essb-addons-filter-btn-dot-premium"></span>
					<?php esc_html_e('Premium', 'essb'); ?>
				</button>
				<button type="button" class="essb-addons-filter-btn" data-filter-type="updates">
					<span class="essb-addons-filter-btn-dot essb-addons-filter-btn-dot-update"></span>
					<?php esc_html_e('Updates', 'essb'); ?>
				</button>
			</div>

			<?php if (! empty($all_categories)) : ?>
				<span class="essb-addons-filter-divider"></span>
				<div class="essb-addons-filter-group" id="essb-addons-cat-group">
					<span class="essb-addons-filter-group-label"><?php esc_html_e('Category', 'essb'); ?></span>
					<?php foreach ($all_categories as $cat) : ?>
						<button type="button"
							class="essb-addons-filter-cat-btn"
							data-filter-cat="<?php echo esc_attr(strtolower($cat)); ?>">
							<?php echo esc_html($cat); ?>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<div class="essb-addons-grid" id="essb-addons-main-grid">
			<?php foreach ($all_list as $key => $data) : ?>
				<?php essb_addons_render_card($key, $data, $current_plugins, 'all'); ?>
			<?php endforeach; ?>

			<div class="essb-addons-no-results" id="essb-addons-no-results">
				<svg viewBox="0 0 24 24">
					<path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
				</svg>
				<div class="essb-addons-no-results-title"><?php esc_html_e('No add-ons match your filters', 'essb'); ?></div>
				<div><?php esc_html_e('Try adjusting your selection.', 'essb'); ?></div>
			</div>
		</div>

	</div><!-- /section-all -->

<?php endif; // deactivate_addons_remote ?>

</div><!-- /essb-addons-wrap -->

<script>
	(function() {
		'use strict';

		/**
		 * ESSBAddonsGridFilter
		 * Type: single-select (all / free / premium / updates)
		 * Category: multi-select (none selected = show all)
		 * Both filters AND-combined.
		 */
		class ESSBAddonsGridFilter {
			constructor(opts) {
				this.gridId = opts.gridId || 'essb-addons-main-grid';
				this.typeGroupId = opts.typeGroupId || 'essb-addons-type-group';
				this.catGroupId = opts.catGroupId || 'essb-addons-cat-group';
				this.countId = opts.countId || 'essb-addons-visible-count';
				this.noResultsId = opts.noResultsId || 'essb-addons-no-results';
				this.cardSel = opts.cardSel || '.essb-addons-card';

				this.CLS_TYPE_ACTIVE = 'essb-filter-active';
				this.CLS_CAT_ACTIVE = 'essb-filter-cat-active';
				this.CLS_HIDDEN = 'essb-addons-card-hidden';

				this._type = 'all';
				this._cats = new Set();

				this._init();
			}

			_init() {
				this._grid = document.getElementById(this.gridId);
				this._countEl = document.getElementById(this.countId);
				this._noResults = document.getElementById(this.noResultsId);
				this._typeGroup = document.getElementById(this.typeGroupId);
				this._catGroup = document.getElementById(this.catGroupId);

				if (!this._grid) return;

				if (this._typeGroup) {
					this._typeGroup.querySelectorAll('[data-filter-type]').forEach(btn => {
						btn.addEventListener('click', () => this._handleType(btn));
					});
				}

				if (this._catGroup) {
					this._catGroup.querySelectorAll('[data-filter-cat]').forEach(btn => {
						btn.addEventListener('click', () => this._handleCat(btn));
					});
				}

				this._apply();
			}

			_handleType(btn) {
				this._typeGroup.querySelectorAll('[data-filter-type]')
					.forEach(b => b.classList.remove(this.CLS_TYPE_ACTIVE));
				btn.classList.add(this.CLS_TYPE_ACTIVE);
				this._type = btn.getAttribute('data-filter-type');
				this._apply();
			}

			_handleCat(btn) {
				const cat = btn.getAttribute('data-filter-cat');
				if (this._cats.has(cat)) {
					this._cats.delete(cat);
					btn.classList.remove(this.CLS_CAT_ACTIVE);
				} else {
					this._cats.add(cat);
					btn.classList.add(this.CLS_CAT_ACTIVE);
				}
				this._apply();
			}

			_apply() {
				const cards = this._grid.querySelectorAll(this.cardSel);
				let visible = 0;

				cards.forEach(card => {
					if (card.id === this.noResultsId) return;

					const cardType = (card.getAttribute('data-addon-type') || '').trim();
					const cardCat = (card.getAttribute('data-addon-category') || '').trim();
					const cardUpdate = (card.getAttribute('data-addon-update') || '').trim();

					let passType = false;

					if (this._type === 'all') {
						passType = true;
					} else if (this._type === 'updates') {
						passType = (cardUpdate === 'yes');
					} else {
						passType = (cardType === this._type);
					}
					const passCat = (this._cats.size === 0) || this._cats.has(cardCat);

					if (passType && passCat) {
						card.classList.remove(this.CLS_HIDDEN);
						visible++;
					} else {
						card.classList.add(this.CLS_HIDDEN);
					}
				});

				if (this._countEl) this._countEl.textContent = visible;
				if (this._noResults) this._noResults.style.display = visible === 0 ? 'block' : 'none';
			}

			reset() {
				this._type = 'all';
				this._cats.clear();
				if (this._typeGroup) {
					this._typeGroup.querySelectorAll('[data-filter-type]')
						.forEach(b => b.classList.remove(this.CLS_TYPE_ACTIVE));
					const allBtn = this._typeGroup.querySelector('[data-filter-type="all"]');
					if (allBtn) allBtn.classList.add(this.CLS_TYPE_ACTIVE);
				}
				if (this._catGroup) {
					this._catGroup.querySelectorAll('[data-filter-cat]')
						.forEach(b => b.classList.remove(this.CLS_CAT_ACTIVE));
				}
				this._apply();
			}
		}

		function boot() {
			window.essbAddonsGridFilter = new ESSBAddonsGridFilter({
				gridId: 'essb-addons-main-grid',
				typeGroupId: 'essb-addons-type-group',
				catGroupId: 'essb-addons-cat-group',
				countId: 'essb-addons-visible-count',
				noResultsId: 'essb-addons-no-results',
				cardSel: '.essb-addons-card'
			});
		}

		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', boot);
		} else {
			boot();
		}
	}());
</script>
