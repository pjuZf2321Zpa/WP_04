<?php
include_once ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/about-page-header.php';

if (!function_exists('essb_dashboard_feature_card')) {
	function essb_dashboard_feature_card($title, $desc, $icon, $field, $link_url = '', $settings_url = '')
	{
		$state = '';
		$field_value = essb_option_bool_value($field);
		$value = '';
		if (!$field_value) {
			$state = 'active';
			$value = '';
		} else {
			$state = '';
			$value = 'true';
		}
?>
		<div class="essb-df-card essb-activate-additional-feature <?php echo esc_attr($state); ?> essb-activate-additional-feature-<?php echo esc_attr($field); ?>" data-type="deactivation">
			<?php if (!empty($settings_url)) { ?>
				<a class="essb-df-card-settings" href="<?php echo esc_url($settings_url); ?>" title="<?php esc_attr_e('Settings', 'essb'); ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></a>
			<?php } ?>
			<input type="hidden" name="essb_options[<?php echo esc_attr($field); ?>]" id="essb_<?php echo esc_attr($field); ?>" class="feature-value" value="<?php echo esc_attr($value); ?>" />
			<div class="essb-ui-icon-frame64">
				<svg class="essb-ui-svg-frame essb-ui-svg-frame-grey" fill="none" height="48" viewBox="0 0 44 48" width="44" xmlns="http://www.w3.org/2000/svg">
					<path d="M16 2.4641C19.7128 0.320509 24.2872 0.320508 28 2.4641L37.6506 8.0359C41.3634 10.1795 43.6506 14.141 43.6506 18.4282V29.5718C43.6506 33.859 41.3634 37.8205 37.6506 39.9641L28 45.5359C24.2872 47.6795 19.7128 47.6795 16 45.5359L6.34937 39.9641C2.63655 37.8205 0.349365 33.859 0.349365 29.5718V18.4282C0.349365 14.141 2.63655 10.1795 6.34937 8.0359L16 2.4641Z" fill=""></path>
					<path d="M16.25 2.89711C19.8081 0.842838 24.1919 0.842837 27.75 2.89711L37.4006 8.46891C40.9587 10.5232 43.1506 14.3196 43.1506 18.4282V29.5718C43.1506 33.6804 40.9587 37.4768 37.4006 39.5311L27.75 45.1029C24.1919 47.1572 19.8081 47.1572 16.25 45.1029L6.59937 39.5311C3.04125 37.4768 0.849365 33.6803 0.849365 29.5718V18.4282C0.849365 14.3196 3.04125 10.5232 6.59937 8.46891L16.25 2.89711Z" stroke=""></path>
				</svg>
				<i class="essb-ui-svg-icon essb-ui-svg-dark-icon"><?php echo essb_ui_get_svg_icon($icon); ?></i>
			</div>
			<div class="essb-df-card-title"><?php echo $title; ?></div>
			<div class="essb-df-card-desc"><?php echo $desc; ?></div>
			<?php if (!empty($link_url)) { ?>
				<div class="essb-df-link-wrap"><a class="essb-ui-btn essb-ui-btn-link" href="<?php echo esc_url($link_url); ?>" target="_blank"><?php esc_html_e('Learn more', 'essb'); ?></a></div>
			<?php } ?>
			<div class="essb-df-card-footer">
				<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline essb-activation-status-notactive"><?php esc_html_e('Not active', 'essb'); ?></span>
				<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary essb-activation-status-active"><?php esc_html_e('Active', 'essb'); ?></span>
				<span class="essb-ui-switch essb-ui-switch-xl">
					<input class="essb-ui-switch-check" data-field="<?php echo esc_attr($field); ?>" id="essb_ui_switch_<?php echo esc_attr($field); ?>" type="checkbox" value="1" <?php if ($state == 'active') { ?>checked="checked" <?php } ?>>
				</span>
			</div>
		</div>
	<?php
	}
}

if (!function_exists('essb_dashboard_addon_card')) {
	function essb_dashboard_addon_card($title, $desc, $icon, $checks, $link_url = '', $install_slug = '')
	{
		$state = '';
		$is_running = false;
		foreach ($checks as $check) {
			$check_param = isset($check['param']) ? $check['param'] : '';
			$check_type = isset($check['type']) ? $check['type'] : '';
			if (!empty($check_type) && !empty($check_param)) {
				if ($check_type == 'param' && defined($check_param)) {
					$is_running = true;
				}
				if ($check_type == 'function' && function_exists($check_param)) {
					$is_running = true;
				}
				if ($check_type == 'class' && class_exists($check_param)) {
					$is_running = true;
				}
			}
		}
		if ($is_running) {
			$state = 'active';
		}
	?>
		<div class="essb-df-card essb-df-card-addon <?php echo esc_attr($state); ?>">
			<div class="essb-ui-icon-frame64">
				<svg class="essb-ui-svg-frame essb-ui-svg-frame-grey" fill="none" height="48" viewBox="0 0 44 48" width="44" xmlns="http://www.w3.org/2000/svg">
					<path d="M16 2.4641C19.7128 0.320509 24.2872 0.320508 28 2.4641L37.6506 8.0359C41.3634 10.1795 43.6506 14.141 43.6506 18.4282V29.5718C43.6506 33.859 41.3634 37.8205 37.6506 39.9641L28 45.5359C24.2872 47.6795 19.7128 47.6795 16 45.5359L6.34937 39.9641C2.63655 37.8205 0.349365 33.859 0.349365 29.5718V18.4282C0.349365 14.141 2.63655 10.1795 6.34937 8.0359L16 2.4641Z" fill=""></path>
					<path d="M16.25 2.89711C19.8081 0.842838 24.1919 0.842837 27.75 2.89711L37.4006 8.46891C40.9587 10.5232 43.1506 14.3196 43.1506 18.4282V29.5718C43.1506 33.6804 40.9587 37.4768 37.4006 39.5311L27.75 45.1029C24.1919 47.1572 19.8081 47.1572 16.25 45.1029L6.59937 39.5311C3.04125 37.4768 0.849365 33.6803 0.849365 29.5718V18.4282C0.849365 14.3196 3.04125 10.5232 6.59937 8.46891L16.25 2.89711Z" stroke=""></path>
				</svg>
				<i class="essb-ui-svg-icon essb-ui-svg-dark-icon"><?php echo essb_ui_get_svg_icon($icon); ?></i>
			</div>
			<div class="essb-df-card-title"><?php echo $title; ?></div>
			<div class="essb-df-card-desc"><?php echo $desc; ?></div>
			<?php if (!empty($link_url)) { ?>
				<div class="essb-df-link-wrap"><a class="essb-ui-btn essb-ui-btn-link" href="<?php echo esc_url($link_url); ?>" target="_blank"><?php esc_html_e('Learn more', 'essb'); ?></a></div>
			<?php } ?>
			<div class="essb-df-card-footer essb-df-card-footer-addon">
				<?php if ($is_running) { ?>
					<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary"><?php esc_html_e('Active', 'essb'); ?></span>
					<?php } elseif (!empty($install_slug)) {
					$addon_state = essb_addon_get_state($install_slug);
					if ($addon_state === 'active') { ?>
						<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary"><?php esc_html_e('Active', 'essb'); ?></span>
					<?php } elseif ($addon_state === 'installed') { ?>
						<button type="button" class="essb-ui-btn essb-ui-btn-link" data-install="<?php echo esc_attr($install_slug); ?>"><?php esc_html_e('Activate', 'essb'); ?></button>
					<?php } else { ?>
						<button type="button" class="essb-ui-btn essb-ui-btn-link" data-install="<?php echo esc_attr($install_slug); ?>"><?php esc_html_e('Install', 'essb'); ?></button>
					<?php } ?>
				<?php } else { ?>
					<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-outline"><?php esc_html_e('Not active', 'essb'); ?></span>
					<a class="essb-ui-btn essb-ui-btn-link" href="<?php echo esc_url(admin_url('admin.php?page=essb_redirect_addons')); ?>" style="margin-left: 1em;">Activate Add-On</a>
				<?php } ?>
			</div>
		</div>
<?php
	}
}

?>

<style>
	.essb-control-btn-activate {
		background: #e74c3c !important;
		color: #fff !important;
		padding: 5px 10px !important;
		border-radius: 3px;
	}

	.essb-news-typetag {
		display: inline-block;
		padding: 3px 5px;
		border-radius: 5px;
		margin-right: 5px;
		font-size: 11px;
		text-transform: uppercase;
		line-height: 1em;
		font-weight: 600;
		color: #fff;
	}

	.essb-df-wrap {
		padding: 0;
		max-width: 1100px;
		margin: 2em auto;
	}

	.essb-df-welcome {
		margin-bottom: 28px;
	}

	.essb-df-welcome-heading {
		font-size: 22px;
		font-weight: 600;
		color: #172153;
		margin: 0 0 8px;
		padding: 0;
		line-height: 1.3;
	}

	.essb-df-welcome-text {
		font-size: 14px;
		color: #6b7280;
		margin: 0 0 18px;
		line-height: 1.6;
	}

	.essb-df-toast {
		position: fixed;
		bottom: 24px;
		right: 24px;
		background: #6b7280;
		color: #fff;
		padding: 10px 20px;
		border-radius: 4px;
		font-size: 13px;
		font-weight: 500;
		box-shadow: 0 4px 12px rgba(0, 0, 0, .15);
		opacity: 0;
		transform: translateY(8px);
		transition: opacity .25s ease, transform .25s ease;
		z-index: 99999999;
		display: flex;
		align-items: center;
		gap: 8px;
	}

	.essb-df-toast-show {
		opacity: 1;
		transform: translateY(0);
	}

	.essb-df-toast-success {
		background: #1b84ff;
		box-shadow: 0 4px 12px rgba(27, 132, 255, .3);
	}

	.essb-df-toast-error {
		background: #dc2626;
		box-shadow: 0 4px 12px rgba(220, 38, 38, .3);
	}

	.essb-df-spinner {
		display: inline-block;
		width: 14px;
		height: 14px;
		border: 2px solid rgba(255, 255, 255, .3);
		border-top-color: #fff;
		border-radius: 50%;
		animation: essb-df-spin .6s linear infinite;
	}

	@keyframes essb-df-spin {
		to {
			transform: rotate(360deg);
		}
	}

	.essb-df-wrap .essb-ui-btn:not(.essb-ui-btn-link) {
		height: 2.5em;
	}

	.essb-df-wrap-bottom-text {
		margin-top: 2em;
	}

	.essb-df-wrap-cards {
		margin-bottom: 2.5em;
	}

	.essb-df-section-title {
		font-size: 18px;
		font-weight: 500;
		color: #172153;
		margin: 0 0 12px;
		padding: 0;
		margin-top: 24px;
	}

	.essb-df-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
		margin-bottom: 32px;
	}

	.essb-df-card {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 6px;
		padding: 20px;
		display: flex;
		flex-direction: column;
		gap: 10px;
		position: relative;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
		transition: box-shadow .16s ease, border-color .16s ease;
	}

	.essb-df-card-settings {
		position: absolute;
		top: 10px;
		right: 10px;
		width: 28px;
		height: 28px;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 50%;
		background: #1b84ff;
		color: #fff;
		text-decoration: none;
		transition: background .15s ease;
	}

	.essb-df-card-settings svg {
		width: 14px;
		height: 14px;
		display: block;
	}

	.essb-df-card-settings:hover {
		background: #172153;
		color: #fff;
	}

	.essb-df-card.active {
		border-color: rgba(27, 132, 255, .5);
		background-color: #f4f9ff;
	}

	.essb-df-card:hover {
		box-shadow: 0 6px 20px rgba(27, 132, 255, .08);
		border-color: rgba(27, 132, 255, .18);
	}

	.essb-df-card .essb-ui-icon-frame64 {
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
		margin: 0 auto 4px;
	}

	.essb-df-card .essb-ui-icon-frame64 i {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		display: flex;
		align-items: center;
		justify-content: center;
		width: 32px;
		height: 32px;
	}

	.essb-df-card .essb-ui-icon-frame64 i svg {
		width: 32px;
		height: 32px;
		display: block;
	}

	.essb-df-card-title {
		font-size: 15px;
		font-weight: 700;
		color: #172153;
		line-height: 1.3;
		text-align: center;
	}

	.essb-df-card-desc {
		font-size: 12px;
		color: #6b7280;
		line-height: 1.5;
		text-align: center;
		flex: 1;
	}

	.essb-df-card .essb-df-link-wrap {
		text-align: center;
	}

	.essb-df-card .essb-ui-btn-link {
		font-size: 12px;
	}

	.essb-df-card-footer {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-top: 10px;
		border-top: 1px solid #f0f3fa;
		margin-top: auto;
	}

	.essb-df-card-footer-addon {
		justify-content: center;
	}

	.essb-df-card.active .essb-activation-status-notactive {
		display: none;
	}

	.essb-df-card:not(.active) .essb-activation-status-active {
		display: none;
	}

	.essb-df-card:not(.active) .essb-df-card-settings {
		display: none;
	}

	.essb-df-card.active .essb-ui-svg-frame-grey {
		fill: var(--primary-light, #e8f3ff);
		stroke: var(--primary-clarity, #b8d6f5);
	}

	.essb-df-card.active .essb-ui-svg-dark-icon .essb-ui-svg-mode-fill {
		fill: var(--primary, #1b84ff);
	}

	.essb-df-card.active .essb-ui-svg-dark-icon .essb-ui-svg-mode-stroke {
		stroke: var(--primary, #1b84ff);
	}

	/* === Featured Add-Ons Carousel === */
	.essb-df-carousel {
		margin-bottom: 32px;
		position: relative;
		overflow: hidden;
	}

	.essb-df-carousel-track {
		display: flex;
		transition: opacity .4s ease;
	}

	.essb-df-carousel-slide {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 20px;
		flex: 0 0 100%;
		min-width: 0;
	}

	.essb-df-addon-card {
		border-radius: 10px;
		padding: 24px;
		color: #fff;
		display: flex;
		align-items: flex-start;
		gap: 16px;
	}

	.essb-df-addon-purple { background: linear-gradient(135deg, #3858E9 0%, #5a75f0 100%); }
	.essb-df-addon-violet  { background: linear-gradient(135deg, #6c47ff 0%, #8b6cff 100%); }
	.essb-df-addon-blue    { background: linear-gradient(135deg, #136EF8 0%, #3b8cf7 100%); }

	.essb-df-addon-icon {
		width: 48px;
		height: 48px;
		border-radius: 12px;
		background: rgba(255,255,255,.18);
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
	}

	.essb-df-addon-icon svg { width: 24px; height: 24px; display: block; }

	.essb-df-addon-body { flex: 1; min-width: 0; }

	.essb-df-addon-name {
		font-size: 15px;
		font-weight: 600;
		color: #fff;
		margin-bottom: 4px;
	}

	.essb-df-addon-desc {
		font-size: 13px;
		color: rgba(255,255,255,.85);
		line-height: 1.5;
		margin-bottom: 14px;
	}

	.essb-df-addon-btn {
		display: inline-block;
		font-size: 12px;
		font-weight: 600;
		padding: 7px 16px;
		border-radius: 5px;
		text-decoration: none;
		background: rgba(255,255,255,.2);
		color: #fff;
		transition: background .2s;
	}

	.essb-df-addon-btn:hover {
		background: rgba(255,255,255,.35);
		color: #fff;
	}

	.essb-df-carousel-dots {
		display: flex;
		justify-content: center;
		gap: 8px;
		margin-top: 16px;
	}

	.essb-df-carousel-dot {
		width: 8px;
		height: 8px;
		border-radius: 50%;
		background: #d1d9e8;
		border: none;
		cursor: pointer;
		padding: 0;
		transition: background .2s, transform .2s;
	}

	.essb-df-carousel-dot.active {
		background: #3858E9;
		transform: scale(1.3);
	}

	@media (max-width: 700px) {
		.essb-df-carousel-slide { grid-template-columns: 1fr; }
	}

	@media (max-width: 1200px) {
		.essb-df-grid {
			grid-template-columns: repeat(2, 1fr);
		}
	}

	@media (max-width: 782px) {
		.essb-df-grid {
			grid-template-columns: 1fr;
		}
	}

	/* === Dashboard top: merged spotlight hero === */
	.essb-df-spot-hero {
		position: relative;
		overflow: hidden;
		background: linear-gradient(120deg, #121a44 0%, #1c2b73 46%, #2748c9 100%);
		border-radius: 14px;
		padding: 30px 32px;
		color: #fff;
		display: flex;
		align-items: center;
		gap: 30px;
		box-shadow: 0 14px 32px rgba(23, 33, 83, .24);
		margin-bottom: 0;
	}

	.essb-df-spot-hero::after {
		content: "";
		position: absolute;
		left: 40%;
		top: -90px;
		width: 260px;
		height: 260px;
		border-radius: 50%;
		background: rgba(255, 255, 255, .05);
	}

	.essb-df-spot-hero-left {
		flex: 1;
		min-width: 0;
		position: relative;
		z-index: 1;
	}

	.essb-df-spot-hero-h {
		font-size: 26px;
		font-weight: 700;
		line-height: 1.2;
		color: #fff;
		margin: 0 0 8px;
		padding: 0;
	}

	.essb-df-spot-hero-p {
		font-size: 14px;
		color: rgba(255, 255, 255, .85);
		line-height: 1.6;
		max-width: 500px;
		margin: 0 0 20px;
	}

	.essb-df-spot-hero-actions {
		display: flex;
		align-items: center;
		gap: 12px;
		flex-wrap: wrap;
	}

	.essb-df-spot-panel {
		box-sizing: border-box;
		width: 336px;
		flex-shrink: 0;
		position: relative;
		z-index: 1;
		background: rgba(255, 255, 255, .1);
		border: 1px solid rgba(255, 255, 255, .22);
		border-radius: 12px;
		padding: 20px;
	}

	.essb-df-spot-panel-badge {
		display: inline-block;
		font-size: 11px;
		font-weight: 600;
		letter-spacing: .09em;
		text-transform: uppercase;
		background: #ffd76a;
		color: #172153;
		padding: 3px 8px;
		border-radius: 5px;
	}

	.essb-df-spot-panel-title {
		font-size: 16px;
		font-weight: 700;
		line-height: 1.3;
		color: #fff;
		margin: 11px 0 6px;
		padding: 0;
	}

	.essb-df-spot-panel-desc {
		font-size: 13px;
		color: rgba(255, 255, 255, .82);
		line-height: 1.5;
		margin: 0 0 16px;
	}

	/* === Dashboard top: shared buttons === */
	.essb-df-btn {
		box-sizing: border-box;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 7px;
		font-size: 13px;
		font-weight: 600;
		line-height: 1;
		border-radius: 7px;
		padding: 11px 18px;
		text-decoration: none;
		border: 1px solid transparent;
		cursor: pointer;
		font-family: inherit;
		transition: background .15s ease, border-color .15s ease;
		white-space: nowrap;
	}

	.essb-df-btn svg {
		width: 15px;
		height: 15px;
	}

	.essb-df-btn-gold {
		background: #ffd76a;
		color: #172153;
	}

	.essb-df-btn-gold:hover,
	.essb-df-btn-gold:focus {
		background: #ffcf4d;
		color: #172153;
	}

	.essb-df-btn-ghost-light {
		background: rgba(255, 255, 255, .14);
		color: #fff;
		border-color: rgba(255, 255, 255, .32);
	}

	.essb-df-btn-ghost-light:hover,
	.essb-df-btn-ghost-light:focus {
		background: rgba(255, 255, 255, .26);
		color: #fff;
	}

	.essb-df-btn-primary {
		background: #1b84ff;
		color: #fff;
	}

	.essb-df-btn-primary:hover,
	.essb-df-btn-primary:focus {
		background: #056ee9;
		color: #fff;
	}

	.essb-df-btn-ghost {
		background: #fff;
		color: #4b5563;
		border-color: #d1d5e0;
	}

	.essb-df-btn-ghost:hover,
	.essb-df-btn-ghost:focus {
		background: #f8faff;
		color: #172153;
	}

	.essb-df-spot-panel-btn {
		display: flex;
		width: 100%;
	}

	/* === Dashboard top: setup cards (horizontal rows) === */
	.essb-df-setup-row {
		display: grid;
		grid-template-columns: 1fr;
		gap: 14px;
	}

	.essb-df-setup-card {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 10px;
		padding: 18px 22px;
		display: flex;
		align-items: center;
		gap: 20px;
		position: relative;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
		transition: box-shadow .16s ease, border-color .16s ease;
	}

	.essb-df-setup-card:hover {
		box-shadow: 0 10px 24px rgba(27, 132, 255, .1);
		border-color: rgba(27, 132, 255, .3);
	}

	.essb-df-setup-card.is-primary {
		border-color: rgba(27, 132, 255, .5);
		background: linear-gradient(120deg, #f4f9ff 0%, #fff 62%);
	}

	.essb-df-setup-icon {
		flex-shrink: 0;
		width: 44px;
		height: 44px;
		border-radius: 10px;
		background: #eaf4ff;
		color: #1b84ff;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.essb-df-setup-icon svg {
		width: 22px;
		height: 22px;
		display: block;
	}

	.essb-df-setup-icon-fill svg {
		fill: currentColor;
	}

	.essb-df-setup-body {
		flex: 1;
		min-width: 0;
	}

	.essb-df-setup-head {
		display: flex;
		align-items: center;
		gap: 10px;
		margin-bottom: 4px;
	}

	.essb-df-setup-title {
		font-size: 15px;
		font-weight: 700;
		color: #172153;
		line-height: 1.3;
		margin: 0;
	}

	.essb-df-setup-desc {
		font-size: 12.5px;
		color: #6b7280;
		line-height: 1.5;
		margin: 0;
	}

	.essb-df-setup-card .essb-df-btn {
		flex-shrink: 0;
		width: auto;
	}

	.essb-df-setup-badge {
		flex-shrink: 0;
		font-size: 10px;
		font-weight: 600;
		letter-spacing: .06em;
		text-transform: uppercase;
		background: #eaf4ff;
		color: #1b84ff;
		padding: 3px 8px;
		border-radius: 5px;
		white-space: nowrap;
	}

	/* === Add-ons updates (shown below the setup cards when updates exist) === */
	.essb-df-main-left .essb-df-updates-widget {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 16px;
		margin-top: 14px;
		margin-bottom: 0;
	}

	.essb-df-main-left .essb-df-updates-widget .essb-df-updates-text {
		margin: 0;
	}

	.essb-df-main-left .essb-df-updates-widget .essb-df-updates-open {
		width: auto;
		flex-shrink: 0;
	}

	@media (max-width: 900px) {
		.essb-df-spot-hero {
			flex-direction: column;
			align-items: stretch;
		}

		.essb-df-spot-panel {
			width: 100%;
		}
	}

	@media (max-width: 640px) {
		.essb-df-setup-card {
			flex-direction: column;
			align-items: stretch;
		}

		.essb-df-setup-icon {
			margin-bottom: 12px;
		}

		.essb-df-setup-card .essb-df-btn {
			width: 100%;
		}
	}

	/* === Optimization callout === */
	.essb-df-optimization {
		background: linear-gradient(135deg, #f4f9ff 0%, #fff 60%);
		border: 1px solid #d4e5fc;
		border-radius: 6px;
		padding: 20px 24px;
		display: flex;
		align-items: center;
		gap: 18px;
		margin-bottom: 28px;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
		flex-wrap: wrap;
	}

	.essb-df-optimization-icon {
		flex-shrink: 0;
		width: 48px;
		height: 48px;
		background: #e1f0ff;
		border-radius: 8px;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.essb-df-optimization-text {
		flex: 1;
		min-width: 0;
	}

	.essb-df-optimization-title {
		font-size: 15px;
		font-weight: 600;
		color: #172153;
		margin: 0 0 4px;
		padding: 0;
		line-height: 1.3;
	}

	.essb-df-optimization-desc {
		font-size: 13px;
		color: #6b7280;
		margin: 0;
		line-height: 1.5;
	}

	.essb-df-optimization-btn {
		flex-shrink: 0;
		white-space: nowrap;
		width: 100%;
		text-align: center;
		justify-content: center;
	}

	/* === Wizard Overlay === */
	.essb-ow-overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: rgba(23, 33, 83, .45);
		z-index: 99990;
		opacity: 0;
		pointer-events: none;
		transition: opacity .3s ease;
	}

	.essb-ow-overlay-show {
		opacity: 1;
		pointer-events: auto;
	}

	/* === Dashboard Main + News Sidebar === */
	.essb-df-main-content {
		display: flex;
		gap: 24px;
		align-items: flex-start;
		margin-top: 20px;
	}

	.essb-df-main-left {
		flex: 1;
		min-width: 0;
	}

	.essb-df-main-left .essb-df-optimization {
		margin-top: 0;
	}

	.essb-df-main-left .essb-df-optimization+.essb-df-optimization {
		margin-top: 16px;
	}

	.essb-df-main-right {
		width: 400px;
		flex-shrink: 0;
	}

	.essb-df-news-widget {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 6px;
		padding: 20px;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
	}

	.essb-df-news-heading {
		font-size: 15px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 14px;
		padding-bottom: 14px;
		border-bottom: 1px solid #f0f3fa;
	}

	.essb-news-row {
		margin-bottom: 14px;
		padding-bottom: 14px;
		border-bottom: 1px solid #f5f7fb;
		line-height: 1.4;
	}

	.essb-news-row:last-child {
		border-bottom: none;
		margin-bottom: 0;
		padding-bottom: 0;
	}

	.essb-news-title a {
		font-size: 13px;
		font-weight: 500;
		color: #6b7280;
		text-decoration: none;
	}

	.essb-news-title a:hover {
		text-decoration: none;
		color: #1b84ff;
	}

	.essb-news-date {
		font-size: 11px;
		color: #9ca3af;
		display: block;
		margin-top: 4px;
	}

	.essb-df-news-footer {
		margin-top: 14px;
		padding-top: 14px;
		border-top: 1px solid #f0f3fa;
		text-align: center;
	}

	@media (max-width: 900px) {
		.essb-df-main-content {
			flex-direction: column;
		}

		.essb-df-main-right {
			width: 100%;
			position: static;
		}
	}

	/* === Activation Form === */
	.essb-activation-form {
		background: #fff;
		border: 1px solid #e4e9f5;
		border-radius: 6px;
		padding: 35px;
		margin-top: 20px;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
		margin: 48px auto;
		max-width: 640px
	}

	.essb-activation-form-title {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
	}

	.essb-activation-title {
		font-size: 18px;
		font-weight: 600;
	}

	.essb-activation-title.color-activated {
		color: #22c55e;
	}

	.essb-activation-title.color-notactivated {
		color: #ef4444;
	}

	.essb-activation-state {
		font-size: 13px;
		font-weight: 600;
		padding: 4px 12px;
		border-radius: 4px;
	}

	.essb-activation-state.background-activated {
		background: #dcfce7;
		color: #166534;
	}

	.essb-activation-state.background-notactivated {
		background: #fef2f2;
		color: #991b1b;
	}

	.essb-activate-localhost {
		font-size: 12px;
		color: #6b7280;
		margin-top: 12px;
		padding: 8px 12px;
		background: #fef9c3;
		border-radius: 4px;
		line-height: 1.4;
	}

	.essb-activation-form-code {
		margin-top: 16px;
	}

	.essb-activation-form-header {
		margin-bottom: 8px;
	}

	.essb-activation-form-header strong {
		font-size: 13px;
		color: #172153;
	}

	.essb-activation-form-header a {
		font-size: 12px;
		color: #1b84ff;
		text-decoration: none;
	}

	.essb-activation-form-header a:hover {
		text-decoration: underline;
	}

	.essb-purchase-code {
		width: 100%;
		padding: 8px 12px;
		font-size: 13px;
		border: 1px solid #d1d5db;
		border-radius: 4px;
		background: #f9fafb;
		color: #374151;
		box-sizing: border-box;
	}

	.essb-purchase-code:focus {
		border-color: #1b84ff;
		box-shadow: 0 0 0 1px #1b84ff;
		outline: none;
	}

	.essb-activation-buttons {
		margin-top: 16px;
	}

	.essb-activation-button {
		display: inline-block;
		padding: 8px 16px;
		font-size: 13px;
		font-weight: 500;
		border-radius: 4px;
		text-decoration: none;
		cursor: pointer;
		border: none;
	}

	.essb-activation-button-default {
		background: #1b84ff;
		color: #fff;
	}

	.essb-activation-button-default:hover {
		background: #1671d9;
		color: #fff;
	}

	/* === Wizard Modal === */
	.essb-ow-wrap {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%) scale(.96);
		width: 760px;
		max-width: calc(100vw - 40px);
		max-height: 88vh;
		background: #fff;
		border-radius: 12px;
		overflow: hidden;
		display: flex;
		flex-direction: column;
		box-shadow: 0 16px 48px rgba(23, 33, 83, .2);
		z-index: 99991;
		opacity: 0;
		pointer-events: none;
		transition: opacity .3s ease, transform .3s ease;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
		font-size: 13px;
		line-height: 1.5;
		color: #172153;
	}

	.essb-ow-wrap-show {
		opacity: 1;
		pointer-events: auto;
		transform: translate(-50%, -50%) scale(1);
	}

	.essb-ow-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 16px 24px;
		border-bottom: 1px solid #eef2f8;
		flex-shrink: 0;
	}

	.essb-ow-header-title {
		display: flex;
		align-items: center;
		gap: 10px;
		font-size: 14px;
		font-weight: 600;
		color: #172153;
	}

	.essb-ow-logo {
		width: 28px;
		height: 28px;
		border-radius: 6px;
		display: flex;
		align-items: center;
		justify-content: center;
		background: #eaf4ff;
		color: #1b84ff;
		flex-shrink: 0;
	}

	.essb-ow-close {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		font-size: 12px;
		font-weight: 600;
		color: #8a94b5;
		background: transparent;
		border: none;
		cursor: pointer;
		padding: 6px 10px;
		border-radius: 6px;
		font-family: inherit;
		transition: background .15s ease, color .15s ease;
	}

	.essb-ow-close:hover {
		background: #f4f7fc;
		color: #172153;
	}

	.essb-ow-progress {
		padding: 14px 24px 16px;
		flex-shrink: 0;
	}

	.essb-ow-progress-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		margin-bottom: 8px;
	}

	.essb-ow-phase {
		font-size: 11px;
		font-weight: 600;
		letter-spacing: .04em;
		text-transform: uppercase;
		color: #8a94b5;
		background: #f4f7fc;
		border-radius: 4px;
		padding: 3px 8px;
		white-space: nowrap;
	}

	.essb-ow-stepmeta {
		font-size: 12px;
		font-weight: 500;
		color: #4b5563;
	}

	.essb-ow-track {
		height: 4px;
		border-radius: 2px;
		background: #eef2f8;
		overflow: hidden;
	}

	.essb-ow-fill {
		height: 100%;
		width: 0%;
		background: #1b84ff;
		transition: width .3s ease;
	}

	.essb-ow-body {
		padding: 4px 24px 22px;
		overflow-y: auto;
		flex: 1;
	}

	.essb-ow-pane {
		display: none;
		padding-bottom: 20px;
	}

	.essb-ow-pane-active {
		display: block;
		animation: essbFadeIn .3s ease;
	}

	@keyframes essbFadeIn {
		from {
			opacity: 0;
			transform: translateY(8px);
		}

		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	.essb-ow-pane-title {
		font-size: 18px;
		font-weight: 600;
		color: #172153;
		margin: 0 0 6px;
		padding: 0;
	}

	.essb-ow-pane-desc {
		font-size: 13px;
		color: #4b5563;
		line-height: 1.6;
		margin: 0 0 18px;
		max-width: 620px;
	}

	.essb-ow-pane-desc a {
		color: #1b84ff;
		text-decoration: none;
		font-weight: 500;
	}

	.essb-ow-pane-desc a:hover {
		text-decoration: underline;
	}

	.essb-ow-note {
		display: flex;
		gap: 10px;
		background: #fff8e6;
		border: 1px solid #f0e2b8;
		border-left: 3px solid #f5a623;
		padding: 11px 14px;
		border-radius: 4px;
		font-size: 12.5px;
		color: #7a6213;
		line-height: 1.55;
		margin-bottom: 16px;
	}

	.essb-ow-note strong {
		color: #5a4a0f;
	}

	.essb-ow-list {
		display: flex;
		flex-direction: column;
		gap: 8px;
	}

	.essb-ow-list-item {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: border-color .15s ease, background .15s ease;
	}

	.essb-ow-list-item:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-ow-list-selected {
		border-color: #1b84ff;
		background: #f8faff;
	}

	.essb-ow-list-item input {
		display: none;
	}

	.essb-ow-list-radio {
		width: 18px;
		height: 18px;
		border: 2px solid #d1d5e0;
		border-radius: 50%;
		flex-shrink: 0;
		margin-top: 1px;
		transition: border-color .2s ease;
		position: relative;
	}

	.essb-ow-list-selected .essb-ow-list-radio {
		border-color: #1b84ff;
	}

	.essb-ow-list-selected .essb-ow-list-radio::after {
		content: '';
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		width: 10px;
		height: 10px;
		border-radius: 50%;
		background: #1b84ff;
	}

	.essb-ow-list-content {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.essb-ow-list-title {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
	}

	.essb-ow-list-desc {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.5;
	}

	.essb-ow-toggle {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: border-color .15s ease, background .15s ease;
	}

	.essb-ow-toggle:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-ow-toggle input {
		display: none;
	}

	.essb-ow-toggle-track {
		position: relative;
		width: 36px;
		height: 20px;
		flex-shrink: 0;
		border-radius: 10px;
		background: #d1d5e0;
		transition: background .2s ease;
		margin-top: 2px;
	}

	.essb-ow-toggle-track::after {
		content: '';
		position: absolute;
		top: 2px;
		left: 2px;
		width: 16px;
		height: 16px;
		border-radius: 50%;
		background: #fff;
		transition: transform .2s ease;
		box-shadow: 0 1px 3px rgba(0, 0, 0, .15);
	}

	.essb-ow-toggle input:checked+.essb-ow-toggle-track {
		background: #1b84ff;
	}

	.essb-ow-toggle input:checked+.essb-ow-toggle-track::after {
		transform: translateX(16px);
	}

	.essb-ow-toggle-content {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.essb-ow-toggle-label {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
	}

	.essb-ow-toggle-desc {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.55;
	}

	.essb-ow-toggle-large {
		padding: 14px 16px;
		background: #f8faff;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		margin-bottom: 0;
		transition: opacity .2s ease, border-color .15s ease;
	}

	.essb-ow-toggle-disabled {
		opacity: .55;
	}

	.essb-ow-options {
		display: flex;
		flex-direction: column;
		gap: 2px;
		margin-top: 4px;
		padding-left: 50px;
	}

	.essb-ow-field {
		display: flex;
		align-items: center;
		gap: 14px;
		padding: 12px 16px;
		margin-bottom: 2px;
	}

	.essb-ow-field-label {
		font-size: 13px;
		color: #172153;
		font-weight: 600;
		min-width: 140px;
	}

	.essb-ow-select {
		font-size: 13px;
		padding: 6px 10px;
		border: 1px solid #d1d5e0;
		border-radius: 4px;
		background: #fff;
		color: #172153;
		cursor: pointer;
	}

	.essb-ow-select:focus {
		outline: none;
		border-color: #1b84ff;
		box-shadow: 0 0 0 2px rgba(27, 132, 255, .15);
	}

	.essb-ow-summary {
		display: flex;
		flex-direction: column;
		gap: 8px;
		margin-bottom: 20px;
	}

	.essb-ow-summary-item {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		background: #fff;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
	}

	.essb-ow-summary-check {
		flex-shrink: 0;
		width: 22px;
		height: 22px;
		border-radius: 50%;
		background: #e1f0ff;
		color: #1b84ff;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 1px;
	}

	.essb-ow-summary-item strong {
		display: block;
		font-size: 13px;
		color: #172153;
		margin-bottom: 2px;
	}

	.essb-ow-summary-item p {
		font-size: 12px;
		color: #4b5563;
		margin: 0;
	}

	.essb-ow-apply-wrap {
		text-align: center;
		padding: 8px 0 12px;
	}

	.essb-ow-btn {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 6px;
		padding: 9px 18px;
		font-size: 13px;
		font-weight: 600;
		border-radius: 6px;
		border: 1px solid transparent;
		cursor: pointer;
		transition: background .15s ease, border-color .15s ease, color .15s ease;
		text-decoration: none;
		font-family: inherit;
	}

	.essb-ow-btn-primary {
		background: #1b84ff;
		color: #fff;
	}

	.essb-ow-btn-primary:hover {
		background: #056ee9;
		color: #fff;
	}

	.essb-ow-btn-ghost {
		background: #fff;
		color: #4b5563;
		border-color: #d1d5e0;
	}

	.essb-ow-btn-ghost:hover {
		background: #f8faff;
		color: #172153;
	}

	.essb-ow-btn:disabled {
		opacity: .45;
		cursor: not-allowed;
	}

	.essb-ow-footer {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		padding: 14px 24px;
		border-top: 1px solid #eef2f8;
		flex-shrink: 0;
	}

	.essb-ow-footmeta {
		font-size: 12px;
		color: #8a94b5;
		font-weight: 500;
	}

	/* === Quick Share Buttons Setup === */
	.essb-sw-overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: rgba(23, 33, 83, .45);
		z-index: 99990;
		opacity: 0;
		pointer-events: none;
		transition: opacity .3s ease;
	}

	.essb-sw-overlay-show {
		opacity: 1;
		pointer-events: auto;
	}

	.essb-sw-wrap {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%) scale(.96);
		width: 760px;
		max-width: calc(100vw - 40px);
		max-height: 88vh;
		background: #fff;
		border-radius: 12px;
		overflow: hidden;
		display: flex;
		flex-direction: column;
		box-shadow: 0 16px 48px rgba(23, 33, 83, .2);
		z-index: 99991;
		opacity: 0;
		pointer-events: none;
		transition: opacity .3s ease, transform .3s ease;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
		font-size: 13px;
		line-height: 1.5;
		color: #172153;
	}

	.essb-sw-wrap-show {
		opacity: 1;
		pointer-events: auto;
		transform: translate(-50%, -50%) scale(1);
	}

	.essb-sw-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 16px 24px;
		border-bottom: 1px solid #eef2f8;
		flex-shrink: 0;
	}

	.essb-sw-header-title {
		display: flex;
		align-items: center;
		gap: 10px;
		font-size: 14px;
		font-weight: 600;
		color: #172153;
	}

	.essb-sw-logo {
		width: 28px;
		height: 28px;
		border-radius: 6px;
		display: flex;
		align-items: center;
		justify-content: center;
		background: #eaf4ff;
		color: #1b84ff;
		flex-shrink: 0;
	}

	.essb-sw-close {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		font-size: 12px;
		font-weight: 600;
		color: #8a94b5;
		background: transparent;
		border: none;
		cursor: pointer;
		padding: 6px 10px;
		border-radius: 6px;
		font-family: inherit;
		transition: background .15s, color .15s;
	}

	.essb-sw-close:hover {
		background: #f4f7fc;
		color: #172153;
	}

	.essb-sw-progress {
		padding: 14px 24px 16px;
		flex-shrink: 0;
	}

	.essb-sw-progress-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		margin-bottom: 8px;
	}

	.essb-sw-phase {
		font-size: 11px;
		font-weight: 600;
		letter-spacing: .04em;
		text-transform: uppercase;
		color: #8a94b5;
		background: #f4f7fc;
		border-radius: 4px;
		padding: 3px 8px;
		white-space: nowrap;
	}

	.essb-sw-stepmeta {
		font-size: 12px;
		font-weight: 500;
		color: #4b5563;
	}

	.essb-sw-track {
		height: 4px;
		border-radius: 2px;
		background: #eef2f8;
		overflow: hidden;
	}

	.essb-sw-fill {
		height: 100%;
		width: 0%;
		background: #1b84ff;
		transition: width .3s ease;
	}

	.essb-sw-body {
		padding: 4px 24px 22px;
		overflow-y: auto;
		flex: 1;
	}

	.essb-sw-pane {
		display: none;
		padding-bottom: 20px;
	}

	.essb-sw-pane-active {
		display: block;
		animation: essbSwFadeIn .3s ease;
	}

	@keyframes essbSwFadeIn {
		from {
			opacity: 0;
			transform: translateY(8px);
		}

		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	.essb-sw-pane-title {
		font-size: 18px;
		font-weight: 600;
		color: #172153;
		margin: 0 0 6px;
		padding: 0;
	}

	.essb-sw-pane-desc {
		font-size: 13px;
		color: #4b5563;
		line-height: 1.6;
		margin: 0 0 18px;
	}

	.essb-sw-section-title {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		margin: 20px 0 10px;
		padding: 0;
	}

	.essb-sw-section-desc {
		font-size: 12px;
		color: #8a94b5;
		margin: -6px 0 12px;
		line-height: 1.5;
	}

	.essb-sw-note {
		display: flex;
		gap: 10px;
		background: #fff8e6;
		border: 1px solid #f0e2b8;
		border-left: 3px solid #f5a623;
		padding: 11px 14px;
		border-radius: 4px;
		font-size: 12.5px;
		color: #7a6213;
		line-height: 1.55;
		margin-bottom: 16px;
	}

	.essb-sw-note-fb {
		background: #f8faff;
		border-color: #e2e8f5;
		border-left-color: #1b84ff;
		color: #4b5563;
		margin-top: -10px;
	}

	/* Network grid - Step 1 */
	.essb-sw-network-search {
		width: 100%;
		padding: 8px 12px;
		font-size: 13px;
		border: 1px solid #d1d5e0;
		border-radius: 6px;
		background: #fff;
		color: #172153;
		outline: none;
		transition: border-color .2s;
		box-sizing: border-box;
		margin-bottom: 10px;
	}

	.essb-sw-network-search:focus {
		border-color: #1b84ff;
		box-shadow: 0 0 0 2px rgba(27, 132, 255, .12);
	}

	.essb-sw-network-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 4px;
		max-height: 260px;
		overflow-y: auto;
		padding: 2px;
		margin-top: 8px;
	}

	.essb-sw-network-item {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 8px 10px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: all .15s;
		font-size: 12px;
		color: #172153;
	}

	.essb-sw-network-item:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-sw-network-selected {
		border-color: #1b84ff;
		background: #f8faff;
	}

	.essb-sw-network-check {
		width: 16px;
		height: 16px;
		border: 2px solid #d1d5e0;
		border-radius: 3px;
		flex-shrink: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 10px;
		color: #fff;
		transition: all .15s;
	}

	.essb-sw-network-selected .essb-sw-network-check {
		background: #1b84ff;
		border-color: #1b84ff;
	}

	.essb-sw-network-icon {
		width: 20px;
		height: 20px;
		border-radius: 50%;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 10px;
		font-weight: 700;
		color: #fff;
		flex-shrink: 0;
		cursor: grab;
	}

	.essb-sw-network-name {
		font-weight: 500;
	}

	.essb-sw-selected-info {
		font-size: 12px;
		color: #8a94b5;
		margin-top: 8px;
		margin-bottom: 8px;
	}

	/* Toggle switches */
	.essb-sw-list-horizontal {
		flex-direction: row !important;
		_flex-wrap: wrap;
	}

	.essb-sw-list-horizontal .essb-sw-list-item {
		flex: 1;
		_min-width: 60px;
		padding: 10px 12px;
		text-align: center;
	}

	.essb-sw-list-horizontal .essb-sw-list-item .essb-sw-list-item-content {
		align-items: center;
		justify-content: center;
		width: 100%;
	}

	.essb-sw-toggle {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		user-select: none;
		transition: border-color .15s ease, background .15s ease;
	}

	.essb-sw-toggle:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-sw-toggle input {
		display: none;
	}

	.essb-sw-toggle-track {
		position: relative;
		width: 36px;
		height: 20px;
		border-radius: 10px;
		background: #d1d5e0;
		transition: background .2s;
		flex-shrink: 0;
		margin-top: 1px;
	}

	.essb-sw-toggle-track::after {
		content: "";
		position: absolute;
		top: 2px;
		left: 2px;
		width: 16px;
		height: 16px;
		border-radius: 50%;
		background: #fff;
		transition: transform .2s;
		box-shadow: 0 1px 3px rgba(0, 0, 0, .15);
	}

	.essb-sw-toggle input:checked+.essb-sw-toggle-track {
		background: #1b84ff;
	}

	.essb-sw-toggle input:checked+.essb-sw-toggle-track::after {
		transform: translateX(16px);
	}

	.essb-sw-toggle-content {
		display: flex;
		flex-direction: column;
		gap: 3px;
	}

	.essb-sw-toggle-desc {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.55;
	}

	.essb-sw-toggle-label {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
	}

	.essb-sw-toggle-large {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		background: #f8faff;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		margin-bottom: 0;
	}

	.essb-sw-toggle-disabled {
		opacity: .55;
	}

	/* Lists (template, display mode, counters) */
	.essb-sw-list {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.essb-sw-list-item {
		display: flex;
		align-items: flex-start;
		gap: 12px;
		padding: 12px 14px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: border-color .15s ease, background .15s ease;
	}

	.essb-sw-list-item:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-sw-list-selected {
		border-color: #1b84ff;
		background: #f8faff;
	}

	.essb-sw-list-item input[type="radio"] {
		display: none;
	}

	.essb-sw-list-item-content {
		display: flex;
		flex-direction: column;
		gap: 2px;
	}

	.essb-sw-list-item-title {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
	}

	.essb-sw-list-item-desc {
		font-size: 12px;
		color: #4b5563;
		line-height: 1.45;
	}

	/* Inline fields */
	.essb-sw-inline-fields {
		display: flex;
		gap: 16px;
		margin-bottom: 8px;
	}

	.essb-sw-field {
		display: flex;
		flex-direction: column;
		gap: 6px;
		flex: 1;
	}

	.essb-sw-field-label {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
	}

	.essb-sw-select {
		padding: 8px 12px;
		font-size: 13px;
		border: 1px solid #d1d5e0;
		border-radius: 6px;
		background: #fff;
		color: #172153;
		outline: none;
		cursor: pointer;
	}

	/* Post type grid - Step 6 */
	.essb-sw-type-grid {
		display: flex;
		flex-wrap: wrap;
		gap: 6px;
		margin-bottom: 8px;
	}

	.essb-sw-type-item {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 8px 14px 8px 12px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: all .15s;
		font-size: 13px;
		font-weight: 500;
		color: #4b5563;
		user-select: none;
	}

	.essb-sw-type-item:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-sw-type-selected {
		border-color: #1b84ff;
		background: #f8faff;
		color: #172153;
	}

	/* Position rows - Step 6 */
	.essb-sw-pos-row {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 12px 14px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		margin-bottom: 6px;
	}

	.essb-sw-pos-toggle {
		flex-shrink: 0;
	}

	.essb-sw-pos-check {
		display: none !important;
	}

	.essb-sw-pos-toggle-slider {
		position: relative;
		width: 36px;
		height: 20px;
		border-radius: 10px;
		background: #1b84ff;
		transition: background .2s;
		display: block;
		cursor: pointer;
	}

	.essb-sw-pos-toggle-slider::after {
		content: "";
		position: absolute;
		top: 2px;
		left: 2px;
		width: 16px;
		height: 16px;
		border-radius: 50%;
		background: #fff;
		transition: transform .2s;
		box-shadow: 0 1px 3px rgba(0, 0, 0, .15);
	}

	.essb-sw-pos-check:not(:checked)+.essb-sw-pos-toggle-slider {
		background: #d1d5e0;
	}

	.essb-sw-pos-check:not(:checked)+.essb-sw-pos-toggle-slider::after {
		transform: none;
	}

	.essb-sw-pos-info {
		flex: 1;
		min-width: 0;
	}

	.essb-sw-pos-name {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
	}

	.essb-sw-pos-desc {
		font-size: 12px;
		color: #8a94b5;
		margin-top: 1px;
	}

	/* Device chips */
	.essb-sw-device-chips {
		display: flex;
		gap: 4px;
		flex-shrink: 0;
	}

	.essb-sw-device-chip {
		font-size: 11px;
		font-weight: 500;
		color: #8a94b5;
		background: #f4f7fc;
		border: 1px solid #e2e8f5;
		padding: 4px 10px;
		border-radius: 5px;
		cursor: pointer;
		user-select: none;
		transition: all .15s;
	}

	.essb-sw-device-chip:hover {
		border-color: #c9d8ee;
	}

	.essb-sw-device-chip-active {
		color: #172153;
		background: #f8faff;
		border-color: #1b84ff;
	}

	/* Position grid (Pinterest) */
	.essb-sw-position-grid {
		display: grid;
		grid-template-columns: repeat(5, 1fr);
		gap: 6px;
	}

	.essb-sw-position-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 6px;
		padding: 10px 8px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: all .15s;
		font-size: 12px;
		font-weight: 500;
		color: #4b5563;
		text-align: center;
	}

	.essb-sw-position-item:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-sw-position-selected {
		border-color: #1b84ff;
		background: #f8faff;
		color: #172153;
	}

	/* Advanced options */
	.essb-sw-advanced-options {
		display: flex;
		flex-direction: column;
		gap: 8px;
		margin-top: 12px;
	}

	.essb-sw-advanced-row {
		display: flex;
		align-items: center;
		gap: 10px;
	}

	/* Summary */
	.essb-sw-summary {
		display: flex;
		flex-direction: column;
		gap: 8px;
		margin-bottom: 20px;
	}

	.essb-sw-summary-item {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		background: #fff;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
	}

	.essb-sw-summary-check {
		flex-shrink: 0;
		width: 22px;
		height: 22px;
		border-radius: 50%;
		background: #e1f0ff;
		color: #1b84ff;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 1px;
	}

	.essb-sw-summary-item strong {
		display: block;
		font-size: 13px;
		color: #172153;
		margin-bottom: 2px;
	}

	.essb-sw-summary-item p {
		font-size: 12px;
		color: #4b5563;
		margin: 0;
	}

	.essb-sw-apply-wrap {
		text-align: center;
		padding: 8px 0 12px;
	}

	/* Buttons */
	.essb-sw-btn {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 6px;
		padding: 9px 18px;
		font-size: 13px;
		font-weight: 600;
		border-radius: 6px;
		border: 1px solid transparent;
		cursor: pointer;
		transition: background .15s ease, border-color .15s ease, color .15s ease;
		text-decoration: none;
		font-family: inherit;
	}

	.essb-sw-btn-primary {
		background: #1b84ff;
		color: #fff;
	}

	.essb-sw-btn-primary:hover {
		background: #056ee9;
		color: #fff;
	}

	.essb-sw-btn-ghost {
		background: #fff;
		color: #4b5563;
		border-color: #d1d5e0;
	}

	.essb-sw-btn-ghost:hover {
		background: #f8faff;
		color: #172153;
	}

	.essb-sw-btn:disabled {
		opacity: .45;
		cursor: not-allowed;
	}

	/* Footer */
	.essb-sw-footer {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		padding: 14px 24px;
		border-top: 1px solid #eef2f8;
		flex-shrink: 0;
	}

	.essb-sw-footmeta {
		font-size: 12px;
		color: #8a94b5;
		font-weight: 500;
	}

	/* Scrollbar */
	.essb-sw-body::-webkit-scrollbar {
		width: 4px;
	}

	.essb-sw-body::-webkit-scrollbar-thumb {
		background: #d1d5e0;
		border-radius: 2px;
	}

	.essb-sw-network-grid::-webkit-scrollbar {
		width: 4px;
	}

	.essb-sw-network-grid::-webkit-scrollbar-thumb {
		background: #d1d5e0;
		border-radius: 2px;
	}

	/* Mobile only badge */
	.essb-sw-badge-mobile {
		font-size: 10px;
		font-weight: 600;
		color: #fff;
		background: #7239ea;
		padding: 2px 8px;
		border-radius: 4px;
		text-transform: uppercase;
		letter-spacing: .3px;
		margin-left: 6px;
		vertical-align: middle;
	}

	/* Mobile only tag */
	.essb-sw-mobile-tag {
		font-size: 10px;
		font-weight: 600;
		color: #fff;
		background: #7239ea;
		padding: 2px 8px;
		border-radius: 4px;
		text-transform: uppercase;
		letter-spacing: .3px;
		margin-left: 6px;
	}

	/* Device visibility step */
	.essb-sw-btn-sm {
		padding: 6px 12px;
		font-size: 12px;
	}

	.essb-sw-visibility-toolbar {
		display: flex;
		gap: 8px;
		margin-bottom: 12px;
	}

	.essb-sw-visibility-list {
		display: flex;
		flex-direction: column;
		gap: 6px;
	}

	.essb-sw-visibility-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		padding: 10px 12px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		background: #fff;
	}

	.essb-sw-visibility-network {
		display: flex;
		align-items: center;
		gap: 8px;
		min-width: 0;
	}

	.essb-sw-visibility-name {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.essb-sw-segmented {
		display: inline-flex;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		overflow: hidden;
		flex-shrink: 0;
	}

	.essb-sw-seg {
		padding: 6px 10px;
		font-size: 12px;
		font-weight: 500;
		color: #4b5563;
		background: #fff;
		border: none;
		border-left: 1px solid #e2e8f5;
		cursor: pointer;
		font-family: inherit;
		transition: background .15s ease, color .15s ease;
	}

	.essb-sw-seg:first-child {
		border-left: none;
	}

	.essb-sw-seg:hover {
		background: #f8faff;
	}

	.essb-sw-seg-active {
		background: #eaf4ff;
		color: #1b84ff;
		font-weight: 600;
	}

	.essb-sw-visibility-empty {
		padding: 14px 16px;
		border: 1px dashed #d1d5e0;
		border-radius: 6px;
		font-size: 12.5px;
		color: #8a94b5;
		text-align: center;
	}

	@media (max-width: 720px) {

		.essb-ow-wrap,
		.essb-sw-wrap {
			top: 0;
			left: 0;
			transform: none;
			width: 100%;
			max-width: 100vw;
			height: 100%;
			max-height: 100vh;
			border-radius: 0;
		}

		.essb-ow-wrap-show,
		.essb-sw-wrap-show {
			transform: none;
		}

		.essb-sw-network-grid {
			grid-template-columns: repeat(2, 1fr);
		}

		.essb-sw-position-grid {
			grid-template-columns: repeat(3, 1fr);
		}
	}

	/* === Initial Config Wizard === */
	/* === Initial Config Wizard (full-screen) === */
	.essb-iw-overlay {
		position: fixed;
		inset: 0;
		background: #f4f9ff;
		z-index: 999998;
		display: none;
	}

	/* ==== Initial Config Wizard ==== */
	.essb-iw-overlay {
		position: fixed;
		inset: 0;
		background: rgba(23, 33, 83, .45);
		display: none;
		z-index: 999998;
	}

	.essb-iw-wrap {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		width: 760px;
		max-width: calc(100vw - 40px);
		max-height: 88vh;
		background: #fff;
		border-radius: 12px;
		overflow: hidden;
		display: none;
		flex-direction: column;
		box-shadow: 0 16px 48px rgba(23, 33, 83, .2);
		z-index: 999999;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
		font-size: 13px;
		line-height: 1.5;
		color: #172153;
	}

	.essb-iw-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 16px 24px;
		border-bottom: 1px solid #eef2f8;
		flex-shrink: 0;
	}

	.essb-iw-header-title {
		display: flex;
		align-items: center;
		gap: 10px;
		font-size: 14px;
		font-weight: 600;
		color: #172153;
	}

	.essb-iw-logo {
		width: 28px;
		height: 28px;
		border-radius: 6px;
		display: flex;
		align-items: center;
		justify-content: center;
		background: #eaf4ff;
		color: #1b84ff;
	}

	.essb-iw-close {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		font-size: 12px;
		font-weight: 600;
		color: #8a94b5;
		background: transparent;
		border: none;
		cursor: pointer;
		padding: 6px 10px;
		border-radius: 6px;
		font-family: inherit;
	}

	.essb-iw-close:hover {
		background: #f4f7fc;
		color: #172153;
	}

	.essb-iw-progress {
		padding: 14px 24px 16px;
		flex-shrink: 0;
	}

	.essb-iw-progress-top {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 8px;
	}

	.essb-iw-phase {
		font-size: 11px;
		font-weight: 600;
		letter-spacing: .04em;
		text-transform: uppercase;
		color: #8a94b5;
		background: #f4f7fc;
		border-radius: 4px;
		padding: 3px 8px;
	}

	.essb-iw-stepmeta {
		font-size: 12px;
		font-weight: 500;
		color: #4b5563;
	}

	.essb-iw-track {
		height: 4px;
		border-radius: 2px;
		background: #eef2f8;
		overflow: hidden;
	}

	.essb-iw-fill {
		height: 100%;
		width: 0%;
		background: #1b84ff;
		transition: width .3s ease;
	}

	.essb-iw-body {
		padding: 4px 24px 22px;
		overflow-y: auto;
		flex: 1;
	}

	.essb-iw-pane {
		display: none;
	}

	.essb-iw-pane-active {
		display: block;
	}

	.essb-iw-pane-title {
		font-size: 18px;
		font-weight: 600;
		color: #172153;
		margin: 0 0 6px;
	}

	.essb-iw-pane-desc {
		font-size: 13px;
		color: #4b5563;
		line-height: 1.6;
		margin: 0 0 18px;
		max-width: 620px;
	}

	/* welcome */
	.essb-iw-welcome {
		text-align: center;
		padding: 12px 8px 4px;
	}

	.essb-iw-welcome-badge {
		width: 54px;
		height: 54px;
		border-radius: 8px;
		margin: 0 auto 16px;
		display: flex;
		align-items: center;
		justify-content: center;
		background: #eaf4ff;
		color: #1b84ff;
	}

	.essb-iw-welcome h2 {
		font-size: 20px;
		font-weight: 600;
		margin: 0 0 8px;
		color: #172153;
	}

	.essb-iw-welcome p {
		font-size: 13.5px;
		color: #4b5563;
		line-height: 1.65;
		max-width: 520px;
		margin: 0 auto 8px;
	}

	.essb-iw-welcome-note {
		font-size: 12px;
		color: #8a94b5;
		margin-top: 10px;
	}

	.essb-iw-overview {
		margin-top: 20px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		overflow: hidden;
		text-align: left;
	}

	.essb-iw-overview-row {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 11px 16px;
		border-bottom: 1px solid #eef2f8;
		font-size: 13px;
	}

	.essb-iw-overview-row:last-child {
		border-bottom: none;
	}

	.essb-iw-overview-num {
		width: 22px;
		height: 22px;
		border-radius: 4px;
		background: #f4f7fc;
		color: #4b5563;
		font-size: 11px;
		font-weight: 600;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
	}

	.essb-iw-overview-name {
		font-weight: 500;
		color: #172153;
	}

	.essb-iw-overview-tag {
		margin-left: auto;
		font-size: 11px;
		color: #8a94b5;
		font-weight: 600;
	}

	/* buttons */
	.essb-iw-btn {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 6px;
		padding: 9px 18px;
		border-radius: 6px;
		font-size: 13px;
		font-weight: 600;
		border: 1px solid transparent;
		cursor: pointer;
		text-decoration: none;
		font-family: inherit;
		transition: background .15s ease, border-color .15s ease, color .15s ease;
	}

	.essb-iw-btn-primary {
		background: #1b84ff;
		color: #fff;
	}

	.essb-iw-btn-primary:hover {
		background: #056ee9;
		color: #fff;
	}

	.essb-iw-btn-ghost {
		background: #fff;
		color: #4b5563;
		border-color: #d1d5e0;
	}

	.essb-iw-btn-ghost:hover {
		background: #f8faff;
		color: #172153;
	}

	.essb-iw-btn-sm {
		padding: 6px 12px;
		font-size: 12px;
	}

	.essb-iw-btn:disabled {
		opacity: .45;
		cursor: not-allowed;
	}

	.essb-iw-btn-success {
		background: #14803e !important;
		border-color: #14803e !important;
		color: #fff !important;
		cursor: default !important;
	}

	/* cards + features */
	.essb-iw-card {
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		padding: 16px;
		background: #fff;
	}

	.essb-iw-card + .essb-iw-card,
	.essb-iw-card + .essb-iw-note,
	.essb-iw-note + .essb-iw-card,
	.essb-iw-card + .essb-iw-addon-row,
	.essb-iw-addon-row + .essb-iw-more {
		margin-top: 12px;
	}

	.essb-iw-feature {
		display: flex;
		gap: 12px;
		align-items: flex-start;
	}

	.essb-iw-feature + .essb-iw-feature {
		margin-top: 14px;
		padding-top: 14px;
		border-top: 1px solid #eef2f8;
	}

	.essb-iw-feature-ico {
		width: 32px;
		height: 32px;
		border-radius: 6px;
		background: #f4f7fc;
		color: #1b84ff;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
	}

	.essb-iw-feature strong {
		display: block;
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 2px;
	}

	.essb-iw-feature span {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.55;
	}

	.essb-iw-more {
		display: flex;
		align-items: center;
		gap: 8px;
		margin-top: 14px;
		font-size: 12.5px;
	}

	.essb-iw-more a {
		color: #1b84ff;
		font-weight: 500;
		text-decoration: none;
	}

	.essb-iw-more a:hover {
		text-decoration: underline;
	}

	.essb-iw-note {
		display: flex;
		gap: 10px;
		background: #fff8e6;
		border: 1px solid #f0e2b8;
		border-left: 3px solid #f5a623;
		border-radius: 4px;
		padding: 11px 14px;
		font-size: 12.5px;
		color: #7a6213;
		line-height: 1.55;
	}

	.essb-iw-note.info {
		background: #f8faff;
		border-color: #e2e8f5;
		border-left-color: #1b84ff;
		color: #4b5563;
	}

	.essb-iw-note b {
		color: #172153;
	}

	/* toggle */
	.essb-iw-toggle {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		padding: 14px 16px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		cursor: pointer;
		transition: border-color .15s ease, background .15s ease;
	}

	.essb-iw-toggle:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-iw-toggle input[type="checkbox"] {
		display: none;
	}

	.essb-iw-switch {
		position: relative;
		width: 36px;
		height: 20px;
		border-radius: 10px;
		background: #d1d5e0;
		flex-shrink: 0;
		margin-top: 1px;
		transition: background .2s ease;
	}

	.essb-iw-switch::after {
		content: '';
		position: absolute;
		top: 2px;
		left: 2px;
		width: 16px;
		height: 16px;
		border-radius: 50%;
		background: #fff;
		box-shadow: 0 1px 2px rgba(23, 33, 83, .25);
		transition: transform .2s ease;
	}

	.essb-iw-toggle input:checked + .essb-iw-switch {
		background: #1b84ff;
	}

	.essb-iw-toggle input:checked + .essb-iw-switch::after {
		transform: translateX(16px);
	}

	.essb-iw-toggle-text strong {
		display: block;
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 3px;
	}

	.essb-iw-toggle-text span {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.55;
	}

	.essb-iw-sub {
		margin-top: 12px;
		padding-left: 18px;
		border-left: 2px solid #eef2f8;
	}

	.essb-iw-sub .essb-iw-toggle + .essb-iw-toggle,
	.essb-iw-sub .essb-iw-note + .essb-iw-toggle {
		margin-top: 10px;
	}

	/* mode grid */
	.essb-iw-mode-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 10px;
		margin: 16px 0;
	}

	.essb-iw-mode-card {
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		padding: 14px;
		cursor: pointer;
		transition: border-color .15s ease, background .15s ease;
		position: relative;
	}

	.essb-iw-mode-card:hover {
		border-color: #c9d8ee;
		background: #f8faff;
	}

	.essb-iw-mode-selected {
		border-color: #1b84ff;
		background: #f8faff;
	}

	.essb-iw-mode-selected::after {
		content: '';
		position: absolute;
		top: 12px;
		right: 12px;
		width: 14px;
		height: 14px;
		border-radius: 50%;
		background: #1b84ff;
		box-shadow: inset 0 0 0 3px #fff;
	}

	.essb-iw-mode-name {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 3px;
	}

	.essb-iw-mode-desc {
		font-size: 12px;
		color: #4b5563;
		line-height: 1.5;
	}

	/* field */
	.essb-iw-field {
		display: flex;
		gap: 10px;
		align-items: center;
	}

	.essb-iw-input {
		flex: 1;
		padding: 8px 12px;
		border: 1px solid #d1d5e0;
		border-radius: 6px;
		font-size: 13px;
		font-family: inherit;
		color: #172153;
		outline: none;
		background: #fff;
	}

	.essb-iw-input:focus {
		border-color: #1b84ff;
		box-shadow: 0 0 0 2px rgba(27, 132, 255, .15);
	}

	.essb-iw-label {
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 6px;
		display: block;
	}

	.essb-iw-label-desc {
		font-size: 12px;
		color: #4b5563;
		margin-bottom: 8px;
		line-height: 1.5;
	}

	/* compact add-on row */
	.essb-iw-addon-row {
		display: flex;
		align-items: center;
		gap: 14px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		padding: 14px 16px;
		background: #fff;
	}

	.essb-iw-addon-txt {
		flex: 1;
		min-width: 0;
	}

	.essb-iw-addon-row strong {
		display: block;
		font-size: 13px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 2px;
	}

	.essb-iw-addon-row span {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.5;
	}

	.essb-iw-learn {
		display: inline-block;
		margin-top: 4px;
		font-size: 12px;
		color: #1b84ff;
		font-weight: 500;
		text-decoration: none;
	}

	.essb-iw-learn:hover {
		text-decoration: underline;
	}

	/* badge */
	.essb-iw-badge {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		font-size: 11px;
		font-weight: 600;
		padding: 4px 10px;
		border-radius: 4px;
		white-space: nowrap;
	}

	.essb-iw-badge-active {
		background: #e7f8ee;
		color: #14803e;
	}

	.essb-iw-badge-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: #22c55e;
	}

	/* add-on feature card */
	.essb-iw-addon-card {
		display: flex;
		align-items: flex-start;
		gap: 14px;
		border: 1px solid #e2e8f5;
		border-radius: 6px;
		padding: 16px;
		background: #fff;
	}

	.essb-iw-addon-tile {
		width: 40px;
		height: 40px;
		border-radius: 6px;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
		color: #fff;
		background: #1b84ff;
	}

	.essb-iw-addon-tile.violet {
		background: #6c47ff;
	}

	.essb-iw-addon-info {
		flex: 1;
		min-width: 0;
	}

	.essb-iw-addon-info strong {
		display: block;
		font-size: 13.5px;
		font-weight: 600;
		color: #172153;
		margin-bottom: 2px;
	}

	.essb-iw-addon-info span {
		font-size: 12.5px;
		color: #4b5563;
		line-height: 1.55;
	}

	.essb-iw-suggest-label {
		display: block;
		font-size: 11px;
		font-weight: 600;
		letter-spacing: .04em;
		text-transform: uppercase;
		color: #8a94b5;
		margin-bottom: 8px;
	}

	.essb-iw-footer {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		padding: 14px 24px;
		border-top: 1px solid #eef2f8;
		background: #fff;
		flex-shrink: 0;
	}

	.essb-iw-foot-mid {
		font-size: 12px;
		color: #8a94b5;
		font-weight: 500;
	}

	@media (max-width: 720px) {
		.essb-iw-wrap {
			max-width: 100vw;
			max-height: 100vh;
			width: 100%;
			height: 100%;
			border-radius: 0;
			top: 0;
			left: 0;
			transform: none;
		}
		.essb-iw-mode-grid {
			grid-template-columns: 1fr;
		}
	}

	#wp-media-modal {
		z-index: 999999;
	}

	.mask-activation .essb-purchase-code {
		display: none;
	}

	.mask-activation .essb-masked-purchase-code {
		width: 100%;
	}
</style>

<div class="essb-df-wrap">

	<?php
	ESSB_MyAPI::dismiss_promotion();

	if (isset($_GET['essb_dismiss_wizard']) && $_GET['essb_dismiss_wizard'] == '1') {
		if (wp_verify_nonce($_GET['_wpnonce'], 'essb_dismiss_wizard')) {
			ESSB_Plugin_Options::set('wizard_dismissed', 'true');
			ESSB_Plugin_Options::save();
		}
	}

	$current_user = wp_get_current_user();
	$show_wizard_popup = !essb_option_bool_value('wizard_dismissed');
	$essb_dashboard_domain = (string) parse_url(home_url(), PHP_URL_HOST);


	?>


	<div class="essb-df-spot-hero">
		<div class="essb-df-spot-hero-left">
			<h2 class="essb-df-spot-hero-h"><?php echo esc_html__('Hi', 'essb') . ' ' . esc_html($current_user->display_name) . ','; ?></h2>
			<p class="essb-df-spot-hero-p"><?php esc_html_e('Welcome back. Run the setup wizard to switch on only what you need, or jump straight into your share button settings.', 'essb'); ?></p>
			<div class="essb-df-spot-hero-actions">
				<button style="display: none;" type="button" class="essb-df-btn essb-df-btn-gold essb-df-hero-iwizard"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 2l3 6 6 1-4.5 4 1 6-5.5-3-5.5 3 1-6L4 9l6-1z"/></svg><?php esc_html_e('Launch the Setup Wizard', 'essb'); ?></button>
				<a href="<?php echo esc_url(admin_url('admin.php?page=essb_redirect_social')); ?>" class="essb-df-btn essb-df-btn-ghost-light"><?php esc_html_e('Continue to Share Buttons Settings', 'essb'); ?></a>
			</div>
		</div>
		<div class="essb-df-spot-panel">
			<span class="essb-df-spot-panel-badge"><?php esc_html_e('New Plugin', 'essb'); ?></span>
			<div class="essb-df-spot-panel-title"><?php esc_html_e('Social Profile Card Studio', 'essb'); ?></div>
			<div class="essb-df-spot-panel-desc"><?php esc_html_e('Turn your bio link into a branded page — 72 presets, a smart style generator and reusable profile cards.', 'essb'); ?></div>
			<a href="https://socialsharingplugin.com/social-profile-card-studio/?utm_source=plugin&utm_medium=dashboard_banner&utm_campaign=social-profile-card-studio-<?php echo esc_attr($essb_dashboard_domain); ?>" target="_blank" rel="noopener" class="essb-df-btn essb-df-btn-gold essb-df-spot-panel-btn"><?php esc_html_e('Learn More', 'essb'); ?></a>
		</div>
	</div>
	<script>
	jQuery(function($) {
		$('.essb-df-hero-iwizard').on('click', function(e) {
			e.preventDefault();
			var btn = document.getElementById('essb-df-open-iwizard');
			if (btn) {
				btn.click();
			}
		});
	});
	</script>

	<?php if ($show_wizard_popup) { ?>
	<div class="essb-gs-overlay" id="essb-gs-overlay"></div>
	<div class="essb-gs-modal" id="essb-gs-modal">
		<div class="essb-gs-header">
			<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:#1b84ff"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
			<h2><?php esc_html_e('Thank you for choosing Easy Social Share Buttons for WordPress!', 'essb'); ?></h2>
		</div>
		<div class="essb-gs-body">
			<p><?php esc_html_e('Start the initial getting started wizard to help you determine the functions you need from the plugin. This will help keep only what you need active, and any function can be enabled later at any time.', 'essb'); ?></p>
		</div>
		<div class="essb-gs-footer">
			<button type="button" class="essb-ui-btn essb-ui-btn-primary essb-gs-start" id="essb-gs-start"><?php esc_html_e('Open Setup Wizard', 'essb'); ?></button>
			<a href="<?php echo esc_url(wp_nonce_url(add_query_arg('essb_dismiss_wizard', '1'), 'essb_dismiss_wizard')); ?>" class="essb-gs-dismiss"><?php esc_html_e('Dismiss', 'essb'); ?></a>
		</div>
	</div>
	<style>
		.essb-gs-overlay {
			position: fixed; top: 0; left: 0; width: 100%; height: 100%;
			background: rgba(23, 33, 83, .45); z-index: 999992;
		}
		.essb-gs-modal {
			position: fixed; top: 50%; left: 50%;
			transform: translate(-50%, -50%);
			background: #fff; border-radius: 12px;
			box-shadow: 0 16px 48px rgba(23, 33, 83, .2);
			width: 100%; max-width: 440px;
			z-index: 999993; padding: 0;
		}
		.essb-gs-header {
			padding: 28px 28px 0;
			text-align: center;
		}
		.essb-gs-header svg {
			margin-bottom: 12px;
		}
		.essb-gs-header h2 {
			font-size: 18px; font-weight: 600; color: #172153;
			margin: 0 0 16px; padding: 0; line-height: 1.3;
		}
		.essb-gs-body {
			padding: 0 28px;
		}
		.essb-gs-body p {
			font-size: 13px; color: #6b7280; line-height: 1.5; margin: 0;
		}
		.essb-gs-footer {
			padding: 20px 28px 28px;
			text-align: center;
		}
		.essb-gs-footer .essb-gs-start {
			display: block; width: 100%; margin-bottom: 10px;
			padding: 10px 20px; font-size: 14px; font-weight: 600;
			border: none; border-radius: 4px; cursor: pointer;
		}
		.essb-gs-dismiss {
			display: inline-block; font-size: 12px; color: #9ca3af;
			text-decoration: none;
		}
		.essb-gs-dismiss:hover {
			color: #6b7280;
		}
	</style>
	<script>
	jQuery(function($) {
		var wizardNonce = '<?php echo wp_create_nonce('essb_dismiss_wizard_ajax'); ?>';
		$('#essb-gs-start').on('click', function() {
			$('#essb-gs-overlay, #essb-gs-modal').fadeOut(200, function() {
				$('#essb-gs-overlay, #essb-gs-modal').remove();
			});
			$.post(ajaxurl, {
				action: 'essb_dismiss_wizard_popup',
				nonce: wizardNonce
			});
			document.getElementById('essb-df-open-iwizard').click();
		});
	});
	</script>
	<?php } ?>

	<div class="essb-df-main-content">
		<div class="essb-df-main-left">
			<h3 class="essb-df-section-title" style="margin-top:0;"><?php esc_html_e('Set up in minutes', 'essb'); ?></h3>
			<div class="essb-df-setup-row">

				<div class="essb-df-setup-card is-primary">
					<div class="essb-df-setup-icon">
						<svg width="32" height="32" viewBox="0 0 44 44" fill="#1b84ff" xmlns="http://www.w3.org/2000/svg">
							<path d="m15,19c-1.1,0-2,0.9-2,2s0.9,2 2,2c0.6,0 1.2-0.3 1.6-0.8 0.2-0.2 0.4-0.6 0.4-1.2 0-0.3-0.1-0.5-0.2-0.8-0.3-0.7-1-1.2-1.8-1.2z" />
							<path d="m26,31c1.1,0 2-0.9 2-2s-0.9-2-2-2c-0.6,0-1.2,0.3-1.6,0.8-0.2,0.2-0.4,0.6-0.4,1.2 0,1.1 0.9,2 2,2z" />
							<path d="m22,0c-12.2,0-22,9.8-22,22s9.8,22 22,22 22-9.8 22-22-9.8-22-22-22zm7,21c-1.6,0-3.1-0.7-4.2-1.7-0.1-0.1-0.4-0.2-0.5-0.1l-3,1.3c-0.2,0.1-0.3,0.3-0.3,0.5 0,0.5-0.1,1-0.2,1.4 0,0.2 0,0.4 0.2,0.5l1.3,.9c0.2,0.1 0.4,0.1 0.6,0 0.9-0.5 2-0.9 3.1-0.9 3.3,0 6,2.7 6,6s-2.7,6-6,6-6-2.7-6-6c0-0.5 0.1-0.9 0.2-1.4 0-0.2 0-0.4-0.2-0.5l-1.3-1c-0.2-0.1-0.4-0.1-0.6,0-0.9,0.6-2,0.9-3.1,0.9-3.3,0-6-2.7-6-6s2.7-6 6-6c1.6,0 3.1,0.7 4.2,1.7 0.1,0.1 0.4,0.2 0.5,0.1l3-1.3c0.2-0.1 0.3-0.3 0.3-0.5 0,0 0,0 0-0.1 0-3.3 2.7-6 6-6s6,2.7 6,6-2.7,6.2-6,6.2z" />
							<path d="m29,13c-1.1,0-2,0.9-2,2 0,0.3 0.1,0.5 0.2,0.8 0.3,0.7 1,1.2 1.8,1.2 1.1,0 2-0.9 2-2s-0.9-2-2-2z" />
						</svg>
					</div>
					<div class="essb-df-setup-body">
						<div class="essb-df-setup-head">
							<div class="essb-df-setup-title"><?php esc_html_e('Getting Started Wizard', 'essb'); ?></div>
							<span class="essb-df-setup-badge"><?php esc_html_e('Recommended', 'essb'); ?></span>
						</div>
						<div class="essb-df-setup-desc"><?php esc_html_e('Answer a few questions and the plugin switches on only the features you need.', 'essb'); ?></div>
					</div>
					<button type="button" class="essb-df-btn essb-df-btn-primary" id="essb-df-open-iwizard"><?php esc_html_e('Launch Setup Wizard', 'essb'); ?></button>
				</div>

				<div class="essb-df-setup-card">
					<div class="essb-df-setup-icon">
						<svg height="32" viewBox="0 0 32 32" width="32" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="#1b84ff">
							<path d="M26.7,21.3c-1.6,0-3.1,0.8-4,1.9l-9.8-4.9c0.3-0.8,0.4-1.5,0.4-2.3s-0.1-1.6-0.4-2.3l9.8-4.9c0.9,1.1,2.4,1.9,4,1.9c2.9,0,5.3-2.4,5.3-5.4S29.6,0,26.7,0s-5.4,2.4-5.4,5.3c0,0.4,0.1,0.8,0.1,1.1l-9.9,5l0,0c-1.2-1.3-2.9-2.1-4.8-2.1C3,9.3,0,12.3,0,16s3,6.7,6.7,6.7c1.9,0,3.6-0.8,4.8-2.1l0,0l9.9,5c-0.1,0.4-0.1,0.8-0.1,1.1c0,2.9,2.4,5.3,5.4,5.3s5.3-2.4,5.3-5.3S29.6,21.3,26.7,21.3z M26.7,2.7c1.4,0,2.6,1.2,2.6,2.6c0,1.5-1.2,2.7-2.6,2.7C25.2,8,24,6.8,24,5.3C24,3.9,25.2,2.7,26.7,2.7z M6.7,20c-2.3,0-4-1.8-4-4s1.8-4,4-4c2.2,0,4,1.8,4,4S8.9,20,6.7,20z M26.7,29.3c-1.5,0-2.7-1.2-2.7-2.6c0-1.5,1.2-2.7,2.7-2.7c1.4,0,2.6,1.2,2.6,2.7C29.3,28.1,28.1,29.3,26.7,29.3z" />
						</svg>
					</div>
					<div class="essb-df-setup-body">
						<div class="essb-df-setup-head">
							<div class="essb-df-setup-title"><?php esc_html_e('Quick Share Buttons Setup', 'essb'); ?></div>
						</div>
						<div class="essb-df-setup-desc"><?php esc_html_e('Pick networks, button style, counters and display positions in minutes.', 'essb'); ?></div>
					</div>
					<button type="button" class="essb-df-btn essb-df-btn-ghost" id="essb-df-open-swizard"><?php esc_html_e('Open Quick Setup', 'essb'); ?></button>
				</div>

				<div class="essb-df-setup-card">
					<div class="essb-df-setup-icon">
						<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#1b84ff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
							<path d="M12 2L2 7l10 5 10-5-10-5z" />
							<path d="M2 17l10 5 10-5" />
							<path d="M2 12l10 5 10-5" />
						</svg>
					</div>
					<div class="essb-df-setup-body">
						<div class="essb-df-setup-head">
							<div class="essb-df-setup-title"><?php esc_html_e('Optimize Performance', 'essb'); ?></div>
						</div>
						<div class="essb-df-setup-desc"><?php esc_html_e('Choose asset modes and loading methods for a faster, lighter site.', 'essb'); ?></div>
					</div>
					<button type="button" class="essb-df-btn essb-df-btn-ghost" id="essb-df-open-wizard"><?php esc_html_e('Open Optimization', 'essb'); ?></button>
				</div>

				<div class="essb-df-setup-card">
					<div class="essb-df-setup-icon essb-df-setup-icon-fill">
						<?php echo essb_ui_get_svg_icon('profile_card'); ?>
					</div>
					<div class="essb-df-setup-body">
						<div class="essb-df-setup-head">
							<div class="essb-df-setup-title"><?php esc_html_e('Create a Link in Bio page', 'essb'); ?></div>
						</div>
						<div class="essb-df-setup-desc"><?php esc_html_e('Build a branded, mobile-first link in bio page using the Social Profile Card Studio Free plugin — 72 presets and a smart style generator.', 'essb'); ?></div>
					</div>
					<button type="button" class="essb-df-btn essb-df-btn-primary" data-spcad-create data-state="<?php echo esc_attr(essb_addon_get_state('social-profile-card-studio')); ?>" data-install-nonce="<?php echo esc_attr(wp_create_nonce('essb_install_free_addon')); ?>" data-redirect="<?php echo esc_url(admin_url('admin.php?page=spcad-card-studio')); ?>"><?php esc_html_e('Create', 'essb'); ?></button>
				</div>
			</div>

			<script>
			jQuery(function($) {
				function essbSpcadToast(message, isError) {
					var cls = isError ? 'essb-df-toast essb-df-toast-error' : 'essb-df-toast essb-df-toast-success';
					var $toast = $('<div></div>').addClass(cls).text(message).appendTo('body');
					setTimeout(function() { $toast.addClass('essb-df-toast-show'); }, 10);
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() { $toast.remove(); }, 300);
					}, isError ? 3200 : 2200);
				}

				function essbSpcadOpen(url) {
					if (!url) { return; }
					var win = window.open(url, '_blank');
					if (!win) { window.location.href = url; }
				}

				$(document).on('click', '[data-spcad-create]', function(e) {
					e.preventDefault();

					var $btn = $(this);
					var url = $btn.attr('data-redirect') || '';
					var nonce = $btn.attr('data-install-nonce') || '';
					var state = $btn.attr('data-state') || '';

					if (state === 'active') {
						essbSpcadOpen(url);
						return;
					}

					var originalText = $btn.text();
					$btn.prop('disabled', true).text('Processing\u2026');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'essb_install_free_addon',
							slug: 'social-profile-card-studio',
							nonce: nonce
						},
						success: function(response) {
							if (response && response.success) {
								$btn.text('Active');
								essbSpcadToast('Social Profile Card Studio installed and activated.');
								essbSpcadOpen(url);
							} else {
								var msg = (response && response.data && response.data.message) ? response.data.message : 'Installation failed';
								$btn.prop('disabled', false).text(originalText);
								essbSpcadToast(msg, true);
							}
						},
						error: function() {
							$btn.prop('disabled', false).text(originalText);
							essbSpcadToast('Connection error. Please try again.', true);
						}
					});
				});
			});
			</script>

			<?php
			if (function_exists('essb_dashboard_addons_updates_render')) {
				essb_dashboard_addons_updates_render();
			}
			?>

		</div>
		<div class="essb-df-main-right">
			<div class="essb-df-news-widget">
				<div class="essb-df-news-heading"><?php esc_html_e('Latest News', 'essb'); ?></div>
				<?php
				if (essb_option_bool_value('deactivate_addons_remote')) :
				?>
					<div class="essb-df-news-disabled-notice" style="padding:16px 20px;margin:12px 0;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #f59e0b;border-radius:6px;font-size:13px;color:#64748b;line-height:1.6;">
						<?php esc_html_e('News updates are currently disabled. Remote API connections are turned off.', 'essb'); ?>
					</div>
				<?php
				else :
					$current_news = ESSB_MyAPI::get_latest_news();
					if (is_array($current_news)) {
						echo ESSB_MyAPI::generate_news_output($current_news);
					}
				endif;
				?>
				<div class="essb-df-news-footer"><a href="https://socialsharingplugin.com/news/?utm_source=plugin&utm_medium=dashboard_news&utm_campaign=read-all-news-<?php echo esc_attr($essb_dashboard_domain); ?>" target="_blank" class="essb-ui-btn essb-ui-btn-link"><?php esc_html_e('Read All News', 'essb'); ?> <span class="screen-reader-text"><?php esc_html_e('(opens in a new window)', 'essb'); ?></span><span aria-hidden="true" class="dashicons dashicons-external" style="font-size:14px;width:14px;height:14px;"></span></a></div>
			</div>
		</div>
	</div>

	<?php

	if (essb_is_envato_version()) {
	?>
		<div class="essb-activation-form" id="activate">
			<div class="essb-activation-form-title">
				<div class="essb-activation-title<?php if (ESSB_Envato_Activation_Manager::isActivated()) {
														echo " color-activated";
													} else {
														echo " color-notactivated";
													} ?>"><?php echo esc_html__('Plugin Activation', 'essb'); ?></div>
				<div class="essb-activation-state<?php if (ESSB_Envato_Activation_Manager::isActivated()) {
														echo " background-activated";
													} else {
														echo " background-notactivated";
													} ?>">
					<i class="fa fa-<?php if (ESSB_Envato_Activation_Manager::isActivated() || ESSB_Envato_Activation_Manager::isThemeIntegrated()) {
										echo "check";
									} else {
										echo "ban";
									} ?>"></i> <?php echo ESSB_Envato_Activation_Manager::isActivated() ? esc_html__('Activated', 'essb') : esc_html__('Not Activated', 'essb'); ?>
				</div>
			</div>

			<?php if (!ESSB_Envato_Activation_Manager::isActivated() && !ESSB_Envato_Activation_Manager::isThemeIntegrated() && ESSB_Envato_Activation_Manager::isDevelopment()): ?>
				<div class="essb-activate-localhost">
					<?php esc_html_e('You are running the plugin in a development environment. Activation is optional and allows you to use locked plugin features without affecting the activation status of your live site.', 'essb'); ?>
				</div>
			<?php endif; ?>

			<div class="essb-activation-form-code">
				<div class="essb-activation-form-header">
					<strong><?php echo esc_html__('Purchase code', 'essb'); ?></strong>
					<br />You can learn how to find your purchase code <a href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-" target="_blank">here</a>

				</div>
				<?php if (ESSB_Envato_Activation_Manager::isActivated()) {
					echo '<div class="mask-activation">';
				} ?>
				<input type="text" class="essb-purchase-code" id="essb-automatic-purchase-code" value="<?php echo ESSB_Envato_Activation_Manager::getPurchaseCode(); ?>" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />

				<?php if (ESSB_Envato_Activation_Manager::isActivated()) { ?>
					<input type="text" class="essb-masked-purchase-code" disabled value="<?php echo ESSB_Envato_Activation_Manager::getMaskedPurchaseCode(); ?>" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
				<?php echo '</div>';
				} ?>
			</div>


			<div class="essb-activation-buttons">
				<?php if (!ESSB_Envato_Activation_Manager::isActivated()) { ?>
					<a href="#" id="essb-activate" class="essb-activation-button essb-activation-button-default essb-activate-plugin"><?php echo esc_html__('Register the code', 'essb'); ?></a>
				<?php } ?>
				<?php if (ESSB_Envato_Activation_Manager::isActivated()) { ?>
					<a href="#" id="essb-deactivate" class="essb-activation-button essb-activation-button-default essb-deactivate-plugin"><?php echo esc_html__('Deregister the code', 'essb'); ?></a>
				<?php } ?>
			</div>
		</div>
	<?php
	}

	?>

	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;margin-top:24px;">
		<h3 style="margin:0;padding:0;font-size:18px;font-weight:500;color:#172153;"><?php esc_html_e('Featured Add-Ons', 'essb'); ?></h3>
		<a href="<?php echo esc_url(admin_url('admin.php?page=essb_redirect_addons')); ?>" class="essb-ui-btn essb-ui-btn-link"><?php esc_html_e('View All Add-ons', 'essb'); ?> <span aria-hidden="true" class="dashicons dashicons-external" style="font-size:14px;width:14px;height:14px;"></span></a>
	</div>
	<div class="essb-df-carousel">
		<div class="essb-df-carousel-track" id="essb-df-carousel-track">
			<!-- Slide 1: Link In Bio page builder + Social Chat -->
			<div class="essb-df-carousel-slide">
				<div class="essb-df-addon-card essb-df-addon-violet">
					<div class="essb-df-addon-icon">
						<svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
							<path fill="#FFFFFF" fill-rule="evenodd" d="M68,20h120c28,0,48,20,48,48v120c0,28-20,48-48,48H68c-28,0-48-20-48-48V68c0-28,20-48,48-48z M128,58c-21,0-38,17-38,38s17,38,38,38s38-17,38-38S149,58,128,58z M128,140c-40,0-73,32-73,72v10h146v-10C201,172,168,140,128,140z"></path>
						</svg>
					</div>
					<div class="essb-df-addon-body">
						<div class="essb-df-addon-name"><?php esc_html_e('Link In Bio page builder', 'essb'); ?></div>
						<div class="essb-df-addon-desc"><?php esc_html_e('Turn your bio link into a branded page and use your profile card anywhere on your site.', 'essb'); ?></div>
						<a href="https://socialsharingplugin.com/social-profile-card-studio/?utm_source=plugin&utm_medium=dashboard_banner&utm_campaign=social-profile-card-studio-<?php echo esc_attr($essb_dashboard_domain); ?>" target="_blank" class="essb-df-addon-btn"><?php esc_html_e('Learn More', 'essb'); ?></a>
					</div>
				</div>
				<div class="essb-df-addon-card essb-df-addon-purple">
					<div class="essb-df-addon-icon">
						<svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
							<path fill="#FFFFFF" d="M218,98c0-9.2-7.5-16.7-16.7-16.7H178V58c0-9.2-7.5-16.7-16.7-16.7H54.7C45.5,41.3,38,48.8,38,58v106.7 c0,5.5,4.5,10,10,10c2.3,0,4.5-0.8,6.3-2.2L78,153.3l0,18.1c0,9.2,7.5,16.7,16.7,16.7h76.8l30.2,24.4c4.3,3.5,10.6,2.8,14.1-1.5 c1.4-1.8,2.2-4,2.2-6.3L218,98z M58,143.7V61.3h100v30l0,0l0,0V128H81c-2.3,0-4.5,0.8-6.3,2.2L58,143.7z M181.3,170.2 c-1.8-1.4-4-2.2-6.3-2.2H98l0-20h63.3c9.2,0,16.7-7.5,16.7-16.7v-30h20l0,82.4L181.3,170.2z"></path>
						</svg>
					</div>
					<div class="essb-df-addon-body">
						<div class="essb-df-addon-name"><?php esc_html_e('Social Chat', 'essb'); ?></div>
						<div class="essb-df-addon-desc"><?php esc_html_e('Add WhatsApp, Telegram, Viber, Signal, Line, and more chat buttons to your site.', 'essb'); ?></div>
						<a href="https://socialsharingplugin.com/social-chat/?utm_source=plugin&utm_medium=dashboard_banner&utm_campaign=social-chat-<?php echo esc_attr($essb_dashboard_domain); ?>" target="_blank" class="essb-df-addon-btn"><?php esc_html_e('Learn More', 'essb'); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<h3 class="essb-df-section-title"><?php esc_html_e('Popular Share Features', 'essb'); ?></h3>
	<div class="essb-df-grid">
		<?php
		essb_dashboard_feature_card(
			esc_html__('Pinterest Pro', 'essb'),
			esc_html__('Add hover-activated Pin buttons to images with customizable positioning and styling. Supports lazy-loaded images and page builders.', 'essb'),
			'pinterest',
			'deactivate_module_pinterestpro',
			'https://socialsharingplugin.com/pinterest-pro-image-hover-pins/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=pinterest-pro-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=pinpro')
		);
		essb_dashboard_feature_card(
			esc_html__('Sharable Quotes', 'essb'),
			esc_html__('Boost shares with beautifully designed click-to-share quotes for X (formerly Twitter). No coding needed.', 'essb'),
			'twitter_x',
			'deactivate_ctt',
			'https://socialsharingplugin.com/click-to-tweet/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=sharable-quotes-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=clicktotweet')
		);
		essb_dashboard_feature_card(
			esc_html__('Highlight Share', 'essb'),
			esc_html__('Show a floating share bar over text visitors highlight, supporting multiple networks.', 'essb'),
			'share_events',
			'deactivate_highlight_share',
			'',
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=highlight_share')
		);
		essb_dashboard_feature_card(
			esc_html__('WooCommerce', 'essb'),
			esc_html__('Unlock additional WooCommerce integrations and display methods to maximize social sharing on your store.', 'essb'),
			'cart',
			'deactivate_method_woocommerce',
			'https://socialsharingplugin.com/woocommerce-social-sharing/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=woocommerce-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_where&tab=where&section=positions')
		);
		essb_dashboard_feature_card(
			esc_html__('Share Optimizations', 'essb'),
			esc_html__('Add social share optimization meta tags for precise control over how your content appears when shared.', 'essb'),
			'share_optimization',
			'deactivate_module_shareoptimize',
			'',
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=optimize')
		);
		essb_dashboard_feature_card(
			esc_html__('Share Counters', 'essb'),
			esc_html__('Display and update share counters on your buttons. Disabling this also turns off features that depend on share values.', 'essb'),
			'numbers',
			'deactivate_share_counters',
			'',
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=sharecnt')
		);
		essb_dashboard_feature_card(
			esc_html__('Plugin Analytics', 'essb'),
			esc_html__('Track social sharing performance with privacy-safe analytics. Gain real-time insights to optimize engagement.', 'essb'),
			'analytics',
			'deactivate_module_analytics',
			'https://socialsharingplugin.com/social-sharing/advanced-privacy-safe-analytics-for-wordpress-share-buttons/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=plugin-analytics-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=analytics')
		);
		essb_dashboard_feature_card(
			esc_html__('Short URL', 'essb'),
			esc_html__('Generate short URLs for sharing your content across social networks.', 'essb'),
			'short_url',
			'deactivate_module_shorturl',
			'',
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=shorturl')
		);
		essb_dashboard_addon_card(
			esc_html__('Shorty - Self Hosted Short URLs', 'essb'),
			esc_html__('Create and manage your own self-hosted short URLs on your WordPress site with no third-party dependency.', 'essb'),
			'short_url',
			array(array('param' => 'SHORTY_VERSION', 'type' => 'param')),
			'https://socialsharingplugin.com/addons/shorty-self-hosted-shorturls/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=shorty-' . $essb_dashboard_domain,
			'shorty'
		);

		essb_dashboard_addon_card(
			esc_html__('AI Social Booster'),
			esc_html__('Generate scroll-stopping social media titles, tweets, and share messages directly from your content using AI.', 'essb'),
			'affiliate',
			array(array('param' => 'ESSB_AI_BOOSTER_VERSION', 'type' => 'param')),
			'https://socialsharingplugin.com/addons/ai-social-booster/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=ai-social-booster-' . $essb_dashboard_domain,
			'ai-social-booster'
		);
		?>
	</div>

	<h3 class="essb-df-section-title"><?php esc_html_e('Popular Social Features', 'essb'); ?></h3>
	<div class="essb-df-grid">
		<?php
		essb_dashboard_addon_card(
			esc_html__('Link in Bio Pages & Social Profile Cards Builder', 'essb'),
			esc_html__('Social Profile Card Studio turns your bio link into a branded page - and works as a card anywhere on your site. 72 presets, a smart style generator and more.', 'essb'),
			'profile_card',
			array(array('param' => 'SPCAD_VERSION', 'type' => 'param')),
			'https://socialsharingplugin.com/social-profile-card-studio/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=social-profile-card-studio-' . $essb_dashboard_domain,
			'social-profile-card-studio'
		);
		essb_dashboard_feature_card(
			esc_html__('Social Profile Links', 'essb'),
			esc_html__('Add plain buttons linking to your social profiles using shortcode, widget, or sidebar.', 'essb'),
			'user_heart',
			'deactivate_module_profiles',
			'https://socialsharingplugin.com/social-profiles/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=social-profile-links-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_profiles&tab=profiles')
		);
		essb_dashboard_feature_card(
			esc_html__('Social Followers Counter', 'essb'),
			esc_html__('Display follower counts for 30+ social networks to showcase your social proof.', 'essb'),
			'heart',
			'deactivate_module_followers',
			'https://socialsharingplugin.com/social-followers-counter/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=social-followers-counter-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_follow&tab=follow')
		);
		essb_dashboard_feature_card(
			esc_html__('Subscribe Forms', 'essb'),
			esc_html__('Add easy-to-use subscribe forms to grow your mailing list with minimal effort.', 'essb'),
			'mail',
			'deactivate_module_subscribe',
			'https://socialsharingplugin.com/grow-your-mailing-list-subscribers/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=subscribe-forms-' . $essb_dashboard_domain,
			admin_url('admin.php?page=essb_redirect_subscribe&tab=subscribe&section=optin-1')
		);
		essb_dashboard_addon_card(
			esc_html__('Social Chat', 'essb'),
			esc_html__('Add WhatsApp, Telegram, Viber, Signal, Line, and other chat buttons to your site.', 'essb'),
			'chat',
			array(array('param' => 'ESSC_VERSION', 'type' => 'param')),
			'https://socialsharingplugin.com/social-chat/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=social-chat-' . $essb_dashboard_domain,
			'social-chat'
		);
		essb_dashboard_addon_card(
			esc_html__('Social Contact', 'essb'),
			esc_html__('Add social contact buttons to your site - WhatsApp, Viber, Telegram, Line, Signal, SMS, iMessage, Phone and Email.', 'essb'),
			'chat',
			array(array('param' => 'ESSB_SC_VERSION', 'type' => 'param')),
			'https://socialsharingplugin.com/social-contact/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=essb-social-contact-' . $essb_dashboard_domain,
			'essb-social-contact'
		);
		essb_dashboard_addon_card(
			esc_html__('Proofly - Social Proof Notifications', 'essb'),
			esc_html__('Add FOMO-driven social proof notifications showing real purchase alerts, share counts, and custom messages.', 'essb'),
			'notification',
			array(array('param' => 'PROOFLY_VERSION', 'type' => 'param')),
			'https://socialsharingplugin.com/addons/proofly-social-proof-notifications/?utm_source=plugin&utm_medium=dashboard_feature&utm_campaign=proofly-' . $essb_dashboard_domain
		);
		essb_dashboard_feature_card(
			esc_html__('Custom Network Buttons', 'essb'),
			esc_html__('Add custom network buttons to your share or follow dialogs.', 'essb'),
			'buttons',
			'deactivate_custombuttons',
			'',
			admin_url('admin.php?page=essb_redirect_social&tab=social&section=custombuttons')
		);
		essb_dashboard_feature_card(
			esc_html__('Custom Display / Positions', 'essb'),
			esc_html__('Create custom display positions you can show anywhere via shortcode or function call.', 'essb'),
			'content',
			'deactivate_custompositions',
			'',
			admin_url('admin.php?page=essb_redirect_where&tab=where&section=custom')
		);
		essb_dashboard_feature_card(
			esc_html__('Functions Translate', 'essb'),
			esc_html__('Translate preset plugin texts into your language for a fully localized experience.', 'essb'),
			'translate',
			'deactivate_module_translate',
			'',
			admin_url('admin.php?page=essb_redirect_advanced&tab=advanced&section=localization')
		);
		?>
	</div>

	<div class="essb-df-wrap-bottom-text">
		<p><?php esc_html_e('These are the most popular features. You can manage all available plugin features from the features manager.', 'essb'); ?> <a class="essb-ui-btn essb-ui-btn-link essb-head-featuresbtn" href="#"><?php esc_html_e('Manage All Features', 'essb'); ?></a> <?php esc_html_e('or', 'essb'); ?> <a class="essb-ui-btn essb-ui-btn-link essb-head-positionsbtn" href="#"><?php esc_html_e('Manage All Display Positions', 'essb'); ?></a></p>
	</div>
</div>

<!-- Optimization Wizard Overlay -->
<div class="essb-ow-overlay" id="essb-ow-overlay"></div>

<!-- Optimization Wizard Modal -->
<div class="essb-ow-wrap" id="essb-ow-wizard">
	<div class="essb-ow-header">
		<div class="essb-ow-header-title">
			<span class="essb-ow-logo">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z" /></svg>
			</span>
			<?php esc_html_e('Optimization Wizard', 'essb'); ?>
		</div>
		<button type="button" class="essb-ow-close" id="essb-ow-close" title="<?php esc_attr_e('Close', 'essb'); ?>">
			<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
			<?php esc_html_e('Exit', 'essb'); ?>
		</button>
	</div>
	<div class="essb-ow-progress">
		<div class="essb-ow-progress-top">
			<span class="essb-ow-phase" id="essb-ow-phase"><?php esc_html_e('Setup', 'essb'); ?></span>
			<span class="essb-ow-stepmeta" id="essb-ow-stepmeta"><?php esc_html_e('Step 1 of 4', 'essb'); ?></span>
		</div>
		<div class="essb-ow-track"><div class="essb-ow-fill" id="essb-ow-fill"></div></div>
	</div>
	<div class="essb-ow-body">

		<!-- Step 1: Share Button Assets Mode -->
		<div class="essb-ow-pane essb-ow-pane-active" data-pane="1">
			<h2 class="essb-ow-pane-title"><?php esc_html_e('Share Button Assets Mode', 'essb'); ?></h2>
			<p class="essb-ow-pane-desc">
				<?php esc_html_e('Choose how the plugin loads its CSS and JavaScript files. If you need every feature and maximum flexibility, choose Full. If performance is your priority, choose Light. Modes different from Full will automatically disable some features to reduce file size and improve load times.', 'essb'); ?>
				<a href="https://docs.socialsharingplugin.com/knowledgebase/how-to-choose-the-right-css-js-mode-for-your-share-buttons/" target="_blank"><?php esc_html_e('Learn more about asset modes.', 'essb'); ?></a>
			</p>
			<div class="essb-ow-list">
				<label class="essb-ow-list-item essb-ow-list-selected">
					<input type="radio" name="essb-ow-css-mode" value="" checked hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Full', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('All features and networks loaded. No optimization applied. Best for sites that need every available option.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-list-item">
					<input type="radio" name="essb-ow-css-mode" value="slim" hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Slim', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Optimized file sizes with minification. Some non-essential features are disabled. Recommended for most sites.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-list-item">
					<input type="radio" name="essb-ow-css-mode" value="mini" hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Mini', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Minimal footprint. Only popular networks remain active. Majority of advanced features are disabled.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-list-item">
					<input type="radio" name="essb-ow-css-mode" value="light" hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Light', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Maximum performance with the smallest file size. Only essential features are kept. Best for speed-critical sites.', 'essb'); ?></span>
					</span>
				</label>
			</div>
		</div>

		<!-- Step 2: Script Loading Method -->
		<div class="essb-ow-pane" data-pane="2">
			<h2 class="essb-ow-pane-title"><?php esc_html_e('Script Loading Method', 'essb'); ?></h2>
			<p class="essb-ow-pane-desc"><?php esc_html_e('Control how plugin JavaScript files are loaded.', 'essb'); ?></p>
			<div class="essb-ow-note"><strong><?php esc_html_e('Note:', 'essb'); ?></strong> <?php esc_html_e('If your site uses an optimization or cache plugin, leave this set to Default to prevent conflicts with button behavior.', 'essb'); ?></div>
			<div class="essb-ow-list">
				<label class="essb-ow-list-item essb-ow-list-selected">
					<input type="radio" name="essb-ow-js-mode" value="" checked hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Default', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('JavaScript loads in the page footer. Provides the widest compatibility with themes, plugins, and cache solutions.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-list-item">
					<input type="radio" name="essb-ow-js-mode" value="async" hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Asynchronous', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Scripts load in the background without blocking page rendering. Pages feel faster but some features may delay appearing.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-list-item">
					<input type="radio" name="essb-ow-js-mode" value="defer" hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Deferred', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Scripts execute after the full page has loaded. Best for non-critical features where timing is not important.', 'essb'); ?></span>
					</span>
				</label>
			</div>
		</div>

		<!-- Step 3: Style Loading Method -->
		<div class="essb-ow-pane" data-pane="3">
			<h2 class="essb-ow-pane-title"><?php esc_html_e('Style Loading Method', 'essb'); ?></h2>
			<p class="essb-ow-pane-desc"><?php esc_html_e('Choose how plugin stylesheets are delivered to balance visual stability and page speed.', 'essb'); ?></p>
			<div class="essb-ow-note"><strong><?php esc_html_e('Note:', 'essb'); ?></strong> <?php esc_html_e('If your site uses an optimization or cache plugin, leave this set to Default to avoid conflicts with button styling.', 'essb'); ?></div>
			<div class="essb-ow-list">
				<label class="essb-ow-list-item essb-ow-list-selected">
					<input type="radio" name="essb-ow-style-mode" value="" checked hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Default', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Minified stylesheets load normally. Best compatibility. No risk of unstyled content flashes.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-list-item">
					<input type="radio" name="essb-ow-style-mode" value="defer" hidden>
					<span class="essb-ow-list-radio"></span>
					<span class="essb-ow-list-content">
						<span class="essb-ow-list-title"><?php esc_html_e('Deferred', 'essb'); ?></span>
						<span class="essb-ow-list-desc"><?php esc_html_e('Dynamically generated CSS moves to the footer so the browser renders content sooner. May cause a brief flash of unstyled content on slower connections.', 'essb'); ?></span>
					</span>
				</label>
			</div>
		</div>

		<!-- Step 4: Combine CSS & JS Files -->
		<div class="essb-ow-pane" data-pane="4">
			<h2 class="essb-ow-pane-title"><?php esc_html_e('Combine CSS &amp; JS Files', 'essb'); ?></h2>
			<p class="essb-ow-pane-desc"><?php esc_html_e('Combine all CSS and JavaScript into single cached files to reduce HTTP requests. This can improve load time.', 'essb'); ?></p>
			<div class="essb-ow-note"><strong><?php esc_html_e('Note:', 'essb'); ?></strong> <?php esc_html_e('Do not enable this if your site already uses an optimization or cache plugin - it may cause visual issues or missing buttons.', 'essb'); ?></div>
			<label class="essb-ow-toggle essb-ow-toggle-large">
				<input type="checkbox" id="essb-ow-precompiled-enable">
				<span class="essb-ow-toggle-track"></span>
				<span class="essb-ow-toggle-content">
					<span class="essb-ow-toggle-label"><?php esc_html_e('Enable combining of CSS and JavaScript files', 'essb'); ?></span>
					<span class="essb-ow-toggle-desc"><?php esc_html_e('Combine all used CSS and JavaScript files into one file each to reduce the number of HTTP requests.', 'essb'); ?></span>
				</span>
			</label>
			<div class="essb-ow-options" id="essb-ow-precompiled-options" style="display:none;">
				<div class="essb-ow-field">
					<label class="essb-ow-field-label"><?php esc_html_e('Combine type', 'essb'); ?></label>
					<select class="essb-ow-select" id="essb-ow-precompiled-mode">
						<option value=""><?php esc_html_e('CSS and JavaScript', 'essb'); ?></option>
						<option value="css"><?php esc_html_e('CSS only', 'essb'); ?></option>
						<option value="js"><?php esc_html_e('JavaScript only', 'essb'); ?></option>
					</select>
				</div>
				<label class="essb-ow-toggle">
					<input type="checkbox" id="essb-ow-precompiled-unique">
					<span class="essb-ow-toggle-track"></span>
					<span class="essb-ow-toggle-content">
						<span class="essb-ow-toggle-label"><?php esc_html_e('Generate unique filename per cache clear', 'essb'); ?></span>
						<span class="essb-ow-toggle-desc"><?php esc_html_e('Creates a new filename each time the cache is refreshed. Recommended when using a CDN to bypass stale cached files.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-toggle">
					<input type="checkbox" id="essb-ow-precompiled-post">
					<span class="essb-ow-toggle-track"></span>
					<span class="essb-ow-toggle-content">
						<span class="essb-ow-toggle-label"><?php esc_html_e('Generate separate cache file per post or page', 'essb'); ?></span>
						<span class="essb-ow-toggle-desc"><?php esc_html_e('Creates individual cache files per page. Useful for large sites but may generate many stored files in the cache folder.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-toggle">
					<input type="checkbox" id="essb-ow-precompiled-footer">
					<span class="essb-ow-toggle-track"></span>
					<span class="essb-ow-toggle-content">
						<span class="essb-ow-toggle-label"><?php esc_html_e('Move CSS styles to footer', 'essb'); ?></span>
						<span class="essb-ow-toggle-desc"><?php esc_html_e('Makes CSS non-render-blocking by loading it in the footer. Improves page load metrics but may cause a flash of unstyled content.', 'essb'); ?></span>
					</span>
				</label>
				<label class="essb-ow-toggle">
					<input type="checkbox" id="essb-ow-precompiled-preload-css">
					<span class="essb-ow-toggle-track"></span>
					<span class="essb-ow-toggle-content">
						<span class="essb-ow-toggle-label"><?php esc_html_e('Load CSS asynchronously (rel=preload)', 'essb'); ?></span>
						<span class="essb-ow-toggle-desc"><?php esc_html_e('Instructs the browser to preload CSS files in the background without blocking page rendering.', 'essb'); ?></span>
					</span>
				</label>
			</div>
		</div>

		<!-- Step 5: Summary -->
		<div class="essb-ow-pane" data-pane="5">
			<h2 class="essb-ow-pane-title"><?php esc_html_e('Review and Apply', 'essb'); ?></h2>
			<p class="essb-ow-pane-desc"><?php esc_html_e('Review the optimizations below. Once applied, you can change any setting later from the Advanced settings page.', 'essb'); ?></p>
			<div class="essb-ow-note"><strong><?php esc_html_e('Important:', 'essb'); ?></strong> <?php esc_html_e('Changes are not saved until you click the Apply Optimization button below.', 'essb'); ?></div>
			<div class="essb-ow-summary" id="essb-ow-summary">
				<div class="essb-ow-summary-item">
					<div class="essb-ow-summary-check"><svg width="16" height="16" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Share Button Assets Mode', 'essb'); ?></strong>
						<p id="essb-ow-summary-css"><?php esc_html_e('Full - all features, no optimization', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-ow-summary-item">
					<div class="essb-ow-summary-check"><svg width="16" height="16" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Script Loading Method', 'essb'); ?></strong>
						<p id="essb-ow-summary-js"><?php esc_html_e('Default - footer, best compatibility', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-ow-summary-item">
					<div class="essb-ow-summary-check"><svg width="16" height="16" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Style Loading Method', 'essb'); ?></strong>
						<p id="essb-ow-summary-style"><?php esc_html_e('Default - minified CSS', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-ow-summary-item">
					<div class="essb-ow-summary-check"><svg width="16" height="16" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Combine CSS &amp; JS Files', 'essb'); ?></strong>
						<p id="essb-ow-summary-precompiled"><?php esc_html_e('Disabled', 'essb'); ?></p>
					</div>
				</div>
			</div>
			<div class="essb-ow-apply-wrap">
				<button type="button" class="essb-ow-btn essb-ow-btn-primary" id="essb-ow-apply"><?php esc_html_e('Apply Optimization', 'essb'); ?></button>
			</div>
		</div>

	</div>
	<div class="essb-ow-footer">
		<button type="button" class="essb-ow-btn essb-ow-btn-ghost" id="essb-ow-prev" disabled>&larr; <?php esc_html_e('Previous', 'essb'); ?></button>
		<span class="essb-ow-footmeta" id="essb-ow-footmeta"><?php esc_html_e('Step 1 of 4', 'essb'); ?></span>
		<button type="button" class="essb-ow-btn essb-ow-btn-primary" id="essb-ow-next"><?php esc_html_e('Next', 'essb'); ?> &rarr;</button>
	</div>
</div>


<div class="essb-sw-overlay" id="essb-sw-overlay"></div>
<div class="essb-sw-wrap" id="essb-sw-wizard">
	<div class="essb-sw-header">
		<div class="essb-sw-header-title">
			<span class="essb-sw-logo">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><line x1="8.6" y1="10.6" x2="15.4" y2="6.4" /><line x1="8.6" y1="13.4" x2="15.4" y2="17.6" /></svg>
			</span>
			<?php esc_html_e('Quick Share Buttons Setup', 'essb'); ?>
		</div>
		<button type="button" class="essb-sw-close" id="essb-sw-close" title="<?php esc_attr_e('Close', 'essb'); ?>">
			<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
			<?php esc_html_e('Exit', 'essb'); ?>
		</button>
	</div>
	<div class="essb-sw-progress">
		<div class="essb-sw-progress-top">
			<span class="essb-sw-phase" id="essb-sw-phase"><?php esc_html_e('Networks', 'essb'); ?></span>
			<span class="essb-sw-stepmeta" id="essb-sw-stepmeta"><?php esc_html_e('Step 1 of 7', 'essb'); ?></span>
		</div>
		<div class="essb-sw-track"><div class="essb-sw-fill" id="essb-sw-fill"></div></div>
	</div>
	<div class="essb-sw-body">

		<!-- Step 1: Networks -->
		<div class="essb-sw-pane essb-sw-pane-active" data-pane="1">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Choose Your Networks', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Select the social networks you want to display. Drag to reorder. The first 4 are pre-selected.', 'essb'); ?></p>
			<input type="text" class="essb-sw-network-search" id="essb-sw-network-search" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
			<div class="essb-sw-network-grid" id="essb-sw-network-grid">
				<?php
				$all_networks = essb_available_social_networks(true);
				$network_colors = array(
					'facebook' => '#1877F2',
					'twitter' => '#000000',
					'linkedin' => '#0A66C2',
					'pinterest' => '#E60023',
					'whatsapp' => '#25D366',
					'telegram' => '#26A5E4',
					'messenger' => '#0078FF',
					'mail' => '#EA4335',
					'reddit' => '#FF4500',
					'tumblr' => '#36465D',
					'vk' => '#4680C2',
					'xing' => '#006567',
					'pocket' => '#EF3F56',
					'flipboard' => '#E12828',
					'digg' => '#000000',
					'ok' => '#EE8208',
					'weibo' => '#E6162D',
					'print' => '#6b7280',
					'copy' => '#6b7280',
					'love' => '#FF6B6B',
					'buffer' => '#231F20',
					'more' => '#6b7280',
					'hackernews' => '#FF6600',
					'evernote' => '#00A82D',
					'blogger' => '#F57D00',
					'gmail' => '#D44638',
					'yahoomail' => '#6001D2',
					'line' => '#00C300',
					'viber' => '#665CAC',
					'flattr' => '#000000',
					'meneame' => '#FF6400',
					'skype' => '#00AFF0',
					'kakaotalk' => '#FFE500',
					'sms' => '#6b7280',
					'subscribe' => '#6b7280',
					'livejournal' => '#00B0EA',
					'yammer' => '#0072C6',
					'mix' => '#FF8126',
					'instapaper' => '#1E1E1E',
					'comments' => '#6b7280',
					'share' => '#6b7280',
					'amazon' => '#FF9900',
					'aol' => '#3399FF',
					'newsvine' => '#075B8A',
					'myspace' => '#030303',
					'mailru' => '#168DE2',
					'viadeo' => '#F07355',
					'del' => '#3399FF',
					'meetedgar' => '#6b7280',
					'fintel' => '#6b7280',
					'yummly' => '#E16220',
				);
				$default_selected = array('facebook', 'twitter', 'linkedin', 'pinterest');
				foreach ($all_networks as $id => $data):
					$color = isset($network_colors[$id]) ? $network_colors[$id] : '#6b7280';
				?>
					<div class="essb-sw-network-item<?php echo in_array($id, $default_selected) ? ' essb-sw-network-selected' : ''; ?>" data-id="<?php echo esc_attr($id); ?>">
						<span class="essb-sw-network-check">&#10003;</span>
						<span class="essb-sw-network-icon" style="background:<?php echo esc_attr($color); ?>"><?php echo esc_html(substr($data['name'], 0, 1)); ?></span>
						<span class="essb-sw-network-name"><?php echo esc_html($data['name']); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="essb-sw-selected-info" id="essb-sw-selected-info"><?php esc_html_e('4 networks selected. Drag to reorder.', 'essb'); ?></div>
			<label class="essb-sw-toggle">
				<input type="checkbox" id="essb-sw-only-selected">
				<span class="essb-sw-toggle-track"></span>
				<span class="essb-sw-toggle-content">
					<span class="essb-sw-toggle-label"><?php esc_html_e('I will use only selected networks on the site', 'essb'); ?></span>
					<span class="essb-sw-toggle-desc"><?php esc_html_e('Unselected networks will not appear anywhere on your site', 'essb'); ?></span>
				</span>
			</label>
		</div>

		<!-- Step 2: Network Device Visibility -->
		<div class="essb-sw-pane" data-pane="2">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Network Device Visibility', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Show or hide each network depending on the device your visitors use. This step always works - turn it on, set a visibility for your selected networks, or apply our recommendations.', 'essb'); ?></p>
			<label class="essb-sw-toggle essb-sw-toggle-large" id="essb-sw-visibility-toggle-wrap">
				<input type="checkbox" id="essb-sw-visibility-enable" <?php checked(essb_option_bool_value('activate_networks_responsive'), true); ?>>
				<span class="essb-sw-toggle-track"></span>
				<span class="essb-sw-toggle-content">
					<span class="essb-sw-toggle-label"><?php esc_html_e('Enable device visibility', 'essb'); ?></span>
					<span class="essb-sw-toggle-desc"><?php esc_html_e('When enabled, each network below is shown or hidden per device. Turn it off to show every network on every device.', 'essb'); ?></span>
				</span>
			</label>
			<div id="essb-sw-visibility-options" style="display:none;margin-top:14px">
				<div class="essb-sw-note essb-sw-note-fb"><strong><?php esc_html_e('Tip:', 'essb'); ?></strong> <?php esc_html_e('Chat networks such as WhatsApp, Telegram, Messenger and Viber work best on mobile. Use "Apply recommendations" to set sensible defaults for the networks you selected.', 'essb'); ?></div>
				<div class="essb-sw-visibility-toolbar">
					<button type="button" class="essb-sw-btn essb-sw-btn-primary essb-sw-btn-sm" id="essb-sw-visibility-suggest"><?php esc_html_e('Apply recommendations', 'essb'); ?></button>
					<button type="button" class="essb-sw-btn essb-sw-btn-ghost essb-sw-btn-sm" id="essb-sw-visibility-reset"><?php esc_html_e('Reset', 'essb'); ?></button>
				</div>
				<div class="essb-sw-visibility-list" id="essb-sw-visibility-list">
					<?php
					if (is_array($all_networks)) {
						foreach ($all_networks as $id => $data) {
							$color = isset($network_colors[$id]) ? $network_colors[$id] : '#6b7280';
							if (essb_option_bool_value('responsive_' . $id . '_desktop')) {
								$device = 'mobile';
							} elseif (essb_option_bool_value('responsive_' . $id . '_mobile')) {
								$device = 'desktop';
							} else {
								$device = 'all';
							}
							?>
							<div class="essb-sw-visibility-row" data-network="<?php echo esc_attr($id); ?>" data-device="<?php echo esc_attr($device); ?>" style="display:none">
								<span class="essb-sw-visibility-network">
									<span class="essb-sw-network-icon" style="background:<?php echo esc_attr($color); ?>"><?php echo esc_html(substr($data['name'], 0, 1)); ?></span>
									<span class="essb-sw-visibility-name"><?php echo esc_html($data['name']); ?></span>
								</span>
								<span class="essb-sw-segmented" role="group">
									<button type="button" class="essb-sw-seg" data-device="all"><?php esc_html_e('All devices', 'essb'); ?></button>
									<button type="button" class="essb-sw-seg" data-device="desktop"><?php esc_html_e('Desktop only', 'essb'); ?></button>
									<button type="button" class="essb-sw-seg" data-device="mobile"><?php esc_html_e('Mobile only', 'essb'); ?></button>
								</span>
							</div>
							<?php
						}
					}
					?>
				</div>
				<div class="essb-sw-visibility-empty" id="essb-sw-visibility-empty" style="display:none"><?php esc_html_e('Select at least one network in the previous step to set its device visibility.', 'essb'); ?></div>
			</div>
		</div>

		<!-- Step 3: Button Style & Appearance -->
		<div class="essb-sw-pane" data-pane="3">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Button Style & Appearance', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Choose a button template and display mode.', 'essb'); ?></p>
			<div class="essb-sw-section-title"><?php esc_html_e('Button Template', 'essb'); ?></div>
			<div class="essb-sw-list">
				<?php
				$templates = array(
					'59' => array('Glow', 'Glow - Rounded buttons with a soft glow effect'),
					'6'  => array('Metro', 'Metro - Modern flat design with vibrant colors'),
					'7'  => array('Big', 'Big - Large buttons for maximum visibility'),
					'8'  => array('Light', 'Light - Minimal buttons with light backgrounds'),
					'14' => array('Blocks', 'Blocks - Outline flat design style buttons'),
					'13' => array('Circles', 'Circles - Rounded ouline style buttons'),
					'15' => array('Dark', 'Dark - Dark theme optimized buttons'),
				);
				$first = true;
				foreach ($templates as $val => $data):
				?>
					<div class="essb-sw-list-item<?php echo $first ? ' essb-sw-list-selected' : ''; ?>">
						<input type="radio" name="essb-sw-template" value="<?php echo esc_attr($val); ?>" <?php echo $first ? 'checked' : ''; ?>>
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php echo esc_html($data[1]); ?></span>
							<span class="essb-sw-list-item-desc" style="display: none;"><?php echo esc_html($data[1]); ?></span>
						</div>
					</div>
				<?php $first = false;
				endforeach; ?>
			</div>
			<p class="essb-sw-section-desc"><?php esc_html_e('More templates are available in the full settings page after setup.', 'essb'); ?></p>
			<div class="essb-sw-section-title"><?php esc_html_e('Button Display Mode', 'essb'); ?></div>
			<div class="essb-sw-list">
				<?php
				$modes = array(
					'' => array('Icon + Name', 'Show network icon and name on buttons'),
					'icon' => array('Icon Only', 'Show network icon only — compact buttons'),
					'icon_hover' => array('Icon + Name on Hover', 'Show icon by default, name appears on hover'),
					'name' => array('Name Only', 'Show network name only without icons'),
				);
				$first2 = true;
				foreach ($modes as $val => $data):
				?>
					<div class="essb-sw-list-item<?php echo $first2 ? ' essb-sw-list-selected' : ''; ?>">
						<input type="radio" name="essb-sw-display-mode" value="<?php echo esc_attr($val); ?>" <?php echo $first2 ? 'checked' : ''; ?>>
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php echo esc_html($data[0]); ?></span>
							<span class="essb-sw-list-item-desc"><?php echo esc_html($data[1]); ?></span>
						</div>
					</div>
				<?php $first2 = false;
				endforeach; ?>
			</div>
		</div>

		<!-- Step 4: Size & Layout -->
		<div class="essb-sw-pane" data-pane="4">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Size & Layout', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Set the size and alignment of your share buttons.', 'essb'); ?></p>
			<div class="essb-sw-section-title"><?php esc_html_e('Desktop Size', 'essb'); ?></div>
			<div class="essb-sw-list essb-sw-list-horizontal" id="essb-sw-size-desktop-list">
				<?php
				$sizes = array('' => 'Default', 'xs' => 'XS', 's' => 'S', 'm' => 'M', 'l' => 'L', 'xl' => 'XL', 'xxl' => '2XL');
				$size_first = true;
				foreach ($sizes as $val => $label):
				?>
					<div class="essb-sw-list-item<?php echo $size_first ? ' essb-sw-list-selected' : ''; ?>" data-value="<?php echo esc_attr($val); ?>">
						<input type="radio" name="essb-sw-size-desktop" value="<?php echo esc_attr($val); ?>" <?php echo $size_first ? ' checked' : ''; ?>>
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php echo esc_html($label); ?></span>
						</div>
					</div>
				<?php $size_first = false;
				endforeach; ?>
			</div>
			<div class="essb-sw-section-title" style="margin-top:14px"><?php esc_html_e('Mobile Size', 'essb'); ?></div>
			<div class="essb-sw-list essb-sw-list-horizontal" id="essb-sw-size-mobile-list">
				<?php
				$size_first = true;
				foreach ($sizes as $val => $label):
				?>
					<div class="essb-sw-list-item<?php echo $size_first ? ' essb-sw-list-selected' : ''; ?>" data-value="<?php echo esc_attr($val); ?>">
						<input type="radio" name="essb-sw-size-mobile" value="<?php echo esc_attr($val); ?>" <?php echo $size_first ? ' checked' : ''; ?>>
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php echo esc_html($label); ?></span>
						</div>
					</div>
				<?php $size_first = false;
				endforeach; ?>
			</div>
			<div class="essb-sw-section-title" style="margin-top:14px"><?php esc_html_e('Alignment', 'essb'); ?></div>
			<div class="essb-sw-list essb-sw-list-horizontal" id="essb-sw-alignment-list">
				<?php
				$alignments = array('' => 'Left', 'center' => 'Center', 'right' => 'Right', 'stretched' => 'Stretched');
				$align_first = true;
				foreach ($alignments as $val => $label):
				?>
					<div class="essb-sw-list-item<?php echo $align_first ? ' essb-sw-list-selected' : ''; ?>" data-value="<?php echo esc_attr($val); ?>">
						<input type="radio" name="essb-sw-alignment" value="<?php echo esc_attr($val); ?>" <?php echo $align_first ? ' checked' : ''; ?>>
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php echo esc_html($label); ?></span>
						</div>
					</div>
				<?php $align_first = false;
				endforeach; ?>
			</div>
			<label class="essb-sw-toggle" style="margin-top:16px">
				<input type="checkbox" id="essb-sw-nospace">
				<span class="essb-sw-toggle-track"></span>
				<span class="essb-sw-toggle-content">
					<span class="essb-sw-toggle-label"><?php esc_html_e('Remove spacing between buttons', 'essb'); ?></span>
					<span class="essb-sw-toggle-desc"><?php esc_html_e('Buttons will appear next to each other without gaps for a compact look', 'essb'); ?></span>
				</span>
			</label>
		</div>

		<!-- Step 5: Counter Settings -->
		<div class="essb-sw-pane" data-pane="5">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Counter Settings', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Configure how share counters are displayed on your buttons.', 'essb'); ?></p>
			<label class="essb-sw-toggle essb-sw-toggle-large" id="essb-sw-counters-toggle-wrap">
				<input type="checkbox" id="essb-sw-show-counters">
				<span class="essb-sw-toggle-track"></span>
				<span class="essb-sw-toggle-content">
					<span class="essb-sw-toggle-label"><?php esc_html_e('Show Counters', 'essb'); ?></span>
					<span class="essb-sw-toggle-desc"><?php esc_html_e('Display share counts next to each button to show social engagement', 'essb'); ?></span>
				</span>
			</label>
			<div id="essb-sw-counter-options" style="display:none;margin-top:12px">
				<div class="essb-sw-note essb-sw-note-fb"><strong><?php esc_html_e('Facebook API Notice:', 'essb'); ?></strong> <?php esc_html_e('Facebook no longer provides share counts. Internal counters are recommended as a privacy-safe alternative.', 'essb'); ?></div>
				<label class="essb-sw-toggle">
					<input type="checkbox" id="essb-sw-internal-counters" checked>
					<span class="essb-sw-toggle-track"></span>
					<span class="essb-sw-toggle-content">
						<span class="essb-sw-toggle-label"><?php esc_html_e('Use internal counters (recommended)', 'essb'); ?></span>
						<span class="essb-sw-toggle-desc"><?php esc_html_e('Count shares using the plugin\'s own database tracking - no external API required', 'essb'); ?></span>
					</span>
				</label>
				<div class="essb-sw-section-title"><?php esc_html_e('Counter Position on Each Button', 'essb'); ?></div>
				<div class="essb-sw-list">
					<?php
					$counter_positions = array(
						'hidden' => array('Hidden', 'Hide individual button counters'),
						'inside' => array('Inside', 'Show counter inside the button'),
						'insidem' => array('Inside Mini', 'Show counter inside — compact mode'),
						'insidename' => array('Inside After Name', 'Show counter after network name'),
						'insidenamem' => array('Inside After Name Mini', 'Show counter after name — compact'),
						'topm' => array('Top Mini', 'Counter appears above the button — mini style'),
					);
					$first3 = true;
					foreach ($counter_positions as $val => $data):
					?>
						<div class="essb-sw-list-item<?php echo $first3 ? ' essb-sw-list-selected' : ''; ?>">
							<input type="radio" name="essb-sw-counter-pos" value="<?php echo esc_attr($val); ?>" <?php echo $first3 ? 'checked' : ''; ?>>
							<div class="essb-sw-list-item-content">
								<span class="essb-sw-list-item-title"><?php echo esc_html($data[0]); ?></span>
								<span class="essb-sw-list-item-desc"><?php echo esc_html($data[1]); ?></span>
							</div>
						</div>
					<?php $first3 = false;
					endforeach; ?>
				</div>
				<div class="essb-sw-section-title"><?php esc_html_e('Total Counter Position', 'essb'); ?></div>
				<div class="essb-sw-list">
					<?php
					$total_counter_positions = array(
						'' => array('Hide total counter', 'Do not display a total share counter'),
						'leftbig' => array('Left Big Number', 'Large total counter on the left side'),
						'rightbig' => array('Right Big Number', 'Large total counter on the right side'),
						'leftbigicon' => array('Left Big Number with Icon', 'Total counter with shares icon on the left'),
						'rightbigicon' => array('Right Big Number with Icon', 'Total counter with shares icon on the right'),
					);
					$first4 = true;
					foreach ($total_counter_positions as $val => $data):
					?>
						<div class="essb-sw-list-item<?php echo $first4 ? ' essb-sw-list-selected' : ''; ?>">
							<input type="radio" name="essb-sw-total-counter-pos" value="<?php echo esc_attr($val); ?>" <?php echo $first4 ? 'checked' : ''; ?>>
							<div class="essb-sw-list-item-content">
								<span class="essb-sw-list-item-title"><?php echo esc_html($data[0]); ?></span>
								<span class="essb-sw-list-item-desc"><?php echo esc_html($data[1]); ?></span>
							</div>
						</div>
					<?php $first4 = false;
					endforeach; ?>
				</div>
			</div>
		</div>

		<!-- Step 6: Where to Display -->
		<div class="essb-sw-pane" data-pane="6">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Where to Display', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Choose which post types and positions to show share buttons on.', 'essb'); ?></p>
			<div class="essb-sw-section-title"><?php esc_html_e('Post Types', 'essb'); ?></div>
			<div class="essb-sw-type-grid" id="essb-sw-type-grid">
				<?php
				$pts = get_post_types(array('show_ui' => true), 'objects');
				foreach ($pts as $pt):
					if ($pt->name === 'homepage' || $pt->name === 'all_lists' || $pt->name === 'attachment') continue;
				?>
					<div class="essb-sw-type-item<?php echo $pt->name === 'post' ? ' essb-sw-type-selected' : ''; ?>" data-id="<?php echo esc_attr($pt->name); ?>"><?php echo esc_html($pt->label); ?></div>
				<?php endforeach; ?>
			</div>
			<div class="essb-sw-section-title"><?php esc_html_e('Display Positions', 'essb'); ?></div>
			<?php
			$positions = array(
				'top' => array('Content Top', 'Show buttons at the top of your content', true, 'any'),
				'bottom' => array('Content Bottom', 'Show buttons at the bottom of your content', true, 'any'),
				'sidebar' => array('Sidebar', 'Floating sidebar with vertical buttons', false, 'any'),
				//'sharebutton' => array('Share Button', 'Floating share button on the side of the screen', false, 'any'),
				'sharebottom' => array('Mobile Share Bar', 'Fixed bottom bar - appears on mobile devices', false, 'mobile'),
			);
			foreach ($positions as $id => $data):
			?>
				<div class="essb-sw-pos-row" data-pos="<?php echo esc_attr($id); ?>">
					<label class="essb-sw-pos-toggle">
						<input type="checkbox" class="essb-sw-pos-check" <?php echo $data[2] ? 'checked' : ''; ?>>
						<span class="essb-sw-pos-toggle-slider"></span>
					</label>
					<div class="essb-sw-pos-info">
						<span class="essb-sw-pos-name"><?php echo esc_html($data[0]); ?> <?php if ($data[3] === 'mobile'): ?><span class="essb-sw-badge-mobile"><?php esc_html_e('MOBILE ONLY', 'essb'); ?></span><?php endif; ?></span>
						<span class="essb-sw-pos-desc"><?php echo esc_html($data[1]); ?></span>
					</div>
					<?php if ($data[3] !== 'mobile'): ?>
						<div class="essb-sw-device-chips">
							<span class="essb-sw-device-chip<?php echo $data[3] === 'any' ? ' essb-sw-device-chip-active' : ''; ?>" data-device="any"><?php esc_html_e('Any device', 'essb'); ?></span>
							<span class="essb-sw-device-chip" data-device="desktop"><?php esc_html_e('Desktop', 'essb'); ?></span>
							<span class="essb-sw-device-chip" data-device="mobile"><?php esc_html_e('Mobile', 'essb'); ?></span>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>

		<!-- Step 7: Pinterest Image Pins -->
		<div class="essb-sw-pane" data-pane="7">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Pinterest Image Pins', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Add hover-activated Pin It buttons over your images.', 'essb'); ?></p>
			<label class="essb-sw-toggle essb-sw-toggle-large" id="essb-sw-pinterest-toggle-wrap">
				<input type="checkbox" id="essb-sw-pinterest-enable">
				<span class="essb-sw-toggle-track"></span>
				<span class="essb-sw-toggle-content">
					<span class="essb-sw-toggle-label"><?php esc_html_e('Show Pinterest Pin button over images', 'essb'); ?></span>
					<span class="essb-sw-toggle-desc"><?php esc_html_e('Adds a Pin It button when users hover over images on your site', 'essb'); ?></span>
				</span>
			</label>
			<div id="essb-sw-pinterest-options" style="display:none;margin-top:12px">
				<div class="essb-sw-section-title"><?php esc_html_e('Button Position on Image', 'essb'); ?></div>
				<div class="essb-sw-position-grid" id="essb-sw-pinterest-position-grid">
					<?php
					$pin_positions = array(
						'top-left' => array('Top Left', '&#8598;'),
						'top-right' => array('Top Right', '&#8599;'),
						'center' => array('Center', '&#8596;'),
						'bottom-left' => array('Bottom Left', '&#8601;'),
						'bottom-right' => array('Bottom Right', '&#8600;'),
					);
					$first5 = true;
					foreach ($pin_positions as $val => $data):
					?>
						<div class="essb-sw-position-item<?php echo $first5 ? ' essb-sw-position-selected' : ''; ?>" data-value="<?php echo esc_attr($val); ?>">
							<span style="font-size:24px;line-height:1"><?php echo $data[1]; ?></span>
							<span style="font-size:11px;font-weight:600;margin-top:4px"><?php echo esc_html($data[0]); ?></span>
						</div>
					<?php $first5 = false;
					endforeach; ?>
				</div>
				<div class="essb-sw-section-title"><?php esc_html_e('Visibility Mode', 'essb'); ?></div>
				<div class="essb-sw-list">
					<div class="essb-sw-list-item essb-sw-list-selected">
						<input type="radio" name="essb-sw-pin-visibility" value="" checked>
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php esc_html_e('Show on hover', 'essb'); ?></span>
							<span class="essb-sw-list-item-desc"><?php esc_html_e('Pin button appears when hovering over the image', 'essb'); ?></span>
						</div>
					</div>
					<div class="essb-sw-list-item">
						<input type="radio" name="essb-sw-pin-visibility" value="always">
						<div class="essb-sw-list-item-content">
							<span class="essb-sw-list-item-title"><?php esc_html_e('Always visible', 'essb'); ?></span>
							<span class="essb-sw-list-item-desc"><?php esc_html_e('Pin button is always shown on images', 'essb'); ?></span>
						</div>
					</div>
				</div>
				<div class="essb-sw-section-title"><?php esc_html_e('Advanced', 'essb'); ?></div>
				<div class="essb-sw-advanced-options">
					<div class="essb-sw-advanced-row">
						<label class="essb-sw-toggle">
							<input type="checkbox" id="essb-sw-pin-nolinks">
							<span class="essb-sw-toggle-track"></span>
							<span class="essb-sw-toggle-content">
								<span class="essb-sw-toggle-label"><?php esc_html_e("Don't show on linked images", 'essb'); ?></span>
								<span class="essb-sw-toggle-desc"><?php esc_html_e('Skip images that are already wrapped in a link', 'essb'); ?></span>
							</span>
						</label>
					</div>
					<div class="essb-sw-advanced-row">
						<label class="essb-sw-toggle">
							<input type="checkbox" id="essb-sw-pin-lazyload">
							<span class="essb-sw-toggle-track"></span>
							<span class="essb-sw-toggle-content">
								<span class="essb-sw-toggle-label"><?php esc_html_e('Images use lazy loading', 'essb'); ?></span>
								<span class="essb-sw-toggle-desc"><?php esc_html_e('Delay the Pin It button for lazy-loaded images to ensure proper positioning', 'essb'); ?></span>
							</span>
						</label>
					</div>
				</div>
			</div>
		</div>

		<!-- Step 8: Review & Apply -->
		<div class="essb-sw-pane" data-pane="8">
			<h3 class="essb-sw-pane-title"><?php esc_html_e('Review & Apply', 'essb'); ?></h3>
			<p class="essb-sw-pane-desc"><?php esc_html_e('Review your configuration before applying.', 'essb'); ?></p>
			<div class="essb-sw-summary" id="essb-sw-summary">
				<div class="essb-sw-summary-item">
					<div class="essb-sw-summary-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Networks', 'essb'); ?></strong>
						<p id="essb-sw-summary-networks"><?php esc_html_e('4 networks selected', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-sw-summary-item">
					<div class="essb-sw-summary-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Button Style', 'essb'); ?></strong>
						<p id="essb-sw-summary-style"><?php esc_html_e('Glow template, Icon + Name', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-sw-summary-item">
					<div class="essb-sw-summary-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Size & Layout', 'essb'); ?></strong>
						<p id="essb-sw-summary-size"><?php esc_html_e('Default sizes, Left aligned', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-sw-summary-item">
					<div class="essb-sw-summary-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Counters', 'essb'); ?></strong>
						<p id="essb-sw-summary-counters"><?php esc_html_e('Disabled', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-sw-summary-item">
					<div class="essb-sw-summary-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Display Positions', 'essb'); ?></strong>
						<p id="essb-sw-summary-positions"><?php esc_html_e('Content Top, Content Bottom', 'essb'); ?></p>
					</div>
				</div>
				<div class="essb-sw-summary-item">
					<div class="essb-sw-summary-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none">
							<path d="M13.3 4.3a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4 0l-3-3a1 1 0 0 1 1.4-1.4L5.6 11l6.3-6.3a1 1 0 0 1 1.4 0z" fill="currentColor" />
						</svg></div>
					<div><strong><?php esc_html_e('Pinterest Image Pins', 'essb'); ?></strong>
						<p id="essb-sw-summary-pinterest"><?php esc_html_e('Disabled', 'essb'); ?></p>
					</div>
				</div>
			</div>
			<div class="essb-sw-apply-wrap">
				<button type="button" class="essb-sw-btn essb-sw-btn-primary" id="essb-sw-apply"><?php esc_html_e('Apply Configuration', 'essb'); ?></button>
			</div>
		</div>

	</div>
	<div class="essb-sw-footer">
		<button type="button" class="essb-sw-btn essb-sw-btn-ghost" id="essb-sw-prev" disabled>&larr; <?php esc_html_e('Previous', 'essb'); ?></button>
		<span class="essb-sw-footmeta" id="essb-sw-footmeta"><?php esc_html_e('Step 1 of 7', 'essb'); ?></span>
		<button type="button" class="essb-sw-btn essb-sw-btn-primary" id="essb-sw-next"><?php esc_html_e('Next', 'essb'); ?> &rarr;</button>
	</div>
</div>

<!-- ===== Initial Config Wizard ===== -->
<div class="essb-iw-overlay" id="essb-iw-overlay"></div>

<div class="essb-iw-wrap" id="essb-iw-wizard" style="display:none" data-install-nonce="<?php echo esc_attr(wp_create_nonce('essb_install_free_addon')); ?>">

	<div class="essb-iw-header">
		<div class="essb-iw-header-title">
			<span class="essb-iw-logo">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><line x1="8.6" y1="10.6" x2="15.4" y2="6.4" /><line x1="8.6" y1="13.4" x2="15.4" y2="17.6" /></svg>
			</span>
			<?php esc_html_e('Getting Started', 'essb'); ?>
		</div>
		<button type="button" class="essb-iw-close" id="essb-iw-close" title="<?php esc_attr_e('Close', 'essb'); ?>">
			<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
			<?php esc_html_e('Exit', 'essb'); ?>
		</button>
	</div>

	<div class="essb-iw-progress">
		<div class="essb-iw-progress-top">
			<span class="essb-iw-phase" id="essb-iw-phase">Setup</span>
			<span class="essb-iw-stepmeta" id="stepLabel">Welcome</span>
		</div>
		<div class="essb-iw-track"><div class="essb-iw-fill" id="essb-iw-fill"></div></div>
	</div>

	<div class="essb-iw-body">

		<!-- ===== Welcome ===== -->
		<div class="essb-iw-pane essb-iw-pane-active" data-pane="welcome" data-phase="Setup" data-name="Welcome">
			<div class="essb-iw-welcome">
				<div class="essb-iw-welcome-badge">
					<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><line x1="8.6" y1="10.6" x2="15.4" y2="6.4" /><line x1="8.6" y1="13.4" x2="15.4" y2="17.6" /></svg>
				</div>
				<h2><?php esc_html_e('Let\'s set up Easy Social Share Buttons', 'essb'); ?></h2>
				<p><?php esc_html_e('A few quick questions so the plugin fits how you work. Anything you don\'t need is switched off automatically - keeping the plugin lightweight and focused.', 'essb'); ?></p>
				<p class="essb-iw-welcome-note"><?php esc_html_e('Takes about 2 minutes - You can change everything later', 'essb'); ?></p>
			</div>
			<div class="essb-iw-overview">
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">1</span><span class="essb-iw-overview-name"><?php esc_html_e('Button mode', 'essb'); ?></span><span class="essb-iw-overview-tag">Setup</span></div>
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">2</span><span class="essb-iw-overview-name"><?php esc_html_e('Social media optimization tags', 'essb'); ?></span><span class="essb-iw-overview-tag">Setup</span></div>
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">3</span><span class="essb-iw-overview-name"><?php esc_html_e('Share counters', 'essb'); ?></span><span class="essb-iw-overview-tag">Setup</span></div>
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">4</span><span class="essb-iw-overview-name"><?php esc_html_e('Internal analytics', 'essb'); ?></span><span class="essb-iw-overview-tag">Setup</span></div>
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">5</span><span class="essb-iw-overview-name"><?php esc_html_e('Pinterest Pro, Link in Bio, quotes, highlight share & short URLs', 'essb'); ?></span><span class="essb-iw-overview-tag">Social</span></div>
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">6</span><span class="essb-iw-overview-name"><?php esc_html_e('Profiles, subscribe forms, Social Chat', 'essb'); ?></span><span class="essb-iw-overview-tag">Extras</span></div>
				<div class="essb-iw-overview-row"><span class="essb-iw-overview-num">7</span><span class="essb-iw-overview-name"><?php esc_html_e('Additional features', 'essb'); ?></span><span class="essb-iw-overview-tag">Finish</span></div>
			</div>
		</div>

		<!-- ===== Step 1: CSS Mode ===== -->
		<div class="essb-iw-pane" data-pane="1" data-phase="Setup" data-name="<?php esc_attr_e('Button mode', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Choose your share buttons mode', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('The mode controls which button styles, templates, and features are available. You can change this anytime from the Advanced Settings.', 'essb'); ?></p>
			<div class="essb-iw-note info"><div><?php esc_html_e('Full - all features, templates, and maximum flexibility. Light - essential features with the smallest footprint. Slim and Mini offer a middle ground.', 'essb'); ?></div></div>
			<div class="essb-iw-mode-grid" id="modeGrid">
				<div class="essb-iw-mode-card essb-iw-mode-selected" data-mode=""><div class="essb-iw-mode-name"><?php esc_html_e('Full', 'essb'); ?></div><div class="essb-iw-mode-desc"><?php esc_html_e('Maximum flexibility, custom designs, all platforms', 'essb'); ?></div></div>
				<div class="essb-iw-mode-card" data-mode="slim"><div class="essb-iw-mode-name"><?php esc_html_e('Slim', 'essb'); ?></div><div class="essb-iw-mode-desc"><?php esc_html_e('Clean UI, performance-focused, standard layouts', 'essb'); ?></div></div>
				<div class="essb-iw-mode-card" data-mode="mini"><div class="essb-iw-mode-name"><?php esc_html_e('Mini', 'essb'); ?></div><div class="essb-iw-mode-desc"><?php esc_html_e('Core networks only, speed-critical sites', 'essb'); ?></div></div>
				<div class="essb-iw-mode-card" data-mode="light"><div class="essb-iw-mode-name"><?php esc_html_e('Light', 'essb'); ?></div><div class="essb-iw-mode-desc"><?php esc_html_e('Ultra-lightweight, maximum performance', 'essb'); ?></div></div>
			</div>
			<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><?php esc_html_e('Learn more about each mode in the', 'essb'); ?> <a href="https://docs.socialsharingplugin.com/knowledgebase/how-to-choose-the-right-css-js-mode-for-your-share-buttons/" target="_blank"><?php esc_html_e('documentation', 'essb'); ?> &rarr;</a></span></div>
		</div>

		<!-- ===== Step 2: Social Optimization ===== -->
		<div class="essb-iw-pane" data-pane="2" data-phase="Setup" data-name="<?php esc_attr_e('Social optimization tags', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Social media optimization tags', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Control how your content looks when shared on Facebook, X (Twitter), LinkedIn, and other social networks.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableSSO" data-target="#ssoOptions" checked><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Add Open Graph meta tags to your site', 'essb'); ?></strong><span><?php esc_html_e('Social networks use these tags to show the right title, description, and image instead of picking random content.', 'essb'); ?></span></span></label>
			<div class="essb-iw-sub" id="ssoOptions">
				<div class="essb-iw-card">
					<label class="essb-iw-label"><?php esc_html_e('Default social image (optional)', 'essb'); ?></label>
					<div class="essb-iw-label-desc"><?php esc_html_e('Used when a post or page doesn\'t have its own featured image.', 'essb'); ?></div>
					<div class="essb-iw-field"><input type="text" class="essb-iw-input" id="ssoDefaultImage" placeholder="<?php esc_attr_e('Enter image URL or click to select', 'essb'); ?>" readonly><button type="button" class="essb-iw-btn essb-iw-btn-ghost essb-iw-btn-sm" id="ssoSelectImage"><?php esc_html_e('Select', 'essb'); ?></button></div>
					<div id="ssoImagePreview" style="display:none;margin-top:8px;">
						<div style="display:flex;align-items:center;gap:10px;">
							<img src="" alt="" id="ssoPreviewImg" style="max-width:160px;border-radius:6px;border:1px solid #e2e8f5;">
							<button type="button" class="essb-iw-btn essb-iw-btn-ghost essb-iw-btn-sm" id="ssoRemoveImage"><?php esc_html_e('Remove', 'essb'); ?></button>
						</div>
					</div>
				</div>
				<div class="essb-iw-note info" style="margin-top:12px;"><div><?php esc_html_e('If you use an SEO plugin (Yoast, Rank Math, etc.), it already handles most meta tags - the plugin extends them with social-specific ones (e.g. WooCommerce product tags).', 'essb'); ?></div></div>
				<div class="essb-iw-addon-row" style="margin-top:12px;">
					<div class="essb-iw-addon-txt"><strong><?php esc_html_e('AI Social Booster', 'essb'); ?></strong><span><?php esc_html_e('Generate scroll-stopping social titles, tweets, and share messages from your content using AI.', 'essb'); ?></span><a href="https://socialsharingplugin.com/addons/ai-social-booster/" target="_blank" class="essb-iw-learn"><?php esc_html_e('Learn more', 'essb'); ?> &rarr;</a></div>
					<?php $aisb_state = essb_addon_get_state('ai-social-booster'); ?>
					<?php if ($aisb_state === 'active'): ?>
						<span class="essb-iw-badge essb-iw-badge-active"><span class="essb-iw-badge-dot"></span><?php esc_html_e('Active', 'essb'); ?></span>
					<?php elseif ($aisb_state === 'installed'): ?>
						<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="ai-social-booster"><?php esc_html_e('Activate', 'essb'); ?></button>
					<?php else: ?>
						<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="ai-social-booster"><?php esc_html_e('Install', 'essb'); ?></button>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<!-- ===== Step 3: Share Counters ===== -->
		<div class="essb-iw-pane" data-pane="3" data-phase="Setup" data-name="<?php esc_attr_e('Share counters', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Share counters', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Display how many times each article has been shared. Social proof encourages more visitors to share your content.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableCounters" data-target="#countersOptions" checked><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('I will display share counters on my website', 'essb'); ?></strong><span><?php esc_html_e('Displays the number of shares next to each button, plus an optional total across all networks.', 'essb'); ?></span></span></label>
			<div class="essb-iw-sub" id="countersOptions">
				<div class="essb-iw-note"><div><?php esc_html_e('Note: Facebook requires an access token to show share counts, otherwise it shows zero. Internal share counters solve this by counting clicks on your site instead of external APIs.', 'essb'); ?></div></div>
				<label class="essb-iw-toggle"><input type="checkbox" id="enableInternalCounters" checked><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Internal share counters', 'essb'); ?></strong><span><?php esc_html_e('Counts every click on your share buttons and stores it in your database. Works for all networks - no API keys needed.', 'essb'); ?></span></span></label>
				<label class="essb-iw-toggle"><input type="checkbox" id="enableAvoidNegative" checked><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Avoid negative social proof', 'essb'); ?></strong><span><?php esc_html_e('Hides counters until they reach a minimum (default 10), so you never show "0 shares".', 'essb'); ?></span></span></label>
			</div>
		</div>

		<!-- ===== Step 4: Analytics ===== -->
		<div class="essb-iw-pane" data-pane="4" data-phase="Setup" data-name="<?php esc_attr_e('Internal analytics', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Internal analytics', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Track how your share buttons perform - which networks get the most clicks and which content resonates.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableAnalytics"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Analytics dashboard for share buttons', 'essb'); ?></strong><span><?php esc_html_e('Records every click and shows reports in your WordPress dashboard. Privacy-safe - no external services.', 'essb'); ?></span></span></label>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></svg></span><div><strong><?php esc_html_e('See which networks perform best', 'essb'); ?></strong><span><?php esc_html_e('Identify which social networks drive the most shares and focus your strategy.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" /></svg></span><div><strong><?php esc_html_e('Find your top content', 'essb'); ?></strong><span><?php esc_html_e('Discover which posts and pages get shared the most, and create more of what works.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg></span><div><strong><?php esc_html_e('Privacy safe, no setup required', 'essb'); ?></strong><span><?php esc_html_e('All data stays on your server. No external calls, no GDPR headaches. Works immediately.', 'essb'); ?></span></div></div>
			</div>
			<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><a href="https://socialsharingplugin.com/social-sharing/advanced-privacy-safe-analytics-for-wordpress-share-buttons/" target="_blank"><?php esc_html_e('Learn more about analytics', 'essb'); ?> &rarr;</a></span></div>
		</div>

		<!-- ===== Step 5: Pinterest Pro ===== -->
		<div class="essb-iw-pane" data-pane="5" data-phase="Social" data-name="<?php esc_attr_e('Pinterest Pro', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Pinterest Pro', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Pinterest is a powerful visual discovery engine. If it\'s a key platform for your audience, the Pro features give you more ways to engage pinners.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enablePinterestPro" data-target="#pinproOptions" checked><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Pinterest Pro Image Share Button', 'essb'); ?></strong><span><?php esc_html_e('Adds a Pin-it button over your images so visitors can save them to Pinterest, plus Pinterest Follow Box and Follow Bar widgets.', 'essb'); ?></span></span></label>
			<div class="essb-iw-sub" id="pinproOptions">
				<div class="essb-iw-card">
					<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2a10 10 0 0 0-3.9 19.2c-.1-.8-.2-2 0-2.9l1.2-5" /><path d="M9.3 9.6c0-2.3 1.7-4.1 4.1-4.1 2.4 0 3.9 1.5 3.9 3.7 0 2.6-1.5 4.6-3.5 4.6-1.1 0-1.9-.9-1.6-2" /></svg></span><div><strong><?php esc_html_e('Pin button over images', 'essb'); ?></strong><span><?php esc_html_e('A Pin-it button appears on image hover so visitors can save your content to their boards.', 'essb'); ?></span></div></div>
					<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="4" rx="1" /><rect x="3" y="10" width="18" height="4" rx="1" /><rect x="3" y="16" width="18" height="4" rx="1" /></svg></span><div><strong><?php esc_html_e('Pinterest Follow widgets', 'essb'); ?></strong><span><?php esc_html_e('Display a Follow Box or Follow Bar so visitors can follow your profile directly.', 'essb'); ?></span></div></div>
				</div>
				<label class="essb-iw-toggle" style="margin-top:12px;"><input type="checkbox" id="enablePinterestOptimize"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Optimize the initial image detection scan', 'essb'); ?></strong><span><?php esc_html_e('Delays the initial image scan until the visitor interacts with the page (touch, move, scroll, type) for better performance.', 'essb'); ?></span></span></label>
				<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><a href="https://socialsharingplugin.com/pinterest-pro-image-hover-pins/" target="_blank"><?php esc_html_e('Learn more about Pinterest Pro', 'essb'); ?> &rarr;</a></span></div>
			</div>

			<?php if (class_exists('WooCommerce')): ?>
			<div id="wooSuggestion" style="margin-top:16px;">
				<span class="essb-iw-suggest-label"><?php esc_html_e('Suggested - WooCommerce detected', 'essb'); ?></span>
				<label class="essb-iw-toggle"><input type="checkbox" id="enablePinterestWoo" data-target="#pinwcOptions"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('WooCommerce product images Pin button', 'essb'); ?></strong><span><?php esc_html_e('Adds a Pin button over product gallery images. Runs on its own - you don\'t need the Pinterest Pro image share button enabled.', 'essb'); ?></span></span></label>
				<div class="essb-iw-sub" id="pinwcOptions">
					<div class="essb-iw-note info"><div><?php esc_html_e('Position, visibility, template, button style, shape, shadow and size of the WooCommerce Pin button are configured in Pinterest Pro WooCommerce.', 'essb'); ?></div></div>
				</div>
			</div>
			<?php endif; ?>
		</div>

		<!-- ===== Step 6: Link In Bio page builder ===== -->
		<div class="essb-iw-pane" data-pane="6" data-phase="Social" data-name="<?php esc_attr_e('Link In Bio page builder', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Link In Bio page builder', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Social Profile Card Studio turns your bio link into a branded page - and works as a card anywhere on your site. 72 presets, a smart style generator and scheduled blocks and more.', 'essb'); ?></p>
			<div class="essb-iw-addon-card">
				<span class="essb-iw-addon-tile violet"><svg width="22" height="22" viewBox="0 0 256 256" fill="#fff"><path fill-rule="evenodd" d="M68,20h120c28,0,48,20,48,48v120c0,28-20,48-48,48H68c-28,0-48-20-48-48V68c0-28,20-48,48-48z M128,58c-21,0-38,17-38,38s17,38,38,38s38-17,38-38S149,58,128,58z M128,140c-40,0-73,32-73,72v10h146v-10C201,172,168,140,128,140z" /></svg></span>
				<div class="essb-iw-addon-info">
					<strong><?php esc_html_e('Link In Bio page builder', 'essb'); ?></strong>
					<span><?php esc_html_e('Free standalone plugin - works on its own or alongside Easy Social Share Buttons. Fully functional on unlimited sites.', 'essb'); ?></span>
					<a href="https://socialsharingplugin.com/social-profile-card-studio/" target="_blank" class="essb-iw-learn"><?php esc_html_e('Learn more', 'essb'); ?> &rarr;</a>
				</div>
				<?php $lbi_state = essb_addon_get_state('social-profile-card-studio'); ?>
				<?php if ($lbi_state === 'active'): ?>
					<span class="essb-iw-badge essb-iw-badge-active"><span class="essb-iw-badge-dot"></span><?php esc_html_e('Active', 'essb'); ?></span>
				<?php elseif ($lbi_state === 'installed'): ?>
					<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="social-profile-card-studio"><?php esc_html_e('Activate', 'essb'); ?></button>
				<?php else: ?>
					<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="social-profile-card-studio"><?php esc_html_e('Install Free', 'essb'); ?></button>
				<?php endif; ?>
			</div>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="3" width="16" height="18" rx="3" /><circle cx="12" cy="10" r="2.4" /><path d="M7.5 17c.8-1.7 2.6-2.6 4.5-2.6s3.7.9 4.5 2.6" /></svg></span><div><strong><?php esc_html_e('Link in Bio page', 'essb'); ?></strong><span><?php esc_html_e('Give your profiles a branded home - one page with all your links, socials and contact options.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="14" rx="2" /><path d="M3 9h18" /></svg></span><div><strong><?php esc_html_e('Profile cards anywhere', 'essb'); ?></strong><span><?php esc_html_e('Publish the same card with a shortcode - in posts, pages, widgets or footers.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" /></svg></span><div><strong><?php esc_html_e('Scheduled blocks and more', 'essb'); ?></strong><span><?php esc_html_e('Schedule blocks, track card performance and export a vCard.', 'essb'); ?></span></div></div>
			</div>
		</div>

		<!-- ===== Step 7: Shareable Quotes ===== -->
		<div class="essb-iw-pane" data-pane="7" data-phase="Social" data-name="<?php esc_attr_e('Shareable Quotes', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Shareable Quotes', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Let visitors turn highlighted text into a tweet with one click. A simple way to make your content more shareable on X (Twitter).', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableQuotes"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Shareable quotes for X (Twitter)', 'essb'); ?></strong><span><?php esc_html_e('Adds a "Click to Tweet" button when visitors select text, pre-composed with the passage and a link back.', 'essb'); ?></span></span></label>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg></span><div><strong><?php esc_html_e('One-click sharing', 'essb'); ?></strong><span><?php esc_html_e('Visitors highlight any text and a tweet is pre-composed with the selected passage.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8" /></svg></span><div><strong><?php esc_html_e('Increase engagement', 'essb'); ?></strong><span><?php esc_html_e('Quote tweets get more visibility on X - easy sharing increases your content\'s reach.', 'essb'); ?></span></div></div>
			</div>
			<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><a href="https://socialsharingplugin.com/click-to-tweet/" target="_blank"><?php esc_html_e('Learn more about shareable quotes', 'essb'); ?> &rarr;</a></span></div>
		</div>

		<!-- ===== Step 8: Highlight Share ===== -->
		<div class="essb-iw-pane" data-pane="8" data-phase="Social" data-name="<?php esc_attr_e('Highlight Share', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Highlight Share', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Let visitors share any passage they highlight. A small floating bar appears over the selected text with the networks you choose - including X (Twitter), WhatsApp, Telegram and more.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableHighlightShare"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Enable highlight and share', 'essb'); ?></strong><span><?php esc_html_e('Shows a share bar over highlighted text on your posts. Works alongside Shareable Quotes or on its own.', 'essb'); ?></span></span></label>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg></span><div><strong><?php esc_html_e('Share the exact passage', 'essb'); ?></strong><span><?php esc_html_e('The selected text is included in the share, so visitors share the part that matters.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><line x1="8.6" y1="10.6" x2="15.4" y2="6.4" /><line x1="8.6" y1="13.4" x2="15.4" y2="17.6" /></svg></span><div><strong><?php esc_html_e('Multiple networks', 'essb'); ?></strong><span><?php esc_html_e('Choose the networks that appear in the bar, from social platforms to messaging apps.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg></span><div><strong><?php esc_html_e('Respects your settings', 'essb'); ?></strong><span><?php esc_html_e('Fine-tune networks, post types, template, size and mobile visibility in Social → Highlight Share.', 'essb'); ?></span></div></div>
			</div>
			<div class="essb-iw-note info" style="margin-top:12px;"><div><?php esc_html_e('Tip: X (Twitter) is enabled by default and highlight sharing runs on posts. You can add more networks, pages and other post types after setup.', 'essb'); ?></div></div>
		</div>

		<!-- ===== Step 9: Short URLs ===== -->
		<div class="essb-iw-pane" data-pane="9" data-phase="Social" data-name="<?php esc_attr_e('Short URLs', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Short URLs for sharing', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Short URLs make your shared links cleaner, trackable, and more trustworthy on social media - and save character space on platforms like X.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableShortUrls"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Short URL support for shared links', 'essb'); ?></strong><span><?php esc_html_e('Replaces long post URLs with shortened versions. Supported: bit.ly, Rebrandly, po.st, Premium URL Shortener, and self-hosted.', 'essb'); ?></span></span></label>
			<div class="essb-iw-addon-row" style="margin-top:12px;">
				<div class="essb-iw-addon-txt"><strong><?php esc_html_e('Shorty - Self-hosted Short URLs', 'essb'); ?></strong><span><?php esc_html_e('Keep your short URLs on your own domain. The free version needs no external API keys.', 'essb'); ?></span><a href="https://socialsharingplugin.com/addons/shorty-self-hosted-shorturls/" target="_blank" class="essb-iw-learn"><?php esc_html_e('Learn more', 'essb'); ?> &rarr;</a></div>
				<?php $shorty_state = essb_addon_get_state('shorty'); ?>
				<?php if ($shorty_state === 'active'): ?>
					<span class="essb-iw-badge essb-iw-badge-active"><span class="essb-iw-badge-dot"></span><?php esc_html_e('Active', 'essb'); ?></span>
				<?php elseif ($shorty_state === 'installed'): ?>
					<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="shorty"><?php esc_html_e('Activate', 'essb'); ?></button>
				<?php else: ?>
					<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="shorty"><?php esc_html_e('Install', 'essb'); ?></button>
				<?php endif; ?>
			</div>
			<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><a href="https://docs.socialsharingplugin.com/knowledgebase/setup-short-urls-for-sharing-bit-ly-rebrandly-com-po-st-premium-url-shortener-sharing-short-url/" target="_blank"><?php esc_html_e('Learn more about short URL setup', 'essb'); ?> &rarr;</a></span></div>
		</div>

		<!-- ===== Step 10: Social Profiles ===== -->
		<div class="essb-iw-pane" data-pane="10" data-phase="Social" data-name="<?php esc_attr_e('Social profile links', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Social profile links', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Display your social media profiles as a link panel on your site - a great way to grow your follower base across all your networks.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableProfiles"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Social profile link buttons', 'essb'); ?></strong><span><?php esc_html_e('Adds a configurable profile panel. Supports 60+ networks with 25+ display templates.', 'essb'); ?></span></span></label>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z" /></svg></span><div><strong><?php esc_html_e('60+ social networks supported', 'essb'); ?></strong><span><?php esc_html_e('From Facebook and X to TikTok, Telegram, and beyond - link to every platform you\'re on.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></svg></span><div><strong><?php esc_html_e('25+ display templates', 'essb'); ?></strong><span><?php esc_html_e('Icons-only, buttons with labels, grid layouts, widget styles and more.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M16 6l-4-4-4 4M12 2v13" /></svg></span><div><strong><?php esc_html_e('Add anywhere on your site', 'essb'); ?></strong><span><?php esc_html_e('Automated display locations, shortcodes, the Elementor widget, or the Block builder.', 'essb'); ?></span></div></div>
			</div>
			<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><a href="https://socialsharingplugin.com/social-profiles/" target="_blank"><?php esc_html_e('Learn more about social profiles', 'essb'); ?> &rarr;</a></span></div>
		</div>

		<!-- ===== Step 11: Subscribe Forms ===== -->
		<div class="essb-iw-pane" data-pane="11" data-phase="Extras" data-name="<?php esc_attr_e('Subscribe forms', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Subscribe forms', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('Grow your mailing list directly from your site. Choose from pop-ups, fly-ins, inline forms and more - all integrated with your email service.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableSubscribe"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Email subscribe forms', 'essb'); ?></strong><span><?php esc_html_e('Capture leads with 12 mailing services, 9 ready designs, pop-ups, fly-ins, inline forms and unlock-to-subscribe.', 'essb'); ?></span></span></label>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="4" width="20" height="16" rx="2" /><path d="m2 7 10 6 10-6" /></svg></span><div><strong><?php esc_html_e('12 mailing services & 9 ready designs', 'essb'); ?></strong><span><?php esc_html_e('Connect Mailchimp, MailerLite, ConvertKit and more, or customize your own.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2 9 9l-7 1 5 5-1 7 6-3 6 3-1-7 5-5-7-1z" /></svg></span><div><strong><?php esc_html_e('Multiple display modes', 'essb'); ?></strong><span><?php esc_html_e('Pop-ups, fly-outs, automatic below content, a subscribe button in share buttons, and unlock-to-subscribe.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M16 6l-4-4-4 4M12 2v13" /></svg></span><div><strong><?php esc_html_e('Place anywhere', 'essb'); ?></strong><span><?php esc_html_e('Widget, shortcode, Elementor, Block builder, or automatic triggers (scroll, delay, exit intent).', 'essb'); ?></span></div></div>
			</div>
			<div class="essb-iw-more"><svg width="15" height="15" viewBox="0 0 20 20" fill="#8a94b5"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg><span><a href="https://socialsharingplugin.com/grow-your-mailing-list-subscribers/" target="_blank"><?php esc_html_e('Learn more about subscribe forms', 'essb'); ?> &rarr;</a></span></div>
		</div>

		<!-- ===== Step 12: Social Chat ===== -->
		<div class="essb-iw-pane" data-pane="12" data-phase="Extras" data-name="<?php esc_attr_e('Social Chat', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Social Chat', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('An engaging way to talk with visitors in real time. Perfect for WooCommerce stores - add WhatsApp, Telegram, Viber, Signal, Line and more chat buttons. Works standalone or alongside Easy Social Share Buttons.', 'essb'); ?></p>
			<div class="essb-iw-addon-card">
				<span class="essb-iw-addon-tile"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.8-.9L3 21l1.9-5.7A8.5 8.5 0 1 1 21 11.5z" /></svg></span>
				<div class="essb-iw-addon-info">
					<strong><?php esc_html_e('Social Chat', 'essb'); ?></strong>
					<span><?php esc_html_e('Free standalone plugin - works on its own or integrated with Easy Social Share Buttons. Fully functional on unlimited sites.', 'essb'); ?></span>
					<a href="https://socialsharingplugin.com/social-chat/" target="_blank" class="essb-iw-learn"><?php esc_html_e('Learn more', 'essb'); ?> &rarr;</a>
				</div>
				<?php $schat_state = essb_addon_get_state('social-chat'); ?>
				<?php if ($schat_state === 'active'): ?>
					<span class="essb-iw-badge essb-iw-badge-active"><span class="essb-iw-badge-dot"></span><?php esc_html_e('Active', 'essb'); ?></span>
				<?php elseif ($schat_state === 'installed'): ?>
					<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="social-chat"><?php esc_html_e('Activate', 'essb'); ?></button>
				<?php else: ?>
					<button type="button" class="essb-iw-btn essb-iw-btn-primary essb-iw-btn-sm" data-install="social-chat"><?php esc_html_e('Install Free', 'essb'); ?></button>
				<?php endif; ?>
			</div>
			<div class="essb-iw-card" style="margin-top:12px;">
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg></span><div><strong><?php esc_html_e('Chat Popup - Simple, Smart, Stylish', 'essb'); ?></strong><span><?php esc_html_e('A floating button opening a popup of your team members, with Same Network and Different Networks modes.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 20a8 8 0 1 0-8-8" /><path d="M9 11l3 3 5-6" /></svg></span><div><strong><?php esc_html_e('Operator Popup - Full Chat Experience', 'essb'); ?></strong><span><?php esc_html_e('A sleek popup with welcome message, suggested replies and chat input. Pro adds greetings and pre-defined replies.', 'essb'); ?></span></div></div>
				<div class="essb-iw-feature"><span class="essb-iw-feature-ico"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.3a2 2 0 0 0 2-1.7l1.4-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" /></svg></span><div><strong><?php esc_html_e('Direct Chat Button - One Click, One Connection', 'essb'); ?></strong><span><?php esc_html_e('A single button linking directly to an operator\'s chat - headers, footers, or alongside products.', 'essb'); ?></span></div></div>
			</div>
		</div>

		<!-- ===== Step 13: Additional Features ===== -->
		<div class="essb-iw-pane" data-pane="13" data-phase="Finish" data-name="<?php esc_attr_e('Additional features', 'essb'); ?>">
			<h2 class="essb-iw-pane-title"><?php esc_html_e('Additional features', 'essb'); ?></h2>
			<p class="essb-iw-pane-desc"><?php esc_html_e('A few more powerful features to round out your setup. Enable what you need, skip what you don\'t.', 'essb'); ?></p>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableCustomButtons"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Custom network buttons', 'essb'); ?></strong><span><?php esc_html_e('Add your own custom network buttons to the share or follow lists - useful for custom URLs or apps.', 'essb'); ?></span></span></label>
			<div style="height:10px;"></div>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableCustomPositions"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Custom display positions', 'essb'); ?></strong><span><?php esc_html_e('Create a custom display position and show it anywhere via shortcode or function call.', 'essb'); ?></span></span></label>
			<div style="height:10px;"></div>
			<label class="essb-iw-toggle"><input type="checkbox" id="enableTranslate"><span class="essb-iw-switch"></span><span class="essb-iw-toggle-text"><strong><?php esc_html_e('Customize and translate plugin texts', 'essb'); ?></strong><span><?php esc_html_e('Translate or customize preset texts ("Share", "Shares", "Send via Email", ...) directly in settings.', 'essb'); ?></span></span></label>
		</div>

	</div>

	<div class="essb-iw-footer">
		<button type="button" class="essb-iw-btn essb-iw-btn-ghost" id="essb-iw-prev" disabled>&larr; <?php esc_html_e('Previous', 'essb'); ?></button>
		<span class="essb-iw-foot-mid" id="essb-iw-footmeta">Welcome</span>
		<button type="button" class="essb-iw-btn essb-iw-btn-primary" id="essb-iw-next"><?php esc_html_e('Next', 'essb'); ?> &rarr;</button>
	</div>

</div>


<script>
	<?php
	if (essb_is_envato_version()) {
	?>
		var essb_api_activate_domain = "<?php echo esc_attr(ESSB_Envato_Activation_Manager::domain()); ?>";
		var essb_api_activate_url = "<?php echo esc_url(ESSB_Envato_Activation_Manager::getSiteURL()); ?>";
		var essb_api_url = "<?php echo esc_url(ESSB_Envato_Activation_Manager::getApiUrl('api')); ?>";
		var essb_ajax_url = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";

		var essb_api_security_token = "<?php echo wp_create_nonce('essb_activate_nonce_token'); ?>";

		var essb_used_purchasecode = "<?php echo esc_url(ESSB_Envato_Activation_Manager::getPurchaseCode()); ?>";
		var essb_used_activationcode = "<?php echo esc_url(ESSB_Envato_Activation_Manager::getActivationCode()); ?>";

	<?php
	}
	?>

	jQuery(document).ready(function($) {

		// ---- Feature toggle save ----
		$('.essb-df-grid').on('change', '.essb-activate-additional-feature .essb-ui-switch-check', function() {
			var state = $(this).is(':checked'),
				field = $(this).data('field') || '',
				rootElement = $('.essb-activate-additional-feature-' + field),
				rootType = rootElement.data('type') || '',
				value = '';

			if (state) {
				rootElement.addClass('active');
				value = (rootType == 'deactivation') ? '' : 'true';
			} else {
				rootElement.removeClass('active');
				value = (rootType == 'deactivation') ? 'true' : '';
			}

			rootElement.find('.feature-value').val(value);

			var $toast = $('<div class="essb-df-toast essb-df-toast-saving"><span class="essb-df-spinner"></span> <?php echo esc_js(esc_html__('Saving', 'essb')); ?>&hellip;</div>').appendTo('body');
			setTimeout(function() {
				$toast.addClass('essb-df-toast-show');
			}, 10);

			var options = {};
			options[field] = value;

			$.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
					action: 'essb_advanced_options',
					cmd: 'save',
					group: 'essb_options',
					advanced_options: options,
					essb_advancedoptions_token: $('#essb_advancedoptions_token').val()
				},
				success: function() {
					$toast.removeClass('essb-df-toast-saving').addClass('essb-df-toast-success').html('<?php echo esc_js(esc_html__('Settings saved', 'essb')); ?>');
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 1500);
				}
			});
		});

		// ---- Wizard: state ----
		var owStep = 1;
		var owTotalSteps = 5;

		// ---- Wizard: open / close ----
		$('#essb-df-open-wizard').on('click', function(e) {
			e.preventDefault();
			$('#essb-ow-overlay').addClass('essb-ow-overlay-show');
			$('#essb-ow-wizard').addClass('essb-ow-wrap-show');
			owGoTo(1);
		});
		$('#essb-ow-close').on('click', function(e) {
			e.preventDefault();
			owClose();
		});
		$('#essb-ow-overlay').on('click', owClose);

		function owClose() {
			$('#essb-ow-overlay').removeClass('essb-ow-overlay-show');
			$('#essb-ow-wizard').removeClass('essb-ow-wrap-show');
		}

		// ---- Wizard: list selection ----
		$('.essb-ow-list-item').on('click', function() {
			$(this).closest('.essb-ow-list').find('.essb-ow-list-item').removeClass('essb-ow-list-selected');
			$(this).addClass('essb-ow-list-selected');
			$(this).find('input[type="radio"]').prop('checked', true);
			owUpdateSummary();
		});

		// ---- Wizard: precompiled toggle ----
		$('#essb-ow-precompiled-enable').on('change', function() {
			var opts = $('#essb-ow-precompiled-options');
			var label = $(this).closest('.essb-ow-toggle-large');
			if ($(this).is(':checked')) {
				opts.show();
				label.removeClass('essb-ow-toggle-disabled');
			} else {
				opts.hide();
				label.addClass('essb-ow-toggle-disabled');
			}
			owUpdateSummary();
		});
		$('#essb-ow-precompiled-mode, #essb-ow-precompiled-unique, #essb-ow-precompiled-post, #essb-ow-precompiled-footer, #essb-ow-precompiled-preload-css').on('change', owUpdateSummary);

		// ---- Wizard: navigation ----
		$('#essb-ow-prev').on('click', function(e) {
			e.preventDefault();
			if (owStep > 1) owGoTo(owStep - 1);
		});
		$('#essb-ow-next').on('click', function(e) {
			e.preventDefault();
			if (owStep < owTotalSteps) owGoTo(owStep + 1);
		});

		function owGoTo(step) {
			owStep = step;
			$('.essb-ow-pane').each(function() {
				$(this).toggleClass('essb-ow-pane-active', parseInt($(this).data('pane')) === step);
			});
			var isSummary = step === owTotalSteps;
			var stepName = $('.essb-ow-pane[data-pane="' + step + '"] .essb-ow-pane-title').text().trim();
			$('#essb-ow-phase').text(isSummary ? '<?php echo esc_js(esc_html__('Review', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Setup', 'essb')); ?>');
			$('#essb-ow-stepmeta').text(isSummary ? '<?php echo esc_js(esc_html__('Summary', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Step', 'essb')); ?> ' + step + ' <?php echo esc_js(esc_html__('of', 'essb')); ?> ' + (owTotalSteps - 1) + ' \u00b7 ' + stepName);
			$('#essb-ow-footmeta').text(isSummary ? '<?php echo esc_js(esc_html__('Summary', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Step', 'essb')); ?> ' + step + ' <?php echo esc_js(esc_html__('of', 'essb')); ?> ' + (owTotalSteps - 1));
			$('#essb-ow-fill').css('width', Math.round((step / owTotalSteps) * 100) + '%');
			$('#essb-ow-prev').prop('disabled', step === 1);
			if (step === owTotalSteps) {
				$('#essb-ow-next').hide();
			} else {
				$('#essb-ow-next').show().text(step === owTotalSteps - 1 ? '<?php echo esc_js(esc_html__('Review Summary', 'essb')); ?> \u2192' : '<?php echo esc_js(esc_html__('Next', 'essb')); ?> \u2192');
			}
		}

		// ---- Wizard: update summary ----
		function owUpdateSummary() {
			// Step 1 - CSS Mode
			var cssItem = $('.essb-ow-pane[data-pane="1"] .essb-ow-list-selected');
			var cssVal = cssItem.length ? cssItem.find('input').val() : '';
			var cssLabels = {
				'': '<?php echo esc_js(esc_html__('Full - all features, no optimization', 'essb')); ?>',
				'slim': '<?php echo esc_js(esc_html__('Slim - optimized files, minified', 'essb')); ?>',
				'mini': '<?php echo esc_js(esc_html__('Mini - minimal footprint', 'essb')); ?>',
				'light': '<?php echo esc_js(esc_html__('Light - maximum performance', 'essb')); ?>'
			};
			$('#essb-ow-summary-css').text(cssLabels[cssVal] || cssLabels['']);

			// Step 2 - JS Mode
			var jsItem = $('.essb-ow-pane[data-pane="2"] .essb-ow-list-selected');
			var jsVal = jsItem.length ? jsItem.find('input').val() : '';
			var jsLabels = {
				'': '<?php echo esc_js(esc_html__('Default - footer, best compatibility', 'essb')); ?>',
				'async': '<?php echo esc_js(esc_html__('Asynchronous - non-render-blocking', 'essb')); ?>',
				'defer': '<?php echo esc_js(esc_html__('Deferred - after page render', 'essb')); ?>'
			};
			$('#essb-ow-summary-js').text(jsLabels[jsVal] || '');

			// Step 3 - Style Mode
			var styleItem = $('.essb-ow-pane[data-pane="3"] .essb-ow-list-selected');
			var styleVal = styleItem.length ? styleItem.find('input').val() : '';
			var styleLabels = {
				'': '<?php echo esc_js(esc_html__('Default - minified CSS', 'essb')); ?>',
				'defer': '<?php echo esc_js(esc_html__('Deferred - dynamic CSS moved to footer', 'essb')); ?>'
			};
			$('#essb-ow-summary-style').text(styleLabels[styleVal] || '');

			// Step 4 - Precompiled
			var preParts = [];
			if ($('#essb-ow-precompiled-enable').is(':checked')) {
				preParts.push('<?php echo esc_js(esc_html__('Enabled', 'essb')); ?>');
				var modeVal = $('#essb-ow-precompiled-mode').val();
				var modeMap = {
					'': '<?php echo esc_js(esc_html__('CSS + JavaScript', 'essb')); ?>',
					'css': '<?php echo esc_js(esc_html__('CSS only', 'essb')); ?>',
					'js': '<?php echo esc_js(esc_html__('JavaScript only', 'essb')); ?>'
				};
				preParts.push(modeMap[modeVal] || modeMap['']);
				if ($('#essb-ow-precompiled-unique').is(':checked')) preParts.push('<?php echo esc_js(esc_html__('Unique filenames', 'essb')); ?>');
				if ($('#essb-ow-precompiled-post').is(':checked')) preParts.push('<?php echo esc_js(esc_html__('Per-post cache', 'essb')); ?>');
				if ($('#essb-ow-precompiled-footer').is(':checked')) preParts.push('<?php echo esc_js(esc_html__('CSS to footer', 'essb')); ?>');
				if ($('#essb-ow-precompiled-preload-css').is(':checked')) preParts.push('<?php echo esc_js(esc_html__('Async CSS preload', 'essb')); ?>');
			} else {
				preParts.push('<?php echo esc_js(esc_html__('Disabled', 'essb')); ?>');
			}
			$('#essb-ow-summary-precompiled').text(preParts.join(', '));
		}

		// ---- Wizard: Apply ----
		$('#essb-ow-apply').on('click', function() {
			var btn = $(this);
			btn.prop('disabled', true).text('<?php echo esc_js(esc_html__('Applying', 'essb')); ?>&hellip;');

			// Build options object
			var options = {};

			// Step 1: css_mode
			var cssMode = $('.essb-ow-pane[data-pane="1"] .essb-ow-list-selected input').val() || '';
			options.css_mode = cssMode;

			// Step 2: js_mode -> load_js_async, load_js_defer, scripts_in_head
			var jsMode = $('.essb-ow-pane[data-pane="2"] .essb-ow-list-selected input').val() || '';
			options.load_js_async = jsMode === 'async' ? 'true' : '';
			options.load_js_defer = jsMode === 'defer' ? 'true' : '';
			options.scripts_in_head = '';

			// Step 3: style_mode -> use_minified_css, load_css_footer
			var styleMode = $('.essb-ow-pane[data-pane="3"] .essb-ow-list-selected input').val() || '';
			options.use_minified_css = 'true';
			options.load_css_footer = styleMode === 'defer' ? 'true' : '';

			// Step 4: precompiled
			var preEnabled = $('#essb-ow-precompiled-enable').is(':checked');
			options.precompiled_resources = preEnabled ? 'true' : '';
			if (preEnabled) {
				options.precompiled_mode = $('#essb-ow-precompiled-mode').val() || '';
				options.precompiled_unique = $('#essb-ow-precompiled-unique').is(':checked') ? 'true' : '';
				options.precompiled_post = $('#essb-ow-precompiled-post').is(':checked') ? 'true' : '';
				options.precompiled_footer = $('#essb-ow-precompiled-footer').is(':checked') ? 'true' : '';
				options.precompiled_preload_css = $('#essb-ow-precompiled-preload-css').is(':checked') ? 'true' : '';
			} else {
				options.precompiled_mode = '';
				options.precompiled_unique = '';
				options.precompiled_post = '';
				options.precompiled_footer = '';
				options.precompiled_preload_css = '';
			}

			// Always set optimization_level to custom
			options.optimization_level = '';

			// Toast: saving state
			var $toast = $('<div class="essb-df-toast essb-df-toast-saving"><span class="essb-df-spinner"></span> <?php echo esc_js(esc_html__('Saving', 'essb')); ?>&hellip;</div>').appendTo('body');
			setTimeout(function() {
				$toast.addClass('essb-df-toast-show');
			}, 10);

			$.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
					action: 'essb_advanced_options',
					cmd: 'save',
					group: 'essb_options',
					advanced_options: options,
					essb_advancedoptions_token: $('#essb_advancedoptions_token').val()
				},
				success: function() {
					// Close wizard
					owClose();
					// Update toast to success
					$toast.removeClass('essb-df-toast-saving').addClass('essb-df-toast-success').html('<?php echo esc_js(esc_html__('Settings saved', 'essb')); ?>');
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 1500);
					btn.prop('disabled', false).text('<?php echo esc_js(esc_html__('Apply Optimization', 'essb')); ?>');
				},
				error: function() {
					$toast.removeClass('essb-df-toast-saving').addClass('essb-df-toast-success').html('<?php echo esc_js(esc_html__('Error saving settings', 'essb')); ?>');
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 2000);
					btn.prop('disabled', false).text('<?php echo esc_js(esc_html__('Apply Optimization', 'essb')); ?>');
				}
			});
		});

		// ---- Init summary ----
		owUpdateSummary();


		// ---- Quick Share Buttons Setup ----
		var swStep = 1;
		var swTotalSteps = 8;

		$('#essb-df-open-swizard').on('click', function(e) {
			e.preventDefault();
			$('#essb-sw-overlay').addClass('essb-sw-overlay-show');
			$('#essb-sw-wizard').addClass('essb-sw-wrap-show');
			swGoTo(1);
		});
		$('#essb-sw-close').on('click', function(e) {
			e.preventDefault();
			swClose();
		});
		$('#essb-sw-overlay').on('click', swClose);

		function swClose() {
			$('#essb-sw-overlay').removeClass('essb-sw-overlay-show');
			$('#essb-sw-wizard').removeClass('essb-sw-wrap-show');
		}

		$('#essb-sw-prev').on('click', function(e) {
			e.preventDefault();
			if (swStep > 1) swGoTo(swStep - 1);
		});
		$('#essb-sw-next').on('click', function(e) {
			e.preventDefault();
			if (swStep < swTotalSteps) swGoTo(swStep + 1);
		});

		function swGoTo(step) {
			swStep = step;
			$('.essb-sw-pane').each(function() {
				$(this).toggleClass('essb-sw-pane-active', parseInt($(this).data('pane')) === step);
			});
			if (step === 2) {
				swBuildVisibilityList();
			}
			var isSummary = step === swTotalSteps;
			var phase = isSummary ? '<?php echo esc_js(esc_html__('Review', 'essb')); ?>' : (step <= 2 ? '<?php echo esc_js(esc_html__('Networks', 'essb')); ?>' : (step <= 5 ? '<?php echo esc_js(esc_html__('Design', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Display', 'essb')); ?>'));
			var stepName = $('.essb-sw-pane[data-pane="' + step + '"] .essb-sw-pane-title').text().trim();
			$('#essb-sw-phase').text(phase);
			$('#essb-sw-stepmeta').text(isSummary ? '<?php echo esc_js(esc_html__('Review & Apply', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Step', 'essb')); ?> ' + step + ' <?php echo esc_js(esc_html__('of', 'essb')); ?> ' + (swTotalSteps - 1) + ' \u00b7 ' + stepName);
			$('#essb-sw-footmeta').text(isSummary ? '<?php echo esc_js(esc_html__('Review & Apply', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Step', 'essb')); ?> ' + step + ' <?php echo esc_js(esc_html__('of', 'essb')); ?> ' + (swTotalSteps - 1));
			$('#essb-sw-fill').css('width', Math.round((step / swTotalSteps) * 100) + '%');
			$('#essb-sw-prev').prop('disabled', step === 1);
			if (step === swTotalSteps) {
				$('#essb-sw-next').hide();
				swUpdateSummary();
			} else {
				$('#essb-sw-next').show().text(step === swTotalSteps - 1 ? '<?php echo esc_js(esc_html__('Review Summary', 'essb')); ?> \u2192' : '<?php echo esc_js(esc_html__('Next', 'essb')); ?> \u2192');
			}
		}

		// Network grid
		$('#essb-sw-network-grid').on('click', '.essb-sw-network-item', function() {
			$(this).toggleClass('essb-sw-network-selected');
			swUpdateNetworkCount();
			swBuildVisibilityList();
		});
		$('#essb-sw-network-search').on('input', function() {
			var q = $(this).val().toLowerCase();
			$('#essb-sw-network-grid .essb-sw-network-item').each(function() {
				var name = $(this).find('.essb-sw-network-name').text().toLowerCase();
				$(this).toggle(name.indexOf(q) > -1);
			});
		});

		function swUpdateNetworkCount() {
			var count = $('#essb-sw-network-grid .essb-sw-network-selected').length;
			$('#essb-sw-selected-info').text(count + ' <?php echo esc_js(esc_html__('network', 'essb')); ?>' + (count !== 1 ? 's' : '') + ' <?php echo esc_js(esc_html__('selected. Drag to reorder.', 'essb')); ?>');
		}
		if ($.fn.sortable) {
			$('#essb-sw-network-grid').sortable({
				placeholder: 'ui-sortable-placeholder',
				tolerance: 'pointer',
				containment: 'parent'
			});
		}

		// Device visibility step
		var swVisibilityMobileOnly = ['whatsapp', 'telegram', 'messenger', 'viber', 'sms', 'line', 'kakaotalk', 'skype'];
		var swVisibilityDesktopOnly = ['print'];

		function swSetRowDevice($row, device) {
			if (device !== 'desktop' && device !== 'mobile') {
				device = 'all';
			}
			$row.attr('data-device', device);
			$row.find('.essb-sw-seg').removeClass('essb-sw-seg-active').filter('[data-device="' + device + '"]').addClass('essb-sw-seg-active');
		}

		function swBuildVisibilityList() {
			var selected = {};
			$('#essb-sw-network-grid .essb-sw-network-selected').each(function() {
				selected[$(this).data('id')] = true;
			});
			var visible = 0;
			$('#essb-sw-visibility-list .essb-sw-visibility-row').each(function() {
				var on = !!selected[$(this).data('network')];
				$(this).toggleClass('essb-sw-visibility-row-active', on);
				$(this).css('display', on ? 'flex' : 'none');
				if (on) {
					visible++;
				}
			});
			$('#essb-sw-visibility-empty').toggle(visible === 0);
		}

		function swUpdateVisibilityPanel() {
			$('#essb-sw-visibility-options').toggle($('#essb-sw-visibility-enable').is(':checked'));
		}

		$('#essb-sw-visibility-enable').on('change', swUpdateVisibilityPanel);

		$('#essb-sw-visibility-list').on('click', '.essb-sw-seg', function() {
			swSetRowDevice($(this).closest('.essb-sw-visibility-row'), $(this).data('device'));
		});

		$('#essb-sw-visibility-suggest').on('click', function() {
			$('#essb-sw-visibility-list .essb-sw-visibility-row-active').each(function() {
				var id = $(this).data('network');
				var device = 'all';
				if (swVisibilityMobileOnly.indexOf(id) !== -1) {
					device = 'mobile';
				} else if (swVisibilityDesktopOnly.indexOf(id) !== -1) {
					device = 'desktop';
				}
				swSetRowDevice($(this), device);
			});
		});

		$('#essb-sw-visibility-reset').on('click', function() {
			$('#essb-sw-visibility-list .essb-sw-visibility-row-active').each(function() {
				swSetRowDevice($(this), 'all');
			});
		});

		// Device visibility: initial state
		$('#essb-sw-visibility-list .essb-sw-visibility-row').each(function() {
			swSetRowDevice($(this), $(this).attr('data-device'));
		});
		swUpdateVisibilityPanel();
		swBuildVisibilityList();

		// List selection (template, display mode, counter positions, pin visibility)
		$('#essb-sw-wizard').on('click', '.essb-sw-list-item', function() {
			$(this).closest('.essb-sw-list').find('.essb-sw-list-item').removeClass('essb-sw-list-selected');
			$(this).addClass('essb-sw-list-selected');
			$(this).find('input[type="radio"]').prop('checked', true);
		});

		// Counter toggle
		$('#essb-sw-show-counters').on('change', function() {
			if ($(this).is(':checked')) {
				$('#essb-sw-counter-options').show();
				$('#essb-sw-counters-toggle-wrap').removeClass('essb-sw-toggle-disabled');
			} else {
				$('#essb-sw-counter-options').hide();
				$('#essb-sw-counters-toggle-wrap').addClass('essb-sw-toggle-disabled');
			}
		});

		// Device chips
		$('.essb-sw-pos-row').on('click', '.essb-sw-device-chip', function() {
			$(this).addClass('essb-sw-device-chip-active');
			$(this).siblings().removeClass('essb-sw-device-chip-active');
		});

		// Post type selection
		$('.essb-sw-type-item').on('click', function() {
			$(this).toggleClass('essb-sw-type-selected');
		});

		// Pinterest toggle
		$('#essb-sw-pinterest-enable').on('change', function() {
			if ($(this).is(':checked')) {
				$('#essb-sw-pinterest-options').show();
				$('#essb-sw-pinterest-toggle-wrap').removeClass('essb-sw-toggle-disabled');
			} else {
				$('#essb-sw-pinterest-options').hide();
				$('#essb-sw-pinterest-toggle-wrap').addClass('essb-sw-toggle-disabled');
			}
		});

		// Pinterest position grid
		$('#essb-sw-pinterest-position-grid').on('click', '.essb-sw-position-item', function() {
			$(this).addClass('essb-sw-position-selected');
			$(this).siblings().removeClass('essb-sw-position-selected');
		});

		// Summary
		function swUpdateSummary() {
			var nCount = $('#essb-sw-network-grid .essb-sw-network-selected').length;
			$('#essb-sw-summary-networks').text(nCount + ' <?php echo esc_js(esc_html__('networks selected', 'essb')); ?>');

			var template = $('.essb-sw-pane[data-pane="3"] .essb-sw-list:first .essb-sw-list-selected .essb-sw-list-item-title').text();
			var mode = $('.essb-sw-pane[data-pane="3"] .essb-sw-list:last .essb-sw-list-selected .essb-sw-list-item-title').text();
			$('#essb-sw-summary-style').text(template + ', ' + mode);

			var deskSize = $('#essb-sw-size-desktop-list .essb-sw-list-selected .essb-sw-list-item-title').text() || '<?php echo esc_js(esc_html__('Default', 'essb')); ?>';
			var mobSize = $('#essb-sw-size-mobile-list .essb-sw-list-selected .essb-sw-list-item-title').text() || '<?php echo esc_js(esc_html__('Default', 'essb')); ?>';
			var align = $('#essb-sw-alignment-list .essb-sw-list-selected .essb-sw-list-item-title').text() || '<?php echo esc_js(esc_html__('Left', 'essb')); ?>';
			var nospace = $('#essb-sw-nospace').is(':checked') ? ', <?php echo esc_js(esc_html__('No spacing', 'essb')); ?>' : '';
			$('#essb-sw-summary-size').text('<?php echo esc_js(esc_html__('Desktop', 'essb')); ?>: ' + deskSize + ', <?php echo esc_js(esc_html__('Mobile', 'essb')); ?>: ' + mobSize + ', ' + align + nospace);

			var showCounters = $('#essb-sw-show-counters').is(':checked');
			if (showCounters) {
				var cPos = $('[name="essb-sw-counter-pos"]:checked').closest('.essb-sw-list-item').find('.essb-sw-list-item-title').text();
				var tPos = $('[name="essb-sw-total-counter-pos"]:checked').closest('.essb-sw-list-item').find('.essb-sw-list-item-title').text();
				$('#essb-sw-summary-counters').text(cPos + ', ' + tPos);
			} else {
				$('#essb-sw-summary-counters').text('<?php echo esc_js(esc_html__('Disabled', 'essb')); ?>');
			}

			var posNames = [];
			$('.essb-sw-pos-row').each(function() {
				if ($(this).find('.essb-sw-pos-check').is(':checked')) {
					var nameText = $(this).find('.essb-sw-pos-name').clone().children().remove().end().text().trim();
					posNames.push(nameText);
				}
			});
			$('#essb-sw-summary-positions').text(posNames.length > 0 ? posNames.join(', ') : '<?php echo esc_js(esc_html__('None', 'essb')); ?>');

			var pinEnabled = $('#essb-sw-pinterest-enable').is(':checked');
			$('#essb-sw-summary-pinterest').text(pinEnabled ? '<?php echo esc_js(esc_html__('Enabled', 'essb')); ?>' : '<?php echo esc_js(esc_html__('Disabled', 'essb')); ?>');
		}

		// Apply
		$('#essb-sw-apply').on('click', function() {
			var btn = $(this);
			btn.prop('disabled', true).text('<?php echo esc_js(esc_html__('Applying', 'essb')); ?>&hellip;');

			var options = {};

			// Step 1: Networks
			var selectedNetworks = [];
			$('#essb-sw-network-grid .essb-sw-network-selected').each(function() {
				selectedNetworks.push($(this).data('id'));
			});
			var allNetworks = [];
			$('#essb-sw-network-grid .essb-sw-network-selected').each(function() {
				allNetworks.push($(this).data('id'));
			});
			options.activate_networks_manage = $('#essb-sw-only-selected').is(':checked') ? 'true' : '';
			options.functions_networks = selectedNetworks;
			options.networks = allNetworks;

			// Step 2: Network device visibility (configured inline in this step)
			var enableVisibility = $('#essb-sw-visibility-enable').is(':checked');
			options.activate_networks_responsive = enableVisibility ? 'true' : '';
			var hiddenMobile = [];
			$('#essb-sw-visibility-list .essb-sw-visibility-row-active').each(function() {
				var id = $(this).data('network');
				if (!id) {
					return;
				}
				var device = $(this).attr('data-device') || 'all';
				options['responsive_' + id + '_desktop'] = (device === 'mobile') ? 'true' : '';
				options['responsive_' + id + '_mobile'] = (device === 'desktop') ? 'true' : '';
				if (device === 'desktop') {
					hiddenMobile.push(id);
				}
			});

			// Step 3: Style
			options.style = $('[name="essb-sw-template"]:checked').val();
			options.button_style = $('[name="essb-sw-display-mode"]:checked').val();

			// Step 4: Size & layout
			options.button_size = $('#essb-sw-size-desktop-list .essb-sw-list-selected').data('value') || '';
			options.button_size_mobile = $('#essb-sw-size-mobile-list .essb-sw-list-selected').data('value') || '';
			var alignment = $('#essb-sw-alignment-list .essb-sw-list-selected').data('value') || '';
			if (alignment === 'stretched') {
				options.button_width = 'full';
				options.button_pos = '';
			} else {
				options.button_pos = alignment;
			}
			options.nospace = $('#essb-sw-nospace').is(':checked') ? 'true' : '';

			// Step 5: Counters
			var showCounters = $('#essb-sw-show-counters').is(':checked');
			options.show_counter = showCounters ? 'true' : '';
			if (showCounters) {
				options.counter_pos = $('[name="essb-sw-counter-pos"]:checked').val();
				options.total_counter_pos = $('[name="essb-sw-total-counter-pos"]:checked').val();
				options.active_internal_counters = $('#essb-sw-internal-counters').is(':checked') ? 'true' : '';
			} else {
				options.counter_pos = '';
				options.total_counter_pos = '';
				options.active_internal_counters = '';
			}

			// Step 6: Positions
			var postTypes = [];
			$('.essb-sw-type-selected').each(function() {
				postTypes.push($(this).data('id'));
			});
			options.display_in_types = postTypes;

			var contentTop = $('.essb-sw-pos-row[data-pos="top"] .essb-sw-pos-check').is(':checked');
			var contentBottom = $('.essb-sw-pos-row[data-pos="bottom"] .essb-sw-pos-check').is(':checked');
			if (contentTop && contentBottom) {
				options.content_position = 'content_both';
			} else if (contentTop) {
				options.content_position = 'content_top';
			} else if (contentBottom) {
				options.content_position = 'content_bottom';
			} else {
				options.content_position = '';
			}

			var btnPositions = [];
			['sidebar', 'sharebutton'].forEach(function(pos) {
				if ($('.essb-sw-pos-row[data-pos="' + pos + '"] .essb-sw-pos-check').is(':checked')) {
					btnPositions.push(pos);
				}
			});
			options.button_position = btnPositions;

			// Sidebar position settings
			var sidebarChecked = btnPositions.indexOf('sidebar') !== -1;
			if (sidebarChecked) {
				options.sidebar_activate = 'true';
				options.sidebar_template = $('[name="essb-sw-template"]:checked').val();
				options.sidebar_button_style = 'icon';
				if (showCounters) {
					options.sidebar_show_counter = 'true';
					options.sidebar_counter_pos = 'hidden';
					options.sidebar_total_counter_pos = $('[name="essb-sw-total-counter-pos"]:checked').val();
				} else {
					options.sidebar_show_counter = '';
					options.sidebar_counter_pos = '';
					options.sidebar_total_counter_pos = '';
				}
			} else {
				options.sidebar_activate = '';
				options.sidebar_template = '';
				options.sidebar_button_style = '';
				options.sidebar_show_counter = '';
				options.sidebar_counter_pos = '';
				options.sidebar_total_counter_pos = '';
			}

			// Share Button display method - enable/disable
			var shareButtonChecked = btnPositions.indexOf('sharebutton') !== -1;
			options.deactivate_method_sharebutton = shareButtonChecked ? '' : 'true';

			var shareBottomChecked = $('.essb-sw-pos-row[data-pos="sharebottom"] .essb-sw-pos-check').is(':checked');
			options.functions_mode_mobile_auto_responsive = shareBottomChecked ? ['sharebottom'] : [];

			// Calculate mobile share bar button count
			if (shareBottomChecked) {
				var mobileNetworks = [];
				$('#essb-sw-network-grid .essb-sw-network-selected').each(function() {
					mobileNetworks.push($(this).data('id'));
				});
				if (mobileNetworks.length === 0) {
					$('#essb-sw-network-grid .essb-sw-network-item').each(function() {
						mobileNetworks.push($(this).data('id'));
					});
				}
				if (enableVisibility) {
					mobileNetworks = mobileNetworks.filter(function(id) {
						return hiddenMobile.indexOf(id) === -1;
					});
				}
				var mobileCount = mobileNetworks.length;
				options.mobile_sharebuttonsbar_count = String(mobileCount < 6 ? mobileCount : 6);
			}

			['top', 'bottom', 'sidebar', 'sharebutton'].forEach(function(pos) {
				var chip = $('.essb-sw-pos-row[data-pos="' + pos + '"] .essb-sw-device-chip-active');
				var device = chip.length ? chip.data('device') : 'any';
				options[pos + '_mobile_deactivate'] = (device === 'desktop') ? 'true' : '';
				options[pos + '_tablet_deactivate'] = (device === 'desktop') ? 'true' : '';
				options[pos + '_desktop_deactivate'] = (device === 'mobile') ? 'true' : '';
			});

			// Step 7: Pinterest
			var pinEnabled = $('#essb-sw-pinterest-enable').is(':checked');
			options.pinterest_images = pinEnabled ? 'true' : '';
			if (pinEnabled) {
				options.pinterest_position = $('#essb-sw-pinterest-position-grid .essb-sw-position-selected').data('value') || 'top-left';
				options.pinterest_visibility = $('[name="essb-sw-pin-visibility"]:checked').val();
				options.pinterest_nolinks = $('#essb-sw-pin-nolinks').is(':checked') ? 'true' : '';
				options.pinterest_lazyload = $('#essb-sw-pin-lazyload').is(':checked') ? 'true' : '';
			} else {
				options.pinterest_position = '';
				options.pinterest_visibility = '';
				options.pinterest_nolinks = '';
				options.pinterest_lazyload = '';
			}

			var $toast = $('<div class="essb-df-toast essb-df-toast-saving"><span class="essb-df-spinner"></span> <?php echo esc_js(esc_html__('Saving', 'essb')); ?>&hellip;</div>').appendTo('body');
			setTimeout(function() {
				$toast.addClass('essb-df-toast-show');
			}, 10);

			$.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
					action: 'essb_advanced_options',
					cmd: 'save',
					group: 'essb_options',
					advanced_options: options,
					essb_advancedoptions_token: $('#essb_advancedoptions_token').val()
				},
				success: function() {
					swClose();
					$toast.removeClass('essb-df-toast-saving').addClass('essb-df-toast-success').html('<?php echo esc_js(esc_html__('Settings saved', 'essb')); ?>');
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 1500);
					btn.prop('disabled', false).text('<?php echo esc_js(esc_html__('Apply Configuration', 'essb')); ?>');
				},
				error: function() {
					$toast.removeClass('essb-df-toast-saving').addClass('essb-df-toast-success').html('<?php echo esc_js(esc_html__('Error saving settings', 'essb')); ?>');
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 2000);
					btn.prop('disabled', false).text('<?php echo esc_js(esc_html__('Apply Configuration', 'essb')); ?>');
				}
			});
		});

		// ======== Initial Config Wizard ========
		(function() {
			'use strict';

			var currentPane = 'welcome';
			var totalSteps = 13;

			var el = {
				closeBtn: document.getElementById('essb-iw-close'),
				prevBtn: document.getElementById('essb-iw-prev'),
				nextBtn: document.getElementById('essb-iw-next'),
				stepLabel: document.getElementById('stepLabel'),
				phase: document.getElementById('essb-iw-phase'),
				fill: document.getElementById('essb-iw-fill'),
				footMeta: document.getElementById('essb-iw-footmeta'),
				panes: document.querySelectorAll('.essb-iw-pane'),
			};

			function showPane(pane) {
				currentPane = pane;
				var active = null;
				el.panes.forEach(function(p) {
					var on = p.getAttribute('data-pane') == pane;
					p.classList.toggle('essb-iw-pane-active', on);
					if (on) active = p;
				});

				if (pane === 'welcome') {
					el.stepLabel.textContent = 'Welcome';
					el.phase.textContent = 'Setup';
					el.fill.style.width = '0%';
					el.footMeta.textContent = 'Welcome';
					el.prevBtn.disabled = true;
					el.nextBtn.disabled = false;
					el.nextBtn.textContent = 'Next \u2192';
					return;
				}

				var step = parseInt(pane, 10);
				var phase = active ? (active.getAttribute('data-phase') || 'Setup') : 'Setup';
				var name = active ? (active.getAttribute('data-name') || '') : '';
				var pct = Math.round((step / totalSteps) * 100);

				el.stepLabel.textContent = 'Step ' + step + ' of ' + totalSteps + (name ? ' \u00b7 ' + name : '');
				el.phase.textContent = phase;
				el.fill.style.width = pct + '%';
				el.footMeta.textContent = 'Step ' + step + ' of ' + totalSteps;
				el.prevBtn.disabled = false;
				el.nextBtn.disabled = false;
				el.nextBtn.textContent = (step === totalSteps) ? 'Save Settings' : 'Next \u2192';
			}

			function nextStep() {
				if (currentPane === 'welcome') {
					showPane('1');
				} else {
					var step = parseInt(currentPane, 10);
					if (step === totalSteps) {
						saveSettings();
					} else if (step < totalSteps) {
						showPane(String(step + 1));
					}
				}
			}

			function prevStep() {
				if (currentPane === '1') {
					showPane('welcome');
				} else if (currentPane !== 'welcome') {
					var step = parseInt(currentPane, 10);
					if (step > 1) showPane(String(step - 1));
				}
			}

			function saveSettings() {
				var modeCard = document.querySelector('#modeGrid .essb-iw-mode-selected');
				var cssMode = modeCard ? modeCard.getAttribute('data-mode') : '';
				var ssoEnabled = document.getElementById('enableSSO').checked;
				var ssoImage = document.getElementById('ssoDefaultImage').value || '';

				var countersEnabled = document.getElementById('enableCounters').checked;
				var internalCounters = document.getElementById('enableInternalCounters').checked;
				var avoidNegative = document.getElementById('enableAvoidNegative').checked;
				var analyticsEnabled = document.getElementById('enableAnalytics').checked;
				var pinterestPro = document.getElementById('enablePinterestPro').checked;
				var pinterestOptimize = document.getElementById('enablePinterestOptimize') ? document.getElementById('enablePinterestOptimize').checked : false;
				var wooPinEl = document.getElementById('enablePinterestWoo');
				var wooPin = wooPinEl ? wooPinEl.checked : false;
				var quotesEnabled = document.getElementById('enableQuotes').checked;
				var highlightShareEnabled = document.getElementById('enableHighlightShare').checked;
				var shortUrlsEnabled = document.getElementById('enableShortUrls').checked;
				var profilesEnabled = document.getElementById('enableProfiles').checked;
				var subscribeEnabled = document.getElementById('enableSubscribe').checked;
				var customButtons = document.getElementById('enableCustomButtons').checked;
				var customPositions = document.getElementById('enableCustomPositions').checked;
				var translateEnabled = document.getElementById('enableTranslate').checked;

				var options = {};
				options.css_mode = cssMode;
				options.deactivate_module_shareoptimize = ssoEnabled ? '' : 'true';
				options.opengraph_tags = ssoEnabled ? 'true' : '';
				options.sso_default_image = ssoImage;

				options.deactivate_share_counters = countersEnabled ? '' : 'true';
				options.deactivate_postcount = countersEnabled ? '' : 'true';
				options.deactivate_ansp = countersEnabled ? '' : 'true';
				options.deactivate_ssr = countersEnabled ? '' : 'true';
				options.deactivate_fakecounters = 'true';
				options.deactivate_expertcounters = 'true';

				if (countersEnabled && internalCounters) {
					options.active_internal_counters = 'true';
					options.active_internal_counters_advanced = 'true';
				} else {
					options.active_internal_counters = 'false';
					options.active_internal_counters_advanced = 'false';
				}

				if (countersEnabled && avoidNegative) {
					options.social_proof_enable = 'true';
					options.button_counter_hidden_till = '10';
					options.total_counter_hidden_till = '10';
				} else {
					options.social_proof_enable = 'false';
				}

				options.deactivate_module_analytics = analyticsEnabled ? '' : 'true';
				options.stats_active = analyticsEnabled ? 'true' : 'false';

				// Pinterest Pro: the module powers both the image share button and the
				// independent WooCommerce product pin button, so keep it enabled if either is on.
				options.deactivate_module_pinterestpro = (pinterestPro || wooPin) ? '' : 'true';
				options.pinterest_images = pinterestPro ? 'true' : 'false';
				options.pinpro_woocommerce = wooPin ? 'true' : '';
				options.pinterest_optimized_load = pinterestOptimize ? 'true' : '';
				if (pinterestPro) {
					options.pinterest_lazyload = 'true';
				}

				options.deactivate_ctt = quotesEnabled ? '' : 'true';
				options.deactivate_highlight_share = highlightShareEnabled ? '' : 'true';
				options.highlight_share = highlightShareEnabled ? 'true' : 'false';
				if (highlightShareEnabled) {
					options.highlight_share_networks = ['twitter'];
					options.highlight_share_post_types = ['post'];
				}
				options.deactivate_module_shorturl = shortUrlsEnabled ? '' : 'true';
				options.deactivate_module_profiles = profilesEnabled ? '' : 'true';
				options.deactivate_module_subscribe = subscribeEnabled ? '' : 'true';
				options.deactivate_custombuttons = customButtons ? '' : 'true';
				options.deactivate_custompositions = customPositions ? '' : 'true';
				options.deactivate_module_translate = translateEnabled ? '' : 'true';

				// Always-applied defaults
				var alwaysTrue = [
					'deactivate_fakecounters', 'deactivate_expertcounters',
					'deactivate_module_aftershare', 'deactivate_module_google_analytics',
					'deactivate_module_affiliate', 'deactivate_module_message',
					'deactivate_stylelibrary',
					'deactivate_method_float', 'deactivate_method_postfloat',
					'deactivate_method_topbar', 'deactivate_method_bottombar',
					'deactivate_method_popup', 'deactivate_method_flyin',
					'deactivate_method_heroshare', 'deactivate_method_postbar',
					'deactivate_method_point', 'deactivate_method_image',
					'deactivate_method_followme', 'deactivate_method_corner',
					'deactivate_method_booster', 'deactivate_method_sharebutton',
					'deactivate_method_except', 'deactivate_method_widget',
					'deactivate_method_advanced_mobile', 'deactivate_module_followers',
					'deactivate_module_instagram', 'deactivate_module_conversions',
					'deactivate_method_integrations', 'deactivate_settings_post_type'
				];
				for (var i = 0; i < alwaysTrue.length; i++) {
					options[alwaysTrue[i]] = 'true';
				}
				options.deactivate_method_woocommerce = <?php echo class_exists('WooCommerce') ? "'false'" : "'true'"; ?>;

				var alwaysFalse = [
					'activate_customcode_share_methods', 'activate_fake',
					'activate_hooks', 'activate_minimal'
				];
				for (var i = 0; i < alwaysFalse.length; i++) {
					options[alwaysFalse[i]] = 'false';
				}

				var iwNextBtn = document.getElementById('essb-iw-next');
				iwNextBtn.disabled = true;
				iwNextBtn.textContent = '<?php echo esc_js(esc_html__('Saving', 'essb')); ?>...';

				var $toast = $('<div class="essb-df-toast essb-df-toast-saving"><span class="essb-df-spinner"></span> <?php echo esc_js(esc_html__('Saving', 'essb')); ?>&hellip;</div>').appendTo('body');
				setTimeout(function() {
					$toast.addClass('essb-df-toast-show');
				}, 10);

				$.ajax({
					type: "POST",
					url: ajaxurl,
					data: {
						action: 'essb_advanced_options',
						cmd: 'save',
						group: 'essb_options',
						advanced_options: options,
						essb_advancedoptions_token: $('#essb_advancedoptions_token').val()
					},
					success: function() {
						document.getElementById('essb-iw-wizard').style.display = 'none';
						document.getElementById('essb-iw-overlay').style.display = 'none';
						$toast.removeClass('essb-df-toast-saving essb-df-toast-success').html('<?php echo esc_js(esc_html__('Page is reloading', 'essb')); ?>&hellip;');
						setTimeout(function() {
							location.reload();
						}, 800);
					},
					error: function() {
						$toast.removeClass('essb-df-toast-saving').addClass('essb-df-toast-success').html('<?php echo esc_js(esc_html__('Error saving settings', 'essb')); ?>');
						setTimeout(function() {
							$toast.removeClass('essb-df-toast-show');
							setTimeout(function() {
								$toast.remove();
							}, 300);
						}, 2000);
						iwNextBtn.disabled = false;
						iwNextBtn.textContent = 'Save Settings';
					}
				});
			}

			el.nextBtn.addEventListener('click', function(e) {
				e.preventDefault();
				nextStep();
			});
			el.prevBtn.addEventListener('click', function(e) {
				e.preventDefault();
				prevStep();
			});
			el.closeBtn.addEventListener('click', function(e) {
				e.preventDefault();
				document.getElementById('essb-iw-wizard').style.display = 'none';
				document.getElementById('essb-iw-overlay').style.display = 'none';
			});

			document.getElementById('essb-df-open-iwizard').addEventListener('click', function(e) {
				e.preventDefault();
				document.getElementById('essb-iw-wizard').style.display = 'flex';
				document.getElementById('essb-iw-overlay').style.display = 'block';
				showPane('welcome');
			});

			document.getElementById('modeGrid').addEventListener('click', function(e) {
				var card = e.target.closest('.essb-iw-mode-card');
				if (!card) return;
				this.querySelectorAll('.essb-iw-mode-card').forEach(function(c) {
					c.classList.remove('essb-iw-mode-selected');
				});
				card.classList.add('essb-iw-mode-selected');
			});

			// Dependent (show/hide) fields: a toggle with data-target controls a block
			document.querySelectorAll('.essb-iw-toggle input[data-target]').forEach(function(input) {
				var target = document.querySelector(input.getAttribute('data-target'));
				if (!target) return;
				var sync = function() { target.style.display = input.checked ? '' : 'none'; };
				input.addEventListener('change', sync);
				sync();
			});

			document.getElementById('ssoSelectImage').addEventListener('click', function(e) {
				e.preventDefault();
				if (typeof wp !== 'undefined' && wp.media) {
					var frame = wp.media({
						title: 'Select Social Image',
						button: {
							text: 'Use this image'
						},
						multiple: false
					});
					frame.on('select', function() {
						var attachment = frame.state().get('selection').first().toJSON();
						document.getElementById('ssoDefaultImage').value = attachment.url;
						var preview = document.getElementById('ssoImagePreview');
						document.getElementById('ssoPreviewImg').src = attachment.url;
						preview.style.display = 'block';
					});
					frame.open();
				}
			});
			document.getElementById('ssoRemoveImage').addEventListener('click', function() {
				document.getElementById('ssoDefaultImage').value = '';
				document.getElementById('ssoImagePreview').style.display = 'none';
				document.getElementById('ssoPreviewImg').src = '';
			});

			(function() {
				var installNonce = document.getElementById('essb-iw-wizard').getAttribute('data-install-nonce');

				document.querySelectorAll('[data-install]').forEach(function(btn) {
					btn.addEventListener('click', function(e) {
						e.preventDefault();
						var slug = this.getAttribute('data-install');
						var originalText = this.textContent;

						this.disabled = true;
						this.textContent = 'Processing\u2026';

						var $btn = this;

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'essb_install_free_addon',
								slug: slug,
								nonce: installNonce
							},
							success: function(response) {
								if (response.success) {
									$btn.textContent = 'Active';
									$btn.className = 'essb-iw-btn essb-iw-btn-sm essb-iw-btn-success';
									$btn.disabled = true;

									var $toast = $('<div class="essb-df-toast essb-df-toast-success">Plugin installed and activated</div>').appendTo('body');
									setTimeout(function() {
										$toast.addClass('essb-df-toast-show');
									}, 10);
									setTimeout(function() {
										$toast.removeClass('essb-df-toast-show');
										setTimeout(function() {
											$toast.remove();
										}, 300);
									}, 2000);
								} else {
									var msg = response.data && response.data.message ? response.data.message : 'Installation failed';
									$btn.textContent = originalText;
									$btn.disabled = false;

									var $toast = $('<div class="essb-df-toast essb-df-toast-error">' + msg + '</div>').appendTo('body');
									setTimeout(function() {
										$toast.addClass('essb-df-toast-show');
									}, 10);
									setTimeout(function() {
										$toast.removeClass('essb-df-toast-show');
										setTimeout(function() {
											$toast.remove();
										}, 300);
									}, 3000);
								}
							},
							error: function() {
								$btn.textContent = originalText;
								$btn.disabled = false;

								var $toast = $('<div class="essb-df-toast essb-df-toast-error">Connection error. Please try again.</div>').appendTo('body');
								setTimeout(function() {
									$toast.addClass('essb-df-toast-show');
								}, 10);
								setTimeout(function() {
									$toast.removeClass('essb-df-toast-show');
									setTimeout(function() {
										$toast.remove();
									}, 300);
								}, 3000);
							}
						});
					});
				});
			})();
		})();

		if ($('#essb-activate').length) {
			$('#essb-activate').on('click', function(e) {
				e.preventDefault();

				var purchase_code = $('#essb-automatic-purchase-code').val();

				if (purchase_code == '') {
					var $toast = $('<div class="essb-df-toast essb-df-toast-error">Missing Purchase Code - Please fill purchase code before processing with activation</div>').appendTo('body');
					setTimeout(function() {
						$toast.addClass('essb-df-toast-show');
					}, 10);
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 3000);
					return;
				}

				$('#essb-cc-preloader').fadeIn(100);
				$.ajax({
					type: "POST",
					url: essb_api_url,
					data: {
						'code': purchase_code,
						'domain': essb_api_activate_domain,
						'url': essb_api_activate_url
					},
					success: function(data) {
						$('#essb-cc-preloader').fadeOut(400);
						if (typeof(data) == "string") data = JSON.parse(data);

						var code = data['code'] || '';
						var activation_message = data['message'] || '';
						var activation_code = data['hash'] || '';

						if (parseInt(code) > 0 && parseInt(code) < 10) {
							$.ajax({
								type: "POST",
								url: ajaxurl,
								data: {
									'action': 'essb_process_activation',
									'purchase_code': purchase_code,
									'activation_code': activation_code,
									'activation_state': 'activate',
									'activate_nonce': essb_api_security_token
								},
								success: function() {
									var $toast = $('<div class="essb-df-toast essb-df-toast-success">Activation Successful — Thank you! Reloading page.</div>').appendTo('body');
									setTimeout(function() {
										$toast.addClass('essb-df-toast-show');
									}, 10);
									setTimeout(function() {
										window.location.reload();
									}, 1000);
								}
							});
						} else {
							var $toast = $('<div class="essb-df-toast essb-df-toast-error">Activation Error - ' + activation_message + '</div>').appendTo('body');
							setTimeout(function() {
								$toast.addClass('essb-df-toast-show');
							}, 10);
							setTimeout(function() {
								$toast.removeClass('essb-df-toast-show');
								setTimeout(function() {
									$toast.remove();
								}, 300);
							}, 4000);
						}
					},
					error: function() {
						$('#essb-cc-preloader').fadeOut(400);
						var $toast = $('<div class="essb-df-toast essb-df-toast-error">Connection Error - Cannot connect to registration server. Please try again.</div>').appendTo('body');
						setTimeout(function() {
							$toast.addClass('essb-df-toast-show');
						}, 10);
						setTimeout(function() {
							$toast.removeClass('essb-df-toast-show');
							setTimeout(function() {
								$toast.remove();
							}, 300);
						}, 4000);
					}
				});
			});
		}

		if ($('#essb-deactivate').length) {
			$('#essb-deactivate').on('click', function(e) {
				e.preventDefault();

				if (typeof essb_used_purchasecode === 'undefined' || essb_used_purchasecode == '') {
					var $toast = $('<div class="essb-df-toast essb-df-toast-error">Missing Purchase Code - Please fill purchase code before processing with deactivation</div>').appendTo('body');
					setTimeout(function() {
						$toast.addClass('essb-df-toast-show');
					}, 10);
					setTimeout(function() {
						$toast.removeClass('essb-df-toast-show');
						setTimeout(function() {
							$toast.remove();
						}, 300);
					}, 3000);
					return;
				}

				$('#essb-cc-preloader').fadeIn(100);
				$.ajax({
					type: "POST",
					url: essb_api_url + 'deactivate.php',
					data: {
						'hash': essb_used_activationcode,
						'code': essb_used_purchasecode
					},
					success: function(data) {
						$('#essb-cc-preloader').fadeOut(400);
						if (typeof(data) == "string") data = JSON.parse(data);

						var code = data['code'] || '';
						var activation_message = data['message'] || '';

						if (parseInt(code) > 0 && parseInt(code) < 10) {
							$.ajax({
								type: "POST",
								url: ajaxurl,
								data: {
									'action': 'essb_process_activation',
									'activation_state': 'deactivate',
									'activate_nonce': essb_api_security_token
								},
								success: function() {
									var $toast = $('<div class="essb-df-toast essb-df-toast-success">Deactivation Successful — Reloading page.</div>').appendTo('body');
									setTimeout(function() {
										$toast.addClass('essb-df-toast-show');
									}, 10);
									setTimeout(function() {
										window.location.reload();
									}, 1000);
								}
							});
						} else {
							var $toast = $('<div class="essb-df-toast essb-df-toast-error">Deactivation Error - ' + activation_message + '</div>').appendTo('body');
							setTimeout(function() {
								$toast.addClass('essb-df-toast-show');
							}, 10);
							setTimeout(function() {
								$toast.removeClass('essb-df-toast-show');
								setTimeout(function() {
									$toast.remove();
								}, 300);
							}, 4000);
						}
					},
					error: function() {
						$('#essb-cc-preloader').fadeOut(400);
						var $toast = $('<div class="essb-df-toast essb-df-toast-error">Connection Error - Cannot connect to registration server. Please try again.</div>').appendTo('body');
						setTimeout(function() {
							$toast.addClass('essb-df-toast-show');
						}, 10);
						setTimeout(function() {
							$toast.removeClass('essb-df-toast-show');
							setTimeout(function() {
								$toast.remove();
							}, 300);
						}, 4000);
					}
				});
			});
		}

		// Featured Add-Ons Carousel
		(function() {
			var track = document.getElementById('essb-df-carousel-track');
			var dots = document.querySelectorAll('.essb-df-carousel-dot');
			var slides = document.querySelectorAll('.essb-df-carousel-slide');
			if (!track || !slides.length) return;
			var current = 0;
			var interval;

			function showSlide(index) {
				slides.forEach(function(s, i) {
					s.style.display = i === index ? 'grid' : 'none';
				});
				dots.forEach(function(d, i) {
					d.classList.toggle('active', i === index);
				});
				current = index;
			}

			function nextSlide() {
				showSlide((current + 1) % slides.length);
			}

			function startRotation() {
				if (interval) clearInterval(interval);
				interval = setInterval(nextSlide, 12000);
			}

			dots.forEach(function(dot) {
				dot.addEventListener('click', function(e) {
					e.preventDefault();
					showSlide(parseInt(this.getAttribute('data-slide')));
					startRotation();
				});
			});

			showSlide(0);
			startRotation();
		})();
	});
</script>