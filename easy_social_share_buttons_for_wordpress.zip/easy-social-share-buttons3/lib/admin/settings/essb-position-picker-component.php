<?php
if (!function_exists('essb5_position_picker')) {
	function essb5_position_picker($opts = array()) {

		$content_position = essb_option_value('content_position');
		if (!is_string($content_position) || $content_position === '') { $content_position = 'content_bottom'; }

		// Raw stored value for the hidden save field. It must round-trip untouched:
		// the display default above is for toggle rendering only.
		$content_position_raw = essb_option_value('content_position');
		if (!is_string($content_position_raw)) { $content_position_raw = ''; }

		$is_float = (strpos($content_position, 'float') !== false);
		$content_top = in_array($content_position, array('content_top','content_both','content_float','content_floatboth'));
		$content_bottom = in_array($content_position, array('content_bottom','content_both','content_floatboth','content_followme'));
		$content_followme = ($content_position === 'content_followme');
		// When the Follow me display method is deactivated it cannot be used;
		// keep the UI responsive instead of locking the content toggles.
		if (essb_options_bool_value('deactivate_method_followme')) {
			$content_followme = false;
		}
		$content_top_style = $is_float ? 'floating' : 'static';
		// When float-from-top display is deactivated, only static is available.
		if (essb_options_bool_value('deactivate_method_float')) {
			$content_top_style = 'static';
		}
		if ($content_position === 'content_manual') { $content_top = false; $content_bottom = false; $content_followme = false; }

		// An empty or unrecognized stored value means "no content buttons".
		// Render all toggles off so the first user interaction computes from
		// what is actually shown instead of the display default.
		if (!in_array($content_position_raw, array('content_top','content_bottom','content_both','content_float','content_floatboth','content_followme','content_manual'), true)) {
			$content_top = false; $content_bottom = false; $content_followme = false;
		}

		$button_position = essb_option_value('button_position');
		if (!is_array($button_position)) { $button_position = array(); }

		$mobile_positions_saved = essb_option_value('functions_mode_mobile_auto_responsive');
		if (!is_array($mobile_positions_saved)) { $mobile_positions_saved = array(); }

		$breakpoint = essb_option_value('functions_mode_mobile_auto_breakpoint');
		if ($breakpoint === '') { $breakpoint = '768'; }

		$sitewide_positions = essb5_available_button_positions();
		$mobile_positions = essb5_available_positions_mobile_only();

		$custom_positions = essb5_get_custom_positions();
		if (!is_array($custom_positions)) { $custom_positions = array(); }
		$locations = array('top','float','bottom','postfloat','sidebar','topbar','bottombar','popup','flyin','heroshare','postbar','point','excerpt','cornerbar','booster','sharebutton','woocommerce_content','followme');
		foreach (array_keys($custom_positions) as $cpk) { $locations[] = (string)$cpk; }
		$device_supported = array('top','float','bottom','postfloat','sidebar','topbar','bottombar','popup','flyin','heroshare','postbar','point','cornerbar','booster','sharebutton','woocommerce_content','followme','excerpt');

		$device_hidden = array();
		$message_hidden = array();
		foreach ($locations as $loc) {
			foreach (array('desktop','tablet','mobile') as $dev) {
				if (essb_option_bool_value($loc . '_' . $dev . '_deactivate')) {
					$device_hidden[$loc][$dev] = true;
				}
			}
			if (essb_option_bool_value($loc . '_text_deactivate')) {
				$message_hidden[$loc] = true;
			}
		}

		$svg_device = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>';
		$svg_gear = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';

		echo '<div class="essb-position-picker">';

		// Content group
		echo '<div class="pp-group"><div class="pp-group-head"><div class="pp-group-title">Inline (Content)</div><div class="pp-group-hint"></div></div><div class="pp-group-body">';

		// Content Top
		$top_loc = $content_top_style === 'floating' ? 'float' : 'top';
		// Responsive deactivation unified under "top" so it persists across style toggles.
		echo '<div class="pp-row' . ($content_top ? ' active' : '') . '" data-key="top">';
		echo '<div class="pp-row-info"><span class="pp-row-label">Content Top</span><span class="pp-row-desc">Show buttons at the top of content</span></div>';
		echo '<div class="pp-row-extra"><select id="ppTopStyle" class="pp-content-style input-element"><option value="static"' . ($content_top_style==='static'?' selected':'') . '>Static</option>';
		if (!essb_options_bool_value('deactivate_method_float')) {
			echo '<option value="floating"' . ($content_top_style==='floating'?' selected':'') . '>Floating</option>';
		}
		echo '</select></div>';
		echo '<div class="pp-row-actions">';
		if (in_array($top_loc, $device_supported)) echo '<button type="button" class="pp-act pp-devices-btn" title="Device visibility">' . $svg_device . '</button>';
		$cog_target = ($content_top_style === 'floating')
    ? '.essb-submenu-item.essb-cc-where-positions|essb-menu-display-6|essb-inner-menu-item-display-6'
    : '.essb-submenu-item.essb-cc-where-positions|essb-menu-display-4|essb-inner-menu-item-display-4';
echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link="' . esc_attr($cog_target) . '">' . $svg_gear . '</button>';
		echo '</div>';
		echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-content-toggle" id="ppContentTopToggle"' . ($content_top ? ' checked' : '') . ($content_followme ? ' disabled' : '') . '><span class="pp-toggle-switch"></span></label>';
		if (in_array($top_loc, $device_supported)) {
			echo '<div class="pp-devices-panel">';
			echo '<span class="pp-devices-label">Hide on:</span>';
			foreach (array('desktop','tablet','mobile') as $dev) {
				$sel = (!empty($device_hidden['top'][$dev]) || !empty($device_hidden['float'][$dev])) ? ' selected' : '';
				echo '<button type="button" class="pp-device-option' . $sel . '" data-device="' . $dev . '">' . ucfirst($dev) . '</button>';
			}
			echo '<span class="pp-devices-label" style="margin-left:8px;">Message:</span>';
			$msel = (!empty($message_hidden['top']) || !empty($message_hidden['float'])) ? ' selected' : '';
			echo '<button type="button" class="pp-message-option' . $msel . '">Hide above/before</button>';
			echo '</div>';
		}
		echo '</div>';

		// Content Bottom
		echo '<div class="pp-row' . ($content_bottom ? ' active' : '') . '" data-key="bottom">';
		echo '<div class="pp-row-info"><span class="pp-row-label">Content Bottom</span><span class="pp-row-desc">Show buttons at the bottom of content</span></div>';
		echo '<div class="pp-row-extra"></div>';
		echo '<div class="pp-row-actions">';
		echo '<button type="button" class="pp-act pp-devices-btn" title="Device visibility">' . $svg_device . '</button>';
		echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link=".essb-submenu-item.essb-cc-where-positions|essb-menu-display-5|essb-inner-menu-item-display-5">' . $svg_gear . '</button>';
		echo '</div>';
		echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-content-toggle" id="ppContentBottomToggle"' . ($content_bottom ? ' checked' : '') . ($content_followme ? ' disabled' : '') . '><span class="pp-toggle-switch"></span></label>';
		echo '<div class="pp-devices-panel">';
		echo '<span class="pp-devices-label">Hide on:</span>';
		foreach (array('desktop','tablet','mobile') as $dev) {
			$sel = !empty($device_hidden['bottom'][$dev]) ? ' selected' : '';
			echo '<button type="button" class="pp-device-option' . $sel . '" data-device="' . $dev . '">' . ucfirst($dev) . '</button>';
		}
		echo '<span class="pp-devices-label" style="margin-left:8px;">Message:</span>';
		$msel = !empty($message_hidden['bottom']) ? ' selected' : '';
		echo '<button type="button" class="pp-message-option' . $msel . '">Hide above/before</button>';
		echo '</div>';
		echo '</div>';

		// Follow Me (hidden when the Follow me display method is deactivated)
		if (!essb_options_bool_value('deactivate_method_followme')) {
			echo '<div class="pp-row' . ($content_followme ? ' active' : '') . '" data-key="followme">';
			echo '<div class="pp-row-info"><span class="pp-row-label">Follow Me Bar</span><span class="pp-row-desc">Fixed bar when content buttons scroll out (manages top+bottom)</span></div>';
			echo '<div class="pp-row-extra"></div>';
			echo '<div class="pp-row-actions">';
			echo '<button type="button" class="pp-act pp-devices-btn" title="Device visibility">' . $svg_device . '</button>';
			echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link=".essb-submenu-item.essb-cc-where-positions|essb-menu-display-18|essb-inner-menu-item-display-18">' . $svg_gear . '</button>';
			echo '</div>';
			echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-content-toggle" id="ppFollowmeToggle"' . ($content_followme ? ' checked' : '') . '><span class="pp-toggle-switch"></span></label>';
			echo '<div class="pp-devices-panel">';
			echo '<span class="pp-devices-label">Hide on:</span>';
			foreach (array('desktop','tablet','mobile') as $dev) {
				$sel = !empty($device_hidden['followme'][$dev]) ? ' selected' : '';
				echo '<button type="button" class="pp-device-option' . $sel . '" data-device="' . $dev . '">' . ucfirst($dev) . '</button>';
			}
			echo '<span class="pp-devices-label" style="margin-left:8px;">Message:</span>';
			$msel = !empty($message_hidden['followme']) ? ' selected' : '';
			echo '<button type="button" class="pp-message-option' . $msel . '">Hide above/before</button>';
			echo '</div>';
			echo '</div>';
		}

		echo '</div></div>';

		// Additional group
		echo '<div class="pp-group"><div class="pp-group-head"><div class="pp-group-title">Additional (Website)</div><div class="pp-group-hint"></div></div><div class="pp-group-body">';
		foreach ($sitewide_positions as $key => $data) {
			$label = isset($data['label']) ? $data['label'] : $key;
			$desc = isset($data['desc']) ? $data['desc'] : '';
			$active = in_array($key, $button_position);
			$devsup = !in_array($key, array('onmedia','widget'));
			// configure link: use provided link, or build for custom positions
			$link = isset($data['link']) ? $data['link'] : '';
			if ($link == '' && is_numeric($key)) {
				$link = '.essb-submenu-item.essb-cc-where-positions||essb-inner-menu-item-display-' . $key;
			}
			echo '<div class="pp-row' . ($active ? ' active' : '') . '" data-key="' . esc_attr($key) . '">';
			$is_custom = is_numeric($key);
			$badge = $is_custom ? ' <span class="pp-badge pp-badge-custom">Custom</span>' : '';
			echo '<div class="pp-row-info"><span class="pp-row-label">' . esc_html($label) . $badge . '</span></div>';
			echo '<div class="pp-row-extra"></div>';
			echo '<div class="pp-row-actions">';
			if ($devsup) echo '<button type="button" class="pp-act pp-devices-btn" title="Device visibility">' . $svg_device . '</button>';
			if ($link != '') {
				if (strpos($link, 'http') === 0) {
					echo '<a class="pp-act pp-cog-btn" title="Settings" href="' . esc_url($link) . '">' . $svg_gear . '</a>';
				} else {
					echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link="' . esc_attr($link) . '">' . $svg_gear . '</button>';
				}
			}
			echo '</div>';
			echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-row-toggle" name="essb_options[button_position][]" value="' . esc_attr($key) . '"' . ($active ? ' checked' : '') . '><span class="pp-toggle-switch"></span></label>';
			if ($devsup) {
				echo '<div class="pp-devices-panel">';
				echo '<span class="pp-devices-label">Hide on:</span>';
				foreach (array('desktop','tablet','mobile') as $dev) {
					$sel = !empty($device_hidden[$key][$dev]) ? ' selected' : '';
					echo '<button type="button" class="pp-device-option' . $sel . '" data-device="' . $dev . '">' . ucfirst($dev) . '</button>';
				}
				echo '<span class="pp-devices-label" style="margin-left:8px;">Message:</span>';
				$msel = !empty($message_hidden[$key]) ? ' selected' : '';
				echo '<button type="button" class="pp-message-option' . $msel . '">Hide above/before</button>';
				echo '</div>';
			}
			echo '</div>';
		}
		echo '</div></div>';

		// Mobile group
		echo '<div class="pp-group"><div class="pp-group-head"><div class="pp-group-title">Mobile</div><div class="pp-group-hint">Mobile-optimized methods.</div></div><div class="pp-group-body">';
		echo '<div class="pp-breakpoint-row"><label class="pp-breakpoint-label" for="essb_pp_breakpoint">Mobile breakpoint</label><div class="pp-breakpoint-input-wrap"><input type="number" class="pp-breakpoint-input input-element" id="essb_pp_breakpoint" name="essb_options[functions_mode_mobile_auto_breakpoint]" value="' . esc_attr($breakpoint) . '"><span class="pp-breakpoint-unit">px</span></div></div>';
		foreach ($mobile_positions as $key => $data) {
			$label = isset($data['label']) ? $data['label'] : $key;
			$desc = isset($data['desc']) ? $data['desc'] : '';
			$active = in_array($key, $mobile_positions_saved);
			echo '<div class="pp-row' . ($active ? ' active' : '') . '" data-key="' . esc_attr($key) . '">';
			echo '<div class="pp-row-info"><span class="pp-row-label">' . esc_html($label) . '</span><span class="pp-row-desc">' . esc_html($desc) . '</span></div>';
			echo '<div class="pp-row-extra"></div>';
			echo '<div class="pp-row-actions">';
			echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link="' . esc_attr(isset($data['link']) ? $data['link'] : '') . '">' . $svg_gear . '</button>';
			echo '</div>';
			echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-row-toggle" name="essb_options[functions_mode_mobile_auto_responsive][]" value="' . esc_attr($key) . '"' . ($active ? ' checked' : '') . '><span class="pp-toggle-switch"></span></label>';
			echo '</div>';
		}
		echo '</div></div>';

		// WooCommerce group
		echo '<div class="pp-group"><div class="pp-group-head"><div class="pp-group-title">WooCommerce</div><div class="pp-group-hint"></div></div><div class="pp-group-body">';
		// WooCommerce Content (shared responsive location)
		echo '<div class="pp-row active" data-key="woocommerce_content">';
		echo '<div class="pp-row-info"><span class="pp-row-label">WooCommerce Content</span><span class="pp-row-desc">Shared device &amp; message visibility for WooCommerce positions</span></div>';
		echo '<div class="pp-row-extra"></div>';
		echo '<div class="pp-row-actions">';
		echo '<button type="button" class="pp-act pp-devices-btn" title="Device visibility">' . $svg_device . '</button>';
		echo '</div>';
		echo '<span class="pp-row-toggle-spacer"></span>';
		echo '<div class="pp-devices-panel">';
		echo '<span class="pp-devices-label">Hide on:</span>';
		foreach (array('desktop','tablet','mobile') as $dev) {
			$sel = !empty($device_hidden['woocommerce_content'][$dev]) ? ' selected' : '';
			echo '<button type="button" class="pp-device-option' . $sel . '" data-device="' . $dev . '">' . ucfirst($dev) . '</button>';
		}
		echo '<span class="pp-devices-label" style="margin-left:8px;">Message:</span>';
		$msel = !empty($message_hidden['woocommerce_content']) ? ' selected' : '';
		echo '<button type="button" class="pp-message-option' . $msel . '">Hide above/before</button>';
		echo '</div>';
		echo '</div>';

		$woo_labels = array(
			'woocommece_share' => array('After Product Short Description','Recommended location',true,false,''),
			'woocommerce_after_add_to_cart_form' => array('After Add to Cart','Single product page only',false,false,''),
			'woocommece_beforeprod' => array('Before Product','Before product block',false,false,''),
			'woocommece_afterprod' => array('After Product','After product block',false,false,''),
		);
		foreach ($woo_labels as $key => $info) {
			$active = essb_option_bool_value($key);
			echo '<div class="pp-row' . ($active ? ' active' : '') . '" data-key="woocommerce_content">';
			echo '<div class="pp-row-info"><span class="pp-row-label">' . esc_html($info[0]) . ($info[2] ? ' <span class="pp-badge pp-badge-rec">Recommended</span>' : '') . '</span><span class="pp-row-desc">' . esc_html($info[1]) . '</span></div>';
			echo '<div class="pp-row-extra"></div>';
			echo '<div class="pp-row-actions">';
			echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link=".essb-submenu-item.essb-cc-where-positions|essb-menu-display-22|essb-inner-menu-item-display-22">' . $svg_gear . '</button>';
			echo '</div>';
			echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-woo-toggle" name="essb_options[' . $key . ']" value="true"' . ($active ? ' checked' : '') . '><span class="pp-toggle-switch"></span></label>';
			echo '</div>';
		}
		// addon-gated
		// WooCommerce Additional (addons) title row
		echo '<div class="pp-row pp-row-title"><div class="pp-row-info"><span class="pp-row-label">WooCommerce Additional</span></div><div class="pp-row-extra"></div><div class="pp-row-actions"></div><span class="pp-row-toggle-spacer"></span></div>';

		$addons = array(
			'woocommece_sharebar' => array('ESSB_DM_WSB_PLUGIN_ROOT','WooCommerce Share Bar','Sticky bottom bar'),
			'woocommece_thankyou' => array('ESSB_DM_WTB_PLUGIN_ROOT','Share on Thank-You Page','Purchased products'),
			'woocommece_index' => array('ESSB_DM_WSC_PLUGIN_ROOT','Product List Share','Share in product lists'),
		);
		foreach ($addons as $key => $info) {
			$const = $info[0];
			if (defined($const)) {
				$active = essb_option_bool_value($key);
				echo '<div class="pp-row' . ($active ? ' active' : '') . '" data-key="woocommerce_content">';
				echo '<div class="pp-row-info"><span class="pp-row-label">' . esc_html($info[1]) . ' <span class="pp-badge pp-badge-lock">Addon</span></span><span class="pp-row-desc">' . esc_html($info[2]) . '</span></div>';
				echo '<div class="pp-row-extra"></div>';
				echo '<div class="pp-row-actions">';
				echo '<button type="button" class="pp-act pp-cog-btn" title="Settings" data-link=".essb-submenu-item.essb-cc-where-positions|essb-menu-display-22|essb-inner-menu-item-display-22">' . $svg_gear . '</button>';
				echo '</div>';
				echo '<label class="pp-switch-wrap"><input type="checkbox" class="pp-woo-toggle" name="essb_options[' . $key . ']" value="true"' . ($active ? ' checked' : '') . '><span class="pp-toggle-switch"></span></label>';
				echo '</div>';
			} else {
				echo '<div class="pp-row locked" data-key="woocommerce_content">';
				echo '<div class="pp-row-info"><span class="pp-row-label">' . esc_html($info[1]) . ' <span class="pp-badge pp-badge-lock">Addon</span></span><span class="pp-row-desc">' . esc_html($info[2]) . '</span></div>';
				echo '<div class="pp-row-extra"></div>';
				echo '<div class="pp-row-actions"></div>';
				echo '<span class="pp-row-toggle-spacer"></span>';
				echo '</div>';
			}
		}
		echo '</div></div>';

		// hidden content_position
		echo '<input type="hidden" name="essb_options[content_position]" id="essb_pp_content_position" value="' . esc_attr($content_position_raw) . '">';

		// hidden responsive inputs
		foreach ($locations as $loc) {
			foreach (array('desktop','tablet','mobile') as $dev) {
				$val = essb_option_bool_value($loc . '_' . $dev . '_deactivate') ? 'true' : '';
				echo '<input type="hidden" name="essb_options[' . $loc . '_' . $dev . '_deactivate]" id="essb_pp_' . $loc . '_' . $dev . '_deactivate" value="' . esc_attr($val) . '">';
			}
			$tval = essb_option_bool_value($loc . '_text_deactivate') ? 'true' : '';
			echo '<input type="hidden" name="essb_options[' . $loc . '_text_deactivate]" id="essb_pp_' . $loc . '_text_deactivate" value="' . esc_attr($tval) . '">';
		}

		echo '</div>';

		// inline JS
		echo '<script type="text/javascript">
		(function(){
			var contentTop = ' . json_encode($content_top) . ';
			var contentTopStyle = ' . json_encode($content_top_style) . ';
			var contentBottom = ' . json_encode($content_bottom) . ';
			var contentFollowme = ' . json_encode($content_followme) . ';
			var deviceHidden = ' . json_encode($device_hidden) . ';
			var messageHidden = ' . json_encode($message_hidden) . ';

			function contentPositionValue(){
				if (contentFollowme) return "content_followme";
				if (contentTop && contentBottom) return (contentTopStyle === "floating") ? "content_floatboth" : "content_both";
				if (contentTop) return (contentTopStyle === "floating") ? "content_float" : "content_top";
				if (contentBottom) return "content_bottom";
				return "content_manual";
			}
			function syncContentPosition(){
				var el = document.getElementById("essb_pp_content_position");
				if (el) el.value = contentPositionValue();
			}
			function syncHidden(loc, dev, val){
				var el = document.getElementById("essb_pp_" + loc + "_" + dev + "_deactivate");
				if (el) el.value = val ? "true" : "";
			}
			function syncMessage(loc, val){
				var el = document.getElementById("essb_pp_" + loc + "_text_deactivate");
				if (el) el.value = val ? "true" : "";
			}

			// top toggle
			var topToggle = document.getElementById("ppContentTopToggle");
			if (topToggle) {
				topToggle.addEventListener("change", function(){
					contentTop = this.checked;
					if (contentTop) contentFollowme = false;
					var fm = document.getElementById("ppFollowmeToggle"); if (fm) fm.checked = contentFollowme;
					var bot = document.getElementById("ppContentBottomToggle"); if (bot) bot.disabled = contentFollowme;
					topToggle.disabled = contentFollowme;
					var row = this.closest(".pp-row"); if (row) row.classList.toggle("active", contentTop);
					syncContentPosition();
				});
			}
			var topStyle = document.getElementById("ppTopStyle");
			if (topStyle) {
				topStyle.addEventListener("change", function(){ contentTopStyle = this.value; syncContentPosition(); });
			}
			var botToggle = document.getElementById("ppContentBottomToggle");
			if (botToggle) {
				botToggle.addEventListener("change", function(){ contentBottom = this.checked; if (contentBottom) contentFollowme = false; var fm = document.getElementById("ppFollowmeToggle"); if (fm) fm.checked = contentFollowme; var row = this.closest(".pp-row"); if (row) row.classList.toggle("active", contentBottom); syncContentPosition(); });
			}
			var fmToggle = document.getElementById("ppFollowmeToggle");
			if (fmToggle) {
				fmToggle.addEventListener("change", function(){ contentFollowme = this.checked; if (contentFollowme){ contentTop = false; contentBottom = false; } var t = document.getElementById("ppContentTopToggle"); var b = document.getElementById("ppContentBottomToggle"); if (t) t.checked = contentTop; if (b) b.checked = contentBottom; if (t) t.disabled = contentFollowme; if (b) b.disabled = contentFollowme; var row = this.closest(".pp-row"); if (row) row.classList.toggle("active", contentFollowme); syncContentPosition(); });
			}

			// sitewide toggles update row active
			document.querySelectorAll(".pp-row-toggle").forEach(function(cb){
				cb.addEventListener("change", function(){
					var row = this.closest(".pp-row"); if (row) row.classList.toggle("active", this.checked);
				});
			});
			// woo toggles
			document.querySelectorAll(".pp-woo-toggle").forEach(function(cb){
				cb.addEventListener("change", function(){
					var row = this.closest(".pp-row"); if (row) row.classList.toggle("active", this.checked);
				});
			});

			// devices button toggle panel
			document.querySelectorAll(".pp-devices-btn").forEach(function(btn){
				btn.addEventListener("click", function(e){
					e.stopPropagation();
					var row = this.closest(".pp-row");
					var panel = row ? row.querySelector(".pp-devices-panel") : null;
					this.classList.toggle("active");
					if (panel) panel.classList.toggle("open");
				});
			});
			// device option
			document.querySelectorAll(".pp-device-option").forEach(function(btn){
				btn.addEventListener("click", function(e){
					e.stopPropagation();
					var row = this.closest(".pp-row");
					var key = row ? row.getAttribute("data-key") : null;
					var dev = this.getAttribute("data-device");
					if (!key || !dev) return;
					deviceHidden[key] = deviceHidden[key] || {desktop:false,tablet:false,mobile:false};
					deviceHidden[key][dev] = !deviceHidden[key][dev];
					this.classList.toggle("selected", deviceHidden[key][dev]);
					syncHidden(key, dev, deviceHidden[key][dev]);
					// unify content-top responsive keys (top <-> float)
					if (key === "top") {
						deviceHidden["float"] = deviceHidden["float"] || {desktop:false,tablet:false,mobile:false};
						deviceHidden["float"][dev] = deviceHidden["top"][dev];
						syncHidden("float", dev, deviceHidden["float"][dev]);
					}
					// update button active
					var btn = row.querySelector(".pp-devices-btn");
					var configured = deviceHidden[key].desktop || deviceHidden[key].tablet || deviceHidden[key].mobile || messageHidden[key];
					if (btn) btn.classList.toggle("active", configured);
				});
			});
			// message option
			document.querySelectorAll(".pp-message-option").forEach(function(btn){
				btn.addEventListener("click", function(e){
					e.stopPropagation();
					var row = this.closest(".pp-row");
					var key = row ? row.getAttribute("data-key") : null;
					if (!key) return;
					messageHidden[key] = !messageHidden[key];
					this.classList.toggle("selected", messageHidden[key]);
					syncMessage(key, messageHidden[key]);
					// unify content-top responsive keys (top <-> float)
					if (key === "top") {
						messageHidden["float"] = messageHidden["top"];
						syncMessage("float", messageHidden["float"]);
					}
					var dbtn = row.querySelector(".pp-devices-btn");
					var h = deviceHidden[key] || {};
					var configured = (h.desktop||h.tablet||h.mobile) || messageHidden[key];
					if (dbtn) dbtn.classList.toggle("active", configured);
				});
			});

			// cog button -> switch tab using data-link
			document.querySelectorAll(".pp-cog-btn").forEach(function(btn){
				btn.addEventListener("click", function(e){
					e.stopPropagation();
					var link = this.getAttribute("data-link") || "";
					if (!link) return;
					var parts = link.split("|");
					if (parts[0]) {
						var firstSel = parts[0];
						if (firstSel.charAt(0) !== "." && firstSel.charAt(0) !== "#") firstSel = "." + firstSel;
						var firstEl = document.querySelector(firstSel);
						if (firstEl) firstEl.click();
					}
					if (parts[1] && document.getElementById(parts[1])) document.getElementById(parts[1]).click();
					if (parts[2] && document.querySelector("." + parts[2])) document.querySelector("." + parts[2]).click();
				});
			});

			// auto-open panels that have saved settings
			document.querySelectorAll(".pp-devices-panel").forEach(function(panel){
				var row = panel.closest(".pp-row");
				var key = row ? row.getAttribute("data-key") : null;
				if (!key) return;
				var h = deviceHidden[key] || {};
				var configured = (h.desktop||h.tablet||h.mobile) || messageHidden[key];
				if (configured) { panel.classList.add("open"); var b = row.querySelector(".pp-devices-btn"); if (b) b.classList.add("active"); }
			});

		})();
		</script>';

		// enqueue styles? inline minimal
		echo '<style>
		.essb-position-picker { width: 100%; }
		.pp-group { background:#fff; border:1px solid var(--color-grey-200); border-radius:8px; margin-bottom:16px; overflow:hidden; }
		.pp-group:hover { border-color:var(--color-grey-400); }
		.pp-group-head { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; padding:15px; background:#fff; border-bottom:1px solid rgba(0,0,0,.07); }
		.pp-group-title { font-size:14px; font-weight:600; color:var(--color-content-blue); margin:0; text-transform:capitalize; }
		.pp-group-title { font-size:14px; font-weight:700; color:var(--color-content-blue); }
		.pp-group-hint { font-size:11.5px; color:var(--color-grey-600); }
		.pp-group-body { padding:0; }
		.pp-row { display:grid; grid-template-columns:1fr 120px auto auto; gap:12px; align-items:center; padding:10px 16px; border-bottom:1px solid var(--color-grey-100); transition:background .15s ease; }
		.pp-row:last-child { border-bottom:none; }
		.pp-row:hover { background:var(--color-grey-100); }
		.pp-row.active { background:var(--primary-light); }
		.pp-row.locked { opacity:.6; }
		.pp-row-info { min-width:0; }
		.pp-row-label { display:inline-flex; align-items:center; gap:8px; font-size:13px; font-weight:600; color:var(--color-content-blue); }
		.pp-row-desc { display:block; font-size:11.5px; color:var(--color-grey-600); margin-top:2px; }
		.pp-badge { display:inline-block; font-size:10px; font-weight:700; letter-spacing:.04em; text-transform:uppercase; padding:2px 7px; border-radius:20px; }
		.pp-badge-rec { color:var(--primary-active); background:var(--primary-light); border:1px solid var(--primary-clarity); }
		.pp-badge-lock { color:var(--color-grey-700); background:var(--color-grey-200); }
		.pp-badge-custom { color:var(--info-active); background:var(--info-light); border:1px solid var(--info-clarity); }
		.pp-row-extra { display:flex; align-items:center; min-width:120px; }
		.pp-content-style { width:100%; padding:5px 8px; font-size:12px; border:1px solid var(--color-grey-300); border-radius:6px; background:#fff; color:var(--color-content-blue); }
		.pp-row-actions { display:flex; gap:4px; }
		.pp-act { display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; padding:0; border:1px solid var(--color-grey-300); border-radius:6px; background:#fff; color:var(--color-grey-600); cursor:pointer; transition:all .15s ease; }
		.pp-act:hover, .pp-act.active { border-color:var(--primary); color:var(--primary); background:var(--primary-light); }
		.pp-switch-wrap { position:relative; display:inline-block; width:38px; height:22px; cursor:pointer; }
		.pp-switch-wrap input,
		.pp-row-toggle, .pp-woo-toggle { position:absolute !important; opacity:0 !important; width:1px !important; height:1px !important; padding:0 !important; margin:-1px !important; overflow:hidden !important; clip:rect(0,0,0,0) !important; white-space:nowrap !important; border:0 !important; appearance:none !important; -webkit-appearance:none !important; }
		.pp-row-toggle-spacer { display:inline-block; width:38px; height:22px; }
		.pp-row-title { background:var(--color-grey-100); }
		.pp-row-title .pp-row-label { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--color-grey-600); }
		.pp-toggle-switch { position:absolute; inset:0; border-radius:22px; background:var(--color-switch-bg); transition:background .15s ease; }
		.pp-toggle-switch::after { content:""; position:absolute; top:2px; left:2px; width:18px; height:18px; border-radius:50%; background:#fff; transition:left .15s ease; box-shadow:0 1px 3px rgba(0,0,0,.2); }
		.pp-row-toggle:checked + .pp-toggle-switch, .pp-woo-toggle:checked + .pp-toggle-switch, .pp-content-toggle:checked + .pp-toggle-switch { background:var(--color-switch-bg-active); }
		.pp-row-toggle:checked + .pp-toggle-switch::after, .pp-woo-toggle:checked + .pp-toggle-switch::after, .pp-content-toggle:checked + .pp-toggle-switch::after { left:18px; }
		.pp-row:not(.active) .pp-row-actions, .pp-row.locked .pp-row-actions { visibility:hidden; pointer-events:none; }
		.pp-devices-panel { display:none; grid-column:1 / -1; padding:10px 12px; margin-top:4px; align-items:center; gap:8px; flex-wrap:wrap; background:#fff; border:1px solid var(--color-grey-200); border-radius:8px; }
		.pp-devices-panel.open { display:flex; }
		.pp-devices-label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--color-grey-600); margin-right:4px; }
		.pp-device-option, .pp-message-option { font-size:11.5px; font-weight:600; padding:5px 12px; border-radius:20px; border:1px solid var(--color-grey-300); background:#fff; color:var(--color-content-blue); cursor:pointer; transition:all .15s ease; }
		.pp-device-option:hover, .pp-message-option:hover { border-color:var(--primary); color:var(--primary); }
		.pp-device-option.selected { background:var(--danger); color:#fff; border-color:var(--danger); }
		.pp-device-option.selected::before { content:"✕ "; font-size:10px; }
		.pp-message-option.selected { background:var(--danger); color:#fff; border-color:var(--danger); }
		.pp-message-option.selected::before { content:"✕ "; font-size:10px; }
		.pp-breakpoint-row { display:flex; align-items:center; gap:10px; padding:10px 16px; border-bottom:1px solid var(--color-grey-100); }
		.pp-breakpoint-label { font-size:12.5px; font-weight:600; color:var(--color-content-blue); }
		.pp-breakpoint-input-wrap { display:flex; align-items:center; gap:4px; }
		.pp-breakpoint-input { width:70px; padding:5px 8px; font-size:12px; border:1px solid var(--color-grey-300); border-radius:6px; outline:none; color:var(--color-content-blue); }
		.pp-breakpoint-input:focus { border-color:var(--primary); }
		.pp-breakpoint-unit { font-size:12px; color:var(--color-grey-600); }
		.pp-switch-wrap input:disabled + .pp-toggle-switch { opacity:.4; cursor:not-allowed; }
		</style>';
	}
}
