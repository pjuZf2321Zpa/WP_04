<?php
if (!function_exists('essb5_positions_by_posttype')) {
	function essb5_positions_by_posttype($opts = array()) {

		global $wp_post_types;

		$pts = get_post_types(array('show_ui' => true, '_builtin' => true));
		$cpts = get_post_types(array('show_ui' => true, '_builtin' => false));

		$post_type_list = array();
		foreach (array_merge($pts, $cpts) as $pt) {
			if (!isset($wp_post_types[$pt])) { continue; }
			$post_type_list[$pt] = $wp_post_types[$pt]->label;
		}
		$post_type_list['homepage'] = 'Homepage';

		$content_positions = essb5_available_content_positions();
		$button_positions = essb5_available_button_positions();

		// determine configured post types (saved non-default values)
		$configured = array();
		foreach ($post_type_list as $pt => $label) {
			$content = essb_option_value('content_position_' . $pt);
			$button = essb_option_value('button_position_' . $pt);
			if (!is_array($button)) { $button = array(); }
			if ($content !== '' || count($button) > 0) {
				$configured[$pt] = array('content' => $content, 'button' => $button);
			}
		}

		$enabled = essb_option_bool_value('positions_by_pt');

		// build option lists
		$content_opts_html = '<option value="">Inherit (global)</option>';
		foreach ($content_positions as $key => $data) {
			$label = isset($data['label']) ? $data['label'] : $key;
			$content_opts_html .= '<option value="' . esc_attr($key) . '">' . esc_html($label) . '</option>';
		}

		$button_chips_html = '';
		foreach ($button_positions as $key => $data) {
			$label = isset($data['label']) ? $data['label'] : $key;
			$button_chips_html .= '<label class="pp-chip"><input type="checkbox" name="essb_options[button_position___PT__][]" value="' . esc_attr($key) . '"> ' . esc_html($label) . '</label>';
		}

		// card renderer
		$render_card = function ($pt, $label, $content_val, $button_vals) use ($content_opts_html, $button_positions) {
			$content_select = str_replace('value="' . esc_attr($content_val) . '"', 'value="' . esc_attr($content_val) . '" selected', $content_opts_html);
			// Stored value not in the current list (e.g. deactivated method):
			// carry it as a selected fallback instead of resetting to Inherit,
			// otherwise the next save would silently delete it.
			if ($content_val !== '' && strpos($content_select, 'value="' . esc_attr($content_val) . '" selected') === false) {
				$content_select = '<option value="' . esc_attr($content_val) . '" selected>' . esc_html($content_val) . ' (' . esc_html__('Inactive', 'essb') . ')</option>' . $content_opts_html;
			}
			$chips = '';
			foreach ($button_positions as $key => $data) {
				$lbl = isset($data['label']) ? $data['label'] : $key;
				$checked = in_array($key, $button_vals) ? ' checked' : '';
				$active = in_array($key, $button_vals) ? ' active' : '';
				$chips .= '<label class="pp-chip' . $active . '"><input type="checkbox" name="essb_options[button_position_' . esc_attr($pt) . '][]" value="' . esc_attr($key) . '"' . $checked . '> ' . esc_html($lbl) . '</label>';
			}
			// Same for stored button values missing from the current list.
			foreach ($button_vals as $bv) {
				if (!isset($button_positions[$bv])) {
					$chips .= '<input type="hidden" name="essb_options[button_position_' . esc_attr($pt) . '][]" value="' . esc_attr($bv) . '">';
				}
			}
			$html = '';
			$html .= '<div class="essb-cp-card" data-pt="' . esc_attr($pt) . '">';
			$html .= '<div class="essb-cp-card-head">';
			$html .= '<div class="essb-cp-card-icon"><i class="fa fa-share-alt"></i></div>';
			$html .= '<div class="essb-cp-card-heading">';
			$html .= '<span class="essb-cp-card-title">' . esc_html($label) . '</span>';
			$html .= '<span class="essb-cp-card-id">' . esc_html($pt) . '</span>';
			$html .= '</div>';
			$html .= '<div class="essb-cp-card-actions">';
			$html .= '<button type="button" class="essb-ui-btn essb-ui-btn-clear essb-ui-btn-danger essb-ui-btn-sm pp-remove-btn" data-pt="' . esc_attr($pt) . '"><i class="fa fa-close"></i> Remove</button>';
			$html .= '</div>';
			$html .= '</div>';
			$html .= '<div class="essb-cp-card-body">';
			$html .= '<div class="pp-field">';
			$html .= '<span class="essb-cp-kicker essb-cp-code-label">Inline (Content)</span>';
			$html .= '<select class="pp-select input-element" name="essb_options[content_position_' . esc_attr($pt) . ']">' . $content_select . '</select>';
			$html .= '</div>';
			$html .= '<div class="pp-field">';
			$html .= '<span class="essb-cp-kicker essb-cp-code-label">Additional (Website)</span>';
			$html .= '<div class="pp-chips">' . $chips . '</div>';
			$html .= '</div>';
			$html .= '</div>';
			$html .= '</div>';
			return $html;
		};

		// template card (placeholders)
		$template_chips = '';
		foreach ($button_positions as $key => $data) {
			$lbl = isset($data['label']) ? $data['label'] : $key;
			$template_chips .= '<label class="pp-chip"><input type="checkbox" name="essb_options[button_position___PT__][]" value="' . esc_attr($key) . '"> ' . esc_html($lbl) . '</label>';
		}
		$template_content_opts = $content_opts_html;
		$template_card = '';
		$template_card .= '<div class="essb-cp-card" data-pt="__PT__">';
		$template_card .= '<div class="essb-cp-card-head">';
		$template_card .= '<div class="essb-cp-card-icon"><i class="fa fa-share-alt"></i></div>';
		$template_card .= '<div class="essb-cp-card-heading">';
		$template_card .= '<span class="essb-cp-card-title">__LABEL__</span>';
		$template_card .= '<span class="essb-cp-card-id">__PT__</span>';
		$template_card .= '</div>';
		$template_card .= '<div class="essb-cp-card-actions">';
		$template_card .= '<button type="button" class="essb-ui-btn essb-ui-btn-clear essb-ui-btn-danger essb-ui-btn-sm pp-remove-btn" data-pt="__PT__"><i class="fa fa-close"></i> Remove</button>';
		$template_card .= '</div>';
		$template_card .= '</div>';
		$template_card .= '<div class="essb-cp-card-body">';
		$template_card .= '<div class="pp-field">';
		$template_card .= '<span class="essb-cp-kicker essb-cp-code-label">Inline (Content)</span>';
		$template_card .= '<select class="pp-select input-element" name="essb_options[content_position___PT__]">' . $template_content_opts . '</select>';
		$template_card .= '</div>';
		$template_card .= '<div class="pp-field">';
		$template_card .= '<span class="essb-cp-kicker essb-cp-code-label">Additional (Website)</span>';
		$template_card .= '<div class="pp-chips">' . $template_chips . '</div>';
		$template_card .= '</div>';
		$template_card .= '</div>';
		$template_card .= '</div>';

		echo '<div class="essb-positions-by-posttype">';

		// toggle
		echo '<div class="pp-toggle-bar">';
		echo '<label class="pp-switch-row">';
		echo '<span class="pp-switch-label">Enable different positions by post type</span>';
		echo '<span class="pp-switch-wrap"><input type="checkbox" id="ppByPtToggle" name="essb_options[positions_by_pt]" value="true" ' . ($enabled ? 'checked' : '') . '><span class="pp-toggle-switch"></span></span>';
		echo '</label>';
		echo '</div>';

		// add row
		echo '<div class="pp-add-row" id="ppAddRow">';
		echo '<label class="pp-add-label" for="ppAddSelect">Add post type</label>';
		echo '<select id="ppAddSelect" class="pp-add-select input-element">';
		echo '<option value="">— choose —</option>';
		foreach ($post_type_list as $pt => $label) {
			if (isset($configured[$pt])) { continue; }
			echo '<option value="' . esc_attr($pt) . '">' . esc_html($label) . '</option>';
		}
		echo '</select>';
		echo '<button type="button" class="pp-btn pp-btn-primary" id="ppAddBtn">+ Add</button>';
		echo '</div>';

		// configured cards
		echo '<div id="ppConfigured">';
		foreach ($configured as $pt => $vals) {
			if (!isset($post_type_list[$pt])) { continue; }
			echo $render_card($pt, $post_type_list[$pt], $vals['content'], $vals['button']);
		}
		if (count($configured) === 0) {
			echo '<div class="pp-empty">No post types configured yet. Add one above.</div>';
		}
		echo '</div>';

		// template
		echo '<template id="ppPtTemplate">' . $template_card . '</template>';

		echo '</div>';

		// styles
		echo '<style>
		.essb-positions-by-posttype { width: 100%; }
		.pp-toggle-bar { background:#fff; border:1px solid var(--color-grey-200); border-radius:8px; padding:12px 16px; margin-bottom:14px; }
		.pp-switch-row { display:flex; align-items:center; justify-content:space-between; gap:12px; }
		.pp-switch-label { font-size:13px; font-weight:600; }
		.pp-switch-wrap { position:relative; display:inline-block; width:38px; height:22px; cursor:pointer; }
		.pp-switch-wrap input { position:absolute; opacity:0; width:1px; height:1px; }
		.pp-toggle-switch { position:absolute; inset:0; border-radius:22px; background:var(--color-grey-300); transition:background .15s ease; }
		.pp-toggle-switch::after { content:""; position:absolute; top:2px; left:2px; width:18px; height:18px; border-radius:50%; background:#fff; transition:left .15s ease; box-shadow:0 1px 3px rgba(0,0,0,.2); }
		.pp-switch-wrap input:checked + .pp-toggle-switch { background:var(--primary-active, #1d4ed8); }
		.pp-switch-wrap input:checked + .pp-toggle-switch::after { left:18px; }
		.pp-add-row { display:flex; align-items:center; gap:10px; background:#fff; border:1px solid var(--color-grey-200); border-radius:8px; padding:12px 16px; margin-bottom:14px; }
		.pp-add-label { font-size:13px; font-weight:600; color:var(--color-content-blue); }
		.pp-add-select { flex:1; max-width:320px; padding:6px 10px; border:1px solid var(--color-grey-300); border-radius:6px; font-size:13px; background:#fff; }
		.pp-btn { padding:7px 14px; border:1px solid var(--color-grey-300); border-radius:6px; background:#fff; color:var(--color-content-blue); font-size:13px; font-weight:600; cursor:pointer; transition:all .15s ease; }
		.pp-btn:hover { border-color:var(--primary, #3b82f6); color:var(--primary, #3b82f6); }
		.pp-btn-primary { background:var(--primary, #3b82f6); color:#fff; border-color:var(--primary, #3b82f6); }
		.pp-btn-primary:hover { background:var(--primary-active, #1d4ed8); color:#fff; border-color:var(--primary-active, #1d4ed8); }
		.pp-btn-danger { color:#ef4444; border-color:#ef4444; }
		.pp-card { background:#fff; border:1px solid var(--color-grey-200); border-radius:8px; margin-bottom:12px; overflow:hidden; }
		.pp-card-head { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:12px 16px; background:var(--color-grey-100); border-bottom:1px solid var(--color-grey-200); }
		.pp-card-title { font-size:14px; font-weight:700; color:var(--color-content-blue); display:flex; align-items:center; gap:8px; }
		.pp-card-badge { font-size:10px; font-weight:700; letter-spacing:.04em; text-transform:uppercase; padding:2px 7px; border-radius:20px; background:var(--primary-light, #eff6ff); color:var(--primary-active, #1d4ed8); border:1px solid var(--primary-clarity, #bfdbfe); }
		.pp-card-body { padding:14px 16px; display:grid; gap:14px; }
		.pp-field { display:grid; gap:6px; }
		.pp-field-label { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--color-grey-600); }
		.pp-select { padding:7px 10px; border:1px solid var(--color-grey-300); border-radius:6px; font-size:13px; background:#fff; max-width:360px; }
		.pp-chips { display:flex; flex-wrap:wrap; gap:6px; }
		.pp-chip { padding:5px 12px; border:1px solid var(--color-grey-300); border-radius:20px; background:#fff; color:var(--color-content-blue); font-size:12px; font-weight:600; cursor:pointer; transition:all .15s ease; display:inline-flex; align-items:center; gap:6px; }
		.pp-chip:hover { border-color:var(--primary, #3b82f6); color:var(--primary, #3b82f6); }
		.pp-chip input { position:absolute; opacity:0; width:1px; height:1px; margin:0; pointer-events:none; }
		.essb-cp-kicker { margin-top: 18px; display: block; }
		.pp-chip:has(input:checked) { background:var(--primary, #3b82f6); color:#fff; border-color:var(--primary, #3b82f6); }
		.pp-empty { text-align:center; padding:30px 16px; color:var(--color-grey-600); font-size:13px; background:#fff; border:1px dashed var(--color-grey-300); border-radius:8px; margin-bottom:12px; }
		</style>';

		// script
		echo '<script>
		(function(){
			var configured = {};
			document.querySelectorAll(".essb-cp-card").forEach(function(card){
				configured[card.getAttribute("data-pt")] = true;
			});
			function refreshSelect() {
				var sel = document.getElementById("ppAddSelect");
				if (!sel) return;
				Array.from(sel.options).forEach(function(opt){
					if (opt.value === "") return;
					opt.disabled = !!configured[opt.value];
					opt.hidden = !!configured[opt.value];
				});
			}
			refreshSelect();

			var toggle = document.getElementById("ppByPtToggle");
			var addRow = document.getElementById("ppAddRow");
			var configuredWrap = document.getElementById("ppConfigured");
			function syncToggle() {
				var on = toggle && toggle.checked;
				if (addRow) addRow.style.display = on ? "" : "none";
				if (configuredWrap) configuredWrap.style.display = on ? "" : "none";
			}
			if (toggle) { toggle.addEventListener("change", syncToggle); syncToggle(); }

			document.addEventListener("click", function(e){
				var addBtn = e.target.closest("#ppAddBtn");
				if (addBtn) {
					var sel = document.getElementById("ppAddSelect");
					var pt = sel ? sel.value : "";
					if (!pt) return;
					var tpl = document.getElementById("ppPtTemplate");
					if (!tpl) return;
					var html = tpl.innerHTML.replace(/__PT__/g, pt).replace(/__LABEL__/g, pt);
					// try to use label from option text
					var opt = sel.querySelector("option[value=\"" + pt + "\"]");
					if (opt) html = html.replace(new RegExp(pt.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\\\$&"), "g"), pt); // noop safety
					var tmp = document.createElement("div");
					tmp.innerHTML = html;
					var card = tmp.firstElementChild;
					// set label properly
					var titleEl = card.querySelector(".essb-cp-card-title");
					var idEl = card.querySelector(".essb-cp-card-id");
					if (titleEl && opt) {
						titleEl.textContent = opt.textContent;
					}
					if (idEl) {
						idEl.textContent = pt;
					}
					var empty = configuredWrap.querySelector(".pp-empty");
					if (empty) empty.remove();
					configuredWrap.appendChild(card);
					configured[pt] = true;
					refreshSelect();
					sel.value = "";
					return;
				}
				var removeBtn = e.target.closest(".pp-remove-btn");
				if (removeBtn) {
					var pt = removeBtn.getAttribute("data-pt");
					var card = removeBtn.closest(".essb-cp-card");
					if (card) card.remove();
					delete configured[pt];
					if (Object.keys(configured).length === 0) {
						var empty = document.createElement("div");
						empty.className = "pp-empty";
						empty.textContent = "No post types configured yet. Add one above.";
						configuredWrap.appendChild(empty);
					}
					refreshSelect();
					return;
				}
			});

			// chip toggle visual state
			document.addEventListener("change", function(e){
				if (e.target && e.target.matches(".pp-chips input[type=checkbox]")) {
					var chip = e.target.closest(".pp-chip");
					if (chip) chip.classList.toggle("active", e.target.checked);
				}
			});
		})();
		</script>';
	}
}
