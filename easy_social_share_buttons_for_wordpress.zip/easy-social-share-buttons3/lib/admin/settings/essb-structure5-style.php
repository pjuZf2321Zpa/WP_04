<?php
if (class_exists('ESSBControlCenter')) {
	ESSBControlCenter::register_sidebar_section_menu('style', 'buttons', esc_html__('Share Buttons', 'essb'));
	if (!essb_option_bool_value('deactivate_module_followers')) {
		ESSBControlCenter::register_sidebar_section_menu('style', 'fans', esc_html__('Followers Counter', 'essb'));
	}
	
	if (!essb_option_bool_value('deactivate_module_profiles')) {
		ESSBControlCenter::register_sidebar_section_menu('style', 'profiles', esc_html__('Profile Links', 'essb'));
	}
	
	if (essb_is_active_feature('imageshare')) {
		ESSBControlCenter::register_sidebar_section_menu('style', 'image', esc_html__('On Media', 'essb'));
	}
	
	if (!essb_option_bool_value('deactivate_ctt')) {
		ESSBControlCenter::register_sidebar_section_menu('style', 'cct', esc_html__('Click to Share', 'essb'));
	}
	
	ESSBControlCenter::register_sidebar_section_menu('style', 'css', esc_html__('Additional CSS', 'essb'));
	ESSBControlCenter::register_sidebar_section_menu('style', 'css2', esc_html__('Additional Footer CSS', 'essb'));
	ESSBControlCenter::register_sidebar_section_menu('style', 'javascript', esc_html__('Additional Javascript', 'essb'));
	ESSBControlCenter::register_sidebar_section_menu('style', 'my-template', esc_html__('Share Buttons Template Builder', 'essb'));
}


ESSBOptionsStructureHelper::menu_item('style', 'buttons', esc_html__('Share Buttons', 'essb'), 'default');

if (!essb_option_bool_value('deactivate_module_followers')) {
	ESSBOptionsStructureHelper::menu_item('style', 'fans', esc_html__('Followers Counter', 'essb'), 'default');
}
ESSBOptionsStructureHelper::menu_item('style', 'image', esc_html__('On Media Share', 'essb'), 'default');
ESSBOptionsStructureHelper::menu_item('style', 'css', esc_html__('Additional CSS', 'essb'), 'default');
ESSBOptionsStructureHelper::menu_item('style', 'css2', esc_html__('Additional Footer CSS', 'essb'), 'default');
ESSBOptionsStructureHelper::menu_item('style', 'javascript', esc_html__('Additional Javascript', 'essb'), 'default');


ESSBOptionsStructureHelper::menu_item('style', 'my-template', esc_html__('Custom Share Buttons Template', 'essb'), 'default');

essb_heading_with_related_section_open('style', 'buttons', esc_html__('Share Buttons', 'essb'), '<i class="fa fa-paint-brush"></i>', '');
ESSBOptionsStructureHelper::field_switch('style', 'buttons', 'customizer_is_active', esc_html__('Enable color customization of the used theme for Share Buttons', 'essb'), '', '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'), '', '', 'true');

$customizer_is_active = essb_options_bool_value('customizer_is_active');
if ($customizer_is_active) {
    ESSBOptionsStructureHelper::panel_start('style', 'buttons', esc_html__('Total Counter', 'essb'), '', 'fa21 ti-ruler-pencil', array("mode" => "toggle", 'state' => 'closed', 'css_class' => 'essb-auto-open'));
	ESSBOptionsStructureHelper::field_color('style', 'buttons', 'customizer_totalbgcolor', esc_html__('Background color', 'essb'), '');
	ESSBOptionsStructureHelper::field_switch('style', 'buttons', 'customizer_totalnobgcolor', esc_html__('Remove background color', 'essb'), '', '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'));
	ESSBOptionsStructureHelper::field_color('style', 'buttons', 'customizer_totalcolor', esc_html__('Text color', 'essb'), '');
	ESSBOptionsStructureHelper::field_textbox('style', 'buttons', 'customizer_totalfontsize', esc_html__('Total counter big style font-size', 'essb'), esc_html__('Enter value in px (ex: 21px) to change the total counter font-size', 'essb'));
	ESSBOptionsStructureHelper::field_textbox('style', 'buttons', 'customizer_totalfontsize_after', esc_html__('Total counter big style shares text font-size', 'essb'), esc_html__('Enter value in px (ex: 10px) to change the total counter shares text font-size', 'essb'));
	ESSBOptionsStructureHelper::field_textbox('style', 'buttons', 'customizer_totalfontsize_beforeafter', esc_html__('Total counter font size', 'essb'), esc_html__('Enter value in px (ex: 14px) to change the total counter text font-size', 'essb'));
	ESSBOptionsStructureHelper::panel_end('style', 'buttons');

	ESSBOptionsStructureHelper::panel_start('style', 'buttons', esc_html__('Background Colors, Icon Size, Network Name Size for All Networks', 'essb'), '', 'fa21 ti-ruler-pencil', array("mode" => "toggle", 'state' => 'closed', 'css_class' => 'essb-auto-open'));
	
	ESSBOptionsStructureHelper::field_heading('style', 'buttons', 'heading7', esc_html__('Colors', 'essb'), '', 'pb0', '<i class="ti-ruler-pencil"></i>');
	ESSBOptionsStructureHelper::holder_start('style', 'buttons', 'essb-related-heading7 mb40', '');
	$color_fields = array(
		'customizer_bgcolor' => esc_html__('Background color', 'essb'),
		'customizer_textcolor' => esc_html__('Text color', 'essb'),
		'customizer_hovercolor' => esc_html__('Hover background color', 'essb'),
		'customizer_hovertextcolor' => esc_html__('Hover text color', 'essb'),
	);
	$color_html = '<div class="essb-sbc-global-colors">';
	foreach ($color_fields as $cid => $clabel) {
		$cval = essb_option_value($cid);
		$color_html .= '<div class="essb-sbc-gc-field"><label>' . $clabel . '</label><div class="essb-cd-color" data-key="' . $cid . '"><label class="sbc-color-btn" data-key="' . $cid . '"><input type="color" class="sbc-color input-element" data-key="' . $cid . '" value="' . esc_attr($cval ? $cval : '#9ca3af') . '"></label><input type="text" id="essb_options_' . $cid . '" name="essb_options[' . $cid . ']" class="input-element essb-cd-input mono sbc-hex input-element input-colorselector" data-key="' . $cid . '" maxlength="7" placeholder="#rrggbb" value="' . esc_attr($cval) . '"></div></div>';
	}
	$color_html .= '</div>';
	ESSBOptionsStructureHelper::field_html('style', 'buttons', $color_html, '', '');
	ESSBOptionsStructureHelper::field_switch('style', 'buttons', 'customizer_remove_bg_hover_effects', esc_html__('Remove effects applied from theme on hover', 'essb'), esc_html__('Activate this option to remove the default theme hover effects (like darken or lighten color).', 'essb'), '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'));
	ESSBOptionsStructureHelper::holder_end('style', 'buttons');
	
	ESSBOptionsStructureHelper::field_heading('style', 'buttons', 'heading_preview', esc_html__('Live preview', 'essb'), '', 'pb0', '<i class="ti-eye"></i>');
	ESSBOptionsStructureHelper::field_html('style', 'buttons', '<div class="essb-sbc-global-preview" id="essbSbcGlobalPreview"><a class="essb-sbc-gp-btn" data-net="facebook"><span class="essb-sbc-gp-icon"></span>Facebook</a><a class="essb-sbc-gp-btn" data-net="twitter"><span class="essb-sbc-gp-icon"></span>X</a><a class="essb-sbc-gp-btn" data-net="linkedin"><span class="essb-sbc-gp-icon"></span>LinkedIn</a></div><script>window.ESSB_TWITTER_X_ICON = ' . wp_json_encode(essb_svg_icon('twitter_x')) . ';</script>', '', '');

	ESSBOptionsStructureHelper::field_heading('style', 'buttons', 'heading7', esc_html__('Sizes', 'essb'), '', 'pb0', '<i class="ti-ruler-pencil"></i>');
	ESSBOptionsStructureHelper::holder_start('style', 'buttons', 'essb-related-heading7 mb40', '');
	
	ESSBOptionsStructureHelper::field_textbox('style', 'buttons', 'customizer_iconsize', esc_html__('Icon size', 'essb'), esc_html__('Provide custom icon size value. Default value for almost all templates is 18. Please enter value without any symbols before/after it - example: 22', 'essb'));
	ESSBOptionsStructureHelper::field_textbox('style', 'buttons', 'customizer_icon_block_size', esc_html__('Size of the icon block', 'essb'), esc_html__('Numeric value (example: 40). Set the width and height of the icon block element, overwriting the default.', 'essb'));
	ESSBOptionsStructureHelper::field_textbox('style', 'buttons', 'customizer_namesize', esc_html__('Network name font size', 'essb'), esc_html__('Enter value in px (ex: 10px) to change the network name text font-size', 'essb'));
	ESSBOptionsStructureHelper::field_switch('style', 'buttons', 'customizer_namebold', esc_html__('Make network name bold', 'essb'), esc_html__('Activate this option to apply bold style over network name', 'essb'), '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'));
	ESSBOptionsStructureHelper::field_switch('style', 'buttons', 'customizer_nameupper', esc_html__('Make network name upper case', 'essb'), esc_html__('Activate this option to apply automatic transform to upper case over network name', 'essb'), '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'));
	ESSBOptionsStructureHelper::holder_end('style', 'buttons');

	ESSBOptionsStructureHelper::panel_end('style', 'buttons');

	ESSBOptionsStructureHelper::field_switch('style', 'buttons', 'customizer_network_is_active', esc_html__('Colors and Icon change for every network', 'essb'), esc_html__('Activate per-network color overrides.', 'essb'), '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'), '', '', 'true');
	
	if (essb_option_bool_value('customizer_network_is_active')) {
		essb3_draw_sharebuttons_customization('style', 'buttons');
	}
}
essb_heading_with_related_section_close('style', 'buttons');
ESSBOptionsStructureHelper::title('style', 'css', esc_html__('Header CSS Code', 'essb'), esc_html__('Enter additional custom CSS code that will appear inside content when the plugin is running. ', 'essb'));
ESSBOptionsStructureHelper::field_editor('style', 'css', 'customizer_css', '', '', 'css');
ESSBOptionsStructureHelper::title('style', 'css2', esc_html__('Footer CSS Code', 'essb'), esc_html__('Enter additional custom CSS code that will appear inside content when the plugin is running. ', 'essb'));
ESSBOptionsStructureHelper::field_editor('style', 'css2', 'customizer_css_footer', '', '', 'css');

ESSBOptionsStructureHelper::title('style', 'javascript', esc_html__('Javascript Code', 'essb'), esc_html__('Enter custom javascript code that will be added only when the plugin is running.', 'essb'));
ESSBOptionsStructureHelper::field_editor('style', 'javascript', 'customizer_js_footer', '', '', 'javascript');


if (!essb_option_bool_value('deactivate_module_followers')) {
	ESSBOptionsStructureHelper::panel_start('style', 'fans', esc_html__('Enable color customization of social followers counter', 'essb'), '', 'fa21 fa fa-paint-brush', array("mode" => "switch", 'switch_id' => 'activate_fanscounter_customizer', 'switch_on' => esc_html__('Yes', 'essb'), 'switch_off' => esc_html__('No', 'essb')));
	essb3_draw_fanscounter_customization('style', 'fans');
	ESSBOptionsStructureHelper::panel_end('style', 'fans');
}

if (!essb_option_bool_value('deactivate_module_profiles')) {
	ESSBOptionsStructureHelper::panel_start('style', 'profiles', esc_html__('Enable color customization of social profile links', 'essb'), '', 'fa21 fa fa-paint-brush', array("mode" => "switch", 'switch_id' => 'activate_profiles_customizer', 'switch_on' => esc_html__('Yes', 'essb'), 'switch_off' => esc_html__('No', 'essb')));
	essb3_draw_profiles_customization('style', 'profiles');
	ESSBOptionsStructureHelper::panel_end('style', 'profiles');
}

if (essb_is_active_feature('imageshare')) {
	ESSBOptionsStructureHelper::panel_start('style', 'image', esc_html__('Activate customization of on media sharing button colors', 'essb'), esc_html__('Activate this option to get range of options to change color for each network into on media sharing.', 'essb'), 'fa21 fa fa-cogs', array("mode" => "switch", 'switch_id' => 'activate_imageshare_customizer', 'switch_on' => esc_html__('Yes', 'essb'), 'switch_off' => esc_html__('No', 'essb')));
	essb3_draw_imageshare_customization('style', 'image');
	ESSBOptionsStructureHelper::panel_end('style', 'image');
}

if (!essb_option_bool_value('deactivate_ctt')) {
	ESSBOptionsStructureHelper::panel_start('style', 'cct', esc_html__('Enable build of a custom template for Click-to-Tweet', 'essb'), '', 'fa21 fa fa-paint-brush', array("mode" => "switch", 'switch_id' => 'activate_cct_customizer', 'switch_on' => esc_html__('Yes', 'essb'), 'switch_off' => esc_html__('No', 'essb')));

	essb3_draw_ctt_customization('style', 'cct');

	ESSBOptionsStructureHelper::panel_end('style', 'cct');
	
}


function essb3_prepare_color_customization_by_network($tab_id, $menu_id) {
	global $essb_networks;

	$list = essb_available_social_networks();
	
	$checkbox_list_networks = array();
	foreach ($list as $key => $object) {
		$checkbox_list_networks[$key] = $object['name'];
	}

	foreach ($checkbox_list_networks as $key => $text) {
	    $button = '<br/><span class="ao-new-subscribe-design essb-settings-upload-svg-icon" data-for="essb_options_customizer_'.$key.'_svgicon" data-picker="ao-svg-file-'.$key.'"><span class="essb_icon fa fa-upload"></span><span>Upload</span></span>';
	    $button .= '<input type="file" name="ao-svg-file-'.$key.'" id="ao-svg-file-'.$key.'" class="ao-hidden" accept=".svg"/>';
	    
	    
		ESSBOptionsStructureHelper::panel_start($tab_id, $menu_id, $text, '', 'fa21 essb_icon_'.$key, array("mode" => "toggle", 'state' => 'closed'));
		ESSBOptionsStructureHelper::field_color($tab_id, $menu_id, 'customizer_'.$key.'_bgcolor', esc_html__('Background color', 'essb'), '');
		ESSBOptionsStructureHelper::field_color($tab_id, $menu_id, 'customizer_'.$key.'_textcolor', esc_html__('Text color', 'essb'), '');
		ESSBOptionsStructureHelper::field_color($tab_id, $menu_id, 'customizer_'.$key.'_hovercolor', esc_html__('Hover background color', 'essb'), '');
		ESSBOptionsStructureHelper::field_color($tab_id, $menu_id, 'customizer_'.$key.'_hovertextcolor', esc_html__('Hover text color', 'essb'), '');
		//ESSBOptionsStructureHelper::field_textarea($tab_id, $menu_id, 'customizer_'.$key.'_svgicon', esc_html__('SVG icon', 'essb') . $button, esc_html__('Provide your own custom SVG icon for this social network. Recommended is to be a single color SVG icon with a fill style.', 'essb'));
		ESSBOptionsStructureHelper::panel_end($tab_id, $menu_id);
	}
}


function essb3_draw_imageshare_customization($tab_id, $menu_id) {
	$listOfNetworksAdvanced = array( "facebook" => "Facebook", "twitter" => "Twitter", "google" => "Google", "linkedin" => "LinkedIn", "pinterest" => "Pinterest", "tumblr" => "Tumblr", "reddit" => "Reddit", "digg" => "Digg", "delicious" => "Delicious", "vkontakte" => "VKontakte", "odnoklassniki" => "Odnoklassniki");

	foreach ($listOfNetworksAdvanced as $network => $title) {
		ESSBOptionsStructureHelper::field_color($tab_id, $menu_id, 'imagecustomizer_'.$network, $title, '');
	}
}

function essb3_draw_fanscounter_customization($tab_id, $menu_id) {
	$network_list = ESSBSocialFollowersCounterHelper::available_social_networks();

	if (defined('ESSB3_SFCE_VERSION')) {
		$network_list = ESSBSocialFollowersCounterHelper::list_of_all_available_networks_extended();
	}

	$networks = array();
	foreach ($network_list as $network => $title) {
		if (ESSBSocialFollowersCounterHelper::is_deprecated_network($network)) {
			continue;
		}
		$networks[$network] = $title;
	}

	$committed = array();
	$committed['fanscustomizer_all'] = essb_option_value('fanscustomizer_all');
	$committed['fanscustomizer_hover_all'] = essb_option_value('fanscustomizer_hover_all');
	$committed['fanscustomizer_icon_all'] = essb_option_value('fanscustomizer_icon_all');
	$committed['fanscustomizer_icon_hover_all'] = essb_option_value('fanscustomizer_icon_hover_all');
	foreach ($networks as $network => $title) {
		$committed['fanscustomizer_' . $network] = essb_option_value('fanscustomizer_' . $network);
		$committed['fanscustomizer_hover_' . $network] = essb_option_value('fanscustomizer_hover_' . $network);
		$committed['fanscustomizer_icon_' . $network] = essb_option_value('fanscustomizer_icon_' . $network);
		$committed['fanscustomizer_icon_hover_' . $network] = essb_option_value('fanscustomizer_icon_hover_' . $network);
	}

	ob_start();
	?>
	<div class="flc-wrap" id="flcWrap">
		<div class="plc-global">
			<div class="plc-global-head">
				<div>
					<div class="plc-global-title"><?php esc_html_e('All networks', 'essb'); ?></div>
					<div class="plc-global-desc"><?php esc_html_e('Global override applied to every follower network unless a per-network color is set.', 'essb'); ?></div>
				</div>
			</div>
			<div class="plc-global-fields">
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Regular', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="fanscustomizer_all">
						<label class="plc-color-btn" data-key="fanscustomizer_all"><input type="color" class="plc-color" data-key="fanscustomizer_all"></label>
						<input type="text" name="essb_options[fanscustomizer_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="fanscustomizer_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Hover', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="fanscustomizer_hover_all">
						<label class="plc-color-btn" data-key="fanscustomizer_hover_all"><input type="color" class="plc-color" data-key="fanscustomizer_hover_all"></label>
						<input type="text" name="essb_options[fanscustomizer_hover_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="fanscustomizer_hover_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Icon', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="fanscustomizer_icon_all">
						<label class="plc-color-btn" data-key="fanscustomizer_icon_all"><input type="color" class="plc-color" data-key="fanscustomizer_icon_all"></label>
						<input type="text" name="essb_options[fanscustomizer_icon_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="fanscustomizer_icon_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Icon hover', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="fanscustomizer_icon_hover_all">
						<label class="plc-color-btn" data-key="fanscustomizer_icon_hover_all"><input type="color" class="plc-color" data-key="fanscustomizer_icon_hover_all"></label>
						<input type="text" name="essb_options[fanscustomizer_icon_hover_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="fanscustomizer_icon_hover_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
			</div>
		</div>

		<div class="plc-toolbar">
			<input type="text" class="input-element essb-cd-input plc-search" id="flcSearch" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
			<span class="essb-ui-badge essb-ui-badge-sm" id="flcCount">0</span>
			<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary" id="flcChanged">0</span>
			<label class="essb-ui-switch essb-ui-switch-lg" style="margin-left:auto;"><input type="checkbox" id="flcPreviewHover"><span><?php esc_html_e('Preview hover', 'essb'); ?></span></label>
			<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-sm" id="flcResetAll"><?php esc_html_e('Reset all per-network', 'essb'); ?></button>
		</div>

		<div class="plc-grid" id="flcGrid"></div>
	</div>
	<script>
		window.FLC_NETWORKS = <?php echo wp_json_encode(array_map(function ($key, $name) {
			return array('key' => $key, 'name' => $name);
		}, array_keys($networks), array_values($networks))); ?>;
		window.FLC_COMMITTED = <?php echo wp_json_encode($committed); ?>;
	</script>
	<?php
	$html = ob_get_clean();

	ESSBOptionsStructureHelper::field_html($tab_id, $menu_id, $html);
}

function essb3_draw_profiles_customization($tab_id, $menu_id) {
	$network_list = ESSBSocialProfilesHelper::available_social_networks();

	$networks = array();
	foreach ($network_list as $network => $title) {
		if (ESSBSocialFollowersCounterHelper::is_deprecated_network($network)) {
			continue;
		}
		$networks[$network] = $title;
	}

	$committed = array();
	$committed['profilecustomize_all'] = essb_option_value('profilecustomize_all');
	$committed['profilecustomize_hover_all'] = essb_option_value('profilecustomize_hover_all');
	$committed['profilecustomize_icon_all'] = essb_option_value('profilecustomize_icon_all');
	$committed['profilecustomize_icon_hover_all'] = essb_option_value('profilecustomize_icon_hover_all');
	foreach ($networks as $network => $title) {
		$committed['profilecustomize_' . $network] = essb_option_value('profilecustomize_' . $network);
		$committed['profilecustomize_hover_' . $network] = essb_option_value('profilecustomize_hover_' . $network);
		$committed['profilecustomize_icon_' . $network] = essb_option_value('profilecustomize_icon_' . $network);
		$committed['profilecustomize_icon_hover_' . $network] = essb_option_value('profilecustomize_icon_hover_' . $network);
	}

	ob_start();
	?>
	<div class="plc-wrap" id="plcWrap">
		<div class="plc-global">
			<div class="plc-global-head">
				<div>
					<div class="plc-global-title"><?php esc_html_e('All networks', 'essb'); ?></div>
					<div class="plc-global-desc"><?php esc_html_e('Global override applied to every profile link unless a per-network color is set.', 'essb'); ?></div>
				</div>
			</div>
			<div class="plc-global-fields">
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Regular', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="profilecustomize_all">
						<label class="plc-color-btn" data-key="profilecustomize_all"><input type="color" class="plc-color" data-key="profilecustomize_all"></label>
						<input type="text" name="essb_options[profilecustomize_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="profilecustomize_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Hover', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="profilecustomize_hover_all">
						<label class="plc-color-btn" data-key="profilecustomize_hover_all"><input type="color" class="plc-color" data-key="profilecustomize_hover_all"></label>
						<input type="text" name="essb_options[profilecustomize_hover_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="profilecustomize_hover_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Icon', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="profilecustomize_icon_all">
						<label class="plc-color-btn" data-key="profilecustomize_icon_all"><input type="color" class="plc-color" data-key="profilecustomize_icon_all"></label>
						<input type="text" name="essb_options[profilecustomize_icon_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="profilecustomize_icon_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>
				<div class="plc-field">
					<label class="plc-field-label"><?php esc_html_e('Icon hover', 'essb'); ?></label>
					<div class="essb-cd-color" data-key="profilecustomize_icon_hover_all">
						<label class="plc-color-btn" data-key="profilecustomize_icon_hover_all"><input type="color" class="plc-color" data-key="profilecustomize_icon_hover_all"></label>
						<input type="text" name="essb_options[profilecustomize_icon_hover_all]" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="profilecustomize_icon_hover_all" maxlength="7" placeholder="#rrggbb">
					</div>
				</div>

			</div>
		</div>

		<div class="plc-toolbar">
			<input type="text" class="input-element essb-cd-input plc-search" id="plcSearch" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
			<span class="essb-ui-badge essb-ui-badge-sm" id="plcCount">0</span>
			<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary" id="plcChanged">0</span>
			<label class="essb-ui-switch essb-ui-switch-lg" style="margin-left:auto;"><input type="checkbox" id="plcPreviewHover"><span><?php esc_html_e('Preview hover', 'essb'); ?></span></label>
			<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-sm" id="plcResetAll"><?php esc_html_e('Reset all per-network', 'essb'); ?></button>
		</div>

		<div class="plc-grid" id="plcGrid"></div>
	</div>
	<script>
		window.PLC_NETWORKS = <?php echo wp_json_encode(array_map(function ($key, $name) {
			return array('key' => $key, 'name' => $name);
		}, array_keys($networks), array_values($networks))); ?>;
		window.PLC_COMMITTED = <?php echo wp_json_encode($committed); ?>;
	</script>
	<?php
	$html = ob_get_clean();

	ESSBOptionsStructureHelper::field_html($tab_id, $menu_id, $html);
}

function essb3_draw_sharebuttons_customization($tab_id, $menu_id) {
	$network_list = essb_available_social_networks();

	$networks = array();
	foreach ($network_list as $key => $object) {
		$networks[$key] = isset($object['name']) ? $object['name'] : $key;
	}

	$committed = array();
	$scalar_keys = array(
		'customizer_is_active',
		'customizer_totalbgcolor', 'customizer_totalnobgcolor', 'customizer_totalcolor',
		'customizer_totalfontsize', 'customizer_totalfontsize_after', 'customizer_totalfontsize_beforeafter',
		'customizer_bgcolor', 'customizer_textcolor', 'customizer_hovercolor', 'customizer_hovertextcolor',
		'customizer_remove_bg_hover_effects',
		'customizer_iconsize', 'customizer_icon_block_size', 'customizer_namesize', 'customizer_namebold', 'customizer_nameupper',
		'customizer_network_is_active'
	);
	foreach ($scalar_keys as $k) {
		$committed[$k] = essb_option_value($k);
	}
	foreach (array_keys($networks) as $network) {
		$committed['customizer_' . $network . '_bgcolor'] = essb_option_value('customizer_' . $network . '_bgcolor');
		$committed['customizer_' . $network . '_textcolor'] = essb_option_value('customizer_' . $network . '_textcolor');
		$committed['customizer_' . $network . '_hovercolor'] = essb_option_value('customizer_' . $network . '_hovercolor');
		$committed['customizer_' . $network . '_hovertextcolor'] = essb_option_value('customizer_' . $network . '_hovertextcolor');
	}

	ob_start();
	?>
	<div class="sbc-wrap" id="sbcWrap">
		<div class="sbc-toolbar">
			<input type="text" class="input-element essb-cd-input sbc-search" id="sbcSearch" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
			<span class="essb-ui-badge essb-ui-badge-sm" id="sbcCount">0</span>
			<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary" id="sbcChanged">0</span>
			<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-sm" id="sbcResetAll"><?php esc_html_e('Reset all per-network', 'essb'); ?></button>
		</div>

		<div class="sbc-grid" id="sbcGrid"></div>
	</div>
	<script>
		window.SBC_NETWORKS = <?php echo wp_json_encode(array_map(function ($key, $name) {
			return array('key' => $key, 'name' => $name);
		}, array_keys($networks), array_values($networks))); ?>;
		window.SBC_COMMITTED = <?php echo wp_json_encode($committed); ?>;
	</script>
	<?php
	$html = ob_get_clean();

	ESSBOptionsStructureHelper::field_html($tab_id, $menu_id, $html);
}

function essb3_draw_ctt_customization($tab_id, $menu_id) {
	$color_keys = array('customize_cct_bg', 'customize_cct_bg_hover', 'customize_cct_color', 'customize_cct_color_hover');
	$committed = array();
	foreach ($color_keys as $k) {
		$committed[$k] = essb_option_value($k);
	}
	$committed['customizer_cct_border'] = essb_option_value('customizer_cct_border');
	$committed['customizer_cct_border_hover'] = essb_option_value('customizer_cct_border_hover');
	$committed['customizer_cct_border_radius'] = essb_option_value('customizer_cct_border_radius');
	$committed['customizer_cct_padding'] = essb_option_value('customizer_cct_padding');
	$committed['customizer_cct_align'] = essb_option_value('customizer_cct_align');
	$committed['customizer_cct_fontsize'] = essb_option_value('customizer_cct_fontsize');

	$parse_border = function ($str) {
		$t = array_values(array_filter(preg_split('/\s+/', trim((string)$str)), 'strlen'));
		return array(
			'size' => isset($t[0]) ? $t[0] : '',
			'style' => isset($t[1]) ? $t[1] : '',
			'color' => isset($t[2]) ? $t[2] : '',
		);
	};
	$b = $parse_border($committed['customizer_cct_border']);
	$bh = $parse_border($committed['customizer_cct_border_hover']);

	$expand = function ($str) {
		$t = array_values(array_filter(preg_split('/\s+/', trim((string)$str)), 'strlen'));
		if (count($t) === 0) return array('', '', '', '');
		if (count($t) === 1) return array($t[0], $t[0], $t[0], $t[0]);
		if (count($t) === 2) return array($t[0], $t[1], $t[0], $t[1]);
		if (count($t) === 3) return array($t[0], $t[1], $t[2], $t[1]);
		return array($t[0], $t[1], $t[2], $t[3]);
	};
	$r = $expand($committed['customizer_cct_border_radius']);
	$p = $expand($committed['customizer_cct_padding']);

	$radius_all = ($r[0] !== '' && $r[0] === $r[1] && $r[1] === $r[2] && $r[2] === $r[3]) ? $r[0] : '';
	$padding_all = ($p[0] !== '' && $p[0] === $p[1] && $p[1] === $p[2] && $p[2] === $p[3]) ? $p[0] : '';

	ob_start();
	?>
	<div class="cct-wrap" id="cctWrap">
		<div class="cct-section">
			<div class="cct-section-title"><?php esc_html_e('Colors', 'essb'); ?></div>
			<div class="cct-card">
				<div class="cct-grid" style="grid-template-columns: repeat(4, 1fr);">
					<?php
					$color_labels = array(
						'customize_cct_bg' => esc_html__('Background color', 'essb'),
						'customize_cct_bg_hover' => esc_html__('Background color on hover', 'essb'),
						'customize_cct_color' => esc_html__('Text color', 'essb'),
						'customize_cct_color_hover' => esc_html__('Text color on hover', 'essb'),
					);
					foreach ($color_labels as $key => $label) {
						$val = isset($committed[$key]) ? $committed[$key] : '';
						?>
						<div class="cct-field">
							<label><?php echo $label; ?></label>
							<div class="cct-color" data-key="<?php echo esc_attr($key); ?>">
								<label class="cct-color-btn" data-key="<?php echo esc_attr($key); ?>" style="background: <?php echo esc_attr($val ? $val : '#f1f1f4'); ?>;"><input type="color" class="cct-color-input" data-key="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($val ? $val : '#9ca3af'); ?>"></label>
								<input type="text" name="essb_options[<?php echo esc_attr($key); ?>]" class="cct-hex input-element" data-key="<?php echo esc_attr($key); ?>" maxlength="7" placeholder="#rrggbb" value="<?php echo esc_attr($val); ?>">
							</div>
						</div>
						<?php
					}
					?>
				</div>
			</div>
		</div>

		<div class="cct-section">
			<div class="cct-section-title"><?php esc_html_e('Borders', 'essb'); ?></div>
			<div class="cct-card" style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
				<div>
					<div style="font-size:12px; font-weight:700; color:#172153; margin-bottom:8px;"><?php esc_html_e('Border', 'essb'); ?></div>
					<div class="cct-split-3">
						<div class="cct-field">
							<label><?php esc_html_e('Size', 'essb'); ?></label>
							<input type="text" class="cct-text input-element" data-split="border" data-part="size" placeholder="1px" value="<?php echo esc_attr($b['size']); ?>">
						</div>
						<div class="cct-field">
							<label><?php esc_html_e('Style', 'essb'); ?></label>
							<select class="cct-select input-element" data-split="border" data-part="style">
								<option value="" <?php selected($b['style'], ''); ?>><?php esc_html_e('Default', 'essb'); ?></option>
								<option value="solid" <?php selected($b['style'], 'solid'); ?>>solid</option>
								<option value="dashed" <?php selected($b['style'], 'dashed'); ?>>dashed</option>
								<option value="dotted" <?php selected($b['style'], 'dotted'); ?>>dotted</option>
								<option value="double" <?php selected($b['style'], 'double'); ?>>double</option>
								<option value="none" <?php selected($b['style'], 'none'); ?>>none</option>
							</select>
						</div>
						<div class="cct-field">
							<label><?php esc_html_e('Color', 'essb'); ?></label>
							<div class="cct-color" data-key="border_color">
								<label class="cct-color-btn" data-key="border_color" style="background: <?php echo esc_attr($b['color'] ? $b['color'] : '#f1f1f4'); ?>;"><input type="color" class="cct-color-input" data-key="border_color" value="<?php echo esc_attr($b['color'] ? $b['color'] : '#9ca3af'); ?>"></label>
								<input type="text" class="cct-hex input-element" data-key="border_color" maxlength="7" placeholder="#rrggbb" value="<?php echo esc_attr($b['color']); ?>">
							</div>
						</div>
					</div>
					<input type="hidden" id="cct_hidden_customizer_cct_border" name="essb_options[customizer_cct_border]" value="<?php echo esc_attr($committed['customizer_cct_border']); ?>">
				</div>
				<div>
					<div style="font-size:12px; font-weight:700; color:#172153; margin-bottom:8px;"><?php esc_html_e('Border on hover', 'essb'); ?></div>
					<div class="cct-split-3">
						<div class="cct-field">
							<label><?php esc_html_e('Size', 'essb'); ?></label>
							<input type="text" class="cct-text input-element" data-split="border_hover" data-part="size" placeholder="1px" value="<?php echo esc_attr($bh['size']); ?>">
						</div>
						<div class="cct-field">
							<label><?php esc_html_e('Style', 'essb'); ?></label>
							<select class="cct-select input-element" data-split="border_hover" data-part="style">
								<option value="" <?php selected($bh['style'], ''); ?>><?php esc_html_e('Default', 'essb'); ?></option>
								<option value="solid" <?php selected($bh['style'], 'solid'); ?>>solid</option>
								<option value="dashed" <?php selected($bh['style'], 'dashed'); ?>>dashed</option>
								<option value="dotted" <?php selected($bh['style'], 'dotted'); ?>>dotted</option>
								<option value="double" <?php selected($bh['style'], 'double'); ?>>double</option>
								<option value="none" <?php selected($bh['style'], 'none'); ?>>none</option>
							</select>
						</div>
						<div class="cct-field">
							<label><?php esc_html_e('Color', 'essb'); ?></label>
							<div class="cct-color" data-key="border_hover_color">
								<label class="cct-color-btn" data-key="border_hover_color" style="background: <?php echo esc_attr($bh['color'] ? $bh['color'] : '#f1f1f4'); ?>;"><input type="color" class="cct-color-input" data-key="border_hover_color" value="<?php echo esc_attr($bh['color'] ? $bh['color'] : '#9ca3af'); ?>"></label>
								<input type="text" class="cct-hex input-element" data-key="border_hover_color" maxlength="7" placeholder="#rrggbb" value="<?php echo esc_attr($bh['color']); ?>">
							</div>
						</div>
					</div>
					<input type="hidden" id="cct_hidden_customizer_cct_border_hover" name="essb_options[customizer_cct_border_hover]" value="<?php echo esc_attr($committed['customizer_cct_border_hover']); ?>">
				</div>
			</div>
		</div>

		<div class="cct-section">
			<div class="cct-section-title"><?php esc_html_e('Border radius', 'essb'); ?></div>
			<div class="cct-card">
				<div style="display:grid; grid-template-columns: repeat(5, 1fr); gap:8px;">
					<div class="cct-field">
						<label><?php esc_html_e('All corners', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-all="radius" placeholder="4px" value="<?php echo esc_attr($radius_all); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Top-left', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="radius" data-part="tl" placeholder="4px" value="<?php echo esc_attr($r[0]); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Top-right', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="radius" data-part="tr" placeholder="4px" value="<?php echo esc_attr($r[1]); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Bottom-right', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="radius" data-part="br" placeholder="4px" value="<?php echo esc_attr($r[2]); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Bottom-left', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="radius" data-part="bl" placeholder="4px" value="<?php echo esc_attr($r[3]); ?>">
					</div>
				</div>
				<input type="hidden" id="cct_hidden_customizer_cct_border_radius" name="essb_options[customizer_cct_border_radius]" value="<?php echo esc_attr($committed['customizer_cct_border_radius']); ?>">
			</div>
		</div>

		<div class="cct-section">
			<div class="cct-section-title"><?php esc_html_e('Padding', 'essb'); ?></div>
			<div class="cct-card">
				<div style="display:grid; grid-template-columns: repeat(5, 1fr); gap:8px;">
					<div class="cct-field">
						<label><?php esc_html_e('All sides', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-all="padding" placeholder="20px" value="<?php echo esc_attr($padding_all); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Top', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="padding" data-part="t" placeholder="25px" value="<?php echo esc_attr($p[0]); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Right', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="padding" data-part="r" placeholder="20px" value="<?php echo esc_attr($p[1]); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Bottom', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="padding" data-part="b" placeholder="10px" value="<?php echo esc_attr($p[2]); ?>">
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Left', 'essb'); ?></label>
						<input type="text" class="cct-text input-element" data-split="padding" data-part="l" placeholder="20px" value="<?php echo esc_attr($p[3]); ?>">
					</div>
				</div>
				<input type="hidden" id="cct_hidden_customizer_cct_padding" name="essb_options[customizer_cct_padding]" value="<?php echo esc_attr($committed['customizer_cct_padding']); ?>">
			</div>
		</div>

		<div class="cct-section">
			<div class="cct-section-title"><?php esc_html_e('Typography & alignment', 'essb'); ?></div>
			<div class="cct-card">
				<div class="cct-grid">
					<div class="cct-field">
						<label><?php esc_html_e('Alignment', 'essb'); ?></label>
						<select class="cct-select input-element" name="essb_options[customizer_cct_align]" data-key="customizer_cct_align">
							<option value="" <?php selected($committed['customizer_cct_align'], ''); ?>><?php esc_html_e('Default', 'essb'); ?></option>
							<option value="left" <?php selected($committed['customizer_cct_align'], 'left'); ?>><?php esc_html_e('Left', 'essb'); ?></option>
							<option value="center" <?php selected($committed['customizer_cct_align'], 'center'); ?>><?php esc_html_e('Center', 'essb'); ?></option>
							<option value="right" <?php selected($committed['customizer_cct_align'], 'right'); ?>><?php esc_html_e('Right', 'essb'); ?></option>
						</select>
					</div>
					<div class="cct-field">
						<label><?php esc_html_e('Font size (quote)', 'essb'); ?></label>
						<input type="text" name="essb_options[customizer_cct_fontsize]" class="cct-text input-element" data-key="customizer_cct_fontsize" placeholder="20px" value="<?php echo esc_attr($committed['customizer_cct_fontsize']); ?>">
					</div>
				</div>
			</div>
		</div>

		<div class="cct-section">
			<div class="cct-section-title"><?php esc_html_e('Live preview', 'essb'); ?></div>
			<div class="cct-preview-stage" id="cctPreviewStage">
				<div class="essb-ctt essb-ctt-user" id="cctPreviewBox">
					<span class="essb-ctt-quote">Add an awesome looking click to share boxes from the best social sharing plugin for #WordPress</span>
					<span class="essb-ctt-button"><span>Click to Share</span><i class="essb_svg_icon_twitter"><svg class="essb-svg-icon essb-svg-icon-twitter_x" aria-hidden="true" role="img" focusable="false" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg></i></span>
				</div>
			</div>
			<div class="cct-preview-inline" id="cctPreviewInline">
				Easy Social Share Buttons for WordPress is developed to be a <a class="essb-ctt-inline" id="cctPreviewInlineBox">complete social media plugin<span class="essb-ctt-button"><i class="essb_svg_icon_twitter"><svg class="essb-svg-icon essb-svg-icon-twitter_x" aria-hidden="true" role="img" focusable="false" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg></i></span></a>. It's build to increase your share, grow your followers, get new subscribers, or communicate with your visitors and customers.
			</div>
			<div style="margin-top:10px; text-align:center; font-size:12px; color:#8a94b5;">
				<?php esc_html_e('Hover over the preview to see the hover state.', 'essb'); ?>
			</div>
		</div>
	</div>
	<script>
		window.CCT_COMMITTED = <?php echo wp_json_encode($committed); ?>;
	</script>
	<?php
	$html = ob_get_clean();

	ESSBOptionsStructureHelper::field_html($tab_id, $menu_id, $html);
}

function essb3_mytemplate_color($key) {
	$value = essb_option_value($key);
	$has_value = (is_string($value) && $value !== '');
	?>
	<div class="mt-color" data-key="<?php echo esc_attr($key); ?>">
		<label class="mt-color-btn" data-key="<?php echo esc_attr($key); ?>" style="background: <?php echo $has_value ? esc_attr($value) : '#f1f1f4'; ?>;">
			<input type="color" class="mt-color-input" data-key="<?php echo esc_attr($key); ?>" value="<?php echo $has_value ? esc_attr($value) : '#9ca3af'; ?>">
		</label>
		<input type="text" name="essb_options[<?php echo esc_attr($key); ?>]" class="mt-hex input-element" data-key="<?php echo esc_attr($key); ?>" maxlength="7" placeholder="#rrggbb" value="<?php echo esc_attr($value); ?>">
	</div>
	<?php
}

function essb3_mytemplate_color_field($key, $label) {
	?>
	<div class="mt-field">
		<label><?php esc_html_e($label, 'essb'); ?></label>
		<?php essb3_mytemplate_color($key); ?>
	</div>
	<?php
}

function essb3_mytemplate_network_row($network, $suffix, $label) {
	$key = 'mytemplate_' . $network . '_' . $suffix;
	$value = essb_option_value($key);
	$has_value = (is_string($value) && $value !== '');
	?>
	<div class="mt-net-row">
		<label><?php esc_html_e($label, 'essb'); ?></label>
		<div class="mt-color" data-key="<?php echo esc_attr($key); ?>">
			<label class="mt-color-btn" data-key="<?php echo esc_attr($key); ?>" style="background: <?php echo $has_value ? esc_attr($value) : '#f1f1f4'; ?>;">
				<input type="color" class="mt-color-input" data-key="<?php echo esc_attr($key); ?>" value="<?php echo $has_value ? esc_attr($value) : '#9ca3af'; ?>">
			</label>
			<input type="text" name="essb_options[<?php echo esc_attr($key); ?>]" class="mt-hex input-element" data-key="<?php echo esc_attr($key); ?>" maxlength="7" placeholder="#rrggbb" value="<?php echo esc_attr($value); ?>">
		</div>
	</div>
	<?php
}

function essb3_mytemplate_text_field($key, $label, $placeholder = '', $desc = '') {
	$value = essb_option_value($key);
	?>
	<div class="mt-field">
		<label><?php esc_html_e($label, 'essb'); ?></label>
		<input type="text" name="essb_options[<?php echo esc_attr($key); ?>]" class="mt-text input-element" data-key="<?php echo esc_attr($key); ?>" placeholder="<?php echo esc_attr($placeholder); ?>" value="<?php echo esc_attr($value); ?>">
		<?php if ($desc !== '') { ?><span class="mt-desc"><?php esc_html_e($desc, 'essb'); ?></span><?php } ?>
	</div>
	<?php
}

function essb3_mytemplate_select_field($key, $label, $options) {
	$value = essb_option_value($key);
	?>
	<div class="mt-field">
		<label><?php esc_html_e($label, 'essb'); ?></label>
		<select name="essb_options[<?php echo esc_attr($key); ?>]" class="mt-select input-element" data-key="<?php echo esc_attr($key); ?>">
			<?php foreach ($options as $option_key => $option_label) { ?>
				<option value="<?php echo esc_attr($option_key); ?>" <?php selected($value, $option_key); ?>><?php esc_html_e($option_label, 'essb'); ?></option>
			<?php } ?>
		</select>
	</div>
	<?php
}

function essb3_mytemplate_switch_field($key, $label) {
	$checked = essb_option_bool_value($key);
	?>
	<div class="mt-switch-row">
		<label class="mt-switch-label"><?php esc_html_e($label, 'essb'); ?></label>
		<span class="essb-ui-switch essb-ui-switch-lg essb-ui"><input type="hidden" name="essb_options[<?php echo esc_attr($key); ?>]" value=""><input type="checkbox" name="essb_options[<?php echo esc_attr($key); ?>]" value="true" data-key="<?php echo esc_attr($key); ?>" <?php echo $checked ? 'checked="checked"' : ''; ?>></span>
	</div>
	<?php
}

function essb3_draw_mytemplate_customization($tab_id, $menu_id) {
	$network_list = essb_available_social_networks();
	$networks = array();
	foreach ($network_list as $key => $object) {
		$name = essb_option_value('user_network_name_' . $key);
		if ($name === '') {
			$name = isset($object['name']) ? $object['name'] : $key;
		}
		$networks[$key] = $name;
	}

	$preview_keys = essb_option_value('networks');
	if (!is_array($preview_keys) || empty($preview_keys)) {
		$preview_keys = array('facebook', 'twitter', 'linkedin', 'pinterest', 'whatsapp', 'telegram', 'reddit', 'tumblr', 'vk', 'mail');
	}
	$preview_keys = array_values(array_filter($preview_keys, function ($key) use ($networks) {
		return isset($networks[$key]);
	}));
	if (empty($preview_keys)) {
		$preview_keys = array('facebook', 'twitter', 'linkedin', 'pinterest', 'whatsapp', 'telegram', 'reddit', 'tumblr', 'vk', 'mail');
	}

	// Use the same network names as the front-end (custom names override the defaults)
	$preview_networks = array();
	foreach ($preview_keys as $key) {
		$preview_networks[] = array('key' => $key, 'name' => $networks[$key]);
	}

	$padding = (string) essb_option_value('mytemplate_padding');
	$padding_parts = array_values(array_filter(preg_split('/\s+/', trim($padding)), 'strlen'));
	$padding_t = isset($padding_parts[0]) ? $padding_parts[0] : '';
	$padding_r = isset($padding_parts[1]) ? $padding_parts[1] : $padding_t;
	$padding_b = isset($padding_parts[2]) ? $padding_parts[2] : $padding_t;
	$padding_l = isset($padding_parts[3]) ? $padding_parts[3] : $padding_r;
	$padding_all = ($padding_t !== '' && $padding_t === $padding_r && $padding_r === $padding_b && $padding_b === $padding_l) ? $padding_t : '';

	if (!class_exists('ESSB_SVG_Icons')) {
		include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
	}

	ob_start();
	?>
	<div class="mt-wrap" id="mtWrap">

		<div class="mt-section">
			<div class="mt-section-title"><?php esc_html_e('Total counter style', 'essb'); ?></div>
			<div class="mt-card">
				<div class="mt-grid mt-grid-3">
					<?php
					essb3_mytemplate_color_field('mytemplate_totalbgcolor', 'Background color');
					essb3_mytemplate_color_field('mytemplate_totalcolor', 'Text color');
					essb3_mytemplate_color_field('mytemplate_totalfontsize_after_color', 'Shares text color');
					?>
				</div>
				<div class="mt-grid mt-grid-3 mt-mt">
					<?php
					essb3_mytemplate_text_field('mytemplate_totalfontsize', 'Total counter big style font-size', '21px');
					essb3_mytemplate_text_field('mytemplate_totalfontsize_after', 'Shares text font-size', '10px');
					essb3_mytemplate_text_field('mytemplate_totalfontsize_beforeafter', 'Total counter text font-size', '14px');
					?>
				</div>
				<?php essb3_mytemplate_switch_field('mytemplate_totalnobgcolor', 'Remove background color'); ?>
			</div>
		</div>

		<div class="mt-section">
			<div class="mt-section-title"><?php esc_html_e('Button style', 'essb'); ?></div>
			<div class="mt-card">
				<div class="mt-grid mt-grid-3">
					<?php
					essb3_mytemplate_text_field('mytemplate_iconsize', 'Icon size', '18', 'Numeric value, default 18');
					essb3_mytemplate_text_field('mytemplate_iconspace', 'Icon gutter', '9', 'Default 9 — reflects over the button size');
					essb3_mytemplate_text_field('mytemplate_namesize', 'Network name font size', '16px');
					?>
				</div>

				<div class="mt-subhead"><?php esc_html_e('Button padding', 'essb'); ?></div>
				<div class="mt-padding">
					<div class="mt-field">
						<label><?php esc_html_e('All sides', 'essb'); ?></label>
						<input type="text" class="mt-text input-element" data-all="padding" placeholder="10px" value="<?php echo esc_attr($padding_all); ?>">
					</div>
					<div class="mt-field">
						<label><?php esc_html_e('Top', 'essb'); ?></label>
						<input type="text" class="mt-text input-element" data-split="padding" data-part="t" placeholder="10px" value="<?php echo esc_attr($padding_t); ?>">
					</div>
					<div class="mt-field">
						<label><?php esc_html_e('Right', 'essb'); ?></label>
						<input type="text" class="mt-text input-element" data-split="padding" data-part="r" placeholder="10px" value="<?php echo esc_attr($padding_r); ?>">
					</div>
					<div class="mt-field">
						<label><?php esc_html_e('Bottom', 'essb'); ?></label>
						<input type="text" class="mt-text input-element" data-split="padding" data-part="b" placeholder="10px" value="<?php echo esc_attr($padding_b); ?>">
					</div>
					<div class="mt-field">
						<label><?php esc_html_e('Left', 'essb'); ?></label>
						<input type="text" class="mt-text input-element" data-split="padding" data-part="l" placeholder="10px" value="<?php echo esc_attr($padding_l); ?>">
					</div>
				</div>
				<input type="hidden" id="mt_hidden_padding" class="mt-padding-value" data-key="mytemplate_padding" name="essb_options[mytemplate_padding]" value="<?php echo esc_attr($padding); ?>">

				<div class="mt-grid mt-grid-3 mt-mt">
					<?php
					essb3_mytemplate_select_field('mytemplate_nameweight', 'Network name text style', array('' => 'Default', 'normal' => 'Normal', 'bold' => 'Bold', 'italic' => 'Italic'));
					essb3_mytemplate_select_field('mytemplate_texttrans', 'Network name text transform', array('' => 'Default', 'uppercase' => 'Uppercase', 'capitalaize' => 'Capitalize'));
					essb3_mytemplate_select_field('mytemplate_shape', 'Button shape', array('' => 'Default', 'rounded' => 'Round Edges', 'round' => 'Round', 'leaf' => 'Leaf'));
					?>
				</div>

				<div class="mt-grid mt-grid-3 mt-mt">
					<?php
					essb3_mytemplate_select_field('mytemplate_effect', 'Button effect', array('' => 'No effect', 'flat' => 'Flat style', 'shadow' => 'Drop shadow', 'glow' => 'Glow effect'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Button effect color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_effect_color'); ?>
					</div>
					<?php
					essb3_mytemplate_select_field('mytemplate_effect_strength', 'Button effect strength', array('' => 'Default', 'small' => 'Small', 'medium' => 'Medium', 'large' => 'Large', 'xlarge' => 'Extra Large'));
					?>
				</div>
			</div>
		</div>

		<div class="mt-section">
			<div class="mt-section-title"><?php esc_html_e('Default color set', 'essb'); ?></div>
			<div class="mt-card">
				<div class="mt-grid mt-grid-2">
					<?php
					essb3_mytemplate_select_field('mytemplate_default_color', 'Background color', array('' => 'Network default/custom color', 'white' => 'White', 'dark' => 'Dark', 'custom' => 'Custom Color'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Custom background color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_default_color_custom'); ?>
					</div>
					<?php
					essb3_mytemplate_select_field('mytemplate_default_textcolor', 'Text/Icon color', array('' => 'White', 'network' => 'Network default/custom color', 'dark' => 'Dark', 'custom' => 'Custom Color'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Custom Text/Icon color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_default_textcolor_custom'); ?>
					</div>
				</div>

				<div class="mt-subhead"><?php esc_html_e('Outline', 'essb'); ?></div>
				<div class="mt-grid mt-grid-3">
					<?php
					essb3_mytemplate_text_field('mytemplate_default_outlinesize', 'Outline size', '2', 'Numeric value (1, 2, 3 …)');
					essb3_mytemplate_select_field('mytemplate_default_outlinecolor', 'Outline color', array('' => 'Network default/custom color', 'white' => 'White', 'dark' => 'Dark', 'custom' => 'Custom Color'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Custom outline color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_default_outlinecolor_custom'); ?>
					</div>
				</div>
			</div>
		</div>

		<div class="mt-section">
			<div class="mt-section-title"><?php esc_html_e('On hover color set', 'essb'); ?></div>
			<div class="mt-card">
				<div class="mt-grid mt-grid-2">
					<?php
					essb3_mytemplate_select_field('mytemplate_hover_color', 'Background color', array('' => 'Generate automatically', 'network' => 'Network default/custom color', 'white' => 'White', 'dark' => 'Dark', 'custom' => 'Custom Color'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Custom background color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_hover_color_custom'); ?>
					</div>
					<?php
					essb3_mytemplate_select_field('mytemplate_hover_textcolor', 'Text/Icon color', array('' => 'White', 'network' => 'Network default/custom color', 'dark' => 'Dark', 'custom' => 'Custom Color'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Custom Text/Icon color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_hover_textcolor_custom'); ?>
					</div>
				</div>

				<div class="mt-subhead"><?php esc_html_e('Outline on hover', 'essb'); ?></div>
				<div class="mt-grid mt-grid-3">
					<?php
					essb3_mytemplate_text_field('mytemplate_hover_outlinesize', 'Outline size', '2');
					essb3_mytemplate_select_field('mytemplate_hover_outlinecolor', 'Outline color', array('' => 'Network default/custom color', 'white' => 'White', 'dark' => 'Dark', 'custom' => 'Custom Color'));
					?>
					<div class="mt-field">
						<label><?php esc_html_e('Custom outline color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_hover_outlinecolor_custom'); ?>
					</div>
				</div>

				<div class="mt-subhead"><?php esc_html_e('Hover behaviour', 'essb'); ?></div>
				<div class="mt-grid mt-grid-3">
					<?php
					essb3_mytemplate_select_field('mytemplate_hover_color_effect', 'Button hover effect', array('' => 'No hover animation', 'shiny' => 'Shiny'));
					essb3_mytemplate_select_field('mytemplate_hover_shape', 'Button shape', array('' => 'Default', 'square' => 'Rectangle', 'rounded' => 'Round Edges', 'round' => 'Round', 'leaf' => 'Leaf'));
					essb3_mytemplate_select_field('mytemplate_hover_effect', 'Button effect', array('' => 'Default', 'no' => 'No effect', 'flat' => 'Flat style', 'shadow' => 'Drop shadow', 'glow' => 'Glow effect'));
					?>
				</div>

				<div class="mt-grid mt-grid-3 mt-mt">
					<div class="mt-field">
						<label><?php esc_html_e('Button effect color', 'essb'); ?></label>
						<?php essb3_mytemplate_color('mytemplate_hover_effect_color'); ?>
					</div>
					<?php
					essb3_mytemplate_select_field('mytemplate_hover_effect_strength', 'Button effect strength', array('' => 'Default', 'small' => 'Small', 'medium' => 'Medium', 'large' => 'Large', 'xlarge' => 'Extra Large'));
					?>
				</div>
			</div>
		</div>

		<div class="mt-section">
			<div class="mt-section-title"><?php esc_html_e('Live preview', 'essb'); ?></div>
			<div class="mt-card">
				<div class="mt-preview-stage">
					<ul class="mt-preview-list" id="mtPreviewList"></ul>
				</div>
			</div>
		</div>

		<div class="mt-section">
			<div class="mt-section-title"><?php esc_html_e('Colors by social networks', 'essb'); ?></div>
			<div class="mt-card">
				<?php essb3_mytemplate_switch_field('mytemplate_network_is_active', 'Use per-network colors'); ?>
				<div class="mt-network-area<?php echo essb_option_bool_value('mytemplate_network_is_active') ? '' : ' mt-hidden'; ?>" id="mtNetworkArea">
					<div class="mt-network-toolbar">
						<input type="text" class="input-element essb-cd-input mt-search" id="mtNetworkSearch" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
						<span class="essb-ui-badge essb-ui-badge-sm" id="mtNetworkCount">0</span>
						<span class="essb-ui-badge essb-ui-badge-sm essb-ui-badge-primary" id="mtNetworkChanged">0</span>
						<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-sm" id="mtNetworkResetAll"><?php esc_html_e('Reset all per-network', 'essb'); ?></button>
					</div>
					<div class="mt-network-grid" id="mtNetworkGrid">
						<?php foreach ($networks as $key => $name) { ?>
							<div class="mt-net-card" data-key="<?php echo esc_attr($key); ?>">
								<div class="mt-net-preview">
									<span class="mt-net-icon"><?php
										$icon_key = $key;
										if ($icon_key == 'twitter') { $icon_key = 'twitter-x'; }
										$svg_icon = class_exists('ESSB_SVG_Icons') ? ESSB_SVG_Icons::get_icon($icon_key) : '';
										echo $svg_icon ? $svg_icon : esc_html($name);
									?></span>
									<span class="mt-net-name"><?php echo esc_html($name); ?></span>
								</div>
								<div class="mt-net-fields">
									<?php
									essb3_mytemplate_network_row($key, 'bgcolor', 'Bg');
									essb3_mytemplate_network_row($key, 'textcolor', 'Text');
									essb3_mytemplate_network_row($key, 'hovercolor', 'Hover bg');
									essb3_mytemplate_network_row($key, 'hovertextcolor', 'Hover txt');
									?>
								</div>
								<div class="mt-net-actions">
									<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-xs mt-reset" data-reset="<?php echo esc_attr($key); ?>"><?php esc_html_e('Reset', 'essb'); ?></button>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>

	</div>
	<script>
		window.MT_PREVIEW_NETWORKS = <?php echo wp_json_encode($preview_networks); ?>;
	</script>
	<?php
	$html = ob_get_clean();

	ESSBOptionsStructureHelper::field_html($tab_id, $menu_id, $html);
}

/** Custom Share Buttons Template Code */
essb_heading_with_related_section_open('style', 'my-template', esc_html__('Custom Template', 'essb'), '<i class="fa fa-paint-brush"></i>', '');
ESSBOptionsStructureHelper::field_switch('style', 'my-template', 'mytemplate_activate', esc_html__('Use my template', 'essb'), esc_html__('Set this option to Yes if you wish to use the custom template you made', 'essb'), '', esc_html__('Yes', 'essb'), esc_html__('No', 'essb'), '', '', 'true');

if (essb_option_bool_value('mytemplate_activate')) {
    essb3_draw_mytemplate_customization('style', 'my-template');
}

essb_heading_with_related_section_close('style', 'my-template');
