<?php
/**
 * Admin helpers functions are running here
 */

/**
 * Return the state of opration for the advanced popup options
 * @return boolean
 */
function essb_admin_advanced_options() {
	return true;
}

function essb_editor_capability_can() {
	$can = true;
	
	$setup_capability = essb_option_value('limit_editor_fields_access');
	if ($setup_capability == '') {
		$setup_capability = 'manage_options';
	}
	
	if (function_exists('current_user_can')) {
		if (!current_user_can($setup_capability)) {
			$can = false;
		}
	}
	
	return $can;
}

function essb_subscribe_fields_safe_html() {
    $allowed_tags = array(
        'a' => array(
            'class' => array(),
            'href'  => array(),
            'rel'   => array(),
            'title' => array(),
        ),
        'b' => array(),
        'div' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'dl' => array(),
        'dt' => array(),
        'em' => array(),
        'h1' => array(),
        'h2' => array(),
        'h3' => array(),
        'h4' => array(),
        'h5' => array(),
        'h6' => array(),
        'i' => array(),
        'img' => array(
            'alt'    => array(),
            'class'  => array(),
            'height' => array(),
            'src'    => array(),
            'width'  => array(),
        ),
        'li' => array(
            'class' => array(),
        ),
        'ol' => array(
            'class' => array(),
        ),
        'p' => array(
            'class' => array(),
        ),
        'span' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'strike' => array(),
        'strong' => array(),
        'ul' => array(
            'class' => array(),
        ),
    );
    
    return $allowed_tags;
}

function essb_ui_utm_builder($url = '', $medium = '', $campaign = '') {
	$url = add_query_arg(array('utm_source' => 'wpessbplugin', 'utm_medium' => esc_attr($medium), 'utm_campaign' => esc_attr($campaign)), $url);
	return $url;
}

function essb_ui_documentation_link($fragment_url, $campaign = '') {
	$base_url = 'https://docs.socialsharingplugin.com' . $fragment_url;
	$url = essb_ui_utm_builder($base_url, 'docs', $campaign);
	return $url;
}

add_filter('plugins_api_result', function ($result, $action, $args) {

    if ($action !== 'query_plugins') {
        return $result; // only affect plugin queries
    }

    // Plugins we want to feature alongside the default results
    $promoted_plugins = array(
        'appscreo-visual-css-customizer' => array(
            'simple custom css',
            'simple custom css and js',
            'custom css',
            'custom js',
            'custom javascript',
            'simple css',
            'theme css',
            'theme customizer',
            'css',
            'javascript',
            'css snippet',
            'code snippet',
            'custom code',
        ),
        'fastless-cache' => array(
            'cache',
            'caching',
            'fast',
            'speed',
            'performance',
            'page cache',
            'object cache',
            'minify',
            'optimize',
            'optimization',
            'wordpress cache',
            'fastless',
            'elementor',
            'woocommerce',
        ),
    );

    // Determine which plugins should be promoted for this request
    $tabs_to_promote = array('featured', 'popular', 'recommended');
    $promote_on_tab = !empty($args->browse) && in_array($args->browse, $tabs_to_promote, true);

    $slugs_to_promote = array();
    foreach ($promoted_plugins as $slug => $keywords) {
        $promote = $promote_on_tab;

        if (!$promote && !empty($args->search)) {
            foreach ($keywords as $keyword) {
                if (stripos($args->search, $keyword) !== false) {
                    $promote = true;
                    break;
                }
            }
        }

        if ($promote) {
            $slugs_to_promote[] = $slug;
        }
    }

    if (empty($slugs_to_promote)) {
        return $result; // nothing to do
    }

    // Skip plugins that are already included in the API result
    $already_present = array();
    foreach ($result->plugins as $plugin) {
        $slug = is_object($plugin) ? $plugin->slug : ($plugin['slug'] ?? '');
        if (in_array($slug, $slugs_to_promote, true)) {
            $already_present[] = $slug;
        }
    }
    $slugs_to_promote = array_values(array_diff($slugs_to_promote, $already_present));

    if (empty($slugs_to_promote)) {
        return $result; // all already included
    }

    // Fetch plugin info for each promoted plugin and inject it at the top
    $fetched = array();
    foreach ($slugs_to_promote as $target_slug) {
        $cache_key = 'promoted_plugin_' . $target_slug;
        $plugin_info = get_transient($cache_key);

        if (!$plugin_info) {
            $plugin_info = plugins_api('plugin_information', array(
                'slug'   => $target_slug,
                'fields' => array(
                    'short_description' => true,
                    'sections'          => true,
                    'screenshots'       => true,
                    'icons'             => true,
                    'active_installs'   => true,
                ),
            ));

            if (is_wp_error($plugin_info)) {
                continue; // API error, skip this plugin
            }

            $plugin_info->slug = $target_slug;
            set_transient($cache_key, $plugin_info, DAY_IN_SECONDS);
        }

        $fetched[] = $plugin_info;
    }

    if (empty($fetched)) {
        return $result;
    }

    // Remove any existing instance to prevent duplicates
    $result->plugins = array_filter($result->plugins, function ($plugin) use ($slugs_to_promote) {
        $slug = is_object($plugin) ? $plugin->slug : ($plugin['slug'] ?? '');
        return !in_array($slug, $slugs_to_promote, true);
    });

    // Unshift in reverse order so the first promoted plugin ends up on top
    $fetched = array_reverse($fetched);
    foreach ($fetched as $plugin_info) {
        array_unshift($result->plugins, $plugin_info);
    }

    return $result;

}, 10, 3);

// Add a "Social Tools" tab to the Add Plugins screen that opens the ESSB Tools page.
add_filter('install_plugins_tabs', function ($tabs) {
    $tabs['social-tools'] = 'Social Tools';
    return $tabs;
});

add_action('install_plugins_pre_social-tools', function () {
    if (!isset($_GET['tab']) || 'social-tools' !== $_GET['tab']) {
        return;
    }
    wp_safe_redirect(admin_url('admin.php?page=essb_redirect_tools'));
    exit;
});