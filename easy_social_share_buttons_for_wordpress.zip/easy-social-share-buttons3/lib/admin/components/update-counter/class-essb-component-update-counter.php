<?php

/**
 * Update Counter component
 *
 * Drawer interface for the share counter connection settings: general update
 * behaviour, Facebook counter API and access tokens, Twitter counter source
 * and LinkedIn counter type. Replaces the legacy advanced settings window that
 * was built from ao-update-counter.php.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Update_Counter')) {

	class ESSB_Component_Update_Counter {

		const ID = 'update-counter';
		const AJAX_ACTION = 'essb_update_counter_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		/**
		 * Text fields managed by this component. Stored as plain strings.
		 */
		private function get_text_fields() {
			return array(
				'facebook_counter_token' => array(
					'title' => esc_html__('Facebook access token key', 'essb'),
					'desc'  => sprintf(esc_html__('To generate your access token key please visit %s and follow instructions to generate application based token', 'essb'), '<a href="https://tools.creoworx.com/facebook/" target="_blank">https://tools.creoworx.com/facebook/</a>'),
				),
				'sharedcount_token' => array(
					'title' => esc_html__('SharedCount.com access token key', 'essb'),
					'desc'  => sprintf(esc_html__('Can the key from your profile %s. You can refer to SharedCount.com documentation for more details.', 'essb'), '<a href="https://www.sharedcount.com/app/account-info" target="_blank">https://www.sharedcount.com/app/account-info</a>'),
				),
			);
		}

		/**
		 * Select fields managed by this component (except the Facebook API field
		 * that drives the conditional token fields and is rendered separately).
		 */
		private function get_select_fields() {
			return array(
				'twitter_counters' => array(
					'title'  => esc_html__('X (prev. Twitter) share counter', 'essb'),
					'desc'   => esc_html__('Select the X (prev. Twitter) counter source. If you select the self-hosted option the value will increase with a click over the share buttons and stored inside the post meta table.', 'essb'),
					'values' => array(
						'self' => 'Self-hosted counter (internally counted by click on buttons)',
						'no'   => 'No counter for X (prev. Twitter) button',
					),
				),
				'linkedin_counter_type' => array(
					'title'  => esc_html__('LinkedIn share counter', 'essb'),
					'desc'   => esc_html__('LinkedIn does not have a counter API. You can choose between a self-hosted counter (with a click on the button) or without a share counter.', 'essb'),
					'values' => array(
						''   => 'Self-hosted counter (internally counted by click on buttons)',
						'no' => 'Without share counter',
					),
				),
			);
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Load the current plugin options
		 */
		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		/**
		 * Save the plugin options
		 */
		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-update-counter', ESSB3_PLUGIN_URL . '/lib/admin/components/update-counter/assets/essb-update-counter.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-update-counter', 'essbUpdateCounterData', $this->get_localized_data());
		}

		/**
		 * Data used by the component interface
		 */
		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$values = array(
				'counter_remove_query_string' => $this->option_is_true($options, 'counter_remove_query_string'),
				'facebook_counter_api'        => $this->option_value($options, 'facebook_counter_api'),
				'facebook_counter_token'      => $this->option_value($options, 'facebook_counter_token'),
				'sharedcount_token'           => $this->option_value($options, 'sharedcount_token'),
				'twitter_counters'            => $this->option_value($options, 'twitter_counters'),
				'linkedin_counter_type'       => $this->option_value($options, 'linkedin_counter_type'),
			);

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $values,
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('Share counter update settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the share counter update settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		private function render_select($key, $field, $value) {
			?>
			<div class="essb-dr-field">
				<label class="essb-dr-field-label" for="essb-uc-<?php echo esc_attr($key); ?>"><?php echo esc_html($field['title']); ?></label>
				<select class="essb-dr-select" id="essb-uc-<?php echo esc_attr($key); ?>" data-field="<?php echo esc_attr($key); ?>">
					<?php foreach ($field['values'] as $option_value => $option_label) : ?>
						<option value="<?php echo esc_attr($option_value); ?>" <?php selected($value, $option_value); ?>><?php echo esc_html($option_label); ?></option>
					<?php endforeach; ?>
				</select>
				<?php if (!empty($field['desc'])) : ?>
					<span class="essb-dr-field-desc"><?php echo wp_kses_post($field['desc']); ?></span>
				<?php endif; ?>
			</div>
			<?php
		}

		private function render_text($key, $field, $value, $wrapper_id = '') {
			?>
			<div class="essb-dr-field essb-dr-field-indent"<?php echo $wrapper_id != '' ? ' id="' . esc_attr($wrapper_id) . '"' : ''; ?>>
				<label class="essb-dr-field-label" for="essb-uc-<?php echo esc_attr($key); ?>"><?php echo esc_html($field['title']); ?></label>
				<input type="text" class="essb-dr-input" id="essb-uc-<?php echo esc_attr($key); ?>" data-field="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
				<?php if (!empty($field['desc'])) : ?>
					<span class="essb-dr-field-desc"><?php echo wp_kses_post($field['desc']); ?></span>
				<?php endif; ?>
			</div>
			<?php
		}

		/**
		 * Render the component drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			$texts = $this->get_text_fields();
			?>
			<div class="essb-dr-overlay" id="essb-uc-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-uc-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Share Counter Update Settings', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-uc-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Configure global options related to the update of the share counters on your website (Facebook, X (formerly Twitter), LinkedIn).', 'essb'); ?></p>

					<h3 class="essb-dr-heading"><?php esc_html_e('General', 'essb'); ?></h3>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-uc-counter_remove_query_string" data-field="counter_remove_query_string" <?php checked($v['counter_remove_query_string'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Don\'t use query string in URLs when updating share counters', 'essb'); ?></span>
						</span>
					</label>

					<h3 class="essb-dr-heading"><?php esc_html_e('Facebook', 'essb'); ?></h3>

					<?php
					$this->render_select('facebook_counter_api', array(
						'title'  => esc_html__('Facebook counter update API', 'essb'),
						'desc'   => esc_html__('Select the counter update source. No matter which you choose (Facebook API or ShareCount API) you need to complete the steps and create an access token key.', 'essb'),
						'values' => array(
							'api2'        => 'Facebook API (Require Token)',
							'sharedcount' => 'SharedCount.com (Require Token)',
						),
					), $v['facebook_counter_api']);
					?>

					<?php $this->render_text('facebook_counter_token', $texts['facebook_counter_token'], $v['facebook_counter_token'], 'essb-uc-token-facebook'); ?>
					<?php $this->render_text('sharedcount_token', $texts['sharedcount_token'], $v['sharedcount_token'], 'essb-uc-token-sharedcount'); ?>

					<h3 class="essb-dr-heading"><?php esc_html_e('Twitter', 'essb'); ?></h3>

					<?php
					foreach ($this->get_select_fields() as $key => $field) {
						if ($key == 'twitter_counters') {
							$this->render_select($key, $field, $v[$key]);
						}
					}
					?>

					<h3 class="essb-dr-heading"><?php esc_html_e('LinkedIn', 'essb'); ?></h3>

					<?php
					foreach ($this->get_select_fields() as $key => $field) {
						if ($key == 'linkedin_counter_type') {
							$this->render_select($key, $field, $v[$key]);
						}
					}
					?>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-uc-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-uc-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Save the share counter update settings through AJAX
		 */
		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$options['counter_remove_query_string'] = (isset($_POST['counter_remove_query_string']) && $_POST['counter_remove_query_string'] === 'true') ? 'true' : '';

			$text_keys = array_merge(
				array('facebook_counter_api'),
				array_keys($this->get_text_fields()),
				array_keys($this->get_select_fields())
			);

			foreach ($text_keys as $key) {
				$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
