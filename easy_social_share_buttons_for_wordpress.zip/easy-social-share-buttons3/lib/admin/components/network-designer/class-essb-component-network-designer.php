<?php

/**
 * Custom Network Designer component
 *
 * Drawer interface for creating and editing custom share buttons.
 * Replaces the legacy manage-buttons / button-designer advanced
 * options window (ao-button-designer.php).
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Network_Designer')) {

	class ESSB_Component_Network_Designer {

		const ID = 'network-designer';
		const AJAX_LOAD = 'essb_network_designer_load';
		const AJAX_SAVE = 'essb_network_designer_save';
		const AJAX_DELETE = 'essb_network_designer_delete';

		/**
		 * Field keys that are stored for a custom share button.
		 */
		private $fields = array(
			'network_id',
			'name',
			'url',
			'counter',
			'icon',
			'padding_top',
			'padding_left',
			'network_color',
			'bgcolor',
			'iconcolor',
			'textcolor',
			'bgcolor_hover',
			'iconcolor_hover',
			'textcolor_hover',
		);

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_LOAD, array($this, 'load'));
			add_action('wp_ajax_' . self::AJAX_SAVE, array($this, 'save'));
			add_action('wp_ajax_' . self::AJAX_DELETE, array($this, 'delete_network'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Make sure the custom buttons helper is available
		 */
		private function include_helper() {
			if (!function_exists('essb_get_custom_buttons')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/custombuttons-helper.php');
			}
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-network-designer', ESSB3_PLUGIN_URL . '/lib/admin/components/network-designer/assets/essb-network-designer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-network-designer', ESSB3_PLUGIN_URL . '/lib/admin/components/network-designer/assets/essb-network-designer.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-network-designer', 'essbNetworkDesignerData', array(
				'nonce'       => wp_create_nonce(self::AJAX_SAVE),
				'loadNonce'   => wp_create_nonce(self::AJAX_LOAD),
				'deleteNonce' => wp_create_nonce(self::AJAX_DELETE),
				'ajaxUrl'     => admin_url('admin-ajax.php'),
				'vars'        => array(
					'%%title%%'       => esc_html__('Generates the current post title', 'essb'),
					'%%permalink%%'   => esc_html__('Generates the current post URL', 'essb'),
					'%%image%%'       => esc_html__('Generates the featured image URL of the current post', 'essb'),
					'%%description%%' => esc_html__('Generates the current post excerpt', 'essb'),
					'%%siteurl%%'     => esc_html__('Generates the site home URL', 'essb'),
				),
				'strings'     => array(
					'createTitle'   => esc_html__('Create Custom Network', 'essb'),
					'editTitle'     => esc_html__('Edit network', 'essb'),
					'save'          => esc_html__('Save network', 'essb'),
					'saving'        => esc_html__('Saving...', 'essb'),
					'delete'        => esc_html__('Delete network', 'essb'),
					'deleteConfirm' => esc_html__('Confirm delete?', 'essb'),
					'deleting'      => esc_html__('Deleting...', 'essb'),
					'cancel'        => esc_html__('Cancel', 'essb'),
					'close'         => esc_html__('Close', 'essb'),
					'created'       => esc_html__('Network created. The settings screen will reload.', 'essb'),
					'updated'       => esc_html__('Network updated. The settings screen will reload.', 'essb'),
					'deleted'       => esc_html__('Network deleted. The settings screen will reload.', 'essb'),
					'errId'         => esc_html__('Fill a custom unique ID for the network button. Use only lowercase letters (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb'),
					'errName'       => esc_html__('Fill the name of the button.', 'essb'),
					'errExists'     => esc_html__('A network with this ID already exists.', 'essb'),
					'errSave'       => esc_html__('Unable to save the network.', 'essb'),
					'errLoad'       => esc_html__('Unable to load the network.', 'essb'),
					'errDelete'     => esc_html__('Unable to delete the network.', 'essb'),
					'reloadNote'    => esc_html__('The settings screen will reload so the change appears in the network list.', 'essb'),
				),
			));
		}

		/**
		 * Render the create/edit drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}
			?>
			<div class="essb-dr-overlay" id="essb-nd-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-nd-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title" id="essb-nd-title"><?php esc_html_e('Create Custom Network', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-nd-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body" id="essb-nd-body">
				<div id="essb-nd-form">

					<!-- Basics -->
					<div class="essb-cd-section">
						<div class="essb-cd-section-title"><?php esc_html_e('Basics', 'essb'); ?></div>

						<div class="essb-cd-field">
							<label class="essb-cd-label" for="essb-nd-id"><?php esc_html_e('Network ID', 'essb'); ?> <span class="hint"><?php esc_html_e('- unique, lowercase, no spaces', 'essb'); ?></span></label>
							<input type="text" class="essb-cd-input mono" id="essb-nd-id" spellcheck="false">
						</div>

						<div class="essb-cd-field">
							<label class="essb-cd-label" for="essb-nd-name"><?php esc_html_e('Name', 'essb'); ?></label>
							<input type="text" class="essb-cd-input" id="essb-nd-name" placeholder="<?php esc_attr_e('e.g. Bluesky', 'essb'); ?>">
						</div>

						<div class="essb-cd-field">
							<label class="essb-cd-label" for="essb-nd-url"><?php esc_html_e('Button URL', 'essb'); ?></label>
							<input type="text" class="essb-cd-input mono" id="essb-nd-url" placeholder="<?php esc_attr_e('https://... or a share command', 'essb'); ?>" spellcheck="false">
							<div class="essb-cd-chips" id="essb-nd-chips"></div>
						</div>

					<label class="essb-dr-toggle essb-dr-toggle-large" style="margin-bottom:0">
						<input type="checkbox" id="essb-nd-counter">
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Enable internal share counter', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Shows the share count on the button when the design supports it.', 'essb'); ?></span>
						</span>
					</label>
					</div>

					<!-- Icon -->
					<div class="essb-cd-section">
						<div class="essb-cd-section-title"><?php esc_html_e('Icon', 'essb'); ?></div>

						<div class="essb-cd-icon-row">
							<div class="essb-cd-icon-preview" id="essb-nd-icon-preview"></div>
							<div class="essb-cd-icon-editor">
								<textarea class="essb-cd-textarea" id="essb-nd-icon" spellcheck="false"></textarea>
								<button type="button" class="essb-cd-upload" id="essb-nd-upload">
									<svg width="12" height="12" viewBox="0 0 14 14" fill="none"><path d="M7 2.5v7M4.5 6L7 3.5 9.5 6M2.5 11h9" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
									<?php esc_html_e('Upload SVG', 'essb'); ?>
								</button>
								<input type="file" id="essb-nd-file" accept=".svg" style="display:none">
							</div>
						</div>

						<div class="essb-cd-row" style="margin-top:14px">
							<div class="essb-cd-field" style="margin-bottom:0">
								<label class="essb-cd-label" for="essb-nd-pad-top"><?php esc_html_e('Icon top padding', 'essb'); ?></label>
								<input type="number" class="essb-cd-input" id="essb-nd-pad-top" min="0" max="40">
							</div>
							<div class="essb-cd-field" style="margin-bottom:0">
								<label class="essb-cd-label" for="essb-nd-pad-left"><?php esc_html_e('Icon left padding', 'essb'); ?></label>
								<input type="number" class="essb-cd-input" id="essb-nd-pad-left" min="0" max="40">
							</div>
						</div>
					</div>

					<!-- Colors -->
					<div class="essb-cd-section">
						<div class="essb-cd-section-title"><?php esc_html_e('Colors', 'essb'); ?></div>

						<div class="essb-cd-field">
							<label class="essb-cd-label" for="essb-nd-network-color"><?php esc_html_e('Network color', 'essb'); ?> <span class="hint"><?php esc_html_e('- used automatically by the templates', 'essb'); ?></span></label>
							<div class="essb-cd-color-main">
								<div class="essb-cd-swatch-lg" id="essb-nd-swatch-main"></div>
								<div class="essb-cd-color">
									<input type="color" id="essb-nd-network-color">
									<input type="text" class="essb-cd-input mono" id="essb-nd-network-color-text" maxlength="7" spellcheck="false">
								</div>
							</div>
						</div>

						<!-- advanced colors -->
						<div class="essb-cd-acc" id="essb-nd-acc-advanced">
							<button type="button" class="essb-cd-acc-head">
								<?php esc_html_e('Advanced colors', 'essb'); ?>
								<svg class="chev" width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2.5 4.5L6 8l3.5-3.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
							<div class="essb-cd-acc-body">
								<div class="essb-cd-row-3">
									<div class="essb-cd-field" style="margin-bottom:0">
										<label class="essb-cd-label" for="essb-nd-bg"><?php esc_html_e('Background', 'essb'); ?></label>
										<div class="essb-cd-color">
											<input type="color" id="essb-nd-bg">
											<input type="text" class="essb-cd-input mono" id="essb-nd-bg-text" maxlength="7" spellcheck="false">
										</div>
									</div>
									<div class="essb-cd-field" style="margin-bottom:0">
										<label class="essb-cd-label" for="essb-nd-icon-color"><?php esc_html_e('Icon', 'essb'); ?></label>
										<div class="essb-cd-color">
											<input type="color" id="essb-nd-icon-color">
											<input type="text" class="essb-cd-input mono" id="essb-nd-icon-color-text" maxlength="7" spellcheck="false">
										</div>
									</div>
									<div class="essb-cd-field" style="margin-bottom:0">
										<label class="essb-cd-label" for="essb-nd-text"><?php esc_html_e('Text', 'essb'); ?></label>
										<div class="essb-cd-color">
											<input type="color" id="essb-nd-text">
											<input type="text" class="essb-cd-input mono" id="essb-nd-text-text" maxlength="7" spellcheck="false">
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- hover colors -->
						<div class="essb-cd-acc" id="essb-nd-acc-hover" style="margin-top:10px">
							<button type="button" class="essb-cd-acc-head">
								<?php esc_html_e('Colors on hover', 'essb'); ?>
								<svg class="chev" width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2.5 4.5L6 8l3.5-3.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
							<div class="essb-cd-acc-body">
								<div class="essb-cd-row-3">
									<div class="essb-cd-field" style="margin-bottom:0">
										<label class="essb-cd-label" for="essb-nd-bg-h"><?php esc_html_e('Background', 'essb'); ?></label>
										<div class="essb-cd-color">
											<input type="color" id="essb-nd-bg-h">
											<input type="text" class="essb-cd-input mono" id="essb-nd-bg-h-text" maxlength="7" spellcheck="false">
										</div>
									</div>
									<div class="essb-cd-field" style="margin-bottom:0">
										<label class="essb-cd-label" for="essb-nd-icon-h"><?php esc_html_e('Icon', 'essb'); ?></label>
										<div class="essb-cd-color">
											<input type="color" id="essb-nd-icon-h">
											<input type="text" class="essb-cd-input mono" id="essb-nd-icon-h-text" maxlength="7" spellcheck="false">
										</div>
									</div>
									<div class="essb-cd-field" style="margin-bottom:0">
										<label class="essb-cd-label" for="essb-nd-text-h"><?php esc_html_e('Text', 'essb'); ?></label>
										<div class="essb-cd-color">
											<input type="color" id="essb-nd-text-h">
											<input type="text" class="essb-cd-input mono" id="essb-nd-text-h-text" maxlength="7" spellcheck="false">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="essb-dr-note" style="margin-top:4px"><?php esc_html_e('The settings screen will reload so the change appears in the network list.', 'essb'); ?></div>

					</div>

					<div id="essb-nd-loading" class="essb-cd-loading hidden">
						<span class="essb-cd-spinner"></span>
						<p><?php esc_html_e('Loading network data...', 'essb'); ?></p>
					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-nd-delete" style="margin-right:auto; color:#f4516c; display:none"><?php esc_html_e('Delete network', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-nd-save"><?php esc_html_e('Save network', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-nd-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Load the settings of an existing custom network for editing
		 */
		public function load() {
			check_ajax_referer(self::AJAX_LOAD, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$network_id = isset($_POST['network']) ? sanitize_key($_POST['network']) : '';
			if (empty($network_id)) {
				wp_send_json_error(array('message' => esc_html__('No network to load.', 'essb')));
			}

			$this->include_helper();
			$setup = essb_get_custom_button_settings($network_id);
			if (empty($setup)) {
				wp_send_json_error(array('message' => esc_html__('No network to load.', 'essb')));
			}

			// Normalize the icon for the editor: decode the base64 payload and
			// clean up JSON escaped quotes that legacy data may contain.
			if (isset($setup['icon']) && $setup['icon'] != '') {
				$decoded_icon = @base64_decode($setup['icon']);
				if ($decoded_icon !== false) {
					$setup['icon'] = stripslashes($decoded_icon);
				}
			}

			wp_send_json_success($setup);
		}

		/**
		 * Create or update a custom network
		 */
		public function save() {
			check_ajax_referer(self::AJAX_SAVE, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$this->include_helper();

			$network_id = isset($_POST['network_id']) ? trim(wp_unslash($_POST['network_id'])) : '';
			$original_id = isset($_POST['original_id']) ? sanitize_key($_POST['original_id']) : '';

			if ($network_id == '') {
				wp_send_json_error(array('code' => 'id', 'message' => esc_html__('Fill a custom unique ID for the network button. Use only lowercase letters (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb')));
			}

			if (!preg_match('/^[a-z0-9_\-]+$/i', $network_id)) {
				wp_send_json_error(array('code' => 'id', 'message' => esc_html__('Fill a custom unique ID for the network button. Use only lowercase letters (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb')));
			}

			$name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
			if ($name == '') {
				wp_send_json_error(array('code' => 'name', 'message' => esc_html__('Fill the name of the button.', 'essb')));
			}

			$existing = essb_get_custom_buttons();

			// When creating a new network the id must be unique.
			if (($original_id == '' || $original_id != $network_id) && isset($existing[$network_id])) {
				wp_send_json_error(array('code' => 'exists', 'message' => esc_html__('A network with this ID already exists.', 'essb')));
			}

			$obj = array();
			foreach ($this->fields as $key) {
				$obj[$key] = isset($_POST[$key]) ? wp_unslash($_POST[$key]) : '';
			}

			$obj['network_id'] = $network_id;
			$obj['name'] = $name;
			$obj['counter'] = (isset($_POST['counter']) && $_POST['counter'] == 'true') ? 'true' : 'false';
			$obj['padding_top'] = (isset($obj['padding_top']) && $obj['padding_top'] != '') ? intval($obj['padding_top']) : '';
			$obj['padding_left'] = (isset($obj['padding_left']) && $obj['padding_left'] != '') ? intval($obj['padding_left']) : '';

			// Encode the icon to match the legacy storage format.
			if (isset($obj['icon']) && $obj['icon'] != '') {
				$obj['icon'] = base64_encode($obj['icon']);
			}

			// Rename support: when the id is changed on an existing network,
			// the entry under the original id is removed.
			if ($original_id != '' && $original_id != $network_id && isset($existing[$original_id])) {
				unset($existing[$original_id]);
			}

			$existing[$network_id] = $obj;
			essb_save_custom_buttons($existing);

			// Make sure the custom share buttons are enabled, otherwise the
			// network will not appear in the list of share networks.
			$options_changed = false;

			if (essb_option_bool_value('deactivate_custombuttons')) {
				ESSB_Plugin_Options::set('deactivate_custombuttons', 'false');
				$options_changed = true;
			}

			if (!essb_option_bool_value('custombuttons_enable')) {
				ESSB_Plugin_Options::set('custombuttons_enable', 'true');
				$options_changed = true;
			}

			if ($options_changed) {
				ESSB_Plugin_Options::save();
			}

			wp_send_json_success(array('id' => $network_id, 'is_new' => ($original_id == '')));
		}

		/**
		 * Delete a custom network
		 */
		public function delete_network() {
			check_ajax_referer(self::AJAX_DELETE, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$network_id = isset($_POST['network']) ? sanitize_key($_POST['network']) : '';
			if (empty($network_id)) {
				wp_send_json_error(array('message' => esc_html__('No network to delete.', 'essb')));
			}

			$this->include_helper();
			essb_remove_custom_button($network_id);

			wp_send_json_success(array('id' => $network_id));
		}
	}
}
