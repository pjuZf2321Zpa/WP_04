<?php

/**
 * Total Counter component
 *
 * Drawer interface for the total share counter options: value format and
 * animation, the "all networks" mode, the texts for the different total counter
 * positions and the total counter icon. Replaces the legacy advanced settings
 * window that was built from ao-total-counter.php.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Total_Counter')) {

	class ESSB_Component_Total_Counter {

		const ID = 'total-counter';
		const AJAX_ACTION = 'essb_total_counter_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		private function counter_value_mode() {
			return array(
				''          => esc_html__('Automatically shorten values above 1000', 'essb'),
				'full'      => esc_html__('Always display full value (default server settings)', 'essb'),
				'fulldot'   => esc_html__('Always display full value - dot thousand separator (example 5.000)', 'essb'),
				'fullcomma' => esc_html__('Always display full value - comma thousand separator (example 5,000)', 'essb'),
				'fullspace' => esc_html__('Always display full value - space thousand separator (example 5 000)', 'essb'),
				'no'        => esc_html__('Without formating', 'essb'),
			);
		}

		private function counter_icons() {
			return array(
				'share'            => array('title' => '', 'content' => '<i class="essb_icon_share"></i>'),
				'share-alt-square' => array('title' => '', 'content' => '<i class="essb_icon_share-alt-square"></i>'),
				'share-alt'        => array('title' => '', 'content' => '<i class="essb_icon_share-alt"></i>'),
				'share-tiny'       => array('title' => '', 'content' => '<i class="essb_icon_share-tiny"></i>'),
				'share-outline'    => array('title' => '', 'content' => '<i class="essb_icon_share-outline"></i>'),
			);
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($options) {
			return array(
				'total_counter_format'                => $this->option_value($options, 'total_counter_format'),
				'animate_total_counter'               => $this->option_is_true($options, 'animate_total_counter'),
				'total_counter_all'                   => $this->option_is_true($options, 'total_counter_all'),
				'counter_total_text'                  => $this->option_value($options, 'counter_total_text'),
				'activate_total_counter_text'         => $this->option_value($options, 'activate_total_counter_text'),
				'activate_total_counter_text_singular' => $this->option_value($options, 'activate_total_counter_text_singular'),
				'activate_total_counter_icon'         => $this->option_value($options, 'activate_total_counter_icon'),
				'total_counter_afterbefore_text'      => $this->option_value($options, 'total_counter_afterbefore_text'),
			);
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-total-counter', ESSB3_PLUGIN_URL . '/lib/admin/components/total-counter/assets/essb-total-counter.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-total-counter', 'essbTotalCounterData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $this->get_values($options),
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('Total share counter settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the total share counter settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-tc-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-tc-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Total share counter', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-tc-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Control how the total share counter value is formatted, displayed and labelled across the different total counter positions.', 'essb'); ?></p>

					<h3 class="essb-dr-heading"><?php esc_html_e('Global Counter Settings', 'essb'); ?></h3>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label" for="essb-tc-total_counter_format"><?php esc_html_e('Total value format', 'essb'); ?></label>
						<select class="essb-dr-select" id="essb-tc-total_counter_format" data-field="total_counter_format">
							<?php foreach ($this->counter_value_mode() as $option_value => $option_label) : ?>
								<option value="<?php echo esc_attr($option_value); ?>" <?php selected($v['total_counter_format'], $option_value); ?>><?php echo esc_html($option_label); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-tc-animate_total_counter" data-field="animate_total_counter" <?php checked($v['animate_total_counter'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Animate value appearance', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-tc-total_counter_all" data-field="total_counter_all" <?php checked($v['total_counter_all'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Always generate total counter based on all social networks', 'essb'); ?> <?php echo essb_generate_expert_badge(); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Enable the option to make the total counter consists of the shares from all available inside the plugin networks. The option does not initiate an update for all networks - it will create a sum of the shares for all available in the plugin networks that are already stored.', 'essb'); ?></span>
						</span>
					</label>

					<h3 class="essb-dr-heading"><?php esc_html_e('Left/Right Total Counter Position', 'essb'); ?></h3>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label" for="essb-tc-counter_total_text"><?php esc_html_e('Change the text "Total"', 'essb'); ?></label>
						<input type="text" class="essb-dr-input" id="essb-tc-counter_total_text" data-field="counter_total_text" value="<?php echo esc_attr($v['counter_total_text']); ?>">
					</div>

					<h3 class="essb-dr-heading"><?php esc_html_e('Left/Right Total Counter With Big Number (and optional icon)', 'essb'); ?></h3>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label" for="essb-tc-activate_total_counter_text"><?php esc_html_e('Change "Shares" text (plural)', 'essb'); ?></label>
						<input type="text" class="essb-dr-input" id="essb-tc-activate_total_counter_text" data-field="activate_total_counter_text" value="<?php echo esc_attr($v['activate_total_counter_text']); ?>">
					</div>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label" for="essb-tc-activate_total_counter_text_singular"><?php esc_html_e('Change "Share" text (singular)', 'essb'); ?></label>
						<input type="text" class="essb-dr-input" id="essb-tc-activate_total_counter_text_singular" data-field="activate_total_counter_text_singular" value="<?php echo esc_attr($v['activate_total_counter_text_singular']); ?>">
					</div>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label"><?php esc_html_e('Total counter icon', 'essb'); ?></label>
						<?php essb_component_options_group_select('activate_total_counter_icon', $this->counter_icons(), '', '', 'essb_options'); ?>
					</div>

					<h3 class="essb-dr-heading"><?php esc_html_e('Before/After Share Buttons Total Counter Position', 'essb'); ?></h3>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label" for="essb-tc-total_counter_afterbefore_text"><?php esc_html_e('Change total counter text when before/after styles are active', 'essb'); ?></label>
						<input type="text" class="essb-dr-input" id="essb-tc-total_counter_afterbefore_text" data-field="total_counter_afterbefore_text" value="<?php echo esc_attr($v['total_counter_afterbefore_text']); ?>">
						<span class="essb-dr-field-desc"><?php esc_html_e('Customize the text that is displayed in before/after share buttons display method. To display the total share number use the string {TOTAL} in text. Example: {TOTAL} users share us', 'essb'); ?></span>
					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-tc-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-tc-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$options['animate_total_counter'] = (isset($_POST['animate_total_counter']) && $_POST['animate_total_counter'] === 'true') ? 'true' : '';
			$options['total_counter_all'] = (isset($_POST['total_counter_all']) && $_POST['total_counter_all'] === 'true') ? 'true' : '';

			$text_fields = array(
				'total_counter_format',
				'counter_total_text',
				'activate_total_counter_text',
				'activate_total_counter_text_singular',
				'activate_total_counter_icon',
				'total_counter_afterbefore_text',
			);

			foreach ($text_fields as $key) {
				$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
