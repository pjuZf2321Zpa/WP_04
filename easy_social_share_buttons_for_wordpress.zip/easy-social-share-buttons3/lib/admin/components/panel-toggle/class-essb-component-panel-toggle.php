<?php

/**
 * Panel Toggle component
 *
 * General-purpose component that handles toggle switches inside
 * essb5_generate_code_advanced_settings_panel via AJAX. Saves the
 * option value directly when the toggle is switched on/off. Unlike
 * counter-options there is no configure button - only the toggle.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Panel_Toggle')) {

	class ESSB_Component_Panel_Toggle {

		const AJAX_ACTION = 'essb_panel_toggle_save';
		const AJAX_TOGGLE = 'essb_panel_toggle_toggle';

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
			add_action('wp_ajax_' . self::AJAX_TOGGLE, array($this, 'toggle'));
		}

		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-panel-toggle', ESSB3_PLUGIN_URL . '/lib/admin/components/panel-toggle/assets/essb-panel-toggle.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-panel-toggle', 'essbPanelToggleData', array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'strings' => array(
					'saving' => esc_html__('Saving settings...', 'essb'),
					'saved' => esc_html__('Settings saved.', 'essb'),
					'error' => esc_html__('Unable to save the settings.', 'essb'),
				),
			));
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$key = isset($_POST['key']) ? sanitize_key(wp_unslash($_POST['key'])) : '';
			$value = isset($_POST['value']) && $_POST['value'] === 'true';

			if ($key === '') {
				wp_send_json_error(array('message' => esc_html__('Missing setting key.', 'essb')));
			}

			$options = $this->get_options();
			$options[$key] = $value ? 'true' : '';

			$this->apply_option_side_effects($key, $value);

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}

		public function toggle() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$key = isset($_POST['key']) ? sanitize_key(wp_unslash($_POST['key'])) : '';
			$value = isset($_POST['value']) && $_POST['value'] === 'true';

			$options = $this->get_options();
			$options[$key] = $value ? 'true' : '';

			$this->apply_option_side_effects($key, $value);

			$this->save_options($options);

			wp_send_json_success(array(
				'reload' => $this->option_requires_reload($key),
				'badge' => array(
					'label'   => $value ? esc_html__('Running', 'essb') : esc_html__('Not Running', 'essb'),
					'primary' => $value,
				),
			));
		}

		/**
		 * Run the additional operations that are normally executed when the
		 * complete settings form is saved.
		 *
		 * The panel toggles save the option alone, so without this the required
		 * database tables would not be created and the feature would stay inactive
		 * until the user saves the settings form.
		 *
		 * @param string $key
		 * @param boolean $value
		 */
		private function apply_option_side_effects($key = '', $value = false)
		{
			if (!$value) {
				return;
			}

			if ($key == 'conversions_lite_run') {
				if (!class_exists('ESSB_Share_Conversions_Pro')) {
					include_once(ESSB3_PLUGIN_ROOT . 'lib/modules/conversions-pro/class-share-conversions.php');
				}

				ESSB_Share_Conversions_Pro::install();
			}

			if ($key == 'stats_active') {
				if (!class_exists('ESSBSocialShareAnalyticsBackEnd')) {
					include_once(ESSB3_PLUGIN_ROOT . 'lib/modules/social-share-analytics/essb-social-share-analytics-backend.php');
				}

			ESSBSocialShareAnalyticsBackEnd::install();
			}
		}

		/**
		 * Some options change the structure of the admin menu - the analytics and
		 * conversions report sections are registered only while the feature is
		 * running. The page has to be reloaded to reflect them.
		 *
		 * @param string $key
		 * @return boolean
		 */
		private function option_requires_reload($key = '')
		{
			$reload_keys = array('stats_active', 'conversions_lite_run');

			return in_array($key, $reload_keys, true);
		}
	}
}
