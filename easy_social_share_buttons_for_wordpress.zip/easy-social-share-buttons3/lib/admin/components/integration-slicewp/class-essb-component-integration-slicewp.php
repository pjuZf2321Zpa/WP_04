<?php

/**
 * SliceWP Integration component
 *
 * Drawer interface for the SliceWP integration options.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Integration_Slicewp')) {

	class ESSB_Component_Integration_Slicewp {

		const ID = 'integration-slicewp';
		const AJAX_ACTION = 'essb_integration_slicewp_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($options) {
			return array(
				'slicewp_active'          => $this->option_is_true($options, 'slicewp_active'),
				'slicewp_active_shortcode' => $this->option_is_true($options, 'slicewp_active_shortcode'),
				'slicewp_bridge_short'    => $this->option_is_true($options, 'slicewp_bridge_short'),
			);
		}

		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-integration-slicewp', ESSB3_PLUGIN_URL . '/lib/admin/components/integration-slicewp/assets/essb-integration-slicewp.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-integration-slicewp', 'essbIntegrationSlicewpData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $this->get_values($options),
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('SliceWP integration settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the SliceWP integration settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-isl-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-isl-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('SliceWP Integration', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-isl-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Configure integration with the SliceWP plugin to share links that contain an affiliate (referral parameter).', 'essb'); ?></p>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-isl-active" data-field="slicewp_active" <?php checked($v['slicewp_active'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Append affiliate ID to shared address', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Automatically appends an affiliate\'s ID to Easy Social Share Buttons sharing links that are generated. You need to have installed SliceWP plugin to use it', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-isl-shortcode" data-field="slicewp_active_shortcode" <?php checked($v['slicewp_active_shortcode'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Append affiliate ID to shortcodes', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Automatically appends an affiliate\'s ID to Easy Social Share Buttons sharing links that are generated when shortcode has a custom url parameter.', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-isl-bridge" data-field="slicewp_bridge_short" <?php checked($v['slicewp_bridge_short'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Generate separate short URL when affiliate ID is added', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('The option will integrate the affiliate ID checks inside short URL generation. This will help to build a separate short URL for each of the affiliate users. The option works only if the short URL option inside the plugin is enabled.', 'essb'); ?></span>
						</span>
					</label>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-isl-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-isl-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$fields = array(
				'slicewp_active',
				'slicewp_active_shortcode',
				'slicewp_bridge_short',
			);

			foreach ($fields as $key) {
				$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
