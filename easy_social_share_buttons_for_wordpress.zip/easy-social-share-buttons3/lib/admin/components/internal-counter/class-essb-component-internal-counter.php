<?php

/**
 * Internal Counter component
 *
 * Drawer interface for the internal share counter options: display counters for
 * networks without an API, overwrite official counters with internal, hide the
 * Mail/Print counter and fully deactivate the internal tracking. Replaces the
 * legacy advanced settings window that was built from ao-internal-counter.php.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Internal_Counter')) {

	class ESSB_Component_Internal_Counter {

		const ID = 'internal-counter';
		const AJAX_ACTION = 'essb_internal_counter_save';
		const AJAX_PRESET = 'essb_internal_counter_preset';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
			add_action('wp_ajax_' . self::AJAX_PRESET, array($this, 'apply_preset_request'));
		}

		/**
		 * Networks that have an official counter API. Those are the networks that
		 * can be selected for the "overwrite official counters" mode.
		 */
		public static function get_api_networks() {
			return array(
				'facebook'  => 'Facebook',
				'pinterest' => 'Pinterest',
				'vk'        => 'VKontakte',
				'ok'        => 'Odnoklassniki',
				'reddit'    => 'Reddit',
				'buffer'    => 'Buffer',
				'xing'      => 'Xing',
				'yummly'    => 'Yummly',
			);
		}

		private function get_switches() {
			return array(
				'active_internal_counters' => array(
					'title' => esc_html__('Display share counters for social networks without API based on button clicks', 'essb'),
					'desc'  => '',
				),
				'active_internal_counters_advanced' => array(
					'title' => esc_html__('Overwrite the official counters with internal', 'essb'),
					'desc'  => esc_html__('Change the official API counter to internal. Enable the option to select which networks to overwrite.', 'essb'),
				),
				'deactive_internal_counters_mail' => array(
					'title' => esc_html__('Don\'t show share counter for Mail and Print buttons', 'essb'),
					'desc'  => esc_html__('Enable to hide the internal share counter for Mail and Print buttons. This won\'t stop the tracking and you can revert back at any time without losing the values.', 'essb'),
				),
				'deactivate_postcount' => array(
					'title' => esc_html__('Fully deactivate internal share counter tracking', 'essb'),
					'desc'  => esc_html__('The internal click tracking on each share button runs automatically in the background even when you don\'t show share counters. Enable the option if you wish to completely disable the internal share counter (no internal counter values will be generated).', 'essb'),
				),
			);
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Load the current plugin options
		 */
		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		/**
		 * Save the plugin options
		 */
		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function option_networks($options) {
			$networks = isset($options['active_internal_counters_advanced_networks']) ? $options['active_internal_counters_advanced_networks'] : array();
			if (!is_array($networks)) {
				$networks = array();
			}

			return array_values(array_intersect($networks, array_keys(self::get_api_networks())));
		}

		/**
		 * Normalized values used by the interface
		 */
		private function get_values($options) {
			return array(
				'active_internal_counters'                    => $this->option_is_true($options, 'active_internal_counters'),
				'active_internal_counters_advanced'           => $this->option_is_true($options, 'active_internal_counters_advanced'),
				'active_internal_counters_advanced_networks'  => $this->option_networks($options),
				'deactive_internal_counters_mail'             => $this->option_is_true($options, 'deactive_internal_counters_mail'),
				'deactivate_postcount'                        => $this->option_is_true($options, 'deactivate_postcount'),
			);
		}

		/**
		 * Reverse check the stored options and guess which quick action (if any)
		 * produced them. Anything that does not match a preset is "custom" ('').
		 */
		private function detect_preset($options) {
			$active = $this->option_is_true($options, 'active_internal_counters');
			$advanced = $this->option_is_true($options, 'active_internal_counters_advanced');
			$mail = $this->option_is_true($options, 'deactive_internal_counters_mail');
			$postcount = $this->option_is_true($options, 'deactivate_postcount');
			$networks = $this->option_networks($options);
			$all_networks = array_keys(self::get_api_networks());

			if ($postcount && !$active && !$advanced && !$mail && count($networks) == 0) {
				return 'disable';
			}

			if (!$postcount && $active && $advanced && $mail && count($networks) == count($all_networks) && count(array_diff($networks, $all_networks)) == 0) {
				return 'all';
			}

			if (!$postcount && $active && !$advanced && $mail && count($networks) == 0) {
				return 'noapi';
			}

			return '';
		}

		/**
		 * Panel badge state: running / disabled / none
		 */
		private function detect_state($options) {
			if ($this->option_is_true($options, 'deactivate_postcount')) {
				return 'disabled';
			}
			if ($this->option_is_true($options, 'active_internal_counters') || $this->option_is_true($options, 'active_internal_counters_advanced')) {
				return 'running';
			}

			return 'none';
		}

		/**
		 * Apply a quick action preset over the options. The "custom" state ('' or
		 * any unknown value) is a no-op: it keeps whatever the user configured
		 * through the drawer.
		 */
		private function apply_preset($options, $preset) {
			if (!in_array($preset, array('noapi', 'all', 'disable'))) {
				return $options;
			}

			$options['active_internal_counters'] = '';
			$options['deactive_internal_counters_mail'] = '';
			$options['active_internal_counters_advanced'] = '';
			$options['active_internal_counters_advanced_networks'] = array();
			$options['deactivate_postcount'] = '';

			if ($preset == 'noapi') {
				$options['active_internal_counters'] = 'true';
				$options['deactive_internal_counters_mail'] = 'true';
			} else if ($preset == 'all') {
				$options['active_internal_counters'] = 'true';
				$options['deactive_internal_counters_mail'] = 'true';
				$options['active_internal_counters_advanced'] = 'true';
				$options['active_internal_counters_advanced_networks'] = array_keys(self::get_api_networks());
			} else if ($preset == 'disable') {
				$options['deactivate_postcount'] = 'true';
			}

			return $options;
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-internal-counter', ESSB3_PLUGIN_URL . '/lib/admin/components/internal-counter/assets/essb-internal-counter.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-internal-counter', 'essbInternalCounterData', $this->get_localized_data());
		}

		/**
		 * Data used by the component interface
		 */
		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'       => wp_create_nonce(self::AJAX_ACTION),
				'presetNonce' => wp_create_nonce(self::AJAX_PRESET),
				'ajaxUrl'     => admin_url('admin-ajax.php'),
				'values'      => $this->get_values($options),
				'preset'      => $this->detect_preset($options),
				'state'       => $this->detect_state($options),
				'strings'     => array(
					'saving'        => esc_html__('Saving...', 'essb'),
					'saved'         => esc_html__('Internal share counter settings saved.', 'essb'),
					'error'         => esc_html__('Unable to save the internal share counter settings.', 'essb'),
					'badgeRunning'  => esc_html__('Running', 'essb'),
					'badgeDisabled' => esc_html__('Disabled', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		private function render_switch($key, $field, $checked) {
			?>
			<label class="essb-dr-toggle">
				<input type="checkbox" id="essb-ic-<?php echo esc_attr($key); ?>" data-field="<?php echo esc_attr($key); ?>" <?php checked($checked, true); ?>>
				<span class="essb-dr-toggle-track"></span>
				<span class="essb-dr-toggle-content">
					<span class="essb-dr-toggle-label"><?php echo esc_html($field['title']); ?></span>
					<?php if (!empty($field['desc'])) : ?>
						<span class="essb-dr-toggle-desc"><?php echo esc_html($field['desc']); ?></span>
					<?php endif; ?>
				</span>
			</label>
			<?php
		}

		/**
		 * Render the component drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			$switches = $this->get_switches();
			$api_networks = self::get_api_networks();
			?>
			<div class="essb-dr-overlay" id="essb-ic-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-ic-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Internal Share Counters', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-ic-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Internal share counters are stored in your database and grow with every click on a share button. Use them for networks that do not provide a share counter API, or overwrite the official counters.', 'essb'); ?></p>

					<?php $this->render_switch('active_internal_counters', $switches['active_internal_counters'], $v['active_internal_counters']); ?>
					<?php $this->render_switch('active_internal_counters_advanced', $switches['active_internal_counters_advanced'], $v['active_internal_counters_advanced']); ?>

					<div class="essb-dr-field essb-dr-field-indent" id="essb-ic-networks-field">
						<label class="essb-dr-field-label"><?php esc_html_e('Networks', 'essb'); ?></label>
						<?php essb_component_multiselect('active_internal_counters_advanced_networks', $api_networks, $v['active_internal_counters_advanced_networks'], 'essb_options'); ?>
						<span class="essb-dr-field-desc"><?php esc_html_e('The list includes only networks with an official counter API. Other networks use the internal counter from the option above.', 'essb'); ?></span>
					</div>

					<?php $this->render_switch('deactive_internal_counters_mail', $switches['deactive_internal_counters_mail'], $v['deactive_internal_counters_mail']); ?>
					<?php $this->render_switch('deactivate_postcount', $switches['deactivate_postcount'], $v['deactivate_postcount']); ?>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-ic-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-ic-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Response shared by the save and the quick action endpoints
		 */
		private function response($options) {
			return array(
				'values' => $this->get_values($options),
				'preset' => $this->detect_preset($options),
				'state'  => $this->detect_state($options),
			);
		}

		/**
		 * Save the drawer options through AJAX
		 */
		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			foreach (array('active_internal_counters', 'active_internal_counters_advanced', 'deactive_internal_counters_mail', 'deactivate_postcount') as $key) {
				$options[$key] = (isset($_POST[$key]) && $_POST[$key] === 'true') ? 'true' : '';
			}

			$networks = isset($_POST['active_internal_counters_advanced_networks']) ? (array) $_POST['active_internal_counters_advanced_networks'] : array();
			$networks = array_map('sanitize_key', $networks);
			$options['active_internal_counters_advanced_networks'] = array_values(array_intersect($networks, array_keys(self::get_api_networks())));

			$this->save_options($options);

			wp_send_json_success($this->response($options));
		}

		/**
		 * Apply a quick action preset through AJAX
		 */
		public function apply_preset_request() {
			check_ajax_referer(self::AJAX_PRESET, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$preset = isset($_POST['preset']) ? sanitize_key(wp_unslash($_POST['preset'])) : '';
			if (!in_array($preset, array('', 'noapi', 'all', 'disable'))) {
				$preset = '';
			}

			$options = $this->get_options();
			$options = $this->apply_preset($options, $preset);

			$this->save_options($options);

			wp_send_json_success($this->response($options));
		}
	}
}
