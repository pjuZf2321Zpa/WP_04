<?php

/**
 * Share Networks Library component
 *
 * Drawer interface that lists the available custom share networks from
 * the Easy Social Share Buttons network library and imports them directly
 * into the plugin as custom share buttons. Networks that are already
 * imported are marked and cannot be added a second time.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Share_Networks')) {

	class ESSB_Component_Share_Networks {

		const ID = 'share-networks';
		const AJAX_LOAD = 'essb_share_networks_load';
		const AJAX_IMPORT = 'essb_share_networks_import';
		const API_URL = 'https://my.socialsharingplugin.com/wp-json/my-essb/v1/share-networks';
		const CACHE_TTL = 600;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_LOAD, array($this, 'load'));
			add_action('wp_ajax_' . self::AJAX_IMPORT, array($this, 'import'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Make sure the custom buttons helper is available
		 */
		private function include_helper() {
			if (!function_exists('essb_get_custom_buttons')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/custombuttons-helper.php');
			}
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-share-networks', ESSB3_PLUGIN_URL . '/lib/admin/components/share-networks/assets/essb-share-networks.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-share-networks', ESSB3_PLUGIN_URL . '/lib/admin/components/share-networks/assets/essb-share-networks.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-share-networks', 'essbShareNetworksData', array(
				'nonce'        => wp_create_nonce(self::AJAX_LOAD),
				'importNonce'  => wp_create_nonce(self::AJAX_IMPORT),
				'ajaxUrl'      => admin_url('admin-ajax.php'),
				'strings'      => array(
					'loading'     => esc_html__('Loading the network library...', 'essb'),
					'import'      => esc_html__('Import', 'essb'),
					'importing'   => esc_html__('Importing...', 'essb'),
					'imported'    => esc_html__('Imported', 'essb'),
					'importedMsg' => esc_html__('Network imported successfully.', 'essb'),
					'importReload' => esc_html__('The settings screen will reload to include the newly imported networks.', 'essb'),
					'already'     => esc_html__('This network is already imported.', 'essb'),
					'importError' => esc_html__('Unable to import the network.', 'essb'),
					'loadError'   => esc_html__('Unable to load the network library. Please try again later.', 'essb'),
					'empty'       => esc_html__('No networks available in the library right now.', 'essb'),
					'noResults'   => esc_html__('No networks match your search.', 'essb'),
					'open'        => esc_html__('Open library', 'essb'),
				),
			));
		}

		/**
		 * Render the component drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}
			?>
			<div class="essb-dr-overlay" id="essb-sn-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-sn-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Share Networks Library', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-sn-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<h2 class="essb-dr-pane-title"><?php esc_html_e('Add new share networks', 'essb'); ?></h2>
					<p class="essb-dr-pane-desc"><?php esc_html_e('Browse the available networks and import them directly as custom share buttons. Already imported networks are marked and cannot be added twice.', 'essb'); ?></p>

					<div class="essb-sn-toolbar">
						<input type="text" class="essb-sn-search" id="essb-sn-search" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
					</div>
					<div class="essb-sn-toolbar-actions">
						<button type="button" class="essb-dr-btn essb-dr-btn-ghost essb-dr-btn-sm" id="essb-sn-refresh"><?php esc_html_e('Refresh', 'essb'); ?></button>
					</div>

					<div class="essb-sn-list" id="essb-sn-list"></div>
					<div class="essb-sn-status" id="essb-sn-status"></div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-sn-close-btn"><?php esc_html_e('Close', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Fetch the network library from the remote API with short cache
		 *
		 * @return array
		 */
		private function fetch_library() {
			$transient = 'essb_share_networks_library';
			$cached = get_transient($transient);
			if ($cached !== false) {
				return $cached;
			}

			$response = wp_remote_get(self::API_URL, array(
				'timeout' => 15,
				'headers' => array('Accept' => 'application/json'),
			));

			if (is_wp_error($response)) {
				return array('error' => $response->get_error_message());
			}

			$code = wp_remote_retrieve_response_code($response);
			$body = wp_remote_retrieve_body($response);
			if ($code != 200 || empty($body)) {
				return array('error' => 'http_' . $code);
			}

			$items = json_decode($body, true);
			if (!is_array($items)) {
				return array('error' => 'invalid_json');
			}

			set_transient($transient, $items, self::CACHE_TTL);

			return $items;
		}

		/**
		 * Load the network library and report the imported state of each network
		 */
		public function load() {
			check_ajax_referer(self::AJAX_LOAD, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$this->include_helper();
			$existing = essb_get_custom_buttons();

			$library = $this->fetch_library();
			if (isset($library['error'])) {
				wp_send_json_error(array('message' => esc_html__('Unable to load the network library.', 'essb')));
			}

			$items = array();
			foreach ($library as $entry) {
				$content = isset($entry['content']) ? json_decode($entry['content'], true) : array();
				if (!is_array($content) || empty($content['network_id'])) {
					continue;
				}

				$network_id = $content['network_id'];
				$icon = isset($content['icon']) ? stripslashes(base64_decode($content['icon'])) : '';

				$color = '';
				if (!empty($content['network_color'])) {
					$color = $content['network_color'];
				} else if (!empty($content['bgcolor'])) {
					$color = $content['bgcolor'];
				} else {
					$color = '#6b7280';
				}

				$name = '';
				if (!empty($content['name'])) {
					$name = $content['name'];
				} else if (!empty($entry['title'])) {
					$name = $entry['title'];
				} else {
					$name = $network_id;
				}

				$items[] = array(
					'id'        => $network_id,
					'name'      => $name,
					'url'       => isset($content['url']) ? $content['url'] : '',
					'color'     => $color,
					'iconcolor' => isset($content['iconcolor']) ? $content['iconcolor'] : '',
					'icon'      => $icon,
					'imported'  => isset($existing[$network_id]),
					'content'   => wp_json_encode($content),
				);
			}

			wp_send_json_success(array('items' => $items));
		}

		/**
		 * Import a single network as a custom share button
		 */
		public function import() {
			check_ajax_referer(self::AJAX_IMPORT, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$content = isset($_POST['content']) ? wp_unslash($_POST['content']) : '';
			if (empty($content)) {
				wp_send_json_error(array('message' => esc_html__('Missing network data.', 'essb')));
			}

			$obj = json_decode($content, true);
			if (!is_array($obj) || empty($obj['network_id'])) {
				wp_send_json_error(array('message' => esc_html__('Invalid network data.', 'essb')));
			}

			if (!preg_match('/^[a-z0-9_\-]+$/i', $obj['network_id'])) {
				wp_send_json_error(array('message' => esc_html__('Invalid network identifier.', 'essb')));
			}

			$this->include_helper();
			$existing = essb_get_custom_buttons();
			if (isset($existing[$obj['network_id']])) {
				wp_send_json_error(array(
					'code'    => 'exists',
					'message' => esc_html__('This network is already imported.', 'essb'),
				));
			}

			essb_create_custom_button($obj);

			// Make sure the custom share buttons are enabled, otherwise
			// the imported network will not be added to the network list.
			$options_changed = false;

			if (essb_option_bool_value('deactivate_custombuttons')) {
				ESSB_Plugin_Options::set('deactivate_custombuttons', 'false');
				$options_changed = true;
			}

			if (!essb_option_bool_value('custombuttons_enable')) {
				ESSB_Plugin_Options::set('custombuttons_enable', 'true');
				$options_changed = true;
			}

			if ($options_changed) {
				ESSB_Plugin_Options::save();
			}

			delete_transient('essb_share_networks_library');

			wp_send_json_success(array('id' => $obj['network_id']));
		}
	}
}
