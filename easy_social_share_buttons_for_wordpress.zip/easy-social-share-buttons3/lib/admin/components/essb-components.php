<?php

/**
 * Admin components loader
 *
 * Registers and boots the self-contained admin components that render
 * their own interface windows inside the plugin settings.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Components')) {

	class ESSB_Components {

		private static $instance = null;

		private $components = array();

		public static function get_instance() {
			if (null === self::$instance) {
				self::$instance = new self;
			}

			return self::$instance;
		}

		private function __construct() {
			$this->load_components();
		}

		/**
		 * Load all registered admin components
		 */
		public function load_components() {
			$components = array(
				'network-setup' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/network-setup/class-essb-component-network-setup.php',
					'class' => 'ESSB_Component_Network_Setup',
				),
				'network-visibility' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/network-visibility/class-essb-component-network-visibility.php',
					'class' => 'ESSB_Component_Network_Visibility',
				),
				'share-networks' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/share-networks/class-essb-component-share-networks.php',
					'class' => 'ESSB_Component_Share_Networks',
				),
				'network-transfer' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/network-transfer/class-essb-component-network-transfer.php',
					'class' => 'ESSB_Component_Network_Transfer',
				),
				'network-designer' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/network-designer/class-essb-component-network-designer.php',
					'class' => 'ESSB_Component_Network_Designer',
				),
				'follow-designer' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/follow-designer/class-essb-component-follow-designer.php',
					'class' => 'ESSB_Component_Follow_Designer',
				),
				'profile-networks' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/profile-networks/class-essb-component-profile-networks.php',
					'class' => 'ESSB_Component_Profile_Networks',
				),
				'after-share' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/after-share/class-essb-component-after-share.php',
					'class' => 'ESSB_Component_After_Share',
				),
				'google-analytics' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/google-analytics/class-essb-component-google-analytics.php',
					'class' => 'ESSB_Component_Google_Analytics',
				),
				'integration-mycred' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/integration-mycred/class-essb-component-integration-mycred.php',
					'class' => 'ESSB_Component_Integration_Mycred',
				),
				'integration-affiliatewp' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/integration-affiliatewp/class-essb-component-integration-affiliatewp.php',
					'class' => 'ESSB_Component_Integration_Affiliatewp',
				),
				'integration-slicewp' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/integration-slicewp/class-essb-component-integration-slicewp.php',
					'class' => 'ESSB_Component_Integration_Slicewp',
				),
				'integration-affiliates' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/integration-affiliates/class-essb-component-integration-affiliates.php',
					'class' => 'ESSB_Component_Integration_Affiliates',
				),
				'advanced-counter-update' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/advanced-counter-update/class-essb-component-advanced-counter-update.php',
					'class' => 'ESSB_Component_Advanced_Counter_Update',
				),
				'update-counter' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/update-counter/class-essb-component-update-counter.php',
					'class' => 'ESSB_Component_Update_Counter',
				),
				'internal-counter' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/internal-counter/class-essb-component-internal-counter.php',
					'class' => 'ESSB_Component_Internal_Counter',
				),
				'single-counter' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/single-counter/class-essb-component-single-counter.php',
					'class' => 'ESSB_Component_Single_Counter',
				),
				'total-counter' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/total-counter/class-essb-component-total-counter.php',
					'class' => 'ESSB_Component_Total_Counter',
				),
				'counter-options' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/counter-options/class-essb-component-counter-options.php',
					'class' => 'ESSB_Component_Counter_Options',
				),
				'counter-autoconfig' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/counter-autoconfig/class-essb-component-counter-autoconfig.php',
					'class' => 'ESSB_Component_Counter_Autoconfig',
				),
				'panel-toggle' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/panel-toggle/class-essb-component-panel-toggle.php',
					'class' => 'ESSB_Component_Panel_Toggle',
				),
				'shortcode-generator' => array(
					'file'  => ESSB3_PLUGIN_ROOT . 'lib/admin/components/shortcode-generator/class-essb-component-shortcode-generator.php',
					'class' => 'ESSB_Component_Shortcode_Generator',
				),
			);

			$components = apply_filters('essb_admin_components', $components);

			foreach ($components as $component_id => $component) {
				if (empty($component['class']) || !class_exists($component['class'])) {
					if (!empty($component['file']) && file_exists($component['file'])) {
						include_once $component['file'];
					}
				}

				if (class_exists($component['class'])) {
					$this->components[$component_id] = new $component['class']();
				}
			}
		}

		/**
		 * Get a registered component instance
		 *
		 * @param string $component_id
		 * @return object|false
		 */
		public function get_component($component_id = '') {
			if (isset($this->components[$component_id])) {
				return $this->components[$component_id];
			}

			return false;
		}
	}
}

ESSB_Components::get_instance();
