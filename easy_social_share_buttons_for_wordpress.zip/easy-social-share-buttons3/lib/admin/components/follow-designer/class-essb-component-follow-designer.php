<?php

/**
 * Custom Profile (Follow) Button Designer component
 *
 * Drawer interface for creating and editing custom social profile buttons.
 * Replaces the legacy manage-follow-buttons / button-designer-profile
 * advanced options window (ao-button-designer-profile.php).
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Follow_Designer')) {

	class ESSB_Component_Follow_Designer {

		const ID = 'follow-designer';
		const AJAX_LOAD = 'essb_follow_designer_load';
		const AJAX_SAVE = 'essb_follow_designer_save';
		const AJAX_DELETE = 'essb_follow_designer_delete';

		/**
		 * Field keys that are stored for a custom profile button.
		 */
		private $fields = array(
			'network_id',
			'name',
			'icon',
			'accent_color',
		);

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_LOAD, array($this, 'load'));
			add_action('wp_ajax_' . self::AJAX_SAVE, array($this, 'save'));
			add_action('wp_ajax_' . self::AJAX_DELETE, array($this, 'delete_network'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Make sure the custom profile buttons helper is available
		 */
		private function include_helper() {
			if (!function_exists('essb_get_custom_profile_buttons')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/customprofilebuttons-helper.php');
			}
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-follow-designer', ESSB3_PLUGIN_URL . '/lib/admin/components/follow-designer/assets/essb-follow-designer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-follow-designer', ESSB3_PLUGIN_URL . '/lib/admin/components/follow-designer/assets/essb-follow-designer.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-follow-designer', 'essbFollowDesignerData', array(
				'nonce'       => wp_create_nonce(self::AJAX_SAVE),
				'loadNonce'   => wp_create_nonce(self::AJAX_LOAD),
				'deleteNonce' => wp_create_nonce(self::AJAX_DELETE),
				'ajaxUrl'     => admin_url('admin-ajax.php'),
				'strings'     => array(
					'createTitle'   => esc_html__('Create Custom Profile Button', 'essb'),
					'editTitle'     => esc_html__('Edit profile button', 'essb'),
					'save'          => esc_html__('Save button', 'essb'),
					'saving'        => esc_html__('Saving...', 'essb'),
					'delete'        => esc_html__('Delete button', 'essb'),
					'deleteConfirm' => esc_html__('Confirm delete?', 'essb'),
					'deleting'      => esc_html__('Deleting...', 'essb'),
					'cancel'        => esc_html__('Cancel', 'essb'),
					'close'         => esc_html__('Close', 'essb'),
					'created'       => esc_html__('Profile button created. The settings screen will reload.', 'essb'),
					'updated'       => esc_html__('Profile button updated. The settings screen will reload.', 'essb'),
					'deleted'       => esc_html__('Profile button deleted. The settings screen will reload.', 'essb'),
					'errId'         => esc_html__('Fill a custom unique ID for the profile button. Use only lowercase letters (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb'),
					'errName'       => esc_html__('Fill the name of the button.', 'essb'),
					'errExists'     => esc_html__('A profile button with this ID already exists.', 'essb'),
					'errSave'       => esc_html__('Unable to save the profile button.', 'essb'),
					'errLoad'       => esc_html__('Unable to load the profile button.', 'essb'),
					'errDelete'     => esc_html__('Unable to delete the profile button.', 'essb'),
					'reloadNote'    => esc_html__('The settings screen will reload so the change appears in the list.', 'essb'),
				),
			));
		}

		/**
		 * Render the create/edit drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}
			?>
			<div class="essb-dr-overlay" id="essb-fd-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-fd-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title" id="essb-fd-title"><?php esc_html_e('Create Custom Profile Button', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-fd-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body" id="essb-fd-body">
				<div id="essb-fd-form">

					<!-- Basics -->
					<div class="essb-fd-section">
						<div class="essb-fd-section-title"><?php esc_html_e('Basics', 'essb'); ?></div>

						<div class="essb-fd-field">
							<label class="essb-fd-label" for="essb-fd-id"><?php esc_html_e('Network ID', 'essb'); ?> <span class="hint"><?php esc_html_e('- unique, lowercase, no spaces', 'essb'); ?></span></label>
							<input type="text" class="essb-fd-input mono" id="essb-fd-id" spellcheck="false">
						</div>

						<div class="essb-fd-field">
							<label class="essb-fd-label" for="essb-fd-name"><?php esc_html_e('Name', 'essb'); ?></label>
							<input type="text" class="essb-fd-input" id="essb-fd-name" placeholder="<?php esc_attr_e('e.g. Bluesky', 'essb'); ?>">
						</div>
					</div>

					<!-- Icon -->
					<div class="essb-fd-section">
						<div class="essb-fd-section-title"><?php esc_html_e('Icon', 'essb'); ?></div>

						<div class="essb-fd-icon-row">
							<div class="essb-fd-icon-preview" id="essb-fd-icon-preview"></div>
							<div class="essb-fd-icon-editor">
								<textarea class="essb-fd-textarea" id="essb-fd-icon" spellcheck="false"></textarea>
								<button type="button" class="essb-fd-upload" id="essb-fd-upload">
									<svg width="12" height="12" viewBox="0 0 14 14" fill="none"><path d="M7 2.5v7M4.5 6L7 3.5 9.5 6M2.5 11h9" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
									<?php esc_html_e('Upload SVG', 'essb'); ?>
								</button>
								<input type="file" id="essb-fd-file" accept=".svg" style="display:none">
							</div>
						</div>
					</div>

					<!-- Color -->
					<div class="essb-fd-section">
						<div class="essb-fd-section-title"><?php esc_html_e('Color', 'essb'); ?></div>

						<div class="essb-fd-field">
							<label class="essb-fd-label" for="essb-fd-color"><?php esc_html_e('Accent color', 'essb'); ?> <span class="hint"><?php esc_html_e('- used automatically by the templates', 'essb'); ?></span></label>
							<div class="essb-fd-color-main">
								<div class="essb-fd-swatch-lg" id="essb-fd-swatch"></div>
								<div class="essb-fd-color">
									<input type="color" id="essb-fd-color">
									<input type="text" class="essb-fd-input mono" id="essb-fd-color-text" maxlength="7" spellcheck="false">
								</div>
							</div>
						</div>
					</div>

					<div class="essb-dr-note" style="margin-top:4px"><?php esc_html_e('The settings screen will reload so the change appears in the list.', 'essb'); ?></div>

					</div>

					<div id="essb-fd-loading" class="essb-fd-loading hidden">
						<span class="essb-fd-spinner"></span>
						<p><?php esc_html_e('Loading button data...', 'essb'); ?></p>
					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-fd-delete" style="margin-right:auto; color:#f4516c; display:none"><?php esc_html_e('Delete button', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-fd-save"><?php esc_html_e('Save button', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-fd-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Load the settings of an existing custom profile button for editing
		 */
		public function load() {
			check_ajax_referer(self::AJAX_LOAD, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$network_id = isset($_POST['network']) ? sanitize_key($_POST['network']) : '';
			if (empty($network_id)) {
				wp_send_json_error(array('message' => esc_html__('No button to load.', 'essb')));
			}

			$this->include_helper();
			$setup = essb_get_custom_profile_button_settings($network_id);
			if (empty($setup)) {
				wp_send_json_error(array('message' => esc_html__('No button to load.', 'essb')));
			}

			// Normalize the icon for the editor: decode the base64 payload and
			// clean up JSON escaped quotes that legacy data may contain.
			if (isset($setup['icon']) && $setup['icon'] != '') {
				$decoded_icon = @base64_decode($setup['icon']);
				if ($decoded_icon !== false) {
					$setup['icon'] = stripslashes($decoded_icon);
				}
			}

			wp_send_json_success($setup);
		}

		/**
		 * Create or update a custom profile button
		 */
		public function save() {
			check_ajax_referer(self::AJAX_SAVE, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$this->include_helper();

			$network_id = isset($_POST['network_id']) ? trim(wp_unslash($_POST['network_id'])) : '';
			$original_id = isset($_POST['original_id']) ? sanitize_key($_POST['original_id']) : '';

			if ($network_id == '') {
				wp_send_json_error(array('code' => 'id', 'message' => esc_html__('Fill a custom unique ID for the profile button. Use only lowercase letters (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb')));
			}

			if (!preg_match('/^[a-z0-9_\-]+$/i', $network_id)) {
				wp_send_json_error(array('code' => 'id', 'message' => esc_html__('Fill a custom unique ID for the profile button. Use only lowercase letters (a-z) and numbers (0-9). No spaces are allowed - use underscore.', 'essb')));
			}

			$name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
			if ($name == '') {
				wp_send_json_error(array('code' => 'name', 'message' => esc_html__('Fill the name of the button.', 'essb')));
			}

			$existing = essb_get_custom_profile_buttons();

			// When creating a new button the id must be unique.
			if (($original_id == '' || $original_id != $network_id) && isset($existing[$network_id])) {
				wp_send_json_error(array('code' => 'exists', 'message' => esc_html__('A profile button with this ID already exists.', 'essb')));
			}

			$obj = array();
			foreach ($this->fields as $key) {
				$obj[$key] = isset($_POST[$key]) ? wp_unslash($_POST[$key]) : '';
			}

			$obj['network_id'] = $network_id;
			$obj['name'] = $name;

			// Encode the icon to match the legacy storage format.
			if (isset($obj['icon']) && $obj['icon'] != '') {
				$obj['icon'] = base64_encode($obj['icon']);
			}

			// Rename support: when the id is changed on an existing button,
			// the entry under the original id is removed.
			if ($original_id != '' && $original_id != $network_id && isset($existing[$original_id])) {
				unset($existing[$original_id]);
			}

			$existing[$network_id] = $obj;
			essb_save_custom_profile_buttons($existing);

			wp_send_json_success(array('id' => $network_id, 'is_new' => ($original_id == '')));
		}

		/**
		 * Delete a custom profile button
		 */
		public function delete_network() {
			check_ajax_referer(self::AJAX_DELETE, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$network_id = isset($_POST['network']) ? sanitize_key($_POST['network']) : '';
			if (empty($network_id)) {
				wp_send_json_error(array('message' => esc_html__('No button to delete.', 'essb')));
			}

			$this->include_helper();
			essb_remove_custom_profile_button($network_id);

			wp_send_json_success(array('id' => $network_id));
		}
	}
}
