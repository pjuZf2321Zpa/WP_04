<?php

/**
 * Shortcode Generator component
 *
 * Reusable drawer that builds a plugin shortcode from a parameter schema.
 * The parameter list is taken from the canonical shortcode registry
 * (ESSBControlCenterShortcodes), so every registered shortcode can be
 * generated without declaring a new schema and the generator can never drift
 * from the real shortcode parameters.
 *
 * The drawer is opened by any element carrying the data attribute
 * "data-essb-shortcode-generator" with the id of a registered generator:
 *
 *   <button data-essb-shortcode-generator="sharable-quote">Generate</button>
 *
 * It can also be opened from javascript with:
 *
 *   window.essbShortcodeGenerator.open('sharable-quote');
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Shortcode_Generator')) {

	class ESSB_Component_Shortcode_Generator {

		private static $instance = null;

		/**
		 * Registered generators
		 *
		 * @var array
		 */
		private $generators = array();

		/**
		 * Shared instance.
		 *
		 * The component is constructed by the admin components loader, so this
		 * resolves the instance that is already registered there instead of
		 * building a second one.
		 */
		public static function get_instance() {
			if (null === self::$instance) {
				if (class_exists('ESSB_Components')) {
					$component = ESSB_Components::get_instance()->get_component('shortcode-generator');

					if ($component) {
						self::$instance = $component;
					}
				}

				if (null === self::$instance) {
					self::$instance = new self;
				}
			}

			return self::$instance;
		}

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawers'));

			$this->register_default_generators();
		}

		/**
		 * Register a shortcode generator.
		 *
		 * Supported configuration keys:
		 *  id       - unique id, used in the data-essb-shortcode-generator attribute
		 *  title    - drawer title
		 *  subtitle - optional drawer subtitle
		 *  desc     - optional description shown above the fields
		 *  code     - shortcode name used when the code is generated
		 *  types    - optional list of selectable shortcode variants
		 *  groups   - optional list of field groups, each with a label and a
		 *             list of parameter names
		 *  fields   - optional field list, overrides the registered shortcode options
		 *
		 * @param array $config
		 * @return bool
		 */
		public function register($config = array()) {
			if (empty($config['id']) || empty($config['code'])) {
				return false;
			}

			$config = wp_parse_args($config, array(
				'title'    => esc_html__('Shortcode Generator', 'essb'),
				'subtitle' => '',
				'desc'     => '',
				'code'     => '',
				'types'    => array(),
				'groups'   => array(),
				'fields'   => array(),
			));

			$this->generators[$config['id']] = $config;

			return true;
		}

		/**
		 * Registered generators
		 *
		 * @return array
		 */
		public function get_generators() {
			return $this->generators;
		}

		/**
		 * The generators that are shipped with the plugin.
		 */
		private function register_default_generators() {
			$this->register(array(
				'id'       => 'sharable-quote',
				'title'    => esc_html__('Shortcode Generator', 'essb'),
				'subtitle' => esc_html__('Click to Share', 'essb'),
				'desc'     => esc_html__('The shortcode updates as you fill in the fields. Copy it and paste it anywhere in the content.', 'essb'),
				'code'     => 'sharable-quote',
				'types'    => array(
					array('code' => 'sharable-quote', 'label' => esc_html__('Block Quote', 'essb'), 'content' => false),
					array('code' => 'inline-tweet', 'label' => esc_html__('Inline', 'essb'), 'content' => true),
				),
				'groups'   => array(
					array('label' => esc_html__('Content', 'essb'), 'params' => array('tweet', 'user', 'hashtags', 'url')),
					array('label' => esc_html__('Appearance', 'essb'), 'params' => array('template', 'via', 'usehashtags')),
				),
			));

			$this->register(array(
				'id'       => 'easy-followers',
				'title'    => esc_html__('Shortcode Generator', 'essb'),
				'subtitle' => esc_html__('Social Followers', 'essb'),
				'desc'     => esc_html__('The shortcode updates as you fill in the fields. Copy it and paste it anywhere in the content.', 'essb'),
				'code'     => 'easy-followers',
				'types'    => array(
					array('code' => 'easy-followers', 'label' => esc_html__('Followers Counter', 'essb'), 'content' => false),
				),
			));

			$this->register(array(
				'id'       => 'easy-profiles',
				'title'    => esc_html__('Shortcode Generator', 'essb'),
				'subtitle' => esc_html__('Social Profiles', 'essb'),
				'desc'     => esc_html__('The shortcode updates as you fill in the fields. Copy it and paste it anywhere in the content.', 'essb'),
				'code'     => 'easy-profiles',
				'types'    => array(
					array('code' => 'easy-profiles', 'label' => esc_html__('Profile Links', 'essb'), 'content' => false),
				),
			));
		}

		/**
		 * The parameter schema of a generator.
		 *
		 * When the generator does not declare its own fields, the options
		 * registered for the shortcode are used.
		 *
		 * @param array $generator
		 * @return array
		 */
		private function get_fields($generator) {
			if (!empty($generator['fields'])) {
				return $generator['fields'];
			}

			if (class_exists('ESSBControlCenterShortcodes')) {
				$options = ESSBControlCenterShortcodes::get_shortcode_options($generator['code']);

				if (!empty($options)) {
					return $options;
				}
			}

			return array();
		}

		/**
		 * Split the fields into the configured groups. Parameters that are not
		 * listed in any group are collected in a trailing group.
		 *
		 * @param array $generator
		 * @param array $fields
		 * @return array
		 */
		private function get_groups($generator, $fields) {
			$groups = array();

			if (!empty($generator['groups'])) {
				foreach ($generator['groups'] as $group) {
					if (empty($group['params'])) {
						continue;
					}

					$group_fields = array();

					foreach ($group['params'] as $param) {
						if (isset($fields[$param])) {
							$group_fields[$param] = $fields[$param];
							unset($fields[$param]);
						}
					}

					if (!empty($group_fields)) {
						$groups[] = array(
							'label'  => isset($group['label']) ? $group['label'] : '',
							'fields' => $group_fields,
						);
					}
				}
			}

			if (!empty($fields)) {
				$groups[] = array(
					'label'  => esc_html__('Options', 'essb'),
					'fields' => $fields,
				);
			}

			return $groups;
		}

		public function assets() {
			$version = ESSB3_VERSION;

			if (function_exists('essb_admin_asset_version')) {
				$version = essb_admin_asset_version('lib/admin/components/shortcode-generator/assets/essb-shortcode-generator.css');
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-shortcode-generator', ESSB3_PLUGIN_URL . '/lib/admin/components/shortcode-generator/assets/essb-shortcode-generator.css', array('essb-components-drawer'), $version);

			$js_version = ESSB3_VERSION;

			if (function_exists('essb_admin_asset_version')) {
				$js_version = essb_admin_asset_version('lib/admin/components/shortcode-generator/assets/essb-shortcode-generator.js');
			}

			wp_enqueue_script('essb-shortcode-generator', ESSB3_PLUGIN_URL . '/lib/admin/components/shortcode-generator/assets/essb-shortcode-generator.js', array('jquery'), $js_version, true);
		}

		/**
		 * Render a single field of a generator.
		 */
		private function render_field($generator_id, $param, $setup) {
			$type = isset($setup['type']) ? $setup['type'] : 'text';
			$title = isset($setup['title']) ? $setup['title'] : '';
			$description = isset($setup['description']) ? $setup['description'] : '';
			$options = isset($setup['options']) ? $setup['options'] : array();
			$value = isset($setup['default_value']) ? $setup['default_value'] : '';

			$field_id = 'essb-scg-' . $generator_id . '-' . $param;

			if ($type == 'section-open') {
				echo '<div class="essb-scg-section-open" data-section="' . esc_attr($title) . '">';
				return;
			}

			if ($type == 'section-close') {
				echo '</div>';
				return;
			}

			if ($type == 'separator' || $type == 'separator-small') {
				echo '<div class="essb-scg-separator' . ($type == 'separator-small' ? ' essb-scg-separator-small' : '') . '">';
				if ($title != '') {
					echo '<span class="essb-scg-separator-title"><strong>' . esc_html($title) . '</strong></span>';
				}
				if ($description != '') {
					echo '<em class="essb-scg-separator-desc">' . esc_html($description) . '</em>';
				}
				echo '</div>';
				return;
			}

			echo '<div class="essb-dr-field">';

			if ($type == 'textarea') {
				echo '<label class="essb-dr-field-label" for="' . esc_attr($field_id) . '">' . esc_html($title) . '</label>';
				echo '<textarea class="essb-dr-textarea" id="' . esc_attr($field_id) . '" data-param="' . esc_attr($param) . '">' . esc_textarea($value) . '</textarea>';
			}
			else if ($type == 'select') {
				echo '<label class="essb-dr-field-label" for="' . esc_attr($field_id) . '">' . esc_html($title) . '</label>';
				echo '<select class="essb-dr-select" id="' . esc_attr($field_id) . '" data-param="' . esc_attr($param) . '">';
				foreach ($options as $option_value => $option_label) {
					echo '<option value="' . esc_attr($option_value) . '"' . selected($value, $option_value, false) . '>' . esc_html($option_label) . '</option>';
				}
				echo '</select>';
			}
			else if ($type == 'checkbox') {
				$checked = ($value === 'yes' || $value === '1' || $value === true || $value === 1);
				echo '<div class="essb-scg-toggle">';
				echo '<label class="essb-dr-field-label" for="' . esc_attr($field_id) . '">' . esc_html($title) . '</label>';
				echo '<label class="essb-scg-switch" for="' . esc_attr($field_id) . '">';
				echo '<input type="checkbox" class="essb-scg-checkbox" id="' . esc_attr($field_id) . '" data-param="' . esc_attr($param) . '" value="yes" ' . ($checked ? 'checked="checked"' : '') . ' />';
				echo '<span class="essb-scg-slider"></span>';
				echo '</label>';
				echo '</div>';
			}
			else {
				echo '<label class="essb-dr-field-label" for="' . esc_attr($field_id) . '">' . esc_html($title) . '</label>';
				echo '<input class="essb-dr-input" id="' . esc_attr($field_id) . '" type="text" value="' . esc_attr($value) . '" data-param="' . esc_attr($param) . '" />';
			}

			if ($description != '') {
				echo '<span class="essb-dr-field-desc">' . esc_html($description) . '</span>';
			}

			echo '</div>';
		}

		public function render_drawers() {
			if (empty($this->generators)) {
				return;
			}

			foreach ($this->generators as $generator_id => $generator) {
				$fields = $this->get_fields($generator);
				$groups = $this->get_groups($generator, $fields);
				?>
				<div class="essb-dr-overlay" id="essb-scg-<?php echo esc_attr($generator_id); ?>-overlay" data-essb-scg-overlay="<?php echo esc_attr($generator_id); ?>"></div>
				<div class="essb-dr-drawer essb-ui essb-scg-drawer" id="essb-scg-<?php echo esc_attr($generator_id); ?>-wrap" data-generator="<?php echo esc_attr($generator_id); ?>">

					<div class="essb-dr-header">
						<div class="essb-scg-heading">
							<div class="essb-dr-title"><?php echo esc_html($generator['title']); ?></div>
							<?php if (!empty($generator['subtitle'])) : ?>
								<div class="essb-scg-subtitle"><?php echo esc_html($generator['subtitle']); ?></div>
							<?php endif; ?>
						</div>
						<button type="button" class="essb-dr-close" data-essb-scg-close="<?php echo esc_attr($generator_id); ?>" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
					</div>

					<div class="essb-dr-body essb-scg-body">

						<?php // The generated shortcode stays pinned on top of the window while the fields are edited ?>
						<div class="essb-scg-result">
							<div class="essb-scg-result-head">
								<span class="essb-scg-kicker"><?php esc_html_e('Your shortcode', 'essb'); ?></span>
								<button type="button" class="essb-scg-copy" data-essb-scg-copy="<?php echo esc_attr($generator_id); ?>"><i class="fa fa-copy"></i><?php esc_html_e('Copy', 'essb'); ?></button>
							</div>
							<div class="essb-scg-code" data-essb-scg-result="<?php echo esc_attr($generator_id); ?>"></div>
						</div>

						<?php if (!empty($generator['desc'])) : ?>
							<p class="essb-dr-pane-desc essb-scg-desc"><?php echo esc_html($generator['desc']); ?></p>
						<?php endif; ?>

						<?php if (!empty($generator['types']) && count($generator['types']) > 1) : ?>
							<div class="essb-scg-section">
								<div class="essb-scg-heading-row"><?php esc_html_e('Shortcode type', 'essb'); ?></div>
								<div class="essb-scg-seg">
									<?php foreach ($generator['types'] as $index => $type) : ?>
										<button type="button"<?php echo $index == 0 ? ' class="on"' : ''; ?> data-code="<?php echo esc_attr($type['code']); ?>" data-content="<?php echo empty($type['content']) ? 'false' : 'true'; ?>"><?php echo esc_html($type['label']); ?></button>
									<?php endforeach; ?>
								</div>
							</div>
						<?php elseif (!empty($generator['types']) && count($generator['types']) == 1) : ?>
							<?php $single_type = $generator['types'][0]; ?>
							<input type="hidden" class="essb-scg-single-type" data-code="<?php echo esc_attr($single_type['code']); ?>" data-content="<?php echo empty($single_type['content']) ? 'false' : 'true'; ?>" />
						<?php endif; ?>

						<?php foreach ($groups as $group) : ?>
							<div class="essb-scg-section">
								<?php if (!empty($group['label'])) : ?>
									<div class="essb-scg-heading-row"><?php echo esc_html($group['label']); ?></div>
								<?php endif; ?>
								<?php foreach ($group['fields'] as $param => $setup) : ?>
									<?php $this->render_field($generator_id, $param, $setup); ?>
								<?php endforeach; ?>
							</div>
						<?php endforeach; ?>

					</div>

				</div>
				<?php
			}
		}
	}
}
