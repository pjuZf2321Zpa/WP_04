<?php

/**
 * Custom Network Transfer component
 *
 * Drawer interfaces for importing a custom network from an export code
 * and exporting the code of an existing custom network. Replaces the
 * legacy export-share-buttons advanced options window.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Network_Transfer')) {

	class ESSB_Component_Network_Transfer {

		const ID = 'network-transfer';
		const AJAX_IMPORT = 'essb_network_transfer_import';
		const AJAX_EXPORT = 'essb_network_transfer_export';

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawers'));
			add_action('wp_ajax_' . self::AJAX_IMPORT, array($this, 'import'));
			add_action('wp_ajax_' . self::AJAX_EXPORT, array($this, 'export'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Make sure the custom buttons helper is available
		 */
		private function include_helper() {
			if (!function_exists('essb_get_custom_buttons')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/custombuttons-helper.php');
			}
		}

		/**
		 * Make sure the custom profile buttons helper is available
		 */
		private function include_profile_helper() {
			if (!function_exists('essb_get_custom_profile_buttons')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/customprofilebuttons-helper.php');
			}
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-network-transfer', ESSB3_PLUGIN_URL . '/lib/admin/components/network-transfer/assets/essb-network-transfer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-network-transfer', ESSB3_PLUGIN_URL . '/lib/admin/components/network-transfer/assets/essb-network-transfer.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-network-transfer', 'essbNetworkTransferData', array(
				'nonce'       => wp_create_nonce(self::AJAX_IMPORT),
				'exportNonce' => wp_create_nonce(self::AJAX_EXPORT),
				'ajaxUrl'     => admin_url('admin-ajax.php'),
				'strings'     => array(
					'importTitle'   => esc_html__('Import Custom Network', 'essb'),
					'exportTitle'   => esc_html__('Export Custom Network', 'essb'),
					'paste'         => esc_html__('Paste code', 'essb'),
					'fromFile'      => esc_html__('From file', 'essb'),
					'pasteLabel'    => esc_html__('Network code', 'essb'),
					'pasteHint'     => esc_html__('output of the Export action', 'essb'),
					'pastePh'       => esc_html__('Paste the network export code here...', 'essb'),
					'fileLabel'     => esc_html__('Exported network file', 'essb'),
					'fileTitle'     => esc_html__('Drag & drop a network file here', 'essb'),
					'fileSub'       => esc_html__('or use the button below', 'essb'),
					'chooseFile'    => esc_html__('Choose file', 'essb'),
					'removeFile'    => esc_html__('Remove file', 'essb'),
					'previewTitle'  => esc_html__('Ready to import', 'essb'),
					'willAdd'       => esc_html__('will be added', 'essb'),
					'errInvalid'    => esc_html__('This does not look like a valid network code. The code should be the output of the Export action.', 'essb'),
					'errFile'       => esc_html__('The selected file does not contain a valid network code.', 'essb'),
					'errExists'     => esc_html__('This network is already imported.', 'essb'),
					'errImport'     => esc_html__('Unable to import the network.', 'essb'),
					'import'        => esc_html__('Import network', 'essb'),
					'importing'     => esc_html__('Importing...', 'essb'),
					'cancel'        => esc_html__('Cancel', 'essb'),
					'close'         => esc_html__('Close', 'essb'),
					'importedTitle' => esc_html__('Network imported', 'essb'),
					'importedDesc'  => esc_html__('The network was added to your custom networks and is ready to be placed on any share position.', 'essb'),
					'importPaneDesc' => esc_html__('Paste the export code of a custom network or load it from a file. The network is added as a custom share button.', 'essb'),
					'importPaneDescP' => esc_html__('Paste the export code of a custom network or load it from a file. The network is added as a custom follow button.', 'essb'),
					'importedDescP' => esc_html__('The network was added to your custom follow buttons and is ready to be used in the follow buttons module.', 'essb'),
					'active'        => esc_html__('active', 'essb'),
					'reloadNote'    => esc_html__('The settings screen will reload so the new network appears in the network list.', 'essb'),
					'done'          => esc_html__('Done', 'essb'),
					'exportCode'    => esc_html__('Export code', 'essb'),
					'exportHint'    => esc_html__('Copy this code and paste it into the Import screen of another Easy Social Share Buttons for a WordPress installation.', 'essb'),
					'copy'          => esc_html__('Copy code', 'essb'),
					'copied'        => esc_html__('Export code copied.', 'essb'),
					'download'      => esc_html__('Download as file', 'essb'),
					'exportLoad'    => esc_html__('Unable to load the network code.', 'essb'),
					'loading'       => esc_html__('Loading the network code...', 'essb'),
					'errMissing'    => esc_html__('No network to export.', 'essb'),
				),
			));
		}

		/**
		 * Render the import and export drawer windows
		 */
		public function render_drawers() {
			if (!$this->is_settings_page()) {
				return;
			}
			$this->render_import_drawer();
			$this->render_export_drawer();
		}

		private function render_import_drawer() {
			?>
			<div class="essb-dr-overlay" id="essb-nt-import-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-nt-import-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Import Custom Network', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" data-nt-close="import" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<div class="essb-nt-success" id="essb-nt-import-success">
						<div class="essb-nt-success-check">
							<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</div>
						<h3><?php esc_html_e('Network imported', 'essb'); ?></h3>
						<p id="essb-nt-success-desc"><?php esc_html_e('The network was added to your custom networks and is ready to be placed on any share position.', 'essb'); ?></p>
						<div class="essb-nt-preview essb-nt-preview-inline" id="essb-nt-import-success-preview">
							<div class="essb-nt-preview-row">
								<div class="essb-nt-preview-icon" id="essb-nt-success-icon"></div>
								<div class="essb-nt-preview-info">
									<div class="essb-nt-preview-name" id="essb-nt-success-name"></div>
									<div class="essb-nt-preview-id" id="essb-nt-success-id"></div>
								</div>
								<span class="essb-nt-preview-status ok"><?php esc_html_e('active', 'essb'); ?></span>
							</div>
						</div>
						<div class="essb-dr-note" style="text-align:left"><?php esc_html_e('The settings screen will reload so the new network appears in the network list.', 'essb'); ?></div>
					</div>

					<div id="essb-nt-import-form">

						<div class="essb-dr-pane-title"><?php esc_html_e('Import a network', 'essb'); ?></div>
						<p class="essb-dr-pane-desc" id="essb-nt-import-desc"><?php esc_html_e('Paste the export code of a custom network or load it from a file. The network is added as a custom share button.', 'essb'); ?></p>

						<div class="essb-nt-tabs">
							<button type="button" class="essb-nt-tab active" data-nt-tab="paste">
								<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><rect x="2" y="3" width="10" height="9" rx="1.5" stroke="currentColor" stroke-width="1.3"/><path d="M5 3V2.5c0-.8.7-1.5 2-1.5s2 .7 2 1.5V3" stroke="currentColor" stroke-width="1.3"/></svg>
								<?php esc_html_e('Paste code', 'essb'); ?>
							</button>
							<button type="button" class="essb-nt-tab" data-nt-tab="file">
								<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M3 1.5h5l3 3v8H3z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M8 1.5v3h3" stroke="currentColor" stroke-width="1.3"/></svg>
								<?php esc_html_e('From file', 'essb'); ?>
							</button>
						</div>

						<div class="essb-nt-pane" data-nt-pane="paste">
							<div class="essb-nt-label"><?php esc_html_e('Network code', 'essb'); ?></div>
							<textarea class="essb-nt-textarea" id="essb-nt-code" placeholder="<?php esc_attr_e('Paste the network export code here...', 'essb'); ?>"></textarea>
						</div>

						<div class="essb-nt-pane" data-nt-pane="file" style="display:none">
							<div class="essb-nt-label"><?php esc_html_e('Exported network file', 'essb'); ?></div>
							<div class="essb-nt-dropzone" id="essb-nt-dropzone">
								<div class="essb-nt-dz-icon">
									<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M7 3h10v18H7z" stroke-linejoin="round"/><path d="M10 8h4M10 12h4" stroke-linecap="round"/></svg>
								</div>
								<div class="essb-nt-dz-title"><?php esc_html_e('Drag & drop a network file here', 'essb'); ?></div>
								<p><?php esc_html_e('or use the button below', 'essb'); ?></p>
								<button type="button" class="essb-dr-btn essb-dr-btn-primary essb-dr-btn-sm" style="margin-top:10px" id="essb-nt-pick-file"><?php esc_html_e('Choose file', 'essb'); ?></button>
								<input type="file" id="essb-nt-file" accept=".json,.txt,.code" style="display:none">
							</div>
							<div class="essb-nt-file" id="essb-nt-file-chip">
								<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 1.5h5l3 3v8H3z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>
								<span class="essb-nt-file-name" id="essb-nt-file-name">bluesky.code</span>
								<span class="essb-nt-file-size" id="essb-nt-file-size"></span>
								<button type="button" class="essb-nt-file-remove" id="essb-nt-file-remove" title="<?php esc_attr_e('Remove file', 'essb'); ?>">
									<svg width="10" height="10" viewBox="0 0 14 14" fill="none"><path d="M2 2l10 10M12 2L2 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
								</button>
							</div>
						</div>

						<div class="essb-nt-preview" id="essb-nt-preview">
							<div class="essb-nt-preview-title"><?php esc_html_e('Ready to import', 'essb'); ?></div>
							<div class="essb-nt-preview-row">
								<div class="essb-nt-preview-icon" id="essb-nt-preview-icon"></div>
								<div class="essb-nt-preview-info">
									<div class="essb-nt-preview-name" id="essb-nt-preview-name"></div>
									<div class="essb-nt-preview-id" id="essb-nt-preview-id"></div>
								</div>
								<span class="essb-nt-preview-status ok" id="essb-nt-preview-status"><?php esc_html_e('will be added', 'essb'); ?></span>
							</div>
						</div>

						<div class="essb-nt-error" id="essb-nt-error">
							<svg width="14" height="14" viewBox="0 0 14 14" fill="none" style="flex-shrink:0"><path d="M7 1.5 13.5 12H.5z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/><path d="M7 5.5V8M7 9.8v.2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
							<span id="essb-nt-error-text"><?php esc_html_e('This does not look like a valid network code. The code should be the output of the Export action.', 'essb'); ?></span>
						</div>
					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-nt-import-btn" disabled><?php esc_html_e('Import network', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" data-nt-close="import"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		private function render_export_drawer() {
			?>
			<div class="essb-dr-overlay" id="essb-nt-export-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-nt-export-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Export Custom Network', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" data-nt-close="export" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<div class="essb-dr-pane-title"><?php esc_html_e('Export a network', 'essb'); ?></div>
					<p class="essb-dr-pane-desc"><?php esc_html_e('Copy this code and paste it into the Import screen of another Easy Social Share Buttons for a WordPress installation.', 'essb'); ?></p>

					<div class="essb-nt-preview" id="essb-nt-export-preview">
						<div class="essb-nt-preview-row">
							<div class="essb-nt-preview-icon" id="essb-nt-export-icon"></div>
							<div class="essb-nt-preview-info">
								<div class="essb-nt-preview-name" id="essb-nt-export-name"></div>
								<div class="essb-nt-preview-id" id="essb-nt-export-id"></div>
							</div>
						</div>
					</div>

					<div class="essb-nt-label"><?php esc_html_e('Export code', 'essb'); ?></div>
					<div class="essb-nt-loading" id="essb-nt-export-loading">
						<div class="essb-nt-spinner"></div>
						<span><?php esc_html_e('Loading the network code...', 'essb'); ?></span>
					</div>
					<textarea class="essb-nt-textarea essb-nt-textarea-code" id="essb-nt-export-code" readonly></textarea>
					<div class="essb-nt-export-actions">
						<button type="button" class="essb-dr-btn essb-dr-btn-primary essb-dr-btn-sm" id="essb-nt-copy">
							<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><rect x="2" y="4" width="9" height="8" rx="1.5" stroke="currentColor" stroke-width="1.3"/><path d="M4.5 4V2.5c0-.8.7-1.5 2-1.5h3c1.4 0 2.5 1.1 2.5 2.5v3c0 .8-.7 1.5-2 1.5" stroke="currentColor" stroke-width="1.3"/></svg>
							<?php esc_html_e('Copy code', 'essb'); ?>
						</button>
						<button type="button" class="essb-dr-btn essb-dr-btn-ghost essb-dr-btn-sm" id="essb-nt-download">
							<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M7 1.5v8M4 7l3 3 3-3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M2.5 11.5h9" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
							<?php esc_html_e('Download as file', 'essb'); ?>
						</button>
					</div>

					<div class="essb-nt-error" id="essb-nt-export-error">
						<svg width="14" height="14" viewBox="0 0 14 14" fill="none" style="flex-shrink:0"><path d="M7 1.5 13.5 12H.5z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/><path d="M7 5.5V8M7 9.8v.2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
						<span id="essb-nt-export-error-text"><?php esc_html_e('Unable to load the network code.', 'essb'); ?></span>
					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" data-nt-close="export"><?php esc_html_e('Close', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Import a custom network from an export code
		 */
		public function import() {
			check_ajax_referer(self::AJAX_IMPORT, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$code = isset($_POST['code']) ? wp_unslash($_POST['code']) : '';
			if (empty($code)) {
				wp_send_json_error(array('message' => esc_html__('Missing network code.', 'essb')));
			}

			$type       = isset($_POST['type']) ? sanitize_key($_POST['type']) : 'share';
			$is_profile = ($type === 'profile');

			$obj = json_decode(base64_decode($code), true);
			if (!is_array($obj) || empty($obj['network_id'])) {
				wp_send_json_error(array('message' => esc_html__('Invalid network code.', 'essb')));
			}

			if (!preg_match('/^[a-z0-9_\-]+$/i', $obj['network_id'])) {
				wp_send_json_error(array('message' => esc_html__('Invalid network identifier.', 'essb')));
			}

			// Normalize a legacy icon that may carry JSON escaped quotes
			if (!empty($obj['icon'])) {
				$decoded_icon = @base64_decode($obj['icon']);
				if ($decoded_icon !== false) {
					$clean_icon = stripslashes($decoded_icon);
					$obj['icon'] = base64_encode($clean_icon);
				}
			}

			if ($is_profile) {
				$this->include_profile_helper();
				$existing = essb_get_custom_profile_buttons();
			} else {
				$this->include_helper();
				$existing = essb_get_custom_buttons();
			}

			if (isset($existing[$obj['network_id']])) {
				wp_send_json_error(array(
					'code'    => 'exists',
					'message' => esc_html__('This network is already imported.', 'essb'),
				));
			}

			if ($is_profile) {
				essb_create_custom_profile_button($obj);
			} else {
				essb_create_custom_button($obj);
			}

			// Make sure the custom buttons are enabled, otherwise
			// the imported network will not be added to the network list.
			$options_changed = false;

			if (essb_option_bool_value('deactivate_custombuttons')) {
				ESSB_Plugin_Options::set('deactivate_custombuttons', 'false');
				$options_changed = true;
			}

			if ($is_profile) {
				if (!essb_option_bool_value('customprofilebuttons_enable')) {
					ESSB_Plugin_Options::set('customprofilebuttons_enable', 'true');
					$options_changed = true;
				}
			} else if (!essb_option_bool_value('custombuttons_enable')) {
				ESSB_Plugin_Options::set('custombuttons_enable', 'true');
				$options_changed = true;
			}

			if ($options_changed) {
				ESSB_Plugin_Options::save();
			}

			if ($is_profile) {
				delete_transient('essb_profile_networks_library');
			}

			wp_send_json_success(array('id' => $obj['network_id']));
		}

		/**
		 * Generate the export code of an existing custom network
		 */
		public function export() {
			check_ajax_referer(self::AJAX_EXPORT, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to perform this action.', 'essb')));
			}

			$network_id = isset($_POST['network']) ? sanitize_key($_POST['network']) : '';
			if (empty($network_id)) {
				wp_send_json_error(array('message' => esc_html__('No network to export.', 'essb')));
			}

			$type       = isset($_POST['type']) ? sanitize_key($_POST['type']) : 'share';
			$is_profile = ($type === 'profile');

			if ($is_profile) {
				$this->include_profile_helper();
				$setup = essb_get_custom_profile_button_settings($network_id);
			} else {
				$this->include_helper();
				$setup = essb_get_custom_button_settings($network_id);
			}

			if (empty($setup)) {
				wp_send_json_error(array('message' => esc_html__('No network to export.', 'essb')));
			}

			// Normalize the icon: legacy data may store the SVG with JSON
			// escaped quotes inside the base64 string. Decode, clean up the
			// slashes and re-encode so both the preview and the export code
			// carry a clean icon.
			if (!empty($setup['icon'])) {
				$decoded_icon = @base64_decode($setup['icon']);
				if ($decoded_icon !== false) {
					$clean_icon = stripslashes($decoded_icon);
					$setup['icon'] = base64_encode($clean_icon);
				}
			}

			$code = base64_encode(wp_json_encode($setup));

			$name = isset($setup['name']) ? $setup['name'] : $network_id;
			$color = '';
			if ($is_profile) {
				if (!empty($setup['accent_color'])) {
					$color = $setup['accent_color'];
				} else {
					$color = '#6b7280';
				}
			} else {
				if (!empty($setup['network_color'])) {
					$color = $setup['network_color'];
				} else if (!empty($setup['bgcolor'])) {
					$color = $setup['bgcolor'];
				} else {
					$color = '#6b7280';
				}
			}

			$url = $is_profile ? '' : (isset($setup['url']) ? $setup['url'] : '');
			$icon = '';
			if (!empty($setup['icon'])) {
				$decoded_icon = @base64_decode($setup['icon']);
				if ($decoded_icon !== false) {
					$icon = stripslashes($decoded_icon);
				}
			}

			wp_send_json_success(array(
				'code'  => $code,
				'name'  => $name,
				'id'    => $network_id,
				'url'   => $url,
				'color' => $color,
				'icon'  => $icon,
			));
		}
	}
}
