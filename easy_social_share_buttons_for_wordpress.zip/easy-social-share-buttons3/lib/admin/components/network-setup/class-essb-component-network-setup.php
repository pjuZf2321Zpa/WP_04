<?php

/**
 * Network Setup component
 *
 * Single-step interface for choosing the networks that will be used on the
 * entire site. Replaces the legacy advanced-networks window and the
 * automatic-network-setup automation.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Network_Setup')) {

	class ESSB_Component_Network_Setup {

		const ID = 'network-setup';
		const AJAX_ACTION = 'essb_network_setup_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_modal'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Load the current plugin options
		 */
		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		/**
		 * Save the plugin options
		 */
		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-network-setup', ESSB3_PLUGIN_URL . '/lib/admin/components/network-setup/assets/essb-network-setup.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-network-setup', ESSB3_PLUGIN_URL . '/lib/admin/components/network-setup/assets/essb-network-setup.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-network-setup', 'essbNetworkSetupData', $this->get_localized_data());
		}

		/**
		 * Data used by the component interface
		 */
		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$manage_active = isset($options['activate_networks_manage']) && $options['activate_networks_manage'] == 'true';

			$current_site_networks = isset($options['networks']) ? $options['networks'] : array();
			if (!is_array($current_site_networks)) {
				$current_site_networks = array();
			}

			$selected = isset($options['functions_networks']) ? $options['functions_networks'] : array();
			if (!is_array($selected)) {
				$selected = array();
			}

			if (count($selected) == 0) {
				$selected = $current_site_networks;
			}

			$colors = $this->get_network_colors();

			$networks = array();
			$all_networks = essb_available_social_networks(true);
			if (is_array($all_networks)) {
				foreach ($all_networks as $network_id => $network_data) {
					$networks[] = array(
						'id'    => $network_id,
						'name'  => isset($network_data['name']) ? $network_data['name'] : $network_id,
						'color' => isset($colors[$network_id]) ? $colors[$network_id] : '#6b7280',
					);
				}
			}

			$data = array(
				'nonce'               => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl'             => admin_url('admin-ajax.php'),
				'manageActive'        => $manage_active,
				'selected'            => array_values($selected),
				'currentSiteNetworks' => array_values($current_site_networks),
				'networks'            => $networks,
				'strings'             => array(
					'saving'    => esc_html__('Saving...', 'essb'),
					'saved'     => esc_html__('Network setup saved.', 'essb'),
					'prefilled' => esc_html__('Prefilled with your current site networks.', 'essb'),
					'selected'  => esc_html__('selected', 'essb'),
					'error'     => esc_html__('Unable to save the network setup.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		private function get_network_colors() {
			if (class_exists('ESSB_Share_Button_Styles')) {
				return ESSB_Share_Button_Styles::get_network_colors();
			}

			return array();
		}

		/**
		 * Render the component drawer window
		 */
		public function render_modal() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$manage_active = $data['manageActive'];
			$selected = array_flip($data['selected']);
			?>
			<div class="essb-dr-overlay" id="essb-ns-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-ns-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Automated Network Setup', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-ns-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<h2 class="essb-dr-pane-title" style="display: none;"><?php esc_html_e('Choose your networks', 'essb'); ?></h2>
					<p class="essb-dr-pane-desc"><?php esc_html_e('Pick the social networks that will be used everywhere on your site. Drag to rearrange, click to select or deselect.', 'essb'); ?></p>

					<label class="essb-dr-toggle essb-dr-toggle-large">
						<input type="checkbox" id="essb-ns-manage-toggle" <?php checked($manage_active, true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('I will use only selected networks on the site', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('When enabled, only the networks you select below are available for sharing. Uncheck to keep all installed networks.', 'essb'); ?></span>
						</span>
					</label>

					<div id="essb-ns-networks-panel">

						<div class="essb-dr-note">
							<strong><?php esc_html_e('What this does:', 'essb'); ?></strong> <?php esc_html_e('applies the selected list as the global network list, so the same buttons appear on all display positions, and disables per-position custom network lists.', 'essb'); ?>
						</div>

						<div class="essb-ns-toolbar">
							<input type="text" class="essb-ns-search" id="essb-ns-search" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
						</div>
						<div class="essb-ns-toolbar-actions">
							<button type="button" class="essb-dr-btn essb-dr-btn-ghost essb-dr-btn-sm" id="essb-ns-prefill"><?php esc_html_e('Use my current site networks', 'essb'); ?></button>
							<button type="button" class="essb-dr-btn essb-dr-btn-ghost essb-dr-btn-sm" id="essb-ns-select-all"><?php esc_html_e('Select all', 'essb'); ?></button>
							<button type="button" class="essb-dr-btn essb-dr-btn-ghost essb-dr-btn-sm" id="essb-ns-clear"><?php esc_html_e('Clear', 'essb'); ?></button>
						</div>

						<div class="essb-ns-count"><span id="essb-ns-selected-count">0</span> <?php esc_html_e('selected', 'essb'); ?></div>

						<div class="essb-ns-network-list" id="essb-ns-network-list">
							<?php foreach ($data['networks'] as $network): ?>
								<div class="essb-ns-network-item<?php echo isset($selected[$network['id']]) ? ' essb-ns-network-active' : ''; ?>" data-network="<?php echo esc_attr($network['id']); ?>">
									<span class="essb-ns-network-drag" style="display: none;"><svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 4h6M3 6h6M3 8h6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg></span>
									<span class="essb-ns-network-check"><svg width="10" height="10" viewBox="0 0 10 10" style="display:none;" fill="none"><path d="M8.3 2.3a1 1 0 0 1 0 1.4l-4 4a1 1 0 0 1-1.4 0l-2-2a1 1 0 0 1 1.4-1.4L3.6 5.6l3.3-3.3a1 1 0 0 1 1.4 0z" fill="#fff"/></svg></span>
									<span class="essb-ns-network-icon" style="background:<?php echo esc_attr($network['color']); ?>"><?php echo esc_html(substr($network['name'], 0, 1)); ?></span>
									<span class="essb-ns-network-name"><?php echo esc_html($network['name']); ?></span>
								</div>
							<?php endforeach; ?>
						</div>

					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-ns-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-ns-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Save the selected networks through AJAX
		 */
		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$manage_active = isset($_POST['manage_active']) && $_POST['manage_active'] === 'true';

			$networks = isset($_POST['networks']) && is_array($_POST['networks']) ? $_POST['networks'] : array();
			$networks = array_map('sanitize_key', $networks);
			$networks = array_values(array_filter($networks));

			if (!function_exists('essb_admin_automation_active_networks')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/admin/helpers/automation-helper.php');
			}

			$options = $this->get_options();
			$options = essb_admin_automation_active_networks($options, $networks, $manage_active);

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
