<?php

/**
 * Counter Autoconfig component
 *
 * Hosts the "Automatically setup internal share counters" panel at the top of
 * the Share Counters screen. A single toggle applies a ready-to-use internal
 * counter configuration (no API keys required) and reloads the screen so the
 * manual settings can be hidden while it is active.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Counter_Autoconfig')) {

	class ESSB_Component_Counter_Autoconfig {

		const ID = 'counter-autoconfig';
		const AJAX_ACTION = 'essb_counter_autoconfig_toggle';
		const OPTION = 'automatic_internal_counter_setup';

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'toggle'));
		}

		/**
		 * Whether the automatic setup is currently active
		 */
		public static function is_active() {
			return essb_option_bool_value(self::OPTION);
		}

		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		/**
		 * Networks that have an official counter API - the full list used by the
		 * "overwrite official counters" mode.
		 */
		private function get_api_networks() {
			if (class_exists('ESSB_Component_Internal_Counter')) {
				return array_keys(ESSB_Component_Internal_Counter::get_api_networks());
			}

			return array('facebook', 'pinterest', 'vk', 'ok', 'reddit', 'buffer', 'xing', 'yummly');
		}

		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-counter-autoconfig', ESSB3_PLUGIN_URL . '/lib/admin/components/counter-autoconfig/assets/essb-counter-autoconfig.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-counter-autoconfig', ESSB3_PLUGIN_URL . '/lib/admin/components/counter-autoconfig/assets/essb-counter-autoconfig.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-counter-autoconfig', 'essbCounterAutoconfigData', array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'strings' => array(
					'saved' => esc_html__('Settings saved. Reloading...', 'essb'),
					'error' => esc_html__('Unable to save the settings.', 'essb'),
				),
			));
		}

		/**
		 * Enable / disable the automatic internal counter setup
		 */
		public function toggle() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$active = isset($_POST['active']) && $_POST['active'] === 'true';
			$options = $this->get_options();

			if ($active) {
				$options[self::OPTION] = 'true';
				$options['active_internal_counters'] = 'true';
				$options['active_internal_counters_advanced'] = 'true';
				$options['active_internal_counters_advanced_networks'] = $this->get_api_networks();
				$options['deactive_internal_counters_mail'] = 'true';
				$options['social_proof_enable'] = 'true';
				$options['button_counter_hidden_till'] = '1';
				$options['total_counter_hidden_till'] = '1';
			} else {
				// Deactivation only turns the automatic setup off so the manual
				// settings show again - it does not change any of the individual
				// options that were applied on activation.
				$options[self::OPTION] = '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
