<?php

/**
 * myCred Integration component
 *
 * Drawer interface for the myCred integration options.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Integration_Mycred')) {

	class ESSB_Component_Integration_Mycred {

		const ID = 'integration-mycred';
		const AJAX_ACTION = 'essb_integration_mycred_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($options) {
			return array(
				'mycred_activate'                    => $this->option_is_true($options, 'mycred_activate'),
				'mycred_points'                      => $this->option_value($options, 'mycred_points'),
				'mycred_group'                       => $this->option_value($options, 'mycred_group'),
				'mycred_activate_custom'             => $this->option_is_true($options, 'mycred_activate_custom'),
				'mycred_referral_activate'           => $this->option_is_true($options, 'mycred_referral_activate'),
				'mycred_referral_activate_shortcode' => $this->option_is_true($options, 'mycred_referral_activate_shortcode'),
			);
		}

		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-integration-mycred', ESSB3_PLUGIN_URL . '/lib/admin/components/integration-mycred/assets/essb-integration-mycred.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-integration-mycred', 'essbIntegrationMycredData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $this->get_values($options),
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('myCred integration settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the myCred integration settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-imc-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-imc-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('myCred Integration', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-imc-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Configure integration with the myCred plugin to award users for sharing content.', 'essb'); ?></p>

					<h3 class="essb-dr-heading"><?php esc_html_e('Award users for clicking on share button', 'essb'); ?></h3>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-imc-activate" data-field="mycred_activate" <?php checked($v['mycred_activate'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate myCred integration for click on links', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('In order to work the myCred integration you need to have myCred Points for click on links hook activated (if you use custom points group you need to activated inside custom points group settings).', 'essb'); ?></span>
						</span>
					</label>

					<div class="essb-dr-field essb-dr-field-indent">
						<label class="essb-dr-field-label" for="essb-imc-points"><?php esc_html_e('myCred reward points for share link click', 'essb'); ?></label>
						<input type="text" class="essb-dr-input" id="essb-imc-points" data-field="mycred_points" value="<?php echo esc_attr($v['mycred_points']); ?>">
						<span class="essb-dr-field-desc"><?php esc_html_e('Provide custom points to reward user when share link. If nothing is provided 1 point will be included.', 'essb'); ?></span>
					</div>

					<div class="essb-dr-field essb-dr-field-indent">
						<label class="essb-dr-field-label" for="essb-imc-group"><?php esc_html_e('myCred custom point type', 'essb'); ?></label>
						<input type="text" class="essb-dr-input" id="essb-imc-group" data-field="mycred_group" value="<?php echo esc_attr($v['mycred_group']); ?>">
						<span class="essb-dr-field-desc"><?php esc_html_e('Provide custom meta key for the points that user will get to share link. To create your own please visit this tutorial: http://codex.mycred.me/get-started/multiple-point-types/. Leave blank to use the default (mycred_default)', 'essb'); ?></span>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-imc-activate-custom" data-field="mycred_activate_custom" <?php checked($v['mycred_activate_custom'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate myCred integration for points for social sharing via the Easy Social Share Buttons for WordPress hook', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Use Easy Social Share Buttons custom hook in myCred to award points for click on share buttons', 'essb'); ?></span>
						</span>
					</label>

					<h3 class="essb-dr-heading"><?php esc_html_e('Award users when someone uses their share link', 'essb'); ?></h3>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-imc-referral-activate" data-field="mycred_referral_activate" <?php checked($v['mycred_referral_activate'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate myCred Referral usage', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('That option requires you to have the Points for referrals hook enabled. That option is not compatible with share counters because adding referral id to url will reset social share counters to zero.', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-imc-referral-shortcode" data-field="mycred_referral_activate_shortcode" <?php checked($v['mycred_referral_activate_shortcode'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate myCred Referral usage in shortcodes', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Activate this option in combination with referrals hook to allow affiliate ID appear also when you use shortcodes.', 'essb'); ?></span>
						</span>
					</label>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-imc-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-imc-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$fields = array(
				'mycred_activate',
				'mycred_points',
				'mycred_group',
				'mycred_activate_custom',
				'mycred_referral_activate',
				'mycred_referral_activate_shortcode',
			);

			foreach ($fields as $key) {
				$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
