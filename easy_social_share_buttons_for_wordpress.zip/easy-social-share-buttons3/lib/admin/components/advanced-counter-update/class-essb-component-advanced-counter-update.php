<?php

/**
 * Advanced Counter Update component
 *
 * Drawer interface for the advanced share counter update options: background
 * update when a cache is used, asynchronous update, bypassing the internal
 * cache, narrowing down updates for popular posts and request logging.
 * Replaces the legacy inline "Advanced counter update options" panel.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Advanced_Counter_Update')) {

	class ESSB_Component_Advanced_Counter_Update {

		const ID = 'advanced-counter-update';
		const AJAX_ACTION = 'essb_advanced_counter_update_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		/**
		 * Switch options managed by this component. Stored as 'true' or ''.
		 */
		private function get_fields() {
			return array(
				'cache_counter_refresh_cache' => array(
					'title' => esc_html__('Force counter update on the background when a cache plugin/server is used', 'essb'),
					'desc'  => esc_html__('The option will add code to update share counters on the backend even when the site is cached. Your visitors will see the change when the cache expires. Warning! This option may generate a high server load - use with caution.', 'essb'),
				),
				'cache_counter_refresh_async' => array(
					'title' => esc_html__('Speed up process of counters update', 'essb'),
					'desc'  => esc_html__('Enable via an external library asynchronous counter update mode which is up to 5 times faster than the regular update. Requires PHP 5.4 or newer and does not work with PHP 8.', 'essb'),
				),
				'cache_counter_force' => array(
					'title' => esc_html__('Always save the share counter value without using the internal cache', 'essb'),
					'desc'  => esc_html__('The option will eliminate the internal cache and save the value from the social network even it is smaller from the past successful update. Warning! Use with caution - without the cache of counters, your site may show zero shares when there are such.', 'essb'),
				),
				'cache_counter_narrow' => array(
					'title' => esc_html__('Narrow down the number of share counter updates for a post/page', 'essb'),
					'desc'  => esc_html__('This option will add an additional check to updated posts to ensure that popular posts will not update so frequently. This will allow to update less popular posts by reserving additional ticks for them.', 'essb'),
				),
				'cache_counter_logging' => array(
					'title' => esc_html__('Log counter update requests', 'essb'),
					'desc'  => esc_html__('Save information for the last 99 requests for a counter update. That helps to detect potential configuration or connection problems. The logging is not compatible with the Speed up process of the counters update option.', 'essb'),
				),
			);
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Load the current plugin options
		 */
		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		/**
		 * Save the plugin options
		 */
		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-advanced-counter-update', ESSB3_PLUGIN_URL . '/lib/admin/components/advanced-counter-update/assets/essb-advanced-counter-update.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-advanced-counter-update', 'essbAdvancedCounterUpdateData', $this->get_localized_data());
		}

		/**
		 * Data used by the component interface
		 */
		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$values = array();
			foreach (array_keys($this->get_fields()) as $key) {
				$values[$key] = $this->option_is_true($options, $key);
			}

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $values,
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('Advanced counter update options saved.', 'essb'),
					'error'  => esc_html__('Unable to save the advanced counter update options.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		/**
		 * Render the component drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-acu-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-acu-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Advanced counter update options', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-acu-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Configure different advanced counter update functions of plugin when you use real time or cached counters.', 'essb'); ?></p>

					<div class="essb-dr-note">
						<strong><?php esc_html_e('Use with caution:', 'essb'); ?></strong> <?php esc_html_e('these functions change how the plugin requests and stores share counters and may increase the load on your server.', 'essb'); ?>
					</div>

					<?php foreach ($this->get_fields() as $key => $field) : ?>
						<label class="essb-dr-toggle">
							<input type="checkbox" id="essb-acu-<?php echo esc_attr($key); ?>" data-field="<?php echo esc_attr($key); ?>" <?php checked($v[$key], true); ?>>
							<span class="essb-dr-toggle-track"></span>
							<span class="essb-dr-toggle-content">
								<span class="essb-dr-toggle-label"><?php echo esc_html($field['title']); ?></span>
								<span class="essb-dr-toggle-desc"><?php echo esc_html($field['desc']); ?></span>
							</span>
						</label>
					<?php endforeach; ?>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-acu-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-acu-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Save the advanced counter update options through AJAX
		 */
		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			foreach (array_keys($this->get_fields()) as $key) {
				$options[$key] = (isset($_POST[$key]) && $_POST[$key] === 'true') ? 'true' : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
