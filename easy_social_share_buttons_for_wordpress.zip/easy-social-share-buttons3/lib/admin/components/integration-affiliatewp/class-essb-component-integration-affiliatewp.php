<?php

/**
 * AffiliateWP Integration component
 *
 * Drawer interface for the AffiliateWP integration options.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Integration_Affiliatewp')) {

	class ESSB_Component_Integration_Affiliatewp {

		const ID = 'integration-affiliatewp';
		const AJAX_ACTION = 'essb_integration_affiliatewp_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($options) {
			return array(
				'affwp_active'        => $this->option_is_true($options, 'affwp_active'),
				'affwp_active_mode'   => $this->option_value($options, 'affwp_active_mode'),
				'affwp_active_shortcode' => $this->option_is_true($options, 'affwp_active_shortcode'),
				'affwp_active_pretty' => $this->option_is_true($options, 'affwp_active_pretty'),
				'affwp_bridge_short'  => $this->option_is_true($options, 'affwp_bridge_short'),
			);
		}

		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-integration-affiliatewp', ESSB3_PLUGIN_URL . '/lib/admin/components/integration-affiliatewp/assets/essb-integration-affiliatewp.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-integration-affiliatewp', 'essbIntegrationAffiliatewpData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $this->get_values($options),
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('AffiliateWP integration settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the AffiliateWP integration settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-iaf-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-iaf-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('AffiliateWP Integration', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-iaf-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Configure integration with the AffiliateWP plugin to share links that contain an affiliate (referral parameter).', 'essb'); ?></p>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-iaf-active" data-field="affwp_active" <?php checked($v['affwp_active'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Append Affiliate ID to shared address', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Automatically appends an affiliate\'s ID to Easy Social Share Buttons sharing links that are generated. You need to have installed AffiliateWP plugin to use it', 'essb'); ?></span>
						</span>
					</label>

					<div class="essb-dr-field essb-dr-field-indent">
						<label class="essb-dr-field-label" for="essb-iaf-mode"><?php esc_html_e('ID Append Mode', 'essb'); ?></label>
						<select class="essb-dr-select" id="essb-iaf-mode" data-field="affwp_active_mode">
							<option value="id" <?php selected($v['affwp_active_mode'], 'id'); ?>><?php esc_html_e('User ID', 'essb'); ?></option>
							<option value="name" <?php selected($v['affwp_active_mode'], 'name'); ?>><?php esc_html_e('Username', 'essb'); ?></option>
						</select>
						<span class="essb-dr-field-desc"><?php esc_html_e('Choose between usage of user id or username when you add affiliate id to outgoing shares.', 'essb'); ?></span>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-iaf-shortcode" data-field="affwp_active_shortcode" <?php checked($v['affwp_active_shortcode'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Append Affiliate ID to shortcodes', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Automatically appends an affiliate\'s ID to Easy Social Share Buttons sharing links that are generated when shortcode has a custom url parameter.', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-iaf-pretty" data-field="affwp_active_pretty" <?php checked($v['affwp_active_pretty'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Use pretty affiliate URLs', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Activate this option if you already have make it active inside AffiliateWP to allow Easy Social Share Buttons generate pretty affiliate URLs.', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-iaf-bridge" data-field="affwp_bridge_short" <?php checked($v['affwp_bridge_short'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Generate separate short URL when affiliate ID is added', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('The option will integrate the affiliate ID checks inside short URL generation. This will help to build a separate short URL for each of the affiliate users. The option works only if the short URL option inside the plugin is enabled.', 'essb'); ?></span>
						</span>
					</label>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-iaf-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-iaf-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$fields = array(
				'affwp_active',
				'affwp_active_mode',
				'affwp_active_shortcode',
				'affwp_active_pretty',
				'affwp_bridge_short',
			);

			foreach ($fields as $key) {
				$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
