<?php

/**
 * Network Visibility component
 *
 * Drawer interface for controlling the per-network device visibility
 * across desktop, tablet and mobile. Replaces the legacy
 * advanced-networks-visibility window and the automatic-responsive-networks
 * automation.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Network_Visibility')) {

	class ESSB_Component_Network_Visibility {

		const ID = 'network-visibility';
		const AJAX_ACTION = 'essb_network_visibility_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Load the current plugin options
		 */
		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		/**
		 * Save the plugin options
		 */
		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-network-visibility', ESSB3_PLUGIN_URL . '/lib/admin/components/network-visibility/assets/essb-network-visibility.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-network-visibility', ESSB3_PLUGIN_URL . '/lib/admin/components/network-visibility/assets/essb-network-visibility.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-network-visibility', 'essbNetworkVisibilityData', $this->get_localized_data());
		}

		/**
		 * Data used by the component interface
		 */
		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$activate = isset($options['activate_networks_responsive']) && $options['activate_networks_responsive'] == 'true';

			$colors = $this->get_network_colors();

			$networks = array();
			$all_networks = essb_available_social_networks(false);
			if (is_array($all_networks)) {
				foreach ($all_networks as $network_id => $network_data) {
					$networks[] = array(
						'id'      => $network_id,
						'name'    => isset($network_data['name']) ? $network_data['name'] : $network_id,
						'color'   => isset($colors[$network_id]) ? $colors[$network_id] : '#6b7280',
						'desktop' => isset($options['responsive_' . $network_id . '_desktop']) && $options['responsive_' . $network_id . '_desktop'] == 'true',
						'mobile'  => isset($options['responsive_' . $network_id . '_mobile']) && $options['responsive_' . $network_id . '_mobile'] == 'true',
					);
				}
			}

			$data = array(
				'nonce'    => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl'  => admin_url('admin-ajax.php'),
				'activate' => $activate,
				'networks' => $networks,
				'strings'  => array(
					'save'      => esc_html__('Save', 'essb'),
					'saving'    => esc_html__('Saving...', 'essb'),
					'saved'     => esc_html__('Network visibility settings saved.', 'essb'),
					'suggested' => esc_html__('Visibility suggestions applied. Review and save when ready.', 'essb'),
					'reset'     => esc_html__('All device visibility selections cleared.', 'essb'),
					'error'     => esc_html__('Unable to save the network visibility settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		private function get_network_colors() {
			if (class_exists('ESSB_Share_Button_Styles')) {
				return ESSB_Share_Button_Styles::get_network_colors();
			}

			return array();
		}

		/**
		 * Render the component drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$activate = $data['activate'];
			?>
			<div class="essb-dr-overlay" id="essb-nv-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-nv-drawer">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Network Device Visibility', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-nv-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<h2 class="essb-dr-pane-title" style="display: none;"><?php esc_html_e('Choose where each network appears', 'essb'); ?></h2>
					<p class="essb-dr-pane-desc"><?php esc_html_e('Hide selected social networks on desktop or mobile devices. Networks with no device hidden are shown everywhere.', 'essb'); ?></p>

					<label class="essb-dr-toggle essb-dr-toggle-large">
						<input type="checkbox" id="essb-nv-activate" <?php checked($activate, true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate network device visibility control', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('When enabled, networks marked below are hidden on the corresponding devices.', 'essb'); ?></span>
						</span>
					</label>

					<div id="essb-nv-panel">

						<div class="essb-dr-note">
							<strong><?php esc_html_e('How it works:', 'essb'); ?></strong> <?php esc_html_e('Check "Hide on Desktop" to remove a network from desktop screens, or "Hide on Mobile" to remove it from phones and tablets. Leave both unchecked to show a network everywhere.', 'essb'); ?>
						</div>

						<div class="essb-nv-toolbar">
							<input type="text" class="essb-nv-search" id="essb-nv-search" placeholder="<?php esc_attr_e('Search networks...', 'essb'); ?>">
						</div>
						<div class="essb-nv-actions">
							<button type="button" class="essb-dr-btn essb-dr-btn-sm essb-nv-btn-suggest" id="essb-nv-suggest"><?php esc_html_e('Suggest visibility', 'essb'); ?></button>
							<button type="button" class="essb-dr-btn essb-dr-btn-sm essb-nv-btn-reset" id="essb-nv-reset" title="<?php esc_attr_e('Clear all selections', 'essb'); ?>"><?php esc_html_e('Reset', 'essb'); ?></button>
						</div>

						<div class="essb-nv-list-head">
							<span><?php esc_html_e('Network', 'essb'); ?></span>
							<span><?php esc_html_e('Hide on Desktop', 'essb'); ?></span>
							<span><?php esc_html_e('Hide on Mobile', 'essb'); ?></span>
						</div>

						<div class="essb-nv-list" id="essb-nv-list">
							<?php foreach ($data['networks'] as $network): ?>
								<div class="essb-nv-network-item" data-network="<?php echo esc_attr($network['id']); ?>">
									<span class="essb-nv-network-cell">
										<span class="essb-nv-network-id" style="background:<?php echo esc_attr($network['color']); ?>"><?php echo esc_html(substr($network['name'], 0, 1)); ?></span>
										<span class="essb-nv-network-name"><?php echo esc_html($network['name']); ?></span>
									</span>
									<label class="essb-dr-toggle essb-dr-toggle-sm essb-nv-device essb-nv-device-desktop" title="<?php esc_attr_e('Hide on Desktop', 'essb'); ?>">
										<input type="checkbox" class="essb-nv-desktop-input" <?php checked($network['desktop'], true); ?>>
										<span class="essb-dr-toggle-track"></span>
									</label>
									<label class="essb-dr-toggle essb-dr-toggle-sm essb-nv-device essb-nv-device-mobile" title="<?php esc_attr_e('Hide on Mobile', 'essb'); ?>">
										<input type="checkbox" class="essb-nv-mobile-input" <?php checked($network['mobile'], true); ?>>
										<span class="essb-dr-toggle-track"></span>
									</label>
								</div>
							<?php endforeach; ?>
						</div>

					</div>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-nv-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-nv-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Save the network visibility settings through AJAX
		 */
		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$activate = isset($_POST['activate']) && $_POST['activate'] === 'true';

			$networks = isset($_POST['networks']) && is_array($_POST['networks']) ? $_POST['networks'] : array();

			$options = $this->get_options();
			$options['activate_networks_responsive'] = $activate ? 'true' : '';

			$all_networks = essb_available_social_networks(false);
			if (is_array($all_networks)) {
				foreach (array_keys($all_networks) as $network_id) {
					unset($options['responsive_' . $network_id . '_desktop']);
					unset($options['responsive_' . $network_id . '_mobile']);
				}
			}

			foreach ($networks as $entry) {
				if (!is_array($entry)) {
					continue;
				}

				$id = isset($entry['id']) ? sanitize_key($entry['id']) : '';
				if ($id == '') {
					continue;
				}

				if (isset($entry['desktop']) && $entry['desktop'] === 'true') {
					$options['responsive_' . $id . '_desktop'] = 'true';
				}

				if (isset($entry['mobile']) && $entry['mobile'] === 'true') {
					$options['responsive_' . $id . '_mobile'] = 'true';
				}
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
