<?php

/**
 * Counter Options component
 *
 * Schema-driven drawer component that hosts the "Additional Share Counter
 * Options & Features" drawers: avoid negative social proof, share count
 * recovery, additional counter display rules and fake share counters, plus the
 * "Advanced Open Graph Options" drawer. Replaces the legacy advanced settings
 * windows built from the matching ao-*.php files.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Counter_Options')) {

	class ESSB_Component_Counter_Options {

		const ID = 'counter-options';
		const AJAX_ACTION = 'essb_counter_options_save';
		const AJAX_TOGGLE = 'essb_counter_options_toggle';

		private $localized_data = null;
		private $drawers = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
			add_action('wp_ajax_' . self::AJAX_TOGGLE, array($this, 'toggle'));
		}

		/**
		 * Drawer definitions. Field types: heading, switch, select, input, hint.
		 * "when" makes a field visible only while the referenced switch is on.
		 */
		private function get_drawers() {
			if (null !== $this->drawers) {
				return $this->drawers;
			}

			$recover_type = array(
				'unchanged'      => esc_html__('Unchanged', 'essb'),
				'default'        => esc_html__('Plain', 'essb'),
				'day_and_name'   => esc_html__('Day and Name', 'essb'),
				'month_and_name' => esc_html__('Month and Name', 'essb'),
				'numeric'        => esc_html__('Numeric', 'essb'),
				'post_name'      => esc_html__('Post Name', 'essb'),
				'custom'         => esc_html__('Custom', 'essb'),
				'current'        => esc_html__('Standard URLs', 'essb'),
			);

			$recover_protocol = array(
				'unchanged'  => esc_html__('Unchanged', 'essb'),
				'http2https' => esc_html__('Switch from http to https', 'essb'),
				'https2http' => esc_html__('Switch from https to http', 'essb'),
			);

			$recover_prefix = array(
				'unchanged' => esc_html__('Unchanged', 'essb'),
				'www'       => esc_html__('www', 'essb'),
				'nonwww'    => esc_html__('non-www', 'essb'),
			);

			$this->drawers = array(
				'avoid-negative-proof' => array(
					'title'  => esc_html__('Avoid negative social proof', 'essb'),
					'desc'   => esc_html__('Avoid social negative proof allows you to hide button counters or total counter till a defined value of shares is reached.', 'essb'),
					'fields' => array(
						array('type' => 'hint', 'label' => esc_html__('Enable', 'essb'), 'desc' => esc_html__('Use the toggle next to the Configure button to enable or disable this feature. Below you can adjust the minimal share values used while the feature is active.', 'essb')),
						array('type' => 'input', 'key' => 'button_counter_hidden_till', 'label' => esc_html__('Minimal share value to display single button counter', 'essb'), 'desc' => esc_html__('Fill the minimal number of shares - example 10. If you leave it blank the counter will always appear. If you need to hide only zero-based shares place 1 in the field.', 'essb')),
						array('type' => 'input', 'key' => 'total_counter_hidden_till', 'label' => esc_html__('Minimal share value to display total counter', 'essb'), 'desc' => esc_html__('Fill the minimal number of shares - example 10. If you leave it blank the counter will always appear. If you need to hide only zero-based shares place 1 in the field.', 'essb')),
					),
				),
				'share-recovery' => array(
					'title'  => esc_html__('Share count recovery', 'essb'),
					'desc'   => esc_html__('Share counter recovery allows you restore back shares once you make a permalink change (including installing a SSL certificate). Share recovery will show back shares only if they are present for both versions of URL (before and after change).', 'essb'),
					'fields' => array(
						array('type' => 'hint', 'label' => esc_html__('Enable', 'essb'), 'desc' => esc_html__('Use the toggle next to the Configure button to enable or disable this feature. The toggle shows Active or Not active. Below you can adjust the recovery options.', 'essb')),
						array('type' => 'select', 'key' => 'counter_recover_mode', 'label' => esc_html__('Previous url format', 'essb'), 'desc' => esc_html__('Choose how your site address is changed. If you choose custom use the field below to setup your URL structure', 'essb'), 'options' => $recover_type),
						array('type' => 'input', 'key' => 'counter_recover_custom', 'label' => esc_html__('Custom Permalink Format', 'essb'), 'desc' => ''),
						array('type' => 'select', 'key' => 'counter_recover_protocol', 'label' => esc_html__('Change of connection protocol', 'essb'), 'desc' => esc_html__('If you change your connection protocol then choose here the option that describes it.', 'essb'), 'options' => $recover_protocol),
						array('type' => 'select', 'key' => 'counter_recover_prefixdomain', 'label' => esc_html__('Previous Domain Prefix', 'essb'), 'desc' => esc_html__('If you make a change of your domain prefix than you need to describe it here.', 'essb'), 'options' => $recover_prefix),
						array('type' => 'input', 'key' => 'counter_recover_subdomain', 'label' => esc_html__('Subdomain', 'essb'), 'desc' => esc_html__('If you move your site to a subdomain enter here its name (without prefix and extra symbols)', 'essb')),
						array('type' => 'hint', 'label' => esc_html__('Cross-domain recovery', 'essb'), 'desc' => esc_html__('If you\'ve migrated your website from one domain to another, fill in these two fields to activate cross-domain share recovery', 'essb')),
						array('type' => 'input', 'key' => 'counter_recover_domain', 'label' => esc_html__('Previous domain name', 'essb'), 'desc' => esc_html__('If you have changed your domain name please fill in this field previous domain name with protocol (example http://example.com) and choose recovery mode to be Change domain name', 'essb')),
						array('type' => 'input', 'key' => 'counter_recover_newdomain', 'label' => esc_html__('New domain name', 'essb'), 'desc' => esc_html__('If plugin is not able to detect your new domain fill here its name with protocol (example http://example.com)', 'essb')),
						array('type' => 'input', 'key' => 'counter_recover_date', 'label' => esc_html__('Date of change', 'essb'), 'desc' => esc_html__('Fill out date when change was made. Once you fill it share counter recovery will be made for all posts that are published before this date. Date should be filled in format yyyy-mm-dd.', 'essb')),
					),
				),
				'other-counter' => array(
					'title'  => esc_html__('Additional counter display rules', 'essb'),
					'desc'   => esc_html__('Configure additional options for share counter display, update, etc.', 'essb'),
					'fields' => array(
						array('type' => 'heading', 'label' => esc_html__('Homepage counter', 'essb')),
						array('type' => 'switch', 'key' => 'homepage_total_allposts', 'label' => esc_html__('Share counter on the homepage is from the shares of all posts and pages', 'essb'), 'desc' => esc_html__('Enable this option to make your homepage show share counters based on the values plugin stores for each of the posts on site.', 'essb')),
						array('type' => 'switch', 'key' => 'site_total_allposts', 'label' => esc_html__('Share counter on entire site is from the shares of all posts and pages', 'essb'), 'desc' => esc_html__('Enable this option to make each post/page from your site show share counters based on the values plugin stores for each of the posts on site.', 'essb')),
						array('type' => 'input', 'key' => 'homepage_total_cache', 'label' => esc_html__('Cache for the total counter on the homepage/site', 'essb'), 'desc' => esc_html__('Modify the default caching value of 30 minutes. Fill in just a numeric value representing minutes - example: 60. Avoid using too small values because you can overload the database server.', 'essb')),
						array('type' => 'heading', 'label' => esc_html__('Hide counter on archives / homepage', 'essb')),
						array('type' => 'switch', 'key' => 'hide_counter_homepage', 'label' => esc_html__('Do not show share counters on the homepage', 'essb'), 'desc' => ''),
						array('type' => 'switch', 'key' => 'hide_counter_archive', 'label' => esc_html__('Do not show share counters on archive pages (category, tags, authors, etc.)', 'essb'), 'desc' => ''),
					),
				),
				'share-fake' => array(
					'title'  => esc_html__('Fake share counters', 'essb'),
					'desc'   => esc_html__('Increase the number of shares with a multiplier (fake values). As an addition, you can also change the values to internal counters for all networks.', 'essb'),
					'fields' => array(
						array('type' => 'switch', 'key' => 'activate_fake_counters', 'label' => esc_html__('Activate fake share counters', 'essb'), 'desc' => esc_html__('All options inside the fake section will not work unless this switch is set to Yes.', 'essb')),
						array('type' => 'input', 'key' => 'fake_counter_correction', 'label' => esc_html__('Counter increase value', 'essb'), 'desc' => esc_html__('Set a numeric value that will be used to increase the number of existing shares. Example if you set 5 the existing shares will be multiplied with 5: if you have 100 real shares, the plugin will show 500.', 'essb'), 'when' => 'activate_fake_counters'),
						array('type' => 'switch', 'key' => 'activate_fake_counters_internal', 'label' => esc_html__('Integrate official API share counters with internal counters', 'essb'), 'desc' => esc_html__('The integration will compare both - official and internal value of shares. And it will show always the greater of them to the front-end.', 'essb')),
					),
				),
				'facebook-ogtags' => array(
					'title'  => esc_html__('Advanced Open Graph Options', 'essb'),
					'desc'   => '',
					'fields' => array(
						array('type' => 'heading', 'label' => esc_html__('Advanced', 'essb')),
						array('type' => 'switch', 'key' => 'sso_advanced_tags', 'label' => esc_html__('Enable advanced Facebook tag fields', 'essb'), 'desc' => ''),
						array('type' => 'input', 'key' => 'opengraph_tags_fbpage', 'label' => esc_html__('Facebook Page URL', 'essb'), 'desc' => '', 'when' => 'sso_advanced_tags'),
						array('type' => 'input', 'key' => 'opengraph_tags_fbadmins', 'label' => esc_html__('Facebook Admins', 'essb'), 'desc' => esc_html__('Enter IDs of Facebook Users that are admins of current page.', 'essb'), 'when' => 'sso_advanced_tags'),
						array('type' => 'input', 'key' => 'opengraph_tags_fbapp', 'label' => esc_html__('Facebook Application ID', 'essb'), 'desc' => esc_html__('Enter ID of Facebook Application to be able to use Facebook Insights', 'essb'), 'when' => 'sso_advanced_tags'),
						array('type' => 'input', 'key' => 'opengraph_tags_fbauthor', 'label' => esc_html__('Facebook Author Profile', 'essb'), 'desc' => '', 'when' => 'sso_advanced_tags'),
						array('type' => 'heading', 'label' => esc_html__('Images', 'essb')),
						array('type' => 'switch', 'key' => 'sso_external_images', 'label' => esc_html__('Allow external images', 'essb'), 'desc' => esc_html__('Include a text field where you can provide the image URL. By default, the plugin allows only the usage of images located in the WordPress media library.', 'essb')),
						array('type' => 'switch', 'key' => 'sso_multipleimages', 'label' => esc_html__('Allow multiple images', 'essb'), 'desc' => esc_html__('Add fields for up to 5 additional images you can select for social media sharing.', 'essb')),
						array('type' => 'switch', 'key' => 'sso_gifimages', 'label' => esc_html__('GIF images support', 'essb'), 'desc' => esc_html__('Set Yes if you have featured image animated GIF images (not required for static GIF images).', 'essb')),
						array('type' => 'heading', 'label' => esc_html__('WooCommerce', 'essb')),
						array('type' => 'switch', 'key' => 'sso_deactivate_woogallery', 'label' => esc_html__('Deactivate gallery integration', 'essb'), 'desc' => esc_html__('Don\'t include in the social media tags the gallery images.', 'essb')),
						array('type' => 'switch', 'key' => 'sso_deactivate_woocommerce', 'label' => esc_html__('Deactivate product tags', 'essb'), 'desc' => esc_html__('Don\'t create product-specific tags - price, availability, promotion, etc. Enabling the option won\'t prevent your products from sharing - they just will have the regular tags like a post or page (not like a product).', 'essb')),
						array('type' => 'heading', 'label' => esc_html__('Expert', 'essb')),
						array('type' => 'switch', 'key' => 'sso_httpshttp', 'label' => esc_html__('Use http version of page in social tags', 'essb'), 'desc' => esc_html__('If you recently move from http to https and realize that shares are gone please activate this option and check are they back.', 'essb')),
						array('type' => 'switch', 'key' => 'sso_apply_the_content', 'label' => esc_html__('Extract full content when generating description', 'essb'), 'desc' => esc_html__('If you see shortcodes in your description activate this option to extract as full rendered content. Warning! Activation of this option may affect work of other plugins or may lead to missing share buttons. If you notice something that is not OK with site immediately deactivate it.', 'essb')),
					),
				),
			);

			return $this->drawers;
		}

		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($drawer_id, $options) {
			$values = array();
			foreach ($this->get_drawers()[$drawer_id]['fields'] as $field) {
				if (empty($field['key'])) {
					continue;
				}

				$key = $field['key'];
				if ($field['type'] == 'switch') {
					$values[$key] = $this->option_is_true($options, $key);
				} else if ($field['type'] == 'select' || $field['type'] == 'input') {
					$values[$key] = $this->option_value($options, $key);
				}
			}

			return $values;
		}

		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-counter-options', ESSB3_PLUGIN_URL . '/lib/admin/components/counter-options/assets/essb-counter-options.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-counter-options', 'essbCounterOptionsData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();
			$drawers = array();
			foreach ($this->get_drawers() as $drawer_id => $drawer) {
				$drawers[$drawer_id] = array('values' => $this->get_values($drawer_id, $options));
			}

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'drawers' => $drawers,
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('Settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		private function render_field($drawer_id, $field, $values) {
			$type = isset($field['type']) ? $field['type'] : '';
			$key = isset($field['key']) ? $field['key'] : '';
			$label = isset($field['label']) ? $field['label'] : '';
			$desc = isset($field['desc']) ? $field['desc'] : '';
			$when = isset($field['when']) ? $field['when'] : '';
			$when_attr = $when != '' ? ' data-when="' . esc_attr($when) . '"' : '';
			$field_id = 'essb-co-' . $drawer_id . '-' . $key;

			if ($type == 'heading') {
				echo '<h3 class="essb-dr-heading">' . esc_html($label) . '</h3>';
				return;
			}

			if ($type == 'hint') {
				echo '<div class="essb-dr-note"' . $when_attr . '><strong>' . esc_html($label) . ':</strong> ' . esc_html($desc) . '</div>';
				return;
			}

			if ($type == 'switch') {
				$checked = !empty($values[$key]);
				echo '<label class="essb-dr-toggle"' . $when_attr . '>';
				echo '<input type="checkbox" id="' . esc_attr($field_id) . '" data-field="' . esc_attr($key) . '" ' . checked($checked, true, false) . '>';
				echo '<span class="essb-dr-toggle-track"></span>';
				echo '<span class="essb-dr-toggle-content">';
				echo '<span class="essb-dr-toggle-label">' . esc_html($label) . '</span>';
				if ($desc != '') {
					echo '<span class="essb-dr-toggle-desc">' . esc_html($desc) . '</span>';
				}
				echo '</span>';
				echo '</label>';
				return;
			}

			echo '<div class="essb-dr-field"' . $when_attr . '>';
			echo '<label class="essb-dr-field-label" for="' . esc_attr($field_id) . '">' . esc_html($label) . '</label>';

			if ($type == 'select') {
				$current = isset($values[$key]) ? $values[$key] : '';
				echo '<select class="essb-dr-select" id="' . esc_attr($field_id) . '" data-field="' . esc_attr($key) . '">';
				foreach ($field['options'] as $option_value => $option_label) {
					echo '<option value="' . esc_attr($option_value) . '" ' . selected($current, $option_value, false) . '>' . esc_html($option_label) . '</option>';
				}
				echo '</select>';
			} else {
				$current = isset($values[$key]) ? $values[$key] : '';
				echo '<input type="text" class="essb-dr-input" id="' . esc_attr($field_id) . '" data-field="' . esc_attr($key) . '" value="' . esc_attr($current) . '">';
			}

			if ($desc != '') {
				echo '<span class="essb-dr-field-desc">' . esc_html($desc) . '</span>';
			}
			echo '</div>';
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$options = $this->get_options();

			foreach ($this->get_drawers() as $drawer_id => $drawer) {
				$values = $this->get_values($drawer_id, $options);
				?>
				<div class="essb-dr-overlay" id="essb-co-<?php echo esc_attr($drawer_id); ?>-overlay"></div>
				<div class="essb-dr-drawer essb-ui" id="essb-co-<?php echo esc_attr($drawer_id); ?>-wrap" data-drawer="<?php echo esc_attr($drawer_id); ?>">

					<div class="essb-dr-header">
						<div class="essb-dr-title"><?php echo esc_html($drawer['title']); ?></div>
						<button type="button" class="essb-dr-close" data-drawer-close="<?php echo esc_attr($drawer_id); ?>" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
					</div>

					<div class="essb-dr-body">
						<?php if (!empty($drawer['desc'])) : ?>
							<p class="essb-dr-pane-desc"><?php echo esc_html($drawer['desc']); ?></p>
						<?php endif; ?>

						<?php
						foreach ($drawer['fields'] as $field) {
							$this->render_field($drawer_id, $field, $values);
						}
						?>
					</div>

					<div class="essb-dr-footer">
						<button type="button" class="essb-dr-btn essb-dr-btn-primary" data-drawer-save="<?php echo esc_attr($drawer_id); ?>"><?php esc_html_e('Save', 'essb'); ?></button>
						<button type="button" class="essb-dr-btn essb-dr-btn-ghost" data-drawer-close="<?php echo esc_attr($drawer_id); ?>"><?php esc_html_e('Cancel', 'essb'); ?></button>
					</div>

				</div>
				<?php
			}
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$drawer_id = isset($_POST['drawer']) ? sanitize_key(wp_unslash($_POST['drawer'])) : '';
			$drawers = $this->get_drawers();
			if (!isset($drawers[$drawer_id])) {
				wp_send_json_error(array('message' => esc_html__('Unknown settings section.', 'essb')));
			}

			$options = $this->get_options();

			foreach ($drawers[$drawer_id]['fields'] as $field) {
				if (empty($field['key'])) {
					continue;
				}

				$key = $field['key'];
				if ($field['type'] == 'switch') {
					$options[$key] = (isset($_POST[$key]) && $_POST[$key] === 'true') ? 'true' : '';
				} else if ($field['type'] == 'select' || $field['type'] == 'input') {
					$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
				}
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}

		/**
		 * Toggle a panel switch. Used by the avoid negative social proof and
		 * share count recovery panels: the panel toggle persists its option and
		 * returns the matching drawer values. Enabling avoid negative social
		 * proof also seeds the two value fields with 1 when they are blank so
		 * the feature works immediately.
		 */
		public function toggle() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$key = isset($_POST['key']) ? sanitize_key(wp_unslash($_POST['key'])) : '';
			$value = isset($_POST['value']) && $_POST['value'] === 'true';

			$toggle_map = array(
				'social_proof_enable'    => 'avoid-negative-proof',
				'counter_recover_active' => 'share-recovery',
			);

			if (!isset($toggle_map[$key])) {
				wp_send_json_error(array('message' => esc_html__('Unknown setting.', 'essb')));
			}

			$panel = $toggle_map[$key];

			$options = $this->get_options();
			$options[$key] = $value ? 'true' : '';

			if ($key == 'social_proof_enable' && $value) {
				if (!isset($options['button_counter_hidden_till']) || $options['button_counter_hidden_till'] === '') {
					$options['button_counter_hidden_till'] = '1';
				}
				if (!isset($options['total_counter_hidden_till']) || $options['total_counter_hidden_till'] === '') {
					$options['total_counter_hidden_till'] = '1';
				}
			}

			$this->save_options($options);

			wp_send_json_success(array(
				'values' => $this->get_values($panel, $options),
				'badge'  => array(
					'label'   => $value ? esc_html__('Running', 'essb') : esc_html__('Not Running', 'essb'),
					'primary' => $value,
				),
			));
		}
	}
}
