<?php

/**
 * Google Analytics Tracking component
 *
 * Drawer interface for the Google Analytics tracking options: UTM parameters,
 * tracking method, GTM data layer events and News Tagging Guide.
 * Replaces the legacy "Google Analytics Tracking" advanced settings window.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Google_Analytics')) {

	class ESSB_Component_Google_Analytics {

		const ID = 'google-analytics';
		const AJAX_ACTION = 'essb_google_analytics_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($options) {
			return array(
				'activate_ga_tracking'     => $this->option_is_true($options, 'activate_ga_tracking'),
				'ga_tracking_mode'        => $this->option_value($options, 'ga_tracking_mode'),
				'activate_ga_layers'       => $this->option_is_true($options, 'activate_ga_layers'),
				'activate_utm'             => $this->option_is_true($options, 'activate_utm'),
				'activate_utm_source'      => $this->option_value($options, 'activate_utm_source'),
				'activate_utm_medium'      => $this->option_value($options, 'activate_utm_medium'),
				'activate_utm_name'        => $this->option_value($options, 'activate_utm_name'),
				'activate_ga_ntg_tracking' => $this->option_is_true($options, 'activate_ga_ntg_tracking'),
			);
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-google-analytics', ESSB3_PLUGIN_URL . '/lib/admin/components/google-analytics/assets/essb-google-analytics.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-google-analytics', 'essbGoogleAnalyticsData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $this->get_values($options),
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('Google Analytics tracking options saved.', 'essb'),
					'error'  => esc_html__('Unable to save the Google Analytics tracking options.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-ga-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-ga-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Google Analytics Tracking', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-ga-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Attach UTM parameters to the shared URLs or enable Events tracking. UTM parameters allow you to track the source of the traffic for your social shares in Google Analytics.', 'essb'); ?></p>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-ga-tracking" data-field="activate_ga_tracking" <?php checked($v['activate_ga_tracking'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate Google Analytics tracking', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Enable tracking via universal analytics or the Google Tag Manager. The analytics code should already be present on the page (the plugin will only send the events).', 'essb'); ?></span>
						</span>
					</label>

					<div id="essb-ga-tracking-fields"<?php echo $v['activate_ga_tracking'] ? '' : ' class="essb-dr-hidden"'; ?>>
						<div class="essb-dr-field essb-dr-field-indent">
							<label class="essb-dr-field-label" for="essb-ga-mode"><?php esc_html_e('Google Analytics Tracking Method', 'essb'); ?></label>
							<select class="essb-dr-select" id="essb-ga-mode" data-field="ga_tracking_mode">
								<option value="simple"><?php esc_html_e('Simple', 'essb'); ?></option>
								<option value="extended"><?php esc_html_e('Extended', 'essb'); ?></option>
							</select>
							<span class="essb-dr-field-desc"><?php esc_html_e('Choose your tracking method: Simple - track clicks by social networks, Extended - track clicks on separate social networks by button display position.', 'essb'); ?></span>
						</div>

						<label class="essb-dr-toggle">
							<input type="checkbox" id="essb-ga-layers" data-field="activate_ga_layers" <?php checked($v['activate_ga_layers'], true); ?>>
							<span class="essb-dr-toggle-track"></span>
							<span class="essb-dr-toggle-content">
								<span class="essb-dr-toggle-label"><?php esc_html_e('Use Google Tag Manager Data Layer Event Tracking', 'essb'); ?></span>
								<span class="essb-dr-toggle-desc"><?php esc_html_e('Activate this option if you use Google Tag Manager to add analytics code and you did not setup automatic event tracking.', 'essb'); ?></span>
							</span>
						</label>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-ga-utm" data-field="activate_utm" <?php checked($v['activate_utm'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Enable UTM tracking', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Add UTM parameters to the shared social links.', 'essb'); ?></span>
						</span>
					</label>

					<div id="essb-ga-utm-fields"<?php echo $v['activate_utm'] ? '' : ' class="essb-dr-hidden"'; ?>>
						<div class="essb-dr-field essb-dr-field-indent">
							<label class="essb-dr-field-label" for="essb-ga-utm-source"><?php esc_html_e('Campaign UTM source', 'essb'); ?></label>
							<input type="text" class="essb-dr-input" id="essb-ga-utm-source" data-field="activate_utm_source" value="<?php echo esc_attr($v['activate_utm_source']); ?>" placeholder="{network}">
							<span class="essb-dr-field-desc"><?php esc_html_e('The value of the UTM source parameter is added to the social share links. Available variables: {network} for the social network or {title} for the post title. Default if blank: {network}', 'essb'); ?></span>
						</div>

						<div class="essb-dr-field essb-dr-field-indent">
							<label class="essb-dr-field-label" for="essb-ga-utm-medium"><?php esc_html_e('Campaign UTM medium', 'essb'); ?></label>
							<input type="text" class="essb-dr-input" id="essb-ga-utm-medium" data-field="activate_utm_medium" value="<?php echo esc_attr($v['activate_utm_medium']); ?>" placeholder="social">
							<span class="essb-dr-field-desc"><?php esc_html_e('The value of the UTM medium parameter is added to the social share links. Available variables: {network} for the social network or {title} for the post title. Default if blank: social', 'essb'); ?></span>
						</div>

						<div class="essb-dr-field essb-dr-field-indent">
							<label class="essb-dr-field-label" for="essb-ga-utm-name"><?php esc_html_e('Campaign UTM name', 'essb'); ?></label>
							<input type="text" class="essb-dr-input" id="essb-ga-utm-name" data-field="activate_utm_name" value="<?php echo esc_attr($v['activate_utm_name']); ?>" placeholder="EasySocialShareButtons">
							<span class="essb-dr-field-desc"><?php esc_html_e('The value of the UTM name parameter is added to the social share links. Available variables: {network} for the social network or {title} for the post title. Default if blank: EasySocialShareButtons', 'essb'); ?></span>
						</div>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-ga-ntg" data-field="activate_ga_ntg_tracking" <?php checked($v['activate_ga_ntg_tracking'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Activate News Tagging Guide (NTG)', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Measuring News Tagging Guide (NTG) conversions', 'essb'); ?></span>
						</span>
					</label>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-ga-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-ga-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$fields = array(
				'activate_ga_tracking',
				'ga_tracking_mode',
				'activate_ga_layers',
				'activate_utm',
				'activate_utm_source',
				'activate_utm_medium',
				'activate_utm_name',
				'activate_ga_ntg_tracking',
			);

			foreach ($fields as $key) {
				$options[$key] = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
