<?php

/**
 * Single Counter component
 *
 * Drawer interface for the individual network share counter options: the value
 * format and the value appearance animation. Replaces the legacy advanced
 * settings window that was built from ao-single-counter.php.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_Single_Counter')) {

	class ESSB_Component_Single_Counter {

		const ID = 'single-counter';
		const AJAX_ACTION = 'essb_single_counter_save';

		private $localized_data = null;

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		private function counter_value_mode() {
			return array(
				''          => esc_html__('Automatically shorten values above 1000', 'essb'),
				'full'      => esc_html__('Always display full value (default server settings)', 'essb'),
				'fulldot'   => esc_html__('Always display full value - dot thousand separator (example 5.000)', 'essb'),
				'fullcomma' => esc_html__('Always display full value - comma thousand separator (example 5,000)', 'essb'),
				'fullspace' => esc_html__('Always display full value - space thousand separator (example 5 000)', 'essb'),
				'no'        => esc_html__('Without formating', 'essb'),
			);
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		private function get_values($options) {
			return array(
				'counter_format'         => $this->option_value($options, 'counter_format'),
				'animate_single_counter' => $this->option_is_true($options, 'animate_single_counter'),
			);
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-single-counter', ESSB3_PLUGIN_URL . '/lib/admin/components/single-counter/assets/essb-single-counter.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-single-counter', 'essbSingleCounterData', $this->get_localized_data());
		}

		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $this->get_values($options),
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('Individual network counter settings saved.', 'essb'),
					'error'  => esc_html__('Unable to save the individual network counter settings.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-sc-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-sc-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('Individual network share counter', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-sc-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Control how the individual network share counter value is formatted and displayed.', 'essb'); ?></p>

					<h3 class="essb-dr-heading"><?php esc_html_e('Counter Value & Animation', 'essb'); ?></h3>

					<div class="essb-dr-field">
						<label class="essb-dr-field-label" for="essb-sc-counter_format"><?php esc_html_e('Share value format', 'essb'); ?></label>
						<select class="essb-dr-select" id="essb-sc-counter_format" data-field="counter_format">
							<?php foreach ($this->counter_value_mode() as $option_value => $option_label) : ?>
								<option value="<?php echo esc_attr($option_value); ?>" <?php selected($v['counter_format'], $option_value); ?>><?php echo esc_html($option_label); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-sc-animate_single_counter" data-field="animate_single_counter" <?php checked($v['animate_single_counter'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Animate value appearance', 'essb'); ?></span>
						</span>
					</label>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-sc-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-sc-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$options['counter_format'] = isset($_POST['counter_format']) ? sanitize_text_field(wp_unslash($_POST['counter_format'])) : '';
			$options['animate_single_counter'] = (isset($_POST['animate_single_counter']) && $_POST['animate_single_counter'] === 'true') ? 'true' : '';

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
