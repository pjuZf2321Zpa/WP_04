<?php

/**
 * After Share Appearance component
 *
 * Drawer interface for the after share appearance options: pop up width,
 * single time appearance, mobile behaviour and static resource loading.
 * Replaces the legacy "After Share Appearance Options" advanced settings
 * window.
 *
 * @since 11.x
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('ESSB_Component_After_Share')) {

	class ESSB_Component_After_Share {

		const ID = 'after-share';
		const AJAX_ACTION = 'essb_after_share_save';

		private $localized_data = null;

		/**
		 * Switch options managed by this component. Stored as 'true' or ''.
		 */
		private $switches = array(
			'afterclose_singledisplay',
			'afterclose_deactive_mobile',
			'afterclose_activate_all',
			'afterclose_deactive_sharedisable',
			'afterclose_activate_sharedisable',
		);

		public function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'assets'));
			add_action('admin_footer', array($this, 'render_drawer'));
			add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'save'));
		}

		/**
		 * Check that we are on a plugin settings page
		 */
		private function is_settings_page() {
			$requested = isset($_REQUEST['page']) ? sanitize_key($_REQUEST['page']) : '';
			if ($requested == 'easy-social-metrics-lite') {
				return true;
			}

			if (strpos($requested, 'essb_') !== 0) {
				return false;
			}

			return true;
		}

		/**
		 * Load the current plugin options
		 */
		private function get_options() {
			if (class_exists('ESSBAdvancedOptions')) {
				$options = ESSBAdvancedOptions::get_instance()->get_plugin_options('essb_options');
			} else {
				$options = get_option(ESSB3_OPTIONS_NAME, array());
			}

			if (!is_array($options)) {
				$options = array();
			}

			return $options;
		}

		/**
		 * Save the plugin options
		 */
		private function save_options($options = array()) {
			if (class_exists('ESSBAdvancedOptions')) {
				ESSBAdvancedOptions::get_instance()->save_plugin_options('essb_options', $options);
			} else {
				update_option(ESSB3_OPTIONS_NAME, $options);
			}
		}

		private function option_value($options, $key) {
			return isset($options[$key]) ? $options[$key] : '';
		}

		private function option_is_true($options, $key) {
			return isset($options[$key]) && $options[$key] == 'true';
		}

		/**
		 * Register component assets only on the plugin settings pages
		 */
		public function assets() {
			if (!$this->is_settings_page()) {
				return;
			}

			wp_enqueue_style('essb-components-drawer', ESSB3_PLUGIN_URL . '/lib/admin/components/assets/essb-drawer.css', array(), ESSB3_VERSION);
			wp_enqueue_style('essb-after-share', ESSB3_PLUGIN_URL . '/lib/admin/components/after-share/assets/essb-after-share.css', array(), ESSB3_VERSION);
			wp_enqueue_script('essb-after-share', ESSB3_PLUGIN_URL . '/lib/admin/components/after-share/assets/essb-after-share.js', array('jquery'), ESSB3_VERSION, true);

			wp_localize_script('essb-after-share', 'essbAfterShareData', $this->get_localized_data());
		}

		/**
		 * Data used by the component interface
		 */
		private function get_localized_data() {
			if (null !== $this->localized_data) {
				return $this->localized_data;
			}

			$options = $this->get_options();

			$values = array(
				'afterclose_popup_width'           => $this->option_value($options, 'afterclose_popup_width'),
				'afterclose_singledisplay'         => $this->option_is_true($options, 'afterclose_singledisplay'),
				'afterclose_singledisplay_days'    => $this->option_value($options, 'afterclose_singledisplay_days'),
				'afterclose_deactive_mobile'       => $this->option_is_true($options, 'afterclose_deactive_mobile'),
				'afterclose_activate_all'          => $this->option_is_true($options, 'afterclose_activate_all'),
				'afterclose_deactive_sharedisable' => $this->option_is_true($options, 'afterclose_deactive_sharedisable'),
				'afterclose_activate_sharedisable' => $this->option_is_true($options, 'afterclose_activate_sharedisable'),
			);

			$data = array(
				'nonce'   => wp_create_nonce(self::AJAX_ACTION),
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'values'  => $values,
				'strings' => array(
					'saving' => esc_html__('Saving...', 'essb'),
					'saved'  => esc_html__('After share appearance options saved.', 'essb'),
					'error'  => esc_html__('Unable to save the after share appearance options.', 'essb'),
				),
			);

			$this->localized_data = $data;

			return $data;
		}

		/**
		 * Render the component drawer window
		 */
		public function render_drawer() {
			if (!$this->is_settings_page()) {
				return;
			}

			$data = $this->get_localized_data();
			$v = $data['values'];
			?>
			<div class="essb-dr-overlay" id="essb-as-overlay"></div>
			<div class="essb-dr-drawer essb-ui" id="essb-as-wrap">

				<div class="essb-dr-header">
					<div class="essb-dr-title"><?php esc_html_e('After Share Appearance Options', 'essb'); ?></div>
					<button type="button" class="essb-dr-close" id="essb-as-close" title="<?php esc_attr_e('Close', 'essb'); ?>">&times;</button>
				</div>

				<div class="essb-dr-body">

					<p class="essb-dr-pane-desc"><?php esc_html_e('Configure the pop up width, how often it appears, its behaviour on mobile and when its code is loaded.', 'essb'); ?></p>

					<div class="essb-as-field">
						<label class="essb-as-label" for="essb-as-popup-width"><?php esc_html_e('Pop up message width', 'essb'); ?></label>
						<input type="text" class="essb-as-input" id="essb-as-popup-width" value="<?php echo esc_attr($v['afterclose_popup_width']); ?>" placeholder="400">
						<span class="essb-as-desc"><?php esc_html_e('Custom width in pixels for the pop up window. Default is 400.', 'essb'); ?></span>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-as-singledisplay" <?php checked($v['afterclose_singledisplay'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Display the pop up once for a selected time', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Prevents the pop up from appearing on every page load.', 'essb'); ?></span>
						</span>
					</label>

					<div class="essb-as-field essb-as-field-indent" id="essb-as-days-field">
						<label class="essb-as-label" for="essb-as-singledisplay-days"><?php esc_html_e('Days between pop up displays', 'essb'); ?></label>
						<input type="text" class="essb-as-input" id="essb-as-singledisplay-days" value="<?php echo esc_attr($v['afterclose_singledisplay_days']); ?>" placeholder="7">
						<span class="essb-as-desc"><?php esc_html_e('Leave blank for the default of 7 days.', 'essb'); ?></span>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-as-deactive-mobile" <?php checked($v['afterclose_deactive_mobile'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Do not display after share action on mobile devices', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Uses server-side mobile detection to hide the pop up on phones and tablets.', 'essb'); ?></span>
						</span>
					</label>

					<div class="essb-dr-note">
						<strong><?php esc_html_e('Static resources load:', 'essb'); ?></strong> <?php esc_html_e('control when the after share code is included on a page.', 'essb'); ?>
					</div>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-as-activate-all" <?php checked($v['afterclose_activate_all'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Include after share actions code on all pages', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Required when you use shortcodes to display buttons outside the automatic positions.', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-as-deactive-sharedisable" <?php checked($v['afterclose_deactive_sharedisable'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Do not include after share actions code on pages where buttons are deactivated', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Skips the code on pages where buttons are turned off in Display Settings.', 'essb'); ?></span>
						</span>
					</label>

					<label class="essb-dr-toggle">
						<input type="checkbox" id="essb-as-activate-sharedisable" <?php checked($v['afterclose_activate_sharedisable'], true); ?>>
						<span class="essb-dr-toggle-track"></span>
						<span class="essb-dr-toggle-content">
							<span class="essb-dr-toggle-label"><?php esc_html_e('Always load after share code', 'essb'); ?></span>
							<span class="essb-dr-toggle-desc"><?php esc_html_e('Loads the after share code even on pages where share buttons are deactivated.', 'essb'); ?></span>
						</span>
					</label>

				</div>

				<div class="essb-dr-footer">
					<button type="button" class="essb-dr-btn essb-dr-btn-primary" id="essb-as-save"><?php esc_html_e('Save', 'essb'); ?></button>
					<button type="button" class="essb-dr-btn essb-dr-btn-ghost" id="essb-as-cancel"><?php esc_html_e('Cancel', 'essb'); ?></button>
				</div>

			</div>
			<?php
		}

		/**
		 * Save the after share appearance options through AJAX
		 */
		public function save() {
			check_ajax_referer(self::AJAX_ACTION, 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(array('message' => esc_html__('You are not allowed to change these settings.', 'essb')));
			}

			$options = $this->get_options();

			$options['afterclose_popup_width'] = isset($_POST['afterclose_popup_width']) ? sanitize_text_field(wp_unslash($_POST['afterclose_popup_width'])) : '';
			$options['afterclose_singledisplay_days'] = isset($_POST['afterclose_singledisplay_days']) ? sanitize_text_field(wp_unslash($_POST['afterclose_singledisplay_days'])) : '';

			foreach ($this->switches as $key) {
				$options[$key] = (isset($_POST[$key]) && $_POST[$key] === 'true') ? 'true' : '';
			}

			$this->save_options($options);

			wp_send_json_success(array('reload' => true));
		}
	}
}
