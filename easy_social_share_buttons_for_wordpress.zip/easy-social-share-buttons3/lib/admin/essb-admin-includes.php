<?php

// Post Meta Class
if (!class_exists('ESSB_Post_Meta')) {
    include_once (ESSB3_PLUGIN_ROOT . 'lib/classes/class-post-meta.php');
}

if (!class_exists('ESSB_Cached_Share_Counters')) {
	include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/share-button/class-cached-share-counters.php');
}

include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/essb-admin-helpers.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/settings/essb-control-center-base.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/components/essb-components.php');

include_once (ESSB3_PLUGIN_ROOT . 'lib/core/cache/essb-cache-detector.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-options-structure-shared.php');
if (defined('ESSB3_SETTING5')) {
	include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-options-framework5.php');
	include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-options-interface5.php');	
	include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/settings/essb-settings-components5.php');
}
else {
	include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-options-framework.php');
	include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-options-interface.php');
}

// metabox builder
include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-matebox-options-framework.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-metabox-interface5.php');


if (!essb_option_bool_value('deactivate_module_pinterestpro')) {
	include_once (ESSB3_PLUGIN_ROOT . 'lib/modules/pinterest-pro/pinterest-pro-admin.php');
}


/**
 * Loading subscribe conversions class
 */
if (essb_option_bool_value('conversions_subscribe_lite_run') && !essb_options_bool_value('deactivate_module_conversions')) {
    if (!class_exists('ESSB_Subscribe_Conversions_Pro')) {
        include_once (ESSB3_MODULES_PATH . 'conversions-pro/class-subscribe-conversions.php');
    }
}

if (essb_option_bool_value('conversions_lite_run') && !essb_options_bool_value('deactivate_module_conversions')) {
    if (!class_exists('ESSB_Share_Conversions_Pro')) {
        include_once (ESSB3_MODULES_PATH . 'conversions-pro/class-share-conversions.php');
    }
}

if (!essb_option_bool_value('deactivate_module_shorturl') && essb_option_bool_value('shorturl_activate')) {
    if (!class_exists('ESSB_Short_URL')) {
        include_once (ESSB3_CLASS_PATH . 'share-information/class-short-url.php');
    }
}

include_once (ESSB3_PLUGIN_ROOT . 'lib/modules/social-share-analytics/essb-social-share-analytics-backend.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/settings/essb-options-structure5.php');

include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/essb-metabox.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/class-admin-svg-icons.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/essb-admin.php');

include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/essb-global-wordpress-notifications.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/essb-trigger-notifications.php');

if (!class_exists('ESSBControlCenterShortcodes')) {
	include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/settings/essb-control-center-shortcodes.php');
	ESSBControlCenterShortcodes::add_plugin_shortcodes();
	
	include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/essb-media-buttons.php');
}

/**
 * Register the add-ons installer
 */

include_once (ESSB3_CLASS_PATH . 'utilities/class-essb-tgm-plugin-activation.php');
if (!class_exists ( 'ESSB_Addons_Helper' )) {
    include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/addons/class-addons-helper.php');
}
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/dashboard/essb-dashboard-addons-updates.php');
include_once (ESSB3_PLUGIN_ROOT . 'lib/admin/dashboard/essb-dashboard-coupon-banner.php');

add_action( 'essb_tgmpa_register', 'essb_map_addons_to_tmga' );

add_action( 'wp_ajax_essb_install_free_addon', 'essb_ajax_install_free_addon' );
add_action( 'wp_ajax_essb_dismiss_wizard_popup', 'essb_ajax_dismiss_wizard_popup' );

/**
 * Register a standalone addons page when remote list update is disabled.
 *
 * When deactivate_addons_remote is enabled, ESSB_MyAddons_API returns empty
 * results which causes TGMPA to skip its admin_menu registration. This
 * ensures the Add-Ons page still exists and shows the disabled notice.
 */
if (essb_option_bool_value('deactivate_addons_remote')) {
	add_action('admin_menu', function () {
		add_submenu_page(
			'essb_options',
			'Add-Ons',
			'Add-Ons',
			'manage_options',
			'essb_redirect_addons',
			function () {
				ESSBControlCenter::draw_blank_content_start();
				include_once ESSB3_PLUGIN_ROOT . 'lib/admin/settings/essb-structure5-addons.php';
				ESSBControlCenter::draw_blank_content_end();
			}
		);
	}, 99);
}

function essb_ajax_dismiss_wizard_popup() {
	if (!check_ajax_referer('essb_dismiss_wizard_ajax', 'nonce', false)) {
		wp_die('0');
	}
	ESSB_Plugin_Options::set('wizard_dismissed', 'true');
	ESSB_Plugin_Options::save();
	wp_die('1');
}

?>