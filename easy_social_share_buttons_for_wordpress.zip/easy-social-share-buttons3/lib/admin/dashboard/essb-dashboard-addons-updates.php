<?php

/**
 * ESSB Dashboard — Add-Ons Updates
 *
 * Detects installed add-ons with available updates and renders an updates
 * block on the plugin dashboard (above the Latest News widget). Opens a
 * custom popup listing each add-on (icon, name, current version, available
 * version) with per-add-on update buttons that run the update via AJAX.
 *
 * @since 11.0
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Detect installed add-ons that have available updates.
 *
 * @return array List of add-ons needing updates.
 */
function essb_dashboard_addons_updates_detect()
{
	if (!function_exists('get_plugins')) {
		require_once wp_normalize_path(ABSPATH . 'wp-admin/includes/plugin.php');
	}

	if (!class_exists('ESSB_MyAddons_API')) {
		include_once ESSB3_PLUGIN_ROOT . 'lib/classes/admin/class-my-api-addons.php';
	}

	$split = ESSB_MyAddons_API::get_split_addons();

	$featured_list = isset($split['featured'])
		? $split['featured']
		: array();

	$all_list = isset($split['addons'])
		? $split['addons']
		: array();

	$addons = array_merge($featured_list, $all_list);

	$current_plugins = essb_get_site_plugins();

	if (empty($current_plugins) || empty($addons)) {
		return array();
	}

	$updates = array();

	foreach ($addons as $key => $data) {

		// Add-on is not installed
		if (!isset($current_plugins[$key])) {
			continue;
		}

		$installed_version = isset($current_plugins[$key]['version'])
			? trim($current_plugins[$key]['version'])
			: '';

		$remote_version = isset($data['version'])
			? trim($data['version'])
			: '';

		if (empty($installed_version) || empty($remote_version)) {
			continue;
		}

		if (!version_compare($remote_version, $installed_version, '>')) {
			continue;
		}

		$updates[] = array(
			'slug'           => $key,
			'name'           => isset($data['name']) ? $data['name'] : $key,
			'installed'      => $installed_version,
			'remote'         => $remote_version,
			'has_download'   => !empty($data['download']),
			'svg_icon'       => isset($data['svg_icon']) ? $data['svg_icon'] : '',
			'color'          => isset($data['color']) ? $data['color'] : '#e4e9f5',
			'svg_icon_color' => isset($data['svg_icon_color']) ? $data['svg_icon_color'] : '#ffffff',
			'svg_color_type' => isset($data['svg_color_type']) ? $data['svg_color_type'] : 'fill',
		);
	}

	return $updates;
}

/**
 * Render a single add-on row inside the popup.
 *
 * @param array $addon Add-on data.
 */
function essb_dashboard_addons_updates_render_row($addon)
{
	$slug        = esc_attr($addon['slug']);
	$name        = esc_html($addon['name']);
	$color       = esc_attr($addon['color']);
	$icon_color  = esc_attr($addon['svg_icon_color']);
	$color_type  = esc_attr($addon['svg_color_type']);
	$has_download = (bool) $addon['has_download'];

	echo '<div class="essb-df-updates-row">';

	echo '<div class="essb-df-updates-row-icon essb-icon-' . $color_type . '" style="background:' . $color . '; --essb-icon-c:' . $icon_color . ';">';
	echo $addon['svg_icon']; // Trusted internal API data
	echo '</div>';

	echo '<div class="essb-df-updates-row-info">';
	echo '<span class="essb-df-updates-row-name">' . $name . '</span>';
	echo '<span class="essb-df-updates-row-versions">' .
		esc_html__('Current', 'essb') . ' ' . esc_html($addon['installed']) .
		' &rarr; ' . esc_html__('Available', 'essb') . ' <strong>' . esc_html($addon['remote']) . '</strong>' .
		'</span>';
	echo '</div>';

	if ($has_download) {
		echo '<button type="button" class="essb-df-updates-row-btn" data-addon="' . $slug . '">' . esc_html__('Update', 'essb') . '</button>';
	} else {
		echo '<span class="essb-df-updates-row-hint">' . esc_html__('Use the Add-Ons page', 'essb') . '</span>';
	}

	echo '</div>';
}

/**
 * Render the dashboard add-ons updates block, popup and inline assets.
 */
function essb_dashboard_addons_updates_render()
{
	$updates = essb_dashboard_addons_updates_detect();

	if (empty($updates)) {
		return;
	}

	$count = count($updates);

	echo '<div class="essb-df-updates-widget" id="essb-df-updates-widget">';
	echo '<p class="essb-df-updates-text">' .
		sprintf(
			_n('Updates available for %s add-on.', 'Updates available for %s add-ons.', $count, 'essb'),
			'<strong id="essb-df-updates-count">' . $count . '</strong>'
		) .
		'</p>';
	echo '<button type="button" class="essb-ui-btn essb-ui-btn-warning essb-df-updates-open" id="essb-df-updates-open">' . esc_html__('Update Now', 'essb') . '</button>';
	echo '</div>';

	echo '<div class="essb-df-updates-overlay" id="essb-df-updates-overlay"></div>';
	echo '<div class="essb-df-updates-modal" id="essb-df-updates-modal" role="dialog" aria-modal="true" aria-labelledby="essb-df-updates-title">';

	echo '<div class="essb-df-updates-modal-header">';
	echo '<h3 id="essb-df-updates-title">' . esc_html__('Add-Ons Updates', 'essb') . '</h3>';
	echo '<button type="button" class="essb-df-updates-close" aria-label="' . esc_attr__('Close', 'essb') . '">';
	echo '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13 1L1 13M1 1l12 12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
	echo '</button>';
	echo '</div>';

	echo '<div class="essb-df-updates-modal-body">';

	foreach ($updates as $addon) {
		essb_dashboard_addons_updates_render_row($addon);
	}

	echo '</div>';

	echo '<div class="essb-df-updates-modal-footer">';
	echo '<button type="button" class="essb-ui-btn essb-ui-btn-warning essb-df-updates-all" id="essb-df-updates-all">' . esc_html__('Update All', 'essb') . '</button>';
	echo '<button type="button" class="essb-ui-btn essb-ui-btn-link essb-df-updates-close">' . esc_html__('Close', 'essb') . '</button>';
	echo '</div>';

	echo '</div>';

	$update_nonce = wp_create_nonce('essb_dashboard_update_addon');

	?>
	<style>
		.essb-df-updates-widget {
			background: #fff8dd;
			border: 1px solid rgba(246, 177, 0, .2);
			border-radius: 6px;
			padding: 20px;
			box-shadow: 0 1px 2px rgba(23, 33, 83, .04);
			margin-bottom: 20px;
		}

		.essb-df-updates-text {
			font-size: 14px;
			color: #6b7280;
			line-height: 1.5;
			margin: 0 0 14px;
		}

		.essb-df-updates-text strong {
			color: #172153;
			font-weight: 600;
		}

		.essb-df-updates-open {
			display: block;
			width: 100%;
			text-align: center;
			padding: 9px 16px;
			font-size: 13px;
			font-weight: 600;
			height: auto;
		}

		.essb-df-updates-open:disabled {
			opacity: .55;
			cursor: default;
		}

		.essb-df-updates-overlay {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background: rgba(23, 33, 83, .45);
			z-index: 999992;
			display: none;
		}

		.essb-df-updates-modal {
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: #fff;
			border-radius: 12px;
			box-shadow: 0 16px 48px rgba(23, 33, 83, .2);
			width: 100%;
			max-width: 560px;
			z-index: 999993;
			display: none;
			flex-direction: column;
			max-height: calc(100vh - 60px);
			overflow: hidden;
		}

		.essb-df-updates-modal.is-open {
			display: flex;
		}

		.essb-df-updates-modal-header {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			padding: 20px 24px 14px;
			border-bottom: 1px solid #f0f3fa;
		}

		.essb-df-updates-modal-header h3 {
			font-size: 17px;
			font-weight: 600;
			color: #172153;
			margin: 0;
			padding: 0;
		}

		.essb-df-updates-close {
			background: none;
			border: none;
			cursor: pointer;
			color: #9ca3af;
			padding: 4px;
			display: inline-flex;
			align-items: center;
		}

		.essb-df-updates-close:hover {
			color: #172153;
		}

		.essb-df-updates-modal-body {
			padding: 4px 24px;
			overflow-y: auto;
		}

		.essb-df-updates-row {
			display: flex;
			align-items: center;
			gap: 12px;
			padding: 14px 0;
			border-bottom: 1px solid #f5f7fb;
		}

		.essb-df-updates-row:last-child {
			border-bottom: none;
		}

		.essb-df-updates-row-icon {
			width: 40px;
			height: 40px;
			border-radius: 8px;
			display: flex;
			align-items: center;
			justify-content: center;
			flex-shrink: 0;
		}

		.essb-df-updates-row-icon svg {
			width: 20px;
			height: 20px;
			display: block;
			flex-shrink: 0;
		}

		.essb-df-updates-row-icon.essb-icon-fill svg path,
		.essb-df-updates-row-icon.essb-icon-fill svg rect,
		.essb-df-updates-row-icon.essb-icon-fill svg circle,
		.essb-df-updates-row-icon.essb-icon-fill svg polygon {
			fill: var(--essb-icon-c, #ffffff);
		}

		.essb-df-updates-row-icon.essb-icon-stroke svg path,
		.essb-df-updates-row-icon.essb-icon-stroke svg rect,
		.essb-df-updates-row-icon.essb-icon-stroke svg circle,
		.essb-df-updates-row-icon.essb-icon-stroke svg polygon {
			stroke: var(--essb-icon-c, #ffffff);
			fill: none;
		}

		.essb-df-updates-row-info {
			flex: 1;
			min-width: 0;
			display: flex;
			flex-direction: column;
			gap: 2px;
		}

		.essb-df-updates-row-name {
			font-size: 13px;
			font-weight: 600;
			color: #172153;
		}

		.essb-df-updates-row-versions {
			font-size: 12px;
			color: #6b7280;
		}

		.essb-df-updates-row-versions strong {
			color: #172153;
			font-weight: 600;
		}

		.essb-df-updates-row-error {
			display: block;
			color: #d63638;
			margin-top: 2px;
		}

		.essb-df-updates-row-btn {
			background: #1b84ff;
			color: #fff;
			border: none;
			border-radius: 4px;
			padding: 7px 14px;
			font-size: 12px;
			font-weight: 600;
			cursor: pointer;
			flex-shrink: 0;
		}

		.essb-df-updates-row-btn:hover {
			background: #166fd8;
		}

		.essb-df-updates-row-btn:disabled {
			opacity: .55;
			cursor: default;
		}

		.essb-df-updates-row-btn.is-updated {
			background: #e7f6ec;
			color: #1a7f37;
		}

		.essb-df-updates-row-hint {
			font-size: 12px;
			color: #9ca3af;
			flex-shrink: 0;
		}

		.essb-df-updates-modal-footer {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			padding: 14px 24px 20px;
			border-top: 1px solid #f0f3fa;
		}
	</style>
	<script>
		jQuery(function($) {
			var $overlay = $('#essb-df-updates-overlay');
			var $modal = $('#essb-df-updates-modal');
			var $openBtn = $('#essb-df-updates-open');
			var $countEl = $('#essb-df-updates-count');
			var $widget = $('#essb-df-updates-widget');
			var $updateAllBtn = $('#essb-df-updates-all');
			var updateNonce = '<?php echo esc_js($update_nonce); ?>';
			if (!$modal.length) return;

			function openPopup() {
				$overlay.show();
				$modal.addClass('is-open');
			}

			function closePopup() {
				$overlay.hide();
				$modal.removeClass('is-open');
			}

			$openBtn.on('click', openPopup);
			$(document).on('click', '.essb-df-updates-close', closePopup);
			$overlay.on('click', closePopup);
			$(document).on('keyup', function(e) {
				if (e.key === 'Escape' && $modal.hasClass('is-open')) closePopup();
			});

			function refreshCount() {
				var total = $('.essb-df-updates-row').length;
				var done = $('.essb-df-updates-row.is-updated').length;
				var remaining = Math.max(0, total - done);
				if ($countEl.length) $countEl.text(remaining);
				if (remaining === 0) {
					$openBtn.prop('disabled', true);
					$widget.find('.essb-df-updates-text').html('<?php echo esc_js(__('All add-ons are up to date.', 'essb')); ?>');
				}
			}

			function runUpdate($btn, done) {
				if ($btn.hasClass('is-updated')) {
					if (done) done();
					return;
				}
				var slug = $btn.data('addon');
				var $row = $btn.closest('.essb-df-updates-row');
				var $versions = $row.find('.essb-df-updates-row-versions');

				$btn.addClass('is-updating').prop('disabled', true).text('<?php echo esc_js(__('Updating', 'essb')); ?>\u2026');

				$.post(ajaxurl, {
					action: 'essb_dashboard_update_addon',
					nonce: updateNonce,
					addon: slug
				}, function(res) {
					if (res && res.success) {
						$btn.removeClass('is-updating').addClass('is-updated').prop('disabled', true).text('<?php echo esc_js(__('Updated', 'essb')); ?>');
						$row.addClass('is-updated');
						$versions.html('<?php echo esc_js(__('Updated to', 'essb')); ?> <strong>' + res.data.version + '</strong>');
						refreshCount();
					} else {
						var msg = (res && res.data && res.data.message) ? res.data.message : '<?php echo esc_js(__('Update failed. Please use the Add-Ons page.', 'essb')); ?>';
						$btn.removeClass('is-updating').prop('disabled', false).text('<?php echo esc_js(__('Update', 'essb')); ?>');
						$versions.append('<span class="essb-df-updates-row-error">' + msg + '</span>');
					}
					if (done) done();
				}).fail(function() {
					$btn.removeClass('is-updating').prop('disabled', false).text('<?php echo esc_js(__('Update', 'essb')); ?>');
					$versions.append('<span class="essb-df-updates-row-error"><?php echo esc_js(__('Update failed. Please use the Add-Ons page.', 'essb')); ?></span>');
					if (done) done();
				});
			}

			$(document).on('click', '.essb-df-updates-row-btn', function() {
				runUpdate($(this));
			});

			$updateAllBtn.on('click', function() {
				var $pending = $('.essb-df-updates-row-btn').not('.is-updated').not('.is-updating');
				if (!$pending.length) return;

				$updateAllBtn.prop('disabled', true).text('<?php echo esc_js(__('Updating', 'essb')); ?>\u2026');

				var queue = [];
				$pending.each(function() {
					queue.push($(this));
				});

				var i = 0;
				function next() {
					if (i >= queue.length) {
						var remaining = $('.essb-df-updates-row-btn').not('.is-updated').length;
						$updateAllBtn.prop('disabled', remaining > 0).text(remaining > 0 ? '<?php echo esc_js(__('Update All', 'essb')); ?>' : '<?php echo esc_js(__('Updated', 'essb')); ?>');
						return;
					}
					runUpdate(queue[i], function() {
						i++;
						next();
					});
				}
				next();
			});
		});
	</script>
	<?php
}

/**
 * Forcefully remove a directory, clearing read-only flags first.
 *
 * On Windows file systems read-only files block unlink(), which makes the
 * upgrader fail with "Could not remove the old plugin". Clearing the flag
 * before deletion avoids that.
 *
 * @param string $dir Absolute path to the directory to remove.
 */
function essb_dashboard_force_delete_dir($dir)
{
	$dir = rtrim((string) $dir, '/\\');

	if (empty($dir) || !is_dir($dir) || is_link($dir)) {
		return;
	}

	$items = @scandir($dir);
	if (!is_array($items)) {
		return;
	}

	foreach ($items as $item) {
		if ($item === '.' || $item === '..') {
			continue;
		}

		$path = $dir . DIRECTORY_SEPARATOR . $item;

		if (is_dir($path) && !is_link($path)) {
			essb_dashboard_force_delete_dir($path);
			@chmod($path, 0755);
			@rmdir($path);
		} else {
			@chmod($path, 0644);
			@unlink($path);
		}
	}

	@chmod($dir, 0755);
	@rmdir($dir);
}

/**
 * Filter callback: force-clear the old add-on directory before the
 * upgrader's own cleanup runs.
 *
 * @param mixed  $result             Result of the upgrader's initial delete.
 * @param string $local_destination  The local package destination.
 * @param string $remote_destination The remote package destination.
 * @param array  $hook_extra         Hook data (contains the plugin file path).
 * @return mixed
 */
function essb_dashboard_clear_old_plugin_dir($result, $local_destination, $remote_destination, $hook_extra)
{
	if (empty($hook_extra['plugin'])) {
		return $result;
	}

	$plugin_dir = dirname(WP_PLUGIN_DIR . '/' . $hook_extra['plugin']);

	// Never attempt to remove the plugins root directory itself.
	if ($plugin_dir === rtrim(WP_PLUGIN_DIR, '/\\')) {
		return $result;
	}

	if (is_dir($plugin_dir) && !is_link($plugin_dir)) {
		essb_dashboard_force_delete_dir($plugin_dir);
	}

	// The upgrader's own cleanup may have already failed with a WP_Error
	// ("Could not remove the old plugin") on read-only files. If our forced
	// delete actually removed the directory, override that error with success.
	if (is_wp_error($result) && !is_dir($plugin_dir)) {
		return true;
	}

	return $result;
}

/**
 * AJAX handler: update a single add-on without leaving the page.
 */
function essb_dashboard_addon_update_ajax()
{
	check_ajax_referer('essb_dashboard_update_addon', 'nonce');

	if (!current_user_can('update_plugins')) {
		wp_send_json_error(array('message' => esc_html__('You do not have permission to update plugins.', 'essb')));
	}

	$slug = isset($_POST['addon']) ? sanitize_key(wp_unslash($_POST['addon'])) : '';
	if (empty($slug)) {
		wp_send_json_error(array('message' => esc_html__('No add-on slug provided.', 'essb')));
	}

	if (!class_exists('ESSB_MyAddons_API')) {
		include_once ESSB3_PLUGIN_ROOT . 'lib/classes/admin/class-my-api-addons.php';
	}

	$addon = ESSB_MyAddons_API::get_addon_by_slug($slug);

	if (!is_array($addon) || empty($addon['download'])) {
		wp_send_json_error(array('message' => esc_html__('Unable to retrieve add-on update information. Please use the Add-Ons page.', 'essb')));
	}

	$remote_version = isset($addon['version']) ? trim($addon['version']) : '';
	if (empty($remote_version)) {
		wp_send_json_error(array('message' => esc_html__('Unable to retrieve the available add-on version.', 'essb')));
	}

	$source = $addon['download'];
	$source = str_replace('{activationKey}', 'freemius', $source);
	$source = str_replace('{domain}', urlencode(get_site_url()), $source);

	if (!function_exists('get_plugins')) {
		require_once wp_normalize_path(ABSPATH . 'wp-admin/includes/plugin.php');
	}

	$file_path = '';
	$plugins = get_plugins();
	foreach ($plugins as $path => $data) {
		if (strpos($path, $slug . '/') === 0) {
			$file_path = $path;
			break;
		}
	}

	if (empty($file_path)) {
		wp_send_json_error(array('message' => esc_html__('The add-on is not installed on this site.', 'essb')));
	}

	if (!class_exists('Plugin_Upgrader')) {
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';

	if (!WP_Filesystem()) {
		wp_send_json_error(array('message' => esc_html__('Unable to initialize the filesystem. The plugin directory may not be writable — use the Add-Ons page instead.', 'essb')));
	}

	// Remember whether the add-on was active so we can reactivate it after the
	// upgrade (Plugin_Upgrader only deactivates, it never reactivates).
	$was_active          = is_plugin_active($file_path);
	$was_network_active  = is_multisite() && is_plugin_active_for_network($file_path);

	wp_clean_plugins_cache(false);

	// Inject the update so the upgrader picks up the custom package.
	$repo_updates = get_site_transient('update_plugins');
	if (!is_object($repo_updates)) {
		$repo_updates = new stdClass();
	}
	if (empty($repo_updates->response[$file_path])) {
		$repo_updates->response[$file_path] = new stdClass();
	}
	$repo_updates->response[$file_path]->slug        = $slug;
	$repo_updates->response[$file_path]->plugin      = $file_path;
	$repo_updates->response[$file_path]->new_version = $remote_version;
	$repo_updates->response[$file_path]->package     = $source;
	set_site_transient('update_plugins', $repo_updates);

	// Ensure the old add-on directory can be removed (Windows read-only fix).
	add_filter('upgrader_clear_destination', 'essb_dashboard_clear_old_plugin_dir', 9, 4);

	$skin = new WP_Ajax_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader($skin);
	$result = $upgrader->upgrade($file_path);

	remove_filter('upgrader_clear_destination', 'essb_dashboard_clear_old_plugin_dir', 9);

	if (is_wp_error($result)) {
		wp_send_json_error(array('message' => $result->get_error_message()));
	}

	if (!$result) {
		$errors = $skin->get_errors();
		if ($errors instanceof WP_Error && $errors->has_errors()) {
			wp_send_json_error(array('message' => $errors->get_error_message()));
		}
		wp_send_json_error(array('message' => esc_html__('Update failed. Please use the Add-Ons page.', 'essb')));
	}

	// Reactivate the add-on if it was active before the upgrade.
	if ($was_active || $was_network_active) {
		$activated = activate_plugin($file_path, '', $was_network_active, true);
		if (is_wp_error($activated)) {
			wp_send_json_error(array(
				'message' => sprintf(
					/* translators: %s: add-on slug. */
					esc_html__('The add-on was updated but could not be reactivated: %s', 'essb'),
					$activated->get_error_message()
				),
			));
		}
	}

	wp_clean_plugins_cache(false);

	wp_send_json_success(array(
		'slug'    => $slug,
		'version' => $remote_version,
	));
}

add_action('wp_ajax_essb_dashboard_update_addon', 'essb_dashboard_addon_update_ajax');
