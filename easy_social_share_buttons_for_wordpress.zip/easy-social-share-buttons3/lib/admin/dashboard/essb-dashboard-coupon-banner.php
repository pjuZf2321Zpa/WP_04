<?php

/**
 * ESSB Dashboard — Add-Ons Coupon Banner
 *
 * Renders a horizontal promo banner on the plugin dashboard (above the
 * Featured Add-Ons section) promoting the ESSBADDONS coupon — 25% off PRO
 * add-ons. Includes the coupon code with a copy-to-clipboard button and a
 * "Learn More" link to the offer page.
 *
 * @since 11.0
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Render the horizontal coupon banner with inline styles and copy script.
 */
function essb_dashboard_coupon_banner_render()
{
	$coupon_code = 'ESSBADDON';

	$essb_dashboard_domain = (string) parse_url(home_url(), PHP_URL_HOST);
	$offer_url   = 'https://socialsharingplugin.com/addons-offer/?utm_source=plugin&utm_medium=dashboard_banner&utm_campaign=essbaddons-' . $essb_dashboard_domain;

	?>
	<style>
		.essb-df-offer-h {
			background: linear-gradient(135deg, #172153 0%, #2a3a8f 55%, #3858E9 100%);
			border-radius: 10px;
			padding: 16px 20px;
			color: #fff;
			display: flex;
			align-items: center;
			gap: 18px;
			margin-bottom: 20px;
			box-shadow: 0 8px 20px rgba(23, 33, 83, .18);
		}

		.essb-df-offer-h-badge {
			flex-shrink: 0;
			font-size: 10px;
			font-weight: 800;
			letter-spacing: .08em;
			text-transform: uppercase;
			background: #f6b100;
			color: #172153;
			padding: 6px 12px;
			border-radius: 4px;
			white-space: nowrap;
		}

		.essb-df-offer-h-text {
			flex: 1;
			min-width: 0;
		}

		.essb-df-offer-h-title {
			font-size: 15px;
			font-weight: 700;
			line-height: 1.3;
			white-space: nowrap;
			color: #fff;
			margin: 0;
			padding: 0;
		}

		.essb-df-offer-h-title span {
			color: #ffd76a;
		}

		.essb-df-offer-h-sub {
			font-size: 12px;
			line-height: 1.45;
			color: rgba(255, 255, 255, .82);
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
			margin: 0;
			padding: 0;
		}

		.essb-df-offer-h-coupon {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			gap: 8px;
			background: #fff;
			border-radius: 7px;
			padding: 8px 10px 8px 14px;
			box-shadow: 0 2px 8px rgba(0, 0, 0, .15);
		}

		.essb-df-offer-h-code {
			font-size: 14px;
			font-weight: 800;
			letter-spacing: .12em;
			color: #172153;
			white-space: nowrap;
		}

		.essb-df-offer-h-copy {
			font-size: 11px;
			font-weight: 700;
			color: #3858E9;
			background: #eef1ff;
			border: none;
			border-radius: 5px;
			padding: 5px 12px;
			cursor: pointer;
			white-space: nowrap;
		}

		.essb-df-offer-h-copy:hover {
			background: #dfe5ff;
		}

		.essb-df-offer-h-btn {
			flex-shrink: 0;
			font-size: 13px;
			font-weight: 700;
			color: #172153;
			background: #ffd76a;
			border-radius: 6px;
			padding: 10px 18px;
			text-decoration: none;
			white-space: nowrap;
			transition: background .2s;
		}

		.essb-df-offer-h-btn:hover {
			background: #ffcf4d;
			color: #172153;
		}

		@media (max-width: 1100px) {
			.essb-df-offer-h {
				flex-wrap: wrap;
			}

			.essb-df-offer-h-text {
				flex-basis: 100%;
				order: 3;
			}

			.essb-df-offer-h-title,
			.essb-df-offer-h-sub {
				white-space: normal;
			}
		}
	</style>

	<div class="essb-df-offer-h">
		<span class="essb-df-offer-h-badge"><?php esc_html_e('25% OFF', 'essb'); ?></span>
		<div class="essb-df-offer-h-text">
			<div class="essb-df-offer-h-title"><?php esc_html_e('PRO Add-Ons', 'essb'); ?> <span><?php esc_html_e('Special Offer', 'essb'); ?></span></div>
			<div class="essb-df-offer-h-sub"><?php esc_html_e('Take 25% off any PRO add-on purchase. Exclusive coupon for Easy Social Share customers.', 'essb'); ?></div>
		</div>
		<div class="essb-df-offer-h-coupon">
			<span class="essb-df-offer-h-code"><?php echo esc_html($coupon_code); ?></span>
			<button type="button" class="essb-df-offer-h-copy" data-coupon="<?php echo esc_attr($coupon_code); ?>"><?php esc_html_e('Copy', 'essb'); ?></button>
		</div>
		<a class="essb-df-offer-h-btn" href="<?php echo esc_url($offer_url); ?>" target="_blank"><?php esc_html_e('Learn More', 'essb'); ?></a>
	</div>

	<script>
		(function() {
			var copyBtn = document.querySelector('.essb-df-offer-h-copy');
			if (!copyBtn) return;

			var copiedText = '<?php echo esc_js(__('Copied!', 'essb')); ?>';
			var originalText = copyBtn.textContent;

			function flashCopied() {
				copyBtn.textContent = copiedText;
				copyBtn.style.color = '#fff';
				copyBtn.style.background = '#22c55e';
				setTimeout(function() {
					copyBtn.textContent = originalText;
					copyBtn.style.color = '';
					copyBtn.style.background = '';
				}, 1500);
			}

			copyBtn.addEventListener('click', function() {
				var code = copyBtn.getAttribute('data-coupon') || copyBtn.textContent;

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(code).then(flashCopied);
				} else {
					var ta = document.createElement('textarea');
					ta.value = code;
					ta.style.position = 'fixed';
					ta.style.opacity = '0';
					document.body.appendChild(ta);
					ta.select();
					try {
						document.execCommand('copy');
						flashCopied();
					} catch (e) {}
					document.body.removeChild(ta);
				}
			});
		})();
	</script>
	<?php
}
