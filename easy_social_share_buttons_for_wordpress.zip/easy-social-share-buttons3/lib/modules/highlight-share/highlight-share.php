<?php
/**
 * Highlight Share module
 *
 * Shows a floating share-button bar over text selected by the visitor.
 *
 * @package EasySocialShareButtons
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Available networks for highlight share.
 *
 * @return array
 */
function essb_highlight_share_networks_source() {
    $allowed = array(
        'bluesky'    => 'Bluesky',
        'buffer'     => 'Buffer',
        'email'      => 'Email',
        'hackernews' => 'Hacker News',
        'mastodon'   => 'Mastodon',
        'reddit'     => 'Reddit',
        'telegram'   => 'Telegram',
        'twitter'    => 'X (formerly Twitter)',
        'whatsapp'   => 'WhatsApp',
        'viber'      => 'Viber',
        'chatgpt'    => 'ChatGPT',
        'grok'       => 'Grok',
        'mistral'  => 'Mistral',
        'claude'     => 'Claude',
        'perplexity' => 'Perplexity',
        'threads'    => 'Threads',
        'truthsocial'      => 'Truth Social',
        'navigator'  => 'Navigator Share',
    );

    // Verify against ESSB available networks where applicable, but keep
    // highlight-specific (AI/custom) networks regardless.
    $essb_networks = function_exists('essb_available_social_networks') ? essb_available_social_networks() : array();

    $result = array();
    foreach ($allowed as $key => $label) {
        if (isset($essb_networks[$key]) && isset($essb_networks[$key]['name'])) {
            $result[$key] = $essb_networks[$key]['name'];
        } 
    }

    return $result;
}

/**
 * Generate a share URL for a highlight network.
 *
 * @param string $network
 * @param array  $share
 * @return string
 */
function essb_highlight_share_generate_url($network, $share) {
    $permalink = isset($share['url']) ? $share['url'] : '';
    $title = '__highlight__';

    // AI networks (Novashare-style prompt).
    $ai_text = rawurlencode('Summarize the content of this URL');

    switch ($network) {
        case 'chatgpt':
            return 'https://chat.openai.com/?q=' . $ai_text . '%3A%20' . rawurlencode($permalink);
        case 'grok':
            return 'https://grok.com/?q=' . $ai_text . '%3A%20' . rawurlencode($permalink);
        case 'perplexity':
            return 'https://www.perplexity.ai/search/new?q=' . $ai_text . '%3A%20' . rawurlencode($permalink);
        case 'claude':
            return 'https://claude.ai/new?q=' . $ai_text . '%3A%20' . rawurlencode($permalink);
        case 'mistral':
            return 'https://chat.mistral.ai/chat?q=' . $ai_text . '%3A%20' . rawurlencode($permalink);
        case 'googleai':
            return 'https://www.google.com/search?udm=50&aep=11&q=' . $ai_text . '%3A%20' . rawurlencode($permalink);
        case 'threads':
            return 'https://www.threads.net/intent/post?text=' . rawurlencode('__highlight__') . '%20' . rawurlencode($permalink);
        case 'bluesky':
            return 'https://bsky.app/intent/compose?text=' . rawurlencode('__highlight__') . '%20' . rawurlencode($permalink);
        case 'mastodon':
            return 'https://share.joinmastodon.org/#text=' . rawurlencode('__highlight__') . '%20' . rawurlencode($permalink);
        case 'viber':
            return 'viber://forward?text=' . rawurlencode('__highlight__') . '%20' . rawurlencode($permalink);
        case 'truthsocial':
            return 'https://truthsocial.com/compose?text=' . rawurlencode('__highlight__') . '%20' . rawurlencode($permalink);
        case 'hackernews':
            return 'https://news.ycombinator.com/submitlink?u=' . rawurlencode($permalink) . '&t=' . rawurlencode('__highlight__');
        case 'navigator':
            return '#';
    }

    // ESSB built-in networks.
    if (function_exists('essb_generate_network_share_url')) {
        $generated = essb_generate_network_share_url($network, $share);
        if (is_array($generated) && isset($generated['url'])) {
            return $generated['url'];
        }
    }

    return '#';
}

/**
 * Check whether highlight share is allowed on the current request.
 *
 * @return bool
 */
function essb_highlight_share_is_allowed() {
    if (essb_option_bool_value('deactivate_highlight_share')) {
        return false;
    }

    if (!essb_option_bool_value('highlight_share')) {
        return false;
    }

    if (!is_singular()) {
        return false;
    }

    if (wp_is_mobile() && essb_option_bool_value('highlight_share_hide_mobile')) {
        return false;
    }

    $post_types = essb_option_value('highlight_share_post_types');
    if (!is_array($post_types)) {
        $post_types = array_filter(explode(',', (string)$post_types));
    }
    if (empty($post_types)) {
        $post_types = array('post');
    }

    if (class_exists('ESSB_Plugin_Loader') && method_exists('ESSB_Plugin_Loader', 'type_selected')) {
        if (!ESSB_Plugin_Loader::type_selected($post_types)) {
            return false;
        }
    } else {
        if (!in_array(get_post_type(), $post_types, true)) {
            return false;
        }
    }

    $post_id = get_the_ID();
    if ($post_id && get_post_meta($post_id, 'essb_disable_highlight_share', true)) {
        return false;
    }

    $allowed = true;
    $allowed = (bool) apply_filters('essb_highlight_share', $allowed);

    return $allowed;
}

/**
 * Append a content marker to the post content (used to scope selection).
 *
 * @param string $content
 * @return string
 */
function essb_highlight_share_content_marker($content) {
    if (!essb_highlight_share_is_allowed()) {
        return $content;
    }

    static $marker_printed = false;
    if ($marker_printed) {
        return $content;
    }
    if (in_array(current_filter(), array('get_the_excerpt', 'wp_head', 'widget_text_content'), true)) {
        return $content;
    }

    $marker_printed = true;
    return $content . '<div class="essb-content-marker" style="display:none;" aria-hidden="true"></div>';
}

/**
 * Render the highlight share container in the footer.
 */
function essb_highlight_share_render() {
    if (!essb_highlight_share_is_allowed()) {
        return;
    }

    $networks = essb_option_value('highlight_share_networks');
    if (!is_array($networks)) {
        $networks = array_filter(explode(',', (string)$networks));
    } else {
        $flattened = array();
        foreach ($networks as $n) {
            if (is_string($n) && strpos($n, ',') !== false) {
                foreach (array_filter(explode(',', $n)) as $part) {
                    $flattened[] = trim($part);
                }
            } else {
                $flattened[] = is_string($n) ? trim($n) : '';
            }
        }
        $networks = array_filter($flattened);
    }

    if (empty($networks)) {
        $networks = array('twitter');
    }

    // Filter to allowed highlight networks.
    $allowed_source = essb_highlight_share_networks_source();
    $allowed_networks = array_values(array_intersect($networks, array_keys($allowed_source)));

    if (empty($allowed_networks)) {
        return;
    }

    $post_url = get_permalink();
    $image = '';
    if (has_post_thumbnail()) {
        $image = get_the_post_thumbnail_url(get_the_ID(), 'full');
    }
    $share = array();
    if (class_exists('ESSB_Site_Share_Information')) {
        $share = ESSB_Site_Share_Information::compile_share_object('__highlight__', '', $image, $post_url);
    } else {
        $share = array(
            'url' => $post_url,
            'title' => '__highlight__',
            'image' => $image,
            'description' => '',
            'twitter_user' => '',
            'twitter_hashtags' => '',
            'twitter_tweet' => '__highlight__',
            'post_id' => get_the_ID(),
            'title_plain' => '__highlight__',
            'short_url_whatsapp' => '',
            'short_url_twitter' => '',
            'short_url' => '',
        );
    }
    $share['title'] = '__highlight__';
    $share['title_plain'] = '__highlight__';
    $share['twitter_tweet'] = '__highlight__';

    $template_option = essb_sanitize_option_value('highlight_share_template');
    $global_style = essb_option_value('style');
    $template_folder = '';
    if ($template_option !== '') {
        $template_folder = function_exists('essb_template_folder') ? essb_template_folder($template_option) : $template_option;
    } else {
        $template_folder = function_exists('essb_template_folder') ? essb_template_folder($global_style) : '';
    }

    $size_desktop = essb_sanitize_option_value('highlight_share_button_size');
    $size_mobile = essb_sanitize_option_value('highlight_share_button_size_mobile');
    $nospace = essb_option_bool_value('highlight_share_nospace');
    $panel_bg = essb_sanitize_option_value('highlight_share_panel_background');
    if ($panel_bg === '') {
        $panel_bg = 'light';
    }

    $instance_id = 'highlight';

    $container_classes = 'essb_links essb_highlight_buttons';
    if ($template_folder) {
        $container_classes .= ' essb_template_' . esc_attr($template_folder);
    }
    if ($size_desktop) {
        $container_classes .= ' essb_size_' . esc_attr($size_desktop);
    }
    if ($size_mobile) {
        $container_classes .= ' essb_size_mobile_' . esc_attr($size_mobile);
    }
    if ($nospace) {
        $container_classes .= ' essb_nospace';
    }
    if ($panel_bg === 'dark') {
        $container_classes .= ' essb-highlight-dark';
    }

    echo '<div id="essb-highlight-share" class="essb-highlight-share essb-highlight-hidden' . ($panel_bg === 'dark' ? ' essb-highlight-dark' : '') . '" aria-hidden="true">';
    echo '<div class="' . esc_attr($container_classes) . '" data-essb-position="highlight" data-essb-postid="' . esc_attr(get_the_ID()) . '" data-essb-instance="' . esc_attr($instance_id) . '">';

    echo '<ul class="essb_links_list">';

    foreach ($allowed_networks as $network) {
        $url = essb_highlight_share_generate_url($network, $share);

        $all_networks = function_exists('essb_available_social_networks') ? essb_available_social_networks(true) : array();
        $network_name = isset($allowed_source[$network]) ? $allowed_source[$network] : $network;

        $css_network = ($network === 'twitter') ? 'twitter_x' : $network;
        echo '<li class="essb_item essb_link_' . esc_attr($css_network) . ' nolightbox essb_link_svg_icon">';
        echo '<a class="nolightbox essb-s-bg-' . esc_attr($css_network) . ' essb-s-c-light essb-s-ch-light essb-s-bgh-dark essb-s-bg-network" rel="noopener noreferrer nofollow" href="' . esc_url($url) . '" target="_blank" title="' . esc_attr($network_name) . '" data-network="' . esc_attr($network) . '">';
        echo '<span class="essb_icon essb_icon_' . esc_attr($css_network) . '">';
        $custom_svg_icon = '';
        if (!class_exists('ESSB_SVG_Icons')) {
            include_once(ESSB3_CLASS_PATH . 'assets/class-svg-icons.php');
        }
        $icon_network = ($network === 'twitter') ? 'twitter_x' : $network;
        if (class_exists('ESSB_SVG_Icons')) {
            $custom_svg_icon = ESSB_SVG_Icons::get_icon($icon_network);
        }
        $custom_svg_icon = apply_filters('essb_network_svg_icon_' . $network, $custom_svg_icon);
        if (!empty($custom_svg_icon)) {
            echo $custom_svg_icon;
        } else {
            // Fallback for networks without SVG icon.
            echo '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zm0 7.5L4.5 6 12 2.5 19.5 6 12 9.5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>';
        }
        echo '</span>';
        echo '</a>';
        echo '</li>';
    }

    echo '</ul>';
    echo '</div>';
    echo '</div>';

    // Inline CSS.
    $size_map = array('xs' => 14, 's' => 16, '' => 18, 'm' => 20, 'l' => 24, 'xl' => 28, 'xxl' => 32);
    $size_css = '';
    foreach ($size_map as $key => $px) {
        if ($key === '') continue;
        $size_css .= '.essb-highlight-share .essb_links.essb_size_' . $key . ' .essb_icon svg{width:' . $px . 'px;height:' . $px . 'px;}';
    }
    $mobile_css = '';
    foreach ($size_map as $key => $px) {
        if ($key === '') continue;
        $mobile_css .= '.essb-highlight-share .essb_links.essb_size_mobile_' . $key . ' .essb_icon svg{width:' . $px . 'px;height:' . $px . 'px;}';
    }
    $css = '#essb-highlight-share{position:absolute;z-index:99999;opacity:0;visibility:hidden;transition:opacity .15s ease}#essb-highlight-share.essb-highlight-visible{opacity:1;visibility:visible}.essb-highlight-share .essb_links{display:flex;gap:4px;padding:6px;background:#fff;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.15)}.essb-highlight-share.essb-highlight-dark .essb_links{background:#212121}.essb-highlight-share .essb_links_list{display:flex;gap:4px;list-style:none;margin:0;padding:0}.essb-highlight-share .essb_item a{display:flex;align-items:center;gap:6px;margin:0 !important}.essb-highlight-share .essb_nospace,.essb-highlight-share .essb_nospace .essb_links_list{gap:0 !important}.essb-highlight-share .essb_links.essb_template_glow-retina .essb_icon{width:auto !important;height:auto !important;padding:8px !important;}' . $size_css;
    if ($mobile_css !== '') {
        $css .= '@media (max-width:768px){' . $mobile_css . '}';
    }
    echo '<style id="essb-highlight-share-css">' . $css . '</style>';

    // Inline JS.
    $breakpoint = 768;
    ?>
    <script id="essb-highlight-share-js">
    (function(){
        var bar = document.getElementById('essb-highlight-share');
        if (!bar) return;
        var buttons = bar.querySelectorAll('a');
        var originals = [];
        buttons.forEach(function(b){ originals.push(b.getAttribute('href')); });

        // Bind ESSB core share (or Web Share API for navigator).
        buttons.forEach(function(b){
            b.addEventListener('click', function(e){
                e.preventDefault();
                var href = b.getAttribute('href') || '#';
                var network = b.getAttribute('data-network') || '';
                if (network === 'navigator') {
                    if (navigator.share) { navigator.share({title: document.title, url: window.location.href}); }
                    return false;
                }
                if (window.essb && typeof essb.window === 'function') {
                    essb.window(href, network, 'highlight');
                } else {
                    window.open(href, '_blank');
                }
                return false;
            });
        });

        function hide(){ bar.classList.remove('essb-highlight-visible'); bar.setAttribute('aria-hidden','true'); }

        function show(rect) {
            var x = rect.left + window.scrollX + (rect.width/2) - (bar.offsetWidth/2);
            var y = rect.top + window.scrollY - bar.offsetHeight - 8;
            if (x < 8) x = 8;
            if (y < 8) y = rect.bottom + window.scrollY + 8;
            bar.style.left = x + 'px';
            bar.style.top = y + 'px';
            bar.classList.add('essb-highlight-visible');
            bar.setAttribute('aria-hidden','false');
        }

        document.addEventListener('mouseup', function(e){
            setTimeout(function(){
                var sel = window.getSelection();
                if (!sel || sel.isCollapsed) { hide(); return; }
                var text = sel.toString().trim();
                if (!text) { hide(); return; }
                if (window.innerWidth < <?php echo (int)$breakpoint; ?>) { hide(); return; }
                try {
                    var range = sel.getRangeAt(0);
                    var common = range.commonAncestorContainer;
                    var container = (common.nodeType === 3) ? common.parentNode : common;
                    var scopeOk = false;
                    var node = container;
                    while (node && node !== document.body) {
                        if (node.querySelector && node.querySelector('.essb-content-marker')) { scopeOk = true; break; }
                        node = node.parentNode;
                    }
                    if (!scopeOk) { hide(); return; }

                    buttons.forEach(function(b, i){
                        var orig = originals[i] || '';
                        var newHref = orig.replace('__highlight__', encodeURIComponent(text));
                        b.setAttribute('href', newHref);
                        // update onclick url
                        var network = b.getAttribute('data-network') || b.getAttribute('data-essb-network') || '';
                    });

                    var rect = range.getBoundingClientRect();
                    show(rect);
                } catch (err) { hide(); }
            }, 10);
        });

        document.addEventListener('mousedown', function(e){
            if (!bar.contains(e.target)) { hide(); }
        });
    })();
    </script>
    <?php
}

// Remove color dots from the highlight networks picker in admin.
add_action('admin_head', function () {
    echo '<style>.settings-panel-highlight_share_networks .essb-ms-dot{display:none !important;}</style>';
});

// Hooks
add_action('the_content', 'essb_highlight_share_content_marker', 999);
add_action('wp_footer', 'essb_highlight_share_render', 25);
