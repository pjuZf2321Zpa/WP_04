<?php

/**
 * Pinterest Pro: Shortcodes for creating pinable images inside content or adding pinable galleries
 *
 * @package EasySocialShareButtons
 * @author appscreo
 * @version 1.0
 * @since 5.9
 *
 */

if (!function_exists('essb5_generate_pinterest_image')) {
	/**
	 * The [pinterest-image] shortcode generation function
	 * 
	 * @param unknown_type $atts
	 */
	function essb5_generate_pinterest_image($atts) {
		
		$type = isset($atts['type']) ? $atts['type'] : '';
		$image = isset($atts['image']) ? $atts['image'] : '';
		$message = isset($atts['message']) ? $atts['message'] : '';
		$custom_image = isset($atts['custom_image']) ? $atts['custom_image'] : '';
		$align = isset($atts['align']) ? $atts['align'] : '';
		$custom_class = isset($atts['class']) ? $atts['class'] : '';
		$elementor = isset($atts['elementor']) ? $atts['elementor'] : false;
		$class_align = '';
		
		if ($elementor) {
			if ($image && is_array($image)) {
				$image = $image['url'];
			}
			
			if ($custom_image && is_array($custom_image)) {
				$custom_image = $custom_image['url'];
			}
		}
		
		$share_image = '';
		$share_message = '';
		$share_url = get_permalink();
		
		// prevent sending blank images in the share command
		if (empty($custom_image)) {
			$custom_image = $image;
		}
		
		if (empty($message)) {
			$message = get_the_title();
		}
		
		if ($align == '') {
			$class_align = 'alignnone size-full';
		}
		else if ($align == 'center') {
			$class_align = 'aligncenter size-full';
		}
		else if ($align == 'left') {
			$class_align = 'alignleft size-full';
		}
		else if ($align == 'right') {
			$class_align = 'alignright size-full';
		}
		
		if ($type == 'post') {
			$essb_post_pin_image = get_post_meta( get_the_ID(), 'essb_post_pin_image', true);
			$essb_post_pin_desc = get_post_meta( get_the_ID(), 'essb_post_pin_desc', true);
			
			$share_message = !empty($essb_post_pin_desc) ? $essb_post_pin_desc : $message;
			$share_image = !empty($essb_post_pin_image) ? $essb_post_pin_image : $custom_image;
		}
		else {
			$share_image = $custom_image;
			$share_message = $message;
		}
		
		$options = array(
				'screen_image' => $image,
				'align' => $class_align,
				'share_image' => $share_image,
				'share_message' => $share_message,
				'share_url' => $share_url,
				'custom_class' => $custom_class
		);
		
		return essb_output_pinable_image_code($options);
	}
}

if (!function_exists('essb5_generate_pinterest_gallery')) {
	/**
	 * The [pinterest-gallery] shortcode
	 * 
	 * @param unknown_type $atts
	 */
	
	function essb5_generate_pinterest_gallery($atts = array()) {
		$message = isset($atts['message']) ? $atts['message'] : '';
		$images = isset($atts['images']) ? $atts['images'] : '';
		$columns = isset($atts['columns']) ? $atts['columns'] : '';
		$custom_class = isset($atts['class']) ? $atts['class'] : '';
		$adjust = isset($atts['adjust']) ? $atts['adjust'] : '';
		$spacing = isset($atts['spacing']) ? $atts['spacing'] : '';
		
		$pinsc_lazyloading = essb_option_bool_value('pinsc_lazyloading'); 
		
		
		$selected_images = explode(',', $images);
		$salt = mt_rand();
		$instance_class = 'pg-'.$salt;
		if ($columns == '') { $columns = '3'; }
		
		$custom_class .= $instance_class;
		
		if ($adjust == 'yes') {
			$custom_class .= ' essb-pin-adjust';
		}
		
		$output = '<div class="essb-pin-gallery columns-'.esc_attr($columns).' '.esc_attr($custom_class).'" data-adjust="'.esc_attr($adjust).'" data-spacing="'.esc_attr($spacing).'" data-lazy="'.esc_attr($pinsc_lazyloading).'">';
		
		$share_url = get_permalink();
		$post_title = get_the_title();
		
		foreach ($selected_images as $image_id) {
			$image_url = wp_get_attachment_url($image_id);
			$custom_desc = get_post_meta( $image_id, 'essb_pin_description', true );
			
			if ($message != '') { $custom_desc = $message; }
			
			if ($custom_desc == '') { $custom_desc = $post_title; }
			
			$options = array(
					'screen_image' => $image_url,
					'align' => '',
					'share_image' => $image_url,
					'share_message' => $message,
					'share_url' => $share_url,
					'custom_class' => 'in-gallery',
				    'image_link' => $image_url
			);
			
			$output .= essb_output_pinable_image_code($options);
			
		}
		
		$output .= '</div>';
		
		
		if ($spacing != '' && intval($spacing) != 0) {
			$custom_css = '.essb-pin-gallery.'.esc_attr($instance_class).' .essb-pin { padding: '.esc_attr($spacing).'px !important; }';
			essb_resource_builder()->add_css($custom_css, $instance_class, 'footer');	
		}
		
		$pinsc_text = essb_option_value('pinsc_text');
		if ($pinsc_text == '') { $pinsc_text = 'Pin'; }
		
		$root_url = get_permalink();
		
		$code = '
(function () {
	"use strict";

	// Self-contained Vanilla lightbox for Pinterest Pro galleries (replaces the removed jQuery simpleLightbox plugin)
	var essbPinLightbox = {
		overlay: null,
		activeIndex: 0,
		group: [],
		visible: false,

		create: function () {
			if (this.overlay) return;

			var ov = document.createElement("div");
			ov.className = "essb-pin-lightbox";
			ov.setAttribute("role", "dialog");
			ov.setAttribute("aria-modal", "true");
			ov.innerHTML = "" +
				"<div class=\"essb-pin-lightbox-backdrop\" data-essb-close></div>" +
				"<div class=\"essb-pin-lightbox-content\">" +
					"<button type=\"button\" class=\"essb-pin-lightbox-close\" data-essb-close aria-label=\"Close\">&times;</button>" +
					"<button type=\"button\" class=\"essb-pin-lightbox-next\" aria-label=\"Next\">&rsaquo;</button>" +
					"<button type=\"button\" class=\"essb-pin-lightbox-prev\" aria-label=\"Previous\">&lsaquo;</button>" +
					"<div class=\"essb-pin-lightbox-figure\"><img alt=\"\" /></div>" +
					"<div class=\"essb-pin-lightbox-caption\"></div>" +
					"<div class=\"essb-fullscreen-pin\"><a href=\"#\" target=\"_blank\" data-post-url=\"' . $root_url . '\"><span class=\"essb_icon essb_icon_pinterest\"></span><span class=\"network-text\">' . $pinsc_text . '</span></a></div>" +
				"</div>";

			document.body.appendChild(ov);
			this.overlay = ov;

			ov.querySelectorAll("[data-essb-close]").forEach(function (el) {
				el.addEventListener("click", function () { essbPinLightbox.close(); });
			});

			ov.querySelector(".essb-pin-lightbox-prev").addEventListener("click", function () { essbPinLightbox.move(-1); });
			ov.querySelector(".essb-pin-lightbox-next").addEventListener("click", function () { essbPinLightbox.move(1); });

			ov.querySelector(".essb-fullscreen-pin a").addEventListener("click", function (e) {
				e.preventDefault();
				e.stopPropagation();
				var btn = this,
					media = btn.getAttribute("data-post-url") || "";
				var img = essbPinLightbox.overlay.querySelector(".essb-pin-lightbox-figure img");
				if (img && img.getAttribute("src")) media = img.getAttribute("src");
				var url = "https://pinterest.com/pin/create/button/?url=" + encodeURIComponent(btn.getAttribute("data-post-url") || "") + "&media=" + encodeURIComponent(media);
				window.open(url, "_blank");
			});

			document.addEventListener("keydown", function (e) {
				if (!essbPinLightbox.visible) return;
				if (e.key === "Escape") essbPinLightbox.close();
				else if (e.key === "ArrowRight") essbPinLightbox.move(1);
				else if (e.key === "ArrowLeft") essbPinLightbox.move(-1);
			});
		},

		open: function (elem, group) {
			this.create();
			this.group = group;
			this.activeIndex = group.indexOf(elem);
			this.visible = true;

			var base = group[0].closest(".essb-pin-gallery");
			var pinUrl = base ? (base.getAttribute("data-pin-url") || "") : "";
			var pinBtn = this.overlay.querySelector(".essb-fullscreen-pin a");
			if (pinUrl) pinBtn.setAttribute("data-post-url", pinUrl);

			document.body.classList.add("hidden-scroll");
			this.overlay.classList.add("essb-pin-lightbox-open");
			this.load();
		},

		load: function () {
			var link = this.group[this.activeIndex];
			var img = this.overlay.querySelector(".essb-pin-lightbox-figure img");
			var href = link.getAttribute("href") || "";
			var inner = link.querySelector("img");
			var title = inner ? (inner.getAttribute("title") || inner.getAttribute("alt") || "") : "";

			img.setAttribute("src", href);
			img.setAttribute("alt", title || "");

			var caption = this.overlay.querySelector(".essb-pin-lightbox-caption");
			caption.textContent = (this.group.length > 1) ? ((this.activeIndex + 1) + " / " + this.group.length + (title ? " \u2014 " + title : "")) : title;
			caption.style.display = caption.textContent ? "" : "none";

			var prev = this.overlay.querySelector(".essb-pin-lightbox-prev"),
				next = this.overlay.querySelector(".essb-pin-lightbox-next");
			prev.style.display = (this.group.length > 1) ? "" : "none";
			next.style.display = (this.group.length > 1) ? "" : "none";
		},

		move: function (step) {
			var total = this.group.length;
			this.activeIndex = (this.activeIndex + step + total) % total;
			this.load();
		},

		close: function () {
			if (!this.visible) return;
			this.visible = false;
			document.body.classList.remove("hidden-scroll");
			this.overlay.classList.remove("essb-pin-lightbox-open");
		}
	};

	var essbPinGalleryInit = function () {
		var galleries = document.querySelectorAll(".essb-pin-gallery");
		if (!galleries.length) return;

		for (var g = 0; g < galleries.length; g++) {
			var galleryLinks = galleries[g].querySelectorAll("a.image-link");
			if (!galleryLinks.length) continue;
			var group = [];
			for (var l = 0; l < galleryLinks.length; l++) {
				group.push(galleryLinks[l]);
				galleryLinks[l].addEventListener("click", function (e) {
					e.preventDefault();
					essbPinLightbox.open(this, group);
				});
			}
		}

		var adjust = document.querySelectorAll(".essb-pin-adjust");
		for (var a = 0; a < adjust.length; a++) {
			var container = adjust[a],
				smallest = 0;
			var pins = container.querySelectorAll(".essb-pin");
			for (var p = 0; p < pins.length; p++) {
				var h = pins[p].offsetHeight;
				if (smallest === 0) smallest = h;
			}
			if (smallest < 100 || smallest === 0) continue;
			for (var p2 = 0; p2 < pins.length; p2++) {
				pins[p2].style.maxHeight = smallest + "px";
			}
			if ((container.getAttribute("data-lazy") || "") == "1") {
				var onScroll = function () {
					document.removeEventListener("scroll", onScroll);
					for (var p3 = 0; p3 < pins.length; p3++) pins[p3].style.maxHeight = smallest + "px";
				};
				document.addEventListener("scroll", onScroll);
			}
		}
	};

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", essbPinGalleryInit);
	} else {
		essbPinGalleryInit();
	}
})();';
		
		essb_resource_builder()->add_js($code, false, $instance_class);
		
		$lightbox_css = '
.essb-pin-lightbox{position:fixed;inset:0;z-index:100500;display:none;align-items:center;justify-content:center}
.essb-pin-lightbox-open{display:flex}
.essb-pin-lightbox-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.85);cursor:pointer}
.essb-pin-lightbox-content{position:relative;max-width:90%;max-height:90%;text-align:center}
.essb-pin-lightbox-figure{position:relative;max-height:78vh}
.essb-pin-lightbox-figure img{max-width:100%;max-height:78vh;height:auto;display:block;margin:0 auto;border-radius:4px}
.essb-pin-lightbox-caption{color:#fff;font-size:14px;padding-top:10px;line-height:1.4}
.essb-pin-lightbox-close,.essb-pin-lightbox-prev,.essb-pin-lightbox-next{position:absolute;z-index:2;background:rgba(0,0,0,.5);border:0;color:#fff;font-size:32px;line-height:44px;width:44px;height:44px;border-radius:50%;cursor:pointer}
.essb-pin-lightbox-close{top:10px;right:10px}
.essb-pin-lightbox-prev{top:50%;left:10px;transform:translateY(-50%)}
.essb-pin-lightbox-next{top:50%;right:10px;transform:translateY(-50%)}
.essb-pin-lightbox .essb-fullscreen-pin{position:absolute;bottom:10px;left:50%;transform:translateX(-50%);z-index:2}
.essb-pin-lightbox .essb-fullscreen-pin a{display:inline-flex;align-items:center;gap:6px;background:#bd081c;color:#fff;padding:8px 14px;border-radius:20px;text-decoration:none;font-size:14px;font-weight:400}
.essb-pin-lightbox .essb-fullscreen-pin .essb_icon{margin:0}
body.hidden-scroll{overflow:hidden}';
		essb_resource_builder()->add_css($lightbox_css, $instance_class, 'footer');
		
		return $output;
	}
}

if (!function_exists('essb_output_pinable_image_code')) {
	/**
	 * The code drawing function. It will use options to generate the code for image with Pin button over it.
	 * 
	 * @param options_array $atts
	 */
	function essb_output_pinable_image_code($atts = array()) {
		$output = '';
		
		$screen_image = isset($atts['screen_image']) ? $atts['screen_image'] : '';
		$align = isset($atts['align']) ? $atts['align'] : '';
		$share_image = isset($atts['share_image']) ? $atts['share_image'] : '';
		$share_message = isset($atts['share_message']) ? $atts['share_message'] : '';
		$share_url = isset($atts['share_url']) ? $atts['share_url'] : '';
		$custom_class = isset($atts['custom_class']) ? $atts['custom_class'] : '';
		$image_link = isset($atts['image_link']) ? $atts['image_link'] : '';
		
		$output_image_size = false;
		if (has_filter('essb_pinpro_output_image_size')) {
		    $output_image_size = apply_filters('essb_pinpro_output_image_size', $output_image_size);
		}
		
		// asigning defaults if nothing is send
		if (empty($share_url)) { $share_url = get_permalink(); }
		if (empty($share_message)) { $share_message = get_the_title(); }
		if (empty($screen_image)) { $screen_image = $share_image; }
		
		// getting the default button setup
		$pinsc_template = essb_option_value('pinsc_template');
		$pinsc_button_style = essb_option_value('pinsc_button_style');
		$pinsc_button_size = essb_option_value('pinsc_button_size');
		$pinsc_css_animations = essb_option_value('pinsc_css_animations');
		$pinsc_position = essb_option_value('pinsc_position');
		$pinsc_text = essb_option_value('pinsc_text');
		$pinsc_alwayscustom = essb_option_bool_value('pinsc_alwayscustom');
		
		$pinsc_link_class = '';
		$pinsc_icon_class = '';
		
		$pinsc_template = essb_template_folder($pinsc_template);
		
		if (class_exists('ESSB_Share_Button_Styles')) {
		    $pinsc_link_class = ESSB_Share_Button_Styles::get_network_element_classes(essb_option_value('pinsc_template'), 'pinterest');
		    $pinsc_icon_class = ESSB_Share_Button_Styles::get_network_icon_classes(essb_option_value('pinsc_template'), 'pinterest');
		    
		    $additional_template_classes = ESSB_Share_Button_Styles::get_root_template_classes(essb_option_value('pinsc_template'));
		    if (!empty($additional_template_classes)) {
		        $pinsc_template .= ' ' . $additional_template_classes;
		    }
		}
		
		if ($pinsc_alwayscustom) {
			$custom_post_pin = get_post_meta( get_the_ID(), 'essb_post_pin_desc', true);
			
			if ($custom_post_pin != '') {
				$share_message = $custom_post_pin;
			}
		}
		
		$shareCmd = 'http://pinterest.com/pin/create/bookmarklet/?media=' . urlencode($share_image) . '&url=' . urlencode($share_url) . '&is_video=false' . '&description=' . urlencode($share_message);
		$buttonStyleClasses = '';
		$buttonSizeClasses = '';
		
		// begin generation of the share button commands
		if ($pinsc_button_style == 'icon_hover') {
			$buttonStyleClasses = ' essb_hide_name';
		}
		if ($pinsc_button_style == 'icon') {
			$buttonStyleClasses = ' essb_force_hide_name essb_force_hide';
		}
		if ($pinsc_button_style == 'button_name') {
			$buttonStyleClasses = ' essb_hide_icon';
		}
		if ($pinsc_button_style == 'vertical') {
			$buttonStyleClasses = ' essb_vertical_name';
		}
			
		if (!empty($pinsc_button_size)) $buttonSizeClasses = ' essb_size_' . $pinsc_button_size;
		if (!empty($pinsc_css_animations)) $buttonSizeClasses .= ' ' . $pinsc_css_animations;
		if (!empty($pinsc_position)) $buttonSizeClasses .= ' essb_pos_' . $pinsc_position;
		
		$output .= '<div class="essb-pin'.($custom_class != '' ? ' '.esc_attr($custom_class) : '').($align != '' ? ' '.esc_attr($align) : '').'">';
		if ($image_link != '') {
			$output .= '<a href="'.esc_url($image_link).'" class="image-link">';
		}
		
		if ($output_image_size) {
		    $sizes = getimagesize($screen_image);
		    $output .= '<img class="pin-generated" src="'.esc_url($screen_image).'" '.($share_image != '' ? 'data-pin-media="'.esc_url($share_image).'"' : '').' title="'.esc_attr($share_message).'" '.(isset($sizes[3]) ? $sizes[3] : '').' />';
		}
		else {		
		  $output .= '<img class="pin-generated" src="'.esc_url($screen_image).'" '.($share_image != '' ? 'data-pin-media="'.esc_url($share_image).'"' : '').' title="'.esc_attr($share_message).'" />';
		}
		
		if ($image_link != '') {
			$output .= '</a>';
		}
		
		$output .= '<div class="essb_links essb_displayed_pinimage essb_template_'.esc_attr($pinsc_template).esc_attr($buttonSizeClasses).'">';
		$output .= '<ul class="essb_links_list'.($buttonStyleClasses != '' ? ' ' . esc_attr($buttonStyleClasses) : '').'">';
		$output .= '<li class="essb_item essb_link_pinterest nolightbox essb_link_svg_icon">';
		$output .= '<a class="nolightbox'.esc_attr($pinsc_link_class).'" href="'.esc_url($shareCmd).'" target="_blank" onclick="essb.share_window(&#39;'.$shareCmd.'&#39;, &#39;pinit&#39;, &#39;pinterest&#39;); return false;"><span class="essb_icon essb_svg_icon_pinterest'.esc_attr($pinsc_icon_class).'">'.essb_svg_icon('pinterest').'</span><span class="essb_network_name">'.($pinsc_text != '' ? $pinsc_text : 'Pin').'</span></a>';
		$output .= '</li>';
		$output .= '</ul>';
		$output .= '</div>';
		
		$output .= '</div>';
		
		return $output;
	}
}