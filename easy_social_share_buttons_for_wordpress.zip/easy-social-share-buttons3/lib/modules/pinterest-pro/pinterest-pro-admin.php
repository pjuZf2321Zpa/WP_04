<?php

if (!class_exists('ESSBPinterestProAdmin')) {
    class ESSBPinterestProAdmin {
        
        public function __construct() {
            add_filter( 'attachment_fields_to_edit', array( $this, 'edit_custom_field'), 10, 2 );
            add_filter( 'attachment_fields_to_save', array( $this, 'save_custom_field'), 10, 2 );
            add_filter( 'wp_prepare_attachment_for_js', array( $this, 'prepare_js'), 10, 3 );
            add_filter( 'image_send_to_editor', array( $this, 'add_pin_description'), 10, 8 );
            
            if (!essb_option_bool_value('gutenberg_disable_pinterenst')) {
                add_action( 'enqueue_block_editor_assets', array($this, 'extend_block_example_enqueue_block_editor_assets' ));
            }
        }
        
        
        public function extend_block_example_enqueue_block_editor_assets() {
            // Enqueue our script
            wp_enqueue_script(
                'essb-pinterest-images',
                esc_url( plugins_url( '/assets/essb-pinterest-images.js', __FILE__ ) ),
                array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor' ),
                '1.0.0',
                true // Enqueue the script in the footer.
                );

            wp_enqueue_script(
                'essb-pinterest-images-title',
                esc_url( plugins_url( '/assets/essb-pinterest-images-title.js', __FILE__ ) ),
                array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-block-editor', 'wp-hooks', 'wp-compose', 'wp-components' ),
                '1.0.2',
                true // Enqueue the script in the footer.
                );
        }
        
        
        public function add_pin_description($html, $image_id, $caption, $title, $alignment, $url, $size, $alt) {
            $pin_title = get_post_meta( $image_id, 'essb_pin_title', true );
            $custom_desc = get_post_meta( $image_id, 'essb_pin_description', true );
            $pin_id = get_post_meta( $image_id, 'essb_pin_id', true);
            $pin_nopin = get_post_meta ($image_id, 'essb_pin_nopin', true);
            
            $data = '';
            
            if ($pin_title != '') {
                $data .= ' data-pin-title="'.esc_attr($pin_title).'" ';
            }
            if ($custom_desc != '') {
                $data .= ' data-pin-description="'.esc_attr($custom_desc).'" ';
            }
            if ($pin_id != '') {
                $data .= ' data-pin-id="'.esc_attr($pin_id).'" ';
            }
            
            if ($pin_nopin == 'true') {
                $data .= ' data-pin-nopin="true" ';
            }
            
            if ($data != '') {
                $html = str_replace( "<img src", "<img{$data}src", $html );
            }
            
            return $html;
        }
        
        public function edit_custom_field($form_fields, $post) {
            $form_fields['essb_pin_title'] = array(
                'label' => 'Pinterest Title',
                'input' => 'text',
                'value' => get_post_meta( $post->ID, 'essb_pin_title', true )
            );
            
            $form_fields['essb_pin_description'] = array(
                'label' => 'Pinterest Text',
                'input' => 'textarea',
                'value' => get_post_meta( $post->ID, 'essb_pin_description', true )
            );
            
            $form_fields['essb_pin_id'] = array(
                'label' => 'Pinterest Repin ID',
                'input' => 'text',
                'value' => get_post_meta( $post->ID, 'essb_pin_id', true )
            );
            
            $form_fields['essb_pin_nopin'] = array(
                'label' => 'Disable Pinning',
                'input' => 'html',
                'html' => "
                <select name='attachments[{$post->ID}][essb_pin_nopin]' id='attachments[{$post->ID}][essb_pin_nopin]'>
                <option value='false' ".(get_post_meta( $post->ID, 'essb_pin_nopin', true ) == "false" ? "selected" : "").">No</option>
    <option value='true' ".(get_post_meta( $post->ID, 'essb_pin_nopin', true ) == "true" ? "selected" : "").">Yes</option>
</select>",
'value' =>  get_post_meta( $post->ID, 'essb_pin_nopin', true )
            );
            
            return $form_fields;
        }
        
        public function save_custom_field($post, $attachment) {
            if (!current_user_can('edit_post', $post['ID'])) {
                return $post;
            }
            
            if (isset($attachment) && isset($attachment['essb_pin_title'])) {
                update_post_meta( $post['ID'], 'essb_pin_title', $this->sanitize_pin_text($attachment['essb_pin_title']) );
            }
            
            if (isset($attachment) && isset($attachment['essb_pin_description'])) {
                update_post_meta( $post['ID'], 'essb_pin_description', $this->sanitize_pin_text($attachment['essb_pin_description']) );
            }
            
            if (isset($attachment) && isset($attachment['essb_pin_id'])) {
                update_post_meta( $post['ID'], 'essb_pin_id', $this->sanitize_pin_text($attachment['essb_pin_id']) );
            }
            
            if (isset($attachment) && isset($attachment['essb_pin_nopin'])) {
                update_post_meta( $post['ID'], 'essb_pin_nopin', $this->sanitize_pin_text($attachment['essb_pin_nopin']) );
            }
            
            return $post;
        }
        
        public function prepare_js($response, $attachment, $meta) {
            $response['essb_pin_title'] = get_post_meta( $attachment->ID, 'essb_pin_title', true );
            $response['essb_pin_description'] = get_post_meta( $attachment->ID, 'essb_pin_description', true );
            $response['essb_pin_id'] = get_post_meta( $attachment->ID, 'essb_pin_id', true );
            $response['essb_pin_nopin'] = get_post_meta( $attachment->ID, 'essb_pin_nopin', true );
            
            return $response;
        }
        
        private function sanitize_pin_text($value) {
            return mb_substr(sanitize_text_field($value), 0, 100);
        }
        
    }
    
    new ESSBPinterestProAdmin();
}