<?php

/**
 * Pinterest Pro - WooCommerce Product Images Pin Button
 *
 * Adds a Pinterest Pin button over the WooCommerce product gallery image that
 * shares the currently displayed product image on Pinterest.
 *
 * @package EasySocialShareButtons
 * @since 10.x
 */

class ESSB_Pinterest_Pro_Woocommerce {

    public static $instance;

    public function __construct() {
        add_action('wp_footer', array($this, 'generate_output'), 20);
        add_action('essb_js_buffer_head', array($this, 'generate_settings'));
        add_filter('essb_css_buffer_head', array($this, 'generate_size_css'));
    }

    public static function get_instance() {
        if (!(self::$instance instanceof self)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function can_run() {
        if (is_admin()) {
            return false;
        }

        if (!class_exists('WooCommerce')) {
            return false;
        }

        if (!function_exists('is_product') || !is_product()) {
            return false;
        }

        if (!essb_option_bool_value('pinpro_woocommerce')) {
            return false;
        }

        if (essb_option_bool_value('deactivate_module_pinterestpro')) {
            return false;
        }

        if (essb_is_module_deactivated_on('pinpro')) {
            return false;
        }

        return true;
    }

    public function generate_settings($buffer) {
        if (!$this->can_run()) {
            return $buffer;
        }

        $setup = $this->get_button_setup();
        $output = 'var essbPinProWoocommerce = ' . json_encode($setup) . ';';

        return $buffer . $output;
    }

    public function generate_size_css($buffer) {
        if (!$this->can_run()) {
            return $buffer;
        }

        $button_size = essb_sanitize_option_value('pinwc_button_size');
        $button_size_mobile = essb_sanitize_option_value('pinwc_button_size_mobile');

        if (!empty($button_size) || !empty($button_size_mobile)) {
            if (!class_exists('ESSB_Share_Button_Size_Styles')) {
                include_once(ESSB3_CLASS_PATH . 'assets/class-share-button-size-styles.php');
            }

            $buffer .= ESSB_Share_Button_Size_Styles::generate_size_code_inline($button_size, $button_size_mobile);
        }

        return $buffer;
    }

    private function get_button_setup() {
        $template = essb_option_value('pinwc_template');

        $setup = array(
            'template'      => essb_template_folder($template),
            'button_style'  => essb_sanitize_option_value('pinwc_button_style'),
            'button_shape'  => essb_sanitize_option_value('pinwc_button_shape'),
            'button_shadow' => essb_option_bool_value('pinwc_button_shadow'),
            'button_size'   => essb_sanitize_option_value('pinwc_button_size'),
            'button_size_mobile' => essb_sanitize_option_value('pinwc_button_size_mobile'),
            'text'          => essb_sanitize_option_value('pinwc_text'),
            'position'      => essb_sanitize_option_value('pinwc_position'),
            'visibility'    => essb_sanitize_option_value('pinwc_visibility'),
            'active'        => true,
            'svgIcon'       => essb_svg_icon('pinterest'),
        );

        if (class_exists('ESSB_Share_Button_Styles')) {
            $setup['template_a_class'] = ESSB_Share_Button_Styles::get_network_element_classes($template, 'pinterest');
            $setup['template_icon_class'] = ESSB_Share_Button_Styles::get_network_icon_classes($template, 'pinterest');

            $additional_template_classes = ESSB_Share_Button_Styles::get_root_template_classes($template);
            if (!empty($additional_template_classes)) {
                $setup['template'] .= ' ' . $additional_template_classes;
            }
        }

        return $setup;
    }

    public function generate_output() {
        if (!$this->can_run()) {
            return;
        }

        global $product;

        if (!$product) {
            return;
        }

        $product_id = $product->get_id();
        $title = $product->get_name();
        $description = $product->get_short_description();
        if (empty($description)) {
            $description = $title;
        }

        $product_url = urlencode(get_permalink($product_id));
        $pin_url = 'https://pinterest.com/pin/create/button/?url=' . $product_url . '&description=' . urlencode($title . ' - ' . $description);

        $setup = $this->get_button_setup();

        $buttonStyleClasses = '';
        if ($setup['button_style'] == 'icon_hover') {
            $buttonStyleClasses = ' essb_hide_name';
        }
        if ($setup['button_style'] == 'icon') {
            $buttonStyleClasses = ' essb_force_hide_name essb_force_hide';
        }
        if ($setup['button_style'] == 'button_name') {
            $buttonStyleClasses = ' essb_hide_icon';
        }
        if ($setup['button_style'] == 'vertical') {
            $buttonStyleClasses = ' essb_vertical_name';
        }

        $buttonSizeClasses = '';
        if (!empty($setup['button_size'])) {
            $buttonSizeClasses .= ' essb_size_' . esc_attr($setup['button_size']);
        }
        if (!empty($setup['button_size_mobile'])) {
            $buttonSizeClasses .= ' essb_size_' . esc_attr($setup['button_size_mobile']) . '_mobile';
        }

        $uid = uniqid();
        $iconMainClass = !empty($setup['svgIcon']) ? 'essb_icon_svg_pinterest' : 'essb_icon_pinterest';
        $template_a_class = isset($setup['template_a_class']) ? $setup['template_a_class'] : '';
        $template_icon_class = isset($setup['template_icon_class']) ? $setup['template_icon_class'] : '';
        $text = !empty($setup['text']) ? $setup['text'] : 'Pin';

        $output = '';

        $output .= '<div class="essb-pinterest-wc-container" style="display:none;">';
        $output .= '<div class="essb_links essb_displayed_pinimage essb_template_' . esc_attr($setup['template']) . $buttonSizeClasses . ' essb_' . esc_attr($uid) . '" data-essb-position="pinit" data-essb-postid="' . esc_attr(get_the_ID()) . '" data-essb-instance="' . esc_attr($uid) . '">';
        $output .= '<ul class="essb_links_list' . esc_attr($buttonStyleClasses) . '">';
        $output .= '<li class="essb_item essb_link_pinterest nolightbox' . (!empty($setup['svgIcon']) ? ' essb_link_svg_icon' : '') . '">';
        $output .= '<a class="essb-pinterest-wc-btn nolightbox' . (!empty($template_a_class) ? ' ' . esc_attr($template_a_class) : '') . '" rel="noreferrer noopener nofollow" href="#" data-pin-url="' . esc_url($pin_url) . '" target="_blank">';
        $output .= '<span class="essb_icon ' . esc_attr($iconMainClass) . (!empty($template_icon_class) ? ' ' . esc_attr($template_icon_class) : '') . '">' . $setup['svgIcon'] . '</span>';
        $output .= '<span class="essb_network_name">' . esc_html($text) . '</span>';
        $output .= '</a>';
        $output .= '</li>';
        $output .= '</ul>';
        $output .= '</div>';
        $output .= '</div>';

        echo $output;
    }
}

ESSB_Pinterest_Pro_Woocommerce::get_instance();
