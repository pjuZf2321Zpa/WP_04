<?php

/**
 * ESSB Core Component
 * 
 * @author appscreo
 * @package EasySocialShareButtons
 * @since 4.0
 *
 */

class ESSBCore
{
	// options container
	private $options;
	private $design_options = array();
	private $network_options = array();
	private $button_style = array();
	private $general_options = array();

	private $list_of_activated_locations = array();
	private $temporary_decativated_locations = array();

	private static $instance = null;

	public static function get_instance()
	{

		if (null == self::$instance) {
			self::$instance = new self;
		}

		return self::$instance;
	} // end get_instance;

	/**
	 * Cloning disabled
	 */
	public function __clone() {}

	/**
	 * Serialization disabled
	 */
	public function __sleep() {}

	/**
	 * De-serialization disabled
	 */
	public function __wakeup() {}


	function __construct()
	{
		global $essb_options;
		$this->options = $essb_options;

		// load settings and defaults
		$this->load();

		add_action('wp_enqueue_scripts', array($this, 'register_assets'), 1);

		// @since 3.3 myEventOn fix for display buttons in widgets
		if (class_exists('EventON')) {
			add_action('eventon_cal_variable_action', array($this, 'eventon_deactiate_content_filters'));
		}
	}

	/**
	 * External bridge to general options generated inside the class
	 */
	public function get_general_options()
	{
		return $this->general_options;
	}

	public function eventon_deactiate_content_filters($args)
	{
		$this->temporary_deactivate_content_filters();

		return $args;
	}

	public function register_assets()
	{
		global $post, $essb_options;

		if ($this->general_options['reset_postdata']) {
			wp_reset_postdata();
		}

		if (essb_is_plugin_deactivated_on() || essb_is_module_deactivated_on('share') || essb_is_module_deactivated_on_category('share')) {
			$this->deactivate_stored_filter_and_actions();
			return;
		}

		// new since @version 4.2 - option to deactivate plugin running of share function on mobile devices
		if (essb_is_mobile() && essb_option_bool_value('deactivate_mobile_share')) {
			$this->deactivate_stored_filter_and_actions();
			return;
		}

		// new since @version 5 deactivate mobile on specific posts only
		if (essb_is_mobile() && essb_is_module_deactivated_on('mobile')) {
			$this->deactivate_stored_filter_and_actions();
			return;
		}

		$this->register_locations();

		$essb_post_template = '';
		$essb_post_animations = '';
		$essb_post_content_position = '';

		$essb_post_button_position = array();

		$essb_post_native = '';
		$essb_post_native_skin = '';


		if (in_array('onmedia', $this->general_options['button_position']) && !defined('ESSB3_IMAGESHARE_ACTIVE')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/modules/social-image-share/essb-social-image-share.php');
			define('ESSB3_IMAGESHARE_ACTIVE', true);
			essb_manager()->factoryActivate('essbis', 'ESSBSocialImageShare');
			essb_depend_load_function('essb_rs_css_build_imageshare_customizer', 'lib/core/resource-snippets/essb_rs_css_build_imageshare_customizer.php');
		}

		$result = ESSB_Core_Asset_Register::register_resources($essb_post_template, $essb_post_animations, $essb_post_content_position, $this->design_options, $this->general_options);
		$this->design_options = $result['design_options'];
		$this->general_options = $result['general_options'];


		$this->general_options['included_mail'] = false;
		if (in_array('mail', $this->network_options['networks'])) {
			if ($this->network_options['mail_function'] == 'form') {
				$this->general_options['included_mail'] = true;

				essb_resource_builder()->activate_resource('mail');
			}
		}
	}

	public function load()
	{
		$loaded = ESSB_Core_Options_Loader::load($this->options);
		$this->general_options = $loaded['general_options'];
		$this->design_options = $loaded['design_options'];
		$this->network_options = $loaded['network_options'];
		$this->button_style = $loaded['button_style'];

		// apply mobile options for content positions
		if ($this->general_options['mobile_css_activate']) {
			if ($this->is_mobile_safecss()) {
				$user_set_mobile = essb_option_value('button_position_mobile');

				if (!is_array($user_set_mobile)) {
					$user_set_mobile = array();
				}

				if (in_array('sharebottom', $user_set_mobile)) {
					$this->general_options['button_position'][] = 'sharebottom';
				}
				if (in_array('sharebar', $user_set_mobile)) {
					$this->general_options['button_position'][] = 'sharebar';
				}
				if (in_array('sharepoint', $user_set_mobile)) {
					$this->general_options['button_position'][] = 'sharepoint';
				}
			}
		} else {
			if (essb_is_mobile()) {
				if (essb_option_bool_value('mobile_positions')) {
					$this->general_options['content_position'] = essb_option_value('content_position_mobile');
					$this->general_options['button_position'] = essb_option_value('button_position_mobile');
					if (! is_array($this->general_options['button_position'])) {
						$this->general_options['button_position'] = array();
					}
				}

				if (ESSB3_DEMO_MODE) {
					$demo_mode_mobile = isset($_REQUEST['mobile']) ? $_REQUEST['mobile'] : '';
					if (! empty($demo_mode_mobile)) {
						$this->general_options['button_position'] = array();
						$this->general_options['button_position'][] = $demo_mode_mobile;
					}
				}
			}
		}

	}

	public function activate($type, $hook, $function, $priority = '', $position = '')
	{
		if ($type == 'filter') {
			add_filter($hook, array($this, $function), $priority);
		} else {
			add_action($hook, array($this, $function), $priority);
		}

		$this->list_of_activated_locations[] = array('type' => $type, 'hook' => $hook, 'function' => $function, 'priority' => $priority, 'position' => $position);
	}

	public function register_locations()
	{
		global $post;

		if (is_admin()) {
			return;
		}

		if ($this->general_options['reset_postdata']) {
			wp_reset_postdata();
		}

		// @since version 3.1 CSS hide of mobile buttons
		if (essb_option_bool_value('mobile_css_activate')) {
			essb_depend_load_function('essb_css_build_mobile_responsive', 'lib/helpers/assets/builder-share-reponsive.php');
		}


		$this->list_of_activated_locations = array();

		$current_post_content_locations = $this->general_options['content_position'];
		$current_post_button_position = $this->general_options['button_position'];

		// different button placement by post type is only avaiable in full interface
		if (!defined('ESSB3_LIGHTMODE') && !ESSB_Runtime_Cache::is('adaptive-styles') && essb_option_bool_value('positions_by_pt')) {
			$content_position_by_pt = '';
			$button_position_by_pt = '';

			if (isset($post)) {
				$content_position_by_pt = essb_option_value('content_position_' . $post->post_type);
				$button_position_by_pt = essb_option_value('button_position_' . $post->post_type);
			}

			/**
			 * Homepage
			 */
			if (is_front_page()) {
				$content_position_by_pt = essb_option_value('content_position_homepage');
				$button_position_by_pt = essb_option_value('button_position_homepage');
			}


			if (!empty($content_position_by_pt)) {
				$current_post_content_locations = $content_position_by_pt;
				$this->general_options['content_position'] = $content_position_by_pt;
			}

			if (!empty($button_position_by_pt) && is_array($button_position_by_pt)) {
				if (essb_exist_in_array($this->general_options['button_position'], 'sharebottom')) {
					$button_position_by_pt[] = 'sharebottom';
				}
				if (essb_exist_in_array($this->general_options['button_position'], 'sharebar')) {
					$button_position_by_pt[] = 'sharebar';
				}
				if (essb_exist_in_array($this->general_options['button_position'], 'sharepoint')) {
					$button_position_by_pt[] = 'sharepoint';
				}

				$current_post_button_position = $button_position_by_pt;
				$this->general_options['button_position'] = $button_position_by_pt;
			}
		}

		if ($current_post_content_locations != '' && $current_post_content_locations != 'content_manual') {
			if (essb_option_bool_value('using_elementor_events')) {
				$this->activate('action', 'elementor/frontend/the_content', 'display_inline', $this->general_options['priority_of_buttons'], 'content_position');

				// Fixing elementor loading duplicated content https://support.creoworx.com/forums/topic/elementor-issue/
				$elementor_page = get_post_meta(get_the_ID(), '_elementor_edit_mode', true);
				if (!$elementor_page) {
					$this->activate('filter', 'the_content', 'display_inline', $this->general_options['priority_of_buttons'], 'content_position');
				}
			} else {
				$this->activate('filter', 'the_content', 'display_inline', $this->general_options['priority_of_buttons'], 'content_position');
			}
		}

		if (essb_option_bool_value('pinterest_images')) {
			$this->activate('filter', 'the_content', 'trigger_pinterest_image_mark', '999', 'content_position');
		}

		$this->activate_button_position_filters($current_post_button_position, $this->general_options['content_position']);

		// excerpt display
		if ($this->general_options['display_excerpt']) {

			// @since verion 3.0.4 - build in Avada theme bridge
			if (class_exists('FusionCore_Plugin')) {
				// detected Avada theme
				if ($this->general_options['display_excerpt_pos'] == 'top') {
					$this->activate('action', 'fusion_blog_shortcode_loop_content', 'display_excerpt_avada', $this->general_options['priority_of_buttons'], '');

					$this->activate('action', 'avada_blog_post_content', 'display_excerpt_avada', '1', '');
				} else {
					$this->activate('action', 'fusion_blog_shortcode_loop_footer', 'display_excerpt_avada', $this->general_options['priority_of_buttons'], '');

					$this->activate('action', 'avada_blog_post_content', 'display_excerpt_avada', '20', '');
				}
			} else {
				$this->activate('filter', 'the_excerpt', 'display_excerpt', $this->general_options['priority_of_buttons'], 'excerpt_position');
			}
		}

		// clean buttons 
		if ($this->general_options['apply_clean_buttons']) {

			if ($this->general_options['apply_clean_buttons_method'] == 'actionremove') {
				add_filter('get_the_excerpt', array($this, 'remove_buttons_excerpts_method2'), -999);
			} else if ($this->general_options['apply_clean_buttons_method'] == 'remove2') {
				// do nothing
			} else {
				if ($this->general_options['apply_clean_buttons_method'] == 'clean2') {
					add_filter('get_the_excerpt', array($this, 'remove_buttons_excerpts_method3'));
				} else {
					add_filter('get_the_excerpt', array($this, 'remove_buttons_excerpts'));
				}
			}
		}

		if (!defined('ESSB3_LIGHTMODE')) {
			// additional module integraton hooks
			//-- WooCommerce

			// refactor in version 4.2 for on demand code load
			if (
				essb_option_bool_value('woocommece_share') || essb_option_bool_value('woocommerce_after_add_to_cart_form') ||
				essb_option_bool_value('woocommece_beforeprod') || essb_option_bool_value('woocommece_afterprod')
			) {

				essb_depend_load_function('essb_woocommerce_activate', 'lib/core/integrations/woocommerce.php');
				essb_woocommerce_activate();
			}






			// BBPress
			if (essb_option_bool_value('bbpress_forum') || essb_option_bool_value('bbpress_topic')) {

				essb_depend_load_function('essb_bbpress_activate', 'lib/core/integrations/bbpress.php');
				essb_bbpress_activate();
			}

			// BuddyPress
			if (essb_option_bool_value('buddypress_group') || essb_option_bool_value('buddypress_activity')) {

				essb_depend_load_function('essb_buddypress_activate', 'lib/core/integrations/buddypress.php');
				essb_buddypress_activate();
			}
		}
	}

	function remove_buttons_excerpts_method2($text)
	{
		remove_filter('the_content', array($this, 'display_inline'), $this->general_options['priority_of_buttons']);
		remove_filter('the_content', array($this, 'display_postfloat'));
		remove_filter('the_content', array($this, 'trigger_bottom_mark'), 9999);
		remove_filter('the_content', array($this, 'display_onmedia'), 9999);
		remove_filter('the_content', array($this, 'trigger_pinterest_image_mark'), 999);

		return $text;
	}

	function remove_buttons_excerpts($text)
	{
		if (!function_exists('essb_excerpt_clean_method1')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/core/extenders/essb-core-extender-excerpt-clean-method1.php');
		}

		return essb_excerpt_clean_method1($text, $this->options, $this->network_options['networks'], $this->network_options['default_names']);
	}

	function remove_buttons_excerpts_method3($text)
	{

		if (!function_exists('essb_excerpt_clean_method3')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/core/extenders/essb-core-extender-excerpt-clean-method3.php');
		}

		return essb_excerpt_clean_method3($text, $this->options, $this->network_options['networks'], $this->network_options['default_names']);
	}


	function reactivate_content_filters_after_temporary_deactivate()
	{
		if (is_admin()) {
			return;
		}

		foreach ($this->temporary_decativated_locations as $hook_data) {
			$type = isset($hook_data['type']) ? $hook_data['type'] : 'filter';
			$hook = isset($hook_data['hook']) ? $hook_data['hook'] : 'the_content';
			$action = isset($hook_data['function']) ? $hook_data['function'] : '';
			$priority = isset($hook_data['priority']) ? $hook_data['priority'] : '';
			$position = isset($hook_data['position']) ? $hook_data['position'] : '';

			if ($hook != 'the_content' && $hook != 'the_excerpt') {
				continue;
			}

			if ($hook != '' && $action != '') {
				$this->activate($type, $hook, $action, $priority, $position);
			}
		}

		$this->temporary_decativated_locations = array();
	}

	function temporary_deactivate_content_filters()
	{
		$this->temporary_decativated_locations = array();

		if (is_admin()) {
			return;
		}

		foreach ($this->list_of_activated_locations as $hook_data) {
			$type = isset($hook_data['type']) ? $hook_data['type'] : 'filter';
			$hook = isset($hook_data['hook']) ? $hook_data['hook'] : 'the_content';
			$action = isset($hook_data['function']) ? $hook_data['function'] : '';
			$priority = isset($hook_data['priority']) ? $hook_data['priority'] : '';
			$position = isset($hook_data['position']) ? $hook_data['position'] : '';

			if ($hook != 'the_content' && $hook != 'the_excerpt') {
				continue;
			}

			if ($hook != '' && $action != '') {
				if ($type == 'filter') {
					if (!empty($priority)) {
						remove_filter($hook, array($this, $action), $priority);
					} else {
						remove_filter($hook, array($this, $action));
					}
				}
				if ($type == 'action') {
					if (!empty($priority)) {
						remove_action($hook, array($this, $action), $priority);
					} else {
						remove_action($hook, array($this, $action));
					}
				}
			}

			$this->temporary_decativated_locations[] = $hook_data;
		}
	}

	function activate_button_position_filters($current_post_button_position, $current_post_content_position = '')
	{

		if (is_array($current_post_button_position)) {
			foreach ($current_post_button_position as $position) {
				if (method_exists($this, 'display_' . $position)) {
					if ($position == 'postfloat') {
						$this->activate('filter', 'the_content', 'display_postfloat', $this->general_options['priority_of_buttons'], 'button_position');
						$this->activate('filter', 'the_content', 'trigger_bottom_mark', '9999', 'button_position');

						if (essb_option_bool_value('using_elementor_events')) {
							$this->activate('filter', 'elementor/frontend/the_content', 'display_postfloat', $this->general_options['priority_of_buttons'], 'button_position');
							$this->activate('filter', 'elementor/frontend/the_content', 'trigger_bottom_mark', '9999', 'button_position');
						}
					} else if ($position == 'onmedia') {
						$this->activate('filter', 'the_content', 'display_onmedia', '9999', 'button_position');
					} else {
						if ($position == 'popup' && essb_option_bool_value('popup_display_purchase')) {
							//woocommerce_thankyou
							$this->activate('action', 'woocommerce_thankyou', 'display_popup', $this->general_options['priority_of_buttons'], 'button_position');
						}

						if ($position == 'postbar') {
							$this->activate('filter', 'the_content', 'trigger_postbar_readbar', $this->general_options['priority_of_buttons'], 'button_position');
							if (essb_option_bool_value('using_elementor_events')) {
								$this->activate('filter', 'elementor/frontend/the_content', 'trigger_postbar_readbar', $this->general_options['priority_of_buttons'], 'button_position');
							}
						}

						$this->activate('filter', 'the_content', 'trigger_bottom_mark', '9999', 'button_position');
						$this->activate('action', 'wp_footer', "display_{$position}", $this->general_options['priority_of_buttons'], 'button_position');
						if (essb_option_bool_value('using_elementor_events')) {
							$this->activate('filter', 'elementor/frontend/the_content', 'trigger_bottom_mark', '9999', 'button_position');
						}
					}
				}
			}
		}

		if ($current_post_content_position == 'content_followme') {
			$this->activate('action', 'wp_footer', 'display_followme', '', 'button_position');
		}
	}


	function deactivate_stored_filter_and_actions($group_filter = '')
	{
		if (is_admin()) {
			return;
		}

		foreach ($this->list_of_activated_locations as $hook_data) {
			$type = isset($hook_data['type']) ? $hook_data['type'] : 'filter';
			$hook = isset($hook_data['hook']) ? $hook_data['hook'] : 'the_content';
			$action = isset($hook_data['function']) ? $hook_data['function'] : '';
			$priority = isset($hook_data['priority']) ? $hook_data['priority'] : '';
			$position = isset($hook_data['position']) ? $hook_data['position'] : '';

			if ($group_filter != '') {
				if ($group_filter != $position || empty($position)) {
					continue;
				}
			}

			if ($hook != '' && $action != '') {
				if ($type == 'filter') {
					if (!empty($priority)) {
						remove_filter($hook, array($this, $action), $priority);
					} else {
						remove_filter($hook, array($this, $action));
					}
				}
				if ($type == 'action') {
					if (!empty($priority)) {
						remove_action($hook, array($this, $action), $priority);
					} else {
						remove_action($hook, array($this, $action));
					}
				}
			}
		}

		$this->list_of_activated_locations = array();
	}

	function check_applicability($post_types = array(), $location = '')
	{
		return ESSB_Core_Applicability_Cheker::check($post_types, $location, $this->general_options);
	}

	function check_applicability_excerpt($post_types = array(), $location = '')
	{

		if (!function_exists('essb_check_applicability_excerpt')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/core/extenders/essb-core-extender-check-applicability-excerpt.php');
		}

		return essb_check_applicability_excerpt($post_types, $location, $this->options, $this->general_options);
	}

	// -- additional plugin special integration hooks

	function trigger_postbar_readbar($content)
	{
		return '<div class="essb_postbar_start"></div>' . $content . '<div class="essb_postbar_end"></div>';
	}

	function trigger_bottom_mark($content)
	{
		$deactivate_trigger = essb_option_bool_value('deactivate_bottom_mark');

		$deactivate_trigger = apply_filters('essb5_remove_bottom_mark', $deactivate_trigger);

		if ($deactivate_trigger) {
			return $content;
		} else {
			return $content . '<div class="essb_break_scroll"></div>';
		}
	}

	function trigger_pinterest_image_mark($content)
	{
		if (essb_option_bool_value('pinterest_images')) {
			$content .= '<div class="essb-pinterest-images"></div>';
		}

		return $content;
	}

	private function render_simple_display($position, $load_func, $load_file, $share_position = '')
	{
		$post_types = $this->general_options['display_in_types'];
		$is_valid = $this->check_applicability($post_types, $position);
		$output = '';

		if ($is_valid) {
			if (empty($share_position)) {
				$share_position = $position;
			}

			essb_depend_load_function($load_func, 'lib/core/display-methods/' . $load_file);

			$share_buttons = $this->generate_share_buttons($share_position);
			$output .= call_user_func($load_func, $share_buttons);
		}

		echo $output;
	}

	private function render_class_display($position, $class, $method, $file, $is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;
		if ($is_shortcode == true) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, $position);
		}

		$output = '';

		if ($is_valid) {

			if (!class_exists($class)) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/core/display-methods/' . $file);
			}

			$share_buttons = '';
			if (!$is_shortcode) {
				$share_buttons = $this->generate_share_buttons($position);
			} else {
				$share_buttons = $this->generate_share_buttons($position, 'share', $share_options, true, $shortcode_options);
			}

			$output = call_user_func(array($class, $method), $this->options, $share_buttons, $is_shortcode, $shortcode_options);

			if (!$is_shortcode) {
				echo $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	function display_booster()
	{
		$this->render_simple_display('booster', 'essb5_generate_booster', 'essb-display-method-booster.php');
	}

	function display_cornerbar()
	{
		$this->render_simple_display('cornerbar', 'essb5_generate_corner_bar', 'essb-display-method-cornerbar.php');
	}

	function display_sharebutton()
	{
		$this->render_simple_display('sharebutton', 'essb5_generate_share_button', 'essb-display-method-button.php');
	}

	function display_followme()
	{
		$this->render_simple_display('followme', 'essb5_generate_followme_bar', 'essb-display-method-followme.php', 'followme_bottom');
	}

	/**
	 * display_point
	 * 
	 * Generate share point code
	 * 
	 * @param unknown_type $is_shortcode
	 * @param unknown_type $shortcode_options
	 * @param unknown_type $share_options
	 */
	function display_point($is_shortcode = true, $shortcode_options = array(), $share_options = array())
	{
		global $post;

		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;
		if ($is_shortcode) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'point');

			// post share bar cannot work on list of posts
			if (!is_single() && !is_page() && !essb_option_bool_value('point_allowall')) {
				$is_valid = false;
			}
		}

		$output = '';
		if ($is_valid) {
			if (!class_exists('ESSBDisplayMethodPoint')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/core/display-methods/essb-display-method-point.php');
			}

			$post_details = essb_get_post_share_details('point');

			$share_buttons = '';
			$total_shares_code = essb_shortcode_total_shares(array('inline' => 'yes', 'url' => $post_details['url']));

			if (!$is_shortcode) {
				$share_buttons = $this->generate_share_buttons('point', 'share', array('only_share' => true));
			} else {
				$share_buttons = $this->generate_share_buttons('point', 'share', $share_options, true, $shortcode_options);
			}

			// Helper class to generate post share bar
			$output = ESSBDisplayMethodPoint::generate_point_code($this->options, $share_buttons, $total_shares_code, $is_shortcode, $shortcode_options);

			// when it is not a shortcode we output the generated markup
			if (!$is_shortcode) {
				print $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	/**
	 * display_postbar
	 * 
	 * Generate social post bar display method
	 * 
	 * @param bool $is_shortcode
	 * @param array $shortcode_options
	 * @param array $share_options
	 * @since 3.5
	 */
	function display_postbar($is_shortcode = true, $shortcode_options = array(), $share_options = array())
	{
		global $post;

		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;
		if ($is_shortcode) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'postbar');

			// post share bar cannot work on list of posts
			if (!is_single() && !is_page()) {
				$is_valid = false;
			}
		}


		$output = '';

		if ($is_valid) {


			if (!class_exists('ESSBDisplayMethodPostBar')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/core/display-methods/essb-display-method-postbar.php');
			}

			$share_buttons = '';
			$total_shares_code = essb_shortcode_total_shares(array('inline' => 'yes'));

			if (!$is_shortcode) {
				$share_buttons = $this->generate_share_buttons('postbar');
			} else {
				$share_buttons = $this->generate_share_buttons('postbar', 'share', $share_options, true, $shortcode_options);
			}

			// Helper class to generate post share bar
			$output = ESSBDisplayMethodPostBar::generate_postbar_code($this->options, $share_buttons, $total_shares_code);

			// when it is not a shortcode we output the generated markup
			if (!$is_shortcode) {
				print $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}


	function display_sharebottom($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		if (!$this->is_mobile_safecss()) {
			return;
		}
		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;

		$hide_on_end = essb_option_bool_value('mobile_sharebuttonsbar_hideend');
		$hide_on_end_percent = essb_option_value('mobile_sharebuttonsbar_hideend_percent');
		$mobile_sharebuttonsbar_showscroll = essb_option_value('mobile_sharebuttonsbar_showscroll');
		$hide_before_end = ' data-hideend="' . ($hide_on_end ? "true" : "false") . '" data-hideend-percent="' . esc_attr($hide_on_end_percent) . '" data-show-percent="' . esc_attr($mobile_sharebuttonsbar_showscroll) . '"';
		$mobile_sharebuttonsbar_pos = essb_option_value('mobile_sharebuttonsbar_pos');
		if ($this->general_options['mobile_css_activate']) {
			$hide_before_end .= ' data-responsive="true"';
		}

		$output = '';

		$css_hidden_load = '';
		if (intval($mobile_sharebuttonsbar_showscroll) > 0) {
			$css_hidden_load = ' essb-mobile-break';
		}
		if ($mobile_sharebuttonsbar_pos == 'top') {
			$css_hidden_load .= ' essb-mobile-sharetop';
		}

		if ($is_shortcode == true) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'sharebottom');
		}

		if ($is_valid) {
			if (!$is_shortcode) {
				$sharebuttons_code = $this->generate_share_buttons('sharebottom');

				$bar_bg = essb_option_value('sharebottom_usercontent_bg');
				if ($bar_bg != '') {
					$bar_bg = ' style="background-color:' . esc_attr($bar_bg) . ';"';
				}

				$bar_hidden = '';
				$bar_controled = '';
				if (essb_option_bool_value('sharebottom_usercontent_control')) {
					$bar_hidden = ' essb-mobile-break';
					$bar_controled = ' data-connected="true"';
				}

				if ($mobile_sharebuttonsbar_pos != 'top' && essb_option_bool_value('sharebottom_adarea') && essb_option_value('sharebottom_usercontent') != '') {
					$bottombar_usercontent = essb_option_value('sharebottom_usercontent');
					$bottombar_usercontent = stripslashes($bottombar_usercontent);
					$bottombar_usercontent = do_shortcode($bottombar_usercontent);

					$sharebuttons_code .= '<div class="adholder"' . $bar_bg . '>' . $bottombar_usercontent . '</div>';
				}

				printf('<div class="essb-mobile-sharebottom%3$s"%2$s>%1$s</div>', $sharebuttons_code, $hide_before_end, esc_attr($css_hidden_load));

				if ($mobile_sharebuttonsbar_pos == 'top' && essb_option_bool_value('sharebottom_adarea') && essb_option_value('sharebottom_usercontent') != '') {
					$bottombar_usercontent = essb_option_value('sharebottom_usercontent');
					$bottombar_usercontent = stripslashes($bottombar_usercontent);
					$bottombar_usercontent = do_shortcode($bottombar_usercontent);
					echo '<div class="adholder essb-adholder-bottom' . $bar_hidden . '"' . $bar_bg . $bar_controled . '>' . $bottombar_usercontent . '</div>';
				}
			} else {
				$sharebuttons_code = $this->generate_share_buttons('sharebottom', 'share', $share_options, true, $shortcode_options);

				if ($mobile_sharebuttonsbar_pos != 'top' && essb_option_bool_value('sharebottom_adarea') && essb_option_value('sharebottom_usercontent') != '') {

					$bottombar_usercontent = essb_option_value('sharebottom_usercontent');
					$bottombar_usercontent = stripslashes($bottombar_usercontent);
					$bottombar_usercontent = do_shortcode($bottombar_usercontent);

					$sharebuttons_code .= '<div class="adholder"' . $bar_bg . '>' . $bottombar_usercontent . '</div>';
				}

				$output = sprintf('<div class="essb-mobile-sharebottom%3$s"%2$s>%1$s</div>', $sharebuttons_code, $hide_before_end, esc_attr($css_hidden_load));

				if ($mobile_sharebuttonsbar_pos == 'top' && essb_option_bool_value('sharebottom_adarea') && essb_option_value('sharebottom_usercontent') != '') {

					$bottombar_usercontent = essb_option_value('sharebottom_usercontent');
					$bottombar_usercontent = stripslashes($bottombar_usercontent);
					$bottombar_usercontent = do_shortcode($bottombar_usercontent);

					$output .= '<div class="adholder essb-adholder-bottom' . $bar_hidden . '"' . $bar_bg . $bar_controled . '>' . $bottombar_usercontent . '</div>';
				}
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	function display_sharebar($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		if (!$this->is_mobile_safecss()) {
			return;
		}
		$this->render_class_display('sharebar', 'ESSBDisplayMethodMobile', 'generate_sharebar_code', 'essb-display-method-mobile.php', $is_shortcode, $shortcode_options, $share_options);
	}


	function display_sharepoint($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		if (!$this->is_mobile_safecss()) {
			return;
		}
		$this->render_class_display('sharepoint', 'ESSBDisplayMethodMobile', 'generate_sharepoint_code', 'essb-display-method-mobile.php', $is_shortcode, $shortcode_options, $share_options);
	}

	function display_topbar($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		$this->render_class_display('topbar', 'ESSBDisplayMethodTopBar', 'generate_topbar_code', 'essb-display-method-topbar.php', $is_shortcode, $shortcode_options, $share_options);
	}

	function display_bottombar($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		$this->render_class_display('bottombar', 'ESSBDisplayMethodBottomBar', 'generate_bottombar_code', 'essb-display-method-bottombar.php', $is_shortcode, $shortcode_options, $share_options);
	}

	function display_sidebar($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		$post_types = $this->general_options['display_in_types'];


		$is_valid = false;
		if ($is_shortcode) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'sidebar');
		}

		$output = '';

		if ($is_valid) {
			essb_depend_load_function('essb_sidebar_extender', 'lib/core/display-methods/essb-display-method-sidebar.php');

			if (!$is_shortcode) {
				$output .= $this->generate_share_buttons('sidebar');
			} else {
				$output .= $this->generate_share_buttons('sidebar', 'share', $share_options, true, $shortcode_options);
			}

			if (!$is_shortcode) {
				echo $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	function display_heroshare($is_shortcode = true, $shortcode_popafter = '', $shortcode_options = array(), $share_options = array())
	{
		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;
		if ($is_shortcode) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'heroshare');

			// hero share cannot work on list of posts
			if (!is_single() && !is_page()) {
				$is_valid = false;
			}
		}

		// @since 3.0.4 - avoid display popup for logged in users
		$popup_avoid_logged_users = essb_option_bool_value('heroshare_avoid_logged_users');
		if ($popup_avoid_logged_users) {
			if (is_user_logged_in()) {
				$is_valid = false;
			}
		}

		if ($is_valid) {

			if (!class_exists('ESSBDisplayMethodHeroShare')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/core/display-methods/essb-display-method-heroshare.php');
			}

			if (ESSB3_DEMO_MODE) {
				$is_active_option = isset($_REQUEST['heroshare']) ? $_REQUEST['heroshare'] : '';
				if (!empty($is_active_option)) {
					$popup_second_type = $is_active_option;
				}

				$is_active_option = isset($_REQUEST['heroshare_title']) ? $_REQUEST['heroshare_title'] : '';
				if (!empty($is_active_option)) {
					$popup_second_title = $is_active_option;
				}
			}


			$post_details = essb_get_post_share_details('heroshare');

			$share_buttons = '';
			if (!$is_shortcode) {
				$share_buttons = $this->generate_share_buttons('heroshare');
			} else {
				$share_buttons = $this->generate_share_buttons('heroshare', 'share', $share_options, true, $shortcode_options);
			}

			$output = ESSBDisplayMethodHeroShare::generate_heroshare_code($this->options, $share_buttons, $is_shortcode, $shortcode_options, $post_details);

			if (!$is_shortcode) {
				echo $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	function display_popup($is_shortcode = true, $shortcode_popafter = '', $shortcode_options = array(), $share_options = array())
	{
		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;
		if ($is_shortcode) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'popup');
		}

		// @since 3.0.4 - avoid display popup for logged in users
		$popup_avoid_logged_users = essb_option_bool_value('popup_avoid_logged_users');
		if ($popup_avoid_logged_users) {
			if (is_user_logged_in()) {
				$is_valid = false;
			}
		}

		$output = '';

		if ($is_valid) {

			if (!class_exists('ESSBDisplayMethodPopup')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/core/display-methods/essb-display-method-popup.php');
			}

			$share_buttons = '';

			if (!$is_shortcode) {
				$share_buttons = $this->generate_share_buttons('popup');
			} else {
				$share_buttons = $this->generate_share_buttons('popup', 'share', $share_options, true, $shortcode_options);
			}

			$output = ESSBDisplayMethodPopup::generate_popup_code($this->options, $share_buttons, $is_shortcode, $shortcode_options);

			if (!$is_shortcode) {
				echo $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	function display_flyin($is_shortcode = false, $shortcode_options = array(), $share_options = array())
	{
		$post_types = $this->general_options['display_in_types'];

		$is_valid = false;
		if ($is_shortcode) {
			$is_valid = true;
		} else {
			$is_valid = $this->check_applicability($post_types, 'flyin');
		}

		$output = '';

		if ($is_valid) {

			if (!class_exists('ESSBDisplayMethodFlyin')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/core/display-methods/essb-display-method-flyin.php');
			}

			$share_buttons = '';

			if (!$is_shortcode) {
				$flyin_noshare = essb_option_bool_value('flyin_noshare');
				if (!$flyin_noshare) {
					$share_buttons = $this->generate_share_buttons('flyin');
				}
			} else {
				$share_buttons = $this->generate_share_buttons('flyin', 'share', $share_options, true, $shortcode_options);
			}

			$output = ESSBDisplayMethodFlyin::generate_flyin_code($this->options, $share_buttons, $is_shortcode, $shortcode_options);

			if (!$is_shortcode) {
				echo $output;
			}
		}

		if ($is_shortcode) {
			return $output;
		}
	}

	function shortcode_display_postfloat($shortcode_options = array(), $share_options = array())
	{
		$display_key = 'postfloat';
		$float_onsingle_only = essb_option_bool_value('float_onsingle_only');
		if ($float_onsingle_only) {
			if (is_archive() || is_front_page() || is_search() || is_tag() || is_post_type_archive() || is_home()) {
				$display_key = 'top';
			}
		}

		return $this->generate_share_buttons($display_key, 'share', $share_options, true, $shortcode_options);
	}

	function display_postfloat($content)
	{
		//
		$links_before = '';
		$links_after = '';

		$display_key = 'postfloat';
		$float_onsingle_only = essb_option_bool_value('float_onsingle_only');
		if ($float_onsingle_only) {
			if (is_archive() || is_front_page() || is_search() || is_tag() || is_post_type_archive() || is_home()) {
				$display_key = 'top';
			}
		}

		$post_types = $this->general_options['display_in_types'];
		if ($this->check_applicability($post_types, $display_key)) {
			essb_depend_load_function('essb_postfloat_extender', 'lib/core/display-methods/essb-display-method-postfloat.php');
			$links_before = $this->generate_share_buttons($display_key);
		}

		return $links_before . $content;
	}

	function display_excerpt($content)
	{
		$post_types = $this->general_options['display_in_types'];

		$links_before = '';
		$links_after = '';

		if ($this->check_applicability_excerpt($post_types, 'excerpt')) {

			if ($this->general_options['display_excerpt_pos'] == 'top') {
				$links_before = $this->generate_share_buttons('excerpt');
			}
			if ($this->general_options['display_excerpt_pos'] == 'bottom') {
				$links_after = $this->generate_share_buttons('excerpt');
			}
		}
		return $links_before . $content . $links_after;
	}

	function display_excerpt_avada()
	{
		echo $this->generate_share_buttons('excerpt');
	}

	function display_inline($content)
	{
		/**
		 * Include additiong inline share buttons display to prevent appearance of non-associated
		 * parts of content
		 */
		global $wp_current_filter;

		if (! empty($wp_current_filter) && is_array($wp_current_filter)) {
			foreach ($wp_current_filter as $filter) {
				if ($filter == 'wp_head') {
					return $content;
				}
			}
		}

		if (! is_main_query()) {
			return $content;
		}

		if (essb_option_bool_value('hide_content_archive')) {
			if (is_archive() || is_search() || is_tag() || is_post_type_archive()) {
				return $content;
			}
		}

		if (essb_option_bool_value('hide_content_home')) {
			if (is_home() || is_front_page()) {
				return $content;
			}
		}

		/**
		 * Start generation of share buttons if OK
		 */

		$links_before = '';
		$links_after = '';

		$post_types = $this->general_options['display_in_types'];
		$content_position = $this->general_options['content_position'];

		// @since 11.1 Native positions are removed
		if ($content_position == 'content_sharenative' || $content_position == 'content_nativeshare') {
			$content_position = 'content_both';
		}

		$check_location_options_top = '';
		$check_location_options_bottom = '';
		if ($content_position == 'content_top' || $content_position == 'content_both' || $content_position == 'content_sharenative') {
			if ($this->check_applicability($post_types, 'top')) {

				$share_buttons_only = ($content_position == 'content_sharenative') ? true : false;

				$links_before = $this->generate_share_buttons('top', 'share', array('only_share' => $share_buttons_only));
			}
		}

		if ($content_position == 'content_float' || $content_position == 'content_floatboth') {

			$display_key = 'float';
			$float_onsingle_only = essb_option_bool_value('float_onsingle_only');
			if ($float_onsingle_only) {
				if (is_archive() || is_front_page() || is_search() || is_tag() || is_post_type_archive() || is_home()) {
					$display_key = 'top';
				}
			}

			if ($this->check_applicability($post_types, $display_key)) {
				essb_depend_load_function('essb_float_extender', 'lib/core/display-methods/essb-display-method-float.php');
				$links_before = $this->generate_share_buttons($display_key);
			}
		}

		if ($content_position == 'content_bottom' || $content_position == 'content_both' || $content_position == 'content_nativeshare' || $content_position == 'content_floatboth') {

			if ($this->check_applicability($post_types, 'bottom')) {
				$share_buttons_only = ($content_position == 'content_nativeshare') ? true : false;
				$links_after = $this->generate_share_buttons('bottom', 'share', array('only_share' => $share_buttons_only));
			}
		}

		if ($content_position == 'content_nativeshare') {
			if ($this->check_applicability($post_types, 'top')) {
				$links_before = $this->generate_like_buttons('top');
			}
		}

		if ($content_position == 'content_sharenative') {
			if ($this->check_applicability($post_types, 'bottom')) {
				$links_after = $this->generate_like_buttons('bottom');
			}
		}


		if ($content_position == 'content_followme') {
			$appear_at = essb_option_value('followme_content');

			if ($appear_at == '' || $appear_at == 'above') {
				if ($this->check_applicability($post_types, 'followme')) {
					$links_before = $this->generate_share_buttons('followme');
				}
			}

			if ($appear_at == '' || $appear_at == 'below') {
				if ($this->check_applicability($post_types, 'followme')) {
					$links_after = $this->generate_share_buttons('followme');
				}
			}
		}

		return $links_before . $content . $links_after;
	}

	// -- end: content display methods

	// start: buttons drawer

	function generate_like_buttons($position)
	{
		return '';
	}

	function generate_share_buttons($position, $likeshare = 'share', $share_options = array(), $is_shortcode = false, $shortcode_options = array(), $media_url = '')
	{
		return ESSB_Core_Button_Generator::generate($position, $likeshare, $share_options, $is_shortcode, $shortcode_options, $media_url, $this->general_options, $this->network_options, $this->design_options, $this->button_style);
	}


	function get_buttons_visual_options($position = '')
	{
		return ESSB_Core_Button_Generator::get_buttons_visual_options($position, $this->design_options, $this->network_options, $this->general_options, $this->button_style);
	}


	// end: button drawer

	function is_mobile()
	{
		// @since 3.4.1 - moved check in global function
		return essb_is_mobile();
	}

	function is_mobile_safecss()
	{
		if ($this->general_options['mobile_css_activate']) {
			return true;
		} else {
			return essb_is_mobile();
		}
	}
}
