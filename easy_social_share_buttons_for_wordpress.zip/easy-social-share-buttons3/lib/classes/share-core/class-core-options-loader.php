<?php

class ESSB_Core_Options_Loader {

    public static function load($options) {
        $all_networks = essb_available_social_networks(true);

        return array(
            'general_options' => self::load_general($options),
            'design_options' => self::load_design($options),
            'network_options' => self::load_network($options, $all_networks),
            'button_style' => self::load_button_style($options),
        );
    }

    private static function load_general($options) {
        $general_options = array();

        $general_options['mobile_exclude_tablet'] = essb_option_bool_value('mobile_exclude_tablet');
        $general_options['mobile_css_activate'] = essb_option_bool_value('mobile_css_activate');

        if (!essb_option_bool_value('mobile_positions') && essb_sanitize_option_value('functions_mode_mobile') != 'auto') {
            $general_options['mobile_css_activate'] = false;
        }

        $general_options['total_counter_afterbefore_text'] = essb_option_value('total_counter_afterbefore_text');

        $general_options['customshare'] = essb_option_bool_value('customshare');
        $general_options['customshare_text'] = essb_option_value('customshare_text');
        $general_options['customshare_url'] = essb_option_value('customshare_url');
        $general_options['customshare_image'] = essb_option_value('customshare_image');
        $general_options['customshare_description'] = essb_option_value('customshare_description');

        $general_options['shorturl_type'] = essb_option_value('shorturl_type');
        $general_options['shorturl_bitlyuser'] = essb_option_value('shorturl_bitlyuser');
        $general_options['shorturl_bitlyapi'] = essb_option_value('shorturl_bitlyapi');

        $general_options['display_in_types'] = essb_option_value('display_in_types');
        $general_options['display_excerpt'] = essb_option_bool_value('display_excerpt');
        $general_options['display_excerpt_pos'] = essb_option_value('display_excerpt_pos');
        $general_options['display_exclude_from'] = essb_option_value('display_exclude_from');
        $general_options['display_include_on'] = essb_option_value('display_include_on');
        $general_options['display_deactivate_on'] = essb_option_value('display_deactivate_on');
        $general_options['deactivate_homepage'] = essb_option_bool_value('deactivate_homepage');

        $general_options['content_position'] = essb_option_value('content_position');
        $general_options['button_position'] = essb_option_value('button_position');
        if (!is_array($general_options['button_position'])) {
            $general_options['button_position'] = array();
        }

        if (!is_array($general_options['display_in_types'])) {
            $general_options['display_in_types'] = array();
        }

        $general_options['total_counter_hidden_till'] = essb_option_value('total_counter_hidden_till');
        $general_options['button_counter_hidden_till'] = essb_option_value('button_counter_hidden_till');

        $general_options['reset_postdata'] = essb_option_bool_value('reset_postdata');
        $general_options['reset_posttype'] = essb_option_bool_value('reset_posttype');
        $general_options['metabox_visual'] = essb_option_bool_value('metabox_visual');
        $general_options['using_yoast_ga'] = essb_option_bool_value('using_yoast_ga');
        $general_options['scripts_in_head'] = essb_option_bool_value('scripts_in_head');

        $general_options['apply_clean_buttons'] = essb_option_bool_value('apply_clean_buttons');
        $general_options['apply_clean_buttons_method'] = essb_option_value('apply_clean_buttons_method');

        $general_options['priority_of_buttons'] = essb_object_value($options, 'priority_of_buttons', '10');
        $general_options['priority_of_buttons'] = intval($general_options['priority_of_buttons']);
        if ($general_options['priority_of_buttons'] == 0) {
            $general_options['priority_of_buttons'] = 10;
        }

        return $general_options;
    }

    private static function load_design($options) {
        $design_options = array();

        $design_options['template'] = essb_object_value($options, 'style', '0');
        $design_options['button_style'] = essb_object_value($options, 'button_style', 'button');
        $design_options['button_align'] = essb_option_value('button_pos');
        $design_options['button_width'] = essb_option_value('button_width');
        $design_options['button_width_fixed_value'] = essb_option_value('fixed_width_value');
        $design_options['button_width_fixed_align'] = essb_option_value('fixed_width_align');
        $design_options['button_width_full_container'] = essb_option_value('fullwidth_share_buttons_container');
        $design_options['button_width_full_button'] = essb_option_value('fullwidth_share_buttons_correction');
        $design_options['button_width_Full_button_mobile'] = essb_option_value('fullwidth_share_buttons_correction');
        $design_options['button_width_columns'] = essb_option_value('fullwidth_share_buttons_columns');
        $design_options['nospace'] = essb_option_bool_value('nospace');
        $design_options['fullwidth_align'] = essb_option_value('fullwidth_align');
        $design_options['fullwidth_share_buttons_columns_align'] = essb_option_value('fullwidth_share_buttons_columns_align');
        $design_options['sidebar_leftright_close'] = essb_option_bool_value('sidebar_leftright_close');

        return $design_options;
    }

    private static function load_network($options, $all_networks) {
        $network_options = array();

        $network_options['networks'] = essb_option_value('networks');
        if (!is_array($network_options['networks'])) {
            $network_options['networks'] = array();
        }

        $network_options['networks_order'] = essb_option_value('networks');
        $network_options['more_button_func'] = essb_option_value('more_button_func');

        $network_options['default_names'] = array();
        foreach ($all_networks as $key => $object) {
            $search_for = 'user_network_name_' . $key;
            $user_network_name = essb_object_value($options, $search_for, $object['name']);
            $network_options['default_names'][$key] = $user_network_name;
        }

        $network_options['twitter_shareshort'] = essb_option_bool_value('twitter_shareshort');
        $network_options['twitter_shareshort_service'] = essb_option_value('twitter_shareshort_service');
        $network_options['twitter_always_count_full'] = essb_option_bool_value('twitter_always_count_full');
        $network_options['twitter_user'] = essb_option_value('twitteruser');
        $network_options['twitter_hashtags'] = essb_option_value('twitterhashtags');
        $network_options['mail_disable_editmessage'] = essb_option_bool_value('mail_disable_editmessage');
        $network_options['mail_function'] = essb_option_value('mail_function');

        if (essb_is_mobile()) {
            if (!essb_option_bool_value('mail_popup_mobile')) {
                $network_options['mail_function'] = 'link';
            }
        }

        $network_options['mail_inline_code'] = essb_option_bool_value('mail_inline_code');
        $network_options['mail_function_mobile'] = essb_option_value('mail_function_mobile');
        $network_options['use_wpmandrill'] = essb_option_bool_value('use_wpmandrill');
        $network_options['mail_copyaddress'] = essb_option_value('mail_copyaddress');
        $network_options['mail_captcha'] = essb_option_value('mail_captcha');
        $network_options['mail_captcha_answer'] = essb_option_value('mail_captcha_answer');
        $network_options['mail_subject'] = essb_object_value($options, 'mail_subject', '');
        $network_options['mail_body'] = essb_object_value($options, 'mail_body', '');
        $network_options['print_use_printfriendly'] = essb_option_bool_value('print_use_printfriendly');
        $network_options['stumble_noshortlink'] = essb_option_bool_value('stumble_noshortlink');
        $network_options['buffer_twitter_user'] = essb_option_bool_value('buffer_twitter_user');

        return $network_options;
    }

    private static function load_button_style($options) {
        $button_style = array();

        $button_style['show_counter'] = essb_option_bool_value('show_counter');
        $button_style['counter_pos'] = essb_option_value('counter_pos');
        $button_style['active_internal_counters'] = essb_option_value('active_internal_counters');
        $button_style['total_counter_pos'] = essb_option_value('total_counter_pos');
        $button_style['message_share_buttons'] = essb_option_value('message_above_share_buttons');
        $button_style['message_share_before_buttons'] = essb_option_value('message_share_before_buttons');
        $button_style['message_like_buttons'] = essb_option_value('message_like_buttons');

        $message_share_before_buttons_on = essb_option_value('message_share_before_buttons_on');
        if (is_array($message_share_before_buttons_on)) {
            if (essb_is_mobile() && !in_array('mobile', $message_share_before_buttons_on)) {
                $button_style['message_share_before_buttons'] = '';
            }
            if (essb_is_tablet() && !in_array('tablet', $message_share_before_buttons_on)) {
                $button_style['message_share_before_buttons'] = '';
            }
            if (!essb_is_mobile() && !essb_is_tablet() && !in_array('desktop', $message_share_before_buttons_on)) {
                $button_style['message_share_before_buttons'] = '';
            }
        }

        $message_above_share_buttons_on = essb_option_value('message_above_share_buttons_on');
        if (is_array($message_above_share_buttons_on)) {
            if (essb_is_mobile() && !in_array('mobile', $message_above_share_buttons_on)) {
                $button_style['message_share_buttons'] = '';
            }
            if (essb_is_tablet() && !in_array('tablet', $message_above_share_buttons_on)) {
                $button_style['message_share_buttons'] = '';
            }
            if (!essb_is_mobile() && !essb_is_tablet() && !in_array('desktop', $message_above_share_buttons_on)) {
                $button_style['message_share_buttons'] = '';
            }
        }

        return $button_style;
    }
}
