<?php

class ESSB_Core_Asset_Register {

    public static function register_resources($essb_post_template, $essb_post_animations, $essb_post_content_position, $design_options, $general_options) {

        $css_animations = essb_option_value('css_animations');
        if (!empty($essb_post_animations)) {
            $css_animations = $essb_post_animations;
        }

        if ($css_animations != '' && $css_animations != 'no') {
            $animate_url = ESSB3_PLUGIN_URL . '/assets/css/essb-animations.min.css';
            essb_resource_builder()->add_static_resource($animate_url, 'easy-social-share-buttons-animations', 'css');
            essb_resource_builder()->activate_resource('animations');
        }

        $use_minifed_css = (ESSBGlobalSettings::$use_minified_css) ? '.min' : '';
        $use_minifed_js = (ESSBGlobalSettings::$use_minified_js) ? '.min' : '';

        $template_url = ESSB3_PLUGIN_URL . '/assets/css/easy-social-share-buttons' . $use_minifed_css . '.css';

        if (essb_sanitize_option_value('css_mode') == 'slim') {
            $template_url = ESSB3_PLUGIN_URL . '/assets/css/easy-social-share-buttons-slim' . $use_minifed_css . '.css';
        }

        if (essb_sanitize_option_value('css_mode') == 'mini') {
            $template_url = ESSB3_PLUGIN_URL . '/assets/css/easy-social-share-buttons-mini' . $use_minifed_css . '.css';
        }

        if (essb_sanitize_option_value('css_mode') == 'light') {
            $template_url = ESSB3_PLUGIN_URL . '/assets/css/easy-social-share-buttons-light' . $use_minifed_css . '.css';
        }

        if (essb_option_bool_value('legacy_icon_font')) {
            essb_resource_builder()->add_static_resource(ESSB3_PLUGIN_URL . '/assets/css/essb-legacy-icon-font' . $use_minifed_css . '.css', 'easy-social-share-buttons-font', 'css');
        }

        if (has_filter('essb_get_the_share_stylesheet_file')) {
            $template_url = apply_filters('essb_get_the_share_stylesheet_file', $template_url);
        }

        essb_resource_builder()->add_static_resource($template_url, 'easy-social-share-buttons', 'css');

        $core_js = ESSB3_PLUGIN_URL . '/assets/js/essb-core' . $use_minifed_js . '.js';
        if (essb_option_value('css_mode') == 'light') {
            $core_js = ESSB3_PLUGIN_URL . '/assets/js/essb-core-light' . $use_minifed_js . '.js';
        }

        essb_resource_builder()->add_static_resource($core_js, 'easy-social-share-buttons-core', 'js');

        $template_id = $design_options['template'];
        $template_slug = essb_template_folder($template_id);
        if (!empty($essb_post_template)) {
            $template_slug = $essb_post_template;
            $design_options['template'] = $template_slug;
        }
        $design_options['template_slug'] = $template_slug;

        $content_postion = $general_options['content_position'];
        if (!empty($essb_post_content_position)) {
            $content_postion = $essb_post_content_position;
            $general_options['content_position'] = $content_postion;
        }
        if ($content_postion == 'content_float' || $content_postion == 'content_floatboth') {
            essb_resource_builder()->activate_resource('float');
            $sharing_postfloat_url = ESSB3_PLUGIN_URL . '/assets/parts/js/sharing-postfloat' . $use_minifed_js . '.js';
            essb_resource_builder()->add_static_resource($sharing_postfloat_url, 'essb-module-sharing-postfloat', 'js', true);
        }

        if ($content_postion == 'content_followme') {
            $sharing_followme_url = ESSB3_PLUGIN_URL . '/assets/parts/js/sharing-followme' . $use_minifed_js . '.js';
            essb_resource_builder()->add_static_resource($sharing_followme_url, 'essb-module-sharing-followme', 'js', true);
        }

        $active_locations = $general_options['button_position'];

        $position_assets = array(
            'postfloat' => array(
                'resources' => array('sidebar', 'postfloat'),
                'js' => array('handle' => 'essb-module-sharing-postfloat', 'file' => 'sharing-postfloat', 'path' => 'parts/js'),
            ),
            'sidebar' => array(
                'resources' => array('sidebar'),
                'js' => array('handle' => 'essb-module-sharing-sidebar', 'file' => 'sharing-sidebar', 'path' => 'parts/js'),
            ),
            'sharebottom' => array(
                'js' => array('handle' => 'essb-module-sharing-mobile', 'file' => 'sharing-mobile', 'path' => 'parts/js'),
            ),
            'topbar' => array(
                'resources' => array('topbottombar'),
                'js' => array('handle' => 'essb-module-sharing-bar', 'file' => 'sharing-bar', 'path' => 'parts/js'),
            ),
            'bottombar' => array(
                'resources' => array('topbottombar'),
                'js' => array('handle' => 'essb-module-sharing-bar', 'file' => 'sharing-bar', 'path' => 'parts/js'),
            ),
            'cornerbar' => array(
                'js' => array('handle' => 'essb-module-sharing-corner-bar', 'file' => 'sharing-corner-bar', 'path' => 'parts/js'),
            ),
            'popup' => array(
                'js' => array('handle' => 'essb-module-sharing-popup', 'file' => 'sharing-popup', 'path' => 'parts/js'),
            ),
            'booster' => array(
                'js' => array('handle' => 'essb-module-sharing-booster', 'file' => 'sharing-booster', 'path' => 'parts/js'),
            ),
            'heroshare' => array(
                'js' => array('handle' => 'essb-module-sharing-heroshare', 'file' => 'sharing-heroshare', 'path' => 'parts/js'),
            ),
            'point' => array(
                'css' => array('handle' => 'essb-module-sharing-point', 'file' => 'sharing-point', 'path' => 'parts/css'),
                'js' => array('handle' => 'essb-module-sharing-point', 'file' => 'sharing-point', 'path' => 'parts/js'),
                'resources' => array('point'),
            ),
            'flyin' => array(
                'js' => array('handle' => 'essb-module-sharing-flyin', 'file' => 'sharing-flyin', 'path' => 'parts/js'),
            ),
            'sharebutton' => array(
            ),
            'postbar' => array(
                'css' => array('handle' => 'essb-module-sharing-postbar', 'file' => 'sharing-postbar', 'path' => 'parts/css'),
                'js' => array('handle' => 'essb-module-sharing-postbar', 'file' => 'sharing-postbar', 'path' => 'parts/js'),
                'resources' => array('postbar'),
            ),
        );

        foreach ($active_locations as $position) {
            if (!isset($position_assets[$position])) {
                continue;
            }

            $config = $position_assets[$position];

            if (!empty($config['resources'])) {
                foreach ($config['resources'] as $resource) {
                    essb_resource_builder()->activate_resource($resource);
                }
            }

            if (!empty($config['css'])) {
                $c = $config['css'];
                $css_path = isset($c['path']) ? $c['path'] : 'modules';
                $asset_url = ESSB3_PLUGIN_URL . '/assets/' . $css_path . '/' . $c['file'] . $use_minifed_css . '.css';
                essb_resource_builder()->add_static_resource($asset_url, $c['handle'], 'css');
            }

            if (!empty($config['js'])) {
                $c = $config['js'];
                $js_path = isset($c['path']) ? $c['path'] : 'modules';
                $script_url = ESSB3_PLUGIN_URL . '/assets/' . $js_path . '/' . $c['file'] . $use_minifed_js . '.js';
                essb_resource_builder()->add_static_resource($script_url, $c['handle'], 'js', true);
                essb_resource_builder()->activate_resource(isset($c['resource']) ? $c['resource'] : $c['handle']);
            }
        }

        return array(
            'design_options' => $design_options,
            'general_options' => $general_options,
        );
    }
}
