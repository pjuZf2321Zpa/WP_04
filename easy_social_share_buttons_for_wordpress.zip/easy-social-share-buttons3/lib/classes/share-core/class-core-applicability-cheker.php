<?php

class ESSB_Core_Applicability_Cheker {

    public static function check($post_types = array(), $location = '', $general_options = array())
    {
        global $post;

        static $cache = array();
        $cache_key = (isset($post) ? $post->ID : '0') . '|' . md5(serialize($post_types));

        if (isset($cache[$cache_key])) {
            return $cache[$cache_key];
        }

        if (is_search() || is_feed()) {
            $cache[$cache_key] = false;
            return false;
        }

        $current_active_post_type = '';
        if ($general_options['reset_posttype'] && isset($post)) {
            $current_active_post_type = isset($post->post_type) ? $post->post_type : '';
        }

        if ($general_options['reset_postdata']) {
            wp_reset_postdata();
        }

        $is_exclusive_active = false;
        if (isset($post)) {
            $is_exclusive_active = essb_is_plugin_activated_on();
        }

        if ($general_options['reset_posttype'] && !empty($current_active_post_type)) {
            if (!in_array($current_active_post_type, $post_types)) {
                if (!$is_exclusive_active) {
                    $cache[$cache_key] = false;
                    return false;
                }
            }
        }

        if ($general_options['apply_clean_buttons']) {
            if ($general_options['apply_clean_buttons_method'] == 'remove2') {
                if (!is_main_query() || !in_the_loop()) {
                    $cache[$cache_key] = false;
                    return false;
                }
            }
        }

        if (essb_option_bool_value('essb_avoid_nonmain')) {
            if (!is_main_query() || !in_the_loop()) {
                $cache[$cache_key] = false;
                return false;
            }

            if (is_singular() && $post->ID !== get_queried_object_id()) {
                $cache[$cache_key] = false;
                return false;
            }
        }

        if (essb_option_bool_value('hide_preview_share')) {
            if (is_preview()) {
                $cache[$cache_key] = false;
                return false;
            }
        }

        $is_all_lists = in_array('all_lists', $post_types);
        $is_set_list = count($post_types) > 0 ? true : false;

        $is_homepage = in_array('homepage', $post_types);
        unset($post_types['homepage']);
        unset($post_types['all_lists']);

        $is_lists_authorized = (is_archive() || is_search() || is_tag() || is_post_type_archive() || is_home()) && $is_all_lists ? true : false;

        if (is_front_page() && $is_homepage) {
            $is_lists_authorized = true;
        }

        $is_singular = is_singular($post_types);
        if ($is_singular && !$is_set_list) {
            $is_singular = false;
        }

        if ($general_options['deactivate_homepage']) {
            if (is_home() || is_front_page()) {
                $is_lists_authorized = false;
                $is_singular = false;
            }
        }

        if ($general_options['display_exclude_from'] != '') {
            $excule_from = explode(',', $general_options['display_exclude_from']);
            $excule_from = array_map('trim', $excule_from);

            if (in_array(get_the_ID(), $excule_from, false)) {
                $is_singular = false;
                $is_lists_authorized = false;
            }
        }

        if (essb_is_module_deactivated_on('share') || essb_is_module_deactivated_on_category('share')) {
            $is_singular = false;
            $is_lists_authorized = false;
        }

        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if ($request_uri != '') {
            $exist_ai1ec_export = strpos($request_uri, 'ai1ec_exporter_controller');
            if ($exist_ai1ec_export !== false) {
                $is_singular = false;
                $is_lists_authorized = false;
            }

            $exist_tribe_cal = strpos($request_uri, 'ical=');
            if ($exist_tribe_cal !== false) {
                $is_singular = false;
                $is_lists_authorized = false;
            }

            if (essb_option_bool_value('hide_buttons_elementor_edit') && strpos($request_uri, '?elementor-preview') !== false) {
                $is_singular = false;
                $is_lists_authorized = false;
            }
        }

        $essb_off = get_post_meta(get_the_ID(), 'essb_off', true);
        if ($essb_off == 'true') {
            $is_lists_authorized = false;
            $is_singular = false;
        }

        if ($is_exclusive_active) {
            $is_singular = true;
        }

        if (has_filter('essb_check_applicability')) {
            $is_singular = apply_filters('essb_check_applicability', $is_singular);
        }

        if (has_filter('essb_check_applicability_archive')) {
            $is_lists_authorized = apply_filters('essb_check_applicability_archive', $is_lists_authorized);
        }

        if ($is_singular || $is_lists_authorized) {
            $cache[$cache_key] = true;
            return true;
        } else {
            $cache[$cache_key] = false;
            return false;
        }
    }
}
