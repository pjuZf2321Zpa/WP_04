<?php
/**
 * Manage plugin activations
 *
 * @author appscreo
 * @since 4.2
 * @package EasySocialShareButtons
 */

class ESSBActivationManager {
    public static function domain() {
        $url = self::getSiteURL();
        $parse = parse_url($url);
        $domain_only = isset($parse['host']) ? $parse['host'] : '';
        
        return self::getDomain($domain_only);
    }
    
    public static function getDomain($domain) {
        if(preg_match("/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i", $domain, $matches)) {
            return $matches['domain'];
        }
        else {
            return $domain;
        }
    }
    
    public static function getSiteURL() {
        return site_url();
    }
}

