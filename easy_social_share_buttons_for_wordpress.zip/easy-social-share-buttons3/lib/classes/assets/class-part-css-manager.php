<?php

/**
 * Part CSS manager.
 *
 * Registers and tracks CSS part files from assets/parts/css/ so that
 * parts registered at any point during the request are guaranteed
 * to appear, even if add_part_css was never explicitly called.
 *
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.5
 */
class ESSB_Part_CSS_Manager {

    /**
     * Parts that have been registered for potential loading.
     *
     * @var array
     */
    private static $registered = array();

    /**
     * Parts that have already been sent for loading via add_part_css.
     *
     * @var array
     */
    private static $loaded = array();

    /**
     * Parts that should be loaded inline (file content embedded in page).
     *
     * @var array
     */
    private static $inline_parts = array();

    /**
     * Register a part key so it can be loaded later.
     *
     * @param string $key
     * @return void
     */
    public static function register($key) {
        if (!isset(self::$registered[$key])) {
            self::$registered[$key] = true;
        }
    }

    /**
     * Immediately load a part via add_part_css and mark it as loaded.
     *
     * @param string $key
     * @return void
     */
    public static function load($key) {
        if (!isset(self::$loaded[$key])) {
            if (isset(self::$inline_parts[$key])) {
                self::load_part_inline($key);
            } else {
                essb_resource_builder()->add_part_css($key);
            }
            self::$loaded[$key] = true;
        }
    }

    /**
     * Load all registered parts that have not yet been loaded.
     * Should be called late in the request (e.g. wp_footer) to
     * ensure everything appears.
     *
     * @return void
     */
    public static function load_all_pending() {
        foreach (self::$registered as $key => $active) {
            if (!isset(self::$loaded[$key])) {
                if (isset(self::$inline_parts[$key])) {
                    self::load_part_inline($key);
                } else {
                    essb_resource_builder()->add_part_css($key);
                }
                self::$loaded[$key] = true;
            }
        }
    }

    /**
     * Load all pending parts whose key starts with "sharing-".
     *
     * @return void
     */
    public static function load_all_pending_share() {
        foreach (self::$registered as $key => $active) {
            if (strpos($key, 'sharing-') !== false && !isset(self::$loaded[$key])) {
                if (isset(self::$inline_parts[$key])) {
                    self::load_part_inline($key);
                } else {
                    essb_resource_builder()->add_part_css($key);
                }
                self::$loaded[$key] = true;
            }
        }
    }

    /**
     * Load all pending parts whose key does NOT start with "sharing-".
     *
     * @return void
     */
    public static function load_all_pending_other() {
        foreach (self::$registered as $key => $active) {
            if (strpos($key, 'sharing-') === false && !isset(self::$loaded[$key])) {
                if (isset(self::$inline_parts[$key])) {
                    self::load_part_inline($key);
                } else {
                    essb_resource_builder()->add_part_css($key);
                }
                self::$loaded[$key] = true;
            }
        }
    }

    /**
     * Load a single part's CSS content inline.
     *
     * @param string $key
     * @return void
     */
    private static function load_part_inline($key) {
        $file = ESSB3_PLUGIN_ROOT . 'assets/parts/css/' . $key . '.min.css';
        if (!file_exists($file)) {
            $file = ESSB3_PLUGIN_ROOT . 'assets/parts/css/' . $key . '.css';
        }
        if (file_exists($file)) {
            $code = file_get_contents($file);
            essb_resource_builder()->add_css($code, 'essb-part-' . $key, 'header');
        }
    }

    /**
     * Mark a part key for inline loading.
     *
     * @param string $key
     * @return void
     */
    public static function set_inline($key) {
        self::$inline_parts[$key] = true;
    }

    /**
     * Check whether a part has been registered.
     *
     * @param string $key
     * @return bool
     */
    public static function is_registered($key) {
        return isset(self::$registered[$key]);
    }

    /**
     * Check whether a part has already been loaded.
     *
     * @param string $key
     * @return bool
     */
    public static function is_loaded($key) {
        return isset(self::$loaded[$key]);
    }

    /**
     * Register keys by reading plugin settings.
     * Call this early in the request so all needed parts are tracked.
     *
     * @return void
     */
    public static function register_keys_by_settings() {
        $button_position = essb_option_value('button_position');
        if (!is_array($button_position)) {
            $button_position = array();
        }

        if (in_array('booster', $button_position, true)) {
            self::register('sharing-booster');
        }

        if (in_array('cornerbar', $button_position, true)) {
            self::register('sharing-corner-bar');
        }

        if (in_array('flyin', $button_position, true)) {
            self::register('sharing-flyin');
        }

        if (essb_option_value('content_position') === 'content_followme') {
            self::register('sharing-followme');
        }

        if (in_array('heroshare', $button_position, true)) {
            self::register('sharing-heroshare');
        }

        if (essb_option_value('mail_function') === 'form') {
            self::register('sharing-mailform');
        }

        $button_position_mobile = essb_option_value('button_position_mobile');
        if (is_array($button_position_mobile) && !empty($button_position_mobile)) {
            self::register('sharing-mobile');
        }

        if (essb_option_bool_value('pinterest_images')) {
            self::register('sharing-pin');
        }

        if (in_array('popup', $button_position, true)) {
            self::register('sharing-popup');
        }

        if (in_array('postfloat', $button_position, true)) {
            self::register('sharing-postfloat');
        }

        if (in_array('sharebutton', $button_position, true)) {
            self::register('sharing-share-button');
        }

        if (in_array('sidebar', $button_position, true)) {
            self::register('sharing-sidebar');
        }

        if (in_array('topbar', $button_position, true) || in_array('bottombar', $button_position, true)) {
            self::register('sharing-topbottombar');
        }
    }

    /**
     * Reset all internal state (useful in testing environments).
     *
     * @return void
     */
    public static function reset() {
        self::$registered = array();
        self::$loaded = array();
        self::$inline_parts = array();
    }
}
