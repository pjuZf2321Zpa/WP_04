<?php

/**
 * Static CSS loader
 *
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 7.2
 *
 */
class ESSB_Static_CSS_Loader {
    
    /**
     * CSS files loaded in the header
     */
    private static $header_files = array();
    
    /**
     * CSS files loaded in the footer
     */
    private static $footer_files = array();
    
    /**
     * Track when header styles will appear
     */
    private static $header_shown = false;
    
    /**
     * @var array
     */
    public static $active_resources = array();

    /**
     * Track styles already output via load_inline_style to prevent duplicates
     * @var array
     */
    private static $loaded_inline_styles = array();
    
    /**
     * @param string $key
     * @param string $url
     */
    public static function register_header_style($key = '', $url = '') {
        self::$header_files[$key] = $url;
        
        if (self::$header_shown) {
            self::$footer_files[$key] = $url;
        }
    }
    
    /**
     * @param string $key
     * @param string $url
     */
    public static function register_footer_style($key = '', $url = '') {
        if (!self::style_loaded($key)) {
            self::$footer_files[$key] = $url;
        }
    }
    
    /**
     * @param string $key
     * @return boolean
     */
    public static function style_loaded($key = '') {
        return isset(self::$header_files[$key]) || isset(self::$footer_files[$key]);
    }
    
    /**
     * @param string $key
     */
    public static function unregister_style($key = '') {
        if (isset(self::$header_files[$key])) {
            unset (self::$header_files[$key]);
        }
        
        if (isset(self::$footer_files[$key])) {
            unset (self::$footer_files[$key]);
        }
    }
    
    /**
     * @param string $type
     * @return array
     */
    public static function get($type = 'header') {
        $r = array();
        
        if ($type == 'header' || $type == 'all') {
            $r = array_merge($r, self::$header_files);
        }
        
        if ($type == 'footer' || $type == 'all') {
            $r = array_merge($r, self::$footer_files);
        }
        
        return $r;
    }

    /**
     * Output an inline stylesheet link tag immediately.
     * When $async_load is true, uses preload pattern for non-render-blocking load.
     *
     * @param string $key
     * @param string $url
     * @param bool   $async_load
     * @return void
     */
    public static function load_inline_style($key = '', $url = '', $async_load = false) {
        if ($key !== '' && isset(self::$loaded_inline_styles[$key])) {
            return;
        }

        if ($async_load) {
            echo '<link href="' . esc_url($url) . '" onload="this.rel=\'stylesheet\'" type="text/css">';
        }
        else {
            echo '<link rel="stylesheet" id="' . esc_attr($key) . '-css" href="' . esc_url($url) . '" type="text/css" media="all" />';
        }

        if ($key !== '') {
            self::$loaded_inline_styles[$key] = $url;
        }
    }

    /**
     * Check if an inline style key has already been output
     *
     * @param string $key
     * @return bool
     */
    public static function inline_style_loaded($key = '') {
        return isset(self::$loaded_inline_styles[$key]);
    }
}