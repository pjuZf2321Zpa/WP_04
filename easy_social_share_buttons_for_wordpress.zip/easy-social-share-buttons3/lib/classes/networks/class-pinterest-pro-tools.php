<?php

/**
 * Specific function related to the work of Pinterest Pro. Loading conditionally javascript code related to them.
 * 
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 10.1
 */
class ESSB_Pinterest_Pro_Tools
{

    /**
     * Initialize
     */
    public static function init()
    {
        add_action('wp_enqueue_scripts', array('ESSB_Pinterest_Pro_Tools', 'initialize_modules'), 1);
        add_action('init', array('ESSB_Pinterest_Pro_Tools', 'register_meta'));
        add_filter('wp_kses_allowed_html', array(__CLASS__, 'kses_allow_pin_attributes'), 10, 2);
    }

    /**
     * Register attachment Pinterest meta for REST/block-editor access.
     */
    public static function register_meta()
    {
        $keys = array('essb_pin_title', 'essb_pin_description', 'essb_pin_id', 'essb_pin_nopin');

        foreach ($keys as $key) {
            register_meta('post', $key, array(
                'object_subtype' => 'attachment',
                'show_in_rest' => true,
                'single' => true,
                'type' => 'string',
                'sanitize_callback' => array('ESSB_Pinterest_Pro_Tools', 'sanitize_pin_text'),
                'auth_callback' => function ($allowed, $meta_key, $object_id, $user_id) {
                    return current_user_can('edit_post', $object_id);
                },
            ));
        }
    }

    /**
     * Sanitize Pinterest meta text for REST writes (self-contained: the admin
     * class is not loaded on frontend/REST requests).
     *
     * @param mixed $value Raw value.
     * @return string
     */
    public static function sanitize_pin_text($value)
    {
        return mb_substr(sanitize_text_field($value), 0, 100);
    }

    public static function kses_allow_pin_attributes($tags, $context)
    {
        if (isset($tags['img']) && is_array($tags['img'])) {
            $tags['img'] += array('data-pin-title' => true, 'data-pin-description' => true, 'data-pin-id' => true, 'data-pin-nopin' => true, 'data-pin-media' => true, 'data-pin-url' => true);
        }
        return $tags;
    }

    /**
     * Initalize spscific modules
     */
    public static function initialize_modules()
    {
        add_filter('wp_get_attachment_image_attributes', array(__CLASS__, 'filter_attachment_image_attributes'), 10, 3);

        self::initialize_advanced_disable_pin();

        if (is_singular() && essb_pin_selected_images_only()) {
            add_action('essb_inline_js_queue', array(__CLASS__, 'generate_pin_selected_only_code'));
        }

        // Pinterest description
        if (is_singular()) {
            add_action('essb_inline_js_queue', array(__CLASS__, 'initialize_pinterest_description'));
            add_filter('the_content', array(__CLASS__, 'apply_default_pinterest_title'), 9);
            add_filter('the_content', array(__CLASS__, 'content_marker'), 999);
            add_filter('the_content', array(__CLASS__, 'pinterest_hidden_images'), 999);
        }
    }

    /**
     * Apply media-library Pinterest fields to template-rendered images.
     *
     * Runs on `wp_get_attachment_image_attributes` (WP 6.x). Existing
     * attributes are never overwritten. Never sets `data-pin-url`.
     *
     * @param array   $attr       Image tag attributes.
     * @param WP_Post $attachment Attachment post object.
     * @param string|array $size  Requested image size.
     * @return array
     */
    public static function filter_attachment_image_attributes($attr, $attachment, $size)
    {
        if (essb_option_value('pinterest_image_attributes') === 'false') {
            return $attr;
        }

        $id = $attachment->ID;

        $pin_title = get_post_meta($id, 'essb_pin_title', true);
        $pin_description = get_post_meta($id, 'essb_pin_description', true);
        $pin_id = get_post_meta($id, 'essb_pin_id', true);
        $pin_nopin = get_post_meta($id, 'essb_pin_nopin', true);

        if (!empty($pin_title) && !isset($attr['data-pin-title'])) {
            $attr['data-pin-title'] = $pin_title;
        }

        if (!empty($pin_description) && !isset($attr['data-pin-description'])) {
            $attr['data-pin-description'] = $pin_description;
        }

        if (!empty($pin_id) && !isset($attr['data-pin-id'])) {
            $attr['data-pin-id'] = $pin_id;
        }

        if ($pin_nopin === 'true' || $pin_nopin === '1') {
            $attr['data-pin-nopin'] = 'true';
        }

        $advanced_minwidth = essb_option_value('pinpro_advanced_minwidth');
        $advanced_minheight = essb_option_value('pinpro_advanced_minheight');

        if ($advanced_minwidth !== '' && $advanced_minwidth !== null && is_numeric($advanced_minwidth) && floatval($advanced_minwidth) > 0) {
            $min_width = floatval($advanced_minwidth);
        } else {
            $legacy_minwidth = essb_option_value('pinterest_minwidth');
            $min_width = ($legacy_minwidth !== '' && $legacy_minwidth !== null && is_numeric($legacy_minwidth) && floatval($legacy_minwidth) > 0) ? floatval($legacy_minwidth) : 0;
        }

        if ($advanced_minheight !== '' && $advanced_minheight !== null && is_numeric($advanced_minheight) && floatval($advanced_minheight) > 0) {
            $min_height = floatval($advanced_minheight);
        } else {
            $legacy_minheight = essb_option_value('pinterest_minheight');
            $min_height = ($legacy_minheight !== '' && $legacy_minheight !== null && is_numeric($legacy_minheight) && floatval($legacy_minheight) > 0) ? floatval($legacy_minheight) : 0;
        }

        if ($min_width > 0 || $min_height > 0) {
            $width = 0;
            $height = 0;
            $has_dimensions = false;

            if (is_array($size)) {
                $width = isset($size[0]) ? intval($size[0]) : 0;
                $height = isset($size[1]) ? intval($size[1]) : 0;
                $has_dimensions = ($width > 0 || $height > 0);
            } else {
                $src = wp_get_attachment_image_src($id, $size);
                if (is_array($src) && isset($src[1], $src[2])) {
                    $width = intval($src[1]);
                    $height = intval($src[2]);
                    $has_dimensions = true;
                }
            }

            if ($has_dimensions) {
                if (($min_width > 0 && $width < $min_width) || ($min_height > 0 && $height < $min_height)) {
                    $attr['data-pin-nopin'] = 'true';
                }
            }
        }

        if (isset($attr['class']) && preg_match('/(?:^|\s)custom-logo(?:\s|$)/', $attr['class'])) {
            $attr['data-pin-nopin'] = 'true';
        }

        return $attr;
    }

    public static function initialize_advanced_disable_pin()
    {
        if (essb_option_bool_value('deactivate_module_pinterestpro') || !essb_option_bool_value('pinpro_advanced_disable')) {
            return;
        }

        add_action('essb_inline_js_queue', array(__CLASS__, 'generate_advanced_disable_pin_code'));
    }

    public static function generate_advanced_disable_pin_code($buffer)
    {
        $pin_disable_options = array();
        $pin_disable_options['min_width'] = essb_sanitize_option_value('pinpro_advanced_minwidth');
        $pin_disable_options['min_height'] = essb_sanitize_option_value('pinpro_advanced_minheight');
        $pin_disable_options['hideon'] = essb_sanitize_option_value('pinpro_advanced_hideon');
        $pin_disable_options['files'] = array();

        $exclude_by_files = essb_option_value('pinpro_advanced_files');

        if (!empty($exclude_by_files)) {
            $pin_disable_options['files'] = explode("\n", $exclude_by_files);
            $pin_disable_options['files'] = array_map('trim', $pin_disable_options['files']);
            $pin_disable_options['files'] = array_filter($pin_disable_options['files']);
            $pin_disable_options['files'] = array_unique($pin_disable_options['files']);
        }

        echo 'window.essbPinAdvancedDisable = essbPinAdvancedDisable = ' . json_encode($pin_disable_options) . ';';
        echo 'document.addEventListener("DOMContentLoaded",function(){"undefined"!=typeof essbPinAdvancedDisable&&(essbPinAdvancedDisable.min_width||essbPinAdvancedDisable.min_height||essbPinAdvancedDisable.hideon||0!=essbPinAdvancedDisable.files.length)&&(essbPinAdvancedDisable.hideon&&document.querySelectorAll(essbPinAdvancedDisable.hideon).forEach(t=>{t.setAttribute("nopin","nopin"),t.setAttribute("data-pin-nopin","true"),t.classList.add("no_pin"),t.classList.add("essb_no_pin"),t.setAttribute("data-pin-no-hover","true")}),(Number(essbPinAdvancedDisable.min_height||0)>0||Number(essbPinAdvancedDisable.min_width||0)>0)&&document.querySelectorAll("img").forEach(t=>{(t.outerWidth()<Number(essbPinImages.min_width||0)||t.outerHeight()<Number(essbPinImages.min_height||0))&&(t.setAttribute("nopin","nopin"),t.setAttribute("data-pin-nopin","true"),t.classList.add("no_pin"),t.classList.add("essb_no_pin"),t.setAttribute("data-pin-no-hover","true"))}),essbPinAdvancedDisable.files.length>0&&document.querySelectorAll("img").forEach(t=>{let e=(t.getAttribute("src")||"").toLowerCase(),i=!1;for(let n of essbPinAdvancedDisable.files)if(e.indexOf(n.toLowerCase())>-1){i=!0;break}i&&(t.setAttribute("nopin","nopin"),t.setAttribute("data-pin-nopin","true"),t.classList.add("no_pin"),t.classList.add("essb_no_pin"),t.setAttribute("data-pin-no-hover","true"))}))});';
    }

    public static function initialize_pinterest_description()
    {
        $post = essb_get_global_post();
        if ($post) {
            $pinterest_description = get_post_meta($post->ID, 'essb_post_pin_desc', true);

            if ($pinterest_description != '') {
                echo 'document.addEventListener("DOMContentLoaded",function(){let t="",e=!1;document.querySelector(".essb-pinterest-pro-content-marker")?(t=".essb-pinterest-pro-content-marker",e=!0):t=document.querySelector(".post img")?".post img":".single-post img",document.querySelectorAll(t).forEach(t=>{e?t.parentNode.querySelectorAll("img").forEach(t=>{""==(t.getAttribute("data-pin-description")||"")&&t.setAttribute("data-pin-description","' . esc_attr($pinterest_description) . '")}):""==(t.getAttribute("data-pin-description")||"")&&t.setAttribute("data-pin-description","' . esc_attr($pinterest_description) . '")})});';
            }
        }
    }

    public static function apply_default_pinterest_title($content)
    {
        global $wp_current_filter;

        // Bail if the_content is being requested by something else.
        if (!empty($wp_current_filter) && is_array($wp_current_filter)) {
            if (count(array_intersect($wp_current_filter, apply_filters('essb_pinterest_pro_excluded_filters', array('wp_head', 'get_the_excerpt', 'widget_text_content', 'p3_content_end')))) > 0) {
                return $content;
            }

            // Nested the_content hook.
            $filter_counts = array_count_values($wp_current_filter);
            if (!empty($filter_counts['the_content']) && $filter_counts['the_content'] > 1) {
                return $content;
            }
        }

        if (!is_singular() || is_feed() || is_embed() || is_admin()) {
            return $content;
        }

        if (!class_exists('WP_HTML_Tag_Processor')) {
            return $content;
        }

        $post = essb_get_global_post();
        if (!$post) {
            return $content;
        }

        // NOTE: core read (not essb_get_post_meta): the key is saved via core
        // update_post_meta (handle_essb_save_metabox), and the custom
        // ESSB_Post_Meta table has no fallback to core postmeta.
        $default = get_post_meta($post->ID, 'essb_post_pin_default_title', true);
        if (empty($default)) {
            return $content;
        }

        $p = new WP_HTML_Tag_Processor($content);
        while ($p->next_tag('img')) {
            if ($p->get_attribute('data-pin-title') !== null) {
                continue;
            }
            $class = $p->get_attribute('class');
            if ($class !== null && strpos($class, 'essb-pinterest-hidden-image') !== false) {
                continue;
            }
            $p->set_attribute('data-pin-title', $default);
        }

        return $p->get_updated_html();
    }

    public static function content_marker($content)
    {
        global $wp_current_filter;

        //bail if the_content is being requested by something else
        if (!empty($wp_current_filter) && is_array($wp_current_filter)) {
            if (count(array_intersect($wp_current_filter, apply_filters('essb_pinterest_pro_excluded_filters', array('wp_head', 'get_the_excerpt', 'widget_text_content', 'p3_content_end')))) > 0) {
                return $content;
            }

            //nested the_content hook
            $filter_counts = array_count_values($wp_current_filter);
            if (!empty($filter_counts['the_content']) && $filter_counts['the_content'] > 1) {
                return $content;
            }
        }


        $deactivate_trigger = false;
        $deactivate_trigger = apply_filters('essb_disable_pinterest_pro_content_marker', $deactivate_trigger);

        if ($deactivate_trigger) {
            return $content;
        } else {
            return $content . '<div class="essb-pinterest-pro-content-marker" style="display: none !important;"></div>';
        }
    }

    public static function pinterest_hidden_images($content)
    {
        global $wp_current_filter;

        //bail if the_content is being requested by something else
        if (!empty($wp_current_filter) && is_array($wp_current_filter)) {
            if (count(array_intersect($wp_current_filter, apply_filters('essb_pinterest_pro_excluded_filters', array('wp_head', 'get_the_excerpt', 'widget_text_content', 'p3_content_end')))) > 0) {
                return $content;
            }

            //nested the_content hook
            $filter_counts = array_count_values($wp_current_filter);
            if (!empty($filter_counts['the_content']) && $filter_counts['the_content'] > 1) {
                return $content;
            }
        }

        $post = essb_get_global_post();

        if ($post && class_exists('ESSB_Post_Meta')) {
            $pinterest_hidden = essb_get_post_meta($post->ID, 'pinterest_hidden');
            $output = '';

            $lazyloading_src = 'data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjEgNjQuMTQwOTQ5LCAyMDEwLzEyLzA3LTEwOjU3OjAxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1LjEgTWFjaW50b3NoIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjREQUMzRUQxNzA2NDExRTE5MEFFOTdBMTMwMDkyNjcwIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjREQUMzRUQyNzA2NDExRTE5MEFFOTdBMTMwMDkyNjcwIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NERBQzNFQ0Y3MDY0MTFFMTkwQUU5N0ExMzAwOTI2NzAiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NERBQzNFRDA3MDY0MTFFMTkwQUU5N0ExMzAwOTI2NzAiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQBAAAAACwAAAAAAQABAAACAkQBADs=';
            $lazyload = true;

            if (has_filter('essb_pinterest_pro_hidden_disable_lazyload')) {
                $lazyload = apply_filters('essb_pinterest_pro_hidden_disable_lazyload', $lazyload);
            }

            if (!empty($pinterest_hidden)) {
                $pinterest_hidden = essb_safe_unserialize($pinterest_hidden);
                $pinterest_hidden = apply_filters('essb_pinterest_hidden_images', $pinterest_hidden);

                foreach ($pinterest_hidden as $single_image) {
                    if ($lazyload) {
                        $output .= '<img class="essb-pinterest-hidden-image essb-pinterest-hidden-image-lazy no-lazy" src="' . $lazyloading_src . '" data-pin-media="' . $single_image . '" alt="Pinterest Hidden Image" data-image-src="' . esc_url($single_image) . '">';
                    } else {
                        $output .= '<img class="essb-pinterest-hidden-image no-lazy" src="' . $single_image . '" data-pin-media="' . $single_image . '" alt="Pinterest Hidden Image">';
                    }
                }
            }

            if (!empty($output)) {
                $output = '<div class="essb-pinterest-hidden-image-container" style="display: none !important;">' . $output . '</div>';
                if ($lazyload) {
                    $output = $output . '<script>!function(){"use strict";var t=!1;function e(){!t&&(t=!0,document.querySelectorAll(".essb-pinterest-hidden-image-lazy").forEach(function(t){let e=t.getAttribute("data-image-src")||"";e&&t.setAttribute("src",e)}))}["click","scroll","touchstart","mousemove","keydown"].forEach(function(t){window.addEventListener(t,e,{once:!0,passive:!0})})}();</script>';
                }
                $content = $output . $content;
            }
        }

        return $content;
    }

    public static function generate_pin_selected_only_code()
    {
        $post = essb_get_global_post();

        if ($post && class_exists('ESSB_Post_Meta')) {
            $pinterest_hidden = essb_get_post_meta($post->ID, 'pinterest_hidden');

            if (!empty($pinterest_hidden)) {
                $pinterest_hidden = essb_safe_unserialize($pinterest_hidden);
                $pinterest_hidden = apply_filters('essb_pinterest_hidden_images', $pinterest_hidden);

                $images = array();

                foreach ($pinterest_hidden as $single_image) {
                    $file_name = basename(parse_url($single_image, PHP_URL_PATH));
                    $images[] = $file_name;
                }

                if (!empty($images)) {
                    $output = 'document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll("img:not(.essb-pinterest-hidden-image)").forEach(t=>{let e=t.classList.contains("no_pin")||t.classList.contains("no-pin")||"true"==(t.getAttribute("data-pin-nopin")||"");t.setAttribute("nopin","nopin"),t.setAttribute("data-pin-nopin","true"),t.classList.add("no_pin"),t.classList.add("essb_no_pin"),t.setAttribute("data-pin-no-hover","true"),e||t.setAttribute("data-pinpro-allowed","true")}),document.querySelectorAll(".essb-pinterest-hidden-image").forEach(t=>{t.setAttribute("data-pin-me-only","true")})});';
                    echo $output;
                }
            }
        }
    }
}

ESSB_Pinterest_Pro_Tools::init();
