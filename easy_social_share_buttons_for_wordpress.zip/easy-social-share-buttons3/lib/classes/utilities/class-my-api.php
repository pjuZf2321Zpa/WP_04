<?php 

class ESSB_MyAPI {
    
    /**
     * The main API address
     * @var string
     */
    private static $api_url = 'https://my.socialsharingplugin.com/wp-json/my-essb/v1/';
    
    private static $news_types = array(
        'news' => array('title' => 'New', 'color' => '#1D89F9'),
        'promo' => array('title' => 'Promo', 'color' => '#C94670'),
        'update' => array('title' => 'Update', 'color' => '#419C33'),
        'other' => array('title' => 'Announcement', 'color' => '#CB9C2A'),
        'guide' => array('title' => 'Blog', 'color' => '#57C5EA')
    );

    /**
     * Test mode flag. When true, returns a test feed instead of reading the transient.
     * @var bool
     * @since 11.7
     */
    private static $test_mode = false;

    /**
     * Enable test mode for previewing news banners without relying on the API/transient.
     *
     * @since 11.7
     * @param bool $enable Whether to enable test mode.
     */
    public static function enable_test_mode($enable = true) {
        self::$test_mode = (bool) $enable;
    }
    
    /**
     * Read the API endpoint and retrieve the result
     * @param string $endpoint
     * @param array $options
     * @return mixed
     */
    private static function get($endpoint = '', $options = array()) {
        
        $url = self::$api_url . $endpoint;
        
        if (count($options) > 0) {
            $url = add_query_arg($options, $url);
        }
        
        $response = wp_remote_get( $url );        
        return json_decode( wp_remote_retrieve_body( $response ) );
    }    
    
    private static function post($endpoint = '', $options = array()) {
        $url = self::$api_url . $endpoint;
        
        if (count($options) > 0) {
            $url = add_query_arg($options, $url);
        }
                
        $curl = curl_init();
        
        curl_setopt_array($curl, array (
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 2,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array (
                "Content-Type: application/json"
            )
        ));
        
        $response = curl_exec($curl);
        curl_close($curl);
        
        return json_decode( $response );
    }
    
    private static function output_type($type = '') {
        $r = '';
        
        if (isset(self::$news_types[$type])) {
            $r = self::$news_types[$type]['title'];
        }
        
        return $r;
    }
    
    private static function format_date_to_local($date = '') {
        $date = str_replace('-', '/', $date);
        $time = strtotime($date);
        
        return date(get_option('date_format'), $time);        
    }
    
    private static function stylesheet_feed() {
        $output = '';
        
        $output .= '.essb-admin-dashboard-widget .essb-news-typetag-update { background-color: ' . self::$news_types['update']['color'] . '; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-typetag-news { background-color: ' . self::$news_types['news']['color'] . '; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-typetag-promo { background-color: ' . self::$news_types['promo']['color'] . '; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-typetag-other { background-color: ' . self::$news_types['other']['color'] . '; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-typetag-guide { background-color: ' . self::$news_types['guide']['color'] . '; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-typetag {
            display: inline-block;
            padding: 3px 5px;
            border-radius: 5px;
            font-size: 11px;
            text-transform: uppercase;
            color: #fff;
            line-height: 1em;
            margin-right: 5px;
            font-weight: 600;
        }';
        
        $output .= '.essb-admin-dashboard-widget .essb-news-row { margin-top: 10px; margin-bottom: 10px; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-row .essb-news-title a { font-weight: 600; text-decoration: none; line-height: 1.4em; }';
        $output .= '.essb-admin-dashboard-widget .essb-news-row .essb-news-date { margin-left: 5px; }';
        $output .= '.essb-admin-dashboard-widget .essb-admindash-overview-logo { border-radius: 50px; }';
        
        return $output;
    }
    
    public static function get_latest_news() {
        if (self::$test_mode) {
            $current_time = time();
            return array(
                (object) [
                    'id' => 432,
                    'title' => 'Pinterest Pro Pin Button for WooCommerce: Boost Sales with Free Easy Social Share Buttons Integration',
                    'display_title' => 'Pinterest Pro Pin Button for WooCommerce: Boost Sales with Free Easy Social Share Buttons Integration',
                    'url' => 'https://socialsharingplugin.com/news/pinterest-pro-pin-button-woocommerce-free/',
                    'date' => date('Y-m-d', $current_time),
                    'period_from' => '',
                    'period_to' => '',
                    'type' => 'news',
                ],
                (object) [
                    'id' => 431,
                    'title' => 'Introducing Social Contact: Instant Connection Buttons for WordPress',
                    'display_title' => 'Introducing Social Contact: Instant Connection Buttons for WordPress – Free, Standalone',
                    'url' => 'https://socialsharingplugin.com/news/social-contact-instant-connection-buttons/',
                    'date' => date('Y-m-d', $current_time - (3600 * 24 * 2)),
                    'period_from' => '',
                    'period_to' => '',
                    'type' => 'news',
                ],
                (object) [
                    'id' => 430,
                    'title' => 'Easy Social Share Buttons version 11.6 just released',
                    'display_title' => 'Easy Social Share Buttons version 11.6 just released. Find out what is new and update the plugin.',
                    'url' => 'https://socialsharingplugin.com/version-changes/#11.6',
                    'date' => date('Y-m-d', $current_time - (3600 * 24 * 5)),
                    'period_from' => '',
                    'period_to' => '',
                    'type' => 'update',
                ],
                (object) [
                    'id' => 999,
                    'title' => 'Summer Social Media Boost',
                    'display_title' => 'Exclusive Summer Deal! Get 50% OFF All Plans',
                    'url' => 'https://socialsharingplugin.com/summer-promo',
                    'date' => date('Y-m-d', $current_time),
                    'period_from' => date('Y-m-d', $current_time - (3600 * 24)),
                    'period_to' => date('Y-m-d', $current_time + (3600 * 24 * 30)),
                    'type' => 'promo',
                ],
                (object) [
                    'id' => 998,
                    'title' => 'New Feature: Advanced Social Scheduling',
                    'display_title' => 'New: Schedule your social shares in advance',
                    'url' => 'https://socialsharingplugin.com/announcement-scheduling',
                    'date' => date('Y-m-d', $current_time),
                    'period_from' => date('Y-m-d', $current_time - (3600 * 24)),
                    'period_to' => date('Y-m-d', $current_time + (3600 * 24 * 30)),
                    'type' => 'other',
                ],
            );
        }

        if (function_exists('essb_option_bool_value') && essb_option_bool_value('deactivate_addons_remote')) {
            return false;
        }

        if ( false === ( $news = get_transient('essb_api_latest_news'))) {
            $news = self::get('news');
            delete_transient('essb_api_latest_news');
            set_transient('essb_api_latest_news', $news, DAY_IN_SECONDS);
        }
        
        return $news;
    }
    
    public static function generate_news_output($news = array()) {
        $output = '';
        
        $output .= '<style>' . self::stylesheet_feed() . '</style>';
        
        foreach ($news as $obj) {                    
            $title = $obj->display_title;
            if (empty($title)) {
                $title = $obj->title;
            }
            
            $obj->url = add_query_arg ( array( 'utm_source' => 'news', 'utm_medium' => 'widget', 'utm_campaign' => $obj->type), $obj->url);
            
            $output .= '<div class="essb-news-row">';
            $type_color = isset(self::$news_types[$obj->type]) ? self::$news_types[$obj->type]['color'] : '#999';
            $output .= '<span class="essb-news-typetag essb-news-typetag-' . $obj->type . '" style="background-color:' . $type_color . '">' . self::output_type($obj->type) . '</span>';
            $output .= '<span class="essb-news-title"><a href="'. $obj->url .'" target="_blank">' . $title . '</a></span>';
            if ($obj->type == 'promo') {
                $output .= '<span class="essb-news-date">' . self::format_date_to_local($obj->period_from) . ' - ' . self::format_date_to_local($obj->period_to) . '</span>';
            }
            else {
                $output .= '<span class="essb-news-date">'.self::format_date_to_local($obj->date).'</span>';
            }
            
            $output .= '</div>';
        }        
        
        return $output;
    }
    
    /**
     * Generate an inline code verification snippet
     */
    public static function refresh_news() {
        $hash = hash ( 'sha1', ESSBActivationManager::domain() );
            
        $code = "
<script>
jQuery(document).ready(function( $ ) {
	\"use strict\";
    let options = { 'action': 'essb_update_latest_news', 'hash': '" . $hash . "' };
				$.ajax({
		            type: \"POST\",
		            url: '".esc_url(admin_url ('admin-ajax.php'))."',
		            data: options,
		            success: function (data) {
		            	console.log(data);		            	
		            }
		    	});
});
</script>
";
        echo $code;
    }
    
    
    public static function define_news_update_action() {
        $essb_settings_access = essb_option_value('essb_access');
        if (empty($essb_settings_access)) {
            $essb_settings_access = 'manage_options';
        }
        
        if (is_admin() && current_user_can($essb_settings_access)) {
            add_action ( 'wp_ajax_essb_update_latest_news', array ('ESSB_MyAPI', 'update_latest_news' ) );
        }
    }
    
    public static function update_latest_news() {
        if (function_exists('essb_option_bool_value') && essb_option_bool_value('deactivate_addons_remote')) {
            echo '403';
            die();
        }

        $current_news = self::get_latest_news();
        
        if (is_array($current_news)) {
            echo '200';
        }
        else {
            echo '404';
        }
        die();
    }
    
    public static function news_update_required() {
        $r = false;
        if (!essb_option_bool_value('deactivate_appscreo') && !essb_option_bool_value('deactivate_addons_remote')) {
            if ( false === ( $news = get_transient('essb_api_latest_news'))) {
                $r = true;
            }
        }
        
        return $r;
    }
    
    
    public static function dismiss_promotion() {
        if (isset($_GET['essb_dismiss_promo']) && $_GET['essb_dismiss_promo'] == '1') {
            if (wp_verify_nonce($_GET['_wpnonce'], 'essb_dismiss_promo')) {
                $user_id = get_current_user_id();
                set_transient('essb_promo_dismissed_' . $user_id, 1, WEEK_IN_SECONDS);
                wp_safe_redirect(remove_query_arg(array('essb_dismiss_promo', '_wpnonce')));
                exit;
            }
        }
    }

    public static function is_promotion_dismissed() {
        $user_id = get_current_user_id();
        return false !== get_transient('essb_promo_dismissed_' . $user_id);
    }

    public static function get_active_promotion() {
        if (self::$test_mode) {
            $current_time = time();
            $test_promo = (object) [
                'id' => 999,
                'title' => 'Summer Social Media Boost',
                'display_title' => '🚀 Exclusive Summer Deal! Get 50% OFF All Plans',
                'url' => 'https://socialsharingplugin.com/summer-promo',
                'date' => date('Y-m-d', $current_time),
                'period_from' => date('Y-m-d', $current_time - (3600 * 24)),
                'period_to' => date('Y-m-d', $current_time + (3600 * 24 * 30)),
                'type' => 'promo',
            ];
            $test_promo->url = add_query_arg(array('utm_source' => 'news', 'utm_medium' => 'dashboard_banner', 'utm_campaign' => $test_promo->type), $test_promo->url);
            return $test_promo;
        }

        if (self::is_promotion_dismissed()) {
            return false;
        }
        $news = get_transient('essb_api_latest_news');
        if (is_array($news)) {
            foreach ($news as $obj) {
                if ($obj->type == 'promo') {
                    $period_from = strtotime($obj->period_from);
                    $period_to = strtotime($obj->period_to);
                    if (time() >= $period_from && time() <= $period_to) {
                        if (!$obj->display_title || empty($obj->display_title)) {
                            $obj->display_title = $obj->title;
                        }
                        $obj->url = add_query_arg(array('utm_source' => 'news', 'utm_medium' => 'dashboard_banner', 'utm_campaign' => $obj->type), $obj->url);
                        return $obj;
                    }
                }
            }
        }
        return false;
    }

    public static function render_promotion_banner($show_plugin_name = false) {
        $promo = self::get_active_promotion();
        if (!$promo) {
            return '';
        }

        $dismiss_url = wp_nonce_url(add_query_arg('essb_dismiss_promo', '1'), 'essb_dismiss_promo');

        $width_css = $show_plugin_name ? "                width: calc(100% - 70px);\n" : '';

        $output = '<style>
            .essb-promo-banner.essb-df-spot-hero-style {
                position: relative;
                overflow: hidden;
                background: linear-gradient(120deg, #121a44 0%, #1c2b73 46%, #2748c9 100%);
                border-radius: 0;
                padding: 15px 25px;
                color: #fff;
                display: flex;
                align-items: center;
                gap: 20px;
                box-shadow: 0 8px 20px rgba(23, 33, 83, .14);
                margin-bottom: 0;
                z-index: 1;
' . $width_css . '            }

            .essb-promo-banner.essb-df-spot-hero-style::after {
                content: "";
                position: absolute;
                right: -40px;
                top: -60px;
                width: 300px;
                height: 300px;
                border-radius: 50%;
                background: rgba(255, 255, 255, .08);
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-icon {
                flex-shrink: 0;
                width: 36px;
                height: 36px;
                background: rgba(255, 215, 106, .2);
                border-radius: 50px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 22px;
                color: #ffd76a;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-content {
                flex: 1;
                min-width: 0;
                position: relative;
                z-index: 1;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-plugin-name {
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: .06em;
                color: rgba(255, 255, 255, .65);
                margin: 0 0 4px;
                display: block;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-title {
                font-size: 18px;
                font-weight: 600;
                line-height: 1.2;
                color: #fff;
                margin: 0 0 3px;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-period {
                font-size: 13px;
                color: rgba(255, 255, 255, .85);
                margin-top: 4px;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-action {
                flex-shrink: 0;
                text-align: center;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-action a:first-child {
                position: relative;
                z-index: 2;
                display: inline-block;
                background: #ffd76a;
                color: #121a44;
                font-size: 15px;
                font-weight: 600;
                padding: 10px 24px;
                border-radius: 8px;
                text-decoration: none;
                cursor: pointer;
                transition: background .2s, transform .2s;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-action a:first-child:hover {
                background: #ffce3a;
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(255, 215, 106, .3);
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-dismiss {
                position: relative;
                z-index: 2;
                display: inline-block;
                color: rgba(255, 255, 255, .75);
                font-size: 13px;
                text-decoration: none;
                margin-left: 16px;
                cursor: pointer;
                transition: color .2s;
            }

            .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-dismiss:hover {
                color: #ffd76a;
                text-decoration: underline;
            }

            @media (max-width: 768px) {
                .essb-promo-banner.essb-df-spot-hero-style {
                    flex-wrap: wrap;
                    padding: 24px;
                }
                .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-action {
                    width: 100%;
                    text-align: center;
                    margin-top: 16px;
                }
                .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-action a:first-child {
                    display: block;
                    text-align: center;
                }
                .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-action a:first-child,
                .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-dismiss {
                    margin-left: 0;
                }
                .essb-promo-banner.essb-df-spot-hero-style .essb-promo-banner-dismiss {
                    margin-top: 8px;
                    display: inline-block;
                }
            }
        </style>';

        $output .= '<div class="essb-promo-banner essb-df-spot-hero-style">';
        $output .= '<div class="essb-promo-banner-icon"><svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 44 44"><g><path d="m15,19c-1.1,0-2,0.9-2,2s0.9,2 2,2c0.6,0 1.2-0.3 1.6-0.8 0.2-0.2 0.4-0.6 0.4-1.2 0-0.3-0.1-0.5-0.2-0.8-0.3-0.7-1-1.2-1.8-1.2z" fill="#FFFFFF"/><path d="m26,31c1.1,0 2-0.9 2-2s-0.9-2-2-2c-0.6,0 -1.2,0.3 -1.6,0.8 -0.2,0.2-0.4,0.6-0.4,1.2 0,1.1 0.9,2 2,2 z" fill="#FFFFFF"/><path d="m22,0c-12.2,0-22,9.8-22,22s9.8,22 22,22 22-9.8 22-22-9.8-22-22-22zm7,21c-1.6,0-3.1-0.7-4.2-1.7-0.1-0.1-0.4-0.2-0.5-0.1l-3,1.3c-0.2,0.1-0.3,0.3-0.3,0.5 0,0.5-0.1,1-0.2,1.4 0,0.2 0,0.4 0.2,0.5l1.3,.9c0.2,0.1 0.4,0.1 0.6,0 0.9-0.5 2-0.9 3.1-0.9 3.3,0 6,2.7 6,6s-2.7,6-6,6-6-2.7-6-6c0-0.5 0.1-0.9 0.2-1.4 0-0.2 0-0.4-0.2-0.5l-1.3-1c-0.2-0.1-0.4-0.1-0.6,0-0.9,0.6-2,0.9-3.1,0.9-3.3,0-6-2.7-6-6s2.7-6 6-6c1.6,0 3.1,0.7 4.2,1.7 0.1,0.1 0.4,0.2 0.5,0.1l3-1.3c0.2-0.1 0.3-0.3 0.3-0.5 0,0 0,0 0-0.1 0-3.3 2.7-6 6-6s6,2.7 6,6-2.7,6.2-6,6.2z" fill="#FFFFFF"/><path d="m29,13c-1.1,0-2,0.9-2,2 0,0.3 0.1,0.5 0.2,0.8 0.3,0.7 1,1.2 1.8,1.2 1.1,0 2-0.9 2-2s-0.9-2-2-2z" fill="#FFFFFF"/></g></svg></div>';
        $output .= '<div class="essb-promo-banner-content">';
        if ($show_plugin_name) {
            $output .= '<div class="essb-promo-banner-plugin-name">Easy Social Share Buttons for WordPress</div>';
        }
        $output .= '<div class="essb-promo-banner-title">' . esc_html($promo->display_title) . '</div>';
        $output .= '<div class="essb-promo-banner-period">' . esc_html(self::format_date_to_local($promo->period_from)) . ' &ndash; ' . esc_html(self::format_date_to_local($promo->period_to)) . '</div>';
        $output .= '</div>';
        $output .= '<div class="essb-promo-banner-action"><a href="' . esc_url($promo->url) . '" target="_blank">' . esc_html__('Learn More', 'essb') . '</a><a href="' . esc_url($dismiss_url) . '" class="essb-promo-banner-dismiss">' . esc_html__('Dismiss', 'essb') . '</a></div>';
        $output .= '</div>';

        return $output;
    }

    public static function has_promotion($show_plugin_name = false) {
        ESSB_MyAPI::dismiss_promotion();
        echo self::render_promotion_banner($show_plugin_name);
    }

    /**
     * Handle dismissal of an individual announcement (type 'other')
     *
     * @since 11.7
     */
    public static function dismiss_announcement() {
        if (isset($_GET['essb_dismiss_announcement']) && $_GET['essb_dismiss_announcement'] == '1') {
            if (wp_verify_nonce($_GET['_wpnonce'], 'essb_dismiss_announcement')) {
                $title = isset($_GET['essb_announcement_title']) ? sanitize_title($_GET['essb_announcement_title']) : '';
                if (!empty($title)) {
                    $user_id = get_current_user_id();
                    $key = 'essb_announcement_dismissed_' . $user_id . '_' . sanitize_title($title);
                    set_transient($key, 1, 0);
                }
                wp_safe_redirect(remove_query_arg(array('essb_dismiss_announcement', 'essb_announcement_title', '_wpnonce')));
                exit;
            }
        }
    }

    /**
     * Check if a specific announcement (type 'other') has been dismissed by the current user
     *
     * @since 11.7
     * @param string $title Announcement title used as the dismissal key
     * @return bool
     */
    public static function is_announcement_dismissed($title = '') {
        if (empty($title)) {
            return false;
        }
        $user_id = get_current_user_id();
        $key = 'essb_announcement_dismissed_' . $user_id . '_' . sanitize_title($title);
        return false !== get_transient($key);
    }

    /**
     * Get the active announcement (type 'other') that is not dismissed and within its period
     *
     * @since 11.7
     * @return object|false
     */
    public static function get_active_announcement() {
        if (self::$test_mode) {
            $current_time = time();
            $test_announcement = (object) [
                'id' => 998,
                'title' => 'New Feature: Advanced Social Scheduling',
                'display_title' => '📅 New: Schedule your social shares in advance',
                'url' => 'https://socialsharingplugin.com/announcement-scheduling',
                'date' => date('Y-m-d', $current_time),
                'period_from' => date('Y-m-d', $current_time - (3600 * 24)),
                'period_to' => date('Y-m-d', $current_time + (3600 * 24 * 30)),
                'type' => 'other',
            ];
            $test_announcement->url = add_query_arg(array('utm_source' => 'news', 'utm_medium' => 'dashboard_banner', 'utm_campaign' => $test_announcement->type), $test_announcement->url);
            return $test_announcement;
        }

        $news = get_transient('essb_api_latest_news');
        if (is_array($news)) {
            foreach ($news as $obj) {
                if ($obj->type == 'other') {
                    if (self::is_announcement_dismissed($obj->title)) {
                        continue;
                    }
                    // Check period if available
                    if (isset($obj->period_from) && isset($obj->period_to)) {
                        $period_from = strtotime($obj->period_from);
                        $period_to = strtotime($obj->period_to);
                        if (time() < $period_from || time() > $period_to) {
                            continue;
                        }
                    }
                    if (!$obj->display_title || empty($obj->display_title)) {
                        $obj->display_title = $obj->title;
                    }
                    $obj->url = add_query_arg(array('utm_source' => 'news', 'utm_medium' => 'dashboard_banner', 'utm_campaign' => $obj->type), $obj->url);
                    return $obj;
                }
            }
        }
        return false;
    }

    /**
     * Render the announcement banner (type 'other') with a light blue color scheme
     *
     * @since 11.7
     * @param bool $show_plugin_name Whether to show "Easy Social Share Buttons for WordPress" above the title
     * @return string
     */
    public static function render_announcement_banner($show_plugin_name = false) {
        $announcement = self::get_active_announcement();
        if (!$announcement) {
            return '';
        }

        self::dismiss_announcement();

        $dismiss_url = wp_nonce_url(add_query_arg(array(
            'essb_dismiss_announcement' => '1',
            'essb_announcement_title' => $announcement->title,
        ), ''), 'essb_dismiss_announcement');

        $width_css = $show_plugin_name ? "                width: calc(100% - 70px);\n" : '';

        $output = '<style>
            .essb-announcement-banner {
                position: relative;
                overflow: hidden;
                background: linear-gradient(120deg, #f4f9ff 0%, #fff 62%);
                border: 1px solid rgba(27, 132, 255, .25);
                border-radius: 0;
                padding: 15px 25px;
                color: #121a44;
                display: flex;
                align-items: center;
                gap: 20px;
                box-shadow: 0 4px 12px rgba(27, 132, 255, .12);
                margin-bottom: 0;
                z-index: 1;
' . $width_css . '            }

            .essb-announcement-banner .essb-announcement-banner-icon {
                flex-shrink: 0;
                width: 36px;
                height: 36px;
                background: #eaf4ff;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 22px;
                color: #1b84ff;
            }

            .essb-announcement-banner .essb-announcement-banner-content {
                flex: 1;
                min-width: 0;
                position: relative;
                z-index: 1;
            }

            .essb-announcement-banner .essb-announcement-banner-plugin-name {
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: .03em;
                color: rgba(27, 132, 255, 1);
                margin: 0 0 4px;
                display: block;
            }

            .essb-announcement-banner .essb-announcement-banner-title {
                font-size: 18px;
                font-weight: 600;
                line-height: 1.2;
                color: #121a44;
                margin: 0 0 3px;
            }

            .essb-announcement-banner .essb-announcement-banner-action {
                flex-shrink: 0;
                text-align: center;
            }

            .essb-announcement-banner .essb-announcement-banner-action a:first-child {
                position: relative;
                z-index: 2;
                display: inline-block;
                background: #1b84ff;
                color: #fff;
                font-size: 15px;
                font-weight: 600;
                padding: 10px 24px;
                border-radius: 8px;
                text-decoration: none;
                cursor: pointer;
                transition: background .2s, transform .2s;
            }

            .essb-announcement-banner .essb-announcement-banner-action a:first-child:hover {
                background: #166fe0;
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(27, 132, 255, .3);
            }

            .essb-announcement-banner .essb-announcement-banner-dismiss {
                position: relative;
                z-index: 2;
                display: inline-block;
                color: rgba(27, 132, 255, .75);
                font-size: 13px;
                text-decoration: none;
                margin-left: 16px;
                cursor: pointer;
                transition: color .2s;
            }

            .essb-announcement-banner .essb-announcement-banner-dismiss:hover {
                color: #1b84ff;
                text-decoration: underline;
            }

            @media (max-width: 768px) {
                .essb-announcement-banner {
                    flex-wrap: wrap;
                    padding: 24px;
                }
                .essb-announcement-banner .essb-announcement-banner-action {
                    width: 100%;
                    text-align: center;
                    margin-top: 16px;
                }
                .essb-announcement-banner .essb-announcement-banner-action a:first-child {
                    display: block;
                    text-align: center;
                }
                .essb-announcement-banner .essb-announcement-banner-action a:first-child,
                .essb-announcement-banner .essb-announcement-banner-dismiss {
                    margin-left: 0;
                }
                .essb-announcement-banner .essb-announcement-banner-dismiss {
                    margin-top: 8px;
                    display: inline-block;
                }
            }
        </style>';

        $output .= '<div class="essb-announcement-banner">';
        $output .= '<div class="essb-announcement-banner-icon"><svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 44 44"><g><path d="m15,19c-1.1,0-2,0.9-2,2s0.9,2 2,2c0.6,0 1.2-0.3 1.6-0.8 0.2-0.2 0.4-0.6 0.4-1.2 0-0.3-0.1-0.5-0.2-0.8-0.3-0.7-1-1.2-1.8-1.2z" fill="#1b84ff"/><path d="m26,31c1.1,0 2-0.9 2-2s-0.9-2-2-2c-0.6,0 -1.2,0.3 -1.6,0.8 -0.2,0.2-0.4,0.6-0.4,1.2 0,1.1 0.9,2 2,2 z" fill="#1b84ff"/><path d="m22,0c-12.2,0-22,9.8-22,22s9.8,22 22,22 22-9.8 22-22-9.8-22-22-22zm7,21c-1.6,0-3.1-0.7-4.2-1.7-0.1-0.1-0.4-0.2-0.5-0.1l-3,1.3c-0.2,0.1-0.3,0.3-0.3,0.5 0,0.5-0.1,1-0.2,1.4 0,0.2 0,0.4 0.2,0.5l1.3,.9c0.2,0.1 0.4,0.1 0.6,0 0.9-0.5 2-0.9 3.1-0.9 3.3,0 6,2.7 6,6s-2.7,6-6,6-6-2.7-6-6c0-0.5 0.1-0.9 0.2-1.4 0-0.2 0-0.4-0.2-0.5l-1.3-1c-0.2-0.1-0.4-0.1-0.6,0-0.9,0.6-2,0.9-3.1,0.9-3.3,0-6-2.7-6-6s2.7-6 6-6c1.6,0 3.1,0.7 4.2,1.7 0.1,0.1 0.4,0.2 0.5,0.1l3-1.3c0.2-0.1 0.3-0.3 0.3-0.5 0,0 0,0 0-0.1 0-3.3 2.7-6 6-6s6,2.7 6,6-2.7,6.2-6,6.2z" fill="#1b84ff"/><path d="m29,13c-1.1,0-2,0.9-2,2 0,0.3 0.1,0.5 0.2,0.8 0.3,0.7 1,1.2 1.8,1.2 1.1,0 2-0.9 2-2s-0.9-2-2-2z" fill="#1b84ff"/></g></svg></div>';
        $output .= '<div class="essb-announcement-banner-content">';
        if ($show_plugin_name) {
            $output .= '<div class="essb-announcement-banner-plugin-name">Easy Social Share Buttons for WordPress</div>';
        }
        $output .= '<div class="essb-announcement-banner-title">' . esc_html($announcement->display_title) . '</div>';
        $output .= '</div>';
        $output .= '<div class="essb-announcement-banner-action"><a href="' . esc_url($announcement->url) . '" target="_blank">' . esc_html__('Learn More', 'essb') . '</a><a href="' . esc_url($dismiss_url) . '" class="essb-announcement-banner-dismiss">' . esc_html__('Dismiss', 'essb') . '</a></div>';
        $output .= '</div>';

        return $output;
    }

    /**
     * Echo the announcement banner if one is active
     *
     * @since 11.7
     * @param bool $show_plugin_name Whether to show the plugin name above the title
     */
    public static function has_announcement($show_plugin_name = false) {
        ESSB_MyAPI::dismiss_announcement();
        echo self::render_announcement_banner($show_plugin_name);
    }

  
}