/**
 * Profile networks selection — modern tile list with a Configure drawer.
 *
 * Renders only the selected profile networks and lets the user configure each
 * one through a right-aligned drawer. The drawer stages a draft; Save commits
 * it into the staged hidden inputs of the settings form and marks the tile as
 * pending until the whole form is saved. Nothing is written to the server by
 * this module.
 */
(function ($) {
	'use strict';

	var ESSB_PN_SVG = {
		handle: '<svg width="8" height="14" viewBox="0 0 8 14" fill="currentColor" aria-hidden="true"><circle cx="1.5" cy="2" r="1.2"/><circle cx="6.5" cy="2" r="1.2"/><circle cx="1.5" cy="7" r="1.2"/><circle cx="6.5" cy="7" r="1.2"/><circle cx="1.5" cy="12" r="1.2"/><circle cx="6.5" cy="12" r="1.2"/></svg>',
		cog: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
		times: '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
		plus: '<svg width="11" height="11" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M6 2.25v7.5M2.25 6h7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
	};

	var docBound = false;

	var essbProfileNetworkSelect = {
		currentNetwork: null,
		currentTile: null,

		esc: function (s) {
			return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
				return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
			});
		},

		tint: function (hex, amount) {
			hex = (hex || '').replace('#', '');
			if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
			if (hex.length !== 6) return '#ffffff';
			var r = parseInt(hex.substr(0, 2), 16), g = parseInt(hex.substr(2, 2), 16), b = parseInt(hex.substr(4, 2), 16);
			r = Math.round(r + (255 - r) * amount);
			g = Math.round(g + (255 - g) * amount);
			b = Math.round(b + (255 - b) * amount);
			return 'rgb(' + r + ',' + g + ',' + b + ')';
		},

		networkKey: function (network) {
			if (network == 'twitter') return 'twitter_x';
			if (network == 'instgram') return 'instagram';
			return network;
		},

		color: function (network) {
			var key = this.networkKey(network);
			var profileColors = (typeof essbAdminSettings != 'undefined' && essbAdminSettings.profile_network_colors) ? essbAdminSettings.profile_network_colors : {};
			var shareColors = (typeof essbAdminSettings != 'undefined' && essbAdminSettings.network_colors) ? essbAdminSettings.network_colors : {};
			return profileColors[key] || shareColors[key] || '#6b7280';
		},

		icon: function (network) {
			var profileIcons = (typeof essbAdminSettings != 'undefined' && essbAdminSettings.profile_network_icons) ? essbAdminSettings.profile_network_icons : {};
			if (profileIcons[network]) {
				return profileIcons[network];
			}
			var key = this.networkKey(network);
			return (typeof essb_svg_icons != 'undefined' && essb_svg_icons[key]) ? essb_svg_icons[key] : '';
		},

		name: function (network) {
			var profile = (typeof essbAdminSettings != 'undefined' && essbAdminSettings.profile_networks && essbAdminSettings.profile_networks[network]) ? essbAdminSettings.profile_networks[network] : null;
			if (profile && (profile['label'] || profile['name'])) {
				return profile['label'] || profile['name'];
			}
			var d = (typeof essbAdminSettings != 'undefined' && essbAdminSettings.networks && essbAdminSettings.networks[network]) ? essbAdminSettings.networks[network] : {};
			return d['label'] || d['name'] || network;
		},

		list: function () {
			return $('.essb-component-networkselect-new[data-position="profile"]').first();
		},

		staged: function (network) {
			return $('#essb-pn-staged .essb-pn-staged-network[data-network="' + network + '"]');
		},

		tile: function (network, name) {
			var brand = this.color(network);
			var tint = this.tint(brand, 0.93);
			var staged = this.staged(network);
			var address = staged.length ? staged.find('.essb-pn-staged-address').val() : '';
			var text = staged.length ? staged.find('.essb-pn-staged-text').val() : '';
			var tileValue = (address != '') ? address : text;

			var iconHtml = this.icon(network);
			if (!iconHtml) {
				iconHtml = '<span class="essb-ns-icon-letter">' + this.esc((name || network).charAt(0).toUpperCase()) + '</span>';
			}

			var out = '';
			out += '<li class="essb-admin-networkselect-single essb-ns-tile" data-network="' + this.esc(network) + '" data-network-name="' + this.esc(name) + '" style="--brand:' + brand + ';--brand-tint:' + tint + '">';
			out += '<span class="essb-ns-handle" title="' + this.esc('Drag to reorder') + '">' + ESSB_PN_SVG.handle + '</span>';
			out += '<span class="essb-ns-icon">' + iconHtml + '</span>';
			out += '<span class="essb-ns-info">';
			out += '<span class="essb-sns-name essb-ns-name">' + this.esc(name) + '</span>';
			out += '<span class="essb-single-network-name essb-ns-text">';
			out += '<span class="essb-ns-text-line"><span class="essb-ns-text-label">' + this.esc('Status') + '</span><span class="essb-ns-tag essb-ns-tag-default">' + this.esc('default') + '</span></span>';
			out += '<span class="essb-ns-text-value">' + this.esc(tileValue) + '</span>';
			out += '</span></span>';
			out += '<span class="essb-ns-actions">';
			out += '<button type="button" class="essb-ns-iconbtn essb-ns-configure" title="' + this.esc('Configure network') + '">' + ESSB_PN_SVG.cog + '</button>';
			out += '<button type="button" class="essb-ns-iconbtn essb-ns-remove" title="' + this.esc('Remove network') + '">' + ESSB_PN_SVG.times + '</button>';
			out += '</span>';
			out += '<input type="hidden" name="essb_options[profile_networks][]" value="' + this.esc(network) + '">';
			out += '<input type="hidden" name="essb_options[profile_networks_order][]" value="' + this.esc(network) + '|' + this.esc(name) + '">';
			out += '</li>';
			return out;
		},

		addTile: function () {
			return '<li class="essb-ns-add" data-network="add" role="button" tabindex="0">' +
				'<span class="essb-ns-add-plus">' + ESSB_PN_SVG.plus + '</span>' +
				'<span>' + this.esc('Add networks') + '</span>' +
				'</li>';
		},

		/**
		 * Redraw the list after the network selection popup is confirmed.
		 */
		render: function (networks, namesCache) {
			var $list = this.list();
			var names = {};

			$list.find('.essb-ns-tile').each(function () {
				names[$(this).attr('data-network')] = $(this).attr('data-network-name') || '';
			});

			var out = '';
			for (var i = 0; i < networks.length; i++) {
				var net = networks[i];
				out += this.tile(net, names[net] || this.name(net));
			}
			out += this.addTile();
			return out;
		},

		// ============ DRAWER ============

		openDrawer: function ($tile) {
			var network = $tile.attr('data-network');
			var name = $tile.find('.essb-ns-name').first().text();
			var staged = this.staged(network);
			var address = staged.length ? staged.find('.essb-pn-staged-address').val() : '';
			var text = staged.length ? staged.find('.essb-pn-staged-text').val() : '';
			var count = staged.length ? staged.find('.essb-pn-staged-count').val() : '';

			this.currentNetwork = network;
			this.currentTile = $tile;

			$('#essb-pn-config-name').text(name);
			$('#essb-pn-config-address').val(address);
			$('#essb-pn-config-text').val(text);
			$('#essb-pn-config-count').val(count);

			var isForm = (network == 'subscribe_form');
			$('#essb-pn-config-address-field').toggle(!isForm);
			$('#essb-pn-config-design-field').toggle(isForm);
			if (isForm) {
				$('#essb-pn-config-design').val(address);
			}

			$('#essb-pn-config-overlay').addClass('essb-dr-overlay-show');
			$('#essb-pn-config-wrap').addClass('essb-dr-drawer-show');
		},

		closeDrawer: function () {
			$('#essb-pn-config-overlay').removeClass('essb-dr-overlay-show');
			$('#essb-pn-config-wrap').removeClass('essb-dr-drawer-show');
			this.currentNetwork = null;
			this.currentTile = null;
		},

		saveDrawer: function () {
			if (!this.currentNetwork) {
				return;
			}

			var network = this.currentNetwork;
			var staged = this.staged(network);
			var address = $('#essb-pn-config-address').val();
			var text = $('#essb-pn-config-text').val();
			var count = $('#essb-pn-config-count').val();

			if (network == 'subscribe_form') {
				address = $('#essb-pn-config-design').val();
			}

			if (staged.length) {
				staged.find('.essb-pn-staged-address').val(address);
				staged.find('.essb-pn-staged-text').val(text);
				staged.find('.essb-pn-staged-count').val(count);
			}

			var $tile = this.currentTile;
			if ($tile && $tile.length) {
				$tile.find('.essb-ns-text-value').text((address != '') ? address : text);
				$tile.addClass('is-pending');
			}

			this.closeDrawer();
		},

		// ============ BINDING ============

		init: function () {
			var self = this;

			$('.essb-component-networkselect-new[data-position="profile"]').each(function () {
				if ($(this).data('essb-pn-bound')) {
					return;
				}
				$(this).data('essb-pn-bound', true);
				self.bind(this);
			});

			if (!docBound) {
				docBound = true;
				$(document).on('pointermove.essb-pn', function (e) { self.onDragMove(e); });
				$(document).on('pointerup.essb-pn', function () { self.onDragEnd(); });
			}

			$('#essb-pn-config-save').off('click.essb-pn').on('click.essb-pn', function () { self.saveDrawer(); });
			$('#essb-pn-config-cancel').off('click.essb-pn').on('click.essb-pn', function () { self.closeDrawer(); });
			$('#essb-pn-config-close').off('click.essb-pn').on('click.essb-pn', function () { self.closeDrawer(); });
			$('#essb-pn-config-overlay').off('click.essb-pn').on('click.essb-pn', function () { self.closeDrawer(); });

			$(document).off('keydown.essb-pn').on('keydown.essb-pn', function (e) {
				if (e.key === 'Escape') {
					self.closeDrawer();
				}
			});
		},

		bind: function (list) {
			var self = this;
			var $list = $(list);

			$list.on('click', '.essb-ns-remove', function (e) {
				e.preventDefault();
				$(this).closest('li.essb-ns-tile').remove();
			});

			$list.on('click', '.essb-ns-configure', function (e) {
				e.preventDefault();
				self.openDrawer($(this).closest('li.essb-ns-tile'));
			});

			$list.on('click', '.essb-ns-add', function (e) {
				e.preventDefault();
				var salt = $list.attr('data-key') || ($list.attr('id') || '').replace('essb-componentkey-', '');
				if (window.essbSettingsHelper) {
					essbSettingsHelper.startNetworkSelection(salt);
				}
			});

			$list.on('pointerdown.essb-pn', '.essb-ns-handle', function (e) {
				self.onDragStart(e, this);
			});
		},

		// ============ DRAG TO REORDER ============

		onDragStart: function (e, handle) {
			var $tile = $(handle).closest('li.essb-ns-tile');
			if (!$tile.length) {
				return;
			}

			e.preventDefault();

			var el = $tile[0];
			var rect = el.getBoundingClientRect();
			this.dragEl = $tile;
			this.dragElDom = el;
			this.dragOffX = e.clientX - rect.left;
			this.dragOffY = e.clientY - rect.top;
			this.dragPlaceholder = $('<li class="essb-ns-placeholder"></li>').css('min-height', rect.height);
			$tile.before(this.dragPlaceholder);

			el.classList.add('dragging');
			el.style.width = rect.width + 'px';
			el.style.left = (e.clientX - this.dragOffX) + 'px';
			el.style.top = (e.clientY - this.dragOffY) + 'px';
			$('body').addClass('essb-ns-dragging');
		},

		onDragMove: function (e) {
			if (!this.dragEl) {
				return;
			}

			var el = this.dragElDom;
			el.style.left = (e.clientX - this.dragOffX) + 'px';
			el.style.top = (e.clientY - this.dragOffY) + 'px';

			var dom = el.parentNode;
			var tiles = dom.querySelectorAll('.essb-ns-tile');
			var target = null;

			for (var i = 0; i < tiles.length; i++) {
				if (tiles[i] === el) continue;
				var b = tiles[i].getBoundingClientRect();
				if (e.clientY < b.top + b.height / 2 && e.clientX < b.right) {
					target = tiles[i];
					break;
				}
			}

			if (target) {
				dom.insertBefore(this.dragPlaceholder[0], target);
			} else {
				dom.insertBefore(this.dragPlaceholder[0], dom.querySelector('.essb-ns-add'));
			}
		},

		onDragEnd: function () {
			if (!this.dragEl) {
				return;
			}

			var el = this.dragElDom;
			this.dragPlaceholder.before(this.dragEl);
			this.dragPlaceholder.remove();

			el.classList.remove('dragging');
			el.style.width = el.style.left = el.style.top = '';
			$('body').removeClass('essb-ns-dragging');

			this.dragEl = null;
			this.dragElDom = null;
			this.dragPlaceholder = null;
		}
	};

	window.essbProfileNetworkSelect = essbProfileNetworkSelect;

	$(function () {
		essbProfileNetworkSelect.init();
	});

})(jQuery);
