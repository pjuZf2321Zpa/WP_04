(function () {
	'use strict';

	var PREFIX = 'fanscustomizer_';
	var root = document.getElementById('flcWrap');
	if (!root) return;

	var networks = (window.FLC_NETWORKS || []).map(function (n) { return n; });
	var committed = Object.assign({}, window.FLC_COMMITTED || {});
	var colors = Object.assign({}, committed);
	var showHoverPreview = false;

	function brandColor(key) {
		if (key === 'twitter') return '#000000';
		try {
			if (window.essbAdminSettings && window.essbAdminSettings.follower_network_colors && window.essbAdminSettings.follower_network_colors[key]) {
				return window.essbAdminSettings.follower_network_colors[key];
			}
		} catch (e) {}
		return '#9ca3af';
	}
	function iconSvg(key) {
		try {
			if (window.essbAdminSettings && window.essbAdminSettings.follower_network_icons && window.essbAdminSettings.follower_network_icons[key]) {
				return window.essbAdminSettings.follower_network_icons[key];
			}
		} catch (e) {}
		return '';
	}

	function isValidHex(v) { return /^#[0-9a-fA-F]{6}$/.test(v); }
	function normalizeHex(v) {
		v = (v || '').trim();
		if (v && v.charAt(0) !== '#') v = '#' + v;
		return v;
	}
	function get(key) { return colors[key] || ''; }
	// store keys already include prefix in colors; helpers below use full keys
	function fullKey(netKey, hover) { return PREFIX + (hover ? 'hover_' : '') + netKey; }
	// Actually committed keys are fanscustomizer_<net> and fanscustomizer_hover_<net>
	function kReg(netKey) { return PREFIX + netKey; }
	function kHov(netKey) { return PREFIX + 'hover_' + netKey; }

	function set(key, value) {
		colors[key] = value || '';
		updateChangedCount();
	}
	function networkByKey(key) {
		for (var i = 0; i < networks.length; i++) if (networks[i].key === key) return networks[i];
		return null;
	}
	function updateColorButton(key, value) {
		var btn = root.querySelector('.plc-color-btn[data-key="' + key + '"]');
		if (btn) btn.style.background = value || '#f1f1f4';
	}
	function bindColorPair(colorInput, hexInput, key) {
		colorInput.addEventListener('input', function () {
			hexInput.value = colorInput.value;
			set(key, colorInput.value);
			updateColorButton(key, colorInput.value);
			var nk = networkKeyFromOption(key);
			refreshCard(nk);
			if (/hover/.test(key)) {
				var p = root.querySelector('.plc-net-card[data-key="' + nk + '"] .plc-net-preview');
				if (p) p.dispatchEvent(new MouseEvent('mouseenter'));
			}
		});
		hexInput.addEventListener('input', function () {
			var v = normalizeHex(hexInput.value);
			if (isValidHex(v)) {
				colorInput.value = v;
				set(key, v);
				updateColorButton(key, v);
				var nk = networkKeyFromOption(key);
				refreshCard(nk);
				if (/hover/.test(key)) {
					var p = root.querySelector('.plc-net-card[data-key="' + nk + '"] .plc-net-preview');
					if (p) p.dispatchEvent(new MouseEvent('mouseenter'));
				}
			} else if (hexInput.value.trim() === '') {
				set(key, '');
				updateColorButton(key, '');
				refreshCard(networkKeyFromOption(key));
			}
		});
		hexInput.addEventListener('blur', function () {
			var v = get(key);
			hexInput.value = v;
			if (v) colorInput.value = v;
		});
	}
	function syncPair(key) {
		var colorInput = root.querySelector('.plc-color[data-key="' + key + '"]');
		var hexInput = root.querySelector('.plc-hex[data-key="' + key + '"]');
		if (!colorInput || !hexInput) return;
		var v = get(key);
		hexInput.value = v;
		if (v && isValidHex(v)) colorInput.value = v;
		var btn = root.querySelector('.plc-color-btn[data-key="' + key + '"]');
		if (btn) btn.style.background = v || '#f1f1f4';
	}
	function networkKeyFromOption(key) {
		key = key.replace(PREFIX + 'hover_', '').replace(PREFIX + 'icon_hover_', '').replace(PREFIX + 'icon_', '').replace(PREFIX, '');
		return key;
	}

	function renderGrid() {
		var grid = root.querySelector('#flcGrid');
		if (!grid) return;
		grid.innerHTML = '';
		var q = (root.querySelector('#flcSearch').value || '').toLowerCase();
		var shown = 0;
		networks.forEach(function (n) {
			if (q && n.name.toLowerCase().indexOf(q) === -1 && n.key.toLowerCase().indexOf(q) === -1) return;
			shown++;
			var card = document.createElement('div');
			card.className = 'plc-net-card';
			card.setAttribute('data-key', n.key);
			var regKey = kReg(n.key);
			var hovKey = kHov(n.key);
			var brand = brandColor(n.key);
			var effective = get(regKey) || brand;
			var svg = iconSvg(n.key);
			card.innerHTML =
				'<div class="plc-net-preview" style="background:' + effective + '">' +
					'<span class="plc-net-icon">' + (svg ? svg : escapeHtml(n.name.charAt(0).toUpperCase())) + '</span>' +
					'<span class="plc-net-name">' + escapeHtml(n.name) + '</span>' +
				'</div>' +
				'<div class="plc-net-fields">' +
					'<div class="plc-net-row">' +
						'<label>Regular</label>' +
						'<div class="essb-cd-color" data-key="' + regKey + '">' +
							'<label class="plc-color-btn" data-key="' + regKey + '"><input type="color" class="plc-color" data-key="' + regKey + '" value="' + (get(regKey) || brand) + '"></label>' +
							'<input type="text" name="essb_options[' + regKey + ']" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="' + regKey + '" maxlength="7" placeholder="#rrggbb">' +
						'</div>' +
					'</div>' +
					'<div class="plc-net-row">' +
						'<label>Hover</label>' +
						'<div class="essb-cd-color" data-key="' + hovKey + '">' +
							'<label class="plc-color-btn" data-key="' + hovKey + '"><input type="color" class="plc-color" data-key="' + hovKey + '" value="' + (get(hovKey) || get(regKey) || brand) + '"></label>' +
							'<input type="text" name="essb_options[' + hovKey + ']" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="' + hovKey + '" maxlength="7" placeholder="#rrggbb">' +
						'</div>' +
					'</div>' +
					'<div class="plc-net-row">' +
						'<label>Icon</label>' +
						'<div class="essb-cd-color" data-key="fanscustomizer_icon_' + n.key + '">' +
							'<label class="plc-color-btn" data-key="fanscustomizer_icon_' + n.key + '"><input type="color" class="plc-color" data-key="fanscustomizer_icon_' + n.key + '" value="' + (get('fanscustomizer_icon_' + n.key) || '#ffffff') + '"></label>' +
							'<input type="text" name="essb_options[fanscustomizer_icon_' + n.key + ']" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="fanscustomizer_icon_' + n.key + '" maxlength="7" placeholder="#rrggbb">' +
						'</div>' +
					'</div>' +
					'<div class="plc-net-row">' +
						'<label>Icon hov</label>' +
						'<div class="essb-cd-color" data-key="fanscustomizer_icon_hover_' + n.key + '">' +
							'<label class="plc-color-btn" data-key="fanscustomizer_icon_hover_' + n.key + '"><input type="color" class="plc-color" data-key="fanscustomizer_icon_hover_' + n.key + '" value="' + (get('fanscustomizer_icon_hover_' + n.key) || '#ffffff') + '"></label>' +
							'<input type="text" name="essb_options[fanscustomizer_icon_hover_' + n.key + ']" class="input-element essb-cd-input mono plc-hex input-colorselector" data-key="fanscustomizer_icon_hover_' + n.key + '" maxlength="7" placeholder="#rrggbb">' +
						'</div>' +
					'</div>' +
				'</div>' +
				'<div class="plc-net-actions">' +
					'<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-xs plc-reset" data-reset="' + n.key + '">Reset</button>' +
				'</div>';
			grid.appendChild(card);

			bindColorPair(
				card.querySelector('.plc-color[data-key="' + regKey + '"]'),
				card.querySelector('.plc-hex[data-key="' + regKey + '"]'),
				regKey
			);
			bindColorPair(
				card.querySelector('.plc-color[data-key="' + hovKey + '"]'),
				card.querySelector('.plc-hex[data-key="' + hovKey + '"]'),
				hovKey
			);
			var iconKey = 'fanscustomizer_icon_' + n.key;
			var iconHovKey = 'fanscustomizer_icon_hover_' + n.key;
			bindColorPair(
				card.querySelector('.plc-color[data-key="' + iconKey + '"]'),
				card.querySelector('.plc-hex[data-key="' + iconKey + '"]'),
				iconKey
			);
			bindColorPair(
				card.querySelector('.plc-color[data-key="' + iconHovKey + '"]'),
				card.querySelector('.plc-hex[data-key="' + iconHovKey + '"]'),
				iconHovKey
			);

			syncPair(regKey);
			syncPair(hovKey);
			syncPair('fanscustomizer_icon_' + n.key);
			syncPair('fanscustomizer_icon_hover_' + n.key);
			refreshCard(n.key);
		});

		var count = root.querySelector('#flcCount');
		if (count) count.textContent = shown + ' of ' + networks.length;

		grid.querySelectorAll('.plc-reset').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var k = btn.getAttribute('data-reset');
				set(kReg(k), '');
				set(kHov(k), '');
				syncPair(kReg(k));
				syncPair(kHov(k));
				refreshCard(k);
			});
		});
	}

	function refreshCard(key) {
		var card = root.querySelector('.plc-net-card[data-key="' + key + '"]');
		if (!card) return;
		var regKey = kReg(key);
		var hovKey = kHov(key);
		var reg = get(regKey);
		var hov = get(hovKey);
		var brand = brandColor(key);
		var effective = reg || brand;
		var effectiveHover = hov || effective;
		var iconColor = get('fanscustomizer_icon_' + key) || get('fanscustomizer_icon_all') || '#ffffff';
		var iconHoverColor = get('fanscustomizer_icon_hover_' + key) || get('fanscustomizer_icon_hover_all') || iconColor;
		var preview = card.querySelector('.plc-net-preview');
		if (preview) {
			var bg = showHoverPreview ? effectiveHover : effective;
			var ic = showHoverPreview ? iconHoverColor : iconColor;
			preview.style.background = bg;
			var iconEl = preview.querySelector('.plc-net-icon');
			var nameEl = preview.querySelector('.plc-net-name');
			if (iconEl) {
				iconEl.style.color = ic;
				var svg = iconEl.querySelector('svg');
				if (svg) svg.style.fill = ic;
			}
			if (nameEl) nameEl.style.color = ic;
			preview.onmouseenter = function () {
				preview.style.background = effectiveHover;
				if (iconEl) {
					iconEl.style.color = iconHoverColor;
					var s = iconEl.querySelector('svg');
					if (s) s.style.fill = iconHoverColor;
				}
				if (nameEl) nameEl.style.color = iconHoverColor;
			};
			preview.onmouseleave = function () {
				preview.style.background = showHoverPreview ? effectiveHover : effective;
				if (iconEl) {
					iconEl.style.color = showHoverPreview ? iconHoverColor : iconColor;
					var s = iconEl.querySelector('svg');
					if (s) s.style.fill = showHoverPreview ? iconHoverColor : iconColor;
				}
				if (nameEl) nameEl.style.color = showHoverPreview ? iconHoverColor : iconColor;
			};
		}
		if (reg || hov) card.classList.add('is-changed'); else card.classList.remove('is-changed');
	}

	function updateChangedCount() {
		var nets = 0;
		networks.forEach(function (n) {
			var r = get(kReg(n.key)) || '';
			var h = get(kHov(n.key)) || '';
			if (r !== '' || h !== '') nets++;
		});
		var el = root.querySelector('#flcChanged');
		if (el) el.textContent = nets + ' of ' + networks.length;
	}

	function bindGlobal() {
		var colorAll = root.querySelector('.plc-color[data-key="fanscustomizer_all"]');
		var hexAll = root.querySelector('.plc-hex[data-key="fanscustomizer_all"]');
		if (colorAll && hexAll) bindColorPair(colorAll, hexAll, 'fanscustomizer_all');
		var colorHov = root.querySelector('.plc-color[data-key="fanscustomizer_hover_all"]');
		var hexHov = root.querySelector('.plc-hex[data-key="fanscustomizer_hover_all"]');
		if (colorHov && hexHov) bindColorPair(colorHov, hexHov, 'fanscustomizer_hover_all');
		var colorIcon = root.querySelector('.plc-color[data-key="fanscustomizer_icon_all"]');
		var hexIcon = root.querySelector('.plc-hex[data-key="fanscustomizer_icon_all"]');
		if (colorIcon && hexIcon) bindColorPair(colorIcon, hexIcon, 'fanscustomizer_icon_all');
		var colorIconHov = root.querySelector('.plc-color[data-key="fanscustomizer_icon_hover_all"]');
		var hexIconHov = root.querySelector('.plc-hex[data-key="fanscustomizer_icon_hover_all"]');
		if (colorIconHov && hexIconHov) bindColorPair(colorIconHov, hexIconHov, 'fanscustomizer_icon_hover_all');
		syncPair('fanscustomizer_all');
		syncPair('fanscustomizer_hover_all');
		syncPair('fanscustomizer_icon_all');
		syncPair('fanscustomizer_icon_hover_all');
	}

	function bindEnable() {
		var cb = document.getElementById('flcEnable');
		var body = root;
		if (!cb || !body) return;
		cb.addEventListener('change', function () {
			if (cb.checked) body.classList.remove('plc-disabled'); else body.classList.add('plc-disabled');
		});
	}

	function bindSearch() {
		var s = root.querySelector('#flcSearch');
		if (!s) return;
		s.addEventListener('input', function (e) {
			renderGrid();
		});
	}

	function bindResetAll() {
		var b = root.querySelector('#flcResetAll');
		if (!b) return;
		b.addEventListener('click', function () {
			networks.forEach(function (n) {
				set(kReg(n.key), '');
				set(kHov(n.key), '');
			});
			renderGrid();
		});
	}
	function bindPreviewHover() {
		var cb = root.querySelector('#flcPreviewHover');
		if (!cb) return;
		cb.addEventListener('change', function () {
			showHoverPreview = cb.checked;
			renderGrid();
		});
	}

	function escapeHtml(s) {
		return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
	}

	function init() {
		bindGlobal();
		bindEnable();
		bindSearch();
		bindResetAll();
		bindPreviewHover();
		renderGrid();
		updateChangedCount();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();