(function ($) {
  'use strict';

  if (!window.ESSB_SFC) { return; }

  var SFC = window.ESSB_SFC;
  var presets = SFC.presets || {};
  var presetMap = SFC.presetMap || {};
  var customized = SFC.customized || {};
  var customs = SFC.customs || [];
  var customKeys = SFC.customKeys || [];
  var customMap = SFC.customMap || { texts: [], colors: [] };

  var overlay = $('#sfc-overlay');
  var modal = $('#sfc-modal');
  var modalLeft = $('#sfc-modal-left');
  var previewStage = $('#sfc-preview');
  var previewBadge = $('#sfc-preview-badge');
  var modalFooter = $('#sfc-modal-footer');
  var modalTitle = $('#sfc-modal-title');

  var styleEl = ensureStyle('sfc-preview-style');
  var currentPreset = 1;
  var customEditing = null; // 'new' or numeric index into customs
  var customDraft = null;
  var presetTimer = null;
  var customTimer = null;

  function ensureStyle(id) {
    var el = document.getElementById(id);
    if (!el) {
      el = document.createElement('style');
      el.id = id;
      document.head.appendChild(el);
    }
    return el;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function ajaxUrl() {
    if (typeof essb_advancedopts_ajaxurl !== 'undefined' && essb_advancedopts_ajaxurl) {
      return essb_advancedopts_ajaxurl;
    }
    return SFC.ajaxurl;
  }

  function advToken() {
    var t = $('#essb_advancedoptions_token').val();
    return t || '';
  }

  function sfcToast(heading) {
    if (typeof $.toast === 'function') {
      $.toast({
        heading: heading,
        showHideTransition: 'fade',
        icon: 'success',
        position: 'bottom-right',
        hideAfter: 5000
      });
    }
  }

  var modalMode = null;

  function openModal(title, badge) {
    modalTitle.text(title);
    previewBadge.text(badge);
    overlay.addClass('sfc-modal-overlay-show');
    modal.addClass('sfc-modal-show');
  }

  function closeModal() {
    overlay.removeClass('sfc-modal-overlay-show');
    modal.removeClass('sfc-modal-show');
    styleEl.textContent = '';
    modalMode = null;
  }

  function revertPresetAndClose() {
    if (presetSnapshot) {
      presets[String(currentPreset)] = $.extend({}, presetSnapshot);
      pushPresetToStore(currentPreset);
    }
    presetSnapshot = null;
    closeModal();
    renderList();
  }

  overlay.on('click', function () {
    if (modalMode === 'preset') { revertPresetAndClose(); } else { closeModal(); }
  });
  $('#sfc-modal-close').on('click', function () {
    if (modalMode === 'preset') { revertPresetAndClose(); } else { closeModal(); }
  });
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') {
      if (modalMode === 'preset') { revertPresetAndClose(); } else { closeModal(); }
    }
  });

  function isCustomized(num) {
    var vals = presets[String(num)] || {};
    var def = presetMap[String(num)];
    if (!def) { return false; }
    var keys = [];
    (def.texts || []).concat(def.colors || []).forEach(function (f) { keys.push(f.key); });
    for (var i = 0; i < keys.length; i++) {
      var v = vals[keys[i]];
      if (v && String(v).trim() !== '') { return true; }
    }
    return !!(customized[String(num)]);
  }

  function renderList() {
    var list = $('#sfc-list');
    list.empty();

    for (var i = 1; i <= 9; i++) {
      (function (num) {
        var row = $('<div class="sfc-row"></div>');
        var pill = isCustomized(num)
          ? '<span class="sfc-pill sfc-pill-customized">Customized</span>'
          : '<span class="sfc-pill sfc-pill-default">Default</span>';
        row.append(
          '<div class="sfc-row-left"><span class="sfc-row-title">Design #' + num + '</span>' + pill + '</div>'
        );
        var right = $('<div class="sfc-row-right"></div>');
        var btn = $('<button type="button" class="essb-ui-btn essb-ui-btn-primary">Customize</button>');
        btn.on('click', function () { openPresetEditor(num); });
        right.append(btn);
        row.append(right);
        list.append(row);
      })(i);
    }

    customs.forEach(function (f, idx) {
      var row = $('<div class="sfc-row"></div>');
      var realIdx = customKeys[idx] !== undefined ? customKeys[idx] : idx;
      row.append(
        '<div class="sfc-row-left"><span class="sfc-row-title">' + esc(f.name || 'Untitled Form') + '</span>' +
        '<span class="sfc-row-sub">Custom &middot; .essb-custom-userdesign-' + esc(String(realIdx)) + '</span></div>'
      );
      var right = $('<div class="sfc-row-right"></div>');
      var editBtn = $('<button type="button" class="essb-ui-btn essb-ui-btn-light">Edit</button>');
      editBtn.on('click', function () { openCustomEditor(idx); });
      var delBtn = $('<button type="button" class="essb-ui-btn essb-ui-btn-danger">Remove</button>');
      delBtn.on('click', function () { removeCustom(idx); });
      right.append(editBtn).append(delBtn);
      row.append(right);
      list.append(row);
    });

    if (!customs.length) {
      list.append('<div style="color:#888;font-size:13px;padding:8px;">No custom forms yet. Click &ldquo;+ Add new form design&rdquo; to create one.</div>');
    }
  }

  function switchRow(optKey, label, checked) {
    return '<div class="sfc-toggle-row-item">' +
      '<span class="essb-ui-switch essb-ui-switch-sm"><input class="essb-ui-switch-check sfc-switch" type="checkbox" data-opt="' + esc(optKey) + '"' + (checked ? ' checked="checked"' : '') + '></span>' +
      '<span class="sfc-toggle-label">' + esc(label) + '</span></div>';
  }

  function textRow(optKey, label, value, textarea) {
    var input;
    if (textarea) {
      input = '<textarea class="input-element sfc-text" rows="3" data-opt="' + esc(optKey) + '">' + esc(value) + '</textarea>';
    } else {
      input = '<input type="text" class="input-element sfc-text" value="' + esc(value) + '" data-opt="' + esc(optKey) + '">';
    }
    return '<label>' + esc(label) + input + '</label>';
  }

  function colorRow(optKey, label, value) {
    var v = value && /^#[0-9a-fA-F]{6}$/.test(value) ? value : '#ffffff';
    return '<div class="sfc-color-item"><span>' + esc(label) + '</span>' +
      '<div class="sfc-color-row">' +
      '<label class="sfc-color-swatch" style="background:' + esc(v) + ';"><input type="color" value="' + esc(v) + '" data-picker="' + esc(optKey) + '"></label>' +
      '<input type="text" class="input-element sfc-color-text sfc-text" value="' + esc(value || '') + '" data-opt="' + esc(optKey) + '" placeholder="#ffffff">' +
      '</div></div>';
  }

  // Persistent hidden store inside the main settings form so preset edits
  // survive modal close / switching designs and submit with Update Options.
  function sfcStoreInput(key, value) {
    var store = $('#sfc-store');
    var input = store.find('input[data-store="' + key + '"]');
    if (!input.length) {
      input = $('<input type="hidden" data-store="' + esc(key) + '">');
      input.attr('name', 'essb_options[' + key + ']');
      store.append(input);
    }
    input.val(value);
  }

  function pushPresetToStore(num) {
    var vals = presets[String(num)] || {};
    Object.keys(vals).forEach(function (k) { sfcStoreInput(k, vals[k]); });
  }

  function buildStoreFromPresets() {
    Object.keys(presets).forEach(function (num) { pushPresetToStore(num); });
  }

  var presetSnapshot = null;

  function openPresetEditor(num) {
    currentPreset = num;
    var def = presetMap[String(num)];
    var vals = presets[String(num)] || {};
    if (!def) { return; }
    presetSnapshot = $.extend({}, vals);

    var html = '<div class="sfc-toggle-row">';
    (def.switches || []).forEach(function (sw) {
      var checked = (vals[sw.key] === 'true');
      html += switchRow(sw.key, sw.label, checked);
    });
    html += '</div>';

    html += '<h3 class="sfc-section-title">Form Texts</h3><div class="sfc-field-grid">';
    (def.texts || []).forEach(function (t) {
      var isArea = (t.short === 'text');
      html += textRow(t.key, t.label, vals[t.key] || '', isArea);
    });
    html += '</div>';

    if ((def.images || []).length) {
      html += '<h3 class="sfc-section-title">Image</h3><div class="sfc-field-grid">';
      def.images.forEach(function (img) {
        if (img.type === 'imagealign') {
          var av = vals[img.key] || '';
          html += '<label>' + esc(img.label) +
            '<select class="input-element sfc-text" data-opt="' + esc(img.key) + '">' +
            '<option value="left"' + (av === 'left' ? ' selected' : '') + '>Left side</option>' +
            '<option value="right"' + (av === 'right' ? ' selected' : '') + '>Right side</option>' +
            '</select></label>';
        } else {
          html += '<label>' + esc(img.label) +
            '<div class="sfc-input-with-btn"><input type="text" class="input-element sfc-text" value="' + esc(vals[img.key] || '') + '" data-opt="' + esc(img.key) + '" data-img="' + esc(img.key) + '" placeholder="https://...">' +
            '<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-sm sfc-media" data-target-opt="' + esc(img.key) + '">Select</button></div></label>';
        }
      });
      html += '</div>';
    }

    html += '<h3 class="sfc-section-title">Colors</h3><div class="sfc-color-grid">';
    (def.colors || []).forEach(function (c) {
      html += colorRow(c.key, c.label, vals[c.key] || '');
    });
    html += '</div>';

    html += '<h3 class="sfc-section-title">Custom List (optional)</h3><div class="sfc-field-grid">';
    (def.custom || []).forEach(function (c) {
      html += textRow(c.key, c.label, vals[c.key] || '', false);
    });
    html += '</div>';

    modalLeft.html(html);
    modalLeft.scrollTop(0);
    modalFooter.html(
      '<span style="font-size:12px;color:#888;margin-right:auto;">Changes save immediately when you press Save Form.</span>' +
      '<button type="button" class="essb-ui-btn essb-ui-btn-light" id="sfc-cancel">Cancel</button>' +
      '<button type="button" class="essb-ui-btn essb-ui-btn-primary" id="sfc-done">Save Form</button>'
    );
    $('#sfc-cancel').on('click', function () {
      revertPresetAndClose();
    });
    $('#sfc-done').on('click', function () {
      savePresetDirectly();
    });

    bindPresetInputs();
    modalMode = 'preset';
    openModal('Customize Design #' + num, 'Design #' + num);
    requestPresetPreview();
  }

  function collectPresetValues() {
    var out = {};
    modalLeft.find('[data-opt]').each(function () {
      var key = $(this).attr('data-opt');
      if ($(this).attr('type') === 'checkbox') {
        out[key] = $(this).is(':checked') ? 'true' : '';
      } else {
        out[key] = $(this).val();
      }
      presets[String(currentPreset)][key] = out[key];
    });

    // Auto-enable color changing when any custom color is set, so the
    // chosen colors actually render in the preview (and on save).
    var hasColor = false;
    Object.keys(out).forEach(function (k) {
      if (k.indexOf('customizer_subscribe_') === 0 && out[k] && String(out[k]).trim() !== '') {
        hasColor = true;
      }
    });
    if (hasColor) {
      var switchKey = (currentPreset === 1) ? 'activate_mailchimp_customizer' : ('activate_mailchimp_customizer' + currentPreset);
      out[switchKey] = 'true';
      presets[String(currentPreset)][switchKey] = 'true';
      var sw = modalLeft.find('.sfc-switch[data-opt="' + switchKey + '"]');
      if (sw.length) { sw.prop('checked', true); }
    }

    pushPresetToStore(currentPreset);
    return out;
  }

  function syncPresetToStore() {
    collectPresetValues();
    pushPresetToStore(currentPreset);
  }

  // Direct save of the bundled design via the advanced-options endpoint
  // (same path the old ao- popups used): no Update Options press needed.
  function savePresetDirectly() {
    var values = collectPresetValues();
    var btn = document.getElementById('sfc-done');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving...'; }
    $.ajax({
      url: ajaxUrl(),
      method: 'POST',
      dataType: 'json',
      data: {
        action: 'essb_advanced_options',
        essb_advancedoptions_token: advToken(),
        cmd: 'save',
        group: 'essb_options',
        advanced_options: values
      }
    }).done(function () {
      pushPresetToStore(currentPreset);
      presetSnapshot = null;
      closeModal();
      renderList();
      sfcToast('Form design saved.');
    }).fail(function () {
      alert('Save failed. Please try again.');
      if (btn) { btn.disabled = false; btn.textContent = 'Save Form'; }
    });
  }

  function bindPresetInputs() {
    modalLeft.off('input change');
    // Preview refreshes on change (blur / commit), not while typing, to avoid
    // too many reloads. Color pickers fire 'change' when the user commits.
    modalLeft.on('change', '.sfc-text, input[type=color]', function () {
      var picker = $(this).attr('data-picker');
      if (picker) {
        var target = modalLeft.find('.sfc-color-text[data-opt="' + picker + '"]');
        target.val($(this).val());
        target.closest('.sfc-color-item').find('.sfc-color-swatch').css('background', $(this).val());
      }
      if ($(this).hasClass('sfc-color-text') && /^#[0-9a-fA-F]{6}$/.test($(this).val())) {
        var k = $(this).attr('data-opt');
        modalLeft.find('input[data-picker="' + k + '"]').val($(this).val());
        $(this).closest('.sfc-color-item').find('.sfc-color-swatch').css('background', $(this).val());
      }
      clearTimeout(presetTimer);
      presetTimer = setTimeout(requestPresetPreview, 60);
    });
    modalLeft.on('change', 'select.sfc-text, .sfc-switch', function () {
      clearTimeout(presetTimer);
      presetTimer = setTimeout(requestPresetPreview, 60);
    });
    modalLeft.on('click', '.sfc-media', function (e) {
      e.preventDefault();
      var targetOpt = $(this).attr('data-target-opt');
      openMediaFrame(function (url) {
        var inp = modalLeft.find('[data-img="' + targetOpt + '"]');
        inp.val(url).trigger('change');
      });
    });
  }

  function requestPresetPreview() {
    var values = collectPresetValues();
    previewStage.html('<div class="sfc-loading">Rendering preview&hellip;</div>');
    $.ajax({
      url: ajaxUrl(),
      method: 'POST',
      dataType: 'json',
      data: {
        action: 'essb_advanced_options',
        essb_advancedoptions_token: advToken(),
        cmd: 'subscribe_preview',
        preview_mode: 'preset',
        design: currentPreset,
        values: values
      },
      success: function (resp) {
        var payload = resp && resp.data ? resp.data : (resp || {});
        if (payload.html) {
          previewStage.html(payload.html);
          styleEl.textContent = payload.css || '';
        } else {
          previewStage.html('<div class="sfc-loading">Preview unavailable.</div>');
        }
      },
      error: function () {
        previewStage.html('<div class="sfc-loading">Preview unavailable.</div>');
      }
    });
  }

  // ---------- Custom forms ----------

  $('#sfc-add-new').on('click', function () { openCustomEditor('new'); });

  function blankCustom() {
    return {
      name: '', customlist: '', customtags: '', add_name: '', sameline_fields: '',
      title: '', text: '', footer: '', name_placeholder: '', email_placeholder: '',
      button_placeholder: '', error_message: '', ok_message: '',
      image: '', image_location: '', image_width: '', image_height: '', image_padding: '', image_area_width: '',
      heading_fontsize: '', heading_fontweight: '', text_fontsize: '', text_fontweight: '',
      footer_fontsize: '', footer_fontweight: '', input_fontsize: '', input_fontweight: '',
      button_fontsize: '', button_fontweight: '', align: '',
      bgcolor: '', bgcolor2: '', image_bgcolor: '', textcolor: '', headingcolor: '', footercolor: '',
      fields_bg: '', fields_text: '', button_bg: '', button_text: '',
      border_color: '', border_width: '', border_radius: '', padding: '', glow_color: '', glow_size: ''
    };
  }

  function openCustomEditor(which) {
    customEditing = which;
    if (which === 'new') {
      customDraft = blankCustom();
    } else {
      customDraft = $.extend({}, blankCustom(), customs[which] || {});
    }

    var html = '<h3 class="sfc-section-title">General</h3><div class="sfc-field-grid">';
    html += '<label>Form name<input type="text" class="input-element" id="cc_name" value="' + esc(customDraft.name || '') + '"></label>';
    html += '<label>List ID<input type="text" class="input-element" id="cc_customlist" value="' + esc(customDraft.customlist || '') + '"></label>';
    html += '<label>Tags (MailChimp)<input type="text" class="input-element" id="cc_customtags" value="' + esc(customDraft.customtags || '') + '"></label>';
    html += '</div>';

    html += '<div class="sfc-toggle-row">';
    html += '<div class="sfc-toggle-row-item"><span class="essb-ui-switch essb-ui-switch-sm"><input class="essb-ui-switch-check" id="cc_addname" type="checkbox"' + ((customDraft.add_name === 'true' || customDraft.add_name === true) ? ' checked="checked"' : '') + '></span><span class="sfc-toggle-label">Include name field</span></div>';
    html += '<div class="sfc-toggle-row-item"><span class="essb-ui-switch essb-ui-switch-sm"><input class="essb-ui-switch-check" id="cc_sameline" type="checkbox"' + ((customDraft.sameline_fields === 'true' || customDraft.sameline === true) ? ' checked="checked"' : '') + '></span><span class="sfc-toggle-label">Fields on the same line</span></div>';
    html += '</div>';

    html += '<h3 class="sfc-section-title">Form Texts</h3><div class="sfc-field-grid">';
    (customMap.texts || []).forEach(function (t) {
      if (t.type === 'textarea') {
        html += '<label>' + esc(t.label) + '<textarea class="input-element" id="cc_' + esc(t.key) + '" rows="3">' + esc(customDraft[t.key] || '') + '</textarea></label>';
      } else {
        html += '<label>' + esc(t.label) + '<input type="text" class="input-element" id="cc_' + esc(t.key) + '" value="' + esc(customDraft[t.key] || '') + '"></label>';
      }
    });
    html += '</div>';

    html += '<h3 class="sfc-section-title">Image</h3><div class="sfc-field-grid">';
    html += '<label>Image location<select class="input-element" id="cc_image_location">' +
      '<option value=""' + (!customDraft.image_location ? ' selected' : '') + '>Do not show image</option>' +
      '<option value="left"' + (customDraft.image_location === 'left' ? ' selected' : '') + '>On the left</option>' +
      '<option value="right"' + (customDraft.image_location === 'right' ? ' selected' : '') + '>On the right</option>' +
      '<option value="top"' + (customDraft.image_location === 'top' ? ' selected' : '') + '>At the top above heading</option>' +
      '<option value="below_heading"' + (customDraft.image_location === 'below_heading' ? ' selected' : '') + '>Between heading and content</option>' +
      '<option value="background"' + (customDraft.image_location === 'background' ? ' selected' : '') + '>As form background</option>' +
      '</select></label>';
    html += '<div id="cc_image_details" style="display:' + (customDraft.image_location ? 'grid' : 'none') + ';gap:10px;">';
    html += '<label>Image URL<div class="sfc-input-with-btn"><input type="text" class="input-element" id="cc_image" value="' + esc(customDraft.image || '') + '" placeholder="https://..."><button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-sm" id="cc_select_image">Select image</button></div></label>';
    html += '<div id="cc_image_size" style="display:' + ((customDraft.image_location && customDraft.image_location !== 'background') ? 'contents' : 'none') + ';">';
    html += '<label>Image width<input type="text" class="input-element" id="cc_image_width" value="' + esc(customDraft.image_width || '') + '" placeholder="100%"></label>';
    html += '<label>Image height<input type="text" class="input-element" id="cc_image_height" value="' + esc(customDraft.image_height || '') + '" placeholder="auto"></label>';
    html += '<label>Image area width<select class="input-element" id="cc_image_area_width">' +
      [''].concat(['25', '30', '40', '50']).map(function (w) {
        return '<option value="' + w + '"' + ((customDraft.image_area_width || '') === w ? ' selected' : '') + '>' + (w === '' ? 'Default' : w + '%') + '</option>';
      }).join('') + '</select></label>';
    html += '<label>Image padding<input type="text" class="input-element" id="cc_image_padding" value="' + esc(customDraft.image_padding || '') + '" placeholder="20px"></label>';
    html += '</div></div></div>';

    html += '<h3 class="sfc-section-title">Font size / weight</h3><div class="sfc-font-grid">';
    [['heading', 'Heading'], ['text', 'Text'], ['footer', 'Footer'], ['input', 'Input fields'], ['button', 'Button']].forEach(function (g) {
      html += '<div class="sfc-font-row"><span class="sfc-font-label">' + g[1] + '</span><div class="sfc-font-inputs">' +
        '<input type="text" class="input-element" data-cfont="' + g[0] + '_fontsize" placeholder="font size (14px)" value="' + esc(customDraft[g[0] + '_fontsize'] || '') + '">' +
        '<select class="input-element" data-cweight="' + g[0] + '_fontweight">' +
        '<option value=""' + (!customDraft[g[0] + '_fontweight'] ? ' selected' : '') + '>Theme default</option>' +
        '<option value="400"' + (customDraft[g[0] + '_fontweight'] === '400' ? ' selected' : '') + '>Normal</option>' +
        '<option value="700"' + (customDraft[g[0] + '_fontweight'] === '700' ? ' selected' : '') + '>Bold</option>' +
        '</select></div></div>';
    });
    html += '<label>Content alignment<select class="input-element" id="cc_align">' +
      '<option value=""' + (!customDraft.align ? ' selected' : '') + '>Theme default</option>' +
      '<option value="left"' + (customDraft.align === 'left' ? ' selected' : '') + '>Left</option>' +
      '<option value="center"' + (customDraft.align === 'center' ? ' selected' : '') + '>Center</option>' +
      '<option value="right"' + (customDraft.align === 'right' ? ' selected' : '') + '>Right</option>' +
      '</select></label></div>';

    html += '<h3 class="sfc-section-title">Colors &amp; Styles</h3><div class="sfc-color-grid">';
    (customMap.colors || []).forEach(function (c) {
      var v = customDraft[c.key] || '';
      var pv = v && /^#[0-9a-fA-F]{6}$/.test(v) ? v : '#cccccc';
      html += '<div class="sfc-color-item"><span>' + esc(c.label) + '</span><div class="sfc-color-row">' +
        '<label class="sfc-color-swatch" style="background:' + esc(pv) + ';"><input type="color" value="' + esc(pv) + '" data-ccpicker="' + esc(c.key) + '"></label>' +
        '<input type="text" class="input-element sfc-color-text" data-cccolor="' + esc(c.key) + '" value="' + esc(v) + '" placeholder="empty = default"></div></div>';
    });
    html += '</div>';

    html += '<h3 class="sfc-section-title">Border &amp; Spacing</h3><div class="sfc-field-grid">';
    html += '<label>Border width<input type="text" class="input-element" id="cc_border_width" value="' + esc(customDraft.border_width || '') + '" placeholder="1px"></label>';
    html += '<label>Border radius<input type="text" class="input-element" id="cc_border_radius" value="' + esc(customDraft.border_radius || '') + '" placeholder="6px"></label>';
    html += '<label>Form padding<input type="text" class="input-element" id="cc_padding" value="' + esc(customDraft.padding || '') + '" placeholder="30px"></label>';
    html += '<label>Glow size<input type="text" class="input-element" id="cc_glow_size" value="' + esc(customDraft.glow_size || '') + '" placeholder="10"></label>';
    html += '</div>';

    modalLeft.html(html);
    modalLeft.scrollTop(0);
    modalFooter.html(
      '<button type="button" class="essb-ui-btn essb-ui-btn-light" id="cc_cancel">Cancel</button>' +
      '<button type="button" class="essb-ui-btn essb-ui-btn-primary" id="cc_save">Save Form</button>'
    );
    $('#cc_cancel').on('click', closeModal);
    $('#cc_save').on('click', saveCustom);

    bindCustomInputs();
    modalMode = 'custom';
    openModal(customEditing === 'new' ? 'New Form Design' : 'Edit: ' + (customDraft.name || 'Untitled'), 'Custom form');
    requestCustomPreview();
  }

  function collectCustom() {
    if (!customDraft) { return {}; }
    var get = function (id) { var el = document.getElementById(id); return el ? el.value : ''; };
    ['name', 'customlist', 'customtags', 'title', 'text', 'footer', 'name_placeholder', 'email_placeholder',
     'button_placeholder', 'error_message', 'ok_message', 'image', 'image_width', 'image_height',
     'image_padding', 'border_width', 'border_radius', 'padding', 'glow_size'].forEach(function (k) {
      var id = 'cc_' + (k === 'ok_message' ? 'ok_message' : k);
      if (k === 'title') { customDraft.title = get('cc_title'); }
      else if (k === 'text') { customDraft.text = get('cc_text'); }
      else { customDraft[k] = get('cc_' + k); }
    });
    customDraft.image_location = get('cc_image_location');
    customDraft.image_area_width = get('cc_image_area_width');
    customDraft.align = get('cc_align');
    var addName = document.getElementById('cc_addname');
    customDraft.add_name = (addName && addName.checked) ? 'true' : '';
    var same = document.getElementById('cc_sameline');
    customDraft.sameline_fields = (same && same.checked) ? 'true' : '';
    $('[data-cfont]').each(function () { customDraft[$(this).attr('data-cfont')] = $(this).val(); });
    $('[data-cweight]').each(function () { customDraft[$(this).attr('data-cweight')] = $(this).val(); });
    $('[data-cccolor]').each(function () { customDraft[$(this).attr('data-cccolor')] = $(this).val(); });
    return customDraft;
  }

  function bindCustomInputs() {
    // Preview refreshes on change (blur / select / toggle), not while typing.
    modalLeft.off('input change click');
    modalLeft.on('change', 'input, textarea, select', function () {
      if ($(this).attr('data-ccpicker')) {
        var key = $(this).attr('data-ccpicker');
        var txt = modalLeft.find('[data-cccolor="' + key + '"]');
        txt.val($(this).val());
        txt.closest('.sfc-color-item').find('.sfc-color-swatch').css('background', $(this).val());
      }
      if ($(this).attr('data-cccolor') && /^#[0-9a-fA-F]{6}$/.test($(this).val())) {
        var k2 = $(this).attr('data-cccolor');
        modalLeft.find('[data-ccpicker="' + k2 + '"]').val($(this).val());
        $(this).closest('.sfc-color-item').find('.sfc-color-swatch').css('background', $(this).val());
      }
      var loc = $('#cc_image_location').val();
      $('#cc_image_details').css('display', loc ? 'grid' : 'none');
      $('#cc_image_size').css('display', (loc && loc !== 'background') ? 'contents' : 'none');
      requestCustomPreview();
    });
    modalLeft.on('click', '#cc_select_image', function (e) {
      e.preventDefault();
      openMediaFrame(function (url) {
        $('#cc_image').val(url).trigger('change');
      });
    });
  }

  function requestCustomPreview() {
    var values = collectCustom();
    previewStage.html('<div class="sfc-loading">Rendering preview&hellip;</div>');
    $.ajax({
      url: ajaxUrl(),
      method: 'POST',
      dataType: 'json',
      data: {
        action: 'essb_advanced_options',
        essb_advancedoptions_token: advToken(),
        cmd: 'subscribe_preview',
        preview_mode: 'custom',
        values: values
      },
      success: function (resp) {
        var payload = resp && resp.data ? resp.data : (resp || {});
        if (payload.html) {
          previewStage.html(payload.html);
          styleEl.textContent = payload.css || '';
        } else {
          previewStage.html('<div class="sfc-loading">Preview unavailable.</div>');
        }
      },
      error: function () {
        previewStage.html('<div class="sfc-loading">Preview unavailable.</div>');
      }
    });
  }

  function saveCustom() {
    var values = collectCustom();
    if (!values.name || String(values.name).trim() === '') {
      alert('Please enter a form name.');
      return;
    }
    var designId = (customEditing === 'new') ? 'new' : String(customKeys[customEditing] !== undefined ? customKeys[customEditing] : customEditing);
    // advanced-options endpoint expects `advanced_options` array + group
    $.ajax({
      url: ajaxUrl(),
      method: 'POST',
      dataType: 'json',
      data: {
        action: 'essb_advanced_options',
        essb_advancedoptions_token: advToken(),
        cmd: 'save',
        group: 'essb_options_forms',
        advanced_options: $.extend({}, values, { form_design_id: designId })
      },
      success: function () {
        reloadCustoms(function () {
          closeModal();
          renderList();
          sfcToast('Custom form saved.');
        });
      },
      error: function () {
        alert('Save failed. Please try again.');
      }
    });
  }

  function removeCustom(idx) {
    if (!confirm('Remove this form design?')) { return; }
    var realIdx = customKeys[idx] !== undefined ? customKeys[idx] : idx;
    $.ajax({
      url: ajaxUrl(),
      method: 'POST',
      dataType: 'text',
      data: {
        action: 'essb_advanced_options',
        essb_advancedoptions_token: advToken(),
        cmd: 'remove_form_design',
        design: String(realIdx)
      },
      complete: function () {
        customs.splice(idx, 1);
        customKeys.splice(idx, 1);
        renderList();
      }
    });
  }

  function reloadCustoms(done) {
    // Re-read from server-rendered source of truth via page reload data is stale;
    // optimistically update local copy from draft when possible, else refetch is skipped
    // and a settings reload will show the persisted state. We update locally for immediacy.
    if (customEditing === 'new' && customDraft) {
      customs.push($.extend({}, customDraft));
      customKeys.push(customKeys.length ? (Math.max.apply(null, customKeys.map(Number)) + 1) : 0);
    } else if (customEditing !== null && customDraft) {
      customs[customEditing] = $.extend({}, customDraft);
    }
    customDraft = null;
    customEditing = null;
    if (done) { done(); }
  }

  function openMediaFrame(cb) {
    if (typeof wp !== 'undefined' && wp.media) {
      var frame = wp.media({ title: 'Select image', multiple: false, library: { type: 'image' } });
      frame.on('select', function () {
        var att = frame.state().get('selection').first().toJSON();
        if (att && att.url && cb) { cb(att.url); }
      });
      frame.open();
    } else {
      var url = prompt('Enter image URL:', '');
      if (url !== null && cb) { cb(url); }
    }
  }

  // The settings layout wraps this component in a transformed ancestor
  // (.essb-flex-grid), which breaks position:fixed. Move overlay + modal
  // to body so centering is viewport-relative. The hidden #sfc-store
  // stays inside the form, and modal inputs are nameless, so saving
  // is unaffected.
  if (overlay.parent().is('#essb-sfc')) {
    $(document.body).append(overlay).append(modal);
  }

  renderList();
  buildStoreFromPresets();
})(jQuery);
