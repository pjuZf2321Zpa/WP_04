/* =========================================================================
 * Easy Social Share Buttons — multi-select component
 *
 * Replaces the Select2 multi-selects. Renders chips + an inline searchable
 * dropdown and keeps the <group>[<field>][] hidden inputs in sync so the saved
 * option is identical to the previous implementation.
 * ========================================================================= */
(function () {
	'use strict';

	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	function MultiSelect(el) {
		this.el = el;
		this.name = el.getAttribute('data-name') || '';
		this.options = [];
		try { this.options = JSON.parse(el.getAttribute('data-options') || '[]'); } catch (e) { this.options = []; }

		this.control = el.querySelector('.essb-ms-control');
		this.chips = el.querySelector('.essb-ms-chips');
		this.search = el.querySelector('.essb-ms-search');
		this.menu = el.querySelector('.essb-ms-menu');
		this.hidden = el.querySelector('.essb-ms-hidden');
		this.activeIndex = -1;

		this.selected = [];
		var self = this;
		this.hidden.querySelectorAll('input').forEach(function (i) { self.selected.push(i.value); });

		this.render();
		this.bind();
	}

	MultiSelect.prototype.optionByValue = function (val) {
		for (var i = 0; i < this.options.length; i++) {
			if (String(this.options[i].value) === String(val)) return this.options[i];
		}
		return null;
	};

	MultiSelect.prototype.render = function () {
		var self = this;

		this.chips.innerHTML = this.selected.map(function (val) {
			var opt = self.optionByValue(val);
			var dot = opt && opt.color ? '<span class="essb-ms-dot" style="background:' + opt.color + '"></span>' : '';
			var label = opt ? opt.label : val;
			return '<span class="essb-ms-chip" data-value="' + esc(val) + '">' + dot +
				'<span class="essb-ms-chip-label">' + esc(label) + '</span>' +
				'<button type="button" class="essb-ms-remove" data-value="' + esc(val) + '">&times;</button></span>';
		}).join('');

		this.hidden.innerHTML = this.selected.map(function (val) {
			return '<input type="hidden" name="' + esc(self.name) + '[]" value="' + esc(val) + '"/>';
		}).join('');

		this.renderMenu();
	};

	MultiSelect.prototype.renderMenu = function () {
		var self = this;
		var q = (this.search.value || '').toLowerCase();
		var html = '', visible = 0;

		this.options.forEach(function (opt) {
			var hide = q && String(opt.label).toLowerCase().indexOf(q) === -1;
			if (!hide) visible++;
			var isSel = self.selected.indexOf(String(opt.value)) !== -1;
			var dot = opt.color ? '<span class="essb-ms-dot" style="background:' + opt.color + '"></span>' : '';
			html += '<div class="essb-ms-option' + (isSel ? ' selected' : '') +
				(String(opt.value) === '' ? ' essb-ms-all' : '') + (hide ? ' hide' : '') +
				'" data-value="' + esc(opt.value) + '">' +
				dot + '<span class="essb-ms-option-label">' + esc(opt.label) + '</span>' +
				'<span class="essb-ms-check"><svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3.5 8.5l3 3 6-7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>';
		});

		this.menu.innerHTML = html + (visible === 0 ? '<div class="essb-ms-empty">No matches</div>' : '');
		this.activeIndex = -1;
	};

	MultiSelect.prototype.toggle = function (val) {
		var i = this.selected.indexOf(val);
		if (i === -1) this.selected.push(val); else this.selected.splice(i, 1);
		this.render();
	};

	MultiSelect.prototype.remove = function (val) {
		var i = this.selected.indexOf(val);
		if (i !== -1) { this.selected.splice(i, 1); this.render(); }
	};

	MultiSelect.prototype.setValues = function (vals) {
		this.selected = (vals || []).map(function (v) { return String(v); });
		this.render();
	};

	MultiSelect.prototype.open = function () {
		this.control.classList.add('open');
		this.menu.hidden = false;
		this.search.focus();
	};

	MultiSelect.prototype.close = function () {
		this.control.classList.remove('open');
		this.menu.hidden = true;
		this.search.value = '';
		this.renderMenu();
	};

	MultiSelect.prototype.bind = function () {
		var self = this;

		this.control.addEventListener('mousedown', function (e) {
			if (e.target.closest('.essb-ms-remove') || e.target.closest('.essb-ms-menu')) return;
			e.preventDefault();
			self.open();
		});

		this.control.addEventListener('click', function (e) {
			var rm = e.target.closest('.essb-ms-remove');
			if (rm) { e.preventDefault(); self.remove(rm.getAttribute('data-value')); return; }
			var op = e.target.closest('.essb-ms-option');
			if (op) { e.preventDefault(); self.toggle(op.getAttribute('data-value')); self.search.focus(); }
		});

		this.search.addEventListener('input', function () { self.renderMenu(); });

		this.search.addEventListener('keydown', function (e) {
			var opts = self.menu.querySelectorAll('.essb-ms-option:not(.hide)');
			if (e.key === 'Enter') {
				e.preventDefault();
				if (self.activeIndex >= 0 && opts[self.activeIndex]) self.toggle(opts[self.activeIndex].getAttribute('data-value'));
				else if (opts.length) self.toggle(opts[0].getAttribute('data-value'));
			} else if (e.key === 'Backspace' && self.search.value === '' && self.selected.length) {
				self.remove(self.selected[self.selected.length - 1]);
			} else if (e.key === 'Escape') {
				self.close();
			} else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
				e.preventDefault();
				if (!opts.length) return;
				self.activeIndex += (e.key === 'ArrowDown' ? 1 : -1);
				if (self.activeIndex < 0) self.activeIndex = opts.length - 1;
				if (self.activeIndex >= opts.length) self.activeIndex = 0;
				for (var i = 0; i < opts.length; i++) opts[i].classList.toggle('active', i === self.activeIndex);
			}
		});

		document.addEventListener('mousedown', function (e) {
			if (!self.control.contains(e.target)) self.close();
		});
	};

	function init() {
		var els = document.querySelectorAll('.essb-multiselect:not([data-essb-ms-init])');
		for (var i = 0; i < els.length; i++) {
			els[i].setAttribute('data-essb-ms-init', '1');
			els[i].essbMultiSelect = new MultiSelect(els[i]);
		}
	}

	if (typeof jQuery !== 'undefined') {
		jQuery(document).ready(init);
	} else if (document.readyState !== 'loading') {
		init();
	} else {
		document.addEventListener('DOMContentLoaded', init);
	}

	// Advanced options (and other UI) inject fields dynamically — auto-init them.
	if (typeof MutationObserver !== 'undefined' && document.body) {
		new MutationObserver(function (mutations) {
			for (var i = 0; i < mutations.length; i++) {
				var added = mutations[i].addedNodes;
				for (var j = 0; j < added.length; j++) {
					var n = added[j];
					if (n.nodeType === 1 && (n.classList.contains('essb-multiselect') || (n.querySelector && n.querySelector('.essb-multiselect')))) {
						init();
						return;
					}
				}
			}
		}).observe(document.body, { childList: true, subtree: true });
	}

	window.essbMultiSelectInit = init;
})();
