(function () {
	'use strict';

	var root = document.getElementById('sbcWrap');
	if (!root) return;

	var networks = (window.SBC_NETWORKS || []).map(function (n) { return n; });
	var committed = Object.assign({}, window.SBC_COMMITTED || {});
	var values = Object.assign({}, committed);

	function adminSetting(key, sub) {
		try {
			if (window.essbAdminSettings && window.essbAdminSettings[key]) {
				if (sub) return window.essbAdminSettings[key][sub];
				return window.essbAdminSettings[key];
			}
		} catch (e) {}
		return null;
	}
	function brandColor(key) {
		var c = adminSetting('network_colors', key);
		if (c) return c;
		var n = networks.filter(function (x) { return x.key === key; })[0];
		return (n && n.brand) ? n.brand : '#9ca3af';
	}
	function networkIcon(key) {
		var svg = adminSetting('svg', key);
		if (svg) return svg;
		var n = networks.filter(function (x) { return x.key === key; })[0];
		return n ? (n.name.charAt(0).toUpperCase()) : '?';
	}
	function isValidHex(v) { return /^#[0-9a-fA-F]{6}$/.test(v); }
	function normalizeHex(v) {
		v = (v || '').trim();
		if (v && v.charAt(0) !== '#') v = '#' + v;
		return v;
	}
	function get(key) { return values[key] || ''; }
	function set(key, value) {
		values[key] = (value === undefined || value === null) ? '' : value;
		renderStaged();
		updateChangedCount();
	}
	function kBg(k) { return 'customizer_' + k + '_bgcolor'; }
	function kTxt(k) { return 'customizer_' + k + '_textcolor'; }
	function kHovBg(k) { return 'customizer_' + k + '_hovercolor'; }
	function kHovTxt(k) { return 'customizer_' + k + '_hovertextcolor'; }

	function updateColorButton(key, value) {
		var btns = document.querySelectorAll('.sbc-color-btn[data-key="' + key + '"]');
		btns.forEach(function (btn) { btn.style.background = value || '#f1f1f4'; });
	}
	function isGlobalColorKey(key) {
		return key === 'customizer_bgcolor' || key === 'customizer_textcolor' || key === 'customizer_hovercolor' || key === 'customizer_hovertextcolor';
	}
	function bindColorPair(colorInput, hexInput, key) {
		colorInput.addEventListener('input', function () {
			hexInput.value = colorInput.value;
			set(key, colorInput.value);
			updateColorButton(key, colorInput.value);
			refreshAllCards();
			if (isGlobalColorKey(key)) renderGlobalPreview();
		});
		hexInput.addEventListener('input', function () {
			var v = normalizeHex(hexInput.value);
			if (isValidHex(v)) {
				colorInput.value = v;
				set(key, v);
				updateColorButton(key, v);
				refreshAllCards();
				if (isGlobalColorKey(key)) renderGlobalPreview();
			} else if (hexInput.value.trim() === '') {
				set(key, '');
				updateColorButton(key, '');
				refreshAllCards();
				if (isGlobalColorKey(key)) renderGlobalPreview();
			}
		});
		hexInput.addEventListener('blur', function () {
			var v = get(key);
			hexInput.value = v;
			if (v && isValidHex(v)) colorInput.value = v;
		});
	}
	function syncPair(key) {
		var colorInputs = document.querySelectorAll('.sbc-color[data-key="' + key + '"]');
		var hexInputs = document.querySelectorAll('.sbc-hex[data-key="' + key + '"]');
		colorInputs.forEach(function (ci) {
			var v = get(key);
			if (v && isValidHex(v)) ci.value = v;
		});
		hexInputs.forEach(function (hi) {
			hi.value = get(key);
		});
		updateColorButton(key, get(key));
	}

	function renderGrid() {
		var grid = root.querySelector('#sbcGrid');
		if (!grid) return;
		grid.innerHTML = '';
		var q = (root.querySelector('#sbcSearch').value || '').toLowerCase();
		var shown = 0;
		networks.forEach(function (n) {
			if (q && n.name.toLowerCase().indexOf(q) === -1 && n.key.toLowerCase().indexOf(q) === -1) return;
			shown++;
			var card = document.createElement('div');
			card.className = 'sbc-net-card';
			card.setAttribute('data-key', n.key);
			var bgKey = kBg(n.key), txtKey = kTxt(n.key), hbgKey = kHovBg(n.key), htxtKey = kHovTxt(n.key);
			var brand = brandColor(n.key);
			var icon = (n.key === 'twitter' && window.ESSB_TWITTER_X_ICON) ? window.ESSB_TWITTER_X_ICON : networkIcon(n.key);
			var isSvg = icon && icon.indexOf('<svg') !== -1;
			card.innerHTML =
				'<div class="sbc-net-preview">' +
					'<span class="sbc-net-icon">' + (isSvg ? icon : escapeHtml(String(icon))) + '</span>' +
					'<span class="sbc-net-name">' + escapeHtml(n.name) + '</span>' +
				'</div>' +
				'<div class="sbc-net-fields">' +
					row(bgKey, 'Bg') + row(txtKey, 'Text') + row(hbgKey, 'Hover bg') + row(htxtKey, 'Hover txt') +
				'</div>' +
				'<div class="sbc-net-actions">' +
					'<button type="button" class="essb-ui-btn essb-ui-btn-light essb-ui-btn-xs sbc-reset" data-reset="' + n.key + '">Reset</button>' +
				'</div>';
			grid.appendChild(card);

			// set preview bg
			var preview = card.querySelector('.sbc-net-preview');
			var effectiveBg = get(bgKey) || get('customizer_bgcolor') || brand;
			var effectiveTxt = get(txtKey) || get('customizer_textcolor') || '#ffffff';
			if (preview) {
				preview.style.background = effectiveBg;
				preview.style.color = effectiveTxt;
				var iconEl = preview.querySelector('.sbc-net-icon');
				if (iconEl) {
					iconEl.style.color = effectiveTxt;
					var svgEl = iconEl.querySelector('svg');
					if (svgEl) svgEl.style.fill = effectiveTxt;
				}
				var nameEl = preview.querySelector('.sbc-net-name');
				if (nameEl) nameEl.style.color = effectiveTxt;
			}

			[bgKey, txtKey, hbgKey, htxtKey].forEach(function (key) {
				var ci = card.querySelector('.sbc-color[data-key="' + key + '"]');
				var hi = card.querySelector('.sbc-hex[data-key="' + key + '"]');
				if (ci && hi) bindColorPair(ci, hi, key);
				syncPair(key);
			});
			refreshCard(n.key);

			card.querySelectorAll('.sbc-reset').forEach(function (btn) {
				btn.addEventListener('click', function () {
					set(bgKey, '');
					set(txtKey, '');
					set(hbgKey, '');
					set(htxtKey, '');
					syncPair(bgKey); syncPair(txtKey); syncPair(hbgKey); syncPair(htxtKey);
					refreshCard(n.key);
				});
			});
		});

		var count = root.querySelector('#sbcCount');
		if (count) count.textContent = shown + ' of ' + networks.length;
	}

	function row(key, label) {
		var v = get(key);
		return '<div class="sbc-net-row">' +
			'<label>' + label + '</label>' +
			'<div class="essb-cd-color" data-key="' + key + '">' +
				'<label class="sbc-color-btn" data-key="' + key + '"><input type="color" class="sbc-color input-element" data-key="' + key + '" value="' + (v || '#9ca3af') + '"></label>' +
				'<input type="text" name="essb_options[' + key + ']" class="essb-cd-input mono sbc-hex input-element input-colorselector" data-key="' + key + '" maxlength="7" placeholder="#rrggbb" value="' + escapeAttr(v) + '">' +
			'</div>' +
		'</div>';
	}

	function refreshCard(key) {
		var card = root.querySelector('.sbc-net-card[data-key="' + key + '"]');
		if (!card) return;
		var bgKey = kBg(key), txtKey = kTxt(key), hbgKey = kHovBg(key), htxtKey = kHovTxt(key);
		var brand = brandColor(key);
		var effectiveBg = get(bgKey) || get('customizer_bgcolor') || brand;
		var effectiveTxt = get(txtKey) || get('customizer_textcolor') || '#ffffff';
		var effectiveHovBg = get(hbgKey) || get('customizer_hovercolor') || effectiveBg;
		var effectiveHovTxt = get(htxtKey) || get('customizer_hovertextcolor') || effectiveTxt;
		var preview = card.querySelector('.sbc-net-preview');
		if (preview) {
			preview.style.background = effectiveBg;
			preview.style.color = effectiveTxt;
			var iconEl = preview.querySelector('.sbc-net-icon');
			if (iconEl) {
				iconEl.style.color = effectiveTxt;
				var svgEl = iconEl.querySelector('svg');
				if (svgEl) svgEl.style.fill = effectiveTxt;
			}
			var nameEl = preview.querySelector('.sbc-net-name');
			if (nameEl) nameEl.style.color = effectiveTxt;
			preview.onmouseenter = function () {
				preview.style.background = effectiveHovBg;
				preview.style.color = effectiveHovTxt;
				if (iconEl) {
					iconEl.style.color = effectiveHovTxt;
					var s = iconEl.querySelector('svg');
					if (s) s.style.fill = effectiveHovTxt;
				}
				if (nameEl) nameEl.style.color = effectiveHovTxt;
			};
			preview.onmouseleave = function () {
				preview.style.background = effectiveBg;
				preview.style.color = effectiveTxt;
				if (iconEl) {
					iconEl.style.color = effectiveTxt;
					var s = iconEl.querySelector('svg');
					if (s) s.style.fill = effectiveTxt;
				}
				if (nameEl) nameEl.style.color = effectiveTxt;
			};
		}
		var changed = (get(bgKey) || get(txtKey) || get(hbgKey) || get(htxtKey)) ? true : false;
		if (changed) card.classList.add('is-changed'); else card.classList.remove('is-changed');
	}

	function refreshAllCards() {
		networks.forEach(function (n) { refreshCard(n.key); });
		renderPreviewStage();
	}

	function updateChangedCount() {
		var nets = 0;
		networks.forEach(function (n) {
			if (get(kBg(n.key)) || get(kTxt(n.key)) || get(kHovBg(n.key)) || get(kHovTxt(n.key))) nets++;
		});
		var el = root.querySelector('#sbcChanged');
		if (el) el.textContent = nets + ' of ' + networks.length;
	}

	function bindGlobalColorInputs() {
		document.querySelectorAll('.sbc-color').forEach(function (ci) {
			var key = ci.getAttribute('data-key');
			var hi = document.querySelector('.sbc-hex[data-key="' + key + '"]');
			if (hi && !ci._bound) {
				ci._bound = true;
				bindColorPair(ci, hi, key);
			}
		});
		var seen = {};
		document.querySelectorAll('.sbc-hex').forEach(function (hi) {
			var key = hi.getAttribute('data-key');
			if (seen[key]) return;
			seen[key] = true;
			syncPair(key);
		});
	}

	function bindTextInputs() {
		root.querySelectorAll('.sbc-text').forEach(function (ti) {
			var key = ti.getAttribute('data-key');
			ti.value = get(key);
			ti.addEventListener('input', function () {
				set(key, ti.value);
			});
		});
	}

	function bindSwitches() {
		root.querySelectorAll('input[type="checkbox"][data-key]').forEach(function (cb) {
			var key = cb.getAttribute('data-key');
			cb.checked = !!get(key);
			cb.addEventListener('change', function () {
				set(key, cb.checked ? '1' : '');
			});
		});
	}

	function bindPanels() {
		root.querySelectorAll('.sbc-panel-head').forEach(function (head) {
			head.addEventListener('click', function (e) {
				if (e.target && e.target.closest && e.target.closest('.essb-ui-switch')) return;
				var panel = head.parentElement;
				panel.classList.toggle('collapsed');
			});
		});
	}

	function bindSearch() {
		var s = root.querySelector('#sbcSearch');
		if (!s) return;
		s.addEventListener('input', function () { renderGrid(); });
	}

	function bindResetAll() {
		var b = root.querySelector('#sbcResetAll');
		if (!b) return;
		b.addEventListener('click', function () {
			networks.forEach(function (n) {
				set(kBg(n.key), '');
				set(kTxt(n.key), '');
				set(kHovBg(n.key), '');
				set(kHovTxt(n.key), '');
			});
			renderGrid();
		});
	}

	function globalVal(id) {
		var el = document.getElementById('essb_options_' + id);
		return el ? (el.value || '') : '';
	}
	function globalChecked(id) {
		var el = document.getElementById('essb_options_' + id);
		return el ? !!el.checked : false;
	}
	function numVal(v, def) {
		v = (v || '').trim();
		if (v === '') return def;
		if (/^\d+$/.test(v)) return v + 'px';
		return v;
	}
	function renderGlobalPreview() {
		var container = document.getElementById('essbSbcGlobalPreview');
		if (!container) return;
		var bg = globalVal('customizer_bgcolor') || '#1b84ff';
		var tc = globalVal('customizer_textcolor') || '#ffffff';
		var hbg = globalVal('customizer_hovercolor') || bg;
		var htc = globalVal('customizer_hovertextcolor') || tc;
		var iconSize = (globalVal('customizer_iconsize') || '18').replace('px', '');
		var nameSize = globalVal('customizer_namesize') || '';
		if (nameSize && !/[a-z%]/i.test(nameSize)) nameSize = nameSize + 'px';
		var bold = globalChecked('customizer_namebold');
		var upper = globalChecked('customizer_nameupper');
		var iconBlock = globalVal('customizer_icon_block_size') || '';
		var btns = container.querySelectorAll('.essb-sbc-gp-btn');
		btns.forEach(function (btn) {
			btn.style.background = bg;
			btn.style.color = tc;
			var net = btn.getAttribute('data-net');
			var icon = (net === 'twitter' && window.ESSB_TWITTER_X_ICON) ? window.ESSB_TWITTER_X_ICON : networkIcon(net);
			var iconEl = btn.querySelector('.essb-sbc-gp-icon');
			if (iconEl) {
				if (icon && icon.indexOf('<svg') !== -1) {
					iconEl.innerHTML = icon;
					var s = iconEl.querySelector('svg');
					if (s) {
						s.style.fill = tc;
						s.style.width = (iconSize || 18) + 'px';
						s.style.height = (iconSize || 18) + 'px';
					}
				} else {
					iconEl.textContent = icon;
				}
				if (iconBlock) {
					iconEl.style.width = iconBlock + 'px';
					iconEl.style.height = iconBlock + 'px';
				} else {
					iconEl.style.width = '';
					iconEl.style.height = '';
				}
			}
			var nameSpan = btn.querySelector('.essb-sbc-gp-name');
			// name is direct text node; wrap handling below
			btn.style.fontSize = nameSize || '';
			btn.style.fontWeight = bold ? 'bold' : '';
			btn.style.textTransform = upper ? 'uppercase' : '';
			btn.onmouseenter = function () {
				btn.style.background = hbg;
				btn.style.color = htc;
				if (iconEl) {
					var s = iconEl.querySelector('svg');
					if (s) s.style.fill = htc;
				}
			};
			btn.onmouseleave = function () {
				btn.style.background = bg;
				btn.style.color = tc;
				if (iconEl) {
					var s = iconEl.querySelector('svg');
					if (s) s.style.fill = tc;
				}
			};
		});
	}
	function bindGlobalPreview() {
		var ids = ['customizer_bgcolor','customizer_textcolor','customizer_hovercolor','customizer_hovertextcolor','customizer_iconsize','customizer_icon_block_size','customizer_namesize'];
		ids.forEach(function (id) {
			var el = document.getElementById('essb_options_' + id);
			if (!el) return;
			var handler = function () { renderGlobalPreview(); };
			el.addEventListener('change', handler);
			el.addEventListener('input', handler);
		});
		['customizer_namebold','customizer_nameupper'].forEach(function (id) {
			var el = document.getElementById('essb_options_' + id);
			if (!el) return;
			el.addEventListener('change', function () { renderGlobalPreview(); });
		});
		// wp-color-picker triggers change on the original input; also listen on the widget
		renderGlobalPreview();
	}

	function renderPreviewStage() {
		var stage = root.querySelector('#sbcPreviewStage');
		var meta = root.querySelector('#sbcPreviewMeta');
		if (!stage) return;
		var pick = networks[0];
		networks.forEach(function (n) {
			if (get(kBg(n.key)) || get(kTxt(n.key)) || get(kHovBg(n.key)) || get(kHovTxt(n.key))) {
				if (pick === networks[0]) pick = n;
			}
		});
		var brand = brandColor(pick.key);
		var bg = get(kBg(pick.key)) || get('customizer_bgcolor') || brand;
		var tc = get(kTxt(pick.key)) || get('customizer_textcolor') || '#ffffff';
		var hbg = get(kHovBg(pick.key)) || get('customizer_hovercolor') || bg;
		var htc = get(kHovTxt(pick.key)) || get('customizer_hovertextcolor') || tc;
		stage.innerHTML = '';
		var btn = document.createElement('a');
		btn.className = 'sbc-preview-stage-btn';
		btn.href = '#';
		btn.style.background = bg;
		btn.style.color = tc;
		var icon = (pick.key === 'twitter' && window.ESSB_TWITTER_X_ICON) ? window.ESSB_TWITTER_X_ICON : networkIcon(pick.key);
		if (icon && icon.indexOf('<svg') !== -1) {
			btn.innerHTML = '<span class="sbc-preview-icon">' + icon + '</span>' + escapeHtml(pick.name);
			var ic = btn.querySelector('.sbc-preview-icon svg');
			if (ic) ic.style.fill = tc;
		} else {
			btn.innerHTML = '<span class="sbc-preview-icon">' + escapeHtml(String(icon)) + '</span>' + escapeHtml(pick.name);
		}
		btn.onmouseenter = function () {
			btn.style.background = hbg;
			btn.style.color = htc;
		};
		btn.onmouseleave = function () {
			btn.style.background = bg;
			btn.style.color = tc;
		};
		stage.appendChild(btn);
		if (meta) meta.textContent = pick.name + ' — normal state (hover with mouse)';
	}

	function renderStaged() {
		var pre = root.querySelector('#sbcStaged');
		if (!pre) return;
		var lines = [];
		var scalarKeys = [
			'customizer_is_active',
			'customizer_totalbgcolor','customizer_totalnobgcolor','customizer_totalcolor',
			'customizer_totalfontsize','customizer_totalfontsize_after','customizer_totalfontsize_beforeafter',
			'customizer_bgcolor','customizer_textcolor','customizer_hovercolor','customizer_hovertextcolor',
			'customizer_remove_bg_hover_effects',
			'customizer_iconsize','customizer_icon_block_size','customizer_namesize','customizer_namebold','customizer_nameupper',
			'customizer_network_is_active'
		];
		scalarKeys.forEach(function (k) {
			lines.push('<input name="essb_options[' + k + ']" value="' + escapeAttr(get(k)) + '">');
		});
		networks.forEach(function (n) {
			[kBg(n.key), kTxt(n.key), kHovBg(n.key), kHovTxt(n.key)].forEach(function (k) {
				lines.push('<input name="essb_options[' + k + ']" value="' + escapeAttr(get(k)) + '">');
			});
		});
		pre.textContent = lines.join('\n');
	}

	function escapeHtml(s) {
		return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
	}
	function escapeAttr(s) {
		return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
	}

	function toggleStaged() {
		var wrap = root.querySelector('#sbcStagedWrap');
		var btn = root.querySelector('#sbcToggleStaged');
		if (!wrap || !btn) return;
		btn.addEventListener('click', function () {
			if (wrap.style.display === 'none') { wrap.style.display = ''; btn.textContent = 'Hide'; }
			else { wrap.style.display = 'none'; btn.textContent = 'Show'; }
		});
	}

	function init() {
		bindPanels();
		bindSwitches();
		bindGlobalColorInputs();
		bindTextInputs();
		bindSearch();
		bindResetAll();
		bindGlobalPreview();
		toggleStaged();
		renderGrid();
		updateChangedCount();
		renderStaged();
		renderPreviewStage();
		var en = root.querySelector('#sbcEnable');
		var body = root.querySelector('#sbcBody');
		if (en && body && !en.checked) body.classList.add('sbc-disabled');
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();