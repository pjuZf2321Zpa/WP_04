(function () {
	'use strict';

	var committed = Object.assign({}, window.CCT_COMMITTED || {});

	// Working state
	var colorValues = {};   // key -> hex (includes virtual border_color keys)
	var splitValues = {};   // "split:part" -> string
	var simpleValues = {};  // original key -> string

	var enabled = true;

	// ---------- helpers ----------
	function isValidHex(v) {
		return /^#[0-9a-fA-F]{6}$/.test(v);
	}
	function normalizeHex(v) {
		v = (v || '').trim();
		if (v && v.charAt(0) !== '#') v = '#' + v;
		return v;
	}
	function esc(s) { return String(s).replace(/"/g, '&quot;'); }

	// CSS shorthand expanders
	function expandRadius(tokens) {
		if (tokens.length === 1) return [tokens[0], tokens[0], tokens[0], tokens[0]];
		if (tokens.length === 2) return [tokens[0], tokens[1], tokens[0], tokens[1]];
		if (tokens.length === 3) return [tokens[0], tokens[1], tokens[2], tokens[1]];
		return tokens.slice(0, 4);
	}
	function expandPadding(tokens) {
		if (tokens.length === 1) return [tokens[0], tokens[0], tokens[0], tokens[0]];
		if (tokens.length === 2) return [tokens[0], tokens[1], tokens[0], tokens[1]];
		if (tokens.length === 3) return [tokens[0], tokens[1], tokens[2], tokens[1]];
		return tokens.slice(0, 4);
	}
	function parseBorder(str) {
		var t = (str || '').trim().split(/\s+/).filter(Boolean);
		return { size: t[0] || '', style: t[1] || '', color: t[2] || '' };
	}

	// ---------- init state from committed ----------
	(function initFromCommitted() {
		var colorKeys = ['customize_cct_bg', 'customize_cct_bg_hover', 'customize_cct_color', 'customize_cct_color_hover'];
		colorKeys.forEach(function (k) { colorValues[k] = committed[k] || ''; });

		// border
		var b = parseBorder(committed.customizer_cct_border);
		splitValues['border:size'] = b.size;
		splitValues['border:style'] = b.style;
		colorValues['border_color'] = b.color;

		// border hover
		var bh = parseBorder(committed.customizer_cct_border_hover);
		splitValues['border_hover:size'] = bh.size;
		splitValues['border_hover:style'] = bh.style;
		colorValues['border_hover_color'] = bh.color;

		// radius
		var rt = (committed.customizer_cct_border_radius || '').trim().split(/\s+/).filter(Boolean);
		var re = expandRadius(rt.length ? rt : []);
		var rparts = ['tl', 'tr', 'br', 'bl'];
		rparts.forEach(function (p, i) { splitValues['radius:' + p] = (re[i] || (rt.length ? rt[0] : '')) || ''; });
		if (!rt.length) rparts.forEach(function (p) { splitValues['radius:' + p] = ''; });

		// padding
		var pt = (committed.customizer_cct_padding || '').trim().split(/\s+/).filter(Boolean);
		var pe = expandPadding(pt.length ? pt : []);
		var pparts = ['t', 'r', 'b', 'l'];
		pparts.forEach(function (p, i) { splitValues['padding:' + p] = (pe[i] || (pt.length ? pt[0] : '')) || ''; });
		if (!pt.length) pparts.forEach(function (p) { splitValues['padding:' + p] = ''; });

		simpleValues['customizer_cct_align'] = committed.customizer_cct_align || '';
		simpleValues['customizer_cct_fontsize'] = committed.customizer_cct_fontsize || '';
	})();

	// ---------- accessors ----------
	function getColor(key) { return colorValues[key] || ''; }
	function setColor(key, value) { colorValues[key] = value || ''; }
	function getSplit(split, part) { return splitValues[split + ':' + part] || ''; }
	function setSplit(split, part, value) { splitValues[split + ':' + part] = value || ''; }
	function getSimple(key) { return simpleValues[key] || ''; }
	function setSimple(key, value) { simpleValues[key] = value || ''; }

	function compileBorder(splitName) {
		var size = getSplit(splitName, 'size');
		var style = getSplit(splitName, 'style');
		var colorKey = (splitName === 'border') ? 'border_color' : 'border_hover_color';
		var color = getColor(colorKey);
		return [size, style, color].filter(Boolean).join(' ').trim();
	}
	function compileRadius() {
		return ['tl', 'tr', 'br', 'bl'].map(function (p) { return getSplit('radius', p); }).join(' ').trim();
	}
	function compilePadding() {
		return ['t', 'r', 'b', 'l'].map(function (p) { return getSplit('padding', p); }).join(' ').trim();
	}

	// ---------- color button update ----------
	function updateColorButton(key, value) {
		var btn = document.querySelector('.cct-color-btn[data-key="' + key + '"]');
		if (btn) btn.style.background = value || '#f1f1f4';
	}

	// ---------- color <-> hex binding ----------
	function bindColorPair(colorInput, hexInput, key) {
		colorInput.addEventListener('input', function () {
			hexInput.value = colorInput.value;
			setColor(key, colorInput.value);
			updateColorButton(key, colorInput.value);
			renderAll();
		});
		hexInput.addEventListener('input', function () {
			var v = normalizeHex(hexInput.value);
			if (isValidHex(v)) {
				colorInput.value = v;
				setColor(key, v);
				updateColorButton(key, v);
				renderAll();
			} else if (hexInput.value.trim() === '') {
				setColor(key, '');
				updateColorButton(key, '');
				renderAll();
			}
		});
		hexInput.addEventListener('blur', function () {
			var v = getColor(key);
			hexInput.value = v;
			if (v) colorInput.value = v;
		});
	}

	function syncColorPair(key) {
		var colorInput = document.querySelector('.cct-color-input[data-key="' + key + '"]');
		var hexInput = document.querySelector('.cct-hex[data-key="' + key + '"]');
		if (!colorInput || !hexInput) return;
		var v = getColor(key);
		hexInput.value = v;
		colorInput.value = (v && isValidHex(v)) ? v : '#9ca3af';
		updateColorButton(key, v);
	}

	// ---------- apply preview ----------
	function applyPreview(forceHover) {
		var box = document.getElementById('cctPreviewBox');
		var inline = document.getElementById('cctPreviewInlineBox');
		var hover = !!forceHover;

		var bg = getColor('customize_cct_bg');
		var bgH = getColor('customize_cct_bg_hover');
		var col = getColor('customize_cct_color');
		var colH = getColor('customize_cct_color_hover');

		var border = compileBorder('border');
		var borderH = compileBorder('border_hover');
		var radius = compileRadius();
		var padding = compilePadding();
		var align = getSimple('customizer_cct_align');
		var fontsize = getSimple('customizer_cct_fontsize');

		var useHover = hover;
		var bgEff = useHover ? (bgH || bg) : bg;
		var colEff = useHover ? (colH || col) : col;
		var borderEff = useHover ? (borderH || border) : border;

		// block
		box.style.backgroundColor = bgEff || '';
		box.style.color = colEff || '';
		box.style.border = borderEff || '';
		// If no border color is specified for hover, fall back to the hover background color
		if (useHover) {
			var borderHoverColor = getColor('border_hover_color');
			if (borderHoverColor === '' && bgH !== '') {
				box.style.borderColor = bgH;
			}
		}
		box.style.borderRadius = radius || '';
		box.style.padding = padding || '';
		box.style.textAlign = align || '';
		var quote = box.querySelector('.essb-ctt-quote');
		if (quote) quote.style.fontSize = fontsize || '';

		// inline uses border-bottom for border
		inline.style.backgroundColor = bgEff || '';
		inline.style.color = colEff || '';
		if (borderEff) inline.style.borderBottom = borderEff; else inline.style.borderBottom = '';
		if (useHover) {
			var borderHoverColor = getColor('border_hover_color');
			if (borderHoverColor === '' && bgH !== '') {
				inline.style.borderBottomColor = bgH;
			}
		}
		inline.style.borderRadius = radius || '';
		// inline padding default small; only apply if provided? keep padding for block only
		if (align) inline.style.textAlign = align;
	}

	// ---------- hidden compiled inputs ----------
	function setHiddenValue(id, value) {
		var el = document.getElementById(id);
		if (el) el.value = value || '';
	}
	function updateHiddenInputs() {
		setHiddenValue('cct_hidden_customizer_cct_border', compileBorder('border'));
		setHiddenValue('cct_hidden_customizer_cct_border_hover', compileBorder('border_hover'));
		setHiddenValue('cct_hidden_customizer_cct_border_radius', compileRadius());
		setHiddenValue('cct_hidden_customizer_cct_padding', compilePadding());
	}

	// ---------- changed count ----------
	function updateChangedCount() {
		var badge = document.getElementById('cctChanged');
		if (!badge) return;
		var count = 0;
		// color keys
		['customize_cct_bg', 'customize_cct_bg_hover', 'customize_cct_color', 'customize_cct_color_hover'].forEach(function (k) {
			if ((getColor(k) || '') !== (committed[k] || '')) count++;
		});
		// compiled keys
		var compiledMap = {
			customizer_cct_border: compileBorder('border'),
			customizer_cct_border_hover: compileBorder('border_hover'),
			customizer_cct_border_radius: compileRadius(),
			customizer_cct_padding: compilePadding(),
			customizer_cct_align: getSimple('customizer_cct_align'),
			customizer_cct_fontsize: getSimple('customizer_cct_fontsize')
		};
		Object.keys(compiledMap).forEach(function (k) {
			if ((compiledMap[k] || '') !== (committed[k] || '')) count++;
		});
		badge.textContent = count + ' changed';
	}

	function syncSplitInputs() {
		document.querySelectorAll('[data-split]').forEach(function (el) {
			var split = el.getAttribute('data-split');
			var part = el.getAttribute('data-part');
			el.value = getSplit(split, part);
		});
	}

	function renderAll() {
		syncSplitInputs();
		// sync "all" inputs with current individual values
		Object.keys(ALL_PARTS).forEach(function (group) {
			var parts = ALL_PARTS[group];
			var vals = parts.map(function (p) { return getSplit(group, p); });
			var allSame = vals.length > 0 && vals.every(function (v) { return v === vals[0]; });
			var el = document.querySelector('[data-all="' + group + '"]');
			if (el) el.value = allSame ? (vals[0] || '') : '';
		});
		updateHiddenInputs();
		applyPreview();
		updateChangedCount();
	}

	// ---------- bind split inputs ----------
	function bindSplitInputs() {
		document.querySelectorAll('[data-split]').forEach(function (el) {
			var split = el.getAttribute('data-split');
			var part = el.getAttribute('data-part');
			var key = split + ':' + part;
			// set initial
			el.value = getSplit(split, part);
			var handler = function () {
				setSplit(split, part, el.value);
				renderAll();
			};
			el.addEventListener('input', handler);
			el.addEventListener('change', handler);
		});
	}

	// ---------- bind "all" inputs ----------
	var ALL_PARTS = {
		radius: ['tl', 'tr', 'br', 'bl'],
		padding: ['t', 'r', 'b', 'l']
	};
	function bindAllInputs() {
		document.querySelectorAll('[data-all]').forEach(function (el) {
			var group = el.getAttribute('data-all');
			var parts = ALL_PARTS[group] || [];
			el.addEventListener('input', function () {
				parts.forEach(function (p) { setSplit(group, p, el.value); });
				renderAll();
			});
		});
	}

	// ---------- bind simple fields ----------
	function bindSimpleFields() {
		document.querySelectorAll('[data-key="customizer_cct_align"]').forEach(function (el) {
			el.value = getSimple('customizer_cct_align');
			el.addEventListener('change', function () {
				setSimple('customizer_cct_align', el.value);
				renderAll();
			});
		});
		document.querySelectorAll('[data-key="customizer_cct_fontsize"]').forEach(function (el) {
			el.value = getSimple('customizer_cct_fontsize');
			el.addEventListener('input', function () {
				setSimple('customizer_cct_fontsize', el.value);
				renderAll();
			});
		});
	}

	// ---------- enable switch ----------
	function bindEnable() {
		var cb = document.getElementById('cctEnable');
		var body = document.getElementById('cctBody');
		if (!cb || !body) return;
		cb.addEventListener('change', function () {
			enabled = cb.checked;
			if (enabled) body.classList.remove('cct-disabled'); else body.classList.add('cct-disabled');
		});
	}

	// ---------- staged toggle ----------
	// ---------- init ----------
	function init() {
		if (!document.getElementById('cctWrap')) return;
		// sync color inputs initial
		['customize_cct_bg', 'customize_cct_bg_hover', 'customize_cct_color', 'customize_cct_color_hover', 'border_color', 'border_hover_color'].forEach(function (k) {
			syncColorPair(k);
			// bind
			var colorInput = document.querySelector('.cct-color-input[data-key="' + k + '"]');
			var hexInput = document.querySelector('.cct-hex[data-key="' + k + '"]');
			if (colorInput && hexInput) bindColorPair(colorInput, hexInput, k);
		});

		bindSplitInputs();
		bindSimpleFields();
		bindAllInputs();
		bindEnable();

		// hover preview on mouse interaction
		var box = document.getElementById('cctPreviewBox');
		var inline = document.getElementById('cctPreviewInlineBox');
		if (box) {
			box.addEventListener('mouseenter', function () { applyPreview(true); });
			box.addEventListener('mouseleave', function () { applyPreview(false); });
		}
		if (inline) {
			inline.addEventListener('mouseenter', function () { applyPreview(true); });
			inline.addEventListener('mouseleave', function () { applyPreview(false); });
		}

		renderAll();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();