(function () {
	'use strict';

	var previewKeys = window.MT_PREVIEW_NETWORKS || [];
	var adminSettings = window.essbAdminSettings || {};
	var allNetworks = adminSettings.networks || {};
	var networkColors = adminSettings.network_colors || {};
	var networkSvgs = adminSettings.svg || {};

	// ---------- helpers ----------
	function isValidHex(v) { return /^#[0-9a-fA-F]{6}$/.test(v); }
	function normalizeHex(v) {
		v = (v || '').trim();
		if (v && v.charAt(0) !== '#') v = '#' + v;
		return v;
	}
	function esc(s) { return String(s).replace(/"/g, '&quot;'); }
	function escapeHtml(s) {
		return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
	}
	function num(v, def) { v = (v || '').trim(); return v === '' ? def : v; }

	function adjustBrightness(hex, steps) {
		steps = Math.max(-255, Math.min(255, steps));
		hex = String(hex || '').replace('#', '');
		if (hex.length === 3) {
			hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
		}
		var parts = hex.match(/.{2}/g) || [];
		var out = '#';
		parts.forEach(function (part) {
			var c = Math.max(0, Math.min(255, parseInt(part, 16) + steps));
			out += (c < 16 ? '0' : '') + c.toString(16);
		});
		return out;
	}
	function lightOrDark(color) {
		var hex = String(color || '').replace('#', '');
		var r = parseInt(hex.substr(0, 2), 16);
		var g = parseInt(hex.substr(2, 2), 16);
		var b = parseInt(hex.substr(4, 2), 16);
		var brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
		return brightness > 155 ? -30 : 30;
	}

	// ---------- DOM accessors (the real form inputs are the source of truth) ----------
	function getInput(key) {
		return document.querySelector('.mt-hex[data-key="' + key + '"], .mt-text[data-key="' + key + '"], .mt-select[data-key="' + key + '"], .mt-padding-value[data-key="' + key + '"]');
	}
	function get(key) {
		var el = getInput(key);
		if (el) return el.value || '';
		var cb = document.querySelector('input[type="checkbox"][data-key="' + key + '"]');
		if (cb) return cb.checked ? 'true' : '';
		return '';
	}
	function set(key, value) {
		var el = getInput(key);
		if (el) { el.value = value; return; }
		var cb = document.querySelector('input[type="checkbox"][data-key="' + key + '"]');
		if (cb) cb.checked = (value === 'true');
	}

	function networkName(key) {
		var n = allNetworks[key];
		return (n && n.name) ? n.name : key;
	}
	function networkBrand(key) {
		return networkColors[key] || '#9ca3af';
	}
	function networkSvg(key) {
		return networkSvgs[key] || '';
	}

	// ---------- padding split ----------
	var paddingParts = { t: '', r: '', b: '', l: '' };
	(function initPadding() {
		var raw = String(get('mytemplate_padding') || '').trim().split(/\s+/).filter(Boolean);
		if (raw.length === 1) { paddingParts = { t: raw[0], r: raw[0], b: raw[0], l: raw[0] }; }
		else if (raw.length === 2) { paddingParts = { t: raw[0], r: raw[1], b: raw[0], l: raw[1] }; }
		else if (raw.length === 3) { paddingParts = { t: raw[0], r: raw[1], b: raw[2], l: raw[1] }; }
		else if (raw.length >= 4) { paddingParts = { t: raw[0], r: raw[1], b: raw[2], l: raw[3] }; }
	})();
	function compilePadding() {
		return [paddingParts.t, paddingParts.r, paddingParts.b, paddingParts.l].join(' ').trim();
	}
	function syncPaddingInputs() {
		document.querySelectorAll('[data-split="padding"]').forEach(function (el) {
			var part = el.getAttribute('data-part');
			el.value = paddingParts[part] || '';
		});
		var allSame = paddingParts.t && paddingParts.t === paddingParts.r && paddingParts.r === paddingParts.b && paddingParts.b === paddingParts.l;
		var all = document.querySelector('[data-all="padding"]');
		if (all) all.value = allSame ? paddingParts.t : '';
	}

	// ---------- geometry ----------
	function iconsizeWithGutter() {
		var iconsize = parseInt(num(get('mytemplate_iconsize'), 18), 10);
		var iconspace = parseInt(num(get('mytemplate_iconspace'), 9), 10);
		if (isNaN(iconsize)) iconsize = 18;
		if (isNaN(iconspace)) iconspace = 9;
		return iconsize + (2 * iconspace);
	}
	function shapeRadius(shape) {
		if (shape === 'rounded') return '4px';
		if (shape === 'round') return iconsizeWithGutter() + 'px';
		if (shape === 'leaf') return '14px 0px';
		if (shape === 'square') return '0px';
		return '';
	}
	function effectShadow(effect, strength, color) {
		var size = '';
		if (effect === 'flat') {
			size = 'inset 0 -2px 0';
			if (strength === 'small') size = 'inset 0 -1px 0';
			if (strength === 'medium') size = 'inset 0 -2px 0';
			if (strength === 'large') size = 'inset 0 -3px 0';
			if (strength === 'xlarge') size = 'inset 0 -4px 0';
		} else if (effect === 'shadow') {
			size = '1px 1px 3px 0';
			if (strength === 'small') size = '0px 1px 1px 0';
			if (strength === 'medium') size = '2px 2px 5px 0';
			if (strength === 'large') size = '3px 3px 10px -1px';
			if (strength === 'xlarge') size = '3px 3px 15px -2px';
		} else if (effect === 'glow') {
			size = '0px 0px 5px 0';
			if (strength === 'small') size = '0px 0px 3px 0';
			if (strength === 'medium') size = '0px 0px 8px 0';
			if (strength === 'large') size = '0px 0px 12px 0';
			if (strength === 'xlarge') size = '0px 0px 18px 0';
		}
		return size ? (size + ' ' + color) : '';
	}

	// ---------- color resolution (mirrors functions-template-helper.php) ----------
	function networkIsActive() { return get('mytemplate_network_is_active') === 'true'; }

	function resolveOutline(storedNetworkColor, sizeKey, colorKey, customKey) {
		var size = get(sizeKey);
		if (size === '') return '';
		var color = storedNetworkColor;
		var mode = get(colorKey);
		var custom = get(customKey);
		if (mode === 'white') color = '#fff';
		if (mode === 'dark') color = '#111';
		if (mode === 'custom' && custom !== '') color = custom;
		return size + 'px solid ' + color;
	}

	function defaultState(key) {
		var brand = networkBrand(key);
		var networkColor = brand;
		var storedNetworkColor = brand;
		var defaultNetworkColor = brand;
		var networkTextColor = '#fff';

		var defColor = get('mytemplate_default_color');
		var defColorCustom = get('mytemplate_default_color_custom');
		var defText = get('mytemplate_default_textcolor');
		var defTextCustom = get('mytemplate_default_textcolor_custom');

		if (defColor === '' && defColorCustom !== '') networkColor = defColorCustom;

		if (networkIsActive()) {
			var nb = get('mytemplate_' + key + '_bgcolor');
			var nt = get('mytemplate_' + key + '_textcolor');
			if (nb !== '') { networkColor = nb; defaultNetworkColor = networkColor; }
			if (nt !== '') networkTextColor = nt;
		}

		if (defColor === 'white') networkColor = '#fff';
		if (defColor === 'dark') networkColor = '#111';
		if (defColor === 'custom' && defColorCustom !== '') { networkColor = defColorCustom; storedNetworkColor = defColorCustom; }

		if (defText === 'network') networkTextColor = defaultNetworkColor;
		if (defText === 'dark') networkTextColor = '#111';
		if (defText === 'custom' && defTextCustom !== '') networkTextColor = defTextCustom;

		var effect = get('mytemplate_effect');
		var shadow = '';
		if (effect !== '') {
			var effectColor = get('mytemplate_effect_color') !== '' ? get('mytemplate_effect_color') : 'rgba(0,0,0,0.15)';
			shadow = effectShadow(effect, get('mytemplate_effect_strength'), effectColor);
		}

		return {
			bg: networkColor,
			text: networkTextColor,
			border: resolveOutline(storedNetworkColor, 'mytemplate_default_outlinesize', 'mytemplate_default_outlinecolor', 'mytemplate_default_outlinecolor_custom'),
			radius: shapeRadius(get('mytemplate_shape')),
			shadow: shadow
		};
	}

	function hoverState(key) {
		var brand = networkBrand(key);
		var networkColor = brand;
		var defaultNetworkColor = brand;
		var storedNetworkColor = brand;
		var networkTextColor = '#fff';

		var hovColor = get('mytemplate_hover_color');
		var hovColorCustom = get('mytemplate_hover_color_custom');
		var hovText = get('mytemplate_hover_textcolor');
		var hovTextCustom = get('mytemplate_hover_textcolor_custom');

		if (hovColor === 'network' && hovColorCustom !== '') networkColor = hovColorCustom;

		if (networkIsActive()) {
			var nb = get('mytemplate_' + key + '_hovercolor');
			var nt = get('mytemplate_' + key + '_hovertextcolor');
			if (nb !== '') { networkColor = nb; defaultNetworkColor = networkColor; }
			if (nt !== '') networkTextColor = nt;
		}

		if (hovColor === '') networkColor = adjustBrightness(networkColor, lightOrDark(networkColor));
		if (hovColor === 'white') networkColor = '#fff';
		if (hovColor === 'dark') networkColor = '#111';
		if (hovColor === 'custom' && hovColorCustom !== '') { networkColor = hovColorCustom; storedNetworkColor = hovColorCustom; }

		if (hovText === 'network') networkTextColor = defaultNetworkColor;
		if (hovText === 'dark') networkTextColor = '#111';
		if (hovText === 'custom' && hovTextCustom !== '') networkTextColor = hovTextCustom;

		var strength = get('mytemplate_hover_effect_strength') !== '' ? get('mytemplate_hover_effect_strength') : get('mytemplate_effect_strength');
		var effect = get('mytemplate_hover_effect');
		var shadow = '';
		if (effect !== '' && effect !== 'no') {
			var effectColor = get('mytemplate_hover_effect_color') !== '' ? get('mytemplate_hover_effect_color') : 'rgba(0,0,0,0.15)';
			shadow = effectShadow(effect, strength, effectColor);
		}

		var hoverShape = get('mytemplate_hover_shape');
		var radius = hoverShape !== '' ? shapeRadius(hoverShape) : '';

		return {
			bg: networkColor,
			text: networkTextColor,
			border: resolveOutline(storedNetworkColor, 'mytemplate_hover_outlinesize', 'mytemplate_hover_outlinecolor', 'mytemplate_hover_outlinecolor_custom'),
			radius: radius,
			shadow: shadow,
			shiny: get('mytemplate_hover_color_effect') === 'shiny'
		};
	}

	function effectiveHoverState(key) {
		var ds = defaultState(key);
		var hs = hoverState(key);
		// When no hover override is set, the default state stays in effect on hover
		if (hs.radius === '') hs.radius = ds.radius;
		if (hs.border === '') hs.border = ds.border;
		if (hs.shadow === '') hs.shadow = ds.shadow;
		return hs;
	}

	// ---------- color <-> hex binding ----------
	function updateColorButton(key, value) {
		document.querySelectorAll('.mt-color-btn[data-key="' + key + '"]').forEach(function (btn) {
			btn.style.background = value || '#f1f1f4';
		});
	}
	function syncColorPair(key) {
		var v = get(key);
		document.querySelectorAll('.mt-color-input[data-key="' + key + '"]').forEach(function (ci) {
			ci.value = (v && isValidHex(v)) ? v : '#9ca3af';
		});
		document.querySelectorAll('.mt-hex[data-key="' + key + '"]').forEach(function (hi) {
			hi.value = v;
		});
		updateColorButton(key, v);
	}
	function bindColorPair(colorInput, hexInput, key) {
		colorInput.addEventListener('input', function () {
			hexInput.value = colorInput.value;
			set(key, colorInput.value);
			updateColorButton(key, colorInput.value);
			renderAll();
		});
		hexInput.addEventListener('input', function () {
			var v = normalizeHex(hexInput.value);
			if (isValidHex(v)) {
				colorInput.value = v;
				set(key, v);
				updateColorButton(key, v);
				renderAll();
			} else if (hexInput.value.trim() === '') {
				set(key, '');
				updateColorButton(key, '');
				renderAll();
			}
		});
		hexInput.addEventListener('blur', function () {
			var v = get(key);
			hexInput.value = v;
			if (v && isValidHex(v)) colorInput.value = v;
		});
	}

	// ---------- live preview ----------
	function buildPreviewList() {
		var list = document.getElementById('mtPreviewList');
		if (!list || list._built) return;
		list.innerHTML = previewKeys.map(function (item) {
			var key = item.key;
			var name = item.name;
			var icon = networkSvg(key) || escapeHtml(name.charAt(0));
			return '<li class="essb_item essb_link_' + esc(key) + '">' +
				'<a href="#" onclick="return false;">' +
					'<span class="essb_icon essb_icon_' + esc(key) + '">' + icon + '</span>' +
					'<span class="essb_network_name">' + escapeHtml(name) + '</span>' +
				'</a>' +
			'</li>';
		}).join('');
		list._built = true;
	}

	function applyState(li, state) {
		var a = li.querySelector('a');
		var icon = li.querySelector('.essb_icon');
		var svg = icon ? icon.querySelector('svg') : null;
		var name = li.querySelector('.essb_network_name');
		a.style.backgroundColor = state.bg || '';
		a.style.color = state.text || '';
		a.style.border = state.border || '';
		a.style.borderRadius = state.radius || '';
		a.style.boxShadow = state.shadow || '';
		if (svg) svg.style.fill = state.text || '';
		if (name) name.style.color = state.text || '';
		li.classList.toggle('mt-shiny', !!state.shiny);
	}

	function renderPreview() {
		buildPreviewList();
		var list = document.getElementById('mtPreviewList');
		if (!list) return;

		var iconSize = parseInt(num(get('mytemplate_iconsize'), 18), 10);
		if (isNaN(iconSize)) iconSize = 18;
		var block = iconsizeWithGutter();

		var padding = get('mytemplate_padding');
		var namesize = get('mytemplate_namesize');
		var nameweight = get('mytemplate_nameweight');
		var texttrans = get('mytemplate_texttrans');

		previewKeys.forEach(function (item) {
			var key = item.key;
			var li = list.querySelector('.essb_link_' + key);
			if (!li) return;
			var a = li.querySelector('a');
			var icon = li.querySelector('.essb_icon');
			var svg = icon ? icon.querySelector('svg') : null;
			var name = li.querySelector('.essb_network_name');

			var ds = defaultState(key);
			var hs = effectiveHoverState(key);

			// static geometry
			a.style.padding = padding || '';
			if (icon) {
				icon.style.width = block + 'px';
				icon.style.height = block + 'px';
				icon.style.fontSize = iconSize + 'px';
			}
			if (svg) {
				svg.style.width = iconSize + 'px';
				svg.style.height = iconSize + 'px';
			}
			if (name) {
				name.style.fontSize = namesize || '';
				name.style.fontWeight = nameweight === 'bold' ? 'bold' : (nameweight === 'normal' ? '400' : '');
				name.style.fontStyle = nameweight === 'italic' ? 'italic' : '';
				name.style.textTransform = texttrans === 'uppercase' ? 'uppercase' : (texttrans === 'capitalaize' ? 'capitalize' : '');
			}

			applyState(li, ds);

			li.onmouseenter = function () { applyState(li, hs); };
			li.onmouseleave = function () { applyState(li, ds); };
		});
	}

	// ---------- per-network cards ----------
	function applyNetPreviewState(card, isHover) {
		var key = card.getAttribute('data-key');
		var state = isHover ? effectiveHoverState(key) : defaultState(key);
		var preview = card.querySelector('.mt-net-preview');
		var icon = card.querySelector('.mt-net-icon');
		var svg = icon ? icon.querySelector('svg') : null;
		var name = card.querySelector('.mt-net-name');
		if (preview) {
			preview.style.background = state.bg || '';
			preview.style.color = state.text || '';
			preview.style.boxShadow = state.shadow || '';
		}
		if (svg) svg.style.fill = state.text || '';
		if (name) name.style.color = state.text || '';
	}

	function refreshNetworkCard(key) {
		var card = document.querySelector('.mt-net-card[data-key="' + key + '"]');
		if (!card) return;
		var bgKey = 'mytemplate_' + key + '_bgcolor';
		var txtKey = 'mytemplate_' + key + '_textcolor';
		var hbgKey = 'mytemplate_' + key + '_hovercolor';
		var htxtKey = 'mytemplate_' + key + '_hovertextcolor';

		applyNetPreviewState(card, false);

		var changed = get(bgKey) || get(txtKey) || get(hbgKey) || get(htxtKey);
		card.classList.toggle('is-changed', !!changed);
	}

	function refreshAllNetworkCards() {
		document.querySelectorAll('.mt-net-card').forEach(function (card) {
			refreshNetworkCard(card.getAttribute('data-key'));
		});
	}

	function bindNetworkCards() {
		document.querySelectorAll('.mt-net-card').forEach(function (card) {
			var key = card.getAttribute('data-key');

			['bgcolor', 'textcolor', 'hovercolor', 'hovertextcolor'].forEach(function (suffix) {
				var k = 'mytemplate_' + key + '_' + suffix;
				var ci = card.querySelector('.mt-color-input[data-key="' + k + '"]');
				var hi = card.querySelector('.mt-hex[data-key="' + k + '"]');
				if (ci && hi && !ci._bound) {
					ci._bound = true;
					bindColorPair(ci, hi, k);
				}
			});

			var preview = card.querySelector('.mt-net-preview');
			if (preview) {
				preview.onmouseenter = function () { applyNetPreviewState(card, true); };
				preview.onmouseleave = function () { applyNetPreviewState(card, false); };
			}

			var reset = card.querySelector('.mt-reset');
			if (reset) {
				reset.addEventListener('click', function () {
					['bgcolor', 'textcolor', 'hovercolor', 'hovertextcolor'].forEach(function (suffix) {
						var k = 'mytemplate_' + key + '_' + suffix;
						set(k, '');
						syncColorPair(k);
					});
					refreshNetworkCard(key);
					renderAll();
				});
			}
		});
	}

	// ---------- changed count ----------
	var committed = {};
	function snapshot() {
		committed = {};
		document.querySelectorAll('[data-key]').forEach(function (el) {
			var k = el.getAttribute('data-key');
			if (!(k in committed)) committed[k] = get(k);
		});
	}
	function updateChangedCount() {
		var badge = document.getElementById('mtNetworkChanged');
		if (!badge) return;
		var count = 0;
		Object.keys(committed).forEach(function (k) {
			if ((get(k) || '') !== (committed[k] || '')) count++;
		});
		badge.textContent = count + ' changed';
	}

	// ---------- network toolbar ----------
	function updateNetworkCount() {
		var count = document.getElementById('mtNetworkCount');
		if (!count) return;
		var total = document.querySelectorAll('.mt-net-card').length;
		var shown = 0;
		document.querySelectorAll('.mt-net-card').forEach(function (card) {
			if (card.style.display !== 'none') shown++;
		});
		count.textContent = shown + ' of ' + total;
	}

	function bindNetworkToolbar() {
		var search = document.getElementById('mtNetworkSearch');
		if (search) {
			search.addEventListener('input', function () {
				var q = search.value.toLowerCase();
				document.querySelectorAll('.mt-net-card').forEach(function (card) {
					var key = card.getAttribute('data-key');
					var name = networkName(key).toLowerCase();
					card.style.display = (q && name.indexOf(q) === -1 && key.indexOf(q) === -1) ? 'none' : '';
				});
				updateNetworkCount();
			});
		}
		var reset = document.getElementById('mtNetworkResetAll');
		if (reset) {
			reset.addEventListener('click', function () {
				document.querySelectorAll('.mt-net-card').forEach(function (card) {
					var key = card.getAttribute('data-key');
					['bgcolor', 'textcolor', 'hovercolor', 'hovertextcolor'].forEach(function (suffix) {
						var k = 'mytemplate_' + key + '_' + suffix;
						set(k, '');
						syncColorPair(k);
					});
					refreshNetworkCard(key);
				});
				renderAll();
			});
		}
	}

	// ---------- render all ----------
	function renderAll() {
		syncPaddingInputs();
		renderPreview();
		refreshAllNetworkCards();
		updateChangedCount();
	}

	// ---------- bindings ----------
	function bindColorPairs() {
		document.querySelectorAll('.mt-color-input[data-key]').forEach(function (ci) {
			var key = ci.getAttribute('data-key');
			var hi = document.querySelector('.mt-hex[data-key="' + key + '"]');
			if (hi && !ci._bound) {
				ci._bound = true;
				bindColorPair(ci, hi, key);
			}
		});
		document.querySelectorAll('.mt-hex[data-key]').forEach(function (hi) {
			var key = hi.getAttribute('data-key');
			if (hi._synced) return;
			hi._synced = true;
			syncColorPair(key);
		});
	}

	function bindTextInputs() {
		document.querySelectorAll('.mt-text[data-key]').forEach(function (el) {
			var key = el.getAttribute('data-key');
			el.addEventListener('input', function () {
				set(key, el.value);
				renderAll();
			});
		});
	}

	function bindSelects() {
		document.querySelectorAll('.mt-select[data-key]').forEach(function (el) {
			var key = el.getAttribute('data-key');
			el.addEventListener('change', function () {
				set(key, el.value);
				renderAll();
			});
		});
	}

	function bindSwitches() {
		document.querySelectorAll('input[type="checkbox"][data-key]').forEach(function (cb) {
			var key = cb.getAttribute('data-key');
			cb.addEventListener('change', function () {
				set(key, cb.checked ? 'true' : '');
				if (key === 'mytemplate_network_is_active') {
					var area = document.getElementById('mtNetworkArea');
					if (area) area.classList.toggle('mt-hidden', !cb.checked);
				}
				renderAll();
			});
		});
	}

	function bindPadding() {
		document.querySelectorAll('[data-split="padding"]').forEach(function (el) {
			var part = el.getAttribute('data-part');
			el.addEventListener('input', function () {
				paddingParts[part] = el.value;
				set('mytemplate_padding', compilePadding());
				renderAll();
			});
		});
		var all = document.querySelector('[data-all="padding"]');
		if (all) {
			all.addEventListener('input', function () {
				paddingParts = { t: all.value, r: all.value, b: all.value, l: all.value };
				set('mytemplate_padding', compilePadding());
				renderAll();
			});
		}
	}

	// ---------- init ----------
	function init() {
		if (!document.getElementById('mtWrap')) return;

		bindColorPairs();
		bindTextInputs();
		bindSelects();
		bindSwitches();
		bindPadding();
		bindNetworkCards();
		bindNetworkToolbar();

		var area = document.getElementById('mtNetworkArea');
		var networkOn = get('mytemplate_network_is_active') === 'true';
		if (area) area.classList.toggle('mt-hidden', !networkOn);

		snapshot();
		renderAll();
		updateNetworkCount();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
