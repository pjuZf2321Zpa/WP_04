/**
 * Modern switch panel (ESSBOptionsFramework::draw_panel_start, mode=switch).
 *
 * These settings panels never save on toggle by themselves - unlike the
 * share-components panels whose toggles save instantly. Two behaviours:
 *
 *   - open (default): the toggle only reveals/hides the panel body. The option
 *     value is saved with the settings form.
 *   - reload (switch_submit = true): the toggle saves the option by submitting
 *     the form and reloads the page, so a heavy panel re-renders.
 *
 * @since 11.x
 */
(function($) {
	'use strict';

	function setPanelState($portlet, on) {
		var $content = $portlet.find('.essb-portlet-content').first();
		if (!$content.length) {
			return;
		}
		if (on) {
			$portlet.addClass('portlet-active');
			$content.removeClass('essb-portlet-content-closed').slideDown('fast');
			$('.CodeMirror').each(function(i, el) {
				if (el.CodeMirror) {
					el.CodeMirror.refresh();
				}
			});
		} else {
			$portlet.removeClass('portlet-active');
			$content.slideUp('fast', function() {
				$content.addClass('essb-portlet-content-closed');
			});
		}
	}

	// open: reveal/hide the panel body only (no saving)
	$(document).on('change', '.essb-panel-modern[data-panel-behaviour="open"] .ao-panel-toggle-control input[type="checkbox"]', function() {
		var $input = $(this);
		$input.closest('.ao-panel-toggle-control').toggleClass('is-active', $input.is(':checked'));
		setPanelState($input.closest('.essb-portlet'), $input.is(':checked'));
	});

	// reload: save the option and reload the page
	$(document).on('change', '.essb-panel-modern[data-panel-behaviour="reload"] .ao-panel-toggle-control input[type="checkbox"]', function() {
		window.essb_disable_ajax_submit = true;
		if ($('#advancedoptions-preloader').length) {
			$('#advancedoptions-preloader').fadeIn(100);
		}
		$('#essb_options_form').submit();
	});

})(jQuery);
