/**
 * Pinterest Pro
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 */
(function () {
	"use strict";

	if (!debounce) {
		var debounce = function (func, wait) {
			var timeout, args, context, timestamp;
			return function () {
				context = this;
				args = [].slice.call(arguments, 0);
				timestamp = new Date();
				var later = function () {
					var last = (new Date()) - timestamp;
					if (last < wait) {
						timeout = setTimeout(later, wait - last);
					} else {
						timeout = null;
						func.apply(context, args);
					}
				};
				if (!timeout) {
					timeout = setTimeout(later, wait);
				}
			};
		};
	}
	
	var essbPinProImagePicker = window.essbPinProImagePicker = function (instance) {
		if (essb) essb.tracking_only('', 'pinpro', instance);
		var e = document.createElement('script');
		e.setAttribute('type', 'text/javascript');
		e.setAttribute('charset', 'UTF-8');
		e.setAttribute('src', '//assets.pinterest.com/js/pinmarklet.js?r=' + Math.random() * 99999999);
		document.body.appendChild(e);
	}	

	var essbPinDomReady = function () {

		/**
		 * Fail-save validation
		 */
		if (!essbPinImages) return;

		/**
		 * Applying additional Pinterest optimizations for images
		 */
		// mobile disable
		if (essbPinImages.disable_mobile && window.innerWidth < 1024) {
			return;
		}
	

		var essbCurrentPinImageCount = window.essbCurrentPinImageCount = 0;

		if (essb_settings) {
			if (essb_settings.pin_pinid_active && essb_settings.pin_pinid) {
				var allImages = document.querySelectorAll('img');
				for (var imageIndex = 0; imageIndex < allImages.length; imageIndex++) {
					if (!allImages[imageIndex].getAttribute || !allImages[imageIndex].setAttribute) continue;
					var hasPinID = allImages[imageIndex].getAttribute('data-pin-id') || '';
					if (!hasPinID || hasPinID == '') allImages[imageIndex].setAttribute('data-pin-id', essb_settings.pin_pinid);
				}
			}
		}

		if (essb_settings) {
			if (essb_settings.pin_force_active && essb_settings.pin_force_image) {
				var forcedImages = document.querySelectorAll('img');
				for (var forceIndex = 0; forceIndex < forcedImages.length; forceIndex++) {
					if (!forcedImages[forceIndex].getAttribute || !forcedImages[forceIndex].setAttribute) continue;
					forcedImages[forceIndex].setAttribute('data-pin-media', essb_settings.pin_force_image);

					/**
					 * Forcing all custom parameters too
					 */
					if (!forcedImages[forceIndex].getAttribute('data-pin-description')) {
						var pinDescription = '';
						if (forcedImages[forceIndex].getAttribute('title')) pinDescription = forcedImages[forceIndex].getAttribute('title');
						else if (forcedImages[forceIndex].getAttribute('alt')) pinDescription = forcedImages[forceIndex].getAttribute('alt');

						// give always priority of the custom description if set
						if (essbPinImages.force_custompin && !essbPinImages.custompin) essbPinImages.custompin = document.title;
						if (essbPinImages.custompin) pinDescription = essbPinImages.custompin;

						// if title is not genenrated it will use the Document Title
						if (pinDescription == '') pinDescription = document.title;

						forcedImages[forceIndex].setAttribute('data-pin-description', pinDescription);
					}

					if (!forcedImages[forceIndex].getAttribute('data-pin-url')) forcedImages[forceIndex].setAttribute('data-pin-url', encodeURI(document.URL));
				}
			}
		}

		document.querySelectorAll('.wp-block-image,.essb-block-image').forEach(element => {
			let pinID = element.getAttribute('data-essb-pin-id') || '',
				pinDesc = element.getAttribute('data-essb-pin-description') || '',
				pinTitle = element.getAttribute('data-essb-pin-title') || '',
				pinAvoud = element.getAttribute('data-essb-pin-nopin') || '';

			if (element.querySelector('figure')) {
				let elFigure = element.querySelector('figure'),
					fpinID = elFigure.getAttribute('data-essb-pin-id') || '',
					fpinDesc = elFigure.getAttribute('data-essb-pin-description') || '',
					fpinTitle = elFigure.getAttribute('data-essb-pin-title') || '',
					fpinAvoud = elFigure.getAttribute('data-essb-pin-nopin') || '';

				if (fpinID != '') pinID = fpinID;
				if (fpinAvoud != '') pinAvoud = fpinAvoud;
				if (fpinDesc != '') pinDesc = fpinDesc;
				if (fpinTitle != '') pinTitle = fpinTitle;
			}

			if (element.tagName != 'IMG') element = element.querySelector('img');
			if (element) {
				if (pinID) element.setAttribute('data-pin-id', pinID);
				if (pinDesc) element.setAttribute('data-pin-description', pinDesc);
				if (pinTitle) element.setAttribute('data-pin-title', pinTitle);
				if (pinAvoud.toUpperCase() == 'TRUE') {
					element.setAttribute('data-pin-nopin', 'true');
					element.classList.add('no_pin');
				}
			}
		});


		/**
		 * Pinterest responsive thumbnail correction
		 */
		if (essb_settings.force_pin_thumbs) {
			// setting up a map of parsing images on site
			var essbReposiveImagesMap = window.essbReposiveImagesMap = {};

			// getting actual size of a single image
			var essbDetectAndLocateImageSize = window.essbDetectAndLocateImageSize = function (url, element, isResponsive) {
				if (isResponsive) {
					essbReposiveImagesMap[element].responsive[url] = {};
				}
				var sizeImage = new Image();
				sizeImage.onload = function () {
					if (essbReposiveImagesMap[element]) {
						if (!isResponsive) {
							essbReposiveImagesMap[element].originalSize = { 'w': sizeImage.width, 'h': sizeImage.height, 'done': true };
							essbCompileTheDataPinImage(element);
						} else {
							essbReposiveImagesMap[element].responsive[url] = { 'w': sizeImage.width, 'h': sizeImage.height, 'done': true };
							essbCompileTheDataPinImage(element);
						}
					}

				};
				sizeImage.src = url;
			};

			var essbCompileTheDataPinImage = window.essbCompileTheDataPinImage = function (element) {
				var totalImages = 0,
					processImages = 0,
					currentMaxW = 0,
					imageURL = '';

				for (var rImageURL in essbReposiveImagesMap[element].responsive) {
					var dataObj = essbReposiveImagesMap[element].responsive[rImageURL] || {};
					totalImages++;

					if (!dataObj.done) continue;
					processImages++;
					if (currentMaxW == 0 || currentMaxW < dataObj.w) {
						currentMaxW = dataObj.w;
						imageURL = rImageURL;
					}

				}

				if (totalImages == processImages && essbReposiveImagesMap[element].original != imageURL) {
					if (essbReposiveImagesMap[element].originalSize.done) {
						if (currentMaxW > essbReposiveImagesMap[element].originalSize.w) {
							var pinKeyImages = document.querySelectorAll('[data-pinpro-key="' + element + '"]');
							if (pinKeyImages) {
								for (var pinKeyIndex = 0; pinKeyIndex < pinKeyImages.length; pinKeyIndex++) {
									if (!pinKeyImages[pinKeyIndex].setAttribute || !pinKeyImages[pinKeyIndex].classList) continue;
									pinKeyImages[pinKeyIndex].setAttribute('data-pin-media', imageURL);
									pinKeyImages[pinKeyIndex].setAttribute('data-media', imageURL);
									pinKeyImages[pinKeyIndex].setAttribute('data-pin-url', window.location.href);
									pinKeyImages[pinKeyIndex].classList.remove('pin-process');
								}
								for (var pinGenIndex = 0; pinGenIndex < pinKeyImages.length; pinGenIndex++) {
									if (!pinKeyImages[pinGenIndex]) continue;
									essbPinImagesGenerateButtons(pinKeyImages[pinGenIndex]);
								}
							}
						}
					}
				}
			}

			var responsiveSourceImages = document.querySelectorAll('img');
			for (var responsiveIndex = 0; responsiveIndex < responsiveSourceImages.length; responsiveIndex++) {
				var thisImage = responsiveSourceImages[responsiveIndex];
				if (!thisImage.getAttribute || !thisImage.setAttribute || !thisImage.classList) continue;

				var responsiveImages = thisImage.getAttribute('srcset') || '',
					uniqueID = Math.random().toString(36).substr(2, 9),
					element = uniqueID;

				if (!responsiveImages || responsiveImages == '') continue;

				thisImage.setAttribute('data-pinpro-key', uniqueID);
				thisImage.classList.add('pin-process');
				var responsiveSet = responsiveImages.split(', '),
					originalImage = thisImage.getAttribute('src') || '';

				essbReposiveImagesMap[element] = {
					source: element,
					original: originalImage,
					originalSize: {},
					responsive: {}
				};
				essbDetectAndLocateImageSize(originalImage, element);
				for (var i = 0; i < responsiveSet.length; i++) {
					if (!responsiveSet[i]) continue;
					var imageData = responsiveSet[i].split(' '),
						imageURL = imageData[0] || '',
						imageSize = (imageData[1] || '').replace('w', '');

					if (!imageURL || !Number(imageSize)) continue;

					essbDetectAndLocateImageSize(imageURL, element, true);

				}

			}
		} // end forcing generation of responsive images

		/**
		 * Pinterest Images
		 */

		var essbPinImagesGenerateButtons = function (image) {
			// the option to avoid button over images with links
			if (essbPinImages.nolinks && image.closest('a')) return;

			// avoid buttons on images that has lower size that setup
			if (image.offsetWidth < Number(essbPinImages.min_width || 0) || image.offsetHeight < Number(essbPinImages.min_height || 0)) return;

			// To provide compatibility with hidden images
			if (image.getAttribute('data-pinpro-allowed')) {
				image.removeAttribute('nopin');
				image.removeAttribute('data-pin-nopin');
				image.classList.remove('no_pin');
				image.classList.remove('essb_no_pin');
			}

			// ignore the non Pinable images
			if (image.classList.contains('no_pin') || image.classList.contains('no-pin') || image.getAttribute('data-pin-nopin') || image.classList.contains('pin-generated') || image.classList.contains('pin-process') || image.classList.contains('zoomImg') || image.classList.contains('lazy-hidden')) return;

			var pinSrc = image.src || '',
				pinDescription = '', shareBtnCode = [],
				buttonStyleClasses = '', buttonSizeClasses = '',
				pinID = image.getAttribute('data-pin-id') || '';

			// additional check for the autoptimize svg placeholder preventing images from load
			// Pinterest also does not accept SVG images
			if (pinSrc.indexOf('data:image/svg+xml') > -1 || pinSrc.indexOf('data:image/gif') > -1 || pinSrc.indexOf('data:image/png') > -1 || pinSrc == '') return;

			if (image.getAttribute('data-media')) pinSrc = image.getAttribute('data-media');
			if (image.getAttribute('data-lazy-src')) pinSrc = image.getAttribute('data-lazy-src');
			if (image.getAttribute('data-pin-media')) pinSrc = image.getAttribute('data-pin-media');

			if (image.getAttribute('data-pin-description')) pinDescription = image.getAttribute('data-pin-description');
			else if (image.getAttribute('title')) pinDescription = image.getAttribute('title');
			else if (image.getAttribute('alt')) pinDescription = image.getAttribute('alt');

			// give always priority of the custom description if set
			if (essbPinImages.force_custompin && !essbPinImages.custompin) essbPinImages.custompin = document.title;
			if (essbPinImages.custompin) pinDescription = essbPinImages.custompin;

			// if title is not genenrated it will use the Document Title
			if (pinDescription == '') pinDescription = document.title;

			var shareCmd = 'https://pinterest.com/pin/create/button/?url=' + encodeURI(document.URL) + '&is_video=false' + '&media=' + encodeURI(pinSrc) + '&description=' + encodeURIComponent(pinDescription);

			if (essbPinImages.legacy_share_cmd)
				shareCmd = 'https://pinterest.com/pin/create/bookmarklet/?url=' + encodeURI(document.URL) + '&media=' + encodeURI(pinSrc) + '&title=' + encodeURIComponent(pinDescription) + '&description=' + encodeURIComponent(pinDescription) + '&media=' + encodeURI(pinSrc);

			// encode the ' symbol separately
			if (shareCmd.indexOf("'") > -1) shareCmd = shareCmd.replace(/'/g, '%27');

			if (pinID != '') shareCmd = 'https://www.pinterest.com/pin/' + pinID + '/repin/x/';

			var imgClasses = image.getAttribute('class'),
				imgStyles = image.getAttribute('style');

			if (essbPinImages['button_style'] == 'icon_hover') {
				buttonStyleClasses = ' essb_hide_name';
			}
			if (essbPinImages['button_style'] == 'icon') {
				buttonStyleClasses = ' essb_force_hide_name essb_force_hide';
			}
			if (essbPinImages['button_style'] == 'button_name') {
				buttonStyleClasses = ' essb_hide_icon';
			}
			if (essbPinImages['button_style'] == 'vertical') {
				buttonStyleClasses = ' essb_vertical_name';
			}

			if (essbPinImages['button_size']) buttonSizeClasses = ' essb_size_' + essbPinImages['button_size'];
			if (essbPinImages['animation']) buttonSizeClasses += ' ' + essbPinImages['animation'];
			if (essbPinImages['position']) buttonSizeClasses += ' essb_pos_' + essbPinImages['position'];

			if (essbPinImages['mobile_position']) buttonSizeClasses += ' essb_mobilepos_' + essbPinImages['mobile_position'];
			if (essbPinImages['visibility'] && essbPinImages['visibility'] == 'always') buttonSizeClasses += ' essb_always_visible';

			image.removeAttribute('class');
			image.removeAttribute('style');

			var pinWrapper = document.createElement('div');
			pinWrapper.className = 'essb-pin';
			if (image.parentNode) {
				image.parentNode.insertBefore(pinWrapper, image);
				pinWrapper.appendChild(image);
			}
			if (imgClasses != '') {
				var imgClassList = imgClasses.split(' ');
				for (var imgClassIndex = 0; imgClassIndex < imgClassList.length; imgClassIndex++) {
					if (imgClassList[imgClassIndex] != '') pinWrapper.classList.add(imgClassList[imgClassIndex]);
				}
			}
			if (imgStyles != '') pinWrapper.setAttribute('style', imgStyles);

			// images count
			window.essbCurrentPinImageCount++;
			pinWrapper.classList.add('essb-pinid-' + window.essbCurrentPinImageCount.toString());

			if (essbPinImages.reposition) {
				var imgWidth = image.offsetWidth;
				if (Number(imgWidth) && !isNaN(imgWidth) && Number(imgWidth) > 0) {
					pinWrapper.style.maxWidth = imgWidth + 'px';
				}
			}

			var uid = (new Date().getTime()).toString(36);

			var iconMainClass = essbPinImages.svgIcon ? 'essb_icon_svg_pinterest' : 'essb_icon_pinterest';
			var shareAction = 'essb.window(&#39;' + shareCmd + '&#39;,&#39;pinpro&#39;,&#39;' + uid + '&#39;); return false;';
			
			if ((essbPinImages['pinterest_behavior'] || '') == 'gallery') {
				shareCmd = '#';
				shareAction = 'window.essbPinProImagePicker(&#39;' + uid + '&#39;); return false;';
			}

			shareBtnCode.push('<div class="essb_links essb_displayed_pinimage essb_template_' + essbPinImages.template + buttonSizeClasses + ' essb_' + uid + '" data-essb-position="pinit" data-essb-postid="' + (essb_settings.post_id || '') + '" data-essb-instance="' + uid + '">');
			shareBtnCode.push('<ul class="essb_links_list' + (buttonStyleClasses != '' ? ' ' + buttonStyleClasses : '') + '">');
			shareBtnCode.push('<li class="essb_item essb_link_pinterest nolightbox' + (essbPinImages['svgIcon'] ? ' essb_link_svg_icon' : '') + '">');
			shareBtnCode.push('<a class="nolightbox' + (essbPinImages['template_a_class'] ? ' ' + essbPinImages['template_a_class'] : '') + '" rel="noreferrer noopener nofollow" href="' + shareCmd + '" onclick="'+shareAction+'" target="_blank"><span class="essb_icon ' + iconMainClass + (essbPinImages['template_icon_class'] ? ' ' + essbPinImages['template_icon_class'] : '') + '">' + (essbPinImages.svgIcon || '') + '</span><span class="essb_network_name">' + (essbPinImages['text'] ? essbPinImages['text'] : 'Pin') + '</span></a>');
			shareBtnCode.push('</li>');
			shareBtnCode.push('</ul>');
			shareBtnCode.push('</div>');

			image.insertAdjacentHTML('afterend', shareBtnCode.join(''));
			image.classList.add('pin-generated'); // adding class to avoid generating again the same information
			//essb.share_window
			//removing the lazyloading class if posted
			if (pinWrapper.classList.contains('lazyloading')) pinWrapper.classList.remove('lazyloading');

			if (essbPinImages['recenter'] && (essbPinImages['position'] || '') == 'middle-middle') {
				var essbContainer = pinWrapper.querySelector('.essb_links');
				if (essbContainer) {
					essbContainer.style.setProperty('margin-left', '-' + Math.round(essbContainer.offsetWidth / 2) + 'px', 'important');
					essbContainer.style.setProperty('margin-top', '-' + Math.round(essbContainer.offsetHeight / 2) + 'px', 'important');
				}
			}

		}

		if (typeof (essbPinImages) != 'undefined' && document.body.classList.contains('tcb-edit-mode')) essbPinImages.active = false;

		if (typeof (essbPinImages) != 'undefined' && essbPinImages.active) {
			/**
			 * Fail-save validation for the minimal width and height
			 */
			if (!essbPinImages.min_width || !Number(essbPinImages.min_width)) essbPinImages.min_width = 300;
			if (!essbPinImages.min_height || !Number(essbPinImages.min_height)) essbPinImages.min_height = 300;

			// mobile optimization
			if (window.innerWidth < 720) {
				if (!Number(essbPinImages.min_width_mobile)) essbPinImages.min_width_mobile = 200;
				if (!Number(essbPinImages.min_height_mobile)) essbPinImages.min_height_mobile = 150;

				essbPinImages.min_width = Math.min(Number(essbPinImages.min_width), Number(essbPinImages.min_width_mobile));
				essbPinImages.min_height = Math.min(Number(essbPinImages.min_height), Number(essbPinImages.min_height_mobile));
			}

			if (document.querySelectorAll('.essb-pin.tve_image').length) {
				var tveLinks = document.querySelectorAll('.essb-pin.tve_image .essb_links');
				for (var tveIndex = 0; tveIndex < tveLinks.length; tveIndex++) tveLinks[tveIndex].remove();
				var tveImages = document.querySelectorAll('.essb-pin img');
				for (var tveImageIndex = 0; tveImageIndex < tveImages.length; tveImageIndex++) tveImages[tveImageIndex].classList.remove('pin-generated');
			}

			// WP Rocket Lazy Videos set no-pin class to those images to prevent holding down
			var rllImages = document.querySelectorAll('.rll-youtube-player img');
			for (var rllIndex = 0; rllIndex < rllImages.length; rllIndex++) rllImages[rllIndex].classList.add('no-pin');

			// Hide on images option
			if (essbPinImages.hideon) {
				var hideImages = document.querySelectorAll(essbPinImages.hideon);
				for (var hideIndex = 0; hideIndex < hideImages.length; hideIndex++) hideImages[hideIndex].classList.add('no-pin');
			}

			window.addEventListener('LazyLoad::Initialized', function (e) {
				var rllLazyImages = document.querySelectorAll('.rll-youtube-player img');
				for (var rllLazyIndex = 0; rllLazyIndex < rllLazyImages.length; rllLazyIndex++) rllLazyImages[rllLazyIndex].classList.add('no-pin');
			});

			var essbPinImagesDetect = function () {

				// WP Rocket Lazy Videos set no-pin class to those images to prevent holding down
				var rllDetectImages = document.querySelectorAll('.rll-youtube-player img');
				for (var rllDetectIndex = 0; rllDetectIndex < rllDetectImages.length; rllDetectIndex++) rllDetectImages[rllDetectIndex].classList.add('no-pin');

				// Hide on images option
				if (essbPinImages.hideon) {
					var hideDetectImages = document.querySelectorAll(essbPinImages.hideon);
					for (var hideDetectIndex = 0; hideDetectIndex < hideDetectImages.length; hideDetectIndex++) hideDetectImages[hideDetectIndex].classList.add('no-pin');
				}

				if (essbPinImages.selector) {
					var selectorImages = document.querySelectorAll(essbPinImages.selector);
					for (var selectorIndex = 0; selectorIndex < selectorImages.length; selectorIndex++) essbPinImagesGenerateButtons(selectorImages[selectorIndex]);
				}
				else {
					if (!document.querySelectorAll('.essb-pinterest-images').length) return;
					var contentImages = document.querySelectorAll('.essb-pinterest-images');
					for (var contentIndex = 0; contentIndex < contentImages.length; contentIndex++) {
						var contentParent = contentImages[contentIndex].parentNode;
						if (!contentParent) continue;
						var contentParentImages = contentParent.querySelectorAll('img');
						for (var contentImageIndex = 0; contentImageIndex < contentParentImages.length; contentImageIndex++) essbPinImagesGenerateButtons(contentParentImages[contentImageIndex]);
					}
				}
			}

			if (essbPinImages.lazyload) window.addEventListener('scroll', debounce(essbPinImagesDetect, 10));

			if (!essbPinImages.optimize_load) setTimeout(essbPinImagesDetect, 1);
			else {
				const essbPinUserInteractions = ["keydown", "mousedown", "mousemove", "wheel", "touchmove", "touchstart", "touchend"];
				essbPinUserInteractions.forEach(function (event) {
					window.addEventListener(event, essbPinTriggerDOMListener, { passive: true });
				});

				document.addEventListener("visibilitychange", essbPinTriggerDOMListener);

				function essbPinTriggerDOMListener() {
					//remove existing user interaction event listeners
					essbPinUserInteractions.forEach(function (event) {
						window.removeEventListener(event, essbPinTriggerDOMListener, { passive: true });
					});

					//remove visibility change listener
					document.removeEventListener("visibilitychange", essbPinTriggerDOMListener);

					//add dom listner if page is still loading
					if (document.readyState === 'loading') {
						document.addEventListener("DOMContentLoaded", essbPinTriggerDetector);
					}
					else {
						//trigger delayed script process
						essbPinTriggerDetector();
					}
				}

				function essbPinTriggerDetector() {
					setTimeout(essbPinImagesDetect, 1);
				}
			}
		}

		if ((typeof (essbPinImages) != 'undefined' && !essbPinImages.active) || typeof (essbPinImages) == 'undefined') {
			if (document.querySelectorAll('.essb-pin.tve_image').length) {
				var inactiveTveLinks = document.querySelectorAll('.essb-pin.tve_image .essb_links');
				for (var inactiveTveIndex = 0; inactiveTveIndex < inactiveTveLinks.length; inactiveTveIndex++) inactiveTveLinks[inactiveTveIndex].remove();
				var inactiveTveImages = document.querySelectorAll('.essb-pin img');
				for (var inactiveTveImageIndex = 0; inactiveTveImageIndex < inactiveTveImages.length; inactiveTveImageIndex++) inactiveTveImages[inactiveTveImageIndex].classList.remove('pin-generated');
			}
		}

	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbPinDomReady);
	} else {
		essbPinDomReady();
	}
})();