/**
 * Subscribe forms
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 *
 * VanillaJS (no jQuery), self-contained.
 */
(function () {
	"use strict";

	// Fade helpers (replaces jQuery fadeIn / fadeOut)
	var fadeIn = function (element, duration) {
		if (!element) return;
		element.style.opacity = '0';
		element.style.display = 'block';
		element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
		requestAnimationFrame(function () {
			element.style.opacity = '1';
		});
	};

	var fadeOut = function (element, duration) {
		if (!element) return;
		element.style.opacity = '1';
		element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
		requestAnimationFrame(function () {
			element.style.opacity = '0';
		});
		window.setTimeout(function () {
			element.style.display = 'none';
		}, duration ? duration : 400);
	};

	// Center helper (replaces jQuery .center() plugin)
	var center = function (element) {
		if (!element) return;
		if (window.getComputedStyle(element).display === 'none') {
			element.style.display = 'block';
		}
		var top = (window.innerHeight - element.offsetHeight) / 2;
		var left = (window.innerWidth - element.offsetWidth) / 2;
		element.style.position = 'fixed';
		element.style.margin = '0';
		element.style.top = (top > 0 ? top : 0) + 'px';
		element.style.left = (left > 0 ? left : 0) + 'px';
	};

	// Slide helper (replaces jQuery slideDown)
	var slideDown = function (element, duration) {
		if (!element) return;
		element.style.display = 'block';
		element.style.height = '0px';
		element.style.overflow = 'hidden';
		element.style.transition = 'height ' + (duration ? duration : 400) + 'ms ease';
		requestAnimationFrame(function () {
			element.style.height = element.scrollHeight + 'px';
		});
		window.setTimeout(function () {
			element.style.height = '';
			element.style.overflow = '';
			element.style.transition = '';
		}, duration ? duration : 400);
	};

	function essb_ajax_subscribe(key, event) {

		event.preventDefault();

		var formContainer = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-from-content-form-mailchimp'),
			positionContainer = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-form-content');

		var usedPosition = positionContainer ? positionContainer.getAttribute('data-position') || '' : '',
			usedDesign = positionContainer ? positionContainer.getAttribute('data-design') || '' : '';

		if (formContainer) {
			// Additional check for require agree to terms check
			var confirmField = formContainer.querySelector('.essb-subscribe-confirm');
			if (confirmField) {
				if (!confirmField.checked) {
					event.preventDefault();
					if (essb_settings.subscribe_terms_error)
						alert(essb_settings.subscribe_terms_error);
					else
						alert('You need to confirm that you agree with our terms');
					return;
				}
			}

			var nameField = formContainer.querySelector('.essb-subscribe-form-content-name-field');
			if (nameField && essb_settings.subscribe_validate_name) {
				if (nameField.value == '') {
					if (essb_settings.subscribe_validate_name_error)
						alert(essb_settings.subscribe_validate_name_error);
					else
						alert('You need to fill name field too');
					return;
				}
			}

			var emailField = formContainer.querySelector('.essb-subscribe-form-content-email-field'),
				user_mail = emailField ? emailField.value : '',
				user_name = nameField ? nameField.value : '';

			var submitButton = formContainer.querySelector('.submit');
			if (submitButton) submitButton.disabled = true;
			formContainer.style.display = 'none';

			var loader = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-loader');
			if (loader) loader.style.display = 'block';

			var submitapi_call = (formContainer.getAttribute('action') || '') + '&mailchimp_email=' + encodeURIComponent(user_mail) + '&mailchimp_name=' + encodeURIComponent(user_name) + '&position=' + encodeURIComponent(usedPosition) + '&design=' + encodeURIComponent(usedDesign) + '&title=' + encodeURIComponent(document.title);

			if (confirmField && confirmField.checked) {
				submitapi_call += '&essb_subscribe_confirm=1';
			}

			/**
			 * @since 8.6 custom fields support for Mailchimp
			 */
			var elCustomFields = document.querySelectorAll('.essb-subscribe-form-' + key + ' .essb-subscribe-from-content-form-mailchimp .essb-subscribe-custom'),
				isCustomError = false;
			for (var i = 0; i < elCustomFields.length; i++) {
				if (elCustomFields[i].value == '' && elCustomFields[i].classList.contains('essb-subscribe-required')) {
					isCustomError = true;
					var place = elCustomFields[i].getAttribute('placeholder') || '';
					alert('You need to fill ' + place);
					break;
				}

				var param = elCustomFields[i].getAttribute('data-field') || '';
				if (param != '') submitapi_call += '&mailchimp_' + encodeURIComponent(param) + '=' + encodeURIComponent(elCustomFields[i].value);
			}

			if (isCustomError) return;

			/**
			 * @since 7.7 Additional check to prevent mixed content 
			 */
			var current_page_url = window.location.href;
			if (current_page_url.indexOf('https://') > -1 && submitapi_call.indexOf('https://') == -1) submitapi_call = submitapi_call.replace('http://', 'https://');

			// validate reCaptcha too
			if (document.querySelector('.essb-subscribe-captcha')) {
				var recaptchaField = document.querySelector('#g-recaptcha-response'),
					recaptcha = recaptchaField ? recaptchaField.value : '';

				if (document.querySelector('input[name="cf-turnstile-response"]')) recaptcha = document.querySelector('input[name="cf-turnstile-response"]').value;
				submitapi_call += '&validate_recaptcha=true&recaptcha=' + recaptcha;
			}

			var successHandler = function (data) {

				if (data) {

					console.log(data);

					if (data['code'] == '1') {
						var successBox = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-form-content-success'),
							errorBox = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-form-content-error');
						if (successBox) successBox.style.display = 'block';
						if (errorBox) errorBox.style.display = 'none';
						formContainer.style.display = 'none';

						// subscribe conversions tracking
						//usedPosition
						if (typeof (essb_subscribe_tracking) != 'undefined') {
							essb_subscribe_tracking(usedPosition);
						}

						// integration with Conversions Pro
						if (typeof (essbSubscribeProLog) != 'undefined') {
							essbSubscribeProLog('subscribe_conversion_success', usedPosition, usedDesign);
						}

						// redirecting users if successful redirect URL is set
						if (data['redirect']) {
							setTimeout(function () {

								if (data['redirect_new']) {
									var win = window.open(data['redirect'], '_blank');
									if (win) win.focus();
								}
								else
									window.location.href = data['redirect'];
							}, 200);
						}

						if (window.pendingUnlockOnSubscribe) essb_optin_locker_unlock();

						essb.trigger('subscribe_success', { 'design': usedDesign, 'position': usedPosition, 'email': user_mail, 'name': user_name });
					}
					else {
						// integration with Conversions Pro
						if (typeof (essbSubscribeProLog) != 'undefined') {
							essbSubscribeProLog('subscribe_conversion_fail', usedPosition, usedDesign);
						}

						var errorBoxFail = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-form-content-error'),
							storedMessage = errorBoxFail ? errorBoxFail.getAttribute('data-message') || '' : '';
						if (storedMessage == '') {
							if (errorBoxFail) errorBoxFail.setAttribute('data-message', errorBoxFail.textContent);
						}

						if (data['code'] == 90) {
							if (errorBoxFail) errorBoxFail.textContent = data['message'];
						} else {
							if (errorBoxFail) errorBoxFail.textContent = storedMessage;
						}
						if (errorBoxFail) errorBoxFail.style.display = 'block';

						var formBox = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-from-content-form');
						if (formBox) formBox.style.display = 'block';
						if (submitButton) submitButton.disabled = false;
					}

					var loaderDone = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-loader');
					if (loaderDone) loaderDone.style.display = 'none';
				}
			};

			fetch(submitapi_call, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: 'mailchimp_email1=' + encodeURIComponent(user_mail) + '&mailchimp_name1=' + encodeURIComponent(user_name)
			}).then(function (response) {
				return response.json();
			}).then(successHandler).catch(function () {
				var loaderFail = document.querySelector('.essb-subscribe-form-' + key + ' .essb-subscribe-loader');
				if (loaderFail) loaderFail.style.display = 'none';
			});
		}

	}

	window.essb_ajax_subscribe = essb_ajax_subscribe;

	var essbSubscribeReady = function () {

		/**
		 * Booster Pop-up forms
		 */
		var booster_optin_triggered = false,
			booster_optin_percent = 0,
			booster_optin_time = 0;

		var essb_manualform_show = window.essb_manualform_show = function () {
			essb_optin_booster_show('manual');
			booster_optin_triggered = false;
		}

		var essb_optin_booster_show = function (event) {

			if (booster_optin_triggered) return;

			var base_element = '.essb-optinbooster-' + event;
			var base_overlay_element = '.essb-optinbooster-overlay-' + event;

			var boosterElement = document.querySelector(base_element);
			if (!boosterElement) return;

			var singleDisplay = boosterElement.getAttribute('data-single') || '',
				singleDisplayDelay = boosterElement.getAttribute('data-single-days') || '';

			if (singleDisplay == '1') {
				var cookie_name = "essbOptinBooster";
				var cookieSet = essbGetCookie(cookie_name);
				if (cookieSet == "yes") { return; }

				singleDisplayDelay = (singleDisplayDelay == '' || !Number(singleDisplayDelay)) ? 14 : Number(singleDisplayDelay);

				essbSetCookie(cookie_name, "yes", singleDisplayDelay);
			}

			var win_width = window.innerWidth;

			var base_width = 700;
			if (win_width < base_width) { base_width = win_width - 60; }

			boosterElement.style.width = base_width + 'px';
			center(boosterElement);

			var boosterOverlay = document.querySelector(base_overlay_element);
			fadeIn(boosterElement, 400);
			fadeIn(boosterOverlay, 200);

			boosterElement.classList.add('active-booster');
			if (boosterOverlay) boosterOverlay.classList.add('active-booster-overlay');

			booster_optin_triggered = true;

			// integration with Conversions Pro
			if (typeof (essbSubscribeProLog) != 'undefined') {
				var boosterPositionContainer = document.querySelector(base_element + ' .essb-subscribe-form-content'),
					position = boosterPositionContainer ? boosterPositionContainer.getAttribute('data-position') || '' : '',
					design = boosterPositionContainer ? boosterPositionContainer.getAttribute('data-design') || '' : '';
				essbSubscribeProLog('subscribe_conversion_loaded', position, design);
			}
		}

		var essb_optinbooster_close = function () {

			var boosterActive = document.querySelector('.active-booster');
			fadeOut(boosterActive, 200);
			var boosterActiveEls = document.querySelectorAll('.active-booster');
			for (var b = 0; b < boosterActiveEls.length; b++) boosterActiveEls[b].classList.remove('active-booster');

			var overlayActive = document.querySelector('.active-booster-overlay');
			fadeOut(overlayActive, 400);
			var overlayActiveEls = document.querySelectorAll('.active-booster-overlay');
			for (var bo = 0; bo < overlayActiveEls.length; bo++) overlayActiveEls[bo].classList.remove('active-booster-overlay');
		}

		if (document.querySelector('.essb-optinbooster-exit')) {

			document.addEventListener('mouseleave', function (e) {

				if (e.clientY < 0) { // Check if the cursor went above the top of the browser window
					essb_optin_booster_show('exit');
				}
			});
		}

		var essb_booster_scroll = function () {
			if (booster_optin_triggered) { return; }

			var current_pos = window.pageYOffset || document.documentElement.scrollTop;
			var height = document.documentElement.scrollHeight - window.innerHeight;
			var percentage = current_pos / height * 100;

			if (percentage > booster_optin_percent && booster_optin_percent > 0) {
				essb_optin_booster_show('scroll');
			}
		}

		var boosterScrollTrigger = document.querySelector('.essb-optinbooster-scroll');
		if (boosterScrollTrigger) {
			booster_optin_percent = boosterScrollTrigger.getAttribute("data-scroll") || "";
			booster_optin_percent = parseFloat(booster_optin_percent);
			window.addEventListener('scroll', essb_booster_scroll);
		}

		var boosterTimeTrigger = document.querySelector('.essb-optinbooster-time');
		if (boosterTimeTrigger) {
			booster_optin_time = boosterTimeTrigger.getAttribute("data-delay") || "";
			booster_optin_time = parseFloat(booster_optin_time);
			booster_optin_time = booster_optin_time * 1000;
			setTimeout(function () { essb_optin_booster_show('time'); }, booster_optin_time);
		}

		var manualTrigger = document.querySelector('.essb-optinbooster-manual');
		if (manualTrigger) {
			var selector = manualTrigger.getAttribute('data-manual-selector') || '';
			if (selector != '') {
				var manualElements = document.querySelectorAll(selector);
				for (var m = 0; m < manualElements.length; m++) {
					manualElements[m].addEventListener('click', function (e) {
						e.preventDefault();
						essb_manualform_show();
					});
				}
			}
		}

		var boosterOverlays = document.querySelectorAll('.essb-optinbooster-overlay');
		for (var bsOv = 0; bsOv < boosterOverlays.length; bsOv++) {
			boosterOverlays[bsOv].addEventListener('click', function (e) {
				e.preventDefault();

				essb_optinbooster_close();
			});
		}

		var boosterCloseButtons = document.querySelectorAll('.essb-optinbooster-close');
		for (var bsCl = 0; bsCl < boosterCloseButtons.length; bsCl++) {
			boosterCloseButtons[bsCl].addEventListener('click', function (e) {
				e.preventDefault();

				essb_optinbooster_close();
			});
		}

		function essbSetCookie(cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toGMTString();
			document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
		}

		function essbGetCookie(cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i].trim();
				if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
			}
			return "";
		}

		/**
		 * Flyout subscribe forms
		 */
		var optin_triggered = false,
			optin_percent = 0,
			optin_time = 0;

		var essb_optin_flyout_show = function (event) {

			if (optin_triggered) return;

			var base_element = '.essb-optinflyout-' + event;
			var base_overlay_element = '.essb-optinflyout-overlay-' + event;

			var flyoutElement = document.querySelector(base_element);
			if (!flyoutElement) return;

			var singleDisplay = flyoutElement.getAttribute('data-single') || '';
			if (singleDisplay == '1') {
				var cookie_name = "essbOptinFlyout";
				var cookieSet = essbGetCookie(cookie_name);
				if (cookieSet == "yes") { return; }
				essbSetCookie(cookie_name, "yes", 14);
			}

			var win_width = window.innerWidth;

			var base_width = 500;
			if (win_width < base_width) { base_width = win_width - 60; }

			flyoutElement.style.width = base_width + 'px';

			slideDown(flyoutElement, 400);

			flyoutElement.classList.add('active-flyout');

			optin_triggered = true;
			// integration with Conversions Pro
			if (typeof (essbSubscribeProLog) != 'undefined') {
				var flyoutPositionContainer = document.querySelector(base_element + ' .essb-subscribe-form-content'),
					position = flyoutPositionContainer ? flyoutPositionContainer.getAttribute('data-position') || '' : '',
					design = flyoutPositionContainer ? flyoutPositionContainer.getAttribute('data-design') || '' : '';
				essbSubscribeProLog('subscribe_conversion_loaded', position, design);
			}
		}

		var essb_optinflyout_close = function () {

			var flyoutActiveEls = document.querySelectorAll('.active-flyout');
			for (var f = 0; f < flyoutActiveEls.length; f++) fadeOut(flyoutActiveEls[f], 200);
			for (var fCls = 0; fCls < flyoutActiveEls.length; fCls++) flyoutActiveEls[fCls].classList.remove('active-flyout');
		}

		var essb_booster_exit = function (e) {
			e = e || window.event;

			if (!e) return;

			var from = e.relatedTarget || e.toElement;

			// Reliable, works on mouse exiting window and user switching active program
			if (!from || from.nodeName === "HTML") {
				essb_optin_flyout_show('exit');
			}
		}

		if (document.querySelector('.essb-optinflyout-exit'))
			document.addEventListener('mouseout', essb_booster_exit);

		var essb_flyout_scroll = function () {
			if (optin_triggered) { return; }

			var current_pos = window.pageYOffset || document.documentElement.scrollTop;
			var height = document.documentElement.scrollHeight - window.innerHeight;
			var percentage = current_pos / height * 100;

			if (percentage > optin_percent && optin_percent > 0) {
				essb_optin_flyout_show('scroll');
			}
		}

		var flyoutScrollTrigger = document.querySelector('.essb-optinflyout-scroll');
		if (flyoutScrollTrigger) {
			optin_percent = flyoutScrollTrigger.getAttribute("data-scroll") || "";
			optin_percent = parseFloat(optin_percent);
			window.addEventListener('scroll', essb_flyout_scroll);
		}

		var flyoutTimeTrigger = document.querySelector('.essb-optinflyout-time');
		if (flyoutTimeTrigger) {
			optin_time = flyoutTimeTrigger.getAttribute("data-delay") || "";
			optin_time = parseFloat(optin_time);
			optin_time = optin_time * 1000;
			setTimeout(function () { essb_optin_flyout_show('time'); }, optin_time);
		}

		var flyoutOverlays = document.querySelectorAll('.essb-optinflyout-overlay');
		for (var flOv = 0; flOv < flyoutOverlays.length; flOv++) {
			flyoutOverlays[flOv].addEventListener('click', function (e) {
				e.preventDefault();

				essb_optinflyout_close();
			});
		}

		var flyoutCloseButtons = document.querySelectorAll('.essb-optinflyout-close');
		for (var flCl = 0; flCl < flyoutCloseButtons.length; flCl++) {
			flyoutCloseButtons[flCl].addEventListener('click', function (e) {
				e.preventDefault();

				essb_optinflyout_close();
			});
		}

		/**
		 * Locker form
		 */
		var locker_optin_triggered = false,
			locker_optin_percent = 0,
			locker_optin_time = 0,
			locker_cookie_name = 'essb_optin_locker_unlocked',
			pendingUnlockOnSubscribe = window.pendingUnlockOnSubscribe = false;

		var essb_optin_locker_unlock = window.essb_optin_locker_unlock = function () {
			essb_optinlocker_close();

			var lockerElement = document.querySelector('.essb-optinlocker'),
				unlockLen = lockerElement ? lockerElement.getAttribute('data-unlock') || '' : '';
			if (!Number(unlockLen)) unlockLen = 90;
			essbSetCookie(locker_cookie_name, "yes", unlockLen);
		};

		var essb_optin_locker_show = function (event) {

			if (locker_optin_triggered) return;

			var base_element = '.essb-optinlocker-' + event;
			var base_overlay_element = '.essb-optinlocker-overlay-' + event;

			var lockerElement = document.querySelector(base_element);
			if (!lockerElement) return;

			// check if it is unlocked
			if (essbGetCookie(locker_cookie_name) == 'yes') return;

			var win_width = window.innerWidth;

			var base_width = 700;
			if (win_width < base_width) { base_width = win_width - 60; }

			lockerElement.style.width = base_width + 'px';
			center(lockerElement);

			var lockerOverlay = document.querySelector(base_overlay_element);
			fadeIn(lockerElement, 400);
			fadeIn(lockerOverlay, 200);

			lockerElement.classList.add('active-locker');
			if (lockerOverlay) lockerOverlay.classList.add('active-locker-overlay');
			document.body.classList.add('removeScroll');

			locker_optin_triggered = true;
			window.pendingUnlockOnSubscribe = true;

			// integration with Conversions Pro
			if (typeof (essbSubscribeProLog) != 'undefined') {
				var lockerPositionContainer = document.querySelector(base_element + ' .essb-subscribe-form-content'),
					position = lockerPositionContainer ? lockerPositionContainer.getAttribute('data-position') || '' : '',
					design = lockerPositionContainer ? lockerPositionContainer.getAttribute('data-design') || '' : '';
				essbSubscribeProLog('subscribe_conversion_loaded', position, design);
			}
		}

		var essb_optinlocker_close = function () {
			var lockerActiveEls = document.querySelectorAll('.active-locker');
			for (var l = 0; l < lockerActiveEls.length; l++) fadeOut(lockerActiveEls[l], 200);
			for (var lCls = 0; lCls < lockerActiveEls.length; lCls++) lockerActiveEls[lCls].classList.remove('active-locker');

			var lockerOverlayEls = document.querySelectorAll('.active-locker-overlay');
			for (var lOv = 0; lOv < lockerOverlayEls.length; lOv++) fadeOut(lockerOverlayEls[lOv], 400);
			for (var lOvCls = 0; lOvCls < lockerOverlayEls.length; lOvCls++) lockerOverlayEls[lOvCls].classList.remove('active-locker-overlay');
			document.body.classList.remove('removeScroll');
		}

		var essb_optinlocker_scroll = function () {
			if (locker_optin_triggered) { return; }
			var current_pos = window.pageYOffset || document.documentElement.scrollTop;
			var height = document.documentElement.scrollHeight - window.innerHeight;
			var percentage = current_pos / height * 100;

			if (percentage > locker_optin_percent && locker_optin_percent > 0) {
				essb_optin_locker_show('scroll');
			}
		}

		var lockerScrollTrigger = document.querySelector('.essb-optinlocker-scroll');
		if (lockerScrollTrigger) {
			locker_optin_percent = lockerScrollTrigger.getAttribute("data-scroll") || "";
			locker_optin_percent = parseFloat(locker_optin_percent);
			window.addEventListener('scroll', essb_optinlocker_scroll);
		}

		var lockerTimeTrigger = document.querySelector('.essb-optinlocker-time');
		if (lockerTimeTrigger) {
			locker_optin_time = lockerTimeTrigger.getAttribute("data-delay") || "";
			locker_optin_time = parseFloat(locker_optin_time);
			locker_optin_time = locker_optin_time * 1000;
			setTimeout(function () { essb_optin_locker_show('time'); }, locker_optin_time);
		}

		var lockerCloseButtons = document.querySelectorAll('.essb-optinlocker-close');
		for (var lc = 0; lc < lockerCloseButtons.length; lc++) {
			lockerCloseButtons[lc].addEventListener('click', function (e) {
				e.preventDefault();
				essb_optinlocker_close();
			});
		}

		/**
		 * Subscribe reCaptcha		
		 */
		var captchaElements = document.querySelectorAll('.essb-subscribe-captcha');
		for (var cap = 0; cap < captchaElements.length; cap++) {
			let captchaId = captchaElements[cap].getAttribute('id') || '';
			if (captchaId == '') continue;

			// Maybe load reCAPTCHA.
			if (typeof (essb_subscribe_recaptcha) != 'undefined' && essb_subscribe_recaptcha && essb_subscribe_recaptcha.recaptchaSitekey) {
				setTimeout(function () {
					grecaptcha.render(essb_subscribe_recaptcha.turnstile ? '#' + captchaId : captchaId, {
						sitekey: essb_subscribe_recaptcha.recaptchaSitekey
					});
				}, 500);
			}
		}

	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbSubscribeReady);
	} else {
		essbSubscribeReady();
	}
})();