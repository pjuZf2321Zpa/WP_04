/**
 * Pinterest Pro - WooCommerce Product Images Pin Button
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 10.x
 */
(function () {
	"use strict";

	var init = function (retries) {
		retries = retries || 0;

		var config = window.essbPinProWoocommerce,
			container = document.querySelector('.essb-pinterest-wc-container'),
			button = container ? container.querySelector('.essb-pinterest-wc-btn') : null,
			gallery = document.querySelector('.woocommerce-product-gallery');

		// The module config is printed by the plugin in the page head. Depending on the
		// optimized loading mode the script can load before the config is available.
		// The gallery may also be rendered after the document is ready. Retry until
		// everything needed is present.
		if (typeof config === 'undefined' || !container || !button || !gallery) {
			if ((container || typeof config !== 'undefined') && retries < 50) {
				setTimeout(function () { init(retries + 1); }, 200);
			}
			return;
		}

		// Detect the gallery structure. Themes like WoodMart (and other swiper based
		// galleries) use a different layout: the active slide is marked with the
		// "wd-active" class and the thumbnail rail lives in its own container. Standard
		// WooCommerce themes use flexslider classes. Standard themes keep their default
		// behavior - the WoodMart handling is an additional detection layer.
		var layout = gallery.querySelector('.wd-carousel-container.wd-gallery-images')
			? {
				woodmart: true,
				positionTarget: gallery.querySelector('.wd-carousel-container.wd-gallery-images'),
				thumbSelector: '.wd-gallery-thumb .wd-carousel-item'
			}
			: {
				woodmart: false,
				thumbSelector: '.flex-control-thumbs li'
			};

		// get the URL of the currently displayed gallery image
		var getCurrentImageUrl = function () {
			var img = null;

			if (layout.woodmart) {
				// WoodMart marks the visible slide with "wd-active". Use the full size
				// image (data-large_image/data-src) for the Pinterest share and ignore
				// the duplicated zoom image that WoodMart injects inside each slide.
				var slide = gallery.querySelector('.wd-gallery-images .wd-carousel-item.wd-active .woocommerce-product-gallery__image img');
				img = slide && !slide.classList.contains('zoomImg') ? slide : null;

				if (!img) {
					img = gallery.querySelector('.wd-gallery-images .woocommerce-product-gallery__image img:not(.zoomImg)');
				}

				if (img) {
					return img.getAttribute('data-large_image') || img.getAttribute('data-src') || img.getAttribute('src') || '';
				}
			} else {
				// Standard WooCommerce flexslider gallery - keep the default behavior.
				var activeSlide = gallery.querySelector('.flex-active-slide');
				if (activeSlide) {
					var activeImg = activeSlide.querySelector('img');
					if (activeImg) return activeImg.getAttribute('src') || activeImg.getAttribute('data-src') || '';
				}

				var mainImg = gallery.querySelector('.woocommerce-product-gallery__image img');
				if (mainImg) return mainImg.getAttribute('src') || mainImg.getAttribute('data-src') || '';
			}

			return '';
		};

		// position the button over the main gallery image
		var positionButton = function () {
			if (!gallery.contains(container)) {
				container.classList.add('essb-pinterest-wc-position-' + (config.position || 'top-right'));
				container.classList.add('essb-pinterest-wc-visibility-' + (config.visibility || 'visible'));

				if (layout.woodmart) {
					// WoodMart renders the thumbnail rail in the same gallery element, so
					// position the button inside the main image container only.
					layout.positionTarget.style.position = 'relative';
					layout.positionTarget.insertBefore(container, layout.positionTarget.firstChild);
				} else {
					var wrapper = gallery.querySelector('.woocommerce-product-gallery__wrapper'),
						trigger = gallery.querySelector('.woocommerce-product-gallery__trigger');

					if (trigger) {
						gallery.insertBefore(container, trigger);
					} else if (wrapper) {
						gallery.insertBefore(container, wrapper);
					} else {
						gallery.insertBefore(container, gallery.firstChild);
					}
				}
			}

			container.style.display = 'block';
		};

		// force the button shape chosen in the settings
		var applyButtonShape = function () {
			var shape = config.button_shape || '';

			if (shape === 'square') {
				button.style.borderRadius = '0';
			} else if (shape === 'rounded') {
				button.style.borderRadius = '5px';
			} else if (shape === 'round') {
				button.style.borderRadius = '50px';
			}
		};

		// add the shadow effect when enabled in the settings
		var applyButtonShadow = function () {
			if (config.button_shadow) {
				button.classList.add('essb-pinterest-wc-btn-shadow');
			}
		};

		// share the current product image on Pinterest
		var openPinWindow = function (e) {
			e.preventDefault();
			e.stopPropagation();

			var currentImage = getCurrentImageUrl(),
				pinUrl = button.getAttribute('data-pin-url') || '';

			if (currentImage && pinUrl) {
				window.open(pinUrl + '&media=' + encodeURIComponent(currentImage), '_blank', 'width=750,height=700,scrollbars=yes,resizable=yes');
			}
		};

		button.addEventListener('click', openPinWindow);

		applyButtonShape();
		applyButtonShadow();

		positionButton();

		// update the button when the gallery image changes
		var updateTimer = null,
			scheduleUpdate = function () {
				if (updateTimer) clearTimeout(updateTimer);
				updateTimer = setTimeout(positionButton, 100);
			};

		var observer = new MutationObserver(scheduleUpdate);
		observer.observe(gallery, { childList: true, subtree: true, attributes: true });

		gallery.addEventListener('click', function (e) {
			if (e.target.closest && e.target.closest(layout.thumbSelector)) scheduleUpdate();
		});
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () { init(0); });
	} else {
		init(0);
	}
})();
