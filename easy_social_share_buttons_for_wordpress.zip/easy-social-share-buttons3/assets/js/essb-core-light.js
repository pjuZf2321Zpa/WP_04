﻿/**
 * Easy Social Share Buttons for WordPress Core Javascript
 *
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	/**
	 * Easy Social Share Buttons for WordPress
	 *
	 * @package EasySocialShareButtons
	 * @since 5.0
	 * @author appscreo
	 */
	var essb = window.essb = {};

	var debounce = function (func, wait) {
		var timeout, args, context, timestamp;
		return function () {
			context = this;
			args = [].slice.call(arguments, 0);
			timestamp = new Date();
			var later = function () {
				var last = (new Date()) - timestamp;
				if (last < wait) {
					timeout = setTimeout(later, wait - last);
				} else {
					timeout = null;
					func.apply(context, args);
				}
			};
			if (!timeout) {
				timeout = setTimeout(later, wait);
			}
		};
	};

	var isElementInViewport = function (el) {
		if (!el) return false;
		var rect = el.getBoundingClientRect();
		return (
			rect.top >= 0 &&
			rect.left >= 0 &&
			rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
			rect.right <= (window.innerWidth || document.documentElement.clientWidth)
		);
	};

	var isVisibleSelector = function (selector) {
		var element = document.querySelector(selector);
		if (!element) return false;
		var top_of_element = element.getBoundingClientRect().top + window.scrollY;
		var bottom_of_element = top_of_element + element.offsetHeight;
		var bottom_of_screen = window.scrollY + window.innerHeight;
		var top_of_screen = window.scrollY;

		if ((bottom_of_screen > top_of_element) && (top_of_screen < bottom_of_element)) {
			return true;
		} else {
			return false;
		}
	};

	var fadeIn = function (element, duration) {
		if (!element) return;
		var durationMs = duration ? duration : 400;
		element.style.opacity = '0';
		element.style.display = 'block';
		element.style.transition = 'opacity ' + durationMs + 'ms ease';
		requestAnimationFrame(function () {
			element.style.opacity = '1';
		});
	};

	var fadeOut = function (element, duration) {
		if (!element) return;
		var durationMs = duration ? duration : 400;
		element.style.opacity = '1';
		element.style.transition = 'opacity ' + durationMs + 'ms ease';
		requestAnimationFrame(function () {
			element.style.opacity = '0';
		});
		window.setTimeout(function () {
			element.style.display = 'none';
		}, durationMs);
	};

	var slideUp = function (element, duration) {
		if (!element) return;
		var durationMs = duration;
		if (durationMs == 'fast') durationMs = 200;
		if (!durationMs) durationMs = 400;
		element.style.height = element.offsetHeight + 'px';
		element.style.overflow = 'hidden';
		element.style.transition = 'height ' + durationMs + 'ms ease';
		requestAnimationFrame(function () {
			element.style.height = '0px';
		});
		window.setTimeout(function () {
			element.style.display = 'none';
		}, durationMs);
	};

	var slideDown = function (element, duration) {
		if (!element) return;
		var durationMs = duration;
		if (durationMs == 'fast') durationMs = 200;
		if (!durationMs) durationMs = 400;
		element.style.display = 'block';
		element.style.height = '0px';
		element.style.overflow = 'hidden';
		element.style.transition = 'height ' + durationMs + 'ms ease';
		requestAnimationFrame(function () {
			element.style.height = element.scrollHeight + 'px';
		});
		window.setTimeout(function () {
			element.style.height = '';
			element.style.overflow = '';
			element.style.transition = '';
		}, durationMs);
	};

	var center = function (element) {
		if (!element) return;
		if (window.getComputedStyle(element).display === 'none') {
			element.style.display = 'block';
		}
		var top = (window.innerHeight - element.offsetHeight) / 2;
		var left = (window.innerWidth - element.offsetWidth) / 2;
		element.style.position = 'fixed';
		element.style.margin = '0';
		element.style.top = (top > 0 ? top : 0) + 'px';
		element.style.left = (left > 0 ? left : 0) + 'px';
	};

	essb.add_event = function (eventID, user_function) {
		if (!essb.events) essb.events = {};
		essb.events[eventID] = user_function;
	};

	essb.trigger = function (eventID, options) {
		if (!essb.events) return;
		if (essb.events[eventID]) essb.events[eventID](options);
	};

	essb.window = function (url, service, instance, trackingOnly) {
		var element = document.querySelector('.essb_' + instance),
			instance_post_id = element ? (element.getAttribute('data-essb-postid') || '') : '',
			instance_position = element ? (element.getAttribute('data-essb-position') || '') : '',
			wnd,
			isMobile = window.innerWidth <= 1024 ? true : false,
			keyWin = 'essb_share_window' + (isMobile) + '-' + (Date.now()).toString();

		var w = (service == 'twitter') ? '500' : '800',
			h = (service == 'twitter') ? '300' : '500',
			left = (screen.width / 2) - (Number(w) / 2),
			top = (screen.height / 2) - (Number(h) / 2);

		if (typeof essbShareWindowURLFilter != 'undefined')
			url = essbShareWindowURLFilter(service, url, instance_post_id, instance_position);

		if (!trackingOnly)
			wnd = window.open(url, keyWin, "height=" + (service == 'twitter' ? '500' : '500') + ",width=" + (service == 'twitter' ? '500' : '800') + ",resizable=1,scrollbars=yes,top=" + top + ",left=" + left);

		if (typeof (essb_settings) != "undefined") {
			if (essb_settings.essb3_stats) {
				essb.handleInternalStats(service, instance_post_id, instance);
			}

			if (essb_settings.essb3_ga)
				essb_ga_tracking(service, url, instance_position);

			if (essb_settings.essb3_ga_ntg && typeof (gtag) != 'undefined') {
				gtag('event', 'social share', {
					'event_category': 'NTG social',
					'event_label': service,
					'non_interaction': false
				});
			}
		}

		if (typeof (essb_settings) != 'undefined') {
			if (typeof (essb_settings.stop_postcount) == 'undefined') essb_self_postcount(service, instance_post_id);
		}

		if (typeof (essb_abtesting_logger) != "undefined")
			essb_abtesting_logger(service, instance_post_id, instance);

		if (typeof (essb_conversion_tracking) != 'undefined')
			essb_conversion_tracking(service, instance_post_id, instance);

		if (!trackingOnly && wnd)
			var pollTimer = window.setInterval(function () {
				if (wnd.closed !== false) {
					window.clearInterval(pollTimer);
					essb_smart_onclose_events(service, instance_post_id);

					if (instance_position == 'booster' && typeof (essb_booster_close_from_action) != 'undefined')
						essb_booster_close_from_action();
				}
			}, 200);
	};

	essb.share_window = function (url, custom_position, service) {
		var w = '800', h = '500', left = (screen.width / 2) - (Number(w) / 2), top = (screen.height / 2) - (Number(h) / 2);
		wnd = window.open(url, "essb_share_window", "height=" + '500' + ",width=" + '800' + ",resizable=1,scrollbars=yes,top=" + top + ",left=" + left);

		if (typeof (essb_settings) != "undefined") {
			if (essb_settings.essb3_stats) {
				essb.handleLogInternalStats(service, essb_settings["post_id"] || '', custom_position);
			}

			if (essb_settings.essb3_ga)
				essb_ga_tracking(service, url, custom_position);

			if (essb_settings.essb3_ga_ntg && gtag) {
				gtag('event', 'social share', {
					'event_category': 'NTG social',
					'event_label': service,
					'non_interaction': false
				});
			}
		}
	};

	essb.fbmessenger = function (url, saltKey) {
		var isMobile = window.innerWidth <= 1024 ? true : false,
			cmd = 'fb-messenger://share/?link=' + url;

		if (isMobile) {
			window.open(cmd, "_self");
			essb.tracking_only('', 'messenger', saltKey, true);
		}
		else {
			essb.window(cmd, 'messenger', saltKey);
		}

		return false;
	};

	essb.whatsapp = function (url, saltKey) {
		var isMobile = window.innerWidth <= 1024 ? true : false,
			cmd = '';

		if (isMobile) cmd = 'whatsapp://send?text=' + url;
		else cmd = 'https://web.whatsapp.com/send?text=' + url;
		if (isMobile) {
			window.open(cmd, "_self");
			essb.tracking_only('', 'whatsapp', saltKey, true);
		}
		else {
			essb.window(cmd, 'whatsapp', saltKey);
		}

		return false;
	};

	essb.sms = function (url, saltKey) {
		var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream,
			cmd = 'sms:' + (iOS ? '&' : '?') + 'body=' + url;
		window.open(cmd, "_self");
		essb.tracking_only('', 'sms', saltKey, true);

		return false;
	};

	essb.tracking_only = function (url, service, instance, afterShare) {
		if (url == '')
			url = document.URL;

		essb.window(url, service, instance, true);

		var element = document.querySelector('.essb_' + instance),
			instance_position = element ? (element.getAttribute('data-essb-position') || '') : '';

		if (afterShare) {
			setTimeout(function () {
				var instanceEl = document.querySelector('.essb_' + instance),
					instance_post_id = instanceEl ? (instanceEl.getAttribute('data-essb-postid') || '') : '';
				essb_smart_onclose_events(service, instance_post_id);

				if (instance_position == 'booster' && typeof (essb_booster_close_from_action) != 'undefined')
					essb_booster_close_from_action();
			}, 1500);
		}
	};

	essb.pinterest_picker = function (instance) {
		essb.tracking_only('', 'pinterest', instance);
		var e = document.createElement('script');
		e.setAttribute('type', 'text/javascript');
		e.setAttribute('charset', 'UTF-8');
		e.setAttribute('src', '//assets.pinterest.com/js/pinmarklet.js?r=' + Math.random() * 99999999);
		document.body.appendChild(e);
	};

	essb.print = function (instance) {
		essb.tracking_only('', 'print', instance);
		window.print();
	};

	essb.setCookie = function (cname, cvalue, exdays) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires=" + d.toGMTString();
		document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
	};

	essb.getCookie = function (cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i].trim();
			if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
		}
		return "";
	};

	essb.toggle_more = function (unique_id) {
		if (essb['is_morebutton_clicked']) {
			essb.toggle_less(unique_id);
			return;
		}
		var container = document.querySelector('.essb_' + unique_id);
		if (container) {
			var afterMoreEls = container.querySelectorAll('.essb_after_more');
			for (var i = 0; i < afterMoreEls.length; i++) {
				afterMoreEls[i].classList.remove('essb_after_more');
				afterMoreEls[i].classList.add('essb_before_less');
			}
		}

		var moreButton = null, moreEl = document.querySelector('.essb_' + unique_id + ' .essb_link_more');
		if (moreEl) {
			moreButton = true;
			moreEl.style.display = 'none';
			moreEl.classList.add('essb_hide_more_sidebar');
		}

		var moreElDots = document.querySelector('.essb_' + unique_id + ' .essb_link_more_dots');
		if (moreElDots) {
			moreButton = true;
			moreElDots.style.display = 'none';
			moreElDots.classList.add('essb_hide_more_sidebar');
		}

		essb['is_morebutton_clicked'] = true;
	};

	essb.toggle_less = function (unique_id) {
		essb['is_morebutton_clicked'] = false;
		var container = document.querySelector('.essb_' + unique_id);
		if (container) {
			var beforeLessEls = container.querySelectorAll('.essb_before_less');
			for (var i = 0; i < beforeLessEls.length; i++) {
				beforeLessEls[i].classList.add('essb_after_more');
				beforeLessEls[i].classList.remove('essb_before_less');
			}
		}

		var moreEl = document.querySelector('.essb_' + unique_id + ' .essb_link_more');
		if (moreEl) {
			moreEl.style.display = '';
			moreEl.classList.remove('essb_hide_more_sidebar');
		}

		var moreElDots = document.querySelector('.essb_' + unique_id + ' .essb_link_more_dots');
		if (moreElDots) {
			moreElDots.style.display = '';
			moreElDots.classList.remove('essb_hide_more_sidebar');
		}
	};

	essb.toggle_more_popup = function (unique_id) {
		if (typeof essb_open_morepopup_window != 'undefined')
			essb_open_morepopup_window(unique_id);
	};

	essb.toggle_less_popup = function (unique_id) {
		if (typeof essb_close_morepopup_window != 'undefined')
			essb_close_morepopup_window(unique_id);
	};

	essb.subscribe_popup_close = function (key) {
		fadeOut(document.querySelector('.essb-subscribe-form-' + key), 400);
		fadeOut(document.querySelector('.essb-subscribe-form-overlay-' + key), 400);
	};

	essb.toggle_subscribe = function (key) {
		var formEl = document.querySelector('.essb-subscribe-form-' + key);
		// subscribe container does not exist
		if (!formEl) return;

		if (!essb['essb_subscribe_opened'])
			essb['essb_subscribe_opened'] = {};

		var asPopup = formEl.getAttribute("data-popup") || "";

		// it is not popup (in content methods is asPopup == "")
		if (asPopup != '1') {
			if (formEl.classList.contains("essb-subscribe-opened")) {
				slideUp(formEl, 'fast');
				formEl.classList.remove("essb-subscribe-opened");
			}
			else {
				slideDown(formEl, 'fast');
				formEl.classList.add("essb-subscribe-opened");

				if (!essb['essb_subscribe_opened'][key]) {
					essb['essb_subscribe_opened'][key] = key;
					essb.tracking_only('', 'subscribe', key, true);
				}
			}
		}
		else {
			var win_width = window.innerWidth;
			var base_width = 600;

			if (win_width < base_width) { base_width = win_width - 40; }

			formEl.style.width = base_width + 'px';
			center(formEl);

			fadeIn(formEl, 400);
			fadeIn(document.querySelector('.essb-subscribe-form-overlay-' + key), 200);
		}
	};

	essb.is_after_comment = function () {
		var addr = window.location.href;

		return addr.indexOf('#comment') > -1 ? true : false;
	};

	essb.copy_link_direct = function (currentLocation) {
		essb_copy_link_direct(currentLocation);
	};

	essb.copy_link = function (instance_id, user_href) {
		if (essb_settings && essb_settings.copybutton_direct) {
			let currentLocation = window.location.href;

			if (instance_id && document.querySelector('.essb_' + instance_id)) {
				let instance_url = document.querySelector('.essb_' + instance_id).getAttribute('data-essb-url') || '';
				if (instance_url != '') currentLocation = instance_url;
			}

			if (user_href && user_href != '') currentLocation = user_href;

			essb.copy_link_direct(currentLocation);
			return;
		}
		essb_open_copy_link_window(instance_id, user_href);
	};

	essb.responsiveEventsCanRun = function (element) {
		var hideOnMobile = element.classList.contains('essb_mobile_hidden'),
			hideOnDesktop = element.classList.contains('essb_desktop_hidden'),
			hideOnTablet = element.classList.contains('essb_tablet_hidden'),
			windowWidth = window.innerWidth,
			canRun = true;

		if (windowWidth <= 768 && hideOnMobile) canRun = false;
		if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
		if (windowWidth > 1100 && hideOnDesktop) canRun = false;

		if (!element) canRun = false;

		return canRun;
	};

	essb.handleInternalStats = function (service, postID, instance) {
		let element = document.querySelector('.essb_' + instance);
		if (element) {
			let instance_postion = element.getAttribute('data-essb-position') || '',
				instance_template = element.getAttribute('data-essb-template') || '',
				instance_button = element.getAttribute('data-essb-button-style') || '',
				instance_counters = element.classList.contains('essb_counters'),
				instance_nostats = element.classList.contains('essb_nostats');

			if (instance_nostats) return;

			essb.logInternalStats(service, postID, instance_postion, instance_template, instance_button, instance_counters);
		}
	}

	essb.handleLogInternalStats = function (service, postId, position) {
		essb.logInternalStats(service, postId, position, position, position, false);
	}

	essb.logInternalStats = function (service, postId, position, template, senderButton, usingCounters) {
		let instanceIsMobile = false;

		if ((/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i).test(navigator.userAgent))
			instanceIsMobile = true;

		if (typeof (essb_settings) != "undefined") {
			fetch(essb_settings.ajax_url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'Accept': '*/*'
				},
				body: new URLSearchParams({
					'action': 'essb_stat_log',
					'post_id': postId,
					'service': service,
					'template': template,
					'mobile': instanceIsMobile,
					'position': position,
					'button': senderButton,
					'counter': usingCounters,
					'nonce': essb_settings.essb3_nonce
				})
			}).then(response => response.text());
		}
		else {
		}
	};

	window.essb = essb;

	/**
	 * Core Specific Functions & Events
	 */

	var essb_int_value = function (value) {
		value = parseInt(value);

		if (isNaN(value) || !isFinite(value)) value = 0;
		return value;
	}

	var essb_self_postcount = function (service, countID) {
		if (typeof (essb_settings) != "undefined") {
			countID = String(countID);

			fetch(essb_settings.ajax_url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'Accept': '*/*'
				},
				body: new URLSearchParams({
					'action': 'essb_self_postcount',
					'post_id': countID,
					'service': service,
					'nonce': essb_settings.essb3_nonce
				})
			}).then(function (data) { });
		}
	};

	var essb_smart_onclose_events = function (service, postID) {
		// 7.0 - trigger only on selected networks (when such are present)
		if (essb_settings && essb_settings['aftershare_networks']) {
			var workingNetworks = essb_settings['aftershare_networks'] != '' ? essb_settings['aftershare_networks'].split(',') : [];
			if (workingNetworks.indexOf(service) == -1) return;
		}
		else {
			// 6.0.3 - adding email & mail as also ignoring options
			if (service == "subscribe" || service == "comments" || service == 'email' || service == 'mail') return;
		}

		if (service == "subscribe" || service == "comments" || service == 'email' || service == 'mail') return;

		if (typeof (essbasc_popup_show) == 'function')
			essbasc_popup_show();

		if (typeof essb_acs_code == 'function')
			essb_acs_code(service, postID);

		var afterShareForm = document.querySelector('.essb-aftershare-subscribe-form');
		if (afterShareForm) {
			var key = afterShareForm.getAttribute('data-salt') || '';
			if (key != '') essb.toggle_subscribe(key);
		}
	};

	var essb_ga_tracking = function (service, url, position) {
		var essb_ga_type = essb_settings.essb3_ga_mode;

		if ('ga' in window && window.ga !== undefined && typeof window.ga === 'function') {
			if (essb_ga_type == "extended")
				ga('send', 'event', 'social', service + ' ' + position, url);

			else
				ga('send', 'event', 'social', service, url);
		}

		if (essb_ga_type == "layers" && typeof (dataLayer) != "undefined") {
			dataLayer.push({
				'service': service,
				'position': position,
				'url': url,
				'event': 'social'
			});
		}
	};

	/** 
	 * After Share Events functions
	 */
	var essbasc_popup_show = window.essbasc_popup_show = function () {
		var popupEl = document.querySelector('.essbasc-popup');
		if (!popupEl) return;
		if (essb.getCookie('essb_aftershare')) return; // cookie already set for visible events

		var cookie_len = (typeof (essbasc_cookie_live) != "undefined") ? essbasc_cookie_live : 7;
		if (parseInt(cookie_len) == 0) { cookie_len = 7; }

		var win_width = window.innerWidth, base_width = 800,
			userwidth = popupEl.getAttribute("data-popup-width") || '',
			singleShow = popupEl.getAttribute("data-single") || '';

		if (Number(userwidth) && Number(userwidth) > 0) base_width = userwidth;
		if (win_width < base_width) base_width = win_width - 60;

		popupEl.style.width = base_width + 'px';
		center(popupEl);
		fadeIn(popupEl, 300);
		fadeIn(document.querySelector('.essbasc-popup-shadow'), 100);

		if (singleShow == 'true') essb.setCookie('essb_aftershare', "yes", cookie_len);
	};

	var essbasc_popup_close = window.essbasc_popup_close = function () {
		fadeOut(document.querySelector('.essbasc-popup'), 200);
		fadeOut(document.querySelector('.essbasc-popup-shadow'), 100);
	};

	function coreReady() {

		/** 
		 * Reveal the social followers counter that comes with a transition effect
		 */
		var fcSidebar = document.querySelector('.essbfc-container-sidebar');
		if (fcSidebar) {
			var fcEls = document.querySelectorAll('.essbfc-container-sidebar');
			for (var i = 0; i < fcEls.length; i++) {
				if (fcEls[i].classList.contains("essbfc-container-sidebar-transition")) {
					fcEls[i].classList.remove("essbfc-container-sidebar-transition");
				}
			}
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', coreReady);
	} else {
		coreReady();
	}

})();