/**
 * Hero Share
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 *
 * VanillaJS (no jQuery), self-contained. Loaded from assets/parts/js/.
 */
(function () {
	"use strict";

	var heroshareTriggeredOnScroll = false;
	var heroshareTriggerPercent = -1;
	var heroshareTriggerEnd = false;
	var heroshareTriggerExit = false;
	var heroImageWidth = 0;

	var center = function (element) {
		if (!element) return;
		var top = (window.innerHeight - element.offsetHeight) / 2;
		var left = (window.innerWidth - element.offsetWidth) / 2;
		element.style.position = 'fixed';
		element.style.margin = '0';
		element.style.top = (top > 0 ? top : 0) + 'px';
		element.style.left = (left > 0 ? left : 0) + 'px';
	};

	var fadeIn = function (element, duration) {
		if (!element) return;
		element.style.opacity = '0';
		element.style.display = 'block';
		element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
		requestAnimationFrame(function () {
			element.style.opacity = '1';
		});
	};

	var fadeOut = function (element, duration) {
		if (!element) return;
		element.style.opacity = '1';
		element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
		requestAnimationFrame(function () {
			element.style.opacity = '0';
		});
		window.setTimeout(function () {
			element.style.display = 'none';
		}, duration ? duration : 400);
	};

	function essbSetCookie(cname, cvalue, exdays) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires=" + d.toGMTString();
		document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
	}

	function essbGetCookie(cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i].trim();
			if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
		}
		return "";
	}

	function get_url_parameter(param_name) {
		var page_url = window.location.search.substring(1);
		var url_variables = page_url.split('&');
		for (var i = 0; i < url_variables.length; i++) {
			var curr_param_name = url_variables[i].split('=');
			if (curr_param_name[0] == param_name) {
				return curr_param_name[1];
			}
		}
	}

	var essb_heroshare_exit = function (e) {
		if (heroshareTriggerExit) { return; }

		e = e || window.event;
		if (!e) return;

		var from = e.relatedTarget || e.toElement;

		if (!from || from.nodeName === "HTML") {
			heroshareTriggerExit = true;
			essb_heroshare_show();
		}
	};

	var essb_heroshare_onscroll = function () {
		if (heroshareTriggeredOnScroll) { return; }

		var current_pos = window.pageYOffset || document.documentElement.scrollTop;
		var height = document.documentElement.scrollHeight - window.innerHeight;
		var percentage = current_pos / height * 100;

		if (!heroshareTriggerEnd) {
			if (percentage > heroshareTriggerPercent && heroshareTriggerPercent > 0) {
				heroshareTriggeredOnScroll = true;
				essb_heroshare_show();
			}
		}
		else {
			var breakScroll = document.querySelector('.essb_break_scroll');
			if (!breakScroll) {
				var userTriggerPercent = 90;
				if (percentage > userTriggerPercent && userTriggerPercent > 0) {
					heroshareTriggeredOnScroll = true;
					essb_heroshare_show();
				}
			}
			else {
				var rect = breakScroll.getBoundingClientRect();
				var top = rect.top + (window.pageYOffset || document.documentElement.scrollTop) - parseFloat(window.getComputedStyle(breakScroll).marginTop);

				if (current_pos >= top) {
					heroshareTriggeredOnScroll = true;
					essb_heroshare_show();
				}
			}
		}
	};

	var essb_heroshare_show = function () {
		var element = document.querySelector('.essb-heroshare');
		if (!element) return;

		var popWidth = element.getAttribute("data-width") || "";
		var popHideOnClose = element.getAttribute("data-close-hide") || "";
		var popHideOnCloseAll = element.getAttribute("data-close-hide-all") || "";
		var popPostId = element.getAttribute("data-postid") || "";

		if (popHideOnClose == "1" || popHideOnCloseAll == "1") {
			var cookie_name = "";
			var base_cookie_name = "essb_heroshare_";
			if (popHideOnClose == "1") {
				cookie_name = base_cookie_name + popPostId;
				var cookieSet = essbGetCookie(cookie_name);
				if (cookieSet == "yes") { return; }
				essbSetCookie(cookie_name, "yes", 7);
			}
			if (popHideOnCloseAll == "1") {
				cookie_name = base_cookie_name + "all";
				var cookieSetAll = essbGetCookie(cookie_name);
				if (cookieSetAll == "yes") { return; }
				essbSetCookie(cookie_name, "yes", 7);
			}
		}

		var win_width = window.innerWidth;

		var base_width = 960;
		var userwidth = popWidth;
		if (Number(userwidth) && Number(userwidth) > 0) {
			base_width = userwidth;
		}

		if (win_width < base_width) { base_width = win_width - 60; }

		var image_width = heroImageWidth;
		var content_width = base_width - image_width - 50;

		var postImage = document.querySelector('.essb-heroshare-post-image');
		if (postImage) postImage.style.width = image_width + 'px';

		var postContent = document.querySelector('.essb-heroshare-post-content');
		if (postContent) postContent.style.width = content_width + 'px';

		element.style.width = base_width + 'px';
		center(element);

		fadeIn(element, 400);
		fadeIn(document.querySelector('.essb-heroshare-shadow'), 200);
	};

	var essb_heroshare_close = function () {
		fadeOut(document.querySelector('.essb-heroshare'), 400);
		fadeOut(document.querySelector('.essb-heroshare-shadow'), 400);
	};

	window.essb_heroshare_show = essb_heroshare_show;
	window.essb_heroshare_close = essb_heroshare_close;

	var essbHeroShareReady = function () {
		var element = document.querySelector('.essb-heroshare');
		if (!element) return;

		var imgEl = element.querySelector('.essb-heroshare-post-image-src');
		if (imgEl) {
			heroImageWidth = imgEl.naturalWidth;
			var heroImageHeight = imgEl.naturalHeight;
			var ratio = 200 / heroImageHeight;
			heroImageWidth = Math.round(heroImageWidth * ratio);
		}

		if ('true' == get_url_parameter('essb_heroshare')) {
			if (element.classList.contains("essb-heroshare-oncomment")) {
				essb_heroshare_show();
				return;
			}
		}

		var popOnPercent = element.getAttribute("data-load-percent") || "";
		var popAfter = element.getAttribute("data-load-time") || "";
		var popOnEnd = element.getAttribute("data-load-end") || "";
		var popManual = element.getAttribute("data-load-manual") || "";
		var popExit = element.getAttribute("data-exit-intent") || "";

		if (popManual == '1') return;

		if (popOnPercent != '' || popOnEnd == "1") {
			heroshareTriggerPercent = Number(popOnPercent);
			heroshareTriggeredOnScroll = false;
			heroshareTriggerEnd = (popOnEnd == "1") ? true : false;
			window.addEventListener('scroll', essb_heroshare_onscroll);
			return;
		}

		if (popExit == '1') {
			document.addEventListener('mouseout', essb_heroshare_exit);
			return;
		}

		if (popAfter && typeof (popAfter) != "undefined") {
			if (popAfter != '' && Number(popAfter)) {
				setTimeout(essb_heroshare_show, Number(popAfter) * 1000);
			}
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbHeroShareReady);
	} else {
		essbHeroShareReady();
	}
})();