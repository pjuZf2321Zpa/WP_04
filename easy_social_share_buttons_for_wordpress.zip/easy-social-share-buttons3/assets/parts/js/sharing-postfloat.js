/**
 * Display Methods: Float from content top (essb_displayed_float) and
 * Post Vertical Float (essb_displayed_postfloat)
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbFloatingInit);
	} else {
		essbFloatingInit();
	}

	function essbFloatingInit() {

		if (!window.debounce) {
			window.debounce = function (func, wait) {
				var timeout, args, context, timestamp;
				return function () {
					context = this;
					args = [].slice.call(arguments, 0);
					timestamp = new Date();
					var later = function () {
						var last = (new Date()) - timestamp;
						if (last < wait) {
							timeout = setTimeout(later, wait - last);
						} else {
							timeout = null;
							func.apply(context, args);
						}
					};
					if (!timeout) {
						timeout = setTimeout(later, wait);
					}
				};
			};
		}
		var debounce = window.debounce;

		var essb_int_value = function (value) {
			value = parseInt(value);
			if (isNaN(value) || !isFinite(value)) value = 0;
			return value;
		};

		var isVisibleSelector = function (selector) {
			var element = document.querySelector(selector);
			if (!element) return false;

			var top_of_element = element.getBoundingClientRect().top + window.scrollY;
			var bottom_of_element = top_of_element + element.offsetHeight;
			var bottom_of_screen = window.scrollY + window.innerHeight;
			var top_of_screen = window.scrollY;

			if ((bottom_of_screen > top_of_element) && (top_of_screen < bottom_of_element)) {
				return true;
			}
			return false;
		};

		var isElementVisible = function (element) {
			if (!element) return false;

			var top_of_element = element.getBoundingClientRect().top + window.scrollY;
			var bottom_of_element = top_of_element + element.offsetHeight;
			var bottom_of_screen = window.scrollY + window.innerHeight;
			var top_of_screen = window.scrollY;

			return (bottom_of_screen > top_of_element) && (top_of_screen < bottom_of_element);
		};

		var responsiveEventsCanRun = function (selector) {
			var element = document.querySelector(selector);
			var hideOnMobile = false,
				hideOnDesktop = false,
				hideOnTablet = false,
				windowWidth = window.innerWidth,
				canRun = true;

			if (element) {
				hideOnMobile = element.classList.contains('essb_mobile_hidden');
				hideOnDesktop = element.classList.contains('essb_desktop_hidden');
				hideOnTablet = element.classList.contains('essb_tablet_hidden');
			} else {
				return false;
			}

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		// Fade helpers (replaces jQuery fadeIn / fadeOut)
		var fadeIn = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var fadeOut = function (element, duration) {
			if (!element) return;
			element.style.opacity = '1';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '0';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, duration ? duration : 400);
		};

		/**
		 * Display Methods: Float on top (essb_displayed_float)
		 */
		var floatElement = document.querySelector('.essb_displayed_float');
		if (floatElement) {

			var computedStyle = window.getComputedStyle(floatElement);
			var marginTop = parseFloat(computedStyle.marginTop);
			if (isNaN(marginTop)) marginTop = 0;

			var floatingTop = floatElement.getBoundingClientRect().top + window.scrollY - marginTop,
				basicElementWidth = '',
				hide_float_percent = floatElement.getAttribute('data-float-hide') || '',
				custom_top_postion = floatElement.getAttribute('data-float-top') || '',
				hide_float_active = false;

			if (hide_float_percent != '' && Number(hide_float_percent) > 0) {
				hide_float_percent = parseInt(hide_float_percent);
				hide_float_active = true;
			}

			var active_custom_top = false;
			if (custom_top_postion != '' && Number(custom_top_postion) > 0) {
				custom_top_postion = parseInt(custom_top_postion);
				active_custom_top = true;
			}

			/**
			 * Hold down scroll event for floating top display method when such is present
			 * inside code
			 */
			function essbFloatingButtons() {
				var y = window.scrollY;

				if (active_custom_top)
					y -= custom_top_postion;

				var height = document.documentElement.scrollHeight - window.innerHeight;
				var percentage = y / height * 100;
				// whether that's below the form
				if (y >= floatingTop) {
					// if so, ad the fixed class
					if (basicElementWidth == '') {
						var widthOfContainer = floatElement.offsetWidth;
						basicElementWidth = widthOfContainer;
						floatElement.style.width = widthOfContainer + 'px';
					}

					floatElement.classList.add('essb_fixed');

				} else {
					// otherwise remove it
					floatElement.classList.remove('essb_fixed');
					if (basicElementWidth != '') {
						floatElement.style.width = basicElementWidth + 'px';
					}
				}

				if (hide_float_active) {
					if (percentage >= hide_float_percent && !floatElement.classList.contains('hidden-float')) {
						floatElement.classList.add('hidden-float');
						fadeOut(floatElement, 100);
						return;
					}
					if (percentage < hide_float_percent && floatElement.classList.contains('hidden-float')) {
						floatElement.classList.remove('hidden-float');
						fadeIn(floatElement, 100);
						return;
					}
				}
			} // end: essbFloatingButtons

			if (responsiveEventsCanRun('.essb_displayed_float'))
				window.addEventListener('scroll', debounce(essbFloatingButtons, 1));
		}

		/**
		 * Display Method: Post Vertical Float (essb_displayed_postfloat)
		 */
		var postfloatElement = document.querySelector('.essb_displayed_postfloat');
		if (postfloatElement) {

			var computedPostStyle = window.getComputedStyle(postfloatElement);
			var postMarginTop = parseFloat(computedPostStyle.marginTop);
			if (isNaN(postMarginTop)) postMarginTop = 0;

			var top = postfloatElement.getBoundingClientRect().top + window.scrollY - postMarginTop;
			var postfloat_always_onscreen = (postfloatElement.getAttribute('data-postfloat-stay') || '').toString() == 'true' ? true : false;
			var postfloat_fix_bottom = (postfloatElement.getAttribute('data-postfloat-fixbottom') || '').toString() == 'true' ? true : false;
			var custom_user_top = postfloatElement.getAttribute('data-postfloat-top') || '';
			var postFloatVisibleSelectors = postfloatElement.getAttribute('data-postfloat-selectors') || '',
				postFloatViewportCheck = [],
				postFloatPercentAppear = postfloatElement.getAttribute('data-postfloat-percent') || '';

			if (!Number(postFloatPercentAppear) || Number(postFloatPercentAppear) == 0) {
				postFloatPercentAppear = '';
				postfloatElement.setAttribute('data-postfloat-percent', '');
			}

			if (postFloatVisibleSelectors != '') {
				postFloatViewportCheck = postFloatVisibleSelectors.split(',');
				for (var i = 0; i < postFloatViewportCheck.length; i++) {
					if (document.querySelector(postFloatViewportCheck[i])) document.querySelector(postFloatViewportCheck[i]).classList.add('essb-postfloat-monitor');
				}
			}

			setTimeout(function () {
				postfloatElement.style.transition = 'all 0.3s linear';
				if (postFloatPercentAppear == '') postfloatElement.style.opacity = '1';
			}, 100);

			if (custom_user_top != '' && Number(custom_user_top) && !isNaN(custom_user_top)) top -= parseInt(custom_user_top);

			function essbPostVerticalFloatScroll() {
				var y = window.scrollY,
					break_top = 0,
					postFloatPercentAppear = postfloatElement.getAttribute('data-postfloat-percent') || '',
					postFloatAppearMeasure = postfloatElement.getAttribute('data-postfloat-percent-m') || '';

				var breakScrollElement = document.querySelector('.essb_break_scroll');
				if (breakScrollElement) {
					var break_position = breakScrollElement.getBoundingClientRect().top + window.scrollY;
					break_top = break_position;
					var hasCustomBreak = postfloatElement.getAttribute('data-postfloat-bottom') || '';

					if (hasCustomBreak && hasCustomBreak != '' && Number(hasCustomBreak) != 0) break_top = Number(break_top) - Number(hasCustomBreak);
				}

				if (postFloatPercentAppear != '') {
					var height = document.documentElement.scrollHeight - window.innerHeight,
						percentage = y / height * 100,
						shouldBeVisible = postFloatAppearMeasure == 'px' ? y >= Number(postFloatPercentAppear) : percentage >= Number(postFloatPercentAppear);

					if (shouldBeVisible) {
						postfloatElement.style.opacity = '1';
						postfloatElement.style.transform = 'translateY(0)';
					}
					else {
						postfloatElement.style.opacity = '0';
						postfloatElement.style.transform = 'translateY(50px)';
					}
				}

				if (y >= top) {
					postfloatElement.classList.add('essb_postfloat_fixed');

					var element_position = postfloatElement.getBoundingClientRect().top + window.scrollY;
					var element_height = postfloatElement.offsetHeight;
					var element_top = parseInt(element_position) + parseInt(element_height);

					if (!postfloat_always_onscreen) {
						if (element_top > break_top) {
							if (!postfloatElement.classList.contains("essb_postfloat_breakscroll")) {
								postfloatElement.classList.add("essb_postfloat_breakscroll");
							}
						}
						else {
							if (postfloatElement.classList.contains("essb_postfloat_breakscroll")) {
								postfloatElement.classList.remove("essb_postfloat_breakscroll");
							}
						}
					}
					else {
						var isOneVisible = false;
						var monitors = document.querySelectorAll('.essb-postfloat-monitor');
						for (var mi = 0; mi < monitors.length; mi++) {
							if (isElementVisible(monitors[mi]))
								isOneVisible = true;
						}

						if (!isOneVisible) {
							if (postfloatElement.classList.contains("essb_postfloat_breakscroll")) {
								postfloatElement.classList.remove("essb_postfloat_breakscroll");
							}

							/**
							 * Fix the postfloat at the bottom of content
							 */
							if (postfloat_fix_bottom) {
								if (element_top > break_top) {
									if (!postfloatElement.classList.contains('essb_postfloat_absolute')) {
										postfloatElement.classList.remove('essb_postfloat_fixed');
										postfloatElement.setAttribute('data-unfixed', element_top);
										postfloatElement.classList.add('essb_postfloat_absolute');
										postfloatElement.style.position = 'absolute';
										postfloatElement.style.top = ((breakScrollElement ? breakScrollElement.getBoundingClientRect().top + window.scrollY : 0) - element_height - 100) + 'px';
									}
								}
								else {
									if (postfloatElement.classList.contains('essb_postfloat_absolute')) {
										postfloatElement.classList.remove('essb_postfloat_absolute');
										postfloatElement.removeAttribute('data-unfixed');
										postfloatElement.style.position = '';
										postfloatElement.style.top = '';
										postfloatElement.classList.add('essb_postfloat_fixed');
									}
								}
							}
						}
						else {
							if (!postfloatElement.classList.contains("essb_postfloat_breakscroll")) {
								postfloatElement.classList.add("essb_postfloat_breakscroll");
							}
						}
					}
				}
				else
					// otherwise remove it
					postfloatElement.classList.remove('essb_postfloat_fixed');

			}

			if (responsiveEventsCanRun('.essb_displayed_postfloat'))
				window.addEventListener('scroll', debounce(essbPostVerticalFloatScroll, 1));

			/**
			 * Display Method: Post Vertical Float (percent appear)
			 */
			function essb_postfloat_onscroll() {
				var current_pos = window.scrollY;
				var height = document.documentElement.scrollHeight - window.innerHeight;
				var percentage = current_pos / height * 100;

				if (!document.querySelector(".essb_displayed_postfloat")) return;
				var value_appear = essb_int_value(postfloatElement.getAttribute('data-postfloat-percent') || '');

				if (value_appear > 0) {
					if (percentage >= value_appear && !postfloatElement.classList.contains("essb_active_postfloat")) {
						postfloatElement.classList.add("essb_active_postfloat");
						return;
					}

					if (percentage < value_appear && postfloatElement.classList.contains("essb_active_postfloat")) {
						postfloatElement.classList.remove("essb_active_postfloat");
						return;
					}
				}
			}

			if (responsiveEventsCanRun('.essb_displayed_postfloat')) {
				if ((typeof essb_settings !== 'undefined' && (essb_settings.postfloat_percent || '') != '') && document.querySelector(".essb_displayed_postfloat"))
					window.addEventListener('scroll', debounce(essb_postfloat_onscroll, 1));
			}
		}
	}
})();
