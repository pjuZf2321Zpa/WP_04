/**
 * Display Method: Sidebar
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbSidebarInit);
	} else {
		essbSidebarInit();
	}

	function essbSidebarInit() {

		if (!window.debounce) {
			window.debounce = function (func, wait) {
				var timeout, args, context, timestamp;
				return function () {
					context = this;
					args = [].slice.call(arguments, 0);
					timestamp = new Date();
					var later = function () {
						var last = (new Date()) - timestamp;
						if (last < wait) {
							timeout = setTimeout(later, wait - last);
						} else {
							timeout = null;
							func.apply(context, args);
						}
					};
					if (!timeout) {
						timeout = setTimeout(later, wait);
					}
				};
			};
		}
		var debounce = window.debounce;

		var essb_int_value = function (value) {
			value = parseInt(value);
			if (isNaN(value) || !isFinite(value)) value = 0;
			return value;
		};

		var isVisibleSelector = function (selector) {
			var element = document.querySelector(selector);
			if (!element) return false;

			var top_of_element = element.getBoundingClientRect().top + window.scrollY;
			var bottom_of_element = top_of_element + element.offsetHeight;
			var bottom_of_screen = window.scrollY + window.innerHeight;
			var top_of_screen = window.scrollY;

			if ((bottom_of_screen > top_of_element) && (top_of_screen < bottom_of_element)) {
				return true;
			}
			return false;
		};

		var responsiveEventsCanRun = function (selector) {
			var element = document.querySelector(selector);
			var hideOnMobile = false,
				hideOnDesktop = false,
				hideOnTablet = false,
				windowWidth = window.innerWidth,
				canRun = true;

			if (element) {
				hideOnMobile = element.classList.contains('essb_mobile_hidden');
				hideOnDesktop = element.classList.contains('essb_desktop_hidden');
				hideOnTablet = element.classList.contains('essb_tablet_hidden');
			} else {
				return false;
			}

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		// Fade helpers (replaces jQuery fadeIn / fadeOut)
		var fadeIn = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var fadeOut = function (element, duration) {
			if (!element) return;
			element.style.opacity = '1';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '0';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, duration ? duration : 400);
		};

		/**
		 * Sidebar animation reveal on load
		 */
		var sidebarTransitionEls = document.querySelectorAll('.essb_sidebar_transition');
		if (sidebarTransitionEls.length) {
			sidebarTransitionEls.forEach(function (element) {
				if (!responsiveEventsCanRun('.essb_sidebar_transition')) return;

				if (element.classList.contains('essb_sidebar_transition_slide'))
					element.classList.toggle('essb_sidebar_transition_slide');

				if (element.classList.contains('essb_sidebar_transition_fade'))
					element.classList.toggle('essb_sidebar_transition_fade');
			});
		}

		/**
		 * Reposition sidebar at the middle of page
		 */
		var sidebarMiddleEl = document.querySelector('.essb_sidebar_location_middle');
		if (sidebarMiddleEl) {
			var essbSidebarRepositionMiddle = function () {
				var heightOfSidebar = sidebarMiddleEl.offsetHeight,
					winHeight = window.innerHeight,
					top = 0;

				if (heightOfSidebar > winHeight) top = 0;
				else {
					top = Math.round((winHeight - heightOfSidebar) / 2);
				}
				sidebarMiddleEl.style.top = top + 'px';
				sidebarMiddleEl.style.opacity = '1';
			};

			essbSidebarRepositionMiddle();
			window.addEventListener('resize', debounce(essbSidebarRepositionMiddle, 1));
		}

		/**
		 * Sidebar close button
		 */
		document.querySelectorAll(".essb_link_sidebar-close a").forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();
				var links_list = link.closest('.essb_links_list') || link.parentElement.parentElement;

				links_list.querySelectorAll(".essb_item").forEach(function (item) {
					if (!item.classList.contains("essb_link_sidebar-close"))
						item.classList.toggle("essb-sidebar-closed-item");
					else
						item.classList.toggle("essb-sidebar-closed-clicked");
				});
			});
		});

		/**
		 * Sidebar appear / disappear on scroll
		 */
		var essb_sidebar_onscroll = function () {
			var current_pos = window.scrollY;
			var height = document.documentElement.scrollHeight - window.innerHeight;
			var percentage = current_pos / height * 100;

			var element = null;
			var sidebarEl = document.querySelector(".essb_displayed_sidebar");
			var sidebarRightEl = document.querySelector(".essb_displayed_sidebar_right");

			if (sidebarEl) element = sidebarEl;
			if (sidebarRightEl) element = sidebarRightEl;

			if (!element) return;

			var value_disappear = essb_int_value(element.getAttribute('data-sidebar-disappear-pos') || '');
			var value_appear = essb_int_value(element.getAttribute('data-sidebar-appear-pos') || '');
			var value_appear_unit = element.getAttribute('data-sidebar-appear-unit') || '';
			var value_contenthidden = element.getAttribute('data-sidebar-contenthidden') || '';
			if (value_appear_unit == 'px') percentage = current_pos;

			var visibleByDisplayCond = true;

			if (value_appear > 0 || value_disappear > 0) {
				visibleByDisplayCond = false;
				if (value_appear && percentage >= value_appear) visibleByDisplayCond = true;
				if (value_disappear && percentage <= value_disappear) visibleByDisplayCond = true;
			}

			// Hiding share buttons when content is visible
			if (value_contenthidden == 'yes' && (document.querySelector('.essb_displayed_top') || document.querySelector('.essb_displayed_bottom'))) {

				if ((document.querySelector('.essb_displayed_top') && isVisibleSelector('.essb_displayed_top')) ||
					(document.querySelector('.essb_displayed_bottom') && isVisibleSelector('.essb_displayed_bottom')))
					fadeOut(element, 100);
				else {
					if (visibleByDisplayCond) fadeIn(element, 100);
				}
			}

			if (value_appear > 0 && value_disappear == 0) {
				if (percentage >= value_appear && !element.classList.contains("active-sidebar")) {
					fadeIn(element, 100);
					element.classList.add("active-sidebar");
					return;
				}

				if (percentage < value_appear && element.classList.contains("active-sidebar")) {
					fadeOut(element, 100);
					element.classList.remove("active-sidebar");
					return;
				}
			}

			if (value_disappear > 0 && value_appear == 0) {
				if (percentage >= value_disappear && !element.classList.contains("hidden-sidebar")) {
					fadeOut(element, 100);
					element.classList.add("hidden-sidebar");
					return;
				}

				if (percentage < value_disappear && element.classList.contains("hidden-sidebar")) {
					fadeIn(element, 100);
					element.classList.remove("hidden-sidebar");
					return;
				}
			}

			if (value_appear > 0 && value_disappear > 0) {
				if (percentage >= value_appear && percentage < value_disappear && !element.classList.contains("active-sidebar")) {
					fadeIn(element, 100);
					element.classList.add("active-sidebar");
					return;
				}

				if ((percentage < value_appear || percentage >= value_disappear) && element.classList.contains("active-sidebar")) {
					fadeOut(element, 100);
					element.classList.remove("active-sidebar");
					return;
				}
			}
		};

		if (responsiveEventsCanRun('.essb_displayed_sidebar')) {
			var sidebarInitEl = document.querySelector('.essb_displayed_sidebar');
			var essbSidebarContentHidden = sidebarInitEl ? (sidebarInitEl.getAttribute('data-sidebar-contenthidden') || '') : '',
				essbSidebarAppearPos = sidebarInitEl ? (sidebarInitEl.getAttribute('data-sidebar-appear-pos') || '') : '',
				essbSidebarDisappearPos = sidebarInitEl ? (sidebarInitEl.getAttribute('data-sidebar-disappear-pos') || '') : '';
			if (essbSidebarAppearPos != '' || essbSidebarDisappearPos != '' || essbSidebarContentHidden == 'yes') {
				if (window.innerWidth > 800) {
					window.addEventListener('scroll', debounce(essb_sidebar_onscroll, 1));
					essb_sidebar_onscroll();
				}
			}
		}
	}
})();
