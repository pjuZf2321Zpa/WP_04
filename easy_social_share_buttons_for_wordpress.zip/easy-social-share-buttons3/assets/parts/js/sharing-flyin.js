/**
 * Flyin
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 *
 * VanillaJS (no jQuery), self-contained. Loaded from assets/parts/js/.
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbFlyinInit);
	} else {
		essbFlyinInit();
	}

	function essbFlyinInit() {

		var debounce = function (func, wait) {
			var timeout, args, context, timestamp;
			return function () {
				context = this;
				args = [].slice.call(arguments, 0);
				timestamp = new Date();
				var later = function () {
					var last = (new Date()) - timestamp;
					if (last < wait) {
						timeout = setTimeout(later, wait - last);
					} else {
						timeout = null;
						func.apply(context, args);
					}
				};
				if (!timeout) {
					timeout = setTimeout(later, wait);
				}
			};
		};

		var essb_responsiveEventsCanRun = function (element) {
			if (!element) return false;
			var hideOnMobile = element.classList.contains('essb_mobile_hidden'),
				hideOnDesktop = element.classList.contains('essb_desktop_hidden'),
				hideOnTablet = element.classList.contains('essb_tablet_hidden'),
				windowWidth = window.innerWidth,
				canRun = true;

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		var essb_int_value = function (value) {
			value = parseInt(value);

			if (isNaN(value) || !isFinite(value)) value = 0;
			return value;
		};

		var essb_setCookie = function (cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toGMTString();
			document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
		};

		var essb_getCookie = function (cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i].trim();
				if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
			}
			return "";
		};

		var essb_is_after_comment = function () {
			var addr = window.location.href;
			return addr.indexOf('#comment') > -1 ? true : false;
		};

		var fadeIn = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var fadeOut = function (element, duration) {
			if (!element) return;
			element.style.opacity = '1';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '0';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, duration ? duration : 400);
		};

		var documentHeight = function () {
			return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		};

		var getOffsetTop = function (element) {
			if (!element) return 0;
			var rect = element.getBoundingClientRect();
			return rect.top + (window.pageYOffset || document.documentElement.scrollTop);
		};

		/**
		 * Display Method: Fly In
		 */
		var flyinElement = document.querySelector('.essb-flyin');
		if (!flyinElement) return;

		var flyinDisplayed = false;
		var flyinTriggeredOnScroll = false;
		var flyinTriggerPercent = -1;
		var flyinTriggerEnd = false;

		var essb_flyin_onscroll = function () {
			if (flyinTriggeredOnScroll) return;

			var current_pos = window.scrollY;
			var height = documentHeight() - window.innerHeight;
			var percentage = current_pos / height * 100;

			if (!flyinTriggerEnd) {
				if (percentage > flyinTriggerPercent && flyinTriggerPercent > 0) {
					flyinTriggeredOnScroll = true;
					essb_flyin_show();
				}
			} else {
				var element = document.querySelector('.essb_break_scroll');
				if (!element) { return; }
				var top = getOffsetTop(element) - parseFloat(window.getComputedStyle(element).marginTop.replace(/auto/, 0));

				if (current_pos >= top) {
					flyinTriggeredOnScroll = true;
					essb_flyin_show();
				}
			}
		};

		var essb_flyin_manual_show = window.essb_flyin_manual_show = function () {
			if (!document.querySelector('.essb-flyin')) return;

			var element = document.querySelector('.essb-flyin'),
				popWidth = element.getAttribute('data-width') || '',
				winWidth = window.innerWidth,
				baseWidth = 400;

			if (Number(popWidth) && Number(popWidth) > 0) baseWidth = Number(popWidth);
			if (winWidth < baseWidth) baseWidth = winWidth - 60;

			element.style.width = baseWidth + 'px';
			fadeIn(element, 400);
		};

		var essb_flyin_show = window.essb_flyin_show = function () {
			if (flyinDisplayed) return;

			var element = document.querySelector('.essb-flyin');
			if (!element) return;

			var popWidth = element.getAttribute("data-width") || "";
			var popHideOnClose = element.getAttribute("data-close-hide") || "";
			var popHideOnCloseAll = element.getAttribute("data-close-hide-all") || "";
			var popPostId = element.getAttribute("data-postid") || "";
			var popAutoCloseAfter = element.getAttribute("data-close-after") || "";

			if (popHideOnClose == "1" || popHideOnCloseAll == "1") {
				var cookie_name = "";
				var base_cookie_name = "essb_flyin_";
				if (popHideOnClose == "1") {
					cookie_name = base_cookie_name + popPostId;
					var cookieSet = essb_getCookie(cookie_name);
					if (cookieSet == "yes") return;
					essb_setCookie(cookie_name, "yes", 7);
				}
				if (popHideOnCloseAll == "1") {
					cookie_name = base_cookie_name + "all";
					var cookieSet = essb_getCookie(cookie_name);
					if (cookieSet == "yes") return;
					essb_setCookie(cookie_name, "yes", 7);
				}
			}

			var win_width = window.innerWidth;
			var base_width = 400;
			var userwidth = popWidth;
			if (Number(userwidth) && Number(userwidth) > 0)
				base_width = userwidth;

			if (win_width < base_width) base_width = win_width - 60;

			// automatically close
			if (Number(popAutoCloseAfter) && Number(popAutoCloseAfter) > 0) {
				var optin_time = parseFloat(popAutoCloseAfter);
				optin_time = optin_time * 1000;
				setTimeout(function () {
					fadeOut(element, 200);
				}, optin_time);
			}

			element.style.width = base_width + 'px';
			fadeIn(element, 400);

			flyinDisplayed = true;
		};

		if (essb_responsiveEventsCanRun(flyinElement)) {
			if (essb_is_after_comment() && flyinElement.classList.contains("essb-flyin-oncomment")) {
				essb_flyin_show();
				return;
			}

			var popOnPercent = flyinElement.getAttribute("data-load-percent") || "";
			var popAfter = flyinElement.getAttribute("data-load-time") || "";
			var popOnEnd = flyinElement.getAttribute("data-load-end") || "";
			var popManual = flyinElement.getAttribute("data-load-manual") || "";

			if (popManual == '1') return;

			if (popOnPercent != '' || popOnEnd == "1") {
				flyinTriggerPercent = Number(popOnPercent);
				flyinTriggeredOnScroll = false;
				flyinTriggerEnd = (popOnEnd == "1") ? true : false;

				window.addEventListener('scroll', debounce(essb_flyin_onscroll, 1));
			}

			if (popAfter && typeof (popAfter) != "undefined") {
				if (popAfter != '' && Number(popAfter)) {
					setTimeout(function () {
						essb_flyin_show();
					}, (Number(popAfter) * 1000));
				} else
					essb_flyin_show();
			} else {
				if (popOnPercent == '' && popOnEnd != '1')
					essb_flyin_show();
			}
		}

	}
})();