/**
 * Popup
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 *
 * VanillaJS (no jQuery), self-contained. Loaded from assets/parts/js/.
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbPopupInit);
	} else {
		essbPopupInit();
	}

	function essbPopupInit() {

		var debounce = function (func, wait) {
			var timeout, args, context, timestamp;
			return function () {
				context = this;
				args = [].slice.call(arguments, 0);
				timestamp = new Date();
				var later = function () {
					var last = (new Date()) - timestamp;
					if (last < wait) {
						timeout = setTimeout(later, wait - last);
					} else {
						timeout = null;
						func.apply(context, args);
					}
				};
				if (!timeout) {
					timeout = setTimeout(later, wait);
				}
			};
		};

		var essb_responsiveEventsCanRun = function (element) {
			if (!element) return false;
			var hideOnMobile = element.classList.contains('essb_mobile_hidden'),
				hideOnDesktop = element.classList.contains('essb_desktop_hidden'),
				hideOnTablet = element.classList.contains('essb_tablet_hidden'),
				windowWidth = window.innerWidth,
				canRun = true;

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		var essb_int_value = function (value) {
			value = parseInt(value);

			if (isNaN(value) || !isFinite(value)) value = 0;
			return value;
		};

		var essb_setCookie = function (cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toGMTString();
			document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
		};

		var essb_getCookie = function (cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i].trim();
				if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
			}
			return "";
		};

		var fadeIn = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var fadeOut = function (element, duration) {
			if (!element) return;
			element.style.opacity = '1';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '0';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, duration ? duration : 400);
		};

		var center = function (element) {
			if (!element) return;
			var top = (window.innerHeight - element.offsetHeight) / 2;
			var left = (window.innerWidth - element.offsetWidth) / 2;
			element.style.position = 'fixed';
			element.style.margin = 0;
			element.style.top = (top > 0 ? top : 0) + 'px';
			element.style.left = (left > 0 ? left : 0) + 'px';
		};

		var fadeInCenter = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			center(element);
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var documentHeight = function () {
			return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		};

		var getOffsetTop = function (element) {
			if (!element) return 0;
			var rect = element.getBoundingClientRect();
			return rect.top + (window.pageYOffset || document.documentElement.scrollTop);
		};

		var essb_is_after_comment = function () {
			var addr = window.location.href;
			return addr.indexOf('#comment') > -1 ? true : false;
		};

		/**
		 * Display Method: Pop up
		 */
		var popupElement = document.querySelector('.essb-popup');
		if (!popupElement) return;

		var popupTriggeredOnScroll = false;
		var popupTriggerPercent = -1;
		var popupTriggerEnd = false;
		var popupTriggerExit = false;
		var popupShown = false;

		var essb_popup_close = function () {
			fadeOut(document.querySelector('.essb-popup'), 200);
			fadeOut(document.querySelector('.essb-popup-shadow'), 400);
		};

		var essb_popup_exit = function (event) {
			if (popupTriggerExit) return;

			var e = event || window.event;

			var from = e.relatedTarget || e.toElement;

			// Reliable, works on mouse exiting window and user switching active program
			if (!from || from.nodeName === "HTML") {
				popupTriggerExit = true;
				essb_popup_show();
			}
		};

		var essb_popup_onscroll = function () {
			if (popupTriggeredOnScroll) return;

			var current_pos = window.scrollY;
			var height = documentHeight() - window.innerHeight;
			var percentage = current_pos / height * 100;

			if (!popupTriggerEnd) {
				if (percentage > popupTriggerPercent && popupTriggerPercent > 0) {
					popupTriggeredOnScroll = true;
					essb_popup_show();
				}
			} else {
				var element = document.querySelector('.essb_break_scroll');
				if (!element) {
					var userTriggerPercent = 90;
					if (percentage > userTriggerPercent && userTriggerPercent > 0) {
						popupTriggeredOnScroll = true;
						essb_popup_show();
					}
				} else {
					var top = getOffsetTop(element) - parseFloat(window.getComputedStyle(element).marginTop.replace(/auto/, 0));

					if (current_pos >= top) {
						popupTriggeredOnScroll = true;
						essb_popup_show();
					}
				}
			}
		};

		var essb_manual_popup_show = window.essb_manual_popup_show = function () {
			popupShown = false;
			essb_popup_show();
		};

		var essb_popup_show = window.essb_popup_show = function () {

			if (popupShown) return;

			var element = document.querySelector('.essb-popup');
			if (!element) return;

			var popWidth = element.getAttribute("data-width") || "";
			var popHideOnClose = element.getAttribute("data-close-hide") || "";
			var popHideOnCloseAll = element.getAttribute("data-close-hide-all") || "";
			var popPostId = element.getAttribute("data-postid") || "";
			var popAutoCloseAfter = element.getAttribute("data-close-after") || "";

			if (popHideOnClose == "1" || popHideOnCloseAll == "1") {
				var cookie_name = "";
				var base_cookie_name = "essb_popup_";
				if (popHideOnClose == "1") {
					cookie_name = base_cookie_name + popPostId;
					var cookieSet = essb_getCookie(cookie_name);
					if (cookieSet == "yes") return;
					essb_setCookie(cookie_name, "yes", 7);
				}
				if (popHideOnCloseAll == "1") {
					cookie_name = base_cookie_name + "all";
					var cookieSet = essb_getCookie(cookie_name);
					if (cookieSet == "yes") return;
					essb_setCookie(cookie_name, "yes", 7);
				}
			}

			var win_width = window.innerWidth;
			var base_width = 800;
			var userwidth = popWidth;
			if (Number(userwidth) && Number(userwidth) > 0) {
				base_width = userwidth;
			}

			if (win_width < base_width) { base_width = win_width - 60; }

			// automatically close
			if (Number(popAutoCloseAfter) && Number(popAutoCloseAfter) > 0) {
				optin_time = Number(popAutoCloseAfter) * 1000;
				setTimeout(function () {
					essb_popup_close();
				}, optin_time);
			}

			element.style.width = base_width + 'px';
			fadeInCenter(element, 400);
			fadeIn(document.querySelector('.essb-popup-shadow'), 200);

			popupShown = true;
		};

		if (essb_responsiveEventsCanRun(popupElement)) {
			if (essb_is_after_comment()) {
				if (popupElement.classList.contains("essb-popup-oncomment")) {
					essb_popup_show();
					return;
				}
			}

			var popOnPercent = popupElement.getAttribute("data-load-percent") || "";
			var popAfter = popupElement.getAttribute("data-load-time") || "";
			var popOnEnd = popupElement.getAttribute("data-load-end") || "";
			var popManual = popupElement.getAttribute("data-load-manual") || "";
			var popExit = popupElement.getAttribute("data-exit-intent") || "";

			if (popManual == '1') {
				popOnPercent = '';
				popAfter = '-1';
				popOnEnd = '';
				popExit = '';
			}

			if (popOnPercent != '' || popOnEnd == "1") {
				popupTriggerPercent = Number(popOnPercent);
				popupTriggeredOnScroll = false;
				popupTriggerEnd = (popOnEnd == "1") ? true : false;
				window.addEventListener('scroll', essb_popup_onscroll);
			}

			if (popExit == '1') {
				function addEvent(obj, evt, fn) {
					if (obj.addEventListener) {
						obj.addEventListener(evt, fn, false);
					} else if (obj.attachEvent) {
						obj.attachEvent("on" + evt, fn);
					}
				}

				// Exit intent trigger
				addEvent(document, 'mouseout', function (evt) {
					evt = evt ? evt : window.event;

					// If this is an autocomplete element.
					if (evt.target.tagName.toLowerCase() == "input")
						return;

					// Get the current viewport width.
					var vpWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

					// If the current mouse X position is within 50px of the right edge
					// of the viewport, return.
					if (evt.clientX >= (vpWidth - 50))
						return;

					// If the current mouse Y position is not within 50px of the top
					// edge of the viewport, return.
					// 7.7.3 - replace 50 -> 0
					if (evt.clientY >= 0)
						return;

					if (evt.toElement === null && evt.relatedTarget === null) {
						essb_popup_exit();
					}
				});
			}

			if (popAfter && typeof (popAfter) != "undefined" && popAfter != '-1') {
				if (popAfter != '' && Number(popAfter)) {
					setTimeout(function () {
						essb_popup_show();
					}, (Number(popAfter) * 1000));
				} else {
					essb_popup_show();
				}
			} else {
				if (popOnPercent == '' && popOnEnd != '1' && popExit != '1' && popAfter != '-1') {
					essb_popup_show();
				}
			}
		}

	}
})();