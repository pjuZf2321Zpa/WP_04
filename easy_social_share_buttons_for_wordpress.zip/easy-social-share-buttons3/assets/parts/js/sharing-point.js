/**
 * Display Method: Share Point (essb-point)
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbPointInit);
	} else {
		essbPointInit();
	}

	function essbPointInit() {

		var pointElement = document.querySelector('.essb-point');
		if (!pointElement) return;

		var shareButtons = document.querySelector('.essb-point-share-buttons');

		var responsiveEventsCanRun = function (selector) {
			var element = document.querySelector(selector);
			var hideOnMobile = false,
				hideOnDesktop = false,
				hideOnTablet = false,
				windowWidth = window.innerWidth,
				canRun = true;

			if (element) {
				hideOnMobile = element.classList.contains('essb_mobile_hidden');
				hideOnDesktop = element.classList.contains('essb_desktop_hidden');
				hideOnTablet = element.classList.contains('essb_tablet_hidden');
			} else {
				return false;
			}

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		var essb_point_triggered = false;
		var essb_point_trigger_mode = "";

		var essb_point_onscroll = pointElement.getAttribute('data-trigger-scroll') || "";
		var essb_point_mode = pointElement.getAttribute('data-point-type') || "simple";
		var essb_point_autoclose = Number(pointElement.getAttribute('data-autoclose') || 0) || 0;

		var essb_point_trigger_open_onscroll = function () {
			var current_pos = window.scrollY + window.innerHeight - 200;

			var breakScrollElement = document.querySelector('.essb_break_scroll');
			var top = NaN;
			if (breakScrollElement) {
				var computedStyle = window.getComputedStyle(breakScrollElement);
				var marginTop = parseFloat(computedStyle.marginTop);
				if (isNaN(marginTop)) marginTop = 0;
				top = breakScrollElement.getBoundingClientRect().top + window.scrollY - marginTop;
			}

			if (essb_point_trigger_mode == 'end') {
				if (current_pos >= top && !essb_point_triggered) {
					if (shareButtons && !shareButtons.classList.contains('essb-point-share-buttons-active')) {
						shareButtons.classList.add('essb-point-share-buttons-active');
						if (essb_point_mode != 'simple') pointElement.classList.toggle('essb-point-open');
						essb_point_triggered = true;

						if (essb_point_autoclose > 0) {
							setTimeout(function () {
								if (shareButtons) shareButtons.classList.remove('essb-point-share-buttons-active');
								if (essb_point_mode != 'simple') pointElement.classList.remove('essb-point-open');
							}, essb_point_autoclose * 1000)
						}
					}
				}
			}
			if (essb_point_trigger_mode == 'middle') {
				var percentage = current_pos * 100 / top;
				if (percentage > 49 && !essb_point_triggered) {
					if (shareButtons && !shareButtons.classList.contains('essb-point-share-buttons-active')) {
						shareButtons.classList.add('essb-point-share-buttons-active');
						if (essb_point_mode != 'simple') pointElement.classList.toggle('essb-point-open');
						essb_point_triggered = true;

						if (essb_point_autoclose > 0) {
							setTimeout(function () {
								if (shareButtons) shareButtons.classList.remove('essb-point-share-buttons-active');
								if (essb_point_mode != 'simple') pointElement.classList.remove('essb-point-open');
							}, essb_point_autoclose * 1000)
						}
					}
				}
			}
		};

		if (responsiveEventsCanRun('.essb-point')) {
			if (essb_point_onscroll == 'end' || essb_point_onscroll == 'middle') {
				essb_point_trigger_mode = essb_point_onscroll;
				window.addEventListener('scroll', essb_point_trigger_open_onscroll);
			}
		}

		pointElement.addEventListener('click', function () {

			if (shareButtons) shareButtons.classList.toggle('essb-point-share-buttons-active');

			if (essb_point_mode != 'simple') pointElement.classList.toggle('essb-point-open');

			if (essb_point_autoclose > 0) {
				setTimeout(function () {
					if (shareButtons) shareButtons.classList.remove('essb-point-share-buttons-active');
					if (essb_point_mode != 'simple') pointElement.classList.remove('essb-point-open');
				}, essb_point_autoclose * 1000)
			}
		});
	}
})();