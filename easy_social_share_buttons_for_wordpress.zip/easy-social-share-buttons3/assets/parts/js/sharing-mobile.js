/**
 * Display Method: Mobile Share Bar (sharebottom)
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbMobileShareBarInit);
	} else {
		essbMobileShareBarInit();
	}

	function essbMobileShareBarInit() {

		if (!window.debounce) {
			window.debounce = function (func, wait) {
				var timeout, args, context, timestamp;
				return function () {
					context = this;
					args = [].slice.call(arguments, 0);
					timestamp = new Date();
					var later = function () {
						var last = (new Date()) - timestamp;
						if (last < wait) {
							timeout = setTimeout(later, wait - last);
						} else {
							timeout = null;
							func.apply(context, args);
						}
					};
					if (!timeout) {
						timeout = setTimeout(later, wait);
					}
				};
			};
		}
		var debounce = window.debounce;

		// Fade helpers (replaces jQuery fadeIn / fadeOut)
		var fadeIn = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var fadeOut = function (element, duration) {
			if (!element) return;
			element.style.opacity = '1';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '0';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, duration ? duration : 400);
		};

		var mobileSharebar = document.querySelector('.essb-mobile-sharebottom');
		if (!mobileSharebar) return;

		var mobileHideOnScroll = false;
		var mobileHideTriggerPercent = 90;
		var mobileAppearOnScroll = false;
		var mobileAppearOnScrollPercent = 0;
		var mobileAdBarConnected = false;

		var essb_mobile_sharebuttons_onscroll = function () {

			var current_pos = window.scrollY;
			var height = document.documentElement.scrollHeight - window.innerHeight;
			var percentage = current_pos / height * 100;

			var isVisible = true;
			if (mobileAppearOnScroll && !mobileHideOnScroll) {
				if (percentage < mobileAppearOnScrollPercent) isVisible = false;
			}
			if (mobileHideOnScroll && !mobileAppearOnScroll) {
				if (percentage > mobileHideTriggerPercent) isVisible = false;
			}
			if (mobileAppearOnScroll && mobileHideOnScroll) {
				if (percentage > mobileHideTriggerPercent || percentage < mobileAppearOnScrollPercent) isVisible = false;

			}

			if (!isVisible) {
				if (!mobileSharebar.classList.contains("essb-mobile-break")) {
					mobileSharebar.classList.add("essb-mobile-break");
					fadeOut(mobileSharebar, 400);
				}

				var adHolder = document.querySelector('.essb-adholder-bottom');
				if (adHolder && mobileAdBarConnected) {
					if (!adHolder.classList.contains("essb-mobile-break")) {
						adHolder.classList.add("essb-mobile-break");
						fadeOut(adHolder, 400);
					}
				}

			} else {
				if (mobileSharebar.classList.contains("essb-mobile-break")) {
					mobileSharebar.classList.remove("essb-mobile-break");
					fadeIn(mobileSharebar, 400);
				}

				var adHolderVisible = document.querySelector('.essb-adholder-bottom');
				if (adHolderVisible && mobileAdBarConnected) {
					if (adHolderVisible.classList.contains("essb-mobile-break")) {
						adHolderVisible.classList.remove("essb-mobile-break");
						fadeIn(adHolderVisible, 400);
					}
				}
			}
		};

		var hide_on_end = mobileSharebar.getAttribute('data-hideend');
		var hide_on_end_user = mobileSharebar.getAttribute('data-hideend-percent');
		var appear_on_scroll = mobileSharebar.getAttribute('data-show-percent') || '';
		var check_responsive = mobileSharebar.getAttribute('data-responsive') || '';

		if (Number(appear_on_scroll)) {
			mobileAppearOnScroll = true;
			mobileAppearOnScrollPercent = Number(appear_on_scroll);
		}

		if (hide_on_end == 'true') mobileHideOnScroll = true;

		var instance_mobile = false;
		if ((/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i).test(navigator.userAgent)) {
			instance_mobile = true;
		}

		var adHolderConnected = document.querySelector('.essb-adholder-bottom');
		if (adHolderConnected) {
			var adbar_connected = adHolderConnected.getAttribute('data-connected') || '';
			if (adbar_connected == 'true') mobileAdBarConnected = true;
		}

		if (mobileHideOnScroll || mobileAppearOnScroll) {
			if (parseInt(hide_on_end_user) > 0)
				mobileHideTriggerPercent = parseInt(hide_on_end_user);

			if (check_responsive == '' || (check_responsive == 'true' && instance_mobile))
				window.addEventListener('scroll', debounce(essb_mobile_sharebuttons_onscroll, 1));

		}
	}
})();
