/**
 * Top Bar, Bottom Bar 
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 *
 * VanillaJS (no jQuery), self-contained. Loaded from assets/parts/js/.
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbBarInit);
	} else {
		essbBarInit();
	}

	function essbBarInit() {

		/**
		 * Display Method: Bottom Bar
		 */

		var debounce = function (func, wait) {
			var timeout, args, context, timestamp;
			return function () {
				context = this;
				args = [].slice.call(arguments, 0);
				timestamp = new Date();
				var later = function () {
					var last = (new Date()) - timestamp;
					if (last < wait) {
						timeout = setTimeout(later, wait - last);
					} else {
						timeout = null;
						func.apply(context, args);
					}
				};
				if (!timeout) {
					timeout = setTimeout(later, wait);
				}
			};
		};

		var essb_int_value = function (value) {
			value = parseInt(value);

			if (isNaN(value) || !isFinite(value)) value = 0;
			return value;
		};

		var essb_responsiveEventsCanRun = function (element) {
			if (!element) return false;
			var hideOnMobile = element.classList.contains('essb_mobile_hidden'),
				hideOnDesktop = element.classList.contains('essb_desktop_hidden'),
				hideOnTablet = element.classList.contains('essb_tablet_hidden'),
				windowWidth = window.innerWidth,
				canRun = true;

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		var documentHeight = function () {
			return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		};

		function essb_bottombar_onscroll() {
			var current_pos = window.scrollY;
			var height = documentHeight() - window.innerHeight;
			var percentage = current_pos / height * 100;

			var element = document.querySelector(".essb_bottombar");
			if (!element) return;

			var links = element.querySelector('.essb_links');
			var value_appear = essb_int_value(links ? (links.getAttribute('data-bottombar-appear') || '') : '');
			var value_disappear = essb_int_value(links ? (links.getAttribute('data-bottombar-disappear') || '') : '');

			if (value_appear > 0) {
				if (percentage >= value_appear && !element.classList.contains("essb_active_bottombar")) {
					element.classList.add("essb_active_bottombar");
					return;
				}

				if (percentage < value_appear && element.classList.contains("essb_active_bottombar")) {
					element.classList.remove("essb_active_bottombar");
					return;
				}
			}
			if (value_disappear > 0) {
				if (percentage >= value_disappear && !element.classList.contains("hidden-float")) {
					element.classList.add("hidden-float");
					element.style.opacity = "0";
					return;
				}
				if (percentage < value_disappear && element.classList.contains("hidden-float")) {
					element.classList.remove("hidden-float");
					element.style.opacity = "1";
					return;
				}
			}
		}

		var bottombarElement = document.querySelector(".essb_bottombar");
		if (bottombarElement)
			if (essb_responsiveEventsCanRun(bottombarElement)) {
				var bottombarLinks = bottombarElement.querySelector('.essb_links');
				var bottombarAppear = bottombarLinks ? (bottombarLinks.getAttribute('data-bottombar-appear') || '') : '';
				var bottombarDisappear = bottombarLinks ? (bottombarLinks.getAttribute('data-bottombar-disappear') || '') : '';
				if (bottombarAppear != '' || bottombarDisappear != '')
					window.addEventListener('scroll', debounce(essb_bottombar_onscroll, 1));
			}

		/**
		 * Display Method: Top Bar
		 */

		function essb_topbar_onscroll() {
			var current_pos = window.scrollY;
			var height = documentHeight() - window.innerHeight;
			var percentage = current_pos / height * 100;

			var element = document.querySelector(".essb_topbar");
			if (!element) return;

			var links = element.querySelector('.essb_links');
			var value_appear = essb_int_value(links ? (links.getAttribute('data-topbar-appear') || '') : '');
			var value_disappear = essb_int_value(links ? (links.getAttribute('data-topbar-disappear') || '') : '');

			if (value_appear > 0) {
				if (percentage >= value_appear && !element.classList.contains("essb_active_topbar")) {
					element.classList.add("essb_active_topbar");
					return;
				}

				if (percentage < value_appear && element.classList.contains("essb_active_topbar")) {
					element.classList.remove("essb_active_topbar");
					return;
				}
			}
			if (value_disappear > 0) {
				if (percentage >= value_disappear && !element.classList.contains("hidden-float")) {
					element.classList.add("hidden-float");
					element.style.opacity = "0";
					return;
				}
				if (percentage < value_disappear && element.classList.contains("hidden-float")) {
					element.classList.remove("hidden-float");
					element.style.opacity = "1";
					return;
				}
			}
		}

		var topbarElement = document.querySelector(".essb_topbar");
		if (topbarElement) {
			if (essb_responsiveEventsCanRun(topbarElement)) {
				var topbarLinks = topbarElement.querySelector('.essb_links');
				var topbarAppear = topbarLinks ? (topbarLinks.getAttribute('data-topbar-appear') || '') : '';
				var topbarDisappear = topbarLinks ? (topbarLinks.getAttribute('data-topbar-disappear') || '') : '';
				if (topbarAppear != '' || topbarDisappear != '')
					window.addEventListener('scroll', debounce(essb_topbar_onscroll, 1));
			}
		}
	}
})();