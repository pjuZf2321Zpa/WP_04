/**
 * Display Method: Corner Bar (essb-cornerbar)
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbCornerbarInit);
	} else {
		essbCornerbarInit();
	}

	function essbCornerbarInit() {

		var cornerbarElement = document.querySelector('.essb-cornerbar');
		if (!cornerbarElement) return;

		var debounce = function (func, wait) {
			var timeout;
			return function () {
				var context = this;
				var args = arguments;
				var later = function () {
					timeout = null;
					func.apply(context, args);
				};
				clearTimeout(timeout);
				timeout = setTimeout(later, wait);
			};
		};

		var isElementInViewport = function (el) {
			var rect = el.getBoundingClientRect();
			return rect.top >= 0 && rect.left >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && rect.right <= (window.innerWidth || document.documentElement.clientWidth);
		};

		var responsiveEventsCanRun = function (selector) {
			var element = document.querySelector(selector);
			var hideOnMobile = false,
				hideOnDesktop = false,
				hideOnTablet = false,
				windowWidth = window.innerWidth,
				canRun = true;

			if (element) {
				hideOnMobile = element.classList.contains('essb_mobile_hidden');
				hideOnDesktop = element.classList.contains('essb_desktop_hidden');
				hideOnTablet = element.classList.contains('essb_tablet_hidden');
			} else {
				return false;
			}

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		var linksElement = cornerbarElement.querySelector('.essb_links');
		if (linksElement) linksElement.classList.remove('essb_displayed_cornerbar');

		var dataCornerBarShow = cornerbarElement.getAttribute('data-show') || '';
		var dataCornerBarHide = cornerbarElement.getAttribute('data-hide') || '';

		var essb_cornerbar_scroll = function () {
			var current_pos = window.scrollY;
			var height = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight;
			var percentage = current_pos / height * 100,
				breakPercent = dataCornerBarShow == 'onscroll' ? 5 : 45;

			if (dataCornerBarShow == 'onscroll' || dataCornerBarShow == 'onscroll50') {
				if (percentage > breakPercent) {
					if (cornerbarElement.classList.contains('essb-cornerbar-hidden')) cornerbarElement.classList.remove('essb-cornerbar-hidden');
				}
				else {
					if (!cornerbarElement.classList.contains('essb-cornerbar-hidden')) cornerbarElement.classList.add('essb-cornerbar-hidden');
				}
			}

			if (dataCornerBarShow == 'content') {
				var isOneVisible = false;
				var topElements = document.querySelectorAll('.essb_displayed_top');
				var bottomElements = document.querySelectorAll('.essb_displayed_bottom');
				var i;

				for (i = 0; i < topElements.length; i++) {
					if (isElementInViewport(topElements[i]))
						isOneVisible = true;
				}
				for (i = 0; i < bottomElements.length; i++) {
					if (isElementInViewport(bottomElements[i]))
						isOneVisible = true;
				}

				if (!isOneVisible) {
					if (cornerbarElement.classList.contains('essb-cornerbar-hidden')) cornerbarElement.classList.remove('essb-cornerbar-hidden');
				}
				else {
					if (!cornerbarElement.classList.contains('essb-cornerbar-hidden')) cornerbarElement.classList.add('essb-cornerbar-hidden');
				}
			}

			if (dataCornerBarHide != '') {
				if (percentage > 90) {
					if (!cornerbarElement.classList.contains('essb-cornerbar-hiddenend')) cornerbarElement.classList.add('essb-cornerbar-hiddenend');
				}
				else {
					if (cornerbarElement.classList.contains('essb-cornerbar-hiddenend')) cornerbarElement.classList.remove('essb-cornerbar-hiddenend');
				}
			}
		};

		if (responsiveEventsCanRun('.essb-cornerbar')) {
			if (dataCornerBarHide != '' || dataCornerBarShow != '')
				window.addEventListener('scroll', debounce(essb_cornerbar_scroll, 1));

			if (dataCornerBarShow == 'content') essb_cornerbar_scroll();
		}
	}
})();