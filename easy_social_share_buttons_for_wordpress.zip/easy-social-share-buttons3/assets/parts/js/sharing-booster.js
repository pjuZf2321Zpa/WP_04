/**
 * Booster
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 8.0
 *
 * VanillaJS (no jQuery), self-contained. Loaded from assets/parts/js/.
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbBoosterInit);
	} else {
		essbBoosterInit();
	}

	function essbBoosterInit() {

		var debounce = function (func, wait) {
			var timeout, args, context, timestamp;
			return function () {
				context = this;
				args = [].slice.call(arguments, 0);
				timestamp = new Date();
				var later = function () {
					var last = (new Date()) - timestamp;
					if (last < wait) {
						timeout = setTimeout(later, wait - last);
					} else {
						timeout = null;
						func.apply(context, args);
					}
				};
				if (!timeout) {
					timeout = setTimeout(later, wait);
				}
			};
		};

		var essb_responsiveEventsCanRun = function (element) {
			if (!element) return false;
			var hideOnMobile = element.classList.contains('essb_mobile_hidden'),
				hideOnDesktop = element.classList.contains('essb_desktop_hidden'),
				hideOnTablet = element.classList.contains('essb_tablet_hidden'),
				windowWidth = window.innerWidth,
				canRun = true;

			if (windowWidth <= 768 && hideOnMobile) canRun = false;
			if (windowWidth > 768 && windowWidth <= 1100 && hideOnTablet) canRun = false;
			if (windowWidth > 1100 && hideOnDesktop) canRun = false;

			return canRun;
		};

		var essb_int_value = function (value) {
			value = parseInt(value);

			if (isNaN(value) || !isFinite(value)) value = 0;
			return value;
		};

		var essb_setCookie = function (cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toGMTString();
			document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
		};

		var essb_getCookie = function (cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i].trim();
				if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
			}
			return "";
		};

		var fadeIn = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var fadeOut = function (element, duration) {
			if (!element) return;
			element.style.opacity = '1';
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '0';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, duration ? duration : 400);
		};

		var center = function (element) {
			if (!element) return;
			var top = (window.innerHeight - element.offsetHeight) / 2;
			var left = (window.innerWidth - element.offsetWidth) / 2;
			element.style.position = 'fixed';
			element.style.margin = 0;
			element.style.top = (top > 0 ? top : 0) + 'px';
			element.style.left = (left > 0 ? left : 0) + 'px';
		};

		var fadeInCenter = function (element, duration) {
			if (!element) return;
			element.style.opacity = '0';
			element.style.display = 'block';
			center(element);
			element.style.transition = 'opacity ' + (duration ? duration : 400) + 'ms ease';
			requestAnimationFrame(function () {
				element.style.opacity = '1';
			});
		};

		var documentHeight = function () {
			return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		};

		/**
		 * Display Method: Share Booster
		 */
		var boosterElement = document.querySelector('.essb-sharebooster');
		if (!boosterElement) return;

		var booster_shown = false;

		function essb_booster_trigger() {
			if (booster_shown) return;

			fadeInCenter(boosterElement, 400);
			fadeIn(document.querySelector('.essb-sharebooster-overlay'), 200);

			document.body.classList.add('essb-sharebooster-preventscroll');

			booster_shown = true;

			if (Number(booster_autoclose))
				setTimeout(essb_booster_close, Number(booster_autoclose) * 1000);
		}

		function essb_booster_close() {
			fadeOut(boosterElement, 200);
			fadeOut(document.querySelector('.essb-sharebooster-overlay'), 400);

			document.body.classList.remove('essb-sharebooster-preventscroll');
		}

		function essb_booster_close_from_action() {
			var boosterCookieKey = booster_donotshow == 'all' ? 'essb_booster_all' : 'essb_booster_' + essb_settings.post_id;

			essb_setCookie(boosterCookieKey, "yes", Number(booster_hide));
			essb_booster_close();
		}

		window.essb_booster_close_from_action = essb_booster_close_from_action;

		function essb_booster_scroll() {
			var current_pos = window.scrollY;
			var height = documentHeight() - window.innerHeight;
			var percentage = current_pos / height * 100,
				breakPercent = booster_scroll;

			if (percentage > breakPercent)
				essb_booster_trigger();
		}

		var booster_trigger = boosterElement.getAttribute('data-trigger') || '',
			booster_time = boosterElement.getAttribute('data-trigger-time') || '',
			booster_scroll = boosterElement.getAttribute('data-trigger-scroll') || '',
			booster_hide = boosterElement.getAttribute('data-donotshow') || '',
			booster_donotshow = boosterElement.getAttribute('data-donotshowon') || '',
			booster_autoclose = boosterElement.getAttribute('data-autoclose') || '';

		if (!Number(booster_hide)) booster_hide = 7;

		var boosterCookieKey = booster_donotshow == 'all' ? 'essb_booster_all' : 'essb_booster_' + essb_settings.post_id;
		var cookie_set = essb_getCookie(boosterCookieKey);

		// booster is already triggered
		if (cookie_set) booster_trigger = 'disabled';

		if (essb_responsiveEventsCanRun(boosterElement)) {
			if (booster_trigger == '')
				essb_booster_trigger();
			if (booster_trigger == 'time')
				setTimeout(essb_booster_trigger, Number(booster_time) * 1000);
			if (booster_trigger == 'scroll')
				window.addEventListener('scroll', debounce(essb_booster_scroll, 1));
		}

		var boosterCloseEl = document.querySelector('.essb-sharebooster-close');
		if (boosterCloseEl) {
			boosterCloseEl.addEventListener('click', function (e) {
				e.preventDefault();
				essb_booster_close();
			});
		}

	}
})();