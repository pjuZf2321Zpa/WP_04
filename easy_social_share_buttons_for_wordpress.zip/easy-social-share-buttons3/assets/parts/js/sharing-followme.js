/**
 * Display Method: Follow Me Bar (content_followme)
 * @package EasySocialShareButtons
 * @author appscreo
 * @since 11.7
 *
 * VanillaJS (no jQuery)
 */

(function () {
	"use strict";

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', essbFollowmeInit);
	} else {
		essbFollowmeInit();
	}

	function essbFollowmeInit() {

		var followmeElement = document.querySelector('.essb-followme');
		if (!followmeElement) return;

		if (!window.debounce) {
			window.debounce = function (func, wait) {
				var timeout, args, context, timestamp;
				return function () {
					context = this;
					args = [].slice.call(arguments, 0);
					timestamp = new Date();
					var later = function () {
						var last = (new Date()) - timestamp;
						if (last < wait) {
							timeout = setTimeout(later, wait - last);
						} else {
							timeout = null;
							func.apply(context, args);
						}
					};
					if (!timeout) {
						timeout = setTimeout(later, wait);
					}
				};
			};
		}
		var debounce = window.debounce;

		var isElementInViewport = function (element) {
			if (!element) return false;
			var rect = element.getBoundingClientRect();

			return (
				rect.top >= 0 &&
				rect.left >= 0 &&
				rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
				rect.right <= (window.innerWidth || document.documentElement.clientWidth)
			);
		};

		// Slide helpers (replaces jQuery slideUp / slideDown)
		var slideUp = function (element, duration) {
			if (!element) return;
			var durationMs = duration ? duration : 400;
			element.style.height = element.offsetHeight + 'px';
			element.style.overflow = 'hidden';
			element.style.transition = 'height ' + durationMs + 'ms ease';
			requestAnimationFrame(function () {
				element.style.height = '0px';
			});
			window.setTimeout(function () {
				element.style.display = 'none';
			}, durationMs);
		};

		var slideDown = function (element, duration) {
			if (!element) return;
			var durationMs = duration ? duration : 400;
			element.style.display = 'block';
			element.style.height = '0px';
			element.style.overflow = 'hidden';
			element.style.transition = 'height ' + durationMs + 'ms ease';
			requestAnimationFrame(function () {
				element.style.height = element.scrollHeight + 'px';
			});
			window.setTimeout(function () {
				element.style.height = '';
				element.style.overflow = '';
				element.style.transition = '';
			}, durationMs);
		};

		var followmeLinks = followmeElement.querySelector('.essb_links');
		if (followmeLinks) followmeLinks.classList.remove('essb_displayed_followme');

		var dataPosition = followmeElement.getAttribute('data-position') || '',
			dataCustomTop = followmeElement.getAttribute('data-top') || '',
			dataBackground = followmeElement.getAttribute('data-background') || '',
			dataFull = followmeElement.getAttribute('data-full') || '',
			dataAvoidLeftMargin = followmeElement.getAttribute('data-avoid-left') || '',
			dataFollowmeHide = followmeElement.getAttribute('data-hide') || '';

		if (dataPosition == 'top' && dataCustomTop != '')
			followmeElement.style.top = dataCustomTop + 'px';
		if (dataBackground != '')
			followmeElement.style.backgroundColor = dataBackground;

		if (dataFull != '1' && dataPosition != 'left' && followmeLinks) {
			var displayedElement = document.querySelector('.essb_displayed_followme');
			var basicWidth = displayedElement ? displayedElement.offsetWidth : 0;
			var leftPosition = displayedElement ? displayedElement.offsetLeft : 0;

			if (dataAvoidLeftMargin != 'true')
				followmeLinks.style.cssText = 'width:' + basicWidth + 'px; margin-left:' + leftPosition + 'px !important;';
			else
				followmeLinks.style.cssText = 'width:' + basicWidth + 'px;';
		}

		function essb_followme_scroll() {
			var isOneVisible = false,
				dataFollowmeShowAfter = followmeElement.getAttribute('data-showafter') || '';

			if (dataFollowmeShowAfter != '' && !Number(dataFollowmeShowAfter)) dataFollowmeShowAfter = '';

			var displayedElements = document.querySelectorAll('.essb_displayed_followme');
			for (var i = 0; i < displayedElements.length; i++) {
				if (isElementInViewport(displayedElements[i]))
					isOneVisible = true;
			}

			var current_pos = window.scrollY;
			var height = document.documentElement.scrollHeight - window.innerHeight;
			var percentage = current_pos / height * 100;

			if (Number(dataFollowmeShowAfter) > 0 && Number(dataFollowmeShowAfter) > current_pos) isOneVisible = true;

			if (!isOneVisible) {
				if (!followmeElement.classList.contains('active')) followmeElement.classList.add('active');
			}
			else {
				if (followmeElement.classList.contains('active')) followmeElement.classList.remove('active');
			}

			if (dataFollowmeHide != '') {
				if (percentage > 95) {
					if (!followmeElement.classList.contains('essb-followme-hiddenend')) {
						followmeElement.classList.add('essb-followme-hiddenend');
						slideUp(followmeElement, 100);
					}
				}
				else {
					if (followmeElement.classList.contains('essb-followme-hiddenend')) {
						followmeElement.classList.remove('essb-followme-hiddenend');
						slideDown(followmeElement, 100);
					}
				}
			}
		}

		window.addEventListener('scroll', debounce(essb_followme_scroll, 1));

		// execute one time after load
		essb_followme_scroll();
	}
})();