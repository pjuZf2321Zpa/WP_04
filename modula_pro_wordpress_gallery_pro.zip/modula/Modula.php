<?php
/**
 * Plugin Name: Modula - PRO
 * Plugin URI: https://wp-modula.com/
 * Description: Modula is one of the best & most creative WordPress gallery plugins. Use it to create a great grid or masonry image gallery.
 * Author: WPChill
 * Author URI: https://www.wpchill.com/
 * Version: 3.0.23
 * Requires PHP: 8.1
 * Requires Plugins: modula-best-grid-gallery
 * Text Domain: modula-pro
 * Domain Path: /languages
 *
 * @package Modula
 */

/**
 * GPL Vault: license Modula PRO on the Business plan and stop the licence-server
 * calls. Additive filters only. The URL test below is deliberately narrow — the
 * update endpoint on the same host must keep working. Remove to "END GPL Vault".
 */
add_filter(
	'pre_option_modula_pro_license_data',
	function () {
		return (object) array(
			'status'         => 'active',
			'product_slug'   => 'business',
			'key'            => '1415b451be1a13c283ba771ea52d38bb',
			'expires'        => 'lifetime',
			'customer_name'  => 'Licensed User',
			'customer_email' => 'license@example.com',
		);
	}
);

add_filter(
	'pre_option_modula_pro_current_plan',
	function () {
		return 'business';
	}
);

add_filter(
	'pre_option_modula_pro_license_key',
	function () {
		return '1415b451be1a13c283ba771ea52d38bb';
	}
);

add_filter(
	'pre_option_modula_pro_license_last_verified',
	function () {
		return time();
	}
);

add_filter(
	'pre_transient_modula_pro_license_status',
	function () {
		return (object) array(
			'status'       => 'active',
			'product_slug' => 'business',
			'key'          => '1415b451be1a13c283ba771ea52d38bb',
			'expires'      => 'lifetime',
		);
	}
);

add_filter(
	'pre_http_request',
	function ( $preempt, $args, $url ) {
		if ( false === strpos( $url, 'wpchill-utils/v1/license' ) ) {
			return $preempt;
		}

		return array(
			'headers'  => array(),
			'body'     => wp_json_encode(
				array(
					'status'       => 'active',
					'product_slug' => 'business',
					'key'          => '1415b451be1a13c283ba771ea52d38bb',
					'expires'      => 'lifetime',
				)
			),
			'response' => array(
				'code'    => 200,
				'message' => 'OK',
			),
			'cookies'  => array(),
			'filename' => null,
		);
	},
	10,
	3
);
// END GPL Vault.

/**
 * Load the bootstrap file.
 */
require_once plugin_dir_path( __FILE__ ) . 'bootstrap.php';

/**
 * Load autoloader.
 */
require plugin_dir_path( __FILE__ ) . 'includes/vendor/autoload.php';

/**
 * Load the helper functions file.
 */
require_once plugin_dir_path( __FILE__ ) . 'includes/modula-pro-helper-functions.php';

/**
 * Register activation hook.
 */
register_activation_hook( __FILE__, array( 'Modula_Pro\Activator', 'activate' ) );

/**
 * Load the core plugin class.
 */
new Modula_Pro();

/**
 * Load the updater class.
 */
new Modula_Pro\Updater\Updater();
