<?php

namespace Modula_Pro;

use Modula_Pro\Extensions\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin activation hook class.
 *
 * Handles plugin activation tasks, including license activation
 * for pre-installed versions.
 *
 * @since      2.8.21
 */
class Activator {

	/**
	 * Activation hook callback.
	 *
	 * Checks if license data exists. If not, and MODULA_PRO_PREINSTALL
	 * is defined, activates the license using the preinstall value.
	 *
	 * @return void
	 */
	public static function activate() {
		$license_key_option = 'modula_pro_license_key';
		$license_key        = get_option( $license_key_option, '' );

		$licensing = Licensing::get_instance();

		if ( ! empty( $license_key ) ) {
			$licensing->activate_license( $license_key );
			return;
		}

		if ( defined( 'MODULA_PRO_PREINSTALL' ) && ! empty( MODULA_PRO_PREINSTALL ) ) {
			$licensing->activate_license( MODULA_PRO_PREINSTALL );
		}
	}
}
