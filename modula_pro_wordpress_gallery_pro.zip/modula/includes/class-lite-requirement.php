<?php
/**
 * Lite dependency gate for Modula Pro bootstrap.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure checks for whether Pro may load Lite-dependent features.
 */
class Lite_Requirement {

	/**
	 * Minimum Modula Lite version Pro boots its features with.
	 *
	 * Pro calls Lite classes directly (settings v2, Motion, watermark scale, the
	 * editor shell), so a Lite without one of them is a fatal error, not a
	 * degraded feature. Below this version Pro stays off and asks for the update.
	 * Raise it whenever Pro starts using a Lite class, method or function that an
	 * older Lite release lacks. 3.0.17 adds `Watermark_Scale`, `Motion_Settings`
	 * and `Animation_Catalog`, which watermarking and the Albums editor need.
	 *
	 * @var string
	 */
	const MINIMUM_VERSION = '3.0.17';

	/**
	 * Notification id for "Lite is missing or inactive".
	 *
	 * @var string
	 */
	const REQUIRED_NOTICE = 'modula-pro-lite-required';

	/**
	 * Notification id for "Lite is below MINIMUM_VERSION".
	 *
	 * @var string
	 */
	const OUTDATED_NOTICE = 'modula-pro-lite-version';

	/**
	 * Whether a Lite version string is present (plugin loaded).
	 *
	 * @param string|null $lite_version Value of MODULA_LITE_VERSION, or null when undefined.
	 * @return bool
	 */
	public static function is_missing( $lite_version ) {
		return null === $lite_version || '' === $lite_version;
	}

	/**
	 * Whether Lite is loaded (any version). Presence is enough to boot features.
	 *
	 * @param string|null $lite_version Value of MODULA_LITE_VERSION, or null when undefined.
	 * @return bool
	 */
	public static function is_satisfied( $lite_version ) {
		return ! self::is_missing( $lite_version );
	}

	/**
	 * Whether Lite is present but below the recommended minimum.
	 *
	 * @param string|null $lite_version Value of MODULA_LITE_VERSION, or null when undefined.
	 * @return bool
	 */
	public static function is_outdated( $lite_version ) {
		if ( self::is_missing( $lite_version ) ) {
			return false;
		}

		return version_compare( (string) $lite_version, self::MINIMUM_VERSION, '<' );
	}

	/**
	 * Soft-fail gate: skip Lite-dependent Pro boot when Lite is inactive, missing
	 * or older than MINIMUM_VERSION.
	 *
	 * @param string|null $lite_version Value of MODULA_LITE_VERSION, or null when undefined.
	 * @return bool
	 */
	public static function should_boot_features( $lite_version ) {
		return self::is_satisfied( $lite_version ) && ! self::is_outdated( $lite_version );
	}

	/**
	 * Lite dependency notifications whose cause is gone for this Lite version.
	 *
	 * @param string|null $lite_version Value of MODULA_LITE_VERSION, or null when undefined.
	 * @return string[] Notification ids to remove.
	 */
	public static function resolved_notices( $lite_version ) {
		if ( self::is_missing( $lite_version ) ) {
			return array();
		}

		if ( self::is_outdated( $lite_version ) ) {
			return array( self::REQUIRED_NOTICE );
		}

		return array( self::REQUIRED_NOTICE, self::OUTDATED_NOTICE );
	}

	/**
	 * Current Lite version constant, or null when Lite is not loaded.
	 *
	 * @return string|null
	 */
	public static function current_lite_version() {
		if ( ! defined( 'MODULA_LITE_VERSION' ) ) {
			return null;
		}

		return (string) MODULA_LITE_VERSION;
	}
}
