<?php
namespace Modula_Pro;

use Modula_Pro\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Templates {
	public function __construct() {
		add_filter( 'modula_template_paths', array( $this, 'add_templates_path' ), 20 );

		add_filter( 'modula_gallery_template_data', array( $this, 'filter_class_helper' ), 20, 1 );

		add_action( 'modula_shortcode_before_items', array( $this, 'gallery_title' ), 5, 4 );
	}

	public function add_templates_path( $paths ) {
		$paths[50] = trailingslashit( MODULA_PRO_PATH ) . '/includes/templates';
		return $paths;
	}

	public function filter_class_helper( $template_data ) {

		if ( isset( $template_data['settings']['filters'] ) && '' !== $template_data['settings']['filters'] ) {
			if ( isset( $template_data['settings']['filterPositioning'] ) ) {
				$horizontal_position = array( 'top', 'bottom', 'top_bottom' );
				$vertical_position   = array( 'left', 'right', 'left_right' );

				if ( in_array( $template_data['settings']['filterPositioning'], $vertical_position, true ) && ! empty( Helper::remove_empty_items( $template_data['settings']['filters'] ) ) ) {
					$template_data['gallery_container']['class'][] = 'vertical-filters';
				}

				if ( in_array( $template_data['settings']['filterPositioning'], $horizontal_position, true ) && ! empty( Helper::remove_empty_items( $template_data['settings']['filters'] ) ) ) {
					$template_data['gallery_container']['class'][] = 'horizontal-filters';
				}
			}
		}

		return $template_data;
	}

	/**
	 * Print the gallery title above the classic gallery's items.
	 *
	 * @param array  $settings        Gallery settings.
	 * @param mixed  $item_data       Unused.
	 * @param array  $images          Unused.
	 * @param string $display_context 'beta' when Lite's v2 shortcode prints the hook.
	 *
	 * @return void
	 */
	public function gallery_title( $settings, $item_data = null, $images = array(), $display_context = 'classic' ) {
		// Beta draws the title in its React tree.
		if ( 'beta' === $display_context ) {
			return;
		}

		$title = get_the_title( explode( '-', $settings['gallery_id'] )[1] );
		if ( isset( $settings['show_gallery_title'] ) && 1 === absint( $settings['show_gallery_title'] ) ) {
			echo ' <' . esc_attr( $settings['gallery_title_type'] ) . " class='modula-gallery-title'> " . esc_html( $title ) . ' </' . esc_attr( $settings['gallery_title_type'] ) . '> ';
		}
	}
}
