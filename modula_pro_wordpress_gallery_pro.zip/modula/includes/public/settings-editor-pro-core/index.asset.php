<?php return array('dependencies' => array('react-jsx-runtime', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n', 'wp-primitives'), 'version' => 'af4e991b259fa491ddba');
