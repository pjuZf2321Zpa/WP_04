<?php
/**
 * Image Guardian global (site-wide) settings for Modula General Settings.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Image_Guardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers Image Guardian site-wide settings in the Modula general-settings app.
 */
class Global_Settings {

	const OPTION_NAME = 'modula_image_guardian';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'modula_admin_page_subtabs', array( $this, 'add_subtab' ) );
		add_filter( 'modula_admin_page_main_tabs', array( $this, 'attach_to_protection' ) );
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_options' ) );
	}

	/**
	 * Default option values.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_defaults() {
		return array(
			'sitewide_enabled'         => false,
			'sitewide_message'         => '',
			'sitewide_block_dragging'  => true,
			'sitewide_block_selection' => true,
			'sitewide_blur'            => false,
			'exceptions'               => array(),
		);
	}

	/**
	 * Merged saved + defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_settings() {
		$saved    = get_option( self::OPTION_NAME, array() );
		$defaults = self::get_defaults();

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$settings = wp_parse_args( $saved, $defaults );

		$settings['sitewide_enabled']         = (bool) $settings['sitewide_enabled'];
		$settings['sitewide_block_dragging']  = (bool) $settings['sitewide_block_dragging'];
		$settings['sitewide_block_selection'] = (bool) $settings['sitewide_block_selection'];
		$settings['sitewide_blur']            = (bool) $settings['sitewide_blur'];
		$settings['sitewide_message']         = is_string( $settings['sitewide_message'] )
			? $settings['sitewide_message']
			: '';
		$settings['exceptions']               = self::sanitize_exception_ids(
			isset( $settings['exceptions'] ) ? $settings['exceptions'] : array()
		);

		return $settings;
	}

	/**
	 * Resolved toast message (custom or translated default).
	 *
	 * @param array<string, mixed>|null $settings Optional preloaded settings.
	 * @return string
	 */
	public static function get_resolved_message( $settings = null ) {
		if ( null === $settings ) {
			$settings = self::get_settings();
		}
		$custom = isset( $settings['sitewide_message'] ) ? trim( (string) $settings['sitewide_message'] ) : '';
		if ( '' !== $custom ) {
			return $custom;
		}

		return __( 'This content is protected.', 'modula-pro' );
	}

	/**
	 * @param mixed $ids Raw IDs.
	 * @return int[]
	 */
	public static function sanitize_exception_ids( $ids ) {
		if ( ! is_array( $ids ) ) {
			return array();
		}
		$out = array();
		foreach ( $ids as $id ) {
			$n = absint( $id );
			if ( $n > 0 && ! in_array( $n, $out, true ) ) {
				$out[] = $n;
			}
		}
		return $out;
	}

	/**
	 * Whether site-wide protection should run on the current front request.
	 *
	 * @return bool
	 */
	public static function should_apply_on_current_request() {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return false;
		}
		if ( is_feed() || is_preview() || is_customize_preview() ) {
			return false;
		}
		// Match gallery Image Guardian enqueue: editors with both caps bypass.
		if ( current_user_can( 'upload_files' ) && current_user_can( 'edit_posts' ) ) {
			return false;
		}

		$settings = self::get_settings();
		if ( empty( $settings['sitewide_enabled'] ) ) {
			return false;
		}

		$exceptions = $settings['exceptions'];
		if ( empty( $exceptions ) ) {
			return true;
		}

		$qid = get_queried_object_id();
		if ( $qid > 0 && in_array( $qid, $exceptions, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * @param array $subtabs Existing subtabs.
	 * @return array
	 */
	public function add_subtab( $subtabs ) {
		$subtabs['image_guardian'] = $this->get_subtab();
		return $subtabs;
	}

	/**
	 * Attach under Protection main tab (alongside Watermark / Roles).
	 *
	 * @param array $tabs Main tabs.
	 * @return array
	 */
	public function attach_to_protection( $tabs ) {
		$subtab = $this->get_subtab();
		foreach ( $tabs as &$tab ) {
			if ( isset( $tab['slug'] ) && 'protection' === $tab['slug'] ) {
				if ( ! isset( $tab['subtabs'] ) || ! is_array( $tab['subtabs'] ) ) {
					$tab['subtabs'] = array();
				}
				$tab['subtabs']['image_guardian'] = $subtab;
			}
		}
		unset( $tab );
		return $tabs;
	}

	/**
	 * @param array $options Uninstall list.
	 * @return array
	 */
	public function uninstall_options( $options ) {
		$options[] = self::OPTION_NAME;
		return $options;
	}

	/**
	 * @return array
	 */
	private function get_subtab() {
		$settings   = self::get_settings();
		$exceptions = $settings['exceptions'];
		$items      = array();
		foreach ( $exceptions as $id ) {
			$title   = get_the_title( $id );
			$items[] = array(
				'id'    => $id,
				'label' => $title ? $title : sprintf( '#%d', $id ),
			);
		}

		$on = array(
			array(
				'field'      => 'sitewide_enabled',
				'comparison' => '===',
				'value'      => true,
			),
		);

		return array(
			'label'  => esc_html__( 'Image Guardian', 'modula-pro' ),
			'badge'  => null,
			'locked' => false,
			'config' => array(
				'option' => self::OPTION_NAME,
				'fields' => array(
					array(
						'type'         => 'toggle',
						'name'         => 'sitewide_enabled',
						'label'        => esc_html__( 'Protect the whole site', 'modula-pro' ),
						'description'  => esc_html__( 'Blocks right-click, optional drag and text selection, and can blur the page when visitors leave the tab. Does not rewrite image URLs. Individual galleries can still use their own Image Guardian settings.', 'modula-pro' ),
						'default'      => $settings['sitewide_enabled'],
						'sanitization' => array( 'bool' ),
					),
					array(
						'type'         => 'textarea',
						'name'         => 'sitewide_message',
						'label'        => esc_html__( 'Protection notice', 'modula-pro' ),
						'description'  => esc_html__( 'Shown when someone tries to right-click. Leave empty to use the default: “This content is protected.” Translate via your multilingual plugin if needed.', 'modula-pro' ),
						'default'      => $settings['sitewide_message'],
						'sanitization' => array( 'text' ),
						'conditions'   => $on,
					),
					array(
						'type'         => 'toggle',
						'name'         => 'sitewide_block_dragging',
						'label'        => esc_html__( 'Block dragging images', 'modula-pro' ),
						'default'      => $settings['sitewide_block_dragging'],
						'sanitization' => array( 'bool' ),
						'conditions'   => $on,
					),
					array(
						'type'         => 'toggle',
						'name'         => 'sitewide_block_selection',
						'label'        => esc_html__( 'Block selecting text', 'modula-pro' ),
						'default'      => $settings['sitewide_block_selection'],
						'sanitization' => array( 'bool' ),
						'conditions'   => $on,
					),
					array(
						'type'         => 'toggle',
						'name'         => 'sitewide_blur',
						'label'        => esc_html__( 'Blur the page when leaving the tab', 'modula-pro' ),
						'default'      => $settings['sitewide_blur'],
						'sanitization' => array( 'bool' ),
						'conditions'   => $on,
					),
					array(
						'type'         => 'post_picker',
						'name'         => 'exceptions',
						'label'        => esc_html__( 'Exceptions', 'modula-pro' ),
						'description'  => esc_html__( 'Pages or posts where site-wide protection stays off.', 'modula-pro' ),
						'default'      => $exceptions,
						'items'        => $items,
						'sanitization' => array( 'number_array' ),
						'conditions'   => $on,
					),
				),
			),
		);
	}
}
