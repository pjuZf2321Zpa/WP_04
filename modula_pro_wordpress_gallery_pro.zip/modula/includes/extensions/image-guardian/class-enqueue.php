<?php
namespace Modula_Pro\Extensions\Image_Guardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/image-guardian';

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_protection_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_sitewide' ), 20 );

		add_filter( 'modula_necessary_scripts', array( $this, 'modula_protection_scripts' ), 15, 2 );
		add_filter( 'modula_link_necessary_scripts', array( $this, 'modula_protection_scripts' ), 15, 2 );
		add_filter( 'modula_necessary_styles', array( $this, 'modula_protection_styles' ), 15, 2 );
		add_filter( 'modula_link_necessary_styles', array( $this, 'modula_protection_styles' ), 15, 2 );

		add_filter( 'modula_shortcode_css', array( $this, 'output_css' ), 15, 3 );
	}

	/**
	 * Register protection script and style
	 */
	public function register_protection_scripts() {
		$base = \MODULA_PRO_URL . $this->extension_url . '/assets/';

		wp_register_script(
			'modula-protection-notice',
			$base . 'js/modula-protection-notice.js',
			array(),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_style(
			'modula-protection-notice',
			$base . 'css/modula-protection-notice.css',
			array(),
			\MODULA_PRO_VERSION
		);
		wp_register_script(
			'modula-sitewide-protection',
			$base . 'js/modula-sitewide-protection.js',
			array( 'modula-protection-notice' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_script(
			'modula-protection-script',
			$base . 'js/modula-protection.js',
			array( 'jquery', 'modula-pro', 'modula-protection-notice' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_script(
			'modula-blur-protection-script',
			$base . 'js/modula-blur-protection.js',
			array( 'jquery', 'modula-pro' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_style(
			'modula-protection-style',
			$base . 'css/modula-protection.css',
			array(),
			\MODULA_PRO_VERSION
		);
	}

	/**
	 * Site-wide soft protection (no URL rewrite).
	 */
	public function maybe_enqueue_sitewide() {
		if ( ! Global_Settings::should_apply_on_current_request() ) {
			return;
		}

		$settings = Global_Settings::get_settings();

		wp_enqueue_style( 'modula-protection-notice' );
		wp_enqueue_script( 'modula-protection-notice' );
		wp_enqueue_script( 'modula-sitewide-protection' );

		wp_localize_script(
			'modula-sitewide-protection',
			'modulaSitewideProtection',
			array(
				'message'        => Global_Settings::get_resolved_message( $settings ),
				'blockDragging'  => ! empty( $settings['sitewide_block_dragging'] ),
				'blockSelection' => ! empty( $settings['sitewide_block_selection'] ),
				'blur'           => ! empty( $settings['sitewide_blur'] ),
			)
		);
	}

	/**
	 * @param array $scripts  Script handles.
	 * @param array $settings Gallery settings.
	 * @return array
	 */
	public function modula_protection_scripts( $scripts, $settings ) {
		$visitor = ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_posts' );

		if ( isset( $settings['protection'] ) && boolval( $settings['protection'] ) && $visitor ) {
			$scripts[] = 'modula-protection-notice';
			$scripts[] = 'modula-protection-script';

			$message = '';
			if ( ! empty( $settings['right_click_message'] ) && is_string( $settings['right_click_message'] ) ) {
				$message = trim( $settings['right_click_message'] );
			} elseif ( ! empty( $settings['rightClickMessage'] ) && is_string( $settings['rightClickMessage'] ) ) {
				$message = trim( $settings['rightClickMessage'] );
			}
			if ( '' === $message ) {
				$message = __( 'This content is protected.', 'modula-pro' );
			}

			wp_enqueue_style( 'modula-protection-notice' );
			wp_localize_script(
				'modula-protection-script',
				'modulaGalleryProtection',
				array(
					'message' => $message,
				)
			);
		}

		if ( isset( $settings['blur_protection'] ) && boolval( $settings['blur_protection'] ) && $visitor ) {
			$scripts[] = 'modula-blur-protection-script';
		}

		return $scripts;
	}

	/**
	 * @param array $styles   Style handles.
	 * @param array $settings Gallery settings.
	 * @return array
	 */
	public function modula_protection_styles( $styles, $settings ) {
		$visitor = ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_posts' );

		if ( isset( $settings['blur_protection'] ) && boolval( $settings['blur_protection'] ) && $visitor ) {
			$styles[] = 'modula-protection-style';
		}

		if ( isset( $settings['protection'] ) && boolval( $settings['protection'] ) && $visitor ) {
			$styles[] = 'modula-protection-notice';
		}

		return $styles;
	}

	/**
	 * @param string $css        Existing CSS.
	 * @param int    $gallery_id Gallery ID.
	 * @param array  $settings   Gallery settings.
	 * @return string
	 */
	public function output_css( $css, $gallery_id, $settings ) {
		if ( isset( $settings['protection'] ) && 1 === absint( $settings['protection'] ) ) {
			$css .= '.modula-gallery a.tile-inner, .modula-gallery img.pic {-webkit-touch-callout: none;}.pp_pic_holder img {-webkit-touch-callout: none;}';
		}

		return $css;
	}
}
