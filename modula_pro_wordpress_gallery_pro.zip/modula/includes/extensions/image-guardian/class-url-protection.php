<?php

namespace Modula_Pro\Extensions\Image_Guardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *
 */
class Url_Protection {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		add_filter( 'modula_shortcode_item_data', array( $this, 'protect_image_links' ), 999, 3 );
		add_filter( 'modula_album_shortcode_item_data', array( $this, 'album_protect_image_links' ), 999, 4 );
		// A Beta album's covers and lightbox images (Album visitor frontend), under the classic item's keys.
		add_filter( 'modula_album_visitor_image_urls', array( $this, 'protect_image_links' ), 999, 3 );

		add_filter( 'query_vars', array( $this, 'image_id_query_var' ) );
		add_filter( 'modula_gallery_srcset_image_url', array( $this, 'speedup_process_srcset_url' ), 50, 2 );
		add_filter( 'modula_slider_thumbnail_src', array( $this, 'slider_thumbnail_src' ), 50, 3 );
		add_filter( 'modula_album_slider_thumbnail_src', array( $this, 'slider_thumbnail_src' ), 50, 3 );

		add_action( 'template_redirect', array( $this, 'handle_image_request' ) );
		add_action( 'init', array( $this, 'add_modula_image_endpoint' ) );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Url_Protection object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Url_Protection ) ) {
			self::$instance = new Url_Protection();
		}

		return self::$instance;
	}

	public function protect_image_links( $item_data, $item, $settings ) {

		if ( ! apply_filters( 'modula_apply_image_guardian_item_data', true, $item, $settings ) ) {
			return $item_data;
		}

		if ( empty( $settings['url_protection'] ) && empty( $settings['blur_protection'] ) && empty( $settings['protection'] ) ) {
			return $item_data;
		}

		$item_data['url_protection'] = ! empty( $settings['url_protection'] );

		$keys        = array( 'data-full', 'src', 'data-src', 'image_full', 'image_url', 'data-thumb', 'data-thumb-src', 'data-modula-image-src' );
		$ignore_keys = array( 'download' );

		$keys        = apply_filters( 'protect_image_keys', $keys, $item, $settings );
		$ignore_keys = apply_filters( 'protect_image_ignore_keys', $ignore_keys, $item, $settings );

		$item_data = $this->process_array( $item_data, $keys, $ignore_keys, $item, $settings );

		return $item_data;
	}

	public function album_protect_image_links( $item_data, $item, $gallery_settings, $album_settings ) {

		return $this->protect_image_links( $item_data, $item, $album_settings );
	}

	private function get_image_size_by_id( $id, $url ) {
		$meta = wp_get_attachment_metadata( $id );
		if ( ! $meta ) {
			return 'full';
		}

		if ( preg_match( '/-(\d+)x(\d+)(?:_c)?\.(jpe?g|png|gif|webp|avif|heic|heif|mp4|webm|ogg)$/i', $url, $m ) ) {
			$w = (int) $m[1];
			$h = (int) $m[2];

			if ( ! empty( $meta['sizes'] ) ) {
				foreach ( $meta['sizes'] as $name => $data ) {
					if ( (int) $data['width'] === $w && (int) $data['height'] === $h ) {
						return $name; // thumbnail/medium/large/etc
					}
				}
			}

			if ( ! empty( $meta['image_meta']['resized_images'] ) ) {
				foreach ( $meta['image_meta']['resized_images'] as $custom ) {
					if ( preg_match( '/^' . $w . 'x' . $h . '(?:_c)?$/', $custom ) ) {
						return $custom; // ex. "333x444_c"
					}
				}
			}
		}

		return 'full';
	}

	private function maybe_add_mip( $url, $settings ) {

		if ( ( ! empty( $settings['protection'] ) && $settings['protection'] )
		|| ( ! empty( $settings['blur_protection'] ) && $settings['blur_protection'] ) ) {
			if ( is_string( $url ) && '' !== $url ) {
				return add_query_arg( 'mip', '1', $url );
			}
		}
		return $url;
	}

	private function process_array( $arr, $keys, $ignore_keys, $item, $settings ) {
		foreach ( $arr as $k => &$v ) {
			if ( in_array( $k, $ignore_keys, true ) ) {
				continue;
			}

			if ( is_array( $v ) ) {
				$v = $this->process_array( $v, $keys, $ignore_keys, $item, $settings );
				continue;
			}

			if ( in_array( $k, $keys, true ) && is_string( $v ) ) {
				$maybe_url = trim( $v );

				if ( strpos( $maybe_url, home_url() ) !== false && preg_match( '/\.(jpe?g|png|gif|webp|avif|heic|heif)(?:\?.*)?$/i', $maybe_url ) ) {
					$attachment_id = isset( $item['id'] ) ? (int) $item['id'] : 0;
					if ( $attachment_id <= 0 ) {
						$attachment_id = (int) attachment_url_to_postid( $maybe_url );
					}

					if ( $attachment_id > 0 && ! empty( $settings['url_protection'] ) ) {
						$v = $this->build_protected_url( $attachment_id, $maybe_url, $settings );
					} else {
						$v = $this->maybe_add_mip( $maybe_url, $settings );
					}
				}
			}
		}
		return $arr;
	}

	public function speedup_process_srcset_url( $image_url, $data ) {
		if ( ! is_string( $image_url ) || '' === $image_url ) {
			return $image_url;
		}

		$attachment_id = isset( $data->link_attributes['data-image-id'] ) ? (int) $data->link_attributes['data-image-id'] : 0;

		if ( $attachment_id <= 0 ) {
			$attachment_id = (int) attachment_url_to_postid( $image_url );
		}
		if ( $attachment_id <= 0 ) {
			if ( isset( $data->settings['protection'] ) && $data->settings['protection'] ) {
				return add_query_arg( 'mip', '1', $image_url );
			}
			return $image_url;
		}

		if ( isset( $data->url_protection ) && $data->url_protection ) {
			$image_url = $this->build_protected_url(
				$attachment_id,
				$image_url,
				isset( $data->settings ) && is_array( $data->settings ) ? $data->settings : array()
			);
		} elseif ( isset( $data->settings['protection'] ) && $data->settings['protection'] ) {
				$image_url = add_query_arg( 'mip', '1', $image_url );
		}

		return $image_url;
	}


	public function slider_thumbnail_src( $thumbnail_url, $image, $settings ) {

		$attachment_id = isset( $image['id'] ) ? (int) $image['id'] : 0;

		if ( $attachment_id <= 0 ) {
			$attachment_id = (int) attachment_url_to_postid( $thumbnail_url );
		}

		if ( $attachment_id <= 0 ) {
			if ( isset( $dsettings['protection'] ) && $settings['protection'] ) {
				return add_query_arg( 'mip', '1', $thumbnail_url );
			}

			return $thumbnail_url;
		}

		if ( isset( $settings['url_protection'] ) && $settings['url_protection'] ) {
			$thumbnail_url = $this->build_protected_url(
				$attachment_id,
				$thumbnail_url,
				$settings
			);
		} else {
				$thumbnail_url = $this->maybe_add_mip( $thumbnail_url, $settings );
		}

		return $thumbnail_url;
	}

	/**
	 * Build protected image URL.
	 *
	 * @param int    $id        Attachment ID.
	 * @param string $url       Original image URL (doar pentru determinarea size-ului).
	 * @param array  $settings  Setări galerie (opțional).
	 * @return string           Protected URL (cu mip=1 dacă protection e on).
	 */
	private function build_protected_url( $id, $url, $settings = array() ) {
		$size = $this->get_image_size_by_id( $id, $url );

		$t   = time();
		$key = $this->image_guardian_signature( (int) $id, $size, $t );

		$protected_url = home_url( '/modula-image/' . $id . '?size=' . rawurlencode( $size ) . '&t=' . $t . '&key=' . $key );

		$protected_url = $this->maybe_add_mip( $protected_url, $settings );

		return $protected_url;
	}

	/**
	 * HMAC signature for protected image URLs.
	 *
	 * @param int    $image_id Attachment ID.
	 * @param string $size     Image size slug.
	 * @param int    $timestamp Unix timestamp.
	 * @return string
	 */
	private function image_guardian_signature( $image_id, $size, $timestamp ) {
		return hash_hmac( 'sha256', $image_id . '|' . $size . '|' . $timestamp, wp_salt( 'modula_image_guardian' ) );
	}



	public function add_modula_image_endpoint() {
		add_rewrite_rule(
			'^modula-image/([0-9]+)/?', // URL pattern
			'index.php?modula_ig_image_id=$matches[1]',
			'top'
		);
		if ( ! get_option( 'modula_i_g_rewrite_rules_flushed_v2', false ) ) {
				flush_rewrite_rules();
				update_option( 'modula_i_g_rewrite_rules_flushed_v2', true );
		}
	}

	public function image_id_query_var( $vars ) {
		$vars[] = 'modula_ig_image_id';
		return $vars;
	}

	public function handle_image_request() {

		$id = get_query_var( 'modula_ig_image_id' );
		if ( ! $id ) {
			return; // not our endpoint
		}

		// Security checks
		$referer  = isset( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
		$home_url = home_url();

		if ( empty( $referer ) || strpos( $referer, $home_url ) !== 0 ) {
			status_header( 403 );
			exit( 'Direct access not allowed' );
		}

		$dest = isset( $_SERVER['HTTP_SEC_FETCH_DEST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_SEC_FETCH_DEST'] ) ) : '';
		$mode = isset( $_SERVER['HTTP_SEC_FETCH_MODE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_SEC_FETCH_MODE'] ) ) : '';

		$is_download = isset( $_GET['dl'] ) && ! empty( $_GET['dl'] );

		// Allow: normal image request (HTTPS cu header OR fallback pe HTTP fără header)
		if ( 'image' === $dest || ( empty( $dest ) && empty( $mode ) && ! $is_download ) ) {
			// Pass Through
		} elseif ( $is_download && ( '' === $dest || 'document' === $dest || ( 'empty' === $dest && '1' === wp_unslash( $_GET['dl'] ) ) ) && ( 'navigate' === $mode || empty( $mode ) ) ) {
			// Modern lightbox downloads mark dl=1; Chrome uses destination "empty".
			header( 'Content-Disposition: attachment; filename="' . basename( get_attached_file( $id ) ) . '"' );
		} else {
			status_header( 403 );
			exit( 'Invalid request type' );
		}

		if ( ! isset( $_GET['t'], $_GET['key'] ) ) {
			status_header( 403 );
			exit( 'Invalid parameters' );
		}

		$image_id  = (int) $id;
		$timestamp = absint( wp_unslash( $_GET['t'] ) );
		$key       = sanitize_text_field( wp_unslash( $_GET['key'] ) );
		$size      = isset( $_GET['size'] ) ? sanitize_text_field( wp_unslash( $_GET['size'] ) ) : 'full';

		$max_age = (int) apply_filters( 'modula_image_guardian_url_ttl', WEEK_IN_SECONDS, $image_id );
		if ( $timestamp < ( time() - $max_age ) || $timestamp > ( time() + 300 ) ) {
			status_header( 403 );
			exit( 'Expired or invalid timestamp' );
		}

		$expected = $this->image_guardian_signature( $image_id, $size, $timestamp );
		if ( ! hash_equals( $expected, $key ) ) {
			status_header( 403 );
			exit( 'Invalid key' );
		}

		// Get size
		$file = '';

		// Standard WP sizes
		if ( in_array( $size, get_intermediate_image_sizes(), true ) || 'full' === $size ) {
			$src = wp_get_attachment_image_src( $image_id, $size );
			if ( $src ) {
				$file = str_replace( wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $src[0] );
			}
		} else {
			// Custom sizes (333x444 or 333x444_c)
			$file = self::modula_crop_file( wp_get_attachment_metadata( $image_id ), $size );
		}

		if ( '' === $file ) {
			status_header( 404 );
			exit( 'Image not found' );
		}

		if ( ! file_exists( $file ) ) {
			status_header( 404 );
			exit( 'File not found' );
		}

		// Use WP_Filesystem instead of readfile()
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		global $wp_filesystem;
		WP_Filesystem();

		$mime = wp_check_filetype( $file )['type'] ?? 'image/jpeg';

		status_header( 200 );
		header( 'Content-Type: ' . $mime );
		header( 'Content-Length: ' . filesize( $file ) );
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $wp_filesystem->get_contents( $file );
		exit;
	}

	/**
	 * Path of a Modula crop of this attachment that exists on disk.
	 *
	 * @param array|false $meta   Attachment metadata.
	 * @param string      $suffix Crop suffix as stored in `resized_images` (333x444 or 333x444_c).
	 * @return string Crop path, or '' when the suffix is not recorded or no crop file exists.
	 */
	public static function modula_crop_file( $meta, $suffix ) {
		if ( empty( $meta['file'] ) || empty( $meta['image_meta']['resized_images'] ) ) {
			return '';
		}

		if ( ! in_array( $suffix, (array) $meta['image_meta']['resized_images'], true ) ) {
			return '';
		}

		$original = trailingslashit( wp_upload_dir()['basedir'] ) . $meta['file'];
		foreach ( self::modula_crop_candidates( $original, $suffix ) as $path ) {
			if ( file_exists( $path ) ) {
				return $path;
			}
		}

		return '';
	}

	/**
	 * Every path a Modula crop of this file may sit at, most likely first.
	 *
	 * The image editor saves crops under a normalized extension (lowercased,
	 * or the `image_editor_output_format` target such as HEIC → JPEG), which
	 * Lite 3.0.18 predicts. An older Lite lacks the helper, so fall back to
	 * the original-extension path crops were predicted at before.
	 *
	 * @param string $original Path of the original image.
	 * @param string $suffix   Crop suffix.
	 * @return string[] Candidate paths.
	 */
	private static function modula_crop_candidates( $original, $suffix ) {
		if ( method_exists( 'Modula_Image', 'crop_file_paths' ) ) {
			return \Modula_Image::crop_file_paths( $original, $suffix );
		}

		$info = pathinfo( $original );

		return array( "{$info['dirname']}/{$info['filename']}-{$suffix}.{$info['extension']}" );
	}
}
