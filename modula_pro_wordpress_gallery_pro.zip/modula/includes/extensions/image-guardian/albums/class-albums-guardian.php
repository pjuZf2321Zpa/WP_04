<?php

namespace Modula_Pro\Extensions\Image_Guardian\Albums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 *
 */
class Albums_Guardian {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.2
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.2
	 */
	public function __construct() {

		// Filter Modula Protection Tab for Albums.
		add_filter( 'modula_album_tabs', array( $this, 'modula_protection_tabs' ) );

		// Filter Modula Protection Fields for Albums.
		add_filter( 'modula_album_fields', array( $this, 'modula_protection_fields' ) );
		// Filter Modula protection Scripts & Styles for Albums
		add_filter( 'modula_album_necessary_scripts', array( $this, 'modula_protection_scripts' ), 15, 2 );
		add_filter( 'modula_album_necessary_styles', array( $this, 'modula_protection_styles' ), 15, 2 );

		// Filter to output necessary css for protections for Albums
		add_filter( 'modula_album_shortcode_css', array( $this, 'output_css' ), 15, 3 );

		// Add defaults for Albums
		add_filter( 'modula_album_default_settings', array( $this, 'set_defaults' ) );

		// Register Protection Scripts for Albums
		add_action( 'wp_enqueue_scripts', array( $this, 'register_protection_scripts' ) );

		// Add protection option to Album Fancybox
		add_filter( 'modula_album_template_data', array( $this, 'album_protection_fancybox_options' ) );
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Modula_Albums_Protection object.
	 * @since 1.0.2
	 *
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Albums_Guardian ) ) {
			self::$instance = new Albums_Guardian();
		}

		return self::$instance;
	}

	/**
	 * Register protection script and style
	 */
	public function register_protection_scripts() {
		// Register Protection script for Albums
		wp_register_script( 'modula-albums-protection-script', \MODULA_PRO_URL . 'includes/extensions/image-guardian/assets/js/modula-albums-protection.js', array( 'jquery', 'modula-pro' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-blur-protection-script', \MODULA_PRO_URL . 'includes/extensions/image-guardian/assets/js/modula-blur-protection.js', array( 'jquery', 'modula-pro' ), \MODULA_PRO_VERSION, true );
		wp_register_style( 'modula-protection-style', \MODULA_PRO_URL . 'includes/extensions/image-guardian/assets/css/modula-protection.css', array(), \MODULA_PRO_VERSION );
	}

	public function modula_protection_scripts( $scripts, $settings ) {

		if ( isset( $settings['protection'] ) && 1 === absint( $settings['protection'] ) && ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_posts' ) ) ) {
			$scripts[] = 'modula-albums-protection-script';
		}

		if ( isset( $settings['blur_protection'] ) && 1 === absint( $settings['blur_protection'] ) && ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_posts' ) ) ) {
			$scripts[] = 'modula-blur-protection-script';
		}

		return $scripts;
	}

	/**
	 * @param $scripts
	 * @param $settings
	 *
	 * @return array
	 *
	 * Enqueue protection script
	 */
	public function modula_protection_styles( $scripts, $settings ) {

		if ( isset( $settings['blur_protection'] ) && 1 === absint( $settings['blur_protection'] ) && ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_posts' ) ) ) {
			$scripts[] = 'modula-protection-style';
		}

		return $scripts;
	}

	/**
	 * @param $tabs
	 * @return mixed
	 *
	 * Protection tab for Albums
	 */
	public function modula_protection_tabs( $tabs ) {

		if ( ! isset( $tabs['protection'] ) ) {
			$tabs['protection'] = array(
				'label'    => esc_html__( 'Image Guardian', 'modula-pro' ),
				'icon'     => 'dashicons dashicons-image-filter',
				'priority' => 100,
			);
		}

		return $tabs;
	}


	/**
	 * @param $fields
	 * @return mixed
	 *
	 * Protection Fields for Albums
	 */
	public function modula_protection_fields( $fields ) {

		if ( ! isset( $fields['protection'] ) || ! is_array( $fields['protection'] ) ) {
			$fields['protection'] = array();
		}

		if ( class_exists( 'Modula_Pro\Extensions\Albums\Albums' ) ) {
			// Add filters settings
			$fields['protection']['protection'] = array(
				'name'      => esc_html__( 'Enable right-click protection', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 10,
				'data_type' => 'bool',
			);

			$fields['protection']['url_protection'] = array(
				'name'      => esc_html__( 'Enable URL protection', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 20,
				'data_type' => 'bool',
			);

			$fields['protection']['blur_protection'] = array(
				'name'      => esc_html__( 'Enable Blur on loosing focus', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 30,
				'data_type' => 'bool',
			);
		}

		return $fields;
	}

	/**
	 * @param $css
	 * @param $gallery_id
	 * @param $settings
	 * @return string
	 *
	 * Output CSS required for protection for Albums
	 */
	public function output_css( $css, $gallery_id, $settings ) {

		if ( isset( $settings['protection'] ) && 1 === absint( $settings['protection'] ) ) {
			$css .= '.modula-album a.tile-inner, .modula-album img.pic {-webkit-touch-callout: none;}';
		}

		return $css;
	}

	/*
	 * Set protection default for Albums
	 */
	public function set_defaults( $defaults ) {
		$defaults['protection']      = 1;
		$defaults['blur_protection'] = 1;
		$defaults['url_protection']  = 0;

		return $defaults;
	}


	/**
	 * Add protection option to Fancybox
	 *
	 * @param $fancybox_options
	 * @param $settings
	 * @return array
	 *
	 * @since 1.0.3
	 */
	public function album_protection_fancybox_options( $template_data ) {

		if ( isset( $template_data['settings']['protection'] ) && 1 === absint( $template_data['settings']['protection'] ) ) {
			$template_data['js_config']['lightbox_settings']['Images']['protected'] = true;
		} else {
			$template_data['js_config']['lightbox_settings']['Images']['protected'] = false;
		}
		$template_data['album_container']['data-config'] = wp_json_encode( $template_data['js_config'] );
		return $template_data;
	}
}
