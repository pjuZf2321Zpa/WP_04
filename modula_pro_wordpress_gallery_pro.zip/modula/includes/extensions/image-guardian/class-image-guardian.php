<?php
namespace Modula_Pro\Extensions\Image_Guardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Modula_Pro\Extensions\Image_Guardian\Albums\Albums_Guardian;
use Modula_Pro\Extensions\Image_Guardian\Url_Protection;

/**
 * Image Guardian class for Modula Pro plugin.
 */
class Image_Guardian {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Filter Modula Protection Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'modula_protection_tabs' ) );

		// Filter Modula Protection Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_protection_fields' ) );

		// Add defaults
		add_filter( 'modula_lite_default_settings', array( $this, 'set_defaults' ) );

		// Add protection option to Fancybox
		add_filter( 'modula_fancybox_options', array( $this, 'protection_fancybox_options' ), 16, 2 );

		// Filter for Video
		add_filter( 'modula_fancybox_options', array( $this, 'disable_download_video' ), 12, 2 );
		// add protection data to migrator
		add_filter( 'modula_migrate_gallery_data', array( $this, 'right_click_protecton_migrator_data' ), 25, 3 );

		// Load the plugin.
		$this->init();

		add_action( 'modula_extension_modula-image-guardian_deactivated', array( $this, 'plugin_deactivation' ) );

		require_once __DIR__ . '/class-global-settings.php';
		new Global_Settings();

		new Enqueue();

		Albums_Guardian::get_instance();
	}

	/**
	 * Delete flush option so rules are flushed again if needed.
	 *
	 * @since 1.1.3
	 */
	public function plugin_deactivation() {
		delete_option( 'modula_i_g_rewrite_rules_flushed_v2' );
	}

	/**
	 * Loads the plugin into WordPress.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		Url_Protection::get_instance();
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Image_Guardian object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Image_Guardian ) ) {
			self::$instance = new Image_Guardian();
		}

		return self::$instance;
	}

	public function modula_protection_tabs( $tabs ) {

		if ( ! isset( $tabs['protection'] ) ) {
			$tabs['protection'] = array(
				'label'    => esc_html__( 'Image Guardian', 'modula-pro' ),
				'icon'     => 'dashicons dashicons-cover-image',
				'priority' => 101,
			);
		}

		unset( $tabs['protection']['badge'] );

		return $tabs;
	}

	// Modula PRO Fields
	public function modula_protection_fields( $fields ) {

		if ( ! isset( $fields['protection'] ) || ! is_array( $fields['protection'] ) ) {
			$fields['protection'] = array();
		}

		// Add filters settings
		$fields['protection']['protection'] = array(
			'name'      => esc_html__( 'Enable right-click protection', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 1,
			'priority'  => 10,
			'data_type' => 'bool',
		);

		$fields['protection']['url_protection'] = array(
			'name'      => esc_html__( 'Enable URL protection', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 0,
			'priority'  => 20,
			'data_type' => 'bool',
		);

		$fields['protection']['blur_protection'] = array(
			'name'      => esc_html__( 'Enable Blur on loosing focus', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 1,
			'priority'  => 30,
			'data_type' => 'bool',
		);

		return $fields;
	}

	/**
	 * Add protection option to Fancybox
	 *
	 * @param $fancybox_options
	 * @param $settings
	 * @return array
	 *
	 * @since 1.0.3
	 */
	public function protection_fancybox_options( $fancybox_options, $settings ) {

		if ( isset( $settings['protection'] ) && 1 === absint( $settings['protection'] ) ) {
			$fancybox_options['Images']['protected'] = true;
		} else {
			$fancybox_options['Images']['protected'] = false;
		}

		return $fancybox_options;
	}

	public function set_defaults( $defaults ) {
		$defaults['protection']      = 1;
		$defaults['blur_protection'] = 1;
		$defaults['url_protection']  = 0;

		return $defaults;
	}

	public function disable_download_video( $fancybox_options, $settings ) {

		if ( isset( $settings['protection'] ) && 1 === absint( $settings['protection'] ) ) {
			if ( isset( $fancybox_options['Html']['videoTpl'] ) ) {
				$fancybox_options['Html']['videoTpl'] = str_replace(
					'<video ',
					'<video oncontextmenu="return false" disablepictureinpicture ',
					$fancybox_options['Html']['videoTpl']
				);
			} else {
				$fancybox_options['Html']['videoTpl'] = '<video class="fancybox__html5video modula_html5_video" controls playsinline controlsList="nodownload" oncontextmenu="return false" disablepictureinpicture poster="{{poster}}" src="{{src}}" type="{{format}}">' .
				'Sorry, your browser doesn\'t support embedded videos, <a href="{{src}}">download</a> and watch with your favorite video player!' .
				'</video>';
			}
		}

		return $fancybox_options;
	}

	/**
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.5
	 */
	public function right_click_protecton_migrator_data( $modula_settings, $guest_settings, $source ) {

		if ( $source ) {
			switch ( $source ) {
				case 'envira':
					if ( isset( $guest_settings['config']['protection'] ) && 1 === absint( $guest_settings['config']['protection'] ) ) {
						$modula_settings['protection'] = 1;
					}

					break;
			}
		}

		return $modula_settings;
	}
}
