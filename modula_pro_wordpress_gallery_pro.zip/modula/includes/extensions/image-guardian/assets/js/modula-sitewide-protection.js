/**
 * Site-wide Image Guardian (no URL rewrite).
 *
 * @param window
 * @param document
 * @package
 */
( function ( window, document ) {
	'use strict';

	const cfg =
		typeof window.modulaSitewideProtection === 'object' &&
		window.modulaSitewideProtection
			? window.modulaSitewideProtection
			: {};

	const message =
		typeof cfg.message === 'string' && cfg.message.trim() !== ''
			? cfg.message.trim()
			: '';
	const blockDragging = !! cfg.blockDragging;
	const blockSelection = !! cfg.blockSelection;
	const blurOnLeave = !! cfg.blur;

	function showNotice() {
		if (
			window.ModulaProtectionNotice &&
			typeof window.ModulaProtectionNotice.show === 'function'
		) {
			window.ModulaProtectionNotice.show( message );
		}
	}

	function onContextMenu( event ) {
		event.preventDefault();
		showNotice();
	}

	function onDragStart( event ) {
		if ( ! blockDragging ) {
			return;
		}
		const target = event.target;
		if (
			target &&
			( target.tagName === 'IMG' ||
				target.tagName === 'PICTURE' ||
				( target.closest && target.closest( 'img, picture' ) ) )
		) {
			event.preventDefault();
			showNotice();
		}
	}

	function onBlur() {
		if ( blurOnLeave ) {
			document.documentElement.classList.add(
				'modula-sitewide-tab-blurred'
			);
		}
	}

	function onFocus() {
		document.documentElement.classList.remove(
			'modula-sitewide-tab-blurred'
		);
	}

	document.addEventListener( 'contextmenu', onContextMenu, true );
	document.addEventListener( 'dragstart', onDragStart, true );
	window.addEventListener( 'blur', onBlur );
	window.addEventListener( 'focus', onFocus );

	if ( blockSelection ) {
		document.documentElement.classList.add(
			'modula-sitewide-block-selection'
		);
	}
	if ( blurOnLeave ) {
		document.documentElement.classList.add( 'modula-sitewide-blur-ready' );
	}
} )( window, document );
