/**
 * Shared Image Guardian protection notice (gallery + site-wide).
 *
 * @param window
 * @param document
 * @package
 */
( function ( window, document ) {
	'use strict';

	const HIDE_MS = 2800;
	let throttleUntil = 0;
	let hideTimer = null;
	let el = null;

	function ensureEl() {
		if ( el && document.body.contains( el ) ) {
			return el;
		}
		el = document.createElement( 'div' );
		el.className = 'modula-protection-notice';
		el.setAttribute( 'role', 'status' );
		el.setAttribute( 'aria-live', 'polite' );
		document.body.appendChild( el );
		return el;
	}

	/**
	 * @param {string} message
	 */
	function show( message ) {
		const text =
			typeof message === 'string' && message.trim() !== ''
				? message.trim()
				: '';
		if ( ! text ) {
			return;
		}
		const now = Date.now();
		if ( now < throttleUntil ) {
			return;
		}
		throttleUntil = now + 400;

		const node = ensureEl();
		node.textContent = text;
		node.classList.add( 'is-visible' );

		if ( hideTimer ) {
			window.clearTimeout( hideTimer );
		}
		hideTimer = window.setTimeout( function () {
			node.classList.remove( 'is-visible' );
		}, HIDE_MS );
	}

	window.ModulaProtectionNotice = {
		show,
	};
} )( window, document );
