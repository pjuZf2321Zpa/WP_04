jQuery( document ).ready( function ( $ ) {
	function isDevToolsOpen() {
		const start = performance.now();
		//  debugger;
		const end = performance.now();
		return end - start > 50;
	}

	function protectImages() {
		$( 'body' ).addClass( 'modula-protect-images' );
	}

	function unprotectImages() {
		$( 'body' ).removeClass( 'modula-protect-images' );
	}

	// Flash protect for PrintScreen
	function flashProtect( duration = 1500 ) {
		$( 'body' ).addClass( 'modula-flash-protect' );
		setTimeout( () => {
			$( 'body' ).removeClass( 'modula-flash-protect' );
		}, duration );
	}

	// ====== Focus ======
	$( window ).on( 'blur', function () {
		protectImages();
	} );

	$( window ).on( 'focus', function () {
		if ( ! isDevToolsOpen() ) {
			unprotectImages();
		}
	} );

	// ====== Key combos ======
	$( document ).on( 'keydown', function ( e ) {
		const code = e.code;

		// PrintScreen
		if ( code === 'PrintScreen' ) {
			flashProtect();
			try {
				navigator.clipboard.writeText( '' );
			} catch ( err ) {}
		}

		// Print dialog
		if ( ( e.ctrlKey || e.metaKey ) && e.key.toLowerCase() === 'p' ) {
			e.preventDefault();
			protectImages();
			alert( 'Printing is disabled on this page.' );
		}

		// DevTools shortcuts
		if (
			( e.ctrlKey &&
				e.shiftKey &&
				[ 'KeyI', 'KeyC' ].includes( code ) ) ||
			( e.metaKey && e.shiftKey && [ 'KeyI', 'KeyC' ].includes( code ) )
		) {
			protectImages();
		}
	} );

	// ====== Clipboard fallback ======
	$( document ).on( 'paste', function () {
		flashProtect();
	} );

	// ====== DevTools detect ======
	$( window ).on( 'resize', function () {
		if ( isDevToolsOpen() ) {
			protectImages();
		} else if ( document.hasFocus() ) {
			unprotectImages();
		}
	} );

	setInterval( () => {
		if ( isDevToolsOpen() ) {
			protectImages();
		}
	}, 2000 );
} );
