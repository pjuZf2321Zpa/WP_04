<?php
namespace Modula_Pro\Extensions\Utils;

class Plugin {
	/**
	 * Static array to collect all plugin file paths that need the dependency warning hidden.
	 *
	 * @var array
	 */
	private static $plugins_to_hide_dependency = array();
	private static $deactivated_plugins        = array();

	private static $instance;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Plugin ) ) {
			self::$instance = new Plugin();
		}
		return self::$instance;
	}

	public function get_deactivated_plugins() {
		return self::$deactivated_plugins;
	}

	/**
	 * Mark the plugin for delete.
	 *
	 * @param string $slug The slug of the plugin.
	 */
	public static function deactivate_and_mark_for_delete( $slug, $file_path ) {
		// Deactivate the plugin if it is active
		if ( \is_plugin_active( $file_path ) ) {
			deactivate_plugins( $file_path );
			self::$deactivated_plugins[] = $slug;
			if ( 'modula-albums' === $slug ) {
				self::$deactivated_plugins[] = 'modula-standalone';
			}
		}

		// Removes everything except the delete action
		add_filter(
			'plugin_action_links_' . $file_path,
			function ( array $actions ) {
				$delete = isset( $actions['delete'] ) ? array( 'delete' => $actions['delete'] ) : array();
				return $delete;
			},
			10,
			4
		);

		// Adds a notice to the plugin row (replaces the dependency warning)
		add_action(
			'after_plugin_row_meta',
			function ( $plugin_file ) use ( $file_path ) {
				if ( $plugin_file !== $file_path ) {
					return;
				}
				wp_admin_notice(
					esc_html__( 'This add-on has been superseded by the Pro plugin and is no longer needed. You can safely delete it.', 'modula-pro' ),
					array(
						'type'               => 'info',
						'additional_classes' => array( 'notice-alt', 'inline', 'warning' ),
					)
				);
			},
			10,
			2
		);

		// Collect file paths for combined CSS output
		self::$plugins_to_hide_dependency[] = $file_path;

		// Add the style output only once (using a static flag). It targets the
		// plugins list table, so print it on that screen only, never on the frontend.
		static $style_output = false;
		if ( ! $style_output ) {
			$style_output = true;
			add_action(
				'admin_footer-plugins.php',
				function () {
					if ( empty( self::$plugins_to_hide_dependency ) ) {
						return;
					}
					$selectors = array();
					$wrappers  = array();
					foreach ( self::$plugins_to_hide_dependency as $file_path ) {
						$selectors[] = 'tr[data-plugin="' . esc_attr( $file_path ) . '"] .requires';
						$wrappers[]  = 'tr[data-plugin="' . esc_attr( $file_path ) . '"]';
					}
					$css_rule     = implode( ', ', $selectors ) . ' { display: none !important; }';
					$wrapper_rule = implode( ', ', $wrappers ) . ' { opacity: 0.7 !important; }';
					?>
					<style>
						<?php
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo $css_rule;
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo $wrapper_rule;
						?>
					</style>
					<?php
				},
				10,
				1
			);
		}
	}
}
