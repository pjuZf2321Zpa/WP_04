<?php

namespace Modula_Pro\Extensions\Download;

use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Albums\V2\Members_Document;
use Modula_Pro\Extensions\Download\Admin\Album_Settings;
use Modula_Pro\Extensions\Download\Admin\Gallery_Settings;

class Download {

	const ZIP_CHUNK_SIZE = 25;

	/**
	 * Post types a ZIP can be built for, and where each keeps its download data.
	 *
	 * - `settings_meta` / `defaults`: the settings meta key and its defaults callback.
	 * - `enable_key`: the setting that turns downloads on.
	 * - `cache_prefix`: the ZIP cache key's prefix. `v2` drops every ZIP cached before
	 *   the download gate and public-only album members, which may hold private images.
	 */
	const DOWNLOAD_TYPES = array(
		'modula-gallery' => array(
			'settings_meta' => 'modula-settings',
			'defaults'      => array( \Modula_CPT_Fields_Helper::class, 'get_defaults' ),
			'enable_key'    => 'enable_download',
			'cache_prefix'  => 'modula_zip_cache_v2_jtg-',
		),
		'modula-album'   => array(
			'settings_meta' => 'modula-album-settings',
			'defaults'      => array( Fields_Helper::class, 'get_defaults' ),
			'enable_key'    => 'enable_download_albums',
			'cache_prefix'  => 'modula_zip_cache_v2_jtg-album-',
		),
	);

	/**
	 * Meta keys whose change alters a ZIP's content without a post save.
	 */
	const ZIP_CONTENT_META_KEYS = array( 'modula-images', 'modula-settings', 'modula-album-galleries', 'modula-album-settings' );

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Post IDs whose ZIPs this request already dropped.
	 *
	 * @var array<int, true>
	 */
	private $invalidated_posts = array();

	/**
	 * Primary class construct
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'require_admin' ), 25 );

		if ( ! is_admin() ) {
			add_action( 'init', array( $this, 'modula_force_download' ) );
		}

		$this->require_helpers();

		add_filter( 'modula_lite_default_settings', array( $this, 'modula_download_defaults' ) );
		add_filter( 'modula_album_default_settings', array( $this, 'modula_download_albums_defaults' ) );

		add_filter( 'modula_gallery_placeholders', array( $this, 'modula_download_placeholders' ), 15, 1 );
		add_filter( 'modula_albums_placeholders', array( $this, 'modula_albums_download_placeholders' ), 15, 1 );
		add_filter( 'modula_placeholder_values', array( $this, 'modula_download_placeholder_values' ), 15, 2 );
		add_filter( 'modula_albums_placeholder_values', array( $this, 'modula_albums_download_placeholder_values' ), 15, 2 );

		// filter for Modula migrator gallery settings
		add_filter( 'modula_migrate_gallery_data', array( $this, 'modula_download_migrate_data' ), 25, 3 );

		add_action( 'modula_extension_modula-download_deactivated', array( $this, 'plugin_deactivation' ) );

		// Schedule cleanup cron job
		add_action( 'modula_download_cleanup_cron', array( $this, 'cleanup_old_zip_files' ) );

		new Enqueue();
		new Shortcode();

		add_action( 'wp_ajax_modula_start_download', array( $this, 'ajax_start_download' ) );
		add_action( 'wp_ajax_nopriv_modula_start_download', array( $this, 'ajax_start_download' ) );
		add_action( 'wp_ajax_modula_process_chunk', array( $this, 'ajax_process_chunk' ) );
		add_action( 'wp_ajax_nopriv_modula_process_chunk', array( $this, 'ajax_process_chunk' ) );
		add_action( 'wp_ajax_modula_download_zip', array( $this, 'ajax_download_zip' ) );
		add_action( 'wp_ajax_nopriv_modula_download_zip', array( $this, 'ajax_download_zip' ) );

		add_action( 'save_post_modula-gallery', array( $this, 'invalidate_zip_cache' ) );
		add_action( 'save_post_modula-album', array( $this, 'invalidate_zip_cache' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $meta_hook ) {
			add_action( $meta_hook, array( $this, 'invalidate_zip_cache_on_meta' ), 10, 3 );
		}
	}

	/**
	 * Clean up scheduled events on plugin deactivation
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function plugin_deactivation() {
		// Clear the scheduled cleanup cron job
		wp_clear_scheduled_hook( 'modula_download_cleanup_cron' );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Modula_Download object.
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Download ) ) {
			self::$instance = new Download();
		}

		return self::$instance;
	}


	/**
	 * Loads all the helper functions into scope
	 *
	 * @since 1.0.0
	 */
	public function require_helpers() {
		require_once \MODULA_PRO_PATH . 'includes/extensions/download/helpers/download-helper.php';
	}

	/**
	 * Add defaults settings for download
	 *
	 * @param array $defaults
	 *
	 * @return array $defaults
	 * @since 1.0.0
	 */
	public function modula_download_defaults( $defaults ) {
		$defaults['enable_download']                  = 0;
		$defaults['download_gallery_button']          = 1;
		$defaults['download_image_sizes']             = 'full';
		$defaults['download_all_gallery_button']      = 1;
		$defaults['download_all_color']               = '';
		$defaults['download_all_background_color']    = '';
		$defaults['download_all_size']                = 'medium';
		$defaults['download_all_hposition']           = 'center';
		$defaults['download_all_position']            = 'below_gallery';
		$defaults['download_all_label']               = 'Download All Images';
		$defaults['custom_zip_name']                  = '%%gallery_title%%';
		$defaults['download_all_lightbox_button']     = 1;
		$defaults['download_all_gallery_button_icon'] = 1;
		$defaults['download_all_gallery_icon_color']  = '';

		return $defaults;
	}

	/**
	 * Add defaults settings for download
	 *
	 * @param array $defaults
	 *
	 * @return array $defaults
	 * @since 1.0.0
	 */
	public function modula_download_albums_defaults( $defaults ) {
		$defaults['enable_download_albums']                  = 0;
		$defaults['download_gallery_button_albums']          = 1;
		$defaults['download_image_sizes_albums']             = 'full';
		$defaults['download_gallery_button_position_albums'] = 'top_left';
		$defaults['download_all_gallery_button_albums']      = 1;
		$defaults['download_all_size_albums']                = 'medium';
		$defaults['download_all_hposition_albums']           = 'center';
		$defaults['download_all_position_albums']            = 'below_gallery';
		$defaults['download_all_label_albums']               = 'Download All Images';
		$defaults['custom_zip_name_albums']                  = '%%album_title%%';
		$defaults['download_all_lightbox_button_albums']     = 1;
		$defaults['download_gallery_button_color_albums']    = '#ffffff';
		$defaults['download_all_gallery_button_icon_albums'] = 1;
		$defaults['download_all_gallery_icon_color_albums']  = '';
		$defaults['download_all_color_albums']               = '';
		$defaults['download_all_background_color_albums']    = '';
		$defaults['download_all_font_size_albums ']          = 0;
		$defaults['download_all_mobile_font_size_albums ']   = 0;

		return $defaults;
	}

	/**
	 * Add Modula Download placeholders
	 *
	 * @param $placeholders
	 *
	 * @return mixed
	 * @since 1.0.0
	 */
	public function modula_download_placeholders( $placeholders ) {

		$placeholders = array_merge(
			array(
				'%%gallery_title%%'          => esc_html__( 'Gallery Title', 'modula-pro' ),
				'%%gallery_id%%'             => esc_html__( 'Gallery ID', 'modula-pro' ),
				'%%gallery_author%%'         => esc_html__( 'Gallery Author', 'modula-pro' ),
				'%%gallery_date%%'           => esc_html__( 'Gallery Date', 'modula-pro' ),
				'%%archive_generated_time%%' => esc_html__( 'Zip Created Time', 'modula-pro' ),
			),
			$placeholders
		);

		return $placeholders;
	}

	/**
	 * Add Modula Download placeholders
	 *
	 * @param $placeholders
	 *
	 * @return mixed
	 * @since 1.0.0
	 */
	public function modula_albums_download_placeholders( $placeholders ) {

		$placeholders = array_merge(
			array(
				'%%album_title%%'            => esc_html__( 'Album Title', 'modula-pro' ),
				'%%album_id%%'               => esc_html__( 'Album ID', 'modula-pro' ),
				'%%album_author%%'           => esc_html__( 'Album Author', 'modula-pro' ),
				'%%album_date%%'             => esc_html__( 'Album Date', 'modula-pro' ),
				'%%archive_generated_time%%' => esc_html__( 'Zip Created Time', 'modula-pro' ),
			),
			$placeholders
		);

		return $placeholders;
	}


	/**
	 * Modula Download placeholder real values
	 *
	 * @param $values
	 * @param $object
	 *
	 * @return array
	 * @since 1.0.0
	 */
	public function modula_download_placeholder_values( $values, $curr_obj ) {
		if ( is_wp_error( $curr_obj ) ) {
			return $values;
		}

		return array_merge(
			$values,
			array(
				'setting' => array(
					'%%gallery_title%%',
					'%%gallery_id%%',
					'%%gallery_author%%',
					'%%gallery_date%%',
					'%%archive_generated_time%%',
				),
				'front'   => array(
					$curr_obj->post_title . ' ',
					$curr_obj->ID . ' ',
					get_the_author_meta( 'nickname', $curr_obj->post_author ) . ' ',
					explode( ' ', $curr_obj->post_date )[0] . ' ',
					gmdate( 'Y-m-d' ) . ' ',
				),
			)
		);
	}

	/**
	 * Modula Download placeholder real values
	 *
	 * @param $values
	 * @param $curr_obj
	 *
	 * @return array
	 * @since 1.0.0
	 */
	public function modula_albums_download_placeholder_values( $values, $curr_obj ) {
		if ( is_wp_error( $curr_obj ) ) {
			return $values;
		}

		return array_merge(
			$values,
			array(
				'setting' => array(
					'%%album_title%%',
					'%%album_id%%',
					'%%album_author%%',
					'%%album_date%%',
					'%%archive_generated_time%%',
				),
				'front'   => array(
					$curr_obj->post_title . ' ',
					$curr_obj->ID . ' ',
					get_the_author_meta( 'nickname', $curr_obj->post_author ) . ' ',
					explode( ' ', $curr_obj->post_date )[0] . ' ',
					gmdate( 'Y-m-d' ) . ' ',
				),
			)
		);
	}

	/**
	 * Force Download the browser to download the gallery
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function modula_force_download() {
		if ( ! isset( $_REQUEST['modula-id'] ) ) {
			return;
		}

		// Any other ?modula-id= is not a download request: leave it alone.
		$post = self::post_from_download_id( sanitize_text_field( wp_unslash( $_REQUEST['modula-id'] ) ) );
		if ( ! self::is_downloadable_post( $post ) ) {
			return;
		}

		$id        = $post->ID;
		$post_type = $post->post_type;

		if ( ! self::is_download_allowed( $post ) ) {
			status_header( 403 );
			exit;
		}

		$settings     = self::download_settings( $post );
		$images       = array();
		$custom_name  = 'modula-pro';
		$upload_dir   = wp_upload_dir();
		$images_paths = array();

		if ( 'modula-gallery' === $post_type ) {
			$images = get_post_meta( $id, 'modula-images', true );

			$custom_name = 'modula-gallery-' . $id;
			if ( ! empty( $settings['custom_zip_name'] ) ) {
				$gallery_info = get_post( $id );

				if ( class_exists( 'Modula_Pro\Utils\Helper' ) && ! empty( \Modula_Helper::modula_placeholders_value( $settings['custom_zip_name'], $gallery_info ) ) && ' ' !== \Modula_Helper::modula_placeholders_value( $settings['custom_zip_name'], $gallery_info ) ) {
					$custom_name = str_replace( '/', '-', trim( sanitize_text_field( \Modula_Helper::modula_placeholders_value( $settings['custom_zip_name'], $gallery_info ) ), '/' ) );
				}
			}
		}

		if ( 'modula-album' === $post_type ) {
			$images = $this->get_album_zip_images( $id );

			$custom_name = 'modula-album-' . $id;

			if ( ! empty( $settings['custom_zip_name_albums'] ) ) {
				$album_info = get_post( $id );
				if ( class_exists( 'Modula_Pro\Utils\Helper' ) && ! empty( \Modula_Pro\Utils\Helper::modula_albums_placeholders_value( $settings['custom_zip_name_albums'], $album_info ) ) && ' ' !== \Modula_Pro\Utils\Helper::modula_albums_placeholders_value( $settings['custom_zip_name_albums'], $album_info ) ) {
					$custom_name = str_replace( '/', '-', trim( sanitize_text_field( \Modula_Pro\Utils\Helper::modula_albums_placeholders_value( $settings['custom_zip_name_albums'], $album_info ) ), '/' ) );
				}
			}
		}

		if ( ! empty( $images ) ) {
			foreach ( $images as $image ) {
				$image_object = false;

				if ( isset( $settings['enable_download'] ) ) {
					if ( $settings['enable_download'] ) {
						if ( isset( $settings['download_image_sizes'] ) && 'full' !== $settings['download_image_sizes'] ) {
							$image_object = wp_get_attachment_image_src( $image['id'], $settings['download_image_sizes'] );
						} elseif ( 'full' === $settings['download_image_sizes'] ) {
							$image_url = wp_get_original_image_url( $image['id'] );
						}
					} else {
						$image_url = wp_get_original_image_url( $image['id'] );
					}
				}

				if ( isset( $settings['enable_download_albums'] ) ) {
					if ( $settings['enable_download_albums'] ) {
						if ( isset( $settings['download_image_sizes_albums'] ) && 'full' !== $settings['download_image_sizes_albums'] ) {
							$image_object = wp_get_attachment_image_src( $image['id'], $settings['download_image_sizes_albums'] );
						} elseif ( 'full' === $settings['download_image_sizes_albums'] ) {
							$image_url = wp_get_original_image_url( $image['id'] );
						}
					} else {
						$image_url = wp_get_original_image_url( $image['id'] );
					}
				}

				if ( $image_object ) {
					$image_url = $image_object[0];
				}

				$baseurl  = preg_replace( '#^https?://#i', '', rtrim( $upload_dir['baseurl'], '/' ) );
				$imageurl = preg_replace( '#^https?://#i', '', rtrim( $image_url, '/' ) );

				$image_path = str_replace( $baseurl, $upload_dir['basedir'], $imageurl );

				$image_path = wp_normalize_path( $image_path );

				if ( $image_path ) {
					$images_paths[] = $image_path;
				}
			}
		}

		$requested_file_path = "{$upload_dir['path']}/{$custom_name}.zip";

		$result    = modula_download_zip( $images_paths, $requested_file_path );
		$file_path = str_replace( content_url(), WP_CONTENT_DIR, $requested_file_path );

		// Run cleanup after creating new zip to prevent accumulation
		modula_download_cleanup_old_zips( 7 );

		modula_download_file( $file_path, $requested_file_path );
	}

	/**
	 * Add download settings to Modula migrator
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.1
	 */
	public function modula_download_migrate_data( $modula_settings, $guest_settings, $source ) {

		if ( isset( $source ) ) {
			switch ( $source ) {
				case 'envira':
					if ( isset( $guest_settings['config']['download'] ) && 1 === $guest_settings['config']['download'] ) {
						$modula_settings['enable_download'] = 1;
					}

					if ( isset( $guest_settings['config']['download_image_size'] ) ) {
						if ( 'thumbnail' === $guest_settings['config']['download_image_size'] || 'medium' === $guest_settings['config']['download_image_size'] || 'large' === $guest_settings['config']['download_image_size'] || 'full' === $guest_settings['config']['download_image_size'] ) {
							$modula_settings['download_image_sizes'] = $guest_settings['config']['download_image_size'];
						}
					}

					if ( isset( $guest_settings['config']['download_all'] ) && 1 === $guest_settings['config']['download_all'] ) {
						$modula_settings['download_all_gallery_button'] = 1;
					}

					if ( isset( $guest_settings['config']['download_custom_name'] ) && 'envira-gallery' !== $guest_settings['config']['download_custom_name'] ) {
						$modula_settings['custom_zip_name'] = $guest_settings['config']['download_custom_name'];
					}

					if ( isset( $guest_settings['config']['download_all_position'] ) ) {
						if ( 'above' === $guest_settings['config']['download_all_position'] ) {
							$modula_settings['download_all_position'] = 'above_gallery';
						} elseif ( 'below' === $guest_settings['config']['download_all_position'] ) {
							$modula_settings['download_all_position'] = 'below_gallery';
						} else {
							$modula_settings['download_all_position'] = 'above_below_gallery';
						}
					}

					if ( isset( $guest_settings['config']['download_all_label'] ) && '' !== $guest_settings['config']['download_all_label'] ) {
						$modula_settings['download_all_label'] = $guest_settings['config']['download_all_label'];
					}

					break;
			}
		}

		return $modula_settings;
	}

	/**
	 * Cleanup old zip files via cron job
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function cleanup_old_zip_files() {
		// Run cleanup for files older than 7 days
		$deleted_count = modula_download_cleanup_old_zips( 7 );

		// Log the cleanup activity
		if ( $deleted_count > 0 ) {
			error_log( sprintf( 'Modula Download: Weekly cleanup completed. Deleted %d old zip files.', $deleted_count ) );
		}
	}

	/**
	 * Manually trigger cleanup for testing purposes
	 * Can be called via: wp-cli or admin action
	 *
	 * @param int $days_old Number of days after which files should be deleted
	 * @return int Number of files deleted
	 * @since 1.0.0
	 */
	public function manual_cleanup( $days_old = 7 ) {
		return modula_download_cleanup_old_zips( $days_old );
	}

	/**
	 * Whether the current request may download a gallery's or album's ZIP.
	 *
	 * The one gate for every download path, direct (`?modula-id=`) and
	 * chunked AJAX: published or editable by the user, downloads enabled for
	 * it, its post password and Password Protect satisfied, and no
	 * `modula_pre_output_filter_check` block.
	 *
	 * On admin-ajax the filter's callbacks see is_admin() and return early,
	 * and Image Proofing's invite check reads `mip_name` from the page URL,
	 * which the AJAX request doesn't carry. The password checks run here
	 * directly for that reason; invite-only proofing is enforced on the
	 * direct path only.
	 *
	 * @param \WP_Post|null $post Gallery or album.
	 * @return bool
	 */
	public static function is_download_allowed( $post ) {
		if ( ! self::is_downloadable_post( $post ) ) {
			return false;
		}
		if ( 'publish' !== $post->post_status && ! current_user_can( 'edit_post', $post->ID ) ) {
			return false;
		}

		$settings = self::download_settings( $post );
		if ( empty( $settings[ self::DOWNLOAD_TYPES[ $post->post_type ]['enable_key'] ] ) || post_password_required( $post ) ) {
			return false;
		}
		if ( ! self::passes_password_protect( $post ) ) {
			return false;
		}
		return ! apply_filters( 'modula_pre_output_filter_check', false, $settings, $post );
	}

	/**
	 * Transient that caches a post's built ZIP.
	 *
	 * Keyed by post, not by the id string the button sent (`jtg-12`,
	 * `modula-12`, …), so invalidate_zip_cache() always finds it.
	 *
	 * @param \WP_Post $post Gallery or album.
	 * @return string
	 */
	public static function zip_cache_key( $post ) {
		return self::DOWNLOAD_TYPES[ $post->post_type ]['cache_prefix'] . $post->ID;
	}

	/**
	 * Whether a post is a gallery or album a ZIP can be built for.
	 *
	 * @param mixed $post Post or null.
	 * @return bool
	 */
	private static function is_downloadable_post( $post ) {
		return $post instanceof \WP_Post && isset( self::DOWNLOAD_TYPES[ $post->post_type ] );
	}

	/**
	 * Gallery or album settings with their defaults.
	 *
	 * @param \WP_Post $post Gallery or album.
	 * @return array<string, mixed>
	 */
	private static function download_settings( $post ) {
		$type = self::DOWNLOAD_TYPES[ $post->post_type ];
		return wp_parse_args( get_post_meta( $post->ID, $type['settings_meta'], true ), call_user_func( $type['defaults'] ) );
	}

	/**
	 * Whether Password Protect, when active, lets the visitor through.
	 *
	 * @param \WP_Post $post Gallery or album.
	 * @return bool
	 */
	private static function passes_password_protect( $post ) {
		if ( ! class_exists( '\Modula_Pro\Extensions\Password_Protect\Password_Protect_Module' ) ) {
			return true;
		}
		$pp_module = \Modula_Pro\Extensions\Password_Protect\Password_Protect_Module::get_instance();
		if ( ! is_object( $pp_module ) || ! method_exists( $pp_module, 'post_username_validation' ) ) {
			return true;
		}
		return (bool) $pp_module->post_username_validation( $post );
	}

	/**
	 * The post a download button's id names (`jtg-12`, `jtg-album-12`, `modula-12`).
	 *
	 * @param string $gallery_id_raw Id string from the request or the job.
	 * @return \WP_Post|null
	 */
	private static function post_from_download_id( $gallery_id_raw ) {
		$parts = explode( '-', (string) $gallery_id_raw );
		$id    = absint( end( $parts ) );
		return $id ? get_post( $id ) : null;
	}

	/**
	 * Images for an album ZIP: each published gallery member's images, plus,
	 * for each published nested album, the first public gallery found in it
	 * (modula_get_ablum_images_recursive()'s existing behaviour).
	 *
	 * Public members only, whoever asks: the ZIP is cached for every visitor
	 * and stored under uploads by album name, so it must not carry what only
	 * the requester can read.
	 *
	 * @param int $album_id Album post ID.
	 * @return array<int, array> Image rows as stored in `modula-images`.
	 */
	private function get_album_zip_images( $album_id ) {
		$members = get_post_meta( $album_id, 'modula-album-galleries', true );
		if ( empty( $members ) || ! is_array( $members ) ) {
			return array();
		}

		$is_public = array( Members_Document::class, 'is_public_member' );
		$images    = array();
		foreach ( $members as $member ) {
			if ( ! is_array( $member ) || ! Members_Document::is_public_member( $member ) ) {
				continue;
			}

			// is_public_member() has checked that the post type matches the member's itemType.
			$member_images = 'modula-album' === get_post_type( $member['id'] )
				? modula_get_ablum_images_recursive( $member['id'], $is_public )
				: get_post_meta( $member['id'], 'modula-images', true );
			if ( ! empty( $member_images ) && is_array( $member_images ) ) {
				$images = array_merge( $images, $member_images );
			}
		}

		return $images;
	}

	/**
	 * @param \WP_Post $post Gallery or album that passed is_download_allowed().
	 * @return array{images_paths: array, upload_dir: array, custom_name: string}
	 */
	private function prepare_download_data( $post ) {
		$id           = $post->ID;
		$post_type    = $post->post_type;
		$settings     = self::download_settings( $post );
		$images       = array();
		$custom_name  = 'modula-gallery-' . $id;
		$upload_dir   = wp_upload_dir();
		$images_paths = array();

		if ( 'modula-gallery' === $post_type ) {
			$images = get_post_meta( $id, 'modula-images', true );

			if ( ! empty( $settings['custom_zip_name'] ) ) {
				$gallery_info = get_post( $id );
				if ( class_exists( 'Modula_Pro\Utils\Helper' ) ) {
					$processed = \Modula_Helper::modula_placeholders_value( $settings['custom_zip_name'], $gallery_info );
					if ( ! empty( $processed ) && ' ' !== $processed ) {
						$custom_name = str_replace( '/', '-', trim( sanitize_text_field( $processed ), '/' ) );
					}
				}
			}
		}

		if ( 'modula-album' === $post_type ) {
			$custom_name = 'modula-album-' . $id;
			$images      = $this->get_album_zip_images( $id );

			if ( ! empty( $settings['custom_zip_name_albums'] ) ) {
				$album_info = get_post( $id );
				if ( class_exists( 'Modula_Pro\Utils\Helper' ) ) {
					$processed = \Modula_Pro\Utils\Helper::modula_albums_placeholders_value( $settings['custom_zip_name_albums'], $album_info );
					if ( ! empty( $processed ) && ' ' !== $processed ) {
						$custom_name = str_replace( '/', '-', trim( sanitize_text_field( $processed ), '/' ) );
					}
				}
			}
		}

		if ( ! empty( $images ) && is_array( $images ) ) {
			$baseurl = preg_replace( '#^https?://#i', '', rtrim( $upload_dir['baseurl'], '/' ) );

			foreach ( $images as $image ) {
				$image_object = false;
				$image_url    = '';

				if ( isset( $settings['enable_download'] ) ) {
					if ( $settings['enable_download'] ) {
						if ( isset( $settings['download_image_sizes'] ) && 'full' !== $settings['download_image_sizes'] ) {
							$image_object = wp_get_attachment_image_src( $image['id'], $settings['download_image_sizes'] );
						} else {
							$image_url = wp_get_original_image_url( $image['id'] );
						}
					} else {
						$image_url = wp_get_original_image_url( $image['id'] );
					}
				}

				if ( isset( $settings['enable_download_albums'] ) ) {
					if ( $settings['enable_download_albums'] ) {
						if ( isset( $settings['download_image_sizes_albums'] ) && 'full' !== $settings['download_image_sizes_albums'] ) {
							$image_object = wp_get_attachment_image_src( $image['id'], $settings['download_image_sizes_albums'] );
						} else {
							$image_url = wp_get_original_image_url( $image['id'] );
						}
					} else {
						$image_url = wp_get_original_image_url( $image['id'] );
					}
				}

				if ( $image_object ) {
					$image_url = $image_object[0];
				}

				if ( empty( $image_url ) ) {
					continue;
				}

				$imageurl   = preg_replace( '#^https?://#i', '', rtrim( $image_url, '/' ) );
				$image_path = str_replace( $baseurl, $upload_dir['basedir'], $imageurl );
				$image_path = wp_normalize_path( $image_path );

				if ( $image_path ) {
					$images_paths[] = $image_path;
				}
			}
		}

		return array(
			'images_paths' => $images_paths,
			'custom_name'  => $custom_name,
			'upload_dir'   => $upload_dir,
		);
	}

	public function ajax_start_download() {
		if ( ! check_ajax_referer( 'modula_download_async', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Security check failed.' ) );
		}

		$gallery_id_raw = isset( $_POST['gallery_id'] ) ? sanitize_text_field( wp_unslash( $_POST['gallery_id'] ) ) : '';

		if ( empty( $gallery_id_raw ) ) {
			wp_send_json_error( array( 'message' => 'Missing gallery ID.' ) );
		}

		$post = self::post_from_download_id( $gallery_id_raw );
		if ( ! $post ) {
			wp_send_json_error( array( 'message' => 'Invalid gallery ID.' ) );
		}

		if ( ! self::is_downloadable_post( $post ) ) {
			wp_send_json_error( array( 'message' => 'Invalid post type.' ) );
		}

		if ( ! self::is_download_allowed( $post ) ) {
			wp_send_json_error( array( 'message' => 'Download not allowed.' ) );
		}

		$cache = get_transient( self::zip_cache_key( $post ) );
		if ( false !== $cache && ! empty( $cache['path'] ) && file_exists( $cache['path'] ) ) {
			if ( $cache['generated_at'] >= strtotime( $post->post_modified_gmt ) ) {
				$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
				wp_send_json_success( array( 'url' => $this->build_download_url( $gallery_id_raw, $nonce ) ) );
			}
		}

		$job_id = md5( uniqid( (string) wp_rand(), true ) );

		set_transient(
			'modula_zip_job_' . $job_id,
			array(
				'status'     => 'processing',
				'progress'   => 0,
				'total'      => 0,
				'gallery_id' => $gallery_id_raw,
			),
			HOUR_IN_SECONDS
		);

		wp_send_json_success( array( 'job_id' => $job_id ) );
	}

	public function ajax_process_chunk() {
		if ( ! check_ajax_referer( 'modula_download_async', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Security check failed.' ) );
		}

		$job_id = isset( $_POST['job_id'] ) ? sanitize_text_field( wp_unslash( $_POST['job_id'] ) ) : '';
		$offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;

		if ( empty( $job_id ) ) {
			wp_send_json_error( array( 'message' => 'Missing job ID.' ) );
		}

		$job = get_transient( 'modula_zip_job_' . $job_id );
		if ( false === $job ) {
			wp_send_json_error( array( 'message' => 'Job not found.' ) );
		}

		// Every chunk re-checks the gate: the post may change status or settings while the ZIP builds.
		$post = self::post_from_download_id( $job['gallery_id'] );
		if ( ! self::is_download_allowed( $post ) ) {
			wp_send_json_error( array( 'message' => 'Download not allowed.' ) );
		}

		@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( 0 === $offset ) {
			$data         = $this->prepare_download_data( $post );
			$images_paths = $data['images_paths'];
			$upload_dir   = $data['upload_dir'];
			$total        = count( $images_paths );

			if ( 0 === $total ) {
				wp_send_json_error( array( 'message' => 'No images found.' ) );
			}

			$cache_dir     = $upload_dir['basedir'] . '/modula-zips';
			$cache_dir_url = $upload_dir['baseurl'] . '/modula-zips';
			wp_mkdir_p( $cache_dir );

			$zip_path = $cache_dir . '/' . $data['custom_name'] . '.zip';
			$zip_url  = $cache_dir_url . '/' . $data['custom_name'] . '.zip';

			set_transient( 'modula_zip_paths_' . $job_id, $images_paths, HOUR_IN_SECONDS );

			$job['total']    = $total;
			$job['zip_path'] = $zip_path;
			$job['zip_url']  = $zip_url;

			if ( file_exists( $zip_path ) ) {
				wp_delete_file( $zip_path );
			}
		} else {
			$images_paths = get_transient( 'modula_zip_paths_' . $job_id );
			if ( false === $images_paths ) {
				wp_send_json_error( array( 'message' => 'Session expired. Please try again.' ) );
			}
		}

		$chunk = array_slice( $images_paths, $offset, self::ZIP_CHUNK_SIZE );

		$zip = new \ZipArchive();
		if ( ! $zip->open( $job['zip_path'], \ZIPARCHIVE::CREATE ) ) {
			wp_send_json_error( array( 'message' => 'Could not open ZIP archive.' ) );
		}

		foreach ( $chunk as $file ) {
			if ( file_exists( $file ) ) {
				$localname = basename( $file );
				$zip->addFile( $file, $localname );
				if ( method_exists( $zip, 'setCompressionName' ) ) {
					$zip->setCompressionName( $localname, \ZipArchive::CM_STORE );
				}
			}
		}

		$zip->close();

		$new_progress    = $offset + count( $chunk );
		$job['progress'] = $new_progress;

		$response = array(
			'progress' => $new_progress,
			'total'    => $job['total'],
			'status'   => 'processing',
		);

		if ( $new_progress >= $job['total'] ) {
			$job['status'] = 'done';
			set_transient(
				self::zip_cache_key( $post ),
				array(
					'path'         => $job['zip_path'],
					'url'          => $job['zip_url'],
					'generated_at' => time(),
				),
				30 * DAY_IN_SECONDS
			);
			delete_transient( 'modula_zip_paths_' . $job_id );
			modula_download_cleanup_old_zips( 7 );
			$nonce               = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			$response['status']  = 'done';
			$response['url']     = $this->build_download_url( $job['gallery_id'], $nonce );
		}

		set_transient( 'modula_zip_job_' . $job_id, $job, HOUR_IN_SECONDS );
		wp_send_json_success( $response );
	}

	private function build_download_url( $gallery_id_raw, $nonce ) {
		return add_query_arg(
			array(
				'action'     => 'modula_download_zip',
				'gallery_id' => $gallery_id_raw,
				'nonce'      => $nonce,
			),
			admin_url( 'admin-ajax.php' )
		);
	}

	public function ajax_download_zip() {
		if ( ! check_ajax_referer( 'modula_download_async', 'nonce', false ) ) {
			wp_die( esc_html__( 'Security check failed.', 'modula-pro' ), '', array( 'response' => 403 ) );
		}

		$gallery_id_raw = isset( $_GET['gallery_id'] ) ? sanitize_text_field( wp_unslash( $_GET['gallery_id'] ) ) : '';

		if ( empty( $gallery_id_raw ) ) {
			wp_die( esc_html__( 'Missing gallery ID.', 'modula-pro' ), '', array( 'response' => 400 ) );
		}

		// A cached ZIP is served only to a request the gate lets through.
		$post = self::post_from_download_id( $gallery_id_raw );
		if ( ! self::is_download_allowed( $post ) ) {
			wp_die( esc_html__( 'Download not allowed.', 'modula-pro' ), '', array( 'response' => 403 ) );
		}

		$cache = get_transient( self::zip_cache_key( $post ) );

		if ( false === $cache || empty( $cache['path'] ) ) {
			wp_die( esc_html__( 'Download expired, please try again.', 'modula-pro' ), '', array( 'response' => 404 ) );
		}

		$file_path = $cache['path'];

		// On some hosts the file can take a moment to become visible right after being written; give it a short grace period.
		$attempts = 0;
		while ( ! file_exists( $file_path ) && $attempts < 10 ) {
			usleep( 300000 );
			++$attempts;
		}

		if ( ! file_exists( $file_path ) ) {
			wp_die( esc_html__( 'Download expired, please try again.', 'modula-pro' ), '', array( 'response' => 404 ) );
		}

		modula_download_file( $file_path, $file_path );
	}

	/**
	 * Drop the cached ZIP of a saved gallery or album, and of every album that
	 * contains it, directly or nested: their ZIPs hold its images, and a status
	 * change can take it out of them.
	 *
	 * @param int $post_id Saved post ID.
	 * @return void
	 */
	public function invalidate_zip_cache( $post_id ) {
		$post_id = (int) $post_id;
		// One save writes several meta keys: walk the albums once per post and request.
		if ( isset( $this->invalidated_posts[ $post_id ] ) ) {
			return;
		}
		$this->invalidated_posts[ $post_id ] = true;

		$post_ids = array( $post_id );
		// Albums may be inactive while downloads stay on for galleries.
		if ( class_exists( Members_Document::class ) ) {
			$post_ids = array_merge( $post_ids, Members_Document::containing_album_ids( $post_id ) );
		}

		foreach ( $post_ids as $id ) {
			$post = get_post( $id );
			if ( ! self::is_downloadable_post( $post ) ) {
				continue;
			}
			self::delete_cached_zip( self::zip_cache_key( $post ) );
		}
	}

	/**
	 * Images, settings and member lists are saved as meta, often without a
	 * post save (the editors' REST routes): drop the ZIPs they feed.
	 *
	 * Callback for added_post_meta, updated_post_meta and deleted_post_meta.
	 *
	 * @param int|int[] $meta_id   Meta ID(s); unused.
	 * @param int       $object_id Post ID.
	 * @param string    $meta_key  Meta key.
	 * @return void
	 */
	public function invalidate_zip_cache_on_meta( $meta_id, $object_id, $meta_key ) {
		if ( ! in_array( $meta_key, self::ZIP_CONTENT_META_KEYS, true ) ) {
			return;
		}
		$this->invalidate_zip_cache( $object_id );
	}

	/**
	 * Delete a cached ZIP's file and transient.
	 *
	 * @param string $cache_key Transient key from zip_cache_key().
	 * @return void
	 */
	private static function delete_cached_zip( $cache_key ) {
		$cache = get_transient( $cache_key );
		if ( false !== $cache && ! empty( $cache['path'] ) && file_exists( $cache['path'] ) ) {
			wp_delete_file( $cache['path'] );
		}
		delete_transient( $cache_key );
	}

	/**
	 * Register settings for download
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function require_admin() {
		new Album_Settings();
		new Gallery_Settings();
	}
}
