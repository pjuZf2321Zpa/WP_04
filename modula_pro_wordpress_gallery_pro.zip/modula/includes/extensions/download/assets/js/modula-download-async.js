( function ( $ ) {
	'use strict';

	const ModulaDownloadAsync = {
		init() {
			$( document ).on(
				'click',
				'.modula-download-all, .modula-fancybox-button.download-all',
				this.onButtonClick.bind( this )
			);
		},

		onButtonClick( e ) {
			const $btn = $( e.currentTarget );

			if ( $btn.data( 'modula-downloading' ) ) {
				e.preventDefault();
				return;
			}

			const galleryId = this.extractGalleryId( $btn.attr( 'href' ) );

			if ( ! galleryId ) {
				return;
			}

			e.preventDefault();
			this.startDownload( $btn, galleryId );
		},

		extractGalleryId( href ) {
			if ( ! href ) {
				return null;
			}
			const match = href.match( /[?&]modula-id=([^&]+)/ );
			return match ? decodeURIComponent( match[ 1 ] ) : null;
		},

		startDownload( $btn, galleryId ) {
			$btn.data( 'modula-downloading', true );
			$btn.data( 'original-html', $btn.html() );
			$btn.text( modulaDownloadAsync.i18n.preparing );

			$.post( modulaDownloadAsync.ajaxurl, {
				action: 'modula_start_download',
				nonce: modulaDownloadAsync.nonce,
				gallery_id: galleryId,
			} )
				.done( ( response ) => {
					if ( ! response.success ) {
						this.resetButton( $btn );
						return;
					}
					if ( response.data.url ) {
						this.handleDone( $btn, response.data.url );
					} else {
						this.processChunks( $btn, response.data.job_id, 0 );
					}
				} )
				.fail( () => this.resetButton( $btn ) );
		},

		processChunks( $btn, jobId, offset ) {
			$.post( modulaDownloadAsync.ajaxurl, {
				action: 'modula_process_chunk',
				nonce: modulaDownloadAsync.nonce,
				job_id: jobId,
				offset,
			} )
				.done( ( response ) => {
					if ( ! response.success ) {
						this.resetButton( $btn );
						return;
					}

					const { status, progress, total, url } = response.data;

					if ( 'done' === status ) {
						this.handleDone( $btn, url );
					} else {
						const pct =
							total > 0
								? Math.round( ( progress / total ) * 100 )
								: 0;
						$btn.text( pct + '%' );
						this.processChunks( $btn, jobId, progress );
					}
				} )
				.fail( () => this.resetButton( $btn ) );
		},

		handleDone( $btn, url ) {
			$btn.text( modulaDownloadAsync.i18n.downloading );
			this.triggerDownload( url );
			setTimeout( () => this.resetButton( $btn ), 3000 );
		},

		triggerDownload( url ) {
			const link = document.createElement( 'a' );
			link.href = url;
			link.style.display = 'none';
			document.body.appendChild( link );
			link.click();
			setTimeout( () => document.body.removeChild( link ), 100 );
		},

		resetButton( $btn ) {
			$btn.html( $btn.data( 'original-html' ) || '' );
			$btn.removeData( 'modula-downloading original-html' );
		},
	};

	$( document ).ready( () => {
		if ( typeof modulaDownloadAsync !== 'undefined' ) {
			ModulaDownloadAsync.init();
		}
	} );
} )( jQuery );
