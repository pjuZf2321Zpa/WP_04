<?php

use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;

/**
 * Helper function to zip gallery
 *
 * @param array  $files
 * @param string $location
 *
 * @return bool
 * @since 1.0.0
 *
 */
function modula_download_zip( $files, $location ) {
	if ( ! extension_loaded( 'zip' ) ) {
		return false;
	}

	if ( file_exists( $location ) ) {
		wp_delete_file( $location );
	}

	// If empty or not array we return false
	if ( empty( $files ) || ! is_array( $files ) ) {
		return false;
	}

	$zip = new \ZipArchive();
	if ( ! $zip->open( $location, \ZIPARCHIVE::CREATE ) ) {
		return false;
	}

	foreach ( $files as $file ) {
		if ( file_exists( $file ) ) {
			$zip->addFile( $file, basename( $file ) );
		}
	}

	$zip->close();

	return true;
}

/**
 * Helper function to download file
 *
 * @param string $file_path
 * @param string $location
 *
 * @return void
 * @since 1.0.0
 *
 */
function modula_download_file( $file_path, $location ) {

	session_write_close();

	if ( function_exists( 'apache_setenv' ) ) {
		@apache_setenv( 'no-gzip', 1 );
	}
	@ini_set( 'zlib.output_compression', 'Off' );

	nocache_headers();
	header( 'Pragma: no-cache' );
	header( 'Expires: 0' );
	header( 'Robots: none' );
	header( 'Content-Type: application/zip' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-Disposition: attachment; filename="' . basename( $location ) . '"' );
	header( 'Content-Transfer-Encoding: binary' );
	header( 'Content-Length: ' . filesize( $file_path ) );

	$absolute_file_path = $file_path;

	if ( stristr( getenv( 'SERVER_SOFTWARE' ), 'lighttpd' ) ) {
		header( "X-LIGHTTPD-send-file: $absolute_file_path" );
		exit();
	} elseif ( stristr( getenv( 'SERVER_SOFTWARE' ), 'nginx' ) || stristr( getenv( 'SERVER_SOFTWARE' ), 'cherokee' ) ) {
		if ( ! isset( $_SERVER['DOCUMENT_ROOT'] ) ) {
			modula_download_readfile_chunked( $absolute_file_path );
			exit();
		}

		$doc_root = realpath( sanitize_text_field( wp_unslash( $_SERVER['DOCUMENT_ROOT'] ) ) );
		if ( $doc_root && strpos( $absolute_file_path, $doc_root ) === 0 ) {
			$relative_file_path = str_replace( $doc_root, '', $absolute_file_path );
			header( "X-Accel-Redirect: /$relative_file_path" );
			exit();
		}
	}

	modula_download_readfile_chunked( $absolute_file_path );
	exit();
}

/**
 * Helper Function to read file in chuncks
 *
 * @param string $file
 * @param bool   $retbytes
 *
 * @return bool
 * @since 1.0.0
 */
function modula_download_readfile_chunked( $file, $retbytes = true ) {

	$chunksize = 1024 * 1024;
	$buffer    = '';
	$cnt       = 0;
	$handle    = fopen( $file, 'r' );

	$size = filesize( $file );

	if ( $size ) {
		header( 'Content-Length: ' . $size );
	}

	if ( false === $handle ) {
		return false;
	}

	while ( ! feof( $handle ) ) {
		$buffer = fread( $handle, $chunksize );
		echo $buffer;

		if ( $retbytes ) {
			$cnt += strlen( $buffer );
		}
	}

	$status = fclose( $handle );

	if ( $retbytes && $status ) {
		return $cnt;
	}

	return $status;
}

/**
 * Helper function to get request url
 *
 * @param string $id
 *
 * @return string $url
 * @since 1.0.0
 */
function modula_download_req_url( $id ) {
	$first_part  = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : false;
	$second_part = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : false;

	$url = add_query_arg(
		array(
			'modula-id' => $id,
		),
		( is_ssl() ? 'https' : 'http' ) . '://' . $first_part . $second_part
	);

	return $url;
}

/**
 * Function to echo the download icon + filter to customize
 *
 * @return string $svg
 *
 * @since 1.0.0
 */
function modula_download_all_svg() {

	return apply_filters(
		'modula_download_all_icon',
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
	<path d="M18.62 17.09V19H5.38v-1.91zm-2.97-6.96L17 11.45l-5 4.87-5-4.87 1.36-1.32 2.68 2.64V5h1.92v7.77z"></path> </svg>'
	);
}

/**
 * Cleanup old zip files from uploads directory
 *
 * @param int $days_old Number of days after which files should be deleted (default: 7)
 * @return int Number of files deleted
 * @since 1.0.0
 */
function modula_download_cleanup_old_zips( $days_old = 7 ) {
	$upload_dir    = wp_upload_dir();
	$base_dir      = $upload_dir['basedir'];
	$cutoff_time   = time() - ( $days_old * DAY_IN_SECONDS );
	$deleted_count = 0;

	// Build search directories: current month + up to 12 months back.
	$search_dirs = array();
	for ( $i = 0; $i <= 12; $i++ ) {
		$timestamp = strtotime( "-{$i} months" );
		$dir       = $base_dir . '/' . gmdate( 'Y', $timestamp ) . '/' . gmdate( 'm', $timestamp );
		if ( is_dir( $dir ) ) {
			$search_dirs[] = $dir;
		}
	}
	$search_dirs = array_unique( $search_dirs );

	// Collect candidate filenames: glob patterns for default names + computed names for custom zip names.
	$glob_patterns      = array(
		'modula-gallery-*.zip',
		'modula-album-*.zip',
		'modula-download*.zip',
	);
	$specific_filenames = modula_download_get_all_possible_zip_filenames();

	foreach ( $search_dirs as $dir ) {
		// Custom-named zips (e.g. "My Gallery.zip" from custom_zip_name setting).
		foreach ( $specific_filenames as $filename ) {
			$file_path = $dir . '/' . $filename;
			if ( is_file( $file_path ) && filemtime( $file_path ) < $cutoff_time ) {
				if ( wp_delete_file( $file_path ) ) {
					++$deleted_count;
				}
			}
		}

		// Standard Modula-named zips via glob.
		foreach ( $glob_patterns as $pattern ) {
			$files = glob( $dir . '/' . $pattern );
			if ( ! $files ) {
				continue;
			}
			foreach ( $files as $file ) {
				if ( is_file( $file ) && filemtime( $file ) < $cutoff_time ) {
					if ( wp_delete_file( $file ) ) {
						++$deleted_count;
					}
				}
			}
		}
	}

	if ( $deleted_count > 0 ) {
		error_log( sprintf( 'Modula Download: Cleaned up %d old zip files older than %d days', $deleted_count, $days_old ) );
	}

	return $deleted_count;
}

/**
 * Get all possible zip filenames by processing gallery/album settings
 *
 * @return array Array of possible zip filenames
 * @since 1.0.0
 */
function modula_download_get_all_possible_zip_filenames() {
	$cached_filenames = get_transient( 'modula_download_possible_filenames' );
	if ( false !== $cached_filenames ) {
		return $cached_filenames;
	}
	$possible_filenames = array();

	$galleries = get_posts(
		array(
			'post_type'      => 'modula-gallery',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		)
	);

	foreach ( $galleries as $gallery ) {
		$settings = get_post_meta( $gallery->ID, 'modula-settings', true );
		$settings = wp_parse_args( $settings, \Modula_CPT_Fields_Helper::get_defaults() );

		$filename = modula_download_generate_possible_filename( $gallery, $settings, 'gallery' );
		if ( $filename ) {
			$possible_filenames[] = $filename;
		}
	}

	$albums = get_posts(
		array(
			'post_type'      => 'modula-album',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		)
	);

	foreach ( $albums as $album ) {
		$settings = get_post_meta( $album->ID, 'modula-album-settings', true );
		$settings = wp_parse_args( $settings, Fields_Helper::get_defaults() );

		$filename = modula_download_generate_possible_filename( $album, $settings, 'album' );
		if ( $filename ) {
			$possible_filenames[] = $filename;
		}
	}

	set_transient(
		'modula_download_possible_filenames',
		$possible_filenames,
		24 * 7 * HOUR_IN_SECONDS // a week cache
	);

	return $possible_filenames;
}

/**
 * Generate possible zip filename for a gallery/album based on its settings
 *
 * @param WP_Post $post The gallery/album post object
 * @param array   $settings The gallery/album settings
 * @param string  $type Either 'gallery' or 'album'
 * @return string|false The possible filename or false if not applicable
 * @since 1.0.0
 */
function modula_download_generate_possible_filename( $post, $settings, $type ) {
	$custom_name = '';

	if ( 'gallery' === $type ) {
		$custom_name = 'modula-gallery-' . $post->ID;
		if ( ! empty( $settings['custom_zip_name'] ) ) {
			if ( class_exists( 'Modula_Pro\Utils\Helper' ) ) {
				$processed_name = \Modula_Helper::modula_placeholders_value( $settings['custom_zip_name'], $post );
				if ( ! empty( $processed_name ) && ' ' !== $processed_name ) {
					$custom_name = str_replace( '/', '-', trim( sanitize_text_field( $processed_name ), '/' ) );
				}
			}
		}
	} elseif ( 'album' === $type ) {
		$custom_name = 'modula-album-' . $post->ID;
		if ( ! empty( $settings['custom_zip_name_albums'] ) ) {
			if ( class_exists( 'Modula_Pro\Utils\Helper' ) ) {
				$processed_name = \Modula_Pro\Utils\Helper::modula_albums_placeholders_value( $settings['custom_zip_name_albums'], $post );
				if ( ! empty( $processed_name ) && ' ' !== $processed_name ) {
					$custom_name = str_replace( '/', '-', trim( sanitize_text_field( $processed_name ), '/' ) );
				}
			}
		}
	}

	return $custom_name ? $custom_name . '.zip' : false;
}
