<?php
namespace Modula_Pro\Extensions\Download;

class Enqueue {
	private $extension_url = 'includes/extensions/download';
	public function __construct() {
		add_action( 'modula_extra_scripts', array( $this, 'download_scripts' ) );
		add_filter( 'modula_link_extra_scripts', array( $this, 'download_link_scripts' ) );
		add_action( 'modula_album_extra_scripts', array( $this, 'download_albums_scripts' ) );
		add_action( 'modula_album_visitor_extra_scripts', array( $this, 'download_albums_scripts' ) );

		add_filter( 'modula_shortcode_css', array( $this, 'download_gallery_css' ), 10, 3 );
		add_filter( 'modula_album_shortcode_css', array( $this, 'download_album_css' ), 10, 3 );
	}

	/**
	 * Enqueue necessary download scripts
	 *
	 * @param array $settings
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_scripts( $settings ) {
		if ( ! isset( $settings['enable_download'] ) || 1 !== (int) $settings['enable_download'] ) {
			return;
		}

		wp_enqueue_style( 'modula-download-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-download-front.css', array(), \MODULA_PRO_VERSION );
		$this->enqueue_async_script();
	}

	/**
	 * Enqueue necessary link scripts
	 *
	 * @param array $settings
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_link_scripts( $settings ) {
		if ( ! isset( $settings['enable_download'] ) || 1 !== (int) $settings['enable_download'] ) {
			return;
		}

		wp_enqueue_style( 'modula-download-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-download-front.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Enqueue necessary download albums scripts
	 *
	 * @param array $settings
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_albums_scripts( $settings ) {
		if ( ! isset( $settings['enable_download_albums'] ) || 1 !== (int) $settings['enable_download_albums'] ) {
			return;
		}

		wp_enqueue_style( 'modula-download-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-download-front.css', array(), \MODULA_PRO_VERSION );
		$this->enqueue_async_script();
	}

	/**
	 * Enqueue async download JS and pass config to frontend.
	 *
	 * @return void
	 */
	private function enqueue_async_script() {
		wp_enqueue_script(
			'modula-download-async',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-download-async.js',
			array( 'jquery' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_localize_script(
			'modula-download-async',
			'modulaDownloadAsync',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'modula_download_async' ),
				'i18n'    => array(
					'preparing'   => esc_html__( 'Preparing...', 'modula-pro' ),
					'downloading' => esc_html__( 'Downloading...', 'modula-pro' ),
				),
			)
		);
	}

	/**
	 * Generate Gallery CSS for position of the dl button
	 *
	 * @param string $css
	 * @param string $gall_id
	 * @param array  $settings
	 *
	 * @return string $css
	 * @since 1.0.0
	 */
	public function download_gallery_css( $css, $gall_id, $settings ) {
		if ( isset( $settings['enableSocial'] ) && 1 === (int) $settings['enableSocial'] ) {
			if ( 1 === $settings['download_gallery_button'] ) {
				if ( isset( $settings['socialIconColor'] ) && '' !== $settings['socialIconColor'] ) {
					$css .= "#{$gall_id} .modula-item .jtg-social a.modula-download-button,#{$gall_id} .modula-item .no-socials a.modula-download-button { color: " . \Modula_Helper::sanitize_rgba_colour( $settings['socialIconColor'] ) . ' }';
				} else {
					$css .= "#{$gall_id}  .modula-item .jtg-social a.modula-download-button,#{$gall_id} .modula-item .no-socials a.modula-download-button { color: " . \Modula_Helper::sanitize_rgba_colour( $settings['socialIconColor'] ) . ' }';
				}
				if ( 'under' === $settings['effect'] && 0 === $settings['enableSocial'] ) {
					$css .= "#{$gall_id} .no-socials { position: absolute; width: " . absint( $settings['socialIconSize'] ) . 'px; height: ' . absint( $settings['socialIconSize'] ) . 'px;margin-left: 25px; bottom: 25px; z-index:100 }';
				}
			}
		}

		if ( 1 === (int) $settings['download_all_gallery_button'] || 1 === (int) $settings['download_all_gallery_button_icon'] ) {
			if ( isset( $settings['download_all_hposition'] ) && 'left' !== $settings['download_all_hposition'] ) {
				if ( 'center' === $settings['download_all_hposition'] ) {
					$css .= "#{$gall_id} .modula-download-all-button { text-align: center }";
				} elseif ( 'right' === $settings['download_all_hposition'] ) {
					$css .= "#{$gall_id} .modula-download-all-button { text-align: right }";
				}
			}

			if ( isset( $settings['download_all_color'] ) && '' !== $settings['download_all_color'] ) {
				$css .= "#{$gall_id} .modula-download-all-button a{";
				$css .= 'color:' . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_color'] ) . ';';
				$css .= '}';
			}

			// Targets the rendered link (a.modula-download-all.wp-block-button__link); it has no `.button` class.
			if ( isset( $settings['download_all_background_color'] ) && '' !== $settings['download_all_background_color'] ) {
				$css .= "#{$gall_id} .modula-download-all-button .modula-download-all{";
				$css .= 'background-color:' . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_background_color'] ) . ';';
				$css .= '}';
			}

			if ( isset( $settings['download_all_gallery_icon_color'] ) && '' !== $settings['download_all_gallery_icon_color'] ) {
				$css .= "#{$gall_id} .modula-download-all-button svg path { fill : " . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_gallery_icon_color'] ) . ' }';
			}
		}

		return $css;
	}

	/**
	 * Generate CSS for Albums
	 *
	 * @param string $css
	 * @param string $gall_id
	 * @param array  $settings
	 *
	 * @return string $css
	 * @since  1.0.0
	 */
	public function download_album_css( $css, $gall_id, $settings ) {
		if ( isset( $settings['enable_download_albums'] ) && 1 === (int) $settings['enable_download_albums'] ) {
			if ( 1 === (int) $settings['download_gallery_button_albums'] ) {
				if ( 'top_left' === $settings['download_gallery_button_position_albums'] ) {
					$css .= "#{$gall_id} .modula-item a.modula-download-button { top:25px; left:25px; bottom:auto;right:auto;}";
				}
				if ( 'top_right' === $settings['download_gallery_button_position_albums'] ) {
					$css .= "#{$gall_id} .modula-item a.modula-download-button { top:25px; right:25px;bottom:auto; }";
				}
				if ( 'bottom_left' === $settings['download_gallery_button_position_albums'] ) {
					$css .= "#{$gall_id} .modula-item a.modula-download-button { bottom:25pxpx; left:25px;right:auto;  }";
				}
				if ( 'bottom_right' === $settings['download_gallery_button_position_albums'] ) {
					$css .= "#{$gall_id} .modula-item a.modula-download-button { bottom:25px; right:25px;  }";
				}

				if ( isset( $settings['download_gallery_button_color_albums'] ) && '' !== $settings['download_gallery_button_color_albums'] ) {
					$css .= "#{$gall_id}  .modula-item a.modula-download-button { color: " . \Modula_Helper::sanitize_rgba_colour( $settings['download_gallery_button_color_albums'] ) . ' }';
				}
			}

			if ( 1 === (int) $settings['download_all_gallery_button_albums'] || 1 === (int) $settings['download_all_gallery_button_icon_albums'] ) {
				if ( isset( $settings['download_all_hposition_albums'] ) && 'left' !== $settings['download_all_hposition_albums'] ) {
					if ( 'center' === $settings['download_all_hposition_albums'] ) {
						$css .= "#{$gall_id} .modula-download-all-button { text-align: center }";
					} elseif ( 'right' === $settings['download_all_hposition_albums'] ) {
						$css .= "#{$gall_id} .modula-download-all-button { text-align: right }";
					}
				}

				// Download all text and background colors; empty adds nothing.
				if ( isset( $settings['download_all_color_albums'] ) && '' !== $settings['download_all_color_albums'] ) {
					$css .= "#{$gall_id} .modula-download-all-button a{";
					$css .= 'color:' . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_color_albums'] ) . ';';
					$css .= '}';
				}

				// Targets the rendered link (a.modula-download-all.wp-block-button__link); it has no `.button` class.
				if ( isset( $settings['download_all_background_color_albums'] ) && '' !== $settings['download_all_background_color_albums'] ) {
					$css .= "#{$gall_id} .modula-download-all-button .modula-download-all{";
					$css .= 'background-color:' . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_background_color_albums'] ) . ';';
					$css .= '}';
				}

				if ( isset( $settings['download_all_gallery_icon_color_albums'] ) && '' !== $settings['download_all_gallery_icon_color_albums'] ) {
					$css .= "#{$gall_id} .modula-download-all-button svg path { fill : " . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_gallery_icon_color_albums'] ) . ' }';
				} else {
					$css .= "#{$gall_id} .modula-download-all-button svg path { fill : black }";
				}
			}
		}
		return $css;
	}
}
