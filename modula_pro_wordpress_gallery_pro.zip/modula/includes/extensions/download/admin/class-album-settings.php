<?php
namespace Modula_Pro\Extensions\Download\Admin;

use Modula_Pro\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Holds the admin object regarding settings
 */
class Album_Settings {

	/**
	 * Holds the admin class object for albums
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Constructor for Album_Settings class
	 *
	 * @return void
	 * @since 1.0.0
	 *
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'set_admin_requirements' ), 50 );
		add_action( 'modula_album_scripts_after_wp_modula', array( $this, 'album_admin_scripts' ) );
		add_action( 'modula_defaults_album_scripts_after_wp_modula', array( $this, 'album_admin_scripts' ) );
	}

	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.0.4
	 */
	public function set_admin_requirements() {
		add_filter( 'modula_album_fields', array( $this, 'download_field' ) );
		add_filter( 'modula_album_tabs', array( $this, 'download_tab' ) );
	}


	/**
	 * Returns the singleton instance of the class
	 *
	 * @return object Modula Download Album Settings object
	 * @since 1.0.0
	 *
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Album_Settings ) ) {
			self::$instance = new Album_Settings();
		}

		return self::$instance;
	}

	/**
	 * Enqueue admin conditions
	 *
	 * @since 1.0.0
	 */
	public function album_admin_scripts() {
		modula_pro_ensure_condition_scripts_registered();
		wp_enqueue_script( 'modula-download-album-conditions', \MODULA_PRO_URL . 'includes/extensions/download/assets/js/modula-download-album-conditions.js', array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-download-admin-css', \MODULA_PRO_URL . 'includes/extensions/download/assets/css/modula-download-admin.css', array(), \MODULA_PRO_VERSION );
	}


	/**
	 * Download Tab for Albums
	 *
	 * @param array $tabs
	 *
	 * @return array $tabs
	 * @since 1.0.0
	 *
	 */
	public function download_tab( $tabs ) {
		$tabs['download'] = array(
			'label'       => esc_html__( 'Download', 'modula-pro' ),
			'title'       => esc_html__( 'Download', 'modula-pro' ),
			'description' => esc_html__( 'Downloading your entire album or just one gallery, is now one click away', 'modula-pro' ),
			'docs_url'    => 'https://wp-modula.com/kb/modula-download/',
			'icon'        => 'dashicons dashicons-download',
			'priority'    => 75,
		);
		return $tabs;
	}

	/**
	 * Download Tab for Albums
	 *
	 * @param array $fields
	 *
	 * @return array $fields
	 * @since 1.0.0
	 *
	 */
	public function download_field( $fields ) {
		$fields['download'] = array(
			'enable_download_albums'                  => array(
				'name'      => esc_html__( 'Enable Download', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 1,
				'children'  => array( 'download_image_sizes_albums', 'download_gallery_button_albums', 'download_all_lightbox_button_albums', 'download_all_gallery_button_albums', 'custom_zip_name_albums' ),
				'data_type' => 'bool',
			),
			'download_image_sizes_albums'             => array(
				'name'      => esc_html__( 'Download Image size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'thumbnail' => esc_html__( 'Thumbnail', 'modula-pro' ),
					'medium'    => esc_html__( 'Medium', 'modula-pro' ),
					'large'     => esc_html__( 'Large', 'modula-pro' ),
					'full'      => esc_html__( 'Full', 'modula-pro' ),
				),
				'default'   => 'thumbnail',
				'priority'  => 3,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'download_gallery_button_albums'          => array(
				'name'      => esc_html__( 'Download Button', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 5,
				'is_child'  => true,
				'children'  => array( 'download_gallery_button_color_albums', 'download_gallery_button_position_albums' ),
				'parent'    => 'enable_download_albums',
				'data_type' => 'bool',
			),
			'download_gallery_button_color_albums'    => array(
				'name'      => esc_html__( 'Download Button Color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '#ffffff',
				'priority'  => 7,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_gallery_button_position_albums' => array(
				'name'      => esc_html__( 'Download Gallery Button Position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'top_left'     => esc_html__( 'Top Left', 'modula-pro' ),
					'top_right'    => esc_html__( 'Top Right', 'modula-pro' ),
					'bottom_left'  => esc_html__( 'Bottom Left', 'modula-pro' ),
					'bottom_right' => esc_html__( 'Bottom Right', 'modula-pro' ),
				),
				'default'   => 'top_left',
				'priority'  => 15,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_all_lightbox_button_albums'     => array(
				'name'      => esc_html__( 'Lightbox Download All Button', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 20,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'download_all_gallery_button_albums'      => array(
				'name'      => esc_html__( 'Download All Button', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 25,
				'is_child'  => true,
				'children'  => array( 'download_all_hposition_albums', 'download_all_position_albums', 'download_all_label_albums', 'download_all_gallery_button_icon_albums', 'download_all_gallery_icon_color_albums' ),
				'parent'    => 'enable_download_albums',
				'data_type' => 'bool',
			),
			'download_all_hposition_albums'           => array(
				'name'      => esc_html__( 'Download all button horizontal position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'left'   => esc_html__( 'Left', 'modula-pro' ),
					'right'  => esc_html__( 'Right', 'modula-pro' ),
					'center' => esc_html__( 'Center', 'modula-pro' ),
				),
				'default'   => 'left',
				'priority'  => 28,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_all_position_albums'            => array(
				'name'      => esc_html__( 'Download all button position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'above_gallery'       => esc_html__( 'Above Album', 'modula-pro' ),
					'below_gallery'       => esc_html__( 'Below Album', 'modula-pro' ),
					'above_below_gallery' => esc_html__( 'Above & Below Album', 'modula-pro' ),
				),
				'default'   => 'above_gallery',
				'priority'  => 35,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_all_label_albums'               => array(
				'name'      => esc_html__( 'Download All Button Label', 'modula-pro' ),
				'type'      => 'text',
				'default'   => esc_html__( 'Download All Images', 'modula-pro' ),
				'priority'  => 40,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_all_gallery_button_icon_albums' => array(
				'name'      => esc_html__( 'Download all Icon', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 46,
				'is_child'  => 'two',
				'data_type' => 'bool',
			),
			'download_all_gallery_icon_color_albums'  => array(
				'name'      => esc_html__( 'Download all Icon Color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '',
				'priority'  => 47,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'custom_zip_name_albums'                  => array(
				'name'      => esc_html__( 'Custom Zip Name', 'modula-pro' ),
				'type'      => 'placeholder',
				'values'    => Helper::modula_albums_placeholders(),
				'default'   => '%%album_title%%',
				'priority'  => 48,
				'afterrow'  => esc_html__( 'Each placeholder will automatically have space between them or you can manually insert a separator.', 'modula-pro' ),
				'is_child'  => true,
				'data_type' => 'text',
			),
		);
		if ( ! extension_loaded( 'zip' ) ) {
			$fields['download']['helper-message'] = array(
				'name'     => ' ',
				'type'     => 'content',
				'content'  => esc_html__( 'In order for the "Download All" functionality to work you need to enable the ZIP PHP extension. Ask your hosting provider to enable it.', 'modula-pro' ),
				'priority' => 0,
			);
		}

		return $fields;
	}
}
