<?php
namespace Modula_Pro\Extensions\Download\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Gallery_Settings {

	/**
	 * Holds the admin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Constructor for Modula_Download_Settings class
	 *
	 * @return void
	 * @since 1.0.0
	 *
	 */
	public function __construct() {
		//Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'download_field' ) );

		//Filter Modula Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'download_tab' ), 99 );

		add_action( 'modula_scripts_after_wp_modula', array( $this, 'gallery_admin_scripts' ) );

		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'gallery_admin_scripts' ) );
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @return object Modula Download Settings object
	 * @since 1.0.0
	 *
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Gallery_Settings ) ) {
			self::$instance = new Gallery_Settings();
		}

		return self::$instance;
	}

	/**
	 * Enqueue admin conditions
	 *
	 * @since 1.0.0
	 */
	public function gallery_admin_scripts() {
		wp_enqueue_script( 'modula-download-conditions', \MODULA_PRO_URL . 'includes/extensions/download/assets/js/modula-download-conditions.js', array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-download-admin-css', \MODULA_PRO_URL . 'includes/extensions/download/assets/css/modula-download-admin.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Download Tab
	 *
	 * @param $tabs
	 *
	 * @return array $tabs
	 * @since 1.0.0
	 */
	public function download_tab( $tabs ) {
		$tabs['download'] = array(
			'label'       => esc_html__( 'Download', 'modula-pro' ),
			'title'       => esc_html__( 'Download Settings', 'modula-pro' ),
			'description' => esc_html__( 'The settings bellow adjust the download options .', 'modula-pro' ),
			'docs_url'    => 'https://wp-modula.com/kb/modula-download/',
			'icon'        => 'dashicons dashicons-download',
			'priority'    => 85,
		);

		if ( isset( $tabs['download']['badge'] ) ) {
			unset( $tabs['download']['badge'] );
		}

		return $tabs;
	}

	/**
	 * Add download fields in settings
	 *
	 * @param  array  $fields
	 *
	 * @return array $fields
	 * @since 1.0.0
	 *
	 */
	public function download_field( $fields ) {
		$fields['download'] = array(
			'enable_download'                  => array(
				'name'      => esc_html__( 'Download', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 1,
				'children'  => array( 'download_image_sizes', 'download_all_gallery_button', 'custom_zip_name' ),
				'data_type' => 'bool',
			),
			'download_image_sizes'             => array(
				'name'      => esc_html__( 'Image size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'thumbnail' => esc_html__( 'Thumbnail', 'modula-pro' ),
					'medium'    => esc_html__( 'Medium', 'modula-pro' ),
					'large'     => esc_html__( 'Large', 'modula-pro' ),
					'full'      => esc_html__( 'Full', 'modula-pro' ),
				),
				'default'   => 'thumbnail',
				'priority'  => 10,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'download_all_gallery_button'      => array(
				'name'      => esc_html__( 'Download all', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 20,
				'is_child'  => true,
				'children'  => array( 'download_all_color', 'download_all_hposition', 'download_all_position', 'download_all_label', 'download_all_gallery_button_icon', 'download_all_gallery_icon_color', 'custom_zip_name', 'download_all_background_color' ),
				'parent'    => 'enable_download',
				'data_type' => 'bool',
			),
			'download_all_color'               => array(
				'name'      => esc_html__( 'Button text color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '',
				'is_child'  => 'two',
				'priority'  => 30,
				'data_type' => 'text',
			),
			'download_all_background_color'    => array(
				'name'      => esc_html__( 'Button background color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '',
				'is_child'  => 'two',
				'priority'  => 40,
				'data_type' => 'text',
			),
			'download_all_gallery_button_icon' => array(
				'name'      => esc_html__( 'Show icon next to button label', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 50,
				'is_child'  => 'two',
				'children'  => array( 'download_all_gallery_icon_color' ),
				'parent'    => 'enable_download',
				'data_type' => 'bool',
			),
			'download_all_gallery_icon_color'  => array(
				'name'      => esc_html__( 'Icon Color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '',
				'priority'  => 60,
				'is_child'  => 'three',
				'data_type' => 'text',
			),
			'download_all_hposition'           => array(
				'name'      => esc_html__( 'Horizontal position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'left'   => esc_html__( 'Left', 'modula-pro' ),
					'right'  => esc_html__( 'Right', 'modula-pro' ),
					'center' => esc_html__( 'Center', 'modula-pro' ),
				),
				'default'   => 'center',
				'priority'  => 80,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_all_position'            => array(
				'name'      => esc_html__( 'Position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'above_gallery'       => esc_html__( 'Above gallery', 'modula-pro' ),
					'below_gallery'       => esc_html__( 'Below gallery', 'modula-pro' ),
					'above_below_gallery' => esc_html__( 'Above & below gallery', 'modula-pro' ),
				),
				'default'   => 'below_gallery',
				'priority'  => 90,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'download_all_label'               => array(
				'name'      => esc_html__( 'Button label', 'modula-pro' ),
				'type'      => 'text',
				'default'   => esc_html__( 'Download All Images', 'modula-pro' ),
				'priority'  => 100,
				'is_child'  => 'two',
				'data_type' => 'text',
			),
			'custom_zip_name'                  => array(
				'name'      => esc_html__( 'Custom zip name', 'modula-pro' ),
				'type'      => 'placeholder',
				'values'    => \Modula_Helper::modula_gallery_placeholders(),
				'default'   => '%%gallery_title%%',
				'priority'  => 110,
				'afterrow'  => esc_html__( 'Each placeholder will automatically have space between them or you can manually insert a separator.', 'modula-pro' ),
				'is_child'  => 'two',
				'data_type' => 'text',
			),

		);

		if ( ! extension_loaded( 'zip' ) ) {
			$fields['download']['helper-message'] = array(
				'name'     => ' ',
				'type'     => 'content',
				'content'  => esc_html__( 'In order for the "Download All" functionality to work you need to enable the ZIP PHP extension. Ask your hosting provider to enable it.', 'modula-pro' ),
				'priority' => 111,
			);
		}

		// Add download button to socials
		$fields['social']['download_gallery_button'] = array(
			'name'      => esc_html__( 'Download Button', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 1,
			'priority'  => 45,
			'is_child'  => true,
			'data_type' => 'bool',
		);

		if ( isset( $fields['social']['enableSocial']['children'] ) ) {
			$fields['social']['enableSocial']['children'] = array_merge( $fields['social']['enableSocial']['children'], array( 'download_gallery_button' ) );
		}

		// Add download all button to lightbox
		$fields['lightboxes']['download_all_lightbox_button'] = array(
			'name'      => esc_html__( 'Download All Button', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 1,
			'priority'  => 34,
			'data_type' => 'bool',
			'is_child'  => true,
		);
		if ( isset( $fields['lightboxes']['lightbox_toolbar']['children'] ) ) {
			$fields['lightboxes']['lightbox_toolbar']['children'][] = 'download_all_lightbox_button';
		}

		return $fields;
	}
}
