<?php
namespace Modula_Pro\Extensions\Download;

use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Albums\V2\Album_Sections;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {
	public function __construct() {
		add_shortcode( 'modula-download', array( $this, 'download_shortcode' ) );

		if ( defined( 'MODULA_LITE_VERSION' ) && version_compare( \MODULA_LITE_VERSION, '2.13.9', '>=' ) ) {
			add_filter( 'modula_admin_aditional_shortcodes_dropdown', array( $this, 'output_download_shortcode' ), 10, 2 );
		} else {
			add_action( 'modula_admin_after_shortcode_metabox', array( $this, 'backwards_output_download_shortcode' ) );
		}

		add_action( 'modula_albums_admin_after_shortcode_metabox', array( $this, 'output_download_album_shortcode' ), 30 );
		add_action( 'manage_modula-gallery_posts_custom_column', array( $this, 'download_gallery_column' ), 30, 2 );
		add_action( 'manage_modula-album_posts_custom_column', array( $this, 'download_album_column' ), 20, 2 );
		add_filter( 'modula_album_shortcode_item_data', array( $this, 'download_albums_item_data_socials' ), 10, 5 );

		add_action( 'modula_extra_socials', array( $this, 'download_gallery_button' ), 10 );
		add_action( 'modula_item_after_image', array( $this, 'download_no_socials' ), 10 );
		add_filter( 'modula_slider_item_after_image', array( $this, 'slider_download_button' ), 15, 1 );
		add_filter( 'modula_shortcode_item_data', array( $this, 'modula_download_item_data' ), 135, 3 );
		if ( extension_loaded( 'zip' ) ) {
			add_action( 'modula_shortcode_before_items', array( $this, 'download_all_gallery_button_above' ), 10, 4 );
			add_action( 'modula_shortcode_after_items', array( $this, 'download_all_gallery_button_below' ), 20, 4 );
			add_action( 'modula_album_shortcode_before_items', array( $this, 'download_all_album_button_above' ), 10, 3 );
			add_action( 'modula_album_shortcode_after_items', array( $this, 'download_all_album_button_below' ), 10, 3 );
			add_filter( 'modula_fancybox_options', array( $this, 'download_fancybox_button' ), 15, 2 );
			add_filter( 'modula_album_template_data', array( $this, 'download_album_fancybox_button' ), 30 );
			add_action( 'modula_album_item_before_link', array( $this, 'download_album_button' ) );
		}
	}

	/**
	 * Display the download button on hover
	 *
	 * @param object $data
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_gallery_button( $data ) {
		if ( isset( $data->download['download_button'] ) && $data->download['download_button'] ) {
			?>
			<a href="<?php echo esc_url( $data->download['image_url'] ); ?>" target="_self" download
				class="modula-download-button" title="Download image">
				<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="download"
					class="svg-inline--fa fa-download fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 512 512">
					<path fill="currentColor"
							d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
				</svg>
			</a>
			<?php
		}
	}

	/**
	 * Add download button to hover effects that don't have socials
	 *
	 * @param $data
	 */
	public function download_no_socials( $data ) {

		if ( isset( $data->download['download_button'] ) && $data->download['download_button'] && $data->hide_socials ) {
			?>
			<div class="no-socials">
				<a href="<?php echo esc_url( $data->download['image_url'] ); ?>" target="_self" download
					class="modula-download-button" title="Download image">
					<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="download"
						class="svg-inline--fa fa-download fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 512 512">
						<path fill="currentColor"
								d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
				</a>
			</div>
			<?php
		}
	}

	/**
	 * Add download settings in item data
	 *
	 * @param array $item_data
	 * @param array $image
	 * @param array $gall_settings
	 * @param array $settings
	 *
	 * @return array $item_data
	 * @since 1.0.0
	 */
	public function download_albums_item_data_socials( $item_data, $image, $gall_settings, $settings ) {
		if ( ! isset( $settings['enable_download_albums'] ) || ! $settings['enable_download_albums'] || ! $settings['download_gallery_button_albums'] ) {
			return $item_data;
		}

		$item_data['download'] = array(
			'download_button' => $settings['enable_download_albums'] ? $settings['download_gallery_button_albums'] : 0,
			'album_id'        => $settings['gallery_id'],
		);

		return $item_data;
	}

	/**
	 * Add download button and download all in $item_data
	 *
	 * @param array $item_data
	 * @param array $image
	 * @param array $settings
	 *
	 * @return array $item_data
	 * @since 1.0.0
	 */
	public function modula_download_item_data( $item_data, $image, $settings ) {
		if ( isset( $settings['enable_download'] ) && 1 === (int) $settings['enable_download'] ) {
			if ( isset( $image['video_template'] ) && '1' === $image['video_template'] ) {
				$item_data['download'] = array(
					'download_button' => 0,
					'image_url'       => $item_data['link_attributes']['data-full'],
				);

				return $item_data;
			}

			if ( 'full' !== $settings['download_image_sizes'] ) {
				$item_data['download'] = array(
					'download_button' => $settings['enable_download'] ? $settings['download_gallery_button'] : 0,
					'image_url'       => wp_get_attachment_image_src( $image['id'], $settings['download_image_sizes'] )[0],
				);
			} elseif ( 'full' === $settings['download_image_sizes'] ) {
				$item_data['download'] = array(
					'download_button' => $settings['enable_download'] ? $settings['download_gallery_button'] : 0,
					'image_url'       => wp_get_original_image_url( $image['id'] ),
				);
			}
		}
		return $item_data;
	}

	/**
	 * Add download all shortcode in the columns
	 *
	 * @param string $column
	 * @param int    $post_id
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_gallery_column( $column, $post_id ) {
		if ( 'shortcode' === $column ) {
			$shortcode = '[modula-download id="' . $post_id . '"]' . esc_html__( 'Download Gallery', 'modula-pro' ) . '[/modula-download]';
			echo '<div class="modula-copy-shortcode">';
			echo '<input type="text" value="' . esc_attr( $shortcode ) . '"  onclick="select()" readonly>';
			echo '<a href="#" title="' . esc_attr__( 'Copy shortcode', 'modula-pro' ) . '" class="copy-modula-shortcode button button-primary dashicons dashicons-format-gallery" style="width:40px;"></a><span></span>';
			echo '</div>';
		}
	}

	/**
	 * Add download all shortcode in albums post type
	 *
	 * @param string $column
	 * @param int    $post_id
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_album_column( $column, $post_id ) {
		if ( 'shortcode' === $column ) {
			$shortcode = '[modula-download id="' . $post_id . '"]' . esc_html__( 'Download Album', 'modula-pro' ) . '[/modula-download]';
			echo '<div class="modula-copy-shortcode">';
			echo '<input type="text" value="' . esc_attr( $shortcode ) . '"  onclick="select()" readonly>';
			echo '<a href="#" title="' . esc_attr__( 'Copy shortcode', 'modula-pro' ) . '" class="copy-modula-shortcode button button-primary dashicons dashicons-format-gallery" style="width:40px;"></a><span></span>';
			echo '</div>';
		}
	}

		/**
	 * Render download all shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string $html
	 * @since 1.0.0
	 */
	public function download_shortcode( $atts, $content = null ) {
		$defaults_atts = array(
			'id' => false,
		);

		$atts = wp_parse_args( $atts, $defaults_atts );

		if ( '' === $atts['id'] || ! $atts['id'] ) {
			return esc_html__( 'Gallery not found', 'modula-pro' );
		}

		$gallery        = get_post( absint( $atts['id'] ) );
		$accepted_posts = array( 'modula-gallery', 'modula-album' );

		if ( ! in_array( get_post_type( $gallery ), $accepted_posts, true ) ) {
			return esc_html__( 'Given ID doesn\'t belong to a Modula Gallery!', 'modula-pro' );
		}

		wp_enqueue_style( 'modula-download-css', \MODULA_PRO_URL . 'includes/extensions/download/assets/css/modula-download-front.css', array(), \MODULA_PRO_VERSION );

		switch ( get_post_type( $gallery ) ) {
			case 'modula-gallery':
				$settings               = get_post_meta( $atts['id'], 'modula-settings', true );
				$defaults               = \Modula_CPT_Fields_Helper::get_defaults();
				$settings               = wp_parse_args( $settings, $defaults );
				$settings['gallery_id'] = 'jtg-' . $atts['id'];

				if ( ! isset( $settings['enable_download'] ) || ! boolval( $settings['enable_download'] ) ) {
					return '';
				}

				ob_start();
				/* phpcs:ignore */
				echo $this->generate_download_css( $atts['id'], $settings );
				$this->render_download_all_button( $settings );

				$html = ob_get_clean();

				return $html;

			case 'modula-album':
				$settings               = get_post_meta( $atts['id'], 'modula-album-settings', true );
				$defaults               = Fields_Helper::get_defaults();
				$settings               = wp_parse_args( $settings, $defaults );
				$settings['gallery_id'] = 'jtg-album-' . $atts['id'];

				if ( ! isset( $settings['enable_download_albums'] ) || ! boolval( $settings['enable_download_albums'] ) ) {
					return '';
				}

				ob_start();
				/* phpcs:ignore */
				echo $this->generate_album_download_css( $atts['id'], $settings );
				$this->render_download_all_album_button( $settings );

				$html = ob_get_clean();

				return $html;
		}
	}

		/**
		 * Download all shortcode CSS
		 *
		 * @param $id
		 * @param $settings
		 *
		 * @return string
		 */
	public function generate_download_css( $id, $settings ) {

		$css  = '<style>';
		$css .= '#jtg-' . $id . '-download.modula-download-all-button .modula-download-all svg {fill:' . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_gallery_icon_color'] ) . '}';
		$css .= "#jtg-{$id}-download.modula-download-all-button svg { display:inline-block;vertical-align:middle;}";
		$css .= '</style>';

		return $css;
	}

	public function generate_album_download_css( $id, $settings ) {
		$css  = '<style>';
		$css .= '#jtg-album-' . $id . '-download.modula-download-all-button .modula-download-all svg {fill:' . \Modula_Helper::sanitize_rgba_colour( $settings['download_all_gallery_icon_color_albums'] ) . '; display:inline-block;vertical-align:middle;}';
		$css .= '</style>';

		return $css;
	}


	/**
	 * Output download shortcode in admin metabox
	 *
	 * @param object $post
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function output_download_shortcode( $shortcodes, $post ) {
		if ( ! $post instanceof \WP_Post ) {
			return $shortcodes;
		}

		if ( class_exists( '\Modula_Pro\Extensions\Extensions' )
			&& ! \Modula_Pro\Extensions\Extensions::get_instance()->extension_enabled( 'modula-download' ) ) {
			return $shortcodes;
		}

		$shortcode   = '[modula-download id="' . $post->ID . '"]' . esc_html__( 'Click here', 'modula-pro' ) . '[/modula-download]';
		$description = esc_html__( 'You can use this shortcode to create a download button for your newly created gallery.', 'modula-download' );

		$shortcodes['modula_download'] = array(
			'code'        => $shortcode,
			'description' => $description,
		);

		return $shortcodes;
	}

		/**
	 * Deprecated output download shortcode in admin metabox
	 *
	 * @param object $post
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function backwards_output_download_shortcode( $post ) {
		$shortcode = '[modula-download id="' . $post->ID . '"]' . esc_html__( 'Download Gallery', 'modula-pro' ) . '[/modula-download]';
		echo '<div class="modula-copy-shortcode">';
		echo '<input type="text" value="' . esc_attr( $shortcode ) . '"  onclick="select()" readonly>';
		echo '<a href="#" title="' . esc_attr__( 'Copy shortcode', 'modula-pro' ) . '" class="copy-modula-shortcode button button-primary dashicons dashicons-format-gallery" style="width:40px;"></a><span></span>';
		echo '<p>' . esc_html__( 'You can use this shortcode to create a download button for your newly created gallery.', 'modula-pro' ) . '</p>';
		echo '</div>';
	}

	/**
	 * Output download shortcode for albums in admin metabox
	 *
	 * @param object $post
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function output_download_album_shortcode( $post ) {
		$shortcode = '[modula-download id="' . $post->ID . '"]' . esc_html__( 'Download Album', 'modula-pro' ) . '[/modula-download]';
		echo '<div class="modula-copy-shortcode">';
		echo '<input type="text" value="' . esc_attr( $shortcode ) . '"  onclick="select()" readonly>';
		echo '<a href="#" title="' . esc_attr__( 'Copy shortcode', 'modula-pro' ) . '" class="copy-modula-shortcode button button-primary dashicons dashicons-format-gallery" style="width:40px;"></a><span></span>';
		echo '<p>' . esc_html__( 'You can use this shortcode to create a download button for your newly created album ', 'modula-pro' ) . '</p>';
		echo '</div>';
	}


	/**
	 * Display the download all (ABOVE) && (ABOVE && BELLOW ) button
	 *
	 * @param array  $settings        Gallery settings.
	 * @param mixed  $item_data       Unused.
	 * @param array  $images          Unused.
	 * @param string $display_context 'beta' when Lite's v2 shortcode prints the hook.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_all_gallery_button_above( $settings, $item_data = null, $images = array(), $display_context = 'classic' ) {
		// Beta draws Download all in its React tree.
		if ( 'beta' === $display_context ) {
			return;
		}

		$gallery_proofing_lock = apply_filters( 'modula_gallery_proofing_lock', false, $settings['gallery_id'] );

		if ( ! isset( $settings['enable_download'] ) || ! $settings['enable_download'] || ! $settings['download_all_gallery_button'] ) {
			return;
		}

		if ( $gallery_proofing_lock ) {
			return;
		}

		$accepted_positions = array( 'above_gallery', 'above_below_gallery' );

		if ( ! in_array( $settings['download_all_position'], $accepted_positions ) ) {
			return;
		}

		$this->render_download_all_button( $settings );
	}

	/**
	 * Display the download all (BELOW) && (ABOVE && BELOW ) button
	 *
	 * @param array  $settings        Gallery settings.
	 * @param mixed  $item_data       Unused.
	 * @param array  $images          Unused.
	 * @param string $display_context 'beta' when Lite's v2 shortcode prints the hook.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_all_gallery_button_below( $settings, $item_data = null, $images = array(), $display_context = 'classic' ) {
		// Beta draws Download all in its React tree.
		if ( 'beta' === $display_context ) {
			return;
		}

		if ( ! isset( $settings['enable_download'] ) || ! $settings['enable_download'] || ! $settings['download_all_gallery_button'] ) {
			return;
		}
		$accepted_positions = array( 'below_gallery', 'above_below_gallery' );

		if ( ! in_array( $settings['download_all_position'], $accepted_positions, true ) ) {
			return;
		}

		$this->render_download_all_button( $settings );
	}

	private function render_download_all_button( $settings ) {
		?>
		<div class="modula-download-all-button">
			<a
				href="<?php echo esc_url( modula_download_req_url( $settings['gallery_id'] ) ); ?>"
				class="modula-download-all wp-block-button__link wp-element-button"
				id="<?php echo esc_attr( $settings['gallery_id'] ) . '-download'; ?>"
				target="_self"
			>
				<?php
				if ( isset( $settings['download_all_gallery_button_icon'] ) && boolval( $settings['download_all_gallery_button_icon'] ) ) {
					echo modula_download_all_svg();
				}

				echo ! empty( $settings['download_all_label'] )
					? esc_html( $settings['download_all_label'] )
					: esc_html__( 'Download All Images', 'modula-download' );
				?>
			</a>
		</div>
		<?php
	}

	/**
	 * Add a download all button in lightbox
	 *
	 * @param array $fancybox_options
	 * @param array $settings
	 *
	 * @return array $fancybox_options
	 * @since 1.0.0
	 */
	public function download_fancybox_button( $fancybox_options, $settings ) {
		if ( ! isset( $settings['enable_download'] ) || intval( $settings['enable_download'] ) !== 1 || ! $settings['download_all_lightbox_button'] ) {
			return $fancybox_options;
		}

		$fancybox_options['Toolbar']['items']['downloadAll']['tpl'] = '<a class="modula-fancybox-button download-all f-button" title="Download All" href="' . esc_url( modula_download_req_url( $settings['gallery_id'] ) ) . '"> <svg xmlns="http://www.w3.org/2000/svg" width="2480" height="3507" viewBox="0 0 2480 3507">
		<rect class="cls-1" x="5" y="2512" width="2475" height="996"/>
		<path id="ALL" class="cls-2" d="M627.528,2585.41L352.443,3406.16H487.6l64.474-199.75H848.647L917.9,3406.16H1054.01L759.34,2585.41H627.528Zm66.383,175.66,112.709,324.9H591.232Zm438.419-175.66v820.75h452.74V3282.19h-323.8V2585.41H1132.33Zm541.09,0v820.75h452.75V3282.19h-323.8V2585.41H1673.42Z"/>
		<rect class="cls-1" x="1001" y="6" width="453" height="1506"/>
		<path class="cls-3" d="M296,1399.6l295.125-296.49,406.3,408.19H1456.28L1869.66,1096,2185,1412.8,1253.13,2349Z"/>
		</svg></a>';
		array_unshift( $fancybox_options['Toolbar']['display']['right'], 'downloadAll' );
		return $fancybox_options;
	}


	/**
	 * Add a download button hovering over image in album
	 *
	 * @param object $data
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_album_button( $data ) {
		if ( isset( $data->download['download_button'] ) && $data->download['download_button'] ) {
			?>
			<div class="no-socials">
				<a href="<?php echo esc_url( modula_download_req_url( $data->gallery_id ) ); ?>"
					target="_self" download
					class="modula-download-button" title="Download image">
					<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="download"
						class="svg-inline--fa fa-download fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 512 512">
						<path fill="currentColor"
								d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
				</a>
			</div>
			<?php
		}
	}

	/**
	 * Display the download all (ABOVE) && (ABOVE && BELOW ) button
	 *
	 * Separated albums/galleries sections print it once, above the first section.
	 *
	 * @param array       $settings
	 * @param object|null $data     Album template data.
	 * @param string      $type     Section type: `all` (merged), `modula-album` or `modula-gallery`.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_all_album_button_above( $settings, $data = null, $type = 'all' ) {

		if ( ! isset( $settings['enable_download_albums'] ) || ! $settings['enable_download_albums'] || ! $settings['download_all_gallery_button_albums'] ) {
			return;
		}

		$accepted_positions = array( 'above_gallery', 'above_below_gallery' );

		if ( ! in_array( $settings['download_all_position_albums'], $accepted_positions ) ) {
			return;
		}

		if ( ! Album_Sections::is_first( $type, $data ) ) {
			return;
		}

		$this->render_download_all_album_button( $settings );
	}

	/**
	 * Display the download all (BELOW) && (ABOVE && BELOW ) button
	 *
	 * Separated albums/galleries sections print it once, below the last section.
	 *
	 * @param array       $settings
	 * @param object|null $data     Album template data.
	 * @param string      $type     Section type: `all` (merged), `modula-album` or `modula-gallery`.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function download_all_album_button_below( $settings, $data = null, $type = 'all' ) {
		if ( ! isset( $settings['enable_download_albums'] ) || ! $settings['enable_download_albums'] || ! $settings['download_all_gallery_button_albums'] ) {
			return;
		}

		$accepted_positions = array( 'below_gallery', 'above_below_gallery' );

		if ( ! in_array( $settings['download_all_position_albums'], $accepted_positions ) ) {
			return;
		}

		if ( ! Album_Sections::is_last( $type, $data ) ) {
			return;
		}

		$this->render_download_all_album_button( $settings );
	}

	private function render_download_all_album_button( $settings ) {
		?>
		<div class="modula-download-all-button wp-block-button">
			<a
				href="<?php echo esc_url( modula_download_req_url( $settings['gallery_id'] ) ); ?>"
				class="modula-download-all wp-block-button__link wp-element-button"
				id="<?php echo esc_attr( $settings['gallery_id'] ) . '-download'; ?>"
				target="_self"
			>
				<?php
				if ( isset( $settings['download_all_gallery_button_icon_albums'] ) && boolval( $settings['download_all_gallery_button_icon_albums'] ) ) {
					echo modula_download_all_svg();
				}

				echo ! empty( $settings['download_all_label_albums'] )
					? esc_html( $settings['download_all_label_albums'] )
					: esc_html__( 'Download All Images', 'modula-download' );
				?>
			</a>
		</div>
		<?php
	}

	/**
	 * Add download all lightbox in albums
	 *
	 * @param $template_data
	 *
	 * @return array $js_config
	 * @since 1.0.0
	 */
	public function download_album_fancybox_button( $template_data ) {

		if ( ! isset( $template_data['settings']['enable_download_albums'] ) || ! $template_data['settings']['enable_download_albums'] || ! $template_data['settings']['download_all_lightbox_button_albums'] ) {
			return $template_data;
		}

		$template_data['js_config']['lightbox_settings']['Toolbar']['items']['downloadAll']['tpl'] = '<a class="modula-fancybox-button download-all f-button" title="' . esc_attr__( 'Download All', 'modula-pro' ) . '" href="' . esc_url( modula_download_req_url( $template_data['settings']['gallery_id'] ) ) . '"> <svg xmlns="http://www.w3.org/2000/svg" width="2480" height="3507" viewBox="0 0 2480 3507">
		<rect class="cls-1" x="5" y="2512" width="2475" height="996"/>
		<path id="ALL" class="cls-2" d="M627.528,2585.41L352.443,3406.16H487.6l64.474-199.75H848.647L917.9,3406.16H1054.01L759.34,2585.41H627.528Zm66.383,175.66,112.709,324.9H591.232Zm438.419-175.66v820.75h452.74V3282.19h-323.8V2585.41H1132.33Zm541.09,0v820.75h452.75V3282.19h-323.8V2585.41H1673.42Z"/>
		<rect class="cls-1" x="1001" y="6" width="453" height="1506"/>
		<path class="cls-3" d="M296,1399.6l295.125-296.49,406.3,408.19H1456.28L1869.66,1096,2185,1412.8,1253.13,2349Z"/>
		</svg></a>';
		array_unshift( $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'], 'downloadAll' );
		$template_data['album_container']['data-config'] = wp_json_encode( $template_data['js_config'] );

		return $template_data;
	}
	/**
	 * Slider download button
	 *
	 * @param $data
	 * @since 1.0.0
	 */
	public function slider_download_button( $data ) {

		if ( isset( $data->download['download_button'] ) && '1' === $data->download['download_button'] ) {
			?>
			<div class="no-socials">
				<a href="<?php echo esc_url( $data->download['image_url'] ); ?>" target="_self" download
					class="modula-download-button" title="Download image">
					<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="download"
						class="svg-inline--fa fa-download fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 512 512">
						<path fill="currentColor"
								d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
				</a>
			</div>
			<?php
		}
	}
}
