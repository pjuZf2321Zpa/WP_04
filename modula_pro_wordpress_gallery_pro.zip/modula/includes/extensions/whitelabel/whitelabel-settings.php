<?php
/**
 * Whitelabel settings page
 *
 * @package modula-whitelabel
 */

$modula_whitelabel_settings = get_option( 'modula_whitelabel_settings', array() );


$modula_tabs = array( 'gallery', 'albums', 'defaults', 'misc' );

$modula_whitelabel_fields = array(
	'brand'                      => array(
		'name'    => esc_html__( 'Brand Name', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Modula',
		'tab'     => 'misc',
	),
	'logo'                       => array(
		'name'    => esc_html__( 'Logo PNG/JPG', 'modula-pro' ),
		'type'    => 'image-upload',
		'default' => 0,
		'tab'     => 'misc',
	),
	'logo_svg'                   => array(
		'name'    => esc_html__( 'Logo SVG', 'modula-pro' ),
		'type'    => 'textarea',
		'default' => 0,
		'tab'     => 'misc',
	),
	'remove_links'               => array(
		'name'    => esc_html__( 'Remove Links', 'modula-pro' ),
		'type'    => 'toggle',
		'default' => false,
		'tab'     => 'misc',
	),
	'feedback_link'              => array(
		'name'    => esc_html__( 'Feedback Link', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'https://google.com',
		'tab'     => 'misc',
	),
	'review_link'                => array(
		'name'    => esc_html__( 'Review Link', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'https://google.com',
		'tab'     => 'misc',
	),
	'gallery_name'               => array(
		'name'    => esc_html__( 'Gallery Name', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Modula Gallery',
		'tab'     => 'gallery',
	),
	'gallery_all_items'          => array(
		'name'    => esc_html__( 'Gallery All Items', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Galleries',
		'tab'     => 'gallery',
	),
	'albums_name'                => array(
		'name'    => esc_html__( 'Albums Name', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Modula Albums',
		'tab'     => 'albums',
	),
	'albums_all_items'           => array(
		'name'    => esc_html__( 'Albums All Items', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Albums',
		'tab'     => 'albums',
	),
	'defaults_gallery_name'      => array(
		'name'    => esc_html__( 'Default Gallery Name', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Modula Defaults Gallery',
		'tab'     => 'defaults',
	),
	'defaults_gallery_all_items' => array(
		'name'    => esc_html__( 'Default Gallery All Items', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Defaults',
		'tab'     => 'defaults',
	),
	'defaults_albums_name'       => array(
		'name'    => esc_html__( 'Default Album Name', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Modula Defaults Albums',
		'tab'     => 'defaults',
	),
	'defaults_albums_all_items'  => array(
		'name'    => esc_html__( 'Default Albums All Items', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Defaults Albums',
		'tab'     => 'defaults',
	),
	'feedback_title'             => array(
		'name'    => esc_html__( 'Feedback Title', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Welcome',
		'tab'     => 'misc',
	),
	'feedback_paragraph'         => array(
		'name'    => esc_html__( 'Feedback Paragraph', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Leave a feedback',
		'tab'     => 'misc',
	),
	'review_notice'              => array(
		'name'    => esc_html__( 'Review Notice', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Please review if you enjoy using the plugin',
		'tab'     => 'misc',
	),
	'review_rate'                => array(
		'name'    => esc_html__( 'Review Rate', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Rate Now',
		'tab'     => 'misc',
	),
	'review_rated'               => array(
		'name'    => esc_html__( 'Review Rated', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Rated',
		'tab'     => 'misc',
	),
	'review_no_rate'             => array(
		'name'    => esc_html__( 'Review No Rate', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'No Rate',
		'tab'     => 'misc',
	),
	'documentation'              => array(
		'name'    => esc_html__( 'Documentation', 'modula-pro' ),
		'type'    => 'textarea',
		'default' => '<a href="https://wp-modula.com/" target="_blank" class="">' . esc_html__( 'Documentation', 'modula-pro' ) . '</a>',
		'tab'     => 'misc',
	),
	'contact'                    => array(
		'name'    => esc_html__( 'Contact', 'modula-pro' ),
		'type'    => 'textarea',
		'default' => '<a href="https://wp-modula.com/" target="_blank" class="">' . esc_html__( 'Contact', 'modula-pro' ) . '</a>',
		'tab'     => 'misc',
	),
	'beaver_block_description'   => array(
		'name'    => esc_html__( 'Beaver Block Description', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Block Description',
		'tab'     => 'misc',
	),
	'beaver_block_category'      => array(
		'name'    => esc_html__( 'Beaver Block Category', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Selected Category',
		'tab'     => 'misc',
	),
	'beaver_block_section'       => array(
		'name'    => esc_html__( 'Beaver Block Section', 'modula-pro' ),
		'type'    => 'text',
		'default' => 'Select your Gallery',
		'tab'     => 'misc',
	),
	'hide_from_plugin_list'      => array(
		'name'    => esc_html__( 'Hide plugin from list', 'modula-pro' ),
		'type'    => 'toggle',
		'default' => false,
		'tab'     => 'misc',
	),

);

/**
 * Render rows for modula whitelabel
 *
 * @param string $field field.
 * @param string $key   key.
 * @param string $type  eg - toggle, text.
 * @param array  $modula_whitelabel_settings settings.
 */
function modula_whitelabel_render_row( $field, $key, $type, $modula_whitelabel_settings ) {
	$html  = '';
	$value = isset( $modula_whitelabel_settings[ $field ] ) ? trim( $modula_whitelabel_settings[ $field ] ) : $key['default'];
	switch ( $type ) {
		case 'text':
			$html .= "<div class='{$key['tab']} whitelabel-tab-content'>";
			$html .= "<p>{$key['name']}</p>";
			$html .= "<input id='modula_whitelabel_settings_{$field}' type='text' name='modula_whitelabel_settings[{$field}]' value='{$value}' >";
			$html .= '</div>';
			break;

		case 'image-upload':
			$style = array(
				'upload'  => '',
				'replace' => 'display:none;',
				'delete'  => 'display:none;',
			);

			if ( 0 !== absint( $value ) ) {
				$style['upload']  = 'display:none;';
				$style['replace'] = '';
				$style['delete']  = '';
			}
			$html  = "<div class='{$key['tab']} whitelabel-tab-content'>";
			$html .= "<p>{$key['name']}</p>";
			$html .= '<div>';
			$html .= '<input type="hidden" name="modula_whitelabel_settings[' . esc_attr( $field ) . ']" id="' . esc_attr( $field ) . '" value="' . absint( $value ) . '">';
			$html .= '<div class="modula_cursor_preview">';
			if ( $value ) {
				$image = wp_get_attachment_image_src( $value );
				if ( $image ) {
					$html .= '<img src="' . esc_url( $image[0] ) . '" id="modula_cursor_preview">';
				}
			}
			$html .= '</div>';
			$html .= '<input type="button" style="' . esc_attr( $style['upload'] ) . '" class="button button-primary" id="upload_cursor_file" value="' . esc_attr__( 'Upload', 'modula-pro' ) . '">';
			$html .= '<input type="button" style="' . esc_attr( $style['replace'] ) . '" class="button button-primary" id="replace_cursor_file" value="' . esc_attr__( 'Replace', 'modula-pro' ) . '">';
			$html .= '<input type="button" style="' . esc_attr( $style['delete'] ) . '" class="button" id="delete_cursor_file" value="' . esc_attr__( 'Delete', 'modula-pro' ) . '">';
			$html .= '</div>';
			$html .= '</div>';
			break;

		case 'textarea':
			$html  = "<div class='{$key['tab']} whitelabel-tab-content'>";
			$html .= "<p>{$key['name']}</p>";
			$html .= "<textarea id='[{$field}]' wrap='off' name=modula_whitelabel_settings[{$field}] rows='3' cols='50' >$value</textarea>";
			$html .= '</div>';
			break;

		case 'toggle':
			$html  = "<div class='{$key['tab']} whitelabel-tab-content'>";
			$html .= "<p>{$key['name']}</p>";
			$html .= '<div class="modula-toggle">';
			$html .= '<input class="modula-toggle__input" type="checkbox" data-setting="' . esc_attr( $field ) . '" id="' . esc_attr( $field ) . '" name="modula_whitelabel_settings[' . esc_attr( $field ) . ']" value="1" ' . checked( 1, $value, false ) . '>';
			$html .= '<div class="modula-toggle__items">';
			$html .= '<span class="modula-toggle__track"></span>';
			$html .= '<span class="modula-toggle__thumb"></span>';
			$html .= '<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 6 6"><path d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path></svg>';
			$html .= '<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 2 6"><path d="M0 0h2v6H0z"></path></svg>';
			$html .= '</div>';
			$html .= '</div>';
			$html .= '</div>';
			break;
	}
	return $html;
}
?>


<div id="modula-tabs">
	<ul class="wp-clearfix nav-tab-wrapper modula-tab-container">
		<li><a class="nav-tab nav-tab-active" href="#gallery">Gallery</a></li>
		<li><a class="nav-tab" href="#albums">Albums</a></li>
		<li><a class="nav-tab" href="#defaults">Defaults</a></li>
		<li><a class="nav-tab last_tab" href="#misc">Misc</a></li>
	</ul>
	<form method="post" action="options.php">
	<?php
	settings_fields( 'modula_whitelabel_settings' );
	// phpcs:disable
	$html = '';
	foreach ( $modula_tabs as $modula_tab ) {
		$html .= "<div id='{$modula_tab}'>";
		foreach ( $modula_whitelabel_fields as $field => $value ) {
			if ( 'gallery' === $modula_tab && 'gallery' === $value['tab'] ) {
				$html .= modula_whitelabel_render_row( $field, $value, $value['type'], $modula_whitelabel_settings );
			} elseif ( 'albums' === $modula_tab && 'albums' === $value['tab'] ) {
				$html .= modula_whitelabel_render_row( $field, $value, $value['type'], $modula_whitelabel_settings );
			} elseif ( 'defaults' === $modula_tab && 'defaults' === $value['tab'] ) {
				$html .= modula_whitelabel_render_row( $field, $value, $value['type'], $modula_whitelabel_settings );
			} elseif ( 'misc' === $modula_tab && 'misc' === $value['tab'] ) {
				$html .= modula_whitelabel_render_row( $field, $value, $value['type'], $modula_whitelabel_settings );
			}
		}
		$html .= '</div>';
	}
	echo $html;
	// phpcs:enable
	?>
		<?php submit_button(); ?>
	</form>
</div>
