jQuery( document ).ready( () => {
	jQuery( '#modula-tabs' ).tabs();

	jQuery( '.nav-tab' ).on( 'click', ( { target } ) => {
		jQuery( '#modula-tabs' )
			.find( '.nav-tab-active' )
			.removeClass( 'nav-tab-active' );
		jQuery( target ).addClass( 'nav-tab-active' );
	} );

	const modulaCursorFrame = new wp.media( {
		title: 'Select a image to upload',
		button: {
			text: 'Use this image',
		},
		multiple: false, // Set to true to allow multiple files to be selected
	} );

	modulaCursorFrame.on( 'select', () => {
		// We set multiple to false so only get one image from the uploader
		const attachment = modulaCursorFrame
			.state()
			.get( 'selection' )
			.first()
			.toJSON();

		let att_id = attachment.id,
			att_src = attachment.url;

		if ( 'undefined' !== typeof attachment.sizes.thumbnail ) {
			att_src = attachment.sizes.thumbnail.url;
		}

		jQuery( '#uploadCursor' ).val( att_id );

		jQuery( '.modula_cursor_preview' ).html(
			'<img src="' + att_src + '" id="modula_cursor_preview">'
		);
		jQuery( '#logo' ).val( att_id );
		jQuery( '#upload_cursor_file' ).hide();
		jQuery( '#replace_cursor_file' ).show();
		jQuery( '#delete_cursor_file' ).show();
	} );

	jQuery( '#upload_cursor_file' ).click( ( event ) => {
		event.preventDefault();
		modulaCursorFrame.open();
	} );

	jQuery( '#replace_cursor_file' ).click( ( event ) => {
		event.preventDefault();
		modulaCursorFrame.open();
	} );
	jQuery( '#delete_cursor_file' ).click( ( event ) => {
		event.preventDefault();

		jQuery( '#logo' ).val( 0 );
		jQuery( '#uploadCursor' ).val( 0 );
		jQuery( '.modula_cursor_preview' ).html( '' );
		jQuery( '#upload_cursor_file' ).show();
		jQuery( '#replace_cursor_file' ).hide();
		jQuery( '#delete_cursor_file' ).hide();
	} );
} );
