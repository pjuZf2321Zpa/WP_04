<?php

namespace Modula_Pro\Extensions\Whitelabel;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Modula Whitelabel class
 */
class Whitelabel {
	/**
	 * Main config array
	 *
	 * @var $modula_whitelabel_config
	 */
	public $modula_whitelabel_config;

	/**
	 * The single instance of the class.
	 *
	 * @var Whitelabel
	 *
	 * @since   1.0.0
	 */
	public static $instance = null;

	/**
	 * Construct function
	 */
	public function __construct() {
		add_filter( 'modula_whitelabel_config', array( $this, 'modula_whitelabel_config' ), 1, 2 );
		add_action( 'init', array( $this, 'init' ), 1, 99 );
	}

	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Whitelabel ) ) {
			self::$instance = new Whitelabel();
		}

		return self::$instance;
	}

	public function modula_whitelabel_config( $config ) {

		$modula_whitelabel_settings = get_option( 'modula_whitelabel_settings', array() );
		if ( ! empty( $modula_whitelabel_settings ) ) {
			$config = array(
				'brand'            => 'Modula' !== $modula_whitelabel_settings['brand'] ? $modula_whitelabel_settings['brand'] : false,
				'gallery'          => array(
					'name'      => $modula_whitelabel_settings['gallery_name'],
					'all_items' => $modula_whitelabel_settings['gallery_all_items'],
				),
				'albums'           => array(
					'name'      => $modula_whitelabel_settings['albums_name'],
					'all_items' => $modula_whitelabel_settings['albums_all_items'],
				),
				'defaults_gallery' => array(
					'name'      => $modula_whitelabel_settings['defaults_gallery_name'],
					'all_items' => $modula_whitelabel_settings['defaults_gallery_all_items'],
				),
				'defaults_album'   => array(
					'name'      => $modula_whitelabel_settings['defaults_albums_name'],
					'all_items' => $modula_whitelabel_settings['defaults_albums_all_items'],
				),
				'logo'             => 0 !== $modula_whitelabel_settings['logo'] ? $modula_whitelabel_settings['logo'] : \MODULA_URL . 'assets/images/modula.png',
				'logo_svg'         => 0 !== $modula_whitelabel_settings['logo_svg'] ? $modula_whitelabel_settings['logo_svg'] : 'html of the logo',
				'feedback'         => array(
					'title'     => $modula_whitelabel_settings['feedback_title'],
					'paragraph' => $modula_whitelabel_settings['feedback_paragraph'],
					'link'      => $modula_whitelabel_settings['feedback_link'],
				),
				'review'           => array(
					'notice'  => $modula_whitelabel_settings['review_notice'],
					'rate'    => $modula_whitelabel_settings['review_rate'],
					'rated'   => $modula_whitelabel_settings['review_rated'],
					'no_rate' => $modula_whitelabel_settings['review_no_rate'],
					'link'    => $modula_whitelabel_settings['review_link'],
				),
				'documentation'    => $modula_whitelabel_settings['documentation'],
				'contact'          => $modula_whitelabel_settings['contact'],
				'beaver_block'     => array(
					'description' => $modula_whitelabel_settings['beaver_block_description'],
					'category'    => $modula_whitelabel_settings['beaver_block_category'],
					'section'     => $modula_whitelabel_settings['beaver_block_section'],
				),
				'remove_links'     => isset( $modula_whitelabel_settings['remove_links'] ) ? $modula_whitelabel_settings['remove_links'] : false,
			);
		} else {
			$config = array(
				'gallery'          => array(
					'name'      => 'Your Gallery',
					'all_items' => 'Galleries',
				),
				'albums'           => array(
					'name'      => 'Your Album',
					'all_items' => 'All Albumele',
				),
				'defaults_gallery' => array(
					'name'      => 'Default Galerry',
					'all_items' => 'All default galleries',
				),
				'defaults_album'   => array(
					'name'      => 'Default Album',
					'all_items' => 'All defaults albums',
				),
				'logo'             => \MODULA_URL . 'assets/images/modula.png',
				'logo_svg'         => 'html of the svg directly copied',
				'feedback'         => array(
					'title'     => 'Welcome',
					'paragraph' => 'Whitelabel Plugin',
					'link'      => 'https://google.com',
				),
				'documentation'    => '<a href="https://wp-modula.com" target="_blank" class="">' . esc_html__( 'Documentation', 'modula-pro' ) . '</a>',
				'contact'          => '<a href="https://wp-modula.com" target="_blank" class="">' . esc_html__( 'Contact', 'modula-pro' ) . '</a>',
				'beaver_block'     => array(
					'description' => 'Block Description',
					'category'    => 'Selected Category',
					'section'     => 'Select your Gallery',
				),
				'remove_links'     => false,
			);
			return $config;
		}
		return $config;
	}

	/**
	 * Initialization function
	 */
	public function init() {
			$this->modula_whitelabel_config = apply_filters( 'modula_whitelabel_config', false );

			// Admin files.
			add_action( 'admin_menu', array( $this, 'modula_whitelabel_menu' ), 9, 1 );
			add_filter( 'submenu_file', array( $this, 'remove_about_submenu_item' ), 10, 2 );
			add_action( 'admin_init', array( $this, 'register_whitelabel_settings' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_whitelabel_assets' ) );

			// Filter for Gallery CPT Labels.
			add_filter( 'modula_cpt_labels', array( $this, 'modula_whitelabel_gallery_labels' ) );

			// Filter for Albums CPT Labels.
			add_filter( 'modula_album_cpt_labels', array( $this, 'modula_whitelabel_albums_labels' ) );

			// Filter for Gallery Default CPT Labels.
			add_filter( 'modula_defaults_cpt_labels', array( $this, 'modula_whitelabel_gallery_defaults_labels' ) );

			// Filter for Albums Default CPT Labels.
			add_filter( 'modula_defaults_albums_cpt_labels', array( $this, 'modula_whitelabel_albums_defaults_labels' ) );

			// Filter for Logo.
			add_filter( 'modula_cpt_args', array( $this, 'modula_image' ) );
			// SVG Logo.
			add_filter( 'modula_svg_icon', array( $this, 'modula_svg' ) );

			// Filter For the Feedback.
			add_filter( 'modula_admin_feedback_title', array( $this, 'feedback_title' ) );
			add_filter( 'modula_admin_feedback_paragraph', array( $this, 'feedback_paragraph' ) );
			add_filter( 'modula_admin_feedback_link', array( $this, 'feedback_link' ) );

			// Filter for review class.
			add_filter( 'modula_review_messages', array( $this, 'review_message' ) );
			add_filter( 'modula_review_link', array( $this, 'review_link' ) );

			// Filter for documentation and contact.
			add_filter( 'modula_admin_documentation_link', array( $this, 'modula_documentation' ) );
			add_filter( 'modula_admin_contact_link', array( $this, 'modula_contact' ) );

			// Filter for Elementor & Beaver Block.
			add_filter( 'modula_elementor_name', array( $this, 'change_elementor_name' ) );
			add_filter( 'modula_albums_elementor_name', array( $this, 'change_elementor_name_albums' ) );

			add_filter( 'modula_beaver_construct', array( $this, 'beaver_block_construct' ), 1 );
			add_filter( 'modula_beaver_module', array( $this, 'beaver_module' ), 1 );

			add_filter( 'modula_albums_beaver_construct', array( $this, 'beaver_block_construct_albums' ), 1 );
			add_filter( 'modula_albums_beaver_module', array( $this, 'beaver_module_albums' ), 1 );

			// Gettext filter to remove traces of Modula from tooltips / settings.
			add_filter( 'gettext', array( $this, 'modula_getter_text' ), 10, 3 );
	}

	/**
	 * Register hidden submenu page
	 *
	 * @since 1.0.1
	 */
	public function modula_whitelabel_menu() {
		add_submenu_page(
			'options-general.php',
			'Whitelabel Settings',
			'Whitelabel Settings',
			'manage_options',
			'whitelabel-settings',
			array( $this, 'whitelabel_settings' )
		);
	}

	/**
	 * Display About page
	 *
	 * @since 2.2.4
	 */
	public function whitelabel_settings() {

		include 'whitelabel-settings.php';
	}

	/**
	 * Remove the About submenu
	 *
	 * @param string $submenu_file submenu entry.
	 * @return mixed
	 */
	public function remove_about_submenu_item( $submenu_file ) {

		remove_submenu_page( 'options-general.php', 'whitelabel-settings' );

		return $submenu_file;
	}

	/**
	 * Register whitelabel settings
	 *
	 * @since 1.0.1
	 */
	public function register_whitelabel_settings() {
		register_setting( 'modula_whitelabel_settings', 'modula_whitelabel_settings' );
	}

	/**
	 * Enqueue whitelabel assets just on the settings page
	 */
	public function enqueue_whitelabel_assets() {
		$screen = get_current_screen();
		if ( 'settings_page_whitelabel-settings' === $screen->id ) {
			wp_enqueue_media();
			wp_enqueue_script( 'jquery-ui-core' );
			wp_enqueue_script( 'jquery-ui-tabs' );
			wp_enqueue_script( 'modula-whitelabel-js', plugin_dir_url( __FILE__ ) . 'modula_whitelabel.js', array( 'jquery' ), '1.0.2', false );
		}

		wp_enqueue_style( 'modula-whitelabel-css', plugin_dir_url( __FILE__ ) . 'modula_whitelabel.css', array(), '1.0.2' );
	}

	/**
	 * Whitelabel gallery labels
	 *
	 * @since 1.0.0
	 *
	 * @param array $labels register_post labels.
	 *
	 * @return array $labels
	 */
	public function modula_whitelabel_gallery_labels( $labels ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] && '' !== $this->modula_whitelabel_config['brand'] ) {
			$labels['menu_name']      = esc_html( $this->modula_whitelabel_config['brand'] );
			$labels['name_admin_bar'] = esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['gallery']['name'] ) ) {
			$labels['menu_name']      = esc_html( $this->modula_whitelabel_config['gallery']['name'] );
			$labels['name_admin_bar'] = esc_html( $this->modula_whitelabel_config['gallery']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['gallery']['singular_name'] ) ) {
			$labels['singular_name'] = esc_html( $this->modula_whitelabel_config['gallery']['singular_name'] );
		}

		if ( isset( $this->modula_whitelabel_config['gallery']['all_items'] ) ) {
			$labels['all_items'] = esc_html( $this->modula_whitelabel_config['gallery']['all_items'] );
		}

		return $labels;
	}

	/**
	 * Whitelabel albums labels
	 *
	 * @since 1.0.0
	 *
	 * @param array $labels register post albums labels.
	 *
	 * @return array $labels
	 */
	public function modula_whitelabel_albums_labels( $labels ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] && '' !== $this->modula_whitelabel_config['brand'] ) {
			$labels['menu_name']      = esc_html( "{$this->modula_whitelabel_config['brand']} Albums" );
			$labels['name_admin_bar'] = esc_html( "{$this->modula_whitelabel_config['brand']} Albums" );
		} elseif ( isset( $this->modula_whitelabel_config['albums']['name'] ) ) {
			$labels['menu_name']      = esc_html( $this->modula_whitelabel_config['albums']['name'] );
			$labels['name_admin_bar'] = esc_html( $this->modula_whitelabel_config['albums']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['albums']['singular_name'] ) ) {
			$labels['singular_name'] = esc_html( $this->modula_whitelabel_config['albums']['singular_name'] );
		}

		if ( isset( $this->modula_whitelabel_config['albums']['all_items'] ) ) {
			$labels['all_items'] = esc_html( $this->modula_whitelabel_config['albums']['all_items'] );
		}

		return $labels;
	}

	/**
	 * Whitelabel gallery defaults labels
	 *
	 * @since 1.0.0
	 *
	 * @param array $labels register post defaults labels.
	 *
	 * @return array $labels
	 */
	public function modula_whitelabel_gallery_defaults_labels( $labels ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] && '' !== $this->modula_whitelabel_config['brand'] ) {
			$labels['menu_name']      = esc_html( "{$this->modula_whitelabel_config['brand']} Defaults" );
			$labels['name_admin_bar'] = esc_html( "{$this->modula_whitelabel_config['brand']} Defaults" );
		} elseif ( isset( $this->modula_whitelabel_config['defaults_gallery']['name'] ) ) {
			$labels['menu_name']      = esc_html( $this->modula_whitelabel_config['defaults_gallery']['name'] );
			$labels['name_admin_bar'] = esc_html( $this->modula_whitelabel_config['defaults_gallery']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['defaults_gallery']['singular_name'] ) ) {
			$labels['singular_name'] = esc_html( $this->modula_whitelabel_config['defaults_gallery']['singular_name'] );
		}

		if ( isset( $this->modula_whitelabel_config['defaults_gallery']['all_items'] ) ) {
			$labels['all_items'] = esc_html( $this->modula_whitelabel_config['defaults_gallery']['all_items'] );
		}

		return $labels;
	}

	/**
	 * Whitelabel albums defaults labels
	 *
	 * @since 1.0.0
	 *
	 * @param array $labels register post albums defaults labels.
	 *
	 * @return array $labels
	 */
	public function modula_whitelabel_albums_defaults_labels( $labels ) {
		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] && '' !== $this->modula_whitelabel_config['brand'] ) {
			$labels['menu_name']      = esc_html( "{$this->modula_whitelabel_config['brand']} Defaults Albums" );
			$labels['name_admin_bar'] = esc_html( "{$this->modula_whitelabel_config['brand']} Defaults Albums" );
		} elseif ( isset( $this->modula_whitelabel_config['defaults_album']['name'] ) ) {
			$labels['menu_name']      = esc_html( $this->modula_whitelabel_config['defaults_album']['name'] );
			$labels['name_admin_bar'] = esc_html( $this->modula_whitelabel_config['defaults_album']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['defaults_album']['singular_name'] ) ) {
			$labels['singular_name'] = esc_html( $this->modula_whitelabel_config['defaults_album']['singular_name'] );
		}

		if ( isset( $this->modula_whitelabel_config['defaults_album']['all_items'] ) ) {
			$labels['all_items'] = esc_html( $this->modula_whitelabel_config['defaults_album']['all_items'] );
		}

		return $labels;
	}

	/**
	 * Whitelabel image
	 *
	 * @param array $cpt_args arguments for cpt.
	 *
	 * @since 1.0.0
	 *
	 * @return string $cpt
	 */
	public function modula_image( $cpt_args ) {
		if ( isset( $this->modula_whitelabel_config['logo'] ) ) {
			$image                 = wp_get_attachment_image_url( $this->modula_whitelabel_config['logo'] );
			$cpt_args['menu_icon'] = $image;
		}
		return $cpt_args;
	}

	/**
	 * Whitelabel svg
	 *
	 * @since 1.0.0
	 *
	 * @param string $svg logo svg.
	 *
	 * @return string $svg
	 */
	public function modula_svg( $svg ) {
		if ( isset( $this->modula_whitelabel_config['logo_svg'] ) ) {
			$svg = $this->modula_whitelabel_config['logo_svg'];
		}
		return $svg;
	}

	/**
	 * Whitelabel feedback title
	 *
	 * @since 1.0.0
	 *
	 * @param string $title title.
	 *
	 * @return string $title
	 */
	public function feedback_title( $title ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			return esc_html( "{$this->modula_whitelabel_config['brand']} Image Gallery" );
		} elseif ( isset( $this->modula_whitelabel_config['feedback']['title'] ) ) {
			return esc_html( $this->modula_whitelabel_config['feedback']['title'] );
		}
		return $title;
	}

	/**
	 * Whitelabel feedback paragraph
	 *
	 * @since 1.0.0
	 *
	 * @param string $paragraph paragraph of the feedback.
	 *
	 * @return string $paragraph
	 */
	public function feedback_paragraph( $paragraph ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			return esc_html( "Do you enjoy using {$this->modula_whitelabel_config['brand']}? Please take a minute to suggest a feature or tell us what you think." );
		} elseif ( isset( $this->modula_whitelabel_config['feedback']['paragraph'] ) ) {
			return esc_html( $this->modula_whitelabel_config['feedback']['paragraph'] );
		}
		return $paragraph;
	}

	/**
	 * Whitelabel feedback link
	 *
	 * @since 1.0.0
	 *
	 * @param string $link link in the feedback area.
	 *
	 * @return string $link
	 */
	public function feedback_link( $link ) {

		if ( isset( $this->modula_whitelabel_config['feedback_link'] ) ) {
			return $this->modula_whitelabel_config['feedback_link'];
		} elseif ( isset( $this->modula_whitelabel_config['feedback']['link'] ) ) {
			return $this->modula_whitelabel_config['feedback']['link'];
		}
		return $link;
	}

	/**
	 * Whitelabel review message
	 *
	 * @since 1.0.0
	 *
	 * @param string $messages different messages in the review section.
	 *
	 * @return string $messages
	 */
	public function review_message( $messages ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$messages['notice'] = esc_html( "Hi there! Stoked to see you're using {$this->modula_whitelabel_config['brand']} for a few days now - hope you like it! And if you do, please consider rating it. It would mean the world to us.  Keep on rocking!" );
		} elseif ( isset( $this->modula_whitelabel_config['review']['notice'] ) ) {
			$messages['notice'] = esc_html( $this->modula_whitelabel_config['review']['notice'] );
		}

		if ( isset( $this->modula_whitelabel_config['review']['rate'] ) ) {
			$messages['rate'] = esc_html( $this->modula_whitelabel_config['review']['rate'] );
		}

		if ( isset( $this->modula_whitelabel_config['review']['rated'] ) ) {
			$messages['rated'] = esc_html( $this->modula_whitelabel_config['review']['rated'] );
		}

		if ( isset( $this->modula_whitelabel_config['review']['no_rate'] ) ) {
			$messages['no_rate'] = esc_html( $this->modula_whitelabel_config['review']['no_rate'] );
		}

		return $messages;
	}

	/**
	 * Whitelabel review link
	 *
	 * @since 1.0.0
	 *
	 * @param string $link link in the review section.
	 *
	 * @return string $link
	 */
	public function review_link( $link ) {

		if ( isset( $this->modula_whitelabel_config['review_link'] ) ) {
			return $this->modula_whitelabel_config['review_link'];
		} elseif ( isset( $this->modula_whitelabel_config['review']['link'] ) ) {
			return $this->modula_whitelabel_config['review']['link'];
		}

		return $link;
	}

	/**
	 * Whitelabel documentation
	 *
	 * @since 1.0.0
	 *
	 * @param string $doc documentation.
	 *
	 * @return string $doc
	 */
	public function modula_documentation( $doc ) {

		if ( isset( $this->modula_whitelabel_config['remove_links'] ) && true === $this->modula_whitelabel_config['remove_links'] ) {
			return '';
		} elseif ( isset( $this->modula_whitelabel_config['documentation'] ) ) {
			return $this->modula_whitelabel_config['documentation'];
		}
		return $doc;
	}

	/**
	 * Whitelabel contact
	 *
	 * @since 1.0.0
	 *
	 * @param string $cont contact.
	 *
	 * @return string $cont
	 */
	public function modula_contact( $cont ) {

		if ( isset( $this->modula_whitelabel_config['remove_links'] ) && true === $this->modula_whitelabel_config['remove_links'] ) {
			return '';
		} elseif ( isset( $this->modula_whitelabel_config['contact'] ) ) {
			return $this->modula_whitelabel_config['contact'];
		}
		return $cont;
	}

	/**
	 * Whitelabel elementor name gallery
	 *
	 * @since 1.0.0
	 *
	 * @param string $name elementor block name.
	 *
	 * @return string $name
	 */
	public function change_elementor_name( $name ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			return esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['gallery']['name'] ) ) {
			return esc_html( $this->modula_whitelabel_config['gallery']['name'] );
		}
		return $name;
	}

	/**
	 * Whitelabel elementor name albums
	 *
	 * @since 1.0.0
	 *
	 * @param string $name elementor block albums name.
	 *
	 * @return string $name
	 */
	public function change_elementor_name_albums( $name ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			return esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['albums']['name'] ) ) {
			return esc_html( $this->modula_whitelabel_config['albums']['name'] );
		}
		return $name;
	}

	/**
	 * Whitelabel beaver construct gallery
	 *
	 * @since 1.0.0
	 *
	 * @param  array $beaver beaver name.
	 *
	 * @return array $beaver
	 */
	public function beaver_block_construct( $beaver ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['name'] = esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['gallery']['name'] ) ) {
			$beaver['name'] = esc_html( $this->modula_whitelabel_config['gallery']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['category'] = esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['beaver_block']['category'] ) ) {
			$beaver['category'] = esc_html( $this->modula_whitelabel_config['beaver_block']['category'] );
		}

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['description'] = esc_html( "A block for {$this->modula_whitelabel_config['brand']}" );
		} elseif ( isset( $this->modula_whitelabel_config['beaver_block']['description'] ) ) {
			$beaver['description'] = esc_html( $this->modula_whitelabel_config['beaver_block']['description'] );
		}

		return $beaver;
	}

	/**
	 * Whitelabel beaver module gallery
	 *
	 * @since 1.0.0
	 *
	 * @param array $beaver beaver modula name.
	 *
	 * @return array $beaver
	 */
	public function beaver_module( $beaver ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['modula_gallery']['title'] = esc_html( "{$this->modula_whitelabel_config['brand']} Gallery" );
		} elseif ( isset( $this->modula_whitelabel_config['gallery']['name'] ) ) {
			$beaver['modula_gallery']['title'] = esc_html( $this->modula_whitelabel_config['gallery']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['modula_gallery']['sections']['modula_gallery_section']['title']                                    = esc_html( "Select the {$this->modula_whitelabel_config['brand']} Gallery you want" );
			$beaver['modula_gallery']['sections']['modula_gallery_section']['fields']['modula_gallery_select']['label'] = esc_html( "Select the {$this->modula_whitelabel_config['brand']} Gallery you want" );
		} elseif ( isset( $this->modula_whitelabel_config['beaver_block']['section'] ) ) {
			$beaver['modula_gallery']['sections']['modula_gallery_section']['title']                                    = esc_html( $this->modula_whitelabel_config['beaver_block']['section'] );
			$beaver['modula_gallery']['sections']['modula_gallery_section']['fields']['modula_gallery_select']['label'] = esc_html( $this->modula_whitelabel_config['beaver_block']['section'] );
		}

		return $beaver;
	}

	/**
	 * Whitelabel beaver construct albums
	 *
	 * @since 1.0.0
	 *
	 * @param  array $beaver beaver for albums.
	 *
	 * @return array $beaver
	 */
	public function beaver_block_construct_albums( $beaver ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['name'] = esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['albums']['name'] ) ) {
			$beaver['name'] = esc_html( $this->modula_whitelabel_config['albums']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['category'] = esc_html( $this->modula_whitelabel_config['brand'] );
		} elseif ( isset( $this->modula_whitelabel_config['beaver_block']['category'] ) ) {
			$beaver['category'] = esc_html( $this->modula_whitelabel_config['beaver_block']['category'] );
		}

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['description'] = esc_html( "A block for {$this->modula_whitelabel_config['brand']}" );
		} elseif ( isset( $this->modula_whitelabel_config['beaver_block']['description'] ) ) {
			$beaver['description'] = esc_html( $this->modula_whitelabel_config['beaver_block']['description'] );
		}

		return $beaver;
	}

	/**
	 * Whitelabel beaver module albums
	 *
	 * @since 1.0.0
	 *
	 * @param array $beaver beaver module for albums.
	 *
	 * @return array $beaver
	 */
	public function beaver_module_albums( $beaver ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['modula_gallery']['title'] = esc_html( "{$this->modula_whitelabel_config['brand']} Albums" );
		} elseif ( isset( $this->modula_whitelabel_config['albums']['name'] ) ) {
			$beaver['modula_gallery']['title'] = esc_html( $this->modula_whitelabel_config['albums']['name'] );
		}

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			$beaver['modula_gallery']['sections']['modula_gallery_section']['title']                                    = esc_html( "Select the {$this->modula_whitelabel_config['brand']} Albums you want" );
			$beaver['modula_gallery']['sections']['modula_gallery_section']['fields']['modula_gallery_select']['label'] = esc_html( "Select the {$this->modula_whitelabel_config['brand']} Albums you want" );
		} elseif ( isset( $this->modula_whitelabel_config['beaver_block']['section'] ) ) {
			$beaver['modula_gallery']['sections']['modula_gallery_section']['title']                                    = esc_html( $this->modula_whitelabel_config['beaver_block']['section'] );
			$beaver['modula_gallery']['sections']['modula_gallery_section']['fields']['modula_gallery_select']['label'] = esc_html( $this->modula_whitelabel_config['beaver_block']['section'] );
		}

		return $beaver;
	}

	/**
	 * Whitelabel getter text
	 *
	 * @since 1.0.0
	 *
	 * @param string $translation replacement.
	 * @param string $text        not used.
	 * @param string $domain      text domain.
	 *
	 * @return string $text
	 */
	public function modula_getter_text( $translation, $text, $domain ) {

		if ( isset( $this->modula_whitelabel_config['brand'] ) && false !== $this->modula_whitelabel_config['brand'] ) {
			if ( strpos( $domain, 'modula' ) === 0 ) {
				$translation = str_replace( 'Modula', esc_html( $this->modula_whitelabel_config['brand'] ), $translation );
			}
		} elseif ( isset( $this->modula_whitelabel_config['gallery']['name'] ) ) {
			if ( strpos( $domain, 'modula' ) === 0 ) {
				$translation = str_replace( 'Modula', esc_html( $this->modula_whitelabel_config['gallery']['name'] ), $translation );
			}
		}
		return $translation;
	}
}
