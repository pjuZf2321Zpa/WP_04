<?php
namespace Modula_Pro\Extensions\Slideshow;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Slideshow class for Modula Pro plugin.
 */
class Slideshow {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Filter Modula Slideshow Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'modula_slideshow_tabs' ), 99 );

		// Filter Modula Slideshow Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_slideshow_fields' ) );

		// Add defaults
		add_filter( 'modula_lite_default_settings', array( $this, 'set_defaults' ) );

		add_filter( 'modula_fancybox_options', array( $this, 'modula_slideshow_fancybox_options' ), 15, 2 );

		add_filter( 'modula_gallery_settings', array( $this, 'modula_slideshow_config' ), 10, 2 );
		add_filter( 'modula_link_gallery_settings', array( $this, 'modula_link_slideshow_config' ), 10, 2 );

		add_filter( 'modula_extra_lightboxes', array( $this, 'extra_lightboxes_options' ), 16, 2 );

		add_filter( 'modula_migrate_gallery_data', array( $this, 'modula_slidehsow_migrator_data' ), 25, 3 );

		new Enqueue();
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Slideshow object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Slideshow ) ) {
			self::$instance = new Slideshow();
		}

		return self::$instance;
	}


	/**
	 * Add extra tab for Modula Slideshow
	 *
	 * @param $tabs
	 *
	 * @return mixed
	 */
	public function modula_slideshow_tabs( $tabs ) {

		if ( ! isset( $tabs['slideshow'] ) ) {
			$tabs['slideshow'] = array(
				'label'       => esc_html__( 'Slideshow', 'modula-pro' ),
				'title'       => esc_html__( 'Lightbox Slideshow Settings', 'modula-pro' ),
				'description' => esc_html__( 'Here you can modify the settings for lightbox slideshow like : autoplay / autoplay time / pause on hover', 'modula-pro' ),
				'icon'        => 'dashicons dashicons-images-alt2',
				'priority'    => 110,
			);
		}

		unset( $tabs['slideshow']['badge'] );

		return $tabs;
	}

	/**
	 * Add fields for Modula Slideshow
	 *
	 * @param $fields
	 *
	 * @return mixed
	 */
	public function modula_slideshow_fields( $fields ) {

		if ( ! isset( $fields['slideshow'] ) || ! is_array( $fields['slideshow'] ) ) {
			$fields['slideshow'] = array();
		}

		// Add slideshow settings
		$fields['slideshow'] = array(
			'enable_slideshow' => array(
				'name'      => esc_html__( 'Slideshow', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 10,
				'children'  => array( 'enable_autoplay', 'pause_on_hover', 'slideshow_speed' ),
				'data_type' => 'bool',
			),
			'enable_autoplay'  => array(
				'name'      => esc_html__( 'Autoplay', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 11,
				'data_type' => 'bool',
			),
			'pause_on_hover'   => array(
				'name'      => esc_html__( 'Pause slideshow on hover', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 12,
				'data_type' => 'bool',
			),
			'slideshow_speed'  => array(
				'name'      => esc_html__( 'Time between slides', 'modula-pro' ),
				'type'      => 'ui-slider',
				'is_child'  => true,
				'min'       => 1000,
				'max'       => 30000,
				'step'      => 1000,
				'default'   => 5000,
				'priority'  => 13,
				'data_type' => 'number',
			),
		);

		return $fields;
	}


	/**
	 * Set defaults for Modula Slideshow
	 *
	 * @param $defaults
	 *
	 * @return mixed
	 */
	public function set_defaults( $defaults ) {
		$defaults['enable_slideshow'] = 0;
		$defaults['enable_autoplay']  = 0;
		$defaults['pause_on_hover']   = 0;
		$defaults['slideshow_speed']  = 5000;

		return $defaults;
	}


	/**
	 * Add extra options to fancybox for slideshow functionality
	 *
	 * @param $ligtboxes_options
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function modula_slideshow_fancybox_options( $fancybox_options, $settings ) {

		$autoplay    = false;
		$hover_pause = false;
		if ( isset( $settings['enable_autoplay'] ) && 1 === (int) $settings['enable_autoplay'] ) {
			$autoplay = true;
		}
		if ( isset( $settings['pause_on_hover'] ) && 1 === (int) $settings['pause_on_hover'] ) {
			$hover_pause = true;
		}

		if ( isset( $settings['enable_slideshow'] ) && 1 === (int) $settings['enable_slideshow'] ) {
			$fancybox_options['Toolbar']['display']['right'][] = 'slideshow';
			$fancybox_options['Slideshow']['playOnStart']      = $autoplay;
			$fancybox_options['Slideshow']['pauseOnHover']     = $hover_pause;
			$fancybox_options['Slideshow']['timeout']          = absint( $settings['slideshow_speed'] );
			// Only wrap slides when Loop slides is on — do not force infinite for slideshow alone.
			if ( isset( $settings['loop_lightbox'] ) && 1 === absint( $settings['loop_lightbox'] ) ) {
				$fancybox_options['Carousel']['infinite'] = true;
			}
		}

		return $fancybox_options;
	}


	public function modula_slideshow_config( $js_config, $settings ) {
		$js_config['options']['lightbox'] = $settings['lightbox'];

		if ( isset( $settings['enable_slideshow'] ) ) {
			$js_config['enableSlideshow'] = $settings['enable_slideshow'];
		}

		if ( isset( $settings['enable_autoplay'] ) ) {
			$js_config['enableAutoplay'] = esc_attr( $settings['enable_autoplay'] );
		}

		if ( isset( $settings['slideshow_speed'] ) ) {
			$js_config['slideshowSpeed'] = $settings['slideshow_speed'];
		}

		if ( isset( $settings['pause_on_hover'] ) ) {
			$js_config['pauseOnHover'] = esc_attr( $settings['pause_on_hover'] );
		}

		return $js_config;
	}

	/**
	 * Add config for modula-link shortcode
	 *
	 * @param $js_config
	 * @param $settings
	 *
	 * @return mixed
	 *
	 * @since 1.0.2
	 */
	public function modula_link_slideshow_config( $js_config, $settings ) {

		if ( isset( $settings['enable_slideshow'] ) ) {
			$js_config['options']['enableSlideshow'] = $settings['enable_slideshow'];
		}

		if ( isset( $settings['enable_autoplay'] ) ) {
			$js_config['options']['enableAutoplay'] = esc_attr( $settings['enable_autoplay'] );
		}

		if ( isset( $settings['slideshow_speed'] ) ) {
			$js_config['options']['slideshowSpeed'] = $settings['slideshow_speed'];
		}

		if ( isset( $settings['pause_on_hover'] ) ) {
			$js_config['options']['pauseOnHover'] = esc_attr( $settings['pause_on_hover'] );
		}

		return $js_config;
	}


	/**
	 * Add functionality to extra lightboxes
	 *
	 * @param $lightboxes_options
	 * @param $settings
	 *
	 * @since 1.0.2
	 *
	 * @return mixed
	 */
	public function extra_lightboxes_options( $lightboxes_options, $settings ) {

		$autoplay    = false;
		$hover_pause = false;
		if ( isset( $settings['enable_autoplay'] ) && 1 === (int) $settings['enable_autoplay'] ) {
			$autoplay = true;
		}
		if ( isset( $settings['pause_on_hover'] ) && 1 === (int) $settings['pause_on_hover'] ) {
			$hover_pause = true;
		}
		if ( isset( $settings['enable_slideshow'] ) && 1 === (int) $settings['enable_slideshow'] ) {
			if ( 'fancybox' === $settings['lightbox'] ) {
				$lightboxes_options['lightboxes']['fancybox']['options']['Slideshow']['playOnStart']  = $autoplay;
				$lightboxes_options['lightboxes']['fancybox']['options']['Slideshow']['pauseOnHover'] = $hover_pause;
				$lightboxes_options['lightboxes']['fancybox']['options']['Slideshow']['timeout']      = absint( $settings['slideshow_speed'] );
				if ( isset( $settings['loop_lightbox'] ) && 1 === absint( $settings['loop_lightbox'] ) ) {
					$lightboxes_options['lightboxes']['fancybox']['options']['Carousel']['infinite'] = true;
				}
			}
		}

		return $lightboxes_options;
	}

	/**
	 * Add Modula Slidehsow migrator data
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 * @since 1.0.3
	 */
	public function modula_slidehsow_migrator_data( $modula_settings, $guest_settings, $source ) {

		if ( isset( $source ) ) {
			switch ( $source ) {
				case 'envira':
					if ( isset( $guest_settings['config']['slideshow'] ) && 1 === (int) $guest_settings['config']['slideshow'] ) {
						$modula_settings['enable_slideshow'] = 1;
					}

					if ( isset( $guest_settings['config']['autoplay'] ) && 1 === (int) $guest_settings['config']['autoplay'] ) {
						$modula_settings['enable_autoplay'] = 1;
					}

					if ( isset( $guest_settings['config']['slideshow_hover'] ) && 1 === (int) $guest_settings['config']['slideshow_hover'] ) {
						$modula_settings['pause_on_hover'] = 1;
					}

					if ( isset( $guest_settings['config']['ss_speed'] ) && '' !== $guest_settings['config']['ss_speed'] ) {
						$modula_settings['slideshow_speed'] = $guest_settings['config']['ss_speed'];
					}
					break;
			}
		}

		return $modula_settings;
	}
}
