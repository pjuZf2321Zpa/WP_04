<?php
namespace Modula_Pro\Extensions\Slideshow;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/slideshow';

	public function __construct() {
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'modula_slideshow_backbone' ), 40 );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'modula_slideshow_backbone' ), 40 );

		add_action( 'wp_head', array( $this, 'output_css' ) );
	}

	/**
	 * Enqueue our slideshow conditions
	 *
	 * @since 1.0.2
	 */
	public function modula_slideshow_backbone() {
		wp_enqueue_script( 'modula-slideshow-conditions', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-slideshow-conditions.js', array( 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
	}

	public function output_css() {
		echo '<style id="modula-slideshow">.modula-toolbar {position: absolute;top: 0;right: 60px;z-index: 9999999;display: block;opacity: 1;}.modula-toolbar span.modula-play {margin-right: 10px;}.modula-toolbar span {cursor:pointer;color: #fff;display:inline-block;}.modula-toolbar span svg {width: 15px;}.modula-toolbar.modula-is-playing span.modula-play {opacity: .5;}.modula-toolbar:not(.modula-is-playing) span.modula-pause {opacity: .5;}</style>';
	}
}
