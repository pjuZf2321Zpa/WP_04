<?php
namespace Modula_Pro\Extensions\Advanced_Shortcodes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/advanced-shortcodes';

	public function __construct() {
		add_action( 'modula_extra_scripts', array( $this, 'global_filters' ) );
	}
	/**
	 * Enqueue Modula global filters script
	 */
	public function global_filters() {
		wp_register_script( 'modula-global-filters', \MODULA_PRO_URL . $this->extension_url . '/assets/js/global-filters.min.js', array( 'modula' ), \MODULA_PRO_VERSION, true );
	}
}
