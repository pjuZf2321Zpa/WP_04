<?php

$gallery_link = get_option( 'mas_gallery_link' );
?>
<style>
	.modula-ads-table th {
		min-width:250px;
	}
</style>
<div class="row">

	<form method="post" action="options.php">
		<?php settings_fields( 'mas_gallery_link' ); ?>
		<table class="form-table modula-ads-table">
			<tbody>
			<tr valign="top">
				<th scope="row" valign="top">
					<?php esc_html_e( 'Gallery link attribute', 'modula-pro' ); ?>
				</th>
				<td>
					<input id="mas_gallery_link" name="mas_gallery_link" type="text" class="regular-text" value="<?php echo esc_attr( $gallery_link ); ?>" />
					<p><?php echo esc_html__( 'Add this shortcode', 'modula-pro' ); ?> <input type="text" readonly value="<?php echo esc_attr( '[modula_all_galleries]' ); ?>"> <?php echo esc_html__( 'on the page/post/product you want to display your galleries.  Then add at the end of that url', 'modula-pro' ); ?> :<i> <?php echo '?' . $gallery_link . esc_html__( '=[gallery_id], where [gallery_id] is the ID of the gallery.', 'modula-pro' ); ?> </i> </p>
				</td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
</div>
