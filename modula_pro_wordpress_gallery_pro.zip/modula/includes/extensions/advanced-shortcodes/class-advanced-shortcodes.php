<?php
namespace Modula_Pro\Extensions\Advanced_Shortcodes;

use Modula_Pro\Extensions\Advanced_Shortcodes\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Advanced Shortcodes class for Modula Pro plugin.
 */
class Advanced_Shortcodes {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( Settings::class, 'get_instance' ), 25 );
		add_shortcode( 'modula_all_galleries', array( $this, 'modula_all_galleries' ) );
		add_shortcode( 'modula_filters', array( $this, 'modula_output_filters' ) );

		add_filter( 'modula_uninstall_db_options', array( $this, 'advanced_shortcodes_uninstall' ), 20, 1 );

		add_filter( 'modula_debug_information', array( $this, 'debug_info' ), 50 );

		new Enqueue();
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Advanced_Shortcodes object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Advanced_Shortcodes ) ) {
			self::$instance = new Advanced_Shortcodes();
		}

		return self::$instance;
	}

	/**
	 * Shortcode for displaying all galleries or galleries based on gallery_id request
	 */
	public function modula_all_galleries() {

		$output       = '';
		$gallery_link = get_option( 'mas_gallery_link' );

		if ( ! $gallery_link ) {
			$gallery_link = 'gallery_id';
		}

		if ( isset( $_REQUEST[ $gallery_link ] ) ) {
			$gallery_id = (int) $_REQUEST[ $gallery_link ];

			$gallery_args = array(
				'post_type' => 'modula-gallery',
				'post__in'  => array( $gallery_id ),
				'order'     => 'DESC',
			);
		} else {
			$gallery_args = array(
				'post_type'      => 'modula-gallery',
				'posts_per_page' => - 1,
				'orderby'        => 'menu_order',
				'order'          => 'DESC',
			);
		}

		$galleries = new \WP_Query( $gallery_args );

		if ( $galleries->have_posts() ) {
			while ( $galleries->have_posts() ) {
				$galleries->the_post();
				$id = get_the_ID();

				if ( ! is_admin() ) {
					if ( post_password_required( $id ) ) {
						$output .= get_the_password_form( $id );
					} else {
						$output .= do_shortcode( '[modula id="' . esc_attr( $id ) . '"]' );
					}
				}
			}
			wp_reset_postdata();
		} elseif ( isset( $gallery_id ) ) {
				$output .= ( $galleries->found_posts == 0 ) ? __( 'No galleries found matching id', 'modula-pro' ) . ' <strong>' . esc_html( $gallery_id ) . '</strong>' : '';
		} else {
			$output .= __( 'No galleries found.', 'modula-pro' );
		}

		return $output;
	}

	/**
	 * Shortcode to output only the filters
	 */

	public function modula_output_filters( $atts ) {

		$gallery_link = get_option( 'mas_gallery_link' );

		$shortcode_atts = shortcode_atts(
			array(
				'gallery_id' => false,
			),
			$atts
		);

		$filters_array = array();

		$gallery_args = array(
			'post_type'      => 'modula-gallery',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'DESC',
		);

		$gallery_id = ( isset( $_REQUEST[ $gallery_link ] ) ) ? $_REQUEST[ $gallery_link ] : $shortcode_atts['gallery_id'];

		// Check to see if $gallery_id is not false
		if ( $gallery_id ) {
			$gallery_args['post__in'] = array( $gallery_id );
		}

		$galleries = new WP_Query( $gallery_args );

		if ( $galleries->have_posts() ) {
			while ( $galleries->have_posts() ) {
				$galleries->the_post();
				$modula_settings = get_post_meta( get_the_ID(), 'modula-settings', true );
				$filters         = $modula_settings['filters'];
				if ( $filters ) {
					foreach ( $filters as $filter ) {
						if ( ! in_array( $filter, $filters_array ) ) {
							$filters_array[] = $filter;
						}
					}
				}
			}
			wp_reset_postdata();
		}

		$html  = '<div class="modula modula-gallery modula-gallery-filters-shortcode"><div class="filters styled-menu menu--default "><ul class="menu__list">';
		$html .= '<li class="menu__item"><a data-filter="all" href="#" class="selected">All</a></li>';

		foreach ( $filters_array as $filter ) {
			$html .= '<li class="menu__item"><a class="menu__link" data-filter="' . esc_attr( urldecode( sanitize_title( $filter ) ) ) . '" href="#jtg-filter-' . esc_attr( urldecode( sanitize_title( $filter ) ) ) . '">' . esc_html( $filter ) . '</a></li>';
		}

		$html .= '</ul></div></div>';

		return $html;
	}


	/**
	 * Uninstall process
	 *
	 * @param $db_options
	 *
	 * @return mixed
	 *
	 * @since 1.0.2
	 */
	public function advanced_shortcodes_uninstall( $db_options ) {

		$db_options[] = 'mas_gallery_link';

		return $db_options;
	}

	/**
	 * Add debug info
	 *
	 * @param $info
	 *
	 * @return mixed
	 * @since 1.0.3
	 */
	public function debug_info( $info ) {
		$link_att = get_option( 'mas_gallery_link' );

		$info['mas_version'] = array(
			'label' => __( 'Modula Advanced Shortcodes versions', 'modula-pro' ),
			'value' => esc_html( \MODULA_PRO_VERSION ),
			'debug' => esc_html( 'MAS version' . \MODULA_PRO_VERSION ),
		);

		$info['mas_version'] = array(
			'label' => __( 'Link attribute', 'modula-pro' ),
			'value' => ( $link_att && '' !== $link_att ) ? esc_html( $link_att ) : __( 'No attribute specified', 'modula-pro' ),
			'debug' => ( $link_att && '' !== $link_att ) ? esc_html( $link_att ) : 'No attribute specified',
		);

		return $info;
	}
}
