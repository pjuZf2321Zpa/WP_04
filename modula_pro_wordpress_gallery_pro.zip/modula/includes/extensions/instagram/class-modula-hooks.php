<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Modula_Hooks {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		add_action( 'admin_init', array( $this, 'save_request_response' ) );
		add_action( 'admin_init', array( $this, 'check_refresh_token' ) );
		add_filter( 'modula_settings_field_sanitization', array( $this, 'sanitize_settings' ), 20, 4 );
		add_filter( 'modula_gallery_fields', array( $this, 'instagram_fields' ) );
	}

	public function admin_enqueue_scripts() {
		$screen = get_current_screen();
		if ( 'modula-gallery_page_modula' !== $screen->base ) {
			return;
		}
	}

	//  @might be deprecated
	public function save_request_response() {
		if ( empty( $_GET['action'] ) || 'save_modula_instagram_token' !== $_GET['action'] ) {
			return;
		}
		$access_token = isset( $_GET['accessToken'] ) ? sanitize_text_field( wp_unslash( $_GET['accessToken'] ) ) : '';
		$expires_in   = isset( $_GET['expiresIn'] ) ? absint( $_GET['expiresIn'] ) : 0;

		OAuth::get_instance()->save_access_token( $access_token );
		OAuth::get_instance()->save_expiry_date( $expires_in );

		wp_safe_redirect( admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media' ) );
	}

	public function check_refresh_token() {
		$expiry_date = OAuth::get_instance()->get_expiry_date();

		if ( false === $expiry_date || ( absint( $expiry_date ) - time() ) <= ( 86400 * 30 * 2 ) ) {
			OAuth::get_instance()->refresh_token();
		}
	}

	public function sanitize_settings( $sanitized_value, $value, $field_id ) {
		if ( 'syncWithInstagram' === $field_id ) {
			return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
		}

		return $sanitized_value;
	}

	public function instagram_fields( $fields ) {
		$fields['misc']['syncWithInstagram'] = array(
			'id'        => 'syncWithInstagram',
			'type'      => 'toggle',
			'name'      => __( 'Sync with Instagram', 'modula-pro' ),
			'desc'      => __( 'Sync your Modula galleries with your Instagram account', 'modula-pro' ),
			'default'   => 0,
			'data_type' => 'bool',
		);
		return $fields;
	}
}
