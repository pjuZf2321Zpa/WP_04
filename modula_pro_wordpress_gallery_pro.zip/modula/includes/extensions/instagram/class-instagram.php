<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MODULA_PRO_INSTAGRAM_DEBUG', true );
define( 'MODULA_PRO_INSTAGRAM_API_URL', 'https://graph.instagram.com' );
define( 'MODULA_PRO_INSTAGRAM_AUTH_URL', 'https://auth.wp-modula.com' );

class Instagram {
	public static $instance;
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Instagram ) ) {
			self::$instance = new Instagram();
		}
		return self::$instance;
	}

	public function __construct() {
		require_once __DIR__ . '/abilities/class-instagram-executor.php';
		require_once __DIR__ . '/abilities/class-provider.php';
		\Modula_Pro\Extensions\Instagram\Abilities\Provider::boot();

		new General_Scripts();
		Instagram_Media_Downloader::get_instance();
		Instagram_Sync::get_instance();
		Instagram_Media_Sync::get_instance();
		new Rest_Api();
		new Modula_Hooks();
		new Instagram_Connector();

		if ( is_admin() ) {
			new Admin\Settings_Editor_Integration();
		}
	}
}
