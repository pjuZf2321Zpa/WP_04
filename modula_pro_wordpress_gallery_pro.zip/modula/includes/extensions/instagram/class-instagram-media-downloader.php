<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Instagram_Media_Downloader extends WP_Background_Process {
	protected $prefix        = 'modula_instagram';
	protected $action        = 'process_instagram_media';
	protected $cron_interval = 5;

	private $errors_key    = 'modula_instagram_error_images';
	private $processed_key = 'modula_processed_images_';

	private $batch_id;
	private $gallery_id;

	private static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Instagram_Media_Downloader ) ) {
			self::$instance = new Instagram_Media_Downloader();
		}
		return self::$instance;
	}

	/**
	 * Task method.
	 *
	 * This method should handle each URL processing.
	 *
	 * @param mixed $url The URL to be processed.
	 * @return mixed
	 */
	protected function task( $image ) {
		$errors = get_post_meta( $image['gallery_id'], $this->errors_key, true );
		if ( isset( $errors[ $image['id'] ] ) && 1 > absint( $errors[ $image['id'] ] ) ) {
			return false;
		}

		$upload = Image_Handler::get_instance()->upload_item_from_url( $image );

		if ( ! is_array( $errors ) ) {
			$errors = array();
		}

		if ( is_wp_error( $upload ) ) {
			if ( isset( $errors[ $image['id'] ] ) ) {
				++$errors[ $image['id'] ];
				update_post_meta( $image['gallery_id'], $this->errors_key, $errors );
				return false;
			}
			$errors[ $image['id'] ] = 1;
			update_post_meta( $image['gallery_id'], $this->errors_key, $errors );
			return $image;
		}

		if ( isset( $errors[ $image['id'] ] ) ) {
			unset( $errors[ $image['id'] ] );
			update_post_meta( $image['gallery_id'], $this->errors_key, $errors );
		}

		$image['attachment_id']  = absint( $upload );
		$image['attachment_url'] = wp_get_attachment_url( $image['attachment_id'] );

		// Get the batch_id from the image data
		$batch_id = isset( $image['batch_id'] ) ? $image['batch_id'] : 'default_batch';

		// Retrieve processed images for the gallery
		$processed_images = get_site_option( $this->processed_key . $image['gallery_id'], array() );

		// Initialize the 'imported_items' array if it doesn't exist
		if ( ! isset( $processed_images['imported_items'] ) ) {
			$processed_images['imported_items'] = array();
		}

		// Initialize the batch array if it doesn't exist
		if ( ! isset( $processed_images['imported_items'][ $batch_id ] ) ) {
			$processed_images['imported_items'][ $batch_id ] = array();
		}

		// Add the image to the current batch
		$processed_images['imported_items'][ $batch_id ][ $image['id'] ] = $image;

		// Remove the image from 'remaining_items' if it's there
		if ( isset( $processed_images['remaining_items'][ $image['id'] ] ) ) {
			unset( $processed_images['remaining_items'][ $image['id'] ] );
		}

		$this->gallery_id = $image['gallery_id'];
		$this->batch_id   = isset( $image['batch_id'] ) ? $image['batch_id'] : 'default_batch';

		// Save the updated processed images back to the site option
		$this->update( $this->processed_key . $image['gallery_id'], $processed_images );

		return false;
	}


	/**
	 * Get the status of the queue.
	 *
	 * @return array The status of the background process, including remaining tasks.
	 */
	public function get_progress( $gallery_id = 0 ) {
		$gallery_id      = absint( $gallery_id );
		$current_batches = $this->get_batches();
		$items           = get_site_option(
			$this->processed_key . $gallery_id,
			array(
				'imported_items'  => array(),
				'remaining_items' => array(),
			)
		);

		// Flatten 'imported_items'
		$flattened_imported_items = array();
		foreach ( $items['imported_items'] as $batch_id => $batch_items ) {
			foreach ( $batch_items as $image_id => $image ) {
				$flattened_imported_items[ $image_id ] = $image;
			}
		}

		// Combine remaining items and imported items
		$total_items = array_merge( $items['remaining_items'], $flattened_imported_items );

		$status = array(
			'total_items'     => count( $total_items ),
			'current_batches' => count( $current_batches ),
			'remaining'       => count( $items['remaining_items'] ),
			'complete'        => false,
			'all_items'       => $total_items,
			'remaining_items' => array_values( $items['remaining_items'] ),
			'imported_items'  => array_values( $flattened_imported_items ),
		);

		$status['complete'] = count( $status['all_items'] ) > 0 && 0 === $status['remaining'];
		return array_merge( $items, $status );
	}

	public function start( $gallery_id ) {
		$batches         = $this->get_batches();
		$items           = get_site_option( $this->processed_key . $gallery_id, false );
		$gallery_batches = array(
			'completed'        => false,
			'remaining_items'  => array(),
			'imported_items'   => isset( $items['imported_items'] )
			? $items['imported_items']
			: array(),
			'current_batch_id' => $this->batch_id,
			'gallery_id'       => $gallery_id,
		);

		foreach ( $batches as $batch ) {
			foreach ( $batch->data as $item ) {
				if ( $item['gallery_id'] === $gallery_id ) {
					$gallery_batches['remaining_items'][ $item['id'] ] = $item;
				}
			}
		}

		$this->update( $this->processed_key . $gallery_id, $gallery_batches );

		$this->dispatch();
	}

	/**
	 * Complete method.
	 *
	 * Called when all tasks are finished processing.
	 */
	protected function complete() {
		// Retrieve processed images for the gallery
		$state = get_site_option( $this->processed_key . $this->gallery_id, array() );

		// Check if the current batch exists
		if ( isset( $state['imported_items'][ $this->batch_id ] ) ) {
			$current_batch_images = $state['imported_items'][ $this->batch_id ];

			// Add current batch images to the gallery
			Image_Handler::get_instance()->add_items_to_gallery( $current_batch_images );
		}

		// Update the state to mark the process as completed
		$state['completed'] = true;
		$this->update( $this->processed_key . $this->gallery_id, $state );

		parent::complete();
	}
}
