<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OAuth {

	private static $instance = null;

	public $access_token = 'modula_instagram_access_token';
	public $expiry_date  = 'modula_instagram_expiry_date';

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof OAuth ) ) {
			self::$instance = new OAuth();
		}
		return self::$instance;
	}

	public function get_access_token() {
		return get_option( $this->access_token, false );
	}

	public function save_access_token( $access_token ) {
		update_option( $this->access_token, $access_token );
	}

	public function get_expiry_date() {
		return get_option( $this->expiry_date, false );
	}

	public function save_expiry_date( $expiry_date ) {
		update_option( $this->expiry_date, absint( $expiry_date ) + time() );
	}

	public function is_token_expired() {

		$expiry_date = $this->get_expiry_date();

		if ( empty( $expiry_date ) ) {
			return true;
		}

		if ( absint( $expiry_date ) < absint( time() ) ) {
			return true;
		}

		return false;
	}

	public function create_request_url() {
		return \MODULA_PRO_INSTAGRAM_AUTH_URL . '/instagram?redirectUrl=' . rawurlencode( admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&action=save_modula_instagram_token' ) );
	}

	public function refresh_token() {
		if ( ! $this->get_access_token() ) {
			return;
		}

		// Prepare the request data
		$data = wp_json_encode(
			array(
				'accessToken' => $this->get_access_token(),
			)
		);

		$url = \MODULA_PRO_INSTAGRAM_AUTH_URL . '/instagram/refresh-token';

		// Send the request
		$response = wp_remote_post(
			$url,
			array(
				'body'      => $data,
				'timeout'   => 15,
				'sslverify' => true,
				'headers'   => array(
					'Content-Type' => 'application/json',
				),
			)
		);

		// Check for errors in the response
		if ( is_wp_error( $response ) || 201 !== wp_remote_retrieve_response_code( $response ) ) {
			return;
		}

		// Decode the response body
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		// Check if accessToken exists in the response data
		if ( isset( $data['accessToken'] ) ) {
			$this->save_access_token( $data['accessToken'] );
		}
		if ( isset( $data['expiresIn'] ) ) {
			$this->save_expiry_date( $data['expiresIn'] );
		}
	}

	public function disconnect_token() {

		delete_option( $this->access_token );
		delete_option( $this->expiry_date );

		do_action( 'modula_instagram_token_disconnect' );
		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Disconnected', 'modula-pro' ),
			),
			200
		);
	}

	public function turn_off_sync() {
	}
}
