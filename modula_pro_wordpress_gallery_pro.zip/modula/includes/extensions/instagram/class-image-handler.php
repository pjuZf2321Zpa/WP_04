<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Image_Handler {

	private static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Image_Handler ) ) {
			self::$instance = new Image_Handler();
		}
		return self::$instance;
	}

	public function image_upload_request( $request ) {
		$data = $request->get_json_params();

		$images_data = $data['images_data'];
		$gallery_id  = $data['gallery_id'];

		if ( empty( $images_data ) || ! is_array( $images_data ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing images data.', 'modula-pro' ),
				),
				400
			);
		}

		if ( ! isset( $gallery_id ) || 0 === absint( $gallery_id ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing gallery id.', 'modula-pro' ),
				),
				400
			);
		}

		$imd = Instagram_Media_Downloader::get_instance();

		$progress = $imd->get_progress( $gallery_id );
		if ( ! empty( $progress['remaining_items'] ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'A process is already running for this gallery.', 'modula-pro' ),
				),
				400
			);
		}

		$batch_id = 'batch_' . time();

		foreach ( $images_data as $image ) {
			$data = array(
				'id'         => $image['id'],
				'url'        => $image['url'],
				'gallery_id' => $gallery_id,
				'author_id'  => get_current_user_id(),
				'type'       => $image['type'],
				'batch_id'   => $batch_id,
			);

			if ( 'video' === $image['type'] ) {
				$data['video_url']     = $image['url'];
				$data['thumbnail_url'] = $image['thumbnail_url'];
			}

			$imd->push_to_queue( $data );
		}

		$imd->save()->start( $gallery_id );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Images added to queue.', 'modula-pro' ),
			),
			200
		);
	}

	public function image_upload_status( $request ) {

		$gallery_id = $request->get_param( 'gallery_id' );

		if ( ! isset( $gallery_id ) || 0 === absint( $gallery_id ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing gallery ID.', 'modula-pro' ),
				),
				400
			);
		}

		$imd = Instagram_Media_Downloader::get_instance();

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => $imd->get_progress( $gallery_id ),
			),
			200
		);
	}

	public function upload_item_from_url( $image ) {
		if ( ! isset( $image['url'] ) || '' === $image['url'] || ! filter_var( $image['url'], FILTER_VALIDATE_URL ) ) {
			return new \WP_Error( 'undefined_url', __( 'Undefined or invalid image URL.', 'modula-pro' ) );
		}

		if ( ! isset( $image['id'] ) || 0 === absint( $image['id'] ) ) {
			return new \WP_Error( 'undefined_id', __( 'Undefined image Instagram ID.', 'modula-pro' ) );
		}

		// All editor, background and ability importers share the provider identity lock.
		global $wpdb;
		$lock = 'modula_ig_' . get_current_blog_id() . '_' . md5( (string) $image['id'] );
		if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) ) {
			return new \WP_Error( 'instagram_media_busy', __( 'This Instagram image is already being imported.', 'modula-pro' ) );
		}
		try {
			return $this->upload_locked_item( $image );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	/** Lookup and insertion must use the same cross-process identity lock. */
	private function upload_locked_item( $image ) {
		$attachment_id = $this->get_image_by_instagram_id( $image['id'] );
		if ( $attachment_id ) {
			return $attachment_id;
		}

		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$tmp = download_url( $image['url'] );

		if ( is_wp_error( $tmp ) ) {
			return new \WP_Error( 'download_failed', $tmp->get_error_message() );
		}

		$url_path  = wp_parse_url( $image['url'], PHP_URL_PATH );
		$file_name = basename( $url_path );

		$file_array = array(
			'name'     => $file_name,
			'tmp_name' => $tmp,
		);

		$file_type = wp_check_filetype( basename( $file_array['name'] ) );
		if ( ! in_array( $file_type['type'], array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4' ), true ) ) {
			return new \WP_Error( 'invalid_file_type', __( 'Invalid image file type.', 'modula-pro' ) );
		}

		$post_data = array(
			'post_author' => $image['author_id'],
		);

		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		// Upload the image
		$attachment_id = media_handle_sideload( $file_array, 0, '', $post_data );

		// Check for upload errors
		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $file_array['tmp_name'] );
			return new \WP_Error( 'upload_failed', $attachment_id->get_error_message() );
		}

		add_post_meta( $attachment_id, 'modula_instagram_image_id', $image['id'], true );
		add_post_meta( $attachment_id, 'modula_instagram_image_date', isset( $image['date'] ) ? $image['date'] : '', true );

		return $attachment_id;
	}

	private function get_image_by_instagram_id( $instagram_id ) {
		global $wpdb;
		//phpcs:ignore
		$post_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM $wpdb->postmeta WHERE meta_key = %s AND meta_value = %s LIMIT 1",
				'modula_instagram_image_id',
				$instagram_id
			)
		);

		if ( $post_id ) {
			return $post_id;
		}

		return false;
	}

	public function add_items_to_gallery( $images ) {
		$sanitized_images = array();
		foreach ( $images as $image ) {
			if ( ! isset( $image['gallery_id'] ) || 0 === absint( $image['gallery_id'] ) ) {
				continue;
			}

			if ( ! isset( $image['attachment_id'] ) || 0 === absint( $image['attachment_id'] ) ) {
				continue;
			}

			$gallery_id = $image['gallery_id'];

			if ( ! isset( $sanitized_images[ $gallery_id ] ) ) {
				$sanitized_images[ $gallery_id ] = array(
					'images'       => array(),
					'settings'     => array(),
					'needs_update' => false,
				);

				$old_images = get_post_meta( $gallery_id, 'modula-images', true );
				if ( ! is_array( $old_images ) ) {
					$old_images = array();
				}
				$sanitized_images[ $gallery_id ]['images'] = $old_images;

				$sanitized_images[ $gallery_id ]['settings'] = get_post_meta( $gallery_id, 'modula-settings', true );
			}

			$current_images = $sanitized_images[ $gallery_id ]['images'];

			$current_images = $this->array_unique_by_key( $current_images, 'id' );

			$current_image_ids = array_map( 'absint', array_column( $current_images, 'id' ) );
			if ( in_array( absint( $image['attachment_id'] ), $current_image_ids, true ) ) {
				continue;
			}

			$upload_position = isset( $sanitized_images[ $gallery_id ]['settings']['upload_position'] ) && $sanitized_images[ $gallery_id ]['settings']['upload_position']
				? $sanitized_images[ $gallery_id ]['settings']['upload_position']
				: 'end';

			$sanitized_image = \Modula_Admin_Helpers::sanitize_image(
				$this->get_item_data( $image )
			);

			if ( 'start' === $upload_position ) {
				array_unshift( $sanitized_images[ $gallery_id ]['images'], $sanitized_image );
			} else {
				$sanitized_images[ $gallery_id ]['images'][] = $sanitized_image;
			}

			$sanitized_images[ $gallery_id ]['needs_update'] = true;
		}

		foreach ( $sanitized_images as $gallery_id => $gallery ) {
			if ( ! $gallery['needs_update'] ) {
				continue;
			}

			$gallery['images'] = apply_filters(
				'modula_instagram_add_image_to_gallery',
				$gallery['images'],
				$gallery_id
			);

			update_post_meta( $gallery_id, 'modula-images', $gallery['images'] );
		}
	}

	public function get_item_data( $image ) {
		$id           = $image['attachment_id'];
		$type         = $image['type'];
		$img_data     = get_post( $id );
		$img_metadata = wp_get_attachment_metadata( $id );

		$new_image = array(
			'id'             => $id,
			'title'          => isset( $img_data->post_title ) ? $img_data->post_title : '',
			'description'    => isset( $img_data->post_excerpt ) ? $img_data->post_excerp : '',
			'alt'            => '',
			'link'           => '',
			'halign'         => 'center',
			'valign'         => 'middle',
			'target'         => '',
			'togglelightbox' => '',
			'hide_title'     => '',
			'src'            => '',
			'type'           => $type,
			'width'          => 2,
			'height'         => 2,
			'full'           => '',
			'thumbnail'      => '',
			'resize'         => false,
			'index'          => '',
			'orientation'    => isset( $img_metadata['image_meta']['orientation'] ) && '0' === $img_metadata['image_meta']['orientation'] ? 'portrait' : 'landscape',
		);

		if ( 'video' === $type ) {
			$new_image['id']              = 'video_template_' . $id;
			$new_image['video_url']       = wp_get_attachment_url( $id );
			$new_image['video_thumbnail'] = $image['thumbnail_url'];
			$new_image['video_template']  = '1';
		}

		return $new_image;
	}

	public static function modula_video_installed() {
		return false;
		// todo: best next feature for future version
		// return defined( 'MODULA_VIDEO_VERSION' );
	}

	private function array_unique_by_key( $arr, $key ) {
		$temp_array = array();
		$i          = 0;
		$key_array  = array();

		foreach ( $arr as $val ) {
			if ( ! in_array( $val[ $key ], $key_array, true ) ) {
				$key_array[ $i ]  = $val[ $key ];
				$temp_array[ $i ] = $val;
			}
			++$i;
		}
		return array_values( $temp_array );
	}
}
