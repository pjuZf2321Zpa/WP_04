<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Instagram_Media_Sync extends WP_Async_Request {
	protected $prefix          = 'modula_instagram_sync';
	protected $action          = 'sync_instagram_media';
	protected $cron_interval   = 5;
	protected $progress_option = 'modula_instagram_sync_progress_';
	protected $gallery_id;
	private static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Instagram_Media_Sync ) ) {
			self::$instance = new Instagram_Media_Sync();
		}
		return self::$instance;
	}

	protected function handle() {
		//phpcs:ignore
		$gallery_id = isset( $_POST['gallery_id'] ) ? absint( wp_unslash( $_POST['gallery_id'] ) ) : null;
		$this->gallery_id = $gallery_id;
		// restart progress
		$this->write_progress(
			array(
				'total'            => 0,
				'synced'           => 0,
				'added_to_gallery' => 0,
				'already_existing' => 0,
				'complete'         => false,
			),
			true
		);

		$sync_instance = Instagram_Sync::get_instance();

		// Sync
		return $sync_instance->sync_gallery_images(
			$gallery_id,
			array( $this, 'write_progress' )
		);
	}

	public function write_progress( $data, $force = false ) {
		$value        = array_merge( $data, array( 'timestamp' => time() ) );
		$current_data = get_option( $this->progress_option . $this->gallery_id, array() );

		if ( empty( $current_data ) ) {
			return update_option( $this->progress_option . $this->gallery_id, $value );
		}

		$time_elapsed = $value['timestamp'] - $current_data['timestamp'];
		if ( $time_elapsed >= 5 || $force ) {
			return update_option(
				$this->progress_option . $this->gallery_id,
				array_merge( $current_data, $value )
			);
		}
	}

	public function get_sync_status( $request ) {
		$this->gallery_id = $request->get_param( 'gallery_id' );
		$progress         = get_option( $this->progress_option . $this->gallery_id, array() );

		return new \WP_REST_Response(
			array(
				'data'    => $progress,
				'success' => true,
			),
			200
		);
	}
}
