<?php
/** Explicit Instagram state reads and gallery sync. Lite keeps schemas and retained-result inspection. */
namespace Modula_Pro\Extensions\Instagram\Abilities;

use Modula\V2\Abilities\Attachments;
use Modula\V2\Abilities\Instagram;
use Modula\V2\Abilities\Instagram_Explanation;
use Modula\V2\Abilities\Integration;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Meta_Sync;
use Modula_Pro\Extensions\Instagram\Image_Handler;
use Modula_Pro\Extensions\Instagram\Instagram_Api_Client;
use Modula_Pro\Extensions\Instagram\Instagram_Sync;

defined( 'ABSPATH' ) || exit;

final class Instagram_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Instagram::READ === $name ) {
			return self::read( $input );
		}
		if ( Instagram::SYNC === $name ) {
			return self::sync( $input );
		}
		return Instagram_Explanation::rejected( $name, $input, Instagram::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Instagram::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/** Local account presence and expiry only. The token value is never returned. */
	public static function account_configured(): bool {
		$expiry = (int) get_option( 'modula_instagram_expiry_date', 0 );
		return (bool) get_option( 'modula_instagram_access_token', false ) && ( ! $expiry || $expiry > time() );
	}

	/**
	 * Account changes are conflicts too. Credentials enter only an irreversible digest.
	 */
	private static function state_revision( int $id, bool $lock = false ): string {
		global $wpdb;
		$gallery = Revision::state( $id, $lock );
		// Authoritative snapshot: fixed option names and boolean-selected FOR UPDATE; caching would hide conflicts.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		$config = $wpdb->get_results( "SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name IN ('modula_instagram_access_token','modula_instagram_expiry_date') ORDER BY option_name" . ( $lock ? ' FOR UPDATE' : '' ), ARRAY_A );
		if ( $wpdb->last_error ) {
			throw new \RuntimeException( 'Account state unavailable.' );
		}
		return hash( 'sha256', $gallery . wp_json_encode( $config ) );
	}

	/**
	 * Local configured flag and revision. No provider query or token disclosure.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function read( array $input ): array {
		$id = (int) $input['id'];
		return array(
			'configured' => self::account_configured(),
			'revision'   => self::state_revision( $id ),
		);
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function sync( array $input ): array {
		$existing = Requests::existing( $input, Instagram::SYNC );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( self::state_revision( (int) $input['id'] ) !== $input['revision'] ) {
			return self::sync_outcome( $input, 'conflict', 'stale_revision' );
		}
		$claimed = Requests::claim( $input, Instagram::SYNC );
		if ( null !== $claimed ) {
			return $claimed;
		}
		return self::sync_locked( $input );
	}

	/**
	 * Provider and gallery work stay after admission. Replay never reaches this method.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function sync_locked( array $input ): array {
		$progress = array(
			'phase'          => 'provider_query',
			'attachment_ids' => array(),
			'added_ids'      => array(),
			'failed'         => 0,
			'complete'       => false,
		);
		$active   = false;
		global $wpdb;
		$lock   = 'modula_instagram_ability_' . get_current_blog_id();
		$locked = false;
		try {
			Requests::context( $input['request_id'], array( 'instagram' => $progress ) );
			// Serialize ability intakes across galleries to avoid duplicate imports of the same provider ID.
			// Database lock/identity state must be read directly, never from an object cache.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$locked = '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) );
			if ( ! $locked ) {
				return Requests::finish( $input['request_id'], self::sync_outcome( $input, 'conflict', 'instagram_busy' ) );
			}
			if ( ! self::access_holds( $input, array() ) || ! self::revision_matches( $input ) ) {
				return Requests::finish( $input['request_id'], self::sync_outcome( $input, 'conflict', 'instagram_state_changed' ) );
			}
			$page = self::provider_page( $input );
			if ( is_string( $page ) ) {
				return Requests::finish( $input['request_id'], self::sync_outcome( $input, 'rejected', $page ) + array( 'instagram' => $progress ) );
			}
			$cursor = self::page_cursor( $page );
			if ( '' !== $cursor ) {
				$progress['after'] = $cursor;
			}
			self::import_images( $page['images'], $progress, $input );
			$progress['phase'] = 'gallery_save';
			Requests::context( $input['request_id'], array( 'instagram' => $progress ) );
			Revision::begin();
			$active = true;
			if ( self::state_revision( (int) $input['id'], true ) !== $input['revision'] ) {
				Revision::end( false );
				$active = false;
				$status = $progress['attachment_ids'] ? 'partial' : 'conflict';
				return Requests::finish( $input['request_id'], self::sync_outcome( $input, $status, 'stale_revision' ) + array( 'instagram' => $progress ) );
			}
			if ( $progress['attachment_ids'] ) {
				Revision::lock_attachments( $progress['attachment_ids'] );
			}
			if ( ! self::access_holds( $input, $progress['attachment_ids'] ) ) {
				throw new \RuntimeException( 'Access changed.' );
			}
			$saved = self::save_gallery( $input, $progress );
			Revision::end( true );
			$active               = false;
			$progress             = $saved['progress'];
			$progress['complete'] = ! self::provider_reports_more( $page ) && 0 === $progress['failed'];
			$code                 = $progress['complete'] ? '' : 'instagram_incomplete';
			$status               = $progress['complete'] ? 'succeeded' : 'partial';
			return Requests::finish(
				$input['request_id'],
				self::sync_outcome( $input, $status, $code ) + array(
					'instagram' => $progress,
					'gallery'   => Integration::gallery( get_post( $input['id'] ) ),
				)
			);
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			// Provider exceptions can carry account data, so the public outcome keeps only the stable code.
			return Requests::finish( $input['request_id'], self::sync_outcome( $input, 'uncertain', 'instagram_unconfirmed' ) + array( 'instagram' => $progress ) );
		} finally {
			if ( $locked ) {
				// Database lock/identity state must be read directly, never from an object cache.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
			}
		}
	}

	/**
	 * Current gallery, upload and account rights. Revision is checked separately.
	 *
	 * @param array<string,mixed> $input
	 * @param array<int,int>      $attachments
	 */
	private static function access_holds( array $input, array $attachments ): bool {
		$record = array(
			'target'         => $input['id'],
			'attachment_ids' => $attachments,
		);
		return Instagram::can_recover( $record ) && Instagram::target_eligible( (int) $input['id'] ) && self::account_configured();
	}

	/**
	 * @param array<string,mixed> $input
	 */
	private static function revision_matches( array $input ): bool {
		return self::state_revision( (int) $input['id'] ) === $input['revision'];
	}

	/**
	 * Safe continuation cursor. Empty when the provider sent none, or sent one that must not be returned.
	 *
	 * @param array<string,mixed> $page Provider page.
	 */
	private static function page_cursor( array $page ): string {
		if ( ! self::provider_reports_more( $page ) ) {
			return '';
		}
		$cursor = $page['after'];
		if ( ! preg_match( '/^[A-Za-z0-9_=-]{1,2000}$/D', $cursor ) ) {
			return '';
		}
		return $cursor;
	}

	/**
	 * A non-empty provider cursor means this page is not the end, even when the cursor cannot be returned.
	 *
	 * @param array<string,mixed> $page Provider page.
	 */
	private static function provider_reports_more( array $page ): bool {
		$cursor = $page['after'] ?? null;
		return is_string( $cursor ) && '' !== $cursor;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|string Rejection code when the page cannot be used.
	 */
	private static function provider_page( array $input ) {
		$service = Instagram_Api_Client::get_instance();
		$limit   = $input['max_items'] ?? 20;
		$page    = $service->get_image_list( $limit, $input['after'] ?? false, $input['refresh'] ?? true );
		if ( ! is_array( $page ) || ! is_array( $page['images'] ?? null ) ) {
			return 'instagram_provider_unavailable';
		}
		// A larger cached page must not silently discard its tail when returning its end cursor.
		if ( count( $page['images'] ) > $limit ) {
			return 'instagram_cache_exceeds_limit';
		}
		return $page;
	}

	/**
	 * @param array<int,mixed>    $images
	 * @param array<string,mixed> $progress
	 * @param array<string,mixed> $input
	 */
	private static function import_images( array $images, array &$progress, array $input ): void {
		$handler = Image_Handler::get_instance();
		foreach ( $images as $image ) {
			self::import_image( $image, $progress, $input, $handler );
		}
	}

	/**
	 * @param mixed               $image
	 * @param array<string,mixed> $progress
	 * @param array<string,mixed> $input
	 */
	private static function import_image( $image, array &$progress, array $input, Image_Handler $handler ): void {
		if ( ! is_array( $image ) || 'image' !== ( $image['type'] ?? '' ) || ! preg_match( '/^[0-9]+$/D', (string) ( $image['id'] ?? '' ) ) ) {
			++$progress['failed'];
			return;
		}
		self::authorize_existing_media( (string) $image['id'] );
		if ( ! self::access_holds( $input, $progress['attachment_ids'] ) ) {
			throw new \RuntimeException( 'Access changed.' );
		}
		$progress['phase'] = 'media_intake';
		Requests::context( $input['request_id'], array( 'instagram' => $progress ) );
		$image['author_id'] = get_current_user_id();
		$attachment         = self::upload_item( $image, $progress, $input, $handler );
		if ( is_wp_error( $attachment ) ) {
			++$progress['failed'];
			return;
		}
		$progress = self::remember_attachment( $progress, (int) $attachment, $input );
	}

	/**
	 * The existing service reuses an attachment by Instagram ID; authorize it before reuse.
	 */
	private static function authorize_existing_media( string $source_id ): void {
		global $wpdb;
		// Database lock/identity state must be read directly, never from an object cache.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$matches = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'modula_instagram_image_id' AND meta_value = %s", $source_id ) );
		foreach ( $matches as $match ) {
			if ( ! Attachments::can_read( (int) $match ) || 'trash' === get_post_status( $match ) ) {
				throw new \RuntimeException( 'Existing media unavailable.' );
			}
		}
	}

	/**
	 * @param array<string,mixed> $image
	 * @param array<string,mixed> $progress
	 * @param array<string,mixed> $input
	 * @return int|\WP_Error
	 */
	private static function upload_item( array $image, array &$progress, array $input, Image_Handler $handler ) {
		$capture = static function ( $id ) use ( &$progress, $input ) {
			$progress = self::remember_attachment( $progress, (int) $id, $input );
		};
		add_action( 'add_attachment', $capture, 1 );
		try {
			return $handler->upload_item_from_url( $image );
		} finally {
			remove_action( 'add_attachment', $capture, 1 );
		}
	}

	/**
	 * @param array<string,mixed> $progress
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function remember_attachment( array $progress, int $attachment_id, array $input ): array {
		$progress['attachment_ids'][] = $attachment_id;
		$progress['attachment_ids']   = array_values( array_unique( $progress['attachment_ids'] ) );
		Requests::context(
			$input['request_id'],
			array(
				'instagram'      => $progress,
				'attachment_ids' => $progress['attachment_ids'],
			)
		);
		return $progress;
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $progress
	 * @return array{progress:array<string,mixed>}
	 */
	private static function save_gallery( array $input, array $progress ): array {
		$before   = array_column( Meta_Sync::get_images_v2( $input['id'] ), 'id' );
		$settings = get_post_meta( $input['id'], 'modula-settings', true );
		$position = is_array( $settings ) ? ( $settings['upload_position'] ?? 'end' ) : 'end';
		Instagram_Sync::get_instance()->add_items_to_gallery( $input['id'], $progress['attachment_ids'], $position );
		$after = array_map( 'strval', array_column( Meta_Sync::get_images_v2( $input['id'] ), 'id' ) );
		if ( array_diff( array_map( 'strval', $progress['attachment_ids'] ), $after ) ) {
			throw new \RuntimeException( 'Gallery persistence unconfirmed.' );
		}
		$progress['added_ids'] = array_values( array_diff( $progress['attachment_ids'], $before ) );
		$progress['phase']     = 'saved';
		return array( 'progress' => $progress );
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function sync_outcome( array $input, string $status, string $code ): array {
		$message = $code ? 'Inspect retained attachments and gallery before any new synchronization.' : '';
		return Requests::outcome( $input['request_id'], $status, $code, $message, Instagram::SYNC );
	}
}
