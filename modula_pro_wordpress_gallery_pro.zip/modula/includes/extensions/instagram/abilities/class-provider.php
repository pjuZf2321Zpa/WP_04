<?php
/** Pro contribution for Instagram state reads and explicit gallery sync. */
namespace Modula_Pro\Extensions\Instagram\Abilities;

use Modula\V2\Abilities\Instagram;
use Modula\V2\Abilities\Instagram_Explanation;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Provider {
	public const ID = 'modula-pro-instagram';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! Pro_Dependency::extension_contract( 'modula-instagram' ) ) {
			return $contributions;
		}
		foreach ( Instagram::names() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Instagram_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck gallery admission and the Instagram feature before any effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Instagram::explain_blockers( $name, $input );
		// A sync needs a connected account; the read reports configuration instead of refusing.
		if ( ! $blockers && Instagram::SYNC === $name && ! Instagram_Executor::account_configured() ) {
			$blockers = array( self::configuration_blocker() );
		}
		if ( ! $blockers ) {
			return null;
		}
		return Instagram_Explanation::rejected( $name, $input, $blockers );
	}

	/** @return array{reason:string,feature:string,remedy:array{action:string,explanation:string,destination:string}} */
	private static function configuration_blocker(): array {
		return array(
			'reason'  => 'configuration_required',
			'feature' => 'modula-instagram',
			'remedy'  => array(
				'action'      => 'configure_service',
				'explanation' => __( 'Connect an Instagram account before syncing media. This operation does not accept credentials.', 'modula-pro' ),
				'destination' => admin_url( 'edit.php?post_type=modula-gallery&page=modula' ),
			),
		);
	}
}
