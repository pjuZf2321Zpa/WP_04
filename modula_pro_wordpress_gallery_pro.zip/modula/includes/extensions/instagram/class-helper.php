<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Helper {
	public static function get_instagram_image_dates( $attachment_ids ) {
		$attachment_ids = array_map( 'intval', $attachment_ids );

		if ( empty( $attachment_ids ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $attachment_ids ), '%d' ) );

		$sql = "
            SELECT p.ID AS attachment_id, pm.meta_value AS instagram_date
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'attachment'
              AND pm.meta_key = %s
              AND p.ID IN ($placeholders)
            ORDER BY pm.meta_value ASC
        ";

		$query_args = array_merge(
			array( 'modula_instagram_image_date' ),
			$attachment_ids
		);

		//phpcs:ignore
		$results = $wpdb->get_results(
            //phpcs:ignore
			$wpdb->prepare( $sql, $query_args ),
			ARRAY_A
		);

		return $results ? $results : array();
	}
}
