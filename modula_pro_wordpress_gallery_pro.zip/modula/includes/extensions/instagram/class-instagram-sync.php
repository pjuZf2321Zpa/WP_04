<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Instagram_Sync {
	private $hook_name     = 'modula_instagram_sync';
	private $interval_name = 'modula_instagram_sync_instagram_media_cron_interval';

	private static $instance = null;

	public function __construct() {
		add_action( 'modula_instagram_token_disconnect', array( $this, 'deactivate' ) );
		if ( ! OAuth::get_instance()->get_access_token() ) {
			return;
		}

		add_filter( 'cron_schedules', array( $this, 'add_custom_cron_interval' ) );

		if ( ! wp_next_scheduled( $this->hook_name ) ) {
			wp_schedule_event( time(), $this->interval_name, $this->hook_name );
		}

		add_action( $this->hook_name, array( $this, 'sync_gallery_images' ) );
	}

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Instagram_Sync ) ) {
			self::$instance = new Instagram_Sync();
		}
		return self::$instance;
	}

	/**
	 * Add custom interval to cron schedules.
	 *
	 * @param array $schedules The existing schedules.
	 * @return array Modified schedules.
	 */
	public function add_custom_cron_interval( $schedules ) {
		$schedules[ $this->interval_name ] = array(
			'interval' => 6 * HOUR_IN_SECONDS,
			'display'  => 'Every 6 Hours',
		);
		return $schedules;
	}

	/**
	 * Unschedule the event when the token is deactivated.
	 */
	public function deactivate() {
		$timestamp = wp_next_scheduled( $this->hook_name );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, $this->hook_name );
		}

		$galleries = get_posts(
			array(
				'post_type'   => 'modula-gallery',
				'numberposts' => -1,
			)
		);

		foreach ( $galleries as $gallery ) {
			$settings = get_post_meta( $gallery->ID, 'modula-settings', true );

			if ( isset( $settings['syncWithInstagram'] ) ) {
				unset( $settings['syncWithInstagram'] );
			}

			update_post_meta( $gallery->ID, 'modula-settings', $settings );
		}
	}

	/**
	 * Callback function to sync instagram images with the gallerys.
	 */
	public function sync_gallery_images( $gallery_id = null, $progress_callback = false ) {
		$instagram_api = Instagram_Api_Client::get_instance();

		// 1. Reset the image cache transient.
		$instagram_api->reset_image_cache();

		// 2. Get the image list. Carousel images are only supported on classic galleries.
		$include_carousels = is_null( $gallery_id )
			|| ! class_exists( '\Modula\V2\Beta_Settings' )
			|| ! \Modula\V2\Beta_Settings::is_beta_gallery( $gallery_id );

		$all_images = array();
		$after      = false;
		do {
			$images = $instagram_api->get_image_list( 200, $after, false, $include_carousels );

			if ( isset( $images['images'] ) ) {
				$all_images = array_merge( $all_images, $images['images'] );
			}

			$after = isset( $images['after'] ) ? $images['after'] : false;
		} while ( $after );

		if ( empty( $all_images ) ) {
			if ( is_callable( $progress_callback ) ) {
				$data = array(
					'total'    => 0,
					'complete' => true,
				);
				call_user_func( $progress_callback, $data, true );
			}
			return;
		}

		if ( is_callable( $progress_callback ) ) {
			$data = array(
				'total'  => count( $all_images ),
				'synced' => 0,
			);

			call_user_func( $progress_callback, $data, true );
		}

		// 3. Check witch images are missing from wp media library.
		$missing_images = $this->missing_media_images( $all_images, $gallery_id );

		if ( is_callable( $progress_callback ) ) {
			$data = array(
				'synced' => count( $all_images ) - count( $missing_images['to_import'] ),
			);
			call_user_func( $progress_callback, $data );
		}

		if ( empty( $missing_images['to_import'] ) && empty( $missing_images['to_add'] ) ) {
			if ( is_callable( $progress_callback ) ) {
				$data = array(
					'complete' => true,
				);
				call_user_func( $progress_callback, $data, true );
			}
			return;
		}

		// 4. Upload the missing images to wp media library
		$image_handler      = Image_Handler::get_instance();
		$new_images         = array();
		$carousel_image_ids = array();
		$uploaded           = 0;
		$total_missing = count( $missing_images['to_import'] );
		foreach ( $missing_images['to_import'] as $index => $missing_image ) {
			$missing_image['author_id'] = 0;
			$upload                     = $image_handler->upload_item_from_url( $missing_image );

			if ( is_wp_error( $upload ) ) {
				continue;
			}
			++$uploaded;
			if ( is_callable( $progress_callback ) ) {
				$data    = array(
					'synced' => ( count( $all_images ) - count( $missing_images['to_import'] ) ) + $uploaded,
				);
				$is_last = ( $index === $total_missing - 1 );
				call_user_func( $progress_callback, $data, $is_last );
			}

			$new_images[] = $upload;
			if ( ! empty( $missing_image['carousel'] ) ) {
				$carousel_image_ids[] = $upload;
			}
		}

		if ( ! empty( $missing_images['to_add'] ) ) {
			if ( is_callable( $progress_callback ) ) {
				$data = array(
					'already_existing' => count( $missing_images['to_add'] ),
				);
				call_user_func( $progress_callback, $data, true );
			}

			$new_images = array_merge( $new_images, $missing_images['to_add'] );
		}

		if ( ! is_null( $gallery_id ) ) {
			$settings        = get_post_meta( $gallery_id, 'modula-settings', true );
			$upload_position = isset( $settings['upload_position'] ) ? $settings['upload_position'] : 'end';

			$this->add_items_to_gallery( $gallery_id, $new_images, $upload_position );

			if ( is_callable( $progress_callback ) ) {
				$data = array(
					'added_to_gallery' => count( $new_images ),
					'complete'         => true,
				);
				call_user_func( $progress_callback, $data, true );
			}

			return;
		}

		// 5. Get all Modula galleries.
		$args = array(
			'post_type'      => 'modula-gallery',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		);

		$galleries = get_posts( $args );

		// 6. Check every gallery if we should sync images.
		foreach ( $galleries as $gallery ) {
			$settings = get_post_meta( $gallery->ID, 'modula-settings', true );

			if ( isset( $settings['syncWithInstagram'] ) && $settings['syncWithInstagram'] ) {
				// 6.1 Add the new images to gallery.
				$upload_position = isset( $settings['upload_position'] ) ? $settings['upload_position'] : 'end';
				$gallery_images  = $new_images;
				if ( class_exists( '\Modula\V2\Beta_Settings' ) && \Modula\V2\Beta_Settings::is_beta_gallery( $gallery->ID ) ) {
					$gallery_images = array_values( array_diff( $new_images, $carousel_image_ids ) );
				}
				$this->add_items_to_gallery( $gallery->ID, $gallery_images, $upload_position );
			}
		}

		if ( is_callable( $progress_callback ) ) {
			$data = array(
				'complete' => true,
			);
			call_user_func( $progress_callback, $data, true );
		}
	}

	private function missing_media_images( $images, $gallery_id = null ) {
		$ids_list = array();

		foreach ( $images as $image ) {
			$ids_list[] = (string) $image['id'];
		}

		$query_args = array(
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'numberposts' => -1,
			'meta_query'  => array(
				array(
					'key'     => 'modula_instagram_image_id',
					'value'   => $ids_list,
					'compare' => 'IN',
				),
			),
		);

		$attachments = get_posts( $query_args );

		$existing_image_ids            = array();
		$existing_image_attachment_ids = array();
		foreach ( $attachments as $attachment ) {
			$existing_id = get_post_meta( $attachment->ID, 'modula_instagram_image_id', true );
			if ( $existing_id ) {
				$existing_image_ids[]            = strval( $existing_id );
				$existing_image_attachment_ids[] = $attachment->ID;
			}
		}

		foreach ( $images as $key => $image ) {
			if ( in_array( strval( $image['id'] ), $existing_image_ids, true ) ) {
				unset( $images[ $key ] );
			}
		}

		$imported_but_not_added = array();
		if ( ! is_null( $gallery_id ) ) {
			$gallery_images = get_post_meta( $gallery_id, 'modula-images', true );
			if ( ! is_array( $gallery_images ) ) {
				$gallery_images = array();
			}

			$gallery_images_ids = array_map( 'absint', array_column( $gallery_images, 'id' ) );
			foreach ( $existing_image_attachment_ids as $image_id ) {
				if ( in_array( $image_id, $gallery_images_ids, true ) ) {
					continue;
				}

				$imported_but_not_added[] = $image_id;
			}
		}

		return array(
			'to_import' => $images,
			'to_add'    => $imported_but_not_added,
		);
	}

	public function add_items_to_gallery( $gallery_id, $images_ids, $upload_positioning ) {
		$beta       = class_exists( \Modula\V2\Beta_Settings::class ) && \Modula\V2\Beta_Settings::is_beta_gallery( $gallery_id );
		$old_images = $beta ? \Modula\V2\Meta_Sync::get_images_v2( $gallery_id ) : get_post_meta( $gallery_id, 'modula-images', true );
		$new_images = array();

		if ( ! is_array( $old_images ) ) {
			$old_images = array();
		}

		$current_images = array_map( 'absint', array_column( $old_images, 'id' ) );

		if ( ! class_exists( 'Modula_Admin_Helpers' ) ) {
			require_once MODULA_PATH . 'includes/admin/helpers/class-modula-admin-helpers.php';
		}

		foreach ( $images_ids as $image_id ) {
			if ( in_array( absint( $image_id ), $current_images, true ) ) {
				continue;
			}

			$image_handler = Image_Handler::get_instance();
			$new_images[]  = \Modula_Admin_Helpers::sanitize_image(
				$image_handler->get_item_data(
					array(
						'attachment_id' => $image_id,
						'type'          => 'image',
					)
				)
			);
		}
		$sorter = Helper::get_instagram_image_dates( array_column( $new_images, 'id' ) );

		foreach ( $new_images as &$image ) {
			foreach ( $sorter as $item ) {
				if ( absint( $item['attachment_id'] ) === absint( $image['id'] ) ) {
					$image['date'] = $item['instagram_date'];
					break;
				}
			}
		}

		usort(
			$new_images,
			function ( $a, $b ) {
				if ( ! isset( $a['date'] ) || ! isset( $b['date'] ) ) {
					return 0;
				}

				return strtotime( $b['date'] ) - strtotime( $a['date'] );
			}
		);

		if ( 'start' === $upload_positioning ) {
			array_splice( $old_images, 0, 0, $new_images );
			$merged_images = $old_images;
		} else {
			$merged_images = array_merge( $old_images, $new_images );
		}

		if ( $beta ) {
			return \Modula\V2\Meta_Sync::persist_merged_gallery_items( $gallery_id, $merged_images, false );
		}
		return update_post_meta( $gallery_id, 'modula-images', $merged_images );
	}
}
