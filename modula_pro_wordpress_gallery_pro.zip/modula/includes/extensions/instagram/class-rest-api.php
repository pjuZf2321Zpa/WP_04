<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rest_Api {
	protected $namespace = 'modula-instagram/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/token/disconnect/',
			array(
				'methods'             => 'POST',
				'callback'            => array( OAuth::get_instance(), 'disconnect_token' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/user-info',
			array(
				'methods'             => 'GET',
				'callback'            => array( Instagram_Api_Client::get_instance(), 'get_user_info' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/image-list',
			array(
				'methods'             => 'GET',
				'callback'            => array( Instagram_Api_Client::get_instance(), 'get_user_image_list' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/sync-gallery',
			array(
				'methods'             => 'POST',
				'callback'            => array( Instagram_Api_Client::get_instance(), 'sync_gallery' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/sync-gallery-status/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( Instagram_Media_Sync::get_instance(), 'get_sync_status' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/get-images',
			array(
				'methods'             => 'POST',
				'callback'            => array( Image_Handler::get_instance(), 'image_upload_request' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/check-status/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( Image_Handler::get_instance(), 'image_upload_status' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);
	}

	public function _permissions_check() {
		return current_user_can( 'manage_options' );
	}
}
