<?php return array('dependencies' => array('wp-api-fetch'), 'version' => 'dcbfcc50c0aa977e8bde');
