<?php return array('dependencies' => array('react', 'react-jsx-runtime', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n', 'wp-primitives'), 'version' => 'caf185bb800bf1b7e5ec');
