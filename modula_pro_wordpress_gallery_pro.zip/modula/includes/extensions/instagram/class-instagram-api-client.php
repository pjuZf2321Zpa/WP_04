<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Instagram_Api_Client {
	/**
	 * Singleton instance of Instagram_Api_Client
	 *
	 * @var Instagram_Api_Client|null
	 */
	private static $instance = null;

	/**
	 * Transient key for caching image list.
	 *
	 * @var string
	 */
	private $img_transient = 'modula_images_list';

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return Instagram_Api_Client|null
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Instagram_Api_Client ) ) {
			self::$instance = new Instagram_Api_Client();
		}
		return self::$instance;
	}

	/**
	 * Makes a request to the Instagram API.
	 *
	 * @param string $endpoint API endpoint to request.
	 * @param array  $params   Optional. Additional query parameters for the request.
	 *
	 * @return array|false The API response data or false on failure.
	 */
	private function make_request( $url ) {

		$response = wp_remote_get( $url );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['error'] ) ) {
			return false;
		}

		return $data;
	}

	/**
	 * Retrieves user data from the Instagram API.
	 *
	 * @param int $limit Optional. The number of media items to retrieve. Default 200.
	 *
	 * @return array|false Array of media data or false on failure.
	 */
	public function get_user_media( $limit = 200, $after = false, $include_children = false ) {
		$fields = 'id,caption,media_type,media_url,thumbnail_url,permalink,timestamp';
		if ( $include_children ) {
			$fields .= ',children{id,media_type,media_url,thumbnail_url,timestamp}';
		}

		$params = array(
			'fields'       => $fields,
			'limit'        => $limit,
			'access_token' => OAuth::get_instance()->get_access_token(),
		);

		if ( empty( $params['access_token'] ) ) {
			return false;
		}

		if ( $after ) {
			$params['after'] = $after;
		}

		$url = MODULA_PRO_INSTAGRAM_API_URL . '/me/media?' . http_build_query( $params );

		$media = $this->make_request( $url );

		if ( ! $media || ! isset( $media['data'] ) ) {
			return false;
		}

		if ( $this->has_after_cursor( $media ) ) {
			$media['after'] = $media['paging']['cursors']['after'];
		}

		return $media;
	}

	private function has_after_cursor( $media ) {
		return isset( $media['paging']['next'] ) && isset( $media['paging']['cursors']['after'] );
	}

	/**
	 * Retrieves user information from the Instagram API.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_user_info() {
		$params = array(
			'fields'       => 'id,username,account_type',
			'access_token' => OAuth::get_instance()->get_access_token(),
		);

		if ( empty( $params['access_token'] ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'No user data received.', 'modula-pro' ),
				),
				400
			);
		}
		$url       = \MODULA_PRO_INSTAGRAM_API_URL . '/me?' . http_build_query( $params );
		$user_info = $this->make_request( $url );

		if ( $user_info ) {
			return new \WP_REST_Response( $user_info, 200 );
		}
		return new \WP_REST_Response(
			array(
				'success' => false,
				'message' => esc_html__( 'No user data received.', 'modula-pro' ),
			),
			400
		);
	}

	/**
	 * Retrieves a list of user images, either from transient cache or by making an API request.
	 *
	 * @param \WP_REST_Request
	 *
	 * @return \WP_REST_Response
	 */
	public function get_user_image_list( $request ) {

		$limit = $request->get_param( 'limit' );
		$after = $request->get_param( 'after' );
		$limit = isset( $limit ) && is_numeric( $limit ) ? intval( $limit ) : 200;
		$after = isset( $after ) ? $after : false;

		$include_carousels = filter_var( $request->get_param( 'carousels' ), FILTER_VALIDATE_BOOLEAN );

		$images = $this->get_image_list( $limit, $after, false, $include_carousels );

		if ( ! $images ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'No image data received.', 'modula-pro' ),
				),
				400
			);
		}

		return new \WP_REST_Response( $images, 200 );
	}

	public function get_image_list( $limit = 200, $after = false, $fresh = false, $include_carousels = false ) {
		$transient = $this->img_transient . ( $include_carousels ? '_carousels' : '' );
		if ( $after ) {
			$transient .= '_' . $after;
		}

		$img_cache = $fresh ? false : get_transient( $transient );

		if ( false !== $img_cache ) {
			return $img_cache;
		}

		$media = $this->get_user_media( $limit, $after, $include_carousels );

		if ( ! $media || ! isset( $media['data'] ) ) {
			return false;
		}

		$images = array();
		$data   = array();

		foreach ( $media['data'] as $item ) {
			if ( 'CAROUSEL_ALBUM' !== $item['media_type'] ) {
				$data_obj = $this->format_media_item( $item );
				if ( $data_obj ) {
					$images[] = $data_obj;
				}
				continue;
			}

			if ( ! $include_carousels || empty( $item['children']['data'] ) ) {
				continue;
			}

			foreach ( $item['children']['data'] as $child ) {
				$data_obj = $this->format_media_item( $child, $item );
				if ( $data_obj ) {
					$images[] = $data_obj;
				}
			}
		}
		if ( isset( $media['after'] ) ) {
			$data['after'] = $media['after'];
		}

		$data['images'] = $images;

		// Bounded explicit callers may bypass the shared cache without replacing a differently sized page.
		if ( ! $fresh ) {
			set_transient( $transient, $data, DAY_IN_SECONDS );
		}

		return $data;
	}

	/**
	 * Formats an Instagram media item for the image list.
	 *
	 * @param array      $item   Media item.
	 * @param array|null $parent Carousel the item belongs to, used for caption and date.
	 *
	 * @return array|false
	 */
	private function format_media_item( $item, $parent = null ) {
		if ( 'IMAGE' !== $item['media_type'] && ! Image_Handler::modula_video_installed() ) {
			return false;
		}

		if ( empty( $item['media_url'] ) ) {
			return false;
		}

		$caption = isset( $item['caption'] ) ? $item['caption'] : '';
		if ( '' === $caption && isset( $parent['caption'] ) ) {
			$caption = $parent['caption'];
		}

		$date = isset( $item['timestamp'] ) ? $item['timestamp'] : '';
		if ( '' === $date && isset( $parent['timestamp'] ) ) {
			$date = $parent['timestamp'];
		}

		$data_obj = array(
			'id'      => $item['id'],
			'url'     => $item['media_url'],
			'caption' => $caption,
			'date'    => $date,
			'type'    => 'image',
		);

		if ( $parent ) {
			$data_obj['carousel'] = true;
		}

		if ( 'VIDEO' === $item['media_type'] ) {
			$data_obj['video_url']     = $item['media_url'];
			$data_obj['thumbnail_url'] = isset( $item['thumbnail_url'] ) ? $item['thumbnail_url'] : '';
			$data_obj['type']          = 'video';
		}

		return $data_obj;
	}

	/**
	 * Refreshes the cached list of user images by deleting the transient.
	 *
	 * @return \WP_REST_Response
	 */
	public function refresh_user_image_list() {
		$this->reset_image_cache();

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Image data refreshed.', 'modula-pro' ),
			),
			200
		);
	}

	public function reset_image_cache() {
		global $wpdb;
		//phpcs:ignore
		$transients = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				'_transient_' . $this->img_transient . '%'
			)
		);

		foreach ( $transients as $transient ) {
			$transient_name = str_replace( '_transient_', '', $transient );
			delete_transient( $transient_name );
		}
	}

	public function sync_gallery( $request ) {
		$gallery_id = $request->get_param( 'gallery_id' );
		if ( ! $gallery_id ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'No gallery ID provided.', 'modula-pro' ),
				),
				400
			);
		}

		$this->reset_image_cache();

		$async_request = Instagram_Media_Sync::get_instance();
		$async_request->data(
			array(
				'gallery_id' => $gallery_id,
			)
		);

		$async_request->dispatch();

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Gallery sync dispatched.', 'modula-pro' ),
			),
			200
		);
	}
}
