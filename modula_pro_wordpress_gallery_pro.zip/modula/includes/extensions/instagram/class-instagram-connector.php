<?php
namespace Modula_Pro\Extensions\Instagram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Instagram_Connector {
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_react_apps' ) );
		add_action( 'modula_gallery_media_select_option', array( $this, 'add_instagram_button' ), 10, 2 );
	}

	/**
	 * Whether the v2 gallery takeover / settings editor owns the Add New UI.
	 *
	 * @return bool
	 */
	private function is_gallery_takeover_active() {
		return class_exists( '\Modula\V2\Admin\Gallery_Takeover_Admin' )
			&& \Modula\V2\Admin\Gallery_Takeover_Admin::should_use_takeover();
	}

	public function add_instagram_button() {
		if ( $this->is_gallery_takeover_active() ) {
			return;
		}

		if ( ! OAuth::get_instance()->get_access_token() ) {
			echo '<li class="modula-not-connected">
			<a href="' . esc_url( OAuth::get_instance()->create_request_url() ) . '">' . esc_html__( 'Connect Instagram', 'modula-pro' ) . '</a>
			</li>';

			return;
		}

		echo '<li id="modula-instagram-connector" data-gallery-id="' . esc_attr( get_the_ID() ) . '">' . esc_html__( 'Instagram', 'modula-pro' ) . '</li>';
	}

	public function enqueue_react_apps() {
		if ( $this->is_gallery_takeover_active() ) {
			return;
		}

		$current_screen = get_current_screen();
		if ( 'modula-gallery' !== $current_screen->id ) {
			return;
		}

		$asset_file = require \MODULA_PRO_PATH . 'includes/extensions/instagram/public/instagram-connector/index.asset.php';
		$enqueue    = array(
			'handle'       => 'modula-instagram-connector',
			'dependencies' => $asset_file['dependencies'],
			'version'      => $asset_file['version'],
			'script'       => \MODULA_PRO_URL . 'includes/extensions/instagram/public/instagram-connector/index.js',
			'style'        => \MODULA_PRO_URL . 'includes/extensions/instagram/public/instagram-connector/index.css',
		);

		wp_enqueue_script(
			$enqueue['handle'],
			$enqueue['script'],
			$enqueue['dependencies'],
			$enqueue['version'],
			true
		);

		wp_enqueue_style(
			$enqueue['handle'],
			$enqueue['style'],
			array( 'wp-components' ),
			$enqueue['version']
		);
	}
}
