<?php
namespace Modula_Pro\Extensions\Deeplink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/deeplink';

	public function __construct() {
		add_action( 'modula_extra_scripts', array( $this, 'deeplink_extra_scripts' ), 15, 2 );

		add_action( 'modula_link_extra_scripts', array( $this, 'link_deeplink_scripts' ), 30, 1 );

		// Enqueue admin required scripts
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'deeplink_admin_scripts' ), 40 );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'deeplink_admin_scripts' ), 40 );

		add_filter( 'modula_gallery_settings', array( $this, 'deeplink_js_config' ), 10, 2 );
		add_filter( 'modula_link_gallery_settings', array( $this, 'link_deeplink_js_config' ), 10, 2 );
	}

		/**
	 * Add deeplink settings to Modula's defaults
	 *
	 * @param $js_config
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function deeplink_js_config( $js_config, $settings ) {
		if ( ! isset( $settings['modula_deeplink'] ) || 1 !== absint( $settings['modula_deeplink'] ) ) {
			$js_config['modula_deeplink'] = 0;
			return $js_config;
		}

		$js_config['modula_deeplink'] = absint( $settings['modula_deeplink'] );
		$js_config['galleryID']       = isset( $settings['gallery_id'] ) ? str_replace( 'jtg-', '', $settings['gallery_id'] ) : '';
		$js_config['customLinkName']  = isset( $settings['customLinkName'] ) ? sanitize_title( $settings['customLinkName'] ) : '';

		return $js_config;
	}

	/**
	 * Modula Link Shortcode js config fitlering
	 *
	 * @param $js_config
	 * @param $settings
	 *
	 * @since 1.0.2
	 *
	 * @return mixed
	 */
	public function link_deeplink_js_config( $js_config, $settings ) {

		if ( ! isset( $settings['modula_deeplink'] ) || 1 !== absint( $settings['modula_deeplink'] ) ) {
			$js_config['options']['modula_deeplink'] = 0;
			return $js_config;
		}

		$js_config['options']['modula_deeplink'] = absint( $settings['modula_deeplink'] );
		$js_config['options']['galleryID']       = isset( $settings['gallery_id'] ) ? str_replace( 'jtg-', '', $settings['gallery_id'] ) : '';
		$js_config['options']['customLinkName']  = isset( $settings['customLinkName'] ) ? sanitize_title( $settings['customLinkName'] ) : '';

		return $js_config;
	}

	/**
	 * Enqueue extra scripts required for deeplinking
	 *
	 * @param  array  $settings  Gallery settings
	 * @param  array  $images    Gallery images
	 *
	 * @since 1.0.2
	 */
	public function deeplink_extra_scripts( $settings, $images ) {
		// Beta ON / modern React shortcode: deeplink runtime lives in lite — do not load legacy JS.
		if (
			class_exists( '\Modula\V2\Modern_Gallery' )
			&& \Modula\V2\Modern_Gallery::is_modern_stack_enabled( \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( is_array( $settings ) ? $settings : array() ) )
		) {
			return;
		}

		$not_included = array( 'fancybox', 'no-link', 'attachment-page' );

		if ( ! in_array( $settings['lightbox'], $not_included ) && isset( $settings['modula_deeplink'] ) && 1 === absint( $settings['modula_deeplink'] ) ) {
			wp_enqueue_script( 'modula-pro', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-deeplink.js', array( 'jquery', 'modula-wfl', 'modula-lightgallery', 'modula-lightboxes' ), \MODULA_PRO_VERSION, true );

			if ( 'lightgallery' === $settings['lightbox'] ) {
				wp_enqueue_script( 'modula-lightbox2-deeplink', \MODULA_PRO_URL . $this->extension_url . '/assets/js/lg-hash.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
			}
		} elseif ( ( 'fancybox' === $settings['lightbox'] || 'lightbox-prefer-url' === $settings['lightbox'] ) && isset( $settings['modula_deeplink'] ) && 1 === absint( $settings['modula_deeplink'] ) ) {
			$deps = array( 'jquery' );

			// Legacy jQuery Fancybox dependency exists only for legacy shortcode.
			// v2 React galleries use Fancybox v6 (no `modula-fancybox` registered).
			if ( wp_script_is( 'modula-fancybox', 'registered' ) ) {
				$deps[] = 'modula-fancybox';
			}

			wp_enqueue_script( 'modula-fancybox-deeplink', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-fancybox-deeplink.js', $deps, \MODULA_PRO_VERSION, true );
			wp_add_inline_script( 'modula-fancybox-deeplink', 'var fancyboxVer = ' . ( ( version_compare( \MODULA_PRO_VERSION, '2.8.0' ) >= 0 ) ? 5 : 3 ) . ';', 'before' );
			// Create our object used for social deeplinking
			$slug = '!modulagallery';
			if ( isset( $settings['customLinkName'] ) && '' !== $settings['customLinkName'] ) {
				$slug = $settings['customLinkName'];
			}
			$social_images = array();
			foreach ( $images as $key => $image ) {
				$social_images[ $key ] = $image['id'];
			}
			// Add fancybox deeplink object
			$deeplink_obj = array(
				'slug'   => $slug,
				'images' => $social_images,
			);

			wp_add_inline_script( 'modula-fancybox-deeplink', 'var deeplinkSocials = ' . wp_json_encode( $deeplink_obj ) . ';', 'before' );
		}
	}

	/**
	 * Enqueue admin Modula Deeplink scripts
	 *
	 * @since 1.0.2
	 */
	public function deeplink_admin_scripts() {
		wp_enqueue_script( 'modula-deeplink-conditions', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-deeplink-conditions.js', array( 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Add deeplink scripts for modula link shortcode
	 *
	 * @param $settings
	 */
	public function link_deeplink_scripts() {

		wp_enqueue_script( 'modula-fancybox-deeplink', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-fancybox-deeplink.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}
}
