( function ( $, window, document ) {
	const modulaGalleryTemp = null;

	$( document ).on( 'modula_api_after_init', function ( event, data ) {
		const modula_gallery = data;
		if ( modula_gallery.options.modula_deeplink == 1 ) {
			modula_open_deeplink(
				modula_gallery,
				modula_gallery.options.customLinkName
			);
		}
	} );

	/**
	 * Fired when a hash is detected in the URL bar
	 * @param modula_gallery
	 * @param customLinkName
	 */
	function modula_open_deeplink( modula_gallery, customLinkName ) {
		if ( modula_gallery ) {
			const gallery_static_id = modula_gallery.$element.attr( 'id' );

			// Get hash
			const hash = window.location.hash.substr( 1 );
			// Check if a hash exists, and it's an modula Gallery Hash
			if (
				! hash ||
				hash.length == 0 ||
				hash.indexOf( `${ customLinkName }` ) == -1
			) {
				return;
			}

			const params = hash.split( '-' ), //break up other url params
				gallery_id = params[ 1 ],
				image_id = params[ 2 ];

			// If here, hash is valid.
			let current_item = modula_gallery.$element.find(
				'a[data-image-id="' + image_id + '"]'
			);
			if ( current_item.length > 1 ) {
				current_item = current_item[ 0 ];
			}

			setTimeout( function () {
				current_item.click();
			}, 400 );
		}
	}

	function modula_change_hash( gallery_id, image_id ) {
		const customLinkName =
			'' == $( '.modula-gallery' ).data( 'config' ).customLinkName
				? 'modulagallery'
				: $( '.modula-gallery' ).data( 'config' ).customLinkName;

		/* Should be executed BEFORE any hash change has occurred. */
		( function ( namespace ) {
			/* Closure to protect local variable "var hash" */
			if ( 'replaceState' in history ) {
				/* Yay, supported! */
				namespace.replaceHash = function ( newhash ) {
					if ( ( '' + newhash ).charAt( 0 ) !== '#' ) {
						newhash = '#' + newhash;
					}
					history.replaceState( '', '', newhash );
				};
			} else {
				const hash = location.hash;
				namespace.replaceHash = function ( newhash ) {
					if ( location.hash !== hash ) {
						history.back();
					}
					location.hash = newhash;
				};
			}
		} )( window );

		window.replaceHash(
			`!${ customLinkName }-` + gallery_id + '-' + image_id
		);
	}

	/**
	 * Bind the modula_make_deeplink function when the window hash changes
	 */
	jQuery( window ).on( 'hashchange', function () {
		modula_open_deeplink( modula_galleries_temp );
	} );

	// Handle Lightbox2
	$( document ).on(
		'modula_lightbox2_lightbox_open modula_lightbox2_lightbox_prev modula_lightbox2_lightbox_next',
		function ( e, lightbox ) {
			const currentSRC = lightbox.$image.attr( 'src' );
			const $gallery_image = jQuery(
				'a.tile-inner[href="' + currentSRC + '"]'
			);
			const modula_gallery_id = $gallery_image
				.parents( '.modula.modula-gallery' )
				.attr( 'id' );
			const gallery_id = modula_gallery_id.replace( 'jtg-', '' );

			modula_change_hash( gallery_id, $gallery_image.data( 'image-id' ) );
		}
	);

	// Handle Magnific Popup
	$( document ).on(
		'modula_magnific_lightbox_open modula_magnific_lightbox_change',
		function ( e, event, data, popup ) {
			const $gallery_image = popup.currItem.el;
			const modula_gallery_id = $gallery_image
				.parents( '.modula.modula-gallery' )
				.attr( 'id' );
			const gallery_id = modula_gallery_id.replace( 'jtg-', '' );
			modula_change_hash( gallery_id, $gallery_image.data( 'image-id' ) );
		}
	);

	// Handle PrettyPhoto
	$( document ).on(
		'modula_prettyphoto_lightbox_change',
		function ( e, data, popup ) {
			if (
				'undefined' === typeof pp_images ||
				'undefined' === typeof rel_index
			) {
				return;
			}

			const currentSRC = pp_images[ rel_index ];
			const $gallery_image = data.$element.find(
				'a.tile-inner[href="' + currentSRC + '"]'
			);
			const modula_gallery_id = $gallery_image
				.parents( '.modula.modula-gallery' )
				.attr( 'id' );
			const gallery_id = modula_gallery_id.replace( 'jtg-', '' );

			modula_change_hash( gallery_id, $gallery_image.data( 'image-id' ) );
		}
	);

	$( document ).on(
		'modula_swipebox_lightbox_after_open modula_swipebox_lightbox_next_slide modula_swipebox_lightbox_prev_slide ',
		function ( event, data, swipebox ) {
			const currentSwipeItem = jQuery(
				'#swipebox-slider .slide.current img'
			).attr( 'src' );
			if ( ! currentSwipeItem ) {
				modula_gallery_item_id = $(
					event.currentTarget.activeElement
				).data( 'image-id' );
			} else {
				modula_gallery_item_id = data.$element
					.find( 'a.tile-inner[href="' + currentSwipeItem + '"]' )
					.data( 'image-id' );
			}

			modula_change_hash(
				data.options.galleryID,
				modula_gallery_item_id
			);
		}
	);

	$( document ).on(
		'modula_magnific_lightbox_close modula_swipebox_lightbox_after_close modula_lightbox2_lightbox_close modula_prettyphoto_lightbox_close',
		function ( e, event, data, popup ) {
			if ( 'pushState' in history ) {
				history.pushState(
					null,
					null,
					window.location.pathname + window.location.search
				);
			}
		}
	);
} )( jQuery, window, document );
