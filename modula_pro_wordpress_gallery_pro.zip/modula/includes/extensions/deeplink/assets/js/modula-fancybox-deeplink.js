( function ( $, window, document ) {
	$( document ).on( 'modula_api_after_init', function ( event, data ) {
		let modula_gallery;

		// if ('undefined' == typeof data) {
		// 	// Get hash
		// 	var hash = window.location.hash.substr(1);

		// 	if(!hash){
		// 		return;
		// 	}

		// 	if(jQuery('a.modula-link').length){
		// 		jQuery('a.modula-link').each(function(){

		// 			var config = JSON.parse(jQuery(this).attr('data-config'));
		// 			var linkName = config.options.customLinkName;

		// 			// Check if a hash exists, and it's an modula Gallery Hash
		// 			if (!hash || hash.length == 0 || hash.indexOf(linkName) == -1) {
		// 				return;
		// 			}

		// 			modula_gallery = config;

		// 		});
		// 	}

		// } else {
		modula_gallery = data;

		if ( modula_gallery.options.modula_deeplink == 1 ) {
			modula_open_fancybox_deeplink(
				modula_gallery,
				modula_gallery.options.customLinkName
			);
		}
	} );

	$( document ).on(
		'modula_link_api_after_init',
		function ( event, modulaLink ) {
			if (
				'undefined' ===
					typeof modulaLink.config.options.modula_deeplink ||
				! modulaLink.config.options.modula_deeplink
			) {
				return;
			}
			let neededHash = false;
			if (
				'undefined' !== typeof modulaLink.config.options.customLinkName
			) {
				neededHash = modulaLink.config.options.customLinkName;
			}

			// Get hash
			const hash = window.location.hash.substr( 1 );

			// Check if a hash exists, and it's an modula Gallery Hash
			if (
				! neededHash ||
				! hash ||
				hash.length == 0 ||
				hash.indexOf( neededHash ) == -1
			) {
				return;
			}

			gallery_static_id = modulaLink.$el
				.attr( 'id' )
				.replace( 'jtg-', '' );

			const params = hash.split( '-' ), //break up other url params
				gallery_id = params.slice( -2, -1 )[ 0 ],
				index = params.slice( -1 )[ 0 ];

			if ( gallery_id != gallery_static_id ) {
				return;
			}

			modulaLink.open( index );
		}
	);

	/**
	 * Fired when a hash is detected in the URL bar
	 * @param modula_gallery
	 * @param customLinkName
	 */
	function modula_open_fancybox_deeplink( modula_gallery, customLinkName ) {
		if ( customLinkName.length == 0 ) {
			customLinkName = '!modulagallery';
		}

		if ( modula_gallery ) {
			if ( modula_gallery.$element ) {
				var gallery_static_id = modula_gallery.$element
					.attr( 'id' )
					.replace( 'jtg-', '' );
			} else {
				var gallery_static_id = modula_gallery.options.galleryID;
			}

			// Get hash
			const hash = window.location.hash.substr( 1 );

			// Check if a hash exists, and it's a modula Gallery Hash
			if (
				! hash ||
				hash.length == 0 ||
				hash.indexOf( `${ customLinkName }` ) == -1
			) {
				return;
			}

			const params = hash.split( '-' ), //break up other url params
				gallery_id = params.slice( -2, -1 )[ 0 ],
				image_id = params.slice( -1 )[ 0 ];

			if ( gallery_id != gallery_static_id ) {
				return;
			}

			// If here, hash is valid. We need to click the element that has the required image id
			if ( modula_gallery.$element ) {
				if ( 'undefined' === typeof fancyboxVer || 3 == fancyboxVer ) {
					var current_item = modula_gallery.$element.find(
						'a[data-image-id="' + image_id + '"]'
					);
				} else {
					var current_item =
						modula_gallery.$element.find( 'a.modula-item-link' );
					current_item = current_item[ image_id - 1 ];
					// if it's undefined, it may be old type of link from FancyBox3
					if ( 'undefined' === typeof current_item ) {
						// try get image by id. (fb3 style)
						current_item = modula_gallery.$element.find(
							'a[data-image-id="' + image_id + '"]'
						);
					}
				}
				if (
					'undefined' !== typeof current_item.length &&
					current_item.length > 1
				) {
					current_item = current_item[ 0 ];
				}
			} else {
				var current_item = jQuery(
					'a#jtg-' + modula_gallery.options.galleryID
				);
			}

			setTimeout( function () {
				current_item.click();
			}, 400 );
		}
	}

	// Function used to add the deeplink params to the social sharing URL
	$( document ).on( 'modula_social_url_params', function ( e ) {
		const imageID = e.detail.params.get( 'modula_image_id' ),
			galleryID = e.detail.params.get( 'modula_gallery_id' );
		const index = deeplinkSocials.images.findIndex(
			( item ) => item === imageID
		);
		// Add +1 to the index to match the deeplink index
		e.detail.params.set(
			'modula_deeplink',
			'#' + deeplinkSocials.slug + '-' + galleryID + '-' + ( index + 1 )
		);
	} );
} )( jQuery, window, document );
