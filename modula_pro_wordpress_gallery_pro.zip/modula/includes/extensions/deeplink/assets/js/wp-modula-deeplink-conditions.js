( function ( $ ) {
	'use strict';
	const modulaDeeplinkConditions = Backbone.Model.extend( {
		initialize( args ) {
			const rows = jQuery(
				'.modula-settings-container tr[data-container]'
			);
			const tabs = jQuery( '.modula-tabs .modula-tab' );

			this.set( 'rows', rows );
			this.set( 'tabs', tabs );

			this.initEvents();
			this.initValues();
		},

		initEvents() {
			this.listenTo(
				wp.Modula.Settings,
				'change:modula_deeplink',
				this.changeDeeplink
			);
		},

		initValues() {
			this.changeDeeplink(
				false,
				wp.Modula.Settings.get( 'modula_deeplink' )
			);
		},

		changeDeeplink( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter(
					'[data-container="modula_deeplink"]'
				),
				children = currentRow.data( 'children' );

			jQuery.each( children, function ( index, item ) {
				const child = jQuery( '[data-container="' + item + '"]' );

				if ( 0 == value ) {
					child.hide();
				} else {
					child.css( 'opacity', '1' );
					child
						.find( 'input, textarea, select, button' )
						.removeAttr( 'disabled' );
					child.show();
				}
			} );

			if ( 1 == value ) {
				currentRow.addClass( 'modula_accordion_open' );
			} else {
				currentRow.removeClass( 'modula_accordion_open' );
			}
		},
	} );

	$( document ).ready( function () {
		new modulaDeeplinkConditions();
	} );
} )( jQuery );
