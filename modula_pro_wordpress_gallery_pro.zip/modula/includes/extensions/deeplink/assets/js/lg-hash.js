/*! lg-hash - v1.0.4 - 2017-12-20
 * http://sachinchoolur.github.io/lightGallery
 * Copyright (c) 2017 Sachin N; Licensed GPLv3 */

( function ( root, factory ) {
	if ( typeof define === 'function' && define.amd ) {
		// AMD. Register as an anonymous module unless amdModuleId is set
		define( [ 'jquery' ], function ( a0 ) {
			return factory( a0 );
		} );
	} else if ( typeof exports === 'object' ) {
		// Node. Does not work with strict CommonJS, but
		// only CommonJS-like environments that support module.exports,
		// like Node.
		module.exports = factory( require( 'jquery' ) );
	} else {
		factory( jQuery );
	}
} )( this, function ( $ ) {
	( function () {
		'use strict';

		let defaults = {
				hash: true,
				modulaGallery: 0,
			},
			customLinkName;

		const Hash = function ( element ) {
			this.core = $( element ).data( 'lightGallery' );
			const modulaConfig = $( element ).data( 'config' );

			this.core.s = $.extend(
				{ modulaGallery: modulaConfig.galleryID },
				defaults,
				this.core.s
			);

			if ( this.core.s.hash ) {
				this.oldHash = window.location.hash;
				this.init();
			}

			return this;
		};

		Hash.prototype.init = function () {
			const _this = this;
			let _hash;
			customLinkName =
				'' == $( '.modula-gallery' ).data( 'config' ).hash
					? 'modulagallery'
					: $( '.modula-gallery' ).data( 'config' ).customLinkName;
			// Change hash value on after each slide transition
			_this.core.$el.on(
				'onAfterSlide.lg.tm',
				function ( event, prevIndex, index ) {
					const imageID = $( _this.core.$items[ index ] ).data(
						'image-id'
					);

					if ( history.replaceState ) {
						history.replaceState(
							null,
							null,
							window.location.pathname +
								window.location.search +
								`#!${ customLinkName }-` +
								_this.core.s.galleryId +
								'-' +
								imageID
						);
					} else {
						window.location.hash =
							`!${ customLinkName }-` +
							_this.core.s.modulaGallery +
							'-' +
							imageID;
					}
				}
			);

			// Listen hash change and change the slide according to slide value
			$( window ).on( 'hashchange.lg.hash', function () {
				_hash = window.location.hash;
				const parts = _hash.split( '-' );
				const _imageID = parseInt( parts[ 2 ], 10 );
				const imageElement = $( _this.core.$items ).filter(
					'[data-image-id=' + _imageID + ']'
				);
				const _idx = $( _this.core.$items ).index( imageElement );

				// it galleryId doesn't exist in the url close the gallery
				if (
					_hash.indexOf(
						`!${ customLinkName }-` + _this.core.s.modulaGallery
					) > -1
				) {
					_this.core.slide( _idx, false, false );
				} else if ( _this.core.lGalleryOn ) {
					_this.core.destroy();
				}
			} );
		};

		Hash.prototype.destroy = function () {
			if ( ! this.core.s.hash ) {
				return;
			}

			// Reset to old hash value
			if (
				this.oldHash &&
				this.oldHash.indexOf(
					`!${ customLinkName }-` + this.core.s.galleryId
				) < 0
			) {
				if ( history.replaceState ) {
					history.replaceState( null, null, this.oldHash );
				} else {
					window.location.hash = this.oldHash;
				}
			} else if ( history.replaceState ) {
				history.replaceState(
					null,
					document.title,
					window.location.pathname + window.location.search
				);
			} else {
				window.location.hash = '';
			}

			this.core.$el.off( '.lg.hash' );
		};

		$.fn.lightGallery.modules.hash = Hash;
	} )();
} );
