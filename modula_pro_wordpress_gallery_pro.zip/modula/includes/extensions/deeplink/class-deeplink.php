<?php
namespace Modula_Pro\Extensions\Deeplink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deeplink class for Modula Pro plugin.
 */
class Deeplink {
	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;
	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Filter Modula Deeplink Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'deeplink_tabs' ), 99 );

		// Filter Modula Deeplink Fields
		add_filter( 'modula_gallery_fields', array( $this, 'deeplink_fields' ) );

		// Field to register image id
		add_filter( 'modula_shortcode_item_data', array( $this, 'modula_pro_attachment_id' ), 50, 2 );

		// Sanitize custom url
		add_filter( 'modula_settings_field_sanitization', array( $this, 'sanitize_custom_link' ), 40, 4 );

		// Apply deeplink/hash options to fancybox
		add_filter( 'modula_fancybox_options', array( $this, 'deeplink_fancybox_options' ), 5, 2 );

		add_filter( 'modula_migrate_gallery_data', array( $this, 'deeplink_migrate' ), 25, 3 );

		// Add defaults
		add_filter( 'modula_lite_default_settings', array( $this, 'set_defaults' ) );

		new Enqueue();
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Deeplink object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Deeplink ) ) {
			self::$instance = new Deeplink();
		}

		return self::$instance;
	}



	/**
	 * @param $tabs
	 *
	 * @return mixed
	 *
	 * Add Modula Deeplink Tab
	 */
	public function deeplink_tabs( $tabs ) {

		if ( ! isset( $tabs['misc'] ) ) {
			$tabs['misc'] = array(
				'label'    => esc_html__( 'Miscellaneous', 'modula-pro' ),
				'icon'     => 'dashicons dashicons-image-filter',
				'priority' => 100,
			);
		}

		unset( $tabs['misc']['badge'] );

		return $tabs;
	}


	/**
	 * @param $fields
	 *
	 * @return mixed
	 *
	 * Add Modula Deeplink field
	 */
	public function deeplink_fields( $fields ) {

		if ( ! isset( $fields['misc'] ) || ! is_array( $fields['misc'] ) ) {
			$fields['misc'] = array();
		}

		$fields['misc']['modula_deeplink'] = array(
			'name'     => __( 'Deeplink', 'modula-pro' ),
			'type'     => 'toggle',
			'default'  => 0,
			'priority' => 15,
			'children' => array( 'customLinkName' ),
		);
		$fields['misc']['customLinkName']  = array(
			'name'     => esc_html__( 'Custom link name', 'modula-pro' ),
			'type'     => 'text',
			'default'  => 'modulagallery',
			'priority' => 20,
			'is_child' => true,
			'afterrow' => esc_html__( 'If using filters, in order for deeplink to work properly please either set `All` as default filter or enable `Reload Page On Filter Click ` setting.', 'modula-pro' ),
		);

		return $fields;
	}

	/**
	 * Add deeplink settings to Modula's defaults
	 *
	 * @param $defaults
	 *
	 * @return mixed
	 */
	public function set_defaults( $defaults ) {

		$defaults['modula_deeplink'] = 0;
		$defaults['customLinkName']  = 'modulagallery';

		return $defaults;
	}



	/**
	 * Add attachment id to item data
	 *
	 * @param $item_data
	 * @param $image
	 *
	 * @return mixed
	 */
	public function modula_pro_attachment_id( $item_data ) {
		if ( isset( $item_data['link_attributes']['data-fancybox'] ) ) {
			$item_data['link_attributes']['data-fancybox'] = str_replace( 'jtg', '!modulagallery', $item_data['link_attributes']['data-fancybox'] );
		}

		return $item_data;
	}

	/**
	 * Add deeplink options to Fancybox
	 *
	 * @param $fancybox_options
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function deeplink_fancybox_options( $fancybox_options, $settings ) {

		if ( ! isset( $settings['modula_deeplink'] ) || 1 !== absint( $settings['modula_deeplink'] ) ) {
			return $fancybox_options;
		}

		if ( isset( $settings['gallery_id'] ) ) {
			if ( isset( $settings['customLinkName'] ) && '' !== $settings['customLinkName'] ) {
				$slug = $settings['customLinkName'] . str_replace( 'jtg', '', $settings['gallery_id'] );
			} else {
				$slug = '!modulagallery' . str_replace( 'jtg', '', $settings['gallery_id'] );
			}

			$fancybox_options['Hash'] = true;
			$fancybox_options['slug'] = $slug;
		}

		return $fancybox_options;
	}

	/**
	 * Function for sanitization of custom linl
	 *
	 * @since 1.0.4
	 *
	 * @param string $sanitized_value
	 * @param string $value
	 * @param string $field_id
	 *
	 * @return string $sanitized_value
	 */
	public function sanitize_custom_link( $sanitized_value, $value, $field_id ) {

		if ( 'customLinkName' === $field_id ) {
			$sanitized_value = sanitize_title( $value );
		}
		return $sanitized_value;
	}

	/**
	 * Add deeplink options to Modula migrator
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.4
	 */
	public function deeplink_migrate( $modula_settings, $guest_settings, $source ) {

		if ( $source ) {
			switch ( $source ) {
				case 'envira':
					if ( isset( $guest_settings['config']['deeplinking'] ) && 1 === absint( $guest_settings['config']['deeplinking'] ) ) {
						$modula_settings['modula_deeplink'] = 1;
					}
					break;
			}
		}

		return $modula_settings;
	}
}
