<?php
/**
 * Pure helpers for Standalone CPT rewrite args and public URLs.
 *
 * Kept free of WordPress I/O so behaviour can be unit-tested without bootstrapping WP.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Standalone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Standalone_Rewrite
 */
class Standalone_Rewrite {

	/**
	 * Default standalone option shape.
	 *
	 * @return array
	 */
	public static function default_settings() {
		return array(
			'gallery' => array(
				'enable_rewrite' => 'disabled',
				'slug'           => 'modula-gallery',
			),
			'album'   => array(
				'enable_rewrite' => 'disabled',
				'slug'           => 'modula-album',
			),
		);
	}

	/**
	 * Deep-merge stored standalone settings with defaults (per gallery/album branch).
	 *
	 * {@see wp_parse_args()} is shallow: a stored `album` array without `slug` would
	 * otherwise replace the whole default branch and drop the fallback slug.
	 *
	 * @param array $stored Option value from the database.
	 * @return array
	 */
	public static function merge_settings( $stored ) {
		$defaults = self::default_settings();
		$stored   = is_array( $stored ) ? $stored : array();

		$merged = $defaults;
		foreach ( array( 'gallery', 'album' ) as $branch ) {
			$branch_stored = isset( $stored[ $branch ] ) && is_array( $stored[ $branch ] )
				? $stored[ $branch ]
				: array();
			$merged[ $branch ] = array_merge( $defaults[ $branch ], $branch_stored );
		}

		return $merged;
	}

	/**
	 * Whether rewrite is enabled for a branch.
	 *
	 * @param array  $settings Merged settings.
	 * @param string $branch   `gallery` or `album`.
	 * @return bool
	 */
	public static function is_enabled( $settings, $branch ) {
		return isset( $settings[ $branch ]['enable_rewrite'] )
			&& 'enabled' === $settings[ $branch ]['enable_rewrite'];
	}

	/**
	 * Rewrite slug for a branch, with safe fallback.
	 *
	 * Callers that persist settings should sanitize the slug (e.g. sanitize_title) before or after.
	 *
	 * @param array  $settings Merged settings.
	 * @param string $branch   `gallery` or `album`.
	 * @return string
	 */
	public static function rewrite_slug( $settings, $branch ) {
		$defaults = self::default_settings();
		$fallback = $defaults[ $branch ]['slug'];
		$slug     = isset( $settings[ $branch ]['slug'] ) ? (string) $settings[ $branch ]['slug'] : $fallback;
		$slug     = trim( $slug, '/' );
		return '' !== $slug ? $slug : $fallback;
	}

	/**
	 * Apply Standalone rewrite visibility onto CPT registration args.
	 *
	 * @param array  $cpt_args Base register_post_type args.
	 * @param string $branch   `gallery` or `album`.
	 * @param array  $settings Merged standalone settings.
	 * @return array
	 */
	public static function apply_to_cpt_args( $cpt_args, $branch, $settings ) {
		if ( ! is_array( $cpt_args ) ) {
			$cpt_args = array();
		}

		if ( ! self::is_enabled( $settings, $branch ) ) {
			return $cpt_args;
		}

		$cpt_args['rewrite']            = array( 'slug' => self::rewrite_slug( $settings, $branch ) );
		$cpt_args['public']             = true;
		$cpt_args['publicly_queryable'] = true;

		return $cpt_args;
	}

	/**
	 * Build a pretty public path for a standalone CPT post.
	 *
	 * @param string $rewrite_slug    Base path (e.g. modula-album).
	 * @param string $slug_path       Already-resolved post slug (never empty), under its
	 *                                ancestors' slugs for a nested album (parent/child).
	 * @return string Path without leading slash, e.g. modula-album/my-album
	 */
	public static function public_path( $rewrite_slug, $slug_path ) {
		$rewrite_slug = trim( (string) $rewrite_slug, '/' );
		$slug_path    = trim( (string) $slug_path, '/' );

		return $rewrite_slug . '/' . $slug_path;
	}

	/**
	 * Resolve a usable post slug for standalone pretty URLs.
	 *
	 * @param string $post_name       Stored post_name.
	 * @param string $sanitized_title Result of sanitize_title( post_title ).
	 * @param int    $post_id         Post id.
	 * @param string $fallback_prefix Prefix when both name and title are empty (gallery|album).
	 * @return string
	 */
	public static function resolve_post_slug( $post_name, $sanitized_title, $post_id, $fallback_prefix ) {
		$post_name = (string) $post_name;
		if ( '' !== $post_name && 'auto-draft' !== $post_name ) {
			return $post_name;
		}

		$sanitized_title = (string) $sanitized_title;
		if ( '' !== $sanitized_title ) {
			return $sanitized_title;
		}

		return $fallback_prefix . '-' . (int) $post_id;
	}
}
