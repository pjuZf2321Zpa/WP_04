<?php

namespace Modula_Pro\Extensions\Standalone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-standalone-rewrite.php';

class Standalone {
	/**
	 * Standalone branch of each post type whose shortcode dropdown gets the permalink row.
	 *
	 * @var array<string, string>
	 */
	const PERMALINK_ROW_BRANCHES = array(
		'modula-gallery' => 'gallery',
		'modula-album'   => 'album',
	);

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;
	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'set_admin_requirements' ), 25 );
		add_filter( 'modula_cpt_args', array( $this, 'alterate_cpt_args' ) );
		add_filter( 'modula_album_cpt_args', array( $this, 'alterate_album_args' ) );
		add_action( 'the_content', array( $this, 'standalone_insert_shortcode' ) );
		add_action( 'modula_extension_modula-standalone_activated', array( $this, 'activate_standalone' ) );
		add_action( 'modula_shortcode_after_items', 'modula_add_back_to_album_button', 110 );
		add_filter( 'modula_admin_aditional_shortcodes_dropdown', array( $this, 'add_gallery_permalink_shortcode_row' ), 11, 2 );
		add_filter( 'modula_settings_api_pre_update_modula_standalone', array( $this, 'prepare_settings_for_save' ), 10, 2 );
	}

	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.0.7
	 */
	public function set_admin_requirements() {
		add_filter( 'modula_admin_page_tabs', array( $this, 'add_settings_tab' ) );
		add_action( 'modula_admin_tab_standalone', array( $this, 'render_settings_tab' ) );
		$this->register_settings();
	}

	/**
	 * @param $tabs
	 * @return mixed
	 *
	 * Add Modula Albums Standalone settings tab
	 */
	public function add_settings_tab( $tabs ) {
		$tabs['standalone'] = array(
			'label'    => esc_html__( 'Standalone', 'modula-pro' ),
			'priority' => 20,
		);

		return $tabs;
	}

	/**
	 * Render settings tab
	 */
	public function render_settings_tab() {
		include 'templates/standalone.php';
	}

	/**
	 * Register standalone settings
	 */
	public function register_settings() {
		// creates our settings in the options table
		register_setting( 'modula_standalone', 'modula_standalone', array( $this, 'sanitize_option' ) );
	}

	/**
	 * Merge + sanitize incoming Standalone settings before they are written.
	 *
	 * Used by the React general-settings REST save (filter) and by register_setting.
	 *
	 * @param array $current Incoming settings payload.
	 * @return array
	 */
	public function prepare_settings_for_save( $current ) {
		$current  = is_array( $current ) ? $current : array();
		$existing = Standalone_Rewrite::merge_settings( get_option( 'modula_standalone', array() ) );

		foreach ( array( 'gallery', 'album' ) as $branch ) {
			if ( ! isset( $current[ $branch ] ) || ! is_array( $current[ $branch ] ) ) {
				$current[ $branch ] = $existing[ $branch ];
				continue;
			}

			// Legacy checkbox UI omits enable_rewrite when unchecked; React always sends the string.
			if ( ! array_key_exists( 'enable_rewrite', $current[ $branch ] ) ) {
				$current[ $branch ]['enable_rewrite'] = 'disabled';
			}

			$current[ $branch ] = array_merge( $existing[ $branch ], $current[ $branch ] );
			unset( $current[ $branch ]['enable_rewrite_description'] );
		}

		$normalized = $this->normalize_standalone_settings( $current );

		// Ensure a flush is scheduled for both React (pre-update filter) and classic register_setting saves.
		update_option( 'modula_flush_rewrite_rules', 1 );

		return $normalized;
	}

	/**
	 * register_setting sanitize callback.
	 *
	 * @param array $current Incoming settings.
	 * @return array
	 */
	public function sanitize_option( $current ) {
		return $this->prepare_settings_for_save( $current );
	}

	/**
	 * Normalize enable flags and slugs after merge.
	 *
	 * @param array $current Settings.
	 * @return array
	 */
	private function normalize_standalone_settings( $current ) {
		$current = Standalone_Rewrite::merge_settings( is_array( $current ) ? $current : array() );

		if ( ! isset( $current['gallery']['enable_rewrite'] ) || 'disabled' === $current['gallery']['enable_rewrite'] ) {
			$current['gallery']['enable_rewrite'] = 'disabled';
		} else {
			$current['gallery']['enable_rewrite'] = 'enabled';
		}

		if ( ! isset( $current['album']['enable_rewrite'] ) || 'disabled' === $current['album']['enable_rewrite'] ) {
			$current['album']['enable_rewrite'] = 'disabled';
		} else {
			$current['album']['enable_rewrite'] = 'enabled';
		}

		$current['gallery']['slug'] = sanitize_title( Standalone_Rewrite::rewrite_slug( $current, 'gallery' ) );
		$current['album']['slug']   = sanitize_title( Standalone_Rewrite::rewrite_slug( $current, 'album' ) );

		if ( '' === $current['gallery']['slug'] ) {
			$current['gallery']['slug'] = Standalone_Rewrite::default_settings()['gallery']['slug'];
		}
		if ( '' === $current['album']['slug'] ) {
			$current['album']['slug'] = Standalone_Rewrite::default_settings()['album']['slug'];
		}

		unset( $current['gallery']['enable_rewrite_description'], $current['album']['enable_rewrite_description'] );

		return $current;
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Standalone object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Standalone ) ) {
			self::$instance = new Standalone();
		}
		return self::$instance;
	}

	/**
	 * Read merged standalone settings.
	 *
	 * @return array
	 */
	private function get_settings() {
		$defaults = apply_filters( 'modula_standalone_default_settings', Standalone_Rewrite::default_settings() );
		$stored   = get_option( 'modula_standalone', array() );
		$stored   = is_array( $stored ) ? $stored : array();

		// Prefer filterable defaults, still deep-merged per branch.
		$merged = Standalone_Rewrite::default_settings();
		foreach ( array( 'gallery', 'album' ) as $branch ) {
			$default_branch = isset( $defaults[ $branch ] ) && is_array( $defaults[ $branch ] )
				? array_merge( $merged[ $branch ], $defaults[ $branch ] )
				: $merged[ $branch ];
			$stored_branch  = isset( $stored[ $branch ] ) && is_array( $stored[ $branch ] )
				? $stored[ $branch ]
				: array();
			$merged[ $branch ] = array_merge( $default_branch, $stored_branch );
		}

		return $merged;
	}

	/**
	 * @param $cpt_args
	 * @return mixed
	 */
	public function alterate_cpt_args( $cpt_args ) {
		$cpt_args = Standalone_Rewrite::apply_to_cpt_args( $cpt_args, 'gallery', $this->get_settings() );
		if ( isset( $cpt_args['rewrite']['slug'] ) ) {
			$cpt_args['rewrite']['slug'] = sanitize_title( $cpt_args['rewrite']['slug'] );
		}
		return $cpt_args;
	}

	/**
	 * @param $cpt_args
	 * @return mixed
	 */
	public function alterate_album_args( $cpt_args ) {
		$cpt_args = Standalone_Rewrite::apply_to_cpt_args( $cpt_args, 'album', $this->get_settings() );
		if ( isset( $cpt_args['rewrite']['slug'] ) ) {
			$cpt_args['rewrite']['slug'] = sanitize_title( $cpt_args['rewrite']['slug'] );
		}
		return $cpt_args;
	}


	public function standalone_insert_shortcode( $content ) {

		// Check if we are on a single Post.
		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		// If not the proper post type (Modula), return early.
		$post_type = get_query_var( 'post_type' );

		if ( 'modula-gallery' === $post_type ) {
			return $this->insert_gallery_shortcode( $content );
		}

		if ( 'modula-album' === $post_type ) {
			return $this->insert_album_shortcode( $content );
		}

		// Pretty permalinks for hierarchical albums may not populate post_type query var.
		if ( is_singular( 'modula-gallery' ) ) {
			return $this->insert_gallery_shortcode( $content );
		}

		if ( is_singular( 'modula-album' ) ) {
			return $this->insert_album_shortcode( $content );
		}

		return $content;
	}

	public function insert_gallery_shortcode( $content ) {
		global $post;

		$id = ( is_singular( 'modula-gallery' ) && $post instanceof \WP_Post )
			? (int) $post->ID
			: (int) get_query_var( 'p' );

		if ( $id < 1 && $post instanceof \WP_Post ) {
			$id = (int) $post->ID;
		}

		$shortcode = '[modula id="' . $id . '"]';

		return $shortcode . $content;
	}

	public function insert_album_shortcode( $content ) {
		global $post;

		$id = ( is_singular( 'modula-album' ) && $post instanceof \WP_Post )
			? (int) $post->ID
			: (int) get_query_var( 'p' );

		if ( $id < 1 && $post instanceof \WP_Post ) {
			$id = (int) $post->ID;
		}

		$shortcode = '[modula-album id="' . $id . '"]';

		return $shortcode . $content;
	}

	public function activate_standalone() {
		flush_rewrite_rules();
	}

	/**
	 * Add the public gallery or album URL to the shortcode dropdown when standalone
	 * pretty URLs are enabled for its branch.
	 *
	 * The name predates the album branch; it stays for callers that remove the hook.
	 *
	 * @param array   $shortcodes Rows keyed by id.
	 * @param WP_Post $post       Gallery or album post.
	 * @return array
	 */
	public function add_gallery_permalink_shortcode_row( $shortcodes, $post ) {
		if ( ! $post instanceof \WP_Post || ! isset( self::PERMALINK_ROW_BRANCHES[ $post->post_type ] ) ) {
			return $shortcodes;
		}

		if ( class_exists( '\Modula_Pro\Extensions\Extensions' )
			&& ! \Modula_Pro\Extensions\Extensions::get_instance()->extension_enabled( 'modula-standalone' ) ) {
			return $shortcodes;
		}

		$branch   = self::PERMALINK_ROW_BRANCHES[ $post->post_type ];
		$settings = $this->get_settings();

		if ( ! Standalone_Rewrite::is_enabled( $settings, $branch ) ) {
			return $shortcodes;
		}

		$url = $this->get_standalone_public_url( $post, Standalone_Rewrite::rewrite_slug( $settings, $branch ), $branch );
		if ( ! is_string( $url ) || '' === $url ) {
			return $shortcodes;
		}

		$shortcodes['standalone_permalink'] = array(
			'code'        => $url,
			'description' => $this->permalink_row_description( $branch ),
		);

		return $shortcodes;
	}

	/**
	 * @param string $branch `gallery` or `album`.
	 * @return string Description of the permalink row in the shortcode dropdown.
	 */
	private function permalink_row_description( $branch ) {
		$descriptions = array(
			'gallery' => esc_html__(
				'Direct link to this gallery’s public page (standalone pretty URLs). Copy and share it or open it in a new tab.',
				'modula-pro'
			),
			'album'   => esc_html__(
				'Direct link to this album’s public page (standalone pretty URLs). Copy and share it or open it in a new tab.',
				'modula-pro'
			),
		);

		return $descriptions[ $branch ];
	}

	/**
	 * Pretty public URL for a standalone gallery or album.
	 *
	 * {@see get_permalink()} returns query-style URLs when rewrite is off or the post
	 * has no post_name; standalone still uses rewrite base + post slug on the front.
	 *
	 * @param \WP_Post|int $post          Gallery or album post (or ID).
	 * @param string       $rewrite_slug  Base path from Standalone settings.
	 * @param string       $fallback_prefix Prefix for empty slug fallback (gallery|album).
	 * @return string
	 */
	public function get_standalone_public_url( $post, $rewrite_slug = '', $fallback_prefix = 'gallery' ) {
		$post = get_post( $post );
		if ( ! $post instanceof \WP_Post ) {
			return '';
		}

		if ( ! get_option( 'permalink_structure' ) ) {
			return (string) get_permalink( $post );
		}

		$settings = $this->get_settings();
		$branch   = 'modula-album' === $post->post_type ? 'album' : 'gallery';

		if ( '' === $rewrite_slug ) {
			if ( ! Standalone_Rewrite::is_enabled( $settings, $branch ) ) {
				return (string) get_permalink( $post );
			}
			$rewrite_slug = Standalone_Rewrite::rewrite_slug( $settings, $branch );
		}

		$resolved = Standalone_Rewrite::resolve_post_slug(
			(string) $post->post_name,
			sanitize_title( $post->post_title ),
			(int) $post->ID,
			$fallback_prefix
		);

		$path = Standalone_Rewrite::public_path( $rewrite_slug, $this->nested_slug_path( $post, $resolved ) );

		return user_trailingslashit( home_url( $path ) );
	}

	/**
	 * The post's slug under its ancestors' slugs, root first, as WordPress serves
	 * a hierarchical type: a child album lives at `{base}/{parent}/{child}/`.
	 * Galleries aren't hierarchical, so WordPress ignores their post_parent and
	 * so does this. The ancestors' part is core's get_page_uri() of the parent;
	 * the post's own slug keeps the Standalone fallbacks get_page_uri() lacks.
	 *
	 * @param \WP_Post $post          Gallery or album post.
	 * @param string   $resolved_slug The post's own resolved slug.
	 * @return string Slug path without leading or trailing slash.
	 */
	private function nested_slug_path( $post, $resolved_slug ) {
		if ( ! is_post_type_hierarchical( $post->post_type ) || ! $post->post_parent ) {
			return $resolved_slug;
		}

		$parent_uri = get_page_uri( (int) $post->post_parent );
		if ( ! is_string( $parent_uri ) || '' === $parent_uri ) {
			return $resolved_slug;
		}

		return $parent_uri . '/' . $resolved_slug;
	}

	/**
	 * Public URL for a gallery or album member tile when Standalone should navigate.
	 *
	 * Prefers core permalinks once the CPT is rewrite-enabled (handles hierarchical albums).
	 * Falls back to the Standalone path builder when get_permalink() still returns a query URL.
	 *
	 * @param int $post_id Member post ID.
	 * @return string
	 */
	public function get_member_standalone_url( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return '';
		}

		$branch   = 'modula-album' === $post->post_type ? 'album' : 'gallery';
		$settings = $this->get_settings();

		if ( ! Standalone_Rewrite::is_enabled( $settings, $branch ) ) {
			return (string) get_permalink( $post );
		}

		$permalink = (string) get_permalink( $post );
		if ( '' !== $permalink && false === strpos( $permalink, '?' ) ) {
			return $permalink;
		}

		return $this->get_standalone_public_url(
			$post,
			Standalone_Rewrite::rewrite_slug( $settings, $branch ),
			$branch
		);
	}
}
