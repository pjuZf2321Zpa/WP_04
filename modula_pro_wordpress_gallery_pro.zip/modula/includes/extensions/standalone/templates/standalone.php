<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
//phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
$mp_defaults = apply_filters(
	'modula_standalone_default_settings',
	\Modula_Pro\Extensions\Standalone\Standalone_Rewrite::default_settings()
);
$mp_settings = \Modula_Pro\Extensions\Standalone\Standalone_Rewrite::merge_settings( get_option( 'modula_standalone', array() ) );
foreach ( array( 'gallery', 'album' ) as $branch ) {
	if ( isset( $mp_defaults[ $branch ] ) && is_array( $mp_defaults[ $branch ] ) ) {
		$mp_settings[ $branch ] = array_merge( $mp_defaults[ $branch ], $mp_settings[ $branch ] );
	}
}


?>
<style type="text/css">
	/* Toggles */
	.modula-toggle {
		position: relative;
		position: relative;
		user-select: none;
		display: inline-block;
	}

	.modula-toggle__items {
		box-sizing: border-box;
		display: inline-block;
		position: relative;
	}
	.modula-toggle__items > * {
		box-sizing: inherit;
	}

	.modula-toggle__input[type=checkbox] {
		border-radius: 2px;
		border: 2px solid #6c7781;
		margin-right: 12px;
		transition: none;
		height: 100%;
		left: 0;
		top: 0;
		margin: 0;
		padding: 0;
		opacity: 0;
		position: absolute;
		width: 100%;
		z-index: 1; }

	.modula-toggle__track {
		background-color: #fff;
		border: 2px solid #6c7781;
		border-radius: 9px;
		display: inline-block;
		height: 18px;
		width: 36px;
		vertical-align: top;
		transition: background .2s ease; }

	.modula-toggle__thumb {
		background-color: #6c7781;
		border: 5px solid #6c7781;
		border-radius: 50%;
		display: block;
		height: 10px;
		width: 10px;
		position: absolute;
		left: 4px;
		top: 4px;
		transition: transform .2s ease; }

	.modula-toggle__off {
		position: absolute;
		right: 6px;
		top: 6px;
		color: #6c7781;
		fill: currentColor; }

	.modula-toggle__on {
		position: absolute;
		top: 6px;
		left: 8px;
		border: 1px solid #fff;
		outline: 1px solid transparent;
		outline-offset: -1px;
		display: none; }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__track {
		background-color: var(--wp-admin-theme-color, #2271b1);
		border: 9px solid transparent; }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__thumb {
		background-color: #fff;
		border-width: 0;
		transform: translateX(18px); }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__off {
		display: none; }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__on {
		display: inline-block; }
</style>
<div class="row">
	<form method="post" action="options.php">

		<?php settings_fields( 'modula_standalone' ); ?>

		<table class="form-table">
			<tbody>
				<tr valign="top" data-settings="enable_rewrite_gallery">
					<th scope="row" valign="top">
						<?php esc_html_e( 'Enable Galleries Link', 'modula-pro' ); ?>
					</th>
					<td>
						<div class="modula-toggle">
							<input class="modula-toggle__input" type="checkbox" <?php checked( 'enabled', $mp_settings['gallery']['enable_rewrite'], true ); ?> name="modula_standalone[gallery][enable_rewrite]" value="enabled">
							<div class="modula-toggle__items">
								<span class="modula-toggle__track"></span>
								<span class="modula-toggle__thumb"></span>
								<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 6 6"><path d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path></svg>
								<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 2 6"><path d="M0 0h2v6H0z"></path></svg>
							</div>
						</div>
					</td>
				</tr>
				<tr valign="top" data-settings="gallery_slug">
					<th scope="row" valign="top">
						<?php esc_html_e( 'Gallery Slug', 'modula-pro' ); ?>
					</th>
					<td>
						<input type="text" name="modula_standalone[gallery][slug]" value="<?php echo esc_attr( $mp_settings['gallery']['slug'] ); ?>" class="wide-text">
					</td>
				</tr>
				<tr valign="top" data-settings="enable_rewrite_album">
					<th scope="row" valign="top">
						<?php esc_html_e( 'Enable Albums Link', 'modula-pro' ); ?>
					</th>
					<td>
						<div class="modula-toggle">
							<input class="modula-toggle__input" type="checkbox" <?php checked( 'enabled', $mp_settings['album']['enable_rewrite'], true ); ?> name="modula_standalone[album][enable_rewrite]" value="enabled">
							<div class="modula-toggle__items">
								<span class="modula-toggle__track"></span>
								<span class="modula-toggle__thumb"></span>
								<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 6 6"><path d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path></svg>
								<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 2 6"><path d="M0 0h2v6H0z"></path></svg>
							</div>
						</div>
					</td>
				</tr>
				<tr valign="top" data-settings="album_slug">
					<th scope="row" valign="top">
						<?php esc_html_e( 'Album Slug', 'modula-pro' ); ?>
					</th>
					<td>
						<input type="text" name="modula_standalone[album][slug]" value="<?php echo esc_attr( $mp_settings['album']['slug'] ); ?>" class="wide-text">
					</td>
				</tr>
				<?php do_action( 'modula_standalone_settings_tab', $mp_settings ); ?>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
</div>
