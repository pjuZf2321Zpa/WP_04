<?php
namespace Modula_Pro\Extensions\Standalone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-standalone-rewrite.php';

class Enqueue {
	private $extension_url = 'includes/extensions/standalone';

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	public function enqueue_scripts( $hook ) {
		if ( 'modula-gallery_page_modula' !== $hook ) {
			return;
		}

		wp_enqueue_script( 'modula-standalone', \MODULA_PRO_URL . $this->extension_url . '/assets/js/admin/wp-modula-standalone.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );

		$settings = Standalone_Rewrite::merge_settings( get_option( 'modula_standalone', array() ) );
		wp_localize_script( 'modula-standalone', 'modulaStandalone', $settings );
	}
}
