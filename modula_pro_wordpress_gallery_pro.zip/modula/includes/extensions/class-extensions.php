<?php

/**
 * Extensions class for Modula Pro plugin.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions;

use Modula_Pro\Extensions\Slider\Albums_Slider;
use Modula_Pro\Extensions\Advanced_Shortcodes\Advanced_Shortcodes;
use Modula_Pro\Extensions\Albums\Albums;
use Modula_Pro\Extensions\Comments\Comments;
use Modula_Pro\Extensions\Content_Galleries\Content_Galleries;
use Modula_Pro\Extensions\Deeplink\Deeplink;
use Modula_Pro\Extensions\Defaults\Defaults;
use Modula_Pro\Extensions\Download\Download;
use Modula_Pro\Extensions\Exif\Exif;
use Modula_Pro\Extensions\Fullscreen\Fullscreen;
use Modula_Pro\Extensions\Image_Guardian\Image_Guardian;
use Modula_Pro\Extensions\Image_Licensing\Image_Licensing;
use Modula_Pro\Extensions\Pagination\Pagination;
use Modula_Pro\Extensions\Password_Protect\Password_Protect;
use Modula_Pro\Extensions\Roles\Roles;
use Modula_Pro\Extensions\Slider\Slider;
use Modula_Pro\Extensions\Slideshow\Slideshow;
use Modula_Pro\Extensions\Standalone\Standalone;
use Modula_Pro\Extensions\Zoom\Zoom;
use Modula_Pro\Extensions\Image_Proofing\Image_Proofing;
use Modula_Pro\Extensions\Instagram\Instagram;
use Modula_Pro\Extensions\Speedup\Speedup;
use Modula_Pro\Extensions\Utils\Plugin;
use Modula_Pro\Extensions\Video\Video;
use Modula_Pro\Extensions\Watermark\Watermark;
use Modula_Pro\Extensions\Whitelabel\Whitelabel;

/**
 * Extensions class for Modula Pro plugin.
 */
class Extensions {
	/**
	 * Modula Settings section (`?section=`) holding each extension's settings. Extensions
	 * without settings of their own are not listed.
	 *
	 * @var array<string,string>
	 */
	const SETTINGS_SECTIONS = array(
		'modula-standalone'          => 'galleries',
		'modula-advanced-shortcodes' => 'galleries',
		'modula-image-licensing'     => 'galleries',
		'modula-video'               => 'connections',
		'modula-instagram'           => 'connections',
		'modula-watermark'           => 'protection',
		'modula-image-guardian'      => 'protection',
		'modula-roles'               => 'roles',
		'modula-speedup'             => 'performance',
	);

	/**
	 * Settings subtabs badged with the plan of the extension they configure.
	 *
	 * @var array<string,string> Subtab => prefixed extension slug.
	 */
	const BADGED_SUBTABS = array(
		'standalone'      => 'modula-standalone',
		'compression'     => 'modula-speedup',
		'shortcodes'      => 'modula-advanced-shortcodes',
		'watermark'       => 'modula-watermark',
		'image_licensing' => 'modula-image-licensing',
		'roles'           => 'modula-roles',
	);

	/**
	 * Settings subtabs whose fields, not the subtab, carry the plan badge of the extension
	 * each field configures.
	 *
	 * @var array<string,array<string,string>> Subtab => field id => prefixed extension slug.
	 */
	const BADGED_SUBTAB_FIELDS = array(
		'social_media' => array(
			'instagram'         => 'modula-instagram',
			'youtube'           => 'modula-video',
			'vimeo'             => 'modula-video',
			'vimeo_credentials' => 'modula-video',
		),
	);

	/**
	 * Plan membership Pro 3.0.15 shipped, frozen for a Lite older than 3.0.14 (no extension
	 * catalog). Its list dividers and duplicate Fullscreen entry are dropped. Lite's catalog
	 * stays the only source when present; never edit this copy, delete it once Pro requires
	 * Lite 3.0.14 (ADR 0048 in Lite).
	 *
	 * @var array<string,string[]>
	 */
	const LEGACY_PLAN_MAP = array(
		'starter'  => array(
			'modula-video',
			'modula-slideshow',
		),
		'trio'     => array(
			'modula-video',
			'modula-slideshow',
			'modula-speedup',
			'modula-standalone',
			'modula-advanced-shortcodes',
			'modula-image-guardian',
			'modula-password-protect',
			'modula-albums',
			'modula-slider',
			'modula-fullscreen',
			'modula-image-licensing',
			'modula-instagram',
			'modula-content-galleries',
		),
		'business' => array(
			'modula-video',
			'modula-slideshow',
			'modula-speedup',
			'modula-standalone',
			'modula-advanced-shortcodes',
			'modula-image-guardian',
			'modula-password-protect',
			'modula-albums',
			'modula-slider',
			'modula-fullscreen',
			'modula-image-licensing',
			'modula-instagram',
			'modula-content-galleries',
			'modula-defaults',
			'modula-roles',
			'modula-zoom',
			'modula-exif',
			'modula-watermark',
			'modula-deeplink',
			'modula-pagination',
			'modula-whitelabel',
			'modula-image-proofing',
			'modula-comments',
			'modula-download',
		),
	);

	/**
	 * Class instance.
	 *
	 * @var Extensions
	 */
	private static $instance;
	private static $active_extensions_cache = array();
	/**
	 * Extensions just re-enabled from deleted plugins (same request). Not deactivated by load_extensions.
	 *
	 * @var array
	 */
	private static $just_reenabled_extensions = array();
	/**
	 * Rows of the last get_extensions() call (Lite's Insights reads them here).
	 *
	 * @var array
	 */
	public $extensions = array();
	/**
	 * Active extensions option
	 *
	 * @var string
	 */
	private $active_extensions = 'modula_pro_active_extensions';
	/**
	 * Current plan option
	 *
	 * @var string
	 */
	private $current_plan = 'modula_pro_current_plan';
	/**
	 * Initial run option
	 *
	 * @var string
	 */
	private $initial_run = 'modula_pro_extension_initial_run';
	/**
	 * Pro fields
	 *
	 * @var array
	 */
	private $pro_fields = array();
	/**
	 * Lite's catalog plan map, read on first use (get_plan_map()).
	 *
	 * @var array<string,string[]>
	 */
	private $plan_map = array();
	/**
	 * Plugin instance
	 *
	 * @var Plugin
	 */
	private $plugin_instance;
	/**
	 * Initialize the extensions.
	 */
	public function __construct() {
		$this->plugin_instance = Plugin::get_instance();

		$this->set_pro_fields();

		// Lite's Modula_Extension_States::FILTER, named literally: an older Lite lacks the class.
		add_filter( 'modula_extension_states', array( $this, 'report_extension_states' ) );
		add_action( 'plugins_loaded', array( $this, 'mark_for_deletion' ), 10 );
		add_action( 'plugins_loaded', array( $this, 'enable_extensions_after_deletion' ), 20 );
		add_action( 'plugins_loaded', array( $this, 'load_extensions' ), 30 );
		add_filter( 'modula_admin_page_subtabs', array( $this, 'replace_proper_badges' ) );
		add_filter( 'modula_admin_page_tabs', array( $this, 'unset_badges' ) );
		add_filter( 'modula_pro_fields', array( $this, 'fields' ) );
		add_filter( 'modula_gallery_tabs', array( $this, 'smart_upsells_tabs' ), 99 );
		add_action( 'modula_admin_page_link', array( $this, 'remove_menu_links' ), 35, 1 );
	}

	/**
	 * Get the instance of the class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Extensions ) ) {
			self::$instance = new Extensions();
		}

		return self::$instance;
	}

	/**
	 * Whether Lite provides the extension catalog (Lite 3.0.14 and later).
	 *
	 * @return bool
	 */
	private function has_catalog() {
		return class_exists( 'Modula_Extension_Catalog' );
	}

	/**
	 * Extensions each plan includes, from Lite's extension catalog (ADR 0048 in Lite). An older
	 * Lite has no catalog, so Pro falls back to the membership it shipped in 3.0.15 and a site
	 * that updates Pro before Lite keeps its extensions running.
	 *
	 * @return array<string,string[]> Plan => extension slugs, plans from the cheapest.
	 */
	private function get_plan_map() {
		if ( ! $this->has_catalog() ) {
			return self::LEGACY_PLAN_MAP;
		}

		if ( array() === $this->plan_map ) {
			$this->plan_map = \Modula_Extension_Catalog::plan_map();
		}

		return $this->plan_map;
	}

	/**
	 * Every catalog extension, in catalog order: the most expensive plan includes them all.
	 *
	 * @return string[]
	 */
	private function get_catalog_slugs() {
		$plan_map = $this->get_plan_map();

		return array() === $plan_map ? array() : end( $plan_map );
	}

	/**
	 * Cheapest plan that includes an extension.
	 *
	 * @param string $extension Prefixed extension slug.
	 * @return string|null Plan slug, null for an extension outside the catalog.
	 */
	private function get_cheapest_plan( $extension ) {
		foreach ( $this->get_plan_map() as $plan => $extensions ) {
			if ( in_array( $extension, $extensions, true ) ) {
				return $plan;
			}
		}

		return null;
	}

	/**
	 * Address of an extension's settings in Modula Settings.
	 *
	 * @param string $extension Prefixed extension slug.
	 * @return string|null URL, null when the extension has no settings of its own.
	 */
	private function get_settings_url( $extension ) {
		if ( ! isset( self::SETTINGS_SECTIONS[ $extension ] ) ) {
			return null;
		}

		return esc_url_raw( admin_url( 'edit.php?post_type=modula-gallery&page=modula&section=' . self::SETTINGS_SECTIONS[ $extension ] ) );
	}

	/**
	 * Each catalog extension's state on this site, for Lite's extension state seam (filter
	 * `modula_extension_states`). Lite owns names, descriptions, plans and order. Pro owns the
	 * state, so the filtered value is replaced, not merged.
	 *
	 * @param array|null $states Reported states; null until someone reports.
	 * @return array<string,array{available:bool,active:bool,settings:?string}> Slug => state.
	 */
	public function report_extension_states( $states ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- the filter passes it; Pro replaces it.
		$reported = array();
		foreach ( $this->get_read_only_extension_status() as $slug => $status ) {
			$reported[ $slug ] = array(
				'available' => $status['available'],
				// Without a plan the stored toggles are kept, but those extensions do not run.
				'active'    => $status['available'] && $status['enabled'],
				'settings'  => $this->get_settings_url( $slug ),
			);
		}

		return $reported;
	}

	/**
	 * Map internal extension keys to class loaders (same order as load_extensions).
	 *
	 * @return array<string, array{0: class-string, 1: string}>
	 */
	private function get_extension_class_loaders() {
		return array(
			'standalone'          => array( Standalone::class, 'get_instance' ),
			'albums'              => array( Albums::class, 'get_instance' ),
			'albums_slider'       => array( Albums_Slider::class, 'get_instance' ),
			'defaults'            => array( Defaults::class, 'get_instance' ),
			'image_proofing'      => array( Image_Proofing::class, 'get_instance' ),
			'download'            => array( Download::class, 'get_instance' ),
			'advanced_shortcodes' => array( Advanced_Shortcodes::class, 'get_instance' ),
			'deeplink'            => array( Deeplink::class, 'get_instance' ),
			'fullscreen'          => array( Fullscreen::class, 'get_instance' ),
			'pagination'          => array( Pagination::class, 'get_instance' ),
			'password_protect'    => array( Password_Protect::class, 'get_instance' ),
			'roles'               => array( Roles::class, 'get_instance' ),
			'slider'              => array( Slider::class, 'get_instance' ),
			'slideshow'           => array( Slideshow::class, 'get_instance' ),
			'zoom'                => array( Zoom::class, 'get_instance' ),
			'comments'            => array( Comments::class, 'get_instance' ),
			'video'               => array( Video::class, 'get_instance' ),
			'image_guardian'      => array( Image_Guardian::class, 'get_instance' ),
			'watermark'           => array( Watermark::class, 'get_instance' ),
			'exif'                => array( Exif::class, 'get_instance' ),
			'content_galleries'   => array( Content_Galleries::class, 'get_instance' ),
			'speedup'             => array( Speedup::class, 'get_instance' ),
			'instagram'           => array( Instagram::class, 'get_instance' ),
			'image_licensing'     => array( Image_Licensing::class, 'get_instance' ),
			'whitelabel'          => array( Whitelabel::class, 'get_instance' ),
		);
	}

	/**
	 * Convert prefixed extension slug (e.g. modula-roles) to internal array key (e.g. roles).
	 *
	 * @param string $prefixed_slug Extension slug with modula- prefix.
	 * @return string
	 */
	private function prefixed_extension_slug_to_key( $prefixed_slug ) {
		$without_prefix = preg_replace( '/^modula-/', '', $prefixed_slug );

		return str_replace( '-', '_', $without_prefix );
	}

	/**
	 * Load extension class(es) so constructors run and register modula_extension_*_activated hooks before do_action.
	 * Mirrors load_extensions() pairing of albums/slider with albums_slider.
	 *
	 * @param string $prefixed_slug e.g. modula-roles.
	 * @return void
	 */
	private function bootstrap_extension_for_activation_hooks( $prefixed_slug ) {
		if ( ! is_string( $prefixed_slug ) || '' === $prefixed_slug ) {
			return;
		}

		$extensions = $this->get_extension_class_loaders();
		$key        = $this->prefixed_extension_slug_to_key( $prefixed_slug );

		if ( ! isset( $extensions[ $key ] ) ) {
			return;
		}

		call_user_func( $extensions[ $key ] );

		if ( 'albums' === $key || 'slider' === $key ) {
			if ( isset( $extensions['albums_slider'] ) ) {
				call_user_func( $extensions['albums_slider'] );
			}
		}
	}

	/**
	 * Load extension classes
	 *
	 * @return void
	 */
	public function load_extensions() {
		$extensions = $this->get_extension_class_loaders();

		$active_extensions = $this->get_active_extensions();
		$current_plan      = Licensing::get_instance()->get_current_plan();
		$plan_map          = $this->get_plan_map();

		// Without a plan nothing loads, but the active set is kept: a renewed
		// license restores it, and deactivation hooks are destructive (Password Protect clears every password).
		if ( ! isset( $plan_map[ $current_plan ] ) ) {
			return;
		}

		$extensions_to_deactivate = array();
		$extra                    = array();
		foreach ( $extensions as $extension => $class ) {
			$prefixed_extension = 'modula-' . str_replace( '_', '-', $extension );

			$exists     = in_array( $prefixed_extension, $active_extensions, true );
			$is_in_plan = in_array( $prefixed_extension, $plan_map[ $current_plan ], true );

			if ( $exists && $is_in_plan ) {
				// todo this is a hack, we should find a better way to do this.
				if ( 'albums' === $extension || 'slider' === $extension ) {
					$extra[] = 'albums_slider';
				}

				call_user_func( $class );
			}

			if ( ! $is_in_plan ) {
				if ( ! in_array( $prefixed_extension, self::$just_reenabled_extensions, true ) ) {
					$extensions_to_deactivate[] = $prefixed_extension;
				}
			}
		}

		if ( ! empty( $extra ) ) {
			foreach ( $extra as $extension ) {
				call_user_func( $extensions[ $extension ] );
			}
		}

		if ( ! empty( $extensions_to_deactivate ) ) {
			$this->toggle_active_status_of_extensions( $extensions_to_deactivate, 'deactivate' );
		}

		self::$just_reenabled_extensions = array();
	}

	/**
	 * Mark for deletion
	 *
	 * THIS SHOULD BE DELETED AFTER A CERTAIN PERIOD OF TIME - AFTER ALL USERS ARE MIGRATED TO THE NEW SYSTEM
	 */
	public function mark_for_deletion() {
		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-albums',
			'modula-albums/modula-albums.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-defaults',
			'modula-defaults/modula-defaults.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-image-proofing',
			'modula-image-proofing/modula-image-proofing.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-download',
			'modula-download/modula-download.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-advanced-shortcodes',
			'modula-advanced-shortcodes/modula-advanced-shortcodes.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-deeplink',
			'modula-deeplink/modula-deeplink.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-fullscreen',
			'modula-fullscreen/modula-fullscreen.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-pagination',
			'modula-pagination/modula-pagination.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-password-protect',
			'modula-password-protect/modula-password-protect.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-roles',
			'modula-roles/modula-roles.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-slider',
			'modula-slider/modula-slider.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-slideshow',
			'modula-slideshow/modula-slideshow.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-zoom',
			'modula-zoom/modula-zoom.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-comments',
			'modula-comments/modula-comments.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-video',
			'modula-video/modula-video.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-protection',
			'modula-protection/modula-protection.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-watermark',
			'modula-watermark/modula-watermark.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-exif',
			'modula-exif/modula-exif.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-content-galleries',
			'modula-content-galleries/modula-content-galleries.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-speedup',
			'modula-speedup/modula-speedup.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-instagram',
			'modula-instagram/modula-instagram.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-image-licensing',
			'modula-image-licensing/modula-image-licensing.php'
		);

		$this->plugin_instance::deactivate_and_mark_for_delete(
			'modula-whitelabel',
			'modula-whitelabel/modula-whitelabel.php'
		);
	}

	public function enable_extensions_after_deletion() {
		if ( get_option( $this->initial_run, false ) ) {
			return;
		}

		$deactivated_plugins = $this->plugin_instance->get_deactivated_plugins();
		if ( empty( $deactivated_plugins ) ) {
			return;
		}

		$licensing = Licensing::get_instance();
		$licensing->check_license( true );

		self::$just_reenabled_extensions = $deactivated_plugins;

		$this->toggle_active_status_of_extensions( $deactivated_plugins, 'activate' );
		update_option( $this->initial_run, true );
	}

	/**
	 * Every catalog extension with Lite's name and description and its state on this site, in
	 * catalog order. Kept in `$extensions` because Lite's Insights reads the rows from there, and
	 * Lite's settings editor and older Extensions pages read this list. An older Lite has no
	 * catalog copy, so its rows are named from the slug: its settings editor gates Pro features
	 * on these rows and would lock them all if the list were empty.
	 *
	 * @return array<string,array{slug:string,name:string,description:string,available:bool,enabled:bool,settings:?string}>
	 *         Slug => row; `enabled` is the stored toggle.
	 */
	public function get_extensions() {
		$this->extensions = array();

		$copy = $this->has_catalog() ? \Modula_Extension_Catalog::copy() : array();
		foreach ( $this->get_read_only_extension_status() as $slug => $status ) {
			$this->extensions[ $slug ] = array(
				'slug'        => $slug,
				'name'        => $copy[ $slug ]['name'] ?? ucwords( str_replace( '-', ' ', substr( $slug, strlen( 'modula-' ) ) ) ),
				'description' => $copy[ $slug ]['description'] ?? '',
				'available'   => $status['available'],
				'enabled'     => $status['enabled'],
				'settings'    => $this->get_settings_url( $slug ),
			);
		}

		return $this->extensions;
	}

	/**
	 * Existing extension entitlements, projected without license or option writes.
	 *
	 * @return array<string,array{available:bool,enabled:bool}> Every catalog extension, in catalog order.
	 */
	public function get_read_only_extension_status() {
		$license = Licensing::get_instance()->get_read_only_status();
		$allowed = $this->get_plan_map()[ $license['plan'] ] ?? array();
		$active  = get_option( $this->active_extensions, array() );
		$active  = is_array( $active ) ? $active : array();
		$result  = array();
		foreach ( $this->get_catalog_slugs() as $slug ) {
			$result[ $slug ] = array(
				'available' => in_array( $slug, $allowed, true ),
				'enabled'   => in_array( $slug, $active, true ),
			);
		}
		return $result;
	}

	/**
	 * Slugs a user toggle must refuse: unknown extensions and, when turning on, extensions the
	 * current plan does not include. Turning off needs only a known slug, so a site whose plan no
	 * longer includes an extension can still drop it. The REST toggles and the Abilities executor
	 * share this rule; plan-driven deactivation in load_extensions() does not go through it.
	 *
	 * @param array $slugs  Prefixed extension slugs, e.g. modula-video.
	 * @param bool  $enable True to turn the extensions on.
	 * @return array Refused slugs, in request order; empty when the toggle may run.
	 */
	public function get_refused_toggle_slugs( array $slugs, $enable ) {
		$statuses = $this->get_read_only_extension_status();
		$refused  = array();
		foreach ( $slugs as $slug ) {
			$status = is_string( $slug ) ? ( $statuses[ $slug ] ?? null ) : null;
			if ( null === $status || ( $enable && ! $status['available'] ) ) {
				$refused[] = $slug;
			}
		}
		return $refused;
	}

	/**
	 * Toggle active extension
	 *
	 * @param string $extension
	 */
	public function toggle_active_extension( $extension ) {
		$extensions = get_option( $this->active_extensions, array() );
		$verb       = '';
		if ( in_array( $extension, $extensions, true ) ) {
			$verb       = 'deactivate';
			$extensions = array_diff( $extensions, array( $extension ) );
		} else {
			$verb = 'activate';
			array_push( $extensions, $extension );
		}

		update_option( $this->active_extensions, $extensions );
		$this->clear_active_extensions_cache();

		if ( 'activate' === $verb ) {
			$this->bootstrap_extension_for_activation_hooks( $extension );
		}

		$hook_action = 'activate' === $verb ? 'activated' : 'deactivated';
		do_action( 'modula_extension_' . $extension . '_' . $hook_action );
	}

	/**
	 * Toggle active status of extensions
	 *
	 * @param array $extensions
	 * @param string $action
	 */
	public function toggle_active_status_of_extensions( $extensions, $action ) {
		$active_extensions = get_option( $this->active_extensions, array() );

		$verb = $action;
		if ( 'activate' === $action ) {
			$active_extensions = array_values( array_unique( array_merge( $active_extensions, $extensions ) ) );
		} else {
			$active_extensions = array_values( array_diff( $active_extensions, $extensions ) );
		}

		update_option( $this->active_extensions, $active_extensions );
		$this->clear_active_extensions_cache();

		$hook_suffix = 'activate' === $verb ? 'activated' : 'deactivated';
		foreach ( $extensions as $extension ) {
			if ( 'activate' === $verb ) {
				$this->bootstrap_extension_for_activation_hooks( $extension );
			}
			do_action( 'modula_extension_' . $extension . '_' . $hook_suffix );
		}
	}

	/**
	 * Replace proper badges for the subtabs
	 *
	 * @param array $subtabs Subtabs configuration.
	 * @return array Subtabs configuration with proper badges.
	 */
	public function replace_proper_badges( $subtabs ) {
		foreach ( self::BADGED_SUBTABS as $key => $extension ) {
			if ( isset( $subtabs[ $key ] ) ) {
				$subtabs[ $key ] = $this->apply_plan_badge( $subtabs[ $key ], $extension );
			}
		}

		foreach ( self::BADGED_SUBTAB_FIELDS as $key => $field_extensions ) {
			if ( isset( $subtabs[ $key ] ) ) {
				$subtabs[ $key ] = $this->apply_field_plan_badges( $subtabs[ $key ], $field_extensions );
			}
		}

		return $subtabs;
	}

	/**
	 * Badge a settings subtab or field with the cheapest plan of its extension while the current
	 * plan lacks the extension, and lock it; clear both otherwise.
	 *
	 * @param array  $item      Subtab or field configuration.
	 * @param string $extension Prefixed slug of the extension it configures.
	 * @return array
	 */
	private function apply_plan_badge( array $item, $extension ) {
		$locked = $this->is_upgradable_addon( $extension );

		$item['badge']  = $locked ? $this->get_cheapest_plan( $extension ) : null;
		$item['locked'] = $locked;

		return $item;
	}

	/**
	 * Badge a subtab's fields by the extension each configures; the subtab itself gets no badge.
	 *
	 * @param array                $subtab           Subtab configuration.
	 * @param array<string,string> $field_extensions Field id => prefixed extension slug.
	 * @return array
	 */
	private function apply_field_plan_badges( array $subtab, array $field_extensions ) {
		$subtab['badge'] = null;
		if ( ! isset( $subtab['config']['fields'] ) ) {
			return $subtab;
		}

		foreach ( $subtab['config']['fields'] as $index => $field ) {
			$extension = $field_extensions[ $field['id'] ?? '' ] ?? null;
			if ( null !== $extension ) {
				$subtab['config']['fields'][ $index ] = $this->apply_plan_badge( $field, $extension );
			}
		}

		return $subtab;
	}

	/**
	 * Check if an addon is upgradable
	 *
	 * @param string $addon Addon slug.
	 * @return bool True if upgradable, false otherwise.
	 */
	public function is_upgradable_addon( $addon = null ) {
		if ( ! $addon ) {
			return false;
		}

		if ( 'modula' === $addon ) {
			return false;
		}

		$current_plan     = Licensing::get_instance()->get_current_plan();
		$owned_extensions = $this->get_plan_map()[ $current_plan ] ?? array();

		return ! in_array( $addon, $owned_extensions, true );
	}

	public function remove_menu_links( $links ) {

		if ( ! $this->is_upgradable_addon( 'modula-albums' ) ) {
			if ( isset( $links['modulaalbums'] ) ) {
				unset( $links['modulaalbums'] );
			}
		}

		if ( ! $this->is_upgradable_addon( 'modula-image-licensing' ) ) {
			if ( isset( $links['modulalicense'] ) ) {
				unset( $links['modulalicense'] );
			}
		}

		if ( ! $this->is_upgradable_addon( 'modula-image-proofing' ) ) {
			if ( isset( $links['image-proofing'] ) ) {
				unset( $links['image-proofing'] );
			}
		}

		if ( ! $this->is_upgradable_addon( 'modula-defaults' ) ) {
			if ( isset( $links['moduladefaults'] ) ) {
				unset( $links['moduladefaults'] );
			}

			if ( isset( $links['albumsdefaults'] ) ) {
				unset( $links['albumsdefaults'] );
			}
		}

		if ( ! $this->is_upgradable_addon( 'modula-albums' ) && class_exists( 'Modula_Pro\Extensions\Albums\Albums' ) ) {
			if ( isset( $links['albumsdefaults'] ) ) {
				unset( $links['albumsdefaults'] );
			}
		}

		if ( isset( $links['gopro'] ) ) {
			unset( $links['gopro'] );
		}

		return $links;
	}
	/**
	 * Set the Modula PRO fields in order for us to handle them
	 * this is required due to previous declaration of fields and tabs
	 *
	 */
	public function set_pro_fields() {
		$this->pro_fields = apply_filters(
			'modula_upsell_pro_fields',
			array(
				'modula-video'            => 'video',
				'modula-speedup'          => 'speedup',
				'modula-watermark'        => 'watermark',
				'modula-download'         => 'download',
				'modula-zoom'             => 'zoom',
				'modula-exif'             => 'exif',
				'modula-slideshow'        => 'slideshow',
				'modula-password-protect' => 'password_protect',
			)
		);
	}

	/**
	 * Check if an extension is enabled
	 *
	 * @param string $extension Extension slug.
	 * @return bool True if enabled, false otherwise.
	 */
	public function extension_enabled( $extension ) {
		$active_extensions = $this->get_active_extensions();
		return in_array( $extension, $active_extensions, true );
	}

	/**
	 * Modula PRO Upsell fields
	 *
	 * @param $fields
	 *
	 * @return mixed
	 *
	 * @since 2.5.2
	 */
	public function fields( $fields ) {
		// Get extensions from the higher package
		$higher_package_extensions = $this->get_higher_package_extensions();

		foreach ( $higher_package_extensions as $key => $package ) {
			if ( isset( $this->pro_fields[ $key ] ) && isset( $fields[ $this->pro_fields[ $key ] ] ) ) {
				unset( $fields[ $this->pro_fields[ $key ] ] );
			}
		}

		return $fields;
	}


	/**
	 * Get extensions from the higher package
	 *
	 * @return array Extensions from the higher package that are not in the current plan.
	 */
	private function get_higher_package_extensions() {
		$current_plan = Licensing::get_instance()->get_current_plan();
		$next_plan    = $this->get_offered_upgrade_plan( $current_plan );

		if ( '' === $next_plan ) {
			return array();
		}

		$plan_map                = $this->get_plan_map();
		$current_plan_extensions = $plan_map[ $current_plan ] ?? array();

		// Extensions in the next plan but not in the current plan.
		$higher_package_extensions = array();
		foreach ( array_diff( $plan_map[ $next_plan ], $current_plan_extensions ) as $extension ) {
			$higher_package_extensions[ $extension ] = $next_plan;
		}

		return $higher_package_extensions;
	}

	/**
	 * Plan whose extensions are offered as upgrades: the next plan up, or, without a plan, the most
	 * expensive one, so every extension is offered.
	 *
	 * @param string $current_plan Current plan slug, '' for none.
	 * @return string Plan slug, '' when nothing is above the current plan.
	 */
	private function get_offered_upgrade_plan( $current_plan ) {
		$plans = array_keys( $this->get_plan_map() );
		if ( array() === $plans ) {
			return '';
		}

		$index = array_search( $current_plan, $plans, true );
		if ( false === $index ) {
			return end( $plans );
		}

		return $plans[ $index + 1 ] ?? '';
	}

	/**
	 * Set badges
	 *
	 * @param $tabs
	 *
	 * @return mixed
	 *
	 * @since 2.5.2
	 */
	public function smart_upsells_tabs( $tabs ) {
		$higher_package_extensions = $this->get_higher_package_extensions();
		foreach ( $higher_package_extensions as $key => $package ) {
			if ( isset( $this->pro_fields[ $key ] ) && isset( $tabs[ $this->pro_fields[ $key ] ] ) ) {
				$tabs[ $this->pro_fields[ $key ] ]['badge'] = __( 'Upgrade', 'modula-pro' );
			}

			if ( 'modula-deeplink' === $key || 'modula-image-guardian' === $key ) {
				$tabs['misc']['badge'] = __( 'Upgrade', 'modula-pro' );
			}
		}

		return $tabs;
	}

	/**
	 * Unset badges for upgradable extensions
	 *
	 * @param array $tabs Tabs configuration.
	 * @return array Tabs configuration with badges unset for upgradable extensions.
	 */
	public function unset_badges( $tabs ) {
		foreach ( $tabs as $slug => $data ) {
			if ( $this->is_upgradable_addon( 'modula-' . $slug ) ) {
				unset( $tabs[ $slug ]['badge'] );
			}
		}
		return $tabs;
	}

	/**
	 * Get active extensions
	 *
	 * @return array Active extensions.
	 */
	public function get_active_extensions() {
		if ( empty( self::$active_extensions_cache ) ) {
			self::$active_extensions_cache = get_option( $this->active_extensions, array() );
		}
		return self::$active_extensions_cache;
	}

	/**
	 * Clear active extensions cache
	 */
	public function clear_active_extensions_cache() {
		self::$active_extensions_cache = array();
	}
}
