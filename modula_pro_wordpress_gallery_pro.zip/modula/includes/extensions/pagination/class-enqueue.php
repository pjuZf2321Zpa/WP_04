<?php
namespace Modula_Pro\Extensions\Pagination;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/pagination';

	public function __construct() {
		add_filter( 'modula_shortcode_css', array( $this, 'pagination_css' ), 16, 3 );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_pagination_scripts' ) );
		add_action( 'modula_necessary_scripts', array( $this, 'enqueue_pagination_scripts' ), 99, 2 );
		add_action( 'modula_necessary_styles', array( $this, 'enqueue_pagination_styles' ), 99, 2 );
	}

	/**
	 * Register pagination
	 *
	 * @since 1.0.0
	 */
	public function register_pagination_scripts() {

		wp_register_script(
			'modula-pagination-infinite-scroll',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/front/infinite-ajax-scroll.js',
			array(),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_script(
			'modula-pro-pagination',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/front/modula-pagination.js',
			array( 'modula-pagination-infinite-scroll' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_script(
			'modula-load-more',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/front/modula-load-more.js',
			array( 'modula-pagination-infinite-scroll' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_script(
			'modula-filters-pagination',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/front/modula-filters-pagination.js',
			array(),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_style(
			'modula-pagination-style',
			\MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-pagination-css.css',
			array(),
			\MODULA_PRO_VERSION
		);
	}

	/**
	 * Enqueue pagination scripts
	 *
	 * @param $scripts
	 *
	 * @param $settings
	 *
	 * @return mixed
	 *
	 * @since 1.0.0
	 */
	public function enqueue_pagination_scripts( $scripts, $settings ) {

		if ( class_exists( '\Modula\V2\Modern_Gallery' ) && \Modula\V2\Modern_Gallery::is_modern_stack_enabled( \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( is_array( $settings ) ? $settings : array() ) ) ) {
			return $scripts;
		}

		if ( isset( $settings['enable_pagination'] ) && 1 === (int) $settings['enable_pagination'] && isset( $settings['enable_infinite_scroll'] ) && 1 === (int) $settings['enable_infinite_scroll'] ) {
			$scripts[] = 'modula-pagination-infinite-scroll';
			$scripts[] = 'modula-pro-pagination';
			$scripts[] = 'modula-pro';
		}

		if ( isset( $settings['enable_pagination'] ) && 1 === (int) $settings['enable_pagination'] && isset( $settings['enable_load_more'] ) && 1 === (int) $settings['enable_load_more'] ) {
			$scripts[] = 'modula-pro';
			$scripts[] = 'modula-pagination-infinite-scroll';
			$scripts[] = 'modula-load-more';
			$scripts[] = 'modula-filters-pagination';
		}

		if ( isset( $settings['enable_pagination'] ) && 1 === absint( $settings['enable_pagination'] ) &&
			( ! isset( $settings['enable_load_more'] ) || 1 !== absint( $settings['enable_load_more'] ) ) &&
			( ! isset( $settings['enable_infinite_scroll'] ) || 1 !== absint( $settings['enable_infinite_scroll'] ) ) ) {
			$scripts[] = 'modula-filters-pagination';
		}

		return $scripts;
	}

	/**
	 * Enqueue pagination styles
	 *
	 * @param $styles
	 * @param $settings
	 *
	 * @return mixed
	 *
	 * @since 1.0.0
	 */
	public function enqueue_pagination_styles( $styles, $settings ) {

		if ( class_exists( '\Modula\V2\Modern_Gallery' ) && \Modula\V2\Modern_Gallery::is_modern_stack_enabled( \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( is_array( $settings ) ? $settings : array() ) ) ) {
			return $styles;
		}

		if ( isset( $settings['enable_pagination'] ) && 1 === (int) $settings['enable_pagination'] && ( ( isset( $settings['enable_infinite_scroll'] ) && 1 === (int) $settings['enable_infinite_scroll'] ) || ( isset( $settings['enable_load_more'] ) && 1 === (int) $settings['enable_load_more'] ) ) ) {
			$styles[] = 'modula-pagination-style';
		}

		return $styles;
	}
		/**
	 * Pagination CSS
	 *
	 * @param $css
	 * @param $gallery_id
	 * @param $settings
	 *
	 * @return string
	 *
	 * @since 1.0.0
	 */
	public function pagination_css( $css, $gallery_id, $settings ) {

		if ( isset( $settings['enable_pagination'] ) && 1 === (int) $settings['enable_pagination'] ) {
			if ( isset( $settings['pagination_color'] ) && '' !== $settings['pagination_color'] ) {
				$color = \Modula_Helper::sanitize_rgba_colour( $settings['pagination_color'] );
				$css  .= "#{$gallery_id} + div.modula-navigation .modula-links-wrapper  a { color : " . $color . '}';
				$css  .= "#{$gallery_id} + .modula-load-more-wrap .modula-load-more { color : " . $color . '}';
			}

			if ( isset( $settings['active_pagination_color'] ) && '' !== $settings['active_pagination_color'] ) {
				$css .= "#{$gallery_id} + .modula-navigation .modula-links-wrapper .current{color:" . \Modula_Helper::sanitize_rgba_colour( $settings['active_pagination_color'] ) . '}';
			}

			$position = isset( $settings['pagination_position'] ) ? $settings['pagination_position'] : 'left';
			$position = in_array( $position, array( 'left', 'center', 'right' ), true ) ? $position : 'left';
			$justify  = 'left' === $position ? 'flex-start' : ( 'right' === $position ? 'flex-end' : 'center' );

			$css .= "#{$gallery_id} + div.modula-navigation .modula-links-wrapper {text-align:" . esc_html( $position ) . '}';
			$css .= "#{$gallery_id} + .modula-load-more-wrap {justify-content:" . esc_html( $justify ) . '}';
		}

		return $css;
	}
}
