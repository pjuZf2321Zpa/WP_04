( function ( Modula ) {
	'use strict';
	const modulaPaginationConditions = Backbone.Model.extend( {
		initialize( args ) {
			const rows = jQuery(
				'.modula-settings-container tr[data-container]'
			);
			const tabs = jQuery( '.modula-tabs .modula-tab' );
			this.set( 'rows', rows );
			this.set( 'tabs', tabs );

			this.initEvents();
			this.initValues();
		},

		initValues() {
			this.changedType( false, wp.Modula.Settings.get( 'type' ) );
			this.changedEnablePagination(
				false,
				wp.Modula.Settings.get( 'enable_pagination' )
			);
			this.changedInfiniteAndLoadMore(
				false,
				wp.Modula.Settings.get( 'enable_infinite_scroll' )
			);
		},

		initEvents() {
			this.listenTo(
				wp.Modula.Settings,
				'change:type',
				this.changedType
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:enable_pagination',
				this.changedEnablePagination
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:enable_infinite_scroll',
				this.handleInfiniteScrollChange
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:enable_load_more',
				this.handleLoadMoreChange
			);
			this.listenTo(
				wp.Modula.Settings,
				'toggleAccordeon:enable_infinite_scroll',
				this.toggleEnableLoadMore
			);
			this.listenTo(
				wp.Modula.Settings,
				'toggleAccordeon:enable_load_more',
				this.toggleEnableLoadMore
			);
		},

		changedType( settings, value ) {
			const rows = this.get( 'rows' );
			if ( 'slider' == value ) {
				rows.filter( '[data-container="enable_pagination"]' ).hide();
			} else {
				rows.filter( '[data-container="enable_pagination"]' ).show();
			}

			this.changedEnablePagination(
				false,
				wp.Modula.Settings.get( 'enable_pagination' )
			);
		},

		changedEnablePagination( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter(
					'[data-container="enable_pagination"]'
				),
				type = wp.Modula.Settings.get( 'type' ),
				children = currentRow.data( 'children' );

			jQuery.each( children, function ( index, item ) {
				const child = jQuery( '[data-container="' + item + '"]' );

				if ( 'slider' == type ) {
					child.hide();
				} else if ( 0 == value ) {
					child.hide();
				} else {
					child.css( 'opacity', '1' );
					child
						.find( 'input, textarea, select, button' )
						.removeAttr( 'disabled' );
					child.show();
				}
			} );

			if ( 0 !== value ) {
				currentRow.addClass( 'modula_accordion_open' );
			} else {
				currentRow.removeClass( 'modula_accordion_open' );
			}

			this.changedInfiniteAndLoadMore();
		},
		handleInfiniteScrollChange( settings, value ) {
			const truthyValue = value === '1' || value === 1 || value === true;
			if ( truthyValue ) {
				const loadMore =
					wp.Modula.Settings.get( 'enable_load_more' ) === '1' ||
					wp.Modula.Settings.get( 'enable_load_more' ) === 1 ||
					wp.Modula.Settings.get( 'enable_load_more' ) === true;

				if ( loadMore ) {
					wp.Modula.Settings.set( 'enable_load_more', '0' );
					jQuery( 'input[data-setting="enable_load_more"]' ).prop(
						'checked',
						false
					);
				}
			}
			this.changedInfiniteAndLoadMore();
		},

		handleLoadMoreChange( settings, value ) {
			const truthyValue = value === '1' || value === 1 || value === true;
			if ( truthyValue ) {
				const infiniteScroll =
					wp.Modula.Settings.get( 'enable_infinite_scroll' ) ===
						'1' ||
					wp.Modula.Settings.get( 'enable_infinite_scroll' ) === 1 ||
					wp.Modula.Settings.get( 'enable_infinite_scroll' ) === true;
				if ( infiniteScroll ) {
					wp.Modula.Settings.set( 'enable_infinite_scroll', '0' );
					jQuery(
						'input[data-setting="enable_infinite_scroll"]'
					).prop( 'checked', false );
				}
			}
			this.changedInfiniteAndLoadMore();
		},

		toggleEnableLoadMore() {
			// Handle accordion toggle events - ensure mutual exclusivity
			const infiniteScroll = wp.Modula.Settings.get(
					'enable_infinite_scroll'
				),
				loadMore = wp.Modula.Settings.get( 'enable_load_more' );

			// Check if both are enabled (shouldn't happen, but handle it)
			const infiniteScrollEnabled =
				infiniteScroll === '1' ||
				infiniteScroll === 1 ||
				infiniteScroll === true;
			const loadMoreEnabled =
				loadMore === '1' || loadMore === 1 || loadMore === true;

			if ( infiniteScrollEnabled && loadMoreEnabled ) {
				// If both are enabled, keep the one that was just toggled
				// This is a fallback - the change handlers should prevent this
				const rows = this.get( 'rows' );
				const infiniteScrollRow = rows.filter(
					'[data-container="enable_infinite_scroll"]'
				);
				const loadMoreRow = rows.filter(
					'[data-container="enable_load_more"]'
				);

				// If infinite scroll row is open, disable load more
				if ( infiniteScrollRow.hasClass( 'modula_accordion_open' ) ) {
					wp.Modula.Settings.set( 'enable_load_more', '0' );
					jQuery( 'input[data-setting="enable_load_more"]' ).prop(
						'checked',
						false
					);
					loadMoreRow.removeClass( 'modula_accordion_open' );
				} else if ( loadMoreRow.hasClass( 'modula_accordion_open' ) ) {
					// If load more row is open, disable infinite scroll
					wp.Modula.Settings.set( 'enable_infinite_scroll', '0' );
					jQuery(
						'input[data-setting="enable_infinite_scroll"]'
					).prop( 'checked', false );
					infiniteScrollRow.removeClass( 'modula_accordion_open' );
				}
			}
		},

		changedInfiniteAndLoadMore() {
			const rows = this.get( 'rows' );
			const infiniteScroll = wp.Modula.Settings.get(
					'enable_infinite_scroll'
				),
				loadMore = wp.Modula.Settings.get( 'enable_load_more' ),
				paginationEnabled =
					wp.Modula.Settings.get( 'enable_pagination' ),
				children = rows.filter(
					'[data-container="pagination_color"],[data-container="active_pagination_color"],[data-container="pagination_position"]'
				);

			if (
				'1' === infiniteScroll ||
				'1' === loadMore ||
				'1' !== paginationEnabled
			) {
				children.hide();
			} else {
				children.css( 'opacity', '1' );
				children
					.find( 'input, textarea, select, button' )
					.removeAttr( 'disabled' );
				children.show();
			}
		},
	} );

	jQuery( document ).ready( function () {
		new modulaPaginationConditions();
	} );
} )( jQuery, wp.Modula );
