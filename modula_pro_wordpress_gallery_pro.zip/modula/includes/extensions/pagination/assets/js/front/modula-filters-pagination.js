( function ( $ ) {
	'use strict';

	function ModulaPagination( modula ) {
		this.instance = modula;

		const self = this,
			inst = self.instance;

		const dropdownFilters = inst.options.dropdownFilters;

		if ( '1' == dropdownFilters ) {
			inst.$element.off( 'change', '.filters' );
			inst.$element.on( 'change', '.filters', function ( e ) {
				if ( jQuery( this ).hasClass( 'modula_menu__item--current' ) ) {
					return;
				}

				const val = this.value,
					url = '?jtg-filter=' + val;

				window.location.href = url;
			} );
		} else {
			inst.$element.on( 'click', '.filters a', function ( e ) {
				e.preventDefault();

				let href = $( this ).attr( 'href' );

				if ( href.startsWith( '#jtg-filter-' ) ) {
					href = href.replace( '#jtg-filter-', '?jtg-filter=' );
				}

				if ( href.startsWith( '#' ) ) {
					href = href.replace( '#', '?jtg-filter=' );
				}

				window.location.href = href;
			} );
		}
	}
	$( document ).on( 'modula_api_after_init', function ( event, inst ) {
		new ModulaPagination( inst );
	} );
} )( jQuery );
