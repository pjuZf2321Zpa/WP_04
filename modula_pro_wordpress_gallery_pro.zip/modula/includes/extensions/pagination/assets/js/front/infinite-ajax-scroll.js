/**
 * Infinite Ajax Scroll v3.0.0-beta.6
 * Turn your existing pagination into infinite scrolling pages with ease
 *
 * Commercial use requires one-time purchase of a commercial license
 * https://infiniteajaxscroll.com/docs/license.html
 *
 * Copyright 2014-2020 Webcreate (Jeroen Fiege)
 * https://infiniteajaxscroll.com
 * @param global
 * @param factory
 */
( function ( global, factory ) {
	typeof exports === 'object' && typeof module !== 'undefined'
		? ( module.exports = factory() )
		: typeof define === 'function' && define.amd
		? define( factory )
		: ( ( global = global || self ),
		  ( global.InfiniteAjaxScroll = factory() ) );
} )( this, function () {
	'use strict';

	/*! @license is-dom-node v1.0.4

		Copyright 2018 Fisssion LLC.

		Permission is hereby granted, free of charge, to any person obtaining a copy
		of this software and associated documentation files (the "Software"), to deal
		in the Software without restriction, including without limitation the rights
		to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
		copies of the Software, and to permit persons to whom the Software is
		furnished to do so, subject to the following conditions:

		The above copyright notice and this permission notice shall be included in all
		copies or substantial portions of the Software.

		THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
		IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
		FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
		AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
		LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
		OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
		SOFTWARE.

	*/
	function isDomNode( x ) {
		return typeof window.Node === 'object'
			? x instanceof window.Node
			: x !== null &&
					typeof x === 'object' &&
					typeof x.nodeType === 'number' &&
					typeof x.nodeName === 'string';
	}

	/*! @license is-dom-node-list v1.2.1

		Copyright 2018 Fisssion LLC.

		Permission is hereby granted, free of charge, to any person obtaining a copy
		of this software and associated documentation files (the "Software"), to deal
		in the Software without restriction, including without limitation the rights
		to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
		copies of the Software, and to permit persons to whom the Software is
		furnished to do so, subject to the following conditions:

		The above copyright notice and this permission notice shall be included in all
		copies or substantial portions of the Software.

		THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
		IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
		FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
		AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
		LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
		OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
		SOFTWARE.

	*/

	function isDomNodeList( x ) {
		const prototypeToString = Object.prototype.toString.call( x );
		const regex = /^\[object (HTMLCollection|NodeList|Object)\]$/;

		return typeof window.NodeList === 'object'
			? x instanceof window.NodeList
			: x !== null &&
					typeof x === 'object' &&
					typeof x.length === 'number' &&
					regex.test( prototypeToString ) &&
					( x.length === 0 || isDomNode( x[ 0 ] ) );
	}

	/*! @license Tealight v0.3.6

		Copyright 2018 Fisssion LLC.

		Permission is hereby granted, free of charge, to any person obtaining a copy
		of this software and associated documentation files (the "Software"), to deal
		in the Software without restriction, including without limitation the rights
		to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
		copies of the Software, and to permit persons to whom the Software is
		furnished to do so, subject to the following conditions:

		The above copyright notice and this permission notice shall be included in all
		copies or substantial portions of the Software.

		THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
		IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
		FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
		AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
		LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
		OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
		SOFTWARE.

	*/

	function tealight( target, context ) {
		if ( context === void 0 ) {
			context = document;
		}

		if ( target instanceof Array ) {
			return target.filter( isDomNode );
		}
		if ( isDomNode( target ) ) {
			return [ target ];
		}
		if ( isDomNodeList( target ) ) {
			return Array.prototype.slice.call( target );
		}
		if ( typeof target === 'string' ) {
			try {
				const query = context.querySelectorAll( target );
				return Array.prototype.slice.call( query );
			} catch ( err ) {
				return [];
			}
		}
		return [];
	}

	const hasOwn = Object.prototype.hasOwnProperty;
	const toStr = Object.prototype.toString;
	const defineProperty = Object.defineProperty;
	const gOPD = Object.getOwnPropertyDescriptor;

	const isArray = function isArray( arr ) {
		if ( typeof Array.isArray === 'function' ) {
			return Array.isArray( arr );
		}

		return toStr.call( arr ) === '[object Array]';
	};

	const isPlainObject = function isPlainObject( obj ) {
		if ( ! obj || toStr.call( obj ) !== '[object Object]' ) {
			return false;
		}

		const hasOwnConstructor = hasOwn.call( obj, 'constructor' );
		const hasIsPrototypeOf =
			obj.constructor &&
			obj.constructor.prototype &&
			hasOwn.call( obj.constructor.prototype, 'isPrototypeOf' );
		// Not own constructor property must be Object
		if ( obj.constructor && ! hasOwnConstructor && ! hasIsPrototypeOf ) {
			return false;
		}

		// Own properties are enumerated firstly, so to speed up,
		// if last one is own, then all properties are own.
		let key;
		for ( key in obj ) {
			/**/
		}

		return typeof key === 'undefined' || hasOwn.call( obj, key );
	};

	// If name is '__proto__', and Object.defineProperty is available, define __proto__ as an own property on target
	const setProperty = function setProperty( target, options ) {
		if ( defineProperty && options.name === '__proto__' ) {
			defineProperty( target, options.name, {
				enumerable: true,
				configurable: true,
				value: options.newValue,
				writable: true,
			} );
		} else {
			target[ options.name ] = options.newValue;
		}
	};

	// Return undefined instead of __proto__ if '__proto__' is not an own property
	const getProperty = function getProperty( obj, name ) {
		if ( name === '__proto__' ) {
			if ( ! hasOwn.call( obj, name ) ) {
				return void 0;
			} else if ( gOPD ) {
				// In early versions of node, obj['__proto__'] is buggy when obj has
				// __proto__ as an own property. Object.getOwnPropertyDescriptor() works.
				return gOPD( obj, name ).value;
			}
		}

		return obj[ name ];
	};

	const extend = function extend() {
		const arguments$1 = arguments;

		let options, name, src, copy, copyIsArray, clone;
		let target = arguments[ 0 ];
		let i = 1;
		const length = arguments.length;
		let deep = false;

		// Handle a deep copy situation
		if ( typeof target === 'boolean' ) {
			deep = target;
			target = arguments[ 1 ] || {};
			// skip the boolean and the target
			i = 2;
		}
		if (
			target == null ||
			( typeof target !== 'object' && typeof target !== 'function' )
		) {
			target = {};
		}

		for ( ; i < length; ++i ) {
			options = arguments$1[ i ];
			// Only deal with non-null/undefined values
			if ( options != null ) {
				// Extend the base object
				for ( name in options ) {
					src = getProperty( target, name );
					copy = getProperty( options, name );

					// Prevent never-ending loop
					if ( target !== copy ) {
						// Recurse if we're merging plain objects or arrays
						if (
							deep &&
							copy &&
							( isPlainObject( copy ) ||
								( copyIsArray = isArray( copy ) ) )
						) {
							if ( copyIsArray ) {
								copyIsArray = false;
								clone = src && isArray( src ) ? src : [];
							} else {
								clone = src && isPlainObject( src ) ? src : {};
							}

							// Never move original objects, clone them
							setProperty( target, {
								name,
								newValue: extend( deep, clone, copy ),
							} );

							// Don't bring in undefined values
						} else if ( typeof copy !== 'undefined' ) {
							setProperty( target, {
								name,
								newValue: copy,
							} );
						}
					}
				}
			}
		}

		// Return the modified object
		return target;
	};

	const commonjsGlobal =
		typeof globalThis !== 'undefined'
			? globalThis
			: typeof window !== 'undefined'
			? window
			: typeof global !== 'undefined'
			? global
			: typeof self !== 'undefined'
			? self
			: {};

	/**
	 * lodash (Custom Build) <https://lodash.com/>
	 * Build: `lodash modularize exports="npm" -o ./`
	 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
	 * Released under MIT license <https://lodash.com/license>
	 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
	 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
	 */

	/** Used as the `TypeError` message for "Functions" methods. */
	const FUNC_ERROR_TEXT = 'Expected a function';

	/** Used as references for various `Number` constants. */
	const NAN = 0 / 0;

	/** `Object#toString` result references. */
	const symbolTag = '[object Symbol]';

	/** Used to match leading and trailing whitespace. */
	const reTrim = /^\s+|\s+$/g;

	/** Used to detect bad signed hexadecimal string values. */
	const reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

	/** Used to detect binary string values. */
	const reIsBinary = /^0b[01]+$/i;

	/** Used to detect octal string values. */
	const reIsOctal = /^0o[0-7]+$/i;

	/** Built-in method references without a dependency on `root`. */
	const freeParseInt = parseInt;

	/** Detect free variable `global` from Node.js. */
	const freeGlobal =
		typeof commonjsGlobal === 'object' &&
		commonjsGlobal &&
		commonjsGlobal.Object === Object &&
		commonjsGlobal;

	/** Detect free variable `self`. */
	const freeSelf =
		typeof self === 'object' && self && self.Object === Object && self;

	/** Used as a reference to the global object. */
	const root = freeGlobal || freeSelf || Function( 'return this' )();

	/** Used for built-in method references. */
	const objectProto = Object.prototype;

	/**
	 * Used to resolve the
	 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
	 * of values.
	 */
	const objectToString = objectProto.toString;

	/* Built-in method references for those with the same name as other `lodash` methods. */
	const nativeMax = Math.max,
		nativeMin = Math.min;

	/**
	 * Gets the timestamp of the number of milliseconds that have elapsed since
	 * the Unix epoch (1 January 1970 00:00:00 UTC).
	 *
	 * @static
	 * @memberOf _
	 * @since 2.4.0
	 * @category Date
	 * @return {number} Returns the timestamp.
	 * @example
	 *
	 * _.defer(function(stamp) {
	 *   console.log(_.now() - stamp);
	 * }, _.now());
	 * // => Logs the number of milliseconds it took for the deferred invocation.
	 */
	const now = function () {
		return root.Date.now();
	};

	/**
	 * Creates a debounced function that delays invoking `func` until after `wait`
	 * milliseconds have elapsed since the last time the debounced function was
	 * invoked. The debounced function comes with a `cancel` method to cancel
	 * delayed `func` invocations and a `flush` method to immediately invoke them.
	 * Provide `options` to indicate whether `func` should be invoked on the
	 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
	 * with the last arguments provided to the debounced function. Subsequent
	 * calls to the debounced function return the result of the last `func`
	 * invocation.
	 *
	 * **Note:** If `leading` and `trailing` options are `true`, `func` is
	 * invoked on the trailing edge of the timeout only if the debounced function
	 * is invoked more than once during the `wait` timeout.
	 *
	 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
	 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
	 *
	 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
	 * for details over the differences between `_.debounce` and `_.throttle`.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Function
	 * @param {Function} func                    The function to debounce.
	 * @param {number}   [wait=0]                The number of milliseconds to delay.
	 * @param {Object}   [options={}]            The options object.
	 * @param {boolean}  [options.leading=false]
	 *                                           Specify invoking on the leading edge of the timeout.
	 * @param {number}   [options.maxWait]
	 *                                           The maximum time `func` is allowed to be delayed before it's invoked.
	 * @param {boolean}  [options.trailing=true]
	 *                                           Specify invoking on the trailing edge of the timeout.
	 * @return {Function} Returns the new debounced function.
	 * @example
	 *
	 * // Avoid costly calculations while the window size is in flux.
	 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
	 *
	 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
	 * jQuery(element).on('click', _.debounce(sendMail, 300, {
	 *   'leading': true,
	 *   'trailing': false
	 * }));
	 *
	 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
	 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
	 * var source = new EventSource('/stream');
	 * jQuery(source).on('message', debounced);
	 *
	 * // Cancel the trailing debounced invocation.
	 * jQuery(window).on('popstate', debounced.cancel);
	 */
	function debounce( func, wait, options ) {
		let lastArgs,
			lastThis,
			maxWait,
			result,
			timerId,
			lastCallTime,
			lastInvokeTime = 0,
			leading = false,
			maxing = false,
			trailing = true;

		if ( typeof func !== 'function' ) {
			throw new TypeError( FUNC_ERROR_TEXT );
		}
		wait = toNumber( wait ) || 0;
		if ( isObject( options ) ) {
			leading = !! options.leading;
			maxing = 'maxWait' in options;
			maxWait = maxing
				? nativeMax( toNumber( options.maxWait ) || 0, wait )
				: maxWait;
			trailing = 'trailing' in options ? !! options.trailing : trailing;
		}

		function invokeFunc( time ) {
			const args = lastArgs,
				thisArg = lastThis;

			lastArgs = lastThis = undefined;
			lastInvokeTime = time;
			result = func.apply( thisArg, args );
			return result;
		}

		function leadingEdge( time ) {
			// Reset any `maxWait` timer.
			lastInvokeTime = time;
			// Start the timer for the trailing edge.
			timerId = setTimeout( timerExpired, wait );
			// Invoke the leading edge.
			return leading ? invokeFunc( time ) : result;
		}

		function remainingWait( time ) {
			const timeSinceLastCall = time - lastCallTime,
				timeSinceLastInvoke = time - lastInvokeTime,
				result = wait - timeSinceLastCall;

			return maxing
				? nativeMin( result, maxWait - timeSinceLastInvoke )
				: result;
		}

		function shouldInvoke( time ) {
			const timeSinceLastCall = time - lastCallTime,
				timeSinceLastInvoke = time - lastInvokeTime;

			// Either this is the first call, activity has stopped and we're at the
			// trailing edge, the system time has gone backwards and we're treating
			// it as the trailing edge, or we've hit the `maxWait` limit.
			return (
				lastCallTime === undefined ||
				timeSinceLastCall >= wait ||
				timeSinceLastCall < 0 ||
				( maxing && timeSinceLastInvoke >= maxWait )
			);
		}

		function timerExpired() {
			const time = now();
			if ( shouldInvoke( time ) ) {
				return trailingEdge( time );
			}
			// Restart the timer.
			timerId = setTimeout( timerExpired, remainingWait( time ) );
		}

		function trailingEdge( time ) {
			timerId = undefined;

			// Only invoke if we have `lastArgs` which means `func` has been
			// debounced at least once.
			if ( trailing && lastArgs ) {
				return invokeFunc( time );
			}
			lastArgs = lastThis = undefined;
			return result;
		}

		function cancel() {
			if ( timerId !== undefined ) {
				clearTimeout( timerId );
			}
			lastInvokeTime = 0;
			lastArgs = lastCallTime = lastThis = timerId = undefined;
		}

		function flush() {
			return timerId === undefined ? result : trailingEdge( now() );
		}

		function debounced() {
			const time = now(),
				isInvoking = shouldInvoke( time );

			lastArgs = arguments;
			lastThis = this;
			lastCallTime = time;

			if ( isInvoking ) {
				if ( timerId === undefined ) {
					return leadingEdge( lastCallTime );
				}
				if ( maxing ) {
					// Handle invocations in a tight loop.
					timerId = setTimeout( timerExpired, wait );
					return invokeFunc( lastCallTime );
				}
			}
			if ( timerId === undefined ) {
				timerId = setTimeout( timerExpired, wait );
			}
			return result;
		}
		debounced.cancel = cancel;
		debounced.flush = flush;
		return debounced;
	}

	/**
	 * Creates a throttled function that only invokes `func` at most once per
	 * every `wait` milliseconds. The throttled function comes with a `cancel`
	 * method to cancel delayed `func` invocations and a `flush` method to
	 * immediately invoke them. Provide `options` to indicate whether `func`
	 * should be invoked on the leading and/or trailing edge of the `wait`
	 * timeout. The `func` is invoked with the last arguments provided to the
	 * throttled function. Subsequent calls to the throttled function return the
	 * result of the last `func` invocation.
	 *
	 * **Note:** If `leading` and `trailing` options are `true`, `func` is
	 * invoked on the trailing edge of the timeout only if the throttled function
	 * is invoked more than once during the `wait` timeout.
	 *
	 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
	 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
	 *
	 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
	 * for details over the differences between `_.throttle` and `_.debounce`.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Function
	 * @param {Function} func                    The function to throttle.
	 * @param {number}   [wait=0]                The number of milliseconds to throttle invocations to.
	 * @param {Object}   [options={}]            The options object.
	 * @param {boolean}  [options.leading=true]
	 *                                           Specify invoking on the leading edge of the timeout.
	 * @param {boolean}  [options.trailing=true]
	 *                                           Specify invoking on the trailing edge of the timeout.
	 * @return {Function} Returns the new throttled function.
	 * @example
	 *
	 * // Avoid excessively updating the position while scrolling.
	 * jQuery(window).on('scroll', _.throttle(updatePosition, 100));
	 *
	 * // Invoke `renewToken` when the click event is fired, but not more than once every 5 minutes.
	 * var throttled = _.throttle(renewToken, 300000, { 'trailing': false });
	 * jQuery(element).on('click', throttled);
	 *
	 * // Cancel the trailing throttled invocation.
	 * jQuery(window).on('popstate', throttled.cancel);
	 */
	function throttle( func, wait, options ) {
		let leading = true,
			trailing = true;

		if ( typeof func !== 'function' ) {
			throw new TypeError( FUNC_ERROR_TEXT );
		}
		if ( isObject( options ) ) {
			leading = 'leading' in options ? !! options.leading : leading;
			trailing = 'trailing' in options ? !! options.trailing : trailing;
		}
		return debounce( func, wait, {
			leading,
			maxWait: wait,
			trailing,
		} );
	}

	/**
	 * Checks if `value` is the
	 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
	 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @return {boolean} Returns `true` if `value` is an object, else `false`.
	 * @example
	 *
	 * _.isObject({});
	 * // => true
	 *
	 * _.isObject([1, 2, 3]);
	 * // => true
	 *
	 * _.isObject(_.noop);
	 * // => true
	 *
	 * _.isObject(null);
	 * // => false
	 */
	function isObject( value ) {
		const type = typeof value;
		return !! value && ( type == 'object' || type == 'function' );
	}

	/**
	 * Checks if `value` is object-like. A value is object-like if it's not `null`
	 * and has a `typeof` result of "object".
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @return {boolean} Returns `true` if `value` is object-like, else `false`.
	 * @example
	 *
	 * _.isObjectLike({});
	 * // => true
	 *
	 * _.isObjectLike([1, 2, 3]);
	 * // => true
	 *
	 * _.isObjectLike(_.noop);
	 * // => false
	 *
	 * _.isObjectLike(null);
	 * // => false
	 */
	function isObjectLike( value ) {
		return !! value && typeof value === 'object';
	}

	/**
	 * Checks if `value` is classified as a `Symbol` primitive or object.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @return {boolean} Returns `true` if `value` is a symbol, else `false`.
	 * @example
	 *
	 * _.isSymbol(Symbol.iterator);
	 * // => true
	 *
	 * _.isSymbol('abc');
	 * // => false
	 */
	function isSymbol( value ) {
		return (
			typeof value === 'symbol' ||
			( isObjectLike( value ) &&
				objectToString.call( value ) == symbolTag )
		);
	}

	/**
	 * Converts `value` to a number.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to process.
	 * @return {number} Returns the number.
	 * @example
	 *
	 * _.toNumber(3.2);
	 * // => 3.2
	 *
	 * _.toNumber(Number.MIN_VALUE);
	 * // => 5e-324
	 *
	 * _.toNumber(Infinity);
	 * // => Infinity
	 *
	 * _.toNumber('3.2');
	 * // => 3.2
	 */
	function toNumber( value ) {
		if ( typeof value === 'number' ) {
			return value;
		}
		if ( isSymbol( value ) ) {
			return NAN;
		}
		if ( isObject( value ) ) {
			const other =
				typeof value.valueOf === 'function' ? value.valueOf() : value;
			value = isObject( other ) ? other + '' : other;
		}
		if ( typeof value !== 'string' ) {
			return value === 0 ? value : +value;
		}
		value = value.replace( reTrim, '' );
		const isBinary = reIsBinary.test( value );
		return isBinary || reIsOctal.test( value )
			? freeParseInt( value.slice( 2 ), isBinary ? 2 : 8 )
			: reIsBadHex.test( value )
			? NAN
			: +value;
	}

	const lodash_throttle = throttle;

	const defaults = {
		item: undefined,
		next: undefined,
		pagination: undefined,
		responseType: 'document',
		bind: true,
		scrollContainer: window,
		spinner: false,
		logger: true,
		loadOnScroll: true,
		negativeMargin: 0,
		trigger: false,
		autoResumeAfterLoad: true,
	};

	const Assert = {
		singleElement: function singleElement( elementOrSelector, property ) {
			const $element = tealight( elementOrSelector );

			if ( $element.length > 1 ) {
				throw new Error(
					'Expected single element for "' + property + '"'
				);
			}

			if ( $element.length === 0 ) {
				throw new Error(
					'Element "' +
						elementOrSelector +
						'" not found for "' +
						property +
						'"'
				);
			}
		},
		anyElement: function anyElement( elementOrSelector, property ) {
			const $element = tealight( elementOrSelector );

			if ( $element.length === 0 ) {
				throw new Error(
					'Element "' +
						elementOrSelector +
						'" not found for "' +
						property +
						'"'
				);
			}
		},
		warn: function warn( fn ) {
			let args = [],
				len = arguments.length - 1;
			while ( len-- > 0 ) {
				args[ len ] = arguments[ len + 1 ];
			}

			try {
				fn.apply( void 0, args );
			} catch ( e ) {
				if ( console && console.warn ) {
					console.warn( e.message );
				}
			}
		},
	};

	function getScrollPosition( el ) {
		if ( el !== window ) {
			return {
				x: el.scrollLeft,
				y: el.scrollTop,
			};
		}

		const supportPageOffset = window.pageXOffset !== undefined;
		const isCSS1Compat = ( document.compatMode || '' ) === 'CSS1Compat';

		return {
			x: supportPageOffset
				? window.pageXOffset
				: isCSS1Compat
				? document.documentElement.scrollLeft
				: document.body.scrollLeft,
			y: supportPageOffset
				? window.pageYOffset
				: isCSS1Compat
				? document.documentElement.scrollTop
				: document.body.scrollTop,
		};
	}

	function getRootRect( el ) {
		let rootRect;

		if ( el !== window ) {
			rootRect = el.getBoundingClientRect();
		} else {
			// Use <html>/<body> instead of window since scroll bars affect size.
			const html = document.documentElement;
			const body = document.body;

			rootRect = {
				top: 0,
				left: 0,
				right: html.clientWidth || body.clientWidth,
				width: html.clientWidth || body.clientWidth,
				bottom: html.clientHeight || body.clientHeight,
				height: html.clientHeight || body.clientHeight,
			};
		}

		return rootRect;
	}

	function getDistanceToFold( el, scrollContainer ) {
		const scroll = getScrollPosition( scrollContainer );
		const rootRect = getRootRect( scrollContainer );
		const boundingRect = el.getBoundingClientRect();

		const scrollYBottom = scroll.y + rootRect.height;
		const bottom = scroll.y + boundingRect.bottom - rootRect.top;

		return Math.trunc( bottom - scrollYBottom );
	}

	const APPEND = 'append';
	const APPENDED = 'appended';
	const BINDED = 'binded';
	const UNBINDED = 'unbinded';
	const HIT = 'hit';
	const LOAD = 'load';
	const LOADED = 'loaded';
	const LAST = 'last';
	const NEXT = 'next';
	const SCROLLED = 'scrolled';
	const RESIZED = 'resized';
	const PAGE = 'page';

	const defaultLastScroll = {
		y: 0,
		x: 0,
		deltaY: 0,
		deltaX: 0,
	};

	function calculateScroll( scrollContainer, lastScroll ) {
		const scroll = getScrollPosition( scrollContainer );

		scroll.deltaY = scroll.y - ( lastScroll ? lastScroll.y : scroll.y );
		scroll.deltaX = scroll.x - ( lastScroll ? lastScroll.x : scroll.x );

		return scroll;
	}

	function scrollHandler() {
		const ias = this;
		const lastScroll = ias._lastScroll || defaultLastScroll;

		const scroll = ( ias._lastScroll = calculateScroll(
			ias.scrollContainer,
			lastScroll
		) );

		this.emitter.emit( SCROLLED, { scroll } );
	}

	function resizeHandler() {
		const ias = this;
		const lastScroll = ias._lastScroll || defaultLastScroll;

		const scroll = ( ias._lastScroll = calculateScroll(
			ias.scrollContainer,
			lastScroll
		) );

		this.emitter.emit( RESIZED, { scroll } );
	}

	function E() {
		// Keep this empty so it's easier to inherit from
		// (via https://github.com/lipsmack from https://github.com/scottcorgan/tiny-emitter/issues/3)
	}

	E.prototype = {
		on( name, callback, ctx ) {
			const e = this.e || ( this.e = {} );

			( e[ name ] || ( e[ name ] = [] ) ).push( {
				fn: callback,
				ctx,
			} );

			return this;
		},

		once( name, callback, ctx ) {
			const self = this;
			function listener() {
				self.off( name, listener );
				callback.apply( ctx, arguments );
			}
			listener._ = callback;
			return this.on( name, listener, ctx );
		},

		emit( name ) {
			const data = [].slice.call( arguments, 1 );
			const evtArr = (
				( this.e || ( this.e = {} ) )[ name ] || []
			).slice();
			let i = 0;
			const len = evtArr.length;

			for ( i; i < len; i++ ) {
				evtArr[ i ].fn.apply( evtArr[ i ].ctx, data );
			}

			return this;
		},

		off( name, callback ) {
			const e = this.e || ( this.e = {} );
			const evts = e[ name ];
			const liveEvents = [];

			if ( evts && callback ) {
				for ( let i = 0, len = evts.length; i < len; i++ ) {
					if (
						evts[ i ].fn !== callback &&
						evts[ i ].fn._ !== callback
					) {
						liveEvents.push( evts[ i ] );
					}
				}
			}

			// Remove event from queue to prevent memory leak
			// Suggested by https://github.com/lazd
			// Ref: https://github.com/scottcorgan/tiny-emitter/commit/c6ebfaa9bc973b33d110a84a307742b7cf94c953#commitcomment-5024910

			liveEvents.length ? ( e[ name ] = liveEvents ) : delete e[ name ];

			return this;
		},
	};

	const tinyEmitter = E;
	const TinyEmitter = E;
	tinyEmitter.TinyEmitter = TinyEmitter;

	function nextHandler( pageIndex ) {
		const ias = this;
		let lastResponse = ias._lastResponse || document;

		const nextEl = tealight( ias.options.next, lastResponse )[ 0 ];

		if ( ! nextEl ) {
			Assert.warn(
				Assert.singleElement,
				ias.options.next,
				'options.next'
			);

			return;
		}

		const nextUrl = nextEl.href;

		return ias.load( nextUrl ).then( function ( data ) {
			lastResponse = ias._lastResponse = data.xhr.response;

			const nextEl = tealight( ias.options.next, lastResponse )[ 0 ];

			return ias
				.append( data.items )
				.then( function () {
					return !! nextEl;
				} )
				.then( function ( hasNextEl ) {
					// only warn for first page, because at some point it's expected that there is no next element
					if (
						! hasNextEl &&
						pageIndex <= 1 &&
						console &&
						console.warn
					) {
						console.warn(
							'Element "' +
								ias.options.next +
								'" not found for "options.next" on "' +
								data.url +
								'"'
						);
					}

					return hasNextEl;
				} );
		} );
	}

	const defaults$1 = {
		element: undefined,
		hide: false,
	};

	function expand( options ) {
		if (
			typeof options === 'string' ||
			( typeof options === 'object' &&
				options.nodeType === Node.ELEMENT_NODE )
		) {
			options = {
				element: options,
				hide: true,
			};
		} else if ( typeof options === 'boolean' ) {
			options = {
				element: undefined,
				hide: options,
			};
		}

		return options;
	}

	const Pagination = function Pagination( ias, options ) {
		this.options = extend( {}, defaults$1, expand( options ) );
		this.originalDisplayStyles = new WeakMap();

		if ( ! this.options.hide ) {
			return;
		}

		Assert.warn(
			Assert.anyElement,
			this.options.element,
			'pagination.element'
		);

		ias.on( BINDED, this.hide.bind( this ) );
		ias.on( UNBINDED, this.restore.bind( this ) );
	};

	Pagination.prototype.hide = function hide() {
		const this$1 = this;

		const els = tealight( this.options.element );

		els.forEach( function ( el ) {
			this$1.originalDisplayStyles.set(
				el,
				window.getComputedStyle( el ).display
			);

			el.style.display = 'none';
		} );
	};

	Pagination.prototype.restore = function restore() {
		const this$1 = this;

		const els = tealight( this.options.element );

		els.forEach( function ( el ) {
			el.style.display =
				this$1.originalDisplayStyles.get( el ) || 'block';
		} );
	};

	const defaults$2 = {
		element: undefined,
		delay: 600,
		show( element ) {
			element.style.opacity = '1';
		},
		hide( element ) {
			element.style.opacity = '0';
		},
	};

	function expand$1( options ) {
		if (
			typeof options === 'string' ||
			( typeof options === 'object' &&
				options.nodeType === Node.ELEMENT_NODE )
		) {
			options = {
				element: options,
			};
		}

		return options;
	}

	const Spinner = function Spinner( ias, options ) {
		// no spinner wanted
		if ( options === false ) {
			return;
		}

		this.ias = ias;
		this.options = extend( {}, defaults$2, expand$1( options ) );

		if ( this.options.element !== undefined ) {
			Assert.singleElement( this.options.element, 'spinner.element' );
		}

		this.element = tealight( this.options.element )[ 0 ]; // @todo should we really cache this?
		this.hideFn = this.options.hide;
		this.showFn = this.options.show;

		ias.on( BINDED, this.bind.bind( this ) );
		ias.on( BINDED, this.hide.bind( this ) );
	};

	Spinner.prototype.bind = function bind() {
		let startTime,
			endTime,
			diff,
			delay,
			self = this,
			ias = this.ias;

		ias.on( NEXT, function () {
			startTime = +new Date();

			self.show();
		} );

		ias.on( LAST, function () {
			self.hide();
		} );

		// setup delay
		ias.on( APPEND, function ( event ) {
			endTime = +new Date();
			diff = endTime - startTime;

			delay = Math.max( 0, self.options.delay - diff );

			// copy original append function
			const appendFn = event.appendFn;

			// wrap append function with delay
			event.appendFn = function ( items, parent, last ) {
				return new Promise( function ( resolve ) {
					setTimeout( function () {
						// turn hide function into promise
						Promise.resolve( self.hide() ).then( function () {
							appendFn( items, parent, last );

							resolve();
						} );
					}, delay );
				} );
			};
		} );
	};

	Spinner.prototype.show = function show() {
		return Promise.resolve( this.showFn( this.element ) );
	};

	Spinner.prototype.hide = function hide() {
		return Promise.resolve( this.hideFn( this.element ) );
	};

	/* eslint no-console: "off" */

	const defaultLogger = {
		hit() {
			console.log( 'Hit scroll threshold' );
		},
		binded() {
			console.log( 'Binded event handlers' );
		},
		unbinded() {
			console.log( 'Unbinded event handlers' );
		},
		// scrolled: (event) => {
		//   console.log('Scrolled');
		// },
		// resized: (event) => {
		//   console.log('Resized');
		// },
		next( event ) {
			console.log(
				'Next page triggered [pageIndex=' + event.pageIndex + ']'
			);
		},
		load( event ) {
			console.log( 'Start loading ' + event.url );
		},
		loaded() {
			console.log( 'Finished loading' );
		},
		append() {
			console.log( 'Start appending items' );
		},
		appended( event ) {
			console.log(
				'Finished appending ' + event.items.length + ' item(s)'
			);
		},
		last() {
			console.log( 'No more pages left to load' );
		},
		page( event ) {
			console.log( 'Page changed [pageIndex=' + event.pageIndex + ']' );
		},
	};

	function expand$2( options ) {
		if ( options === true ) {
			options = defaultLogger;
		}

		return options;
	}

	const Logger = function Logger( ias, options ) {
		// no logger wanted
		if ( options === false ) {
			return;
		}

		const logger = expand$2( options );

		Object.keys( logger ).forEach( function ( key ) {
			ias.on( key, logger[ key ] );
		} );
	};

	function getPageBreak( pageBreaks, scrollTop, scrollContainer ) {
		const rootRect = getRootRect( scrollContainer );
		const scrollBottom = scrollTop + rootRect.height;

		for ( let b = pageBreaks.length - 1; b >= 0; b-- ) {
			const bottom =
				pageBreaks[ b ].sentinel.getBoundingClientRect().bottom +
				scrollTop;

			if ( scrollBottom > bottom ) {
				const x = Math.min( b + 1, pageBreaks.length - 1 );

				return pageBreaks[ x ];
			}
		}

		return pageBreaks[ 0 ];
	}

	const Paging = function Paging( ias ) {
		this.ias = ias;
		this.pageBreaks = [];
		this.currentPageIndex = ias.pageIndex;
		this.currentScrollTop = 0;

		ias.on( BINDED, this.binded.bind( this ) );
		ias.on( NEXT, this.next.bind( this ) );
		ias.on( SCROLLED, this.scrolled.bind( this ) );
		ias.on( RESIZED, this.scrolled.bind( this ) );
	};

	Paging.prototype.binded = function binded() {
		const sentinel = this.ias.sentinel();
		if ( ! sentinel ) {
			return;
		}

		this.pageBreaks.push( {
			pageIndex: this.currentPageIndex,
			url: document.location.toString(),
			title: document.title,
			sentinel: this.ias.sentinel(),
		} );
	};

	Paging.prototype.next = function next( nextEvent ) {
		const this$1 = this;

		let url = document.location.toString();
		let title = document.title;

		// @todo can be moved inside appended when eventStack is implemented
		const loaded = function ( event ) {
			url = event.url;

			if ( event.xhr.response ) {
				title = event.xhr.response.title;
			}
		};

		this.ias.once( LOADED, loaded );

		this.ias.once( APPENDED, function () {
			this$1.pageBreaks.push( {
				pageIndex: nextEvent.pageIndex,
				url,
				title,
				sentinel: this$1.ias.sentinel(),
			} );

			this$1.update();

			// @todo can be removed when eventStack is implemented
			this$1.ias.off( LOADED, loaded );
		} );
	};

	Paging.prototype.scrolled = function scrolled( event ) {
		this.update( event.scroll.y );
	};

	Paging.prototype.update = function update( scrollTop ) {
		this.currentScrollTop = scrollTop || this.currentScrollTop;

		const pageBreak = getPageBreak(
			this.pageBreaks,
			this.currentScrollTop,
			this.ias.scrollContainer
		);

		if ( pageBreak && pageBreak.pageIndex !== this.currentPageIndex ) {
			this.ias.emitter.emit( PAGE, pageBreak );

			this.currentPageIndex = pageBreak.pageIndex;
		}
	};

	const defaults$3 = {
		element: undefined,
		when( pageIndex ) {
			return true;
		},
		show( element ) {
			element.style.opacity = '1';
		},
		hide( element ) {
			element.style.opacity = '0';
		},
	};

	function expand$3( options ) {
		if (
			typeof options === 'string' ||
			typeof options === 'function' ||
			( typeof options === 'object' &&
				options.nodeType === Node.ELEMENT_NODE )
		) {
			options = {
				element: options,
			};
		}

		if ( typeof options.element === 'function' ) {
			options.element = options.element();
		}

		// expand array to a function, e.g.:
		// [0, 1, 2] -> function(pageIndex) { /* return true when pageIndex in [0, 1, 2] */ }
		if ( options.when && Array.isArray( options.when ) ) {
			const when = options.when;
			options.when = function ( pageIndex ) {
				return when.indexOf( pageIndex ) !== -1;
			};
		}

		return options;
	}

	const Trigger = function Trigger( ias, options ) {
		const this$1 = this;

		// no trigger wanted
		if ( options === false ) {
			return;
		}

		this.ias = ias;
		this.options = extend( {}, defaults$3, expand$3( options ) );

		if ( this.options.element !== undefined ) {
			Assert.singleElement( this.options.element, 'trigger.element' );
		}

		this.element = tealight( this.options.element )[ 0 ]; // @todo should we really cache this?
		this.hideFn = this.options.hide;
		this.showFn = this.options.show;
		this.voter = this.options.when;
		this.showing = undefined;
		this.enabled = undefined;

		ias.on( BINDED, this.bind.bind( this ) );
		ias.on( UNBINDED, this.unbind.bind( this ) );
		ias.on( HIT, this.hit.bind( this ) );
		ias.on( NEXT, function ( e ) {
			return this$1.ias.once( APPENDED, function () {
				return this$1.update( e.pageIndex );
			} );
		} );
	};

	Trigger.prototype.bind = function bind() {
		this.hide();
		this.update( this.ias.pageIndex );

		this.element.addEventListener(
			'click',
			this.clickHandler.bind( this )
		);
	};

	Trigger.prototype.unbind = function unbind() {
		this.element.removeEventListener(
			'click',
			this.clickHandler.bind( this )
		);
	};

	Trigger.prototype.clickHandler = function clickHandler() {
		const this$1 = this;

		this.hide().then( function () {
			return this$1.ias.next();
		} );
	};

	Trigger.prototype.update = function update( pageIndex ) {
		this.enabled = this.voter( pageIndex );

		if ( this.enabled ) {
			this.ias.disableLoadOnScroll();
		} else {
			this.ias.enableLoadOnScroll();
		}
	};

	Trigger.prototype.hit = function hit() {
		if ( ! this.enabled ) {
			return;
		}

		this.show();
	};

	Trigger.prototype.show = function show() {
		if ( this.showing ) {
			return;
		}

		this.showing = true;

		return Promise.resolve( this.showFn( this.element ) );
	};

	Trigger.prototype.hide = function hide() {
		if ( ! this.showing && this.showing !== undefined ) {
			return;
		}

		this.showing = false;

		return Promise.resolve( this.hideFn( this.element ) );
	};

	function appendFn( items, parent, last ) {
		const sibling = last ? last.nextSibling : null;
		const insert = document.createDocumentFragment();

		items.forEach( function ( item ) {
			insert.appendChild( item );
		} );

		parent.insertBefore( insert, sibling );
	}

	const InfiniteAjaxScroll = function InfiniteAjaxScroll(
		container,
		options
	) {
		const this$1 = this;
		if ( options === void 0 ) {
			options = {};
		}

		Assert.singleElement( container, 'container' );

		this.container = tealight( container )[ 0 ];
		this.options = extend( {}, defaults, options );
		this.emitter = new tinyEmitter();

		// @todo might need to call enableLoadOnScroll (or disableLoadOnScroll)
		//     instead of injecting the value right away
		this.loadOnScroll = this.options.loadOnScroll;
		this.negativeMargin = Math.abs( this.options.negativeMargin );

		this.scrollContainer = this.options.scrollContainer;
		if ( this.options.scrollContainer !== window ) {
			Assert.singleElement(
				this.options.scrollContainer,
				'options.scrollContainer'
			);

			this.scrollContainer = tealight(
				this.options.scrollContainer
			)[ 0 ];
		}

		this.nextHandler = nextHandler;

		if ( this.options.next === false ) {
			this.nextHandler = function () {};
		} else if ( typeof this.options.next === 'function' ) {
			this.nextHandler = this.options.next;
		}

		this.binded = false;
		this.paused = false;
		this.pageIndex = this.sentinel() ? 0 : -1;

		this.on( HIT, function () {
			if ( ! this$1.loadOnScroll ) {
				return;
			}

			this$1.next();
		} );

		this.on( SCROLLED, this.measure );
		this.on( RESIZED, this.measure );

		// initialize extensions
		this.pagination = new Pagination( this, this.options.pagination );
		this.spinner = new Spinner( this, this.options.spinner );
		this.logger = new Logger( this, this.options.logger );
		this.paging = new Paging( this );
		this.trigger = new Trigger( this, this.options.trigger );

		// @todo review this logic when prefill support is added
		// measure after all plugins are done binding
		this.on( BINDED, this.measure );

		if ( this.options.bind ) {
			// @todo on document.ready? (window.addEventListener('DOMContentLoaded'))
			this.bind();
		}
	};

	InfiniteAjaxScroll.prototype.bind = function bind() {
		if ( this.binded ) {
			return;
		}

		this._scrollListener = lodash_throttle( scrollHandler, 200 ).bind(
			this
		);
		this._resizeListener = lodash_throttle( resizeHandler, 200 ).bind(
			this
		);

		this.scrollContainer.addEventListener( 'scroll', this._scrollListener );
		this.scrollContainer.addEventListener( 'resize', this._resizeListener );

		this.binded = true;

		this.emitter.emit( BINDED );
	};

	InfiniteAjaxScroll.prototype.unbind = function unbind() {
		if ( ! this.binded ) {
			return;
		}

		this.scrollContainer.removeEventListener(
			'resize',
			this._resizeListener
		);
		this.scrollContainer.removeEventListener(
			'scroll',
			this._scrollListener
		);

		this.binded = false;

		this.emitter.emit( UNBINDED );
	};

	InfiniteAjaxScroll.prototype.next = function next() {
		const this$1 = this;

		this.pause();

		const event = {
			pageIndex: this.pageIndex + 1,
		};

		this.emitter.emit( NEXT, event );

		return Promise.resolve( this.nextHandler( event.pageIndex ) ).then(
			function ( result ) {
				this$1.pageIndex = event.pageIndex;

				if ( ! result ) {
					this$1.emitter.emit( LAST );

					return;
				}

				if ( this$1.options.autoResumeAfterLoad ) {
					this$1.resume();
				}
			}
		);
	};

	InfiniteAjaxScroll.prototype.load = function load( url ) {
		const ias = this;

		return new Promise( function ( resolve, reject ) {
			const xhr = new XMLHttpRequest();

			xhr.onreadystatechange = function () {
				if ( xhr.readyState !== XMLHttpRequest.DONE ) {
					return;
				}

				if ( xhr.status === 200 ) {
					let items = xhr.response;

					if ( ias.options.responseType === 'document' ) {
						items = tealight( ias.options.item, xhr.response );
						// @todo assert there actually are items in the response
					}

					ias.emitter.emit( LOADED, {
						items,
						url,
						xhr,
					} );

					resolve( { items, url, xhr } );
				} else {
					// @todo is console.error the best approach?
					console.error( 'Request failed' );

					reject( xhr );
				}
			};

			// FIXME: make no-caching configurable
			// @see https://developer.mozilla.org/nl/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest#Bypassing_the_cache
			const nocacheUrl =
				url + ( /\?/.test( url ) ? '&' : '?' ) + new Date().getTime();

			xhr.open( 'GET', nocacheUrl, true );
			xhr.responseType = ias.options.responseType;
			xhr.setRequestHeader( 'X-Requested-With', 'XMLHttpRequest' );

			// @todo define event variable and pass that around so it can be manipulated

			ias.emitter.emit( LOAD, { url, xhr } );

			xhr.send();
		} );
	};

	/**
	 * @param {Array<Element>} items
	 * @param {Element|null}   parent
	 */
	InfiniteAjaxScroll.prototype.append = function append( items, parent ) {
		const ias = this;
		parent = parent || ias.container;

		const event = {
			items,
			parent,
			appendFn,
		};

		ias.emitter.emit( APPEND, event );

		const executor = function ( resolve ) {
			window.requestAnimationFrame( function () {
				Promise.resolve(
					event.appendFn( event.items, event.parent, ias.sentinel() )
				).then( function () {
					resolve( { items, parent } );
				} );
			} );
		};

		return new Promise( executor ).then( function ( event ) {
			ias.emitter.emit( APPENDED, event );
		} );
	};

	InfiniteAjaxScroll.prototype.sentinel = function sentinel() {
		const items = tealight( this.options.item, this.container );

		if ( ! items.length ) {
			return null;
		}

		return items[ items.length - 1 ];
	};

	InfiniteAjaxScroll.prototype.pause = function pause() {
		this.paused = true;
	};

	InfiniteAjaxScroll.prototype.resume = function resume() {
		this.paused = false;

		this.measure();
	};

	InfiniteAjaxScroll.prototype.enableLoadOnScroll =
		function enableLoadOnScroll() {
			this.loadOnScroll = true;
		};

	InfiniteAjaxScroll.prototype.disableLoadOnScroll =
		function disableLoadOnScroll() {
			this.loadOnScroll = false;
		};

	InfiniteAjaxScroll.prototype.measure = function measure() {
		if ( this.paused ) {
			return;
		}

		let distance = 0;
		const sentinel = this.sentinel();

		// @todo review this logic when prefill support is added
		if ( sentinel ) {
			distance = getDistanceToFold( sentinel, this.scrollContainer );
		}

		// apply negative margin
		distance -= this.negativeMargin;

		if ( distance <= 0 ) {
			this.emitter.emit( HIT, { distance } );
		}
	};

	InfiniteAjaxScroll.prototype.on = function on( event, callback ) {
		this.emitter.on( event, callback, this );

		if ( event === BINDED && this.binded ) {
			callback.bind( this )();
		}
	};

	InfiniteAjaxScroll.prototype.off = function off( event, callback ) {
		this.emitter.off( event, callback, this );
	};

	InfiniteAjaxScroll.prototype.once = function once( event, callback ) {
		this.emitter.once( event, callback, this );

		if ( event === BINDED && this.binded ) {
			callback.bind( this )();
		}
	};

	return InfiniteAjaxScroll;
} );
