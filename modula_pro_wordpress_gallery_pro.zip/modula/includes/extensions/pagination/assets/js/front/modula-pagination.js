jQuery( document ).on(
	'modula_api_after_init',
	function ( modulaEvent, modula ) {
		const $galleryParent = modula.$itemsCnt.parent();
		const gallery_id = $galleryParent.attr( 'id' );
		const config = $galleryParent.data( 'config' );
		if (
			'undefined' === typeof config ||
			'infinite' !== config.load_images
		) {
			return;
		}

		const $spinner = jQuery(
			'<div class="modula-infinite-spinner"><div class="spinner"></div></div>'
		);
		$galleryParent.append( $spinner );

		const ss = new InfiniteAjaxScroll( modula.$itemsCnt, {
			item: '.modula-infinite-scroll-item-' + gallery_id,
			next: '.modula-infinite-pagination.' + gallery_id + ' .next',
			pagination: '.modula-infinite-pagination.' + gallery_id,
			logger: false,
			autoResumeAfterLoad: false,
		} );

		let isLoading = false;

		ss.pause();
		ss.on( 'scrolled', function () {
			if ( ! isLoading ) {
				isLoading = true;
				ss.resume();
			}
		} );

		modula.options.originalHeight = modula.options.height;
		ss.on( 'load', () => {
			isLoading = true;
			$spinner.show();
		} );
		ss.on( 'append', ( event ) => {
			isLoading = false;
			$spinner.hide();
			removeHidden( event.items, gallery_id, modula );
			refreshModula( modula, event, ss.pageIndex );
		} );
		ss.on( 'error', () => {
			isLoading = false;
			$spinner.hide();
		} );
	}
);

function refreshModula( instance, scroll_event, page ) {
	const itemsWrapper = jQuery( scroll_event.parent );
	const items = scroll_event.items;
	const currentPage = page + 2;

	if ( 0 == items.length ) {
		return;
	}

	instance.$itemsCnt.append( items );
	instance.$items = instance.$itemsCnt.find( '.modula-item' );

	if ( 'creative-gallery' == instance.options.type ) {
		instance.$itemsCnt.data(
			'area',
			instance.$itemsCnt.width() * instance.options.height * currentPage
		);
		instance.options.height = instance.options.originalHeight * currentPage;
		instance.$element
			.find( '.modula-items' )
			.height( instance.options.height );
		var creativeGrid = new modulaCreativeGallery( {
			top: instance.options.height,
			items: items.length,
			width: instance.$itemsCnt.width(),
			height: instance.options.originalHeight,
			randomFactor: instance.options.randomFactor,
			gutter: instance.options.gutter,
		} );
	}

	jQuery.each( items, function ( index, value ) {
		const element = jQuery( this );
		const elementImage = jQuery( this ).find( 'img' );
		var slot;

		if ( instance.isIsotope ) {
			instance.$itemsCnt.modulaisotope( 'appended', element );
		}

		if ( 'creative-gallery' == instance.options.type ) {
			var slot = creativeGrid.tiles[ index ];
			instance.tiles.push( slot );

			element.data( 'size', slot );

			element
				.addClass( 'tiled' )
				.addClass( slot.width > slot.height ? 'tile-h' : 'tile-v' )
				.data( 'position' );

			element.css( {
				width: slot.width,
				height: slot.height,
			} );

			element.find( '.figc' ).css( {
				width: slot.width,
				height: slot.height,
			} );

			i = instance.options.images_per_page * ( currentPage - 1 ) + index;
			instance.loadImage( i );
		}
	} );

	if (
		'grid' == instance.options.type &&
		'automatic' == instance.options.grid_type
	) {
		instance.$itemsCnt.justifiedGallery( 'norewind' );
	}

	if ( 'custom-grid' == instance.options.type ) {
		instance.createCustomGallery();
	}

	if ( instance.isIsotope ) {
		instance.$itemsCnt.modulaisotope( 'layout' );
	}
}

function modulaCreativeGallery( options ) {
	const defaults = {
		width: 0,
		height: 0,
		randomFactor: 5,
		gutter: 5,
		items: 0,
		top: 0,
	};

	this.options = jQuery.extend( {}, defaults, options );
	this.tiles = [];

	if ( 0 == this.options.items ) {
		return [];
	}

	for ( let i = 0; i < this.options.items; i++ ) {
		this.tiles.push( this.getSlot() );
	}

	this.tiles.sort( function ( x, y ) {
		return x.position - y.position;
	} );
}

modulaCreativeGallery.prototype.getSlot = function () {
	if ( this.tiles.length == 0 ) {
		var tile = {
			top: this.options.top + this.options.gutter,
			left: 0,
			width: this.options.width,
			height: this.options.height,
			area: this.options.width * this.options.height,
			position: 0,
		};

		return tile;
	}

	let maxTileIdx = 0;
	for ( let i = 0; i < this.tiles.length; i++ ) {
		var tile = this.tiles[ i ];
		if ( tile.area > this.tiles[ maxTileIdx ].area ) {
			maxTileIdx = i;
		}
	}

	var tile = {};

	const maxTileData = this.tiles[ maxTileIdx ];

	if ( maxTileData.width > maxTileData.height ) {
		var randomMaxDelta =
			( maxTileData.width / 2 ) * this.options.randomFactor;

		maxTileData.prevWidth = maxTileData.width;
		maxTileData.width = Math.floor(
			maxTileData.width / 2 + randomMaxDelta * ( Math.random() - 0.5 )
		);

		tile = {
			top: maxTileData.top,
			left: maxTileData.left + maxTileData.width + this.options.gutter,
			width:
				maxTileData.prevWidth - maxTileData.width - this.options.gutter,
			height: maxTileData.height,
		};
	} else {
		var randomMaxDelta =
			( maxTileData.height / 2 ) * this.options.randomFactor;

		maxTileData.prevHeight = maxTileData.height;
		maxTileData.height = Math.floor(
			maxTileData.height / 2 + randomMaxDelta * ( Math.random() - 0.5 )
		);

		tile = {
			left: maxTileData.left,
			top: maxTileData.top + maxTileData.height + this.options.gutter,
			width: maxTileData.width,
			height:
				maxTileData.prevHeight -
				maxTileData.height -
				this.options.gutter,
		};
	}

	tile.area = tile.width * tile.height;
	tile.position = tile.top * 1000 + tile.left;

	maxTileData.position = maxTileData.top * 1000 + maxTileData.left;

	this.tiles[ maxTileIdx ] = maxTileData;
	this.tiles[ maxTileIdx ].area = maxTileData.width * maxTileData.height;

	return tile;
};

function removeHidden( loaded_items, gallery_id, modula ) {
	const hidden_items = modula.$element.find(
		'.hidden-items .modula-hidden-item'
	);

	if ( 0 == hidden_items.length ) {
		return;
	}
	jQuery( loaded_items ).each( function ( index ) {
		item_id = jQuery( this )
			.find( '.modula-item-content a' )
			.data( 'image-id' );
		jQuery( hidden_items ).remove( '#' + item_id );
	} );

	// Update modula instance with the remaining hidden items.
	modula.hiddenItems = modula.$element.find(
		'.hidden-items .modula-hidden-item'
	);
}
