<?php return array('dependencies' => array('wp-element', 'wp-i18n'), 'version' => 'c6f9198d561d1e991824');
