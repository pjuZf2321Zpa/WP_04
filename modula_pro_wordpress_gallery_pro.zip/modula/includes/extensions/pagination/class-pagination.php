<?php
namespace Modula_Pro\Extensions\Pagination;

use Modula_Pro\Extensions\Pagination\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pagination class for Modula Pro plugin.
 */
class Pagination {

	public static $instance;
	public $images_count = 0;

	public function __construct() {
		add_action( 'admin_init', array( Settings::class, 'get_instance' ), 25 );
		add_filter( 'modula_gallery_before_shuffle_images', array( $this, 'images_per_page' ), 999, 2 );
		add_action( 'modula_after_gallery', array( $this, 'navigation_links' ), 15, 1 );
		add_filter( 'modula_gallery_settings', array( $this, 'gallery_settings' ), 15, 2 );

		add_filter( 'modula_gallery_before_shuffle_images', array( $this, 'modula_gallery_images' ) );
		add_filter( 'modula_shortcode_item_data', array( $this, 'modula_item_data' ), 15, 3 );
		add_action( 'modula_shortcode_after_items', array( $this, 'output_not_lazy_loaded_items' ), 10, 3 );
		add_filter( 'modula_gallery_settings', array( $this, 'modula_pagination_config' ), 999, 2 );
		new Enqueue();

		/*
		 * Paginated query views (?modula-page=N) must not be indexed as separate
		 * pages. Always on — no setting.
		 */
		add_filter( 'wp_robots', array( $this, 'filter_wp_robots' ) );
		add_filter( 'get_canonical_url', array( $this, 'filter_canonical_url' ), 20, 2 );
		add_filter( 'wpseo_robots', array( $this, 'filter_yoast_robots' ) );
		add_filter( 'wpseo_canonical', array( $this, 'filter_seo_plugin_canonical' ) );
		add_filter( 'rank_math/frontend/robots', array( $this, 'filter_rank_math_robots' ) );
		add_filter( 'rank_math/frontend/canonical', array( $this, 'filter_seo_plugin_canonical' ) );

		if ( is_admin() ) {
			new Admin\Settings_Editor_Integration();
		}
	}

	/**
	 * Whether the current request is a Modula gallery page query view.
	 *
	 * @return bool
	 */
	private function is_modula_paginated_view(): bool {
		if ( is_admin() ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public query var.
		return isset( $_GET['modula-page'] ) && '' !== $_GET['modula-page'];
	}

	/**
	 * Current request URL with `modula-page` stripped (canonical target).
	 *
	 * @return string
	 */
	private function get_url_without_modula_page(): string {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$url         = home_url( $request_uri );

		return remove_query_arg( 'modula-page', $url );
	}

	/**
	 * Mark paginated gallery views as noindex (WordPress core robots API).
	 *
	 * @param array $robots Robots directives.
	 * @return array
	 */
	public function filter_wp_robots( $robots ) {
		if ( ! $this->is_modula_paginated_view() ) {
			return $robots;
		}

		$robots['noindex'] = true;
		unset( $robots['index'] );

		return $robots;
	}

	/**
	 * Point canonical at the base URL without `modula-page`.
	 *
	 * @param string      $canonical_url Canonical URL.
	 * @param \WP_Post|null $post         Post object.
	 * @return string
	 */
	public function filter_canonical_url( $canonical_url, $post = null ) {
		if ( ! $this->is_modula_paginated_view() ) {
			return $canonical_url;
		}

		$clean = $this->get_url_without_modula_page();

		return $clean ? $clean : $canonical_url;
	}

	/**
	 * Yoast SEO robots string.
	 *
	 * @param string $robots Robots directives.
	 * @return string
	 */
	public function filter_yoast_robots( $robots ) {
		if ( ! $this->is_modula_paginated_view() ) {
			return $robots;
		}

		$parts = array_map( 'trim', explode( ',', (string) $robots ) );
		$parts = array_values(
			array_filter(
				$parts,
				static function ( $part ) {
					return '' !== $part && 0 !== strcasecmp( $part, 'index' );
				}
			)
		);

		if ( ! in_array( 'noindex', array_map( 'strtolower', $parts ), true ) ) {
			array_unshift( $parts, 'noindex' );
		}

		return implode( ', ', $parts );
	}

	/**
	 * Rank Math robots array.
	 *
	 * @param array $robots Robots directives.
	 * @return array
	 */
	public function filter_rank_math_robots( $robots ) {
		if ( ! $this->is_modula_paginated_view() || ! is_array( $robots ) ) {
			return $robots;
		}

		$robots['index'] = 'noindex';

		return $robots;
	}

	/**
	 * Yoast / Rank Math canonical URL.
	 *
	 * @param string $canonical Canonical URL.
	 * @return string
	 */
	public function filter_seo_plugin_canonical( $canonical ) {
		if ( ! $this->is_modula_paginated_view() ) {
			return $canonical;
		}

		$clean = $this->get_url_without_modula_page();

		return $clean ? $clean : $canonical;
	}

	/**
	 * React v2 stack owns pagination output and slicing.
	 */
	private function is_modern_stack_enabled( $settings = array() ): bool {
		if ( ! class_exists( '\Modula\V2\Modern_Gallery' ) ) {
			return false;
		}
		$post_id = is_array( $settings ) ? \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( $settings ) : 0;
		return \Modula\V2\Modern_Gallery::is_modern_stack_enabled( $post_id );
	}

	/**
	 * Return the allowed images/page
	 *
	 * @param $images
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.0.0
	 */
	public function images_per_page( $images, $settings ) {

		if ( $this->is_modern_stack_enabled( $settings ) ) {
			return $images;
		}

		// Allowed gallery types for pagination
		$allowed_types = apply_filters( 'modula_pagination_allowed_types', array( 'creative-gallery', 'custom-grid', 'grid' ) );

		if ( ! in_array( $settings['type'], $allowed_types, true ) ) {
			return $images;
		}

		if ( ! isset( $settings['enable_pagination'] ) || 0 === (int) $settings['enable_pagination'] ) {
			return $images;
		}

		if ( isset( $_GET['jtg-filter'] ) ) {
			$filtered_images = array();
			$filter          = sanitize_title( wp_unslash( $_GET['jtg-filter'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			foreach ( $images as $image ) {
				$image_filters = array_map( 'sanitize_title', explode( ',', $image['filters'] ) );
				if ( in_array( $filter, $image_filters, true ) && ! empty( $image_filters ) ) {
					$filtered_images[] = $image;
				}
			}

			if ( ! empty( $filtered_images ) ) {
				$images = $filtered_images;
			}

			$this->images_count = count( $images );
		}

		$offset     = 0;
		$pagination = count( $images );

		if ( isset( $_GET['modula-page'] ) ) {
			$offset = absint( $_GET['modula-page'] ) - 1;
		}

		if ( isset( $settings['pagination_number'] ) && 0 !== (int) $settings['pagination_number'] && ! empty( $settings['pagination_number'] ) ) {
			$offset     = $offset * absint( $settings['pagination_number'] );
			$pagination = absint( $settings['pagination_number'] );
		}

		$images = array_slice( $images, $offset, $pagination );

		return $images;
	}

	/**
	 * Resolve classic gallery post ID for pagination meta lookups.
	 *
	 * Soft-fails (null) when Lite lacks `Modula_Helper::classic_gallery_post_id`
	 * so an outdated Lite cannot fatal the shortcode / Elementor editor path.
	 *
	 * @param mixed $gallery_id Shortcode gallery_id or numeric post id.
	 * @return int|null
	 * @since 3.0.5
	 */
	public static function resolve_classic_gallery_post_id( $gallery_id ) {
		if ( ! class_exists( '\Modula_Helper', false ) || ! is_callable( array( '\Modula_Helper', 'classic_gallery_post_id' ) ) ) {
			return null;
		}

		return \Modula_Helper::classic_gallery_post_id( $gallery_id );
	}

	/**
	 * Output the navigation links
	 *
	 * @param $settings
	 *
	 * @since 1.0.0
	 */
	public function navigation_links( $settings ) {

		if ( $this->is_modern_stack_enabled( $settings ) ) {
			return;
		}

		// Allowed gallery types for pagination
		$allowed_types = apply_filters( 'modula_pagination_allowed_types', array( 'creative-gallery', 'custom-grid', 'grid' ) );

		if ( in_array( $settings['type'], $allowed_types, true ) ) {
			$post_id = self::resolve_classic_gallery_post_id( $settings['gallery_id'] );
			if ( null === $post_id ) {
				return;
			}

			$images = apply_filters( 'modula_pagination_links', get_post_meta( $post_id, 'modula-images', true ), $settings );

			if ( isset( $_GET['jtg-filter'] ) ) {
				$filtered_images = array();
				$filter          = sanitize_title( wp_unslash( $_GET['jtg-filter'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

				foreach ( $images as $image ) {
					$image_filters = array_map( 'sanitize_title', explode( ',', $image['filters'] ) );
					if ( in_array( $filter, $image_filters, true ) && ! empty( $image_filters ) ) {
						$filtered_images[] = $image;
					}
				}

				if ( ! empty( $filtered_images ) ) {
					$images = $filtered_images;
				}
			}

			$pagination_html = '';
			$infinite_html   = '';
			$load_more_html  = '';

			if ( isset( $settings['enable_pagination'] ) && 0 !== (int) $settings['enable_pagination'] && 0 !== (int) $settings['pagination_number'] && ! empty( $settings['pagination_number'] ) ) {
				if ( isset( $settings['enable_infinite_scroll'] ) && 1 === (int) $settings['enable_infinite_scroll'] ) {
					$page          = isset( $_GET['modula-page'] ) ? absint( $_GET['modula-page'] ) + 1 : 2;
					$numeric_keys  = array_values( array_filter( array_keys( $_GET ), 'is_numeric' ) );
					$base_next_url = ! empty( $numeric_keys ) ? remove_query_arg( $numeric_keys ) : false;

					$infinite_html .= '<div class="modula-infinite-pagination ' . esc_attr( $settings['gallery_id'] ) . '" style="display:none;">';
					$infinite_html .= '<a href="' . esc_url( add_query_arg( 'modula-page', $page, $base_next_url ) ) . '" class="next">Next</a>';
					$infinite_html .= '</div>';
				} elseif ( isset( $settings['enable_load_more'] ) && 1 === (int) $settings['enable_load_more'] ) {
					$page          = isset( $_GET['modula-page'] ) ? absint( $_GET['modula-page'] ) + 1 : 2;
					$numeric_keys  = array_values( array_filter( array_keys( $_GET ), 'is_numeric' ) );
					$base_next_url = ! empty( $numeric_keys ) ? remove_query_arg( $numeric_keys ) : false;

					$load_more_html .= '<div class="modula-load-more-wrap ' . esc_attr( $settings['gallery_id'] ) . '">';
					$load_more_html .= '<a href="' . esc_url( add_query_arg( 'modula-page', $page, $base_next_url ) ) . '" class="next">Next</a>';
					$load_more_html .= '<button type="button" id="modula-' . esc_attr( $settings['gallery_id'] ) . '-load" class="modula-load-more">' . esc_html__( 'Load more', 'modula-pro' ) . '</button>';
					$load_more_html .= '</div>';
				} else {
					$pagination       = $settings['pagination_number'];
					$image_nr         = count( $images );
					$page_num         = ceil( $image_nr / $pagination );
					$pagination_html .= '<div class="modula-navigation pagination ' . esc_attr( $settings['gallery_id'] ) . '"><div class="modula-links-wrapper nav-links">';
					$pagination_html .= paginate_links(
						array(
							'base'      => add_query_arg( array( 'modula-page' => '%#%' ) ),
							'format'    => '',
							'prev_text' => __( '&laquo;', 'modula-pro' ),
							'next_text' => __( '&raquo;', 'modula-pro' ),
							'total'     => $page_num,
							'current'   => ( isset( $_GET['modula-page'] ) ) ? absint( $_GET['modula-page'] ) : '1',
						)
					);
					$pagination_html .= '</div></div>';
				}
			}

			//phpcs:disable
			echo $pagination_html;
			echo $infinite_html;
			echo $load_more_html;
			//phpcs:enable
		}
	}


	/**
	 * @param $js_config
	 * @param $settings
	 *
	 * @return mixed
	 *
	 * @since 1.0.0
	 */
	public function gallery_settings( $js_config, $settings ) {
		if ( isset( $settings['enable_pagination'] ) ) {
			$js_config['pagination'] = boolval( $settings['enable_pagination'] );
		}

		if ( isset( $settings['pagination_number'] ) ) {
			$js_config['images_per_page'] = $settings['pagination_number'];
		}

		if ( $this->images_count > 0 ) {
			$js_config['images_count'] = $this->images_count;
		}

		if ( isset( $settings['enable_infinite_scroll'] ) && '1' === $settings['enable_infinite_scroll'] ) {
			$js_config['load_images'] = 'infinite';
		}

		if ( isset( $settings['enable_load_more'] ) && '1' === $settings['enable_load_more'] ) {
			$js_config['load_images'] = 'button';
		}

		return $js_config;
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Pagination object.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Pagination ) ) {
			self::$instance = new Pagination();
		}

		return self::$instance;
	}

	/**
	 * Set images count
	 *
	 * @param array $images
	 *
	 * @return array $images
	 * @since 1.0.1
	 */
	public function modula_gallery_images( $images ) {
		$this->images_count = count( $images );

		return $images;
	}

	/**
	 * Add extra classes to modula-item so that we can differentiate what we need to retrieve via AJAX when doing infinite scroll or load more
	 *
	 * @param array $item_data
	 * @param array $image
	 * @param array $settings
	 *
	 * @return void
	 * @since 1.0.1
	 */
	public function modula_item_data( $item_data, $image, $settings ) {

		if ( $this->is_modern_stack_enabled( $settings ) ) {
			return $item_data;
		}

		if ( isset( $settings['enable_pagination'] ) && 1 === (int) $settings['enable_pagination'] && isset( $settings['enable_load_more'] ) && 1 === (int) $settings['enable_load_more'] ) {
			$item_data['item_classes'][] = 'modula-load-more-item-' . $settings['gallery_id'];
		}

		if ( isset( $settings['enable_pagination'] ) && 1 === (int) $settings['enable_pagination'] && isset( $settings['enable_infinite_scroll'] ) && 1 === (int) $settings['enable_infinite_scroll'] ) {
			$item_data['item_classes'][] = 'modula-infinite-scroll-item-' . $settings['gallery_id'];
		}

		return $item_data;
	}

	public function output_not_lazy_loaded_items( $settings, $item_data, $images ) {

		if ( $this->is_modern_stack_enabled( $settings ) ) {
			return;
		}

		if ( isset( $settings['maxImagesCount'] ) && ( absint( $settings['maxImagesCount'] ) !== 0 && ! wp_is_mobile() ) ) {
			return;
		}

		if ( isset( $settings['maxImagesCount_mobile'] ) && ( absint( $settings['maxImagesCount_mobile'] ) !== 0 && wp_is_mobile() ) ) {
			return;
		}

		if ( ! isset( $settings['showAllOnLightbox'] ) || absint( $settings['showAllOnLightbox'] ) !== 1 ) {
			return;
		}

		$images_ids = wp_list_pluck( $images, 'id' );

		$chuks      = explode( '-', $settings['gallery_id'] );
		$gallery_id = $chuks[1];

		$all_images = get_post_meta( $gallery_id, 'modula-images', true );

		if ( isset( $_GET['jtg-filter'] ) && ! empty( $_GET['jtg-filter'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$active_filter = sanitize_title( wp_unslash( $_GET['jtg-filter'] ) );
			$all_images    = array_values(
				array_filter(
					$all_images,
					function ( $image ) use ( $active_filter ) {
						$image_filters = array_map( 'sanitize_title', explode( ',', $image['filters'] ) );
						return in_array( $active_filter, $image_filters, true );
					}
				)
			);
		}
		$offset = 0;

		if ( isset( $_GET['modula-page'] ) ) {
			$offset = absint( $_GET['modula-page'] ) - 1;
		}

		if ( isset( $settings['pagination_number'] ) && 0 !== (int) $settings['pagination_number'] && ! empty( $settings['pagination_number'] ) ) {
			$offset = $offset * absint( $settings['pagination_number'] );
		}

		$pre_images     = array_slice( $all_images, 0, $offset );
		$pre_images_ids = wp_list_pluck( $pre_images, 'id' );

		echo '<div class="hidden-items">';
		foreach ( $all_images as $image ) {
			if ( in_array( $image['id'], $images_ids, true ) ) {
				continue;
			}

			$attr = array(
				'class' => array( 'tile-inner', 'modula-hidden-item', 'modula-hidden-item-lazyload' ),
			);

			if ( in_array( $image['id'], $pre_images_ids, true ) ) {
				$attr['class'][] = 'modula-pre-hidden-item';
			}

			if ( isset( $image['filters'] ) ) {
				$filters = explode( ',', $image['filters'] );
				foreach ( $filters as $filter ) {
					$attr['class'][] = 'jtg-filter-all jtg-filter-' . esc_attr( urldecode( sanitize_title( $filter ) ) );
				}
			}

			$image_full = wp_get_attachment_image_src( $image['id'], 'full' );
			if ( is_array( $image_full ) ) {
				$attr['data-full'] = $image_full[0];
			}
			if ( isset( $item_data['link_attributes']['data-fancybox'] ) ) {
				$attr['data-fancybox'] = $item_data['link_attributes']['data-fancybox'];
			}

			$title   = get_the_title( $image['id'] );
			$caption = get_post_field( 'post_excerpt', $image['id'] );

			if ( 'fancybox' === $settings['lightbox'] ) {
				if ( ( isset( $settings['showTitleLightbox'] ) && 1 === absint( $settings['showTitleLightbox'] ) ) && ( isset( $settings['showCaptionLightbox'] ) && 1 === absint( $settings['showCaptionLightbox'] ) ) ) {
					$attr['data-caption'] = esc_attr( '<span class="modula-caption-title">' . $title . '</span><br><span class="modula-caption-description">' . $caption . '</span>' );
				} elseif ( ( isset( $settings['showTitleLightbox'] ) && 1 === absint( $settings['showTitleLightbox'] ) ) && ( ! isset( $settings['showCaptionLightbox'] ) || 1 !== absint( $settings['showCaptionLightbox'] ) ) ) {
					$attr['data-caption'] = esc_attr( '<span class="modula-caption-title">' . $title . '</span>' );
				} elseif ( ( ! isset( $settings['showTitleLightbox'] ) || 1 !== absint( $settings['showTitleLightbox'] ) ) && ( isset( $settings['showCaptionLightbox'] ) && 1 === absint( $settings['showCaptionLightbox'] ) ) ) {
					$attr['data-caption'] = esc_attr( '<span class="modula-caption-description">' . $caption . '</span>' );
				} else {
					$attr['data-caption'] = '';
				}
			} else {
				$attr['data-title'] = $caption;
			}

			$attr['id'] = absint( $image['id'] );
			//phpcs:disable
			echo '<a ' . \Modula_Helper::generate_attributes( apply_filters( 'modula_hidden_items_data', $attr, $settings, $image ) ) . '></a>';
			//phpcs:enable
		}
		echo '</div>';
	}

	public function modula_pagination_config( $js_config, $settings ) {

		if ( isset( $settings['enable_pagination'] ) && 1 === absint( $settings['enable_pagination'] ) &&
			( ! isset( $settings['enable_load_more'] ) || 1 !== absint( $settings['enable_load_more'] ) ) &&
			( ! isset( $settings['enable_infinite_scroll'] ) || 1 !== absint( $settings['enable_infinite_scroll'] ) ) ) {
			$js_config['filterClick'] = 1;
		}

		return $js_config;
	}
}
