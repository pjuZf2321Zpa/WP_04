<?php
/**
 * Settings editor (v2) integration for pagination preview.
 *
 * @package Modula_Pro\Extensions\Pagination
 */

namespace Modula_Pro\Extensions\Pagination\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Editor_Integration
 */
class Settings_Editor_Integration {

	/**
	 * @var string
	 */
	private $extension_url = 'includes/extensions/pagination';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'modula_gallery_settings_editor_enqueue', array( $this, 'enqueue_settings_editor_pagination' ), 10, 1 );
	}

	/**
	 * Enqueue the Pro pagination settings-editor bundle after the lite shell.
	 *
	 * @param int $post_id Gallery post ID.
	 * @return void
	 */
	public function enqueue_settings_editor_pagination( $post_id ) {
		unset( $post_id );

		$asset_path = \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-pagination/index.asset.php';
		$script_url = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-pagination/index.js';
		$style_url  = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-pagination/index.css';

		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset = require $asset_path;
		$deps  = isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] )
			? $asset['dependencies']
			: array();

		if ( ! in_array( 'modula-gallery-settings-editor', $deps, true ) ) {
			$deps[] = 'modula-gallery-settings-editor';
		}

		$version = isset( $asset['version'] ) ? $asset['version'] : \MODULA_PRO_VERSION;

		wp_enqueue_script(
			'modula-settings-editor-pagination',
			$script_url,
			$deps,
			$version,
			true
		);

		if ( file_exists( \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-pagination/index.css' ) ) {
			wp_enqueue_style(
				'modula-settings-editor-pagination',
				$style_url,
				array( 'modula-gallery-settings-editor' ),
				$version
			);
		}

		wp_set_script_translations(
			'modula-settings-editor-pagination',
			'modula-pro',
			\MODULA_PRO_PATH . 'languages'
		);
	}
}
