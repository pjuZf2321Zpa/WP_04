<?php
namespace Modula_Pro\Extensions\Pagination\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pagination settings class for Modula Pro plugin.
 */
class Settings {

	/**
	 * Holds the admin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	public function __construct() {
		//Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_pagination_field' ) );
		// Enqueue admin required scripts
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'modula_pagination_admin_scripts' ), 40 );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'modula_pagination_admin_scripts' ), 40 );
		add_filter( 'modula_lite_default_settings', array( $this, 'pagination_defaults' ), 15, 1 );
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @return object Modula Pagination Settings object
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Settings ) ) {
			self::$instance = new Settings();
		}

		return self::$instance;
	}

	/**
	 * Add pagination fields in settings
	 *
	 * @param $fields
	 *
	 * @return mixed $fields
	 *
	 * @since 1.0.0
	 */
	public function modula_pagination_field( $fields ) {

		$fields['general']['enable_pagination']       = array(
			'name'     => esc_html__( 'Enable pagination', 'modula-pro' ),
			'type'     => 'toggle',
			'default'  => 0,
			'priority' => 93,
			'children' => array( 'enable_infinite_scroll', 'enable_load_more', 'pagination_number', 'pagination_color', 'active_pagination_color', 'pagination_position' ),
		);
		$fields['general']['enable_infinite_scroll']  = array(
			'name'     => esc_html__( 'Enable infinite scroll', 'modula-pro' ),
			'type'     => 'toggle',
			'default'  => 0,
			'priority' => 94,
			'is_child' => true,
			'parent'   => 'enable_pagination',
		);
		$fields['general']['enable_load_more']        = array(
			'name'     => esc_html__( 'Enable Load more button', 'modula-pro' ),
			'type'     => 'toggle',
			'default'  => 0,
			'priority' => 95,
			'is_child' => true,
			'parent'   => 'enable_pagination',
		);
		$fields['general']['pagination_number']       = array(
			'name'     => esc_html__( 'Number of images per page', 'modula-pro' ),
			'type'     => 'text',
			'default'  => get_option( 'posts_per_page' ),
			'is_child' => true,
			'priority' => 96,
		);
		$fields['general']['pagination_color']        = array(
			'name'     => esc_html__( 'Pagination links color', 'modula-pro' ),
			'type'     => 'color',
			'alpha'    => true,
			'default'  => '',
			'is_child' => true,
			'priority' => 97,
		);
		$fields['general']['active_pagination_color'] = array(
			'name'     => esc_html__( 'Pagination active page color', 'modula-pro' ),
			'type'     => 'color',
			'alpha'    => true,
			'default'  => '',
			'is_child' => true,
			'priority' => 98,
		);
		$fields['general']['pagination_position']     = array(
			'name'     => esc_html__( 'Pagination position', 'modula-pro' ),
			'type'     => 'select',
			'default'  => 'left',
			'values'   => array(
				'left'   => esc_html__( 'Left', 'modula-pro' ),
				'center' => esc_html__( 'Center', 'modula-pro' ),
				'right'  => esc_html__( 'Right', 'modula-pro' ),
			),
			'is_child' => true,
			'priority' => 99,
		);

		return $fields;
	}

	/**
	 * Enqueue admin Modula Pagiantion scripts
	 *
	 * @since 1.0.0
	 */
	public function modula_pagination_admin_scripts() {
		wp_enqueue_script( 'modula-pagination-conditions', \MODULA_PRO_URL . 'includes/extensions/pagination/assets/js/admin/modula-pagination-conditions.js', array( 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Pagination defaults
	 *
	 * @param $defaults
	 *
	 * @return mixed
	 *
	 * @since 1.0.0
	 */
	public function pagination_defaults( $defaults ) {

		$defaults['enable_pagination']       = 0;
		$defaults['enable_infinite_scroll']  = 0;
		$defaults['enable_load_more']        = 0;
		$defaults['pagination_number']       = get_option( 'posts_per_page' );
		$defaults['pagination_color']        = '';
		$defaults['active_pagination_color'] = '';
		$defaults['pagination_position']     = 'left';

		return $defaults;
	}
}
