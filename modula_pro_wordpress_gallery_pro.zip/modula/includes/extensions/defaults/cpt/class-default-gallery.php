<?php

namespace Modula_Pro\Extensions\Defaults\CPT;

use Modula_Pro\Extensions\Defaults\Utils\Legacy_Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Default_Gallery {
	private $cpt_name;
	private $labels;
	private $metaboxes;
	private $builder;
	private $args;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_cpt' ), 15 );
		add_action( 'rest_api_init', array( $this, 'register_post_meta_rest' ) );

		$this->cpt_name = apply_filters( 'modula_defaults_cpt_name', 'modula-defaults' );
		if ( ! is_admin() ) {
			return;
		}

		/* Fire our meta box setup function on the post editor screen. */
		add_action( 'load-post.php', array( $this, 'meta_boxes_setup' ) );
		add_action( 'load-post-new.php', array( $this, 'meta_boxes_setup' ) );
		// Scripts & styles
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ), 20 );

		// Add Defaults actions to Modula CTP in publish metabox
		add_action( 'modula_cpt_publish_actions', array( $this, 'output_defaults_metabox' ) );

		add_filter( 'modula_gallery_fields', array( $this, 'remove_fields' ), 99 );

		$this->cpt_name = apply_filters( 'modula_defaults_cpt_name', 'modula-defaults' );

		// Create a default from Modula's gallery action
		// Since 1.0.1
		add_action( 'wp_ajax_create_modula_default', array( $this, 'create_default_from_gallery' ) );

		// Post Table Columns
		add_action( 'admin_menu', array( $this, 'replace_submit_meta_box' ) );

		// Create preset link in list view
		add_filter( 'post_row_actions', array( $this, 'create_default_link' ), 15, 2 );

		// Add the modula-defaults CPT to unistall process
		add_filter( 'modula_uninstall_post_types', array( $this, 'modula_uninstall_modula_defaults' ), 30, 1 );

		add_filter( 'bulk_actions-edit-modula-gallery', array( $this, 'modula_gallery_defaults_bulk_edit' ), 10, 1 );

		add_action( 'init', array( $this, 'add_metaboxes' ) );
	}

	/**
	 * Lite field builder (loaded by Modula_CPT; ensure file exists before use).
	 *
	 * @since 3.0.0
	 * @return \Modula_Field_Builder|null
	 */
	private function get_builder() {
		if ( $this->builder instanceof \Modula_Field_Builder ) {
			return $this->builder;
		}

		if ( ! class_exists( 'Modula_Field_Builder', false ) ) {
			if ( ! defined( 'MODULA_PATH' ) ) {
				return null;
			}

			$helper = MODULA_PATH . 'includes/admin/cpt/class-modula-cpt-fields-helper.php';
			$file   = MODULA_PATH . 'includes/admin/cpt/class-modula-field-builder.php';

			if ( file_exists( $helper ) ) {
				require_once $helper;
			}
			if ( ! file_exists( $file ) ) {
				return null;
			}
			require_once $file;
		}

		if ( ! class_exists( 'Modula_Field_Builder', false ) ) {
			return null;
		}

		$this->builder = \Modula_Field_Builder::get_instance();

		return $this->builder;
	}

	public function add_metaboxes() {
		$this->metaboxes = apply_filters(
			'modula_defaults_cpt_metaboxes',
			array(
				'modula-settings'        => array(
					'title'    => esc_html__( 'Settings', 'modula-pro' ),
					'callback' => 'output_defaults_settings',
					'context'  => 'normal',
				),

				'modula-gallery-sorting' => array(
					'title'    => esc_html__( 'Gallery Sorting', 'modula-pro' ),
					'callback' => 'output_gallery_sorting',
					'context'  => 'side',
				),
			)
		);
	}
	/**
	 * Register CPT
	 *
	 * @since 1.0.0
	 */
	public function register_cpt() {
		$this->labels = apply_filters(
			'modula_defaults_cpt_labels',
			array(
				'name'                  => esc_html__( 'Gallery presets', 'modula-pro' ),
				'singular_name'         => esc_html__( 'Gallery presets', 'modula-pro' ),
				'menu_name'             => esc_html__( 'Modula', 'modula-pro' ),
				'name_admin_bar'        => esc_html__( 'Modula Presets', 'modula-pro' ),
				'archives'              => esc_html__( 'Item Archives', 'modula-pro' ),
				'attributes'            => esc_html__( 'Item Attributes', 'modula-pro' ),
				'parent_item_colon'     => esc_html__( 'Parent Item:', 'modula-pro' ),
				'all_items'             => esc_html__( 'Gallery presets (legacy)', 'modula-pro' ),
				'add_new_item'          => esc_html__( 'Add New Item', 'modula-pro' ),
				'add_new'               => esc_html__( 'Add New', 'modula-pro' ),
				'new_item'              => esc_html__( 'New Item', 'modula-pro' ),
				'edit_item'             => esc_html__( 'Edit Item', 'modula-pro' ),
				'update_item'           => esc_html__( 'Update Item', 'modula-pro' ),
				'view_item'             => esc_html__( 'View Item', 'modula-pro' ),
				'view_items'            => esc_html__( 'View Items', 'modula-pro' ),
				'search_items'          => esc_html__( 'Search Item', 'modula-pro' ),
				'not_found'             => esc_html__( 'Not found', 'modula-pro' ),
				'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'modula-pro' ),
				'featured_image'        => esc_html__( 'Featured Image', 'modula-pro' ),
				'set_featured_image'    => esc_html__( 'Set featured image', 'modula-pro' ),
				'remove_featured_image' => esc_html__( 'Remove featured image', 'modula-pro' ),
				'use_featured_image'    => esc_html__( 'Use as featured image', 'modula-pro' ),
				'insert_into_item'      => esc_html__( 'Insert into item', 'modula-pro' ),
				'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'modula-pro' ),
				'items_list'            => esc_html__( 'Items list', 'modula-pro' ),
				'items_list_navigation' => esc_html__( 'Items list navigation', 'modula-pro' ),
				'filter_items_list'     => esc_html__( 'Filter items list', 'modula-pro' ),
			),
			$this->labels
		);

		$this->args = apply_filters(
			'modula_defaults_cpt_args',
			array(
				'label'               => esc_html__( 'Gallery presets', 'modula-pro' ),
				'description'         => esc_html__( 'Modula is the most powerful, user-friendly WordPress gallery plugin. Add galleries, masonry grids and more in a few clicks.', 'modula-pro' ),
				'supports'            => array( 'title' ),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => 'edit.php?post_type=modula-gallery',
				'menu_position'       => 23,
				//phpcs:disable WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
				'menu_icon'           => 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 32 32"><path fill="#f0f5fa" d="M9.3 25.3c-2.4-0.7-4.7-1.4-7.1-2.1 2.4-3.5 4.7-7 7-10.5C9.3 12.9 9.3 24.9 9.3 25.3z"/><path fill="#f0f5fa" d="M9.6 20.1c3.7 2 7.4 3.9 11.1 5.9 -0.1 0.1-5 5-5.2 5.2C13.6 27.5 11.6 23.9 9.6 20.1 9.6 20.2 9.6 20.2 9.6 20.1z"/><path fill="#f0f5fa" d="M22.3 11.9c-3.7-2-7.4-4-11-6 0 0 0 0 0 0 0 0 0 0 0 0 1.7-1.7 3.4-3.3 5.1-5 0 0 0 0 0.1-0.1C18.5 4.5 20.4 8.2 22.3 11.9 22.4 11.9 22.3 11.9 22.3 11.9z"/><path fill="#f0f5fa" d="M4.7 15c-0.6-2.4-1.2-4.7-1.8-7 0.2 0 11.9 0.6 12.7 0.6 0 0 0 0 0 0 0 0 0 0 0 0 -3.6 2.1-7.2 4.2-10.7 6.3C4.8 15 4.8 15 4.7 15z"/><path fill="#f0f5fa" d="M22.9 19.6c-0.2-4.2-0.3-8.3-0.5-12.5 2.4 0.6 4.8 1.2 7.1 1.8C27.4 12.4 25.1 16 22.9 19.6 22.9 19.6 22.9 19.6 22.9 19.6z"/><path fill="#f0f5fa" d="M27.7 16.8c0.6 2.4 1.2 4.7 1.9 7.1 -4.2-0.2-8.5-0.4-12.7-0.5 0 0 0 0 0 0C20.5 21.2 24.1 19 27.7 16.8z"/></svg>' ),
				'show_in_admin_bar'   => true,
				'show_in_nav_menus'   => false,
				'can_export'          => true,
				'has_archive'         => false,
				'exclude_from_search' => true,
				'rewrite'             => false,
				'show_in_rest'        => true,
			)
		);

		$args           = $this->args;
		$args['labels'] = $this->labels;

		register_post_type( $this->cpt_name, $args );
	}

	public function register_post_meta_rest() {
		register_rest_field(
			'modula-defaults',
			'modulaSettings',
			array(
				'get_callback' => function ( $post_arr ) {
					return get_post_meta( $post_arr['id'], 'modula-settings', true );
				},
			)
		);
	}

	/**
	 * Add the link to action list for post_row_actions
	 *
	 * @param $actions
	 * @param $post
	 *
	 * @return mixed
	 *
	 * @since 1.0.1
	 */
	public function create_default_link( $actions, $post ) {

		if ( Legacy_Admin::should_hide_legacy_defaults_admin() ) {
			return $actions;
		}

		if ( 'modula-gallery' !== get_post_type( $post ) ) {
			return $actions;
		}

		$actions['create_default'] = '<a href="#" class="modula-list-default-create" title="' . esc_attr__( 'Create preset', 'modula-pro' ) . '" post-id="' . absint( $post->ID ) . '">' . esc_html__( 'Create preset', 'modula-pro' ) . '</a><span class="response_status"></span>';

		if ( count( get_posts( array( 'post_type' => 'modula-defaults' ) ) ) > 0 ) {
			$actions['apply_default'] = '<a href="#" class="modula-list-apply-create" title="' . esc_attr__( 'Apply preset', 'modula-pro' ) . '" post-id="' . absint( $post->ID ) . '">' . esc_html__( 'Apply preset', 'modula-pro' ) . '</a>';
		}

		return $actions;
	}

	/**
	 * Metaboxes
	 *
	 * @since 1.0.0
	 */
	public function meta_boxes_setup() {
		/* Add meta boxes on the 'add_meta_boxes' hook. */
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );

		/* Save post meta on the 'save_post' hook. */
		add_action( 'save_post', array( $this, 'save_meta_boxes' ), 10, 2 );
	}

	/**
	 * Admin scripts
	 *
	 * @since 1.0.0
	 */
	public function admin_scripts( $hook ) {
		global $id, $post;

		// Get current screen.
		$screen = get_current_screen();

		// Check if is modula-defaults custom post type
		if ( 'modula-defaults' !== $screen->post_type ) {
			return;
		}

		// Set the post_id
		$post_id = isset( $post->ID ) ? $post->ID : (int) $id;

		if ( 'post-new.php' !== $hook && 'post.php' !== $hook ) {
			return;
		}

		// Media Scripts
		wp_enqueue_media( array( 'post' => $post_id ) );

		// Get current album settings.
		$settings = get_post_meta( $post_id, 'modula-settings', true );

		$modula_defaults_helper['settings'] = is_array( $settings )
		? wp_parse_args( $settings, \Modula_CPT_Fields_Helper::get_defaults() )
		: \Modula_CPT_Fields_Helper::get_defaults();

		wp_enqueue_style( 'wp-color-picker' );
		// Enqueue Code Editor for Custom CSS
		wp_enqueue_code_editor( array( 'type' => 'text/css' ) );
		// Enqueue styles
		wp_enqueue_style( 'modula-jquery-ui' );
		wp_enqueue_style( 'modula-cpt-style' );
		wp_enqueue_style( 'modula-selectize' );
		wp_enqueue_style( 'modula-selectize-default' );
		wp_enqueue_style( 'modula-pro-effects' );
		// Enqueue scripts
		wp_enqueue_script( 'modula-resize-senzor' );
		wp_enqueue_script( 'modula-packery' );
		wp_enqueue_script( 'modula-settings' );
		wp_enqueue_script( 'modula-conditions' );
		wp_enqueue_script( 'modula-pro-conditions' );
		do_action( 'modula_defaults_scripts_before_wp_modula' );

		wp_enqueue_script( 'modula' );

		$modula_defaults_helper = apply_filters( 'modula_helper_properties', $modula_defaults_helper );
		wp_localize_script( 'modula', 'modulaHelper', $modula_defaults_helper );

		do_action( 'modula_defaults_scripts_after_wp_modula' );
	}

	/**
	 * Add metaboxes to CPT
	 *
	 * @since 1.0.0
	 */
	public function add_meta_boxes() {
		foreach ( $this->metaboxes as $metabox_id => $metabox ) {
			add_meta_box(
				$metabox_id,
				$metabox['title'],
				array( $this, $metabox['callback'] ),
				$this->cpt_name,
				$metabox['context'],
				'high'
			);
		}
	}

	/**
	 * Output settings metabox content
	 *
	 * @since 1.0.0
	 */
	public function output_defaults_settings() {
		$builder = $this->get_builder();
		if ( ! $builder ) {
			return;
		}
		$builder->render( 'settings' );
	}

	public function output_gallery_sorting( $post ) {
		echo '<div class="modula-sorting-container">';
		$value = get_post_meta( $post->ID, 'modulaSorting', true );

		if ( empty( $value ) ) {
			$value = 'manual';
		}
		$available = array(
			'manual'            => esc_html__( 'Manual', 'modula-pro' ),
			'dateCreatedNew'    => esc_html__( 'Date created - newest first', 'modula-pro' ),
			'dateCreatedOld'    => esc_html__( 'Date created - oldest first', 'modula-pro' ),
			'dateModifiedFirst' => esc_html__( 'Date modified - most recent first', 'modula-pro' ),
			'dateModifiedLast'  => esc_html__( 'Date modified - most recent last', 'modula-pro' ),
			'titleAZ'           => esc_html__( 'Title alphabetically', 'modula-pro' ),
			'titleZA'           => esc_html__( 'Title reverse', 'modula-pro' ),
			'random'            => esc_html__( 'Random', 'modula-pro' ),
		);

		foreach ( $available as $k => $v ) {
			$checked = $value === $k ? 'checked="checked"' : '';
			echo '<input id="' . esc_attr( $k ) . '" type="radio" name="modula_sorting" ' . esc_attr( $checked ) . ' value="' . esc_attr( $k ) . '">';
			echo '<label for="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</label>';
			echo '<br />';
		}

		echo '</div>';
	}

	/**
	 * Add Modula Presets metabox to Modula's CPT publish metabox
	 *
	 * @since 1.0.1
	 */
	public function output_defaults_metabox() {
		if ( Legacy_Admin::should_hide_legacy_defaults_admin() ) {
			return;
		}

		echo '<div class="defaults_metabox_wrapper">';
		echo '<div class="modula-tooltip"><span>[?]</span>';
		echo '<div class="modula-tooltip-content">' . esc_html__( 'Create a new preset based on this gallery\'s settings or import one from a previously saved preset.', 'modula-pro' ) . '</div>';
		echo '</div>';
		echo esc_html__( 'Modula Presets Actions', 'modula-pro' );
		echo '<div class="modula-defaults-metabox wp-clearfix">';
		echo '<a class="" id="create_default">' . esc_html__( 'Create Preset', 'modula-pro' ) . '</a>';
		echo ( count( get_posts( array( 'post_type' => 'modula-defaults' ) ) ) > 0 ) ? '<a class="button" id="import_default">' . esc_html__( 'Import Preset', 'modula-pro' ) . '</a>' : '';
		echo '<div class="response_status"></div>';
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Save metaboxes settings
	 *
	 * @param $post_id
	 * @param $post
	 *
	 * @return mixed
	 *
	 * @since 1.0.0
	 */
	public function save_meta_boxes( $post_id, $post ) {

		/* Get the post type object. */
		$post_type = get_post_type_object( $post->post_type );

		/* Check if the current user has permission to edit the post. */
		if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) || 'modula-defaults' !== $post_type->name ) {
			return $post_id;
		}
        //phpcs:disable WordPress.Security
		$settings = isset( $_POST['modula-settings'] ) ? wp_unslash( $_POST['modula-settings'] ) : array();
		if ( empty( $settings ) ) {
			return $post_id;
		}

		$fields_with_tabs = \Modula_CPT_Fields_Helper::get_fields( 'all' );
		// Here we will save all our settings
		$modula_settings = array();

		// Ensure $fields_with_tabs is an array before iterating
		if ( ! is_array( $fields_with_tabs ) ) {
			return $post_id;
		}

		// Values for selects
		$effect_values = apply_filters( 'modula_effect_values', array( 'none', 'pufrobo' ) );

		// We will save only our settings.
		foreach ( $fields_with_tabs as $tab => $fields ) {
			// We will iterate throught all fields of current tab
			foreach ( $fields as $field_id => $field ) {
				if ( isset( $settings[ $field_id ] ) ) {
					switch ( $field_id ) {
						case 'effect':
							if ( in_array( $settings[ $field_id ], $effect_values, true ) ) {
								$modula_settings[ $field_id ] = $settings[ $field_id ];
							} else {
								$modula_settings[ $field_id ] = 'pufrobo';
							}
							break;
						default:
							if ( is_array( $settings[ $field_id ] ) ) {
								$sanitized                    = array_map( 'sanitize_text_field', $settings[ $field_id ] );
								$modula_settings[ $field_id ] = apply_filters( 'modula_settings_field_sanitization', $sanitized, $settings[ $field_id ], $field_id, $field );
							} else {
								$modula_settings[ $field_id ] = apply_filters( 'modula_settings_field_sanitization', sanitize_text_field( $settings[ $field_id ] ), $settings[ $field_id ], $field_id, $field );
							}

							break;
					}
				} elseif ( 'toggle' === $field['type'] ) {
					$modula_settings[ $field_id ] = '0';
				} else {
					$modula_settings[ $field_id ] = '';
				}
			}
		}

		$modula_settings['helpergrid'] = isset( $settings['helpergrid'] ) ? 1 : 0;

		if ( isset( $_POST['modula_sorting'] ) ) {
			$modula_sorting = $_POST['modula_sorting'];
			update_post_meta( $post_id, 'modulaSorting', $modula_sorting );
		}

		update_post_meta( $post_id, 'modula-settings', $modula_settings );
	}

	/**
	 * Replace submit meta box
	 *
	 * @since 1.0.0
	 */
	public function replace_submit_meta_box() {
		global $post;
		$post_type = 'modula-defaults';
		remove_meta_box( 'submitdiv', $post_type, 'side' );
		add_meta_box( 'submitdiv', esc_html__( 'Publish', 'modula-pro' ), array( $this, 'post_submit_meta_box' ), $post_type, 'side', 'high' );
	}

	/**
	 * New submit meta box
	 *
	 * @since 1.0.0
	 */
	public function post_submit_meta_box() {
		global $action, $post;
		$post_type        = $post->post_type; // get current post_type
		$post_type_object = get_post_type_object( $post_type );
		$can_publish      = current_user_can( $post_type_object->cap->publish_posts );
		?>
<div class="submitbox" id="submitpost">

	<div id="minor-publishing">

		<?php // Hidden submit button early on so that the browser chooses the right button when form is submitted with Return key ?>
		<div style="display:none;">
			<?php submit_button( __( 'Save', 'modula-pro' ), '', 'save' ); ?>
		</div>

		<div id="minor-publishing-actions">
			<div id="save-action">
				<?php
				if ( 'publish' !== $post->post_status && 'future' !== $post->post_status && 'pending' !== $post->post_status ) {
					$private_style = '';
					if ( 'private' === $post->post_status ) {
						$private_style = 'style="display:none"';
					}
					?>
				<input <?php echo esc_attr( $private_style ); ?> type="submit" name="save" id="save-post"
					value="<?php esc_attr_e( 'Save Draft', 'modula-pro' ); ?>" class="button" />
				<span class="spinner"></span>
				<?php } elseif ( 'pending' === $post->post_status && $can_publish ) { ?>
				<input type="submit" name="save" id="save-post" value="<?php esc_attr_e( 'Save as Pending', 'modula-pro' ); ?>"
					class="button" />
				<span class="spinner"></span>
				<?php } ?>
			</div>
			<?php if ( is_post_type_viewable( $post_type_object ) ) : ?>
			<div id="preview-action">
				<?php
				$preview_link = esc_url( get_preview_post_link( $post ) );
				if ( 'publish' === $post->post_status ) {
					$preview_button_text = esc_html__( 'Preview Changes', 'modula-pro' );
				} else {
					$preview_button_text = esc_html__( 'Preview', 'modula-pro' );
				}

							$preview_button = sprintf(
								'%1$s<span class="screen-reader-text"> %2$s</span>',
								$preview_button_text,
								/* translators: Accessibility text. */
								esc_html__( '(opens in a new tab)', 'modula-pro' )
							);
				?>
				<a class="preview button" href="<?php echo esc_url( $preview_link ); ?>"
					target="wp-preview-<?php echo (int) $post->ID; ?>"
					id="post-preview"><?php echo esc_html( $preview_button ); ?></a>
				<input type="hidden" name="wp-preview" id="wp-preview" value="" />
			</div>
			<?php endif; // public post type ?>
			<?php
				/**
				 * Fires before the post time/date setting in the Publish meta box.
				 *
				 * @param WP_Post $post WP_Post object for the current post.
				 *
				 * @since 4.4.0
				 *
				 */
				/* phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound */
				do_action( 'post_submitbox_minor_actions', $post );
			?>
			<div class="clear"></div>
		</div><!-- #minor-publishing-actions -->

		<div id="misc-publishing-actions">

			<div class="misc-pub-section misc-pub-post-status">
				<?php esc_html_e( 'Status:', 'modula-pro' ); ?> <span id="post-status-display">
					<?php

					switch ( $post->post_status ) {
						case 'private':
							esc_html_e( 'Privately Published', 'modula-pro' );
							break;
						case 'publish':
							esc_html_e( 'Published', 'modula-pro' );
							break;
						case 'future':
							esc_html_e( 'Scheduled', 'modula-pro' );
							break;
						case 'pending':
							esc_html_e( 'Pending Review', 'modula-pro' );
							break;
						case 'draft':
						case 'auto-draft':
							esc_html_e( 'Draft', 'modula-pro' );
							break;
					}
					?>
				</span>
				<?php
				if ( 'publish' === $post->post_status || 'private' === $post->post_status || $can_publish ) {
					$private_style = '';
					if ( 'private' === $post->post_status ) {
						$private_style = 'style="display:none"';
					}
					?>
				<a href="#post_status" <?php echo esc_attr( $private_style ); ?> class="edit-post-status hide-if-no-js"
					role="button"><span aria-hidden="true"><?php esc_html_e( 'Edit', 'modula-pro' ); ?></span> <span
						class="screen-reader-text"><?php esc_html_e( 'Edit status', 'modula-pro' ); ?></span></a>

				<div id="post-status-select" class="hide-if-js">
					<input type="hidden" name="hidden_post_status" id="hidden_post_status"
						value="<?php echo esc_attr( ( 'auto-draft' === $post->post_status ) ? 'draft' : $post->post_status ); ?>" />
					<label for="post_status" class="screen-reader-text"><?php _e( 'Set status', 'modula-pro' ); ?></label>
					<select name="post_status" id="post_status">
						<?php if ( 'publish' === $post->post_status ) : ?>
						<option<?php selected( $post->post_status, 'publish' ); ?> value='publish'>
							<?php esc_html_e( 'Published', 'modula-pro' ); ?></option>
							<?php elseif ( 'private' === $post->post_status ) : ?>
							<option<?php selected( $post->post_status, 'private' ); ?> value='publish'>
								<?php esc_html_e( 'Privately Published', 'modula-pro' ); ?></option>
								<?php elseif ( 'future' === $post->post_status ) : ?>
								<option<?php selected( $post->post_status, 'future' ); ?> value='future'>
									<?php esc_html_e( 'Scheduled', 'modula-pro' ); ?></option>
									<?php endif; ?>
									<option<?php selected( $post->post_status, 'pending' ); ?> value='pending'>
								<?php esc_html_e( 'Pending Review', 'modula-pro' ); ?></option>
								<?php if ( 'auto-draft' === $post->post_status ) : ?>
										<option<?php selected( $post->post_status, 'auto-draft' ); ?> value='draft'>
											<?php esc_html_e( 'Draft', 'modula-pro' ); ?></option>
											<?php else : ?>
											<option<?php selected( $post->post_status, 'draft' ); ?> value='draft'>
												<?php esc_html_e( 'Draft', 'modula-pro' ); ?></option>
												<?php endif; ?>
					</select>
					<a href="#post_status" class="save-post-status hide-if-no-js button"><?php esc_html_e( 'OK', 'modula-pro' ); ?></a>
					<a href="#post_status"
						class="cancel-post-status hide-if-no-js button-cancel"><?php esc_html_e( 'Cancel', 'modula-pro' ); ?></a>
				</div>

				<?php } ?>
			</div><!-- .misc-pub-section -->

			<div class="misc-pub-section misc-pub-visibility" id="visibility">
				<?php esc_html_e( 'Visibility:', 'modula-pro' ); ?> <span id="post-visibility-display">
					<?php

					if ( 'private' === $post->post_status ) {
						$post->post_password = '';
						$visibility          = 'private';
						$visibility_trans    = __( 'Private', 'modula-pro' );
					} elseif ( ! empty( $post->post_password ) ) {
						$visibility       = 'password';
						$visibility_trans = __( 'Password protected', 'modula-pro' );
					} elseif ( 'post' === $post_type && is_sticky( $post->ID ) ) {
						$visibility       = 'public';
						$visibility_trans = __( 'Public, Sticky', 'modula-pro' );
					} else {
						$visibility       = 'public';
						$visibility_trans = __( 'Public', 'modula-pro' );
					}

					echo esc_html( $visibility_trans );
					?>
				</span>
				<?php if ( $can_publish ) { ?>
				<a href="#visibility" class="edit-visibility hide-if-no-js" role="button"><span
						aria-hidden="true"><?php esc_html_e( 'Edit', 'modula-pro' ); ?></span> <span
						class="screen-reader-text"><?php esc_html_e( 'Edit visibility', 'modula-pro' ); ?></span></a>

				<div id="post-visibility-select" class="hide-if-js">
					<input type="hidden" name="hidden_post_password" id="hidden-post-password"
						value="<?php echo esc_attr( $post->post_password ); ?>" />
					<?php if ( 'post' === $post_type ) : ?>
					<input type="checkbox" style="display:none" name="hidden_post_sticky" id="hidden-post-sticky"
						value="sticky" <?php checked( is_sticky( $post->ID ) ); ?> />
					<?php endif; ?>
					<input type="hidden" name="hidden_post_visibility" id="hidden-post-visibility"
						value="<?php echo esc_attr( $visibility ); ?>" />
					<input type="radio" name="visibility" id="visibility-radio-public" value="public"
						<?php checked( $visibility, 'public' ); ?> /> <label for="visibility-radio-public"
						class="selectit"><?php esc_html_e( 'Public', 'modula-pro' ); ?></label><br />
					<?php if ( 'post' === $post_type && current_user_can( 'edit_others_posts' ) ) : ?>
					<span id="sticky-span"><input id="sticky" name="sticky" type="checkbox" value="sticky"
							<?php checked( is_sticky( $post->ID ) ); ?> /> <label for="sticky"
							class="selectit"><?php esc_html_e( 'Stick this post to the front page', 'modula-pro' ); ?></label><br /></span>
					<?php endif; ?>
					<input type="radio" name="visibility" id="visibility-radio-password" value="password"
						<?php checked( $visibility, 'password' ); ?> /> <label for="visibility-radio-password"
						class="selectit"><?php esc_html_e( 'Password protected', 'modula-pro' ); ?></label><br />
					<span id="password-span"><label for="post_password"><?php esc_html_e( 'Password:', 'modula-pro' ); ?></label> <input
							type="text" name="post_password" id="post_password"
							value="<?php echo esc_attr( $post->post_password ); ?>" maxlength="255" /><br /></span>
					<input type="radio" name="visibility" id="visibility-radio-private" value="private"
						<?php checked( $visibility, 'private' ); ?> /> <label for="visibility-radio-private"
						class="selectit"><?php esc_html_e( 'Private', 'modula-pro' ); ?></label><br />

					<p>
						<a href="#visibility" class="save-post-visibility hide-if-no-js button"><?php esc_html_e( 'OK', 'modula-pro' ); ?></a>
						<a href="#visibility"
							class="cancel-post-visibility hide-if-no-js button-cancel"><?php esc_html_e( 'Cancel', 'modula-pro' ); ?></a>
					</p>
				</div>
				<?php } ?>

			</div><!-- .misc-pub-section -->

			<?php
					/* translators: Publish box date string. 1: Date, 2: Time. See https://secure.php.net/date */
					$date_string = __( '%1$s at %2$s', 'modula-pro' );
					/* translators: Publish box date format, see https://secure.php.net/date */
					$date_format = _x( 'M j, Y', 'publish box date format', 'modula-pro' );
					/* translators: Publish box time format, see https://secure.php.net/date */
					$time_format = _x( 'H:i', 'publish box time format', 'modula-pro' );

			if ( 0 !== $post->ID ) {
				if ( 'future' === $post->post_status ) { // scheduled for publishing at a future date
					/* translators: Post date information. %s: Date on which the post is currently scheduled to be published. */
					$stamp = __( 'Scheduled for: %s', 'modula-pro' );
				} elseif ( 'publish' === $post->post_status || 'private' === $post->post_status ) { // already published
					/* translators: Post date information. %s: Date on which the post was published. */
					$stamp = __( 'Published on: %s', 'modula-pro' );
				} elseif ( '0000-00-00 00:00:00' === $post->post_date_gmt ) { // draft, 1 or more saves, no date specified
					$stamp = __( 'Publish <b>immediately</b>', 'modula-pro' );
				} elseif ( time() < strtotime( $post->post_date_gmt . ' +0000' ) ) { // draft, 1 or more saves, future date specified
					/* translators: Post date information. %s: Date on which the post is to be published. */
					$stamp = __( 'Schedule for: %s', 'modula-pro' );
				} else { // draft, 1 or more saves, date specified
					/* translators: Post date information. %s: Date on which the post is to be published. */
					$stamp = __( 'Publish on: %s', 'modula-pro' );
				}
				$date = sprintf(
					$date_string,
					date_i18n( $date_format, strtotime( $post->post_date ) ),
					date_i18n( $time_format, strtotime( $post->post_date ) )
				);
			} else { // draft (no saves, and thus no date specified)
				$stamp = __( 'Publish <b>immediately</b>', 'modula-pro' );
				$date  = sprintf(
					$date_string,
					date_i18n( $date_format, strtotime( current_time( 'mysql' ) ) ),
					date_i18n( $time_format, strtotime( current_time( 'mysql' ) ) )
				);
			}

			if ( $can_publish ) :
				?>
			<div class="misc-pub-section curtime misc-pub-curtime">
				<span id="timestamp">
				<?php printf( $stamp, '<b>' . esc_html( $date ) . '</b>' ); ?>
				</span>
				<a href="#edit_timestamp" class="edit-timestamp hide-if-no-js" role="button">
					<span aria-hidden="true"><?php esc_html_e( 'Edit', 'modula-pro' ); ?></span>
					<span class="screen-reader-text"><?php esc_html_e( 'Edit date and time', 'modula-pro' ); ?></span>
				</a>
				<fieldset id="timestampdiv" class="hide-if-js">
					<legend class="screen-reader-text"><?php esc_html_e( 'Date and time', 'modula-pro' ); ?></legend>
					<?php touch_time( ( 'edit' === $action ), 1 ); ?>
				</fieldset>
			</div>
			<?php endif; ?>

			<?php if ( 'draft' === $post->post_status && get_post_meta( $post->ID, '_customize_changeset_uuid', true ) ) : ?>
			<div class="notice notice-info notice-alt inline">
				<p>
					<?php
						printf(
						/* translators: %s: URL to the Customizer. */
							esc_html__( 'This draft comes from your <a href="%s">unpublished customization changes</a>. You can edit, but there&#8217;s no need to publish now. It will be published automatically with those changes.', 'modula-pro' ),
							esc_url(
								add_query_arg(
									'changeset_uuid',
									rawurlencode( get_post_meta( $post->ID, '_customize_changeset_uuid', true ) ),
									admin_url( 'customize.php' )
								)
							)
						);
					?>
				</p>
			</div>
			<?php endif; ?>

			<?php
				/**
				 * Fires after the post time/date setting in the Publish meta box.
				 *
				 * @param WP_Post $post WP_Post object for the current post.
				 *
				 * @since 4.4.0 Added the `$post` parameter.
				 *
				 * @since 2.9.0
				 */
				/* phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound */
				do_action( 'post_submitbox_misc_actions', $post );
			?>
		</div>
		<div class="clear"></div>
	</div>
	<div class="modula-shortcuts">
		<?php esc_html_e( 'Want a faster and easier way to save presets? Use our Keyboard shortcut:', 'modula-pro' ); ?>
		<strong>CTRL/CMD + S</strong>
	</div>
	<div id="major-publishing-actions">
		<?php
				/**
				 * Fires at the beginning of the publishing actions section of the Publish meta box.
				 *
				 * @param WP_Post|null $post WP_Post object for the current post on Edit Post screen,
				 *                           null on Edit Link screen.
				 *
				 * @since 4.9.0 Added the `$post` parameter.
				 *
				 * @since 2.7.0
				 */
				/* phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound */
				do_action( 'post_submitbox_start', $post );
		?>
		<div id="delete-action">
			<?php
			if ( current_user_can( 'delete_post', $post->ID ) ) {
				if ( ! EMPTY_TRASH_DAYS ) {
					$delete_text = __( 'Delete Permanently', 'modula-pro' );
				} else {
					$delete_text = __( 'Move to Trash', 'modula-pro' );
				}
				?>
			<a class="submitdelete deletion"
				href="<?php echo get_delete_post_link( $post->ID ); ?>"><?php echo esc_html( $delete_text ); ?></a>
				<?php
			}
			?>
		</div>
		<div id="publishing-action">
			<span class="spinner"></span>

			<?php
			if ( ! in_array( $post->post_status, array( 'publish', 'future', 'private' ), true ) || 0 === $post->ID ) {
				if ( $can_publish ) :
					if ( ! empty( $post->post_date_gmt ) && time() < strtotime( $post->post_date_gmt . ' +0000' ) ) :
						?>
			<input name="original_publish" type="hidden" id="original_publish"
				value="<?php echo esc_attr_x( 'Schedule', 'post action/button label', 'modula-pro' ); ?>" />
						<?php submit_button( _x( 'Schedule', 'post action/button label', 'modula-pro' ), 'primary large', 'publish', false ); ?>
			<?php else : ?>
			<input name="original_publish" type="hidden" id="original_publish"
				value="
				<?php
				esc_attr_e( 'Update ', 'modula-pro' ) . 'modula-defaults';
				?>
" />
				<?php submit_button( __( 'Save Preset', 'modula-pro' ), 'primary large', 'publish', false ); ?>
				<?php
					endif;
				else :
					?>
			<input name="original_publish" type="hidden" id="original_publish"
				value="<?php esc_attr_e( 'Submit for Review', 'modula-pro' ); ?>" />
					<?php submit_button( __( 'Submit for Review', 'modula-pro' ), 'primary large', 'publish', false ); ?>
					<?php
				endif;
			} else {
				?>

			<input name="save" type="submit" class="button button-primary button-large" id="publish"
				value="<?php esc_attr_e( 'Update Preset', 'modula-pro' ) . 'modula-defaults'; ?>" />
				<?php
			}
			?>
		</div>
		<div class="clear"></div>
	</div>
</div> 
		<?php
	}

	/**
	 * Unset Insert watermark field
	 *
	 * @param $fields
	 *
	 * @return mixed
	 *
	 * @since 1.0.0
	 */
	public function remove_fields( $fields ) {
		global $post;

		if ( isset( $fields['watermark']['watermark_apply_to_existing_images'] ) && 'modula-defaults' === get_post_type( $post ) ) {
			unset( $fields['watermark']['watermark_apply_to_existing_images'] );
		}

		if ( isset( $fields['watermark']['watermark_remove_watermark'] ) && 'modula-defaults' === get_post_type( $post ) ) {
			unset( $fields['watermark']['watermark_remove_watermark'] );
		}

		return $fields;
	}

	/**
	 * Create a Modula Preset from current gallery settings
	 *
	 * @since 1.0.1
	 */
	public function create_default_from_gallery() {

		check_ajax_referer( 'modula-defaults', 'nonce' );

		if ( ! isset( $_POST['post_id'] ) ) {
			wp_die( esc_html__( 'No gallery to duplicate has been supplied!', 'modula-pro' ) );
		}

		$id = absint( $_POST['post_id'] );
		if ( ! current_user_can( 'edit_post', $id ) ) {
			wp_die( -1, 403 );
		}

		// Get the original post
		$post             = get_post( $id );
		$gallery_settings = get_post_meta( $id, 'modula-settings', true );
		$sorting          = get_post_meta( $id, 'modulaSorting', true );

		if ( isset( $post ) && null !== $post ) {
			$title = $post->post_title;

			if ( '' === $title ) {
				// empty title
				$title = esc_html__( 'Preset from gallery ID', 'modula-pro' ) . $id;
			} else {
				$title = esc_html__( 'Preset from ', 'modula-pro' ) . $title;
			}

			$post_name = $post->post_name;

			$new_post = array(
				'post_content'          => $post->post_content,
				'post_status'           => 'publish',
				'post_content_filtered' => $post->post_content_filtered,
				'post_mime_type'        => $post->post_mime_type,
				'post_password'         => $post->post_password,
				'post_title'            => $title,
				'post_type'             => 'modula-defaults',
				'post_name'             => $post_name,
			);

			$new_post_id = wp_insert_post( wp_slash( $new_post ) );

			update_post_meta( $new_post_id, 'modula-settings', wp_parse_args( $gallery_settings, \Modula_CPT_Fields_Helper::get_defaults() ) );
			update_post_meta( $new_post_id, 'modulaSorting', $sorting );
			echo esc_html__( 'Preset Created', 'modula-pro' );
			die();
		} else {
			wp_die( esc_html__( 'Copy creation failed, original post not a Modula gallery:', 'modula-pro' ) . ' ' . esc_html( $id ) );
		}
	}

	/**
	 * Add defaults-albums Custom Post Type to uninstall process
	 *
	 * @param $cpts
	 *
	 * @return mixed
	 * @since 1.0.1
	 */
	public function modula_uninstall_modula_defaults( $cpts ) {
		$cpts[] = 'modula-defaults';

		return $cpts;
	}

	/**
	 * Add bulk edit options
	 *
	 * @param $bulk_actions
	 *
	 * @return mixed
	 * @since 1.0.1
	 */
	public function modula_gallery_defaults_bulk_edit( $bulk_actions ) {
		if ( Legacy_Admin::should_hide_legacy_defaults_admin() ) {
			return $bulk_actions;
		}

		$bulk_actions['apply_default'] = esc_html__( 'Apply preset', 'modula-pro' );

		return $bulk_actions;
	}
}
