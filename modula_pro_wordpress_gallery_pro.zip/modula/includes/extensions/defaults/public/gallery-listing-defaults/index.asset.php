<?php return array('dependencies' => array('wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '527a7cbe318ccb8f06ce');
