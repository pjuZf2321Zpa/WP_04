<?php return array('dependencies' => array('wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '200b5bfc978383d4c4b8');
