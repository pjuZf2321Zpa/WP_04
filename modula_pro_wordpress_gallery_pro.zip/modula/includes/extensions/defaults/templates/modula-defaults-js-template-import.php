<script type="text/html" id="tmpl-modula-defaults-import">
	<div class="media-frame-title">
		<h3><?php esc_html_e( 'Import preset', 'modula-pro' ); ?></h3>
	</div>
	<div class="media-frame-content">
		<div id="modula-defaults-import" class="attachments-browser" post-id="<?php echo get_the_ID(); ?>">
			<label>
				<select id="modula-defaults-select">
					<option value="none" disabled selected><?php echo esc_html( 'Select a preset to import', 'modula-pro' ); ?></option>
				</select>
			</label>
		</div>
	</div>
	<div class="media-frame-toolbar">
		<div class="media-toolbar">
			<div class="media-toolbar-primary search-form">
				<a href="#"
					class="modula-gallery-import-submit button media-button button-large media-button-insert"
					title="<?php esc_attr_e( 'Import', 'modula-pro' ); ?>">
					<?php esc_html_e( 'Import', 'modula-pro' ); ?>
				</a>
			</div>
		</div>
	</div>
</script>
