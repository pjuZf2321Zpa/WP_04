<script type="text/html" id="tmpl-modula-defaults-configuration">
	<div class="media-frame-title">
		<h3 class="create-me"></h3>
	</div>
	<div class="media-frame-content">
		<div id="modula-defaults" class="attachments-browser">
			<h4><?php esc_html_e( 'Select preset', 'modula-defaults' ); ?></h4>
			<label>
				<select id="modula-defaults-select">
					<option value="none" disabled
					        selected><?php echo esc_html( 'Select a preset', 'modula-defaults' ); ?></option>
				</select>
			</label>
		</div>
	</div>
	<div class="media-frame-toolbar">
		<div class="media-toolbar">
			<div class="media-toolbar-primary search-form">
				<a href="#" id="modula-cfs"
				   class="button media-button button-large media-button-insert button-secondary"
				   title="<?php esc_attr_e( 'Create without preset', 'modula-defaults' ); ?>">
					<?php esc_html_e( 'Create without preset', 'modula-defaults' ); ?>
				</a>
				<a href="#" id="modula-uap"
				   class="modula-gallery-create-submit button media-button button-large media-button-insert button-primary"
				   title="<?php esc_attr_e( 'Create with preset', 'modula-defaults' ); ?>" disabled="">
					<?php esc_html_e( 'Create with preset', 'modula-defaults' ); ?>
				</a>
			</div>
		</div>
	</div>
</script>