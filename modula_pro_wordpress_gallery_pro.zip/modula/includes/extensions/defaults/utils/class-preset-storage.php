<?php
/**
 * Gallery / album presets storage (flat + v2 grouped meta).
 *
 * @package Modula_Pro\Extensions\Defaults
 */

namespace Modula_Pro\Extensions\Defaults\Utils;

defined( 'ABSPATH' ) || exit;

/**
 * Class Preset_Storage
 */
class Preset_Storage {

	const PRESET_POST_TYPE = 'modula-defaults';

	const ALBUM_PRESET_POST_TYPE = 'defaults-albums';

	const SETTINGS_V2_META_KEY = 'modula_settings_v2';

	/** Statuses of gallery presets offered for applying (trash is excluded). */
	const LISTED_PRESET_STATUSES = array( 'publish', 'draft', 'private' );

	/**
	 * Whether Modula lite v2 settings stack is available (autoload-enabled check).
	 *
	 * @return bool
	 */
	public static function v2_settings_available() {
		if ( class_exists( '\Modula\V2\Settings\Sanitizer' ) ) {
			return true;
		}

		if ( defined( 'MODULA_PATH' ) ) {
			$autoload = MODULA_PATH . 'includes/v2/autoload.php';
			if ( is_readable( $autoload ) ) {
				require_once $autoload;
			}
		}

		return class_exists( '\Modula\V2\Settings\Sanitizer' )
			&& class_exists( '\Modula\V2\Settings\Adapter' );
	}

	/**
	 * @return bool
	 */
	public static function v2_meta_sync_available() {
		if ( class_exists( '\Modula\V2\Meta_Sync' ) ) {
			return true;
		}

		if ( defined( 'MODULA_PATH' ) ) {
			$autoload = MODULA_PATH . 'includes/v2/autoload.php';
			if ( is_readable( $autoload ) ) {
				require_once $autoload;
			}
		}

		return class_exists( '\Modula\V2\Meta_Sync' );
	}

	/**
	 * List gallery default presets.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function list_presets() {
		$posts = get_posts(
			array(
				'post_type'      => self::PRESET_POST_TYPE,
				'post_status'    => self::LISTED_PRESET_STATUSES,
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$out = array();
		foreach ( $posts as $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$out[] = self::format_preset_list_item( $post );
		}

		return $out;
	}

	/**
	 * Layout label for a build_summary() result.
	 *
	 * @param array<string, mixed> $summary Preset summary.
	 * @return string Translated layout label, '' when unknown or Lite labels are unavailable.
	 */
	public static function summary_layout_label( array $summary ) {
		$layout_type = $summary['highlights']['layoutType'] ?? '';
		if ( '' === $layout_type || ! class_exists( '\Modula\V2\Settings\Gallery_Type_Labels' ) ) {
			return '';
		}
		return \Modula\V2\Settings\Gallery_Type_Labels::label_for( $layout_type );
	}

	/**
	 * Whether a post is a gallery preset that list_presets() offers.
	 *
	 * @param int $preset_id Candidate preset ID.
	 * @return bool
	 */
	public static function is_listed_preset( $preset_id ) {
		$preset_id = absint( $preset_id );
		return $preset_id
			&& self::PRESET_POST_TYPE === get_post_type( $preset_id )
			&& in_array( get_post_status( $preset_id ), self::LISTED_PRESET_STATUSES, true );
	}

	/**
	 * List album default presets (`defaults-albums`).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function list_album_presets() {
		$posts = get_posts(
			array(
				'post_type'      => self::ALBUM_PRESET_POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$out = array();
		foreach ( $posts as $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$out[] = self::format_album_preset_list_item( $post );
		}

		return $out;
	}

	/**
	 * @param \WP_Post $post Preset post.
	 * @return array<string, mixed>
	 */
	public static function format_preset_list_item( \WP_Post $post ) {
		$grouped = self::get_preset_grouped( (int) $post->ID );

		return array(
			'id'      => (int) $post->ID,
			'title'   => self::get_preset_title( $post ),
			'updated' => mysql2date( 'c', $post->post_modified_gmt, false ),
			'summary' => self::build_summary( $grouped ),
		);
	}

	/**
	 * @param \WP_Post $post Album preset post.
	 * @return array<string, mixed>
	 */
	public static function format_album_preset_list_item( \WP_Post $post ) {
		$grouped = self::get_album_preset_grouped( (int) $post->ID );

		return array(
			'id'      => (int) $post->ID,
			'title'   => self::get_preset_title( $post ),
			'updated' => mysql2date( 'c', $post->post_modified_gmt, false ),
			'summary' => self::build_summary( $grouped ),
		);
	}

	/**
	 * @param int $preset_id Preset post ID.
	 * @return array<string, mixed>|null
	 */
	public static function get_preset( $preset_id ) {
		$preset_id = absint( $preset_id );
		$post      = get_post( $preset_id );

		if ( ! $post || self::PRESET_POST_TYPE !== $post->post_type ) {
			return null;
		}

		$grouped = self::get_preset_grouped( $preset_id );

		return array(
			'id'       => $preset_id,
			'title'    => self::get_preset_title( $post ),
			'updated'  => mysql2date( 'c', $post->post_modified_gmt, false ),
			'settings' => $grouped,
			'sorting'  => self::get_preset_sorting( $preset_id ),
			'summary'  => self::build_summary( $grouped ),
		);
	}

	/**
	 * @param int $preset_id Album preset post ID.
	 * @return array<string, mixed>|null
	 */
	public static function get_album_preset( $preset_id ) {
		$preset_id = absint( $preset_id );
		$post      = get_post( $preset_id );

		if ( ! $post || self::ALBUM_PRESET_POST_TYPE !== $post->post_type ) {
			return null;
		}

		$grouped = self::get_album_preset_grouped( $preset_id );

		return array(
			'id'       => $preset_id,
			'title'    => self::get_preset_title( $post ),
			'updated'  => mysql2date( 'c', $post->post_modified_gmt, false ),
			'settings' => $grouped,
			'sorting'  => self::get_preset_sorting( $preset_id ),
			'summary'  => self::build_summary( $grouped ),
		);
	}

	/**
	 * Read a gallery preset as grouped v2 settings.
	 *
	 * Prefer stored `modula_settings_v2` when the raw meta is non-empty. Do not
	 * trust `Meta_Sync::get_settings_v2()` emptiness alone: normalize_settings_v2_read()
	 * injects responsive defaults into an empty document, which would skip flat
	 * adapt for legacy (flat-only) presets. Flat-only presets adapt via
	 * Adapter::to_grouped( …, legacy_import ) — same path as first gallery open.
	 *
	 * @param int $preset_id Preset post ID.
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_preset_grouped( $preset_id, $repair = true ) {
		$preset_id = absint( $preset_id );
		if ( ! $preset_id ) {
			return array();
		}

		$v2_key = self::v2_meta_sync_available()
			? \Modula\V2\Meta_Sync::SETTINGS_V2_META_KEY
			: self::SETTINGS_V2_META_KEY;
		$raw    = get_post_meta( $preset_id, $v2_key, true );

		if ( self::raw_settings_v2_meta_non_empty( $raw ) ) {
			if ( self::v2_meta_sync_available() ) {
				return \Modula\V2\Meta_Sync::get_settings_v2( $preset_id, $repair );
			}
			if ( is_string( $raw ) ) {
				$decoded = json_decode( $raw, true );
				return is_array( $decoded ) ? $decoded : array();
			}
			return is_array( $raw ) ? $raw : array();
		}

		$flat = get_post_meta( $preset_id, 'modula-settings', true );
		if ( ! is_array( $flat ) ) {
			$flat = array();
		}

		if ( self::v2_settings_available() ) {
			return \Modula\V2\Settings\Adapter::to_grouped(
				$flat,
				array( 'legacy_import' => true )
			);
		}

		return array();
	}

	/**
	 * Whether raw modula_settings_v2 meta holds a real stored document.
	 *
	 * @param mixed $raw Post meta value for settings v2.
	 * @return bool
	 */
	private static function raw_settings_v2_meta_non_empty( $raw ) {
		if ( is_string( $raw ) && '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			return is_array( $decoded ) && ! empty( $decoded );
		}
		return is_array( $raw ) && ! empty( $raw );
	}

	/**
	 * @param int $preset_id Preset post ID.
	 * @return string
	 */
	public static function get_preset_sorting( $preset_id ) {
		$sorting = get_post_meta( absint( $preset_id ), 'modulaSorting', true );
		return is_string( $sorting ) && '' !== $sorting ? $sorting : 'manual';
	}

	/**
	 * Persist grouped settings on a preset post (dual flat + v2).
	 *
	 * @param int                                  $preset_id Preset post ID.
	 * @param array<string, array<string, mixed>> $grouped   Grouped settings.
	 * @param string                               $sorting   Gallery sorting mode.
	 * @return true|\WP_Error
	 */
	public static function save_preset_grouped( $preset_id, array $grouped, $sorting = 'manual' ) {
		$preset_id = absint( $preset_id );
		if ( ! $preset_id || self::PRESET_POST_TYPE !== get_post_type( $preset_id ) ) {
			return new \WP_Error( 'modula_invalid_preset', __( 'Invalid preset.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( ! self::v2_settings_available() ) {
			return new \WP_Error( 'modula_v2_unavailable', __( 'Modula v2 settings are not available.', 'modula-pro' ), array( 'status' => 500 ) );
		}

		$sanitized = \Modula\V2\Settings\Sanitizer::sanitize_grouped( $grouped );
		$json      = wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$v2_key    = self::v2_meta_sync_available()
			? \Modula\V2\Meta_Sync::SETTINGS_V2_META_KEY
			: self::SETTINGS_V2_META_KEY;
		update_post_meta( $preset_id, $v2_key, wp_slash( false !== $json ? $json : '{}' ) );

		$flat = \Modula\V2\Settings\Adapter::to_flat( $sanitized );

		update_post_meta( $preset_id, 'modula-settings', wp_slash( wp_parse_args( $flat, \Modula_CPT_Fields_Helper::get_defaults() ) ) );
		update_post_meta( $preset_id, 'modulaSorting', sanitize_text_field( $sorting ) );

		return true;
	}

	/**
	 * Create a new preset post from grouped settings.
	 *
	 * @param string                               $title   Preset title.
	 * @param array<string, array<string, mixed>> $grouped Grouped settings.
	 * @param string                               $sorting Sorting mode.
	 * @return int|\WP_Error New preset post ID.
	 */
	public static function create_preset( $title, array $grouped, $sorting = 'manual' ) {
		$title = sanitize_text_field( $title );
		if ( '' === $title ) {
			$title = __( 'Gallery preset', 'modula-pro' );
		}

		$preset_id = wp_insert_post(
			wp_slash(
				array(
					'post_title'  => $title,
					'post_status' => 'publish',
					'post_type'   => self::PRESET_POST_TYPE,
				)
			),
			true
		);

		if ( is_wp_error( $preset_id ) ) {
			return $preset_id;
		}

		$saved = self::save_preset_grouped( (int) $preset_id, $grouped, $sorting );
		if ( is_wp_error( $saved ) ) {
			wp_delete_post( $preset_id, true );
			return $saved;
		}

		return (int) $preset_id;
	}

	/**
	 * Apply preset settings to a gallery (settings only; images untouched).
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @param int $preset_id  Preset post ID.
	 * @return array<string, mixed>|\WP_Error Applied grouped settings payload.
	 */
	public static function apply_preset_to_gallery( $gallery_id, $preset_id, $repair_source = true ) {
		$gallery_id = absint( $gallery_id );
		$preset_id  = absint( $preset_id );

		if ( 'modula-gallery' !== get_post_type( $gallery_id ) ) {
			return new \WP_Error( 'modula_invalid_gallery', __( 'Invalid gallery.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( self::PRESET_POST_TYPE !== get_post_type( $preset_id ) ) {
			return new \WP_Error( 'modula_invalid_preset', __( 'Invalid preset.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		$grouped = self::get_preset_grouped( $preset_id, $repair_source );
		if ( empty( $grouped ) ) {
			return new \WP_Error( 'modula_empty_preset', __( 'Preset has no settings.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( ! self::v2_settings_available() ) {
			return new \WP_Error( 'modula_v2_unavailable', __( 'Modula v2 settings are not available.', 'modula-pro' ), array( 'status' => 500 ) );
		}

		if ( ! self::v2_meta_sync_available() ) {
			return new \WP_Error( 'modula_v2_unavailable', __( 'Modula v2 settings are not available.', 'modula-pro' ), array( 'status' => 500 ) );
		}
		$grouped['freeform']['placements'] = self::preset_layout_placements( $gallery_id, $grouped );

		$sanitized = \Modula\V2\Settings\Sanitizer::sanitize_grouped( $grouped );
		$sorting   = self::get_preset_sorting( $preset_id );
		$write     = static function () use ( $gallery_id, $sanitized, $sorting ) {
			self::write_gallery_settings( $gallery_id, $sanitized, $sorting );
		};

		/*
		 * v2 is canonical here. Without the guard, the flat compatibility write fires
		 * Meta_Sync's updated_post_meta rebuild, which re-derives an unstamped custom
		 * hover builder from the legacy effect and overwrites the preset's hover.
		 * Lite before 3.0.12 has no guard, so write directly there, as Pro 3.0.15 did.
		 */
		if ( is_callable( array( '\Modula\V2\Meta_Sync', 'with_canonical_gallery_write' ) ) ) {
			\Modula\V2\Meta_Sync::with_canonical_gallery_write( $gallery_id, $write );
		} else {
			$write();
		}

		return array(
			'settings' => $sanitized,
			'sorting'  => $sorting,
		);
	}

	/**
	 * Whether grouped preset settings carry a Preset layout (ADR 0051): a Freeform
	 * preset whose placements are kept as ordered slots.
	 *
	 * @param array<string, array<string, mixed>> $grouped Grouped preset settings.
	 * @return bool
	 */
	private static function has_preset_layout( array $grouped ) {
		$slots = $grouped['freeform']['placements'] ?? array();
		return 'freeform' === ( $grouped['general']['type'] ?? '' ) && is_array( $slots ) && array() !== $slots;
	}

	/**
	 * Freeform placements a gallery keeps after Apply preset.
	 *
	 * A Preset layout's slots carry another gallery's occurrence identities, so they map
	 * by catalog order instead (ADR 0051): slot N goes to the target's Nth item and
	 * replaces its arrangement. Items beyond the slots get no placement, so the write-time
	 * reconcile appends them in rows of 3; slots beyond the items are dropped. Without a
	 * Preset layout or target items, the target keeps its own placements.
	 *
	 * @param int                                 $gallery_id Target gallery ID.
	 * @param array<string, array<string, mixed>> $grouped    Grouped preset settings.
	 * @return array<int, array<string, mixed>> Placements to store on the target.
	 */
	private static function preset_layout_placements( $gallery_id, array $grouped ) {
		$own = \Modula\V2\Meta_Sync::get_settings_v2( $gallery_id, false )['freeform']['placements'] ?? array();
		if ( ! self::has_preset_layout( $grouped ) || ! class_exists( '\Modula\V2\Freeform_Catalog' ) ) {
			return $own;
		}

		$rows    = array_values( array_filter( \Modula\V2\Meta_Sync::get_images_v2( $gallery_id ), 'is_array' ) );
		$columns = (int) ( \Modula\V2\Settings\Registry::get_schema()['freeform']['placements']['items']['properties']['w']['maximum'] ?? 0 );
		// Without a surface width, slots cannot be kept on the surface; keep the target's own layout.
		if ( array() === $rows || $columns < 1 ) {
			return $own;
		}

		// Reads derive the same identities once placements are stored, so the catalog needs no write.
		$ids   = array_column( \Modula\V2\Freeform_Catalog::identify( $rows ), 'freeformId' );
		$slots = array_values( $grouped['freeform']['placements'] );
		$count = min( count( $ids ), count( $slots ) );

		$placements = array();
		for ( $index = 0; $index < $count; $index++ ) {
			$placements[] = self::constrain_slot( $ids[ $index ], (array) $slots[ $index ], $columns );
		}
		return $placements;
	}

	/**
	 * Place a Preset layout slot on an item, kept on the surface like any placement.
	 * Mirrors constrainFreeformPlacement() in Lite's shared freeformGeometry.js, plus the
	 * schema's z minimum of 0, which the JS leaves to the server sanitizer.
	 *
	 * @param string               $id      Target occurrence identity.
	 * @param array<string, mixed> $slot    Slot geometry (x, y, w, h, z).
	 * @param int                  $columns Surface width in grid columns.
	 * @return array<string, mixed>
	 */
	private static function constrain_slot( $id, array $slot, $columns ) {
		$w = min( $columns, max( 1, (int) ( $slot['w'] ?? 8 ) ) );
		return array(
			'id' => $id,
			'x'  => min( $columns - $w, max( 0, (int) ( $slot['x'] ?? 0 ) ) ),
			'y'  => max( 0, (int) ( $slot['y'] ?? 0 ) ),
			'w'  => $w,
			'h'  => max( 1, (int) ( $slot['h'] ?? 6 ) ),
			'z'  => max( 0, (int) ( $slot['z'] ?? 0 ) ),
		);
	}

	/**
	 * Write grouped settings (canonical v2 plus the flat compatibility copy) and sorting.
	 *
	 * @param int                                 $gallery_id Gallery post ID.
	 * @param array<string, array<string, mixed>> $sanitized  Sanitized grouped settings.
	 * @param string                              $sorting    Sorting value.
	 * @return void
	 */
	private static function write_gallery_settings( $gallery_id, array $sanitized, $sorting ) {
		$json = wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		update_post_meta( $gallery_id, \Modula\V2\Meta_Sync::SETTINGS_V2_META_KEY, wp_slash( false !== $json ? $json : '{}' ) );

		$flat     = \Modula\V2\Settings\Adapter::to_flat( $sanitized );
		$defaults = class_exists( '\Modula_CPT_Fields_Helper', false )
			? \Modula_CPT_Fields_Helper::get_defaults()
			: array();
		update_post_meta(
			$gallery_id,
			'modula-settings',
			wp_slash( is_array( $defaults ) && ! empty( $defaults )
				? wp_parse_args( $flat, $defaults )
				: $flat )
		);

		update_post_meta( $gallery_id, 'modulaSorting', $sorting );
	}

	/**
	 * Whether albums v2 settings stack is available.
	 *
	 * @return bool
	 */
	public static function album_v2_settings_available() {
		return class_exists( '\Modula_Pro\Extensions\Albums\V2\Sanitizer' )
			&& class_exists( '\Modula_Pro\Extensions\Albums\V2\Adapter' )
			&& class_exists( '\Modula_Pro\Extensions\Albums\V2\Meta_Sync' )
			&& class_exists( '\Modula_Pro\Extensions\Albums\V2\Settings_Replacement' );
	}

	/**
	 * Read album preset settings as a grouped v2 document.
	 *
	 * Flat legacy presets are converted without schema default fill so omitted
	 * groups (especially passwordProtect) remain absent for replace semantics.
	 * Stored v2 documents are returned as saved; callers that need omit vs
	 * explicit protection should prefer flat carriers via
	 * {@see Settings_Replacement::flat_carries_explicit_protection()}.
	 *
	 * @param int $preset_id Album preset post ID (`defaults-albums`).
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_album_preset_grouped( $preset_id ) {
		$preset_id = absint( $preset_id );
		if ( ! $preset_id || ! self::album_v2_settings_available() ) {
			return array();
		}

		$flat = get_post_meta( $preset_id, \Modula_Pro\Extensions\Albums\V2\Meta_Sync::FLAT_META_KEY, true );
		if ( is_array( $flat ) && ! empty( $flat ) ) {
			$grouped = \Modula_Pro\Extensions\Albums\V2\Meta_Sync::with_read_dim_color(
				\Modula_Pro\Extensions\Albums\V2\Adapter::to_grouped( $flat, array( 'schema_defaults' => false ) ),
				\Modula_Pro\Extensions\Albums\V2\Meta_Sync::get_stored_settings_v2( $preset_id ),
				$flat
			);
			if ( ! \Modula_Pro\Extensions\Albums\V2\Settings_Replacement::flat_carries_explicit_protection( $flat )
				&& array_key_exists( 'passwordProtect', $grouped )
			) {
				unset( $grouped['passwordProtect'] );
			}
			return $grouped;
		}

		$v2 = \Modula_Pro\Extensions\Albums\V2\Meta_Sync::get_settings_v2( $preset_id );
		if ( empty( $v2 ) ) {
			return array();
		}

		// v2-only presets always sanitize full groups; treat default-off protection as omit.
		if ( isset( $v2['passwordProtect'] ) && is_array( $v2['passwordProtect'] )
			&& ! \Modula_Pro\Extensions\Albums\V2\Settings_Replacement::grouped_carries_explicit_protection( $v2['passwordProtect'] )
		) {
			unset( $v2['passwordProtect'] );
		}

		return $v2;
	}

	/**
	 * Project only supplied album preset fields; adapter defaults must not turn omission into a reset.
	 * The classic readers copy this flat copy as it is, so `hoverColor` is the hex the classic
	 * visitor reads, as an album's (album ticket 38); the Dim color's alpha stays in the v2 copy.
	 */
	public static function album_preset_flat( array $grouped ): array {
		$flat = \Modula_Pro\Extensions\Albums\V2\Adapter::to_flat( $grouped );
		$selected = array();
		foreach ( \Modula_Pro\Extensions\Albums\V2\Field_Registry::get_flat_to_grouped_mapping() as $key => $field ) {
			if ( array_key_exists( $field['key'], $grouped[$field['group']] ?? array() ) && array_key_exists( $key, $flat ) ) { $selected[$key] = $flat[$key]; }
		}
		return \Modula_Pro\Extensions\Albums\V2\Meta_Sync::with_legacy_hover_color( $selected, array() );
	}

	/** Save an explicit album preset document without touching any album or its members. */
	public static function save_album_preset_grouped( $preset_id, array $grouped, $sorting = 'manual' ) {
		if ( self::ALBUM_PRESET_POST_TYPE !== get_post_type( $preset_id ) || ! self::album_v2_settings_available() ) {
			return new \WP_Error( 'modula_invalid_preset', 'An available album preset is required.' );
		}
		$valid = \Modula_Pro\Extensions\Albums\V2\Settings_Writer::validate_patch( 0, $grouped );
		if ( is_wp_error( $valid ) ) { return $valid; }
		if ( ! in_array( $sorting, \Modula_Pro\Extensions\Albums\V2\Album_Sorting::modes(), true ) ) { return new \WP_Error( 'invalid_sorting', 'Invalid album preset sorting.' ); }
		// Keep omitted protection absent so the existing application flow preserves it.
		$meta = \Modula_Pro\Extensions\Albums\V2\Meta_Sync::class;
		update_post_meta( $preset_id, $meta::SETTINGS_V2_META_KEY, wp_slash( wp_json_encode( $grouped ) ) );
		update_post_meta( $preset_id, $meta::FLAT_META_KEY, wp_slash( self::album_preset_flat( $grouped ) ) );
		update_post_meta( $preset_id, 'modulaSorting', $sorting );
		return true;
	}

	/**
	 * Apply album preset settings to an album (settings only; members untouched).
	 *
	 * Uses the shared v2 settings replacement: full replace of supported groups
	 * (+ sorting), preserving opaque flat keys and omitted protection.
	 *
	 * @param int $album_id  Album post ID.
	 * @param int $preset_id Album preset post ID (`defaults-albums`).
	 * @return array<string, mixed>|\WP_Error Applied grouped settings payload.
	 */
	public static function apply_preset_to_album( $album_id, $preset_id ) {
		$album_id  = absint( $album_id );
		$preset_id = absint( $preset_id );

		if ( 'modula-album' !== get_post_type( $album_id ) ) {
			return new \WP_Error( 'modula_invalid_album', __( 'Invalid album.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( self::ALBUM_PRESET_POST_TYPE !== get_post_type( $preset_id ) ) {
			return new \WP_Error( 'modula_invalid_preset', __( 'Invalid preset.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( ! self::album_v2_settings_available() ) {
			return new \WP_Error( 'modula_v2_unavailable', __( 'Modula album v2 settings are not available.', 'modula-pro' ), array( 'status' => 500 ) );
		}

		$grouped = self::get_album_preset_grouped( $preset_id );
		if ( empty( $grouped ) ) {
			return new \WP_Error( 'modula_empty_preset', __( 'Preset has no settings.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		$sanitized = \Modula_Pro\Extensions\Albums\V2\Settings_Replacement::replace_grouped( $album_id, $grouped );
		if ( is_wp_error( $sanitized ) ) {
			return $sanitized;
		}

		$sorting = self::get_preset_sorting( $preset_id );
		if ( class_exists( '\Modula_Pro\Extensions\Albums\V2\Album_Sorting', false ) ) {
			$sorting = \Modula_Pro\Extensions\Albums\V2\Album_Sorting::set_mode( $album_id, $sorting );
		} else {
			update_post_meta( $album_id, 'modulaSorting', sanitize_key( $sorting ) );
		}

		return array(
			'settings' => $sanitized,
			'sorting'  => $sorting,
		);
	}

	/**
	 * Build a compact summary for UI (highlights per group).
	 *
	 * @param array<string, array<string, mixed>> $grouped Grouped settings.
	 * @return array<string, mixed>
	 */
	public static function build_summary( array $grouped ) {
		$highlights = array();
		$groups     = array();

		$skip_groups = array( 'general', 'proofing' );

		if ( isset( $grouped['general'] ) && is_array( $grouped['general'] ) && isset( $grouped['general']['type'] ) ) {
			$type = $grouped['general']['type'];
			if ( is_scalar( $type ) && '' !== (string) $type ) {
				$highlights['layoutType'] = (string) $type;
				$groups[]                 = array(
					'group'  => 'general',
					'fields' => array(
						array(
							'key'   => 'type',
							'value' => self::stringify_summary_value( $type ),
						),
					),
				);
			}
		}

		foreach ( $grouped as $group_id => $keys ) {
			if ( ! is_string( $group_id ) || ! is_array( $keys ) || in_array( $group_id, $skip_groups, true ) ) {
				continue;
			}

			$changed = array();
			foreach ( $keys as $key => $value ) {
				if ( ! is_string( $key ) ) {
					continue;
				}
				$changed[] = array(
					'key'   => $key,
					'value' => self::stringify_summary_value( $value ),
				);
				if ( count( $changed ) >= 6 ) {
					break;
				}
			}

			if ( empty( $changed ) ) {
				continue;
			}

			$groups[] = array(
				'group'  => $group_id,
				'fields' => $changed,
			);

			if ( 'lightbox' === $group_id && isset( $keys['lightbox'] ) ) {
				$highlights['lightbox'] = (string) $keys['lightbox'];
			}
		}

		// Apply preset confirmations say the Freeform arrangement is replaced too.
		if ( self::has_preset_layout( $grouped ) ) {
			$highlights['presetLayout'] = true;
		}

		return array(
			'highlights' => $highlights,
			'groups'     => $groups,
			'groupCount' => count( $groups ),
			'fieldCount' => array_sum(
				array_map(
					static function ( $g ) {
						return isset( $g['fields'] ) && is_array( $g['fields'] ) ? count( $g['fields'] ) : 0;
					},
					$groups
				)
			),
		);
	}

	/**
	 * @param \WP_Post $post Preset post.
	 * @return string
	 */
	private static function get_preset_title( \WP_Post $post ) {
		$title = trim( $post->post_title );
		if ( '' !== $title ) {
			return $title;
		}
		return sprintf(
			/* translators: %d: default preset post ID */
			__( 'Preset ID %d', 'modula-pro' ),
			(int) $post->ID
		);
	}

	/**
	 * @param mixed $value Setting value.
	 * @return string
	 */
	private static function stringify_summary_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? '1' : '0';
		}
		if ( is_scalar( $value ) ) {
			return (string) $value;
		}
		if ( is_array( $value ) ) {
			$json = wp_json_encode( $value );
			return is_string( $json ) ? $json : '';
		}
		return '';
	}
}
