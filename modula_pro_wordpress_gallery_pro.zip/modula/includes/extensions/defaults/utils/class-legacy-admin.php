<?php
/**
 * Legacy defaults admin UI guards (hidden when Modula 3.0 beta / v2 settings editor is on).
 *
 * @package Modula_Pro\Extensions\Defaults
 */

namespace Modula_Pro\Extensions\Defaults\Utils;

defined( 'ABSPATH' ) || exit;

/**
 * Class Legacy_Admin
 */
class Legacy_Admin {

	/**
	 * Whether the v2 React settings editor is enabled (beta opt-in).
	 *
	 * @return bool
	 */
	public static function is_modern_settings_editor_enabled( $post_id = 0 ) {
		return (bool) apply_filters( 'modula_enable_modern_settings_editor', false, (int) $post_id );
	}

	/**
	 * Legacy CPT list/edit screens should be hidden when the v2 editor manages defaults.
	 *
	 * @return bool
	 */
	public static function should_hide_legacy_defaults_admin() {
		return self::is_modern_settings_editor_enabled();
	}
}
