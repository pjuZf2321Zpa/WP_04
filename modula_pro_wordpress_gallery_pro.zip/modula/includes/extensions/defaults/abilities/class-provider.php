<?php
/** Pro contribution for gallery and album preset ability executors. */
namespace Modula_Pro\Extensions\Defaults\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Preset_Explanation;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Provider {
	public const ID = 'modula-pro-presets';

	/** @var int Entries into a preset executor during this request. */
	public static $executions = 0;

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! Pro_Dependency::extension_contract( 'modula-defaults' ) ) {
			return $contributions;
		}
		$operations = array();
		foreach ( array_merge( Gallery_Preset_Executor::callbacks(), Album_Preset_Executor::callbacks() ) as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck the preset feature before any effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		++self::$executions;
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Preset_Explanation::rejected( $name, $input, $blockers );
	}
}
