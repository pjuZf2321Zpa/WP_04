<?php
/** Gallery preset list, read, CRUD, apply and batch. Lite keeps the descriptor and explanation. */
namespace Modula_Pro\Extensions\Defaults\Abilities;

use Modula\V2\Abilities\Batch;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Integration;
use Modula\V2\Abilities\Presets;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Settings_Contract;
use Modula\V2\Abilities\Update;
use Modula\V2\Meta_Sync;
use Modula\V2\Settings\Sanitizer;
use Modula\V2\Settings\Writer;
use Modula_Pro\Extensions\Defaults\Utils\Preset_Storage;

defined( 'ABSPATH' ) || exit;

class Gallery_Preset_Executor {
	/** @return array<string,callable> */
	public static function callbacks(): array {
		return array(
			Presets::name( 'list' )   => array( static::class, 'listing' ),
			Presets::name( 'read' )   => array( static::class, 'read' ),
			Presets::name( 'create' ) => array( static::class, 'create' ),
			Presets::name( 'update' ) => array( static::class, 'update' ),
			Presets::name( 'delete' ) => array( static::class, 'delete' ),
			Presets::APPLY            => array( static::class, 'apply' ),
			Presets::BATCH            => array( static::class, 'batch' ),
		);
	}

	/** @return class-string<Presets> */
	protected static function owner(): string {
		return Presets::class;
	}

	/** Current preset entitlement (album presets also need Albums) plus the actor's right on this preset. */
	public static function can_access( int $id = 0, string $status = '', bool $create = false ): bool {
		$owner = static::owner();
		return $owner::available() && $owner::object_access( $id, $status, $create );
	}

	protected static function post_type(): string {
		return 'modula-defaults';
	}

	protected static function family(): string {
		return 'gallery';
	}

	public static function listing( array $input ) {
		$owner = static::owner();
		$gated = Provider::gate( $owner::name( 'list' ), $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( ! static::can_access() ) {
			return new \WP_Error( 'modula_forbidden', 'Current preset permissions and entitlement are required.' );
		}
		$ids  = array();
		$scan = 1;
		do {
			$query = new \WP_Query(
				array(
					'post_type'      => static::post_type(),
					'post_status'    => array( 'publish', 'draft', 'private' ),
					'fields'         => 'ids',
					'posts_per_page' => 200,
					'paged'          => $scan++,
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				)
			);
			foreach ( $query->posts as $id ) {
				if ( static::can_access( (int) $id ) ) {
					$ids[] = (int) $id;
				}
			}
		} while ( 200 === count( $query->posts ) );
		$page = $input['page'] ?? 1;
		$size = $input['per_page'] ?? 20;
		return array(
			'schema_version' => Contract::VERSION,
			'page'           => $page,
			'per_page'       => $size,
			'total'          => count( $ids ),
			'total_pages'    => (int) ceil( count( $ids ) / $size ),
			'presets'        => array_map( array( $owner, 'summary' ), array_slice( $ids, ( $page - 1 ) * $size, $size ) ),
		);
	}

	public static function read( array $input ) {
		$owner = static::owner();
		$gated = Provider::gate( $owner::name( 'read' ), $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$id = (int) $input['id'];
		if ( ! static::can_access( $id ) ) {
			return new \WP_Error( 'modula_forbidden', 'Current preset permissions and entitlement are required.' );
		}
		$revision           = Revision::document( $id );
		$preset             = $owner::summary( $id );
		$preset['settings'] = Contract::project( static::get_settings( $id ), static::read_settings_schema() );
		$preset['sorting']  = Preset_Storage::get_preset_sorting( $id );
		if ( ! hash_equals( $revision, Revision::document( $id ) ) ) {
			return new \WP_Error( 'modula_read_conflict', 'Preset changed while reading. Read again.' );
		}
		return array(
			'schema_version' => Contract::VERSION,
			'preset'         => $preset,
		);
	}

	public static function create( array $input ): array {
		return static::write( $input, 'create' );
	}

	public static function update( array $input ): array {
		return static::write( $input, 'update' );
	}

	public static function delete( array $input ): array {
		$input['id'] = (int) $input['id'];
		return static::write( $input, 'delete' );
	}

	public static function apply( array $input ): array {
		return static::write( $input, 'apply' );
	}

	public static function batch( array $input ): array {
		$owner = static::owner();
		$gated = Provider::gate( $owner::BATCH, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		// Each apply child names the same preset revision; the batch fingerprint stays over the original input.
		return Batch::execute(
			$input,
			$owner::BATCH,
			static function ( array $target ) use ( $input ): array {
				$target['preset_id']       = $input['preset_id'];
				$target['preset_revision'] = $input['preset_revision'];
				return $target;
			}
		);
	}

	protected static function write( array $input, string $verb ): array {
		$owner     = static::owner();
		$operation = 'apply' === $verb ? $owner::APPLY : $owner::name( $verb );
		$request   = $input['request_id'];
		$existing  = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$gated = Provider::gate( $operation, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$id      = $input['id'] ?? 0;
		$apply   = 'apply' === $verb;
		$create  = 'create' === $verb;
		$source  = $apply ? $input['preset_id'] : $id;
		$outcome = static function ( $status, $code = '', $message = '' ) use ( $request, $operation ) {
			return Requests::outcome( $request, $status, $code, $message, $operation );
		};
		if ( ! static::can_access( $source, $input['status'] ?? '', $create ) || ( $apply && ! static::target_access( $id ) ) || ( 'delete' === $verb && ! $owner::can_delete( $id ) ) ) {
			return $outcome( 'forbidden', 'current_permission_denied', 'Current preset, target and operation permissions are required.' );
		}
		if ( $apply && ! static::eligible_target( $id ) ) {
			return $outcome( 'rejected', 'unsupported_target', 'Preset application requires an eligible Beta target outside trash.' );
		}
		if ( isset( $input['title'] ) && '' === trim( sanitize_text_field( $input['title'] ) ) ) {
			return $outcome( 'rejected', 'invalid_title', 'Provide a nonempty title.' );
		}
		if ( 'update' === $verb && ! array_intersect( array_keys( $input ), array( 'title', 'status', 'settings', 'sorting' ) ) ) {
			return $outcome( 'rejected', 'empty_patch', 'Provide preset fields to change.' );
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$transaction = false;
		try {
			Revision::begin();
			$transaction = true;
			if ( $create ) {
				Revision::document( 0, true );
			}
			$revision        = $create ? '' : ( $apply ? static::target_revision( $id, true ) : Revision::document( $id, true ) );
			$source_revision = $apply ? Revision::document( $source, true ) : '';
			if ( ! $create && ( ! hash_equals( $revision, $input['revision'] ) || ( $apply && ! hash_equals( $source_revision, $input['preset_revision'] ) ) ) ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $request, $outcome( 'conflict', 'stale_revision', 'Read and reconcile both the source preset and target before a new request.' ) );
			}
			if ( ! static::can_access( $source, $input['status'] ?? '', $create ) || ( $apply && ! static::target_access( $id ) ) || ( 'delete' === $verb && ! $owner::can_delete( $id ) ) ) {
				throw new \RuntimeException( 'Access changed.' );
			}
			$settings = $apply ? static::get_settings( $source ) : ( $input['settings'] ?? null );
			$sorting  = $apply ? Preset_Storage::get_preset_sorting( $source ) : ( $input['sorting'] ?? ( $id ? Preset_Storage::get_preset_sorting( $id ) : 'manual' ) );
			$valid    = null !== $settings ? static::validate_settings( $settings ) : true;
			if ( 'delete' !== $verb && ( ( null !== $settings && ( ! $settings || is_wp_error( $valid ) ) ) || ! in_array( $sorting, $owner::sorting_schema()['enum'], true ) ) ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $request, $outcome( 'rejected', 'ineligible_preset_settings', is_wp_error( $valid ) ? $valid->get_error_message() : 'Preset contains invalid or unavailable configuration. No target was changed.' ) );
			}
			if ( $create ) {
				$id = wp_insert_post(
					wp_slash(
						array(
							'post_type'   => static::post_type(),
							'post_title'  => sanitize_text_field( $input['title'] ),
							'post_status' => $input['status'],
							'post_author' => get_current_user_id(),
						)
					),
					true
				);
				if ( is_wp_error( $id ) || ! $id ) {
					throw new \RuntimeException( 'Creation unconfirmed.' );
				}
				Revision::track( array( $id ) );
				if ( ! Requests::target( $request, $id ) ) {
					throw new \RuntimeException( 'Target unconfirmed.' );
				}
			}
			if ( 'delete' === $verb ) {
				if ( ! wp_delete_post( $id, true ) || get_post( $id ) ) {
					throw new \RuntimeException( 'Deletion unconfirmed.' );
				}
			} elseif ( $apply ) {
				$saved = static::apply_settings( $id, $source );
				if ( is_wp_error( $saved ) || ! hash_equals( $source_revision, Revision::document( $source ) ) ) {
					throw new \RuntimeException( 'Application unconfirmed.' );
				}
			} else {
				if ( null !== $settings ) {
					if ( is_wp_error( static::save_settings( $id, $settings, $sorting ) ) ) {
						throw new \RuntimeException( 'Settings unconfirmed.' );
					}
				} elseif ( isset( $input['sorting'] ) ) {
					update_post_meta( $id, 'modulaSorting', $sorting );
				}
				$post = array( 'ID' => $id );
				foreach ( array(
					'title'  => 'post_title',
					'status' => 'post_status',
				) as $key => $field ) {
					if ( isset( $input[ $key ] ) ) {
						$post[ $field ] = 'title' === $key ? sanitize_text_field( $input[ $key ] ) : $input[ $key ];
					}
				}
				if ( ! $create && count( $post ) > 1 && is_wp_error( wp_update_post( wp_slash( $post ), true ) ) ) {
					throw new \RuntimeException( 'Metadata unconfirmed.' );
				}
			}
			Revision::clear_cache();
			if ( 'delete' !== $verb ) {
				if ( null !== $settings && ! ( $apply ? static::application_confirmed( $id, $settings, $saved ) : static::settings_confirmed( $id, $settings ) ) ) {
					throw new \RuntimeException( 'Settings confirmation differs.' );
				}
				if ( $sorting !== Preset_Storage::get_preset_sorting( $id ) ) {
					throw new \RuntimeException( 'Sorting confirmation differs.' );
				}
				foreach ( array(
					'title'  => 'post_title',
					'status' => 'post_status',
				) as $key => $field ) {
					if ( isset( $input[ $key ] ) && get_post( $id )->$field !== ( 'title' === $key ? sanitize_text_field( $input[ $key ] ) : $input[ $key ] ) ) {
						throw new \RuntimeException( 'Metadata confirmation differs.' );
					}
				}
			}
			$out = $outcome( 'succeeded' );
			if ( 'delete' === $verb ) {
				$out['deleted_id'] = $id;
			} elseif ( $apply ) {
				$out[ static::family() ] = static::target_summary( $id );
			} else {
				$out['preset'] = $owner::summary( $id );
			}
			$out = Requests::finish( $request, $out );
			if ( 'succeeded' !== $out['status'] ) {
				throw new \RuntimeException( 'Outcome unconfirmed.' );
			}
			Revision::end( true );
			$transaction = false;
			return $out;
		} catch ( \Throwable $error ) {
			if ( $transaction ) {
				Revision::end( false );
			}
			return Requests::finish( $request, $outcome( 'uncertain', 'preset_write_unconfirmed', 'The preset operation was not confirmed. Recover this identity before another action.' ) );
		}
	}

	protected static function validate_settings( array $settings ) {
		$available = Settings_Contract::schema();
		$defaults  = Sanitizer::sanitize_grouped( array() );
		$active    = array();
		foreach ( $settings as $group => $fields ) {
			if ( ! is_array( $fields ) ) {
				return new \WP_Error( 'invalid_preset_group', 'Invalid preset group: ' . $group );
			}
			foreach ( $fields as $key => $value ) {
				// A stored preset names every default; a `number` default reads back from JSON as an integer.
				if ( array_key_exists( $key, $defaults[ $group ] ?? array() ) && static::matches_stored( $defaults[ $group ][ $key ], $value ) ) {
					continue;
				}
				$active[ $group ][ $key ] = $value;
				$shape                    = $available['properties'][ $group ]['properties'][ $key ] ?? null;
				if ( null === $shape ) {
					return new \WP_Error( 'unavailable_preset_field', 'Unavailable preset field: ' . $group . '.' . $key );
				}
				if ( ! Settings_Contract::strict_types( $value, $shape ) || is_wp_error( rest_validate_value_from_schema( $value, $shape ) ) ) {
					return new \WP_Error( 'invalid_preset_field', 'Invalid preset field: ' . $group . '.' . $key );
				}
			}
		}
		return Writer::validate_strict_patch( 0, $active );
	}

	protected static function read_settings_schema(): array {
		return Contract::settings_schema();
	}

	protected static function get_settings( int $id ): array {
		return Preset_Storage::get_preset_grouped( $id, false );
	}

	protected static function save_settings( int $id, array $settings, string $sorting ) {
		return Preset_Storage::save_preset_grouped( $id, $settings, $sorting );
	}

	protected static function settings_confirmed( int $id, array $settings ): bool {
		return static::matches_stored( Sanitizer::sanitize_grouped( $settings ), json_decode( (string) get_post_meta( $id, Meta_Sync::SETTINGS_V2_META_KEY, true ), true ) );
	}

	/**
	 * Whether an expected settings value equals one read back from the JSON meta.
	 *
	 * Both sides are compared as JSON, the form storage keeps: JSON has one number
	 * kind, so a `number` field holding 1.0 is written as 1 and read back as an
	 * integer, which a strict PHP comparison reports as a difference.
	 *
	 * @param mixed $expected Settings document or value as PHP produced it.
	 * @param mixed $stored   The decoded stored counterpart; null when nothing is stored.
	 */
	protected static function matches_stored( $expected, $stored ): bool {
		$json = wp_json_encode( $expected );
		return false !== $json && wp_json_encode( $stored ) === $json;
	}

	protected static function target_access( int $id ): bool {
		return Update::can_update( $id );
	}

	protected static function eligible_target( int $id ): bool {
		return \Modula\V2\Beta_Settings::is_beta_gallery( $id ) && 'trash' !== get_post_status( $id ) && ! get_post_meta( $id, '_modula_bind_target_type', true );
	}

	protected static function target_revision( int $id, bool $lock = false ): string {
		return Revision::state( $id, $lock );
	}

	protected static function target_summary( int $id ): array {
		return Integration::gallery( get_post( $id ) ) + array( 'revision' => Revision::state( $id ) );
	}

	protected static function apply_settings( int $id, int $source ) {
		$members = get_post_meta( $id, 'modula-images', true );
		$saved   = Meta_Sync::with_canonical_gallery_write(
			$id,
			static function () use ( $id, $source ) {
				return Preset_Storage::apply_preset_to_gallery( $id, $source, false );
			}
		);
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		if ( get_post_meta( $id, 'modula-images', true ) !== $members ) {
			return new \WP_Error( 'members_changed', 'Preset changed member composition.' );
		}
		return $saved;
	}

	protected static function application_confirmed( int $id, array $settings, $saved ): bool {
		// Placements are the target's own or its Preset layout mapping (ADR 0051), as apply wrote them.
		if ( ! isset( $saved['settings']['freeform']['placements'] ) ) {
			return false;
		}
		$settings['freeform']['placements'] = $saved['settings']['freeform']['placements'];
		return static::settings_confirmed( $id, $settings );
	}
}
