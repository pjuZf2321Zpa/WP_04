<?php
/** Album preset CRUD and apply. Compound Albums requirements stay on the Lite descriptor. */
namespace Modula_Pro\Extensions\Defaults\Abilities;

use Modula\V2\Abilities\Album_Presets;
use Modula\V2\Abilities\Albums;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Settings_Contract;
use Modula_Pro\Extensions\Albums\Abilities\Album_Executor;
use Modula_Pro\Extensions\Albums\V2\Meta_Sync;
use Modula_Pro\Extensions\Albums\V2\Registry;
use Modula_Pro\Extensions\Albums\V2\Sanitizer;
use Modula_Pro\Extensions\Albums\V2\Settings_Writer;
use Modula_Pro\Extensions\Defaults\Utils\Preset_Storage;

defined( 'ABSPATH' ) || exit;

final class Album_Preset_Executor extends Gallery_Preset_Executor {
	/** @return array<string,callable> */
	public static function callbacks(): array {
		return array(
			Album_Presets::name( 'list' )   => array( static::class, 'listing' ),
			Album_Presets::name( 'read' )   => array( static::class, 'read' ),
			Album_Presets::name( 'create' ) => array( static::class, 'create' ),
			Album_Presets::name( 'update' ) => array( static::class, 'update' ),
			Album_Presets::name( 'delete' ) => array( static::class, 'delete' ),
			Album_Presets::APPLY            => array( static::class, 'apply' ),
			Album_Presets::BATCH            => array( static::class, 'batch' ),
		);
	}

	/** @return class-string<Album_Presets> */
	protected static function owner(): string {
		return Album_Presets::class;
	}

	protected static function post_type(): string {
		return 'defaults-albums';
	}

	protected static function family(): string {
		return 'album';
	}

	protected static function validate_settings( array $settings ) {
		return Settings_Writer::validate_patch( 0, $settings );
	}

	protected static function read_settings_schema(): array {
		return Contract::settings_schema( Registry::get_schema() );
	}

	protected static function get_settings( int $id ): array {
		return Preset_Storage::get_album_preset_grouped( $id );
	}

	protected static function save_settings( int $id, array $settings, string $sorting ) {
		return Preset_Storage::save_album_preset_grouped( $id, $settings, $sorting );
	}

	protected static function settings_confirmed( int $id, array $settings ): bool {
		return self::matches_stored( $settings, json_decode( (string) get_post_meta( $id, Meta_Sync::SETTINGS_V2_META_KEY, true ), true ) ) && Preset_Storage::album_preset_flat( $settings ) === get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
	}

	protected static function target_access( int $id ): bool {
		return Album_Executor::can_access( $id );
	}

	protected static function eligible_target( int $id ): bool {
		return \Modula\V2\Beta_Settings::is_beta_album( $id ) && 'trash' !== get_post_status( $id );
	}

	protected static function target_revision( int $id, bool $lock = false ): string {
		return Revision::document( $id, $lock );
	}

	protected static function target_summary( int $id ): array {
		return Albums::summary( $id );
	}

	protected static function apply_settings( int $id, int $source ) {
		$keys    = array( 'modula_album_members_v2', 'modula-album-galleries' );
		$members = array();
		foreach ( $keys as $key ) {
			$members[ $key ] = get_post_meta( $id, $key, true );
		}
		$parent = get_post( $id )->post_parent;
		Meta_Sync::ensure_settings_v2_from_flat( $id );
		$before   = Meta_Sync::get_settings_v2( $id );
		$settings = self::get_settings( $source );
		if ( ! array_key_exists( 'passwordProtect', $settings ) && isset( $before['passwordProtect'] ) ) {
			$settings['passwordProtect'] = $before['passwordProtect'];
		}
		$expected = Sanitizer::sanitize_grouped( Sanitizer::sanitize_grouped( $settings ) );
		// The flat copy the write projects against: read after the import above, which may write it.
		$prior_flat = get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
		$password   = get_post( $id )->post_password;
		$saved      = Meta_Sync::with_canonical_write(
			$id,
			static function () use ( $id, $source ) {
				return Preset_Storage::apply_preset_to_album( $id, $source );
			}
		);
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		foreach ( $members as $key => $value ) {
			if ( $value !== get_post_meta( $id, $key, true ) ) {
				return new \WP_Error( 'members_changed', 'Preset changed member composition.' );
			}
		}
		if ( $parent !== get_post( $id )->post_parent || ( ! array_key_exists( 'passwordProtect', self::get_settings( $source ) ) && $password !== get_post( $id )->post_password ) ) {
			return new \WP_Error( 'album_changed', 'Preset changed unrequested hierarchy or protection.' );
		}
		// The flat hoverColor is the hex the classic visitor reads, not the v2 Dim color (album ticket 25);
		// projected again here only so the album's prior flat value is kept while the color is the same.
		return array(
			'expected'      => $expected,
			'expected_flat' => Meta_Sync::with_legacy_hover_color( Preset_Storage::album_preset_flat( $expected ), is_array( $prior_flat ) ? $prior_flat : array() ),
		);
	}

	protected static function application_confirmed( int $id, array $settings, $saved ): bool {
		// As stored: a preset without filters leaves the list wiped, which a repairing read would refill from the members.
		if ( ! isset( $saved['expected'], $saved['expected_flat'] ) || ! self::matches_stored( $saved['expected'], Meta_Sync::get_settings_v2( $id, false ) ) ) {
			return false;
		}
		$flat = get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
		foreach ( $saved['expected_flat'] as $key => $value ) {
			if ( ! array_key_exists( $key, $flat ) || $value !== $flat[ $key ] ) {
				return false;
			}
		}
		return true;
	}
}
