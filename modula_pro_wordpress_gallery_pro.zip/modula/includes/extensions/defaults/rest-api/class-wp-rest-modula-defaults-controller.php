<?php
/**
 * REST API for gallery defaults presets (v2 settings editor).
 *
 * @package Modula_Pro\Extensions\Defaults
 */

namespace Modula_Pro\Extensions\Defaults\Rest_API;

use Modula_Pro\Extensions\Defaults\Utils\Preset_Storage;

defined( 'ABSPATH' ) || exit;

/**
 * Class WP_Rest_Modula_Defaults_Controller
 */
class WP_Rest_Modula_Defaults_Controller {

	/**
	 * @var string
	 */
	public $namespace = 'modula-defaults/v1';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/presets',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_presets' ),
					'permission_callback' => array( $this, 'check_edit_posts' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_preset' ),
					'permission_callback' => array( $this, 'check_edit_posts' ),
					'args'                => array(
						'title'           => array(
							'type'     => 'string',
							'required' => false,
						),
						'sourceGalleryId' => array(
							'type'     => 'integer',
							'required' => false,
						),
						'settings'        => array(
							'type'     => 'object',
							'required' => false,
						),
						'sorting'         => array(
							'type'     => 'string',
							'required' => false,
						),
						'mode'            => array(
							'type'     => 'string',
							'enum'     => array( 'create', 'update' ),
							'required' => false,
						),
						'presetId'        => array(
							'type'     => 'integer',
							'required' => false,
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/presets/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_preset' ),
					'permission_callback' => array( $this, 'check_edit_posts' ),
					'args'                => array(
						'id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_preset' ),
					'permission_callback' => array( $this, 'check_edit_posts' ),
					'args'                => array(
						'id'       => array(
							'type'     => 'integer',
							'required' => true,
						),
						'title'    => array(
							'type'     => 'string',
							'required' => false,
						),
						'settings' => array(
							'type'     => 'object',
							'required' => true,
						),
						'sorting'  => array(
							'type'     => 'string',
							'required' => false,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_preset' ),
					'permission_callback' => array( $this, 'check_edit_posts' ),
					'args'                => array(
						'id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/galleries/(?P<gallery_id>\d+)/apply/(?P<preset_id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'apply_preset' ),
					'permission_callback' => array( $this, 'check_gallery_edit' ),
					'args'                => array(
						'gallery_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
						'preset_id'  => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/albums/(?P<album_id>\d+)/apply/(?P<preset_id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'apply_preset_to_album' ),
					'permission_callback' => array( $this, 'check_album_edit' ),
					'args'                => array(
						'album_id'  => array(
							'type'     => 'integer',
							'required' => true,
						),
						'preset_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/album-presets',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_album_presets' ),
					'permission_callback' => array( __CLASS__, 'can_edit_albums' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/album-presets/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_album_preset' ),
					'permission_callback' => array( __CLASS__, 'can_edit_albums' ),
					'args'                => array(
						'id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
			)
		);
	}

	/**
	 * @return bool
	 */
	public function check_edit_posts() {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Whether the user can edit albums, under the album post type's own
	 * capabilities (album capabilities while Roles is active).
	 *
	 * @return bool
	 */
	public static function can_edit_albums() {
		$album_type = get_post_type_object( 'modula-album' );

		return null !== $album_type && current_user_can( $album_type->cap->edit_posts );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public function check_gallery_edit( $request ) {
		$gallery_id = (int) $request['gallery_id'];
		if ( $gallery_id <= 0 || 'modula-gallery' !== get_post_type( $gallery_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Invalid gallery.', 'modula-pro' ), array( 'status' => 403 ) );
		}
		if ( ! current_user_can( 'edit_post', $gallery_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit this gallery.', 'modula-pro' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public function check_album_edit( $request ) {
		$album_id = (int) $request['album_id'];
		if ( $album_id <= 0 || 'modula-album' !== get_post_type( $album_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Invalid album.', 'modula-pro' ), array( 'status' => 403 ) );
		}
		if ( ! current_user_can( 'edit_post', $album_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit this album.', 'modula-pro' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * @return \WP_REST_Response
	 */
	public function get_presets() {
		$presets = Preset_Storage::list_presets();

		return new \WP_REST_Response(
			array(
				'presets' => $presets,
				'count'   => count( $presets ),
			),
			200
		);
	}

	/**
	 * @return \WP_REST_Response
	 */
	public function get_album_presets() {
		$presets = Preset_Storage::list_album_presets();

		return new \WP_REST_Response(
			array(
				'presets' => $presets,
				'count'   => count( $presets ),
			),
			200
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_preset( $request ) {
		$preset = Preset_Storage::get_preset( (int) $request['id'] );
		if ( null === $preset ) {
			return new \WP_Error( 'rest_not_found', __( 'Preset not found.', 'modula-pro' ), array( 'status' => 404 ) );
		}
		return new \WP_REST_Response( $preset, 200 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_album_preset( $request ) {
		$preset = Preset_Storage::get_album_preset( (int) $request['id'] );
		if ( null === $preset ) {
			return new \WP_Error( 'rest_not_found', __( 'Preset not found.', 'modula-pro' ), array( 'status' => 404 ) );
		}
		return new \WP_REST_Response( $preset, 200 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create_preset( $request ) {
		$mode = $request->get_param( 'mode' );
		$mode = is_string( $mode ) ? $mode : 'create';

		$grouped = $this->resolve_grouped_settings_from_request( $request );
		if ( is_wp_error( $grouped ) ) {
			return $grouped;
		}

		$sorting = $this->resolve_sorting_from_request( $request );
		$title   = $request->get_param( 'title' );
		$title   = is_string( $title ) ? $title : '';

		if ( 'update' === $mode ) {
			$preset_id = absint( $request->get_param( 'presetId' ) );
			if ( $preset_id <= 0 ) {
				return new \WP_Error( 'modula_missing_preset', __( 'Preset ID is required for update.', 'modula-pro' ), array( 'status' => 400 ) );
			}
			if ( ! current_user_can( 'edit_post', $preset_id ) ) {
				return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit this preset.', 'modula-pro' ), array( 'status' => 403 ) );
			}
			if ( '' !== $title ) {
				wp_update_post(
					array(
						'ID'         => $preset_id,
						'post_title' => sanitize_text_field( $title ),
					)
				);
			}
			$saved = Preset_Storage::save_preset_grouped( $preset_id, $grouped, $sorting );
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
			$preset = Preset_Storage::get_preset( $preset_id );
			return new \WP_REST_Response( $preset, 200 );
		}

		if ( '' === $title ) {
			$source_id = absint( $request->get_param( 'sourceGalleryId' ) );
			if ( $source_id > 0 ) {
				$gallery = get_post( $source_id );
				if ( $gallery && 'modula-gallery' === $gallery->post_type ) {
					$gallery_title = trim( $gallery->post_title );
					$title         = '' !== $gallery_title
						? sprintf(
							/* translators: %s: gallery title */
							__( 'Preset from %s', 'modula-pro' ),
							$gallery_title
						)
						: sprintf(
							/* translators: %d: gallery ID */
							__( 'Preset from gallery ID %d', 'modula-pro' ),
							$source_id
						);
				}
			}
		}

		$new_id = Preset_Storage::create_preset( $title, $grouped, $sorting );
		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}

		$preset = Preset_Storage::get_preset( (int) $new_id );
		return new \WP_REST_Response( $preset, 201 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_preset( $request ) {
		$preset_id = (int) $request['id'];
		if ( ! current_user_can( 'edit_post', $preset_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit this preset.', 'modula-pro' ), array( 'status' => 403 ) );
		}

		$settings = $request->get_param( 'settings' );
		if ( ! is_array( $settings ) ) {
			return new \WP_Error( 'modula_invalid_settings', __( 'Settings must be a grouped object.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		$title = $request->get_param( 'title' );
		if ( is_string( $title ) && '' !== $title ) {
			wp_update_post(
				array(
					'ID'         => $preset_id,
					'post_title' => sanitize_text_field( $title ),
				)
			);
		}

		$sorting = $this->resolve_sorting_from_request( $request );
		$saved   = Preset_Storage::save_preset_grouped( $preset_id, $settings, $sorting );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$preset = Preset_Storage::get_preset( $preset_id );
		return new \WP_REST_Response( $preset, 200 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete_preset( $request ) {
		$preset_id = (int) $request['id'];
		if ( ! current_user_can( 'delete_post', $preset_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to delete this preset.', 'modula-pro' ), array( 'status' => 403 ) );
		}
		$deleted = wp_delete_post( $preset_id, true );
		if ( ! $deleted ) {
			return new \WP_Error( 'modula_delete_failed', __( 'Could not delete preset.', 'modula-pro' ), array( 'status' => 500 ) );
		}
		return new \WP_REST_Response(
			array(
				'deleted' => true,
				'id'      => $preset_id,
			),
			200
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function apply_preset( $request ) {
		$gallery_id = (int) $request['gallery_id'];
		$preset_id  = (int) $request['preset_id'];

		$result = Preset_Storage::apply_preset_to_gallery( $gallery_id, $preset_id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response(
			array(
				'galleryId' => $gallery_id,
				'presetId'  => $preset_id,
				'settings'  => $result['settings'],
				'sorting'   => $result['sorting'],
			),
			200
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function apply_preset_to_album( $request ) {
		$album_id  = (int) $request['album_id'];
		$preset_id = (int) $request['preset_id'];

		$result = Preset_Storage::apply_preset_to_album( $album_id, $preset_id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response(
			array(
				'albumId'  => $album_id,
				'presetId' => $preset_id,
				'settings' => $result['settings'],
				'sorting'  => $result['sorting'],
			),
			200
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, array<string, mixed>>|\WP_Error
	 */
	private function resolve_grouped_settings_from_request( $request ) {
		$settings = $request->get_param( 'settings' );
		if ( is_array( $settings ) && ! empty( $settings ) ) {
			return $settings;
		}

		$source_id = absint( $request->get_param( 'sourceGalleryId' ) );
		if ( $source_id <= 0 ) {
			return new \WP_Error( 'modula_missing_settings', __( 'Settings or source gallery ID is required.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( 'modula-gallery' !== get_post_type( $source_id ) ) {
			return new \WP_Error( 'modula_invalid_gallery', __( 'Invalid source gallery.', 'modula-pro' ), array( 'status' => 400 ) );
		}

		if ( ! current_user_can( 'edit_post', $source_id ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to read this gallery.', 'modula-pro' ), array( 'status' => 403 ) );
		}

		if ( Preset_Storage::v2_meta_sync_available() ) {
			$grouped = \Modula\V2\Meta_Sync::get_settings_v2( $source_id );
			if ( ! empty( $grouped ) ) {
				return $grouped;
			}
		}

		$flat = get_post_meta( $source_id, 'modula-settings', true );
		if ( ! is_array( $flat ) ) {
			$flat = array();
		}

		if ( Preset_Storage::v2_settings_available() ) {
			return \Modula\V2\Settings\Adapter::to_grouped( $flat );
		}

		return new \WP_Error( 'modula_v2_unavailable', __( 'Modula v2 settings are not available.', 'modula-pro' ), array( 'status' => 500 ) );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return string
	 */
	private function resolve_sorting_from_request( $request ) {
		$sorting = $request->get_param( 'sorting' );
		if ( is_string( $sorting ) && '' !== $sorting ) {
			return sanitize_key( $sorting );
		}

		$source_id = absint( $request->get_param( 'sourceGalleryId' ) );
		if ( $source_id > 0 ) {
			$from_gallery = get_post_meta( $source_id, 'modulaSorting', true );
			if ( is_string( $from_gallery ) && '' !== $from_gallery ) {
				return sanitize_key( $from_gallery );
			}
		}

		return 'manual';
	}
}
