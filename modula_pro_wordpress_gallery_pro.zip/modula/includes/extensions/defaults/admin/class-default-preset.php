<?php
/**
 * Default preset: the gallery Preset new Beta galleries start from.
 *
 * @package Modula_Pro\Extensions\Defaults
 */

namespace Modula_Pro\Extensions\Defaults\Admin;

use Modula\V2\Admin\Beta_Gallery_Admin;
use Modula_Pro\Extensions\Defaults\Utils\Preset_Storage;

defined( 'ABSPATH' ) || exit;

/**
 * Owns the Default preset setting (Settings → Display → New galleries) and
 * applies the chosen Preset when Lite creates a Beta gallery from the admin
 * editor choice (`modula_new_beta_gallery_created`).
 */
class Default_Preset {

	/** Settings option holding the New galleries subtab fields. */
	const OPTION_NAME = 'modula_new_galleries';

	/** Field in OPTION_NAME: Default preset ID, 0 for none. */
	const FIELD_NAME = 'default_gallery_preset';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'modula_new_beta_gallery_created', array( $this, 'apply_on_create' ), 10, 2 );
		add_filter( 'modula_admin_page_main_tabs', array( $this, 'attach_to_display' ) );
		add_filter( 'modula_settings_api_pre_update_' . self::OPTION_NAME, array( $this, 'validate_setting' ) );
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_options' ) );
	}

	/**
	 * Stored Default preset ID, whether or not that Preset still exists.
	 *
	 * @return int Preset ID, 0 for none.
	 */
	public static function stored_default_id() {
		return self::preset_id_from( get_option( self::OPTION_NAME, array() ) );
	}

	/**
	 * @param mixed $option_value OPTION_NAME value (stored or about to be saved).
	 * @return int Preset ID, 0 when missing or malformed.
	 */
	private static function preset_id_from( $option_value ) {
		if ( ! is_array( $option_value ) || ! isset( $option_value[ self::FIELD_NAME ] ) ) {
			return 0;
		}
		return absint( $option_value[ self::FIELD_NAME ] );
	}

	/**
	 * Default preset ID when it is a listed Preset; trashed or deleted ones fall back to 0.
	 *
	 * @return int Preset ID, 0 for built-in defaults.
	 */
	public static function usable_default_id() {
		$preset_id = self::stored_default_id();
		return ( $preset_id && Preset_Storage::is_listed_preset( $preset_id ) ) ? $preset_id : 0;
	}

	/**
	 * Preset to apply for a create choice from Lite.
	 *
	 * @param int|string $preset_choice Preset ID, `blank`, or `default`.
	 * @return int Preset ID, 0 for built-in defaults.
	 */
	public static function resolve_preset_id( $preset_choice ) {
		if ( Beta_Gallery_Admin::PRESET_CHOICE_DEFAULT === $preset_choice ) {
			return self::usable_default_id();
		}
		if ( is_int( $preset_choice ) && Preset_Storage::is_listed_preset( $preset_choice ) ) {
			return $preset_choice;
		}
		// `blank`, an unlisted ID, or anything unknown: keep built-in defaults.
		return 0;
	}

	/**
	 * Start a new Beta gallery from the chosen Preset (`modula_new_beta_gallery_created`).
	 *
	 * The create already succeeded with built-in defaults, so a failed apply is
	 * logged, not surfaced.
	 *
	 * @param int        $post_id       New Beta gallery ID.
	 * @param int|string $preset_choice Preset ID, `blank`, or `default`.
	 * @return void
	 */
	public function apply_on_create( $post_id, $preset_choice ) {
		$preset_id = self::resolve_preset_id( $preset_choice );
		if ( ! $preset_id ) {
			return;
		}

		$result = Preset_Storage::apply_preset_to_gallery( $post_id, $preset_id );
		if ( is_wp_error( $result ) ) {
			self::log_apply_failure( $post_id, $preset_id, $result );
		}
	}

	/**
	 * Reject a Default preset that is not a Preset (settings REST, before save).
	 *
	 * Re-saving the stored ID is allowed even when that Preset is trashed, so
	 * saving other settings never fails because of it.
	 *
	 * @param mixed $value Schema-sanitized option value.
	 * @return array<string, int>|\WP_Error Option value, or an error that blocks the save.
	 */
	public function validate_setting( $value ) {
		$preset_id = self::preset_id_from( $value );

		$is_allowed = 0 === $preset_id
			|| self::stored_default_id() === $preset_id
			|| Preset_Storage::is_listed_preset( $preset_id );
		if ( ! $is_allowed ) {
			return new \WP_Error(
				'modula_invalid_default_preset',
				__( 'Choose an existing gallery preset as the default.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		return array( self::FIELD_NAME => $preset_id );
	}

	/**
	 * Add the New galleries subtab to the Display settings tab.
	 *
	 * @param array $tabs Main settings tabs.
	 * @return array
	 */
	public function attach_to_display( $tabs ) {
		if ( ! is_array( $tabs ) ) {
			return $tabs;
		}
		foreach ( $tabs as &$tab ) {
			if ( ! isset( $tab['slug'] ) || 'display' !== $tab['slug'] ) {
				continue;
			}
			if ( ! isset( $tab['subtabs'] ) || ! is_array( $tab['subtabs'] ) ) {
				$tab['subtabs'] = array();
			}
			$tab['subtabs']['new_galleries'] = $this->get_subtab();
		}
		unset( $tab );
		return $tabs;
	}

	/**
	 * @param array $options Uninstall list.
	 * @return array
	 */
	public function uninstall_options( $options ) {
		$options[] = self::OPTION_NAME;
		return $options;
	}

	/**
	 * Settings subtab definition.
	 *
	 * Labels are React text (escaped on render), so they use `__()`; only the
	 * paragraph description is rendered as HTML and is escaped here.
	 *
	 * @return array Settings subtab definition.
	 */
	private function get_subtab() {
		$stored_id  = self::stored_default_id();
		$is_missing = $stored_id && ! Preset_Storage::is_listed_preset( $stored_id );

		$fields = array(
			array(
				'type'         => 'select',
				'name'         => self::FIELD_NAME,
				'label'        => __( 'Default gallery preset', 'modula-pro' ),
				'description'  => __( 'New galleries you create from Galleries → New gallery start with this preset’s settings. You can still pick another preset, or start blank, from the arrow next to each New gallery button. Existing galleries don’t change.', 'modula-pro' ),
				'options'      => self::preset_select_options( $is_missing ? $stored_id : 0 ),
				'default'      => $stored_id,
				'sanitization' => array( 'number' ),
			),
		);

		if ( $is_missing ) {
			$fields[] = array(
				'type'        => 'paragraph',
				'name'        => self::FIELD_NAME . '_notice',
				'label'       => __( 'Default preset unavailable', 'modula-pro' ),
				'description' => esc_html__( 'This preset is in the trash or was deleted. New galleries start from built-in defaults until you restore it or choose another preset.', 'modula-pro' ),
			);
		}

		return array(
			'label'  => __( 'New galleries', 'modula-pro' ),
			'badge'  => null,
			'locked' => false,
			'config' => array(
				'option' => self::OPTION_NAME,
				'fields' => $fields,
			),
		);
	}

	/**
	 * Select options: None, every listed Preset, then the stored but missing one.
	 *
	 * @param int $missing_id Stored Default preset ID that is no longer listed, 0 for none.
	 * @return array<int, array{value: int, label: string}>
	 */
	private static function preset_select_options( $missing_id ) {
		$options = array(
			array(
				'value' => 0,
				'label' => __( 'None (built-in defaults)', 'modula-pro' ),
			),
		);
		foreach ( Preset_Storage::list_presets() as $preset ) {
			$options[] = array(
				'value' => (int) $preset['id'],
				'label' => (string) $preset['title'],
			);
		}
		if ( $missing_id ) {
			// Keep the stored choice selected so restoring the Preset brings it back (no silent reset).
			$options[] = array(
				'value' => $missing_id,
				'label' => sprintf(
					/* translators: %s: preset title or ID */
					__( '%s (unavailable)', 'modula-pro' ),
					self::preset_label( $missing_id )
				),
			);
		}
		return $options;
	}

	/**
	 * @param int $preset_id Preset ID.
	 * @return string Title, or `#ID` when the post has none.
	 */
	private static function preset_label( $preset_id ) {
		$title = get_the_title( $preset_id );
		return '' !== $title ? $title : sprintf( '#%d', $preset_id );
	}

	/**
	 * Record a failed create-time apply in the Modula Debug Log, when Lite provides it.
	 *
	 * @param int       $post_id   Gallery ID.
	 * @param int       $preset_id Preset ID.
	 * @param \WP_Error $error     Apply error.
	 * @return void
	 */
	private static function log_apply_failure( $post_id, $preset_id, \WP_Error $error ) {
		if ( ! class_exists( 'Modula_Debug_Log' ) || ! is_callable( array( 'Modula_Debug_Log', 'log_failure' ) ) ) {
			return;
		}
		\Modula_Debug_Log::log_failure(
			\Modula_Debug_Log::CHANNEL_GALLERY_PERSIST,
			'Default preset apply on create failed: ' . $error->get_error_message(),
			array(
				'gallery_id' => (int) $post_id,
				'preset_id'  => (int) $preset_id,
				'error_code' => (string) $error->get_error_code(),
			)
		);
	}
}
