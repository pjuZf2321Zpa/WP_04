<?php
/**
 * Settings editor (v2) integration for gallery defaults.
 *
 * @package Modula_Pro\Extensions\Defaults
 */

namespace Modula_Pro\Extensions\Defaults\Admin;

use Modula_Pro\Extensions\Defaults\Utils\Preset_Storage;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Editor_Integration
 */
class Settings_Editor_Integration {

	/**
	 * @var string
	 */
	private $extension_url = 'includes/extensions/defaults';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'modula_settings_editor_config', array( $this, 'filter_settings_editor_config' ), 10, 2 );
		add_action( 'modula_gallery_settings_editor_enqueue', array( $this, 'enqueue_settings_editor_defaults' ), 10, 1 );
	}

	/**
	 * Inject defaults bootstrap into the React settings editor.
	 *
	 * @param array<string, mixed> $editor_config Localized config.
	 * @param int                  $post_id       Gallery post ID.
	 * @return array<string, mixed>
	 */
	public function filter_settings_editor_config( $editor_config, $post_id ) {
		unset( $post_id );

		$presets = Preset_Storage::list_presets();

		$editor_config['galleryDefaults'] = array(
			'restNamespace'  => 'modula-defaults/v1',
			'presetCount'    => count( $presets ),
			'featureEnabled' => true,
		);

		return $editor_config;
	}

	/**
	 * Enqueue the Pro defaults settings-editor bundle after the lite shell.
	 *
	 * @param int $post_id Gallery post ID.
	 * @return void
	 */
	public function enqueue_settings_editor_defaults( $post_id ) {
		unset( $post_id );

		$asset_path = \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-defaults/index.asset.php';
		$script_url = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-defaults/index.js';
		$style_url  = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-defaults/index.css';

		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset = require $asset_path;
		$deps  = isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] )
			? $asset['dependencies']
			: array();

		if ( ! in_array( 'modula-gallery-settings-editor', $deps, true ) ) {
			$deps[] = 'modula-gallery-settings-editor';
		}

		$version = isset( $asset['version'] ) ? $asset['version'] : \MODULA_PRO_VERSION;

		wp_enqueue_script(
			'modula-settings-editor-defaults',
			$script_url,
			$deps,
			$version,
			true
		);

		if ( file_exists( \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-defaults/index.css' ) ) {
			wp_enqueue_style(
				'modula-settings-editor-defaults',
				$style_url,
				array( 'modula-gallery-settings-editor' ),
				$version
			);
		}

		wp_set_script_translations(
			'modula-settings-editor-defaults',
			'modula-pro',
			\MODULA_PRO_PATH . 'languages'
		);
	}
}
