<?php
/**
 * Gallery listing integration for Apply preset (Defaults).
 *
 * @package Modula_Pro\Extensions\Defaults
 */

namespace Modula_Pro\Extensions\Defaults\Admin;

use Modula_Pro\Extensions\Defaults\Utils\Preset_Storage;

defined( 'ABSPATH' ) || exit;

/**
 * Class Listing_Integration
 */
class Listing_Integration {

	/**
	 * @var string
	 */
	private $extension_url = 'includes/extensions/defaults';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'modula_gallery_listing_config', array( $this, 'filter_listing_config' ) );
		add_action( 'modula_gallery_listing_enqueue', array( $this, 'enqueue_listing_defaults' ) );
	}

	/**
	 * Mark Apply preset (listing) as entitled and offer New from preset when Defaults is active.
	 *
	 * @param array<string, mixed> $config Listing bootstrap.
	 * @return array<string, mixed>
	 */
	public function filter_listing_config( $config ) {
		if ( ! is_array( $config ) ) {
			return $config;
		}
		if ( $this->listing_defaults_asset_ready() ) {
			$config['canUseApplyPreset'] = true;
		}
		// New from preset menu in the New gallery editor choice (Lite renders it).
		$classic_types                    = self::classic_gallery_types();
		$config['galleryPresets']         = array_map(
			static function ( array $preset ) use ( $classic_types ) {
				return self::to_create_menu_preset( $preset, $classic_types );
			},
			Preset_Storage::list_presets()
		);
		$config['defaultGalleryPresetId'] = Default_Preset::usable_default_id();
		return $config;
	}

	/**
	 * @param array<string, mixed> $preset        Preset_Storage::list_presets() row.
	 * @param string[]|null        $classic_types Classic editor gallery types, null when unknown.
	 * @return array{id: int, title: string, summary: string, classicEditor: bool} Menu row; summary is the layout label.
	 */
	private static function to_create_menu_preset( array $preset, $classic_types ) {
		return array(
			'id'            => (int) $preset['id'],
			'title'         => (string) $preset['title'],
			'summary'       => is_array( $preset['summary'] ?? null ) ? Preset_Storage::summary_layout_label( $preset['summary'] ) : '',
			'classicEditor' => self::classic_can_show_layout( (int) $preset['id'], $classic_types ),
		);
	}

	/**
	 * Whether the classic editor can show a preset's layout.
	 *
	 * Reads the flat `type` that classic New from preset fills the Gallery Type field
	 * with (Defaults::modula_defaults_field_value), not the v2 summary: v2 reads classic
	 * Masonry + Automatic columns as `justified-grid`. A preset without a type starts
	 * from the classic default. Lite always loads its classic fields helper; if it is
	 * ever missing, every preset stays (today's menu) rather than hiding them all.
	 *
	 * @param int           $preset_id     Preset ID.
	 * @param string[]|null $classic_types Classic editor gallery types, null when unknown.
	 * @return bool
	 */
	private static function classic_can_show_layout( $preset_id, $classic_types ) {
		$settings = get_post_meta( $preset_id, 'modula-settings', true );
		$type     = is_array( $settings ) && is_string( $settings['type'] ?? null ) ? $settings['type'] : '';
		if ( '' === $type || null === $classic_types ) {
			return true;
		}
		return in_array( $type, $classic_types, true );
	}

	/**
	 * Gallery types the classic Gallery Type field offers (Lite's plus Pro's slider, video, BnB).
	 *
	 * @return string[]|null Type slugs, or null when the classic fields are unavailable.
	 */
	private static function classic_gallery_types() {
		if ( ! class_exists( 'Modula_CPT_Fields_Helper' ) ) {
			return null;
		}
		$general = \Modula_CPT_Fields_Helper::get_fields( 'general' );
		$values  = $general['type']['values'] ?? null;
		return is_array( $values ) ? array_map( 'strval', array_keys( $values ) ) : null;
	}

	/**
	 * @return bool
	 */
	private function listing_defaults_asset_ready() {
		return file_exists(
			\MODULA_PRO_PATH . $this->extension_url . '/public/gallery-listing-defaults/index.asset.php'
		);
	}

	/**
	 * Enqueue the listing Defaults Apply preset host after the Lite listing shell.
	 *
	 * @return void
	 */
	public function enqueue_listing_defaults() {
		if ( ! $this->listing_defaults_asset_ready() ) {
			return;
		}

		$asset_path = \MODULA_PRO_PATH . $this->extension_url . '/public/gallery-listing-defaults/index.asset.php';
		$script_url = \MODULA_PRO_URL . $this->extension_url . '/public/gallery-listing-defaults/index.js';
		$style_url  = \MODULA_PRO_URL . $this->extension_url . '/public/gallery-listing-defaults/index.css';

		$asset = require $asset_path;
		$deps  = isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] )
			? $asset['dependencies']
			: array();

		if ( ! in_array( 'modula-gallery-listing', $deps, true ) ) {
			$deps[] = 'modula-gallery-listing';
		}

		$version = isset( $asset['version'] ) ? $asset['version'] : \MODULA_PRO_VERSION;

		wp_enqueue_script(
			'modula-gallery-listing-defaults',
			$script_url,
			$deps,
			$version,
			true
		);

		wp_localize_script(
			'modula-gallery-listing-defaults',
			'modulaGalleryListingDefaults',
			array(
				'restNamespace' => 'modula-defaults/v1',
				'nonce'         => wp_create_nonce( 'wp_rest' ),
			)
		);

		// admin-ui's own styles come with the Content page's stylesheet.
		if ( file_exists( \MODULA_PRO_PATH . $this->extension_url . '/public/gallery-listing-defaults/index.css' ) ) {
			wp_enqueue_style(
				'modula-gallery-listing-defaults',
				$style_url,
				array( 'modula-gallery-listing' ),
				$version
			);
		}

		wp_set_script_translations(
			'modula-gallery-listing-defaults',
			'modula-pro',
			\MODULA_PRO_PATH . 'languages'
		);
	}
}
