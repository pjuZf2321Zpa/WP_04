<?php
namespace Modula_Pro\Extensions\Defaults;

use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Defaults\Admin\Default_Preset;
use Modula_Pro\Extensions\Defaults\Admin\Listing_Integration;
use Modula_Pro\Extensions\Defaults\Admin\Settings_Editor_Integration;
use Modula_Pro\Extensions\Defaults\CPT\Default_Album;
use Modula_Pro\Extensions\Defaults\CPT\Default_Gallery;
use Modula_Pro\Extensions\Defaults\Rest_API\WP_Rest_Modula_Defaults_Controller;
use Modula_Pro\Extensions\Extensions;

class Defaults {
	/**
	 * Class instance.
	 *
	 * @var Defaults
	 */
	private static $instance;

	/**
	 * Get the instance of the class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Defaults ) ) {
			self::$instance = new Defaults();
		}

		return self::$instance;
	}

	public function __construct() {
		new Enqueue();
		require_once __DIR__ . '/abilities/class-gallery-preset-executor.php';
		require_once __DIR__ . '/abilities/class-album-preset-executor.php';
		require_once __DIR__ . '/abilities/class-provider.php';
		\Modula_Pro\Extensions\Defaults\Abilities\Provider::boot();
		add_filter( 'modula_enqueue_for_post_types', array( $this, 'allowed_post_types' ) );
		new Default_Gallery();
		new Default_Album();
		$this->init_rest_and_editor();
		$this->set_admin_requirements();
	}

	/**
	 * REST + v2 settings editor integration (always when extension loads).
	 *
	 * @return void
	 */
	private function init_rest_and_editor() {
		$extensions = Extensions::get_instance();
		if ( $extensions && $extensions->is_upgradable_addon( 'modula-defaults' ) ) {
			return;
		}

		new WP_Rest_Modula_Defaults_Controller();

		// Not admin-only: the general-settings app loads and saves its tabs over REST.
		if ( ! class_exists( Default_Preset::class, false ) ) {
			require_once __DIR__ . '/admin/class-default-preset.php';
		}
		new Default_Preset();

		if ( is_admin() ) {
			new Settings_Editor_Integration();
			if ( ! class_exists( Listing_Integration::class, false ) ) {
				require_once __DIR__ . '/admin/class-listing-integration.php';
			}
			new Listing_Integration();
		}
	}

	public function allowed_post_types( $allowed_post_types ) {
		$allowed_post_types[] = 'modula-defaults';
		$allowed_post_types[] = 'defaults-albums';
		return $allowed_post_types;
	}

	/**
	 * Set admin requirements
	 *
	 * @return void
	 */
	public function set_admin_requirements() {
		if ( ! is_admin() ) {
			return;
		}

		$extensions = Extensions::get_instance();

		if ( $extensions && ! $extensions->is_upgradable_addon( 'modula-defaults' ) ) {
			if ( class_exists( 'Modula_Pro\Extensions\Albums\Albums' ) ) {
				add_filter( 'modula_albums_admin_field_value', array( $this, 'modula_defaults_albums_field_value' ), 3, 15 );
				add_filter( 'modula_album_fields', array( $this, 'modula_album_fields' ), 100 );
				add_action( 'save_post', array( $this, 'save_meta_boxes' ), 100, 2 );
				add_action( 'page_attributes_misc_attributes', array( $this, 'child_album_inherit_settings_metabox' ) );
			}

			$this->require_admin();
			add_filter( 'modula_backbone_settings', array( $this, 'set_defaults' ), 1, 15 );
			add_filter( 'modula_pro_cpt_sorting_default', array( $this, 'set_sorting_default' ) );
		} else {
			add_filter( 'modula_defaults_cpt_args', array( $this, 'remove_defaults_galleries_menu_item' ) );
			add_filter( 'modula_defaults_albums_cpt_args', array( $this, 'remove_defaults_albums_menu_item' ) );
		}
	}

		/**
	 * Loads all admin related files into scope.
	 *
	 * @since 1.0.0
	 */
	public function require_admin() {
		add_filter( 'modula_admin_field_value', array( $this, 'modula_defaults_field_value' ), 3, 15 );
		add_action( 'admin_footer', array( $this, 'print_modula_templates' ) );

		add_action( 'wp_ajax_modula_defaults_settings', array( $this, 'defaults_populate' ) );
		add_action( 'wp_ajax_import_modula_default', array( $this, 'populate_import_select' ) );
		add_action( 'wp_ajax_import_modula_default_setting', array( $this, 'import_modula_default_setting' ) );
		add_filter( 'modula_page_header', array( $this, 'modula_header' ) );
		add_filter( 'modula_admin_page_link', array( $this, 'unset_upsells_menu_entries' ), 30, 1 );
	}

	/**
	 * Print Default template
	 *
	 * @since 1.0.0
	 */
	public function print_modula_templates() {
		include MODULA_PRO_PATH . 'includes/extensions/defaults/templates/modula-defaults-js-templates.php';
		include MODULA_PRO_PATH . 'includes/extensions/defaults/templates/modula-defaults-js-template-import.php';
	}

	/**
	 * Set the new settings for the New Modula Gallery
	 *
	 * @param $settings
	 *
	 * @return array|object|string|void
	 *
	 */
	public function set_defaults( $settings ) {
		//phpcs:disable WordPress.Security
		if ( ! isset( $_GET['modula_default'] ) || ! wp_unslash( $_GET['modula_default'] ) ) {
			return $settings;
		}

		if ( 'modula-defaults' !== get_post_type( absint( wp_unslash( $_GET['modula_default'] ) ) ) ) {
			return $settings;
		}

		$default_setting = get_post_meta( absint( $_GET['modula_default'] ), 'modula-settings', true );

		$default_setting = wp_parse_args( $default_setting, $settings );

		return $default_setting;
	}

	/**
	 * Set the new settings for the New Modula Gallery
	 *
	 * @param $settings
	 *
	 * @return array|object|string|void
	 *
	 * @since 1.2.5
	 */
	public function set_sorting_default( $sorting ) {

		if ( ! isset( $_GET['modula_default'] ) || ! $_GET['modula_default'] ) {
			return $sorting;
		}

		if ( 'modula-defaults' !== get_post_type( absint( $_GET['modula_default'] ) ) ) {
			return $sorting;
		}

		$default_sorting = get_post_meta( absint( $_GET['modula_default'] ), 'modulaSorting', true );

		if ( $default_sorting ) {
			return $default_sorting;
		}

		return $sorting;
	}

	/**
	 * Set the admin fields
	 *
	 * @param $value
	 * @param $key
	 *
	 * @return mixed
	 *
	 */
	public function modula_defaults_field_value( $value, $key ) {

		if ( ! isset( $_GET['modula_default'] ) || ! $_GET['modula_default'] ) {
			return $value;
		}

		if ( 'modula-defaults' !== get_post_type( absint( $_GET['modula_default'] ) ) ) {
			return $value;
		}

		if ( 'watermark_apply_to_existing_images' === $key ) {
			return $value;
		}

		if ( 'watermark_remove_watermark' === $key ) {
			return $value;
		}

		if ( 'modula_speed_help' === $key ) {
			return $value;
		}

		$default_setting = get_post_meta( absint( $_GET['modula_default'] ), 'modula-settings', true );
		$default_setting = wp_parse_args( $default_setting, \Modula_CPT_Fields_Helper::get_defaults() );

		// Fields with no stored or built-in default (e.g. Pro `helper-message`) keep their own value.
		if ( ! array_key_exists( $key, $default_setting ) ) {
			return $value;
		}

		return $default_setting[ $key ];
	}

	/**
	 * Set the admin fields for Modula albums
	 *
	 * @param $value
	 * @param $key
	 *
	 * @return mixed
	 *
	 */
	public function modula_defaults_albums_field_value( $value, $key ) {

		if ( ! isset( $_GET['modula_default'] ) || ! $_GET['modula_default'] ) {
			return $value;
		}

		if ( 'defaults-albums' !== get_post_type( absint( $_GET['modula_default'] ) ) ) {
			return $value;
		}

		$default_setting = get_post_meta( absint( $_GET['modula_default'] ), 'modula-album-settings', true );
		$default_setting = wp_parse_args( $default_setting, Fields_Helper::get_defaults() );
		$value           = $default_setting[ $key ];

		return $value;
	}

	public function defaults_populate() {

		$this->verify_defaults_ajax();

		if ( ! isset( $_POST['post_type'] ) ) {
			echo false;
			wp_die();
		}

		$options = array();

		$post_type = ( 'modula-gallery' === $_POST['post_type'] ) ? 'modula-defaults' : 'defaults-albums';

		$modula_defaults = get_posts(
			array(
				'post_type'   => $post_type,
				'numberposts' => -1,
				'orderby'     => 'date',
				'order'       => 'ASC',
			)
		);

		if ( $modula_defaults ) {
			foreach ( $modula_defaults as $default ) {
				$options[] = array(
					'id'    => absint( $default->ID ),
					'title' => ( $default->post_title && '' !== $default->post_title ) ? esc_html( $default->post_title ) : esc_html__( 'Preset ID ', 'modula-pro' ) . $default->ID,
				);
			}
		}

		echo wp_json_encode( $options );
		wp_die();
	}

	public function populate_import_select() {

		$this->verify_defaults_ajax();

		if ( ! isset( $_POST['post_type'] ) ) {
			echo false;
			wp_die();
		}

		$options = array();

		$post_type = ( 'modula-gallery' === $_POST['post_type'] ) ? 'modula-defaults' : 'defaults-albums';

		$modula_defaults = get_posts(
			array(
				'post_type'   => $post_type,
				'numberposts' => -1,
				'orderby'     => 'date',
				'order'       => 'ASC',
			)
		);

		if ( $modula_defaults ) {
			foreach ( $modula_defaults as $default ) {
				$options[] = array(
					'id'    => absint( $default->ID ),
					'title' => ( $default->post_title && '' !== $default->post_title ) ? esc_html( $default->post_title ) : esc_html__( 'Preset ID ', 'modula-pro' ) . $default->ID,
				);
			}
		}

		echo wp_json_encode( $options );
		wp_die();
	}

	public function import_modula_default_setting() {

		$this->verify_defaults_ajax();

		// Bounce if there is no import ID or current post ID
		if ( ! isset( $_POST['post_id'] ) || ! isset( $_POST['current_post'] ) ) {
			echo false;
			wp_die();
		}

		$allowed_cpt = array( 'modula-defaults', 'defaults-albums', 'modula-gallery', 'modula-album' );
		$post_type   = get_post_type( absint( $_POST['post_id'] ) );

		if ( ! in_array( $post_type, $allowed_cpt, true ) ) {
			echo false;
			wp_die();
		}

		$preset_id = absint( $_POST['post_id'] );
		if ( ! current_user_can( 'edit_post', $preset_id ) ) {
			wp_die( -1, 403 );
		}

		if ( ! is_array( $_POST['current_post'] ) ) {
			// Do this one for single post
			$curr_post_type = get_post_type( absint( $_POST['current_post'] ) );

			// Check to see if we are in the correct post type and we import the correct post type
			if ( ! in_array( $curr_post_type, $allowed_cpt, true ) ) {
				echo false;
				wp_die();
			}

			$current_id = absint( $_POST['current_post'] );
			if ( ! current_user_can( 'edit_post', $current_id ) ) {
				wp_die( -1, 403 );
			}

			if ( 'modula-defaults' === $post_type ) {
				$preset_settings  = wp_parse_args( get_post_meta( absint( $_POST['post_id'] ), 'modula-settings', true ), \Modula_CPT_Fields_Helper::get_defaults() );
				$gallery_settings = get_post_meta( absint( $_POST['current_post'] ), 'modula-settings', true );

				// We update the gallery with the new options and keep options that are not found in defaults
				update_post_meta( absint( $_POST['current_post'] ), 'modula-settings', wp_parse_args( $preset_settings, $gallery_settings ) );

				// We update the sorting options with those in defaults
				$sorting = get_post_meta( absint( $_POST['post_id'] ), 'modulaSorting', true );
				update_post_meta( absint( $_POST['current_post'] ), 'modulaSorting', $sorting );
			} else {
				$preset_settings = wp_parse_args( get_post_meta( absint( $_POST['post_id'] ), 'modula-album-settings', true ), Fields_Helper::get_defaults() );
				$album_settings  = get_post_meta( absint( $_POST['current_post'] ), 'modula-album-settings', true );

				// We update the album with the new options and keep options that are not found in defaults
				update_post_meta( absint( $_POST['current_post'] ), 'modula-album-settings', wp_parse_args( $preset_settings, $album_settings ) );
			}
		} else {
			// Do this for post array
			foreach ( $_POST['current_post'] as $mcpt ) {

				// Do this one for single post
				$curr_post_type = get_post_type( absint( $mcpt ) );

				// Check to see if we are in the correct post type and we import the correct post type
				if ( ! in_array( $curr_post_type, $allowed_cpt, true ) ) {
					continue;
				}

				$target_id = absint( $mcpt );
				if ( ! current_user_can( 'edit_post', $target_id ) ) {
					continue;
				}

				if ( 'modula-defaults' === $post_type ) {
					$preset_settings  = wp_parse_args( get_post_meta( absint( $_POST['post_id'] ), 'modula-settings', true ), \Modula_CPT_Fields_Helper::get_defaults() );
					$gallery_settings = get_post_meta( absint( $mcpt ), 'modula-settings', true );

					// We update the gallery with the new options and keep options that are not found in defaults
					update_post_meta( absint( $mcpt ), 'modula-settings', wp_parse_args( $preset_settings, $gallery_settings ) );

					// We update the sorting options with those in defaults
					$sorting = get_post_meta( absint( $_POST['post_id'] ), 'modulaSorting', true );
					update_post_meta( absint( $mcpt ), 'modulaSorting', $sorting );
				} else {
					$preset_settings = wp_parse_args( get_post_meta( absint( $_POST['post_id'] ), 'modula-album-settings', true ), Fields_Helper::get_defaults() );
					$album_settings  = get_post_meta( absint( $mcpt ), 'modula-album-settings', true );

					// We update the album with the new options and keep options that are not found in defaults
					update_post_meta( absint( $mcpt ), 'modula-album-settings', wp_parse_args( $preset_settings, $album_settings ) );
				}
			}
		}

		// Everything good and settings were imported
		echo 'Settings imported';
		wp_die();
	}

	public function modula_header( $return_value ) {

		$current_screen = get_current_screen();

		if ( 'modula-defaults' === $current_screen->post_type || 'defaults-albums' === $current_screen->post_type ) {
			return true;
		}
		return $return_value;
	}

	/**
	 * Verify AJAX nonce and editor capability for defaults admin actions.
	 *
	 * Album editors may hold album capabilities without edit_posts. Each
	 * action still checks edit_post on the items it changes.
	 *
	 * @return void
	 */
	private function verify_defaults_ajax() {
		check_ajax_referer( 'modula-defaults', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) && ! WP_Rest_Modula_Defaults_Controller::can_edit_albums() ) {
			wp_die( -1, 403 );
		}
	}

	/**
	 * Unset upsell menu entries
	 *
	 * @param [type] $links
	 * @return void
	 */
	public function unset_upsells_menu_entries( $links ) {

		if ( isset( $links['moduladefaults'] ) ) {
			unset( $links['moduladefaults'] );
		}

		if ( isset( $links['albumsdefaults'] ) ) {
			unset( $links['albumsdefaults'] );
		}

		return $links;
	}

	/**
	 * Remove Gallery Defaults menu item from Modula if license expired or non-existent.
	 *
	 */
	public function remove_defaults_galleries_menu_item( $args ) {

		$args['show_in_menu'] = false;

		return $args;
	}

	/**
	 * Remove Albums Defaults menu item from Modula if license expired or non-existent.
	 *
	 */
	public function remove_defaults_albums_menu_item( $args ) {

		$args['show_in_menu'] = false;

		return $args;
	}

	public function modula_album_fields( $fields ) {
		$fields['general']['inherit_from_parent'] = array(
			'name'      => esc_html__( 'Overwrite children settings', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 0,
			'priority'  => 10,
			'data_type' => 'bool',
		);

		return $fields;
	}

	public function save_meta_boxes( $post_id, $post ) {

		$post_type = get_post_type_object( $post->post_type );

		/* Check if the current user has permission to edit the post. */
		if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) || 'modula-album' !== $post_type->name ) {
			return $post_id;
		}

		if ( ! isset( $_POST['modula-settings'] ) ) {
			return $post_id;
		}

		if ( isset( $_POST['modula-settings']['inherit_from_parent'] ) ) {
			$modula_settings                        = get_post_meta( $post_id, 'modula-album-settings', true );
			$modula_settings['inherit_from_parent'] = 0;
			update_post_meta( $post_id, 'modula-album-settings', $modula_settings );

			$this->overwrite_album_children_settings( $post_id, $modula_settings );
		}

		if ( isset( $_POST['modula-settings']['album_child_inherit_parent'] ) ) {
			$this->child_album_inherit_settings( $post_id );
		}
		return $post_id;
	}

	private function overwrite_album_children_settings( $album_id, $settings = array() ) {

		if ( empty( $settings ) ) {
			$settings = get_post_meta( $album_id, 'modula-album-settings', true );
		}

		$children = get_posts(
			array(
				'post_type'      => 'modula-album',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'post_parent'    => $album_id,
				'orderby'        => 'menu_order',
				'order'          => 'ASC',
				'fields'         => 'ids',
			)
		);

		if ( empty( $children ) ) {
			return;
		}

		foreach ( $children as $child_id ) {
			update_post_meta( $child_id, 'modula-album-settings', $settings );
			$this->overwrite_album_children_settings( $child_id, $settings );
		}
	}

	public function child_album_inherit_settings_metabox( $post ) {

		$post_type = get_post_type_object( $post->post_type );
		if ( ! current_user_can( $post_type->cap->edit_post, $post->ID ) || 'modula-album' !== $post_type->name ) {
			return;
		}

		?>
		<div id="modula-album-default-item-attributes">
			<label for="album_child_inherit_parent"> <?php esc_html_e( 'Import parent settings', 'modula-pro' ); ?></label>
			<div class="modula-toggle">
				<input 
					class="modula-toggle__input"
					type="checkbox"
					id="album_child_inherit_parent"
					name="modula-settings[album_child_inherit_parent]"
					data-setting="album_child_inherit_parent"
					value="1"
				>
				<div class="modula-toggle__items">
					<span class="modula-toggle__track"></span>
					<span class="modula-toggle__thumb"></span>

					<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 6 6">
						<path d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path>
					</svg>
					<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 2 6">
						<path d="M0 0h2v6H0z"></path>
					</svg>
				</div>
			</div>
		</div>
		<?php
	}

	private function child_album_inherit_settings( $album_id ) {
		$parent_id = wp_get_post_parent_id( $album_id );

		if ( ! $parent_id ) {
			return;
		}

		$settings = get_post_meta( $parent_id, 'modula-album-settings', true );

		if ( empty( $settings ) || ! is_array( $settings ) ) {
			return;
		}

		update_post_meta( $album_id, 'modula-album-settings', $settings );
	}
}
