<?php
namespace Modula_Pro\Extensions\Defaults;

class Enqueue {
	private $extension_url = 'includes/extensions/defaults';

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	public function enqueue_scripts() {
		$screen        = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$defaults_cpt  = $screen && in_array( $screen->post_type, array( 'modula-defaults', 'defaults-albums' ), true );
		$gallery_id    = 0;
		if ( $screen && 'modula-gallery' === $screen->post_type && class_exists( '\Modula\V2\Beta_Settings' ) ) {
			$gallery_id = \Modula\V2\Beta_Settings::current_gallery_id();
		}
		$modern_editor = (bool) apply_filters( 'modula_enable_modern_settings_editor', false, $gallery_id );
		$on_gallery_list = $screen && isset( $screen->id ) && 'edit-modula-gallery' === $screen->id;

		// v2 gallery editor: skip legacy Add New / import intercept; defaults CPT keeps legacy assets.
		if ( $modern_editor && ! $defaults_cpt ) {
			return;
		}

		wp_enqueue_media();

		wp_enqueue_style( 'modula-defaults-admin-style', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-defaults-admin.css', null, \MODULA_PRO_VERSION );
		wp_enqueue_style( 'modula-selectize', \MODULA_URL . 'assets/css/admin/selectize.default.css', array(), \MODULA_PRO_VERSION );
		wp_enqueue_style( 'admin-modula-album-grid-system' );

		// Loaded from modula pro
		wp_enqueue_script( 'modula-selectize', \MODULA_URL . 'assets/js/admin/selectize.js', array( 'jquery' ), MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-header-style', \MODULA_URL . 'assets/css/admin/modula-header.css', null, \MODULA_PRO_VERSION );
		wp_enqueue_script( 'modula-pro-tilt' );

		if ( ! $modern_editor && ! $on_gallery_list ) {
			// Script used for adding new galleries (legacy Add New intercept).
			wp_enqueue_script( 'modula-defaults-modal', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-defaults-modal.js', array(), \MODULA_PRO_VERSION, true );
			wp_enqueue_script( 'modula-defaults-admin', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-defaults-admin.js', array( 'modula-defaults-modal' ), \MODULA_PRO_VERSION, true );
		}

		wp_enqueue_script( 'modula-defaults-import-modal', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-defaults-import-modal.js', array(), \MODULA_PRO_VERSION, true );

		$localize_handle = ( $modern_editor || $on_gallery_list ) ? 'modula-defaults-import-modal' : 'modula-defaults-admin';

		// Localize the script
		wp_localize_script(
			$localize_handle,
			'modulaDefaultHelper',
			array(
				'ajax_url'           => admin_url( 'admin-ajax.php' ),
				'nonce'              => wp_create_nonce( 'modula-defaults' ),
				'defaults_galleries' => count( get_posts( array( 'post_type' => 'modula-defaults' ) ) ),
				'defaults_albums'    => count( get_posts( array( 'post_type' => 'defaults-albums' ) ) ),
				'creating_default'   => esc_html__( 'Creating preset', 'modula-pro' ),
				'created_default'    => esc_html__( 'Preset created', 'modula-pro' ),
				'error_creating'     => esc_html__( 'Error creating preset', 'modula-pro' ),
				'confirmation_text'  => esc_html__( 'All settings will be overwritten. Are you sure?', 'modula-pro' ),
			)
		);
	}
}
