const { __ } = wp.i18n;
const { Fragment, useEffect } = wp.element;

import ModulaDefaultGalleryImage from './ModulaGalleryImage';
import ModulaDefaultStyle from './ModulaDefaultStyle';
import ModulaDefaultMediaPlaceholder from './ModulaMediaPlaceholder';

const ModulaDefaultGallery = ( props ) => {
	const { images, jsConfig, id } = props.attributes;
	const { defaultSettings, galleryId } = props;
	const {
		exportImages,
		modulaRun,
		onSelectImage,
		onSelectImages,
		onMoveBackward,
		onMoveForward,
		onRemoveImage,
		isFirstItem,
		isLastItem,
		isSelected,
		selectedImage,
		checkHoverEffect,
		imageCount,
		setImageCount,
	} = props;

	useEffect( () => {
		if ( defaultSettings !== undefined ) {
			checkHoverEffect( defaultSettings.effect );
		}
		if ( jsConfig !== undefined ) {
			modulaRun( jsConfig );
		}
	}, [] );

	let galleryClassNames = 'modula modula-gallery ';
	let itemsClassNames = 'modula-items';
	if ( defaultSettings.type == 'creative-gallery' ) {
		galleryClassNames += 'modula-creative-gallery';
	} else if ( defaultSettings.type == 'custom-grid' ) {
		galleryClassNames += 'modula-custom-grid';
	} else if ( defaultSettings.type == 'slider' ) {
		galleryClassNames = 'modula-slider';
	} else {
		galleryClassNames += 'modula-columns';
		itemsClassNames += ' grid-gallery';
		if ( defaultSettings.grid_type == 'automatic' ) {
			itemsClassNames += ' justified-gallery';
		}
	}

	return [
		<Fragment key={ 5 }>
			{ /* <Inspector onIdChange={ ( id ) => onIdChange( id ) } { ...props } /> */ }
			<ModulaDefaultStyle id={ galleryId } settings={ defaultSettings } />
			<div
				id={ `jtg-${ galleryId }` }
				className={ galleryClassNames }
				data-config={ JSON.stringify( jsConfig ) }
			>
				{ defaultSettings.type == 'grid' &&
					'automatic' != defaultSettings.grid_type && (
						<div className="modula-grid-sizer"> </div>
					) }
				<div className={ itemsClassNames }>
					{ images.length > 0 && (
						<Fragment>
							<Fragment>
								{ images.map( ( img, index ) => {
									return [
										<ModulaDefaultGalleryImage
											{ ...props }
											img={ img }
											index={ index }
											selectedImage={ selectedImage }
											isFirstItem={ index === 0 }
											isLastItem={
												index + 1 === images.length
											}
											isSelected={
												isSelected &&
												selectedImage === index
											}
											onSelect={ onSelectImage }
											onMoveBackward={ onMoveBackward(
												index
											) }
											onMoveForward={ onMoveForward(
												index
											) }
											key={ index }
										/>,
									];
								} ) }
							</Fragment>
						</Fragment>
					) }
				</div>
			</div>
			<ModulaDefaultMediaPlaceholder
				onSelectImages={ onSelectImages }
				images={ images }
				imageCount={ imageCount }
				setImageCount={ setImageCount }
				setAttributes={ props.setAttributes }
				attributes={ props.attributes }
			/>
		</Fragment>,
	];
};

export default ModulaDefaultGallery;
