import icons from '../utils/icons';
const { useSelect } = wp.data;
const { Fragment } = wp.element;

const ModulaDefaultGalleryImageInner = ( props ) => {
	const {
		defaultSettings,
		onSelectImage,
		index,
		imageId,
		hideTitle,
		hideDescription,
		hideSocial,
	} = props;

	// Fetch image meta with hook ( probabily will be moved into ModulaGalleryImage ## REMINDER)
	const imageMeta = useSelect(
		( select ) => {
			return select( 'core' ).getMedia( imageId );
		},
		//force the function not to run evertime the component renders just on specific events
		[ onSelectImage ]
	);

	const effectArray = [ 'tilt_1', 'tilt_3', 'tilt_7' ],
		overlayArray = [ 'tilt_3', 'tilt_7' ],
		svgArray = [ 'tilt_1', 'tilt_7' ],
		jtgBody = [
			'lily',
			'sadie',
			'ruby',
			'bubba',
			'dexter',
			'chico',
			'ming',
		];

	return (
		<Fragment key={ 8 }>
			{ effectArray.includes( defaultSettings.effect ) && (
				<div className="tilter__deco tilter__deco--shine">
					<div />
				</div>
			) }
			{ overlayArray.includes( defaultSettings.effect ) && (
				<div className="tilter__deco tilter__deco--overlay" />
			) }

			{ svgArray.includes( defaultSettings.effect ) && (
				<div className="tilter__deco tilter__deco--lines" />
			) }

			<div
				className="figc"
				onClick={ onSelectImage( index ) }
				onFocus={ onSelectImage( index ) }
			>
				<div className="figc-inner">
					{ /* checking for undefined because on the first run , imageId doesnt exist */ }
					{ ! hideTitle && (
						<h2
							className={
								! jtgBody.includes( defaultSettings.effect )
									? 'jtg-title'
									: ''
							}
						>
							{ ' ' }
							{ undefined != imageMeta &&
								imageMeta.title.rendered }{ ' ' }
						</h2>
					) }
					<div
						className={
							jtgBody.includes( defaultSettings.effect )
								? 'jtg-body'
								: ''
						}
					>
						{ ! hideDescription && (
							<p className="description">
								{ ' ' }
								{ undefined != imageMeta &&
									imageMeta.caption.raw }{ ' ' }
							</p>
						) }

						{ ! hideSocial &&
							'1' == defaultSettings.enableSocial && (
								<div className="jtg-social">
									{ '1' == defaultSettings.enableTwitter && (
										<a
											className="modula-icon-twitter"
											href="#"
										>
											{ ' ' }
											${ icons.twitter }{ ' ' }
										</a>
									) }
									{ '1' == defaultSettings.enableFacebook && (
										<a
											className="modula-icon-facebook"
											href="#"
										>
											{ ' ' }
											${ icons.facebook }{ ' ' }
										</a>
									) }
									{ '1' == defaultSettings.enableWhatsapp && (
										<a
											className="modula-icon-whatsapp"
											href="#"
										>
											{ ' ' }
											${ icons.whatsapp }{ ' ' }
										</a>
									) }
									{ '1' == defaultSettings.enableLinkedin && (
										<a
											className="modula-icon-linkedin"
											href="#"
										>
											{ ' ' }
											${ icons.linkedin }{ ' ' }
										</a>
									) }
									{ '1' ==
										defaultSettings.enablePinterest && (
										<a
											className="modula-icon-pinterest"
											href="#"
										>
											{ ' ' }
											${ icons.pinterest }{ ' ' }
										</a>
									) }
									{ '1' == defaultSettings.enableEmail && (
										<a
											className="modula-icon-email"
											href="#"
										>
											{ ' ' }
											${ icons.email }{ ' ' }
										</a>
									) }
								</div>
							) }
					</div>
				</div>
			</div>
		</Fragment>
	);
};

export default ModulaDefaultGalleryImageInner;
