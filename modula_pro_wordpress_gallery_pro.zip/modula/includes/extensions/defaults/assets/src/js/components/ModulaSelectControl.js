const { useEffect } = wp.element;

export const ModulaGallerySearch = ( props ) => {
	const {
		className,
		options,
		placeholder,
		value,
		ajax,
		defaults,
		galleries,
		ajaxAction,
	} = props;

	const onChangeFunction =
		'undefined' !== typeof props.onChange
			? props.onChange
			: props.onChangeFunction;

	useEffect( () => {
		const defaultsArray = [];
		const galleriesArray = [];
		if ( defaults != undefined && 0 == defaultsArray.length ) {
			defaults.forEach( ( defaultPreset ) => {
				defaultsArray.push( {
					value: defaultPreset.id,
					label: defaultPreset.title.rendered,
				} );
			} );
		}

		if ( galleries != undefined && 0 == galleriesArray.length ) {
			galleries.forEach( ( gallery ) => {
				galleriesArray.push( {
					value: gallery.id,
					label: gallery.title.rendered,
				} );
			} );
		}

		const getRequiredOption = ( ajaxAction ) => {
			if (
				ajaxAction != undefined &&
				'modula_get_defaults' == ajaxAction
			) {
				if ( 0 == options.length ) {
					return defaultsArray.concat( options );
				}
				return options.concat( defaultsArray );
			} else if (
				ajaxAction != undefined &&
				'modula_get_gallery' == ajaxAction
			) {
				if ( 0 == options.length ) {
					return galleriesArray.concat( options );
				}
				return options.concat( galleriesArray );
			}
		};
		if ( false == ajax ) {
			jQuery( `.${ className }` ).selectize( {
				valueField: 'value',
				labelField: 'label',
				searchField: [ 'label', 'value' ],
				create: false,
				maxItems: 1,
				options,
				placeholder,
				preload: true,
				allowEmptyOptions: true,
				closeAfterSelect: true,
				onChange: ( value ) => {
					onChangeFunction( value );
				},
			} );
		} else {
			jQuery( `.${ className }` ).selectize( {
				valueField: 'value',
				labelField: 'label',
				searchField: [ 'label', 'value' ],
				create: false,
				maxItems: 1,
				placeholder,
				preload: true,
				options:
					'modula_get_defaults' == ajaxAction
						? defaultsArray
						: galleriesArray,
				allowEmptyOptions: true,
				closeAfterSelect: true,
				render: {
					option( item, escape ) {
						return (
							'<div>' +
							'<span class="title">' +
							'<span class="name">' +
							escape( item.label ) +
							'</span>' +
							'</div>'
						);
					},
				},
				load( query, callback ) {
					if ( ! query.length ) {
						return callback();
					}
					jQuery.ajax( {
						url: modulaDefaultsVars.ajaxURL,
						type: 'GET',
						data: {
							action: ajaxAction,
							nonce: modulaDefaultsVars.nonce,
							term: query,
						},
						success: ( res ) => {
							callback( res.slice( 0, 10 ) );
						},
					} );
				},
				onChange: ( value ) => {
					onChangeFunction( value );
				},
			} );
		}
	}, [ defaults, galleries ] );

	return [
		<div key={ 13 } className="modula-inspector-select">
			<label> { props.label }</label>
			<input className={ className } defaultValue={ value } />
		</div>,
	];
};

export default ModulaGallerySearch;
