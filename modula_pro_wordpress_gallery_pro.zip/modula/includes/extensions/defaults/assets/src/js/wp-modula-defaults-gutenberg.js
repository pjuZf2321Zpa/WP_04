/**
 * Internal dependencies
 */
import ModulaDefaultEdit from './components/Edit';
import ModulaDefaultInspector from './components/Inspector';
import icons from './utils/icons';

/**
 * WordPress dependencies
 */

const { __ } = wp.i18n;
const { Platform, Component, Fragment, useEffect, useState } = wp.element;
const { useSelect, withSelect } = wp.data;
const { SelectControl, Button, Spinner, Toolbar, IconButton } = wp.components;
const { createHigherOrderComponent } = wp.compose;

const withDefaultsEdit = createHigherOrderComponent( ( ModulaEdit ) => {
	return ( props ) => {
		const { attributes, setAttributes, isSelected } = props;
		const { id, images, status, isGallery, galleryType } = attributes;

		const switchBlock = ( type ) => {
			setAttributes( {
				status: 'loading',
				images: [],
				id: 0,
				currentSelectize: [],
			} );

			setAttributes( { galleryType: type, status: 'ready' } );
		};

		const defaults = useSelect( ( select ) => {
			const { getEntityRecords } = select( 'core' );
			const query = {
				post_status: 'publish',
				per_page: 1,
			};

			return (
				getEntityRecords( 'postType', 'modula-defaults', query ) || []
			);
		} );

		const galleries = useSelect( ( select ) => {
			const { getEntityRecords } = select( 'core' );
			const query = {
				post_status: 'publish',
				per_page: 1,
			};

			return (
				getEntityRecords( 'postType', 'modula-gallery', query ) || []
			);
		} );

		if ( 'none' === attributes.galleryType ) {
			return [
				<Fragment key={ 1 }>
					<div className="modula-block-preview">
						<div className="modula-block-preview__content">
							<div className="modula-block-preview__logo" />
							<div className="modula-button-group">
								{ galleries.length > 0 && (
									<Button
										className="modula-button"
										target="_blank"
										onClick={ ( e ) => {
											setAttributes( {
												status: 'ready',
												galleryType: 'gallery',
											} );
										} }
									>
										{ __(
											'Display An Existing Gallery',
											'modula-best-grid-gallery'
										) }
										{ icons.chevronRightFancy }
									</Button>
								) }

								<Button
									className="modula-button"
									target="_blank"
									onClick={ ( e ) => {
										setAttributes( {
											status: 'ready',
											defaults,
											galleryType: 'defaults',
										} );
									} }
								>
									{ __(
										'Create New Gallery using a Preset ( fastest way )',
										'modula-best-grid-gallery'
									) }
									{ icons.chevronRightFancy }
								</Button>
							</div>
						</div>
					</div>
				</Fragment>,
			];
		}

		if ( 'gallery' == galleryType ) {
			return (
				<ModulaEdit
					{ ...props }
					defaults={ defaults }
					switchBlock={ switchBlock }
					key={ 1 }
				/>
			);
		}
		return (
			<ModulaDefaultEdit
				{ ...props }
				defaults={ defaults }
				switchBlock={ switchBlock }
				key={ 2 }
			/>
		);
	};
}, 'withDefaultsEdit' );

wp.hooks.addFilter(
	'modula.ModulaEdit',
	'modula/modula-defaults-edit',
	withDefaultsEdit,
	1
);

const withDefaultsInspector = createHigherOrderComponent(
	( ModulaInspector ) => {
		return ( props ) => {
			const selectOptions = ( items ) => {
				if ( undefined == items ) {
					return;
				}
				let options = {};
				if (
					0 < items.length &&
					items[ 0 ].type == 'modula-defaults'
				) {
					options = [
						{
							value: 0,
							label: __(
								'select a preset',
								'modula-best-grid-gallery'
							),
						},
					];
				} else {
					options = [
						{
							value: 0,
							label: __(
								'select a gallery',
								'modula-best-grid-gallery'
							),
						},
					];
				}

				items.forEach( ( gallery ) => {
					if ( gallery.title.rendered.length == 0 ) {
						options.push( {
							value: gallery.id,
							label:
								__(
									'Unnamed Gallery',
									'modula-best-grid-gallery'
								) + gallery.id,
						} );
					} else {
						options.push( {
							value: gallery.id,
							label: gallery.title.rendered,
						} );
					}
				} );

				return options;
			};
			return <ModulaDefaultInspector { ...props } />;
		};
	}
);
wp.hooks.addFilter(
	'modula.ModulaInspector',
	'modula/modula-defaults-inspector',
	withDefaultsInspector,
	1
);
