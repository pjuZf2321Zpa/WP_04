import icons from '../utils/icons';
import ModulaDefaultGalleryImageInner from './ModulaGalleryImageInner';

/**
 * @param {Record<string, unknown>} settings
 * @return {string}
 */
function buildDefaultBlockItemClasses( settings ) {
	const hb = settings?.hover_builder;
	if ( hb && typeof hb === 'object' ) {
		const parts = [ 'modula-item', 'modula-hover-v2' ];
		let card = typeof hb.cardTreatment === 'string' ? hb.cardTreatment : '';
		const dimRaw = hb.dimOverlay;
		let dimOn = dimRaw === true || dimRaw === 1 || dimRaw === '1';
		if ( card === 'dim' ) {
			dimOn = true;
			card = 'none';
		}
		if ( card && card !== 'none' ) {
			parts.push( `modula-hover-card--${ card }` );
		}
		if ( dimOn ) {
			parts.push( 'modula-hover-card--dim-addon' );
		}
		const slots = [
			[ 'title', 'titleEnter' ],
			[ 'caption', 'captionEnter' ],
			[ 'social', 'socialEnter' ],
		];
		for ( const [ slot, key ] of slots ) {
			const ent = typeof hb[ key ] === 'string' ? hb[ key ] : '';
			if ( ent && ent !== 'none' ) {
				parts.push( `modula-hover-enter--${ slot }--${ ent }` );
			}
		}
		return parts.join( ' ' );
	}
	const effect =
		typeof settings?.effect === 'string' && settings.effect !== ''
			? settings.effect
			: 'none';
	return effect !== 'none' ? `modula-item effect-${ effect }` : 'modula-item';
}

const { __ } = wp.i18n;
const { useState } = wp.element;
const { Button, ButtonGroup } = wp.components;
const { MediaPlaceholder } = wp.blockEditor;

const ModulaDefaultGalleryImage = ( props ) => {
	const [ isEditing, setEditing ] = useState( false );

	const { images, defaultSettings, id, effectCheck } = props.attributes;

	const {
		img,
		index,
		onRemoveImage,
		isFirstItem,
		isLastItem,
		isSelected,
		onSelectImage,
		onMoveBackward,
		onMoveForward,
		setAttributes,
		checkHoverEffect,
	} = props;

	const onReplaceImage = ( image ) => {
		let imagesArray = images;

		let removedImageIndex;
		imagesArray = imagesArray.filter( ( image, index ) => {
			if ( image.id == img.id ) {
				removedImageIndex = index;
			}
			return image.id != img.id;
		} );
		const newImageElement = {
			id: image.id,
			url: image.sizes.full.url,
		};

		imagesArray.splice( removedImageIndex, 0, newImageElement );

		setAttributes( { images: imagesArray } );
		setEditing( false );
	};

	return [
		<div
			className={ buildDefaultBlockItemClasses( defaultSettings ) }
			data-width="2"
			data-height="2"
			key={ 6 }
		>
			<div className="modula-item-overlay" />
			{ isSelected && (
				<ButtonGroup
					style={ {
						zIndex: '21321',
						position: 'absolute',
						display: 'flex',
					} }
				>
					<Button
						className="modula-button button"
						style={ { padding: '20px' } }
						onClick={ isFirstItem ? undefined : onMoveBackward }
					>
						{ icons.chevronLeft }
					</Button>
					<Button
						className="modula-button button"
						style={ { padding: '20px' } }
						onClick={ isLastItem ? undefined : onMoveForward }
					>
						{ icons.chevronRight }
					</Button>
					<Button
						className="modula-button button"
						onClick={ ( e ) => onRemoveImage( e, images ) }
						style={ { padding: '20px' } }
					>
						{ icons.remove }
					</Button>
					<Button
						className={ 'modula-button button' }
						onClick={ () => {
							isEditing === true
								? setEditing( false )
								: setEditing( true );
						} }
						style={ { padding: '20px' } }
					>
						{ icons.replace }
					</Button>
				</ButtonGroup>
			) }

			{ isEditing ? (
				<MediaPlaceholder
					labels={ { title: __( 'Edit gallery image' ) } }
					onSelect={ onReplaceImage }
					accept="image/*"
					allowedTypes={ [ 'image' ] }
					value={ ( img.id, img.url ) }
				/>
			) : (
				<div className="modula-item-content">
					<img
						className={ `modula-image pic` }
						data-id={ img.id }
						data-full={ img.url }
						data-src={ img.url }
						data-valign="middle"
						data-halign="center"
						data-width="2"
						data-height="2"
						src={ img.url }
					/>
					<ModulaDefaultGalleryImageInner
						defaultSettings={ defaultSettings }
						imagesCount={ images.length }
						//selected image will now trigger on click on ModulaDefaultGalleryImageInner
						onSelectImage={ onSelectImage }
						index={ index }
						imageId={ img.id }
						hideTitle={
							undefined != effectCheck &&
							effectCheck.title == true
								? false
								: true
						}
						hideDescription={
							undefined != effectCheck &&
							effectCheck.description == true
								? false
								: true
						}
						hideSocial={
							undefined != effectCheck &&
							effectCheck.social == true
								? false
								: true
						}
						effectCheck={ effectCheck }
					/>
				</div>
			) }
		</div>,
	];
};

export default ModulaDefaultGalleryImage;
