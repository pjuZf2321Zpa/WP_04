/**
 * Internal dependencies
 */
import Inspector from './Inspector';
import ModulaDefaultGallery from './ModulaGallery';
import ModulaSelectControl from './ModulaSelectControl';
import icons from '../utils/icons';

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;
const { Fragment, useEffect, useState } = wp.element;
const { withSelect } = wp.data;
const { Button, Spinner, Toolbar, IconButton } = wp.components;
const { BlockControls } = wp.editor;

export const ModulaDefaultsEdit = ( props ) => {
	const { attributes, setAttributes, defaults, switchBlock, galleries } =
		props;
	const { images, id, status, defaultSettings, jsConfig, galleryId } =
		attributes;
	const [ selectedImage, setSelectedImage ] = useState();
	// useState on preupload event to verify the number of images that will be uploaded so that we will init modula only at the last image
	const [ imageCount, setImageCount ] = useState( 0 );

	useEffect( () => {
		if ( id !== 0 ) {
			onIdChange( id );
		}

		modulaRun();
	}, [] );

	useEffect( () => {
		//Grab the instance and set it as atribute to access it when we want
		jQuery( document ).on(
			'modula_api_after_init',
			function ( event, inst ) {
				props.setAttributes( { instance: inst } );
			}
		);

		if (
			props.attributes.instance != undefined &&
			defaultSettings != undefined &&
			defaultSettings.type == 'grid'
		) {
			props.attributes.instance.reset( props.attributes.instance );
		}
	} );

	const onIdChange = ( id ) => {
		if ( isNaN( id ) || '' == id ) {
			return;
		}
		id = parseInt( id );
		setAttributes( { id, status: 'ready' } );
		//let task = tasks.find(task => task.name === someValue);

		if ( id !== 0 ) {
			getDefaultsSettings( id );
		}
	};

	const getDefaultsSettings = ( id ) => {
		fetch( `${ modulaVars.restURL }wp/v2/modula-defaults/${ id }` )
			.then( ( res ) => res.json() )
			.then( ( result ) => {
				const settings = result;
				setAttributes( {
					currentSelectize: [
						{
							value: id,
							label:
								'' === result.title.rendered
									? `Unnamed`
									: result.title.rendered,
						},
					],
				} );
				setAttributes( { status: 'loading' } );
				jQuery.ajax( {
					type: 'POST',
					data: {
						action: 'modula_get_jsconfig',
						nonce: modulaVars.nonce,
						settings: settings.modulaSettings,
					},
					url: modulaVars.ajaxURL,
					success: ( result ) => {
						const galleryId = Math.floor( Math.random() * 999 );
						setAttributes( {
							galleryId,
							defaultSettings: settings.modulaSettings,
							jsConfig: result,
							status: 'ready',
						} );
					},
				} );
			} );
	};

	const checkHoverEffect = ( effect ) => {
		jQuery.ajax( {
			type: 'POST',
			data: {
				action: 'modula_check_hover_effect',
				nonce: modulaVars.nonce,
				effect,
			},
			url: modulaVars.ajaxURL,
			success: ( result ) => {
				setAttributes( { effectCheck: result } );
			},
		} );
	};

	const modulaRun = ( checker ) => {
		setAttributes( { status: 'ready' } );
		const modulaGalleries = jQuery( '.modula.modula-gallery' );

		jQuery.each( modulaGalleries, function () {
			const modulaID = jQuery( this ).attr( 'id' ),
				modulaSettings = jQuery( this ).data( 'config' );

			jQuery( '#' + modulaID ).modulaGallery( modulaSettings );
		} );
	};

	const selectOptions = ( items ) => {
		if ( undefined == items ) {
			return;
		}
		let options = {};
		if ( items[ 0 ].type == 'modula-defaults' ) {
			options = [
				{
					value: 0,
					label: __( 'select a preset', 'modula-best-grid-gallery' ),
				},
			];
		} else {
			options = [
				{
					value: 0,
					label: __( 'select a gallery', 'modula-best-grid-gallery' ),
				},
			];
		}

		items.forEach( ( gallery ) => {
			if ( gallery.title.rendered.length == 0 ) {
				options.push( {
					value: gallery.id,
					label:
						__( 'Unnamed Gallery', 'modula-best-grid-gallery' ) +
						gallery.id,
				} );
			} else {
				options.push( {
					value: gallery.id,
					label: gallery.title.rendered,
				} );
			}
		} );

		return options;
	};

	const onSelectImages = ( img ) => {
		const selectEvent = true;
		const imagesArray = [ ...images ];

		img.map( ( image ) => {
			imagesArray.push( {
				id: image.id,
				url: image.url,
			} );
		} );
		const imagesIds = imagesArray.map( ( o ) => o.id );
		const imagesFiltered = imagesArray.filter(
			( { id }, index ) => ! imagesIds.includes( id, index + 1 )
		);

		setAttributes( {
			images: imagesFiltered,
			status: 'loading',
		} );
		if ( img.length > 4 ) {
			if ( img[ img.length - 1 ].hasOwnProperty( 'id' ) ) {
				modulaRun( selectEvent );
			}
			if ( img[ img.length - 2 ].hasOwnProperty( 'id' ) ) {
				modulaRun( selectEvent );
			}
			if ( img[ img.length - 3 ].hasOwnProperty( 'id' ) ) {
				modulaRun( selectEvent );
			}
		} else if ( img.length <= 4 ) {
			modulaRun( selectEvent );
		}
	};

	const onSelectImage = ( index ) => {
		return () => {
			setSelectedImage( index );
		};
	};

	const onRemoveImage = ( e ) => {
		e.preventDefault();

		let imagesArray = [ ...images ];
		let removeImageId = '';
		removeImageId = jQuery( jQuery( e.target ).parents()[ 2 ] ).find(
			'img'
		)[ 0 ].dataset.id;
		imagesArray = imagesArray.filter( ( image, index ) => {
			return image.id != removeImageId;
		} );
		setAttributes( {
			images: imagesArray,
		} );

		//status set to loading to force rerender of the gallery to update with new images
		setAttributes( { status: 'loading' } );
		modulaRun();
	};

	const onMove = ( oldIndex, newIndex ) => {
		const newImages = [ ...images ];

		newImages.splice( newIndex, 1, images[ oldIndex ] );
		newImages.splice( oldIndex, 1, images[ newIndex ] );

		setSelectedImage( newIndex );
		props.setAttributes( { images: newImages } );
	};

	const onMoveForward = ( oldIndex ) => {
		return () => {
			if ( oldIndex === images.length - 1 ) {
				return;
			}
			//status set to loading to force rerender of the gallery to update with new images
			setAttributes( { status: 'loading' } );
			onMove( oldIndex, oldIndex + 1 );
			modulaRun();
		};
	};

	const onMoveBackward = ( oldIndex ) => {
		return () => {
			if ( oldIndex === 0 ) {
				return;
			}
			//status set to loading to force rerender of the gallery to update with new images
			setAttributes( { status: 'loading' } );
			onMove( oldIndex, oldIndex - 1 );
			modulaRun();
		};
	};

	const blockControls = (
		<BlockControls>
			<Toolbar>
				<IconButton
					label={ __( 'Edit gallery', 'modula-best-grid-gallery' ) }
					icon="edit"
					href={
						modulaVars.adminURL +
						'post.php?post=' +
						id +
						'&action=edit'
					}
					target="_blank"
				/>
			</Toolbar>
		</BlockControls>
	);

	if ( status === 'loading' ) {
		return [
			<Fragment key={ 2 }>
				<div className="modula-block-preview">
					<div className="modula-block-preview__content">
						<div className="modula-block-preview__logo" />
						<Spinner />
					</div>
				</div>
			</Fragment>,
		];
	}

	if ( id == 0 ) {
		return [
			<Fragment key={ 3 }>
				<Inspector
					onIdChange={ ( id ) => onIdChange( id ) }
					selectOptions={ selectOptions }
					{ ...props }
					switchBlock={ switchBlock }
				/>

				<div className="modula-block-preview">
					<div className="modula-block-preview__content">
						<div className="modula-block-preview__logo" />
						{ defaults.length === 0 && (
							<Fragment>
								<p>
									{ __(
										"You don't seem to have any galleries.",
										'modula-best-grid-gallery'
									) }
								</p>
								<Button
									className="modula-button"
									href={
										modulaVars.adminURL +
										'post-new.php?post_type=modula-defaults'
									}
									target="_blank"
								>
									{ __(
										'Add New Gallery',
										'modula-best-grid-gallery'
									) }
									{ icons.chevronRightFancy }
								</Button>
							</Fragment>
						) }
						{ defaults.length > 0 && (
							<Fragment>
								<Fragment>
									<ModulaSelectControl
										className={ 'modula-defaults-input' }
										placeholder={ __(
											'Search for a preset…',
											'modula-best-grid-gallery'
										) }
										value={ id }
										ajax={ true }
										ajaxAction={ 'modula_get_defaults' }
										onChangeFunction={ onIdChange }
										options={
											props.attributes.currentSelectize
										}
										defaults={ defaults }
										galleries={ galleries }
									/>
								</Fragment>
								{ id != 0 && (
									<Button
										target="_blank"
										href={
											modulaVars.adminURL +
											'post.php?post=' +
											id +
											'&action=edit'
										}
										isPrimary
									>
										{ __( 'Edit Gallery' ) }
									</Button>
								) }
							</Fragment>
						) }
					</div>
				</div>
			</Fragment>,
		];
	}
	if ( defaultSettings ) {
		return [
			<Fragment key={ 4 }>
				{ blockControls }
				<Inspector
					onIdChange={ ( id ) => onIdChange( id ) }
					switchBlock={ switchBlock }
					selectOptions={ selectOptions }
					{ ...props }
				/>
				<ModulaDefaultGallery
					{ ...props }
					onSelectImages={ onSelectImages }
					onRemoveImage={ onRemoveImage }
					onSelectImage={ onSelectImage }
					selectedImage={ selectedImage }
					onMoveBackward={ onMoveBackward }
					onMoveForward={ onMoveForward }
					defaultSettings={ defaultSettings }
					jsConfig={ jsConfig }
					modulaRun={ modulaRun }
					checkHoverEffect={ checkHoverEffect }
					galleryId={ galleryId }
					setImageCount={ setImageCount }
					imageCount={ imageCount }
				/>
			</Fragment>,
		];
	}

	return null;
};

export default withSelect( ( select, props ) => {
	const { getEntityRecords } = select( 'core' );
	const query = {
		post_status: 'publish',
		per_page: 5,
	};

	return {
		defaults:
			getEntityRecords( 'postType', 'modula-defaults', query ) || [],
	};
} )( ModulaDefaultsEdit );
