import ModulaSelectControl from './ModulaSelectControl';

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { InspectorControls } = wp.editor;
const { Button, PanelBody } = wp.components;

/**
 * Inspector controls
 * @param props
 */
const Inspector = ( props ) => {
	const { onIdChange } = props;
	const { attributes, defaults, galleries } = props;
	const { id, galleryType } = attributes;
	return (
		<Fragment>
			<InspectorControls>
				<PanelBody
					title={ __(
						'Gallery Settings',
						'modula-best-grid-gallery'
					) }
					initialOpen={ true }
				>
					<ModulaSelectControl
						className="modula-gallery-type-select"
						placeholder="Select type..."
						value={ galleryType }
						options={ [
							{ value: 'gallery', label: 'Gallery' },
							{ value: 'defaults', label: 'Presets' },
						] }
						onChangeFunction={ props.switchBlock }
						ajax={ false }
						label={ __( 'Select type' ) }
					/>

					{ 'defaults' == galleryType && (
						<Fragment>
							{ defaults.length === 0 && (
								<Fragment>
									<p>
										{ __(
											"You don't seem to have any galleries."
										) }
									</p>
									<Button
										href={
											modulaVars.adminURL +
											'post-new.php?post_type=modula-gallery'
										}
										target="_blank"
										isSecondary
									>
										{ __(
											'Add New Gallery',
											'modula-best-grid-gallery'
										) }
									</Button>
								</Fragment>
							) }
							{ defaults.length > 0 && (
								<Fragment>
									<ModulaSelectControl
										className={ 'modula-defaults-input' }
										placeholder={ __(
											'Select Preset',
											'modula-best-grid-gallery'
										) }
										options={
											props.attributes.currentSelectize
										}
										value={ id }
										ajax={ true }
										ajaxAction={ 'modula_get_defaults' }
										onChangeFunction={ onIdChange }
										label={ __( 'Select preset' ) }
										defaults={ defaults }
										galleries={ galleries }
									/>
								</Fragment>
							) }
						</Fragment>
					) }

					{ 'gallery' == galleryType && (
						<ModulaSelectControl
							className={ 'modula-gallery-input' }
							placeholder={ __(
								'Select Gallery',
								'modula-best-grid-gallery'
							) }
							value={ id }
							ajax={ true }
							options={ props.attributes.currentSelectize }
							ajaxAction={ 'modula_get_gallery' }
							onChange={ onIdChange }
							label={ __( 'Select gallery' ) }
							galleries={ galleries }
						/>
					) }
					{ id != 0 && (
						<Button
							target="_blank"
							href={
								modulaVars.adminURL +
								'post.php?post=' +
								id +
								'&action=edit'
							}
							isPrimary
						>
							{ __( 'Edit gallery' ) }
						</Button>
					) }
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
};

export default Inspector;
