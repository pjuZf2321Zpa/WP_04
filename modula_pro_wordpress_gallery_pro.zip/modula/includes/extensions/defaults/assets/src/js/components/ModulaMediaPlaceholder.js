const { MediaPlaceholder } = wp.blockEditor;
const { __ } = wp.i18n;

const ModulaMediaPlaceholder = ( props ) => {
	const { imageCount, onSelectImages, images, setImageCount } = props;

	if ( images.length == 0 ) {
		return [
			<MediaPlaceholder
				key={ 10 }
				onSelect={ ( images ) => {
					onSelectImages( images );
				} }
				allowedTypes={ [ 'image' ] }
				onFilesPreUpload={ ( files ) => {
					setImageCount( files.length );
				} }
				addToGallery={ false }
				multiple={ 'add' }
				value={ images }
				labels={ {
					title: __( 'Modula Gallery', 'modula-defaults' ),
					instructions: __(
						'Drag images, upload new ones or select files from your library',
						'modula-defaults'
					),
				} }
			/>,
		];
	}
	return [
		<MediaPlaceholder
			key={ 9 }
			onSelect={ ( images ) => onSelectImages( images ) }
			allowedTypes={ [ 'image' ] }
			className="modula-appender-media"
			addToGallery={ false }
			isAppender={ true }
			style={ { height: '60px' } }
			multiple={ 'add' }
			value={ images }
			labels={ {
				title: '',
				instructions: __( '' ),
			} }
		/>,
	];
};

export default ModulaMediaPlaceholder;
