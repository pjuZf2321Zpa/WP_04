! ( function ( e ) {
	const t = {};
	function a( l ) {
		if ( t[ l ] ) {
			return t[ l ].exports;
		}
		const n = ( t[ l ] = { i: l, l: ! 1, exports: {} } );
		return (
			e[ l ].call( n.exports, n, n.exports, a ), ( n.l = ! 0 ), n.exports
		);
	}
	( a.m = e ),
		( a.c = t ),
		( a.d = function ( e, t, l ) {
			a.o( e, t ) ||
				Object.defineProperty( e, t, { enumerable: ! 0, get: l } );
		} ),
		( a.r = function ( e ) {
			'undefined' !== typeof Symbol &&
				Symbol.toStringTag &&
				Object.defineProperty( e, Symbol.toStringTag, {
					value: 'Module',
				} ),
				Object.defineProperty( e, '__esModule', { value: ! 0 } );
		} ),
		( a.t = function ( e, t ) {
			if ( ( 1 & t && ( e = a( e ) ), 8 & t ) ) {
				return e;
			}
			if ( 4 & t && 'object' === typeof e && e && e.__esModule ) {
				return e;
			}
			const l = Object.create( null );
			if (
				( a.r( l ),
				Object.defineProperty( l, 'default', {
					enumerable: ! 0,
					value: e,
				} ),
				2 & t && 'string' !== typeof e )
			) {
				for ( const n in e ) {
					a.d(
						l,
						n,
						function ( t ) {
							return e[ t ];
						}.bind( null, n )
					);
				}
			}
			return l;
		} ),
		( a.n = function ( e ) {
			const t =
				e && e.__esModule
					? function () {
							return e.default;
					  }
					: function () {
							return e;
					  };
			return a.d( t, 'a', t ), t;
		} ),
		( a.o = function ( e, t ) {
			return Object.prototype.hasOwnProperty.call( e, t );
		} ),
		( a.p = '' ),
		a( ( a.s = 0 ) );
} )( [
	function ( e, t, a ) {
		'use strict';
		a.r( t );
		const l = wp.element.useEffect,
			n = function ( e ) {
				const t = e.className,
					a = e.options,
					n = e.placeholder,
					o = e.value,
					c = e.ajax,
					r = e.defaults,
					i = e.galleries,
					u = e.ajaxAction,
					d = void 0 !== e.onChange ? e.onChange : e.onChangeFunction;
				return (
					l(
						function () {
							const e = [],
								l = [];
							null != r &&
								0 == e.length &&
								r.forEach( function ( t ) {
									e.push( {
										value: t.id,
										label: t.title.rendered,
									} );
								} ),
								null != i &&
									0 == l.length &&
									i.forEach( function ( e ) {
										l.push( {
											value: e.id,
											label: e.title.rendered,
										} );
									} );
							0 == c
								? jQuery( '.'.concat( t ) ).selectize( {
										valueField: 'value',
										labelField: 'label',
										searchField: [ 'label', 'value' ],
										create: ! 1,
										maxItems: 1,
										options: a,
										placeholder: n,
										preload: ! 0,
										allowEmptyOptions: ! 0,
										closeAfterSelect: ! 0,
										onChange( e ) {
											d( e );
										},
								  } )
								: jQuery( '.'.concat( t ) ).selectize( {
										valueField: 'value',
										labelField: 'label',
										searchField: [ 'label', 'value' ],
										create: ! 1,
										maxItems: 1,
										placeholder: n,
										preload: ! 0,
										options:
											'modula_get_defaults' == u ? e : l,
										allowEmptyOptions: ! 0,
										closeAfterSelect: ! 0,
										render: {
											option( e, t ) {
												return (
													'<div><span class="title"><span class="name">' +
													t( e.label ) +
													'</span></div>'
												);
											},
										},
										load( e, t ) {
											if ( ! e.length ) {
												return t();
											}
											jQuery.ajax( {
												url: modulaDefaultsVars.ajaxURL,
												type: 'GET',
												data: {
													action: u,
													nonce: modulaDefaultsVars.nonce,
													term: e,
												},
												success( e ) {
													t( e.slice( 0, 10 ) );
												},
											} );
										},
										onChange( e ) {
											d( e );
										},
								  } );
						},
						[ r, i ]
					),
					[
						React.createElement(
							'div',
							{ key: 13, className: 'modula-inspector-select' },
							React.createElement( 'label', null, ' ', e.label ),
							React.createElement( 'input', {
								className: t,
								defaultValue: o,
							} )
						),
					]
				);
			},
			o = wp.i18n.__,
			c = wp.element.Fragment,
			r = wp.editor.InspectorControls,
			i = wp.components,
			u = i.Button,
			d = i.PanelBody,
			s = function ( e ) {
				const t = e.onIdChange,
					a = e.attributes,
					l = e.defaults,
					i = e.galleries,
					s = a.id,
					m = a.galleryType;
				return React.createElement(
					c,
					null,
					React.createElement(
						r,
						null,
						React.createElement(
							d,
							{
								title: o(
									'Gallery Settings',
									'modula-best-grid-gallery'
								),
								initialOpen: ! 0,
							},
							React.createElement( n, {
								className: 'modula-gallery-type-select',
								placeholder: 'Select type...',
								value: m,
								options: [
									{ value: 'gallery', label: 'Gallery' },
									{ value: 'defaults', label: 'Presets' },
								],
								onChangeFunction: e.switchBlock,
								ajax: ! 1,
								label: o( 'Select type' ),
							} ),
							'defaults' == m &&
								React.createElement(
									c,
									null,
									0 === l.length &&
										React.createElement(
											c,
											null,
											React.createElement(
												'p',
												null,
												o(
													"You don't seem to have any galleries."
												)
											),
											React.createElement(
												u,
												{
													href:
														modulaVars.adminURL +
														'post-new.php?post_type=modula-gallery',
													target: '_blank',
													isSecondary: ! 0,
												},
												o(
													'Add New Gallery',
													'modula-best-grid-gallery'
												)
											)
										),
									l.length > 0 &&
										React.createElement(
											c,
											null,
											React.createElement( n, {
												className:
													'modula-defaults-input',
												placeholder: o(
													'Select Preset',
													'modula-best-grid-gallery'
												),
												options:
													e.attributes
														.currentSelectize,
												value: s,
												ajax: ! 0,
												ajaxAction:
													'modula_get_defaults',
												onChangeFunction: t,
												label: o( 'Select preset' ),
												defaults: l,
												galleries: i,
											} )
										)
								),
							'gallery' == m &&
								React.createElement( n, {
									className: 'modula-gallery-input',
									placeholder: o(
										'Select Gallery',
										'modula-best-grid-gallery'
									),
									value: s,
									ajax: ! 0,
									options: e.attributes.currentSelectize,
									ajaxAction: 'modula_get_gallery',
									onChange: t,
									label: o( 'Select gallery' ),
									galleries: i,
								} ),
							0 != s &&
								React.createElement(
									u,
									{
										target: '_blank',
										href:
											modulaVars.adminURL +
											'post.php?post=' +
											s +
											'&action=edit',
										isPrimary: ! 0,
									},
									o( 'Edit gallery' )
								)
						)
					)
				);
			},
			m = {};
		( m.modula = React.createElement(
			'svg',
			{
				xmlns: 'http://www.w3.org/2000/svg',
				x: '0px',
				y: '0px',
				viewBox: '364 242.9 312.2 357',
			},
			React.createElement(
				'g',
				null,
				React.createElement( 'path', {
					d: 'M528.1,242.9c8.5,16.9,17,33.8,25.6,50.6c13.4,26.4,26.9,52.7,39.9,79.7c-41.8-23.3-83.6-46.7-125.4-70.1 c0.3-1.9,1.7-2.6,2.7-3.5c17.7-17.7,35.4-35.4,53.1-53c1.1-1.1,2.6-2,3.1-3.7C527.4,242.9,527.8,242.9,528.1,242.9z',
				} ),
				React.createElement( 'path', {
					d: 'M602.3,463.3c11.3-6.9,22.6-13.9,33.9-20.8c5.5-3.4,11.1-6.7,16.5-10.3c2.2-1.4,2.9-1.1,3.5,1.5 c6.4,25.3,13,50.6,19.6,75.8c0.6,2.2,1,3.7-2.4,3.5c-46.7-2.1-93.5-4.1-140.2-6.1c-0.2,0-0.3-0.1-0.5-0.2c0.5-1.7,2.1-2,3.3-2.7 c20-12.3,39.9-24.7,60-36.8c3.4-2.1,5.1-3.7,4.8-8.5c-1.4-21.3-1.8-42.6-2.6-63.9c-0.9-24.1-1.8-48.3-2.8-72.4 c-0.2-6.1-0.2-6.1,5.5-4.6c23.8,6.2,47.6,12.5,71.5,18.5c3.9,1,4.2,1.9,2.1,5.4c-23.4,38.5-46.7,77.1-70,115.7c-1,1.7-2,3.4-3,5.1 C601.7,462.8,602,463,602.3,463.3z',
				} ),
				React.createElement( 'path', {
					d: 'M372.8,326.9c48,2.6,95.8,5.1,143.9,7.7c-0.9,2-2.5,2.3-3.7,3.1c-38.6,23.2-77.3,46.4-115.9,69.6c-3,1.8-4.3,2.6-5.4-1.9 c-5.9-24.9-12.2-49.7-18.3-74.6C373.1,329.6,373,328.4,372.8,326.9z',
				} ),
				React.createElement( 'path', {
					d: 'M517.6,599.9c-23.2-43.7-45.9-86.6-69.2-130.5c2.3,1.2,3.5,1.8,4.7,2.4c39.8,21.5,79.5,43.1,119.3,64.5 c3.2,1.7,4.1,2.5,1,5.6c-17.7,17.8-35.2,35.9-52.8,53.9C519.7,596.9,518.9,598.2,517.6,599.9z',
				} ),
				React.createElement( 'path', {
					d: 'M364.9,505.1c26.6-40.5,53.1-80.8,79.7-121.3c1.3,1.3,0.9,2.5,0.9,3.6c0,46-0.1,92-0.1,137.9c0,3.1-0.2,4.5-4,3.3 c-24.9-7.7-49.9-15.2-74.9-22.8C366,505.8,365.7,505.5,364.9,505.1z',
				} )
			)
		) ),
			( m.remove = React.createElement(
				'svg',
				{
					width: '24',
					height: '24',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 24 24',
					role: 'img',
					'aria-hidden': 'true',
					focusable: 'false',
				},
				React.createElement( 'path', {
					d: 'M13 11.9l3.3-3.4-1.1-1-3.2 3.3-3.2-3.3-1.1 1 3.3 3.4-3.5 3.6 1 1L12 13l3.5 3.5 1-1z',
				} )
			) ),
			( m.replace = React.createElement(
				'svg',
				{
					width: '24',
					height: '24',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 24 24',
					role: 'img',
					'aria-hidden': 'true',
					focusable: 'false',
				},
				React.createElement( 'path', {
					d: 'M20.1 5.1L16.9 2 6.2 12.7l-1.3 4.4 4.5-1.3L20.1 5.1zM4 20.8h8v-1.5H4v1.5z',
				} )
			) ),
			( m.chevronLeft = React.createElement(
				'svg',
				{
					width: '24',
					height: '24',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 24 24',
					role: 'img',
					'aria-hidden': 'true',
					focusable: 'false',
				},
				React.createElement( 'path', {
					d: 'M14.6 7l-1.2-1L8 12l5.4 6 1.2-1-4.6-5z',
				} )
			) ),
			( m.chevronRight = React.createElement(
				'svg',
				{
					width: '24',
					height: '24',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 24 24',
					role: 'img',
					'aria-hidden': 'true',
					focusable: 'false',
				},
				React.createElement( 'path', {
					d: 'M10.6 6L9.4 7l4.6 5-4.6 5 1.2 1 5.4-6z',
				} )
			) ),
			( m.twitter = React.createElement(
				'svg',
				{
					'aria-hidden': 'true',
					'data-prefix': 'fab',
					'data-icon': 'twitter',
					className: 'svg-inline--fa fa-twitter fa-w-16',
					role: 'img',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 512 512',
				},
				React.createElement( 'path', {
					fill: 'currentColor',
					d: 'M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z',
				} )
			) ),
			( m.facebook = React.createElement(
				'svg',
				{
					'aria-hidden': 'true',
					'data-prefix': 'fab',
					'data-icon': 'facebook-f',
					className: 'svg-inline--fa fa-facebook-f fa-w-9',
					role: 'img',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 264 512',
				},
				React.createElement( 'path', {
					fill: 'currentColor',
					d: 'M76.7 512V283H0v-91h76.7v-71.7C76.7 42.4 124.3 0 193.8 0c33.3 0 61.9 2.5 70.2 3.6V85h-48.2c-37.8 0-45.1 18-45.1 44.3V192H256l-11.7 91h-73.6v229',
				} )
			) ),
			( m.whatsapp = React.createElement(
				'svg',
				{
					'aria-hidden': 'true',
					focusable: 'false',
					preserveAspectRatio: 'xMidYMid meet',
					viewBox: '0 0 1536 1600',
				},
				React.createElement( 'path', {
					d: 'M985 878q13 0 97.5 44t89.5 53q2 5 2 15q0 33-17 76q-16 39-71 65.5T984 1158q-57 0-190-62q-98-45-170-118T476 793q-72-107-71-194v-8q3-91 74-158q24-22 52-22q6 0 18 1.5t19 1.5q19 0 26.5 6.5T610 448q8 20 33 88t25 75q0 21-34.5 57.5T599 715q0 7 5 15q34 73 102 137q56 53 151 101q12 7 22 7q15 0 54-48.5t52-48.5zm-203 530q127 0 243.5-50t200.5-134t134-200.5t50-243.5t-50-243.5T1226 336t-200.5-134T782 152t-243.5 50T338 336T204 536.5T154 780q0 203 120 368l-79 233l242-77q158 104 345 104zm0-1382q153 0 292.5 60T1315 247t161 240.5t60 292.5t-60 292.5t-161 240.5t-240.5 161t-292.5 60q-195 0-365-94L0 1574l136-405Q28 991 28 780q0-153 60-292.5T249 247T489.5 86T782 26z',
					fill: 'currentColor',
				} )
			) ),
			( m.pinterest = React.createElement(
				'svg',
				{
					'aria-hidden': 'true',
					'data-prefix': 'fab',
					'data-icon': 'pinterest-p',
					className: 'svg-inline--fa fa-pinterest-p fa-w-12',
					role: 'img',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 384 512',
				},
				React.createElement( 'path', {
					fill: 'currentColor',
					d: 'M204 6.5C101.4 6.5 0 74.9 0 185.6 0 256 39.6 296 63.6 296c9.9 0 15.6-27.6 15.6-35.4 0-9.3-23.7-29.1-23.7-67.8 0-80.4 61.2-137.4 140.4-137.4 68.1 0 118.5 38.7 118.5 109.8 0 53.1-21.3 152.7-90.3 152.7-24.9 0-46.2-18-46.2-43.8 0-37.8 26.4-74.4 26.4-113.4 0-66.2-93.9-54.2-93.9 25.8 0 16.8 2.1 35.4 9.6 50.7-13.8 59.4-42 147.9-42 209.1 0 18.9 2.7 37.5 4.5 56.4 3.4 3.8 1.7 3.4 6.9 1.5 50.4-69 48.6-82.5 71.4-172.8 12.3 23.4 44.1 36 69.3 36 106.2 0 153.9-103.5 153.9-196.8C384 71.3 298.2 6.5 204 6.5z',
				} )
			) ),
			( m.linkedin = React.createElement(
				'svg',
				{
					'aria-hidden': 'true',
					focusable: 'false',
					'data-prefix': 'fab',
					'data-icon': 'linkedin-in',
					className: 'svg-inline--fa fa-linkedin-in fa-w-14',
					role: 'img',
					xmlns: 'http://www.w3.org/2000/svg',
					viewBox: '0 0 448 512',
				},
				React.createElement( 'path', {
					fill: 'currentColor',
					d: 'M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z',
				} )
			) ),
			( m.email = React.createElement(
				'svg',
				{
					xmlns: 'http://www.w3.org/2000/svg',
					width: '24',
					height: '24',
					viewBox: '0 0 24 24',
				},
				React.createElement( 'path', {
					d: 'M0 3v18h24v-18h-24zm6.623 7.929l-4.623 5.712v-9.458l4.623 3.746zm-4.141-5.929h19.035l-9.517 7.713-9.518-7.713zm5.694 7.188l3.824 3.099 3.83-3.104 5.612 6.817h-18.779l5.513-6.812zm9.208-1.264l4.616-3.741v9.348l-4.616-5.607z',
					fill: 'currentColor',
				} )
			) ),
			( m.chevronRightFancy = React.createElement(
				'svg',
				{
					xmlns: 'http://www.w3.org/2000/svg',
					width: '16',
					height: '16',
					fill: 'currentColor',
					className: 'bi bi-chevron-right',
					viewBox: '0 0 16 16',
				},
				React.createElement( 'path', {
					fillRule: 'evenodd',
					d: 'M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z',
				} )
			) ),
			( m.chevronLeftFancy = React.createElement(
				'svg',
				{
					xmlns: 'http://www.w3.org/2000/svg',
					width: '16',
					height: '16',
					fill: 'currentColor',
					className: 'bi bi-chevron-left',
					viewBox: '0 0 16 16',
				},
				React.createElement( 'path', {
					fillRule: 'evenodd',
					d: 'M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z',
				} )
			) );
		const g = m,
			f = wp.data.useSelect,
			p = wp.element.Fragment,
			h = function ( e ) {
				const t = e.defaultSettings,
					a = e.onSelectImage,
					l = e.index,
					n = e.imageId,
					o = e.hideTitle,
					c = e.hideDescription,
					r = e.hideSocial,
					i = f(
						function ( e ) {
							return e( 'core' ).getMedia( n );
						},
						[ a ]
					),
					u = [
						'lily',
						'sadie',
						'ruby',
						'bubba',
						'dexter',
						'chico',
						'ming',
					];
				return React.createElement(
					p,
					{ key: 8 },
					[ 'tilt_1', 'tilt_3', 'tilt_7' ].includes( t.effect ) &&
						React.createElement(
							'div',
							{ className: 'tilter__deco tilter__deco--shine' },
							React.createElement( 'div', null )
						),
					[ 'tilt_3', 'tilt_7' ].includes( t.effect ) &&
						React.createElement( 'div', {
							className: 'tilter__deco tilter__deco--overlay',
						} ),
					[ 'tilt_1', 'tilt_7' ].includes( t.effect ) &&
						React.createElement( 'div', {
							className: 'tilter__deco tilter__deco--lines',
						} ),
					React.createElement(
						'div',
						{ className: 'figc', onClick: a( l ), onFocus: a( l ) },
						React.createElement(
							'div',
							{ className: 'figc-inner' },
							! o &&
								React.createElement(
									'h2',
									{
										className: u.includes( t.effect )
											? ''
											: 'jtg-title',
									},
									' ',
									null != i && i.title.rendered,
									' '
								),
							React.createElement(
								'div',
								{
									className: u.includes( t.effect )
										? 'jtg-body'
										: '',
								},
								! c &&
									React.createElement(
										'p',
										{ className: 'description' },
										' ',
										null != i && i.caption.raw,
										' '
									),
								! r &&
									'1' == t.enableSocial &&
									React.createElement(
										'div',
										{ className: 'jtg-social' },
										'1' == t.enableTwitter &&
											React.createElement(
												'a',
												{
													className:
														'modula-icon-twitter',
													href: '#',
												},
												' ',
												'$',
												g.twitter,
												' '
											),
										'1' == t.enableFacebook &&
											React.createElement(
												'a',
												{
													className:
														'modula-icon-facebook',
													href: '#',
												},
												' ',
												'$',
												g.facebook,
												' '
											),
										'1' == t.enableWhatsapp &&
											React.createElement(
												'a',
												{
													className:
														'modula-icon-whatsapp',
													href: '#',
												},
												' ',
												'$',
												g.whatsapp,
												' '
											),
										'1' == t.enableLinkedin &&
											React.createElement(
												'a',
												{
													className:
														'modula-icon-linkedin',
													href: '#',
												},
												' ',
												'$',
												g.linkedin,
												' '
											),
										'1' == t.enablePinterest &&
											React.createElement(
												'a',
												{
													className:
														'modula-icon-pinterest',
													href: '#',
												},
												' ',
												'$',
												g.pinterest,
												' '
											),
										'1' == t.enableEmail &&
											React.createElement(
												'a',
												{
													className:
														'modula-icon-email',
													href: '#',
												},
												' ',
												'$',
												g.email,
												' '
											)
									)
							)
						)
					)
				);
			};
		function y( e, t ) {
			return (
				( function ( e ) {
					if ( Array.isArray( e ) ) {
						return e;
					}
				} )( e ) ||
				( function ( e, t ) {
					let a =
						null == e
							? null
							: ( 'undefined' !== typeof Symbol &&
									e[ Symbol.iterator ] ) ||
							  e[ '@@iterator' ];
					if ( null != a ) {
						let l,
							n,
							o,
							c,
							r = [],
							i = ! 0,
							u = ! 1;
						try {
							if (
								( ( o = ( a = a.call( e ) ).next ), 0 === t )
							) {
								if ( Object( a ) !== a ) {
									return;
								}
								i = ! 1;
							} else {
								for (
									;
									! ( i = ( l = o.call( a ) ).done ) &&
									( r.push( l.value ), r.length !== t );
									i = ! 0
								) {}
							}
						} catch ( e ) {
							( u = ! 0 ), ( n = e );
						} finally {
							try {
								if (
									! i &&
									null != a.return &&
									( ( c = a.return() ), Object( c ) !== c )
								) {
									return;
								}
							} finally {
								if ( u ) {
									throw n;
								}
							}
						}
						return r;
					}
				} )( e, t ) ||
				( function ( e, t ) {
					if ( ! e ) {
						return;
					}
					if ( 'string' === typeof e ) {
						return v( e, t );
					}
					let a = Object.prototype.toString.call( e ).slice( 8, -1 );
					'Object' === a &&
						e.constructor &&
						( a = e.constructor.name );
					if ( 'Map' === a || 'Set' === a ) {
						return Array.from( e );
					}
					if (
						'Arguments' === a ||
						/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test( a )
					) {
						return v( e, t );
					}
				} )( e, t ) ||
				( function () {
					throw new TypeError(
						'Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.'
					);
				} )()
			);
		}
		function v( e, t ) {
			( null == t || t > e.length ) && ( t = e.length );
			for ( var a = 0, l = new Array( t ); a < t; a++ ) {
				l[ a ] = e[ a ];
			}
			return l;
		}
		const b = wp.i18n.__,
			w = wp.element.useState,
			E = wp.components,
			R = E.Button,
			j = E.ButtonGroup,
			S = wp.blockEditor.MediaPlaceholder,
			x = function ( e ) {
				const t = y( w( ! 1 ), 2 ),
					a = t[ 0 ],
					l = t[ 1 ],
					n = e.attributes,
					o = n.images,
					c = n.defaultSettings,
					r = ( n.id, n.effectCheck ),
					i = e.img,
					u = e.index,
					d = e.onRemoveImage,
					s = e.isFirstItem,
					m = e.isLastItem,
					f = e.isSelected,
					p = e.onSelectImage,
					v = e.onMoveBackward,
					E = e.onMoveForward,
					x = e.setAttributes;
				e.checkHoverEffect;
				return [
					React.createElement(
						'div',
						{
							className: 'modula-item effect-'.concat( c.effect ),
							'data-width': '2',
							'data-height': '2',
							key: 6,
						},
						React.createElement( 'div', {
							className: 'modula-item-overlay',
						} ),
						f &&
							React.createElement(
								j,
								{
									style: {
										zIndex: '21321',
										position: 'absolute',
										display: 'flex',
									},
								},
								React.createElement(
									R,
									{
										className: 'modula-button button',
										style: { padding: '20px' },
										onClick: s ? void 0 : v,
									},
									g.chevronLeft
								),
								React.createElement(
									R,
									{
										className: 'modula-button button',
										style: { padding: '20px' },
										onClick: m ? void 0 : E,
									},
									g.chevronRight
								),
								React.createElement(
									R,
									{
										className: 'modula-button button',
										onClick( e ) {
											return d( e, o );
										},
										style: { padding: '20px' },
									},
									g.remove
								),
								React.createElement(
									R,
									{
										className: 'modula-button button',
										onClick() {
											l( ! 0 !== a );
										},
										style: { padding: '20px' },
									},
									g.replace
								)
							),
						a
							? React.createElement( S, {
									labels: {
										title: b( 'Edit gallery image' ),
									},
									onSelect( e ) {
										let t,
											a = o;
										a = a.filter( function ( e, a ) {
											return (
												e.id == i.id && ( t = a ),
												e.id != i.id
											);
										} );
										const n = {
											id: e.id,
											url: e.sizes.full.url,
										};
										a.splice( t, 0, n ),
											x( { images: a } ),
											l( ! 1 );
									},
									accept: 'image/*',
									allowedTypes: [ 'image' ],
									value: ( i.id, i.url ),
							  } )
							: React.createElement(
									'div',
									{ className: 'modula-item-content' },
									React.createElement( 'img', {
										className: 'modula-image pic',
										'data-id': i.id,
										'data-full': i.url,
										'data-src': i.url,
										'data-valign': 'middle',
										'data-halign': 'center',
										'data-width': '2',
										'data-height': '2',
										src: i.url,
									} ),
									React.createElement( h, {
										defaultSettings: c,
										imagesCount: o.length,
										onSelectImage: p,
										index: u,
										imageId: i.id,
										hideTitle: null == r || 1 != r.title,
										hideDescription:
											null == r || 1 != r.description,
										hideSocial: null == r || 1 != r.social,
										effectCheck: r,
									} )
							  )
					),
				];
			},
			k = function ( e ) {
				let t = e.id,
					a = e.settings,
					l = '';
				'grid' == a.type &&
					'automatic' != a.grid_type &&
					( l += '#jtg-'
						.concat(
							t,
							'.modula-gallery .modula-item, .modula-gallery .modula-grid-sizer { width: calc('
						)
						.concat( 100 / a.grid_type, '% - ' )
						.concat(
							a.gutter - a.gutter / a.grid_type,
							'px) !important}'
						) ),
					'0' != a.borderSize &&
						( l += '#jtg-'
							.concat( t, ' .modula-item {\n\t\t\tborder: ' )
							.concat( a.borderSize, 'px solid ' )
							.concat( a.borderColor, ';\n\t\t}' ) ),
					'0' != a.borderRadius &&
						( l += '#jtg-'
							.concat(
								t,
								' .modula-item {\n\t\t\tborder-radius: '
							)
							.concat( a.borderRadius, 'px;\n\t\t}' ) ),
					'0' != a.shadowSize &&
						( l += '#jtg-'
							.concat( t, ' .modula-item {\n\t\t\tbox-shadow: ' )
							.concat( a.shadowColor, ' 0px 0px ' )
							.concat( a.shadowSize, 'px;\n\t\t}' ) ),
					'#ffffff' != a.socialIconColor &&
						( l += '#jtg-'
							.concat(
								t,
								' .modula-item .jtg-social a {\n\t\t\tcolor: '
							)
							.concat( a.socialIconColor, ';\n\t\t}' ) ),
					'16' != a.socialIconSize &&
						( l += '#jtg-'
							.concat(
								t,
								' .modula-item .jtg-social svg {\n\t\t\theight: '
							)
							.concat( a.socialIconSize, 'px;\n\t\t\twidth: ' )
							.concat( a.socialIconSize, 'px;\n\t\t}' ) ),
					'10' != a.socialIconPadding &&
						( l += '#jtg-'
							.concat(
								t,
								' .modula-item .jtg-social a:not(:last-child) {\n\t\t\tmargin-right: '
							)
							.concat( a.socialIconPadding, 'px;\n\t\t}' ) ),
					( l += '#jtg-'
						.concat(
							t,
							' .modula-item .caption {\n\t\tbackground-color: '
						)
						.concat( a.captionColor, ';\n\t}' ) ),
					'' != a.captionColor &&
						( l += '#jtg-'
							.concat( t, ' .modula-item .figc {\n\t\t\tcolor: ' )
							.concat( a.captionColor, ';\n\t\t}' ) ),
					'' != a.titleFontSize &&
						'0' != a.titleFontSize &&
						( l += '#jtg-'
							.concat(
								t,
								' .modula-item .figc .jtg-title {\n\t\t\tfont-size: '
							)
							.concat( a.titleFontSize, 'px;\n\t\t}' ) ),
					'' != a.captionFontSize &&
						'0' != a.captionFontSize &&
						( l += '#jtg-'
							.concat(
								t,
								' .modula-item .figc p.description {\n\t\t\tfont-size: '
							)
							.concat( a.captionFontSize, 'px;\n\t\t}' ) ),
					( l += '#jtg-'
						.concat(
							t,
							' .modula-items .figc p.description {\n\t\t\tcolor: '
						)
						.concat( a.captionColor, ';\n\t}' ) ),
					'' != a.titleColor
						? ( l += '#jtg-'
								.concat(
									t,
									' .modula-items .figc .jtg-title {\n\t\t\tcolor: '
								)
								.concat( a.titleColor, ';\n\t\t}' ) )
						: ( l += '#jtg-'
								.concat(
									t,
									' .modula-items .figc .jtg-title {\n\t\t\tcolor: '
								)
								.concat( a.captionColor, ';\n\t\t}' ) ),
					( l += '#jtg-'
						.concat( t, '.modula-gallery .modula-item > a, #jtg-' )
						.concat( t, '.modula-gallery .modula-item, #jtg-' )
						.concat(
							t,
							'.modula-gallery .modula-item-content > a  {\n\t\tcursor: '
						)
						.concat( a.cursor, ';\n\t}' ) ),
					( l += '#jtg-'.concat(
						t,
						'.modula-gallery .modula-item .modula-item-content { opacity:1; }'
					) ),
					'custom-grid' != a.type &&
						( ( l += '#jtg-'
							.concat( t, ' {\n\t\twidth: ' )
							.concat(
								a.width,
								';\n\t\tmargin : 0 auto;\n\t\t}'
							) ),
						0 == e.imagesCount
							? ( l += '#jtg-'.concat(
									t,
									' .modula-items {\n\t\t\t\theight: 100px;\n\t\t\t}'
							  ) )
							: 'grid' != a.type &&
							  ( l += '#jtg-'
									.concat(
										t,
										' .modula-items {\n\t\t\t\theight: '
									)
									.concat( a.height, ';\n\t\t\t}' ) ) ),
					null != a.style &&
						0 != a.style.length &&
						( l += ''.concat( a.style ) );
				let n = '';
				return (
					'' != a.mobileTitleFontSize &&
						0 != a.mobileTitleFontSize &&
						( n += '#jtg-'
							.concat(
								t,
								' .modula-item .figc .jtg-title {\n\t\t\tfont-size: '
							)
							.concat( a.mobileTitleFontSize, 'px\n\t\t}' ) ),
					( n += '#jtg-'
						.concat(
							t,
							' .modula-items .figc p.description {\n\t\tcolor: '
						)
						.concat( a.captionColor, ';\n\t\tfont-size: ' )
						.concat( a.mobileCaptionFontSize, 'px;\n\t}' ) ),
					( l += '@media screen and (max-width:480px){\n\t\t'.concat(
						n,
						'\n\t\t}'
					) ),
					'none' == a.effect &&
						( l += 'jtg-'.concat(
							t,
							' .modula-items .modula-item:hover img {\n\t\t\topacity: 1;\n\t\t}'
						) ),
					( l += '#jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item .modula-item-overlay,   #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-layla,   #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-ruby,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-bubba,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-sarah,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-milo,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-julia,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-hera,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-winston,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-selena,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-terry,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-phoebe,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items} .modula-item.effect-apollo,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-steve,  #jtg-'
						)
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-ming{ \n\t\tbackground-color: '
						)
						.concat( a.hoverColor, ';\n\t}' ) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-oscar {\n\t\tbackground: -webkit-linear-gradient(45deg, '
						)
						.concat( a.hoverColor, ' 0, #9b4a1b 40%, ' )
						.concat(
							a.hoverColor,
							' 100%);\n\t\tbackground: linear-gradient(45deg, '
						)
						.concat( a.hoverColor, ' 0, #9b4a1b 40%, ' )
						.concat( a.hoverColor, ' 100%);\n\t}' ) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-roxy {\n\t\tbackground: -webkit-linear-gradient(45deg, '
						)
						.concat(
							a.hoverColor,
							' 0, #05abe0 100%);\n\t\tbackground: linear-gradient(45deg, '
						)
						.concat( a.hoverColor, ' 0, #05abe0 100%);\n\t}' ) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-dexter {\n\t\tbackground: -webkit-linear-gradient(top, '
						)
						.concat(
							a.hoverColor,
							' 0, rgba(104,60,19,1) 100%);\n\t\tbackground: linear-gradient(top, '
						)
						.concat(
							a.hoverColor,
							' 0, rgba(104,60,19,1) 100%);\n\t}'
						) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-jazz {\n\t\tbackground: -webkit-linear-gradient(-45deg, '
						)
						.concat(
							a.hoverColor,
							' 0, #f33f58 100%);\n\t\tbackground: linear-gradient(-45deg, '
						)
						.concat( a.hoverColor, ' 0, #f33f58 100%);\n\t}' ) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-lexi {\n\t\tbackground: -webkit-linear-gradient(-45deg, '
						)
						.concat(
							a.hoverColor,
							' 0, #fff 100%);\n\t\tbackground: linear-gradient(-45deg, '
						)
						.concat( a.hoverColor, ' 0, #fff 100%);\n\t}' ) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula .modula-items .modula-item.effect-duke {\n\t\tbackground: -webkit-linear-gradient(-45deg, '
						)
						.concat(
							a.hoverColor,
							' 0, #cc6055 100%);\n\t\tbackground: linear-gradient(-45deg, '
						)
						.concat( a.hoverColor, ' 0, #cc6055 100%);\n\t}' ) ),
					a.hoverOpacity <= 100 &&
						'none' != a.effect &&
						( l += 'jtg-'
							.concat(
								t,
								'.modula .modula-items .modula-item:hover img {\n\t\t\topacity: '
							)
							.concat( 1 - a.hoverOpacity / 100, ' ;\n\t\t}' ) ),
					'default' != a.titleFontWeight &&
						( l += 'jtg-'
							.concat(
								t,
								'.modula .modula-items .modula-item .jtg-title {\n\t\t\tfont-weight : '
							)
							.concat( a.titleFontWeight, ';\n\t\t}' ) ),
					'default' != a.captionFontWeight &&
						( l += 'jtg-'
							.concat(
								t,
								'.modula .modula-items .modula-item p.description {\n\t\t\tfont-weight : '
							)
							.concat( a.captionFontWeight, ';\n\t\t}' ) ),
					( l += 'jtg-'
						.concat(
							t,
							'.modula-gallery .modula-item.effect-terry .jtg-social a:not(:last-child) {\n\t\tmargin-bottom: '
						)
						.concat( a.socialIconPadding, 'px;\n\t}' ) ),
					React.createElement( 'style', {
						dangerouslySetInnerHTML: {
							__html: '\n      \t\t\t\t'.concat(
								l,
								'\n    \t\t\t\t'
							),
						},
					} )
				);
			},
			C = wp.blockEditor.MediaPlaceholder,
			_ = wp.i18n.__,
			I = function ( e ) {
				e.imageCount;
				const t = e.onSelectImages,
					a = e.images,
					l = e.setImageCount;
				return 0 == a.length
					? [
							React.createElement( C, {
								key: 10,
								onSelect( e ) {
									t( e );
								},
								allowedTypes: [ 'image' ],
								onFilesPreUpload( e ) {
									l( e.length );
								},
								addToGallery: ! 1,
								multiple: 'add',
								value: a,
								labels: {
									title: _(
										'Modula Gallery',
										'modula-defaults'
									),
									instructions: _(
										'Drag images, upload new ones or select files from your library',
										'modula-defaults'
									),
								},
							} ),
					  ]
					: [
							React.createElement( C, {
								key: 9,
								onSelect( e ) {
									return t( e );
								},
								allowedTypes: [ 'image' ],
								className: 'modula-appender-media',
								addToGallery: ! 1,
								isAppender: ! 0,
								style: { height: '60px' },
								multiple: 'add',
								value: a,
								labels: { title: '', instructions: _( '' ) },
							} ),
					  ];
			};
		function z() {
			return ( z = Object.assign
				? Object.assign.bind()
				: function ( e ) {
						for ( let t = 1; t < arguments.length; t++ ) {
							const a = arguments[ t ];
							for ( const l in a ) {
								Object.prototype.hasOwnProperty.call( a, l ) &&
									( e[ l ] = a[ l ] );
							}
						}
						return e;
				  } ).apply( this, arguments );
		}
		wp.i18n.__;
		const N = wp.element,
			F = N.Fragment,
			M = N.useEffect,
			T = function ( e ) {
				const t = e.attributes,
					a = t.images,
					l = t.jsConfig,
					n = ( t.id, e.defaultSettings ),
					o = e.galleryId,
					c = ( e.exportImages, e.modulaRun ),
					r = e.onSelectImage,
					i = e.onSelectImages,
					u = e.onMoveBackward,
					d = e.onMoveForward,
					s =
						( e.onRemoveImage,
						e.isFirstItem,
						e.isLastItem,
						e.isSelected ),
					m = e.selectedImage,
					g = e.checkHoverEffect,
					f = e.imageCount,
					p = e.setImageCount;
				M( function () {
					void 0 !== n && g( n.effect ), void 0 !== l && c( l );
				}, [] );
				let h = 'modula modula-gallery ',
					y = 'modula-items';
				return (
					'creative-gallery' == n.type
						? ( h += 'modula-creative-gallery' )
						: 'custom-grid' == n.type
						? ( h += 'modula-custom-grid' )
						: 'slider' == n.type
						? ( h = 'modula-slider' )
						: ( ( h += 'modula-columns' ),
						  ( y += ' grid-gallery' ),
						  'automatic' == n.grid_type &&
								( y += ' justified-gallery' ) ),
					[
						React.createElement(
							F,
							{ key: 5 },
							React.createElement( k, { id: o, settings: n } ),
							React.createElement(
								'div',
								{
									id: 'jtg-'.concat( o ),
									className: h,
									'data-config': JSON.stringify( l ),
								},
								'grid' == n.type &&
									'automatic' != n.grid_type &&
									React.createElement(
										'div',
										{ className: 'modula-grid-sizer' },
										' '
									),
								React.createElement(
									'div',
									{ className: y },
									a.length > 0 &&
										React.createElement(
											F,
											null,
											React.createElement(
												F,
												null,
												a.map( function ( t, l ) {
													return [
														React.createElement(
															x,
															z( {}, e, {
																img: t,
																index: l,
																selectedImage:
																	m,
																isFirstItem:
																	0 === l,
																isLastItem:
																	l + 1 ===
																	a.length,
																isSelected:
																	s &&
																	m === l,
																onSelect: r,
																onMoveBackward:
																	u( l ),
																onMoveForward:
																	d( l ),
																key: l,
															} )
														),
													];
												} )
											)
										)
								)
							),
							React.createElement( I, {
								onSelectImages: i,
								images: a,
								imageCount: f,
								setImageCount: p,
								setAttributes: e.setAttributes,
								attributes: e.attributes,
							} )
						),
					]
				);
			};
		function O() {
			return ( O = Object.assign
				? Object.assign.bind()
				: function ( e ) {
						for ( let t = 1; t < arguments.length; t++ ) {
							const a = arguments[ t ];
							for ( const l in a ) {
								Object.prototype.hasOwnProperty.call( a, l ) &&
									( e[ l ] = a[ l ] );
							}
						}
						return e;
				  } ).apply( this, arguments );
		}
		function A( e ) {
			return (
				( function ( e ) {
					if ( Array.isArray( e ) ) {
						return L( e );
					}
				} )( e ) ||
				( function ( e ) {
					if (
						( 'undefined' !== typeof Symbol &&
							null != e[ Symbol.iterator ] ) ||
						null != e[ '@@iterator' ]
					) {
						return Array.from( e );
					}
				} )( e ) ||
				P( e ) ||
				( function () {
					throw new TypeError(
						'Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.'
					);
				} )()
			);
		}
		function B( e, t ) {
			return (
				( function ( e ) {
					if ( Array.isArray( e ) ) {
						return e;
					}
				} )( e ) ||
				( function ( e, t ) {
					let a =
						null == e
							? null
							: ( 'undefined' !== typeof Symbol &&
									e[ Symbol.iterator ] ) ||
							  e[ '@@iterator' ];
					if ( null != a ) {
						let l,
							n,
							o,
							c,
							r = [],
							i = ! 0,
							u = ! 1;
						try {
							if (
								( ( o = ( a = a.call( e ) ).next ), 0 === t )
							) {
								if ( Object( a ) !== a ) {
									return;
								}
								i = ! 1;
							} else {
								for (
									;
									! ( i = ( l = o.call( a ) ).done ) &&
									( r.push( l.value ), r.length !== t );
									i = ! 0
								) {}
							}
						} catch ( e ) {
							( u = ! 0 ), ( n = e );
						} finally {
							try {
								if (
									! i &&
									null != a.return &&
									( ( c = a.return() ), Object( c ) !== c )
								) {
									return;
								}
							} finally {
								if ( u ) {
									throw n;
								}
							}
						}
						return r;
					}
				} )( e, t ) ||
				P( e, t ) ||
				( function () {
					throw new TypeError(
						'Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.'
					);
				} )()
			);
		}
		function P( e, t ) {
			if ( e ) {
				if ( 'string' === typeof e ) {
					return L( e, t );
				}
				let a = Object.prototype.toString.call( e ).slice( 8, -1 );
				return (
					'Object' === a &&
						e.constructor &&
						( a = e.constructor.name ),
					'Map' === a || 'Set' === a
						? Array.from( e )
						: 'Arguments' === a ||
						  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test( a )
						? L( e, t )
						: void 0
				);
			}
		}
		function L( e, t ) {
			( null == t || t > e.length ) && ( t = e.length );
			for ( var a = 0, l = new Array( t ); a < t; a++ ) {
				l[ a ] = e[ a ];
			}
			return l;
		}
		const q = wp.i18n.__,
			V = wp.element,
			G = V.Fragment,
			Q = V.useEffect,
			U = V.useState,
			D = wp.data.withSelect,
			H = wp.components,
			$ = H.Button,
			W = H.Spinner,
			Y = H.Toolbar,
			J = H.IconButton,
			K = wp.editor.BlockControls,
			X = D( function ( e, t ) {
				return {
					defaults:
						( 0, e( 'core' ).getEntityRecords )(
							'postType',
							'modula-defaults',
							{ post_status: 'publish', per_page: 5 }
						) || [],
				};
			} )( function ( e ) {
				const t = e.attributes,
					a = e.setAttributes,
					l = e.defaults,
					o = e.switchBlock,
					c = e.galleries,
					r = t.images,
					i = t.id,
					u = t.status,
					d = t.defaultSettings,
					m = t.jsConfig,
					f = t.galleryId,
					p = B( U(), 2 ),
					h = p[ 0 ],
					y = p[ 1 ],
					v = B( U( 0 ), 2 ),
					b = v[ 0 ],
					w = v[ 1 ];
				Q( function () {
					0 !== i && E( i ), j();
				}, [] ),
					Q( function () {
						jQuery( document ).on(
							'modula_api_after_init',
							function ( t, a ) {
								e.setAttributes( { instance: a } );
							}
						),
							null != e.attributes.instance &&
								null != d &&
								'grid' == d.type &&
								e.attributes.instance.reset(
									e.attributes.instance
								);
					} );
				var E = function ( e ) {
						isNaN( e ) ||
							'' == e ||
							( ( e = parseInt( e ) ),
							a( { id: e, status: 'ready' } ),
							0 !== e && R( e ) );
					},
					R = function ( e ) {
						fetch(
							''
								.concat(
									modulaVars.restURL,
									'wp/v2/modula-defaults/'
								)
								.concat( e )
						)
							.then( function ( e ) {
								return e.json();
							} )
							.then( function ( t ) {
								const l = t;
								a( {
									currentSelectize: [
										{
											value: e,
											label:
												'' === t.title.rendered
													? 'Unnamed'
													: t.title.rendered,
										},
									],
								} ),
									a( { status: 'loading' } ),
									jQuery.ajax( {
										type: 'POST',
										data: {
											action: 'modula_get_jsconfig',
											nonce: modulaVars.nonce,
											settings: l.modulaSettings,
										},
										url: modulaVars.ajaxURL,
										success( e ) {
											const t = Math.floor(
												999 * Math.random()
											);
											a( {
												galleryId: t,
												defaultSettings:
													l.modulaSettings,
												jsConfig: e,
												status: 'ready',
											} );
										},
									} );
							} );
					},
					j = function ( e ) {
						a( { status: 'ready' } );
						const t = jQuery( '.modula.modula-gallery' );
						jQuery.each( t, function () {
							const e = jQuery( this ).attr( 'id' ),
								t = jQuery( this ).data( 'config' );
							jQuery( '#' + e ).modulaGallery( t );
						} );
					},
					S = function ( e ) {
						if ( null != e ) {
							let t = {};
							return (
								( t =
									'modula-defaults' == e[ 0 ].type
										? [
												{
													value: 0,
													label: q(
														'select a preset',
														'modula-best-grid-gallery'
													),
												},
										  ]
										: [
												{
													value: 0,
													label: q(
														'select a gallery',
														'modula-best-grid-gallery'
													),
												},
										  ] ),
								e.forEach( function ( e ) {
									0 == e.title.rendered.length
										? t.push( {
												value: e.id,
												label:
													q(
														'Unnamed Gallery ',
														'modula-best-grid-gallery'
													) + e.id,
										  } )
										: t.push( {
												value: e.id,
												label: e.title.rendered,
										  } );
								} ),
								t
							);
						}
					},
					x = function ( t, a ) {
						const l = A( r );
						l.splice( a, 1, r[ t ] ),
							l.splice( t, 1, r[ a ] ),
							y( a ),
							e.setAttributes( { images: l } );
					},
					k = React.createElement(
						K,
						null,
						React.createElement(
							Y,
							null,
							React.createElement( J, {
								label: q(
									'Edit gallery',
									'modula-best-grid-gallery'
								),
								icon: 'edit',
								href:
									modulaVars.adminURL +
									'post.php?post=' +
									i +
									'&action=edit',
								target: '_blank',
							} )
						)
					);
				return 'loading' === u
					? [
							React.createElement(
								G,
								{ key: 2 },
								React.createElement(
									'div',
									{ className: 'modula-block-preview' },
									React.createElement(
										'div',
										{
											className:
												'modula-block-preview__content',
										},
										React.createElement( 'div', {
											className:
												'modula-block-preview__logo',
										} ),
										React.createElement( W, null )
									)
								)
							),
					  ]
					: 0 == i
					? [
							React.createElement(
								G,
								{ key: 3 },
								React.createElement(
									s,
									O(
										{
											onIdChange( e ) {
												return E( e );
											},
											selectOptions: S,
										},
										e,
										{ switchBlock: o }
									)
								),
								React.createElement(
									'div',
									{ className: 'modula-block-preview' },
									React.createElement(
										'div',
										{
											className:
												'modula-block-preview__content',
										},
										React.createElement( 'div', {
											className:
												'modula-block-preview__logo',
										} ),
										0 === l.length &&
											React.createElement(
												G,
												null,
												React.createElement(
													'p',
													null,
													q(
														"You don't seem to have any galleries.",
														'modula-best-grid-gallery'
													)
												),
												React.createElement(
													$,
													{
														className:
															'modula-button',
														href:
															modulaVars.adminURL +
															'post-new.php?post_type=modula-defaults',
														target: '_blank',
													},
													q(
														'Add New Gallery',
														'modula-best-grid-gallery'
													),
													g.chevronRightFancy
												)
											),
										l.length > 0 &&
											React.createElement(
												G,
												null,
												React.createElement(
													G,
													null,
													React.createElement( n, {
														className:
															'modula-defaults-input',
														placeholder: q(
															'Search for a preset...',
															'modula-best-grid-gallery'
														),
														value: i,
														ajax: ! 0,
														ajaxAction:
															'modula_get_defaults',
														onChangeFunction: E,
														options:
															e.attributes
																.currentSelectize,
														defaults: l,
														galleries: c,
													} )
												),
												0 != i &&
													React.createElement(
														$,
														{
															target: '_blank',
															href:
																modulaVars.adminURL +
																'post.php?post=' +
																i +
																'&action=edit',
															isPrimary: ! 0,
														},
														q( 'Edit Gallery' )
													)
											)
									)
								)
							),
					  ]
					: d
					? [
							React.createElement(
								G,
								{ key: 4 },
								k,
								React.createElement(
									s,
									O(
										{
											onIdChange( e ) {
												return E( e );
											},
											switchBlock: o,
											selectOptions: S,
										},
										e
									)
								),
								React.createElement(
									T,
									O( {}, e, {
										onSelectImages( e ) {
											const t = A( r );
											e.map( function ( e ) {
												t.push( {
													id: e.id,
													url: e.url,
												} );
											} );
											const l = t.map( function ( e ) {
													return e.id;
												} ),
												n = t.filter(
													function ( e, t ) {
														const a = e.id;
														return ! l.includes(
															a,
															t + 1
														);
													}
												);
											a( {
												images: n,
												status: 'loading',
											} ),
												e.length > 4
													? ( e[
															e.length - 1
													  ].hasOwnProperty(
															'id'
													  ) && j( ! 0 ),
													  e[
															e.length - 2
													  ].hasOwnProperty(
															'id'
													  ) && j( ! 0 ),
													  e[
															e.length - 3
													  ].hasOwnProperty(
															'id'
													  ) && j( ! 0 ) )
													: e.length <= 4 && j( ! 0 );
										},
										onRemoveImage( e ) {
											e.preventDefault();
											let t,
												l = A( r );
											( t = jQuery(
												jQuery(
													e.target
												).parents()[ 2 ]
											).find( 'img' )[ 0 ].dataset.id ),
												( l = l.filter(
													function ( e, a ) {
														return e.id != t;
													}
												) ),
												a( { images: l } ),
												a( { status: 'loading' } ),
												j();
										},
										onSelectImage( e ) {
											return function () {
												y( e );
											};
										},
										selectedImage: h,
										onMoveBackward( e ) {
											return function () {
												0 !== e &&
													( a( {
														status: 'loading',
													} ),
													x( e, e - 1 ),
													j() );
											};
										},
										onMoveForward( e ) {
											return function () {
												e !== r.length - 1 &&
													( a( {
														status: 'loading',
													} ),
													x( e, e + 1 ),
													j() );
											};
										},
										defaultSettings: d,
										jsConfig: m,
										modulaRun: j,
										checkHoverEffect( e ) {
											jQuery.ajax( {
												type: 'POST',
												data: {
													action: 'modula_check_hover_effect',
													nonce: modulaVars.nonce,
													effect: e,
												},
												url: modulaVars.ajaxURL,
												success( e ) {
													a( { effectCheck: e } );
												},
											} );
										},
										galleryId: f,
										setImageCount: w,
										imageCount: b,
									} )
								)
							),
					  ]
					: null;
			} );
		function Z() {
			return ( Z = Object.assign
				? Object.assign.bind()
				: function ( e ) {
						for ( let t = 1; t < arguments.length; t++ ) {
							const a = arguments[ t ];
							for ( const l in a ) {
								Object.prototype.hasOwnProperty.call( a, l ) &&
									( e[ l ] = a[ l ] );
							}
						}
						return e;
				  } ).apply( this, arguments );
		}
		const ee = wp.i18n.__,
			te = wp.element,
			ae = ( te.Platform, te.Component, te.Fragment ),
			le = ( te.useEffect, te.useState, wp.data ),
			ne = le.useSelect,
			oe = ( le.withSelect, wp.components ),
			ce = ( oe.SelectControl, oe.Button ),
			re =
				( oe.Spinner,
				oe.Toolbar,
				oe.IconButton,
				wp.compose.createHigherOrderComponent ),
			ie = re( function ( e ) {
				return function ( t ) {
					const a = t.attributes,
						l = t.setAttributes,
						n =
							( t.isSelected,
							a.id,
							a.images,
							a.status,
							a.isGallery,
							a.galleryType ),
						o = function ( e ) {
							l( {
								status: 'loading',
								images: [],
								id: 0,
								currentSelectize: [],
							} ),
								l( { galleryType: e, status: 'ready' } );
						},
						c = ne( function ( e ) {
							return (
								( 0, e( 'core' ).getEntityRecords )(
									'postType',
									'modula-defaults',
									{ post_status: 'publish', per_page: 1 }
								) || []
							);
						} ),
						r = ne( function ( e ) {
							return (
								( 0, e( 'core' ).getEntityRecords )(
									'postType',
									'modula-gallery',
									{ post_status: 'publish', per_page: 1 }
								) || []
							);
						} );
					return 'none' === a.galleryType
						? [
								React.createElement(
									ae,
									{ key: 1 },
									React.createElement(
										'div',
										{ className: 'modula-block-preview' },
										React.createElement(
											'div',
											{
												className:
													'modula-block-preview__content',
											},
											React.createElement( 'div', {
												className:
													'modula-block-preview__logo',
											} ),
											React.createElement(
												'div',
												{
													className:
														'modula-button-group',
												},
												r.length > 0 &&
													React.createElement(
														ce,
														{
															className:
																'modula-button',
															target: '_blank',
															onClick( e ) {
																l( {
																	status: 'ready',
																	galleryType:
																		'gallery',
																} );
															},
														},
														ee(
															'Display An Existing Gallery',
															'modula-best-grid-gallery'
														),
														g.chevronRightFancy
													),
												React.createElement(
													ce,
													{
														className:
															'modula-button',
														target: '_blank',
														onClick( e ) {
															l( {
																status: 'ready',
																defaults: c,
																galleryType:
																	'defaults',
															} );
														},
													},
													ee(
														'Create New Gallery using a Preset ( fastest way )',
														'modula-best-grid-gallery'
													),
													g.chevronRightFancy
												)
											)
										)
									)
								),
						  ]
						: 'gallery' == n
						? React.createElement(
								e,
								Z( {}, t, {
									defaults: c,
									switchBlock: o,
									key: 1,
								} )
						  )
						: React.createElement(
								X,
								Z( {}, t, {
									defaults: c,
									switchBlock: o,
									key: 2,
								} )
						  );
				};
			}, 'withDefaultsEdit' );
		wp.hooks.addFilter(
			'modula.ModulaEdit',
			'modula/modula-defaults-edit',
			ie,
			1
		);
		const ue = re( function ( e ) {
			return function ( e ) {
				return React.createElement( s, e );
			};
		} );
		wp.hooks.addFilter(
			'modula.ModulaInspector',
			'modula/modula-defaults-inspector',
			ue,
			1
		);
	},
] );
