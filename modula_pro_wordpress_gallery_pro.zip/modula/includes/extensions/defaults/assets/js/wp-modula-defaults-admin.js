wp.ModulaDefaults =
	'undefined' === typeof wp.ModulaDefaults ? {} : wp.ModulaDefaults;
wp.ModulaDefaultsImport =
	'undefined' === typeof wp.ModulaDefaultsImport
		? {}
		: wp.ModulaDefaultsImport;
wp.ModulaDefaultsAlbums =
	'undefined' === typeof wp.ModulaDefaultsAlbums
		? {}
		: wp.ModulaDefaultsAlbums;

( function ( $, modulaDefaults, modulaDefaultsImport, modulaDefaultsAlbums ) {
	jQuery( document ).ready( function ( $ ) {
		// Modula edit item modal.
		wp.ModulaDefaults.View = new wp.ModulaDefaults.modal.model( {} );

		// Modula import default modal.
		wp.ModulaDefaultsImport.View = new wp.ModulaDefaultsImport.modal.model(
			{}
		);

		// Modula edit item modal.
		if ( wp.ModulaDefaultsAlbums.length ) {
			wp.ModulaDefaultsAlbums.View =
				new wp.ModulaDefaultsAlbums.modal.model( {} );
		}

		/**
		 * Give the user an option to select defaults for the new gallery
		 */
		$(
			"a[href$='post-new.php?post_type=modula-gallery'], a[href$='post-new.php?post_type=modula-album']"
		).on( 'click', function ( e ) {
			if (
				$( this )
					.attr( 'href' )
					.indexOf( 'post-new.php?post_type=modula-gallery' ) > 0
			) {
				if ( modulaDefaultHelper.defaults_galleries <= 0 ) {
					return;
				}
			} else if ( modulaDefaultHelper.defaults_albums <= 0 ) {
				return;
			}

			e.preventDefault();

			const post_type = jQuery( this )
				.attr( 'href' )
				.split( 'post_type=' )[ 1 ];

			const opts = {
				url: modulaDefaultHelper.ajax_url,
				type: 'post',
				async: true,
				cache: false,
				dataType: 'json',
				data: {
					action: 'modula_defaults_settings',
					post_type,
					nonce: modulaDefaultHelper.nonce,
				},
				success( response ) {
					wp.ModulaDefaults.View.open( response, post_type );
				},
			};

			jQuery.ajax( opts );
		} );

		// Create our new defaults functionality
		$(
			'body .modula-defaults-metabox a#create_default,tr.type-modula-gallery a.modula-list-default-create,body .modula-defaults-metabox a#create_album_default,tr.type-modula-album a.modula-list-default-create'
		).click( function ( e ) {
			e.preventDefault();

			let link_id = $( this ).attr( 'id' ),
				btn_wrapper = $( this ).parents( '.defaults_metabox_wrapper' ),
				action,
				post_id,
				response_status;

			// let's see if this is for album or gallery
			if (
				'create_album_default' === link_id ||
				$( this ).parents( 'tr' ).hasClass( 'type-modula-album' )
			) {
				action = 'create_modula_album_default';

				if ( $( 'tr.type-modula-album' ).length ) {
					post_id = $( this ).attr( 'post-id' );
					btn_wrapper = $( this ).parents( 'td' );
				} else {
					post_id = $( 'input#post_ID' ).val();
				}
			} else {
				action = 'create_modula_default';
				post_id = $( 'input#post_ID' ).val();
				if ( 'create_default' !== link_id ) {
					post_id = $( this ).attr( 'post-id' );
					btn_wrapper = $( this ).parents( 'td' );
				}
			}

			const data = {
				action,
				post_id,
				nonce: modulaDefaultHelper.nonce,
			};

			response_status = btn_wrapper.find( '.response_status' );
			response_status.html(
				'<span>' + modulaDefaultHelper.creating_default + '</span>'
			);

			// Do the magic
			$.post( modulaDefaultHelper.ajax_url, data, function ( response ) {
				if ( response ) {
					response_status.html(
						'<span>' +
							modulaDefaultHelper.created_default +
							'</span>'
					);

					setTimeout( function () {
						response_status.html( '' );
					}, 1500 );
				} else {
					response_status.html(
						'<span style="color:red;">' +
							modulaDefaultHelper.error_creating +
							'</span>'
					);
				}
			} );
		} );

		// Import our defaults into gallery/album functionality
		$(
			'body .modula-defaults-metabox a#import_default,body span.apply_default a.modula-list-apply-create'
		).click( function ( e ) {
			e.preventDefault();

			const post_type = $( 'input#post_type' ).length
					? $( 'input#post_type' ).val()
					: $( 'input[name="post_type"]' ).val(),
				// Metabox Import Preset has no post-id attr; fall back to the edit screen post ID.
				post_id =
					$( this ).attr( 'post-id' ) || $( 'input#post_ID' ).val(),
				opts = {
					url: modulaDefaultHelper.ajax_url,
					type: 'post',
					async: true,
					cache: false,
					dataType: 'json',
					data: {
						action: 'import_modula_default',
						post_type,
						nonce: modulaDefaultHelper.nonce,
					},
					success( response ) {
						wp.ModulaDefaultsImport.View.open(
							response,
							post_type,
							post_id
						);
					},
				};

			$.ajax( opts );
		} );

		$( '#doaction,#doaction2' ).on( 'click', function ( e ) {
			if (
				'apply_default' ===
					$(
						'.tablenav.top div.bulkactions select[name="action"]'
					).val() ||
				'apply_default' ===
					$(
						'.tablenav.bottom div.bulkactions select[name="action"]'
					).val()
			) {
				e.preventDefault();

				const post_type = $( 'input[name="post_type"]' ).val(),
					opts = {
						url: modulaDefaultHelper.ajax_url,
						type: 'post',
						async: true,
						cache: false,
						dataType: 'json',
						data: {
							action: 'import_modula_default',
							post_type,
							nonce: modulaDefaultHelper.nonce,
						},
						success( response ) {
							wp.ModulaDefaultsImport.View.open(
								response,
								post_type
							);
						},
					};

				$.ajax( opts );
			}
		} );
		function checkParentSelect() {
			const val = $( '#parent_id' ).val();

			if ( val && val !== '' ) {
				$( '#modula-album-default-item-attributes' ).show();
			} else {
				$( '#modula-album-default-item-attributes' ).hide();
			}
		}

		$( '#parent_id' ).on( 'change', function () {
			checkParentSelect();
		} );

		checkParentSelect();
	} );
} )(
	jQuery,
	wp.ModulaDefaults,
	wp.ModulaDefaultsImport,
	wp.ModulaDefaultsAlbums
);
