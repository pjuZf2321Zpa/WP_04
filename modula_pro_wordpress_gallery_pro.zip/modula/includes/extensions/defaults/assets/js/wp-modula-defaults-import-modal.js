wp.ModulaDefaultsImport =
	'undefined' === typeof wp.ModulaDefaultsImport
		? {}
		: wp.ModulaDefaultsImport;
wp.ModulaDefaultsImport.post_type = 'modula-gallery';
( function ( $, modulaDefaultsImport ) {
	const modulaDefaultsImportModal = Backbone.Model.extend( {
		defaults: {
			item: false,
		},

		initialize( args ) {
			const modalDefaultsImportView = new modulaDefaultsImport.modal.view(
				{
					model: this,
					childViews: args.childViews,
				}
			);

			const wpMediaView = new wp.media.view.Modal( {
				controller: {
					trigger() {},
				},
			} );

			this.set( 'wpMediaView', wpMediaView );
			this.set( 'modulaDefaultsImportModal', modalDefaultsImportView );
		},

		open( $item, postType, postId = 0 ) {
			const wpMediaView = this.get( 'wpMediaView' ),
				modulaDefaultsImportModal = this.get(
					'modulaDefaultsImportModal'
				);

			// Render Modula View
			modulaDefaultsImportModal.render();
			// Append modulaModalView to wpMediaView
			wpMediaView.content( modulaDefaultsImportModal );
			// Open wpMediaView
			wpMediaView.open();
			wp.ModulaDefaultsImport.post_type = postType;
			wp.ModulaDefaultsImport.post_id = postId;

			// Add modula-defaults-modal-wrapper class to modal wrapper so we can style it
			this.attributes.wpMediaView.$el.addClass(
				'modula-defaults-modal-wrapper'
			);

			const selectWrapper = wpMediaView.$el.find(
				'#modula-defaults-select'
			);
			// Remove all previous set options except the default one
			const default_option = selectWrapper.find( 'option' ).val( 'none' );
			selectWrapper.find( 'option' ).not( default_option ).remove();

			jQuery.each( $item, function () {
				const o = new Option(
					jQuery( this )[ 0 ].title,
					jQuery( this )[ 0 ].id
				);
				selectWrapper.append( o ).change();
			} );

			selectWrapper.selectize();
		},
	} );

	const modulaDefaultsImportModalView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'div',
		className:
			'media-frame mode-select wp-core-ui hide-router hide-menu modula-defaults-select',

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-defaults-import' ),

		/**
		 * Events
		 * - Functions to call when specific events occur
		 */
		events: {
			'click  .modula-gallery-import-submit': 'importSettings',
		},

		/**
		 * Initialize
		 *
		 * @param args
		 */
		initialize( args ) {
			// Set some flags
			this.item = false;
		},
		/**
		 * Render
		 * - Binds the model to the view, so we populate the view's fields and data
		 */
		render() {
			// Get HTML
			this.$el.html( this.template( this.model.toJSON() ) );

			// Return
			return this;
		},
		importSettings( el ) {
			if ( ! confirm( modulaDefaultHelper.confirmation_text ) ) {
				return;
			}

			let $current_post = wp.ModulaDefaultsImport.post_id ?? false;

			// Metabox Import may open without a row post-id; use the edit screen ID.
			if ( ! $current_post ) {
				$current_post = $( 'input#post_ID' ).val() || false;
			}

			if ( $( 'tbody#the-list' ).length && ! $current_post ) {
				$current_post = [];
				$( 'tbody#the-list th.check-column' ).each( function () {
					$current_post.push(
						$( this )
							.find( 'input[type="checkbox"]:checked' )
							.attr( 'value' )
					);
				} );
			}

			const data = {
				action: 'import_modula_default_setting',
				post_id: $(
					'#modula-defaults-import select#modula-defaults-select'
				).val(),
				current_post: $current_post,
				nonce: modulaDefaultHelper.nonce,
			};

			$.post( modulaDefaultHelper.ajax_url, data, function ( response ) {
				// reload the page if everything OK
				location.reload( true );
			} );
		},
	} );

	modulaDefaultsImport.modal = {
		model: modulaDefaultsImportModal,
		view: modulaDefaultsImportModalView,
	};
} )( jQuery, wp.ModulaDefaultsImport );
