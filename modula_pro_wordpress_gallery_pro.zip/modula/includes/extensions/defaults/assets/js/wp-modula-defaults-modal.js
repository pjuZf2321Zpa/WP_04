wp.ModulaDefaults =
	'undefined' === typeof wp.ModulaDefaults ? {} : wp.ModulaDefaults;
wp.ModulaDefaults.post_type = 'modula-gallery';
( function ( $, modulaDefaults ) {
	const modulaDefaultsModal = Backbone.Model.extend( {
		defaults: {
			item: false,
		},

		initialize( args ) {
			const modalDefaultsView = new modulaDefaults.modal.view( {
				model: this,
				childViews: args.childViews,
			} );

			const wpMediaView = new wp.media.view.Modal( {
				controller: {
					trigger() {},
				},
			} );

			this.set( 'wpMediaView', wpMediaView );
			this.set( 'modulaDefaultsModal', modalDefaultsView );
		},

		open( $item, postType ) {
			let wpMediaView = this.get( 'wpMediaView' ),
				modulaDefaultsModal = this.get( 'modulaDefaultsModal' ),
				create_type;

			// Render Modula View
			modulaDefaultsModal.render();
			// Append modulaModalView to wpMediaView
			wpMediaView.content( modulaDefaultsModal );
			// Open wpMediaView
			wpMediaView.open();
			wp.ModulaDefaults.post_type = postType;

			// Add modula-defaults-modal-wrapper class to modal wrapper so we can style it
			this.attributes.wpMediaView.$el.addClass(
				'modula-defaults-modal-wrapper'
			);

			if ( 'modula-gallery' == wp.ModulaDefaults.post_type ) {
				create_type = 'gallery';
			} else {
				create_type = 'album';
			}

			wpMediaView.$el
				.find( 'h3.create-me' )
				.html( 'Create ' + create_type );

			const selectWrapper = wpMediaView.$el.find(
				'#modula-defaults-select'
			);
			// Remove all previous set options except the default one
			const default_option = selectWrapper.find( 'option' ).val( 'none' );
			selectWrapper.find( 'option' ).not( default_option ).remove();

			jQuery.each( $item, function () {
				const o = new Option(
					jQuery( this )[ 0 ].title,
					jQuery( this )[ 0 ].id
				);
				selectWrapper.append( o ).change();
			} );

			selectWrapper.selectize();
		},
	} );

	const modulaDefaultsModalView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'div',
		className:
			'media-frame mode-select wp-core-ui hide-router hide-menu modula-defaults-select',

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-defaults-configuration' ),

		/**
		 * Events
		 * - Functions to call when specific events occur
		 */
		events: {
			'change #modula-defaults-select': 'selectDefault',
			'click a#modula-cfs': 'createFromScratch',
		},

		/**
		 * Initialize
		 *
		 * @param args
		 */
		initialize( args ) {
			// Set some flags
			this.item = false;
		},
		/**
		 * Render
		 * - Binds the model to the view, so we populate the view's fields and data
		 */
		render() {
			// Get HTML
			this.$el.html( this.template( this.model.toJSON() ) );

			// Return
			return this;
		},
		selectDefault( el ) {
			if ( 'none' !== el.target.value ) {
				$( '.modula-defaults-select .modula-gallery-create-submit' )
					.removeAttr( 'disabled' )
					.attr(
						'href',
						'post-new.php?post_type=' +
							wp.ModulaDefaults.post_type +
							'&modula_default=' +
							el.target.value
					);
			} else {
				$(
					'.modula-defaults-select .modula-gallery-create-submit'
				).attr( 'disabled', 'disabled' );
			}
		},
		createFromScratch( el ) {
			el.preventDefault();
			window.location.href =
				'post-new.php?post_type=' + wp.ModulaDefaults.post_type;
		},
	} );

	modulaDefaults.modal = {
		model: modulaDefaultsModal,
		view: modulaDefaultsModalView,
	};
} )( jQuery, wp.ModulaDefaults );
