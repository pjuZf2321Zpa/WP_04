( function ( Modula ) {
	'use strict';

	const modulaZoomConditions = Backbone.Model.extend( {
		initialize( args ) {
			const rows = jQuery(
				'.modula-settings-container tr[data-container]'
			);
			const tabs = jQuery( '.modula-tabs .modula-tab' );
			this.set( 'rows', rows );
			this.set( 'tabs', tabs );

			this.initEvents();
			this.initValues();
		},

		initValues() {
			this.changedZoom( false, wp.Modula.Settings.get( 'enable_zoom' ) );
			this.changedZoomType(
				false,
				wp.Modula.Settings.get( 'zoom_type' )
			);
		},

		initEvents() {
			this.listenTo(
				wp.Modula.Settings,
				'change:enable_zoom',
				this.changedZoom
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:zoom_type',
				this.changedZoomType
			);
		},

		changedZoom( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter( '[data-container="enable_zoom"]' ),
				children = currentRow.data( 'children' );

			jQuery.each( children, function ( index, item ) {
				const child = jQuery( '[data-container="' + item + '"]' );

				if ( 0 == value ) {
					child.hide();
				} else {
					child.setting_state( this, 'on' );
					child
						.find( 'input, textarea, select, button' )
						.removeAttr( 'disabled' );
					child.show();
				}
			} );

			if ( '1' == value ) {
				currentRow.addClass( 'modula_accordion_open' );
			} else {
				currentRow.removeClass( 'modula_accordion_open' );
			}
			this.changedZoomType(
				false,
				wp.Modula.Settings.get( 'zoom_type' )
			);
		},

		changedZoomType( settings, value ) {
			const rows = this.get( 'rows' ),
				tabs = this.get( 'tabs' ),
				parentRow = rows.filter( '[data-container="enable_zoom"]' );

			if ( '1' != wp.Modula.Settings.attributes.enable_zoom ) {
				rows.filter(
					'[data-container="zoom_effect"], [data-container="zoom_window_position"], [data-container="zoom_window_size"],[data-container="zoom_lens_size"], [data-container="zoom_lens_shape"], [data-container="zoom_tint_color"], [data-container="zoom_tint_opacity"]'
				).hide();
			} else {
				rows.filter(
					'[data-container="zoom_effect"], [data-container="zoom_window_position"], [data-container="zoom_window_size"],[data-container="zoom_lens_size"], [data-container="zoom_lens_shape"], [data-container="zoom_tint_color"], [data-container="zoom_tint_opacity"]'
				).show();
				rows.filter(
					'[data-container="zoom_effect"], [data-container="zoom_window_position"], [data-container="zoom_window_size"],[data-container="zoom_lens_size"], [data-container="zoom_lens_shape"], [data-container="zoom_tint_color"], [data-container="zoom_tint_opacity"]'
				).setting_state( this, 'on' );
			}

			if (
				'window' == value &&
				'1' == wp.Modula.Settings.attributes.enable_zoom
			) {
				rows.filter( '[data-container="zoom_lens_size"]' ).hide();

				jQuery( 'option[value="easing"]' ).show();
			} else if (
				'inner' == value &&
				'1' == wp.Modula.Settings.attributes.enable_zoom
			) {
				rows.filter(
					'[data-container="zoom_window_position"], [data-container="zoom_window_size"], [data-container="zoom_lens_size"], [data-container="zoom_lens_shape"], [data-container="zoom_tint_color"], [data-container="zoom_tint_opacity"],[data-container="zoom_effect"]'
				).hide();
				rows.filter( '[data-container="zoom_type"]' ).setting_state(
					this,
					'on'
				);
			} else if (
				'lens' == value &&
				'1' == wp.Modula.Settings.attributes.enable_zoom
			) {
				rows.filter(
					'[data-container="zoom_window_position"], [data-container="zoom_window_size"], [data-container="zoom_tint_color"], [data-container="zoom_tint_opacity"]'
				).hide();
				rows.filter(
					'[data-container="zoom_effect"], [data-container="zoom_type"], [data-container="zoom_lens_size"], [data-container="zoom_lens_shape"],[data-container="zoom_effect"]'
				).setting_state( this, 'on' );
				jQuery( 'option[value="easing"]' ).hide();
			}
		},
	} );

	jQuery( document ).ready( function () {
		new modulaZoomConditions();
	} );
} )( jQuery, wp.Modula );
