( function ( $ ) {
	const MAX_INIT_ATTEMPTS = 48;

	/**
	 * @param {unknown} instance Fancybox (v6) or legacy carousel instance.
	 * @return {unknown|null}
	 */
	function resolveLightboxInstance( instance ) {
		if ( ! instance || typeof instance !== 'object' ) {
			return null;
		}
		const container =
			instance.container ||
			( typeof instance.getContainer === 'function'
				? instance.getContainer()
				: null );
		if ( ! container ) {
			return null;
		}
		return instance;
	}

	/**
	 * @param {unknown} instance
	 * @return {object|null}
	 */
	function resolveMzoomSettings( instance ) {
		if ( ! instance || typeof instance !== 'object' ) {
			return null;
		}

		if ( typeof instance.option === 'function' ) {
			const fromOption = instance.option( 'mzoom' );
			if ( fromOption && typeof fromOption === 'object' ) {
				return fromOption;
			}
		}

		const options =
			instance.options ||
			( typeof instance.getOptions === 'function'
				? instance.getOptions()
				: null );
		if ( options && options.mzoom && typeof options.mzoom === 'object' ) {
			return options.mzoom;
		}

		return null;
	}

	/**
	 * @param {unknown} instance
	 * @return {{ slide: object, imageEl: ReturnType<typeof $> }|null}
	 */
	function resolveSlideImage( instance ) {
		const slide =
			typeof instance.getSlide === 'function'
				? instance.getSlide()
				: null;
		if ( ! slide ) {
			return null;
		}

		if ( slide.type && 'image' !== slide.type ) {
			return null;
		}

		let imageNode = slide.imageEl || null;
		if ( ! imageNode && slide.contentEl ) {
			imageNode = slide.contentEl.querySelector(
				'img.fancybox-image, img'
			);
		}
		if ( ! imageNode ) {
			return null;
		}

		return {
			slide,
			imageEl: $( imageNode ),
		};
	}

	/**
	 * @param {unknown} instance
	 */
	function destroyElevateZoomOnInstance( instance ) {
		const resolved = resolveSlideImage( instance );
		if ( ! resolved ) {
			$( '.ZoomContainer' ).remove();
			return;
		}
		const ezPlus = resolved.imageEl.data().ezPlus;
		if ( typeof ezPlus !== 'undefined' && ezPlus.zoomContainer ) {
			ezPlus.zoomContainer.remove();
		}
	}

	/**
	 * @param {unknown} instance
	 * @param {number}  [attempt]
	 */
	function initElevateZoomOnCarousel( instance, attempt ) {
		const tryCount = typeof attempt === 'number' ? attempt : 0;
		const lightbox = resolveLightboxInstance( instance );
		if ( ! lightbox ) {
			return;
		}

		const settings = resolveMzoomSettings( lightbox );
		if ( ! settings ) {
			return;
		}

		const resolved = resolveSlideImage( lightbox );
		if ( ! resolved ) {
			if ( tryCount < MAX_INIT_ATTEMPTS ) {
				requestAnimationFrame( function () {
					initElevateZoomOnCarousel( instance, tryCount + 1 );
				} );
			}
			return;
		}

		const container = $(
			lightbox.container ||
				( typeof lightbox.getContainer === 'function'
					? lightbox.getContainer()
					: null )
		);
		const imageEl = resolved.imageEl;

		if ( typeof $.fn.ezPlus !== 'function' ) {
			return;
		}

		if ( ! settings.zoomOnHover ) {
			container
				.find( '.modula-fancybox-elevatezoom-button' )
				.off( 'click.modulaElevateZoom' )
				.on( 'click.modulaElevateZoom', function () {
					if (
						typeof imageEl.data().ezPlus !== 'undefined' &&
						$( '.ZoomContainer' ).length
					) {
						imageEl.data().ezPlus.zoomContainer.remove();
					} else {
						imageEl.ezPlus( settings );
					}
				} );
			return;
		}

		if ( $( '.ZoomContainer' ).length ) {
			$( '.ZoomContainer' ).remove();
		}

		imageEl.ezPlus( settings );

		imageEl
			.off( 'mouseleave.modulaElevateZoom mouseenter.modulaElevateZoom' )
			.on( 'mouseleave.modulaElevateZoom', function ( e ) {
				e.stopPropagation();
				const ezPlus = imageEl.data().ezPlus;
				if ( typeof ezPlus !== 'undefined' && ezPlus.zoomContainer ) {
					ezPlus.zoomContainer.remove();
				}
			} )
			.on( 'mouseenter.modulaElevateZoom', function ( e ) {
				e.stopPropagation();
				if ( $( '.ZoomContainer' ).length ) {
					$( '.ZoomContainer' ).remove();
				}
				imageEl.ezPlus( settings );
			} );
	}

	/**
	 * @param {Event|jQuery.Event} event
	 */
	function onCarouselLifecycle( event ) {
		const instance =
			( event && event.detail && event.detail.instance ) ||
			( event && event.detail && event.detail.fancybox ) ||
			( arguments.length > 1 ? arguments[ 1 ] : null );
		initElevateZoomOnCarousel( instance );
	}

	/**
	 * @param {Event|jQuery.Event} event
	 */
	function onLightboxClose( event ) {
		const instance =
			( event && event.detail && event.detail.instance ) ||
			( event && event.detail && event.detail.fancybox ) ||
			( arguments.length > 1 ? arguments[ 1 ] : null );
		destroyElevateZoomOnInstance( instance );
	}

	$( function () {
		$( document ).on(
			'modula_fancybox_Carousel_ready modula_fancybox_Carousel_change',
			onCarouselLifecycle
		);
		$( document ).on( 'modula_fancybox_close', onLightboxClose );
	} );

	document.addEventListener(
		'modula_fancybox_Carousel_ready',
		onCarouselLifecycle
	);
	document.addEventListener(
		'modula_fancybox_Carousel_change',
		onCarouselLifecycle
	);
	document.addEventListener(
		'modula_fancybox_custom_Carousel_selectSlide',
		onCarouselLifecycle
	);
	document.addEventListener(
		'modula_fancybox_Carousel_reveal',
		onCarouselLifecycle
	);
	document.addEventListener( 'modula_fancybox_close', onLightboxClose );
	document.addEventListener( 'modula_fancybox_destroy', onLightboxClose );
} )( jQuery );
