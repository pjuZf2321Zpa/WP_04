<?php

namespace Modula_Pro\Extensions\Zoom;

use Modula_Pro\Extensions\Zoom\Admin\Album_Settings;
use Modula_Pro\Extensions\Zoom\Admin\Gallery_Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Zoom {
	/**
	 * Class instance.
	 *
	 * @var Zoom
	 */
	private static $instance;

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Zoom object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Zoom ) ) {
			self::$instance = new Zoom();
		}
		return self::$instance;
	}

	/**
	 * Main construct function for our class
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->require_helper();

		new Enqueue();

		add_action( 'admin_init', array( $this, 'set_admin_requirements' ), 25 );
		add_filter( 'modula_lite_default_settings', array( $this, 'zoom_defaults' ) );
		add_filter( 'modula_gallery_settings', array( $this, 'zoom_gallery_settings' ), 90, 2 );
		add_filter( 'modula_link_gallery_settings', array( $this, 'zoom_gallery_link_settings' ), 10, 2 );
		add_filter( 'modula_fancybox_options', array( $this, 'zoom_fancybox_settings' ), 35, 2 );
		add_filter( 'modula_album_default_settings', array( $this, 'zoom_albums_defaults' ) );

		add_filter( 'modula_album_template_data', array( $this, 'zoom_albums_settings' ) );
		add_filter( 'modula_migrate_gallery_data', array( $this, 'zoom_migrator_data' ), 25, 3 );
	}

	/**
	 * Require helper file
	 *
	 * @since 1.0.0
	 */
	public function require_helper() {
		require_once MODULA_PRO_PATH . 'includes/extensions/zoom/helpers/zoom-helper.php';
	}

	/**
	 * Add Zoom defaults settings
	 *
	 * @param array $defaults
	 *
	 * @return mixed $defaults;
	 * @since 1.0.0
	 */
	public function zoom_defaults( $defaults ) {
		$defaults['enable_zoom']          = 0;
		$defaults['zoom_on_hover']        = 1;
		$defaults['zoom_type']            = 'window';
		$defaults['zoom_effect']          = 'fade_in';
		$defaults['zoom_window_position'] = 'upper_left';
		$defaults['zoom_window_size']     = 'medium';
		$defaults['zoom_lens_size']       = 'medium';
		$defaults['zoom_lens_shape']      = 'round';
		$defaults['zoom_tint_color']      = '';
		$defaults['zoom_tint_opacity']    = 0;

		return $defaults;
	}

	/**
	 * Add Zoom Albums defaults settings
	 *
	 * @param array $defaults
	 *
	 * @return mixed $defaults;
	 * @since 1.0.0
	 */
	public function zoom_albums_defaults( $defaults ) {
		$defaults['enable_zoom_albums']          = 0;
		$defaults['zoom_on_hover_albums']        = 1;
		$defaults['zoom_type_albums']            = 'window';
		$defaults['zoom_effect_albums']          = 'fade_in';
		$defaults['zoom_window_position_albums'] = 'upper_left';
		$defaults['zoom_window_size_albums']     = 'medium';
		$defaults['zoom_lens_size_albums']       = 'medium';
		$defaults['zoom_lens_shape_albums']      = 'round';
		$defaults['zoom_tint_color_albums']      = '';
		$defaults['zoom_tint_opacity_albums']    = 0;

		return $defaults;
	}

	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.0.4
	 */
	public function set_admin_requirements() {
		Album_Settings::get_instance();
		Gallery_Settings::get_instance();
	}

	/**
	 * JS Config for Zoom
	 *
	 * @param array $js_config
	 * @param array $settings
	 *
	 * @return mixed $js_config
	 *
	 * @since 1.0.0
	 */
	public function zoom_gallery_settings( $js_config, $settings ) {

		if ( ! isset( $settings['enable_zoom'] ) || ! modula_zoom_is_enabled( $settings ) ) {
			return $js_config;
		}

		$js_config['lightboxOpts']['mzoom'] = array(
			'zoomType'           => modula_zoom_normalize_type( $settings['zoom_type'] ),
			'zoomOnHover'        => boolval( $settings['zoom_on_hover'] ),
			'zoomWindowPosition' => modula_zoom_get_window_position( $settings['zoom_window_position'] ),
			'zoomWindowWidth'    => modula_zoom_get_window_size( $settings['zoom_window_size'] ),
			'zoomWindowHeight'   => modula_zoom_get_window_size( $settings['zoom_window_size'] ),
			'lensSize'           => modula_zoom_get_window_size( $settings['zoom_lens_size'] ),
			'zoomLensShape'      => $settings['zoom_lens_shape'],
			'lensShape'          => $settings['zoom_lens_shape'],
			'tint'               => 'lens' !== $settings['zoom_type'] ? true : false,
			'tintColour'         => ! empty( $settings['zoom_tint_color'] ) ? $settings['zoom_tint_color'] : '#666',
			'tintOpacity'        => ( ! empty( $settings['zoom_tint_opacity'] ) ? absint( $settings['zoom_tint_opacity'] ) : 0 ) / 100,
			'easing'             => 'easing' === $settings['zoom_effect'] ? true : false,
			'zoomWindowFadeIn'   => 'fade_in' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'lensFadeIn'         => 'fade_in' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zoomTintFadeIn'     => 'fade_in' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zoomWindowFadeOut'  => 'fade_out' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'lensFadeOut'        => 'fade_out' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zoomTintFadeOut'    => 'fade_out' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zIndex'             => 999999999,
		);

		$js_config['lightboxOpts']['Toolbar']['items']['elevateZoom']['tpl'] = '<button title="' . esc_html__( 'Enable zoom', 'modula-pro' ) . '" class="modula-fancybox-elevatezoom-button f-button"><svg tabindex="-1" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="7.5"></circle><path d="m21 21-4.35-4.35M11 8v6M8 11h6"></path></svg></button>';

		return $js_config;
	}

	/**
	 * JS Config & Fancybox Options for [modula-link]
	 *
	 * @param array $link_js_config
	 * @param array $settings
	 *
	 * @return mixed $link_js_config
	 * @since 1.0.0
	 */
	public function zoom_gallery_link_settings( $link_js_config, $settings ) {

		if ( ! isset( $settings['enable_zoom'] ) || ! modula_zoom_is_enabled( $settings ) ) {
			return $link_js_config;
		}

		$link_js_config['lightboxOpts']['mzoom'] = array(
			'zoomType'           => modula_zoom_normalize_type( $settings['zoom_type'] ),
			'zoomOnHover'        => boolval( $settings['zoom_on_hover'] ),
			'zoomWindowPosition' => modula_zoom_get_window_position( $settings['zoom_window_position'] ),
			'zoomWindowWidth'    => modula_zoom_get_window_size( $settings['zoom_window_size'] ),
			'zoomWindowHeight'   => modula_zoom_get_window_size( $settings['zoom_window_size'] ),
			'lensSize'           => modula_zoom_get_window_size( $settings['zoom_lens_size'] ),
			'zoomLensShape'      => $settings['zoom_lens_shape'],
			'lensShape'          => $settings['zoom_lens_shape'],
			'tint'               => 'lens' !== $settings['zoom_type'] ? true : false,
			'tintColour'         => ! empty( $settings['zoom_tint_color'] ) ? $settings['zoom_tint_color'] : '#666',
			'tintOpacity'        => ( ! empty( $settings['zoom_tint_opacity'] ) ? absint( $settings['zoom_tint_opacity'] ) : 0 ) / 100,
			'easing'             => 'easing' === $settings['zoom_effect'] ? true : false,
			'zoomWindowFadeIn'   => 'fade_in' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'lensFadeIn'         => 'fade_in' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zoomTintFadeIn'     => 'fade_in' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zoomWindowFadeOut'  => 'fade_out' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'lensFadeOut'        => 'fade_out' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zoomTintFadeOut'    => 'fade_out' === $settings['zoom_effect'] || 'fade_in_out' === $settings['zoom_effect'] ? 650 : false,
			'zIndex'             => 999999999,
		);

		$link_js_config['lightboxOpts']['Toolbar']['items']['elevateZoom']['tpl'] = '<button title="' . esc_html__( 'Enable zoom', 'modula-pro' ) . '" class="modula-fancybox-elevatezoom-button f-button"><svg tabindex="-1" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="7.5"></circle><path d="m21 21-4.35-4.35M11 8v6M8 11h6"></path></svg></button>';

		return $link_js_config;
	}

	/**
	 * Removes default zoom buttons in case elevate zoom is used.
	 *
	 * @param array $fancybox_options
	 * @param array $settings
	 *
	 * @return mixed $fancybox_options
	 * @since 1.0.0
	 */
	public function zoom_fancybox_settings( $fancybox_options, $settings ) {

		if ( ! isset( $settings['enable_zoom'] ) || ! modula_zoom_is_enabled( $settings ) ) {
			return $fancybox_options;
		}

		// Look for zoom button
		$key = array_search( 'zoom', $fancybox_options['buttons'], true );

		// if found remove zoom button
		if ( false !== $key ) {
			unset( $fancybox_options['buttons'][ $key ] );
		}

		// if zoom on hover is disabled, show elevateZoom toolbar button.
		if ( ! isset( $settings['zoom_on_hover'] ) || ! $settings['zoom_on_hover'] ) {
			$fancybox_options['Toolbar']['display']['right'][] = 'elevateZoom';
		}

		$fancybox_options['compact']         = false;
		$fancybox_options['contentClick']    = false;
		$fancybox_options['contentDblClick'] = false;
		$fancybox_options['buttons']         = array_values( $fancybox_options['buttons'] );

		return $fancybox_options;
	}

	/**
	 * Add Zoom Albums settings to template data
	 *
	 * @param array $template_data
	 *
	 * @return mixed $template_data
	 * @since 1.0.0
	 */
	public function zoom_albums_settings( $template_data ) {
		if ( ! isset( $template_data['settings']['enable_zoom_albums'] ) || 1 !== (int) $template_data['settings']['enable_zoom_albums'] ) {
			return $template_data;
		}

		$template_data['js_config']['lightbox_settings']['mzoom'] = array(
			'zoomType'           => modula_zoom_normalize_type( $template_data['settings']['zoom_type_albums'] ),
			'zoomOnHover'        => boolval( $template_data['settings']['zoom_on_hover_albums'] ),
			'zoomWindowPosition' => modula_zoom_get_window_position( $template_data['settings']['zoom_window_position_albums'] ),
			'zoomWindowWidth'    => modula_zoom_get_window_size( $template_data['settings']['zoom_window_size_albums'] ),
			'zoomWindowHeight'   => modula_zoom_get_window_size( $template_data['settings']['zoom_window_size_albums'] ),
			'lensSize'           => modula_zoom_get_window_size( $template_data['settings']['zoom_lens_size_albums'] ),
			'zoomLensShape'      => $template_data['settings']['zoom_lens_shape_albums'],
			'lensShape'          => $template_data['settings']['zoom_lens_shape_albums'],
			'tint'               => 'lens' !== $template_data['settings']['zoom_type_albums'] ? true : false,
			'tintColour'         => $template_data['settings']['zoom_tint_color_albums'],
			'tintOpacity'        => isset( $template_data['settings']['zoom_tint_opacity_albums'] ) && '' !== $template_data['settings']['zoom_tint_opacity_albums'] ? absint( $template_data['settings']['zoom_tint_opacity_albums'] ) / 100 : 0,
			'easing'             => 'easing' === $template_data['settings']['zoom_effect_albums'] ? true : false,
			'zoomWindowFadeIn'   => 'fade_in' === $template_data['settings']['zoom_effect_albums'] || 'fade_in_out' === $template_data['settings']['zoom_effect_albums'] ? 650 : false,
			'lensFadeIn'         => 'fade_in' === $template_data['settings']['zoom_effect_albums'] || 'fade_in_out' === $template_data['settings']['zoom_effect_albums'] ? 650 : false,
			'zoomTintFadeIn'     => 'fade_in' === $template_data['settings']['zoom_effect_albums'] || 'fade_in_out' === $template_data['settings']['zoom_effect_albums'] ? 650 : false,
			'zoomWindowFadeOut'  => 'fade_out' === $template_data['settings']['zoom_effect_albums'] || 'fade_in_out' === $template_data['settings']['zoom_effect_albums'] ? 650 : false,
			'lensFadeOut'        => 'fade_out' === $template_data['settings']['zoom_effect_albums'] || 'fade_in_out' === $template_data['settings']['zoom_effect_albums'] ? 650 : false,
			'zoomTintFadeOut'    => 'fade_out' === $template_data['settings']['zoom_effect_albums'] || 'fade_in_out' === $template_data['settings']['zoom_effect_albums'] ? 650 : false,
			'zIndex'             => 999999999,
		);

		if ( isset( $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'] ) ) {
			// Look for zoom button
			$key = array_search( 'iterateZoom', $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'], true );

			// if found remove zoom button
			if ( false !== $key ) {
				unset( $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'][ $key ] );
			}
		}

		// if zoom on hover is disabled, show elevateZoom toolbar button.
		if ( ! isset( $template_data['settings']['zoom_on_hover_albums'] ) || ! $template_data['settings']['zoom_on_hover_albums'] ) {
			$template_data['js_config']['lightbox_settings']['Toolbar']['items']['elevateZoom']['tpl'] = '<button title="' . esc_html__( 'Enable zoom', 'modula-pro' ) . '" class="modula-fancybox-elevatezoom-button f-button"><svg tabindex="-1" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="7.5"></circle><path d="m21 21-4.35-4.35M11 8v6M8 11h6"></path></svg></button>';
			array_unshift( $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'], 'elevateZoom' );
		}

		$template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'] = array_values( $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'] );

		$template_data['js_config']['lightbox_settings']['compact']         = false;
		$template_data['js_config']['lightbox_settings']['contentClick']    = false;
		$template_data['js_config']['lightbox_settings']['contentDblClick'] = false;

		$template_data['album_container']['data-config'] = wp_json_encode( $template_data['js_config'] );

		return $template_data;
	}

	/**
	 * Add Modula Zoom data to migrator
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.1
	 */
	public function zoom_migrator_data( $modula_settings, $guest_settings, $source ) {
		switch ( $source ) {
			case 'envira':
				if ( isset( $guest_settings['config']['zoom'] ) && 1 === (int) $guest_settings['config']['zoom'] ) {
					$modula_settings['enable_zoom'] = 1;
				}

				if ( isset( $guest_settings['config']['zoom_hover'] ) && 1 === (int) $guest_settings['config']['zoom_hover'] ) {
					$modula_settings['zoom_on_hover'] = 1;
				} else {
					$modula_settings['zoom_on_hover'] = 0;
				}

				if ( isset( $guest_settings['config']['zoom_effect'] ) ) {
					if ( 'no-effect' === $guest_settings['config']['zoom_effect'] ) {
						$modula_settings['zoom_effect'] = 'none';
					} else {
						$modula_settings['zoom_effect'] = str_replace( '-', '_', $guest_settings['config']['zoom_effect'] );
					}
				}

				if ( isset( $guest_settings['config']['zoom_type'] ) ) {
					if ( 'basic' === $guest_settings['config']['zoom_type'] ) {
						$modula_settings['zoom_type'] = 'window';
					} else {
						$modula_settings['zoom_type'] = $guest_settings['config']['zoom_type'];
					}
				}

				if ( isset( $guest_settings['config']['zoom_lens_shape'] ) ) {
					$modula_settings['zoom_lens_shape'] = $guest_settings['config']['zoom_lens_shape'];
				}

				if ( isset( $guest_settings['config']['zoom_position'] ) ) {
					$modula_settings['zoom_window_position'] = str_replace( '-', '_', $guest_settings['config']['zoom_position'] );
				}

				if ( isset( $guest_settings['config']['zoom_window_size'] ) ) {
					if ( 'x-large' === $guest_settings['config']['zoom_window_size'] ) {
						$modula_settings['zoom_window_size'] = 'xlarge';
					} else {
						$modula_settings['zoom_window_size'] = $guest_settings['config']['zoom_window_size'];
					}
				}

				if ( isset( $guest_settings['config']['zoom_tint_color'] ) ) {
					$modula_settings['zoom_tint_color'] = '#' . $guest_settings['config']['zoom_tint_color'];
				}

				if ( isset( $guest_settings['config']['zoom_tint_color_opacity'] ) ) {
					$modula_settings['zoom_tint_opacity'] = $guest_settings['config']['zoom_tint_color_opacity'];
				}

				break;
			default:
				break;
		}

		return $modula_settings;
	}
}
