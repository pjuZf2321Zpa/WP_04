<?php

namespace Modula_Pro\Extensions\Zoom\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Gallery_Settings {
		/**
	 * Holds the admnin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Main construct function for our class
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		//Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_zoom_field' ) );

		//Filter Modula Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'modula_zoom_tab' ), 99 );
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @since 1.0.0
	 *
	 * @return object Modula_Zoom_Settings object
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Gallery_Settings ) ) {
			self::$instance = new Gallery_Settings();
		}

		return self::$instance;
	}

	/**
	 * Add the Zoom tab in settings
	 *
	 * @param array $tabs
	 *
	 * @return mixed $tabs
	 * @since 1.0.0
	 *
	 */
	public function modula_zoom_tab( $tabs ) {
		$tabs['zoom'] = array(
			'label'    => esc_html__( 'Zoom', 'modula-pro' ),
			'title'    => esc_html__( 'Zoom Settings', 'modula-pro' ),
			'docs_url' => 'https://wp-modula.com/kb/modula-zoom/',
			'icon'     => 'dashicons dashicons-search',
			'priority' => 85,
		);

		if ( isset( $tabs['zoom']['badge'] ) ) {
			unset( $tabs['zoom']['badge'] );
		}

		return $tabs;
	}

	/**
	 * Add zoom fields in settings
	 *
	 * @param array $fields
	 *
	 * @return mixed $fields
	 * @since 1.0.0
	 *
	 */
	public function modula_zoom_field( $fields ) {
		$fields['zoom'] = array(
			'enable_zoom'          => array(
				'name'      => esc_html__( 'Zoom', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 1,
				'children'  => array( 'zoom_on_hover', 'zoom_type', 'zoom_effect', 'zoom_window_position', 'zoom_window_size', 'zoom_lens_size', 'zoom_lens_shape', 'zoom_tint_color', 'zoom_tint_opacity' ),
				'data_type' => 'bool',
			),
			'zoom_on_hover'        => array(
				'name'      => esc_html__( 'Zoom on hover', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 3,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'zoom_type'            => array(
				'name'      => esc_html__( 'Type of zoom', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'window' => esc_html__( 'Basic', 'modula-pro' ),
					'inner'  => esc_html__( 'Inner', 'modula-pro' ),
					'lens'   => esc_html__( 'Lens', 'modula-pro' ),
				),
				'default'   => 'basic',
				'priority'  => 5,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_effect'          => array(
				'name'      => esc_html__( 'Zoom effect', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'none'        => esc_html__( 'No effect', 'modula-pro' ),
					'fade_in'     => esc_html__( 'Fade in', 'modula-pro' ),
					'fade_out'    => esc_html__( 'Fade out', 'modula-pro' ),
					'fade_in_out' => esc_html__( 'Fade in/out', 'modula-pro' ),
					'easing'      => esc_html__( 'Easing', 'modula-pro' ),
				),
				'default'   => 'fade_in',
				'priority'  => 10,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_window_position' => array(
				'name'      => esc_html__( 'Zoom window position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'upper_left'  => esc_html__( 'Upper left', 'modula-pro' ),
					'upper_right' => esc_html__( 'Upper right', 'modula-pro' ),
					'lower_left'  => esc_html__( 'Lower left', 'modula-pro' ),
					'lower_right' => esc_html__( 'Lower right', 'modula-pro' ),
				),
				'default'   => 'upper_left',
				'priority'  => 15,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_window_size'     => array(
				'name'      => esc_html__( 'Zoom window size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'small'  => esc_html__( 'Small', 'modula-pro' ),
					'medium' => esc_html__( 'Medium', 'modula-pro' ),
					'large'  => esc_html__( 'Large', 'modula-pro' ),
					'xlarge' => esc_html__( 'Extra large', 'modula-pro' ),
				),
				'default'   => 'medium',
				'priority'  => 20,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_lens_size'       => array(
				'name'      => esc_html__( 'Lens size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'small'  => esc_html__( 'Small', 'modula-pro' ),
					'medium' => esc_html__( 'Medium', 'modula-pro' ),
					'large'  => esc_html__( 'Large', 'modula-pro' ),
					'xlarge' => esc_html__( 'Extra large', 'modula-pro' ),
				),
				'default'   => 'medium',
				'priority'  => 25,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_lens_shape'      => array(
				'name'      => esc_html__( 'Zoom lens shape', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'round'  => esc_html__( 'Round', 'modula-pro' ),
					'square' => esc_html__( 'Square', 'modula-pro' ),
				),
				'default'   => 'round',
				'priority'  => 30,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_tint_color'      => array(
				'name'      => esc_html__( 'Tint color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '',
				'priority'  => 35,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_tint_opacity'    => array(
				'name'      => esc_html__( 'Tint opacity', 'modula-pro' ),
				'type'      => 'ui-slider',
				'default'   => 0,
				'min'       => 0,
				'max'       => 100,
				'step'      => 1,
				'priority'  => 40,
				'is_child'  => true,
				'data_type' => 'number',
			),
		);

		return $fields;
	}
}
