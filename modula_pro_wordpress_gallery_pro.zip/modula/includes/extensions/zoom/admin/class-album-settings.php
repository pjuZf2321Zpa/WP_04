<?php

namespace Modula_Pro\Extensions\Zoom\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Album_Settings {
	/**
	 * Holds the admin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Main construct function for our class
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		//Filter Modula Fields
		add_filter( 'modula_album_fields', array( $this, 'modula_zoom_albums_field' ) );

		//Filter Modula Tab
		add_filter( 'modula_album_tabs', array( $this, 'modula_zoom_albums_tab' ) );

		add_action( 'modula_album_scripts_after_wp_modula', array( $this, 'modula_zoom_album_admin_scripts' ) );
		add_action( 'modula_defaults_album_scripts_after_wp_modula', array( $this, 'modula_zoom_album_admin_scripts' ) );
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @since 1.0.0
	 *
	 * @return object Modula_Zoom_Albums_Settings object
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Album_Settings ) ) {
			self::$instance = new Album_Settings();
		}

		return self::$instance;
	}

	/**
	 * Enqueue admin conditions
	 *
	 * @since 1.0.0
	 */
	public function modula_zoom_album_admin_scripts() {
		modula_pro_ensure_condition_scripts_registered();
		wp_enqueue_script( 'modula-zoom-album-conditions', \MODULA_PRO_URL . 'includes/extensions/zoom/assets/js/modula-zoom-album-conditions.js', array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Add the Zoom tab in settings
	 *
	 * @param array $tabs
	 *
	 * @return mixed $tabs
	 * @since 1.0.0
	 *
	 */
	public function modula_zoom_albums_tab( $tabs ) {
		$tabs['zoom'] = array(
			'label'    => esc_html__( 'Zoom', 'modula-pro' ),
			'title'    => esc_html__( 'Zoom Settings', 'modula-pro' ),
			'icon'     => 'dashicons dashicons-search',
			'docs_url' => 'https://wp-modula.com/kb/modula-zoom/',
			'priority' => 85,
		);
		return $tabs;
	}

	/**
	 * Add zoom fields in settings
	 *
	 * @param array $fields
	 *
	 * @return mixed $fields
	 * @since 1.0.0
	 *
	 */
	public function modula_zoom_albums_field( $fields ) {
		$fields['zoom'] = array(
			'enable_zoom_albums'          => array(
				'name'      => esc_html__( 'Enable Zoom', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 1,
				'children'  => array( 'zoom_on_hover_albums', 'zoom_type_albums', 'zoom_effect_albums', 'zoom_window_position_albums', 'zoom_window_size_albums', 'zoom_lens_size_albums', 'zoom_lens_shape_albums', 'zoom_tint_color_albums', 'zoom_tint_opacity_albums' ),
				'data_type' => 'bool',
			),
			'zoom_on_hover_albums'        => array(
				'name'      => esc_html__( 'Zoom on Hover', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 3,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'zoom_type_albums'            => array(
				'name'      => esc_html__( 'Type of zoom', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'window' => esc_html__( 'Basic', 'modula-pro' ),
					'inner'  => esc_html__( 'Inner', 'modula-pro' ),
					'lens'   => esc_html__( 'Lens', 'modula-pro' ),
				),
				'default'   => 'basic',
				'priority'  => 5,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_effect_albums'          => array(
				'name'      => esc_html__( 'Zoom effect', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'none'        => esc_html__( 'No effect', 'modula-pro' ),
					'fade_in'     => esc_html__( 'Fade In', 'modula-pro' ),
					'fade_out'    => esc_html__( 'Fade Out', 'modula-pro' ),
					'fade_in_out' => esc_html__( 'Fade In Out', 'modula-pro' ),
					'easing'      => esc_html__( 'Easing', 'modula-pro' ),
				),
				'default'   => 'fade_in',
				'priority'  => 10,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_window_position_albums' => array(
				'name'      => esc_html__( 'Zoom window position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'upper_left'  => esc_html__( 'Upper Left', 'modula-pro' ),
					'upper_right' => esc_html__( 'Upper Right', 'modula-pro' ),
					'lower_left'  => esc_html__( 'Lower Left', 'modula-pro' ),
					'lower_right' => esc_html__( 'Lower Right', 'modula-pro' ),
				),
				'default'   => 'upper_left',
				'priority'  => 15,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_window_size_albums'     => array(
				'name'      => esc_html__( 'Zoom window size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'small'  => esc_html__( 'Small', 'modula-pro' ),
					'medium' => esc_html__( 'Medium', 'modula-pro' ),
					'large'  => esc_html__( 'Large', 'modula-pro' ),
					'xlarge' => esc_html__( 'Extra Large', 'modula-pro' ),
				),
				'default'   => 'medium',
				'priority'  => 20,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_lens_size_albums'       => array(
				'name'      => esc_html__( 'Lens Size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'small'  => esc_html__( 'Small', 'modula-pro' ),
					'medium' => esc_html__( 'Medium', 'modula-pro' ),
					'large'  => esc_html__( 'Large', 'modula-pro' ),
					'xlarge' => esc_html__( 'Extra Large', 'modula-pro' ),
				),
				'default'   => 'medium',
				'priority'  => 25,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_lens_shape_albums'      => array(
				'name'      => esc_html__( 'Zoom lens shape', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'round'  => esc_html__( 'Round', 'modula-pro' ),
					'square' => esc_html__( 'Square', 'modula-pro' ),
				),
				'default'   => 'round',
				'priority'  => 30,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_tint_color_albums'      => array(
				'name'      => esc_html__( 'Tint Color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '',
				'priority'  => 35,
				'is_child'  => true,
				'data_type' => 'text',
			),
			'zoom_tint_opacity_albums'    => array(
				'name'      => esc_html__( 'Tint Opacity', 'modula-pro' ),
				'type'      => 'ui-slider',
				'default'   => 0,
				'min'       => 0,
				'max'       => 100,
				'step'      => 1,
				'priority'  => 40,
				'is_child'  => true,
				'data_type' => 'number',
			),
		);

		return $fields;
	}
}
