<?php
namespace Modula_Pro\Extensions\Zoom;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/zoom';

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'modula_extra_scripts', array( $this, 'zoom_scripts' ) );
		add_action( 'modula_link_extra_scripts', array( $this, 'zoom_scripts' ) );
		add_action( 'modula_album_extra_scripts', array( $this, 'zoom_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'zoom_settings_editor_scripts' ), 30 );
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'zoom_admin_scripts' ) );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'zoom_admin_scripts' ) );
		add_filter( 'modula_shortcode_css', array( $this, 'zoom_css' ), 25, 3 );
		add_filter( 'modula_link_shortcode_css', array( $this, 'zoom_css' ), 25, 3 );
		add_filter( 'modula_album_shortcode_css', array( $this, 'albums_zoom_css' ), 25, 3 );
	}

	public function register_scripts() {
		wp_register_script( 'modula-elevate-zoom', \MODULA_PRO_URL . $this->extension_url . '/assets/js/jquery.elevatezoom.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-zoom-js', \MODULA_PRO_URL . $this->extension_url . '/assets/js/fancybox-modula-zoom.js', array( 'jquery', 'modula-elevate-zoom' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-zoom-link-js', \MODULA_PRO_URL . $this->extension_url . '/assets/js/fancybox-modula-link-zoom.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-zoom-albums-js', \MODULA_PRO_URL . $this->extension_url . '/assets/js/fancybox-modula-albums-zoom.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Whether the modern v2 React gallery stack is active.
	 *
	 * @return bool
	 */
	private function is_modern_stack_enabled( $post_id = 0 ) {
		return class_exists( '\Modula\V2\Modern_Gallery' )
			&& \Modula\V2\Modern_Gallery::is_modern_stack_enabled( (int) $post_id );
	}

	/**
	 * Enqueue elevateZoom bridge for the v2 settings editor live lightbox preview.
	 *
	 * @param string $hook_suffix Current admin screen hook.
	 * @return void
	 */
	public function zoom_settings_editor_scripts( $hook_suffix ) {
		if ( ! $this->is_modern_gallery_settings_editor_screen( $hook_suffix ) ) {
			return;
		}

		$this->enqueue_zoom_runtime_scripts();
		$this->enqueue_zoom_container_css( 'modula-gallery-preview-front' );
	}

	/**
	 * @param string $hook_suffix Current admin screen hook.
	 * @return bool
	 */
	private function is_modern_gallery_settings_editor_screen( $hook_suffix ) {
		$post_id = 0;
		if ( class_exists( '\Modula\V2\Beta_Settings' ) ) {
			$post_id = \Modula\V2\Beta_Settings::current_gallery_id();
		}
		if ( ! apply_filters( 'modula_enable_modern_settings_editor', false, $post_id ) ) {
			return false;
		}

		if ( 'post.php' !== $hook_suffix && 'post-new.php' !== $hook_suffix ) {
			return false;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return $screen && 'modula-gallery' === $screen->post_type;
	}

	/**
	 * Enqueue necessary zoom scripts
	 *
	 * @param array $settings
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function zoom_scripts( $settings ) {

		$post_id = 0;
		if ( class_exists( '\Modula\V2\Modern_Gallery' ) && is_array( $settings ) ) {
			$post_id = \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( $settings );
		}
		if ( $this->is_modern_stack_enabled( $post_id ) ) {
			return;
		}

		if ( isset( $settings['enable_zoom'] ) && modula_zoom_is_enabled( $settings ) ) {
			$this->enqueue_zoom_runtime_scripts();
		}

		if ( isset( $settings['enable_zoom_albums'] ) && 1 === (int) $settings['enable_zoom_albums'] ) {
			$this->enqueue_zoom_runtime_scripts();
		}
	}

	/**
	 * @return void
	 */
	private function enqueue_zoom_runtime_scripts() {
		wp_enqueue_script( 'modula-elevate-zoom' );
		wp_enqueue_script( 'modula-zoom-js' );
	}

	/**
	 * @param string $style_handle Optional style handle to attach inline CSS to.
	 * @return void
	 */
	private function enqueue_zoom_container_css( $style_handle = '' ) {
		$css = '.zoomContainer {z-index: 300000000!important;}';

		if ( is_string( $style_handle ) && '' !== $style_handle && wp_style_is( $style_handle, 'enqueued' ) ) {
			wp_add_inline_style( $style_handle, $css );
			return;
		}

		wp_register_style( 'modula-zoom-container', false, array(), \MODULA_PRO_VERSION );
		wp_enqueue_style( 'modula-zoom-container' );
		wp_add_inline_style( 'modula-zoom-container', $css );
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function zoom_admin_scripts() {
		wp_enqueue_script( 'modula-zoom-conditions', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-zoom-conditions.js', array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Add inline CSS for Modula Gallery
	 *
	 * @param string $css
	 * @param string $gallery_id
	 * @param array  $settings
	 *
	 * @return string
	 * @since 1.0.0
	 */
	public function zoom_css( $css, $gallery_id, $settings ) {

		if ( ! isset( $settings['enable_zoom'] ) || ! modula_zoom_is_enabled( $settings ) ) {
			return $css;
		}

		$css .= '.zoomContainer {z-index: 300000000!important;}';

		return $css;
	}

	/**
	 * Add inline CSS for Modula Albums
	 *
	 * @param string $css
	 * @param string $gallery_id
	 * @param array  $settings
	 *
	 * @return string
	 * @since 1.0.0
	 */
	public function albums_zoom_css( $css, $gallery_id, $settings ) {

		if ( ! isset( $settings['enable_zoom_albums'] ) || 1 !== (int) $settings['enable_zoom_albums'] ) {
			return $css;
		}

		$css .= '.zoomContainer {z-index: 300000000!important;}';

		return $css;
	}
}
