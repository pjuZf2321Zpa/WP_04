<?php

/**
 * Format the window position into something readable
 * by elevatezoom
 *
 * @param $pos
 *
 * @return int
 *
 */
function modula_zoom_get_window_position( $pos ) {
	switch ( $pos ) {
		case 'upper_left':
			return 11;
		case 'upper_right':
			return 1;
		case 'lower_left':
			return 9;
		case 'lower_right':
			return 3;
	}
}

/**
 * Format the window size into number
 *
 * @param $size
 * @return int
 */
function modula_zoom_get_window_size( $size ) {
	switch ( $size ) {
		case 'small':
			return 100;
		case 'medium':
			return 200;
		case 'large':
			return 300;
		case 'xlarge':
			return 350;
		default:
			return 100;
	}
}

/**
 * Legacy galleries stored `basic`; elevateZoom expects `window`.
 *
 * @param string $type Stored zoom type.
 * @return string
 */
function modula_zoom_normalize_type( $type ) {
	if ( ! is_string( $type ) || '' === $type || 'basic' === $type ) {
		return 'window';
	}
	return $type;
}

/**
 * Whether gallery flat settings have zoom enabled (boolean, int, or string).
 *
 * @param array $settings Flat gallery settings.
 * @return bool
 */
function modula_zoom_is_enabled( $settings ) {
	if ( ! is_array( $settings ) || ! array_key_exists( 'enable_zoom', $settings ) ) {
		return false;
	}

	$value = $settings['enable_zoom'];

	return true === $value || 1 === (int) $value;
}
