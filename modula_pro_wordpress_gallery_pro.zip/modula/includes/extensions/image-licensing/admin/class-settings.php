<?php
namespace Modula_Pro\Extensions\Image_Licensing\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main class for Image Licensing global settings
 */
class Settings {

	/**
	 * Holds the admin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class construct
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		//Filter Modula Fields
		add_filter( 'modula_gallery_tabs', array( $this, 'set_ia_gallery_tab' ) );
		add_filter( 'modula_gallery_fields', array( $this, 'set_ia_gallery_fields' ) );

		// Template for Image Attribution
		add_action( 'admin_footer', array( $this, 'print_modula_ia_templates' ) );

		// Save Filters for our items
		add_filter( 'modula_gallery_image_attributes', array( $this, 'ia_add_item_fields' ) );

		// Add meta to image model
		add_filter( 'modula_image_properties', array( $this, 'modula_ia_add_metadata' ) );

		add_filter( 'modula_render_image_licensing_select_field_type', array( $this, 'licensing_select_field_type' ), 10, 5 );
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @return object Modula Image Licensing Settings object
	 *
	 *  @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Settings ) ) {
			self::$instance = new Settings();
		}

		return self::$instance;
	}

	/**
	 * Sets the licensing settings tab in Modula Settings
	 *
	 * @param $license_key
	 * @param $store_url
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function set_ia_gallery_tab( $tabs ) {
		$tabs['image_licensing'] = array(
			'label'    => esc_html__( 'Image Licensing', 'modula-pro' ),
			'title'    => esc_html__( 'Image Licensing Settings', 'modula-pro' ),
			'docs_url' => 'https://wp-modula.com/kb/image-licensing-settings/',
			'icon'     => 'dashicons dashicons-images-alt2',
			'priority' => 50,
		);

		return $tabs;
	}

	/**
	 * Sets the licensing settings
	 *
	 * @param $license_key
	 * @param $store_url
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function set_ia_gallery_fields( $fields ) {
		$options = array();
		foreach ( \Modula_Helper::get_image_licenses() as $key => $value ) {
			$options[ $key ] = $value['name'];
		}
		$fields['image_licensing'] = array(
			'image_licensing'          => array(
				'name'     => esc_html__( 'Select license type', 'modula-pro' ),
				'default'  => 'none',
				'type'     => 'image_licensing_select',
				'values'   => $options,
				'priority' => 10,
			),
			'display_with_description' => array(
				'name'     => esc_html__( 'Display in description', 'modula-pro' ),
				'type'     => 'toggle',
				'default'  => 0,
				'priority' => 20,
			),
			'show_on_lightbox'         => array(
				'name'     => esc_html__( 'Show license in lightbox', 'modula-pro' ),
				'type'     => 'toggle',
				'default'  => 0,
				'priority' => 30,
			),
		);
		return $fields;
	}

	/**
	 * Add ia information to edit modal
	 *
	 * @param $fields
	 *
	 * @return mixed $fields
	 *
	 * @since 1.0.0
	 */
	public function ia_add_item_fields( $fields ) {
		$fields[] = 'image_licensing';

		return $fields;
	}

	/**
	 * Add ia meta to image model
	 *
	 * @param $image
	 *
	 * @return mixed $image
	 *
	 * @since 1.0.0
	 */
	public function modula_ia_add_metadata( $image ) {

		$meta = wp_get_attachment_metadata( $image['id'] );

		if ( isset( $image['image_licensing'] ) && '' === $image['image_licensing'] ) {
			$image['image_licensing'] = isset( $meta['image_meta']['image_licensing'] ) ? $meta['image_meta']['image_licensing'] : 'none';
		}

		return $image;
	}

	/**
	 * Renders and sets the template for gallery images individual license.
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function print_modula_ia_templates() {
		$image_licenses = \Modula_Helper::get_image_licenses();
		?>
		<script type="text/html" id="tmpl-modula-image_licensing">

			<span class="name"><?php esc_html_e( 'Image Licensing', 'modula-pro' ); ?></span>
			<select name="image_licensing" class="inline-input image-image-licensing-selector">
				<?php foreach ( $image_licenses as $key => $val ) : ?>
				<option value="<?php echo esc_html( $key ); ?>" <# if ( <?php echo "'" . esc_html( $key ) . "'"; ?> === data.image_licensing ) { #> selected <# } #>><?php echo esc_html( $val['name'] ); ?></option>
				<?php endforeach; ?>
			</select>

		</script>
		<?php
	}

	/**
	 * Renders the licensing select field type.
	 *
	 * @return void
	 *
	 * @since 1.0.2
	 */
	public function licensing_select_field_type( $html, $field, $value ) {
		$ccs  = \Modula_Helper::get_image_licenses();
		$html = '<div class="modula-image-licensing-radio-wrapper">';

		foreach ( $field['values'] as $val_key => $val ) {
			if ( ! isset( $ccs[ $val_key ] ) ) {
				continue;
			}

			$cc = $ccs[ $val_key ];

			$checked = ( $val_key === $value ) ? 'checked="checked"' : '';

			$html .= '
            <input
                ' . $checked . '
                id="modula_image_licensing_license_' . esc_attr( $val_key ) . '"
                class="modula_image_licensing_radio_input"
                type="radio"
                name="modula-settings[' . esc_attr( $field['id'] ) . ']"
                data-setting="modula-settings[' . esc_attr( $field['id'] ) . ']"
                value="' . esc_attr( $val_key ) . '">';

			$html .= '<label class="modula-image-licensing-radio-icon" for="modula_image_licensing_license_' . esc_attr( $val_key ) . '">';

			if ( isset( $cc['image'] ) && $cc['image'] !== '' ) {
				$html .= '<img alt="Creative Commons License" style="border-width:0" src="' . esc_url( $cc['image'] ) . '"/>';
			}

			if ( isset( $cc['license'] ) && $cc['license'] !== '' ) {
				// translators: %s is the license name.
				$html .= '<span class="modula-image-licensing-radio-name">' . sprintf( __( 'This work is licensed under a %s', 'modula-pro' ), esc_html( $cc['name'] ) ) . '</span>';
			} else {
				// translators: %s is the license name.
				$html .= '<span class="modula-image-licensing-radio-name">' . esc_html__( 'None', 'modula-pro' ) . '</span>';
			}

			$html .= '</label>';
		}

		$html .= '</div>';

		return $html;
	}
}
