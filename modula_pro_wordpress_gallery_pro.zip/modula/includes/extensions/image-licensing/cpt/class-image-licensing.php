<?php
namespace Modula_Pro\Extensions\Image_Licensing\CPT;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main class for Image Licenses CPT
 */
class Image_Licensing {

	private $cpt_name;
	private $metaboxes   = array();
	private $labels      = array();
	private $args        = array();
	private $column_data = null;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->column_data = new \stdClass();

		add_action( 'init', array( $this, 'register_cpt' ) );
		add_action( 'admin_menu', array( $this, 'reorder_submenu' ), 999 );

		add_action( 'wp_ajax_dismiss_image_licensing_notice', array( $this, 'dismiss_image_licensing_notice' ) );

		/* Fire our meta box setup function on the post editor screen. */
		add_action( 'load-post.php', array( $this, 'meta_boxes_setup' ) );
		add_action( 'load-post-new.php', array( $this, 'meta_boxes_setup' ) );

		// Post Table Columns
		add_filter( 'manage_edit-modula-image-licensing_columns', array( $this, 'add_columns' ) );
		add_action( 'manage_modula-image-licensing_posts_custom_column', array( $this, 'column_data' ), 2 );
		add_filter( 'manage_edit-modula-image-licensing_sortable_columns', array( $this, 'sortable_columns' ) );
		add_filter( 'list_table_primary_column', array( $this, 'set_primary_column_name' ), 10, 2 );

		// Remove upsell licensing menu item.
		add_filter( 'modula_admin_page_link', array( $this, 'remove_menu_upsell' ) );
	}

	/**
	 * Registers the licenses CPT
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function register_cpt() {

		$this->labels = apply_filters(
			'modula_image_licensing_cpt_labels',
			array(
				'name'                  => esc_html__( 'Image Licensing', 'modula-pro' ),
				'singular_name'         => esc_html__( 'Image Licensing', 'modula-pro' ),
				'menu_name'             => esc_html__( 'Modula Image Licensing', 'modula-pro' ),
				'name_admin_bar'        => esc_html__( 'Modula Image Licensing', 'modula-pro' ),
				'archives'              => esc_html__( 'License Archives', 'modula-pro' ),
				'attributes'            => esc_html__( 'License Attributes', 'modula-pro' ),
				'parent_item_colon'     => esc_html__( 'Parent License:', 'modula-pro' ),
				'all_items'             => esc_html__( 'Image Licenses', 'modula-pro' ),
				'add_new_item'          => esc_html__( 'Add New License', 'modula-pro' ),
				'add_new'               => esc_html__( 'Add New', 'modula-pro' ),
				'new_item'              => esc_html__( 'New License', 'modula-pro' ),
				'edit_item'             => esc_html__( 'Edit License', 'modula-pro' ),
				'update_item'           => esc_html__( 'Update License', 'modula-pro' ),
				'view_item'             => esc_html__( 'View License', 'modula-pro' ),
				'view_items'            => esc_html__( 'View Licenses', 'modula-pro' ),
				'search_items'          => esc_html__( 'Search Licenses', 'modula-pro' ),
				'not_found'             => '<a href="' . admin_url( 'post-new.php?post_type=modula-image-license' ) . '">' . esc_html__( 'Add your first license ', 'modula-pro' ) . '</a>' . esc_html__( 'now or check out our ', 'modula-pro' ) . '<a href="' . esc_url( 'https://wp-modula.com/knowledge-base/' ) . '" target="_blank">' . esc_html__( 'documentation ', 'modula-pro' ) . '</a>' . esc_html__( 'if you need help figuring things out.', 'modula-pro' ),
				'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'modula-pro' ),
				'featured_image'        => esc_html__( 'Featured License', 'modula-pro' ),
				'set_featured_image'    => esc_html__( 'Set featured image', 'modula-pro' ),
				'remove_featured_image' => esc_html__( 'Remove featured image', 'modula-pro' ),
				'use_featured_image'    => esc_html__( 'Use as featured image', 'modula-pro' ),
				'insert_into_item'      => esc_html__( 'Insert into license', 'modula-pro' ),
				'uploaded_to_this_item' => esc_html__( 'Uploaded to this license', 'modula-pro' ),
				'items_list'            => esc_html__( 'Licenses list', 'modula-pro' ),
				'items_list_navigation' => esc_html__( 'Licenses list navigation', 'modula-pro' ),
				'filter_items_list'     => esc_html__( 'Filter licenses list', 'modula-pro' ),
			),
			$this->labels
		);

		$this->args = apply_filters(
			'modula_image_licensing_cpt_args',
			array(
				'label'               => esc_html__( 'Modula Image Licensing', 'modula-pro' ),
				'description'         => esc_html__( 'Modula is the most powerful, user-friendly WordPress gallery plugin. Add galleries, masonry grids and more in a few clicks.', 'modula-pro' ),
				'supports'            => array( 'title', 'thumbnail' ),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => 'edit.php?post_type=modula-gallery',
				'menu_icon'           => 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 32 32"><path fill="#f0f5fa" d="M9.3 25.3c-2.4-0.7-4.7-1.4-7.1-2.1 2.4-3.5 4.7-7 7-10.5C9.3 12.9 9.3 24.9 9.3 25.3z"/><path fill="#f0f5fa" d="M9.6 20.1c3.7 2 7.4 3.9 11.1 5.9 -0.1 0.1-5 5-5.2 5.2C13.6 27.5 11.6 23.9 9.6 20.1 9.6 20.2 9.6 20.2 9.6 20.1z"/><path fill="#f0f5fa" d="M22.3 11.9c-3.7-2-7.4-4-11-6 0 0 0 0 0 0 0 0 0 0 0 0 1.7-1.7 3.4-3.3 5.1-5 0 0 0 0 0.1-0.1C18.5 4.5 20.4 8.2 22.3 11.9 22.4 11.9 22.3 11.9 22.3 11.9z"/><path fill="#f0f5fa" d="M4.7 15c-0.6-2.4-1.2-4.7-1.8-7 0.2 0 11.9 0.6 12.7 0.6 0 0 0 0 0 0 0 0 0 0 0 0 -3.6 2.1-7.2 4.2-10.7 6.3C4.8 15 4.8 15 4.7 15z"/><path fill="#f0f5fa" d="M22.9 19.6c-0.2-4.2-0.3-8.3-0.5-12.5 2.4 0.6 4.8 1.2 7.1 1.8C27.4 12.4 25.1 16 22.9 19.6 22.9 19.6 22.9 19.6 22.9 19.6z"/><path fill="#f0f5fa" d="M27.7 16.8c0.6 2.4 1.2 4.7 1.9 7.1 -4.2-0.2-8.5-0.4-12.7-0.5 0 0 0 0 0 0C20.5 21.2 24.1 19 27.7 16.8z"/></svg>' ),
				'show_in_admin_bar'   => true,
				'show_in_nav_menus'   => false,
				'can_export'          => true,
				'has_archive'         => false,
				'exclude_from_search' => true,
				'rewrite'             => false,
				'show_in_rest'        => false,
			)
		);

		$this->metaboxes = apply_filters(
			'modula_image_licensing_cpt_metaboxes',
			array(
				'modula-album-galleries' => array(
					'title'    => esc_html__( 'Aditional Data', 'modula-pro' ),
					'callback' => 'output_image_licensing_metaboxes',
					'context'  => 'normal',
				),
			)
		);

		$this->cpt_name = apply_filters( 'modula_licensing_cpt_name', 'modula-image-license' );
		$args           = $this->args;
		$args['labels'] = $this->labels;

		register_post_type( $this->cpt_name, $args );
	}

	/**
	 * Reorders the Image Licensing submenu item position
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function reorder_submenu() {
		global $submenu;

		$parent_menu = 'edit.php?post_type=modula-gallery';

		if ( ! isset( $submenu[ $parent_menu ] ) ) {
			return;
		}

		$licensing_item  = null;
		$licensing_index = null;

		foreach ( $submenu[ $parent_menu ] as $index => $item ) {
			if ( isset( $item[2] ) && strpos( $item[2], 'modula-image-license' ) !== false ) {
				$licensing_item  = $item;
				$licensing_index = $index;
				break;
			}
		}

		if ( null === $licensing_item || null === $licensing_index ) {
			return;
		}

		unset( $submenu[ $parent_menu ][ $licensing_index ] );

		// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		$submenu[ $parent_menu ] = array_values( $submenu[ $parent_menu ] );

		$desired_position = 7;

		$desired_position = min( $desired_position, count( $submenu[ $parent_menu ] ) );

		array_splice( $submenu[ $parent_menu ], $desired_position, 0, array( $licensing_item ) );
	}

	/**
	 * Hooks meta box render/save methods to licenses CPT
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function meta_boxes_setup() {

		/* Add meta boxes on the 'add_meta_boxes' hook. */
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );

		/* Save post meta on the 'save_post' hook. */
		add_action( 'save_post', array( $this, 'save_meta_boxes' ), 10, 2 );

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_metabox_style' ) );
	}

	/**
	 * Lays out the license fields metabox, on the license edit screen only.
	 *
	 * The extension's shared admin stylesheet never loads (its Enqueue class
	 * is not instantiated), so the metabox has a stylesheet of its own.
	 *
	 * @return void
	 */
	public function enqueue_metabox_style() {
		$screen = get_current_screen();

		if ( ! $screen || $this->cpt_name !== $screen->post_type ) {
			return;
		}

		wp_enqueue_style( 'modula-image-license-metabox', \MODULA_PRO_URL . 'includes/extensions/image-licensing/assets/css/image-license-metabox.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Registers the meta boxes in licenses CPT
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function add_meta_boxes() {

		global $post;

		if ( $this->metaboxes ) {
			foreach ( $this->metaboxes as $metabox_id => $metabox ) {
				if ( 'modula-shortcode' === $metabox_id && 'auto-draft' === $post->post_status ) {
					break;
				}

				add_meta_box(
					$metabox_id,
					$metabox['title'],
					array( $this, $metabox['callback'] ),
					$this->cpt_name,
					$metabox['context'],
					'high'
				);
			}
		}
	}

	/**
	 * Renders the licenses CPT metaboxes
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function output_image_licensing_metaboxes() {
		global $post;

		$metas = get_post_meta( $post->ID, 'modula-image-licensing', true );

		$license_page = isset( $metas['license_page'] ) ? $metas['license_page'] : '';
		$buy_page     = isset( $metas['buy_page'] ) ? $metas['buy_page'] : '';
		$company_name = isset( $metas['company_name'] ) ? $metas['company_name'] : '';
		$author_name  = isset( $metas['author_name'] ) ? $metas['author_name'] : '';

		?>
		<div class="modula-ia-metabox-wrap">
			<div class="modula-ia-item">
					<label class="modula-ia-meta-label" for="modula-ia-company-name"> <?php esc_html_e( 'Company Name', 'modula-pro' ); ?> </label>
					<input type="text" id="modula-ia-company-name" name="modula_ia_company_name" value="<?php echo esc_attr( $company_name ); ?>"/>
			</div>
			<div class="modula-ia-item">
					<label class="modula-ia-meta-label" for="modula-ia-author-name"> <?php esc_html_e( 'Author Name', 'modula-pro' ); ?> </label>
					<input type="text" id="modula-ia-author-name" name="modula_ia_author_name" value="<?php echo esc_attr( $author_name ); ?>"/>
			</div>
			<div class="modula-ia-item">
					<label class="modula-ia-meta-label" for="modula-ia-license-page"> <?php esc_html_e( 'License Page URL', 'modula-pro' ); ?> </label>
					<input type="text" id="modula-ia-license-page" name="modula_ia_license_page" value="<?php echo esc_attr( $license_page ); ?>"/>
			</div>
			<div class="modula-ia-item">
					<label class="modula-ia-meta-label" for="modula-ia-buy-page"> <?php esc_html_e( 'Buy Page URL', 'modula-pro' ); ?> </label>
					<input type="text" id="modula-ia-buy-page" name="modula_ia_buy_page" value="<?php echo esc_attr( $buy_page ); ?>"/>
			</div>
		</div>
		
		<?php
	}

	/**
	 * Saves the licenses CPT metaboxes values on save post action.
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function save_meta_boxes( $post_id, $post ) {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		/* Get the post type object. */
		$post_type = get_post_type_object( $post->post_type );

		/* Check if the current user has permission to edit the post. */
		if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) || 'modula-image-license' !== $post_type->name ) {
			return $post_id;
		}

		$metas = get_post_meta( $post_id, 'modula-image-licensing', array() );

		$metas['license_page'] = isset( $_POST['modula_ia_license_page'] ) ? sanitize_text_field( wp_unslash( $_POST['modula_ia_license_page'] ) ) : '';
		$metas['buy_page']     = isset( $_POST['modula_ia_buy_page'] ) ? sanitize_text_field( wp_unslash( $_POST['modula_ia_buy_page'] ) ) : '';
		$metas['company_name'] = isset( $_POST['modula_ia_company_name'] ) ? sanitize_text_field( wp_unslash( $_POST['modula_ia_company_name'] ) ) : '';
		$metas['author_name']  = isset( $_POST['modula_ia_author_name'] ) ? sanitize_text_field( wp_unslash( $_POST['modula_ia_author_name'] ) ) : '';

		update_post_meta( $post_id, 'modula-image-licensing', $metas );
	}

	/**
	 * PRO license check function
	 *
	 * @since 1.0.0
	 */
	public function modula_pro_license_check() {

		if ( get_option( 'modula_image_licensing_pro_check' ) ) {
			return;
		}
		// If no license is available let the user know
		$current_screen = get_current_screen();
		echo '<div id="modula_image_licensing_pro_check" class="notice notice-warning is-dismissible">
             <p>' . esc_html__( 'In order to use Modula Image Attribution addon with your gallery you\'ll need to activate your license ', 'modula-pro' ) . '<a href="' . esc_url( admin_url( 'edit.php?post_type=modula-gallery&page=modula&modula-tab=licenses' ) ) . '">' . esc_html__( 'here', 'modula-pro' ) . '</a></p>'
			. ' </div>';
	}

	/**
	 * Admin list table columns function.
	 *
	 * @access public
	 *
	 * @param array $columns
	 *
	 * @return array
	 *
	 * @since 1.0.0
	*/
	public function add_columns( $columns ) {
		$columns = array();

		$columns['cb']              = '<input type="checkbox" />';
		$columns['license_title']   = __( 'License Title', 'modula-pro' );
		$columns['license_page']    = __( 'License Page', 'modula-pro' );
		$columns['license_buy']     = __( 'License Buy Page', 'modula-pro' );
		$columns['license_company'] = __( 'Company', 'modula-pro' );
		$columns['license_author']  = __( 'Author', 'modula-pro' );

		return $columns;
	}

	/**
	 * Admin list table custom_columns function.
	 *
	 * @access public
	 *
	 * @param mixed $column
	 *
	 * @return void
	 *
	 * @since 1.0.0
	*/
	public function column_data( $column ) {
		global $post;

		if ( ! isset( $this->column_data->id ) || $post->ID !== $this->column_data->id ) {
			$this->column_data = get_post_meta( $post->ID, 'modula-image-licensing', true );
		}

		switch ( $column ) {
			case 'license_title':
				global $wp_list_table;

				if ( ! $wp_list_table ) {
					$wp_list_table = _get_list_table( 'WP_Posts_List_Table' );
				}

				$wp_list_table->column_title( $post );
				break;
			case 'license_page':
				echo isset( $this->column_data['license_page'] ) ? esc_html( $this->column_data['license_page'] ) : '';
				break;
			case 'license_buy':
				echo isset( $this->column_data['buy_page'] ) ? esc_html( $this->column_data['buy_page'] ) : '';
				break;
			case 'license_company':
				echo isset( $this->column_data['company_name'] ) ? esc_html( $this->column_data['company_name'] ) : '';
				break;
			case 'license_author':
				echo isset( $this->column_data['author_name'] ) ? esc_html( $this->column_data['author_name'] ) : '';
				break;
		}
	}

	/**
	 * Admin list table sortable_columns function.
	 *
	 * @access public
	 *
	 * @param mixed $columns
	 *
	 * @return array
	 *
	 * @since 1.0.0
	*/
	public function sortable_columns( $columns ) {
		$custom = array(

			'license_title'   => 'license_title',
			'license_company' => 'company_name',
			'license_author'  => 'author_name',

		);

		return wp_parse_args( $custom, $columns );
	}

	/**
	 * Defaults the primary column name to 'license_title'
	 *
	 * @access public
	 *
	 * @param string $column_name
	 *
	 * @return string
	 *
	 * @since 1.0.0
	 */
	public function set_primary_column_name( $column_name, $context ) {
		if ( 'edit-modula-image-licensing' === $context ) {
			return 'license_title';
		}

		return $column_name;
	}

	/**
	 * Removes the upsell menu link set in Modula Lite.
	 *
	 * @access public
	 *
	 * @param string $column_name
	 *
	 * @return string
	 *
	 * @since 1.0.0
	 */
	public function remove_menu_upsell( $links ) {
		if ( isset( $links['modulalicense'] ) ) {
			unset( $links['modulalicense'] );
		}

		return $links;
	}
}
