wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;
wp.Modula.models =
	'undefined' === typeof wp.Modula.models ? {} : wp.Modula.models;
wp.Modula.views = 'undefined' === typeof wp.Modula.views ? {} : wp.Modula.views;
wp.Modula.modalChildViews =
	'undefined' === typeof wp.Modula.modalChildViews
		? []
		: wp.Modula.modalChildViews;

wp.Modula.bulkedit.childviews =
	'undefined' === typeof wp.Modula.bulkedit.childviews
		? []
		: wp.Modula.bulkedit.childviews;
const ModulaImageLicensingModalView = Backbone.View.extend( {
	/**
	 * The Tag Name and Tag's Class(es)
	 */
	tagName: 'div',
	className: 'setting modula-image-licensing',

	/**
	 * Template
	 * - The template to load inside the above tagName element
	 */
	template: wp.template( 'modula-image_licensing' ),

	/**
	 * Initialize
	 * @param args
	 */
	initialize( args ) {
		const view = this;

		this.model = args.model;
		this.isSelectize = false;
	},

	render() {
		const item = this.model.get( 'item' ),
			image_licensing = item.get( 'image_licensing' );

		data = {
			image_licensing: 'none',
		};

		if ( image_licensing ) {
			data.image_licensing = image_licensing;
		}

		this.$el.html( this.template( data ) );

		return this;
	},
} );

wp.Modula.modalChildViews.push( ModulaImageLicensingModalView );

( function ( $, modula ) {
	const ImageLicensingFiltersView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'div',
		className: 'setting modula-image-licensing',

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-image_licensing' ),
		selectize: false,

		/**
		 * Initialize
		 * @param args
		 */
		initialize( args ) {
			this.modal = args.modal;
		},

		render() {
			image_licensing = modula.Settings.get( 'image_licensing' );

			data = {
				image_licensing: 'none',
			};

			if ( image_licensing ) {
				data.image_licensing = image_licensing;
			}

			this.$el.html( this.template( data ) );

			return this;
		},

		saveView() {
			const self = this,
				value = this.$el.find( 'select' ).val();
			selection = this.modal.get( 'selection' );

			if ( selection.length > 0 ) {
				selection.each( function ( item ) {
					item.set( 'image_licensing', value );
				} );
			}
		},
	} );
	wp.Modula.bulkedit.childviews.push( ImageLicensingFiltersView );
} )( jQuery, wp.Modula );
