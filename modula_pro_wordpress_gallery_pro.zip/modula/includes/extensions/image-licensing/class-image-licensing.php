<?php
namespace Modula_Pro\Extensions\Image_Licensing;

use Modula_Pro\Extensions\Image_Licensing\Admin\Settings;
use Modula_Pro\Extensions\Image_Licensing\CPT\Image_Licensing as Image_Licensing_CPT;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Main class for Image Licensing
 */
class Image_Licensing {
	/**
	 * Holds the class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class construct
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( Settings::class, 'get_instance' ), 25 );

		new Image_Licensing_CPT();

		add_filter( 'modula_display_licensing_box', array( $this, 'render_box' ), 10, 3 );
		add_filter( 'modula_display_licensing_json', array( $this, 'render_ld_json' ), 10, 4 );
		add_filter( 'modula_link_item', array( $this, 'lightbox_license_gallery_link' ), 10, 4 );
		add_filter( 'modula_shortcode_item_data', array( $this, 'add_image_license' ), 20, 3 );
		// Before EXIF (10): a gallery's lightbox shows the license first.
		add_filter( 'modula_album_visitor_lightbox_item', array( $this, 'album_visitor_lightbox_license' ), 5, 3 );

		add_filter( 'modula-image-licensing-licenses', array( $this, 'set_custom_ia_licenses' ) );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Image_Licensing object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Image_Licensing ) ) {
			self::$instance = new Image_Licensing();
		}

		return self::$instance;
	}

	/**
	 * Filters the array for ld+json script schema for the licenses CPT.
	 *
	 * @param $json
	 * @param $image_license
	 * @param $item
	 * @param $settings
	 *
	 * @return mixed $json
	 *
	 * @since 1.0.0
	 */
	public function render_ld_json( $json, $image_attrib_options, $settings, $item ) {

		if ( ( isset( $settings['image_licensing'] ) && 'none' !== $settings['image_licensing'] ) || ( isset( $item['image_licensing'] ) && 'none' !== $item['image_licensing'] ) ) {
			$image_license = isset( $settings['image_licensing'] ) ? $settings['image_licensing'] : 'none';

			// Overwrite gallery 'image_licensing' with image's 'image_licensing'
			if ( isset( $item['image_licensing'] ) && 'none' !== $item['image_licensing'] ) {
				$image_license = $item['image_licensing'];
			}

			return $this->generate_ld_json( $json, $image_license, $item, $settings );
		}

		return $json;
	}

	/**
	 * Generates the array for ld+json script schema for the licenses CPT.
	 *
	 * @param $json
	 * @param $image_license
	 * @param $item
	 *
	 * @return mixed $html
	 *
	 * @since 1.0.0
	 */
	public function generate_ld_json( $json, $image_license, $item ) {
		$defaults = \Modula_Helper::get_default_image_licenses();

		// If it's a default license type then let modula lite take care of it.
		if ( isset( $defaults[ $image_license ] ) ) {
			$image_attrib_options = get_option( 'modula_image_license_option', false );
			if ( ! $image_attrib_options ) {
				$image_attrib_options = array();
			}
			$image_attrib_options['image_licensing'] = $image_license;

			return \Modula_Helper::render_ia_item_ld_json( $image_attrib_options, $item['img_attributes']['data-full'] );
		} else {
			// This means it's custom CPT license. Set data.
			$metas = get_post_meta( absint( $image_license ), 'modula-image-licensing', true );

			$license_page = isset( $metas['license_page'] ) ? $metas['license_page'] : '';
			$buy_page     = isset( $metas['buy_page'] ) ? $metas['buy_page'] : '';
			$company_name = isset( $metas['company_name'] ) ? $metas['company_name'] : '';
			$author_name  = isset( $metas['author_name'] ) ? $metas['author_name'] : '';
			$img_url      = $item['img_attributes']['data-full'];

			$json = array(
				'@context'           => 'https://schema.org/',
				'@type'              => 'ImageObject',
				'contentUrl'         => esc_url( $img_url ),
				'license'            => esc_url( $license_page ),
				'acquireLicensePage' => esc_html( $buy_page ),
				'creditText'         => esc_html( $company_name ),
				'creator'            => array(
					'@type' => 'Person',
					'name'  => esc_html( $author_name ),
				),
				'copyrightNotice'    => esc_html( $company_name ),
			);

			return $json;
		}

		return $json;
	}


	/**
	 * Renders the license markup to be displayed under the licensed gallery.
	 *
	 * @param $html
	 * @param $image_attrib_options
	 * @param $settings
	 *
	 * @return string $html
	 *
	 * @since 1.0.0
	 */
	public function render_box( $html, $image_attrib_options, $settings ) {
		if ( ! isset( $settings['image_licensing'] ) ) {
			return '';
		}

		if ( 'none' !== $settings['image_licensing'] && ! $this->is_setting_enabled( $settings['display_with_description'] ?? null ) ) {
			return '';
		}

		$defaults = \Modula_Helper::get_default_image_licenses();

		// If it's a default license type then let modula lite take care of it.
		if ( isset( $defaults[ $settings['image_licensing'] ] ) ) {
			return \Modula_Helper::render_license_box( $settings['image_licensing'] );
		} else {
			// This means it's custom CPT license. Set data.
			$post = get_post( absint( $settings['image_licensing'] ) );

			$metas = get_post_meta( absint( $settings['image_licensing'] ), 'modula-image-licensing', true );
			if ( empty( $metas ) || null == $post || 'trash' == $post->post_status ) {
				return $html;
			}
			$license_page  = isset( $metas['license_page'] ) ? $metas['license_page'] : '';
			$image_src     = get_the_post_thumbnail_url( absint( $settings['image_licensing'] ), 'thumbnail' );
			$license_title = get_the_title( absint( $settings['image_licensing'] ) );
		}

		ob_start();
		?>
		<div class="modula-creative-commons-wrap">
			<?php if ( $image_src ) : ?>
			<a rel="license" href="<?php echo esc_url( $license_page ); ?>" target="_BLANK">
				<img alt="<?php echo esc_attr( $license_title ); ?>" style="border-width:0" src="<?php echo esc_url( $image_src ); ?>" />
			</a>
			<?php endif; ?>
			<?php // translators: %1$s is the license page, %2$s is the license title, %3$s is the license link. ?>
			<p> <?php printf( esc_html__( 'This work is licensed under a %1$s %2$s %3$s', 'modula-pro' ), '<a rel="license" href="' . esc_url( $license_page ) . '" target="_BLANK" >', esc_html( $license_title ), '</a>' ); ?></p>
		</div>
		<?php
		$html = ob_get_clean();

		return $html;
	}

	/**
	 * Creates caption markup to be displayed in lightbox.
	 *
	 * @param $image_license - the license id.
	 *
	 * @return string $caption - the license html markup.
	 *
	 * @since 1.0.0
	 */
	private function caption_license( $image_license ) {

		$defaults = \Modula_Helper::get_default_image_licenses();
		$caption  = '';

		// If it's a default license type then let modula lite take care of it.
		if ( isset( $defaults[ $image_license ] ) ) {
			// This means it's default license.
			$ccs       = \Modula_Helper::get_image_licenses();
			$cc        = $ccs[ $image_license ];
			$image_src = false;
			if ( isset( $cc['image'] ) ) {
				$image_src = $cc['image'];
			}
			$caption .= '<div class="modula-image-licensing-caption-wrap"><a class="modula-image-licensing-caption" rel="license" href="' . esc_url( $cc['license'] ) . '" target="_BLANK">';
			$caption .= $image_src ? '<img alt="' . esc_attr( $cc['name'] ) . '" style="border-width:0" src="' . esc_url( $cc['image'] ) . '" />' : '';
			// translators: %s is the license name.
			$caption .= '<span>' . esc_html( sprintf( __( 'This work is licensed under a %s', 'modula-pro' ), $cc['name'] ) ) . '</span> </a></div>';
		} else {
			// This means it's custom CPT license.
			$metas         = get_post_meta( absint( $image_license ), 'modula-image-licensing', true );
			$license_page  = isset( $metas['license_page'] ) ? $metas['license_page'] : '';
			$image_src     = get_the_post_thumbnail_url( absint( $image_license ), 'thumbnail' );
			$license_title = get_the_title( absint( $image_license ) );
			$caption      .= '<div class="modula-image-licensing-caption-wrap"><a class="modula-image-licensing-caption" rel="license" href="' . esc_url( $license_page ) . '" target="_BLANK">';
			$caption      .= $image_src ? '<img alt="' . esc_attr( $license_title ) . '" style="border-width:0" src="' . esc_url( $image_src ) . '" >' : '';
			$caption      .= '<span>' . esc_html( sprintf( __( 'This work is licensed under a %s', 'modula-pro' ), $license_title ) ) . '</span></a></div>';
		}

		return $caption;
	}

	/**
	 * Integrate Image Licensing with [modula-link] lightbox
	 *
	 * @param $image_url
	 * @param $image
	 * @param $gall_id
	 * @param $settings
	 *
	 * @return mixed $image_url
	 *
	 * @since 1.0.0
	 */
	public function lightbox_license_gallery_link( $image_url, $image, $gall_id, $settings ) {
		$license = $this->lightbox_license( $image, $settings );
		if ( '' !== $license ) {
			$image_url['opts']['caption'] .= $this->caption_license( $license );
		}

		return $image_url;
	}

	/**
	 * The license in a Beta album's lightbox (Album visitor frontend), after
	 * the caption, as in its gallery's own lightbox (`captionExtraHtml`).
	 *
	 * @param array<string, mixed> $item     Lightbox row.
	 * @param array<string, mixed> $image    Gallery row.
	 * @param array<string, mixed> $settings The member gallery's settings.
	 * @return array<string, mixed> The row, with the license its gallery shows in the lightbox.
	 */
	public function album_visitor_lightbox_license( $item, $image, $settings ) {
		$license = $this->lightbox_license( $image, $settings );
		if ( '' === $license ) {
			return $item;
		}

		$item['captionExtraHtml'] = ( $item['captionExtraHtml'] ?? '' ) . $this->caption_license( $license );
		return $item;
	}

	/**
	 * The license a lightbox shows for an image: with "Show on lightbox" on,
	 * the image's own, else its gallery's, while that license exists.
	 *
	 * @param array<string, mixed> $image    Gallery row.
	 * @param array<string, mixed> $settings Gallery settings.
	 * @return string The license key or CPT ID; '' for none.
	 */
	private function lightbox_license( $image, $settings ) {
		if ( ! $this->is_setting_enabled( $settings['show_on_lightbox'] ?? null ) ) {
			return '';
		}

		$licenses = \Modula_Helper::get_image_licenses();
		foreach ( array( $image['image_licensing'] ?? null, $settings['image_licensing'] ?? null ) as $license ) {
			if ( is_scalar( $license ) && 'none' !== (string) $license && isset( $licenses[ (string) $license ] ) ) {
				return (string) $license;
			}
		}

		return '';
	}

	/**
	 * Function to add image attribution data to item data
	 *
	 * @param $item_data
	 * @param $image
	 * @param $settings
	 *
	 * @return mixed $item_data
	 *
	 * @since 1.0.0
	 */
	public function add_image_license( $item_data, $image, $settings ) {
		if ( isset( $image['image_licensing'] ) ) {
			$item_data['image_licensing'] = $image['image_licensing'];
		}

		$license = $this->lightbox_license( $image, $settings );
		if ( '' !== $license ) {
			$item_data['link_attributes']['data-caption'] = ( $item_data['link_attributes']['data-caption'] ?? '' ) . $this->caption_license( $license );
		}

		return $item_data;
	}

	/**
	 * Accept legacy "1"/"0" strings and v2 boolean settings.
	 *
	 * @param mixed $value Setting value.
	 * @return bool
	 */
	private function is_setting_enabled( $value ) {
		if ( true === $value || 1 === $value ) {
			return true;
		}
		if ( is_string( $value ) ) {
			$trimmed = strtolower( trim( $value ) );
			return '1' === $trimmed || 'true' === $trimmed || 'yes' === $trimmed || 'on' === $trimmed;
		}
		return false;
	}

	/**
	 * Add licenses CPTs values to get_image_licenses() result.
	 *
	 * @param array $licenses
	 *
	 * @return array $licenses
	 *
	 * @since 1.0.0
	 */
	public function set_custom_ia_licenses( $licenses ) {

		$args  = array( 'post_type' => 'modula-image-license' );
		$posts = get_posts( $args );

		foreach ( $posts as $post ) {
			$metas = get_post_meta( $post->ID, 'modula-image-licensing', true );
			if ( empty( $metas ) ) {
				continue;
			}
			$licenses[ $post->ID ]['name']    = $post->post_title;
			$licenses[ $post->ID ]['license'] = isset( $metas['license_page'] ) ? $metas['license_page'] : '';
			$licenses[ $post->ID ]['image']   = get_the_post_thumbnail_url( $post->ID, 'thumbnail' );
		}

		return $licenses;
	}
}
