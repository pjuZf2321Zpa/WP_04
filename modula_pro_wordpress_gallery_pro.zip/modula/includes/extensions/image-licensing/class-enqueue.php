<?php
namespace Modula_Pro\Extensions\Image_Licensing;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/image-licensing';
	public function __construct() {
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'modula_ia_admin_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'modula_ia_admin_css' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'modula_ia_register_front_css' ) );
		add_action( 'modula_extra_scripts', array( $this, 'modula_ia_enqueue_front_css' ) );
		add_filter( 'modula_link_extra_scripts', array( $this, 'modula_ia_enqueue_front_css' ) );
		add_action( 'modula_album_extra_scripts', array( $this, 'modula_ia_enqueue_front_css' ) );
		add_filter( 'modula_troubleshooting_frontend_handles', array( $this, 'add_ia_style' ), 60, 2 );
	}
	/**
	 * Add front styles into modula troubleshooting
	 *
	 * @since 1.0.2
	 */
	public function add_ia_style( $handles ) {

		$handles['styles'][] = 'modula-ia-front';

		return $handles;
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @since 1.0.0
	 */
	public function modula_ia_admin_scripts() {

		wp_enqueue_script( 'modula-image-licensing-js', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-image-licensing.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Enqueue admin css
	 *
	 * @since 1.0.0
	 */
	public function modula_ia_admin_css() {

		wp_enqueue_style( 'modula-image-licensing-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/wp-modula-image-licensing.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @since 1.0.2
	 */
	public function modula_ia_register_front_css() {
		wp_register_style( 'modula-ia-front', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-image-licensing.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Enqueue front styles & scripts
	 *
	 * @since 1.0.2
	 */
	public function modula_ia_enqueue_front_css( $settings ) {

		if ( isset( $settings['image_licensing'] ) && 'none' !== $settings['image_licensing'] ) {
			wp_enqueue_style( 'modula-ia-front' );
		}
	}
}
