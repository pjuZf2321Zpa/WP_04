<?php

/**
 * The image row's EXIF fields in the order the lightbox line lists them (the
 * order of the gallery's EXIF switches), each with the stored values that mean
 * "no data" besides '' and 'N/A'. A field's gallery switch has the same key.
 *
 * Lite mirrors this list in `apps/gallery-shared/utils/exifCaption.js`, which
 * builds the editor's lightbox preview line.
 *
 * @return array<string, string[]> Row field → its "no data" values.
 * @since 3.0.0
 */
function modula_exif_caption_fields() {
	return array(
		'exif_camera'        => array(),
		'exif_lens'          => array(),
		'exif_shutter_speed' => array( 'sec' ),
		'exif_aperture'      => array(),
		'exif_focal_length'  => array(),
		'exif_iso'           => array(),
		'exif_date'          => array( '0' ),
	);
}

/**
 * The camera icon at the start of the lightbox EXIF line. It strokes in the
 * caption's text colour, so it follows the light and dark lightbox themes.
 *
 * @return string SVG markup.
 * @since 3.0.0
 */
function modula_exif_caption_icon() {
	return '<svg class="modula-exif__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"></path><circle cx="12" cy="13" r="3.5"></circle></svg>';
}

/**
 * The site language's short month names, January first, for the line's date.
 *
 * @return string[] Twelve month abbreviations.
 * @since 3.0.0
 */
function modula_exif_month_abbrevs() {
	global $wp_locale;

	$months = array();
	for ( $month = 1; $month <= 12; $month++ ) {
		$months[] = $wp_locale->get_month_abbrev( $wp_locale->get_month( $month ) );
	}

	return $months;
}

/**
 * The text one EXIF field shows on the lightbox line. Values are stored as
 * typed in the image's EXIF fields, so the recognised shapes are normalised
 * ("1/250" → "1/250s", "200" → "ISO 200", "2026-03-12 14:30" → "12 Mar 2026")
 * and anything else shows as stored.
 *
 * @param string   $field  Row field, a key of modula_exif_caption_fields().
 * @param mixed    $value  Stored row value.
 * @param string[] $skip   The field's "no data" values.
 * @param string[] $months Twelve month abbreviations, January first.
 * @return string Plain text, or '' when the field has no data.
 * @since 3.0.0
 */
function modula_exif_caption_value( $field, $value, $skip, $months ) {
	if ( ! is_string( $value ) && ! is_int( $value ) ) {
		return '';
	}

	$text = trim( (string) $value );
	if ( '' === $text || 'N/A' === $text || in_array( $text, $skip, true ) ) {
		return '';
	}

	switch ( $field ) {
		case 'exif_shutter_speed':
			return preg_match( '/^(\d+(?:[.\/]\d+)?)\s*(?:s|sec)?$/i', $text, $parts ) ? $parts[1] . 's' : $text;
		case 'exif_iso':
			return preg_match( '/^\d+$/', $text ) ? 'ISO ' . $text : $text;
		case 'exif_date':
			return modula_exif_caption_date( $text, $months );
		default:
			return $text;
	}
}

/**
 * A stored "Y-m-d" or "Y-m-d H:i" date as "12 Mar 2026"; any other text as is.
 *
 * @param string   $text   Stored date.
 * @param string[] $months Twelve month abbreviations, January first.
 * @return string
 * @since 3.0.0
 */
function modula_exif_caption_date( $text, $months ) {
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/', $text, $parts ) ) {
		return $text;
	}

	$month = (int) $parts[2];
	$day   = (int) $parts[3];
	if ( $month < 1 || $month > 12 || $day < 1 || $day > 31 ) {
		return $text;
	}

	return $day . ' ' . $months[ $month - 1 ] . ' ' . $parts[1];
}

/**
 * Build EXIF caption HTML for a gallery image row (lightbox / data-caption):
 * one line, a camera icon then the fields the gallery shows, joined by " · ".
 *
 * Used by classic shortcode filters, the classic album lightbox and the v2
 * frontend adapter (`captionExtraHtml` for React Fancybox). Lite's
 * `buildExifCaptionHtml()` builds the same markup for the editor preview;
 * `includes/extensions/exif/scripts/test-exif-caption.php` and Lite's
 * `exifCaption.test.js` check both against Lite's `exifCaption.parity.json`.
 *
 * @param array $image    Image row with optional exif_* keys.
 * @param array $settings Flat gallery settings.
 * @return string HTML fragment (may be empty).
 * @since 3.0.0
 */
function modula_build_exif_caption_html( $image, $settings ) {
	if ( ! is_array( $settings ) || ! isset( $settings['enable_exif'] ) || 1 !== absint( $settings['enable_exif'] ) ) {
		return '';
	}
	if ( ! is_array( $image ) ) {
		return '';
	}

	$months = modula_exif_month_abbrevs();
	$values = array();
	foreach ( modula_exif_caption_fields() as $field => $skip ) {
		if ( ! isset( $image[ $field ] ) || 1 !== absint( $settings[ $field ] ?? 0 ) ) {
			continue;
		}
		$value = modula_exif_caption_value( $field, $image[ $field ], $skip, $months );
		if ( '' !== $value ) {
			$values[] = esc_html( $value );
		}
	}

	if ( array() === $values ) {
		return '';
	}

	return '<div class="modula-exif">' . modula_exif_caption_icon() . '<span>' . implode( ' · ', $values ) . '</span></div>';
}

/**
 * Format parameters for EXIF info
 *
 * @param string $type
 * @param string $param
 *
 * @return string
 * @since 1.0.0
 */
function modula_format_exif_data( $type, $param ) {
	$html = '';
	if ( isset( $type ) ) {
		switch ( $type ) {
			case 'shutter_speed':
				if ( ! empty( $param ) ) {
					if ( $param > 0 && ( 1 / $param ) > 1 ) {
						$html .= '1/';
						$html .= number_format( ( 1 / $param ), 0, '.', '' );
					} else {
						$html .= esc_attr( $param ) . ' sec';
					}
				} else {
					$html .= esc_attr( 'N/A' );
				}
				break;
			case 'focal_length':
				$html = empty( $param ) ? esc_attr( 'N/A' ) : ( round( $param, 0 ) . 'mm' );
				break;
			case 'aperture':
				$html = empty( $param ) ? esc_attr( 'N/A' ) : ( 'f/' . esc_attr( $param ) );
				break;
			case 'iso':
				$html = empty( $param ) ? esc_attr( 'N/A' ) : ( 'ISO ' . esc_attr( $param ) );
				break;
			case 'lens':
				if ( empty( $param ) ) {
					$html = esc_attr( 'N/A' );
					break;
				}

				$lenses = array(
					// Generic
					'----'                               => 'N/A',
					'0.0 mm f/0.0'                       => 'N/A',
					'70.0-200.0 mm f/2.8'                => '70-200mm f/2.8',
					'85.0 mm f/1.4'                      => '85mm f/1.4',
					'24.0-70.0 mm f/2.8'                 => '24-70mm f/2.8',
					'14.0-24.0 mm f/2.8'                 => '14-24mm f/2.8',
					// Nikon
					'AF-S Zoom-Nikkor 14-24mm f/2.8G ED' => '14-24mm f/2.8',
					// Canon
					'EF-S17-55mm f/2.8 IS USM'           => '17-55mm f/2.8',
					'EF11-24mm f/4L USM'                 => '11-24mm f/4',
					'EF24-70mm f/2.8L II USM'            => '24-70mm f/2.8',
					// Rolleiflex
					'XCD 45'                             => 'XCD 45mm',
				);

				if ( isset( $lenses[ $param ] ) ) {
					$html = esc_attr( $lenses[ $param ] );
				} else {
					$html = esc_attr( $param );
				}
				break;
			case 'camera':
				if ( empty( $param ) ) {
					$html = esc_attr( 'N/A' );
					break;
				}

				$cameras = array(
					'ILCE-6000'            => 'SONY α6000',
					'ILCE-7RM2'            => 'SONY α7R II',
					'ILCE-7RM3'            => 'SONY α7R III',
					'X1D II 50C'           => 'Rolleiflex X1D II',
					'X-T2'                 => 'FUJIFILM X-T2',
					'Canon EOS 5D Mark IV' => 'Canon 5D Mark IV',
				);
				if ( isset( $cameras[ $param ] ) ) {
					$html = esc_attr( $cameras[ $param ] );
				} else {
					$html = esc_attr( $param );
				}
				break;
			default:
				$html = esc_attr( $param );
		}
	}

	return $html;
}
