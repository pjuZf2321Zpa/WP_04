<?php
namespace Modula_Pro\Extensions\Exif\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	/**
	 * Holds the admin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	public function __construct() {
		//Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_exif_field' ) );
		add_filter( 'modula_album_fields', array( $this, 'modula_exif_albums_field' ) );

		//Filter Modula Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'modula_exif_tab' ), 99 );
		add_filter( 'modula_album_tabs', array( $this, 'modula_exif_album_tab' ) );

		// Template for EXIF
		add_action( 'admin_footer', array( $this, 'print_modula_exif_templates' ) );

		// Image attribute whitelist + metadata fill are registered on Exif (REST-safe).
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @return object Modula Exif Settings object
	 *
	 *  @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Settings ) ) {
			self::$instance = new Settings();
		}

		return self::$instance;
	}

	/**
	 * Add the exif tab in settings
	 *
	 * @param $tabs
	 *
	 * @return mixed $tabs
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_tab( $tabs ) {
		$tabs['exif'] = array(
			'label'    => esc_html__( 'EXIF', 'modula-pro' ),
			'title'    => esc_html__( 'Exif Settings', 'modula-pro' ),
			'icon'     => 'dashicons dashicons-camera-alt',
			'docs_url' => 'https://wp-modula.com/kb/modula-exif/',
			'priority' => 85,
		);

		if ( isset( $tabs['exif']['badge'] ) ) {
			unset( $tabs['exif']['badge'] );
		}

		return $tabs;
	}

	/**
	 * Add the exif tab in settings
	 *
	 * @param $tabs
	 *
	 * @return mixed $tabs
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_album_tab( $tabs ) {
		$tabs['exif'] = array(
			'label'    => esc_html__( 'EXIF', 'modula-pro' ),
			'title'    => esc_html__( 'Exif Settings', 'modula-pro' ),
			'docs_url' => 'https://wp-modula.com/kb/modula-exif/',
			'icon'     => 'dashicons dashicons-camera-alt',
			'priority' => 85,
		);
		return $tabs;
	}

	/**
	 * Add exif fields in settings
	 *
	 * @param $fields
	 *
	 * @return mixed $fields
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_field( $fields ) {
		$fields['exif'] = array(
			'enable_exif'        => array(
				'name'      => esc_html__( 'Enable Exif', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 1,
				'children'  => array( 'exif_camera', 'exif_lens', 'exif_shutter_speed', 'exif_aperture', 'exif_focal_length', 'exif_iso', 'exif_date' ),
				'data_type' => 'bool',
			),
			'exif_camera'        => array(
				'name'      => esc_html__( 'Show camera model', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 3,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'exif_lens'          => array(
				'name'      => esc_html__( 'Show lens data', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 4,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'exif_shutter_speed' => array(
				'name'      => esc_html__( 'Show shutter speed', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 5,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'exif_aperture'      => array(
				'name'      => esc_html__( 'Show aperture', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 6,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'exif_focal_length'  => array(
				'name'      => esc_html__( 'Show focal length', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 7,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'exif_iso'           => array(
				'name'      => esc_html__( 'Show ISO', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 8,
				'is_child'  => true,
				'data_type' => 'bool',
			),
			'exif_date'          => array(
				'name'      => esc_html__( 'Show date information', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 9,
				'is_child'  => true,
				'data_type' => 'bool',
			),
		);

		return $fields;
	}

	/**
	 * Add exif fields in settings
	 *
	 * @param $fields
	 *
	 * @return mixed $fields
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_albums_field( $fields ) {
		$fields['exif'] = array(
			'displayExif' => array(
				'name'      => esc_html__( 'Show EXIF data', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'default' => esc_html__( 'Take Gallery setting', 'modula-pro' ),
					'on'      => esc_html__( 'Display EXIF data', 'modula-pro' ),
					'off'     => esc_html__( 'Hide EXIF data', 'modula-pro' ),
				),
				'default'   => 'default',
				'priority'  => 1,
				'data_type' => 'text',
			),
		);

		return $fields;
	}

	/**
	 * EXIF information in edit image
	 *
	 * @since 1.0.0
	 *
	 */
	public function print_modula_exif_templates() {
		?>
		<script type="text/html" id="tmpl-modula-exif">

				<span class="name"><?php esc_html_e( 'Exif Information', 'modula-pro' ); ?></span>

				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'camera' ); ?> </span>
					<p> <?php esc_html_e( 'Camera Model', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_camera" value="{{ data.exif_camera }}" placeholder="<?php echo esc_html( 'Ex.: SM-j105H' ); ?>"/>
				</label>
				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'lens' ); ?> </span>
					<p> <?php esc_html_e( 'Lens', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_lens" value="{{ data.exif_lens }}" placeholder="<?php echo esc_html( 'Ex.: 85mm f/1.4' ); ?>"/>
				</label>
				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'eye' ); ?> </span>
					<p> <?php esc_html_e( 'Focal Length', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_focal_length" value="{{ data.exif_focal_length }}" placeholder="<?php echo esc_html( 'Ex.: 3mm' ); ?>" />
				</label>
				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'shutter_speed' ); ?> </span>
					<p> <?php esc_html_e( 'Shutter Speed', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_shutter_speed" value="{{ data.exif_shutter_speed }}" placeholder="<?php echo esc_html( 'Ex.: 1/25' ); ?>" />
				</label>
				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'aperture' ); ?> </span>
					<p> <?php esc_html_e( 'Aperture', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_aperture" value="{{ data.exif_aperture }}" placeholder="<?php echo esc_html( 'Ex.: f/2.2' ); ?>" />
				</label>
				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'iso' ); ?> </span>
					<p> <?php esc_html_e( 'Iso', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_iso" value="{{ data.exif_iso }}" placeholder="<?php echo esc_html( 'Ex.: ISO 125' ); ?>" />
				</label>
				<label class="exif">
					<span> <?php echo self::modula_exif_get_icons( 'calendar' ); ?> </span>
					<p> <?php esc_html_e( 'Date', 'modula-pro' ); ?> </p>
					<input type="text" name="exif_date" value="{{ data.exif_date }}" placeholder="<?php echo esc_html( gmdate( 'Y-m-d H:i' ) ); ?>"/>
				</label>
		</script>
		<?php
	}

	/**
		 * Get icons function
		 *
		 * @param $icon
		 *
		 * @return mixed|string|void $icons;
		 *
		 * @since 1.0.0
		 */
	public static function modula_exif_get_icons( $icon ) {

		switch ( $icon ) {
			case 'camera':
				return '<svg width="24" height="24" viewBox="0 0 24 24"><path fill="#000000" d="M4,4H7L9,2H15L17,4H20A2,2 0 0,1 22,6V18A2,2 0 0,1 20,20H4A2,2 0 0,1 2,18V6A2,2 0 0,1 4,4M12,7A5,5 0 0,0 7,12A5,5 0 0,0 12,17A5,5 0 0,0 17,12A5,5 0 0,0 12,7M12,9A3,3 0 0,1 15,12A3,3 0 0,1 12,15A3,3 0 0,1 9,12A3,3 0 0,1 12,9Z"/></svg>';

			case 'iso':
				return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM5.5 7.5h2v-2H9v2h2V9H9v2H7.5V9h-2V7.5zM19 19H5L19 5v14zm-2-2v-1.5h-5V17h5z"/></svg>';

			case 'shutter_speed':
				return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15 1H9v2h6V1zm4.03 6.39l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42C16.07 4.74 14.12 4 12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9 9-4.03 9-9c0-2.12-.74-4.07-1.97-5.61zM12 20c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7zm-.32-5H6.35c.57 1.62 1.82 2.92 3.41 3.56l-.11-.06 2.03-3.5zm5.97-4c-.57-1.6-1.78-2.89-3.34-3.54L12.26 11h5.39zm-7.04 7.83c.45.11.91.17 1.39.17 1.34 0 2.57-.45 3.57-1.19l-2.11-3.9-2.85 4.92zM7.55 8.99C6.59 10.05 6 11.46 6 13c0 .34.04.67.09 1h4.72L7.55 8.99zm8.79 8.14C17.37 16.06 18 14.6 18 13c0-.34-.04-.67-.09-1h-4.34l2.77 5.13zm-3.01-9.98C12.9 7.06 12.46 7 12 7c-1.4 0-2.69.49-3.71 1.29l2.32 3.56 2.72-4.7z"/></svg>';

			case 'lens':
				return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/></svg>';

			case 'aperture':
				return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M9.4 10.5l4.77-8.26C13.47 2.09 12.75 2 12 2c-2.4 0-4.6.85-6.32 2.25l3.66 6.35.06-.1zM21.54 9c-.92-2.92-3.15-5.26-6-6.34L11.88 9h9.66zm.26 1h-7.49l.29.5 4.76 8.25C21 16.97 22 14.61 22 12c0-.69-.07-1.35-.2-2zM8.54 12l-3.9-6.75C3.01 7.03 2 9.39 2 12c0 .69.07 1.35.2 2h7.49l-1.15-2zm-6.08 3c.92 2.92 3.15 5.26 6 6.34L12.12 15H2.46zm11.27 0l-3.9 6.76c.7.15 1.42.24 2.17.24 2.4 0 4.6-.85 6.32-2.25l-3.66-6.35-.93 1.6z"/></svg>';

			case 'calendar':
				return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 3h-1V1h-2v2H7V1H5v2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 18H4V10h16v11zm0-13H4V5h16v3z"/></svg>';

			case 'eye':
				return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 6.5c3.79 0 7.17 2.13 8.82 5.5-1.65 3.37-5.02 5.5-8.82 5.5S4.83 15.37 3.18 12C4.83 8.63 8.21 6.5 12 6.5m0-2C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 5c1.38 0 2.5 1.12 2.5 2.5s-1.12 2.5-2.5 2.5-2.5-1.12-2.5-2.5 1.12-2.5 2.5-2.5m0-2c-2.48 0-4.5 2.02-4.5 4.5s2.02 4.5 4.5 4.5 4.5-2.02 4.5-4.5-2.02-4.5-4.5-4.5z"/></svg>';

			default:
				return apply_filters( 'modula_exif_get_icon', '', $icon );
		}
	}

	/**
	 * Add exif information to edit modal
	 *
	 * @param $fields
	 *
	 * @return mixed $fields
	 *
	 * @since 1.0.0
	 */
	public function exif_add_item_fields( $fields ) {
		$fields[] = 'exif_camera';
		$fields[] = 'exif_lens';
		$fields[] = 'exif_focal_length';
		$fields[] = 'exif_shutter_speed';
		$fields[] = 'exif_aperture';
		$fields[] = 'exif_iso';
		$fields[] = 'exif_date';
		return $fields;
	}

	/**
	 * Add exif meta to image model
	 *
	 * @param $image
	 *
	 * @return mixed $image
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_add_metadata( $image ) {

		if ( ! extension_loaded( 'exif' ) ) {
			return $image;
		}

		if ( empty( $image['id'] ) ) {
			return $image;
		}

		$meta = wp_get_attachment_metadata( $image['id'] );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}
		if ( ! isset( $meta['image_meta'] ) || ! is_array( $meta['image_meta'] ) ) {
			$meta['image_meta'] = array();
		}

		$file = get_attached_file( $image['id'] );
		if ( $file ) {
			$pp        = pathinfo( $file );
			$extension = isset( $pp['extension'] ) ? strtolower( $pp['extension'] ) : '';

			if ( in_array( $extension, array( 'jpg', 'jpeg', 'tiff' ), true ) ) {
				$exif = @exif_read_data( $file );
				if ( $exif && isset( $exif['UndefinedTag:0xA434'] ) ) {
					$meta['image_meta']['lens'] = empty( $exif['UndefinedTag:0xA434'] ) ? '' : $exif['UndefinedTag:0xA434'];
					wp_update_attachment_metadata( $image['id'], $meta );
				}
			}
		}

		$image_meta = $meta['image_meta'];

		if ( isset( $image['exif_camera'] ) && '' === $image['exif_camera'] ) {
			$image['exif_camera'] = modula_format_exif_data(
				'camera',
				isset( $image_meta['camera'] ) ? $image_meta['camera'] : ''
			);
		}

		if ( isset( $image['exif_lens'] ) && empty( $image['exif_lens'] ) ) {
			$image['exif_lens'] = modula_format_exif_data(
				'lens',
				isset( $image_meta['lens'] ) ? $image_meta['lens'] : ''
			);
		}

		if ( isset( $image['exif_focal_length'] ) && '' === $image['exif_focal_length'] ) {
			$image['exif_focal_length'] = modula_format_exif_data(
				'focal_length',
				isset( $image_meta['focal_length'] ) ? $image_meta['focal_length'] : ''
			);
		}

		if ( isset( $image['exif_shutter_speed'] ) && '' === $image['exif_shutter_speed'] ) {
			$image['exif_shutter_speed'] = modula_format_exif_data(
				'shutter_speed',
				isset( $image_meta['shutter_speed'] ) ? $image_meta['shutter_speed'] : ''
			);
		}

		if ( isset( $image['exif_aperture'] ) && '' === $image['exif_aperture'] ) {
			$image['exif_aperture'] = modula_format_exif_data(
				'aperture',
				isset( $image_meta['aperture'] ) ? $image_meta['aperture'] : ''
			);
		}

		if ( isset( $image['exif_iso'] ) && '' === $image['exif_iso'] ) {
			$image['exif_iso'] = modula_format_exif_data(
				'iso',
				isset( $image_meta['iso'] ) ? $image_meta['iso'] : ''
			);
		}

		if ( isset( $image['exif_date'] ) ) {
			if ( empty( $image['exif_date'] ) && ! empty( $image_meta['created_timestamp'] ) ) {
				$image['exif_date'] = esc_html( gmdate( 'Y-m-d H:i', $image_meta['created_timestamp'] ) );
			} elseif ( 'N/A' === $image['exif_date'] || empty( $image['exif_date'] ) ) {
				$image['exif_date'] = sanitize_text_field( 'N/A' );
			}
		}

		return $image;
	}
}
