<?php

namespace Modula_Pro\Extensions\Exif;

use Modula_Pro\Extensions\Exif\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main class for EXIF
 */
class Exif {

	/**
	 * Holds the class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * A gallery's switch for each EXIF field, each on by default.
	 */
	private const EXIF_FIELD_SETTINGS = array(
		'exif_camera',
		'exif_lens',
		'exif_shutter_speed',
		'exif_aperture',
		'exif_focal_length',
		'exif_iso',
		'exif_date',
	);

	/**
	 * Primary class construct
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->require_helpers();

		// REST image patch needs these outside admin_init (same pattern as Video).
		add_filter( 'modula_gallery_image_attributes', array( $this, 'exif_add_item_fields' ) );
		add_filter( 'modula_image_properties', array( $this, 'modula_exif_add_metadata' ) );

		add_action( 'admin_init', array( Settings::class, 'get_instance' ), 25 );

		add_filter( 'modula_lite_default_settings', array( $this, 'modula_exif_defaults' ) );
		add_filter( 'modula_album_default_settings', array( $this, 'modula_exif_albums_defaults' ) );
		add_filter( 'modula_link_item', array( $this, 'modula_exif_gallery_link' ), 10, 4 );
		add_filter( 'modula_shortcode_item_data', array( $this, 'modula_exif_item_data' ), 20, 3 );
		add_filter( 'modula_hidden_items_data', array( $this, 'modula_hidden_items_exif' ), 20, 3 );
		add_filter( 'modula_album_lightbox_item', array( $this, 'modula_exif_albums_lightbox' ), 10, 5 );
		add_filter( 'modula_album_visitor_lightbox_item', array( $this, 'album_visitor_lightbox_exif' ), 10, 4 );
		add_filter( 'modula_frontend_adapter_item', array( $this, 'attach_caption_extra_html' ), 20, 4 );
		add_filter( 'modula_settings_editor_config', array( $this, 'settings_editor_exif_caption' ) );

		// filter for migrator
		add_filter( 'modula_migrate_gallery_data', array( $this, 'modula_exif_migrator_data' ), 25, 3 );

		new Enqueue();
	}

	/**
	 * Loads all the helper functions
	 *
	 * @since 1.0.0
	 */
	public function require_helpers() {
		require_once MODULA_PRO_PATH . 'includes/extensions/exif/modula-exif-helper.php';
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Exif object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Exif ) ) {
			self::$instance = new Exif();
		}

		return self::$instance;
	}


	/**
	 * Add Exif defaults settings
	 *
	 * @param $defaults
	 *
	 * @return mixed $defaults;
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_defaults( $defaults ) {
		$defaults['enable_exif'] = 0;
		foreach ( self::EXIF_FIELD_SETTINGS as $field ) {
			$defaults[ $field ] = 1;
		}

		return $defaults;
	}

	/**
	 * Add Exif defaults settings
	 *
	 * @param $defaults
	 *
	 * @return mixed $defaults;
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_albums_defaults( $defaults ) {

		$defaults['displayExif'] = 'default';

		return $defaults;
	}

	/**
	 * Integrate EXIF with [modula-link]
	 *
	 * @param $image_url
	 * @param $image
	 * @param $gall_id
	 * @param $settings
	 *
	 * @return mixed $image_url
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_gallery_link( $image_url, $image, $gall_id, $settings ) {
		$extra = modula_build_exif_caption_html( $image, $settings );
		if ( '' !== $extra ) {
			$image_url['opts']['caption'] .= $extra;
		}

		return $image_url;
	}

	/**
	 * Function to add exif information in item data
	 *
	 * @param $item_data
	 * @param $image
	 * @param $settings
	 *
	 * @return mixed $item_data
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_item_data( $item_data, $image, $settings ) {
		$extra = modula_build_exif_caption_html( $image, $settings );
		// `data-caption` is only set on link_attributes for Fancybox modes; skip when absent
		// (e.g. external-url / attachment-page / direct / no-link).
		if ( '' !== $extra && isset( $item_data['link_attributes']['data-caption'] ) ) {
			$item_data['link_attributes']['data-caption'] .= $extra;
		}

		return $item_data;
	}

	/**
	 * Attach pre-rendered EXIF HTML for the React Fancybox caption pipeline.
	 *
	 * Lite merges `captionExtraHtml` generically; EXIF formatting stays in Pro.
	 *
	 * @param array $converted_item Frontend item row.
	 * @param array $image          Original image row.
	 * @param array $item_data      Processed item_data.
	 * @param array $settings       Flat gallery settings.
	 * @return array
	 */
	public function attach_caption_extra_html( $converted_item, $image, $item_data, $settings ) {
		if ( ! is_array( $converted_item ) ) {
			return $converted_item;
		}

		$extra = modula_build_exif_caption_html( $image, $settings );
		if ( '' === $extra ) {
			return $converted_item;
		}

		$existing                           = isset( $converted_item['captionExtraHtml'] ) && is_string( $converted_item['captionExtraHtml'] )
			? $converted_item['captionExtraHtml']
			: '';
		$converted_item['captionExtraHtml'] = $existing . $extra;

		return $converted_item;
	}

	/**
	 * What the gallery editor's lightbox preview needs to build the EXIF line
	 * from the unsaved settings (the visitor gets it as `captionExtraHtml` from
	 * the saved ones): the line's icon and the site's short month names.
	 *
	 * @param array<string, mixed> $editor_config Localized config for the React editor.
	 * @return array<string, mixed> The config, with `exifCaption` ({ icon: string, months: string[] }).
	 */
	public function settings_editor_exif_caption( $editor_config ) {
		$editor_config['exifCaption'] = array(
			'icon'   => modula_exif_caption_icon(),
			'months' => modula_exif_month_abbrevs(),
		);

		return $editor_config;
	}

	/**
	 * Add EXIF image data for hidden items
	 *
	 * @param $attr
	 * @param $settings
	 * @param $image
	 *
	 * @return mixed
	 * @since 1.0.0
	 */
	public function modula_hidden_items_exif( $attr, $settings, $image ) {
		if ( ! isset( $attr['data-caption'] ) ) {
			return $attr;
		}

		$extra = modula_build_exif_caption_html( $image, $settings );
		if ( '' !== $extra ) {
			$attr['data-caption'] .= $extra;
		}

		return $attr;
	}

	/**
	 * EXIF in a classic album's lightbox: the gallery's EXIF line, by the
	 * album's "Show EXIF data", as a Beta album shows it
	 * (`album_visitor_lightbox_exif()`).
	 *
	 * @param array<string, mixed> $image_config   Lightbox item, with `opts.caption`.
	 * @param array<string, mixed> $image          Gallery row, with its `exif_*` fields.
	 * @param array<string, mixed> $settings       The member gallery's settings.
	 * @param mixed                $gallery        Unused; the filter passes it.
	 * @param array<string, mixed> $album_settings Album flat settings.
	 * @return array<string, mixed> The item, with the EXIF line after its caption.
	 *
	 * @since 1.0.0
	 */
	public function modula_exif_albums_lightbox( $image_config, $image, $settings, $gallery, $album_settings ) {
		if ( ! is_array( $settings ) || ! is_array( $album_settings ) ) {
			return $image_config;
		}

		$exif_settings = $this->album_exif_settings( $settings, $album_settings );
		if ( null === $exif_settings ) {
			return $image_config;
		}

		$image_config['opts']['caption'] .= modula_build_exif_caption_html( $image, $exif_settings );

		return $image_config;
	}

	/**
	 * EXIF in a Beta album's lightbox (Album visitor frontend), after the
	 * caption and what the extensions before it added, as in a gallery's
	 * lightbox (`captionExtraHtml`).
	 *
	 * @param array<string, mixed> $item           Lightbox row.
	 * @param array<string, mixed> $image          Gallery row, with its `exif_*` fields.
	 * @param array<string, mixed> $settings       The member gallery's settings.
	 * @param array<string, mixed> $album_settings Album flat settings.
	 * @return array<string, mixed> The row, with the EXIF the album shows.
	 */
	public function album_visitor_lightbox_exif( $item, $image, $settings, $album_settings ) {
		$exif_settings = $this->album_exif_settings( $settings, $album_settings );
		if ( null === $exif_settings ) {
			return $item;
		}

		$extra = modula_build_exif_caption_html( $image, $exif_settings );
		if ( '' === $extra ) {
			return $item;
		}

		$item['captionExtraHtml'] = ( $item['captionExtraHtml'] ?? '' ) . $extra;
		return $item;
	}

	/**
	 * The gallery settings EXIF reads in an album's lightbox, by the album's
	 * "Show EXIF data", as the classic album reads it
	 * (`modula_exif_albums_lightbox()`): "Take Gallery setting" keeps the
	 * gallery's; "Display EXIF data" turns every field on, as the defaults do
	 * (`modula_exif_defaults()`), so it shows every field the image has.
	 *
	 * @param array<string, mixed> $settings       The member gallery's settings.
	 * @param array<string, mixed> $album_settings Album flat settings; `displayExif` defaults to "Take Gallery setting".
	 * @return array<string, mixed>|null Null while the album hides EXIF, or for a choice it does not know.
	 */
	private function album_exif_settings( array $settings, array $album_settings ) {
		switch ( $album_settings['displayExif'] ?? 'default' ) {
			case 'default':
				return $settings;
			case 'on':
				return array_merge( $settings, array_fill_keys( self::EXIF_FIELD_SETTINGS, 1 ), array( 'enable_exif' => 1 ) );
			default:
				return null;
		}
	}

	/**
	 * Add modula migrator data for EXIF
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.1
	 */
	public function modula_exif_migrator_data( $modula_settings, $guest_settings, $source ) {

		if ( isset( $source ) ) {
			switch ( $source ) {
				case 'envira':
					if ( isset( $guest_settings['config']['exif_lightbox'] ) && 1 === absint( $guest_settings['config']['exif_lightbox'] ) ) {
						$modula_settings['enable_exif'] = 1;
					}

					if ( isset( $guest_settings['config']['exif_lightbox_aperture'] ) && 1 === absint( $guest_settings['config']['exif_lightbox_aperture'] ) ) {
						$modula_settings['exif_aperture'] = 1;
					}

					if ( isset( $guest_settings['config']['exif_lightbox_shutter_speed'] ) && 1 === absint( $guest_settings['config']['exif_lightbox_shutter_speed'] ) ) {
						$modula_settings['exif_shutter_speed'] = 1;
					}

					if ( isset( $guest_settings['config']['exif_lightbox_focal_length'] ) && 1 === absint( $guest_settings['config']['exif_lightbox_focal_length'] ) ) {
						$modula_settings['exif_focal_length'] = 1;
					}

					if ( isset( $guest_settings['config']['exif_lightbox_iso'] ) && 1 === absint( $guest_settings['config']['exif_lightbox_iso'] ) ) {
						$modula_settings['exif_iso'] = 1;
					}

					if ( isset( $guest_settings['config']['exif_lightbox_capture_time'] ) && 1 === absint( $guest_settings['config']['exif_lightbox_capture_time'] ) ) {
						$modula_settings['exif_date'] = 1;
					}

					break;
			}
		}

		return $modula_settings;
	}

	/**
	 * Whitelist EXIF keys on gallery image rows (REST patch + save).
	 *
	 * @param array $fields Attribute keys.
	 * @return array
	 */
	public function exif_add_item_fields( $fields ) {
		$fields[] = 'exif_camera';
		$fields[] = 'exif_lens';
		$fields[] = 'exif_focal_length';
		$fields[] = 'exif_shutter_speed';
		$fields[] = 'exif_aperture';
		$fields[] = 'exif_iso';
		$fields[] = 'exif_date';
		return $fields;
	}

	/**
	 * Fill empty EXIF fields from attachment metadata when available.
	 *
	 * @param array $image Image row.
	 * @return array
	 */
	public function modula_exif_add_metadata( $image ) {

		if ( ! extension_loaded( 'exif' ) ) {
			return $image;
		}

		if ( empty( $image['id'] ) ) {
			return $image;
		}

		$meta = wp_get_attachment_metadata( $image['id'] );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}
		if ( ! isset( $meta['image_meta'] ) || ! is_array( $meta['image_meta'] ) ) {
			$meta['image_meta'] = array();
		}

		$file = get_attached_file( $image['id'] );
		if ( $file ) {
			$pp        = pathinfo( $file );
			$extension = isset( $pp['extension'] ) ? strtolower( $pp['extension'] ) : '';

			if ( in_array( $extension, array( 'jpg', 'jpeg', 'tiff' ), true ) ) {
				$exif = @exif_read_data( $file );
				if ( $exif && isset( $exif['UndefinedTag:0xA434'] ) ) {
					$meta['image_meta']['lens'] = empty( $exif['UndefinedTag:0xA434'] ) ? '' : $exif['UndefinedTag:0xA434'];
					wp_update_attachment_metadata( $image['id'], $meta );
				}
			}
		}

		$image_meta = $meta['image_meta'];

		if ( isset( $image['exif_camera'] ) && '' === $image['exif_camera'] ) {
			$image['exif_camera'] = modula_format_exif_data(
				'camera',
				isset( $image_meta['camera'] ) ? $image_meta['camera'] : ''
			);
		}

		if ( isset( $image['exif_lens'] ) && empty( $image['exif_lens'] ) ) {
			$image['exif_lens'] = modula_format_exif_data(
				'lens',
				isset( $image_meta['lens'] ) ? $image_meta['lens'] : ''
			);
		}

		if ( isset( $image['exif_focal_length'] ) && '' === $image['exif_focal_length'] ) {
			$image['exif_focal_length'] = modula_format_exif_data(
				'focal_length',
				isset( $image_meta['focal_length'] ) ? $image_meta['focal_length'] : ''
			);
		}

		if ( isset( $image['exif_shutter_speed'] ) && '' === $image['exif_shutter_speed'] ) {
			$image['exif_shutter_speed'] = modula_format_exif_data(
				'shutter_speed',
				isset( $image_meta['shutter_speed'] ) ? $image_meta['shutter_speed'] : ''
			);
		}

		if ( isset( $image['exif_aperture'] ) && '' === $image['exif_aperture'] ) {
			$image['exif_aperture'] = modula_format_exif_data(
				'aperture',
				isset( $image_meta['aperture'] ) ? $image_meta['aperture'] : ''
			);
		}

		if ( isset( $image['exif_iso'] ) && '' === $image['exif_iso'] ) {
			$image['exif_iso'] = modula_format_exif_data(
				'iso',
				isset( $image_meta['iso'] ) ? $image_meta['iso'] : ''
			);
		}

		if ( isset( $image['exif_date'] ) ) {
			if ( empty( $image['exif_date'] ) && ! empty( $image_meta['created_timestamp'] ) ) {
				$image['exif_date'] = esc_html( gmdate( 'Y-m-d H:i', $image_meta['created_timestamp'] ) );
			} elseif ( 'N/A' === $image['exif_date'] || empty( $image['exif_date'] ) ) {
				$image['exif_date'] = sanitize_text_field( 'N/A' );
			}
		}

		return $image;
	}
}
