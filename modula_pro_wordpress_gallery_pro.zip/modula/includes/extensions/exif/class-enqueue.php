<?php
namespace Modula_Pro\Extensions\Exif;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/exif';

	public function __construct() {
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'exif_admin_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'modula_extra_scripts', array( $this, 'enqueue_scripts' ) );
		add_filter( 'modula_link_extra_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'modula_album_extra_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'modula_album_visitor_extra_scripts', array( $this, 'enqueue_scripts' ) );
		add_filter( 'modula_troubleshooting_frontend_handles', array( $this, 'add_exif_style' ), 60, 2 );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'exif_admin_scripts' ) );
		add_action( 'modula_gallery_settings_editor_enqueue', array( $this, 'enqueue_settings_editor_styles' ) );
	}

	/**
	 * The visitor's EXIF caption styles in the gallery editor, whose
	 * lightbox preview shows the same EXIF lines.
	 */
	public function enqueue_settings_editor_styles() {
		// The front handle is registered on `wp_enqueue_scripts`, which admin screens skip.
		$this->register_scripts();
		wp_enqueue_style( 'modula-exif-css' );
	}

	/**
	 * Register front styles & scripts
	 *
	 * @since 1.0.8
	 */
	public function register_scripts() {
		wp_register_style(
			'modula-exif-css',
			\MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-exif-front.css',
			array(),
			\MODULA_PRO_VERSION
		);
	}

	/**
	 * Enqueue front styles & scripts
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts( $settings ) {
		wp_enqueue_style( 'modula-exif-css' );
	}

	/**
	 * Add front styles into modula troubleshooting
	 *
	 * @since 1.0.8
	 */
	public function add_exif_style( $handles ) {

		$handles['styles'][] = 'modula-exif-css';

		return $handles;
	}
	/**
	 * Enqueue admin scripts
	 *
	 * @since 1.0.0
	 */
	public function exif_admin_scripts() {
		wp_enqueue_script(
			'modula-exif-conditions',
			\MODULA_PRO_URL . 'includes/extensions/exif/assets/js/modula-exif-conditions.js',
			array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_enqueue_script(
			'modula-exif-js',
			\MODULA_PRO_URL . 'includes/extensions/exif/assets/js/wp-modula-exif.js',
			array( 'jquery' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_enqueue_style(
			'modula-exif-admin-css',
			\MODULA_PRO_URL . 'includes/extensions/exif/assets/css/modula-exif-admin.css',
			\MODULA_PRO_VERSION
		);
	}
}
