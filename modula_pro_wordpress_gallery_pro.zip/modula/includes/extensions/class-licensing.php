<?php

namespace Modula_Pro\Extensions;

class Licensing {
	// Instance
	private static $instance;

	/** @var int Keep last known active license when the remote server is unreachable (7 days). */
	private const GRACE_PERIOD_SECONDS = 604800;

	/** @var int Renewal grace: an expired license keeps its plan this long after its expiry date (14 days). */
	private const RENEWAL_GRACE_SECONDS = 1209600;

	/** @var string[] Plan slugs a license can name (the keys of Extensions' plan map). */
	private const PLANS = array( 'starter', 'trio', 'business' );

	/** License states projected by get_license_state(). */
	public const STATE_ACTIVE        = 'active';
	public const STATE_RENEWAL_GRACE = 'renewal_grace';
	public const STATE_EXPIRED       = 'expired';
	public const STATE_NONE          = 'none';

	/** @var int Transient TTL after a successful remote check. */
	private const CACHE_TTL_SECONDS = 3600;

	/** @var int Transient TTL while serving cached data during grace. */
	private const GRACE_CACHE_TTL_SECONDS = 21600;

	// API URL
	private $api_url = 'https://wp-modula.com/wp-json/wpchill-utils/v1/license';

	// Transients
	private $transient = 'modula_pro_license_status';

	// Options
	private $current_plan  = 'modula_pro_current_plan';
	private $license_data  = 'modula_pro_license_data';
	private $license_key   = 'modula_pro_license_key';
	private $last_verified = 'modula_pro_license_last_verified';

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Licensing ) ) {
			self::$instance = new Licensing();
		}
		return self::$instance;
	}

	public function __construct() {
		register_activation_hook( \MODULA_PRO_FILE, array( $this, 'schedule_tracking' ) );
		add_filter( 'modula_uninstall_transients', array( $this, 'uninstall_transients' ) );
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_options' ) );

		// Set the weekly interval.
		add_filter( 'cron_schedules', array( $this, 'set_weekly_cron_schedule' ) );

		// Hook our check_license_valability function to the weekly action.
		add_action( 'wpchill_weekly_license', array( $this, 'check_license' ) );

		// Remove the upgrade plugin action link from the plugin row.
		add_filter( 'modula_upgrade_plugin_action', array( $this, 'remove_upgrade_plugin_action' ) );
	}

	public function remove_upgrade_plugin_action( $actions ) {
		// Follows the license, not the plan: an expired license keeps Lite's upgrade link, renewal grace included.
		$valid = $this->is_license_valid();

		if ( ! $valid ) {
			return $actions;
		}

		$actions['upgrade_available'] = false;
		return $actions;
	}

	/**
	 * Make API request to license server
	 *
	 * @param array $data Request data to send.
	 * @return object|false Response object on success, false on failure.
	 */
	private function make_request( $data ) {
		$args = array(
			'timeout'   => 15,
			'sslverify' => true,
			'headers'   => array(
				'Content-Type' => 'application/json',
			),
			'body'      => wp_json_encode( $data ),
		);

		$response = wp_remote_post( $this->api_url, $args );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		if ( $status_code < 200 || $status_code >= 300 ) {
			return false;
		}

		$body    = wp_remote_retrieve_body( $response );
		$decoded = json_decode( $body );

		if ( null === $decoded && json_last_error() !== JSON_ERROR_NONE ) {
			return false;
		}

		return $decoded;
	}

	/**
	 * Whether the remote payload is a license status object we can trust.
	 *
	 * @param mixed $response Decoded API response.
	 * @return bool
	 */
	private function is_valid_license_response( $response ) {
		return is_object( $response ) && isset( $response->status ) && is_string( $response->status );
	}

	/**
	 * @param mixed $response Decoded API response.
	 * @return bool
	 */
	private function is_active_license_response( $response ) {
		return $this->is_valid_license_response( $response ) && 'active' === $response->status;
	}

	/**
	 * Timestamp of the last successful remote verification for an active license.
	 *
	 * @return int
	 */
	private function get_last_verified_timestamp() {
		return (int) get_option( $this->last_verified, 0 );
	}

	/**
	 * Bootstrap last_verified for sites that already had an active license stored before grace existed.
	 *
	 * @return void
	 */
	private function bootstrap_last_verified_from_stored_license() {
		if ( $this->get_last_verified_timestamp() > 0 ) {
			return;
		}

		$stored = $this->get_license_data();
		if ( $stored && $this->is_active_license_response( $stored ) ) {
			update_option( $this->last_verified, time() );
		}
	}

	/**
	 * @return bool
	 */
	public function is_in_grace_period() {
		$this->bootstrap_last_verified_from_stored_license();

		$last_verified = $this->get_last_verified_timestamp();
		if ( $last_verified <= 0 ) {
			return false;
		}

		return ( time() - $last_verified ) < self::GRACE_PERIOD_SECONDS;
	}

	/**
	 * Last known good active license payload (transient, then option).
	 *
	 * @return object|false
	 */
	private function get_fallback_license_status() {
		$cached = $this->get_cached_status();
		if ( $cached && $this->is_active_license_response( $cached ) ) {
			return $cached;
		}

		$stored = $this->get_license_data();
		if ( $stored && $this->is_active_license_response( $stored ) ) {
			return $stored;
		}

		return false;
	}

	/**
	 * Persist a trustworthy remote response. Never clears the plan on malformed payloads.
	 *
	 * @param object $response Decoded API response.
	 * @return bool True when persisted.
	 */
	private function persist_license_response( $response ) {
		if ( ! $this->is_valid_license_response( $response ) ) {
			return false;
		}

		if ( $this->is_active_license_response( $response ) ) {
			if ( ! empty( $response->product_slug ) ) {
				update_option( $this->current_plan, sanitize_key( $response->product_slug ) );
			}
			update_option( $this->last_verified, time() );
		} else {
			update_option( $this->current_plan, '' );
		}

		update_option( $this->license_data, $response );

		return true;
	}

	/**
	 * Cache license status in a transient.
	 *
	 * @param object $response License status object.
	 * @param int    $ttl      Cache lifetime in seconds.
	 * @return void
	 */
	private function cache_license_status( $response, $ttl ) {
		if ( ! is_object( $response ) ) {
			return;
		}

		set_transient( $this->transient, $response, max( 60, $ttl ) );
	}

	/**
	 * When the license server cannot be reached, reuse the last known active status during grace.
	 *
	 * @return object|false
	 */
	private function handle_license_check_failure() {
		if ( ! $this->is_in_grace_period() ) {
			return false;
		}

		$fallback = $this->get_fallback_license_status();
		if ( ! $fallback ) {
			return false;
		}

		$this->cache_license_status( $fallback, self::GRACE_CACHE_TTL_SECONDS );

		return $fallback;
	}

	/**
	 * Persist a trustworthy remote response and cache it as the current license status.
	 *
	 * @param object|false $response Decoded API response, false on request failure.
	 * @return bool True when stored.
	 */
	private function store_license_response( $response ) {
		if ( ! $this->persist_license_response( $response ) ) {
			return false;
		}

		$this->cache_license_status( $response, self::CACHE_TTL_SECONDS );

		return true;
	}

	/**
	 * Whether an activation answer makes the key this site's license: an active license, or an expired one,
	 * which is saved so its renewal grace applies and the license card can offer the renewal.
	 *
	 * @param mixed $response Decoded API response.
	 * @return bool
	 */
	private function is_accepted_key_response( $response ) {
		return $this->is_active_license_response( $response ) || $this->is_expired_license_response( $response );
	}

	/**
	 * @return string The saved license key, '' when there is none.
	 */
	private function saved_license_key() {
		return trim( (string) get_option( $this->license_key, '' ) );
	}

	/**
	 * Activate a license key
	 *
	 * A new key replaces the saved license only once the license server reports it active or expired (expired
	 * starts its renewal grace): any other answer or a failed request changes no option or cache, so the
	 * caller can show the error over the current license.
	 * The replaced key is then deactivated on this site. Re-activating the saved key (plugin re-activation, the
	 * same key entered again) stores the answer whatever its status, as a license check does, because it
	 * describes the current license.
	 *
	 * @param string $license_key License key to activate.
	 * @return object|false The license server's answer, false on request failure.
	 */
	public function activate_license( $license_key ) {
		$license_key  = trim( (string) $license_key );
		$saved_key    = $this->saved_license_key();
		$is_saved_key = '' !== $saved_key && $license_key === $saved_key;
		$response     = $this->request_license_action( 'activate', $license_key );

		if ( $is_saved_key ) {
			$this->store_license_response( $response );
			return $response;
		}

		if ( ! $this->is_accepted_key_response( $response ) ) {
			return $response;
		}

		update_option( $this->license_key, $license_key );
		$this->store_license_response( $response );

		if ( '' !== $saved_key ) {
			$this->release_license_key( $saved_key );
		}

		return $response;
	}

	/**
	 * Deactivate a replaced key on this site, best effort. Its answer is not stored, since the saved license
	 * is now the new key; when the server does not release it, the old license keeps counting this site
	 * until the owner frees it in their wp-modula.com account.
	 *
	 * @param string $license_key Replaced license key.
	 * @return void
	 */
	private function release_license_key( $license_key ) {
		$this->request_license_action( 'deactivate', $license_key );
	}

	/**
	 * Send one license action for this site to the license server.
	 *
	 * @param string $action      activate|deactivate|check.
	 * @param string $license_key License key the action applies to.
	 * @return object|false Response object, false on request failure.
	 */
	private function request_license_action( $action, $license_key ) {
		$response = $this->make_request(
			array(
				'action'      => $action,
				'url'         => home_url(),
				'license_key' => $license_key,
				'item_id'     => MODULA_PRO_STORE_ITEM_ID,
			)
		);

		return $this->honor_paid_term( $response );
	}

	/**
	 * Cancelling a subscription disables its license on the store at once, but the customer paid until
	 * `expiration`, so a disabled license with a future expiration is read as active; the store's own
	 * status is kept in `store_status`. The store expires or revokes licenses that must stop earlier.
	 *
	 * This is done once, on the answer as it arrives, so every reader agrees, including the license card
	 * of a Lite release that predates the rule (Lite and Pro update separately). A disabled lifetime
	 * license, or one without a date, has no term left and stays disabled.
	 *
	 * @param object|false $response Decoded API response, false on request failure.
	 * @return object|false The answer, active within a disabled license's paid term.
	 */
	private function honor_paid_term( $response ) {
		if ( ! $this->is_valid_license_response( $response ) || 'disabled' !== $response->status ) {
			return $response;
		}

		$expiration = $this->expiration_timestamp( $response );
		if ( null === $expiration || $expiration <= time() ) {
			return $response;
		}

		$response->store_status = $response->status;
		$response->status       = 'active';

		return $response;
	}

	/**
	 * Deactivate a license key
	 *
	 * @param string $license_key License key to deactivate.
	 * @return object|false Response object with license status, false on request failure.
	 */
	public function deactivate_license( $license_key ) {
		$this->clear_cache();

		$response = $this->request_license_action( 'deactivate', $license_key );

		if ( $this->store_license_response( $response ) ) {
			delete_option( $this->license_key );
			delete_option( $this->last_verified );
		}

		return $response;
	}

	/**
	 * Check license status
	 *
	 * @param bool   $force_refresh Whether to bypass transient cache.
	 * @return object|false Response object with license status, false on request failure.
	 */
	public function check_license( $force_refresh = false ) {
		if ( ! $force_refresh && $this->get_cached_status() ) {
			return $this->get_cached_status();
		}

		$license_key = get_option( $this->license_key, '' );

		if ( ! $license_key ) {
			return false;
		}

		$response = $this->request_license_action( 'check', $license_key );

		if ( ! $this->store_license_response( $response ) ) {
			return $this->handle_license_check_failure();
		}

		return $response;
	}

	/**
	 * Clear license status cache
	 *
	 * @return bool True on success, false on failure.
	 */
	public function clear_cache() {
		return delete_transient( $this->transient );
	}

	/**
	 * Get cached license status
	 *
	 * @return object|false Cached license status object, false if not cached.
	 */
	public function get_cached_status() {
		return get_transient( $this->transient );
	}

	/**
	 * Get license data
	 *
	 * @return object|false License data object, false if not found.
	 */
	public function get_license_data() {
		return get_option( $this->license_data );
	}

	/**
	 * Product the stored license names, such as "Agency license".
	 *
	 * @return string Unescaped, '' when the stored answer names none.
	 */
	public function get_product_name() {
		$license = $this->get_license_data();
		if ( ! is_object( $license ) || ! isset( $license->product_name ) || ! is_string( $license->product_name ) ) {
			return '';
		}

		return trim( $license->product_name );
	}

	/**
	 * Get the transient name
	 *
	 * @return string The transient name.
	 */
	public function get_transient_name() {
		return $this->transient;
	}

	/**
	 * Set weekly cron schedule
	 *
	 * @param array $schedules list of recurrences
	 */
	public function set_weekly_cron_schedule( $schedules ) {
		// cron_schedules may run before init (e.g. wp_schedule_event from plugins_loaded); avoid __() until textdomain may load (WP 6.7+).
		$weekly_display = did_action( 'init' ) ? __( 'Weekly', 'modula-pro' ) : 'Weekly';

		$schedules['weekly'] = array(
			'interval' => 604800,
			'display'  => $weekly_display,
		);

		return $schedules;
	}

	/**
	 * When the plugin is activated
	 * Create scheduled event
	 * And check if tracking is enabled - perhaps the plugin has been reactivated
	 */
	public function schedule_tracking() {
		if ( ! wp_next_scheduled( 'wpchill_weekly_license' ) ) {
			wp_schedule_event( time(), 'weekly', 'wpchill_weekly_license' );
		}

		$this->check_license();
	}

	/**
	 * Add our transients to the uninstall process
	 *
	 * @param $transients
	 *
	 * @return mixed
	 *
	 */
	public function uninstall_transients( $transients ) {
		$transients[] = $this->get_transient_name();
		return $transients;
	}

	/**
	 * Add our options to the uninstall process.
	 *
	 * @param array $db_options Option names.
	 * @return array
	 */
	public function uninstall_options( $db_options ) {
		$db_options[] = $this->last_verified;
		return $db_options;
	}

	/**
	 * Plan slug used for extension gating: the license's plan while it is active or in renewal grace.
	 *
	 * @return string starter|trio|business, or '' when no plan is covered.
	 */
	public function get_current_plan() {
		return $this->get_license_state()['plan'];
	}

	/**
	 * Whether the site's license covers a plan (active or in renewal grace): the gate for Pro features
	 * the plan includes. Use is_license_valid() (active, or within the license check grace) only where the
	 * license itself matters, such as the upgrade notice.
	 *
	 * @return bool
	 */
	public function has_plan() {
		return '' !== $this->get_current_plan();
	}

	/**
	 * Inspect existing entitlement state without repairing options or refreshing a provider.
	 * Never returns the license payload/key.
	 *
	 * @return array{plan:string,status:string} `status` is one of the STATE_* values.
	 */
	public function get_read_only_status() {
		$license = $this->get_license_state();

		return array(
			'plan'   => $license['plan'],
			'status' => $license['state'],
		);
	}

	/**
	 * Entitlement from the saved key and the stored license server answer, without writes or remote calls.
	 *
	 * Without a saved key (never licensed, or deactivated) there is no plan. An expired license keeps its
	 * plan until renewal grace ends. The license check grace for an unreachable server is a separate rule:
	 * it keeps the last stored answer, which this method reads as is.
	 *
	 * @return array{state:string,plan:string,renewal_grace_ends:int|null} `renewal_grace_ends` is a unix
	 *         timestamp, set only in renewal grace.
	 */
	public function get_license_state() {
		$license = $this->get_license_data();

		if ( ! $this->has_saved_license_key() || ! $this->is_valid_license_response( $license ) ) {
			return $this->build_license_state( self::STATE_NONE );
		}

		if ( $this->is_active_license_response( $license ) ) {
			return $this->build_license_state( self::STATE_ACTIVE, $this->licensed_plan( $license ) );
		}

		if ( ! $this->is_expired_license_response( $license ) ) {
			return $this->build_license_state( self::STATE_NONE );
		}

		$grace_ends = $this->renewal_grace_ends( $license );
		if ( null === $grace_ends || time() >= $grace_ends ) {
			return $this->build_license_state( self::STATE_EXPIRED );
		}

		return $this->build_license_state( self::STATE_RENEWAL_GRACE, $this->licensed_plan( $license ), $grace_ends );
	}

	/**
	 * @param mixed $response Decoded API response.
	 * @return bool
	 */
	private function is_expired_license_response( $response ) {
		return $this->is_valid_license_response( $response ) && 'expired' === $response->status;
	}

	/**
	 * @param string   $state              One of the STATE_* values.
	 * @param string   $plan               Plan slug, '' for none.
	 * @param int|null $renewal_grace_ends Unix timestamp, null outside renewal grace.
	 * @return array{state:string,plan:string,renewal_grace_ends:int|null}
	 */
	private function build_license_state( $state, $plan = '', $renewal_grace_ends = null ) {
		return array(
			'state'              => $state,
			'plan'               => $plan,
			'renewal_grace_ends' => $renewal_grace_ends,
		);
	}

	/**
	 * @return bool
	 */
	private function has_saved_license_key() {
		return '' !== $this->saved_license_key();
	}

	/**
	 * Plan saved for the license (then the plan the license names).
	 *
	 * The plan option comes first, as before renewal grace existed: an active answer saves its product
	 * there, an expired one clears it (so renewal grace falls back to the stored product), and the
	 * `pre_option_modula_pro_current_plan` filter keeps working for tests and site overrides.
	 *
	 * An unrecognized product has no plan rather than a guessed one: with no plan nothing loads and the
	 * active set is kept, while a guessed smaller plan would deactivate (and run the destructive hooks of)
	 * every extension outside it.
	 *
	 * @param object $license Stored license server answer.
	 * @return string starter|trio|business, or ''.
	 */
	private function licensed_plan( $license ) {
		$candidates = array(
			get_option( $this->current_plan, '' ),
			isset( $license->product_slug ) ? sanitize_key( (string) $license->product_slug ) : '',
		);

		foreach ( $candidates as $plan ) {
			if ( in_array( $plan, self::PLANS, true ) ) {
				return $plan;
			}
		}

		return '';
	}

	/**
	 * End of renewal grace for an expired license.
	 *
	 * @param object $license Stored license server answer; `expiration` is unix seconds or 'lifetime'.
	 * @return int|null Null when the answer carries no expiry date.
	 */
	private function renewal_grace_ends( $license ) {
		$expiration = $this->expiration_timestamp( $license );

		return null === $expiration ? null : $expiration + self::RENEWAL_GRACE_SECONDS;
	}

	/**
	 * @param object $license License server answer; `expiration` is unix seconds or 'lifetime'.
	 * @return int|null The expiry date, null when the answer carries none.
	 */
	private function expiration_timestamp( $license ) {
		$expiration = isset( $license->expiration ) ? $license->expiration : null;
		$has_date   = is_int( $expiration ) || ( is_string( $expiration ) && ctype_digit( $expiration ) );

		return ( $has_date && (int) $expiration > 0 ) ? (int) $expiration : null;
	}

	/**
	 * Check if license is valid
	 *
	 * @return bool|null True if license is valid, false if license is not valid, null if license is not found.
	 */
	public function is_license_valid() {
		$license_status = $this->get_license_data();

		// If the option is false it means it is empty
		if ( ! $license_status ) {
			return null;
		}

		if ( 'active' === $license_status->status ) {
			return true;
		}

		if ( $this->is_in_grace_period() && $this->get_fallback_license_status() ) {
			return true;
		}

		return false;
	}
}
