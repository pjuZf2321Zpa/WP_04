<?php

$speedup_settings = get_option( 'modula_speedup', array(
	'enable_optimization'    => 'disabled',
	'thumbnail_optimization' => 'lossy',
	'lightbox_optimization'  => 'lossless',
) );

if ( ! $this->run_compression() ) {
	$speedup_settings['enable_optimization'] = 'disabled';
}

$values = array(
	'lossless' => esc_html__( 'Lossless Compresion', 'modula-speedup' ),
	'lossy'    => esc_html__( 'Lossy Compresion', 'modula-speedup' ),
	'glossy'   => esc_html__( 'Glossy Compresion', 'modula-speedup' ),
	'disabled' => esc_html__( 'Disable Compresion', 'modula-speedup' ),
);


?>
<style type="text/css">
	/* Toggles */
	.modula-toggle {
	    position: relative;
	    position: relative;
	    user-select: none;
	    display: inline-block;
	}

	.modula-toggle__items {
	  box-sizing: border-box;
	  display: inline-block;
	    position: relative;
	}
	.modula-toggle__items > * {
	  box-sizing: inherit;
	}

	.modula-toggle__input[type=checkbox] {
	  border-radius: 2px;
	  border: 2px solid #6c7781;
	  margin-right: 12px;
	  transition: none;
	  height: 100%;
	  left: 0;
	  top: 0;
	  margin: 0;
	  padding: 0;
	  opacity: 0;
	  position: absolute;
	  width: 100%;
	  z-index: 1; }

	.modula-toggle__track {
	  background-color: #fff;
	  border: 2px solid #6c7781;
	  border-radius: 9px;
	  display: inline-block;
	  height: 18px;
	  width: 36px;
	  vertical-align: top;
	  transition: background .2s ease; }

	.modula-toggle__thumb {
	  background-color: #6c7781;
	  border: 5px solid #6c7781;
	  border-radius: 50%;
	  display: block;
	  height: 10px;
	  width: 10px;
	  position: absolute;
	  left: 4px;
	  top: 4px;
	  transition: transform .2s ease; }

	.modula-toggle__off {
	  position: absolute;
	  right: 6px;
	  top: 6px;
	  color: #6c7781;
	  fill: currentColor; }

	.modula-toggle__on {
	  position: absolute;
	  top: 6px;
	  left: 8px;
	  border: 1px solid #fff;
	  outline: 1px solid transparent;
	  outline-offset: -1px;
	  display: none; }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__track {
	  background-color: var(--wp-admin-theme-color, #2271b1);;
	  border: 9px solid transparent; }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__thumb {
	  background-color: #fff;
	  border-width: 0;
	  transform: translateX(18px); }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__off {
	  display: none; }

	.modula-toggle__input[type=checkbox]:checked + .modula-toggle__items .modula-toggle__on {
	  display: inline-block; }

	.post-type-modula-gallery tr.compression_disabled {
      opacity: 0.5; }
	.compression_disabled .modula-toggle__input[type=checkbox]{
	  cursor: default;
      border: none; }
	.compression_disabled .modula-toggle__input[type=checkbox]:checked::before{
	  display: none; }
</style>
<div class="row">
	<form method="post" action="options.php">

		<?php settings_fields('modula_speedup'); ?>

		<?php
		$disabled       = $this->run_compression() ? '' : 'compression_disabled';
		$disabled_input = $this->run_compression() ? false : 'disabled';
		?>

		<table class="form-table">
			<tbody>
				<tr valign="top" class="<?php echo esc_attr( $disabled ); ?>">
					<th scope="row" valign="top">
						<?php _e('Compression', 'modula-speedup'); ?>
					</th>
					<td>
						<div class="modula-toggle">
							<input id="modula_speedup_optimization" class="modula-toggle__input" type="checkbox" <?php echo $disabled_input ? sprintf('disabled="%s"', esc_attr( $disabled_input ) ) : ''; ?> <?php checked( 'enabled', $speedup_settings['enable_optimization'], true ); ?> name="modula_speedup[enable_optimization]" value="enabled">
							<div class="modula-toggle__items">
								<span class="modula-toggle__track"></span>
								<span class="modula-toggle__thumb"></span>
								<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 6 6"><path d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path></svg>
								<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true" role="img" focusable="false" viewBox="0 0 2 6"><path d="M0 0h2v6H0z"></path></svg>
							</div>
							<!-- <label for="modula_speedup_optimization"></label> -->
						</div>
					</td>
				</tr>
				<tr valign="top" class="<?php echo esc_attr( $disabled ); ?>">
					<th scope="row" valign="top">
						<?php _e('Thumbnail Compression', 'modula-speedup'); ?>
					</th>
					<td>
						<select name="modula_speedup[thumbnail_optimization]"  <?php echo $disabled_input ? sprintf('disabled="%s"', esc_attr( $disabled_input ) ) : ''; ?>>
							<?php
							foreach ( $values as $value => $label ) {
								echo '<option value="' . $value . '" ' . selected( $value, $speedup_settings['thumbnail_optimization'], false ) . '>' . $label . '</option>';
							}
							?>
						</select>
					</td>
				</tr>
				<tr valign="top" class="<?php echo esc_attr( $disabled ); ?>">
					<th scope="row" valign="top">
						<?php _e('Lightbox Compression', 'modula-speedup'); ?>
					</th>
					<td>
						<select name="modula_speedup[lightbox_optimization]"  <?php echo $disabled_input ? sprintf('disabled="%s"', esc_attr( $disabled_input ) ) : ''; ?>>
							<?php
							foreach ( $values as $value => $label ) {
								echo '<option value="' . $value . '" ' . selected( $value, $speedup_settings['lightbox_optimization'], false ) . '>' . $label . '</option>';
							}
							?>
						</select>
					</td>
				</tr>
			</tbody>
		</table>
		<div>
			<?php
			if( ! $this->run_compression() ){
				echo'<span class="dashicons dashicons-warning"></span> ';
				echo sprintf( esc_html__( 'We\'ve detected that your site is running in a %s %s environment%s, and as a result, our image optimization services have been disabled. If you have questions, please contact us at %shello@wp-modula.com%s', 'modula-best-grid-gallery' ), '<strong>', wp_get_environment_type(), '</strong>', '<a target="_BLANK" href="mailto:hello@wp-modula.com">', '</a>' ) ;
				echo '<br>';
			}
			echo '<p>' . sprintf( '<strong>%s</strong>. %s', esc_html__( 'Lossless Compression', 'modula-speedup' ), esc_html__( 'File sizes will be reduced by removing unnecessary image information (and statistical redundancies) resulting in no loss of quality.', 'modula-speedup' ) ) . '</p>';
			echo '<p>' . sprintf( '<strong>%s</strong>. %s', esc_html__( 'Lossy Compression', 'modula-speedup' ), esc_html__( 'File sizes will be significantly reduced, resulting in a slight loss of image quality that is visible', 'modula-speedup' ) ) . '</p>';
			echo '<p>' . sprintf( '<strong>%s</strong>. %s', esc_html__( 'Glossy Compression', 'modula-speedup' ), esc_html__( 'Glossy is the best choice if you care about your website’s load time and you believe that a slight loss of page speed is an acceptable compromise for top-notch image quality.', 'modula-speedup' ) ) . '</p>';
			?>
		</div>
		<?php submit_button(); ?>
	</form>
</div>