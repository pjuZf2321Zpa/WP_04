<?php

namespace Modula_Pro\Extensions\Speedup\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	/**
	 * Holds the admin class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	public function __construct() {

		// Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_speedup_fields' ) );

		// Filter Modula Gallery
		add_filter( 'modula_gallery_tabs', array( $this, 'add_speedup_gallery' ) );

		// Filter Defaults
		add_filter( 'modula_lite_default_settings', array( $this, 'default_settings' ) );

		// Render Field Type
		add_filter( 'modula_render_speedup-select_field_type', array( $this, 'render_field_type' ), 10, 3 );

		// Stop resize if we have speed up enabled
		add_filter( 'modula_resize_images', array( $this, 'check_if_optimize' ), 10, 2 );

		// Add Setings Tab
		add_filter( 'modula_admin_page_tabs', array( $this, 'add_compression_tab' ) );
		add_action( 'modula_admin_tab_compression', array( $this, 'render_compression_tab' ) );
		add_action( 'admin_init', array( $this, 'register_compression_option' ) );

		add_filter( 'modula_field_type_speedup-select_format', array( $this, 'modula_compression_compatibilty_admin_field' ), 99, 2 );
	}

	/**
	 * Notice for disabled compression due to local environment
	 *
	 *
	 * @return string
	 * @since 1.0.16
	 */
	public function modula_compression_compatibilty_notice() {

		$notice = '<span class="dashicons dashicons-warning"></span> ';
		/* translators: 1: environment type, 2: environment type, 3: environment type, 4: email address, 5: email address */
		$notice .= sprintf( esc_html__( 'We\'ve detected that your site is running in a %1$s %2$s environment%3$s, and as a result, our image optimization services have been disabled. If you have questions, please contact us at %4$shello@wp-modula.com%5$s', 'modula-pro' ), '<strong>', wp_get_environment_type(), '</strong>', '<a target="_BLANK" href="mailto:hello@wp-modula.com">', '</a>' );
		$notice .= '<br><br>';

		return $notice;
	}

	/**
	 * Settings rows format
	 *
	 * @param $format
	 *
	 * @param $field
	 *
	 * @return string
	 * @since 1.0.16
	 */
	public function modula_compression_compatibilty_admin_field( $format, $field ) {

		$disabled = $this->run_compression() ? '' : 'compression_disabled';

		$format = '<tr data-container="' . esc_attr( $field['id'] ) . '" class="' . esc_attr( $disabled ) . '"><th scope="row" ><label>%s</label>%s</th><td>%s</td></tr>';

		return $format;
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Video_Setings object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Settings ) ) {
			self::$instance = new Settings();
		}

		return self::$instance;
	}


	public function add_speedup_gallery( $tabs ) {

		if ( isset( $tabs['speedup'] ) ) {
			return $tabs;
		}

		$tabs['speedup'] = array(
			'label'    => esc_html__( 'Speed Up', 'modula-pro' ),
			'title'    => esc_html__( 'Optimize your images', 'modula-pro' ),
			'icon'     => 'dashicons dashicons-dashboard',
			'priority' => 75,
		);

		return $tabs;
	}

	/**
	 * Add video related settings.
	 *
	 * @since 1.0.0
	 *
	 * @return array $fields.
	 */
	public function modula_speedup_fields( $fields ) {

		$fields['speedup'] = array(
			'enable_optimization'    => array(
				'name'      => esc_html__( 'Compression', 'modula-pro' ),
				'type'      => 'speedup-select',
				'default'   => 'default',
				'values'    => array(
					'default'  => esc_html__( 'Default', 'modula-pro' ),
					'enabled'  => esc_html__( 'Enabled', 'modula-pro' ),
					'disabled' => esc_html__( 'Disabled', 'modula-pro' ),
				),
				'priority'  => 1,
				'data_type' => 'text',
			),
			'thumbnail_optimization' => array(
				'name'      => esc_html__( 'Thumbnail Compression', 'modula-pro' ),
				'type'      => 'speedup-select',
				'default'   => 'default',
				'values'    => array(
					'default'  => esc_html__( 'Default', 'modula-pro' ),
					'lossless' => esc_html__( 'Lossless Compresion', 'modula-pro' ),
					'lossy'    => esc_html__( 'Lossy Compresion', 'modula-pro' ),
					'glossy'   => esc_html__( 'Glossy Compresion', 'modula-pro' ),
					'disabled' => esc_html__( 'Disable Compresion', 'modula-pro' ),
				),
				'priority'  => 5,
				'data_type' => 'text',
			),
			'lightbox_optimization'  => array(
				'name'      => esc_html__( 'Lightbox Compression', 'modula-pro' ),
				'type'      => 'speedup-select',
				'default'   => 'default',
				'values'    => array(
					'default'  => esc_html__( 'Default', 'modula-pro' ),
					'lossless' => esc_html__( 'Lossless Compresion', 'modula-pro' ),
					'lossy'    => esc_html__( 'Lossy Compresion', 'modula-pro' ),
					'glossy'   => esc_html__( 'Glossy Compresion', 'modula-pro' ),
					'disabled' => esc_html__( 'Disable Compresion', 'modula-pro' ),
				),
				'priority'  => 10,
				'data_type' => 'text',
			),
			'modula_speed_help'      => array(
				'name'     => '',
				'type'     => 'content',
				'content'  => $this->compression_description(),
				'priority' => 15,
			),
		);

		return $fields;
	}

	/**
	 * Add default for item's video url.
	 *
	 * @since 1.0.0
	 *
	 * @return array $defaults.
	 */
	public function default_settings( $defaults ) {

		$defaults['enable-optimization']    = 'default';
		$defaults['thumbnail_optimization'] = 'default';
		$defaults['lightbox_optimization']  = 'default';

		return $defaults;
	}

	/**
	 * Compression settings descriptions
	 *
	 * @since 1.0.0
	 *
	 * @modified 1.0.16
	 *
	 * @return string
	 */
	public function compression_description() {
		$description = '';
		if ( ! $this->run_compression() ) {
			$description .= $this->modula_compression_compatibilty_notice();
		}

		$description .= '<span class="dashicons dashicons-warning"></span> ';
		/* translators: 1: Modula settings link, 2: Modula settings link */
		$description .= sprintf( esc_html__( 'When set to *default* the Modula default gallery optimization settings you have chosen under %1$sModula > Settings%2$s will be used.', 'modula-pro' ), '<a target="_blank" href="' . admin_url( 'edit.php?post_type=modula-gallery&page=modula&modula-tab=compression' ) . '">', '</a>' );
		$description .= '<br><br>';
		$description .= sprintf( '<strong>%s</strong>. %s', esc_html__( 'Lossless Compression', 'modula-pro' ), esc_html__( 'File sizes will be reduced by removing unnecessary image information (and statistical redundancies) resulting in no loss of quality.', 'modula-pro' ) );
		$description .= '<br><br>';
		$description .= sprintf( '<strong>%s</strong>. %s', esc_html__( 'Lossy Compression', 'modula-pro' ), esc_html__( 'File sizes will be significantly reduced, resulting in a slight loss of image quality that is visible.', 'modula-pro' ) );
		$description .= '<br><br>';
		$description .= sprintf( '<strong>%s</strong>. %s', esc_html__( 'Glossy Compression', 'modula-pro' ), esc_html__( 'Glossy is the best choice if you care about your website’s load time and and you believe that a slight loss of page speed is an acceptable compromise for top-notch image quality.', 'modula-pro' ) );
		$description .= '<br>';

		return $description;
	}

	public function add_compression_tab( $tabs ) {

			$tabs['compression'] = array(
				'label'    => esc_html__( 'SpeedUp Settings', 'modula-pro' ),
				'priority' => 30,
			);

			return $tabs;
	}

	public function render_compression_tab() {
		include 'tabs/compression.php';
	}

	public function register_compression_option() {
		// creates our settings in the options table
		register_setting( 'modula_speedup', 'modula_speedup', array( $this, 'sanitize_option' ) );
	}

	public function sanitize_option( $current ) {
		$defaults = array(
			'enable_optimization'    => 'disabled',
			'thumbnail_optimization' => 'lossy',
			'lightbox_optimization'  => 'lossless',
		);

		$accepted_values = array( 'lossless', 'lossy', 'glossy', 'disabled' );
		$new             = array();

		if ( isset( $current['enable_optimization'] ) ) {
			$new['enable_optimization'] = 'enabled';
		} else {
			$new['enable_optimization'] = 'disabled';
		}

		if ( isset( $current['thumbnail_optimization'] ) && in_array( $current['thumbnail_optimization'], $accepted_values, true ) ) {
			$new['thumbnail_optimization'] = $current['thumbnail_optimization'];
		}

		if ( isset( $current['lightbox_optimization'] ) && in_array( $current['lightbox_optimization'], $accepted_values, true ) ) {
			$new['lightbox_optimization'] = $current['lightbox_optimization'];
		}

		$new = wp_parse_args( $new, $defaults );

		return $new;
	}

	public function render_field_type( $html, $field, $value ) {

		$default_values = array(
			'enable_optimization'    => 'disabled',
			'thumbnail_optimization' => 'lossy',
			'lightbox_optimization'  => 'lossless',
		);

		$defaults = get_option( 'modula_speedup', $default_values );

		$disabled = '';
		if ( ! $this->run_compression() ) {
			$value    = $default_values[ $field['id'] ];
			$disabled = 'disabled="disabled"';
		}

		$html = '<select name="modula-settings[' . esc_attr( $field['id'] ) . ']" data-setting="' . esc_attr( $field['id'] ) . '" ' . esc_attr( $disabled ) . ' class="regular-text speedup-select">';
		foreach ( $field['values'] as $key => $option ) {
			if ( is_array( $option ) ) {
				$html .= '<optgroup label="' . esc_attr( $key ) . '">';
				foreach ( $option as $key_subvalue => $subvalue ) {
					$html .= '<option value="' . esc_attr( $key_subvalue ) . '" ' . selected( $key_subvalue, $value, false ) . '>' . esc_html( $subvalue ) . '</option>';
				}
				$html .= '</optgroup>';
			} else {
				$html .= '<option value="' . esc_attr( $key ) . '" ' . selected( $key, $value, false ) . '>' . esc_html( $option ) . '</option>';
			}
		}
		$html .= '</select>';

		$style = '';
		if ( 'default' !== $value ) {
			$style = 'display:none';
		}

		$html .= '<span class="extra-info" style="' . $style . '">Default Status: <strong>' . $defaults[ $field['id'] ] . '</strong></span>';

		return $html;
	}

	public function check_if_optimize( $status, $settings ) {

		if ( ! isset( $settings['enable_optimization'] ) ) {
			return $status;
		}

		$defaults = get_option(
			'modula_speedup',
			array(
				'enable_optimization'    => 'disabled',
				'thumbnail_optimization' => 'lossy',
				'lightbox_optimization'  => 'lossless',
			)
		);

		if ( ( 'default' === $settings['enable_optimization'] && 'enabled' === $defaults['enable_optimization'] ) || 'enabled' === $settings['enable_optimization'] ) {
			return false;
		}

		return $status;
	}

	/**
	 * Checks if the environment type should run compression functionality.
	 *
	 * Lite owns the gate (Modula_Settings::compression_available()), so Pro's
	 * Speed Up admin, Lite's Settings page and the gallery editor agree. An
	 * older Lite without it gets the same filter evaluated here.
	 *
	 * @since 1.0.16
	 *
	 * @return bool
	 */
	public function run_compression() {
		if ( method_exists( '\Modula_Settings', 'compression_available' ) ) {
			return \Modula_Settings::compression_available();
		}

		return apply_filters( 'modula_speedup_run_local_compression', 'production' === \wp_get_environment_type() );
	}
}
