<?php

namespace Modula_Pro\Extensions\Speedup;

use Modula_Pro\Extensions\Licensing;
use Modula_Pro\Extensions\Speedup\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Speedup class for Modula Pro plugin.
 *
 */
class Speedup {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	private $imgopt_host;
	private $site_host;
	private $settings;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->imgopt_host = apply_filters( 'modula_speedup_cdn_domain', 'https://wp-modula.b-cdn.net/' );
		// Get website domain
		if ( function_exists( 'domain_mapping_siteurl' ) ) {
			$this->site_host = \domain_mapping_siteurl( get_current_blog_id() );
		} else {
			$this->site_host = site_url();
		}

		add_action( 'admin_init', array( Settings::class, 'get_instance' ), 25 );

		add_filter( 'modula_lite_default_settings', array( $this, 'speedup_defaults' ) );

		add_filter( 'modula_shortcode_item_data', array( $this, 'generate_optimized_image_links' ), 100, 3 );
		// Finalize Beta candidates after image protection has supplied its policy.
		add_filter( 'modula_shortcode_item_data', array( $this, 'finalize_beta_responsive_images' ), 1000, 3 );

		// Optimisation for gallery image in Albums
		add_filter( 'modula_album_shortcode_item_data', array( $this, 'generate_optimized_image_links' ), 100, 3 );

		// Optimisation for gallery lightbox images in Albums
		add_filter( 'modula_album_lightbox_item', array( $this, 'generate_lightbox_config_image_url' ), 100, 3 );

		// The same for Beta albums (Album visitor frontend), after Video gives a video row its poster.
		add_filter( 'modula_album_visitor_lightbox_item', array( $this, 'album_visitor_lightbox_item' ), 100, 3 );
		add_filter( 'modula_album_visitor_cover', array( $this, 'album_visitor_cover' ), 100, 2 );

		// Optimisation for gallery lightbox images with modula link.
		add_filter( 'modula_link_item', array( $this, 'generate_modula_link_image_url' ), 100, 4 );

		add_action( 'modula_shortcode_after_items', array( $this, 'after_gallery' ) );

		add_filter( 'modula_imgopt_separator', array( $this, 'wp_optimize_compatibility' ) );

		$this->settings = get_option(
			'modula_speedup',
			array(
				'enable_optimization'    => 'disabled',
				'thumbnail_optimization' => 'lossy',
				'lightbox_optimization'  => 'lossless',
			)
		);

		add_filter( 'modula_uninstall_db_options', array( $this, 'speedup_uninstall' ), 18, 1 );

		// Add debug information
		add_filter( 'modula_debug_information', array( $this, 'debug_information' ), 40 );

		// Filter for the srcset and sizes on template image
		add_filter( 'modula_template_image_srcset', array( $this, 'modula_speedup_srcset' ), 30, 3 );

		add_filter( 'modula_gallery_tabs', array( $this, 'modula_speedup_tab' ), 99 );
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Speedup object.
	 * @since 1.0.0
	 *
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Speedup ) ) {
			self::$instance = new Speedup();
		}

		return self::$instance;
	}

	public function generate_optimized_image_links( $item_data, $item, $settings ) {
		// Ensure that the settings are set.
		$settings     = wp_parse_args( $settings, \Modula_CPT_Fields_Helper::get_defaults() );
		$compressions = $this->compressions( $settings );
		if ( null === $compressions ) {
			return $item_data;
		}

		if ( ! isset( $settings['modula_display_context'] ) ) {
			add_filter( 'modula_resize_images', '__return_false', 10 );
		}

		$image_compresion    = $compressions['thumbnail'];
		$lightbox_compresion = $compressions['lightbox'];

		if ( 'disabled' === $image_compresion && 'disabled' === $lightbox_compresion ) {
			return $item_data;
		}

		$gallery_type = isset( $settings['type'] ) ? $settings['type'] : 'creative-gallery';
		$grid_sizes   = false;
		$crop         = false;
		$grid_types   = array( 'creative-gallery', 'custom-grid', 'grid', 'justified-grid', 'parallax-masonry', 'uniform-grid', 'fit-grid', 'polaroid', 'bento' );

		if ( in_array( $gallery_type, $grid_types, true ) ) {
			if ( 'custom' !== $settings['grid_image_size'] ) {
				$grid_sizes = $settings['grid_image_size'];
			} elseif ( 'custom-grid' === $settings['type'] ) {
					$grid_sizes = array(
						'width'  => absint( $settings['img_size'] ) * absint( isset( $item['width'] ) ? $item['width'] : 1 ),
						'height' => absint( $settings['img_size'] ) * absint( isset( $item['height'] ) ? $item['height'] : 1 ),
					);
			} else {
				$grid_sizes = isset( $settings['grid_image_dimensions'] ) ? $settings['grid_image_dimensions'] : array();
				if ( ! is_array( $grid_sizes ) ) {
					$dim        = absint( $grid_sizes );
					$grid_sizes = array(
						'width'  => $dim,
						'height' => $dim,
					);
				}
			}

			if ( 'custom' === $settings['grid_image_size'] ) {
				if ( 'custom-grid' === $settings['type'] ) {
					$settings['img_crop'] = isset( $settings['img_crop'] ) ? $settings['img_crop'] : 1;
					$crop                 = boolval( $settings['img_crop'] );
				} else {
					$crop = boolval( $settings['grid_image_crop'] );
				}
			}
		} elseif ( 'slider' === $gallery_type ) {
			$grid_sizes = isset( $settings['slider_image_size'] ) ? $settings['slider_image_size'] : '';

			if ( 'custom' === $grid_sizes ) {
				$grid_sizes = isset( $settings['slider_image_dimensions'] ) ? $settings['slider_image_dimensions'] : array();
				$crop       = boolval( isset( $settings['slider_image_crop'] ) ? $settings['slider_image_crop'] : false );
			} elseif ( 'default' === $grid_sizes || '' === $grid_sizes ) {
				$grid_sizes = 'large';
			}
		}

		$grid_sizes = apply_filters( 'modula_speedup_image_size', $grid_sizes, $settings );

		$image_attr = isset( $item_data['img_attributes'] ) && is_array( $item_data['img_attributes'] ) ? $item_data['img_attributes'] : array();

		if ( isset( $image_attr['data-src'] ) && isset( $image_attr['width'] ) && isset( $image_attr['height'] ) ) {
			$image_attr['data-src'] = $item_data['img_attributes']['data-src'];
		} else {
			$resizer = new \Modula_Image();
			$sizes   = $resizer->get_image_size( $item['id'], $gallery_type, $grid_sizes, $crop );
			if ( is_wp_error( $sizes ) || ! is_array( $sizes ) || empty( $sizes['url'] ) || ! isset( $sizes['width'], $sizes['height'] ) ) {
				return $item_data;
			}
			$resized = $resizer->resize_image( $sizes['url'], $sizes['width'], $sizes['height'], $crop );

			if ( is_wp_error( $resized ) || ! is_array( $resized ) || ! isset( $resized['resized_url'] ) ) {
				return $item_data;
			}

			$image_info = false;
			if ( isset( $resized['image_info'] ) ) {
				$image_info = $resized['image_info'];
			}

			$image_attr['data-src']  = $resized['resized_url'];
			$image_attr['width']     = $sizes['width'];
			$image_attr['height']    = $sizes['height'];
			$item_data['image_info'] = $image_info;
		}

		$thumb_url = false;

		if ( 'disabled' !== $image_compresion ) {
			if ( 0 === strpos( $image_attr['data-src'], $this->site_host ) ) {

				// Used to generate gallery images url for Modula Gallery
				$sp_args                = apply_filters(
					'modula_gallery_optimized_img_args',
					array(
						'w' => $image_attr['width'],
						'h' => $image_attr['height'],
						'q' => $image_compresion,
					),
					$item_data,
					$item,
					$settings
				);
				$image_attr['data-src'] = $this->build_imgopt_url( $image_attr['data-src'], $sp_args );
				$thumb                  = wp_get_attachment_image_src( $item['id'], 'thumbnail' );
				if ( $thumb ) {
					// Used to generate thumbnail navigation image url for Modula Gallery
					$sp_args_tmb = apply_filters(
						'modula_lightbox_thumb_optimized_img_args',
						array(
							'w' => $thumb[1],
							'h' => $thumb[2],
							'q' => $image_compresion,
						),
						$item_data,
						$item,
						$settings
					);
					$thumb_url   = $this->build_imgopt_url( $thumb[0], $sp_args_tmb );
				}
			}
		}

		// This is a fix for #36 working with Albums.
		if ( isset( $item_data['img_attributes']['src'] ) ) {
			$image_full = $item_data['img_attributes']['src'];
		}

		if ( isset( $item_data['img_attributes']['data-full'] ) ) {
			$image_full = $item_data['img_attributes']['data-full'];
		}

		if ( 'disabled' !== $lightbox_compresion ) {
			if ( 0 === strpos( $image_full, $this->site_host ) ) {
				// Used to generate lightbox image url in Modula Gallery
				$sp_args    = apply_filters(
					'modula_lightbox_optimized_img_args',
					array(
						'w' => 0,
						'h' => 0,
						'q' => $lightbox_compresion,
					),
					$item_data,
					$item,
					$settings
				);
				$image_full = $this->build_imgopt_url( $image_full, $sp_args );
			}
		}

		$item_data['image_full'] = $image_full;
		$item_data['image_url']  = $image_attr['data-src'];

		$item_data['img_attributes']['data-full'] = $image_full;

		// Add src to img tag if lazy load is disabled.
		// Modula Lite 2.12.26+ (new lazy load system)
		if ( isset( $settings['modula_display_context'] ) || ( function_exists( 'modula_run_lazy_load' ) && ! \modula_run_lazy_load( $settings ) ) ) {
			$item_data['img_attributes']['src'] = $image_attr['data-src'];

			// Older Modula Lite versions (fallback)
		} elseif ( ! function_exists( 'modula_run_lazy_load' ) && ( ! isset( $settings['lazy_load'] ) || '1' !== $settings['lazy_load'] ) ) {
			$item_data['img_attributes']['src'] = $image_attr['data-src'];
		}

		$item_data['img_attributes']['data-src'] = $image_attr['data-src'];

		// Add download link to image attribute. Prevents serving a CDN url to fancybox download.
		if ( isset( $settings['lightbox_download'] ) && ( '1' === $settings['lightbox_download'] || ( isset( $settings['modula_display_context'] ) && \Modula_Helper::is_truthy_flag( $settings['lightbox_download'] ) ) ) ) {

			// Set the original image url instead of ...-scaled.ext
			$item_data['img_attributes']['data-download'] = wp_get_original_image_url( $item['id'] );
		}

		if ( $thumb_url ) {
			$item_data['link_attributes']['data-thumb'] = $thumb_url;
		}

		$item_data['img_attributes']['width']  = (int) $image_attr['width'];
		$item_data['img_attributes']['height'] = (int) $image_attr['height'];
		$item_data['compression']              = $image_compresion;

		return $item_data;
	}

	/** Apply the saved Beta thumbnail policy to its existing responsive candidates. */
	public function finalize_beta_responsive_images( $item_data, $item, $settings ) {
		if ( ! isset( $settings['modula_display_context'] ) || empty( $item_data['compression'] ) || 'disabled' === $item_data['compression'] ) {
			return $item_data;
		}
		if ( empty( $item_data['img_attributes']['srcset'] ) ) {
			return $item_data;
		}

		$meta   = wp_get_attachment_metadata( $item['id'] );
		$data   = (object) $item_data;
		$width  = (int) ( $item_data['img_attributes']['width'] ?? 0 );
		$height = (int) ( $item_data['img_attributes']['height'] ?? 0 );
		if ( $width <= 0 || $height <= 0 ) {
			return $item_data;
		}
		$item_data['img_attributes']['srcset'] = preg_replace_callback(
			'/(\S+)\s+(\d+)w/',
			function ( $candidate ) use ( $data, $meta, $width, $height ) {
				$url = $candidate[1];
				if ( 0 !== strpos( $url, trailingslashit( $this->site_host ) ) ) {
					return $candidate[0];
				}
				$args = apply_filters(
					'modula_gallery_srcset_optimized_img_args',
					array(
						'w' => (int) $candidate[2],
						'h' => (int) round( $candidate[2] * $height / $width ),
						'q' => $data->compression,
					),
					$data->img_attributes['srcset'],
					$data,
					$meta
				);
				$url = apply_filters( 'modula_gallery_srcset_image_url', $url, $data, $meta );
				return str_replace( ' ', '%20', $this->build_imgopt_url( $url, $args ) ) . ' ' . $candidate[2] . 'w';
			},
			$item_data['img_attributes']['srcset']
		);
		return $item_data;
	}

	/**
	 * Reorganizes the filter settings for Modula Link
	 *
	 * @since 1.0.16
	 *
	 * @param array  $image_config - Image config array
	 * @param array  $image - Image data
	 * @param int    $image_id - Image id
	 * @param string $gallery_settings - the settings of the image hosting gallery
	 * @return array
	 */
	public function generate_modula_link_image_url( $image_config, $image, $image_id, $gallery_settings ) {

		return $this->generate_lightbox_config_image_url( $image_config, $image, $gallery_settings );
	}

	/**
	 * Image compression( CDN) for Album galleries and Modula Link lightboxes.
	 *
	 * @since 1.0.16
	 *
	 * @param array  $image_config - Image config array
	 * @param array  $image - Image data
	 * @param string $gallery_settings - the settings of the image hosting gallery
	 * @return array
	 */

	public function generate_lightbox_config_image_url( $image_config, $image, $gallery_settings ) {
		// Ensure that the settings are set.
		$gallery_settings = wp_parse_args( $gallery_settings, \Modula_CPT_Fields_Helper::get_defaults() );
		$compressions     = $this->compressions( $gallery_settings );
		if ( null === $compressions ) {
			return $image_config;
		}

		list( $image_config['src'], $image_config['opts']['thumb'] ) = $this->optimized_lightbox_files( $image_config['src'], $image_config['opts']['thumb'], $compressions, $image_config, $image, $gallery_settings );
		return $image_config;
	}

	/**
	 * A Beta album's lightbox row (Album visitor frontend), as the classic
	 * album's (`generate_lightbox_config_image_url()`): the image at the
	 * member gallery's lightbox compression, its thumbnail at its thumbnail
	 * compression. A video row's poster is the image here.
	 *
	 * @param array<string, mixed> $item             Lightbox row.
	 * @param array<string, mixed> $image            Gallery row.
	 * @param array<string, mixed> $gallery_settings The member gallery's settings.
	 * @return array<string, mixed> The row, with its files optimized.
	 */
	public function album_visitor_lightbox_item( $item, $image, $gallery_settings ) {
		$gallery_settings = wp_parse_args( $gallery_settings, \Modula_CPT_Fields_Helper::get_defaults() );
		$compressions     = $this->compressions( $gallery_settings );
		if ( null === $compressions ) {
			return $item;
		}

		list( $item['url'], $item['thumbnail'] ) = $this->optimized_lightbox_files( $item['url'], $item['thumbnail'], $compressions, $item, $image, $gallery_settings );
		return $item;
	}

	/**
	 * A Beta album member's cover (Album visitor frontend), as the classic
	 * album's (`generate_optimized_image_links()`): each file from this site,
	 * the cover at the album's image size and the member gallery's thumbnail
	 * compression, its full size at its lightbox compression.
	 *
	 * @param array{id: int, src: string, width: int, height: int, full: string} $cover            The cover.
	 * @param array<string, mixed>                                               $gallery_settings The member gallery's settings.
	 * @return array{id: int, src: string, width: int, height: int, full: string} The cover, its files optimized.
	 */
	public function album_visitor_cover( $cover, $gallery_settings ) {
		$gallery_settings = wp_parse_args( $gallery_settings, \Modula_CPT_Fields_Helper::get_defaults() );
		$compressions     = $this->compressions( $gallery_settings );
		if ( null === $compressions ) {
			return $cover;
		}

		$image = array( 'id' => $cover['id'] );
		if ( 'disabled' !== $compressions['thumbnail'] && 0 === strpos( $cover['src'], $this->site_host ) ) {
			$sp_args      = apply_filters(
				'modula_gallery_optimized_img_args',
				array(
					'w' => $cover['width'],
					'h' => $cover['height'],
					'q' => $compressions['thumbnail'],
				),
				$cover,
				$image,
				$gallery_settings
			);
			$cover['src'] = $this->build_imgopt_url( $cover['src'], $sp_args );
		}
		if ( 'disabled' !== $compressions['lightbox'] && 0 === strpos( $cover['full'], $this->site_host ) ) {
			$sp_args       = apply_filters(
				'modula_lightbox_optimized_img_args',
				array(
					'w' => 0,
					'h' => 0,
					'q' => $compressions['lightbox'],
				),
				$cover,
				$image,
				$gallery_settings
			);
			$cover['full'] = $this->build_imgopt_url( $cover['full'], $sp_args );
		}

		return $cover;
	}

	/**
	 * The compressions a gallery's images get: its own, or the site's for
	 * "default". One rule for its tiles, its lightbox and an album's.
	 *
	 * @param array<string, mixed> $gallery_settings Gallery settings, with their defaults.
	 * @return array{lightbox: string, thumbnail: string}|null Null while Speedup optimizes nothing for the gallery; an empty switch counts as off.
	 */
	private function compressions( array $gallery_settings ) {
		if ( ! Licensing::get_instance()->has_plan() ) {
			return null;
		}
		if ( '' === $gallery_settings['enable_optimization'] || 'disabled' === $gallery_settings['enable_optimization'] ) {
			return null;
		}
		if ( 'default' === $gallery_settings['enable_optimization'] && 'disabled' === $this->settings['enable_optimization'] ) {
			return null;
		}

		return array(
			'lightbox'  => ( 'default' === $gallery_settings['lightbox_optimization'] ) ? $this->settings['lightbox_optimization'] : $gallery_settings['lightbox_optimization'],
			'thumbnail' => ( 'default' === $gallery_settings['thumbnail_optimization'] ) ? $this->settings['thumbnail_optimization'] : $gallery_settings['thumbnail_optimization'],
		);
	}

	/**
	 * A lightbox image and its thumbnail, each at its compression. A file
	 * that is missing ('') stays missing.
	 *
	 * @param string                                    $src              Lightbox image.
	 * @param string                                    $thumb            Its thumbnail.
	 * @param array{lightbox: string, thumbnail: string} $compressions     The gallery's compressions (`compressions()`).
	 * @param array<string, mixed>                      $image_config     The lightbox slide, for the args filters.
	 * @param array<string, mixed>                      $image            Gallery row.
	 * @param array<string, mixed>                      $gallery_settings Gallery settings.
	 * @return array{0: string, 1: string} The image and its thumbnail.
	 */
	private function optimized_lightbox_files( $src, $thumb, array $compressions, $image_config, $image, $gallery_settings ) {
		if ( 'disabled' !== $compressions['lightbox'] && '' !== $src ) {
			// Used to generate lightbox image url for Modula Albums & Modula Link lightboxes
			$sp_args = apply_filters(
				'modula_lightbox_link_optimized_img_args',
				array(
					'w' => 0,
					'h' => 0,
					'q' => $compressions['lightbox'],
				),
				$image_config,
				$image,
				$gallery_settings
			);
			$src     = $this->build_imgopt_url( $src, $sp_args );
		}

		if ( 'disabled' !== $compressions['thumbnail'] && '' !== $thumb ) {
			// Used to generate thumbnail image navigation url for Modula Albums & Modula Link lightboxes
			$sp_args_tmb = apply_filters(
				'modula_gallery_link_optimized_img_args',
				array(
					'w' => 0,
					'h' => 0,
					'q' => $compressions['thumbnail'],
				),
				$image_config,
				$image,
				$gallery_settings
			);
			$thumb       = $this->build_imgopt_url( $thumb, $sp_args_tmb );
		}

		return array( $src, $thumb );
	}

	public function after_gallery( $settings ) {
		if ( ! Licensing::get_instance()->has_plan() ) {
			return;
		}

		if ( 'disabled' === $settings['enable_optimization'] ) {
			return;
		}

		if ( 'default' === $settings['enable_optimization'] && 'disabled' === $this->settings['enable_optimization'] ) {
			return;
		}

		add_filter( 'modula_resize_images', '__return_true', 10 );
	}

	private function build_imgopt_url( $orig_url, $args ) {
		// sanitize width and height.
		if ( ! isset( $args['w'] ) || strpos( $args['w'], '%' ) !== false ) {
			$args['w'] = 0;
		}
		if ( ! isset( $args['h'] ) || strpos( $args['h'], '%' ) !== false ) {
			$args['h'] = 0;
		}
		if ( ! isset( $args['q'] ) ) {
			$args['q'] = 'lossless';
		}

		$width  = (int) $args['w'];
		$height = (int) $args['h'];

		$separator = apply_filters( 'modula_imgopt_separator', ',', $orig_url, $args );

		$imgopt_base_url = $this->get_imgopt_base_url( $args['q'] );
		$imgopt_size     = '';

		if ( $width && 0 !== $width ) {
			$imgopt_size = $separator . 'w_' . $width;
		}
		if ( $height && 0 !== $height ) {
			$imgopt_size .= $separator . 'h_' . $height;
		}

		$url = $imgopt_base_url . $imgopt_size . '/' . $orig_url;

		return $url;
	}

	private function get_imgopt_base_url( $compression ) {

		$imgopt_host = $this->imgopt_host;

		$separator = apply_filters( 'modula_imgopt_separator', ',', null, array( 'q' => $compression ) );

		$imgopt_base_url = $imgopt_host . 'spai/q_' . $compression . $separator . 'ret_img';

		return $imgopt_base_url;
	}

	public function speedup_defaults( $defaults ) {

		$defaults['enable_optimization']    = 'default';
		$defaults['thumbnail_optimization'] = 'default';
		$defaults['lightbox_optimization']  = 'default';

		return $defaults;
	}

	/**
	 * Speedup uninstall
	 *
	 * @param $db_options
	 *
	 * @return mixed
	 *
	 * @since 1.0.3
	 */
	public function speedup_uninstall( $db_options ) {

		$db_options[] = 'modula_speedup';

		return $db_options;
	}

	/**
	 * Add debug information
	 *
	 * @param $info
	 *
	 * @return mixed
	 * @since 1.0.7
	 */
	public function debug_information( $info ) {

		$speedup_otps = get_option( 'modula_speedup' );

		$info['modula_speedup_version'] = array(
			'label' => __( 'Modula Speedup Version', 'modula-pro' ),
			'value' => esc_html( \MODULA_PRO_VERSION ),
			'debug' => esc_html( 'Modula Speedup version ' . \MODULA_PRO_VERSION ),
		);

		$info['compression'] = array(
			'label' => __( 'Modula compression', 'modula-pro' ),
			'value' => ( isset( $speedup_otps['enable_optimization'] ) && 'enabled' === $speedup_otps['enable_optimization'] ) ? esc_html__( 'Enabled', 'modula-pro' ) : esc_html__( 'Disabled', 'modula-pro' ),
			'debug' => ( isset( $speedup_otps['enable_optimization'] ) && 'enabled' === $speedup_otps['enable_optimization'] ) ? 'Enabled compression' : 'Disabled compression',
		);

		$info['thumb_compression'] = array(
			'label' => __( 'Modula thumbnail compression', 'modula-pro' ),
			'value' => ( isset( $speedup_otps['thumbnail_optimization'] ) ) ? esc_html( $speedup_otps['thumbnail_optimization'] ) : esc_html__( 'Disabled', 'modula-pro' ),
			'debug' => ( isset( $speedup_otps['thumbnail_optimization'] ) ) ? esc_html( $speedup_otps['thumbnail_optimization'] ) : 'Disabled thumbnail compression',
		);

		$info['lightbox_compression'] = array(
			'label' => __( 'Modula lightbox compression', 'modula-pro' ),
			'value' => ( isset( $speedup_otps['lightbox_optimization'] ) ) ? esc_html( $speedup_otps['lightbox_optimization'] ) : esc_html__( 'Disabled', 'modula-pro' ),
			'debug' => ( isset( $speedup_otps['lightbox_optimization'] ) ) ? esc_html( $speedup_otps['lightbox_optimization'] ) : 'Disabled lightbox compression',
		);

		return $info;
	}

	/**
	 * Add CDN to the srcset of the images
	 *
	 * @param $srcset
	 * @param $data
	 * @param $image_meta
	 *
	 * @return array|string|string[]
	 *
	 * @since 1.0.10
	 */
	public function modula_speedup_srcset( $srcset, $data, $image_meta ) {
		//phpcs:disable
		if ( ! isset( $data->compression ) || ! $data->compression ) {
			return $srcset;
		}

		// If the displayed image was cropped to a different ratio, use the cropped file for srcset.
		if ( isset( $image_meta['sizes']['custom'] ) ) {
			$orig_ratio   = round( (int) $image_meta['width'] / max( 1, (int) $image_meta['height'] ), 2 );
			$custom_ratio = round( (int) $image_meta['sizes']['custom']['width'] / max( 1, (int) $image_meta['sizes']['custom']['height'] ), 2 );
			if ( $orig_ratio !== $custom_ratio ) {
				$image_meta['file']   = dirname( $image_meta['file'] ) . '/' . $image_meta['sizes']['custom']['file'];
				$image_meta['width']  = (int) $image_meta['sizes']['custom']['width'];
				$image_meta['height'] = (int) $image_meta['sizes']['custom']['height'];
			}
		}

		$srcset      = '';
		$src_matched = false;
		$upload_dir  = wp_get_upload_dir();
		$image_src   = $upload_dir['baseurl'] . $image_meta['file'];

		$dirname = _wp_get_attachment_relative_path( $image_meta['file'] );
		if ( $dirname ) {
			$dirname = trailingslashit( $dirname );
		}

		$upload_dir    = wp_get_upload_dir();
		$image_baseurl = trailingslashit( $upload_dir['baseurl'] ) . $dirname;

		/*
		 * If currently on HTTPS, prefer HTTPS URLs when we know they're supported by the domain
		 * (which is to say, when they share the domain name of the current request).
		 */
		if ( is_ssl() && 'https' !== substr( $image_baseurl, 0, 5 ) && parse_url( $image_baseurl, PHP_URL_HOST ) === $_SERVER['HTTP_HOST'] ) {
			$image_baseurl = set_url_scheme( $image_baseurl, 'https' );
		}

		$image_width  = $image_meta['width'];
		$image_height = $image_meta['height'];
		$image_edited = preg_match( '/-e[0-9]{13}/', wp_basename( $image_src ), $image_edit_hash );
		$sources      = array();
		// As said in WP, the 'src' image has to be the first in the 'srcset', because of a bug in iOS8. See #35030.
		$sizes['full'] = array(
			'file'   => basename( $image_meta['file'] ),
			'width'  => $image_width,
			'height' => $image_height,
		);

		$sizes = array_merge( $sizes, $image_meta['sizes'] );

		foreach ( $sizes as $size => $values ) {
			$is_src = false;

			// Check if image meta isn't corrupted.
			if ( ! is_array( $values ) ) {
				continue;
			}

			// If the file name is part of the `src`, we've confirmed a match.
			if ( ! $src_matched && false !== strpos( $image_src, $dirname . $values['file'] ) ) {
				$src_matched = true;
				$is_src      = true;
			}

			// Filter out images that are from previous edits.
			if ( $image_edited && ! strpos( $values['file'], $image_edit_hash[0] ) ) {
				continue;
			}

			// If the image dimensions are within 1px of the expected size, use it.
			if ( wp_image_matches_ratio( $image_width, $image_height, $values['width'], $values['height'] ) || 'custom' === $size ) {

				// Used to generate the srcset of the iamge.
				$sp_args = apply_filters(
					'modula_gallery_srcset_optimized_img_args',
					array(
						'w' => $values['width'],
						'h' => $values['height'],
						'q' => $data->compression,
					),
					$srcset,
					$data,
					$image_meta
				);
				// Add the URL, descriptor, and value to the sources array to be returned.
				$image_url = apply_filters( 'modula_gallery_srcset_image_url', $image_baseurl . $values['file'], $data, $image_meta );
				$source    = array(
					'url'        => $this->build_imgopt_url( $image_url, $sp_args ),
					'descriptor' => 'w',
					'value'      => $values['width'],
				);

				// The 'src' image has to be the first in the 'srcset', because of a bug in iOS8. See #35030.
				if ( $is_src ) {
					$sources = array( $values['width'] => $source ) + $sources;
				} else {
					$sources[ $values['width'] ] = $source;
				}
			}
		}

		foreach ( $sources as $key => $source ) {
			$srcset .= str_replace( ' ', '%20', $source['url'] ) . ' ' . $source['value'] . $source['descriptor'] . ', ';
		}

		return rtrim( $srcset, ', ' );
		//phpcs:enable
	}

	/**
	 * Unset badge
	 *
	 * @param [type] $tabs
	 * @return void
	 * @since 1.0.12
	 */
	public function modula_speedup_tab( $tabs ) {

		unset( $tabs['speedup']['badge'] );

		return $tabs;
	}

	public function wp_optimize_compatibility( $separator ) {
		if ( class_exists( 'WP_Optimize' ) ) {
			return '&';
		}
		return $separator;
	}
}
