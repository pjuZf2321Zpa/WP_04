jQuery( document ).on(
	'modula_fancybox_lightbox_after_show',
	function ( e, obj, instance, current ) {
		let download_image_src = '';
		// Check if the instance has the $thumb property and if it's not null
		if (
			'undefined' !== typeof instance.$thumb &&
			null !== instance.$thumb
		) {
			download_image_src = jQuery( instance.$thumb[ 0 ] )
				.find( 'img' )
				.data( 'download' );
		}

		if ( '' !== download_image_src ) {
			instance.$content
				.parents( '.modula-fancybox-container' )
				.find( '[data-fancybox-download]' )
				.attr( 'href', download_image_src );
		}
	}
);
