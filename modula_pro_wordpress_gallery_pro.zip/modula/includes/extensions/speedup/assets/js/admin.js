jQuery( document ).ready( function () {
	jQuery( '#modula-speedup .speedup-select' ).change( function () {
		const value = jQuery( this ).val();

		if ( 'default' == value ) {
			jQuery( this ).parent().find( 'span' ).show();
		} else {
			jQuery( this ).parent().find( 'span' ).hide();
		}
	} );
} );
