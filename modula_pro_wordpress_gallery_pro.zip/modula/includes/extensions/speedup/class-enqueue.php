<?php
namespace Modula_Pro\Extensions\Speedup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	/**
	 * The URL of the extension.
	 *
	 * @var string
	 */
	private $extension_url = 'includes/extensions/speedup';

	/**
	 * Primary class constructor.
	 */
	public function __construct() {
		add_action(
			'wp_enqueue_scripts',
			array( $this, 'extra_scripts' )
		);

		add_filter(
			'modula_necessary_scripts',
			array( $this, 'modula_speedup_add_script' ),
			99,
			2
		);

		add_action(
			'modula_scripts_after_wp_modula',
			array( $this, 'admin_scripts' ),
			15
		);
		add_action(
			'modula_defaults_scripts_after_wp_modula',
			array( $this, 'admin_scripts' ),
			15
		);
	}
	/**
	 * Enqueue needed scripts
	 *
	 * @since 1.0.14
	 */
	public function extra_scripts() {
		wp_register_script(
			'modula-fancybox-speedup',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/front.js',
			array( 'jquery', 'modula-pro' ),
			\MODULA_PRO_VERSION,
			true
		);
	}

	/**
	 * Enqueue slider scripts
	 *
	 * @param $scripts
	 * @param $settings
	 *
	 * @return array
	 */
	public function modula_speedup_add_script( $scripts, $settings ) {
		if ( 'enabled' === $settings['enable_optimization'] ) {
			$scripts[] = 'modula-fancybox-speedup';
		}
		return $scripts;
	}

	/**
	 * Enqueue admin scripts
	 */
	public function admin_scripts() {
		wp_enqueue_style(
			'modula-speedup',
			\MODULA_PRO_URL . $this->extension_url . '/assets/css/admin.css',
			array(),
			\MODULA_PRO_VERSION
		);
		wp_enqueue_script(
			'modula-speedup',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/admin.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			\MODULA_PRO_VERSION,
			true
		);
	}
}
