<?php
/**
 * REST API for watermark apply / remove (v2 settings editor).
 *
 * @package Modula_Pro\Extensions\Watermark
 */

namespace Modula_Pro\Extensions\Watermark\Rest_API;

use Modula_Pro\Extensions\Watermark\Watermark;

defined( 'ABSPATH' ) || exit;

/**
 * Class WP_Rest_Modula_Watermark_Controller
 */
class WP_Rest_Modula_Watermark_Controller {

	/**
	 * @var string
	 */
	public $namespace = 'modula-watermark/v1';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/galleries/(?P<gallery_id>[\d]+)/apply',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'apply_watermark' ),
					'permission_callback' => array( $this, 'check_edit_gallery' ),
					'args'                => array(
						'gallery_id' => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
						'imageId'    => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/galleries/(?P<gallery_id>[\d]+)/remove',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'remove_watermark' ),
					'permission_callback' => array( $this, 'check_edit_gallery' ),
					'args'                => array(
						'gallery_id' => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
						'imageId'    => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public function check_edit_gallery( $request ) {
		$gallery_id = absint( $request['gallery_id'] );
		if ( $gallery_id <= 0 || 'modula-gallery' !== get_post_type( $gallery_id ) ) {
			return new \WP_Error(
				'modula_watermark_invalid_gallery',
				esc_html__( 'Invalid gallery.', 'modula-pro' ),
				array( 'status' => 404 )
			);
		}

		if ( ! current_user_can( 'edit_post', $gallery_id ) ) {
			return new \WP_Error(
				'modula_watermark_forbidden',
				esc_html__( 'Sorry, you are not allowed to edit this gallery.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Apply watermark to a single gallery image.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function apply_watermark( $request ) {
		$gallery_id = absint( $request['gallery_id'] );
		$image_id   = absint( $request['imageId'] );

		$service = Watermark::get_instance();
		$result  = $service->apply_watermark_to_image( $gallery_id, $image_id );

		// The editor names the settings it burned: Override off burns the global image watermark.
		return $this->format_result( $result, array( 'settingsSource' => $service->get_watermark_settings_source( $gallery_id ) ) );
	}

	/**
	 * Remove watermark from a single gallery image.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function remove_watermark( $request ) {
		$gallery_id = absint( $request['gallery_id'] );
		$image_id   = absint( $request['imageId'] );

		$result = Watermark::get_instance()->remove_watermark_from_image( $gallery_id, $image_id );

		return $this->format_result( $result );
	}

	/**
	 * @param true|\WP_Error       $result  Result from watermark service.
	 * @param array<string, mixed> $details Extra fields for a success response.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private function format_result( $result, array $details = array() ) {
		if ( true === $result ) {
			return new \WP_REST_Response(
				array_merge( array( 'success' => true ), $details ),
				200
			);
		}

		if ( ! is_wp_error( $result ) ) {
			return new \WP_Error(
				'modula_watermark_unknown',
				esc_html__( 'Something was wrong. Please try again', 'modula-pro' ),
				array( 'status' => 500 )
			);
		}

		$data   = $result->get_error_data();
		$skipped = is_array( $data ) && ! empty( $data['skipped'] );

		if ( $skipped ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'skipped' => true,
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				200
			);
		}

		$status = 400;
		if ( is_array( $data ) && isset( $data['status'] ) ) {
			$status = absint( $data['status'] );
		}

		return new \WP_Error(
			$result->get_error_code(),
			$result->get_error_message(),
			array( 'status' => $status )
		);
	}
}
