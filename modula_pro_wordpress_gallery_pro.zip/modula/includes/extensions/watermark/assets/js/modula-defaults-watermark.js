( function ( $ ) {
	'use strict';

	const modulaDefaultsWatermarkConditions = Backbone.Model.extend( {
		initialize( args ) {
			const rows = jQuery(
					'.modula-settings-container #modula-watermark tr[data-container]'
				),
				modulaWatermark = jQuery(
					'[data-container="watermark_apply_to_existing_images"] .modula-watermark-container'
				);

			this.set( 'rows', rows );
			this.set( 'modula-watermark', modulaWatermark );
			this.set( 'needSave', false );

			this.initEvents();
			this.initValues();
		},

		initEvents() {
			const modulaWatermarkContainer = this.get( 'modula-watermark' ),
				modulaWatermark = this;

			this.listenTo(
				wp.ModulaDefaults.Settings,
				'change:enable_watermark',
				this.enableWatermark
			);
			this.listenTo(
				wp.ModulaDefaults.Settings,
				'change:custom_settings_watermark',
				this.showCustomSettings
			);
			this.listenTo(
				wp.ModulaDefaults.Settings,
				'change',
				this.showSaveNotice
			);

			modulaWatermarkContainer.on(
				'click',
				'.button',
				function ( event ) {
					const button = $( this );

					event.preventDefault();
					if ( modulaWatermark.get( 'needSave' ) ) {
						const saveNotice = modulaWatermarkContainer
							.find( '.modula-watermark-error' )
							.data( 'msg' );

						modulaWatermarkContainer
							.find( '.button' )
							.addClass( 'disabled' );
						modulaWatermarkContainer
							.find( '.button' )
							.attr( 'disabled', 'disabled' );

						modulaWatermarkContainer
							.find( '.modula-watermark-error' )
							.html( saveNotice );

						return;
					}

					button.addClass( 'updating-message' );
					const post_id = $( 'form #post_ID' ).val(),
						data = {
							action: 'modula_apply_watermark',
							gallery: post_id,
						};

					$.post( ajaxurl, data, function ( response ) {
						modulaWatermarkContainer
							.find( '.modula-watermark-error' )
							.html( response );
						button.removeClass( 'updating-message' );
					} );
				}
			);
		},

		showSaveNotice() {
			const modulaWatermark = this.get( 'modula-watermark' ),
				saveNotice = modulaWatermark
					.find( '.modula-watermark-error' )
					.data( 'msg' );
			this.set( 'needSave', true );

			modulaWatermark.find( '.button' ).addClass( 'disabled' );
			modulaWatermark.find( '.button' ).attr( 'disabled', 'disabled' );

			modulaWatermark
				.find( '.modula-watermark-error' )
				.html( saveNotice );
		},

		initValues() {
			this.enableWatermark(
				false,
				wp.ModulaDefaults.Settings.get( 'enable_watermark' )
			);
			this.showCustomSettings(
				false,
				wp.ModulaDefaults.Settings.get( 'custom_settings_watermark' )
			);
		},

		enableWatermark( settings, value ) {
			const rows = this.get( 'rows' );

			if ( '1' == value ) {
				rows.filter(
					'[data-container="custom_settings_watermark"], [data-container="watermark_apply_to_existing_images"]'
				).show();
				if (
					'1' ==
					wp.ModulaDefaults.Settings.get(
						'custom_settings_watermark'
					)
				) {
					rows.filter(
						'[data-container="watermark_image"], [data-container="watermark_position"], [data-container="watermark_margin"], [data-container="watermark_image_dimension_width"], [data-container="watermark_image_dimension_height"]'
					).show();
				} else {
					rows.filter(
						'[data-container="watermark_image"], [data-container="watermark_position"], [data-container="watermark_margin"], [data-container="watermark_image_dimension_width"], [data-container="watermark_image_dimension_height"]'
					).hide();
				}
			} else {
				rows.filter(
					'[data-container="custom_settings_watermark"], [data-container="watermark_apply_to_existing_images"]'
				).hide();
				rows.filter(
					'[data-container="watermark_image"], [data-container="watermark_position"], [data-container="watermark_margin"], [data-container="watermark_image_dimension_width"], [data-container="watermark_image_dimension_height"]'
				).hide();
			}
		},

		showCustomSettings( settings, value ) {
			const rows = this.get( 'rows' );

			if ( '1' == value ) {
				if (
					'1' == wp.ModulaDefaults.Settings.get( 'enable_watermark' )
				) {
					rows.filter(
						'[data-container="watermark_image"], [data-container="watermark_position"], [data-container="watermark_margin"], [data-container="watermark_image_dimension_width"], [data-container="watermark_image_dimension_height"]'
					).show();
				} else {
					rows.filter(
						'[data-container="watermark_image"], [data-container="watermark_position"], [data-container="watermark_margin"], [data-container="watermark_image_dimension_width"], [data-container="watermark_image_dimension_height"]'
					).hide();
				}
			} else {
				rows.filter(
					'[data-container="watermark_image"], [data-container="watermark_position"], [data-container="watermark_margin"], [data-container="watermark_image_dimension_width"], [data-container="watermark_image_dimension_height"]'
				).hide();
			}
		},
	} );

	$( document ).ready( function () {
		// Hide Settings
		if ( undefined === wp.Modula.watermark ) {
			wp.Modula.watermark = {};
		}
		wp.Modula.watermark.DefaultsConditions =
			new modulaDefaultsWatermarkConditions();

		const modulaWatermarkFrame = new wp.media( {
			title: 'Select a image to upload',
			button: {
				text: 'Use this image',
			},
			multiple: false, // Set to true to allow multiple files to be selected
		} );

		modulaWatermarkFrame.on( 'select', function () {
			// We set multiple to false so only get one image from the uploader
			const attachment = modulaWatermarkFrame
				.state()
				.get( 'selection' )
				.first()
				.toJSON();

			const att_id = attachment.id,
				att_src = attachment.url,
				height = parseInt( attachment.height ),
				width = parseInt( attachment.width ),
				image_preview = $( '.modula_watermark_image_preview' );

			$( '#watermark_image' ).val( att_id );
			image_preview.html( '<img src="' + att_src + '">' );

			if ( width >= height ) {
				image_preview.removeClass(
					'modula_watermark_preview_portrait'
				);
				image_preview.addClass( 'modula_watermark_preview_landscape' );
			} else {
				image_preview.removeClass(
					'modula_watermark_preview_landscape'
				);
				image_preview.addClass( 'modula_watermark_preview_portrait' );
			}

			$( '#upload_watermark_file' ).hide();
			$( '#replace_watermark_file' ).show();
			$( '#delete_watermark_file' ).show();
		} );

		$( '#upload_watermark_file' ).click( function ( event ) {
			event.preventDefault();
			modulaWatermarkFrame.open();
		} );

		$( '#replace_watermark_file' ).click( function ( event ) {
			event.preventDefault();
			modulaWatermarkFrame.open();
		} );

		$( '#delete_watermark_file' ).click( function ( event ) {
			event.preventDefault();

			$( '#watermark_image' ).val( 0 );
			$( '.modula_watermark_image_preview' ).html( '' );

			$( '#upload_watermark_file' ).show();
			$( '#replace_watermark_file' ).hide();
			$( '#delete_watermark_file' ).hide();
		} );
	} );
} )( jQuery );
