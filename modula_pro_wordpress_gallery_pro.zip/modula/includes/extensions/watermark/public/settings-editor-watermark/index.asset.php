<?php return array('dependencies' => array('wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '2b9f628b983302861097');
