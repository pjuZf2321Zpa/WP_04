<?php
namespace Modula_Pro\Extensions\Watermark;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/watermark';
	public function __construct() {
		// Filter Modula Watermark Scripts & Styles
		add_filter( 'admin_enqueue_scripts', array( $this, 'modula_watermark_scripts' ), 25 );

		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'watermark_defaults_script' ) );
	}

	/**
	 * @param $scripts
	 * @param $settings
	 *
	 * @return array
	 *
	 * Enqueue watermark script
	 */
	public function modula_watermark_scripts( $hook ) {

		if ( 'modula-gallery_page_modula' === $hook ) {
			if ( isset( $_GET['modula-tab'] ) && 'watermark' === $_GET['modula-tab'] ) {
				wp_enqueue_media();
				wp_enqueue_style( 'jquery-ui', \MODULA_URL . 'assets/css/admin/jquery-ui.min.css', null, \MODULA_PRO_VERSION );

				wp_enqueue_script( 'modula-watermark-settings', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-watermark-settings.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-slider' ), \MODULA_PRO_VERSION, true );
			}
		}

		$screen                 = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$is_modula_gallery_edit = ( 'post-new.php' === $hook || 'post.php' === $hook ) && $screen && 'modula-gallery' === $screen->post_type;
		$is_gallery_takeover    = class_exists( '\Modula\V2\Admin\Gallery_Takeover_Admin' ) && \Modula\V2\Admin\Gallery_Takeover_Admin::should_use_takeover();
		// Classic metabox stack registers modula-gallery; v2 takeover does not — avoid invalid deps and legacy JS that expects wp.Modula.
		$use_modula_gallery_dep = $is_modula_gallery_edit && ! $is_gallery_takeover;
		$watermark_deps         = $use_modula_gallery_dep ? array( 'jquery', 'modula-gallery' ) : array( 'jquery' );

		// Register Watermark script (only depend on modula-gallery when on classic gallery edit screen).
		wp_register_script( 'modula-watermark-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-watermark.js', $watermark_deps, \MODULA_PRO_VERSION, true );
		// Register Watermark style
		wp_register_style( 'modula-watermark-style', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-watermark.css', array(), \MODULA_PRO_VERSION );

		if ( $is_modula_gallery_edit && ! $is_gallery_takeover ) {
			wp_enqueue_style( 'modula-watermark-style' );
			wp_enqueue_script( 'modula-watermark-script' );

			$modula_wm = array(
				// translators: %1$s is the image number, %2$s is the total number of images
				'upd_images'     => esc_html__( 'Watermarking image %1$s1 of %2$s2...', 'modula-pro' ),
				'upd_done'       => esc_html__( 'Finished watermarking images.', 'modula-pro' ),
				'err_no_images'  => esc_html__( 'Add images and save the gallery before trying to watermark.', 'modula-pro' ),
				// translators: %1$s is the image number, %2$s is the total number of images
				'restore_images' => esc_html__( 'Restoring image %1$s1 of %2$s2...', 'modula-pro' ),
				'restore_done'   => esc_html__( 'Finished restoring images.', 'modula-pro' ),

			);
			$modula_wm = apply_filters( 'modula_watermarking_response_messages', $modula_wm );
			wp_localize_script( 'modula-watermark-script', 'modulaWmMessages', $modula_wm );
			wp_add_inline_script( 'modula-watermark-script', 'const watermarkNonce = "' . wp_create_nonce( 'modula_watermark_images' ) . '"', 'before' );
		}
	}

	/**
	 * Enqueue Modula Defaults neede scripts
	 *
	 * @since 1.0.2
	 */
	public function watermark_defaults_script() {
		wp_enqueue_script( 'modula-watermark-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-watermark.js', array(), \MODULA_PRO_VERSION, true );
	}
}
