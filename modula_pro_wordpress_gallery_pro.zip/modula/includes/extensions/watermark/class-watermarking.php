<?php
namespace Modula_Pro\Extensions\Watermark;

use Modula\V2\Settings\Watermark_Scale;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Watermarking class.
 *
 * @since 1.0.0
 *
 * @package Modula_Pro\Extensions\Watermark
 */
class Watermarking {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Path to the file.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $file = __FILE__;

	/**
	 * Holds the base class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public $base;

	/**
	 * Holds the watermark sufix added ad the end of file.
	 *
	 * @since 1.0.9
	 *
	 * @var object
	 */
	public $sufix = '_w';

	/**
	 * Overlay a watermark, if specified, to the uploaded image
	 *
	 * @param string      $attachment_path Path of the image.
	 * @param string|null $watermark_path  Path of the watermark image (null for text).
	 * @param int         $gallery_id      Gallery ID.
	 * @param array       $settings        Watermark settings.
	 * @param array       $img_obj         Image context.
	 *
	 * @throws \ImagickException
	 * @since 1.0.0
	 */
	public function add_watermark( $attachment_path, $watermark_path, $gallery_id, $settings, $img_obj ) {
		$type = $this->resolve_watermark_type( $settings );

		if ( 'none' === $type ) {
			return false;
		}

		if ( $this->has_imagick_extension() ) {
			if ( 'text' === $type ) {
				return $this->watermark_text_imagick( $attachment_path, $gallery_id, $settings );
			}
			return $this->watermark_imagick( $attachment_path, $watermark_path, $gallery_id, $settings, $img_obj );
		}

		if ( $this->has_gd_extension() ) {
			if ( 'text' === $type ) {
				return $this->watermark_text_gd( $attachment_path, $gallery_id, $settings );
			}
			return $this->watermark_gd( $attachment_path, $watermark_path, $gallery_id, $settings, $img_obj );
		}

		return false;
	}

	/**
	 * Resolve watermark type from settings (legacy-aware).
	 *
	 * @param array $settings Settings.
	 * @return string none|text|image
	 */
	public function resolve_watermark_type( $settings ) {
		$type = isset( $settings['watermark_type'] ) ? sanitize_key( (string) $settings['watermark_type'] ) : '';
		if ( in_array( $type, array( 'none', 'text', 'image' ), true ) ) {
			return $type;
		}
		$image_id = isset( $settings['watermark_image'] ) ? absint( $settings['watermark_image'] ) : 0;
		return $image_id > 0 ? 'image' : 'none';
	}

	/**
	 * Flag to determine if the GD library has been compiled.
	 *
	 * @return bool
	 * @since 1.0.0
	 */
	public function has_gd_extension() {
		return extension_loaded( 'gd' ) && function_exists( 'gd_info' );
	}

	/**
	 * Flag to determine if the Imagick library has been compiled.
	 *
	 * @return bool
	 * @since 1.0.0
	 */
	public function has_imagick_extension() {
		return extension_loaded( 'imagick' );
	}

	/**
	 * Whether this server can draw a text watermark at its size.
	 *
	 * GD needs FreeType and a TrueType font; its built-in bitmap font has one
	 * fixed ~9px size, so it is never used for text.
	 *
	 * @return bool
	 */
	public function can_render_text() {
		if ( $this->has_imagick_extension() ) {
			return true;
		}
		return '' !== $this->resolve_gd_text_font_path();
	}

	/**
	 * TrueType font GD draws text with, or '' when GD cannot draw TrueType text.
	 *
	 * @return string
	 */
	private function resolve_gd_text_font_path() {
		if ( ! $this->has_gd_extension() || ! function_exists( 'imagettfbbox' ) || ! function_exists( 'imagettftext' ) ) {
			return '';
		}
		return $this->resolve_system_font_path();
	}

	/**
	 * Text size and margin in px for one image.
	 *
	 * A gallery's settings carry shares of the image width (Lite's
	 * Watermark_Scale). The global Watermark settings are image-only and keep
	 * their px margin, so a margin without a share is used as px.
	 *
	 * @param array $settings    Burn settings.
	 * @param int   $image_width Width of the image being watermarked.
	 * @return array{text_size:int, margin:int}
	 */
	public function resolve_mark_px( $settings, $image_width ) {
		$text_share = isset( $settings['watermark_text_size_share'] ) ? (float) $settings['watermark_text_size_share'] : Watermark_Scale::default_share( 'watermark_text_size_share' );

		return array(
			'text_size' => max( 1, Watermark_Scale::px_for_width( $text_share, $image_width ) ),
			'margin'    => $this->resolve_margin_px( $settings, $image_width ),
		);
	}

	/**
	 * @param array $settings    Burn settings.
	 * @param int   $image_width Image width.
	 * @return int
	 */
	private function resolve_margin_px( $settings, $image_width ) {
		if ( isset( $settings['watermark_margin_share'] ) ) {
			return Watermark_Scale::px_for_width( (float) $settings['watermark_margin_share'], $image_width );
		}
		return isset( $settings['watermark_margin'] ) ? (int) $settings['watermark_margin'] : 10;
	}

	/**
	 * Opacity 0–100 from settings (default 100 for legacy image burns).
	 *
	 * @param array $settings Settings.
	 * @return int
	 */
	private function resolve_opacity( $settings ) {
		if ( ! isset( $settings['watermark_opacity'] ) || '' === $settings['watermark_opacity'] ) {
			return 100;
		}
		$opacity = (int) $settings['watermark_opacity'];
		return max( 0, min( 100, $opacity ) );
	}

	/**
	 * Find a readable system TrueType font (no bundled fonts).
	 *
	 * @return string Absolute path or empty string.
	 */
	private function resolve_system_font_path() {
		$candidates = array(
			// macOS
			'/System/Library/Fonts/Supplemental/Arial.ttf',
			'/Library/Fonts/Arial.ttf',
			'/System/Library/Fonts/Helvetica.ttc',
			'/System/Library/Fonts/SFNS.ttf',
			// Linux
			'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
			'/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
			'/usr/share/fonts/truetype/freefont/FreeSans.ttf',
			'/usr/share/fonts/TTF/DejaVuSans.ttf',
			// Windows
			'C:\\Windows\\Fonts\\arial.ttf',
			'C:\\Windows\\Fonts\\segoeui.ttf',
			'C:\\Windows\\Fonts\\calibri.ttf',
		);

		/**
		 * Filter system font paths tried for text watermarks.
		 *
		 * @param string[] $candidates Absolute font file paths.
		 */
		$candidates = apply_filters( 'modula_watermark_system_font_candidates', $candidates );

		foreach ( $candidates as $path ) {
			if ( is_string( $path ) && '' !== $path && is_readable( $path ) ) {
				return $path;
			}
		}

		return '';
	}

	/**
	 * Parse the text colour the editor saves.
	 *
	 * The editor's colour picker saves `rgba(r,g,b,a)`; older settings and
	 * typed values are `#RGB`, `#RRGGBB` or `#RRGGBBAA`. Anything else burns
	 * white, as before. The colour's alpha multiplies the watermark opacity.
	 *
	 * @param string $value Stored colour.
	 * @return array{r:int,g:int,b:int,a:float} Channels 0–255, alpha 0–1.
	 */
	public function parse_text_color( $value ) {
		$value = trim( (string) $value );
		$rgba  = $this->parse_rgb_function( $value );
		if ( null !== $rgba ) {
			return $rgba;
		}

		$hex = ltrim( $value, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( ! in_array( strlen( $hex ), array( 6, 8 ), true ) || ! ctype_xdigit( $hex ) ) {
			return array(
				'r' => 255,
				'g' => 255,
				'b' => 255,
				'a' => 1.0,
			);
		}
		return array(
			'r' => hexdec( substr( $hex, 0, 2 ) ),
			'g' => hexdec( substr( $hex, 2, 2 ) ),
			'b' => hexdec( substr( $hex, 4, 2 ) ),
			'a' => 8 === strlen( $hex ) ? hexdec( substr( $hex, 6, 2 ) ) / 255 : 1.0,
		);
	}

	/**
	 * Parse `rgb(r,g,b)` / `rgba(r,g,b,a)`, comma- or space-separated.
	 *
	 * @param string $value Trimmed colour.
	 * @return array{r:int,g:int,b:int,a:float}|null Null when the value is not this notation.
	 */
	private function parse_rgb_function( $value ) {
		$pattern = '/^rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})(?:\s*[,\/]\s*([\d.]+)(%?))?\s*\)$/i';
		if ( ! preg_match( $pattern, $value, $parts ) ) {
			return null;
		}

		$alpha = 1.0;
		if ( isset( $parts[4] ) && '' !== $parts[4] ) {
			$alpha = (float) $parts[4] / ( '%' === $parts[5] ? 100 : 1 );
		}
		return array(
			'r' => min( 255, (int) $parts[1] ),
			'g' => min( 255, (int) $parts[2] ),
			'b' => min( 255, (int) $parts[3] ),
			'a' => max( 0.0, min( 1.0, $alpha ) ),
		);
	}

	/**
	 * Calculate watermark top-left for a 9-point grid.
	 *
	 * @param string $position Position key.
	 * @param int    $margin   Margin px for this image (resolve_mark_px()), on both axes.
	 * @param int    $image_w  Image width.
	 * @param int    $image_h  Image height.
	 * @param int    $mark_w   Mark width.
	 * @param int    $mark_h   Mark height.
	 * @param string $attachment_path Path for filter.
	 * @param int    $gallery_id Gallery id for filter.
	 * @param array  $settings Settings for filter.
	 * @return array{x:float|int,y:float|int}
	 */
	private function calculate_position( $position, $margin, $image_w, $image_h, $mark_w, $mark_h, $attachment_path, $gallery_id, $settings ) {
		$margin  = (int) $margin;
		$image_w = (int) $image_w;
		$image_h = (int) $image_h;
		$mark_w  = (int) $mark_w;
		$mark_h  = (int) $mark_h;
		$coords  = array(
			'x' => $margin,
			'y' => $margin,
		);

		switch ( $position ) {
			case 'top_left':
				$coords = array(
					'x' => $margin,
					'y' => $margin,
				);
				break;
			case 'top_center':
				$coords = array(
					'x' => ( $image_w - $mark_w ) / 2,
					'y' => $margin,
				);
				break;
			case 'top_right':
				$coords = array(
					'x' => ( $image_w - $mark_w ) - $margin,
					'y' => $margin,
				);
				break;
			case 'middle_left':
				$coords = array(
					'x' => $margin,
					'y' => ( $image_h - $mark_h ) / 2,
				);
				break;
			case 'center':
				$coords = array(
					'x' => ( $image_w - $mark_w ) / 2,
					'y' => ( $image_h - $mark_h ) / 2,
				);
				break;
			case 'middle_right':
				$coords = array(
					'x' => ( $image_w - $mark_w ) - $margin,
					'y' => ( $image_h - $mark_h ) / 2,
				);
				break;
			case 'bottom_left':
				$coords = array(
					'x' => $margin,
					'y' => ( $image_h - $mark_h ) - $margin,
				);
				break;
			case 'bottom_center':
				$coords = array(
					'x' => ( $image_w - $mark_w ) / 2,
					'y' => ( $image_h - $mark_h ) - $margin,
				);
				break;
			case 'bottom_right':
				$coords = array(
					'x' => ( $image_w - $mark_w ) - $margin,
					'y' => ( $image_h - $mark_h ) - $margin,
				);
				break;
			default:
				$coords = apply_filters( 'modula_watermark_position', $coords, $attachment_path, $gallery_id, $settings );
				break;
		}

		return $coords;
	}

	/**
	 * Merge watermark layer onto base with opacity (GD).
	 *
	 * @param resource|\GdImage $image     Base image.
	 * @param resource|\GdImage $watermark Watermark layer.
	 * @param int               $x         X.
	 * @param int               $y         Y.
	 * @param int               $w         Width.
	 * @param int               $h         Height.
	 * @param int               $opacity   0–100.
	 * @return void
	 */
	private function gd_merge_with_opacity( $image, $watermark, $x, $y, $w, $h, $opacity ) {
		$opacity = max( 0, min( 100, (int) $opacity ) );
		if ( 100 === $opacity ) {
			imagecopy( $image, $watermark, (int) $x, (int) $y, 0, 0, (int) $w, (int) $h );
			return;
		}
		// imagecopymerge pct is opacity for non-alpha sources; for PNG with alpha, scale alpha then copy.
		if ( function_exists( 'imagepalettetotruecolor' ) ) {
			@imagepalettetotruecolor( $watermark );
		}
		imagealphablending( $watermark, false );
		imagesavealpha( $watermark, true );
		for ( $py = 0; $py < $h; $py++ ) {
			for ( $px = 0; $px < $w; $px++ ) {
				$rgba = imagecolorat( $watermark, $px, $py );
				$a    = ( $rgba & 0x7F000000 ) >> 24;
				$r    = ( $rgba >> 16 ) & 0xFF;
				$g    = ( $rgba >> 8 ) & 0xFF;
				$b    = $rgba & 0xFF;
				// GD alpha: 0 opaque, 127 transparent. Scale toward transparent by opacity.
				$new_a = (int) round( 127 - ( ( 127 - $a ) * ( $opacity / 100 ) ) );
				$color = imagecolorallocatealpha( $watermark, $r, $g, $b, $new_a );
				imagesetpixel( $watermark, $px, $py, $color );
			}
		}
		imagealphablending( $image, true );
		imagecopy( $image, $watermark, (int) $x, (int) $y, 0, 0, (int) $w, (int) $h );
	}

	/**
	 * Save GD image to watermarked path.
	 *
	 * @param resource|\GdImage $image           Image.
	 * @param string            $attachment_path Source path.
	 * @param array             $image_meta      getimagesize meta.
	 * @return string|false
	 */
	private function gd_write_watermarked( $image, $attachment_path, $image_meta ) {
		$attachment_path = $this->build_watermarked_path( $attachment_path );
		$written         = false;
		$mime            = isset( $image_meta['mime'] ) ? $image_meta['mime'] : '';

		switch ( $mime ) {
			case 'image/jpeg':
			case 'image/jpg':
				$written = (bool) imagejpeg( $image, $attachment_path );
				break;
			case 'image/png':
				$written = (bool) imagepng( $image, $attachment_path );
				break;
			case 'image/gif':
				$written = (bool) imagegif( $image, $attachment_path );
				break;
			case 'image/webp':
				if ( function_exists( 'imagewebp' ) ) {
					$written = (bool) imagewebp( $image, $attachment_path );
				}
				break;
		}

		imagedestroy( $image );

		if ( ! $written || ! file_exists( $attachment_path ) ) {
			return false;
		}

		return $attachment_path;
	}

	/**
	 * Text watermark via GD using a system TTF when available.
	 *
	 * @param string $attachment_path Path.
	 * @param int    $gallery_id      Gallery ID.
	 * @param array  $settings        Settings.
	 * @return string|false
	 */
	public function watermark_text_gd( $attachment_path, $gallery_id, $settings ) {
		if ( ! $attachment_path || ! is_readable( $attachment_path ) ) {
			return false;
		}

		$text = isset( $settings['watermark_text'] ) ? (string) $settings['watermark_text'] : '';
		$text = trim( wp_strip_all_tags( $text ) );
		if ( '' === $text ) {
			return false;
		}

		// The bitmap font has one fixed ~9px size; callers report the missing font (can_render_text()).
		$font_path = $this->resolve_gd_text_font_path();
		if ( '' === $font_path ) {
			return false;
		}

		$image = @imagecreatefromstring( file_get_contents( $attachment_path ) );
		if ( ! $image ) {
			return false;
		}

		$image_meta   = getimagesize( $attachment_path );
		$image_width  = imagesx( $image );
		$image_height = imagesy( $image );
		$mark_px      = $this->resolve_mark_px( $settings, $image_width );
		// GD sizes TrueType text in points at 96 dpi; 0.75pt draws a 1px em.
		$size         = $mark_px['text_size'] * 0.75;
		$color        = $this->parse_text_color( isset( $settings['watermark_text_color'] ) ? $settings['watermark_text_color'] : '#FFFFFF' );
		$opacity      = $this->resolve_opacity( $settings ) * $color['a'];
		$position_key = isset( $settings['watermark_position'] ) ? $settings['watermark_position'] : 'bottom_left';

		// GD alpha: 0 = opaque, 127 = transparent.
		$gd_alpha = (int) round( 127 - ( 127 * ( $opacity / 100 ) ) );
		$gd_alpha = max( 0, min( 127, $gd_alpha ) );

		imagealphablending( $image, true );

		$bbox = imagettfbbox( $size, 0, $font_path, $text );
		if ( false === $bbox ) {
			imagedestroy( $image );
			return false;
		}
		$mark_w = abs( $bbox[2] - $bbox[0] );
		$mark_h = abs( $bbox[7] - $bbox[1] );
		$coords = $this->calculate_position( $position_key, $mark_px['margin'], $image_width, $image_height, $mark_w, $mark_h, $attachment_path, $gallery_id, $settings );
		// imagettftext baseline is bottom of text; bbox[1] is often negative.
		$baseline_y = (int) $coords['y'] + $mark_h;
		$baseline_x = (int) $coords['x'];
		$allocated  = imagecolorallocatealpha( $image, $color['r'], $color['g'], $color['b'], $gd_alpha );
		imagettftext( $image, $size, 0, $baseline_x, $baseline_y, $allocated, $font_path, $text );

		return $this->gd_write_watermarked( $image, $attachment_path, is_array( $image_meta ) ? $image_meta : array() );
	}

	/**
	 * Text watermark via Imagick using a system font when available.
	 *
	 * @param string $attachment_path Path.
	 * @param int    $gallery_id      Gallery ID.
	 * @param array  $settings        Settings.
	 * @return string|false
	 * @throws \ImagickException
	 */
	public function watermark_text_imagick( $attachment_path, $gallery_id, $settings ) {
		if ( ! $attachment_path || ! is_readable( $attachment_path ) ) {
			return false;
		}

		$text = isset( $settings['watermark_text'] ) ? (string) $settings['watermark_text'] : '';
		$text = trim( wp_strip_all_tags( $text ) );
		if ( '' === $text ) {
			return false;
		}

		$path = pathinfo( $attachment_path );
		$ext  = isset( $path['extension'] ) ? strtolower( $path['extension'] ) : '';

		$image        = new \Imagick( $attachment_path );
		$size         = $image->getImageGeometry();
		$image_width  = (int) $size['width'];
		$image_height = (int) $size['height'];

		$mark_px = $this->resolve_mark_px( $settings, $image_width );
		// ImageMagick's default 72 dpi makes a point one pixel.
		$font_size    = $mark_px['text_size'];
		$color        = $this->parse_text_color( isset( $settings['watermark_text_color'] ) ? $settings['watermark_text_color'] : '#FFFFFF' );
		$opacity      = $this->resolve_opacity( $settings ) * $color['a'];
		$margin       = $mark_px['margin'];
		$position_key = isset( $settings['watermark_position'] ) ? $settings['watermark_position'] : 'bottom_left';
		$font_path    = $this->resolve_system_font_path();

		$draw = new \ImagickDraw();
		if ( $font_path ) {
			$draw->setFont( $font_path );
		} else {
			// Let ImageMagick pick a configured system family.
			$draw->setFont( 'Arial' );
		}
		$draw->setFontSize( $font_size );
		$draw->setFillColor( new \ImagickPixel( sprintf( 'rgba(%d,%d,%d,%.4f)', $color['r'], $color['g'], $color['b'], $opacity / 100 ) ) );

		$metrics = $image->queryFontMetrics( $draw, $text );
		$mark_w  = isset( $metrics['textWidth'] ) ? (int) ceil( $metrics['textWidth'] ) : $font_size * strlen( $text );
		$mark_h  = isset( $metrics['textHeight'] ) ? (int) ceil( $metrics['textHeight'] ) : $font_size;
		$coords  = $this->calculate_position( $position_key, $margin, $image_width, $image_height, $mark_w, $mark_h, $attachment_path, $gallery_id, $settings );
		$x       = (int) $coords['x'];
		// annotateImage uses baseline; approximate with ascent.
		$ascent = isset( $metrics['ascender'] ) ? (int) $metrics['ascender'] : $mark_h;
		$y      = (int) $coords['y'] + max( 1, $ascent );

		$image->annotateImage( $draw, $x, $y, 0, $text );

		if ( 'heic' === $ext || 'heif' === $ext ) {
			$image->setImageFormat( 'jpeg' );
			$attachment_path = $this->build_watermarked_path( $attachment_path, 'jpg' );
		} else {
			$attachment_path = $this->build_watermarked_path( $attachment_path );
		}

		$image->writeImage( $attachment_path );
		$image->clear();
		$image->destroy();
		$draw->destroy();

		if ( ! file_exists( $attachment_path ) ) {
			return false;
		}

		return $attachment_path;
	}

	/**
	 * Watermark image using GD
	 *
	 * @param string $attachment_path Path.
	 * @param string $watermark_path  Watermark path.
	 * @param int    $gallery_id      Gallery ID.
	 * @param array  $settings        Settings.
	 * @param array  $img_obj         Context.
	 *
	 * @return string|false
	 * @since 1.0
	 */
	public function watermark_gd( $attachment_path, $watermark_path, $gallery_id, $settings, $img_obj ) {
		if ( ! $attachment_path || ! $watermark_path ) {
			return false;
		}

		$image     = @imagecreatefromstring( file_get_contents( $attachment_path ) );
		$watermark = @imagecreatefromstring( file_get_contents( $watermark_path ) );

		if ( ! $image || ! $watermark ) {
			if ( $image ) {
				imagedestroy( $image );
			}
			if ( $watermark ) {
				imagedestroy( $watermark );
			}
			return false;
		}

		$image_width      = imagesx( $image );
		$image_height     = imagesy( $image );
		$watermark_width  = imagesx( $watermark );
		$watermark_height = imagesy( $watermark );
		$image_meta       = getimagesize( $attachment_path );
		$scale_factor     = 0.25;
		$resize_factor    = $watermark_height > 0 ? ( $watermark_width / $watermark_height ) : 1;

		$src_watermark = @imagecreatefromstring( file_get_contents( $watermark_path ) );

		if ( ( '0' != $settings['watermark_image_dimension_width'] && '' != $settings['watermark_image_dimension_width'] ) && ( '0' == $settings['watermark_image_dimension_height'] || '' == $settings['watermark_image_dimension_height'] ) ) {
			$new_watermark_width  = (int) $settings['watermark_image_dimension_width'];
			$new_watermark_height = (float) $settings['watermark_image_dimension_width'] / $resize_factor;
			imagedestroy( $watermark );
			$watermark = imagecreatetruecolor( $new_watermark_width, (int) $new_watermark_height );
			imagecolortransparent( $watermark, imagecolorallocatealpha( $watermark, 0, 0, 0, 127 ) );
			imagealphablending( $watermark, false );
			imagesavealpha( $watermark, true );
			imagecopyresampled( $watermark, $src_watermark, 0, 0, 0, 0, $new_watermark_width, $new_watermark_height, $watermark_width, $watermark_height );
			$watermark_width  = (int) $new_watermark_width;
			$watermark_height = (int) $new_watermark_height;
		}

		if ( ( '0' != $settings['watermark_image_dimension_height'] && '' != $settings['watermark_image_dimension_height'] ) && ( '0' == $settings['watermark_image_dimension_width'] || '' == $settings['watermark_image_dimension_width'] ) ) {
			$new_watermark_width  = (float) $settings['watermark_image_dimension_height'] * $resize_factor;
			$new_watermark_height = (int) $settings['watermark_image_dimension_height'];
			imagedestroy( $watermark );
			$watermark = imagecreatetruecolor( (int) $new_watermark_width, $new_watermark_height );
			imagecolortransparent( $watermark, imagecolorallocatealpha( $watermark, 0, 0, 0, 127 ) );
			imagealphablending( $watermark, false );
			imagesavealpha( $watermark, true );
			imagecopyresampled( $watermark, $src_watermark, 0, 0, 0, 0, $new_watermark_width, $new_watermark_height, $watermark_width, $watermark_height );
			$watermark_width  = (int) $new_watermark_width;
			$watermark_height = (int) $new_watermark_height;
		}

		if ( ( '0' != $settings['watermark_image_dimension_height'] && '' != $settings['watermark_image_dimension_height'] ) && ( '0' != $settings['watermark_image_dimension_width'] && '' != $settings['watermark_image_dimension_width'] ) ) {
			$new_watermark_width  = (int) $settings['watermark_image_dimension_width'];
			$new_watermark_height = (int) $settings['watermark_image_dimension_height'];
			imagedestroy( $watermark );
			$watermark = imagecreatetruecolor( $new_watermark_width, $new_watermark_height );
			imagecolortransparent( $watermark, imagecolorallocatealpha( $watermark, 0, 0, 0, 127 ) );
			imagealphablending( $watermark, false );
			imagesavealpha( $watermark, true );
			imagecopyresampled( $watermark, $src_watermark, 0, 0, 0, 0, $new_watermark_width, $new_watermark_height, $watermark_width, $watermark_height );
			$watermark_width  = (int) $new_watermark_width;
			$watermark_height = (int) $new_watermark_height;
		}

		if ( $watermark_width > $image_width || $watermark_height > $image_height ) {
			$new_watermark_width  = $watermark_width * $scale_factor;
			$new_watermark_height = $watermark_height * $scale_factor;
			$tmp                  = imagecreatetruecolor( (int) $new_watermark_width, (int) $new_watermark_height );
			imagecolortransparent( $tmp, imagecolorallocatealpha( $tmp, 0, 0, 0, 127 ) );
			imagealphablending( $tmp, false );
			imagesavealpha( $tmp, true );
			imagecopyresampled( $tmp, $watermark, 0, 0, 0, 0, (int) $new_watermark_width, (int) $new_watermark_height, $watermark_width, $watermark_height );
			imagedestroy( $watermark );
			$watermark        = $tmp;
			$watermark_width  = (int) $new_watermark_width;
			$watermark_height = (int) $new_watermark_height;
		}

		if ( $src_watermark ) {
			imagedestroy( $src_watermark );
		}

		imagealphablending( $image, true );
		imagealphablending( $watermark, true );

		$position = $this->calculate_position(
			isset( $settings['watermark_position'] ) ? $settings['watermark_position'] : 'bottom_left',
			$this->resolve_margin_px( $settings, $image_width ),
			$image_width,
			$image_height,
			$watermark_width,
			$watermark_height,
			$attachment_path,
			$gallery_id,
			$settings
		);

		$this->gd_merge_with_opacity(
			$image,
			$watermark,
			(int) $position['x'],
			(int) $position['y'],
			$watermark_width,
			$watermark_height,
			$this->resolve_opacity( $settings )
		);

		imagedestroy( $watermark );

		return $this->gd_write_watermarked( $image, $attachment_path, is_array( $image_meta ) ? $image_meta : array() );
	}

	/**
	 * Watermark image using Imagick
	 *
	 * @param string $attachment_path Path.
	 * @param string $watermark_path  Unused (reads from settings).
	 * @param int    $gallery_id      Gallery ID.
	 * @param array  $settings        Settings.
	 * @param array  $img_obj         Context.
	 *
	 * @throws \ImagickException
	 * @since 1.0
	 */
	public function watermark_imagick( $attachment_path, $watermark_path, $gallery_id, $settings, $img_obj ) {
		$watermark_path = get_attached_file( $settings['watermark_image'] );
		if ( ! $watermark_path || ! is_readable( $watermark_path ) ) {
			return false;
		}

		$path = pathinfo( $attachment_path );
		$ext  = isset( $path['extension'] ) ? strtolower( $path['extension'] ) : '';

		$image     = new \Imagick( $attachment_path );
		$watermark = new \Imagick( $watermark_path );

		$image_size   = $image->getImageGeometry();
		$image_width  = $image_size['width'];
		$image_height = $image_size['height'];

		$watermark_size   = $watermark->getImageGeometry();
		$watermark_width  = $watermark_size['width'];
		$watermark_height = $watermark_size['height'];
		$resize_factor    = $watermark_height > 0 ? ( $watermark_width / $watermark_height ) : 1;

		if ( ! empty( $settings['watermark_image_dimension_width'] ) && empty( $settings['watermark_image_dimension_height'] ) ) {
			$watermark_width  = (int) $settings['watermark_image_dimension_width'];
			$watermark_height = (float) $watermark_width / $resize_factor;
			$watermark->scaleImage( $watermark_width, (int) $watermark_height );
		}

		if ( ! empty( $settings['watermark_image_dimension_height'] ) && empty( $settings['watermark_image_dimension_width'] ) ) {
			$watermark_height = (int) $settings['watermark_image_dimension_height'];
			$watermark_width  = (float) $watermark_height * $resize_factor;
			$watermark->scaleImage( (int) $watermark_width, $watermark_height );
		}

		if ( ! empty( $settings['watermark_image_dimension_width'] ) && ! empty( $settings['watermark_image_dimension_height'] ) ) {
			$watermark_width  = (int) $settings['watermark_image_dimension_width'];
			$watermark_height = (int) $settings['watermark_image_dimension_height'];
			$watermark->scaleImage( $watermark_width, $watermark_height );
		}

		if ( $watermark_width > $image_width || $watermark_height > $image_height ) {
			$scale_factor     = 0.25;
			$watermark_width  = $watermark_width * $scale_factor;
			$watermark_height = $watermark_height * $scale_factor;
			$watermark->scaleImage( $watermark_width, $watermark_height );
		}

		$watermark_size   = $watermark->getImageGeometry();
		$watermark_width  = $watermark_size['width'];
		$watermark_height = $watermark_size['height'];

		$opacity = $this->resolve_opacity( $settings );
		if ( $opacity < 100 ) {
			$watermark->evaluateImage( \Imagick::EVALUATE_MULTIPLY, $opacity / 100, \Imagick::CHANNEL_ALPHA );
		}

		$position = $this->calculate_position(
			isset( $settings['watermark_position'] ) ? $settings['watermark_position'] : 'bottom_left',
			$this->resolve_margin_px( $settings, $image_width ),
			$image_width,
			$image_height,
			$watermark_width,
			$watermark_height,
			$attachment_path,
			$gallery_id,
			$settings
		);

		$image->compositeImage( $watermark, \Imagick::COMPOSITE_OVER, (int) $position['x'], (int) $position['y'] );

		if ( 'heic' === $ext || 'heif' === $ext ) {
			$image->setImageFormat( 'jpeg' );
			$attachment_path = $this->build_watermarked_path( $attachment_path, 'jpg' );
		} else {
			$attachment_path = $this->build_watermarked_path( $attachment_path );
		}

		$image->writeImage( $attachment_path );

		$image->clear();
		$image->destroy();
		$watermark->clear();
		$watermark->destroy();

		if ( ! file_exists( $attachment_path ) ) {
			return false;
		}

		return $attachment_path;
	}

	/**
	 * Build destination path for a watermarked image.
	 *
	 * @param string      $source_path Source image path.
	 * @param string|null $force_ext   Optional extension override.
	 * @return string
	 */
	private function build_watermarked_path( $source_path, $force_ext = null ) {
		$path = pathinfo( $source_path );
		$ext  = null !== $force_ext ? $force_ext : ( isset( $path['extension'] ) ? $path['extension'] : '' );
		$name = isset( $path['filename'] ) ? $path['filename'] : '';

		$name = preg_replace( '/\.(jpe?g|png|gif|webp|heic|heif)$/i', '', $name );

		$suffix = $this->sufix;
		if ( '' !== $suffix && substr( $name, -strlen( $suffix ) ) === $suffix ) {
			$name = substr( $name, 0, -strlen( $suffix ) );
		}

		$dir = isset( $path['dirname'] ) ? $path['dirname'] : '.';

		return $dir . '/' . $name . $suffix . ( '' !== $ext ? '.' . $ext : '' );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return Watermarking
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Watermarking ) ) {
			self::$instance = new Watermarking();
		}

		return self::$instance;
	}
}
