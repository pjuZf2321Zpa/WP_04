<?php
namespace Modula_Pro\Extensions\Watermark;

use Modula\V2\Settings\Watermark_Scale;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *
 */
class Watermark {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		require_once __DIR__ . '/abilities/class-watermark-executor.php';
		require_once __DIR__ . '/abilities/class-provider.php';
		\Modula_Pro\Extensions\Watermark\Abilities\Provider::boot();

		add_action( 'admin_init', array( $this, 'set_admin_requirements' ), 25 );

		// Add ajax_button field type used for ajax
		add_filter( 'modula_render_ajax_button_field_type', array( $this, 'ajax_button_field_type' ), 10, 5 );

		// Add image_upload field type
		add_filter( 'modula_render_image_upload_field_type', array( $this, 'image_upload_field_type' ), 10, 5 );

		// Add defaults
		add_filter( 'modula_lite_default_settings', array( $this, 'add_watermark_defaults' ), 10, 5 );

		add_action( 'admin_init', array( $this, 'register_watermark_option' ) );

		add_filter( 'modula_uninstall_db_options', array( $this, 'watermark_uninstall' ), 16, 1 );

		add_filter( 'modula_migrate_gallery_data', array( $this, 'watermark_migrator_gallery_data' ), 25, 3 );

		// Add debug information
		add_filter( 'modula_debug_information', array( $this, 'debug_information' ), 45 );

		new \Modula_Pro\Extensions\Watermark\Rest_API\WP_Rest_Modula_Watermark_Controller();
		new Enqueue();

		if ( is_admin() ) {
			new Admin\Settings_Editor_Integration();
		}
	}

	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.0.7
	 */
	public function set_admin_requirements() {
		// Filter Modula Watermark Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'modula_watermark_tabs' ), 99 );

		// Filter Modula Watermark Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_watermark_fields' ) );

		// Add Setings Tab
		add_filter( 'modula_admin_page_tabs', array( $this, 'add_watermark_tab' ) );
		add_action( 'modula_admin_tab_watermark', array( $this, 'render_watermark_tab' ) );

		// Ajax for applying watermark
		add_action( 'wp_ajax_modula_remove_watermark', array( $this, 'modula_remove_watermark' ), 10, 2 );
		add_action( 'wp_ajax_modula_apply_single_watermark', array( $this, 'modula_apply_watermark' ), 10, 2 );

		new Watermarking();
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Modula_Watermark object.
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Watermark ) ) {
			self::$instance = new Watermark();
		}

		return self::$instance;
	}

	/**
	 * Add Modula Watermark Tab
	 *
	 * @param $tabs
	 *
	 * @return mixed
	 */
	public function modula_watermark_tabs( $tabs ) {

		if ( ! isset( $tabs['watermark'] ) ) {
			$tabs['watermark'] = array(
				'label'    => esc_html__( 'Watermark', 'modula-pro' ),
				'icon'     => 'dashicons dashicons-id-alt',
				'priority' => 100,
			);
		}

		unset( $tabs['watermark']['badge'] );

		return $tabs;
	}

	/**
	 * Add fields for Modula Watermark tab
	 *
	 * @param $fields
	 *
	 * @return mixed
	 */
	public function modula_watermark_fields( $fields ) {

		// Add filters settings
		$fields['watermark'] = array(
			'enable_watermark'                   => array(
				'name'      => esc_html__( 'Watermark', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 10,
				'children'  => array( 'custom_settings_watermark', 'watermark_apply_to_existing_images', 'watermark_remove_watermark' ),
				'data_type' => 'bool',
			),
			'custom_settings_watermark'          => array(
				'name'      => esc_html__( 'Use custom settings', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 20,
				'children'  => array( 'watermark_image', 'watermark_position', 'watermark_margin', 'watermark_image_dimension_width', 'watermark_image_dimension_height', 'watermark_enable_backup' ),
				'parent'    => 'enable_watermark',
				'data_type' => 'bool',
			),
			'watermark_image'                    => array(
				'name'        => esc_html__( 'Watermark Image', 'modula-pro' ),
				'type'        => 'image_upload',
				'default'     => 0,
				'class'       => 'button insert-media-url',
				'button_text' => esc_html__( 'Upload Watermark', 'modula-pro' ),
				'is_child'    => true,
				'priority'    => 30,
				'data_type'   => 'number',
			),
			'watermark_position'                 => array(
				'name'      => esc_html__( 'Watermark Position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'top_left'     => esc_html__( 'Top left', 'modula-pro' ),
					'top_right'    => esc_html__( 'Top right', 'modula-pro' ),
					'bottom_right' => esc_html__( 'Bottom right', 'modula-pro' ),
					'bottom_left'  => esc_html__( 'Bottom left', 'modula-pro' ),
					'center'       => esc_html__( 'Center', 'modula-pro' ),
				),
				'default'   => 'bottom_left',
				'is_child'  => true,
				'priority'  => 40,
				'data_type' => 'text',
			),
			'watermark_margin'                   => array(
				'name'      => esc_html__( 'Watermark Margin', 'modula-pro' ),
				'type'      => 'ui-slider',
				'is_child'  => true,
				'priority'  => 50,
				'min'       => 0,
				'max'       => 50,
				'step'      => 1,
				'default'   => 10,
				'data_type' => 'number',
			),
			'watermark_image_dimension_width'    => array(
				'name'      => esc_html__( 'Watermark Image Width', 'modula-pro' ),
				'type'      => 'text',
				'is_child'  => true,
				'priority'  => 50,
				'default'   => 100,
				'data_type' => 'number',
			),
			'watermark_image_dimension_height'   => array(
				'name'      => esc_html__( 'Watermark Image Height', 'modula-pro' ),
				'type'      => 'text',
				'is_child'  => true,
				'priority'  => 50,
				'default'   => 0,
				'data_type' => 'number',
			),
			'watermark_enable_backup'            => array(
				'name'      => esc_html__( 'Backup images', 'modula-pro' ),
				'type'      => 'toggle',
				'is_child'  => true,
				'priority'  => 51,
				'default'   => 1,
				'data_type' => 'bool',
			),
			'watermark_apply_to_existing_images' => array(
				'name'          => esc_html__( 'Watermark inserted images', 'modula-pro' ),
				'type'          => 'ajax_button',
				'value'         => 'apply_watermark',
				'button_text'   => 'Watermark Images',
				'priority'      => 52,
				'error_message' => esc_html__( 'You need to save your gallery before applying watermark', 'modula-pro' ),
				'data_type'     => 'default',
			),
			'watermark_remove_watermark'         => array(
				'name'          => esc_html__( 'Remove Watermark', 'modula-pro' ),
				'type'          => 'ajax_button',
				'value'         => 'remove_watermark',
				'button_text'   => 'Remove Watermark',
				'priority'      => 53,
				'error_message' => esc_html__( 'You need to save your gallery before removing watermark', 'modula-pro' ),
				'data_type'     => 'default',
			),

		);

		return $fields;
	}


	/***
	 * Add ajax_button field type, used for ajax
	 *
	 * @param $html
	 * @param $field
	 *
	 * @return string
	 */
	public function ajax_button_field_type( $html, $field ) {
		// Always enabled: the server answers per image (Remove needs that image's backup file).
		$html  = '<div class="modula-watermark-container ' . esc_attr( $field['value'] ) . '">';
		$html .= '<a href="#" class="button button-primary modula_ajax_button ' . esc_attr( $field['value'] ) . '">' . esc_html( $field['button_text'] ) . '</a>';
		$html .= '<div class="modula-watermark-error" data-msg="' . esc_attr( $field['error_message'] ) . '"></div>';
		$html .= '</div>';

		return $html;
	}


	/***
	 * Add image_upload field type
	 *
	 * @param $html
	 * @param $field
	 * @param $value
	 *
	 * @return string
	 */
	public function image_upload_field_type( $html, $field, $value ) {

		$style = array(
			'upload'  => '',
			'replace' => 'display:none;',
			'delete'  => 'display:none;',
		);

		if ( 0 !== absint( $value ) ) {
			$style['upload']  = 'display:none;';
			$style['replace'] = '';
			$style['delete']  = '';
		}

		$html  = '<input type="hidden" name="modula-settings[' . esc_attr( $field['id'] ) . ']" id="' . esc_attr( $field['id'] ) . '" value="' . absint( $value ) . '">';
		$html .= '<div class="modula_watermark_image_preview">';
		if ( $value ) {
			$image = wp_get_attachment_image_src( $value, 'full' );
			if ( $image ) {
				$width  = $image[1];
				$height = $image[2];
				$class  = $width >= $height ? 'modula_watermark_preview_landscape' : 'modula_watermark_preview_portrait';
				$html  .= '<img src="' . esc_url( $image[0] ) . '" id="modula_watermark_preview" class="' . $class . '">';
			}
		}
		$html .= '</div>';
		$html .= '<input type="button" style="' . esc_attr( $style['upload'] ) . '" class="button button-primary" id="upload_watermark_file" value="' . esc_attr__( 'Upload', 'modula-pro' ) . '">';
		$html .= '<input type="button" style="' . esc_attr( $style['replace'] ) . '" class="button button-primary" id="replace_watermark_file" value="' . esc_attr__( 'Replace', 'modula-pro' ) . '">';
		$html .= '<input type="button" style="' . esc_attr( $style['delete'] ) . '" class="button" id="delete_watermark_file" value="' . esc_attr__( 'Delete', 'modula-pro' ) . '">';

		return $html;
	}

	/**
	 * @param $tabs
	 *
	 * @return mixed
	 *
	 * Add Watermark Settings tab
	 */
	public function add_watermark_tab( $tabs ) {

		$tabs['watermark'] = array(
			'label'    => esc_html__( 'Watermark Settings', 'modula-pro' ),
			'priority' => 30,
		);

		return $tabs;
	}

	/**
	 * Render Watermark Settings Tab
	 */
	public function render_watermark_tab() {
		if ( is_plugin_active( 'modula-best-grid-gallery/Modula.php' ) ) {
			include 'tabs/watermark.php';
		}
	}

	/**
	 * Register Watermark options
	 */
	public function register_watermark_option() {
		// creates our settings in the options table
		register_setting( 'modula-pro', 'modula-pro', array( $this, 'sanitize_option' ) );
	}

	public function sanitize_option( $current ) {
		return $current;
	}

	/**
	 * @param $defaults
	 *
	 * @return mixed
	 *
	 * Add Watermark Defaults
	 */
	public function add_watermark_defaults( $defaults ) {
		// No text size / margin share defaults: these merge under stored settings and would
		// mask the one-time px conversion (Watermark_Scale::gallery_flat_shares() fills them).
		$defaults['enable_watermark']                 = 0;
		$defaults['custom_settings_watermark']        = 0;
		$defaults['watermark_type']                   = 'none';
		$defaults['watermark_text']                   = '';
		$defaults['watermark_text_color']             = '#FFFFFF';
		$defaults['watermark_image']                  = 0;
		$defaults['watermark_position']               = 'bottom_left';
		$defaults['watermark_margin']                 = 10;
		$defaults['watermark_opacity']                = 60;
		$defaults['watermark_apply_scope']            = 'all';
		$defaults['watermark_image_dimension_width']  = 100;
		$defaults['watermark_image_dimension_height'] = 0;
		$defaults['watermark_enable_backup']          = 1;
		return $defaults;
	}

	/**
	 * AJAX: apply watermark to a single gallery image.
	 *
	 * @return void
	 */
	public function modula_apply_watermark() {
		check_ajax_referer( 'modula_watermark_images', 'nonce' );

		$gallery_id = isset( $_POST['gallery'] ) ? absint( $_POST['gallery'] ) : 0;
		$image_id   = isset( $_POST['modula_image_id'] ) ? absint( $_POST['modula_image_id'] ) : 0;
		$result     = $this->apply_watermark_to_image( $gallery_id, $image_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
			wp_die();
		}

		wp_send_json( array( 'status' => 'success' ) );
		wp_die();
	}

	/**
	 * Normalize burn-in settings from gallery meta or global option.
	 *
	 * @param array $source Settings array.
	 * @return array
	 */
	private function extract_watermark_burn_settings( $source ) {
		if ( ! is_array( $source ) ) {
			$source = array();
		}

		$type = isset( $source['watermark_type'] ) ? sanitize_key( (string) $source['watermark_type'] ) : '';
		if ( ! in_array( $type, array( 'none', 'text', 'image' ), true ) ) {
			$image_id = isset( $source['watermark_image'] ) ? absint( $source['watermark_image'] ) : 0;
			$type     = $image_id > 0 ? 'image' : 'none';
		}

		return array(
			'watermark_type'                   => $type,
			'watermark_text'                   => isset( $source['watermark_text'] ) ? (string) $source['watermark_text'] : '',
			'watermark_text_color'             => isset( $source['watermark_text_color'] ) ? (string) $source['watermark_text_color'] : '#FFFFFF',
			'watermark_image'                  => isset( $source['watermark_image'] ) ? absint( $source['watermark_image'] ) : 0,
			'watermark_position'               => isset( $source['watermark_position'] ) ? (string) $source['watermark_position'] : 'bottom_left',
			'watermark_margin'                 => isset( $source['watermark_margin'] ) ? absint( $source['watermark_margin'] ) : 10,
			'watermark_opacity'                => isset( $source['watermark_opacity'] ) ? absint( $source['watermark_opacity'] ) : 60,
			'watermark_image_dimension_width'  => isset( $source['watermark_image_dimension_width'] ) ? absint( $source['watermark_image_dimension_width'] ) : 100,
			'watermark_image_dimension_height' => isset( $source['watermark_image_dimension_height'] ) ? absint( $source['watermark_image_dimension_height'] ) : 0,
			'watermark_enable_backup'          => ! empty( $source['watermark_enable_backup'] ) ? 1 : 0,
		);
	}

	/**
	 * Whether Apply burns the gallery's own watermark settings.
	 *
	 * With Override global watermark off it burns the global Watermark
	 * settings, which are image-only.
	 *
	 * @param array $settings Gallery flat settings.
	 * @return bool
	 */
	private static function uses_gallery_watermark_settings( $settings ) {
		return ! empty( $settings['custom_settings_watermark'] );
	}

	/**
	 * Whether Apply keeps a backup of the original, from the settings Apply burns.
	 *
	 * The gallery's setting with Override global watermark on, else the global
	 * Watermark settings (`modula_watermark`). Remove never asks: it needs the
	 * backup file, whatever the setting says today.
	 *
	 * @param array       $gallery_settings Gallery flat settings.
	 * @param array|false $global_settings  The `modula_watermark` option.
	 * @return bool
	 */
	public static function resolve_backup_enabled( $gallery_settings, $global_settings ) {
		$source = self::uses_gallery_watermark_settings( $gallery_settings ) ? $gallery_settings : $global_settings;
		return is_array( $source ) && ! empty( $source['watermark_enable_backup'] );
	}

	/**
	 * Whether Apply keeps a backup of the original for a gallery.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return bool
	 */
	public function is_backup_enabled( $gallery_id ) {
		$settings = get_post_meta( absint( $gallery_id ), 'modula-settings', true );
		return self::resolve_backup_enabled( is_array( $settings ) ? $settings : array(), get_option( 'modula_watermark' ) );
	}

	/**
	 * Burn settings Apply uses while a gallery's Override global watermark is off.
	 *
	 * The global Watermark settings (`modula_watermark`) are image-only (no
	 * text UI) and keep their margin in px on the original. The editor's canvas
	 * preview reads the same array.
	 *
	 * @return array|null Normalized burn settings; null when the option is missing.
	 */
	public function get_global_burn_settings() {
		$modula_settings = get_option( 'modula_watermark' );
		if ( ! $modula_settings || ! is_array( $modula_settings ) ) {
			return null;
		}

		$settings                   = $this->extract_watermark_burn_settings( $modula_settings );
		$settings['watermark_type'] = ! empty( $settings['watermark_image'] ) ? 'image' : 'none';
		$settings['watermark_text'] = '';
		return $settings;
	}

	/**
	 * Which settings Apply burns for a gallery, so the editor can say so.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return string `gallery` (Override global watermark on) or `global`.
	 */
	public function get_watermark_settings_source( $gallery_id ) {
		$settings = get_post_meta( absint( $gallery_id ), 'modula-settings', true );
		return self::uses_gallery_watermark_settings( is_array( $settings ) ? $settings : array() ) ? 'gallery' : 'global';
	}

	/**
	 * Apply watermark to a single attachment in a gallery.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @param int $image_id   Attachment ID.
	 * @return true|\WP_Error
	 */
	public function apply_watermark_to_image( $gallery_id, $image_id ) {
		$this->ensure_attachment_admin_includes();

		$gallery_id = absint( $gallery_id );
		$image_id   = absint( $image_id );

		if ( $gallery_id <= 0 || $image_id <= 0 ) {
			return new \WP_Error(
				'modula_watermark_invalid_args',
				esc_html__( 'Something was wrong. Please try again', 'modula-pro' )
			);
		}

		$settings = get_post_meta( $gallery_id, 'modula-settings', true );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		if ( empty( $settings['enable_watermark'] ) ) {
			return new \WP_Error(
				'modula_watermark_disabled',
				esc_html__( 'Please enable watermark and update gallery', 'modula-pro' )
			);
		}

		if ( ! self::uses_gallery_watermark_settings( $settings ) ) {
			$wattermark_settings = $this->get_global_burn_settings();
			if ( null === $wattermark_settings ) {
				return new \WP_Error(
					'modula_watermark_settings_missing',
					esc_html__( 'There seems to be an error with the Watermark settings. Please check.', 'modula-pro' )
				);
			}
		} else {
			if ( empty( $settings ) ) {
				return new \WP_Error(
					'modula_watermark_settings_missing',
					esc_html__( 'There seems to be an error with the Watermark settings. Please check.', 'modula-pro' )
				);
			}

			// The gallery's text size and margin are shares of the image width (px saved earlier convert).
			$wattermark_settings = array_merge(
				$this->extract_watermark_burn_settings( $settings ),
				Watermark_Scale::gallery_flat_shares( $settings )
			);
		}

		$watermarking = Watermarking::get_instance();
		$type         = $watermarking->resolve_watermark_type( $wattermark_settings );

		// Classic metabox / legacy image flow: image present with type none → treat as image.
		if ( 'none' === $type && ! empty( $wattermark_settings['watermark_image'] ) ) {
			$type                                  = 'image';
			$wattermark_settings['watermark_type'] = 'image';
		}

		if ( 'none' === $type ) {
			return new \WP_Error(
				'modula_watermark_type_none',
				esc_html__( 'Choose a Text or Image watermark type before applying.', 'modula-pro' )
			);
		}

		$watermark_path = null;
		if ( 'text' === $type ) {
			$text = isset( $wattermark_settings['watermark_text'] ) ? trim( (string) $wattermark_settings['watermark_text'] ) : '';
			if ( '' === $text ) {
				return new \WP_Error(
					'modula_watermark_text_missing',
					esc_html__( 'Please enter watermark text and update the gallery.', 'modula-pro' )
				);
			}
			if ( ! $watermarking->can_render_text() ) {
				return new \WP_Error(
					'modula_watermark_font_missing',
					esc_html__( 'This server cannot draw text watermarks at their size: it has no Imagick and no TrueType font for GD. Ask your host to install a font such as DejaVu Sans, or use an image watermark.', 'modula-pro' )
				);
			}
		} else {
			if ( empty( $wattermark_settings['watermark_image'] ) ) {
				return new \WP_Error(
					'modula_watermark_image_missing',
					esc_html__( 'Please select a Watermark Image and update gallery', 'modula-pro' )
				);
			}

			$watermark_path = get_attached_file( $wattermark_settings['watermark_image'] );
			if ( ! $watermark_path ) {
				return new \WP_Error(
					'modula_watermark_file_missing',
					esc_html__( 'Missing watermark image.', 'modula-pro' )
				);
			}
		}

		$already_watermarked = get_post_meta( $image_id, 'modula_watermark_applied', true );
		if ( $already_watermarked ) {
			// Restore clean original from backup (keep backup), then burn in new settings.
			$restored = $this->restore_image_from_watermark_backup(
				$gallery_id,
				$image_id,
				array(
					'delete_backup'         => false,
					'require_backup'        => true,
					'require_watermarked'   => true,
					'reapply_error_context' => true,
				)
			);
			if ( is_wp_error( $restored ) ) {
				return $restored;
			}
		}

		$original_image = wp_get_original_image_path( $image_id );
		if ( ! $original_image ) {
			return new \WP_Error(
				'modula_watermark_original_missing',
				esc_html__( 'Missing original image.', 'modula-pro' ),
				array( 'skipped' => true )
			);
		}

		$previous_files = $this->get_attachment_files( $image_id );

		if ( self::resolve_backup_enabled( $settings, get_option( 'modula_watermark' ) ) ) {
			$upload_dir      = wp_get_upload_dir();
			$backup_relative = get_post_meta( $image_id, 'modula-backup', true );
			$backup_exists   = is_string( $backup_relative )
				&& '' !== $backup_relative
				&& ! empty( $upload_dir['basedir'] )
				&& file_exists( $upload_dir['basedir'] . $backup_relative );

			// Re-apply keeps an existing clean backup; only create on first apply.
			if ( ! $backup_exists ) {
				$current_user = wp_get_current_user();

				if ( isset( $current_user->user_login ) && ! empty( $upload_dir['basedir'] ) ) {
					$modula_gallery_folder = '/modula/gallery-' . $gallery_id . '/';
					$modula_gallery_dir    = $upload_dir['basedir'] . $modula_gallery_folder;

					if ( ! file_exists( $modula_gallery_dir ) ) {
						wp_mkdir_p( $modula_gallery_dir );
					}

					$backup_path = $modula_gallery_dir . basename( $original_image );
					if ( ! copy( $original_image, $backup_path ) || hash_file( 'sha256', $original_image ) !== hash_file( 'sha256', $backup_path ) ) {
						return new \WP_Error( 'modula_watermark_backup_failed', 'Could not preserve the original watermark backup.' );
					}
					update_post_meta( $image_id, 'modula-backup', $modula_gallery_folder . basename( $original_image ) );
				}
			}
		}

		$attachment_path = $watermarking->add_watermark( $original_image, $watermark_path, $gallery_id, $wattermark_settings, array( 'id' => $image_id ) );

		if ( ! $attachment_path || ! file_exists( $attachment_path ) ) {
			return new \WP_Error(
				'modula_watermark_write_failed',
				esc_html__( 'Could not create the watermarked image. Please ensure GD WebP support or Imagick is available.', 'modula-pro' )
			);
		}

		update_attached_file( $image_id, $attachment_path );
		$generated = $this->regenerate_watermark_metadata( $image_id, $attachment_path );
		if ( is_wp_error( $generated ) ) { return $generated; }

		update_post_meta( $image_id, 'modula_watermark_applied', true );

		// Only after the watermarked files are in place: the clean ones must not stay reachable by URL.
		$cleanup = $this->delete_superseded_files( $image_id, $previous_files );

		// Regenerates Modula custom grid thumbnails when the gallery uses custom dimensions.
		$grid_image_size = isset( $settings['grid_image_size'] ) ? $settings['grid_image_size'] : '';
		if ( 'custom' === $grid_image_size ) {
			$resizer    = new \Modula_Image();
			$grid_sizes = array(
				'width'  => isset( $settings['grid_image_dimensions']['width'] ) ? $settings['grid_image_dimensions']['width'] : 0,
				'height' => isset( $settings['grid_image_dimensions']['height'] ) ? $settings['grid_image_dimensions']['height'] : 0,
			);
			$crop       = ! empty( $settings['grid_image_crop'] );
			$type       = isset( $settings['type'] ) ? $settings['type'] : 'creative-gallery';
			$sizes      = $resizer->get_image_size( $image_id, $type, $grid_sizes, $crop );

			if (
				! is_wp_error( $sizes )
				&& is_array( $sizes )
				&& ! empty( $sizes['url'] )
				&& isset( $sizes['width'], $sizes['height'] )
			) {
				$resizer->resize_image(
					$sizes['url'],
					$sizes['width'],
					$sizes['height'],
					! empty( $settings['grid_image_crop'] ),
					'c',
					100,
					false,
					array(),
					true
				);
			}
		}

		return $cleanup;
	}

	/**
	 * AJAX: remove watermark from a single gallery image.
	 *
	 * @return void
	 */
	public function modula_remove_watermark() {
		check_ajax_referer( 'modula_watermark_images', 'nonce' );

		$gallery_id = isset( $_POST['gallery'] ) ? absint( $_POST['gallery'] ) : 0;
		$image_id   = isset( $_POST['modula_image_id'] ) ? absint( $_POST['modula_image_id'] ) : 0;
		$result     = $this->remove_watermark_from_image( $gallery_id, $image_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
			wp_die();
		}

		wp_send_json( array( 'status' => 'success' ) );
		wp_die();
	}

	/**
	 * Restore a single attachment from watermark backup (user-facing remove).
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @param int $image_id   Attachment ID.
	 * @return true|\WP_Error
	 */
	public function remove_watermark_from_image( $gallery_id, $image_id ) {
		return $this->restore_image_from_watermark_backup(
			$gallery_id,
			$image_id,
			array(
				'delete_backup'       => true,
				'require_backup'      => true,
				'require_watermarked' => true,
			)
		);
	}

	/**
	 * Restore attachment pixels from the Modula watermark backup folder.
	 *
	 * @param int   $gallery_id Gallery post ID.
	 * @param int   $image_id   Attachment ID.
	 * @param array $options {
	 *     Optional. Restore behaviour.
	 *
	 *     @type bool $delete_backup         Delete the backup file after restore. Default true.
	 *     @type bool $require_backup        Fail when backup meta/file is missing. Default true.
	 *     @type bool $require_watermarked   Fail when image is not marked watermarked. Default true.
	 *     @type bool $reapply_error_context Use re-apply-oriented error messages. Default false.
	 * }
	 * @return true|\WP_Error
	 */
	private function restore_image_from_watermark_backup( $gallery_id, $image_id, $options = array() ) {
		$this->ensure_attachment_admin_includes();

		$gallery_id = absint( $gallery_id );
		$image_id   = absint( $image_id );
		$options    = wp_parse_args(
			$options,
			array(
				'delete_backup'         => true,
				'require_backup'        => true,
				'require_watermarked'   => true,
				'reapply_error_context' => false,
			)
		);

		if ( $gallery_id <= 0 || $image_id <= 0 ) {
			return new \WP_Error(
				'modula_watermark_invalid_args',
				esc_html__( 'Something was wrong. Please try again', 'modula-pro' )
			);
		}

		$settings = get_post_meta( $gallery_id, 'modula-settings', true );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		// No backup-setting check: the setting only decides whether Apply keeps a backup;
		// whether this image has one is the backup file below.
		$already_watermarked = get_post_meta( $image_id, 'modula_watermark_applied', true );
		if ( ! empty( $options['require_watermarked'] ) && ! $already_watermarked ) {
			return new \WP_Error(
				'modula_watermark_not_applied',
				esc_html__( 'Image not watermarked. Skipping image.', 'modula-pro' ),
				array( 'skipped' => true )
			);
		}

		$upload_dir         = wp_get_upload_dir();
		$backup_relative    = get_post_meta( $image_id, 'modula-backup', true );
		$original_file_path = ( is_string( $backup_relative ) && '' !== $backup_relative && ! empty( $upload_dir['basedir'] ) )
			? $upload_dir['basedir'] . $backup_relative
			: '';

		if ( empty( $original_file_path ) || ! file_exists( $original_file_path ) ) {
			if ( empty( $options['require_backup'] ) ) {
				return true;
			}

			if ( ! empty( $options['reapply_error_context'] ) ) {
				if ( empty( $backup_relative ) ) {
					return new \WP_Error(
						'modula_watermark_reapply_no_backup',
						esc_html__( 'This image was watermarked without a backup. Re-upload the original or enable backups before the first apply.', 'modula-pro' )
					);
				}

				return new \WP_Error(
					'modula_watermark_reapply_backup_missing',
					esc_html__( 'Original backup not found. Cannot re-apply watermark.', 'modula-pro' )
				);
			}

			return new \WP_Error(
				'modula_watermark_backup_missing',
				esc_html__( 'This image has no saved original, so its watermark cannot be removed. Skipping image.', 'modula-pro' ),
				array( 'skipped' => true )
			);
		}

		$attached_file = wp_get_original_image_path( $image_id );
		if ( ! $attached_file ) {
			return new \WP_Error(
				'modula_watermark_original_missing',
				esc_html__( 'Missing original image.', 'modula-pro' ),
				array( 'skipped' => true )
			);
		}

		$previous_files = $this->get_attachment_files( $image_id );

		$copy_path = pathinfo( $attached_file, PATHINFO_DIRNAME ) . '/' . basename( $original_file_path );
		if ( ! copy( $original_file_path, $copy_path ) || hash_file( 'sha256', $copy_path ) !== hash_file( 'sha256', $original_file_path ) ) {
			return new \WP_Error( 'modula_watermark_restore_failed', 'Could not restore the retained original.' );
		}

		update_attached_file( $image_id, $copy_path );
		$generated = $this->regenerate_watermark_metadata( $image_id, $copy_path );
		if ( is_wp_error( $generated ) ) { return $generated; }

		// Only after the clean files are in place: the watermarked ones must not stay reachable by URL.
		$cleanup = $this->delete_superseded_files( $image_id, $previous_files );

		if ( ! empty( $options['delete_backup'] ) && file_exists( $original_file_path ) ) {
			wp_delete_file( $original_file_path );
			delete_post_meta( $image_id, 'modula-backup' );
		}

		update_post_meta( $image_id, 'modula_watermark_applied', false );

		$grid_image_size = isset( $settings['grid_image_size'] ) ? $settings['grid_image_size'] : '';
		if ( 'custom' === $grid_image_size ) {
			$resizer = new \Modula_Image();
			$type    = isset( $settings['type'] ) ? $settings['type'] : 'creative-gallery';
			$dims    = isset( $settings['grid_image_dimensions'] ) && is_array( $settings['grid_image_dimensions'] )
				? $settings['grid_image_dimensions']
				: array();
			$crop    = ! empty( $settings['grid_image_crop'] );
			$sizes   = $resizer->get_image_size( $image_id, $type, $dims, $crop );

			if (
				! is_wp_error( $sizes )
				&& is_array( $sizes )
				&& ! empty( $sizes['url'] )
				&& isset( $sizes['width'], $sizes['height'] )
			) {
				$resizer->resize_image(
					$sizes['url'],
					$sizes['width'],
					$sizes['height'],
					$crop,
					'c',
					100,
					false,
					array(),
					true
				);
			}
		}

		return $cleanup;
	}

	/**
	 * Load wp-admin attachment helpers (needed for REST; already loaded on admin-ajax).
	 *
	 * @return void
	 */
	private function regenerate_watermark_metadata( $image_id, $path ) {
		$expected = array();
		$capture = static function ( $sizes ) use ( &$expected ) { $expected = $sizes; return $sizes; };
		add_filter( 'intermediate_image_sizes_advanced', $capture, PHP_INT_MAX );
		try { $metadata = wp_generate_attachment_metadata( $image_id, $path ); }
		finally { remove_filter( 'intermediate_image_sizes_advanced', $capture, PHP_INT_MAX ); }
		if ( ! is_array( $metadata ) || empty( $metadata['width'] ) || empty( $metadata['height'] ) ) { return new \WP_Error( 'modula_watermark_metadata_failed', 'Watermark bytes changed but image metadata could not be confirmed.' ); }
		wp_update_attachment_metadata( $image_id, $metadata );
		foreach ( $expected as $name => $size ) {
			$resize = image_resize_dimensions( $metadata['width'], $metadata['height'], $size['width'], $size['height'], $size['crop'] );
			if ( $resize && ( empty( $metadata['sizes'][ $name ]['file'] ) || ! is_file( dirname( get_attached_file( $image_id ) ) . '/' . $metadata['sizes'][ $name ]['file'] ) ) ) { return new \WP_Error( 'modula_watermark_derivatives_failed', 'Watermark bytes changed but some derivatives could not be confirmed.' ); }
		}
		return true;
	}

	private function ensure_attachment_admin_includes() {
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}
	}

	/**
	 * Uninstall filter
	 *
	 * @param $db_options
	 *
	 * @return mixed
	 *
	 * @since 1.0.1
	 */
	public function watermark_uninstall( $db_options ) {

		$db_options[] = 'modula-pro';

		return $db_options;
	}

	/**
	 * Add Modula Watermark data to migrator
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.2
	 */
	public function watermark_migrator_gallery_data( $modula_settings, $guest_settings, $source ) {

		if ( $source ) {
			switch ( $source ) {
				case 'envira':
					if ( isset( $guest_settings['config']['watermarking'] ) && 1 === (int) $guest_settings['config']['watermarking'] ) {
						$modula_settings['enable_watermark']          = 1;
						$modula_settings['custom_settings_watermark'] = 1;
						$modula_settings['watermark_image']           = isset( $guest_settings['config']['watermarking_image_id'] ) ? $guest_settings['config']['watermarking_image_id'] : false;
						$modula_settings['watermark_position']        = str_replace( '-', '_', $guest_settings['config']['watermarking_position'] );
						$modula_settings['watermark_margin']          = $guest_settings['config']['watermarking_margin'];
					}
					break;
			}
		}

		return $modula_settings;
	}

	/**
	 * Add debug information
	 *
	 * @param $info
	 *
	 * @return mixed
	 * @since 1.0.5
	 */
	public function debug_information( $info ) {

		$watermark_opts = get_option( 'modula-pro' );

		$info['modula_watermark_version'] = array(
			'label' => __( 'Modula Watermark Version', 'modula-pro' ),
			'value' => esc_html( \MODULA_PRO_VERSION ),
			'debug' => esC_html( 'Modula Watermark version ' . \MODULA_PRO_VERSION ),
		);

		$info['watermark_image'] = array(
			'label' => __( 'Watermark image', 'modula-pro' ),
			'value' => ( $watermark_opts && 0 !== (int) $watermark_opts['watermark_image'] ) ? __( 'Image present', 'modula-pro' ) : __( 'Image not present', 'modula-pro' ),
			'debug' => ( $watermark_opts && 0 !== (int) $watermark_opts['watermark_image'] ) ? 'Image present' : 'Image not present',
		);

		$info['watermark_position'] = array(
			'label' => __( 'Watermark position', 'modula-pro' ),
			'value' => ( $watermark_opts && '' !== $watermark_opts['watermark_position'] ) ? esc_html( $watermark_opts['watermark_position'] ) : 'No position',
			'debug' => ( $watermark_opts && '' !== $watermark_opts['watermark_position'] ) ? esc_html( $watermark_opts['watermark_position'] ) : 'No position',
		);

		$info['watermark_margin'] = array(
			'label' => __( 'Watermark margin', 'modula-pro' ),
			'value' => ( $watermark_opts && '' !== $watermark_opts['watermark_margin'] ) ? esc_html( $watermark_opts['watermark_margin'] ) : 'No margin',
			'debug' => ( $watermark_opts && '' !== $watermark_opts['watermark_margin'] ) ? esc_html( $watermark_opts['watermark_margin'] ) : 'No margin',
		);

		$info['watermark_image_dimension_height'] = array(
			'label' => __( 'Watermark image height', 'modula-pro' ),
			'value' => ( $watermark_opts && isset( $watermark_opts['watermark_image_dimension_height'] ) ) ? esc_html( $watermark_opts['watermark_image_dimension_height'] . 'px' ) : __( 'No height', 'modula-pro' ),
			'debug' => ( $watermark_opts && ! empty( $watermark_opts['watermark_image_dimension_height'] ) ) ? esc_html( $watermark_opts['watermark_image_dimension_height'] . 'px' ) : 'No height',
		);

		$info['watermark_image_dimension_width'] = array(
			'label' => __( 'Watermark image width', 'modula-pro' ),
			'value' => ( $watermark_opts && isset( $watermark_opts['watermark_image_dimension_width'] ) ) ? esc_html( $watermark_opts['watermark_image_dimension_width'] . 'px' ) : __( 'No width', 'modula-pro' ),
			'debug' => ( $watermark_opts && ! empty( $watermark_opts['watermark_image_dimension_width'] ) ) ? esc_html( $watermark_opts['watermark_image_dimension_width'] . 'px' ) : 'No width',
		);

		$info['watermark_backup'] = array(
			'label' => __( 'Watermark backup', 'modula-pro' ),
			'value' => ( $watermark_opts && isset( $watermark_opts['watermark_enable_backup'] ) && 1 === (int) $watermark_opts['watermark_enable_backup'] ) ? 'Enabled' : 'Disabled',
			'debug' => ( $watermark_opts && isset( $watermark_opts['watermark_enable_backup'] ) && 1 === (int) $watermark_opts['watermark_enable_backup'] ) ? 'Enabled' : 'Disabled',
		);

		return $info;
	}

	/**
	 * Files an attachment owns on disk, from its attached file and metadata.
	 *
	 * A big upload is served from `name-scaled.jpg` and keeps `name.jpg` as
	 * `original_image`; both count, with every sub-size.
	 *
	 * @param string|false $attached_file Absolute path of the attached file.
	 * @param array|false  $metadata      Attachment metadata.
	 * @return string[] Normalized absolute paths.
	 */
	public static function list_attachment_files( $attached_file, $metadata ) {
		if ( ! is_string( $attached_file ) || '' === $attached_file ) {
			return array();
		}

		$dir   = dirname( $attached_file ) . '/';
		$files = array( $attached_file );
		if ( ! empty( $metadata['original_image'] ) ) {
			$files[] = $dir . $metadata['original_image'];
		}
		$sizes = isset( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ? $metadata['sizes'] : array();
		foreach ( $sizes as $size ) {
			if ( ! empty( $size['file'] ) ) {
				$files[] = $dir . $size['file'];
			}
		}

		return array_values( array_unique( array_map( 'wp_normalize_path', $files ) ) );
	}

	/**
	 * Files Apply or Remove replaced: owned before, not owned now, never the backup.
	 *
	 * @param string[] $previous    list_attachment_files() before the change.
	 * @param string[] $current     list_attachment_files() after the change.
	 * @param string   $backup_path Absolute path of the backup kept for Remove, or ''.
	 * @return string[]
	 */
	public static function list_superseded_files( $previous, $current, $backup_path ) {
		$keep = '' === $backup_path ? $current : array_merge( $current, array( wp_normalize_path( $backup_path ) ) );
		return array_values( array_diff( $previous, $keep ) );
	}

	/**
	 * Files the attachment owns on disk now.
	 *
	 * @param int $image_id Attachment ID.
	 * @return string[]
	 */
	private function get_attachment_files( $image_id ) {
		return self::list_attachment_files( get_attached_file( $image_id, true ), wp_get_attachment_metadata( $image_id ) );
	}

	/**
	 * Delete the files Apply or Remove replaced, once the new files and metadata are in place.
	 *
	 * @param int      $image_id       Attachment ID.
	 * @param string[] $previous_files get_attachment_files() before the change.
	 * @return true|\WP_Error Names the files that are still on disk.
	 */
	private function delete_superseded_files( $image_id, $previous_files ) {
		$upload_dir      = wp_get_upload_dir();
		$backup_relative = get_post_meta( $image_id, 'modula-backup', true );
		$backup_path     = ( is_string( $backup_relative ) && '' !== $backup_relative && ! empty( $upload_dir['basedir'] ) )
			? $upload_dir['basedir'] . $backup_relative
			: '';

		$left = array();
		foreach ( self::list_superseded_files( $previous_files, $this->get_attachment_files( $image_id ), $backup_path ) as $path ) {
			if ( ! file_exists( $path ) ) {
				continue;
			}
			wp_delete_file( $path );
			if ( file_exists( $path ) ) {
				$left[] = basename( $path );
			}
		}

		if ( empty( $left ) ) {
			return true;
		}

		return new \WP_Error(
			'modula_watermark_cleanup_failed',
			sprintf(
				/* translators: %s: comma-separated file names. */
				esc_html__( 'The image was updated, but these replaced files could not be deleted and are still reachable by URL: %s', 'modula-pro' ),
				esc_html( implode( ', ', $left ) )
			)
		);
	}
}
