<?php
/** Explicit shared watermark file effects. Lite keeps schemas and retained-result inspection. */
namespace Modula_Pro\Extensions\Watermark\Abilities;

use Modula\V2\Abilities\Attachments;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Watermark;
use Modula\V2\Abilities\Watermark_Explanation;
use Modula\V2\Beta_Settings;
use Modula\V2\Meta_Sync;
use Modula_Pro\Extensions\Watermark\Watermark as Service;

defined( 'ABSPATH' ) || exit;

final class Watermark_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Watermark::READ === $name ) {
			return self::read( $input );
		}
		if ( in_array( $name, Watermark::mutations(), true ) ) {
			return self::execute( $input, $name );
		}
		return Watermark_Explanation::rejected( $name, $input, Watermark::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Watermark::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/**
	 * Attachments whose current read right must survive for this effect and its recovery: the target and, for APPLY, the image mark.
	 *
	 * @param array<string,mixed> $input
	 * @return array<int,int>
	 */
	public static function referenced_attachment_ids( array $input, string $operation ): array {
		$ids  = Watermark::referenced_attachment_ids( $input );
		$mark = Watermark::APPLY === $operation ? self::image_mark_id( (int) $input['id'] ) : 0;
		if ( $mark > 0 ) {
			$ids[] = $mark;
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Applying a configured image mark requires reading it, like the target attachment.
	 *
	 * @param array<string,mixed> $input
	 */
	public static function mark_readable( string $name, array $input ): bool {
		$id = $input['id'] ?? null;
		if ( Watermark::APPLY !== $name || ! is_int( $id ) ) {
			return true;
		}
		$mark = self::image_mark_id( $id );
		return $mark < 1 || Attachments::can_read( $mark );
	}

	/**
	 * Site option or gallery settings, using the stored checkbox convention.
	 * Absent, 0, "0" and "" select the site watermark option.
	 *
	 * @return array{custom:mixed,burn:array<string,mixed>}
	 */
	private static function burn_settings( int $gallery ): array {
		$settings = get_post_meta( $gallery, 'modula-settings', true );
		$settings = is_array( $settings ) ? $settings : array();
		$custom   = $settings['custom_settings_watermark'] ?? null;
		$burn     = self::checkbox_enabled( $custom ) ? $settings : get_option( 'modula_watermark', array() );
		return array(
			'custom' => $custom,
			'burn'   => is_array( $burn ) ? $burn : array(),
		);
	}

	/**
	 * Image used as the mark, or 0 for a custom text mark or an unset image.
	 */
	private static function image_mark_id( int $gallery ): int {
		$resolved = self::burn_settings( $gallery );
		return self::image_mark_from( $resolved['custom'], $resolved['burn'] );
	}

	/**
	 * @param mixed               $custom Gallery custom_settings_watermark checkbox.
	 * @param array<string,mixed> $burn
	 */
	private static function image_mark_from( $custom, array $burn ): int {
		if ( self::checkbox_enabled( $custom ) && 'text' === ( $burn['watermark_type'] ?? '' ) ) {
			return 0;
		}
		$image = $burn['watermark_image'] ?? 0;
		return is_numeric( $image ) && (int) $image > 0 ? (int) $image : 0;
	}

	/**
	 * Historical watermark checkboxes are stored as 1/"1" or left unset.
	 *
	 * @param mixed $value
	 */
	private static function checkbox_enabled( $value ): bool {
		return true === $value || 1 === $value || '1' === $value;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function read( array $input ) {
		try {
			$state = self::inspect( $input );
			// A change between the two reads means the snapshot is not stable enough to return.
			if ( $state !== self::inspect( $input ) ) {
				throw new \RuntimeException( 'inspection_changed' );
			}
			return array(
				'schema_version' => Contract::VERSION,
				'watermark'      => $state,
			);
		} catch ( \Throwable $error ) {
			$data = $error instanceof \DomainException ? array( 'reason' => $error->getMessage() ) : array();
			return new \WP_Error( 'modula_watermark_unavailable', 'A stable accessible local image in a Beta gallery is required.', $data );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$out        = static function ( $status, $code = '' ) use ( $input, $operation ) {
			return Requests::outcome( $input['request_id'], $status, $code, $code ? 'Inspect shared files and retained backup before any new request.' : '', $operation );
		};
		$referenced = self::referenced_attachment_ids( $input, $operation );
		if ( ! Watermark::can_recover(
			array(
				'target'         => $input['id'],
				'attachment_ids' => $referenced,
			)
		) ) {
			return $out( 'forbidden', 'current_permission_denied' );
		}
		// Lite records only the target attachment; recovery of an applied mark must keep requiring read access to it.
		$existing = Requests::claim( $input, $operation, array( 'attachment_ids' => $referenced ) );
		if ( null !== $existing ) {
			return $existing;
		}
		$progress = array(
			'attachment_id' => $input['attachment_id'],
			'phase'         => 'validation',
			'original'      => 'unchanged',
			'derivatives'   => 'unchanged',
		);
		$active   = false;
		$started  = false;
		try {
			Revision::begin();
			$active  = true;
			$current = self::inspect( $input, true );
			if ( ! hash_equals( $current['revision'], $input['revision'] ) ) {
				throw new \DomainException( 'stale_revision' );
			}
			if ( ! Watermark::available( $operation ) ) {
				throw new \DomainException( 'feature_unavailable' );
			}
			$guard        = self::guard_destinations( $input, $operation, $current );
			$keeps_backup = $guard['keeps_backup'];
			$backup       = $guard['backup'];
			$restore_hash = $backup ? hash_file( 'sha256', $backup ) : '';
			$progress     = array_replace(
				$progress,
				array(
					'phase'       => 'file_effect',
					'original'    => 'uncertain',
					'derivatives' => 'uncertain',
				)
			);
			// Record uncertainty only once a file write is about to start. A failed record here stays uncertain.
			$started = true;
			Requests::context( $input['request_id'], array( 'watermark' => $progress ) );
			if ( Watermark::APPLY === $operation ) {
				$result = Service::get_instance()->apply_watermark_to_image( $input['id'], $input['attachment_id'] );
			} else {
				$result = Service::get_instance()->remove_watermark_from_image( $input['id'], $input['attachment_id'] );
			}
			// Files cannot roll back. Commit metadata even when a later derivative or confirmation failed.
			Revision::end( true );
			$active = false;
			if ( is_wp_error( $result ) || true !== $result ) {
				throw new \RuntimeException( 'file_effect_unconfirmed' );
			}
			$after = self::inspect( $input );
			if ( self::effect_unconfirmed( $operation, $after, $current, $restore_hash, $keeps_backup ) ) {
				throw new \RuntimeException( 'file_effect_unconfirmed' );
			}
			$progress = array_replace(
				$after,
				array(
					'phase'       => 'completed',
					'original'    => Watermark::APPLY === $operation ? 'watermarked' : 'restored',
					'derivatives' => 'regenerated',
				)
			);
			Requests::context( $input['request_id'], array( 'watermark' => $progress ) );
			return Requests::finish( $input['request_id'], $out( 'succeeded' ) + array( 'watermark' => $progress ) );
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( $started );
			}
			if ( $started ) {
				$progress = self::observe_partial( $progress, (int) $input['attachment_id'], $current['sha256'] ?? '' );
			}
			$code   = ! $started && $error instanceof \DomainException ? $error->getMessage() : 'file_effect_unconfirmed';
			$status = self::failure_status( $started, $code );
			return Requests::finish( $input['request_id'], $out( $status, $code ) + array( 'watermark' => $progress ) );
		}
	}

	/**
	 * Refuse colliding destinations before the service writes.
	 *
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $current
	 * @return array{backup:string,keeps_backup:bool}
	 */
	private static function guard_destinations( array $input, string $operation, array $current ): array {
		$resolved     = self::burn_settings( (int) $input['id'] );
		$mark         = self::image_mark_from( $resolved['custom'], $resolved['burn'] );
		$keeps_backup = Service::get_instance()->is_backup_enabled( (int) $input['id'] );
		$needs_backup = Watermark::REMOVE === $operation || $current['applied'];
		if ( Watermark::APPLY === $operation && $mark > 0 ) {
			self::require_mark( $mark );
		}
		$backup = self::backup( (int) $input['attachment_id'] );
		if ( $needs_backup && '' === $backup ) {
			throw new \DomainException( 'backup_missing' );
		}
		$original = (string) wp_get_original_image_path( $input['attachment_id'] );
		$attached = (string) get_attached_file( $input['attachment_id'], true );
		if ( '' !== $backup && $needs_backup ) {
			self::assert_free_destination( dirname( $original ) . '/' . basename( $backup ), $original, $attached );
		}
		$info        = pathinfo( $original );
		$filename    = preg_replace( '/\.(jpe?g|png|gif|webp|heic|heif)$/i', '', $info['filename'] );
		$destination = Watermark::APPLY === $operation
			? $info['dirname'] . '/' . preg_replace( '/_w$/', '', $filename ) . '_w.' . $info['extension']
			: $info['dirname'] . '/' . basename( $backup );
		self::assert_free_destination( $destination, $original, $attached );
		if ( Watermark::APPLY === $operation && '' === $backup && $keeps_backup ) {
			self::assert_backup_destination( $input['id'], $original );
		}
		return array(
			'backup'       => $backup,
			'keeps_backup' => $keeps_backup,
		);
	}

	private static function require_mark( int $mark ): void {
		Revision::lock_attachments( array( $mark ) );
		if ( ! Attachments::can_read( $mark ) ) {
			throw new \DomainException( 'watermark_image_forbidden' );
		}
		self::paths( $mark );
	}

	private static function assert_free_destination( string $destination, string $original, string $attached ): void {
		$path = self::safe_path( $destination, false );
		if ( is_file( $path ) && $path !== $original && $path !== $attached ) {
			throw new \DomainException( 'destination_exists' );
		}
	}

	/** @param int|string $gallery */
	private static function assert_backup_destination( $gallery, string $original ): void {
		$backup_destination = wp_get_upload_dir()['basedir'] . '/modula/gallery-' . $gallery . '/' . basename( $original );
		self::safe_path( $backup_destination, false );
		if ( file_exists( $backup_destination ) ) {
			throw new \DomainException( 'backup_destination_exists' );
		}
	}

	/**
	 * @param array<string,mixed> $after
	 * @param array<string,mixed> $current
	 * @param bool                $keeps_backup Watermark::is_backup_enabled() for the gallery.
	 */
	private static function effect_unconfirmed( string $operation, array $after, array $current, string $restore_hash, bool $keeps_backup ): bool {
		if ( Watermark::REMOVE === $operation ) {
			return $after['applied'] || $after['original_sha256'] !== $restore_hash;
		}
		if ( ! $after['applied'] || $after['sha256'] === $current['sha256'] ) {
			return true;
		}
		return $keeps_backup && ! $after['backup'];
	}

	/**
	 * @param array<string,mixed> $progress
	 * @return array<string,mixed>
	 */
	private static function observe_partial( array $progress, int $attachment, string $previous_hash ): array {
		$path = get_attached_file( $attachment, true );
		if ( is_string( $path ) && is_file( $path ) ) {
			$progress['sha256']   = hash_file( 'sha256', $path );
			$progress['original'] = '' !== $previous_hash && $previous_hash !== $progress['sha256'] ? 'changed' : 'unchanged';
		}
		try {
			$progress['backup'] = '' !== self::backup( $attachment );
		} catch ( \Throwable ) {
			// Backup observation after an uncertain write must not replace the file outcome.
			return $progress;
		}
		return $progress;
	}

	/**
	 * @return string|array<int,mixed>
	 */
	private static function mark_state( int $mark, bool $lock ) {
		if ( $mark < 1 ) {
			return '';
		}
		if ( ! Attachments::can_read( $mark ) ) {
			return 'unavailable';
		}
		try {
			return array(
				Revision::document( $mark, $lock ),
				array_map(
					static function ( $path ) {
						return hash_file( 'sha256', $path );
					},
					self::paths( $mark )
				),
			);
		} catch ( \DomainException ) {
			// A missing watermark source stays unavailable and must not block backup restoration.
			return 'unavailable';
		}
	}

	private static function failure_status( bool $started, string $code ): string {
		if ( $started ) {
			return 'uncertain';
		}
		if ( 'stale_revision' === $code ) {
			return 'conflict';
		}
		return 'rejected';
	}

	/** Existing and prospective paths must remain inside uploads, without symlink ancestors. */
	private static function safe_path( string $path, bool $required = true ): string {
		$base = realpath( wp_get_upload_dir()['basedir'] );
		if ( ! $base || strpos( $path, $base . '/' ) !== 0 || strpos( $path, '..' ) !== false ) {
			throw new \DomainException( 'unsafe_file' );
		}
		$part = $path;
		while ( $part !== $base ) {
			if ( is_link( $part ) ) {
				throw new \DomainException( 'unsafe_file' );
			}
			$part = dirname( $part );
		}
		if ( $required && ( ! is_file( $path ) || ! is_readable( $path ) ) ) {
			throw new \DomainException( 'missing_file' );
		}
		return $path;
	}

	/** @return array<int,string> */
	private static function supported_mime( int $id ): bool {
		return in_array( get_post_mime_type( $id ), array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ), true );
	}

	/** Exactly 40 million pixels and 80 MiB remain allowed. An unreadable size is outside that bound. */
	private static function within_image_bounds( string $path ): bool {
		$size = wp_getimagesize( $path );
		if ( ! is_array( $size ) ) {
			return false;
		}
		$bytes = filesize( $path );
		if ( false === $bytes ) {
			return false;
		}
		return $size[0] * $size[1] <= 40000000 && $bytes <= 80 * MB_IN_BYTES;
	}

	private static function paths( int $id ): array {
		if ( ! wp_attachment_is_image( $id ) || 'trash' === get_post_status( $id ) ) {
			throw new \DomainException( 'local_image_required' );
		}
		if ( class_exists( '\WPChill\Folders\Storage\Option_Provider_Map_Repository' ) && ( new \WPChill\Folders\Storage\Option_Provider_Map_Repository() )->find_by_attachment( $id ) ) {
			throw new \DomainException( 'local_image_required' );
		}
		if ( ! self::supported_mime( $id ) ) {
			throw new \DomainException( 'unsupported_image' );
		}
		$file = self::safe_path( (string) get_attached_file( $id, true ) );
		if ( ! self::within_image_bounds( $file ) ) {
			throw new \DomainException( 'unsupported_image' );
		}
		$original = self::safe_path( (string) wp_get_original_image_path( $id ) );
		if ( ! self::within_image_bounds( $original ) ) {
			throw new \DomainException( 'unsupported_image' );
		}
		$paths = array( $file, $original );
		$meta  = wp_get_attachment_metadata( $id );
		foreach ( $meta['sizes'] ?? array() as $derivative ) {
			$paths[] = self::safe_path( dirname( $file ) . '/' . $derivative['file'] );
		}
		return array_values( array_unique( $paths ) );
	}

	private static function backup( int $id ): string {
		$relative = get_post_meta( $id, 'modula-backup', true );
		if ( ! is_string( $relative ) || '' === $relative ) {
			return '';
		}
		$path = self::safe_path( wp_get_upload_dir()['basedir'] . $relative, false );
		return is_file( $path ) ? self::safe_path( $path ) : '';
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function inspect( array $input, bool $lock = false ): array {
		$id         = $input['id'];
		$attachment = $input['attachment_id'];
		$gallery    = Revision::state( $id, $lock );
		$document   = Revision::document( $attachment, $lock );
		if ( ! Watermark::can_recover(
			array(
				'target'         => $id,
				'attachment_ids' => array( $attachment ),
			)
		) || ! Beta_Settings::is_beta_gallery( $id ) || 'trash' === get_post_status( $id ) || Watermark::is_bound_gallery( $id ) ) {
			throw new \DomainException( 'unsupported_target' );
		}
		$matches = array_filter(
			Meta_Sync::get_images_v2( $id ),
			static function ( $row ) use ( $attachment ) {
				return (string) ( $row['id'] ?? '' ) === (string) $attachment;
			}
		);
		if ( ! $matches ) {
			throw new \DomainException( 'attachment_not_in_gallery' );
		}
		$hashes = array_map(
			static function ( $path ) {
				return hash_file( 'sha256', $path );
			},
			self::paths( $attachment )
		);
		$backup = self::backup( $attachment );
		global $wpdb;
		// Authoritative snapshot: fixed option names and boolean-selected FOR UPDATE; caching would hide conflicts.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$options = $wpdb->get_results( "SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name IN ('modula_watermark','modula-pro') ORDER BY option_name" . ( $lock ? ' FOR UPDATE' : '' ), ARRAY_A );
		if ( $wpdb->last_error ) {
			throw new \RuntimeException( 'Settings inspection failed.' );
		}
		$mark       = self::image_mark_id( (int) $id );
		$mark_state = self::mark_state( $mark, $lock );
		return array(
			'attachment_id'   => $attachment,
			'revision'        => hash( 'sha256', wp_json_encode( array( $gallery, $document, $hashes, $backup ? hash_file( 'sha256', $backup ) : '', $options, $mark_state ) ) ),
			'sha256'          => $hashes[0],
			'original_sha256' => hash_file( 'sha256', wp_get_original_image_path( $attachment ) ),
			'backup'          => '' !== $backup,
			'applied'         => self::checkbox_enabled( get_post_meta( $attachment, 'modula_watermark_applied', true ) ),
			'phase'           => 'inspection',
			'original'        => 'present',
			'derivatives'     => 'present',
		);
	}
}
