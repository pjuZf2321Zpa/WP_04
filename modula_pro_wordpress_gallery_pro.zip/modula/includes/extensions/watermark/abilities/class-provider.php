<?php
/** Pro contribution for watermark inspection and shared-file effects. */
namespace Modula_Pro\Extensions\Watermark\Abilities;

use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;
use Modula\V2\Abilities\Watermark;
use Modula\V2\Abilities\Watermark_Explanation;

defined( 'ABSPATH' ) || exit;

final class Provider {
	public const ID = 'modula-pro-watermark';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! Pro_Dependency::extension_contract( 'modula-watermark' ) ) {
			return $contributions;
		}
		foreach ( Watermark::names() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Watermark_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck gallery admission and the watermark feature before any file effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		// The mark image is read access like the target attachment, so it precedes Lite's commercial blockers.
		$blockers = Watermark_Executor::mark_readable( $name, $input ) ? Watermark::explain_blockers( $name, $input ) : array( Watermark::permission_blocker() );
		if ( ! $blockers ) {
			return null;
		}
		return Watermark_Explanation::rejected( $name, $input, $blockers );
	}
}
