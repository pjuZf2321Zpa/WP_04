<?php
/**
 * Settings editor (v2) integration for Watermark action button.
 *
 * @package Modula_Pro\Extensions\Watermark
 */

namespace Modula_Pro\Extensions\Watermark\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Editor_Integration
 */
class Settings_Editor_Integration {

	/**
	 * @var string
	 */
	private $extension_url = 'includes/extensions/watermark';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'modula_settings_editor_config', array( $this, 'filter_settings_editor_config' ), 10, 2 );
		add_action( 'modula_gallery_settings_editor_enqueue', array( $this, 'enqueue' ), 10, 1 );
	}

	/**
	 * The global burn settings, for the canvas watermark preview while Override is off.
	 *
	 * @param array<string, mixed> $editor_config Localized config.
	 * @param int                  $post_id       Gallery post ID.
	 * @return array<string, mixed>
	 */
	public function filter_settings_editor_config( $editor_config, $post_id ) {
		unset( $post_id );

		$editor_config['watermarkGlobal'] = \Modula_Pro\Extensions\Watermark\Watermark::get_instance()->get_global_burn_settings();

		return $editor_config;
	}

	/**
	 * @param int $post_id Gallery post ID.
	 * @return void
	 */
	public function enqueue( $post_id ) {
		unset( $post_id );

		$asset_path = \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-watermark/index.asset.php';
		$script_url = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-watermark/index.js';
		$style_url  = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-watermark/index.css';

		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset = require $asset_path;
		$deps  = isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] )
			? $asset['dependencies']
			: array();

		if ( ! in_array( 'modula-gallery-settings-editor', $deps, true ) ) {
			$deps[] = 'modula-gallery-settings-editor';
		}

		$version = isset( $asset['version'] ) ? $asset['version'] : \MODULA_PRO_VERSION;

		wp_enqueue_script(
			'modula-settings-editor-watermark',
			$script_url,
			$deps,
			$version,
			true
		);

		if ( file_exists( \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-watermark/index.css' ) ) {
			wp_enqueue_style(
				'modula-settings-editor-watermark',
				$style_url,
				array( 'modula-gallery-settings-editor' ),
				$version
			);
		}

		wp_set_script_translations(
			'modula-settings-editor-watermark',
			'modula-pro',
			\MODULA_PRO_PATH . 'languages'
		);
	}
}
