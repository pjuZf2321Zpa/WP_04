<?php
/**
 * Settings editor (v2) integration for Content Galleries import modal.
 *
 * @package Modula_Pro\Extensions\Content_Galleries
 */

namespace Modula_Pro\Extensions\Content_Galleries\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Editor_Integration
 */
class Settings_Editor_Integration {

	/**
	 * @var string
	 */
	private $extension_url = 'includes/extensions/content-galleries';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'modula_gallery_settings_editor_enqueue', array( $this, 'enqueue' ), 10, 1 );
	}

	/**
	 * @param int $post_id Gallery post ID.
	 * @return void
	 */
	public function enqueue( $post_id ) {
		unset( $post_id );

		$asset_path = \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-content-galleries/index.asset.php';
		$script_url = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-content-galleries/index.js';
		$style_url  = \MODULA_PRO_URL . $this->extension_url . '/public/settings-editor-content-galleries/index.css';

		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset = require $asset_path;
		$deps  = isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] )
			? $asset['dependencies']
			: array();

		if ( ! in_array( 'modula-gallery-settings-editor', $deps, true ) ) {
			$deps[] = 'modula-gallery-settings-editor';
		}

		$version = isset( $asset['version'] ) ? $asset['version'] : \MODULA_PRO_VERSION;

		wp_enqueue_script(
			'modula-settings-editor-content-galleries',
			$script_url,
			$deps,
			$version,
			true
		);

		if ( file_exists( \MODULA_PRO_PATH . $this->extension_url . '/public/settings-editor-content-galleries/index.css' ) ) {
			wp_enqueue_style(
				'modula-settings-editor-content-galleries',
				$style_url,
				array( 'modula-gallery-settings-editor' ),
				$version
			);
		}

		wp_set_script_translations(
			'modula-settings-editor-content-galleries',
			'modula-pro',
			\MODULA_PRO_PATH . 'languages'
		);
	}
}
