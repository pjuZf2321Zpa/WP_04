<?php
namespace Modula_Pro\Extensions\Content_Galleries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Posts_Processing_Api {

	private static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Posts_Processing_Api ) ) {
			self::$instance = new Posts_Processing_Api();
		}
		return self::$instance;
	}

	public function query_all_posts() {

		$posts_fields = array();
		$post_types   = get_post_types( array( 'public' => true ), 'objects' );

		foreach ( $post_types as $post_type ) {
			// Exclude builtin post types and only allow posts and pages.
			if ( 'modula-gallery' !== $post_type->name && ( ! $post_type->_builtin || 'post' === $post_type->name || 'page' === $post_type->name ) ) {
				$post_fields = $this->query_post_fields( $post_type->name, true );
				if ( isset( $post_fields['success'] ) && $post_fields['success'] ) {
					$post_fields['data']['post_label'] = $post_type->labels->singular_name;
					$posts_fields[]                    = $post_fields['data'];
				}
			}
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => $posts_fields,
			),
			200
		);
	}


	public function request_post_fields( $request ) {

		$type = $request->get_param( 'type' );

		if ( ! isset( $type ) || '' === $type ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing post type.', 'modula-pro' ),
				),
				400
			);
		}

		$fields = $this->query_post_fields( $type, true );

		if ( ! isset( $fields['success'] ) || false === $fields['success'] ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => $fields['message'],
				),
				404
			);
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => $fields['data'],
			),
			200
		);
	}

	public function query_post_fields( $type, $single = false ) {

		$args = array(
			'post_type'      => $type,
			'posts_per_page' => $single ? 1 : -1,
			'order'          => 'DESC',
			'orderby'        => 'date',
		);

		$posts = get_posts( $args );

		if ( empty( $posts ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'No posts found for this post type.', 'modula-pro' ),
			);
		}

		$post = $posts[0];

		$fields = array();

		$excluded_fields = apply_filters( 'modula_content_galleries_excluded_fields', array( '_edit_last', '_edit_lock', 'nofollow', 'noopener', 'noreferrer' ), $type );

		foreach ( $posts as $post ) {
			$field = array(
				'post_id'      => $post->ID,
				'post_title'   => $post->post_title,
				'post_content' => $post->post_content,
				'post_excerpt' => $post->post_excerpt,
				'post_type'    => $post->post_type,
			);

			$post_meta = get_post_meta( $post->ID );

			if ( ! empty( $post_meta ) ) {
				foreach ( $post_meta as $key => $value ) {
					if ( in_array( $key, $excluded_fields, true ) ) {
						continue;
					}
					$field[ $key ] = $value[0];
				}
			}

			$fields[] = $field;
		}

		if ( $single && isset( $fields[0] ) ) {
			return array(
				'success' => true,
				'data'    => $fields[0],
			);
		}

		return array(
			'success' => true,
			'data'    => $fields,
		);
	}


	public function save_fields_mapping( $request ) {
		$data = $request->get_json_params();

		$gallery_id = $data['gallery_id'];
		$mapping    = $data['mappings'];
		$post_type  = $mapping['post_type'];

		if ( ! isset( $gallery_id ) || 0 === absint( $gallery_id ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing gallery ID.', 'modula-pro' ),
				),
				400
			);
		}

		if ( empty( $post_type ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing post type.', 'modula-pro' ),
				),
				400
			);
		}

		if ( empty( $mapping ) || ! is_array( $mapping ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing mapping data.', 'modula-pro' ),
				),
				400
			);
		}

		update_post_meta( $gallery_id, 'modula_content_galleries_mapping', $mapping );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Mapping saved successfully.', 'modula-pro' ),
			),
			200
		);
	}


	public function get_fields_mapping( $request ) {
		$gallery_id = $request->get_param( 'gallery_id' );

		if ( ! isset( $gallery_id ) || 0 === absint( $gallery_id ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing gallery ID.', 'modula-pro' ),
				),
				400
			);
		}

		$mappings = get_post_meta( $gallery_id, 'modula_content_galleries_mapping', true );

		if ( false === $mappings || empty( $mappings ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'No mappings were found for this gallery.', 'modula-pro' ),
				),
				200
			);
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => $mappings,
			),
			200
		);
	}

	public function query_single_post_fields( $id ) {

		if ( ! is_numeric( $id ) || $id <= 0 ) {
			return new WP_Error( 'invalid_id', __( 'Invalid post ID.', 'modula-pro' ) );
		}

		$post = get_post( $id );

		if ( empty( $post ) || is_wp_error( $post ) ) {
			return new WP_Error( 'post_not_found', __( 'Post not found.', 'modula-pro' ) );
		}

		$fields = array(
			'post_title'   => $post->post_title,
			'post_content' => $post->post_content,
			'post_excerpt' => $post->post_excerpt,
			'post_type'    => $post->post_type,
		);

		$post_meta = get_post_meta( $post->ID );

		if ( ! empty( $post_meta ) && is_array( $post_meta ) ) {
			foreach ( $post_meta as $key => $value ) {
				$fields[ $key ] = isset( $value[0] ) ? $value[0] : '';
			}
		}
		return $fields;
	}
}
