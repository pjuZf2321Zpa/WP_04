<?php
namespace Modula_Pro\Extensions\Content_Galleries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Content_Sync {
	private static $instance = null;

	private $excluded_types     = array();
	private $previous_post_meta = false;

	public function __construct() {

		if ( apply_filters( 'modula_content_galleries_prevent_sync', false ) ) {
			return;
		}

		$this->excluded_types = apply_filters(
			'modula_content_sync_excluded_post_types',
			array(
				'modula-gallery',
				'attachment',
				'revision',
				'nav_menu_item',
				'custom_css',
				'customize_changeset',
				'oembed_cache',
				'user_request',
				'wp_block',
				'wp_template',
				'wp_template_part',
			)
		);
		add_action( 'pre_post_update', array( $this, 'store_previous_post_meta' ) );

		add_action( 'wp_after_insert_post', array( $this, 'update_gallery_images' ), 999, 2 );

		add_action( 'before_delete_post', array( $this, 'remove_gallery_images' ) );
	}

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Content_Sync ) ) {
			self::$instance = new Content_Sync();
		}
		return self::$instance;
	}

	public function store_previous_post_meta( $post_id ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		$this->previous_post_meta = get_post_meta( $post_id );
	}

	public function update_gallery_images( $post_id, $post = null ) {

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		$post_type = $post ? $post->post_type : get_post_type( $post_id );

		if ( in_array( $post_type, $this->excluded_types, true ) ) {
			return;
		}

		$this->check_and_process_galleries( $post_id, $post_type, 'update' );
	}


	public function remove_gallery_images( $post_id ) {

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		$post_type = get_post_type( $post_id );

		if ( in_array( $post_type, $this->excluded_types, true ) ) {
			return;
		}

		$this->check_and_process_galleries( $post_id, $post_type, 'delete' );
	}


	public function check_and_process_galleries( $post_id, $post_type, $action ) {
		$post_processing = Posts_Processing_Api::get_instance();
		$post_fields     = $post_processing->query_single_post_fields( $post_id );

		if ( empty( $post_fields ) || is_wp_error( $post_fields ) ) {
			return;
		}

		$args = array(
			'post_type'   => 'modula-gallery',
			'numberposts' => -1,
		);

		$galleries = get_posts( $args );

		foreach ( $galleries as $gallery ) {
			$settings        = get_post_meta( $gallery->ID, 'modula-settings', true );
			$upload_position = isset( $settings['upload_position'] ) ? $settings['upload_position'] : 'end';

			if ( apply_filters( 'modula_content_galleries_prevent_gallery_sync', false, $gallery, $settings ) ) {
				continue;
			}

			$mapping = get_post_meta( $gallery->ID, 'modula_content_galleries_mapping', true );

			if ( isset( $mapping['post_type'] ) && $mapping['post_type'] === $post_type ) {
				$image                = array();
				$image['id']          = isset( $post_fields[ $mapping['image_id'] ] ) ? $post_fields[ $mapping['image_id'] ] : false;
				$image['title']       = isset( $post_fields[ $mapping['image_title'] ] ) ? $post_fields[ $mapping['image_title'] ] : false;
				$image['description'] = isset( $post_fields[ $mapping['image_caption'] ] ) ? $post_fields[ $mapping['image_caption'] ] : false;
				$image['import_url']  = isset( $mapping['import_url'] ) && (bool) $mapping['import_url'] ? get_permalink( absint( $post_id ) ) : false;

				$gallery_builder = Gallery_Builder::get_instance();

				if ( 'delete' === $action ) {
					$gallery_builder->delete_image_from_gallery( $gallery->ID, $image['id'] );
				} else {
					$old_image = isset( $this->previous_post_meta[ $mapping['image_id'] ] ) && isset( $this->previous_post_meta[ $mapping['image_id'] ][0] ) ? absint( $this->previous_post_meta[ $mapping['image_id'] ][0] ) : false;

					// Check if post image changed & delete the old image if so.
					if ( $old_image && absint( $image['id'] ) !== $old_image ) {
						$gallery_builder->delete_image_from_gallery( $gallery->ID, $old_image );
					}
					if ( false !== $image['id'] && $gallery_builder->image_exists( $image['id'] ) ) {
						$gallery_builder->add_image_to_gallery( $gallery->ID, $image, $upload_position );
					}
				}
			}
		}
	}
}
