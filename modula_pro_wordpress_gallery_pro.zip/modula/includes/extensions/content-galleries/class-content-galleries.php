<?php
namespace Modula_Pro\Extensions\Content_Galleries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Content_Galleries {
	public static $instance;
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Content_Galleries ) ) {
			self::$instance = new Content_Galleries();
		}

		return self::$instance;
	}

	public function __construct() {
		Content_Sync::get_instance();
		new Rest_Api();
		new Content_Galleries_Connector();

		if ( is_admin() ) {
			new Admin\Settings_Editor_Integration();
		}
	}
}
