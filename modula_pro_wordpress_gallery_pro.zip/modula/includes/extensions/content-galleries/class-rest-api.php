<?php
namespace Modula_Pro\Extensions\Content_Galleries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rest_Api {
	protected $namespace = 'modula-content-galleries/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {

		register_rest_route(
			$this->namespace,
			'/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( Posts_Processing_Api::get_instance(), 'query_all_posts' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/posts/(?P<type>[\w-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( Posts_Processing_Api::get_instance(), 'request_post_fields' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/mappings',
			array(
				'methods'             => 'POST',
				'callback'            => array( Posts_Processing_Api::get_instance(), 'save_fields_mapping' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/mappings/(?P<gallery_id>[\w-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( Posts_Processing_Api::get_instance(), 'get_fields_mapping' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/galleries',
			array(
				'methods'             => 'POST',
				'callback'            => array( Gallery_Builder::get_instance(), 'gallery_build_request' ),
				'permission_callback' => array( $this, '_permissions_check' ),
			)
		);
	}

	public function _permissions_check() {

		return current_user_can( 'manage_options' );
	}
}
