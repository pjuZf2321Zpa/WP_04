<?php
namespace Modula_Pro\Extensions\Content_Galleries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Gallery_Builder {

	private static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Gallery_Builder ) ) {
			self::$instance = new Gallery_Builder();
		}
		return self::$instance;
	}

	public function gallery_build_request( $request ) {
		$data = $request->get_json_params();

		$gallery_id = $data['gallery_id'];

		if ( ! isset( $gallery_id ) || 0 === absint( $gallery_id ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing gallery id.', 'modula-pro' ),
				),
				400
			);
		}

		if ( ! isset( $data['post_type'] ) || '' === $data['post_type'] ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing post type.', 'modula-pro' ),
				),
				400
			);
		}

		if ( ! isset( $data['image_id'] ) || '' === $data['image_id'] ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => esc_html__( 'Invalid or missing image id.', 'modula-pro' ),
				),
				400
			);
		}

		$mapping = array(
			'post_type'     => $data['post_type'],
			'image_id'      => $data['image_id'],
			'import_url'    => isset( $data['import_url'] ) ? $data['import_url'] : false,
			'image_title'   => isset( $data['image_title'] ) ? $data['image_title'] : '',
			'image_caption' => isset( $data['image_caption'] ) ? $data['image_caption'] : '',
			'advanced_mode' => isset( $data['advanced_mode'] ) ? $data['advanced_mode'] : false,
		);

		update_post_meta( $gallery_id, 'modula_content_galleries_mapping', $mapping );

		$processing_api = Posts_Processing_Api::get_instance();
		$posts_fields   = $processing_api->query_post_fields( $mapping['post_type'], false );

		if ( ! isset( $posts_fields['success'] ) || false === $posts_fields['success'] ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => $posts_fields['message'],
				),
				404
			);
		}

		$images    = array();
		$not_found = 0;
		$existing  = 0;
		$updated   = 0;

		$settings        = get_post_meta( $gallery_id, 'modula-settings', true );
		$upload_position = isset( $settings['upload_position'] ) ? $settings['upload_position'] : 'end';

		foreach ( $posts_fields['data'] as $post_fields ) {
			$image                = array();
			$image['id']          = isset( $post_fields[ $mapping['image_id'] ] ) ? $post_fields[ $mapping['image_id'] ] : false;
			$image['title']       = isset( $post_fields[ $mapping['image_title'] ] ) ? $post_fields[ $mapping['image_title'] ] : false;
			$image['description'] = isset( $post_fields[ $mapping['image_caption'] ] ) ? $post_fields[ $mapping['image_caption'] ] : false;
			$image['import_url']  = isset( $mapping['import_url'] ) && (bool) $mapping['import_url'] ? get_permalink( absint( $post_fields['post_id'] ) ) : false;

			if ( false === $image['id'] || ! $this->image_exists( $image['id'] ) ) {
				++$not_found;
				continue;
			}

			$new_image = $this->add_image_to_gallery( $gallery_id, $image, $upload_position );
			if ( isset( $new_image['status'] ) ) {
				if ( 'exists' === $new_image['status'] ) {
					++$existing;
				} elseif ( 'update' === $new_image['status'] ) {
					++$existing;
					++$updated;
				}
			}
			$images[] = $new_image['data'];
		}

		$message = '';

		$totals = 0;
		if ( isset( $posts_fields['data'] ) && count( $posts_fields['data'] ) > 0 ) {
			$totals = count( $posts_fields['data'] );
		}

		$imported = $totals - $not_found - $existing;

		if ( $totals <= 0 ) {
			$message = esc_html__( 'No posts to import.', 'modula-pro' );
		} elseif ( $totals > 0 && 0 === $not_found && 0 === $existing ) {
			// translators: %1$d is the total number of posts, %2$s is the singular/plural verb form, %3$s is the singular/plural form of "post"
			$message = sprintf( esc_html__( 'All %1$d %3$s %2$s imported successfully.', 'modula-pro' ), $totals, $this->get_was_were( $totals ), $this->get_post_posts( $totals ) );
		} elseif ( $not_found > 0 && 0 === $existing ) {
			// translators: %1$d is the total number of posts, %2$d is the number of successfully imported posts, %3$s is the singular/plural verb form, %4$d is the number of posts without an attached image, %5$s is the singular/plural form of "post"
			$message = sprintf( esc_html__( 'Out of %1$d %5$s, %2$d %3$s imported successfully and %4$d did not have an image attached.', 'modula-pro' ), $totals, $imported, $this->get_was_were( $imported ), $not_found, $this->get_post_posts( $totals ) );
		} elseif ( 0 === $not_found && $existing > 0 && 0 === $updated ) {
			// translators: %1$d is the total number of posts, %2$d is the number of successfully imported posts, %3$s is the singular/plural verb form, %4$d is the number of posts that already existed in the gallery, %5$s is the singular/plural form of "post"
			$message = sprintf( esc_html__( 'Out of %1$d %5$s, %2$d %3$s imported successfully and %4$d already existed in the gallery.', 'modula-pro' ), $totals, $imported, $this->get_was_were( $imported ), $existing, $this->get_post_posts( $totals ) );
		} elseif ( $not_found > 0 && $existing > 0 && 0 === $updated ) {
			// translators: %1$d is the total number of posts, %2$d is the number of successfully imported posts, %3$s is the singular/plural verb form, %4$d is the number of posts without an attached image, %5$d is the number of posts that already existed in the gallery, %6$s is the singular/plural form of "post"
			$message = sprintf( esc_html__( 'Out of %1$d %6$s, %2$d %3$s imported successfully, %4$d did not have an image attached and %5$d already existed in the gallery.', 'modula-pro' ), $totals, $imported, $this->get_was_were( $imported ), $not_found, $existing, $this->get_post_posts( $totals ) );
		} elseif ( $not_found > 0 && $existing > 0 && $updated > 0 ) {
			// translators: %1$d is the total number of posts, %2$d is the number of successfully imported posts, %3$s is the singular/plural verb form, %4$d is the number of posts without an attached image, %5$d is the number of posts that already existed in the gallery, and %6$d is the number of posts that were updated, %7$s is the singular/plural form of "post"
			$message = sprintf( esc_html__( 'Out of %1$d %7$s, %2$d %3$s imported successfully, %4$d did not have an image attached and %5$d already existed in the gallery ( of which %6$d %8$s updated ).', 'modula-pro' ), $totals, $imported, $this->get_was_were( $imported ), $not_found, $existing, $updated, $this->get_post_posts( $totals ), $this->get_was_were( $updated ) );
		} elseif ( 0 === $not_found && $existing > 0 && $updated > 0 ) {
			// translators: %1$d is the total number of posts, %2$d is the number of successfully imported posts, %3$s is the singular/plural verb form, %4$d is the number of posts that already existed in the gallery, and %5$d is the number of posts that were updated, %6$s is the singular/plural form of "post"
			$message = sprintf( esc_html__( 'Out of %1$d %6$s, %2$d %3$s imported successfully, %4$d already existed in the gallery ( of which %5$d %7$s updated ).', 'modula-pro' ), $totals, $imported, $this->get_was_were( $imported ), $existing, $updated, $this->get_post_posts( $totals ), $this->get_was_were( $updated ) );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => $images,
				'message' => $message,
			),
			200
		);
	}


	public function add_image_to_gallery( $gallery_id, $image, $upload_positioning = 'end' ) {

		$old_images = get_post_meta( $gallery_id, 'modula-images', true );
		$new_images = array();

		if ( ! is_array( $old_images ) ) {
			$old_images = array();
		}

		$image_data = $this->get_item_data( $image );

		$current_images = array_map( 'absint', array_column( $old_images, 'id' ) );
		$found_key      = array_search( absint( $image['id'] ), $current_images, true );
		$changes        = false;

		// Check if image exists in gallery.
		if ( false !== $found_key ) {
			// Image exists in gallery, check if we need to update the 'link' property.
			if ( isset( $old_images[ $found_key ] ) ) {
				if ( ( ! isset( $old_images[ $found_key ]['link'] ) && false === $image['import_url'] ) || ( isset( $old_images[ $found_key ]['link'] ) && ( empty( $old_images[ $found_key ]['link'] ) !== $image['import_url'] ? false : $old_images[ $found_key ]['link'] ) ) ) {
					$old_images[ $found_key ]['link'] = false !== $image['import_url'] ? $image['import_url'] : '';
					$changes                          = true;
				}

				if ( isset( $image_data['title'] ) && $old_images[ $found_key ]['title'] !== $image_data['title'] ) {
					$old_images[ $found_key ]['title'] = $image_data['title'];
					$changes                           = true;
				}

				if ( isset( $image_data['description'] ) && $old_images[ $found_key ]['description'] !== $image_data['description'] ) {
					$old_images[ $found_key ]['description'] = $image_data['description'];
					$changes                                 = true;
				}

				if ( $changes ) {
					update_post_meta( $gallery_id, 'modula-images', $old_images );
					return array(
						'status' => 'update',
						'data'   => $image_data,
					);
				}
			}
			return array(
				'status' => 'exists',
				'data'   => $image_data,
			);
		}

		if ( ! class_exists( 'Modula_Admin_Helpers', false ) ) {
			$helpers_file = defined( 'MODULA_PATH' )
				? \MODULA_PATH . 'includes/admin/helpers/class-modula-admin-helpers.php'
				: '';

			if ( '' === $helpers_file || ! file_exists( $helpers_file ) ) {
				return array(
					'status' => 'missing_helpers',
					'data'   => $image_data,
				);
			}

			require_once $helpers_file;
		}

		$image = \Modula_Admin_Helpers::sanitize_image( $image_data );
		$image = apply_filters( 'modula_content_galleries_add_image_to_gallery', $image );

		if ( 'start' === $upload_positioning ) {
			$old_images = array_merge( array( $image ), $old_images );
		} else {
			$old_images = array_merge( $old_images, array( $image ) );
		}

		update_post_meta( $gallery_id, 'modula-images', $old_images );

		return array(
			'status' => 'added',
			'data'   => $image_data,
		);
	}

	public function get_item_data( $image ) {
		$id           = $image['id'];
		$img_metadata = wp_get_attachment_metadata( $id );

		$new_image = array(
			'id'             => $id,
			'title'          => isset( $image['title'] ) ? wp_filter_post_kses( $image['title'] ) : '',
			'description'    => isset( $image['description'] ) ? wp_filter_post_kses( do_blocks( $image['description'] ) ) : '',
			'alt'            => '',
			'link'           => isset( $image['import_url'] ) && false !== $image['import_url'] ? $image['import_url'] : '',
			'halign'         => 'center',
			'valign'         => 'middle',
			'target'         => '',
			'togglelightbox' => '',
			'hide_title'     => '',
			'src'            => '',
			'width'          => 2,
			'height'         => 2,
			'full'           => '',
			'thumbnail'      => '',
			'resize'         => false,
			'index'          => '',
			'orientation'    => isset( $img_metadata['image_meta']['orientation'] ) && '0' === $img_metadata['image_meta']['orientation'] ? 'portrait' : 'landscape',
			'url'            => wp_get_attachment_url( $id ),
		);

		if ( isset( $img_metadata['image_meta']['mime_type'] ) && 'video/mp4' === $img_metadata['image_meta']['mime_type'] ) {
			$new_image['id']              = 'video_template_' . $id;
			$new_image['video_url']       = wp_get_attachment_url( $id );
			$new_image['video_thumbnail'] = $image['thumbnail_url'];
			$new_image['video_template']  = '1';
		}

		return $new_image;
	}

	public function image_exists( $image_id ) {
		if ( empty( $image_id ) || ! is_numeric( $image_id ) ) {
			return false;
		}

		$image_post = get_post( $image_id );

		if ( $image_post && wp_attachment_is_image( $image_id ) ) {
			return true;
		}

		return false;
	}

	public function delete_image_from_gallery( $gallery_id, $image_id ) {
		$old_images = get_post_meta( $gallery_id, 'modula-images', true );

		if ( ! is_array( $old_images ) ) {
			$old_images = array();
		}

		foreach ( $old_images as $key => $image ) {
			if ( absint( $image['id'] ) === absint( $image_id ) ) {
				unset( $old_images[ $key ] );
			}
		}
		update_post_meta( $gallery_id, 'modula-images', $old_images );
	}

	private function get_was_were( $count ) {
		return 1 === $count ? esc_html__( 'was', 'modula-pro' ) : esc_html__( 'were', 'modula-pro' );
	}

	private function get_post_posts( $count ) {
		return 1 === $count ? esc_html__( 'post', 'modula-pro' ) : esc_html__( 'posts', 'modula-pro' );
	}
}
