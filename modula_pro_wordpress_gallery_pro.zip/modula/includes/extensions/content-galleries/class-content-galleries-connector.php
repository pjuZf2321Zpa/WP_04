<?php
namespace Modula_Pro\Extensions\Content_Galleries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Content_Galleries_Connector {
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_react_apps' ) );
		add_action( 'modula_gallery_media_select_option', array( $this, 'add_media_select_button' ), 10, 2 );
	}

	/**
	 * Whether the v2 gallery takeover / settings editor owns the Add New UI.
	 *
	 * @return bool
	 */
	private function is_gallery_takeover_active() {
		return class_exists( '\Modula\V2\Admin\Gallery_Takeover_Admin' )
			&& \Modula\V2\Admin\Gallery_Takeover_Admin::should_use_takeover();
	}

	public function add_media_select_button() {
		if ( $this->is_gallery_takeover_active() ) {
			return;
		}

		echo '<li id="modula-content-galleries" data-gallery-id="' . esc_attr( get_the_ID() ) . '">' . esc_html__( 'Images from Posts', 'modula-pro' ) . '</li>';
	}

	public function enqueue_react_apps() {
		if ( $this->is_gallery_takeover_active() ) {
			return;
		}

		$current_screen = get_current_screen();
		if ( 'modula-gallery' !== $current_screen->id ) {
			return;
		}

		$asset_file = require \MODULA_PRO_PATH . 'includes/extensions/content-galleries/public/content-galleries/index.asset.php';
		$enqueue    = array(
			'handle'       => 'modula-content-galleries-connector',
			'dependencies' => $asset_file['dependencies'],
			'version'      => $asset_file['version'],
			'script'       => \MODULA_PRO_URL . 'includes/extensions/content-galleries/public/content-galleries/index.js',
			'style'        => \MODULA_PRO_URL . 'includes/extensions/content-galleries/public/content-galleries/index.css',
		);

		wp_enqueue_script(
			$enqueue['handle'],
			$enqueue['script'],
			$enqueue['dependencies'],
			$enqueue['version'],
			true
		);

		wp_enqueue_style(
			$enqueue['handle'],
			$enqueue['style'],
			array( 'wp-components' ),
			$enqueue['version']
		);
	}
}
