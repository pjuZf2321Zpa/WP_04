<?php
namespace Modula_Pro\Extensions;

/**
 * Api class for Modula Pro plugin.
 */
class Api {
	/**
	 * Class instance.
	 *
	 * @var Api
	 */
	private static $instance;

	/**
	 * Namespace for the API.
	 *
	 * @var string
	 */
	private $namespace = 'modula-pro/v1';

	/**
	 * Get the instance of the class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Api ) ) {
			self::$instance = new Api();
		}

		return self::$instance;
	}

	/**
	 * Initialize the API.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register the routes for the API.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/extensions',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_extensions' ),
				'permission_callback' => array( $this, 'get_extensions_permission' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/extension',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'toggle_extension' ),
				'permission_callback' => array( $this, 'toggle_extension_permission' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/extensions',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'toggle_extensions' ),
				'permission_callback' => array( $this, 'toggle_extension_permission' ),
			)
		);
	}

	/**
	 * Get the extensions permission.
	 */
	public function get_extensions_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Toggle the extension permission. Extensions are Pro modules, not plugins, so the gate
	 * matches the extensions list and license routes.
	 */
	public function toggle_extension_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Get the extensions.
	 */
	public function get_extensions() {
		$instance = Extensions::get_instance();

		return rest_ensure_response( $instance->get_extensions() );
	}

	/**
	 * Toggle the extension: turn it off when active, on otherwise.
	 *
	 * @param \WP_REST_Request $request Request with `extension`, a prefixed slug.
	 * @return \WP_REST_Response|\WP_Error `{success:true}`, or an error when nothing changed.
	 */
	public function toggle_extension( $request ) {
		$extension = $request->get_param( 'extension' );
		if ( ! is_string( $extension ) || '' === $extension ) {
			return $this->invalid_param( 'extension' );
		}

		// Decide the direction once, so the entitlement check covers the write that follows.
		$instance = Extensions::get_instance();
		$action   = $instance->extension_enabled( $extension ) ? 'deactivate' : 'activate';
		$refused  = $instance->get_refused_toggle_slugs( array( $extension ), 'activate' === $action );
		if ( array() !== $refused ) {
			return $this->extensions_unavailable( $refused );
		}

		$instance->toggle_active_status_of_extensions( array( $extension ), $action );

		return rest_ensure_response( array( 'success' => true ) );
	}

	/**
	 * Turn several extensions on or off.
	 *
	 * @param \WP_REST_Request $request Request with `extensions`, a list of prefixed slugs, and `status`, activate|deactivate.
	 * @return \WP_REST_Response|\WP_Error `{success:true}`, or an error when nothing changed.
	 */
	public function toggle_extensions( $request ) {
		$extensions = $this->parse_extension_slugs( $request->get_param( 'extensions' ) );
		if ( null === $extensions ) {
			return $this->invalid_param( 'extensions' );
		}

		$action = $request->get_param( 'status' );
		if ( ! in_array( $action, array( 'activate', 'deactivate' ), true ) ) {
			return $this->invalid_param( 'status' );
		}

		$instance = Extensions::get_instance();
		$refused  = $instance->get_refused_toggle_slugs( $extensions, 'activate' === $action );
		if ( array() !== $refused ) {
			return $this->extensions_unavailable( $refused );
		}

		$instance->toggle_active_status_of_extensions( $extensions, $action );

		return rest_ensure_response( array( 'success' => true ) );
	}

	/**
	 * Normalize the bulk toggle's slug list, so a repeated slug runs its hooks once.
	 *
	 * @param mixed $value Raw `extensions` parameter.
	 * @return array|null Unique slugs, or null unless the value is a non-empty list of non-empty strings.
	 */
	private function parse_extension_slugs( $value ) {
		if ( ! is_array( $value ) || array() === $value ) {
			return null;
		}

		foreach ( $value as $slug ) {
			if ( ! is_string( $slug ) || '' === $slug ) {
				return null;
			}
		}

		return array_values( array_unique( $value ) );
	}

	/**
	 * @param string $param Parameter name.
	 * @return \WP_Error
	 */
	private function invalid_param( $param ) {
		return new \WP_Error(
			'rest_invalid_param',
			/* translators: %s: request parameter name. */
			sprintf( __( 'Invalid parameter: %s.', 'modula-pro' ), $param ),
			array(
				'status' => 400,
				'param'  => $param,
			)
		);
	}

	/**
	 * @param array $slugs Refused extension slugs.
	 * @return \WP_Error
	 */
	private function extensions_unavailable( array $slugs ) {
		return new \WP_Error(
			'modula_pro_extension_unavailable',
			__( 'An extension in the request is unknown or not available on this site.', 'modula-pro' ),
			array(
				'status'     => 403,
				'extensions' => $slugs,
			)
		);
	}
}
