<?php

namespace Modula_Pro\Extensions\Fullscreen;

use Modula_Pro\Extensions\Fullscreen\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Fullscreen class for Modula Pro plugin.
 */
class Fullscreen {
	/**
	 * Holds the class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;


	/**
	 * Primary class construct
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( Settings::class, 'get_instance' ), 25 );

		add_filter( 'modula_fancybox_options', array( $this, 'modula_fullscreen_fancybox_settings' ), 35, 2 );
		add_filter( 'modula_album_template_data', array( $this, 'modula_fullscreen_albums' ), 30 );
		add_filter( 'modula_album_visitor_lightbox_fullscreen', array( $this, 'album_visitor_lightbox_fullscreen' ), 10, 2 );
		add_filter( 'modula_lite_default_settings', array( $this, 'modula_fullscreen_defaults' ) );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Fullscreen object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Fullscreen ) ) {
			self::$instance = new Fullscreen();
		}

		return self::$instance;
	}

	/**
	 * Add Fullscreen defaults settings
	 *
	 * @param $defaults
	 * @return $defaults;
	 */
	public function modula_fullscreen_defaults( $defaults ) {
		$defaults['enable_fullscreen'] = 0;
		// Opt-in only — matches admin field + v2 schema (`lightbox.openFullscreen` default false).
		$defaults['open_fullscreen']   = 0;

		return $defaults;
	}

	/**
	 * Fancybox options for gallery to add the fullscreen buttom
	 *
	 * @since 1.0.0
	 *
	 * @param $fancybox_options, $settings
	 * @return $fancybox_options
	 */
	public function modula_fullscreen_fancybox_settings( $fancybox_options, $settings ) {
		if ( self::shows_button( $settings ) ) {
			array_unshift( $fancybox_options['Toolbar']['display']['right'], 'fullscreen' );
		}
		if ( self::opens_in_fullscreen( $settings ) ) {
			$fancybox_options['Fullscreen'] = array( 'autoStart' => true );
		}

		return $fancybox_options;
	}

	/**
	 * A Beta album's lightbox (Album visitor frontend), as the classic album's
	 * (`modula_fullscreen_albums()`): the first gallery member with the
	 * fullscreen button gives the album the button, and its "Open in
	 * fullscreen".
	 *
	 * @param array{enable: bool, open: bool} $fullscreen       What the album shows so far.
	 * @param list<mixed>                     $gallery_settings The settings of each gallery member that opens the lightbox, in album order.
	 * @return array{enable: bool, open: bool}
	 */
	public function album_visitor_lightbox_fullscreen( $fullscreen, $gallery_settings ) {
		foreach ( $gallery_settings as $settings ) {
			if ( self::shows_button( $settings ) ) {
				return array(
					'enable' => true,
					'open'   => self::opens_in_fullscreen( $settings ),
				);
			}
		}

		return $fullscreen;
	}

	/**
	 * @param mixed $settings Gallery settings.
	 * @return bool Whether the gallery's lightbox shows the fullscreen button.
	 */
	private static function shows_button( $settings ) {
		return is_array( $settings ) && 1 === (int) ( $settings['enable_fullscreen'] ?? 0 );
	}

	/**
	 * @param mixed $settings Gallery settings.
	 * @return bool Whether the gallery's lightbox opens in fullscreen.
	 */
	private static function opens_in_fullscreen( $settings ) {
		return is_array( $settings ) && 1 === (int) ( $settings['open_fullscreen'] ?? 0 );
	}


	/**
	 * Setting for fullscreen button
	 *
	 * @since 1.0.0
	 *
	 * @param $template_data
	 * @return $template_data
	 */
	public function modula_fullscreen_albums( $template_data ) {
		foreach ( $template_data['galleries'] as $key => $value ) {
			$settings = get_post_meta( $value['id'], 'modula-settings', true );

			if ( self::shows_button( $settings ) && false === array_search( 'fullscreen', $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'], true ) ) {
				array_unshift( $template_data['js_config']['lightbox_settings']['Toolbar']['display']['right'], 'fullscreen' );

				if ( self::opens_in_fullscreen( $settings ) ) {
					$template_data['js_config']['lightbox_settings']['Fullscreen'] = array( 'autoStart' => true );
				}

				$template_data['album_container']['data-config'] = json_encode( $template_data['js_config'] );
				break;
			}
		}

		return $template_data;
	}
}
