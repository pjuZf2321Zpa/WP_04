<?php

namespace Modula_Pro\Extensions\Fullscreen\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main class for FullScreen Settings
 *
 * @since 1.0.0
 */
class Settings {
	/**
	 * Holds the admnin class object
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Main construct function for our class
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_fullscreen_field' ) );
	}

	/**
	 * Returns the singleton instance of the class
	 *
	 * @since 1.0.0
	 *
	 * @return object Modula_Fullscreen_Settings object
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Settings ) ) {
			self::$instance = new Settings();
		}

		return self::$instance;
	}

	/**
	 * Add fullscreen fields in settings
	 *
	 * @since 1.0.0
	 *
	 * @param $fields
	 *
	 * @return $fields
	 */
	public function modula_fullscreen_field( $fields ) {
		$fields['lightboxes']['enable_fullscreen'] = array(
			'name'      => esc_html__( 'Fullscreen button', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 0,
			'is_child'  => true,
			'priority'  => 34,
			'data_type' => 'bool',
		);
		$fields['lightboxes']['open_fullscreen']   = array(
			'name'      => esc_html__( 'Open in Fullscreen', 'modula-pro' ),
			'type'      => 'toggle',
			'default'   => 0,
			'priority'  => 95,
			'data_type' => 'bool',
		);

		if ( isset( $fields['lightboxes']['lightbox_toolbar']['children'] ) ) {
			$fields['lightboxes']['lightbox_toolbar']['children'][] = 'enable_fullscreen';
		}

		return $fields;
	}
}
