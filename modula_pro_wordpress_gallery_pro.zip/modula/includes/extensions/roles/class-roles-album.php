<?php
namespace Modula_Pro\Extensions\Roles;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class that adds the Modula Album custom capabilities.
 *
 * Roles loads it only while the Albums extension is active, so the album
 * post type uses album capabilities only with both extensions on. Turning
 * Roles off brings back the post capabilities; album capabilities stay on
 * the roles, unused.
 */
class Album_Roles {

	/**
	 * Roles option, shared with the gallery capabilities.
	 */
	const ROLES_OPTION = 'modula_roles';

	/**
	 * Suffix of a role's album entry in the roles option (`editor_album`),
	 * the shape Modula Settings stores album choices in.
	 */
	const ALBUM_ROLE_SUFFIX = '_album';

	/**
	 * Option recording the migration from post capabilities.
	 */
	const MIGRATION_OPTION = 'modula_album_roles_migrated';

	/**
	 * Current migration version.
	 */
	const MIGRATION_VERSION = '1';

	/**
	 * Every post primitive map_meta_cap can require for an album, and the
	 * album primitive that replaces it.
	 */
	const MIGRATED_CAPABILITIES = array(
		'edit_posts'             => 'edit_albums',
		'edit_others_posts'      => 'edit_others_albums',
		'edit_published_posts'   => 'edit_published_albums',
		'edit_private_posts'     => 'edit_private_albums',
		'publish_posts'          => 'publish_albums',
		'read_private_posts'     => 'read_private_albums',
		'delete_posts'           => 'delete_albums',
		'delete_others_posts'    => 'delete_others_albums',
		'delete_published_posts' => 'delete_published_albums',
		'delete_private_posts'   => 'delete_private_albums',
	);

	/**
	 * Album capabilities offered as toggles in Modula Settings › Roles.
	 */
	const CHOICE_CAPABILITIES = array(
		'edit_albums',
		'edit_others_albums',
		'publish_albums',
		'delete_albums',
		'delete_others_albums',
		'read_private_albums',
	);

	/**
	 * Holds the class object.
	 *
	 * @var Album_Roles
	 */
	private static $instance;

	/**
	 * Primitive capabilities used by Modula Albums
	 *
	 * @var array
	 * @since 1.0.4
	 */
	private $album_capabilities = array(
		'edit_posts'          => 'edit_albums',
		'delete_posts'        => 'delete_albums',
		'publish_posts'       => 'publish_albums',
		'edit_others_posts'   => 'edit_others_albums',
		'read_private_posts'  => 'read_private_albums',
		'delete_others_posts' => 'delete_others_albums',
	);

	/**
	 * Primary class constructor.
	 *
	 * @sinnce 1.0.4
	 */
	public function __construct() {

		// Albums are hierarchical, so their list rows use page_row_actions.
		add_filter( 'page_row_actions', array( $this, 'duplicate_gallery_link_removal' ), 15, 2 );
		add_filter( 'modula_album_cpt_args', array( $this, 'add_albums_capabilities' ) );
		add_filter( 'modula_roles_options_capabilities', array( $this, 'add_albums_as_addon' ) );
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_options' ), 15 );

		// Before any album capability check of the request.
		add_action( 'init', array( $this, 'maybe_migrate' ), 0 );
		add_action( 'modula_roles_role_body', array( $this, 'options_additional_capabilities' ), 20, 5 );
		add_action( 'modula_roles_sanitize_options', array( $this, 'sanitize_album_option' ) );
		add_action( 'modula_roles_plugin_activation', array( $this, 'plugin_activation' ) );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * Modula Settings builds Roles outside its singleton on save, so the
	 * album hooks must not be registered twice.
	 *
	 * @return Album_Roles
	 */
	public static function get_instance() {
		if ( ! self::$instance instanceof Album_Roles ) {
			self::$instance = new Album_Roles();
		}

		return self::$instance;
	}

	/**
	 * Add modula roles custom capabilities
	 *
	 * @param array $args Post type args.
	 *
	 * @since 1.0.4
	 */
	public function add_albums_capabilities( $args ) {

		$args['capability_type'] = array( 'album', 'albums' );
		$args['map_meta_cap']    = true;
		$args['capabilities']    = $this->album_capabilities;

		return $args;
	}

	/**
	 * Add modula roles custom capabilities
	 *
	 * @param array $addons Addons array.
	 *
	 * @since 1.0.4
	 */
	public function add_albums_as_addon( $addons ) {

		$addons['albums'] = __( 'Albums', 'modula-pro' );

		return $addons;
	}

	/**
	 * Modula Albums capabilities options.
	 *
	 * @param object $instance Modula_Roles instance.
	 * @param object $role     WP_Role instance.
	 * @param array  $wp_role  WP_Role array.
	 * @param string $key      Key.
	 *
	 * @return array
	 * @since 1.0.4
	 */
	public function options_additional_capabilities( $instance, $role, $wp_role, $key ) {
		$capabilities                         = array();
		$capabilities['edit_albums']          = __( 'View & Edit Own Albums', 'modula-pro' );
		$capabilities['edit_others_albums']   = __( 'Edit Others Albums', 'modula-pro' );
		$capabilities['publish_albums']       = __( 'Publish Albums', 'modula-pro' );
		$capabilities['delete_albums']        = __( 'Delete Own Albums', 'modula-pro' );
		$capabilities['delete_others_albums'] = __( 'Delete Others Albums', 'modula-pro' );
		$capabilities['read_private_albums']  = __( 'Edit Private Albums', 'modula-pro' );

		echo '<div class="modula-role-body" data-tab="albums">';
		foreach ( $capabilities as $capability => $capability_name ) {
			?>
			<div class="modula_roles_cap">
				<?php $instance->the_toggle_input( $capability_name, $key, $capability, $role->has_cap( $capability ) ); ?>
			</div>
			<?php
		}

		echo '</div>';

		return $capabilities;
	}

	/**
	 * Applies the saved album choices to each role's capabilities.
	 *
	 * A role whose saved value carries no album choices keeps its album
	 * capabilities as they are.
	 *
	 * @param mixed $current Current value or default.
	 *
	 * @return false|mixed
	 * @since 1.0.4
	 */
	public function sanitize_album_option( $current = false ) {
		if ( ! is_array( $current ) ) {
			return $current;
		}

		foreach ( array_keys( wp_roles()->roles ) as $key ) {
			if ( 'administrator' === $key ) {
				continue;
			}

			$choices = self::stored_album_choices( $current, $key );
			if ( null === $choices ) {
				continue;
			}

			foreach ( self::capabilities_from_choices( $choices ) as $capability => $granted ) {
				Roles_Helper::set_capability( $key, $granted, $capability );
			}
		}

		return $current;
	}

	/**
	 * Reads one role's album choices from the roles option.
	 *
	 * `{role}_album` is the current shape; album capability keys under
	 * `{role}` are the shape older Settings screens stored. A false
	 * `{role}_album.enabled` turns every album choice off.
	 *
	 * @param array  $current Roles option value.
	 * @param string $role    Role key.
	 *
	 * @return array<string, bool>|null Choice capability → granted, or null
	 *                                  when the value holds no album choices
	 *                                  for the role.
	 */
	public static function stored_album_choices( array $current, $role ) {
		$album_key = $role . self::ALBUM_ROLE_SUFFIX;

		if ( isset( $current[ $album_key ] ) && is_array( $current[ $album_key ] ) ) {
			$entry = $current[ $album_key ];
			if ( array_key_exists( 'enabled', $entry ) && ! wp_validate_boolean( $entry['enabled'] ) ) {
				return array_fill_keys( self::CHOICE_CAPABILITIES, false );
			}

			return self::choices_from_entry( $entry );
		}

		$has_legacy_choices = isset( $current[ $role ] )
			&& is_array( $current[ $role ] )
			&& array() !== array_intersect_key( $current[ $role ], array_flip( self::CHOICE_CAPABILITIES ) );
		if ( $has_legacy_choices ) {
			return self::choices_from_entry( $current[ $role ] );
		}

		return null;
	}

	/**
	 * Album capabilities a role gets from its choices.
	 *
	 * The published and private capabilities have no toggle of their own;
	 * they follow the toggles that need them.
	 *
	 * @param array<string, bool> $choices Choice capability → granted.
	 *
	 * @return array<string, bool> Album capability → granted.
	 */
	public static function capabilities_from_choices( array $choices ) {
		$can_delete = $choices['delete_albums'] || $choices['delete_others_albums'];

		$capabilities                            = $choices;
		$capabilities['edit_published_albums']   = $choices['edit_albums'] || $choices['edit_others_albums'];
		$capabilities['delete_published_albums'] = $can_delete;
		$capabilities['edit_private_albums']     = $choices['read_private_albums'];
		$capabilities['delete_private_albums']   = $choices['read_private_albums'] && $can_delete;

		return $capabilities;
	}

	/**
	 * Grants album capabilities once per site, before albums switch to the
	 * album capability type.
	 *
	 * A site that already has albums was managing them with post
	 * capabilities, so each role gets the album capabilities matching its
	 * post capabilities and nobody loses access. A fresh install has no
	 * albums and nobody to lock out, so only administrators get album
	 * capabilities, as with galleries.
	 *
	 * It only adds capabilities, so re-running after an interrupted request
	 * is safe.
	 */
	public function maybe_migrate() {
		if ( self::MIGRATION_VERSION === get_option( self::MIGRATION_OPTION ) ) {
			return;
		}

		// Without an answer, a site with albums would look fresh and lose
		// access, so try again on the next request.
		$site_has_albums = self::site_has_albums();
		if ( null === $site_has_albums ) {
			return;
		}

		foreach ( wp_roles()->roles as $key => $role_data ) {
			$grants = $site_has_albums
				? self::migration_grants( $key, $role_data['capabilities'] )
				: self::fresh_install_grants( $key );

			foreach ( $grants as $capability ) {
				Roles_Helper::set_capability( $key, true, $capability );
			}
		}

		// WordPress loads the current user before init, with the capabilities
		// its roles had then. Reload them so this request already sees the
		// album capabilities.
		$current_user = wp_get_current_user();
		if ( $current_user->exists() ) {
			$current_user->get_role_caps();
		}

		$this->sync_stored_choices();
		update_option( self::MIGRATION_OPTION, self::MIGRATION_VERSION );
	}

	/**
	 * Album capabilities a role gets on a fresh install: all of them for
	 * administrators, none for anyone else.
	 *
	 * @param string $role Role key.
	 *
	 * @return string[]
	 */
	private static function fresh_install_grants( $role ) {
		return 'administrator' === $role ? array_values( self::MIGRATED_CAPABILITIES ) : array();
	}

	/**
	 * Album capabilities a role gets from its post capabilities on a site
	 * that already has albums.
	 *
	 * @param string              $role         Role key.
	 * @param array<string, bool> $capabilities The role's capabilities.
	 *
	 * @return string[]
	 */
	public static function migration_grants( $role, array $capabilities ) {
		if ( 'administrator' === $role ) {
			return array_values( self::MIGRATED_CAPABILITIES );
		}

		$grants = array();
		foreach ( self::MIGRATED_CAPABILITIES as $post_capability => $album_capability ) {
			if ( isset( $capabilities[ $post_capability ] ) && true === (bool) $capabilities[ $post_capability ] ) {
				$grants[] = $album_capability;
			}
		}

		return $grants;
	}

	/**
	 * A role's album entry for the roles option, read from its capabilities.
	 *
	 * @param \WP_Role $role Role.
	 *
	 * @return array<string, bool> `enabled` plus each choice capability.
	 */
	public static function stored_choices_for_role( $role ) {
		$choices = array();
		foreach ( self::CHOICE_CAPABILITIES as $capability ) {
			$choices[ $capability ] = $role->has_cap( $capability );
		}

		return array( 'enabled' => in_array( true, $choices, true ) ) + $choices;
	}

	/**
	 * Set additional albums capabilities on plugin activation
	 *
	 * @since 1.0.4
	 */
	public function plugin_activation() {

		// ALBUMS
		// Add capabilities to administrator by default.
		foreach ( self::MIGRATED_CAPABILITIES as $album_capability ) {
			Roles_Helper::set_capability( 'administrator', true, $album_capability );
		}

		Roles_Helper::set_capability( 'administrator', true, 'read_album' );
		Roles_Helper::set_capability( 'administrator', true, 'edit_album' );
		Roles_Helper::set_capability( 'administrator', true, 'delete_album' );
	}

	/**
	 * Uninstall options on main plugin uninstall
	 *
	 * @param array $options DB Options array.
	 *
	 * @return array
	 */
	public function uninstall_options( $options ) {
		$options[] = self::MIGRATION_OPTION;

		return $options;
	}

	/**
	 * Remove the duplicate album link from row actions.
	 *
	 * @param array   $actions An array of row action links.
	 * @param WP_Post $post    The post object.
	 *
	 * @return array
	 * @since 1.0.4
	 */
	public function duplicate_gallery_link_removal( $actions, $post ) {

		if ( 'modula-album' !== get_post_type( $post ) ) {
			return $actions;
		}

		if ( ! current_user_can( 'edit_album', $post->ID ) ) {
			unset( $actions['duplicate_modula'] );
		}

		return $actions;
	}

	/**
	 * Rewrites the album choices in the roles option from the roles' album
	 * capabilities.
	 *
	 * Choices stored before the migration were read from capabilities nobody
	 * had, so applying them again (Roles re-activation re-applies the option)
	 * would take away migrated access. Gallery choices stay as they are.
	 */
	private function sync_stored_choices() {
		$stored = get_option( self::ROLES_OPTION );
		if ( ! is_array( $stored ) ) {
			return;
		}

		foreach ( array_keys( wp_roles()->roles ) as $key ) {
			if ( 'administrator' === $key ) {
				continue;
			}

			$stored[ $key . self::ALBUM_ROLE_SUFFIX ] = self::stored_choices_for_role( get_role( $key ) );
			if ( isset( $stored[ $key ] ) && is_array( $stored[ $key ] ) ) {
				$stored[ $key ] = array_diff_key( $stored[ $key ], array_flip( self::CHOICE_CAPABILITIES ) );
			}
		}

		// Runs on init, before Roles registers the option's sanitize callback
		// on admin_init, so this write does not re-apply capabilities.
		update_option( self::ROLES_OPTION, $stored );
	}

	/**
	 * Whether the site has any album, published or not.
	 *
	 * Queries the table directly: the migration runs on init before the
	 * album post type is registered. It runs once per site, so there is
	 * nothing to cache.
	 *
	 * @return bool|null Null when the lookup failed.
	 */
	private static function site_has_albums() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- post type not registered yet; runs once.
		$album_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status <> 'auto-draft' LIMIT 1",
				'modula-album'
			)
		);
		if ( '' !== $wpdb->last_error ) {
			return null;
		}

		return null !== $album_id;
	}

	/**
	 * Choice capabilities granted by one stored entry.
	 *
	 * @param array $entry `{role}_album` or legacy `{role}` entry.
	 *
	 * @return array<string, bool>
	 */
	private static function choices_from_entry( array $entry ) {
		$choices = array();
		foreach ( self::CHOICE_CAPABILITIES as $capability ) {
			$choices[ $capability ] = Roles_Helper::is_granted( $entry, $capability );
		}

		return $choices;
	}
}
