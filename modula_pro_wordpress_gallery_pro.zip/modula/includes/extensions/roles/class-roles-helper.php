<?php

namespace Modula_Pro\Extensions\Roles;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Roles_Helper {

	/**
	 * Set capabilities
	 *
	 * @param string $role       User role
	 * @param bool   $status     Status
	 * @param string $capability Capability
	 *
	 * @since 1.0.4 - moved from class-modula-roles.php
	 */
	public static function set_capability( $role, $status, $capability ) {
		$role = get_role( $role );
		if ( $status ) {
			$role->add_cap( $capability );
		} else {
			$role->remove_cap( $capability );
		}
	}

	/**
	 * Check whether any of the capabilities is granted in a role's choices.
	 *
	 * Reads the stored values, not the keys: Modula Settings saves every
	 * choice, unchecked ones as false.
	 *
	 * @param array $array1 A role's choices, `capability => value`.
	 * @param array $array2 Capabilities.
	 *
	 * @return bool
	 * @since 1.0.3 - moved from class-modula-roles.php
	 */
	public static function check_for_key( $array1, $array2 ) {
		foreach ( $array2 as $capability ) {
			if ( self::is_granted( $array1, $capability ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether a role's choices grant a capability.
	 *
	 * @param array  $choices    A role's choices, `capability => value`; the
	 *                           classic form stores '1', Modula Settings booleans.
	 * @param string $capability Capability.
	 *
	 * @return bool
	 */
	public static function is_granted( $choices, $capability ) {
		return isset( $choices[ $capability ] ) && wp_validate_boolean( $choices[ $capability ] );
	}

	/**
	 * Check if a role has a capability
	 *
	 * @param string $role       User role.
	 * @param string $capability Capability.
	 *
	 * @return bool
	 */
	public static function check_capability( $role, $capability ) {
		$role = get_role( $role );

		return $role->has_cap( $capability );
	}
}
