<?php
namespace Modula_Pro\Extensions\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/roles';

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'register_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	public function register_styles() {
		wp_register_style( 'modula-roles-settings', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-roles-settings.css', array(), \MODULA_PRO_VERSION );
		wp_register_script( 'modula-roles-settings', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-roles-settings.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}

	public function enqueue_styles() {
		if ( is_admin() && isset( $_GET['modula-tab'] ) && 'roles' === $_GET['modula-tab'] ) {
			wp_enqueue_style( 'modula-roles-settings' );
			wp_enqueue_script( 'modula-roles-settings' );
		}
	}
}
