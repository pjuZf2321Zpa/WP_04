<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $wp_roles;
$options = get_option( 'modula_roles' );


$capabilities = array(
	'edit_galleries'          => __( 'View & Edit Own Gallery', 'modula-pro' ),
	'edit_other_galleries'    => __( 'Edit Others Galleries', 'modula-pro' ),
	'publish_galleries'       => __( 'Publish Galleries', 'modula-pro' ),
	'delete_galleries'        => __( 'Delete Own Galleries', 'modula-pro' ),
	'delete_others_galleries' => __( 'Delete Others Galleries', 'modula-pro' ),
	'read_private_galleries'  => __( 'Edit Private Galleries', 'modula-pro' ),
);

$notification = __( 'In order for other permissions to work the role must have access to View & Edit Own Gallery.', 'modula-pro' );
?>
<form method="post" action="options.php">
	<?php settings_fields( 'modula_roles' ); ?>
	<?php echo '<span class="dashicons dashicons-info"></span>&nbsp;' . esc_html( $notification ); ?>
	<div class="modula-roles-container">
		<?php foreach ( $wp_roles->roles as $key => $wp_role ) : ?>
			<?php
			if ( 'administrator' === $key ) {
				continue;
			}
			?>
			<?php $role = get_role( $key ); ?>
			<div class="modula-role-box postbox">
				<div class="modula-role-head postbox-header">
					<span
						class="modula-role-name"><?php echo esc_html( translate_user_role( $wp_role['name'] ) ); ?></span> <?php $this->the_toggle_input( '', $key, 'enabled', $this->is_role_enabled( $key, $options ) ); ?>
				</div>
				<div class="inside">
					<?php $this->display_tabs(); ?>
					<div class="modula-role-body active" data-tab="modula">
						<?php foreach ( $capabilities as $capability => $capability_name ) : ?>
							<?php
							if ( 'edit_gallery' === $capability ) {
								continue;
							}
							?>
							<div class="modula_roles_cap">
								<?php $this->the_toggle_input( $capability_name, $key, $capability, $role->has_cap( $capability ) ); ?>
							</div>
						<?php endforeach; ?>
						<?php if ( ! in_array( $key, array( 'editor', 'author' ), true ) ) : ?>
							<div class="modula_roles_cap">
								<?php $this->the_toggle_input( __( 'Upload Files', 'modula-pro' ), $key, 'upload_files', $role->has_cap( 'upload_files' ), __( 'The user will have access to all media files. The user can upload,edit, delete, any files from media gallery.', 'modula-pro' ) ); ?>
							</div>
						<?php endif; ?>
					</div>
					<?php do_action( 'modula_roles_role_body', $this, $role, $wp_role, $key, $options ); ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php submit_button(); ?>
</form>
