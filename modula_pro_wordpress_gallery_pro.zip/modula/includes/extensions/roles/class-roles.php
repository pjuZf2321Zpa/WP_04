<?php
namespace Modula_Pro\Extensions\Roles;

use Modula_Pro\Extensions\Extensions;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Roles {
	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primitive capabilities used by Modula.
	 *
	 * @var array
	 */
	private $capabilities = array(
		'edit_posts'          => 'edit_galleries',
		'delete_posts'        => 'delete_galleries',
		'publish_posts'       => 'publish_galleries',
		'edit_others_posts'   => 'edit_other_galleries',
		'read_private_posts'  => 'read_private_galleries',
		'delete_others_posts' => 'delete_others_galleries',
	);

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ), 25 );

		add_filter( 'modula_cpt_args', array( $this, 'add_capabilities' ) );
		add_filter( 'post_row_actions', array( $this, 'delete_galleries_row_action' ), 20, 2 );
		add_filter( 'post_row_actions', array( $this, 'duplicate_gallery_link_removal' ), 15, 2 );
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_options' ), 15 );
		add_filter( 'modula_uninstall_transients', array( $this, 'uninstall_options' ), 15 );

		add_filter( 'modula_admin_page_tabs', array( $this, 'add_settings_tab' ) );
		add_action( 'modula_admin_tab_roles', array( $this, 'render_settings_tab' ) );

		add_action( 'modula_extension_modula-roles_activated', array( $this, 'plugin_activation' ) );
		new Enqueue();

		// Loaded from here, not from the extensions loader, so its hooks are
		// in place when Roles activation fires modula_roles_plugin_activation.
		if ( $this->is_albums_active() ) {
			Album_Roles::get_instance();
		}
	}

	/**
	 * @return bool Whether the Albums extension is active.
	 */
	private function is_albums_active() {
		$active_extensions = (array) Extensions::get_instance()->get_active_extensions();

		return in_array( 'modula-albums', $active_extensions, true );
	}

	/**
	 * @param $tabs
	 *
	 * @return mixed
	 *
	 * Add Modula Roles settings tab
	 */
	public function add_settings_tab( $tabs ) {

		$tabs['roles'] = array(
			'label'    => esc_html__( 'Roles', 'modula-pro' ),
			'priority' => 120,
		);

		return $tabs;
	}

	/*
	 * Add modula roles custom capabilities
	 */
	public function add_capabilities( $args ) {

		$args['capability_type'] = array( 'gallery', 'galleries' );
		$args['map_meta_cap']    = true;
		$args['capabilities']    = $this->capabilities;

		return $args;
	}

	/**
	 * Render settings tab
	 */
	public function render_settings_tab() {

		include 'tabs/roles.php';
	}

	/**
	 * Register roles settings
	 */
	public function register_settings() {
		// creates our settings in the options table
		register_setting(
			'modula_roles',
			'modula_roles',
			array(
				'sanitize_callback' => array(
					$this,
					'sanitize_option',
				),
			)
		);
	}

	/**
	 * Option sanitizer
	 *
	 * @param mixed $current Current value or default.
	 *
	 * @return false|mixed
	 */
	public function sanitize_option( $current = false ) {
		global $wp_roles;

		if ( false === $current ) {
			return $current;
		}

		foreach ( $wp_roles->roles as $key => $role ) {
			if ( 'administrator' !== $key ) {
				// We set the 'edit_galleries' cap if the role is allowed to see the gallery.
				foreach ( $this->capabilities as $capability ) {
					if ( in_array( $capability, array( 'edit_published_galleries', 'delete_published_galleries' ), true ) ) {
						continue;
					}
					if ( isset( $current[ $key ] ) && isset( $current[ $key ][ $capability ] ) ) {
						Roles_Helper::set_capability( $key, $current[ $key ][ $capability ], $capability );
					} else {
						Roles_Helper::set_capability( $key, false, $capability );
					}
				}

				if ( isset( $current[ $key ] ) && Roles_Helper::check_for_key(
					$current[ $key ],
					array(
						'edit_galleries',
						'edit_other_galleries',
					)
				) ) {
					Roles_Helper::set_capability( $key, true, 'edit_published_galleries' );
				} else {
					Roles_Helper::set_capability( $key, false, 'edit_published_galleries' );
				}

				if ( isset( $current[ $key ] ) && Roles_Helper::check_for_key(
					$current[ $key ],
					array(
						'delete_galleries',
						'delete_others_galleries',
					)
				) ) {
					Roles_Helper::set_capability( $key, true, 'delete_published_galleries' );
				} else {
					Roles_Helper::set_capability( $key, false, 'delete_published_galleries' );
				}
			}
			if ( in_array( $key, array( 'subscriber', 'contributor' ), true ) ) {
				$choices = isset( $current[ $key ] ) ? $current[ $key ] : array();
				Roles_Helper::set_capability( $key, Roles_Helper::is_granted( $choices, 'upload_files' ), 'upload_files' );
			}
		}

		/**
		 * Fires after Modula Roles options are sanitized.
		 *
		 * Hook: modula_roles_sanitize_options
		 *
		 * @hooked: sanitize_album_option - 10
		 */
		do_action( 'modula_roles_sanitize_options', $current );

		return $current;
	}

	/**
	 * Prevent plugin activation if Modula Pro is not installed and activated
	 */
	public function plugin_activation() {

		$current_version = get_option( 'modula_roles_version' );
		if ( false === $current_version || version_compare( $current_version, \MODULA_PRO_VERSION, '<' ) ) {
			delete_transient( 'modula-roles-capabilities-update' );
			update_option( 'modula_roles_version', \MODULA_PRO_VERSION );
		}

		if ( false !== get_transient( 'modula-roles-capabilities-update' ) ) {
			return;
		}

		// Add capabilities to administrator by default.
		foreach ( $this->capabilities as $capability ) {
			Roles_Helper::set_capability( 'administrator', true, $capability );
		}

		Roles_Helper::set_capability( 'administrator', true, 'read_gallery' );
		Roles_Helper::set_capability( 'administrator', true, 'edit_gallery' );
		Roles_Helper::set_capability( 'administrator', true, 'delete_gallery' );
		Roles_Helper::set_capability( 'administrator', true, 'edit_published_galleries' );
		Roles_Helper::set_capability( 'administrator', true, 'delete_published_galleries' );
		// Call this function on update so we can do backwards compatibility on previously set capabilities.
		$this->sanitize_option( get_option( 'modula_roles' ) );

		do_action( 'modula_roles_plugin_activation' );
		set_transient( 'modula-roles-capabilities-update', true, 30 * DAY_IN_SECONDS );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Roles object.
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Roles ) ) {
			self::$instance = new Roles();
		}

		return self::$instance;
	}


	public function delete_galleries_row_action( $actions, $post ) {

		if ( 'modula-gallery' === $post->post_type ) {
			$current_user = wp_get_current_user();

			if ( current_user_can( 'delete_gallery', $post->ID ) && ( absint( $post->post_author ) !== absint( $current_user->ID ) ) ) {
				if ( ! current_user_can( 'delete_others_galleries', $post->ID ) ) {
					unset( $actions['trash'] );
				}
			}
		}

		return $actions;
	}

	/**
	 * Remove the duplicate gallery link from row actions.
	 *
	 * @param array   $actions An array of row action links.
	 * @param WP_Post $post    The post object.
	 *
	 * @return array
	 * @since 1.0.3
	 */
	public function duplicate_gallery_link_removal( $actions, $post ) {

		if ( 'modula-gallery' !== get_post_type( $post ) ) {
			return $actions;
		}

		if ( ! current_user_can( 'edit_gallery', $post->ID ) ) {
			unset( $actions['duplicate_modula'] );
		}

		return $actions;
	}

	/**
	 * Adds custom Modula Roles toggle input for admin settings
	 *
	 * @param string $name    capability name
	 *
	 * @param string $key     role slug
	 *
	 * @param string $cap     capability slug
	 *
	 * @param bool   $checked
	 *
	 * @param string $tooltip tooltip for capability
	 *
	 * @return void
	 * @since 1.0.4
	 */
	public function the_toggle_input( $name, $key, $cap, $checked, $tooltip = false ) {
		?>
		<div class="modula-toggle">
			<label class="">
				<span class="toggle-name"><?php echo esc_html( $name ); ?></span>
				<input class="modula-toggle__input" type="checkbox"
						name="modula_roles[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( $cap ); ?>]"
						value="1" <?php checked( $checked ); ?>/>
				<div class="modula-toggle__items">
					<span class="modula-toggle__track"></span>
					<span class="modula-toggle__thumb"></span>
					<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true"
						role="img"
						focusable="false"
						viewBox="0 0 6 6">
						<path
							d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path>
					</svg>
					<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true"
						role="img"
						focusable="false"
						viewBox="0 0 2 6">
						<path d="M0 0h2v6H0z"></path>
					</svg>
				</div>
			</label>
			<?php if ( $tooltip ) : ?>
				<div class="modula-roles-tooltip"><span>[?]</span>
					<div class="modula-roles-tooltip-content"><?php echo esc_html( $tooltip ); ?></div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Backwards compatibility returns the boolean value of main toggle.
	 *
	 * @param string $key     role slug
	 *
	 * @param array  $options options array
	 *
	 * @return bool
	 * @since 1.0.4
	 */
	public function is_role_enabled( $key, $options ) {
		if ( ! isset( $options[ $key ]['enabled'] ) ) {
			// This means the options belong to an older Modula Roles with no ['enabled'] option.
			$role = get_role( $key );
			foreach ( $this->capabilities as $cap ) {
				if ( $role->has_cap( $cap ) ) {
					// This means a previous cap was added so return true.
					return true;
				}
			}
		} elseif ( isset( $options[ $key ]['enabled'] ) && '1' === $options[ $key ]['enabled'] ) {
			return true;
		}

		return false;
	}

	/**
	 * Display tabs for Modula Roles settings
	 *
	 * @return void
	 * @since 1.0.4
	 */
	public function display_tabs() {
		/**
		 * Filter to add more tabs to Modula Roles settings
		 *
		 * Hook: modula_roles_options_capabilities
		 *
		 * @hooked: add_albums_as_addon - 10
		 */
		$addons = apply_filters( 'modula_roles_options_capabilities', array() );
		if ( 0 === count( $addons ) ) {
			return;
		}
		?>
		<ul class="modula-roles-tab-list">
			<li class="modula-roles-tab-item active" data-item="modula"> <?php esc_html_e( 'Modula', 'modula-pro' ); ?></li>
			<?php foreach ( $addons as $key => $addon ) : ?>
				<li class="modula-roles-tab-item"
					data-item="<?php echo esc_attr( $key ); ?>"> <?php echo esc_html( $addon ); ?></li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/**
	 * Uninstall options on main plugin uninstall
	 *
	 * @param array $options DB Options array.
	 *
	 * @return array
	 * @since 1.0.4
	 */
	public function uninstall_options( $options ) {
		$options[] = 'modula_roles_version';

		return $options;
	}

	/**
	 * Uninstall transients on main plugin uninstall
	 *
	 * @param array $transients DB transients array.
	 *
	 * @return array
	 * @since 1.0.4
	 */
	public function uninstall_transients( $transients ) {
		$transients[] = 'modula-roles-capabilities-update';

		return $transients;
	}
}
