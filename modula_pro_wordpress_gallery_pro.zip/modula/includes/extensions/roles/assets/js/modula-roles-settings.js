jQuery( document ).ready( function () {
	// On page load check
	jQuery( '.modula-roles-container .modula-role-box' ).each( function () {
		check_role_enabled( this );
	} );

	// On toggle check
	jQuery( '.modula-role-head input[type=checkbox]' ).click( function () {
		toggle_role_enabled( jQuery( this ).parents( '.modula-role-box' ) );
	} );

	// tabs navigation
	jQuery( '.modula-roles-tab-list .modula-roles-tab-item' ).click(
		function () {
			navigate_tab( this );
		}
	);
} );

function check_role_enabled( box ) {
	const input = jQuery( box ).find(
		'.modula-role-head input[type=checkbox]'
	);
	( enabled = jQuery( input ).prop( 'checked' ) ),
		( body = jQuery( box ).find( '.modula-role-body' ) );
	inputs = jQuery( box ).find( '.modula-role-body .modula_roles_cap' );
	tabs = jQuery( box ).find( '.modula-roles-tab-list' );

	if ( enabled ) {
		body.css( 'opacity', '1' );
		tabs.removeClass( 'disabled' );
		jQuery( inputs ).each( function () {
			jQuery( this )
				.find( 'input[type=checkbox]' )
				.prop( 'disabled', false );
		} );
	} else {
		body.css( 'opacity', '0.5' );
		tabs.addClass( 'disabled' );
		jQuery( inputs ).each( function () {
			jQuery( this )
				.find( 'input[type=checkbox]' )
				.prop( 'disabled', true );
		} );
	}
}

function toggle_role_enabled( box ) {
	const input = jQuery( box ).find(
		'.modula-role-head input[type=checkbox]'
	);
	( enabled = jQuery( input ).prop( 'checked' ) ),
		( body = jQuery( box ).find( '.modula-role-body' ) );
	inputs = jQuery( box ).find( '.modula-role-body .modula_roles_cap' );
	tabs = jQuery( box ).find( '.modula-roles-tab-list' );

	if ( enabled ) {
		body.css( 'opacity', '1' );
		tabs.removeClass( 'disabled' );
		jQuery( inputs ).each( function () {
			jQuery( this )
				.find( 'input[type=checkbox]' )
				.prop( 'disabled', false )
				.prop( 'checked', true );
		} );
	} else {
		body.css( 'opacity', '0.5' );
		tabs.addClass( 'disabled' );
		jQuery( inputs ).each( function () {
			jQuery( this )
				.find( 'input[type=checkbox]' )
				.prop( 'checked', false )
				.prop( 'disabled', true );
		} );
	}
}

function navigate_tab( el ) {
	parent = jQuery( el ).parents( '.modula-role-box' );
	disabled = jQuery( parent )
		.find( '.modula-roles-tab-list' )
		.hasClass( 'disabled' );

	if ( disabled ) {
		return;
	}

	selected = jQuery( el ).data( 'item' );

	// 1. Remove active class from tabs
	parent.find( '.modula-roles-tab-item.active' ).removeClass( 'active' );

	// 2. Remove active class from body
	parent.find( '.modula-role-body.active' ).removeClass( 'active' );

	// 3. Add active class to selected tab
	jQuery( el ).addClass( 'active' );

	// 4. Add active class to selected body
	parent
		.find( ".modula-role-body[data-tab='" + selected + "']" )
		.addClass( 'active' );
}
