jQuery( document ).on(
	'modula_gallery_type_check',
	function ( event, backbone, location, type ) {
		if ( 'slider' == type ) {
			// If resizeble is enable we will destroy it
			if ( backbone.isResizeble ) {
				backbone.disableResizeble();
			}

			// If sortable is not enabled, we will initialize it.
			if ( ! backbone.isSortable ) {
				backbone.enableSortable();
			}

			if ( 'undefined' !== typeof backbone.helperGrid ) {
				backbone.helperGrid.hide();
			}

			if ( 'undefined' !== typeof backbone.container ) {
				backbone.container
					.removeClass( 'modula-custom-grid' )
					.addClass( 'modula-creative-gallery' );

				backbone.container.sortable( {
					items: '.modula-single-image',
					cursor: 'move',
					forcePlaceholderSize: true,
					placeholder: 'modula-single-image-placeholder',
					stop( event, ui ) {
						const itemsIDs =
							backbone.container.sortable( 'toArray' );
						itemsIDs.forEach( function ( itemID, i ) {
							const id = '#' + itemID;
							jQuery( id ).trigger( 'modula:updateIndex', {
								index: i,
							} );
						} );
					},
				} );
			}

			backbone.$el.removeClass( 'modula-resizer-enabled' );
		}
	}
);
