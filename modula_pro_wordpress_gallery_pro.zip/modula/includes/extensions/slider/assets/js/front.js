if ( 'undefined' === typeof window.modulacheckDevice ) {
	window.modulacheckDevice = function ( opts ) {
		if ( 'undefined' !== typeof opts ) {
			let devices = true;
			if (
				'undefined' !== typeof opts.lightbox_devices &&
				'both' !== opts.lightbox_devices
			) {
				if ( 'mobile' === opts.lightbox_devices ) {
					devices = 1024 > jQuery( window ).width();
				} else {
					devices = 1024 < jQuery( window ).width();
				}
			}
			return devices;
		}
		return false;
	};
}

( function ( $ ) {
	'use strict';

	$( document ).ready( function () {
		initModulaCarousel( $( '.modula-slider' ) );
	} );

	//Divi builder fix - init sliders after modula galery finised building the html.
	$( document ).on( 'modula_api_after_init', () => {
		initModulaCarousel( $( '.modula-slider' ) );
	} );

	$( document ).on( 'elementor/popup/show', ( event, id, instance ) => {
		initModulaCarousel(
			$( '#elementor-popup-modal-' + id ).find( '.modula-slider' )
		);
	} );

	function initModulaCarousel( modulaSliders ) {
		if ( modulaSliders.length > 0 ) {
			$.each( modulaSliders, function () {
				if ( $( this ).data( 'modula-carousel-initialized' ) ) {
					return;
				}
				$( this ).data( 'modula-carousel-initialized', true );

				const self = this,
					modulaID = $( this ).attr( 'id' ),
					config = $( this ).data( 'config' ),
					nav = $( this ).find( '.modula-carousel-nav' ),
					main = $( this ).find( '.modula-items' );

				const options = {
					...config.slider_settings,
					fill: true,
					Thumbs: false,
				};

				const plugins = {};

				/*
				 * Use Pro ModulaCarousel (carousel.umd.js), not Lite Fancybox's
				 * window.Carousel — attaching Pro Autoplay to Fancybox Carousel
				 * collapses multi-slide layout (FreeScout #50960).
				 */
				if (
					'undefined' !== typeof options.MSplugins &&
					'undefined' !== typeof options.MSplugins.Autoplay &&
					options.MSplugins.Autoplay &&
					'undefined' !== typeof Autoplay
				) {
					plugins.Autoplay = Autoplay;
				}

				if (
					'undefined' !== typeof options.Autoplay &&
					options.Autoplay
				) {
					options.Autoplay.progressParentEl = ( ref ) => {
						if (
							'undefined' !== typeof options.Dots &&
							options.Dots
						) {
							return ref.instance.container.querySelector(
								'.f-carousel__dots .is-current .f-carousel__dot'
							);
						}
						return ref.instance.container;
					};
				}

				// Define opts.on so we can add events to it.
				options.on = {};

				// Create a custom trigger for each fancybox event.
				options.on[ '*' ] = function ( fancybox, eventName ) {
					// replace . from event name with _ and set custom event.
					jQuery( document ).trigger(
						'modula_slider_' + eventName.replace( /\./g, '_' ),
						[ fancybox, this ]
					);
				};

				// Slide pause on hover event
				options.on[ 'ready change' ] = function (
					fancybox,
					eventName
				) {
					$( self ).trigger( 'afterChange', [
						fancybox,
						config,
						this,
					] );

					// Compatibility with Modula Video - pauses videos after swipe.
					const slides = fancybox.slides;
					$.each( slides, function ( index, slide ) {
						const initial = slides[ index ].el,
							initial_player = $( initial ).find(
								'.modula_video_preview_element'
							)[ 0 ],
							icon = $( initial ).find( '.modula-video-icon' ),
							iframe = $( initial ).find( 'iframe, video' );
						if ( $( slide.el ).hasClass( 'is-selected' ) ) {
							// On 'Auto' nav image size, scale thumbnail navigation viewport based on slide img width.
							if (
								( 'undefined' !== typeof options.navSize &&
									'auto' === options.navSize ) ||
								( 'undefined' !== typeof options.snapSlides &&
									'auto' === options.snapSlides )
							) {
								let imgObj = $( slide.el ).find(
										'img.pic, picture.pic img'
									),
									vidObj = $( slide.el ).find(
										'.video-sizer'
									),
									navWidth = false;

								// Check if we have an image, else it may be a video
								if ( 0 != imgObj.length ) {
									navWidth = imgObj.attr( 'width' ) + 'px';
								} else if ( 0 != vidObj.length ) {
									navWidth = vidObj.width() + 'px';
								} else {
									navWidth = '100%';
								}

								if (
									'undefined' !== typeof options.navSize &&
									'auto' === options.navSize &&
									'undefined' !== typeof ModulaNavCarousel
								) {
									$( ModulaNavCarousel.container ).css(
										'width',
										navWidth
									);
								}

								if (
									'undefined' !== typeof options.snapSlides &&
									'auto' === options.snapSlides &&
									1 === options.slidesToShow
								) {
									$( fancybox.container )
										.parent()
										.css( 'width', navWidth );
								}
							}

							// Start the player(s) on swipe/next
							if ( 'undefined' !== typeof initial_player ) {
								if ( modulaVideoPreview.duration > 0 ) {
									if (
										'undefined' !==
										typeof window.modulaVideoWatchtime[
											index
										]
									) {
										clearInterval(
											window.modulaVideoWatchtime[ index ]
										);
									}

									// Track Watchtime
									window.modulaVideoWatchtime[ index ] =
										setInterval( async function () {
											initial_player.load();
											// Wait for Vimeo play now to prevent interruption by calls to pause
											await initial_player.play();
										}, modulaVideoPreview.duration * 1000 );
								}
								if (
									'undefined' !==
										typeof $( initial_player ).data(
											'autothumb'
										) &&
									'1' ==
										$( initial_player ).data( 'autothumb' )
								) {
									icon.hide();
									initial_player.play();
								}
							}
						} else {
							// Stop the previous playing video in slider.
							if ( 'undefined' !== typeof iframe ) {
								iframe.attr( 'src', iframe.attr( 'src' ) );
							}

							// Stop the previous player
							if ( 'undefined' !== typeof initial_player ) {
								clearInterval(
									window.modulaVideoWatchtime[ index ]
								);
								// Resets video element & it's poster if any.
								initial_player.load();
								initial_player.pause();
							}
						}
					} );
				};

				options.on.init = function ( fancybox ) {
					jQuery( document ).trigger(
						'modula_fancybox_lightbox_on_init',
						[ fancybox, this ]
					);
				};

				const mainCarousel = new ModulaCarousel(
					main[ 0 ],
					options,
					plugins
				);

				if ( nav.length ) {
					const navConfig = nav.data( 'config' );
					const navOptions = {
						...navConfig,
						infinite: false,
						fill: true,
						slidesPerPage: 1,
						dragFree: true,
						Dots: false,
						direction: options.direction, // import direction from main slider
						Sync: {
							target: mainCarousel, // main slider as Sync target for nav
						},
						center:
							'undefined' !== typeof options.navSlides &&
							options.navSlides % 2 !== 0,
						classes: {
							container: 'f-carousel',
							viewport: 'f-carousel__viewport',
							track: 'f-carousel__track',
							slide: 'modula-slider-nav-item',
							isLTR: 'is-ltr',
							isRTL: 'is-rtl',
							isHorizontal: 'is-horizontal',
							isVertical: 'is-vertical',
							inTransition: 'in-transition',
							isSelected: 'is-selected',
						},
						Navigation: false,
					};

					var ModulaNavCarousel = new ModulaCarousel(
						nav[ 0 ],
						navOptions
					);
				}

				// Lightbox functionality
				if ( 'fancybox' === config.lightbox ) {
					if (
						'undefined' === typeof config.lightboxOpts &&
						'undefined' !== typeof config.lightbox_settings
					) {
						config.lightboxOpts = config.lightbox_settings;
						delete config.lightbox_settings;
					}

					main.on(
						'click',
						'.modula-item-link:not( .modula-simple-link )',
						function ( e ) {
							e.preventDefault();

							const slides = main.find( '.f-carousel__track' ),
								items = slides
									.find( '.modula-item' )
									.filter( ':not( .modula-simple-link )' ),
								links = jQuery.map( items, function ( o ) {
									const link =
											jQuery( o ).find(
												'.modula-item-link'
											),
										image = jQuery( o ).find( '.pic' );

									var image_link = image.data( 'full' );
									if ( typeof image_link === 'undefined' ) {
										var image_link = image.attr( 'src' );
									}

									if ( link.length > 0 ) {
										return {
											src: image_link,
											opts: {
												caption: link.data( 'caption' ),
												alt: image.attr( 'alt' ),
												thumb: link.attr(
													'data-thumb'
												),
												$thumb: image.parents(
													'.modula-item'
												),
												image_id:
													link.attr(
														'data-image-id'
													),
											},
										};
									}
								} );

							const index = items.index(
								jQuery( this ).parents( '.modula-item' )
							);

							config.lightboxOpts.beforeLoad = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_before_load',
									[ main, this ]
								);
							};
							config.lightboxOpts.afterLoad = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_after_load',
									[ main, this ]
								);
							};
							config.lightboxOpts.beforeShow = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_before_show',
									[ main, this ]
								);
							};
							config.lightboxOpts.afterShow = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_after_show',
									[ main, this ]
								);
							};
							config.lightboxOpts.beforeClose = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_before_close',
									[ main, this ]
								);
							};
							config.lightboxOpts.afterClose = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_after_close',
									[ main, this ]
								);
							};
							config.lightboxOpts.onInit = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_on_init',
									[ main, this ]
								);
							};
							config.lightboxOpts.onActivate = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_on_activate',
									[ main, this ]
								);
							};
							config.lightboxOpts.onDeactivate = function () {
								jQuery( document ).trigger(
									'modula_fancybox_lightbox_on_deactivate',
									[ main, this ]
								);
							};

							if ( modulacheckDevice( config ) ) {
								jQuery.modulaFancybox.open(
									links,
									config.lightboxOpts,
									index
								);
							}
						}
					);

					main.on(
						'click',
						'.gallery-link:not(.simple-link)',
						function ( evt ) {
							evt.preventDefault();
							if ( modulacheckDevice( config ) ) {
								const images =
									$( this ).data( 'gallery-images' );
								jQuery.modulaFancybox.open(
									images,
									config.lightboxOpts
								);
							}
						}
					);
				}

				$( this ).trigger( 'init', [ mainCarousel, config, this ] );
			} );
		}
	}
} )( jQuery );
