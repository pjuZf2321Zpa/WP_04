jQuery( function ( $ ) {
	if ( 'undefined' !== typeof elementorFrontend.hooks ) {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/modula_elementor_gallery.default',
			function ( $scope ) {
				const modulaSliders = $scope.find( '.modula-slider' );
				if ( modulaSliders.length > 0 ) {
					$.each( modulaSliders, function () {
						const config = $( this ).data( 'config' ),
							nav = $( this ).find( '.modula-carousel-nav' ),
							main = $( this ).find( '.modula-items' );

						const options = {
							...config.slider_settings,
							fill: true,
							Thumbs: false,
						};
						const MC = new ModulaCarousel( main[ 0 ], options );

						if ( nav.length ) {
							const navConfig = nav.data( 'config' );

							const navOptions = {
								...navConfig,
								infinite: false,
								transition: false,
								center: false,
								fill: true,
								slidesPerPage: 1,
								dragFree: true,
								Dots: false,
								direction: options.direction, // import direction from main slider
								Sync: {
									target: MC, // aci dam caruselul principal ca target pentru nav
								},
								classes: {
									container: 'f-carousel',
									viewport: 'f-carousel__viewport',
									track: 'f-carousel__track',
									slide: 'modula-slider-nav-item',
									isLTR: 'is-ltr',
									isRTL: 'is-rtl',
									isHorizontal: 'is-horizontal',
									isVertical: 'is-vertical',
									inTransition: 'in-transition',
									isSelected: 'is-selected',
								},
								Thumbs: {
									type: 'modern',
								},
							};
							new ModulaCarousel( nav[ 0 ], navOptions );
						}
					} );
				}
			}
		);

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/modula_albums_elementor.default',
			function ( $scope ) {
				const modulaSliders = $scope.find( '.modula-slider' );
				if ( modulaSliders.length > 0 ) {
					$.each( modulaSliders, function () {
						const config = $( this ).data( 'config' ),
							nav = $( this ).find( '.modula-carousel-nav' ),
							main = $( this ).find( '.modula-items' );

						const options = {
							...config.slider_settings,
							fill: true,
							Thumbs: false,
						};
						const MC = new ModulaCarousel( main[ 0 ], options );

						if ( nav.length ) {
							const navConfig = nav.data( 'config' );

							const navOptions = {
								...navConfig,
								infinite: false,
								transition: false,
								center: false,
								fill: true,
								slidesPerPage: 1,
								dragFree: true,
								Dots: false,
								direction: options.direction, // import direction from main slider
								Sync: {
									target: MC, // aci dam caruselul principal ca target pentru nav
								},
								classes: {
									container: 'f-carousel',
									viewport: 'f-carousel__viewport',
									track: 'f-carousel__track',
									slide: 'modula-slider-nav-item',
									isLTR: 'is-ltr',
									isRTL: 'is-rtl',
									isHorizontal: 'is-horizontal',
									isVertical: 'is-vertical',
									inTransition: 'in-transition',
									isSelected: 'is-selected',
								},
								Thumbs: {
									type: 'modern',
								},
							};
							new ModulaCarousel( nav[ 0 ], navOptions );
						}
					} );
				}
			}
		);
	}

	jQuery( window ).on( 'elementor/frontend/init', () => {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/modula_elementor_gallery.default',
			function ( $scope ) {
				const modulaSliders = $scope.find( '.modula-slider' );
				if ( modulaSliders.length > 0 ) {
					$.each( modulaSliders, function () {
						const config = $( this ).data( 'config' ),
							nav = $( this ).find( '.modula-carousel-nav' ),
							main = $( this ).find( '.modula-items' );

						const options = {
							...config.slider_settings,
							fill: true,
							Thumbs: false,
						};
						const MC = new ModulaCarousel( main[ 0 ], options );

						if ( nav.length ) {
							const navConfig = nav.data( 'config' );
							const navOptions = {
								...navConfig,
								infinite: false,
								transition: false,
								center: false,
								fill: true,
								slidesPerPage: 1,
								dragFree: true,
								Dots: false,
								direction: options.direction, // import direction from main slider
								Sync: {
									target: MC, // aci dam caruselul principal ca target pentru nav
								},
								classes: {
									container: 'f-carousel',
									viewport: 'f-carousel__viewport',
									track: 'f-carousel__track',
									slide: 'modula-slider-nav-item',
									isLTR: 'is-ltr',
									isRTL: 'is-rtl',
									isHorizontal: 'is-horizontal',
									isVertical: 'is-vertical',
									inTransition: 'in-transition',
									isSelected: 'is-selected',
								},
								Thumbs: {
									type: 'modern',
								},
							};
							new ModulaCarousel( nav[ 0 ], navOptions );
						}
					} );
				}
			}
		);
	} );
} );
