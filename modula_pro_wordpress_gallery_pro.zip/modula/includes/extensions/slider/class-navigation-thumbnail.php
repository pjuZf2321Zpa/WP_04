<?php
namespace Modula_Pro\Extensions\Slider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Navigation files are independent of the main slide and download sources. */
final class Navigation_Thumbnail {
	public static function resolve( $image, $settings ) {
		$filter = 'modula_slider_thumbnail_src';
		$id = is_numeric( $image['id'] ?? null ) ? absint( $image['id'] ) : 0;
		$poster = $image['video_thumbnail'] ?? '';
		if ( $poster ) {
			$id = attachment_url_to_postid( $poster );
		}
		$full = $id ? wp_get_attachment_image_src( $id, 'full' ) : false;
		if ( ! $full ) {
			return array(
				'src'    => apply_filters( $filter, $poster, $image, $settings ),
				'srcset' => '',
				'width'  => 0,
				'height' => 0,
				'source' => 'external',
			);
		}
		$image['id'] = $id;
		$size = $settings['slider_syncing_nav_size'] ?? 'auto';
		if ( 'custom' === $size ) {
			$custom = self::custom( $full, $image, $settings, $filter );
			if ( $custom ) {
				return $custom;
			}
		}
		$meta = wp_get_attachment_metadata( $id );
		$src = null;
		if ( ! in_array( $size, array( 'auto', '', 'custom' ), true ) ) {
			$src = wp_get_attachment_image_src( $id, $size );
			// A missing named derivative also falls back through the available natural-aspect files.
			if ( 'full' !== $size && ( ! $src || ! $src[3] ) ) {
				$src = null;
			}
		}
		if ( ! $src ) {
			$candidates = array();
			foreach ( ( $meta['sizes'] ?? array() ) as $name => $dimensions ) {
				if ( wp_image_matches_ratio( $full[1], $full[2], $dimensions['width'], $dimensions['height'] ) ) {
					$candidate = wp_get_attachment_image_src( $id, $name );
					if ( $candidate && $candidate[3] ) {
						$candidates[] = $candidate;
					}
				}
			}
			usort(
				$candidates,
				static function ( $a, $b ) {
					return $a[1] <=> $b[1];
				}
			);
			$src = $full;
			foreach ( $candidates as $candidate ) {
				$src = $candidate;
				if ( $candidate[1] >= 300 ) {
					break;
				}
			}
		}
		// WordPress matches srcset candidates by ratio, not crop origin. A named
		// crop must keep its chosen composition even when another same-ratio file exists.
		$natural_aspect = wp_image_matches_ratio( $full[1], $full[2], $src[1], $src[2] );
		$srcset = 'full' !== $size && $natural_aspect ? wp_calculate_image_srcset( array( $src[1], $src[2] ), $src[0], $meta, $id ) : '';
		// Run every responsive URL through the existing hook, including Image Guardian.
		$filtered = array();
		foreach ( explode( ', ', $srcset ?: '' ) as $candidate ) {
			if ( preg_match( '/^(.*) (\d+w)$/', $candidate, $match ) ) {
				$url = apply_filters( $filter, $match[1], $image, $settings );
				if ( $url ) {
					$filtered[] = $url . ' ' . $match[2];
				}
			}
		}
		return array(
			'src' => apply_filters( $filter, $src[0], $image, $settings ),
			'srcset' => implode( ', ', $filtered ),
			'width' => $src[1],
			'height' => $src[2],
			'source' => $src[3] ? 'derivative' : ( 'full' === $size ? 'explicit-full' : 'original-fallback' ),
		);
	}

	private static function custom( $full, $image, $settings, $filter ) {
		$width = absint( $settings['slider_syncing_nav_image_dimensions']['width'] ?? 0 );
		$height = absint( $settings['slider_syncing_nav_image_dimensions']['height'] ?? 0 );
		$crop = ! empty( $settings['slider_syncing_nav_image_crop'] );
		$resizer = new \Modula_Image();
		$sources = array();
		foreach ( array( 1, 2 ) as $scale ) {
			$result = $resizer->resize_image( $full[0], $width * $scale, $height * $scale, $crop );
			$url = is_array( $result ) ? ( $result['resized_url'] ?? '' ) : $result;
			if ( is_string( $url ) && $url && $url !== $full[0] ) {
				$dimensions = image_resize_dimensions( $full[1], $full[2], $width * $scale, $height * $scale, $crop );
				if ( $dimensions ) {
					$sources[] = array( apply_filters( $filter, $url, $image, $settings ), $dimensions[4], $dimensions[5] );
				}
			}
		}
		if ( ! $sources ) {
			// Invalid dimensions, missing local files or unavailable resizer: use a real available file.
			return null;
		}
		return array(
			'src' => $sources[0][0],
			'width' => $sources[0][1],
			'height' => $sources[0][2],
			'srcset' => implode(
				', ',
				array_map(
					static function ( $source ) {
						return $source[0] . ' ' . $source[1] . 'w';
					},
					$sources
				)
			),
			'source' => 'custom',
			'customKey' => $width . 'x' . $height . ':' . ( $crop ? '1' : '0' ),
		);
	}

}
