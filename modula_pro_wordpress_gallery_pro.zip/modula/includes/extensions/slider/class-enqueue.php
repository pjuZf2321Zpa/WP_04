<?php
namespace Modula_Pro\Extensions\Slider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/slider';

	public function __construct() {
		// Register Slider Scripts.
		add_action( 'wp_enqueue_scripts', array( $this, 'register_slider_scripts' ) );

		// Elementor Scripts and Styles actions.
		add_action( 'modula_elementor_before_enqueue_elementor-preview', array( $this, 'modula_slider_elementor_scripts' ) );
		add_action( 'modula_elementor_before_enqueue_styles', array( $this, 'modula_slider_elementor_styles' ) );

		// Filter Modula slider Scripts & Styles.
		add_filter( 'modula_necessary_scripts', array( $this, 'modula_slider_scripts' ), 15, 2 );
		add_filter( 'modula_necessary_styles', array( $this, 'modula_slider_styles' ), 15, 2 );

		// Enqueue Modula slider Scripts & Styles for Divi pagebuilder.
		add_action( 'modula_divi_builder_sripts_after_modula', array( $this, 'modula_divi_builder_slider_scripts' ) );

		// Model output css.
		add_filter( 'modula_shortcode_css', array( $this, 'modula_slider_output_css' ), 17, 3 );

		// Enqueue block assets.
		add_action( 'modula_block_style', array( $this, 'enqueue_modula_block_styles' ) );
		add_action( 'modula_block_scripts', array( $this, 'enqueue_modula_block_scripts' ) );

		// Add admin scripts.
		add_action( 'admin_init', array( $this, 'add_admin_scripts' ), 25 );
	}

	public function add_admin_scripts() {
		// Enqueue admin required scripts
		add_action( 'modula_scripts_before_wp_modula', array( $this, 'modula_slider_admin_scripts' ), 1 );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'modula_slider_admin_scripts' ), 40 );
	}

	/**
	 * Enqueue slider elementor scripts
	 */

	public function modula_slider_elementor_scripts() {
		wp_enqueue_script( 'modula-slider-carousel-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/carousel.umd.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-slider-elementor', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-slider-elementor.js', array(), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Enqueue slider elementor styles
	 */

	public function modula_slider_elementor_styles() {
		wp_enqueue_style( 'modula-slider-css' );
		wp_enqueue_style( 'modula-slider-carousel-autoplay-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/carousel.autoplay.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Enqueue slider styles & scripts for Divi builder.
	 *
	 * @return void
	 */
	public function modula_divi_builder_slider_scripts() {
		wp_enqueue_script( 'modula-pro' );
		wp_enqueue_script( 'modula-slider-script' );
		wp_enqueue_style( 'modula-slider-css' );
	}


	/**
	 * Enqueue slider styles
	 *
	 * @param $styles
	 * @param $settings
	 * @return array
	 */
	public function modula_slider_styles( $styles, $settings ) {

		if ( 'slider' === $settings['type'] ) {
			$styles[] = 'modula-slider-css';

			if (
				( isset( $settings['slider_syncing'] ) && 1 === absint( $settings['slider_syncing'] ) )
				|| ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) )
			) {
				$styles[] = 'modula-slider-carousel-autoplay-css';
			}
		}

		return $styles;
	}
	/**
	 * Enqueue slider scripts
	 *
	 * @param $scripts
	 * @param $settings
	 *
	 * @return array
	 */
	public function modula_slider_scripts( $scripts, $settings ) {

		$scripts[] = 'modula-slider-script';
		$scripts[] = 'modula-slider-carousel-script';

		$scripts[] = 'modula-pro';

		if ( 'slider' === $settings['type'] ) {
			$scripts[] = 'modula-fancybox';
			if ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) ) {
				$scripts[] = 'modula-slider-carousel-autoplay-script';
			}

			$excludes = array( 'modula', 'modula-isotope', 'modula-isotope-packery' );
			foreach ( $scripts as $key => $script ) {
				if ( in_array( $script, $excludes, true ) ) {
					unset( $scripts[ $key ] );
				}
			}
		}
		return $scripts;
	}
	/**
	 * Register slider scripts and styles
	 */
	public function register_slider_scripts() {
		// Register Slider script
		wp_register_script( 'modula-slider-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/front.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_style( 'modula-slider-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/front.min.css', array(), \MODULA_PRO_VERSION );

		// Register Slider carousel autoplay script
		wp_register_script( 'modula-slider-carousel-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/carousel.umd.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-slider-carousel-autoplay-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/carousel.autoplay.umd.js', array( 'jquery', 'modula-slider-carousel-script' ), \MODULA_PRO_VERSION, true );
		wp_register_style( 'modula-slider-carousel-autoplay-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/carousel.autoplay.css', array(), \MODULA_PRO_VERSION );
	}


	/**
	 * Enqueue admin Modula Slider scripts
	 */
	public function modula_slider_admin_scripts() {
		wp_enqueue_script( 'modula-slider-conditions', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-slider-conditions.js', array( 'modula-conditions', 'modula-pro-conditions' ), MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-slider-settings', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-slider.js', array(), MODULA_PRO_VERSION, true );
	}

	public function enqueue_modula_block_styles() {
		wp_enqueue_style( 'modula-slider-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/front.min.css', array(), \MODULA_PRO_VERSION );
		wp_enqueue_style( 'modula-slider-css' );
		wp_enqueue_style( 'modula-slider-carousel-autoplay-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/carousel.autoplay.css', array(), \MODULA_PRO_VERSION );
	}

	public function enqueue_modula_block_scripts() {
		wp_enqueue_script( 'modula-slider-carousel-script', \MODULA_PRO_URL . $this->extension_url . '/assets/js/carousel.umd.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}

		/**
	 * We need to overwrite the height but still display the correct css
	 *
	 * @param $css
	 * @param $gallery_id
	 * @param $settings
	 * @return mixed
	 */
	public function modula_slider_output_css( $css, $gallery_id, $settings ) {

		if ( 'slider' !== $settings['type'] ) {
			return $css;
		}
		$width = ( ! empty( $settings['width'] ) && 'auto' !== strtolower( $settings['width'] ) ) ? $settings['width'] : '100%';
		$css  .= "#{$gallery_id}.modula-slider { max-width: calc( {$width} - 44px ); margin: 0 auto; }";
		$css  .= "#{$gallery_id}.modula-slider .modula-item .video-sizer iframe { min-width:100% }";

		// set the height to auto
		$css .= "#{$gallery_id} .modula-items{height:auto}";
		// remove the hover background color
		$css .= "#{$gallery_id} .modula-item{background-color:transparent}";
		// remove loading effects
		$css .= "#{$gallery_id} .modula-item{transform:none;}";
		// remove hover opacity on image
		$css .= "#{$gallery_id} .modula-item:hover img{opacity:1;}";

		$css .= "#{$gallery_id} .slider-clickable { position:relative;width:max-content;margin:0 auto;max-width:100%; }#{$gallery_id} .slider-clickable .modula-item-link, #{$gallery_id}  .slider-clickable .modula-simple-link { position:absolute; width:100%; height:100%; cursor:pointer; z-index:999;}";

		// If center mode is on, calculate margins & slides to show.
		if ( isset( $settings['slider_centerMode'] ) && 1 === absint( $settings['slider_centerMode'] ) ) {
			$css .= "#{$gallery_id} .modula-items.f-carousel{--f-carousel-slide-width: calc( ( 100% / " . absint( $settings['slider_slidesToShow'] ) . ' ) - ' . absint( $settings['slider_centerPadding'] ) . 'px - ' . absint( $settings['gutter'] ) * ( absint( $settings['slider_slidesToShow'] ) + 1 ) . 'px );--f-carousel-spacing: ' . absint( $settings['gutter'] ) . 'px;}';
			if ( 1 < absint( $settings['slider_slidesToShow'] ) ) {
				$css .= "html body #{$gallery_id}.modula-slider .modula-items .modula-video-content{width: calc( ( 100% / " . absint( $settings['slider_slidesToShow'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px); }';
			} else {
				$css .= "html body #{$gallery_id}.modula-slider .modula-items .modula-video-content{width: calc( 100% / " . absint( $settings['slider_slidesToShow'] ) . '); }';
			}
		} elseif ( 1 < absint( $settings['slider_slidesToShow'] ) ) {
				$css .= "#{$gallery_id} .modula-items.f-carousel{--f-carousel-slide-width: calc( ( 100% - ( ( " . absint( $settings['slider_slidesToShow'] ) . ' - 1 ) * ' . absint( $settings['gutter'] ) . 'px ) ) / ' . absint( $settings['slider_slidesToShow'] ) . ' );--f-carousel-spacing: ' . absint( $settings['gutter'] ) . 'px;}';
				$css .= "html body #{$gallery_id}.modula-slider .modula-items .modula-video-content{width: calc( ( 100% / " . absint( $settings['slider_slidesToShow'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px); }';
		} else {
			$css .= "#{$gallery_id} .modula-items.f-carousel{--f-carousel-slide-width: 100%;--f-carousel-spacing: 0;}";
			$css .= "html body #{$gallery_id}.modula-slider .modula-items .modula-video-content{width: calc( 100% / " . absint( $settings['slider_slidesToShow'] ) . '); }';
		}

		if ( isset( $settings['enable_responsive'] ) && 1 === absint( $settings['enable_responsive'] ) ) {
			$css .= "@media (max-width: 1024px) { 
				#{$gallery_id} .modula-items.f-carousel{
					--f-carousel-slide-width: calc( ( 100% / " . absint( $settings['slider_tablet_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
					--f-carousel-spacing: ' . absint( $settings['gutter'] ) . "px;
				}
				html body #{$gallery_id}.modula-slider .modula-items .modula-video-content{
					width: calc( ( 100% / " . absint( $settings['slider_tablet_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
				}
			}';
			$css .= "@media (max-width: 600px) { 
				#{$gallery_id} .modula-items.f-carousel{
					--f-carousel-slide-width: calc( ( 100% / " . absint( $settings['slider_mobile_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
					--f-carousel-spacing: ' . absint( $settings['gutter'] ) . "px;
				}
				html body #{$gallery_id}.modula-slider .modula-items .modula-video-content{
					width: calc( ( 100% / " . absint( $settings['slider_mobile_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
				}
			}';
		}

		// Slider dimensions for video
		$real_sizes = self::get_real_sizes( $settings );
		$min_height = esc_attr( '50vh' );
		if ( 0 === absint( $real_sizes['width'] ) ) {
			$width  = esc_attr( '100%' );
			$height = 'auto';
		} else {
			$min_height = esc_attr( 'auto' );
			$width      = absint( $real_sizes['width'] ) . 'px';
			$height     = ( ( absint( $real_sizes['width'] ) / 16 ) * 9 ) . 'px';
		}

		$css .= "#{$gallery_id} .modula-items .f-carousel__track .modula-item .video-sizer { width:" . $width . '; max-width:100%;margin:0 auto;}';

		if ( 'auto' !== $height ) {
			$css .= "#{$gallery_id} .modula-items .f-carousel__track .modula-item .video-sizer iframe, #{$gallery_id}  .modula-items .f-carousel__track .modula-item .video-sizer video { max-height:" . $height . '!important;max-height:100vh;min-height:' . $min_height . ' }';
		}

		if ( ! isset( $settings['hide_title'] ) || 1 !== absint( $settings['hide_title'] ) ) {
			$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .jtg-title {margin-bottom:0px;}";

			if ( '' !== $settings['titleColor'] ) {
				$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .jtg-title {";
				$css .= 'color:' . \Modula_Helper::sanitize_rgba_colour( $settings['titleColor'] ) . ';';
				$css .= '}';
			}

			if ( '' !== $settings['titleFontSize'] && 0 !== absint( $settings['titleFontSize'] ) ) {
				$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .jtg-title {";
				$css .= 'font-size:' . absint( $settings['titleFontSize'] ) . 'px;';
				$css .= '}';
			}

			// Settings for font family caption and title
			if ( isset( $settings['titleFontFamily'] ) && 'Default' !== $settings['titleFontFamily'] ) {
				$css .= "#{$gallery_id} .jtg-title{ font-family:" . esc_attr( $settings['titleFontFamily'] ) . '; }';
			}

			// Settings for Title Font Weight
			if ( 'default' !== $settings['titleFontWeight'] ) {
				$css .= "#{$gallery_id} .jtg-title {font-weight:" . esc_attr( $settings['titleFontWeight'] ) . '; }';
			}

			if ( '' !== $settings['mobileTitleFontSize'] && 0 !== absint( $settings['mobileTitleFontSize'] ) ) {
				$css .= "@media all and (max-width:600px){#{$gallery_id}.modula-slider .modula-items .slider-image-info .description {";
				$css .= 'font-size:' . absint( $settings['mobileCaptionFontSize'] ) . 'px;';
				$css .= '}}';
			}
		}

		if ( ! isset( $settings['hide_description'] ) || 1 !== absint( $settings['hide_description'] ) ) {
			$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .description {margin-bottom:0px;}";

			if ( '' !== $settings['captionColor'] ) {
				$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .description {";
				$css .= 'color:' . \Modula_Helper::sanitize_rgba_colour( $settings['captionColor'] ) . ';';
				$css .= '}';
			}

			if ( '' !== $settings['captionFontSize'] && 0 !== absint( $settings['captionFontSize'] ) ) {
				$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .description {";
				$css .= 'font-size:' . absint( $settings['captionFontSize'] ) . 'px;';
				$css .= '}';
			}

			// Settings for font family caption and title
			if ( isset( $settings['captionsFontFamily'] ) && 'Default' !== $settings['captionsFontFamily'] ) {
				$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .description{ font-family:" . esc_attr( $settings['captionsFontFamily'] ) . '; }';
			}

			// Settings for Captions Font Weight
			if ( 'default' !== $settings['captionFontWeight'] ) {
				$css .= "#{$gallery_id}.modula-slider .modula-items .slider-image-info .description{font-weight:" . esc_attr( $settings['captionFontWeight'] ) . '; }';
			}

			if ( '' !== $settings['mobileCaptionFontSize'] && 0 !== absint( $settings['mobileCaptionFontSize'] ) ) {
				$css .= "@media all and (max-width:600px){#{$gallery_id}.modula-slider .modula-items .slider-image-info .description {";
				$css .= 'font-size:' . absint( $settings['mobileCaptionFontSize'] ) . 'px;';
				$css .= '}}';
			}
		}

		if ( isset( $settings['slider_syncing_nav_thumbnails_border_color'] ) ) {
			$css .= '#' . $gallery_id . '.modula-slider .modula-carousel-nav .modula-slider-nav-item.is-nav-selected img.modula-slider-nav-image{border: 2px solid ' . \Modula_Helper::sanitize_rgba_colour( $settings['slider_syncing_nav_thumbnails_border_color'] ) . '}';
			$css .= '#' . $gallery_id . '.modula-slider .modula-carousel-nav .modula-slider-nav-item.is-nav-selected picture.modula-slider-nav-image img{border: 2px solid ' . \Modula_Helper::sanitize_rgba_colour( $settings['slider_syncing_nav_thumbnails_border_color'] ) . '}';
		}

		if ( isset( $settings['slider_adaptiveHeight'] ) && $settings['slider_adaptiveHeight'] ) {
			$css .= "#{$gallery_id} .modula-items .f-carousel__track { align-items:flex-start }";
		}

		if ( isset( $settings['slider_speed'] ) && 0 !== $settings['slider_speed'] ) {
			$speed_ms = (int) $settings['slider_speed'];

			$css .= "#{$gallery_id} { --f-transition-duration: {$speed_ms}ms !important; }";
		}

		if ( isset( $settings['slider_syncing'] ) && 1 === absint( $settings['slider_syncing'] ) ) {
			$gutter        = isset( $settings['gutter'] ) ? absint( $settings['gutter'] ) : 10;
			$tablet_gutter = isset( $settings['tablet_gutter'] ) ? absint( $settings['tablet_gutter'] ) : $gutter;
			$mobile_gutter = isset( $settings['mobile_gutter'] ) ? absint( $settings['mobile_gutter'] ) : $gutter;
			$css          .= "#{$gallery_id} .modula-carousel-nav.f-carousel {margin-top: " . $gutter . 'px;}';
			$css          .= "@media screen and (max-width: 992px) {#{$gallery_id} .modula-carousel-nav.f-carousel {margin-top: " . $tablet_gutter . 'px;}}';
			$css          .= "@media screen and (max-width: 768px) {#{$gallery_id} .modula-carousel-nav.f-carousel {margin-top: " . $mobile_gutter . 'px;}}';
			if ( isset( $settings['slider_syncing'] ) ) {
				if ( 'auto' === $settings['slider_syncing_nav_size'] ) {
					$css .= "#{$gallery_id} .modula-slider-nav-item img.modula-slider-nav-image { aspect-ratio: 16 / 9; object-fit: cover;}";
					$css .= "#{$gallery_id} .modula-slider-nav-item picture.modula-slider-nav-image img{ aspect-ratio: 16 / 9; object-fit: cover;}";
				} else {
					$image_sizes = \Modula_Helper::get_image_sizes();
					if ( isset( $image_sizes[ $settings['slider_syncing_nav_size'] ] ) && is_array( $image_sizes[ $settings['slider_syncing_nav_size'] ] ) ) {
						$image_size = $image_sizes[ $settings['slider_syncing_nav_size'] ];
						$css       .= "#{$gallery_id} .modula-slider-nav-item img.modula-slider-nav-image { aspect-ratio: " . $image_size['width'] . ' / ' . $image_size['height'] . '; object-fit: cover;}';
						$css       .= "#{$gallery_id} .modula-slider-nav-item picture.modula-slider-nav-image img{ aspect-ratio: 16 / 9; object-fit: cover;}";
					} else {
						$css .= "#{$gallery_id} .modula-slider-nav-item img.modula-slider-nav-image { aspect-ratio: 1; object-fit: cover;}";
						$css .= "#{$gallery_id} .modula-slider-nav-item picture.modula-slider-nav-image img{ aspect-ratio: 1; object-fit: cover;}";
					}
				}
			}
		}

		if ( isset( $settings['slider_arrows_inside'] ) && boolval( $settings['slider_arrows_inside'] ) ) {
			$css .= "#{$gallery_id}.modula-slider .modula-items.f-carousel { --f-arrow-pos: 12px; --f-button-next-pos: 10px; --f-button-prev-pos: 10px; }";
		}

		if ( isset( $settings['show-video-icon'] ) && $settings['show-video-icon'] ) {
			$css .= ".modula-lightbox-{$gallery_id} .fancybox__thumbs .f-thumbs__slide.for-video .modula-video-icon {  position: absolute; width: 30px;top: 50%;left: 50%;transform: translate(-50%,-50%); }";

			if ( isset( $settings['video-icon-color'] ) && '#ffffff' !== $settings['video-icon-color'] ) {
				$css .= ".modula-lightbox-{$gallery_id} .fancybox__thumbs .f-thumbs__slide.for-video .modula-video-icon path { fill : " . \Modula_Helper::sanitize_rgba_colour( $settings['video-icon-color'] ) . ' }';
			}
		}

		return $css;
	}

	public static function get_real_sizes( $settings ) {

		if ( ! is_array( $settings ) || empty( $settings ) || 'full' === $settings['slider_image_size'] ) {
			$size = array(
				'width'  => 0,
				'height' => 0,
			);
			return $size;
		}

		if ( 'custom' !== $settings['slider_image_size'] ) {
			$size = \Modula_Helper::get_image_sizes()[ $settings['slider_image_size'] ];
		} else {
			$size = $settings['slider_image_dimensions'];
		}

		return $size;
	}
}
