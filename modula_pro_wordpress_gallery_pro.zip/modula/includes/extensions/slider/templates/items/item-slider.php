<div class="<?php echo esc_attr( implode( ' ', $data->item_classes ) ); ?>" <?php echo \Modula_Helper::generate_attributes( $data->item_attributes ); ?>>

	<?php if ( 'no-link' !== $data->lightbox && isset( $data->is_custom_url ) ) : ?>
	<div class="slider-clickable">
		<?php endif ?>

		<?php do_action( 'modula_slider_item_before_link', $data ); ?>

		<?php if ( 'no-link' !== $data->lightbox ) : ?>
			<a<?php echo \Modula_Helper::generate_attributes( $data->link_attributes ); ?>
					class="<?php echo esc_attr( implode( ' ', $data->link_classes ) ); ?>"></a>
		<?php endif ?>

		<?php do_action( 'modula_slider_item_after_link', $data ); ?>

		<div class="modula-slider-image-wrapper">
			<?php do_action( 'modula_slider_item_before_image', $data ); ?>

			<?php if ( ! isset( $data->is_video ) || false === $data->is_video ) : ?>
				<?php
				/**
				 *Hook : modula_item_template_image
				* @hooked: modula_sources_and_sizes
				*/
				do_action( 'modula_item_template_image', $data );
				?>

			<?php endif ?>
			
			<?php do_action( 'modula_slider_item_after_image', $data ); ?>
		</div>
		<?php if ( 'no-link' !== $data->lightbox && isset( $data->is_custom_url ) ) : ?>
	</div>
<?php endif ?>
</div>
