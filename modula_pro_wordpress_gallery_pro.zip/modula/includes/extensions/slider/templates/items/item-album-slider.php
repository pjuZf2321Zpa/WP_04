<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div <?php echo \Modula_Helper::generate_attributes( $data->item_attributes ); ?> >
	<div class="modula-item-overlay"></div>

	<div class="modula-item-content">

		<?php do_action( 'modula_album_item_before_link', $data ); ?>

		<a <?php echo \Modula_Helper::generate_attributes( $data->link_attributes ); ?>></a>

		<?php do_action( 'modula_album_item_after_link', $data ); ?>

		<div class="modula-slider-image-wrapper">

		<?php do_action( 'modula_album_item_before_image', $data ); ?>

		<?php

		$image = '<img ' . \Modula_Helper::generate_attributes( $data->img_attributes ) . '/>';

		$image_meta = wp_get_attachment_metadata( $data->img_attributes['data-image-id'] );
		$first_size = reset( $image_meta['sizes'] );
		$mimetype   = $first_size['mime-type'];

		if ( ! empty( $data->image_info ) ) {
			$image_meta['sizes']['custom'] = array(
				'file'      => $data->image_info['name'] . '-' . $data->image_info['suffix'] . '.' . $data->image_info['ext'],
				'width'     => $data->img_attributes['width'],
				'height'    => $data->img_attributes['height'],
				'mime-type' => $mimetype,
			);
		}
		if ( false === $data->remove_srcset ) {
			echo wp_image_add_srcset_and_sizes( $image, $image_meta, $data->img_attributes['data-image-id'] );
		} else {
			echo $image;
		}

		do_action( 'modula_album_item_after_image', $data );
		?>
		</div>
	</div>
</div>
