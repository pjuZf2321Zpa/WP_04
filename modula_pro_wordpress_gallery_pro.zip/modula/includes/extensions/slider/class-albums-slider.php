<?php
namespace Modula_Pro\Extensions\Slider;

use Modula_Pro\Extensions\Extensions;
use Modula_Pro\Extensions\Slider\Slider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *
 */
class Albums_Slider {

	/**
	 * Holds the class object.
	 *
	 * @since 1.1.2
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.1.2
	 */
	private function __construct() {
		new Enqueue();

		// Filter Modula slider Scripts & Styles.
		add_filter( 'modula_album_necessary_scripts', array( $this, 'modula_slider_scripts' ), 15, 2 );
		add_filter( 'modula_album_necessary_styles', array( $this, 'modula_slider_styles' ), 15, 2 );

		add_action( 'admin_init', array( $this, 'set_admin_requirements' ), 25 );

		// Add defaults.
		add_filter( 'modula_album_default_settings', array( $this, 'set_defaults' ) );

		add_filter( 'modula_album_template_data', array( $this, 'modula_album_gallery_classes' ), 40 );

		// Add new classe for each item and add lightbox_slider option to lightbox.
		add_filter( 'modula_album_shortcode_item_data', array( $this, 'modula_album_slider_item_data' ), 90, 4 );

		// Model output css.
		add_filter( 'modula_album_shortcode_css', array( $this, 'modula_album_slider_output_css' ), 17, 3 );

		// Add slider settings to js config.
		add_filter( 'modula_album_js_config', array( $this, 'js_slider_config' ), 999, 2 );

		// Add action for slider syncing.
		add_action( 'modula_album_shortcode_after_items', array( $this, 'modula_slider_syncing' ), 85, 3 );

		// Add new path for templates.
		add_filter( 'modula-albums_template_paths', array( $this, 'add_modula_slider_templates_path' ), 20 );

		// Enqueue block assets.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_modula_block_styles' ) );

		add_action( 'modula_effects_with_title', array( $this, 'slider_effect_info' ) );
		add_action( 'modula_effects_with_description', array( $this, 'slider_effect_info' ) );

		add_filter( 'modula_album_item_before_image', array( $this, 'add_caption_title_top' ) );
		add_filter( 'modula_album_item_after_image', array( $this, 'add_caption_title_bottom' ) );
	}

	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.1.2
	 */
	public function set_admin_requirements() {

		$extensions = Extensions::get_instance();

		if ( $extensions && ! $extensions->is_upgradable_addon( 'modula-slider' ) ) {
			add_filter( 'modula_album_fields', array( $this, 'modula_album_slider_gallery_type' ), 15, 1 );

			add_action( 'modula_album_scripts_before_wp_modula', array( $this, 'modula_slider_admin_scripts' ), 1 );
			add_action(
				'modula_album_defaults_scripts_after_wp_modula',
				array(
					$this,
					'modula_slider_admin_scripts',
				),
				40
			);
		}
	}

	/**
	 * Enqueue admin Modula Slider scripts
	 *
	 * @since 1.1.2
	 */
	public function modula_slider_admin_scripts() {
		wp_enqueue_script( 'modula-albums-slider-conditions', \MODULA_PRO_URL . 'includes/extensions/slider/assets/js/modula-slider-albums-conditions.js', array(), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-slider-settings', \MODULA_PRO_URL . 'includes/extensions/slider/assets/js/wp-modula-slider.js', array(), \MODULA_PRO_VERSION, true );
	}


	/**
	 * Enqueue slider scripts
	 *
	 * @param array $scripts Array of scripts.
	 * @param array $settings Array of settings.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function modula_slider_scripts( $scripts, $settings ) {

		if ( isset( $settings['album_type'] ) && 'slider' === $settings['album_type'] ) {
			$scripts[] = 'modula-slider-script';
			$scripts[] = 'modula-slider-carousel-script';

			if ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) ) {
				$scripts[] = 'modula-slider-carousel-autoplay-script';
			}
		}

		return $scripts;
	}

	/**
	 * Add extra path for modula templates
	 *
	 * @param array $paths Array of paths.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function add_modula_slider_templates_path( $paths ) {

		$paths[60] = trailingslashit( \MODULA_PRO_PATH ) . 'includes/extensions/slider/templates';

		return $paths;
	}

	/**
	 * Enqueue slider styles
	 *
	 * @param array $styles Array of styles.
	 * @param array $settings Array of settings.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function modula_slider_styles( $styles, $settings ) {

		if ( isset( $settings['album_type'] ) && 'slider' === $settings['album_type'] ) {
			$styles[] = 'modula-slider-css';

			if (
				( isset( $settings['slider_syncing'] ) && 1 === absint( $settings['slider_syncing'] ) )
				|| ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) )
			) {
				$styles[] = 'modula-slider-carousel-autoplay-css';
			}
		}

		return $styles;
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Modula_Albums_Slider object.
	 * @since 1.1.2
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Albums_Slider ) ) {
			self::$instance = new Albums_Slider();
		}

		return self::$instance;
	}

	/**
	 * Add Modula Slider fields and type
	 *
	 * @param array $fields Array of fields.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function modula_album_slider_gallery_type( $fields ) {
		// Let's manipulate the general field and album type field.
		if ( isset( $fields['general']['album_type'] ) ) {
			// Add slider fields.
			$slider_fields = array(
				'slider_adaptiveHeight'                => array(
					'name'      => esc_html__( 'Adaptive Height', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 1,
					'priority'  => 134,
					'data_type' => 'bool',
				),
				'slider_syncing'                       => array(
					'name'      => esc_html__( 'Enable thumbnail navigation', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 1,
					'priority'  => 135,
					'data_type' => 'bool',
				),
				'slider_syncing_nav_size'              => array(
					'name'      => esc_html__( 'Thumbnail Image Size', 'modula-pro' ),
					'type'      => 'select',
					'values'    => Slider::get_thumbnail_nav_sizes(),
					'default'   => 'auto',
					'is_child'  => true,
					'priority'  => 136,
					'data_type' => 'text',
				),
				'slider_syncing_nav_image_dimensions'  => array(
					'name'      => esc_html__( 'Dimensions', 'modula-pro' ),
					'type'      => 'image-size',
					'default'   => 0,
					'is_child'  => true,
					'priority'  => 137,
					'data_type' => 'number',
				),
				'slider_syncing_nav_image_crop'        => array(
					'name'      => esc_html__( 'Crop Images ?', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'is_child'  => true,
					'priority'  => 138,
					'data_type' => 'bool',
				),
				'slider_syncing_nav_thumbnails_number' => array(
					'name'      => esc_html__( 'Thumbnails number', 'modula-pro' ),
					'type'      => 'text',
					'default'   => 0,
					'is_child'  => true,
					'priority'  => 139,
					'data_type' => 'number',
				),
				'slider_arrows_inside'                 => array(
					'name'      => esc_html__( 'Arrows inside', 'modula-slider' ),
					'type'      => 'toggle',
					'default'   => 1,
					'priority'  => 145,
					'data_type' => 'bool',
					'is_child'  => true,
				),
				'slider_syncing_nav_thumbnails_gutter' => array(
					'name'      => esc_html__( 'Space betwenn thumbnails', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 0,
					'max'       => 100,
					'step'      => 1,
					'default'   => 10,
					'after'     => 'px',
					'is_child'  => true,
					'priority'  => 140,
					'data_type' => 'number',
				),
				'slider_syncing_nav_thumbnails_border_color' => array(
					'name'      => esc_html__( 'Active Border Color', 'modula-pro' ),
					'type'      => 'color',
					'default'   => '#000000',
					'is_child'  => true,
					'priority'  => 141,
					'data_type' => 'text',
				),
				'slider_autoplay'                      => array(
					'name'      => esc_html__( 'Enable autoplay', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'priority'  => 142,
					'data_type' => 'bool',
				),
				'slider_autoplaySpeed'                 => array(
					'name'      => esc_html__( 'Autoplay speed', 'modula-pro' ),
					'type'      => 'text',
					'default'   => 3000,
					'is_child'  => true,
					'priority'  => 143,
					'data_type' => 'number',
				),
				'slider_pauseOnHover'                  => array(
					'name'      => esc_html__( 'Pause on hover', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'is_child'  => true,
					'priority'  => 144,
					'data_type' => 'bool',
				),
				'slider_arrows'                        => array(
					'name'      => esc_html__( 'Show arrows navigation', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 1,
					'priority'  => 145,
					'data_type' => 'bool',
				),
				'slider_dots'                          => array(
					'name'      => esc_html__( 'Show dots navigation', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'priority'  => 146,
					'data_type' => 'bool',
				),
				'slider_draggable'                     => array(
					'name'      => esc_html__( 'Enable mouse dragging', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 1,
					'priority'  => 147,
					'data_type' => 'bool',
				),
				'slider_centerMode'                    => array(
					'name'      => esc_html__( 'Center mode', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 20,
					'priority'  => 148,
					'data_type' => 'bool',
				),
				'slider_centerPadding'                 => array(
					'name'      => esc_html__( 'Center Padding', 'modula-pro' ),
					'type'      => 'text',
					'default'   => '50px',
					'is_child'  => true,
					'priority'  => 149,
					'data_type' => 'text',
				),
				'slider_fade'                          => array(
					'name'      => esc_html__( 'Enable Fade effect', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'priority'  => 150,
					'data_type' => 'bool',
				),
				'slider_infinite'                      => array(
					'name'      => esc_html__( 'Infinite loop', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 1,
					'priority'  => 151,
					'data_type' => 'bool',
				),
				'slider_slidesToShow'                  => array(
					'name'      => esc_html__( 'Slides to show at once', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 1,
					'max'       => 10,
					'step'      => 1,
					'default'   => 1,
					'priority'  => 152,
					'data_type' => 'number',
				),
				'slider_slidesToScroll'                => array(
					'name'      => esc_html__( 'Slides to scroll', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 1,
					'max'       => 10,
					'step'      => 1,
					'default'   => 1,
					'priority'  => 153,
					'data_type' => 'number',
				),
				'slider_speed'                         => array(
					'name'      => esc_html__( 'Animation speed', 'modula-pro' ),
					'type'      => 'text',
					'default'   => 300,
					'priority'  => 154,
					'data_type' => 'number',
				),
				'slider_rtl'                           => array(
					'name'      => esc_html__( 'Enable RTL', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'priority'  => 155,
					'data_type' => 'bool',
				),
				'slider_initialSlide'                  => array(
					'name'      => esc_html__( 'Starting slide', 'modula-pro' ),
					'type'      => 'text',
					'default'   => 0,
					'priority'  => 156,
					'data_type' => 'number',
				),
				'slider_image_info'                    => array(
					'name'      => esc_html__( 'Show title and caption under the image', 'modula-pro' ),
					'type'      => 'toggle',
					'default'   => 0,
					'priority'  => 157,
					'data_type' => 'bool',
				),
				'slider_image_info_position'           => array(
					'name'      => esc_html__( 'Title and caption position', 'modula-pro' ),
					'type'      => 'select',
					'values'    => array(
						'top_outside' => __( 'Top Outside', 'modula-pro' ),
						'top_inside'  => __( 'Top Inside', 'modula-pro' ),
						'bot_outside' => __( 'Bottom Outside', 'modula-pro' ),
						'bot_inside'  => __( 'Bottom Inside', 'modula-pro' ),
					),
					'default'   => 'bot_outside',
					'is_child'  => true,
					'priority'  => 158,
					'data_type' => 'text',
				),
			);

			$slider_responsive_fields = array(
				'slider_tablet_slides'  => array(
					'name'      => esc_html__( 'Tablet slides to show ', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 1,
					'max'       => 12,
					'step'      => 1,
					'default'   => 1,
					'priority'  => 30,
					'is_child'  => true,
					'data_type' => 'number',
				),
				'slider_tablet_scrolls' => array(
					'name'      => esc_html__( 'Tablet slides to scroll', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 1,
					'max'       => 12,
					'step'      => 1,
					'default'   => 1,
					'is_child'  => true,
					'priority'  => 31,
					'data_type' => 'number',
				),
				'slider_mobile_slides'  => array(
					'name'      => esc_html__( 'Mobile slides to show', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 1,
					'max'       => 12,
					'step'      => 1,
					'default'   => 1,
					'is_child'  => true,
					'priority'  => 32,
					'data_type' => 'number',
				),
				'slider_mobile_scrolls' => array(
					'name'      => esc_html__( 'Mobile slides to scroll', 'modula-pro' ),
					'type'      => 'ui-slider',
					'min'       => 1,
					'max'       => 12,
					'step'      => 1,
					'default'   => 1,
					'is_child'  => true,
					'priority'  => 33,
					'data_type' => 'number',
				),
			);

			$fields['general']    = array_merge( $fields['general'], $slider_fields );
			$fields['responsive'] = array_merge( $fields['responsive'], $slider_responsive_fields );
			// Add the slider type to the album type field.
			$fields['general']['album_type']['values']['slider'] = esc_html__( 'Slider', 'modula-pro' );
			// Unset slider disabled option.
			if ( isset( $fields['general']['album_type']['disabled']['values']['slider'] ) ) {
				unset( $fields['general']['album_type']['disabled']['values']['slider'] );
			}

			if ( isset( $fields['general']['image_size'] ) && isset( $fields['general']['image_size']['default'] ) ) {
				$fields['general']['image_size']['default'] = 'large';
			}

			// Set default album width to auto
			if ( isset( $fields['general']['album_width'] ) ) {
				$fields['general']['album_width']['default'] = 'Auto';
			} else {
				$fields['general']['width']['default'] = 'Auto';
			}
		}

		return $fields;
	}

	/**
	 * Remake the gallery classes and add slider_lightbox to config
	 *
	 * @param array $template_data The template data.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function modula_album_gallery_classes( $template_data ) {

		$settings = $template_data['settings'];
		if ( isset( $settings['album_type'] ) && 'slider' === $settings['album_type'] ) {
			$template_data['album_container']['class'] = array( 'modula-slider' );

			$js_config           = json_decode( $template_data['album_container']['data-config'] );
			$js_config->lightbox = isset( $settings['enable_lightbox'] ) ? 'fancybox' : 'no-link';

			// Remove hover effects from slider.
			$template_data['settings']['effect'] = 'album-slider';
		}

		return $template_data;
	}

	/**
	 * We need to overwrite the height but still display the correct css
	 *
	 * @param string $css The css.
	 * @param int $album_id The Album ID.
	 * @param array $settings The gallery settings.
	 *
	 * @return string
	 * @since 1.1.2
	 */
	public function modula_album_slider_output_css( $css, $album_id, $settings ) {

		if ( isset( $settings['album_type'] ) && 'slider' === $settings['album_type'] ) {
			if ( isset( $settings['album_width'] ) ) {
				if ( 'auto' === $settings['album_width'] ) {
					$css .= "#{$album_id} { width:auto; }";
				} elseif ( 'full' === $settings['album_width'] ) {
					$css .= "#{$album_id}.modula-slider { max-width: calc( 100% - 44px ); margin: 0 auto; }";
				} else {
					$css .= "#{$album_id}.modula-slider { max-width: calc( " . esc_attr( $settings['width'] ) . ' - 44px ); margin: 0 auto; }';
				}
			} else {
				$width = ( ! empty( $settings['width'] ) && 'auto' !== strtolower( $settings['width'] ) ) ? $settings['width'] : '100%';
				$css  .= "#{$album_id}.modula-slider { max-width: calc( {$width} - 44px ); margin: 0 auto; }";
			}

			$width = ( ! empty( $settings['album_width'] ) && 'auto' !== strtolower( $settings['album_width'] ) ) ? $settings['width'] : ( ( ! empty( $settings['width'] ) && 'auto' !== strtolower( $settings['width'] ) ) ? $settings['width'] : '100%' );

			$css .= "#{$album_id}.modula-slider .modula-item .video-sizer iframe { min-width:100% }";

			// set the height to auto
			$css .= "#{$album_id} .modula-items{height:auto}";
			// remove the hover background color
			$css .= "#{$album_id} .modula-item{background-color:transparent}";
			// remove loading effects
			$css .= "#{$album_id} .modula-item{transform:none;}";
			// remove hover opacity on image
			$css .= "#{$album_id} .modula-item:hover img{opacity:1;}";

			$css .= "#{$album_id} .slider-clickable { position:relative;width:max-content;margin:0 auto;max-width:100%; }#{$album_id} .slider-clickable .modula-item-link, #{$album_id}  .slider-clickable .modula-simple-link { position:absolute; width:100%; height:100%; cursor:pointer; z-index:999;}";

			// If center mode is on, calculate margins & slides to show.
			if ( isset( $settings['slider_centerMode'] ) && '1' === $settings['slider_centerMode'] ) {
				$css .= "#{$album_id} .modula-items.f-carousel{--f-carousel-slide-width: calc( ( 100% / " . absint( $settings['slider_slidesToShow'] ) . ' ) - ' . absint( $settings['slider_centerPadding'] ) . 'px - ' . absint( $settings['gutter'] ) * ( absint( $settings['slider_slidesToShow'] ) + 1 ) . 'px );--f-carousel-spacing: ' . absint( $settings['gutter'] ) . 'px;}';
			} elseif ( 1 < absint( $settings['slider_slidesToShow'] ) ) {
					$css .= "#{$album_id} .modula-items.f-carousel{--f-carousel-slide-width: calc( ( 100% - ( ( " . absint( $settings['slider_slidesToShow'] ) . ' - 1 ) * ' . absint( $settings['gutter'] ) . 'px ) ) / ' . absint( $settings['slider_slidesToShow'] ) . ' );--f-carousel-spacing: ' . absint( $settings['gutter'] ) . 'px;}';
					$css .= "html body #{$album_id}.modula-slider .modula-items .modula-video-content{width: calc( ( 100% / " . absint( $settings['slider_slidesToShow'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px); }';
			} else {
				$css .= "#{$album_id} .modula-items.f-carousel{--f-carousel-slide-width: 100%;--f-carousel-spacing: 0;}";
				$css .= "html body #{$album_id}.modula-slider .modula-items .modula-video-content{width: calc( 100% / " . absint( $settings['slider_slidesToShow'] ) . '); }';
			}

			if ( isset( $settings['enable_responsive'] ) && '1' === $settings['enable_responsive'] ) {
				$css .= "@media (max-width: 1024px) { 
					#{$album_id} .modula-items.f-carousel{
						--f-carousel-slide-width: calc( ( 100% / " . absint( $settings['slider_tablet_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
						--f-carousel-spacing: ' . absint( $settings['gutter'] ) . "px;
					}
					html body #{$album_id}.modula-slider .modula-items .modula-video-content{
						width: calc( ( 100% / " . absint( $settings['slider_tablet_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
					}
				}';

				$css .= "@media (max-width: 600px) { 
					#{$album_id} .modula-items.f-carousel{
						--f-carousel-slide-width: calc( ( 100% / " . absint( $settings['slider_mobile_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
						--f-carousel-spacing: ' . absint( $settings['gutter'] ) . "px;
					}
					html body #{$album_id}.modula-slider .modula-items .modula-video-content{
						width: calc( ( 100% / " . absint( $settings['slider_mobile_slides'] ) . ' ) - ' . absint( $settings['gutter'] ) . 'px );
					}
				}';
			}

			// Slider dimensions for video.
			$real_sizes = self::get_real_sizes( $settings );
			$min_height = esc_attr( '50vh' );
			if ( 0 === $real_sizes['width'] ) {
				$width  = esc_attr( '100%' );
				$height = 'auto';
			} else {
				$min_height = esc_attr( 'auto' );
				$width      = absint( $real_sizes['width'] ) . 'px';
				$height     = ( ( absint( $real_sizes['width'] ) / 16 ) * 9 ) . 'px';
			}

			$css .= "#{$album_id} .modula-items .f-carousel__track .modula-item .video-sizer { width:" . $width . '; max-width:100%;}';
			if ( 'auto' !== $height ) {
				$css .= "#{$album_id} .modula-items .f-carousel__track .modula-item .video-sizer iframe, #{$album_id}  .modula-items .f-carousel__track .modula-item .video-sizer video { max-height:" . $height . '!important;max-height:100vh;min-height:' . $min_height . ' }';
			} else {
				$css .= "#{$album_id} .modula-items .f-carousel__track .modula-item .video-sizer iframe, #{$album_id}  .modula-items .f-carousel__track .modula-item .video-sizer video { max-height:100vh;min-height:" . $min_height . ' }';
			}
			if ( ! isset( $settings['hide_title'] ) || '1' !== absint( $settings['hide_title'] ) ) {
				$css .= "#{$album_id}.modula-slider .modula-items .slider-image-info .jtg-title {margin-bottom:0px;}";

				if ( '' !== $settings['titleColor'] ) {
					$css .= "#{$album_id}.modula-slider .modula-items .slider-image-info .jtg-title {";
					$css .= 'color:' . \Modula_Helper::sanitize_rgba_colour( $settings['titleColor'] ) . ';';
					$css .= '}';
				}

				if ( '' !== $settings['titleFontSize'] && 0 !== absint( $settings['titleFontSize'] ) ) {
					$css .= "#{$album_id}.modula-slider .modula-items .slider-image-info .jtg-title {";
					$css .= 'font-size:' . absint( $settings['titleFontSize'] ) . 'px;';
					$css .= '}';
				}

				if ( '' !== $settings['mobileTitleFontSize'] && 0 !== absint( $settings['mobileTitleFontSize'] ) ) {
					$css .= "@media all and (max-width:600px){#{$album_id}.modula-slider .modula-items .slider-image-info .description {";
					$css .= 'font-size:' . absint( $settings['mobileCaptionFontSize'] ) . 'px;';
					$css .= '}}';
				}
			}

			if ( ! isset( $settings['hide_description'] ) || '1' !== absint( $settings['hide_description'] ) ) {
				$css .= "#{$album_id}.modula-slider .modula-items .slider-image-info .description {margin-bottom:0px;}";

				if ( '' !== $settings['captionColor'] ) {
					$css .= "#{$album_id}.modula-slider .modula-items .slider-image-info .description {";
					$css .= 'color:' . \Modula_Helper::sanitize_rgba_colour( $settings['captionColor'] ) . ';';
					$css .= '}';
				}

				if ( '' !== $settings['captionFontSize'] && 0 !== absint( $settings['captionFontSize'] ) ) {
					$css .= "#{$album_id}.modula-slider .modula-items .slider-image-info .description {";
					$css .= 'font-size:' . absint( $settings['captionFontSize'] ) . 'px;';
					$css .= '}';
				}

				if ( '' !== $settings['mobileCaptionFontSize'] && 0 !== absint( $settings['mobileCaptionFontSize'] ) ) {
					$css .= "@media all and (max-width:600px){#{$album_id}.modula-slider .modula-items .slider-image-info .description {";
					$css .= 'font-size:' . absint( $settings['mobileCaptionFontSize'] ) . 'px;';
					$css .= '}}';
				}
			}

			if ( isset( $settings['slider_syncing_nav_thumbnails_border_color'] ) ) {
				$css .= '#' . $album_id . '.modula-slider .modula-carousel-nav .modula-slider-nav-item.is-nav-selected img.modula-slider-nav-image{border: 2px solid ' . \Modula_Helper::sanitize_rgba_colour( $settings['slider_syncing_nav_thumbnails_border_color'] ) . '}';
				$css .= '#' . $album_id . '.modula-slider .modula-carousel-nav .modula-slider-nav-item.is-nav-selected picture.modula-slider-nav-image img{border: 2px solid ' . \Modula_Helper::sanitize_rgba_colour( $settings['slider_syncing_nav_thumbnails_border_color'] ) . '}';
			}

			$css .= '#' . $album_id . '.modula-slider .modula-item-content{ position: relative; margin: 0 auto;}';
			$css .= '#' . $album_id . '.modula-slider .modula-item-content a.gallery-link{ position: absolute;left: 0; right: 0;top: 0;bottom: 0; z-index: 9999; }';

			if ( isset( $settings['slider_adaptiveHeight'] ) && 1 === absint( $settings['slider_adaptiveHeight'] ) ) {
				$css .= "#{$album_id} .modula-items .f-carousel__track { align-items:flex-start }";
			}

			if ( isset( $settings['slider_speed'] ) && 0 !== $settings['slider_speed'] ) {
				$speed_ms = (int) $settings['slider_speed'];
				$css     .= "#{$album_id} { --f-transition-duration: {$speed_ms}ms !important; }";
			}

			if ( isset( $settings['slider_syncing'] ) && 1 === absint( $settings['slider_syncing'] ) ) {
				$gutter        = isset( $settings['gutter'] ) ? absint( $settings['gutter'] ) : 10;
				$tablet_gutter = isset( $settings['tablet_gutter'] ) ? absint( $settings['tablet_gutter'] ) : $gutter;
				$mobile_gutter = isset( $settings['mobile_gutter'] ) ? absint( $settings['mobile_gutter'] ) : $gutter;
				$css          .= "#{$album_id} .modula-carousel-nav.f-carousel {margin-top: " . $gutter . 'px;}';
				$css          .= "@media screen and (max-width: 992px) {#{$album_id} .modula-carousel-nav.f-carousel {margin-top: " . $tablet_gutter . 'px;}}';
				$css          .= "@media screen and (max-width: 768px) {#{$album_id} .modula-carousel-nav.f-carousel {margin-top: " . $mobile_gutter . 'px;}}';
				if ( isset( $settings['slider_syncing'] ) ) {
					if ( 'auto' === $settings['slider_syncing_nav_size'] ) {
						$css .= "#{$album_id} .modula-slider-nav-item img.modula-slider-nav-image { aspect-ratio: 16 / 9; object-fit: cover;}";
						$css .= "#{$album_id} .modula-slider-nav-item picture.modula-slider-nav-image img{ aspect-ratio: 16 / 9; object-fit: cover;}";
					} else {
						$image_sizes = \Modula_Helper::get_image_sizes();
						if ( isset( $image_sizes[ $settings['slider_syncing_nav_size'] ] ) && is_array( $image_sizes[ $settings['slider_syncing_nav_size'] ] ) ) {
							$image_size = $image_sizes[ $settings['slider_syncing_nav_size'] ];
							$css       .= "#{$album_id} .modula-slider-nav-item img.modula-slider-nav-image { aspect-ratio: " . $image_size['width'] . ' / ' . $image_size['height'] . '; object-fit: cover;}';
							$css       .= "#{$album_id} .modula-slider-nav-item picture.modula-slider-nav-image img{ aspect-ratio: 16 / 9; object-fit: cover;}";
						} else {
							$css .= "#{$album_id} .modula-slider-nav-item img.modula-slider-nav-image { aspect-ratio: 1; object-fit: cover;}";
							$css .= "#{$album_id} .modula-slider-nav-item picture.modula-slider-nav-image img{ aspect-ratio: 1; object-fit: cover;}";
						}
					}
				}
			}

			if ( isset( $settings['slider_arrows_inside'] ) && (bool) $settings['slider_arrows_inside'] ) {
				$css .= "#{$album_id}.modula-slider .modula-items.f-carousel { --f-button-next-pos: 10px; --f-button-prev-pos: 10px; }";
			}
		}

		return $css;
	}

	/**
	 * Set defaults
	 *
	 * @param $defaults
	 *
	 * @return mixed
	 * @since 1.1.2
	 */
	public function set_defaults( $defaults ) {
		$defaults['album_type']                                 = 'grid';
		$defaults['slider_adaptiveHeight']                      = 1;
		$defaults['slider_image_height']                        = '800';
		$defaults['slider_syncing']                             = 1;
		$defaults['slider_syncing_nav_size']                    = 'auto';
		$defaults['slider_syncing_nav_thumbnails_number']       = 0;
		$defaults['slider_syncing_nav_thumbnails_gutter']       = 10;
		$defaults['slider_syncing_nav_thumbnails_border_color'] = '#000000';
		$defaults['slider_autoplay']                            = 0;
		$defaults['slider_autoplaySpeed']                       = 3000;
		$defaults['slider_arrows']                              = 1;
		$defaults['slider_arrows_inside']                       = 1;
		$defaults['slider_centerMode']                          = 1;
		$defaults['slider_centerPadding']                       = '50px';
		$defaults['slider_dots']                                = 0;
		$defaults['slider_draggable']                           = 1;
		$defaults['slider_fade']                                = 0;
		$defaults['slider_infinite']                            = 1;
		$defaults['slider_pauseOnHover']                        = 1;
		$defaults['slider_slidesToShow']                        = 1;
		$defaults['slider_slidesToScroll']                      = 1;
		$defaults['slider_speed']                               = 300;
		$defaults['slider_rtl']                                 = 0;
		$defaults['slider_initialSlide']                        = 0;
		$defaults['slider_tablet_slides']                       = 1;
		$defaults['slider_tablet_scrolls']                      = 1;
		$defaults['slider_mobile_slides']                       = 1;
		$defaults['slider_mobile_scrolls']                      = 1;
		$defaults['slider_syncing_nav_image_dimensions']        = 0;
		$defaults['slider_syncing_nav_image_crop']              = 0;
		$defaults['slider_image_info']                          = 0;
		$defaults['slider_image_info_position']                 = 'bot_outside';
		$defaults['image_size']                                 = 'large';
		$defaults['width']                                      = 'Auto';

		return $defaults;
	}

	/**
	 * Slider JS config
	 *
	 * @param array $js_config JS settings.
	 * @param array $settings Album settings.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function js_slider_config( $js_config, $settings ) {

		if ( isset( $settings['album_type'] ) && 'slider' === $settings['album_type'] ) {
			$js_config['slider_settings'] = array(
				'adaptiveHeight' => boolval( $settings['slider_adaptiveHeight'] ),
				'center'         => boolval( $settings['slider_centerMode'] ),
				'Dots'           => boolval( $settings['slider_dots'] ),
				'draggable'      => boolval( $settings['slider_draggable'] ),
				'transition'     => boolval( $settings['slider_fade'] ) ? 'fade' : 'slide',
				'infinite'       => boolval( $settings['slider_infinite'] ),
				'pauseOnHover'   => boolval( $settings['slider_pauseOnHover'] ),
				'slidesToShow'   => absint( $settings['slider_slidesToShow'] ),
				'slidesToScroll' => absint( $settings['slider_slidesToScroll'] ),
				'direction'      => boolval( $settings['slider_rtl'] ) ? 'rtl' : 'ltr',
				'initialSlide'   => ( $settings['slider_initialSlide'] > 0 ) ? (int) $settings['slider_initialSlide'] - 1 : (int) $settings['slider_initialSlide'],
				'showCount'      => apply_filters( 'modula_show_slider_numbers', 0, $settings ),
			);

			if ( $settings['lazy_load'] ) {
				if ( isset( $settings['slider_adaptiveHeight'] ) && 1 !== absint( $settings['slider_adaptiveHeight'] ) ) {
					$js_config['slider_settings']['lazyLoad'] = 'ondemand';
				} else {
					$js_config['slider_settings']['lazyLoad'] = 'progressive';
				}
			}

			if ( isset( $settings['enable_responsive'] ) && 1 === absint( $settings['enable_responsive'] ) ) {
				$responsive = array(
					array(
						'breakpoint' => 1024,
						'settings'   => array(
							'slidesToShow'   => ( isset( $settings['slider_tablet_slides'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_tablet_slides'] ) : 1,
							'slidesToScroll' => ( isset( $settings['slider_tablet_scrolls'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_tablet_scrolls'] ) : 1,
						),
					),
					array(
						'breakpoint' => 600,
						'settings'   => array(
							'slidesToShow'   => ( isset( $settings['slider_mobile_slides'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_mobile_slides'] ) : 1,
							'slidesToScroll' => ( isset( $settings['slider_mobile_scrolls'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_mobile_scrolls'] ) : 1,
						),
					),
				);

				$js_config['slider_settings']['responsive'] = $responsive;
			}

			if ( isset( $settings['slider_draggable'] ) && 0 === absint( $settings['slider_draggable'] ) ) {
				$js_config['slider_settings']['Panzoom']['touch'] = false;
			}

			if ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) ) {
				$js_config['slider_settings']['Autoplay'] = array(
					'autoStart'    => true,
					'timeout'      => ( 0 <= absint( $settings['slider_autoplaySpeed'] ) ) ? absint( $settings['slider_autoplaySpeed'] ) : 3000,
					'pauseOnHover' => ( 0 <= absint( $settings['slider_pauseOnHover'] ) ) ? boolval( $settings['slider_pauseOnHover'] ) : false,
				);
			}

			if ( isset( $settings['slider_syncing'] ) && 1 === absint( $settings['slider_syncing'] ) ) {
				if ( isset( $settings['slider_syncing_nav_size'] ) && '' !== $settings['slider_syncing_nav_size'] ) {
					$js_config['slider_settings']['navSize'] = esc_js( $settings['slider_syncing_nav_size'] );
				}
				$js_config['slider_settings']['navSlides'] = absint( $settings['slider_syncing_nav_thumbnails_number'] );
			}

			$js_config['slider_settings']['MSplugins'] = array();
			if ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) ) {
				$js_config['slider_settings']['MSplugins']['Autoplay'] = true;
			}

			if ( ! isset( $settings['slider_arrows'] ) || 1 !== absint( $settings['slider_arrows'] ) ) {
				$js_config['slider_settings']['Navigation'] = false;
			}
			if ( isset( $settings['album_width'] ) && 'custom' !== $settings['album_width'] ) {
				$js_config['slider_settings']['snapSlides'] = $settings['album_width'];
			} else {
				$js_config['slider_settings']['snapSlides'] = isset( $settings['width'] ) ? esc_js( strtolower( $settings['width'] ) ) : 'auto';
			}
		}

		return $js_config;
	}

	public static function get_real_sizes( $settings ) {

		if ( ! is_array( $settings ) || empty( $settings ) || 'full' === $settings['image_size'] ) {
			return array(
				'width'  => 0,
				'height' => 0,
			);
		}

		if ( 'custom' !== $settings['image_size'] ) {
			$size = \Modula_Helper::get_image_sizes()[ $settings['image_size'] ];
		} else {
			$size = $settings['image_dimensions'];
		}

		return $size;
	}

	public function change_effect( $template_data ) {

		if ( 'slider' !== $template_data['settings']['album_type'] ) {
			return $template_data;
		}

		$template_data['settings']['effect'] = 'slider';

		return $template_data;
	}

	/**
	 * Sanitize slider fields
	 *
	 * @param $sanitized_value
	 * @param $value
	 * @param $field_id
	 * @param $field
	 *
	 * @return mixed
	 *
	 * @since 1.1.2
	 */
	public function sanitize_slider_fields( $sanitized_value, $value, $field_id ) {

		if ( 'slider_image_dimensions' === $field_id ) {
			$new_value = array();
			if ( is_array( $value ) && ! empty( $value ) ) {
				foreach ( $value as $key => $img_size ) {
					$new_value[ $key ] = absint( $img_size );
				}
			}

			return $new_value;
		}

		return $sanitized_value;
	}

	public function enqueue_modula_block_styles() {
		wp_register_style( 'modula-slider-css', \MODULA_PRO_URL . 'includes/extensions/slider/assets/css/front.min.css', array(), \MODULA_PRO_VERSION );
		wp_register_script( 'modula-slider-carousel-autoplay-script', \MODULA_PRO_URL . 'includes/extensions/slider/assets/js/carousel.autoplay.umd.js', array( 'jquery', 'modula-slider-carousel-script' ), \MODULA_PRO_VERSION );
		wp_register_style( 'modula-slider-carousel-autoplay-css', \MODULA_PRO_URL . 'includes/extensions/slider/assets/css/carousel.autoplay.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Render Thumbnail navigation (galleries view – all item types).
	 *
	 * @param object $data Template data with settings and galleries.
	 * @since 1.1.2
	 */
	public function galleries_slider_syncing( $data ) {
		$settings = $data->settings;
		$this->modula_slider_syncing( $settings, $data, 'all' );
	}

	/**
	 * Render Thumbnail navigation (albums-only view).
	 *
	 * @param object $data Template data with settings and galleries.
	 * @since 1.1.2
	 */
	public function albums_slider_syncing( $data ) {
		$settings = $data->settings;
		$this->modula_slider_syncing( $settings, $data, 'modula-album' );
	}

	/**
	 * Render Thumbnail navigation
	 *
	 * @param array  $settings Gallery/album settings.
	 * @param object $data     Optional. Template data object with ->galleries. If empty, galleries are loaded from post meta.
	 * @param string $type     Optional. Filter by item type: 'all', 'modula-gallery', 'modula-album'. Default 'all'.
	 * @return void
	 * @since 1.1.2
	 */
	public function modula_slider_syncing( $settings, $data = null, $type = 'all' ) {

		if ( empty( $data ) || ! isset( $data->galleries ) ) {
			$galleries = get_post_meta( absint( preg_replace( '/\D+/', '', $settings['gallery_id'] ) ), 'modula-album-galleries', true );
		} else {
			$galleries = $data->galleries;
		}

		if ( empty( $galleries ) || ! is_array( $galleries ) ) {
			$galleries = array();
		}

		$images = array();
		foreach ( $galleries as $gallery ) {
			$item_type = isset( $gallery['itemType'] ) ? $gallery['itemType'] : 'modula-gallery';

			if ( 'all' !== $type && $item_type !== $type ) {
				continue;
			}

			if ( ! empty( $gallery['cover'] ) ) {
				$images[] = array( 'id' => absint( $gallery['cover'] ) );
				continue;
			}

			if ( 'modula-gallery' === $item_type ) {
				$item_images = get_post_meta( $gallery['id'], 'modula-images', true );
			} elseif ( 'modula-album' === $item_type ) {
				$cover_id    = modula_get_album_cover_id( $gallery['id'] );
				$item_images = $cover_id ? array( array( 'id' => $cover_id ) ) : array();
			} else {
				$item_images = array();
			}

			if ( empty( $item_images ) || ! isset( $item_images[0] ) || empty( $item_images[0]['id'] ) ) {
				continue;
			}

			$images[] = $item_images[0];
		}

		if ( isset( $settings['album_type'] ) && isset( $settings['slider_slidesToShow'] ) && 'slider' === $settings['album_type'] && 1 === absint( $settings['slider_slidesToShow'] ) ) {
			if ( 1 === absint( $settings['slider_syncing'] ) ) {
				if ( ! empty( $images ) ) {
					global $_wp_additional_image_sizes;
					$images_count   = count( $images );
					$slides_count   = absint( $settings['slider_syncing_nav_thumbnails_number'] );
					$gutter_size    = absint( $settings['slider_syncing_nav_thumbnails_gutter'] );
					$slides_to_show = ( $slides_count > $images_count || 0 === $slides_count ) ? $images_count : $slides_count;

					$slider_width = '';
					if ( 'auto' === $settings['slider_syncing_nav_size'] ) {
						$slider_width = '100%';
					} elseif ( 'custom' === $settings['slider_syncing_nav_size'] ) {
						$slider_width = absint( ( $settings['slider_syncing_nav_image_dimensions']['width'] + $gutter_size ) * $slides_to_show ) . 'px';
					} else {
						$width               = 100;
						$default_image_sizes = get_intermediate_image_sizes();
						$image_sizes         = array();

						foreach ( $default_image_sizes as $size ) {
							$image_sizes[ $size ]['width']  = intval( get_option( "{$size}_size_w" ) );
							$image_sizes[ $size ]['height'] = intval( get_option( "{$size}_size_h" ) );
							$image_sizes[ $size ]['crop']   = get_option( "{$size}_crop" ) ? get_option( "{$size}_crop" ) : false;
						}

						if ( isset( $_wp_additional_image_sizes ) && count( $_wp_additional_image_sizes ) ) {
							$image_sizes = array_merge( $image_sizes, $_wp_additional_image_sizes );
						}

						if ( isset( $image_sizes[ $settings['slider_syncing_nav_size'] ] ) ) {
							$width = $image_sizes[ $settings['slider_syncing_nav_size'] ]['width'];
						}

						$slider_width = absint( ( $width * $slides_to_show ) + ( $gutter_size * ( $slides_to_show - 1 ) ) ) . 'px';
					}

					echo "<div class='modula-carousel-nav-wrapp'>";
					echo "<div class='modula-carousel-nav' style='width:" . esc_attr( $slider_width ) . "; max-width: 100%;'>";
					foreach ( $images as $index => $image ) {
						$thumbnail_src = '';

						if ( 'custom' !== $settings['slider_syncing_nav_size'] ) {
							$thumb = wp_get_attachment_image_src( $image['id'], $settings['slider_syncing_nav_size'] );

							if ( $thumb ) {
								$thumbnail_src = $thumb[0];
							}
						} else {
							$image_full = wp_get_attachment_image_src( $image['id'], 'full' );
							$width      = $settings['slider_syncing_nav_image_dimensions']['width'];
							$height     = $settings['slider_syncing_nav_image_dimensions']['height'];
							$crop       = (bool) $settings['slider_syncing_nav_image_crop'];

							if ( ! $image_full ) {
								continue;
							}

							$resizer = new \Modula_Image();
							$resized = $resizer->resize_image( $image_full[0], $width, $height, $crop );

							if ( isset( $resized['resized_url'] ) ) {
								$image_url = $resized['resized_url'];
							} else {
								$image_url = $resized;
							}

							if ( is_wp_error( $image_url ) ) {
								$image_url = $image_full[0];
							}

							$thumbnail_src = $image_url;
						}

						$thumbnail_src = apply_filters( 'modula_album_slider_thumbnail_src', $thumbnail_src, $image, $settings );

						if ( 'auto' !== $settings['slider_syncing_nav_size'] ) {
							$img_style = 'max-width: calc( ( 100% - ' . $gutter_size . 'px ) / 2 );width:' . absint( $width ) . 'px;margin:0 ' . ( $gutter_size ? absint( $gutter_size ) : 0 ) . 'px 0 0;';
						} else {
							$img_style = 'width: calc( ( 100% - ( ' . ( $slides_to_show - 1 ) . ' * ' . $gutter_size . 'px ) ) / ' . $slides_to_show . ' );margin:0 ' . ( $gutter_size ? absint( $gutter_size ) : 0 ) . 'px 0 0;';
						}

						echo "<div class='modula-slider-nav-item' style='" . esc_attr( $img_style ) . "'>";
						do_action( 'modula_slider_before_thumbnail', $image, $images, $settings );
						if ( ! empty( $thumbnail_src ) ) {
							echo "<img class='modula-slider-nav-image'  src='" . esc_url( $thumbnail_src ) . "'>";
						}
						do_action( 'modula_slider_after_thumbnail', $image, $images, $settings );
						echo '</div>';
					}
					echo '</div>';
					echo '</div>';
				}
			}
		}
	}

		/**
	 * Set item data
	 *
	 * @param $item_data
	 * @param $image
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function modula_album_slider_item_data( $item_data, $image, $gallery_settings, $settings ) {
		if ( 'slider' === $settings['album_type'] ) {
			// add only item class
			$item_data['item_attributes']['class'][] = 'f-carousel__slide';

			unset( $item_data['item_attributes']['data-width'] );
			unset( $item_data['item_attributes']['data-height'] );

			if ( ! isset( $item_data['item_type'] ) || 'modula-album' !== $item_data['item_type'] ) {
				unset( $item_data['link_attributes']['href'] );
			}

			if ( isset( $settings['slider_image_info'] ) && 1 === absint( $settings['slider_image_info'] ) ) {
				$item_data['slider_image_info']          = 1;
				$item_data['slider_image_info_position'] = isset( $settings['slider_image_info_position'] ) ? $settings['slider_image_info_position'] : 'bot_outside';
			}
		}

		return $item_data;
	}

	public function slider_effect_info( $effects ) {
		$effects[] = 'album-slider';

		return $effects;
	}

	public function add_caption_title_top( $data ) {
		if ( ! isset( $data->slider_image_info ) || 1 !== absint( $data->slider_image_info ) ) {
			return;
		}

		if ( ! in_array( $data->slider_image_info_position, array( 'top_outside', 'top_inside' ), true ) ) {
			return;
		}

		$this->add_caption_title( $data );
	}

	public function add_caption_title_bottom( $data ) {
		if ( ! isset( $data->slider_image_info ) || 1 !== absint( $data->slider_image_info ) ) {
			return;
		}
		if ( ! in_array( $data->slider_image_info_position, array( 'bot_outside', 'bot_inside' ), true ) ) {
			return;
		}

		$this->add_caption_title( $data );
	}

	public function add_caption_title( $data ) {

		$output = '<div class="slider-image-info ' . esc_attr( $data->slider_image_info_position ) . '">';

		if ( ! $data->hide_title ) {
			$output .= sprintf(
				"<p class='jtg-title'>%s</p>",
				wp_kses_post( $data->title )
			);
		}

		if ( ! $data->hide_description ) {
			$output .= sprintf(
				'<p class="description">%s</p>',
				wp_kses_post( $data->description )
			);
		}

		$output .= '</div>';

		echo $output;
	}
}
