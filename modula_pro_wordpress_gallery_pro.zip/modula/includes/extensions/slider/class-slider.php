<?php
namespace Modula_Pro\Extensions\Slider;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-navigation-thumbnail.php';

/**
 * Class Slider
 */
class Slider {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		new Enqueue();

		add_action( 'admin_init', array( $this, 'set_admin_requirements' ), 25 );

		// Add defaults.
		add_filter( 'modula_lite_default_settings', array( $this, 'set_defaults' ) );

		// Add image sizes.
		add_filter( 'modula_resize_image_slider', array( $this, 'modula_slider_image_sizes' ), 15, 4 );

		add_filter( 'modula_speedup_image_size', array( $this, 'modula_slider_get_size' ), 20, 2 );

		// Add new classe for each item and add lightbox_slider option to lightbox.
		add_filter( 'modula_shortcode_item_data', array( $this, 'modula_slider_item_data' ), 90, 3 );
		add_filter( 'modula_shortcode_video_item_data', array( $this, 'modula_slider_item_data' ), 90, 3 );
		add_filter( 'modula_frontend_adapter_item', array( $this, 'navigation_thumbnail_data' ), 20, 4 );

		// Generate new images' links.
		add_filter( 'modula_shortcode_item_data', array( $this, 'change_image_size' ), 6, 3 );

		// Lock each slide to its image ratio. Runs after Speedup (100), the last classic-renderer filter that sets width/height.
		add_filter( 'modula_shortcode_item_data', array( $this, 'add_slide_aspect_ratio' ), 105, 3 );

		// Add slider class and remove the other + add the slider_lightbox setting to config ( v1.0.6 ).
		add_filter( 'modula_gallery_template_data', array( $this, 'modula_gallery_classes' ), 40 );

		// Right now slider doesn't support hover effects.
		add_filter( 'modula_gallery_template_data', array( $this, 'change_effect' ), 99 );

		// Remove filters.
		add_filter( 'modula_gallery_template_data', array( $this, 'modula_slider_settings' ), 10, 1 );

		// Add slider settings to js config.
		add_filter( 'modula_gallery_settings', array( $this, 'js_slider_config' ), 10, 2 );

		// Add action for slider syncing.
		add_action( 'modula_shortcode_after_items', array( $this, 'modula_slider_syncing' ), 85, 4 );

		// Add new path for templates.
		add_filter( 'modula_template_paths', array( $this, 'add_modula_slider_templates_path' ), 20 );

		add_filter( 'modula_settings_field_sanitization', array( $this, 'sanitize_slider_fields' ), 25, 4 );

		add_filter( 'modula_migrate_gallery_data', array( $this, 'modula_migrate_data' ), 99, 3 );

		// Troubleshooting scripts.
		add_filter( 'modula_troubleshooting_fields', array( $this, 'add_troubleshooting_fields' ) );
		add_filter( 'modula_troubleshooting_defaults', array( $this, 'add_troubleshooting_defaults' ) );
		add_filter( 'modula_troubleshooting_frontend_handles', array( $this, 'add_main_slider_files' ), 70, 2 );

		// Add shuffle for slider.
		add_filter( 'modula_shuffle_grid_types', array( $this, 'add_slider_shuffle' ) );
		add_filter( 'modula_fancybox_options', array( $this, 'add_video_icon_compat' ), 10, 2 );
		// Filter the gallery data for the REST API. Used for the Gutenberg editor, to remove the
		// image data-width and data-height attributes.
		add_filter( 'rest_prepare_modula-gallery', array( $this, 'rest_api_filter_data' ), 60, 3 );

		add_filter( 'modula_slider_item_before_image', array( $this, 'add_caption_title_top' ) );
		add_filter( 'modula_slider_item_after_image', array( $this, 'add_caption_title_bottom' ), 100 );
	}


	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.0.14
	 */
	public function set_admin_requirements() {
		add_filter( 'modula_gallery_fields', array( $this, 'modula_slider_gallery_type' ), 15, 1 );
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Slider object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Slider ) ) {
			self::$instance = new Slider();
		}

		return self::$instance;
	}

	/**
	 * Add Modula Slider fields and type
	 *
	 * @param $fields
	 * @return mixed
	 */
	public function modula_slider_gallery_type( $fields ) {

		// Add new Gallery type
		if ( isset( $fields['general']['type']['disabled'] ) && isset( $fields['general']['type']['disabled']['values'] ) && isset( $fields['general']['type']['disabled']['values']['slider'] ) ) {
			unset( $fields['general']['type']['disabled']['values']['slider'] );
		}
		$fields['general']['type']['values']['slider'] = esc_html__( 'Slider', 'modula-pro' );

		// Add slider fields
		$slider_fields = array(
			'slider_image_size'                          => array(
				'name'      => esc_html__( 'Slider Images Size', 'modula-pro' ),
				'type'      => 'dimensions-select',
				'values'    => \Modula_Helper::get_image_sizes( true ),
				'default'   => 'large',
				'priority'  => 27,
				'data_type' => 'text',
			),
			'slider_image_dimensions'                    => array(
				'name'      => esc_html__( 'Image Dimensions', 'modula-pro' ),
				'type'      => 'image-size',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 28,
				'data_type' => 'number',
			),

			'slider_image_crop'                          => array(
				'name'      => esc_html__( 'Crop Images ?', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 29,
				'data_type' => 'bool',
			),
			'slider_adaptiveHeight'                      => array(
				'name'      => esc_html__( 'Adaptive Height', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 134,
				'data_type' => 'bool',
			),
			'slider_syncing'                             => array(
				'name'      => esc_html__( 'Enable thumbnail navigation', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 135,
				'data_type' => 'bool',
			),

			'slider_syncing_nav_size'                    => array(
				'name'      => esc_html__( 'Thumbnail Image Size', 'modula-pro' ),
				'type'      => 'select',
				'values'    => self::get_thumbnail_nav_sizes(),
				'default'   => 'auto',
				'is_child'  => true,
				'priority'  => 136,
				'data_type' => 'text',
			),

			'slider_syncing_nav_image_dimensions'        => array(
				'name'      => esc_html__( 'Dimensions', 'modula-pro' ),
				'type'      => 'image-size',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 137,
				'data_type' => 'number',
			),

			'slider_syncing_nav_image_crop'              => array(
				'name'      => esc_html__( 'Crop Images ?', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 138,
				'data_type' => 'bool',
			),

			'slider_syncing_nav_thumbnails_number'       => array(
				'name'      => esc_html__( 'Thumbnails number', 'modula-pro' ),
				'type'      => 'text',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 139,
				'data_type' => 'number',
			),

			'slider_syncing_nav_thumbnails_gutter'       => array(
				'name'      => esc_html__( 'Space between thumbnails', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 0,
				'max'       => 100,
				'step'      => 1,
				'default'   => 10,
				'after'     => 'px',
				'is_child'  => true,
				'priority'  => 140,
				'data_type' => 'number',
			),

			'slider_syncing_nav_thumbnails_border_color' => array(
				'name'      => esc_html__( 'Active Border Color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '#000000',
				'is_child'  => true,
				'priority'  => 141,
				'data_type' => 'text',
			),

			'slider_autoplay'                            => array(
				'name'      => esc_html__( 'Enable autoplay', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 142,
				'data_type' => 'bool',
			),
			'slider_autoplaySpeed'                       => array(
				'name'      => esc_html__( 'Autoplay speed', 'modula-pro' ),
				'type'      => 'text',
				'default'   => 3000,
				'is_child'  => true,
				'priority'  => 143,
				'data_type' => 'number',
			),
			'slider_pauseOnHover'                        => array(
				'name'      => esc_html__( 'Pause on hover', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 144,
				'data_type' => 'bool',
			),
			'slider_arrows'                              => array(
				'name'      => esc_html__( 'Show arrows navigation', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 145,
				'data_type' => 'bool',
			),
			'slider_arrows_inside'                       => array(
				'name'      => esc_html__( 'Arrows inside', 'modula-slider' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 145,
				'data_type' => 'bool',
				'is_child'  => true,
			),
			'slider_dots'                                => array(
				'name'      => esc_html__( 'Show dots navigation', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 146,
				'data_type' => 'bool',
			),
			'slider_draggable'                           => array(
				'name'      => esc_html__( 'Enable mouse dragging', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 147,
				'data_type' => 'bool',
			),
			'slider_centerMode'                          => array(
				'name'      => esc_html__( 'Center mode', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 20,
				'priority'  => 148,
				'data_type' => 'bool',
			),
			'slider_centerPadding'                       => array(
				'name'      => esc_html__( 'Center Padding', 'modula-pro' ),
				'type'      => 'text',
				'default'   => '50px',
				'is_child'  => true,
				'priority'  => 149,
				'data_type' => 'text',
			),
			'slider_fade'                                => array(
				'name'      => esc_html__( 'Enable Fade effect', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 150,
				'data_type' => 'bool',
			),
			'slider_infinite'                            => array(
				'name'      => esc_html__( 'Infinite loop', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 151,
				'data_type' => 'bool',
			),
			'slider_slidesToShow'                        => array(
				'name'      => esc_html__( 'Slides to show at once', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 1,
				'max'       => 10,
				'step'      => 1,
				'default'   => 1,
				'priority'  => 152,
				'data_type' => 'number',
			),
			'slider_slidesToScroll'                      => array(
				'name'      => esc_html__( 'Slides to scroll', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 1,
				'max'       => 10,
				'step'      => 1,
				'default'   => 1,
				'priority'  => 153,
				'data_type' => 'number',
			),
			'slider_speed'                               => array(
				'name'      => esc_html__( 'Animation speed', 'modula-pro' ),
				'type'      => 'text',
				'default'   => 300,
				'priority'  => 154,
				'data_type' => 'number',
			),
			'slider_rtl'                                 => array(
				'name'      => esc_html__( 'Enable RTL', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 155,
				'data_type' => 'bool',
			),
			'slider_initialSlide'                        => array(
				'name'      => esc_html__( 'Starting slide', 'modula-pro' ),
				'type'      => 'text',
				'default'   => 0,
				'priority'  => 156,
				'data_type' => 'number',
			),
			'slider_image_info'                          => array(
				'name'      => esc_html__( 'Show title and caption', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 157,
				'data_type' => 'bool',
			),
			'slider_image_info_position'                 => array(
				'name'      => esc_html__( 'Title and caption position', 'modula-pro' ),
				'type'      => 'select',
				'values'    => array(
					'top_outside' => __( 'Top Outside', 'modula-pro' ),
					'top_inside'  => __( 'Top Inside', 'modula-pro' ),
					'bot_outside' => __( 'Bottom Outside', 'modula-pro' ),
					'bot_inside'  => __( 'Bottom Inside', 'modula-pro' ),
				),
				'default'   => 'bot_outside',
				'is_child'  => true,
				'priority'  => 158,
				'data_type' => 'text',
			),
		);

		$slider_responsive_fields = array(
			'slider_tablet_slides'  => array(
				'name'      => esc_html__( 'Tablet slides to show ', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 1,
				'max'       => 12,
				'step'      => 1,
				'default'   => 1,
				'priority'  => 30,
				'is_child'  => true,
				'data_type' => 'number',
			),
			'slider_tablet_scrolls' => array(
				'name'      => esc_html__( 'Tablet slides to scroll', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 1,
				'max'       => 12,
				'step'      => 1,
				'default'   => 1,
				'is_child'  => true,
				'priority'  => 31,
				'data_type' => 'number',
			),
			'slider_mobile_slides'  => array(
				'name'      => esc_html__( 'Mobile slides to show', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 1,
				'max'       => 12,
				'step'      => 1,
				'default'   => 1,
				'is_child'  => true,
				'priority'  => 32,
				'data_type' => 'number',
			),
			'slider_mobile_scrolls' => array(
				'name'      => esc_html__( 'Mobile slides to scroll', 'modula-pro' ),
				'type'      => 'ui-slider',
				'min'       => 1,
				'max'       => 12,
				'step'      => 1,
				'default'   => 1,
				'is_child'  => true,
				'priority'  => 33,
				'data_type' => 'number',
			),
		);

		$slider_lightbox_fields['slider_lightbox'] = array(
			'name'      => esc_html__( 'Image click behavior', 'modula-pro' ),
			'type'      => 'select',
			'default'   => 'no-link',
			'values'    => array(
				'no-link'         => esc_html__( 'No link', 'modula-pro' ),
				'attachment-page' => esc_html__( 'Attachment page', 'modula-pro' ),
				'fancybox'        => esc_html__( 'Open Images in a Lightbox', 'modula-pro' ),
			),
			'priority'  => 0,
			'data_type' => 'text',
		);

		// Set default gallery width to auto
		$fields['general']['width']['default'] = 'Auto';

		$fields['lightboxes'] = array_merge( $fields['lightboxes'], $slider_lightbox_fields );
		$fields['general']    = array_merge( $fields['general'], $slider_fields );
		$fields['responsive'] = array_merge( $fields['responsive'], $slider_responsive_fields );

		return $fields;
	}

	/**
	 * Add image sizes for slider type
	 *
	 * @param $return
	 * @param $id
	 * @param $sizes
	 * @param $crop
	 *
	 * @return mixed
	 */
	public function modula_slider_image_sizes( $return_obj, $id, $sizes, $crop ) {

		if ( is_array( $sizes ) ) {
			if ( ! $crop ) {
				$image_obj = wp_get_attachment_image_src( $id, 'full' );
				$ratio     = (float) ( (int) $image_obj[1] / (int) $image_obj[2] );
				$width     = absint( $sizes['width'] );
				$height    = absint( $sizes['height'] );

				if ( 0 === $width || 0 === $height ) {
					if ( 0 === $width ) {
						$width = $height * $ratio;
					} else {
						$height = $width / $ratio;
					}
				} elseif ( $sizes['width'] / $sizes['height'] !== $image_obj[1] / $image_obj[2] ) {

					// keep height
					if ( $sizes['width'] >= $sizes['height'] ) {
						$height = $sizes['width'] / $ratio;
					} else {
						$width = $sizes['height'] * $ratio;
					}
				}

				$return_obj['width']  = (int) $width;
				$return_obj['height'] = (int) $height;
			} else {
				$return_obj['width']  = $sizes['width'];
				$return_obj['height'] = $sizes['height'];
			}
		} else {
			$image_sizes = wp_get_attachment_image_src( $id, $sizes );

			if ( $image_sizes ) {
				$return_obj['width']  = $image_sizes[1];
				$return_obj['height'] = $image_sizes[2];
			}
		}

		return $return_obj;
	}


	public function modula_slider_get_size( $size, $settings ) {

		if ( isset( $settings['type'] ) && 'slider' === $settings['type'] ) {
			$size = ( 'custom' !== $settings['slider_image_size'] ) ? $settings['slider_image_size'] : $settings['slider_image_dimensions'];
		}

		return $size;
	}

	/** Supply navigation-only image descriptors to the Beta renderer and editor preview. */
	public function navigation_thumbnail_data( $item, $image, $item_data, $settings ) {
		$preview = 'settings_editor' === ( $settings['modula_display_context'] ?? '' );
		if ( 'slider' !== ( $settings['type'] ?? '' ) && ! $preview ) {
			return $item;
		}
		$item['sliderThumbnail'] = Navigation_Thumbnail::resolve( $image, $settings );
		if ( $preview ) {
			// Preview settings change without refetching the gallery's editable item catalog.
			foreach ( array_merge( array( 'auto', 'full' ), get_intermediate_image_sizes() ) as $size ) {
				$choice = array_merge( $settings, array( 'slider_syncing_nav_size' => $size ) );
				$item['sliderThumbnailChoices'][ $size ] = Navigation_Thumbnail::resolve( $image, $choice );
			}
			if ( 'custom' === ( $settings['slider_syncing_nav_size'] ?? '' ) ) {
				$item['sliderThumbnailChoices']['custom'] = $item['sliderThumbnail'];
			}
		}
		return $item;
	}

	/**
	 * Set item data
	 *
	 * @param $item_data
	 * @param $image
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function modula_slider_item_data( $item_data, $image, $settings ) {
		if ( 'slider' !== $settings['type'] ) {
			return $item_data;
		}

		// empty array
		$item_data['item_classes'] = array();
		// add only item class
		$item_data['item_classes'][] = 'modula-item';
		$item_data['item_classes'][] = 'f-carousel__slide';
		// allow showing social icons no matter the hover effect
		$item_data['hide_socials'] = false;
		// allow showing title no matter the hover effect
		$item_data['hide_title'] = ( 1 === absint( $settings['hide_title'] ) ) ? true : false;
		// allow showing description no matter the hover effect
		$item_data['hide_description']                  = ( 1 === absint( $settings['hide_description'] ) ) ? true : false;
		$item_data['item_attributes']['data-thumb-src'] = isset( $item_data['link_attributes']['data-thumb'] ) ? $item_data['link_attributes']['data-thumb'] : false;
		// if has link use as clickable link
		if ( '' !== $image['link'] ) {
			$item_data['link_attributes']['href'] = $image['link'];
			$item_data['is_custom_url']           = true;
			$item_data['item_classes'][]          = 'modula-simple-link';
		}

		if ( isset( $settings['slider_image_info'] ) && 1 === absint( $settings['slider_image_info'] ) ) {
			$item_data['slider_image_info']          = '1';
			$item_data['slider_image_info_position'] = isset( $settings['slider_image_info_position'] ) ? $settings['slider_image_info_position'] : 'bot_outside';
		}

		// As of v1.0.6 we introduce a new setting called slider_lightbox
		// It is used for links in the slider
		if ( isset( $settings['slider_lightbox'] ) ) {
			$item_data['lightbox'] = $settings['slider_lightbox'];
		} else {
			$item_data['lightbox'] = 'no-link';
		}
		// Set the item data custom grid, used for srcset and sizes behaviour.
		if ( 'custom' === $settings['slider_image_size'] ) {
			$item_data['custom_grid'] = true;
		}
		// Set the crop option for the image, used for srcset and sizes behaviour.
		// Use absint: crop is stored as int 1/0 from the CPT; strict '1' === would fail for integer 1.
		// Only when size is custom — same as change_image_size().
		if ( 'custom' === $settings['slider_image_size'] && 1 === absint( $settings['slider_image_crop'] ?? 0 ) ) {
			$item_data['crop'] = true;
		}

		return $item_data;
	}

	/**
	 * Modula image attributes
	 *
	 * @param $item_data
	 * @param $item
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function change_image_size( $item_data, $item, $settings ) {

		if ( ! apply_filters( 'modula_resize_images', true, $settings ) ) {
			return $item_data;
		}

		// We need to change only for gallery type slider
		if ( 'slider' !== $settings['type'] ) {
			return $item_data;
		}

		if ( ! class_exists( 'Modula_Image' ) ) {
			return $item_data;
		}

		$resizer = new \Modula_Image();

		if ( 'custom' === $settings['slider_image_size'] ) {
			$dims = isset( $settings['slider_image_dimensions'] ) ? $settings['slider_image_dimensions'] : null;
			if ( ! is_array( $dims ) ) {
				return $item_data;
			}
			$grid_sizes = array(
				'width'  => absint( $dims['width'] ?? 0 ),
				'height' => absint( $dims['height'] ?? 0 ),
			);
			if ( $grid_sizes['width'] < 1 || $grid_sizes['height'] < 1 ) {
				return $item_data;
			}
		} else {
			$grid_sizes = $settings['slider_image_size'];
			// Legacy “default” slug is not a WP size — treat as large (v2 schema default).
			if ( ! is_array( $grid_sizes ) && ( 'default' === $grid_sizes || '' === $grid_sizes ) ) {
				$grid_sizes = 'large';
			}
		}

		$crop = false;

		if ( 'custom' === $settings['slider_image_size'] ) {
			$crop = ( 1 === absint( $settings['slider_image_crop'] ?? 0 ) );
		}

		$align = 'c';

		if ( 'top' === $item['valign'] ) {
			$valign = 't';
		} elseif ( 'bottom' === $item['valign'] ) {
			$valign = 'b';
		} else {
			$valign = 'c';
		}

		if ( 'left' === $item['halign'] ) {
			$halign = 'l';
		} elseif ( 'right' === $item['halign'] ) {
			$halign = 'r';
		} else {
			$halign = 'c';
		}

		if ( $valign !== $halign ) {
			$align = $valign . $halign;
		}

		$sizes = $resizer->get_image_size( $item['id'], 'slider', $grid_sizes, $crop );
		if ( is_wp_error( $sizes ) ) {
			return $item_data;
		}
		$width  = isset( $sizes['width'] ) ? $sizes['width'] : null;
		$height = isset( $sizes['height'] ) ? $sizes['height'] : null;

		$resized    = $resizer->resize_image( $sizes['url'], $width, $height, $crop, $align );
		$image_info = false;

		// If we couldn't resize the image we will return the full image.
		if ( is_wp_error( $resized ) ) {
			$image_url = $sizes['url'];
		} elseif ( is_array( $resized ) && isset( $resized['resized_url'] ) ) {
			$image_url = $resized['resized_url'];
		} elseif ( is_array( $resized ) && isset( $resized['image_info'] ) ) {
			$image_info = $resized['image_info'];
			$image_url  = isset( $resized['resized_url'] ) ? $resized['resized_url'] : $sizes['url'];
		} else {
			// resize_image can return a string URL when no array is returned.
			$image_url = is_string( $resized ) ? $resized : $sizes['url'];
		}

		$item_data['img_attributes']['width']  = $width;
		$item_data['img_attributes']['height'] = $height;
		$item_data['image_full']               = $sizes['url'];
		$item_data['image_url']                = ( isset( $sizes['thumb_url'] ) ) ? $sizes['thumb_url'] : $image_url;
		// If thumb_url exists it means we are in predefined sizes
		$item_data['img_attributes']['src']      = ( isset( $sizes['thumb_url'] ) ) ? $sizes['thumb_url'] : $image_url;
		$item_data['img_attributes']['data-src'] = ( isset( $sizes['thumb_url'] ) ) ? $sizes['thumb_url'] : $image_url;
		$item_data['image_info']                 = $image_info;

		if ( $settings['lazy_load'] ) {
			$item_data['img_attributes']['data-lazy'] = $image_url;
			$item_data['img_attributes']['src']       = '';
		}

		return $item_data;
	}

	/**
	 * Give a slider image an explicit aspect ratio from its width/height attributes.
	 *
	 * The ratio the browser derives from the attributes is `auto w / h`: once a lazy-load
	 * placeholder (such as a 1x1 GIF `src`) has loaded, its own 1:1 ratio wins. The slide then
	 * renders square and the carousel grows to the tallest slide until the real image loads.
	 * An explicit ratio holds the slide at the image ratio whatever lazy loader is active.
	 *
	 * @param array $item_data Item data; reads and extends `img_attributes`.
	 * @param array $item      Gallery image.
	 * @param array $settings  Gallery settings.
	 *
	 * @return array
	 */
	public function add_slide_aspect_ratio( $item_data, $item, $settings ) {
		if ( 'slider' !== ( $settings['type'] ?? '' ) ) {
			return $item_data;
		}

		// The v2 renderer spreads img_attributes as React props, where `style` must be an object.
		if ( isset( $settings['modula_display_context'] ) ) {
			return $item_data;
		}

		$width  = absint( $item_data['img_attributes']['width'] ?? 0 );
		$height = absint( $item_data['img_attributes']['height'] ?? 0 );
		if ( $width < 1 || $height < 1 ) {
			return $item_data;
		}

		// `contain` letterboxes instead of stretching when the delivered file's ratio differs
		// from its attributes (for example a failed crop that falls back to the full image).
		$style        = 'aspect-ratio: ' . $width . ' / ' . $height . ';object-fit: contain;';
		$inline_style = $item_data['img_attributes']['style'] ?? '';
		if ( is_string( $inline_style ) && '' !== $inline_style ) {
			$style = rtrim( $inline_style, ';' ) . ';' . $style;
		}
		$item_data['img_attributes']['style'] = $style;

		return $item_data;
	}


	/**
	 * Remake the gallery classes and add slider_lightbox to config
	 *
	 * @param $template_data
	 *
	 * @return mixed
	 */
	public function modula_gallery_classes( $template_data ) {
		if ( 'slider' !== $template_data['settings']['type'] ) {
			return $template_data;
		}

		$template_data['gallery_container']['class'] = array( 'modula-slider' );

		$js_config           = json_decode( $template_data['gallery_container']['data-config'] );
		$js_config->lightbox = isset( $template_data['settings']['slider_lightbox'] ) ? $template_data['settings']['slider_lightbox'] : 'no-link';

		$template_data['gallery_container']['data-config'] = wp_json_encode( $js_config );

		return $template_data;
	}


	/**
	 * Hide used filters
	 *
	 * @param $template_data
	 *
	 * @return mixed
	 */
	public function modula_slider_settings( $template_data ) {
		if ( 'slider' === $template_data['settings']['type'] ) {
			$template_data['settings']['filters'] = array();
		}

		return $template_data;
	}

	/**
	 * Set defaults
	 *
	 * @param $defaults
	 * @return mixed
	 */
	public function set_defaults( $defaults ) {
		$defaults['slider_adaptiveHeight']                      = 1;
		$defaults['slider_image_size']                          = 'large';
		$defaults['slider_image_dimensions']                    = 0;
		$defaults['slider_image_height']                        = '800';
		$defaults['slider_syncing']                             = 1;
		$defaults['slider_syncing_nav_size']                    = 'auto';
		$defaults['slider_syncing_nav_thumbnails_number']       = 0;
		$defaults['slider_syncing_nav_thumbnails_gutter']       = 10;
		$defaults['slider_syncing_nav_thumbnails_border_color'] = '#000000';
		$defaults['slider_autoplay']                            = 0;
		$defaults['slider_autoplaySpeed']                       = 3000;
		$defaults['slider_arrows']                              = 1;
		$defaults['slider_centerMode']                          = 1;
		$defaults['slider_centerPadding']                       = '50px';
		$defaults['slider_dots']                                = 0;
		$defaults['slider_draggable']                           = 1;
		$defaults['slider_fade']                                = 0;
		$defaults['slider_infinite']                            = 1;
		$defaults['slider_pauseOnHover']                        = 1;
		$defaults['slider_slidesToShow']                        = 1;
		$defaults['slider_slidesToScroll']                      = 1;
		$defaults['slider_initialSlide']                        = 0;
		$defaults['slider_speed']                               = 300;
		$defaults['slider_rtl']                                 = 0;
		$defaults['slider_initialSlide']                        = 0;
		$defaults['slider_image_crop']                          = 0;
		$defaults['slider_tablet_slides']                       = 1;
		$defaults['slider_tablet_scrolls']                      = 1;
		$defaults['slider_mobile_slides']                       = 1;
		$defaults['slider_mobile_scrolls']                      = 1;
		$defaults['slider_lightbox']                            = 'no-link';
		$defaults['slider_syncing_nav_image_dimensions']        = 0;
		$defaults['slider_syncing_nav_image_crop']              = 0;
		$defaults['slider_image_info']                          = 0;
		$defaults['slider_image_info_position']                 = 'bot_outside';
		$defaults['slider_arrows_inside']                       = 1;

		return $defaults;
	}

	public function js_slider_config( $js_config, $settings ) {

		if ( 'slider' === $js_config['type'] ) {
			$js_config['slider_settings'] = array(
				'adaptiveHeight' => boolval( $settings['slider_adaptiveHeight'] ),
				'center'         => boolval( $settings['slider_centerMode'] ),
				'Dots'           => boolval( $settings['slider_dots'] ),
				'draggable'      => boolval( $settings['slider_draggable'] ),
				'transition'     => boolval( $settings['slider_fade'] ) ? 'fade' : 'slide',
				'infinite'       => boolval( $settings['slider_infinite'] ),
				'pauseOnHover'   => boolval( $settings['slider_pauseOnHover'] ),
				'slidesToShow'   => absint( $settings['slider_slidesToShow'] ),
				'slidesPerPage'  => absint( $settings['slider_slidesToScroll'] ),
				'direction'      => boolval( $settings['slider_rtl'] ) ? 'rtl' : 'ltr',
				'initialSlide'   => ( $settings['slider_initialSlide'] > 0 ) ? (int) $settings['slider_initialSlide'] - 1 : (int) $settings['slider_initialSlide'],
				'showCount'      => apply_filters( 'modula_show_slider_numbers', 0, $settings ),
			);

			if ( $settings['lazy_load'] ) {
				if ( isset( $settings['slider_adaptiveHeight'] ) && 1 !== absint( $settings['slider_adaptiveHeight'] ) ) {
					$js_config['slider_settings']['lazyLoad'] = 'ondemand';
				} else {
					$js_config['slider_settings']['lazyLoad'] = 'progressive';
				}
			}

			if ( isset( $settings['enable_responsive'] ) && 1 === absint( $settings['enable_responsive'] ) ) {
				$responsive = array(
					array(
						'breakpoint' => 1024,
						'settings'   => array(
							'slidesToShow'   => ( isset( $settings['slider_tablet_slides'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_tablet_slides'] ) : 1,
							'slidesToScroll' => ( isset( $settings['slider_tablet_scrolls'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_tablet_scrolls'] ) : 1,
						),
					),
					array(
						'breakpoint' => 600,
						'settings'   => array(
							'slidesToShow'   => ( isset( $settings['slider_mobile_slides'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_mobile_slides'] ) : 1,
							'slidesToScroll' => ( isset( $settings['slider_mobile_scrolls'] ) && 0 <= $settings['slider_tablet_scrolls'] ) ? absint( $settings['slider_mobile_scrolls'] ) : 1,
						),
					),
				);

				$js_config['slider_settings']['responsive'] = $responsive;
			}

			if ( isset( $settings['slider_draggable'] ) && 0 === absint( $settings['slider_draggable'] ) ) {
				$js_config['slider_settings']['Panzoom']['touch'] = false;
			}

			if ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) ) {
				$js_config['slider_settings']['Autoplay'] = array(
					'autoStart'    => true,
					'timeout'      => ( 0 <= absint( $settings['slider_autoplaySpeed'] ) ) ? absint( $settings['slider_autoplaySpeed'] ) : 3000,
					'pauseOnHover' => ( 0 <= absint( $settings['slider_pauseOnHover'] ) ) ? boolval( $settings['slider_pauseOnHover'] ) : false,
				);
			}

			if ( isset( $settings['slider_syncing'] ) && 1 === absint( $settings['slider_syncing'] ) ) {
				if ( isset( $settings['slider_syncing_nav_size'] ) && '' !== $settings['slider_syncing_nav_size'] ) {
					$js_config['slider_settings']['navSize'] = esc_js( $settings['slider_syncing_nav_size'] );
				}
				$js_config['slider_settings']['navSlides'] = absint( $settings['slider_syncing_nav_thumbnails_number'] );
			}

			$js_config['slider_settings']['MSplugins'] = array();
			if ( isset( $settings['slider_autoplay'] ) && 1 === absint( $settings['slider_autoplay'] ) ) {
				$js_config['slider_settings']['MSplugins']['Autoplay'] = true;
			}

			if ( ! isset( $settings['slider_arrows'] ) || 1 !== absint( $settings['slider_arrows'] ) ) {
				$js_config['slider_settings']['Navigation'] = false;
			}
			if ( isset( $settings['width'] ) && '' !== $settings['width'] ) {
				$js_config['slider_settings']['snapSlides'] = esc_js( strtolower( $settings['width'] ) );
			}
		}

		return $js_config;
	}


	public function change_effect( $template_data ) {

		if ( 'slider' !== $template_data['settings']['type'] ) {
			return $template_data;
		}

		$template_data['settings']['effect'] = 'slider';
		return $template_data;
	}

	/**
	 * Add extra path for modula templates
	 *
	 * @param $paths
	 *
	 * @return mixed
	 */
	public function add_modula_slider_templates_path( $paths ) {

		$paths[60] = trailingslashit( \MODULA_PRO_PATH ) . 'includes/extensions/slider/templates';
		return $paths;
	}

	/**
	 * Render Thumbnail navigation
	 *
	 * @param $settings
	 * @param $item_data
	 * @param $images
	 *
	 * @return void $html
	 */
	public function modula_slider_syncing( $settings, $item_data, $images, $display_context = 'classic' ) {
		// Beta mounts its own thumbnail rail. The server-rendered items remain the no-JS fallback.
		if ( 'beta' === $display_context ) {
			return;
		}

		if ( 'slider' === $settings['type'] && 1 === absint( $settings['slider_slidesToShow'] ) ) {
			if ( 1 === absint( $settings['slider_syncing'] ) ) {
				if ( ! empty( $images ) ) {
					global $_wp_additional_image_sizes;

					$images_count   = count( $images );
					$slides_count   = absint( $settings['slider_syncing_nav_thumbnails_number'] );
					$gutter_size    = absint( $settings['slider_syncing_nav_thumbnails_gutter'] );
					$slides_to_show = ( $slides_count > $images_count || 0 === $slides_count ) ? $images_count : $slides_count;

					$slider_width = '';
					if ( 'auto' === $settings['slider_syncing_nav_size'] ) {
						$slider_width = '100%';
					} elseif ( 'custom' === $settings['slider_syncing_nav_size'] ) {
						$slider_width = absint( ( $settings['slider_syncing_nav_image_dimensions']['width'] + $gutter_size ) * $slides_to_show ) . 'px';
					} else {
						$width               = 100;
						$default_image_sizes = get_intermediate_image_sizes();

						foreach ( $default_image_sizes as $size ) {
							$image_sizes[ $size ]['width']  = intval( get_option( "{$size}_size_w" ) );
							$image_sizes[ $size ]['height'] = intval( get_option( "{$size}_size_h" ) );
							$image_sizes[ $size ]['crop']   = get_option( "{$size}_crop" ) ? get_option( "{$size}_crop" ) : false;
						}

						if ( isset( $_wp_additional_image_sizes ) && count( $_wp_additional_image_sizes ) ) {
							$image_sizes = array_merge( $image_sizes, $_wp_additional_image_sizes );
						}

						if ( isset( $image_sizes[ $settings['slider_syncing_nav_size'] ] ) ) {
							$width = $image_sizes[ $settings['slider_syncing_nav_size'] ]['width'];
						}

						$slider_width = absint( ( $width * $slides_to_show ) + ( $gutter_size * ( $slides_to_show - 1 ) ) ) . 'px';
					}

					echo "<div class='modula-carousel-nav-wrapp'>";
					echo "<div class='modula-carousel-nav' style='width:" . esc_attr( $slider_width ) . "; max-width: 100%;'>";
					foreach ( $images as $index => $image ) {
						$thumbnail_src = '';

						if ( 'custom' !== $settings['slider_syncing_nav_size'] ) {
							$thumb = wp_get_attachment_image_src( $image['id'], $settings['slider_syncing_nav_size'] );

							if ( $thumb ) {
								$thumbnail_src = $thumb[0];
							}
						} else {
							$image_full = wp_get_attachment_image_src( $image['id'], 'full' );
							$width      = $settings['slider_syncing_nav_image_dimensions']['width'];
							$height     = $settings['slider_syncing_nav_image_dimensions']['height'];
							$crop       = boolval( $settings['slider_syncing_nav_image_crop'] );

							if ( ! $image_full ) {
								continue;
							}

							$resizer = new \Modula_Image();
							$resized = $resizer->resize_image( $image_full[0], $width, $height, $crop );

							// Let's check if resize gives us both URL and image info
							// Also, if resized_url is available, image_info should be available
							if ( isset( $resized['resized_url'] ) ) {
								$image_url = $resized['resized_url'];
							} else {
								$image_url = $resized;
							}

							if ( is_wp_error( $image_url ) ) {
								$image_url = $image_full[0];
							}

							$thumbnail_src = $image_url;
						}

						$thumbnail_src = apply_filters( 'modula_slider_thumbnail_src', $thumbnail_src, $image, $settings );

						if ( 'auto' !== $settings['slider_syncing_nav_size'] ) {
							$img_style = 'max-width: calc( ( 100% - ' . $gutter_size . 'px ) / 2 );width:' . absint( $width ) . 'px;margin:0 ' . ( $gutter_size ? absint( $gutter_size ) : 0 ) . 'px 0 0;';
						} else {
							$img_style = 'width: calc( ( 100% - ( ' . ( $slides_to_show - 1 ) . ' * ' . $gutter_size . 'px ) ) / ' . $slides_to_show . ' );margin:0 ' . ( $gutter_size ? absint( $gutter_size ) : 0 ) . 'px 0 0;';
						}

						echo "<div class='modula-slider-nav-item' style='" . esc_attr( $img_style ) . "'>";
							do_action( 'modula_slider_before_thumbnail', $image, $images, $settings );
						if ( '' !== $thumbnail_src ) {
							echo "<img class='modula-slider-nav-image'  src='" . esc_url( $thumbnail_src ) . "'>";
						}
							do_action( 'modula_slider_after_thumbnail', $image, $images, $settings );
						echo '</div>';
					}
					echo '</div>';
					echo '</div>';
				}
			}
		}
	}


	/**
	 * Sanitize slider fields
	 *
	 * @param $sanitized_value
	 * @param $value
	 * @param $field_id
	 * @param $field
	 *
	 * @return mixed
	 *
	 * @since 1.0.3
	 */
	public function sanitize_slider_fields( $sanitized_value, $value, $field_id, $field ) {

		if ( 'slider_image_dimensions' === $field_id ) {
			$new_value = array();
			if ( is_array( $value ) && ! empty( $value ) ) {
				foreach ( $value as $key => $img_size ) {
					$new_value[ $key ] = absint( $img_size );
				}
			}

			return $new_value;
		}

		return $sanitized_value;
	}

	/**
	 * Modula migration data
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $guest
	 *
	 * @return mixed
	 * @since 1.0.5
	 */
	public function modula_migrate_data( $modula_settings, $guest_settings, $guest ) {

		switch ( $guest ) {
			case 'foogallery':
				if ( 'image-viewer' === $guest_settings['grid_type'] ) {
					$modula_settings['type']                    = 'slider';
					$modula_settings['slider_image_size']       = 'custom';
					$modula_settings['slider_image_dimensions'] = array(
						'width'  => $guest_settings['image-viewer_thumbnail_size']['width'],
						'height' => $guest_settings['image-viewer_thumbnail_size']['height'],
					);
				}

				break;
		}

		return $modula_settings;
	}

	/**
	 * Adds modula slider troubleshooting field
	 *
	 * @param $fields
	 *
	 * @return array
	 * @since 1.1.2
	*/
	public function add_troubleshooting_fields( $fields ) {

		$fields['slider_scripts'] = array(
			'label'       => esc_html__( 'Slider Scripts & Styles', 'modula-pro' ),
			'description' => esc_html__( 'Check this if you\'re using slider type galleries', 'modula-pro' ),
			'type'        => 'toggle',
			'class'       => array( 'troubleshoot-subfield' ),
			'priority'    => 50,
		);

		return $fields;
	}

	/**
	 * Default values for modula slider troubleshooting field
	 *
	 * @param array $defaults Array of default values.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function add_troubleshooting_defaults( $defaults ) {
		$defaults['slider_scripts'] = false;

		return $defaults;
	}

	/**
	 * Files to be enqueued globally
	 *
	 * @param array $handles Array of handles to be enqueued.
	 * @param array $options Array of options.
	 *
	 * @return array
	 * @since 1.1.2
	 */
	public function add_main_slider_files( $handles, $options ) {

		if ( $options['slider_scripts'] ) {
			$handles['scripts'][] = 'modula-slider-script';
			$handles['scripts'][] = 'modula-pro';
			$handles['styles'][]  = 'modula-slider-css';
		}

		return $handles;
	}

	/**
	 * Add slider to allowed shuffle gallery types
	 *
	 * @param $allowed_types
	 *
	 * @return array
	 * @since 1.1.2
	*/
	public function add_slider_shuffle( $allowed_types ) {
		$allowed_types[] = 'slider';

		return $allowed_types;
	}

	public function add_video_icon_compat( $lightbox_settings, $settings ) {
		if ( ! class_exists( 'Modula_Video' ) || ! method_exists( 'Modula_Video', 'get_video_icon_svg' ) ) {
			return $lightbox_settings;
		}

		$icon = '';
		if ( isset( $settings['use-custom-icon'] ) && 1 === absint( $settings['use-custom-icon'] ) && isset( $settings['custom-video-icon'] ) && 0 !== absint( $settings['custom-video-icon'] ) ) {
			$icon = '<div class="modula-video-icon" ><img src ="' . esc_url( wp_get_attachment_image_src( absint( $settings['custom-video-icon'] ), 'full' )[0] ) . '"></div>';
		} else {
			$svg_data = isset( $settings['video-icon-icon'] ) ? \Modula_Video::get_video_icon_svg( $settings['video-icon-icon'] ) : \Modula_Video::get_video_icon_svg();
			$icon     = '<div class="modula-video-icon"><svg viewBox="0 0 24 24" aria-hidden="true" data-prefix="far" data-icon="play-circle" class="svg-inline--fa fa-play-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="#fff" d="' . esc_attr( $svg_data ) . '"></path></svg></div>';
		}
		$lightbox_settings['Thumbs']['thumbTpl'] = '<button class="f-thumbs__slide__button" tabindex="0" type="button" aria-label="{{GOTO}}" data-carousel-index="%i">
														<img class="f-thumbs__slide__img" data-lazy-src="{{%s}}" alt="" />
														' . ( $icon ) . '
													</button>';
		return $lightbox_settings;
	}

	public static function get_thumbnail_nav_sizes() {
		return array_merge( array( 'auto' => __( 'Auto', 'modula-pro' ) ), \Modula_Helper::get_image_sizes( true ) );
	}

	/**
	 * Filter the REST API response
	 *
	 * @param $settings
	 *
	 * @return array
	 * @since 1.1.13
	*/
	public function rest_api_filter_data( $response, $post, $request ) {
		$data = $response->get_data();

		// Partial REST responses (e.g. `_fields`) may omit gallery meta.
		if ( empty( $data['modulaSettings'] ) || ! is_array( $data['modulaSettings'] ) ) {
			return $response;
		}

		$modula_settings = $data['modulaSettings'];
		if ( ! isset( $modula_settings['type'] ) || 'slider' !== $modula_settings['type'] ) {
			return $response;
		}

		if ( empty( $data['modulaImages'] ) || ! is_array( $data['modulaImages'] ) ) {
			return $response;
		}

		$modula_images = $data['modulaImages'];

		foreach ( $modula_images as $key => $image ) {
			$image_data = wp_get_attachment_image_src( $image['id'], 'full' );
			if ( $image_data ) {
				list($url, $width, $height) = $image_data;
				// Set proper width and height for the response
				if ( isset( $image['width'] ) ) {
					$data['modulaImages'][ $key ]['data-width'] = $width;
				}
				if ( isset( $image['height'] ) ) {
					$data['modulaImages'][ $key ]['data-height'] = $height;
				}
				$data['modulaImages'][ $key ]['src'] = $url;
			}
		}
		// Set the new data
		$response->set_data( $data );
		return $response;
	}

	public function add_caption_title_top( $data ) {
		if ( ! isset( $data->slider_image_info ) || '1' !== $data->slider_image_info ) {
			return;
		}

		if ( ! in_array( $data->slider_image_info_position, array( 'top_outside', 'top_inside' ), true ) ) {
			return;
		}

		$this->add_caption_title( $data );
	}

	public function add_caption_title_bottom( $data ) {
		if ( ! isset( $data->slider_image_info ) || '1' !== $data->slider_image_info ) {
			return;
		}
		if ( ! in_array( $data->slider_image_info_position, array( 'bot_outside', 'bot_inside' ), true ) ) {
			return;
		}

		$this->add_caption_title( $data );
	}

	public function add_caption_title( $data ) {

		$output = '<div class="slider-image-info ' . esc_attr( $data->slider_image_info_position ) . '">';

		if ( ! $data->hide_title ) {
			$output .= sprintf(
				"<p class='jtg-title'>%s</p>",
				wp_kses_post( $data->title )
			);
		}

		if ( ! $data->hide_description ) {
			$output .= sprintf(
				'<p class="description">%s</p>',
				wp_kses_post( $data->description )
			);
		}

		$output .= '</div>';

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $output;
	}
}
