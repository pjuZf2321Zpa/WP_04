<?php

namespace Modula_Pro\Extensions\Albums;

use Modula_Pro\Extensions\Albums\Utils\Albums_Template_Loader;
use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Albums\V2\Album_Sections;
use Modula_Pro\Extensions\Albums\V2\Lightbox_Visitor_Config;
use Modula_Pro\Extensions\Albums\V2\Members_Document;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {

	private $loader;

	/**
	 * Modula_Albums_Shortcode constructor.
	 */
	public function __construct() {

		$this->loader = new Albums_Template_Loader();

		add_shortcode( 'modula-album', array( $this, 'album_shortcode_handler' ) );

		// Add shortcode related hooks
		add_filter( 'modula_album_shortcode_item_data', 'modula_album_generate_image_links', 10, 4 );
		add_filter( 'modula_album_shortcode_item_data', 'modula_album_check_lightboxes_and_links', 15, 4 );
		add_filter( 'modula_album_shortcode_item_data', 'modula_album_check_hover_effect', 20, 4 );
		add_filter( 'modula_album_shortcode_item_data', 'modula_album_check_custom_grid', 25, 1 );
		add_filter( 'modula_album_shortcode_item_data', 'modula_album_enable_lazy_load', 30, 4 );
		// Manipulate the gallery settings
		add_filter( 'modula_album_shortcode_gallery_setting', array( $this, 'manipulate_gallery_settings' ), 15, 3 );

		add_action( 'modula_album_shortcode_before_items', array( $this, 'add_album_navigation_above' ), 200, 3 );
		add_action( 'modula_album_shortcode_after_items', array( $this, 'add_album_navigation_below' ), 200, 3 );
		add_action( 'modula_album_shortcode_after_items', array( $this, 'add_back_to_album_button' ), 300, 3 );

		add_filter( 'modula_albums_backwards_compatibility_front', array( $this, 'backward_compatibility_front_responsive_gutter' ) );
		add_filter( 'modula_albums_backwards_compatibility_front', array( $this, 'backward_compatibility_front_grid_type' ) );
		add_filter( 'modula_album_default_settings', array( $this, 'backward_compatibility_default_album_width' ), 100 );
	}

	public function album_shortcode_handler( $atts ) {
		$default_atts = array(
			'id'    => false,
			'align' => '',
		);

		$atts = wp_parse_args( $atts, $default_atts );

		if ( ! $atts['id'] || 'modula-album' != get_post_type( $atts['id'] ) ) {
			return esc_html__( 'Album not found.', 'modula-pro' );
		}

		// Classic and beta albums alike: a private or draft album stays hidden from visitors who can't read it.
		if ( ! Members_Document::is_visitor_readable_album( $atts['id'] ) ) {
			return esc_html__( 'This album is not published.', 'modula-pro' );
		}

		/* Generate uniq id for this album */
		$gallery_id = 'jtg-album-' . $atts['id'];

		/* Get album settings */
		$settings = apply_filters( 'modula_albums_backwards_compatibility_front', modula_albums_get_album_settings( $atts['id'] ) );

		$pre_gallery_html = apply_filters( 'modula_albums_pre_output_filter_check', false, $settings, $atts['id'] );

		if ( false !== $pre_gallery_html ) {

			// If there is HTML, then we stop trying to display the gallery and return THAT HTML.
			$pre_output = apply_filters( 'modula_albums_pre_output_filter', '', $settings, $atts['id'] );
			return $pre_output;
		}

		$type       = isset( $settings['type'] ) ? $settings['type'] : 3;
		$album_type = isset( $settings['album_type'] ) ? $settings['album_type'] : 'grid';

		$default           = Fields_Helper::get_defaults();
		$settings          = wp_parse_args( $settings, $default );
		$galleries         = get_post_meta( $atts['id'], 'modula-album-galleries', true );
		$script_manager    = \Modula_Script_Manager::get_instance();
		$necessary_scripts = array();

		/* Get gallery images */
		$galleries = apply_filters( 'modula_album_before_shuffle_galleries', $galleries, $settings );

		$galleries = Members_Document::with_repaired_titles( Members_Document::visitor_readable_members( $galleries ) );

		// Return early if no galleries to show.
		if ( empty( $galleries ) ) {
			return esc_html__( 'There are no items to display.', 'modula-pro' );
		}

		$shuffle_permitted = apply_filters( 'modula_album_shuffle_grid_types', array( '1', '2', '3', '4', '5', '6' ), $settings );

		if ( isset( $settings['shuffle_galleries'] ) && '1' === $settings['shuffle_galleries'] && in_array( $type, $shuffle_permitted, true ) ) {
			shuffle( $galleries );
		}

		if ( '1' === $settings['lazy_load'] ) {
			$necessary_scripts[] = 'modula-lazysizes';
		}

		if ( in_array( $settings['effect'], array( 'tilt_1', 'tilt_3', 'tilt_7' ), true ) ) {
			$necessary_scripts[] = 'modula-pro-tilt';
		}

		$necessary_scripts[] = 'modula-fancybox';
		$necessary_scripts[] = 'modula-isotope';
		$necessary_scripts[] = 'modula-isotope-packery';
		$necessary_scripts[] = 'modula-albums';

		/* Enqueue lightbox related scripts & styles */
		do_action( 'modula_album_extra_scripts', $settings );

		// Main CSS & JS
		$necessary_scripts = apply_filters( 'modula_album_necessary_scripts', $necessary_scripts, $settings );

		$necessary_styles = apply_filters( 'modula_album_necessary_styles', array( 'modula-album-grid-system', 'modula-fancybox', 'modula' ), $settings );

		if ( ! empty( $necessary_scripts ) ) {
			foreach ( $necessary_scripts as $script ) {
				$script_manager->add_script( $script );
			}
		}

		if ( ! empty( $necessary_styles ) ) {
			foreach ( $necessary_styles as $style ) {
				wp_enqueue_style( $style );
			}
		}

		$settings['gallery_id'] = $gallery_id;
		$settings['align']      = ( isset( $atts['align'] ) && '' !== $atts['align'] ) ? 'align' . $atts['align'] : '';

		$has_album   = false;
		$has_gallery = false;
		foreach ( $galleries as $gallery ) {
			if ( isset( $gallery['itemType'] ) && 'modula-album' === $gallery['itemType'] ) {
				$has_album = true;
				if ( $has_gallery ) {
					break;
				}
			}
			if ( ! isset( $gallery['itemType'] ) || ( isset( $gallery['itemType'] ) && 'modula-gallery' === $gallery['itemType'] ) ) {
				$has_gallery = true;
				if ( $has_album ) {
					break;
				}
			}
		}

		$template_data = array(
			'album_id'        => $atts['id'],
			'settings'        => $settings,
			'galleries'       => $galleries,
			'has_album'       => $has_album,
			'has_gallery'     => $has_gallery,
			'loader'          => $this->loader,
			// Gallery container attributes
			'album_container' => array(
				'id'    => $gallery_id,
				'class' => ( 'custom-grid' === $album_type ) ? array( 'modula', 'modula-album', 'modula-custom-grid', $settings['align'] ) : array( 'modula', 'modula-album', 'modula-grid', $settings['align'] ),
			),

			// Items container attributes
			'items_container' => array(
				'class' => array( 'modula-items' ),
			),
		);

		ob_start();

		/* Config for gallery script */
		$js_config = array(
			'type'              => $type,
			'columns'           => 12,
			'albumType'         => $album_type,
			'gutter'            => isset( $settings['gutter'] ) ? absint( $settings['gutter'] ) : 10,
			'mobileGutter'      => isset( $settings['mobile_gutter'] ) ? absint( $settings['mobile_gutter'] ) : 10,
			'tabletGutter'      => isset( $settings['tablet_gutter'] ) ? absint( $settings['tablet_gutter'] ) : 10,
			'enableResponsive'  => isset( $settings['enable_responsive'] ) ? $settings['enable_responsive'] : 1,
			'tabletColumns'     => isset( $settings['tablet_columns'] ) ? $settings['tablet_columns'] : 2,
			'mobileColumns'     => isset( $settings['mobile_columns'] ) ? $settings['mobile_columns'] : 1,
			'lazyLoad'          => isset( $settings['lazy_load'] ) ? $settings['lazy_load'] : 1,
			'lightbox'          => isset( $settings['enable_lightbox'] ) ? 'fancybox' : false,
			'lightbox_settings' => array(
				'animated'      => true,
				'Thumbs'        => array(
					'type' => 'modern',
				),
				'Toolbar'       => array(
					'display' => array(
						'right' => array(
							'close',
						),
					),
				),
				'Carousel'      => array(
					'infinite'   => false,
					'transition' => 'slide',
					'Panzoom'    => array(
						'touch' => false,
					),
				),
				'touch'         => false,
				'backdropClick' => false, //The action to perform when the user clicks on the backdrop
				'i18n'          => array(
					'CLOSE'       => esc_html__( 'Close', 'modula-pro' ),
					'NEXT'        => esc_html__( 'Next', 'modula-pro' ),
					'PREV'        => esc_html__( 'Previous', 'modula-pro' ),
					'Error'       => esc_html__( 'The requested content cannot be loaded. Please try again later.', 'modula-pro' ),
					'PLAY_START'  => esc_html__( 'Start slideshow', 'modula-pro' ),
					'PLAY_STOP'   => esc_html__( 'Pause slideshow', 'modula-pro' ),
					'FULL_SCREEN' => esc_html__( 'Full screen', 'modula-pro' ),
					'THUMBS'      => esc_html__( 'Thumbnails', 'modula-pro' ),
					'DOWNLOAD'    => esc_html__( 'Download', 'modula-pro' ),
					'SHARE'       => esc_html__( 'Share', 'modula-pro' ),
					'ZOOM'        => esc_html__( 'Zoom', 'modula-pro' ),
				),
				'Images'        => array(
					'Panzoom' => array(),
				),
				'wheel'         => false,
			),
		);
		// Same breakpoints as the album CSS, for the visitor script's gutter.
		list( $js_config['treatAsPhoneUnder'], $js_config['treatAsTabletUnder'] ) = \Modula_Pro\Extensions\Albums\V2\Responsive_Breakpoints::from_flat( $settings );

		$js_config['lightbox_settings']['Toolbar']['display']['right'] = array();
		$js_config['lightbox_settings']['Toolbar']['enabled']          = true;
		if ( isset( $settings['enable_thumbs'] ) && 1 === (int) $settings['enable_thumbs'] ) {
			$js_config['lightbox_settings']['Toolbar']['display']['right'][] = 'thumbs';
		}
		$js_config['lightbox_settings']['mainClass'] = 'modula-fancybox-container modula-lightbox-' . $gallery_id;

		// Display thumbnails on opening
		if ( isset( $settings['autostart_thumbs'] ) && 1 === (int) $settings['autostart_thumbs'] ) {
			$js_config['lightbox_settings']['Thumbs']['showOnStart'] = true;
		} else {
			$js_config['lightbox_settings']['Thumbs']['showOnStart'] = false;
		}

		if ( isset( $settings['lightbox_thumbsPosition'] ) ) {
			$js_config['Thumbs']['position'] = $settings['lightbox_thumbsPosition'];
		}

		if ( isset( $settings['enable_download'] ) && 1 === (int) $settings['enable_download'] ) {
			$js_config['lightbox_settings']['Toolbar']['display']['right'][] = 'download';
		}

		if ( isset( $settings['enable_share'] ) && 1 === (int) $settings['enable_share'] ) {
			$js_config['lightbox_settings']['Toolbar']['items']['share']['tpl'] = '<button data-fancybox-share class="f-button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M2.55 19c1.4-8.4 9.1-9.8 11.9-9.8V5l7 7-7 6.3v-3.5c-2.8 0-10.5 2.1-11.9 4.2z"/></svg></button>';

			$js_config['lightbox_settings']['Toolbar']['display']['right'][] = 'share';
			if ( isset( $settings['lightbox_facebook'] ) && 1 === (int) $settings['lightbox_facebook'] ) {
				$js_config['lightbox_settings']['modulaShare'][] = 'facebook';
			}

			if ( isset( $settings['lightbox_twitter'] ) && 1 === (int) $settings['lightbox_twitter'] ) {
				$js_config['lightbox_settings']['modulaShare'][] = 'twitter';
			}

			if ( isset( $settings['lightbox_whatsapp'] ) && 1 === (int) $settings['lightbox_whatsapp'] ) {
				$js_config['lightbox_settings']['modulaShare'][] = 'whatsapp';
			}

			if ( isset( $settings['lightbox_linkedin'] ) && 1 === (int) $settings['lightbox_linkedin'] ) {
				$js_config['lightbox_settings']['modulaShare'][] = 'linkedin';
			}

			if ( isset( $settings['lightbox_pinterest'] ) && 1 === (int) $settings['lightbox_pinterest'] ) {
				$js_config['lightbox_settings']['modulaShare'][] = 'pinterest';
			}

			if ( isset( $settings['lightbox_email'] ) && 1 === (int) $settings['lightbox_email'] ) {
				$js_config['lightbox_settings']['modulaShare'][] = 'email';
			}

			if ( isset( $settings['lightboxEmailSubject'] ) ) {
				$js_config['lightbox_settings']['lightboxEmailSubject'] = esc_html( $settings['lightboxEmailSubject'] );
			} else {
				$js_config['lightbox_settings']['lightboxEmailSubject'] = esc_html__( 'Check out this awesome album !!', 'modula-pro' );
			}

			if ( isset( $settings['lightboxEmailMessage'] ) ) {
				$js_config['lightbox_settings']['lightboxEmailMessage'] = esc_html( $settings['lightboxEmailMessage'] );
			} else {
				$js_config['lightbox_settings']['lightboxEmailMessage'] = esc_html__( 'Here is the link to the image : %%image_link%% and this is the link to the gallery : %%gallery_link%% ', 'modula-pro' );
			}
		}

		if ( isset( $settings['enable_zoom'] ) && 1 === (int) $settings['enable_zoom'] ) {
			$js_config['lightbox_settings']['Toolbar']['display']['right'][] = 'iterateZoom';
		}

		if ( isset( $settings['enable_play'] ) && 1 === (int) $settings['enable_play'] ) {
			$js_config['lightbox_settings']['Toolbar']['display']['right'][] = 'slideshow';
		}

		if ( isset( $settings['transition_effect'] ) ) {
			$js_config['lightbox_settings']['Carousel']['transition'] = $settings['transition_effect'];
		}

		if ( isset( $settings['animation_effect'] ) && 'false' !== $settings['animation_effect'] ) {
			$js_config['lightbox_settings']['Images']['zoom'] = false;
			$js_config['lightbox_settings']['showClass']      = 'm-' . $settings['animation_effect'] . 'In';
			$js_config['lightbox_settings']['hideClass']      = 'm-' . $settings['animation_effect'] . 'Out';
		}

		$js_config['lightbox_settings']['Toolbar']['display']['right'][] = 'close';

		$js_config['lightbox_settings']['lightbox_devices'] = apply_filters( 'modula_lightbox_devices', 'both' );
		$js_config['lightbox_devices']                      = apply_filters( 'modula_lightbox_devices', 'both' );

		if ( isset( $settings['doubleClick'] ) && 1 === (int) $settings['doubleClick'] ) {
			$js_config['lightbox_settings']['mobileDoubleClick'] = 1;
		}

		if ( isset( $settings['loop_lightbox'] ) && 1 === (int) $settings['loop_lightbox'] ) {
			$js_config['lightbox_settings']['Carousel']['infinite'] = true;
		}
		$js_config['lightbox_settings']['keyboard'] = apply_filters( 'modula_lightbox_keyboard', true ) ? array(
			'Escape'     => 'close',
			'Delete'     => 'close',
			'Backspace'  => 'close',
			'PageUp'     => 'next',
			'PageDown'   => 'prev',
			'ArrowUp'    => 'prev',
			'ArrowDown'  => 'next',
			'ArrowRight' => 'next',
			'ArrowLeft'  => 'prev',
		) : false;

		$js_config['lightbox_settings']['wheel'] = apply_filters( 'modula_lightbox_wheel', true );

		if ( apply_filters( 'modula_lightbox_click_slide', true ) ) {
			$js_config['lightbox_settings']['backdropClick'] = 'close';
		}

		if ( isset( $settings['lightbox_infobar'] ) && 1 === (int) $settings['lightbox_infobar'] ) {
			$js_config['lightbox_settings']['Toolbar']['display']['left'][] = 'infobar';
		} else {
			$js_config['lightbox_settings']['Toolbar']['display']['left'] = array();
		}

		if ( isset( $settings['transition_effect'] ) ) {
			$js_config['lightbox_settings']['Carousel']['transition'] = $settings['transition_effect'];
		}

		if ( isset( $settings['animation_effect'] )
			&& 'false' !== $settings['animation_effect'] ) {
			$js_config['lightbox_settings']['Images']['zoom'] = false;
			$js_config['lightbox_settings']['showClass']      = 'm-' . $settings['animation_effect'] . 'In';
			$js_config['lightbox_settings']['hideClass']      = 'm-' . $settings['animation_effect'] . 'Out';
		}

		if ( isset( $settings['enable_slideshow'] ) && 1 === (int) $settings['enable_slideshow'] ) {
			$js_config['lightbox_settings']['Slideshow']['playOnStart'] = true;
			$js_config['lightbox_settings']['Slideshow']['timeout']     = Lightbox_Visitor_Config::resolve_slideshow_timeout( $settings );
			if ( isset( $settings['loop_lightbox'] ) && 1 === (int) $settings['loop_lightbox'] ) {
				$js_config['lightbox_settings']['Carousel']['infinite'] = true;
			}
		}

		if ( apply_filters( 'modula_lightbox_caption_copy', false ) && wp_is_mobile() ) {
			$js_config['lightbox_settings']['copyCaptionMobile'] = 1;
		}

		$template_data['js_config']                      = apply_filters( 'modula_album_js_config', $js_config, $settings );
		$template_data['album_container']['data-config'] = wp_json_encode( $js_config );

		$template_data = apply_filters( 'modula_album_template_data', $template_data );

		if ( ! isset( $settings['merge_items'] ) || boolval( $settings['merge_items'] ) ) {
			echo $this->generate_album_css( $gallery_id, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$this->loader->set_template_data( $template_data );
			$this->loader->get_template_part( 'modula', 'albums' );
		} else {
			$this->render_separate_sections( $template_data, $settings, Album_Sections::container_ids( $gallery_id, $has_album, $has_gallery ) );
		}

		$html = ob_get_clean();

		return $html;
	}

	/**
	 * Render the albums and galleries sections, each with its own container id.
	 *
	 * Album CSS is scoped to the container id (including `#id.modula-album` and
	 * `#id.modula-slider` rules from extensions), so each section gets its own
	 * copy. All styles print before the sections to keep them adjacent siblings.
	 *
	 * @param array                $template_data Filtered album template data.
	 * @param array                $settings      Album settings, as the merged layout passes them to the CSS.
	 * @param array<string,string> $section_ids   Template slug => container id, from Album_Sections::container_ids().
	 * @return void
	 */
	private function render_separate_sections( $template_data, $settings, $section_ids ) {
		foreach ( $section_ids as $container_id ) {
			echo $this->generate_album_css( $container_id, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		foreach ( $section_ids as $template => $container_id ) {
			$template_data['album_container']['id'] = $container_id;
			$this->loader->set_template_data( $template_data );
			$this->loader->get_template_part( 'modula', $template );
		}
	}

	/**
	 * @param $gallery_id
	 * @param $settings
	 * @return mixed|string|void
	 *
	 * Generate CSS for each Gallery
	 */
	private function generate_album_css( $gallery_id, $settings ) {

		$no_height = array( 'zoe', 'fluid-up' );
		$css       = '<style>';

		if ( 'custom-grid' !== $settings['album_type'] ) {
			if ( isset( $settings['album_width'] ) ) {
				if ( 'auto' === $settings['album_width'] ) {
					$css .= "#{$gallery_id} { width:auto; }";
				} elseif ( 'full' === $settings['album_width'] ) {
					$css .= "#{$gallery_id} { width:100%; }";
				} else {
					$css .= "#{$gallery_id} { width:" . esc_attr( $settings['width'] ) . ';}';
				}
			} else {
				$css .= "#{$gallery_id} { width:" . esc_attr( $settings['width'] ) . ';}';
			}

			if ( 1 === absint( $settings['enable_responsive'] ) ) {
				list( $phone_under, $tablet_under ) = \Modula_Pro\Extensions\Albums\V2\Responsive_Breakpoints::from_flat( $settings );
				$queries                            = \Modula_Pro\Extensions\Albums\V2\Responsive_Breakpoints::media_queries( $phone_under, $tablet_under );

				$css .= "@media {$queries['tablet']} { #{$gallery_id}.modula-album .modula-items .modula-item, .modula-album .modula-grid-sizer { width: calc(" . 100 / $settings['tablet_columns'] . '% - ' . ( absint( $settings['tablet_gutter'] ) - absint( $settings['tablet_gutter'] ) / absint( $settings['tablet_columns'] ) ) . 'px) !important ; }  }';

				$css .= "@media {$queries['mobile']} { #{$gallery_id}.modula-album .modula-items .modula-item, .modula-album .modula-grid-sizer { width: calc(" . 100 / $settings['mobile_columns'] . '% - ' . ( absint( $settings['mobile_gutter'] ) - absint( $settings['mobile_gutter'] ) / absint( $settings['mobile_columns'] ) ) . 'px) !important ; }  }';
			}
		} else {
			$css .= "#{$gallery_id}, #{$gallery_id} .modula-items { width:100%; }";
		}

		if ( '' !== $settings['captionColor'] || '' !== $settings['captionFontSize'] ) {
			$css .= "#{$gallery_id} .modula-items .figc p.description,#{$gallery_id} .modula-items .figc .jtg-body *,#{$gallery_id} .modula-items .figc .jtg-description {";

			if ( '' !== $settings['captionColor'] ) {
				$css .= 'color:' . sanitize_hex_color( $settings['captionColor'] ) . ';';
			}

			if ( '0' !== $settings['captionFontSize'] ) {
				$css .= 'font-size:' . absint( $settings['captionFontSize'] ) . 'px;';
			} else {
				$css .= 'font-size:inherit;';
			}
			$css .= '}';
		}

		if ( '' !== $settings['titleColor'] || '' !== $settings['titleFontSize'] ) {
			$css .= "#{$gallery_id} .modula-items .figc .jtg-title {";

			if ( '' !== $settings['titleColor'] ) {
				$css .= 'color:' . sanitize_hex_color( $settings['titleColor'] ) . ';';
			}

			if ( '0' !== $settings['titleFontSize'] ) {
				$css .= 'font-size:' . absint( $settings['titleFontSize'] ) . 'px;';
			} else {
				$css .= 'font-size:inherit;';
			}
			$css .= '}';
		}

		$css .= '#' . $gallery_id . '.modula-album .modula-items .modula-item{ background-color: ' . sanitize_hex_color( $settings['hoverColor'] ) . '; }';
		$css .= '#' . $gallery_id . '.modula-album .modula-items .modula-item.effect-under .figc{ background-color: ' . sanitize_hex_color( $settings['backgroundColor'] ) . '; }';
		$css .= '#' . $gallery_id . '.modula-album .modula-items .modula-item:hover img.pic { opacity:' . round( absint( $settings['hoverOpacity'] ) / 100, 1 ) . ';}';
		$css .= '#' . $gallery_id . '.modula-album .modula-items .modula-item:hover picture.pic { opacity:' . round( absint( $settings['hoverOpacity'] ) / 100, 1 ) . ';}';

		if ( '0' !== $settings['imageCountFontSize'] ) {
			$css .= "#{$gallery_id} .modula-items .figc .jtg-title .image_count { font-size:" . absint( $settings['imageCountFontSize'] ) . 'px }';
		} else {
			$css .= "#{$gallery_id} .modula-items .figc .jtg-title .image_count { font-size:inherit; }";
		}

		if ( '' !== $settings['imageCountColor'] ) {
			$css .= "#{$gallery_id} .modula-items .figc .jtg-title .image_count { color:" . sanitize_hex_color( $settings['imageCountColor'] ) . '; }';
		}

		// Responsive fixes
		$css .= '@media screen and (max-width:480px){';

		if ( '' !== $settings['mobileTitleFontSize'] && 0 !== $settings['mobileTitleFontSize'] ) {
			$css .= "#{$gallery_id} .modula-item .figc .jtg-title {  font-size: " . absint( $settings['mobileTitleFontSize'] ) . 'px; }';
		}

		$css .= "#{$gallery_id} .modula-items .figc p.description,#{$gallery_id} .modula-items .figc .jtg-body *, #{$gallery_id} .modula-items .figc .jtg-description { color:" . sanitize_hex_color( $settings['captionColor'] ) . ';font-size:' . absint( $settings['mobileCaptionFontSize'] ) . 'px; }';

		$css .= '}';

		// Cursor
		if ( 'custom' !== $settings['cursor'] ) {
			$css .= "#{$gallery_id} .modula-item> .modula-item-content > a { cursor:" . esc_attr( $settings['cursor'] ) . '; } ';
		} elseif ( 0 !== absint( $settings['uploadCursor'] ) ) {
				$image_src = wp_get_attachment_image_src( $settings['uploadCursor'] );
				$css      .= "#{$gallery_id} .modula-item> .modula-item-content > a { cursor:url(" . esc_url( $image_src[0] ) . '),auto ; } ';
		}
		if ( 'grid' === $settings['album_type'] ) {
			$css .= "#{$gallery_id}.modula-album .modula-item { width: calc(" . 100 / absint( $settings['type'] ) . '% - ' . ( absint( $settings['gutter'] ) - absint( $settings['gutter'] ) / absint( $settings['type'] ) ) . 'px) !important ; } ';
			$css .= "#{$gallery_id} .modula-items{position:relative;}";
		}

		$css .= "#{$gallery_id} .modula-items > .modula-item > .modula-item-content > .figc>.figc-inner { padding:" . absint( $settings['hoverPadding'] ) . 'px; } ';

		$css = apply_filters( 'modula_album_shortcode_css', $css, $gallery_id, $settings );

		$css .= "#{$gallery_id}  .modula-item.effect-oscar { background: -webkit-linear-gradient(45deg," . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#9b4a1b 40%,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 100%);background: linear-gradient(45deg,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#9b4a1b 40%,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 100%);}';

		$css .= "#{$gallery_id}  .modula-item.effect-roxy {background: -webkit-linear-gradient(45deg," . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#05abe0 100%);background: linear-gradient(45deg,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#05abe0 100%);}';

		$css .= "#{$gallery_id} .modula-item.effect-dexter {background: -webkit-linear-gradient(top," . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,rgba(104,60,19,1) 100%); background: linear-gradient(to bottom,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,rgba(104,60,19,1) 100%);}';

		$css .= "#{$gallery_id}  .modula-item.effect-jazz {background: -webkit-linear-gradient(-45deg," . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#f33f58 100%);background: linear-gradient(-45deg,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#f33f58 100%);}';

		$css .= "#{$gallery_id} .modula-item.effect-lexi {background: -webkit-linear-gradient(-45deg," . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#fff 100%);background: linear-gradient(-45deg,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#fff 100%);}';

		$css .= "#{$gallery_id} .modula-item.effect-duke {background: -webkit-linear-gradient(-45deg," . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#cc6055 100%);background: linear-gradient(-45deg,' . \modula_pro_sanitize_color( $settings['hoverColor'] ) . ' 0,#cc6055 100%);}';

		if ( ! isset( $settings['enable_navigation'] ) || 1 !== absint( $settings['enable_navigation'] ) ) {
			$css .= 'html body .modula-fancybox-container.modula-lightbox-' . $gallery_id . ' .fancybox__nav{display:none}';
			$css .= 'html body .modula-fancybox-container.modula-lightbox-' . $gallery_id . ' .f-button.is-arrow.is-prev,html body .modula-fancybox-container.modula-lightbox-' . $gallery_id . ' .f-button.is-arrow.is-next{display:none}';
		}

		// caption positioning
		if ( isset( $settings['captionPosition'] ) ) {
			$css .= '.modula-fancybox-container.modula-lightbox-' . $gallery_id . ' .fancybox__caption {text-align:' . esc_attr( $settings['captionPosition'] ) . '}';
		}

		if ( isset( $settings['lightbox_background_color'] ) && '' !== $settings['lightbox_background_color'] ) {
			$css .= '.modula-fancybox-container.modula-lightbox-' . $gallery_id . ' .fancybox__backdrop{background:' . modula_pro_sanitize_color( $settings['lightbox_background_color'] ) . ';opacity:1 !important;}';
		}

		$css .= "</style>\n";

		return $css;
	}

	public function add_album_navigation_above( $settings, $data, $type = 'all' ) {

		$parent_album_id = wp_get_post_parent_id( $data->album_id );

		if ( ! $parent_album_id ) {
			return false;
		}

		$parent_settings = modula_albums_get_album_settings( $parent_album_id );

		if ( ! isset( $parent_settings['albums_navigation'] ) || ( 'above' !== $parent_settings['albums_navigation'] && 'above_below' !== $parent_settings['albums_navigation'] ) ) {
			return false;
		}

		if ( ! Album_Sections::is_first( $type, $data ) ) {
			return false;
		}

		modula_add_album_navigation_button( $data->album_id );
	}

	public function add_album_navigation_below( $settings, $data, $type = 'all' ) {

		$parent_album_id = wp_get_post_parent_id( $data->album_id );

		if ( ! $parent_album_id ) {
			return false;
		}

		$parent_settings = modula_albums_get_album_settings( $parent_album_id );

		if ( ! isset( $parent_settings['albums_navigation'] ) || ( 'below' !== $parent_settings['albums_navigation'] && 'above_below' !== $parent_settings['albums_navigation'] ) ) {
			return false;
		}

		if ( ! Album_Sections::is_last( $type, $data ) ) {
			return false;
		}

		modula_add_album_navigation_button( $data->album_id );
	}

	public function add_back_to_album_button( $settings, $data, $type = 'all' ) {

		if ( ! Album_Sections::is_last( $type, $data ) ) {
			return false;
		}

		modula_add_back_to_album_button();
	}

	/**
	 *  Backwards compatibility for responsive gutter
	 *
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.3.0
	 */
	public function backward_compatibility_front_responsive_gutter( $settings ) {

		// Backwards compatibility for tablet & mobile gutter.
		if ( isset( $settings['gutter'] ) ) {
			if ( ! isset( $settings['tablet_gutter'] ) ) {
				$settings['tablet_gutter'] = absint( $settings['gutter'] );
			}

			if ( ! isset( $settings['mobile_gutter'] ) ) {
				$settings['mobile_gutter'] = absint( $settings['gutter'] );
			}
		}

		return $settings;
	}

	/**
	 * Backwards compatibility for default album width
	 *
	 * @param $value
	 * @param $key
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.3.0
	 */
	public function backward_compatibility_default_album_width( $defaults ) {
		global $post;

		if ( ! isset( $post->ID ) ) {
			return $defaults;
		}

		$settings = get_post_meta( $post->ID, 'modula-album-settings', true );

		// Check if album_width was previously saved.
		if ( isset( $settings['album_width'] ) ) {
			return $defaults;
		}

		// Check if first time save.
		if ( ! isset( $settings['album_width'] ) && ! isset( $settings['width'] ) ) {
			return $defaults;
		}

		$defaults['album_width'] = 'custom';

		return $defaults;
	}

	/**
	 *  Backwards compatibility for grid type
	 *
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.3.0
	 */
	public function backward_compatibility_front_grid_type( $settings ) {

		if ( isset( $settings['type'] ) && 'custom-grid' === $settings['type'] ) {
			$settings['album_type'] = 'custom-grid';
		}

		return $settings;
	}

	/**
	 * Manipulate the gallery settings
	 *
	 * @param array $gallery_settings
	 * @param array $album_settings
	 * @param array $gallery
	 * @return array
	 */
	public function manipulate_gallery_settings( $gallery_settings, $album_settings, $gallery ) {
		$gallery_settings['gallery_id'] = $gallery['id'];

		return $gallery_settings;
	}
}
