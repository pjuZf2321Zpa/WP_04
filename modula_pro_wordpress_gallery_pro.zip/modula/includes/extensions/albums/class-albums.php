<?php
namespace Modula_Pro\Extensions\Albums;

use Modula_Pro\Extensions\Albums\Albums_Gutenberg;
use Modula_Pro\Extensions\Albums\Beaver\Albums_Beaver;
use Modula_Pro\Extensions\Albums\Shortcode;
use Modula_Pro\Extensions\Albums\CPT\Album;
use Modula_Pro\Extensions\Albums\Elementor\Albums_Elementor_Check;
use Modula_Pro\Extensions\Albums\Utils\Albums_Template_Loader;
use Modula_Pro\Extensions\Albums\Utils\Duplicator;
use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Albums\Utils\Hover_Effects;
use Modula_Pro\Extensions\Albums\V2\Visitor\Dispatcher;
use Modula_Pro\Extensions\Albums\V2\Visitor\Renderer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Albums {
	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'init' ) );
		$this->init_albums_editor_v2();
		new Albums_Template_Loader();

		// Include assets
		new Fields_Helper();
		new Hover_Effects();
		new Album();
		new Duplicator();
		new Albums_Gutenberg();
		new Enqueue();

		require_once MODULA_PRO_PATH . 'includes/extensions/albums/utils/helper.php';

		new Albums_Elementor_Check();
		new Albums_Beaver();

		add_filter( 'modula_page_header', array( $this, 'header' ) );

		add_filter( 'modula_uninstall_post_types', array( $this, 'uninstall_post_type_process' ), 15, 1 );
	}

	/**
	 * Loads the plugin into WordPress.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		// [modula-album] renders a Beta album with the Album visitor frontend, any other with the classic album.
		new Dispatcher( new Shortcode(), new Renderer() );
	}

	/**
	 * Albums settings editor v2 (React takeover + REST).
	 *
	 * @return void
	 */
	private function init_albums_editor_v2() {
		require_once MODULA_PRO_PATH . 'includes/extensions/albums/v2/bootstrap.php';
		\Modula_Pro\Extensions\Albums\V2\Meta_Sync::init();
		\Modula_Pro\Extensions\Albums\V2\Members_Document::init_lifecycle_hooks();
		\Modula_Pro\Extensions\Albums\V2\Album_Post::init();
		\Modula_Pro\Extensions\Albums\V2\Rest\Album_Settings_Controller::init();
		\Modula_Pro\Extensions\Albums\V2\Rest\Album_Members_Controller::init();
		\Modula_Pro\Extensions\Albums\V2\Admin\Album_Takeover_Admin::init();
		\Modula_Pro\Extensions\Albums\V2\Admin\Albums_Editor_Enqueue::init();
		\Modula_Pro\Extensions\Albums\Abilities\Provider::boot();
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Albums object.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Albums ) ) {
			self::$instance = new Albums();
		}
		return self::$instance;
	}

	/**
	 * Uninstall modula custom post types process
	 *
	 * @param $modula_post_types
	 *
	 * @return mixed
	 *
	 * @since 1.0.3
	 */
	public function uninstall_post_type_process( $modula_post_types ) {

		$modula_post_types[] = 'modula-album';

		return $modula_post_types;
	}

	/**
	 * Modula header places
	 *
	 * @param $return
	 *
	 * @return bool|mixed
	 * @since 1.1.0
	 */
	public function header( $return_value ) {

		$current_screen = get_current_screen();

		if ( 'modula-album' === $current_screen->post_type ) {
			return true;
		}

		return $return_value;
	}
}
