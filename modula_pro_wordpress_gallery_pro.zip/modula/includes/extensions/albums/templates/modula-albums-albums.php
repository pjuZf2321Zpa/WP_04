<?php

use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div <?php echo Modula_Helper::generate_attributes( $data->album_container ); ?> > 
	<?php
	if ( isset( $data->has_album, $data->has_gallery ) && $data->has_album && $data->has_gallery && ! empty( $data->settings['albums_title_label'] ) ) {
		printf(
			'<h3 class="modula-item-album-title">%s</h3>',
			esc_html( $data->settings['albums_title_label'] )
		);
	}
	?>

	<?php do_action( 'modula_album_shortcode_before_items', $data->settings, $data, 'modula-album' ); ?>

	<div <?php echo Modula_Helper::generate_attributes( $data->items_container ); ?>>
		<?php
		$troubleshooting_options = get_option( 'modula_troubleshooting_option', array() );
		$albums_srcset           = isset( $troubleshooting_options['remove_srcset'] ) ? $troubleshooting_options['remove_srcset'] : false;
		// Backwards compatibility for ex-albums setting remove_srcset.
		if ( $albums_srcset && '1' === $albums_srcset ) {
			$troubleshooting_options['disable_srcset'] = '1';
		}

		// go through every gallery in the album
		foreach ( $data->galleries as $gallery ) {

			if ( isset( $gallery['itemType'] ) && 'modula-album' !== $gallery['itemType'] ) {
				continue;
			}

			// FEATURED IMAGE CHECK
			$featured_id = get_post_thumbnail_id( $gallery['id'] );

			if ( $featured_id ) {
				$images = array(
					array(
						'id' => $featured_id,
					),
				);
			} else {
				// No featured image? get first available image in the album's galleries.
				$images = modula_get_ablum_images_recursive( $gallery['id'] );
			}

			if( empty( $images ) ) {
				continue;
			}

			// get gallery album settings
			$gallery_width  = ( 'custom-grid' === $data->settings['album_type'] ) ? $gallery['width'] : '';
			$gallery_height = ( 'custom-grid' === $data->settings['album_type'] ) ? $gallery['height'] : '';


			$gallery_settings = get_post_meta( $gallery['id'], 'modula-settings', true );
			$gallery_settings = wp_parse_args( $gallery_settings, Fields_Helper::get_defaults() );
			$image_count      = ( isset( $data->settings['display_image_count'] ) && boolval( $data->settings['display_image_count'] ) ) ? modula_get_album_visitor_member_count( $gallery['id'] ) : false;
			$image_count_html = '(' . esc_html( $image_count ) . ' ' . esc_html( _n( 'Item', 'Items', $image_count, 'modula-pro' ) ) . ')';

			// Prepare array for images configuration
			$images_config = array();

			// only display gallery images data if lightbox enabled in album
			if ( isset( $data->settings['enable_lightbox'] ) && '1' == $data->settings['enable_lightbox'] && ! ( isset( $gallery['itemType'] ) && 'modula-album' === $gallery['itemType'] ) ) {
				if ( ! empty( $images ) ) {
					foreach ( $images as $image ) {

						$mime_type = get_post_mime_type( $image['id'] );
						if ( 'image/heic' === $mime_type || 'image/heif' === $mime_type ) {
							$src = wp_get_attachment_image_src( $image['id'], 'full' );
							if ( ! $src || ! isset( $src[0] ) ) {
								$src = false;
							}
							$src = $src[0];
						} else {
							$src = wp_get_original_image_url( $image['id'] );
						}

						$img_title   = get_the_title( $image['id'] );
						$img_caption = get_post_field( 'post_excerpt', $image['id'] );
						$img_alt     = isset( $image['alt'] ) ? $image['alt'] : '';

						// The image is saved in the gallery meta but may have been deleted from media library.
						// Let's check.
						if ( ! $src ) {
							continue;
						}

						$caption = '';
						if ( 1 == $data->settings['show_image_title'] ) {
							$caption .= '<span class="modula-album-caption-title">' . $img_title . '</span>';
						}
						if ( 1 == $data->settings['show_image_title'] && 1 == $data->settings['show_image_caption'] ) {
							$caption .= '<br>';
						}
						if ( 1 == $data->settings['show_image_caption'] ) {
							$caption .= '<span class="modula-album-caption-description">' . $img_caption . '</span>';
						}

						$image_config = array(
							'src'  => esc_attr( $src ),
							'opts' => array(
								// seems like it was doing a double escape, adding multiple "
								'caption'  => $caption,
								'alt'      => $img_alt,
								'thumb'    => esc_attr( wp_get_attachment_image_url( $image['id'] ) ),
								'image_id' => absint( $image['id'] ),
								'title'    => $img_title,
								'download' => isset( $data->settings['enable_download'] ) ? $data->settings['enable_download'] : 0,
							),
						);

						$images_config[] = apply_filters( 'modula_album_lightbox_item', $image_config, $image, $gallery_settings, $gallery, $data->settings );
					}
				}

				$gallery_link = '#';
			} elseif ( '' != ( $gallery['customurl'] ?? '' ) ) {
					$gallery_link = esc_url( $gallery['customurl'] );
			} else {
				$gallery_link = modula_album_member_public_url( $gallery['id'] );
				if ( isset( $data->settings['back_to_album_button'] ) && 1 === absint( $data->settings['back_to_album_button'] ) ) {
						$gallery_link = add_query_arg( 'back_to_album', 1, $gallery_link );
				}
			}

			$image = array( 'id' => modula_get_album_cover_id( $gallery['id'] ) );

			if ( empty( $image['id'] ) ) {
				continue;
			}

			$image_object = get_post( $image['id'] );
			$full_img_src = wp_get_original_image_url( $image['id'] );

			if ( is_wp_error( $image_object ) || get_post_type( $image_object ) != 'attachment' ) {
				continue;
			}


			// Create array with data in order to send it to image template
			$item_data = array(
				/* Gallery settings */
				'gallery_id'          => $gallery['id'],
				'gallery_images'      => $images_config,
				'album_type'          => $data->settings['album_type'],
				'item_type'           => isset( $gallery['itemType'] ) ? $gallery['itemType'] : 'modula-album',

				/* Item Elements */
				'title'               => isset( $gallery['title'] ) ? $gallery['title'] : '',
				'description'         => isset( $gallery['caption'] ) ? $gallery['caption'] : '',
				'image_count'         => $image_count,
				'image_count_content' => $image_count_html,
				'display_image_count' => boolval( $data->settings['display_image_count'] ),

				/* What to show from elements */
				'hide_title'          => boolval( $data->settings['hide_title'] ),
				'hide_description'    => boolval( $data->settings['hide_description'] ),
				'hide_socials'        => true,
				'remove_srcset'       => isset( $troubleshooting_options['disable_srcset'] ) ? $troubleshooting_options['disable_srcset'] : false,

				/* Item container attributes & classes */
				'columns'             => 12,
				'item_attributes'     => array(
					'data-width'  => $gallery_width,
					'data-height' => $gallery_height,
					'class'       => array( 'modula-item', 'tg-loaded' ),
				),

				/* Item link attributes & classes */
				'link_attributes'     => array(
					'class'               => array( 'gallery-link' ),
					'href'                => $gallery_link,
					'data-gallery-id'     => $gallery['id'],
					'data-gallery-images' => $images_config,
				),

				/* Item img attributes & classes */
				'img_attributes'      => array(
					'alt'       => isset( $gallery['alt'] ) ? (string) $gallery['alt'] : '',
					'class'     => array( 'pic' ),
					'data-full' => $full_img_src,
				),
			);

			if( isset( $gallery['itemType'] ) && 'modula-album' === $gallery['itemType'] ) {
				$item_data['link_attributes']['class'][] = 'simple-link';
			}

			$gallery_settings = apply_filters( 'modula_album_shortcode_gallery_setting', $gallery_settings, $data->settings, $gallery );

			$image = apply_filters( 'modula_album_shortcode_image_data', $image, $gallery_settings );


			/**
			 * Hook: modula_album_shortcode_item_data.
			 *
			 * @hooked modula_album_generate_image_links - 10
			 * @hooked modula_album_check_lightboxes_and_links - 15
			 * @hooked modula_album_check_hover_effect - 20
			 * @hooked modula_album_check_custom_grid - 25
			 * @hooked modula_album_enable_lazy_load - 30
			 */
			$item_data = apply_filters( 'modula_album_shortcode_item_data', $item_data, $image, $gallery_settings, $data->settings, $images );

			do_action( 'modula_album_shortcode_before_item', $gallery_settings, $item_data );

			$data->loader->set_template_data( $item_data );
			$data->loader->get_template_part( 'items/item', $data->settings['effect'] );

			do_action( 'modula_album_shortcode_after_item', $gallery_settings, $item_data );
		}

		?>
	</div>

	<?php do_action( 'modula_album_shortcode_after_items', $data->settings, $data, 'modula-album' ); ?>
</div>
