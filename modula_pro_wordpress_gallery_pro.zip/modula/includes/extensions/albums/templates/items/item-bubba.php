<div <?php echo Modula_Helper::generate_attributes( $data->item_attributes ); ?> >
	<div class="modula-item-overlay"></div>

	<div class="modula-item-content">

		<?php do_action( 'modula_album_item_before_link', $data ); ?>

		<a <?php echo Modula_Helper::generate_attributes( $data->link_attributes ); ?>></a>

		<?php do_action( 'modula_album_item_after_link', $data ); ?>

		<?php

		$image = '<img ' . Modula_Helper::generate_attributes( $data->img_attributes ) . '/>';

		$image_meta = wp_get_attachment_metadata( $data->img_attributes['data-image-id'] );

		if ( ! is_array( $image_meta ) ) {
			$image_meta = array( 'sizes' => array() );
		} elseif ( ! isset( $image_meta['sizes'] ) ) {
			$image_meta['sizes'] = array();
		}

		if ( ! empty( $data->image_info ) ) {
			$mimetype = isset( $image_meta['sizes']['thumbnail']['mime-type'] ) ? $image_meta['sizes']['thumbnail']['mime-type'] : '';
			if ( empty( $mimetype ) ) {
				$mimetype = get_post_mime_type( $data->img_attributes['data-image-id'] );
			}

			$image_meta['sizes']['custom'] = array(
				'file'      => $data->image_info['name'] . '-' . $data->image_info['suffix'] . '.' . $data->image_info['ext'],
				'width'     => $data->img_attributes['width'],
				'height'    => $data->img_attributes['height'],
				'mime-type' => $mimetype,
			);
		}

		if ( false == $data->remove_srcset ) {
			echo wp_image_add_srcset_and_sizes( $image, $image_meta, $data->img_attributes['data-image-id'] );
		} else {
			echo $image;
		}

		do_action( 'modula_album_item_after_image', $data );
		?>

		<div class="figc<?php echo '' == $data->title ? ' no-title' : ''; ?><?php echo '' == $data->description ? ' no-description' : ''; ?>">
			<div class="figc-inner">
				<?php if ( ! $data->hide_title || $data->display_image_count ) : ?>
					<h2 class='jtg-title'>
						<?php
						if ( ! $data->hide_title ) {
							echo wp_kses_post( $data->title );
						}
						?>
						<?php if ( $data->image_count ) { ?>
							<span class="image_count"><?php echo esc_html( $data->image_count_content ); ?></span>
						<?php } ?>
					</h2>
				<?php endif ?>
				<div class="jtg-body">
					<?php if ( ! $data->hide_description && '' != $data->description ) : ?>
						<div class="jtg-description">
							<?php echo wp_kses_post( $data->description ); ?>
						</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div>
</div>
