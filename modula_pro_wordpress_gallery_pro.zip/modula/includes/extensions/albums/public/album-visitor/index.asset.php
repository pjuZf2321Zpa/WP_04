<?php return array('dependencies' => array('react', 'react-dom', 'react-jsx-runtime', 'wp-api-fetch', 'wp-element', 'wp-i18n', 'wp-primitives', 'wp-url'), 'version' => '7b9148210d781a87220f');
