/*
 *  Project: jQuery Modula 2
 *  Version: 1.0
 *  Description: Artistic gallery
 *  Author: WPChill
 */
function tg_getURLParameter( name ) {
	return (
		decodeURIComponent(
			( new RegExp( '[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)' ).exec(
				location.search
			) || [ , '' ] )[ 1 ].replace( /\+/g, '%20' )
		) || null
	);
}

if ( 'undefined' === typeof window.modulacheckDevice ) {
	window.modulacheckDevice = function ( opts ) {
		if ( 'undefined' !== typeof opts ) {
			let devices = true;
			if (
				'undefined' !== typeof opts.lightbox_devices &&
				'both' !== opts.lightbox_devices
			) {
				if ( 'mobile' == opts.lightbox_devices ) {
					devices = 1024 > jQuery( window ).width();
				} else {
					devices = 1024 < jQuery( window ).width();
				}
			}
			return devices;
		}
		return false;
	};
}

// Compatibility with WPBakery Page Builder
jQuery( document ).on(
	'vc-full-width-row-single vc-full-width-row',
	function ( event, element ) {
		if ( jQuery( 'body' ).find( '.modula' ).length > 0 ) {
			jQuery( window ).trigger( 'modula-update' );
		}
	}
);

// Compatibility with Elementor
jQuery( window ).on( 'elementor/frontend/init', function () {
	if ( window.elementorFrontend ) {
		window.elementorFrontend.hooks.addAction(
			'frontend/element_ready/global',
			function ( $scope ) {
				if ( jQuery( 'body' ).find( '.modula' ).length > 0 ) {
					jQuery( window ).trigger( 'modula-update' );
				}
			}
		);
	}
} );

( function ( $, window, document, undefined ) {
	// Create the defaults once
	const pluginName = 'modulaAlbums',
		defaults = {
			resizer: '/',
			keepArea: true,
			type: '3',
			albumType: 'grid',
			columns: 3,
			gutter: 10,
			mobileGutter: 10,
			tabletGutter: 10,
			enableResponsive: false,
			tabletColumns: 2,
			mobileColumns: 1,
			// Classic album breakpoints; the shortcode passes the saved values.
			treatAsPhoneUnder: 768,
			treatAsTabletUnder: 992,
			/*enableTwitter: false,
			enableFacebook: false,
			enableGplus: false,
			enablePinterest: false,
			enableLinkedin: false,
			enableWhatsapp: false,*/
			lazyLoad: 0,
			initLightbox: false,
			lightbox_settings: {},
		};

	// The actual plugin constructor
	function Plugin( element, options ) {
		this.element = element;
		this.$element = $( element );
		this.$itemsCnt = this.$element.find( '.modula-items' );
		this.$items = this.$itemsCnt.find( '.modula-item' );

		this.options = $.extend( {}, defaults, options );
		// options.gutter tracks the current viewport; keep the desktop value.
		this.desktopGutter = this.options.gutter;

		this._defaults = defaults;
		this._name = pluginName;

		this.tiles = [];
		this.$tilesCnt = null;
		this.completed = false;
		this.lastWidth = 0;
		this.resizeTO = 0;
		this.isIsotope = false;

		// Initiate Gallery
		this.init();
	}

	/**
	 * Gutter for a viewport width, from the album's saved breakpoints: mobile
	 * below "Treat as a phone under", tablet up to "Treat as a tablet under".
	 *
	 * @param {number} viewport Viewport width in px.
	 * @return {number} Gutter in px.
	 */
	Plugin.prototype.gutterForViewport = function ( viewport ) {
		if ( viewport < Number( this.options.treatAsPhoneUnder ) ) {
			return this.options.mobileGutter;
		}
		if ( viewport <= Number( this.options.treatAsTabletUnder ) ) {
			return this.options.tabletGutter;
		}
		return this.desktopGutter;
	};

	Plugin.prototype.init = function () {
		const instance = this;
		this.options.gutter = this.gutterForViewport(
			document.documentElement.clientWidth
		);

		// Trigger event before init
		$( document ).trigger( 'modula_albums_api_before_init', [ instance ] );

		if ( 'custom-grid' === this.options.albumType ) {
			this.createCustomGallery();
		} else {
			this.createColumnsGrid();
		}

		$( window ).resize( function () {
			instance.onResize( instance );
		} );

		$( window ).on( 'modula-update', function () {
			instance.onResize( instance );
		} );

		$( document ).on( 'lazyloaded', function ( evt ) {
			let element = $( evt.target ),
				parent,
				index;

			if ( 'modula-album' == element.data( 'source' ) ) {
				element.data( 'size', {
					width: element.width(),
					height: element.height(),
				} );
				parent = element.parents( '.modula-item' );
				parent.addClass( 'tg-loaded' );
				index = instance.$items.index( parent );
				instance.placeImage( index );

				if ( instance.isIsotope ) {
					instance.$itemsCnt.modulaisotope( 'layout' );
				}
			}
		} );

		// Create social links
		//this.setupSocial();
		$( instance.$element ).addClass( 'modula-album-initialized' );
		// Trigger custom gallery JS
		if ( this.options.onComplete ) {
			this.options.onComplete();
		}

		// Init lightox
		if ( ! instance.options.initLightbox ) {
			this.initLightbox();
		}

		// Trigger event after init
		$( document ).trigger( 'modula_albums_api_after_init', [ instance ] );
	};

	Plugin.prototype.initLightbox = function () {
		let self = this,
			tapped = false,
			tappedTimeout,
			doubleTap = false,
			doubleTapTimeout,
			tappedImage,
			gallery = $( this ).data( 'gallery-id' ),
			opts = self.options.lightbox_settings;

		self.$element
			.find( '.gallery-link:not(.simple-link)' )
			.click( function ( evt ) {
				evt.preventDefault();

				const images = $( this ).data( 'gallery-images' );

				opts.beforeLoad = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_before_load',
						[ self, this ]
					);
				};
				opts.afterLoad = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_after_load',
						[ self, this ]
					);
				};
				opts.beforeShow = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_before_show',
						[ self, this ]
					);
				};
				opts.afterShow = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_after_show',
						[ self, this ]
					);
				};
				opts.beforeClose = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_before_close',
						[ self, this ]
					);
				};
				opts.afterClose = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_after_close',
						[ self, this ]
					);
				};
				opts.onInit = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_on_init',
						[ self, this ]
					);
				};
				opts.onActivate = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_on_activate',
						[ self, this ]
					);
				};
				opts.onDeactivate = function () {
					jQuery( document ).trigger(
						'modula_albums_fancybox_lightbox_on_deactivate',
						[ self, this ]
					);
				};

				const links = $.map( images, function ( o, i ) {
					console.log( o.opts );
					const link_data = {
						src: o.src,
						opts: {
							thumb: o.opts.thumb,
							caption: o.opts.caption,
							alt: o.opts.alt,
							image_id: o.opts.image_id,
							title: o.opts.title,
						},
						// Set current true only for the first image
						current: 0 === i ? true : false,
					};

					if (
						'undefined' !== typeof o.opts.download &&
						o.opts.download
					) {
						link_data.downloadFilename = o.opts.title;
						link_data.downloadSrc = o.opts.download_file ?? o.src;
					}

					return link_data;
				} );

				modulaImage = $( this );

				if ( modulacheckDevice( opts ) ) {
					// Let's see if user selected to double click on mobile view
					if (
						opts.mobileDoubleClick &&
						1024 > $( window ).width()
					) {
						if ( ! doubleTap ) {
							//if tap is not set, set up single tap
							doubleTap = true;

							doubleTapTimeout = setTimeout( function () {
								doubleTap = false;
							}, 300 );
						} else {
							//tapped within 300ms of last tap. double tap
							clearTimeout( doubleTapTimeout ); //stop single tap callback
							doubleTap = false;
							// Check to see if is same image or another
							if (
								tappedImage &&
								tappedImage.is( modulaImage )
							) {
								$.modulaFancybox.open( links, opts );
							}
						}
						// Update the tapped image
						tappedImage = modulaImage;
					} else {
						$.modulaFancybox.open( links, opts );
					}
				}
			} );
		// Copy caption on double tap
		if ( opts.copyCaptionMobile ) {
			const doCopyCaption = function ( caption ) {
				const textEl = caption.querySelector(
					'.modula-album-caption-description'
				);
				const textToCopy = textEl
					? textEl.textContent
					: caption.textContent;
				if ( ! textToCopy.trim() ) {
					return;
				}
				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard
						.writeText( textToCopy.trim() )
						.catch( function ( err ) {
							console.error( 'Could not copy text: ', err );
						} );
				} else {
					const ta = document.createElement( 'textarea' );
					ta.value = textToCopy.trim();
					document.body.appendChild( ta );
					ta.select();
					document.execCommand( 'copy' );
					document.body.removeChild( ta );
				}
			};
			document.addEventListener(
				'touchend',
				function ( e ) {
					const caption = e.target.closest( '.fancybox__caption' );
					if ( ! caption ) {
						return;
					}
					e.preventDefault();
					e.stopPropagation();
					if ( ! tapped ) {
						tapped = true;
						tappedTimeout = setTimeout( function () {
							tapped = false;
						}, 400 );
					} else {
						clearTimeout( tappedTimeout );
						tapped = false;
						doCopyCaption( caption );
					}
				},
				true
			);
		}
	};

	Plugin.prototype.trunc = function ( v ) {
		if ( Math.trunc ) {
			return Math.trunc( v );
		}
		v = +v;
		if ( ! isFinite( v ) ) {
			return v;
		}

		return v - ( v % 1 ) || ( v < 0 ? -0 : v === 0 ? v : 0 );
	};

	// Create custom grid gallery based on packery.
	Plugin.prototype.createCustomGallery = function () {
		let instance = this,
			size,
			containerWidth = this.$element.width(),
			plugin = this,
			columns = this.options.columns,
			viewport = document.documentElement.clientWidth;

		if ( '1' == this.options.enableResponsive ) {
			if ( viewport <= 568 ) {
				columns = this.options.mobileColumns;
			} else if ( viewport <= 768 ) {
				columns = this.options.tabletColumns;
			}
		}

		if ( this.options.gutter > 0 ) {
			size =
				( containerWidth - this.options.gutter * ( columns - 1 ) ) /
				columns;
		} else {
			size = Math.floor( ( containerWidth / columns ) * 1000 ) / 1000;
		}

		this.$items.each( function ( i, item ) {
			let slot = {},
				widthColumns,
				heightColumns,
				auxWidth,
				auxHeight;

			widthColumns = $( item ).data( 'width' );
			heightColumns = $( item ).data( 'height' );

			if ( widthColumns > 12 ) {
				widthColumns = 12;
			}

			if ( '1' == plugin.options.enableResponsive ) {
				auxWidth = widthColumns;
				auxHeight = heightColumns;

				if ( 1 == columns ) {
					widthColumns = 1;
					heightColumns = ( widthColumns * auxHeight ) / auxWidth;
				} else {
					widthColumns = Math.round( ( columns * auxWidth ) / 12 );
					if ( widthColumns < 1 ) {
						widthColumns = 1;
					}

					heightColumns = Math.round(
						( widthColumns * auxHeight ) / auxWidth
					);
					if ( heightColumns < 1 ) {
						heightColumns = 1;
					}
				}
			}

			slot.width =
				size * widthColumns +
				plugin.options.gutter * ( widthColumns - 1 );
			slot.height =
				Math.round( size ) * heightColumns +
				plugin.options.gutter * ( heightColumns - 1 );

			$( item )
				.data( 'size', slot )
				.addClass( 'tiled' )
				.addClass( slot.width > slot.height ? 'tile-h' : 'tile-v' )
				.data( 'position' );

			$( item ).css( $( item ).data( 'size' ) );
			$( item )
				.find( '.figc' )
				.css( {
					width: $( item ).data( 'size' ).width,
					height: $( item ).data( 'size' ).height,
				} );

			// Load Images
			if ( '1' != instance.options.lazyLoad ) {
				instance.loadImage( i );
			}
		} );

		const packery_args = {
			itemSelector: '.modula-item',
			layoutMode: 'packery',
			packery: {
				gutter: parseInt( plugin.options.gutter ),
			},
		};

		if ( ! this.isIsotope ) {
			this.$itemsCnt.modulaisotope( packery_args );
			this.isIsotope = true;
		} else {
			instance.$itemsCnt.modulaisotope( 'layout' );
		}
	};

	Plugin.prototype.createColumnsGrid = function () {
		const instance = this;

		// Load Images
		if ( '1' != instance.options.lazyLoad ) {
			this.$items.each( function ( index, el ) {
				instance.loadImage( index );
			} );
		}

		if ( ! this.isIsotope ) {
			this.$itemsCnt.modulaisotope( {
				// set itemSelector so .grid-sizer is not used in layout
				itemSelector: '.modula-item',
				// percentPosition: true,
				layoutMode: 'packery',
				packery: {
					// use element for option
					gutter: parseInt( this.options.gutter ),
				},
			} );
			this.isIsotope = true;
		} else {
			instance.$itemsCnt.modulaisotope( 'layout' );
		}
	};

	Plugin.prototype.getSlot = function () {
		if ( this.tiles.length == 0 ) {
			var tile = {
				top: 0,
				left: 0,
				width: this.$itemsCnt.width(),
				height: this.options.height,
				area: this.$itemsCnt.width() * this.options.height,
				position: 0,
			};

			return tile;
		}

		let maxTileIdx = 0;
		for ( let i = 0; i < this.tiles.length; i++ ) {
			var tile = this.tiles[ i ];
			if ( tile.area > this.tiles[ maxTileIdx ].area ) {
				maxTileIdx = i;
			}
		}

		var tile = {};

		const maxTileData = this.tiles[ maxTileIdx ];

		if ( maxTileData.width > maxTileData.height ) {
			var randomMaxDelta =
				( maxTileData.width / 2 ) * this.options.randomFactor;

			maxTileData.prevWidth = maxTileData.width;
			maxTileData.width = Math.floor(
				maxTileData.width / 2 + randomMaxDelta * ( Math.random() - 0.5 )
			);

			tile = {
				top: maxTileData.top,
				left:
					maxTileData.left + maxTileData.width + this.options.gutter,
				width:
					maxTileData.prevWidth -
					maxTileData.width -
					this.options.gutter,
				height: maxTileData.height,
			};
		} else {
			var randomMaxDelta =
				( maxTileData.height / 2 ) * this.options.randomFactor;

			maxTileData.prevHeight = maxTileData.height;
			maxTileData.height = Math.floor(
				maxTileData.height / 2 +
					randomMaxDelta * ( Math.random() - 0.5 )
			);

			tile = {
				left: maxTileData.left,
				top: maxTileData.top + maxTileData.height + this.options.gutter,
				width: maxTileData.width,
				height:
					maxTileData.prevHeight -
					maxTileData.height -
					this.options.gutter,
			};
		}

		tile.area = tile.width * tile.height;
		tile.position = tile.top * 1000 + tile.left;

		maxTileData.position = maxTileData.top * 1000 + maxTileData.left;

		this.tiles[ maxTileIdx ] = maxTileData;
		this.tiles[ maxTileIdx ].area = maxTileData.width * maxTileData.height;

		return tile;
	};

	Plugin.prototype.reset = function () {
		const instance = this;
		instance.tiles = [];

		if ( 'custom-grid' === instance.options.albumType ) {
			this.createCustomGallery();
		} else {
			this.createColumnsGrid();
		}

		instance.lastWidth = instance.$itemsCnt.width();
	};

	Plugin.prototype.onResize = function ( instance ) {
		if ( instance.lastWidth == instance.$itemsCnt.width() ) {
			return;
		}

		instance.options.gutter = instance.gutterForViewport(
			document.documentElement.clientWidth
		);

		clearTimeout( instance.resizeTO );
		instance.resizeTO = setTimeout( function () {
			if ( instance.options.keepArea ) {
				const area = instance.$itemsCnt.data( 'area' );
				instance.$itemsCnt.height( area / instance.$itemsCnt.width() );
			}

			instance.reset();
			if ( instance.isIsotope ) {
				instance.$itemsCnt.modulaisotope( 'layout' );
			}
		}, 1000 );
	};

	Plugin.prototype.loadImage = function ( index ) {
		const instance = this;
		const source = instance.$items.eq( index ).find( '.pic' );
		const img = new Image();
		img.onerror = function () {
			console.log( 'error loading image [' + index + '] : ' + this.src );
			if ( index + 1 < instance.$items.length ) {
				instance.loadImage( index + 1 );
			}
		};
		img.onload = function () {
			source.data( 'size', { width: this.width, height: this.height } );
			instance.placeImage( index );

			instance.$items.eq( index ).addClass( 'tg-loaded' );
			if ( index + 1 < instance.$items.length ) {
				instance.loadImage( index + 1 );
			}
		};

		const original_src = source.data( 'src' );
		img.src = original_src;
		source.attr( 'src', original_src );

		instance.placeImage( index );
	};

	Plugin.prototype.placeImage = function ( index ) {
		if ( 'custom-grid' != this.options.albumType ) {
			return;
		}

		const $tile = this.$items.eq( index );
		const $image = $tile.find( '.pic' ).first();

		if ( ! $image.length ) {
			return;
		}

		const coverStyles = window.modulaAlbumCustomGridCoverStyles;
		if ( ! coverStyles ) {
			return;
		}

		const align = {
			valign: $image.data( 'valign' )
				? $image.data( 'valign' )
				: 'middle',
			halign: $image.data( 'halign' )
				? $image.data( 'halign' )
				: 'center',
		};

		$image.css( coverStyles.buildCustomGridCoverStyles( align ) );

		if ( $image.is( 'picture' ) ) {
			$image
				.find( 'img' )
				.css( coverStyles.buildCustomGridCoverInnerImgStyles( align ) );
		}

		this.$items.eq( index ).addClass( 'tg-loaded' );
	};

	/*Plugin.prototype.setupSocial = function () {
		if (this.options.enableTwitter) {
			setupTwitter(this.$items, this);
		}
		if (this.options.enableFacebook) {
			setupFacebook(this.$items, this);
		}
		if (this.options.enablePinterest) {
			setupPinterest(this.$items, this);
		}
		if (this.options.enableLinkedin) {
			setupLinkedIN(this.$items, this);
		}
		if (this.options.enableWhatsapp) {
			setupWhatsapp(this.$items, this);
		}
	}*/

	Plugin.prototype.destroy = function () {
		if ( this.isPackeryActive ) {
			this.$itemsCnt.packery( 'destroy' );
			this.isPackeryActive = false;
		}
	};

	//credits James Padolsey http://james.padolsey.com/
	const qualifyURL = function ( url ) {
		const img = document.createElement( 'img' );
		img.src = url; // set string url
		url = img.src; // get qualified url
		img.src = null; // no server request
		return url;
	};

	/*var setupTwitter = function ($tiles, plugin) {
		$tiles.find(".modula-icon-twitter").click(function (e) {
			e.preventDefault();

			//var $caption = $(this).parents(".tile:first").find(".description");
			var $caption = '';

			var text = plugin.options.twitterText || document.title;
			if (!plugin.options.twitterText && $caption.length == 1 && $caption.text().length > 0)
				text = $.trim($caption.text());

			var w = window.open("https://twitter.com/intent/tweet?url=" + encodeURI(location.href.split('#')[0]) + "&text=" + encodeURI(text), "ftgw", "location=1,status=1,scrollbars=1,width=600,height=400");
			w.moveTo((screen.width / 2) - (300), (screen.height / 2) - (200));
			return false;
		});
	}

	var setupFacebook = function ($tiles, plugin) {
		$tiles.find(".modula-icon-facebook").click(function (e) {
			e.preventDefault();

			var image = $(this).parents(".tile:first").find(".pic");

			//var $caption = $(this).parents(".tile:first").find(".description");
			var $caption = '';

			var text = plugin.options.facebookText || document.title;
			if (!plugin.options.facebookText && $caption.length == 1 && $caption.text().length > 0)
				text = $.trim($caption.text());


			var src = image.attr("src");
			var url = "//www.facebook.com/sharer.php?u=" + location.href;

			var w = window.open(url, "ftgw", "location=1,status=1,scrollbars=1,width=600,height=400");
			w.moveTo((screen.width / 2) - (300), (screen.height / 2) - (200));
			return false;
		});
	}

	var setupWhatsapp = function ($tiles, plugin) {
		$tiles.find(".modula-icon-whatsapp").click(function (e) {
			e.preventDefault();

			//var $caption = $(this).parents(".tile:first").find(".description");
			var $caption = '';

			var text = plugin.options.whatsappText || document.title;

			if (!plugin.options.whatsappText && $caption.length == 1 && $caption.text().length > 0)
				text = $.trim($caption.text());

			var w = window.open("https://api.whatsapp.com/send?text=" + encodeURI((window.location.href.split("#")[0])) + '&preview_url=true', "ftgw", "location=1,status=1,scrollbars=1,width=600,height=400");
			w.moveTo((screen.width / 2) - (300), (screen.height / 2) - (200));
			return false;
		});
	}

	var setupPinterest = function ($tiles, plugin) {
		$tiles.find(".modula-icon-pinterest").click(function (e) {
			e.preventDefault();

			var image = $(this).parents(".tile:first").find(".pic");

			//var $caption = $(this).parents(".tile:first").find(".description");
			var $caption = '';

			var text = plugin.options.pinterestText || document.title;
			if (!plugin.options.pinterestText && $caption.length == 1 && $caption.text().length > 0)
				text = $.trim($caption.text());

			var url = "http://pinterest.com/pin/create/button/?url=" + encodeURI(location.href) + "&description=" + encodeURI(text);

			if (image.length == 1) {
				var src = image.attr("src");
				url += ("&media=" + qualifyURL(src));
			}

			var w = window.open(url, "ftgw", "location=1,status=1,scrollbars=1,width=600,height=400");
			w.moveTo((screen.width / 2) - (300), (screen.height / 2) - (200));
			return false;
		});
	}

	var setupLinkedIN = function ($tiles, plugin) {
		$tiles.find(".modula-icon-linkedin").click(function (e) {
			e.preventDefault();

			var url = "//linkedin.com/shareArticle?mini=true&url=" + +encodeURI(location.href);

			var w = window.open(url, "ftgw", "location=1,status=1,scrollbars=1,width=600,height=400");
			w.moveTo((screen.width / 2) - (300), (screen.height / 2) - (200));
			return false;
		});
	}*/

	$.fn[ pluginName ] = function ( options ) {
		const args = arguments;

		if ( options === undefined || typeof options === 'object' ) {
			return this.each( function () {
				if ( ! $.data( this, 'plugin_' + pluginName ) ) {
					$.data(
						this,
						'plugin_' + pluginName,
						new Plugin( this, options )
					);
				}
			} );
		} else if (
			typeof options === 'string' &&
			options[ 0 ] !== '_' &&
			options !== 'init'
		) {
			let returns;

			this.each( function () {
				const instance = $.data( this, 'plugin_' + pluginName );

				// Tests that there's already a plugin-instance
				// and checks that the requested public method exists
				if (
					instance instanceof Plugin &&
					typeof instance[ options ] === 'function'
				) {
					// Call the method of our plugin instance,
					// and pass it the supplied arguments.
					returns = instance[ options ].apply(
						instance,
						Array.prototype.slice.call( args, 1 )
					);
				}

				// Allow instances to be destroyed via the 'destroy' method
				if ( options === 'destroy' ) {
					$.data( this, 'plugin_' + pluginName, null );
				}
			} );

			return returns !== undefined ? returns : this;
		}
	};
} )( jQuery, window, document );

jQuery( window ).on( 'load', function () {
	const modulaAlbums = jQuery( '.modula.modula-album' );

	jQuery.each( modulaAlbums, function () {
		const modulaID = jQuery( this ).attr( 'id' ),
			modulaSettings = jQuery( this ).data( 'config' );

		jQuery( this ).modulaAlbums( modulaSettings );
	} );
} );
