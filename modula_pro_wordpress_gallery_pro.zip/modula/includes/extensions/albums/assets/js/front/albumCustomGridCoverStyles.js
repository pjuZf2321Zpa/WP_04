/**
 * Classic visitor album — Custom Grid cover fill styles.
 * Keeps covers inside the tile via absolute fill + object-fit (no escaped inset crop).
 *
 * @package
 */
( function ( root, factory ) {
	if ( typeof module === 'object' && module.exports ) {
		module.exports = factory();
	} else {
		root.modulaAlbumCustomGridCoverStyles = factory();
	}
} )( typeof self !== 'undefined' ? self : this, function () {
	/**
	 * @param {string} [valign] top | middle | bottom
	 * @return {string}
	 */
	function mapValign( valign ) {
		if ( valign === 'top' || valign === 'bottom' ) {
			return valign;
		}
		return 'center';
	}

	/**
	 * @param {string} [halign] left | center | right
	 * @return {string}
	 */
	function mapHalign( halign ) {
		if ( halign === 'left' || halign === 'right' ) {
			return halign;
		}
		return 'center';
	}

	/**
	 * @param {{ valign?: string, halign?: string }} [align]
	 * @return {string}
	 */
	function objectPositionFromAlign( align ) {
		const a = align || {};
		return mapHalign( a.halign ) + ' ' + mapValign( a.valign );
	}

	/**
	 * Styles for img.pic or picture.pic on Album Type custom-grid.
	 *
	 * @param {{ valign?: string, halign?: string }} [align]
	 * @return {Record<string, string|number>}
	 */
	function buildCustomGridCoverStyles( align ) {
		return {
			position: 'absolute',
			top: 0,
			right: 0,
			bottom: 0,
			left: 0,
			width: '100%',
			height: '100%',
			margin: 0,
			maxWidth: 'none',
			objectFit: 'cover',
			objectPosition: objectPositionFromAlign( align ),
		};
	}

	/**
	 * Styles for img nested under picture.pic (object-fit applies to the img).
	 *
	 * @param {{ valign?: string, halign?: string }} [align]
	 * @return {Record<string, string>}
	 */
	function buildCustomGridCoverInnerImgStyles( align ) {
		return {
			width: '100%',
			height: '100%',
			objectFit: 'cover',
			objectPosition: objectPositionFromAlign( align ),
			display: 'block',
		};
	}

	return {
		buildCustomGridCoverStyles: buildCustomGridCoverStyles,
		buildCustomGridCoverInnerImgStyles: buildCustomGridCoverInnerImgStyles,
		objectPositionFromAlign: objectPositionFromAlign,
	};
} );
