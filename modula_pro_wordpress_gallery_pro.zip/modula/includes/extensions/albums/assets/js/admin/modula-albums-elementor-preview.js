jQuery( function ( $ ) {
	/**
	 * Starts the classic albums script on one widget's classic album.
	 *
	 * @param {Object} $album jQuery collection holding the album root.
	 */
	function initClassicAlbum( $album ) {
		const $albumById = $( '#' + $album.attr( 'id' ) ),
			modulaSettings = $album.data( 'config' ),
			modulaInstance = $albumById.data( 'plugin_modulaAlbums' );

		if ( modulaInstance ) {
			modulaInstance.destroy();
			$albumById.data( 'plugin_modulaAlbums', null );
		}

		$albumById.modulaAlbums( modulaSettings );
	}

	/**
	 * Elementor inserts the widget's markup after the page has loaded, so
	 * each album script has to be started on it by hand.
	 *
	 * @param {Object} $scope jQuery collection holding the widget's wrapper.
	 */
	function initWidgetAlbum( $scope ) {
		const $album = $scope.find( '.modula-album' );

		if ( $album.length > 0 ) {
			initClassicAlbum( $album );
		}

		// A Beta album: the Album visitor frontend mounts its shell.
		if (
			$scope.find( '[data-modula-album-visitor]' ).length > 0 &&
			'function' === typeof window.ModulaAlbumVisitorInit
		) {
			window.ModulaAlbumVisitorInit();
		}
	}

	// Every widget, not the Modula Albums one alone: Elementor's Shortcode
	// widget inserts an album's markup the same way.
	function registerWidgetHandler() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/widget',
			initWidgetAlbum
		);
	}

	if ( 'undefined' !== typeof elementorFrontend.hooks ) {
		registerWidgetHandler();
	}

	$( window ).on( 'elementor/frontend/init', registerWidgetHandler );
} );
