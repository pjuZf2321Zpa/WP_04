! ( function ( e ) {
	const t = {};
	function n( r ) {
		if ( t[ r ] ) {
			return t[ r ].exports;
		}
		const o = ( t[ r ] = { i: r, l: ! 1, exports: {} } );
		return (
			e[ r ].call( o.exports, o, o.exports, n ), ( o.l = ! 0 ), o.exports
		);
	}
	( n.m = e ),
		( n.c = t ),
		( n.d = function ( e, t, r ) {
			n.o( e, t ) ||
				Object.defineProperty( e, t, { enumerable: ! 0, get: r } );
		} ),
		( n.r = function ( e ) {
			'undefined' !== typeof Symbol &&
				Symbol.toStringTag &&
				Object.defineProperty( e, Symbol.toStringTag, {
					value: 'Module',
				} ),
				Object.defineProperty( e, '__esModule', { value: ! 0 } );
		} ),
		( n.t = function ( e, t ) {
			if ( ( 1 & t && ( e = n( e ) ), 8 & t ) ) {
				return e;
			}
			if ( 4 & t && 'object' === typeof e && e && e.__esModule ) {
				return e;
			}
			const r = Object.create( null );
			if (
				( n.r( r ),
				Object.defineProperty( r, 'default', {
					enumerable: ! 0,
					value: e,
				} ),
				2 & t && 'string' !== typeof e )
			) {
				for ( const o in e ) {
					n.d(
						r,
						o,
						function ( t ) {
							return e[ t ];
						}.bind( null, o )
					);
				}
			}
			return r;
		} ),
		( n.n = function ( e ) {
			const t =
				e && e.__esModule
					? function () {
							return e.default;
					  }
					: function () {
							return e;
					  };
			return n.d( t, 'a', t ), t;
		} ),
		( n.o = function ( e, t ) {
			return Object.prototype.hasOwnProperty.call( e, t );
		} ),
		( n.p = '' ),
		n( ( n.s = 0 ) );
} )( [
	function ( e, t, n ) {
		'use strict';
		function r( e ) {
			return ( r =
				'function' === typeof Symbol &&
				'symbol' === typeof Symbol.iterator
					? function ( e ) {
							return typeof e;
					  }
					: function ( e ) {
							return e &&
								'function' === typeof Symbol &&
								e.constructor === Symbol &&
								e !== Symbol.prototype
								? 'symbol'
								: typeof e;
					  } )( e );
		}
		function o( e, t ) {
			if ( ! ( e instanceof t ) ) {
				throw new TypeError( 'Cannot call a class as a function' );
			}
		}
		function a( e, t ) {
			for ( let n = 0; n < t.length; n++ ) {
				const r = t[ n ];
				( r.enumerable = r.enumerable || ! 1 ),
					( r.configurable = ! 0 ),
					'value' in r && ( r.writable = ! 0 ),
					Object.defineProperty( e, r.key, r );
			}
		}
		function l( e, t ) {
			return ( l =
				Object.setPrototypeOf ||
				function ( e, t ) {
					return ( e.__proto__ = t ), e;
				} )( e, t );
		}
		function c( e ) {
			const t = ( function () {
				if ( 'undefined' === typeof Reflect || ! Reflect.construct ) {
					return ! 1;
				}
				if ( Reflect.construct.sham ) {
					return ! 1;
				}
				if ( 'function' === typeof Proxy ) {
					return ! 0;
				}
				try {
					return (
						Date.prototype.toString.call(
							Reflect.construct( Date, [], function () {} )
						),
						! 0
					);
				} catch ( e ) {
					return ! 1;
				}
			} )();
			return function () {
				let n,
					r = i( e );
				if ( t ) {
					const o = i( this ).constructor;
					n = Reflect.construct( r, arguments, o );
				} else {
					n = r.apply( this, arguments );
				}
				return u( this, n );
			};
		}
		function u( e, t ) {
			return ! t || ( 'object' !== r( t ) && 'function' !== typeof t )
				? ( function ( e ) {
						if ( void 0 === e ) {
							throw new ReferenceError(
								"this hasn't been initialised - super() hasn't been called"
							);
						}
						return e;
				  } )( e )
				: t;
		}
		function i( e ) {
			return ( i = Object.setPrototypeOf
				? Object.getPrototypeOf
				: function ( e ) {
						return e.__proto__ || Object.getPrototypeOf( e );
				  } )( e );
		}
		n.r( t );
		const s = wp.i18n.__,
			p = wp.element,
			f = p.Component,
			m = p.Fragment,
			d = wp.editor.InspectorControls,
			b = wp.components,
			y = b.SelectControl,
			h = b.Button,
			g = b.PanelBody,
			v = ( function ( e ) {
				! ( function ( e, t ) {
					if ( 'function' !== typeof t && null !== t ) {
						throw new TypeError(
							'Super expression must either be null or a function'
						);
					}
					( e.prototype = Object.create( t && t.prototype, {
						constructor: {
							value: e,
							writable: ! 0,
							configurable: ! 0,
						},
					} ) ),
						t && l( e, t );
				} )( i, e );
				let t,
					n,
					r,
					u = c( i );
				function i( e ) {
					return o( this, i ), u.apply( this, arguments );
				}
				return (
					( t = i ),
					( n = [
						{
							key: 'selectOptions',
							value() {
								const e = [ { value: 0, label: s( 'none' ) } ];
								return (
									this.props.galleries.forEach(
										function ( t ) {
											0 == t.title.rendered.length
												? e.push( {
														value: t.id,
														label:
															s(
																'Unnamed Album ',
																'modula-best-grid-gallery'
															) + t.id,
												  } )
												: e.push( {
														value: t.id,
														label: t.title.rendered,
												  } );
										}
									),
									e
								);
							},
						},
						{
							key: 'render',
							value() {
								const e = this,
									t = this.props,
									n = t.attributes,
									r = ( t.setAttributes, t.galleries ),
									o = n.id;
								return React.createElement(
									m,
									null,
									React.createElement(
										d,
										null,
										React.createElement(
											g,
											{
												title: s(
													'Gallery Settings',
													'modula-best-grid-gallery'
												),
												initialOpen: ! 0,
											},
											0 === r.length &&
												React.createElement(
													m,
													null,
													React.createElement(
														'p',
														null,
														s(
															"You don't seem to have any albums."
														)
													),
													React.createElement(
														h,
														{
															href:
																modulaAlbumsVars.adminURL +
																'post-new.php?post_type=modula-gallery',
															target: '_blank',
															isDefault: ! 0,
														},
														s(
															'Add New Album',
															'modula-best-grid-gallery'
														)
													)
												),
											r.length > 0 &&
												React.createElement(
													m,
													null,
													React.createElement( y, {
														key: o,
														label: s(
															'Select Album',
															'modula-best-grid-gallery'
														),
														value: o,
														options:
															this.selectOptions(),
														onChange( t ) {
															return e.props.onIdChange(
																parseInt( t )
															);
														},
													} ),
													0 != o &&
														React.createElement(
															h,
															{
																target: '_blank',
																href:
																	modulaAlbumsVars.adminURL +
																	'post.php?post=' +
																	o +
																	'&action=edit',
																isDefault: ! 0,
															},
															s( 'Edit album' )
														)
												)
										)
									)
								);
							},
						},
					] ) && a( t.prototype, n ),
					r && a( t, r ),
					i
				);
			} )( f );
		function R( e ) {
			return ( R =
				'function' === typeof Symbol &&
				'symbol' === typeof Symbol.iterator
					? function ( e ) {
							return typeof e;
					  }
					: function ( e ) {
							return e &&
								'function' === typeof Symbol &&
								e.constructor === Symbol &&
								e !== Symbol.prototype
								? 'symbol'
								: typeof e;
					  } )( e );
		}
		function w() {
			return ( w =
				Object.assign ||
				function ( e ) {
					for ( let t = 1; t < arguments.length; t++ ) {
						const n = arguments[ t ];
						for ( const r in n ) {
							Object.prototype.hasOwnProperty.call( n, r ) &&
								( e[ r ] = n[ r ] );
						}
					}
					return e;
				} ).apply( this, arguments );
		}
		function E( e, t ) {
			if ( ! ( e instanceof t ) ) {
				throw new TypeError( 'Cannot call a class as a function' );
			}
		}
		function _( e, t ) {
			for ( let n = 0; n < t.length; n++ ) {
				const r = t[ n ];
				( r.enumerable = r.enumerable || ! 1 ),
					( r.configurable = ! 0 ),
					'value' in r && ( r.writable = ! 0 ),
					Object.defineProperty( e, r.key, r );
			}
		}
		function O( e, t ) {
			return ( O =
				Object.setPrototypeOf ||
				function ( e, t ) {
					return ( e.__proto__ = t ), e;
				} )( e, t );
		}
		function k( e ) {
			const t = ( function () {
				if ( 'undefined' === typeof Reflect || ! Reflect.construct ) {
					return ! 1;
				}
				if ( Reflect.construct.sham ) {
					return ! 1;
				}
				if ( 'function' === typeof Proxy ) {
					return ! 0;
				}
				try {
					return (
						Date.prototype.toString.call(
							Reflect.construct( Date, [], function () {} )
						),
						! 0
					);
				} catch ( e ) {
					return ! 1;
				}
			} )();
			return function () {
				let n,
					r = S( e );
				if ( t ) {
					const o = S( this ).constructor;
					n = Reflect.construct( r, arguments, o );
				} else {
					n = r.apply( this, arguments );
				}
				return j( this, n );
			};
		}
		function j( e, t ) {
			return ! t || ( 'object' !== R( t ) && 'function' !== typeof t )
				? ( function ( e ) {
						if ( void 0 === e ) {
							throw new ReferenceError(
								"this hasn't been initialised - super() hasn't been called"
							);
						}
						return e;
				  } )( e )
				: t;
		}
		function S( e ) {
			return ( S = Object.setPrototypeOf
				? Object.getPrototypeOf
				: function ( e ) {
						return e.__proto__ || Object.getPrototypeOf( e );
				  } )( e );
		}
		const C = wp.i18n.__,
			A = wp.element,
			P = A.Component,
			x = A.Fragment,
			N = wp.data.withSelect,
			I = wp.components,
			T = I.SelectControl,
			M = I.Button,
			B = I.Spinner,
			D = I.Toolbar,
			L = I.IconButton,
			U = wp.editor.BlockControls,
			V = ( function ( e ) {
				! ( function ( e, t ) {
					if ( 'function' !== typeof t && null !== t ) {
						throw new TypeError(
							'Super expression must either be null or a function'
						);
					}
					( e.prototype = Object.create( t && t.prototype, {
						constructor: {
							value: e,
							writable: ! 0,
							configurable: ! 0,
						},
					} ) ),
						t && O( e, t );
				} )( a, e );
				let t,
					n,
					r,
					o = k( a );
				function a( e ) {
					let t;
					return (
						E( this, a ),
						( ( t = o.apply(
							this,
							arguments
						) ).props.attributes.status = 'ready' ),
						( t.props.attributes.images = [] ),
						t
					);
				}
				return (
					( t = a ),
					( n = [
						{
							key: 'componentDidMount',
							value() {
								0 !== this.props.attributes.id &&
									this.onIdChange( this.props.attributes.id );
							},
						},
						{
							key: 'onIdChange',
							value( e ) {
								const t = this;
								this.props.setAttributes( {
									status: 'loading',
								} ),
									jQuery.ajax( {
										type: 'POST',
										data: {
											action: 'modula_get_album_meta',
											id: e,
											nonce: modulaAlbumsVars.nonce,
										},
										url: modulaAlbumsVars.ajaxURL,
										success( n ) {
											return t.onGalleryLoaded( e, n );
										},
									} );
							},
						},
						{
							key: 'onGalleryLoaded',
							value( e, t ) {
								! 1 !== t.success
									? this.props.setAttributes( {
											id: e,
											images: JSON.parse( t ),
											status: 'ready',
									  } )
									: this.props.setAttributes( {
											id: 0,
											status: 'ready',
									  } );
							},
						},
						{
							key: 'selectOptions',
							value() {
								const e = [
									{
										value: 0,
										label: C(
											'select a album',
											'modula-best-grid-gallery'
										),
									},
								];
								return (
									this.props.galleries.forEach(
										function ( t ) {
											0 == t.title.rendered.length
												? e.push( {
														value: t.id,
														label:
															C(
																'Unnamed Album ',
																'modula-best-grid-gallery'
															) + t.id,
												  } )
												: e.push( {
														value: t.id,
														label: t.title.rendered,
												  } );
										}
									),
									e
								);
							},
						},
						{
							key: 'render',
							value() {
								const e = this,
									t = this.props,
									n = t.attributes,
									r = t.galleries,
									o = n.id,
									a = n.images,
									l = n.status,
									c = React.createElement(
										U,
										null,
										a.length > 0 &&
											React.createElement(
												D,
												null,
												React.createElement( L, {
													label: C(
														'Edit Album',
														'modula-best-grid-gallery'
													),
													icon: 'edit',
													href:
														modulaAlbumsVars.adminURL +
														'post.php?post=' +
														o +
														'&action=edit',
													target: '_blank',
												} )
											)
									);
								return 'loading' === l
									? [
											React.createElement(
												x,
												null,
												React.createElement(
													'div',
													{
														className:
															'modula-block-preview',
													},
													React.createElement(
														'div',
														{
															className:
																'modula-block-preview__content',
														},
														React.createElement(
															'div',
															{
																className:
																	'modula-albums-block-preview__logo',
															}
														),
														React.createElement(
															B,
															null
														)
													)
												)
											),
									  ]
									: 0 == o || 0 === a.length
									? [
											React.createElement(
												x,
												null,
												React.createElement(
													v,
													w(
														{
															onIdChange( t ) {
																return e.onIdChange(
																	t
																);
															},
														},
														this.props
													)
												),
												React.createElement(
													'div',
													{
														className:
															'modula-block-preview',
													},
													React.createElement(
														'div',
														{
															className:
																'modula-block-preview__content',
														},
														React.createElement(
															'div',
															{
																className:
																	'modula-albums-block-preview__logo',
															}
														),
														0 === r.length &&
															React.createElement(
																x,
																null,
																React.createElement(
																	'p',
																	null,
																	C(
																		"You don't seem to have any albums.",
																		'modula-best-grid-gallery'
																	)
																),
																React.createElement(
																	M,
																	{
																		href:
																			modulaAlbumsVars.adminURL +
																			'post-new.php?post_type=modula-gallery',
																		target: '_blank',
																		isDefault:
																			! 0,
																	},
																	C(
																		'Add New Album',
																		'modula-best-grid-gallery'
																	)
																)
															),
														r.length > 0 &&
															React.createElement(
																x,
																null,
																React.createElement(
																	T,
																	{
																		key: o,
																		value: o,
																		options:
																			this.selectOptions(),
																		onChange(
																			t
																		) {
																			return e.onIdChange(
																				parseInt(
																					t
																				)
																			);
																		},
																	}
																),
																0 != o &&
																	React.createElement(
																		M,
																		{
																			target: '_blank',
																			href:
																				modulaAlbumsVars.adminURL +
																				'post.php?post=' +
																				o +
																				'&action=edit',
																			isPrimary:
																				! 0,
																		},
																		C(
																			'Edit Album'
																		)
																	)
															)
													)
												)
											),
									  ]
									: [
											React.createElement(
												x,
												null,
												c,
												React.createElement(
													v,
													w(
														{
															onIdChange( t ) {
																return e.onIdChange(
																	t
																);
															},
														},
														this.props
													)
												),
												React.createElement(
													'div',
													{
														className:
															'modula-block-preview--images',
													},
													a.map( function ( e, t ) {
														return [
															React.createElement(
																'div',
																{
																	className:
																		'modula-preview-image-wrap',
																},
																React.createElement(
																	'img',
																	{
																		src: e.src,
																	}
																)
															),
														];
													} )
												)
											),
									  ];
							},
						},
					] ) && _( t.prototype, n ),
					r && _( t, r ),
					a
				);
			} )( P ),
			z = N( function ( e, t ) {
				return {
					galleries:
						( 0, e( 'core' ).getEntityRecords )(
							'postType',
							'modula-album',
							{ post_status: 'publish', per_page: -1 }
						) || [],
				};
			} )( V ),
			G = {};
		G.modula = React.createElement(
			'svg',
			{
				xmlns: 'http://www.w3.org/2000/svg',
				x: '0px',
				y: '0px',
				viewBox: '364 242.9 312.2 357',
			},
			React.createElement(
				'g',
				null,
				React.createElement( 'path', {
					d: 'M528.1,242.9c8.5,16.9,17,33.8,25.6,50.6c13.4,26.4,26.9,52.7,39.9,79.7c-41.8-23.3-83.6-46.7-125.4-70.1 c0.3-1.9,1.7-2.6,2.7-3.5c17.7-17.7,35.4-35.4,53.1-53c1.1-1.1,2.6-2,3.1-3.7C527.4,242.9,527.8,242.9,528.1,242.9z',
				} ),
				React.createElement( 'path', {
					d: 'M602.3,463.3c11.3-6.9,22.6-13.9,33.9-20.8c5.5-3.4,11.1-6.7,16.5-10.3c2.2-1.4,2.9-1.1,3.5,1.5 c6.4,25.3,13,50.6,19.6,75.8c0.6,2.2,1,3.7-2.4,3.5c-46.7-2.1-93.5-4.1-140.2-6.1c-0.2,0-0.3-0.1-0.5-0.2c0.5-1.7,2.1-2,3.3-2.7 c20-12.3,39.9-24.7,60-36.8c3.4-2.1,5.1-3.7,4.8-8.5c-1.4-21.3-1.8-42.6-2.6-63.9c-0.9-24.1-1.8-48.3-2.8-72.4 c-0.2-6.1-0.2-6.1,5.5-4.6c23.8,6.2,47.6,12.5,71.5,18.5c3.9,1,4.2,1.9,2.1,5.4c-23.4,38.5-46.7,77.1-70,115.7c-1,1.7-2,3.4-3,5.1 C601.7,462.8,602,463,602.3,463.3z',
				} ),
				React.createElement( 'path', {
					d: 'M372.8,326.9c48,2.6,95.8,5.1,143.9,7.7c-0.9,2-2.5,2.3-3.7,3.1c-38.6,23.2-77.3,46.4-115.9,69.6c-3,1.8-4.3,2.6-5.4-1.9 c-5.9-24.9-12.2-49.7-18.3-74.6C373.1,329.6,373,328.4,372.8,326.9z',
				} ),
				React.createElement( 'path', {
					d: 'M517.6,599.9c-23.2-43.7-45.9-86.6-69.2-130.5c2.3,1.2,3.5,1.8,4.7,2.4c39.8,21.5,79.5,43.1,119.3,64.5 c3.2,1.7,4.1,2.5,1,5.6c-17.7,17.8-35.2,35.9-52.8,53.9C519.7,596.9,518.9,598.2,517.6,599.9z',
				} ),
				React.createElement( 'path', {
					d: 'M364.9,505.1c26.6-40.5,53.1-80.8,79.7-121.3c1.3,1.3,0.9,2.5,0.9,3.6c0,46-0.1,92-0.1,137.9c0,3.1-0.2,4.5-4,3.3 c-24.9-7.7-49.9-15.2-74.9-22.8C366,505.8,365.7,505.5,364.9,505.1z',
				} )
			)
		);
		const F = G;
		function Y( e, t ) {
			for ( let n = 0; n < t.length; n++ ) {
				const r = t[ n ];
				( r.enumerable = r.enumerable || ! 1 ),
					( r.configurable = ! 0 ),
					'value' in r && ( r.writable = ! 0 ),
					Object.defineProperty( e, r.key, r );
			}
		}
		const J = wp.i18n.__,
			Q = wp.blocks.registerBlockType;
		new ( ( function () {
			function e() {
				! ( function ( e, t ) {
					if ( ! ( e instanceof t ) ) {
						throw new TypeError(
							'Cannot call a class as a function'
						);
					}
				} )( this, e ),
					this.registerBlock();
			}
			let t, n, r;
			return (
				( t = e ),
				( n = [
					{
						key: 'registerBlock',
						value() {
							( this.blockName = 'modula/albums' ),
								( this.blockAttributes = {
									id: { type: 'number', default: 0 },
								} ),
								Q( this.blockName, {
									title: modulaAlbumsVars.gutenbergAlbumsTitle,
									icon: F.modula,
									description: J(
										'Make your albums stand out.',
										'modula-best-grid-gallery'
									),
									keywords: [
										J( 'gallery' ),
										J( 'modula' ),
										J( 'images' ),
									],
									category: 'common',
									supports: {
										align: [ 'wide', 'full' ],
										customClassName: ! 1,
									},
									attributes: this.blockAttributes,
									edit: z,
									save() {
										return null;
									},
								} );
						},
					},
				] ) && Y( t.prototype, n ),
				r && Y( t, r ),
				e
			);
		} )() )();
	},
] );
