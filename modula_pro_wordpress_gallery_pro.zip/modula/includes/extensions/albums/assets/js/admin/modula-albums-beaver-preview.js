jQuery( function ( $ ) {
	$( '.fl-builder-content' ).on(
		'fl-builder.layout-rendered',
		beaver_album_preview
	);

	function beaver_album_preview() {
		const modula_album = $( '.modula-album' );

		if ( modula_album.length > 0 ) {
			const albumID = modula_album.attr( 'id' ),
				modulaSettings = modula_album.data( 'config' ),
				modulaInstance = jQuery( '#' + albumID ).data(
					'plugin_modulaAlbums'
				);

			if ( modulaInstance ) {
				modulaInstance.destroy();
				jQuery( '#' + albumID ).data( 'plugin_modulaAlbums', null );
			}

			$( '#' + albumID ).modulaAlbums( modulaSettings );
		}
	}
} );
