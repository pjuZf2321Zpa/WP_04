( function ( $ ) {
	const settingsFields = $( '.form-table tr[data-settings]' );

	$( document ).ready( function () {
		if ( 'disabled' == modulaStandalone.gallery.enable_rewrite ) {
			settingsFields.filter( '[data-settings="gallery_slug"]' ).hide();
		}

		if ( 'disabled' == modulaStandalone.album.enable_rewrite ) {
			settingsFields.filter( '[data-settings="album_slug"]' ).hide();
		}

		$( 'input[name="modula_standalone[gallery][enable_rewrite]"]' ).change(
			function () {
				if ( this.checked ) {
					settingsFields
						.filter( '[data-settings="gallery_slug"]' )
						.show();
				} else {
					settingsFields
						.filter( '[data-settings="gallery_slug"]' )
						.hide();
				}
			}
		);

		$( 'input[name="modula_standalone[album][enable_rewrite]"]' ).change(
			function () {
				if ( this.checked ) {
					settingsFields
						.filter( '[data-settings="album_slug"]' )
						.show();
				} else {
					settingsFields
						.filter( '[data-settings="album_slug"]' )
						.hide();
				}
			}
		);
	} );
} )( jQuery );
