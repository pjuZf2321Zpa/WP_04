wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;

( function ( $, modula ) {
	const modulaModal = Backbone.Model.extend( {
		defaults: {
			item: false,
			_frame: false,
		},

		initialize( args ) {
			const modalView = new modula.editModal.view( {
				model: this,
				childViews: args.childViews,
			} );

			const wpMediaView = new wp.media.view.Modal( {
				controller: {
					trigger() {},
				},
			} );

			this.set( 'wpMediaView', wpMediaView );
			this.set( 'modulaModal', modalView );
		},

		open( $item ) {
			const wpMediaView = this.get( 'wpMediaView' ),
				modulaModal = this.get( 'modulaModal' );

			// Set the current item
			this.set( 'item', $item );
			// Render Modula View
			modulaModal.render();
			// Append modulaModalView to wpMediaView
			wpMediaView.content( modulaModal );
			// Open wpMediaView
			wpMediaView.open();

			modulaModal.initEditor();
		},

		frame() {
			const self = this;

			if ( self._frame ) {
				self._frame.state().get( 'selection' ).reset();

				return self._frame;
			}

			self._frame = wp.media( {
				title: 'Select or Upload Cover for your gallery',
				button: {
					text: 'Use as cover',
				},
				multiple: false, // Set to true to allow multiple files to be selected
			} );

			// When an image is selected in the media frame...
			self._frame.on( 'select', function () {
				// Get media attachment details from the frame state
				let attachment = self._frame
						.state()
						.get( 'selection' )
						.first()
						.toJSON(),
					item = self.get( 'item' ),
					url,
					editModal;

				if ( 'undefined' !== typeof attachment.sizes.large ) {
					url = attachment.sizes.large.url;
				} else {
					url = attachment.sizes.full.url;
				}

				if ( 'undefined' !== typeof attachment.sizes.thumbnail ) {
					thumb = attachment.sizes.thumbnail.url;
				} else {
					thumb = attachment.sizes.full.url;
				}

				item.set( 'cover', attachment.id );
				item.set( 'coverURL', url );
				item.set( 'coverThumb', thumb );

				editModal = self.get( 'modulaModal' );
				editModal.render();
			} );

			return this._frame;
		},
	} );

	const modulaModalView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'div',
		className:
			'edit-attachment-frame mode-select hide-menu hide-router modula-edit-popup modula-album-edit-gallery',

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-gallery-editor' ),

		/**
		 * Events
		 * - Functions to call when specific events occur
		 */
		events: {
			'click .edit-media-header .left': 'loadPreviousItem',
			'click .edit-media-header .right': 'loadNextItem',

			'keyup input': 'updateItem',
			'keyup textarea': 'updateItem',
			'change input': 'updateItem',
			'change textarea': 'updateItem',
			'blur textarea': 'updateItem',
			'change select': 'updateItem',

			'click .actions a.modula-gallery-meta-submit': 'saveItem',
			'click .actions a.modula-gallery-meta-submit-close':
				'saveItemAndClose',

			'keyup input#link-search': 'searchLinks',
			'click div.query-results li': 'insertLink',

			'click .button-cover-image': 'openFrame',
			'click .delete-cover': 'deleteCover',
		},

		/**
		 * Initialize
		 *
		 * @param object model   ModulaImage Backbone Model
		 * @param args
		 */
		initialize( args ) {
			// Define loading and loaded events, which update the UI with what's happening.
			this.on( 'loading', this.loading, this );
			this.on( 'loaded', this.loaded, this );

			// Change item when model updates his attribute
			this.listenTo( this.model, 'change:item', this.changeItem );

			// Child Views
			this.childViews = args.childViews;

			// Set some flags
			this.is_loading = false;
			this.search_timer = '';
			this.item = false;
		},

		changeItem() {
			this.item = this.model.get( 'item' );
		},

		/**
		 * Render
		 * - Binds the model to the view, so we populate the view's fields and data
		 */
		render() {
			// Get the current item from model if not exist.
			if ( ! this.item ) {
				this.item = this.model.get( 'item' );
			}

			// Get current Index.
			this.attachment_index = modula.Galleries.indexOf( this.item );

			// Get HTML
			if ( this.item ) {
				this.$el.html( this.template( this.item.toJSON() ) );

				// Generate Child Views
				if ( this.childViews.length > 0 ) {
					this.childViews.forEach( function ( view ) {
						// Init with model
						const childView = new view( {
							model: this.model,
						} );

						// Render view within our main view
						this.$el
							.find( 'div.modula-addons' )
							.append( childView.render().el );
					}, this );
				}
			}

			this.initEditor();

			// Enable / disable the buttons depending on the index
			if ( this.attachment_index == 0 ) {
				// Disable left button
				this.$el.find( 'button.left' ).addClass( 'disabled' );
			}
			if ( this.attachment_index == modula.Galleries.length - 1 ) {
				// Disable right button
				this.$el.find( 'button.right' ).addClass( 'disabled' );
			}

			// Return
			return this;
		},

		/**
		 * Renders an error using
		 * wp.media.view.ModulaGalleryError
		 * @param error
		 */
		renderError( error ) {
			// Define model
			const model = {};
			model.error = error;

			// Define view
			const view = new wp.media.view.ModulaGalleryError( {
				model,
			} );

			// Return rendered view
			return view.render().el;
		},

		/**
		 * Tells the view we're loading by displaying a spinner
		 */
		loading() {
			// Set a flag so we know we're loading data
			this.is_loading = true;

			// Show the spinner
			this.$el.find( '.spinner' ).css( 'visibility', 'visible' );
		},

		/**
		 * Hides the loading spinner
		 * @param response
		 */
		loaded( response ) {
			// Set a flag so we know we're not loading anything now
			this.is_loading = false;

			// Hide the spinner
			this.$el.find( '.spinner' ).css( 'visibility', 'hidden' );

			// Display the error message, if it's provided
			if ( typeof response !== 'undefined' ) {
				this.$el
					.find( 'div.media-toolbar' )
					.after( this.renderError( response ) );
			}
		},

		/**
		 * Load the previous model in the collection
		 */
		loadPreviousItem() {
			let item;

			// Decrement the index
			this.attachment_index--;

			// Get the model at the new index from the collection
			item = modula.Galleries.at( this.attachment_index );
			this.model.set( 'item', item );

			// Re-render the view
			this.render();
		},

		/**
		 * Load the next model in the collection
		 */
		loadNextItem() {
			let item;

			// Increment the index
			this.attachment_index++;

			// Get the model at the new index from the collection
			item = modula.Galleries.at( this.attachment_index );
			this.model.set( 'item', item );

			// Re-render the view
			this.render();
		},

		/**
		 * Updates the model based on the changed view data
		 * @param event
		 */
		updateItem( event ) {
			// Check if the target has a name. If not, it's not a model value we want to store
			if ( event.target.name == '' ) {
				return;
			}

			// Update the model's value, depending on the input type
			if ( event.target.type == 'checkbox' ) {
				value = event.target.checked ? event.target.value : 0;
			} else {
				value = event.target.value;
			}

			// Update the model
			this.item.set( event.target.name, value );
		},

		/**
		 * Saves the image metadata
		 * @param event
		 */
		saveItem( event ) {
			let view,
				self = this,
				item = this.model.get( 'item' );

			event.preventDefault();

			// Tell the View we're loading
			this.trigger( 'loading' );

			// Get item view and render it.
			view = this.item.get( 'view' );
			view.render();

			// Show the user the 'saved' notice for 1.5 seconds
			const saved = this.$el.find( '.saved' );
			saved.fadeIn();

			if (
				typeof tinymce !== 'undefined' &&
				tinymce.get( 'modula_album_caption' )
			) {
				this.item.set(
					'caption',
					wp.editor.getContent( 'modula_album_caption' )
				);
			}

			wp.Modula.Save.saveImage( item.get( 'id' ), function () {
				// Tell the view we've finished successfully
				self.trigger( 'loaded loaded:success' );
				saved.fadeOut();
			} );
		},

		saveItemAndClose( event ) {
			let view,
				self = this;

			event.preventDefault();

			// Tell the View we're loading
			this.trigger( 'loading' );

			if (
				typeof tinymce !== 'undefined' &&
				tinymce.get( 'modula_album_caption' )
			) {
				this.item.set(
					'caption',
					wp.editor.getContent( 'modula_album_caption' )
				);
			}

			clearInterval( wp.Modula.Save.updateInterval );
			wp.Modula.Save.saveImages( function () {
				// Get item view and render it.
				view = self.model.get( 'wpMediaView' );
				view.close();
			} );
		},

		deleteCover() {
			const self = this,
				item = self.model.get( 'item' );

			item.set( 'cover', 0 );
			item.set( 'coverURL', '' );
			item.set( 'coverThumb', '' );

			editModal = self.model.get( 'modulaModal' );
			editModal.render();
		},

		/**
		 * Searches Links
		 * @param event
		 */
		searchLinks( event ) {},

		/**
		 * Inserts the clicked link into the URL field
		 * @param event
		 */
		insertLink( event ) {},

		openFrame( event ) {
			const self = this;
			self.model.frame().open();
		},

		initEditor() {
			if ( typeof wp.editor !== 'undefined' ) {
				wp.editor.remove( 'modula_album_caption' );
			} else if (
				typeof tinymce !== 'undefined' &&
				tinymce.get( 'modula_album_caption' )
			) {
				tinymce.get( 'modula_album_caption' ).remove();
			}

			if ( typeof wp.editor !== 'undefined' ) {
				wp.editor.initialize( 'modula_album_caption', {
					tinymce: {
						resize: false,
						quicktags: false,
						branding: false,
						menubar: false,
						wpautop: false,
						statusbar: false,
						forced_root_block: false,
						forced_br_newlines: true,
						force_p_newlines: false,
						convert_newlines_to_brs: true,
						remove_linebreaks: false,
						plugins: 'lists link textcolor colorpicker',
						toolbar1:
							'bold italic underline strikethrough | bullist numlist | link unlink',
						content_style:
							'a[data-mce-selected] { box-shadow: none !important; background-color: transparent !important; }',
					},
					quicktags: true,
				} );
			}
		},
	} );

	modula.editModal = {
		model: modulaModal,
		view: modulaModalView,
	};
} )( jQuery, wp.Modula );
