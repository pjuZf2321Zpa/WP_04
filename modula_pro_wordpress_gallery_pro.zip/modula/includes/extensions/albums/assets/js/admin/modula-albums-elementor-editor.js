jQuery( function ( $ ) {
	elementor.hooks.addAction(
		'panel/open_editor/widget/modula_albums_elementor',
		function ( panel, model, view ) {
			// Get search input
			search_input = panel.$el.find(
				'select[data-setting="modula_albums_select"]'
			);

			const search_input_active =
				model.attributes.settings.attributes.modula_albums_select;

			let search_val, timer, selective_input;

			// Initialize the selectize
			search_input.selectize( {
				create: false,
				maxItems: 1,
				closeAfterSelect: true,

				valueField: 'ID',
				labelField: 'post_title',
				searchField: 'post_title',

				load( query, callback ) {
					if ( ! query.length ) {
						return callback();
					}

					jQuery.ajax( {
						url: modula_albums_elementor_ajax.ajax_url,
						type: 'POST',
						dataType: 'json',
						data: {
							action: 'modula_albums_elementor_ajax_search',
							s: query,
						},
						error() {
							callback();
						},
						success( response ) {
							callback( response.data );
						},
					} );
				},
			} );
		}
	);
} );
