wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;

( function ( $, modula ) {
	const selection = Backbone.Collection.extend( {} );
	const library = Backbone.Collection.extend( {
		modelId( attrs ) {
			return attrs.id;
		},

		searchItems( string ) {
			const library = this;

			elements = _.filter( library.models, function ( item ) {
				const title = item.get( 'title' ).toLowerCase(),
					check = title.search( string );

				if ( -1 == check ) {
					item.set( 'visible', false );
					return false;
				}
				item.set( 'visible', true );
				return true;
			} );

			library.trigger( 'modula-search-complete' );
			return elements;
		},
	} );

	const modal = Backbone.Model.extend( {
		initialize( args ) {
			const self = this;
			const selection = new modula.modal.selection();
			const library = new modula.modal.library();
			this.set( 'selection', selection );
			this.set( 'library', library );

			// var library = ;
			wp.ajax
				.post( 'modula_get_galleries', {
					_wpnonce: modulaAlbumsAdmin._wpnonce,
				} )
				.done( function ( data ) {
					jQuery.each( data, function ( index, gallery ) {
						// Create Models
						const item = new modula.modal.itemModel( gallery );
						library.add( item );
					} );

					self.set( 'library', library );
				} );

			const modalView = new modula.modal.view( {
				model: this,
			} );
			this.set( 'modalView', modalView );

			const wpMediaView = new wp.media.view.Modal( {
				controller: {
					trigger() {},
				},
				title: 'Choose Galleries',
			} );
			this.set( 'modal', wpMediaView );
		},
		open() {
			const modal = this.get( 'modal' ),
				modalView = this.get( 'modalView' ),
				selection = this.get( 'selection' ),
				library = this.get( 'library' );

			_.each( modula.Galleries.models, function ( item ) {
				const id = item.get( 'id' ),
					itemLibrary = library.get( id );

				selection.add( itemLibrary );
			} );

			// Render Modula View
			modalView.render();
			// Append modulaModalView to wpMediaView
			modal.content( modalView );
			// Open wpMediaView
			modal.open();
		},
		close() {
			const modal = this.get( 'modal' ),
				selection = this.get( 'selection' ),
				albumsLib = modula.albumsModal
					? modula.albumsModal.get( 'library' )
					: null,
				oldGalleriesCollection = wp.Modula.Galleries;

			_.each( modula.Galleries.models, function ( item ) {
				const id = item.get( 'id' ),
					itemLibrary = albumsLib.get( id );
				selection.add( itemLibrary );
			} );

			modula.Galleries = new modula.galleries.collection();
			const addToStart = jQuery( '#modula-upload-position-start' ).is(
				':checked'
			);

			const existingModels = [];

			selection.each( function ( gallery ) {
				const atts = gallery.toJSON(),
					currentModel = oldGalleriesCollection.get( atts.id );

				if ( currentModel ) {
					existingModels.push( currentModel );
					oldGalleriesCollection.remove( currentModel );
				} else {
					new modula.galleries.model( atts );
				}
			} );

			if ( addToStart ) {
				existingModels.forEach( function ( model ) {
					modula.Galleries.addItem( model );
				} );
			} else {
				const current = modula.Galleries.models.slice();
				modula.Galleries.reset( existingModels.concat( current ) );
			}

			while ( ( model = oldGalleriesCollection.first() ) ) {
				model.delete();
			}

			modula.Galleries.each( function ( model, index ) {
				model.set( 'index', index );
			} );

			if ( modula.GalleryView && modula.GalleryView.container ) {
				const container = modula.GalleryView.container;

				modula.Galleries.each( function ( model ) {
					const view = model.get( 'view' );
					if ( view && view.$el ) {
						container.append( view.$el );
						view.delegateEvents();
					}
				} );

				if ( container.data( 'packery' ) ) {
					container.packery( 'destroy' );
				}

				container.packery( {
					itemSelector: '.modula-single-image',
					gutter: parseInt( wp.Modula.Resizer.get( 'gutter' ) ),
					columnWidth: wp.Modula.Resizer.get( 'size' ),
					rowHeight: wp.Modula.Resizer.get( 'size' ),
				} );
			}

			modal.close();
			selection.reset();
			modula.Galleries.each( function ( model ) {
				model.resize();
			} );

			wp.Modula.Events.trigger( 'modula_album_items_changed' );
		},
	} );

	const itemModel = Backbone.Model.extend( {
		/**
		 * Defaults
		 * As we always populate this model with existing data, we
		 * leave these blank to just show how this model is structured.
		 */
		defaults: {
			id: '',
			title: '',
			caption: '',
			alt: '',
			visible: true,
			cover: 0,
			customurl: '',
			coverinfo: {},
			thumb: {},
			images: {},
			itemType: 'modula-gallery',
		},

		initialize( args ) {
			const library = modula.galleriesModal.get( 'library' );
			this.listenTo( library, 'modula-search-complete', function () {
				const visible = this.get( 'visible' ),
					view = this.get( 'view' );

				if ( ! visible ) {
					if ( view ) {
						view.$el.hide();
					}
				} else if ( view ) {
					view.$el.show();
				}
			} );
		},
	} );

	const modalView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'div',
		className: 'modula-bulkedit-popup',
		childViews: [],
		items: [],

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-albums-bulkedit' ),

		events: {
			'click #save-modula-albums-galleries': 'close',
			'click #modula-select-all': 'select',
			'click #modula-deselect-all': 'deselect',
			'click #modula-toggle': 'toggle',
			'keyup #modula-search-input': 'search',
			'change #modula-search-input': 'search',
		},

		initialize() {
			const self = this;
		},

		/**
		 * Render
		 * - Binds the model to the view, so we populate the view's fields and data
		 */
		render() {
			const self = this,
				selection = this.model.get( 'selection' ),
				library = this.model.get( 'library' );

			// Reset selection
			// selection.reset();

			// Get HTML
			this.$el.html( this.template() );

			// Left area
			library.each( function ( item ) {
				const view = item.get( 'view' );

				if ( '' == item.attributes.title ) {
					item.attributes.title = 'Untitled';
				}

				if ( view ) {
					view.remove();
				}

				const newView = new modula.modal.itemView( { model: item } );
				item.set( 'view', newView );

				self.$el.find( 'ul.attachments' ).append( newView.render().el );
			} );
		},

		close() {
			const self = this;
			self.model.close();
		},

		select() {
			const selection = this.model.get( 'selection' ),
				library = this.model.get( 'library' );
			selection.add( library.models );
		},

		deselect() {
			const selection = this.model.get( 'selection' );
			selection.reset();
		},

		toggle() {
			const selection = this.model.get( 'selection' ),
				library = this.model.get( 'library' ),
				oldSelection = selection.clone();

			if ( selection.length == 0 ) {
				selection.add( modula.Items.models );
			} else if ( selection.length == modula.Items.length ) {
				selection.reset();
			} else {
				selection.reset();
				library.each( function ( item ) {
					if (
						! oldSelection.findWhere( { id: item.get( 'id' ) } )
					) {
						selection.add( item );
					}
				} );
			}

			oldSelection.reset();
		},

		search() {
			const self = this,
				searchInput = self.$el.find( '#modula-search-input' ),
				library = self.model.get( 'library' );

			library.searchItems( searchInput.val() );
		},
	} );

	const itemView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'li',
		className: 'attachment',

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-gallery-item' ),

		events: {
			click: 'checkStatus',
		},

		initialize( args ) {
			const selection = modula.galleriesModal.get( 'selection' );
			this.listenTo( selection, 'add', this.itemAdded );
			this.listenTo( selection, 'remove', this.itemRemoved );
			this.listenTo( selection, 'reset', this.removeItem );

			this.checkSelected();
		},

		checkSelected() {
			const model = this.model,
				selection = modula.galleriesModal.get( 'selection' );

			if ( selection.contains( model ) ) {
				this.$el.addClass( 'selected details' );
			}
		},

		/**
		 * Render
		 * - Binds the model to the view, so we populate the view's fields and data
		 */
		render() {
			// Get HTML
			this.$el.html( this.template( this.model.toJSON() ) );
			return this;
		},

		checkStatus() {
			const selection = modula.galleriesModal.get( 'selection' );

			if ( this.$el.hasClass( 'selected' ) ) {
				selection.remove( this.model );
				// this.$el.removeClass( 'selected details' );
			} else {
				selection.add( this.model );
				// this.$el.addClass( 'selected details' );
			}
		},

		itemAdded() {
			const selection = modula.galleriesModal.get( 'selection' );

			if ( selection.findWhere( { id: this.model.get( 'id' ) } ) ) {
				this.$el.addClass( 'selected details' );
			}
		},

		itemRemoved() {
			const selection = modula.galleriesModal.get( 'selection' );
			if ( ! selection.findWhere( { id: this.model.get( 'id' ) } ) ) {
				this.$el.removeClass( 'selected details' );
			}
		},

		removeItem() {
			this.$el.removeClass( 'selected details' );
		},
	} );

	modula.modal = {
		model: modal,
		view: modalView,
		selection,
		library,
		itemView,
		itemModel,
	};
} )( jQuery, wp.Modula );
