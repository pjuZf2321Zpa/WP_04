jQuery( document ).ready( function ( $ ) {
	// Copy shortcode functionality
	$( '.copy-modula-shortcode' ).click( function ( e ) {
		e.preventDefault();
		const gallery_shortcode = $( this ).parent().find( 'input' );
		gallery_shortcode.focus();
		gallery_shortcode.select();
		document.execCommand( 'copy' );
		$( this ).next( 'span' ).text( 'Shortcode copied' );
		$( '.copy-modula-shortcode' )
			.not( $( this ) )
			.parent()
			.find( 'span' )
			.text( '' );
	} );
} );
