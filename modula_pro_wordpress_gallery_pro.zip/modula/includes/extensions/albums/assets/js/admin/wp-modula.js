wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;
wp.Modula.modalChildViews =
	'undefined' === typeof wp.Modula.modalChildViews
		? []
		: wp.Modula.modalChildViews;
wp.Modula.previewer =
	'undefined' === typeof wp.Modula.previewer ? {} : wp.Modula.previewer;
wp.Modula.modal = 'undefined' === typeof wp.Modula.modal ? {} : wp.Modula.modal;
wp.Modula.amodal =
	'undefined' === typeof wp.Modula.amodal ? {} : wp.Modula.amodal;
wp.Modula.galleries =
	'undefined' === typeof wp.Modula.galleries ? {} : wp.Modula.galleries;
wp.Modula.upload =
	'undefined' === typeof wp.Modula.upload ? {} : wp.Modula.upload;

jQuery( document ).ready( function ( $ ) {
	// Here we will have all gallery's items.
	if ( wp.Modula.galleries.collection ) {
		wp.Modula.Galleries = new wp.Modula.galleries.collection();
	}

	// Settings related objects.
	wp.Modula.Settings = new wp.Modula.settings.model(
		modulaAlbumsHelper.settings
	);
	wp.Modula.Events = wp.Modula.Events || _.extend( {}, Backbone.Events );

	// Add this here in order for other extensions to hook into it. This fixes some problems regarding the
	// order of execution.
	jQuery( document ).trigger( 'modula_albums_admin_trigger' );

	// Initiate Modula Resizer
	if (
		'undefined' === typeof wp.Modula.Resizer &&
		wp.Modula.previewer.resizer
	) {
		wp.Modula.Resizer = new wp.Modula.previewer.resizer();
	}

	// Initiate Gallery View
	if ( wp.Modula.previewer.view ) {
		wp.Modula.GalleryView = new wp.Modula.previewer.view( {
			el: $( '#modula-uploader-container' ),
		} );
	}

	if ( 'undefined' !== typeof wp.Modula.editModal ) {
		// Modula edit item modal.
		wp.Modula.EditModal = new wp.Modula.editModal.model( {
			childViews: wp.Modula.modalChildViews,
		} );
	}

	// Here we will add items for the gallery to collection.
	if ( 'undefined' !== typeof modulaAlbumsHelper.items ) {
		$.each( modulaAlbumsHelper.items, function ( index, image ) {
			const imageModel = new wp.Modula.galleries.model( image );
		} );
	}

	// Modula conditions
	wp.Modula.Conditions = new modulaAlbumsConditions();

	// Hover Effects
	wp.Modula.hovereffects.init();

	// Bulk Edit
	if ( wp.Modula.modal.model ) {
		wp.Modula.galleriesModal = new wp.Modula.modal.model();
	}

	$( '#modula-wp-gallery' )
		.off( 'click' )
		.on( 'click', function ( evt ) {
			evt.preventDefault();
			wp.Modula.galleriesModal.open();
		} );

	if ( wp.Modula.amodal.model ) {
		wp.Modula.albumsModal = new wp.Modula.amodal.model();
	}

	$( '#modula-wp-album' ).click( function ( evt ) {
		evt.preventDefault();
		wp.Modula.albumsModal.open();
	} );

	// Save on CTRL/Meta Key + S
	$( document ).keydown( function ( e ) {
		if (
			( e.keyCode === 115 || e.keyCode === 83 ) &&
			( e.ctrlKey || e.metaKey ) &&
			! e.altKey
		) {
			e.preventDefault();
			$( '#publish' ).click();
			return false;
		}
	} );
	jQuery(
		'tr[data-container="lightboxEmailMessage"] td .modula-placeholders'
	).on( 'click', 'span', function () {
		const input = jQuery( 'textarea[data-setting="lightboxEmailMessage"]' );
		const placeholder = jQuery( this ).attr( 'data-placeholder' );
		input.val( function ( index, value ) {
			value += placeholder;
			return value;
		} );
	} );
	jQuery( document ).on(
		'click',
		'#modula-hover-effect .modula-hover-effect-item',
		function () {
			const input = jQuery( this ).find( 'input[type="radio"]' );
			if ( input.length > 0 ) {
				input.prop( 'checked', false );
				input.prop( 'checked', true );
				input.trigger( 'change' );
			}
		}
	);

	// Open WordPress Media Gallery
	$( '#modula_album_add_action_button' ).click( function ( e ) {
		e.preventDefault();
		e.stopPropagation();
		if ( $( '#modula_album_add_action' ).hasClass( 'open' ) ) {
			$( '#modula_album_add_action' ).hide().removeClass( 'open' );
		} else {
			$( '#modula_album_add_action' ).show().addClass( 'open' );
		}
	} );

	$( '#modula_album_add_action li' ).click( function ( e ) {
		$( '#modula_album_add_action' ).hide().removeClass( 'open' );
	} );
	// Close the Add New info box on click outside
	$( document ).on( 'click', function ( e ) {
		if ( ! $( e.target ).closest( '#modula_album_add_action' ).length ) {
			$( '#modula_album_add_action' ).hide().removeClass( 'open' );
		}
	} );

	const checkSticky = () => {
		const sideSortables = document.getElementById( 'side-sortables' );
		const submitDiv = document.getElementById( 'submitdiv' );

		if ( ! submitDiv || ! sideSortables ) {
			return;
		}

		const offsetTop = submitDiv.offsetTop + 100;
		const stickyClass = 'is-sticky';
		if ( window.scrollY >= offsetTop ) {
			sideSortables.classList.add( stickyClass );
		} else {
			sideSortables.classList.remove( stickyClass );
		}
	};

	window.addEventListener( 'scroll', checkSticky );

	checkSticky();

	//prevents the album metaboxes from being dragged.
	$(
		'#normal-sortables:has(.modula-no-drag), #side-sortables:has(.modula-no-drag)'
	).off();
} );
