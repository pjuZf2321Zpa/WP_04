( function ( $ ) {
	$( document ).ready( function () {
		$( 'html body' ).on(
			'click',
			'#modula_albums_pro_check button.notice-dismiss',
			function () {
				jQuery.ajax( {
					url: ajaxurl,
					type: JSON,
					method: 'POST',
					data: {
						action: 'dismiss_albums_notice',
						nonce: modulaAlbumsNonce,
					},
				} );
			}
		);
	} );
} )( jQuery );
