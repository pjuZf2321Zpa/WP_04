wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;

( function ( $, modula ) {
	const modulaSaveGalleries = {
		updateInterval: false,

		checkSave() {
			const self = this;

			$( '#publishing-action .spinner' ).addClass( 'is-active' );
			$( '#publishing-action #publish' ).attr( 'disabled', 'disabled' );

			if ( ! self.updateInterval ) {
				self.updateInterval = setInterval(
					$.proxy( self.saveImages, self ),
					1000
				);
			} else {
				clearInterval( self.updateInterval );
				self.updateInterval = setInterval(
					$.proxy( self.saveImages, self ),
					1000
				);
			}
		},

		saveImages( callback = false ) {
			let galleries = [],
				self = this,
				ajaxData;

			clearInterval( self.updateInterval );

			wp.Modula.Galleries.each( function ( item ) {
				const attributes = item.getAttributes();
				galleries[ attributes.index ] = attributes;
			} );

			ajaxData = {
				_wpnonce: modulaAlbumsHelper._wpnonce,
				action: 'modula_albums_save_galleries',
				album: modulaAlbumsHelper.id,
			};
			ajaxData.galleries = JSON.stringify( galleries );

			$.ajax( {
				method: 'POST',
				url: modulaAlbumsHelper.ajax_url,
				data: ajaxData,
				dataType: 'json',
			} ).done( function ( msg ) {
				$( '#publishing-action .spinner' ).removeClass( 'is-active' );
				$( '#publishing-action #publish' ).removeAttr( 'disabled' );

				if ( typeof callback === 'function' ) {
					callback();
				}
			} );
		},

		saveImage( id, callback = false ) {
			const gallery = wp.Modula.Galleries.get( id ),
				json = gallery.getAttributes();

			$( '#publishing-action .spinner' ).addClass( 'is-active' );
			$( '#publishing-action #publish' ).attr( 'disabled', 'disabled' );

			ajaxData = {
				_wpnonce: modulaAlbumsHelper._wpnonce,
				action: 'modula_albums_save_gallery',
				album: modulaAlbumsHelper.id,
			};
			ajaxData.gallery = JSON.stringify( json );

			$.ajax( {
				method: 'POST',
				url: modulaAlbumsHelper.ajax_url,
				data: ajaxData,
				dataType: 'json',
			} ).done( function ( msg ) {
				$( '#publishing-action .spinner' ).removeClass( 'is-active' );
				$( '#publishing-action #publish' ).removeAttr( 'disabled' );

				if ( typeof callback === 'function' ) {
					callback();
				}
			} );
		},
	};

	modula.Save = modulaSaveGalleries;
} )( jQuery, wp.Modula );
