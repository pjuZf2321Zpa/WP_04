wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;

( function ( $, modula ) {
	const ModulaToolbar = wp.media.view.Toolbar.Select.extend( {
		clickSelect() {
			const controller = this.controller,
				state = controller.state(),
				selection = state.get( 'selection' );

			controller.close();
			state.trigger( 'insert', selection ).reset();
		},
	} );

	const ModulaAttachmentsBrowser = wp.media.view.AttachmentsBrowser.extend( {
		createToolbar() {
			let LibraryViewSwitcher, Filters, toolbarOptions;

			wp.media.view.AttachmentsBrowser.prototype.createToolbar.call(
				this
			);

			this.toolbar.set(
				'modula-error',
				new modula.upload.errorview( {
					controller: this.controller,
					priority: -80,
				} )
			);
		},
	} );

	const ModulaFrame = wp.media.view.MediaFrame.Select.extend( {
		className: 'media-frame modula-media-modal',

		createStates() {
			const options = this.options;

			if ( this.options.states ) {
				return;
			}

			// Add the default states.
			this.states.add( [
				// Main states.
				new modula.upload.library( {
					library: wp.media.query( options.library ),
					multiple: options.multiple,
					title: options.title,
					priority: 20,
				} ),
			] );
		},

		createSelectToolbar( toolbar, options ) {
			options = options || this.options.button || {};
			options.controller = this;

			toolbar.view = new modula.upload.toolbar( options );
		},

		browseContent( contentRegion ) {
			const state = this.state();

			// this.$el.removeClass('hide-toolbar');

			// Browse our library of attachments.
			contentRegion.view = new modula.upload.attachmentsbrowser( {
				// contentRegion.view = new wp.media.view.AttachmentsBrowser({
				controller: this,
				collection: state.get( 'library' ),
				selection: state.get( 'selection' ),
				model: state,
				sortable: state.get( 'sortable' ),
				search: state.get( 'searchable' ),
				filters: state.get( 'filterable' ),
				date: state.get( 'date' ),
				display: state.has( 'display' )
					? state.get( 'display' )
					: state.get( 'displaySettings' ),
				dragInfo: state.get( 'dragInfo' ),

				idealColumnWidth: state.get( 'idealColumnWidth' ),
				suggestedWidth: state.get( 'suggestedWidth' ),
				suggestedHeight: state.get( 'suggestedHeight' ),

				AttachmentView: state.get( 'AttachmentView' ),
			} );
		},
	} );

	const ModulaSelection = wp.media.model.Selection.extend( {
		add( models, options ) {
			let needed, differences;

			if ( ! this.multiple ) {
				this.remove( this.models );
			}

			if ( this.length >= 20 ) {
				models = [];
				wp.media.frames.modula.trigger( 'modula:show-error', {
					message: modulaAlbumsHelper.strings.limitExceeded,
				} );
			} else {
				needed = 20 - this.length;

				if ( Array.isArray( models ) && models.length > 1 ) {
					// Create an array with elements that we don't have in our selection
					differences = _.difference(
						_.pluck( models, 'cid' ),
						_.pluck( this.models, 'cid' )
					);

					// Check if we have mode elements that we need
					if ( differences.length > needed ) {
						// Filter our models, to have only that we don't have already
						models = _.filter( models, function ( model ) {
							return _.contains( differences, model.cid );
						} );
						// Get only how many we need.
						models = models.slice( 0, needed );
						wp.media.frames.modula.trigger( 'modula:show-error', {
							message: modulaAlbumsHelper.strings.limitExceeded,
						} );
					}
				}
			}

			/**
			 * call 'add' directly on the parent class
			 */
			return wp.media.model.Attachments.prototype.add.call(
				this,
				models,
				options
			);
		},
	} );

	const ModulaLibrary = wp.media.controller.Library.extend( {
		initialize() {
			let selection = this.get( 'selection' ),
				props;

			if ( ! this.get( 'library' ) ) {
				this.set( 'library', wp.media.query() );
			}

			if ( ! ( selection instanceof modula.upload.selection ) ) {
				props = selection;

				if ( ! props ) {
					props = this.get( 'library' ).props.toJSON();
					props = _.omit( props, 'orderby', 'query' );
				}

				this.set(
					'selection',
					new modula.upload.selection( null, {
						multiple: this.get( 'multiple' ),
						props,
					} )
				);
			}

			this.resetDisplays();
		},
	} );

	const ModulaError = wp.media.View.extend( {
		tagName: 'div',
		className: 'modula-error-container hide',
		errorTimeout: false,
		delay: 400,
		message: '',

		initialize() {
			this.controller.on( 'modula:show-error', this.show, this );
			this.controller.on( 'modula:hide-error', this.hide, this );

			this.render();
		},

		show( e ) {
			if ( 'undefined' !== typeof e.message ) {
				this.message = e.message;
			}

			if ( '' != this.message ) {
				this.render();
				this.$el.removeClass( 'hide' );
			}
		},

		hide() {
			this.$el.addClass( 'hide' );
		},

		render() {
			const html =
				'<div class="modula-error"><span>' +
				this.message +
				'</span></div>';
			this.$el.html( html );
		},
	} );

	modula.upload = {
		toolbar: ModulaToolbar,
		attachmentsbrowser: ModulaAttachmentsBrowser,
		frame: ModulaFrame,
		selection: ModulaSelection,
		library: ModulaLibrary,
		errorview: ModulaError,
	};
} )( jQuery, wp.Modula );
