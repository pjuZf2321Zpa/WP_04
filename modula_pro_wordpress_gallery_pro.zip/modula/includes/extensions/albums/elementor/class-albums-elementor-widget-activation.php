<?php

namespace Modula_Pro\Extensions\Albums\Elementor;

use Modula_Pro\Extensions\Albums\Elementor\Widgets\Modula_Albums_Elementor;
use Modula_Pro\Extensions\Albums\V2\Visitor\Renderer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Albums_Elementor_Widget_Activation {

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function include_widgets_files() {
		new Modula_Albums_Elementor();
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since  1.2.0
	 * @access public
	 */
	public function register_widgets() {
		$this->include_widgets_files();
		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Modula_Albums_Elementor() );
	}

	public function __construct() {

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_widgets' ) );

		// Enqueue needed scripts for elementor Editor
		add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'modula_albums_elementor_enqueue_editor_scripts' ) );

		// Enqueue needed scripts and styles in Elementor preview
		add_action( 'elementor/preview/enqueue_scripts', array( $this, 'modula_albums_elementor_enqueue_scripts' ) );
		add_action( 'elementor/preview/enqueue_styles', array( $this, 'modula_albums_elementor_enqueue_styles' ) );

		add_action( 'wp_ajax_modula_albums_elementor_ajax_search', array( $this, 'modula_albums_elementor_ajax_search' ) );
	}

	public function modula_albums_elementor_enqueue_editor_scripts() {
		wp_enqueue_script( 'modula-albums-elementor-editor', \MODULA_PRO_URL . 'includes/extensions/albums/assets/js/admin/modula-albums-elementor-editor.js', null, \MODULA_PRO_VERSION, true );
		wp_localize_script(
			'modula-albums-elementor-editor',
			'modula_albums_elementor_ajax',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
			)
		);

		wp_enqueue_script( 'modula-selectize', \MODULA_PRO_URL . 'assets/js/admin/selectize.js', null, \MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-selectize', \MODULA_PRO_URL . 'assets/css/admin/selectize.default.css', null, \MODULA_PRO_VERSION );
	}

	/**
	 * Enqueue scripts in Elementor preview
	 */
	public function modula_albums_elementor_enqueue_scripts() {

		do_action( 'modula_albums_elementor_before_enqueue_scripts' );

		wp_enqueue_script( 'modula-lazysizes' );
		wp_enqueue_script( 'modula-fancybox' );
		wp_enqueue_script( 'modula-isotope' );
		wp_enqueue_script( 'modula-isotope-packery' );
		wp_enqueue_script( 'modula-albums' );

		// Elementor renders the widget over AJAX, so the shortcode of a Beta
		// album cannot enqueue the Album visitor frontend in the preview. When
		// the bundle is not built, the shortcode prints its own error.
		Renderer::enqueue_assets();

		do_action( 'modula_albums_elementor_before_enqueue_elementor-preview' );

		wp_enqueue_script( 'modula-albums-elementor-preview', \MODULA_PRO_URL . 'includes/extensions/albums/assets/js/admin/modula-albums-elementor-preview.js', null, \MODULA_PRO_VERSION, true );

		do_action( 'modula_albums_elementor_after_enqueue_scripts' );
	}

	/**
	 *  Enqueue styles in Elementor preview
	 */
	public function modula_albums_elementor_enqueue_styles() {
		do_action( 'modula_albums_elementor_before_enqueue_styles' );
		wp_enqueue_style( 'modula-albums' );
		wp_enqueue_style( 'modula-album-grid-system' );
		wp_enqueue_style( 'modula' );
		do_action( 'modula_albums_elementor_after_enqueue_styles' );
	}

	public function modula_albums_elementor_ajax_search() {
		// phpcs:ignore WordPress.Security
		if ( 'modula_elementor_ajax_search' !== $_POST['action'] ) {
			wp_send_json_error();
			return;
		}

		// phpcs:ignore WordPress.Security
		if ( '' === $_POST['s'] ) {
			wp_send_json_success();
			return;
		}

		$args = array(
			'post_type'      => 'modula-album',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
			// phpcs:ignore WordPress.Security
			's'              => sanitize_text_field( wp_unslash( $_POST['s'] ) ),
		);

		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) {
			$galleries = $query->posts;
			wp_send_json_success( $galleries );
		}

		wp_send_json_success();
	}
}
