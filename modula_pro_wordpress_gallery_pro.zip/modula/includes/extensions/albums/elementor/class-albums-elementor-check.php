<?php
namespace Modula_Pro\Extensions\Albums\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Albums_Elementor_Check {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.7
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.7';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.7
	 * @var string Minimum Elementor version required to run the elementor block.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.4.5';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.7
	 * @var string Minimum PHP version required to run the elementor block.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Constructor
	 *
	 * @since  1.0.7
	 * @access public
	 */
	public function __construct() {

		// Init Plugin
		$this->init();
	}

	public function init() {

		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( \ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );
			return;
		}

		add_action( 'elementor/widgets/widgets_registered', array( $this, 'remove_modula_widget' ), 15 );

		new Albums_Elementor_Widget_Activation();
	}


	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since  1.0.7
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			// translators: %1$s: Modula Albums Elementor widget, %2$s: Elementor, %3$s: Minimum Elementor version
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'modula-pro' ),
			'<strong>' . esc_html__( 'Modula Albums Elementor widget', 'modula-pro' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'modula-pro' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since  1.0.7
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			// translators: %1$s: Modula Albums Elementor widget, %2$s: PHP, %3$s: Minimum PHP version
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'modula-pro' ),
			'<strong>' . esc_html__( 'Modula Albums Elementor widget', 'modula-pro' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'modula-pro' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/* Remove WordPress widget because we have a dedicated Elementor Widget */
	public function remove_modula_widget( $widget_manager ) {
		$widget_manager->unregister_widget_type( 'wp-widget-modula_albums_widget' );
	}
}
