<?php
namespace Modula_Pro\Extensions\Albums\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hover_Effects {

	public static function get_hover_effects() {
		return apply_filters(
			'modula_albums_hover_effects',
			array(
				'none'     => esc_html__( '1. None', 'modula-pro' ),
				'under'    => esc_html__( '2. Under Image', 'modula-pro' ),
				'pufrobo'  => esc_html__( '3. Pufrobo', 'modula-pro' ),
				'fluid-up' => esc_html__( '4. Fluid Up', 'modula-pro' ),
				'hide'     => esc_html__( '5. Hide', 'modula-pro' ),
				'quiet'    => esc_html__( '6. Quiet', 'modula-pro' ),
				'reflex'   => esc_html__( '7. Reflex', 'modula-pro' ),
				'lens'     => esc_html__( '8. Lens', 'modula-pro' ),
				'appear'   => esc_html__( '9. Appear', 'modula-pro' ),
				'crafty'   => esc_html__( '10. Crafty', 'modula-pro' ),
				'seemo'    => esc_html__( '11. Seemo', 'modula-pro' ),
				'comodo'   => esc_html__( '12. Comodo', 'modula-pro' ),
				'lily'     => esc_html__( '13. Lily', 'modula-pro' ),
				'sadie'    => esc_html__( '14. Sadie', 'modula-pro' ),
				'honey'    => esc_html__( '15. Honey', 'modula-pro' ),
				'layla'    => esc_html__( '16. Layla', 'modula-pro' ),
				'zoe'      => esc_html__( '17. Zoe', 'modula-pro' ),
				'oscar'    => esc_html__( '18. Oscar', 'modula-pro' ),
				'marley'   => esc_html__( '19. Marley', 'modula-pro' ),
				'ruby'     => esc_html__( '20. Ruby', 'modula-pro' ),
				'roxy'     => esc_html__( '21. Roxy', 'modula-pro' ),
				'bubba'    => esc_html__( '22. Bubba', 'modula-pro' ),
				'dexter'   => esc_html__( '23. Dexter', 'modula-pro' ),
				'sarah'    => esc_html__( '24. Sarah', 'modula-pro' ),
				'chico'    => esc_html__( '25. Chico', 'modula-pro' ),
				'milo'     => esc_html__( '26. Milo', 'modula-pro' ),
				'julia'    => esc_html__( '27. Julia', 'modula-pro' ),
				'selena'   => esc_html__( '28. Selena', 'modula-pro' ),
				'phoebe'   => esc_html__( '29. Phoebe', 'modula-pro' ),
				'apollo'   => esc_html__( '30. Apollo', 'modula-pro' ),
				'steve'    => esc_html__( '31. Steve', 'modula-pro' ),
				'jazz'     => esc_html__( '32. Jazz', 'modula-pro' ),
				'ming'     => esc_html__( '33. Ming', 'modula-pro' ),
				'lexi'     => esc_html__( '34. Lexi', 'modula-pro' ),
				'duke'     => esc_html__( '35. Duke', 'modula-pro' ),
				'tilt_1'   => esc_html__( '36. Tilt Effect 1', 'modula-pro' ),
				'tilt_3'   => esc_html__( '37. Tilt Effect 2', 'modula-pro' ),
				'tilt_7'   => esc_html__( '38. Tilt Effect 3', 'modula-pro' ),
			)
		);
	}

	public static function get_hover_effects_keys() {
		$hover_effects = self::get_hover_effects();
		return array_keys( $hover_effects );
	}

	/**
	 * Whether each album hover effect prints the tile title and caption, as the
	 * album shortcode decides it (`modula_album_check_hover_effect`). The albums
	 * editor's canvas tiles follow it.
	 *
	 * @return array<string, array{title: bool, description: bool}> Keyed by effect slug; empty without Lite's helper.
	 */
	public static function get_caption_elements() {
		if ( ! class_exists( '\Modula_Helper' ) ) {
			return array();
		}

		$caption_elements = array();
		foreach ( self::get_hover_effects_keys() as $effect ) {
			$elements                    = \Modula_Helper::hover_effects_elements( $effect );
			$caption_elements[ $effect ] = array(
				'title'       => (bool) $elements['title'],
				'description' => (bool) $elements['description'],
			);
		}

		return $caption_elements;
	}
}
