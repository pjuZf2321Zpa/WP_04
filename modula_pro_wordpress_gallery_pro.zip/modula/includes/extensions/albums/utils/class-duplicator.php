<?php

namespace Modula_Pro\Extensions\Albums\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Duplicator {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'post_row_actions', array( $this, 'duplicate_album_link' ), 10, 2 );
	}

	/**
	 * Duplicate album link
	 *
	 * @param array $actions
	 * @param object $post
	 * @return array
	 */
	public function duplicate_album_link( $actions, $post ) {
		if ( 'modula-album' !== get_post_type( $post ) ) {
			return $actions;
		}

		$actions['duplicate_modula'] = '<a href="' . \modula_duplicate_gallery_get_clone_post_link( $post->ID, 'display', false ) . '" title="' . esc_attr__( 'Duplicate this album', 'modula-pro' ) . '">' . esc_html__( 'Duplicate album', 'modula-pro' ) . '</a>';

		return $actions;
	}
}
