<?php
namespace Modula_Pro\Extensions\Albums\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Fields_Helper {

	/**
	 * @return mixed|void
	 *
	 * Modula Albums CPT tabs
	 */
	public static function get_tabs() {
		return apply_filters(
			'modula_album_tabs',
			array(
				'general'      => array(
					'label'    => esc_html__( 'General', 'modula-pro' ),
					'title'    => esc_html__( 'General Settings', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-admin-generic',
					'docs_url' => 'https://wp-modula.com/kb/modula-albums-extension/#h-general-settings',
					'priority' => 10,
				),
				'lightbox'     => array(
					'label'    => esc_html__( 'Lightbox', 'modula-pro' ),
					'title'    => esc_html__( 'Lightbox Settings', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-filter',
					'docs_url' => 'https://wp-modula.com/kb/modula-albums-extension/#h-lightbox-settings',
					'priority' => 15,
				),
				'captions'     => array(
					'label'    => esc_html__( 'Captions', 'modula-pro' ),
					'title'    => esc_html__( 'Caption Settings', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-text',
					'docs_url' => 'https://wp-modula.com/kb/modula-albums-extension/#h-caption-settings',
					'priority' => 15,
				),
				'hover-effect' => array(
					'label'    => esc_html__( 'Hover effects', 'modula-pro' ),
					'title'    => esc_html__( 'Hover Effect Settings', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-layout',
					'docs_url' => 'https://wp-modula.com/kb/modula-albums-extension/#h-hover-effects',
					'priority' => 70,
				),
				'responsive'   => array(
					'label'    => esc_html__( 'Responsive', 'modula-pro' ),
					'title'    => esc_html__( 'Responsive Settings', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-smartphone',
					'docs_url' => 'https://wp-modula.com/kb/modula-albums-extension/#responsive',
					'priority' => 90,
				),
				'speedup'      => array(
					'label'    => esc_html__( 'Speed Up', 'modula-pro' ),
					'title'    => esc_html__( 'Optimize your album', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-dashboard',
					'docs_url' => 'https://wp-modula.com/kb/modula-speed-up/',
					'priority' => 80,
				),
				'misc'         => array(
					'label'    => esc_html__( 'Misc', 'modula-pro' ),
					'title'    => esc_html__( 'Miscellaneous', 'modula-pro' ),
					'icon'     => 'dashicons dashicons-dashboard',
					'docs_url' => 'https://wp-modula.com/kb/right-click-protection/',
					'priority' => 100,
				),
			)
		);
	}

	/**
	 * @param $tab
	 * @return array|mixed|void
	 *
	 * Modula Albums CTP fields
	 */
	public static function get_fields( $tab ) {
		$fields = apply_filters(
			'modula_album_fields',
			array(
				'general'      => array(
					'album_type'            => array(
						'name'      => esc_html__( 'Grid Type', 'modula-pro' ),
						'type'      => 'icon-radio',
						'default'   => 'grid',
						'values'    => array(
							'grid'        => esc_html__( 'Grid', 'modula-pro' ),
							'custom-grid' => esc_html__( 'Custom Grid', 'modula-pro' ),
						),
						'disabled'  => array(
							'title'  => esc_html__( 'Gallery types with PRO license', 'modula-pro' ),
							'values' => array(
								'slider' => esc_html__( 'Slider', 'modula-pro' ),
							),
						),
						'priority'  => 10,
						'data_type' => 'text',
					),
					'merge_items'           => array(
						'name'      => esc_html__( 'Merge galleries and albums', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 10,
						'data_type' => 'bool',
					),
					'albums_title_label'    => array(
						'name'      => esc_html__( 'Change "Albums" label.', 'modula-pro' ),
						'type'      => 'text',
						'default'   => esc_html__( 'Albums', 'modula-pro' ),
						'is_child'  => true,
						'priority'  => 11,
						'data_type' => 'text',
					),
					'galleries_title_label' => array(
						'name'      => esc_html__( 'Change "Galleries" label.', 'modula-pro' ),
						'type'      => 'text',
						'default'   => esc_html__( 'Galleries', 'modula-pro' ),
						'is_child'  => true,
						'priority'  => 12,
						'data_type' => 'text',
					),
					'max_galleries_count'   => array(
						'name'      => esc_html__( 'Galleries to show.', 'modula-pro' ),
						'type'      => 'number',
						'default'   => 0,
						'priority'  => 15,
						'min'       => 0,
						'step'      => 1,
						'data_type' => 'number',
					),
					'type'                  => array(
						'name'      => esc_html__( 'Number of Columns', 'modula-pro' ),
						'type'      => 'select',
						'default'   => '3',
						'values'    => array(
							'1'  => esc_html__( 'One Column(1)', 'modula-pro' ),
							'2'  => esc_html__( 'Two Columns(2)', 'modula-pro' ),
							'3'  => esc_html__( 'Three Columns(3)', 'modula-pro' ),
							'4'  => esc_html__( 'Four Columns(4)', 'modula-pro' ),
							'5'  => esc_html__( 'Five Columns(5)', 'modula-pro' ),
							'6'  => esc_html__( 'Six Columns(6)', 'modula-pro' ),
							'7'  => esc_html__( 'Seven Column(7)', 'modula-pro' ),
							'8'  => esc_html__( 'Eight Columns(8)', 'modula-pro' ),
							'9'  => esc_html__( 'Nine Columns(9)', 'modula-pro' ),
							'10' => esc_html__( 'Ten Columns(10)', 'modula-pro' ),
							'11' => esc_html__( 'Eleven Columns(11)', 'modula-pro' ),
							'12' => esc_html__( 'Twelve Columns(12)', 'modula-pro' ),
						),
						'priority'  => 20,
						'data_type' => 'text',
					),
					'gutter'                => array(
						'name'      => esc_html__( 'Space between album images', 'modula-pro' ),
						'type'      => 'gutterInput',
						'default'   => 10,
						'priority'  => 30,
						// Attribute specific for gutterInput type fields
						'media'     => 'desktop',
						'data_type' => 'number',
					),
					'tablet_gutter'         => array(
						'name'      => esc_html__( 'Gutter for tablet', 'modula-pro' ),
						'type'      => 'gutterInput',
						'default'   => 10,
						'priority'  => 35,
						// Attribute specific for gutterInput type fields
						'media'     => 'tablet',
						'data_type' => 'number',
					),
					'mobile_gutter'         => array(
						'name'      => esc_html__( 'Gutter for mobile', 'modula-pro' ),
						'type'      => 'gutterInput',
						'default'   => 10,
						'priority'  => 36,
						// Attribute specific for gutterInput type fields
						'media'     => 'mobile',
						'data_type' => 'number',
					),
					'album_width'           => array(
						'name'      => esc_html__( 'Album width', 'modula-pro' ),
						'type'      => 'select',
						'values'    => array(
							'auto'   => esc_html__( 'Auto', 'modula-pro' ),
							'full'   => esc_html__( 'Full', 'modula-pro' ),
							'custom' => esc_html__( 'Custom', 'modula-pro' ),
						),
						'default'   => 'auto',
						'priority'  => 37,
						'data_type' => 'text',
					),
					'width'                 => array(
						'name'      => esc_html__( 'Custom album width', 'modula-pro' ),
						'type'      => 'text',
						'default'   => '100%',
						'priority'  => 40,
						'data_type' => 'text',
						'is_child'  => true,
					),
					'image_size'            => array(
						'name'      => esc_html__( 'Gallery Image Size', 'modula-pro' ),
						'type'      => 'dimensions-select',
						'values'    => self::get_image_sizes(),
						'default'   => 'medium',
						'priority'  => 50,
						'data_type' => 'text',
					),
					'image_dimensions'      => array(
						'name'      => esc_html__( 'Width x Height', 'modula-pro' ),
						'type'      => 'image-size',
						'default'   => 0,
						'priority'  => 60,
						'is_child'  => true,
						'data_type' => 'number',
					),
					'crop_images'           => array(
						'name'      => esc_html__( 'Crop Images', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 70,
						'is_child'  => true,
						'data_type' => 'bool',
					),
					'shuffle_galleries'     => array(
						'name'      => esc_html__( 'Shuffle galleries & albums', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 75,
						'data_type' => 'bool',
					),
					'back_to_album_button'  => array(
						'name'      => esc_html__( 'Back to album button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 85,
						'data_type' => 'bool',
					),
					'albums_navigation'     => array(
						'name'      => esc_html__( 'Albums navigation position', 'modula-pro' ),
						'type'      => 'select',
						'values'    => array(
							'above'       => esc_html__( 'Above', 'modula-pro' ),
							'below'       => esc_html__( 'Below', 'modula-pro' ),
							'above_below' => esc_html__( 'Above & Below', 'modula-pro' ),
						),
						'default'   => 'below',
						'priority'  => 95,
						'data_type' => 'text',
					),
				),
				'lightbox'     => array(
					'enable_lightbox'           => array(
						'name'      => esc_html__( 'Enable Lightbox', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 10,
						'children'  => array( 'show_image_title', 'show_image_caption', 'enable_slideshow', 'enable_thumbs', 'enable_download', 'enable_share', 'enable_zoom', 'enable_play', 'enable_navigation', 'animation_effect', 'transition_effect', 'captionPosition', 'enable_navigation', 'enable_zoom', 'loop_lightbox', 'doubleClick', 'lightbox_background_color', 'lightbox_toolbar', 'lightbox_close', 'lightbox_infobar', 'autostart_thumbs', 'lightbox_thumbsPosition' ),

						'data_type' => 'bool',
					),
					'enable_navigation'         => array(
						'name'      => esc_html__( 'Show arrows navigation', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 30,
						'data_type' => 'bool',
					),
					'doubleClick'               => array(
						'name'      => esc_html__( 'Mobile requires double-tap', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 40,
						'data_type' => 'bool',
					),
					'loop_lightbox'             => array(
						'name'      => esc_html__( 'Loop navigation', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 50,
						'data_type' => 'bool',
					),
					'show_image_title'          => array(
						'name'      => esc_html__( 'Show Image Title', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 60,
						'data_type' => 'bool',
					),
					'show_image_caption'        => array(
						'name'      => esc_html__( 'Show Image Caption', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 70,
						'data_type' => 'bool',
					),
					'captionPosition'           => array(
						'name'      => esc_html__( 'Title and caption position', 'modula-pro' ),
						'type'      => 'select',
						'values'    => array(
							'left'   => esc_html__( 'Left', 'modula-pro' ),
							'right'  => esc_html__( 'Right', 'modula-pro' ),
							'center' => esc_html__( 'Center', 'modula-pro' ),
						),
						'default'   => 'left',
						'priority'  => 80,
						'data_type' => 'text',
					),
					'lightbox_toolbar'          => array(
						'name'      => esc_html__( 'Show toolbar', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 110,
						'children'  => array( 'lightbox_close', 'enable_thumbs', 'enable_download', 'enable_zoom', 'enable_share', 'enable_play' ),
						'data_type' => 'bool',
					),
					'lightbox_close'            => array(
						'name'      => esc_html__( 'Close button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'is_child'  => true,
						'priority'  => 112,
						'data_type' => 'bool',
					),
					'enable_thumbs'             => array(
						'name'      => esc_html__( 'Thumbnails button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 114,
						'data_type' => 'bool',
						'is_child'  => true,
					),
					'enable_download'           => array(
						'name'      => esc_html__( 'Download Button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 116,
						'data_type' => 'bool',
						'is_child'  => true,
					),
					'enable_zoom'               => array(
						'name'      => esc_html__( 'Zoom Button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 118,
						'data_type' => 'bool',
						'is_child'  => true,
					),
					'enable_share'              => array(
						'name'      => esc_html__( 'Share Button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 120,
						'children'  => array( 'lightbox_facebook', 'lightbox_twitter', 'lightbox_whatsapp', 'lightbox_linkedin', 'lightbox_pinterest', 'lightbox_email' ),
						'parent'    => 'enable_lightbox',
						'data_type' => 'bool',
						'is_child'  => true,
					),
					'lightbox_facebook'         => array(
						'name'      => esc_html__( 'Facebook', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'is_child'  => 'two',
						'priority'  => 122,
						'data_type' => 'bool',
					),
					'lightbox_twitter'          => array(
						'name'      => esc_html__( 'X', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'is_child'  => 'two',
						'priority'  => 124,
						'data_type' => 'bool',
					),
					'lightbox_whatsapp'         => array(
						'name'      => esc_html__( 'WhastApp', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'is_child'  => 'two',
						'priority'  => 126,
						'data_type' => 'bool',
					),
					'lightbox_linkedin'         => array(
						'name'      => esc_html__( 'LinkedIn', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'is_child'  => 'two',
						'priority'  => 128,
						'data_type' => 'bool',
					),
					'lightbox_pinterest'        => array(
						'name'      => esc_html__( 'Pinterest', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'is_child'  => 'two',
						'priority'  => 130,
						'data_type' => 'bool',
					),
					'lightbox_email'            => array(
						'name'      => esc_html__( 'Email', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'is_child'  => 'two',
						'priority'  => 132,
						'children'  => array( 'lightboxEmailSubject', 'lightboxEmailMessage' ),
						'parent'    => 'enable_share',
						'data_type' => 'bool',
					),
					'lightboxEmailSubject'      => array(
						'name'      => esc_html__( 'Email subject', 'modula-pro' ),
						'type'      => 'text',
						'default'   => esc_html__( 'Check out this awesome image !!', 'modula-pro' ),
						'is_child'  => 'three',
						'priority'  => 134,
						'data_type' => 'text',
					),
					'lightboxEmailMessage'      => array(
						'name'      => esc_html__( 'Email message', 'modula-pro' ),
						'type'      => 'textarea-placeholder',
						'values'    => array(
							'%%image_link%%'   => esc_html__( 'Image Link', 'modula-pro' ),
							'%%gallery_link%%' => esc_html__( 'Album Link', 'modula-pro' ),
						),
						'default'   => esc_html__( 'Here is the link to the image : %%image_link%% and this is the link to the gallery : %%gallery_link%% ', 'modula-pro' ),
						'is_child'  => 'three',
						'priority'  => 136,
						'data_type' => 'text',
					),
					'enable_play'               => array(
						'name'      => esc_html__( 'Play Button', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 140,
						'data_type' => 'bool',
						'is_child'  => true,
					),
					'lightbox_infobar'          => array(
						'name'      => esc_html__( 'Show image position in gallery', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 160,
						'data_type' => 'bool',
					),
					'animation_effect'          => array(
						'name'      => esc_html__( 'Select open/close animation', 'modula-pro' ),
						'type'      => 'select',
						'default'   => 'false',
						'values'    => array(
							'false'       => esc_html__( 'None', 'modula-pro' ),
							'fade'        => esc_html__( 'Fade', 'modula-pro' ),
							'zoom'        => esc_html__( 'Zoom', 'modula-pro' ),
							'zoom-in-out' => esc_html__( 'Zoom-in-out', 'modula-pro' ),
						),
						'priority'  => 170,
						'data_type' => 'text',
					),
					'transition_effect'         => array(
						'name'      => esc_html__( 'Transition effect', 'modula-pro' ),
						'type'      => 'select',
						'default'   => 'fade',
						'values'    => array(
							'fade'      => esc_html__( 'Fade', 'modula-pro' ),
							'crossfade' => esc_html__( 'Crossfade', 'modula-pro' ),
							'slide'     => esc_html__( 'Slide', 'modula-pro' ),
							'classic'   => esc_html__( 'Classic', 'modula-pro' ),
						),
						'priority'  => 180,
						'data_type' => 'text',
					),
					'enable_slideshow'          => array(
						'name'      => esc_html__( 'Enable autoplay', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 190,
						'children'  => array( 'slideshow_duration' ),
						'data_type' => 'bool',
					),
					'slideshow_duration'        => array(
						'name'      => esc_html__( 'Time between slides', 'modula-pro' ),
						'type'      => 'text',
						'default'   => 3000,
						'is_child'  => true,
						'priority'  => 200,
						'data_type' => 'number',
					),
					'autostart_thumbs'          => array(
						'name'      => esc_html__( 'Show thumbnails', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 220,
						'data_type' => 'bool',
					),
					'lightbox_background_color' => array(
						'name'      => esc_html__( 'Lightbox background color', 'modula-pro' ),
						'type'      => 'color',
						'alpha'     => true,
						'default'   => 'rgba(30,30,30,.9)',
						'priority'  => 240,
						'data_type' => 'text',
					),
					'lightbox_thumbsPosition'   => array(
						'name'      => esc_html__( 'Thumbnails position', 'modula-pro' ),
						'type'      => 'select',
						'values'    => array(
							'left'   => esc_html__( 'Left', 'modula-pro' ),
							'bottom' => esc_html__( 'Bottom', 'modula-pro' ),
							'right'  => esc_html__( 'Right', 'modula-pro' ),
						),
						'default'   => 'bottom',
						'priority'  => 250,
						'data_type' => 'text',
					),
					'lightbox_info'             => array(
						'name' => esc_html__( 'Each gallery from an album will open a URL, and there are 2 options for that:', 'modula-pro' ),
						'type' => 'album-lightbox-info',
					),
				),
				'captions'     => array(
					'hide_title'            => array(
						'name'      => esc_html__( 'Hide image title', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 20,
						'children'  => array( 'titleColor', 'titleFontSize', 'mobileTitleFontSize' ),
						'data_type' => 'bool',
					),
					'titleColor'            => array(
						'name'      => esc_html__( 'Title Color', 'modula-pro' ),
						'type'      => 'color',
						'default'   => '#000000',
						'is_child'  => true,
						'priority'  => 20,
						'data_type' => 'text',
					),
					'titleFontSize'         => array(
						'name'      => esc_html__( 'Title Font Size', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 12,
						'is_child'  => true,
						'priority'  => 20,
						'data_type' => 'number',
					),
					'mobileTitleFontSize'   => array(
						'name'      => esc_html__( 'Mobile Title Font Size', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 10,
						'is_child'  => true,
						'priority'  => 20,
						'data_type' => 'number',
					),
					'hide_description'      => array(
						'name'      => esc_html__( 'Hide image caption', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 30,
						'children'  => array( 'captionColor', 'captionFontSize', 'mobileCaptionFontSize' ),
						'data_type' => 'bool',
					),
					'captionColor'          => array(
						'name'      => esc_html__( 'Caption Color', 'modula-pro' ),
						'type'      => 'color',
						'default'   => '#000000',
						'is_child'  => true,
						'priority'  => 30,
						'data_type' => 'text',
					),
					'captionFontSize'       => array(
						'name'      => esc_html__( 'Caption Font Size', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 14,
						'is_child'  => true,
						'priority'  => 30,
						'data_type' => 'number',
					),
					'mobileCaptionFontSize' => array(
						'name'      => esc_html__( 'Caption font size on mobile', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 12,
						'is_child'  => true,
						'priority'  => 30,
						'data_type' => 'number',
					),
				),
				'hover-effect' => array(
					'cursor'              => array(
						'name'      => esc_html__( 'Cursor Icon', 'modula-pro' ),
						'type'      => 'select',
						'default'   => 'zoom-in',
						'priority'  => 8,
						'values'    => array(
							'pointer'     => esc_html__( 'Pointer', 'modula-pro' ),
							'zoom-in'     => esc_html__( 'Magnifying Glass', 'modula-pro' ),
							'wait'        => esc_html__( 'Loading', 'modula-pro' ),
							'cell'        => esc_html__( 'Cell', 'modula-pro' ),
							'crosshair'   => esc_html__( 'Crosshair', 'modula-pro' ),
							'nesw-resize' => esc_html__( 'Resize 1', 'modula-pro' ),
							'nwse-resize' => esc_html__( 'Resize 2', 'modula-pro' ),
							'custom'      => esc_html__( 'Custom', 'modula-pro' ),
						),
						'data_type' => 'text',
					),
					'uploadCursor'        => array(
						'name'        => esc_html__( 'Upload your cursor', 'modula-pro' ),
						'type'        => 'cursor_upload',
						'default'     => 0,
						'class'       => 'button insert-media-url',
						'button_text' => esc_html__( 'Upload Cursor', 'modula-pro' ),
						'is_child'    => true,
						'priority'    => 9,
						'data_type'   => 'text',
					),
					'display_image_count' => array(
						'name'      => esc_html__( 'Display Image Count', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 40,
						'data_type' => 'bool',
					),
					'imageCountColor'     => array(
						'name'      => esc_html__( 'Image Count Color', 'modula-pro' ),
						'type'      => 'color',
						'default'   => '#ffffff',
						'is_child'  => true,
						'priority'  => 50,
						'data_type' => 'text',
					),
					'imageCountFontSize'  => array(
						'name'      => esc_html__( 'Image Count Font Size', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 14,
						'is_child'  => true,
						'priority'  => 70,
						'data_type' => 'number',
					),
					'hoverColor'          => array(
						'name'      => esc_html__( 'Hover Color', 'modula-pro' ),
						'type'      => 'color',
						'default'   => '#ffffff',
						'priority'  => 80,
						'data_type' => 'text',
					),
					'backgroundColor'     => array(
						'name'      => esc_html__( 'Background Color', 'modula-pro' ),
						'type'      => 'color',
						'default'   => '#ffffff',
						'priority'  => 90,
						'data_type' => 'text',
					),
					'hoverOpacity'        => array(
						'name'      => esc_html__( 'Hover Opacity', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 50,
						'priority'  => 100,
						'data_type' => 'number',
					),
					'hoverPadding'        => array(
						'name'      => esc_html__( 'Hover Padding', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 0,
						'max'       => 100,
						'default'   => 32,
						'priority'  => 100,
						'data_type' => 'number',
					),
					'effect'              => array(
						'name'      => esc_html__( 'Hover effect', 'modula-pro' ),
						'type'      => 'hover-effect',
						'default'   => 'under',
						'priority'  => 110,
						'data_type' => 'text',
					),
				),
				'speedup'      => array(
					'lazy_load' => array(
						'name'      => esc_html__( 'Lazy Load', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 0,
						'priority'  => 1,
						'data_type' => 'bool',
					),
				),
				'responsive'   => array(
					'enable_responsive' => array(
						'name'      => esc_html__( 'Custom responsiveness', 'modula-pro' ),
						'type'      => 'toggle',
						'default'   => 1,
						'priority'  => 10,
						'children'  => array( 'tablet_columns', 'mobile_columns' ),
						'data_type' => 'bool',
					),
					'tablet_columns'    => array(
						'name'      => esc_html__( 'Tablet Columns', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 1,
						'max'       => 6,
						'step'      => 1,
						'default'   => 2,
						'is_child'  => true,
						'priority'  => 20,
						'data_type' => 'number',
					),
					'mobile_columns'    => array(
						'name'      => esc_html__( 'Mobile Columns', 'modula-pro' ),
						'type'      => 'ui-slider',
						'min'       => 1,
						'max'       => 6,
						'step'      => 1,
						'default'   => 1,
						'is_child'  => true,
						'priority'  => 30,
						'data_type' => 'number',
					),
				),
			)
		);

		if ( 'all' == $tab ) {
			return $fields;
		}

		if ( isset( $fields[ $tab ] ) ) {
			return $fields[ $tab ];
		} else {
			return array();
		}
	}

	/**
	 * @return mixed|void
	 *
	 * Get the defaults of the Albums
	 */
	public static function get_defaults() {

		return apply_filters(
			'modula_album_default_settings',
			array(

				// General
				'album_type'                => 'grid',
				'upload_position'           => 'end',
				'merge_items'               => 0,
				'inherit_from_parent'       => 0,
				'albums_title_label'        => esc_html__( 'Albums', 'modula-pro' ),
				'galleries_title_label'     => esc_html__( 'Galleries', 'modula-pro' ),
				'max_galleries_count'        => 0,
				'type'                      => '3',
				'gutter'                    => 10,
				'tablet_gutter'             => 10,
				'mobile_gutter'             => 10,
				'width'                     => '100%',
				'display_image_count'       => 0,
				'image_dimensions'          => array(
					'width'  => '',
					'height' => '',
				),
				'crop_images'               => 0,
				'shuffle_galleries'         => 0,
				'image_size'                => 'medium',
				'album_width'               => 'auto',

				// Lightbox
				'enable_lightbox'           => 1,
				'back_to_album_button'      => 0,
				'albums_navigation'         => 'below',
				'show_image_title'          => 0,
				'show_image_caption'        => 1,
				'enable_slideshow'          => 0,
				'slideshow_duration'        => '3000',
				'enable_thumbs'             => 0,
				'autostart_thumbs'          => 1,
				'enable_download'           => 0,
				'enable_share'              => 0,
				'lightbox_facebook'         => 0,
				'lightbox_twitter'          => 0,
				'lightbox_whatsapp'         => 0,
				'lightbox_linkedin'         => 0,
				'lightbox_pinterest'        => 0,
				'lightbox_email'            => 0,
				'lightboxEmailSubject'      => esc_html__( 'Check out this awesome album !!', 'modula-pro' ),
				'lightboxEmailMessage'      => esc_html__( 'Here is the link to the image : %%image_link%% and this is the link to the gallery : %%gallery_link%%', 'modula-pro' ),
				'enable_navigation'         => 1,
				'lightbox_thumbsPosition'   => 'bottom',
				'animation_effect'          => false,
				'transition_effect'         => 'fade',
				'captionPosition'           => 'left',
				'open_Lightbox_on'          => 'both',
				'enable_zoom'               => 0,
				'loop_lightbox'             => 0,
				'doubleClick'               => 0,
				'lightbox_background_color' => 'rgba(30,30,30,.9)',
				
				
				'lightbox_toolbar'          => 1,
				'lightbox_close'            => 1,
				'lightbox_infobar'          => 1,
				

				// Style
				'cursor'                    => 'pointer',
				'uploadCursor'              => 0,
				'effect'                    => 'under',
				'titleColor'                => '#000000',
				'captionColor'              => '#000000',
				'hoverColor'                => '#000000',
				'backgroundColor'           => '#000000',
				'imageCountColor'           => '#ffffff',
				'imageCountFontSize'        => 14,
				'hide_title'                => 0,
				'hide_description'          => 0,
				'titleFontSize'             => 0,
				'captionFontSize'           => 14,
				'hoverOpacity'              => 50,
				'hoverPadding'              => 0,

				// Speed Up
				'lazy_load'                 => 0,

				// Responsive
				'enable_responsive'         => 1,
				'tablet_columns'            => 2,
				'mobile_columns'            => 1,
				// Classic album breakpoints (Responsive_Breakpoints::DEFAULT_*).
				'treat_as_tablet_under'     => 992,
				'treat_as_phone_under'      => 768,
				'mobileTitleFontSize'       => 10,
				'mobileCaptionFontSize'     => 12,
			)
		);
	}

	public static function get_image_sizes() {

		global $_wp_additional_image_sizes;

		$sizes                        = array();
		$get_intermediate_image_sizes = self::get_image_sizes_arr();

		// Create the full array with sizes
		// print_r( $get_intermediate_image_sizes );
		foreach ( $get_intermediate_image_sizes as $_size => $args ) {
			$image_size_txt = ucfirst( strtolower( str_replace( '_', ' ', $_size ) ) );
			$image_size_txt = str_replace( '-', ' ', $image_size_txt );
			if ( ! in_array( $_size, $sizes, true ) ) {
				$sizes[ $_size ] = array(
					'dimensions' => array(
						'width'  => $args['width'],
						'height' => $args['height'],
					),
					'label'      => $image_size_txt,
					'crop'       => $args['crop'],
				);
			}
		}

		foreach ( $_wp_additional_image_sizes as $_size => $args ) {
			$image_size_txt = ucfirst( strtolower( str_replace( '_', ' ', $_size ) ) );
			$image_size_txt = str_replace( '-', ' ', $image_size_txt );
			if ( ! in_array( $_size, $sizes, true ) ) {
				$sizes[ $_size ] = array(
					'dimensions' => array(
						'width'  => $args['width'],
						'height' => $args['height'],
					),
					'label'      => $image_size_txt,
					'crop'       => $args['crop'],
				);
			}
		}

		return $sizes;
	}

	/**
	 * Get information about available image sizes
	 */
	public static function get_image_sizes_arr( $size = '' ) {

		global $_wp_additional_image_sizes;

		$sizes                        = array();
		$get_intermediate_image_sizes = get_intermediate_image_sizes();

		// Create the full array with sizes and crop info
		foreach ( $get_intermediate_image_sizes as $_size ) {
			if ( in_array( $_size, array( 'thumbnail', 'medium', 'large' ), true ) ) {
				$sizes[ $_size ]['width']  = get_option( $_size . '_size_w' );
				$sizes[ $_size ]['height'] = get_option( $_size . '_size_h' );
				$sizes[ $_size ]['crop']   = (bool) get_option( $_size . '_crop' );
			} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
				$sizes[ $_size ] = array(
					'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
					'height' => $_wp_additional_image_sizes[ $_size ]['height'],
					'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
				);
			}
		}

		// Get only 1 size if found
		if ( $size ) {
			if ( isset( $sizes[ $size ] ) ) {
				return $sizes[ $size ];
			} else {
				return false;
			}
		}
		return $sizes;
	}
}
