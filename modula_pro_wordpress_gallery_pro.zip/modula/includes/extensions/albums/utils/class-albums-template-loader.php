<?php

namespace Modula_Pro\Extensions\Albums\Utils;

use Modula_Pro\Extensions\Utils\Gamajo_Template_Loader;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *
 * Template loader for Modula Albums.
 *
 * Only need to specify class properties here.
 *
 */
class Albums_Template_Loader extends Gamajo_Template_Loader {
	/**
	 * Prefix for filter names.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $filter_prefix = 'modula-albums';

	/**
	 * Directory name where custom templates for this plugin should be found in the theme.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $theme_template_directory = 'modula/albums';

	/**
	 * Reference to the root directory path of this plugin.
	 *
	 * Can either be a defined constant, or a relative reference from where the subclass lives.
	 *
	 * In this case, `MODULA_ALBUMS_PATH` would be defined in the root plugin file as:
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $plugin_directory = MODULA_PRO_PATH . 'includes/extensions/albums';

	/**
	 * Directory name where templates are found in this plugin.
	 *
	 * Can either be a defined constant, or a relative reference from where the subclass lives.
	 *
	 * @since 1.1.0
	 *
	 * @var string
	 */
	protected $plugin_template_directory = 'templates';
}
