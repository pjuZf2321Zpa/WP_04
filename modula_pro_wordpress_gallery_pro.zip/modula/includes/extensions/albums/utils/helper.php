<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @param $item_data
 * @param $item
 * @param $settings
 * @param $album_settings
 * @return mixed
 *
 * Generate image
 */
function modula_album_generate_image_links( $item_data, $item, $settings, $album_settings ) {

	// If the image is not resized we will try to resize it now
	// This is safe to call every time, as resize_image() will check if the image already exists, preventing thumbnails from being generated every single time.
	$resizer = new \Modula_Image();

	$gallery_type = ( isset( $album_settings['album_type'] ) && 'custom-grid' === $album_settings['album_type'] ) ? 'custom-grid' : 'grid';

	if ( 'custom' === $album_settings['image_size'] ) {
		$grid_sizes = array(
			'width'  => $album_settings['image_dimensions']['width'],
			'height' => $album_settings['image_dimensions']['height'],
		);
	} else {
		$grid_sizes = $album_settings['image_size'];
	}

	$crop = false;

	if ( 'custom' === $album_settings['image_size'] ) {
		$crop = boolval( $album_settings['crop_images'] );
	}

	$sizes   = $resizer->get_image_size( $item['id'], $gallery_type, $grid_sizes, $crop );
	$resized = $resizer->resize_image( $sizes['url'], $sizes['width'], $sizes['height'], $crop );

	$image_info = false;
	// If we couldn't resize the image we will return the full image.
	if ( is_wp_error( $resized ) ) {
		$resized = $sizes['url'];
	}
	// Let's check if resize gives us both URL and image info
	// Also, if resized_url is available, image_info should be available
	if ( isset( $resized['resized_url'] ) ) {
		$image_url  = $resized['resized_url'];
		$image_info = $resized['image_info'];
	} else {
		$image_url = $resized;
	}

	$item_data['img_attributes']['width']  = $sizes['width'];
	$item_data['img_attributes']['height'] = $sizes['height'];
	$item_data['image_full']               = $sizes['url'];
	$item_data['image_url']                = ( isset( $sizes['thumb_url'] ) ) ? $sizes['thumb_url'] : $image_url;
	// If thumb_url exists it means we are in predefined sizes
	$item_data['img_attributes']['src']           = ( isset( $sizes['thumb_url'] ) ) ? $sizes['thumb_url'] : $image_url;
	$item_data['img_attributes']['data-src']      = ( isset( $sizes['thumb_url'] ) ) ? $sizes['thumb_url'] : $image_url;
	$item_data['img_attributes']['data-image-id'] = $item['id'];
	$item_data['image_info']                      = $image_info;

	return $item_data;
}


function modula_album_check_lightboxes_and_links( $item_data, $item, $gallery_settings, $settings ) {
	// Create link attributes like : title/rel
	$caption = isset( $item['description'] ) ? $item['description'] : '';

	$item_data['link_attributes']['title']      = wp_strip_all_tags( $caption );
	$item_data['link_attributes']['data-title'] = $caption;

	$item_data['link_attributes']['rel'] = $gallery_settings['gallery_id'];

	if ( ! isset( $settings['enable_lightbox'] ) || 1 !== (int) $settings['enable_lightbox'] ) {
		$item_data['link_attributes']['class'][] = 'simple-link';
	}

	return $item_data;
}

function modula_album_check_hover_effect( $item_data, $item, $gallery_settings, $settings ) {

	// Album tiles use the album's classic effect settings. A member gallery's
	// hover_builder (Beta gallery v2) must not suppress the album effect class.

	$effect = isset( $settings['effect'] ) ? $settings['effect'] : 'under';

	$hover_effect_elements = \Modula_Helper::hover_effects_elements( $effect );

	if ( ! $hover_effect_elements['title'] ) {
		$item_data['hide_title'] = true;
	}

	if ( ! $hover_effect_elements['description'] ) {
		$item_data['hide_description'] = true;
	}

	if ( ! $hover_effect_elements['social'] ) {
		$item_data['hide_socials'] = true;
	}

	if ( 'none' !== $effect ) {
		$item_data['item_attributes']['class'][] = 'effect-' . $effect;
	}

	if ( 'under' === $effect ) {
		$item_data['item_attributes']['class'][] = 'modula-caption-effect-item';
	}

	return $item_data;
}

function modula_album_check_custom_grid( $item_data ) {

	if ( isset( $item_data['album_type'] ) && 'custom-grid' === $item_data['album_type'] ) {
		return $item_data;
	}

	$item_data['item_attributes']['data-width']  = 2;
	$item_data['item_attributes']['data-height'] = 2;

	return $item_data;
}

function modula_album_enable_lazy_load( $item_data, $item, $gallery_settings, $settings ) {
	if ( '1' !== $settings['lazy_load'] ) {
		return $item_data;
	}

	if ( isset( $item_data['img_attributes']['class'] ) && is_array( $item_data['img_attributes']['class'] ) ) {
		$item_data['img_attributes']['class'][] = 'lazyload';
	}

	if ( isset( $item_data['img_attributes']['src'] ) ) {
		unset( $item_data['img_attributes']['src'] );
	}

	$item_data['img_attributes']['data-source'] = 'modula-album';

	return $item_data;
}

function modula_get_albums() {

	$albums      = get_posts(
		array(
			'post_type'      => 'modula-album',
			'posts_per_page' => -1,
		)
	);
	$album_array = array( 'none' => esc_html__( 'None', 'modula-pro' ) );
	foreach ( $albums as $album ) {
		$album_array[ $album->ID ] = esc_html( $album->post_title );
	}

	return $album_array;
}

/**
 * Recursively searches through Modula albums until it finds a gallery
 * and returns the images of that gallery.
 *
 * This function looks for the first gallery within an album hierarchy.
 * If the current album contains sub-albums, it continues searching recursively
 * until a gallery is found, then returns its images.
 *
 * @since 1.3.0
 *
 * @param int           $id        Album ID.
 * @param callable|null $is_shown  Member predicate, `( array $member ): bool`, applied at every
 *                                 level. Defaults to the current visitor's read access.
 *
 * @return array
 */
function modula_get_ablum_images_recursive( $id, $is_shown = null ) {
	if ( null === $is_shown ) {
		$is_shown = array( \Modula_Pro\Extensions\Albums\V2\Members_Document::class, 'is_visitor_readable_member' );
	}
	$galleries = get_post_meta( $id, 'modula-album-galleries', true );
	if ( empty( $galleries ) || ! is_array( $galleries ) ) {
		return array();
	}

	foreach ( $galleries as $gallery ) {
		// These images reach the visitor: skip members they mustn't see.
		if ( ! is_array( $gallery ) || ! $is_shown( $gallery ) ) {
			continue;
		}
		if ( ! isset( $gallery['itemType'] ) || 'modula-gallery' === $gallery['itemType'] ) {
			return get_post_meta( $gallery['id'], 'modula-images', true ); // return first found gallery images
		}
		if ( 'modula-album' !== $gallery['itemType'] ) {
			continue;
		}
		$images = modula_get_ablum_images_recursive( $gallery['id'], $is_shown ); // try to find the next gallery in album
		// A nested album whose members are all hidden yields nothing: keep looking.
		if ( ! empty( $images ) ) {
			return $images;
		}
	}
	return array();
}

/**
 * Members of an album the current visitor can read, for its "N Items" count.
 *
 * @param int $id Album ID.
 *
 * @return int
 */
function modula_get_album_visitor_member_count( $id ) {
	$items = get_post_meta( $id, 'modula-album-galleries', true );
	return count( \Modula_Pro\Extensions\Albums\V2\Members_Document::visitor_readable_members( $items ) );
}

/**
 * Cover for a nested album: featured image, else the first visitor-readable member's cover, else its first image.
 *
 * @param int   $id      Album ID.
 * @param array $visited Loop guard.
 *
 * @return int Attachment ID or 0.
 */
function modula_get_album_cover_id( $id, $visited = array() ) {
	$id = absint( $id );
	if ( ! $id || in_array( $id, $visited, true ) ) {
		return 0;
	}
	$visited[] = $id;

	$featured_id = (int) get_post_thumbnail_id( $id );
	if ( $featured_id ) {
		return $featured_id;
	}

	// The cover shows on the visitor's album tile: take it from the first member they can read.
	$items = \Modula_Pro\Extensions\Albums\V2\Members_Document::visitor_readable_members( get_post_meta( $id, 'modula-album-galleries', true ) );
	if ( empty( $items ) ) {
		return 0;
	}

	return modula_get_album_member_cover_id( $items[0], $visited );
}

/**
 * Cover of one album member: a nested album's (`modula_get_album_cover_id()`),
 * else the gallery's chosen cover, else its first image. The nested album's
 * cover and its card's thumbnail strip (album-member-card ticket 03) read it.
 *
 * @param array $item    Stored member.
 * @param array $visited Albums already walked (loop guard).
 *
 * @return int Attachment ID or 0.
 */
function modula_get_album_member_cover_id( $item, $visited = array() ) {
	if ( isset( $item['itemType'] ) && 'modula-album' === $item['itemType'] ) {
		return modula_get_album_cover_id( $item['id'], $visited );
	}

	$images = get_post_meta( $item['id'], 'modula-images', true );
	if ( empty( $images ) || ! is_array( $images ) ) {
		return 0;
	}

	$cover_id = isset( $item['cover'] ) ? absint( $item['cover'] ) : 0;
	if ( $cover_id && 'attachment' === get_post_type( $cover_id ) ) {
		return $cover_id;
	}

	foreach ( $images as $image ) {
		if ( ! empty( $image['id'] ) && 'attachment' === get_post_type( absint( $image['id'] ) ) ) {
			return absint( $image['id'] );
		}
	}

	return 0;
}

/**
 * Where a nested album shows its sibling albums: its parent's "Albums
 * navigation position" (`above`, `below` or `above_below`; classic default
 * `below`), as the classic album reads it.
 *
 * @param int $album_id Album post ID.
 * @return array{above: bool, below: bool} Both false for an album with no parent, or an unknown position.
 */
function modula_album_navigation_places( $album_id ) {
	$places = array(
		'above' => false,
		'below' => false,
	);

	$parent_album_id = wp_get_post_parent_id( $album_id );
	if ( ! $parent_album_id ) {
		return $places;
	}

	$parent_settings = modula_albums_get_album_settings( $parent_album_id );
	$position        = isset( $parent_settings['albums_navigation'] ) ? (string) $parent_settings['albums_navigation'] : '';

	$places['above'] = 'above' === $position || 'above_below' === $position;
	$places['below'] = 'below' === $position || 'above_below' === $position;
	return $places;
}

/**
 * The sibling albums a nested album's navigation links: the nested albums
 * just before and after it in its parent's members, among those a visitor
 * can read. Each link keeps the page's `back_to_album`.
 *
 * @param int $album_id Album post ID.
 * @return array{previous: array{url: string, title: string}|null, next: array{url: string, title: string}|null}
 *         `title` as `get_the_title()` returns it; both null for an album with no parent,
 *         or one its parent does not list.
 */
function modula_album_navigation_siblings( $album_id ) {
	$siblings = array(
		'previous' => null,
		'next'     => null,
	);

	$parent_album_id = wp_get_post_parent_id( $album_id );
	if ( ! $parent_album_id ) {
		return $siblings;
	}

	// Prev/next show the sibling's title and link: only albums the visitor can read.
	$items     = \Modula_Pro\Extensions\Albums\V2\Members_Document::visitor_readable_members( get_post_meta( $parent_album_id, 'modula-album-galleries', true ) );
	$album_ids = array();
	foreach ( $items as $item ) {
		if ( isset( $item['itemType'] ) && 'modula-album' === $item['itemType'] && ! empty( $item['id'] ) ) {
			$album_ids[] = (int) $item['id'];
		}
	}

	$position = array_search( (int) $album_id, $album_ids, true );
	if ( false === $position ) {
		return $siblings;
	}
	if ( $position > 0 ) {
		$siblings['previous'] = modula_album_navigation_link( $album_ids[ $position - 1 ] );
	}
	if ( isset( $album_ids[ $position + 1 ] ) ) {
		$siblings['next'] = modula_album_navigation_link( $album_ids[ $position + 1 ] );
	}

	return $siblings;
}

/**
 * A sibling album's link in the navigation, as the classic album builds it.
 *
 * @param int $album_id Sibling album post ID.
 * @return array{url: string, title: string} Its permalink, with the page's `back_to_album` as an integer, and its title.
 */
function modula_album_navigation_link( $album_id ) {
	$url = get_permalink( $album_id );
	// A read-only navigation flag in the URL; no state changes.
	if ( isset( $_GET['back_to_album'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$url = add_query_arg( 'back_to_album', absint( $_GET['back_to_album'] ), $url ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	return array(
		'url'   => (string) $url,
		'title' => (string) get_the_title( $album_id ),
	);
}

function modula_add_album_navigation_button( $album_id ) {
	$siblings = modula_album_navigation_siblings( $album_id );
	$buttons  = '';

	if ( null !== $siblings['previous'] ) {
		$buttons .= sprintf(
			'<a href="%s" class="modula-album-button modula-prev-album-button"><span class="dashicons dashicons-arrow-left-alt2"></span> %s</a>',
			esc_url( $siblings['previous']['url'] ),
			esc_html( $siblings['previous']['title'] )
		);
	}
	if ( null !== $siblings['next'] ) {
		$buttons .= sprintf(
			'<a href="%s" class="modula-album-button modula-next-album-button">%s <span class="dashicons dashicons-arrow-right-alt2"></span></a>',
			esc_url( $siblings['next']['url'] ),
			esc_html( $siblings['next']['title'] )
		);
	}

	if ( '' !== $buttons ) {
		printf( '<div class="modula-albums-navigation-buttons">%s</div>', $buttons ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Each link is escaped above.
	}
	return false;
}

/**
 * Public URL for an album member (gallery or nested album) when Standalone is enabled.
 *
 * Falls back to get_permalink when Standalone is unavailable or disabled for that CPT.
 *
 * @param int $post_id Member post ID.
 * @return string
 */
function modula_album_member_public_url( $post_id ) {
	$post_id = absint( $post_id );
	if ( $post_id < 1 ) {
		return '';
	}

	if ( class_exists( '\Modula_Pro\Extensions\Standalone\Standalone' ) ) {
		$url = \Modula_Pro\Extensions\Standalone\Standalone::get_instance()->get_member_standalone_url( $post_id );
		if ( is_string( $url ) && '' !== $url ) {
			return $url;
		}
	}

	$permalink = get_permalink( $post_id );
	return is_string( $permalink ) ? $permalink : '';
}

function modula_albums_get_album_settings( $album_id ) {
	$settings = get_post_meta( $album_id, 'modula-album-settings', true );
	$defaults = \Modula_Pro\Extensions\Albums\Utils\Fields_Helper::get_defaults();
	return wp_parse_args( $settings, $defaults );
}
