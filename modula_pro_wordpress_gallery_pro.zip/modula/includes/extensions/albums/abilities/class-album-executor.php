<?php
/** Album list, read, create and update. Lite keeps the descriptor and explanation. */
namespace Modula_Pro\Extensions\Albums\Abilities;

use Modula\V2\Abilities\Albums;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Settings_Contract;
use Modula\V2\Beta_Settings;
use Modula_Pro\Extensions\Albums\V2\Meta_Sync;
use Modula_Pro\Extensions\Albums\V2\Registry;
use Modula_Pro\Extensions\Albums\V2\Sanitizer;
use Modula_Pro\Extensions\Albums\V2\Settings_Writer;

defined( 'ABSPATH' ) || exit;

final class Album_Executor {
	/** @return array<string,callable> */
	public static function callbacks(): array {
		return array(
			'modula/list-albums'  => array( self::class, 'listing' ),
			'modula/read-album'   => array( self::class, 'read' ),
			'modula/create-album' => array( self::class, 'create' ),
			'modula/update-album' => array( self::class, 'update' ),
		);
	}

	/** Current Albums entitlement plus the actor's right on this album, checked before every executor effect. */
	public static function can_access( int $id = 0, string $status = '', bool $create = false ): bool {
		return Albums::available() && Albums::object_access( $id, $status, $create );
	}

	/**
	 * Active stored values that are not dormant defaults.
	 *
	 * @param array<string,mixed> $settings
	 * @return true|\WP_Error
	 */
	public static function validate_configuration( array $settings ) {
		$defaults            = Sanitizer::sanitize_grouped( array() );
		$normalized_defaults = Sanitizer::sanitize_grouped( $defaults );
		$active              = array();
		$readable            = Contract::settings_schema( Registry::get_schema() );
		foreach ( $settings as $group => $fields ) {
			if ( ! is_array( $fields ) ) {
				return new \WP_Error( 'invalid_album_settings', 'Invalid stored album settings.' );
			}
			foreach ( $fields as $key => $value ) {
				if ( ! isset( $readable['properties'][ $group ]['properties'][ $key ] ) || ! array_key_exists( $key, $defaults[ $group ] ?? array() ) ) {
					continue;
				}
				if ( $value === $defaults[ $group ][ $key ] || $value === $normalized_defaults[ $group ][ $key ] ) {
					continue;
				}
				$active[ $group ][ $key ] = $value;
			}
		}
		if ( ! $active ) {
			return true;
		}
		$blockers = Settings_Contract::blockers( $active, true );
		if ( $blockers ) {
			return new \WP_Error( 'feature_unavailable', 'The album uses a feature that is not currently enabled.', array( 'blockers' => $blockers ) );
		}
		return Settings_Writer::validate_patch( 0, $active );
	}

	public static function listing( array $input ) {
		$gated = Provider::gate( 'modula/list-albums', $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( ! self::can_access() ) {
			return new \WP_Error( 'modula_forbidden', 'Current album permissions and entitlement are required.' );
		}
		$ids  = array();
		$scan = 1;
		do {
			$query = new \WP_Query(
				array(
					'post_type'      => 'modula-album',
					'post_status'    => empty( $input['status'] ) || 'any' === $input['status'] ? array( 'draft', 'publish', 'private', 'pending', 'trash' ) : $input['status'],
					'meta_key'       => Beta_Settings::META_KEY,
					'meta_value'     => '1',
					's'              => $input['search'] ?? '',
					'fields'         => 'ids',
					'posts_per_page' => 200,
					'paged'          => $scan++,
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				)
			);
			foreach ( $query->posts as $id ) {
				if ( self::can_access( (int) $id ) && Beta_Settings::is_beta_album( $id ) ) {
					$ids[] = (int) $id;
				}
			}
		} while ( 200 === count( $query->posts ) );
		$page = $input['page'] ?? 1;
		$size = $input['per_page'] ?? 20;
		return array(
			'schema_version' => Contract::VERSION,
			'page'           => $page,
			'per_page'       => $size,
			'total'          => count( $ids ),
			'total_pages'    => (int) ceil( count( $ids ) / $size ),
			'albums'         => array_map( array( Albums::class, 'summary' ), array_slice( $ids, ( $page - 1 ) * $size, $size ) ),
		);
	}

	public static function read( array $input ) {
		$gated = Provider::gate( 'modula/read-album', $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$id = (int) $input['id'];
		if ( ! self::can_access( $id ) ) {
			return new \WP_Error( 'modula_forbidden', 'Current album permissions and entitlement are required.' );
		}
		if ( ! Beta_Settings::is_beta_album( $id ) ) {
			return new \WP_Error( 'modula_classic_unsupported', 'Only Beta albums are supported.' );
		}
		$revision          = Revision::document( $id );
		$album             = Albums::summary( $id );
		$album['settings'] = Contract::project( Meta_Sync::get_settings_v2( $id ), Contract::settings_schema( Registry::get_schema() ) );
		if ( ! hash_equals( $revision, Revision::document( $id ) ) ) {
			return new \WP_Error( 'modula_read_conflict', 'Album changed while reading. Read again.' );
		}
		return array(
			'schema_version' => Contract::VERSION,
			'album'          => $album,
		);
	}

	public static function create( array $input ): array {
		return self::write( $input, true );
	}

	public static function update( array $input ): array {
		return self::write( $input, false );
	}

	private static function write( array $input, bool $create ): array {
		$operation = $create ? 'modula/create-album' : 'modula/update-album';
		$request   = $input['request_id'];
		$existing  = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$gated = Provider::gate( $operation, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$id       = $create ? 0 : $input['id'];
		$metadata = $create ? array(
			'title'  => $input['title'],
			'status' => $input['status'],
		) : ( $input['metadata'] ?? array() );
		$outcome  = static function ( $status, $code = '', $message = '' ) use ( $request, $operation ) {
			return Requests::outcome( $request, $status, $code, $message, $operation );
		};
		if ( ! self::can_access( $id, $metadata['status'] ?? '', $create ) ) {
			return $outcome( 'forbidden', 'current_permission_denied', 'Current album permissions and entitlement are required.' );
		}
		if ( ! $create && ( ! Beta_Settings::is_beta_album( $id ) || 'trash' === get_post_status( $id ) ) ) {
			return $outcome( 'rejected', 'unsupported_target', 'Only Beta albums outside trash can be changed.' );
		}
		if ( ( isset( $metadata['title'] ) && '' === trim( sanitize_text_field( $metadata['title'] ) ) ) || ( ! $metadata && empty( $input['settings'] ) ) ) {
			return $outcome( 'rejected', 'invalid_patch', 'Provide a nonempty title or settings patch.' );
		}
		if ( ! empty( $input['settings'] ) ) {
			$schema = Settings_Contract::recognized( true );
			$valid  = rest_validate_value_from_schema( $input['settings'], $schema, 'settings' );
			if ( is_wp_error( $valid ) || ! Settings_Contract::strict_types( $input['settings'], $schema ) ) {
				return $outcome( 'rejected', 'invalid_settings', 'A requested album setting is invalid or has the wrong JSON type.' );
			}
			$blockers = Settings_Contract::blockers( $input['settings'], true );
			if ( $blockers ) {
				$claimed = Requests::claim( $input, $operation );
				if ( null !== $claimed ) {
					return $claimed;
				}
				$blocked             = $outcome( 'rejected', 'feature_unavailable', 'A requested album setting is locked by its current feature requirement. Nothing on this album was saved.' );
				$blocked['blockers'] = $blockers;
				return Requests::finish( $request, $blocked );
			}
			$valid = Settings_Writer::validate_patch( $create ? 0 : $id, $input['settings'] );
			if ( is_wp_error( $valid ) ) {
				return $outcome( 'rejected', $valid->get_error_code(), $valid->get_error_message() );
			}
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$transaction = false;
		try {
			Revision::begin();
			$transaction = true;
			if ( $create ) {
				Revision::document( 0, true );
			}
			if ( ! $create && ! hash_equals( Revision::document( $id, true ), $input['revision'] ) ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $request, $outcome( 'conflict', 'stale_revision', 'Read and reconcile the album before submitting a new request.' ) );
			}
			if ( ! self::can_access( $id, $metadata['status'] ?? '', $create ) ) {
				throw new \RuntimeException( 'Access changed.' );
			}
			if ( $create ) {
				$id = wp_insert_post(
					wp_slash(
						array(
							'post_type'   => 'modula-album',
							'post_status' => 'draft',
							'post_title'  => sanitize_text_field( $metadata['title'] ),
							'post_author' => get_current_user_id(),
							'meta_input'  => array( Beta_Settings::META_KEY => '1' ),
						)
					),
					true
				);
				if ( is_wp_error( $id ) || ! $id ) {
					throw new \RuntimeException( 'Creation unconfirmed.' );
				}
				Revision::track( array( $id ) );
				Meta_Sync::apply_new_beta_album_create_defaults( $id );
				if ( ! Requests::target( $request, $id ) ) {
					throw new \RuntimeException( 'Target unconfirmed.' );
				}
			}
			$post = array( 'ID' => $id );
			foreach ( array(
				'title'  => 'post_title',
				'status' => 'post_status',
			) as $key => $field ) {
				if ( isset( $metadata[ $key ] ) ) {
					$post[ $field ] = 'title' === $key ? sanitize_text_field( $metadata[ $key ] ) : $metadata[ $key ];
				}
			}
			if ( count( $post ) > 1 && is_wp_error(
				Meta_Sync::with_canonical_write(
					$id,
					static function () use ( $post ) {
						return wp_update_post( wp_slash( $post ), true );
					}
				)
			) ) {
				throw new \RuntimeException( 'Metadata unconfirmed.' );
			}
			if ( ! empty( $input['settings'] ) ) {
				$saved = Settings_Writer::patch( $id, $input['settings'], true );
				if ( is_wp_error( $saved ) ) {
					throw new \RuntimeException( 'Settings unconfirmed.' );
				}
			}
			Revision::clear_cache();
			foreach ( $post as $key => $value ) {
				if ( 'ID' !== $key && get_post( $id )->$key !== $value ) {
					throw new \RuntimeException( 'Metadata confirmation differs.' );
				}
			}
			$out          = $outcome( 'succeeded' );
			$out['album'] = Albums::summary( $id );
			$out          = Requests::finish( $request, $out );
			if ( 'succeeded' !== $out['status'] ) {
				throw new \RuntimeException( 'Outcome unconfirmed.' );
			}
			Revision::end( true );
			$transaction = false;
			return $out;
		} catch ( \Throwable $error ) {
			if ( $transaction ) {
				Revision::end( false );
			}
			return Requests::finish( $request, $outcome( 'uncertain', 'album_write_unconfirmed', 'Album write was not confirmed. Recover this identity before another action.' ) );
		}
	}
}
