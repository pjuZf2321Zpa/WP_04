<?php
/** Album duplicate, trash, restore and delete. Hierarchy edits stay inside this executor. */
namespace Modula_Pro\Extensions\Albums\Abilities;

use Modula\V2\Abilities\Album_Lifecycle;
use Modula\V2\Abilities\Albums;
use Modula\V2\Abilities\Lifecycle;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Beta_Settings;
use Modula_Pro\Extensions\Albums\V2\Members_Document;
use Modula_Pro\Extensions\Albums\V2\Meta_Sync;

defined( 'ABSPATH' ) || exit;

final class Lifecycle_Executor {
	private const COPY_META = array( Meta_Sync::FLAT_META_KEY, Meta_Sync::SETTINGS_V2_META_KEY, 'modulaSorting', '_thumbnail_id', Members_Document::MEMBERS_V2_META_KEY, Members_Document::CLASSIC_META_KEY );

	/** @return array<string,callable> */
	public static function callbacks(): array {
		return array(
			Album_Lifecycle::READ      => array( self::class, 'read' ),
			Album_Lifecycle::DUPLICATE => array( self::class, 'duplicate' ),
			Album_Lifecycle::TRASH     => array( self::class, 'trash' ),
			Album_Lifecycle::RESTORE   => array( self::class, 'restore' ),
			Album_Lifecycle::DELETE    => array( self::class, 'delete' ),
		);
	}

	public static function read( array $input ) {
		$gated = Provider::gate( Album_Lifecycle::READ, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$id = (int) $input['id'];
		if ( ! Album_Executor::can_access( $id ) || ! Beta_Settings::is_beta_album( $id ) ) {
			return new \WP_Error( 'modula_forbidden', 'An accessible Beta album is required.' );
		}
		$graph = Member_Executor::graph();
		if ( ! isset( $graph[ $id ] ) || ! hash_equals( Member_Executor::token( $graph ), Member_Executor::token( Member_Executor::graph() ) ) ) {
			return new \WP_Error( 'modula_read_conflict', 'Album hierarchy changed while reading.' );
		}
		return array(
			'id'       => $id,
			'revision' => Member_Executor::token( $graph ),
			'status'   => get_post_status( $id ),
		);
	}

	public static function duplicate( array $input ): array {
		return self::execute( $input, Album_Lifecycle::DUPLICATE );
	}

	public static function trash( array $input ): array {
		return self::execute( $input, Album_Lifecycle::TRASH );
	}

	public static function restore( array $input ): array {
		return self::execute( $input, Album_Lifecycle::RESTORE );
	}

	public static function delete( array $input ): array {
		return self::execute( $input, Album_Lifecycle::DELETE );
	}

	private static function permitted( int $id, string $operation, string $status ): bool {
		return Album_Executor::can_access( $id, $status ) && ( Album_Lifecycle::DUPLICATE === $operation ? Album_Executor::can_access( 0, $status, true ) : Albums::can_delete( $id ) );
	}

	private static function execute( array $input, string $operation ): array {
		$input['id'] = (int) $input['id'];
		$id          = $input['id'];
		$request     = $input['request_id'];
		$outcome     = static function ( $status, $code = '', $message = '' ) use ( $request, $operation ) {
			return Requests::outcome( $request, $status, $code, $message, $operation );
		};
		$existing    = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$gated = Provider::gate( $operation, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( ! self::permitted( $id, $operation, $input['status'] ?? '' ) ) {
			return $outcome( 'forbidden', 'current_permission_denied', 'Current album and lifecycle permissions are required.' );
		}
		if ( ! Beta_Settings::is_beta_album( $id ) ) {
			return $outcome( 'rejected', 'unsupported_target', 'Only Beta albums support lifecycle changes.' );
		}
		$trashed = 'trash' === get_post_status( $id );
		if ( ( Album_Lifecycle::RESTORE === $operation && ! $trashed ) || ( in_array( $operation, array( Album_Lifecycle::DUPLICATE, Album_Lifecycle::TRASH ), true ) && $trashed ) || ( Album_Lifecycle::TRASH === $operation && ! EMPTY_TRASH_DAYS ) ) {
			return $outcome( 'rejected', 'invalid_lifecycle_state', 'Restore requires trash; duplicate/trash require a live album and trash must be enabled.' );
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$active = false;
		try {
			Revision::begin();
			$active = true;
			$graph  = Member_Executor::graph( true );
			if ( ! hash_equals( $input['revision'], Member_Executor::token( $graph ) ) ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $request, $outcome( 'conflict', 'stale_revision', 'Read and reconcile the album lifecycle graph.' ) );
			}
			if ( Album_Lifecycle::DUPLICATE === $operation ) {
				$settings = Meta_Sync::get_settings_v2( $id );
				if ( ! $settings ) {
					$flat     = get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
					$settings = \Modula_Pro\Extensions\Albums\V2\Adapter::to_grouped( is_array( $flat ) ? $flat : array() );
				}
				$valid = Album_Executor::validate_configuration( $settings );
				if ( is_wp_error( $valid ) ) {
					Revision::end( false );
					$active  = false;
					$blocked = $outcome( 'rejected', $valid->get_error_code(), $valid->get_error_message() );
					$data    = $valid->get_error_data();
					if ( is_array( $data ) && ! empty( $data['blockers'] ) && is_array( $data['blockers'] ) ) {
						$blocked['blockers'] = $data['blockers'];
					}
					return Requests::finish( $request, $blocked );
				}
			}
			$documents = array();
			$parents   = array();
			$access    = array_column( $graph[ $id ]['members'], 'id' );
			if ( Album_Lifecycle::DELETE === $operation ) {
				foreach ( $graph as $album => $state ) {
					if ( $album === $id ) {
						continue;
					}
					$members = array_values(
						array_filter(
							$state['members'],
							static function ( $member ) use ( $id ) {
								return (int) $member['id'] !== $id;
							}
						)
					);
					if ( $members !== $state['members'] ) {
						$documents[ $album ] = $members;
					}
					if ( $id === $state['parent'] ) {
						$parents[ $album ] = 0;
					}
				}
				foreach ( array_unique( array_merge( array_keys( $documents ), array_keys( $parents ) ) ) as $affected ) {
					if ( ! Beta_Settings::is_beta_album( $affected ) || ! Album_Executor::can_access( $affected ) ) {
						Revision::end( false );
						$active = false;
						return Requests::finish( $request, $outcome( 'rejected', 'ineligible_hierarchy', 'Every changed parent and child must be an accessible Beta album.' ) );
					}
					$access[] = $affected;
				}
			}
			$access = array_values( array_unique( array_diff( $access, array( $id ) ) ) );
			foreach ( $access as $member ) {
				Revision::document( $member, true );
				if ( ! current_user_can( 'edit_post', $member ) || ! current_user_can( 'read_post', $member ) ) {
					Revision::end( false );
					$active = false;
					return Requests::finish( $request, $outcome( 'forbidden', 'inaccessible_member', 'Current access to affected members is required.' ) );
				}
			}
			if ( ! self::permitted( $id, $operation, $input['status'] ?? '' ) ) {
				throw new \RuntimeException( 'Access changed.' );
			}
			Requests::context( $request, array( 'member_access' => $access ) );
			$out = $outcome( 'succeeded' );
			if ( Album_Lifecycle::DUPLICATE === $operation ) {
				$copy = self::copy( $id, $input['status'], $graph[ $id ]['members'] );
				Requests::context( $request, array( 'copy' => $copy ) );
				$out['album'] = Albums::summary( $copy );
			} elseif ( Album_Lifecycle::DELETE === $operation ) {
				if ( is_wp_error( Members_Document::persist_composition( $documents, $parents ) ) || ! wp_delete_post( $id, true ) || get_post( $id ) ) {
					throw new \RuntimeException( 'Deletion unconfirmed.' );
				}
				Requests::context( $request, array( 'deleted' => true ) );
				$out['deleted_id'] = $id;
			} else {
				$status = Album_Lifecycle::TRASH === $operation ? 'trash' : $input['status'];
				$saved  = Meta_Sync::with_canonical_write(
					$id,
					static function () use ( $id, $status ) {
						if ( 'trash' === $status ) {
							return wp_trash_post( $id );
						}
						add_filter( 'wp_untrash_post_status', array( Lifecycle::class, 'restore_draft' ), PHP_INT_MAX );
						try {
							$saved = wp_untrash_post( $id );
						} finally {
							remove_filter( 'wp_untrash_post_status', array( Lifecycle::class, 'restore_draft' ), PHP_INT_MAX );
						}
						return $saved && 'publish' === $status ? wp_update_post(
							array(
								'ID'          => $id,
								'post_status' => 'publish',
							),
							true
						) : $saved;
					}
				);
				if ( ! $saved || is_wp_error( $saved ) || get_post_status( $id ) !== $status ) {
					throw new \RuntimeException( 'Lifecycle unconfirmed.' );
				}
				$out['album'] = Albums::summary( $id );
			}
			$out = Requests::finish( $request, $out );
			if ( 'succeeded' !== $out['status'] ) {
				throw new \RuntimeException( 'Outcome unconfirmed.' );
			}
			Revision::end( true );
			$active = false;
			return $out;
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			return Requests::finish( $request, $outcome( 'uncertain', 'album_lifecycle_unconfirmed', 'Recover this request and reconcile the album before another action.' ) );
		}
	}

	private static function copy( int $id, string $status, array $members ): int {
		$source = get_post( $id );
		$copy   = wp_insert_post(
			wp_slash(
				array(
					'post_type'     => 'modula-album',
					'post_status'   => 'draft',
					'post_title'    => 'Copy of ' . $source->post_title,
					'post_author'   => get_current_user_id(),
					'post_password' => $source->post_password,
					'meta_input'    => array( Beta_Settings::META_KEY => '1' ),
				)
			),
			true
		);
		if ( is_wp_error( $copy ) || ! $copy ) {
			throw new \RuntimeException( 'Copy unconfirmed.' );
		}
		Revision::track( array( $copy ) );
		Meta_Sync::with_canonical_write(
			$copy,
			static function () use ( $copy, $id, $status ) {
				foreach ( self::COPY_META as $key ) {
					if ( metadata_exists( 'post', $id, $key ) ) {
						update_post_meta( $copy, $key, wp_slash( get_post_meta( $id, $key, true ) ) );
					}
				}
				if ( 'publish' === $status ) {
					wp_update_post(
						array(
							'ID'          => $copy,
							'post_status' => $status,
						)
					);
				}
			}
		);
		Revision::clear_cache();
		if ( get_post_status( $copy ) !== $status || get_post( $copy )->post_password !== $source->post_password || Member_Executor::members( $copy ) !== $members ) {
			throw new \RuntimeException( 'Copy differs.' );
		}
		foreach ( self::COPY_META as $key ) {
			if ( get_post_meta( $copy, $key, true ) !== get_post_meta( $id, $key, true ) ) {
				throw new \RuntimeException( 'Copy configuration differs.' );
			}
		}
		return $copy;
	}
}
