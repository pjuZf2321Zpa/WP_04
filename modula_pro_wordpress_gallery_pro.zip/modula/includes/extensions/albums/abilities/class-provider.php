<?php
/** Pro contribution for album ability executors. */
namespace Modula_Pro\Extensions\Albums\Abilities;

use Modula\V2\Abilities\Album_Explanation;
use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Provider {
	public const ID = 'modula-pro-albums';

	/** @var int Entries into an album executor during this request. */
	public static $executions = 0;

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! Pro_Dependency::extension_contract( 'modula-albums' ) ) {
			return $contributions;
		}
		$operations = array();
		foreach ( array_merge( Album_Executor::callbacks(), Member_Executor::callbacks(), Lifecycle_Executor::callbacks() ) as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck the album feature before any effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		++self::$executions;
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Album_Explanation::rejected( $name, $input, $blockers );
	}
}
