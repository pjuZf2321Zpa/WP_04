<?php

namespace Modula_Pro\Extensions\Albums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Albums_Gutenberg {

	public function __construct() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'register_block_type' ) );
		add_action( 'init', array( $this, 'generate_js_vars' ) );
		add_action( 'wp_ajax_modula_get_album_meta', array( $this, 'get_album_meta' ) );
		add_action( 'wp_ajax_nopriv_modula_get_album_meta', array( $this, 'callback_get_album_meta' ) );
	}

	public function callback_get_album_meta() {
		return false;
	}

	public function register_block_type() {
		wp_register_script( 'albums-gutenberg', \MODULA_PRO_URL . 'includes/extensions/albums/assets/js/admin/wp-modula-albums-gutenberg.js', array(), \MODULA_PRO_VERSION, true );
		wp_register_style( 'albums-gutenberg', \MODULA_PRO_URL . 'includes/extensions/albums/assets/css/admin/modula-albums-gutenberg.css', array(), true );

		register_block_type(
			'modula/albums',
			array(
				'render_callback' => array( $this, 'render_modula_album' ),
				'editor_script'   => 'albums-gutenberg',
				'editor_style'    => 'albums-gutenberg',
			)
		);
	}

	public function generate_js_vars() {
		wp_localize_script(
			'albums-gutenberg',
			'modulaAlbumsVars',
			apply_filters(
				'modula_albums_gutenberg_vars',
				array(
					'adminURL'             => admin_url(),
					'ajaxURL'              => admin_url( 'admin-ajax.php' ),
					'nonce'                => wp_create_nonce( 'modula_nonce' ),
					'gutenbergAlbumsTitle' => esc_html__( 'Modula Albums', 'modula-pro' ),
				)
			)
		);
	}

	public function render_modula_album( $atts ) {
		if ( ! isset( $atts['id'] ) ) {
			return;
		}

		return do_shortcode( '[modula-album id="' . absint( $atts['id'] ) . '"]' );
	}

	public function get_album_meta() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$id = isset( $_POST['id'] ) ? wp_unslash( $_POST['id'] ) : '';
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$nonce = isset( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';

		if ( ! $id || ! $nonce ) {
			wp_send_json_error();
			die();
		}

		if ( ! wp_verify_nonce( $nonce, 'modula_nonce' ) ) {
			wp_send_json_error();
			die();
		}

		$galleries = get_post_meta( $id, 'modula-album-galleries', true );

		if ( ! is_array( $galleries ) ) {
			wp_send_json_error();
			die();
		}

		foreach ( $galleries as $key => $gallery ) :
			$gallery_id = $galleries[ $key ]['id'];
			$gal_images = get_post_meta( $gallery_id, 'modula-images', true );
			$i          = 0;

			if ( 0 !== $galleries[ $key ]['cover'] && ! empty( $galleries[ $key ]['cover'] ) ) {
				$image_obj                = wp_get_attachment_image_src( $galleries[ $key ]['cover'], 'large' );
				$images[ $key ]['src']    = $image_obj[0];
				$images[ $key ]['width']  = $image_obj[1];
				$images[ $key ]['height'] = $image_obj[2];
			} else {
				foreach ( $gal_images as $image ) {
					if ( $i < 1 ) {
						$image_obj                = wp_get_attachment_image_src( $image['id'], 'large' );
						$images[ $key ]['src']    = $image_obj[0];
						$images[ $key ]['width']  = $image_obj[1];
						$images[ $key ]['height'] = $image_obj[2];
					}
					++$i;
				}
			}
		endforeach;

		echo wp_json_encode( $images );
		die();
	}
}
