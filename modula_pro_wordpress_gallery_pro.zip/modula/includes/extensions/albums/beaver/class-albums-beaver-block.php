<?php

namespace Modula_Pro\Extensions\Albums\Beaver;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Albums_Beaver_Block extends \FLBuilderModule {

	public function __construct() {
		parent::__construct(
			apply_filters(
				'modula_albums_beaver_construct',
				array(
					'name'            => esc_html__( 'Modula Albums', 'modula-pro' ),
					'description'     => esc_html__( 'A block for Modula Albums', 'modula-pro' ),
					'category'        => esc_html__( 'Modula', 'modula-pro' ),
					'icon'            => 'format-image.svg',
					'dir'             => MODULA_PRO_PATH . 'includes/extensions/albums/beaver/',
					'url'             => MODULA_PRO_URL . 'includes/extensions/albums/beaver/',
					'partial_refresh' => true,
				)
			)
		);
	}
}

\FLBuilder::register_module(
	'Modula_Pro\\Extensions\\Albums\\Beaver\\Albums_Beaver_Block',
	apply_filters(
		'modula_albums_beaver_module',
		array(
			'modula_album' => array(
				'title'    => esc_html__( 'Modula Albums', 'modula-pro' ),
				'sections' => array(
					'modula_album_section' => array(
						'title'  => esc_html__( 'Select the Modula Album you want', 'modula-pro' ),
						'fields' => array(
							'modula_album_select' => array(
								'type'    => 'select',
								'label'   => esc_html__( 'Select Modula Album', 'modula-pro' ),
								'default' => 'none',
								'options' => modula_get_albums(),
							),
						),
					),
				),
			),
		)
	)
);
