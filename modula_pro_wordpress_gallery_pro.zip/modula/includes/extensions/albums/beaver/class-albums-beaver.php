<?php

namespace Modula_Pro\Extensions\Albums\Beaver;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Albums_Beaver {

	/**
	 * Modula_Beaver constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'include_beaver_block' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_page_builder_scripts' ) );
	}

	/**
	 * Include Modula Beaver Block
	 */
	public function include_beaver_block() {
		if ( ! class_exists( 'FLBuilder' ) ) {
			return;
		}

		new Albums_Beaver_Block();
	}

	/**
	 * Enqueue needed scripts in the admin required for pagebuilder preview
	 */
	public function enqueue_page_builder_scripts() {

		// only enqueue for Beaver page builder live editing
		if ( ! class_exists( 'FLBuilderModel' ) || ! \FLBuilderModel::is_builder_active() ) {
			return;
		}

		wp_register_script( 'modula-albums-beaver-preview', \MODULA_PRO_URL . 'includes/extensions/albums/assets/js/admin/modula-albums-beaver-preview.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-lazysizes' );
		wp_enqueue_script( 'modula-fancybox' );
		wp_enqueue_script( 'modula-isotope' );
		wp_enqueue_script( 'modula-isotope-packery' );
		wp_enqueue_script( 'modula-albums' );
		wp_enqueue_script( 'modula-albums-beaver-preview' );
	}
}
