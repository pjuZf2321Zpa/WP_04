<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$album_id = $settings->modula_album_select;
if ( 'none' !== $album_id ) {
	echo do_shortcode( '[modula-album id="' . absint( $album_id ) . '"]' );
} else {
	echo esc_html__( 'No album was selected', 'modula-pro' );
}
