<?php
namespace Modula_Pro\Extensions\Albums\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Albums_Admin {

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		add_action( 'wp_ajax_modula_albums_save_galleries', array( $this, 'save_galleries' ) );
		add_action( 'wp_ajax_modula_albums_save_gallery', array( $this, 'save_gallery' ) );

		// Custom Field
		add_filter( 'modula_field_type_album-lightbox-info_format', array( $this, 'field_format' ), 10, 2 );
		add_filter( 'modula_render_album-lightbox-info_field_type', array( $this, 'render_field' ) );

		// Add Modula Albums debug information
		add_filter( 'modula_debug_information', array( $this, 'debug_information' ), 35 );

		add_filter( 'modula_albums_admin_field_value', array( $this, 'backward_compatibility_admin_responsive_gutter' ), 10, 3 );
		add_filter( 'modula_albums_admin_field_value', array( $this, 'backward_compatibility_admin_grid_type' ), 10, 3 );
		add_filter( 'modula_album_fields', array( $this, 'backward_compatibility_admin_album_width' ), 100 );
	}

	private function sanitize_gallery( $image ) {

		$new_image = array();

		$image_attributes = apply_filters(
			'modula_album_gallery_attributes',
			array(
				'id',
				'alt',
				'title',
				'caption',
				'width',
				'height',
				'gridX',
				'gridY',
				'cover',
				'customurl',
				'shuffleCover',
				'itemType',
			)
		);

		foreach ( $image_attributes as $attribute ) {
			if ( isset( $image[ $attribute ] ) ) {
				switch ( $attribute ) {
					case 'alt':
					case 'itemType':
						$new_image[ $attribute ] = sanitize_text_field( $image[ $attribute ] );
						break;
					case 'customurl':
						$new_image[ $attribute ] = esc_url( $image[ $attribute ] );
						break;
					case 'cover':
					case 'shuffleCover':
						$new_image[ $attribute ] = sanitize_text_field( $image[ $attribute ] );
						break;
					case 'id':
					case 'width':
					case 'height':
						$new_image[ $attribute ] = absint( $image[ $attribute ] );
						break;
					case 'gridX':
					case 'gridY':
						$raw_cell = $image[ $attribute ];
						if ( '' === $raw_cell || null === $raw_cell || ( is_string( $raw_cell ) && '' === trim( $raw_cell ) ) ) {
							$new_image[ $attribute ] = '';
						} elseif ( is_numeric( $raw_cell ) && (int) $raw_cell >= 0 ) {
							$new_image[ $attribute ] = absint( $raw_cell );
						} else {
							$new_image[ $attribute ] = '';
						}
						break;
					case 'title':
					case 'caption':
						$new_image[ $attribute ] = wp_filter_post_kses( $image[ $attribute ] );
						break;
					default:
						$new_image[ $attribute ] = apply_filters( 'modula_album_gallery_field_sanitization', sanitize_text_field( $image[ $attribute ] ), $image[ $attribute ], $attribute );
						break;
				}
			} else {
				$new_image[ $attribute ] = '';
			}
		}

		return $new_image;
	}

	/**
	 * Save selected galleries in Modula Albums
	 */
	public function save_galleries() {
		// phpcs:ignore WordPress.Security
		$nonce = isset( $_POST['_wpnonce'] ) ? wp_unslash( $_POST['_wpnonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'modula-ajax-save' ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		if ( ! isset( $_POST['album'] ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		$album_id = absint( $_POST['album'] );

		if ( 'modula-album' !== get_post_type( $album_id ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		if ( ! isset( $_POST['galleries'] ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		$old_galleries = get_post_meta( $album_id, 'modula-album-galleries', true );
		if ( ! is_array( $old_galleries ) ) {
			$old_galleries = array();
		}

		$galleries = json_decode( stripslashes( $_POST['galleries'] ), true );
		if ( ! is_array( $galleries ) ) {
			$galleries = array();
		}

		$old_album_ids = $this->extract_album_ids( $old_galleries );
		$new_album_ids = $this->extract_album_ids( $galleries );

		$added_album_ids   = array_values( array_diff( $new_album_ids, $old_album_ids ) );
		$removed_album_ids = array_values( array_diff( $old_album_ids, $new_album_ids ) );

		$this->set_albums_parent( $added_album_ids, $album_id );
		$this->set_albums_parent( $removed_album_ids, 0 );

		$new_galleries = array();

		if ( is_array( $galleries ) ) {
			foreach ( $galleries as $gallery ) {
				$new_galleries[] = $this->sanitize_gallery( $gallery );
			}
		}

		update_post_meta( $album_id, 'modula-album-galleries', $new_galleries );
		wp_send_json( array( 'status' => 'succes' ) );
	}

	/**
	 * Save gallery in Modula Album
	 */
	public function save_gallery() {
        // phpcs:ignore WordPress.Security
		$nonce = isset( $_POST['_wpnonce'] ) ? wp_unslash( $_POST['_wpnonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'modula-ajax-save' ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		if ( ! isset( $_POST['album'] ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		$album_id = absint( $_POST['album'] );

		if ( 'modula-album' !== get_post_type( $album_id ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		if ( ! isset( $_POST['gallery'] ) ) {
			wp_send_json( array( 'status' => 'failed' ) );
		}

		// phpcs:ignore WordPress.Security
		$gallery          = json_decode( wp_unslash( $_POST['gallery'] ), true );
		$update_galleries = array();

		$old_galleries = get_post_meta( $album_id, 'modula-album-galleries', true );

		if ( $old_galleries && is_array( $old_galleries ) ) {
			foreach ( $old_galleries as $key => $old_gallery ) {
				if ( $old_gallery['id'] === $gallery['id'] ) {
					$old_galleries[ $key ] = $this->sanitize_gallery( $gallery );
				}
			}
			$update_galleries = $old_galleries;
		} else {
			$update_galleries[ $gallery['id'] ] = $this->sanitize_gallery( $gallery );
		}

		update_post_meta( $album_id, 'modula-album-galleries', $update_galleries );
		wp_send_json( array( 'status' => 'succes' ) );
	}

	public function field_format( $format, $field ) {
		$format = '<tr data-container="' . esc_attr( $field['id'] ) . '"><td colspan="2" style="padding-left:0;"><label class="th-label">%s</label>%s<div>%s</div></td></tr>';

		return $format;
	}

	public function render_field() {

		$html  = '<div class="modula-album-url-settings">';
		$html .= '<ol>';
		$html .= '<li><p>Will redirect to a custom URL if one is set in Gallery Settings.</p></li>';
		$html .= '<li><p>Will redirect to a gallery URL if <a href="' . admin_url( 'edit.php?post_type=modula-gallery&page=modula' ) . '">standalone</a> is active.</p></li>';
		$html .= '</ol>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Add debug information
	 *
	 * @param $info
	 *
	 * @return mixed
	 * @since 1.0.8
	 */
	public function debug_information( $info ) {

		$standalone = get_option( 'modula_standalone' );

		$info['modula_albums_version'] = array(
			'label' => __( 'Modula Albums Version', 'modula-pro' ),
			'value' => MODULA_PRO_VERSION,
			'debug' => esc_html( 'Albums version ' . MODULA_PRO_VERSION ),
		);

		$info['total_albums'] = array(
			'label' => __( 'Total albums', 'modula-pro' ),
			'value' => esc_html( count( \modula_get_albums() ) ),
			'debug' => esc_html( 'Total albums ' . count( \modula_get_albums() ) ),
		);

		$info['albums_standalone'] = array(
			'label' => __( 'Albums standalone', 'modula-pro' ),
			'value' => ( $standalone && isset( $standalone['album']['enable_rewrite'] ) && 'enabled' === $standalone['album']['enable_rewrite'] ) ? esc_html__( 'Yes', 'modula-pro' ) : esc_html__( 'No', 'modula-pro' ),
			'debug' => ( $standalone && isset( $standalone['album']['enable_rewrite'] ) && 'enabled' === $standalone['album']['enable_rewrite'] ) ? esc_html( 'yes' ) : esc_html( 'no' ),
		);

		$info['albums_standalone_slug'] = array(
			'label' => __( 'Albums standalone slug', 'modula-pro' ),
			'value' => ( $standalone && isset( $standalone['album']['slug'] ) && '' !== $standalone['album']['slug'] ) ? esc_html( $standalone['album']['slug'] ) : esc_html__( 'None', 'modula-pro' ),
			'debug' => ( $standalone && isset( $standalone['album']['slug'] ) && '' !== $standalone['album']['slug'] ) ? esc_html( $standalone['album']['slug'] ) : esc_html( 'None' ),
		);

		$info['galleries_standalone'] = array(
			'label' => __( 'Galleries standalone', 'modula-pro' ),
			'value' => ( $standalone && isset( $standalone['gallery']['enable_rewrite'] ) && 'enabled' === $standalone['gallery']['enable_rewrite'] ) ? esc_html__( 'Yes', 'modula-pro' ) : esc_html__( 'No', 'modula-pro' ),
			'debug' => ( $standalone && isset( $standalone['gallery']['enable_rewrite'] ) && 'enabled' === $standalone['gallery']['enable_rewrite'] ) ? esc_html( 'yes' ) : esc_html( 'no' ),
		);

		$info['galleries_standalone_slug'] = array(
			'label' => __( 'Galleries standalone slug', 'modula-pro' ),
			'value' => ( $standalone && isset( $standalone['gallery']['slug'] ) && '' !== $standalone['gallery']['slug'] ) ? esc_html( $standalone['gallery']['slug'] ) : esc_html__( 'None', 'modula-pro' ),
			'debug' => ( $standalone && isset( $standalone['gallery']['slug'] ) && '' !== $standalone['gallery']['slug'] ) ? esc_html( $standalone['gallery']['slug'] ) : esc_html( 'None' ),
		);

		return $info;
	}

	/**
	 * Backwards compatibility for responsive gutter
	 *
	 * @param $value
	 * @param $key
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.3.0
	 */
	public function backward_compatibility_admin_responsive_gutter( $value, $key, $settings ) {

		if ( 'tablet_gutter' === $key && ! isset( $settings['tablet_gutter'] ) && isset( $settings['gutter'] ) ) {
			return absint( $settings['gutter'] );
		}

		if ( 'mobile_gutter' === $key && ! isset( $settings['mobile_gutter'] ) && isset( $settings['gutter'] ) ) {
			return absint( $settings['gutter'] );
		}

		return $value;
	}

	/**
	 * Backwards compatibility for album width
	 *
	 * @param $value
	 * @param $key
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.3.0
	 */
	public function backward_compatibility_admin_album_width( $fields ) {
		global $post;

		if ( ! isset( $post->ID ) ) {
			return $fields;
		}

		$settings = get_post_meta( $post->ID, 'modula-album-settings', true );

		// Check if album_width was previously saved.
		if ( isset( $settings['album_width'] ) ) {
			return $fields;
		}

		// Check if first time save.
		if ( ! isset( $settings['album_width'] ) && ! isset( $settings['width'] ) ) {
			return $fields;
		}

		$fields['general']['album_width']['default'] = 'custom';

		return $fields;
	}

	/**
	 * Backwards compatibility for grid type
	 *
	 * @param $value
	 * @param $key
	 * @param $settings
	 *
	 * @return mixed
	 * @since 1.3.0
	 */
	public function backward_compatibility_admin_grid_type( $value, $key, $settings ) {

		if ( 'album_type' === $key && isset( $settings['type'] ) && 'custom-grid' === $settings['type'] ) {
			return 'custom-grid';
		}

		if ( 'type' === $key && isset( $settings['type'] ) && 'custom-grid' === $settings['type'] ) {
			return 3;
		}

		return $value;
	}

	private function extract_album_ids( $items ): array {
		if ( empty( $items ) || ! is_array( $items ) ) {
			return array();
		}

		$ids = array();

		foreach ( $items as $item ) {
			if ( empty( $item['itemType'] ) || 'modula-album' !== $item['itemType'] ) {
				continue;
			}

			if ( empty( $item['id'] ) ) {
				continue;
			}

			$ids[] = (int) $item['id'];
		}

		$ids = array_values( array_unique( array_filter( $ids ) ) );

		return $ids;
	}

	private function set_albums_parent( $albums_id, $parent_id ) {
		foreach ( $albums_id as $child_id ) {
			wp_update_post(
				array(
					'ID'          => (int) $child_id,
					'post_parent' => (int) $parent_id,
				)
			);
		}
	}
}
