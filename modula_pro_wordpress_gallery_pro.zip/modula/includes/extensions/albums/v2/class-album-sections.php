<?php
/**
 * Sections of a visitor album rendered with "Merge galleries and albums" off.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Owns which separated section carries the album id, and which section is
 * first or last for controls that must print once (navigation, Back to album,
 * Download All).
 */
class Album_Sections {

	/**
	 * Container id of each separated section, in render order (albums, then galleries).
	 *
	 * The galleries section keeps the album container id: the album lightbox
	 * class (`modula-lightbox-<id>`) and the Download All archive are keyed to it,
	 * and nested album tiles never open the lightbox. When both sections render,
	 * the albums section gets a suffixed id so the page has no duplicate ids.
	 *
	 * @param string $album_container_id Album container id, e.g. `jtg-album-12`.
	 * @param bool   $has_album          The album lists at least one nested album.
	 * @param bool   $has_gallery        The album lists at least one gallery.
	 * @return array<string,string> Template slug => container id.
	 */
	public static function container_ids( $album_container_id, $has_album, $has_gallery ) {
		$sections = array();

		if ( $has_album ) {
			$sections['albums-albums'] = $has_gallery ? $album_container_id . '-albums' : $album_container_id;
		}

		if ( $has_gallery ) {
			$sections['albums-galleries'] = $album_container_id;
		}

		return $sections;
	}

	/**
	 * Whether the section opens the album output, so "above" controls print once.
	 *
	 * The galleries section is first only when no albums section precedes it.
	 *
	 * @param string      $type Section type passed to the items hooks: `all` (merged), `modula-album` or `modula-gallery`.
	 * @param object|null $data Album template data; reads `has_album`.
	 * @return bool
	 */
	public static function is_first( $type, $data ) {
		if ( 'modula-gallery' === $type ) {
			return ! ( isset( $data->has_album ) && $data->has_album );
		}

		return 'all' === $type || 'modula-album' === $type;
	}

	/**
	 * Whether the section closes the album output, so "below" controls print once.
	 *
	 * The albums section is last only when no galleries section follows it.
	 *
	 * @param string      $type Section type passed to the items hooks: `all` (merged), `modula-album` or `modula-gallery`.
	 * @param object|null $data Album template data; reads `has_gallery`.
	 * @return bool
	 */
	public static function is_last( $type, $data ) {
		return 'modula-album' !== $type || ! ( isset( $data->has_gallery ) && $data->has_gallery );
	}
}
