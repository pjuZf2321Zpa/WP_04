<?php
/**
 * Full-screen takeover for modula-album when modern settings editor is enabled.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Album_Takeover_Admin
 *
 * The Albums editor is offered to everyone and opted into per album, as the gallery
 * editor (Lite ADR 0054): a Beta album (stored `_modula_beta`) opens the takeover; a
 * classic album opens the editor choice from the listing. A Beta gallery flag does
 * not enable albums takeover.
 *
 * Force-OFF site-wide, keeping every `_modula_beta`, is the gallery editor's:
 * `add_filter( 'modula_enable_modern_settings_editor', '__return_false' );`
 */
class Album_Takeover_Admin {

	/**
	 * @return void
	 */
	public static function init() {
		add_filter( 'admin_body_class', array( __CLASS__, 'filter_body_class' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'remove_legacy_metaboxes' ), 99 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'register_pro_extension_script_dependencies' ), 15 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'dequeue_legacy_album_scripts' ), 100 );
		add_action( 'admin_head', array( __CLASS__, 'print_appearance_boot_script' ), 1 );
		add_action( 'admin_footer', array( __CLASS__, 'render_root' ), 5 );
		add_filter( 'modula_gallery_listing_config', array( __CLASS__, 'filter_listing_config' ) );
	}

	/**
	 * Expose album takeover availability to the gallery listing bootstrap.
	 *
	 * @param array<string, mixed> $config Listing config.
	 * @return array<string, mixed>
	 */
	public static function filter_listing_config( $config ) {
		if ( ! is_array( $config ) ) {
			return $config;
		}
		$config['albumTakeoverAvailable'] = self::is_takeover_ui_available();
		return $config;
	}

	/**
	 * Whether Albums editor takeover UI may be offered (listing / create / Try / Convert).
	 *
	 * Site-wide force-OFF only — no edit-screen or Beta-album check. On by default;
	 * Lite's Beta_Gallery_Admin::is_album_takeover_available() asks this too.
	 *
	 * @return bool
	 */
	public static function is_takeover_ui_available() {
		return self::is_takeover_enabled_for( 0 );
	}

	/**
	 * Whether the albums React takeover should replace the classic album edit screen.
	 *
	 * Requires is_takeover_enabled_for() and a Beta album (stored `_modula_beta`).
	 *
	 * @return bool
	 */
	public static function should_use_takeover() {
		if ( ! self::is_modula_album_edit_screen() ) {
			return false;
		}

		$album_id = class_exists( '\Modula\V2\Beta_Settings' )
			? \Modula\V2\Beta_Settings::current_album_id()
			: 0;

		if ( ! self::is_takeover_enabled_for( $album_id ) ) {
			return false;
		}
		if ( $album_id < 1 || ! class_exists( '\Modula\V2\Beta_Settings' ) || ! \Modula\V2\Beta_Settings::is_beta_album( $album_id ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Whether `modula_enable_modern_settings_editor` lets the Albums editor run for this album.
	 *
	 * Defaults true; false is the force-OFF, as for galleries, even for albums that
	 * already store `_modula_beta`. For an album, Lite's Beta_Settings answers the
	 * filter from its stored flag; with no album (ID 0) it keeps this default.
	 *
	 * @param int $album_id Album post ID (0 on a screen without one).
	 * @return bool
	 */
	public static function is_takeover_enabled_for( $album_id ) {
		return (bool) apply_filters( 'modula_enable_modern_settings_editor', true, $album_id );
	}

	/**
	 * @return bool
	 */
	private static function is_modula_album_edit_screen() {
		if ( ! is_admin() ) {
			return false;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen
			&& 'post' === $screen->base
			&& 'modula-album' === $screen->post_type;
	}

	/**
	 * @return void
	 */
	public static function remove_legacy_metaboxes() {
		if ( ! self::should_use_takeover() ) {
			return;
		}
		remove_meta_box( 'modula-album-settings', 'modula-album', 'normal' );
		remove_meta_box( 'modula-album-galleries', 'modula-album', 'normal' );
		remove_meta_box( 'modula-album-shortcode', 'modula-album', 'side' );
	}

	/**
	 * Register script handles Pro extensions depend on without loading the legacy album metabox stack.
	 *
	 * @param string $hook_suffix Current admin screen hook.
	 * @return void
	 */
	public static function register_pro_extension_script_dependencies( $hook_suffix ) {
		if ( ! self::should_use_takeover() ) {
			return;
		}
		if ( 'post.php' !== $hook_suffix && 'post-new.php' !== $hook_suffix ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'modula-album' !== $screen->post_type ) {
			return;
		}

		if ( function_exists( 'modula_pro_ensure_condition_scripts_registered' ) ) {
			modula_pro_ensure_condition_scripts_registered();
		}
	}

	/**
	 * @param string $hook_suffix
	 * @return void
	 */
	public static function dequeue_legacy_album_scripts( $hook_suffix ) {
		if ( ! self::should_use_takeover() ) {
			return;
		}
		if ( 'post.php' !== $hook_suffix && 'post-new.php' !== $hook_suffix ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'modula-album' !== $screen->post_type ) {
			return;
		}
		$handles = apply_filters(
			'modula_album_takeover_dequeue_legacy_scripts',
			array(
				'modula-albums',
				'wp-modula-albums',
				'wp-modula-settings',
				'wp-modula',
				'wp-modula-items',
				'wp-modula-galleries',
				'wp-modula-save',
				'wp-modula-modal',
				'modula',
				'modula-items',
				'modula-save',
				'modula-modal',
				'modula-upload',
				'modula-gallery',
				'modula-conditions',
				'modula-settings',
				'modula-pro-tilt',
				'modula-resize-senzor',
				'modula-packery',
				'modula-edit-screen',
				'albums-wp-modula',
				'modula-albums-conditions',
				'modula-albums-hovereffects',
				'modula-albums-password-protect-conditions',
				'modula-slider-conditions',
				'modula-slider-settings',
				'modula-zoom-conditions',
				'modula-comments-conditions',
				'modula-exif-conditions',
				'modula-exif-js',
				'modula-download-conditions',
				'modula-deeplink-conditions',
				'modula-slideshow-conditions',
				'modula-video-conditions',
				'modula-pagination-conditions',
				'modula-image-proofing-conditions',
			)
		);
		foreach ( $handles as $handle ) {
			wp_dequeue_script( $handle );
		}
	}

	/**
	 * @param string $classes
	 * @return string
	 */
	public static function filter_body_class( $classes ) {
		if ( self::should_use_takeover() ) {
			$classes .= ' modula-album-takeover';
		}
		return $classes;
	}

	/**
	 * Early paint: resolve the shared editor appearance before the React bundle loads.
	 *
	 * The shared boot shell in Lite writes `data-modula-se-appearance` on `<html>` and
	 * copies a leftover `modula-albums-editor-appearance` value into the shared key once.
	 *
	 * @return void
	 */
	public static function print_appearance_boot_script() {
		if ( ! self::should_use_takeover() || ! self::has_boot_shell() ) {
			return;
		}
		\Modula\V2\Admin\Takeover_Boot_Shell::print_appearance_script();
	}

	/**
	 * Fixed root for the React app, painted with the shared boot shell and desktop-only notice.
	 *
	 * @return void
	 */
	public static function render_root() {
		if ( ! self::should_use_takeover() ) {
			return;
		}
		$root_id    = 'modula-album-takeover-root';
		$root_class = 'modula-album-takeover__mount modula-albums-editor-mount';
		if ( ! self::has_boot_shell() ) {
			echo '<div id="' . esc_attr( $root_id ) . '" class="' . esc_attr( $root_class ) . '"></div>' . "\n";
			return;
		}
		\Modula\V2\Admin\Takeover_Boot_Shell::render_mount(
			array(
				'id'              => $root_id,
				'class'           => $root_class,
				'back_url'        => Albums_Editor_Enqueue::list_url(),
				'desktop_message' => __( 'The album editor is a desktop experience. Open this page on a computer to continue.', 'modula-pro' ),
			)
		);
	}

	/**
	 * Whether the active Lite ships the shared takeover boot shell (Lite 3.0.13+).
	 *
	 * @return bool
	 */
	private static function has_boot_shell() {
		return class_exists( '\Modula\V2\Admin\Takeover_Boot_Shell' );
	}

	/**
	 * @return void
	 */
	public static function enqueue_takeover_styles() {
		if ( ! defined( 'MODULA_URL' ) || ! defined( 'MODULA_LITE_VERSION' ) ) {
			return;
		}
		if ( self::has_boot_shell() ) {
			\Modula\V2\Admin\Takeover_Boot_Shell::enqueue_styles();
		}
		$css_rel = 'assets/css/admin/album-takeover-admin.css';
		$css_abs = MODULA_PATH . $css_rel;
		if ( ! file_exists( $css_abs ) ) {
			return;
		}
		wp_enqueue_style(
			'modula-album-takeover-admin',
			MODULA_URL . $css_rel,
			array(),
			(string) filemtime( $css_abs )
		);
	}
}
