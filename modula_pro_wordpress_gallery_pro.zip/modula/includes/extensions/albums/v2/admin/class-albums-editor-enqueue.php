<?php
/**
 * Enqueue albums editor React bundle from Pro compiled assets.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Admin;

use Modula\V2\Modern_Gallery;

defined( 'ABSPATH' ) || exit;

/**
 * Class Albums_Editor_Enqueue
 */
class Albums_Editor_Enqueue {

	/**
	 * Album list URL after `modula_albums_editor_config`, kept for the pre-React mount.
	 *
	 * @var string
	 */
	private static $list_url = '';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ), 25 );
	}

	/**
	 * Configured album list URL, the same `listUrl` the editor receives.
	 *
	 * Falls back to the album post type list when the editor bundle was not enqueued.
	 *
	 * @return string
	 */
	public static function list_url() {
		return '' !== self::$list_url ? self::$list_url : admin_url( 'edit.php?post_type=modula-album' );
	}

	/**
	 * @param string $hook_suffix
	 * @return void
	 */
	public static function enqueue_scripts( $hook_suffix ) {
		if ( ! Album_Takeover_Admin::should_use_takeover() ) {
			return;
		}
		if ( 'post.php' !== $hook_suffix && 'post-new.php' !== $hook_suffix ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'modula-album' !== $screen->post_type ) {
			return;
		}

		if ( ! defined( 'MODULA_PRO_PATH' ) || ! defined( 'MODULA_PRO_URL' ) ) {
			return;
		}

		$rel        = 'includes/extensions/albums/public/albums-editor';
		$asset_path = MODULA_PRO_PATH . $rel . '/index.asset.php';
		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset   = require $asset_path;
		$version = isset( $asset['version'] ) ? $asset['version'] : ( defined( 'MODULA_PRO_VERSION' ) ? MODULA_PRO_VERSION : '1.0.0' );
		$deps    = isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] ) ? $asset['dependencies'] : array( 'wp-element', 'wp-i18n' );

		// The canvas plays the classic Tilt effects with the visitor's runtime
		// (`TiltFx`). It runs first, so its scan of the page binds no tile.
		if ( ! wp_script_is( 'modula-pro-tilt', 'registered' ) ) {
			wp_register_script( 'modula-pro-tilt', MODULA_PRO_URL . 'assets/js/misc/modula-pro-tilt.js', array( 'jquery' ), MODULA_PRO_VERSION, true );
		}
		$deps[] = 'modula-pro-tilt';

		wp_enqueue_script(
			'modula-albums-editor',
			MODULA_PRO_URL . $rel . '/index.js',
			$deps,
			$version,
			true
		);

		wp_set_script_translations(
			'modula-albums-editor',
			'modula-pro',
			MODULA_PRO_PATH . 'languages'
		);
		// Shared editor shell strings are in the Lite text domain (Lite 3.0.13+).
		if ( class_exists( '\Modula\V2\Admin\Takeover_Shell_Translations' ) ) {
			\Modula\V2\Admin\Takeover_Shell_Translations::attach( 'modula-albums-editor' );
		}

		wp_enqueue_style(
			'modula-albums-editor',
			MODULA_PRO_URL . $rel . '/index.css',
			array( 'wp-components' ),
			$version
		);
		// The canvas renders the album with the visitor's components (album-frontend
		// ticket 13), on Lite's gallery visitor stylesheets, as the gallery editor's
		// live preview does. An older Lite lacks the helper; the canvas then shows
		// unstyled tiles instead of a fatal error.
		if ( method_exists( Modern_Gallery::class, 'enqueue_visitor_stylesheets' ) ) {
			Modern_Gallery::enqueue_visitor_stylesheets();
		}

		Album_Takeover_Admin::enqueue_takeover_styles();
		wp_enqueue_media();

		$post_id = 0;
		if ( 'post.php' === $hook_suffix ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0;
		}

		$post_status   = $post_id ? get_post_status( $post_id ) : '';
		$status_object = $post_status ? get_post_status_object( $post_status ) : null;
		$gate_config   = self::get_extension_gate_config();

		$post_status_choices = array();
		// Same allowlist as listing Quick edit / editor document status (no pending/future).
		$status_slugs        = array( 'publish', 'draft', 'private' );
		foreach ( $status_slugs as $slug ) {
			$obj = get_post_status_object( $slug );
			if ( ! is_object( $obj ) || empty( $obj->label ) ) {
				continue;
			}
			$post_status_choices[] = array(
				'value' => $slug,
				'label' => $obj->label,
			);
		}
		/**
		 * Filter status options shown in the Albums editor document panel.
		 *
		 * @param array<int, array{value: string, label: string}> $post_status_choices Rows for the React editor.
		 * @param int                                             $post_id            Current album post ID.
		 */
		$post_status_choices = apply_filters( 'modula_albums_editor_post_status_choices', $post_status_choices, $post_id );

		$permalink_pieces = self::editor_permalink_pieces(
			$post_id ? get_post( $post_id ) : null
		);
		$view_permalink   = $post_id ? get_permalink( $post_id ) : false;
		$view_url         = $view_permalink ? (string) $view_permalink : '';

		// Same WP registered sizes + Custom as classic album dimensions-select.
		$grid_image_labels = class_exists( '\Modula_Helper' )
			? \Modula_Helper::get_image_sizes( true )
			: array();
		if ( ! is_array( $grid_image_labels ) ) {
			$grid_image_labels = array();
		}
		// Pixel sizes, for the Slider preview's thumbnail file size (as Lite's gallery editor).
		$image_size_dimensions = class_exists( '\Modula_Helper' )
			? \Modula_Helper::get_image_sizes( false )
			: array();
		if ( ! is_array( $image_size_dimensions ) ) {
			$image_size_dimensions = array();
		}
		$slider_image_size_labels = $grid_image_labels;
		$slider_syncing_nav_size_labels = array_merge(
			array(
				'auto' => esc_html__( 'Auto', 'modula-pro' ),
			),
			$grid_image_labels
		);

		$hover_effects = \Modula_Pro\Extensions\Albums\Utils\Hover_Effects::get_hover_effects();
		if ( ! is_array( $hover_effects ) ) {
			$hover_effects = array();
		}

		$editor_config = array(
			'albumId'               => $post_id,
			'nonce'                 => wp_create_nonce( 'wp_rest' ),
			'takeover'              => true,
			'isPro'                 => true,
			'activeExtensionSlugs'  => $gate_config['activeExtensionSlugs'],
			'extensionEntitlements' => $gate_config['extensionEntitlements'],
			'upgradeUrl'            => $gate_config['upgradeUrl'],
			'extensionsAdminUrl'    => $gate_config['extensionsAdminUrl'],
			'listUrl'               => admin_url( 'edit.php?post_type=modula-album' ),
			// Empty without the create capability: the header hides its "+".
			'newAlbumUrl'           => class_exists( '\Modula\V2\Admin\Beta_Gallery_Admin' )
				? \Modula\V2\Admin\Beta_Gallery_Admin::new_editor_create_url( 'modula-album' )
				: '',
			'adminUrl'              => admin_url( 'index.php' ),
			'postTitle'             => $post_id ? get_the_title( $post_id ) : '',
			'postStatus'            => $post_status,
			'postStatusLabel'       => ( $status_object && ! empty( $status_object->label ) ) ? $status_object->label : $post_status,
			'postStatusChoices'     => $post_status_choices,
			'canEditAlbumStatus'    => (bool) ( $post_id && current_user_can( 'edit_post', $post_id ) ),
			'postSlug'              => $permalink_pieces['slug'],
			'permalinkPrefix'       => $permalink_pieces['permalinkPrefix'],
			'permalinkSuffix'       => $permalink_pieces['permalinkSuffix'],
			'viewUrl'               => $view_url,
			'albumShortcode'        => $post_id ? '[modula-album id="' . $post_id . '"]' : '',
			'albumEmbedRows'        => self::album_embed_rows( $post_id ),
			'modulaDocsBaseUrl'     => 'https://wp-modula.com/kb/modula-albums-extension/',
			'gridImageSizes'        => $grid_image_labels,
			'sliderImageSizes'      => $slider_image_size_labels,
			'sliderSyncingNavSizes' => $slider_syncing_nav_size_labels,
			'imageSizeDimensions'   => $image_size_dimensions,
			'hoverEffects'          => $hover_effects,
			// What each effect prints on a tile, for the canvas tiles' captions.
			'hoverEffectCaptions'   => \Modula_Pro\Extensions\Albums\Utils\Hover_Effects::get_caption_elements(),
		);

		/**
		 * Filter localized config for the albums editor React app.
		 *
		 * @param array<string, mixed> $editor_config
		 * @param int                  $post_id
		 */
		$editor_config = apply_filters( 'modula_albums_editor_config', $editor_config, $post_id );

		self::$list_url = isset( $editor_config['listUrl'] ) && is_string( $editor_config['listUrl'] ) ? $editor_config['listUrl'] : '';

		wp_localize_script( 'modula-albums-editor', 'modulaAlbumsEditor', $editor_config );
	}

	/**
	 * Embed rows after Shortcode and PHP: the rows of
	 * `modula_admin_aditional_shortcodes_dropdown` that apply to an album, as
	 * the gallery editor reads them. Rows outside the label table are skipped:
	 * Modula Link and Download add their gallery shortcodes to every post.
	 *
	 * @param int $post_id Album post ID; 0 before the album exists.
	 * @return list<array{id:string,label:string,code:string}>
	 */
	public static function album_embed_rows( $post_id ) {
		$post = $post_id ? get_post( $post_id ) : null;
		if ( ! $post instanceof \WP_Post || 'modula-album' !== $post->post_type ) {
			return array();
		}

		$extra = apply_filters( 'modula_admin_aditional_shortcodes_dropdown', array(), $post );
		if ( ! is_array( $extra ) ) {
			return array();
		}

		$labels = array(
			'standalone_permalink' => __( 'Permalink', 'modula-pro' ),
		);

		$rows = array();
		foreach ( $labels as $key => $label ) {
			$code = isset( $extra[ $key ]['code'] ) ? $extra[ $key ]['code'] : '';
			if ( ! is_string( $code ) || '' === $code ) {
				continue;
			}
			$rows[] = array(
				'id'    => $key,
				'label' => $label,
				'code'  => $code,
			);
		}

		return $rows;
	}

	/**
	 * Slug + classic-style permalink pieces for editor permalink seeding.
	 *
	 * Mirrors listing Quick edit permalink chrome (prefix + slug + suffix).
	 *
	 * @param \WP_Post|null $post Album post.
	 * @return array{slug:string,permalinkPrefix:string,permalinkSuffix:string}
	 */
	private static function editor_permalink_pieces( $post ) {
		$slug   = ( $post instanceof \WP_Post ) ? (string) $post->post_name : '';
		$prefix = '';
		$suffix = '';

		if ( ! ( $post instanceof \WP_Post ) || (int) $post->ID < 1 ) {
			return array(
				'slug'            => $slug,
				'permalinkPrefix' => $prefix,
				'permalinkSuffix' => $suffix,
			);
		}

		if ( ! function_exists( 'get_sample_permalink' ) ) {
			require_once ABSPATH . 'wp-admin/includes/post.php';
		}

		$sample = get_sample_permalink( (int) $post->ID );
		if ( is_array( $sample ) ) {
			$template = isset( $sample[0] ) ? (string) $sample[0] : '';
			if ( '' === $slug && isset( $sample[1] ) && is_string( $sample[1] ) ) {
				$slug = (string) $sample[1];
			}
			$parts = preg_split( '/%(?:postname|pagename)%/', $template, 2 );
			if ( is_array( $parts ) ) {
				$prefix = isset( $parts[0] ) ? (string) $parts[0] : '';
				$suffix = isset( $parts[1] ) ? (string) $parts[1] : '';
			}
		}

		return array(
			'slug'            => $slug,
			'permalinkPrefix' => $prefix,
			'permalinkSuffix' => $suffix,
		);
	}

	/**
	 * Plan/toggle flags and upsell URLs — same keys as gallery editor bootstrap.
	 *
	 * @return array{
	 *     activeExtensionSlugs: string[],
	 *     extensionEntitlements: array<string, array{available: bool, enabled: bool}>,
	 *     upgradeUrl: string,
	 *     extensionsAdminUrl: string
	 * }
	 */
	private static function get_extension_gate_config() {
		$extension_entitlements = array();
		if ( class_exists( '\Modula\V2\Admin\Settings_Editor_Metabox' ) ) {
			$extension_entitlements = \Modula\V2\Admin\Settings_Editor_Metabox::get_extension_entitlements_for_editor();
		}

		$extensions_instance = class_exists( '\Modula_Pro\Extensions\Extensions' )
			? \Modula_Pro\Extensions\Extensions::get_instance()
			: ( class_exists( '\Modula_Extensions_Base' ) ? \Modula_Extensions_Base::get_instance() : null );

		$active_extension_slugs = array();
		if ( is_object( $extensions_instance ) && method_exists( $extensions_instance, 'get_active_extensions' ) ) {
			$raw_active = $extensions_instance->get_active_extensions();
			if ( is_array( $raw_active ) ) {
				$active_extension_slugs = array_values( $raw_active );
			}
		}

		/**
		 * Filter active Modula extension slugs passed to the v2 editors (gated fields).
		 *
		 * @param string[] $active_extension_slugs Slugs from Extensions::get_active_extensions().
		 */
		$active_extension_slugs = apply_filters( 'modula_settings_editor_active_extensions', $active_extension_slugs ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Shared with gallery editor.

		$upgrade_url = defined( 'MODULA_PRO_STORE_UPGRADE_URL' )
			? MODULA_PRO_STORE_UPGRADE_URL
			: 'https://wp-modula.com/pricing';

		return array(
			'activeExtensionSlugs'  => $active_extension_slugs,
			'extensionEntitlements' => $extension_entitlements,
			'upgradeUrl'            => $upgrade_url,
			'extensionsAdminUrl'    => admin_url( 'edit.php?post_type=modula-gallery&page=modula-addons' ),
		);
	}
}
