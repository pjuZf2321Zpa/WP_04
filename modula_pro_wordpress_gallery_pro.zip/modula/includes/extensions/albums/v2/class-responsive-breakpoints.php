<?php
/**
 * Album responsive breakpoints: defaults, the phone-below-tablet rule and the
 * visitor media queries built from them.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * One owner for "Treat as a tablet under" / "Treat as a phone under".
 */
final class Responsive_Breakpoints {

	/**
	 * Defaults keep the classic album CSS (tablet 768–992px, mobile up to 768px),
	 * not the gallery's 1024 / 600, so existing albums render as before.
	 */
	const DEFAULT_TABLET_UNDER = 992;
	const DEFAULT_PHONE_UNDER  = 768;

	/**
	 * The phone breakpoint must be below the tablet breakpoint.
	 *
	 * @param array<string, mixed> $responsive Grouped `responsive` settings; missing keys read the defaults.
	 * @return true|\WP_Error
	 */
	public static function validate_pair( array $responsive ) {
		$tablet = absint( $responsive['treatAsTabletUnder'] ?? self::DEFAULT_TABLET_UNDER );
		$phone  = absint( $responsive['treatAsPhoneUnder'] ?? self::DEFAULT_PHONE_UNDER );
		if ( $phone < $tablet ) {
			return true;
		}
		return new \WP_Error(
			'invalid_responsive_breakpoints',
			__( '"Treat as a phone under" must be smaller than "Treat as a tablet under".', 'modula-pro' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Saved breakpoints from flat (classic) album settings.
	 *
	 * @param array<string, mixed> $settings Flat album settings.
	 * @return array{0: int, 1: int} Phone and tablet breakpoints in px.
	 */
	public static function from_flat( array $settings ) {
		return array(
			absint( $settings['treat_as_phone_under'] ?? self::DEFAULT_PHONE_UNDER ),
			absint( $settings['treat_as_tablet_under'] ?? self::DEFAULT_TABLET_UNDER ),
		);
	}

	/**
	 * Visitor media queries. Both bounds are inclusive, as in the classic CSS:
	 * at exactly the phone width both match and the later mobile rule wins.
	 *
	 * @param int $phone  Phone breakpoint in px.
	 * @param int $tablet Tablet breakpoint in px.
	 * @return array{tablet: string, mobile: string}
	 */
	public static function media_queries( $phone, $tablet ) {
		$phone  = absint( $phone );
		$tablet = absint( $tablet );
		return array(
			'tablet' => "(min-width: {$phone}px) and (max-width: {$tablet}px)",
			'mobile' => "(max-width: {$phone}px)",
		);
	}
}
