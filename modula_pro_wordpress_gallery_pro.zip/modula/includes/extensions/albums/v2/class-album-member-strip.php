<?php
/**
 * The thumbnail strip on a nested album's member card (album-member-card
 * ticket 03, Lite ADR 0057).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Which covers a nested album's card shows at its cover's bottom left: those
 * of its first members a visitor can open (`Album_Member_Counts::counted_members()`),
 * in album order, each resolved as that member's own cover
 * (`modula_get_album_member_cover_id()`). There is no "+N". The Album visitor
 * frontend (`Visitor\Payload`, which guards the addresses) and the Albums
 * editor's members response read the same IDs.
 */
final class Album_Member_Strip {

	/**
	 * The most thumbnails a strip shows.
	 */
	public const SIZE = 3;

	/**
	 * @param int $album_id Nested album ID.
	 * @return list<int> Up to SIZE cover attachment IDs; a member with no cover is skipped.
	 */
	public static function cover_ids( $album_id ) {
		$album_id = absint( $album_id );
		$ids      = array();
		foreach ( Album_Member_Counts::counted_members( $album_id ) as $member ) {
			// The nested album itself is walked already, so its own covers end there.
			$cover_id = modula_get_album_member_cover_id( $member, array( $album_id ) );
			if ( $cover_id > 0 && 'attachment' === get_post_type( $cover_id ) ) {
				$ids[] = $cover_id;
			}
			if ( count( $ids ) >= self::SIZE ) {
				break;
			}
		}
		return $ids;
	}
}
