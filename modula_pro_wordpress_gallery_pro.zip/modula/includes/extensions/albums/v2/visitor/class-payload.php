<?php
/**
 * Album visitor frontend bootstrap payload: the JSON the shortcode prints for the visitor bundle.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Visitor;

use Modula\V2\Beta_Settings;
use Modula\V2\Images\Adapter as Gallery_Images_Adapter;
use Modula\V2\Meta_Sync as Gallery_Meta_Sync;
use Modula\V2\Modern_Gallery;
use Modula\V2\Rest\Settings_Controller;
use Modula_Pro\Extensions\Albums\Utils\Hover_Effects;
use Modula_Pro\Extensions\Albums\V2\Adapter;
use Modula_Pro\Extensions\Albums\V2\Album_Member_Counts;
use Modula_Pro\Extensions\Albums\V2\Album_Member_Strip;
use Modula_Pro\Extensions\Albums\V2\Album_Member_Style;
use Modula_Pro\Extensions\Albums\V2\Album_Motion;
use Modula_Pro\Extensions\Albums\V2\Members_Document;
use Modula_Pro\Extensions\Albums\V2\Meta_Sync;
use Modula_Pro\Extensions\Download\Download;
use Modula_Pro\Extensions\Image_Guardian\Albums\Albums_Guardian;

defined( 'ABSPATH' ) || exit;

/**
 * Builds the album bootstrap, as Lite's visitor gallery prints `data-modula-gallery`.
 *
 * Shape:
 * - `albumId`  int, the album post ID;
 * - `settings` the album's grouped settings with schema defaults, redacted for visitors,
 *   with the colors it paints sanitized (`VISITOR_COLORS`);
 * - `members`  list of `{ id, itemType, title, caption, alt, cover: { id, src, width, height, full, srcset, sizes }, cell: { width, height, gridX, gridY }, link, target, filters, lightboxItems?, itemCount?, downloadUrl? }`,
 *   shuffled and cut to "Galleries to show" as the album asks.
 *   `cover.srcset` and `cover.sizes` are '' when Troubleshooting turns srcset off;
 *   `cell` is the member's Custom grid cell in grid units (`Members_Document::member_cell()`);
 *   `link` is what the member follows (its custom URL, else its public page);
 *   `target` is where it opens that link, as a gallery image's: 0 Same tab, 1 New tab (`Members_Document::member_target()`);
 *   `filters` is the member's album filters, the gallery item's filter text ('' for none, `Members_Document::member_filters()`);
 *   `lightboxItems` are a gallery member's images while the album's lightbox
 *   is on, and the member then opens them instead of following its link:
 *   `{ id, url, thumbnail, title, description, alt }` and what the extensions
 *   add as the gallery lightbox reads it (`LIGHTBOX_ITEM_FIELDS`);
 *   `itemCount` (int|null, null when unknown) is there while "Display image count" is on;
 *   `counts` (`Album_Member_Counts::for_member()`, null when unknown) too while the album draws member cards;
 *   `strip`, a nested album's `{ id, src }` thumbnails (`Album_Member_Strip`), while the album draws member cards;
 *   `downloadUrl`, the member's own ZIP as the classic button links it, is there while
 *   "Download one image" is on (`downloads_members()`);
 * - `customCursorUrl` the uploaded cursor's URL while the cursor is Custom, else '';
 * - `playedMotion` `{ entrance, hover }`, what the album plays (`Album_Motion::played()`):
 *   `auto` resolved per album type, `custom` for the classic hover, hover '' on a Slider album;
 * - `classicEffectText` `{ title, description }`, what the classic effect prints of the member text;
 * - `zoomExtensionActive` bool, whether the lightbox's zoom master is available, as for galleries;
 * - `shareButtons` the lightbox's share button templates by network, while the lightbox and its
 *   Share button are on (`Modula_Helper::render_lightbox_share_template()`, as for galleries);
 * - `lightboxFullscreen` `{ enable, open }`, the lightbox's fullscreen button and whether it opens
 *   in fullscreen, as the Fullscreen extension answers for the gallery members that open it;
 * - `navigation` `{ above, below, previous, next, backToAlbumUrl }`, what a nested album's page
 *   shows as the classic album prints it: `above`/`below` from the parent's "Albums navigation
 *   position" (`modula_album_navigation_places()`); `previous`/`next` `{ url, title }` (text) or null, the sibling albums, while it
 *   shows somewhere; `backToAlbumUrl` the "Back to album" link while the page carries
 *   `back_to_album`, else ''.
 */
final class Payload {

	/**
	 * The colors the visitor paints, as `group.key`: the member card's
	 * background, the member text, the
	 * lightbox background, the download buttons and the filter bar's links
	 * (printed into the bar's CSS). They go through the gallery's sanitizer, as the
	 * gallery's colors do, so rgba colors show (the classic album keeps hex only).
	 */
	private const VISITOR_COLORS = array(
		'general.memberCardBackground',
		'captions.titleColor',
		'captions.captionColor',
		'hover.imageCountColor',
		'hover.backgroundColor',
		'hover.hoverColor',
		'lightbox.lightboxBackgroundColor',
		'download.downloadGalleryButtonColor',
		'download.downloadAllColor',
		'download.downloadAllBackgroundColor',
		'download.downloadAllGalleryIconColor',
		'filters.filterLinkColor',
		'filters.filterLinkHoverColor',
	);

	/**
	 * What an extension may set on a lightbox row, as text, under the keys the
	 * gallery lightbox reads (`buildModulaLightboxSlidesFromItems`): the file
	 * and its text; a video to play with its own autoplay and loop (Video);
	 * HTML after the caption (Image licensing, EXIF).
	 */
	private const LIGHTBOX_ITEM_FIELDS = array(
		'url',
		'thumbnail',
		'title',
		'description',
		'alt',
		'video_url',
		'autoplay_lightbox',
		'loop_video',
		'captionExtraHtml',
	);

	/**
	 * @param int                  $album_id Album post ID.
	 * @param array<string, mixed> $flat     Album flat settings as the classic album reads them; covers are sized with them.
	 * @return array{albumId: int, settings: array<string, mixed>, members: list<array<string, mixed>>, customCursorUrl: string, playedMotion: array{entrance: string, hover: string}, classicEffectText: array{title: bool, description: bool}, zoomExtensionActive: bool, lightboxFullscreen: array{enable: bool, open: bool}, navigation: array{above: bool, below: bool, previous: array{url: string, title: string}|null, next: array{url: string, title: string}|null, backToAlbumUrl: string}, shareButtons?: array<string, string>}
	 */
	public static function build( $album_id, array $flat ) {
		$settings = self::with_available_guardian(
			self::with_available_downloads( self::with_visitor_colors( self::settings( $album_id ) ) )
		);
		$members  = self::members( $album_id, $settings, $flat );

		$payload = array(
			'albumId'             => $album_id,
			// Pro checks the password server-side; visitors type it, so no visitor needs it (as for galleries).
			'settings'            => current_user_can( 'edit_post', $album_id ) ? $settings : Settings_Controller::redact_settings_for_public( $settings ),
			'members'             => $members,
			'customCursorUrl'     => self::custom_cursor_url( $settings ),
			'playedMotion'        => Album_Motion::played( $settings ),
			'classicEffectText'   => self::classic_effect_text( $settings ),
			'zoomExtensionActive' => Modern_Gallery::is_zoom_extension_active(),
			'lightboxFullscreen'  => self::lightbox_fullscreen( $members ),
			'navigation'          => self::navigation( $album_id ),
		);
		if ( self::shares_from_lightbox( $settings ) ) {
			$payload['shareButtons'] = \Modula_Helper::render_lightbox_share_template();
		}

		return $payload;
	}

	/**
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return bool Whether a gallery member opens its images in the album's lightbox.
	 */
	private static function opens_lightbox( array $settings ) {
		return true === ( $settings['lightbox']['enableLightbox'] ?? false );
	}

	/**
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return bool Whether a visitor can share from the album's lightbox: it is on, with its Share button.
	 */
	private static function shares_from_lightbox( array $settings ) {
		return self::opens_lightbox( $settings ) && true === ( $settings['lightbox']['enableShare'] ?? false );
	}

	/**
	 * The lightbox's fullscreen button, which the album has no setting for:
	 * the Fullscreen extension answers from the galleries it opens, as it
	 * adds the button to the classic album (`modula_album_template_data`).
	 *
	 * @param list<array<string, mixed>> $members Payload members.
	 * @return array{enable: bool, open: bool} Whether the button shows, and whether the lightbox opens in fullscreen; it opens so only with the button.
	 */
	private static function lightbox_fullscreen( array $members ) {
		$none    = array(
			'enable' => false,
			'open'   => false,
		);
		$opening = array_filter(
			$members,
			static function ( array $member ) {
				return array() !== ( $member['lightboxItems'] ?? array() );
			}
		);
		if ( array() === $opening ) {
			return $none;
		}

		$gallery_settings = array_values(
			array_map(
				static function ( array $member ) {
					return self::gallery_settings( $member['id'] );
				},
				$opening
			)
		);
		/**
		 * Filters whether a Beta album's lightbox shows the fullscreen button, and opens in fullscreen.
		 *
		 * @param array{enable: bool, open: bool} $fullscreen       Neither, by default.
		 * @param list<array<string, mixed>>      $gallery_settings The settings of each gallery member that opens the lightbox, in album order.
		 */
		$fullscreen = apply_filters( 'modula_album_visitor_lightbox_fullscreen', $none, $gallery_settings );
		$enable     = is_array( $fullscreen ) && true === ( $fullscreen['enable'] ?? false );
		return array(
			'enable' => $enable,
			'open'   => $enable && true === ( $fullscreen['open'] ?? false ),
		);
	}

	/**
	 * A gallery's settings as its lightbox's extensions read them: its classic
	 * settings with Lite's defaults, as the classic album passes them to
	 * `modula_album_lightbox_item` (the Beta editor keeps them in step).
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return array<string, mixed>
	 */
	private static function gallery_settings( $gallery_id ) {
		return wp_parse_args( get_post_meta( $gallery_id, 'modula-settings', true ), \Modula_CPT_Fields_Helper::get_defaults() );
	}

	/**
	 * The download extension builds every ZIP and its links. While it is off,
	 * the album offers no download (no member button, no Download all, no
	 * lightbox Download All), as the classic album, whose buttons that
	 * extension prints.
	 *
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return array<string, array<string, mixed>> The settings, with downloads off while the extension is.
	 */
	private static function with_available_downloads( array $settings ) {
		if ( ! ( Download::$instance instanceof Download ) ) {
			$settings['download']['enableDownload'] = false;
		}

		return $settings;
	}

	/**
	 * Image Guardian adds the album's protection. While it is off, the album
	 * protects nothing (no right-click block, no blur, no hidden address), as
	 * the classic album, whose scripts and URL rule that extension adds; the
	 * stored switches default to on.
	 *
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return array<string, array<string, mixed>> The settings, with protection off while the extension is.
	 */
	private static function with_available_guardian( array $settings ) {
		if ( ! ( Albums_Guardian::$instance instanceof Albums_Guardian ) ) {
			$settings['protection'] = array(
				'protection'     => false,
				'blurProtection' => false,
				'urlProtection'  => false,
			);
		}

		return $settings;
	}

	/**
	 * "Download one image": each member gets the classic button.
	 *
	 * @param array<string, array<string, mixed>> $settings Album grouped settings (`with_available_downloads()`).
	 * @return bool Whether each member carries its download link.
	 */
	private static function downloads_members( array $settings ) {
		return true === ( $settings['download']['enableDownload'] ?? false )
			&& true === ( $settings['download']['downloadGalleryButton'] ?? false );
	}

	/**
	 * What a nested album's page shows around the album, as the classic album
	 * prints it (`Shortcode::add_album_navigation_above()` / `_below()` and
	 * `add_back_to_album_button()`): its sibling albums where its parent places
	 * them, and "Back to album".
	 *
	 * @param int $album_id Album post ID.
	 * @return array{above: bool, below: bool, previous: array{url: string, title: string}|null, next: array{url: string, title: string}|null, backToAlbumUrl: string}
	 */
	private static function navigation( $album_id ) {
		$places     = modula_album_navigation_places( $album_id );
		$navigation = array(
			'above'          => $places['above'],
			'below'          => $places['below'],
			'previous'       => null,
			'next'           => null,
			'backToAlbumUrl' => esc_url_raw( modula_back_to_album_url() ),
		);
		// No place to show them: the siblings are not looked up.
		if ( ! $places['above'] && ! $places['below'] ) {
			return $navigation;
		}

		$siblings               = modula_album_navigation_siblings( $album_id );
		$navigation['previous'] = self::navigation_link( $siblings['previous'] );
		$navigation['next']     = self::navigation_link( $siblings['next'] );
		return $navigation;
	}

	/**
	 * @param array{url: string, title: string}|null $link A sibling's link, its title as `get_the_title()` returns it.
	 * @return array{url: string, title: string}|null The link with its title as text, which the visitor escapes.
	 */
	private static function navigation_link( $link ) {
		if ( null === $link ) {
			return null;
		}

		return array(
			'url'   => esc_url_raw( $link['url'] ),
			// The title filters print entities (wptexturize's dashes, quotes).
			'title' => html_entity_decode( $link['title'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
		);
	}

	/**
	 * What the album's classic effect prints of the member text, as the
	 * classic album hides the rest (`modula_album_check_hover_effect`).
	 *
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return array{title: bool, description: bool} Nothing for an effect the classic album lists no text for.
	 */
	private static function classic_effect_text( array $settings ) {
		$effect = (string) ( $settings['hover']['effect'] ?? '' );
		return Hover_Effects::get_caption_elements()[ $effect ] ?? array(
			'title'       => false,
			'description' => false,
		);
	}

	/**
	 * The settings with each member text color sanitized; a key the album
	 * lacks stays out.
	 *
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return array<string, array<string, mixed>>
	 */
	private static function with_visitor_colors( array $settings ) {
		foreach ( self::VISITOR_COLORS as $path ) {
			list( $group, $key ) = explode( '.', $path );
			if ( isset( $settings[ $group ][ $key ] ) ) {
				$settings[ $group ][ $key ] = \Modula_Helper::sanitize_rgba_colour( $settings[ $group ][ $key ] );
			}
		}

		return $settings;
	}

	/**
	 * The uploaded cursor's full-size URL, as the gallery's shortcode resolves
	 * it, while the album's cursor is Custom.
	 *
	 * @param array<string, array<string, mixed>> $settings Album grouped settings.
	 * @return string The URL, or '' for another cursor or no uploaded image.
	 */
	private static function custom_cursor_url( array $settings ) {
		$attachment_id = absint( $settings['hover']['uploadCursor'] ?? 0 );
		if ( 'custom' !== ( $settings['hover']['cursor'] ?? '' ) || 0 === $attachment_id ) {
			return '';
		}

		$image = wp_get_attachment_image_src( $attachment_id, 'full' );
		return is_array( $image ) ? (string) $image[0] : '';
	}

	/**
	 * The album's grouped settings, with each schema default the store lacks.
	 *
	 * @param int $album_id Album post ID.
	 * @return array<string, array<string, mixed>>
	 */
	private static function settings( $album_id ) {
		// Convert keeps the classic settings; until the Albums editor opens the album, they are all it stores.
		if ( array() === Meta_Sync::get_stored_settings_v2( $album_id ) ) {
			return Adapter::to_grouped( modula_albums_get_album_settings( $album_id ), array( 'legacy_import' => true ) );
		}

		return Adapter::with_schema_defaults( Meta_Sync::get_settings_v2( $album_id ) );
	}

	/**
	 * The members the visitor may see, each with a cover: in album order, or
	 * shuffled, then cut to "Galleries to show", as the classic album does.
	 *
	 * @param int                  $album_id Album post ID.
	 * @param array<string, mixed> $settings Album grouped settings.
	 * @param array<string, mixed> $flat     Album flat settings.
	 * @return list<array<string, mixed>>
	 */
	private static function members( $album_id, array $settings, array $flat ) {
		/** This filter is documented in the classic album shortcode. */
		$stored   = apply_filters( 'modula_album_before_shuffle_galleries', get_post_meta( $album_id, 'modula-album-galleries', true ), $flat );
		$members  = Members_Document::with_repaired_titles( Members_Document::visitor_readable_members( $stored ) );
		$shuffles = self::shuffles_members( $settings );
		if ( $shuffles ) {
			shuffle( $members );
		}

		$entries = self::member_entries( $members, $settings, $flat );
		$shown   = self::within_galleries_to_show( $entries, $settings );
		if ( $shuffles || count( $shown ) < count( $entries ) ) {
			return self::packed_in_order( $shown );
		}

		return $shown;
	}

	/**
	 * Members with no Custom grid position, so the grid packs them in their
	 * order, as the classic album always packs. A shuffled or cut list would
	 * otherwise keep its stored positions: the tiles would not move, or would
	 * leave holes where the cut members sat.
	 *
	 * @param list<array<string, mixed>> $entries Payload members.
	 * @return list<array<string, mixed>>
	 */
	private static function packed_in_order( array $entries ) {
		return array_map(
			static function ( array $entry ) {
				$entry['cell']['gridX'] = '';
				$entry['cell']['gridY'] = '';
				return $entry;
			},
			$entries
		);
	}

	/**
	 * A Slider album ignores the member settings the Albums editor hides for it:
	 * shuffle and "Galleries to show".
	 *
	 * @param array<string, mixed> $settings Album grouped settings.
	 * @return bool
	 */
	private static function is_slider_album( array $settings ) {
		return 'slider' === ( $settings['general']['albumType'] ?? 'grid' );
	}

	/**
	 * "Shuffle galleries and albums": a new member order on each load, as the
	 * classic album shuffles it; not on a Slider album.
	 *
	 * @param array<string, mixed> $settings Album grouped settings.
	 * @return bool
	 */
	private static function shuffles_members( array $settings ) {
		return true === ( $settings['layout']['shuffleGalleries'] ?? false ) && ! self::is_slider_album( $settings );
	}

	/**
	 * "Galleries to show" (0 = all) on a Grid or Custom grid album, as the
	 * classic album counts it: only gallery members count. Merged, the list
	 * stops at the first gallery past the limit, as the classic merged list
	 * does; in separate sections only the galleries are cut. A Slider album
	 * shows every member (the classic album limits Grid and Custom grid only).
	 *
	 * @param list<array<string, mixed>> $entries  Payload members.
	 * @param array<string, mixed>       $settings Album grouped settings.
	 * @return list<array<string, mixed>>
	 */
	private static function within_galleries_to_show( array $entries, array $settings ) {
		$limit = absint( $settings['general']['maxGalleriesCount'] ?? 0 );
		if ( 0 === $limit || self::is_slider_album( $settings ) ) {
			return $entries;
		}

		$is_merged = true === ( $settings['general']['mergeItems'] ?? false );
		$kept      = array();
		$galleries = 0;
		foreach ( $entries as $entry ) {
			if ( 'modula-gallery' !== $entry['itemType'] ) {
				$kept[] = $entry;
				continue;
			}
			if ( $galleries < $limit ) {
				++$galleries;
				$kept[] = $entry;
				continue;
			}
			if ( $is_merged ) {
				break;
			}
		}

		return $kept;
	}

	/**
	 * @param list<array<string, mixed>> $members  Readable stored members, in render order.
	 * @param array<string, mixed>       $settings Album grouped settings.
	 * @param array<string, mixed>       $flat     Album flat settings.
	 * @return list<array<string, mixed>> Payload members; a member with nothing to show is left out.
	 */
	private static function member_entries( array $members, array $settings, array $flat ) {
		$opens_lightbox    = self::opens_lightbox( $settings );
		$back_to_album     = true === ( $settings['navigation']['backToAlbumButton'] ?? false );
		$counts_items      = true === ( $settings['hover']['displayImageCount'] ?? false );
		$draws_cards       = Album_Member_Style::draws_cards( $settings );
		$counts_per_kind   = $counts_items && $draws_cards;
		$downloads_members = self::downloads_members( $settings );

		$entries = array();
		foreach ( $members as $member ) {
			// A readable member has a post ID; the helpers below read it as an int.
			$member['id'] = absint( $member['id'] );
			$entry        = 'modula-album' === ( $member['itemType'] ?? '' )
				? self::album_member( $member, $flat )
				: self::gallery_member( $member, $flat, $opens_lightbox );
			if ( null === $entry ) {
				continue;
			}
			$entry['link']   = self::member_link( $member, $back_to_album );
			$entry['target'] = Members_Document::member_target( $member );
			if ( $counts_items ) {
				$entry['itemCount'] = self::item_count( $entry );
			}
			if ( $counts_per_kind ) {
				// The member card's badge and meta line.
				$entry['counts'] = Album_Member_Counts::for_member( $entry['itemType'], $entry['id'] );
			}
			if ( $draws_cards && 'modula-album' === $entry['itemType'] ) {
				$entry['strip'] = self::strip_thumbnails( $entry['id'], $flat );
			}
			if ( $downloads_members ) {
				// The classic button's link: the member's own ZIP, which its own download settings gate.
				$entry['downloadUrl'] = esc_url_raw( modula_download_req_url( $entry['id'] ) );
			}
			$entries[] = $entry;
		}

		return $entries;
	}

	/**
	 * What "Display image count" shows for a member: a gallery's items as the
	 * Albums editor counts them; a nested album's members a visitor can open,
	 * as the classic album counts them.
	 *
	 * @param array{id: int, itemType: string} $entry Payload member.
	 * @return int|null Null when Lite's gallery counter is missing.
	 */
	private static function item_count( array $entry ) {
		return 'modula-album' === $entry['itemType']
			? modula_get_album_visitor_member_count( $entry['id'] )
			: Members_Document::gallery_item_count( $entry['id'] );
	}

	/**
	 * A gallery member, or null when it has no image to show (the classic album skips it too).
	 *
	 * @param array<string, mixed> $member         Stored member.
	 * @param array<string, mixed> $flat           Album flat settings.
	 * @param bool                 $opens_lightbox Whether the album's lightbox is on.
	 * @return array<string, mixed>|null
	 */
	private static function gallery_member( array $member, array $flat, $opens_lightbox ) {
		$rows   = self::gallery_rows( $member['id'] );
		$images = array_values(
			array_filter(
				$rows,
				static function ( array $row ) {
					return self::is_attachment_row( $row );
				}
			)
		);
		if ( array() === $images ) {
			return null;
		}

		$gallery_settings = self::gallery_settings( $member['id'] );
		$entry            = self::member_entry( $member, 'modula-gallery', self::gallery_cover_id( $member, $images ), $gallery_settings, $flat );
		if ( null === $entry || ! $opens_lightbox ) {
			return $entry;
		}

		$entry['lightboxItems'] = self::lightbox_items( $rows, $gallery_settings, $flat );
		return $entry;
	}

	/**
	 * A nested album member, or null when no cover can be found for it. Its
	 * cover gets Lite's gallery defaults, as the classic album finds no
	 * gallery settings for a nested album.
	 *
	 * @param array<string, mixed> $member Stored member.
	 * @param array<string, mixed> $flat   Album flat settings.
	 * @return array<string, mixed>|null
	 */
	private static function album_member( array $member, array $flat ) {
		return self::member_entry( $member, 'modula-album', modula_get_album_cover_id( $member['id'] ), \Modula_CPT_Fields_Helper::get_defaults(), $flat );
	}

	/**
	 * @param array<string, mixed> $member           Stored member.
	 * @param string               $item_type        `modula-gallery` or `modula-album`.
	 * @param int                  $cover_id         Cover attachment ID.
	 * @param array<string, mixed> $gallery_settings The member's gallery settings (`gallery_settings()`).
	 * @param array<string, mixed> $flat             Album flat settings.
	 * @return array<string, mixed>|null Null when the cover is not an attachment.
	 */
	private static function member_entry( array $member, $item_type, $cover_id, array $gallery_settings, array $flat ) {
		$cover = self::cover( $cover_id, $gallery_settings, $flat );
		if ( null === $cover ) {
			return null;
		}

		return array(
			'id'       => $member['id'],
			'itemType' => $item_type,
			'title'    => (string) ( $member['title'] ?? '' ),
			'caption'  => (string) ( $member['caption'] ?? '' ),
			'alt'      => (string) ( $member['alt'] ?? '' ),
			'cover'    => $cover,
			'cell'     => Members_Document::member_cell( $member ),
			// The gallery item's filter text, which the gallery's filter bar matches.
			'filters'  => Members_Document::member_filters( $member ),
		);
	}

	/**
	 * A gallery's rows as its own renderer reads them, embedded blocks aside
	 * (they have no lightbox file). An attachment row's `id` is an int; a
	 * row without one (a video row) keeps its own.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return list<array<string, mixed>>
	 */
	private static function gallery_rows( $gallery_id ) {
		$images = Beta_Settings::is_beta_gallery( $gallery_id ) ? self::beta_gallery_images( $gallery_id ) : get_post_meta( $gallery_id, 'modula-images', true );
		if ( ! is_array( $images ) ) {
			return array();
		}

		$rows = array();
		foreach ( $images as $image ) {
			if ( ! is_array( $image ) || ! isset( $image['id'] ) || Gallery_Images_Adapter::is_embedded_gallery_item( $image ) ) {
				continue;
			}
			if ( self::is_attachment_row( $image ) ) {
				$image['id'] = (int) $image['id'];
			}
			$rows[] = $image;
		}

		return $rows;
	}

	/**
	 * A Beta gallery's rows, as Lite's visitor gallery reads them: its v2
	 * storage, else the classic list a gallery not yet saved in the new editor keeps.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return array<int, mixed>
	 */
	private static function beta_gallery_images( $gallery_id ) {
		$images = Gallery_Meta_Sync::get_images_v2( $gallery_id );
		if ( is_array( $images ) && array() !== $images ) {
			return $images;
		}

		return Gallery_Meta_Sync::get_gallery_images_with_embedded_fallback( $gallery_id );
	}

	/**
	 * @param array{id: mixed} $image Gallery row (`gallery_rows()`).
	 * @return bool Whether the row is an attachment, by its numeric ID.
	 */
	private static function is_attachment_row( array $image ) {
		// absint() would read a UUID that starts with digits as an attachment ID.
		$id = absint( $image['id'] );
		return $id > 0 && (string) $id === (string) $image['id'];
	}

	/**
	 * The gallery member's cover, as the classic album picks it: a random image
	 * with "Shuffle cover", else the chosen cover, else the first image that exists.
	 *
	 * @param array<string, mixed>       $member Stored member.
	 * @param list<array<string, mixed>> $images Gallery image rows.
	 * @return int Attachment ID, or 0.
	 */
	private static function gallery_cover_id( array $member, array $images ) {
		if ( (bool) ( $member['shuffleCover'] ?? false ) ) {
			return $images[ array_rand( $images ) ]['id'];
		}

		$cover_id = absint( $member['cover'] ?? 0 );
		if ( $cover_id > 0 ) {
			return $cover_id;
		}

		foreach ( $images as $image ) {
			if ( get_post( $image['id'] ) ) {
				return $image['id'];
			}
		}

		return 0;
	}

	/**
	 * The cover at the album's image size, resized as the classic album resizes it.
	 *
	 * @param int                  $attachment_id    Cover attachment ID.
	 * @param array<string, mixed> $gallery_settings The member's gallery settings.
	 * @param array<string, mixed> $flat             Album flat settings.
	 * @return array{id: int, src: string, width: int, height: int, full: string, srcset: string, sizes: string}|null
	 */
	private static function cover( $attachment_id, array $gallery_settings, array $flat ) {
		if ( $attachment_id < 1 || 'attachment' !== get_post_type( $attachment_id ) ) {
			return null;
		}

		$sized = modula_album_generate_image_links( array(), array( 'id' => $attachment_id ), array(), $flat );
		$cover = array(
			'id'     => $attachment_id,
			'src'    => (string) $sized['img_attributes']['src'],
			'width'  => absint( $sized['img_attributes']['width'] ),
			'height' => absint( $sized['img_attributes']['height'] ),
			'full'   => (string) $sized['image_full'],
		);
		/**
		 * Filters the files of a Beta album member's cover, before Image Guardian's rule: Speedup optimizes it here.
		 *
		 * @param array{id: int, src: string, width: int, height: int, full: string} $cover            The cover at the album's image size.
		 * @param array<string, mixed>                                               $gallery_settings The member's gallery settings; Lite's defaults for a nested album.
		 * @param array<string, mixed>                                               $flat             Album flat settings.
		 */
		$cover = self::with_text_fields( $cover, apply_filters( 'modula_album_visitor_cover', $cover, $gallery_settings, $flat ), array( 'src', 'full' ) );

		$urls          = self::guarded_urls(
			$attachment_id,
			array(
				'src'        => $cover['src'],
				'image_full' => $cover['full'],
			),
			$flat
		);
		$cover['src']  = $urls['src'];
		$cover['full'] = $urls['image_full'];

		// From the final address, as the classic item template: core finds no srcset for a protected or optimized one.
		return $cover + self::cover_sources( $cover, $sized['image_info'] ?? false );
	}

	/**
	 * A nested album card's thumbnail strip (album-member-card ticket 03): its
	 * strip covers (`Album_Member_Strip`) at thumbnail size, each through the
	 * member-cover filter and Image Guardian's rule, as the member cover is.
	 *
	 * @param int                  $album_id Nested album ID.
	 * @param array<string, mixed> $flat     Album flat settings.
	 * @return list<array{id: int, src: string}> Empty for no strip.
	 */
	private static function strip_thumbnails( $album_id, array $flat ) {
		$thumbnails = array();
		foreach ( Album_Member_Strip::cover_ids( $album_id ) as $attachment_id ) {
			$src = wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
			if ( ! is_string( $src ) || '' === $src ) {
				continue;
			}
			$thumbnail = array(
				'id'     => $attachment_id,
				'src'    => $src,
				'width'  => 0,
				'height' => 0,
				'full'   => $src,
			);
			/** This filter is documented in cover(). */
			$thumbnail = self::with_text_fields( $thumbnail, apply_filters( 'modula_album_visitor_cover', $thumbnail, \Modula_CPT_Fields_Helper::get_defaults(), $flat ), array( 'src', 'full' ) );

			$urls         = self::guarded_urls(
				$attachment_id,
				array(
					'src'        => $thumbnail['src'],
					'image_full' => $thumbnail['full'],
				),
				$flat
			);
			$thumbnails[] = array(
				'id'  => $attachment_id,
				'src' => $urls['src'],
			);
		}
		return $thumbnails;
	}

	/**
	 * What a filter returned, as text, under the keys a caller takes from it.
	 *
	 * @param array<string, mixed> $values   The values the filter was given.
	 * @param mixed                $filtered What it returned.
	 * @param list<string>         $keys     The keys a callback may set.
	 * @return array<string, mixed> The values, with each key the callback set to text; anything else it returned is left out.
	 */
	private static function with_text_fields( array $values, $filtered, array $keys ) {
		if ( ! is_array( $filtered ) ) {
			return $values;
		}

		foreach ( $keys as $key ) {
			if ( isset( $filtered[ $key ] ) && is_string( $filtered[ $key ] ) ) {
				$values[ $key ] = $filtered[ $key ];
			}
		}
		return $values;
	}

	/**
	 * An image's file addresses as visitors get them. Image Guardian hooks the
	 * filter as it hooks the classic album's `modula_album_shortcode_item_data`:
	 * "Hide the real file address" swaps them for its protected endpoint, and
	 * right-click or blur protection marks them `mip=1`.
	 *
	 * @param int                   $attachment_id Attachment ID; 0 for a row without one.
	 * @param array<string, string> $urls          Addresses under the classic item's keys (`src`, `image_full`, `data-thumb`).
	 * @param array<string, mixed>  $flat          Album flat settings.
	 * @return array<string, string> The same keys; an address a callback drops or breaks stays as it was.
	 */
	private static function guarded_urls( $attachment_id, array $urls, array $flat ) {
		/**
		 * Filters the file addresses of one image a Beta album shows: a member's cover, or an image in its lightbox.
		 *
		 * @param array<string, string> $urls  Addresses under the classic item's keys (`src`, `image_full`, `data-thumb`).
		 * @param array{id: int}        $image The attachment; ID 0 for a lightbox row without one.
		 * @param array<string, mixed>  $flat  Album flat settings.
		 */
		$guarded = apply_filters( 'modula_album_visitor_image_urls', $urls, array( 'id' => $attachment_id ), $flat );
		return self::with_text_fields( $urls, $guarded, array_keys( $urls ) );
	}

	/**
	 * The cover's responsive sources, as the classic album's item template adds
	 * them (`wp_image_add_srcset_and_sizes()`): the attachment's sizes, and the
	 * cover itself when Modula resized it. None while Troubleshooting turns
	 * srcset off.
	 *
	 * @param array{id: int, src: string, width: int, height: int} $cover      Sized cover.
	 * @param array<string, string>|false                         $image_info Parts of the file Modula resized (`name`, `suffix`, `ext`), else false.
	 * @return array{srcset: string, sizes: string}
	 */
	private static function cover_sources( array $cover, $image_info ) {
		$none = array(
			'srcset' => '',
			'sizes'  => '',
		);
		if ( self::is_srcset_disabled() ) {
			return $none;
		}

		$meta = wp_get_attachment_metadata( $cover['id'] );
		$meta = is_array( $meta ) ? $meta : array();
		if ( ! isset( $meta['sizes'] ) || ! is_array( $meta['sizes'] ) ) {
			$meta['sizes'] = array();
		}
		if ( is_array( $image_info ) ) {
			$mime = $meta['sizes']['thumbnail']['mime-type'] ?? get_post_mime_type( $cover['id'] );

			$meta['sizes']['custom'] = array(
				'file'      => "{$image_info['name']}-{$image_info['suffix']}.{$image_info['ext']}",
				'width'     => $cover['width'],
				'height'    => $cover['height'],
				'mime-type' => (string) $mime,
			);
		}

		// As core does for an <img>: the srcset matches the file without its query.
		list( $src ) = explode( '?', $cover['src'] );
		$size_array  = array( $cover['width'], $cover['height'] );
		$srcset      = wp_calculate_image_srcset( $size_array, $src, $meta, $cover['id'] );
		if ( ! is_string( $srcset ) || '' === $srcset ) {
			return $none;
		}

		$sizes = wp_calculate_image_sizes( $size_array, $src, $meta, $cover['id'] );
		return array(
			'srcset' => $srcset,
			'sizes'  => is_string( $sizes ) ? $sizes : '',
		);
	}

	/**
	 * Troubleshooting › Disable srcset, or the albums' old "Remove srcset",
	 * which the classic album reads as the same switch.
	 *
	 * @return bool
	 */
	private static function is_srcset_disabled() {
		$options = get_option( 'modula_troubleshooting_option', array() );
		if ( ! is_array( $options ) ) {
			return false;
		}

		// As the classic templates read them: `remove_srcset` only as '1'; `disable_srcset`
		// loosely (`false == $remove_srcset` there), so '0', '' and a missing key keep the srcset.
		return '1' === ( $options['remove_srcset'] ?? '' ) || ! empty( $options['disable_srcset'] );
	}

	/**
	 * A gallery's rows as the gallery lightbox reads them, as the classic
	 * album passes each through `modula_album_lightbox_item`: what the album
	 * reads of it (`row_item()`), then what the extensions add (Video, EXIF,
	 * Image licensing, Speedup), then Image Guardian's address rule, which
	 * ran last on the classic album too. A row left with no file to show
	 * stays out: a deleted attachment, or a video row with the Video
	 * extension off.
	 *
	 * @param list<array<string, mixed>> $rows             Gallery rows (`gallery_rows()`).
	 * @param array<string, mixed>       $gallery_settings The gallery's settings (`gallery_settings()`).
	 * @param array<string, mixed>       $flat             Album flat settings.
	 * @return list<array<string, mixed>>
	 */
	private static function lightbox_items( array $rows, array $gallery_settings, array $flat ) {
		$items = array();
		foreach ( $rows as $row ) {
			$item = self::row_item( $row );
			/**
			 * Filters one row of a Beta album member's lightbox, as `modula_album_lightbox_item` filters the classic album's.
			 *
			 * @param array<string, string|int> $item             `{ id, url, thumbnail, title, description, alt }`; a callback may set `LIGHTBOX_ITEM_FIELDS`, as text.
			 * @param array<string, mixed>      $row              The gallery row.
			 * @param array<string, mixed>      $gallery_settings The gallery's settings.
			 * @param array<string, mixed>      $flat             Album flat settings.
			 */
			$item = self::with_text_fields( $item, apply_filters( 'modula_album_visitor_lightbox_item', $item, $row, $gallery_settings, $flat ), self::LIGHTBOX_ITEM_FIELDS );
			if ( '' === $item['url'] ) {
				continue;
			}

			$urls              = self::guarded_urls(
				self::is_attachment_row( $row ) ? $row['id'] : 0,
				array(
					'src'        => $item['url'],
					'data-thumb' => $item['thumbnail'],
				),
				$flat
			);
			$item['url']       = $urls['src'];
			$item['thumbnail'] = $urls['data-thumb'];
			$items[]           = $item;
		}

		return $items;
	}

	/**
	 * What the album reads of a row, with the classic album's sources: an
	 * attachment's original file, its thumbnail, and its title and caption.
	 *
	 * @param array<string, mixed> $row Gallery row.
	 * @return array{id: int|string, url: string, thumbnail: string, title: string, description: string, alt: string} No file or text for a row without an attachment, or whose attachment was deleted from the media library.
	 */
	private static function row_item( array $row ) {
		$item = array(
			'id'          => $row['id'],
			'url'         => '',
			'thumbnail'   => '',
			'title'       => '',
			'description' => '',
			'alt'         => (string) ( $row['alt'] ?? '' ),
		);
		if ( ! self::is_attachment_row( $row ) ) {
			return $item;
		}
		$url = self::original_image_url( $row['id'] );
		if ( '' === $url ) {
			return $item;
		}

		$thumbnail = wp_get_attachment_image_url( $row['id'] );
		return array_merge(
			$item,
			array(
				'url'         => $url,
				'thumbnail'   => is_string( $thumbnail ) ? $thumbnail : $url,
				// Raw text: the lightbox escapes its caption.
				'title'       => (string) get_post_field( 'post_title', $row['id'] ),
				'description' => self::row_caption( $row ),
			)
		);
	}

	/**
	 * An attachment row's caption as its Beta gallery shows it: Lite's rule,
	 * the Media Library Caption, else the caption cached on the row.
	 *
	 * @param array<string, mixed> $row Gallery row of an attachment.
	 * @return string
	 */
	private static function row_caption( array $row ) {
		$media_library_caption = (string) get_post_field( 'post_excerpt', $row['id'] );
		// Lite added the resolver in 3.0.18, after Lite_Requirement::MINIMUM_VERSION (3.0.17); an older Lite keeps the Media Library Caption alone.
		if ( ! function_exists( 'modula_resolve_gallery_item_caption' ) ) {
			return $media_library_caption;
		}

		return modula_resolve_gallery_item_caption( $media_library_caption, $row['description'] ?? '' );
	}

	/**
	 * @param int $attachment_id Attachment ID.
	 * @return string The original image's URL, or '' when the attachment has none.
	 */
	private static function original_image_url( $attachment_id ) {
		$mime = get_post_mime_type( $attachment_id );
		// Browsers can't show a HEIC/HEIF original; its full-size derivative is a JPEG (as the classic album).
		if ( 'image/heic' === $mime || 'image/heif' === $mime ) {
			$full = wp_get_attachment_image_src( $attachment_id, 'full' );
			return is_array( $full ) ? (string) $full[0] : '';
		}

		$url = wp_get_original_image_url( $attachment_id );
		return is_string( $url ) ? $url : '';
	}

	/**
	 * What a member follows when it does not open in the lightbox, as the
	 * classic album links it: its custom URL, else its public page.
	 *
	 * @param array<string, mixed> $member        Stored member.
	 * @param bool                 $back_to_album Whether the album shows "Back to album" on member pages.
	 * @return string
	 */
	private static function member_link( array $member, $back_to_album ) {
		$custom_url = trim( (string) ( $member['customurl'] ?? '' ) );
		if ( '' !== $custom_url ) {
			return esc_url_raw( $custom_url );
		}

		$url = modula_album_member_public_url( $member['id'] );
		if ( '' === $url || ! $back_to_album ) {
			return $url;
		}

		return add_query_arg( 'back_to_album', 1, $url );
	}
}
