<?php
/**
 * [modula-album] dispatcher: a Beta album → Album visitor frontend; otherwise the classic album.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Visitor;

use Modula\V2\Beta_Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Chooses the album renderer as Lite's [modula] dispatcher does for galleries (ADR 0052).
 * The block, Elementor and Beaver integrations call the shortcode, so they follow.
 */
final class Dispatcher {

	/**
	 * Rollout gate added while the Album visitor frontend was built (album-frontend ticket 01).
	 * On by default since the parity ticket (12); a callback returning false keeps a Beta album classic.
	 */
	public const GATE_FILTER = 'modula_album_visitor_frontend';

	/**
	 * Classic album shortcode (`album_shortcode_handler()`); not changed.
	 *
	 * @var object
	 */
	private $classic;

	/**
	 * Album visitor frontend renderer (`render()`).
	 *
	 * @var object
	 */
	private $visitor;

	/**
	 * Register [modula-album], replacing the classic album's registration of the tag.
	 *
	 * @param object $classic Classic album shortcode.
	 * @param object $visitor Album visitor frontend renderer.
	 */
	public function __construct( $classic, $visitor ) {
		$this->classic = $classic;
		$this->visitor = $visitor;

		add_shortcode( 'modula-album', array( $this, 'render' ) );

		// Early enqueue, as for galleries, so page caches and builders that print the head first still get the assets.
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_visitor_assets_early' ), 20 );
	}

	/**
	 * Enqueue the Album visitor frontend's assets in the head when the singular
	 * post is a Beta album (its standalone page) or embeds one with [modula-album].
	 *
	 * @return void
	 */
	public static function maybe_enqueue_visitor_assets_early() {
		if ( ! is_singular() ) {
			return;
		}

		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return;
		}

		if ( self::uses_visitor_frontend( (int) $post->ID ) || self::embeds_visitor_album( (string) $post->post_content ) ) {
			Renderer::enqueue_assets();
		}
	}

	/**
	 * @param string $content Post content.
	 * @return bool Whether a [modula-album] in it renders with the Album visitor frontend.
	 */
	private static function embeds_visitor_album( $content ) {
		if ( '' === $content || ! has_shortcode( $content, 'modula-album' ) ) {
			return false;
		}
		if ( ! preg_match_all( '/' . get_shortcode_regex( array( 'modula-album' ) ) . '/s', $content, $matches ) ) {
			return false;
		}

		foreach ( $matches[3] as $atts_string ) {
			$atts = shortcode_parse_atts( $atts_string );
			if ( is_array( $atts ) && ! empty( $atts['id'] ) && self::uses_visitor_frontend( absint( $atts['id'] ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether visitors see this album with the Album visitor frontend.
	 *
	 * Only a stored `_modula_beta` switches the visitor, as for the Albums
	 * editor; no filter makes an album Beta (Lite ADR 0054).
	 *
	 * @param int $album_id Album post ID.
	 * @return bool
	 */
	public static function uses_visitor_frontend( $album_id ) {
		$album_id = absint( $album_id );
		if ( ! Beta_Settings::is_stored_beta_album( $album_id ) ) {
			return false;
		}

		/**
		 * Whether a Beta album renders with the Album visitor frontend.
		 *
		 * @param bool $enabled  Default true; false keeps the classic album.
		 * @param int  $album_id Album post ID.
		 */
		return (bool) apply_filters( self::GATE_FILTER, true, $album_id ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- GATE_FILTER is the prefixed `modula_album_visitor_frontend`.
	}

	/**
	 * Route by the album's stored Beta flag.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes, passed on as they came.
	 * @return string
	 */
	public function render( $atts ) {
		$album_id = is_array( $atts ) && isset( $atts['id'] ) ? absint( $atts['id'] ) : 0;
		if ( self::uses_visitor_frontend( $album_id ) ) {
			return $this->visitor->render( $atts );
		}

		return $this->classic->album_shortcode_handler( $atts );
	}
}
