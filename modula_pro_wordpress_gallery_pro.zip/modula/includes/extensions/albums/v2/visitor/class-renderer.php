<?php
/**
 * Album visitor frontend renderer: the [modula-album] output of a Beta album.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Visitor;

use Modula\V2\Modern_Gallery;
use Modula_Pro\Extensions\Albums\V2\Album_Motion;
use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Albums\V2\Members_Document;

defined( 'ABSPATH' ) || exit;

/**
 * Prints the album shell with its bootstrap JSON and enqueues the visitor
 * bundle, as Lite's visitor gallery prints its shell; the render is client-only.
 */
final class Renderer {

	/**
	 * Script handle of the visitor bundle.
	 */
	public const SCRIPT_HANDLE = 'modula-album-visitor';

	/**
	 * Style handle of the visitor bundle's own stylesheet.
	 */
	public const STYLE_HANDLE = 'modula-album-visitor';

	/**
	 * Built bundle, relative to the plugin root (`npm run build:album-visitor`).
	 */
	private const BUNDLE_DIR = 'includes/extensions/albums/public/album-visitor';

	/**
	 * The dispatcher calls this for a Beta album only.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes (`id`, `align`).
	 * @return string
	 */
	public function render( $atts ) {
		$atts     = wp_parse_args(
			is_array( $atts ) ? $atts : array(),
			array(
				'id'    => 0,
				'align' => '',
			)
		);
		$album_id = absint( $atts['id'] );

		// As for the classic album: a private or draft album stays hidden from visitors who can't read it.
		if ( ! Members_Document::is_visitor_readable_album( $album_id ) ) {
			return esc_html__( 'This album is not published.', 'modula-pro' );
		}

		/** This filter is documented in the classic album shortcode. */
		$flat = apply_filters( 'modula_albums_backwards_compatibility_front', modula_albums_get_album_settings( $album_id ) );

		// Password protection prints its own form here, as it does for the classic album.
		if ( false !== apply_filters( 'modula_albums_pre_output_filter_check', false, $flat, $album_id ) ) {
			return apply_filters( 'modula_albums_pre_output_filter', '', $flat, $album_id );
		}

		$flat    = wp_parse_args( $flat, Fields_Helper::get_defaults() );
		$payload = Payload::build( $album_id, $flat );
		if ( array() === $payload['members'] ) {
			return esc_html__( 'There are no items to display.', 'modula-pro' );
		}

		if ( ! self::enqueue_assets() ) {
			return '<div class="modula-album-visitor modula-gallery-bootstrap-error" role="alert">'
				. esc_html__( 'This album could not load its display scripts. Clear any page or CDN cache, then reload. If it continues, reinstall Modula or contact support.', 'modula-pro' )
				. '</div>';
		}

		/**
		 * Fires as a Beta album renders with the Album visitor frontend, as
		 * `modula_album_extra_scripts` fires for the classic album and Lite's
		 * visitor gallery fires `modula_extra_scripts`. An extension whose album
		 * assets serve the new frontend hooks it (the download extension's
		 * ZIP progress); the classic hook's other callbacks load the classic
		 * album's own scripts, so it is not fired here.
		 *
		 * @param array<string, mixed> $flat Album flat settings with their defaults.
		 */
		do_action( 'modula_album_visitor_extra_scripts', $flat );
		// The bundle binds each tile of a classic Tilt effect to its runtime (`TiltFx`).
		if ( Album_Motion::plays_classic_tilt( $payload['settings'] ) ) {
			wp_enqueue_script( 'modula-pro-tilt' );
		}
		// The bundle prints "Back to album" in the classic button's markup, with its stylesheet.
		if ( '' !== $payload['navigation']['backToAlbumUrl'] ) {
			modula_enqueue_back_to_album_style();
		}

		return self::shell( $album_id, (string) $atts['align'], $payload );
	}

	/**
	 * Enqueue the visitor bundle and the gallery visitor stylesheets it renders with.
	 *
	 * @return bool False when a bundle is not built.
	 */
	public static function enqueue_assets() {
		$asset_path = MODULA_PRO_PATH . self::BUNDLE_DIR . '/index.asset.php';
		if ( ! file_exists( $asset_path ) || ! Modern_Gallery::visitor_renderer_assets_available() ) {
			return false;
		}

		// The gallery's stylesheets only: this bundle mounts the album, not the gallery's loader.
		Modern_Gallery::enqueue_visitor_stylesheets();

		$asset = require $asset_path;
		// The album's own styles (the image count), built with the bundle.
		wp_enqueue_style(
			self::STYLE_HANDLE,
			MODULA_PRO_URL . self::BUNDLE_DIR . '/index.css',
			array(),
			$asset['version']
		);
		wp_style_add_data( self::STYLE_HANDLE, 'rtl', 'replace' );
		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			MODULA_PRO_URL . self::BUNDLE_DIR . '/index.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);
		wp_set_script_translations( self::SCRIPT_HANDLE, 'modula-pro', MODULA_PRO_PATH . 'languages' );

		return true;
	}

	/**
	 * @param int                  $album_id Album post ID.
	 * @param string               $align    Shortcode `align` (block alignment).
	 * @param array<string, mixed> $payload  Album bootstrap (Payload::build()).
	 * @return string
	 */
	private static function shell( $album_id, $align, array $payload ) {
		$classes = array( 'modula-album-visitor' );
		if ( '' !== $align ) {
			$classes[] = 'align' . sanitize_html_class( $align );
		}

		return sprintf(
			'<div id="%1$s" class="%2$s" data-modula-album-visitor><script type="application/json">%3$s</script></div>',
			esc_attr( 'jtg-album-' . $album_id ),
			esc_attr( implode( ' ', $classes ) ),
			// HEX_TAG: a member title with a literal </script> must not close the tag early.
			wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG )
		);
	}
}
