<?php
/**
 * Bridge album.persist failures to Lite Modula Debug Log.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Debug_Log
 */
class Debug_Log {

	/**
	 * Log an album.persist failure when Lite Modula Debug Log is available.
	 *
	 * @param int    $album_id   Album id.
	 * @param string $error_code Error code.
	 * @param string $message    Message.
	 * @param string $resource   Route resource (settings|members).
	 * @return void
	 */
	public static function log_persist_failure( $album_id, $error_code, $message, $resource = 'settings' ) {
		if ( ! class_exists( 'Modula_Debug_Log' ) || ! is_callable( array( 'Modula_Debug_Log', 'log_failure' ) ) ) {
			return;
		}

		$channel = 'album.persist';
		if ( defined( 'Modula_Debug_Log::CHANNEL_ALBUM_PERSIST' ) ) {
			$channel = \Modula_Debug_Log::CHANNEL_ALBUM_PERSIST;
		}

		\Modula_Debug_Log::log_failure(
			$channel,
			$message,
			array(
				'album_id'   => (int) $album_id,
				'route'      => '/modula/v2/album/' . (int) $album_id . '/' . sanitize_key( $resource ),
				'error_code' => (string) $error_code,
			)
		);
	}
}
