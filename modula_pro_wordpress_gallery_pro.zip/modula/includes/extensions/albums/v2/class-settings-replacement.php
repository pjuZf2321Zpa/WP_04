<?php
/**
 * Capability-checked album settings replacement (Apply preset / parent-children).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Replacement
 *
 * Full replace of schema-owned grouped settings while preserving album members
 * (callers never touch members meta), opaque flat keys (via Meta_Sync), and
 * password protection when the source omits an explicit protection change.
 */
class Settings_Replacement {

	/**
	 * Flat keys that mark an explicit Password Protect change on a legacy preset.
	 *
	 * @var string[]
	 */
	const PROTECTION_FLAT_KEYS = array(
		'enable_password',
		'password',
		'password_protect_username',
		'password_protect_text',
	);

	/**
	 * Replace album grouped settings from a source document.
	 *
	 * @param int                                 $album_id        Album post ID.
	 * @param array<string, array<string, mixed>> $source_grouped  Source grouped settings (sparse omit OK).
	 * @param array<string, mixed>                $args {
	 *     Optional.
	 *
	 *     @type bool $require_capability When true (default), require edit_post.
	 * }
	 * @return array<string, array<string, mixed>>|\WP_Error Sanitized grouped settings.
	 */
	public static function replace_grouped( $album_id, array $source_grouped, array $args = array() ) {
		$album_id = absint( $album_id );
		if ( ! $album_id || 'modula-album' !== get_post_type( $album_id ) ) {
			return new \WP_Error(
				'modula_invalid_album',
				__( 'Invalid album.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$require_capability = ! array_key_exists( 'require_capability', $args ) || ! empty( $args['require_capability'] );
		if ( $require_capability && ! current_user_can( 'edit_post', $album_id ) ) {
			return new \WP_Error(
				'modula_forbidden',
				__( 'Sorry, you are not allowed to edit this album.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}

		// Open/migrate path: ensure passwordProtect and other owned groups exist
		// from flat before omit-vs-replace decisions.
		Meta_Sync::ensure_settings_v2_from_flat( $album_id );

		$existing            = Meta_Sync::get_settings_v2( $album_id );
		$protection_omitted  = ! array_key_exists( 'passwordProtect', $source_grouped );
		$incoming_for_action = $source_grouped;
		$to_sanitize         = $source_grouped;

		if ( $protection_omitted && isset( $existing['passwordProtect'] ) && is_array( $existing['passwordProtect'] ) ) {
			$to_sanitize['passwordProtect'] = $existing['passwordProtect'];
		}

		$sanitized = Sanitizer::sanitize_grouped( $to_sanitize );
		Meta_Sync::save_settings_v2( $album_id, $sanitized );

		$flat = get_post_meta( $album_id, Meta_Sync::FLAT_META_KEY, true );

		/**
		 * Fires after album settings are replaced (Apply preset / parent-children).
		 *
		 * @param int                                 $album_id  Album post ID.
		 * @param array<string, array<string, mixed>> $sanitized Grouped v2 settings.
		 * @param array<string, mixed>                $flat      Flat modula-album-settings.
		 * @param array<string, mixed>                $incoming  Source groups (omit vs explicit).
		 */
		do_action(
			'modula_album_settings_v2_updated',
			$album_id,
			$sanitized,
			is_array( $flat ) ? $flat : array(),
			$incoming_for_action
		);

		return $sanitized;
	}

	/**
	 * Whether a flat album-settings bag carries an explicit protection change.
	 *
	 * @param array<string, mixed> $flat Flat settings.
	 * @return bool
	 */
	public static function flat_carries_explicit_protection( array $flat ) {
		foreach ( self::PROTECTION_FLAT_KEYS as $key ) {
			if ( array_key_exists( $key, $flat ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether a grouped passwordProtect bag is an explicit protection change
	 * (enable, password value, or disable with keys present beyond schema defaults).
	 *
	 * Default-off empty password is treated as omit for v2-only presets.
	 *
	 * @param array<string, mixed> $password_protect Grouped passwordProtect keys.
	 * @return bool
	 */
	public static function grouped_carries_explicit_protection( array $password_protect ) {
		$enabled  = ! empty( $password_protect['enablePassword'] );
		$password = isset( $password_protect['password'] )
			? (string) $password_protect['password']
			: '';
		return $enabled || '' !== $password;
	}
}
