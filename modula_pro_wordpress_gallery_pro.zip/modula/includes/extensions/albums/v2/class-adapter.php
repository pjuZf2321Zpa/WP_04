<?php
/**
 * Flat modula-album-settings ↔ grouped album settings v2.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

use Modula\V2\Settings\Adapter as Gallery_Adapter;

defined( 'ABSPATH' ) || exit;

/**
 * Class Adapter
 */
class Adapter {

	/** @var array<string, string>|null */
	private static $grouped_to_flat = null;

	/**
	 * @return array<string, string>
	 */
	private static function get_grouped_to_flat() {
		if ( null !== self::$grouped_to_flat ) {
			return self::$grouped_to_flat;
		}
		self::$grouped_to_flat = array();
		foreach ( Field_Registry::get_flat_to_grouped_mapping() as $flat => $entry ) {
			self::$grouped_to_flat[ $entry['group'] . '.' . $entry['key'] ] = $flat;
		}
		return self::$grouped_to_flat;
	}

	/**
	 * Schema definition of the grouped field a flat legacy key maps to.
	 *
	 * @param string $flat_key Flat modula-album-settings key.
	 * @return array<string, mixed>|null Definition (empty when the field has none); null when the flat key is unmapped.
	 */
	private static function get_definition_for_flat_key( $flat_key ) {
		$map = Field_Registry::get_flat_to_grouped_mapping();
		if ( ! isset( $map[ $flat_key ] ) || ! is_array( $map[ $flat_key ] ) ) {
			return null;
		}
		$entry  = $map[ $flat_key ];
		$group  = isset( $entry['group'] ) ? $entry['group'] : '';
		$key    = isset( $entry['key'] ) ? $entry['key'] : '';
		$schema = Registry::get_schema();
		return isset( $schema[ $group ][ $key ] ) && is_array( $schema[ $group ][ $key ] ) ? $schema[ $group ][ $key ] : array();
	}

	/**
	 * Declared schema type for a flat legacy key.
	 *
	 * @param string $flat_key Flat modula-album-settings key.
	 * @return string|null Schema type when mapped; null when the flat key is unmapped.
	 */
	private static function get_type_for_flat_key( $flat_key ) {
		$def = self::get_definition_for_flat_key( $flat_key );
		if ( null === $def ) {
			return null;
		}
		if ( ! isset( $def['type'] ) || ! is_string( $def['type'] ) || '' === $def['type'] ) {
			return 'string';
		}
		return $def['type'];
	}

	/**
	 * Convert a legacy flat value into the grouped representation for its type.
	 *
	 * Conversion is owned by the field's declared schema type — never by a
	 * global zero/one heuristic that would turn numeric `'1'` into `true`.
	 *
	 * @param mixed  $value    Raw flat value.
	 * @param string $flat_key Flat key (used to resolve schema type).
	 * @return mixed
	 */
	private static function normalize_for_grouped( $value, $flat_key ) {
		if ( '' === $value || null === $value ) {
			return $value;
		}
		// Filter names such as `007` stay text: the gallery's rule.
		if ( Gallery_Adapter::keeps_text_list_as_stored( self::get_definition_for_flat_key( $flat_key ) ) ) {
			return $value;
		}
		if ( is_array( $value ) ) {
			return array_map(
				function ( $v ) use ( $flat_key ) {
					return self::normalize_for_grouped( $v, $flat_key );
				},
				$value
			);
		}
		if ( is_object( $value ) ) {
			return $value;
		}

		$type = self::get_type_for_flat_key( $flat_key );

		if ( 'boolean' === $type ) {
			if ( true === $value || false === $value ) {
				return (bool) $value;
			}
			if ( 1 === $value || 0 === $value || '1' === $value || '0' === $value ) {
				return 1 === $value || '1' === $value;
			}
			return (bool) $value;
		}

		if ( 'integer' === $type || 'number' === $type ) {
			if ( true === $value || false === $value ) {
				return $value ? 1 : 0;
			}
			$str = is_string( $value ) ? $value : (string) $value;
			if ( is_numeric( $str ) ) {
				return (int) $str;
			}
			return $value;
		}

		if ( 'string' === $type ) {
			if ( true === $value || false === $value ) {
				return $value ? '1' : '0';
			}
			return is_scalar( $value ) ? (string) $value : $value;
		}

		// Unmapped or unsupported type: preserve prior best-effort numeric cast
		// without treating every '0'/'1' string as a boolean.
		if ( true === $value || false === $value ) {
			return (bool) $value;
		}
		$str = is_string( $value ) ? $value : (string) $value;
		if ( is_numeric( $str ) && false === strpos( $str, '.' ) ) {
			return (int) $str;
		}
		return $value;
	}

	/**
	 * Project a grouped value back to the flat shape expected by classic consumers.
	 *
	 * Boolean fields emit legacy `'0'`/`'1'` strings so strict comparisons such as
	 * `'1' === $settings['lazy_load']` keep working.
	 *
	 * @param mixed  $value    Grouped value.
	 * @param string $flat_key Flat key (used to resolve schema type).
	 * @return mixed
	 */
	private static function normalize_for_flat( $value, $flat_key ) {
		$type = self::get_type_for_flat_key( $flat_key );
		if ( 'boolean' !== $type ) {
			return $value;
		}
		if ( true === $value || 1 === $value || '1' === $value ) {
			return '1';
		}
		if ( false === $value || 0 === $value || '0' === $value ) {
			return '0';
		}
		return rest_sanitize_boolean( $value ) ? '1' : '0';
	}

	/**
	 * @param mixed $value
	 * @return array{width: int, height: int}
	 */
	public static function normalize_width_height_object( $value ) {
		if ( is_array( $value ) && isset( $value['width'], $value['height'] ) ) {
			return array(
				'width'  => absint( $value['width'] ),
				'height' => absint( $value['height'] ),
			);
		}
		if ( is_array( $value ) && array_key_exists( 0, $value ) && array_key_exists( 1, $value ) ) {
			return array(
				'width'  => absint( $value[0] ),
				'height' => absint( $value[1] ),
			);
		}
		return array(
			'width'  => 0,
			'height' => 0,
		);
	}

	/**
	 * Convert flat legacy settings to grouped v2.
	 *
	 * When `$options['legacy_import']` is true, absent keys are filled from effective
	 * classic album defaults before conversion so opening an existing album does not
	 * adopt new-album schema defaults (cursor, padding, colors, title font size, …).
	 * Omit that flag for brand-new albums so {@see fill_schema_defaults()} applies.
	 *
	 * @param array<string, mixed> $flat    Flat modula-album-settings.
	 * @param array<string, mixed> $options {
	 *     Optional. Conversion options.
	 *
	 *     @type bool $legacy_import   When true, merge classic defaults under `$flat`.
	 *     @type bool $schema_defaults When false, do not fill missing schema keys
	 *                                 (used for sparse preset source documents).
	 * }
	 * @return array<string, array<string, mixed>>
	 */
	public static function to_grouped( array $flat, array $options = array() ) {
		if ( ! empty( $options['legacy_import'] ) ) {
			$flat = array_merge( self::get_flat_defaults(), $flat );
		}

		$grouped  = array();
		$flat_map = Field_Registry::get_flat_to_grouped_mapping();
		foreach ( $flat as $flat_key => $value ) {
			if ( ! isset( $flat_map[ $flat_key ] ) ) {
				continue;
			}
			$entry = $flat_map[ $flat_key ];
			$g     = $entry['group'];
			$k     = $entry['key'];
			if ( ! isset( $grouped[ $g ] ) ) {
				$grouped[ $g ] = array();
			}
			if ( 'image_dimensions' === $flat_key ) {
				$grouped[ $g ][ $k ] = self::normalize_width_height_object( $value );
			} else {
				$grouped[ $g ][ $k ] = self::normalize_for_grouped( $value, $flat_key );
			}
		}
		// A classic flat document (a classic save, an older preset) predates the
		// Motion keys: they play its classic effect, not the new-album `auto`.
		$grouped = Album_Motion::with_existing_album_values( $grouped );
		if ( ! array_key_exists( 'schema_defaults', $options ) || ! empty( $options['schema_defaults'] ) ) {
			self::fill_schema_defaults( $grouped );
		}
		return $grouped;
	}

	/**
	 * @param array<string, array<string, mixed>> $grouped
	 * @return array<string, mixed>
	 */
	public static function to_flat( array $grouped ) {
		$flat     = array();
		$reverse  = self::get_grouped_to_flat();
		$defaults = self::get_flat_defaults();
		foreach ( $grouped as $group => $keys ) {
			if ( ! is_array( $keys ) ) {
				continue;
			}
			foreach ( $keys as $key => $value ) {
				$path = $group . '.' . $key;
				if ( ! isset( $reverse[ $path ] ) ) {
					continue;
				}
				$flat_key = $reverse[ $path ];
				if ( 'image_dimensions' === $flat_key ) {
					$flat[ $flat_key ] = self::normalize_width_height_object( $value );
				} else {
					$flat[ $flat_key ] = self::normalize_for_flat( $value, $flat_key );
				}
			}
		}
		return array_merge( $defaults, $flat );
	}

	/**
	 * Grouped settings with each missing schema key at its default, as the
	 * Album visitor frontend reads them.
	 *
	 * @param array<string, array<string, mixed>> $grouped Stored grouped settings.
	 * @return array<string, array<string, mixed>>
	 */
	public static function with_schema_defaults( array $grouped ) {
		self::fill_schema_defaults( $grouped );
		return $grouped;
	}

	/**
	 * @param array<string, array<string, mixed>> $grouped
	 * @return void
	 */
	private static function fill_schema_defaults( array &$grouped ) {
		$schema = Registry::get_schema();
		foreach ( $schema as $group => $fields ) {
			if ( ! is_array( $fields ) ) {
				continue;
			}
			if ( ! isset( $grouped[ $group ] ) || ! is_array( $grouped[ $group ] ) ) {
				$grouped[ $group ] = array();
			}
			foreach ( $fields as $key => $def ) {
				if ( ! array_key_exists( $key, $grouped[ $group ] ) && is_array( $def ) && array_key_exists( 'default', $def ) ) {
					$grouped[ $group ][ $key ] = $def['default'];
				}
			}
		}
	}

	/**
	 * @return array<string, mixed>
	 */
	public static function get_flat_defaults() {
		if ( class_exists( '\Modula_Pro\Extensions\Albums\Utils\Fields_Helper', false ) ) {
			$defaults = \Modula_Pro\Extensions\Albums\Utils\Fields_Helper::get_defaults();
			if ( is_array( $defaults ) ) {
				return $defaults;
			}
		}
		return array();
	}
}
