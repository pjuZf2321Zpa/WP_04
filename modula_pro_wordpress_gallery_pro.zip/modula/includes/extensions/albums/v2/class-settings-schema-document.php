<?php
/**
 * Album settings v2 document loader.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Schema_Document
 */
class Settings_Schema_Document {

	/**
	 * @var array<string, mixed>|null
	 */
	private static $document = null;

	/**
	 * @return array<string, mixed>
	 */
	public static function get_document() {
		if ( null !== self::$document ) {
			return self::$document;
		}
		$data_file = __DIR__ . '/data/albums-settings-v2-document.php';
		if ( ! is_readable( $data_file ) ) {
			self::$document = array();
			return self::$document;
		}
		/** @var array<string, mixed> $loaded */
		$loaded         = require $data_file;
		self::$document = is_array( $loaded ) ? $loaded : array();
		return self::$document;
	}

	/**
	 * @return array<string, array<string, array<string, mixed>>>
	 */
	public static function get_settings_tree_raw() {
		$doc = self::get_document();
		return isset( $doc['settings'] ) && is_array( $doc['settings'] ) ? $doc['settings'] : array();
	}

	/**
	 * @param array<string, array<string, mixed>> $settings
	 * @return array<string, array<string, mixed>>
	 */
	public static function strip_editor_presentation_keys_from_settings( array $settings ) {
		$out = array();
		foreach ( $settings as $group => $fields ) {
			if ( ! is_array( $fields ) ) {
				$out[ $group ] = $fields;
				continue;
			}
			$out[ $group ] = array();
			foreach ( $fields as $key => $def ) {
				if ( is_array( $def ) && ! empty( $def['editorPresentationOnly'] ) ) {
					continue;
				}
				if ( ! is_array( $def ) ) {
					$out[ $group ][ $key ] = $def;
					continue;
				}
				$clean = $def;
				unset(
					$clean['editorLabel'],
					$clean['enumOptionLabels'],
					$clean['editorControl'],
					$clean['editorDescription'],
					$clean['editorTooltip'],
					$clean['editorOmitFromSettingsSidebar'],
					$clean['editorPresentationOnly']
				);
				$out[ $group ][ $key ] = $clean;
			}
		}
		return $out;
	}

	/**
	 * @return void
	 */
	public static function reset() {
		self::$document = null;
	}
}
