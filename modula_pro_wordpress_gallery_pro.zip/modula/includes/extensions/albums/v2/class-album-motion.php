<?php
/**
 * The album's stored Motion choices (`motion.*`, Darken on hover, Where it
 * sits): their allowed values, how `auto` resolves per album type, and how
 * albums saved before the Motion settings keep what they play.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

use Modula\V2\Abilities\Hover_Builder_Policy;
use Modula\V2\Motion\Animation_Catalog;
use Modula\V2\Motion\Motion_Settings;
use Modula\V2\Settings\Adapter as Gallery_Adapter;
use Modula\V2\Settings\Sanitizer as Gallery_Sanitizer;

defined( 'ABSPATH' ) || exit;

/**
 * The choices are the gallery's (Lite's Motion_Settings, enums from the shared
 * animation catalog). An album's `custom` hover is its classic effect:
 * `hover.effect` with its colors and padding, which is what the classic
 * album shortcode plays. A classic effect maps to a catalog preset as a
 * classic gallery's does; Under Image is "Under the image" in Where it sits,
 * with no hover of its own (UNDER_IMAGE_HOVER). Albums have no loading
 * effects, so their entrance has no `custom`. Darken on hover is
 * `hover.dimOverlay`, as in the gallery: whether the hovered cover
 * darkens. `hover.hoverColor` is its Dim color, whose tint and alpha a
 * catalog hover plays; the classic effect paints the same color behind the
 * cover and darkens it by `hover.hoverOpacity` (the hovered cover's
 * opacity). The flat copy keeps that color as the hex the classic visitor
 * reads (Meta_Sync::with_legacy_hover_color).
 */
final class Album_Motion {

	/**
	 * What `auto` plays for album types the gallery catalog does not
	 * recommend for, as catalog preset ids. Grid follows the album design's
	 * Motion tab (Flip wave, Tilt); Custom grid and Slider take the catalog's
	 * row for the gallery type of the same name.
	 */
	private const ALBUM_RECOMMENDED = array(
		'grid' => array(
			'entrance' => 'flip',
			'hover'    => 'tilt',
		),
	);

	/**
	 * What an album saved before the Motion settings played, beyond its
	 * hover: no entrance (the gallery's rule gives `custom` only for loading
	 * effects, which albums never had), the classic pace, on phones too.
	 */
	private const EXISTING_ALBUM_VALUES = array(
		'entrance' => 'none',
		'speed'    => 'normal',
		'phones'   => true,
	);

	/**
	 * What an unreadable Dim color darkens with: black, as the canvas drew it
	 * before the migration (ticket 15), and as the gallery's visitor falls back.
	 */
	public const UNREADABLE_DIM_COLOR = '#000000';

	/**
	 * The classic effect that prints the captions under the cover.
	 */
	private const UNDER_IMAGE_EFFECT = 'under';

	/**
	 * The hover an Under Image album plays (album-frontend ticket 16): the
	 * effect is "Under the image" in Where it sits, not a hover, as a
	 * classic gallery's import makes it, with the same hover (Lite ticket
	 * 105). An album has no builder, and its `custom` is the classic effect,
	 * so it names the hover here instead of matching a builder. Under
	 * the image, None - with captions draws the same tile as None (the
	 * title and caption layers skip text under the image); on the image it
	 * keeps the text on the cover, so Where it sits decides.
	 */
	private const UNDER_IMAGE_HOVER = 'none-with-captions';

	/**
	 * The classic effects that move with the classic tilt runtime.
	 */
	private const CLASSIC_TILT_EFFECTS = array( 'tilt_1', 'tilt_3', 'tilt_7' );

	/**
	 * Allowed values of `motion.{kind}`: the gallery's choices, without the
	 * entrance `custom` (the gallery's own loading effects, which albums lack).
	 *
	 * @param string $kind `entrance` or `hover`.
	 * @return array<int, string>
	 */
	public static function choices( string $kind ): array {
		$choices = Motion_Settings::choices( $kind );
		if ( 'entrance' !== $kind ) {
			return $choices;
		}
		return array_values( array_diff( $choices, array( Motion_Settings::CUSTOM ) ) );
	}

	/**
	 * @param string             $kind        `entrance` or `hover`.
	 * @param array<int, string> $album_types The `general.albumType` values.
	 * @return array<string, string> The catalog preset `auto` plays, keyed by album type.
	 */
	public static function recommended_by_album_type( string $kind, array $album_types ): array {
		$table = array();
		foreach ( $album_types as $album_type ) {
			$table[ $album_type ] = self::recommended( $kind, $album_type );
		}
		return $table;
	}

	/**
	 * @param string $kind       `entrance` or `hover`.
	 * @param string $album_type `general.albumType`.
	 * @return string The catalog preset `auto` plays for the album type.
	 */
	public static function recommended( string $kind, string $album_type ): string {
		return self::ALBUM_RECOMMENDED[ $album_type ][ $kind ] ?? Animation_Catalog::recommended( $kind, $album_type );
	}

	/**
	 * What a stored choice plays: `auto` the album type's recommendation, any
	 * other value as stored.
	 *
	 * @param string $kind       `entrance` or `hover`.
	 * @param string $choice     Stored `motion.{kind}`.
	 * @param string $album_type `general.albumType`.
	 * @return string A catalog preset id, or `custom` for the classic hover.
	 */
	public static function resolve( string $kind, string $choice, string $album_type ): string {
		return Motion_Settings::AUTO === $choice ? self::recommended( $kind, $album_type ) : $choice;
	}

	/**
	 * What the album plays for visitors (the Album visitor frontend): its
	 * resolved entrance, and its resolved hover, which is none where the
	 * gallery hides the Hover menu for the album type (Slider), as a gallery
	 * slider plays no hover, and none while the album draws member cards,
	 * which fix the hover (Lite ADR 0057).
	 *
	 * @param array<string, mixed> $grouped Grouped album settings (schema defaults filled).
	 * @return array{entrance: string, hover: string} Catalog preset ids, `custom` for the classic hover; entrance `none` and hover '' when nothing plays.
	 */
	public static function played( array $grouped ): array {
		$album_type = (string) ( $grouped['general']['albumType'] ?? '' );
		$entrance   = (string) ( $grouped['motion']['entrance'] ?? '' );
		$hover      = (string) ( $grouped['motion']['hover'] ?? '' );
		$plays      = self::plays_hover( $hover, $album_type ) && ! Album_Member_Style::draws_cards( $grouped );

		return array(
			'entrance' => '' === $entrance ? 'none' : self::resolve( 'entrance', $entrance, $album_type ),
			'hover'    => $plays ? self::resolve( 'hover', $hover, $album_type ) : '',
		);
	}

	/**
	 * Whether the album plays its classic Tilt effect for visitors, which
	 * moves with the classic tilt runtime (`modula-pro-tilt`), as the classic
	 * shortcode loads it for those effects.
	 *
	 * @param array<string, mixed> $grouped Grouped album settings.
	 * @return bool
	 */
	public static function plays_classic_tilt( array $grouped ): bool {
		return Motion_Settings::CUSTOM === self::played( $grouped )['hover']
			&& in_array( $grouped['hover']['effect'] ?? '', self::CLASSIC_TILT_EFFECTS, true );
	}

	/**
	 * @param string $hover      Stored `motion.hover`.
	 * @param string $album_type `general.albumType`.
	 * @return bool Whether a hover plays: a stored choice, on an album type whose Hover menu the gallery shows.
	 */
	private static function plays_hover( string $hover, string $album_type ): bool {
		return '' !== $hover && ! Animation_Catalog::menu_hidden_for_type( 'hover', $album_type );
	}

	/**
	 * Fill the Motion keys an album saved before the Motion settings lacks,
	 * with explicit values that play what it plays: no entrance, the hover
	 * choice its classic effect stands for, Darken on hover as its classic
	 * opacity darkens (never for Under Image, as the gallery's), and its
	 * captions where the classic effect prints them. Stored values are kept,
	 * and the classic effect and opacity are never rewritten. An album
	 * migrated while Under Image was still a hover (`custom` with `under`) is
	 * the exception (without_under_image_hover): it reads Under Image's hover
	 * choice now, with Darken on hover off, and its Dim color takes the
	 * alpha of its classic opacity, as any album that migrates to a catalog
	 * preset does. Where it sits stays as stored, and the classic effect, the
	 * opacity and the flat copy's color stay too, so the step can be
	 * recomputed.
	 * A document without a classic effect (a new album, a preset that leaves
	 * hover out) is returned as it is; new albums get the schema defaults
	 * (`auto`, no darkening).
	 *
	 * @param array<string, mixed> $grouped Grouped album settings.
	 * @return array<string, mixed>
	 */
	public static function with_existing_album_values( array $grouped ): array {
		$effect = self::classic_effect( $grouped );
		if ( null === $effect ) {
			return $grouped;
		}
		$motion = isset( $grouped['motion'] ) && is_array( $grouped['motion'] ) ? $grouped['motion'] : array();
		if ( ! array_key_exists( 'hover', $motion ) ) {
			$motion['hover']  = self::hover_choice_for_effect( $effect );
			$grouped['hover'] = self::with_dim_alpha_for_choice( $grouped['hover'], $motion['hover'] );
		}
		$grouped['motion'] = $motion + self::EXISTING_ALBUM_VALUES;
		// Only a stored opacity tells: a preset that leaves it out must not
		// carry a Darken on hover over the album it is applied to.
		$opacity = $grouped['hover']['hoverOpacity'] ?? null;
		if ( null !== $opacity && ! array_key_exists( 'dimOverlay', $grouped['hover'] ) ) {
			$grouped['hover']['dimOverlay'] = self::effect_darkens( $effect, $opacity );
		}
		// While Under Image played as the classic hover, Darken on hover was
		// the migration's (from the opacity), not a choice made since.
		if ( self::plays_under_image_as_hover( $grouped['motion']['hover'], $effect ) ) {
			$grouped['hover']['dimOverlay'] = false;
		}
		$captions = isset( $grouped['captions'] ) && is_array( $grouped['captions'] ) ? $grouped['captions'] : array();
		if ( ! array_key_exists( 'contentPlacement', $captions ) ) {
			$captions['contentPlacement'] = self::placement_for_effect( $effect );
		}
		$grouped['captions'] = $captions;
		return self::without_under_image_hover( $grouped );
	}

	/**
	 * Under Image is no hover (UNDER_IMAGE_HOVER): settings that play it as
	 * the classic hover (`custom` with `under`, as albums migrated before
	 * album-frontend ticket 16 store it, or a save that names `custom`) play
	 * Under Image's hover choice instead, with the Dim color at the alpha of
	 * the classic opacity, as any album that migrates to a catalog preset.
	 * Where it sits and Darken on hover are left as they are: the read
	 * (with_existing_album_values) turns a migrated Darken on hover off
	 * first, while the settings writer, which also applies this so a strict
	 * write that names `custom` is refused before it writes, keeps one the
	 * user turned on since.
	 *
	 * @param array<string, mixed> $grouped Grouped album settings.
	 * @return array<string, mixed>
	 */
	public static function without_under_image_hover( array $grouped ): array {
		$effect = self::classic_effect( $grouped );
		if ( null === $effect || ! self::plays_under_image_as_hover( $grouped['motion']['hover'] ?? null, $effect ) ) {
			return $grouped;
		}
		$grouped['motion']['hover'] = self::UNDER_IMAGE_HOVER;
		$grouped['hover']           = self::with_dim_alpha_for_choice( $grouped['hover'], self::UNDER_IMAGE_HOVER );
		return $grouped;
	}

	/**
	 * A settings patch that changes the classic effect (`hover.effect`),
	 * without naming `motion.hover`, sets the hover choice from the new effect,
	 * as a gallery's builder write does (Motion_Settings::with_hover_choice_from_builder_write):
	 * the catalog preset it matches, else the classic effect (`custom`). An
	 * effect whose builder plays the same motion as the stored one leaves the
	 * choice alone, and a stored choice that already plays the matched preset
	 * stays, so `auto` stays `auto`. The patch also puts Where it sits where
	 * the effect prints the captions, unless it names it. The interim Motion
	 * tab's Hover effect row and ability writes both write the effect;
	 * Darken on hover never moves the choice.
	 *
	 * @param array<string, mixed> $existing Stored grouped settings.
	 * @param array<string, mixed> $incoming Grouped patch.
	 * @return array<string, mixed> The patch, with the Motion keys the effect moved.
	 */
	public static function with_motion_from_effect_write( array $existing, array $incoming ): array {
		$effect = self::classic_effect( $incoming );
		if ( null === $effect || self::classic_effect( $existing ) === $effect ) {
			return $incoming;
		}
		if ( ! isset( $incoming['motion']['hover'] ) ) {
			$choice = self::hover_choice_moved_by_effect( $existing, $incoming, $effect );
			if ( null !== $choice ) {
				$incoming['motion']['hover'] = $choice;
			}
		}
		if ( ! isset( $incoming['captions']['contentPlacement'] ) ) {
			$incoming['captions']['contentPlacement'] = self::placement_for_effect( $effect );
		}
		return $incoming;
	}

	/**
	 * The hover choice a classic effect stands for, as a classic gallery's
	 * migration decides it: the catalog preset that the gallery's builder for
	 * the effect plays, else `custom`, the classic effect itself. Under Image
	 * is no hover (UNDER_IMAGE_HOVER).
	 *
	 * @param string $effect Classic effect slug.
	 * @return string A catalog hover preset id or `custom`.
	 */
	private static function hover_choice_for_effect( string $effect ): string {
		if ( self::UNDER_IMAGE_EFFECT === $effect ) {
			return self::UNDER_IMAGE_HOVER;
		}
		return Motion_Settings::hover_choice_for_builder( self::gallery_builder_for_effect( $effect ) );
	}

	/**
	 * @param mixed  $choice Stored `motion.hover`.
	 * @param string $effect Classic effect slug.
	 * @return bool Whether the album plays Under Image as its classic hover, as migrations before album-frontend ticket 16 stored it.
	 */
	private static function plays_under_image_as_hover( $choice, string $effect ): bool {
		return Motion_Settings::CUSTOM === $choice && self::UNDER_IMAGE_EFFECT === $effect;
	}

	/**
	 * @param string $effect Classic effect slug.
	 * @return array<string, mixed> The gallery's hover builder for a classic gallery with that effect.
	 */
	private static function gallery_builder_for_effect( string $effect ): array {
		return Gallery_Adapter::hover_builder_from_legacy_effect_slug( $effect );
	}

	/**
	 * The gallery's builder-write rule, for an effect write.
	 *
	 * @param array<string, mixed> $existing Stored grouped settings.
	 * @param array<string, mixed> $incoming Grouped patch.
	 * @param string               $effect   The new classic effect.
	 * @return string|null The new hover choice; null when the stored one stays.
	 */
	private static function hover_choice_moved_by_effect( array $existing, array $incoming, string $effect ) {
		$stored_effect = self::classic_effect( $existing );
		if ( null !== $stored_effect && Hover_Builder_Policy::same_motion( self::gallery_builder_for_effect( $stored_effect ), self::gallery_builder_for_effect( $effect ) ) ) {
			return null;
		}
		$choice = self::hover_choice_for_effect( $effect );
		if ( Motion_Settings::CUSTOM !== $choice && self::stored_choice_plays( $existing, $incoming, $choice ) ) {
			return null;
		}
		return $choice;
	}

	/**
	 * @param array<string, mixed> $existing Stored grouped settings.
	 * @param array<string, mixed> $incoming Grouped patch; its album type wins.
	 * @param string               $preset   Catalog hover preset id.
	 * @return bool The stored hover choice plays `$preset`.
	 */
	private static function stored_choice_plays( array $existing, array $incoming, string $preset ): bool {
		$stored = $existing['motion']['hover'] ?? null;
		if ( ! is_string( $stored ) ) {
			return false;
		}
		$album_type = $incoming['general']['albumType'] ?? $existing['general']['albumType'] ?? '';
		return self::resolve( 'hover', $stored, is_string( $album_type ) ? $album_type : '' ) === $preset;
	}

	/**
	 * A catalog hover darkens with the Dim color's alpha, as the gallery's;
	 * the classic effect with the cover's opacity, over the same color. So an
	 * album that migrates to a catalog preset reads its Dim color with the
	 * alpha its classic opacity took from the cover, and darkens as before.
	 * The classic effect (`custom`) keeps its color as stored. Both values
	 * must be in the document: a preset that leaves one out keeps the other.
	 *
	 * @param array<string, mixed> $hover  Grouped hover settings.
	 * @param string               $choice The migrated `motion.hover`.
	 * @return array<string, mixed>
	 */
	private static function with_dim_alpha_for_choice( array $hover, string $choice ): array {
		if ( Motion_Settings::CUSTOM === $choice ) {
			return $hover;
		}
		if ( ! isset( $hover['hoverColor'], $hover['hoverOpacity'] ) ) {
			return $hover;
		}
		$alpha               = self::classic_dim_strength( $hover['hoverOpacity'] );
		$hover['hoverColor'] = Gallery_Sanitizer::color_with_alpha( (string) $hover['hoverColor'], $alpha )
			?? Gallery_Sanitizer::color_with_alpha( self::UNREADABLE_DIM_COLOR, $alpha );
		return $hover;
	}

	/**
	 * How much the classic hover darkens the cover: the album shortcode sets
	 * the hovered cover's opacity to the hover opacity rounded to one
	 * decimal, and the color behind it shows through the rest. 95 or more
	 * never darkens.
	 *
	 * @param mixed $opacity Stored `hover.hoverOpacity` (0–100).
	 * @return float Strength 0–1, in tenths.
	 */
	private static function classic_dim_strength( $opacity ): float {
		return round( 1 - round( absint( $opacity ) / 100, 1 ), 1 );
	}

	/**
	 * Darken on hover for an album saved before the Motion settings: on when
	 * its classic opacity darkened the cover. Under Image never darkens, as a
	 * classic gallery's import of it has no dim (maintainer, 2026-10-27); its
	 * Dim color still keeps the classic strength for when it is turned on.
	 *
	 * @param string $effect  Classic effect slug.
	 * @param mixed  $opacity Stored `hover.hoverOpacity` (0–100).
	 */
	private static function effect_darkens( string $effect, $opacity ): bool {
		return self::UNDER_IMAGE_EFFECT !== $effect && self::classic_dim_strength( $opacity ) > 0;
	}

	/**
	 * @param array<string, mixed> $grouped Grouped settings or patch.
	 * @return string|null The classic effect slug as the sanitizer stores it; null when the document has none.
	 */
	private static function classic_effect( array $grouped ) {
		$effect = $grouped['hover']['effect'] ?? null;
		return is_string( $effect ) ? sanitize_text_field( $effect ) : null;
	}

	/**
	 * @param string $effect Classic effect slug.
	 * @return string `captions.contentPlacement` where the effect prints the captions.
	 */
	private static function placement_for_effect( string $effect ): string {
		return self::UNDER_IMAGE_EFFECT === $effect ? 'below-image' : 'inside-image';
	}
}
