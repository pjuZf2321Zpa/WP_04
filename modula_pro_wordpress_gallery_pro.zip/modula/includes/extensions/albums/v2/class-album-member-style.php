<?php
/**
 * The album member style (`general.memberStyle`, Lite ADR 0057): Classic, the
 * gallery-tile look, or Card, the album member card.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Which albums draw their members as cards. The Albums editor and the shared
 * album components read the same rule (`albums-shared/albumMemberStyle.js`,
 * `apps/albums-editor/data/form-rules.json`).
 */
final class Album_Member_Style {

	/**
	 * `general.memberStyle` values; the schema default is Classic, so an
	 * existing album keeps its look.
	 */
	public const CLASSIC = 'classic';
	public const CARD    = 'card';

	/**
	 * Album types whose members a Card album draws as cards: the types that
	 * offer Member style. A Slider album keeps its slides.
	 */
	private const CARD_ALBUM_TYPES = array( 'grid', 'custom-grid' );

	/**
	 * The card's title sizes (album-member-card ticket 07), as
	 * `ALBUM_TITLE_SIZE_SWAPS` in `albums-shared/albumMemberStyle.js`: a Card
	 * album draws them where the album keeps the schema defaults (12 / 10).
	 */
	private const CARD_TITLE_SIZES = array(
		'titleFontSize'       => 18,
		'mobileTitleFontSize' => 16,
	);

	/**
	 * What a new Beta album starts with (ticket 06, ADR 0057): Card, with the
	 * card's title sizes, so its editor rows show what is drawn. Only the
	 * create paths stamp it (`Meta_Sync::apply_new_beta_album_create_defaults()`);
	 * Convert to beta, Try the beta and migration keep Classic.
	 *
	 * @return array<string, array<string, mixed>> A grouped settings patch.
	 */
	public static function create_defaults(): array {
		return array(
			'general'  => array( 'memberStyle' => self::CARD ),
			'captions' => self::CARD_TITLE_SIZES,
		);
	}

	/**
	 * @return array<int, string> The `general.memberStyle` values.
	 */
	public static function choices(): array {
		return array( self::CLASSIC, self::CARD );
	}

	/**
	 * Whether the album draws its members as cards. Card fixes the text
	 * placement and the hover, so Where it sits and the hover choice don't
	 * apply while it does.
	 *
	 * @param array<string, mixed> $grouped Grouped album settings.
	 * @return bool
	 */
	public static function draws_cards( array $grouped ): bool {
		$general = is_array( $grouped['general'] ?? null ) ? $grouped['general'] : array();
		return self::CARD === ( $general['memberStyle'] ?? '' )
			&& in_array( $general['albumType'] ?? '', self::CARD_ALBUM_TYPES, true );
	}
}
