<?php
/**
 * Album members document: sanitize, cycle checks, classic meta sync.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Members_Document
 *
 * Shape: { "members": [ { id, itemType, title, caption, alt, cover, shuffleCover, customurl, target, width, height, ... }, ... ] }
 * Dual-writes classic `modula-album-galleries` list meta.
 */
class Members_Document {

	public const MEMBERS_V2_META_KEY = 'modula_album_members_v2';

	public const CLASSIC_META_KEY = 'modula-album-galleries';

	/**
	 * Stamped as `version` in every stored v2 document. A document without it was
	 * written by an older version and yields to the classic list (see legacy_document()).
	 */
	public const STORAGE_VERSION = 1;

	/**
	 * A member's "Open link in", as a gallery image's `target`: Same tab
	 * (also for a member saved before the choice existed) or New tab.
	 */
	public const TARGET_SAME_TAB = 0;

	public const TARGET_NEW_TAB = 1;

	/**
	 * Attribute keys persisted on each member (parity with legacy sanitize_gallery).
	 *
	 * @return list<string>
	 */
	public static function member_attribute_keys() {
		/**
		 * Filter album member attribute keys for sanitize / document shape.
		 *
		 * @param list<string> $keys Attribute names.
		 */
		return apply_filters(
			'modula_album_gallery_attributes',
			array(
				'id',
				'alt',
				'title',
				'caption',
				'width',
				'height',
				'gridX',
				'gridY',
				'cover',
				'customurl',
				'target',
				'shuffleCover',
				'itemType',
				'filters',
			)
		);
	}

	/**
	 * @param mixed $member Raw member.
	 * @return array<string, mixed>
	 */
	public static function sanitize_member( $member ) {
		if ( ! is_array( $member ) ) {
			return array();
		}

		$new_member = array();
		foreach ( self::member_attribute_keys() as $attribute ) {
			if ( ! isset( $member[ $attribute ] ) ) {
				// A member saved before "Open link in" existed stores Same tab, not ''.
				$new_member[ $attribute ] = 'target' === $attribute ? self::member_target( $member ) : '';
				continue;
			}
			$value = $member[ $attribute ];
			switch ( $attribute ) {
				case 'alt':
				case 'itemType':
					$new_member[ $attribute ] = sanitize_text_field( $value );
					break;
				case 'customurl':
					$new_member[ $attribute ] = esc_url( $value );
					break;
				case 'target':
					$new_member[ $attribute ] = self::sanitize_member_target( $value );
					break;
				case 'cover':
				case 'shuffleCover':
					$new_member[ $attribute ] = sanitize_text_field( $value );
					break;
				case 'id':
				case 'width':
				case 'height':
					$new_member[ $attribute ] = absint( $value );
					break;
				case 'gridX':
				case 'gridY':
					$new_member[ $attribute ] = self::sanitize_member_cell( $value );
					break;
				case 'title':
				case 'caption':
					// Documents hold unslashed values; wp_filter_post_kses() would add slashes on every read.
					$new_member[ $attribute ] = wp_kses_post( $value );
					break;
				case 'filters':
					$new_member[ $attribute ] = self::sanitize_member_filters( $value );
					break;
				default:
					$new_member[ $attribute ] = apply_filters(
						'modula_album_gallery_field_sanitization',
						sanitize_text_field( $value ),
						$value,
						$attribute
					);
					break;
			}
		}

		return $new_member;
	}

	/**
	 * Album filter names a member carries, stored as a gallery image's
	 * (Lite's filter list helpers): comma-separated, a comma inside a name
	 * encoded as `&#44;`. A list of names is accepted too.
	 *
	 * @param mixed $value Raw filters: text or a list of names.
	 * @return string
	 */
	private static function sanitize_member_filters( $value ) {
		if ( is_array( $value ) ) {
			$value = array_filter( $value, 'is_scalar' );
		}
		$names = array_map( 'sanitize_text_field', modula_gallery_filter_list_parse_image_filters( $value ) );
		return modula_gallery_filter_list_format_image_filters( $names );
	}

	/**
	 * A member's album filters, read as `sanitize_member()` stores them: the
	 * gallery item's filter text, '' for none.
	 *
	 * @param array<string, mixed> $member Stored member.
	 * @return string
	 */
	public static function member_filters( array $member ) {
		return self::sanitize_member_filters( $member['filters'] ?? '' );
	}

	/**
	 * A member's "Open link in", as the editor's memberTarget(): only 1 or '1'
	 * is New tab; anything else, booleans included, is Same tab.
	 *
	 * @param mixed $value Raw target.
	 * @return int TARGET_SAME_TAB or TARGET_NEW_TAB.
	 */
	private static function sanitize_member_target( $value ) {
		return self::TARGET_NEW_TAB === $value || (string) self::TARGET_NEW_TAB === $value
			? self::TARGET_NEW_TAB
			: self::TARGET_SAME_TAB;
	}

	/**
	 * A member's "Open link in", read as `sanitize_member()` stores it; none
	 * (a member saved before the choice existed) is Same tab.
	 *
	 * @param array<string, mixed> $member Stored or raw member.
	 * @return int TARGET_SAME_TAB or TARGET_NEW_TAB.
	 */
	public static function member_target( array $member ) {
		return self::sanitize_member_target( $member['target'] ?? null );
	}

	/**
	 * Custom-grid cell. Empty string means unplaced; 0 is valid.
	 *
	 * @param mixed $value Raw cell.
	 * @return int|string
	 */
	private static function sanitize_member_cell( $value ) {
		if ( '' === $value || null === $value ) {
			return '';
		}
		if ( is_string( $value ) && '' === trim( $value ) ) {
			return '';
		}
		if ( ! is_numeric( $value ) ) {
			return '';
		}
		$n = (int) $value;
		return $n >= 0 ? absint( $n ) : '';
	}

	/**
	 * A member's Custom grid cell, read as `sanitize_member()` stores it: the
	 * span in grid units, and the position, '' when the member has none.
	 *
	 * @param array<string, mixed> $member Stored member.
	 * @return array{width: int, height: int, gridX: int|string, gridY: int|string}
	 */
	public static function member_cell( array $member ) {
		return array(
			'width'  => absint( $member['width'] ?? 0 ),
			'height' => absint( $member['height'] ?? 0 ),
			'gridX'  => self::sanitize_member_cell( $member['gridX'] ?? '' ),
			'gridY'  => self::sanitize_member_cell( $member['gridY'] ?? '' ),
		);
	}

	/**
	 * @param mixed $members Raw members list.
	 * @return list<array<string, mixed>>
	 */
	public static function sanitize_members_list( $members ) {
		if ( ! is_array( $members ) ) {
			return array();
		}
		$out = array();
		foreach ( $members as $member ) {
			$clean = self::sanitize_member( $member );
			if ( empty( $clean['id'] ) ) {
				continue;
			}
			$out[] = $clean;
		}
		return $out;
	}

	/**
	 * @param mixed $document Raw document.
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function sanitize_document( $document ) {
		$members = array();
		if ( is_array( $document ) && isset( $document['members'] ) ) {
			$members = self::sanitize_members_list( $document['members'] );
		} elseif ( is_array( $document ) && self::is_list_array( $document ) ) {
			$members = self::sanitize_members_list( $document );
		}
		return array( 'members' => $members );
	}

	/**
	 * Walk post_parent (or any injected resolver) and collect ancestor album IDs.
	 *
	 * @param int              $album_id      Start album.
	 * @param callable(int):int $get_parent_id Parent id for an album.
	 * @return list<int>
	 */
	public static function collect_ancestor_ids( $album_id, callable $get_parent_id ) {
		$ids     = array();
		$current = absint( $album_id );
		$seen    = array();
		while ( $current > 0 && ! isset( $seen[ $current ] ) ) {
			$seen[ $current ] = true;
			$parent           = absint( call_user_func( $get_parent_id, $current ) );
			if ( $parent < 1 ) {
				break;
			}
			$ids[]   = $parent;
			$current = $parent;
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * First usable attachment id from classic `modula-images` list meta.
	 *
	 * @param mixed $images Images meta.
	 * @return int
	 */
	public static function first_attachment_id_from_images_meta( $images ) {
		if ( ! is_array( $images ) ) {
			return 0;
		}
		foreach ( $images as $img ) {
			if ( ! is_array( $img ) || empty( $img['id'] ) ) {
				continue;
			}
			$id = absint( $img['id'] );
			if ( $id > 0 ) {
				return $id;
			}
		}
		return 0;
	}

	/**
	 * Albums that must not be nested under $album_id (self + ancestors).
	 *
	 * @param int $album_id Album ID.
	 * @return list<int>
	 */
	public static function excluded_nested_album_ids( $album_id ) {
		$album_id = absint( $album_id );
		if ( $album_id < 1 ) {
			return array();
		}
		$ancestors   = self::collect_ancestor_ids(
			$album_id,
			static function ( $id ) {
				$post = get_post( $id );
				return ( $post && $post->post_parent ) ? (int) $post->post_parent : 0;
			}
		);
		$ancestors[] = $album_id;
		return array_values( array_unique( array_filter( $ancestors ) ) );
	}

	/**
	 * @param int $attachment_id Attachment ID.
	 * @return array<string, mixed>
	 */
	public static function attachment_thumb_payload( $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		if ( $attachment_id < 1 || ! function_exists( 'wp_get_attachment_image_src' ) ) {
			return array();
		}
		$attachment = function_exists( 'wp_prepare_attachment_for_js' ) ? wp_prepare_attachment_for_js( $attachment_id ) : array();
		$image_url  = wp_get_attachment_image_src( $attachment_id, 'large' );
		$image_full = wp_get_attachment_image_src( $attachment_id, 'full' );
		return array(
			'id'          => $attachment_id,
			'orientation' => ( is_array( $attachment ) && ! empty( $attachment['orientation'] ) ) ? $attachment['orientation'] : 'landscape',
			'full'        => ( is_array( $image_full ) && ! empty( $image_full[0] ) ) ? $image_full[0] : '',
			'thumbnail'   => ( is_array( $image_url ) && ! empty( $image_url[0] ) ) ? $image_url[0] : '',
		);
	}

	/**
	 * Whether a member should appear on visitor / listing / editor surfaces (ADR 0026).
	 *
	 * Trashed or missing posts are soft-hidden; membership meta is kept until permanent delete.
	 *
	 * @param array<string, mixed> $member Member.
	 * @return bool
	 */
	public static function is_live_member( array $member ) {
		$id = isset( $member['id'] ) ? absint( $member['id'] ) : 0;
		if ( $id < 1 ) {
			return false;
		}
		$item_type = isset( $member['itemType'] ) && '' !== (string) $member['itemType']
			? (string) $member['itemType']
			: 'modula-gallery';
		$post      = get_post( $id );
		if ( ! $post || 'trash' === $post->post_status ) {
			return false;
		}
		if ( 'modula-album' === $item_type ) {
			return 'modula-album' === $post->post_type;
		}
		return 'modula-gallery' === $post->post_type;
	}

	/**
	 * Whether the current visitor may see a member on the front end.
	 *
	 * A live member that is published, or that the current user can read_post.
	 * Galleries use Lite's visitor-readable rule (ADR 0028); nested albums use
	 * the same rule through is_visitor_readable_album(). Editor surfaces keep
	 * is_live_member(), which shows private and draft members to editors.
	 *
	 * @param array<string, mixed> $member Member.
	 * @return bool
	 */
	public static function is_visitor_readable_member( array $member ) {
		if ( ! self::is_live_member( $member ) ) {
			return false;
		}
		$id = absint( $member['id'] );
		if ( 'modula-album' === get_post_type( $id ) ) {
			return self::is_visitor_readable_album( $id );
		}
		return \Modula_Helper::is_visitor_readable_gallery( $id );
	}

	/**
	 * Whether a member is public: live and published, whoever asks.
	 *
	 * For artifacts shared by every visitor, such as the cached album ZIP
	 * under uploads, which must not carry what only the requester can read.
	 *
	 * @param array<string, mixed> $member Member.
	 * @return bool
	 */
	public static function is_public_member( array $member ) {
		if ( ! self::is_live_member( $member ) ) {
			return false;
		}
		// A live member's post exists.
		return 'publish' === get_post( absint( $member['id'] ) )->post_status;
	}

	/**
	 * The members the current visitor may see, in order.
	 *
	 * @param mixed $members Stored member list (`modula-album-galleries`).
	 * @return array<int, array<string, mixed>> Re-indexed members.
	 */
	public static function visitor_readable_members( $members ) {
		if ( ! is_array( $members ) ) {
			return array();
		}
		return array_values(
			array_filter(
				$members,
				static function ( $member ) {
					return is_array( $member ) && self::is_visitor_readable_member( $member );
				}
			)
		);
	}

	/**
	 * Whether the current visitor may see an album: published, or the current
	 * user can read_post. The album counterpart of Lite's visitor-readable
	 * gallery (ADR 0028).
	 *
	 * @param int $album_id Album post ID.
	 * @return bool
	 */
	public static function is_visitor_readable_album( $album_id ) {
		$album = get_post( absint( $album_id ) );
		if ( ! $album || 'modula-album' !== $album->post_type ) {
			return false;
		}
		if ( 'publish' === $album->post_status ) {
			return true;
		}
		return current_user_can( 'read_post', $album->ID );
	}

	/**
	 * Trashed member still present in membership (Restore brings it back).
	 *
	 * @param array<string, mixed> $member Member.
	 * @return bool
	 */
	public static function is_soft_hidden_member( array $member ) {
		$id = isset( $member['id'] ) ? absint( $member['id'] ) : 0;
		if ( $id < 1 ) {
			return false;
		}
		$item_type = isset( $member['itemType'] ) && '' !== (string) $member['itemType']
			? (string) $member['itemType']
			: 'modula-gallery';
		$post      = get_post( $id );
		if ( ! $post || 'trash' !== $post->post_status ) {
			return false;
		}
		if ( 'modula-album' === $item_type ) {
			return 'modula-album' === $post->post_type;
		}
		return 'modula-gallery' === $post->post_type;
	}

	/**
	 * Soft-hide trashed / missing members for editor GET (meta unchanged).
	 *
	 * @param array{members?: list<array<string, mixed>>} $document Document.
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function filter_live_members_document( array $document ) {
		$sanitized = self::sanitize_document( $document );
		$live      = array();
		foreach ( $sanitized['members'] as $member ) {
			if ( self::is_live_member( $member ) ) {
				$live[] = $member;
			}
		}
		return array( 'members' => $live );
	}

	/**
	 * Keep soft-hidden (trashed) members in storage when the editor saves a live-only document.
	 *
	 * @param int                                         $album_id Album ID.
	 * @param array{members?: list<array<string, mixed>>} $incoming Incoming document.
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function merge_soft_hidden_members( $album_id, array $incoming ) {
		$incoming = self::sanitize_document( $incoming );
		$stored   = self::ensure_document_from_classic( $album_id );
		$seen     = array();
		foreach ( $incoming['members'] as $member ) {
			$key          = ( isset( $member['itemType'] ) ? (string) $member['itemType'] : 'modula-gallery' ) . ':' . absint( $member['id'] );
			$seen[ $key ] = true;
		}
		foreach ( $stored['members'] as $member ) {
			if ( ! self::is_soft_hidden_member( $member ) ) {
				continue;
			}
			$key = ( isset( $member['itemType'] ) ? (string) $member['itemType'] : 'modula-gallery' ) . ':' . absint( $member['id'] );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$incoming['members'][] = $member;
			$seen[ $key ]          = true;
		}
		return $incoming;
	}

	/**
	 * Remove a permanently deleted gallery from every album that references it.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return int Number of albums updated.
	 */
	public static function prune_gallery_from_all_albums( $gallery_id ) {
		$gallery_id = absint( $gallery_id );
		if ( $gallery_id < 1 ) {
			return 0;
		}

		$album_ids = get_posts(
			array(
				'post_type'              => 'modula-album',
				'post_status'            => array_keys( get_post_stati() ),
				'posts_per_page'         => -1,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		if ( ! is_array( $album_ids ) || empty( $album_ids ) ) {
			return 0;
		}

		$updated = 0;
		foreach ( $album_ids as $album_id ) {
			$raw      = get_post_meta( (int) $album_id, self::MEMBERS_V2_META_KEY, true );
			$document = self::stored_document( (int) $album_id, $raw );
			$next     = array();
			$changed  = false;
			foreach ( $document['members'] as $member ) {
				$item_type = isset( $member['itemType'] ) && '' !== (string) $member['itemType']
					? (string) $member['itemType']
					: 'modula-gallery';
				if ( 'modula-gallery' === $item_type && absint( $member['id'] ) === $gallery_id ) {
					$changed = true;
					continue;
				}
				$next[] = $member;
			}
			if ( ! $changed ) {
				continue;
			}
			// Persist without merge_soft_hidden — the gallery is being permanently deleted.
			$sanitized = self::sanitize_document( array( 'members' => $next ) );
			if ( self::members_create_cycle( (int) $album_id, $sanitized['members'], array( __CLASS__, 'child_album_ids_from_storage' ) ) ) {
				continue;
			}
			self::write_members_keeping_source( (int) $album_id, $raw, $sanitized['members'] );
			// Removing a gallery never changes nested album parentage.
			++$updated;
		}

		return $updated;
	}

	/**
	 * Remove album filter names from an album's members, as a gallery settings
	 * save removes the names it drops from the gallery's images: read-time
	 * repair then cannot refill the album's list with them. Trashed members,
	 * kept in storage, lose the names too.
	 *
	 * @param int      $album_id Album ID.
	 * @param string[] $names    Filter names, decoded.
	 * @return bool True when a member changed.
	 */
	public static function strip_filter_names( $album_id, array $names ) {
		$album_id = absint( $album_id );
		if ( $album_id < 1 || empty( $names ) ) {
			return false;
		}
		$raw      = get_post_meta( $album_id, self::MEMBERS_V2_META_KEY, true );
		$stripped = modula_gallery_filter_list_strip_names_from_images( self::stored_document( $album_id, $raw )['members'], $names );
		if ( empty( $stripped['changed'] ) ) {
			return false;
		}
		self::write_members_keeping_source( $album_id, $raw, $stripped['images'] );
		return true;
	}

	/**
	 * An album's stored members, trashed ones included, read without
	 * backfilling its v2 document.
	 *
	 * @param int $album_id Album ID.
	 * @return list<array<string, mixed>>
	 */
	public static function stored_members( $album_id ) {
		$album_id = absint( $album_id );
		return self::stored_document( $album_id, get_post_meta( $album_id, self::MEMBERS_V2_META_KEY, true ) )['members'];
	}

	/**
	 * The v2 document, or the classic list while the album has none.
	 *
	 * @param int   $album_id Album ID.
	 * @param mixed $raw      Stored `modula_album_members_v2` value.
	 * @return array{members: list<array<string, mixed>>}
	 */
	private static function stored_document( $album_id, $raw ) {
		return self::is_missing_document( $raw )
			? self::document_from_classic( get_post_meta( $album_id, self::CLASSIC_META_KEY, true ) )
			: self::get_document( $album_id );
	}

	/**
	 * Write an album's members to both metas, keeping its source: a classic
	 * album keeps classic as its only source, since a v2 copy written here
	 * would go stale when the classic album editor changes the album.
	 *
	 * @param int                        $album_id Album ID.
	 * @param mixed                      $raw      Stored `modula_album_members_v2` value.
	 * @param list<array<string, mixed>> $members  Sanitized members.
	 * @return void
	 */
	private static function write_members_keeping_source( $album_id, $raw, array $members ) {
		if ( null !== self::current_document( $raw ) ) {
			self::persist_document_meta( $album_id, array( 'members' => $members ) );
		}
		update_post_meta( $album_id, self::CLASSIC_META_KEY, wp_slash( $members ) );
	}

	/**
	 * Albums that list a post, directly or through nested albums.
	 *
	 * Reads every album's classic member list, which visitors and downloads
	 * read too. Meant for rare events such as dropping cached album ZIPs.
	 *
	 * @param int $post_id Gallery or album post ID.
	 * @return list<int> Album IDs, each once; cycles end.
	 */
	public static function containing_album_ids( $post_id ) {
		$albums_by_member = self::album_ids_by_member();
		$found            = array();
		$queue            = array( absint( $post_id ) );
		while ( $queue ) {
			$member_id = array_shift( $queue );
			$new       = array_values( array_diff( $albums_by_member[ $member_id ] ?? array(), $found ) );
			$found     = array_merge( $found, $new );
			$queue     = array_merge( $queue, $new );
		}
		return $found;
	}

	/**
	 * Member post ID => IDs of the albums whose classic list holds it.
	 *
	 * @return array<int, list<int>>
	 */
	private static function album_ids_by_member() {
		$album_ids = get_posts(
			array(
				'post_type'              => 'modula-album',
				'post_status'            => array_keys( get_post_stati() ),
				'posts_per_page'         => -1,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		if ( empty( $album_ids ) || ! is_array( $album_ids ) ) {
			return array();
		}
		// One query for every album's members instead of one per album (`fields => ids` skips the meta cache).
		update_meta_cache( 'post', $album_ids );

		$albums_by_member = array();
		foreach ( $album_ids as $album_id ) {
			$members    = get_post_meta( (int) $album_id, self::CLASSIC_META_KEY, true );
			$member_ids = is_array( $members ) ? array_column( array_filter( $members, 'is_array' ), 'id' ) : array();
			foreach ( array_unique( array_filter( array_map( 'absint', $member_ids ) ) ) as $member_id ) {
				$albums_by_member[ $member_id ][] = (int) $album_id;
			}
		}
		return $albums_by_member;
	}

	/**
	 * Permanent-delete hook: prune gallery membership (not trash).
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function maybe_prune_deleted_gallery( $post_id ) {
		$post_id = absint( $post_id );
		if ( $post_id < 1 || 'modula-gallery' !== get_post_type( $post_id ) ) {
			return;
		}
		self::prune_gallery_from_all_albums( $post_id );
	}

	/**
	 * @return void
	 */
	public static function init_lifecycle_hooks() {
		add_action( 'before_delete_post', array( __CLASS__, 'maybe_prune_deleted_gallery' ) );
	}

	/**
	 * Add editor display fields (thumbs) without changing persistable keys.
	 *
	 * @param array{members?: list<array<string, mixed>>} $document Document.
	 * @param int                                         $album_id Current album (for parent labels).
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function enrich_document_for_editor( array $document, $album_id = 0 ) {
		$sanitized = self::sanitize_document( $document );
		$album_id  = absint( $album_id );
		foreach ( $sanitized['members'] as $index => $member ) {
			$sanitized['members'][ $index ] = self::enrich_member_for_editor( $member, $album_id );
		}
		return $sanitized;
	}

	/**
	 * @param array<string, mixed> $member   Member.
	 * @param int                  $album_id Current album.
	 * @return array<string, mixed>
	 */
	public static function enrich_member_for_editor( array $member, $album_id = 0 ) {
		$id        = isset( $member['id'] ) ? absint( $member['id'] ) : 0;
		$item_type = isset( $member['itemType'] ) ? (string) $member['itemType'] : 'modula-gallery';
		$cover_id  = isset( $member['cover'] ) ? absint( $member['cover'] ) : 0;

		$thumb_id = 0;
		if ( $cover_id > 0 && 'modula-gallery' === $item_type ) {
			$thumb_id             = $cover_id;
			$large                = function_exists( 'wp_get_attachment_image_src' ) ? wp_get_attachment_image_src( $cover_id, 'large' ) : false;
			$thumb                = function_exists( 'wp_get_attachment_image_src' ) ? wp_get_attachment_image_src( $cover_id, 'thumbnail' ) : false;
			$member['coverURL']   = ( is_array( $large ) && ! empty( $large[0] ) ) ? $large[0] : '';
			$member['coverThumb'] = ( is_array( $thumb ) && ! empty( $thumb[0] ) ) ? $thumb[0] : '';
		} elseif ( 'modula-album' === $item_type && $id > 0 && function_exists( 'modula_get_album_cover_id' ) ) {
			$thumb_id = modula_get_album_cover_id( $id );
			$parent   = self::foreign_parent_title( get_post( $id ), $album_id );
			if ( '' !== $parent ) {
				$member['parent'] = $parent;
			}
		} elseif ( $id > 0 ) {
			$thumb_id = self::first_attachment_id_from_images_meta( get_post_meta( $id, 'modula-images', true ) );
		}

		$thumb = self::attachment_thumb_payload( $thumb_id );
		if ( ! empty( $thumb ) ) {
			$member['thumb'] = $thumb;
		}

		if ( empty( $member['title'] ) && $id > 0 ) {
			// The stored title, not get_the_title(): texturize rewrites quotes and dashes, and the editor saves this title.
			$post            = get_post( $id );
			$member['title'] = $post ? $post->post_title : '';
		}
		if ( isset( $member['title'] ) ) {
			$member['title'] = self::editor_title( self::repaired_title( $member['title'], $id ) );
		}

		if ( $id > 0 ) {
			$member = array_merge( $member, self::member_panel_fields( $id, $item_type ) );
		}

		return $member;
	}

	/**
	 * What the member panel's identity card reads: the member's item count
	 * and, for a gallery the current user can edit, its edit screen. Display
	 * only: sanitize_member() drops both on save.
	 *
	 * @param int    $id        Member post ID.
	 * @param string $item_type Member type.
	 * @return array{itemCount: int|null, counts: array<string, int>|null, strip?: list<array{id: int, src: string}>, editUrl?: string} `itemCount` is null when Lite's listing helper is unavailable; `counts` is the member card's (`Album_Member_Counts`), as the visitor gets it; `strip` a nested album card's thumbnails (`Album_Member_Strip`).
	 */
	private static function member_panel_fields( $id, $item_type ) {
		$counts = Album_Member_Counts::for_member( $item_type, $id );
		if ( 'modula-album' === $item_type ) {
			return array(
				'itemCount' => self::live_member_count( $id ),
				'counts'    => $counts,
				'strip'     => self::strip_thumbnails( $id ),
			);
		}

		$fields = array(
			'itemCount' => self::gallery_item_count( $id ),
			'counts'    => $counts,
		);
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return $fields;
		}
		$edit_url = get_edit_post_link( $id, 'raw' );
		if ( is_string( $edit_url ) && '' !== $edit_url ) {
			$fields['editUrl'] = $edit_url;
		}
		return $fields;
	}

	/**
	 * A nested album card's thumbnail strip on the editor canvas: the
	 * visitor's covers (`Album_Member_Strip`) at thumbnail size. The canvas
	 * shows the editor its own files, so Image Guardian's visitor rule is the
	 * visitor's only.
	 *
	 * @param int $album_id Nested album ID.
	 * @return list<array{id: int, src: string}>
	 */
	private static function strip_thumbnails( $album_id ) {
		$thumbnails = array();
		foreach ( Album_Member_Strip::cover_ids( $album_id ) as $attachment_id ) {
			$src = wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
			if ( is_string( $src ) && '' !== $src ) {
				$thumbnails[] = array(
					'id'  => $attachment_id,
					'src' => $src,
				);
			}
		}
		return $thumbnails;
	}

	/**
	 * Members with titles damaged by the old unslashed write repaired for display.
	 *
	 * @param array<int, array<string, mixed>> $members Members.
	 * @return array<int, array<string, mixed>>
	 */
	public static function with_repaired_titles( array $members ) {
		foreach ( $members as $index => $member ) {
			if ( isset( $member['title'], $member['id'] ) ) {
				$members[ $index ]['title'] = self::repaired_title( $member['title'], $member['id'] );
			}
		}
		return $members;
	}

	/**
	 * The member title, or the post title when the stored one is its damaged copy.
	 *
	 * Before f9b7f98 the members JSON was written unslashed, so `—` lost the
	 * backslash of `—` and was stored as `u2014`. An editor save then copied
	 * that text into the classic list, and the legacy rebuild kept it. A stored
	 * title that equals the post title with exactly this damage is repaired; any
	 * other stored title is the user's own. Captions have no original to compare.
	 *
	 * @param mixed $title   Stored member title.
	 * @param mixed $post_id Member post ID.
	 * @return mixed The post title when $title is its damaged copy; otherwise $title.
	 */
	public static function repaired_title( $title, $post_id ) {
		// Only damaged text carries the escape residue; skip the post read otherwise.
		if ( ! is_string( $title ) || ! preg_match( '/u[0-9a-f]{4}/', $title ) ) {
			return $title;
		}
		$post = get_post( absint( $post_id ) );
		if ( ! $post ) {
			return $title;
		}
		$encoded = wp_json_encode( $post->post_title );
		if ( ! is_string( $encoded ) ) {
			return $title;
		}
		// update_post_meta() unslashed the JSON: the encoded title without its quotes, unslashed.
		$damaged = stripslashes( substr( $encoded, 1, -1 ) );
		return self::editor_title( $title ) === self::editor_title( $damaged ) ? $post->post_title : $title;
	}

	/**
	 * Plain-text title for the Albums editor, which renders titles as text.
	 *
	 * Stored member titles pass through kses (`&` becomes `&amp;`) and post
	 * titles may carry entities, so they are decoded once here. Markup is not
	 * stripped: React escapes it, so `<b>` shows as literal text. Decoding and
	 * kses are not inverses: a stored `&lt;b&gt;` is saved back as a `<b>` tag.
	 *
	 * @param mixed $title Stored or post title.
	 * @return string Decoded title; '' when missing.
	 */
	public static function editor_title( $title ) {
		return html_entity_decode( (string) $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	/**
	 * One page of picker candidates from ids already in display order.
	 *
	 * Eligibility is a PHP check (a usable cover), so totals count eligible ids
	 * rather than SQL rows.
	 *
	 * @param list<int>          $ids         Candidate ids in display order.
	 * @param callable(int):bool $is_eligible Whether an id can be offered.
	 * @param int                $page        1-based page.
	 * @param int                $per_page    Page size, at least 1.
	 * @return array{ids: list<int>, total: int, total_pages: int}
	 */
	public static function page_candidate_ids( array $ids, callable $is_eligible, $page, $per_page ) {
		$eligible = array_values( array_filter( $ids, $is_eligible ) );
		$total    = count( $eligible );
		return array(
			'ids'         => array_slice( $eligible, ( $page - 1 ) * $per_page, $per_page ),
			'total'       => $total,
			'total_pages' => (int) ceil( $total / $per_page ),
		);
	}

	/**
	 * Gallery picker candidates: published galleries whose first image exists.
	 *
	 * @param string $search   Search terms; '' lists every gallery.
	 * @param int    $page     1-based page.
	 * @param int    $per_page Page size, at least 1.
	 * @return array{items: list<array<string, mixed>>, total: int, total_pages: int}
	 */
	public static function query_gallery_candidates( $search, $page, $per_page ) {
		$ids    = self::candidate_post_ids(
			array(
				'post_type' => 'modula-gallery',
				's'         => $search,
			)
		);
		$covers = array();
		foreach ( $ids as $id ) {
			$covers[ $id ] = self::first_attachment_id_from_images_meta( get_post_meta( $id, 'modula-images', true ) );
		}
		// One query for every cover attachment instead of one per gallery.
		_prime_post_caches( array_values( array_filter( $covers ) ), false, false );

		$paged = self::page_candidate_ids(
			$ids,
			static function ( $id ) use ( $covers ) {
				return $covers[ $id ] > 0 && null !== get_post( $covers[ $id ] );
			},
			$page,
			$per_page
		);

		$items = array();
		foreach ( $paged['ids'] as $id ) {
			$items[] = self::candidate_payload( get_post( $id ), $covers[ $id ], self::gallery_item_count( $id ) );
		}
		return array(
			'items'       => $items,
			'total'       => $paged['total'],
			'total_pages' => $paged['total_pages'],
		);
	}

	/**
	 * Nested-album picker candidates (excludes self and ancestors).
	 *
	 * @param int    $album_id Current album.
	 * @param string $search   Search terms; '' lists every album.
	 * @param int    $page     1-based page.
	 * @param int    $per_page Page size, at least 1.
	 * @return array{items: list<array<string, mixed>>, total: int, total_pages: int}
	 */
	public static function query_album_candidates( $album_id, $search, $page, $per_page ) {
		$album_id = absint( $album_id );
		$ids      = self::candidate_post_ids(
			array(
				'post_type'    => 'modula-album',
				's'            => $search,
				'post__not_in' => self::excluded_nested_album_ids( $album_id ),
				'orderby'      => 'menu_order',
				'order'        => 'ASC',
			)
		);
		$covers   = array();
		foreach ( $ids as $id ) {
			$covers[ $id ] = function_exists( 'modula_get_album_cover_id' ) ? modula_get_album_cover_id( $id ) : 0;
		}

		$paged = self::page_candidate_ids(
			$ids,
			static function ( $id ) use ( $covers ) {
				return $covers[ $id ] > 0;
			},
			$page,
			$per_page
		);

		$items = array();
		foreach ( $paged['ids'] as $id ) {
			$post    = get_post( $id );
			$items[] = self::candidate_payload( $post, $covers[ $id ], self::live_member_count( $id ) ) + array(
				'parent' => self::foreign_parent_title( $post, $album_id ),
			);
		}
		return array(
			'items'       => $items,
			'total'       => $paged['total'],
			'total_pages' => $paged['total_pages'],
		);
	}

	/**
	 * Published candidate ids in display order, with their meta cached.
	 *
	 * @param array<string, mixed> $query get_posts() arguments (post type, search, order).
	 * @return list<int>
	 */
	private static function candidate_post_ids( array $query ) {
		$ids = get_posts(
			array_merge(
				array(
					'posts_per_page' => -1,
					'post_status'    => 'publish',
					'fields'         => 'ids',
					'no_found_rows'  => true,
				),
				$query
			)
		);
		$ids = array_map( 'intval', $ids );
		update_meta_cache( 'post', $ids );
		return $ids;
	}

	/**
	 * @param \WP_Post $post       Candidate post.
	 * @param int      $cover_id   Cover attachment ID.
	 * @param int|null $item_count Items in the gallery or album; null when unknown.
	 * @return array<string, mixed>
	 */
	private static function candidate_payload( $post, $cover_id, $item_count ) {
		return array(
			'id'        => (int) $post->ID,
			'title'     => self::editor_title( $post->post_title ),
			'caption'   => '',
			'alt'       => '',
			'cover'     => '',
			'itemType'  => $post->post_type,
			'thumb'     => self::attachment_thumb_payload( $cover_id ),
			'status'    => $post->post_status,
			'itemCount' => $item_count,
		);
	}

	/**
	 * Gallery item count as the listing shows it. Candidates need classic
	 * `modula-images`, which is the catalog the listing selects for them.
	 * The member panel, the canvas tile and the album visitor's image count
	 * read it.
	 *
	 * @param int $gallery_id Gallery ID.
	 * @return int|null Null when Lite's listing helper is unavailable.
	 */
	public static function gallery_item_count( $gallery_id ) {
		if ( ! class_exists( '\Modula\V2\Rest\Listing_Gallery_Item_Counts' ) ) {
			return null;
		}
		$counts = \Modula\V2\Rest\Listing_Gallery_Item_Counts::count_rows( get_post_meta( $gallery_id, 'modula-images', true ) );
		return $counts['total'];
	}

	/**
	 * Live members of another album, read without backfilling its v2 document.
	 *
	 * @param int $album_id Album ID.
	 * @return int
	 */
	private static function live_member_count( $album_id ) {
		$document = array( 'members' => self::stored_members( $album_id ) );
		return count( self::filter_live_members_document( $document )['members'] );
	}

	/**
	 * Title of a nested album's parent when that parent is not the current album.
	 *
	 * @param \WP_Post|null $post     Nested album.
	 * @param int           $album_id Current album.
	 * @return string
	 */
	private static function foreign_parent_title( $post, $album_id ) {
		if ( ! $post || (int) $post->post_parent < 1 || absint( $album_id ) === (int) $post->post_parent ) {
			return '';
		}
		$parent_post = get_post( $post->post_parent );
		return $parent_post ? self::editor_title( $parent_post->post_title ) : '';
	}

	/**
	 * @param array<mixed> $value Array.
	 * @return bool
	 */
	private static function is_list_array( array $value ) {
		if ( function_exists( 'array_is_list' ) ) {
			return array_is_list( $value );
		}
		if ( array() === $value ) {
			return true;
		}
		return array_keys( $value ) === range( 0, count( $value ) - 1 );
	}

	/**
	 * Classic list → document.
	 *
	 * @param mixed $classic Classic meta list.
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function document_from_classic( $classic ) {
		return array(
			'members' => self::sanitize_members_list( is_array( $classic ) ? $classic : array() ),
		);
	}

	/**
	 * Document → classic list.
	 *
	 * @param array{members?: mixed} $document Document.
	 * @return list<array<string, mixed>>
	 */
	public static function classic_from_document( array $document ) {
		$sanitized = self::sanitize_document( $document );
		return $sanitized['members'];
	}

	/**
	 * Nested album member IDs from a members list.
	 *
	 * @param list<array<string, mixed>> $members Members.
	 * @return list<int>
	 */
	public static function extract_album_ids( array $members ) {
		$ids = array();
		foreach ( $members as $item ) {
			if ( empty( $item['itemType'] ) || 'modula-album' !== $item['itemType'] ) {
				continue;
			}
			if ( empty( $item['id'] ) ) {
				continue;
			}
			$ids[] = (int) $item['id'];
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Whether assigning $members to $album_id would self-reference or cycle.
	 *
	 * @param int                            $album_id           Parent album ID.
	 * @param list<array<string, mixed>>     $members            Proposed members.
	 * @param callable(int):list<int>        $get_child_album_ids Resolves nested album IDs for another album.
	 * @return bool True when invalid.
	 */
	public static function members_create_cycle( $album_id, array $members, callable $get_child_album_ids ) {
		$album_id = absint( $album_id );
		if ( $album_id < 1 ) {
			return true;
		}

		foreach ( self::extract_album_ids( $members ) as $child_id ) {
			if ( $child_id === $album_id ) {
				return true;
			}
			if ( self::album_reaches( $child_id, $album_id, $get_child_album_ids, array() ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param int                     $from                 Start album.
	 * @param int                     $target               Looking for this ID in the tree.
	 * @param callable(int):list<int> $get_child_album_ids  Child resolver.
	 * @param array<int, true>        $seen                 Visited.
	 * @return bool
	 */
	private static function album_reaches( $from, $target, callable $get_child_album_ids, array $seen ) {
		$from = absint( $from );
		if ( $from < 1 || isset( $seen[ $from ] ) ) {
			return false;
		}
		$seen[ $from ] = true;

		$children = $get_child_album_ids( $from );
		if ( ! is_array( $children ) ) {
			return false;
		}
		foreach ( $children as $child ) {
			$child = absint( $child );
			if ( $child === absint( $target ) ) {
				return true;
			}
			if ( self::album_reaches( $child, $target, $get_child_album_ids, $seen ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param int $post_id Album ID.
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function get_document( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return array( 'members' => array() );
		}
		$raw     = get_post_meta( $post_id, self::MEMBERS_V2_META_KEY, true );
		$current = self::current_document( $raw );
		if ( null !== $current ) {
			return self::sanitize_document( $current );
		}
		if ( self::is_missing_document( $raw ) ) {
			return array( 'members' => array() );
		}
		return self::legacy_document( $post_id, $raw );
	}

	/**
	 * Stored v2 document carrying the storage version, or null.
	 *
	 * @param mixed $raw Stored `modula_album_members_v2` value.
	 * @return array<string, mixed>|null Null when missing, unreadable or unstamped.
	 */
	private static function current_document( $raw ) {
		$document = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
		if ( ! is_array( $document ) || ! isset( $document['version'] ) ) {
			return null;
		}
		return $document;
	}

	/**
	 * @param mixed $raw Stored `modula_album_members_v2` value.
	 * @return bool
	 */
	private static function is_missing_document( $raw ) {
		return '' === $raw || false === $raw || null === $raw;
	}

	/**
	 * @param mixed $raw Stored `modula_album_members_v2` value.
	 * @return bool True when written by a version before STORAGE_VERSION.
	 */
	private static function is_legacy_document( $raw ) {
		return ! self::is_missing_document( $raw ) && null === self::current_document( $raw );
	}

	/**
	 * Members of an album whose v2 document predates STORAGE_VERSION.
	 *
	 * Older writes stored the JSON unslashed: a quote could leave it unreadable,
	 * and `ă` became `u0103`. Every older writer also wrote the classic list, which
	 * is serialized PHP and kept the text; the classic album editor may have changed
	 * it since. So the classic list wins. Without it, the legacy JSON is the only copy.
	 *
	 * @param int   $post_id Album ID.
	 * @param mixed $raw     Stored legacy v2 value.
	 * @return array{members: list<array<string, mixed>>}
	 */
	private static function legacy_document( $post_id, $raw ) {
		$classic = get_post_meta( $post_id, self::CLASSIC_META_KEY, true );
		if ( is_array( $classic ) ) {
			return self::document_from_classic( array_map( array( __CLASS__, 'unslash_legacy_quotes' ), $classic ) );
		}
		return self::sanitize_document( is_string( $raw ) ? json_decode( $raw, true ) : $raw );
	}

	/**
	 * Undo the slashes that 3.0.12–3.0.15 ability writes stored in title and caption.
	 *
	 * Those writes saved `O\'Brien` in both metas. No older write path kept a
	 * literal backslash, so on legacy data `\'` and `\"` are always this damage.
	 * Current documents are never passed here: they may hold `\'` on purpose.
	 *
	 * @param mixed $member Classic member.
	 * @return mixed
	 */
	private static function unslash_legacy_quotes( $member ) {
		if ( ! is_array( $member ) ) {
			return $member;
		}
		foreach ( array( 'title', 'caption' ) as $field ) {
			if ( isset( $member[ $field ] ) && is_string( $member[ $field ] ) ) {
				$member[ $field ] = str_replace( array( "\\'", '\\"' ), array( "'", '"' ), $member[ $field ] );
			}
		}
		return $member;
	}

	/**
	 * Backfill v2 document from classic meta when empty, and rebuild a legacy one.
	 *
	 * @param int $post_id Album ID.
	 * @return array{members: list<array<string, mixed>>}
	 */
	public static function ensure_document_from_classic( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return array( 'members' => array() );
		}
		$raw_v2  = get_post_meta( $post_id, self::MEMBERS_V2_META_KEY, true );
		$classic = get_post_meta( $post_id, self::CLASSIC_META_KEY, true );
		if ( self::is_legacy_document( $raw_v2 ) && is_array( $classic ) ) {
			// Rebuild once from the classic list. Classic is rewritten too, so the
			// repaired text reaches visitors. Without classic meta the legacy value is kept.
			$document = self::get_document( $post_id );
			self::persist_document_meta( $post_id, $document );
			update_post_meta( $post_id, self::CLASSIC_META_KEY, wp_slash( $document['members'] ) );
			return $document;
		}
		$existing = self::get_document( $post_id );
		if ( ! empty( $existing['members'] ) ) {
			return $existing;
		}
		// Empty members may be intentional; only backfill when classic has data or v2 missing entirely.
		if ( self::is_missing_document( $raw_v2 ) && is_array( $classic ) && ! empty( $classic ) ) {
			$document = self::document_from_classic( $classic );
			self::persist_document_meta( $post_id, $document );
			return $document;
		}
		if ( ! self::is_missing_document( $raw_v2 ) ) {
			return $existing;
		}
		if ( is_array( $classic ) ) {
			$document = self::document_from_classic( $classic );
			self::persist_document_meta( $post_id, $document );
			return $document;
		}
		return array( 'members' => array() );
	}

	/**
	 * Default child-album resolver using classic / v2 members meta.
	 *
	 * @param int $album_id Album ID.
	 * @return list<int>
	 */
	public static function child_album_ids_from_storage( $album_id ) {
		$album_id = absint( $album_id );
		if ( ! $album_id ) {
			return array();
		}
		$document = self::get_document( $album_id );
		if ( ! empty( $document['members'] ) ) {
			return self::extract_album_ids( $document['members'] );
		}
		$classic = get_post_meta( $album_id, self::CLASSIC_META_KEY, true );
		return self::extract_album_ids( is_array( $classic ) ? $classic : array() );
	}

	/**
	 * Save document, sync classic meta, update nested album post_parent.
	 *
	 * @param int   $post_id  Album ID.
	 * @param array $document Document or { members: [] }.
	 * @return array{members: list<array<string, mixed>>}|\WP_Error
	 */
	public static function save_document( $post_id, array $document ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return new \WP_Error(
				'modula_album_members_invalid',
				__( 'Album not found.', 'modula-pro' ),
				array( 'status' => 404 )
			);
		}

		$sanitized = self::sanitize_document( $document );
		$sanitized = self::merge_soft_hidden_members( $post_id, $sanitized );
		if ( self::members_create_cycle( $post_id, $sanitized['members'], array( __CLASS__, 'child_album_ids_from_storage' ) ) ) {
			return new \WP_Error(
				'modula_album_members_cycle',
				__( 'An album cannot contain itself or form a nested album cycle.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$old_classic = get_post_meta( $post_id, self::CLASSIC_META_KEY, true );
		if ( ! is_array( $old_classic ) ) {
			$old_classic = array();
		}
		$old_album_ids = self::extract_album_ids( $old_classic );
		$new_album_ids = self::extract_album_ids( $sanitized['members'] );

		$added   = array_values( array_diff( $new_album_ids, $old_album_ids ) );
		$removed = array_values( array_diff( $old_album_ids, $new_album_ids ) );

		self::persist_document_meta( $post_id, $sanitized );
		update_post_meta( $post_id, self::CLASSIC_META_KEY, wp_slash( $sanitized['members'] ) );

		self::set_albums_parent( $added, $post_id );
		self::set_albums_parent( $removed, 0 );

		return $sanitized;
	}

	/**
	 * Persist a fully validated composition plan. Caller owns authorization, graph validation
	 * and transaction. Unlike editor save, this does not repair or merge hidden members.
	 * Returns an error if hooks or storage prevent exact confirmation.
	 */
	public static function persist_composition( array $documents, array $parents ) {
		foreach ( $documents as $id => $members ) {
			self::persist_document_meta( $id, array( 'members' => $members ) );
			update_post_meta( $id, self::CLASSIC_META_KEY, wp_slash( $members ) );
		}
		foreach ( $parents as $id => $parent ) {
			$saved = Meta_Sync::with_canonical_write( $id, static function () use ( $id, $parent ) {
				return wp_update_post( array( 'ID' => $id, 'post_parent' => $parent ), true );
			} );
			if ( is_wp_error( $saved ) || ! $saved ) { return new \WP_Error( 'album_parent_unconfirmed', 'Album parent update failed.' ); }
		}
		foreach ( $documents as $id => $members ) {
			wp_cache_delete( $id, 'post_meta' );
			if ( self::get_document( $id )['members'] !== $members || get_post_meta( $id, self::CLASSIC_META_KEY, true ) !== $members ) { return new \WP_Error( 'album_members_unconfirmed', 'Album members differ after saving.' ); }
		}
		foreach ( $parents as $id => $parent ) {
			clean_post_cache( $id );
			if ( (int) get_post( $id )->post_parent !== $parent ) { return new \WP_Error( 'album_parent_unconfirmed', 'Album parent differs after saving.' ); }
		}
		return true;
	}

	/**
	 * @param int                                $post_id  Album ID.
	 * @param array{members: list<array<string, mixed>>} $document Document.
	 * @return void
	 */
	private static function persist_document_meta( $post_id, array $document ) {
		$stored = array(
			'version' => self::STORAGE_VERSION,
			'members' => $document['members'],
		);
		// update_post_meta() unslashes its value: unslashed JSON would lose its
		// unicode and quote escapes, and stored text its backslashes.
		update_post_meta( $post_id, self::MEMBERS_V2_META_KEY, wp_slash( wp_json_encode( $stored ) ) );
	}

	/**
	 * @param list<int> $album_ids Child album IDs.
	 * @param int       $parent_id Parent album ID (0 to clear).
	 * @return void
	 */
	private static function set_albums_parent( array $album_ids, $parent_id ) {
		foreach ( $album_ids as $child_id ) {
			wp_update_post(
				array(
					'ID'          => (int) $child_id,
					'post_parent' => (int) $parent_id,
				)
			);
		}
	}
}
