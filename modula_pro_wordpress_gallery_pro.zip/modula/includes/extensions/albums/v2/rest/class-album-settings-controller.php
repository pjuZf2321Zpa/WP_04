<?php
/**
 * Album settings v2 REST controller.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Rest;

use Modula_Pro\Extensions\Albums\V2\Adapter;
use Modula_Pro\Extensions\Albums\V2\Album_Post;
use Modula_Pro\Extensions\Albums\V2\Debug_Log;
use Modula_Pro\Extensions\Albums\V2\Meta_Sync;
use Modula_Pro\Extensions\Albums\V2\Registry;
use Modula_Pro\Extensions\Albums\V2\Sanitizer;

defined( 'ABSPATH' ) || exit;

/**
 * Class Album_Settings_Controller
 */
class Album_Settings_Controller {

	const NAMESPACE = 'modula/v2';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		$album_id_args = array(
			'id' => array(
				'required'          => true,
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
				'validate_callback' => function ( $param ) {
					return $param > 0;
				},
			),
		);

		$read_args = array_merge(
			$album_id_args,
			array(
				'group'  => array(
					'required'          => false,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_key',
				),
				'groups' => array(
					'required'          => false,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
				'key'    => array(
					'required'          => false,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/album/(?P<id>\d+)/settings',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_settings' ),
					'permission_callback' => array( __CLASS__, 'check_album_edit' ),
					'args'                => $read_args,
				),
				array(
					'methods'             => array( 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'update_settings' ),
					'permission_callback' => array( __CLASS__, 'check_album_write' ),
					'args'                => $album_id_args,
				),
			)
		);
	}

	/**
	 * @param \WP_REST_Request $request
	 * @return bool|\WP_Error
	 */
	public static function check_album_edit( $request ) {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || 'modula-album' !== $post->post_type ) {
			return new \WP_Error( 'rest_not_found', __( 'Album not found.', 'modula-pro' ), array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new \WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you are not allowed to edit this album.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * Write access: edit capability + Beta album (mirror gallery settings REST).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public static function check_album_write( $request ) {
		$edit = self::check_album_edit( $request );
		if ( true !== $edit ) {
			return $edit;
		}
		$id = (int) $request['id'];
		if ( class_exists( '\Modula\V2\Beta_Settings' ) && ! \Modula\V2\Beta_Settings::is_beta_album( $id ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'The Albums editor is only available for Beta albums.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function get_settings( $request ) {
		$id = (int) $request['id'];
		Meta_Sync::ensure_settings_v2_from_flat( $id );
		$data = Meta_Sync::get_settings_v2( $id );
		if ( empty( $data ) ) {
			$flat = get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
			if ( is_array( $flat ) ) {
				$data = Sanitizer::sanitize_grouped(
					Adapter::to_grouped(
						$flat,
						array(
							'legacy_import' => true,
						)
					)
				);
			}
		}

		/**
		 * Filter album settings v2 after load.
		 *
		 * @param array<string, mixed> $data Grouped settings.
		 * @param int                  $id   Album post ID.
		 */
		$data = apply_filters( 'modula_v2_album_settings', $data, $id );

		$key = $request->get_param( 'key' );
		if ( '' !== $key && is_string( $key ) ) {
			$parts = explode( '.', $key, 2 );
			if ( 2 === count( $parts ) ) {
				$group = $parts[0];
				$k     = $parts[1];
				if ( isset( $data[ $group ][ $k ] ) ) {
					return new \WP_REST_Response( array( 'value' => $data[ $group ][ $k ] ), 200 );
				}
				return new \WP_REST_Response( array( 'value' => null ), 200 );
			}
		}

		$group      = $request->get_param( 'group' );
		$groups     = $request->get_param( 'groups' );
		$group_str  = is_string( $group ) ? $group : '';
		$groups_str = is_string( $groups ) ? $groups : '';
		if ( '' !== $groups_str ) {
			$want = array_map( 'trim', array_filter( explode( ',', $groups_str ) ) );
		} elseif ( '' !== $group_str ) {
			$want = array( $group_str );
		} else {
			$want = null;
		}

		if ( null !== $want ) {
			$data = array_intersect_key( $data, array_flip( $want ) );
		}

		return new \WP_REST_Response( $data, 200 );
	}

	/**
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function update_settings( $request ) {
		$id = (int) $request['id'];
		Meta_Sync::ensure_settings_v2_from_flat( $id );

		$raw = $request->get_body();
		if ( '' === trim( (string) $raw ) ) {
			Debug_Log::log_persist_failure( $id, 'rest_empty_request', 'album settings save rejected: empty body', 'settings' );
			return new \WP_Error(
				'rest_empty_request',
				__( 'Request body must contain a JSON object of grouped settings.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$incoming = $request->get_json_params();
		if ( ! is_array( $incoming ) ) {
			$decoded = json_decode( $raw, true );
			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
				Debug_Log::log_persist_failure( $id, 'rest_invalid_json', 'album settings save rejected: invalid JSON', 'settings' );
				return new \WP_Error(
					'rest_invalid_json',
					__( 'Invalid JSON body. Send a JSON object of settings groups.', 'modula-pro' ),
					array( 'status' => 400 )
				);
			}
			$incoming = $decoded;
		}

		foreach ( $incoming as $group => $keys ) {
			if ( ! is_string( $group ) || '' === $group ) {
				Debug_Log::log_persist_failure( $id, 'rest_invalid_param', 'album settings save rejected: invalid group name', 'settings' );
				return new \WP_Error(
					'rest_invalid_param',
					__( 'Each top-level key must be a non-empty settings group name (string).', 'modula-pro' ),
					array( 'status' => 400 )
				);
			}
			if ( null !== $keys && ! is_array( $keys ) ) {
				Debug_Log::log_persist_failure( $id, 'rest_invalid_param', 'album settings save rejected: invalid group shape', 'settings' );
				return new \WP_Error(
					'rest_invalid_param',
					sprintf(
						/* translators: %s: settings group name */
						__( 'Group "%s" must be a JSON object of settings.', 'modula-pro' ),
						$group
					),
					array( 'status' => 400 )
				);
			}
		}

		$sanitized = \Modula_Pro\Extensions\Albums\V2\Settings_Writer::patch( $id, $incoming );
		if ( is_wp_error( $sanitized ) ) {
			return $sanitized;
		}

		$status_meta = Album_Post::finish_editor_write( $id, 'settings' );
		if ( is_wp_error( $status_meta ) ) {
			return $status_meta;
		}

		return new \WP_REST_Response( array_merge( $sanitized, $status_meta ), 200 );
	}

	/**
	 * Merge a partial PATCH into existing grouped settings.
	 *
	 * Only schema-owned groups and keys are applied. Unknown client fields are
	 * ignored so opaque server-owned flat keys cannot be invented or overwritten
	 * through the grouped contract.
	 *
	 * @param array<string, array<string, mixed>> $base     Existing grouped settings.
	 * @param array<string, array<string, mixed>> $incoming Incoming PATCH body.
	 * @return array<string, array<string, mixed>>
	 */
	public static function merge_owned_grouped_settings( array $base, array $incoming ) {
		return \Modula_Pro\Extensions\Albums\V2\Settings_Writer::merge_owned_grouped_settings( $base, $incoming );
	}
}
