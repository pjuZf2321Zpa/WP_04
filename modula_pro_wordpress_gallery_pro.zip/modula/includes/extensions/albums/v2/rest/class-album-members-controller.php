<?php
/**
 * Album members v2 REST controller.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2\Rest;

use Modula_Pro\Extensions\Albums\V2\Album_Post;
use Modula_Pro\Extensions\Albums\V2\Album_Sorting;
use Modula_Pro\Extensions\Albums\V2\Debug_Log;
use Modula_Pro\Extensions\Albums\V2\Members_Document;

defined( 'ABSPATH' ) || exit;

/**
 * Class Album_Members_Controller
 */
class Album_Members_Controller {

	const NAMESPACE = 'modula/v2';

	/** Member picker page size; the maximum bounds every candidates response. */
	const CANDIDATES_PER_PAGE_DEFAULT = 24;
	const CANDIDATES_PER_PAGE_MAX     = 60;

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		$album_id_args = array(
			'id' => array(
				'required'          => true,
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
				'validate_callback' => function ( $param ) {
					return $param > 0;
				},
			),
		);

		register_rest_route(
			self::NAMESPACE,
			'/album/(?P<id>\d+)/members',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_members' ),
					'permission_callback' => array( __CLASS__, 'check_album_edit' ),
					'args'                => $album_id_args,
				),
				array(
					'methods'             => array( 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'update_members' ),
					'permission_callback' => array( __CLASS__, 'check_album_write' ),
					'args'                => $album_id_args,
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/album/(?P<id>\d+)/member-candidates',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_member_candidates' ),
					'permission_callback' => array( __CLASS__, 'check_album_edit' ),
					'args'                => array_merge(
						$album_id_args,
						array(
							'itemType' => array(
								'type'              => 'string',
								'enum'              => array( 'modula-gallery', 'modula-album' ),
								'default'           => 'modula-gallery',
								'sanitize_callback' => 'sanitize_text_field',
							),
							'search'   => array(
								'type'              => 'string',
								'default'           => '',
								'validate_callback' => 'rest_validate_request_arg',
								'sanitize_callback' => 'sanitize_text_field',
							),
							'page'     => array(
								'type'              => 'integer',
								'default'           => 1,
								'minimum'           => 1,
								'validate_callback' => 'rest_validate_request_arg',
								'sanitize_callback' => 'absint',
							),
							'per_page' => array(
								'type'              => 'integer',
								'default'           => self::CANDIDATES_PER_PAGE_DEFAULT,
								'minimum'           => 1,
								'maximum'           => self::CANDIDATES_PER_PAGE_MAX,
								'validate_callback' => 'rest_validate_request_arg',
								'sanitize_callback' => 'absint',
							),
						)
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/album/(?P<id>\d+)/sorting',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_sorting' ),
					'permission_callback' => array( __CLASS__, 'check_album_edit' ),
					'args'                => $album_id_args,
				),
				array(
					'methods'             => array( 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'update_sorting' ),
					'permission_callback' => array( __CLASS__, 'check_album_write' ),
					'args'                => $album_id_args,
				),
			)
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public static function check_album_edit( $request ) {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || 'modula-album' !== $post->post_type ) {
			return new \WP_Error( 'rest_not_found', __( 'Album not found.', 'modula-pro' ), array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new \WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you are not allowed to edit this album.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public static function check_album_write( $request ) {
		$edit = self::check_album_edit( $request );
		if ( true !== $edit ) {
			return $edit;
		}
		$id = (int) $request['id'];
		if ( class_exists( '\Modula\V2\Beta_Settings' ) && ! \Modula\V2\Beta_Settings::is_beta_album( $id ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'The Albums editor is only available for Beta albums.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function get_members( $request ) {
		$id       = (int) $request['id'];
		$document = Members_Document::ensure_document_from_classic( $id );
		$document = Members_Document::filter_live_members_document( $document );
		$document = Members_Document::enrich_document_for_editor( $document, $id );

		/**
		 * Filter album members document after load.
		 *
		 * @param array{members: list<array<string, mixed>>} $document Document.
		 * @param int                                        $id       Album post ID.
		 */
		$document = apply_filters( 'modula_v2_album_members', $document, $id );

		return new \WP_REST_Response( $document, 200 );
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function update_members( $request ) {
		$id = (int) $request['id'];

		$raw = $request->get_body();
		if ( '' === trim( (string) $raw ) ) {
			Debug_Log::log_persist_failure( $id, 'rest_empty_request', 'album members save rejected: empty body', 'members' );
			return new \WP_Error(
				'rest_empty_request',
				__( 'Request body must contain a JSON album members document.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$incoming = $request->get_json_params();
		if ( ! is_array( $incoming ) ) {
			$decoded = json_decode( $raw, true );
			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
				Debug_Log::log_persist_failure( $id, 'rest_invalid_json', 'album members save rejected: invalid JSON', 'members' );
				return new \WP_Error(
					'rest_invalid_json',
					__( 'Invalid JSON body. Send a JSON object with a members array.', 'modula-pro' ),
					array( 'status' => 400 )
				);
			}
			$incoming = $decoded;
		}

		$result = Members_Document::save_document( $id, $incoming );
		if ( is_wp_error( $result ) ) {
			Debug_Log::log_persist_failure( $id, $result->get_error_code(), 'album members save failed', 'members' );
			return $result;
		}

		/**
		 * Fires after album members are saved via v2 REST.
		 *
		 * @param int                                        $id       Album post ID.
		 * @param array{members: list<array<string, mixed>>} $document Saved document.
		 */
		do_action( 'modula_album_members_v2_updated', $id, $result );

		$status_meta = Album_Post::finish_editor_write( $id, 'members' );
		if ( is_wp_error( $status_meta ) ) {
			return $status_meta;
		}

		$enriched = Members_Document::enrich_document_for_editor(
			Members_Document::filter_live_members_document( $result ),
			$id
		);

		return new \WP_REST_Response( array_merge( $enriched, $status_meta ), 200 );
	}

	/**
	 * One page of picker candidates. `items` keeps its shape; `total` and
	 * `totalPages` describe every match for the search.
	 *
	 * @param \WP_REST_Request $request Request (search, page and per_page validated by the route).
	 * @return \WP_REST_Response
	 */
	public static function get_member_candidates( $request ) {
		$id        = (int) $request['id'];
		$item_type = (string) $request['itemType'];
		$search    = (string) $request['search'];
		$page      = (int) $request['page'];
		$per_page  = (int) $request['per_page'];
		$result    = 'modula-album' === $item_type
			? Members_Document::query_album_candidates( $id, $search, $page, $per_page )
			: Members_Document::query_gallery_candidates( $search, $page, $per_page );

		return new \WP_REST_Response(
			array(
				'itemType'   => $item_type,
				'items'      => $result['items'],
				'page'       => $page,
				'perPage'    => $per_page,
				'total'      => $result['total'],
				'totalPages' => $result['total_pages'],
			),
			200
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function get_sorting( $request ) {
		$id = (int) $request['id'];
		return new \WP_REST_Response(
			array(
				'sorting' => Album_Sorting::get_mode( $id ),
			),
			200
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function update_sorting( $request ) {
		$id       = (int) $request['id'];
		$incoming = $request->get_json_params();
		if ( ! is_array( $incoming ) ) {
			$raw      = $request->get_body();
			$decoded  = json_decode( (string) $raw, true );
			$incoming = is_array( $decoded ) ? $decoded : array();
		}
		$raw_mode = isset( $incoming['sorting'] ) ? $incoming['sorting'] : '';
		$mode     = Album_Sorting::set_mode( $id, $raw_mode );

		$status_meta = Album_Post::finish_editor_write( $id, 'sorting' );
		if ( is_wp_error( $status_meta ) ) {
			return $status_meta;
		}

		return new \WP_REST_Response(
			array_merge(
				array(
					'sorting' => $mode,
				),
				$status_meta
			),
			200
		);
	}
}
