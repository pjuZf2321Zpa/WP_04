<?php
/**
 * Visitor lightbox config helpers for albums (pure settings → JS config rules).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Lightbox_Visitor_Config
 */
class Lightbox_Visitor_Config {

	/**
	 * Resolve Fancybox Slideshow timeout from flat album settings.
	 *
	 * Prefer the authored `slideshow_duration` key; accept legacy `slideshow_speed`
	 * when duration is absent so older documents still advance at their saved pace.
	 *
	 * @param array $settings Flat modula-album-settings.
	 * @return int Milliseconds.
	 */
	public static function resolve_slideshow_timeout( array $settings ) {
		if ( array_key_exists( 'slideshow_duration', $settings ) && '' !== $settings['slideshow_duration'] && null !== $settings['slideshow_duration'] ) {
			return absint( $settings['slideshow_duration'] );
		}
		if ( array_key_exists( 'slideshow_speed', $settings ) && '' !== $settings['slideshow_speed'] && null !== $settings['slideshow_speed'] ) {
			return absint( $settings['slideshow_speed'] );
		}
		return 3000;
	}
}
