<?php
/** Shared album grouped-settings persistence for the editor and native automation. */
namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

final class Settings_Writer {
	/** Merge only fields owned by the album schema; opaque stored keys stay unchanged. */
	public static function merge_owned_grouped_settings( array $base, array $incoming ): array {
		$schema = Registry::get_schema();
		foreach ( $incoming as $group => $keys ) {
			if ( ! is_string( $group ) || ! is_array( $keys ) ) {
				continue;
			}
			if ( ! isset( $schema[ $group ] ) || ! is_array( $schema[ $group ] ) ) {
				continue;
			}
			if ( ! isset( $base[ $group ] ) || ! is_array( $base[ $group ] ) ) {
				$base[ $group ] = array();
			}
			foreach ( $keys as $key => $value ) {
				if ( ! is_string( $key ) || ! isset( $schema[ $group ][ $key ] ) ) {
					continue;
				}
				$base[ $group ][ $key ] = $value;
			}
		}
		return $base;
	}

	/**
	 * The album's settings after a patch, sanitized. A save can't wipe the
	 * filter list: the gallery's rule (Lite), which lets an explicit [] clear it.
	 * Nor can it make Under Image a hover again (Album_Motion::without_under_image_hover).
	 */
	private static function sanitized_patch( array $existing, array $incoming ): array {
		$merged    = self::merge_owned_grouped_settings( $existing, $incoming );
		$sanitized = Album_Motion::without_under_image_hover( Sanitizer::sanitize_grouped( $merged ) );
		return modula_protect_filter_list_on_grouped_save( $existing, $incoming, $sanitized );
	}

	/** Validate canonical values and availability before any post hooks or metadata writes. */
	public static function validate_patch( int $id, array $incoming ) {
		$schema = \Modula\V2\Abilities\Settings_Contract::schema( true );
		if ( is_wp_error( rest_validate_value_from_schema( $incoming, $schema, 'settings' ) ) || ! \Modula\V2\Abilities\Settings_Contract::strict_types( $incoming, $schema ) ) { return new \WP_Error( 'invalid_settings', 'Album settings contain invalid or unavailable fields.' ); }
		$sanitized = self::sanitized_patch( Meta_Sync::get_settings_v2( $id ), $incoming );
		$pair      = Responsive_Breakpoints::validate_pair( $sanitized['responsive'] );
		if ( is_wp_error( $pair ) ) {
			return $pair;
		}
		foreach ( $incoming as $group => $fields ) {
			foreach ( $fields as $key => $value ) {
				if ( ! array_key_exists( $key, $sanitized[ $group ] ?? array() ) || $sanitized[ $group ][ $key ] !== $value ) { return new \WP_Error( 'invalid_settings', 'Use canonical album setting values: ' . $group . '.' . $key ); }
			}
		}
		return true;
	}

	public static function patch( int $id, array $incoming, bool $strict = false ) {
		if ( $strict ) {
			$valid = self::validate_patch( $id, $incoming );
			if ( is_wp_error( $valid ) ) { return $valid; }
		}
		$existing  = Meta_Sync::get_settings_v2( $id );
		$incoming  = Album_Motion::with_motion_from_effect_write( $existing, $incoming );
		$sanitized = self::sanitized_patch( $existing, $incoming );
		// Cross-field rule on the merged result, before any write; covers the non-strict editor save too.
		$pair = Responsive_Breakpoints::validate_pair( $sanitized['responsive'] );
		if ( is_wp_error( $pair ) ) {
			return $pair;
		}
		if ( $strict ) {
			$selected = $existing;
			foreach ( $incoming as $group => $fields ) {
				foreach ( $fields as $key => $value ) {
					if ( ! array_key_exists( $key, $sanitized[ $group ] ?? array() ) || $sanitized[ $group ][ $key ] !== $value ) { return new \WP_Error( 'invalid_settings', 'Use canonical album setting values.' ); }
					$selected[ $group ][ $key ] = $value;
				}
			}
		}
		// Names the save drops from the list leave the members first, so the
		// list can't be refilled with them on read (the gallery writer's rule).
		Members_Document::strip_filter_names( $id, modula_filter_list_removed_names_on_grouped_save( $existing, $incoming, $sanitized ) );
		if ( $strict ) {
			$prior = get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
			$flat = is_array( $prior ) ? $prior : array();
			$projected = Meta_Sync::with_legacy_hover_color( Adapter::to_flat( $selected ), $flat );
			foreach ( Field_Registry::get_flat_to_grouped_mapping() as $key => $field ) {
				if ( array_key_exists( $field['key'], $incoming[ $field['group'] ] ?? array() ) && array_key_exists( $key, $projected ) ) { $flat[ $key ] = $projected[ $key ]; }
			}
			update_post_meta( $id, Meta_Sync::SETTINGS_V2_META_KEY, wp_slash( wp_json_encode( $selected ) ) );
			update_post_meta( $id, Meta_Sync::FLAT_META_KEY, wp_slash( $flat ) );
			$sanitized = $selected;
		} else {
			Meta_Sync::save_settings_v2( $id, $sanitized );
		}
		$flat = get_post_meta( $id, Meta_Sync::FLAT_META_KEY, true );
		do_action( 'modula_album_settings_v2_updated', $id, $sanitized, is_array( $flat ) ? $flat : array(), $incoming );
		if ( $strict ) {
			wp_cache_delete( $id, 'post_meta' );
			$stored = Meta_Sync::get_settings_v2( $id );
			foreach ( $incoming as $group => $fields ) {
				foreach ( $fields as $key => $value ) {
					if ( ! array_key_exists( $key, $stored[ $group ] ?? array() ) || $stored[ $group ][ $key ] !== $value ) { return new \WP_Error( 'settings_unconfirmed', 'Saved album settings differ from the requested values.' ); }
				}
			}
		}
		return $sanitized;
	}
}
