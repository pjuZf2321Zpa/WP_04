<?php
/**
 * Export album settings v2 artifacts beside the Pro Albums editor.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

use Modula\V2\Motion\Animation_Catalog;
use Modula\V2\Settings\Settings_Schema_Exporter as Lite_Exporter;

defined( 'ABSPATH' ) || exit;

/**
 * Class Albums_Schema_Exporter
 */
class Albums_Schema_Exporter {

	const GENERATED_RELATIVE = 'includes/extensions/albums/apps/albums-editor/generated';

	/**
	 * @param string $pro_root Absolute path to the Pro plugin root.
	 * @return void
	 */
	public static function run( $pro_root ) {
		$pro_root = rtrim( $pro_root, '/' );
		$out_dir  = $pro_root . '/' . self::GENERATED_RELATIVE;
		if ( ! is_dir( $out_dir ) && ! mkdir( $out_dir, 0755, true ) && ! is_dir( $out_dir ) ) {
			throw new \RuntimeException( 'Could not create directory: ' . $out_dir );
		}

		$doc     = Settings_Schema_Document::get_document();
		$encoded = json_encode( $doc, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		if ( false === $encoded ) {
			throw new \RuntimeException( 'Could not encode albums v2 document.' );
		}
		$doc = json_decode( $encoded, true );
		if ( ! is_array( $doc ) ) {
			throw new \RuntimeException( 'Could not copy albums v2 document for export.' );
		}

		if ( function_exists( 'apply_filters' ) && isset( $doc['settings'] ) && is_array( $doc['settings'] ) ) {
			$doc['settings'] = apply_filters( 'modula_v2_album_settings_schema', $doc['settings'] );
		}

		$types_doc = $doc;
		if ( isset( $types_doc['settings'] ) && is_array( $types_doc['settings'] ) ) {
			$types_doc['settings'] = Settings_Schema_Document::strip_editor_presentation_keys_from_settings( $types_doc['settings'] );
		}
		unset( $types_doc['editorNavigation'] );
		Lite_Exporter::write_json_file( $types_doc, $out_dir . '/modula-albums-schema-v2.json' );

		$settings_schema = isset( $doc['settings'] ) && is_array( $doc['settings'] ) ? $doc['settings'] : array();
		$mapping         = Field_Registry::get_flat_to_grouped_mapping();
		$form            = self::build_form_schema( $mapping, $settings_schema );
		Lite_Exporter::write_form_schema_js( $form, $out_dir . '/modula-albums-form-schema.js' );

		$nav  = isset( $doc['editorNavigation'] ) && is_array( $doc['editorNavigation'] ) ? $doc['editorNavigation'] : array();
		$cats = isset( $nav['categories'] ) && is_array( $nav['categories'] ) ? $nav['categories'] : array();
		$cats = Lite_Exporter::derive_category_grouped_paths( $cats );
		$gls  = isset( $nav['groupLabels'] ) && is_array( $nav['groupLabels'] ) ? $nav['groupLabels'] : array();
		Lite_Exporter::write_editor_structure_js(
			array(
				'SETTINGS_EDITOR_CATEGORIES' => $cats,
				'GROUP_LABELS'               => $gls,
			),
			$out_dir . '/modula-albums-editor-structure.js'
		);

		// The Motion menus list the gallery's catalog (Lite's, with its labels).
		if ( ! Lite_Exporter::write_animation_catalog_js( Animation_Catalog::data(), $out_dir . '/modula-animation-catalog.js' ) ) {
			throw new \RuntimeException( 'Could not write the generated modula-animation-catalog.js.' );
		}
	}

	/**
	 * @param array<string, array> $mapping
	 * @param array<string, mixed> $settings_schema
	 * @return array<string, mixed>
	 */
	public static function build_form_schema( array $mapping, array $settings_schema ) {
		$group_labels = Settings_Editor_Presenter::get_group_labels_for_export();
		$groups       = array();

		foreach ( $mapping as $flat_key => $entry ) {
			$group = $entry['group'];
			$key   = $entry['key'];
			if ( ! isset( $groups[ $group ] ) ) {
				$label            = isset( $group_labels[ $group ] ) ? $group_labels[ $group ] : Lite_Exporter::title_case_group( $group );
				$groups[ $group ] = array(
					'id'     => $group,
					'label'  => $label,
					'fields' => array(),
				);
			}
			$schema_field = isset( $settings_schema[ $group ][ $key ] ) && is_array( $settings_schema[ $group ][ $key ] )
				? $settings_schema[ $group ][ $key ]
				: null;

			if ( is_array( $schema_field ) && ! empty( $schema_field['editorOmitFromSettingsSidebar'] ) ) {
				continue;
			}

			$schema_export = Lite_Exporter::schema_for_form_export( $schema_field );
			if ( null === $schema_export ) {
				$schema_export = array(
					'type' => 'unknown',
					'note' => 'missing from albums v2 document',
				);
			}

			$field            = array(
				'flatKey'     => $flat_key,
				'groupedPath' => $group . '.' . $key,
				'groupedKey'  => $key,
				'schema'      => $schema_export,
				'control'     => Lite_Exporter::infer_control( $schema_field, $flat_key, $key ),
			);
			$field['control'] = Lite_Exporter::apply_editor_control( $field['control'], $schema_field, $field );

			if ( is_array( $schema_field ) && ! empty( $schema_field['editorLabel'] ) && is_string( $schema_field['editorLabel'] ) ) {
				$field['editorLabel'] = $schema_field['editorLabel'];
			}
			if ( is_array( $schema_field ) && ! empty( $schema_field['enumOptionLabels'] ) && is_array( $schema_field['enumOptionLabels'] ) ) {
				$field['control']['optionLabels'] = $schema_field['enumOptionLabels'];
			}

			$groups[ $group ]['fields'][] = $field;
		}

		return array(
			'groups' => array_values( $groups ),
		);
	}
}
