<?php
/**
 * Album settings v2 sanitizer.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Sanitizer
 */
class Sanitizer {

	/**
	 * @param array<string, array<string, mixed>> $grouped
	 * @return array<string, array<string, mixed>>
	 */
	public static function sanitize_grouped( array $grouped ) {
		$schema = Registry::get_schema();
		$out    = array();
		foreach ( $schema as $group => $group_def ) {
			if ( ! is_string( $group ) || '' === $group || ! is_array( $group_def ) ) {
				continue;
			}
			$keys = isset( $grouped[ $group ] ) && is_array( $grouped[ $group ] ) ? $grouped[ $group ] : array();
			$custom = apply_filters( 'modula_v2_sanitize_album_group_' . $group, null, $keys, $group );
			if ( is_array( $custom ) ) {
				$out[ $group ] = $custom;
			} else {
				$out[ $group ] = self::sanitize_group( $keys, $group_def, $group );
			}
		}
		return $out;
	}

	/**
	 * @param array<string, mixed> $keys
	 * @param array<string, mixed> $group_def
	 * @param string               $group
	 * @return array<string, mixed>
	 */
	private static function sanitize_group( array $keys, array $group_def, $group ) {
		if ( 'layout' === $group && array_key_exists( 'imageDimensions', $keys ) ) {
			$keys['imageDimensions'] = Adapter::normalize_width_height_object( $keys['imageDimensions'] );
		}
		if ( 'lightbox' === $group && array_key_exists( 'animationEffect', $keys ) ) {
			if ( false === $keys['animationEffect'] ) {
				$keys['animationEffect'] = 'false';
			}
		}
		$result = array();
		foreach ( $group_def as $key => $def ) {
			if ( ! is_array( $def ) ) {
				continue;
			}
			$value          = array_key_exists( $key, $keys )
				? $keys[ $key ]
				: ( array_key_exists( 'default', $def ) ? $def['default'] : null );
			$type           = isset( $def['type'] ) ? $def['type'] : 'string';
			$result[ $key ] = self::sanitize_value(
				$value,
				$type,
				isset( $def['enum'] ) ? $def['enum'] : null,
				array_key_exists( 'default', $def ) ? $def['default'] : null,
				$def
			);
		}
		return $result;
	}

	/**
	 * A list setting, each entry by its `items` schema, as the gallery's
	 * sanitizer: an empty list (or a value that is not a list) reads as the default.
	 *
	 * @param mixed $value    Raw value.
	 * @param mixed $fallback Schema default.
	 * @param array $def      Field definition (`items`: the entries' schema).
	 * @return array
	 */
	private static function sanitize_list( $value, $fallback, array $def ) {
		if ( ! is_array( $value ) ) {
			return is_array( $fallback ) ? $fallback : array();
		}
		$item_def  = isset( $def['items'] ) && is_array( $def['items'] ) ? $def['items'] : array();
		$item_type = isset( $item_def['type'] ) ? $item_def['type'] : 'string';
		$item_enum = isset( $item_def['enum'] ) ? $item_def['enum'] : null;
		$out       = array();
		foreach ( $value as $item ) {
			$out[] = self::sanitize_value( $item, $item_type, $item_enum, null, $item_def );
		}
		return ( array() === $out && is_array( $fallback ) ) ? $fallback : $out;
	}

	/**
	 * @param mixed       $value
	 * @param string      $type
	 * @param array|null  $allowed_values
	 * @param mixed       $fallback
	 * @param array       $def
	 * @return mixed
	 */
	private static function sanitize_value( $value, $type, $allowed_values = null, $fallback = null, array $def = array() ) {
		switch ( $type ) {
			case 'boolean':
				return rest_sanitize_boolean( $value );
			case 'integer':
			case 'number':
				if ( ! is_numeric( $value ) ) {
					$out = is_scalar( $fallback ) ? (int) $fallback : 0;
				} else {
					$out = (int) $value;
				}
				if ( isset( $def['minimum'] ) && $out < (int) $def['minimum'] ) {
					$out = (int) $def['minimum'];
				}
				if ( isset( $def['maximum'] ) && $out > (int) $def['maximum'] ) {
					$out = (int) $def['maximum'];
				}
				return $out;
			case 'object':
				if ( ! is_array( $value ) ) {
					return is_array( $fallback ) ? $fallback : array();
				}
				if ( isset( $def['properties'] ) && is_array( $def['properties'] ) ) {
					return Adapter::normalize_width_height_object( $value );
				}
				return $value;
			case 'array':
				return self::sanitize_list( $value, $fallback, $def );
			case 'string':
			default:
				$str = is_scalar( $value ) ? (string) $value : ( is_scalar( $fallback ) ? (string) $fallback : '' );
				if ( is_array( $allowed_values ) && ! empty( $allowed_values ) ) {
					$allowed_strings = array_map( 'strval', $allowed_values );
					if ( ! in_array( $str, $allowed_strings, true ) ) {
						$str = is_scalar( $fallback ) ? (string) $fallback : '';
					}
				}
				return sanitize_text_field( $str );
		}
	}
}
