<?php
/**
 * Album sort mode (gallery-editor `modulaSorting` analog).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Album_Sorting
 */
class Album_Sorting {

	public const META_KEY = 'modulaSorting';

	/**
	 * Same ids as gallery-editor Sort & order.
	 *
	 * @return list<string>
	 */
	public static function modes() {
		return array(
			'manual',
			'dateCreatedNew',
			'dateCreatedOld',
			'dateModifiedFirst',
			'dateModifiedLast',
			'titleAZ',
			'titleZA',
			'random',
		);
	}

	/**
	 * @param mixed $value Raw mode.
	 * @return string Whitelisted mode; missing/unknown → manual.
	 */
	public static function sanitize_mode( $value ) {
		$mode = is_string( $value ) ? sanitize_text_field( $value ) : '';
		return in_array( $mode, self::modes(), true ) ? $mode : 'manual';
	}

	/**
	 * @param int $album_id Album post ID.
	 * @return string
	 */
	public static function get_mode( $album_id ) {
		$album_id = absint( $album_id );
		if ( $album_id < 1 || ! function_exists( 'get_post_meta' ) ) {
			return 'manual';
		}
		$raw = get_post_meta( $album_id, self::META_KEY, true );
		return self::sanitize_mode( $raw );
	}

	/**
	 * @param int   $album_id Album post ID.
	 * @param mixed $value    Raw mode.
	 * @return string Persisted mode.
	 */
	public static function set_mode( $album_id, $value ) {
		$album_id = absint( $album_id );
		$mode     = self::sanitize_mode( $value );
		if ( $album_id > 0 && function_exists( 'update_post_meta' ) ) {
			update_post_meta( $album_id, self::META_KEY, $mode );
		}
		return $mode;
	}
}
