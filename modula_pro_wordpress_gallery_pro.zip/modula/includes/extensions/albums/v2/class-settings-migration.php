<?php
/**
 * Per-document album settings migration (legacy flat → grouped v2).
 *
 * Reusable by later field-family tickets: bump {@see DOCUMENT_VERSION}, add a
 * transform step, and keep backups under {@see PRE_MIGRATION_META_KEY}.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Migration
 */
class Settings_Migration {

	/**
	 * Current album settings document version.
	 *
	 * Bump when an incompatible grouped-document transform is introduced.
	 *
	 * v2: backfill newly owned schema groups (e.g. `download`) from flat so a
	 * later sanitize/project does not overwrite classic extension settings with
	 * schema defaults.
	 *
	 * v3: same backfill for newly owned `zoom` (and any other groups added after
	 * v2) when an album already carried a v2 stamp without that group.
	 *
	 * v4: same backfill for newly owned `passwordProtect` when an album already
	 * carried a v3 stamp without that group.
	 *
	 * v5: same backfill for newly owned `exif` when an album already carried a
	 * v4 stamp without that group.
	 *
	 * v6: same backfill for newly owned `protection` (Image Guardian) when an
	 * album already carried a v5 stamp without that group.
	 */
	const DOCUMENT_VERSION = 6;

	/**
	 * Post meta: integer document version after a successful migration.
	 */
	const VERSION_META_KEY = '_modula_album_settings_document_version';

	/**
	 * Post meta: recoverable pre-migration representation (settings only).
	 *
	 * Never stores WordPress post_password.
	 */
	const PRE_MIGRATION_META_KEY = '_modula_album_settings_pre_migration';

	/**
	 * Whether the album already has a usable migrated settings document.
	 *
	 * @param int $post_id Album post ID.
	 * @return bool
	 */
	public static function is_current( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return false;
		}
		$version = (int) get_post_meta( $post_id, self::VERSION_META_KEY, true );
		if ( $version < self::DOCUMENT_VERSION ) {
			return false;
		}
		$v2 = Meta_Sync::get_settings_v2( $post_id );
		return ! empty( $v2 );
	}

	/**
	 * Ensure the album's grouped settings document exists and is at the current version.
	 *
	 * Sparse/full legacy flat imports use effective classic defaults. Repeated calls are
	 * idempotent. Does not apply new-album creation defaults.
	 *
	 * @param int $post_id Album post ID.
	 * @return void
	 */
	public static function ensure_migrated( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return;
		}

		if ( self::is_current( $post_id ) ) {
			return;
		}

		$v2   = Meta_Sync::get_settings_v2( $post_id );
		$flat = get_post_meta( $post_id, Meta_Sync::FLAT_META_KEY, true );
		if ( ! is_array( $flat ) ) {
			$flat = array();
		}

		if ( empty( $v2 ) && empty( $flat ) ) {
			return;
		}

		self::store_pre_migration_backup( $post_id, $flat, Meta_Sync::get_stored_settings_v2( $post_id ) );

		if ( empty( $v2 ) ) {
			Meta_Sync::sync_settings_v2(
				$post_id,
				$flat,
				array(
					'legacy_import' => true,
				)
			);
			self::stamp_version( $post_id );
			return;
		}

		$version = (int) get_post_meta( $post_id, self::VERSION_META_KEY, true );
		if ( $version < self::DOCUMENT_VERSION ) {
			$transformed = self::backfill_missing_groups_from_flat( $v2, $flat );
			Meta_Sync::save_settings_v2( $post_id, $transformed );
			return;
		}

		self::stamp_version( $post_id );
	}

	/**
	 * Fill schema groups absent from an older grouped document using flat values.
	 *
	 * Existing groups are left untouched. Missing groups are taken from a legacy
	 * flat→grouped conversion so classic extension settings survive the next
	 * sanitize that materializes every schema group.
	 *
	 * @param array<string, array<string, mixed>> $v2   Existing grouped settings.
	 * @param array<string, mixed>                $flat Flat modula-album-settings.
	 * @return array<string, array<string, mixed>>
	 */
	private static function backfill_missing_groups_from_flat( array $v2, array $flat ) {
		$from_flat = Adapter::to_grouped(
			$flat,
			array(
				'legacy_import' => true,
			)
		);
		$schema = Registry::get_schema();
		foreach ( $schema as $group => $group_def ) {
			if ( ! is_string( $group ) || '' === $group || ! is_array( $group_def ) ) {
				continue;
			}
			if ( isset( $v2[ $group ] ) && is_array( $v2[ $group ] ) ) {
				continue;
			}
			if ( isset( $from_flat[ $group ] ) && is_array( $from_flat[ $group ] ) ) {
				$v2[ $group ] = $from_flat[ $group ];
			}
		}
		return Sanitizer::sanitize_grouped( $v2 );
	}

	/**
	 * Brand-new Beta album creation defaults (schema), never for open/convert of existing docs.
	 *
	 * @param int $post_id Album post ID.
	 * @return bool Whether the album was new and got the defaults; false for an album that already had settings, or a post that is no album.
	 */
	public static function apply_creation_defaults( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return false;
		}

		if ( self::is_current( $post_id ) ) {
			return false;
		}

		$v2   = Meta_Sync::get_settings_v2( $post_id );
		$flat = get_post_meta( $post_id, Meta_Sync::FLAT_META_KEY, true );
		if ( ! empty( $v2 ) || ( is_array( $flat ) && ! empty( $flat ) ) ) {
			self::ensure_migrated( $post_id );
			return false;
		}

		$grouped   = Adapter::to_grouped( array() );
		$sanitized = Sanitizer::sanitize_grouped( $grouped );
		Meta_Sync::save_settings_v2( $post_id, $sanitized );
		self::stamp_version( $post_id );
		return true;
	}

	/**
	 * Store a one-shot pre-migration backup when none exists yet.
	 *
	 * Used by classic save paths that write v2 outside {@see ensure_migrated()}.
	 *
	 * @param int $post_id Album post ID.
	 * @return void
	 */
	public static function backup_if_needed( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return;
		}
		$flat = get_post_meta( $post_id, Meta_Sync::FLAT_META_KEY, true );
		self::store_pre_migration_backup(
			$post_id,
			is_array( $flat ) ? $flat : array(),
			Meta_Sync::get_stored_settings_v2( $post_id )
		);
	}

	/**
	 * @param int                                 $post_id Album post ID.
	 * @param array<string, mixed>                $flat    Flat settings.
	 * @param array<string, array<string, mixed>> $v2      Grouped settings.
	 * @return void
	 */
	private static function store_pre_migration_backup( $post_id, array $flat, array $v2 ) {
		$existing = get_post_meta( $post_id, self::PRE_MIGRATION_META_KEY, true );
		if ( is_array( $existing ) && ! empty( $existing ) ) {
			return;
		}

		$payload = array(
			'version'   => self::DOCUMENT_VERSION,
			'flat'      => $flat,
			'grouped'   => $v2,
			'backed_up' => time(),
		);

		update_post_meta( $post_id, self::PRE_MIGRATION_META_KEY, $payload );
	}

	/**
	 * @param int $post_id Album post ID.
	 * @return void
	 */
	private static function stamp_version( $post_id ) {
		update_post_meta( $post_id, self::VERSION_META_KEY, self::DOCUMENT_VERSION );
	}
}
