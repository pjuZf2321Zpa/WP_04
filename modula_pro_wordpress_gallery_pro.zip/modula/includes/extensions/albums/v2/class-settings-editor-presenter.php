<?php
/**
 * Album settings editor export helpers (group labels for codegen).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Settings_Editor_Presenter
 */
class Settings_Editor_Presenter {

	/**
	 * @return array<string, string>
	 */
	public static function get_group_labels_for_export() {
		$doc = Settings_Schema_Document::get_document();
		$nav = isset( $doc['editorNavigation'] ) && is_array( $doc['editorNavigation'] ) ? $doc['editorNavigation'] : array();
		if ( ! empty( $nav['groupLabels'] ) && is_array( $nav['groupLabels'] ) ) {
			return $nav['groupLabels'];
		}
		return array();
	}
}
