<?php
/**
 * Album settings v2 meta sync (flat modula-album-settings ↔ modula_album_settings_v2).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

use Modula\V2\Settings\Sanitizer as Gallery_Sanitizer;

defined( 'ABSPATH' ) || exit;

/**
 * Class Meta_Sync
 */
class Meta_Sync {

	private static $canonical_writes = array();

	/** Keep metadata-only native writes from reimporting and normalizing unrelated settings. */
	public static function with_canonical_write( int $id, callable $callback ) {
		self::$canonical_writes[ $id ] = ( self::$canonical_writes[ $id ] ?? 0 ) + 1;
		try { return $callback(); }
		finally {
			--self::$canonical_writes[ $id ];
			if ( ! self::$canonical_writes[ $id ] ) { unset( self::$canonical_writes[ $id ] ); }
		}
	}


	const SETTINGS_V2_META_KEY = 'modula_album_settings_v2';

	const FLAT_META_KEY = 'modula-album-settings';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'save_post_modula-album', array( __CLASS__, 'on_save_album' ), 20, 2 );
		add_action( 'load-post.php', array( __CLASS__, 'on_load_post_for_v2_backfill' ) );
	}

	/**
	 * @return void
	 */
	public static function on_load_post_for_v2_backfill() {
		if ( ! is_admin() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0;
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		self::ensure_settings_v2_from_flat( $post_id );
	}

	/**
	 * Open/convert path: migrate existing flat (or stamp older grouped) with legacy defaults.
	 *
	 * @param int $post_id Album post ID.
	 * @return void
	 */
	public static function ensure_settings_v2_from_flat( $post_id ) {
		Settings_Migration::ensure_migrated( $post_id );
	}

	/**
	 * Brand-new Beta album only: schema creation defaults, then the create-only
	 * defaults: Member style Card with the card's title sizes (ADR 0057). An
	 * album that already has settings is left as it is.
	 * Written through Settings_Writer::patch(), so the flat copy carries them;
	 * a preset or settings applied after the create defaults win.
	 *
	 * Call from create paths — never from Convert to beta or Try the beta duplicate.
	 *
	 * @param int $post_id Album post ID.
	 * @return void
	 */
	public static function apply_new_beta_album_create_defaults( $post_id ) {
		// An album that already has settings keeps them: the create paths can run twice.
		if ( ! Settings_Migration::apply_creation_defaults( $post_id ) ) {
			return;
		}
		$stamped = Settings_Writer::patch( absint( $post_id ), Album_Member_Style::create_defaults() );
		if ( is_wp_error( $stamped ) ) {
			// The album keeps the schema defaults (Classic); the editor still offers Card.
			Debug_Log::log_persist_failure( absint( $post_id ), $stamped->get_error_code(), 'member style create stamp failed' );
		}
	}

	/**
	 * @param int     $post_id
	 * @param WP_Post $post
	 * @return void
	 */
	public static function on_save_album( $post_id, $post ) {
		if ( ! empty( self::$canonical_writes[ $post_id ] ) ) { return; }
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! $post || 'modula-album' !== $post->post_type ) {
			return;
		}
		$settings = get_post_meta( $post_id, self::FLAT_META_KEY, true );
		if ( is_array( $settings ) ) {
			if ( ! Settings_Migration::is_current( $post_id ) ) {
				Settings_Migration::backup_if_needed( $post_id );
			}
			self::sync_settings_v2(
				$post_id,
				$settings,
				array(
					'legacy_import' => true,
				)
			);
			update_post_meta( $post_id, Settings_Migration::VERSION_META_KEY, Settings_Migration::DOCUMENT_VERSION );
		}
	}

	/**
	 * @param int                  $post_id
	 * @param array<string, mixed> $flat
	 * @param array<string, mixed> $options {
	 *     Optional.
	 *
	 *     @type bool $legacy_import Merge classic defaults under `$flat` before convert.
	 * }
	 * @return void
	 */
	public static function sync_settings_v2( $post_id, array $flat, array $options = array() ) {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return;
		}
		$grouped   = self::with_read_dim_color( Adapter::to_grouped( $flat, $options ), self::get_settings_v2( $post_id ), $flat );
		$sanitized = Sanitizer::sanitize_grouped( $grouped );
		// update_post_meta() unslashes: unslashed JSON would lose its `\u` escapes and break on quotes.
		update_post_meta( $post_id, self::SETTINGS_V2_META_KEY, wp_slash( wp_json_encode( $sanitized ) ) );
	}

	/**
	 * A re-import from the flat copy (every save_post, the classic screen's
	 * included) keeps the Dim color as v2 reads it while the flat `hoverColor`
	 * is still its legacy projection (with_legacy_hover_color). The flat copy
	 * holds no alpha, so taking the color back from it would make a catalog
	 * hover darken at full strength. A color changed in the flat copy wins.
	 * An album preset reads its flat copy the same way (Preset_Storage).
	 *
	 * @param array<string, array<string, mixed>> $grouped Grouped settings imported from `$flat`.
	 * @param array<string, array<string, mixed>> $read    The v2 settings stored beside `$flat`: an album's
	 *                                                     as they read, a preset's as stored.
	 * @param array<string, mixed>                $flat    The flat copy being imported.
	 * @return array<string, array<string, mixed>>
	 */
	public static function with_read_dim_color( array $grouped, array $read, array $flat ) {
		$dim    = $read['hover']['hoverColor'] ?? null;
		$legacy = $flat['hoverColor'] ?? null;
		if ( ! is_string( $dim ) || ! is_string( $legacy ) ) {
			return $grouped;
		}
		if ( self::with_legacy_hover_color( array( 'hoverColor' => $dim ), array( 'hoverColor' => $legacy ) )['hoverColor'] !== $legacy ) {
			return $grouped;
		}
		$grouped['hover']['hoverColor'] = $dim;
		return $grouped;
	}

	/**
	 * The stored grouped settings, as they read: an album saved before the
	 * Motion settings reads explicit Motion values that play its classic hover
	 * (Album_Motion::with_existing_album_values), the filter defaults
	 * (Album_Filters::with_defaults), and a wiped filter list refilled from
	 * the members' names (Album_Filters::with_list_from_members). Nothing is
	 * written; the next save stores them.
	 *
	 * @param int  $post_id
	 * @param bool $repair  Refill a wiped filter list. False reads the list as
	 *                      stored, for confirming a write (as Lite's gallery read).
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_settings_v2( $post_id, $repair = true ) {
		$grouped = Album_Filters::with_defaults( Album_Motion::with_existing_album_values( self::get_stored_settings_v2( $post_id ) ) );
		if ( ! $repair ) {
			return $grouped;
		}
		return Album_Filters::with_list_from_members( $grouped, Members_Document::stored_members( $post_id ) );
	}

	/**
	 * The grouped settings exactly as stored, for migration backups.
	 *
	 * @param int $post_id
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_stored_settings_v2( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return array();
		}
		$raw = get_post_meta( $post_id, self::SETTINGS_V2_META_KEY, true );
		if ( is_string( $raw ) && '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}
		if ( is_array( $raw ) ) {
			return $raw;
		}
		return array();
	}

	/**
	 * Flat settings for a classic album screen save. That screen writes every
	 * field it renders, so stored keys it does not render (Albums editor only
	 * settings, inactive extensions) are kept instead of dropped.
	 *
	 * @param array<string, mixed> $classic    Settings built from the classic form.
	 * @param mixed                $prior_flat Previously stored flat meta.
	 * @return array<string, mixed>
	 */
	public static function merge_classic_save( array $classic, $prior_flat ) {
		if ( ! is_array( $prior_flat ) ) {
			return $classic;
		}
		return array_merge( array_diff_key( $prior_flat, $classic ), $classic );
	}

	/**
	 * Project schema-owned grouped settings to flat, then re-attach unmapped
	 * keys from the prior flat document (inactive extensions / integrations).
	 *
	 * Opaque keys are server-owned: they only come from `$prior_flat`, never
	 * from the grouped projection alone.
	 *
	 * @param array<string, array<string, mixed>> $grouped    Sanitized grouped settings.
	 * @param array<string, mixed>                $prior_flat Previously stored flat meta.
	 * @return array<string, mixed>
	 */
	public static function project_flat_preserving_opaque( array $grouped, array $prior_flat ) {
		$projected = self::with_legacy_hover_color( Adapter::to_flat( $grouped ), $prior_flat );
		$map       = Field_Registry::get_flat_to_grouped_mapping();
		foreach ( $prior_flat as $key => $value ) {
			if ( ! is_string( $key ) || '' === $key ) {
				continue;
			}
			if ( isset( $map[ $key ] ) ) {
				continue;
			}
			$projected[ $key ] = $value;
		}
		return $projected;
	}

	/**
	 * The flat copy's `hoverColor` is what the classic album screen and
	 * shortcode read: a hex color behind the cover (`sanitize_hex_color`),
	 * darkened by `hoverOpacity`. The v2 document stores the gallery's Dim
	 * color, alpha included (album ticket 25), so the projection keeps the
	 * prior flat value while the Dim color still has its color (the migration
	 * only added an alpha) and otherwise writes the Dim color's hex without
	 * the alpha. The classic visitor then shows what it showed before.
	 *
	 * @param array<string, mixed> $flat       Flat projection of the v2 document.
	 * @param array<string, mixed> $prior_flat Previously stored flat meta.
	 * @return array<string, mixed>
	 */
	public static function with_legacy_hover_color( array $flat, array $prior_flat ) {
		if ( ! isset( $flat['hoverColor'] ) || ! is_string( $flat['hoverColor'] ) ) {
			return $flat;
		}
		$dim_hex = Gallery_Sanitizer::opaque_hex( $flat['hoverColor'] );
		if ( null === $dim_hex ) {
			return $flat;
		}
		$prior              = $prior_flat['hoverColor'] ?? null;
		$flat['hoverColor'] = is_string( $prior ) && self::legacy_hex( $prior ) === $dim_hex ? $prior : $dim_hex;
		return $flat;
	}

	/**
	 * The color a stored flat `hoverColor` stands for in the Dim color: its
	 * hex, or black when it can't be read, as the migration darkens it
	 * (Album_Motion::UNREADABLE_DIM_COLOR).
	 *
	 * @param string $legacy Stored flat `hoverColor`.
	 * @return string Lowercase `#rrggbb`.
	 */
	private static function legacy_hex( string $legacy ) {
		return Gallery_Sanitizer::opaque_hex( $legacy ) ?? Album_Motion::UNREADABLE_DIM_COLOR;
	}

	/**
	 * @param int                                 $post_id
	 * @param array<string, array<string, mixed>> $grouped
	 * @return void
	 */
	public static function save_settings_v2( $post_id, array $grouped ) {
		$post_id   = absint( $post_id );
		$sanitized = Sanitizer::sanitize_grouped( $grouped );
		// update_post_meta() unslashes: slash the JSON (its `\u` escapes, quotes) and the flat strings.
		update_post_meta( $post_id, self::SETTINGS_V2_META_KEY, wp_slash( wp_json_encode( $sanitized ) ) );
		$prior = get_post_meta( $post_id, self::FLAT_META_KEY, true );
		$flat  = self::project_flat_preserving_opaque(
			$sanitized,
			is_array( $prior ) ? $prior : array()
		);
		update_post_meta( $post_id, self::FLAT_META_KEY, wp_slash( $flat ) );
		update_post_meta( $post_id, Settings_Migration::VERSION_META_KEY, Settings_Migration::DOCUMENT_VERSION );
	}
}
