<?php
/**
 * Album settings v2 registry.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Registry
 */
class Registry {

	/**
	 * @var array<string, array<string, array>>|null
	 */
	private static $schema = null;

	/**
	 * @return array<string, array<string, array>>
	 */
	public static function get_schema() {
		if ( null !== self::$schema ) {
			return self::$schema;
		}
		$raw = Settings_Schema_Document::strip_editor_presentation_keys_from_settings(
			Settings_Schema_Document::get_settings_tree_raw()
		);
		/**
		 * Filter album v2 settings schema (extensions).
		 *
		 * @param array $schema Group => key => definition.
		 */
		self::$schema = apply_filters( 'modula_v2_album_settings_schema', $raw );
		return self::$schema;
	}

	/**
	 * @param string $group
	 * @param string $key
	 * @return array{type?: string, default?: mixed, enum?: array}|null
	 */
	public static function get_key_definition( $group, $key ) {
		$schema = self::get_schema();
		if ( ! isset( $schema[ $group ][ $key ] ) || ! is_array( $schema[ $group ][ $key ] ) ) {
			return null;
		}
		$def = $schema[ $group ][ $key ];
		$out = array();
		if ( isset( $def['type'] ) ) {
			$out['type'] = $def['type'];
		}
		if ( array_key_exists( 'default', $def ) ) {
			$out['default'] = $def['default'];
		}
		if ( ! empty( $def['enum'] ) && is_array( $def['enum'] ) ) {
			$out['enum'] = $def['enum'];
		}
		if ( isset( $def['minimum'] ) ) {
			$out['minimum'] = $def['minimum'];
		}
		if ( isset( $def['maximum'] ) ) {
			$out['maximum'] = $def['maximum'];
		}
		return $out;
	}
}
