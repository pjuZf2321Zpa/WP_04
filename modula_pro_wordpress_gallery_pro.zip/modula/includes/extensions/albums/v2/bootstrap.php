<?php
/**
 * Albums v2 bootstrap (load classes).
 *
 * @package Modula_Pro
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-field-registry.php';
require_once __DIR__ . '/class-lightbox-visitor-config.php';
require_once __DIR__ . '/class-album-member-style.php';
require_once __DIR__ . '/class-album-motion.php';
require_once __DIR__ . '/class-album-filters.php';
require_once __DIR__ . '/class-settings-schema-document.php';
require_once __DIR__ . '/class-registry.php';
require_once __DIR__ . '/class-adapter.php';
require_once __DIR__ . '/class-sanitizer.php';
require_once __DIR__ . '/class-responsive-breakpoints.php';
require_once __DIR__ . '/class-album-sections.php';
require_once __DIR__ . '/class-settings-migration.php';
require_once __DIR__ . '/class-meta-sync.php';
require_once __DIR__ . '/class-settings-replacement.php';
require_once __DIR__ . '/class-settings-writer.php';
require_once __DIR__ . '/class-members-document.php';
require_once __DIR__ . '/class-album-member-counts.php';
require_once __DIR__ . '/class-album-member-strip.php';
require_once __DIR__ . '/class-debug-log.php';
require_once __DIR__ . '/class-album-sorting.php';
require_once __DIR__ . '/class-album-post.php';
require_once __DIR__ . '/class-settings-editor-presenter.php';
require_once __DIR__ . '/class-albums-schema-exporter.php';
require_once __DIR__ . '/rest/class-album-settings-controller.php';
require_once __DIR__ . '/rest/class-album-members-controller.php';
require_once __DIR__ . '/admin/class-album-takeover-admin.php';
require_once __DIR__ . '/admin/class-albums-editor-enqueue.php';
require_once __DIR__ . '/visitor/class-payload.php';
require_once __DIR__ . '/visitor/class-renderer.php';
require_once __DIR__ . '/visitor/class-dispatcher.php';
require_once dirname( __DIR__ ) . '/abilities/class-album-executor.php';
require_once dirname( __DIR__ ) . '/abilities/class-member-executor.php';
require_once dirname( __DIR__ ) . '/abilities/class-lifecycle-executor.php';
require_once dirname( __DIR__ ) . '/abilities/class-provider.php';
