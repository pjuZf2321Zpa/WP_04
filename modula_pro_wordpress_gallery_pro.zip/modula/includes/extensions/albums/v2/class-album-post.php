<?php
/**
 * New-album promotion out of auto-draft.
 *
 * Mirrors Lite's `Gallery_Post::ensure_persistable()` status and title rule. It
 * lives in Pro because Compatible Pro supports Lite releases that predate any
 * shared helper.
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * Class Album_Post
 */
class Album_Post {

	public const POST_TYPE = 'modula-album';

	/**
	 * @return void
	 */
	public static function init() {
		add_filter( 'rest_pre_insert_' . self::POST_TYPE, array( __CLASS__, 'promote_rest_insert' ), 10, 2 );
		add_filter( 'rest_prepare_' . self::POST_TYPE, array( __CLASS__, 'add_rest_status_meta' ), 10, 3 );
	}

	/**
	 * After a successful Albums editor v2 write: mark the album Beta, then promote it.
	 *
	 * The mark comes first, so a failed promotion still leaves the album Beta:
	 * the data already saved is the editor's.
	 *
	 * @param int    $post_id  Album post ID.
	 * @param string $resource v2 route segment for failure logs (`settings`, `members`, `sorting`).
	 * @return array{postStatus: string, postStatusLabel: string}|\WP_Error Status fields for the response.
	 */
	public static function finish_editor_write( $post_id, $resource ) {
		self::mark_saved_in_editor( $post_id );
		return self::promote_after_write( $post_id, $resource );
	}

	/**
	 * The Albums editor and the Album visitor frontend go together (Lite ADR 0053):
	 * an album saved in the editor stores `_modula_beta`, so its visitor renders
	 * what the canvas shows. Only the editor's v2 writes call this; opening the
	 * editor, core REST writes and abilities store nothing, as for a gallery.
	 *
	 * @param int $post_id Album post ID.
	 * @return void
	 */
	private static function mark_saved_in_editor( $post_id ) {
		if ( ! class_exists( '\Modula\V2\Beta_Settings' ) ) {
			return;
		}
		// Force-OFF stays a no-op: a REST write that slips past the closed editor marks nothing.
		if ( ! Admin\Album_Takeover_Admin::is_takeover_enabled_for( $post_id ) ) {
			return;
		}
		\Modula\V2\Beta_Settings::mark_as_beta_album( $post_id );
	}

	/**
	 * Promote an auto-draft album after a successful Albums editor v2 write.
	 *
	 * WordPress lists no auto-drafts, so an album written only through the v2
	 * endpoints would vanish from the listing. Promotion runs after the write so
	 * a rejected write cannot publish the album. The write is not atomic with
	 * it: on failure the saved data stays and the error asks the editor to
	 * retry, and the retry promotes.
	 *
	 * @param int    $post_id  Album post ID.
	 * @param string $resource v2 route segment for failure logs (`settings`, `members`, `sorting`).
	 * @return array{postStatus: string, postStatusLabel: string}|\WP_Error Status fields for the response.
	 */
	public static function promote_after_write( $post_id, $resource ) {
		$promoted = self::ensure_persistable( $post_id );
		if ( is_wp_error( $promoted ) ) {
			Debug_Log::log_persist_failure( $post_id, $promoted->get_error_code(), "album promote after {$resource} save failed", $resource );
			return $promoted;
		}

		return self::rest_response_meta( $promoted );
	}

	/**
	 * @param int $post_id Album post ID.
	 * @return int|\WP_Error Album ID; unchanged unless it was an auto-draft.
	 */
	public static function ensure_persistable( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || self::POST_TYPE !== get_post_type( $post_id ) ) {
			return new \WP_Error(
				'modula_invalid_album',
				__( 'Invalid album.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you are not allowed to edit this album.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return new \WP_Error(
				'rest_not_found',
				__( 'Album not found.', 'modula-pro' ),
				array( 'status' => 404 )
			);
		}

		if ( 'auto-draft' !== $post->post_status ) {
			return $post_id;
		}

		$updated = wp_update_post(
			array(
				'ID'          => $post_id,
				'post_status' => self::promoted_status( $post_id ),
				'post_title'  => self::persistable_title( $post_id, (string) $post->post_title ),
			),
			true
		);

		return is_wp_error( $updated ) ? $updated : $post_id;
	}

	/**
	 * `rest_pre_insert_modula-album`: a core REST write on an auto-draft (the
	 * editor's title PUT) also promotes it.
	 *
	 * An explicit `status` in the request wins; saved albums keep their status.
	 *
	 * @param \stdClass                             $prepared_post Post prepared for the database.
	 * @param \WP_REST_Request|array<string, mixed> $request       REST request.
	 * @return \stdClass
	 */
	public static function promote_rest_insert( $prepared_post, $request ) {
		$post_id = isset( $prepared_post->ID ) ? absint( $prepared_post->ID ) : 0;
		$post    = $post_id ? get_post( $post_id ) : null;
		if ( ! $post || isset( $request['status'] ) || 'auto-draft' !== $post->post_status ) {
			return $prepared_post;
		}

		$prepared_post->post_status = self::promoted_status( $post_id );
		$title                      = isset( $prepared_post->post_title ) ? (string) $prepared_post->post_title : (string) $post->post_title;
		$prepared_post->post_title  = self::persistable_title( $post_id, $title );
		return $prepared_post;
	}

	/**
	 * `rest_prepare_modula-album`: add the editor's status fields in edit context.
	 *
	 * @param \WP_REST_Response $response REST response.
	 * @param \WP_Post          $post     Album post.
	 * @param \WP_REST_Request  $request  REST request.
	 * @return \WP_REST_Response
	 */
	public static function add_rest_status_meta( $response, $post, $request ) {
		if ( 'edit' !== $request['context'] ) {
			return $response;
		}

		$response->set_data( array_merge( $response->get_data(), self::rest_response_meta( $post->ID ) ) );
		return $response;
	}

	/**
	 * REST payload fragment the editor top bar adopts after a write.
	 *
	 * @param int $post_id Album post ID.
	 * @return array{postStatus: string, postStatusLabel: string}
	 */
	public static function rest_response_meta( $post_id ) {
		$status = get_post_status( absint( $post_id ) );
		$status = is_string( $status ) ? $status : '';
		$object = '' !== $status ? get_post_status_object( $status ) : null;

		return array(
			'postStatus'      => $status,
			'postStatusLabel' => ( is_object( $object ) && ! empty( $object->label ) ) ? $object->label : $status,
		);
	}

	/**
	 * @param int $post_id Album post ID.
	 * @return string `publish` when the user may publish, otherwise `draft`; filterable.
	 */
	private static function promoted_status( $post_id ) {
		$status = current_user_can( 'publish_post', $post_id ) ? 'publish' : 'draft';

		/**
		 * Status used when promoting a new album from auto-draft on its first editor write.
		 *
		 * @param string $status  `publish` or `draft`.
		 * @param int    $post_id Album post ID.
		 */
		return apply_filters( 'modula_album_auto_promote_status', $status, $post_id );
	}

	/**
	 * @param int    $post_id Album post ID.
	 * @param string $title   Stored or incoming title.
	 * @return string The title, or "Album #ID" for a placeholder.
	 */
	private static function persistable_title( $post_id, $title ) {
		$title = trim( $title );
		// phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- matches core's auto-draft title.
		if ( '' !== $title && __( 'Auto Draft', 'default' ) !== $title ) {
			return $title;
		}

		/* translators: %d: album post ID */
		return sprintf( __( 'Album #%d', 'modula-pro' ), $post_id );
	}
}
