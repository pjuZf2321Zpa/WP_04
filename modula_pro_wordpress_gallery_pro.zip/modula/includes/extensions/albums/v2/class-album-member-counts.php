<?php
/**
 * An album member's counts per kind, for the album member card's badge and
 * meta line (album-member-card ticket 02, Lite ADR 0057).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

defined( 'ABSPATH' ) || exit;

/**
 * One helper for the Album visitor frontend (`Visitor\Payload`) and the
 * Albums editor's members response, so the visitor and the canvas count the
 * same:
 * - a gallery: its items by kind, as the content page counts them (Lite
 *   `Listing_Gallery_Item_Counts`, the classic catalog, else the v2 one);
 * - a nested album: its galleries and albums (its counted members), and its
 *   photos summed over every counted gallery under it, at any depth, each
 *   gallery once. A cycle (A → B → A) ends at an album already visited, as
 *   `modula_get_album_cover_id()` does.
 *
 * A member counts when the visitor may see it (`Members_Document::is_visitor_readable_member()`:
 * not trashed, published or readable) and has no password: a protected
 * gallery or album opens behind its form, so its items don't show.
 */
final class Album_Member_Counts {

	/**
	 * Photos per gallery ID, for this request: a gallery under several
	 * nested albums is read once.
	 *
	 * @var array<int, int>
	 */
	private static $gallery_photos = array();

	/**
	 * @param string $item_type `modula-gallery` or `modula-album`.
	 * @param int    $id        Member post ID.
	 * @return array<string, int>|null Gallery: `photos`, `videos`, `blocks`, `shortcodes`; album: `galleries`, `albums`, `photos`. Null when Lite's listing helper is unavailable.
	 */
	public static function for_member( $item_type, $id ) {
		if ( ! class_exists( '\Modula\V2\Rest\Listing_Gallery_Item_Counts' ) ) {
			return null;
		}
		return 'modula-album' === $item_type
			? self::album_counts( absint( $id ) )
			: self::gallery_counts( absint( $id ) );
	}

	/**
	 * @param int $gallery_id Gallery ID.
	 * @return array{photos: int, videos: int, blocks: int, shortcodes: int}
	 */
	private static function gallery_counts( $gallery_id ) {
		$counts = \Modula\V2\Rest\Listing_Gallery_Item_Counts::count_rows( self::gallery_catalog( $gallery_id ) );
		return array(
			'photos'     => $counts['images'],
			'videos'     => $counts['videos'],
			'blocks'     => $counts['blocks'],
			'shortcodes' => $counts['shortcodes'],
		);
	}

	/**
	 * The catalog the content page counts: classic `modula-images` when it has
	 * rows, else the v2 images.
	 *
	 * @param int $gallery_id Gallery ID.
	 * @return array<int, array<string, mixed>>
	 */
	private static function gallery_catalog( $gallery_id ) {
		$classic = get_post_meta( $gallery_id, 'modula-images', true );
		$v2      = array();
		if ( ( ! is_array( $classic ) || empty( $classic ) ) && class_exists( '\Modula\V2\Meta_Sync' ) ) {
			$v2 = \Modula\V2\Meta_Sync::get_images_v2( $gallery_id );
		}
		return \Modula\V2\Rest\Listing_Gallery_Item_Counts::select_catalog( $classic, $v2 );
	}

	/**
	 * @param int $album_id Nested album ID.
	 * @return array{galleries: int, albums: int, photos: int}
	 */
	private static function album_counts( $album_id ) {
		$counts  = array(
			'galleries' => 0,
			'albums'    => 0,
			'photos'    => 0,
		);
		$members = self::counted_members( $album_id );
		foreach ( $members as $member ) {
			$kind = self::is_album_member( $member ) ? 'albums' : 'galleries';
			++$counts[ $kind ];
		}
		$counts['photos'] = array_sum( self::photos_by_gallery( $album_id, array() ) );
		return $counts;
	}

	/**
	 * Photos of every counted gallery under an album, at any depth.
	 *
	 * @param int        $album_id Album ID.
	 * @param array<int> $visited  Albums already walked (cycle guard).
	 * @return array<int, int> Photos keyed by gallery ID, so a gallery counts once.
	 */
	private static function photos_by_gallery( $album_id, array $visited ) {
		if ( in_array( $album_id, $visited, true ) ) {
			return array();
		}
		$visited[] = $album_id;

		$photos = array();
		foreach ( self::counted_members( $album_id ) as $member ) {
			$id = absint( $member['id'] );
			if ( self::is_album_member( $member ) ) {
				$photos += self::photos_by_gallery( $id, $visited );
				continue;
			}
			$photos[ $id ] = self::gallery_photos( $id );
		}
		return $photos;
	}

	/**
	 * @param int $gallery_id Gallery ID.
	 * @return int Its photos, read once per request.
	 */
	private static function gallery_photos( $gallery_id ) {
		if ( ! isset( self::$gallery_photos[ $gallery_id ] ) ) {
			self::$gallery_photos[ $gallery_id ] = self::gallery_counts( $gallery_id )['photos'];
		}
		return self::$gallery_photos[ $gallery_id ];
	}

	/**
	 * An album's members that count: readable by the visitor, with no
	 * password, in album order. The card's thumbnail strip shows the same
	 * members (`Album_Member_Strip`).
	 *
	 * @param int $album_id Album ID.
	 * @return list<array<string, mixed>>
	 */
	public static function counted_members( $album_id ) {
		$readable = Members_Document::visitor_readable_members( get_post_meta( $album_id, 'modula-album-galleries', true ) );
		return array_values(
			array_filter(
				$readable,
				static function ( array $member ) {
					return '' === (string) get_post_field( 'post_password', absint( $member['id'] ) );
				}
			)
		);
	}

	/**
	 * @param array<string, mixed> $member Stored member.
	 * @return bool Whether it is a nested album (a missing type is a gallery).
	 */
	private static function is_album_member( array $member ) {
		return 'modula-album' === ( $member['itemType'] ?? '' );
	}
}
