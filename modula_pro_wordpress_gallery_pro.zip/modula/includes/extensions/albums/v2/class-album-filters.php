<?php
/**
 * Album filters: the filter list and filter bar settings an album defines for
 * its own members (album-editor-1to1 ticket 22).
 *
 * @package Modula_Pro
 */

namespace Modula_Pro\Extensions\Albums\V2;

use Modula\V2\Settings\Field_Registry as Gallery_Field_Registry;
use Modula\V2\Settings\Settings_Schema_Document as Gallery_Settings_Schema_Document;

defined( 'ABSPATH' ) || exit;

/**
 * The album `filters` group is the gallery's (Lite), key for key: types,
 * defaults, enums, controls, and the flat names the keys are dual-written
 * under. Read from the gallery's document, so the two never drift. The album
 * keeps every key the gallery editor shows (not the reload on click, which it
 * hides), drops the Lite locks (albums are Pro only) and has its own copy
 * where the gallery's names images or the gallery.
 */
final class Album_Filters {

	const GROUP = 'filters';

	/**
	 * Presentation keys of the gallery's Lite locks.
	 *
	 * @var string[]
	 */
	const LITE_LOCK_KEYS = array( 'editorShowInLite', 'editorOmitControlInLite', 'editorLightboxLiteUpsell' );

	/**
	 * The album's copy, over the gallery's: an album filter is carried by
	 * galleries and albums, not images.
	 *
	 * @var array<string, array<string, string>>
	 */
	const COPY = array(
		'filters'           => array(
			'editorDescription' => 'The number is how many galleries and albums carry that filter. Empty filters will not show up in the bar.',
		),
		'showFilterCount'   => array(
			'editorLabel'       => 'Show the count on each filter',
			'editorDescription' => 'Shows how many galleries and albums carry that filter, next to the filter name.',
		),
		'allFilterLabel'    => array(
			'editorDescription' => 'Text on the button that shows every gallery and album.',
		),
		'filterPositioning' => array(
			'editorDescription' => 'Where the filter bar sits relative to the album.',
		),
	);

	/**
	 * The `filters` group of the album settings document, in the gallery's order.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function settings() {
		$gallery = Gallery_Settings_Schema_Document::get_settings_tree_raw()[ self::GROUP ] ?? array();
		$out     = array();
		foreach ( $gallery as $key => $definition ) {
			if ( ! self::is_shown_in_gallery_editor( $definition ) ) {
				continue;
			}
			$out[ $key ] = array_merge(
				array_diff_key( $definition, array_flip( self::LITE_LOCK_KEYS ) ),
				self::COPY[ $key ] ?? array()
			);
		}
		return $out;
	}

	/**
	 * The settings as they read: an album saved before the filter settings
	 * reads their defaults, so the editor and the abilities see every key.
	 * Nothing is written; the next save stores them. An empty document (not
	 * yet migrated) stays empty.
	 *
	 * @param array<string, array<string, mixed>> $grouped Stored grouped settings.
	 * @return array<string, array<string, mixed>>
	 */
	public static function with_defaults( array $grouped ) {
		if ( array() === $grouped ) {
			return $grouped;
		}
		$stored = isset( $grouped[ self::GROUP ] ) && is_array( $grouped[ self::GROUP ] ) ? $grouped[ self::GROUP ] : array();
		foreach ( self::settings() as $key => $definition ) {
			if ( ! array_key_exists( $key, $stored ) && array_key_exists( 'default', $definition ) ) {
				$stored[ $key ] = $definition['default'];
			}
		}
		$grouped[ self::GROUP ] = $stored;
		return $grouped;
	}

	/**
	 * A wiped list reads back from the names the album's members carry, as a
	 * gallery's list does from its images' (Lite's repair). A save that
	 * removes names takes them off the members first, so only a list wiped
	 * some other way (Apply preset) is refilled. Nothing is written; the next
	 * save stores the list.
	 *
	 * @param array<string, array<string, mixed>> $grouped Grouped settings as they read.
	 * @param list<array<string, mixed>>          $members The album's stored members.
	 * @return array<string, array<string, mixed>>
	 */
	public static function with_list_from_members( array $grouped, array $members ) {
		if ( ! isset( $grouped[ self::GROUP ] ) || ! is_array( $grouped[ self::GROUP ] ) ) {
			return $grouped;
		}
		$repair = modula_maybe_repair_gallery_filter_list( $grouped[ self::GROUP ]['filters'] ?? array( '' ), $members );
		if ( $repair['repaired'] ) {
			$grouped[ self::GROUP ]['filters'] = $repair['list'];
		}
		return $grouped;
	}

	/**
	 * Flat `modula-album-settings` key => grouped key, under the gallery's flat names.
	 *
	 * @return array<string, array{group: string, key: string}>
	 */
	public static function flat_to_grouped() {
		$keys = self::settings();
		$out  = array();
		foreach ( Gallery_Field_Registry::get_flat_to_grouped_mapping() as $flat_key => $entry ) {
			if ( self::GROUP === $entry['group'] && isset( $keys[ $entry['key'] ] ) ) {
				$out[ $flat_key ] = $entry;
			}
		}
		return $out;
	}

	/**
	 * A stored gallery setting the gallery editor has a row for: not a
	 * presentation-only heading, not kept out of the settings panel.
	 *
	 * @param mixed $definition Gallery field definition.
	 * @return bool
	 */
	private static function is_shown_in_gallery_editor( $definition ) {
		return is_array( $definition )
			&& empty( $definition['editorPresentationOnly'] )
			&& empty( $definition['editorOmitFromSettingsSidebar'] );
	}
}
