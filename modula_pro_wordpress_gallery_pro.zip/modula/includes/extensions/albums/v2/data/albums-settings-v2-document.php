<?php
/**
 * Modula albums settings v2 document — PHP source of truth for types, defaults, and editor metadata.
 * Generated JSON for the React app: includes/extensions/albums/apps/albums-editor/generated/modula-albums-schema-v2.json.
 *
 * @package Modula_Pro
 */

$editor_navigation = require __DIR__ . '/albums-settings-v2-editor-navigation.php';

// `general.albumType` values; the Motion recommendations are keyed by them.
$modula_album_types = array( 'grid', 'custom-grid', 'slider' );

return array(
	'$schema'           => 'https://json-schema.org/draft/2020-12/schema',
	'$id'               => 'modula-album-settings-v2',
	'title'             => 'Modula Album Settings v2',
	'description'       => 'Grouped album settings for modula-album CPT.',
	'version'           => '2.0.0',
	'editorNavigation'  => $editor_navigation,
	'settings'          => array(
		'general'     => array(
			'albumType'            => array(
				'type'             => 'string',
				'enum'             => $modula_album_types,
				'default'          => 'grid',
				'editorLabel'      => 'Type',
				'enumOptionLabels' => array(
					'grid'        => 'Grid',
					'custom-grid' => 'Custom grid',
					'slider'      => 'Slider',
				),
				'proEnhancements'  => array(
					'extensionBased' => array(
						'modula-slider' => array( 'slider' ),
					),
				),
			),
			// The album member style (Lite ADR 0057). Classic by default, so an
			// existing album keeps its tiles; new Beta albums are stamped Card
			// (Album_Member_Style::create_defaults). Grid and Custom grid offer it.
			// `description` is what the abilities and MCP read.
			'memberStyle'          => array(
				'type'              => 'string',
				'enum'              => \Modula_Pro\Extensions\Albums\V2\Album_Member_Style::choices(),
				'default'           => \Modula_Pro\Extensions\Albums\V2\Album_Member_Style::CLASSIC,
				'description'       => 'How the album draws its galleries and nested albums: "classic" as gallery tiles, "card" as cards with the cover on top and the title, caption and counts under it; a nested album\'s card also shows its galleries as a badge and a strip of what is inside. Grid and Custom grid albums only. Existing albums stay on Classic; new albums start on Card.',
				'editorLabel'       => 'Member style',
				'editorDescription' => 'Classic draws each gallery and album as a tile. Card draws it as a card with its title, caption and counts under the cover.',
				'enumOptionLabels'  => array(
					'classic' => 'Classic',
					'card'    => 'Card',
				),
			),
			// The album member card's look, while Member style is Card. Its title
			// and caption keep the album's caption colors and sizes.
			'memberCardBackground' => array(
				'type'          => 'string',
				'default'       => '#ffffff',
				'description'   => 'The card\'s background color while Member style is Card: hex or rgba.',
				'editorLabel'   => 'Card background',
				'editorControl' => array(
					'kind'        => 'color',
					'acceptAlpha' => true,
				),
			),
			'memberCardRadius'     => array(
				'type'          => 'integer',
				'default'       => 16,
				'minimum'       => 0,
				'maximum'       => 100,
				'description'   => 'The card\'s corner radius in px while Member style is Card.',
				'editorLabel'   => 'Corner radius',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'memberCardShadow'     => array(
				'type'        => 'boolean',
				'default'     => true,
				'description' => 'Whether the card casts a soft shadow while Member style is Card.',
				'editorLabel' => 'Card shadow',
			),
			'mergeItems'           => array(
				'type'          => 'boolean',
				'default'       => false,
				'editorLabel'   => 'Merge galleries and albums',
			),
			'albumsTitleLabel'     => array(
				'type'        => 'string',
				'default'     => 'Albums',
				'editorLabel' => 'Change "Albums" label',
			),
			'galleriesTitleLabel'  => array(
				'type'        => 'string',
				'default'     => 'Galleries',
				'editorLabel' => 'Change "Galleries" label',
			),
			'maxGalleriesCount'    => array(
				'type'          => 'integer',
				'default'       => 0,
				'minimum'       => 0,
				'editorLabel'   => 'Galleries to show',
				// The slider stops at 50 (the design's range); the stored value
				// has no maximum, so a larger one is read out and kept as it is.
				// 0 reads "All" (`patches/galleryLayout.js`).
				'editorControl' => array(
					'kind' => 'range',
					'min'  => 0,
					'max'  => 50,
					'step' => 1,
				),
			),
			'columns'              => array(
				'type'             => 'string',
				'enum'             => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12' ),
				'default'          => '3',
				'editorLabel'      => 'Columns',
				'enumOptionLabels' => array(
					'1'  => '1 column',
					'2'  => '2 columns',
					'3'  => '3 columns',
					'4'  => '4 columns',
					'5'  => '5 columns',
					'6'  => '6 columns',
					'7'  => '7 columns',
					'8'  => '8 columns',
					'9'  => '9 columns',
					'10' => '10 columns',
					'11' => '11 columns',
					'12' => '12 columns',
				),
			),
			'albumWidth'           => array(
				'type'             => 'string',
				'enum'             => array( 'auto', 'full', 'custom' ),
				'default'          => 'auto',
				'editorLabel'      => 'Album width',
				'enumOptionLabels' => array(
					'auto'   => 'Auto',
					'full'   => 'Full',
					'custom' => 'Custom',
				),
			),
			'width'                => array(
				'type'        => 'string',
				'default'     => '100%',
				'editorLabel' => 'Custom width',
			),
			'uploadPosition'       => array(
				'type'             => 'string',
				'enum'             => array( 'start', 'end' ),
				'default'          => 'end',
				'editorLabel'      => 'New items position',
				'enumOptionLabels' => array(
					'start' => 'Start',
					'end'   => 'End',
				),
			),
			'inheritFromParent'    => array(
				'type'                    => 'boolean',
				'default'                 => false,
				'editorLabel'             => 'Inherit from parent',
				'editorOmitFromSettingsSidebar' => true,
			),
			'helpergrid'           => array(
				'type'                    => 'boolean',
				'default'                 => false,
				'editorOmitFromSettingsSidebar' => true,
			),
		),
		'layout'      => array(
			'gutter'            => array(
				'type'          => 'integer',
				'default'       => 10,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Desktop',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'tabletGutter'      => array(
				'type'          => 'integer',
				'default'       => 10,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Tablet',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'mobileGutter'      => array(
				'type'          => 'integer',
				'default'       => 10,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Mobile',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'imageSize'         => array(
				'type'        => 'string',
				'default'     => 'medium',
				'editorLabel' => 'Image file size',
			),
			'imageDimensions'   => array(
				'type'       => 'object',
				'default'    => array(
					'width'  => 0,
					'height' => 0,
				),
				'properties' => array(
					'width'  => array( 'type' => 'integer' ),
					'height' => array( 'type' => 'integer' ),
				),
				'editorLabel' => 'Custom dimensions',
			),
			'cropImages'        => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Crop images to fit',
			),
			'shuffleGalleries'  => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Shuffle galleries and albums',
			),
		),
		'navigation'  => array(
			'backToAlbumButton' => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Back to album button',
			),
			'albumsNavigation'  => array(
				'type'             => 'string',
				'enum'             => array( 'above', 'below', 'above_below' ),
				'default'          => 'below',
				'editorLabel'      => 'Albums navigation position',
				'enumOptionLabels' => array(
					'above'       => 'Above',
					'below'       => 'Below',
					'above_below' => 'Above & below',
				),
			),
		),
		'lightbox'    => array(
			'enableLightbox'          => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Enable lightbox',
			),
			'enableNavigation'        => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Prev and next arrows',
			),
			'doubleClick'             => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Mobile requires double-tap',
			),
			'loopLightbox'            => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Loop images',
			),
			'showImageTitle'          => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Show title',
			),
			'showImageCaption'        => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Show caption',
			),
			'captionPosition'         => array(
				'type'             => 'string',
				'enum'             => array( 'left', 'right', 'center' ),
				'default'          => 'left',
				'editorLabel'      => 'Position',
				'enumOptionLabels' => array(
					'left'   => 'Left',
					'right'  => 'Right',
					'center' => 'Center',
				),
			),
			'lightboxToolbar'         => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Show toolbar',
			),
			'lightboxClose'           => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Show close button',
			),
			'enableThumbs'            => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Thumbnails button',
			),
			'enableDownload'          => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Download button',
			),
			'enableZoom'              => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Zoom button',
			),
			'enablePlay'              => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Play button',
			),
			'enableShare'             => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Share button',
			),
			'lightboxFacebook'        => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Facebook',
			),
			'lightboxTwitter'         => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'X',
			),
			'lightboxWhatsapp'        => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'WhatsApp',
			),
			'lightboxLinkedin'        => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'LinkedIn',
			),
			'lightboxPinterest'       => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Pinterest',
			),
			'lightboxEmail'           => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Email',
			),
			'lightboxEmailSubject'    => array(
				'type'        => 'string',
				'default'     => 'Check out this awesome album !!',
				'editorLabel' => 'Email subject',
			),
			'lightboxEmailMessage'    => array(
				'type'        => 'string',
				'default'     => 'Here is the link to the image : %%image_link%% and this is the link to the gallery : %%gallery_link%%',
				'editorLabel' => 'Email message',
			),
			'lightboxInfobar'         => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Image counter',
			),
			'animationEffect'         => array(
				'type'             => 'string',
				'enum'             => array( 'false', 'fade', 'zoom', 'zoom-in-out' ),
				'default'          => 'false',
				'editorLabel'      => 'Animation',
				'enumOptionLabels' => array(
					'false'       => 'None',
					'fade'        => 'Fade',
					'zoom'        => 'Zoom',
					'zoom-in-out' => 'Zoom in/out',
				),
			),
			'transitionEffect'        => array(
				'type'             => 'string',
				'enum'             => array( 'fade', 'crossfade', 'slide', 'classic' ),
				'default'          => 'fade',
				'editorLabel'      => 'How one image becomes the next',
				'enumOptionLabels' => array(
					'fade'      => 'Fade',
					'crossfade' => 'Crossfade',
					'slide'     => 'Slide',
					'classic'   => 'Classic',
				),
				'editorControl'    => array(
					'kind' => 'segmentedEnum',
				),
			),
			'enableSlideshow'         => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Autoplay',
			),
			'slideshowDuration'       => array(
				'type'        => 'integer',
				'default'     => 3000,
				'minimum'     => 0,
				'editorLabel' => 'Time between slides (ms)',
			),
			'autostartThumbs'         => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Show thumbnail strip',
			),
			'lightboxBackgroundColor' => array(
				'type'        => 'string',
				'default'     => 'rgba(30,30,30,.9)',
				'editorLabel' => 'Background color',
			),
			'lightboxThumbsPosition'  => array(
				'type'             => 'string',
				'enum'             => array( 'left', 'bottom', 'right' ),
				'default'          => 'bottom',
				'editorLabel'      => 'Position',
				'enumOptionLabels' => array(
					'left'   => 'Left',
					'bottom' => 'Bottom',
					'right'  => 'Right',
				),
			),
			'openLightboxOn'          => array(
				'type'                    => 'string',
				'default'                 => 'both',
				'editorOmitFromSettingsSidebar' => true,
			),
		),
		/*
		 * Album filters: the album's own filter list and its filter bar, the
		 * gallery's `filters` group key for key (Album_Filters).
		 */
		'filters'     => \Modula_Pro\Extensions\Albums\V2\Album_Filters::settings(),
		'captions'    => array(
			'hideTitle'             => array(
				'type'          => 'boolean',
				'default'       => false,
				'editorLabel'   => 'Show gallery title',
				'editorControl' => array(
					'kind'          => 'toggle',
					'invertBoolean' => true,
				),
			),
			'titleColor'            => array(
				'type'        => 'string',
				'default'     => '#000000',
				'editorLabel' => 'Color',
			),
			'titleFontSize'         => array(
				'type'          => 'integer',
				'default'       => 12,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Title font size',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'mobileTitleFontSize'   => array(
				'type'          => 'integer',
				'default'       => 10,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Mobile title font size',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'hideDescription'       => array(
				'type'          => 'boolean',
				'default'       => false,
				'editorLabel'   => 'Show gallery caption',
				'editorControl' => array(
					'kind'          => 'toggle',
					'invertBoolean' => true,
				),
			),
			'captionColor'          => array(
				'type'        => 'string',
				'default'     => '#000000',
				'editorLabel' => 'Color',
			),
			'captionFontSize'       => array(
				'type'          => 'integer',
				'default'       => 14,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Caption font size',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'mobileCaptionFontSize' => array(
				'type'          => 'integer',
				'default'       => 12,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Mobile caption font size',
				'editorControl' => array( 'unit' => 'px' ),
			),
			// The gallery's key and values. A new album keeps today's new-album
			// look (Under Image); albums saved before it read the placement of
			// their classic effect (Album_Motion::with_existing_album_values).
			// While the hover is `custom`, the classic effect places the captions:
			// on the image, since Under Image is no hover (album-frontend ticket 16).
			'contentPlacement'      => array(
				'type'              => 'string',
				'enum'              => array( 'inside-image', 'below-image' ),
				'default'           => 'below-image',
				'editorLabel'       => 'Where it sits',
				'editorDescription' => 'On the image, the caption sits on top of the cover. Under, it sits below it. With a Custom hover, the classic hover effect places it.',
				'enumOptionLabels'  => array(
					'inside-image' => 'On the image',
					'below-image'  => 'Under the image',
				),
				'editorControl'     => array(
					'kind'               => 'segmentedEnum',
					'optionDescriptions' => array(
						'inside-image' => 'The caption sits on top of the cover.',
						'below-image'  => 'The caption sits below the cover.',
					),
				),
			),
		),
		'hover'       => array(
			'cursor'              => array(
				'type'             => 'string',
				'enum'             => array( 'pointer', 'zoom-in', 'wait', 'cell', 'crosshair', 'nesw-resize', 'nwse-resize', 'custom' ),
				'default'          => 'zoom-in',
				'editorLabel'      => 'Cursor',
				'enumOptionLabels' => array(
					'pointer'     => 'Pointer',
					'zoom-in'     => 'Magnifying glass',
					'wait'        => 'Loading',
					'cell'        => 'Cell',
					'crosshair'   => 'Crosshair',
					'nesw-resize' => 'Diagonal resize (NESW)',
					'nwse-resize' => 'Diagonal resize (NWSE)',
					'custom'      => 'Custom',
				),
			),
			// As the gallery's: off keeps the pointer. Albums saved before it
			// have no stored value and read this default, so they keep their cursor.
			'changeCursor'        => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Change the cursor',
			),
			'uploadCursor'        => array(
				'type'          => 'integer',
				'default'       => 0,
				'editorLabel'   => 'Upload cursor',
				'editorControl' => array(
					'kind'               => 'mediaAttachment',
					'libraryType'        => 'image',
					'mediaFrameTitle'    => 'Choose custom cursor image',
					'selectButtonLabel'  => 'Upload cursor',
					'replaceButtonLabel' => 'Replace cursor',
					'removeButtonLabel'  => 'Remove',
				),
			),
			'displayImageCount'   => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Display image count',
			),
			'imageCountColor'     => array(
				'type'        => 'string',
				'default'     => '#ffffff',
				'editorLabel' => 'Color',
			),
			'imageCountFontSize'  => array(
				'type'          => 'integer',
				'default'       => 14,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Size',
				'editorControl' => array( 'unit' => 'px' ),
			),
			// Darken on hover, the gallery's key: whether the hovered cover
			// darkens. Albums saved before it read the value their opacity
			// plays (Album_Motion::with_existing_album_values).
			'dimOverlay'          => array(
				'type'              => 'boolean',
				'default'           => false,
				'editorLabel'       => 'Darken on hover',
				'editorDescription' => 'When enabled, darkens the cover on hover using the dim color.',
			),
			// The Dim color, as the gallery's: a catalog hover darkens with its
			// tint and alpha. The classic effect (Custom) paints it behind the
			// cover and darkens by hoverOpacity.
			'hoverColor'          => array(
				'type'              => 'string',
				'default'           => 'rgba(0,0,0,.5)',
				'editorLabel'       => 'Dim color',
				'editorDescription' => 'Tint and strength (alpha) used when Darken on hover is on.',
				'editorControl'     => array(
					'kind'        => 'color',
					'acceptAlpha' => true,
				),
			),
			// Under the image: the background behind the title and caption.
			'backgroundColor'     => array(
				'type'        => 'string',
				'default'     => '#ffffff',
				'editorLabel' => 'Background behind text',
			),
			// The classic effect's strength: how much of the hovered cover
			// shows over the Dim color. No row, as the gallery has none; a
			// catalog hover reads the Dim color's alpha (Album_Motion).
			'hoverOpacity'        => array(
				'type'                          => 'integer',
				'default'                       => 50,
				'minimum'                       => 0,
				'maximum'                       => 100,
				'editorLabel'                   => 'Image opacity',
				'editorDescription'             => 'How much of the cover shows through the dim color on hover with the Custom effect.',
				'editorOmitFromSettingsSidebar' => true,
			),
			'hoverPadding'        => array(
				'type'          => 'integer',
				'default'       => 32,
				'minimum'       => 0,
				'maximum'       => 100,
				'editorLabel'   => 'Padding around text',
				'editorControl' => array( 'unit' => 'px' ),
			),
			'effect'              => array(
				'type'        => 'string',
				'default'     => 'under',
				'editorLabel' => 'Hover effect',
			),
		),
		/*
		 * The Motion tab's choices, as in the gallery. Entrance and hover values
		 * come from Lite's animation catalog (Album_Motion::choices): `auto`
		 * plays the recommendation for the album type, a hover of `custom` the
		 * album's classic effect. Albums saved before this group keep explicit
		 * values (Album_Motion::with_existing_album_values).
		 */
		'motion'      => array(
			'entrance' => array(
				'type'              => 'string',
				'enum'              => \Modula_Pro\Extensions\Albums\V2\Album_Motion::choices( 'entrance' ),
				'default'           => \Modula\V2\Motion\Motion_Settings::AUTO,
				'editorLabel'       => 'Entrance',
				'editorDescription' => 'How covers appear as visitors scroll to them. Recommended follows the album type.',
				'editorControl'     => array(
					'kind'                   => 'motionChoice',
					'motionKind'             => 'entrance',
					'recommendedByAlbumType' => \Modula_Pro\Extensions\Albums\V2\Album_Motion::recommended_by_album_type( 'entrance', $modula_album_types ),
				),
			),
			'speed'    => array(
				'type'              => 'string',
				'enum'              => array_keys( \Modula\V2\Motion\Animation_Catalog::speeds() ),
				'default'           => 'normal',
				'editorLabel'       => 'Speed',
				'editorDescription' => 'Pace of the entrance, and of hover motion where it applies.',
				'enumOptionLabels'  => array(
					'slow'   => 'Slow',
					'normal' => 'Normal',
					'fast'   => 'Fast',
				),
				'editorControl'     => array(
					'kind' => 'segmentedEnum',
				),
			),
			'hover'    => array(
				'type'              => 'string',
				'enum'              => \Modula_Pro\Extensions\Albums\V2\Album_Motion::choices( 'hover' ),
				'default'           => \Modula\V2\Motion\Motion_Settings::AUTO,
				'editorLabel'       => 'Hover',
				'editorDescription' => 'What happens when a visitor points at a cover. Recommended follows the album type; Custom is the classic hover effect.',
				'editorControl'     => array(
					'kind'                   => 'motionChoice',
					'motionKind'             => 'hover',
					'recommendedByAlbumType' => \Modula_Pro\Extensions\Albums\V2\Album_Motion::recommended_by_album_type( 'hover', $modula_album_types ),
				),
			),
			'phones'   => array(
				'type'              => 'boolean',
				'default'           => true,
				'editorLabel'       => 'Animate on phones',
				'editorDescription' => 'When off, phones show the album without entrance or hover motion.',
			),
		),
		'slider'      => array(
			'adaptiveHeight'                  => array(
				'type'              => 'boolean',
				'default'           => true,
				'editorLabel'       => 'Height follows slide',
				'editorDescription' => 'Slider height grows or shrinks with the current slide.',
			),
			'sectionSlides'                   => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Slides',
				'editorControl'           => array( 'kind' => 'heading' ),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'sectionNavigation'               => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Navigation',
				'editorControl'           => array( 'kind' => 'heading' ),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'sectionAutoplay'                 => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Autoplay',
				'editorControl'           => array( 'kind' => 'heading' ),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'sectionThumbnails'               => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Thumbnails',
				'editorControl'           => array( 'kind' => 'heading' ),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'syncing'                         => array(
				'type'              => 'boolean',
				'default'           => true,
				'editorLabel'       => 'Show thumbnails',
				'editorDescription' => 'Show a synced strip of thumbnails with the main slider.',
			),
			'syncingNavSize'                  => array(
				'type'        => 'string',
				'default'     => 'auto',
				'description' => 'Size of thumbnails in the strip. Choose Custom to set width and height below.',
				'editorLabel' => 'Thumbnail file size',
			),
			'syncingNavImageDimensions'       => array(
				'type'        => 'object',
				'properties'  => array(
					'width'  => array( 'type' => 'integer' ),
					'height' => array( 'type' => 'integer' ),
				),
				'description' => 'Used when Thumbnail image size is Custom. “Crop to dimensions” applies to the thumbnail strip.',
				'editorLabel' => 'Width and height',
			),
			'syncingNavImageCrop'             => array(
				'type'        => 'boolean',
				'default'     => false,
				'description' => 'When on, thumbnails are cropped to the exact width and height above.',
				'editorLabel' => 'Crop thumbnails to fit',
			),
			'syncingNavThumbnailsNumber'      => array(
				'type'              => 'integer',
				'minimum'           => 0,
				'maximum'           => 20,
				'default'           => 0,
				'editorLabel'       => 'Visible thumbnails',
				'editorDescription' => 'How many thumbnails show at once (0 uses default).',
			),
			'syncingNavThumbnailsGutter'      => array(
				'type'        => 'integer',
				'minimum'     => 0,
				'maximum'     => 50,
				'default'     => 10,
				'editorLabel' => 'Space between thumbnails',
			),
			'syncingNavThumbnailsBorderColor' => array(
				'type'        => 'string',
				'default'     => '#000000',
				'editorLabel' => 'Border color',
			),
			'autoplay'                        => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Autoplay',
			),
			'pauseOnHover'                    => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Pause when hovering',
			),
			'autoplaySpeed'                   => array(
				'type'          => 'integer',
				'minimum'       => 1000,
				'maximum'       => 15000,
				'default'       => 3000,
				'editorLabel'   => 'Time between slides',
				'editorControl' => array(
					'kind' => 'range',
					'min'  => 1000,
					'max'  => 15000,
					'step' => 100,
					'unit' => 'ms',
				),
			),
			'arrows'                          => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Show arrows',
			),
			'arrowsInside'                    => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Arrows over the image',
			),
			'dots'                            => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Show page dots',
			),
			'draggable'                       => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Drag to move',
			),
			'centerMode'                      => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Peek side slides',
			),
			'centerPadding'                   => array(
				'type'          => 'string',
				'default'       => '50px',
				'editorLabel'   => 'Side peek size',
				'editorControl' => array(
					'kind'        => 'range',
					'min'         => 0,
					'max'         => 200,
					'step'        => 1,
					'valueFormat' => 'px',
				),
			),
			'fade'                            => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Fade between slides',
			),
			'infinite'                        => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Loop endlessly',
			),
			'slidesToShow'                    => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'maximum'     => 12,
				'default'     => 1,
				'editorLabel' => 'Visible at once',
			),
			'slidesToScroll'                  => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'maximum'     => 12,
				'default'     => 1,
				'editorLabel' => 'Advance by',
			),
			'speed'                           => array(
				'type'          => 'integer',
				'minimum'       => 150,
				'maximum'       => 350,
				'default'       => 300,
				'editorLabel'   => 'How fast slides change',
				'editorControl' => array( 'unit' => 'ms' ),
			),
			'rtl'                             => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Right-to-left',
			),
			'initialSlide'                    => array(
				'type'        => 'integer',
				'default'     => 0,
				'editorLabel' => 'Start on slide',
			),
			'imageInfo'                       => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Show title and caption',
			),
			'imageInfoPosition'               => array(
				'type'             => 'string',
				'enum'             => array(
					'top_outside',
					'top_inside',
					'bot_outside',
					'bot_inside',
				),
				'default'          => 'bot_outside',
				'editorLabel'      => 'Caption placement',
				'enumOptionLabels' => array(
					'top_outside' => 'Above the slide',
					'top_inside'  => 'Top of the slide',
					'bot_outside' => 'Below the slide',
					'bot_inside'  => 'Bottom of the slide',
				),
			),
			'tabletSlides'                    => array(
				'type'                    => 'integer',
				'minimum'                 => 1,
				'maximum'                 => 6,
				'default'                 => 1,
				'editorLabel'             => 'Visible at once',
				'editorSidebarNestedOnly' => true,
			),
			'tabletScrolls'                   => array(
				'type'                    => 'integer',
				'minimum'                 => 1,
				'maximum'                 => 6,
				'default'                 => 1,
				'editorLabel'             => 'Advance by',
				'editorSidebarNestedOnly' => true,
			),
			'mobileSlides'                    => array(
				'type'                    => 'integer',
				'minimum'                 => 1,
				'maximum'                 => 6,
				'default'                 => 1,
				'editorLabel'             => 'Visible at once',
				'editorSidebarNestedOnly' => true,
			),
			'mobileScrolls'                   => array(
				'type'                    => 'integer',
				'minimum'                 => 1,
				'maximum'                 => 6,
				'default'                 => 1,
				'editorLabel'             => 'Advance by',
				'editorSidebarNestedOnly' => true,
			),
		),
		'responsive'  => array(
			'enableResponsive' => array(
				'type'        => 'boolean',
				'default'     => true,
				'editorLabel' => 'Responsive',
			),
			'tabletColumns'    => array(
				'type'        => 'integer',
				'default'     => 2,
				'minimum'     => 1,
				'maximum'     => 6,
				'editorLabel' => 'Tablet',
			),
			'mobileColumns'    => array(
				'type'        => 'integer',
				'default'     => 1,
				'minimum'     => 1,
				'maximum'     => 6,
				'editorLabel' => 'Mobile',
			),
			// Ranges match the gallery; defaults keep the classic album breakpoints
			// (Responsive_Breakpoints::DEFAULT_*), not the gallery's 1024 / 600.
			'treatAsTabletUnder' => array(
				'type'          => 'integer',
				'minimum'       => 768,
				'maximum'       => 1400,
				'default'       => 992,
				'editorLabel'   => 'Treat as a tablet under',
				'editorControl' => array(
					'kind' => 'range',
					'min'  => 768,
					'max'  => 1400,
					'step' => 1,
					'unit' => 'px',
				),
			),
			'treatAsPhoneUnder'  => array(
				'type'          => 'integer',
				'minimum'       => 320,
				'maximum'       => 900,
				'default'       => 768,
				'editorLabel'   => 'Treat as a phone under',
				'editorControl' => array(
					'kind' => 'range',
					'min'  => 320,
					'max'  => 900,
					'step' => 1,
					'unit' => 'px',
				),
			),
		),
		'performance' => array(
			'lazyLoad' => array(
				'type'        => 'boolean',
				'default'     => false,
				'editorLabel' => 'Lazy load',
			),
		),
		'download'    => array(
			'enableDownload'                 => array(
				'type'                             => 'boolean',
				'default'                          => false,
				'editorLabel'                      => 'Enable download',
				'editorLightboxLiteUpsell'         => array(
					'title'              => 'Looking to add download functionality to your album?',
					'needsProMessage'    => "Download entire albums or a single photo.\n\nSelect the image sizes the user can download (thumbnail, full size, or custom).\n\nGive your users the ability to download your images and albums with an easy to use shortcode.",
					'compareUrl'         => 'https://wp-modula.com/free-vs-pro/?utm_source=modula-pro&utm_medium=albums-settings-editor&utm_campaign=upsell&utm_term=lite-vs-pro&utm_content=v3',
					'pricingUrl'         => 'https://wp-modula.com/pricing/?utm_source=upsell&utm_medium=albums-settings-editor-download&utm_campaign=download-extension&utm_content=v3',
					'freeVsPremiumLabel' => 'Free vs Premium',
					'getPremiumLabel'    => 'Get Premium!',
					'extensionSlug'      => 'modula-download',
				),
			),
			'sectionWhatTheyCanTake'         => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'What they can take',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'downloadGalleryButton'          => array(
				'type'                    => 'boolean',
				'default'                 => true,
				'editorLabel'             => 'Download one image',
				'editorSidebarNestedOnly' => true,
			),
			'downloadGalleryButtonColor'     => array(
				'type'                    => 'string',
				'default'                 => '#ffffff',
				'editorLabel'             => 'Button color',
				'editorSidebarNestedOnly' => true,
			),
			'downloadGalleryButtonPosition'  => array(
				'type'                    => 'string',
				'enum'                    => array( 'top_left', 'top_right', 'bottom_left', 'bottom_right' ),
				'default'                 => 'top_left',
				'editorLabel'             => 'Button position',
				'enumOptionLabels'        => array(
					'top_left'     => 'Top left',
					'top_right'    => 'Top right',
					'bottom_left'  => 'Bottom left',
					'bottom_right' => 'Bottom right',
				),
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllLightboxButton'      => array(
				'type'                    => 'boolean',
				'default'                 => true,
				'editorLabel'             => 'Lightbox download all',
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllGalleryButton'       => array(
				'type'                    => 'boolean',
				'default'                 => true,
				'editorLabel'             => 'Download the whole album',
				'editorSidebarNestedOnly' => true,
			),
			'downloadImageSizes'             => array(
				'type'                    => 'string',
				'enum'                    => array( 'thumbnail', 'medium', 'large', 'full' ),
				'default'                 => 'full',
				'editorLabel'             => 'Download size',
				'enumOptionLabels'        => array(
					'thumbnail' => 'Thumbnail',
					'medium'    => 'Medium',
					'large'     => 'Large',
					'full'      => 'Full',
				),
				'editorControl'           => array(
					'allowsCustomImageSize' => false,
				),
				'editorSidebarNestedOnly' => true,
			),
			'sectionGalleryButton'           => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'The album button',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllLabel'               => array(
				'type'                    => 'string',
				'default'                 => 'Download All Images',
				'editorLabel'             => 'Label',
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllPosition'            => array(
				'type'                    => 'string',
				'enum'                    => array( 'above_gallery', 'below_gallery', 'above_below_gallery' ),
				'default'                 => 'below_gallery',
				'editorLabel'             => 'Where it sits',
				'enumOptionLabels'        => array(
					'above_gallery'       => 'Above album',
					'below_gallery'       => 'Below album',
					'above_below_gallery' => 'Above & below album',
				),
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllHposition'           => array(
				'type'                    => 'string',
				'enum'                    => array( 'left', 'right', 'center' ),
				'default'                 => 'center',
				'editorLabel'             => 'Alignment',
				'enumOptionLabels'        => array(
					'left'   => 'Left',
					'right'  => 'Right',
					'center' => 'Center',
				),
				'editorControl'           => array(
					'kind' => 'segmentedEnum',
				),
				'editorSidebarNestedOnly' => true,
			),
			'sectionHowItLooks'              => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'How it looks',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllColor'               => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Text',
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllBackgroundColor'     => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Background',
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllGalleryButtonIcon'   => array(
				'type'                    => 'boolean',
				'default'                 => true,
				'editorLabel'             => 'Icon before the label',
				'editorSidebarNestedOnly' => true,
			),
			'downloadAllGalleryIconColor'    => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Icon color',
				'editorSidebarNestedOnly' => true,
			),
			'sectionZipName'                 => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Name of the download',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'customZipName'                  => array(
				'type'                    => 'string',
				'default'                 => '%%album_title%%',
				'editorLabel'             => 'Zip file name',
				'editorDescription'       => 'Type anything you like between the tokens — dashes, underscores, plain words.',
				'editorControl'           => array(
					'kind'   => 'placeholderPattern',
					'tokens' => array(
						array(
							'token' => '%%album_title%%',
							'label' => 'album_title',
						),
						array(
							'token' => '%%album_date%%',
							'label' => 'date',
						),
						array(
							'token' => '%%album_id%%',
							'label' => 'id',
						),
					),
				),
				'editorSidebarNestedOnly' => true,
			),
		),
		'zoom'        => array(
			'enableZoom'             => array(
				'type'                     => 'boolean',
				'default'                  => false,
				'editorLabel'              => 'Enable lightbox zoom',
				'editorLightboxLiteUpsell' => array(
					'title'              => 'Want zoom inside the lightbox?',
					'needsProMessage'    => "Let visitors magnify images without leaving your album—zoom happens right in the lightbox.\n\nPick the style that fits: classic window zoom, a follow-along lens, or inner zoom—then fine-tune motion, window size, lens shape, tint, and opacity.\n\nThe Modula ZOOM add-on is built for portfolios, products, and any shot where the details should stand out.",
					'compareUrl'         => 'https://wp-modula.com/free-vs-pro/?utm_source=modula-pro&utm_medium=albums-settings-editor&utm_campaign=upsell&utm_term=lite-vs-pro&utm_content=v3',
					'pricingUrl'         => 'https://wp-modula.com/pricing/?utm_source=upsell&utm_medium=albums-settings-editor-zoom&utm_campaign=zoom-extension&utm_content=v3',
					'freeVsPremiumLabel' => 'Free vs Premium',
					'getPremiumLabel'    => 'Get Premium!',
					'extensionSlug'      => 'modula-zoom',
				),
			),
			'sectionStyle'           => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Style',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'zoomOnHover'            => array(
				'type'                    => 'boolean',
				'default'                 => true,
				'editorLabel'             => 'Zoom on hover',
				'editorDescription'       => 'Magnifies when the pointer rests on the image. When off, Zoom still needs Enable, but hover does not trigger it — visitors use the lightbox toolbar button instead.',
				'editorSidebarNestedOnly' => true,
			),
			'zoomType'               => array(
				'type'                    => 'string',
				'default'                 => 'window',
				'enum'                    => array( 'window', 'inner', 'lens' ),
				'editorLabel'             => 'Kind',
				'enumOptionLabels'        => array(
					'window' => 'Basic',
					'inner'  => 'Inner',
					'lens'   => 'Lens',
				),
				'editorSidebarNestedOnly' => true,
			),
			'zoomEffect'             => array(
				'type'                    => 'string',
				'default'                 => 'fade_in',
				'enum'                    => array( 'none', 'fade_in', 'fade_out', 'fade_in_out', 'easing' ),
				'editorLabel'             => 'How it appears',
				'enumOptionLabels'        => array(
					'none'        => 'No effect',
					'fade_in'     => 'Fade In',
					'fade_out'    => 'Fade Out',
					'fade_in_out' => 'Fade In Out',
					'easing'      => 'Easing',
				),
				'editorSidebarNestedOnly' => true,
			),
			'sectionMagnifiedWindow' => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Magnified window',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'zoomWindowPosition'     => array(
				'type'                    => 'string',
				'default'                 => 'upper_left',
				'enum'                    => array( 'upper_left', 'upper_right', 'lower_left', 'lower_right' ),
				'editorLabel'             => 'Window position',
				'enumOptionLabels'        => array(
					'upper_left'  => 'Upper Left',
					'upper_right' => 'Upper Right',
					'lower_left'  => 'Lower Left',
					'lower_right' => 'Lower Right',
				),
				'editorSidebarNestedOnly' => true,
			),
			'zoomWindowSize'         => array(
				'type'                    => 'string',
				'default'                 => 'medium',
				'enum'                    => array( 'small', 'medium', 'large', 'xlarge' ),
				'editorLabel'             => 'Window size',
				'enumOptionLabels'        => array(
					'small'  => 'Small',
					'medium' => 'Medium',
					'large'  => 'Large',
					'xlarge' => 'Extra Large',
				),
				'editorSidebarNestedOnly' => true,
			),
			'zoomLensSize'           => array(
				'type'                    => 'string',
				'default'                 => 'medium',
				'enum'                    => array( 'small', 'medium', 'large', 'xlarge' ),
				'editorLabel'             => 'Lens size',
				'enumOptionLabels'        => array(
					'small'  => 'Small',
					'medium' => 'Medium',
					'large'  => 'Large',
					'xlarge' => 'Extra Large',
				),
				'editorSidebarNestedOnly' => true,
			),
			'zoomLensShape'          => array(
				'type'                    => 'string',
				'default'                 => 'round',
				'enum'                    => array( 'round', 'square' ),
				'editorLabel'             => 'Lens shape',
				'enumOptionLabels'        => array(
					'round'  => 'Round',
					'square' => 'Square',
				),
				'editorControl'           => array(
					'kind' => 'segmentedEnum',
				),
				'editorSidebarNestedOnly' => true,
			),
			'sectionTint'            => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Tint',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'zoomTintColor'          => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Color',
				'editorSidebarNestedOnly' => true,
			),
			'zoomTintOpacity'        => array(
				'type'                    => 'integer',
				'default'                 => 0,
				'minimum'                 => 0,
				'maximum'                 => 100,
				'editorLabel'             => 'Strength',
				'editorControl'           => array(
					'kind' => 'range',
					'min'  => 0,
					'max'  => 100,
					'step' => 1,
				),
				'editorSidebarNestedOnly' => true,
			),
		),
		'passwordProtect' => array(
			'enablePassword'          => array(
				'type'                     => 'boolean',
				'default'                  => false,
				'editorLabel'              => 'Password protect',
				'editorLightboxLiteUpsell' => array(
					'title'              => 'Password-protect this album?',
					'needsProMessage'    => 'Upgrade to Modula Premium to use the Password Protect add-on: visitors enter a password before they can view the album—ideal for client proofing, private deliveries, and members-only collections.',
					'compareUrl'         => 'https://wp-modula.com/free-vs-pro/?utm_source=modula-pro&utm_medium=albums-settings-editor&utm_campaign=upsell&utm_term=lite-vs-pro&utm_content=v3',
					'pricingUrl'         => 'https://wp-modula.com/pricing/?utm_source=upsell&utm_medium=albums-settings-editor-password-protect&utm_campaign=password-protect-addon&utm_content=v3',
					'freeVsPremiumLabel' => 'Free vs Premium',
					'getPremiumLabel'    => 'Get Premium!',
					'extensionSlug'      => 'modula-password-protect',
				),
			),
			'sectionPasswordForm'     => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Password form',
				'editorControl'           => array(
					'kind' => 'heading',
				),
				'editorPresentationOnly'  => true,
				'editorSidebarNestedOnly' => true,
			),
			'password'                => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Set password',
				'editorSidebarNestedOnly' => true,
				'editorControl'           => array(
					'kind' => 'passwordWithStrength',
				),
			),
			'passwordProtectUsername' => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Request username or email with password',
				'editorSidebarNestedOnly' => true,
			),
			'passwordProtectText'     => array(
				'type'                    => 'string',
				'default'                 => '',
				'editorLabel'             => 'Protect text',
				'editorSidebarNestedOnly' => true,
				'editorControl'           => array(
					'kind' => 'textarea',
				),
			),
		),
		'exif'            => array(
			'displayExif' => array(
				'type'                     => 'string',
				'default'                  => 'default',
				'enum'                     => array( 'default', 'on', 'off' ),
				'editorLabel'              => 'Show EXIF data',
				'enumOptionLabels'         => array(
					'default' => 'Take Gallery setting',
					'on'      => 'Display EXIF data',
					'off'     => 'Hide EXIF data',
				),
				'editorLightboxLiteUpsell' => array(
					'title'              => 'Looking to add EXIF image info functionality to your lightbox?',
					'needsProMessage'    => "EXIF data is automatically read and displayed.\n\nControl how member galleries show camera metadata in the album lightbox—follow each gallery, always show, or always hide.\n\nWith the Modula EXIF extension you'll enrich photos with camera model, lens, shutter speed, aperture, ISO, and date.",
					'compareUrl'         => 'https://wp-modula.com/free-vs-pro/?utm_source=modula-pro&utm_medium=albums-settings-editor&utm_campaign=upsell&utm_term=lite-vs-pro&utm_content=v3',
					'pricingUrl'         => 'https://wp-modula.com/pricing/?utm_source=upsell&utm_medium=albums-settings-editor-exif&utm_campaign=exif-extension&utm_content=v3',
					'freeVsPremiumLabel' => 'Free vs Premium',
					'getPremiumLabel'    => 'Get Premium!',
					'extensionSlug'      => 'modula-exif',
				),
			),
		),
		'protection'      => array(
			'protection'     => array(
				'type'                     => 'boolean',
				'default'                  => true,
				'editorLabel'              => 'Block right-click on images',
				'editorLightboxLiteUpsell' => array(
					'title'              => 'Lock down how visitors can grab your album images?',
					'needsProMessage'    => "Cut down casual right-click saving, optionally blur the album when the tab loses focus, and hide real file addresses behind a protected endpoint.\n\nImage Guardian is built for proofs, client reviews, and portfolios you don't want scraped in one click.",
					'compareUrl'         => 'https://wp-modula.com/free-vs-pro/?utm_source=modula-pro&utm_medium=albums-settings-editor&utm_campaign=upsell&utm_term=lite-vs-pro&utm_content=v3',
					'pricingUrl'         => 'https://wp-modula.com/pricing/?utm_source=upsell&utm_medium=albums-settings-editor-protection&utm_campaign=image-guardian-protection&utm_content=v3',
					'freeVsPremiumLabel' => 'Free vs Premium',
					'getPremiumLabel'    => 'Get Premium!',
					'extensionSlug'      => 'modula-image-guardian',
				),
			),
			'urlProtection'  => array(
				'type'                    => 'boolean',
				'default'                 => false,
				'editorLabel'             => 'Hide the real file address',
				'editorSidebarNestedOnly' => true,
			),
			'blurProtection' => array(
				'type'                    => 'boolean',
				'default'                 => true,
				'editorLabel'             => 'Blur images when leaving the tab',
				'editorSidebarNestedOnly' => true,
			),
		),
	),
);
