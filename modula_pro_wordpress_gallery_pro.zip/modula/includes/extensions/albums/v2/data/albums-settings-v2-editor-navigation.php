<?php
/**
 * Albums settings editor navigation (categories + group labels).
 *
 * Same shape as the gallery editor's navigation
 * (Lite `includes/v2/settings/data/settings-v2-editor-navigation.php`), and
 * grouped as the album design's `HE_ORG` (`.scratch/album-editor-1to1`):
 * Layout, Lightbox, Motion, Interact, Protect (the rail's short labels for
 * the Interaction and Protection categories, shared with the gallery). The
 * design has no filters: the Filters tab sits where the gallery's does, after
 * Lightbox.
 *
 * Each category has a hub submenu (`role` hub) and, where it has secondary
 * sections, a "More settings" submenu (`role` more). Every submenu and drill
 * carries a stable `id`; the settings panel keys a section's open state by the
 * ids above it. A drill lists its fields as `items` (`field` and nested
 * `drill` entries); the exporter derives its flat `groupedPaths`. A drill with
 * `nestedUnder` holds the options of the host field listed just before it (the
 * design's "kids" of a toggle) and starts open; other sections start closed.
 * A `headless` drill has no header and is always open; its host row carries
 * its reset.
 *
 * One list serves every album type: the field rules in
 * `apps/albums-editor/data/form-rules.json` hide the rows of other types
 * (slider rows outside Slider, Columns and Spacing in Slider).
 *
 * @package Modula_Pro
 */

$modula_albums_nav_field = static function ( $grouped_path, array $extra = array() ) {
	return array_merge(
		array(
			'type'        => 'field',
			'groupedPath' => $grouped_path,
		),
		$extra
	);
};

$modula_albums_nav_fields = static function ( array $grouped_paths ) use ( $modula_albums_nav_field ) {
	return array_map( $modula_albums_nav_field, $grouped_paths );
};

/*
 * Hosts whose dependents box only repeats the host's name (the design's
 * `HF_NOHEAD`, plus the album layer's additions and the boxes it titles like
 * their toggle), as the gallery's `$modula_nav_headless_hosts`. Image file
 * size joins them: the design draws its custom dimensions and crop rows flat
 * under it, with no box title. Their box is
 * `headless`: no header, always open while the host is on, and the host row's
 * reset covers the host and the box.
 */
$modula_albums_nav_headless_hosts = array(
	'slider.syncing',
	'slider.autoplay',
	'general.albumWidth',
	'layout.imageSize',
	'captions.hideTitle',
	'captions.hideDescription',
	'hover.displayImageCount',
	'lightbox.enableLightbox',
	'lightbox.enableSlideshow',
	'lightbox.autostartThumbs',
	'zoom.enableZoom',
	'lightbox.lightboxToolbar',
	'lightbox.enableShare',
	'download.enableDownload',
	'download.downloadGalleryButton',
	'passwordProtect.enablePassword',
	'filters.showFilterBar',
	'filters.enableCollapsibleFilters',
);

/*
 * Dependent fields of a host field, shown while the host is on. `$host_on`
 * replaces the default `truthy` test (inverted keys such as captions.hideTitle,
 * or a menu value such as a custom width); `false` leaves the box without a
 * condition of its own. The gallery's `$modula_nav_kids` also takes `$extra`
 * (icons, summaries), which the album panel does not draw.
 */
$modula_albums_nav_kids = static function ( $id, $label, $host, array $items, $host_on = null ) use ( $modula_albums_nav_headless_hosts ) {
	$drill = array(
		'type'        => 'drill',
		'id'          => $id,
		'label'       => $label,
		'nestedUnder' => $host,
		'items'       => $items,
	);
	if ( false !== $host_on ) {
		$drill['visibleWhen'] = null === $host_on
			? array(
				'path'   => $host,
				'truthy' => true,
			)
			: $host_on;
	}
	if ( in_array( $host, $modula_albums_nav_headless_hosts, true ) ) {
		$drill['headless'] = true;
	}
	return $drill;
};

$modula_albums_nav_not_slider = array(
	'path' => 'general.albumType',
	'neq'  => 'slider',
);

/*
 * Shown for every album type but these, as the gallery's `$modula_nav_not_types`
 * (album types share the gallery types' names).
 */
$modula_albums_nav_not_types = static function ( array $types ) {
	return array(
		'all' => array_map(
			static function ( $type ) {
				return array(
					'path' => 'general.albumType',
					'neq'  => $type,
				);
			},
			array_values( $types )
		),
	);
};

$modula_albums_nav_lightbox_on = array(
	'path'   => 'lightbox.enableLightbox',
	'truthy' => true,
);

return array(
	'categories'  => array(
		array(
			'name'        => 'layout',
			'title'       => 'Layout',
			'description' => 'Album type, dimensions, spacing, captions, navigation and responsive behavior',
			'hubSections' => array(
				array(
					'type'  => 'submenu',
					'id'    => 'hub',
					'role'  => 'hub',
					'items' => array(
						$modula_albums_nav_field( 'general.albumType' ),
						// Grid and Custom grid only (form-rules.json).
						$modula_albums_nav_field( 'general.memberStyle' ),
						$modula_albums_nav_kids(
							'member-card',
							'Card',
							'general.memberStyle',
							$modula_albums_nav_fields(
								array(
									'general.memberCardBackground',
									'general.memberCardRadius',
									'general.memberCardShadow',
								)
							),
							array(
								'path' => 'general.memberStyle',
								'eq'   => 'card',
							)
						),
						$modula_albums_nav_field( 'general.columns' ),
						$modula_albums_nav_field( 'layout.gutter' ),
						$modula_albums_nav_field( 'layout.tabletGutter' ),
						$modula_albums_nav_field( 'layout.mobileGutter' ),
						$modula_albums_nav_field( 'slider.slidesToShow' ),
						$modula_albums_nav_field( 'slider.arrows' ),
						$modula_albums_nav_kids( 'arrows', 'Arrows', 'slider.arrows', $modula_albums_nav_fields( array( 'slider.arrowsInside' ) ) ),
						$modula_albums_nav_field( 'slider.dots' ),
						$modula_albums_nav_field( 'slider.autoplay' ),
						$modula_albums_nav_kids( 'slider-autoplay', 'Autoplay', 'slider.autoplay', $modula_albums_nav_fields( array( 'slider.pauseOnHover', 'slider.autoplaySpeed' ) ) ),
						$modula_albums_nav_field( 'slider.syncing' ),
						$modula_albums_nav_kids(
							'thumbnails',
							'Thumbnails',
							'slider.syncing',
							$modula_albums_nav_fields(
								array(
									'slider.syncingNavSize',
									// Shown while the thumbnail file size is custom.
									'slider.syncingNavImageDimensions',
									'slider.syncingNavImageCrop',
									'slider.syncingNavThumbnailsNumber',
									'slider.syncingNavThumbnailsGutter',
									'slider.syncingNavThumbnailsBorderColor',
								)
							)
						),
						$modula_albums_nav_field( 'general.albumWidth' ),
						$modula_albums_nav_kids(
							'custom-width',
							'Custom width',
							'general.albumWidth',
							$modula_albums_nav_fields( array( 'general.width' ) ),
							array(
								'path' => 'general.albumWidth',
								'eq'   => 'custom',
							)
						),
						$modula_albums_nav_field( 'layout.imageSize' ),
						$modula_albums_nav_kids(
							'image-size',
							'Custom dimensions',
							'layout.imageSize',
							$modula_albums_nav_fields( array( 'layout.imageDimensions', 'layout.cropImages' ) ),
							array(
								'path' => 'layout.imageSize',
								'eq'   => 'custom',
							)
						),
						$modula_albums_nav_field( 'slider.adaptiveHeight' ),
						$modula_albums_nav_field( 'slider.slidesToScroll' ),
						$modula_albums_nav_field( 'slider.centerMode' ),
						$modula_albums_nav_kids( 'peek', 'Peek', 'slider.centerMode', $modula_albums_nav_fields( array( 'slider.centerPadding' ) ) ),
						$modula_albums_nav_field( 'slider.fade' ),
						$modula_albums_nav_field( 'slider.infinite' ),
						$modula_albums_nav_field( 'slider.speed' ),
						$modula_albums_nav_field( 'slider.rtl' ),
						$modula_albums_nav_field( 'slider.initialSlide' ),
						$modula_albums_nav_field( 'slider.draggable' ),
						// New items position (general.uploadPosition) has no row: the
						// Sort & order Start / End segment edits it, as in the gallery.
						$modula_albums_nav_field( 'responsive.enableResponsive' ),
						$modula_albums_nav_kids(
							'responsive',
							'On phones and tablets',
							'responsive.enableResponsive',
							$modula_albums_nav_fields(
								array(
									'responsive.tabletColumns',
									'responsive.mobileColumns',
									'responsive.treatAsTabletUnder',
									'responsive.treatAsPhoneUnder',
									// Two device-switch rows: Visible at once, then Advance by.
									'slider.tabletSlides',
									'slider.mobileSlides',
									'slider.tabletScrolls',
									'slider.mobileScrolls',
								)
							)
						),
						array(
							'type'  => 'drill',
							'id'    => 'captions',
							'label' => 'Captions',
							'icon'  => 'caption',
							'items' => array(
								// Where it sits, first as in the design and the gallery.
								$modula_albums_nav_field( 'captions.contentPlacement' ),
								$modula_albums_nav_field( 'slider.imageInfo' ),
								$modula_albums_nav_field( 'slider.imageInfoPosition' ),
								$modula_albums_nav_field( 'captions.hideTitle' ),
								$modula_albums_nav_kids(
									'title-style',
									'Title style',
									'captions.hideTitle',
									$modula_albums_nav_fields(
										array(
											'captions.titleColor',
											'captions.titleFontSize',
											'captions.mobileTitleFontSize',
										)
									),
									array(
										'path' => 'captions.hideTitle',
										'eq'   => false,
									)
								),
								$modula_albums_nav_field( 'captions.hideDescription' ),
								$modula_albums_nav_kids(
									'caption-style',
									'Caption style',
									'captions.hideDescription',
									$modula_albums_nav_fields(
										array(
											'captions.captionColor',
											'captions.captionFontSize',
											'captions.mobileCaptionFontSize',
										)
									),
									array(
										'path' => 'captions.hideDescription',
										'eq'   => false,
									)
								),
								$modula_albums_nav_field( 'hover.displayImageCount' ),
								$modula_albums_nav_kids(
									'image-count',
									'Image count',
									'hover.displayImageCount',
									$modula_albums_nav_fields( array( 'hover.imageCountColor', 'hover.imageCountFontSize' ) )
								),
								// Under the image, as the gallery's text rows there.
								$modula_albums_nav_field( 'hover.backgroundColor' ),
								$modula_albums_nav_field( 'hover.hoverPadding' ),
							),
						),
						array(
							'type'        => 'drill',
							'id'          => 'items',
							'label'       => 'Galleries and albums',
							'icon'        => 'gallery',
							'visibleWhen' => $modula_albums_nav_not_slider,
							'items'       => $modula_albums_nav_fields(
								array(
									'general.mergeItems',
									'general.albumsTitleLabel',
									'general.galleriesTitleLabel',
									'general.maxGalleriesCount',
								)
							),
						),
						array(
							'type'  => 'drill',
							'id'    => 'navigation',
							'label' => 'Album navigation',
							'icon'  => 'navigation',
							'items' => $modula_albums_nav_fields(
								array(
									'navigation.backToAlbumButton',
									'navigation.albumsNavigation',
								)
							),
						),
						$modula_albums_nav_field( 'layout.shuffleGalleries', array( 'visibleWhen' => $modula_albums_nav_not_slider ) ),
					),
				),
				array(
					'type'  => 'submenu',
					'id'    => 'more',
					'role'  => 'more',
					'label' => 'More settings',
					'items' => array(
						// Where the gallery keeps it (Advanced is gone).
						array(
							'type'  => 'drill',
							'id'    => 'performance',
							'label' => 'Speed Up',
							'icon'  => 'chartBar',
							'items' => $modula_albums_nav_fields( array( 'performance.lazyLoad' ) ),
						),
					),
				),
			),
		),
		array(
			'name'        => 'lightbox',
			'title'       => 'Lightbox',
			'description' => 'What happens after someone clicks a gallery tile inside the album.',
			'hubSections' => array(
				array(
					'type'  => 'submenu',
					'id'    => 'hub',
					'role'  => 'hub',
					'items' => array(
						$modula_albums_nav_field( 'lightbox.enableLightbox' ),
						$modula_albums_nav_kids(
							'lightbox-options',
							'Lightbox options',
							'lightbox.enableLightbox',
							array(
								$modula_albums_nav_field( 'lightbox.loopLightbox' ),
								$modula_albums_nav_field( 'lightbox.enableNavigation' ),
								$modula_albums_nav_field( 'lightbox.lightboxBackgroundColor' ),
								$modula_albums_nav_field( 'lightbox.transitionEffect' ),
								$modula_albums_nav_field( 'lightbox.showImageTitle' ),
								$modula_albums_nav_field( 'lightbox.showImageCaption' ),
								$modula_albums_nav_field( 'lightbox.captionPosition' ),
								$modula_albums_nav_field( 'lightbox.enableSlideshow' ),
								$modula_albums_nav_kids( 'slideshow', 'Autoplay', 'lightbox.enableSlideshow', $modula_albums_nav_fields( array( 'lightbox.slideshowDuration' ) ) ),
								$modula_albums_nav_field( 'lightbox.autostartThumbs' ),
								/*
								 * No condition of its own: the position also applies to
								 * thumbnails opened with the toolbar button, so the box shows
								 * whenever the position's field rule (form-rules.json) does.
								 */
								$modula_albums_nav_kids(
									'thumbnail-strip',
									'Thumbnail strip',
									'lightbox.autostartThumbs',
									$modula_albums_nav_fields( array( 'lightbox.lightboxThumbsPosition' ) ),
									false
								),
								$modula_albums_nav_field( 'zoom.enableZoom' ),
								$modula_albums_nav_kids(
									'zoom',
									'Zoom',
									'zoom.enableZoom',
									$modula_albums_nav_fields(
										array(
											'zoom.zoomOnHover',
											'zoom.zoomType',
											'zoom.zoomEffect',
											'zoom.zoomWindowPosition',
											'zoom.zoomWindowSize',
											'zoom.zoomLensSize',
											'zoom.zoomLensShape',
											'zoom.zoomTintOpacity',
											'zoom.zoomTintColor',
										)
									)
								),
							)
						),
					),
				),
				array(
					'type'  => 'submenu',
					'id'    => 'more',
					'role'  => 'more',
					'label' => 'More settings',
					'items' => array(
						array(
							'type'        => 'drill',
							'id'          => 'links',
							'label'       => 'Lightbox & Links',
							'icon'        => 'fullscreen',
							'visibleWhen' => $modula_albums_nav_lightbox_on,
							'items'       => array(
								$modula_albums_nav_field( 'lightbox.animationEffect' ),
								$modula_albums_nav_field( 'lightbox.doubleClick' ),
								$modula_albums_nav_field( 'lightbox.lightboxToolbar' ),
								$modula_albums_nav_kids(
									'buttons',
									'Buttons',
									'lightbox.lightboxToolbar',
									array(
										$modula_albums_nav_field( 'lightbox.lightboxClose' ),
										$modula_albums_nav_field( 'lightbox.enableThumbs' ),
										$modula_albums_nav_field( 'lightbox.enableDownload' ),
										$modula_albums_nav_field( 'lightbox.enableZoom' ),
										$modula_albums_nav_field( 'lightbox.enablePlay' ),
										$modula_albums_nav_field( 'lightbox.enableShare' ),
										$modula_albums_nav_kids(
											'share',
											'Share',
											'lightbox.enableShare',
											$modula_albums_nav_fields(
												array(
													'lightbox.lightboxFacebook',
													'lightbox.lightboxTwitter',
													'lightbox.lightboxWhatsapp',
													'lightbox.lightboxLinkedin',
													'lightbox.lightboxPinterest',
													'lightbox.lightboxEmail',
													'lightbox.lightboxEmailSubject',
													'lightbox.lightboxEmailMessage',
												)
											)
										),
										$modula_albums_nav_field( 'lightbox.lightboxInfobar' ),
									)
								),
							),
						),
						array(
							'type'                    => 'drill',
							'id'                      => 'exif',
							'label'                   => 'EXIF',
							'icon'                    => 'capturePhoto',
							'nestedUpsellGroupedPath' => 'exif.displayExif',
							'visibleWhen'             => $modula_albums_nav_lightbox_on,
							'items'                   => $modula_albums_nav_fields( array( 'exif.displayExif' ) ),
						),
					),
				),
			),
		),
		array(
			'name'        => 'filters',
			'title'       => 'Filters',
			'description' => 'The album filters, and the bar visitors use to show some of the album’s galleries and albums.',
			/*
			 * The gallery's Filters tab (album ticket 22), in its order: the
			 * list, the All label, then Show the filter bar with its Filter bar
			 * box and, inside it, the Collapse box. Hidden for Slider, as the
			 * gallery hides it for its types without filters.
			 */
			'visibleWhen' => $modula_albums_nav_not_types( array( 'slider' ) ),
			'hubSections' => array(
				array(
					'type'  => 'submenu',
					'id'    => 'hub',
					'role'  => 'hub',
					'items' => array(
						$modula_albums_nav_field( 'filters.filters' ),
						$modula_albums_nav_field( 'filters.allFilterLabel' ),
						$modula_albums_nav_field( 'filters.showFilterBar' ),
						$modula_albums_nav_kids(
							'filter-bar',
							'Filter bar',
							'filters.showFilterBar',
							array(
								$modula_albums_nav_field( 'filters.filterTextAlignment' ),
								$modula_albums_nav_field( 'filters.filterPositioning' ),
								$modula_albums_nav_field( 'filters.defaultActiveFilter' ),
								$modula_albums_nav_field( 'filters.dropdownFilters' ),
								$modula_albums_nav_field( 'filters.hideAllFilter' ),
								$modula_albums_nav_field( 'filters.showFilterCount' ),
								$modula_albums_nav_field( 'filters.filterLinkColor' ),
								$modula_albums_nav_field( 'filters.filterLinkHoverColor' ),
								$modula_albums_nav_field( 'filters.enableCollapsibleFilters' ),
								$modula_albums_nav_kids( 'collapse', 'Collapse', 'filters.enableCollapsibleFilters', $modula_albums_nav_fields( array( 'filters.collapsibleActionText' ) ) ),
								$modula_albums_nav_field( 'filters.enableMobileDropdownFilters' ),
							)
						),
					),
				),
			),
		),
		array(
			'name'        => 'motion',
			'title'       => 'Motion',
			'description' => 'How covers appear and what they do under the pointer.',
			/*
			 * The gallery's slim picker (album ticket 15): Entrance, Speed,
			 * Hover, Darken on hover and Animate on phones; Darken on hover's
			 * Dim color in More settings › Overlay, as the gallery keeps it
			 * (its alpha is the strength; album ticket 25). Cursor and its
			 * upload sit in More settings › Cursor options under Change the
			 * cursor, shown only while it is on (Lite editor-qa ticket 14,
			 * album ticket 42).
			 * Hover hides for the types the catalog hides it for (Slider). The
			 * classic effect has no row: it is what the Hover menu's Custom
			 * plays, as a gallery's own hover builder is.
			 */
			'hubSections' => array(
				array(
					'type'  => 'submenu',
					'id'    => 'hub',
					'role'  => 'hub',
					'items' => array(
						$modula_albums_nav_field( 'motion.entrance' ),
						$modula_albums_nav_field( 'motion.speed' ),
						$modula_albums_nav_field(
							'motion.hover',
							array(
								'visibleWhen' => $modula_albums_nav_not_types( \Modula\V2\Motion\Animation_Catalog::menu_hidden_types( 'hover' ) ),
							)
						),
						$modula_albums_nav_field( 'hover.dimOverlay' ),
						$modula_albums_nav_field( 'motion.phones' ),
					),
				),
				array(
					'type'  => 'submenu',
					'id'    => 'more',
					'role'  => 'more',
					'label' => 'More settings',
					'items' => array(
						// Darken on hover's Dim color (tint and strength), while it is on.
						array(
							'type'        => 'drill',
							'id'          => 'overlay',
							'label'       => 'Overlay',
							'icon'        => 'brush',
							'visibleWhen' => array(
								'path'   => 'hover.dimOverlay',
								'truthy' => true,
							),
							'items'       => $modula_albums_nav_fields( array( 'hover.hoverColor' ) ),
						),
						// form-rules.json shows Cursor only while Change the cursor is on.
						array(
							'type'  => 'drill',
							'id'    => 'cursor-zoom',
							'label' => 'Cursor options',
							'icon'  => 'search',
							'items' => $modula_albums_nav_fields( array( 'hover.changeCursor', 'hover.cursor', 'hover.uploadCursor' ) ),
						),
					),
				),
			),
		),
		array(
			'name'        => 'interaction',
			'title'       => 'Interact',
			'description' => 'What visitors can download from the album.',
			'hubSections' => array(
				array(
					'type'  => 'submenu',
					'id'    => 'hub',
					'role'  => 'hub',
					'items' => array(
						$modula_albums_nav_field( 'download.enableDownload' ),
						$modula_albums_nav_kids(
							'download',
							'Download',
							'download.enableDownload',
							array(
								$modula_albums_nav_field( 'download.downloadGalleryButton' ),
								$modula_albums_nav_kids(
									'download-button',
									'Download button',
									'download.downloadGalleryButton',
									$modula_albums_nav_fields(
										array(
											'download.downloadGalleryButtonColor',
											'download.downloadGalleryButtonPosition',
										)
									)
								),
								$modula_albums_nav_field( 'download.downloadAllLightboxButton' ),
								$modula_albums_nav_field( 'download.downloadAllGalleryButton' ),
								$modula_albums_nav_kids(
									'album-button',
									'The album button',
									'download.downloadAllGalleryButton',
									$modula_albums_nav_fields(
										array(
											'download.downloadAllLabel',
											'download.downloadAllPosition',
											'download.downloadAllHposition',
											'download.downloadAllColor',
											'download.downloadAllBackgroundColor',
											'download.downloadAllGalleryButtonIcon',
											'download.downloadAllGalleryIconColor',
											'download.customZipName',
										)
									)
								),
								$modula_albums_nav_field( 'download.downloadImageSizes' ),
							)
						),
					),
				),
			),
		),
		array(
			'name'        => 'protection',
			'title'       => 'Protect',
			'description' => 'Password access and Image Guardian for this album.',
			'hubSections' => array(
				array(
					'type'  => 'submenu',
					'id'    => 'hub',
					'role'  => 'hub',
					'items' => array(
						$modula_albums_nav_field( 'passwordProtect.enablePassword' ),
						$modula_albums_nav_kids(
							'password',
							'Password',
							'passwordProtect.enablePassword',
							$modula_albums_nav_fields(
								array(
									'passwordProtect.password',
									// Kept under Password, as in the gallery.
									'passwordProtect.passwordProtectUsername',
									'passwordProtect.passwordProtectText',
								)
							)
						),
						array(
							'type'                    => 'drill',
							'id'                      => 'image-guardian',
							'label'                   => 'Image Guardian',
							'icon'                    => 'shield',
							'nestedUpsellGroupedPath' => 'protection.protection',
							'items'                   => $modula_albums_nav_fields(
								array(
									'protection.protection',
									'protection.blurProtection',
									'protection.urlProtection',
								)
							),
						),
					),
				),
			),
		),
	),
	'groupLabels' => array(
		'general'         => 'General',
		'layout'          => 'Layout',
		'navigation'      => 'Navigation',
		'lightbox'        => 'Lightbox',
		'filters'         => 'Filters',
		'captions'        => 'Captions & titles',
		'hover'           => 'Hover',
		'download'        => 'Download',
		'zoom'            => 'Zoom',
		'passwordProtect' => 'Password protect',
		'exif'            => 'EXIF',
		'protection'      => 'Image Guardian',
		'slider'          => 'Slider',
		'responsive'      => 'Responsive',
		'performance'     => 'Performance',
	),
);
