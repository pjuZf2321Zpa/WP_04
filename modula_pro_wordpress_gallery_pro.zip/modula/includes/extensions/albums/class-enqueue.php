<?php
namespace Modula_Pro\Extensions\Albums;

class Enqueue {
	private $extension_url = 'includes/extensions/albums';

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts_shortcode' ) );
	}

	public function enqueue_scripts_shortcode() {
		wp_register_style( 'modula-album-grid-system', \MODULA_PRO_URL . $this->extension_url . '/assets/css/front/modula-album-grid-system.css', null, \MODULA_PRO_VERSION );
		wp_register_script(
			'modula-album-custom-grid-cover-styles',
			MODULA_PRO_URL . $this->extension_url . '/assets/js/front/albumCustomGridCoverStyles.js',
			array(),
			\MODULA_PRO_VERSION,
			true
		);
		wp_register_script(
			'modula-albums',
			MODULA_PRO_URL . $this->extension_url . '/assets/js/front/modula-albums.js',
			array( 'jquery', 'modula-album-custom-grid-cover-styles' ),
			\MODULA_PRO_VERSION,
			true
		);

		// Modula scripts used for Tilt Hover Effects
		wp_register_script( 'modula-pro-tilt', \MODULA_PRO_URL . 'assets/js/misc/modula-pro-tilt.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}
}
