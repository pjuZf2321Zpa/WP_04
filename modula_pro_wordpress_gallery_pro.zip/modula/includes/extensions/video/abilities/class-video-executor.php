<?php
/** Explicit video source resolution and local video-item composition. Lite keeps schemas and retained-result inspection. */
namespace Modula_Pro\Extensions\Video\Abilities;

use Modula\V2\Abilities\Attachments;
use Modula\V2\Abilities\Composition;
use Modula\V2\Abilities\Integration;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Update;
use Modula\V2\Abilities\Video;
use Modula\V2\Abilities\Video_Explanation;
use Modula\V2\Beta_Settings;
use Modula\V2\Images\Adapter;
use Modula\V2\Meta_Sync;
use Modula_Pro\Extensions\Video\Admin\Google_Auth;
use Modula_Pro\Extensions\Video\Admin\Vimeo_Auth;
use Modula_Pro\Extensions\Video\Video as Service;

defined( 'ABSPATH' ) || exit;

final class Video_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Video::RESOLVE === $name ) {
			return self::resolve( $input );
		}
		if ( Video::UPDATE === $name ) {
			return self::compose( $input );
		}
		return Video_Explanation::rejected( $name, $input, Video::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Video::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function resolve( array $input ): array {
		$existing = Requests::existing( $input, Video::RESOLVE );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! self::supported_target( $input ) ) {
			return self::resolve_outcome( $input, 'rejected', 'unsupported_source_or_target' );
		}
		if ( 'playlist' === $input['kind'] ) {
			$configuration = self::playlist_configuration( (string) $input['url'] );
			if ( $configuration ) {
				return Video_Explanation::rejected( Video::RESOLVE, $input, array( $configuration ) );
			}
		}
		$claimed = Requests::claim( $input, Video::RESOLVE );
		if ( null !== $claimed ) {
			return $claimed;
		}
		return self::query_provider( $input );
	}

	/**
	 * Provider work stays after admission. Replay and composition never reach this method.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function query_provider( array $input ): array {
		$progress = array(
			'phase'    => 'provider_query',
			'sources'  => array(),
			'complete' => false,
		);
		$active   = false;
		try {
			Requests::context( $input['request_id'], array( 'video' => $progress ) );
			Revision::begin();
			$active = true;
			if ( Revision::state( $input['id'], true ) !== $input['revision'] ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], self::resolve_outcome( $input, 'conflict', 'stale_revision' ) );
			}
			if ( ! Video::available() ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], self::resolve_outcome( $input, 'rejected', 'feature_unavailable' ) );
			}
			if ( ! self::target_still_editable( $input ) ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], self::resolve_outcome( $input, 'forbidden', 'current_permission_denied' ) );
			}
			$complete = true;
			$snaps    = self::provider_snaps( $input, $complete );
			Revision::end( true );
			$active = false;
			if ( ! is_array( $snaps ) || isset( $snaps['error'] ) || ! $snaps ) {
				return Requests::finish( $input['request_id'], self::resolve_outcome( $input, 'rejected', 'provider_source_unavailable' ) + array( 'video' => $progress ) );
			}
			$accepted             = true;
			$progress             = self::remember_sources( $snaps, $progress, $input['request_id'], $accepted );
			$progress['phase']    = 'resolved';
			$progress['complete'] = $accepted && $complete && count( $snaps ) <= 100;
			$code                 = $progress['complete'] ? '' : 'provider_incomplete';
			return Requests::finish( $input['request_id'], self::resolve_outcome( $input, $progress['complete'] ? 'succeeded' : 'partial', $code ) + array( 'video' => $progress ) );
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			return Requests::finish( $input['request_id'], self::resolve_outcome( $input, 'uncertain', 'provider_unconfirmed' ) + array( 'video' => $progress ) );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function compose( array $input ): array {
		$existing = Requests::existing( $input, Video::UPDATE );
		if ( null !== $existing ) {
			return $existing;
		}
		$id = (int) $input['id'];
		if ( ! self::gallery_editable( $id ) ) {
			return self::compose_outcome( $input, 'forbidden', 'current_permission_denied', 'Current gallery and requested publication permissions are required.' );
		}
		if ( ! Beta_Settings::is_beta_gallery( $id ) || 'trash' === get_post_status( $id ) ) {
			return self::compose_outcome( $input, 'rejected', 'unsupported_target', 'Only existing Beta galleries outside trash can be patched.' );
		}
		if ( get_post_meta( $id, '_modula_bind_target_type', true ) ) {
			return self::compose_outcome( $input, 'rejected', 'unsupported_bound_target', 'Bound gallery mutations require the source-aware bound operations in their own delivery stage.' );
		}
		$claimed = Requests::claim( $input, Video::UPDATE );
		if ( null !== $claimed ) {
			return $claimed;
		}
		$transaction = false;
		try {
			Revision::begin();
			$transaction = true;
			$current     = Revision::state( $id, true );
			Revision::clear_cache();
			if ( ! hash_equals( $current, $input['revision'] ) ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $input['request_id'], self::compose_outcome( $input, 'conflict', 'stale_revision', 'Read the current gallery and reconcile changes before submitting a new request identity.' ) );
			}
			if ( ! Video::available() ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $input['request_id'], self::compose_outcome( $input, 'rejected', 'feature_unavailable', 'This video operation is not currently executable.' ) );
			}
			if ( ! self::gallery_editable( $id ) || ! Beta_Settings::is_beta_gallery( $id ) ) {
				throw new \RuntimeException( 'Access changed.' );
			}
			$changes     = $input['video_changes'];
			$attachments = Video::referenced_attachment_ids( $changes, $id );
			if ( $attachments ) {
				Revision::lock_attachments( $attachments );
			}
			$items = self::prepare( $id, $changes );
			if ( is_wp_error( $items ) ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $input['request_id'], self::compose_outcome( $input, 'rejected', $items->get_error_code(), $items->get_error_message() ) );
			}
			if ( ! Composition::persist( $id, $items ) ) {
				throw new \RuntimeException( 'Composition differs from requested values.' );
			}
			$out                        = self::compose_outcome( $input, 'succeeded' );
			$out['gallery']             = Integration::gallery( get_post( $id ) );
			$out['gallery']['revision'] = Revision::state( $id );
			$out                        = Requests::finish( $input['request_id'], $out );
			Revision::end( true );
			return $out;
		} catch ( \Throwable $error ) {
			if ( $transaction ) {
				Revision::end( false );
			}
			return Requests::finish( $input['request_id'], self::compose_outcome( $input, 'uncertain', 'update_unconfirmed', 'The patch was not confirmed. Recover this request and inspect the gallery before a new action.' ) );
		}
	}

	/**
	 * Local attachment metadata and retained sources only. This does not call the remote provider.
	 *
	 * @param array<int,array<string,mixed>> $changes
	 * @return array<int,array<string,mixed>>|\WP_Error
	 */
	private static function prepare( int $id, array $changes ) {
		foreach ( Video::referenced_attachment_ids( $changes, $id ) as $attachment ) {
			if ( ! Attachments::can_read( $attachment ) ) {
				return new \WP_Error( 'video_attachment_forbidden', 'Current source and poster rights required.' );
			}
		}
		$items  = Meta_Sync::get_images_v2( $id );
		$placed = array();
		foreach ( $changes as $change ) {
			$prepared = self::apply_change( $id, $items, $change, $placed );
			if ( is_wp_error( $prepared ) ) {
				return $prepared;
			}
			$items  = $prepared['items'];
			$placed = $prepared['placed'];
		}
		return Composition::validate_cells( $items, $placed );
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @param array<string,mixed>            $change
	 * @param array<string,bool>             $placed
	 * @return array{items:array<int,array<string,mixed>>,placed:array<string,bool>}|\WP_Error
	 */
	private static function apply_change( int $id, array $items, array $change, array $placed ) {
		$action  = $change['action'];
		$item_id = $change['item_id'];
		$index   = self::index( $items, $item_id );
		$invalid = self::reject_change( $action, $index, $items, $change );
		if ( is_wp_error( $invalid ) ) {
			return $invalid;
		}
		$row = 'add' === $action ? self::added_row( $id, $change ) : $items[ $index ];
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$rights = self::reject_local_rights( $row );
		if ( is_wp_error( $rights ) ) {
			return $rights;
		}
		if ( 'remove' === $action ) {
			array_splice( $items, $index, 1 );
			return array(
				'items'  => $items,
				'placed' => $placed,
			);
		}
		$fields = $change['fields'] ?? array();
		$row    = self::with_fields( $row, $fields );
		if ( array_intersect_key( $fields, Composition::layout_fields() ) ) {
			$placed[ $item_id ] = true;
		}
		if ( 'update' === $action ) {
			$items[ $index ] = $row;
			return array(
				'items'  => $items,
				'placed' => $placed,
			);
		}
		if ( 'move' === $action ) {
			array_splice( $items, $index, 1 );
		}
		$before = isset( $change['before_id'] ) ? self::index( $items, $change['before_id'] ) : count( $items );
		if ( $before < 0 ) {
			return new \WP_Error( 'invalid_video_anchor', 'before_id must identify one existing item.' );
		}
		array_splice( $items, $before, 0, array( Adapter::normalize_item_row( Adapter::strip_bootstrap_only_row_keys( $row ) ) ) );
		return array(
			'items'  => $items,
			'placed' => $placed,
		);
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @param array<string,mixed>            $change
	 * @return true|\WP_Error
	 */
	private static function reject_change( string $action, int $index, array $items, array $change ) {
		if ( self::identity_rejected( $action, $index, $items ) ) {
			return new \WP_Error( 'invalid_video_identity', 'Add needs an absent identity; other actions need one existing video item.' );
		}
		if ( self::change_shape_rejected( $action, $change ) ) {
			return new \WP_Error( 'invalid_video_change', 'Source is add-only; fields are add/update-only; before_id is add/move-only.' );
		}
		return true;
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 */
	private static function identity_rejected( string $action, int $index, array $items ): bool {
		if ( 'add' === $action ) {
			return -1 !== $index;
		}
		return $index < 0 || ! Adapter::is_video_template_row( $items[ $index ] );
	}

	/**
	 * @param array<string,mixed> $change
	 */
	private static function change_shape_rejected( string $action, array $change ): bool {
		$source_fields          = isset( $change['attachment_id'] ) || isset( $change['source_request_id'] ) || isset( $change['source_index'] );
		$fields_on_wrong_action = isset( $change['fields'] ) && ! in_array( $action, array( 'add', 'update' ), true );
		$anchor_on_wrong_action = isset( $change['before_id'] ) && ! in_array( $action, array( 'add', 'move' ), true );
		$fields                 = $change['fields'] ?? null;
		$update_without_fields  = 'update' === $action && ( ! is_array( $fields ) || 0 === count( $fields ) );
		return ( 'add' !== $action && $source_fields ) || $fields_on_wrong_action || $anchor_on_wrong_action || $update_without_fields;
	}

	/**
	 * @param array<string,mixed> $change
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function added_row( int $id, array $change ) {
		if ( isset( $change['attachment_id'] ) === isset( $change['source_request_id'] ) || ( isset( $change['source_request_id'] ) !== isset( $change['source_index'] ) ) ) {
			return new \WP_Error( 'invalid_video_source', 'Choose exactly one attachment or retained provider source.' );
		}
		if ( isset( $change['attachment_id'] ) ) {
			return self::attachment_row( $change );
		}
		return self::retained_source_row( $id, $change );
	}

	/**
	 * @param array<string,mixed> $change
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function attachment_row( array $change ) {
		$attachment = $change['attachment_id'];
		if ( ! Attachments::can_read( $attachment ) || 'trash' === get_post_status( $attachment ) || 0 !== strpos( (string) get_post_mime_type( $attachment ), 'video/' ) ) {
			return new \WP_Error( 'video_attachment_forbidden', 'An accessible existing video attachment is required.' );
		}
		$snap = Service::get_video_snap_from_attachment( $attachment );
		if ( ! is_array( $snap ) ) {
			return new \WP_Error( 'video_attachment_forbidden', 'An accessible existing video attachment is required.' );
		}
		$url = wp_get_attachment_url( $attachment );
		return self::video_row( $change['item_id'], is_string( $url ) ? $url : '', $snap );
	}

	/**
	 * Uses the stored resolve outcome. Does not query YouTube or Vimeo again.
	 *
	 * @param array<string,mixed> $change
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function retained_source_row( int $id, array $change ) {
		$record   = Requests::record( $change['source_request_id'] );
		$resolved = Requests::recover( array( 'request_id' => $change['source_request_id'] ) );
		if ( self::retained_source_missing( $id, $change, $record, $resolved ) ) {
			return new \WP_Error( 'video_source_unavailable', 'Use a confirmed retained source from this gallery and actor.' );
		}
		$snap = $resolved['video']['sources'][ $change['source_index'] ];
		return self::video_row( $change['item_id'], (string) ( $snap['video_url'] ?? '' ), $snap );
	}

	/**
	 * @param array<string,mixed>      $change
	 * @param array<string,mixed>|null $record
	 * @param array<string,mixed>      $resolved
	 */
	private static function retained_source_missing( int $id, array $change, $record, array $resolved ): bool {
		if ( ! is_array( $record ) || Video::RESOLVE !== ( $record['operation'] ?? '' ) ) {
			return true;
		}
		if ( $id !== (int) ( $record['target'] ?? 0 ) ) {
			return true;
		}
		if ( ! in_array( $resolved['status'] ?? '', array( 'succeeded', 'partial' ), true ) ) {
			return true;
		}
		return ! isset( $resolved['video']['sources'][ $change['source_index'] ] );
	}

	/**
	 * @param array<string,mixed> $snap
	 * @return array<string,mixed>
	 */
	private static function video_row( string $item_id, string $url, array $snap ): array {
		return array(
			'id'                 => $item_id,
			'video_template'     => '1',
			'video_url'          => $url,
			'video_title'        => $snap['title'] ?? '',
			'video_alt'          => '',
			'video_description'  => $snap['description'] ?? '',
			'thumbnail'          => $snap['thumb'] ?? '',
			'video_thumbnail'    => $snap['thumb'] ?? '',
			'full'               => $snap['thumb'] ?? '',
			'title'              => $snap['title'] ?? '',
			'description'        => $snap['description'] ?? '',
			'width'              => 2,
			'height'             => 2,
			'video_width'        => $snap['width'] ?? 1920,
			'video_height'       => $snap['height'] ?? 1080,
			'autoplay_thumbnail' => 'inherit',
			'autoplay_lightbox'  => 'inherit',
			'loop_video'         => 'inherit',
			'halign'             => 'center',
			'valign'             => 'middle',
			'link'               => '',
			'target'             => '',
			'togglelightbox'     => '',
		);
	}

	/**
	 * @param array<string,mixed> $row
	 * @return true|\WP_Error
	 */
	private static function reject_local_rights( array $row ) {
		$local_id = attachment_url_to_postid( $row['video_url'] ?? '' );
		if ( $local_id && ! Attachments::can_read( $local_id ) ) {
			return new \WP_Error( 'video_attachment_forbidden', 'Current video attachment rights required.' );
		}
		return true;
	}

	/**
	 * @param array<string,mixed> $row
	 * @param array<string,mixed> $fields
	 * @return array<string,mixed>
	 */
	private static function with_fields( array $row, array $fields ): array {
		$row = array_replace( $row, $fields );
		foreach ( array(
			'video_title'       => 'title',
			'video_description' => 'description',
		) as $source => $target ) {
			if ( isset( $fields[ $source ] ) ) {
				$row[ $target ] = sanitize_textarea_field( $fields[ $source ] );
				$row[ $source ] = $row[ $target ];
			}
		}
		if ( isset( $fields['video_alt'] ) ) {
			$row['video_alt'] = sanitize_text_field( $fields['video_alt'] );
		}
		return $row;
	}

	/**
	 * @param array<string,mixed> $input
	 */
	private static function supported_target( array $input ): bool {
		$id = (int) $input['id'];
		return Beta_Settings::is_beta_gallery( $id ) && 'trash' !== get_post_status( $id ) && ! get_post_meta( $id, '_modula_bind_target_type', true ) && Service::supported_provider_url( (string) $input['url'], 'playlist' === $input['kind'] );
	}

	/**
	 * @param array<string,mixed> $input
	 */
	private static function target_still_editable( array $input ): bool {
		$id = (int) $input['id'];
		return Video::can_recover( array( 'target' => $id ) ) && Beta_Settings::is_beta_gallery( $id ) && 'trash' !== get_post_status( $id ) && ! get_post_meta( $id, '_modula_bind_target_type', true );
	}

	private static function gallery_editable( int $id ): bool {
		return Update::can_update( $id );
	}

	/**
	 * Missing playlist account is configuration, distinct from an unavailable source.
	 * Single videos keep the service fallback and are not blocked here.
	 *
	 * @return array<string,mixed>
	 */
	private static function playlist_configuration( string $url ): array {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( in_array( $host, array( 'youtube.com', 'www.youtube.com', 'youtu.be' ), true ) ) {
			return self::account_blocker( Google_Auth::$access_token, __( 'Connect the Google account used for YouTube playlists before resolving this source.', 'modula-pro' ) );
		}
		if ( in_array( $host, array( 'vimeo.com', 'www.vimeo.com' ), true ) ) {
			return self::account_blocker( Vimeo_Auth::$access_token, __( 'Connect the Vimeo account that owns this channel or Showcase before resolving this source.', 'modula-pro' ) );
		}
		return array();
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function account_blocker( string $option, string $explanation ): array {
		$token = get_option( $option, false );
		if ( is_string( $token ) && '' !== $token ) {
			return array();
		}
		return array(
			'reason'  => 'configuration_required',
			'feature' => 'modula-video',
			'remedy'  => array(
				'action'      => 'configure_service',
				'explanation' => $explanation,
				'destination' => admin_url( 'edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media' ),
			),
		);
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<int,array<string,mixed>>|false
	 */
	private static function provider_snaps( array $input, bool &$complete ) {
		$complete = true;
		if ( 'playlist' === $input['kind'] ) {
			return Service::get_video_playlist_snap( $input['url'], $input['max_sources'] ?? 100, $complete );
		}
		$snap = Service::get_video_snap( $input['url'], true );
		return is_array( $snap ) ? array( $snap + array( 'video_url' => $input['url'] ) ) : array();
	}

	/**
	 * @param array<int,mixed>     $snaps
	 * @param array<string,mixed> $progress
	 * @param bool                $accepted True when every returned source passed the URL bound.
	 * @return array<string,mixed>
	 */
	private static function remember_sources( array $snaps, array $progress, string $request_id, bool &$accepted ): array {
		$accepted = true;
		foreach ( array_slice( $snaps, 0, 100 ) as $snap ) {
			if ( ! is_array( $snap ) || ! Service::supported_provider_url( (string) ( $snap['video_url'] ?? '' ) ) ) {
				$accepted = false;
				continue;
			}
			$progress['sources'][] = self::clean_source( $snap, (string) $snap['video_url'] );
			Requests::context( $request_id, array( 'video' => $progress ) );
		}
		return $progress;
	}

	/**
	 * @param array<string,mixed> $snap
	 * @return array<string,string|int>
	 */
	private static function clean_source( array $snap, string $url ): array {
		return array(
			'video_url'   => $url,
			'title'       => sanitize_text_field( (string) ( $snap['title'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $snap['description'] ?? '' ) ),
			'thumb'       => esc_url_raw( (string) ( $snap['thumb'] ?? '' ), array( 'http', 'https' ) ),
			'width'       => max( 1, (int) ( $snap['width'] ?? 1920 ) ),
			'height'      => max( 1, (int) ( $snap['height'] ?? 1080 ) ),
		);
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function resolve_outcome( array $input, string $status, string $code = '' ): array {
		$message = $code ? 'Inspect retained sources; do not repeat an uncertain provider request.' : '';
		return Requests::outcome( $input['request_id'], $status, $code, $message, Video::RESOLVE );
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function compose_outcome( array $input, string $status, string $code = '', string $message = '' ): array {
		return Requests::outcome( $input['request_id'], $status, $code, $message, Video::UPDATE );
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @param mixed                          $id
	 */
	private static function index( array $items, $id ): int {
		$found = array_keys(
			array_filter(
				$items,
				static function ( $row ) use ( $id ) {
					return (string) ( $row['id'] ?? '' ) === (string) $id;
				}
			)
		);
		return 1 === count( $found ) ? $found[0] : -1;
	}
}
