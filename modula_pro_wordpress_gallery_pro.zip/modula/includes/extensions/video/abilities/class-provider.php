<?php
/** Pro contribution for video source resolution and video-item composition. */
namespace Modula_Pro\Extensions\Video\Abilities;

use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;
use Modula\V2\Abilities\Video;
use Modula\V2\Abilities\Video_Explanation;

defined( 'ABSPATH' ) || exit;

final class Provider {
	public const ID = 'modula-pro-video';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! Pro_Dependency::extension_contract( 'modula-video' ) || ! Pro_Dependency::host_executor_ready( Video::RESOLVE ) ) {
			return $contributions;
		}
		$operations = array();
		foreach ( Video_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck gallery admission and the video feature before any effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Video::explain_blockers( $name, $input );
		if ( ! $blockers ) {
			return null;
		}
		return Video_Explanation::rejected( $name, $input, $blockers );
	}
}
