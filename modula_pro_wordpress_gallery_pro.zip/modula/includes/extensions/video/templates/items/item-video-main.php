<div class="modula-video-main-item"<?php echo \Modula_Helper::generate_attributes( $data->item_attributes ); ?> >
	<div class="modula-video-main-item-content">

		<?php
		echo '<div style="position: relative; width: 100%; padding-top: 56.25%;">'; // Aspect ratio 16:9 (pentru a se potrivi cu videoclipurile YouTube)
			echo '<div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">';
					$modula_video = \Modula_Pro\Extensions\Video\Video::get_instance();
					// Verificăm tipul de link și generăm iframe-ul corespunzător
					$video_url = $data->link_attributes['data-full'];
					$autoplay  = isset( $data->video_attributes['data-autothumb'] ) && '0' != $data->video_attributes['data-autothumb'] ? 1 : 0;
					$img_url   = isset( $data->img_attributes['data-src'] ) ? $data->img_attributes['data-src'] : false;

		if ( 0 === (int) $autoplay && $img_url ) {
			echo '<img src="' . esc_attr( $img_url ) . '" class="modula_video_preview_image" />';
			$modula_video->output_video_icon( $data );
		}

		if ( strpos( $video_url, 'youtube.com' ) !== false || strpos( $video_url, 'youtu.be' ) !== false ) {
			// YouTube link
			$videoId = \Modula_Pro\Extensions\Video\Video::get_youtube_video_id( $video_url );

			if ( $videoId ) {
				echo '<div width="100%" height="100%" video_type="youtube" video_autoplay="' . $autoplay . '" video_id="' . esc_attr( $videoId ) . '" id="modula-video-player" class="modula_video_preview_element" /></div>';
			}
		} elseif ( strpos( $video_url, 'vimeo.com' ) !== false ) {
			// Vimeo link
			$videoId = \Modula_Pro\Extensions\Video\Video::get_vimeo_video_id( $video_url );

			if ( $videoId ) {
				echo '<div width="100%" height="100%" video_type="vimeo" video_autoplay="' . $autoplay . '" video_id="' . esc_attr( $videoId ) . '" id="modula-video-player" class="modula_video_preview_element" /></div>';
			}
		} else {
			// Fișier video local
			echo '<div width="100%" height="100%" video_type="hosted" video_autoplay="' . $autoplay . '" video_id="' . esc_attr( $video_url ) . '" id="modula-video-player" class="modula_video_preview_element" /></div>';
		}

					/**
					 * Hook: modula_item_after_video
					 */
					do_action( 'modula_item_after_video', $data );
			echo '</div>';
		echo '</div>';
		?>

	</div>

</div>
