<div class="<?php echo esc_attr( implode( ' ', $data->item_classes ) ); ?>"<?php echo \Modula_Helper::generate_attributes( $data->item_attributes ); ?> >

	<div class="modula-item-content">

		<?php do_action( 'modula_item_before_link', $data ); ?>
		<?php
			$modula_video = \Modula_Pro\Extensions\Video\Video::get_instance();
			// Verificăm tipul de link și generăm iframe-ul corespunzător
			$video_url = $data->link_attributes['data-full'];
			$autoplay  = isset( $data->video_attributes['data-autothumb'] ) && '0' != $data->video_attributes['data-autothumb'] ? 1 : 0;
		if ( strpos( $video_url, 'youtube.com' ) !== false || strpos( $video_url, 'youtu.be' ) !== false ) {
			// YouTube link
			$videoId   = \Modula_Pro\Extensions\Video\Video::get_youtube_video_id( $video_url );
			$videoType = 'youtube';
		} elseif ( strpos( $video_url, 'vimeo.com' ) !== false ) {
			// Vimeo link
			$videoId   = \Modula_Pro\Extensions\Video\Video::get_vimeo_video_id( $video_url );
			$videoType = 'vimeo';
		} else {
			$videoId   = $video_url;
			$videoType = 'hosted';
		}
		?>
		<div 
			class="modula-video-list-overlay" 
			video_id="<?php echo esc_attr( $videoId ); ?>"
			video_type="<?php echo esc_attr( $videoType ); ?>"
			video_autoplay="<?php echo esc_attr( $autoplay ); ?>"
			video_thumb="<?php echo esc_attr( $data->img_attributes['data-src'] ); ?>"
		></div>

		<?php
		/**
		 * Hook: modula_item_after_link
		 */
		do_action( 'modula_item_after_link', $data );

		/**
		 *Hook : modula_item_template_image
		 * @hooked: modula_sources_and_sizes
		 */
		do_action( 'modula_item_template_image', $data );

		?>

	</div>

</div>
