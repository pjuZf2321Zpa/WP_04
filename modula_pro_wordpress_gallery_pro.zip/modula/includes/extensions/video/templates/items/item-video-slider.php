<div class="modula-video-slider-item <?php echo esc_attr( implode( ' ', $data->item_classes ) ); ?>" <?php echo \Modula_Helper::generate_attributes( $data->item_attributes ); ?>>
	
	<?php if ( 'no-link' !== $data->lightbox && isset( $data->is_custom_url ) ) : ?>
	<div class="slider-clickable">
		<?php endif ?>

		<?php do_action( 'modula_slider_item_before_link', $data ); ?>

		<?php if ( 'no-link' !== $data->lightbox ) : ?>
			<a<?php echo \Modula_Helper::generate_attributes( $data->link_attributes ); ?>
					class="<?php echo esc_attr( implode( ' ', $data->link_classes ) ); ?>"></a>
		<?php else : ?>
			<div class="modula_video_slider_overlay"></div>
		<?php endif ?>
		<?php do_action( 'modula_slider_item_after_link', $data ); ?>
		
			<div class="modula_video_slider_positioner">
			
				<?php if ( ! isset( $data->is_video ) || false === $data->is_video ) : ?>
					
					<?php
					/**
					 *Hook : modula_item_template_image
					* @hooked: modula_sources_and_sizes
					*/
					do_action( 'modula_item_template_image', $data );
					?>

				<?php endif ?>

		<?php do_action( 'modula_slider_item_after_image', $data ); ?>
		</div>
		<?php if ( 'no-link' !== $data->lightbox && isset( $data->is_custom_url ) ) : ?>
	</div>
<?php endif ?>

	<?php if ( isset( $data->slider_image_info ) && 1 === (int) $data->slider_image_info ) { ?>
		<div class="slider-image-info">
			<?php if ( ! $data->hide_title ) : ?>
				<p class='jtg-title'><?php echo wp_kses_post( $data->title ); ?></p>
			<?php endif ?>
			<?php if ( ! $data->hide_description ) : ?>
				<p class="description"><?php echo wp_kses_post( $data->description ); ?></p>
			<?php endif ?>
		</div>
	<?php } ?>

</div>
