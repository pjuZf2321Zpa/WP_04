<!-- Gallery Container -->
<div <?php echo \Modula_Helper::generate_attributes( $data->gallery_container ); ?>>
	
	<?php do_action( 'modula_shortcode_before_video_items', $data->settings ); ?>
	
	<div class="modula-video-player-wrap <?php echo isset( $data->settings['playlist_position'] ) ? 'playlist_' . esc_attr( $data->settings['playlist_position'] ) : 'playlist_right'; ?>" >
		<?php
		$main      = false;
		$list      = '';
		$item_data = array();
		foreach ( $data->images as $image ) {
			$image['title']       = isset( $image['title'] ) ? $image['title'] : '';
			$image['description'] = isset( $image['description'] ) ? $image['description'] : '';
			$image['alt']         = isset( $image['alt'] ) ? $image['alt'] : '';

			if ( apply_filters( 'modula_check_item_not_video', ( empty( $image['video_url'] ) ), $image ) ) {
				continue;
			}

			// Create array with data in order to send it to image template
			$item_data = array(
				/* Item Elements */
				'title'            => \Modula_Helper::get_title( $image, 'title' ),
				'description'      => \Modula_Helper::get_description( $image, 'caption' ),
				'lightbox'         => $data->settings['lightbox'],

				/* What to show from elements */
				'hide_title'       => boolval( $data->settings['hide_title'] ) ? true : false,
				'hide_description' => boolval( $data->settings['hide_description'] ) ? true : false,
				'hide_socials'     => ! boolval( $data->settings['enableSocial'] ),
				'enableTwitter'    => boolval( $data->settings['enableTwitter'] ),
				'enableWhatsapp'   => boolval( $data->settings['enableWhatsapp'] ),
				'enableFacebook'   => boolval( $data->settings['enableFacebook'] ),
				'enablePinterest'  => boolval( $data->settings['enablePinterest'] ),
				'enableLinkedin'   => boolval( $data->settings['enableLinkedin'] ),
				'enableEmail'      => boolval( $data->settings['enableEmail'] ),
				'lazyLoad'         => boolval( $data->settings['lazy_load'] ),

				/* Item container attributes & classes */
				'item_classes'     => array( 'modula-video-item' ),
				'item_attributes'  => array(),

				/* Item link attributes & classes */
				'link_attributes'  => array(
					'data-image-id' => $image['id'],
				),

				/* Item img attributes & classes */
				'img_classes'      => array( 'pic', 'wp-image-' . $image['id'] ),

				'img_attributes'   => array(
					'data-valign' => esc_attr( $image['valign'] ),
					'data-halign' => esc_attr( $image['halign'] ),
					'alt'         => $image['alt'],
					'data-full'   => esc_url( wp_get_original_image_url( $image['id'] ) ),
					'title'       => $image['title'],
				),
			);

			if ( isset( $image['togglelightbox'] ) && 1 === $image['togglelightbox'] ) {
				$item_data['link_classes'][] = 'modula-simple-link'; //prevent the lightboxification
				$item_data['link_classes'][] = 'modula-no-follow'; //prevent the opening of the image
			}
			// need this to model the image attributes.
			$image = apply_filters( 'modula_shortcode_image_data', $image, $data->settings );

			/**
			 * Hook: modula_shortcode_item_data.
			 *
			 * @hooked modula_generate_image_links - 10
			 * @hooked modula_check_lightboxes_and_links - 15
			 * @hooked modula_check_hover_effect - 20
			 * @hooked modula_check_custom_grid - 25
			 * @hooked modula_enable_lazy_load - 30
			 *
			 */

			$item_data = apply_filters( 'modula_shortcode_item_data', $item_data, $image, $data->settings, $data->images );

			if ( ! $main ) {
				ob_start();
					do_action( 'modula_shortcode_before_main_item', $data->settings, $item_data );
					$data->loader->set_template_data( $item_data );
					$data->loader->get_template_part( 'items/item', 'video-main' );
					do_action( 'modula_shortcode_after_main_item', $data->settings, $item_data );
				$main = ob_get_clean();
			}

			// if the list is empty, this is the first element.
			if ( empty( $list ) ) {
				$item_data['item_classes'][] = 'current-item';
			}

			// Items Container
			ob_start();
				do_action( 'modula_shortcode_before_video_item', $data->settings, $item_data );
				$data->loader->set_template_data( $item_data );
				$data->loader->get_template_part( 'items/item', 'video-list' );
				do_action( 'modula_shortcode_after_video_item', $data->settings, $item_data );
			$list .= ob_get_clean();
		}
		if ( $main ) {
			echo $main;
			if ( ! empty( $list ) ) {
				echo '<div class="modula-video-items-wrap" >';
					echo '<div class="modula-video-items" >';
						echo $list;
					echo '</div>';
				echo '</div>';
			}
		}

		?>
	</div>
	
	<?php

	/**
	 * Hook: modula_shortcode_after_items.
	 *
	 * @hooked modula_edit_gallery - 100
	 * @hooked modula_show_schemaorg - 90
	 * @hooked modula_show_items_schemaorg - 91
	 * @hooked modula_slider_syncing - 85
	 */
	do_action( 'modula_shortcode_after_video_items', $data->settings, $item_data, $data->images );
	?>

</div>
