<?php
namespace Modula_Pro\Extensions\Video;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	/**
	 * Extension URL
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	private $extension_url = 'includes/extensions/video';

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'modula_extra_scripts', array( $this, 'modula_video_scripts' ), 10, 2 );

		// Add extra scripts to albums
		add_action( 'modula_album_extra_scripts', array( $this, 'modula_video_albums_scripts' ) );

		// Register & enqueue scripts for lightbox video
		add_action( 'wp_enqueue_scripts', array( $this, 'register_lightgallery_video_script' ) );
		add_action( 'modula_lighbox_shortcode', array( $this, 'enqueue_lightgallery_video_script' ), 11 );

		add_action( 'modula_block_style', array( $this, 'enqueue_modula_block_styles' ) );
		add_action( 'modula_block_scripts', array( $this, 'enqueue_modula_block_scripts' ) );
	}

	/**
	 * Register lightgallery video script.
	 *
	 * @since 1.0.0
	 */
	public function register_lightgallery_video_script() {
		wp_register_script( 'lightgallery-video', \MODULA_PRO_URL . 'includes/extensions/video/assets/js/lg-video.min.js', array( 'jquery' ), null, true );
	}

	/**
	 * If the current lightbox is lightgallery enqueue the lightgallery video script.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_lightgallery_video_script( $lightbox ) {

		if ( 'lightgallery' === $lightbox ) {
			wp_enqueue_script( 'lightgallery-video' );
		}
	}

	/**
	 * Enqueue needed scripts
	 *
	 * @since 1.0.5
	 */
	public function register_scripts() {

		// Youtube Player
		wp_register_script( 'modula-youtube-iframe', \MODULA_PRO_URL . $this->extension_url . '/assets/js/src/youtube-iframeapi.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-youtube-widget', \MODULA_PRO_URL . $this->extension_url . '/assets/js/src/youtube-widgetapi.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-youtube-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/youtube-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );

		// Vimeo Player
		wp_register_script( 'modula-vimeo-player', \MODULA_PRO_URL . $this->extension_url . '/assets/js/src/vimeo-player.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-vimeo-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/vimeo-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );

		wp_register_script( 'modula-fancybox-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/fancybox-modula-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_script( 'modula-video-preview', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-video-preview.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_register_style( 'modula-video-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-video-css.css', array(), \MODULA_PRO_VERSION );
		wp_register_script( 'modula-albums-fancybox-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/fancybox-albums-modula-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}

		/**
	 * Enqueue needed scripts for galleries
	 *
	 * @param $settings
	 * @param $images
	 *
	 * @since 1.1.0 added video players scripts.
	 */
	public function modula_video_scripts( $settings, $images = array() ) {
		$is_modern_video_gallery = class_exists( '\Modula\V2\Modern_Gallery' )
			&& \Modula\V2\Modern_Gallery::is_modern_stack_enabled( \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( is_array( $settings ) ? $settings : array() ) )
			&& isset( $settings['type'] )
			&& 'video' === $settings['type'];

		$preview_enabled = Video::is_preview_video_enabled( isset( $settings['preview-video'] ) ? $settings['preview-video'] : 0 );
		if ( $preview_enabled || ( isset( $settings['type'] ) && 'video' === $settings['type'] ) ) {
			$players = array(
				'youtu' => 1,
				'vimeo' => 1,
			);
			foreach ( $images as $img ) {
				if ( isset( $img['video_url'] ) && ! empty( $players ) ) {
					if ( isset( $players['youtu'] ) && false !== strpos( $img['video_url'], 'youtu' ) ) {
						wp_enqueue_script( 'modula-youtube-iframe' );
						wp_enqueue_script( 'modula-youtube-widget' );
						wp_enqueue_script( 'modula-youtube-video' );
						unset( $players['youtu'] );
					}
					if ( isset( $players['vimeo'] ) && false !== strpos( $img['video_url'], 'vimeo' ) ) {
						wp_enqueue_script( 'modula-vimeo-player' );
						wp_enqueue_script( 'modula-vimeo-video' );
						unset( $players['vimeo'] );
					}
				}
			}

			if ( ! $is_modern_video_gallery ) {
				wp_enqueue_script( 'modula-video-preview' );
				wp_add_inline_script( 'modula-video-preview', 'var modulaVideoPreview = ' . wp_json_encode( array( 'duration' => isset( $settings['preview-video-duration'] ) ? absint( $settings['preview-video-duration'] ) : 3 ) ) . ';', 'before' );
			}
		}

		wp_enqueue_script( 'modula-fancybox-video' );
		if ( ! $is_modern_video_gallery ) {
			wp_enqueue_style( 'modula-video-css' );
		}
	}

	/**
	 * Enqueue needed scripts for albums
	 *
	 * @since 1.0.5
	 */
	public function modula_video_albums_scripts() {
		wp_enqueue_script( 'modula-albums-fancybox-video' );
		wp_enqueue_script( 'modula-video-preview' );
		wp_enqueue_script( 'modula-youtube-video' );
		wp_enqueue_script( 'modula-vimeo-video' );
		wp_enqueue_style( 'modula-video-css' );
	}

	public function enqueue_modula_block_styles() {
		wp_enqueue_style( 'modula-video-css', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-video-css.css', array(), \MODULA_PRO_VERSION );
	}

	public function enqueue_modula_block_scripts() {
		wp_enqueue_script( 'modula-youtube-iframe', \MODULA_PRO_URL . $this->extension_url . '/assets/js/src/youtube-iframeapi.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-youtube-widget', \MODULA_PRO_URL . $this->extension_url . '/assets/js/src/youtube-widgetapi.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-youtube-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/youtube-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-vimeo-player', \MODULA_PRO_URL . $this->extension_url . '/assets/js/src/vimeo-player.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-vimeo-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/vimeo-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-fancybox-video', \MODULA_PRO_URL . $this->extension_url . '/assets/js/fancybox-modula-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-video-preview', \MODULA_PRO_URL . $this->extension_url . '/assets/js/modula-video-preview.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_add_inline_script( 'modula-video-preview', 'var modulaVideoPreview = ' . wp_json_encode( array( 'duration' => 3 ) ) . ';', 'before' );
	}
}
