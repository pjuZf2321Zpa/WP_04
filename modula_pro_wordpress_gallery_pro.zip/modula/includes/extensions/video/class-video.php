<?php
namespace Modula_Pro\Extensions\Video;

use Modula_Pro\Extensions\Video\Admin\Google_Auth;
use Modula_Pro\Extensions\Video\Admin\Video_Settings;
use Modula_Pro\Extensions\Video\Admin\Vimeo_Auth;
use WPChill\Modula_Pro\Vendor\Google\Client as GoogleClient;
use WPChill\Modula_Pro\Vendor\Google\Service\YouTube;
use WPChill\Modula_Pro\Vendor\GuzzleHttp\Client;
use WPChill\Modula_Pro\Vendor\GuzzleHttp\Exception\ClientException;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Video {
	/**
	 * The poster of a video with no image, under the plugin URL.
	 */
	private const NO_IMAGE_POSTER = 'includes/extensions/video/assets/img/no-image.jpg';

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *ca
	 * @var object
	 */
	public static $instance;

	/**
	 * Holds the item data.
	 *
	 * @since 1.0.0
	 *
	 * @var array
	 */
	public $item_data = false;

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Video object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Video ) ) {
			self::$instance = new Video();
		}

		return self::$instance;
	}

	public function __construct() {
		$this->set_plugin_requirements();
		require_once __DIR__ . '/abilities/class-video-executor.php';
		require_once __DIR__ . '/abilities/class-provider.php';
		\Modula_Pro\Extensions\Video\Abilities\Provider::boot();

		// Moved here because we need to do the sanitization in REST API as well, not only on admin side.
		add_filter( 'modula_image_field_sanitization', array( $this, 'modula_video_image_fields_sanitization' ), 10, 3 );
		// Specify the modula video image fields. Moved here because we need to do the sanitization in REST API as well, not only on admin side.
		add_filter( 'modula_gallery_image_attributes', array( $this, 'add_item_fields' ) );

		// v2 settings editor snap / playlist — must register outside is_admin().
		new Rest_API\WP_Rest_Modula_Video_Controller();

		if ( is_admin() ) {
			new Admin\Settings_Editor_Integration();
		}
	}


	/**
	 * Set admin requirements and check for license.
	 *
	 * @return void
	 * @since 1.0.7
	 */
	public function set_plugin_requirements() {

		add_filter( 'modula_shortcode_video_item_data', array( $this, 'add_video' ), 5, 3 );
		add_filter( 'modula_shortcode_video_item_data', array( $this, 'modula_slider_add_video_class' ), 91, 3 );

		add_filter( 'modula_shortcode_item_data', array( $this, 'add_video' ), 5, 3 );
		add_filter( 'modula_shortcode_item_data', array( $this, 'modula_slider_add_video_class' ), 91, 3 );

		if ( is_admin() ) {
			$this->init_admin();
		}

		add_action( 'modula_slider_after_thumbnail', array( $this, 'output_video_icon_to_slider_thumb' ), 10, 3 );

		// Filter fancybox video options
		add_filter( 'modula_fancybox_options', array( $this, 'video_fancybox_options' ), 11, 2 );

		// Add video css
		add_filter( 'modula_shortcode_css', array( $this, 'generate_video_css' ), 15, 3 );

		// Video in modula-link
		add_filter( 'modula_link_item', array( $this, 'modula_video_link' ), 10, 2 );

		// Video slider
		add_action( 'modula_slider_item_after_image', array( $this, 'modula_video_after_image_slider' ) );

		// Albums integration
		add_filter( 'modula_album_lightbox_item', array( $this, 'add_video_to_albums' ), 10, 3 );
		add_filter( 'modula_album_visitor_lightbox_item', array( $this, 'album_visitor_lightbox_video' ), 10, 3 );

		// add video data to migrator
		add_filter( 'modula_migrate_gallery_data', array( $this, 'modula_video_migrator_data' ), 25, 3 );

		// Register scripts
		new Enqueue();

		// Filter Defaults
		add_filter( 'modula_lite_default_settings', array( $this, 'default_settings' ) );

		// Add video thumbnail image
		add_filter( 'modula_shortcode_video_item_data', array( $this, 'add_link_data' ), 26, 3 );
		add_filter( 'modula_shortcode_item_data', array( $this, 'add_link_data' ), 26, 3 );
		add_filter( 'modula_hidden_items_data', array( $this, 'add_hidden_video' ), 26, 3 );

		add_action( 'modula_item_template_image', array( $this, 'modula_video_inject_tag' ), 99 );
		add_action( 'modula_slider_item_after_image', array( $this, 'modula_video_inject_slider_tag' ), 99 );

		add_filter( 'modula_resize_images', array( $this, 'prevent_resize_video_template' ), 19 );
		add_filter( 'modula_check_item_not_image', array( $this, 'check_item_not_image' ), 10, 2 );
		add_filter( 'modula_shortcode_video_item_data', array( $this, 'resize_video_template' ), 15, 3 );
		add_filter( 'modula_shortcode_item_data', array( $this, 'resize_video_template' ), 15, 3 );
		add_filter( 'modula_album_shortcode_item_data', array( $this, 'add_video_to_albums_config' ), 15, 5 );

		// Add new path for templates.
		add_filter( 'modula_template_paths', array( $this, 'add_modula_slider_templates_path' ), 20 );
		add_filter( 'modula_gallery_template_name', array( $this, 'modula_video_template_name' ), 10, 2 );

		add_filter( 'modula_item_template_name', array( $this, 'modula_video_slider_item_template_name' ), 10, 3 );
	}

	/**
	 * Inserts the video preview tag into slider
	 *
	 * @param $data
	 *
	 * @return void
	 * @since 1.1.0
	 */
	public function modula_video_inject_tag( $data ) {
		$this->output_video_icon( $data );
		if ( ! isset( $data->video_type ) ) {
			return;
		}

		if ( '' === $data->video_type ) {
			return;
		}

		switch ( $data->video_type ) {
			case 'hosted':
				?>
				<video autoplay muted="true" loop="true" playsinline webkit-playsinline src="
				<?php
				echo esc_attr( $data->link_attributes['data-full'] );
				?>
				" class="modula_video_preview_element" 
				<?php
				//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo \Modula_Helper::generate_attributes( $data->video_attributes );
				?>
				>
					<source src="
					<?php
					echo esc_attr( $data->link_attributes['data-full'] );
					?>
					" type="video/mp4">
					<?php
					echo esc_html__( 'Your browser does not support the video tag.', 'modula-pro' );
					?>
				</video>
				<?php
				break;
			case 'youtube':
				$video_src = self::get_youtube_video_id( $data->link_attributes['data-full'] );
				?>
				<youtube-video  video_id="<?php echo esc_attr( $video_src ); ?>" class="modula_video_preview_element" 
				<?php
				//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo \Modula_Helper::generate_attributes( $data->video_attributes );
				?>
				autoplay /></youtube-video>
				<?php
				break;
			case 'vimeo':
				?>
				<vimeo-video video_src="<?php echo esc_attr( $data->link_attributes['data-full'] ); ?>" class="modula_video_preview_element" 
				<?php
				//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo \Modula_Helper::generate_attributes( $data->video_attributes );
				?>
				autoplay/>
				<?php
				break;
		}
	}

	/**
	 * By default, Modula Slider has the img template action disabled in case of video
	 * we need the slider image to show up in case of preview so this method adds it back.
	 *
	 * @param $data
	 *
	 * @return void
	 * @since 1.1.0
	 */
	public function modula_video_inject_slider_tag( $data ) {
		if ( ! isset( $data->preview_video ) || ! $data->preview_video ) {
			return;
		}
		if ( ! isset( $data->is_video ) || ! $data->is_video ) {
			return;
		}
		?>
		<div class="video-sizer">
			<?php do_action( 'modula_item_template_image', $data ); ?>
		</div>
		<?php
	}

	/**
	 * Initializes the admin part of plugin and checks for license.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function init_admin() {
		Google_Auth::get_instance();
		Vimeo_Auth::get_instance();
		new Video_Settings();
	}

	/**
		 * Display video in link shortcode
		 *
		 * @param $image
		 * @param $item
		 * @return $image
		 */
	public function modula_video_link( $image, $item ) {

		if ( isset( $item['video_url'] ) && '' !== $item['video_url'] ) {
			$image['src'] = $item['video_url'];
		}

		return $image;
	}

	/**
	 * Output video icon, if enabled, for each gallery item.
	 *
	 * @since 1.0.0
	 */
	public function output_video_icon( $data ) {

		if ( $data->is_video && isset( $data->custom_video_icon_id ) ) {
			echo '<div class="modula-video-icon" ><img src ="' . esc_url( wp_get_attachment_image_src( $data->custom_video_icon_id, 'full' )[0] ) . '"></div>';
		} elseif ( $data->is_video ) {
			$svg_data = isset( $data->video_svg_icon ) ? self::get_video_icon_svg( $data->video_svg_icon ) : self::get_video_icon_svg();
			echo '<div class="modula-video-icon"><svg viewBox="0 0 24 24" aria-hidden="true" data-prefix="far" data-icon="play-circle" class="svg-inline--fa fa-play-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="#fff" d="' . esc_attr( $svg_data ) . '"></path></svg></div>';
		}
	}

	/**
	 * Output video icon, if enabled, for each slider nav item.
	 *
	 * @since 1.0.0
	 */
	public function output_video_icon_to_slider_thumb( $image, $images, $settings ) {
		if ( isset( $image['video_template'] ) && 1 === (int) $image['video_template'] ) {
			$img = isset( $image['video_thumbnail'] ) && '' !== $image['video_thumbnail'] ? $image['video_thumbnail'] : \MODULA_PRO_URL . 'includes/extensions/video/assets/img/placeholder.png';
			echo "<img class='modula-slider-nav-image' src='" . esc_url( $img ) . "'>";
		}

		if ( isset( $settings['show-video-icon'] ) && $settings['show-video-icon'] ) {
			if ( isset( $image['video_url'] ) && '' !== $image['video_url'] ) {
				if ( isset( $settings['custom-video-icon'] ) && absint( $settings['custom-video-icon'] ) > 0 ) {
					$attachment_icon = wp_get_attachment_image_src( absint( $settings['custom-video-icon'] ), 'full' );
					echo '<div class="modula-video-icon" >' . ( isset( $attachment_icon[0] ) ? '<img src=" ' . esc_url( $attachment_icon[0] ) . ' " />' : \Modula_Helper::get_icon( 'video' ) ) . '</div>';
				} else {
					$svg_data = isset( $settings['video-icon-icon'] ) ? self::get_video_icon_svg( $settings['video-icon-icon'] ) : self::get_video_icon_svg();
					echo '<div class="modula-video-icon"><svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" data-prefix="far" data-icon="play-circle" class="svg-inline--fa fa-play-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="#fff" d="' . esc_attr( $svg_data ) . '"></path></svg></div>';
				}
			}
		}
	}



	/**
	 * Change video icon color if necessary
	 *
	 * @since 1.0.0
	 *
	 * @return string $css.
	 */
	public function generate_video_css( $css, $gallery_id, $settings ) {

		if ( isset( $settings['show-video-icon'] ) && $settings['show-video-icon'] ) {
			$css .= "#{$gallery_id} .modula-video-icon {  position: absolute; width: 30px;top: 50%;left: 50%;transform: translate(-50%,-50%); }";

			// Backwards compatibility check
			if ( isset( $settings['video-icon-size'] ) && ! isset( $settings['play-icon-size'] ) ) {
				$size                       = str_replace( array( 'px', '%' ), '', $settings['video-icon-size'] );
				$settings['play-icon-size'] = array( $size, $size, $size );
			}

			if ( isset( $settings['video-icon-color'] ) && '#ffffff' !== $settings['video-icon-color'] ) {
				$css .= "#{$gallery_id} .modula-video-icon path { fill : " . \Modula_Helper::sanitize_rgba_colour( $settings['video-icon-color'] ) . ' }';
			}
			// Play icon size css
			if ( isset( $settings['play-icon-size'][0] ) ) {
				$css .= "#{$gallery_id} .modula-video-icon { width : " . absint( $settings['play-icon-size'][0] ) . 'px}';
			}
			if ( isset( $settings['play-icon-size'][1] ) ) {
				$css .= "@media screen and (max-width: 992px){ #{$gallery_id} .modula-video-icon { width : " . absint( $settings['play-icon-size'][1] ) . 'px}}';
			}
			if ( isset( $settings['play-icon-size'][2] ) ) {
				$css .= "@media screen and (max-width: 768px) { #{$gallery_id} .modula-video-icon { width : " . absint( $settings['play-icon-size'][2] ) . 'px}}';
			}

			if ( isset( $settings['custom-video-icon'] ) && 0 !== absint( $settings['custom-video-icon'] ) ) {
				$css .= "#{$gallery_id} .modula-video-icon > img{ max-width : 100%!important;width:100%; }";
			}

			if ( isset( $settings['slider_syncing'] ) && 1 === (int) $settings['slider_syncing'] ) {
				$css .= "html body #{$gallery_id}.modula-slider .modula-slider-nav .modula-slider-nav-item .modula-video-icon img{ border:none; }";
			}
		}

		if ( isset( $settings['borderSize'] ) && 0 < absint( $settings['borderSize'] ) ) {
			$css .= "html body #{$gallery_id} .modula-video-items .modula-video-item.current-item .modula-item-content{ 
				border:" . absint( $settings['borderSize'] ) . 'px solid ' . \Modula_Helper::sanitize_rgba_colour( $settings['borderColor'] ) . ';
				border-radius: ' . absint( $settings['borderRadius'] ) . 'px;
				overflow: hidden;
			}';
		}
		return $css;
	}

	/**
	 * Setting options for the video player in FancyBox.
	 *
	 * @param $fancybox_options, $settings
	 *
	 * @return array
	 */
	public function video_fancybox_options( $fancybox_options, $settings ) {
		$video_attrs = array(
			'controls',
			'playsinline',
		);

		if ( ! isset( $settings['autoplay-videos'] ) || 1 !== (int) $settings['autoplay-videos'] ) {
			//Set autoplay false, default is true.
			$fancybox_options['Html']['videoAutoplay'] = 0;
		}

		if ( isset( $settings['autoplay-videos'] ) && 1 === (int) $settings['autoplay-videos'] ) {
			$fancybox_options['Carousel']['preload'] = 0;
		}

		$video_attrs     = implode( ' ', $video_attrs );
		$browser_support = sprintf( 'Sorry, your browser doesn\'t support embedded videos, %s download %s and watch with your favorite video player!', '<a href="{{src}}">', '</a>' );
		$video_tpl       = '<video class="fancybox__html5video modula_html5_video" ' . esc_attr( $video_attrs ) . ' controlsList="nodownload" poster="{{poster}}" src="{{src}}" type="{{format}}" >  ' . $browser_support . ' </video>';

		$fancybox_options['Html']['videoTpl'] = $video_tpl;

		// This is required to show the toolbar if there aren't
		// any images in lightbox ( eg. 2 videos, 0 images ).
		// default is 'auto';
		if ( isset( $fancybox_options['Toolbar']['display'] ) ) {
			$fancybox_options['Toolbar']['enabled'] = true;
		}
		$fancybox_options['Html']['vimeo']['autopause'] = 0;
		return $fancybox_options;
	}


	/**
	 * Formats the video url for YouTube and Vimeo into the format required for fancybox
	 * With the fancybox 5 update it also serves as backwards compat for Vimeo videos.
	 *
	 * @param $final_url
	 *
	 * @return string
	 * @since 1.0.0
	 * @modified 1.1.0
	 */
	public static function video_link_formatter( $final_url ) {

		$final_url = sanitize_url( $final_url );

		// Check if youtube.
		if ( false !== strpos( $final_url, 'youtu' ) ) {
			// check if already embed format.
			if ( false !== strpos( $final_url, 'embed' ) ) {
				return $final_url;
			} else {
				if ( strpos( $final_url, 'shorts' ) ) {
					return str_replace( 'shorts', 'embed', $final_url );
				}
				// Extrage query params
				$parsed_url = wp_parse_url( $final_url, PHP_URL_QUERY );
				if ( $parsed_url ) {
					parse_str( $parsed_url, $params );
				}
				// Obține video ID
				$video_id = $params['v'] ?? null;

				// fallback pentru youtu.be/u1Teoi-Y_sk
				if ( ! $video_id && preg_match( '#youtu\.be/([a-zA-Z0-9_-]{11})#', $final_url, $m ) ) {
					$video_id = $m[1];
				}

				if ( ! $video_id ) {
					return $final_url; // nu e link valid YouTube
				}

				// Verifică start time
				$start = '';
				if ( ! empty( $params['start'] ) ) {
					$start = 'start=' . intval( $params['start'] );
				} elseif ( ! empty( $params['t'] ) ) {
					$start = 'start=' . intval( $params['t'] );
				}

				// Construim URL final
				$final_url = 'https://www.youtube.com/embed/' . $video_id;
				if ( $start ) {
					$final_url .= '?' . $start;
				}
			}
			// check if vimeo.
		} elseif ( false !== strpos( $final_url, 'vimeo' ) ) {
			// check if already player format.
			if ( ! strpos( $final_url, 'player' ) ) {
				return $final_url;
			} else {
				$pattern = '/player.vimeo.com\/video\/(\d+)/';

				// Check if the embed URL matches the pattern
				if ( preg_match( $pattern, $final_url, $matches ) ) {
					// Construct the video link using the extracted video ID
					$video_id   = $matches[1];
					$video_link = "https://vimeo.com/{$video_id}";

					return $video_link;
				}
			}
		}
		return $final_url;
	}

	/**
	 * Inserts video/iframe to be displayed in Modula Slider instead of image.
	 *
	 * @param $data
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function modula_video_after_image_slider( $data ) {

		if ( true === $data->is_video && ( ! isset( $data->preview_video ) || ! $data->preview_video ) ) {
			?>
			<div class="video-sizer">
				<?php if ( strpos( $data->img_attributes['data-full'], 'youtu' ) ) { ?>
					<iframe src="<?php echo esc_url( $data->img_attributes['data-full'] ); ?>" frameborder="0" allow="encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				<?php } elseif ( strpos( $data->img_attributes['data-full'], 'vimeo' ) ) { ?>
					<iframe src="<?php echo esc_url( $this->vimeo_slider_link_formatter( $data->img_attributes['data-full'] ) ); ?>" frameborder="0" allow="encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				<?php } else { ?> 
					<video src="<?php echo esc_attr( $data->img_attributes['data-full'] ); ?>" controls allowfullscreen></video>
				<?php } ?>
			</div>
			<?php
		}
	}

	/**
	 * Adds the video src to Modula Albums display.
	 *
	 * @param $data
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function add_video_to_albums( $image_config, $image ) {

		if ( isset( $image['video_url'] ) && '' !== $image['video_url'] ) {
			$image_config['src'] = self::video_link_formatter( $image['video_url'] );
		}

		return $image_config;
	}

	/**
	 * A video row in a Beta album's lightbox (Album visitor frontend), as the
	 * gallery lightbox reads it: the video to play, over the row's own
	 * thumbnail (else the image's, else the no-image poster, as the classic
	 * album), with its own autoplay and loop, else its gallery's.
	 *
	 * @param array<string, mixed> $item     Lightbox row.
	 * @param array<string, mixed> $image    Gallery row.
	 * @param array<string, mixed> $settings The member gallery's settings.
	 * @return array<string, mixed> The row; an image row as it is.
	 */
	public function album_visitor_lightbox_video( $item, $image, $settings ) {
		$video_url = trim( (string) ( $image['video_url'] ?? '' ) );
		if ( '' === $video_url ) {
			return $item;
		}

		$poster = $this->album_video_poster( $item, $image );
		return array_merge(
			$item,
			array(
				// A row without an image has no file of its own to fall back on.
				'url'               => '' !== $item['url'] ? $item['url'] : $poster,
				'thumbnail'         => $poster,
				'video_url'         => $video_url,
				'autoplay_lightbox' => self::lightbox_video_flag( $image['autoplay_lightbox'] ?? null, $settings['autoplay-videos'] ?? 0 ),
				'loop_video'        => self::lightbox_video_flag( $image['loop_video'] ?? null, $settings['loop-videos'] ?? 0 ),
			)
		);
	}

	/**
	 * @param array<string, mixed> $item  Lightbox row.
	 * @param array<string, mixed> $image Gallery row.
	 * @return string The poster a video row shows in an album's lightbox.
	 */
	private function album_video_poster( array $item, array $image ) {
		$candidates = array( trim( (string) ( $image['video_thumbnail'] ?? '' ) ), $item['thumbnail'], $item['url'] );
		foreach ( $candidates as $poster ) {
			if ( '' !== $poster ) {
				return $poster;
			}
		}

		return \MODULA_PRO_URL . self::NO_IMAGE_POSTER;
	}

	/**
	 * A video's lightbox autoplay or loop, as `add_link_data()` resolves it:
	 * the row's own value, unless it inherits its gallery's.
	 *
	 * @param mixed $item_value    The row's value; 'inherit', '' or none takes the gallery's.
	 * @param mixed $gallery_value The gallery's value.
	 * @return string '1' or '0'.
	 */
	private static function lightbox_video_flag( $item_value, $gallery_value ) {
		$value = ( null === $item_value || 'inherit' === $item_value || '' === $item_value ) ? $gallery_value : $item_value;
		return in_array( $value, array( 1, '1', true, 'on' ), true ) ? '1' : '0';
	}

	/**
	 * Add Modula Video data to migrator
	 *
	 * @param $modula_settings
	 * @param $guest_settings
	 * @param $source
	 *
	 * @return mixed
	 *
	 * @since 1.0.4
	 */
	public function modula_video_migrator_data( $modula_settings, $guest_settings, $source ) {
		switch ( $source ) {
			case 'envira':
				if ( isset( $guest_settings['config']['videos_play_icon'] ) && 1 === (int) $guest_settings['config']['videos_play_icon'] ) {
					$modula_settings['show-video-icon'] = 1;
				}

				if ( isset( $guest_settings['config']['videos_autoplay'] ) && 1 === (int) $guest_settings['config']['videos_autoplay'] ) {
					$modula_settings['autoplay-videos'] = 1;
				}

				break;
		}

		return $modula_settings;
	}

	/**
	 * Add default for item's video url.
	 *
	 * @since 1.0.0
	 *
	 * @return array $defaults.
	 */
	public function default_settings( $defaults ) {

		$defaults['video_url']              = '';
		$defaults['video_title']            = '';
		$defaults['video_description']      = '';
		$defaults['video_alt']              = '';
		$defaults['video_thumbnail']        = '';
		$defaults['video_template']         = false;
		$defaults['video_width']            = 1280;
		$defaults['video_height']           = 720;
		$defaults['autoplay-videos']        = 0;
		$defaults['loop-videos']            = 0;
		$defaults['show-video-icon']        = 1;
		$defaults['use-custom-icon']        = 0;
		$defaults['custom-video-icon']      = 0;
		$defaults['video-icon-color']       = '#ffffff';
		$defaults['preview-video']          = 0;
		$defaults['preview-video-duration'] = 3000;
		$defaults['autoplay_thumbnail']     = 'inherit';
		$defaults['autoplay_lightbox']      = 'inherit';
		$defaults['loop_video']             = 'inherit';

		return $defaults;
	}

	/**
	 * Add image settings thumbnail url to image data.
	 *
	 * @since 1.0.6
	 */
	public function add_link_data( $item_data, $image, $settings ) {

		if ( isset( $image['video_thumbnail'] ) && '' !== $image['video_thumbnail'] ) {
			// Set the user selected video thumbnail.
			$item_data['link_attributes']['data-thumb'] = esc_url( $image['video_thumbnail'] );
		} else {
			// Set the gallery image as video thumbnail.
			$item_data['link_attributes']['data-thumb'] = isset( $item_data['img_attributes']['data-src'] ) ? $item_data['img_attributes']['data-src'] : $item_data['img_attributes']['data-full'];
		}

		if ( isset( $image['video_template'] ) && 1 === (int) $image['video_template'] ) {
			$caption = '';

			if ( isset( $image['video_description'] ) && '' !== $image['video_description'] ) {
				$caption = $image['video_description'];
			}

			$title = '';

			if ( isset( $image['video_title'] ) && '' !== $image['video_title'] ) {
				$title = $image['video_title'];
			}

			$show_title   = ( isset( $settings['showTitleLightbox'] ) && 1 === absint( $settings['showTitleLightbox'] ) ) && ( ! isset( $image['hide_title'] ) || 1 !== absint( $image['hide_title'] ) );
			$show_caption = ( isset( $settings['showCaptionLightbox'] ) && 1 === absint( $settings['showCaptionLightbox'] ) );

			if ( $show_title && $show_caption ) {
				$item_data['link_attributes']['data-caption'] = esc_attr( '<span class="modula-caption-title">' . $title . '</span><br><span class="modula-caption-description">' . $caption . '</span>' );
			} elseif ( $show_title && ! $show_caption ) {
				$item_data['link_attributes']['data-caption'] = esc_attr( '<span class="modula-caption-title">' . $title . '</span>' );
			} elseif ( ! $show_title && $show_caption ) {
				$item_data['link_attributes']['data-caption'] = esc_attr( '<span class="modula-caption-description">' . $caption . '</span>' );
			} else {
				$item_data['link_attributes']['data-caption'] = '';
			}

			$item_data['title']       = isset( $image['video_title'] ) ? $image['video_title'] : '';
			$item_data['caption']     = isset( $image['video_description'] ) ? $image['video_description'] : '';
			$item_data['description'] = isset( $image['video_description'] ) ? $image['video_description'] : '';
		}
		if ( isset( $image['video_alt'] ) && '' !== $image['video_alt'] ) {
			$item_data['img_attributes']['alt'] = $image['video_alt'];
		}

		return $item_data;
	}

	/**
	 * Get youtube video id from url
	 *
	 * @param $url
	 *
	 * @return string
	 * @since 1.1.0
	 */
	public static function get_youtube_video_id( $url ) {
		// Regex pattern to match YouTube video IDs, including Shorts
		$youtube_matcher = '/(?:youtube\.com|youtu\.be|youtube\-nocookie\.com)\/(?:.*?(?:v=|v\/|u\/|embed\/|shorts\/))?([\w-]{11})/i';

		// Extract the video ID using the regex pattern
		preg_match( $youtube_matcher, $url, $matches );

		if ( isset( $matches[1] ) ) {
			return $matches[1];
		}

		return ''; // Return an empty string if no match is found
	}

	/**
	 * Get vimeo video id from url
	 *
	 * @param $url
	 *
	 * @return string
	 * @since 1.1.0
	 */
	public static function get_vimeo_video_id( $url ) {

		// check if already player format.
		if ( ! strpos( $url, 'player' ) ) {
			$pattern = '/vimeo\.com\/(\d+)/';
			preg_match( $pattern, $url, $matches );

			return isset( $matches[1] ) ? $matches[1] : false;
		} else {
			$pattern = '/player.vimeo.com\/video\/(\d+)/';
			preg_match( $pattern, $url, $matches );
			return isset( $matches[1] ) ? $matches[1] : false;
		}

		return false;
	}



	/**
	 * Retrieves the available play icons used in the video module.
	 *
	 * @return array
	 * @since 1.1.0
	 */
	public static function get_available_icons() {
		return apply_filters(
			'modula_video_available_play_icons',
			array(
				'default'              => array(
					'name'     => esc_html__( 'Default', 'modula-pro' ),
					'svg_data' => 'M 17.421875 11.15625 L 9.171875 6.140625 C 8.433594 5.726562 7.5 6.257812 7.5 7.125 L 7.5 16.875 C 7.5 17.738281 8.429688 18.273438 9.171875 17.859375 L 17.421875 13.125 C 18.191406 12.699219 18.191406 11.585938 17.421875 11.15625 Z M 23.625 12 C 23.625 5.578125 18.421875 0.375 12 0.375 C 5.578125 0.375 0.375 5.578125 0.375 12 C 0.375 18.421875 5.578125 23.625 12 23.625 C 18.421875 23.625 23.625 18.421875 23.625 12 Z M 2.625 12 C 2.625 6.820312 6.820312 2.625 12 2.625 C 17.179688 2.625 21.375 6.820312 21.375 12 C 21.375 17.179688 17.179688 21.375 12 21.375 C 6.820312 21.375 2.625 17.179688 2.625 12 Z M 2.625 12 ',
				),
				'play'                 => array(
					'name'     => esc_html__( 'Play', 'modula-pro' ),
					'svg_data' => 'M23 12l-22 12v-24l22 12zm-21 10.315l18.912-10.315-18.912-10.315v20.63z',
				),
				'google_play_5'        => array(
					'name'     => esc_html__( 'Google Play 5', 'modula-pro' ),
					'svg_data' => 'M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm0 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm-3.715 15.832l5.266-5.25 1.856 1.85-6.259 3.47c-.238.132-.53.13-.766-.005l-.097-.065zm4.735-5.78l-5.02 5.005v-10.01l5.02 5.005zm3.137-2.068l2.452 1.359c.242.134.391.385.391.657s-.149.523-.391.657l-2.519 1.397-2.008-2.002 2.075-2.068zm-7.927-3.767l.152-.114c.236-.135.528-.137.766-.005l6.326 3.507-1.923 1.917-5.321-5.305z',
				),
				'google_play_4'        => array(
					'name'     => esc_html__( 'Google Play 4', 'modula-pro' ),
					'svg_data' => 'M12 0c-6.626 0-12 5.372-12 12 0 6.627 5.374 12 12 12 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12zm-4.667 18.804l6.143-6.125 2.166 2.158-7.303 4.049c-.278.154-.618.152-.894-.006l-.112-.076zm5.524-6.743l-5.857 5.839v-11.679l5.857 5.84zm3.659-2.413l2.862 1.586c.281.156.455.449.455.766s-.174.61-.455.766l-2.94 1.63-2.342-2.335 2.42-2.413zm-9.248-4.395l.177-.133c.276-.158.616-.16.894-.006l7.381 4.092-2.244 2.237-6.208-6.19z',
				),
				'google_play_3'        => array(
					'name'     => esc_html__( 'Google Play 3', 'modula-pro' ),
					'svg_data' => 'M19 0c2.762 0 5 2.239 5 5v14c0 2.761-2.238 5-5 5h-14c-2.761 0-5-2.239-5-5v-14c0-2.761 2.239-5 5-5h14zm-13.698 19.776l7.022-7.001 2.474 2.468-8.346 4.627c-.317.176-.706.173-1.021-.007l-.129-.087zm6.313-7.707l-6.693 6.674v-13.348l6.693 6.674zm4.183-2.758l3.27 1.813c.322.179.521.513.521.876s-.199.697-.521.876l-3.36 1.862-2.676-2.669 2.766-2.758zm-10.57-5.022l.203-.152c.315-.18.704-.183 1.021-.007l8.436 4.677-2.564 2.556-7.096-7.074z',
				),
				'google_play_2'        => array(
					'name'     => esc_html__( 'Google Play 2', 'modula-pro' ),
					'svg_data' => 'M24 0v24h-24v-24h24zm-18.62 19.776l7.022-7.001 2.474 2.468-8.346 4.627c-.317.176-.706.173-1.021-.007l-.129-.087zm6.314-7.707l-6.694 6.674v-13.348l6.694 6.674zm4.182-2.758l3.27 1.813c.322.179.521.513.521.876s-.199.697-.521.876l-3.36 1.862-2.676-2.669 2.766-2.758zm-10.57-5.022l.203-.152c.315-.18.704-.183 1.021-.007l8.436 4.677-2.564 2.556-7.096-7.074z',
				),
				'google_play_1'        => array(
					'name'     => esc_html__( 'Google Play 1', 'modula-pro' ),
					'svg_data' => 'M1.571 23.664l10.531-10.501 3.712 3.701-12.519 6.941c-.476.264-1.059.26-1.532-.011l-.192-.13zm9.469-11.56l-10.04 10.011v-20.022l10.04 10.011zm6.274-4.137l4.905 2.719c.482.268.781.77.781 1.314s-.299 1.046-.781 1.314l-5.039 2.793-4.015-4.003 4.149-4.137zm-15.854-7.534c.09-.087.191-.163.303-.227.473-.271 1.056-.275 1.532-.011l12.653 7.015-3.846 3.835-10.642-10.612z',
				),
				'simple_solid'         => array(
					'name'     => esc_html__( 'Simple Solid', 'modula-pro' ),
					'svg_data' => 'M3 22v-20l18 10-18 10z',
				),
				'solid_circle_break'   => array(
					'name'     => esc_html__( 'Solid Circle Break', 'modula-pro' ),
					'svg_data' => 'M9 16.985v-10.021l9 5.157-9 4.864zm4-14.98c5.046.504 9 4.782 9 9.97 0 1.467-.324 2.856-.892 4.113l1.738 1.006c.732-1.555 1.154-3.285 1.154-5.119 0-6.303-4.842-11.464-11-11.975v2.005zm-10.109 14.082c-.568-1.257-.891-2.646-.891-4.112 0-5.188 3.954-9.466 9-9.97v-2.005c-6.158.511-11 5.672-11 11.975 0 1.833.421 3.563 1.153 5.118l1.738-1.006zm17.213 1.734c-1.817 2.523-4.769 4.175-8.104 4.175s-6.288-1.651-8.105-4.176l-1.746 1.011c2.167 3.122 5.768 5.169 9.851 5.169 4.082 0 7.683-2.047 9.851-5.168l-1.747-1.011z',
				),
				'solid_circle'         => array(
					'name'     => esc_html__( 'Solid Circle', 'modula-pro' ),
					'svg_data' => 'M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-3 17v-10l9 5.146-9 4.854z',
				),
				'solid_circle_fill'    => array(
					'name'     => esc_html__( 'Solid Circle Fill', 'modula-pro' ),
					'svg_data' => 'M13 2.004c5.046.504 9 4.783 9 9.97 0 1.467-.324 2.856-.892 4.113l1.738 1.005c.732-1.553 1.154-3.284 1.154-5.117 0-6.304-4.842-11.464-11-11.975v2.004zm-10.109 14.083c-.568-1.257-.891-2.646-.891-4.112 0-5.188 3.954-9.466 9-9.97v-2.005c-6.158.511-11 5.671-11 11.975 0 1.833.421 3.563 1.153 5.118l1.738-1.006zm17.213 1.734c-1.817 2.523-4.769 4.174-8.104 4.174s-6.288-1.651-8.105-4.175l-1.746 1.01c2.167 3.123 5.768 5.17 9.851 5.17 4.082 0 7.683-2.047 9.851-5.168l-1.747-1.011zm-8.104-13.863c-4.419 0-8 3.589-8 8.017s3.581 8.017 8 8.017 8-3.589 8-8.017-3.581-8.017-8-8.017zm-2 11.023v-6.013l6 3.152-6 2.861z',
				),
				'simple_solid_reverse' => array(
					'name'     => esc_html__( 'Simple Solid Reverse', 'modula-pro' ),
					'svg_data' => 'M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-3 17v-10l9 5.146-9 4.854z',
				),
			),
		);
	}

	/**
	 * Retrieves the selected play icon svg data. Used to display the selected icon in the admin.
	 *
	 * @param $icon
	 *
	 * @return mixed|string
	 * @since 1.1.0
	 */
	public static function get_video_icon_svg( $icon = 'default' ) {
		$icons = self::get_available_icons();

		if ( isset( $icons[ $icon ] ) ) {
			return $icons[ $icon ]['svg_data'];
		} else {
			return '';
		}
	}

	/**
	 * Transforms vimeo standard url to vimeo embed url.
	 *
	 * @param $final_url
	 *
	 * @return mixed|string
	 * @since 1.1.0
	 */
	private function vimeo_slider_link_formatter( $final_url ) {
		// check if already player format.
		if ( strpos( $final_url, 'player' ) ) {
			return $final_url;
		} else {
			$url_parts  = array(
				'hd'            => 1,
				'show_portrait' => 0,
				'fullscreen'    => 1,
			);
			$start_time = '';
			$vimeo_id   = '';

			// remove traling slash if exist.
			$vimeo_url = rtrim( $final_url, '/\\' );

			// remove the first part of vimeo link.
			$vimeo_url = preg_replace( '/(https?:\/\/)?(www\.)?(player\.)?vimeo\.com\//', '', $vimeo_url );

			// check if we have start time.
			if ( false !== strpos( $vimeo_url, '#t=' ) ) {
				$parts      = explode( '#t=', $vimeo_url );
				$start_time = '#t=' . $parts[1];
				$vimeo_url  = $parts[0];
			}

			// remove traling slash if exist.
			$vimeo_url = rtrim( $vimeo_url, '/\\' );

			// check if we have / in url, probably we have a private url.
			if ( false !== strpos( $vimeo_url, '/' ) ) {
				$parts = explode( '/', $vimeo_url );
				if ( isset( $parts[1] ) && ! empty( $parts[1] ) ) {
					$url_parts['h'] = $parts[1];
				}
				$vimeo_url = $parts[0];
			}

			// now $vimeo_url should be the video id.
			$vimeo_id = $vimeo_url;

			if ( empty( $vimeo_id ) ) {
				$request     = wp_remote_get( 'https://vimeo.com/api/oembed.json?url=' . $final_url );
				$response    = wp_remote_retrieve_body( $request );
				$video_array = json_decode( $response, true );
				$vimeo_id    = $video_array['video_id'];
				$start_time  = '';
			}

			$final_url = '//player.vimeo.com/video/' . $vimeo_id;
			$final_url = add_query_arg( $url_parts, $final_url );
			if ( ! empty( $start_time ) ) {
				$final_url .= '&' . $start_time;
			}
		}
		return $final_url;
	}

	/**
	 * Snapshot metadata for a Media Library video attachment (self-hosted).
	 *
	 * @param int $attach_id Attachment post ID.
	 * @return array<string, mixed>|false
	 */
	public static function get_video_snap_from_attachment( $attach_id ) {
		$attach_id = absint( $attach_id );
		if ( ! $attach_id || 'attachment' !== get_post_type( $attach_id ) ) {
			return false;
		}

		$mime = get_post_mime_type( $attach_id );
		if ( ! is_string( $mime ) || 0 !== strpos( $mime, 'video/' ) ) {
			return false;
		}

		$default = array(
			'title' => '',
			'thumb' => \MODULA_PRO_URL . self::NO_IMAGE_POSTER,
		);

		$thumb = get_the_post_thumbnail_url( $attach_id, 'full' );

		return array(
			'title'  => get_the_title( $attach_id ),
			'thumb'  => $thumb ? $thumb : $default['thumb'],
			'width'  => 1920,
			'height' => 1080,
		);
	}

	public static function get_video_snap( $url = false, $bounded = false ) {
		$default = array(
			'title' => '',
			'thumb' => \MODULA_PRO_URL . self::NO_IMAGE_POSTER,
		);

		if ( ! $url ) {
			return false;
		}

		if ( false !== strpos( $url, 'youtu' ) ) {
			$google_auth = Google_Auth::get_instance();
			$token       = $google_auth->get_access_token();
			$video_id    = self::get_youtube_video_id( $url );
			if ( empty( $video_id ) ) {
				return false;
			}
			$data = false;
			if ( $token ) {
				if ( $google_auth->is_token_expired() ) {
					$google_auth->refresh_token( false );
				}
				$data = self::get_yotube_advanced_data( $video_id, $google_auth->get_access_token(), $bounded );
			}

			if ( ! $data ) {
				// backup way to get at least video poster.
				$thumbnail_url = "https://img.youtube.com/vi/$video_id/hqdefault.jpg";
				$data          = array(
					'title' => '',
					'thumb' => $thumbnail_url,
				);

				// Add aditional data to set the image's width x height.
				if ( strpos( $url, 'shorts' ) ) {
					$data['height'] = 1920;
					$data['width']  = 1080;
				} else {
					$data['width']  = 1920;
					$data['height'] = 1080;
				}
			}

			return $data;
		} elseif ( false !== strpos( $url, 'vimeo' ) ) {
			// Vimeo video ID
			$video_id = self::get_vimeo_video_id( $url );

			if ( ! $video_id ) {
				return false;
			}

			$vimeo_auth = Vimeo_Auth::get_instance();
			$token      = $vimeo_auth->get_access_token();
			$data       = false;
			if ( $token ) {
				$data = self::get_vimeo_advanced_data( $video_id, $vimeo_auth->get_access_token(), $bounded );
			}

			if ( ! $data ) {
				// Vimeo oEmbed endpoint
				$oembed_url = 'https://vimeo.com/api/oembed.json?url=https://vimeo.com/' . $video_id;

				// Initialize cURL
				$ch = curl_init();
				curl_setopt( $ch, CURLOPT_URL, $oembed_url );
				curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
				if ( $bounded ) { curl_setopt( $ch, CURLOPT_TIMEOUT, 15 ); curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 5 ); }

				// Fetch the data
				$data = curl_exec( $ch );
				curl_close( $ch );

				// Decode the JSON response
				$response = json_decode( $data, true );
				if ( is_null( $response ) ) {
					return $default;
				}
				// Get the thumbnail URL
				$data           = array(
					'title' => $response['title'],
					'thumb' => $response['thumbnail_url'],
				);
				$data['width']  = 1920;
				$data['height'] = 1080;
			}

			return $data;
		} else {
			$attach_id = attachment_url_to_postid( $url );

			if ( 0 === (int) $attach_id ) {
				return false;
			}

			$thumb = get_the_post_thumbnail_url( $attach_id, 'full' );

			if ( $thumb ) {
				return array(
					'title'  => get_the_title( $attach_id ),
					'thumb'  => $thumb,
					'width'  => 1920,
					'height' => 1080,
				);
			} else {
				return $default;
			}
		}

		return false;
	}

	private static function get_yotube_advanced_data( $video_id, $token, $bounded = false ) {
		try {
			// Create the Google Client
			$client = new GoogleClient();
			if ( $bounded ) { $client->setHttpClient( new Client( array( 'timeout' => 15, 'connect_timeout' => 5 ) ) ); }

			// Set OAuth token
			$client->setAccessToken( $token );

			// Create the YouTube service
			$youtube = new YouTube( $client );

			// Fetch the video details
			$video_response = $youtube->videos->listVideos(
				'snippet, player',
				array(
					'id'        => $video_id,
					'maxHeight' => 1920,
					'maxWidth'  => 1920,
				)
			);

			// Process the response to get video details
			if ( count( $video_response->getItems() ) > 0 ) {
				$video = $video_response->getItems()[0];

				$snippet = $video->getSnippet();
				$player  = $video->getPlayer();

				// Video title
				$title = $snippet->getTitle();

				// Video description
				$description = $snippet->getDescription();

				// Extract the highest-quality thumbnail
				$thumbnails = $snippet->getThumbnails();

				$thumbnail = '';
				if ( $thumbnails ) {
					if ( $thumbnails->getMaxres() ) {
						$thumbnail = $thumbnails->getMaxres()->getUrl();
					} elseif ( $thumbnails->getStandard() ) {
						$thumbnail = $thumbnails->getStandard()->getUrl();
					} elseif ( $thumbnails->getHigh() ) {
						$thumbnail = $thumbnails->getHigh()->getUrl();
					} elseif ( $thumbnails->getMedium() ) {
						$thumbnail = $thumbnails->getMedium()->getUrl();
					} elseif ( $thumbnails->getDefault() ) {
						$thumbnail = $thumbnails->getDefault()->getUrl();
					}
				}

				return array(
					'title'       => $title,
					'thumb'       => $thumbnail,
					'description' => $description,
					//phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
					'width'       => isset( $player->embedWidth ) ? $player->embedWidth : 1920,
					//phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
					'height'      => isset( $player->embedHeight ) ? $player->embedHeight : 1080,
					'video_url'   => 'https://www.youtube.com/watch?v=' . $video_id,
				);
			}
		} catch ( \Exception $e ) {
			// Clear stored token on 403 insufficient scopes so user can reconnect with correct scope (youtube.readonly).
			if ( 403 === (int) $e->getCode() && false !== strpos( strtolower( $e->getMessage() ), 'insufficient' ) ) {
				delete_option( Google_Auth::$access_token );
				delete_option( Google_Auth::$refresh_token );
				delete_option( Google_Auth::$expiry_date );
			}
			// API errors (e.g. 403 insufficient scopes, rate limits) fall back to public thumbnail.
			return false;
		}

		return false;
	}


	private static function get_vimeo_advanced_data( $video_id, $token, $bounded = false ) {
		// Create a new HTTP client
		$client = new Client(
			array(
				'timeout' => $bounded ? 15 : 0,
				'connect_timeout' => $bounded ? 5 : 0,
				'headers' => array(
					'Authorization' => "Bearer $token",
				),
			)
		);

		try {
			$response = $client->get( 'https://api.vimeo.com/videos/' . $video_id );
		} catch ( ClientException $e ) {
			return false;
		}

		// Extract video details
		$video_details = json_decode( (string) $response->getBody(), true );

		return array(
			'title'       => $video_details['name'],
			'thumb'       => $video_details['pictures']['base_link'],
			'description' => $video_details['description'],
			'width'       => $video_details['width'],
			'height'      => $video_details['height'],
			'video_url'   => 'https://vimeo.com/' . $video_id,
		);
	}

	public function prevent_resize_video_template( $boolean ) {
		if ( isset( $this->item_data['video_template'] ) && 1 === (int) $this->item_data['video_template'] ) {
			return false;
		}

		return $boolean;
	}

	public function check_item_not_image( $is_image, $item ) {

		if ( $is_image && isset( $item['video_template'] ) && 1 === (int) $item['video_template'] ) {
			return false;
		}

		return $is_image;
	}


	public function resize_video_template( $item_data, $image, $settings ) {
		$gallery_type = isset( $settings['type'] ) ? $settings['type'] : 'creative-gallery';
		if ( isset( $image['video_template'] ) && 1 === (int) $image['video_template'] ) {
			if ( 0 < absint( $image['video_width'] ) && 0 < absint( $image['video_height'] ) ) {
				$item_data['img_attributes']['data-ratio'] = absint( $image['video_width'] ) / absint( $image['video_height'] );
			}

			$item_data['video_attributes']['width']  = $image['video_width'];
			$item_data['video_attributes']['height'] = $image['video_height'];
			$item_data['img_attributes']['width']    = $image['video_width'];
			$item_data['img_attributes']['height']   = $image['video_height'];
			if ( isset( $image['video_thumbnail'] ) && ! empty( $image['video_thumbnail'] ) ) {
				$item_data['img_attributes']['src']      = $image['video_thumbnail'];
				$item_data['img_attributes']['srcset']   = $image['video_thumbnail'];
				$item_data['img_attributes']['data-src'] = $image['video_thumbnail'];
			} else {
				$placeholder_url                         = \MODULA_PRO_URL . 'includes/extensions/video/assets/img/placeholder.png';
				$item_data['img_attributes']['src']      = $placeholder_url;
				$item_data['img_attributes']['srcset']   = $placeholder_url;
				$item_data['img_attributes']['data-src'] = $placeholder_url;
			}
		} elseif ( 'video' === $gallery_type ) {
			$image_url = wp_get_original_image_url( $image['id'] );
			if ( ! $image_url ) {
				$image_url = wp_get_attachment_image_url( $image['id'] );
			}
			if ( ! $image_url ) {
				$image_url = '';
			}

			$item_data['img_attributes']['height']   = $image['video_height'];
			$item_data['img_attributes']['width']    = $image['video_width'];
			$item_data['image_url']                  = ( isset( $image['video_thumbnail'] ) ) ? $image['video_thumbnail'] : $image_url;
			$item_data['img_attributes']['src']      = $image_url;
			$item_data['img_attributes']['srcset']   = $image_url;
			$item_data['img_attributes']['data-src'] = $image_url;

			return $item_data;
		}

		return $item_data;
	}

	/** Canonical Vimeo collection identity; share parameters never reach the API. */
	public static function vimeo_collection_path( $url ) {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || 'https' !== ( $parts['scheme'] ?? '' )
			|| ! in_array( strtolower( $parts['host'] ?? '' ), array( 'vimeo.com', 'www.vimeo.com' ), true )
			|| array_intersect( array( 'user', 'pass', 'port', 'fragment' ), array_keys( $parts ) )
		) {
			return false;
		}
		$path = $parts['path'] ?? '';
		if ( preg_match( '~^/showcase/([0-9]+)/?$~D', $path, $match ) ) {
			foreach ( empty( $parts['query'] ) ? array() : explode( '&', $parts['query'] ) as $param ) {
				if ( ! preg_match( '#^(fl|fe)=[A-Za-z0-9._~%\-]*$#D', $param ) ) {
					return false;
				}
			}
			return '/me/albums/' . $match[1];
		}
		return empty( $parts['query'] ) && preg_match( '~^/channels/[A-Za-z0-9_-]+/?$~D', $path ) ? rtrim( $path, '/' ) : false;
	}

	/** Only canonical supported provider endpoints; abilities never accept a generic URL fetch. */
	public static function supported_provider_url( string $url, bool $playlist = false ): bool {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || 'https' !== ( $parts['scheme'] ?? '' ) || array_intersect( array( 'user', 'pass', 'port', 'fragment' ), array_keys( $parts ) ) ) {
			return false;
		}
		$host = strtolower( (string) ( $parts['host'] ?? '' ) );
		$path = (string) ( $parts['path'] ?? '' );
		parse_str( (string) ( $parts['query'] ?? '' ), $query );
		if ( in_array( $host, array( 'youtube.com', 'www.youtube.com', 'youtu.be' ), true ) ) {
			if ( $playlist ) {
				return in_array( $path, array( '/playlist', '/watch' ), true ) && isset( $query['list'] ) && is_string( $query['list'] ) && 1 === preg_match( '/^[A-Za-z0-9_-]{1,120}$/D', $query['list'] ) && ! array_diff( array_keys( $query ), array( 'v', 'list' ) );
			}
			return ! array_diff( array_keys( $query ), array( 'v' ) ) && '' !== self::get_youtube_video_id( $url );
		}
		if ( $playlist ) {
			return false !== self::vimeo_collection_path( $url );
		}
		return in_array( $host, array( 'vimeo.com', 'www.vimeo.com' ), true ) && ! $query && 1 === preg_match( '~^/[0-9]+/?$~D', $path );
	}

	public static function get_video_playlist_snap( $url, $limit = 0, &$complete = null ) {
		$complete = true;
		$data = array();

		if ( in_array( strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ), array( 'youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be' ), true ) ) {
			$google_auth = Google_Auth::get_instance();
			$token       = $google_auth->get_access_token();

			if ( $token ) {
				if ( $google_auth->is_token_expired() ) {
					$google_auth->refresh_token( false );
				}
				parse_str( parse_url( $url, PHP_URL_QUERY ), $query_params );
				$playlist_id = isset( $query_params['list'] ) ? $query_params['list'] : null;

				if ( null === $playlist_id ) {
					return array( 'error' => esc_html__( 'Invalid YouTube playlist id.', 'modula-pro' ) );
				}

				$videos = self::get_video_ids_from_playlist( $playlist_id, $google_auth->get_access_token(), $limit, $complete );

				foreach ( $videos as $video ) {
					$data[] = self::get_yotube_advanced_data( $video, $google_auth->get_access_token(), $limit > 0 );
				}
			} else {
				$data['error'] = sprintf(
					// translators: %1$s is the link to the Google account settings, %2$s is the closing link tag
					esc_html__( 'You need to connect your Google account %1$shere%2$s to use YouTube playlist functionality', 'modula-pro' ),
					'<a target="_BLANK" href="' . admin_url( '/edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media' ) . '">',
					'</a>'
				);
			}
		} elseif ( in_array( strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ), array( 'vimeo.com', 'www.vimeo.com' ), true ) ) {
			$path = self::vimeo_collection_path( $url );
			// Preserve ordinary legacy channel share links; only their path is used by the channel API.
			$channel_path = (string) wp_parse_url( $url, PHP_URL_PATH );
			if ( preg_match( '~^/channels/[A-Za-z0-9_-]+/?$~D', $channel_path ) && in_array( wp_parse_url( $url, PHP_URL_SCHEME ), array( 'http', 'https' ), true ) ) {
				$path = rtrim( $channel_path, '/' );
			}
			if ( false === $path ) {
				$complete = false;
				return array( 'error' => esc_html__( 'Enter a valid Vimeo channel URL or a public Showcase HTTPS share link copied from Vimeo.', 'modula-pro' ) );
			}
			$vimeo_auth = Vimeo_Auth::get_instance();
			$token      = $vimeo_auth->get_access_token();

			if ( $token ) {
				$data = 0 === strpos( $path, '/me/albums/' )
					? self::get_video_from_showcase( $path, $token, $limit, $complete )
					: self::get_video_from_channel( $url, $token, $limit, $complete );
			} else {
				$complete = false;
				$data['error'] = esc_html__( 'Connect your Vimeo account in Modula Social Media settings. To import a public Showcase, connect the account that owns it.', 'modula-pro' );
			}
		} else {
			$complete = false;
			$data['error'] = esc_html__( 'Enter a YouTube playlist, Vimeo channel, or public Vimeo Showcase URL.', 'modula-pro' );
		}

		return $data;
	}

	// Function to fetch video IDs from a YouTube playlist
	private static function get_video_ids_from_playlist( $playlist_id, $token, $limit = 0, &$complete = null ) {
		$video_ids       = array();
		$next_page_token = '';
		// Create the Google Client
		$client = new GoogleClient();
		if ( $limit ) { $client->setHttpClient( new Client( array( 'timeout' => 15, 'connect_timeout' => 5 ) ) ); }

		// Set OAuth token
		$client->setAccessToken( $token );

		// Create the YouTube service
		$youtube = new YouTube( $client );
		do {
			try {
				// Fetch playlist items with a limit and part
				//phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$playlist_response = $youtube->playlistItems->listPlaylistItems(
					'snippet,contentDetails',
					array(
						'playlistId' => $playlist_id,
						'maxResults' => 50, // Adjust as needed
						'pageToken'  => $next_page_token,
					)
				);
			} catch ( \WPChill\Modula_Pro\Vendor\Google\Service\Exception $e ) {
				$complete = false;
				return $video_ids;
			}
			// Extract video IDs from the response
			foreach ( $playlist_response->getItems() as $item ) {
				$video_ids[] = $item->getContentDetails()->getVideoId();
				if ( $limit && count( $video_ids ) > $limit ) { $complete = false; return array_slice( $video_ids, 0, $limit ); }
			}

			// Get the next page token, if any
			$next_page_token = $playlist_response->getNextPageToken();
			if ( $limit && count( $video_ids ) >= $limit && $next_page_token ) { $complete = false; break; }
		} while ( $next_page_token ); // Continue fetching if there's a next page

		return $video_ids;
	}


	/** Fetch only a constructed API path; never forward provider redirects or error bodies. */
	private static function vimeo_showcase_request( $path, $token, $query = array() ) {
		$url = 'https://api.vimeo.com' . $path;
		$response = wp_remote_get( $query ? add_query_arg( $query, $url ) : $url, array(
			'timeout' => 15,
			'redirection' => 0,
			'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Accept' => 'application/vnd.vimeo.*+json;version=3.4' ),
		) );
		$status = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		if ( 401 === $status ) {
			return array( 'error' => esc_html__( 'Your Vimeo connection has expired or is invalid. Reconnect Vimeo in Modula Social Media settings.', 'modula-pro' ) );
		}
		if ( in_array( $status, array( 403, 404 ), true ) ) {
			return array( 'error' => esc_html__( 'This Showcase is unavailable to the connected Vimeo account. Connect the account that owns it and check that the Showcase is public.', 'modula-pro' ) );
		}
		if ( 429 === $status ) {
			return array( 'error' => esc_html__( 'Vimeo is limiting requests. Wait a few minutes before importing again.', 'modula-pro' ) );
		}
		$data = 200 === $status ? json_decode( wp_remote_retrieve_body( $response ), true ) : null;
		if ( ! is_array( $data ) || isset( $data['error'] ) ) {
			return array( 'error' => esc_html__( 'Vimeo could not return the complete Showcase. Please try again later. No videos were imported.', 'modula-pro' ) );
		}
		return $data;
	}

	/** Public owner Showcases only; editor imports are all-or-error, ability results can be bounded. */
	private static function get_video_from_showcase( $path, $token, $limit, &$complete ) {
		$complete = false;
		$collection = self::vimeo_showcase_request( $path, $token );
		if ( isset( $collection['error'] ) ) {
			return $collection;
		}
		if ( 'anybody' !== ( $collection['privacy']['view'] ?? '' ) ) {
			return array( 'error' => esc_html__( 'Only public Vimeo Showcases can be imported. Change the Showcase privacy to Public and try again.', 'modula-pro' ) );
		}
		$snaps = array();
		$seen = array();
		$omitted = false;
		$fail = static function ( $message ) use ( &$snaps, $limit ) {
			return $limit && $snaps ? $snaps : array( 'error' => $message );
		};
		for ( $page = 1; $page <= 200; ++$page ) {
			// 'default' follows the Showcase's display order; 'manual' would override other sort modes.
			$data = self::vimeo_showcase_request( $path . '/videos', $token, array( 'per_page' => 50, 'page' => $page, 'sort' => 'default' ) );
			if ( isset( $data['error'] ) ) {
				return $fail( $data['error'] );
			}
			if ( ! isset( $data['data'], $data['paging'] ) || ! is_array( $data['data'] ) || ! is_array( $data['paging'] ) || ! array_key_exists( 'next', $data['paging'] ) ) {
				return $fail( esc_html__( 'Vimeo returned an incomplete Showcase response. No videos were imported. Please try again.', 'modula-pro' ) );
			}
			$before_page = count( $seen );
			foreach ( $data['data'] as $video ) {
				$uri = is_array( $video ) ? ( $video['uri'] ?? '' ) : '';
				if ( ! is_string( $uri ) || ! preg_match( '~^/videos/([0-9]+)$~D', $uri, $match ) || isset( $seen[ $uri ] ) ) {
					return $fail( esc_html__( 'Vimeo returned inconsistent Showcase pages. No videos were imported. Please try again.', 'modula-pro' ) );
				}
				$seen[ $uri ] = true;
				if ( 'anybody' !== ( $video['privacy']['view'] ?? '' )
					|| 'nobody' === ( $video['privacy']['embed'] ?? '' )
					|| ! is_string( $video['pictures']['base_link'] ?? null )
					|| ! preg_match( '~^https?://~i', $video['pictures']['base_link'] )
					|| ! is_numeric( $video['width'] ?? null )
					|| (int) $video['width'] <= 0
					|| ! is_numeric( $video['height'] ?? null )
					|| (int) $video['height'] <= 0
					|| ( isset( $video['is_playable'] ) && ! $video['is_playable'] )
					|| ( isset( $video['status'] ) && 'available' !== $video['status'] ) ) {
					$omitted = true;
					continue;
				}
				$snaps[] = array(
					'title'       => (string) ( $video['name'] ?? '' ),
					'description' => (string) ( $video['description'] ?? '' ),
					'thumb'       => $video['pictures']['base_link'],
					'width'       => (int) $video['width'],
					'height'      => (int) $video['height'],
					'video_url'   => 'https://vimeo.com/' . $match[1],
				);
				if ( $limit && count( $snaps ) >= $limit ) {
					$complete = ! $omitted && empty( $data['paging']['next'] )
						&& count( $seen ) === $before_page + count( $data['data'] )
						&& count( $seen ) === (int) ( $data['total'] ?? count( $seen ) );
					return $snaps;
				}
			}
			if ( empty( $data['paging']['next'] ) ) {
				if ( isset( $data['total'] ) && count( $seen ) !== (int) $data['total'] ) {
					$omitted = true;
				}
				if ( $omitted ) {
					return $fail( esc_html__( 'Some Showcase videos are private, unavailable, or missing usable video details. No videos were imported. Check the collection in Vimeo.', 'modula-pro' ) );
				}
				if ( ! $snaps ) {
					return array( 'error' => esc_html__( 'This public Vimeo Showcase contains no accessible videos to import.', 'modula-pro' ) );
				}
				$complete = true;
				return $snaps;
			}
			if ( ! $data['data'] ) {
				break;
			}
			// Pagination links are signals only. Construct the next numbered page on the same API resource.
		}
		return $fail( esc_html__( 'Vimeo did not finish returning the Showcase. No videos were imported. Try a smaller collection.', 'modula-pro' ) );
	}

	// Function to fetch video IDs from a YouTube playlist
	private static function get_video_from_channel( $url, $token, $limit = 0, &$complete = null ) {
		if ( ! strpos( $url, '/channels/' ) ) {
			return array( 'error' => esc_html__( 'Invalid Vimeo channel url', 'modula-pro' ) );
		}
		$channel_api_url = 'https://api.vimeo.com' . rtrim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' ) . '/videos';
		// Create a new HTTP client
		$client = new Client(
			array(
				'base_uri' => 'https://api.vimeo.com',
				'timeout' => $limit ? 15 : 0,
				'connect_timeout' => $limit ? 5 : 0,
				'headers' => array(
					'Authorization' => "Bearer $token",
				),
			)
		);

		$videos = array();
		$return = array();
		$params = array( 'per_page' => 50 ); // Fetch 50 videos per page, adjust as needed

		// Loop through pages
		while ( $channel_api_url ) {
			try {
				$response = $client->get( $channel_api_url, $params ? array( 'query' => $params ) : array() );
				$params = array();
				$data     = json_decode( (string) $response->getBody(), true );

				// Add the video data to the list
				if ( isset( $data['data'] ) ) {
					$videos = array_merge( $videos, $data['data'] ); // Combine new videos with existing ones
					if ( $limit && count( $videos ) >= $limit ) { $complete = count( $videos ) === $limit && empty( $data['paging']['next'] ); $videos = array_slice( $videos, 0, $limit ); break; }
				}

				// Check for next page
				$channel_api_url = $data['paging']['next'] ?? null;
			} catch ( ClientException $e ) {
				$complete = false;
				if ( $limit && $videos ) { break; }
				return array( 'error' => esc_html__( 'The Vimeo channel URL entered is malformed or no videos could be found.', 'modula-pro' ) );
			}
		}

		foreach ( $videos as $video ) {
			$return[] = array(
				'title'       => $video['name'],
				'thumb'       => $video['pictures']['base_link'],
				'description' => $video['description'],
				'width'       => $video['width'],
				'height'      => $video['height'],
				'video_url'   => 'https://vimeo.com/' . basename( trim( $video['uri'], '/' ) ),
			);
		}

		return $return;
	}

	/**
	 * Set the video gallery name so we can use the video template
	 *
	 * @param $paths
	 *
	 * @return mixed
	 */
	public function modula_video_template_name( $name, $type ) {

		return 'video' !== $type ? $name : 'video';
	}


	/**
	 * Add extra path for modula templates
	 *
	 * @param $paths
	 *
	 * @return mixed
	 */
	public function add_modula_slider_templates_path( $paths ) {

		$paths[32] = trailingslashit( \MODULA_PRO_PATH ) . '/includes/extensions/video/templates';
		return $paths;
	}

	/**
	 * Template for video slider
	 *
	 * @param  string  $name
	 * @param  array   $settings
	 * @param  array   $item
	 *
	 * @return string
	 * @since 1.1.0
	 */
	public function modula_video_slider_item_template_name( $name, $settings, $item ) {
		if ( isset( $settings['type'] ) && 'slider' === $settings['type'] && self::is_preview_video_enabled( isset( $settings['preview-video'] ) ? $settings['preview-video'] : 0 ) && isset( $item['video_url'] ) && '' !== $item['video_url'] ) {
			return 'video-slider';
		}

		return $name;
	}


	public function add_video_to_albums_config( $item_data, $image, $gallery_settings, $settings, $images ) {

		if ( isset( $settings['enable_lightbox'] ) && 1 === (int) $settings['enable_lightbox'] ) {
			if ( ! empty( $images ) ) {
				$images_config = array();
				foreach ( $images as $image ) {
					$image['title']       = isset( $image['title'] ) ? $image['title'] : '';
					$image['description'] = isset( $image['description'] ) ? $image['description'] : '';
					$image['alt']         = isset( $image['alt'] ) ? $image['alt'] : '';

					$img_title   = get_the_title( $image['id'] );
					$img_caption = get_post_field( 'post_excerpt', $image['id'] );

					if ( isset( $image['video_url'] ) && '' !== $image['video_url'] ) {
						$src = self::video_link_formatter( $image['video_url'] );
					} else {
						$src = wp_get_attachment_image_url( $image['id'], 'full' );
					}

					if ( ! $src ) {
						continue;
					}

					if ( isset( $image['video_thumbnail'] ) && '' !== $image['video_thumbnail'] ) {
						$thumb = $image['video_thumbnail'];
					} else {
						$thumb = wp_get_attachment_image_url( $image['id'] );
					}

					if ( ! $thumb ) {
						$thumb = \MODULA_PRO_URL . self::NO_IMAGE_POSTER;
					}

					$caption = '';
					if ( 1 === (int) $settings['show_image_title'] ) {
						$caption .= '<span class="modula-album-caption-title">' . $img_title . '</span>';
					}
					if ( 1 === (int) $settings['show_image_title'] && 1 === (int) $settings['show_image_caption'] ) {
						$caption .= '<br>';
					}
					if ( 1 === (int) $settings['show_image_caption'] ) {
						$caption .= '<span class="modula-album-caption-description">' . $img_caption . '</span>';
					}

					$image_config = array(
						'src'  => esc_attr( $src ),
						'opts' => array(
							'caption'  => $caption,
							'alt'      => $image['alt'],
							'thumb'    => $thumb,
							'image_id' => $image['id'],
							'title'    => $img_title,
							'download' => isset( $settings['enable_download'] ) ? $settings['enable_download'] : 0,
						),
					);

					// Re-run lightbox item filters so Video rebuild does not wipe
					// EXIF / Speedup / other album lightbox caption contributions.
					$images_config[] = apply_filters(
						'modula_album_lightbox_item',
						$image_config,
						$image,
						$gallery_settings,
						array(
							'id' => isset( $item_data['gallery_id'] ) ? $item_data['gallery_id'] : 0,
						),
						$settings
					);
				}
				$item_data['gallery_images']                         = $images_config;
				$item_data['link_attributes']['data-gallery-images'] = $images_config;
			}
		}

		return $item_data;
	}

	/**
	 * Sanitize image fields
	 *
	 * @param array $sanitized The sanitized data
	 * @param mixed $value
	 * @param mixed $attribute
	 * @return void
	 */
	public function modula_video_image_fields_sanitization( $sanitized, $value, $attribute ) {
		if ( 'video_url' === $attribute ) {
			return sanitize_url( $value );
		}

		return $sanitized;
	}

	/**
	 * Add video related settings to edit modal.
	 *
	 * @param array $fields The fields.
	 *
	 * @since 1.0.0
	 *
	 * @return array $fields.
	 * @moved @1.1.5
	 */
	public function add_item_fields( $fields ) {

		$fields[] = 'video_url';
		$fields[] = 'video_title';
		$fields[] = 'video_alt';
		$fields[] = 'video_description';
		$fields[] = 'video_thumbnail';
		$fields[] = 'video_template';
		$fields[] = 'video_width';
		$fields[] = 'video_height';
		$fields[] = 'autoplay_thumbnail';
		$fields[] = 'autoplay_lightbox';
		$fields[] = 'loop_video';
		return $fields;
	}

	/**
	 * Whether "Preview Video in Gallery" is considered enabled.
	 * Normalizes values saved as 1, "1", true, "true" (toggle/REST/legacy).
	 *
	 * @param mixed $value Setting value.
	 * @return bool
	 */
	public static function is_preview_video_enabled( $value ) {
		return in_array( $value, array( 1, '1', true, 'true' ), true );
	}

	/**
	 * Alter the current gallery item data in order to add video related attributes.
	 *
	 * @since 1.0.0
	 *
	 * @return array item_data.
	 */
	public function add_video( $item_data, $item, $settings ) {

		$item_data['is_video'] = false;

		if ( isset( $item['video_url'] ) && '' !== $item['video_url'] ) {
			if ( ! isset( $item_data['item_classes'] ) || ! is_array( $item_data['item_classes'] ) ) {
				$item_data['item_classes'] = array( 'modula-item' );
			}
			if ( ! isset( $item_data['img_classes'] ) || ! is_array( $item_data['img_classes'] ) ) {
				$item_data['img_classes'] = array();
			}
			if ( ! isset( $item_data['link_classes'] ) || ! is_array( $item_data['link_classes'] ) ) {
				$item_data['link_classes'] = array();
			}
			if ( ! isset( $item_data['img_attributes'] ) || ! is_array( $item_data['img_attributes'] ) ) {
				$item_data['img_attributes'] = array();
			}
			if ( ! isset( $item_data['link_attributes'] ) || ! is_array( $item_data['link_attributes'] ) ) {
				$item_data['link_attributes'] = array();
			}

			$video_class       = 'modula-hosted-video-content';
			$video_type        = 'hosted';
			$item['video_url'] = self::video_link_formatter( $item['video_url'] );

			$loop = isset( $settings['loop-videos'] ) ? $settings['loop-videos'] : 0;
			if ( isset( $item['loop_video'] ) && 'inherit' !== $item['loop_video'] ) {
				$loop = $item['loop_video'];
			}

			// Check if Vimeo video URL
			if ( false !== strpos( $item['video_url'], 'vimeo' ) ) {
				if ( 1 === (int) $loop ) {
					$item['video_url'] = add_query_arg( array( 'loop' => '1' ), self::video_link_formatter( $item['video_url'] ) );
				}

				$video_class = 'modula-vimeo-video-content';
				$video_type  = 'vimeo';

				// Check if Youtube video URL
			} elseif ( false !== strpos( $item['video_url'], 'youtu' ) ) {
				if ( 1 === (int) $loop ) {
					$item['video_url'] = add_query_arg(
						array(
							'loop'     => '1',
							'playlist' => self::get_youtube_video_id( $item['video_url'] ),
						),
						self::video_link_formatter( $item['video_url'] )
					);
				}

				$video_class = 'modula-youtube-video-content';
				$video_type  = 'youtube';
			}

			$video_class .= ' modula-video-content';

			// Don't escape it as we will escape it later when we echo.
			$item_data['img_attributes']['data-full'] = $item['video_url'];

			// The pic class is used for opening in lightbox.
			// Add it only for slider type.
			$classes = array( 'tile-inner', 'modula-item-link' );
			if ( 'slider' === $settings['type'] ) {
				$classes[] = 'pic';
			}
			$item_data['link_attributes']['class'] = $classes;
			$item_data['link_attributes']['rel']   = $settings['gallery_id'];
			// Attach the video url to the data-full attribut in order to properly open it in lightbox.
			$item_data['link_attributes']['data-full'] = $item['video_url'];

			// we nee to remake the array keys as the hover effect needs to be 1
			$item_data['item_classes'] = array_values( array_diff( $item_data['item_classes'], array( 'modula-simple-link' ) ) );

			if ( self::is_preview_video_enabled( isset( $settings['preview-video'] ) ? $settings['preview-video'] : 0 ) ) {
				$item_data['item_classes'][] = $video_class;
				$item_data['video_type']     = $video_type;
				$item_data['img_classes'][]  = 'modula_video_poster';
			}

			if ( 'magnific' === $settings['lightbox'] ) {
				$item_data['link_classes'][] = 'mfp-iframe';
			}

			$item_data['is_video'] = true;
		}

		if ( isset( $item['togglelightbox'] ) && 1 === $item['togglelightbox'] ) {
			$item_data['link_attributes']['class'][] = 'modula-simple-link'; //prevent the lightboxification
			$item_data['link_attributes']['class'][] = 'modula-no-follow'; //prevent the opening of the image
		}

		if ( isset( $settings['custom-video-icon'] ) && 0 !== absint( $settings['custom-video-icon'] ) ) {
			$item_data['custom_video_icon_id'] = $settings['custom-video-icon'];
		}

		if ( ( ! isset( $settings['custom-video-icon'] ) || 0 === absint( $settings['custom-video-icon'] ) ) && isset( $settings['video-icon-icon'] ) ) {
			$item_data['video_svg_icon'] = $settings['video-icon-icon'];
		}

		if ( ! isset( $settings['show-video-icon'] ) || ! $settings['show-video-icon'] ) {
			$item_data['is_video'] = false;
		}

		$item_data['preview_video'] = self::is_preview_video_enabled( isset( $settings['preview-video'] ) ? $settings['preview-video'] : 0 );

		if ( isset( $item['autoplay_thumbnail'] ) && 'inherit' !== $item['autoplay_thumbnail'] && '' !== $item['autoplay_thumbnail'] ) {
			$item_data['video_attributes']['data-autothumb'] = $item['autoplay_thumbnail'];
		}
		$item_data['video_attributes']['data-autothumb'] = isset( $settings['autoplay_thumbnail'] ) ? $settings['autoplay_thumbnail'] : 0;

		$item_data['video_attributes']['data-autolight'] = isset( $settings['autoplay-videos'] ) ? $settings['autoplay-videos'] : 0;
		if ( isset( $item['autoplay_lightbox'] ) && 'inherit' !== $item['autoplay_lightbox'] && '' !== $item['autoplay_lightbox'] ) {
			$item_data['video_attributes']['data-autolight'] = $item['autoplay_lightbox'];
		}

		$item_data['video_attributes']['data-loop'] = isset( $settings['loop-videos'] ) ? $settings['loop-videos'] : 0;
		if ( isset( $item['loop_video'] ) && 'inherit' !== $item['loop_video'] && '' !== $item['loop_video'] ) {
			$item_data['video_attributes']['data-loop'] = $item['loop_video'];
		}

		/*
		 * Classic Fancybox reads data-loop / data-autolight from img.pic
		 * (fancybox-modula-video.js). Preview-only video_attributes are not enough.
		 */
		if ( isset( $item['video_url'] ) && '' !== $item['video_url'] ) {
			if ( ! isset( $item_data['img_attributes'] ) || ! is_array( $item_data['img_attributes'] ) ) {
				$item_data['img_attributes'] = array();
			}
			$item_data['img_attributes']['data-loop']      = $item_data['video_attributes']['data-loop'];
			$item_data['img_attributes']['data-autolight'] = $item_data['video_attributes']['data-autolight'];
		}

		// Save item data so we can check if the item is video later.
		$this->item_data = $item;

		return $item_data;
	}

	public function add_hidden_video( $attr, $settings, $item ) {
		if ( isset( $item['video_url'] ) && '' !== $item['video_url'] ) {
			$video_class       = 'modula-hosted-video-content';
			$video_type        = 'hosted';
			$item['video_url'] = self::video_link_formatter( $item['video_url'] );

			$autoplay        = isset( $settings['autoplay-videos'] ) ? absint( $settings['autoplay-videos'] ) : 0;
			$should_autoplay = isset( $settings['type'] ) && ( 'video' === $settings['type'] || 'slider' === $settings['type'] ) ? 0 : 1;
			if ( isset( $item['autoplay_lightbox'] ) && 'inherit' !== $item['autoplay_lightbox'] ) {
				$autoplay = $item['autoplay_lightbox'];
			}

			$loop = isset( $settings['loop-videos'] ) ? absint( $settings['loop-videos'] ) : 0;
			if ( isset( $item['loop_video'] ) && 'inherit' !== $item['loop_video'] ) {
				$loop = $item['loop_video'];
			}

			// Check if Vimeo video URL
			if ( false !== strpos( $item['video_url'], 'vimeo' ) ) {
				if ( 1 === $loop ) {
					$item['video_url'] = add_query_arg( array( 'loop' => '1' ), $item['video_url'] );
				}

				if ( 1 === $autoplay && 1 === $should_autoplay ) {
					$item['video_url'] = add_query_arg( array( 'autoplay' => '1' ), $item['video_url'] );
				}

				$video_class = 'modula-vimeo-video-content';
				$video_type  = 'vimeo';

				// Check if Youtube video URL
			} elseif ( false !== strpos( $item['video_url'], 'youtu' ) ) {
				if ( 1 === $loop ) {
					$item['video_url'] = add_query_arg(
						array(
							'loop'     => '1',
							'playlist' => self::get_youtube_video_id( $item['video_url'] ),
						),
						self::video_link_formatter( $item['video_url'] )
					);
				}

				$video_class = 'modula-youtube-video-content';
				$video_type  = 'youtube';
			}

			$video_class .= ' modula-video-content';

			// Don't escape it as we will escape it later when we echo.
			$attr['data-full'] = $item['video_url'];

			$attr['rel'] = $settings['gallery_id'];

			if ( 'magnific' === $settings['lightbox'] ) {
				$attr['class'][] = 'mfp-iframe';
			}

			$attr['is_video'] = true;
		}

		if ( isset( $item['video_template'] ) && 1 === (int) $item['video_template'] ) {
			if ( 'fancybox' === $settings['lightbox'] ) {
				$caption = '';

				if ( isset( $item['video_description'] ) && '' !== $item['video_description'] ) {
					$caption = $item['video_description'];
				}

				$title = '';

				if ( isset( $item['video_title'] ) && '' !== $item['video_title'] ) {
					$title = $item['video_title'];
				}

				$show_title   = ( isset( $settings['showTitleLightbox'] ) && 1 === absint( $settings['showTitleLightbox'] ) ) && ( ! isset( $item['hide_title'] ) || 1 !== absint( $item['hide_title'] ) );
				$show_caption = ( isset( $settings['showCaptionLightbox'] ) && 1 === absint( $settings['showCaptionLightbox'] ) );

				if ( $show_title && $show_caption ) {
					$attr['data-caption'] = esc_attr( '<span class="modula-caption-title">' . $title . '</span><br><span class="modula-caption-description">' . $caption . '</span>' );
				} elseif ( $show_title && ! $show_caption ) {
					$attr['data-caption'] = esc_attr( '<span class="modula-caption-title">' . $title . '</span>' );
				} elseif ( ! $show_title && $show_caption ) {
					$attr['data-caption'] = esc_attr( '<span class="modula-caption-description">' . $caption . '</span>' );
				} else {
					$attr['data-caption'] = '';
				}
			}
		}

		return $attr;
	}

	/**
	 * Set item data
	 *
	 * @param $item_data
	 * @param $image
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function modula_slider_add_video_class( $item_data, $image, $settings ) {

		if ( 'slider' === $settings['type'] ) {
			if ( isset( $image['video_url'] ) && '' !== $image['video_url'] ) {
				$video_class = 'modula-hosted-video-content';

				if ( strpos( $image['video_url'], 'vimeo' ) ) {
					$video_class = 'modula-vimeo-video-content';
				}

				if ( strpos( $image['video_url'], 'youtu' ) ) {
					$video_class = 'modula-youtube-video-content';
				}

				$video_class .= ' modula-video-content';

				$item_data['item_classes'][] = $video_class;
			}
		}
		return $item_data;
	}
}
