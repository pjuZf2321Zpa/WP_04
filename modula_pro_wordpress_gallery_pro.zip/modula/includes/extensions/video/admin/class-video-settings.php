<?php
namespace Modula_Pro\Extensions\Video\Admin;

use Modula_Pro\Extensions\Video\Video;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Video_Settings {

	/**
	 * Holds the admin class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	public function __construct() {

		// Filter Modula Fields
		add_filter( 'modula_gallery_fields', array( $this, 'modula_video_fields' ) );

		// Save Filters for our resonsive-input types
		add_filter( 'modula_render_responsive-input_field_type', array( $this, 'edit_icon_size_fields' ), 10, 3 );

		// Backwards compatibility for responsive-input types
		add_filter( 'modula_admin_field_value', array( $this, 'backward_compatibility_responsive_video_icon' ), 15, 3 );
		add_filter( 'modula_backbone_settings', array( $this, 'backward_compatibility_backbone_responsive_video_icon' ), 15 );

		// Custom video icon upload field type
		add_filter( 'modula_render_video_icon_upload_field_type', array( $this, 'video_icon_upload_field_type' ), 10, 5 );
		// Custom video icon upload field type
		add_filter( 'modula_render_select-play-icon_field_type', array( $this, 'select_play_icon_field_type' ), 10, 5 );

		/* Add templates for our plugin */
		add_action( 'admin_footer', array( $this, 'print_modula_video_templates' ) );

		// Show Video Icon on backend
		add_action( 'modula_admin_gallery_image_start', array( $this, 'backend_show_video_icon' ), 99 );

		// Add new input for item
		add_action( 'modula_item_extra_fields', array( $this, 'extra_item_fields' ) );

		// Add JS
		add_action( 'modula_scripts_before_wp_modula', array( $this, 'video_js' ) );

		// Enqueue admin required scripts
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'modula_video_admin_scripts' ), 40 );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'modula_video_admin_scripts' ), 40 );

		add_action( 'modula_scripts_before_wp_modula', array( $this, 'video_js' ) );

		//Filter Modula Video Tab
		add_filter( 'modula_gallery_tabs', array( $this, 'modula_video_tab' ) );

		// Start doing stuff for add new video
		add_action( 'modula_gallery_media_button', array( $this, 'add_video_media_button' ) );
		add_action( 'modula_gallery_media_select_option', array( $this, 'add_video_media_option' ) );
		add_filter( 'modula_helper_properties', array( $this, 'also_display_video_template_to_metabox' ) );
		add_action( 'wp_ajax_modula_video_get_snap', array( $this, 'get_snap' ) );
		add_action( 'wp_ajax_modula_video_get_playlist_snap', array( $this, 'get_playlist_snap' ) );
		add_filter( 'modula_admin_page_tabs', array( $this, 'add_settings_tab' ) );
		add_action( 'modula_admin_tab_video', array( $this, 'integrations_navigation' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'modula_video_integrations_scripts' ) );

		add_filter( 'modula_gallery_fields', array( $this, 'modula_video_gallery_type' ), 15, 1 );

		add_filter( 'modula_settings_editor_config', array( $this, 'filter_settings_editor_config' ), 10, 2 );
	}

	/**
	 * Expose video OAuth hints to the v2 settings editor (takeover has no legacy metabox DOM).
	 *
	 * @param array<string, mixed> $editor_config Localized config for the React editor.
	 * @param int                  $post_id       Current gallery post ID.
	 * @return array<string, mixed>
	 */
	public function filter_settings_editor_config( $editor_config, $post_id ) {
		unset( $post_id );

		$vimeo_auth  = Vimeo_Auth::get_instance();
		$google_auth = Google_Auth::get_instance();

		$editor_config['videoOAuthConnected'] = (bool) (
		$vimeo_auth->get_access_token() || $google_auth->get_access_token()
		);

		$editor_config['videoIntegrationsUrl'] = admin_url(
			'edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media'
		);

		return $editor_config;
	}


	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Modula_Video_Setings object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Video_Setings ) ) {
			self::$instance = new Video_Setings();
		}

		return self::$instance;
	}

	public function modula_video_tab( $tabs ) {

		unset( $tabs['video']['badge'] );

		return $tabs;
	}

	public function modula_video_admin_scripts() {

		wp_enqueue_script( 'modula-video-conditions', \MODULA_PRO_URL . 'includes/extensions/video/assets/js/wp-modula-video-conditional.js', array( 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-video-admin-css', \MODULA_PRO_URL . 'includes/extensions/video/assets/css/wp-modula-video-admin.css', array(), \MODULA_PRO_VERSION );
	}

	/**
	 * Add video related settings.
	 *
	 * @since 1.0.0
	 *
	 * @return array $fields.
	 */
	public function modula_video_fields( $fields ) {

		$fields['video'] = array(
			'autoplay-videos'        => array(
				'name'      => esc_html__( 'Autoplay Videos', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'afterrow'  => wp_kses_post( 'On iOS, Autoplay is supported only for self hosted videos. The videos will autoplay on mute. For more details check : <a target="_blank" href="https://webkit.org/blog/6784/new-video-policies-for-ios"> video policies </a> ', 'modula-pro' ),
				'priority'  => 1,
				'data_type' => 'bool',
			),

			'loop-videos'            => array(
				'name'      => esc_html__( 'Loop Videos', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 2,
				'data_type' => 'bool',
			),

			'show-video-icon'        => array(
				'name'      => esc_html__( 'Display Play Icon', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 3,
				'children'  => array( 'use-custom-icon', 'play-icon-size', 'custom-video-icon', 'video-icon-color', 'video-icon-icon' ),
				'data_type' => 'bool',
			),

			'use-custom-icon'        => array(
				'name'      => esc_html__( 'Use custom icon', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'is_child'  => true,
				'priority'  => 5,
				'data_type' => 'bool',
			),

			'custom-video-icon'      => array(
				'name'        => esc_html__( 'Upload Custom Icon', 'modula-pro' ),
				'type'        => 'video_icon_upload',
				'default'     => 0,
				'class'       => 'button insert-media-url',
				'button_text' => esc_html__( 'Upload Video Icon', 'modula-pro' ),
				'is_child'    => true,
				'priority'    => 10,
				'data_type'   => 'text',

			),

			'video-icon-icon'        => array(
				'name'     => esc_html__( 'Select Video Play Icon', 'modula-pro' ),
				'is_child' => true,
				'type'     => 'select-play-icon',
				'default'  => '',
				'priority' => 12,
				'values'   => Video::get_available_icons(),
			),

			'video-icon-color'       => array(
				'name'      => esc_html__( 'Play Icon Color', 'modula-pro' ),
				'type'      => 'color',
				'default'   => '#FFF',
				'alpha'     => true,
				'is_child'  => true,
				'priority'  => 15,
				'data_type' => 'text',
			),

			'play-icon-size'         => array(
				'name'      => esc_html__( 'Play Icon Size', 'modula-pro' ),
				'type'      => 'responsive-input',
				'default'   => array( 30, 30, 30 ),
				'is_child'  => true,
				'priority'  => 20,
				'data_type' => 'number',
			),

			'preview-video'          => array(
				'name'      => esc_html__( 'Preview Video in Gallery', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 30,
				'children'  => array( 'preview-video-duration', 'autoplay_thumbnail' ),
				'data_type' => 'bool',
			),

			'preview-video-duration' => array(
				'name'      => esc_html__( 'Preview Duration', 'modula-pro' ),
				'type'      => 'number',
				'default'   => 3,
				'after'     => esc_html__( 'seconds', 'modula-pro' ),
				'is_child'  => true,
				'priority'  => 35,
				'data_type' => 'number',
			),

			'autoplay_thumbnail'     => array(
				'name'      => esc_html__( 'Autoplay videos in thumbnail', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'after'     => esc_html__( 'seconds', 'modula-pro' ),
				'is_child'  => true,
				'priority'  => 40,
				'data_type' => 'number',
			),
		);
		$fields['general']['playlist_position'] = array(
			'name'     => esc_html__( 'Playlist Position', 'modula-pro' ),
			'type'     => 'select',
			'values'   => array(
				'right'  => esc_html__( 'Right', 'modula-pro' ),
				'bottom' => esc_html__( 'Bottom', 'modula-pro' ),
			),
			'default'  => 'justify',
			'priority' => 20,
		);
		return $fields;
	}

	/**
	 * Modula Item's video url template.
	 *
	 * @since 1.0.0
	 *
	 */
	public function print_modula_video_templates() {
		?>
		<script type="text/html" id="tmpl-modula-video">
			<label class="">
				<span class="name"><?php esc_html_e( 'Video URL', 'modula-pro' ); ?></span>
				<input type="text" class="modula_video_url_input" name="video_url" value="{{ data.video_url }}" />
				<div class="description">
					<?php esc_html_e( 'Insert a video url, can be YouTube, Vimeo or self hosted.', 'modula-pro' ); ?>
				</div>
			</label>
			<label class="">
				<span class="name"><?php esc_html_e( 'Video Thumbnail', 'modula-pro' ); ?></span>
				<input type="text" name="video_thumbnail" value="{{ data.video_thumbnail }}" />
				<div class="description">
					<?php esc_html_e( 'Insert a video thumbnail witch will display in lightbox navigation. Also serves as poster for self hosted videos.', 'modula-pro' ); ?>
				</div>
			</label>
			<!-- Autoplay thumbnail -->
			<div class="setting">
				<span class="name"><?php esc_html_e( 'Autoplay thumbnail', 'modula-pro' ); ?></span>
				<select name="autoplay_thumbnail">
					<option value="inherit" <# if ( data.autoplay_thumbnail == 'inherit' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'Inherit', 'modula-pro' ); ?></option>
					<option value="1" <# if ( data.autoplay_thumbnail == '1' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'ON', 'modula-pro' ); ?></option>
					<option value="0" <# if ( data.autoplay_thumbnail == '0' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'OFF', 'modula-pro' ); ?></option>
				</select>
			</div>
			<!-- Autoplay lighbox -->
			<div class="setting">
				<span class="name"><?php esc_html_e( 'Autoplay lighbox', 'modula-pro' ); ?></span>
				<select name="autoplay_lightbox">
					<option value="inherit" <# if ( data.autoplay_lightbox == 'inherit' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'Inherit', 'modula-pro' ); ?></option>
					<option value="1" <# if ( data.autoplay_lightbox == '1' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'ON', 'modula-pro' ); ?></option>
					<option value="0" <# if ( data.autoplay_lightbox == '0' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'OFF', 'modula-pro' ); ?></option>
				</select>
			</div>
			<!-- Loop Video -->
			<div class="setting">
				<span class="name"><?php esc_html_e( 'Loop Video', 'modula-pro' ); ?></span>
				<select name="loop_video">
					<option value="inherit" <# if ( data.loop_video == 'inherit' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'Inherit', 'modula-pro' ); ?></option>
					<option value="1" <# if ( data.loop_video == '1' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'ON', 'modula-pro' ); ?></option>
					<option value="0" <# if ( data.loop_video == '0' ) { #> selected="selected" <# } #> > <?php esc_html_e( 'OFF', 'modula-pro' ); ?></option>
				</select>
			</div>
		</script>
		<script type="text/html" id="tmpl-modula-video-item">
			<div class="modula-single-image-content {{data.orientation}}" <# if ( data.full != '' ) { #> style="background-image:url('{{ data.thumbnail }}'); background-position: {{ data.valign }} {{ data.halign }};" <# } #> >
				<?php do_action( 'modula_admin_gallery_video_start' ); ?>
				<# if ( 'video_url' in data && data.video_url != '' && 'video_img_icon' in data && data.video_img_icon ) { #>
				
					<div class="modula-video-icon">
						<img class="img_icon" src="{{data.video_img_icon}}" />
					</div>
						
				<# }else if( 'video_url' in data && data.video_url != '' && 'video_svg_icon' in data && data.video_svg_icon ){ #>
					<div class="modula-video-icon">
						<svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" data-prefix="far" data-icon="play-circle" class="svg-inline--fa fa-play-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="{{data.video_icon_color}}" d="{{data.video_svg_icon}}"></path></svg>
					</div>
				<# } #>
				<# if ( data.thumbnail != '' ) { #>
					<img class="modula_video_previewer_image" src="{{ data.thumbnail }}">
				<# } #>
				<div class="actions">
					<?php do_action( 'modula_admin_gallery_video_before_actions' ); ?>
					<a href="#" class="modula-edit-video" title="<?php esc_attr_e( 'Edit Video', 'modula-pro' ); ?>"><span class="dashicons dashicons-edit"></span></a>
					<?php do_action( 'modula_admin_gallery_video_after_actions' ); ?>
					<a href="#" class="modula-delete-video" title="<?php esc_attr_e( 'Delete Video', 'modula-pro' ); ?>"><span class="dashicons dashicons-trash"></span></a>
				</div>
				<div class="segrip ui-resizable-handle ui-resizable-se"></div>
				<?php do_action( 'modula_admin_gallery_video_end' ); ?>
			</div>
		</script>
		<script type="text/html" id="tmpl-modula-video-editor">
			<div class="edit-media-header">
				<button class="left dashicons"><span class="screen-reader-text"><?php esc_html_e( 'Edit previous media item', 'modula-pro' ); ?></span></button>
				<button class="right dashicons"><span class="screen-reader-text"><?php esc_html_e( 'Edit next media item', 'modula-pro' ); ?></span></button>
			</div>
			<div class="media-frame-title">
				<h1><?php esc_html_e( 'Edit Metadata', 'modula-pro' ); ?></h1>
			</div>
			<div class="media-frame-content">
				<div class="attachment-details save-ready">
					<!-- Left -->
					<div class="attachment-media-view portrait">
						<div class="thumbnail thumbnail-image">
							<img class="details-image" src="{{ data.full }}" draggable="false" />
						</div>
					</div>
					
					<!-- Right -->
					<div class="attachment-info">
						<!-- Settings -->
						<div class="settings">
							<!-- Attachment ID -->
							<input type="hidden" name="id" value="{{ data.id }}" />
							
							<!-- Video Title -->
							<label class="setting">
								<span class="name"><?php esc_html_e( 'Video Title', 'modula-pro' ); ?></span>
								<input type="text" name="video_title" value="{{ data.video_title }}" />
								<div class="description">
									<?php esc_html_e( 'Video titles can take any type of HTML.', 'modula-pro' ); ?>
								</div>
							</label>
						
							
							<!-- Video Alt Text -->
							<label class="setting">
								<span class="name"><?php esc_html_e( 'Video Alt Text', 'modula-pro' ); ?></span>
								<input type="text" name="video_alt" value="{{ data.video_alt }}" />
								<div class="description">
									<?php esc_html_e( 'Very important for SEO, the Alt Text describes the video.', 'modula-pro' ); ?>
								</div>
							</label>

							<!-- Video Caption Text -->
							<label class="setting">
								<span class="name"><?php esc_html_e( 'Video Caption Text', 'modula-pro' ); ?></span>
								<textarea name="video_description">{{ data.video_description }}</textarea>
							</label>
							<!-- Link -->
							<div class="setting modula-link">
								<label class="">
									<span class="name"><?php esc_html_e( 'URL', 'modula-pro' ); ?></span>
									<input type="text" name="link" value="{{ data.link }}" />
									<span class="dashicons dashicons-editor-break"></span>
									<span class="description">
										<?php esc_html_e( 'You can start typing the first 3 letter and we will autocomplete the rest !', 'modula-pro' ); ?>
										<?php esc_html_e( 'Enter a hyperlink if you wish to link this video to somewhere other than the general selected action.', 'modula-pro' ); ?>
									</span>
								</label>
								<label>
								<span class="description">
									<input type="checkbox" name="target" value="1"<# if ( data.target == '1' ) { #> checked <# } #> />
									<span><?php esc_html_e( 'Opens your image links in a new browser window / tab.', 'modula-pro' ); ?></span>
								</span>
								</label>
							</div>
							<!-- Hide from lightbox -->
							<div class="setting modula-toggle-lightbox">
								<div class="modula-toggle">
									<label class="">
										<span class="name"><?php esc_html_e( 'Hide video from lightbox', 'modula-pro' ); ?></span>
										<input class="modula-toggle__input" type="checkbox" name="togglelightbox" value="1"<# if ( data.togglelightbox == '1' ) { #> checked <# } #> />
										<div class="modula-toggle__items">
											<span class="modula-toggle__track"></span>
											<span class="modula-toggle__thumb"></span>
											<svg class="modula-toggle__off" width="6" height="6" aria-hidden="true"
													role="img"
													focusable="false"
													viewBox="0 0 6 6">
												<path d="M3 1.5c.8 0 1.5.7 1.5 1.5S3.8 4.5 3 4.5 1.5 3.8 1.5 3 2.2 1.5 3 1.5M3 0C1.3 0 0 1.3 0 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z"></path>
											</svg>
											<svg class="modula-toggle__on" width="2" height="6" aria-hidden="true"
													role="img"
													focusable="false"
													viewBox="0 0 2 6">
												<path d="M0 0h2v6H0z"></path>
											</svg>
										</div>
									</label>
								</div>
							</div>
							<!-- Addons can populate the UI here -->
							<div class="modula-addons"></div>
							<label class="setting">
								<span class="name"><?php esc_html_e( 'Video Width X Height', 'modula-pro' ); ?></span>
								<div class="modula-video-image-w-h">
									<input type="number" name="video_width" value="{{ data.video_width }}" />
									<span>x</span>
									<input type="number" name="video_height" value="{{ data.video_height }}" />
									<span>px</span>
								</div>
								<div class="description">
									<?php esc_html_e( 'Set the width & height for videos. Used for aspect ratio calculations.', 'modula-pro' ); ?>
								</div>
							</label>
						</div>
						<!-- /.settings -->     
					
						<!-- Actions -->
						<div class="actions">
							<a href="#" class="modula-gallery-meta-submit button media-button button-large button-primary media-button-insert" title="<?php esc_attr_e( 'Save Metadata', 'modula-pro' ); ?>">
								<?php esc_html_e( 'Save', 'modula-pro' ); ?>
							</a>
							<a href="#" class="modula-gallery-meta-submit-close button media-button button-large media-button-insert" title="<?php esc_attr_e( 'Save & Close', 'modula-pro' ); ?>">
								<?php esc_html_e( 'Save & Close', 'modula-pro' ); ?>
							</a>

							<!-- Save Spinner -->
							<span class="settings-save-status">
								<span class="spinner"></span>
								<span class="saved"><?php esc_html_e( 'Saved.', 'modula-pro' ); ?></span>
							</span>
						</div>
						<!-- /.actions -->
					</div>
				</div>
			</div>
		</script>
		<?php
	}

	/**
	 * Item's video url hidden input.
	 *
	 * @since 1.0.0
	 *
	 */
	public function extra_item_fields() {
		echo '<input type="hidden" name="modula-images[video_url][{{data.index}}]" class="modula-image-video-url" value="{{ data.video_url }}">';
	}

	/**
	 * Add input settings for video play button size on different devices.
	 *
	 * @since 1.0.6
	 *
	 * @return string.
	 */
	public function edit_icon_size_fields( $html, $field, $value ) {
		if ( empty( $value ) ) {
			$value = isset( $field['default'] ) ? $field['default'] : array( 30, 30, 30 );
		}
		$html  = '<span class="dashicons dashicons-desktop"></span><input type="number" class="responsive-input" name="modula-settings[' . esc_attr( $field['id'] ) . '][]" value="' . esc_attr( $value[0] ) . '"><span class="modula_input_suffix">px</span>';
		$html .= '<span class="dashicons dashicons-tablet"></span><input type="number" class="responsive-input" name="modula-settings[' . esc_attr( $field['id'] ) . '][]" value="' . esc_attr( $value[1] ) . '"><span class="modula_input_suffix">px</span>';
		$html .= '<span class="dashicons dashicons-smartphone"></span><input type="number" class="responsive-input" name="modula-settings[' . esc_attr( $field['id'] ) . '][]"  value="' . esc_attr( $value [2] ) . '"><span class="modula_input_suffix">px</span>';

		return $html;
	}

	/**
	 *  Backwards compatibility for responsie play button size fields
	 *
	 * @since 1.0.6
	 */
	public function backward_compatibility_responsive_video_icon( $value, $key, $settings ) {

		if ( 'play-icon-size' === $key && ! isset( $settings['play-icon-size'] ) ) {
			if ( isset( $settings['video-icon-size'] ) ) {
				$size = str_replace( array( 'px', '%' ), '', $settings['video-icon-size'] );
				return array( $size, $size, $size );
			}
		}

		return $value;
	}

	/**
	 *  Backwards compatibility for responsie play button size fields
	 *
	 * @since 1.0.6
	 */
	public function backward_compatibility_backbone_responsive_video_icon( $settings ) {

		if ( isset( $settings['video-icon-size'] ) && ! isset( $settings['play-icon-size'][0] ) ) {
			$settings['play-icon-size'][0] = str_replace( array( 'px', '%' ), '', $settings['video-icon-size'] );
		}

		if ( isset( $settings['video-icon-size'] ) && ! isset( $settings['play-icon-size'][1] ) ) {
			$settings['play-icon-size'][1] = str_replace( array( 'px', '%' ), '', $settings['video-icon-size'] );
		}

		if ( isset( $settings['video-icon-size'] ) && ! isset( $settings['play-icon-size'][2] ) ) {
			$settings['play-icon-size'][2] = str_replace( array( 'px', '%' ), '', $settings['video-icon-size'] );
		}

		return $settings;
	}

	/***
	 * Add video_icon_upload field type
	 *
	 * @param $html
	 * @param $field
	 * @param $value
	 *
	 * @return string
	 */
	public function video_icon_upload_field_type( $html, $field, $value ) {

		$style = array(
			'upload'  => '',
			'replace' => 'display:none;',
			'delete'  => 'display:none;',
		);

		if ( 0 !== absint( $value ) ) {
			$style['upload']  = 'display:none;';
			$style['replace'] = '';
			$style['delete']  = '';
		}
		$image = '';
		if ( $value ) {
			$image = wp_get_attachment_image_src( $value );
		}

		$html  = '<input type="hidden" name="modula-settings[' . esc_attr( $field['id'] ) . ']" id="' . esc_attr( $field['id'] ) . '" value="' . absint( $value ) . '" data-img-src="' . ( ( ! empty( $image ) && isset( $image[0] ) ) ? esc_url( $image[0] ) : '' ) . '">';
		$html .= '<div class="modula_custom_video_icon_preview">';
		if ( $image ) {
			$html .= '<img src="' . esc_url( $image[0] ) . '" id="modula_custom_video_icon_preview">';
		}
		$html .= '</div>';
		$html .= '<input type="button" style="' . esc_attr( $style['upload'] ) . '" class="button button-primary" id="upload_video_icon" value="' . esc_attr__( 'Upload', 'modula-pro' ) . '">';
		$html .= '<input type="button" style="' . esc_attr( $style['replace'] ) . '" class="button button-primary" id="replace_video_icon" value="' . esc_attr__( 'Replace', 'modula-pro' ) . '">';
		$html .= '<input type="button" style="' . esc_attr( $style['delete'] ) . '" class="button" id="delete_video_icon" value="' . esc_attr__( 'Delete', 'modula-pro' ) . '">';

		return $html;
	}

	/**
	 * Add script that will handle video related actions in backend.
	 *
	 * @since 1.0.0
	 *
	 */
	public function video_js() {
		$screen = get_current_screen();
		if ( ! $screen || 'modula-gallery' !== $screen->post_type ) {
			return;
		}

		wp_enqueue_script( 'modula-video', \MODULA_PRO_URL . 'includes/extensions/video/assets/js/wp-modula-video.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-video-metabox', \MODULA_PRO_URL . 'includes/extensions/video/assets/js/wp-modula-video-metabox.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
		wp_add_inline_script(
			'modula-video-metabox',
			'const modula_video_ajax = ' . wp_json_encode(
				array(
					'nonce'   => wp_create_nonce( 'modula_video_nonce' ),
					'ajaxurl' => admin_url( 'admin-ajax.php' ),
				)
			) . ';',
			'before'
		);
		wp_enqueue_script( 'modula-video-modal', \MODULA_PRO_URL . 'includes/extensions/video/assets/js/wp-modula-video-modal.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
	}

	/**
	 * Displays the play icon in admin edit metabox video item.
	 *
	 * @since 1.1.0
	 */
	public function backend_show_video_icon() {

		?>
		<# if ( 'video_url' in data && data.video_url != '' && 'video_img_icon' in data && data.video_img_icon ) { #> 
		<?php

			echo '<div class="modula-video-icon">
                    <img class="img_icon" src="{{data.video_img_icon}}" />
                </div>';

		?>
		<# }else if( 'video_url' in data && data.video_url != '' && 'video_svg_icon' in data && data.video_svg_icon ){ #> 
		<?php
			echo '<div class="modula-video-icon">
                    <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" data-prefix="far" data-icon="play-circle" class="svg-inline--fa fa-play-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="{{data.video_icon_color}}" d="{{data.video_svg_icon}}"></path></svg>
                </div>';
		?>
		<# } #> 
		<?php
	}

	/**
	 * Displays the play icon select field in the settings
	 *
	 * @since 1.1.0
	 */
	public function select_play_icon_field_type( $html, $field, $value ) {
		$html = '<select id="' . esc_attr( $field['id'] ) . '" name="modula-settings[' . esc_attr( $field['id'] ) . ']" data-setting="' . esc_attr( $field['id'] ) . '">';

		foreach ( $field['values'] as $key => $option ) {
			$html .=
				'<option value="' . esc_attr( $key ) . '" data-icon="' . esc_attr( $option['svg_data'] ) . '" ' . selected( $key, $value, false ) . '>' . esc_html( $option['name'] ) . '</option>';
		}

		$html .= '</select>';

		return $html;
	}


	/**
	 * Adds the add video button to edit metabox
	 *
	 * @since 1.1.0
	 *
	 */
	public function add_video_media_button() {
		$vimeo_auth  = Vimeo_Auth::get_instance();
		$vtoken      = $vimeo_auth->get_access_token();
		$google_auth = Google_Auth::get_instance();
		$ytoken      = $google_auth->get_access_token();

		echo '<div id="modula-video-media-input-box" style="display:none;">';
			echo '<label for="modula-video-media-input">' . esc_html__( 'Insert self hosted, YouTube or Vimeo video URL.', 'modula-pro' ) . '</label>';
			echo '<div id="modula-video-media-input-wrap">';
				echo '<input type="text" id="modula-video-media-input">';
				echo '<button class="button button-primary"id="modula-video-media-input-run">' . esc_html__( 'Add', 'modula-pro' ) . '</button>';
			echo '</div>';
		echo '</div>';

		echo '<div id="modula-video-media-playlist-box" style="display:none;">';
		if ( ! $vtoken && ! $ytoken ) {
			echo '<div>';
			/* translators: 1: opening anchor tag, 2: closing anchor tag */
			printf( esc_html__( 'You need to connect your Google or Vimeo accounts %1$shere%2$s to use the playlist functionality', 'modula-pro' ), '<a target="_BLANK" href="' . esc_url( admin_url( '/edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media' ) ) . '">', '</a>' );
			echo '</div>';
		} else {
			echo '<label for="modula-video-media-playlist">' . esc_html__( 'Insert a YouTube playlist, Vimeo channel, or public Showcase URL. For Showcases, connect the Vimeo account that owns the collection.', 'modula-pro' ) . '</label>';
			echo '<div id="modula-video-media-playlist-wrap">';
				echo '<input type="text" id="modula-video-media-playlist">';
				echo '<button class="button button-primary"id="modula-video-media-playlist-run">' . esc_html__( 'Add', 'modula-pro' ) . '</button>';
			echo '</div>';
		}
		echo '</div>';
	}

	/**
	 * Adds the add video button to edit metabox
	 *
	 * @since 1.1.0
	 *
	 */
	public function add_video_media_option() {
		echo '<li id="modula-video-insert-template">' . esc_html__( 'Video', 'modula-pro' ) . '</li>';
		echo '<li id="modula-playlist-insert-template">' . esc_html__( 'Video Playlist', 'modula-pro' ) . '</li>';
	}

	/**
	 * Replicates Modula Lite functionality to add images for admin edit metabox
	 * BUT also includes the video template type metabox
	 *
	 * @since 1.1.0
	 *
	 */
	public function also_display_video_template_to_metabox( $modula_helper ) {
		global $id, $post;

		// Reset images array to empty
		$modula_helper['items'] = array();
		// Set the post_id
		$post_id = isset( $post->ID ) ? $post->ID : (int) $id;

		// Get all items from current gallery.
		$images = get_post_meta( $post_id, 'modula-images', true );

		if ( is_array( $images ) && ! empty( $images ) ) {
			foreach ( $images as $image ) {
				if ( is_numeric( $image['id'] ) && 'attachment' === get_post_type( $image['id'] ) ) {
					$attachment = wp_prepare_attachment_for_js( $image['id'] );
					$image_url  = wp_get_attachment_image_src( $image['id'], 'large' );
					$image_full = wp_get_attachment_image_src( $image['id'], 'full' );

					$image['full']            = $image_full[0];
					$image['thumbnail']       = $image_url[0];
					$image['orientation']     = ( isset( $attachment['orientation'] ) ) ? $attachment['orientation'] : '';
					$image['alt']             = get_post_meta( $image['id'], '_wp_attachment_image_alt', true );
					$image['title']           = get_the_title( $image['id'] );
					$image['caption']         = get_post_field( 'post_excerpt', $image['id'] );
					$image['description']     = get_post_field( 'post_excerpt', $image['id'] );
					$modula_helper['items'][] = apply_filters( 'modula_image_properties', $image );
				}

				if ( isset( $image['video_template'] ) && '1' === $image['video_template'] ) {
					if ( ! isset( $image['video_thumbnail'] ) || '' === $image['video_thumbnail'] ) {
						if ( isset( $image['video_url'] ) && '' !== $image['video_url'] ) {
							$img = Video::get_video_snap( $image['video_url'] );
						} else {
							$img = Video::get_video_snap();
						}

						if ( is_array( $img ) ) {
							if ( ! empty( $img['title'] ) ) {
								$image['title'] = $img['title'];
							}
							if ( ! empty( $img['thumb'] ) ) {
								$image['full']      = $img['thumb'];
								$image['thumbnail'] = $img['thumb'];
							}
						}
					} else {
						$image['full']      = $image['video_thumbnail'];
						$image['thumbnail'] = $image['video_thumbnail'];
					}

					$image['orientation'] = '';

					if ( function_exists( 'modula_repair_video_custom_grid_spans' ) ) {
						$image = modula_repair_video_custom_grid_spans( $image );
					}

					$modula_helper['items'][] = $image;
				}
			}
		}

		return $modula_helper;
	}

	/**
	 * Ajax callback function to get the thumbnail or snapshot of video.
	 *
	 * @since 1.1.0
	 */
	public function get_snap() {

		check_ajax_referer( 'modula_video_nonce', '_ajax_nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( esc_html__( 'You are not allowed to access video snapshots.', 'modula-pro' ), 403 );
		}

		$attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		$video_url     = isset( $_POST['video_url'] ) ? sanitize_url( wp_unslash( $_POST['video_url'] ) ) : '';

		if ( $attachment_id > 0 ) {
			if ( ! current_user_can( 'read_post', $attachment_id ) ) {
				wp_send_json_error( esc_html__( 'You are not allowed to access this attachment.', 'modula-pro' ), 403 );
			}
			$snap = Video::get_video_snap_from_attachment( $attachment_id );
		} elseif ( '' !== $video_url ) {
			$snap = Video::get_video_snap( $video_url );
		} else {
			wp_send_json_error( 'No video url given.' );
		}

		if ( is_array( $snap ) && ! empty( $snap ) ) {
			wp_send_json_success( $snap );
		} else {
			wp_send_json_error( esc_html__( 'The URL entered is malformed or no videos could be found.', 'modula-pro' ) );
		}
	}

	/**
	 * Ajax callback function to get the thumbnail or snapshot of video.
	 *
	 * @since 1.1.0
	 */
	public function get_playlist_snap() {

		check_ajax_referer( 'modula_video_nonce', '_ajax_nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( esc_html__( 'You are not allowed to access video snapshots.', 'modula-pro' ), 403 );
		}

		if ( ! isset( $_POST['playlist_url'] ) || '' === $_POST['playlist_url'] ) {
			wp_send_json_error( 'No video url given.' );
		}

		$snap = Video::get_video_playlist_snap( sanitize_url( wp_unslash( $_POST['playlist_url'] ) ) );

		if ( is_array( $snap ) && ! isset( $snap['error'] ) ) {
			wp_send_json_success( $snap );
		} elseif ( isset( $snap['error'] ) ) {
				wp_send_json_error( $snap['error'] );
		} else {
			wp_send_json_error( esc_html__( 'The YouTube playlist, Vimeo channel, or public Showcase URL entered is malformed or no videos could be found.', 'modula-pro' ) );
		}
	}

	/**
	 * @param $tabs
	 *
	 * @return mixed
	 *
	 * Add Modula Video oauth settings tab
	 */
	public function add_settings_tab( $tabs ) {
		$tabs['video'] = array(
			'label'    => esc_html__( 'Video', 'modula-pro' ),
			'priority' => 125,
		);

		return $tabs;
	}

	/**
	 * @param $tabs
	 *
	 * @return mixed
	 *
	 * Add Modula Video oauth subnav settings in tab
	 */
	public function integrations_navigation() {
		$subtabs = apply_filters(
			'modula_video_integrations_subtabs',
			array(
				array(
					'title' => __( 'Youtube', 'modula-pro' ),
					'slug'  => 'yt',
					'url'   => admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=yt' ),
				),
				array(
					'title' => __( 'Vimeo', 'modula-pro' ),
					'slug'  => 'vi',
					'url'   => admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=vi' ),
				),
			)
		);

		$current = isset( $_GET['sub'] ) ? sanitize_text_field( wp_unslash( $_GET['sub'] ) ) : 'yt';
		?>
		<div class="modula-subtab-navigation wp-clearfix wrap">
			<ul class="subsubsub">
				<?php foreach ( $subtabs as $subtab ) : ?>
					<li><a href="<?php echo esc_url( $subtab['url'] ); ?>" <?php echo $current === $subtab['slug'] ? 'class="current"' : ''; ?> ><?php echo esc_html( $subtab['title'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}


	public function modula_video_integrations_scripts() {
		if ( isset( $_GET['page'] ) && isset( $_GET['modula-tab'] ) && 'modula' === $_GET['page'] && 'video' === $_GET['modula-tab'] ) {
			wp_enqueue_script( 'modula-video-oauth', \MODULA_PRO_URL . 'includes/extensions/video/assets/js/modula-video-oauth.js', array( 'jquery' ), \MODULA_PRO_VERSION, true );
			wp_enqueue_style( 'modula-video-admin', \MODULA_PRO_URL . 'includes/extensions/video/assets/css/modula-video-admin.css' );
		}
	}


	/**
	 * Add Modula Video fields and type
	 *
	 * @param $fields
	 * @return mixed
	 */
	public function modula_video_gallery_type( $fields ) {

		// Add new Gallery type
		if ( isset( $fields['general']['type']['disabled'] ) && isset( $fields['general']['type']['disabled']['values'] ) && isset( $fields['general']['type']['disabled']['values']['video'] ) ) {
			unset( $fields['general']['type']['disabled']['values']['video'] );
		}
		$fields['general']['type']['values']['video'] = esc_html__( 'Video', 'modula-pro' );

		// Add slider fields
		$slider_fields = array();

		$slider_responsive_fields = array();

		$slider_lightbox_fields['video_lightbox'] = array();

		return $fields;
	}
}
