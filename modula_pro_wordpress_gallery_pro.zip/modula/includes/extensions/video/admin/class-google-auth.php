<?php

namespace Modula_Pro\Extensions\Video\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Google Auth
 *
 * @since 1.0.2
 */
class Google_Auth {

	/**
	 * The single instance of the class.
	 *
	 * @var Google_Auth
	 *
	 * @since 1.0.2
	 */
	public static $instance;

	/**
	 * Access token key.
	 *
	 * @var string
	 *
	 * @since 1.0.2
	 */
	public static $access_token = 'modula_video_google_access_token';

	/**
	 * Refresh token key.
	 *
	 * @var string
	 *
	 * @since 1.0.2
	 */
	public static $refresh_token = 'modula_video_google_refresh_token';

	/**
	 * Expiry date key.
	 *
	 * @var string
	 *
	 * @since 1.0.2
	 */
	public static $expiry_date = 'modula_video_google_expiry_date';

	/**
	 * Google_Auth constructor.
	 *
	 * @since 1.0.2
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'save_request_response' ) );
		add_action( 'modula_admin_tab_video', array( $this, 'google_token_field' ), 20 );
	}

	/**
	 * Get the single instance of the class.
	 *
	 * @return Google_Auth
	 * @since 1.0.2
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Google_Auth ) ) {
			self::$instance = new Google_Auth();
		}

		return self::$instance;
	}

	/**
	 * Render settings tab
	 */
	public function render_settings_tab() {

		include 'tabs/roles.php';
	}

	/**
	 * Get the access token.
	 *
	 * @since 1.0.2
	 */
	public function get_access_token() {
		return get_option( self::$access_token, false );
	}

	/**
	 * Save access token.
	 *
	 * @param  string  $access_token  Access token.
	 *
	 * @since 1.0.2
	 */
	public function save_access_token( $access_token ) {
		update_option( self::$access_token, $access_token );
	}

	/**
	 * Get the refresh token.
	 *
	 * @param  string  $refresh_token  Refresh token.
	 *
	 * @since 1.0.2
	 */
	public function get_refresh_token() {
		return get_option( self::$refresh_token, false );
	}

	/**
	 * Save refresh token.
	 *
	 * @param  string  $refresh_token  Refresh token.
	 *
	 * @since 1.0.2
	 */
	public function save_refresh_token( $refresh_token ) {
		update_option( self::$refresh_token, $refresh_token );
	}

	/**
	 * Get the expiry date.
	 *
	 * @param  string  $expiry_date  Expiry date.
	 *
	 * @since 1.0.2
	 */
	public function get_expiry_date() {
		return get_option( self::$expiry_date, false );
	}

	/**
	 * Save expiry date.
	 *
	 * @param  string  $expiry_date  Expiry date.
	 *
	 * @since 1.0.2
	 */
	public function save_expiry_date( $expiry_date ) {
		update_option( self::$expiry_date, $expiry_date );
	}

	/**
	 * Check if token is expired.
	 *
	 * @since 1.0.2
	 */
	public function is_token_expired() {

		$expiry_date = $this->get_expiry_date();

		if ( empty( $expiry_date ) ) {
			return true;
		}

		$current_time = time();

		if ( absint( $expiry_date ) < absint( $current_time ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Make request for access token.
	 *
	 * @return string
	 * @since 1.0.2
	 */
	public function create_request_url() {
		$youtube_scope = 'https://www.googleapis.com/auth/youtube.readonly';
		$redirect_url  = admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&action=save_modula_video_ii_token' );
		// Single param so the server never sees & and can't misparse scope vs redirectUrl.
		// Server should: read "params", decode it, then split by & and then by = to get scope and redirectUrl.
		$inner_query = 'scope=' . rawurlencode( $youtube_scope ) . '&redirectUrl=' . rawurlencode( rawurlencode( $redirect_url ) );
		$auth_url    = 'https://auth.wp-modula.com/google?params=' . rawurlencode( $inner_query );
		return $auth_url;
	}

	/**
	 * Save request response.
	 *
	 * @since 1.0.2
	 */
	public function save_request_response() {
		if ( empty( $_GET['action'] ) || 'save_modula_video_ii_token' !== $_GET['action'] ) {
			return;
		}
		$access_token  = isset( $_GET['accessToken'] ) ? sanitize_text_field( wp_unslash( $_GET['accessToken'] ) ) : '';
		$refresh_token = isset( $_GET['refreshToken'] ) ? sanitize_text_field( wp_unslash( $_GET['refreshToken'] ) ) : '';
		$expiry_date   = isset( $_GET['expireDate'] ) ? sanitize_text_field( wp_unslash( $_GET['expireDate'] ) ) : '';
		$this->save_access_token( $access_token );
		$this->save_refresh_token( $refresh_token );
		// The expiry date is in milliseconds, so we need to divide it by 1000.
		$this->save_expiry_date( $expiry_date / 1000 );
		// Delete the notice in case it's still there.
		update_option( 'modula_video_gsc_connected_notice', true );

		wp_safe_redirect( admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media' ) );
	}

	/**
	 * Refresh token.
	 *
	 * @since 1.0.2
	 */
	public function refresh_token( $do_ajax = true ) {

		if ( $do_ajax ) {
			check_ajax_referer( 'modula_video_reconnect_gsc', 'nonce' );
		}

		$data = wp_json_encode(
			array(
				'refreshToken' => $this->get_refresh_token(),
			)
		);

		$url = 'https://auth.wp-modula.com/google/refresh-token';
		// Send the request.
		$response = wp_remote_post(
			$url,
			array(
				'body'      => $data,
				'timeout'   => 15,
				'sslverify' => true,
				'headers'   => array(
					'Content-Type' => 'application/json',
				),
			)
		);

		$response_code = wp_remote_retrieve_response_code( $response );
		$body          = wp_remote_retrieve_body( $response );
		$body_decoded  = is_string( $body ) ? json_decode( $body, true ) : array();

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 201 !== $response_code ) {
			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = esc_html__( 'An error occurred, please try again.', 'modula-pro' );
			}

			wp_send_json_error( $message );
			die();
		}

		// decode the license data
		$data = $body_decoded;

		if ( isset( $data['accessToken'] ) ) {
			$this->save_access_token( $data['accessToken'] );
		}
		if ( isset( $data['expiryDate'] ) ) {
			// The expiry date is in milliseconds, so we need to divide it by 1000.
			$this->save_expiry_date( $data['expiryDate'] / 1000 );
		}
		update_option( 'modula_video_gsc_connected_notice', true );
		if ( $do_ajax ) {
			wp_send_json_success( esc_html__( 'Token refreshed', 'modula-pro' ) );
		}
	}

	/**
	 * Google token field.
	 *
	 * @since 1.0.2
	 */
	public function google_token_field() {
		if ( isset( $_GET['sub'] ) && 'yt' !== $_GET['sub'] ) {
			return;
		}

		?>
		<div class="row">
			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th scope="row" style="width:300px;" valign="top">
							<h2><?php esc_html_e( 'YouTube', 'modula-pro' ); ?></h2>
						</th>
					</tr>
					<tr valign="top">
						<th scope="row" valign="top">
							<?php esc_html_e( 'Video', 'modula-pro' ); ?>
						</th>
						<td>
							<?php
							if ( ! $this->get_access_token() ) {
								echo '<a href="' . esc_url( $this->create_request_url() ) . '" class="modula-oauth-button"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" class="modula-oauth-g-logo"><g><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path><path fill="none" d="M0 0h48v48H0z"></path></g></svg><span>' . esc_html__( 'Sign in with Google', 'modula-pro' ) . '</span></a>';
							} elseif ( $this->is_token_expired() ) {
								echo '<a href="#" class="button button-primary" id="modula-video-reconnect-gsc" data-nonce="' . esc_attr( wp_create_nonce( 'modula_video_reconnect_gsc' ) ) . '" data-action="reconnect">' . esc_html__( 'Refresh token', 'modula-pro' ) . '</a>';
								echo '&nbsp;<a href="#" class="button button-primary" id="modula-video-disconnect-gsc" data-nonce="' . esc_attr( wp_create_nonce( 'modula_video_reconnect_gsc' ) ) . '" data-action="disconnect">' . esc_html__( 'Disconnect', 'modula-pro' ) . '</a>';
							} else {
								echo '<a href="#" class="button button-secondary" style="pointer-events: none;">' . esc_html__( 'Connected to Google', 'modula-pro' ) . '</a>';
								echo '&nbsp;<a href="#" class="button button-primary" id="modula-video-disconnect-gsc" data-nonce="' . esc_attr( wp_create_nonce( 'modula_video_reconnect_gsc' ) ) . '" data-action="disconnect">' . esc_html__( 'Disconnect', 'modula-pro' ) . '</a>';
							}
							?>
							<p class="description">
								<?php
								// translators: %s placeholders are for the opening and closing anchor tags.
								printf( esc_html__( 'If you need step by step instructions on how to connect your account, please read our online %1$sknowledgebase article%2$s on this topic.', 'modula-pro' ), '<a href="https://wp-modula.com/kb/how-to-connect-modula-to-youtube-and-add-video-playlists-to-your-galleries/" target="_blank">', '</a>' );
								?>
							</p>
						</td>					
					</tr>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Disconnect GSC.
	 *
	 * @since 1.0.2
	 */
	public function disconnect_gsc() {
		check_ajax_referer( 'modula_video_reconnect_gsc', 'nonce' );
		delete_option( self::$access_token );
		delete_option( self::$refresh_token );
		delete_option( self::$expiry_date );
		wp_send_json_success( esc_html__( 'Disconnected', 'modula-pro' ) );
	}
}
