<?php
namespace Modula_Pro\Extensions\Video\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WPChill\Modula_Pro\Vendor\GuzzleHttp\Client;

/**
 * Vimeo Auth
 *
 * @since 1.0.2
 */
class Vimeo_Auth {

	/**
	 * The single instance of the class.
	 *
	 * @var Vimeo_Auth
	 *
	 * @since 1.0.2
	 */
	public static $instance;

	/**
	 * Access token key.
	 *
	 * @var string
	 *
	 * @since 1.0.2
	 */
	public static $access_token = 'modula_video_vimeo_access_token';

	/**
	 * Refresh token key.
	 *
	 * @var string
	 *
	 * @since 1.0.2
	 */
	public static $refresh_token = 'modula_video_vimeo_refresh_token';

	/**
	 * Expiry date key.
	 *
	 * @var string
	 *
	 * @since 1.0.2
	 */
	public static $expiry_date = 'modula_video_vimeo_expiry_date';

	/**
	 * modula_video_Vimeo_Auth constructor.
	 *
	 * @since 1.0.2
	 */
	public function __construct() {

		add_action( 'admin_init', array( $this, 'save_request_response' ) );
		add_action( 'admin_init', array( $this, 'save_request_request' ) );
		add_action( 'admin_init', array( $this, 'disconnect_request_request' ) );
		add_action( 'modula_admin_tab_video', array( $this, 'google_token_field' ) );
		add_action( 'wp_ajax_modula_video_reconnect_gsc', array( $this, 'refresh_token' ) );
		add_action( 'wp_ajax_modula_video_disconnect_gsc', array( $this, 'disconnect_gsc' ) );
	}

	/**
	 * Get the single instance of the class.
	 *
	 * @return Vimeo_Auth
	 * @since 1.0.2
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Vimeo_Auth ) ) {
			self::$instance = new Vimeo_Auth();
		}

		return self::$instance;
	}

	/**
	 * Get the access token.
	 *
	 * @since 1.0.2
	 */
	public function get_access_token() {
		return get_option( self::$access_token, false );
	}

	/**
	 * Save access token.
	 *
	 * @param  string  $access_token  Access token.
	 *
	 * @since 1.0.2
	 */
	public function save_access_token( $access_token ) {
		update_option( self::$access_token, $access_token );
	}

	/**
	 * Make request for access token.
	 *
	 * @return string
	 * @since 1.0.2
	 */
	public function create_request_url() {

		$redirect_uri = admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=vi&action=save_modula_video_vimeo_token' );

		// Make the URL for the request.
		return 'https://api.vimeo.com/integrations/authorize?response_type=code&client_id=$clientId&redirect_uri=' . $redirect_uri . '&scope=public';
	}

	/**
	 * Save request response.
	 *
	 * @since 1.0.2
	 */
	public function save_request_response() {

		if ( empty( $_GET['action'] ) || 'save_modula_video_vimeo_token' !== $_GET['action'] ) {
			return;
		}
		$vimeo_creds   = get_option( 'modula_video_vimeo_creds', array() );
		$client_id     = $vimeo_creds['client_id'];
		$client_secret = $vimeo_creds['client_secret'];
		$access_code   = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		$redirect_uri  = admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=vi&action=save_modula_video_vimeo_token' );

		if ( ! empty( $access_code ) ) {
			// Exchange the authorization code for an access token
			$client   = new Client();
			$response = $client->post(
				'https://api.vimeo.com/oauth/access_token',
				array(
					'form_params' => array(
						'grant_type'    => 'authorization_code',
						'code'          => $access_code,
						'redirect_uri'  => $redirect_uri,
						'client_id'     => $client_id,
						'client_secret' => $client_secret,
					),
				)
			);

			$data = json_decode( (string) $response->getBody(), true );

			// Extract the OAuth access token
			$access_token = $data['access_token'];

			$this->save_access_token( $access_token );
		}
		wp_safe_redirect( admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=vi' ) );
	}

	/**
	 * Save request request.
	 *
	 * @since 1.0.2
	 */
	public function save_request_request() {
		//phpcs:disable WordPress.Security
		if ( ! isset( $_POST['nonce_vimeo'] ) || ! wp_verify_nonce( $_POST['nonce_vimeo'], 'nonce_vimeo' ) ) {
			return;
		}

		if ( empty( $_POST['request_vimeo'] ) || 'request_vimeo' !== $_POST['request_vimeo'] ) {
			return;
		}

		if ( isset( $_POST['vimeo_creds'] ) ) {
			if ( isset( $_POST['vimeo_creds']['client_id'] ) && isset( $_POST['vimeo_creds']['client_secret'] ) && '' != $_POST['vimeo_creds']['client_id'] && '' != $_POST['vimeo_creds']['client_secret'] ) {
				$client = $_POST['vimeo_creds']['client_id'];
				update_option( 'modula_video_vimeo_creds', array_map( 'sanitize_text_field', $_POST['vimeo_creds'] ) );

				$redirect_uri = admin_url( '/edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media&sub=vi&action=save_modula_video_vimeo_token' );
				// Make the URL for the request.
				wp_redirect( 'https://api.vimeo.com/oauth/authorize?response_type=code&client_id=' . $client . '&redirect_uri=' . urlencode( $redirect_uri ) . '&scope=public' );
				die();
			}
		}
		wp_safe_redirect( admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=vi' ) );
		die();
	}

	/**
	 * Save request request.
	 *
	 * @since 1.0.2
	 */
	public function disconnect_request_request() {

		if ( ! isset( $_POST['nonce_vimeo'] ) || ! wp_verify_nonce( $_POST['nonce_vimeo'], 'nonce_vimeo' ) ) {
			return;
		}

		if ( empty( $_POST['request_vimeo'] ) || 'disconnect_vimeo' !== $_POST['request_vimeo'] ) {
			return;
		}
		delete_option( self::$access_token );

		wp_safe_redirect( admin_url( '/edit.php?post_type=modula-gallery&page=modula&tab=social_media&sub=vi' ) );
		die();
	}

	/**
	 * Vimeo token field.
	 *
	 * @since 1.0.2
	 */
	public function google_token_field() {

		if ( ! isset( $_GET['sub'] ) || ( isset( $_GET['sub'] ) && 'vi' !== $_GET['sub'] ) ) {
			return;
		}

		$vimeo_creds = get_option( 'modula_video_vimeo_creds', array() );
		?>
		<form method="post" autocomplete="off" action="<?php echo esc_url( admin_url( '/edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media&sub=vi' ) ); ?>">
			<div class="row">
				<table class="form-table">
					<tbody>
						<tr valign="top">
							<th scope="row" style="width:300px;" valign="top">
								<h2><?php esc_html_e( 'Vimeo', 'modula-pro' ); ?></h2>
							</th>
						</tr>
						<tr valign="top">
							<th scope="row" valign="top">
								<?php esc_html_e( 'Vimeo Client ID', 'modula-pro' ); ?>
							</th>
							<td>
								<input style="width: 320px;" type="text" autocomplete="off" name="vimeo_creds[client_id]" value="<?php echo isset( $vimeo_creds['client_id'] ) ? esc_attr( $vimeo_creds['client_id'] ) : ''; ?>"/>
							</td>
						</tr>
						<tr valign="top">
							<th scope="row" valign="top">
								<?php esc_html_e( 'Vimeo Client Secret', 'modula-pro' ); ?>
							</th>
							<td>
								<input style="width: 320px;" type="password" autocomplete="off" name="vimeo_creds[client_secret]" value="<?php echo isset( $vimeo_creds['client_secret'] ) ? esc_attr( $vimeo_creds['client_secret'] ) : ''; ?>"/>
							</td>
						</tr>
						<tr valign="top">
							<th scope="row" valign="top">
								<?php esc_html_e( 'Vimeo RedirectURI', 'modula-pro' ); ?>
							</th>
							<td>
								<input style="width: 320px;" readonly="readonly" type="text" autocomplete="off" value="<?php echo esc_url( admin_url( '/edit.php?post_type=modula-gallery&page=modula&modula-tab=social_media&sub=vi&action=save_modula_video_vimeo_token' ) ); ?>"/>
								<p class="description">
									<?php
									// translators: %s placeholders are for the opening and closing anchor tags.
									printf( esc_html__( 'If you need step by step instructions on how to connect your account, please read our online %1$sknowledgebase article%2$s on this topic.', 'modula-pro' ), '<a href="https://wp-modula.com/kb/how-to-connect-modula-to-vimeo-and-add-video-playlists-to-your-galleries/" target="_blank">', '</a>' );
									?>
								</p>
							</td>					
						</tr>
						<tr valign="top">
							<td colspan="2">
								<?php
								if ( ! $this->get_access_token() ) {
									echo '<input type="hidden" name="request_vimeo" value="request_vimeo" />';
									echo '<input type="submit" class="button button-primary" value="' . esc_html__( 'Connect to Vimeo', 'modula-pro' ) . '" />';
								} else {
									echo '<a href="#" class="button button-secondary" style="pointer-events: none;">' . esc_html__( 'Connected to Vimeo', 'modula-pro' ) . '</a>';
									echo '<input type="hidden" name="request_vimeo" value="disconnect_vimeo" />';
									echo '&nbsp;<input type="submit" class="button button-primary" value="' . esc_html__( 'Disconnect from Vimeo', 'modula-pro' ) . '" />';
								}
									// Nonce
									echo '<input type="hidden" name="nonce_vimeo" value="' . esc_attr( wp_create_nonce( 'nonce_vimeo' ) ) . '" />';
								?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</form>
		<?php
	}
}
