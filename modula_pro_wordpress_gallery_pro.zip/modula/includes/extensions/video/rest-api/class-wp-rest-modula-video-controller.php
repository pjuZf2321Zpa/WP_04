<?php
/**
 * REST API for video snap / playlist snap (v2 settings editor).
 *
 * @package Modula_Pro\Extensions\Video
 */

namespace Modula_Pro\Extensions\Video\Rest_API;

use Modula_Pro\Extensions\Video\Video;

defined( 'ABSPATH' ) || exit;

/**
 * Class WP_Rest_Modula_Video_Controller
 */
class WP_Rest_Modula_Video_Controller {

	/**
	 * @var string
	 */
	public $namespace = 'modula-video/v1';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/snap',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_snap' ),
					'permission_callback' => array( $this, 'check_upload_files' ),
					'args'                => array(
						'video_url'     => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_url',
						),
						'attachment_id' => array(
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/playlist-snap',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_playlist_snap' ),
					'permission_callback' => array( $this, 'check_upload_files' ),
					'args'                => array(
						'playlist_url' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_url',
						),
					),
				),
			)
		);
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public function check_upload_files( $request ) {
		unset( $request );

		if ( ! current_user_can( 'upload_files' ) ) {
			return new \WP_Error(
				'modula_video_forbidden',
				esc_html__( 'You are not allowed to access video snapshots.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Resolve a single video thumbnail / metadata snap.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_snap( $request ) {
		$attachment_id = absint( $request->get_param( 'attachment_id' ) );
		$video_url     = (string) $request->get_param( 'video_url' );

		if ( $attachment_id > 0 ) {
			if ( ! current_user_can( 'read_post', $attachment_id ) ) {
				return new \WP_Error(
					'modula_video_attachment_forbidden',
					esc_html__( 'You are not allowed to access this attachment.', 'modula-pro' ),
					array( 'status' => 403 )
				);
			}
			$snap = Video::get_video_snap_from_attachment( $attachment_id );
		} elseif ( '' !== $video_url ) {
			$snap = Video::get_video_snap( $video_url );
		} else {
			return new \WP_Error(
				'modula_video_missing_url',
				esc_html__( 'No video url given.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( is_array( $snap ) && ! empty( $snap ) ) {
			return new \WP_REST_Response( $snap, 200 );
		}

		return new \WP_Error(
			'modula_video_snap_not_found',
			esc_html__( 'The URL entered is malformed or no videos could be found.', 'modula-pro' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Resolve playlist / channel video snaps.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_playlist_snap( $request ) {
		$playlist_url = (string) $request->get_param( 'playlist_url' );

		if ( '' === $playlist_url ) {
			return new \WP_Error(
				'modula_video_missing_url',
				esc_html__( 'No video url given.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$snap = Video::get_video_playlist_snap( $playlist_url );

		if ( is_array( $snap ) && isset( $snap['error'] ) ) {
			$message = is_string( $snap['error'] ) ? $snap['error'] : '';
			return new \WP_Error(
				'modula_video_playlist_error',
				$message ? $message : esc_html__( 'The YouTube playlist, Vimeo channel, or public Showcase URL entered is malformed or no videos could be found.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( is_array( $snap ) ) {
			return new \WP_REST_Response( $snap, 200 );
		}

		return new \WP_Error(
			'modula_video_playlist_not_found',
			esc_html__( 'The YouTube playlist, Vimeo channel, or public Showcase URL entered is malformed or no videos could be found.', 'modula-pro' ),
			array( 'status' => 400 )
		);
	}
}
