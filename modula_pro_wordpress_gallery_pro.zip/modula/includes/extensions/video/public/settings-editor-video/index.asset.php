<?php return array('dependencies' => array('wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '959116ba3a4850a91ae5');
