class YoutubeVideoElement extends HTMLElement {
	paused = true;
	ytPlayerContainer = undefined;

	ytPlayerPromise = false;

	ytPlayer = false;

	initialized = false;
	constructor() {
		super();
		this.options = {
			autoplay: 0,
			controls: 0,
			mute: 1,
			playsinline: 1,
			showinfo: 0,
			origin: window.location.origin,
		};
	}

	connectedCallback() {
		this.ytPlayerContainer = this.createYTPlayerElement();
		this.appendChild( this.ytPlayerContainer );
		this.ytPlayerContainer.style.display = 'block'; // to adhere to shape of youtube's generated iframe
	}

	createYTPlayerElement() {
		return document.createElement( 'div' );
	}

	async init() {
		this.ytPlayer = await this.buildPlayer();
		this.initialized = true;
		return this.ytPlayer;
	}

	load() {
		if ( this.initialized ) {
			this.ytPlayer.seekTo( 0 );
		}
	}

	async play() {
		this.paused = false;
		if ( this.initialized ) {
			this.ytPlayer.playVideo();
		} else {
			await this.init();
			this.ytPlayer.playVideo();
		}
	}
	pause() {
		if ( this.initialized ) {
			this.ytPlayer.stopVideo();
		}
	}

	onPlay() {
		this.paused = false;
	}

	onPause() {
		this.paused = true;
	}

	onEnd() {
		this.paused = true;
	}

	get videoid() {
		return this.getAttribute( 'video_id' );
	}

	_onYTApiStateChange( obj ) {
		const stateMap = {
			'-1': 'unstarted',
			0: 'ended',
			1: 'playing',
			2: 'pause',
			3: 'buffering',
			5: 'cued',
		};
		const state = stateMap[ obj.data.toString() ];
		// trigger our internal event handling method
		// whenever the youtube api player triggers an event
		const eventMethodMap = {
			ended: this.onEnd,
			pause: this.onPause,
			playing: this.onPlay,
		};
		if ( eventMethodMap[ state ] ) {
			const method = eventMethodMap[ state ];
			if ( method ) {
				method.call( this );
				// TODO: trigger 'play' MediaEvent if the video has been paused at least once
				this.dispatchEvent( new CustomEvent( state ) );
			}
		}
	}

	buildPlayer() {
		if ( this.ytPlayerPromise ) {
			return this.ytPlayerPromise;
		}
		this.ytPlayerPromise = new Promise( ( resolve ) => {
			const playerOptions = {
				playerVars: this.options,
				videoId: this.videoid,
				events: {
					onError: () => {
						this.error = new Error( 'player could not be built' );
					},
					onReady: ( e ) => {
						this.dispatchEvent( new CustomEvent( 'loadstart' ) );
						this.dispatchEvent( new CustomEvent( 'canplay' ) );
						this.resolveBuildPlayerPromise = resolve;
						resolve( e.target );
					},
					onStateChange: ( obj ) => this._onYTApiStateChange( obj ),
				},
			};
			this.ytPlayer = new YT.Player(
				this.ytPlayerContainer,
				playerOptions
			);
		} );
		return this.ytPlayerPromise;
	}
}
customElements.define( 'youtube-video', YoutubeVideoElement );
