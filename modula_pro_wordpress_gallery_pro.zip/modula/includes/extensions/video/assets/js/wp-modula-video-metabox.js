wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;
wp.Modula.videoModalChildViews =
	'undefined' === typeof wp.Modula.modalChildViews
		? []
		: wp.Modula.modalChildViews;
( function ( $, modula ) {
	const uploadHandler = Backbone.Model.extend( {
		initialize() {
			const self = this;

			// Open video input dropdown
			$( '#modula-video-insert-template' ).click( function ( e ) {
				e.preventDefault();
				$( '#modula-video-media-input-box' ).show();
			} );

			// Open video playlist input dropdown
			$( '#modula-playlist-insert-template' ).click( function ( e ) {
				e.preventDefault();
				$( '#modula-video-media-playlist-box' ).show();
			} );

			// Hides video input dropdown on "Add New" click.
			$( '#modula_gallery_add_action_button' ).click( function ( e ) {
				e.preventDefault();
				$( '#modula-video-media-input-box' ).hide();
				$( '#modula-video-media-playlist-box' ).hide();
			} );

			// Open WordPress Media Gallery
			$( '#modula-video-media-input-run' ).click( function ( e ) {
				e.preventDefault();
				const wrap = $( this ).parent().parent(),
					URL = wrap.find( '#modula-video-media-input' ).val();

				self.startSpinner( wrap );
				wrap.find( '.modula_video_bad_url' ).remove();
				const debouncedProcess = self.debounce( () => {
					self.processVideoBox( URL, wrap );
				}, 500 );

				debouncedProcess(); // Apply debounce to avoid rapid triggering
			} );

			// Open WordPress Media Gallery
			$( '#modula-video-media-playlist-run' ).click( function ( e ) {
				e.preventDefault();
				const wrap = $( this ).parent().parent(),
					playlist = wrap
						.find( '#modula-video-media-playlist' )
						.val();

				self.startSpinner( wrap );
				wrap.find( '.modula_video_bad_url' ).remove();
				const debouncedProcess = self.debounce( () => {
					self.processVideoBoxes( playlist, wrap );
				}, 500 );

				debouncedProcess(); // Apply debounce to avoid rapid triggering
			} );
		},

		// External function to process video box and perform required actions
		processVideoBox( URL, wrap ) {
			const self = this;
			this.generateVideoBox( URL )
				.then( ( videoData ) => {
					if ( ! videoData ) {
						throw new Error(
							'No data returned from generateVideoBox'
						);
					}

					// Find the last video template ID and increment
					let lastId = 0;
					modula.Items.models.forEach( ( model ) => {
						if ( model.attributes.video_template ) {
							const currentId = parseInt(
								model.id.replace( 'video_template_', '' ),
								10
							);
							if ( currentId >= lastId ) {
								lastId = currentId + 1;
							}
						}
					} );

					// Create a new model with the given data
					const newModel = new modula.items.model( {
						video_template: true,
						id: 'video_template_' + lastId,
						video_title: videoData.title,
						video_alt: videoData.alt,
						video_description: videoData.description,
						thumbnail: videoData.thumb,
						video_thumbnail: videoData.thumb,
						full: videoData.thumb,
						description: videoData.description,
						video_url: URL,
						// Custom-grid cell spans (not video pixels).
						width: 2,
						height: 2,
						video_width: videoData.width || 1920,
						video_height: videoData.height || 1080,
						autoplay_thumbnail: 'inherit',
						autoplay_lightbox: 'inherit',
						loop_video: 'inherit',
					} );

					const uploadPosition = $(
						'[name="modula-settings[upload_position]"]:checked'
					).val();

					if ( 'start' === uploadPosition ) {
						modula.Items.add( newModel, { at: 0 } );
						modula.Items.trigger( 'newItemAdded', newModel );
						modula.Items.trigger( 'collectionUpdated', newModel );
					}

					// Add the model to the VideoViews, render, and save
					newModel.get( 'view' ).render();
					modula.Save.saveImages();
					self.stopSpinner( wrap );
					wrap.hide();
					wrap.find( 'input' ).val( '' );
				} )
				.catch( ( error ) => {
					self.stopSpinner( wrap );
					wrap.append(
						'<span class="modula_video_bad_url">' +
							error +
							'</span>'
					);
					console.error( 'Failed to update video URL:', error );
				} );
		},

		generateVideoBox( URL ) {
			return new Promise( ( resolve, reject ) => {
				$.ajax( {
					url: modula_video_ajax.ajaxurl,
					type: 'POST', // POST request
					dataType: 'json',
					data: {
						video_url: URL,
						action: 'modula_video_get_snap',
						_ajax_nonce: modula_video_ajax.nonce, // Include nonce
					},
					success( data ) {
						if ( data.success ) {
							resolve( data.data ); // Resolve on success
						} else {
							reject( data.data ); // Reject if data.success is false
						}
					},
					error( jqXHR, textStatus, errorThrown ) {
						console.error(
							`AJAX error: ${ textStatus }, ${ errorThrown }`
						);
						reject( false );
					},
				} );
			} );
		},

		// External function to process video box and perform required actions
		processVideoBoxes( URL, wrap ) {
			const self = this;
			this.generateVideoBoxes( URL )
				.then( ( videoData ) => {
					if ( ! videoData ) {
						throw new Error(
							'No data returned from generateVideoBox'
						);
					}

					const uploadPosition = $(
						'[name="modula-settings[upload_position]"]:checked'
					).val();

					// Find the last video template ID and increment
					let lastId = 0;
					modula.Items.models.forEach( ( model ) => {
						if ( model.attributes.video_template ) {
							const currentId = parseInt(
								model.id.replace( 'video_template_', '' ),
								10
							);

							if ( currentId >= lastId ) {
								lastId = currentId + 1;
							}
						}
					} );
					let videos = videoData;
					// Reverse the videoData in order to output the correct order of the videos
					if ( 'start' === uploadPosition ) {
						videos = videoData.reverse();
					}
					$.each( videos, function ( index, video ) {
						// Create a new model with the given data
						const newModel = new modula.items.model( {
							video_template: true,
							id: 'video_template_' + ( lastId + index ),
							title: video.title,
							thumbnail: video.thumb,
							video_thumbnail: video.thumb,
							full: video.thumb,
							description: video.description,
							video_url: video.video_url,
							// Custom-grid cell spans (not video pixels).
							width: 2,
							height: 2,
							video_width: video.width || 1920,
							video_height: video.height || 1080,
							autoplay_thumbnail: 'inherit',
							autoplay_lightbox: 'inherit',
							loop_video: 'inherit',
						} );

						if ( 'start' === uploadPosition ) {
							modula.Items.add( newModel, { at: 0 } );
							modula.Items.trigger( 'newItemAdded', newModel );
							modula.Items.trigger(
								'collectionUpdated',
								newModel
							);
						}
						// Add the model to the VideoViews, render, and save
						newModel.get( 'view' ).render();
					} );
					modula.Save.saveImages();
					self.stopSpinner( wrap );
					wrap.hide();
					wrap.find( 'input' ).val( '' );
				} )
				.catch( ( error ) => {
					self.stopSpinner( wrap );
					wrap.append(
						'<span class="modula_video_bad_url">' +
							error +
							'</span>'
					);
					console.error( 'Failed to update video URL:', error );
				} );
		},

		generateVideoBoxes( URL ) {
			return new Promise( ( resolve, reject ) => {
				$.ajax( {
					url: modula_video_ajax.ajaxurl,
					type: 'POST', // POST request
					dataType: 'json',
					data: {
						playlist_url: URL,
						action: 'modula_video_get_playlist_snap',
						_ajax_nonce: modula_video_ajax.nonce, // Include nonce
					},
					success( data ) {
						if ( data.success ) {
							resolve( data.data ); // Resolve on success
						} else {
							reject( data.data ); // Reject if data.success is false
						}
					},
					error( jqXHR, textStatus, errorThrown ) {
						console.error(
							`AJAX error: ${ textStatus }, ${ errorThrown }`
						);
						reject( false );
					},
				} );
			} );
		},

		// Debounce utility function to avoid rapid repeated calls
		debounce( func, wait ) {
			let timeout;
			return ( ...args ) => {
				clearTimeout( timeout );
				timeout = setTimeout( () => func.apply( this, args ), wait );
			};
		},

		startSpinner( wrap ) {
			wrap.find( 'input' ).attr( 'disabled', true );
			wrap.find( 'button' ).attr( 'disabled', true );
			wrap.addClass( 'modula-spinner' );
		},

		stopSpinner( wrap ) {
			wrap.find( 'input' ).attr( 'disabled', false );
			wrap.find( 'button' ).attr( 'disabled', false );
			wrap.removeClass( 'modula-spinner' );
		},
	} );
	new uploadHandler();

	wp.Modula.views.modulaVideoView = Backbone.View.extend( {
		updateVideoUrl( model, el ) {
			const input = $( el ),
				video_url = input.val(),
				wrap = input.parent().parent();

			// set the model video url as the new one
			model.attributes.video_url = video_url;

			input.attr( 'disabled', true );
			wrap.addClass( 'modula-spinner' );

			return new Promise( ( resolve, reject ) => {
				$.ajax( {
					url: modula_video_ajax.ajaxurl,
					type: 'POST', // POST request
					dataType: 'json',
					data: {
						video_url,
						action: 'modula_video_get_snap',
						_ajax_nonce: modula_video_ajax.nonce, // Include nonce
					},
					success( data ) {
						if ( data.success ) {
							model.attributes.video_title = data.data.title;
							model.attributes.thumbnail = data.data.thumb;
							model.attributes.video_thumbnail = data.data.thumb;
							model.attributes.full = data.data.thumb;
							model.attributes.video_alt = data.data.alt || '';
							model.attributes.video_description =
								data.data.description || '';
							model.attributes.video_width =
								data.data.width || 1920;
							model.attributes.video_height =
								data.data.height || 1080;

							resolve(); // Resolve on success
						} else {
							input.removeAttr( 'disabled' );
							wrap.removeClass( 'modula-spinner' );
							reject( 'Data not successful' ); // Reject if data.success is false
						}
					},
					error( jqXHR, textStatus, errorThrown ) {
						console.error(
							`AJAX error: ${ textStatus }, ${ errorThrown }`
						);
						input.removeAttr( 'disabled' );
						wrap.removeClass( 'modula-spinner' );
						reject(
							`AJAX error: ${ textStatus }, ${ errorThrown }`
						); // Reject on AJAX error
					},
				} );
			} );
		},
	} );

	// We extend the default Modula model, overwriting the init function, so we can insert Modula Video view.
	wp.Modula.items.model = modula.items.model.extend( {
		initialize( args ) {
			// Check if wp.Modula.Items exist
			modula.Items =
				'undefined' === typeof modula.Items
					? new modula.items.collection()
					: modula.Items;

			// Add this model to items
			modula.Items.addItem( this );

			// Set collection index to this model
			this.set( 'index', modula.Items.indexOf( this ) );

			// Check if current model is video template
			if (
				'undefined' !== typeof this.attributes.video_template &&
				'1' == this.attributes.video_template
			) {
				// this is the modula video view.
				var view = new modula.items.videoView( {
					model: this,
					id: 'modula-item-' + this.get( 'id' ),
				} );
			} else {
				// this is the modula lite default view.
				var view = new modula.items.view( {
					model: this,
					id: 'modula-item-' + this.get( 'id' ),
				} );
			}

			this.set( 'view', view );

			if ( 'custom-grid' == modula.Settings.get( 'type' ) ) {
				this.set( 'resize', true );
				this.resize();
			}
		},
	} );

	// We extend the modula default items view to copy it's functionality
	// but replace the tempalte with the video item template.
	wp.Modula.items.videoView = modula.items.view.extend( {
		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-video-item' ),

		/**
		 * Events
		 * - Functions to call when specific events occur
		 */
		events: {
			'click .modula-edit-video': 'editImage',
			'click .modula-delete-video': 'deleteImage',
			resize: 'resizeImage',
			resizestop: 'resizeStop',
			'modula:updateIndex': 'updateIndex',
		},

		editImage( event ) {
			event.preventDefault();
			// Open Modula Modal
			modula.EditVideoModal.open( this.model );
		},
	} );

	// new modulaVideoView();
} )( jQuery, wp.Modula );

jQuery( document ).ready( function ( $ ) {
	// Initialize Filters
	wp.Modula.VideoViews = new wp.Modula.views.modulaVideoView();

	// Modula edit video modal.
	wp.Modula.EditVideoModal = new wp.Modula.videoModal.model( {
		childViews: wp.Modula.videoModalChildViews,
	} );
} );
