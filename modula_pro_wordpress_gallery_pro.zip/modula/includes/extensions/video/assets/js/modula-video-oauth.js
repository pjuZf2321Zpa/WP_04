jQuery( document ).on(
	'click',
	'#modula-video-reconnect-gsc, #modula-video-disconnect-gsc',
	function ( e ) {
		e.preventDefault();

		const $nonce = jQuery( this ).data( 'nonce' ),
			$action = jQuery( this ).data( 'action' );

		jQuery.ajax( {
			url: ajaxurl,
			method: 'POST',
			data: {
				action: 'modula_video_' + $action + '_gsc',
				nonce: $nonce,
			},
			success( response ) {
				window.location.reload();
			},
			error() {
				alert(
					'Error connecting to Google Search Console. Please try again.'
				);
			},
		} );
	}
);
