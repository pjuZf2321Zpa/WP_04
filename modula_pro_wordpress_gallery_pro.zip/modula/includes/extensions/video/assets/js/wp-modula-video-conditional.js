( function ( $, modula ) {
	'use strict';
	const modulaVideoConditions = Backbone.Model.extend( {
		initialize( args ) {
			const rows = jQuery(
				'.modula-settings-container tr[data-container]'
			);
			this.set( 'rows', rows );
			const tabs = jQuery( '.modula-tabs .modula-tab' );
			this.set( 'tabs', tabs );
			this.initEvents();
			this.initValues();
		},

		initValues() {
			this.changedType( false, wp.Modula.Settings.get( 'type' ) );
			this.changedShowVideoIcon(
				false,
				wp.Modula.Settings.get( 'show-video-icon' )
			);
			this.changedCustomIcon(
				false,
				wp.Modula.Settings.get( 'use-custom-icon' )
			);
			this.changedVideoPreview(
				false,
				wp.Modula.Settings.get( 'preview-video' )
			);
			this.changedVideoIcon();
		},

		initEvents() {
			this.listenTo(
				wp.Modula.Settings,
				'change:type',
				this.changedType
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:show-video-icon',
				this.changedShowVideoIcon
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:use-custom-icon',
				this.changedCustomIcon
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:preview-video',
				this.changedVideoPreview
			);

			this.listenTo(
				wp.Modula.Settings,
				'toggleAccordeon:show-video-icon',
				this.toggleShowVideoIcon
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:show-video-icon',
				this.changedVideoIcon
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:use-custom-icon',
				this.changedVideoIcon
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:video-icon-icon',
				this.changedVideoIcon
			);
			this.listenTo(
				wp.Modula.Settings,
				'change:video-icon-color',
				this.changedVideoIcon
			);
		},

		changedType( settings, value ) {
			const rows = this.get( 'rows' ),
				tabs = this.get( 'tabs' );
			tabs.show();
			if ( 'slider' == value ) {
				rows.filter(
					'[data-container="autoplay-videos"], [data-container="show-video-icon"],[data-container="playlist_position"]'
				).hide();
				rows.filter( '[data-container="enableVideosOnSlider"]' ).show();
			} else if ( 'custom-grid' === value ) {
				rows.filter(
					'[data-container="autoplay-videos"], [data-container="show-video-icon"]'
				).show();
				rows.filter(
					'[data-container="enableVideosOnSlider"],[data-container="playlist_position"]'
				).hide();
			} else if ( 'creative-gallery' === value ) {
				rows.filter(
					'[data-container="autoplay-videos"], [data-container="show-video-icon"]'
				).show();
				rows.filter(
					'[data-container="enableVideosOnSlider"],[data-container="playlist_position"]'
				).hide();
			} else if ( 'grid' === value ) {
				rows.filter(
					'[data-container="autoplay-videos"], [data-container="show-video-icon"]'
				).show();
				rows.filter(
					'[data-container="enableVideosOnSlider"],[data-container="playlist_position"]'
				).hide();
			} else if ( 'video' === value ) {
				rows.filter(
					'[data-container="grid_type"],[data-container="grid_row_height"],[data-container="slider_image_size"],[data-container="grid_justify_last_row"],[data-container="slider_image_dimensions"],[data-container="slider_image_crop"],[data-container="gutter"],[data-container="width"],[data-container="grid_image_size"],[data-container="grid_image_dimensions"],[data-container="img_size"],[data-container="img_crop"],[data-container="grid_image_crop"],[data-container="height"],[data-container="randomFactor"],[data-container="maxImagesCount"],[data-container="maxImagesCount_mobile"],[data-container="shuffle"],[data-container="slider_adaptiveHeight"],[data-container="slider_syncing"],[data-container="slider_syncing_nav_size"],[data-container="slider_syncing_nav_image_dimensions"],[data-container="slider_syncing_nav_image_crop"],[data-container="slider_syncing_nav_thumbnails_number"],[data-container="slider_syncing_nav_thumbnails_gutter"],[data-container="slider_syncing_nav_thumbnails_border_color"],[data-container="slider_autoplay"],[data-container="slider_autoplaySpeed"],[data-container="slider_pauseOnHover"],[data-container="slider_arrows"],[data-container="slider_dots"],[data-container="slider_draggable"],[data-container="slider_centerMode"],[data-container="slider_centerPadding"],[data-container="slider_fade"],[data-container="slider_infinite"],[data-container="slider_slidesToShow"],[data-container="slider_slidesToScroll"],[data-container="slider_speed"],[data-container="slider_rtl"],[data-container="slider_initialSlide"],[data-container="slider_image_info"],[data-container="shadowSize"],[data-container="shadowColor"]'
				).hide();
				rows.filter(
					'[data-container="enableVideosOnSlider"],[data-container="type"],[data-container="show-video-icon"],[data-container="use-custom-icon"],[data-container="video-icon-icon"],[data-container="video-icon-color"],[data-container="play-icon-size"],[data-container="preview-video"],[data-container="preview-video-duration"],[data-container="autoplay_thumbnail"],[data-container="borderSize"],[data-container="borderRadius"],[data-container="borderColor"],[data-container="custom-video-icon"],[data-container="style"],[data-container="protection"],[data-container="modula_deeplink"],[data-container="customLinkName"],[data-container="enable_password"],[data-container="password"],[data-container="password_protect_username"],[data-container="password_protect_text"],[data-container="playlist_position"]'
				).show();
				tabs.hide();
				tabs.filter(
					'[data-tab="modula-general"],[data-tab="modula-video"],[data-tab="modula-style"],[data-tab="modula-misc"],[data-tab="modula-password_protect"],[data-tab="modula-customizations"]'
				).show();
			}
		},

		changedShowVideoIcon( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter(
					'[data-container="show-video-icon"]'
				),
				children = currentRow.data( 'children' );

			jQuery.each( children, function ( index, item ) {
				const child = jQuery( '[data-container="' + item + '"]' );

				if (
					0 == value &&
					currentRow.hasClass( 'modula_accordion_open' )
				) {
					child.hide();
				} else {
					child.css( 'opacity', '1' );
					child
						.find( 'input, textarea, select, button' )
						.removeAttr( 'disabled' );
					child.show();
				}
			} );

			if ( '1' == wp.Modula.Settings.get( 'use-custom-icon' ) ) {
				rows.filter( '[data-container="custom-video-icon"]' ).show();
				rows.filter(
					'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
				).hide();
			} else {
				rows.filter( '[data-container="custom-video-icon"]' ).hide();
				rows.filter(
					'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
				).show();
			}

			if ( 1 == value ) {
				currentRow.addClass( 'modula_accordion_open' );
			} else {
				currentRow.removeClass( 'modula_accordion_open' );
			}
			this.changedCustomIcon(
				false,
				wp.Modula.Settings.get( 'use-custom-icon' )
			);
		},

		changedCustomIcon( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter(
					'[data-container="show-video-icon"]'
				);

			if ( '1' == value ) {
				if (
					'0' == wp.Modula.Settings.get( 'show-video-icon' ) &&
					currentRow.hasClass( 'modula_accordion_open' )
				) {
					rows.filter(
						'[data-container="custom-video-icon"]'
					).setting_state( this, 'off' );
					rows.filter(
						'[data-container="custom-video-icon"]'
					).show();
				} else if (
					'0' == wp.Modula.Settings.get( 'show-video-icon' ) &&
					! currentRow.hasClass( 'modula_accordion_open' )
				) {
					rows.filter(
						'[data-container="custom-video-icon"]'
					).hide();
				} else {
					rows.filter(
						'[data-container="custom-video-icon"]'
					).show();
				}
				rows.filter(
					'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
				).hide();
			} else {
				rows.filter( '[data-container="custom-video-icon"]' ).hide();
				if (
					'0' === wp.Modula.Settings.get( 'show-video-icon' ) &&
					currentRow.hasClass( 'modula_accordion_open' )
				) {
					rows.filter(
						'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
					).setting_state( this, 'off' );
					rows.filter(
						'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
					).show();
				} else if (
					'0' === wp.Modula.Settings.get( 'show-video-icon' ) &&
					! currentRow.hasClass( 'modula_accordion_open' )
				) {
					rows.filter(
						'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
					).hide();
				} else {
					rows.filter(
						'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
					).show();
				}
			}
		},
		toggleShowVideoIcon() {
			const rows = this.get( 'rows' );

			if ( '1' === wp.Modula.Settings.get( 'use-custom-icon' ) ) {
				rows.filter(
					'[data-container="video-icon-color"], [data-container="video-icon-icon"]'
				).hide();
			} else {
				rows.filter( '[data-container="custom-video-icon"]' ).hide();
			}
		},
		changedVideoPreview( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter( '[data-container="preview-video"]' ),
				children = currentRow.data( 'children' );

			jQuery.each( children, function ( index, item ) {
				const child = jQuery( '[data-container="' + item + '"]' );

				if ( 0 === value ) {
					child.hide();
				} else {
					child.css( 'opacity', '1' );
					child
						.find( 'input, textarea, select, button' )
						.removeAttr( 'disabled' );
					child.show();
				}
			} );

			if ( 1 === value ) {
				currentRow.addClass( 'modula_accordion_open' );
			} else {
				currentRow.removeClass( 'modula_accordion_open' );
			}
		},
		changedVideoIcon() {
			const modula_items_models = wp.Modula.Items.models,
				use_custom_icon = wp.Modula.Settings.get( 'use-custom-icon' ),
				show_icon = wp.Modula.Settings.get( 'show-video-icon' ),
				icon_color = wp.Modula.Settings.get( 'video-icon-color' );
			jQuery.each( modula_items_models, function ( index, value ) {
				if ( 0 != show_icon ) {
					if ( 0 != use_custom_icon ) {
						var src =
							jQuery( '#custom-video-icon' ).data( 'img-src' );
						modula_items_models[ index ].attributes.video_img_icon =
							src;
						modula_items_models[
							index
						].attributes.video_svg_icon = false;
					} else {
						const svg = jQuery(
							'#modula_video_play_icon_selected'
						).data( 'svg' );
						modula_items_models[
							index
						].attributes.video_img_icon = false;
						modula_items_models[ index ].attributes.video_svg_icon =
							svg;
						modula_items_models[
							index
						].attributes.video_icon_color = icon_color;
					}
				} else {
					modula_items_models[
						index
					].attributes.video_img_icon = false;
					modula_items_models[
						index
					].attributes.video_svg_icon = false;
				}

				modula_items_models[ index ].attributes.video_icon = src;
				modula_items_models[ index ].get( 'view' ).render();
			} );
		},
	} );

	$( document ).ready( function () {
		const options = $( '#video-icon-icon option' )
			.map( function () {
				return {
					value: $( this ).val(),
					text: $( this ).text(),
					icon: $( this ).data( 'icon' ),
				};
			} )
			.get();
		$( '#video-icon-icon' ).selectize( {
			options,
			render: {
				option( data, escape ) {
					return (
						'<div class="modula_video_play_icon_select"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" data-prefix="far" data-icon="play-circle" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="#000" d="' +
						data.icon +
						'"></path></svg><span>' +
						data.text +
						'</span></div>'
					);
				},
				item( data, escape ) {
					return (
						'<div id="modula_video_play_icon_selected" data-svg="' +
						data.icon +
						'" class="modula_video_play_icon_selected"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" data-prefix="far" data-icon="play-circle" role="img" xmlns="http://www.w3.org/2000/svg" ><path fill="#000" d="' +
						data.icon +
						'"></path></svg><span>' +
						data.text +
						'</span></div>'
					);
				},
			},
		} );

		const selector = new modulaVideoConditions();
		const modulaVideoFrame = new wp.media( {
			title: 'Select a image to upload',
			button: {
				text: 'Use this image',
			},
			multiple: false, // Set to true to allow multiple files to be selected
		} );

		modulaVideoFrame.on( 'select', function () {
			// We set multiple to false so only get one image from the uploader
			const attachment = modulaVideoFrame
				.state()
				.get( 'selection' )
				.first()
				.toJSON();

			let att_id = attachment.id,
				att_src = attachment.url;

			if ( 'undefined' !== typeof attachment.sizes.thumbnail ) {
				att_src = attachment.sizes.thumbnail.url;
			}

			$( '#custom-video-icon' ).val( att_id ).data( 'img-src', att_src );
			$( '.modula_custom_video_icon_preview' ).html(
				'<img src="' + att_src + '">'
			);
			selector.changedVideoIcon();

			$( '#upload_video_icon' ).hide();
			$( '#replace_video_icon' ).show();
			$( '#delete_video_icon' ).show();
		} );

		$( '#upload_video_icon' ).click( function ( event ) {
			event.preventDefault();
			modulaVideoFrame.open();
		} );

		$( '#replace_video_icon' ).click( function ( event ) {
			event.preventDefault();
			modulaVideoFrame.open();
		} );

		$( '#delete_video_icon' ).click( function ( event ) {
			event.preventDefault();

			$( '#custom-video-icon' ).val( 0 ).data( 'img-src', '' );
			$( '.modula_custom_video_icon_preview' ).html( '' );
			selector.changedVideoIcon();
			$( '#upload_video_icon' ).show();
			$( '#replace_video_icon' ).hide();
			$( '#delete_video_icon' ).hide();
		} );
	} );
} )( jQuery, wp.Modula );
