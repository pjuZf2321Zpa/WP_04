wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;

( function ( $, modula ) {
	const modulaVideoModal = Backbone.Model.extend( {
		defaults: {
			item: false,
		},

		initialize( args ) {
			const modalView = new modula.videoModal.view( {
				model: this,
				childViews: args.childViews,
			} );

			const wpMediaView = new wp.media.view.Modal( {
				controller: {
					trigger() {},
				},
			} );

			this.set( 'wpMediaView', wpMediaView );
			this.set( 'modulaVideoModal', modalView );
		},

		open( $item ) {
			const wpMediaView = this.get( 'wpMediaView' ),
				modulaVideoModal = this.get( 'modulaVideoModal' );

			// Set the current item
			this.set( 'item', $item );
			// Render Modula View
			modulaVideoModal.render();
			// Append modulaModalView to wpMediaView
			wpMediaView.content( modulaVideoModal );
			// Open wpMediaView
			wpMediaView.open();
		},
	} );

	const modulaVideoModalView = Backbone.View.extend( {
		/**
		 * The Tag Name and Tag's Class(es)
		 */
		tagName: 'div',
		className:
			'edit-attachment-frame mode-select hide-menu hide-router modula-edit-popup',

		/**
		 * Template
		 * - The template to load inside the above tagName element
		 */
		template: wp.template( 'modula-video-editor' ),
		defTemplate: wp.template( 'modula-image-editor' ),

		/**
		 * Events
		 * - Functions to call when specific events occur
		 */
		events: {
			'click .edit-media-header .left': 'loadPreviousItem',
			'click .edit-media-header .right': 'loadNextItem',

			'keyup input': 'updateItem',
			'keyup textarea': 'updateItem',
			'change input': 'updateItem',
			'change textarea': 'updateItem',
			'blur textarea': 'updateItem',
			'change select': 'updateItem',
			'input input.modula_video_url_input': 'changeVideoUrl',

			'click .actions a.modula-gallery-meta-submit': 'saveItem',
			'click .actions a.modula-gallery-meta-submit-close':
				'saveItemAndClose',

			'keyup input#link-search': 'searchLinks',
			'click div.query-results li': 'insertLink',
		},

		/**
		 * Initialize
		 *
		 * @param object model   ModulaImage Backbone Model
		 * @param args
		 */
		initialize( args ) {
			// Define loading and loaded events, which update the UI with what's happening.
			this.on( 'loading', this.loading, this );
			this.on( 'loaded', this.loaded, this );
			this.on(
				'videoTemplateChanged',
				this.onVideoTemplateChanged,
				this
			); // Event listener
			// Change item when model updates his attribute
			this.listenTo( this.model, 'change:item', this.changeItem );

			// Child Views
			this.childViews = args.childViews;

			// Set some flags
			this.is_loading = false;
			this.search_timer = '';
			this.item = false;
		},

		changeItem() {
			this.item = this.model.get( 'item' );
		},

		changeVideoUrl( elem ) {
			this.item = this.model.get( 'item' );

			modula.VideoViews.updateVideoUrl( this.item, elem.currentTarget )
				.then( () => {
					this.render();
				} )
				.catch( ( error ) => {
					console.error( 'Failed to update video URL:', error );
					// Handle any additional error processing, if needed
				} );
		},

		/**
		 * Render
		 * - Binds the model to the view, so we populate the view's fields and data
		 */
		render() {
			// Get the current item from model if not exist.
			if ( ! this.item ) {
				this.item = this.model.get( 'item' );
			}

			// Get current Index.
			this.attachment_index = modula.Items.indexOf( this.item );
			const args = {};
			// Get HTML
			if (
				this.item &&
				'undefined' != this.item.attributes.video_template &&
				'1' == this.item.attributes.video_template
			) {
				args.template = this.template;
				args.childViews = this.childViews;
			} else if ( this.item ) {
				args.template = this.defTemplate;
				args.childViews = wp.Modula.modalChildViews;
			}

			this.trigger( 'ModulaVideoModalRender', args, this.item );

			this.$el.html( args.template( this.item.toJSON() ) );

			// Generate Child Views
			if ( args.childViews.length > 0 ) {
				args.childViews.forEach( function ( view ) {
					// Init with model
					const childView = new view( {
						model: this.model,
					} );

					// Render view within our main view
					this.$el
						.find( 'div.modula-addons' )
						.append( childView.render().el );
				}, this );
			}

			// Enable / disable the buttons depending on the index
			if ( this.attachment_index == 0 ) {
				// Disable left button
				this.$el.find( 'button.left' ).addClass( 'disabled' );
			}
			if ( this.attachment_index == modula.Items.length - 1 ) {
				// Disable right button
				this.$el.find( 'button.right' ).addClass( 'disabled' );
			}
			// Hide / show the url input based on gallery settings.
			if ( modula.Settings.get( 'lightbox' ) != 'external-url' ) {
				this.$el
					.find( '.setting.modula-link' )
					.addClass( 'modula-hide' );
			} else {
				this.$el
					.find( '.setting.modula-link' )
					.removeClass( 'modula-hide' );
			}

			// Return
			return this;
		},

		/**
		 * Renders an error using
		 * wp.media.view.ModulaGalleryError
		 * @param error
		 */
		renderError( error ) {
			// Define model
			const model = {};
			model.error = error;

			// Define view
			const view = new wp.media.view.ModulaGalleryError( {
				model,
			} );

			// Return rendered view
			return view.render().el;
		},

		/**
		 * Tells the view we're loading by displaying a spinner
		 */
		loading() {
			// Set a flag so we know we're loading data
			this.is_loading = true;

			// Show the spinner
			this.$el.find( '.spinner' ).css( 'visibility', 'visible' );
		},

		/**
		 * Hides the loading spinner
		 * @param response
		 */
		loaded( response ) {
			// Set a flag so we know we're not loading anything now
			this.is_loading = false;

			// Hide the spinner
			this.$el.find( '.spinner' ).css( 'visibility', 'hidden' );

			// Display the error message, if it's provided
			if ( typeof response !== 'undefined' ) {
				this.$el
					.find( 'div.media-toolbar' )
					.after( this.renderError( response ) );
			}
		},

		/**
		 * Load the previous model in the collection
		 */
		loadPreviousItem() {
			let item;

			// Decrement the index
			this.attachment_index--;

			// Get the model at the new index from the collection
			item = modula.Items.at( this.attachment_index );

			this.model.set( 'item', item );

			// Re-render the view
			this.render();
		},

		/**
		 * Load the next model in the collection
		 */
		loadNextItem() {
			let item;

			// Increment the index
			this.attachment_index++;

			// Get the model at the new index from the collection
			item = modula.Items.at( this.attachment_index );
			this.model.set( 'item', item );

			// Re-render the view
			this.render();
		},

		/**
		 * Updates the model based on the changed view data
		 * @param event
		 */
		updateItem( event ) {
			// Check if the target has a name. If not, it's not a model value we want to store
			if ( event.target.name == '' ) {
				return;
			}

			// Update the model's value, depending on the input type
			if ( event.target.type == 'checkbox' ) {
				value = event.target.checked ? event.target.value : 0;
			} else {
				value = event.target.value;
			}

			// Update the model
			this.item.set( event.target.name, value );
		},

		/**
		 * Saves the image metadata
		 * @param event
		 */
		saveItem( event ) {
			let view,
				self = this,
				item = this.model.get( 'item' );

			event.preventDefault();

			// Tell the View we're loading
			this.trigger( 'loading' );

			// Get item view and render it.
			view = this.item.get( 'view' );
			view.render();

			// Show the user the 'saved' notice for 1.5 seconds
			const saved = this.$el.find( '.saved' );
			saved.fadeIn();

			wp.Modula.Save.saveImages( function () {
				// Tell the view we've finished successfully
				self.trigger( 'loaded loaded:success' );
				saved.fadeOut();
			} );
		},

		saveItemAndClose( event ) {
			let view,
				self = this;

			event.preventDefault();

			// Tell the View we're loading
			this.trigger( 'loading' );

			clearInterval( wp.Modula.Save.updateInterval );
			wp.Modula.Save.saveImages( function () {
				// Get item view and render it.
				view = self.model.get( 'wpMediaView' );
				view.close();
			} );
		},

		/**
		 * Searches Links
		 * @param event
		 */
		searchLinks( event ) {},

		/**
		 * Inserts the clicked link into the URL field
		 * @param event
		 */
		insertLink( event ) {},
	} );

	modula.videoModal = {
		model: modulaVideoModal,
		view: modulaVideoModalView,
	};
} )( jQuery, wp.Modula );
