class VimeoVideoElement extends HTMLElement {
	playing = undefined;
	vmIframe = undefined;

	constructor() {
		super();
		this.options = {
			url: this.getAttribute( 'video_src' ),
			autoplay: 0,
			controls: 0,
			muted: 1,
			width: this.getAttribute( 'width' ),
			height: this.getAttribute( 'height' ),
			autopause: false,
			loop: this.getAttribute( 'data-autothumb' ), // fix for loop in case of autoplay videos in thumbnail, without this the video will not always replay at end.
		};
	}

	connectedCallback() {
		this.vmIframe = this;
		this.playing = false;
		this.init();
	}

	async init() {
		this.vmPlayer = await this.buildPlayer();
		[ 'ended' ].forEach( ( e ) => {
			const self = this;
			this.vmPlayer.on( e, ( progress ) => {
				self.dispatchEvent( new CustomEvent( e ) );
			} );
		} );
	}

	load() {
		if ( this.vmPlayer ) {
			this.vmPlayer.setCurrentTime( 0 );
		}
	}

	async play() {
		try {
			if ( this.vmPlayer ) {
				this.playing = await this.vmPlayer.play();
			}
		} catch ( error ) {
			// Do nothing, this most likely occured because the video is on autoplay
			// and the user is not engaged with the browser tab https://goo.gl/LdLk22
		}
	}

	pause() {
		if ( this.vmPlayer && this.playing ) {
			this.playing = false;
			this.vmPlayer.pause();
		}
	}

	buildPlayer() {
		return new Vimeo.Player( this.vmIframe, this.options );
	}
}
customElements.define( 'vimeo-video', VimeoVideoElement );
