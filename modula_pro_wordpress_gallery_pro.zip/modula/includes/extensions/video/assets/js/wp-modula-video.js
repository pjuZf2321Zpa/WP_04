wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;
wp.Modula.models =
	'undefined' === typeof wp.Modula.models ? {} : wp.Modula.models;
wp.Modula.views = 'undefined' === typeof wp.Modula.views ? {} : wp.Modula.views;
wp.Modula.modalChildViews =
	'undefined' === typeof wp.Modula.modalChildViews
		? []
		: wp.Modula.modalChildViews;

const ModulaVideoModalView = Backbone.View.extend( {
	/**
	 * The Tag Name and Tag's Class(es)
	 */
	tagName: 'div',
	className: 'setting modula-video',

	/**
	 * Template
	 * - The template to load inside the above tagName element
	 */
	template: wp.template( 'modula-video' ),

	/**
	 * Initialize
	 * @param args
	 */
	initialize( args ) {
		const view = this;

		this.model = args.model;
		this.isSelectize = false;
	},

	render() {
		const item = this.model.get( 'item' ),
			videoURL = item.get( 'video_url' ),
			videoTitle = item.get( 'video_title' ),
			videoDescription = item.get( 'video_description' ),
			videoAlt = item.get( 'video_alt' ),
			videoThumbnail = item.get( 'video_thumbnail' ),
			autoplayThumbnail = item.get( 'autoplay_thumbnail' ),
			autoplayLightbox = item.get( 'autoplay_lightbox' ),
			loopVideo = item.get( 'loop_video' ),
			data = {
				video_url: '',
				video_title: '',
				video_description: '',
				video_alt: '',
				video_thumbnail: '',
				autoplay_thumbnail: 'inherit',
				autoplay_lightbox: 'inherit',
				loop_video: 'inherit',
			};

		if ( videoURL ) {
			data.video_url = videoURL;
		}

		if ( videoTitle ) {
			data.video_title = videoTitle;
		}

		if ( videoDescription ) {
			data.video_description = videoDescription;
		}

		if ( videoAlt ) {
			data.video_alt = videoAlt;
		}

		if ( videoThumbnail ) {
			data.video_thumbnail = videoThumbnail;
		}

		if ( autoplayThumbnail ) {
			data.autoplay_thumbnail = autoplayThumbnail;
		}

		if ( autoplayLightbox ) {
			data.autoplay_lightbox = autoplayLightbox;
		}

		if ( loopVideo ) {
			data.loop_video = loopVideo;
		}

		this.$el.html( this.template( data ) );

		return this;
	},
} );

wp.Modula.modalChildViews.push( ModulaVideoModalView );

jQuery( document ).on(
	'modula_gallery_type_check',
	function ( event, backbone, location, type ) {
		if ( 'video' == type ) {
			// If resizeble is enable we will destroy it
			if ( backbone.isResizeble ) {
				backbone.disableResizeble();
			}

			// If sortable is not enabled, we will initialize it.
			if ( ! backbone.isSortable ) {
				backbone.enableSortable();
			}

			backbone.container
				.removeClass( 'modula-custom-grid' )
				.addClass( 'modula-creative-gallery' );
			backbone.helperGrid.hide();

			backbone.container.sortable( {
				items: '.modula-single-image',
				cursor: 'move',
				forcePlaceholderSize: true,
				placeholder: 'modula-single-image-placeholder',
				stop( event, ui ) {
					const itemsIDs = backbone.container.sortable( 'toArray' );
					itemsIDs.forEach( function ( itemID, i ) {
						const id = '#' + itemID;
						jQuery( id ).trigger( 'modula:updateIndex', {
							index: i,
						} );
					} );
				},
			} );
			backbone.$el.removeClass( 'modula-resizer-enabled' );
		}
	}
);
