jQuery( document ).on(
	'modula_fancybox_lightbox_after_show',
	function ( e, obj, instance, current ) {
		const video_src = instance.src;

		if (
			'undefined' !== typeof video_src &&
			video_src.indexOf( '.mov' ) > 0
		) {
			instance.type = 'html';
			instance.contentType = 'html';
			instance.$content.html(
				'<object  pluginspage="http://www.apple.com/quicktime/download" data="' +
					video_src +
					'" type="video/quicktime"><param name="autoplay" value="true"><param name="scale" value="tofit"><param name="controller" value="true"><param name="enablejavascript" value="true"><param name="src" value="' +
					video_src +
					'"><param name="loop" value="false"></object>'
			);
			instance.$slide.addClass( 'modula-mov-object' );
		}
	}
);

jQuery( document ).on(
	'modula_fancybox_lightbox_on_init',
	function ( e, fancybox ) {
		const slides = fancybox.userSlides;

		jQuery.each( slides, function ( index, slide ) {
			var img,
				ratio = false,
				autoplay = false;

			if (
				slide.opts.hasOwnProperty( '$thumb' ) &&
				typeof slide.opts.$thumb !== 'string'
			) {
				var img = slide.opts.$thumb.find( '.pic' ),
					ratio =
						'undefined' !== typeof img.data( 'ratio' )
							? img.data( 'ratio' )
							: false,
					autoplay =
						'undefined' !== typeof img.data( 'autolight' )
							? img.data( 'autolight' )
							: false;
			}

			if ( ratio ) {
				fancybox.userSlides[ index ].videoRatio = parseFloat( ratio );
			}
			if ( autoplay ) {
				fancybox.userSlides[ index ].videoAutoplay = autoplay;
			}
		} );
	}
);

// Add / clear loop on HTML5 video elements (gallery + per-item data-loop on .pic).
jQuery( document ).on( 'modula_fancybox_done', function ( e, fancybox ) {
	if ( undefined === fancybox ) {
		return;
	}

	const slide = fancybox.getSlide();
	var video = jQuery( slide.el ).find( '.modula_html5_video, video.fancybox__html5video' ),
		loop = false;

	if (
		slide.opts.hasOwnProperty( '$thumb' ) &&
		typeof slide.opts.$thumb !== 'string'
	) {
		var img = slide.opts.$thumb.find( '.pic' );
		if ( img.length ) {
			loop =
				'undefined' !== typeof img.data( 'loop' )
					? img.data( 'loop' )
					: false;
		}
	}

	if ( 1 === loop || true === loop || '1' === loop ) {
		video.attr( 'loop', 'loop' ).prop( 'loop', true );
	} else {
		video.removeAttr( 'loop' ).prop( 'loop', false );
	}
} );

( function ( $ ) {
	window.modulaVideoWatchtime = [];

	$( '.modula-slider' ).on(
		'afterChange init',
		'.modula-items.slick-slider',
		function ( event, slick ) {
			const slides = slick.$slides;

			$.each( slides, function ( index, value ) {
				const initial = slides[ index ],
					initial_player = $( initial ).find(
						'.modula_video_preview_element'
					)[ 0 ],
					icon = $( initial ).find( '.modula-video-icon' ),
					iframe = $( initial ).find(
						'.modula-video-content iframe'
					);

				if ( $( value ).hasClass( 'slick-active' ) ) {
					// Start the player(s) on swipe/next
					if ( 'undefined' !== typeof initial_player ) {
						if ( modulaVideoPreview.duration > 0 ) {
							if (
								'undefined' !==
								typeof window.modulaVideoWatchtime[ index ]
							) {
								clearInterval(
									window.modulaVideoWatchtime[ index ]
								);
							}

							// Track Watchtime
							window.modulaVideoWatchtime[ index ] = setInterval(
								async function () {
									initial_player.load();
									// Wait for Vimeo play now to prevent interruption by calls to pause
									await initial_player.play();
								},
								modulaVideoPreview.duration * 1000
							);
						}
						if (
							'undefined' !==
								typeof $( initial_player ).data(
									'autothumb'
								) &&
							'1' == $( initial_player ).data( 'autothumb' )
						) {
							icon.hide();
							initial_player.play();
						}
					}
				} else {
					// Stop the previous playing video in slider.
					if ( 'undefined' !== typeof iframe ) {
						iframe.attr( 'src', iframe.attr( 'src' ) );
					}

					// Stop the previous player
					if ( 'undefined' !== typeof initial_player ) {
						clearInterval( window.modulaVideoWatchtime[ index ] );
						// Resets video element & it's poster if any.
						initial_player.load();
						initial_player.pause();
					}
				}
			} );
		}
	);
} )( jQuery );
