wp.ModulaDefaultsAlbums =
	'undefined' === typeof wp.ModulaDefaultsAlbums
		? {}
		: wp.ModulaDefaultsAlbums;

( function ( $, modula ) {
	const modulaDefaultsAlbumsPasswordProtectConditions = Backbone.Model.extend(
		{
			initialize( args ) {
				const rows = jQuery(
					'.modula-settings-container tr[data-container]'
				);
				this.set( 'rows', rows );

				this.initEvents();
				this.initValues();
			},

			initEvents() {
				this.listenTo(
					wp.ModulaDefaultsAlbums.Settings,
					'change:enable_password',
					this.changedPassword
				);
			},

			initValues() {
				this.changedPassword(
					false,
					wp.ModulaDefaultsAlbums.Settings.get( 'enable_password' )
				);
			},

			changedPassword( settings, value ) {
				const rows = this.get( 'rows' ),
					tabs = this.get( 'tabs' );

				if ( '1' == value ) {
					rows.filter(
						'[data-container="password"], [data-container="password_protect_username"], [data-container="password_protect_text"]'
					).show();
				} else {
					rows.filter(
						'[data-container="password"], [data-container="password_protect_username"], [data-container="password_protect_text"]'
					).hide();
				}
			},
		}
	);

	$( document ).ready( function () {
		new modulaDefaultsAlbumsPasswordProtectConditions();
	} );
} )( jQuery, wp.ModulaDefaultsAlbums );
