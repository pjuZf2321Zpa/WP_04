wp.Modula = 'undefined' === typeof wp.Modula ? {} : wp.Modula;

( function ( $, modula ) {
	let instance;
	const modulaPasswordProtectConditions = Backbone.Model.extend( {
		initialize( args ) {
			const rows = jQuery(
				'.modula-settings-container tr[data-container]'
			);
			this.set( 'rows', rows );

			// Ensure wp.Modula.Settings exists before binding.
			this.waitForSettingsAndInit();
		},

		waitForSettingsAndInit() {
			instance = this;

			if ( wp.Modula && wp.Modula.Settings ) {
				this.initEvents();
				this.initValues();
				return;
			}

			// Fallback: try again once the document is ready.
			jQuery( document ).ready( () => {
				if ( wp.Modula && wp.Modula.Settings ) {
					this.initEvents();
					this.initValues();
				}
			} );
		},

		initEvents() {
			if ( ! wp.Modula || ! wp.Modula.Settings ) {
				return;
			}

			this.listenTo(
				wp.Modula.Settings,
				'change:enable_password',
				this.changedPassword
			);

			// Attach password input events
			this.passwordFieldInit();
			this.visibilityToggle();
			this.passwordCopy();
			this.passwordOnInputChange();
		},

		initValues() {
			if ( ! wp.Modula.Settings ) {
				return;
			}

			this.changedPassword(
				false,
				wp.Modula.Settings.get( 'enable_password' )
			);
		},

		changedPassword( settings, value ) {
			const rows = this.get( 'rows' ),
				currentRow = rows.filter(
					'[data-container="enable_password"]'
				),
				children = currentRow.data( 'children' );

			jQuery.each( children, function ( index, item ) {
				const child = jQuery( '[data-container="' + item + '"]' );

				if ( 0 == value ) {
					child.hide();
				} else {
					child.css( 'opacity', '1' );
					child
						.find( 'input, textarea, select, button' )
						.removeAttr( 'disabled' );
					child.show();
				}
			} );

			if ( '1' == value ) {
				currentRow.addClass( 'modula_accordion_open' );
			} else {
				currentRow.removeClass( 'modula_accordion_open' );
			}
		},

		visibilityToggle() {
			jQuery( document ).on(
				'click',
				'.modula-password-visibility-toggle',
				function ( element ) {
					const button = jQuery( this ),
						status = button.data( 'toggle' ),
						wrapper = button.parent(),
						input = wrapper.find( 'input' );

					if ( input.attr( 'type' ) == 'password' ) {
						// We must show the password.
						button
							.find( '.dashicons' )
							.removeClass( 'dashicons-visibility' );
						button
							.find( '.dashicons' )
							.addClass( 'dashicons-hidden' );
						input.attr( 'type', 'text' );
					} else {
						// We must hide the password.

						button
							.find( '.dashicons' )
							.removeClass( 'dashicons-hidden' );
						button
							.find( '.dashicons' )
							.addClass( 'dashicons-visibility' );
						input.attr( 'type', 'password' );
					}
				}
			);
		},

		passwordCopy() {
			jQuery( document ).on(
				'click',
				'.copy-modula-password',
				function ( element ) {
					element.preventDefault();
					let gallery_password = $( this ).parent().find( 'input' ),
						field_type = gallery_password.attr( 'type' ),
						type_changed = false;

					// Do we need to transform input to text?
					if ( 'text' != field_type ) {
						gallery_password.attr( 'type', 'text' );
						type_changed = true;
					}

					// Do the copy.
					gallery_password.focus();
					gallery_password.select();
					document.execCommand( 'copy' );
					$( this ).next( 'span' ).text( 'Password Copied' );

					// Change back if we transformed previously
					if ( true == type_changed ) {
						gallery_password.attr( 'type', 'password' );
					}
				}
			);
		},

		check_pass_strength() {
			let pass1 = $( '#modula-password-protect-password' ).val(),
				strength;

			$( '#pass-strength-result' ).removeClass(
				'short bad good strong empty'
			);

			if ( ! pass1 || '' === pass1.trim() ) {
				$( '#pass-strength-result' ).hide();
				$( '#pass-strength-result' )
					.addClass( 'empty' )
					.html( '&nbsp;' );
				return;
			}

			strength = wp.passwordStrength.meter(
				pass1,
				wp.passwordStrength.userInputDisallowedList(),
				pass1
			);

			switch ( strength ) {
				case -1:
					$( '#pass-strength-result' )
						.addClass( 'bad' )
						.html( pwsL10n.unknown );
					break;
				case 2:
					$( '#pass-strength-result' )
						.addClass( 'bad' )
						.html( pwsL10n.bad );
					break;
				case 3:
					$( '#pass-strength-result' )
						.addClass( 'good' )
						.html( pwsL10n.good );
					break;
				case 4:
					$( '#pass-strength-result' )
						.addClass( 'strong' )
						.html( pwsL10n.strong );
					break;
				case 5:
					$( '#pass-strength-result' )
						.addClass( 'short' )
						.html( pwsL10n.mismatch );
					break;
				default:
					$( '#pass-strength-result' )
						.addClass( 'short' )
						.html( pwsL10n.short );
			}
			$( '#pass-strength-result' ).show();
		},

		passwordFieldInit() {
			jQuery.getScript(
				'/wp-includes/js/zxcvbn.min.js',
				function ( data, textStatus, jqxhr ) {
					instance.check_pass_strength();
				}
			);
		},

		passwordOnInputChange() {
			jQuery( document ).on(
				'keyup',
				'.modula-password input',
				function ( element ) {
					instance.check_pass_strength();
				}
			);
		},
	} );

	$( document ).ready( function () {
		new modulaPasswordProtectConditions();
	} );
} )( jQuery, wp.Modula );
