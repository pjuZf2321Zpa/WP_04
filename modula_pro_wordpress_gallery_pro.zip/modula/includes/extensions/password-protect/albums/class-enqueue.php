<?php
namespace Modula_Pro\Extensions\Password_Protect\Albums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/password-protect';

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	public function admin_scripts( $hook ) {
		// Get current screen.
		$screen = get_current_screen();

		// Only load for Modula Albums editor screens.
		if ( empty( $screen->post_type ) || 'modula-album' !== $screen->post_type ) {
			return;
		}

		// Only load on post editor screens.
		if ( 'post-new.php' !== $hook && 'post.php' !== $hook ) {
			return;
		}

		if (
			class_exists( '\Modula_Pro\Extensions\Albums\V2\Admin\Album_Takeover_Admin', false )
			&& \Modula_Pro\Extensions\Albums\V2\Admin\Album_Takeover_Admin::should_use_takeover()
		) {
			return;
		}

		// Needs wp-backbone (Backbone.Model) and the albums admin scripts that create wp.Modula.Settings.
		wp_enqueue_script(
			'modula-albums-password-protect-conditions',
			\MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-albums-password-conditional.js',
			array( 'jquery', 'wp-backbone', 'albums-wp-modula', 'user-profile' ),
			\MODULA_PRO_VERSION,
			true
		);
		wp_enqueue_style( 'modula-password-protect-admin', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-password-protect-admin.css', array(), \MODULA_PRO_VERSION );
	}
}
