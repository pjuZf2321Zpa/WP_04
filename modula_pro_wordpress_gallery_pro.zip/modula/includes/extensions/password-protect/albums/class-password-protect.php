<?php
namespace Modula_Pro\Extensions\Password_Protect\Albums;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Password Protect Albums
 */
class Password_Protect {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.2
	 */
	public function __construct() {
		// Add protect_textarea field type for Albums
		add_filter( 'modula_render_protect_textarea_field_type', array( $this, 'textarea_field_type' ), 10, 5 );
		add_filter( 'modula_render_protect_password_field_type', array( $this, 'password_field_type' ), 10, 5 );

		// Add another format for our textarea for Albums
		add_filter( 'modula_field_type_protect_textarea_format', array( $this, 'password_protect_textarea_format' ), 15, 10 );

		// Load conditional js for Albums
		new Enqueue();

		add_filter( 'modula_album_default_settings', array( $this, 'album_password_protect_defaults' ) );

		// Alter Save
		/* Fire our meta box setup function on the post editor screen. */
		add_action( 'load-post.php', array( $this, 'save_password' ) );
		add_action( 'load-post-new.php', array( $this, 'save_password' ) );

		// Filter Modula Password Protect Tab for Albums
		add_filter( 'modula_album_tabs', array( $this, 'modula_password_protect_tabs' ) );

		// Filter Modula Password Protect Fields for Albums
		add_filter( 'modula_album_fields', array( $this, 'modula_password_protect_fields' ) );

		// Sync WP post_password when settings are saved via the albums v2 REST editor.
		add_action( 'modula_album_settings_v2_updated', array( $this, 'sync_post_password_from_settings_v2' ), 10, 4 );

		// Require the password protection module
		Password_Protect_Module::get_instance();
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.2
	 *
	 * @return object The Password_Protect object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Password_Protect ) ) {
			self::$instance = new Password_Protect();
		}

		return self::$instance;
	}


	/**
	 * Add Password Protect Tab
	 *
	 * @param $tabs
	 *
	 * @return mixed
	 */
	public function modula_password_protect_tabs( $tabs ) {

		if ( ! isset( $tabs['password_protect'] ) ) {
			$tabs['password_protect'] = array(
				'label'    => esc_html__( 'Password Protect', 'modula-pro' ),
				'docs_url' => 'https://wp-modula.com/kb/password-protection-extension/',
				'icon'     => 'dashicons dashicons-shield',
				'priority' => 100,
			);
		}

		return $tabs;
	}


	/**
	 * Add Password Protect Fields
	 *
	 * @param $fields
	 *
	 * @return mixed
	 */
	public function modula_password_protect_fields( $fields ) {
		if ( ! class_exists( 'Modula_Pro\Extensions\Albums\Albums' ) ) {
			return $fields;
		}

		$fields['password_protect'] = array(
			'enable_password'           => array(
				'name'      => esc_html__( 'Enable Password Protect', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 10,
				'children'  => array( 'password', 'password_protect_username', 'password_protect_text' ),
				'data_type' => 'bool',
			),
			'password'                  => array(
				'name'      => esc_html__( 'Password', 'modula-pro' ),
				'type'      => 'protect_password',
				'priority'  => 30,
				'data_type' => 'text',
			),
			'password_protect_username' => array(
				'name'      => esc_html__( 'Request username or email with password', 'modula-pro' ),
				'type'      => 'text',
				'priority'  => 30,
				'data_type' => 'text',
			),
			'password_protect_text'     => array(
				'name'      => esc_html__( 'Protection message', 'modula-pro' ),
				'type'      => 'protect_textarea',
				'priority'  => 40,
				'data_type' => 'text',
			),
		);

		return $fields;
	}

	/***
	 * Add protect_textarea field type
	 *
	 * @param $html
	 * @param $field
	 * @param $value
	 *
	 * @return string
	 */
	public function textarea_field_type( $html, $field, $value ) {

		$html  = '<div class="modula-textarea">';
		$html .= '<textarea data-setting="' . esc_attr( $field['id'] ) . '" name="modula-settings[' . esc_attr( $field['id'] ) . ']" id="modula-' . esc_attr( $field['id'] ) . '" rows="10" cols="50">' . wp_kses_post( $value ) . '</textarea>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Custom format for protect_textarea field type
	 *
	 * @param $format
	 * @param $field
	 *
	 * @return string
	 */
	public function password_protect_textarea_format( $format, $field ) {

		$format = '<tr data-container="' . esc_attr( $field['id'] ) . '"><th scope="row"><label class="th-label">%s</label>%s</th><td>%s</td></tr>';

		return $format;
	}

	public function save_password() {

		/* Save post meta on the 'save_post' hook. */
		add_action( 'save_post', array( $this, 'save_extra_fields' ), 50, 2 );
	}

	public function save_extra_fields( $post_id, $post ) {

		//phpcs:disable
		/* Get the post type object. */
		$post_type = get_post_type_object( $post->post_type );
		/* Check if the current user has permission to edit the post. */
		if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) ) {
			return $post_id;
		}

		if ( 'modula-album' != get_post_type( $post ) ) {
			return $post_id;
		}

		/*
		 * Classic album editor posts modula-settings. REST title/status saves and
		 * other non-classic writers omit that bag; treat omission as "no protection
		 * change" rather than an intentional disable. An empty array is also not a
		 * classic form submission (the form always posts other settings keys).
		 */
		if (
			! isset( $_POST['modula-settings'] ) ||
			! is_array( $_POST['modula-settings'] ) ||
			array() === $_POST['modula-settings']
		) {
			return $post_id;
		}

		global $wpdb;

		if ( ! isset( $_POST['modula-settings']['enable_password'] ) && '' === $post->post_password ) {
			return $post_id;
		} elseif ( ! isset( $_POST['modula-settings']['enable_password'] ) && '' !== $post->post_password ) {
			$wpdb->update( $wpdb->posts, array( 'post_password' => '' ), array( 'ID' => $post_id ) );
		} elseif ( isset( $_POST['modula-settings']['password'] ) && '' !== $_POST['modula-settings']['password'] ) {
			$args = array(
				'post_password' => sanitize_text_field( $_POST['modula-settings']['password'] ),
			);
			// This write skips wp_insert_post, so check publishing here.
			if ( current_user_can( 'publish_post', $post_id ) ) {
				$args['post_status'] = 'publish';
			}
			$wpdb->update( $wpdb->posts, $args, array( 'ID' => $post_id ) );
		}
		//phpcs:enable
	}

	/**
	 * Sync WordPress post_password from flat album settings after a v2 REST save.
	 *
	 * Classic editor continues to use {@see save_extra_fields()} via save_post + $_POST.
	 * A PATCH that omits the passwordProtect group leaves post_password unchanged.
	 *
	 * @param int                                 $post_id  Album post ID.
	 * @param array<string, array<string, mixed>> $grouped  Grouped v2 settings (unused; flat is source of truth).
	 * @param array<string, mixed>                $flat     Flat modula-album-settings.
	 * @param array<string, mixed>|null           $incoming Incoming PATCH groups; null means always sync.
	 * @return void
	 */
	public function sync_post_password_from_settings_v2( $post_id, $grouped = array(), $flat = array(), $incoming = null ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || 'modula-album' !== get_post_type( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Explicit omit vs disable: unrelated PATCH groups must not touch the gate.
		if ( is_array( $incoming ) && ! array_key_exists( 'passwordProtect', $incoming ) ) {
			return;
		}

		if ( ! is_array( $flat ) ) {
			$flat = get_post_meta( $post_id, 'modula-album-settings', true );
		}
		if ( ! is_array( $flat ) ) {
			return;
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}

		$enabled  = isset( $flat['enable_password'] ) && 1 === absint( $flat['enable_password'] );
		$password = isset( $flat['password'] ) ? sanitize_text_field( (string) $flat['password'] ) : '';

		global $wpdb;

		// Match classic behaviour: disabling protection clears the WP gate.
		if ( ! $enabled ) {
			if ( '' !== (string) $post->post_password ) {
				$wpdb->update(
					$wpdb->posts,
					array( 'post_password' => '' ),
					array( 'ID' => $post_id ),
					array( '%s' ),
					array( '%d' )
				);
				clean_post_cache( $post_id );
			}
			return;
		}

		// Enabled but empty password field: keep existing post_password (classic does the same).
		if ( '' === $password ) {
			return;
		}

		if ( (string) $post->post_password === $password ) {
			return;
		}

		// Do not force post_status here — REST saves must not republish drafts.
		$wpdb->update(
			$wpdb->posts,
			array( 'post_password' => $password ),
			array( 'ID' => $post_id ),
			array( '%s' ),
			array( '%d' )
		);
		clean_post_cache( $post_id );
	}

	/**
	 * Add albums defaults
	 *
	 * @param $defaults
	 *
	 * @return mixed
	 *
	 * @since 1.0.4
	 */
	public function album_password_protect_defaults( $defaults ) {
		$defaults['enable_password']           = 0;
		$defaults['password']                  = '';
		$defaults['password_protect_username'] = '';
		$defaults['password_protect_text']     = '';

		return $defaults;
	}

		/***
	 * Add protect_textarea field type
	 *
	 * @param $html
	 * @param $field
	 * @param $value
	 *
	 * @return string
	 */
	public function password_field_type( $html, $field, $value ) {
		$initial_password = ! empty( $value ) ? $value : wp_generate_password( 18 );
		$pass_exists      = ! empty( $value ) ? true : false;
		ob_start();
		?>
		<div class="modula-password">
			<div class="modula-password-input-wrapper">
				<input type="<?php echo ( $pass_exists ? 'password' : 'text' ); ?>" data-setting="<?php echo esc_attr( $field['id'] ); ?>" name="modula-settings[<?php echo esc_attr( $field['id'] ); ?>]" id="modula-password-protect-password" class="regular-text" autocomplete="new-password" spellcheck="false" data-reveal="1" value="<?php echo esc_attr( $initial_password ); ?>" aria-describedby="modula-password-protect-pasword" />
				<div style="display:none" id="pass-strength-result" aria-live="polite"></div>
				<button type="button" class="modula-password-visibility-toggle" data-toggle="<?php echo ( $pass_exists ? 0 : 1 ); ?>" aria-label="<?php esc_attr_e( 'Toggle show/hide password', 'modula-pro' ); ?>">
					<span class="dashicons dashicons-<?php echo ( $pass_exists ? 'visibility' : 'hidden' ); ?>"></span>
				</button>
			</div>
			<a href="#" title="Copy password" class="copy-modula-password button button-primary dashicons dashicons-format-gallery" style="width:40px;"></a>
			<span></span>
		</div>
		<?php
		return ob_get_clean();
	}
}
