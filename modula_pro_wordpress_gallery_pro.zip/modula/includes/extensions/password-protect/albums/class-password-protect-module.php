<?php
namespace Modula_Pro\Extensions\Password_Protect\Albums;

use Modula_Pro\Extensions\Albums\Utils\Fields_Helper;
use Modula_Pro\Extensions\Password_Protect\Password_Protect_Module as Gallery_Password_Protect_Module;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *
 * @since   1.0.2
 *
 * @package Modula_Pro\Extensions\Password_Protect\Albums
 * @author  WPChill
 */
class Password_Protect_Module {

	/**
	 * The cookie that holds the username a visitor gave for an album, by album ID.
	 */
	private const USERNAME_COOKIE_PREFIX = 'modula_albums_password_protect_email_';

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.2
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.2
	 */
	public function __construct() {

		add_action( 'login_form_postpass', array( $this, 'username_validation' ) );
		add_filter( 'modula_albums_pre_output_filter_check', array( $this, 'password_protect_albums_check' ), 10, 3 );
		add_filter( 'modula_albums_pre_output_filter', array( $this, 'password_protect_albums' ), 10, 3 );
		add_filter( 'the_password_form', array( $this, 'modula_password_form' ), 15, 2 );
		add_filter( 'the_password_form', array( $this, 'modula_password_form_message' ), 30, 2 );
		add_filter( 'post_password_expires', array( $this, 'modula_albums_password_expires' ) );
	}

	/**
	 * Customize cookie expire time for password.
	 *
	 * @param int $expires The expiry time, as passed to setcookie().
	 *
	 * @return  mixed|void
	 * @since 1.0.2
	 *
	 */
	public function modula_albums_password_expires( $expires ) {
		// default is 10 days.
		$expires = apply_filters( 'modula_albums_password_protect_time_limit', time() + 864000, false, false );

		return $expires;
	}

	/**
	 * Customize message for password.
	 *
	 * @since 1.0.2
	 */
	public function change_password_message_content( $output ) {

		// Grab the album ID from the form.
		$start     = 'id="pwbox-';
		$end       = '"';
		$start_pos = strpos( $output, $start ) + strlen( $start );
		$end_pos   = strpos( $output, $end, $start_pos );
		$id        = substr( $output, $start_pos, ( $end_pos - $start_pos ) );

		// Check we got a valid ID.
		if ( ! is_numeric( $id ) ) {
			return $output;
		}

		// Check if post is a Modula Album Post.
		global $post;

		if ( ! in_array( $post->post_type, array( 'modula-album' ), true ) ) {
			return $output;
		}

		$settings = get_post_meta( $post->ID, 'modula-album-settings', true );

		$message = ( isset( $settings['password_protect_text'] ) && ! empty( $settings['password_protect_text'] ) ) ? $settings['password_protect_text'] : false;

		$message = apply_filters( 'modula_albums_password_protect_message', $message, $post, $settings );

		if ( ! empty( $post->post_password ) && true === post_password_required( $post ) ) {
			$output = '

			<form action="' . get_option( 'siteurl' ) . '/wp-pass.php" method="post">
			  ' . $message . '

			    <label for="post_password">' . esc_html__( 'Password', 'modula-pro' ) . ':</label>
			    <input name="post_password" class="input" type="password" size="20" />
			    <input type="submit" name="Submit" class="button" value="' . esc_html__( 'Submit', 'modula-pro' ) . '" />

			</form>

			';

			return $output;
		} else {
			return $output;
		}
	}


	/**
	 * Checks if the given Modula Album requires a username as part of the validation
	 * process.
	 * If validation passes, we store the username in a cookie, and continue.
	 *
	 * @since 1.0.0
	 */
	public function username_validation() {
		//phpcs:disable
		// Check if Post ID and Username are specified in the POST request.
		if ( ! isset( $_POST['post_ID'] ) || ! isset( $_POST['password_protect_username'] ) ) {
			return;
		}

		$id                    = absint( $_POST['post_ID'] );
		$modula_album_defaults = Fields_Helper::get_defaults();
		$modula_settings       = wp_parse_args( get_post_meta( $id, 'modula-album-settings', true ), $modula_album_defaults );

		// Check if the email address / username matches the one from the gallery.
		$email = isset( $modula_settings['password_protect_username'] ) ? $modula_settings['password_protect_username'] : '';

		if ( isset( $email ) && ! empty( $email ) ) {
			if ( $email !== $_POST['password_protect_username'] ) {
				// Username doesn't match so redirect to referring page.
				$redirect = wp_get_referer();
				wp_safe_redirect( $redirect ? $redirect : home_url( '/' ) );
				die();
			}

			// If here, username matches.
			// Set cookie.
			$time_limit = apply_filters( 'modula_albums_password_protect_time_limit', time() + 864000, $id, $modula_settings );
			$expire     = time() + intval( $time_limit );

			setcookie( self::USERNAME_COOKIE_PREFIX . $id, $email, intval( $expire ) );
		}
		//phpcs:enable
	}

	/**
	 * Password protect an album, if password protection is enabled
	 *
	 * @param array $modula_settings Album Data
	 * @param int   $id              Modula Album ID
	 *
	 * @return mixed false (if password required) or Gallery Form
	 * @since 1.0.2
	 *
	 */
	public function password_protect_albums( $pre_output, $modula_settings, $album ) {

		// Check if Post is password protected, and if so whether the password has been provided.
		if ( $this->username_given( $modula_settings, $album ) && post_password_required( $album ) === false ) {
			return false;
		}

		// check current post type so that if standalone is active the password form won't be displayed twice
		if ( 'modula-album' !== get_post_type() ) {
			// Assign password form to variable.
			$pre_output = get_the_password_form( $album );
		}

		return $pre_output;
	}

	/**
	 * @param $return_obj
	 * @param $modula_settings
	 * @param $album
	 * @return bool
	 *
	 * Check if post is password protected
	 */
	public function password_protect_albums_check( $return_obj, $modula_settings, $album ) {

		// Only do this on the frontend.
		if ( is_admin() ) {
			return false;
		}

		// Return if we couldn't get the Modula Album
		if ( ! $album ) {
			return false;
		}

		// Unlocked only with the password and, when the album asks for one, the username, as for galleries.
		if ( post_password_required( $album ) === false && $this->username_given( $modula_settings, $album ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Whether the visitor gave the album's username, when it asks for one:
	 * the cookie `username_validation()` sets must hold it. WordPress sets
	 * the password cookie on its own, so the password alone must not unlock
	 * an album that asks for a username. Turning protection off clears the
	 * password but keeps the username, so it counts only while the album has
	 * a password (the gallery checks `enable_password` for the same reason).
	 *
	 * @param array<string, mixed> $modula_settings Album flat settings.
	 * @param int                  $album           Album ID.
	 * @return bool True when no username is asked for.
	 */
	private function username_given( $modula_settings, $album ) {
		$email = isset( $modula_settings['password_protect_username'] ) ? (string) $modula_settings['password_protect_username'] : '';
		if ( '' === $email || '' === (string) get_post_field( 'post_password', $album ) ) {
			return true;
		}

		$cookie = self::USERNAME_COOKIE_PREFIX . $album;
		return isset( $_COOKIE[ $cookie ] ) && $_COOKIE[ $cookie ] === $email; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- Compared, never stored or printed; username_validation() sets it unslashed.
	}


	/**
	 * Checks if the given form belongs to an Modula Album, and display a custom message if Modula Album has one.
	 *
	 * @param string $output Output
	 *
	 * @return string Output
	 * @since 1.0.0
	 *
	 */
	public function modula_password_form_message( $output, $post ) {

		if ( ! $post ) {
			// Backwards compatibility wp <5.8. There's no function var or public exposure, so grab the ID from the form
			$start     = 'id="pwbox-';
			$end       = '"';
			$start_pos = strpos( $output, $start ) + strlen( $start );
			$end_pos   = strpos( $output, $end, $start_pos );
			$id        = substr( $output, $start_pos, ( $end_pos - $start_pos ) );

			// Check we got a valid ID
			if ( ! is_numeric( $id ) ) {
				return $output;
			}

			$post = get_post( $id );
		} else {
			$id = $post->ID;
		}

		if ( ! $post || ! in_array( $post->post_type, array( 'modula-album' ), true ) ) {
			return $output;
		}

		$modula_settings = get_post_meta( $id, 'modula-album-settings', true );
		if ( ! is_array( $modula_settings ) ) {
			$modula_settings = array();
		}

		$message = ( ! empty( $modula_settings['password_protect_text'] ) ) ? $modula_settings['password_protect_text'] : false;
		$message = apply_filters( 'modula_albums_password_protect_message', $message, $post, $modula_settings );

		if ( ! $message ) {
			return $output;
		}

		return $this->replace_password_form_intro_message( $output, $message );
	}

	/**
	 * Swap the core password-form intro paragraph for the album Protect text.
	 *
	 * @param string $output  Password form HTML.
	 * @param string $message Custom protect text from album settings.
	 * @return string
	 */
	private function replace_password_form_intro_message( $output, $message ) {
		if ( ! is_string( $output ) || '' === $output ) {
			return $output;
		}

		$message_html = wp_kses_post( $message );
		$defaults     = array_unique(
			array_filter(
				array(
					__( 'This content is password-protected. To view it, please enter the password below.' ),
					__( 'This content is password protected. To view it please enter your password below:' ),
					'This content is password-protected. To view it, please enter the password below.',
					'This content is password protected. To view it please enter your password below:',
					'This content is password protected. Please enter a password to view.',
				)
			)
		);

		$replaced = $output;
		foreach ( $defaults as $default ) {
			$replaced = str_replace( $default, $message_html, $replaced );
		}

		if ( $replaced !== $output ) {
			return $replaced;
		}

		$fallback = preg_replace(
			'#(<p>)(.*?)(</p>\s*<p>\s*<label\b[^>]*>)#is',
			'$1' . $message_html . '$3',
			$output,
			1
		);

		return is_string( $fallback ) ? $fallback : $output;
	}

	/**
	 * Checks if the given form belongs to an Modula Album POST, and if that gallery
	 * requires a username as well, prepends the form with a username field
	 *
	 * @param string $output Output
	 *
	 * @return string Output
	 * @since 1.0.0
	 *
	 */
	public function modula_password_form( $output, $post ) {

		if ( ! $post ) {
			// Backwards compatibility wp <5.8. There's no function var or public exposure, so grab the ID from the form
			$start     = 'id="pwbox-';
			$end       = '"';
			$start_pos = strpos( $output, $start ) + strlen( $start );
			$end_pos   = strpos( $output, $end, $start_pos );
			$id        = substr( $output, $start_pos, ( $end_pos - $start_pos ) );

			// Check we got a valid ID
			if ( ! is_numeric( $id ) ) {
				return $output;
			}

			$post = get_post( $id );
		} else {
			$id = $post->ID;
		}

		if ( ! in_array( $post->post_type, array( 'modula-album' ), true ) ) {
			return $output;
		}

		$modula_settings = get_post_meta( $id, 'modula-album-settings', true );

		$username_field = '<p><label for="username-' . esc_attr( $id ) . '">' . esc_html__( 'Username', 'modula-pro' ) . ': <input type="text" name="password_protect_username" id="username-' . esc_attr( $id ) . '" value="" /></label></p>';

		$email = $modula_settings['password_protect_username'] ?? '';

		if ( isset( $email ) && ! empty( $email ) ) {
			$output = str_replace( "</p>\n", $username_field, $output );
			$output = str_replace( '</form>', '<input type="hidden" name="post_ID" value="' . esc_attr( $id ) . '" /></form>', $output );
		}

		return Gallery_Password_Protect_Module::without_core_redirect_field( $output );
	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @return object The Password_Protect_Module object.
	 * @since 1.0.0
	 *
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Password_Protect_Module ) ) {
			self::$instance = new Password_Protect_Module();
		}

		return self::$instance;
	}
}
