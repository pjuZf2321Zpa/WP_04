<?php
namespace Modula_Pro\Extensions\Password_Protect;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Enqueue {
	private $extension_url = 'includes/extensions/password-protect';

	public function __construct() {
		// Load conditional js
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ), 25 );
	}

	public function admin_scripts( $hook ) {
		// Get current screen.
		$screen = get_current_screen();

		// Check if is modula custom post type
		if ( 'modula-gallery' !== $screen->post_type && 'modula-defaults' !== $screen->post_type ) {
			return;
		}

		// Only load on post editor screens.
		if ( 'post-new.php' !== $hook && 'post.php' !== $hook ) {
			return;
		}

		modula_pro_ensure_condition_scripts_registered();

		wp_enqueue_script( 'modula-password-protect-conditions', \MODULA_PRO_URL . $this->extension_url . '/assets/js/wp-modula-password-conditional.js', array( 'user-profile', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-password-protect-admin', \MODULA_PRO_URL . $this->extension_url . '/assets/css/modula-password-protect-admin.css', array(), \MODULA_PRO_VERSION );
	}
}
