<?php
namespace Modula_Pro\Extensions\Comments\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Comments_Custom_Columns {
	/**
	 * The single instance of the class.
	 *
	 * @var Settings
	 *
	 * @since 1.0.0
	 */
	public static $instance = null;

	/**
	 * Class Constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Add custom columns to the comments list table.
		add_filter( 'manage_edit-comments_columns', array( $this, 'add_custom_columns' ) );
		// Add the content to the custom columns.
		add_action( 'manage_comments_custom_column', array( $this, 'add_custom_column_content' ), 10, 2 );
		// Add image id meta to the admin reply.
		add_action( 'comment_post', array( $this, 'save_admin_reply' ) );

		// Hides edit-comments.php 'View Item' links.
		add_action( 'admin_head', array( $this, 'hide_view_item' ) );
	}

	/**
	 * Main Comments_Custom_Columns Instance.
	 *
	 * Ensures only one instance of Comments_Custom_Columns is loaded or can be loaded.
	 *
	 * @return Comments_Custom_Columns - Main instance.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Comments_Custom_Columns ) ) {
			self::$instance = new Comments_Custom_Columns();
		}

		return self::$instance;
	}

	/**
	 * Add custom columns to the comments list table.
	 *
	 * @param array $columns The list of columns.
	 *
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function add_custom_columns( $columns ) {
		$columns['modula_comment_image'] = __( 'Modula Image Comment', 'modula-pro' );

		return $columns;
	}

	/**
	 * Add the content to the custom columns.
	 *
	 * @param string $column  The column name.
	 * @param int $comment The comment ID.
	 *
	 * @since 1.0.0
	 */
	public function add_custom_column_content( $column, $comment ) {
		if ( 'modula_comment_image' === $column ) {
			$comment_image = get_comment_meta( $comment, 'modula_image_id', true );

			if ( ! empty( $comment_image ) ) {
				$url = wp_get_attachment_image_url( $comment_image, 'thumbnail' );
				echo '<img src="' . esc_url( $url ) . '" style="max-width: 100px; height: auto;" />';
			} else {
				echo esc_html__( 'No image', 'modula-pro' );
			}
		}
	}

	/**
	 * Save the admin reply and update the comment meta.
	 *
	 * @param int $comment_id The ID of the reply comment.
	 *
	 * @since 1.0.0
	 */
	public function save_admin_reply( $comment_id ) {
		$reply             = get_comment( $comment_id );
		$parent_comment_id = $this->reduce_parent_id( $reply->comment_parent );
		$parent_comment    = get_comment( $parent_comment_id );

		if ( null === $parent_comment_id || 0 === $parent_comment_id ) {
			return;
		}

		if ( 'modula_comment' !== $parent_comment->comment_type ) {
			return;
		}

		$comment_data = array(
			'comment_ID'     => $reply->comment_ID,
			'comment_type'   => $parent_comment->comment_type,
			'comment_parent' => $parent_comment_id,
		);

		wp_update_comment( $comment_data );

		$comment_image = get_comment_meta( $parent_comment_id, 'modula_image_id', true );
		if ( empty( $comment_image ) || 0 === $comment_image ) {
			return;
		}

		add_comment_meta( $comment_id, 'modula_image_id', absint( $comment_image ), true );
	}

	/**
	 * Recursively find the top-level parent comment ID.
	 *
	 * @param int $parent_comment_id The ID of the parent comment.
	 * @return int The top-level parent comment ID.
	 *
	 * @since 1.0.0
	 */
	private function reduce_parent_id( $parent_comment_id ) {
		$comment = get_comment( $parent_comment_id );

		if ( empty( $comment->comment_parent ) ) {
			return $parent_comment_id;
		}

		return $this->reduce_parent_id( $comment->comment_parent );
	}

	/**
	 * Hide the "View Item" link in the admin panel for Modula Gallery comments.
	 *
	 * @since 1.0.0
	 */
	public function hide_view_item() {
		$post_id = false;
		if ( isset( $_GET['p'] ) ) {
			$post_id = intval( $_GET['p'] );
		} elseif ( isset( $_GET['c'] ) && isset( $_GET['action'] ) && 'editcomment' === $_GET['action'] ) {
			$comm    = intval( $_GET['c'] );
			$post_id = get_comment( $comm )->comment_post_ID;
		}

		if ( get_post_type( $post_id ) === 'modula-gallery' ) {
			echo '<style>
				#wpadminbar #wp-admin-bar-view { display:none; }
				#wpbody .comments-view-item-link { display:none; }
				#wpbody #comment-link-box { display:none; }
				#misc-publishing-actions .misc-pub-reply-to { display:none; }
			</style>';
		}
	}
}
