<?php
namespace Modula_Pro\Extensions\Comments\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Comments_Filter {

	/**
	 * The single instance of the class.
	 *
	 * @var Settings
	 *
	 * @since 1.0.0
	 */
	public static $instance = null;

	/**
	 * Class Constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Add modula_comment comment type to the list of comment types.
		add_filter( 'admin_comment_types_dropdown', array( $this, 'filter_by_comment_type' ) );
		// Add custom filters to the comments list table.
		add_action( 'restrict_manage_comments', array( $this, 'add_custom_filters' ) );
		// Add the filters to the query.
		add_filter( 'pre_get_comments', array( $this, 'filter_comments' ) );
	}

	/**
	 * Main Comments_Filter Instance.
	 *
	 * Ensures only one instance of Comments_Filter is loaded or can be loaded.
	 *
	 * @return Comments_Filter - Main instance.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Comments_Filter ) ) {
			self::$instance = new Comments_Filter();
		}

		return self::$instance;
	}

	/**
	 * Add Modula Comments to the list of comment types.
	 *
	 * @param array $comment_types The list of comment types.
	 *
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function filter_by_comment_type( $comment_types ) {
		$comment_types['modula_comment'] = __( 'Modula Comments', 'modula-pro' );

		return $comment_types;
	}

	/**
	 * Add custom filters to the comments list table.
	 *
	 * @since 1.0.0
	 */
	public function add_custom_filters() {
		$this->add_gallery_filter();
	}

	/**
	 * Add a filter to the comments list table to filter by gallry ID.
	 *
	 * @since 1.0.0
	 */
	private function add_gallery_filter() {
		//phpcs:ignore WordPress.Security
		$selected = isset( $_GET['modula_gallery_id'] ) ? $_GET['modula_gallery_id'] : '';

		// Try to get post value instead.
		if ( empty( $selected ) && isset( $_GET['p'] ) ) {
			$selected = absint( $_GET['p'] );
		}

		global $wpdb;
		// Get all galleries.
		$galleries = get_posts(
			array(
				'post_type'      => 'modula-gallery',
				'posts_per_page' => -1,
				'meta_query'     => array( // Get all galleries that have comments enabled.
					array(
						'key'     => 'modula-settings',
						'value'   => '"comment_status";b:1',
						'compare' => 'LIKE',
						'type'    => 'CHAR',
					),
				),
			)
		);

		$html = '';
		// Create custom SQL to query for comments that belong to a specific gallery.
		// Use this because of the pre_get_comments filter.
		global $wpdb;
		$sql = "SELECT COUNT(comment_ID) FROM {$wpdb->comments} WHERE comment_post_ID = %d";
		foreach ( $galleries as $gallery ) {
			$cache_key      = 'modula_comments_count_' . $gallery->ID;
			$comments_count = wp_cache_get( $cache_key );

			if ( false === $comments_count ) {
				//phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$comments_count = absint( $wpdb->get_var( $wpdb->prepare( $sql, absint( $gallery->ID ) ) ) );
				wp_cache_set( $cache_key, $comments_count, '', 3600 ); // Cache for 1 hour
			}
			// Don't show galleries with no comments.
			if ( ! $comments_count ) {
				continue;
			}
			$html .= '<option value="' . esc_attr( $gallery->ID ) . '" ' . selected( $selected, $gallery->ID, false ) . '>' . esc_html( $gallery->post_title ) . '</option>';
		}
		?>
		<select name="modula_gallery_id">
			<option value=""><?php esc_html_e( 'All Galleries', 'modula-pro' ); ?></option>
			<?php //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo( $html ); ?>
		</select>
		<?php
	}

	/**
	 * Add the post_id query arg to the query based on gallery ID.
	 *
	 * @param \WP_Comment_Query $query The comments query.
	 *
	 * @return \WP_Comment_Query
	 *
	 * @since 1.0.0
	 */
	public function filter_comments( $query ) {

		// Add the gallery ID filter.
		if ( ! empty( $_GET['modula_gallery_id'] ) ) {
			$query->query_vars['post_id'] = absint( $_GET['modula_gallery_id'] ); // phpcs:ignore
		}

		//phpcs:ignore WordPress.Security
		if ( ! empty( $_GET['modula_gallery_image'] ) ) {
			//phpcs:ignore WordPress.DB
			$query->query_vars['meta_query'] = array(
				array(
					'key'     => 'modula_gallery_image',
					'value'   => absint( $_GET['modula_gallery_image'] ), // phpcs:ignore
					'compare' => '=',
				),
			);
		}

		if ( ! empty( $_GET['comment_status'] ) && 'mine' === $_GET['comment_status'] ) {
			$user_id                      = get_current_user_id();
			$query->query_vars['user_id'] = $user_id;
		}
		return $query;
	}
}
