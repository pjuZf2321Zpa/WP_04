<?php
namespace Modula_Pro\Extensions\Comments\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Modula Comments admin settings class.
 */
class Settings {

	/**
	 * The single instance of the class.
	 *
	 * @var Settings
	 *
	 * @since 1.0.0
	 */
	public static $instance = null;

	/**
	 * Class Constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Add comments support to the Modula custom post type.
		add_filter( 'modula_cpt_args', array( $this, 'add_comments_support' ) );
		// Add comments tab for Modula custom post type.
		add_filter( 'modula_gallery_tabs', array( $this, 'cpt_comments_tab' ) );
		// Add comments settings.
		add_filter( 'modula_gallery_fields', array( $this, 'add_comments_settings' ), 45 );
		// Update post comment status on modula-settings postmeta update.
		add_action( 'wp_insert_post_data', array( $this, 'set_comment_status' ), 15, 1 );
		// Remove the comments metabox.
		add_action( 'add_meta_boxes', array( $this, 'remove_comments_metabox' ), 99 );

		add_action( 'modula_scripts_after_wp_modula', array( $this, 'comments_conditions_admin_scripts' ) );
		add_action( 'modula_defaults_scripts_after_wp_modula', array( $this, 'comments_conditions_admin_scripts' ) );
	}

	/**
	 * Main Settings Instance.
	 *
	 * Ensures only one instance of Settings is loaded or can be loaded.
	 *
	 * @return Settings - Main instance.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Settings ) ) {
			self::$instance = new Settings();
		}

		return self::$instance;
	}

	/**
	 * Add comments support to the Modula custom post type.
	 *
	 * @param array $args The post type arguments.
	 *
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function add_comments_support( $args ) {
		$args['supports'][] = 'comments';
		return $args;
	}

	/**
	 * Add comments tab for Modula custom post type.
	 *
	 * @param array $tabs The tabs.
	 *
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function cpt_comments_tab( $tabs ) {
		$tabs['comments'] = array(
			'title'    => __( 'Comments', 'modula-pro' ),
			'label'    => esc_html__( 'Comments', 'modula-pro' ),
			'icon'     => 'dashicons dashicons-admin-comments',
			'docs_url' => 'https://wp-modula.com/kb/modula-comments/',
			'priority' => 80,
		);

		return $tabs;
	}

	/**
	 * Add comments settings.
	 *
	 * @param array $fields
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function add_comments_settings( $fields ) {
		$fields['comments'] = array(
			'comment_status'  => array(
				'name'      => esc_html__( 'Comments', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 39,
				'children'  => array( 'toggle_comments' ),
				'data_type' => 'bool',
			),
			'toggle_comments' => array(
				'name'      => esc_html__( 'Lightbox Toggle Comments', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 1,
				'priority'  => 50,
				'children'  => array( 'start_collapsed' ),
				'data_type' => 'bool',
				'is_child'  => true,
			),
			'start_collapsed' => array(
				'name'      => esc_html__( 'Start Hidden', 'modula-pro' ),
				'type'      => 'toggle',
				'default'   => 0,
				'priority'  => 51,
				'data_type' => 'bool',
				'is_child'  => 'two',
			),
		);

		// Add "Toggle Comments" button to toolbar's children so it can show/hide it.
		if ( isset( $fields['lightboxes']['lightbox_toolbar']['children'] ) ) {
			$fields['lightboxes']['lightbox_toolbar']['children'][] = 'toggle_comments';
		}

		return $fields;
	}

	/**
	 * Update post comment status on when updating the post.
	 *
	 * @param array $data The post data.
	 *
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function set_comment_status( $data ) {
		if ( empty( $_POST['post_type'] ) || 'modula-gallery' !== sanitize_text_field( wp_unslash( $_POST['post_type'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $data;
		}
		if ( empty( $_POST['modula-settings']['comment_status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$comment_status = 'closed';
		} else {
			$comment_status_post = sanitize_text_field( wp_unslash( $_POST['modula-settings']['comment_status'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			$comment_status = ( '1' === $comment_status_post || 'open' === $comment_status_post ) ? 'open' : 'closed'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		$data['comment_status'] = $comment_status;

		return $data;
	}

	/**
	 * Remove the comments metaboxes.
	 *
	 * @since 1.0.0
	 */
	public function remove_comments_metabox() {
		remove_meta_box( 'commentstatusdiv', 'modula-gallery', 'normal' );
		remove_meta_box( 'commentsdiv', 'modula-gallery', 'normal' );
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @since 1.0.0
	 */
	public function comments_conditions_admin_scripts() {
		wp_enqueue_script( 'modula-comments-conditions', \MODULA_PRO_URL . 'includes/extensions/comments/public/conditions/index.js', array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
	}
}
