<?php
namespace Modula_Pro\Extensions\Comments;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Comments {

	/**
	 * The single instance of the class.
	 *
	 * @var Comments
	 *
	 * @since   1.0.0
	 */
	public static $instance = null;

	/**
	 * Class Constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Initialize classes.
		$this->init_classes();
		// Set admin hooks.
		if ( is_admin() ) {
			// Initialize admin classes.
			$this->init_admin_classes();
		}
	}

	/**
	 * Modula_Comments Instance.
	 *
	 * Ensures only one instance of Main is loaded or can be loaded.
	 *
	 * @return Comments - Comments instance.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Comments ) ) {
			self::$instance = new Comments();
		}

		return self::$instance;
	}

	/**
	 * Init admin classes.
	 *
	 * @since 1.0.0
	 */
	public function init_admin_classes() {
		Admin\Settings::get_instance();
		Admin\Comments_Filter::get_instance();
		Admin\Comments_Custom_Columns::get_instance();
	}

	/**
	 * Initialize classes.
	 *
	 * @since 1.0.0
	 */
	public function init_classes() {
		Comment\Type::get_instance();
		new Rest_API\WP_Rest_Modula_Comments_Controller();
		Front\Requirements::get_instance();
		Front\Fancybox_Config::get_instance();
		Front\Front_Display::get_instance();
	}
}
