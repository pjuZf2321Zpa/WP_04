<?php
namespace Modula_Pro\Extensions\Comments\Front;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Requirements {
	/**
	 * The single instance of the class.
	 *
	 * @var Requirements
	 *
	 * @since   1.0.0
	 */
	public static $instance = null;

	/**
	 * Main Requirements Instance.
	 *
	 * Ensures only one instance of Requirements is loaded or can be loaded.
	 *
	 * @return Requirements - Main instance.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Requirements ) ) {
			self::$instance = new Requirements();
		}

		return self::$instance;
	}

	/**
	 * Class Constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Fired by legacy + v2 shortcode when a gallery is rendered on the page.
		add_action( 'modula_extra_scripts', array( $this, 'enqueue_scripts' ), 10, 1 );
	}

	/**
	 * Enqueue scripts when a gallery with comments enabled is on the page.
	 *
	 * Works for both legacy jQuery galleries and the beta (v2) React stack —
	 * both fire `modula_extra_scripts` from their shortcode enqueue path.
	 *
	 * @param array $settings Flat gallery settings.
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts( $settings = array() ) {
		if ( ! Fancybox_Config::is_comments_enabled_for_settings( $settings ) ) {
			return;
		}

		if ( class_exists( '\Modula\V2\Modern_Gallery' ) ) {
			$gallery_id = \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( $settings );
			if ( $gallery_id && \Modula\V2\Modern_Gallery::is_modern_stack_enabled( $gallery_id ) ) {
				$this->enqueue_beta_loader();
				return;
			}
		}

		if ( wp_script_is( 'modula-gallery-comments', 'enqueued' ) ) {
			return;
		}

		$asset_file = require \MODULA_PRO_PATH . 'includes/extensions/comments/public/gallery-comments/index.asset.php';
		$deps       = array_merge( $asset_file['dependencies'], array() );

		// Legacy jQuery galleries register modula-fancybox; v2 React galleries do not need it.
		if ( wp_script_is( 'modula-fancybox', 'registered' ) ) {
			$deps[] = 'modula-fancybox';
		}

		$enqueue = array(
			'handle'       => 'modula-gallery-comments',
			'dependencies' => $deps,
			'version'      => $asset_file['version'],
			'script'       => \MODULA_PRO_URL . 'includes/extensions/comments/public/gallery-comments/index.js',
			'style'        => \MODULA_PRO_URL . 'includes/extensions/comments/public/gallery-comments/index.css',
		);

		wp_enqueue_script(
			$enqueue['handle'],
			$enqueue['script'],
			$enqueue['dependencies'],
			$enqueue['version'],
			true
		);

		wp_localize_script(
			$enqueue['handle'],
			'modulaGalleryCommentsApi',
			array(
				'root'  => esc_url_raw( rest_url() ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);

		// The classic Fancybox toggle retains its Dashicons dependency.
		wp_enqueue_style(
			$enqueue['handle'],
			$enqueue['style'],
			array( 'dashicons' ),
			$enqueue['version']
		);

		wp_set_script_translations(
			'modula-gallery-comments',
			'modula-pro',
			\MODULA_PRO_PATH . 'languages'
		);
	}

	/** Register only the first-use loader and shared WordPress dependencies for Beta. */
	private function enqueue_beta_loader() {
		$handle = 'modula-gallery-comments-beta';
		if ( wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}
		$base = 'includes/extensions/comments/public/gallery-comments/beta/';
		$asset = require \MODULA_PRO_PATH . $base . 'beta.asset.php';
		wp_enqueue_script( $handle, \MODULA_PRO_URL . $base . 'beta.js', $asset['dependencies'], $asset['version'], true );
		wp_localize_script(
			$handle,
			'modulaGalleryCommentsApi',
			array(
				'root' => esc_url_raw( rest_url() ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
		add_filter( 'load_script_textdomain_relative_path', array( $this, 'beta_translations_path' ) );
		wp_set_script_translations( $handle, 'modula-pro', \MODULA_PRO_PATH . 'languages' );
	}

	/**
	 * The Beta strings live in the lazy-loaded `comments.<hash>.js` chunk, not in `beta.js`,
	 * so point the loader's translation lookup at the chunk's JSON file.
	 *
	 * @param string|false $relative Script path relative to the plugin root.
	 * @return string|false
	 */
	public function beta_translations_path( $relative ) {
		$base = 'includes/extensions/comments/public/gallery-comments/beta/';
		if ( $base . 'beta.js' !== $relative ) {
			return $relative;
		}

		$chunks = glob( \MODULA_PRO_PATH . $base . 'comments.*.js' );

		return empty( $chunks ) ? $relative : $base . basename( $chunks[0] );
	}
}
