<?php
namespace Modula_Pro\Extensions\Comments\Front;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Fancybox_Config {
	/**
	 * The single instance of the class.
	 *
	 * @var Fancybox_Config
	 *
	 * @since   1.0.0
	 */
	public static $instance = null;

	/**
	 * Main Fancybox_Config Instance.
	 *
	 * Ensures only one instance of Fancybox_Config is loaded or can be loaded.
	 *
	 * @return Fancybox_Config - Main instance.
	 *
	 * @since 1.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Fancybox_Config ) ) {
			self::$instance = new Fancybox_Config();
		}

		return self::$instance;
	}

	/**
	 * Class Constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Add the comments template to the lightbox if comments are enabled
		add_filter( 'modula_fancybox_options', array( $this, 'lightbox_comments_template' ), 30, 2 );
		add_filter( 'modula_fancybox_options', array( $this, 'lightbox_comments_button' ), 45, 2 );
		add_filter( 'modula_modern_shortcode_data', array( $this, 'inject_v2_bootstrap_metadata' ), 10, 3 );
	}

	/**
	 * Whether gallery comments are enabled in flat settings.
	 *
	 * @param array $settings Flat gallery settings.
	 * @return bool
	 */
	public static function is_comments_enabled_for_settings( $settings ) {
		return is_array( $settings ) && ! empty( $settings['comment_status'] );
	}

	/**
	 * Runtime payload consumed by the gallery-comments React bundle.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return array<string, mixed>|null
	 */
	public static function build_gallery_comments_payload( $gallery_id ) {
		$gallery_id = absint( $gallery_id );
		if ( $gallery_id < 1 ) {
			return null;
		}

		$user = wp_get_current_user()->data;

		return array(
			'galleryId'           => $gallery_id,
			'galleryAuthorId'     => (int) get_post_field( 'post_author', $gallery_id ),
			'requireNameEmail'    => get_option( 'require_name_email' ),
			'commentRegistration' => get_option( 'comment_registration' ),
			'threadedComments'    => get_option( 'thread_comments' ),
			'commentsPerPage'     => get_option( 'page_comments' ) ? get_option( 'comments_per_page' ) : 100,
			'showAvatars'         => get_option( 'show_avatars' ),
			'loginUrl'            => wp_login_url(),
			'user'                => $user,
			'userAvatar'          => isset( $user->ID ) ? get_avatar_url( $user->ID ) : get_avatar_url( 0 ),
		);
	}

	/**
	 * Inject galleryComments into v2 React bootstrap metadata.
	 *
	 * @param array $gallery_data Bootstrap payload.
	 * @param array $flat         Flat gallery settings.
	 * @param int   $gallery_id   Gallery post ID.
	 * @return array
	 */
	public function inject_v2_bootstrap_metadata( $gallery_data, $flat, $gallery_id ) {
		if ( ! self::is_comments_enabled_for_settings( $flat ) ) {
			return $gallery_data;
		}

		$payload = self::build_gallery_comments_payload( $gallery_id );
		if ( empty( $payload ) ) {
			return $gallery_data;
		}

		if ( ! isset( $gallery_data['metadata'] ) || ! is_array( $gallery_data['metadata'] ) ) {
			$gallery_data['metadata'] = array();
		}

		$payload['betaGallery'] = true;
		$gallery_data['metadata']['galleryComments'] = $payload;

		return $gallery_data;
	}

	/**
	 * Lightbox comments template
	 *
	 * @param array $config The config array.
	 * @param array $settings The settings array.
	 *
	 * return array $config The config array.
	 *
	 * @since 1.0.0
	 */
	public function lightbox_comments_template( $config, $settings ) {
		// Add the comments template to the lightbox if comments are enabled
		if ( self::is_comments_enabled_for_settings( $settings ) ) {
			$state                 = isset( $settings['start_collapsed'] ) && $settings['start_collapsed'] && isset( $settings['toggle_comments'] ) && $settings['toggle_comments'];
			$config['tpl']['main'] = '<div class="fancybox__container has-sidebar" role="dialog" aria-modal="true" aria-label="{{MODAL}}" tabindex="-1">
                <div class="fancybox__backdrop"></div>
                <div class="fancybox__cols ' . ( $state ? 'sidebar-hidden' : '' ) . ' ">
                <div class="fancybox__col fancybox__image_holder">
                    <div class="fancybox__carousel"></div>
                    <div class="fancybox__footer"></div>
                </div>
                <div id="modula-comments-wrapper" class="fancybox__col">
                </div>
                </div>
            </div>';
			// Add the gallery ID and options to the config
			if ( isset( $settings['gallery_id'] ) && ! empty( $settings['gallery_id'] ) ) {
				$gallery_id = preg_replace( '/[^0-9]/', '', $settings['gallery_id'] );
				$payload    = self::build_gallery_comments_payload( (int) $gallery_id );
				if ( ! empty( $payload ) ) {
					$config['galleryComments'] = $payload;
				}
			}
		}

		return $config;
	}

	/**
	 * Add am "Open Comments" button in lightbox
	 *
	 * @param array $config
	 * @param array $settings
	 *
	 * @return array $config
	 * @since 1.0.0
	 */
	public function lightbox_comments_button( $config, $settings ) {

		// Check if comments are enabled for this gallery.
		if ( ! self::is_comments_enabled_for_settings( $settings ) ) {
			return $config;
		}

		// Check if toolbar button should show for this gallery.
		if ( ! isset( $settings['toggle_comments'] ) || ! boolval( $settings['toggle_comments'] ) ) {
			return $config;
		}

		$config['Toolbar']['items']['toggleComments']['tpl'] = '<button class="modula-fancybox-button f-button" id="modula-comments-toggle" title="' . esc_attr__( 'Toggle Comments', 'modula-pro' ) . '"><span class="dashicons dashicons-admin-comments"></span></button>';

		array_unshift( $config['Toolbar']['display']['right'], 'toggleComments' );

		return $config;
	}
}
