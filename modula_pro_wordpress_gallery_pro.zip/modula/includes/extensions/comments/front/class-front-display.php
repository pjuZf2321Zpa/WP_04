<?php
namespace Modula_Pro\Extensions\Comments\Front;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Front_Display
 *
 * Class used to display comments on the front end.
 *
 * @package Modula_Comments\Front
 *
 * @since 1.0.0
 */
class Front_Display {

	/**
	 * The single instance of the class.
	 *
	 * @var Front_Display
	 *
	 * @since 1.0.0
	 */
	public static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Front_Display ) ) {
			self::$instance = new Front_Display();
		}

		return self::$instance;
	}

	/**
	 * Front_Display constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Check if commetns are enabled and parse the data.
		add_filter( 'modula_shortcode_item_data', array( $this, 'comments_enabled' ), 30, 3 );
		// Comments social icon.
		add_filter( 'modula_get_icon', array( $this, 'comments_svg_icon' ), 15, 2 );
		// Add anonymous comments.
		add_action( 'init', array( $this, 'anonymous_comments' ) );
		// Add default for the comment_status field.
		add_filter( 'modula_lite_default_settings', array( $this, 'add_comments_settings_defaults' ) );
		// Set comments open by default.
		add_filter( 'comments_open', array( $this, 'comments_open' ), 10, 2 );
	}

	/**
	 * Check if comments are enabled.
	 *
	 * @param object $item_data The item data object.
	 *
	 * @since 1.0.0
	 */
	public function comments_enabled( $item_data, $image, $settings ) {
		if ( $settings['comment_status'] ) {
			$item_data['comments_enabled'] = true;
		} else {
			$item_data['comments_enabled'] = false;
		}

		return $item_data;
	}

	/**
	 * Allow anonymous comments in the REST api.
	 *
	 * @since 1.0.0
	 */
	public function anonymous_comments() {
		add_filter( 'rest_allow_anonymous_comments', array( $this, 'allow_anonymous_rest_comments' ), 10, 2 );
	}

	/**
	 * Allow guest REST comments only on the Modula comments namespace.
	 *
	 * @since 3.0.0
	 *
	 * @param bool            $allow   Whether anonymous comments are allowed.
	 * @param WP_REST_Request $request The REST request.
	 * @return bool
	 */
	public function allow_anonymous_rest_comments( $allow, $request ) {
		if ( get_option( 'comment_registration' ) ) {
			return false;
		}

		if ( ! $request instanceof \WP_REST_Request ) {
			return $allow;
		}

		$route = $request->get_route();
		if ( is_string( $route ) && str_starts_with( $route, '/modula-comments/v1/' ) ) {
			return true;
		}

		return $allow;
	}

	/**
	 * Add default for the comment_status field.
	 *
	 * @param array $defaults The default settings.
	 *
	 * @return array
	 *
	 * @since 1.0.0
	 */
	public function add_comments_settings_defaults( $defaults ) {
		$defaults['comment_status']  = 1;
		$defaults['toggle_comments'] = 1;
		$defaults['start_collapsed'] = 0;
		return $defaults;
	}

	/**
	 * Sets comments open for galleries with comments enabled, and closed on attachments.
	 *
	 * @param bool $comments_open Whether comments are open.
	 * @param int  $post_id       The post ID.
	 * @return bool|string
	 *
	 * @since 1.0.0
	 */
	public function comments_open( $comments_open, $post_id ) {

		if ( $post_id && 'attachment' === get_post_type( $post_id ) ) {
			return false;
		}

		// Bail if already open.
		if ( 'open' === $comments_open ) {
			return $comments_open;
		}

		if ( 'modula-gallery' !== get_post_type( $post_id ) ) {
			return $comments_open;
		}

		$settings = get_post_meta( $post_id, 'modula-settings', true );

		if ( ! isset( $settings['toggle_comments'] ) || ( isset( $settings['toggle_comments'] ) && boolval( $settings['toggle_comments'] ) ) ) {
			return 'open';
		}

		return $comments_open;
	}
}
