<?php return array('dependencies' => array(), 'version' => '700d34b3b85e6ef9a0dd');
