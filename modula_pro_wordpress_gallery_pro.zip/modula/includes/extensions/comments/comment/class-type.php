<?php
namespace Modula_Pro\Extensions\Comments\Comment;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Type {

	/**
	 * The single instance of the class.
	 *
	 * @var Type
	 */
	public static $instance = null;


	/**
	 * Class constructor
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Register custom comment meta
		add_action( 'init', array( $this, 'set_comment_meta' ), 15 );
	}

	/**
	 * Get the instance of the class
	 *
	 * @return Type
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Type ) ) {
			self::$instance = new Type();
		}

		return self::$instance;
	}

	/**
	 * Register the custom meta key for the comment
	 *
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function set_comment_meta() {

		$args = array(
			'type'         => 'integer', // Validate and sanitize the meta value as a string.
			'description'  => __( 'The image that the comment is associated with.', 'modula-pro' ), // Shown in the schema for the meta key.
			'single'       => true, // Return a single value of the type. Default: false.
			'show_in_rest' => true, // Show in the WP REST API response. Default: false.
		);

		register_meta( 'comment', 'modula_image_id', $args );
	}
}
