<?php
namespace Modula_Pro\Extensions\Comments\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Notifications
 *
 * Handles the new comment notifications.
 *
 * @since 1.0.0
 */
class Notifications {

	/**
	 * The single instance of the class.
	 *
	 * @var Notifications
	 *
	 * @since 1.0.0
	 */
	public static $instance = null;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Notifications ) ) {
			self::$instance = new Notifications();
		}

		return self::$instance;
	}

	/**
	 * Notifications constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
	}

	/**
	 * Display the missing dependencies notification.
	 *
	 * @since 1.0.0
	 */
	public static function missing_dependencies_notice() {
		$message = esc_html__( 'Modula Comments requires Modula and Modula PRO to be installed and activated.', 'modula-pro' );
		if ( class_exists( '\Modula_Notifications' ) ) {
			// Add a notification to the Modula_Notifications class.
			$notice = array(
				'title'   => esc_html__( 'Modula Comments dependencies', 'modula-pro' ),
				'message' => $message,
				'status'  => 'error',
			);

			\Modula_Notifications::add_notification( 'modula-comments-dependencies', $notice );
		} else { // If the Modula_Notifications class is not available, display a default WordPress notice.
			?>
			<div class="notice notice-error is-dismissible">
				<p><?php echo esc_html( $message ); ?></p>
			</div>
			<?php
		}
	}

	/**
	 * Notification for new comments.
	 *
	 * @param int $gallery_id The gallery ID.
	 * @param int $comment_id The comment ID.
	 *
	 * @since 1.0.0
	 */
	public function new_comment( $gallery_id, $comment_id ) {

		if ( ! class_exists( 'Modula_Notifications' ) ) {
			return;
		}
		$gallery_title          = get_the_title( $gallery_id );
		$filtered_comments_link = add_query_arg(
			array(
				'p'              => $gallery_id,
				'comment_status' => 'approved',
			),
			admin_url( 'edit-comments.php' )
		);

		$message = sprintf(
			/* translators: %s is the link to the gallery comments screen. */
			esc_html__( 'New comment on %s gallery.', 'modula-pro' ),
			'<a href="' . esc_url( $filtered_comments_link ) . '">' . esc_html( $gallery_title ) . '</a>'
		);
		$notice = array(
			'title'   => esc_html__( 'New comment', 'modula-pro' ),
			'message' => $message,
			'status'  => 'info',
		);
		// Add notification to the Modula_Notifications class based on the gallery ID
		// and image ID, with a random number to avoid duplicates.
		\Modula_Notifications::add_notification( "modula-$gallery_id-new-comment-$comment_id", $notice );
	}

	/**
	 * Notification for comments that need approval.
	 *
	 * @param int $gallery_id The gallery ID.
	 * @param int $comment_id The comment ID.
	 *
	 * @since 1.0.0
	 */
	public function comment_needs_approval( $gallery_id, $comment_id ) {
		if ( ! class_exists( 'Modula_Notifications' ) ) {
			return;
		}
		$gallery_title          = get_the_title( $gallery_id );
		$filtered_comments_link = add_query_arg(
			array(
				'p' => $gallery_id,
			),
			admin_url( 'edit-comments.php' )
		);

		$message = sprintf(
			/* translators: %s is the link to the gallery comments screen. */
			esc_html__( 'New comment on %s gallery needs approval.', 'modula-pro' ),
			'<a href="' . esc_url( $filtered_comments_link ) . '">' . esc_html( $gallery_title ) . '</a>'
		);
		$notice = array(
			'title'   => esc_html__( 'New comment needs approval', 'modula-pro' ),
			'message' => $message,
			'status'  => 'info',
		);
		// Add notification to the Modula_Notifications class based on the gallery ID
		// and image ID, with a random number to avoid duplicates.
		\Modula_Notifications::add_notification( "modula-$gallery_id-new-comment-$comment_id", $notice );
	}

	/**
	 * PRO license check function
	 *
	 * @since 1.0.0
	 */
	public static function modula_pro_license_notice() {

		$message    = esc_html__( 'In order to use Modula Comments addon with your gallery you\'ll need to activate your license ', 'modula-pro' ) . '<a href="' . esc_url( admin_url( 'edit.php?post_type=modula-gallery&page=modula&modula-tab=licenses' ) ) . '">' . esc_html__( 'here', 'modula-pro' );
			$notice = array(
				'title'   => esc_html__( 'License needed', 'modula-pro' ),
				'message' => $message,
				'status'  => 'info',
			);
			// Add notification to the Modula_Notifications class based on the gallery ID
			// and image ID, with a random number to avoid duplicates.
			\Modula_Notifications::add_notification( 'modula-comments-license', $notice );
	}
}
