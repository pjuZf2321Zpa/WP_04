<?php
namespace Modula_Pro\Extensions\Comments\Rest_API;

use Modula_Pro\Extensions\Comments\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Modula Comments REST Endpoints class.
 *
 * @since 1.0.0
 */
class WP_Rest_Modula_Comments_Controller extends \WP_REST_Comments_Controller {

		/**
	 * Instance of a comment meta fields object.
	 *
	 * @since 1.0.0
	 * @var WP_Rest_Modula_Comments_Controller $meta
	 */
	protected $meta;

	/**
	 * Modula Comments REST API namespace.
	 *
	 * @var string
	 *
	 * @since 1.0.0
	 */
	public $namespace = 'modula-comments/v1';

	/**
	 * Modula Comments comment REST API base.
	 *
	 * @var string
	 *
	 * @since 1.0.0
	 */
	public $rest_comments_base = 'comments';

	/**
	 * Modula Comments gallery REST API base.
	 *
	 * @var string
	 *
	 * @since 1.0.0
	 */
	public $rest_gallery_base = 'galleries';

	/**
	 * Modula Comments config REST API base.
	 *
	 * @var string
	 *
	 * @since 1.0.0
	 */
	public $rest_config_base = 'galleries';

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->meta = new WP_REST_Modula_Comment_Meta_Fields();
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Registers the routes for comments.
	 *
	 * @since 1.0.0
	 *
	 * @see register_rest_route()
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			"/{$this->rest_gallery_base}/(?P<gallery_id>[\d]+)/{$this->rest_comments_base}",
			array(
				'args'   => array(
					'gallery_id' => array(
						'description' => __( 'Unique identifier for the gallery.', 'modula-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => $this->get_collection_params(),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'create_item_permissions_check' ),
					'args'                => array_merge(
						$this->get_endpoint_args_for_item_schema( \WP_REST_Server::CREATABLE ),
						array(
							'image' => array(
								'description' => __( 'Attachment ID for the gallery image this comment belongs to.', 'modula-pro' ),
								'type'        => 'integer',
								'required'    => false,
							),
						)
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_comments_base . '/(?P<id>[\d]+)',
			array(
				'args'   => array(
					'id' => array(
						'description' => __( 'Unique identifier for the comment.', 'modula-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( \WP_REST_Server::EDITABLE ),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'delete_item_permissions_check' ),
					'args'                => array(
						'force'    => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Whether to bypass Trash and force deletion.', 'modula-pro' ),
						),
						'password' => array(
							'description' => __( 'The password for the parent post of the comment (if the post is password protected).', 'modula-pro' ),
							'type'        => 'string',
						),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/config/',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_comments_config' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);
	}

	/**
	 * Checks if a given request has access to read comments.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return true|WP_Error True if the request has read access, error object otherwise.
	 */
	public function get_items_permissions_check( $request ) {

		$gallery_id = isset( $request['gallery_id'] ) ? absint( $request['gallery_id'] ) : 0;
		if ( $gallery_id > 0 ) {
			$gallery_post = get_post( $gallery_id );
			if ( ! $gallery_post || 'modula-gallery' !== $gallery_post->post_type ) {
				return new \WP_Error(
					'rest_invalid_gallery',
					__( 'Invalid gallery.', 'modula-pro' ),
					array( 'status' => 404 )
				);
			}
			if ( ! $this->check_read_post_permission( $gallery_post, $request ) ) {
				return new \WP_Error(
					'rest_cannot_read_post',
					__( 'Sorry, you are not allowed to read the post for this comment.', 'modula-pro' ),
					array( 'status' => rest_authorization_required_code() )
				);
			}
		}

		if ( ! empty( $request['post'] ) ) {
			foreach ( (array) $request['post'] as $post_id ) {
				$post = get_post( $post_id );

				if ( ! empty( $post_id ) && $post && ! $this->check_read_post_permission( $post, $request ) ) {
					return new \WP_Error(
						'rest_cannot_read_post',
						__( 'Sorry, you are not allowed to read the post for this comment.', 'modula-pro' ),
						array( 'status' => rest_authorization_required_code() )
					);
				} elseif ( 0 === $post_id && ! current_user_can( 'moderate_comments' ) ) {
					return new \WP_Error(
						'rest_cannot_read',
						__( 'Sorry, you are not allowed to read comments without a post.', 'modula-pro' ),
						array( 'status' => rest_authorization_required_code() )
					);
				}
			}
		}

		if ( ! empty( $request['context'] ) && 'edit' === $request['context'] && ! current_user_can( 'moderate_comments' ) ) {
			return new \WP_Error(
				'rest_forbidden_context',
				__( 'Sorry, you are not allowed to edit comments.', 'modula-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			$protected_params = array( 'author', 'author_exclude', 'author_email', 'type', 'status' );
			$forbidden_params = array();

			foreach ( $protected_params as $param ) {
				if ( 'status' === $param ) {
					if ( 'approve' !== $request[ $param ] ) {
						$forbidden_params[] = $param;
					}
				} elseif ( 'type' === $param ) {
					if ( 'modula_comment' !== $request[ $param ] ) {
						$forbidden_params[] = $param;
					}
				} elseif ( ! empty( $request[ $param ] ) ) {
					$forbidden_params[] = $param;
				}
			}

			if ( ! empty( $forbidden_params ) ) {
				return new \WP_Error(
					'rest_forbidden_param',
					/* translators: %s: List of forbidden parameters. */
					sprintf( __( 'Query parameter not permitted: %s', 'modula-pro' ), implode( ', ', $forbidden_params ) ),
					array( 'status' => rest_authorization_required_code() )
				);
			}
		}

		return true;
	}

	/**
	 * Checks if a given request has access to create a comment.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return true|\WP_Error True if the request has access to create, error object otherwise.
	 */
	public function create_item_permissions_check( $request ) {
		$error = $this->validate_gallery_comment_parent( $request );
		if ( is_wp_error( $error ) ) {
			return $error;
		}

		return parent::create_item_permissions_check( $request );
	}

	/**
	 * A Modula comment parent must be a gallery, and match the route gallery when present.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return true|\WP_Error
	 */
	protected function validate_gallery_comment_parent( $request ) {
		$post_id = isset( $request['post'] ) ? absint( $request['post'] ) : 0;
		if ( ! $post_id ) {
			return true;
		}

		if ( 'modula-gallery' !== get_post_type( $post_id ) ) {
			return new \WP_Error(
				'rest_comment_invalid_post_type',
				__( 'Modula comments can only be created on a gallery.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}

		$gallery_id = isset( $request['gallery_id'] ) ? absint( $request['gallery_id'] ) : 0;
		if ( $gallery_id && $gallery_id !== $post_id ) {
			return new \WP_Error(
				'rest_comment_gallery_mismatch',
				__( 'The comment gallery does not match the request.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Creates a comment.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return WP_REST_Response|WP_Error Response object on success, or error object on failure.
	 */
	public function create_item( $request ) {

		// Check if the gallery ID is specified.
		if ( empty( $request['post'] ) ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_gallery_id_not_specified',
					__( 'Please specify the gallery ID.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}

		$parent_error = $this->validate_gallery_comment_parent( $request );
		if ( is_wp_error( $parent_error ) ) {
			wp_send_json_error( $parent_error );
		}

		// Do not allow comments to be created with a non-default type.
		if ( ! empty( $request['type'] ) && 'modula_comment' !== $request['type'] ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_invalid_comment_type',
					__( 'Cannot create a comment that is not a modula_comment type.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}

		$request['post']  = absint( $request['post'] );
		$gallery_id       = $request['post'];
		$prepared_comment = $this->prepare_item_for_database( $request );

		if ( is_wp_error( $prepared_comment ) ) {
			wp_send_json_error( $prepared_comment );
		}

		$prepared_comment['comment_type'] = 'modula_comment';

		if ( ! isset( $prepared_comment['comment_content'] ) ) {
			$prepared_comment['comment_content'] = '';
		}

		if ( ! $this->check_is_comment_content_allowed( $prepared_comment ) ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_comment_content_invalid',
					__( 'Invalid comment content.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}

		// Setting remaining values before wp_insert_comment so we can use wp_allow_comment().
		if ( ! isset( $prepared_comment['comment_date_gmt'] ) ) {
			$prepared_comment['comment_date_gmt'] = current_time( 'mysql', true );
		}

		// Set author data if the user's logged in.
		$missing_author = empty( $prepared_comment['user_id'] )
			&& empty( $prepared_comment['comment_author'] )
			&& empty( $prepared_comment['comment_author_email'] )
			&& empty( $prepared_comment['comment_author_url'] );

		if ( is_user_logged_in() && $missing_author ) {
			$user = wp_get_current_user();

			$prepared_comment['user_id']              = $user->ID;
			$prepared_comment['comment_author']       = $user->display_name;
			$prepared_comment['comment_author_email'] = $user->user_email;
			$prepared_comment['comment_author_url']   = $user->user_url;
		}

		// Honor the discussion setting that requires a name and email address of the comment author.
		if ( get_option( 'require_name_email' ) ) {
			if ( empty( $prepared_comment['comment_author'] ) || empty( $prepared_comment['comment_author_email'] ) ) {
				wp_send_json_error(
					new \WP_Error(
						'rest_comment_author_data_required',
						__( 'Creating a comment requires valid author name and email values.', 'modula-pro' ),
						array( 'status' => 400 )
					)
				);
			}
		}

		if ( ! isset( $prepared_comment['comment_author_email'] ) ) {
			$prepared_comment['comment_author_email'] = '';
		}

		if ( ! isset( $prepared_comment['comment_author_url'] ) ) {
			$prepared_comment['comment_author_url'] = '';
		}

		if ( ! isset( $prepared_comment['comment_agent'] ) ) {
			$prepared_comment['comment_agent'] = '';
		}

		$check_comment_lengths = wp_check_comment_data_max_lengths( $prepared_comment );

		if ( is_wp_error( $check_comment_lengths ) ) {
			$error_code = $check_comment_lengths->get_error_code();
			wp_send_json_error(
				new \WP_Error(
					$error_code,
					__( 'Comment field exceeds maximum length allowed.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}

		$prepared_comment['comment_approved'] = wp_allow_comment( $prepared_comment, true );

		if ( is_wp_error( $prepared_comment['comment_approved'] ) ) {
			$error_code    = $prepared_comment['comment_approved']->get_error_code();
			$error_message = $prepared_comment['comment_approved']->get_error_message();

			if ( 'comment_duplicate' === $error_code ) {
				wp_send_json_error(
					new \WP_Error(
						$error_code,
						$error_message,
						array( 'status' => 409 )
					)
				);
			}

			if ( 'comment_flood' === $error_code ) {
				wp_send_json_error(
					new \WP_Error(
						$error_code,
						$error_message,
						array( 'status' => 400 )
					)
				);
			}

			wp_send_json_success( $prepared_comment['comment_approved'] );
		}

		if ( is_wp_error( $prepared_comment ) ) {
			return $prepared_comment;
		}

		$comment_id = wp_insert_comment( wp_filter_comment( wp_slash( (array) $prepared_comment ) ) );

		if ( ! $comment_id ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_comment_failed_create',
					__( 'Creating comment failed.', 'modula-pro' ),
					array( 'status' => 500 )
				)
			);
		}

		if ( isset( $request['status'] ) ) {
			$this->handle_status_param( $request['status'], $comment_id );
		}

		$comment = get_comment( $comment_id );

		$image_meta = 0;
		if ( ! empty( $request['meta']['modula_image_id'] ) ) {
			$image_meta = absint( $request['meta']['modula_image_id'] );
		} elseif ( isset( $request['image'] ) && '' !== $request['image'] ) {
			$image_meta = absint( $request['image'] );
		}

		if ( $image_meta > 0 ) {
			add_comment_meta( $comment_id, 'modula_image_id', $image_meta );
		}

		$fields_update = $this->update_additional_fields_for_object( $comment, $request );

		if ( is_wp_error( $fields_update ) ) {
			wp_send_json_error( $fields_update );
		}

		$notification       = Utils\Notifications::get_instance();
		$comment_moderation = get_option( 'comment_moderation' );
		if ( ! $comment_moderation || 'approved' === wp_get_comment_status( $comment_id ) ) {
			$notification->new_comment( $gallery_id, $comment_id );
		} else {
			$notification->comment_needs_approval( $gallery_id, $comment_id );
		}

		$context = current_user_can( 'moderate_comments' ) ? 'edit' : 'view';
		$request->set_param( 'context', $context );
		$response = $this->prepare_item_for_response( $comment, $request );
		$response = rest_ensure_response( $response );

		$response->set_status( 201 );
		$response->header( 'Location', rest_url( sprintf( '%s/%s/%d', $this->namespace, $this->rest_base, $comment_id ) ) );

		wp_send_json_success( $response );
	}

	/**
	 * Retrieves the query params for collections.
	 *
	 * @since 1.0.0
	 *
	 * @return array Comments collection parameters.
	 */
	public function get_collection_params() {
		$query_params = parent::get_collection_params();

		$query_params['context']['default'] = 'view';

		$query_params['after'] = array(
			'description' => __( 'Limit response to comments published after a given ISO8601 compliant date.', 'modula-pro' ),
			'type'        => 'string',
			'format'      => 'date-time',
		);

		$query_params['author'] = array(
			'description' => __( 'Limit result set to comments assigned to specific user IDs. Requires authorization.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
		);

		$query_params['author_exclude'] = array(
			'description' => __( 'Ensure result set excludes comments assigned to specific user IDs. Requires authorization.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
		);

		$query_params['author_email'] = array(
			'default'     => null,
			'description' => __( 'Limit result set to that from a specific author email. Requires authorization.', 'modula-pro' ),
			'format'      => 'email',
			'type'        => 'string',
		);

		$query_params['before'] = array(
			'description' => __( 'Limit response to comments published before a given ISO8601 compliant date.', 'modula-pro' ),
			'type'        => 'string',
			'format'      => 'date-time',
		);

		$query_params['exclude'] = array(
			'description' => __( 'Ensure result set excludes specific IDs.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
			'default'     => array(),
		);

		$query_params['include'] = array(
			'description' => __( 'Limit result set to specific IDs.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
			'default'     => array(),
		);

		$query_params['offset'] = array(
			'description' => __( 'Offset the result set by a specific number of items.', 'modula-pro' ),
			'type'        => 'integer',
		);

		$query_params['order'] = array(
			'description' => __( 'Order sort attribute ascending or descending.', 'modula-pro' ),
			'type'        => 'string',
			'default'     => 'asc',
			'enum'        => array(
				'asc',
				'desc',
			),
		);

		$query_params['orderby'] = array(
			'description' => __( 'Sort collection by comment attribute.', 'modula-pro' ),
			'type'        => 'string',
			'default'     => 'date_gmt',
			'enum'        => array(
				'date',
				'date_gmt',
				'id',
				'include',
				'post',
				'parent',
				'type',
			),
		);

		$query_params['parent'] = array(
			'default'     => array(),
			'description' => __( 'Limit result set to comments of specific parent IDs.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
		);

		$query_params['parent_exclude'] = array(
			'default'     => array(),
			'description' => __( 'Ensure result set excludes specific parent IDs.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
		);

		$query_params['post'] = array(
			'default'     => array(),
			'description' => __( 'Limit result set to comments assigned to specific post IDs.', 'modula-pro' ),
			'type'        => 'array',
			'items'       => array(
				'type' => 'integer',
			),
		);

		$query_params['status'] = array(
			'default'           => 'approve',
			'description'       => __( 'Limit result set to comments assigned a specific status. Requires authorization.', 'modula-pro' ),
			'sanitize_callback' => 'sanitize_key',
			'type'              => 'string',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$query_params['type'] = array(
			'default'           => 'modula_comment',
			'description'       => __( 'Limit result set to comments assigned a specific type. Requires authorization.', 'modula-pro' ),
			'sanitize_callback' => 'sanitize_key',
			'type'              => 'string',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$query_params['password'] = array(
			'description' => __( 'The password for the post if it is password protected.', 'modula-pro' ),
			'type'        => 'string',
		);

		$query_params['image'] = array(
			'description' => __( 'Limit result set to comments for a specific gallery image attachment ID.', 'modula-pro' ),
			'type'        => 'integer',
			'required'    => true,
		);

		return $query_params;
	}

	/**
	 * Retrieves a list of comment items for a gallery specific image.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return WP_REST_Response|WP_Error Response object on success, or error object on failure.
	 */
	public function get_items( $request ) {

		if ( empty( $request['gallery_id'] ) ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_gallery_id_not_specified',
					__( 'Gallery ID not specified.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}

		if ( ! isset( $request['image'] ) || '' === $request['image'] ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_image_id_not_specified',
					__( 'Image ID not specified.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}

		$gallery_id = absint( $request['gallery_id'] );
		$image_id   = absint( $request['image'] );

		if ( $image_id < 1 ) {
			wp_send_json_error(
				new \WP_Error(
					'rest_image_id_not_specified',
					__( 'Image ID not specified.', 'modula-pro' ),
					array( 'status' => 400 )
				)
			);
		}
		$limit  = ! empty( $request['per_page'] ) ? absint( $request['per_page'] ) : 20;
		$page   = ! empty( $request['page'] ) && 0 !== absint( $request['page'] ) ? absint( $request['page'] ) : 1;
		$offset = ( $page - 1 ) * $limit;
		global $wpdb;
		$sql = "SELECT 
					parent.comment_ID AS comment_ID,
					parent.comment_content AS comment_content,
					parent.user_id AS user_id,
					parent.comment_date AS comment_date,
					parent.comment_post_ID AS comment_post_ID,
					parent.comment_approved AS comment_approved,
					parent.comment_author_email AS comment_author_email,
					parent.comment_author_url AS comment_author_url,
					parent.comment_author AS comment_author,
					COALESCE(children.children_list, '') AS replies,
					cc.total_comments AS total_comments
				FROM 
					{$wpdb->comments} parent
				INNER JOIN {$wpdb->commentmeta} AS meta ON parent.comment_ID = meta.comment_id AND meta.meta_key = 'modula_image_id'
				CROSS JOIN ( 
				SELECT COUNT(comments.comment_ID) as total_comments FROM {$wpdb->comments} comments
				INNER JOIN {$wpdb->commentmeta} meta ON comments.comment_ID = meta.comment_id AND meta.meta_key = 'modula_image_id'
				WHERE 
				comments.comment_type = 'modula_comment' AND comments.comment_approved = 1 AND comments.comment_parent = 0 AND comments.comment_post_ID = %d
				AND meta.meta_value = %d ) cc ON 1=1
				LEFT JOIN (
					SELECT 
						comment_parent,
						GROUP_CONCAT(JSON_OBJECT(
                            'comment_ID', comment_ID,
                            'comment_content', comment_content,
                            'user_id', user_id,
                            'comment_date', comment_date,
                            'comment_post_ID', comment_post_ID,
                            'comment_approved', comment_approved,
							'comment_author_email', comment_author_email,
							'comment_author_url', comment_author_url,
							'comment_author', comment_author
                        ) ORDER BY comment_date DESC SEPARATOR '%modula_comments%') AS children_list
					FROM 
						{$wpdb->comments}
					WHERE 
						comment_parent != 0 AND comment_type = 'modula_comment' AND comment_approved = 1
					GROUP BY 
						comment_parent
				) AS children ON parent.comment_ID = children.comment_parent
				WHERE 
					parent.comment_parent = 0 AND parent.comment_post_ID = %d AND meta.meta_value = %d and parent.comment_type = 'modula_comment' AND parent.comment_approved = 1
				GROUP BY 
					parent.comment_ID
				ORDER BY 
					parent.comment_date DESC
				LIMIT %d OFFSET %d
				";
		// Set the max length of the group_concat function to 1000000
		$wpdb->query( 'SET SESSION group_concat_max_len = 1000000' );

		//phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$comments       = $wpdb->get_results( $wpdb->prepare( $sql, $gallery_id, $image_id, $gallery_id, $image_id, $limit, $offset ) );
		$total_comments = 0;
		$can_see_emails = current_user_can( 'moderate_comments' );
		if ( ! empty( $comments ) ) {
			foreach ( $comments as $key => $comment ) {
				$comments[ $key ]->comment_date = human_time_diff( strtotime( $comment->comment_date ), strtotime( current_time( 'mysql' ) ) ) . ' ' . esc_html__( 'ago', 'modula-pro' );
				$comments[ $key ]->user_avatar  = get_avatar_url( $comment->user_id );
				if ( ! $can_see_emails ) {
					unset( $comments[ $key ]->comment_author_email );
				}
				$unformatted_replies = explode( '%modula_comments%', $comment->replies );
				$replies             = array();
				foreach ( $unformatted_replies as $reply_key => $reply ) {
					if ( empty( $reply ) ) {
						continue;
					}
					$decoded_reply = json_decode( $reply, true );
					if ( json_last_error() === JSON_ERROR_NONE && isset( $decoded_reply['comment_date'] ) ) {
						$decoded_reply['user_avatar']  = get_avatar_url( $decoded_reply['user_id'] );
						$decoded_reply['comment_date'] = human_time_diff( strtotime( $decoded_reply['comment_date'] ), strtotime( current_time( 'mysql' ) ) ) . ' ' . esc_html__( 'ago', 'modula-pro' );
						if ( ! $can_see_emails ) {
							unset( $decoded_reply['comment_author_email'] );
						}
						$replies[] = $decoded_reply;
					}
				}
				$comments[ $key ]->replies = $replies;
				$total_comments            = $comment->total_comments;
			}
		}
		$response = array(
			'total_comments' => $total_comments,
			'comments'       => $comments,
		);
		//sleep( 10 );
		$response = rest_ensure_response( $response );
		return $response;
	}

	/**
	 * Updates a comment.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return bool|WP_Error Response bool on success, or error object on failure.
	 *
	 * @since 1.0.0
	 */
	public function update_item_permissions_check( $request ) {

		$comment = $this->get_comment( $request['id'] );
		if ( is_wp_error( $comment ) ) {
			return $comment;
		}

		$current_user = wp_get_current_user();
		// User needs to be logged in to delete a comment.
		if ( ! $current_user->exists() ) {
			return new \WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you need a valid account in order to edit comments.', 'modula-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}
		// Allow admins to do anything.
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		// Users can only delete their own comments.
		if ( absint( $comment->user_id ) !== ( $current_user->ID ) ) {
			return new \WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you are not allowed to edit this comment.', 'modula-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		return true;
	}

	/**
	 * Permissions to delete a comment.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return bool|WP_Error Response bool on success, or error object on failure.
	 *
	 * @since 1.0.0
	 */
	public function delete_item_permissions_check( $request ) {

		$comment = $this->get_comment( $request['id'] );
		if ( is_wp_error( $comment ) ) {
			return $comment;
		}

		$current_user = wp_get_current_user();

		// User needs to be logged in to delete a comment.
		if ( ! $current_user->exists() ) {
			return new \WP_Error(
				'rest_cannot_delete',
				__( 'Sorry, you need a valid account in order to delete comments.', 'modula-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}
		// Allow admins to do anything.
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		// Users can only delete their own comments.
		if ( absint( $comment->user_id ) !== absint( $current_user->ID ) ) {
			return new \WP_Error(
				'rest_cannot_delete',
				__( 'Sorry, you are not allowed to delete this comment.', 'modula-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		return true;
	}

	/**
	 * Get the comments configuration.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return WP_Comment|WP_Error Comment object or WP_Error.
	 *
	 * @since 1.0.0
	 */
	public function get_comments_config( $request ) {
		$current_user = wp_get_current_user();
		$user_payload = array(
			'ID'           => 0,
			'display_name' => '',
			'user_email'   => '',
		);
		if ( $current_user->exists() ) {
			$user_payload = array(
				'ID'           => (int) $current_user->ID,
				'display_name' => $current_user->display_name,
				'user_email'   => $current_user->user_email,
			);
		}
		$config = array(
			'requireNameEmail'    => get_option( 'require_name_email' ),
			'commentRegistration' => get_option( 'comment_registration' ),
			'threadedComments'    => get_option( 'thread_comments' ),
			'commentsPerPage'     => get_option( 'page_comments' ) ? get_option( 'comments_per_page' ) : 100, // Limit is 100 set by Wp
			'showAvatars'         => get_option( 'show_avatars' ),
			'loginUrl'            => wp_login_url(),
			'user'                => $user_payload,
			'userAvatar'          => $current_user->exists() ? get_avatar_url( $current_user->ID ) : get_avatar_url( 0 ),
		);

		$response = rest_ensure_response( $config );
		return $response;
	}

	/**
	 * Permissions check for the comments config.
	 *
	 * @param [type] $request
	 * @return void
	 *
	 * @since 1.0.0
	 */
	public function permissions_check( $request ) {
		return true; // Return true to send the data when called for.
	}
}
