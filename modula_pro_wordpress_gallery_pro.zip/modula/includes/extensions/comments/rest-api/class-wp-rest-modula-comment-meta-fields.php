<?php
namespace Modula_Pro\Extensions\Comments\Rest_API;

/**
 * REST API: WP_REST_Modula_Comment_Meta_Fields class
 *
 * This is a modified copy of the WP_REST_Comment_Meta_Fields class
 *
 * @package WordPress
 * @subpackage REST_API
 * @since 1.0.0
 */

/**
 * Class to manage comment meta via the REST API.
 *
 * @since 1.0.0
 *
 * @see WP_REST_Meta_Fields
 */
class WP_REST_Modula_Comment_Meta_Fields extends \WP_REST_Meta_Fields {

	/**
	 * Retrieves the comment type for comment meta.
	 *
	 * @since 1.0.0
	 *
	 * @return string The meta type.
	 */
	protected function get_meta_type() {
		return 'comment';
	}

	/**
	 * Retrieves the comment meta subtype.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	protected function get_meta_subtype() {
		return 'comment';
	}

	/**
	 * Retrieves the type for register_rest_field() in the context of comments.
	 *
	 * @since 1.0.0
	 *
	 * @return string The REST field type.
	 */
	public function get_rest_field_type() {
		return 'comment';
	}
}
