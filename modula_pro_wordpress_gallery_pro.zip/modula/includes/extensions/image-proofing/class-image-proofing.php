<?php
namespace Modula_Pro\Extensions\Image_Proofing;

use Modula_Pro\Extensions\Standalone\Standalone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Image_Proofing {
	public static $instance;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Image_Proofing ) ) {
			self::$instance = new Image_Proofing();
		}

		return self::$instance;
	}

	public function __construct() {
		require_once __DIR__ . '/abilities/class-proofing-executor.php';
		require_once __DIR__ . '/abilities/class-selection-executor.php';
		require_once __DIR__ . '/abilities/class-client-executor.php';
		require_once __DIR__ . '/abilities/class-email-executor.php';
		require_once __DIR__ . '/abilities/class-provider.php';
		\Modula_Pro\Extensions\Image_Proofing\Abilities\Provider::boot();

		add_action( 'modula_extension_modula-image-proofing_activated', array( Plugin_Activator::class, 'activate' ) );

		add_action( 'init', array( $this, 'run_plugin' ) );
	}


	public function run_plugin() {
		User_Manager::setup_role();

		if ( is_admin() ) {
			new Modula_View_Override();
			new Admin\Settings_Editor_Integration();
		}

		new Gallery_Settings();
		new Email_Settings();
		Standalone::get_instance();
		new Rest_Api();
		new Frontend_Scripts();
		Front\Modern_Proofing_Bootstrap::get_instance();
		Front\Modern_Proofing_Scripts::get_instance();
		new Gallery_Protection();
	}
}
