<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Plugin_Activator {
	public static function activate() {
		static::create_tables();
	}

	private static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$annotations_table = $wpdb->prefix . 'modula_image_proofing_annotations';
		$selections_table  = $wpdb->prefix . 'modula_image_proofing_selections';
		$invitations_table = $wpdb->prefix . 'modula_image_proofing_invitations';

		$ant = "CREATE TABLE IF NOT EXISTS $annotations_table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            annotation_id VARCHAR(36) NOT NULL,
            image_id BIGINT UNSIGNED NOT NULL,
            user_id VARCHAR(255) NOT NULL,
            type VARCHAR(50) NOT NULL,
            geometry TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY image_id (image_id),
            KEY user_id (user_id)
        ) $charset_collate;";

		$slt = "CREATE TABLE IF NOT EXISTS $selections_table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            gallery_id BIGINT UNSIGNED NOT NULL,
            user_id VARCHAR(255) NOT NULL,
            selections LONGTEXT NOT NULL,
            notes TEXT DEFAULT NULL,
            submitted BOOLEAN DEFAULT FALSE,
            updated_at DATETIME NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (id),
            KEY (gallery_id),
            KEY user_id (user_id)
        ) $charset_collate;";

		$ivt = "CREATE TABLE IF NOT EXISTS $invitations_table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            gallery_id BIGINT UNSIGNED NOT NULL,
            user_id VARCHAR(255) NOT NULL,
            expired BOOLEAN DEFAULT FALSE,
            PRIMARY KEY (id),
            KEY gallery_id (gallery_id),
            KEY user_id (user_id)
        ) $charset_collate;
        ";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// Skip annotations table for now
		// dbDelta( $ant );
		// Create tables
		dbDelta( $slt );
		dbDelta( $ivt );
	}
}
