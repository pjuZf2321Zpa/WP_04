<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers Image Proofing email settings in the Modula general-settings app.
 *
 * @since 1.0.0
 */
class Email_Settings {

	const OPTION_NAME = 'modula_image_proofing_emails';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'modula_admin_page_subtabs', array( $this, 'add_subtab' ) );
		add_filter( 'modula_admin_page_main_tabs', array( $this, 'add_main_tab' ) );
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_options' ) );
	}

	/**
	 * Get default email settings.
	 *
	 * @return array
	 */
	public static function get_defaults() {
		return array(
			'from_name'  => get_bloginfo( 'name' ),
			'from_email' => get_option( 'admin_email' ),
			'reply_to'   => '',
			'logo_id'    => 0,
			'invitation' => array(
				'subject' => __( 'Image Proofing Invitation', 'modula-pro' ),
				'body'    => self::get_default_template( 'client-invitation' ),
			),
			'selection'  => array(
				'subject' => __( 'Client submitted an image selection', 'modula-pro' ),
				'body'    => self::get_default_template( 'selection-submission' ),
			),
		);
	}

	/**
	 * Get merged email settings (saved + defaults).
	 *
	 * @return array
	 */
	public static function get_settings() {
		$saved    = get_option( self::OPTION_NAME, array() );
		$defaults = self::get_defaults();

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$settings               = wp_parse_args( $saved, $defaults );
		$settings['logo_id']    = isset( $settings['logo_id'] ) ? absint( $settings['logo_id'] ) : 0;
		$settings['invitation'] = wp_parse_args(
			isset( $saved['invitation'] ) && is_array( $saved['invitation'] ) ? $saved['invitation'] : array(),
			$defaults['invitation']
		);
		$settings['selection']  = wp_parse_args(
			isset( $saved['selection'] ) && is_array( $saved['selection'] ) ? $saved['selection'] : array(),
			$defaults['selection']
		);

		$settings['invitation']['body'] = self::maybe_repair_body(
			$settings['invitation']['body'],
			'client-invitation'
		);
		$settings['selection']['body']  = self::maybe_repair_body(
			$settings['selection']['body'],
			'selection-submission'
		);

		return $settings;
	}

	/**
	 * Restore a body that was corrupted by wp_kses_post (stripped document tags),
	 * and drop the `data-mce-*` attributes the old TinyMCE editor saved.
	 *
	 * @param string $body          Saved body.
	 * @param string $template_name Template basename.
	 * @return string
	 */
	public static function maybe_repair_body( $body, $template_name ) {
		$default = self::get_default_template( $template_name );

		if ( '' === trim( (string) $body ) ) {
			return $default;
		}

		// Bodies saved under the old html/wp_kses_post sanitizer lost document tags.
		if ( trim( wp_kses_post( $default ) ) === trim( (string) $body ) ) {
			return $default;
		}

		// The same helper as Lite's email_html sanitizer; Lite releases before it keep the body as saved.
		if ( ! method_exists( 'Modula_Settings_Sanitizer', 'strip_mce_attributes' ) ) {
			return $body;
		}

		return \Modula_Settings_Sanitizer::strip_mce_attributes( $body );
	}

	/**
	 * Reset one or both email template bodies/subjects to file defaults.
	 *
	 * @param string $type invitation|selection|all.
	 * @return array Updated settings.
	 */
	public static function reset_template( $type = 'all' ) {
		$settings = self::get_settings();
		$defaults = self::get_defaults();

		if ( 'invitation' === $type || 'all' === $type ) {
			$settings['invitation'] = $defaults['invitation'];
		}

		if ( 'selection' === $type || 'all' === $type ) {
			$settings['selection'] = $defaults['selection'];
		}

		update_option( self::OPTION_NAME, $settings );

		return $settings;
	}

	/**
	 * Resolve the effective From name used when sending.
	 *
	 * @param array|null $settings Optional settings array.
	 * @return string
	 */
	public static function get_effective_from_name( $settings = null ) {
		if ( null === $settings ) {
			$settings = self::get_settings();
		}

		$from_name = isset( $settings['from_name'] ) ? trim( (string) $settings['from_name'] ) : '';

		if ( '' === $from_name ) {
			$from_name = get_bloginfo( 'name' );
		}

		return $from_name;
	}

	/**
	 * Resolve the effective From email used when sending.
	 *
	 * @param array|null $settings Optional settings array.
	 * @return string
	 */
	public static function get_effective_from_email( $settings = null ) {
		if ( null === $settings ) {
			$settings = self::get_settings();
		}

		$from_email = isset( $settings['from_email'] ) ? trim( (string) $settings['from_email'] ) : '';

		if ( '' === $from_email || ! is_email( $from_email ) ) {
			$from_email = get_option( 'admin_email' );
		}

		return $from_email;
	}

	/**
	 * Resolve the effective Reply-To email used when sending.
	 *
	 * @param array|null $settings Optional settings array.
	 * @return string
	 */
	public static function get_effective_reply_to( $settings = null ) {
		if ( null === $settings ) {
			$settings = self::get_settings();
		}

		$reply_to = isset( $settings['reply_to'] ) ? trim( (string) $settings['reply_to'] ) : '';

		if ( '' === $reply_to || ! is_email( $reply_to ) ) {
			return self::get_effective_from_email( $settings );
		}

		return $reply_to;
	}

	/**
	 * Build HTML for the {{logo}} placeholder from the saved attachment.
	 *
	 * @param array|null $settings Optional settings.
	 * @return string
	 */
	public static function get_logo_html( $settings = null ) {
		if ( null === $settings ) {
			$settings = self::get_settings();
		}

		$logo_id = isset( $settings['logo_id'] ) ? absint( $settings['logo_id'] ) : 0;

		if ( ! $logo_id ) {
			return '';
		}

		$url = wp_get_attachment_image_url( $logo_id, 'medium' );

		if ( ! $url ) {
			return '';
		}

		return sprintf(
			'<p style="margin:0 0 16px;"><img src="%1$s" alt="%2$s" style="max-width:200px;height:auto;display:block;" /></p>',
			esc_url( $url ),
			esc_attr__( 'Logo', 'modula-pro' )
		);
	}

	/**
	 * Load default HTML body from a template file.
	 *
	 * @param string $template_name Template basename without extension.
	 * @return string
	 */
	public static function get_default_template( $template_name ) {
		$template_path = \MODULA_PRO_PATH . 'includes/extensions/image-proofing/templates/' . $template_name . '.html';

		if ( ! file_exists( $template_path ) ) {
			return '';
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$content = file_get_contents( $template_path );

		return false === $content ? '' : $content;
	}

	/**
	 * Add Image Proofing subtab to the shared subtabs registry.
	 *
	 * @param array $subtabs Existing subtabs.
	 * @return array
	 */
	public function add_subtab( $subtabs ) {
		$subtabs['image_proofing'] = $this->get_subtab();

		return $subtabs;
	}

	/**
	 * Attach Image Proofing as its own main settings tab.
	 *
	 * @param array $tabs Existing main tabs.
	 * @return array
	 */
	public function add_main_tab( $tabs ) {
		$tabs[] = array(
			'label'   => esc_html__( 'Image Proofing', 'modula-pro' ),
			'slug'    => 'image_proofing',
			'subtabs' => array(
				'image_proofing' => $this->get_subtab(),
			),
		);

		return $tabs;
	}

	/**
	 * Register option for uninstall cleanup.
	 *
	 * @param array $options Uninstall option list.
	 * @return array
	 */
	public function uninstall_options( $options ) {
		$options[] = self::OPTION_NAME;

		return $options;
	}

	/**
	 * Build the Image Proofing settings subtab definition.
	 *
	 * @return array
	 */
	private function get_subtab() {
		$settings   = self::get_settings();
		$from_name  = self::get_effective_from_name( $settings );
		$from_email = self::get_effective_from_email( $settings );
		$logo_id    = isset( $settings['logo_id'] ) ? absint( $settings['logo_id'] ) : 0;
		$logo_src   = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : null;

		/* translators: 1: From name, 2: From email address */
		$preview = sprintf(
			esc_html__( 'Invitation emails are sent from: %1$s <%2$s>', 'modula-pro' ),
			esc_html( $from_name ),
			esc_html( $from_email )
		);

		$body_tip = esc_html__( 'Tip: empty lines in Visual mode become blank paragraph tags in Code view and create gaps at the top of the email. Switch to Code and delete empty tags above your content to close the gap.', 'modula-pro' );

		$invitation_placeholders = sprintf(
			/* translators: %s: comma-separated list of placeholders */
			esc_html__( 'Available placeholders: %s', 'modula-pro' ),
			'<code>{{logo}}</code>, <code>{{gallery_name}}</code>, <code>{{gallery_link}}</code>, <code>{{intro_text}}</code>, <code>{{subject}}</code>'
		) . '<br />' . $body_tip;

		$selection_placeholders = sprintf(
			/* translators: %s: comma-separated list of placeholders */
			esc_html__( 'Available placeholders: %s', 'modula-pro' ),
			'<code>{{logo}}</code>, <code>{{user_name}}</code>, <code>{{user_email}}</code>, <code>{{gallery_title}}</code>, <code>{{gallery_url}}</code>, <code>{{gallery_edit_url}}</code>, <code>{{selection_count}}</code>, <code>{{submitted_by_text}}</code>, <code>{{gallery_id}}</code>, <code>{{user_id}}</code>, <code>{{subject}}</code>'
		) . '<br />' . $body_tip;

		return array(
			'label'  => esc_html__( 'Email', 'modula-pro' ),
			'badge'  => null,
			'locked' => false,
			'config' => array(
				'option'  => self::OPTION_NAME,
				'submenu' => array(
					'class'   => 'modula_image_proofing_email_submenu',
					'options' => array(
						array(
							'label' => esc_html__( 'Sender', 'modula-pro' ),
							'value' => 'sender',
						),
						array(
							'label' => esc_html__( 'Invitation', 'modula-pro' ),
							'value' => 'invitation',
						),
						array(
							'label' => esc_html__( 'Photographer notification', 'modula-pro' ),
							'value' => 'selection',
						),
					),
				),
				'fields'  => array(
					array(
						'type'        => 'paragraph',
						'name'        => 'from_preview',
						'label'       => esc_html__( 'Sending address', 'modula-pro' ),
						'description' => $preview,
						'group'       => 'sender',
					),
					array(
						'type'         => 'text',
						'name'         => 'from_name',
						'label'        => esc_html__( 'From name', 'modula-pro' ),
						'default'      => $settings['from_name'],
						'description'  => esc_html__( 'The name recipients see as the sender.', 'modula-pro' ),
						'sanitization' => array( 'text' ),
						'group'        => 'sender',
					),
					array(
						'type'         => 'text',
						'name'         => 'from_email',
						'label'        => esc_html__( 'From email', 'modula-pro' ),
						'default'      => $settings['from_email'],
						'description'  => esc_html__( 'Use an address on your site domain for best deliverability.', 'modula-pro' ),
						'sanitization' => array( 'email' ),
						'group'        => 'sender',
					),
					array(
						'type'         => 'text',
						'name'         => 'reply_to',
						'label'        => esc_html__( 'Reply-to', 'modula-pro' ),
						'default'      => $settings['reply_to'],
						'description'  => esc_html__( 'Leave blank to use the From email address.', 'modula-pro' ),
						'sanitization' => array( 'email' ),
						'group'        => 'sender',
					),
					array(
						'type'             => 'image_select',
						'name'             => 'logo_id',
						'label'            => esc_html__( 'Logo', 'modula-pro' ),
						'default'          => $logo_id,
						'src'              => $logo_src,
						'description'      => esc_html__( 'Shown wherever you place the {{logo}} placeholder in invitation or notification emails.', 'modula-pro' ),
						'mediaTitle'       => esc_html__( 'Select email logo', 'modula-pro' ),
						'mediaButtonText'  => esc_html__( 'Use this logo', 'modula-pro' ),
						'uploadButtonText' => esc_html__( 'Set logo', 'modula-pro' ),
						'sanitization'     => array( 'number' ),
						'group'            => 'sender',
					),
					array(
						'type'           => 'button',
						'text'           => esc_html__( 'Send test email', 'modula-pro' ),
						'loadingText'    => esc_html__( 'Sending test email…', 'modula-pro' ),
						'successMessage' => esc_html__( 'Test email sent successfully.', 'modula-pro' ),
						'errorMessage'   => esc_html__( 'Failed to send test email. Please try again.', 'modula-pro' ),
						'group'          => 'sender',
						'api'            => array(
							'path'   => '/modula-image-proofing/v1/send-test-email',
							'method' => 'POST',
							'data'   => array(),
						),
					),
					array(
						'type'         => 'text',
						'name'         => 'invitation.subject',
						'label'        => esc_html__( 'Invitation subject', 'modula-pro' ),
						'default'      => $settings['invitation']['subject'],
						'sanitization' => array( 'text' ),
						'group'        => 'invitation',
					),
					array(
						'type'         => 'code_editor',
						'name'         => 'invitation.body',
						'label'        => esc_html__( 'Invitation message', 'modula-pro' ),
						'default'      => $settings['invitation']['body'],
						'description'  => $invitation_placeholders,
						'mode'         => 'htmlmixed',
						'wysiwyg'      => true,
						'defaultView'  => 'visual',
						'sanitization' => array( 'email_html' ),
						'group'        => 'invitation',
					),
					array(
						'type'    => 'button',
						'text'    => esc_html__( 'Reset to default', 'modula-pro' ),
						'variant' => 'secondary',
						'reload'  => true,
						'group'   => 'invitation',
						'api'     => array(
							'path'   => '/modula-image-proofing/v1/reset-email-template',
							'method' => 'POST',
							'data'   => array( 'type' => 'invitation' ),
						),
					),
					array(
						'type'         => 'text',
						'name'         => 'selection.subject',
						'label'        => esc_html__( 'Photographer notification subject', 'modula-pro' ),
						'default'      => $settings['selection']['subject'],
						'description'  => esc_html__( 'Email sent when a client submits their final selection. Recipient is set per gallery under Image Proofing settings (defaults to the gallery owner).', 'modula-pro' ),
						'sanitization' => array( 'text' ),
						'group'        => 'selection',
					),
					array(
						'type'         => 'code_editor',
						'name'         => 'selection.body',
						'label'        => esc_html__( 'Photographer notification message', 'modula-pro' ),
						'default'      => $settings['selection']['body'],
						'description'  => $selection_placeholders,
						'mode'         => 'htmlmixed',
						'wysiwyg'      => true,
						'defaultView'  => 'visual',
						'sanitization' => array( 'email_html' ),
						'group'        => 'selection',
					),
					array(
						'type'    => 'button',
						'text'    => esc_html__( 'Reset to default', 'modula-pro' ),
						'variant' => 'secondary',
						'reload'  => true,
						'group'   => 'selection',
						'api'     => array(
							'path'   => '/modula-image-proofing/v1/reset-email-template',
							'method' => 'POST',
							'data'   => array( 'type' => 'selection' ),
						),
					),
				),
			),
		);
	}
}
