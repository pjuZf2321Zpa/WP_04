<?php
/** Pro contribution for Proofing administration, accounts, invitation mail and selection moderation. */
namespace Modula_Pro\Extensions\Image_Proofing\Abilities;

use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Proofing;
use Modula\V2\Abilities\Proofing_Explanation;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Provider {
	public const ID = 'modula-pro-proofing';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! Pro_Dependency::extension_contract( 'modula-image-proofing' ) ) {
			return $contributions;
		}
		$names = Proofing_Explanation::names();
		foreach ( $names as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( array( Proofing_Executor::callbacks(), Selection_Executor::callbacks(), Client_Executor::callbacks(), Email_Executor::callbacks() ) as $callbacks ) {
			foreach ( $callbacks as $name => $execute ) {
				$operations[ $name ] = array( 'execute' => $execute );
			}
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck gallery or user-management admission and the Proofing feature before any effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Proofing_Explanation::blockers( $name, $input );
		if ( ! $blockers ) {
			return null;
		}
		return Proofing_Explanation::rejected( $name, $input, $blockers );
	}

	/**
	 * Context an executor records when it admits a request, before its transaction.
	 * A failure rolls the transaction back, so later context writes are lost; recovery still needs the users.
	 * An unknown row references no client yet: the executor's locked read rejects it or reports uncertainty,
	 * and success records the clients it touched.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed> Proofing administration, selection and email context: proofing_users.
	 */
	public static function admission_context( string $name, array $input ): array {
		return Proofing::rejection_context( $name, $input ) ?? array( 'proofing_users' => array() );
	}

	/**
	 * @return array{0:string,1:string} Status and code for a failed Proofing effect.
	 */
	public static function failure_status( \Throwable $error, string $fallback ): array {
		if ( ! $error instanceof \DomainException ) {
			return array( 'uncertain', $fallback );
		}
		$code = $error->getMessage();
		if ( 'stale_revision' === $code ) {
			return array( 'conflict', $code );
		}
		return array( 'rejected', $code );
	}

	public static function eligible( int $id ): bool {
		return Proofing::available() && Proofing::target_eligible( $id );
	}
}
