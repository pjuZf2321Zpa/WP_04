<?php
/** Explicit Proofing account creation and role association. Lite keeps schemas and retained-result inspection. */
namespace Modula_Pro\Extensions\Image_Proofing\Abilities;

use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Proofing;
use Modula\V2\Abilities\Proofing_Clients;
use Modula\V2\Abilities\Proofing_Explanation;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;

defined( 'ABSPATH' ) || exit;

final class Client_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	public static function run( string $name, array $input ): array {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Proofing_Clients::READ === $name ) {
			return self::read( $input );
		}
		if ( in_array( $name, Proofing_Clients::mutations(), true ) ) {
			return self::execute( $input, $name );
		}
		return Proofing_Explanation::rejected( $name, $input, Proofing_Clients::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Proofing_Clients::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function read( array $input ): array {
		try {
			return array(
				'schema_version' => Contract::VERSION,
				'client'         => self::inspect( $input['user_id'] ),
			);
		} catch ( \DomainException $error ) {
			return Requests::outcome( '', 'rejected', $error->getMessage(), 'Current access to this user is required.', Proofing_Clients::READ );
		} catch ( \Throwable $failure ) {
			return Requests::outcome( '', 'uncertain', 'client_unconfirmed', 'The account could not be inspected. Retry the read.', Proofing_Clients::READ );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! Proofing_Clients::can_recover(
			array(
				'operation' => $operation,
				'client_id' => $input['user_id'] ?? 0,
			)
		) ) {
			return self::outcome( $input, $operation, 'forbidden', 'current_permission_denied' );
		}
		if ( ! get_role( 'modula_client' ) ) {
			return self::outcome( $input, $operation, 'rejected', 'client_role_unavailable' );
		}
		if ( Proofing_Clients::CREATE === $operation && ! self::client_identity_valid( $input ) ) {
			return self::outcome( $input, $operation, 'rejected', 'invalid_client' );
		}
		// Recovery of an association reads client_id, even when the effect fails before its own context write.
		$existing = Requests::claim( $input, $operation, Proofing::rejection_context( $operation, $input ) ?? array() );
		if ( null !== $existing ) {
			return $existing;
		}
		return self::apply( $input, $operation );
	}

	/**
	 * @param array<string,mixed> $input
	 */
	private static function client_identity_valid( array $input ): bool {
		$username = $input['username'];
		$email    = $input['email'];
		return validate_username( $username )
			&& sanitize_user( $username, true ) === $username
			&& is_email( $email )
			&& sanitize_email( $email ) === $email;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function apply( array $input, string $operation ): array {
		$active    = false;
		$committed = false;
		$id        = (int) ( $input['user_id'] ?? 0 );
		$client    = null;
		try {
			global $wpdb;
			Revision::begin();
			$active = true;
			Revision::require_transactional_table( $wpdb->users );
			Revision::require_transactional_table( $wpdb->usermeta );
			if ( Proofing_Clients::CREATE === $operation ) {
				$client = self::create_client( $input );
				$id     = (int) $client['id'];
			} else {
				$client = self::associate_client( $input );
			}
			$send = Proofing_Clients::CREATE === $operation && $client['created'] && $input['send_password_email'];
			if ( $send ) {
				$client['email_status'] = 'uncertain';
			}
			Requests::context(
				$input['request_id'],
				array(
					'client_id' => $id,
					'client'    => $client,
				)
			);
			$saved = $send ? null : self::confirm_saved( $input, $operation, $client );
			Revision::end( true );
			$active    = false;
			$committed = true;
			if ( ! $send ) {
				return $saved;
			}
			// The durable account checkpoint survives termination during notification; recovery never resends.
			$client['email_status'] = self::notify( $id );
			$client['revision']     = self::inspect( $id )['revision'];
			Requests::context( $input['request_id'], array( 'client' => $client ) );
			$status = 'succeeded' === $client['email_status'] ? 'succeeded' : 'uncertain';
			$code   = 'succeeded' === $client['email_status'] ? '' : 'password_email_' . $client['email_status'];
			return Requests::finish( $input['request_id'], self::outcome( $input, $operation, $status, $code ) + array( 'client' => $client ) );
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			if ( $id ) {
				clean_user_cache( $id );
			}
			$code = $error instanceof \DomainException ? $error->getMessage() : 'client_unconfirmed';
			if ( ! $committed && 'stale_revision' === $code ) {
				$status = 'conflict';
			} elseif ( ! $committed && $error instanceof \DomainException ) {
				$status = 'rejected';
			} else {
				$status = 'uncertain';
			}
			$payload = $committed && $client ? array( 'client' => $client ) : array();
			return Requests::finish( $input['request_id'], self::outcome( $input, $operation, $status, $code ) + $payload );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $client
	 * @return array<string,mixed>
	 */
	private static function confirm_saved( array $input, string $operation, array $client ): array {
		$result = Requests::finish( $input['request_id'], self::outcome( $input, $operation, 'succeeded' ) + array( 'client' => $client ) );
		if ( 'succeeded' !== $result['status'] ) {
			throw new \RuntimeException();
		}
		return $result;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function create_client( array $input ): array {
		global $wpdb;
		// Lock both indexed identities and their insertion gaps before testing for an existing account.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Authoritative locked reads; identifiers are internal, values are prepared.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID,user_email,user_login FROM {$wpdb->users} WHERE user_email = %s OR user_login = %s ORDER BY ID FOR UPDATE", $input['email'], $input['username'] ), ARRAY_A );
		if ( $wpdb->last_error ) {
			throw new \RuntimeException();
		}
		$existing = self::email_match( $rows, $input['email'] );
		if ( $existing ) {
			return self::inspect_or_clean( $existing, true );
		}
		if ( $rows ) {
			throw new \DomainException( 'username_exists' );
		}
		$created = wp_insert_user(
			array(
				'user_login' => $input['username'],
				'user_email' => $input['email'],
				'user_pass'  => wp_generate_password( 40, true, true ),
				'role'       => 'modula_client',
			)
		);
		if ( is_wp_error( $created ) ) {
			throw new \DomainException( 'client_creation_failed' );
		}
		$client            = self::inspect_or_clean( (int) $created, false );
		$client['created'] = true;
		return $client;
	}

	/**
	 * @param array<int,array<string,mixed>> $rows
	 */
	private static function email_match( array $rows, string $email ): int {
		foreach ( $rows as $row ) {
			if ( 0 === strcasecmp( (string) $row['user_email'], $email ) ) {
				return (int) $row['ID'];
			}
		}
		return 0;
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function inspect_or_clean( int $id, bool $lock ): array {
		try {
			return self::inspect( $id, $lock );
		} catch ( \Throwable $error ) {
			clean_user_cache( $id );
			throw $error;
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function associate_client( array $input ): array {
		$id     = (int) $input['user_id'];
		$client = self::inspect( $id, true );
		if ( ! hash_equals( $client['revision'], $input['revision'] ) ) {
			throw new \DomainException( 'stale_revision' );
		}
		if ( ! current_user_can( 'promote_user', $id ) ) {
			throw new \DomainException( 'client_unavailable' );
		}
		$user = get_userdata( $id );
		if ( ! $user instanceof \WP_User ) {
			throw new \DomainException( 'client_unavailable' );
		}
		$roles = $user->roles;
		$user->add_role( 'modula_client' );
		$client  = self::inspect( $id );
		$current = get_userdata( $id );
		$removed = $current instanceof \WP_User ? array_diff( $roles, $current->roles ) : $roles;
		if ( ! $client['associated'] || $removed ) {
			throw new \RuntimeException();
		}
		return $client;
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function inspect( int $id, bool $lock = false ): array {
		global $wpdb;
		$user = get_userdata( $id );
		if ( ! Proofing_Clients::can_manage() || ! $user instanceof \WP_User || ! current_user_can( 'edit_user', $id ) ) {
			throw new \DomainException( 'client_unavailable' );
		}
		$suffix = $lock ? ' FOR UPDATE' : '';
		if ( $lock ) {
			Revision::require_transactional_table( $wpdb->users );
			Revision::require_transactional_table( $wpdb->usermeta );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Authoritative locked reads; identifiers and lock suffix are internal, values are prepared.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->users} WHERE ID = %d" . $suffix, $id ), ARRAY_A );
		if ( $wpdb->last_error || ! $rows ) {
			throw new \RuntimeException();
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Authoritative locked reads; identifiers and lock suffix are internal, values are prepared.
		$meta = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key,meta_value FROM {$wpdb->usermeta} WHERE user_id = %d ORDER BY umeta_id" . $suffix, $id ), ARRAY_A );
		if ( $wpdb->last_error ) {
			throw new \RuntimeException();
		}
		clean_user_cache( $id );
		$fresh = get_userdata( $id );
		if ( ! $fresh instanceof \WP_User ) {
			throw new \RuntimeException();
		}
		return array(
			'id'           => $id,
			'revision'     => hash( 'sha256', wp_json_encode( array( $rows, $meta ) ) ),
			'created'      => false,
			'associated'   => in_array( 'modula_client', $fresh->roles, true ),
			'email_status' => 'not_requested',
		);
	}

	/** Observe WordPress notification without storing password-reset keys or message bodies. */
	private static function notify( int $id ): string {
		$status = 'uncertain';
		$user   = get_userdata( $id );
		if ( ! $user instanceof \WP_User ) {
			return $status;
		}
		$email   = $user->user_email;
		$matches = static function ( $data ) use ( $email ) {
			return in_array( $email, (array) ( $data['to'] ?? array() ), true );
		};
		$success = static function ( $data ) use ( &$status, $matches ) {
			if ( $matches( $data ) ) {
				$status = 'succeeded';
			}
		};
		$failed  = static function ( $error ) use ( &$status, $matches ) {
			if ( $matches( $error->get_error_data() ?? array() ) ) {
				$status = 'failed';
			}
		};
		$short   = static function ( $pre, $data ) use ( &$status, $matches ) {
			if ( null !== $pre && $matches( $data ) ) {
				$status = $pre ? 'succeeded' : 'failed';
			}
			return $pre;
		};
		add_action( 'wp_mail_succeeded', $success );
		add_action( 'wp_mail_failed', $failed );
		add_filter( 'pre_wp_mail', $short, PHP_INT_MAX, 2 );
		try {
			wp_new_user_notification( $id, null, 'user' );
		} finally {
			remove_action( 'wp_mail_succeeded', $success );
			remove_action( 'wp_mail_failed', $failed );
			remove_filter( 'pre_wp_mail', $short, PHP_INT_MAX );
		}
		return $status;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function outcome( array $input, string $operation, string $status, string $code = '' ): array {
		$message = $code ? 'Recover this request and inspect the account before another effect.' : '';
		return Requests::outcome( $input['request_id'], $status, $code, $message, $operation );
	}
}
