<?php
/** Explicit Proofing settings and invitation records. Lite keeps schemas and retained-result inspection. */
namespace Modula_Pro\Extensions\Image_Proofing\Abilities;

use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Proofing;
use Modula\V2\Abilities\Proofing_Explanation;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Meta_Sync;
use Modula\V2\Settings\Writer;
use Modula_Pro\Extensions\Image_Proofing\Data_Handler;

defined( 'ABSPATH' ) || exit;

final class Proofing_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Proofing::READ === $name ) {
			return self::read( $input );
		}
		if ( in_array( $name, Proofing::mutations(), true ) ) {
			return self::execute( $input, $name );
		}
		return Proofing_Explanation::rejected( $name, $input, Proofing::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Proofing::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function read( array $input ) {
		try {
			$result = self::inspect( $input['id'] );
			// A change between the two reads means the snapshot is not stable enough to return.
			// phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Compare two successive snapshots.
			if ( $result !== self::inspect( $input['id'] ) ) {
				throw new \RuntimeException( 'inspection_changed' );
			}
			return array(
				'schema_version' => Contract::VERSION,
				'proofing'       => $result,
			);
		} catch ( \Throwable $error ) {
			return new \WP_Error( 'modula_proofing_unavailable', 'A stable accessible eligible Beta gallery is required.' );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! Proofing::can_administer( (int) $input['id'] ) ) {
			return self::outcome( $input, $operation, 'forbidden', 'current_permission_denied' );
		}
		$existing = Requests::claim( $input, $operation, Provider::admission_context( $operation, $input ) );
		if ( null !== $existing ) {
			return $existing;
		}
		$active = false;
		try {
			Revision::begin();
			$active  = true;
			$current = self::inspect( $input['id'], true );
			if ( ! hash_equals( $current['revision'], $input['revision'] ) ) {
				throw new \DomainException( 'stale_revision' );
			}
			$users = self::apply( $input, $operation, $current );
			foreach ( $current['invitations'] as $row ) {
				if ( ctype_digit( $row['client'] ) ) {
					$users[] = (int) $row['client'];
				}
			}
			Requests::context( $input['request_id'], array( 'proofing_users' => array_unique( $users ) ) );
			$result  = self::inspect( $input['id'] );
			$outcome = Requests::finish( $input['request_id'], self::outcome( $input, $operation, 'succeeded' ) + array( 'proofing' => $result ) );
			if ( 'succeeded' !== $outcome['status'] ) {
				throw new \RuntimeException( 'outcome_unconfirmed' );
			}
			Revision::end( true );
			$active = false;
			return $outcome;
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			list( $status, $code ) = Provider::failure_status( $error, 'proofing_unconfirmed' );
			return Requests::finish( $input['request_id'], self::outcome( $input, $operation, $status, $code ) );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $current
	 * @return array<int,int>
	 */
	private static function apply( array $input, string $operation, array $current ): array {
		if ( Proofing::UPDATE === $operation ) {
			self::apply_settings( $input, $current );
			return array();
		}
		return self::apply_invitation( $input, $operation, $current );
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $current
	 */
	private static function apply_settings( array $input, array $current ): void {
		$settings = $input['settings'] ?? array();
		if ( ! is_array( $settings ) ) {
			throw new \DomainException( 'invalid_settings' );
		}
		if ( array() === $settings && ! array_key_exists( 'locked', $input ) ) {
			throw new \DomainException( 'empty_patch' );
		}
		if ( isset( $input['locked'] ) ) {
			if ( isset( $settings['imageProofing'] ) && $settings['imageProofing'] !== $input['locked'] ) {
				throw new \DomainException( 'inconsistent_lock' );
			}
			$settings['imageProofing'] = $input['locked'];
		}
		$merged = array_replace( $current['settings'], $settings );
		// An absent or zero max is the stored "no upper bound" convention, not a failed limit.
		if ( self::max_selection_set( $merged ) && ( $merged['minSelection'] ?? 0 ) > $merged['maxSelection'] ) {
			throw new \DomainException( 'invalid_selection_limits' );
		}
		if ( self::notification_set( $settings ) && ! is_email( $settings['notificationEmail'] ) ) {
			throw new \DomainException( 'invalid_email' );
		}
		if ( is_wp_error( Writer::validate_strict_patch( $input['id'], array( 'proofing' => $settings ) ) ) ) {
			throw new \DomainException( 'invalid_settings' );
		}
		$saved = Meta_Sync::with_canonical_gallery_write(
			$input['id'],
			static function () use ( $input, $settings ) {
				return Writer::patch( $input['id'], array( 'proofing' => $settings ), true );
			}
		);
		if ( is_wp_error( $saved ) ) {
			throw new \RuntimeException( 'settings_unconfirmed' );
		}
		if ( isset( $input['locked'] ) ) {
			update_post_meta( $input['id'], '_modula_locked_for_proofing', $input['locked'] ? '1' : '0' );
		}
	}

	/**
	 * @param array<string,mixed> $settings
	 */
	private static function max_selection_set( array $settings ): bool {
		$max = $settings['maxSelection'] ?? null;
		return null !== $max && false !== $max && '' !== $max && 0 !== $max && '0' !== $max;
	}

	/**
	 * @param array<string,mixed> $settings
	 */
	private static function notification_set( array $settings ): bool {
		$email = $settings['notificationEmail'] ?? null;
		return null !== $email && false !== $email && '' !== $email && 0 !== $email && '0' !== $email;
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $current
	 * @return array<int,int>
	 */
	private static function apply_invitation( array $input, string $operation, array $current ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'modula_image_proofing_invitations';
		$users = array();
		if ( Proofing::CREATE === $operation ) {
			$users = self::create_invitation( $input );
		} else {
			$users = self::change_invitation( $input, $operation, $current, $table );
		}
		if ( $wpdb->last_error ) {
			throw new \RuntimeException( 'invitation_unconfirmed' );
		}
		return $users;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<int,int>
	 */
	private static function create_invitation( array $input ): array {
		if ( isset( $input['user_id'] ) === isset( $input['guest_identifier'] ) ) {
			throw new \DomainException( 'one_client_required' );
		}
		$client = isset( $input['user_id'] ) ? (string) $input['user_id'] : $input['guest_identifier'];
		$users  = array();
		if ( isset( $input['user_id'] ) ) {
			$user = get_userdata( $input['user_id'] );
			// modula_client is the account type this operation accepts; edit_user is the capability check.
			if ( ! $user instanceof \WP_User || ! current_user_can( 'edit_user', $user->ID ) || ! in_array( 'modula_client', $user->roles, true ) ) {
				throw new \DomainException( 'client_unavailable' );
			}
			$users[] = $user->ID;
		}
		$invitation = ( new Data_Handler() )->create_invitation( $input['id'], $client );
		if ( ! is_numeric( $invitation ) || (int) $invitation < 1 ) {
			throw new \RuntimeException( 'invitation_unconfirmed' );
		}
		return $users;
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $current
	 * @return array<int,int>
	 */
	private static function change_invitation( array $input, string $operation, array $current, string $table ): array {
		global $wpdb;
		$matches = array();
		foreach ( $current['invitations'] as $row ) {
			if ( $row['id'] === $input['invitation_id'] ) {
				$matches[] = $row;
			}
		}
		if ( ! $matches ) {
			throw new \DomainException( 'invitation_unavailable' );
		}
		$users = array();
		if ( ctype_digit( $matches[0]['client'] ) ) {
			$users[] = (int) $matches[0]['client'];
		}
		// Existing delete_invitation also removes selections, which this record-only operation must preserve.
		if ( Proofing::DELETE === $operation ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Record-only mutation must not invoke selection deletion.
			$written = $wpdb->delete(
				$table,
				array(
					'id'         => $input['invitation_id'],
					'gallery_id' => $input['id'],
				),
				array( '%d', '%d' )
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Record-only expiry update.
			$written = $wpdb->update(
				$table,
				array( 'expired' => (int) $input['expired'] ),
				array(
					'id'         => $input['invitation_id'],
					'gallery_id' => $input['id'],
				),
				array( '%d' ),
				array( '%d', '%d' )
			);
		}
		if ( false === $written ) {
			throw new \RuntimeException( 'invitation_unconfirmed' );
		}
		return $users;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function outcome( array $input, string $operation, string $status, string $code = '' ): array {
		$message = $code ? 'Read current Proofing state and reconcile before a new request.' : '';
		return Requests::outcome( $input['request_id'], $status, $code, $message, $operation );
	}

	/**
	 * Raw rows are hashed, but only authorized records are returned. Lock gaps cover ordinary inserts.
	 *
	 * @return array<string,mixed>
	 */
	public static function inspect( int $id, bool $lock = false ): array {
		if ( ! Provider::eligible( $id ) ) {
			throw new \DomainException( 'unsupported_proofing_target' );
		}
		$revision = Revision::state( $id, $lock );
		global $wpdb;
		$table = $wpdb->prefix . 'modula_image_proofing_invitations';
		if ( $lock ) {
			Revision::require_transactional_table( $table );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Authoritative locked reads; identifiers and lock suffix are internal, values are prepared.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,user_id,expired FROM $table WHERE gallery_id = %d ORDER BY id LIMIT 1001" . ( $lock ? ' FOR UPDATE' : '' ), $id ), ARRAY_A );
		if ( $wpdb->last_error || count( $rows ) > 1000 ) {
			throw new \DomainException( 'proofing_records_unavailable' );
		}
		$visible = array();
		foreach ( $rows as $row ) {
			if ( ctype_digit( $row['user_id'] ) && ( ! get_userdata( (int) $row['user_id'] ) || ! current_user_can( 'edit_user', (int) $row['user_id'] ) ) ) {
				continue;
			}
			$visible[] = array(
				'id'      => (int) $row['id'],
				'client'  => $row['user_id'],
				'expired' => (bool) $row['expired'],
			);
		}
		$settings = Meta_Sync::get_settings_v2( $id, false );
		return array(
			'id'          => $id,
			'revision'    => hash( 'sha256', wp_json_encode( array( $revision, $rows ) ) ),
			'settings'    => $settings['proofing'] ?? array(),
			'locked'      => (bool) get_post_meta( $id, '_modula_locked_for_proofing', true ),
			'invitations' => $visible,
		);
	}
}
