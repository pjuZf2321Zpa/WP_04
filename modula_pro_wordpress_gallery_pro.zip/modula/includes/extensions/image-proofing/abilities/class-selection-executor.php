<?php
/** Administrative selection reads and moderation. Never client submission. */
namespace Modula_Pro\Extensions\Image_Proofing\Abilities;

use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Proofing;
use Modula\V2\Abilities\Proofing_Explanation;
use Modula\V2\Abilities\Proofing_Selections;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;

defined( 'ABSPATH' ) || exit;

final class Selection_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Proofing_Selections::LISTING === $name ) {
			return self::listing( $input );
		}
		if ( Proofing_Selections::READ === $name ) {
			return self::read( $input );
		}
		if ( in_array( $name, Proofing_Selections::mutations(), true ) ) {
			return self::execute( $input, $name );
		}
		return Proofing_Explanation::rejected( $name, $input, Proofing::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Proofing_Selections::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function read( array $input ) {
		try {
			$gallery = self::gallery( $input['id'] );
			$row     = self::row( $input['id'], $input['selection_id'] );
			// phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Compare two successive snapshots.
			if ( $gallery !== self::gallery( $input['id'] ) || $row !== self::row( $input['id'], $input['selection_id'] ) ) {
				throw new \RuntimeException( 'inspection_changed' );
			}
			return array(
				'schema_version' => Contract::VERSION,
				'selection'      => self::project( $row, $gallery ),
			);
		} catch ( \Throwable $error ) {
			return new \WP_Error( 'modula_selection_unavailable', 'A stable accessible gallery and selection are required.' );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	private static function listing( array $input ) {
		try {
			$gallery = self::gallery( $input['id'] );
			global $wpdb;
			$table = $wpdb->prefix . 'modula_image_proofing_selections';
			$limit = $input['per_page'] ?? 25;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Internal table, prepared bounded cursor.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE gallery_id = %d AND id > %d ORDER BY id LIMIT %d", $input['id'], $input['after_id'] ?? 0, $limit + 1 ), ARRAY_A );
			// phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Compare two successive gallery snapshots.
			if ( $wpdb->last_error || $gallery !== self::gallery( $input['id'] ) ) {
				throw new \RuntimeException( 'inspection_changed' );
			}
			$more = count( $rows ) > $limit;
			$rows = array_slice( $rows, 0, $limit );
			$next = $more ? (int) end( $rows )['id'] : 0;
			return array(
				'schema_version' => Contract::VERSION,
				'selections'     => self::visible_selections( $rows, $gallery ),
				'next_after_id'  => $next,
			);
		} catch ( \Throwable $error ) {
			return new \WP_Error( 'modula_selections_unavailable', 'Accessible eligible gallery selection data is required.' );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! Proofing::can_administer( (int) $input['id'] ) ) {
			return self::outcome( $input, $operation, 'forbidden', 'current_permission_denied' );
		}
		$existing = Requests::claim( $input, $operation, Provider::admission_context( $operation, $input ) );
		if ( null !== $existing ) {
			return $existing;
		}
		$active = false;
		try {
			Revision::begin();
			$active    = true;
			$gallery   = self::gallery( $input['id'], true );
			$row       = self::row( $input['id'], $input['selection_id'], true );
			$selection = self::project( $row, $gallery );
			if ( ! hash_equals( $selection['revision'], $input['revision'] ) ) {
				throw new \DomainException( 'stale_revision' );
			}
			$users = ctype_digit( $row['user_id'] ) ? array( (int) $row['user_id'] ) : array();
			Requests::context( $input['request_id'], array( 'proofing_users' => $users ) );
			self::moderate( $input, $operation );
			if ( Proofing_Selections::DELETE === $operation ) {
				$selection['deleted'] = true;
			} else {
				$selection = self::confirmed_unlock( $input, $row, $gallery );
			}
			$result = Requests::finish( $input['request_id'], self::outcome( $input, $operation, 'succeeded' ) + array( 'selection' => $selection ) );
			if ( 'succeeded' !== $result['status'] ) {
				throw new \RuntimeException( 'outcome_unconfirmed' );
			}
			Revision::end( true );
			$active = false;
			return $result;
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			list( $status, $code ) = Provider::failure_status( $error, 'selection_unconfirmed' );
			return Requests::finish( $input['request_id'], self::outcome( $input, $operation, $status, $code ) );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 */
	private static function moderate( array $input, string $operation ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'modula_image_proofing_selections';
		$where = array(
			'id'         => $input['selection_id'],
			'gallery_id' => $input['id'],
		);
		if ( Proofing_Selections::DELETE === $operation ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Narrow locked administrative write, never the submit path.
			$written = $wpdb->delete( $table, $where, array( '%d', '%d' ) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Unlock changes only the submitted flag.
			$written = $wpdb->update( $table, array( 'submitted' => 0 ), $where, array( '%d' ), array( '%d', '%d' ) );
		}
		if ( false === $written ) {
			throw new \RuntimeException( 'selection_unconfirmed' );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $before
	 * @return array<string,mixed>
	 */
	private static function confirmed_unlock( array $input, array $before, string $gallery ): array {
		$after = self::row( $input['id'], $input['selection_id'] );
		// phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Compare the locked row with the row read after unlock.
		if ( $after['selections'] !== $before['selections'] || $after['notes'] !== $before['notes'] || (bool) $after['submitted'] ) {
			throw new \RuntimeException( 'selection_unconfirmed' );
		}
		return self::project( $after, $gallery );
	}

	/**
	 * @param array<int,array<string,mixed>> $rows
	 * @return array<int,array<string,mixed>>
	 */
	private static function visible_selections( array $rows, string $gallery ): array {
		$result = array();
		foreach ( $rows as $row ) {
			if ( ! self::can_read_client( $row['user_id'] ) ) {
				continue;
			}
			$result[] = self::project( $row, $gallery );
		}
		return $result;
	}

	private static function can_read_client( string $client ): bool {
		if ( ! ctype_digit( $client ) ) {
			return true;
		}
		$user = (int) $client;
		return get_userdata( $user ) instanceof \WP_User && current_user_can( 'edit_user', $user );
	}

	private static function gallery( int $id, bool $lock = false ): string {
		$revision = Revision::state( $id, $lock );
		if ( ! Provider::eligible( $id ) ) {
			throw new \DomainException( 'unsupported_proofing_target' );
		}
		return $revision;
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function row( int $id, int $selection, bool $lock = false ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'modula_image_proofing_selections';
		if ( $lock ) {
			Revision::require_transactional_table( $table );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Internal table and lock suffix; values prepared.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d AND gallery_id = %d" . ( $lock ? ' FOR UPDATE' : '' ), $selection, $id ), ARRAY_A );
		if ( $wpdb->last_error ) {
			throw new \RuntimeException( 'selection_unconfirmed' );
		}
		if ( ! is_array( $row ) || ! self::can_read_client( $row['user_id'] ) ) {
			throw new \DomainException( 'selection_unavailable' );
		}
		return $row;
	}

	/**
	 * @param array<string,mixed> $row
	 * @return array<string,mixed>
	 */
	private static function project( array $row, string $gallery ): array {
		$images = json_decode( $row['selections'], true );
		if ( ! self::selection_payload_readable( $images, $row['notes'] ) ) {
			throw new \DomainException( 'selection_data_unavailable' );
		}
		return array(
			'id'         => (int) $row['id'],
			'gallery_id' => (int) $row['gallery_id'],
			'client'     => $row['user_id'],
			'revision'   => hash( 'sha256', wp_json_encode( array( $gallery, $row ) ) ),
			'image_ids'  => $images,
			'notes'      => $row['notes'],
			'submitted'  => (bool) $row['submitted'],
			'deleted'    => false,
		);
	}

	/**
	 * @param mixed $images
	 */
	private static function selection_payload_readable( $images, $notes ): bool {
		if ( ! is_array( $images ) || array_values( $images ) !== $images || ! is_string( $notes ) ) {
			return false;
		}
		if ( count( $images ) > 10000 || strlen( $notes ) > 65535 ) {
			return false;
		}
		foreach ( $images as $image ) {
			if ( ! is_int( $image ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function outcome( array $input, string $operation, string $status, string $code = '' ): array {
		$message = $code ? 'Read the current selection before a new moderation request.' : '';
		return Requests::outcome( $input['request_id'], $status, $code, $message, $operation );
	}
}
