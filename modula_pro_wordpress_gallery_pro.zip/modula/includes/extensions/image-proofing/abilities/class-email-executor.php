<?php
/** Explicit invitation delivery. Lite keeps the schema and never resends a retained result. */
namespace Modula_Pro\Extensions\Image_Proofing\Abilities;

use Modula\V2\Abilities\Proofing;
use Modula\V2\Abilities\Proofing_Email;
use Modula\V2\Abilities\Proofing_Explanation;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula_Pro\Extensions\Image_Proofing\Email_Handler;

defined( 'ABSPATH' ) || exit;

final class Email_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	public static function run( string $name, array $input ): array {
		$gated = Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		if ( Proofing_Email::SEND === $name ) {
			return self::execute( $input );
		}
		return Proofing_Explanation::rejected( $name, $input, Proofing::explain_blockers( $name, $input ) );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		return array(
			Proofing_Email::SEND => static function ( $input ) {
				return self::run( Proofing_Email::SEND, is_array( $input ) ? $input : array() );
			},
		);
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function execute( array $input ): array {
		$existing = Requests::existing( $input, Proofing_Email::SEND );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! Proofing::can_administer( (int) $input['id'] ) ) {
			return self::outcome( $input, 'forbidden', 'current_permission_denied' );
		}
		if ( ! is_email( $input['recipient'] ) || sanitize_email( $input['recipient'] ) !== $input['recipient'] ) {
			return self::outcome( $input, 'rejected', 'invalid_recipient' );
		}
		$existing = Requests::claim( $input, Proofing_Email::SEND, Provider::admission_context( Proofing_Email::SEND, $input ) );
		if ( null !== $existing ) {
			return $existing;
		}
		return self::deliver( $input );
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function deliver( array $input ): array {
		$active   = false;
		$mail     = null;
		$admitted = false;
		try {
			Revision::begin();
			$active     = true;
			$invitation = self::active_invitation( $input );
			$users      = self::recipient_users( $invitation, $input['recipient'] );
			$mail       = array(
				'gallery_id'    => $input['id'],
				'invitation_id' => $input['invitation_id'],
				'email_status'  => 'uncertain',
			);
			Requests::context(
				$input['request_id'],
				array(
					'proofing_users' => $users,
					'proofing_email' => $mail,
				)
			);
			Revision::end( true );
			$active   = false;
			$admitted = true;
			// The committed checkpoint survives process termination during the external call.
			$sent = self::send( $input, $invitation, $users );
			if ( true === $sent ) {
				$mail['email_status'] = 'accepted';
			} elseif ( false === $sent ) {
				$mail['email_status'] = 'failed';
			}
			Requests::context( $input['request_id'], array( 'proofing_email' => $mail ) );
			$status = true === $sent ? 'succeeded' : 'uncertain';
			$code   = true === $sent ? '' : 'invitation_email_' . $mail['email_status'];
			return Requests::finish( $input['request_id'], self::outcome( $input, $status, $code ) + array( 'proofing_email' => $mail ) );
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			$code = ! $admitted && $error instanceof \DomainException ? $error->getMessage() : 'invitation_email_unconfirmed';
			if ( 'stale_revision' === $code ) {
				$status = 'conflict';
			} elseif ( ! $admitted && $error instanceof \DomainException ) {
				$status = 'rejected';
			} else {
				$status = 'uncertain';
			}
			$payload = $admitted ? array( 'proofing_email' => $mail ) : array();
			return Requests::finish( $input['request_id'], self::outcome( $input, $status, $code ) + $payload );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function active_invitation( array $input ): array {
		$current = Proofing_Executor::inspect( $input['id'], true );
		if ( ! hash_equals( $current['revision'], $input['revision'] ) ) {
			throw new \DomainException( 'stale_revision' );
		}
		$invitation = self::open_invitation( $current['invitations'], (int) $input['invitation_id'] );
		if ( ! $invitation || ! class_exists( Email_Handler::class ) || ! get_permalink( $input['id'] ) ) {
			throw new \DomainException( 'invitation_unavailable' );
		}
		return $invitation;
	}

	/**
	 * @param array<int,array<string,mixed>> $rows
	 * @return array<string,mixed>|null
	 */
	private static function open_invitation( array $rows, int $invitation_id ): ?array {
		foreach ( $rows as $row ) {
			if ( $row['id'] === $invitation_id && ! $row['expired'] ) {
				return $row;
			}
		}
		return null;
	}

	/**
	 * @param array<string,mixed> $invitation
	 * @return array<int,int>
	 */
	private static function recipient_users( array $invitation, string $recipient ): array {
		if ( ! ctype_digit( $invitation['client'] ) ) {
			return array();
		}
		$user         = get_userdata( (int) $invitation['client'] );
		$matches_role = $user instanceof \WP_User && in_array( 'modula_client', $user->roles, true );
		$matches_mail = $user instanceof \WP_User && 0 === strcasecmp( $user->user_email, $recipient );
		if ( ! $user instanceof \WP_User || ! current_user_can( 'edit_user', $user->ID ) || ! $matches_role || ! $matches_mail ) {
			throw new \DomainException( 'recipient_mismatch' );
		}
		return array( $user->ID );
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,mixed> $invitation
	 * @param array<int,int>      $users
	 * @return mixed
	 */
	private static function send( array $input, array $invitation, array $users ) {
		$handler = new Email_Handler();
		if ( $users ) {
			return $handler->send_client_invitation_email( $input['id'], $users[0], $input['recipient'] );
		}
		return $handler->send_invitation_email( $input['id'], $invitation['client'], $input['recipient'] );
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function outcome( array $input, string $status, string $code = '' ): array {
		$message = $code ? 'Reconcile this invitation request; do not automatically resend.' : '';
		return Requests::outcome( $input['request_id'], $status, $code, $message, Proofing_Email::SEND );
	}
}
