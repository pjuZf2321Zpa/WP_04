<?php

namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Notifications {
	private static $instance;

	public static function get_instance() {
		if ( ! isset( self::$instance ) || ! ( self::$instance instanceof Notifications ) ) {
			self::$instance = new Notifications();
		}

		return self::$instance;
	}

	public function add_notification( $id, $notice ) {
		if ( ! $this->can_add_notification() ) {
			return;
		}

		$defaults = array(
			'title'   => '',
			'message' => '',
			'status'  => 'success',
			'timed'   => 0,
		);

		$notice = array_merge( $defaults, $notice );

		\Modula_Notifications::add_notification( $id, $notice );
	}

	private function can_add_notification() {
		if ( ! class_exists( 'Modula_Notifications' ) ) {
			return false;
		}

		return true;
	}
}
