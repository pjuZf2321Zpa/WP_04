<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class User_Manager {
	public static function setup_role() {
		$capabilities = array(
			'read'                          => true,
			'modula_see_gallery'            => true,
			'modula_select_images'          => true,
			'modula_annotate_images'        => true,
			'modula_comment_on_annotations' => true,
		);

		$role = get_role( 'modula_client' );

		if ( $role ) {
			foreach ( $capabilities as $cap => $grant ) {
				if ( $grant ) {
					$role->add_cap( $cap );
				} else {
					$role->remove_cap( $cap );
				}
			}
		} else {
			add_role( 'modula_client', __( 'Client', 'modula-pro' ), $capabilities );
		}
	}

	public static function create_user( $data ) {
		if ( ! isset( $data['user_name'] ) || ! isset( $data['user_email'] ) ) {
			return array(
				'error'   => true,
				'message' => __( 'User name or email is not set.', 'modula-pro' ),
			);
		}

		$user_name  = sanitize_text_field( $data['user_name'] );
		$user_email = sanitize_email( $data['user_email'] );

		if ( ! is_email( $user_email ) ) {
			return array(
				'error'   => true,
				'message' => __( 'Invalid email address.', 'modula-pro' ),
			);
		}
		$user_id = email_exists( $user_email );
		if ( $user_id ) {
			$user = new \WP_User( $user_id );

			$user->add_role( 'modula_client' );

			return array(
				'success' => true,
				'message' => __( 'User already exists. A new role (specific to image proofing) has been added.', 'modula-pro' ),
				'user'    => array(
					'id'    => $user_id,
					'email' => $user_email,
				),
			);
		}

		$user_id = wp_create_user( $user_name, '', $user_email );

		if ( is_wp_error( $user_id ) ) {
			return array(
				'error'   => true,
				'message' => $user_id->get_error_message(),
			);
		}

		$user = new \WP_User( $user_id );
		$user->set_role( 'modula_client' );

		wp_new_user_notification( $user_id, null, 'user' );

		return array(
			'success' => true,
			'message' => __( 'User created successfully! An email has been sent to the user to set their password.', 'modula-pro' ),
			'user'    => array(
				'id'    => $user_id,
				'email' => $user_email,
			),
		);
	}
}
