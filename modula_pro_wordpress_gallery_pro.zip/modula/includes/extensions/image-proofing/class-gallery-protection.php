<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Gallery_Protection {

	/**
	 * Constructor for Gallery_Protection class
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function __construct() {
		add_filter( 'modula_pre_output_filter_check', array( $this, 'invitation_check' ), 10, 3 );
		add_filter( 'modula_pre_output_filter', array( $this, 'rejection_message' ), 10, 3 );
		add_filter( 'modula_gallery_proofing_lock', array( $this, 'proofing_lock' ), 10, 2 );
	}

	public function proofing_lock( $lock, $gallery_id ) {
		$locked = get_post_meta( str_replace( 'jtg-', '', $gallery_id ), '_modula_locked_for_proofing', true );

		return '1' === $locked || true === $locked ? true : false;
	}

	public function invitation_check( $response, $modula_settings, $gallery ) {
		if ( is_admin() || ! $gallery ) {
			return $response;
		}

		// Proofing stopped: invite visitors should not silently see a public gallery.
		if ( ! isset( $modula_settings['image_proofing'] ) || 0 === absint( $modula_settings['image_proofing'] ) ) {
			return $this->is_invite_visitor( $gallery ) ? true : $response;
		}

		$modula_settings = $this->get_modula_settings( $modula_settings );

		// Check permalink access first
		$data_handler = new Data_Handler();
		//phpcs:disable
		if ( ! empty( $_GET['mip_name'] ) ) {
			$invite_status = $data_handler->is_invited(
				$gallery->ID,
				sanitize_text_field( wp_unslash( $_GET['mip_name'] ) )
			);
			return $invite_status['invited'] && ! $invite_status['expired'] ? $response : true;
		}
		//phpcs:enable

		if ( ! is_user_logged_in() ) {
			return true;
		}

		if ( isset( $gallery->post_author ) && absint( $gallery->post_author ) === absint( get_current_user_id() ) ) {
			return $response;
		}

		// Check if logged-in user is invited
		$invite_status = $data_handler->is_invited( $gallery->ID, get_current_user_id() );
		return $invite_status['invited'] && ! $invite_status['expired'] ? $response : true;
	}

	public function rejection_message( $pre_output, $modula_settings, $gallery ) {
		if ( ! $this->invitation_check( false, $modula_settings, $gallery ) ) {
			return $pre_output;
		}

		// Proofing disabled but visitor arrived via invite — round is over.
		if ( ! isset( $modula_settings['image_proofing'] ) || 0 === absint( $modula_settings['image_proofing'] ) ) {
			return $this->get_formatted_notice(
				esc_html__( 'This proofing round has ended. You can no longer select or submit images from this gallery.', 'modula-image-proofing' ),
				'closed'
			);
		}

		$modula_settings = $this->get_modula_settings( $modula_settings );

		$data_handler = new Data_Handler();

		//phpcs:disable
		// Handle permalink access
		if ( ! empty( $_GET['mip_name'] ) ) {
			$invite_status = $data_handler->is_invited(
				$gallery->ID,
				sanitize_text_field( wp_unslash( $_GET['mip_name'] ) )
			);

			if ( $invite_status['expired'] ) {
				return $this->get_formatted_notice(
					$this->add_redirect_link(
						$modula_settings
					),
					'closed'
				);
			}

			// Invalid or no permalink
			return $this->get_formatted_notice(
				$this->add_login_link( $modula_settings ),
				'unavailable'
			);
		}

		// Handle logged-in user access
		if ( ! is_user_logged_in() ) {
			return $this->get_formatted_notice(
				$this->add_login_link( $modula_settings ),
				'unavailable'
			);
		}

		$invite_status = $data_handler->is_invited( $gallery->ID, get_current_user_id() );

		return $this->get_formatted_notice(
			$invite_status['expired']
				? $this->add_redirect_link( $modula_settings )
				: $this->add_login_link( $modula_settings ),
			$invite_status['expired'] ? 'closed' : 'unavailable'
		);
	}

	/**
	 * Whether the current request is from a known invite visitor (permalink or logged-in invitee).
	 *
	 * @param \WP_Post $gallery Gallery post.
	 * @return bool
	 */
	private function is_invite_visitor( $gallery ) {
		$data_handler = new Data_Handler();

		//phpcs:disable
		if ( ! empty( $_GET['mip_name'] ) ) {
			$invite_status = $data_handler->is_invited(
				$gallery->ID,
				sanitize_text_field( wp_unslash( $_GET['mip_name'] ) )
			);
			return ! empty( $invite_status['invited'] );
		}
		//phpcs:enable

		if ( ! is_user_logged_in() ) {
			return false;
		}

		if ( isset( $gallery->post_author ) && absint( $gallery->post_author ) === absint( get_current_user_id() ) ) {
			return false;
		}

		$invite_status = $data_handler->is_invited( $gallery->ID, get_current_user_id() );
		return ! empty( $invite_status['invited'] );
	}

	/**
	 * Build a closed-round / unavailable notice card.
	 *
	 * @param string $notice  Notice HTML/text.
	 * @param string $variant closed|unavailable.
	 * @return string
	 */
	private function get_formatted_notice( $notice, $variant = 'unavailable' ) {
		$title = 'closed' === $variant
			? esc_html__( 'This proofing round is over', 'modula-image-proofing' )
			: esc_html__( 'You cannot access this gallery', 'modula-image-proofing' );

		$styles = '<style>.modula-proofing-closed-round{display:flex;align-items:center;justify-content:center;min-height:220px;padding:2rem 1rem;background:#f3f4f6;border-radius:8px;box-sizing:border-box}.modula-proofing-closed-round__card{max-width:36rem;width:100%;padding:1.75rem 1.5rem;background:#fff;border:1px solid #e5e7eb;border-radius:8px;box-shadow:0 1px 2px rgba(0,0,0,.04);text-align:center}.modula-proofing-closed-round__title{margin:0 0 .75rem;font-size:1.25rem;font-weight:600;color:#111827;line-height:1.3}.modula-proofing-rejection-message{margin:0;color:#4b5563;line-height:1.5;font-size:1rem}.modula-proofing-rejection-message-link{display:inline-block;margin-top:.75rem}</style>';

		return $styles . sprintf(
			'<div class="modula-proofing-rejection-message-wrap modula-proofing-closed-round" role="status"><div class="modula-proofing-closed-round__card"><p class="modula-proofing-closed-round__title">%1$s</p><div class="modula-proofing-rejection-message">%2$s</div></div></div>',
			$title,
			wp_kses_post( $notice )
		);
	}

	private function add_redirect_link( $settings ) {
		$show_contact_link = isset( $settings['expire_link_to_page'] ) && 1 === absint( $settings['expire_link_to_page'] );

		if ( ! $show_contact_link ) {
			return $settings['expire_rejection_notice'];
		}

		$link = sprintf( '<br /><a class="modula-proofing-rejection-message-link" href="%s">%s</a>', esc_url( $settings['expire_link_to_page_url'] ), esc_html__( 'Contact gallery owner', 'modula-image-proofing' ) );

		return $settings['expire_rejection_notice'] . $link;
	}

	private function add_login_link( $settings ) {
		$show_contact_link = isset( $settings['show_login_link'] ) && 1 === absint( $settings['show_login_link'] );

		if ( ! $show_contact_link ) {
			return $settings['login_rejection_notice'];
		}

		return $settings['login_rejection_notice'] . '<br />' . $this->get_link();
	}

	private function get_link() {
		$here = esc_url( home_url( $_SERVER['REQUEST_URI'] ) );
		return '<a class="modula-proofing-rejection-message-link" href="' . esc_url( wp_login_url( $here ) ) . '">' . esc_html__( 'Login', 'modula-image-proofing' ) . '</a>';
	}

	private function get_modula_settings( $settings ) {
		if ( empty( $settings['expire_rejection_notice'] )
			&& empty( $settings['login_rejection_notice'] )
		) {
			$settings = array_merge(
				$settings,
				Gallery_Settings::get_image_proofing_defaults()
			);
		}

		return $settings;
	}
}
