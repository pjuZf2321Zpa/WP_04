<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Legacy admin proofing UI (metabox + admin-preview bundle) and shared admin affordances.
 *
 * When the v2 settings editor takeover is active, proofing is handled by the Pro settings-editor-proofing bundle
 * (the proofing manager modal); this class skips legacy metabox/script output in that case.
 */
class Modula_View_Override {

	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'handle_metaboxes' ), 9999999 );
		add_action( 'modula_scripts_after_wp_modula', array( $this, 'enqueue_scripts_and_styles' ) );
		add_filter( 'display_post_states', array( $this, 'custom_post_states' ), 10, 2 );
	}

	/**
	 * Whether the v2 gallery takeover / settings editor owns the proofing admin UI.
	 *
	 * @return bool
	 */
	private function is_gallery_takeover_active() {
		return class_exists( '\Modula\V2\Admin\Gallery_Takeover_Admin' )
			&& \Modula\V2\Admin\Gallery_Takeover_Admin::should_use_takeover();
	}

	public function handle_metaboxes() {
		if ( $this->is_gallery_takeover_active() ) {
			return;
		}

		$post_id          = get_the_ID();
		$proofing_enabled = $this->proofing_enabled( $post_id );
		$locked           = $this->gallery_locked_for_proofing( $post_id );

		$this->add_proofing_metabox( $locked );

		if ( ! $proofing_enabled || ! $locked ) {
			return;
		}

		$this->strip_gallery_metaboxes();
	}

	public function add_proofing_metabox( $locked ) {
		$position = $locked ? 'normal' : 'side';

		add_meta_box(
			'modula_proof_metabox',
			__( 'Image Proofing', 'modula-pro' ),
			array( $this, 'render_proof_metabox' ),
			'modula-gallery',
			$position,
			'high'
		);
	}

	public function strip_gallery_metaboxes() {
		$meta_boxes = $this->get_meta_boxes();

		foreach ( $meta_boxes as $meta_box ) {
			remove_meta_box( $meta_box['id'], 'modula-gallery', $meta_box['context'] );
		}
	}

	private function get_meta_boxes() {
		global $wp_meta_boxes;
		$meta_boxes = array();
		foreach ( $wp_meta_boxes['modula-gallery'] as $location => $priorities ) {
			foreach ( $priorities as $boxes ) {
				foreach ( $boxes as $box ) {
					if ( ! is_array( $box ) ) {
						continue;
					}
					$meta_boxes[] = array_merge( $box, array( 'context' => $location ) );
				}
			}
		}

		return $meta_boxes;
	}

	public function render_proof_metabox( $post ) {
		$gallery_id = $post->ID;
		echo '<div id="modula-proofing-metabox" data-galleryid="' . esc_attr( $gallery_id ) . '"></div>';
	}

	private function gallery_locked_for_proofing( $post_id ) {
		$locked = get_post_meta( $post_id, '_modula_locked_for_proofing', true );

		return ! empty( $locked );
	}

	private function proofing_enabled( $gallery_id ) {
		$settings = get_post_meta( $gallery_id, 'modula-settings', true );
		$settings = wp_parse_args( $settings, \Modula_CPT_Fields_Helper::get_defaults() );

		if ( isset( $settings['image_proofing'] ) && 1 === absint( $settings['image_proofing'] ) ) {
			return true;
		}

		return false;
	}

	public function enqueue_scripts_and_styles() {
		if ( $this->is_gallery_takeover_active() ) {
			return;
		}

		global $post;
		if ( ! $post || 'modula-gallery' !== $post->post_type ) {
			return;
		}

		$asset_path = \MODULA_PRO_PATH . 'includes/extensions/image-proofing/public/admin-preview/index.asset.php';
		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset_file = require $asset_path;
		$enqueue    = array(
			'handle'       => 'modula-admin-proofing',
			'dependencies' => $asset_file['dependencies'],
			'version'      => $asset_file['version'],
			'script'       => \MODULA_PRO_URL . 'includes/extensions/image-proofing/public/admin-preview/index.js',
			'style'        => \MODULA_PRO_URL . 'includes/extensions/image-proofing/public/admin-preview/index.css',
		);

		wp_enqueue_script(
			$enqueue['handle'],
			$enqueue['script'],
			$enqueue['dependencies'],
			$enqueue['version'],
			true
		);

		wp_enqueue_style(
			$enqueue['handle'],
			$enqueue['style'],
			array(),
			$enqueue['version']
		);

		wp_localize_script(
			$enqueue['handle'],
			'modulaProofing',
			array(
				'ajaxurl'        => admin_url( 'admin-ajax.php' ),
				'watermarkNonce' => wp_create_nonce( 'modula_watermark_images' ),
			)
		);
	}

	public function custom_post_states( $post_states, $post ) {
		if ( 'modula-gallery' !== $post->post_type ) {
			return $post_states;
		}

		if ( $this->gallery_locked_for_proofing( $post->ID ) ) {
			$post_states[] = __( 'Image proofing', 'modula-pro' );
		}

		return $post_states;
	}
}
