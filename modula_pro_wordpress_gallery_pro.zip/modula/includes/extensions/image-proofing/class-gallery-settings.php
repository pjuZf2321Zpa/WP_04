<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Gallery_Settings {

	/**
	 * Constructor for Gallery_Settings class
	 *
	 * @return void
	 * @since 1.0.0
	 *
	 */
	public function __construct() {
		add_filter( 'modula_gallery_tabs', array( $this, 'image_proofing_tab' ) );
		add_filter( 'modula_gallery_fields', array( $this, 'image_proofing_fields' ), 9999 );
		add_filter( 'modula_lite_default_settings', array( $this, 'image_proofing_defaults' ), 9 );
		add_filter( 'rest_prepare_modula-gallery', array( $this, 'prepare_gallery_rest' ), 10, 3 );
		add_filter( 'modula_admin_field_value', array( $this, 'prefill_notification_email_field' ), 10, 3 );
		add_filter( 'modula_v2_gallery_settings', array( $this, 'prefill_notification_email_v2' ), 10, 2 );

		add_action( 'modula_scripts_after_wp_modula', array( $this, 'conditions_script' ), 100 );
	}

	public static function get_image_proofing_defaults() {
		return array(
			'image_proofing'              => 0,
			'min_selection'               => 1,
			'max_selection'               => 1,
			'proofing_notification_email' => '',
			'login_rejection_notice'      => esc_html__( 'You do not have permission to review this gallery. If this is a mistake, please contact the site administrator.', 'modula-pro' ),
			'expire_rejection_notice'     => esc_html__( 'Your invitation to proof this gallery has expired. Please contact the site administrator.', 'modula-pro' ),
			'expire_link_to_page'         => 0,
			'expire_link_to_page_url'     => '',
			'show_login_link'             => 1,
		);
	}


	/**
	 * Image proofing Tab
	 *
	 * @param $tabs
	 *
	 * @return array $tabs
	 * @since 1.0.0
	 */
	public function image_proofing_tab( $tabs ) {
		$tabs['image_proofing'] = array(
			'label'       => esc_html__( 'Image Proofing', 'modula-pro' ),
			'title'       => esc_html__( 'Image Proofing', 'modula-pro' ),
			'description' => esc_html__( 'The settings bellow adjust the image proofing options .', 'modula-pro' ),
			'icon'        => 'dashicons dashicons-flag',
			'priority'    => 85,
		);

		if ( isset( $tabs['image_proofing']['badge'] ) ) {
			unset( $tabs['image_proofing']['badge'] );
		}

		return $tabs;
	}
	/**
	 * Add image proofing fields in gallery settings
	 *
	 * @param  array  $fields
	 *
	 * @return array $fields
	 * @since 1.0.0
	 *
	 */
	public function image_proofing_fields( $fields ) {
		$fields['image_proofing'] = array(
			'image_proofing'              => array(
				'name'        => esc_html__( 'Enable Image Proofing', 'modula-pro' ),
				'type'        => 'toggle',
				'default'     => 0,
				'description' => esc_html__( 'Enable this option to enable image proofing functionality for this gallery.', 'modula-pro' ),
				'priority'    => 1,
				'children'    => array( 'min_selection', 'max_selection', 'proofing_notification_email', 'login_rejection_notice', 'expire_rejection_notice' ),
				'data_type'   => 'bool',
			),
			'min_selection'               => array(
				'name'        => esc_html__( 'Minimum number of images', 'modula-pro' ),
				'type'        => 'number',
				'description' => esc_html__( 'Set the minimum number of images to select for proofing.', 'modula-pro' ),
				'default'     => 0,
				'is_child'    => true,
				'priority'    => 10,
				'data_type'   => 'number',
			),
			'max_selection'               => array(
				'name'        => esc_html__( 'Maximum number of images', 'modula-pro' ),
				'type'        => 'number',
				'description' => esc_html__( 'Set the maximum number of images to select for proofing.', 'modula-pro' ),
				'default'     => 0,
				'is_child'    => true,
				'priority'    => 20,
				'data_type'   => 'number',
			),
			'proofing_notification_email' => array(
				'name'         => esc_html__( 'Photographer notification email', 'modula-pro' ),
				'type'         => 'text',
				'description'  => esc_html__( 'Where to send the email when a client submits their final selection. Defaults to the gallery owner email.', 'modula-pro' ),
				'default'      => '',
				'is_child'     => true,
				'priority'     => 25,
				'data_type'    => 'text',
				'sanitization' => 'sanitize_email',
			),
			'login_rejection_notice'      => array(
				'name'         => esc_html__( 'Log-in required message', 'modula-pro' ),
				'type'         => 'textarea',
				'description'  => esc_html__( 'Write a message for the user that is not allowed to view or proof this gallery.', 'modula-pro' ),
				'default'      => esc_html__( 'You do not have permission to review this gallery. If this is a mistake, please contact the site administrator.', 'modula-pro' ),
				'is_child'     => true,
				'priority'     => 30,
				'data_type'    => 'text',
				// translators: %1$s is a placeholder for %%login-link%%,  %2$s is a placeholder for %%login-button%%, %3$s is a placeholder for %%mail-to-gallery-owner%%
				'after_text'   => sprintf( esc_html__( 'Use the %1$s placeholder to create a link or %2$s placeholder to create a button directing users to the login page. Use the %3$s placeholder to create a mail link to the gallery owner.', 'modula-pro' ), '<code contenteditable="true">%%login-link%%</code>', '<code contenteditable="true">%%login-button%%</code>', '<code contenteditable="true">%%mail-to-gallery-owner%%</code>' ),
				'sanitization' => array( $this, 'sanitize_textarea_field' ),
			),
			'show_login_link'             => array(
				'name'         => esc_html__( 'Show login link', 'modula-pro' ),
				'type'         => 'toggle',
				'description'  => esc_html__( 'Show a link to the login page in the rejection notice.', 'modula-pro' ),
				'default'      => 1,
				'is_child'     => true,
				'priority'     => 40,
				'data_type'    => 'bool',
				'sanitization' => array( $this, 'sanitize_bool_field' ),
			),
			'expire_rejection_notice'     => array(
				'name'         => esc_html__( 'Proofing invitation expired message', 'modula-pro' ),
				'type'         => 'textarea',
				'description'  => esc_html__( 'Write a message for the user that had the invitation expired.', 'modula-pro' ),
				'default'      => esc_html__( 'Your invitation to proof this gallery has expired. Please contact the site administrator.', 'modula-pro' ),
				'is_child'     => true,
				'priority'     => 50,
				'data_type'    => 'text',
				// translators: %1$s is a placeholder for %%mail-to-gallery-owner%%
				'after_text'   => sprintf( esc_html__( 'Use the %1$s placeholder to create a mail link to the gallery owner.', 'modula-pro' ), '<code contenteditable="true">%%mail-to-gallery-owner%%</code>' ),
				'sanitization' => array( $this, 'sanitize_textarea_field' ),
			),
			'expire_link_to_page'         => array(
				'name'         => esc_html__( 'Link to page', 'modula-pro' ),
				'type'         => 'toggle',
				'description'  => esc_html__( 'Redirect the user to a specific page after the invitation expires?', 'modula-pro' ),
				'default'      => 0,
				'is_child'     => true,
				'priority'     => 60,
				'data_type'    => 'bool',
				'sanitization' => array( $this, 'sanitize_bool_field' ),
			),
			'expire_link_to_page_url'     => array(
				'name'         => esc_html__( 'Link to page', 'modula-pro' ),
				'type'         => 'url',
				'description'  => esc_html__( 'Set the page where the user will be redirected after the invitation expires.', 'modula-pro' ),
				'default'      => '',
				'is_child'     => true,
				'priority'     => 70,
				'data_type'    => 'text',
				'sanitization' => 'esc_url',
			),
		);

		return $fields;
	}

	public function image_proofing_defaults( $defaults ) {
		return array_merge( $defaults, self::get_image_proofing_defaults() );
	}

	/**
	 * Prefill photographer notification email only for authenticated edit requests.
	 * Strip the address from public/view REST responses so it is not exposed.
	 *
	 * @param \WP_REST_Response $response Response.
	 * @param \WP_Post          $post     Gallery post.
	 * @param \WP_REST_Request  $request  Request.
	 * @return \WP_REST_Response
	 */
	public function prepare_gallery_rest( $response, $post, $request ) {
		$data = $response->get_data();

		if ( ! isset( $data['modulaSettings'] ) || ! is_array( $data['modulaSettings'] ) ) {
			$data['modulaSettings'] = array();
		}

		$context  = $request instanceof \WP_REST_Request ? $request->get_param( 'context' ) : 'view';
		$can_edit = current_user_can( 'edit_post', $post->ID );

		if ( 'edit' !== $context || ! $can_edit ) {
			unset( $data['modulaSettings']['proofing_notification_email'] );
			$response->set_data( $data );
			return $response;
		}

		$saved = isset( $data['modulaSettings']['proofing_notification_email'] )
			? trim( (string) $data['modulaSettings']['proofing_notification_email'] )
			: '';

		if ( '' === $saved || ! is_email( $saved ) ) {
			$author = get_userdata( $post->post_author );
			$data['modulaSettings']['proofing_notification_email'] = $author ? $author->user_email : '';
		}

		$response->set_data( $data );

		return $response;
	}

	/**
	 * Prefill classic gallery settings textbox with the author email when empty.
	 *
	 * @param mixed  $value    Current value.
	 * @param string $key      Setting key.
	 * @param array  $settings All settings.
	 * @return mixed
	 */
	public function prefill_notification_email_field( $value, $key, $settings ) {
		unset( $settings );

		if ( 'proofing_notification_email' !== $key ) {
			return $value;
		}

		$saved = is_string( $value ) ? trim( $value ) : '';

		if ( '' !== $saved && is_email( $saved ) ) {
			return $saved;
		}

		$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! $post_id ) {
			global $post;
			$post_id = $post instanceof \WP_Post ? absint( $post->ID ) : 0;
		}

		if ( ! $post_id ) {
			return $value;
		}

		$author = get_userdata( get_post_field( 'post_author', $post_id ) );

		return $author ? $author->user_email : $value;
	}

	/**
	 * Prefill photographer notification email in v2 settings for the settings editor.
	 *
	 * @param array $data       Grouped settings.
	 * @param int   $gallery_id Gallery ID.
	 * @return array
	 */
	public function prefill_notification_email_v2( $data, $gallery_id ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		if ( ! isset( $data['proofing'] ) || ! is_array( $data['proofing'] ) ) {
			$data['proofing'] = array();
		}

		$saved = isset( $data['proofing']['notificationEmail'] )
			? trim( (string) $data['proofing']['notificationEmail'] )
			: '';

		if ( '' === $saved || ! is_email( $saved ) ) {
			$author = get_userdata( get_post_field( 'post_author', $gallery_id ) );
			$data['proofing']['notificationEmail'] = $author ? $author->user_email : '';
		}

		return $data;
	}

	/**
	 * Resolve the photographer notification recipient for a gallery.
	 *
	 * @param int $gallery_id Gallery ID.
	 * @return string|false
	 */
	public static function get_notification_email( $gallery_id ) {
		$settings = get_post_meta( $gallery_id, 'modula-settings', true );
		$saved    = is_array( $settings ) && isset( $settings['proofing_notification_email'] )
			? trim( (string) $settings['proofing_notification_email'] )
			: '';

		if ( '' !== $saved && is_email( $saved ) ) {
			return $saved;
		}

		$author_id = get_post_field( 'post_author', $gallery_id );
		$author    = $author_id ? get_userdata( $author_id ) : false;

		return $author ? $author->user_email : false;
	}

	public function conditions_script() {
		wp_enqueue_script( 'modula-image-proofing-conditions', \MODULA_PRO_URL . 'includes/extensions/image-proofing/public/conditions/index.js', array( 'jquery', 'modula-conditions', 'modula-pro-conditions' ), \MODULA_PRO_VERSION, true );
		wp_enqueue_style( 'modula-image-proofing-conditions', \MODULA_PRO_URL . 'includes/extensions/image-proofing/public/conditions/index.css', array(), \MODULA_PRO_VERSION );
	}

	public function sanitize_textarea_field( $value ) {
		return wp_kses_post( $value );
	}

	public function sanitize_bool_field( $value ) {
		return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
	}

	public function sanitize_text_field( $value ) {
		return sanitize_text_field( $value );
	}
}
