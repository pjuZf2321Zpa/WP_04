<?php
namespace Modula_Pro\Extensions\Image_Proofing\Front;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue the React gallery-proofing bundle for modern v2 shortcode output.
 */
class Modern_Proofing_Scripts {

	/** @var self|null */
	private static $instance = null;

	/** @var string */
	private $extension_url = 'includes/extensions/image-proofing';

	/**
	 * @return self
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'modula_extra_scripts', array( $this, 'enqueue_modern_bundle' ), 15 );
	}

	/**
	 * Whether the modern v2 React gallery stack is active.
	 *
	 * @return bool
	 */
	private function is_modern_stack_enabled( $settings = array() ) {
		if ( ! class_exists( '\Modula\V2\Modern_Gallery' ) ) {
			return false;
		}
		$post_id = is_array( $settings ) ? \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( $settings ) : 0;
		return \Modula\V2\Modern_Gallery::is_modern_stack_enabled( $post_id );
	}

	/**
	 * Enqueue gallery-proofing for React galleries when proofing is enabled.
	 *
	 * @param array $settings Flat gallery settings.
	 * @return void
	 */
	public function enqueue_modern_bundle( $settings ) {
		if ( ! $this->is_modern_stack_enabled( $settings ) ) {
			return;
		}

		if ( ! Modern_Proofing_Bootstrap::is_proofing_enabled_for_settings( $settings ) ) {
			return;
		}

		$asset_path = \MODULA_PRO_PATH . $this->extension_url . '/public/gallery-proofing/index.asset.php';
		if ( ! file_exists( $asset_path ) ) {
			return;
		}

		$asset_file = require $asset_path;
		$handle     = 'modula-gallery-proofing';

		wp_enqueue_script(
			$handle,
			\MODULA_PRO_URL . $this->extension_url . '/public/gallery-proofing/index.js',
			$asset_file['dependencies'],
			$asset_file['version'],
			true
		);

		wp_localize_script(
			$handle,
			'modulaGalleryProofingApi',
			array(
				'root'  => esc_url_raw( rest_url() ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);

		wp_enqueue_style(
			$handle,
			\MODULA_PRO_URL . $this->extension_url . '/public/gallery-proofing/index.css',
			array( 'wp-components', 'dashicons' ),
			$asset_file['version']
		);

		wp_set_script_translations(
			$handle,
			'modula-image-proofing',
			\MODULA_PRO_PATH . $this->extension_url . '/languages'
		);
	}
}
