<?php
namespace Modula_Pro\Extensions\Image_Proofing\Front;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Inject galleryProofing metadata into v2 React bootstrap payloads.
 */
class Modern_Proofing_Bootstrap {

	/** @var self|null */
	private static $instance = null;

	/**
	 * @return self
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_filter( 'modula_modern_shortcode_data', array( $this, 'inject_v2_bootstrap_metadata' ), 10, 3 );
	}

	/**
	 * Whether image proofing is enabled in flat gallery settings.
	 *
	 * @param array $flat Flat gallery settings.
	 * @return bool
	 */
	public static function is_proofing_enabled_for_settings( $flat ) {
		return is_array( $flat ) && ! empty( $flat['image_proofing'] );
	}

	/**
	 * Runtime payload consumed by the gallery-proofing React bundle.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return array<string, mixed>|null
	 */
	public static function build_gallery_proofing_payload( $gallery_id ) {
		$gallery_id = absint( $gallery_id );
		if ( $gallery_id < 1 ) {
			return null;
		}

		return array(
			'galleryId'     => $gallery_id,
			'restNamespace' => 'modula-image-proofing/v1',
			'enabled'       => true,
		);
	}

	/**
	 * Inject galleryProofing into v2 React bootstrap metadata.
	 *
	 * @param array $gallery_data Bootstrap payload.
	 * @param array $flat         Flat gallery settings.
	 * @param int   $gallery_id   Gallery post ID.
	 * @return array
	 */
	public function inject_v2_bootstrap_metadata( $gallery_data, $flat, $gallery_id ) {
		if ( ! self::is_proofing_enabled_for_settings( $flat ) ) {
			return $gallery_data;
		}

		$payload = self::build_gallery_proofing_payload( $gallery_id );
		if ( empty( $payload ) ) {
			return $gallery_data;
		}

		if ( ! isset( $gallery_data['metadata'] ) || ! is_array( $gallery_data['metadata'] ) ) {
			$gallery_data['metadata'] = array();
		}

		$gallery_data['metadata']['galleryProofing'] = $payload;

		return $gallery_data;
	}
}
