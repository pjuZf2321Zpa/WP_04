<?php
namespace Modula_Pro\Extensions\Image_Proofing;

use Modula_Pro\Extensions\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rest_Api {
	private $data_handler;

	public function __construct() {
		$this->data_handler = new Data_Handler();

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			'modula-image-proofing/v1',
			'/config/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_gallery_config' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'config/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'set_gallery_config' ),
				'permission_callback' => array( $this, 'permissions_check_gallery_config_admin' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'config/lock/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'set_gallery_lock' ),
				'permission_callback' => array( $this, 'permissions_check_gallery_config_admin' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/annotations/(?P<image_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_annotations' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/annotations',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_annotation' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/annotations/(?P<annotation_id>[a-zA-Z0-9-]+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_annotation' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/annotations/(?P<annotation_id>[a-zA-Z0-9-]+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_annotation' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/selections',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'save_selection' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/selections/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_selection' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/selections/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_selection' ),
				'permission_callback' => array( $this, 'permissions_check_selection_moderation' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/selections/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'edit_selection' ),
				'permission_callback' => array( $this, 'permissions_check_selection_moderation' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/gallery-selections/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_gallery_selections' ),
				'permission_callback' => array( $this, 'permissions_check_gallery_owner_for_submissions' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/users',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_user' ),
				'permission_callback' => array( $this, 'create_user_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/invite-client',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'invite_client' ),
				'permission_callback' => array( $this, 'permissions_check_invite_client' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/enhancers',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_enhancers' ),
				'permission_callback' => array( $this, 'permissions_check_enhancers' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/enhancers',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_enhancers' ),
				'permission_callback' => array( $this, 'permissions_check_enhancers' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/invitations/(?P<invitation_id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'edit_invitation' ),
				'permission_callback' => array( $this, 'gallery_owner_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/invitations/(?P<invitation_id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_invitation' ),
				'permission_callback' => array( $this, 'gallery_owner_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/invitations/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_invitations' ),
				'permission_callback' => array( $this, 'gallery_owner_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/invitations/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_invitation' ),
				'permission_callback' => array( $this, 'gallery_owner_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/invitations/(?P<invitation_id>\d+)/send-email',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'send_invitation_email' ),
				'permission_callback' => array( $this, 'gallery_owner_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/send-test-email',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'send_test_email' ),
				'permission_callback' => array( $this, 'settings_permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/reset-email-template',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reset_email_template' ),
				'permission_callback' => array( $this, 'settings_permissions_check' ),
			)
		);

		register_rest_route(
			'modula-image-proofing/v1',
			'/nudge/(?P<gallery_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'send_photographer_nudge' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);
	}

	/**
	 * Who may manage Image Proofing global settings / test emails.
	 *
	 * @return bool
	 */
	public function settings_permissions_check() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Send a test invitation email to the current user.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function send_test_email( $request ) {
		unset( $request );

		$user = wp_get_current_user();
		if ( ! $user || ! is_email( $user->user_email ) ) {
			return new \WP_Error(
				'no_user_email',
				__( 'Could not determine your email address.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$email_handler = new Email_Handler();
		$result        = $email_handler->send_test_email( $user->user_email );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			array(
				'sent'    => true,
				'success' => true,
				'to'      => $user->user_email,
				'message' => __( 'Test email sent successfully.', 'modula-pro' ),
			)
		);
	}

	/**
	 * Reset invitation and/or selection email templates to file defaults.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function reset_email_template( $request ) {
		$body = $request->get_json_params();
		$type = isset( $body['type'] ) ? sanitize_key( $body['type'] ) : 'all';

		if ( ! in_array( $type, array( 'invitation', 'selection', 'all' ), true ) ) {
			return new \WP_Error(
				'invalid_type',
				__( 'Invalid email template type.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$settings = Email_Settings::reset_template( $type );

		return rest_ensure_response(
			array(
				'success'  => true,
				'type'     => $type,
				'settings' => $settings,
				'message'  => __( 'Email template reset to default.', 'modula-pro' ),
			)
		);
	}

	public function create_user_check() {
		return current_user_can( 'create_users' );
	}

	public function plugin_install_check() {
		return current_user_can( 'install_plugins' );
	}

	/**
	 * Who may change gallery modula-settings / lock via Image Proofing REST (admin flows only).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function permissions_check_gallery_config_admin( $request ) {
		if ( current_user_can( 'update_core' ) ) {
			return true;
		}

		$gallery_id = isset( $request['gallery_id'] ) ? absint( $request['gallery_id'] ) : 0;
		if ( ! $gallery_id || ! get_post( $gallery_id ) ) {
			return false;
		}

		if ( current_user_can( 'edit_post', $gallery_id ) ) {
			return true;
		}

		return absint( get_post_field( 'post_author', $gallery_id ) ) === get_current_user_id();
	}

	/**
	 * Extension enhancers: GET is used from the proofing admin UI; POST toggles extensions (install_plugins).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function permissions_check_enhancers( $request ) {
		if ( current_user_can( 'update_core' ) ) {
			return true;
		}
		if ( 'GET' === $request->get_method() ) {
			return current_user_can( 'edit_posts' );
		}
		return current_user_can( 'install_plugins' );
	}

	/**
	 * Invite-client email flow — must be able to edit the target gallery.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function permissions_check_invite_client( $request ) {
		if ( current_user_can( 'update_core' ) ) {
			return true;
		}

		$body       = $request->get_json_params();
		$gallery_id = isset( $body['gallery_id'] ) ? absint( $body['gallery_id'] ) : 0;

		if ( ! $gallery_id || ! get_post( $gallery_id ) ) {
			return false;
		}

		if ( current_user_can( 'edit_post', $gallery_id ) ) {
			return true;
		}

		return absint( get_post_field( 'post_author', $gallery_id ) ) === get_current_user_id();
	}

	/**
	 * Owner / editor access for all submissions on a gallery.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function permissions_check_gallery_owner_for_submissions( $request ) {
		if ( current_user_can( 'update_core' ) ) {
			return true;
		}

		$gallery_id = isset( $request['gallery_id'] ) ? absint( $request['gallery_id'] ) : 0;
		if ( ! $gallery_id || ! get_post( $gallery_id ) ) {
			return false;
		}

		if ( current_user_can( 'edit_post', $gallery_id ) ) {
			return true;
		}

		return absint( get_post_field( 'post_author', $gallery_id ) ) === get_current_user_id();
	}

	/**
	 * Unlock/delete selection rows (moderation).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function permissions_check_selection_moderation( $request ) {
		if ( current_user_can( 'update_core' ) ) {
			return true;
		}

		$selection_id = isset( $request['id'] ) ? absint( $request['id'] ) : 0;
		if ( ! $selection_id ) {
			return false;
		}

		$gallery_id = $this->data_handler->get_gallery_id_for_selection_id( $selection_id );
		if ( ! $gallery_id ) {
			return false;
		}

		if ( current_user_can( 'edit_post', $gallery_id ) ) {
			return true;
		}

		return absint( get_post_field( 'post_author', $gallery_id ) ) === get_current_user_id();
	}

	/**
	 * Resolve gallery post ID for proofing permission checks.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return int Gallery ID or 0.
	 */
	private function resolve_proofing_gallery_id_from_request( $request ) {
		if ( ! empty( $request['gallery_id'] ) ) {
			return absint( $request['gallery_id'] );
		}

		$json = $request->get_json_params();
		if ( is_array( $json ) && isset( $json['gallery_id'] ) ) {
			return absint( $json['gallery_id'] );
		}

		if ( ! empty( $request['image_id'] ) ) {
			$image_id = absint( $request['image_id'] );
			if ( $image_id ) {
				return absint( get_post_field( 'post_parent', $image_id ) );
			}
		}

		if ( is_array( $json ) && ! empty( $json['image_id'] ) ) {
			$image_id = absint( $json['image_id'] );
			if ( $image_id ) {
				return absint( get_post_field( 'post_parent', $image_id ) );
			}
		}

		$selection_param_id = $request->get_param( 'id' );
		if ( $selection_param_id && in_array( $request->get_method(), array( 'DELETE', 'PUT' ), true ) ) {
			$route = (string) $request->get_route();
			if ( false !== strpos( $route, '/selections/' ) ) {
				return $this->data_handler->get_gallery_id_for_selection_id( absint( $selection_param_id ) );
			}
		}

		if ( ! empty( $request['annotation_id'] ) ) {
			$annotation_id = sanitize_text_field( $request['annotation_id'] );
			if ( preg_match( '/^[a-zA-Z0-9-]+$/', $annotation_id ) ) {
				return $this->data_handler->get_gallery_id_for_annotation_uuid( $annotation_id );
			}
		}

		return 0;
	}

	/**
	 * Proofing REST: privileged users, invited users (by user ID or X-MIP-Identifier), or nothing.
	 * Never treat a random non-empty header as authorization.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function permissions_check( $request ) {
		if ( current_user_can( 'update_core' ) || current_user_can( 'edit_posts' ) || current_user_can( 'modula_select_images' ) ) {
			return true;
		}

		$gallery_id = $this->resolve_proofing_gallery_id_from_request( $request );
		if ( ! $gallery_id || ! get_post( $gallery_id ) ) {
			return false;
		}

		if ( is_user_logged_in() ) {
			$invite_status = $this->data_handler->is_invited( $gallery_id, (string) get_current_user_id() );
			if ( ! empty( $invite_status['invited'] ) && empty( $invite_status['expired'] ) ) {
				return true;
			}
		}

		$mip_raw = $request->get_header( 'X-MIP-Identifier' );
		if ( null === $mip_raw || '' === $mip_raw ) {
			return false;
		}

		$mip_identifier = sanitize_text_field( wp_unslash( $mip_raw ) );
		$invite_status  = $this->data_handler->is_invited( $gallery_id, $mip_identifier );

		return ! empty( $invite_status['invited'] ) && empty( $invite_status['expired'] );
	}

	public function gallery_owner_check( $request ) {
		if ( current_user_can( 'update_core' ) || current_user_can( 'edit_posts' ) ) {
			return true;
		}

		$body       = $request->get_json_params();
		$user_id    = get_current_user_id();
		$gallery_id = intval( $body['gallery_id'] );
		$post       = get_post( $gallery_id );

		return absint( $post->post_author ) === absint( $user_id );
	}

	public function get_annotations( $request ) {
		$image_id    = intval( $request['image_id'] );
		$annotations = $this->data_handler->get_annotations_by_image( $image_id );

		return rest_ensure_response( $annotations );
	}

	public function create_annotation( $request ) {
		$annotation_data = $request->get_json_params();
		// Validate and sanitize $annotation_data as needed

		$annotation_id = $this->data_handler->create_annotation( $annotation_data );

		return rest_ensure_response( array( 'annotation_id' => $annotation_id ) );
	}

	public function update_annotation( $request ) {
		$annotation_id   = sanitize_text_field( $request['annotation_id'] );
		$annotation_data = $request->get_json_params();
		// Validate and sanitize $annotation_data as needed
		$this->data_handler->update_annotation( $annotation_id, $annotation_data );

		return rest_ensure_response( array( 'annotation_id' => $annotation_id ) );
	}

	public function delete_annotation( $request ) {
		$annotation_id = sanitize_text_field( $request['annotation_id'] );

		$this->data_handler->delete_annotation( $annotation_id );

		return rest_ensure_response( array( 'deleted' => true ) );
	}

	public function save_selection( $request ) {
		$body    = $request->get_json_params();
		$user_id = $request->get_header( 'X-MIP-Identifier' ) ? sanitize_text_field( $request->get_header( 'X-MIP-Identifier' ) ) : get_current_user_id();

		$saved = $this->data_handler->save_selection(
			$body['gallery_id'],
			$body['image_ids'],
			$body['notes'],
			$body['submitted'],
			$user_id,
		);

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		if ( $body['submitted'] ) {
			$notifications = Notifications::get_instance();
			$email_handler = new Email_Handler();
			$gallery_title = $email_handler->get_gallery_title( $body['gallery_id'] );
			$user          = $email_handler->get_user_name( $user_id );

			$notifications->add_notification(
				'selection-notice-' . $body['gallery_id'] . '-' . $user_id,
				array(
					// translators: %s is the gallery title
					'title'   => sprintf( esc_html__( 'Selection Submitted for gallery: %s', 'modula-pro' ), $gallery_title ),
					// translators: %d is the number of images, %s is the user name
					'message' => sprintf( esc_html__( 'A selection of %1$d images has been submitted by %2$s.', 'modula-pro' ), count( $body['image_ids'] ), $user ),
					'actions' => array(
						array(
							'id'    => 'view-selection-' . $body['gallery_id'] . '-' . $user_id,
							'label' => __( 'View Selection', 'modula-pro' ),
							'url'   => esc_url_raw( admin_url( 'post.php?post=' . absint( $body['gallery_id'] ) . '&action=edit' ) ),
						),
					),
				)
			);

			$email_result = $email_handler->send_selection_email( $body['gallery_id'], $user_id );

			if ( is_wp_error( $email_result ) ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional failure logging
				error_log( 'Modula Image Proofing selection email: ' . $email_result->get_error_message() );
			} elseif ( true !== $email_result ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional failure logging
				error_log( 'Modula Image Proofing selection email: failed to send.' );
			}
		}

		return rest_ensure_response( array( 'saved' => true ) );
	}

	/**
	 * Client nudge: re-notify the photographer about a submitted selection (max 1/hour).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function send_photographer_nudge( $request ) {
		$gallery_id = absint( $request['gallery_id'] );
		$user_id    = $request->get_header( 'X-MIP-Identifier' )
			? sanitize_text_field( $request->get_header( 'X-MIP-Identifier' ) )
			: get_current_user_id();

		if ( ! $gallery_id || ! $user_id ) {
			return new \WP_Error(
				'invalid_request',
				__( 'Invalid gallery or user.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$selection = $this->data_handler->get_selection_by_user( $gallery_id, $user_id );
		if ( empty( $selection['submitted'] ) ) {
			return new \WP_Error(
				'not_submitted',
				__( 'You can only send a reminder after submitting your final selection.', 'modula-pro' ),
				array( 'status' => 400 )
			);
		}

		$transient_key = 'mip_nudge_' . $gallery_id . '_' . md5( (string) $user_id );
		if ( false !== get_transient( $transient_key ) ) {
			return new \WP_Error(
				'rate_limited',
				__( 'You can send another notification in one hour.', 'modula-pro' ),
				array( 'status' => 429 )
			);
		}

		$email_handler = new Email_Handler();
		$gallery_title = $email_handler->get_gallery_title( $gallery_id );
		$user_name     = $email_handler->get_user_name( $user_id );
		$image_count   = isset( $selection['image_ids'] ) && is_array( $selection['image_ids'] )
			? count( $selection['image_ids'] )
			: 0;

		Notifications::get_instance()->add_notification(
			'selection-nudge-' . $gallery_id . '-' . md5( (string) $user_id ) . '-' . time(),
			array(
				// translators: %s is the gallery title
				'title'   => sprintf( esc_html__( 'Selection reminder for gallery: %s', 'modula-pro' ), $gallery_title ),
				// translators: %1$s is the user name, %2$d is the number of images
				'message' => sprintf(
					esc_html__( '%1$s asked to notify you again about their submitted selection (%2$d images).', 'modula-pro' ),
					$user_name,
					$image_count
				),
				'actions' => array(
					array(
						'id'    => 'view-selection-nudge-' . $gallery_id . '-' . md5( (string) $user_id ),
						'label' => __( 'View Selection', 'modula-pro' ),
						'url'   => esc_url_raw( admin_url( 'post.php?post=' . $gallery_id . '&action=edit' ) ),
					),
				),
			)
		);

		$email_result = $email_handler->send_selection_email( $gallery_id, $user_id );

		if ( is_wp_error( $email_result ) ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional failure logging
			error_log( 'Modula Image Proofing nudge email: ' . $email_result->get_error_message() );
			return $email_result;
		}

		if ( true !== $email_result ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional failure logging
			error_log( 'Modula Image Proofing nudge email: failed to send.' );
			return new \WP_Error(
				'email_failed',
				__( 'Failed to send notification.', 'modula-pro' ),
				array( 'status' => 500 )
			);
		}

		set_transient( $transient_key, 1, HOUR_IN_SECONDS );

		return rest_ensure_response(
			array(
				'sent'    => true,
				'message' => __( 'Notification sent to the photographer.', 'modula-pro' ),
			)
		);
	}

	public function get_selection( $request ) {
		$gallery_id = intval( $request['gallery_id'] );
		$user_id    = $request->get_header( 'X-MIP-Identifier' ) ? sanitize_text_field( $request->get_header( 'X-MIP-Identifier' ) ) : get_current_user_id();
		$selection  = $this->data_handler->get_selection( $gallery_id, $user_id );

		return rest_ensure_response( $selection );
	}

	public function get_gallery_selections( $request ) {
		$gallery_id = intval( $request['gallery_id'] );
		$selections = $this->data_handler->get_gallery_selections( $gallery_id );

		return rest_ensure_response( $selections );
	}

	public function delete_selection( $request ) {
		$id = intval( $request['id'] );
		$this->data_handler->delete_selection( $id );

		return rest_ensure_response(
			array(
				'deleted' => true,
				'success' => true,
			)
		);
	}

	public function edit_selection( $request ) {
		$id     = intval( $request['id'] );
		$body   = $request->get_json_params();
		$action = $body['action'];

		switch ( $action ) {
			case 'unlock':
				$this->data_handler->unlock_selections( $id );
				break;
			default:
				return rest_ensure_response(
					array(
						'modified' => false,
						'success'  => false,
					)
				);
		}

		return rest_ensure_response(
			array(
				'modified' => true,
				'success'  => true,
			)
		);
	}

	public function get_gallery_config( $request ) {
		$gallery_id     = intval( $request['gallery_id'] );
		$settings       = get_post_meta( $gallery_id, 'modula-settings', true );
		$locked         = get_post_meta( $gallery_id, '_modula_locked_for_proofing', true );
		$mip_identifier = $request->get_header( 'X-MIP-Identifier' );
		$title          = get_the_title( $gallery_id );
		$defaults       = array(
			'max_selection'           => 0,
			'min_selection'           => 1,
			'image_proofing'          => false,
			'locked'                  => false,
			'login_rejection_notice'  => esc_html__( 'You do not have permission to review this gallery. If this is a mistake, please contact the site administrator.', 'modula-pro' ),
			'expire_rejection_notice' => esc_html__( 'Your invitation to proof this gallery has expired. Please contact the site administrator.', 'modula-pro' ),
			'title'                   => $title,
		);

		$config = array(
			'max_selection'           => isset( $settings['max_selection'] ) ? $settings['max_selection'] : $defaults['max_selection'],
			'min_selection'           => isset( $settings['min_selection'] ) ? $settings['min_selection'] : $defaults['min_selection'],
			'image_proofing'          => isset( $settings['image_proofing'] ) ? $settings['image_proofing'] : $defaults['image_proofing'],
			'locked'                  => empty( $locked ) ? $defaults['locked'] : (bool) $locked,
			'login_rejection_notice'  => isset( $settings['login_rejection_notice'] ) ? $settings['login_rejection_notice'] : $defaults['login_rejection_notice'],
			'expire_rejection_notice' => isset( $settings['expire_rejection_notice'] ) ? $settings['expire_rejection_notice'] : $defaults['expire_rejection_notice'],
		);

		if ( empty( $mip_identifier ) ) {
			$config['owner'] = get_current_user_id() === absint( get_post_field( 'post_author', $gallery_id ) );
		}

		$config = wp_parse_args( $config, $defaults );

		return rest_ensure_response( $config );
	}

	public function set_gallery_config( $request ) {
		$body             = $request->get_json_params();
		$gallery_id       = intval( $request['gallery_id'] );
		$config           = isset( $body['config'] ) && is_array( $body['config'] ) ? $body['config'] : array();
		$current_settings = get_post_meta( $gallery_id, 'modula-settings', true );
		if ( ! is_array( $current_settings ) ) {
			$current_settings = array();
		}
		foreach ( $config as $key => $value ) {
			switch ( $key ) {
				case 'enable_password':
				case 'protection':
					$config[ $key ] = (bool) $value;
					break;
				case 'password_protect_text':
					$config['password_protect_text'] = wp_kses_post( $value );
					break;
				case 'proofing_notification_email':
					$config[ $key ] = sanitize_email( $value );
					break;
				default:
					$config[ $key ] = sanitize_text_field( $value );
					break;
			}
		}
		$updated_settings = array_merge( $current_settings, $config );
		update_post_meta( $gallery_id, 'modula-settings', $updated_settings );

		return rest_ensure_response( array( 'updated' => true ) );
	}

	public function set_gallery_lock( $request ) {
		$body       = $request->get_json_params();
		$gallery_id = intval( $request['gallery_id'] );
		$lock       = absint( $body['lock'] );
		$config     = get_post_meta( $gallery_id, 'modula-settings', true );

		$config['image_proofing'] = $lock;

		update_post_meta( $gallery_id, 'modula-settings', $config );
		update_post_meta( $gallery_id, '_modula_locked_for_proofing', $lock );

		return rest_ensure_response( array( 'updated' => true ) );
	}

	public function create_user( $request ) {
		$body     = $request->get_json_params();
		$args     = array(
			'user_name'  => $body['user_name'],
			'user_email' => $body['user_email'],
		);
		$response = User_Manager::create_user( $args );

		return rest_ensure_response( $response );
	}

	public function get_enhancers() {
		return rest_ensure_response(
			array(
				'modula-watermark',
				'modula-password-protect',
				'modula-protection',
			)
		);
	}

	public function handle_enhancers( $request ) {
		$body   = $request->get_json_params();
		$action = $body['action'];

		switch ( $action ) {
			case 'activate':
				return $this->activate_enhancers( $request );
			case 'deactivate':
				return $this->deactivate_enhancers( $request );
		}
	}

	public function activate_enhancers( $request ) {
		$enhancer_request = $request->get_json_params();
		$slugs            = $enhancer_request['slugs'];
		$gallery_id       = intval( $request['gallery_id'] );

		$extensions = Extensions::get_instance();
		$extensions->toggle_active_status_of_extensions( $slugs, 'activate' );

		$config = get_post_meta( $gallery_id, 'modula-settings', true );
		foreach ( $slugs as $slug ) {
			switch ( $slug ) {
				case 'modula-watermark':
					$config['enable_watermark'] = true;
					break;
				case 'modula-password-protect':
					$config['enable_password'] = true;
					break;
				case 'modula-protection':
					$config['protection'] = true;
					break;
				default:
					break;
			}
		}
		update_post_meta( $gallery_id, 'modula-settings', $config );

		return rest_ensure_response(
			array(
				'activated' => true,
				'action'    => esc_html__( 'Deactivate', 'modula-pro' ),
				'status'    => 'active',
			)
		);
	}

	public function deactivate_enhancers( $request ) {
		$enhancer_request = $request->get_json_params();
		$slugs            = $enhancer_request['slugs'];

		$extensions = Extensions::get_instance();
		$extensions->toggle_active_status_of_extensions( $slugs, 'deactivate' );

		return rest_ensure_response(
			array(
				'deactivated' => true,
				'action'      => esc_html__( 'Activate', 'modula-pro' ),
				'status'      => 'installed',
			)
		);
	}

	public function invite_client( $request ) {
		$body          = $request->get_json_params();
		$email_handler = new Email_Handler();
		$email_handler->send_client_invitation_email( $body['gallery_id'], $body['user_id'] );

		$this->data_handler->create_invitation( $body['gallery_id'], $body['user_id'] );
		return rest_ensure_response(
			array(
				'invited' => true,
				'success' => true,
			)
		);
	}

	public function create_invitation( $request ) {
		$body          = $request->get_json_params();
		$invitation_id = $this->data_handler->create_invitation( $body['gallery_id'], $body['user_id'] );

		return rest_ensure_response(
			array(
				'created'       => true,
				'invitation_id' => $invitation_id,
				'success'       => true,
			)
		);
	}

	public function get_invitations( $request ) {
		$gallery_id  = intval( $request['gallery_id'] );
		$invitations = $this->data_handler->get_invitations( $gallery_id );

		return rest_ensure_response( $invitations );
	}

	public function delete_invitation( $request ) {
		$invitation_id = intval( $request['invitation_id'] );

		$this->data_handler->delete_invitation( $invitation_id );

		return rest_ensure_response(
			array(
				'deleted' => true,
				'success' => true,
			)
		);
	}

	public function edit_invitation( $request ) {
		$invitation_id = intval( $request['invitation_id'] );
		$body          = $request->get_json_params();
		$action        = $body['action'];

		switch ( $action ) {
			case 'expire':
				$this->data_handler->expire_invitation( $invitation_id );
				break;
			case 'activate':
				$this->data_handler->activate_invitation( $invitation_id );
				break;
			case 'unlock':
				$this->data_handler->unlock_selections( $invitation_id );
				break;
			default:
				return rest_ensure_response(
					array(
						'modified' => false,
						'success'  => false,
					)
				);
		}

		return rest_ensure_response(
			array(
				'modified' => true,
				'success'  => true,
			)
		);
	}

	public function send_invitation_email( $request ) {
		$body          = $request->get_json_params();
		$emails        = $body['emails'];
		$invitation_id = $body['invitationId'];

		$invitation    = $this->data_handler->get_invitation( $invitation_id );
		$email_handler = new Email_Handler();
		$emails_sent   = array();
		foreach ( $emails as $email ) {
			if ( ! is_email( $email ) ) {
				continue;
			}

			$emails_sent[] = $email_handler->send_invitation_email(
				$invitation['gallery_id'],
				$invitation['user_id'],
				$email
			);
		}

		return rest_ensure_response( array( 'sent' => $emails_sent ) );
	}
}
