<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Data_Handler {
	private $wpdb;
	private $annotations_table;
	private $gallery_selections_table;
	private $invitations_table;

	public function __construct() {
		global $wpdb;
		$this->wpdb                     = $wpdb;
		$this->annotations_table        = $this->wpdb->prefix . 'modula_image_proofing_annotations';
		$this->gallery_selections_table = $this->wpdb->prefix . 'modula_image_proofing_selections';
		$this->invitations_table        = $this->wpdb->prefix . 'modula_image_proofing_invitations';
	}

	public function create_annotation( $annotation_data ) {
		$data = array(
			'annotation_id' => sanitize_text_field( $annotation_data['id'] ),
			'image_id'      => intval( $annotation_data['image_id'] ),
			'user_id'       => get_current_user_id(),
			'type'          => sanitize_text_field( $annotation_data['target']['selector']['type'] ),
			'geometry'      => wp_json_encode( $annotation_data['target']['selector']['geometry'] ),
			'created_at'    => current_time( 'mysql' ),
			'updated_at'    => current_time( 'mysql' ),
		);

		$this->wpdb->insert( $this->annotations_table, $data, array( '%s', '%d', '%s', '%s', '%s', '%s', '%s' ) );

		return $this->wpdb->insert_id;
	}

	public function get_annotations_by_image( $image_id ) {
		$results = $this->wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$this->wpdb->prepare(
                // phpcs:ignore
				"SELECT * FROM {$this->annotations_table} WHERE image_id = %d", $image_id
			),
			ARRAY_A
		);

		// Decode geometry data
		foreach ( $results as &$result ) {
			$result['geometry'] = json_decode( $result['geometry'], true );
		}

		return $results;
	}

	public function update_annotation( $annotation_id, $annotation_data ) {
		$data = array(
			'geometry'   => wp_json_encode( $annotation_data['target']['selector']['geometry'] ),
			'updated_at' => current_time( 'mysql' ),
		);

		$where = array( 'annotation_id' => sanitize_text_field( $annotation_id ) );

		$this->wpdb->update(
			$this->annotations_table,
			$data,
			$where,
			array( '%s', '%s' ),
			array( '%s' )
		);
	}

	public function delete_annotation( $annotation_id ) {
		$this->wpdb->delete(
			$this->annotations_table,
			array( 'annotation_id' => sanitize_text_field( $annotation_id ) ),
			array( '%s' )
		);
	}

	public function save_selection( $gallery_id, $image_ids, $notes, $submitted, $head_user_id = null ) {
		$user_id       = $head_user_id ? $head_user_id : get_current_user_id();
		$invite_status = $this->is_invited( $gallery_id, $user_id );
		$user_can      = current_user_can( 'edit_posts' )
			|| ( ( current_user_can( 'modula_select_images' ) || null !== $head_user_id )
			&& $invite_status['invited']
			&& ! $invite_status['expired'] );

		if ( current_user_can( 'update_core' ) ) {
			$user_can = true;
		}

		if ( ! $user_id ) {
			return new \WP_Error( 'not_logged_in', __( 'User must be logged in to save selections.', 'modula-pro' ) );
		}

		if ( ! $user_can ) {
			return new \WP_Error( 'not_authorized', __( 'User is not authorized to save selections.', 'modula-pro' ) );
		}

		$gallery_id = intval( $gallery_id );
		$image_ids  = array_map( 'intval', $image_ids );

		$existing = $this->get_selection_by_user( $gallery_id, $user_id );

		if ( ! empty( $existing['submitted'] ) ) {
			return new \WP_Error(
				'selection_locked',
				__( 'This selection has already been submitted and cannot be changed until it is unlocked.', 'modula-pro' ),
				array( 'status' => 403 )
			);
		}

		$data = array(
			'gallery_id' => $gallery_id,
			'user_id'    => $user_id,
			'selections' => wp_json_encode( $image_ids ),
			'notes'      => sanitize_textarea_field( $notes ),
			'submitted'  => $submitted,
		);

		//phpcs:disable
		// Check if a selection already exists for this gallery and user
		$existing_selection = $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT COUNT(*) FROM {$this->gallery_selections_table} WHERE gallery_id = %d AND user_id = %s",
				$gallery_id,
				$user_id
			)
		);
		//phpcs:enable

		if ( $existing_selection ) {
			// Update existing selection
			$this->wpdb->update(
				$this->gallery_selections_table,
				$data,
				array(
					'gallery_id' => $gallery_id,
					'user_id'    => $user_id,
				),
				array( '%d', '%s', '%s', '%s', '%d' ),
				array( '%d', '%s' )
			);
		} else {
			// Insert new selection
			$this->wpdb->insert(
				$this->gallery_selections_table,
				$data,
				array( '%d', '%s', '%s', '%s', '%d' )
			);
		}
		return true;
	}

	public function get_selection( $gallery_id, $head_user_id = null ) {
		$user_id       = $head_user_id ? $head_user_id : get_current_user_id();
		$invite_status = $this->is_invited( $gallery_id, $user_id );
		$user_can      = current_user_can( 'edit_posts' )
			|| ( ( current_user_can( 'modula_select_images' ) || null !== $head_user_id )
			&& $invite_status['invited']
			&& ! $invite_status['expired'] );

		if ( current_user_can( 'update_core' ) ) {
			$user_can = true;
		}

		if ( ! $user_id ) {
			return new \WP_Error( 'not_logged_in', __( 'User must be logged in to get selections.', 'modula-pro' ) );
		}

		if ( ! $user_can ) {
			return new \WP_Error( 'not_authorized', __( 'User is not authorized to get selections.', 'modula-pro' ) );
		}

		return $this->get_selection_by_user( $gallery_id, $user_id );
	}

	public function get_gallery_selections( $gallery_id ) {
		$gallery_owner = get_post_field( 'post_author', $gallery_id );
		$user_can      = current_user_can( 'edit_posts' ) || absint( get_current_user_id() ) === absint( $gallery_owner );

		if ( current_user_can( 'update_core' ) ) {
			$user_can = true;
		}

		if ( ! $user_can ) {
			return new \WP_Error( 'not_authorized', __( 'User is not authorized to get gallery selections.', 'modula-pro' ) );
		}

		$gallery_id = intval( $gallery_id );

		$selections = $this->wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$this->wpdb->prepare(
				// phpcs:ignore
				"SELECT id, selections, notes, submitted, user_id FROM {$this->gallery_selections_table} WHERE gallery_id = %d",
				// phpcs:ignore
				$gallery_id
			),
			ARRAY_A
		);

		$results = array();
		foreach ( $selections as &$selection ) {
			$user_info = get_userdata( absint( $selection['user_id'] ) );
			if ( $user_info ) {
				$first_name = get_user_meta( absint( $selection['user_id'] ), 'first_name', true );
				$last_name  = get_user_meta( absint( $selection['user_id'] ), 'last_name', true );
				$user_name  = ( empty( $first_name ) && empty( $last_name ) ? $user_info->user_login : $first_name . ' ' . $last_name );
			} else {
				$user_name = $selection['user_id'];
			}

			$result    = array(
				'id'         => (int) $selection['id'],
				'image_ids'  => json_decode( $selection['selections'], true ),
				'notes'      => $selection['notes'],
				'submitted'  => (bool) absint( $selection['submitted'] ),
				'user_id'    => esc_html( $selection['user_id'] ),
				'user_name'  => esc_html( $user_name ),
				'user_email' => $user_info ? esc_html( $user_info->user_email ) : '',
			);
			$results[] = $result;
		}

		return $results;
	}

	public function get_selection_by_user( $gallery_id, $user_id ) {
		$gallery_id = intval( $gallery_id );
		$user_id    = $user_id;

		$selection_row = $this->wpdb->get_row(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared	
			$this->wpdb->prepare(
				// phpcs:ignore
				"SELECT id, selections, notes, submitted FROM {$this->gallery_selections_table} WHERE gallery_id = %d AND user_id = %s",
				// phpcs:ignore
				$gallery_id,
				// phpcs:ignore
				$user_id
			),
			ARRAY_A
		);

		if ( $selection_row ) {
			$image_ids = json_decode( $selection_row['selections'], true );
			$notes     = $selection_row['notes'];
			$submitted = $selection_row['submitted'];

			return array(
				'id'        => $selection_row['id'],
				'image_ids' => $image_ids,
				'notes'     => $notes,
				'submitted' => (bool) absint( $submitted ),
			);
		}

		return array(
			'id'        => null,
			'image_ids' => array(),
			'notes'     => '',
			'submitted' => false,
		);
	}

	public function delete_selection( $id ) {
		return $this->wpdb->delete(
			$this->gallery_selections_table,
			array( 'id' => $id ),
			array( '%d' )
		);
	}

	public function create_invitation( $gallery_id, $user_id ) {
		$existing_invitation = $this->wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$this->wpdb->prepare(
				// phpcs:ignore
				"SELECT id FROM {$this->invitations_table} WHERE gallery_id = %d AND user_id = %s",
				// phpcs:ignore
				$gallery_id,
				// phpcs:ignore
				$user_id
			)
		);

		if ( ! $existing_invitation ) {
			$this->wpdb->insert(
				$this->invitations_table,
				array(
					'gallery_id' => $gallery_id,
					'user_id'    => $user_id,
				),
				array( '%d', '%s' )
			);
			return $this->wpdb->insert_id;
		}

		return $existing_invitation;
	}

	public function delete_invitation( $invitation_id ) {
		$invitation = $this->get_invitation( $invitation_id );
		$gallery_id = $invitation['gallery_id'];
		$user_id    = $invitation['user_id'];

		$this->wpdb->delete(
			$this->invitations_table,
			array( 'id' => $invitation_id ),
			array( '%d' )
		);

		$this->wpdb->delete(
			$this->gallery_selections_table,
			array(
				'user_id'    => $user_id,
				'gallery_id' => $gallery_id,
			),
			array( '%s', '%d' )
		);

		return true;
	}

	public function expire_invitation( $invitation_id ) {
		$this->wpdb->update(
			$this->invitations_table,
			array( 'expired' => 1 ),
			array( 'id' => $invitation_id ),
			array( '%d' ),
			array( '%d' )
		);

		return true;
	}

	public function activate_invitation( $invitation_id ) {
		$this->wpdb->update(
			$this->invitations_table,
			array( 'expired' => 0 ),
			array( 'id' => $invitation_id ),
			array( '%d' ),
			array( '%d' )
		);
	}

	public function unlock_selections( $id ) {
		$this->wpdb->update(
			$this->gallery_selections_table,
			array( 'submitted' => 0 ),
			array( 'id' => $id ),
			array( '%d' ),
			array( '%d' )
		);

		return true;
	}

	public function expire_invitations_by_gallery( $gallery_id ) {
		$this->wpdb->update(
			$this->invitations_table,
			array( 'expired' => 1 ),
			array( 'gallery_id' => $gallery_id ),
			array( '%d' ),
			array( '%d' )
		);

		return true;
	}

	public function is_invited( $gallery_id, $user_id ) {
		$gallery_id = intval( $gallery_id );
		$user_id    = $user_id;

		// phpcs:disable
		$result = $this->wpdb->get_row(
			$this->wpdb->prepare(
				"SELECT expired FROM {$this->invitations_table} WHERE gallery_id = %d AND user_id = %s",
				$gallery_id,
				$user_id
			)
		);
		// phpcs:enable
		if ( ! $result ) {
			return array(
				'invited' => false,
				'expired' => false,
			);
		}

		return array(
			'invited' => true,
			'expired' => absint( $result->expired ) === 1,
		);
	}


	public function get_invitation( $invitation_id ) {
		// phpcs:disable
		return $this->wpdb->get_row(
			$this->wpdb->prepare( "SELECT * FROM {$this->invitations_table} WHERE id = %d", $invitation_id ),
			ARRAY_A
		);
		// phpcs:enable
	}

	public function get_invitations( $gallery_id ) {
		$gallery_id = intval( $gallery_id );
		// phpcs:disable
		$data = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SELECT i.*,
					COALESCE(s.selections, NULL) as selections,
					COALESCE(s.id, NULL) as submission_id,
					CASE 
						WHEN s.submitted IS NULL THEN 0
						WHEN s.submitted = '' THEN 0
						ELSE s.submitted 
						END as submitted
				FROM {$this->invitations_table} i
				LEFT JOIN {$this->gallery_selections_table} s 
					ON i.user_id = s.user_id 
					AND i.gallery_id = s.gallery_id
				WHERE i.gallery_id = %d",
				$gallery_id
			),
			ARRAY_A
		);
		// phpcs:enable

		if ( empty( $data ) ) {
			return $data;
		}

		foreach ( $data as &$invitation ) {
			$invitation['permalink'] = add_query_arg( 'mip_name', $invitation['user_id'], get_permalink( $gallery_id ) );

			if ( is_numeric( $invitation['user_id'] ) ) {
				$user = get_user_by( 'ID', $invitation['user_id'] );
				if ( $user ) {
					$invitation['name']      = $user->display_name;
					$invitation['email']     = $user->user_email;
					$invitation['permalink'] = get_permalink( $gallery_id );
				}
			}

			$invitation['image_details'] = $this->get_image_details( $invitation['selections'] );
		}
		unset( $invitation );

		return $data;
	}

	private function get_image_details( $image_ids ) {
		if ( is_null( $image_ids ) || ! $this->is_json( $image_ids ) ) {
			return array();
		}

		$image_ids     = json_decode( $image_ids, true );
		$image_details = array();
		foreach ( $image_ids as $image_id ) {
			$image_details[] = array(
				'id'       => $image_id,
				'filename' => basename( get_attached_file( $image_id ) ),
				'url'      => wp_get_attachment_url( $image_id ),
			);
		}
		return $image_details;
	}

	private function is_json( $string_value ) {
		return is_string( $string_value ) && is_array( json_decode( $string_value, true ) ) && ( json_last_error() === JSON_ERROR_NONE );
	}

	/**
	 * Resolve gallery ID from a proofing selection row primary key.
	 *
	 * @param int $selection_id Selection row ID.
	 * @return int Gallery post ID or 0.
	 */
	public function get_gallery_id_for_selection_id( $selection_id ) {
		$selection_id = absint( $selection_id );
		if ( ! $selection_id ) {
			return 0;
		}

		$gallery_id = $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT gallery_id FROM {$this->gallery_selections_table} WHERE id = %d",
				$selection_id
			)
		);

		return $gallery_id ? absint( $gallery_id ) : 0;
	}

	/**
	 * Resolve gallery ID from an annotation UUID (image parent post).
	 *
	 * @param string $annotation_id Annotation UUID.
	 * @return int Gallery post ID or 0.
	 */
	public function get_gallery_id_for_annotation_uuid( $annotation_id ) {
		$annotation_id = sanitize_text_field( $annotation_id );
		if ( '' === $annotation_id ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$table_exists = $this->wpdb->get_var( $this->wpdb->prepare( 'SHOW TABLES LIKE %s', $this->annotations_table ) );
		if ( $table_exists !== $this->annotations_table ) {
			return 0;
		}

		$image_id = $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT image_id FROM {$this->annotations_table} WHERE annotation_id = %s LIMIT 1",
				$annotation_id
			)
		);

		if ( ! $image_id ) {
			return 0;
		}

		return absint( get_post_field( 'post_parent', absint( $image_id ) ) );
	}
}
