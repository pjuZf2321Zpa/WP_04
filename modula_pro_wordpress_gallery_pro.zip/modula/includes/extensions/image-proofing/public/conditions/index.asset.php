<?php return array('dependencies' => array(), 'version' => 'eb039f81f3ece8639343');
