<?php return array('dependencies' => array('react', 'react-jsx-runtime', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n', 'wp-primitives'), 'version' => '018f917be2f105902b67');
