<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Frontend_Scripts {
	private $extension_url = 'includes/extensions/image-proofing';
	public function __construct() {
		add_action( 'modula_extra_scripts', array( $this, 'enqueue_react_apps' ) );
	}

	public function enqueue_react_apps( $settings ) {
		if (
			class_exists( '\Modula\V2\Modern_Gallery' )
			&& \Modula\V2\Modern_Gallery::is_modern_stack_enabled( \Modula\V2\Modern_Gallery::gallery_post_id_from_flat( is_array( $settings ) ? $settings : array() ) )
		) {
			return;
		}

		if ( ! isset( $settings['image_proofing'] ) || ! $settings['image_proofing'] ) {
			return;
		}

		$asset_file = require \MODULA_PRO_PATH . $this->extension_url . '/public/image-proofing/index.asset.php';
		$enqueue    = array(
			'handle'       => 'modula-image-proofing',
			'dependencies' => $asset_file['dependencies'],
			'version'      => $asset_file['version'],
			'script'       => \MODULA_PRO_URL . $this->extension_url . '/public/image-proofing/index.js',
			'style'        => \MODULA_PRO_URL . $this->extension_url . '/public/image-proofing/index.css',
		);

		wp_enqueue_script(
			$enqueue['handle'],
			$enqueue['script'],
			$enqueue['dependencies'],
			$enqueue['version'],
			true
		);

		wp_enqueue_style(
			$enqueue['handle'],
			$enqueue['style'],
			array( 'wp-components', 'dashicons' ),
			$enqueue['version']
		);
	}
}
