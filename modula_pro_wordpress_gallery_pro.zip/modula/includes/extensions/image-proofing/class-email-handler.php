<?php
namespace Modula_Pro\Extensions\Image_Proofing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Email_Handler {

	/**
	 * Send a client invitation email to a registered user.
	 *
	 * @param int $gallery_id Gallery ID.
	 * @param int $user_id    User ID.
	 * @param string|null $recipient Validated explicit recipient snapshot for recoverable callers.
	 * @return bool
	 */
	public function send_client_invitation_email( $gallery_id, $user_id, $recipient = null ) {
		$user_email   = null === $recipient ? $this->get_user_email( $user_id ) : $recipient;
		$gallery_link = get_permalink( $gallery_id );
		$gallery_name = $this->get_gallery_title( $gallery_id );

		return $this->send_invitation(
			$user_email,
			$gallery_id,
			array(
				'{{logo}}'         => Email_Settings::get_logo_html(),
				'{{gallery_name}}' => $gallery_name,
				'{{gallery_link}}' => $gallery_link,
				'{{intro_text}}'   => __( 'You have been invited to select images from the following gallery:', 'modula-pro' ),
			)
		);
	}

	/**
	 * Send an invitation email to an arbitrary address with a named identifier.
	 *
	 * @param int    $gallery_id Gallery ID.
	 * @param string $identifier Invitation identifier.
	 * @param string $email      Recipient email.
	 * @return bool
	 */
	public function send_invitation_email( $gallery_id, $identifier, $email ) {
		$gallery_link = get_permalink( $gallery_id );
		$gallery_name = $this->get_gallery_title( $gallery_id );

		return $this->send_invitation(
			$email,
			$gallery_id,
			array(
				'{{logo}}'         => Email_Settings::get_logo_html(),
				'{{gallery_name}}' => $gallery_name,
				'{{gallery_link}}' => $gallery_link . '?mip_name=' . rawurlencode( $identifier ),
				'{{intro_text}}'   => __( 'You have been invited to select images from the following gallery:', 'modula-pro' ),
			)
		);
	}

	/**
	 * Notify the gallery author (or configured address) that a selection was submitted.
	 *
	 * @param int          $gallery_id Gallery ID.
	 * @param int|string   $user_id    User ID or identifier.
	 * @return true|\WP_Error
	 */
	public function send_selection_email( $gallery_id, $user_id ) {
		$notification_email = Gallery_Settings::get_notification_email( $gallery_id );

		if ( ! $notification_email ) {
			return new \WP_Error( 'no_author_email', __( 'Could not determine photographer notification email.', 'modula-pro' ) );
		}

		$image_ids = $this->get_user_selection( $gallery_id, $user_id );

		if ( is_wp_error( $image_ids ) ) {
			return $image_ids;
		}

		if ( empty( $image_ids ) ) {
			return new \WP_Error( 'no_images_selected', __( 'No images were selected.', 'modula-pro' ) );
		}

		$email_content = $this->prepare_email_content( $gallery_id, $user_id );
		$email_sent    = $this->send_email(
			$notification_email,
			$email_content['subject'],
			$email_content['message'],
			$email_content['headers'],
			array(
				'type'       => 'selection',
				'gallery_id' => $gallery_id,
				'user_id'    => $user_id,
			)
		);

		if ( ! $email_sent ) {
			return new \WP_Error( 'email_failed', __( 'Failed to send email.', 'modula-pro' ) );
		}

		return true;
	}

	/**
	 * Send a test invitation email to the given address.
	 *
	 * @param string $to Recipient email.
	 * @return true|\WP_Error
	 */
	public function send_test_email( $to ) {
		if ( ! is_email( $to ) ) {
			return new \WP_Error( 'invalid_email', __( 'Invalid email address.', 'modula-pro' ) );
		}

		$sent = $this->send_invitation(
			$to,
			0,
			array(
				'{{logo}}'         => Email_Settings::get_logo_html(),
				'{{gallery_name}}' => __( 'Sample Gallery', 'modula-pro' ),
				'{{gallery_link}}' => home_url( '/' ),
				'{{intro_text}}'   => __( 'You have been invited to select images from the following gallery:', 'modula-pro' ),
			),
			true
		);

		if ( ! $sent ) {
			return new \WP_Error( 'email_failed', __( 'Failed to send test email.', 'modula-pro' ) );
		}

		return true;
	}

	/**
	 * Build and send an invitation email.
	 *
	 * @param string $to           Recipient.
	 * @param int    $gallery_id   Gallery ID (0 for test).
	 * @param array  $placeholders Placeholder map.
	 * @param bool   $is_test      Whether this is a test email.
	 * @return bool
	 */
	private function send_invitation( $to, $gallery_id, $placeholders, $is_test = false ) {
		$settings = Email_Settings::get_settings();
		$subject  = isset( $settings['invitation']['subject'] ) ? $settings['invitation']['subject'] : '';
		$body     = isset( $settings['invitation']['body'] ) ? $settings['invitation']['body'] : '';

		if ( '' === trim( (string) $body ) ) {
			$body = Email_Settings::get_default_template( 'client-invitation' );
		}

		$subject = $this->apply_subject_filter( $subject, 'invitation', $gallery_id );
		$body    = $this->replace_placeholders(
			$body,
			array_merge(
				array(
					'{{subject}}' => $subject,
				),
				$placeholders
			)
		);
		$body    = $this->apply_content_filter( $body, 'invitation', $gallery_id );

		$headers = $this->build_headers( 'invitation', $gallery_id );

		if ( $is_test ) {
			$subject = sprintf(
				/* translators: %s: original subject line */
				__( '[Test] %s', 'modula-pro' ),
				$subject
			);
		}

		return $this->send_email(
			$to,
			$subject,
			$body,
			$headers,
			array(
				'type'       => 'invitation',
				'gallery_id' => $gallery_id,
				'is_test'    => $is_test,
			)
		);
	}

	/**
	 * @param int          $gallery_id Gallery ID.
	 * @param int|string   $user_id    User ID or identifier.
	 * @return array|\WP_Error List of selected image IDs.
	 */
	private function get_user_selection( $gallery_id, $user_id ) {
		$data_handler = new Data_Handler();
		$selection    = $data_handler->get_selection_by_user( $gallery_id, $user_id );

		if ( is_wp_error( $selection ) ) {
			return $selection;
		}

		if ( empty( $selection['image_ids'] ) || ! is_array( $selection['image_ids'] ) ) {
			return array();
		}

		return $selection['image_ids'];
	}

	/**
	 * @param int          $gallery_id Gallery ID.
	 * @param int|string   $user_id    User ID or identifier.
	 * @return array{subject: string, message: string, headers: array}
	 */
	private function prepare_email_content( $gallery_id, $user_id ) {
		$settings  = Email_Settings::get_settings();
		$subject   = isset( $settings['selection']['subject'] ) ? $settings['selection']['subject'] : '';
		$body      = isset( $settings['selection']['body'] ) ? $settings['selection']['body'] : '';
		$image_ids = $this->get_user_selection( $gallery_id, $user_id );
		$count     = is_array( $image_ids ) ? count( $image_ids ) : 0;

		if ( '' === trim( (string) $body ) ) {
			$body = Email_Settings::get_default_template( 'selection-submission' );
		}

		$subject = $this->apply_subject_filter( $subject, 'selection', $gallery_id );
		$body    = $this->replace_placeholders(
			$body,
			array(
				'{{logo}}'              => Email_Settings::get_logo_html( $settings ),
				'{{subject}}'           => $subject,
				'{{gallery_id}}'        => $gallery_id,
				'{{user_id}}'           => $user_id,
				'{{user_name}}'         => $this->get_user_name( $user_id ),
				'{{user_email}}'        => $this->get_user_email( $user_id ),
				'{{gallery_title}}'     => $this->get_gallery_title( $gallery_id ),
				'{{gallery_url}}'       => get_permalink( $gallery_id ),
				'{{gallery_edit_url}}'  => $this->get_gallery_edit_url( $gallery_id ),
				'{{selection_count}}'   => (string) $count,
				'{{submitted_by_text}}' => $this->get_submitted_by_text( $user_id ),
			)
		);
		$body    = $this->apply_content_filter( $body, 'selection', $gallery_id );

		return array(
			'subject' => $subject,
			'message' => $body,
			'headers' => $this->build_headers( 'selection', $gallery_id ),
		);
	}

	/**
	 * Build email headers including From / Reply-To.
	 *
	 * @param string $type       Email type: invitation|selection.
	 * @param int    $gallery_id Gallery ID.
	 * @return array
	 */
	private function build_headers( $type, $gallery_id ) {
		$settings   = Email_Settings::get_settings();
		$from_name  = Email_Settings::get_effective_from_name( $settings );
		$from_email = Email_Settings::get_effective_from_email( $settings );
		$reply_to   = Email_Settings::get_effective_reply_to( $settings );

		/**
		 * Filter the Image Proofing From email address.
		 *
		 * @param string $from_email From email.
		 * @param string $type       Email type.
		 * @param int    $gallery_id Gallery ID.
		 */
		$from_email = apply_filters( 'modula_proofing_email_from', $from_email, $type, $gallery_id );

		/**
		 * Filter the Image Proofing From name.
		 *
		 * @param string $from_name  From name.
		 * @param string $type       Email type.
		 * @param int    $gallery_id Gallery ID.
		 */
		$from_name = apply_filters( 'modula_proofing_email_from_name', $from_name, $type, $gallery_id );

		/**
		 * Filter the Image Proofing Reply-To address.
		 *
		 * @param string $reply_to   Reply-To email.
		 * @param string $type       Email type.
		 * @param int    $gallery_id Gallery ID.
		 */
		$reply_to = apply_filters( 'modula_proofing_email_reply_to', $reply_to, $type, $gallery_id );

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			sprintf( 'From: %s <%s>', $this->sanitize_from_name( $from_name ), $from_email ),
			sprintf( 'Reply-To: %s', $reply_to ),
		);

		/**
		 * Filter the Image Proofing email headers.
		 *
		 * @param array  $headers    Headers.
		 * @param string $type       Email type.
		 * @param int    $gallery_id Gallery ID.
		 */
		return apply_filters( 'modula_proofing_email_headers', $headers, $type, $gallery_id );
	}

	/**
	 * @param string $subject    Subject.
	 * @param string $type       Email type.
	 * @param int    $gallery_id Gallery ID.
	 * @return string
	 */
	private function apply_subject_filter( $subject, $type, $gallery_id ) {
		/**
		 * Filter the Image Proofing email subject.
		 *
		 * @param string $subject    Subject.
		 * @param string $type       Email type.
		 * @param int    $gallery_id Gallery ID.
		 */
		return apply_filters( 'modula_proofing_email_subject', $subject, $type, $gallery_id );
	}

	/**
	 * @param string $content    HTML body.
	 * @param string $type       Email type.
	 * @param int    $gallery_id Gallery ID.
	 * @return string
	 */
	private function apply_content_filter( $content, $type, $gallery_id ) {
		/**
		 * Filter the Image Proofing email HTML body.
		 *
		 * @param string $content    HTML content.
		 * @param string $type       Email type.
		 * @param int    $gallery_id Gallery ID.
		 */
		return apply_filters( 'modula_proofing_email_content', $content, $type, $gallery_id );
	}

	/**
	 * @param string $content      Template content.
	 * @param array  $placeholders Placeholder map.
	 * @return string
	 */
	private function replace_placeholders( $content, $placeholders ) {
		return strtr( $content, $placeholders );
	}

	/**
	 * Strip characters that break From headers.
	 *
	 * @param string $name From name.
	 * @return string
	 */
	private function sanitize_from_name( $name ) {
		return str_replace( array( "\r", "\n", '<', '>' ), '', $name );
	}

	/**
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $message HTML body.
	 * @param array  $headers Headers.
	 * @param array  $context Optional context (unused; reserved for future logging).
	 * @return bool
	 */
	private function send_email( $to, $subject, $message, $headers = array(), $context = array() ) {
		unset( $context );
		return wp_mail( $to, $subject, $message, $headers );
	}

	/**
	 * Admin edit URL for a gallery. Must not use get_edit_post_link() during client
	 * submit — that returns empty when the current user cannot edit the post.
	 *
	 * @param int $gallery_id Gallery ID.
	 * @return string
	 */
	private function get_gallery_edit_url( $gallery_id ) {
		return admin_url( 'post.php?post=' . absint( $gallery_id ) . '&action=edit' );
	}

	/**
	 * @param int|string $user_id User ID or identifier.
	 * @return string
	 */
	public function get_user_name( $user_id ) {
		if ( is_numeric( $user_id ) && get_userdata( $user_id ) ) {
			$user = get_userdata( $user_id );
			return esc_html( $user->display_name );
		}

		return (string) $user_id;
	}

	/**
	 * @param int|string $user_id User ID or identifier.
	 * @return string
	 */
	public function get_user_email( $user_id ) {
		$user = get_userdata( $user_id );
		return $user ? esc_html( $user->user_email ) : '';
	}

	/**
	 * @param int $gallery_id Gallery ID.
	 * @return string
	 */
	public function get_gallery_title( $gallery_id ) {
		$gallery = get_post( $gallery_id );
		return $gallery ? esc_html( $gallery->post_title ) : '';
	}

	/**
	 * @param int|string $user_id User ID or identifier.
	 * @return string
	 */
	public function get_submitted_by_text( $user_id ) {
		$user = get_userdata( $user_id );

		// translators: %s is the user display name or ID
		$content = __( 'The images for proofing have been submitted by the user (%s), please check your gallery dashboard.', 'modula-pro' );

		if ( is_numeric( $user_id ) && $user ) {
			return sprintf( $content, esc_html( $user->display_name ) );
		}

		return sprintf( $content, $user_id );
	}
}
