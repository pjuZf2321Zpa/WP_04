<?php
namespace Modula_Pro\Admin;

use Modula_Pro\Extensions\Licensing;
use Modula_Pro\Utils\Bulk_Editor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {
	public function __construct() {

		add_action( 'admin_enqueue_scripts', array( $this, 'license_script' ) );
		add_filter( 'modula_admin_page_tabs', array( $this, 'add_license_tab' ) );
		add_action( 'admin_footer', array( $this, 'add_css_translation' ) );
		// Whatever the license: the content page needs the list once it has expired.
		add_filter( 'modula_gallery_listing_config', array( $this, 'add_pro_only_gallery_types' ) );

		if ( Licensing::get_instance()->has_plan() ) {
			// Remove Albums upsell metabox.
			add_action( 'do_meta_boxes', array( $this, 'remove_albums_upsell_metabox' ), 16, 1 );

			// Enqueue block assets.
			add_action( 'modula_block_style', array( $this, 'enqueue_modula_block_styles' ) );
			add_action( 'modula_block_scripts', array( $this, 'enqueue_modula_block_scripts' ) );

			// Run bulk editor functionality
			new Bulk_Editor();
		}
	}

	// deprecated, should be removed after 2.9.0
	public function add_license_tab() {}

	/**
	 * Tell the content page which gallery types need Pro or a Pro extension: the values Lite's
	 * settings document gates under `general.type.proEnhancements`, the list the gallery editor
	 * locks. The page marks those galleries PRO expired while the license is expired or in
	 * renewal grace. A Lite without that document leaves the list empty.
	 *
	 * @param array<string, mixed> $config Content page bootstrap.
	 * @return array<string, mixed>
	 */
	public function add_pro_only_gallery_types( $config ) {
		if ( ! is_array( $config ) ) {
			return $config;
		}
		if ( ! class_exists( '\Modula\V2\Settings\Settings_Schema_Document' ) || ! class_exists( '\Modula\V2\Abilities\Field_Requirements' ) ) {
			return $config;
		}

		$settings = \Modula\V2\Settings\Settings_Schema_Document::get_settings_tree_raw();
		$type     = isset( $settings['general']['type'] ) && is_array( $settings['general']['type'] ) ? $settings['general']['type'] : array();

		$config['proOnlyGalleryTypes'] = array_map( 'strval', array_keys( \Modula\V2\Abilities\Field_Requirements::for_values( $type ) ) );
		return $config;
	}

	public function add_css_translation() {
		global $pagenow, $typenow;

		if ( 'post.php' === $pagenow && 'modula-gallery' === $typenow ) {
			// Injectăm CSS-ul în footer
			echo '<style>
					:root {
						--modula-hidden-text: "' . esc_html__( 'Hidden', 'modula-pro' ) . '";
					}
				</style>';
		}
	}

	public function license_script() {
		global $id, $post;

		// Get current screen.
		$screen = get_current_screen();

		wp_enqueue_style( 'modula-pro-style', MODULA_PRO_URL . 'assets/js/misc/wp-modula-pro.css', array(), MODULA_PRO_VERSION );
	}

	public function remove_albums_upsell_metabox() {
		remove_meta_box( 'modula-albums-upsell', 'modula-gallery', 'normal' );
	}

	public function enqueue_modula_block_styles() {
		wp_enqueue_style( 'modula-pro-effects', MODULA_PRO_URL . 'assets/js/misc/effects.css', array(), MODULA_PRO_VERSION );

		wp_enqueue_style( 'modula-pro-bnb', MODULA_PRO_URL . 'assets/js/misc/modula-pro.css', array(), MODULA_PRO_VERSION );
	}

	public function enqueue_modula_block_scripts() {
		$screen = get_current_screen();
		if ( 'post' !== $screen->base && 'page' !== $screen->base && 'widgets' !== $screen->base ) {
			return;
		}
		wp_enqueue_script( 'modula-pro-gutenberg', MODULA_PRO_URL . 'assets/js/gutenberg/modula-pro.js', array( 'jquery' ), MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-pro', MODULA_PRO_URL . 'assets/js/misc/modula-pro.js', array( 'jquery' ), MODULA_PRO_VERSION, true );
		wp_enqueue_script( 'modula-pro-tilt', MODULA_PRO_URL . 'assets/js/misc/modula-pro-tilt.js', array( 'jquery' ), MODULA_PRO_VERSION, true );
	}
}
