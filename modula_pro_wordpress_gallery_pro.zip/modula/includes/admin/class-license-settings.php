<?php
namespace Modula_Pro\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers Settings › License (ADR 0049 in Lite): one main tab with a
 * license-kind subtab, which Lite draws as the shared license card. The card
 * saves through its own actions, so the subtab carries no settings config.
 *
 * @since 3.0.16
 */
class License_Settings {

	/**
	 * Main tab slug, subtab key and settings section id (`?section=license`).
	 */
	const SLUG = 'license';

	/**
	 * Lite places an unknown main tab in a section of its own after the known
	 * ones, in filter order: run after Lite's own late tabs (99) and other
	 * add-ons so License stays the last General section.
	 */
	const PRIORITY = 1000;

	/**
	 * Name of Lite's license card kind constant, read by name: an older Lite
	 * (the same minimum version) lacks it and cannot draw the card.
	 */
	const LITE_LICENSE_KIND_CONSTANT = 'Modula_Settings_Sections::LICENSE_KIND';

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Not admin-only: the settings app reads the tabs over REST.
		add_filter( 'modula_admin_page_main_tabs', array( $this, 'add_main_tab' ), self::PRIORITY );
	}

	/**
	 * Add the License main tab when Lite can draw license cards.
	 *
	 * @param array $tabs Main tabs.
	 * @return array
	 */
	public function add_main_tab( $tabs ) {
		if ( ! self::is_available() ) {
			return $tabs;
		}

		$tabs[] = array(
			'label'   => esc_html__( 'License', 'modula-pro' ),
			'slug'    => self::SLUG,
			'subtabs' => array(
				self::SLUG => array(
					'label' => esc_html__( 'License', 'modula-pro' ),
					'kind'  => constant( self::LITE_LICENSE_KIND_CONSTANT ),
				),
			),
		);

		return $tabs;
	}

	/**
	 * Whether Settings › License exists: Lite can draw license cards.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return defined( self::LITE_LICENSE_KIND_CONSTANT );
	}

	/**
	 * Whether Settings › License exists and the current user can open it.
	 *
	 * @return bool
	 */
	public static function can_open() {
		// Same capability as Modula Settings.
		return self::is_available() && current_user_can( 'manage_options' );
	}

	/**
	 * Address of Settings › License.
	 *
	 * @return string Unescaped URL.
	 */
	public static function url() {
		return admin_url( 'edit.php?post_type=modula-gallery&page=modula&section=' . self::SLUG );
	}
}
