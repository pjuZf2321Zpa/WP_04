<?php
namespace Modula_Pro\Admin;

use Modula_Pro\Extensions\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License links on the Plugins screen (decision 28 in Lite's extensions
 * redesign): every link opens Settings › License.
 *
 * @since 3.0.16
 */
class Plugins_Screen_License {

	/**
	 * Action link key, so other code can find or remove the link.
	 */
	const LINK_KEY = 'modula_license';

	/**
	 * After Lite's Settings and Upgrade links (60), so the license link can go before Settings.
	 */
	const LITE_ROW_PRIORITY = 70;

	/**
	 * Pro's Licensing, read for the license state and product.
	 *
	 * @var Licensing
	 */
	private $licensing;

	/**
	 * Modula PRO's plugin basename, which identifies its row.
	 *
	 * @var string
	 */
	private $pro_basename;

	/**
	 * Register the Plugins screen hooks.
	 *
	 * @param Licensing $licensing Pro's Licensing.
	 */
	public function __construct( Licensing $licensing ) {
		$this->licensing    = $licensing;
		$this->pro_basename = plugin_basename( MODULA_PRO_FILE );

		add_filter( 'plugin_action_links_' . MODULA_FILE, array( $this, 'add_lite_row_link' ), self::LITE_ROW_PRIORITY );
		add_filter( 'plugin_action_links_' . $this->pro_basename, array( $this, 'add_pro_row_link' ) );
		add_filter( 'plugin_row_meta', array( $this, 'add_pro_row_meta' ), 10, 2 );
		// Fires from WordPress 6.5, so the note never needs a fallback for wp_admin_notice() (6.4).
		add_action( 'after_plugin_row_meta', array( $this, 'render_pro_row_note' ) );
	}

	/**
	 * Put the license link on the Modula row, before Lite's Settings link, while the license asks for a
	 * key or a renewal.
	 *
	 * @param array $links Row action links.
	 * @return array
	 */
	public function add_lite_row_link( $links ) {
		$prompt = $this->prompt();
		if ( null === $prompt ) {
			return $links;
		}

		$position = $this->lite_row_link_position( $links );

		return array_slice( $links, 0, $position, true ) + array( self::LINK_KEY => $this->license_link( $prompt['link'] ) ) + array_slice( $links, $position, null, true );
	}

	/**
	 * Put the license link first on the Modula PRO row.
	 *
	 * @param array $links Row action links.
	 * @return array
	 */
	public function add_pro_row_link( $links ) {
		$texts = $this->row_texts();
		if ( null === $texts ) {
			return $links;
		}

		return array( self::LINK_KEY => $this->license_link( $texts['link'] ) ) + $links;
	}

	/**
	 * Add "<product name> · active" to the Modula PRO row's meta while the license is active.
	 *
	 * @param string[] $plugin_meta Row meta.
	 * @param string   $plugin_file Row's plugin basename.
	 * @return string[]
	 */
	public function add_pro_row_meta( $plugin_meta, $plugin_file ) {
		if ( $this->pro_basename !== $plugin_file || Licensing::STATE_ACTIVE !== $this->visible_state() ) {
			return $plugin_meta;
		}

		$plugin_meta[] = esc_html( $this->active_license_meta() );

		return $plugin_meta;
	}

	/**
	 * Print the note under the Modula PRO row's meta while the license asks for a key or a renewal.
	 *
	 * @param string $plugin_file Row's plugin basename.
	 */
	public function render_pro_row_note( $plugin_file ) {
		if ( $this->pro_basename !== $plugin_file ) {
			return;
		}

		$prompt = $this->prompt();
		if ( null === $prompt ) {
			return;
		}

		wp_admin_notice(
			esc_html( $prompt['note'] ) . ' ' . $this->license_link( $prompt['link'] ),
			array(
				'type'               => 'warning',
				'additional_classes' => array( 'notice-alt', 'inline' ),
			)
		);
	}

	/**
	 * Row texts while the license asks for a key or a renewal: they carry a note.
	 *
	 * @return array{link:string,note:string}|null Null while the license is active, or without links.
	 */
	private function prompt() {
		$texts = $this->row_texts();
		if ( null === $texts || null === $texts['note'] ) {
			return null;
		}

		return $texts;
	}

	/**
	 * License link text, and the note that asks for a key or a renewal, by license state.
	 *
	 * @return array{link:string,note:string|null}|null Null when the user gets no license links.
	 */
	private function row_texts() {
		$state = $this->visible_state();
		if ( null === $state ) {
			return null;
		}

		$renew          = array(
			'link' => __( 'Renew license', 'modula-pro' ),
			'note' => __( 'Renew your license to get updates and support.', 'modula-pro' ),
		);
		$texts_by_state = array(
			Licensing::STATE_ACTIVE        => array(
				'link' => __( 'License', 'modula-pro' ),
				'note' => null,
			),
			Licensing::STATE_NONE          => array(
				'link' => __( 'Enter license key', 'modula-pro' ),
				'note' => __( 'Enter your license key to get updates and support.', 'modula-pro' ),
			),
			Licensing::STATE_RENEWAL_GRACE => $renew,
			Licensing::STATE_EXPIRED       => $renew,
		);

		return $texts_by_state[ $state ] ?? null;
	}

	/**
	 * The license state, for users who can open Settings › License.
	 *
	 * @return string|null One of Licensing::STATE_*, null when the user gets no license links.
	 */
	private function visible_state() {
		if ( ! License_Settings::can_open() ) {
			return null;
		}

		return $this->licensing->get_license_state()['state'];
	}

	/**
	 * Meta text for an active license, such as "Agency license · active".
	 *
	 * @return string Unescaped.
	 */
	private function active_license_meta() {
		$product = $this->licensing->get_product_name();
		if ( '' === $product ) {
			return __( 'Active license', 'modula-pro' );
		}

		/* translators: %s: license product name, such as "Agency license". */
		return sprintf( __( '%s · active', 'modula-pro' ), $product );
	}

	/**
	 * Where the license link goes on the Modula row: before Lite's Settings link, as drawn, or before
	 * Deactivate when other code removed Settings; last when neither is there.
	 *
	 * @param array $links Row action links.
	 * @return int
	 */
	private function lite_row_link_position( $links ) {
		$keys = array_keys( $links );

		foreach ( array( 'settings', 'deactivate' ) as $anchor ) {
			$position = array_search( $anchor, $keys, true );
			if ( false !== $position ) {
				return $position;
			}
		}

		return count( $links );
	}

	/**
	 * Link to Settings › License.
	 *
	 * @param string $text Link text, unescaped.
	 * @return string
	 */
	private function license_link( $text ) {
		return '<a href="' . esc_url( License_Settings::url() ) . '">' . esc_html( $text ) . '</a>';
	}
}
