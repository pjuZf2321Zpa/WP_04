<?php
namespace Modula_Pro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lightbox_Enhancer {
	public function __construct() {
		add_filter( 'modula_fancybox_options', array( $this, 'output_lightbox_options' ), 10, 2 );
		add_filter( 'modula_fancybox_options', array( $this, 'output_lightbox_close_button' ), 9999, 2 );
		add_action( 'modula_extra_scripts', array( $this, 'check_for_fonts' ) );

		add_filter( 'modula_shortcode_item_data', array( $this, 'pro_extra_item_data' ), 16, 3 );

		add_action( 'modula_extra_scripts', array( $this, 'output_extra_effects_scripts' ) );

		add_action( 'modula_item_after_image', array( $this, 'extra_effects_extra_elements' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'preview_extra_effects_scripts' ) );
	}

	public function output_lightbox_options( $fancybox_options, $settings ) {
		$lightbox_share     = ( isset( $settings['lightbox_share'] ) && 1 === absint( $settings['lightbox_share'] ) ) || ( isset( $settings['enableSocial'] ) && 1 === absint( $settings['enableSocial'] ) );
		$lightbox_facebook  = ( isset( $settings['lightbox_facebook'] ) && 1 === absint( $settings['lightbox_facebook'] ) ) || ( isset( $settings['enableFacebook'] ) && 1 === absint( $settings['enableFacebook'] ) );
		$lightbox_twitter   = ( isset( $settings['lightbox_twitter'] ) && 1 === absint( $settings['lightbox_twitter'] ) ) || ( isset( $settings['enableTwitter'] ) && 1 === absint( $settings['enableTwitter'] ) );
		$lightbox_whatsapp  = ( isset( $settings['lightbox_whatsapp'] ) && 1 === absint( $settings['lightbox_whatsapp'] ) ) || ( isset( $settings['enableWhatsapp'] ) && 1 === absint( $settings['enableWhatsapp'] ) );
		$lightbox_linkedin  = ( isset( $settings['lightbox_linkedin'] ) && 1 === absint( $settings['lightbox_linkedin'] ) ) || ( isset( $settings['enableLinkedin'] ) && 1 === absint( $settings['enableLinkedin'] ) );
		$lightbox_pinterest = ( isset( $settings['lightbox_pinterest'] ) && 1 === absint( $settings['lightbox_pinterest'] ) ) || ( isset( $settings['enablePinterest'] ) && 1 === absint( $settings['enablePinterest'] ) );
		$lightbox_email     = ( isset( $settings['lightbox_email'] ) && 1 === absint( $settings['lightbox_email'] ) ) || ( isset( $settings['enableEmail'] ) && 1 === absint( $settings['enableEmail'] ) );

		$fancybox_options['buttons'] = array();

		if ( isset( $settings['loop_lightbox'] ) && 1 === absint( $settings['loop_lightbox'] ) ) {
			$fancybox_options['loop'] = true;
		}

		if ( isset( $fancybox_options['clickContent'] ) ) {
			unset( $fancybox_options['clickContent'] );
		}

		if ( isset( $settings['lightbox_toolbar'] ) && 1 === absint( $settings['lightbox_toolbar'] ) ) {
			$fancybox_options['toolbar'] = true;
		} else {
			$fancybox_options['toolbar'] = false;
		}

		if ( isset( $settings['lightbox_infobar'] ) && 1 === absint( $settings['lightbox_infobar'] ) ) {
			$fancybox_options['infobar'] = true;
		} else {
			$fancybox_options['infobar'] = false;
		}

		// Add all buttons.
		if ( isset( $settings['lightbox_zoom'] ) && 1 === absint( $settings['lightbox_zoom'] ) ) {
			$fancybox_options['buttons'][] = 'zoom';
		}

		if ( $lightbox_share ) {
			$fancybox_options['buttons'][]   = 'share';
			$fancybox_options['modulaShare'] = array();

			if ( $lightbox_facebook ) {
				$fancybox_options['modulaShare'][] = 'facebook';
			}

			if ( $lightbox_twitter ) {
				$fancybox_options['modulaShare'][] = 'twitter';
			}

			if ( $lightbox_whatsapp ) {
				$fancybox_options['modulaShare'][] = 'whatsapp';
			}

			if ( $lightbox_linkedin ) {
				$fancybox_options['modulaShare'][] = 'linkedin';
			}

			if ( $lightbox_pinterest ) {
				$fancybox_options['modulaShare'][] = 'pinterest';
			}

			if ( $lightbox_email ) {
				$fancybox_options['modulaShare'][] = 'email';
			}

			if ( isset( $settings['lightboxEmailSubject'] ) ) {
				$fancybox_options['lightboxEmailSubject'] = esc_html( $settings['lightboxEmailSubject'] );
			} elseif ( isset( $settings['emailSubject'] ) ) {
				$fancybox_options['lightboxEmailSubject'] = esc_html( $settings['emailSubject'] );
			} else {
				$fancybox_options['lightboxEmailSubject'] = esc_html__( 'Check out this awesome image !!', 'modula-pro' );
			}

			if ( isset( $settings['lightboxEmailMessage'] ) ) {
				$fancybox_options['lightboxEmailMessage'] = esc_html( $settings['lightboxEmailMessage'] );
			} elseif ( isset( $settings['emailMessage'] ) ) {
				$fancybox_options['lightboxEmailMessage'] = esc_html( $settings['emailMessage'] );
			} else {
				$fancybox_options['lightboxEmailMessage'] = esc_html__( 'Here is the link to the image : %%image_link%% and this is the link to the gallery : %%gallery_link%% ', 'modula-pro' );
			}

			if ( isset( $settings['galleryMessage'] ) ) {
				$fancybox_options['messageGallery'] = $settings['galleryMessage'];
			} else {
				$fancybox_options['messageGallery'] = esc_html__( 'Here is the link to the gallery :', 'modula-pro' );
			}
		}

		if ( isset( $settings['lightbox_download'] ) && 1 === absint( $settings['lightbox_download'] ) ) {
			$fancybox_options['buttons'][] = 'download';
		}

		if ( isset( $settings['lightbox_thumbs'] ) && 1 === absint( $settings['lightbox_thumbs'] ) ) {
			$fancybox_options['buttons'][] = 'thumbs';
		}

		if ( isset( $settings['lightbox_thumbsAutoStart'] ) && 1 === absint( $settings['lightbox_thumbsAutoStart'] ) ) {
			$fancybox_options['thumbs']['autoStart'] = true;
		} else {
			$fancybox_options['thumbs']['autoStart'] = false;
		}

		if ( isset( $settings['lightbox_animationEffect'] ) && 'false' !== $settings['lightbox_animationEffect'] ) {
			$fancybox_options['animationEffect'] = esc_html( $settings['lightbox_animationEffect'] );
		} else {
			$fancybox_options['animationEffect'] = false;
		}
		if ( isset( $settings['lightbox_animationDuration'] ) ) {
			$fancybox_options['animationDuration'] = (int) $settings['lightbox_animationDuration'];
		}

		if ( isset( $settings['lightbox_transitionEffect'] ) ) {
			$fancybox_options['transitionEffect'] = esc_html( $settings['lightbox_transitionEffect'] );
		}

		if ( isset( $settings['lightbox_animationEffect'] ) ) {
			$fancybox_options['animationEffect'] = esc_html( $settings['lightbox_animationEffect'] );
		}

		return $fancybox_options;
	}

	/**
	 * Legacy lightbox toggles are stored as 1/0, '1'/'0', or boolean (e.g. v2 / JSON).
	 *
	 * @param array  $settings Gallery settings.
	 * @param string $key      Setting key (e.g. showTitleLightbox).
	 * @return bool
	 */
	private function is_lightbox_toggle_on( array $settings, $key ) {
		if ( ! array_key_exists( $key, $settings ) ) {
			return false;
		}
		return filter_var( $settings[ $key ], FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Whether settings belong to a Beta (_modula_beta) gallery.
	 *
	 * Shortcode settings use gallery_id like `jtg-123` (classic) or `modula-123` (Beta).
	 *
	 * @param array $settings Gallery settings.
	 * @return bool
	 */
	private function is_beta_gallery_from_settings( array $settings ) {
		$raw = isset( $settings['gallery_id'] ) ? (string) $settings['gallery_id'] : '';
		if ( '' === $raw ) {
			return false;
		}

		$post_id = absint( preg_replace( '/[^0-9]/', '', $raw ) );
		if ( $post_id < 1 ) {
			return false;
		}

		if ( class_exists( '\Modula\V2\Beta_Settings' ) ) {
			return \Modula\V2\Beta_Settings::is_beta_gallery( $post_id );
		}

		return '1' === (string) get_post_meta( $post_id, '_modula_beta', true );
	}

	/**
	 * Whether this item uses the Fancybox trigger link (not a simple/custom URL link).
	 *
	 * @param array $item_data Filtered item data.
	 * @param array $image     Image row.
	 * @param array $settings  Gallery settings.
	 * @return bool
	 */
	private function should_apply_fancybox_caption_markup( array $item_data, array $image, array $settings ) {
		if ( empty( $settings['lightbox'] ) || ! in_array( (string) $settings['lightbox'], array( 'fancybox', 'lightbox-prefer-url' ), true ) ) {
			return false;
		}
		if ( ! empty( $image['link'] ) ) {
			return false;
		}
		$link_classes = isset( $item_data['link_classes'] ) && is_array( $item_data['link_classes'] ) ? $item_data['link_classes'] : array();
		if ( in_array( 'modula-simple-link', $link_classes, true ) ) {
			return false;
		}
		return ! empty( $item_data['link_attributes'] ) && is_array( $item_data['link_attributes'] );
	}

	public function output_lightbox_close_button( $fancybox_options, $settings ) {

		if ( isset( $settings['lightbox_close'] ) && 1 === absint( $settings['lightbox_close'] ) ) {
			$fancybox_options['buttons'][] = 'close';
		}

		return $fancybox_options;
	}

	public function check_for_fonts( $settings ) {

		if ( ( isset( $settings['hide_title'] ) && 1 === absint( $settings['hide_title'] ) ) && ( isset( $settings['hide_description'] ) && 1 === absint( $settings['hide_description'] ) ) ) {
			return;
		}

		if ( ! isset( $settings['captionsFontFamily'] ) || ! isset( $settings['titleFontFamily'] ) ) {
			return;
		}

		if ( 'Default' === $settings['captionsFontFamily'] && 'Default' === $settings['titleFontFamily'] ) {
			return;
		}

		$fonts = array();

		if ( 'Default' !== $settings['titleFontFamily'] ) {
			if ( 'normal' === $settings['titleFontWeight'] ) {
				$fonts[ $settings['titleFontFamily'] ] = array( 300, 400, 700 );
			} else {
				$fonts[ $settings['titleFontFamily'] ] = array( intval( $settings['titleFontWeight'] ) );
			}
		}

		if ( 'Default' !== $settings['captionsFontFamily'] ) {
			if ( 'normal' === $settings['captionFontWeight'] ) {
				$fonts_weights = array( 300, 400, 700 );
			} else {
				$fonts_weights = array( intval( $settings['captionFontWeight'] ) );
			}

			if ( isset( $fonts[ $settings['captionsFontFamily'] ] ) ) {
				$fonts[ $settings['captionsFontFamily'] ] = array_merge( $fonts[ $settings['captionsFontFamily'] ], $fonts_weights );
			} else {
				$fonts[ $settings['captionsFontFamily'] ] = $fonts_weights;
			}
		}

		if ( empty( $fonts ) ) {
			return;
		}

		$new_fonts = array();
		foreach ( $fonts as $font => $weights ) {
			$font_name   = str_replace( ' ', '+', $font );
			$new_fonts[] = $font_name . ':' . implode( ',', array_unique( $weights ) );
		}

		$fonts_string = implode( '|', $new_fonts );
		$font_url     = 'https://fonts.googleapis.com/css?family=' . $fonts_string . '&display=swap';
		wp_enqueue_style( 'modula-pro-font', $font_url, array(), MODULA_PRO_VERSION );
	}

	public function pro_extra_item_data( $item_data, $image, $settings ) {

		/**
		 * @since 2.2.2 after fancyBox update to v3.5.7
		 */
		// Check if not set prior by Modula Speedup with a highest priority filter
		if ( ! isset( $item_data['link_attributes']['data-thumb'] ) ) {
			$thumb = wp_get_attachment_image_src( $image['id'], 'thumbnail' );
			if ( $thumb ) {
				$item_data['link_attributes']['data-thumb'] = $thumb[0];
			} else {
				$item_data['link_attributes']['data-thumb'] = $item_data['img_attributes']['data-src'];
			}
		}

		/**
		 * @since 2.3.0
		 */
		if ( $this->should_apply_fancybox_caption_markup( $item_data, $image, $settings ) ) {
			$caption = '';

			if ( isset( $image['description'] ) && '' !== $image['description'] ) {
				$caption = $image['description'];
			} elseif ( wp_get_attachment_image_src( $image['id'] ) ) {
				$caption = wp_get_attachment_caption( $image['id'] );
			}

			$title = '';

			if ( isset( $image['title'] ) && '' !== $image['title'] ) {
				$title = $image['title'];
			} elseif ( wp_get_attachment_image_src( $image['id'] ) ) {
				$title = get_the_title( $image['id'] );
			}

			$show_title   = $this->is_lightbox_toggle_on( $settings, 'showTitleLightbox' ) && ( ! isset( $image['hide_title'] ) || 1 !== absint( $image['hide_title'] ) );
			$show_caption = $this->is_lightbox_toggle_on( $settings, 'showCaptionLightbox' );

			$caption_parts = array();
			if ( $show_title && '' !== $title ) {
				$caption_parts[] = '<span class="modula-caption-title">' . $title . '</span>';
			}
			if ( $show_caption && '' !== $caption ) {
				$caption_parts[] = '<span class="modula-caption-description">' . $caption . '</span>';
			}
			$item_data['link_attributes']['data-caption'] = ! empty( $caption_parts )
				? esc_attr( implode( '<br>', $caption_parts ) )
				: '';
		}

		if ( isset( $image['link'] ) && '' !== $image['link'] ) {
			$lightbox_mode = isset( $settings['lightbox'] ) ? (string) $settings['lightbox'] : '';
			$is_beta       = $this->is_beta_gallery_from_settings( $settings );

			/*
			 * Classic (non-Beta): keep the pre-3.0 Pro habit — Fancybox + Custom URL
			 * is still a tile redirect (href + modula-simple-link). Users on the old
			 * editor / shortcode stack stay on the scenario they know.
			 *
			 * Beta: Fancybox stays lightbox-first; Custom URL is exposed as
			 * data-modula-item-url for in-lightbox follow. Hybrid
			 * (lightbox-prefer-url) is the explicit mixed-gallery tile redirect.
			 */
			$fancybox_lightbox_first = ( 'fancybox' === $lightbox_mode && $is_beta );

			if ( $fancybox_lightbox_first ) {
				// Undo classic-style simple-link if an earlier filter added it.
				if ( isset( $item_data['link_attributes']['class'] ) && is_array( $item_data['link_attributes']['class'] ) ) {
					$item_data['link_attributes']['class'] = array_values(
						array_diff( $item_data['link_attributes']['class'], array( 'modula-simple-link' ) )
					);
				}
				if ( isset( $item_data['link_classes'] ) && is_array( $item_data['link_classes'] ) ) {
					$item_data['link_classes'] = array_values(
						array_diff( $item_data['link_classes'], array( 'modula-simple-link' ) )
					);
				}
				if ( isset( $item_data['item_classes'] ) && is_array( $item_data['item_classes'] ) ) {
					$item_data['item_classes'] = array_values(
						array_diff( $item_data['item_classes'], array( 'modula-simple-link' ) )
					);
				}

				$item_data['link_attributes']['data-modula-item-url'] = esc_url( $image['link'] );
				if ( isset( $image['target'] ) && ( 1 === absint( $image['target'] ) || '1' === (string) $image['target'] ) ) {
					$item_data['link_attributes']['data-modula-item-url-target'] = '_blank';
				}
			} else {
				unset( $item_data['link_attributes']['data-caption'] );
				unset( $item_data['link_attributes']['rel'] );
				unset( $item_data['link_attributes']['data-fancybox'] );
				unset( $item_data['link_attributes']['title'] );

				$item_data['link_attributes']['href'] = $image['link'];

				if ( isset( $image['target'] ) && 1 === absint( $image['target'] ) ) {
					$item_data['link_attributes']['target'] = '_blank';
				}

				$item_data['link_attributes']['class'][] = 'modula-simple-link';
				$item_data['item_classes'][]             = 'modula-simple-link';
			}
		}

		if ( isset( $settings['lightbox_download'] ) && 1 === absint( $settings['lightbox_download'] ) ) {
			if ( ! empty( $item_data['title'] ) ) {
				$item_data['img_attributes']['data-download-filename'] = $item_data['title'];
			} elseif ( ! empty( $item_data['img_attributes']['title'] ) ) {
				$item_data['img_attributes']['data-download-filename'] = $item_data['img_attributes']['title'];
			} else {
				$item_data['img_attributes']['data-download-filename'] = 'no-title';
			}
		}

		return $item_data;
	}

	public function output_extra_effects_scripts( $settings ) {

		$effect      = isset( $settings['effect'] ) ? (string) $settings['effect'] : '';
		$tilt_effect = array( 'tilt_1', 'tilt_2', 'tilt_3', 'tilt_4', 'tilt_5', 'tilt_6', 'tilt_7', 'tilt_8' );

		if ( in_array( $effect, $tilt_effect, true ) ) {
			wp_enqueue_script( 'modula-pro-tilt' );
		}
	}

	public function preview_extra_effects_scripts() {

		$current_screen = get_current_screen();

		// Register and Enqueue scripts only for Modula Gallery posts
		if ( 'modula-gallery' === $current_screen->id ) {

			// Modula Pro scripts used for Tilt Hover Effects
			wp_register_script( 'modula-pro-tilt', MODULA_PRO_URL . 'assets/js/misc/modula-pro-tilt.js', array( 'jquery' ), MODULA_PRO_VERSION, true );
			wp_enqueue_script( 'modula-pro-tilt' );
		}
	}

	public function extra_effects_extra_elements( $data ) {

		if ( count( $data->item_classes ) > 1 ) {
			$hover_effect  = $data->item_classes[1];
			$effect        = explode( '-', $hover_effect );
			$effect_array  = array( 'tilt_1', 'tilt_2', 'tilt_3', 'tilt_4', 'tilt_5', 'tilt_6', 'tilt_7', 'tilt_8' );
			$overlay_array = array( 'tilt_2', 'tilt_3', 'tilt_4', 'tilt_5', 'tilt_6', 'tilt_7', 'tilt_8' );
			$svg_array     = array( 'tilt_1', 'tilt_2', 'tilt_4', 'tilt_5', 'tilt_6', 'tilt_7', 'tilt_8' );
			if ( in_array( $effect[1], $effect_array, true ) ) {
				echo '<div class="tilter__deco tilter__deco--shine"><div></div></div>';

				if ( in_array( $effect[1], $overlay_array, true ) ) {
					echo '<div class="tilter__deco tilter__deco--overlay"></div>';
				}

				if ( in_array( $effect[1], $svg_array, true ) ) {
					echo '<div class="tilter__deco tilter__deco--lines"></div>';
				}
			}
		}
	}
}
