<?php
/** Folder offload/onload, library offload, status and cancel. Lite keeps schemas and retained-result inspection. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Transfer_Explanation;
use Modula\V2\Abilities\Transfers;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Storage;
use WPChill\Folders\Mutation_Lock;
use WPChill\Folders\Rest\Folder_Transfers_Controller;
use WPChill\Folders\Storage\Folder_Transfer_State;

defined( 'ABSPATH' ) || exit;

final class Transfer_Executor {
	/** Storage and transfer state services, rechecked before each effect. */
	public static function available(): bool {
		return Storage::available() && Transfers::inspect_ready();
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Transfer_Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$method = self::operations()[ $name ] ?? '';
		if ( '' === $method ) {
			return Transfer_Explanation::rejected( $name, $input, Availability::blockers( $name ) );
		}
		return call_user_func( array( self::class, $method ), $input );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Transfers::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/** Owned dispatch table and signature floor: older Lite-forwarding executors lack this contract.
	 * @return array<string,string>
	 */
	public static function operations(): array {
		return array(
			Transfers::START   => 'start',
			Transfers::LIBRARY => 'library',
			Transfers::READ    => 'read',
			Transfers::CANCEL  => 'cancel',
		);
	}

	private static function read( array $input ) {
		$blocked = Transfer_Provider::gate( Transfers::READ, $input );
		if ( null !== $blocked ) {
			return $blocked;
		}
		if ( ! Transfers::authorized( $input['job_id'] ) ) {
			return new \WP_Error( 'modula_forbidden', 'Current transfer and media permissions required.' );
		}
		$job = Folder_Transfers_Controller::service()->retained_status( $input['job_id'] );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		if ( ! is_array( $job ) ) {
			return new \WP_Error( 'modula_transfer_unavailable', 'Retained transfer is unavailable.' );
		}
		return array(
			'schema_version' => Contract::VERSION,
			'transfer'       => $job,
		);
	}

	private static function start( array $input ): array {
		return self::enqueue( $input, Transfers::START );
	}

	private static function library( array $input ): array {
		return self::enqueue( $input, Transfers::LIBRARY );
	}

	private static function enqueue( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! self::available() ) {
			return Requests::outcome( $input['request_id'], 'forbidden', 'current_permission_denied', '', $operation );
		}
		if ( ! self::valid_connection_input( $input, $operation ) ) {
			return Requests::outcome( $input['request_id'], 'rejected', 'invalid_connection', '', $operation );
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		try {
			$result = Mutation_Lock::run(
				'storage',
				static function () use ( $input, $operation ) {
					return self::admit_locked( $input, $operation );
				}
			);
			if ( is_wp_error( $result ) ) {
				return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'rejected', 'operation_busy', '', $operation ) );
			}
			return $result;
		} catch ( \Throwable $error ) {
			return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'uncertain', 'transfer_admission_unconfirmed', '', $operation ) );
		}
	}

	private static function valid_connection_input( array $input, string $operation ): bool {
		if ( Transfers::LIBRARY === $operation ) {
			return true;
		}
		if ( 'onload' === $input['direction'] ) {
			return ! isset( $input['connection_id'] );
		}
		return isset( $input['connection_id'] ) && '' !== $input['connection_id'];
	}

	/** Own admission, the request/job binding and transaction around the shared queue. */
	private static function admit_locked( array $input, string $operation ): array {
		$active = false;
		try {
			$blocked = Transfer_Provider::gate_admission( $operation, $input );
			if ( null !== $blocked ) {
				return Requests::finish( $input['request_id'], $blocked );
			}
			Revision::begin();
			$active = true;
			if ( ! hash_equals( $input['revision'], Revision::organization( true ) ) ) {
				throw new \DomainException( 'stale_revision' );
			}
			if ( ! self::available() ) {
				throw new \DomainException( 'current_permission_denied' );
			}
			$job_id = wp_generate_uuid4();
			Requests::context( $input['request_id'], array( 'job_id' => $job_id ) );
			$job = self::enqueue_job( $input, $operation, $job_id );
			if ( is_wp_error( $job ) ) {
				throw new \DomainException( $job->get_error_code() );
			}
			if ( ! Transfers::authorized( $job_id ) ) {
				throw new \DomainException( 'current_permission_denied' );
			}
			Revision::end( true );
			$active = false;
			return Transfers::recover( $input['request_id'], Requests::record( $input['request_id'] ) );
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			foreach ( array( Folder_Transfer_State::OPTION_KEY, 'alloptions', 'notoptions' ) as $key ) {
				wp_cache_delete( $key, 'options' );
			}
			$code   = $error instanceof \DomainException ? $error->getMessage() : 'transfer_admission_unconfirmed';
			$status = 'uncertain';
			if ( $error instanceof \DomainException ) {
				$status = 'stale_revision' === $code ? 'conflict' : 'rejected';
			}
			return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], $status, $code, '', $operation ) );
		}
	}

	private static function enqueue_job( array $input, string $operation, string $job_id ) {
		$service = Folder_Transfers_Controller::service();
		$context = array( 'id' => $job_id );
		if ( Transfers::LIBRARY === $operation ) {
			return $service->enqueue_library( $input['connection_id'], $context );
		}
		switch ( $input['direction'] ) {
			case 'offload':
				return $service->enqueue_folder_offload( $input['folder_id'], $input['connection_id'], $context );
			case 'onload':
				return $service->enqueue_folder_onload( $input['folder_id'], $context );
			default:
				return new \WP_Error( 'invalid_direction', 'Unknown transfer direction.' );
		}
	}

	private static function cancel( array $input ): array {
		$existing = Requests::existing( $input, Transfers::CANCEL );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! self::available() || ! Transfers::authorized( $input['job_id'] ) ) {
			return Requests::outcome( $input['request_id'], 'forbidden', 'current_permission_denied', '', Transfers::CANCEL );
		}
		$existing = Requests::claim( $input, Transfers::CANCEL );
		if ( null !== $existing ) {
			return $existing;
		}
		try {
			Requests::context( $input['request_id'], array( 'job_id' => $input['job_id'] ) );
			$result = Mutation_Lock::run(
				'storage',
				static function () use ( $input ) {
					return self::cancel_locked( $input );
				}
			);
			if ( is_wp_error( $result ) ) {
				return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'rejected', 'cancel_unconfirmed', '', Transfers::CANCEL ) );
			}
			return Requests::finish( $input['request_id'], $result );
		} catch ( \Throwable $error ) {
			return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'uncertain', 'cancel_unconfirmed', '', Transfers::CANCEL ) );
		}
	}

	private static function cancel_locked( array $input ) {
		$blocked = Transfer_Provider::gate_admission( Transfers::CANCEL, $input );
		if ( null !== $blocked ) {
			return $blocked;
		}
		if ( ! self::available() || ! Transfers::authorized( $input['job_id'] ) ) {
			return new \WP_Error( 'current_permission_denied' );
		}
		$service = Folder_Transfers_Controller::service();
		$active  = ( new Folder_Transfer_State() )->get();
		if ( $active && $active['id'] === $input['job_id'] ) {
			$job = $service->cancel( $input['job_id'] );
		} else {
			$job = $service->retained_status( $input['job_id'] );
		}
		if ( is_wp_error( $job ) || ! is_array( $job ) ) {
			return new \WP_Error( 'cancel_unconfirmed' );
		}
		return Requests::outcome( $input['request_id'], 'succeeded', '', '', Transfers::CANCEL ) + array( 'transfer' => $job );
	}
}
