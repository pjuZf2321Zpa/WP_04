<?php
/** Storage inspection, ingest/uningest and guarded cloud delete. Lite keeps schemas and the shared file pipeline. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Storage;
use Modula\V2\Abilities\Storage_Explanation;
use Modula\V2\Abilities\Attachments;
use Modula\V2\Abilities\Attachment_Lifecycle;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Media_Folders;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use WPChill\Folders\Mutation_Lock;
use WPChill\Folders\Rest\Connections_Controller;
use WPChill\Folders\Rest\Source_Groups_Controller;
use WPChill\Folders\Rest\Folders_Controller;
use WPChill\Folders\Storage\S3_Compatible_Source_Group_List_Adapter;
use WPChill\Folders\Storage\S3_Compatible_Object_Store;
use WPChill\Folders\Storage\Option_Provider_Map_Repository;
use WPChill\Folders\Storage\Cloud_Delete_Service;
use WPChill\Folders\Storage\Folder_Transfer_State;

defined( 'ABSPATH' ) || exit;

final class Storage_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$gated = Storage_Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		$method = self::operations()[ $name ] ?? '';
		if ( '' === $method ) {
			return Storage_Explanation::rejected( $name, $input, Availability::blockers( $name ) );
		}
		return call_user_func( array( self::class, $method ), $input );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Storage::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/** Owned dispatch table and signature floor: older Lite-forwarding executors lack this contract.
	 * @return array<string,string>
	 */
	public static function operations(): array {
		return array(
			Storage::LISTING  => 'listing',
			Storage::BROWSE   => 'browse',
			Storage::INGEST   => 'ingest',
			Storage::UNINGEST => 'uningest',
			Storage::DELETE   => 'delete',
		);
	}

	private static function listing( array $input ) {
		$blocked = Storage_Provider::gate( Storage::LISTING, $input );
		if ( null !== $blocked ) {
			return $blocked;
		}
		if ( ! Storage::available() ) {
			return new \WP_Error( 'modula_forbidden', 'Storage unavailable.' );
		}
		$rows = array();
		foreach ( Connections_Controller::service()->list_all() as $row ) {
			$rows[] = array(
				'id'   => (string) $row['id'],
				'name' => (string) ( $row['name'] ?? $row['id'] ),
			);
		}
		return Media_Folders::page( $input, $rows, 'connections' ) + array( 'revision' => Revision::organization() );
	}

	private static function browse( array $input ) {
		$blocked = Storage_Provider::gate( Storage::BROWSE, $input );
		if ( null !== $blocked ) {
			return $blocked;
		}
		if ( ! Storage::available() ) {
			return new \WP_Error( 'modula_forbidden', 'Storage unavailable.' );
		}
		$connection = Connections_Controller::service()->find( $input['connection_id'] );
		if ( ! $connection ) {
			return new \WP_Error( 'modula_storage_unavailable', 'Storage connection unavailable.' );
		}
		$revision = Revision::organization();
		$result   = ( new S3_Compatible_Source_Group_List_Adapter( $connection ) )->list_page( $input['prefix'] ?? '', $input['cursor'] ?? '', $input['per_page'] ?? 20 );
		if ( is_wp_error( $result ) ) {
			return new \WP_Error( 'modula_storage_read_failed', 'Remote listing could not be confirmed. No representation was changed.' );
		}
		$maps = new Option_Provider_Map_Repository();
		foreach ( $result['entries'] as &$row ) {
			unset( $row['ingested'] );
			$id                   = 'object' === $row['kind'] ? $maps->find_attachment_id( $input['connection_id'], $row['key'] ) : 0;
			$row['attachment_id'] = $id && Attachments::can_read( $id ) ? (int) $id : 0;
		}
		unset( $row );
		if ( ! hash_equals( $revision, Revision::organization() ) ) {
			return new \WP_Error( 'modula_read_conflict', 'Storage changed during inspection.' );
		}
		return array(
			'schema_version' => Contract::VERSION,
			'revision'       => $revision,
		) + $result;
	}

	private static function ingest( array $input ): array {
		return self::execute( $input, Storage::INGEST );
	}

	private static function uningest( array $input ): array {
		return self::execute( $input, Storage::UNINGEST );
	}

	private static function delete( array $input ): array {
		return self::execute( $input, Storage::DELETE );
	}

	/** Current target rights are checked both before claim and under the storage lock. */
	private static function permitted( array $input, string $operation ): bool {
		if ( ! Storage::available() ) {
			return false;
		}
		if ( Storage::INGEST === $operation ) {
			return true;
		}
		$id = $input['id'];
		return Attachments::can_read( $id ) && current_user_can( 'delete_post', $id )
			&& ( Storage::DELETE !== $operation || current_user_can( 'edit_post', $id ) );
	}

	private static function required_caps( int $id, string $operation ): array {
		if ( Storage::INGEST === $operation ) {
			return array();
		}
		$caps = map_meta_cap( 'delete_post', get_current_user_id(), $id );
		if ( Storage::DELETE === $operation ) {
			$caps = array_merge( $caps, map_meta_cap( 'read_post', get_current_user_id(), $id ), map_meta_cap( 'edit_post', get_current_user_id(), $id ) );
		}
		return array_values( array_unique( $caps ) );
	}

	private static function outcome( array $input, string $operation, string $status, string $code = '' ): array {
		return Requests::outcome( $input['request_id'], $status, $code, '' === $code ? '' : 'Inspect retained phases and representation before a new request.', $operation );
	}

	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! self::permitted( $input, $operation ) ) {
			return self::outcome( $input, $operation, 'forbidden', 'current_permission_denied' );
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$progress = array(
			'attachment_id'  => $input['id'] ?? 0,
			'phase'          => 'validation',
			'representation' => 'uncertain',
			'mapping'        => 'uncertain',
			'remote_bytes'   => Storage::DELETE === $operation ? 'uncertain' : 'unchanged',
		);
		try {
			Requests::context(
				$input['request_id'],
				array(
					'storage'       => $progress,
					'required_caps' => self::required_caps( $input['id'] ?? 0, $operation ),
				)
			);
			$locked = Mutation_Lock::run(
				'storage',
				static function () use ( $input, $operation, &$progress ) {
					return self::execute_locked( $input, $operation, $progress );
				}
			);
			if ( is_wp_error( $locked ) ) {
				return Requests::finish( $input['request_id'], self::outcome( $input, $operation, 'rejected', 'operation_busy' ) );
			}
			return $locked;
		} catch ( \Throwable $error ) {
			return Requests::finish( $input['request_id'], self::outcome( $input, $operation, 'uncertain', 'storage_effect_unconfirmed' ) + array( 'storage' => $progress ) );
		}
	}

	/** Own the transaction, effect sequence and durable checkpoints inside the worker mutex. */
	private static function execute_locked( array $input, string $operation, array &$progress ): array {
		$active = false;
		$map    = null;
		try {
			$blocked = Storage_Provider::gate_admission( $operation, $input );
			if ( null !== $blocked ) {
				return Requests::finish( $input['request_id'], $blocked );
			}
			Revision::begin();
			$active                   = true;
			$progress['remote_bytes'] = 'unchanged';
			self::validate_revision( $input, $operation );
			if ( ! self::permitted( $input, $operation ) ) {
				throw new \DomainException( 'current_permission_denied' );
			}
			if ( ( new Folder_Transfer_State() )->has_active() ) {
				throw new \DomainException( 'transfer_active' );
			}
			$maps = new Option_Provider_Map_Repository();
			if ( Storage::INGEST === $operation ) {
				self::ingest_object( $input, $maps, $progress );
			} else {
				$map = self::removal_target( $input, $operation, $maps );
				self::remove_object( $input, $operation, $maps, $map, $progress, $active );
			}
			$progress['phase'] = 'completed';
			// The representation, mapping and retained identity commit together.
			Requests::context( $input['request_id'], array( 'storage' => $progress ) );
			$response = Requests::finish( $input['request_id'], self::outcome( $input, $operation, 'succeeded' ) + array( 'storage' => $progress ) );
			if ( $active ) {
				Revision::end( true );
			}
			$active = false;
			return $response;
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			self::refresh_progress( $progress, $map );
			$code = $error instanceof \DomainException ? $error->getMessage() : 'storage_effect_unconfirmed';
			return Requests::finish( $input['request_id'], self::outcome( $input, $operation, self::failure_status( $error ), $code ) + array( 'storage' => $progress ) );
		}
	}

	private static function validate_revision( array $input, string $operation ): void {
		Revision::attachment_usage();
		$remove = Storage::INGEST !== $operation;
		if ( ! hash_equals( Revision::organization( true ), $remove ? $input['storage_revision'] : $input['revision'] ) ) {
			throw new \DomainException( 'stale_revision' );
		}
		if ( $remove && ! hash_equals( Revision::document( $input['id'], true ), $input['revision'] ) ) {
			throw new \DomainException( 'stale_revision' );
		}
	}

	/** Validate the exact mapped identity and usage before touching WordPress or the provider. */
	private static function removal_target( array $input, string $operation, Option_Provider_Map_Repository $maps ): array {
		$map = $maps->find_by_attachment( $input['id'] );
		if ( ! $map ) {
			throw new \DomainException( 'not_ingested' );
		}
		if ( Attachment_Lifecycle::used( $input['id'] ) ) {
			throw new \DomainException( 'attachment_in_use' );
		}
		if ( Storage::DELETE === $operation && ( $map['connection_id'] !== $input['connection_id'] || $map['key'] !== $input['key'] ) ) {
			throw new \DomainException( 'storage_target_mismatch' );
		}
		return $map;
	}

	private static function remove_object( array $input, string $operation, Option_Provider_Map_Repository $maps, array $map, array &$progress, bool &$active ): void {
		$service = new Cloud_Delete_Service( $maps, Folders_Controller::membership_service(), new S3_Compatible_Object_Store(), Connections_Controller::service() );
		if ( Storage::UNINGEST === $operation ) {
			$progress['phase'] = 'uningest';
			$result            = $service->uningest( $input['id'] );
			if ( is_wp_error( $result ) ) {
				throw new \DomainException( 'uningest_refused' );
			}
		} else {
			$result = $service->delete_from_bucket(
				$input['id'],
				static function ( $phase ) use ( &$progress, &$active, $input ) {
					$progress = array_merge( $progress, $phase );
					Requests::context( $input['request_id'], array( 'storage' => $progress ) );
					// Commit WordPress removal and the first checkpoint before irreversible DELETE.
					// Further provider checkpoints autocommit, including across process death.
					if ( $active && 'remote' === $phase['phase'] ) {
						Revision::end( true );
						$active = false;
					}
				}
			);
			if ( is_wp_error( $result ) ) {
				self::throw_delete_failure( $progress );
			}
		}
		if ( get_post( $input['id'] ) || $maps->find_by_attachment( $input['id'] ) || $maps->find_attachment_id( $map['connection_id'], $map['key'] ) ) {
			throw new \RuntimeException( 'Representation removal unconfirmed.' );
		}
		$progress['representation'] = 'removed';
		$progress['mapping']        = 'removed';
	}

	private static function throw_delete_failure( array $progress ): void {
		if ( 'unchanged' === $progress['remote_bytes'] ) {
			throw new \DomainException( 'cloud_delete_refused' );
		}
		throw new \RuntimeException( 'Cloud effects unconfirmed.' );
	}

	private static function ingest_object( array $input, Option_Provider_Map_Repository $maps, array &$progress ): void {
		$key = $input['key'];
		if ( '' === $key || '/' === substr( $key, -1 ) || false !== strpos( $key, '..' ) || false !== strpos( $key, '\\' ) || '/' === $key[0] || preg_match( '/[\x00-\x1f]/', $key ) ) {
			throw new \DomainException( 'invalid_object_key' );
		}
		$connection = Connections_Controller::service()->find( $input['connection_id'] );
		if ( ! $connection ) {
			throw new \DomainException( 'connection_unavailable' );
		}
		$id = $maps->find_attachment_id( $input['connection_id'], $key );
		if ( $id && ! Attachments::can_read( $id ) ) {
			throw new \DomainException( 'current_permission_denied' );
		}
		// HEAD verifies existence without downloading or modifying the object.
		$remote = ( new S3_Compatible_Object_Store() )->head( $connection, $key );
		if ( is_wp_error( $remote ) ) {
			throw new \DomainException( 'remote_object_unconfirmed' );
		}
		$progress['phase'] = 'ingest';
		$capture           = static function ( $id ) use ( &$progress ) {
			$progress['attachment_id'] = (int) $id;
		};
		add_action( 'add_attachment', $capture, -999 );
		try {
			$result = Source_Groups_Controller::ingest_service()->ingest( $input['connection_id'], $key );
		} finally {
			remove_action( 'add_attachment', $capture, -999 );
		}
		if ( is_wp_error( $result ) ) {
			throw new \RuntimeException( 'Ingest unconfirmed.' );
		}
		$progress['attachment_id'] = (int) $result['attachment_id'];
		if ( (int) $maps->find_attachment_id( $input['connection_id'], $key ) !== $progress['attachment_id'] || ! get_post( $progress['attachment_id'] ) ) {
			throw new \RuntimeException( 'Mapping unconfirmed.' );
		}
		$progress['representation'] = $id ? 'reused' : 'created';
		$progress['mapping']        = 'present';
	}

	/** Re-read after rollback; never project stale option/post caches as confirmation. */
	private static function refresh_progress( array &$progress, ?array $map ): void {
		foreach ( array( Option_Provider_Map_Repository::OPTION_KEY, 'alloptions', 'notoptions' ) as $key ) {
			wp_cache_delete( $key, 'options' );
		}
		$id = $progress['attachment_id'];
		if ( $id ) {
			clean_post_cache( $id );
		}
		$maps                       = new Option_Provider_Map_Repository();
		$progress['representation'] = $id && get_post( $id ) ? 'retained' : 'absent';
		$progress['mapping']        = 'absent';
		if ( $id && $maps->find_by_attachment( $id ) ) {
			$progress['mapping'] = 'present';
			return;
		}
		if ( $map && $maps->find_attachment_id( $map['connection_id'], $map['key'] ) ) {
			$progress['mapping'] = 'index_retained';
		}
	}

	private static function failure_status( \Throwable $error ): string {
		if ( ! $error instanceof \DomainException ) {
			return 'uncertain';
		}
		return 'stale_revision' === $error->getMessage() ? 'conflict' : 'rejected';
	}
}
