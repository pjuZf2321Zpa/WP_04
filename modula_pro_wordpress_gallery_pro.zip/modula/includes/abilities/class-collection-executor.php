<?php
/** Paid Collection reads and mutations. Lite owns free Favorites and historical authorization. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Attachments;
use Modula\V2\Abilities\Collection_Explanation;
use Modula\V2\Abilities\Collections;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Media_Folders;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use WPChill\Folders\Rest\Collections_Controller;

defined( 'ABSPATH' ) || exit;

final class Collection_Executor {
	/** @return array<string,mixed>|\WP_Error */
	public static function run( string $name, array $input ) {
		$method = self::operations()[ $name ] ?? '';
		if ( '' === $method ) {
			return new \WP_Error( 'modula_unknown_operation', 'Unknown Collection operation.' );
		}
		$gated = Collection_Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		return call_user_func( array( self::class, $method ), $input, $name );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( array_keys( self::operations() ) as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/** Owned operation table also rejects older Lite-forwarding executor packages. */
	public static function operations(): array {
		return array(
			Collections::LISTING       => 'listing',
			Collections::MEMBERS       => 'listing',
			Collections::CREATE        => 'mutate',
			Collections::UPDATE        => 'mutate',
			Collections::DELETE        => 'mutate',
			Collections::ADD_MEMBER    => 'mutate',
			Collections::REMOVE_MEMBER => 'mutate',
		);
	}

	private static function listing( array $input, string $operation ) {
		if ( ! Collections::available( $operation ) ) {
			return new \WP_Error( 'modula_forbidden', 'Current organizer permission and feature access are required.' );
		}
		$revision = Revision::collections();
		$service  = Collections_Controller::service();
		if ( Collections::LISTING === $operation ) {
			$rows   = array_map( array( self::class, 'summary' ), $service->list_all() );
			$result = Media_Folders::page( $input, $rows, 'collections' );
		} else {
			if ( ! $service->find( $input['id'] ) ) {
				return new \WP_Error( 'modula_not_found', 'Collection not found.' );
			}
			$ids = array_values( array_filter( $service->object_ids( $input['id'] ), array( Attachments::class, 'can_read' ) ) );
			sort( $ids );
			$result                = Media_Folders::page( $input, $ids, 'attachments' );
			$result['attachments'] = array_map( array( Attachments::class, 'summary' ), $result['attachments'] );
		}
		if ( ! hash_equals( $revision, Revision::collections() ) ) {
			return new \WP_Error( 'modula_read_conflict', 'Organization changed during inspection. Read again.' );
		}
		return $result + array( 'revision' => $revision );
	}

	private static function summary( array $row ): array {
		return Contract::project( $row, Collections::collection_schema() );
	}

	private static function is_member_operation( string $operation ): bool {
		return in_array( $operation, array( Collections::ADD_MEMBER, Collections::REMOVE_MEMBER ), true );
	}

	private static function mutate( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! Collections::available( $operation ) || ( self::is_member_operation( $operation ) && ! Attachments::can_read( $input['id'] ) ) ) {
			return Requests::outcome( $input['request_id'], 'forbidden', 'current_permission_denied', 'Current organizer and attachment access are required.', $operation );
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$active = false;
		try {
			// Keep historical authorization outside the effect transaction; the locked revision protects this member snapshot.
			$ids = self::affected_media( $input, $operation );
			Requests::context( $input['request_id'], array( 'media_ids' => $ids ) );
			Revision::begin();
			$active   = true;
			$blockers = Collections::explain_blockers( $operation, $input );
			if ( $blockers ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], Collection_Explanation::outcome( $operation, $input, $blockers ) );
			}
			if ( ! hash_equals( Revision::collections( true ), $input['revision'] ) ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'conflict', 'stale_revision', 'Read current collections/favorites and reconcile before a new request.', $operation ) );
			}
			self::authorize_media( $ids );
			$blockers = Collections::explain_blockers( $operation, $input );
			if ( $blockers ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], Collection_Explanation::outcome( $operation, $input, $blockers ) );
			}
			$fields               = self::fields( $input );
			$response             = self::apply_mutation( $input, $operation, $fields );
			$response             = Requests::outcome( $input['request_id'], 'succeeded', '', '', $operation ) + $response;
			$response['revision'] = Revision::collections();
			$response             = Requests::finish( $input['request_id'], $response );
			Revision::end( true );
			$active = false;
			return $response;
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			if ( $error instanceof \DomainException ) {
				return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'rejected', $error->getMessage(), 'Collection mutation was refused.', $operation ) );
			}
			return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'uncertain', 'organization_unconfirmed', 'Recover this identity before further action.', $operation ) );
		}
	}

	/** Collect every member before deletion; it only removes labels, never source objects. */
	private static function affected_media( array $input, string $operation ): array {
		if ( self::is_member_operation( $operation ) ) {
			return array( $input['id'] );
		}
		if ( Collections::DELETE !== $operation ) {
			return array();
		}
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Current protected member authorization must see all object types; the attachment-only service omits unsupported labels.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT object_id,object_type FROM {$wpdb->prefix}wpchill_collection_labels WHERE collection_id = %d", $input['id'] ), ARRAY_A );
		if ( null === $rows || $wpdb->last_error ) {
			throw new \RuntimeException( 'Collection members unconfirmed.' );
		}
		$ids = array();
		foreach ( $rows as $row ) {
			if ( 'attachment' !== $row['object_type'] ) {
				throw new \DomainException( 'unsupported_member' );
			}
			$ids[] = (int) $row['object_id'];
		}
		return $ids;
	}

	private static function authorize_media( array $ids ): void {
		if ( $ids ) {
			Revision::lock_attachments( $ids );
		}
		foreach ( $ids as $id ) {
			if ( ! Attachments::can_read( $id ) ) {
				throw new \DomainException( 'inaccessible_member' );
			}
		}
	}

	private static function fields( array $input ): array {
		$fields = array_intersect_key( $input['changes'] ?? $input, array_flip( array( 'name', 'color' ) ) );
		if ( isset( $fields['name'] ) ) {
			$fields['name'] = sanitize_text_field( $fields['name'] );
			if ( '' === trim( $fields['name'] ) ) {
				throw new \DomainException( 'invalid_name' );
			}
		}
		return $fields;
	}

	/** Dispatch distinct validated Collection effects; reject unsupported operations. */
	private static function apply_mutation( array $input, string $operation, array $fields ): array {
		$service       = Collections_Controller::service();
		$id            = (int) ( $input['id'] ?? 0 );
		$collection_id = self::is_member_operation( $operation ) ? $input['collection_id'] : $id;
		if ( Collections::CREATE !== $operation && ! $service->find( $collection_id ) ) {
			throw new \DomainException( 'collection_not_found' );
		}
		switch ( $operation ) {
			case Collections::CREATE:
				$saved = $service->create( $fields );
				break;
			case Collections::UPDATE:
				$saved = $service->update( $id, $fields );
				break;
			case Collections::DELETE:
				$saved = $service->delete( $id );
				break;
			case Collections::ADD_MEMBER:
			case Collections::REMOVE_MEMBER:
				$method = Collections::ADD_MEMBER === $operation ? 'label' : 'unlabel';
				$saved  = $service->$method(
					array(
						'collection_id' => $collection_id,
						'object_id'     => $id,
						'object_type'   => 'attachment',
					)
				);
				break;
			default:
				throw new \DomainException( 'unknown_operation' );
		}
		if ( is_wp_error( $saved ) ) {
			throw new \DomainException( esc_html( $saved->get_error_code() ) );
		}
		return self::confirm_mutation( $operation, $id, $collection_id, $fields, $saved );
	}

	private static function confirm_mutation( string $operation, int $id, int $collection_id, array $fields, $saved ): array {
		$service = Collections_Controller::service();
		if ( self::is_member_operation( $operation ) ) {
			if ( in_array( $id, $service->object_ids( $collection_id ), true ) !== ( Collections::ADD_MEMBER === $operation ) ) {
				throw new \RuntimeException( 'Member save unconfirmed.' );
			}
			return array();
		}
		if ( Collections::DELETE === $operation ) {
			if ( $service->find( $id ) ) {
				throw new \RuntimeException( 'Delete unconfirmed.' );
			}
			return array( 'deleted_id' => $id );
		}
		$row = $service->find( (int) $saved['id'] );
		foreach ( $fields as $key => $value ) {
			if ( ! $row || strtolower( $row[ $key ] ) !== strtolower( $value ) ) {
				throw new \RuntimeException( 'Collection save unconfirmed.' );
			}
		}
		return array( 'collection' => self::summary( $row ) );
	}
}
