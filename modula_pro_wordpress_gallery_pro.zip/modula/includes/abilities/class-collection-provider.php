<?php
/** Pro contribution for paid collection operations. Favorites stay in Lite. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Collection_Explanation;
use Modula\V2\Abilities\Collections;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Collection_Provider {
	public const ID = 'modula-pro-collections';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		foreach ( Collections::premium() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Collection_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck Folders entitlement before any collection effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Collections::explain_blockers( $name, $input );
		if ( ! $blockers ) {
			return null;
		}
		return Collection_Explanation::rejected( $name, $input, $blockers );
	}
}
