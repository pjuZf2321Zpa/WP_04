<?php
/** Pro contribution for storage inspection and mutations. Queued transfers use a separate Pro provider. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;
use Modula\V2\Abilities\Storage;
use Modula\V2\Abilities\Storage_Explanation;

defined( 'ABSPATH' ) || exit;

final class Storage_Provider {
	public const ID = 'modula-pro-storage';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		foreach ( Storage::names() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Storage_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck Compatible Pro, Folders and storage entitlement before any effect. Null means storage may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Storage_Explanation::rejected( $name, $input, $blockers );
	}

	/** Revalidate an owned claim without replaying it; the executor persists the outcome. */
	public static function gate_admission( string $name, array $input ) {
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Storage_Explanation::outcome( $name, $input, $blockers );
	}
}
