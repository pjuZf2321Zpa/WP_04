<?php
/** Explicit extension toggles and premium site-setting writes. Lite keeps free settings and Diagnostics. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Revision;
use Modula\V2\Abilities\Site_Explanation;
use Modula\V2\Abilities\Site_Settings;

defined( 'ABSPATH' ) || exit;

final class Site_Executor {
	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	public static function run( string $name, array $input ) {
		if ( Site_Settings::EXTENSION !== $name ) {
			return Site_Explanation::rejected( $name, $input, Site_Settings::explain_blockers( $input ) );
		}
		$gated = self::gate( $input );
		if ( null !== $gated ) {
			return $gated;
		}
		return self::toggle( $input );
	}

	/**
	 * Already-admitted premium option groups. Returns false before any write when a group is no longer executable.
	 * A lost manage_options capability throws so the caller rolls the claimed request back without a partial write.
	 *
	 * @param array<string,mixed> $settings
	 */
	public static function write_premium( array $settings ): bool {
		if ( ! Site_Settings::can_manage() ) {
			throw new \RuntimeException( 'Access changed.' );
		}
		foreach ( $settings as $name => $patch ) {
			if ( ! is_string( $name ) || ! self::option_allowed( $name, $patch ) ) {
				return false;
			}
		}
		foreach ( $settings as $name => $patch ) {
			self::store( $name, $patch );
		}
		return true;
	}

	/**
	 * Premium option persistence stays in Pro. Lite keeps the same confirmation rule for free fields.
	 *
	 * @param mixed $patch
	 */
	private static function store( string $name, $patch ): void {
		$value = is_array( $patch ) ? array_replace_recursive( (array) get_option( $name, array() ), Site_Settings::sanitize_patch( $patch ) ) : sanitize_text_field( $patch );
		$value = apply_filters( 'modula_settings_api_pre_update_' . $name, $value, $name );
		update_option( $name, $value );
		do_action( 'modula_settings_api_update_' . $name, $value );
		Site_Settings::clear_cache();
		if ( get_option( $name ) !== $value ) {
			throw new \RuntimeException( 'Settings write unconfirmed.' );
		}
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	private static function gate( array $input ) {
		$blockers = Site_Settings::explain_blockers( $input );
		if ( ! $blockers ) {
			return null;
		}
		return Site_Explanation::rejected( Site_Settings::EXTENSION, $input, $blockers );
	}

	/**
	 * @param mixed $patch
	 */
	private static function option_allowed( string $name, $patch ): bool {
		$feature = Site_Settings::premium_map()[ $name ] ?? '';
		if ( '' === $feature ) {
			return false;
		}
		return array() === Site_Settings::option_blockers( $name, $feature, $patch );
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>
	 */
	private static function toggle( array $input ): array {
		$operation = Site_Settings::EXTENSION;
		$existing  = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$out      = static function ( $status, $code = '', $message = '' ) use ( $input, $operation ) {
			return Requests::outcome( $input['request_id'], $status, $code, $message, $operation );
		};
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		$transaction = false;
		try {
			Revision::begin();
			$transaction = true;
			if ( ! hash_equals( Site_Settings::revision( true ), $input['revision'] ) ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $input['request_id'], $out( 'conflict', 'stale_revision', 'Read current settings and reconcile before a new request.' ) );
			}
			$rejected = self::toggle_admission( $input, $out );
			if ( null !== $rejected ) {
				Revision::end( false );
				$transaction = false;
				return Requests::finish( $input['request_id'], $rejected );
			}
			self::apply_toggle( $input );
			$result             = $out( 'succeeded' );
			$result['revision'] = Site_Settings::revision();
			$result             = Requests::finish( $input['request_id'], $result );
			Revision::end( true );
			$transaction = false;
			Site_Settings::clear_cache();
			return $result;
		} catch ( \Throwable $error ) {
			if ( $transaction ) {
				Revision::end( false );
			}
			Site_Settings::clear_cache();
			return Requests::finish( $input['request_id'], $out( 'uncertain', 'settings_unconfirmed', 'Extension hooks could not be confirmed. Recover and inspect before a new action.' ) );
		}
	}

	/**
	 * @param callable $out
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	private static function toggle_admission( array $input, callable $out ) {
		if ( ! Site_Settings::can_activate() || ! Site_Provider::can_toggle() ) {
			throw new \RuntimeException( 'Access changed.' );
		}
		$blockers = Site_Settings::explain_blockers( $input );
		if ( $blockers ) {
			$locked             = $out( 'rejected', 'feature_unavailable', 'This extension toggle is not currently executable.' );
			$locked['blockers'] = $blockers;
			return $locked;
		}
		// Same rule as the REST toggle routes: a known extension, available on this site to turn on.
		$refused = \Modula_Pro\Extensions\Extensions::get_instance()->get_refused_toggle_slugs( array( $input['extension'] ), true === $input['enabled'] );
		if ( array() !== $refused ) {
			return $out( 'rejected', 'extension_unavailable', 'The extension is unknown or lacks stored entitlement.' );
		}
		return null;
	}

	/**
	 * @param array<string,mixed> $input
	 */
	private static function apply_toggle( array $input ): void {
		$extensions = \Modula_Pro\Extensions\Extensions::get_instance();
		$status     = self::extension_status( $input['extension'] );
		if ( is_array( $status ) && $status['enabled'] !== $input['enabled'] ) {
			$action = true === $input['enabled'] ? 'activate' : 'deactivate';
			$extensions->toggle_active_status_of_extensions( array( $input['extension'] ), $action );
		}
		$confirmed = self::extension_status( $input['extension'] );
		if ( ! is_array( $confirmed ) || $confirmed['enabled'] !== $input['enabled'] ) {
			throw new \RuntimeException( 'Extension write unconfirmed.' );
		}
	}

	/**
	 * @param mixed $slug
	 * @return array<string,mixed>|null
	 */
	private static function extension_status( $slug ) {
		if ( ! is_string( $slug ) || '' === $slug ) {
			return null;
		}
		$status = \Modula_Pro\Extensions\Extensions::get_instance()->get_read_only_extension_status()[ $slug ] ?? null;
		return is_array( $status ) ? $status : null;
	}
}
