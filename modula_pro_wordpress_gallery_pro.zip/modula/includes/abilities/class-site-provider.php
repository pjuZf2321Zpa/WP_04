<?php
/** Pro contribution for extension toggles and premium site-setting writes. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;
use Modula\V2\Abilities\Site_Settings;

defined( 'ABSPATH' ) || exit;

final class Site_Provider {
	public const ID = 'modula-pro-site-administration';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
		add_filter( 'modula_ability_premium_site_settings_writer', array( self::class, 'writer' ) );
	}

	/** The extension service supports cache-safe toggles. Checked without refreshing licensing. */
	public static function can_toggle(): bool {
		return Pro_Dependency::available() && Pro_Dependency::methods(
			'\Modula_Pro\Extensions\Extensions',
			array(
				'clear_active_extensions_cache'      => 0,
				'toggle_active_status_of_extensions' => 2,
			),
			false
		);
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		if ( ! self::can_toggle() || ! Pro_Dependency::host_executor_ready( Site_Settings::EXTENSION ) ) {
			return $contributions;
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => array(
				Site_Settings::EXTENSION => array(
					'execute' => static function ( $input ) {
						return Site_Executor::run( Site_Settings::EXTENSION, is_array( $input ) ? $input : array() );
					},
				),
			),
		);
		return $contributions;
	}

	/**
	 * Supply the premium writer only when its signature is present. A missing method stays explanatory.
	 *
	 * @param mixed $writer
	 * @return mixed
	 */
	public static function writer( $writer ) {
		if ( ! Site_Settings::writer_ready() ) {
			return $writer;
		}
		return array( Site_Executor::class, 'write_premium' );
	}
}
