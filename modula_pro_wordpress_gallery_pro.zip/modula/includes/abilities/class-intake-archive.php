<?php
/** Pro-owned archive selection and validation; image staging is shared with free upload. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Intake_Files;

defined( 'ABSPATH' ) || exit;

final class Intake_Archive {
	private const MAX_ENTRIES = 100;

	public static function prepare( array $input, Intake_Files $staging ): array {
		list( $bytes, $name ) = $staging->decode( $input );
		if ( 'zip' !== strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) || ! class_exists( '\ZipArchive' ) ) {
			throw new \InvalidArgumentException( 'zip_unavailable' );
		}
		$path = $staging->stage( $bytes, $name );
		unset( $bytes );
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $path, \ZipArchive::CHECKCONS ) ) {
			throw new \InvalidArgumentException( 'invalid_archive' );
		}
		try {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive exposes the native numFiles property.
			$count = $zip->numFiles;
			if ( $count < 1 || $count > self::MAX_ENTRIES ) {
				throw new \InvalidArgumentException( 'archive_entries_limit' );
			}
			$total   = 0;
			$entries = array();
			$seen    = array();
			for ( $i = 0; $i < $count; ++$i ) {
				$stat = $zip->statIndex( $i );
				if ( ! $stat ) {
					throw new \InvalidArgumentException( 'invalid_archive' );
				}
				$entry = str_replace( '\\', '/', $stat['name'] );
				if ( preg_match( '~(^/|^[a-zA-Z]:|(^|/)\.\.(/|$)|\x00)~', $entry ) ) {
					throw new \InvalidArgumentException( 'unsafe_archive_path' );
				}
				$opsys      = 0;
				$attributes = 0;
				if ( $zip->getExternalAttributesIndex( $i, $opsys, $attributes ) && 0120000 === ( ( $attributes >> 16 ) & 0170000 ) ) {
					throw new \InvalidArgumentException( 'archive_symlink' );
				}
				if ( ! empty( $stat['encryption_method'] ) ) {
					throw new \InvalidArgumentException( 'encrypted_archive' );
				}
				if ( '/' === substr( $entry, -1 ) || 0 === strpos( $entry, '__MACOSX/' ) || 0 === strpos( basename( $entry ), '._' ) ) {
					continue;
				}
				$total += $stat['size'];
				if ( $stat['size'] > Intake_Files::MAX_BYTES || $total > Intake_Executor::MAX_EXPANDED || $stat['size'] > max( 1, $stat['comp_size'] ) * 100 ) {
					throw new \InvalidArgumentException( 'archive_size_limit' );
				}
				$filename = sanitize_file_name( basename( $entry ) );
				if ( '' === $filename || isset( $seen[ $filename ] ) || empty( wp_check_filetype( $filename, $staging->allowed() )['type'] ) ) {
					throw new \InvalidArgumentException( 'invalid_archive_entry' );
				}
				$seen[ $filename ] = true;
				$entries[]         = array( $i, $filename, $stat['size'] );
			}
			if ( ! $entries ) {
				throw new \InvalidArgumentException( 'empty_archive' );
			}
			$files = array();
			foreach ( $entries as $entry ) {
				$bytes = $zip->getFromIndex( $entry[0], Intake_Files::MAX_BYTES + 1 );
				if ( false === $bytes || strlen( $bytes ) !== $entry[2] ) {
					throw new \InvalidArgumentException( 'archive_read_failed' );
				}
				$files[] = $staging->image( $bytes, $entry[1] );
			}
			if ( is_multisite() && ( ! is_upload_space_available() || $total > get_upload_space_available() ) ) {
				throw new \InvalidArgumentException( 'upload_quota_exceeded' );
			}
			return $files;
		} finally {
			$zip->close();
		}
	}
}
