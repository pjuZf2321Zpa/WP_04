<?php
/** Pro contribution for queued folder and library transfers. The portable queue stays in Folders. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;
use Modula\V2\Abilities\Transfer_Explanation;
use Modula\V2\Abilities\Transfers;

defined( 'ABSPATH' ) || exit;

final class Transfer_Provider {
	public const ID = 'modula-pro-transfers';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		foreach ( Transfers::names() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Transfer_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck Compatible Pro, Folders and storage entitlement before any queue effect. Null means the transfer may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Transfer_Explanation::rejected( $name, $input, $blockers );
	}

	/** Revalidate an owned claim without replaying it; the executor persists the outcome. */
	public static function gate_admission( string $name, array $input ) {
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Transfer_Explanation::outcome( $name, $input, $blockers );
	}
}
