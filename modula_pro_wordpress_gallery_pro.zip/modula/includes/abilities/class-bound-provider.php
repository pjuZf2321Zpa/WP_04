<?php
/** Pro contribution for bound-gallery creation, reads and exclusions. Derive/merge stays in Lite. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Bound;
use Modula\V2\Abilities\Bound_Explanation;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Bound_Provider {
	public const ID = 'modula-pro-bound';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		foreach ( Bound::names() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Bound_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck Compatible Pro and the host bound-gallery entitlement before any effect. Null means the operation may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Bound::explain_blockers( $name, $input );
		if ( ! $blockers ) {
			return null;
		}
		return Bound_Explanation::rejected( $name, $input, $blockers );
	}
}
