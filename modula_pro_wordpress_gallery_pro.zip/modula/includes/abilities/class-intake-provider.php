<?php
/** Pro contribution for ZIP and server-folder intake. Ordinary image upload stays in Lite. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Intake;
use Modula\V2\Abilities\Intake_Explanation;
use Modula\V2\Abilities\Pro_Dependency;
use Modula\V2\Abilities\Providers;

defined( 'ABSPATH' ) || exit;

final class Intake_Provider {
	public const ID = 'modula-pro-intake';

	public static function boot(): void {
		add_filter( 'modula_ability_provider_contributions', array( self::class, 'contribute' ), 10 );
	}

	/**
	 * @param array<int,array<string,mixed>> $contributions
	 * @return array<int,array<string,mixed>>
	 */
	public static function contribute( array $contributions ): array {
		foreach ( Intake::premium() as $name ) {
			if ( ! Pro_Dependency::host_executor_ready( $name ) ) {
				return $contributions;
			}
		}
		$operations = array();
		foreach ( Intake_Executor::callbacks() as $name => $execute ) {
			$operations[ $name ] = array( 'execute' => $execute );
		}
		$contributions[] = array(
			'provider'   => self::ID,
			'protocol'   => Providers::PROTOCOL,
			'operations' => $operations,
		);
		return $contributions;
	}

	/**
	 * Recheck Compatible Pro before any file effect. Null means intake may continue.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|null
	 */
	public static function gate( string $name, array $input ) {
		$blockers = Availability::blockers( $name );
		if ( ! $blockers ) {
			return null;
		}
		return Intake_Explanation::rejected( $name, $input, $blockers );
	}
}
