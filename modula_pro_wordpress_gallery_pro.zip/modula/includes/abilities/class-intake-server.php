<?php
/** Pro-owned authorized server browsing, selection and source revalidation. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Intake_Explanation;
use Modula\V2\Abilities\Intake_Files;
use Modula\V2\Abilities\Server_Import;

defined( 'ABSPATH' ) || exit;

final class Intake_Server {
	/**
	 * Copy bounded server bytes into owned staging; never move the original source.
	 *
	 * @return array<string,mixed> Upload-shaped staged file.
	 */
	private static function stage_source( Intake_Files $staging, string $path, string $name ): array {
		// Staging uses wp_tempnam() and media helpers outside wp-admin requests.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Bounded local source, never a remote URL.
		$bytes = file_get_contents( $path, false, null, 0, Intake_Files::MAX_BYTES + 1 );
		if ( false === $bytes ) {
			throw new \InvalidArgumentException( 'source_unreadable' );
		}
		return $staging->image( $bytes, $name );
	}

	private static function resolve( string $root, string $relative ): string {
		if ( preg_match( '~[\\\\\x00-\x1f:]|(^/)|(^|/)\.\.?(/|$)|//~', $relative ) ) {
			throw new \InvalidArgumentException( 'invalid_source_path' );
		}
		$path = $root;
		foreach ( array_filter( explode( '/', $relative ), 'strlen' ) as $part ) {
			$path .= '/' . $part;
			if ( is_link( $path ) ) {
				throw new \InvalidArgumentException( 'source_symlink' );
			}
		}
		$real = realpath( $path );
		if ( ! $real || ! is_readable( $real ) || ! \Modula_Folder_Import_Path::is_path_under_root( $real, $root ) ) {
			throw new \InvalidArgumentException( 'invalid_source_path' );
		}
		return $real;
	}
	private static function authorize( string $path, bool $delete ): int {
		$owner = Server_Import::uploader()->resolve_folder_import_attachment( $path );
		if ( is_wp_error( \Modula_Folder_Import_Path::authorize_import( $owner, $delete, 'current_user_can' ) ) ) {
			throw new \InvalidArgumentException( 'source_permission_denied' );
		}
		// Removing a registered original or derivative leaves a broken Media Library object.
		// Its guarded attachment lifecycle, not folder intake, owns those shared bytes.
		if ( $delete && $owner ) {
			throw new \InvalidArgumentException( 'registered_source_preserved' );
		}
		return (int) $owner;
	}
	public static function browse( array $input ) {
		if ( ! Server_Import::can_import() ) {
			return new \WP_Error( 'modula_forbidden', 'Current Folder import permissions are required.' );
		}
		$blockers = Availability::blockers( Server_Import::BROWSE );
		if ( $blockers ) {
			return Intake_Explanation::rejected( Server_Import::BROWSE, $input, $blockers );
		}
		try {
			$root     = Server_Import::root();
			$identity = Server_Import::identity( $root );
			if ( isset( $input['root'] ) && ! hash_equals( $identity, $input['root'] ) ) {
				throw new \InvalidArgumentException( 'root_changed' );
			}
			$relative = $input['path'] ?? '';
			$path     = self::resolve( $root, $relative );
			if ( ! is_dir( $path ) ) {
				throw new \InvalidArgumentException( 'invalid_source_path' );
			}
			$entries = self::visible_entries( $root, $relative, $path );
			usort(
				$entries,
				static function ( $a, $b ) {
					return strcmp( $a['path'], $b['path'] );
				}
			);
			$page = $input['page'] ?? 1;
			$size = $input['per_page'] ?? 20;
			return array(
				'schema_version' => Contract::VERSION,
				'root'           => $identity,
				'path'           => $relative,
				'page'           => $page,
				'total'          => count( $entries ),
				'entries'        => array_slice( $entries, ( $page - 1 ) * $size, $size ),
			);
		} catch ( \InvalidArgumentException $error ) {
			return new \WP_Error( $error->getMessage(), 'Folder selection is unavailable or not authorized.' );
		} catch ( \Throwable $error ) {
			return new \WP_Error( 'browse_unavailable', 'Folder inspection could not be completed.' );
		}
	}

	/** Bound the directory walk and expose only authorized direct children. */
	private static function visible_entries( string $root, string $relative, string $path ): array {
		$entries = array();
		$count   = 0;
		$allowed = Server_Import::uploader()->define_allowed_mime_types();
		foreach ( new \DirectoryIterator( $path ) as $entry ) {
			if ( ++$count > 10002 ) {
				throw new \InvalidArgumentException( 'directory_limit' );
			}
			if ( $entry->isDot() || $entry->isLink() ) {
				continue;
			}
			$name    = ( '' === $relative ? '' : rtrim( $relative, '/' ) . '/' ) . $entry->getFilename();
			$visible = self::visible_entry( $root, $name, $allowed );
			if ( null !== $visible ) {
				$entries[] = $visible;
			}
		}
		return $entries;
	}

	/** A rejected child is omitted; a directory-level failure remains an explicit error. */
	private static function visible_entry( string $root, string $relative, array $allowed ): ?array {
		try {
			$resolved = self::resolve( $root, $relative );
			if ( is_dir( $resolved ) ) {
				return array(
					'path' => $relative,
					'kind' => 'directory',
					'size' => 0,
				);
			}
			if ( ! is_file( $resolved ) || empty( wp_check_filetype( wp_basename( $relative ), $allowed )['type'] ) ) {
				return null;
			}
			self::authorize( $resolved, false );
			$size = filesize( $resolved );
			if ( false === $size ) {
				throw new \InvalidArgumentException( 'source_unreadable' );
			}
			return array(
				'path' => $relative,
				'kind' => 'file',
				'size' => $size,
			);
		} catch ( \InvalidArgumentException $error ) {
			return null;
		}
	}

	public static function prepare( array $input, Intake_Files $staging ): array {
		$root = Server_Import::root();
		if ( ! hash_equals( Server_Import::identity( $root ), $input['root'] ) ) {
			throw new \InvalidArgumentException( 'root_changed' );
		}
		$files = array();
		$total = 0;
		foreach ( $input['paths'] as $relative ) {
			$path = self::resolve( $root, $relative );
			if ( ! is_file( $path ) ) {
				throw new \InvalidArgumentException( 'invalid_source_file' );
			}
			$owner = self::authorize( $path, $input['delete_after_import'] );
			$size  = filesize( $path );
			if ( false === $size ) {
				throw new \InvalidArgumentException( 'source_unreadable' );
			}
			$total += $size;
			if ( $total > Intake_Executor::MAX_EXPANDED ) {
				throw new \InvalidArgumentException( 'file_size_limit' );
			}
			$file           = self::stage_source( $staging, $path, sanitize_file_name( basename( $path ) ) );
			$file['source'] = array(
				'path'   => $relative,
				'owner'  => $owner,
				'root'   => $input['root'],
				'digest' => hash_file( 'sha256', $file['tmp_name'] ),
				'stat'   => self::stat( $path ),
			);
			$files[]        = $file;
		}
		if ( is_multisite() && ( ! is_upload_space_available() || $total > get_upload_space_available() ) ) {
			throw new \InvalidArgumentException( 'upload_quota_exceeded' );
		}
		return $files;
	}
	private static function stat( string $path ): array {
		clearstatcache( true, $path );
		$stat = stat( $path );
		if ( false === $stat ) {
			throw new \InvalidArgumentException( 'source_unreadable' );
		}
		return array( $stat['dev'], $stat['ino'], $stat['size'], $stat['mtime'], $stat['ctime'] );
	}
	/** Recheck root, path, identity, bytes and current source permissions before each effect. */
	public static function revalidate( array $source, bool $delete ): string {
		if ( ! Server_Import::can_import() ) {
			throw new \InvalidArgumentException( 'source_permission_denied' );
		}
		$root = Server_Import::root();
		if ( ! hash_equals( Server_Import::identity( $root ), $source['root'] ) ) {
			throw new \InvalidArgumentException( 'root_changed' );
		}
		$path = self::resolve( $root, $source['path'] );
		if ( ! is_file( $path ) || self::stat( $path ) !== $source['stat'] || ! hash_equals( $source['digest'], hash_file( 'sha256', $path ) ) || self::authorize( $path, $delete ) !== $source['owner'] ) {
			throw new \InvalidArgumentException( 'source_changed' );
		}
		return $path;
	}
}
