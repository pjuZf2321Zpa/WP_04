<?php
/** Premium Freeform ability authoring. Shared gallery persistence owns the final write. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Creation;
use Modula\V2\Freeform_Catalog;
use Modula\V2\Meta_Sync;

defined( 'ABSPATH' ) || exit;

final class Freeform_Author {
	public static function boot(): void {
		add_filter( 'modula_ability_setting_authors', array( self::class, 'authors' ) );
	}

	/** This Pro ships the author, so it always registers; a missing author keeps the common explanatory contract. */
	public static function authors( array $authors ): array {
		return $authors + array( 'freeform.placements' => array( self::class, 'prepare' ) );
	}

	/**
	 * Author complete replacement or deterministic reset without changing membership.
	 * Called inside the shared revision transaction after current feature admission.
	 *
	 * @return array|\WP_Error Canonical placements or current attachment denial.
	 */
	public static function prepare( int $id, array $placements ) {
		$rows        = array_values( array_filter( Meta_Sync::get_images_v2( $id ), 'is_array' ) );
		$attachments = array_filter( array_column( $rows, 'id' ), 'is_numeric' );
		if ( ! Creation::can_use_attachments( array_map( 'intval', $attachments ) ) ) {
			return new \WP_Error( 'invalid_attachments', 'Freeform authoring requires current access to the gallery images.' );
		}
		$rows = Freeform_Catalog::identify( $rows );
		return Freeform_Catalog::reconcile( $rows, $placements );
	}
}
