<?php
/** Pro-owned premium intake admission, import progress and source effects. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Availability;
use Modula\V2\Abilities\Intake;
use Modula\V2\Abilities\Intake_Attachment;
use Modula\V2\Abilities\Intake_Explanation;
use Modula\V2\Abilities\Intake_Files;
use Modula\V2\Abilities\Intake_Target;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Server_Import;
use Modula\V2\Abilities\Update;

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-intake-archive.php';
require_once __DIR__ . '/class-intake-server.php';

final class Intake_Executor {
	/** Combined image bytes one archive or server-folder import may stage. */
	public const MAX_EXPANDED = 33554432;

	public static function operations(): array {
		return array(
			Intake::ZIP           => array( self::class, 'zip' ),
			Server_Import::BROWSE => array( self::class, 'browse' ),
			Server_Import::IMPORT => array( self::class, 'import' ),
		);
	}

	public static function callbacks(): array {
		return self::operations();
	}

	public static function zip( array $input ): array {
		return self::execute( $input, Intake::ZIP );
	}

	/** @return array|\WP_Error */
	public static function browse( array $input ) {
		return Intake_Server::browse( $input );
	}

	public static function import( array $input ): array {
		return self::execute( $input, Server_Import::IMPORT );
	}

	private static function authorized( array $input, string $operation ): bool {
		return Intake::can_upload()
			&& ( Server_Import::IMPORT !== $operation || Server_Import::can_import() )
			&& ( ! isset( $input['id'] ) || Update::can_update( $input['id'] ) );
	}

	/** Admission stays outside the effect loop; staged files are always owned and cleaned. */
	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( ! self::authorized( $input, $operation ) ) {
			return Requests::outcome( $input['request_id'], 'forbidden', 'current_permission_denied', 'Current upload and requested gallery permissions are required.', $operation );
		}
		$blockers = Availability::blockers( $operation );
		if ( $blockers ) {
			return Intake_Explanation::rejected( $operation, $input, $blockers );
		}
		$invalid = Intake_Target::validate( $input, $operation );
		if ( null !== $invalid ) {
			return $invalid;
		}
		$staging = new Intake_Files();
		try {
			$files = Server_Import::IMPORT === $operation ? Intake_Server::prepare( $input, $staging ) : Intake_Archive::prepare( $input, $staging );
		} catch ( \InvalidArgumentException $error ) {
			$staging->cleanup();
			return Requests::outcome( $input['request_id'], 'rejected', $error->getMessage(), 'Invalid media or archive. No attachments were imported.', $operation );
		} catch ( \Throwable $error ) {
			$staging->cleanup();
			return Requests::outcome( $input['request_id'], 'rejected', 'staging_failed', 'Media could not be staged. No attachments were imported.', $operation );
		}
		try {
			$context  = self::source_context( $input, $files, $operation );
			$existing = Requests::claim( $input, $operation, $context );
			if ( null !== $existing ) {
				return $existing;
			}
			return self::import_files( $input, $files, $operation );
		} finally {
			$staging->cleanup();
		}
	}

	/** Preserve current source ownership at atomic admission, before any file effect. */
	private static function source_context( array $input, array $files, string $operation ): array {
		if ( Server_Import::IMPORT !== $operation ) {
			return array();
		}
		return array(
			'source_root'    => $input['root'],
			'source_owners'  => array_values( array_unique( array_filter( array_column( array_column( $files, 'source' ), 'owner' ) ) ) ),
			'delete_sources' => $input['delete_after_import'],
		);
	}

	private static function progress( array $files ): array {
		$objects = array();
		foreach ( $files as $file ) {
			$row = array(
				'filename'      => $file['name'],
				'attachment_id' => 0,
				'status'        => 'not_started',
				'code'          => '',
			);
			if ( isset( $file['source'] ) ) {
				$row['source']        = $file['source']['path'];
				$row['source_status'] = 'retained';
			}
			$objects[] = $row;
		}
		return array(
			'phase'          => 'import',
			'attachment_ids' => array(),
			'objects'        => $objects,
		);
	}

	/** Multi-file sequencing and source removal are exclusively premium orchestration. */
	private static function import_files( array $input, array $files, string $operation ): array {
		$progress = self::progress( $files );
		try {
			Requests::context( $input['request_id'], array( 'intake' => $progress ) );
			foreach ( $files as $index => $file ) {
				$blockers = Availability::blockers( $operation );
				if ( ! self::authorized( $input, $operation ) || $blockers ) {
					throw new \RuntimeException( 'Admission changed before import.' );
				}
				self::import_file( $input, $file, $progress, $index, $operation );
				Requests::context( $input['request_id'], array( 'intake' => $progress ) );
			}
			return self::complete( $input, $progress, $operation );
		} catch ( \Throwable $error ) {
			$outcome           = Requests::outcome( $input['request_id'], 'uncertain', 'intake_unconfirmed', 'Import or composition was interrupted. Inspect retained attachments and phase before a new action.', $operation );
			$outcome['intake'] = $progress;
			return Requests::finish( $input['request_id'], $outcome );
		}
	}

	private static function import_file( array $input, array $file, array &$progress, int $index, string $operation ): void {
		if ( isset( $file['source'] ) ) {
			try {
				Intake_Server::revalidate( $file['source'], $input['delete_after_import'] );
			} catch ( \InvalidArgumentException $error ) {
				$progress['objects'][ $index ]['status'] = 'rejected';
				$progress['objects'][ $index ]['code']   = $error->getMessage();
				return;
			}
		}
		$progress['objects'][ $index ]['status'] = 'in_progress';
		Requests::context( $input['request_id'], array( 'intake' => $progress ) );
		$id = Intake_Attachment::import( $file, $input['request_id'], $progress, $index );
		if ( is_wp_error( $id ) ) {
			$progress['objects'][ $index ]['status'] = 'rejected';
			$progress['objects'][ $index ]['code']   = 'wordpress_import_failed';
			return;
		}
		if ( ! in_array( (int) $id, $progress['attachment_ids'], true ) ) {
			throw new \RuntimeException( 'Identity not recorded.' );
		}
		$progress['objects'][ $index ]['status'] = 'succeeded';
		if ( isset( $file['source'] ) && $input['delete_after_import'] ) {
			self::remove_source( $input, $file['source'], $progress, $index, $operation );
		}
	}

	/** Persist uncertainty before removal; neither replay nor recovery retries it. */
	private static function remove_source( array $input, array $source, array &$progress, int $index, string $operation ): void {
		$progress['objects'][ $index ]['source_status'] = 'uncertain';
		Requests::context( $input['request_id'], array( 'intake' => $progress ) );
		try {
			if ( ! self::authorized( $input, $operation ) || Availability::blockers( $operation ) ) {
				throw new \InvalidArgumentException( 'Admission changed before source removal.' );
			}
			$path = Intake_Server::revalidate( $source, true );
			wp_delete_file( $path );
			clearstatcache( true, $path );
			$progress['objects'][ $index ]['source_status'] = ( file_exists( $path ) || is_link( $path ) ) ? 'delete_failed' : 'deleted';
		} catch ( \InvalidArgumentException $error ) {
			$progress['objects'][ $index ]['source_status'] = 'delete_failed';
		}
		if ( 'deleted' !== $progress['objects'][ $index ]['source_status'] ) {
			$progress['objects'][ $index ]['status'] = 'partial';
			$progress['objects'][ $index ]['code']   = 'source_removal_unconfirmed';
		}
	}

	private static function complete( array $input, array &$progress, string $operation ): array {
		$failed = count(
			array_filter(
				$progress['objects'],
				static function ( $row ) {
					return 'succeeded' !== $row['status'];
				}
			)
		);
		$status = 'succeeded';
		$code   = '';
		if ( $failed ) {
			$status = $progress['attachment_ids'] ? 'partial' : 'rejected';
			$code   = 'import_incomplete';
		}
		$composed = Intake_Target::compose( $input, $progress );
		if ( null !== $composed && 'succeeded' !== $composed['status'] ) {
			$status = 'partial';
			$code   = 'composition_' . $composed['code'];
		}
		if ( 'succeeded' === $status ) {
			$progress['phase'] = 'completed';
		}
		Requests::context( $input['request_id'], array( 'intake' => $progress ) );
		$outcome           = Requests::outcome( $input['request_id'], $status, $code, 'succeeded' === $status ? '' : 'Inspect retained attachments and failed phase; recover this identity before a new action.', $operation );
		$outcome['intake'] = $progress;
		return Requests::finish( $input['request_id'], $outcome );
	}
}
