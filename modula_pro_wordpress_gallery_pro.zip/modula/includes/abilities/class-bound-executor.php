<?php
/** Bound-gallery source reads, creation and exclusions. Lite keeps schemas, derive/merge and retained-result inspection. */
namespace Modula_Pro\Abilities;

use Modula\V2\Abilities\Bound;
use Modula\V2\Abilities\Bound_Explanation;
use Modula\V2\Abilities\Contract;
use Modula\V2\Abilities\Creation;
use Modula\V2\Abilities\Integration;
use Modula\V2\Abilities\Media_Folders;
use Modula\V2\Abilities\Requests;
use Modula\V2\Abilities\Storage;
use Modula\V2\Abilities\Revision;
use Modula\V2\Meta_Sync;
use Modula\Bound_Gallery\Bound_Gallery;
use WPChill\Folders\Mutation_Lock;
use WPChill\Folders\Rest\Source_Groups_Controller;

defined( 'ABSPATH' ) || exit;

final class Bound_Executor {
	/** Current media administration, Folders services and host entitlement, rechecked before each effect. */
	public static function available(): bool {
		return Media_Folders::can_manage() && Bound::services_ready() && Bound::entitled();
	}

	/**
	 * @param array<string,mixed> $input
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function run( string $name, array $input ) {
		$method = self::operations()[ $name ] ?? '';
		if ( '' === $method ) {
			return new \WP_Error( 'modula_unknown_operation', 'Unknown bound-gallery operation.' );
		}
		$gated = Bound_Provider::gate( $name, $input );
		if ( null !== $gated ) {
			return $gated;
		}
		return call_user_func( array( self::class, $method ), $input );
	}

	/** @return array<string,callable> */
	public static function callbacks(): array {
		$out = array();
		foreach ( Bound::names() as $name ) {
			$out[ $name ] = static function ( $input ) use ( $name ) {
				return self::run( $name, is_array( $input ) ? $input : array() );
			};
		}
		return $out;
	}

	/** @return array<string,string> */
	public static function operations(): array {
		return array(
			Bound::SOURCE  => 'source',
			Bound::READ    => 'read',
			Bound::CREATE  => 'create',
			Bound::EXCLUDE => 'exclude',
		);
	}

	/** Live execution requires the host gate; shared membership inspection also serves historical authorization. */
	private static function inspect( array $target, bool $lock = false ): array {
		if ( ! self::available() || ( 'remote_prefix' === $target['type'] && ! Storage::available() ) ) {
			throw new \DomainException( 'current_permission_denied' );
		}
		return Bound::source_membership( $target, $lock );
	}

	private static function source( array $input ) {
		$blocked = Bound_Provider::gate( Bound::SOURCE, $input );
		if ( null !== $blocked ) {
			return $blocked;
		}
		try {
			$source = self::inspect( $input['target'] );
			return array(
				'schema_version'  => Contract::VERSION,
				'revision'        => $source['revision'],
				'attachment_ids'  => $source['ids'],
				'unknown_objects' => count( $source['unknown'] ),
			);
		} catch ( \Throwable $error ) {
			return new \WP_Error( 'modula_source_unavailable', 'Source is unavailable, inaccessible, changed or exceeds the bounded catalog.' );
		}
	}
	private static function read( array $input ) {
		$blocked = Bound_Provider::gate( Bound::READ, $input );
		if ( null !== $blocked ) {
			return $blocked;
		}
		try {
			$id       = $input['id'];
			$target   = Bound::target( $id );
			$source   = self::inspect( $target );
			$revision = self::revision( $id, $source );
			$items    = Bound_Gallery::apply_derived_catalog( $id, Meta_Sync::get_images_v2( $id ) );
			foreach ( $items as &$item ) {
				$item['itemKind'] = \Modula\V2\Images\Adapter::get_item_kind( $item );
				$item             = Contract::project( $item, Contract::item_schema() );
			}
			unset( $item );
			if ( ! hash_equals( $revision, self::revision( $id, self::inspect( $target ) ) ) ) {
				throw new \DomainException( 'source_changed' );
			}
			return array(
				'schema_version' => Contract::VERSION,
				'revision'       => $revision,
				'gallery'        => Contract::project( Integration::gallery( get_post( $id ) ), Contract::gallery_schema() ),
				'target'         => $target,
				'exclusions'     => Bound_Gallery::get_exclusions( $id ),
				'items'          => $items,
			);
		} catch ( \Throwable $error ) {
			return new \WP_Error( 'modula_bound_unavailable', 'Current bound gallery and source access required; retry inspection if the source changed.' );
		}
	}
	private static function revision( int $id, array $source, bool $lock = false ): string {
		return hash( 'sha256', Revision::state( $id, $lock ) . $source['revision'] );
	}
	private static function create( array $input ): array {
		return self::execute( $input, Bound::CREATE );
	}

	private static function exclude( array $input ): array {
		return self::execute( $input, Bound::EXCLUDE );
	}

	private static function execute( array $input, string $operation ): array {
		$existing = Requests::existing( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		if ( Bound::CREATE === $operation && '' === trim( sanitize_text_field( $input['title'] ) ) ) {
			return Requests::outcome( $input['request_id'], 'rejected', 'invalid_title', '', $operation );
		}
		$existing = Requests::claim( $input, $operation );
		if ( null !== $existing ) {
			return $existing;
		}
		try {
			// Retain source authorization outside the effect transaction, including stale/refused outcomes.
			$target = Bound::CREATE === $operation ? $input['target'] : Bound::target( $input['id'] );
			Requests::context( $input['request_id'], array( 'bind_target' => $target ) );
			$result = Mutation_Lock::run(
				'storage',
				static function () use ( $input, $operation ) {
					return self::transact( $input, $operation );
				}
			);
			if ( is_wp_error( $result ) ) {
				return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'rejected', 'operation_busy', '', $operation ) );
			}
			return $result;
		} catch ( \Throwable $error ) {
			return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], 'uncertain', 'bound_effect_unconfirmed', '', $operation ) );
		}
	}

	/** One protected transaction; ingestion may be external, so unconfirmed effects stay uncertain. */
	private static function transact( array $input, string $operation ): array {
		$active = false;
		$id     = (int) ( $input['id'] ?? 0 );
		try {
			Revision::begin();
			$active   = true;
			$blockers = Bound::explain_blockers( $operation, $input );
			if ( $blockers ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], Bound_Explanation::outcome( $operation, $input, $blockers ) );
			}
			$target   = Bound::CREATE === $operation ? $input['target'] : Bound::target( $id );
			$source   = self::inspect( $target, true );
			$revision = Bound::CREATE === $operation ? $source['revision'] : self::revision( $id, $source, true );
			if ( ! hash_equals( $input['revision'], $revision ) ) {
				throw new \DomainException( 'stale_revision' );
			}
			$blockers = Bound::explain_blockers( $operation, $input );
			if ( $blockers ) {
				Revision::end( false );
				$active = false;
				return Requests::finish( $input['request_id'], Bound_Explanation::outcome( $operation, $input, $blockers ) );
			}
			Requests::context( $input['request_id'], array( 'bind_target' => $target ) );
			if ( Bound::CREATE === $operation ) {
				$id = self::create_gallery( $input, $target, $source );
			} else {
				self::save_exclusions( $input, $source );
			}
			$after_source = self::inspect( $target, true );
			if ( Bound::EXCLUDE === $operation && ! hash_equals( $source['revision'], $after_source['revision'] ) ) {
				throw new \DomainException( 'stale_revision' );
			}
			$response = Requests::finish(
				$input['request_id'],
				Requests::outcome( $input['request_id'], 'succeeded', '', '', $operation ) + array(
					'gallery'  => Integration::gallery( get_post( $id ) ),
					'revision' => self::revision( $id, $after_source, true ),
				)
			);
			Revision::end( true );
			$active = false;
			return $response;
		} catch ( \Throwable $error ) {
			if ( $active ) {
				Revision::end( false );
			}
			self::clear_rolled_back_caches( $id );
			$code   = $error instanceof \DomainException ? $error->getMessage() : 'bound_effect_unconfirmed';
			$status = $error instanceof \DomainException ? 'rejected' : 'uncertain';
			if ( 'stale_revision' === $code ) {
				$status = 'conflict';
			}
			return Requests::finish( $input['request_id'], Requests::outcome( $input['request_id'], $status, $code, '', $operation ) );
		}
	}

	/** Create a draft first; publish only after permissions and catalog persistence are confirmed. */
	private static function create_gallery( array $input, array $target, array $source ): int {
		foreach ( $source['unknown'] as $key ) {
			$ingest = Source_Groups_Controller::ingest_service()->ingest( $target['connection_id'], $key );
			if ( is_wp_error( $ingest ) ) {
				throw new \RuntimeException( 'Ingest unconfirmed.' );
			}
			$source['ids'][] = (int) $ingest['attachment_id'];
		}
		if ( ! Creation::can_use_attachments( $source['ids'] ) ) {
			throw new \DomainException( 'source_media_unavailable' );
		}
		$target_id = 'media_folder' === $target['type'] ? (string) $target['folder_id'] : Bound_Gallery::remote_prefix_target_id( $target['connection_id'], $target['prefix'] );
		$id        = wp_insert_post(
			wp_slash(
				array(
					'post_type'   => 'modula-gallery',
					'post_status' => 'draft',
					'post_title'  => sanitize_text_field( $input['title'] ),
					'post_author' => get_current_user_id(),
					'meta_input'  => array(
						'_modula_beta'                  => 1,
						Bound_Gallery::META_TARGET_TYPE => $target['type'],
						Bound_Gallery::META_TARGET_ID   => $target_id,
					),
				)
			),
			true
		);
		if ( is_wp_error( $id ) || ! $id ) {
			throw new \RuntimeException( 'Target unconfirmed.' );
		}
		// The inserted post can enter WordPress caches before a later creation step fails.
		Revision::track( array( $id ) );
		if ( ! Requests::target( $input['request_id'], $id ) ) {
			throw new \RuntimeException( 'Target unconfirmed.' );
		}
		Meta_Sync::apply_new_beta_gallery_create_defaults( $id );
		$rows = Bound_Gallery::apply_derived_catalog( $id, array() );
		if ( is_wp_error( Meta_Sync::persist_merged_gallery_items( $id, $rows, false ) ) ) {
			throw new \RuntimeException( 'Catalog unconfirmed.' );
		}
		if ( ! self::available() || ! Creation::can_create( $input['status'] ) || ! Creation::can_use_attachments( $source['ids'] ) ) {
			throw new \DomainException( 'current_permission_denied' );
		}
		if ( 'publish' === $input['status'] ) {
			$published = wp_update_post(
				array(
					'ID'          => $id,
					'post_status' => 'publish',
				),
				true
			);
			if ( is_wp_error( $published ) || ! $published ) {
				throw new \RuntimeException( 'Publication unconfirmed.' );
			}
		}
		if ( get_post_status( $id ) !== $input['status'] ) {
			throw new \RuntimeException( 'Publication unconfirmed.' );
		}
		return $id;
	}

	/** Hide/restore only gallery exclusions; source memberships and bytes are never removed. */
	private static function save_exclusions( array $input, array $source ): void {
		$id      = $input['id'];
		$members = array_unique( array_merge( $source['ids'], Bound_Gallery::get_exclusions( $id ) ) );
		if ( array_diff( $input['attachment_ids'], $members ) || ! Creation::can_use_attachments( $input['attachment_ids'] ) ) {
			throw new \DomainException( 'invalid_source_members' );
		}
		foreach ( $input['attachment_ids'] as $attachment_id ) {
			if ( 'hide' === $input['action'] ) {
				Bound_Gallery::exclude_attachment( $id, $attachment_id );
			} else {
				Bound_Gallery::restore_attachment( $id, $attachment_id );
			}
		}
		$excluded    = Bound_Gallery::get_exclusions( $id );
		$unconfirmed = 'hide' === $input['action'] ? array_diff( $input['attachment_ids'], $excluded ) : array_intersect( $input['attachment_ids'], $excluded );
		if ( $unconfirmed ) {
			throw new \RuntimeException( 'Exclusions unconfirmed.' );
		}
	}

	private static function clear_rolled_back_caches( int $id ): void {
		wp_cache_delete( 'wpchill_folders_storage_maps', 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( 'notoptions', 'options' );
		if ( $id ) {
			clean_post_cache( $id );
		}
	}
}
