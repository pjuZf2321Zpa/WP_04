<?php
/**
 * Thin Modula Pro host bootstrap for wpchill-folders storage and Folders entitlement.
 *
 * Lives outside the wpchill-folders copy unit. Runs on plugins_loaded
 * priority 5 so it wins the library singleton before Lite's priority 10.
 *
 * @package Modula_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'modula_pro_wpchill_folders_init_config' ) ) {

	/**
	 * Turn Lite host config into a Pro init payload with storage and Folders entitlement on.
	 *
	 * @param array $host_config Lite host config.
	 * @return array
	 */
	function modula_pro_wpchill_folders_init_config( array $host_config ) {
		$host_config['storage'] = true;
		$host_config['folders'] = true;
		return $host_config;
	}

	/**
	 * Init wpchill-folders with storage entitlement.
	 *
	 * @return void
	 */
	function modula_pro_init_wpchill_folders() {
		if ( ! function_exists( 'wpchill_folders_init' ) || ! function_exists( 'modula_wpchill_folders_host_config' ) ) {
			return;
		}

		wpchill_folders_init( modula_pro_wpchill_folders_init_config( modula_wpchill_folders_host_config() ) );
	}

	/**
	 * Schedule Pro folders init before Lite.
	 *
	 * @return void
	 */
	function modula_pro_bootstrap_wpchill_folders() {
		if ( function_exists( 'did_action' ) && did_action( 'plugins_loaded' ) ) {
			modula_pro_init_wpchill_folders();
			return;
		}

		if ( function_exists( 'add_action' ) ) {
			add_action( 'plugins_loaded', 'modula_pro_init_wpchill_folders', 5 );
			return;
		}

		modula_pro_init_wpchill_folders();
	}

	modula_pro_bootstrap_wpchill_folders();
}

