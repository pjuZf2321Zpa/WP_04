<?php
namespace Modula_Pro\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {

	public static function remove_empty_items( $arr ) {

		if ( ! is_array( $arr ) ) {
			return false;
		}

		if ( empty( $arr ) ) {
			return $arr;
		}

		$new_array = array();

		foreach ( $arr as $value ) {
			if ( '' !== $value ) {
				$new_array[] = $value;
			}
		}

		return $new_array;
	}

	public static function get_plugins( $plugin_folder = '' ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return get_plugins( $plugin_folder );
	}

	public static function _get_plugin_basename_from_slug( $slug ) {
		$keys = array_keys( self::get_plugins() );
		foreach ( $keys as $key ) {
			if ( preg_match( '|^' . $slug . '/|', $key ) ) {
				return $key;
			}

			if ( 'modula-best-grid-gallery' === $slug ) {
				if ( preg_match( '|^modula-lite/|', $key ) ) {
					return $key;
				}
			}
		}
		return $slug;
	}

	public static function check_plugin_is_installed( $slug ) {
		$plugin_path = self::_get_plugin_basename_from_slug( $slug );
		if ( file_exists( WP_PLUGIN_DIR . '/' . $plugin_path ) ) {
			return true;
		}

		if ( 'modula-best-grid-gallery' === $slug ) {
			return file_exists( WP_PLUGIN_DIR . '/modula-lite' );
		}

		return false;
	}

	/**
	 * @return bool
	 */
	public static function check_plugin_is_active( $slug ) {
		$plugin_path = self::_get_plugin_basename_from_slug( $slug );
		$exists      = self::check_plugin_is_installed( $slug );
		if ( $exists ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';

			$active = is_plugin_active( $plugin_path );

			if ( $active ) {
				return $active;
			}

			if ( 'modula-best-grid-gallery' === $slug ) {
				$active = is_plugin_active( str_replace( 'modula-best-grid-gallery', 'modula-lite', $plugin_path ) );
			}

			return $active;
		}

		return false;
	}

	/**
	 * Modula Placeholders
	 *
	 * @return mixed|void
	 * @since 2.3.2
	 */
	public static function modula_albums_placeholders() {

		return apply_filters( 'modula_albums_placeholders', array() );
	}

	/**
	 * Placeholders real/front value
	 *
	 * @param $value
	 * @param $obj
	 *
	 * @return string|string[]
	 * @since 2.3.2
	 */
	public static function modula_albums_placeholders_value( $value, $obj ) {

		$values = apply_filters(
			'modula_albums_placeholder_values',
			array(
				'setting' => array(),
				'front'   => array(),
			),
			$obj
		);

		return str_replace( $values['setting'], $values['front'], $value );
	}

	/**
	 * Defaults from the pro version
	 *
	 * @param array $defaults Array of default settings.
	 *
	 * @return array
	 * @since 2.6.5 - moved from class-modula-pro-settings.php here in order to preserve the default settings in front.
	 */
	public static function default_settings( $defaults ) {

		$defaults['maxImagesCount']              = 0;
		$defaults['maxImagesCount_mobile']       = 0;
		$defaults['showAllOnLightbox']           = 0;
		$defaults['filters']                     = array( '' );
		$defaults['filterClick']                 = 0;
		$defaults['allFilterLabel']              = esc_html__( 'All', 'modula-pro' );
		$defaults['dropdownFilters']             = 0;
		$defaults['loadedRotate']                = 0;
		$defaults['loadedHSlide']                = 0;
		$defaults['loadedVSlide']                = 0;
		$defaults['hoverColor']                  = '#000000';
		$defaults['uploadCursor']                = 0;
		$defaults['hoverOpacity']                = 50;
		$defaults['hideAllFilter']               = 0;
		$defaults['enableCollapsibleFilters']    = 0;
		$defaults['enableMobileDropdownFilters'] = 0;
		$defaults['filterPositioning']           = 'top';
		$defaults['filterTextAlignment']         = 'none';
		$defaults['defaultActiveFilter']         = 'All';
		$defaults['filterLinkColor']             = '';
		$defaults['filterLinkHoverColor']        = '';
		$defaults['filterStyle']                 = 'default';
		$defaults['showTitleLightbox']           = 0;
		$defaults['showCaptionLightbox']         = 1;
		$defaults['captionPosition']             = 'center';
		$defaults['show_gallery_title']          = 0;
		$defaults['gallery_title_type']          = 'p';
		$defaults['titleFontWeight']             = 'normal';
		$defaults['captionFontWeight']           = 'normal';
		$defaults['collapsibleActionText']       = __( 'Filter by', 'modula-pro' );
$defaults['loop_lightbox']               = 0;
		$defaults['doubleClick']                 = 0;
		$defaults['lightbox_background_color']   = 'rgba(30,30,30,.9)';
		$defaults['lightbox_toolbar']            = 1;
		$defaults['lightbox_close']              = 1;
		$defaults['lightbox_download']           = 0;
		$defaults['lightbox_thumbs']             = 0;
		$defaults['lightbox_zoom']               = 0;
		$defaults['lightbox_infobar']            = 1;
		$defaults['lightbox_dblclickSlide']      = 0;
		$defaults['lightbox_animationEffect']    = false;
		$defaults['lightbox_transitionEffect']   = 'fade';
		$defaults['lightbox_thumbsAutoStart']    = 0;

		if ( ! isset( $defaults['cursor'] ) ) {
			$defaults['cursor'] = 'magnifying-glass';
		}

		return $defaults;
	}
}
