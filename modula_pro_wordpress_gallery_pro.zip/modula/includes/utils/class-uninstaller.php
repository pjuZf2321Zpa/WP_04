<?php
namespace Modula_Pro\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Uninstaller {
	public function __construct() {
		add_filter( 'modula_uninstall_db_options', array( $this, 'uninstall_process' ), 25, 1 );
		add_filter( 'modula_uninstall_transients', array( $this, 'uninstall_process_transients' ), 25, 1 );
	}

	public function uninstall_process( $db_options ) {

		$db_options[] = 'modula_pro_license_status';
		$db_options[] = 'modula_pro_license_key';

		return $db_options;
	}

	public function uninstall_process_transients( $transients ) {

		$transients[] = 'modula_pro_licensed_extensions';

		return $transients;
	}
}
