<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @return array
 *
 * Return default active filter
 */
function modula_pro_current_active_filter() {
	$id       = get_the_ID();
	$settings = get_post_meta( $id, 'modula-settings', true );
	$filters  = isset( $settings['filters'] ) ? $settings['filters'] : false;

	$return = array(
		'All' => esc_html__( 'All', 'modula-pro' ),
	);

	if ( $filters ) {
		foreach ( $filters as $filter ) {
			$comma             = '&#44';
			$return[ $filter ] = esc_html( str_replace( $comma, ',', $filter ) );
		}
	}

	return $return;
}

function modula_pro_sanitize_color( $color ) {

	if ( method_exists( 'Modula_Helper', 'sanitize_rgba_colour' ) ) {
		return Modula_Helper::sanitize_rgba_colour( $color );
	}

	if ( empty( $color ) || is_array( $color ) ) {
		return 'rgba(0,0,0,0)';
	}

	if ( false === strpos( $color, 'rgba' ) ) {
		return sanitize_hex_color( $color );
	}

	$color = str_replace( ' ', '', $color );
	sscanf( $color, 'rgba(%d,%d,%d,%f)', $red, $green, $blue, $alpha );

	return 'rgba(' . absint( $red ) . ',' . absint( $green ) . ',' . absint( $blue ) . ',' . floatval( $alpha ) . ')';
}

function modula_pro_hex_to_rgb( $hex, $alpha = false ) {

	$hex = str_replace( '#', '', $hex );

	$length   = strlen( $hex );
	$rgb['r'] = hexdec( 6 === $length ? substr( $hex, 0, 2 ) : ( 3 === $length ? str_repeat( substr( $hex, 0, 1 ), 2 ) : 0 ) );
	$rgb['g'] = hexdec( 6 === $length ? substr( $hex, 2, 2 ) : ( 3 === $length ? str_repeat( substr( $hex, 1, 1 ), 2 ) : 0 ) );
	$rgb['b'] = hexdec( 6 === $length ? substr( $hex, 4, 2 ) : ( 3 === $length ? str_repeat( substr( $hex, 2, 1 ), 2 ) : 0 ) );
	if ( $alpha ) {
		$rgb['a'] = ( 0 < $alpha ) ? $alpha / 100 : 0;
	} else {
		$rgb['a'] = 1;
	}

	return 'rgba(' . absint( $rgb['r'] ) . ',' . absint( $rgb['g'] ) . ',' . absint( $rgb['b'] ) . ',' . floatval( $rgb['a'] ) . ')';
}

/**
 * Ensures modula-conditions and modula-pro-conditions are registered so scripts
 * that depend on them can be enqueued without triggering WordPress 6.9.1 notices.
 * Call this before enqueueing any script that lists these as dependencies (e.g. on album screens).
 *
 * @since 2.10.0
 */
function modula_pro_ensure_condition_scripts_registered() {
	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

	if ( ! wp_script_is( 'modula-conditions', 'registered' ) && defined( 'MODULA_URL' ) && defined( 'MODULA_LITE_VERSION' ) ) {
		wp_register_script(
			'modula-conditions',
			MODULA_URL . 'assets/js/admin/wp-modula-conditions' . $suffix . '.js',
			array( 'jquery' ),
			MODULA_LITE_VERSION,
			true
		);
	}

	if ( ! wp_script_is( 'modula-pro-conditions', 'registered' ) ) {
		wp_register_script(
			'modula-pro-conditions',
			MODULA_PRO_URL . 'assets/js/misc/wp-modula-pro-conditions.js',
			array( 'jquery' ),
			MODULA_PRO_VERSION,
			true
		);
	}
}

/**
 * Where "Back to album" leads on an album or gallery page opened from an
 * album with "Back to album" on (`?back_to_album`): the current post's
 * parent, else the referer when there is no current post.
 *
 * A post with no parent gets its own permalink (`get_the_permalink( 0 )` is
 * the current post's), as the button has always linked it; only nested albums
 * have a parent.
 *
 * @return string The link, or '' when the page shows no "Back to album".
 */
function modula_back_to_album_url() {
	global $post;

	// A read-only navigation flag in the URL; no state changes.
	if ( empty( $_GET['back_to_album'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return '';
	}

	$referrer = wp_get_referer();

	if ( isset( $post->ID ) ) {
		$parent_id = wp_get_post_parent_id( $post->ID );
		$referrer  = get_the_permalink( $parent_id );
	}

	return $referrer ? (string) $referrer : '';
}

/**
 * The "Back to album" button's stylesheet, for the classic button and the Album visitor frontend's.
 *
 * @return void
 */
function modula_enqueue_back_to_album_style() {
	wp_enqueue_style(
		'modula-backto',
		MODULA_PRO_URL . 'includes/extensions/albums/assets/css/front/modula-backto.css',
		array(),
		MODULA_PRO_VERSION
	);
}

function modula_add_back_to_album_button() {
	$referrer = modula_back_to_album_url();

	if ( '' !== $referrer ) {
		modula_enqueue_back_to_album_style();

		echo '<a href="' . esc_url( $referrer ) . '" class="modula-album-button modula-back-to-album-button">'
			. esc_html__( 'Back to Album', 'modula-pro' )
			. '<span class="dashicons dashicons-arrow-right-alt2"></span></a>';
	}
}
