<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-lite-requirement.php';

use Modula_Pro\Admin\Admin;
use Modula_Pro\Admin\License_Settings;
use Modula_Pro\Admin\Plugins_Screen_License;
use Modula_Pro\Admin\Settings;
use Modula_Pro\Extensions\Api;
use Modula_Pro\Extensions\Extensions;
use Modula_Pro\Extensions\Licensing;
use Modula_Pro\Gallery_Types\Bnb;
use Modula_Pro\Gutenberg;
use Modula_Pro\Lightbox_Enhancer;
use Modula_Pro\Lite_Requirement;
use Modula_Pro\Scripts;
use Modula_Pro\Shortcodes\Link_Shortcode;
use Modula_Pro\Templates;
use Modula_Pro\Utils\Debug;
use Modula_Pro\Utils\Gallery_Upgrade;
use Modula_Pro\Utils\Importer;
use Modula_Pro\Utils\Plugin_Conflicts;
use Modula_Pro\Utils\Troubleshooting;
use Modula_Pro\Utils\Uninstaller;

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * @since      2.0.0
 */
class Modula_Pro {
	public function __construct() {
		$lite_version = Lite_Requirement::current_lite_version();

		// Soft-fail when Lite is inactive, missing or too old: keep wp-admin usable (FreeScout #50772).
		if ( ! Lite_Requirement::should_boot_features( $lite_version ) ) {
			$notice = Lite_Requirement::is_outdated( $lite_version ) ? 'lite_version_notice' : 'lite_required_notice';
			add_action( 'admin_notices', array( $this, $notice ) );
			add_action( 'admin_init', array( $this, 'clear_resolved_lite_notices' ) );
			return;
		}

		add_action( 'admin_init', array( $this, 'clear_resolved_lite_notices' ) );

		$this->init();

		if ( is_admin() ) {
			$this->admin_init();
		}
	}

	/**
	 * Display admin notice when Modula Lite is missing or deactivated.
	 */
	public function lite_required_notice() {
		$message = esc_html__( 'Modula PRO requires the free Modula plugin (Modula Lite) to be installed and active. Please install or activate Modula Lite to use Pro features.', 'modula-pro' );
		$this->render_lite_dependency_notice( Lite_Requirement::REQUIRED_NOTICE, $message );
	}

	/**
	 * Display admin notice when Modula Lite version is below the required minimum.
	 */
	public function lite_version_notice() {
		$message = sprintf(
			/* translators: %s: minimum Modula Lite version required by Pro */
			esc_html__( 'Modula PRO requires Modula Lite %s or newer. PRO features are paused until you update the free Modula plugin.', 'modula-pro' ),
			Lite_Requirement::MINIMUM_VERSION
		);
		$this->render_lite_dependency_notice( Lite_Requirement::OUTDATED_NOTICE, $message );
	}

	/**
	 * Remove stored Lite dependency notifications whose cause is gone. They are persistent
	 * WPChill notifications, so without this an updated or activated Lite leaves them in the bell.
	 */
	public function clear_resolved_lite_notices() {
		if ( ! class_exists( 'WPChill_Notifications' ) ) {
			return;
		}

		// Notifications are stored with update_option(), so they autoload: checking the loaded
		// options costs no query, while delete_option() queries even when nothing is stored.
		$stored = wp_load_alloptions();
		foreach ( Lite_Requirement::resolved_notices( Lite_Requirement::current_lite_version() ) as $notification_id ) {
			if ( isset( $stored[ \WPChill_Notifications::$notification_prefix . $notification_id ] ) ) {
				\WPChill_Notifications::remove_notification( $notification_id );
			}
		}
	}

	/**
	 * Render a Lite dependency admin notice via notifications API or fallback markup.
	 *
	 * @param string $notification_id Notification id for Modula_Notifications.
	 * @param string $message         Escaped notice message.
	 */
	private function render_lite_dependency_notice( $notification_id, $message ) {
		if ( class_exists( 'Modula_Notifications' ) ) {
			$notice = array(
				'title'   => esc_html__( 'Modula PRO', 'modula-pro' ),
				'message' => $message,
				'status'  => 'error',
			);
			\Modula_Notifications::add_notification( $notification_id, $notice );
		} elseif ( function_exists( 'wp_admin_notice' ) ) {
			wp_admin_notice(
				$message,
				array(
					'type'        => 'error',
					'dismissible' => true,
				)
			);
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
		}
	}

	public function init() {
		add_action( 'init', array( $this, 'set_locale' ) );
		add_filter( 'modula_settings_editor_upsells', '__return_empty_array' );
		Api::get_instance();
		Extensions::get_instance();

		new Scripts();
		new Bnb();
		new Settings();

		// Not in the built classmap; booted here, not in admin_init(), because the settings app reads tabs over REST.
		require_once MODULA_PRO_PATH . 'includes/admin/class-license-settings.php';
		new License_Settings();

		new Link_Shortcode();
		new Gallery_Upgrade();
		new Plugin_Conflicts();
		new Lightbox_Enhancer();
		new Templates();
		new Gutenberg();
		new Troubleshooting();

		require_once MODULA_PRO_PATH . 'includes/wpchill-folders-bootstrap.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-intake-executor.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-intake-provider.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-collection-executor.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-collection-provider.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-storage-executor.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-storage-provider.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-transfer-executor.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-transfer-provider.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-bound-executor.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-bound-provider.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-site-executor.php';
		require_once MODULA_PRO_PATH . 'includes/abilities/class-site-provider.php';
		\Modula_Pro\Abilities\Intake_Provider::boot();
		\Modula_Pro\Abilities\Collection_Provider::boot();
		\Modula_Pro\Abilities\Storage_Provider::boot();
		\Modula_Pro\Abilities\Transfer_Provider::boot();
		\Modula_Pro\Abilities\Bound_Provider::boot();
		\Modula_Pro\Abilities\Site_Provider::boot();
		require_once MODULA_PRO_PATH . 'includes/abilities/class-freeform-author.php';
		\Modula_Pro\Abilities\Freeform_Author::boot();
	}

	public function admin_init() {
		Licensing::get_instance();

		if ( Licensing::get_instance()->has_plan() ) {
			Importer::get_instance();
		}

		new Admin();

		// Not in the built classmap.
		require_once MODULA_PRO_PATH . 'includes/admin/class-plugins-screen-license.php';
		new Plugins_Screen_License( Licensing::get_instance() );

		new Debug();
		new Uninstaller();
		new \Modula_Pro\Admin\Settings_Editor_Pro_Core_Integration();
	}

	public function set_locale() {
		load_plugin_textdomain(
			'modula-pro',
			false,
			dirname( plugin_basename( MODULA_PRO_FILE ) ) . '/languages'
		);
	}

	//deprecated
	public static function check_for_license() {
		return null;
	}
}
