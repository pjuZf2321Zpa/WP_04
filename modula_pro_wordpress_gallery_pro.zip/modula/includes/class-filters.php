<?php
namespace Modula_Pro;

use Modula_Pro\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Filters {
	public function __construct() {
		add_filter( 'modula_gallery_settings', array( $this, 'modula_pro_config' ), 10, 2 );
	}

	public function modula_pro_config( $js_config, $settings ) {
		$lightbox = isset( $settings['lightbox'] ) ? $settings['lightbox'] : '';
		if ( function_exists( 'modula_coerce_lightbox_click_mode' ) ) {
			$lightbox = modula_coerce_lightbox_click_mode( $lightbox );
		} elseif ( 'direct' === $lightbox ) {
			$lightbox = 'fancybox';
		}
		$js_config['lightbox'] = $lightbox;

		if ( apply_filters( 'modula_disable_lightboxes', true ) && ! in_array( $lightbox, array( 'no-link', 'attachment-page', 'external-url', 'lightbox-prefer-url' ), true ) ) {
			$js_config['lightbox'] = 'fancybox';
		}

		if ( isset( $settings['filterClick'] ) ) {
			$js_config['filterClick'] = esc_attr( $settings['filterClick'] );
		}

		if ( isset( $settings['dropdownFilters'] ) ) {
			$js_config['dropdownFilters'] = esc_attr( $settings['dropdownFilters'] );

			if ( wp_is_mobile() && isset( $settings['enableMobileDropdownFilters'] ) && 1 === $settings['enableMobileDropdownFilters'] ) {
				$js_config['dropdownFilters'] = '1';
			}
		}

		$js_config['defaultActiveFilter'] = ( isset( $settings['defaultActiveFilter'] ) ) ? esc_attr( sanitize_title( $settings['defaultActiveFilter'] ) ) : false;
		$js_config['initLightbox']        = 'modula_pro_init_lightbox';

		$js_config['haveFilters'] = 0;
		if ( isset( $settings['filters'] ) && 'bnb' !== $settings['type'] ) {
			$filters = Helper::remove_empty_items( $settings['filters'] );

			if ( is_array( $filters ) && ! empty( $filters ) ) {
				$js_config['haveFilters'] = 1;
			}
		}



		if ( isset( $settings['doubleClick'] ) && 1 === absint( $settings['doubleClick'] ) ) {
			$js_config['mobileDoubleClick'] = 1;
		}

		return $js_config;
	}
}

