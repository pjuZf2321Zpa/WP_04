<?php

define( 'MODULA_PRO_VERSION', '3.0.23' );
define( 'MODULA_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'MODULA_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'MODULA_PRO_FILE', str_replace( '/', DIRECTORY_SEPARATOR, MODULA_PRO_PATH . 'Modula.php' ) );
define( 'MODULA_PRO_REACT_APPS_URL', plugin_dir_url( __FILE__ ) . 'assets/js/react-apps' );
define( 'MODULA_PRO_REACT_APPS_PATH', plugin_dir_path( __FILE__ ) . 'assets/js/react-apps' );
defined( 'MODULA_PRO_STORE_URL' ) || define( 'MODULA_PRO_STORE_URL', 'https://wp-modula.com' );
defined( 'MODULA_PRO_ALTERNATIVE_STORE_URL' ) || define( 'MODULA_PRO_ALTERNATIVE_STORE_URL', 'https://license.wpchill.com/modula' );
defined( 'MODULA_PRO_STORE_UPGRADE_URL' ) || define( 'MODULA_PRO_STORE_UPGRADE_URL', 'https://wp-modula.com/pricing' );
defined( 'MODULA_PRO_STORE_ITEM_ID' ) || define( 'MODULA_PRO_STORE_ITEM_ID', 212 );
define( 'MODULA_PRO_PREINSTALL', 'edf7626466fe11d0fa83987c0dc1b296');