<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'modula_pro_alternative_server' );
delete_option( 'modula_pro_license_key' );
delete_option( 'modula_pro_license_status' );
