<?php return array('dependencies' => array('wp-compose', 'wp-element', 'wp-i18n'), 'version' => '0d3e7451ba0c46b42e5d');
