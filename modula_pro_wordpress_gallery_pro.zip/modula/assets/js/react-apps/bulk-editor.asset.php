<?php return array('dependencies' => array('react', 'react-jsx-runtime', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => 'f74483862c1050b8ee94');
