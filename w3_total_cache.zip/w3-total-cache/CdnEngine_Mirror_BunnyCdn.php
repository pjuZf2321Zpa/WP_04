<?php
/**
 * File: CdnEngine_Mirror_BunnyCdn.php
 *
 * @since   2.6.0
 * @package W3TC
 */

namespace W3TC;

/**
 * Class: CdnEngine_Mirror_BunnyCdn
 *
 * @since 2.6.1
 *
 * @extends CdnEngine_Mirror
 */
class CdnEngine_Mirror_BunnyCdn extends CdnEngine_Mirror {
	/**
	 * Constructor.
	 *
	 * @param array $w3tc_config {
	 *     Configuration.
	 *
	 *     @type string $w3tc_account_api_key Account API key.
	 *     @type string $storage_api_key Storage API key.
	 *     @type string $stream_api_key  Steam API key.
	 *     @type int    $pull_zone_id    Pull zone id.
	 *     @type string $w3tc_cdn_hostname    CDN hostname.
	 * }
	 */
	public function __construct( array $w3tc_config = array() ) {
		$w3tc_config = \array_merge(
			array(
				'account_api_key' => '',
				'storage_api_key' => '',
				'stream_api_key'  => '',
				'pull_zone_id'    => null,
				'domain'          => '',
			),
			$w3tc_config
		);

		parent::__construct( $w3tc_config );
	}

	/**
	 * Purge remote files.
	 *
	 * @since 2.6.0
	 *
	 * @param  array $files   Local and remote file paths.
	 * @param  array $results Results.
	 *
	 * @return bool
	 */
	public function purge( $files, &$results ) {
		if ( empty( $this->_config['account_api_key'] ) ) {
			$results = $this->_get_results( $files, W3TC_CDN_RESULT_HALT, \__( 'Missing account API key.', 'w3-total-cache' ) );

			return false;
		}

		if ( empty( $this->_config['cdn_hostname'] ) ) {
			$results = $this->_get_results( $files, W3TC_CDN_RESULT_HALT, \__( 'Missing CDN hostname.', 'w3-total-cache' ) );

			return false;
		}

		$url_prefixes = $this->url_prefixes();
		$api          = new Cdn_BunnyCdn_Api( $this->_config );
		$results      = array();

		try {
			$items = array();

			foreach ( $files as $w3tc_file ) {
				foreach ( $url_prefixes as $prefix ) {
					$items[] = array(
						'url'       => $prefix . '/' . $w3tc_file['remote_path'],
						'recursive' => true,
					);
				}
			}

			$api->purge( array( 'items' => $items ) );

			$results[] = $this->_get_result( '', '', W3TC_CDN_RESULT_OK, 'OK' );
		} catch ( \Exception $e ) {
			$results[] = $this->_get_result( '', '', W3TC_CDN_RESULT_HALT, \__( 'Could not purge pull zone items: ', 'w3-total-cache' ) . $e->getMessage() );
		}

		return ! $this->_is_error( $results );
	}

	/**
	 * Purge CDN completely.
	 *
	 * @since 2.6.0
	 *
	 * @param  array $results Results.
	 *
	 * @return bool
	 */
	public function purge_all( &$results ) {
		if ( empty( $this->_config['account_api_key'] ) ) {
			$results = $this->_get_results( array(), W3TC_CDN_RESULT_HALT, __( 'Missing account API key.', 'w3-total-cache' ) );

			return false;
		}

		// Purge active pull zones: CDN & CDNFSD.
		$zones       = array();
		$w3tc_config = Dispatcher::config();
		$cdn_zone_id = $w3tc_config->get_integer( 'cdn.bunnycdn.pull_zone_id' );
		$fsd_zone_id = $w3tc_config->get_integer( 'cdnfsd.bunnycdn.pull_zone_id' );

		if ( $w3tc_config->get_boolean( 'cdn.enabled' ) && 'bunnycdn' === $w3tc_config->get_string( 'cdn.engine' ) && $cdn_zone_id ) {
			$zones[] = array(
				'id'                      => $cdn_zone_id,
				'verify_tls_certificates' => $w3tc_config->get_boolean( 'cdn.bunnycdn.verify_tls_certificates', true ),
			);
		}

		if ( $w3tc_config->get_boolean( 'cdnfsd.enabled' ) && 'bunnycdn' === $w3tc_config->get_string( 'cdnfsd.engine' ) && $fsd_zone_id ) {
			$zones[] = array(
				'id'                      => $fsd_zone_id,
				'verify_tls_certificates' => $w3tc_config->get_boolean( 'cdnfsd.bunnycdn.verify_tls_certificates', true ),
			);
		}

		if ( empty( $zones ) ) {
			$results = $this->_get_results( array(), W3TC_CDN_RESULT_HALT, __( 'Missing pull zone id.', 'w3-total-cache' ) );

			return false;
		}

		$results = array();

		foreach ( $zones as $zone ) {
			$api = new Cdn_BunnyCdn_Api(
				array_merge(
					$this->_config,
					array(
						'pull_zone_id'            => $zone['id'],
						'verify_tls_certificates' => $zone['verify_tls_certificates'],
					)
				)
			);

			try {
				$api->purge_pull_zone();
				$results[] = $this->_get_result( '', '' ); // W3TC_CDN_RESULT_OK.
			} catch ( \Exception $e ) {
				$results[] = $this->_get_result( '', '', W3TC_CDN_RESULT_HALT, \__( 'Could not purge pull zone', 'w3-total-cache' ) . '; ' . $e->getMessage() );
			}
		}

		return ! $this->_is_error( $results );
	}

	/**
	 * Get URL prefixes.
	 *
	 * If set to "auto", then add URLs for both "http" and "https".
	 *
	 * @since 2.6.0
	 *
	 * @return array
	 */
	private function url_prefixes() {
		$url_prefixes = array();

		if ( 'auto' === $this->_config['ssl'] || 'enabled' === $this->_config['ssl'] ) {
			$url_prefixes[] = 'https://' . $this->_config['cdn_hostname'];
		}
		if ( 'auto' === $this->_config['ssl'] || 'enabled' !== $this->_config['ssl'] ) {
			$url_prefixes[] = 'http://' . $this->_config['cdn_hostname'];
		}

		return $url_prefixes;
	}
}
