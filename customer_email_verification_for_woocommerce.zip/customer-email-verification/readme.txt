=== Customer Email Verification ===
Contributors: zorem
Tags: woocommerce, email verification, otp, spam protection, two-factor
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.0.6
WC requires at least: 4.8
WC tested up to: 11.2.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0

Reduce registration and order spam by requiring customers to verify their email address during registration or before checkout.

== Description ==

Customer Email Verification helps WooCommerce store owners cut down on registration and order spam by requiring customers to verify their email address when they register an account or before they can check out.

It confirms that a real, reachable inbox is behind every new account and order — stopping fake signups, throwaway addresses, and bot traffic before they reach your store.

= Key features =

* **Signup verification** — verify the email address on the registration form with a one-time code (OTP) or a verification link.
* **Checkout verification** — optionally require guests to verify their email before placing an order (classic and Blocks checkout).
* **Login authentication** — prompt unverified or unrecognized logins to verify with a one-time code.
* **Two-Factor Authentication (2FA)** — optional authenticator-app (TOTP) verification with QR enrolment and recovery codes.
* **Smart Form** — a modern, brand-customizable login/registration form with built-in email or phone (SMS) verification, four ready-made layouts, and an optional My Account takeover.
* **Spam protection** — block disposable/temporary email domains, validate the email domain (MX check), restrict signups to specific domains (B2B), and block specific addresses.
* **Email customizer** — design the verification emails and popups to match your brand.
* **Analytics** — track signups, verification rate, blocked spam, and time-to-verify from a dashboard.
* **Maintenance tools** — auto-clean stale unverified records, auto-delete unverified accounts (with safeguards), and send re-engagement reminders.
* **Translation-ready** — WPML and Polylang compatible; HPOS (High-Performance Order Storage) compatible.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/customer-email-verification` directory, or install the plugin through the WordPress **Plugins** screen.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Make sure WooCommerce is installed and active.
4. Go to **WooCommerce → Email Verification** to configure signup, checkout, login, and spam-protection settings.

== Frequently Asked Questions ==

= Does this require WooCommerce? =

Yes. WooCommerce must be installed and active.

= Is checkout verification enabled by default? =

No. Signup verification is the core feature; checkout verification is opt-in and can be enabled under **WooCommerce → Email Verification → Settings**.

= Is it compatible with the Blocks checkout and HPOS? =

Yes. The plugin supports both the classic and Blocks (Store API) checkout and declares High-Performance Order Storage compatibility.

= Is it translation-ready? =

Yes. The plugin is fully translatable and compatible with both WPML and Polylang.

== Changelog ==

= 3.0.6 - 2026-10-21 =
* Improvement - Added a one-time notice introducing AI Agent OS from zorem, with a launch offer. It is shown to store managers outside the plugin's own screens, can be dismissed, and goes away when the offer ends or once AI Agent OS is installed.
* Improvement - The Unverified Users list, the Maintenance statistics and the daily unverified-account cleanup are now much faster on stores with a large number of abandoned signups, thanks to new database indexes added automatically on update.
* Fix - The Settings page no longer times out on large stores. The number of accounts eligible for auto-delete on the Maintenance card is now counted in the background after the page has loaded, and the cleanup checks customer orders in batches instead of one customer at a time.
* Fix - Smart Form sign-in with an email or SMS code now sends a fresh code every time the customer clicks Sign in. Previously only the first code was sent and later requests were silently skipped, so customers could not log in. The "Resend code" link follows the Verification Email Resend Limit and shows the resend-limit message when it is reached.
* Fix - Changing the account email address on the My Account page now verifies correctly. The emailed code always matches, pressing Enter in the code field verifies it instead of sending another email, and a new email is not sent while a valid code is still waiting to be entered.
* Dev - Tested with WooCommerce 11.2.1
* Dev - Tested with WordPress 7.1.3

= 3.0.5 - 2026-10-08 =
* Feature - Added a setup checklist to the top of the Settings tab that walks you through getting started: turning on signup and checkout verification, sending yourself a test verification email, customizing the email and popup, enabling disposable email blocking and reviewing the Unverified Users list. It hides itself once every step is done, or you can hide it at any time.
* Improvement - Added a "Leave a review" card to the Settings sidebar and a one-time review request notice that can be dismissed.
* Fix - Only store managers can now change a customer's verification status, delete Unverified Users entries or save the plugin settings. Customers viewing their own profile see their verification status only, without the verify/unverify buttons.
* Fix - Email and popup previews in the customizer are now available to administrators only.
* Fix - Spam Protection now shows the correct size of the built-in disposable email list (430+ domains), and the "available variables" hint in the customizer can now be translated.
* Dev - Tested with WooCommerce 11.1.2
* Dev - Tested with WordPress 7.1.3

= 3.0.4 - 2026-09-23 =
* Fix - Smart Form registration now runs WooCommerce's own registration checks before the verification code is sent, so problems such as an email address already being in use are reported immediately instead of after the customer has entered their code.
* Fix - Custom fields added to the Smart Form registration are now available to WooCommerce and other plugins while the account is being created, so values such as phone or company are stored against the new account correctly.
* Fix - Customers are now returned to the page they originally requested after signing in or registering through the Smart Form, instead of always being sent to the account page.
* Fix - Checkout verification now re-checks the live cart when the order is submitted, so items added after a code was verified are taken into account.
* Fix - The email-change verification on the Edit Account page now uses its own dedicated code, so it can only be completed with a code issued for that change.
* Fix - Customers who use up their login verification attempts are still required to verify before they can reach the rest of their account pages.
* Fix - Signing in with an emailed or texted code now also asks for the Authenticator App code when two-factor authentication is enabled on the account.
* Dev - Tested with WooCommerce 11.1.2
* Dev - Tested with WordPress 7.1.2

= 3.0.3 - 2026-09-03 =
* Fix - Store staff are no longer blocked at checkout. Administrators, editors and shop managers are now exempt from checkout email verification, so they can place test orders without being held behind the verification popup.
* Fix - The [cev_smart_form] shortcode no longer renders the login/register form to visitors who are already signed in.
* Fix - Corrected the template path used by the front-end popup preview, which stopped the preview from loading.
* Fix - Removed a duplicate key in the checkout script data that could override the resend countdown text.
* Dev - Replaced deprecated WooCommerce cart properties with their supported accessors, preserving tax-inclusive subtotals on tax-enabled stores.
* Dev - Corrected the registration type of three hooks (pre_get_users, block_categories_all, woocommerce_form_field) to match WordPress and WooCommerce.
* Dev - Resolved all findings from the WooCommerce marketplace static-analysis (Quality Insights) audit.
* Dev - Tested with WooCommerce 11.0.1
* Dev - Tested with WordPress 7.1

= 3.0.2 - 2026-08-19 =
* Feature - Added AI detection of disposable/throwaway email addresses. Beyond the built-in domain list, it flags brand-new temp-mail domains and abusive patterns (random mailboxes, plus-address abuse) and lets you review and add them to your block list in one click, so spam protection stays current automatically.
* Feature - Added bot-cluster detection. When many signups arrive in a short burst sharing the same device fingerprint and network, the Unverified Users screen flags the cluster and lets you block and delete the whole group in one click — stopping coordinated bot attacks that per-user rules miss.
* Feature - Added AI risk scoring for registrations and guest checkout. Each signup/order is scored from multiple signals (disposable/gibberish email patterns, IP/ASN reputation, signup velocity, device reuse) and the merchant chooses what happens at each risk level — allow, require a one-time code, or block — with a Low/Balanced/Strict sensitivity. A new Risk column on the Unverified Users screen shows the score and reasons.
* Feature - Added a "Require OTP on every login" option in Login Authentication.
* Dev - Tested with WooCommerce 11.0.1
* Dev - Tested with WordPress 7.0.4

= 3.0.1 - 2026-08-04 =
* Feature - Login method now supports multiple sign-in options at once. Enable any combination of Password, Email OTP, and Phone OTP on the Smart Form login (single-select is no longer required).
* Feature - Added a password strength setting for the Smart Form registration. Choose to require a strong password (upper and lower case, a number, and a symbol) or a simpler minimum-length rule, with a configurable minimum length.
* Improvement - Redesigned all customer-facing verification popups with a unified, professional design. Registration, login, account verification, checkout, edit-account and 2FA screens now share one modern visual language, with popup customizer settings applying consistently across every surface plus new Border Radius, Elevation, Accent Color, Font Family and Overlay Opacity options.
* Dev - Tested with WooCommerce 10.9.4
* Dev - Tested with WordPress 7.0.2

= 3.0 - 2026-06-23 =
* New - Added Paid-Order Gatekeeping option. Verified users remain in a restricted "pending paid order" state until their first WooCommerce order completes — preventing welcome-coupon abuse and stopping bot accounts from receiving promotional emails before they've bought anything.
* New - Added "Force re-verify all customers" admin tool to mark every existing unverified user as unverified in a single action. Available as a Tools-page button and as a WP Users list bulk action.
* New - Added Cart-Total Threshold Verification. Trigger OTP verification only when the cart subtotal or total exceeds a specified amount.
* New - Added Polylang compatibility alongside existing WPML support.
* New - Added Smart Form — a unified, brand-customizable login/register form with four ready-made template layouts, flexible login + registration modes, an optional My Account takeover, and SMS verification gateways (MSG91, Twilio, Vonage, WhatsApp Business).
* Improvement - Redesigned the entire admin experience with the new Zorem UI (ZUI) design system across Settings, Unverified Users, Maintenance, Analytics, the Email Customizer, and the 2FA setup card.

= 2.9.5.1 - 2026-05-19 =
* Fix - License tab incorrectly appearing; removed accidental license-gating code that caused the admin page to render blank.

= 2.9.5 - 2026-05-18 =
* New - Added 2FA via Authenticator app as a primary verification method.
* New - Added role-based verification — enforce 2FA for specific user roles only.
* New - Added a Verification Analytics dashboard (signups, verification rate, blocked spam, average time-to-verify, top blocked domains, and a signup-to-verify funnel).

= 2.9.4 - 2026-05-06 =
* Feature - Disposable / temporary email blocking, DNS-based MX validation, B2B allowlist and address block-list, auto-cleanup of stale unverified records, auto-delete of unverified accounts (with safeguards), and re-engagement reminder emails.

For the full changelog, see changelog.txt.

== Upgrade Notice ==

= 3.0.1 =
Adds multiple simultaneous Smart Form login methods and a unified, redesigned popup experience. Tested with WooCommerce 10.9.4.
