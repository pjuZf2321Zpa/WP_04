<?php
/**
 * Re-engagement Reminder Email Template
 *
 * Sent to registered users who never completed email verification.
 * Customizable through the CEV email customizer (Re-engagement Reminder
 * email type) — heading, body copy, button text and link, footer all
 * pull from `cev_pro_customizer` settings via merge tags.
 *
 * Mirrors the layout/styling of cev-email-verification.php so all CEV
 * emails share a consistent visual identity. The PIN block is replaced
 * by a CTA button that deep-links to the My Account / registration page.
 *
 * Variables passed in by the sender (CEV_Pro_Maintenance::send_reengagement_to_user
 * and the customizer preview):
 *
 *   string $email_heading  Resolved heading.
 *   string $content        Resolved body copy (merge-tags applied).
 *   string $button_text    CTA button label.
 *   string $button_url     CTA target URL.
 *   string $footer_content Optional footer copy.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Email template runs inside wc_get_template()'s function scope (not global); the WooCommerce email args (button_text, content, email_heading, …) are a fixed template contract and the cev_* customizer reads are already prefixed.

$cev_verification_image_content            = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_image_content', '' );
$cev_new_email_image_width                 = cev_pro()->function->cev_pro_customizer_settings( 'cev_email_content_widget_header_image_width', cev_pro()->customizer_options->defaults['cev_email_content_widget_header_image_width'] );
$cev_content_align_style                   = cev_pro()->function->cev_pro_customizer_settings( 'cev_content_align_style', cev_pro()->customizer_options->defaults['cev_content_align_style'] );
$cev_verification_content_font_color       = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_content_font_color', cev_pro()->customizer_options->defaults['cev_verification_content_font_color'] );
$cev_header_content_font_size              = cev_pro()->function->cev_pro_customizer_settings( 'cev_header_content_font_size', cev_pro()->customizer_options->defaults['cev_header_content_font_size'] );
$cev_verification_content_background_color = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_content_background_color', cev_pro()->customizer_options->defaults['cev_verification_content_background_color'] );
$cev_verification_content_border_color     = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_content_border_color', cev_pro()->customizer_options->defaults['cev_verification_content_border_color'] );

// Defensive defaults so the template still renders if the sender omits a var.
$button_text    = isset( $button_text ) ? (string) $button_text : __( 'Complete sign up', 'customer-email-verification' );
$button_url     = isset( $button_url ) ? (string) $button_url : '#';
$content        = isset( $content ) ? $content : '';
$email_heading  = isset( $email_heading ) ? $email_heading : '';
$footer_content = isset( $footer_content ) ? $footer_content : '';
?>
<style>
#template_header {
	display: none;
}
#template_header_image {
	display: none;
}
#template_container, #template_body {
	width: 600px !important;
	border: 1px solid <?php echo esc_attr( $cev_verification_content_border_color ); ?> !important;
}
#template_footer td {
	border-top: 0 !important;
}
#body_content {
	background-color: <?php echo esc_attr( $cev_verification_content_background_color ); ?> !important;
	padding: 0 !important;
}
div#wrapper {
	padding-top: 40px;
}
</style>

<table cellpadding="0" cellspacing="0" border="0" width="100%" style="width:100%; border-collapse:collapse;">

	<?php if ( $cev_verification_image_content ) : ?>
	<tr>
		<td align="center" style="padding:14px 0; text-align:center;">
			<img src="<?php echo esc_url( $cev_verification_image_content ); ?>"
				width="<?php echo esc_attr( $cev_new_email_image_width ); ?>"
				alt="<?php esc_attr_e( 'Re-engagement reminder', 'customer-email-verification' ); ?>"
				style="display:inline-block; max-height:60px; width:auto; max-width:<?php echo esc_attr( $cev_new_email_image_width ); ?>px; height:auto;">
		</td>
	</tr>
	<?php endif; ?>

	<tr>
		<td align="<?php echo esc_attr( $cev_content_align_style ); ?>"
			style="padding:14px 0;
				   text-align:<?php echo esc_attr( $cev_content_align_style ); ?>;">
			<h1 style="margin:0;font-size:<?php echo esc_attr( $cev_header_content_font_size ); ?>px;font-weight:700;color:#1a1a2e;text-align:<?php echo esc_attr( $cev_content_align_style ); ?>;line-height:1.3;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,Helvetica,sans-serif;"><?php echo wp_kses_post( $email_heading ); ?></h1>
		</td>
	</tr>

	<tr>
		<td align="<?php echo esc_attr( $cev_content_align_style ); ?>"
			style="padding:14px 0;
				   text-align:<?php echo esc_attr( $cev_content_align_style ); ?>;
				   color:<?php echo esc_attr( $cev_verification_content_font_color ); ?>;
				   font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, Helvetica, sans-serif;
				   font-size:15px;
				   line-height:1.7;">
			<?php echo wp_kses_post( wpautop( $content ) ); ?>
		</td>
	</tr>

	<?php
	// Note: the button markup below is deliberately written on a single line
	// (no whitespace between the nested <td>, <a>, and label tags). Some hosts
	// run wpautop() / wptexturize() / similar over the final email body, which
	// converts newlines between those tags into stray <br> tags and breaks
	// the button layout. Keeping the markup on a single line prevents that.
	?>
	<?php if ( ! empty( $button_text ) && ! empty( $button_url ) ) : ?>
	<tr>
		<td align="<?php echo esc_attr( $cev_content_align_style ); ?>" style="padding:4px 0 20px 0; text-align:<?php echo esc_attr( $cev_content_align_style ); ?>;"><table role="presentation" cellspacing="0" cellpadding="0" border="0" style="display:inline-block; border-collapse:separate;"><tr><td align="center" bgcolor="#2563eb" style="background-color:#2563eb; border-radius:4px; padding:11px 26px;"><a href="<?php echo esc_url( $button_url ); ?>" style="display:inline-block; color:#ffffff !important; text-decoration:none; font-weight:600; font-size:14px; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, Helvetica, sans-serif; line-height:1.4; letter-spacing:.2px;"><?php echo esc_html( $button_text ); ?></a></td></tr></table></td>
	</tr>
	<?php endif; ?>

	<?php if ( ! empty( $footer_content ) ) : ?>
	<tr>
		<td align="<?php echo esc_attr( $cev_content_align_style ); ?>"
			style="padding:14px 0;
				   text-align:<?php echo esc_attr( $cev_content_align_style ); ?>;
				   color:#6b7280;
				   font-size:13px;
				   font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, Helvetica, sans-serif;
				   line-height:1.6;">
			<?php echo wp_kses_post( $footer_content ); ?>
		</td>
	</tr>
	<?php endif; ?>

</table>
