<?php
/**
 * Plugin Name:	Customer Email Verification
 * Plugin URI:	http://woocommerce.com/products/customer-email-verification/
 * Description: The Customer Email Verification helps WooCommerce store owners to reduce registration and orders spam by requiring customers to verify their email address when they register an account or before they can checkout on your store.
 * Version: 3.0.6
 * Author: zorem
 * Author URI: https://www.zorem.com
 * License: GPLv3
 * License URI: http://www.gnu.org/licenses/gpl-3.0
 * Text Domain: customer-email-verification
 * Domain Path: /lang/
 * Requires Plugins: woocommerce
 * Requires at least: 6.0
 * Tested up to: 7.1
 * Requires PHP: 7.4
 * WC requires at least: 4.8
 * WC tested up to: 11.2.1
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package zorem
 * Woo: 8105872:4b9f6cbe025271aa7ae3c09e808651bf

 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class for Customer Email Verification
 * 
 * This class handles the initialization and management of all plugin functionality
 * including email verification, login authentication, and admin settings.
 */
class Customer_Email_Verification_Pro {

	/**
	 * The one plugin instance.
	 *
	 * Published as the FIRST statement of the constructor, before
	 * includes_for_all() runs. Some included files call cev_pro() at global
	 * scope; cev_pro() used to assign its static only AFTER the constructor
	 * returned, so each of those nested calls saw an unset static and built
	 * ANOTHER Customer_Email_Verification_Pro. Three objects were created per
	 * request and every hook each of them registered fired three times.
	 *
	 * @since 3.0.3
	 * @var Customer_Email_Verification_Pro|null
	 */
	public static $instance = null;

	/**
	 * Customer Email Verification Pro
	 *
	 * @var string
	 */
	public $version = '3.0.6';
	public $plugin_file;
	public $plugin_path;
	public $my_account;
	public $admin;
	public $preview;
	public $cev_pro_guest_user;
	public $cev_pro_login_authentication;
	public $email_login;
	public $customizer;
	public $customizer_options;
	public $signup;
	public $install;
	public $cev_pro_checkout_block;
	public $checkout_verification;
	public $enqueue;
	public $hooks;
	public $function;
	private static $action_links_registered = false;
	
	/**
	 * Initialize the main plugin function
	 * 
	 * Sets up the plugin by defining constants, checking dependencies,
	 * and initializing all necessary classes and hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Publish this object before anything else runs, so the cev_pro()
		// calls made at global scope by the files includes_for_all() pulls in
		// reuse it instead of constructing a second and third copy.
		if ( null === self::$instance ) {
			self::$instance = $this;
		}

		// Store the main plugin file path
		$this->plugin_file = __FILE__;
		
		// Set plugin path directly to avoid calling get_plugin_path() during construction
		$this->plugin_path = untrailingslashit(plugin_dir_path(__FILE__));

		// Define the plugin path constant if not already defined
		if (!defined('CUSTOMER_EMAIL_VERIFICATION_PATH')) {
			define('CUSTOMER_EMAIL_VERIFICATION_PATH', $this->plugin_path);
		}

		// Plugin-owned cron events (maintenance / cleanup / re-engagement)
		// are scheduled and cleared via the CEV_Pro_Cron manager so all
		// schedule definitions live in one file. Loaded ahead of time by
		// includes_for_all() so the closures below can find the class.
		register_activation_hook( __FILE__, function() {
			if ( class_exists( 'CEV_Pro_Cron' ) ) {
				CEV_Pro_Cron::register_schedules();
			}
		} );

		register_deactivation_hook( __FILE__, function() {
			if ( class_exists( 'CEV_Pro_Cron' ) ) {
				CEV_Pro_Cron::clear_schedules();
			}
		} );

		$this->includes_for_all();
		
		// Delay initialization to avoid issues during plugin activation
		add_action('plugins_loaded', array($this, 'initialize_plugin'), 5);
		
		// Load text domain on init
		add_action('init', array($this, 'load_pro_textdomain'), 20);
	}
	
	/**
	 * Initialize plugin after plugins are loaded
	 */
	public function initialize_plugin() {
		// Check if WooCommerce is active before proceeding with core functionality
		if ( $this->is_wc_active() ) {
			// Get the WooCommerce My Account page ID
			$this->my_account = get_option('woocommerce_myaccount_page_id');

			// If My Account page ID is empty, fallback to the homepage ID
			if ('' === $this->my_account) {
				$this->my_account = get_option('page_on_front');
			}
			
			// Include necessary plugin files and dependencies
			$this->includes();

			// Initialize core functionalities
			$this->init();
			
			// Note: Hooks are initialized automatically when CEV_Pro_Hooks is instantiated
			// Note: $this->admin->init() is called automatically via 'init' hook 
			// set in WC_Customer_Email_Verification_Admin_Pro constructor
			
			// Initialize preview-related functionalities
			$this->preview->init();
			
			// Call on_plugins_loaded directly since we're already on plugins_loaded hook
			$this->on_plugins_loaded();
		}
	}
	
	/**
	 * Include files that are needed regardless of WooCommerce status
	 * 
	 * These files are loaded early because they handle core functionality
	 * that must be available even if WooCommerce is not active.
	 *
	 * @since 1.0.0
	 */
	public function includes_for_all() {
		// Use plugin_path directly to avoid method calls during construction
		$plugin_path = $this->plugin_path;
		
		// Load functions file first (contains cev_pro_admin_settings function)
		$functions_file = $plugin_path . '/includes/cev-pro-functions.php';
		if (file_exists($functions_file)) {
			require_once $functions_file;
			// Initialize the function property to access CEV_Functions_Pro methods
			$this->function = CEV_Functions_Pro::get_instance();
		}

		// Load shared email pre-flight validator (disposable blocking + future MX / allow-blocklist rules).
		$validator_file = $plugin_path . '/includes/class-cev-email-validation.php';
		if ( file_exists( $validator_file ) ) {
			require_once $validator_file;
			if ( class_exists( 'CEV_Email_Validation' ) ) {
				CEV_Email_Validation::register();
			}
		}

		// Load AI spam/fraud risk scoring (heuristic engine that plugs into the validation chain).
		$signup_risk_file = $plugin_path . '/includes/class-cev-signup-risk.php';
		if ( file_exists( $signup_risk_file ) ) {
			require_once $signup_risk_file;
			if ( class_exists( 'CEV_Signup_Risk' ) ) {
				CEV_Signup_Risk::register();
			}
		}

		// Load bot-cluster detection (coordinated signup-burst detector).
		$bot_cluster_file = $plugin_path . '/includes/class-cev-bot-cluster.php';
		if ( file_exists( $bot_cluster_file ) ) {
			require_once $bot_cluster_file;
			if ( class_exists( 'CEV_Bot_Cluster' ) ) {
				CEV_Bot_Cluster::register();
			}
		}

		// Load cron manager (single source of truth for plugin-owned WP-Cron events).
		// Loaded BEFORE the activation closure runs so register_activation_hook()
		// can call CEV_Pro_Cron::register_schedules(). Also self-heals at init for
		// installs that gain new crons via plugin update without re-activation.
		$cron_file = $plugin_path . '/includes/cev-pro-cron.php';
		if ( file_exists( $cron_file ) ) {
			require_once $cron_file;
			if ( class_exists( 'CEV_Pro_Cron' ) ) {
				CEV_Pro_Cron::register();
			}
		}

		// Load maintenance helpers (auto-cleanup cron, stats, CSV export rows).
		$maintenance_file = $plugin_path . '/includes/cev-pro-maintenance.php';
		if ( file_exists( $maintenance_file ) ) {
			require_once $maintenance_file;
			if ( class_exists( 'CEV_Pro_Maintenance' ) ) {
				CEV_Pro_Maintenance::register();
			}
		}

		// Load admin settings class first
		$admin_settings_file = $plugin_path . '/includes/admin/cev-pro-admin-settings.php';
		if (file_exists($admin_settings_file)) {
			require_once $admin_settings_file;
		}

		// Setup checklist shown at the top of the Settings tab.
		$setup_checklist_file = $plugin_path . '/includes/admin/cev-pro-setup-checklist.php';
		if ( file_exists( $setup_checklist_file ) ) {
			require_once $setup_checklist_file;
			CEV_Pro_Setup_Checklist::get_instance();
		}
		
		// Load admin functionalities - handles plugin settings and admin interface
		$admin_file = $plugin_path . '/includes/admin/class-wc-customer-email-verification-admin.php';
		if (file_exists($admin_file)) {
			require_once $admin_file;
			if (class_exists('WC_Customer_Email_Verification_Admin_Pro')) {
				$this->admin = WC_Customer_Email_Verification_Admin_Pro::get_instance();
			}
		}
		
		// Load admin user management class
		$admin_user_file = $plugin_path . '/includes/admin/cev-pro-admin-user.php';
		if (file_exists($admin_user_file)) {
			require_once $admin_user_file;
		}

		// Load admin notice class
		$admin_notice_file = $plugin_path . '/includes/admin/cev-pro-admin-notice.php';
		if (file_exists($admin_notice_file)) {
			require_once $admin_notice_file;
		}

		// Load plugin review notice class
		$review_notice_file = $plugin_path . '/includes/admin/cev-pro-review-notice.php';
		if (file_exists($review_notice_file)) {
			require_once $review_notice_file;
		}

		// Load AI Agent OS launch notice class
		$agent_os_notice_file = $plugin_path . '/includes/admin/cev-pro-agent-os-notice.php';
		if (file_exists($agent_os_notice_file)) {
			require_once $agent_os_notice_file;
		}

		// Load installation class - handles plugin activation and setup tasks
		$install_file = $plugin_path . '/includes/cev-pro-installation.php';
		if (file_exists($install_file)) {
			require_once $install_file;
			if (class_exists('CEV_Pro_Installation')) {
				$this->install = CEV_Pro_Installation::get_instance(__FILE__);
			}
		}
	}
	
	/**
	 * Check if WooCommerce is active.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if WooCommerce is active, false otherwise.
	 */
	private function is_wc_active() {
		// Ensure the is_plugin_active function is available
		if (!function_exists('is_plugin_active')) {
			require_once ABSPATH . '/wp-admin/includes/plugin.php';
		}

		// Check if WooCommerce is active
		$is_active = is_plugin_active('woocommerce/woocommerce.php');

		// If WooCommerce is not active, defer notice to admin_notices hook
		if (false === $is_active) {
			add_action('admin_notices', array($this, 'notice_activate_wc'));
		}

		return $is_active;
	}

	/**
	 * Display an admin notice if WooCommerce is not active.
	 *
	 * @since 1.0.0
	 */
	public function notice_activate_wc() {
		// Store translated message in a variable to ensure it runs on admin_notices
		$message = sprintf(
			/* translators: %s: search WooCommerce plugin link */
			esc_html__('Please install and activate %1$sWooCommerce%2$s plugin for the Customer Email Verification PRO to work.', 'customer-email-verification'),
			'<a href="' . esc_url(admin_url('plugin-install.php?tab=search&s=WooCommerce&plugin-search-input=Search+Plugins')) . '">',
			'</a>'
		);
		?>
		<div class="error">
			<p><?php echo wp_kses_post($message); ?></p>
		</div>
		<?php
	}

	/**
	 * Include necessary plugin files and initialize classes
	 * 
	 * Loads all required class files and creates instances of each component.
	 * This method is called only when WooCommerce is active.
	 *
	 * @since 1.0.0
	 */	
	public function includes() {
		// Load signup verification process
		require_once $this->get_plugin_path() . '/includes/signup-verification/class-cev-signup-verification.php';
		$this->signup = CEV_Signup_Verification::get_instance();

		// Load Smart Form front-end shortcode (Phase 1 scaffold).
		require_once $this->get_plugin_path() . '/includes/smart-form/class-cev-smart-form.php';
		CEV_Smart_Form::get_instance();

		// Load Smart Form AJAX handlers (Phase 3: email registration + OTP verify).
		require_once $this->get_plugin_path() . '/includes/smart-form/cev-smart-form-ajax.php';
		CEV_Smart_Form_Ajax::get_instance();

		// Load the native SMS gateway (Phase 5: provider drivers + admin test-send).
		require_once $this->get_plugin_path() . '/includes/smart-form/sms/class-cev-sms-gateway.php';
		CEV_SMS_Gateway::register();

		// Load the SMS plugin compatibility layer (Phase 11: defer to SMS for
		// WooCommerce when active + compatible; native gateway is the fallback).
		require_once $this->get_plugin_path() . '/includes/smart-form/sms/class-cev-sms-compat.php';

		// Load email preview feature for front-end
		require_once $this->get_plugin_path() . '/includes/class-wc-customer-email-verification-preview-front.php';
		$this->preview = WC_Customer_Email_Verification_Preview_Pro::get_instance();
		
		// Load edit account verification class (after WooCommerce is loaded).
		require_once $this->get_plugin_path() . '/includes/edit-account/class-cev-edit-account-verification.php';
		CEV_Edit_Account_Verification::get_instance();

		// Load checkout verification class
		require_once $this->get_plugin_path() . '/includes/checkout-verification/class-cev-checkout-verification.php';
		$this->checkout_verification = CEV_Checkout_Verification::get_instance();
	
		// Load social login support for guest users
		require_once $this->get_plugin_path() . '/includes/cev-pro-social-login.php';
		$this->cev_pro_guest_user = WC_Customer_Email_Verification_Social_Login::get_instance();

		// Load login authentication handling
		require_once $this->get_plugin_path() . '/includes/login-authentication/class-cev-login-authentication.php';
		$this->cev_pro_login_authentication = WC_Customer_Email_Verification_Login_Authentication::get_instance();

		// Load Two-Factor Authentication (Authenticator App / TOTP).
		// All five classes load on every request so the AJAX endpoints +
		// `authenticate` filter are wired up regardless of which page the
		// user is on. The classes themselves bail early when the master
		// toggle is off, so the cost when 2FA is disabled is negligible.
		// CEV_QR is the server-side QR encoder (replaces the JS one).
		require_once $this->get_plugin_path() . '/includes/two-factor/class-cev-totp.php';
		require_once $this->get_plugin_path() . '/includes/two-factor/class-cev-qr.php';
		require_once $this->get_plugin_path() . '/includes/two-factor/class-cev-2fa-manager.php';
		require_once $this->get_plugin_path() . '/includes/two-factor/class-cev-2fa-ajax.php';
		require_once $this->get_plugin_path() . '/includes/two-factor/class-cev-2fa-setup.php';
		require_once $this->get_plugin_path() . '/includes/two-factor/class-cev-2fa-login.php';
		CEV_2FA_Manager::instance();
		CEV_2FA_Ajax::instance();
		CEV_2FA_Setup::instance();
		CEV_2FA_Login::instance();

		// Analytics dashboard — owns the `cev_analytics_data` AJAX endpoint
		// that powers the new Analytics tab in CEV admin.
		require_once $this->get_plugin_path() . '/includes/admin/cev-pro-admin-analytics.php';
		CEV_Pro_Admin_Analytics::instance();

		// Multi-vendor compatibility — Dokan. Inert unless Dokan is active and
		// signup verification is enabled.
		require_once $this->get_plugin_path() . '/includes/integrations/class-cev-dokan-integration.php';
		CEV_Dokan_Integration::get_instance();

		// Load checkout block functionality (only if checkout verification is enabled).
		if ( 1 == cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout', 1 ) ) {
			require_once $this->get_plugin_path() . '/includes/checkout-verification/cev-pro-checkout-block.php';
			$this->cev_pro_checkout_block = WC_Customer_Email_Verification_Checkout_Block::get_instance();
		}

		// Instantiate enqueue handler for scripts and styles
		require_once $this->get_plugin_path() . '/includes/cev-pro-enqueue.php';
		$this->enqueue = new CEV_Enqueue_Pro();

		// Load hooks class - handles WordPress hooks and filters for plugin functionality
		require_once $this->get_plugin_path() . '/includes/cev-pro-hooks.php';
		$this->hooks = new CEV_Pro_Hooks($this);
	}
	
	/**
	 * Initialize plugin hooks and filters
	 * 
	 * Sets up plugin-specific hooks including action links and activation hooks.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		// Prevent duplicate registration of action links filter
		if ( ! self::$action_links_registered ) {
		// Add custom action links to the plugin page (Settings link)
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this , 'my_plugin_action_links' ));
			self::$action_links_registered = true;
		}
	
		// Register activation hook to handle plugin activation tasks
		register_activation_hook( __FILE__, array( $this,'on_activation_cev' ) );
	}
	/**
	 * Handle actions on plugin activation
	 * 
	 * Deactivates previous versions of the plugin and sets a transient notice.
	 * This prevents conflicts when multiple versions are installed.
	 *
	 * @since 2.4
	 */
	public function on_activation_cev() {
		// Deactivate older versions of the Customer Email Verification plugin
		deactivate_plugins( 'customer-email-verification-for-woocommerce/customer-email-verification-for-woocommerce.php' );
		deactivate_plugins( 'customer-email-verification-pro/customer-email-verification-pro.php' );

		// Register the login-authentication endpoint then flush so the URL works immediately.
		add_rewrite_endpoint( 'login-authentication', EP_PAGES );
		flush_rewrite_rules();

		// Set a transient notice for the free version (shown for 3 seconds)
		set_transient( 'free_cev_plugin', 'notice', 3 );

		// Prevent showing the plugin notice again
		update_option( 'cev_pro_plugin_notice_ignore', 'true' );
	}

	/**
	 * Add plugin action links.
	 *
	 * Add a link to the settings page on the plugins.php page.
	 *
	 * @since 1.0.0
	 *
	 * @param  array  $links List of existing plugin action links.
	 * @return array         List of modified plugin action links.
	 */
	public function my_plugin_action_links( $links ) {
		// Prevent duplicate Settings links
		$settings_url = esc_url( admin_url( '/admin.php?page=customer-email-verification-for-woocommerce' ) );
		$settings_text = esc_html__( 'Settings', 'customer-email-verification' );
		$settings_link = '<a href="' . $settings_url . '">' . $settings_text . '</a>';
		
		// Check if Settings link already exists to prevent duplicates
		$link_exists = false;
		foreach ( $links as $link ) {
			if ( false !== strpos( $link, $settings_url ) ) {
				$link_exists = true;
				break;
			}
		}
		
		if ( ! $link_exists ) {
			$links = array_merge( array( $settings_link ), $links );
		}
		
		return $links;
	}

	/**
	 * Check if the specified user is an administrator
	 * 
	 * Used to skip email verification requirements for admin users,
	 * as they typically don't need to verify their email addresses.
	 *
	 * @since 1.0.0
	 *
	 * @param int $user_id The WordPress user ID to check
	 * @return bool True if user is an administrator, false otherwise
	 */
	public function is_admin_user( $user_id ) {
		// Get user object by ID
		$user = get_user_by( 'id', $user_id );
		
		// Return false if user doesn't exist
		if ( !$user ) {
			return false;
		}
		
		// Get user roles
		$roles = $user->roles;
		
		// Check if user has administrator role
		if ( in_array( 'administrator', (array) $roles ) ) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Perform actions when all plugins are loaded.
	 */
	public function on_plugins_loaded() {
		// Allow custom HTML tags in email content (moved to functions file)
		if ( isset( cev_pro()->function ) ) {
			add_filter('wp_kses_allowed_html', array(cev_pro()->function, 'my_allowed_tags'));

			// Allow safe CSS styles in emails
			add_filter('safe_style_css', array(cev_pro()->function, 'safe_style_css_callback'), 10, 1);
		}

		// Defer customizer loading to init
		add_action('init', array($this, 'load_customizer'));
	}

	/**
	 * Load customizer files on init to avoid early translation calls.
	 */
	public function load_customizer() {
		require_once $this->get_plugin_path() . '/includes/customizer/cev-customizer.php';
		$this->customizer = CEV_Customizer::get_instance();

		require_once $this->get_plugin_path() . '/includes/customizer/cev-customizer-options.php';
		$this->customizer_options = CEV_Customizer_Options::get_instance();

		// Smart Form gets its own top-level Customizer panel (Phase 8).
		require_once $this->get_plugin_path() . '/includes/customizer/cev-customizer-smart-form.php';
		CEV_Customizer_Smart_Form::get_instance();
	}

	/**
	 * Load the plugin text domain for translations.
	 */
	public function load_pro_textdomain() {
		// phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Self-hosted distribution (WooCommerce Marketplace / zorem.com); explicit load keeps bundled /lang translations reliable.
		load_plugin_textdomain('customer-email-verification', false, dirname(plugin_basename($this->plugin_file)) . '/lang/');
	}
	
	/**
	 * Gets the absolute plugin path without a trailing slash
	 * 
	 * Example: /path/to/wp-content/plugins/plugin-directory
	 *
	 * @since 1.0.0
	 *
	 * @return string Plugin path
	 */
	public function get_plugin_path() {
		if (isset($this->plugin_path)) {
			return $this->plugin_path;
		}

		$this->plugin_path = untrailingslashit(plugin_dir_path(__FILE__));

		return $this->plugin_path;
	}
	
	/**
	 * Gets the absolute plugin URL
	 * 
	 * Example: https://your-site.com/wp-content/plugins/plugin-directory/
	 *
	 * @since 1.0.0
	 *
	 * @return string The absolute plugin URL
	 */	
	public function plugin_dir_url() {
		return plugin_dir_url( __FILE__ );
	}

}

/**
* Returns an instance of customer_email_verification_pro.
*
* @since 1.0.0
* @version 1.0.0
*
* @return Customer_Email_Verification_Pro
*/
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Plugin-owned global function; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
function cev_pro() {
	// The constructor publishes self::$instance on its first line, so a
	// re-entrant call made while the object is still being built returns that
	// same object rather than starting another one.
	if ( null === Customer_Email_Verification_Pro::$instance ) {
		new Customer_Email_Verification_Pro();
	}

	return Customer_Email_Verification_Pro::$instance;
}

/**
* Register this class globally.
*
* Backward compatibility.
*/
cev_pro();
/**
 * Declare compatibility for custom order tables with WooCommerce.
 *
 * Ensures that the plugin declares compatibility with WooCommerce's custom order tables feature.
 */
add_action('before_woocommerce_init', function() {
	// Check if WooCommerce FeaturesUtil class is available
	if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
		// Declare compatibility with the custom order tables feature
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
	}
});

if ( ! function_exists( 'zorem_tracking' ) ) {
	function zorem_tracking() {
		require_once dirname( __FILE__ ) . '/zorem-tracking/zorem-tracking.php';
		$plugin_name             = 'CEV Pro (WC.com)';
		$plugin_slug             = 'cev-pro-wccom';
		$user_id                 = '1';
		$setting_page_type       = 'top-level';
		$setting_page_location   = 'A custom top-level admin menu (admin.php)';
		$parent_menu_type        = '';
		$menu_slug               = 'customer-email-verification-for-woocommerce';
		$plugin_id               = '22';
		$zorem_tracking          = WC_Trackers::get_instance( $plugin_name, $plugin_slug, $user_id,
			$setting_page_type, $setting_page_location, $parent_menu_type, $menu_slug, $plugin_id );

		return $zorem_tracking;
	}
	zorem_tracking();
}
