<?php
/**
 * Smart Form — front-end shortcode module.
 *
 * Registers the [cev_smart_form] shortcode that renders the Smart Form on any
 * page, and exposes the gating + JS config the enqueue layer needs. Asset
 * loading itself lives in CEV_Enqueue_Pro (cev-pro-enqueue.php) — this class
 * stays presentation/logic only. Phase 1 scaffold: the shortcode is inert
 * until the merchant selects the Smart Form signup type, and it renders only a
 * placeholder container. The Login + Register markup lands in later phases.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Smart_Form Class.
 *
 * Singleton. Owns the shortcode + the front-end config; the CSS/JS are enqueued
 * by CEV_Enqueue_Pro::smart_form_enqueue() using the helpers exposed here.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Smart_Form {

	/**
	 * Shortcode tag.
	 *
	 * @var string
	 */
	const SHORTCODE = 'cev_smart_form';

	/**
	 * Transient key caching whether any published page hosts the shortcode.
	 *
	 * @var string
	 */
	const SHORTCODE_PRESENCE_TRANSIENT = 'cev_smart_form_shortcode_present';

	/**
	 * Single instance of this class.
	 *
	 * @var CEV_Smart_Form|null
	 */
	private static $instance = null;

	/**
	 * Template slug currently being rendered — set in render(), read by customizer().
	 *
	 * @var string
	 */
	private $current_render_template = '';

	/**
	 * Retrieve the singleton instance.
	 *
	 * @since 2.10.0
	 * @return CEV_Smart_Form
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — register the shortcode.
	 *
	 * @since 2.10.0
	 */
	public function __construct() {
		add_shortcode( self::SHORTCODE, array( $this, 'render_shortcode' ) );

		// Replace the WooCommerce My Account login/register form with the Smart
		// Form when takeover is enabled (front-end, logged-out visitors only).
		add_filter( 'woocommerce_locate_template', array( $this, 'maybe_take_over_myaccount_form' ), 20, 3 );

		// Purge page caches when the merchant switches the signup form type so a
		// cached page never shows the previous form.
		add_action( 'update_option_cev_pro_admin_settings', array( $this, 'maybe_purge_on_form_type_change' ), 10, 2 );

		// Background handler for the deferred cache flush (scheduled by
		// maybe_purge_on_form_type_change) so the save request never blocks.
		add_action( 'cev_smart_form_purge_caches', array( $this, 'purge_caches' ) );

		// Nudge the merchant if Smart Form is selected but surfaced nowhere.
		add_action( 'admin_notices', array( $this, 'maybe_render_placement_notice' ) );
	}

	/**
	 * Whether Smart Form is the active signup form type.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_smart_form_active() {
		return 'smart' === (string) cev_pro()->function->cev_pro_admin_settings( 'cev_signup_form_type', 'woocommerce' );
	}

	/**
	 * Whether the queried singular post contains the shortcode. Used by the
	 * enqueue layer to load the Smart Form assets only where they are needed.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function page_has_shortcode() {
		if ( ! is_singular() ) {
			return false;
		}

		$post = get_post();

		return ( $post instanceof WP_Post ) && has_shortcode( $post->post_content, self::SHORTCODE );
	}

	/**
	 * Registration password policy for the Smart Form.
	 *
	 * Read by BOTH the server validator ( CEV_Smart_Form_Ajax::is_strong_password )
	 * and the browser ( localized into the cev_smart_form config for smart-form.js )
	 * so the two never drift. require_strong defaults to true for installs that
	 * predate the setting, preserving the historical strong-password behaviour.
	 *
	 * @since 2.10.0
	 * @return array Policy with 'require_strong' bool and 'min_length' int.
	 */
	public static function password_policy() {
		$require_strong = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_require_strong_password', 1 ) );
		$min_length     = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_password_min_length', 8 );

		if ( 4 > $min_length ) {
			$min_length = 4;
		} elseif ( 64 < $min_length ) {
			$min_length = 64;
		}

		return array(
			'require_strong' => $require_strong,
			'min_length'     => $min_length,
		);
	}

	/**
	 * Customer-facing message shown when a password fails the current policy.
	 *
	 * Built once here so the browser hint ( localized ) and the server AJAX error
	 * stay identical, reflecting whether the strong rule is on and the configured
	 * minimum length.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public static function password_error_message() {
		$policy = self::password_policy();

		if ( $policy['require_strong'] ) {
			return sprintf(
				/* translators: %d: minimum number of characters. */
				__( 'Please choose a stronger password: at least %d characters, including upper and lower case letters, a number, and a symbol.', 'customer-email-verification' ),
				$policy['min_length']
			);
		}

		return sprintf(
			/* translators: %d: minimum number of characters. */
			__( 'Please choose a password with at least %d characters.', 'customer-email-verification' ),
			$policy['min_length']
		);
	}

	/**
	 * Build the non-sensitive front-end config consumed by smart-form.js.
	 *
	 * SMS credentials are NEVER exposed here.
	 *
	 * @since 2.10.0
	 * @return array
	 */
	public function get_config() {
		$settings    = cev_pro()->function;
		$code_length = (int) $settings->cev_pro_admin_settings( 'cev_verification_code_length', 4 );

		$sms_ready       = class_exists( 'CEV_SMS_Compat' ) ? CEV_SMS_Compat::has_backend() : false;
		$login_methods   = self::login_methods_for_form( $sms_ready );

		return array(
			'template'     => (string) $settings->cev_pro_admin_settings( 'cev_signup_smart_template', 'template1' ),
			'reg_method'   => (string) $settings->cev_pro_admin_settings( 'cev_smart_reg_method', 'email' ),
			// Primary method (first enabled) kept for backward-compatible checks;
			// login_methods is the full enabled set the login tabs render from.
			'login_method' => isset( $login_methods[0] ) ? $login_methods[0] : 'password',
			'login_methods' => $login_methods,
			'sms_ready'    => $sms_ready,
			'otp_length'   => ( 6 === $code_length ) ? 6 : 4,
			'ajax_url'     => admin_url( 'admin-ajax.php' ),
			'nonce'        => wp_create_nonce( 'cev_smart_form_nonce' ),
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			'resend_delay' => (int) apply_filters( 'cev_smart_form_resend_delay', 30 ),
			'intl_phone'   => array(
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
				'enabled'             => (bool) apply_filters( 'cev_smart_form_intl_phone', true ),
				'utils_url'           => cev_pro()->plugin_dir_url() . 'assets/intl-tel-input/js/utils.js',
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
				'initial_country'     => strtolower( (string) apply_filters( 'cev_smart_form_intl_initial_country', $this->store_country() ) ),
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
				'preferred_countries' => array_values( array_map( 'strtolower', (array) apply_filters( 'cev_smart_form_intl_preferred_countries', array( $this->store_country() ) ) ) ),
			),
			'i18n'         => array(
				/* translators: %s: the form field label, e.g. "Email address". */
				'field_required' => __( '%s is required.', 'customer-email-verification' ),
				'email_invalid'  => __( 'Enter a valid email address.', 'customer-email-verification' ),
				'phone_invalid'  => __( 'Enter a valid phone number.', 'customer-email-verification' ),
				'generic_error'  => __( 'Something went wrong. Please try again.', 'customer-email-verification' ),
				'creating'       => __( 'Creating your account…', 'customer-email-verification' ),
				'resend'         => __( 'Resend code', 'customer-email-verification' ),
				/* translators: %d: seconds remaining before the code can be resent. */
				'resend_in'      => __( 'Resend code in %d s', 'customer-email-verification' ),
				'password_weak'  => __( 'Use at least 8 characters with upper & lower case, a number, and a symbol.', 'customer-email-verification' ),
				'pw_weak'        => __( 'Weak', 'customer-email-verification' ),
				'pw_medium'      => __( 'Medium', 'customer-email-verification' ),
				'pw_strong'      => __( 'Strong', 'customer-email-verification' ),
				'pw_show'        => __( 'Show password', 'customer-email-verification' ),
				'pw_hide'        => __( 'Hide password', 'customer-email-verification' ),
				'please_wait'    => __( 'Please wait…', 'customer-email-verification' ),
			),
		);
	}

	/**
	 * The valid Smart Form login methods, in canonical display order.
	 *
	 * @since 2.11.0
	 * @return string[]
	 */
	public static function login_method_keys() {
		return array( 'password', 'email_otp', 'phone_otp' );
	}

	/**
	 * Parse the stored (comma-separated) login-method value into a clean,
	 * de-duplicated, canonically-ordered list. Never returns an empty set —
	 * falls back to Password so a store can always sign in.
	 *
	 * @since 2.11.0
	 * @param string $raw Stored value (e.g. "password,email_otp").
	 * @return string[]
	 */
	public static function parse_login_methods( $raw ) {
		$parts   = array_filter( array_map( 'trim', explode( ',', (string) $raw ) ) );
		// array_intersect keeps the order of the first array (canonical order).
		$methods = array_values( array_intersect( self::login_method_keys(), $parts ) );
		if ( empty( $methods ) ) {
			$methods = array( 'password' );
		}
		return $methods;
	}

	/**
	 * The login methods currently enabled by the admin (raw enabled set).
	 *
	 * @since 2.11.0
	 * @return string[]
	 */
	public static function enabled_login_methods() {
		$raw = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_login_method', 'password' );
		return self::parse_login_methods( $raw );
	}

	/**
	 * The login methods to actually render on the login form.
	 *
	 * Same as the enabled set, except Phone OTP is only usable when an SMS
	 * backend is available; when it isn't, it is replaced by Email OTP (the
	 * documented fallback) so the customer can still receive a code.
	 *
	 * @since 2.11.0
	 * @param bool $sms_ready Whether an SMS gateway backend is available.
	 * @return string[]
	 */
	public static function login_methods_for_form( $sms_ready ) {
		$methods = self::enabled_login_methods();

		if ( ! $sms_ready && in_array( 'phone_otp', $methods, true ) ) {
			// Drop Phone OTP and make sure Email OTP is offered as the fallback.
			$methods = array_values(
				array_diff( $methods, array( 'phone_otp' ) )
			);
			if ( ! in_array( 'email_otp', $methods, true ) ) {
				$methods[] = 'email_otp';
			}
			// Re-apply canonical order.
			$methods = array_values( array_intersect( self::login_method_keys(), $methods ) );
		}

		if ( empty( $methods ) ) {
			$methods = array( 'password' );
		}
		return $methods;
	}

	/* ---------- Custom fields (developer filter, no admin UI) ---------- */

	/**
	 * The register-form slots a custom field can target, in render order.
	 * A field's 'placement' picks one of these; order within a slot follows
	 * the field's 'priority'.
	 *
	 * @since 3.0.2
	 * @return string[]
	 */
	public static function custom_field_slots() {
		return array( 'register_top', 'after_email', 'after_phone', 'after_password', 'before_submit' );
	}

	/**
	 * Input types a custom field may use.
	 *
	 * @since 3.0.2
	 * @return string[]
	 */
	public static function custom_field_types() {
		return array( 'text', 'email', 'tel', 'url', 'number', 'date', 'textarea', 'select', 'radio', 'checkbox_group', 'acceptance' );
	}

	/**
	 * Keys reserved by the form's built-in inputs — a custom field may not use
	 * them (would clash with the register payload).
	 *
	 * @since 3.0.2
	 * @return string[]
	 */
	public static function custom_field_reserved_keys() {
		return array( 'email', 'password', 'phone', 'login', 'otp', 'nonce', 'action', 'channel', 'remember' );
	}

	/**
	 * Developer-registered custom fields for the Smart Form register step.
	 *
	 * There is no admin UI: a developer adds fields with the
	 * `cev_smart_form_custom_fields` filter. Each entry is normalised +
	 * validated here so the renderer and the AJAX validator share one clean,
	 * safe definition set. The array KEY is the field key, which is ALSO the
	 * user-meta key the value is saved to — first_name / last_name / billing_*
	 * are all user-meta keys, so naming the field is all a developer does.
	 *
	 * @since 3.0.2
	 * @return array Keyed by field key, sorted by placement priority.
	 */
	public static function get_custom_fields() {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$raw = apply_filters( 'cev_smart_form_custom_fields', array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$slots    = self::custom_field_slots();
		$types    = self::custom_field_types();
		$reserved = self::custom_field_reserved_keys();
		$fields   = array();

		foreach ( $raw as $raw_key => $def ) {
			if ( ! is_array( $def ) ) {
				continue;
			}
			$key = sanitize_key( (string) $raw_key );
			if ( '' === $key || in_array( $key, $reserved, true ) ) {
				continue;
			}

			$type = isset( $def['type'] ) ? sanitize_key( $def['type'] ) : 'text';
			if ( ! in_array( $type, $types, true ) ) {
				$type = 'text';
			}

			$placement = isset( $def['placement'] ) ? sanitize_key( $def['placement'] ) : 'before_submit';
			if ( ! in_array( $placement, $slots, true ) ) {
				$placement = 'before_submit';
			}

			$fields[ $key ] = array(
				'key'         => $key,
				'label'       => isset( $def['label'] ) ? (string) $def['label'] : $key,
				'type'        => $type,
				'required'    => ! empty( $def['required'] ),
				'options'     => ( isset( $def['options'] ) && is_array( $def['options'] ) ) ? $def['options'] : array(),
				'placeholder' => isset( $def['placeholder'] ) ? (string) $def['placeholder'] : '',
				'placement'   => $placement,
				'priority'    => isset( $def['priority'] ) ? (int) $def['priority'] : 10,
			);
		}

		uasort(
			$fields,
			function ( $a, $b ) {
				if ( $a['priority'] === $b['priority'] ) {
					return 0;
				}
				return ( $a['priority'] < $b['priority'] ) ? -1 : 1;
			}
		);

		return $fields;
	}

	/**
	 * The allowed submit VALUES for a choice field (select / radio /
	 * checkbox_group). Supports list options ( array( 'A', 'B' ) ) and
	 * associative options ( array( 'us' => 'United States' ) ).
	 *
	 * @since 3.0.2
	 * @param array $field A normalised field definition.
	 * @return string[]
	 */
	public static function custom_field_option_values( $field ) {
		$values = array();
		if ( empty( $field['options'] ) || ! is_array( $field['options'] ) ) {
			return $values;
		}
		foreach ( $field['options'] as $opt_key => $opt_label ) {
			$values[] = is_string( $opt_key ) ? (string) $opt_key : (string) $opt_label;
		}
		return $values;
	}

	/**
	 * Allowed HTML in a custom-field label — lets the acceptance (T&C) label
	 * carry a single link, nothing script-y.
	 *
	 * @since 3.0.2
	 * @return array
	 */
	private static function custom_field_label_tags() {
		return array(
			'a'      => array(
				'href'   => array(),
				'target' => array(),
				'rel'    => array(),
				'class'  => array(),
			),
			'br'     => array(),
			'strong' => array(),
			'em'     => array(),
			'span'   => array( 'class' => array() ),
		);
	}

	/**
	 * Echo the custom fields assigned to a slot, in priority order. Called from
	 * the register-fields template at each slot anchor.
	 *
	 * @since 3.0.2
	 * @param string $slot Slot name (see custom_field_slots()).
	 * @return void
	 */
	public function render_custom_fields( $slot ) {
		$slot = (string) $slot;
		foreach ( self::get_custom_fields() as $field ) {
			if ( $field['placement'] === $slot ) {
				$this->render_custom_field( $field );
			}
		}
	}

	/**
	 * Dispatch one custom field to the renderer for its type.
	 *
	 * @since 3.0.2
	 * @param array $field Normalised field definition.
	 * @return void
	 */
	private function render_custom_field( $field ) {
		$id   = 'cev-sf-cf-' . $field['key'];
		$name = 'cev_cf[' . $field['key'] . ']';
		$req  = ! empty( $field['required'] );
		$err  = $id . '-error';

		if ( 'acceptance' === $field['type'] ) {
			$this->render_custom_acceptance( $field, $id, $name, $req, $err );
			return;
		}
		if ( 'radio' === $field['type'] || 'checkbox_group' === $field['type'] ) {
			$this->render_custom_choice( $field, $id, $name, $req, $err );
			return;
		}
		if ( 'select' === $field['type'] ) {
			$this->render_custom_select( $field, $id, $name, $req, $err );
			return;
		}
		if ( 'textarea' === $field['type'] ) {
			$this->render_custom_textarea( $field, $id, $name, $req, $err );
			return;
		}
		$this->render_custom_input( $field, $id, $name, $req, $err );
	}

	/**
	 * Render the label + required/optional marker for a custom field.
	 *
	 * @since 3.0.2
	 * @param array  $field Field definition.
	 * @param string $for   Input id to bind to (empty for a group label).
	 * @return void
	 */
	private function render_custom_label( $field, $for = '' ) {
		if ( '' !== $for ) {
			echo '<label class="cev-sf-label" for="' . esc_attr( $for ) . '">';
		} else {
			echo '<span class="cev-sf-label">';
		}
		echo wp_kses( $field['label'], self::custom_field_label_tags() );
		if ( ! empty( $field['required'] ) ) {
			echo ' <span class="cev-sf-req" aria-hidden="true">*</span>';
		} else {
			echo ' <span class="cev-sf-optional">' . esc_html__( '(optional)', 'customer-email-verification' ) . '</span>';
		}
		if ( '' !== $for ) {
			echo '</label>';
		} else {
			echo '</span>';
		}
	}

	/**
	 * Render a single-line / typed custom input (text, email, tel, url, number, date).
	 *
	 * @since 3.0.2
	 * @param array  $field Field definition.
	 * @param string $id    Input id.
	 * @param string $name  Input name.
	 * @param bool   $req   Whether required.
	 * @param string $err   Error-span id.
	 * @return void
	 */
	private function render_custom_input( $field, $id, $name, $req, $err ) {
		$type_map  = array(
			'text'   => 'text',
			'email'  => 'email',
			'tel'    => 'tel',
			'url'    => 'url',
			'number' => 'number',
			'date'   => 'date',
		);
		$html_type = isset( $type_map[ $field['type'] ] ) ? $type_map[ $field['type'] ] : 'text';

		echo '<div class="cev-sf-field cev-sf-field--custom">';
		$this->render_custom_label( $field, $id );
		echo '<input type="' . esc_attr( $html_type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="cev-sf-input"';
		if ( '' !== (string) $field['placeholder'] ) {
			echo ' placeholder="' . esc_attr( $field['placeholder'] ) . '"';
		}
		if ( $req ) {
			echo ' required aria-required="true"';
		}
		echo ' aria-describedby="' . esc_attr( $err ) . '" />';
		echo '<span class="cev-sf-error" id="' . esc_attr( $err ) . '" aria-live="polite"></span>';
		echo '</div>';
	}

	/**
	 * Render a multi-line custom textarea.
	 *
	 * @since 3.0.2
	 * @param array  $field Field definition.
	 * @param string $id    Input id.
	 * @param string $name  Input name.
	 * @param bool   $req   Whether required.
	 * @param string $err   Error-span id.
	 * @return void
	 */
	private function render_custom_textarea( $field, $id, $name, $req, $err ) {
		echo '<div class="cev-sf-field cev-sf-field--custom">';
		$this->render_custom_label( $field, $id );
		echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="cev-sf-input" rows="4"';
		if ( '' !== (string) $field['placeholder'] ) {
			echo ' placeholder="' . esc_attr( $field['placeholder'] ) . '"';
		}
		if ( $req ) {
			echo ' required aria-required="true"';
		}
		echo ' aria-describedby="' . esc_attr( $err ) . '"></textarea>';
		echo '<span class="cev-sf-error" id="' . esc_attr( $err ) . '" aria-live="polite"></span>';
		echo '</div>';
	}

	/**
	 * Render a custom dropdown.
	 *
	 * @since 3.0.2
	 * @param array  $field Field definition.
	 * @param string $id    Input id.
	 * @param string $name  Input name.
	 * @param bool   $req   Whether required.
	 * @param string $err   Error-span id.
	 * @return void
	 */
	private function render_custom_select( $field, $id, $name, $req, $err ) {
		echo '<div class="cev-sf-field cev-sf-field--custom">';
		$this->render_custom_label( $field, $id );
		echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="cev-sf-input"';
		if ( $req ) {
			echo ' required aria-required="true"';
		}
		echo ' aria-describedby="' . esc_attr( $err ) . '">';
		echo '<option value="">' . esc_html__( 'Choose…', 'customer-email-verification' ) . '</option>';
		foreach ( (array) $field['options'] as $opt_key => $opt_label ) {
			$val = is_string( $opt_key ) ? (string) $opt_key : (string) $opt_label;
			echo '<option value="' . esc_attr( $val ) . '">' . esc_html( (string) $opt_label ) . '</option>';
		}
		echo '</select>';
		echo '<span class="cev-sf-error" id="' . esc_attr( $err ) . '" aria-live="polite"></span>';
		echo '</div>';
	}

	/**
	 * Render a radio group or a checkbox group.
	 *
	 * @since 3.0.2
	 * @param array  $field Field definition.
	 * @param string $id    Base id.
	 * @param string $name  Base name.
	 * @param bool   $req   Whether required.
	 * @param string $err   Error-span id.
	 * @return void
	 */
	private function render_custom_choice( $field, $id, $name, $req, $err ) {
		$is_radio   = ( 'radio' === $field['type'] );
		$input_type = $is_radio ? 'radio' : 'checkbox';
		$input_name = $is_radio ? $name : $name . '[]';

		echo '<div class="cev-sf-field cev-sf-field--custom cev-sf-field--choice">';
		$this->render_custom_label( $field );
		echo '<div class="cev-sf-choice-group"' . ( $is_radio ? ' role="radiogroup"' : '' ) . '>';

		$i = 0;
		foreach ( (array) $field['options'] as $opt_key => $opt_label ) {
			$val    = is_string( $opt_key ) ? (string) $opt_key : (string) $opt_label;
			$opt_id = $id . '-' . $i;
			echo '<label class="cev-sf-choice" for="' . esc_attr( $opt_id ) . '">';
			echo '<input type="' . esc_attr( $input_type ) . '" id="' . esc_attr( $opt_id ) . '" name="' . esc_attr( $input_name ) . '" value="' . esc_attr( $val ) . '"';
			// Mark only the first control required so the JS validates the group once.
			if ( $req && 0 === $i ) {
				echo ' required aria-required="true"';
			}
			echo ' /> <span>' . esc_html( (string) $opt_label ) . '</span>';
			echo '</label>';
			++$i;
		}

		echo '</div>';
		echo '<span class="cev-sf-error" id="' . esc_attr( $err ) . '" aria-live="polite"></span>';
		echo '</div>';
	}

	/**
	 * Render a single acceptance checkbox (the Terms & Conditions type). The
	 * label may carry one link (see custom_field_label_tags()).
	 *
	 * @since 3.0.2
	 * @param array  $field Field definition.
	 * @param string $id    Input id.
	 * @param string $name  Input name.
	 * @param bool   $req   Whether required.
	 * @param string $err   Error-span id.
	 * @return void
	 */
	private function render_custom_acceptance( $field, $id, $name, $req, $err ) {
		echo '<div class="cev-sf-field cev-sf-field--custom cev-sf-field--acceptance">';
		echo '<label class="cev-sf-check" for="' . esc_attr( $id ) . '">';
		echo '<input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1"';
		if ( $req ) {
			echo ' required aria-required="true"';
		}
		echo ' aria-describedby="' . esc_attr( $err ) . '" />';
		echo '<span class="cev-sf-check__label cev-sf-label">';
		echo wp_kses( $field['label'], self::custom_field_label_tags() );
		if ( $req ) {
			echo ' <span class="cev-sf-req" aria-hidden="true">*</span>';
		}
		echo '</span>';
		echo '</label>';
		echo '<span class="cev-sf-error" id="' . esc_attr( $err ) . '" aria-live="polite"></span>';
		echo '</div>';
	}

	/**
	 * The store's base country as a lowercase ISO code — the intl-tel-input
	 * default country for the phone field. Falls back to 'us'.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	private function store_country() {
		$country = '';
		if ( function_exists( 'wc_get_base_location' ) ) {
			$base    = wc_get_base_location();
			$country = isset( $base['country'] ) ? (string) $base['country'] : '';
		}
		return '' !== $country ? strtolower( $country ) : 'us';
	}

	/**
	 * Storage-key prefix for the currently-rendering template's customizer settings.
	 *
	 * @since 2.10.0
	 * @return string  E.g. 'cev_sf_t1_' for Template 1.
	 */
	private function settings_prefix() {
		$t   = $this->current_render_template;
		if ( '' === $t ) {
			$t = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_signup_smart_template', 'template1' );
		}
		$map = array( 'template1' => 't1', 'template2' => 't2', 'template3' => 't3', 'template4' => 't4' );
		return 'cev_sf_' . ( isset( $map[ $t ] ) ? $map[ $t ] : 't1' ) . '_';
	}

	/**
	 * Read a template-specific customizer value.
	 *
	 * @since 2.10.0
	 * @param string $field   Field name without template prefix, e.g. 'heading'.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function customizer( $field, $default = '' ) {
		return cev_pro()->function->cev_pro_customizer_settings( $this->settings_prefix() . $field, $default );
	}

	/**
	 * Brand title markup for the form header — the Customizer Heading text,
	 * falling back to the store name when the Heading is empty (Phase 8). There
	 * is no logo upload; this slot always shows the Heading.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public function brand_title_html() {
		$heading = trim( (string) $this->customizer( 'heading', '' ) );
		if ( '' === $heading ) {
			$heading = get_bloginfo( 'name' );
		}
		return esc_html( $heading );
	}

	/**
	 * Scoped <style> block mapping the Customizer Smart Form options onto CSS
	 * variables: the brand colour (all templates) plus the brand-panel
	 * background, text colour and vertical alignment (templates 2 & 3).
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public function brand_color_inline_style() {
		$color = sanitize_hex_color( (string) $this->customizer( 'brand_color', '#4f46e5' ) );
		if ( empty( $color ) ) {
			$color = '#4f46e5';
		}

		$vars = array(
			'--cev-sf-brand'       => $color,
			'--cev-sf-brand-hover' => $this->darken_hex( $color, 0.85 ),
		);

		// Brand-panel background — always solid colour.
		$solid = sanitize_hex_color( (string) $this->customizer( 'panel_bg_solid', '' ) );
		$vars['--cev-sf-panel-bg'] = $solid ? $solid : $color;

		// Panel text colour.
		$text = sanitize_hex_color( (string) $this->customizer( 'panel_text_color', '' ) );
		if ( $text ) {
			$vars['--cev-sf-panel-text'] = $text;
		}

		// Button font colour (--cev-sf-on-brand; defaults to #ffffff in CSS).
		$btn_text = sanitize_hex_color( (string) $this->customizer( 'btn_font_color', '' ) );
		if ( $btn_text ) {
			$vars['--cev-sf-on-brand'] = $btn_text;
		}

		// Panel vertical alignment — always centred.
		$vars['--cev-sf-panel-justify'] = 'center';

		$css = '';
		foreach ( $vars as $name => $value ) {
			$css .= $name . ':' . $value . ';';
		}

		return '<style>.cev-smart-form{' . $css . '}</style>';
	}

	/**
	 * Optional brand-panel extras (tagline + benefit bullets) shown under the
	 * title on templates 2 & 3. Returns '' when both are empty.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public function brand_panel_extras_html() {
		$tagline     = trim( (string) $this->customizer( 'panel_tagline', '' ) );
		$bullets_raw = (string) $this->customizer( 'panel_bullets', '' );
		$bullets     = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $bullets_raw ) ) );

		ob_start();

		if ( '' !== $tagline ) {
			echo '<p class="cev-sf-brand__tagline">' . esc_html( $tagline ) . '</p>';
		}

		if ( ! empty( $bullets ) ) {
			echo '<ul class="cev-sf-brand__bullets">';
			foreach ( $bullets as $bullet ) {
				echo '<li class="cev-sf-brand__bullet">' . esc_html( $bullet ) . '</li>';
			}
			echo '</ul>';
		}

		return ob_get_clean();
	}

	/**
	 * Darken a hex colour by a factor (1.0 = unchanged, 0 = black). Used for the
	 * brand colour's hover shade.
	 *
	 * @since 2.10.0
	 * @param string $hex    Hex colour (#rgb or #rrggbb).
	 * @param float  $factor Multiplier applied to each channel.
	 * @return string
	 */
	private function darken_hex( $hex, $factor = 0.85 ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) ) {
			return '#' . $hex;
		}
		$r = (int) round( hexdec( substr( $hex, 0, 2 ) ) * $factor );
		$g = (int) round( hexdec( substr( $hex, 2, 2 ) ) * $factor );
		$b = (int) round( hexdec( substr( $hex, 4, 2 ) ) * $factor );
		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	/**
	 * Render the [cev_smart_form] shortcode.
	 *
	 * When Smart Form is the active signup type, renders the selected template's
	 * Login + Register markup. When the standard WooCommerce form is active, the
	 * shortcode falls back to the WC login/register form (logged-out) so a page
	 * built around the shortcode never goes blank after a form-type switch.
	 *
	 * @since 2.10.0
	 * @param array|string $atts Shortcode attributes (unused for now).
	 * @return string
	 */
	public function render_shortcode( $atts = array() ) {
		unset( $atts );

		// Nothing to show someone who is already signed in. Mirrors
		// wc_login_form_fallback() so both form types behave identically.
		// render() itself stays unguarded — the Customizer preview calls it
		// directly while the merchant is logged in.
		if ( is_user_logged_in() ) {
			return '';
		}

		if ( ! $this->is_smart_form_active() ) {
			return $this->wc_login_form_fallback();
		}

		return $this->render();
	}

	/**
	 * Build the Smart Form markup for the selected template.
	 *
	 * Shared by the shortcode and the My Account takeover so both render the
	 * identical form. The Customizer preview passes a template override so a
	 * merchant can preview any of the four templates.
	 *
	 * @since 2.10.0
	 * @param string $template_override Optional template slug to force (preview).
	 * @return string
	 */
	public function render( $template_override = '' ) {
		$cev_config = $this->get_config();
		$allowed    = array( 'template1', 'template2', 'template3', 'template4' );
		$template   = in_array( $template_override, $allowed, true )
			? $template_override
			: ( in_array( $cev_config['template'], $allowed, true ) ? $cev_config['template'] : 'template1' );
		$view       = __DIR__ . '/views/' . str_replace( 'template', 'template-', $template ) . '.php';

		if ( ! file_exists( $view ) ) {
			return '';
		}

		$this->current_render_template = $template;

		ob_start();
		// $view resolves to one of the four allowlisted template-N.php files
		// (validated against $allowed above) — never user-controlled input.
		include $view; // nosemgrep: audit.php.lang.security.file.inclusion-arg -- Path built only from the template1-4 allowlist, not request input.

		// Reuse the SAME signup verification popup (#otp-popup) for the Smart
		// Form OTP step — driven by smart-form.js against the cev_smart_* AJAX
		// endpoints. require_once dedupes with the classic render hooked to
		// woocommerce_before_customer_login_form, so the popup is never doubled.
		$cev_popup = cev_pro()->get_plugin_path() . '/includes/signup-verification/views/cev-signup-popup.php';
		if ( file_exists( $cev_popup ) ) {
			require_once $cev_popup;
		}

		// Apply the Customizer brand colour as scoped CSS variables (Phase 8).
		$cev_sf_result                 = $this->brand_color_inline_style() . ob_get_clean();
		$this->current_render_template = '';
		return $cev_sf_result;
	}

	/**
	 * Fallback used by the shortcode when the standard WooCommerce form is the
	 * active type — render WC's own login/register form so a shortcode page is
	 * never blank. Returns empty for logged-in users (no form to show).
	 *
	 * @since 2.10.0
	 * @return string
	 */
	private function wc_login_form_fallback() {
		if ( is_user_logged_in() || ! function_exists( 'wc_get_template' ) ) {
			return '';
		}

		ob_start();
		wc_get_template( 'myaccount/form-login.php' );
		return ob_get_clean();
	}

	/**
	 * Whether the Smart Form should replace the WooCommerce My Account form.
	 * True only when Smart Form is active AND the takeover toggle is on.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_myaccount_takeover_enabled() {
		return $this->is_smart_form_active()
			&& 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_takeover_myaccount', 0 );
	}

	/**
	 * Whether the current request is the logged-out My Account page with
	 * takeover enabled. Used by the enqueue layer to load the assets there.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function should_take_over_myaccount() {
		return $this->is_myaccount_takeover_enabled()
			&& function_exists( 'is_account_page' )
			&& is_account_page()
			&& ! is_user_logged_in();
	}

	/**
	 * Whether the Smart Form is the active form on the current page — either it
	 * has taken over My Account, or the page hosts the [cev_smart_form] shortcode.
	 * Used to gate asset loading (and to skip the classic signup script here).
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_active_on_page() {
		return $this->is_smart_form_active() && ( $this->should_take_over_myaccount() || $this->page_has_shortcode() );
	}

	/**
	 * Swap WooCommerce's myaccount/form-login.php template for the Smart Form
	 * when takeover is enabled. The logged-in dashboard is untouched (WC only
	 * loads form-login.php for logged-out visitors).
	 *
	 * @since 2.10.0
	 * @param string $template      Located template path.
	 * @param string $template_name Template name being located.
	 * @param string $template_path Theme template path (unused).
	 * @return string
	 */
	public function maybe_take_over_myaccount_form( $template, $template_name, $template_path ) {
		unset( $template_path );

		if ( 'myaccount/form-login.php' !== $template_name ) {
			return $template;
		}

		if ( is_user_logged_in() || ! $this->is_myaccount_takeover_enabled() ) {
			return $template;
		}

		$override = __DIR__ . '/views/myaccount-form-login.php';

		return file_exists( $override ) ? $override : $template;
	}

	/**
	 * Purge page caches when the signup form type changes so cached pages never
	 * show the previous form.
	 *
	 * @since 2.10.0
	 * @param mixed $old_value Previous consolidated settings array.
	 * @param mixed $new_value New consolidated settings array.
	 * @return void
	 */
	public function maybe_purge_on_form_type_change( $old_value, $new_value ) {
		$old_type = is_array( $old_value ) && isset( $old_value['cev_signup_form_type'] ) ? (string) $old_value['cev_signup_form_type'] : '';
		$new_type = is_array( $new_value ) && isset( $new_value['cev_signup_form_type'] ) ? (string) $new_value['cev_signup_form_type'] : '';

		if ( $old_type === $new_type ) {
			return;
		}

		// Run the (possibly slow) page-cache flush in the BACKGROUND so the
		// settings save returns instantly. A synchronous full-cache purge can
		// otherwise block the request long enough to trip a 504 on cache-heavy
		// sites. Action Scheduler (bundled with WooCommerce) is preferred; fall
		// back to a one-off WP-Cron event.
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( 'cev_smart_form_purge_caches', array(), 'cev-smart-form', true );
		} elseif ( ! wp_next_scheduled( 'cev_smart_form_purge_caches' ) ) {
			wp_schedule_single_event( time() + 5, 'cev_smart_form_purge_caches' );
		}
	}

	/**
	 * Fire common page-cache plugin purge hooks. Runs in the background (hooked
	 * to cev_smart_form_purge_caches) so a slow full-cache flush never blocks
	 * the settings save and trips a 504.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function purge_caches() {
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
		}
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
		}

		// LiteSpeed Cache.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		do_action( 'litespeed_purge_all' );
	}

	/**
	 * Whether any published page contains the [cev_smart_form] shortcode.
	 * Result is cached in a transient (best-effort LIKE query).
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function has_shortcode_on_any_page() {
		$cached = get_transient( self::SHORTCODE_PRESENCE_TRANSIENT );
		if ( false !== $cached ) {
			return ( 'yes' === $cached );
		}

		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_content LIKE %s LIMIT 1",
				'%' . $wpdb->esc_like( '[' . self::SHORTCODE . ']' ) . '%'
			)
		);
		// phpcs:enable

		$result = empty( $found ) ? 'no' : 'yes';
		set_transient( self::SHORTCODE_PRESENCE_TRANSIENT, $result, HOUR_IN_SECONDS );

		return ( 'yes' === $result );
	}

	/**
	 * Admin nudge: Smart Form is selected but surfaced nowhere (takeover off and
	 * no page hosts the shortcode), so customers would never see it.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function maybe_render_placement_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $this->is_smart_form_active() || $this->is_myaccount_takeover_enabled() ) {
			return;
		}

		if ( $this->has_shortcode_on_any_page() ) {
			return;
		}

		$settings_url = admin_url( 'admin.php?page=customer-email-verification-for-woocommerce' );
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				printf(
					/* translators: 1: opening <strong> tag, 2: closing </strong> tag, 3: the [cev_smart_form] shortcode */
					esc_html__( '%1$sSmart Form is selected%2$s but it is not shown anywhere yet. Turn on the "Replace the My Account page form with the Smart Form" toggle, or add the %3$s shortcode to a page.', 'customer-email-verification' ),
					'<strong>',
					'</strong>',
					'<code>[' . esc_html( self::SHORTCODE ) . ']</code>'
				);
				?>
				<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Open Smart Form settings', 'customer-email-verification' ); ?></a>
			</p>
		</div>
		<?php
	}
}
