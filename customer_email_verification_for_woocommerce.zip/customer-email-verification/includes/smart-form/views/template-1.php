<?php
/**
 * Smart Form — Template 1: Branded minimal.
 *
 * Store name + underline tabs on a bordered card with a brand top accent.
 * Expects $cev_config.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="cev-smart-form cev-sf--t1" data-cev-smart-form data-template="template1">
	<div class="cev-sf-card cev-sf-card--minimal">
		<div class="cev-sf-logo"><?php echo wp_kses_post( CEV_Smart_Form::get_instance()->brand_title_html() ); ?></div>
		<?php include __DIR__ . '/partials/form-area.php'; ?>
	</div>
</div>
