<?php
/**
 * Smart Form — Register form fields partial.
 *
 * Expects $cev_config (from CEV_Smart_Form::get_config()) in scope. Email is
 * always shown; phone appears only when the registration method is phone, and a
 * password field appears only when the login method is password. The OTP step is
 * hidden until the email-registration AJAX (Phase 3) succeeds, then revealed by
 * smart-form.js.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$cev_cfg          = ( isset( $cev_config ) && is_array( $cev_config ) ) ? $cev_config : array();
$cev_reg_method   = isset( $cev_cfg['reg_method'] ) ? $cev_cfg['reg_method'] : 'email';
$cev_login_method = isset( $cev_cfg['login_method'] ) ? $cev_cfg['login_method'] : 'password';
$cev_otp_len      = isset( $cev_cfg['otp_length'] ) ? (int) $cev_cfg['otp_length'] : 4;

// Phone field: forced on + required for phone (SMS) registration; otherwise
// driven by the admin "Show phone number field" / "Require the phone number" toggles.
$cev_show_phone     = ( 'phone' === $cev_reg_method ) || ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_show_phone_field', 0 ) );
$cev_phone_required = ( 'phone' === $cev_reg_method ) || ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_phone_required', 0 ) );
?>
<form class="cev-sf-form" data-cev-sf-form="register" novalidate>
	<div class="cev-sf-step" data-cev-sf-step="fields">
		<?php CEV_Smart_Form::get_instance()->render_custom_fields( 'register_top' ); ?>
		<div class="cev-sf-field">
			<label class="cev-sf-label" for="cev-sf-reg-email"><?php esc_html_e( 'Email address', 'customer-email-verification' ); ?> <span class="cev-sf-req" aria-hidden="true">*</span></label>
			<input type="email" id="cev-sf-reg-email" name="email" class="cev-sf-input" autocomplete="email" required aria-required="true" aria-describedby="cev-sf-reg-email-error" />
			<span class="cev-sf-error" id="cev-sf-reg-email-error" aria-live="polite"></span>
		</div>
		<?php CEV_Smart_Form::get_instance()->render_custom_fields( 'after_email' ); ?>
		<?php if ( $cev_show_phone ) : ?>
			<div class="cev-sf-field">
				<label class="cev-sf-label" for="cev-sf-reg-phone">
					<?php esc_html_e( 'Phone number', 'customer-email-verification' ); ?>
					<?php if ( $cev_phone_required ) : ?>
						<span class="cev-sf-req" aria-hidden="true">*</span>
					<?php else : ?>
						<span class="cev-sf-optional"><?php esc_html_e( '(optional)', 'customer-email-verification' ); ?></span>
					<?php endif; ?>
				</label>
				<?php if ( $cev_phone_required ) : ?>
					<input type="tel" id="cev-sf-reg-phone" name="phone" class="cev-sf-input" autocomplete="tel" data-cev-sf-intl="1" placeholder="<?php esc_attr_e( 'e.g. +1 415 555 0123', 'customer-email-verification' ); ?>" required aria-required="true" aria-describedby="cev-sf-reg-phone-error" />
				<?php else : ?>
					<input type="tel" id="cev-sf-reg-phone" name="phone" class="cev-sf-input" autocomplete="tel" data-cev-sf-intl="1" placeholder="<?php esc_attr_e( 'e.g. +1 415 555 0123', 'customer-email-verification' ); ?>" aria-describedby="cev-sf-reg-phone-error" />
				<?php endif; ?>
				<span class="cev-sf-error" id="cev-sf-reg-phone-error" aria-live="polite"></span>
			</div>
		<?php endif; ?>
		<?php CEV_Smart_Form::get_instance()->render_custom_fields( 'after_phone' ); ?>
		<div class="cev-sf-field">
			<label class="cev-sf-label" for="cev-sf-reg-password"><?php esc_html_e( 'Password', 'customer-email-verification' ); ?> <span class="cev-sf-req" aria-hidden="true">*</span></label>
			<div class="cev-sf-input-wrap">
				<input type="password" id="cev-sf-reg-password" name="password" class="cev-sf-input cev-sf-input--password" autocomplete="new-password" required aria-required="true" aria-describedby="cev-sf-reg-password-error" />
				<button type="button" class="cev-sf-pw-toggle" aria-label="<?php esc_attr_e( 'Show password', 'customer-email-verification' ); ?>" aria-pressed="false">
					<svg class="cev-sf-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
					<svg class="cev-sf-eye-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>
				</button>
			</div>
			<div class="cev-sf-pw-meter" aria-hidden="true" hidden><span class="cev-sf-pw-bar"></span></div>
			<span class="cev-sf-pw-label" aria-live="polite"></span>
			<span class="cev-sf-error" id="cev-sf-reg-password-error" aria-live="polite"></span>
		</div>
		<?php CEV_Smart_Form::get_instance()->render_custom_fields( 'after_password' ); ?>
		<?php
		// Let WooCommerce-form captcha / security plugins (e.g. All In One WP
		// Security) inject their captcha here, as on the standard WC register form.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		if ( apply_filters( 'cev_smart_form_fire_wc_hooks', true ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
			do_action( 'woocommerce_register_form' );
		}
		?>
		<?php CEV_Smart_Form::get_instance()->render_custom_fields( 'before_submit' ); ?>
		<span class="cev-sf-error cev-sf-form-error" aria-live="polite"></span>
		<button type="submit" class="cev-sf-btn cev-sf-btn--primary"><?php echo esc_html( CEV_Smart_Form::get_instance()->customizer( 'register_button', __( 'Create account', 'customer-email-verification' ) ) ); ?></button>
		<p class="cev-sf-alt"><?php esc_html_e( 'Already registered?', 'customer-email-verification' ); ?> <button type="button" class="cev-sf-link" data-cev-sf-tab="login"><?php esc_html_e( 'Log in', 'customer-email-verification' ); ?></button></p>
	</div>
	<?php // OTP entry reuses the shared signup verification popup (#otp-popup), opened by smart-form.js. ?>
</form>
