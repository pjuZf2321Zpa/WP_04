<?php
/**
 * Smart Form — Login form fields partial.
 *
 * Expects $cev_config (from CEV_Smart_Form::get_config()) in scope.
 *
 * The admin can enable any combination of login methods (Password, Email OTP,
 * Phone OTP). When more than one is enabled the form shows a tab per method;
 * each tab reveals its own pane and enables only that pane's inputs (the others
 * are disabled so they never submit). The active method is posted as
 * `cev_login_method`, and for the OTP methods the delivery channel is posted as
 * `channel` (email | phone). smart-form.js routes the submit accordingly.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$cev_cfg = ( isset( $cev_config ) && is_array( $cev_config ) ) ? $cev_config : array();

// Enabled login methods, in canonical order (password, email_otp, phone_otp).
$cev_login_methods = ( isset( $cev_cfg['login_methods'] ) && is_array( $cev_cfg['login_methods'] ) && ! empty( $cev_cfg['login_methods'] ) )
	? $cev_cfg['login_methods']
	: array( 'password' );

$cev_active_method  = $cev_login_methods[0];
$cev_multi          = ( count( $cev_login_methods ) > 1 );
$cev_login_btn      = (string) CEV_Smart_Form::get_instance()->customizer( 'login_button', __( 'Log in', 'customer-email-verification' ) );
$cev_send_code_txt  = __( 'Send code', 'customer-email-verification' );

// The delivery channel posted for the initially-active method (OTP only).
$cev_active_channel = ( 'phone_otp' === $cev_active_method ) ? 'phone' : 'email';

// Human labels for each method tab.
$cev_method_label = array(
	'password'  => __( 'Password', 'customer-email-verification' ),
	'email_otp' => __( 'Email code', 'customer-email-verification' ),
	'phone_otp' => __( 'Phone code', 'customer-email-verification' ),
);

// Submit-button label for the initially-active method.
$cev_submit_label = ( 'password' === $cev_active_method ) ? $cev_login_btn : $cev_send_code_txt;
?>
<form class="cev-sf-form" data-cev-sf-form="login" novalidate>
	<?php if ( $cev_multi ) : ?>
		<div class="cev-sf-login-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Choose how to sign in', 'customer-email-verification' ); ?>">
			<?php foreach ( $cev_login_methods as $cev_m ) : ?>
				<?php $cev_on = ( $cev_m === $cev_active_method ); ?>
				<button type="button" class="cev-sf-login-tab<?php echo $cev_on ? ' is-active' : ''; ?>" data-cev-sf-login-method="<?php echo esc_attr( $cev_m ); ?>" role="tab" aria-selected="<?php echo $cev_on ? 'true' : 'false'; ?>">
					<?php echo esc_html( isset( $cev_method_label[ $cev_m ] ) ? $cev_method_label[ $cev_m ] : $cev_m ); ?>
				</button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<input type="hidden" name="cev_login_method" value="<?php echo esc_attr( $cev_active_method ); ?>" data-cev-sf-login-method-value />
	<input type="hidden" name="channel" value="<?php echo esc_attr( $cev_active_channel ); ?>" data-cev-sf-channel-value />

	<?php foreach ( $cev_login_methods as $cev_m ) : ?>
		<?php
		$cev_on = ( $cev_m === $cev_active_method );
		// Active pane inputs get required + aria-required; inactive panes are
		// disabled so they never submit or block native validation. Each input
		// emits those attributes inline via a literal ternary (safe output).
		?>
		<div class="cev-sf-login-pane" data-cev-sf-login-pane="<?php echo esc_attr( $cev_m ); ?>"<?php echo $cev_on ? '' : ' hidden'; ?>>
			<?php if ( 'password' === $cev_m ) : ?>
				<div class="cev-sf-field">
					<label class="cev-sf-label" for="cev-sf-login-id"><?php esc_html_e( 'Email or username', 'customer-email-verification' ); ?> <span class="cev-sf-req" aria-hidden="true">*</span></label>
					<input type="text" id="cev-sf-login-id" name="login" class="cev-sf-input" autocomplete="username"<?php echo $cev_on ? ' required aria-required="true"' : ' disabled'; ?> aria-describedby="cev-sf-login-id-error" />
					<span class="cev-sf-error" id="cev-sf-login-id-error" aria-live="polite"></span>
				</div>
				<div class="cev-sf-field">
					<label class="cev-sf-label" for="cev-sf-login-pass"><?php esc_html_e( 'Password', 'customer-email-verification' ); ?> <span class="cev-sf-req" aria-hidden="true">*</span></label>
					<input type="password" id="cev-sf-login-pass" name="password" class="cev-sf-input" autocomplete="current-password"<?php echo $cev_on ? ' required aria-required="true"' : ' disabled'; ?> aria-describedby="cev-sf-login-pass-error" />
					<span class="cev-sf-error" id="cev-sf-login-pass-error" aria-live="polite"></span>
				</div>
				<p class="cev-sf-lost-password">
					<a href="<?php echo esc_url( wc_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'customer-email-verification' ); ?></a>
				</p>
			<?php elseif ( 'phone_otp' === $cev_m ) : ?>
				<div class="cev-sf-field">
					<label class="cev-sf-label" for="cev-sf-login-phone"><?php esc_html_e( 'Phone number', 'customer-email-verification' ); ?> <span class="cev-sf-req" aria-hidden="true">*</span></label>
					<input type="tel" id="cev-sf-login-phone" name="login" class="cev-sf-input" data-cev-sf-intl="1" autocomplete="tel" placeholder="<?php esc_attr_e( 'e.g. +1 415 555 0123', 'customer-email-verification' ); ?>"<?php echo $cev_on ? ' required aria-required="true"' : ' disabled'; ?> aria-describedby="cev-sf-login-phone-error" />
					<span class="cev-sf-error" id="cev-sf-login-phone-error" aria-live="polite"></span>
				</div>
				<p class="cev-sf-hint"><?php esc_html_e( 'We will send you a one-time code to sign in.', 'customer-email-verification' ); ?></p>
			<?php else : ?>
				<div class="cev-sf-field">
					<label class="cev-sf-label" for="cev-sf-login-email"><?php esc_html_e( 'Email address', 'customer-email-verification' ); ?> <span class="cev-sf-req" aria-hidden="true">*</span></label>
					<input type="email" id="cev-sf-login-email" name="login" class="cev-sf-input" autocomplete="email"<?php echo $cev_on ? ' required aria-required="true"' : ' disabled'; ?> aria-describedby="cev-sf-login-email-error" />
					<span class="cev-sf-error" id="cev-sf-login-email-error" aria-live="polite"></span>
				</div>
				<p class="cev-sf-hint"><?php esc_html_e( 'We will send you a one-time code to sign in.', 'customer-email-verification' ); ?></p>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>

	<?php
	// Let WooCommerce-form captcha / security plugins (e.g. All In One WP
	// Security) inject their captcha here, as on the standard WC login form.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
	if ( apply_filters( 'cev_smart_form_fire_wc_hooks', true ) ) {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		do_action( 'woocommerce_login_form' );
	}
	?>
	<span class="cev-sf-error cev-sf-form-error" aria-live="polite"></span>

	<button type="submit" class="cev-sf-btn cev-sf-btn--primary" data-cev-sf-login-submit data-cev-sf-label-password="<?php echo esc_attr( $cev_login_btn ); ?>" data-cev-sf-label-otp="<?php echo esc_attr( $cev_send_code_txt ); ?>"><?php echo esc_html( $cev_submit_label ); ?></button>
	<p class="cev-sf-alt"><?php esc_html_e( 'New here?', 'customer-email-verification' ); ?> <button type="button" class="cev-sf-link" data-cev-sf-tab="register"><?php esc_html_e( 'Create an account', 'customer-email-verification' ); ?></button></p>
</form>
