<?php
/**
 * Smart Form — shared form area: Login + Register panels with an OPTIONAL tab bar.
 *
 * The tab switcher renders unless $cev_no_tabs is set — only template 1 keeps the
 * tabs; the other templates set $cev_no_tabs = true and switch between Login and
 * Register via the in-form link ("New here? / Already registered?"). Set
 * $cev_tabs_center = true for a centered tab strip. Expects $cev_config in scope.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Customizer (Phase 8) — optional subheading / footer. The Heading drives the
// brand title (see CEV_Smart_Form::brand_title_html()) and is NOT rendered as a
// separate element here.
$cev_sf_subheading = (string) CEV_Smart_Form::get_instance()->customizer( 'subheading', __( 'Choose how you\'d like to continue', 'customer-email-verification' ) );
$cev_sf_footer     = (string) CEV_Smart_Form::get_instance()->customizer( 'footer', '' );
?>
<?php if ( empty( $cev_subheading_in_panel ) && '' !== $cev_sf_subheading ) : ?>
	<div class="cev-sf-headings">
		<div class="cev-sf-subheading"><?php echo esc_html( $cev_sf_subheading ); ?></div>
	</div>
<?php endif; ?>
<?php $cev_has_tabs = empty( $cev_no_tabs ); ?>
<?php if ( $cev_has_tabs ) : ?>
<div class="cev-sf-tabs<?php echo empty( $cev_tabs_center ) ? '' : ' cev-sf-tabs--center'; ?>" role="tablist" aria-label="<?php esc_attr_e( 'Login or register', 'customer-email-verification' ); ?>">
	<button type="button" class="cev-sf-tab is-active" data-cev-sf-tab="login" role="tab" id="cev-sf-tab-login" aria-controls="cev-sf-panel-login" aria-selected="true"><?php esc_html_e( 'Log in', 'customer-email-verification' ); ?></button>
	<button type="button" class="cev-sf-tab" data-cev-sf-tab="register" role="tab" id="cev-sf-tab-register" aria-controls="cev-sf-panel-register" aria-selected="false" tabindex="-1"><?php esc_html_e( 'Register', 'customer-email-verification' ); ?></button>
</div>
<?php endif; ?>
<div class="cev-sf-panels">
	<?php if ( $cev_has_tabs ) : ?>
	<div class="cev-sf-panel is-active" data-cev-sf-panel="login" role="tabpanel" id="cev-sf-panel-login" aria-labelledby="cev-sf-tab-login" tabindex="0">
	<?php else : ?>
	<div class="cev-sf-panel is-active" data-cev-sf-panel="login">
	<?php endif; ?>
		<?php include __DIR__ . '/login-fields.php'; ?>
	</div>
	<?php if ( $cev_has_tabs ) : ?>
	<div class="cev-sf-panel" data-cev-sf-panel="register" role="tabpanel" id="cev-sf-panel-register" aria-labelledby="cev-sf-tab-register" tabindex="0">
	<?php else : ?>
	<div class="cev-sf-panel" data-cev-sf-panel="register">
	<?php endif; ?>
		<?php include __DIR__ . '/register-fields.php'; ?>
	</div>
</div>
<?php if ( '' !== $cev_sf_footer ) : ?>
	<div class="cev-sf-footer"><?php echo wp_kses_post( $cev_sf_footer ); ?></div>
<?php endif; ?>
