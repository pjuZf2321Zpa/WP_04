<?php
/**
 * Smart Form — My Account takeover template.
 *
 * Replaces WooCommerce's myaccount/form-login.php with the Smart Form when the
 * "Replace the My Account page form with the Smart Form" toggle is on. WC only
 * loads form-login.php for logged-out visitors, so the logged-in dashboard is
 * never affected. The markup is built by CEV_Smart_Form::render() from the
 * selected template, where every interpolated value is escaped at source.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( class_exists( 'CEV_Smart_Form' ) ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built by CEV_Smart_Form::render() where every interpolated value is escaped at source; wp_kses_post would strip required form attributes.
	echo CEV_Smart_Form::get_instance()->render();
}
