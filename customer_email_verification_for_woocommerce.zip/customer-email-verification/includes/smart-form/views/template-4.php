<?php
/**
 * Smart Form — Template 4: Side-by-side.
 *
 * Login and Register shown together in two columns (no tabs). Expects $cev_config.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="cev-smart-form cev-sf--t4" data-cev-smart-form data-template="template4">
	<div class="cev-sf-columns">
		<div class="cev-sf-col">
			<h3 class="cev-sf-col__title"><?php esc_html_e( 'Log in', 'customer-email-verification' ); ?></h3>
			<?php include __DIR__ . '/partials/login-fields.php'; ?>
		</div>
		<div class="cev-sf-col cev-sf-col--divider">
			<h3 class="cev-sf-col__title"><?php esc_html_e( 'Create an account', 'customer-email-verification' ); ?></h3>
			<?php include __DIR__ . '/partials/register-fields.php'; ?>
		</div>
	</div>
</div>
