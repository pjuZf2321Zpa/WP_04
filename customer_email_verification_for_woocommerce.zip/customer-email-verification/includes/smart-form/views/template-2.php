<?php
/**
 * Smart Form — Template 2: Split / brand panel.
 *
 * Brand panel beside the tabbed form. Expects $cev_config. The panel
 * background, text colour and heading are Customizer-driven via the
 * --cev-sf-panel-* CSS variables set by brand_color_inline_style().
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// No tab bar — switch between Login and Register via the in-form link.
// Panel always shows on the left; content always centred.
$cev_no_tabs             = true;
$cev_sf                  = CEV_Smart_Form::get_instance();
$cev_card_class          = 'cev-sf-card cev-sf-card--split';
$cev_sf_subheading_t2    = (string) $cev_sf->customizer( 'subheading', __( 'Choose how you\'d like to continue', 'customer-email-verification' ) );
$cev_subheading_in_panel = true;
?>
<div class="cev-smart-form cev-sf--t2" data-cev-smart-form data-template="template2">
	<div class="<?php echo esc_attr( $cev_card_class ); ?>">
		<div class="cev-sf-brand">
			<div class="cev-sf-brand__content">
				<span class="cev-sf-brand__logo"><?php echo wp_kses_post( $cev_sf->brand_title_html() ); ?></span>
				<?php if ( '' !== $cev_sf_subheading_t2 ) : ?>
					<p class="cev-sf-brand__subheading"><?php echo esc_html( $cev_sf_subheading_t2 ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="cev-sf-formside">
			<?php include __DIR__ . '/partials/form-area.php'; ?>
		</div>
	</div>
</div>
