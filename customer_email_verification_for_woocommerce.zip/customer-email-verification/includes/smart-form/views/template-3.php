<?php
/**
 * Smart Form — Template 3: Brand header banner.
 *
 * A bordered card with a brand-coloured header (title + subheading) above
 * the tabbed form. The header background, text colour and content are
 * Customizer-driven via the --cev-sf-panel-* CSS variables set by
 * brand_color_inline_style().
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// No tab bar — switch between Login and Register via the in-form link.
// Banner always shows; subheading lives in the banner, not the form area.
$cev_no_tabs             = true;
$cev_sf                  = CEV_Smart_Form::get_instance();
$cev_card_class          = 'cev-sf-card cev-sf-card--banner';
$cev_sf_subheading_t3    = (string) $cev_sf->customizer( 'subheading', __( 'Choose how you\'d like to continue', 'customer-email-verification' ) );
$cev_subheading_in_panel = true;
?>
<div class="cev-smart-form cev-sf--t3" data-cev-smart-form data-template="template3">
	<div class="<?php echo esc_attr( $cev_card_class ); ?>">
		<div class="cev-sf-banner">
			<div class="cev-sf-brand__content">
				<div class="cev-sf-banner__title"><?php echo wp_kses_post( $cev_sf->brand_title_html() ); ?></div>
				<?php if ( '' !== $cev_sf_subheading_t3 ) : ?>
					<p class="cev-sf-brand__subheading"><?php echo esc_html( $cev_sf_subheading_t3 ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="cev-sf-banner-body">
			<?php include __DIR__ . '/partials/form-area.php'; ?>
		</div>
	</div>
</div>
