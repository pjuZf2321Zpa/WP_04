<?php
/**
 * Smart Form — SMS gateway factory (Phase 5).
 *
 * Provider-agnostic entry point for sending SMS. Picks a driver from the
 * cev_sms_provider setting and delegates send() to it. Also wires the admin
 * "Send test SMS" AJAX so credentials can be validated before any phone
 * verification flow uses the gateway.
 *
 * This native gateway is the FALLBACK: when Zorem's SMS for WooCommerce plugin
 * is active and compatible, CEV defers to it (Phase 11). It is fully
 * self-contained and never requires that plugin.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_Gateway class.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_SMS_Gateway {

	/**
	 * Nonce action for the admin test-send.
	 *
	 * @var string
	 */
	const TEST_NONCE_ACTION = 'cev_sms_test_nonce';

	/**
	 * Provider => driver-class map.
	 *
	 * @var array
	 */
	private static $drivers = array(
		'whatsapp' => 'CEV_SMS_WhatsApp',
		'twilio'   => 'CEV_SMS_Twilio',
		'vonage'   => 'CEV_SMS_Vonage',
		'msg91'    => 'CEV_SMS_MSG91',
	);

	/**
	 * Register the admin test-send AJAX handler.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function register() {
		add_action( 'wp_ajax_cev_sms_test_send', array( __CLASS__, 'ajax_test_send' ) );
	}

	/**
	 * Send an SMS via the configured provider.
	 *
	 * @since 2.10.0
	 * @param string $to      Recipient phone number (international).
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	public static function send( $to, $message ) {
		$to = trim( (string) $to );
		if ( '' === $to ) {
			return new WP_Error( 'sms_no_recipient', __( 'No recipient phone number was provided.', 'customer-email-verification' ) );
		}

		// SMS-flood / cost-abuse guard (Phase 10).
		$flood = self::flood_check( $to );
		if ( is_wp_error( $flood ) ) {
			return $flood;
		}

		$driver = self::get_driver();
		if ( is_wp_error( $driver ) ) {
			return $driver;
		}

		$result = $driver->send( $to, (string) $message );

		/**
		 * Fires after an SMS send attempt. No credentials or message body are
		 * passed — only the recipient, success flag, and any error message.
		 *
		 * @since 2.10.0
		 * @param string $to      Recipient phone number.
		 * @param bool   $success Whether the send succeeded.
		 * @param string $error   Error message when it failed.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		do_action( 'cev_sms_sent', $to, ( true === $result ), is_wp_error( $result ) ? $result->get_error_message() : '' );

		return $result;
	}

	/**
	 * Whether the configured provider has the credentials it needs.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public static function is_configured() {
		$driver = self::get_driver();
		return ! is_wp_error( $driver ) && $driver->is_configured();
	}

	/**
	 * SMS-flood / cost-abuse guard (Phase 10). Caps how many messages a single
	 * number can receive within a rolling window. Skipped for shop managers so
	 * the admin "Send test SMS" is never blocked. Filterable via
	 * cev_sms_flood_max / cev_sms_flood_window.
	 *
	 * @since 2.10.0
	 * @param string $to Recipient phone number.
	 * @return true|WP_Error
	 */
	private static function flood_check( $to ) {
		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$max    = (int) apply_filters( 'cev_sms_flood_max', 10 );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$window = (int) apply_filters( 'cev_sms_flood_window', DAY_IN_SECONDS );
		if ( $max <= 0 ) {
			return true;
		}

		$digits = preg_replace( '/[^0-9]/', '', (string) $to );
		if ( '' === $digits ) {
			return true;
		}

		$key   = 'cev_sms_flood_' . md5( $digits );
		$count = (int) get_transient( $key );
		if ( $count >= $max ) {
			return new WP_Error( 'sms_flood', __( 'This number has received too many messages recently. Please try again later.', 'customer-email-verification' ) );
		}
		set_transient( $key, $count + 1, $window );

		return true;
	}

	/**
	 * Resolve the driver for the configured provider.
	 *
	 * @since 2.10.0
	 * @return CEV_SMS_Driver|WP_Error
	 */
	private static function get_driver() {
		$provider = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_sms_provider', 'whatsapp' );

		if ( ! isset( self::$drivers[ $provider ] ) ) {
			return new WP_Error( 'sms_no_provider', __( 'No SMS provider is configured.', 'customer-email-verification' ) );
		}

		self::load_classes();

		$class = self::$drivers[ $provider ];
		if ( ! class_exists( $class ) ) {
			return new WP_Error( 'sms_driver_missing', __( 'The selected SMS provider is unavailable.', 'customer-email-verification' ) );
		}

		return new $class();
	}

	/**
	 * Lazily require the base + driver classes.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	private static function load_classes() {
		$dir = __DIR__;
		require_once $dir . '/class-cev-sms-driver.php';
		foreach ( array( 'whatsapp', 'twilio', 'vonage', 'msg91' ) as $driver ) {
			require_once $dir . '/drivers/class-cev-sms-' . $driver . '.php';
		}
	}

	/**
	 * AJAX: send a test SMS from the admin SMS Gateway settings (capability +
	 * nonce checked). Surfaces the provider error verbatim.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function ajax_test_send() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'customer-email-verification' ) ) );
		}
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::TEST_NONCE_ACTION ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please reload the page.', 'customer-email-verification' ) ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$phone = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		if ( '' === $phone ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a phone number to test.', 'customer-email-verification' ) ) );
		}

		$result = self::send( $phone, __( 'Your test message from Customer Email Verification.', 'customer-email-verification' ) );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => __( 'Test SMS sent successfully.', 'customer-email-verification' ) ) );
	}
}
