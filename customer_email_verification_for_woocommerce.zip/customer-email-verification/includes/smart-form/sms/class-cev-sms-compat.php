<?php
/**
 * Smart Form — SMS plugin compatibility layer (Phase 11).
 *
 * When Zorem's "SMS for WooCommerce" plugin is active AND compatible, CEV defers
 * SMS delivery + provider configuration to it. CEV's own native gateway (Phase 5)
 * becomes the FALLBACK for when that plugin is missing, inactive, or too old.
 *
 * ── Integration points (SMS for WooCommerce >= 2.0) ──────────────────────────
 *   Detection : function_exists( 'SMSWOO' ) && class_exists( 'SMSWOO_Sms_Sender' )
 *   Version   : SMSWOO()->version            (e.g. '2.4.2')
 *   Send API  : SMSWOO()->sms_sender->send_sms( $phone, $message )  -> bool
 *               ( $phone may be E.164 — send_sms() is +-aware and will NOT
 *                 double-prefix the country code )
 *   Settings  : admin.php?page=sms-for-woocommerce
 *   Fallback  : CEV_SMS_Gateway::send() / ::is_configured()         (Phase 5)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_Compat class.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_SMS_Compat {

	/**
	 * Minimum supported SMS-for-WooCommerce version (the public send_sms() API).
	 *
	 * @var string
	 */
	const MIN_VERSION = '2.0.0';

	/**
	 * Per-request cache of the availability check.
	 *
	 * @var bool|null
	 */
	private static $available = null;

	/**
	 * Whether the SMS plugin is installed + active (any version).
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public static function is_sms_plugin_active() {
		return function_exists( 'SMSWOO' ) && class_exists( 'SMSWOO_Sms_Sender' );
	}

	/**
	 * The active SMS plugin version, or '' when not active.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public static function plugin_version() {
		if ( function_exists( 'SMSWOO' ) && isset( SMSWOO()->version ) ) {
			return (string) SMSWOO()->version;
		}
		return '';
	}

	/**
	 * Minimum version CEV requires of the SMS plugin (filterable).
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public static function min_version() {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (string) apply_filters( 'cev_sms_plugin_min_version', self::MIN_VERSION );
	}

	/**
	 * Whether the SMS plugin is active AND compatible (>= the minimum version)
	 * AND has its sms_sender object instantiated (requires an active subscription).
	 * Cached per request; filterable.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public static function is_sms_plugin_available() {
		if ( null !== self::$available ) {
			return self::$available;
		}

		$ok = self::is_sms_plugin_active();
		if ( $ok ) {
			$version = self::plugin_version();
			$ok      = ( '' === $version ) || version_compare( $version, self::min_version(), '>=' );
		}
		// sms_sender is only instantiated when the SMS plugin subscription is active.
		// Without it, calling send_sms() would fatal on a null object.
		if ( $ok ) {
			$ok = function_exists( 'SMSWOO' ) && isset( SMSWOO()->sms_sender ) && is_object( SMSWOO()->sms_sender );
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		self::$available = (bool) apply_filters( 'cev_sms_plugin_available', $ok );
		return self::$available;
	}

	/**
	 * The SMS plugin is active but too old for CEV to integrate with.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public static function is_active_but_incompatible() {
		return self::is_sms_plugin_active() && ! self::is_sms_plugin_available();
	}

	/**
	 * URL of the SMS plugin's settings page.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public static function settings_url() {
		return admin_url( 'admin.php?page=sms-for-woocommerce' );
	}

	/**
	 * Whether ANY usable SMS backend exists — the SMS plugin (compatible) OR
	 * CEV's native gateway with credentials configured. Phone flows gate on this.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public static function has_backend() {
		if ( self::is_sms_plugin_available() ) {
			return true;
		}
		return class_exists( 'CEV_SMS_Gateway' ) && CEV_SMS_Gateway::is_configured();
	}

	/**
	 * Unified SMS delivery (Phase 11). Routes to the SMS plugin when available +
	 * compatible, else CEV's native gateway (Phase 5). Returns true|WP_Error to
	 * match CEV_SMS_Gateway::send(), so callers are unchanged.
	 *
	 * @since 2.10.0
	 * @param string $phone   Recipient phone number (E.164 or local).
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	public static function deliver_sms( $phone, $message ) {
		$phone   = trim( (string) $phone );
		$message = (string) $message;
		if ( '' === $phone ) {
			return new WP_Error( 'sms_no_recipient', __( 'No recipient phone number was provided.', 'customer-email-verification' ) );
		}

		if ( self::is_sms_plugin_available() && function_exists( 'SMSWOO' ) ) {
			$sent = SMSWOO()->sms_sender->send_sms( $phone, $message );
			if ( $sent ) {
				return true;
			}
			return new WP_Error( 'sms_plugin_failed', __( 'The SMS could not be sent. Please check your SMS plugin configuration.', 'customer-email-verification' ) );
		}

		if ( class_exists( 'CEV_SMS_Gateway' ) ) {
			return CEV_SMS_Gateway::send( $phone, $message );
		}

		return new WP_Error( 'sms_unavailable', __( "No SMS backend is available. Configure CEV's SMS gateway or activate the SMS for WooCommerce plugin.", 'customer-email-verification' ) );
	}
}

if ( ! function_exists( 'cev_deliver_sms' ) ) {
	/**
	 * Unified SMS send entry point (Phase 11). Phone flows (Phases 6 & 7) call
	 * this — never the native gateway directly — so SMS routes to the SMS-for-
	 * WooCommerce plugin when available, else CEV's native gateway.
	 *
	 * @since 2.10.0
	 * @param string $phone   Recipient phone number.
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Plugin-owned global function; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
	function cev_deliver_sms( $phone, $message ) {
		return CEV_SMS_Compat::deliver_sms( $phone, $message );
	}
}
