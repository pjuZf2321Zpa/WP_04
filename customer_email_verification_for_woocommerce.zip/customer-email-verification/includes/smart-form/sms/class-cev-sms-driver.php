<?php
/**
 * Smart Form — SMS driver base class (Phase 5).
 *
 * Provider-agnostic base for the native SMS drivers. Each driver reads ONLY its
 * own stored credentials (cev_sms_* settings) and returns true|WP_Error from
 * send(). No secrets are ever logged or echoed.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_Driver abstract class.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
abstract class CEV_SMS_Driver {

	/**
	 * Read a plugin setting.
	 *
	 * @since 2.10.0
	 * @param string $key     Setting key.
	 * @param string $default Default value.
	 * @return mixed
	 */
	protected function setting( $key, $default = '' ) {
		return cev_pro()->function->cev_pro_admin_settings( $key, $default );
	}

	/**
	 * Digits-only form of a phone number.
	 *
	 * @since 2.10.0
	 * @param string $phone Phone number.
	 * @return string
	 */
	protected function digits( $phone ) {
		return preg_replace( '/[^0-9]/', '', (string) $phone );
	}

	/**
	 * E.164 form (leading +) of a phone number.
	 *
	 * @since 2.10.0
	 * @param string $phone Phone number.
	 * @return string
	 */
	protected function e164( $phone ) {
		$digits = $this->digits( $phone );
		return '' === $digits ? '' : '+' . $digits;
	}

	/**
	 * POST to a provider endpoint. Returns the response array or a WP_Error on a
	 * transport error.
	 *
	 * @since 2.10.0
	 * @param string $url  Endpoint URL.
	 * @param array  $args wp_safe_remote_post() args.
	 * @return array|WP_Error
	 */
	protected function post( $url, $args ) {
		$args = wp_parse_args(
			$args,
			array(
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
				'timeout'     => (int) apply_filters( 'cev_sms_http_timeout', 10 ),
				'redirection' => 0,
				'sslverify'   => true,
			)
		);

		$response = wp_safe_remote_post( esc_url_raw( $url ), $args );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'sms_http_error', $response->get_error_message() );
		}
		return $response;
	}

	/**
	 * Whether the driver has the credentials it needs.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	abstract public function is_configured();

	/**
	 * Send an SMS.
	 *
	 * @since 2.10.0
	 * @param string $to      Recipient phone number (international).
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	abstract public function send( $to, $message );
}
