<?php
/**
 * Smart Form — Vonage (Nexmo) SMS driver (Phase 5).
 *
 * Ported from the SMS for WooCommerce plugin's SMSWOO_Nexmo. Reads only the
 * cev_sms_vonage_* credentials.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_Vonage driver.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_SMS_Vonage extends CEV_SMS_Driver {

	/**
	 * Vonage SMS API endpoint.
	 *
	 * @var string
	 */
	const API_ENDPOINT = 'https://rest.nexmo.com/sms/json';

	/**
	 * Whether Vonage is configured.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_configured() {
		return '' !== (string) $this->setting( 'cev_sms_vonage_key' )
			&& '' !== (string) $this->setting( 'cev_sms_vonage_secret' );
	}

	/**
	 * Send via Vonage.
	 *
	 * @since 2.10.0
	 * @param string $to      Recipient phone number.
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	public function send( $to, $message ) {
		$key    = (string) $this->setting( 'cev_sms_vonage_key' );
		$secret = (string) $this->setting( 'cev_sms_vonage_secret' );

		if ( '' === $key || '' === $secret ) {
			return new WP_Error( 'sms_not_configured', __( 'Vonage is not configured. Add your API key and secret.', 'customer-email-verification' ) );
		}

		$body = http_build_query(
			array(
				'from'       => (string) $this->setting( 'cev_sms_vonage_sender' ),
				'to'         => $this->digits( $to ),
				'type'       => 'unicode',
				'text'       => $message,
				'api_key'    => $key,
				'api_secret' => $secret,
			)
		);

		$response = $this->post(
			self::API_ENDPOINT,
			array(
				'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( isset( $decoded['messages'][0]['status'] ) && 0 === (int) $decoded['messages'][0]['status'] ) {
			return true;
		}

		$message = isset( $decoded['messages'][0]['error-text'] ) ? $decoded['messages'][0]['error-text'] : __( 'The SMS could not be sent via Vonage.', 'customer-email-verification' );
		return new WP_Error( 'sms_send_failed', $message );
	}
}
