<?php
/**
 * Smart Form — Twilio SMS driver (Phase 5).
 *
 * Ported from the SMS for WooCommerce plugin's SMSWOO_Twilio. Sends a standard
 * text message via the Twilio REST API. Reads only the cev_sms_twilio_* creds.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_Twilio driver.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_SMS_Twilio extends CEV_SMS_Driver {

	/**
	 * Whether Twilio is configured.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_configured() {
		return '' !== (string) $this->setting( 'cev_sms_twilio_account_sid' )
			&& '' !== (string) $this->setting( 'cev_sms_twilio_auth_token' );
	}

	/**
	 * Send via Twilio.
	 *
	 * @since 2.10.0
	 * @param string $to      Recipient phone number.
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	public function send( $to, $message ) {
		$sid   = (string) $this->setting( 'cev_sms_twilio_account_sid' );
		$token = (string) $this->setting( 'cev_sms_twilio_auth_token' );

		if ( '' === $sid || '' === $token ) {
			return new WP_Error( 'sms_not_configured', __( 'Twilio is not configured. Add your Account SID and Auth Token.', 'customer-email-verification' ) );
		}

		$to = $this->e164( $to );

		if ( 'messaging_service_sid' === (string) $this->setting( 'cev_sms_twilio_send_via', 'phone_number' ) ) {
			$body = array(
				'MessagingServiceSid' => (string) $this->setting( 'cev_sms_twilio_messaging_service_sid' ),
				'To'                  => $to,
				'Body'                => $message,
			);
		} else {
			$from = (string) $this->setting( 'cev_sms_twilio_phone' );
			// A numeric sender becomes E.164; an alphanumeric sender ID is used as-is.
			$from = ( 1 === preg_match( '/^\d+$/', $from ) ) ? '+' . $from : $from;
			$body = array(
				'From' => $from,
				'To'   => $to,
				'Body' => $message,
			);
		}

		$endpoint = 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode( $sid ) . '/Messages.json';

		$response = $this->post(
			$endpoint,
			array(
				'headers' => array(
					// Base64 is required by the HTTP Basic auth scheme, not obfuscation.
					// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
					'Authorization' => 'Basic ' . base64_encode( $sid . ':' . $token ),
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 === $code || 201 === $code ) {
			return true;
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		$message = isset( $decoded['message'] ) ? $decoded['message'] : __( 'The SMS could not be sent via Twilio.', 'customer-email-verification' );
		return new WP_Error( 'sms_send_failed', $message );
	}
}
