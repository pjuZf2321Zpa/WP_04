<?php
/**
 * Smart Form — WhatsApp Business driver (Phase 5, net-new).
 *
 * Sends a text message via the WhatsApp Business Cloud API (Meta Graph). Reads
 * only the cev_sms_wa_* credentials (access token + phone-number ID).
 *
 * Note: the Cloud API only allows free-form TEXT inside the 24-hour customer
 * window; business-initiated OTP delivery requires an approved template. This
 * driver covers the text/test-send capability for Phase 5; template support is
 * a later refinement once the phone-verification flow (Phase 6) lands.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_WhatsApp driver.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_SMS_WhatsApp extends CEV_SMS_Driver {

	/**
	 * Graph API version.
	 *
	 * @var string
	 */
	const API_VERSION = 'v18.0';

	/**
	 * Whether WhatsApp is configured.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_configured() {
		return '' !== (string) $this->setting( 'cev_sms_wa_access_token' )
			&& '' !== (string) $this->setting( 'cev_sms_wa_sender' );
	}

	/**
	 * Send via WhatsApp Business Cloud API.
	 *
	 * @since 2.10.0
	 * @param string $to      Recipient phone number.
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	public function send( $to, $message ) {
		$token    = (string) $this->setting( 'cev_sms_wa_access_token' );
		$phone_id = (string) $this->setting( 'cev_sms_wa_sender' );

		if ( '' === $token || '' === $phone_id ) {
			return new WP_Error( 'sms_not_configured', __( 'WhatsApp is not configured. Add your access token and phone number ID.', 'customer-email-verification' ) );
		}

		$endpoint = 'https://graph.facebook.com/' . self::API_VERSION . '/' . rawurlencode( $phone_id ) . '/messages';

		$payload = array(
			'messaging_product' => 'whatsapp',
			'recipient_type'    => 'individual',
			'to'                => $this->digits( $to ),
			'type'              => 'text',
			'text'              => array(
				'preview_url' => false,
				'body'        => $message,
			),
		);

		$response = $this->post(
			$endpoint,
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code    = (int) wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 === $code && isset( $decoded['messages'] ) ) {
			return true;
		}

		$message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'The WhatsApp message could not be sent.', 'customer-email-verification' );
		return new WP_Error( 'sms_send_failed', $message );
	}
}
