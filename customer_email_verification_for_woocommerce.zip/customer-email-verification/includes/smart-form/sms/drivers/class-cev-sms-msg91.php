<?php
/**
 * Smart Form — MSG91 SMS driver (Phase 5).
 *
 * Ported from the SMS for WooCommerce plugin's SMSWOO_Msg91. Sends a standard
 * (non-DLT) message — the international number carries the country code, so
 * country is sent as 0. Reads only the cev_sms_msg91_* credentials.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_SMS_MSG91 driver.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_SMS_MSG91 extends CEV_SMS_Driver {

	/**
	 * MSG91 send-SMS endpoint.
	 *
	 * @var string
	 */
	const API_ENDPOINT = 'https://api.msg91.com/api/v2/sendsms';

	/**
	 * Whether MSG91 is configured.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function is_configured() {
		return '' !== (string) $this->setting( 'cev_sms_msg91_auth_key' );
	}

	/**
	 * Send via MSG91.
	 *
	 * @since 2.10.0
	 * @param string $to      Recipient phone number.
	 * @param string $message Message body.
	 * @return true|WP_Error
	 */
	public function send( $to, $message ) {
		$authkey = (string) $this->setting( 'cev_sms_msg91_auth_key' );

		if ( '' === $authkey ) {
			return new WP_Error( 'sms_not_configured', __( 'MSG91 is not configured. Add your authentication key.', 'customer-email-verification' ) );
		}

		$payload = array(
			'sender'  => (string) $this->setting( 'cev_sms_msg91_sender' ),
			'route'   => '4',
			'country' => '0',
			'sms'     => array(
				array(
					'message' => $message,
					'to'      => array( $this->digits( $to ) ),
				),
			),
		);

		$response = $this->post(
			self::API_ENDPOINT,
			array(
				'headers' => array(
					'authkey'      => $authkey,
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 === $code || 201 === $code ) {
			return true;
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		$message = isset( $decoded['message'] ) ? $decoded['message'] : __( 'The SMS could not be sent via MSG91.', 'customer-email-verification' );
		return new WP_Error( 'sms_send_failed', $message );
	}
}
