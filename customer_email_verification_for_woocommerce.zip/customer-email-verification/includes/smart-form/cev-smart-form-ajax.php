<?php
/**
 * Smart Form — AJAX handlers (Phase 3: email registration + OTP verify).
 *
 * Wires the Smart Form Register form's registration flow end-to-end:
 *   1. register()        — validates + stores pending data in a transient, sends OTP.
 *                          The account is NOT created here. Store-side registration
 *                          validation (woocommerce_registration_errors /
 *                          registration_errors) runs HERE, before any code is sent.
 *   2. verify_register() — verifies the OTP, THEN calls wc_create_new_customer().
 *                          Only a confirmed OTP produces a wp_users row.
 *   3. resend_register() — re-sends the OTP using the pending transient (no user_id).
 *
 * OTP storage (pre-account):
 *   - Email channel: CEV_Signup_Email writes to cev_user_log keyed by email address.
 *   - SMS channel:   cev_sf_sms_otp_{md5(email)} transient stores {pin, enddate}.
 *   - Pending data:  cev_sf_reg_{md5(email)} transient stores {password, phone, …}.
 *
 * Email validation reuses:
 *   - CEV_Email_Validation     — disposable / MX / allow-blocklist spam checks.
 *   - auto_verify_user_on_registration() hook — sets customer_email_verified via
 *     cev_signup_email_verified_{md5(email)} transient set before account creation,
 *     honouring Paid-Order Gatekeeping ('true' / 'pending_paid_order').
 *
 * Phone (SMS) registration (Phase 6) delivers the same OTP via
 * CEV_SMS_Compat::deliver_sms() (Phase 11: routes to the SMS-for-WooCommerce
 * plugin when active, else the native gateway). reCAPTCHA rendering is
 * intentionally not handled here.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Smart_Form_Ajax Class.
 *
 * Singleton. Registers the priv + nopriv AJAX endpoints for the Smart Form
 * email-registration flow.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Smart_Form_Ajax {

	/**
	 * Nonce action shared with the Smart Form front-end config.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'cev_smart_form_nonce';

	/**
	 * Canonical phone-number user meta key — the verified login phone, written by
	 * SMS registration and reused by Phone OTP login (Phase 7) / backfill (7.5).
	 *
	 * @var string
	 */
	const PHONE_META = 'cev_phone';

	/**
	 * Background action that sends the WooCommerce "account created" welcome
	 * email out-of-band (Action Scheduler / WP-Cron), so a slow SMTP server
	 * can't hold the registration request open and trip a 504.
	 *
	 * @var string
	 */
	const WELCOME_EMAIL_ACTION = 'cev_smart_form_send_welcome_email';

	/**
	 * Single instance of this class.
	 *
	 * @var CEV_Smart_Form_Ajax|null
	 */
	private static $instance = null;

	/**
	 * Retrieve the singleton instance.
	 *
	 * @since 2.10.0
	 * @return CEV_Smart_Form_Ajax
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — register the AJAX endpoints (logged-out + logged-in).
	 *
	 * @since 2.10.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_nopriv_cev_smart_register', array( $this, 'register' ) );
		add_action( 'wp_ajax_cev_smart_register', array( $this, 'register' ) );
		add_action( 'wp_ajax_nopriv_cev_smart_verify_register', array( $this, 'verify_register' ) );
		add_action( 'wp_ajax_cev_smart_verify_register', array( $this, 'verify_register' ) );
		add_action( 'wp_ajax_nopriv_cev_smart_resend_register', array( $this, 'resend_register' ) );
		add_action( 'wp_ajax_cev_smart_resend_register', array( $this, 'resend_register' ) );

		// Login (Phase 4): password + email-OTP.
		add_action( 'wp_ajax_nopriv_cev_smart_login', array( $this, 'login' ) );
		add_action( 'wp_ajax_cev_smart_login', array( $this, 'login' ) );
		add_action( 'wp_ajax_nopriv_cev_smart_login_otp_request', array( $this, 'login_otp_request' ) );
		add_action( 'wp_ajax_cev_smart_login_otp_request', array( $this, 'login_otp_request' ) );
		add_action( 'wp_ajax_nopriv_cev_smart_login_otp_verify', array( $this, 'login_otp_verify' ) );
		add_action( 'wp_ajax_cev_smart_login_otp_verify', array( $this, 'login_otp_verify' ) );

		// Out-of-band welcome email (keeps SMTP latency off the register request).
		add_action( self::WELCOME_EMAIL_ACTION, array( $this, 'dispatch_new_account_email' ) );
	}

	/**
	 * AJAX: validate the registration data and send the OTP. The account is NOT
	 * created here — it is created only after the OTP is confirmed in
	 * verify_register(), so no orphaned users are left if the visitor abandons.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function register() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::NONCE_ACTION ) ) {
			CEV_Ajax_Response::send_nonce_error();
			return;
		}

		$reg_method = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_reg_method', 'email' );

		// Third-party captcha (e.g. All In One WP Security) injected via the WC
		// register-form hook — validate it before doing anything else.
		$captcha_error = $this->third_party_captcha_error( 'register' );
		if ( is_wp_error( $captcha_error ) ) {
			CEV_Ajax_Response::send_error( $captcha_error->get_error_code(), $captcha_error->get_error_message() );
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$password = '';
		// Passwords are used verbatim — do NOT sanitize_text_field (it can mangle valid characters).
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		if ( isset( $_POST['password'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$password = (string) wp_unslash( $_POST['password'] );
		}

		if ( ! is_email( $email ) ) {
			CEV_Ajax_Response::send_invalid_email_error( $email );
			return;
		}

		// Spam protection: disposable / MX / allow-blocklist (reused engine).
		if ( class_exists( 'CEV_Email_Validation' ) ) {
			$preflight = CEV_Email_Validation::get_instance()->validate( $email, 'signup' );
			if ( is_wp_error( $preflight ) ) {
				CEV_Ajax_Response::send_error( $preflight->get_error_code(), $preflight->get_error_message(), array( 'email' => $email ) );
				return;
			}
		}

		// Existing account — point them to login rather than failing silently.
		if ( email_exists( $email ) ) {
			CEV_Ajax_Response::send_error(
				'email_exists',
				__( 'An account with this email already exists. Please log in instead.', 'customer-email-verification' ),
				array( 'email' => $email )
			);
			return;
		}

		// The Smart Form register form always collects a password (mandatory),
		// regardless of the login method, so require it server-side too.
		if ( '' === $password ) {
			CEV_Ajax_Response::send_missing_field_error( 'password' );
			return;
		}

		// Enforce the configured password policy (strong rule + minimum length,
		// filterable via cev_smart_form_password_is_strong). The message mirrors the
		// browser hint so client and server always agree.
		if ( ! $this->is_strong_password( $password ) ) {
			CEV_Ajax_Response::send_error(
				'weak_password',
				CEV_Smart_Form::password_error_message()
			);
			return;
		}

		// Phone number — shown / required per the admin settings (always required
		// for phone-SMS registration).
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$phone          = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$phone_shown    = ( 'phone' === $reg_method ) || ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_show_phone_field', 0 ) );
		$phone_required = ( 'phone' === $reg_method ) || ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_phone_required', 0 ) );
		if ( $phone_required && '' === $phone ) {
			CEV_Ajax_Response::send_missing_field_error( 'phone' );
			return;
		}

		// Phone (SMS) registration: validate the number and confirm a provider is
		// configured BEFORE creating the account — never create one we cannot
		// verify, and never fatal when SMS is unavailable.
		$use_sms    = ( 'phone' === $reg_method );
		$phone_e164 = '';
		if ( $use_sms ) {
			$phone_e164 = self::normalize_phone( $phone );
			if ( '' === $phone_e164 ) {
				CEV_Ajax_Response::send_error( 'invalid_phone', __( 'Please enter a valid phone number, including your country code.', 'customer-email-verification' ) );
				return;
			}
			// Phone is a login credential (Phone OTP) — it must be unique.
			if ( self::phone_exists( $phone_e164 ) ) {
				CEV_Ajax_Response::send_error( 'phone_exists', __( 'This phone number is already linked to an account. Please log in or use a different number.', 'customer-email-verification' ), array( 'phone' => $phone ) );
				return;
			}
			if ( ! CEV_SMS_Compat::has_backend() ) {
				CEV_Ajax_Response::send_error( 'sms_unavailable', __( 'Phone verification is temporarily unavailable. Please try again later or contact the store.', 'customer-email-verification' ) );
				return;
			}
		}

		// Per-IP OTP-send cap — stops one network from spraying codes.
		$rate = $this->check_ip_send_rate( $use_sms ? 'sms' : 'email' );
		if ( is_wp_error( $rate ) ) {
			CEV_Ajax_Response::send_error( $rate->get_error_code(), $rate->get_error_message(), array( 'email' => $email ) );
			return;
		}

		// Developer-registered custom fields (via the cev_smart_form_custom_fields
		// filter). Read raw here — the nonce is already verified above — then
		// validate + sanitize per field in a pure helper. Values ride the pending
		// transient and are written to the account only after OTP confirmation.
		$custom_raw = array();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		if ( isset( $_POST['cev_cf'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$custom_post = wp_unslash( $_POST['cev_cf'] );
			if ( is_array( $custom_post ) ) {
				$custom_raw = $custom_post;
			}
		}
		$custom_values = $this->validate_custom_fields( $custom_raw );
		if ( is_wp_error( $custom_values ) ) {
			CEV_Ajax_Response::send_error( $custom_values->get_error_code(), $custom_values->get_error_message() );
			return;
		}

		// Mirror the custom values onto the field names a standard WooCommerce
		// register form would have posted, so store-side validation sees them.
		$this->expose_custom_fields_to_post( $custom_values );

		// Let the store reject the registration BEFORE a code is sent. The account
		// is only created after OTP confirmation, so without this a store that adds
		// required registration fields fails once the customer has already entered
		// their code, with no way forward.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		if ( apply_filters( 'cev_smart_form_pre_validate_registration', true, $email ) ) {
			$registration_errors = $this->validate_registration( $email );

			if ( is_wp_error( $registration_errors ) && $registration_errors->get_error_code() ) {
				CEV_Ajax_Response::send_error(
					$registration_errors->get_error_code(),
					wp_strip_all_tags( (string) $registration_errors->get_error_message() ),
					array( 'email' => $email )
				);
				return;
			}
		}

		// Store validated registration data so verify_register() can create the
		// account after OTP confirmation. TTL matches the OTP window (10 min).
		$pending_key = 'cev_sf_reg_' . md5( strtolower( $email ) );
		set_transient(
			$pending_key,
			array(
				'password'    => $password,
				'phone'       => $phone,
				'phone_e164'  => $phone_e164,
				'phone_shown' => $phone_shown,
				'use_sms'     => $use_sms,
				'custom'      => $custom_values,
			),
			620
		);

		// Send OTP without creating the account yet.
		$delivery = $this->deliver_pre_account_otp( $email, $phone_e164, $use_sms );
		if ( is_wp_error( $delivery ) ) {
			delete_transient( $pending_key );
			CEV_Ajax_Response::send_error( $delivery->get_error_code(), $delivery->get_error_message(), array( 'email' => $email ) );
			return;
		}

		CEV_Ajax_Response::send_success(
			array(
				'email'       => $email,
				'step'        => 'otp',
				'channel'     => $use_sms ? 'sms' : 'email',
				'destination' => $use_sms ? $this->mask_phone( $phone_e164 ) : $email,
			),
			$use_sms
				? __( 'We have sent a verification code to your phone.', 'customer-email-verification' )
				: __( 'We have emailed you a verification code.', 'customer-email-verification' ),
			'otp_sent'
		);
	}

	/**
	 * AJAX: verify the OTP then create the account (set verified + auto-login).
	 * The account is created ONLY here, after OTP confirmation, so no orphaned
	 * users are left when the visitor closes the popup without verifying.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function verify_register() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::NONCE_ACTION ) ) {
			CEV_Ajax_Response::send_nonce_error();
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$code = isset( $_POST['otp'] ) ? preg_replace( '/[^0-9]/', '', sanitize_text_field( wp_unslash( $_POST['otp'] ) ) ) : '';

		if ( ! is_email( $email ) ) {
			CEV_Ajax_Response::send_invalid_email_error( $email );
			return;
		}
		if ( '' === $code ) {
			CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
			return;
		}

		// Retrieve the pending registration data stored by register().
		$pending_key = 'cev_sf_reg_' . md5( strtolower( $email ) );
		$pending     = get_transient( $pending_key );
		if ( ! is_array( $pending ) ) {
			CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
			return;
		}

		$use_sms      = ! empty( $pending['use_sms'] );
		$phone_e164   = isset( $pending['phone_e164'] ) ? (string) $pending['phone_e164'] : '';
		$attempts_key = 'cev_sf_failed_' . md5( strtolower( $email ) );

		if ( $use_sms ) {
			// SMS: verify against the pre-account OTP transient.
			$sms_key = 'cev_sf_sms_otp_' . md5( strtolower( $email ) );
			$stored  = get_transient( $sms_key );
			if ( ! is_array( $stored ) || empty( $stored['pin'] ) ) {
				CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
				return;
			}
			if ( ! empty( $stored['enddate'] ) && time() > (int) $stored['enddate'] ) {
				CEV_Ajax_Response::send_invalid_code_error( 'expired' );
				return;
			}
			if ( (string) $code !== (string) $stored['pin'] ) {
				$failed = (int) get_transient( $attempts_key ) + 1;
				if ( method_exists( cev_pro()->function, 'log_event' ) ) {
					cev_pro()->function->log_event( $email, 'otp_failed', 'signup' );
				}
				if ( 5 <= $failed ) {
					delete_transient( $sms_key );
					delete_transient( $attempts_key );
					CEV_Ajax_Response::send_invalid_code_error( 'max_attempts' );
					return;
				}
				set_transient( $attempts_key, $failed, HOUR_IN_SECONDS );
				CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
				return;
			}
			// Correct SMS OTP — remove the OTP transient.
			delete_transient( $sms_key );
		} else {
			// Email: verify against the cev_user_log record written by deliver_pre_account_otp().
			global $wpdb;
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}cev_user_log WHERE email = %s AND pin = %s",
					$email,
					$code
				)
			);
			// phpcs:enable

			if ( ! $row ) {
				$failed = (int) get_transient( $attempts_key ) + 1;
				if ( method_exists( cev_pro()->function, 'log_event' ) ) {
					cev_pro()->function->log_event( $email, 'otp_failed', 'signup' );
				}
				if ( 5 <= $failed ) {
					// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->delete( $wpdb->prefix . 'cev_user_log', array( 'email' => $email ), array( '%s' ) );
					// phpcs:enable
					delete_transient( $attempts_key );
					CEV_Ajax_Response::send_invalid_code_error( 'max_attempts' );
					return;
				}
				set_transient( $attempts_key, $failed, HOUR_IN_SECONDS );
				CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
				return;
			}

			// Check expiration (mirrors the signup popup logic).
			$expiration_setting = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_expiration', 'never' );
			if ( 'never' !== $expiration_setting && ! empty( $row->last_updated ) ) {
				$elapsed = current_time( 'timestamp' ) - (int) strtotime( $row->last_updated );
				if ( $elapsed > (int) $expiration_setting ) {
					CEV_Ajax_Response::send_invalid_code_error( 'expired' );
					return;
				}
			}

			// Clean up the email log record.
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->delete( $wpdb->prefix . 'cev_user_log', array( 'email' => $email ), array( '%s' ) );
			// phpcs:enable
		}

		// OTP confirmed — clean up shared counters.
		delete_transient( $attempts_key );
		delete_transient( 'cev_sf_resend_' . md5( strtolower( $email ) ) );

		// Mark the email as pre-verified so auto_verify_user_on_registration()
		// sets customer_email_verified correctly (honouring Paid-Order Gatekeeping).
		$verified_transient_key = 'cev_signup_email_verified_' . md5( strtolower( $email ) );
		set_transient( $verified_transient_key, true, HOUR_IN_SECONDS );

		// Mirror the held custom values onto the conventional register-form field
		// names before the account exists, so third-party validation and
		// woocommerce_created_customer handlers see them.
		if ( isset( $pending['custom'] ) && is_array( $pending['custom'] ) ) {
			$this->expose_custom_fields_to_post( $pending['custom'] );
		}

		// NOW create the account — OTP already confirmed above.
		$user_id = wc_create_new_customer( $email, '', $pending['password'] );
		if ( is_wp_error( $user_id ) ) {
			delete_transient( $verified_transient_key );
			CEV_Ajax_Response::send_error( $user_id->get_error_code(), $user_id->get_error_message(), array( 'email' => $email ) );
			return;
		}
		$user_id = (int) $user_id;

		// Clean up the pending registration transient.
		delete_transient( $pending_key );

		// Phone meta — store for billing and Phone OTP login (Phase 7).
		if ( $use_sms && '' !== $phone_e164 ) {
			update_user_meta( $user_id, self::PHONE_META, $phone_e164 );
			if ( isset( $pending['phone'] ) && '' !== $pending['phone'] ) {
				update_user_meta( $user_id, 'billing_phone', $pending['phone'] );
			}
		} elseif ( ! $use_sms && isset( $pending['phone'] ) && '' !== $pending['phone'] ) {
			update_user_meta( $user_id, 'billing_phone', $pending['phone'] );
		}

		// Persist developer-registered custom fields to the new account.
		if ( isset( $pending['custom'] ) && is_array( $pending['custom'] ) && ! empty( $pending['custom'] ) ) {
			$this->save_custom_fields( $user_id, $pending['custom'] );
		}

		// Analytics — read the state auto_verify_user_on_registration() wrote.
		if ( method_exists( cev_pro()->function, 'log_event' ) ) {
			$new_state = (string) get_user_meta( $user_id, 'customer_email_verified', true );
			cev_pro()->function->log_event( $email, 'otp_verified', 'signup', array(), $user_id );
			if ( 'pending_paid_order' === $new_state ) {
				cev_pro()->function->log_event( $email, 'verification_pending_paid_order', 'signup', array(), $user_id );
			}
		}

		$this->send_new_account_email( $user_id );
		$this->maybe_auto_login( $user_id );

		CEV_Ajax_Response::send_success(
			array(
				'verified'     => true,
				'redirect_url' => $this->redirect_url( $user_id ),
			),
			__( 'Your email has been verified.', 'customer-email-verification' ),
			'verified'
		);
	}

	/**
	 * AJAX: resend the registration OTP (honours the admin resend limit).
	 * Uses the pending-registration transient — no account exists yet.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function resend_register() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::NONCE_ACTION ) ) {
			CEV_Ajax_Response::send_nonce_error();
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! is_email( $email ) ) {
			CEV_Ajax_Response::send_invalid_email_error( $email );
			return;
		}

		// Session must be live — pending data proves register() was called first.
		$pending_key = 'cev_sf_reg_' . md5( strtolower( $email ) );
		$pending     = get_transient( $pending_key );
		if ( ! is_array( $pending ) ) {
			CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
			return;
		}

		// Per-email resend limit (transient-based; no user_id available yet).
		$resend_key   = 'cev_sf_resend_' . md5( strtolower( $email ) );
		$resend_limit = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_redirect_limit_resend', 1 );
		$resend_count = (int) get_transient( $resend_key );
		if ( 0 < $resend_limit && $resend_count >= $resend_limit ) {
			CEV_Ajax_Response::send_limit_reached_error( $resend_limit );
			return;
		}

		$use_sms    = ! empty( $pending['use_sms'] );
		$phone_e164 = isset( $pending['phone_e164'] ) ? (string) $pending['phone_e164'] : '';

		$rate = $this->check_ip_send_rate( $use_sms ? 'sms' : 'email' );
		if ( is_wp_error( $rate ) ) {
			CEV_Ajax_Response::send_error( $rate->get_error_code(), $rate->get_error_message() );
			return;
		}

		$delivery = $this->deliver_pre_account_otp( $email, $phone_e164, $use_sms );
		if ( is_wp_error( $delivery ) ) {
			CEV_Ajax_Response::send_error( $delivery->get_error_code(), $delivery->get_error_message() );
			return;
		}

		set_transient( $resend_key, $resend_count + 1, 620 );

		CEV_Ajax_Response::send_success(
			array( 'email' => $email ),
			__( 'A new verification code has been sent.', 'customer-email-verification' ),
			'email_sent'
		);
	}

	/**
	 * AJAX: password login. Authenticates via wp_signon() so security plugins and
	 * the login-authentication module still apply, then signs the customer in. An
	 * unverified customer is logged in normally — the existing "verify on login"
	 * prompt (if enabled) handles verification on the next page load.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function login() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::NONCE_ACTION ) ) {
			CEV_Ajax_Response::send_nonce_error();
			return;
		}

		$captcha_error = $this->third_party_captcha_error( 'login' );
		if ( is_wp_error( $captcha_error ) ) {
			CEV_Ajax_Response::send_error( $captcha_error->get_error_code(), $captcha_error->get_error_message() );
			return;
		}

		// Only accept password sign-in when the admin has it enabled.
		if ( ! in_array( 'password', CEV_Smart_Form::enabled_login_methods(), true ) ) {
			CEV_Ajax_Response::send_error( 'password_login_disabled', __( 'Password sign-in is not available.', 'customer-email-verification' ) );
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$login    = isset( $_POST['login'] ) ? sanitize_text_field( wp_unslash( $_POST['login'] ) ) : '';
		$password = '';
		// Passwords are used verbatim — do NOT sanitize_text_field.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		if ( isset( $_POST['password'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$password = (string) wp_unslash( $_POST['password'] );
		}

		if ( '' === $login || '' === $password ) {
			CEV_Ajax_Response::send_error( 'missing_credentials', __( 'Please enter your email/username and password.', 'customer-email-verification' ) );
			return;
		}

		$user = wp_signon(
			array(
				'user_login'    => $login,
				'user_password' => $password,
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			$code              = $user->get_error_code();
			$credential_errors = array( 'incorrect_password', 'invalid_username', 'invalid_email', 'authentication_failed', 'empty_password', 'empty_username' );
			$message           = in_array( $code, $credential_errors, true )
				? __( 'The email/username or password you entered is incorrect.', 'customer-email-verification' )
				: wp_strip_all_tags( $user->get_error_message() );
			CEV_Ajax_Response::send_error( 'login_failed', $message );
			return;
		}

		// wp_signon already set the auth cookie; ensure the WC customer session too.
		if ( function_exists( 'wc_set_customer_auth_cookie' ) ) {
			wc_set_customer_auth_cookie( $user->ID );
		}

		CEV_Ajax_Response::send_success(
			array( 'redirect_url' => $this->redirect_url( $user->ID ) ),
			__( 'You are now logged in.', 'customer-email-verification' ),
			'logged_in'
		);
	}

	/**
	 * AJAX: email-OTP login — send a one-time sign-in code. Returns a generic
	 * response (no account enumeration) and honours the admin resend limit.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function login_otp_request() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::NONCE_ACTION ) ) {
			CEV_Ajax_Response::send_nonce_error();
			return;
		}

		$captcha_error = $this->third_party_captcha_error( 'login' );
		if ( is_wp_error( $captcha_error ) ) {
			CEV_Ajax_Response::send_error( $captcha_error->get_error_code(), $captcha_error->get_error_message() );
			return;
		}

		// Only accept code sign-in when Email OTP or Phone OTP is enabled.
		$otp_login_enabled = (bool) array_intersect( array( 'email_otp', 'phone_otp' ), CEV_Smart_Form::enabled_login_methods() );
		if ( ! $otp_login_enabled ) {
			CEV_Ajax_Response::send_error( 'otp_login_disabled', __( 'Code sign-in is not available.', 'customer-email-verification' ) );
			return;
		}

		// Identifier-first: the visitor enters their email, username, or phone.
		// The initial request posts the login field; the popup "resend" posts email.
		$is_resend = false;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$identifier = isset( $_POST['login'] ) ? sanitize_text_field( wp_unslash( $_POST['login'] ) ) : '';
		if ( '' === $identifier ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
			$identifier = isset( $_POST['email'] ) ? sanitize_text_field( wp_unslash( $_POST['email'] ) ) : '';
			$is_resend  = true;
		}

		if ( '' === $identifier ) {
			CEV_Ajax_Response::send_error( 'missing_login', __( 'Please enter your email, username, or phone number.', 'customer-email-verification' ) );
			return;
		}

		// Delivery channel. Phone delivery is honoured ONLY when Phone OTP is one
		// of the enabled login methods AND an SMS backend is configured; any
		// other case (including a crafted request) falls back to email, the
		// documented universal fallback.
		$enabled_methods = CEV_Smart_Form::enabled_login_methods();
		$sms_ready       = class_exists( 'CEV_SMS_Compat' ) ? CEV_SMS_Compat::has_backend() : false;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$requested_channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';
		if ( 'phone' === $requested_channel && in_array( 'phone_otp', $enabled_methods, true ) && $sms_ready ) {
			$channel = 'phone';
		} else {
			$channel = 'email';
		}

		// Sign-in codes are throttled per identifier, NOT by the shared
		// cev_user_resend_times counter: that counter is also raised by other
		// flows and only cleared on a successful verify, so with the default
		// limit of 1 every request after the first silently sent nothing.
		$send_state = $this->login_otp_send_state( $identifier, $is_resend );
		if ( is_wp_error( $send_state ) ) {
			CEV_Ajax_Response::send_limit_reached_error();
			return;
		}

		$user = $this->resolve_login_user( $identifier );

		if ( 'phone' === $channel ) {
			// Phone OTP — the entered number must belong to an account that has a
			// phone on file, with a provider configured. Per the admin's chosen UX
			// we tell the visitor when it does not, so they can correct the number
			// or switch to Email OTP. (This intentionally reveals phone-on-file
			// status for the number that was typed.)
			$has_phone = $user ? ( '' !== (string) get_user_meta( $user->ID, self::PHONE_META, true ) ) : false;
			if ( ! $user || ! $has_phone || ! CEV_SMS_Compat::has_backend() ) {
				CEV_Ajax_Response::send_error(
					'phone_not_linked',
					__( 'This phone number is not associated with any account. Please use a different phone number or switch to Email OTP login.', 'customer-email-verification' )
				);
				return;
			}

			if ( $send_state && ! is_wp_error( $this->check_ip_send_rate( 'sms' ) ) ) {
				$phone = (string) get_user_meta( $user->ID, self::PHONE_META, true );
				$pin   = (string) cev_pro()->function->store_verification_pin( $user->ID );
				if ( '' !== $pin ) {
					/* translators: %s = the verification code. */
					$message = sprintf( __( 'Your verification code is %s', 'customer-email-verification' ), $pin );
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
					$message = (string) apply_filters( 'cev_smart_form_sms_otp_message', $message, $pin, $user->ID );
					if ( ! is_wp_error( CEV_SMS_Compat::deliver_sms( $phone, $message ) ) ) {
						$this->record_login_otp_send( $identifier, $is_resend );
						if ( method_exists( cev_pro()->function, 'log_event' ) ) {
							cev_pro()->function->log_event( $user->user_email, 'otp_sent', 'login', array(), $user->ID );
						}
					}
				}
			}

			CEV_Ajax_Response::send_success(
				array(
					'login'       => $identifier,
					'step'        => 'otp',
					'channel'     => 'sms',
					'destination' => $this->display_identifier( $identifier ),
				),
				__( 'We have sent a sign-in code to your phone.', 'customer-email-verification' ),
				'otp_sent'
			);
			return;
		}

		// Email OTP (default, or the manual switch). Non-enumerating: the same
		// response whether or not the account exists. The popup carries the
		// identifier for verify/resend; the shown destination is derived only
		// from what the visitor typed.
		// The send is recorded whether or not the account exists, so the
		// resend limit behaves the same for unknown identifiers.
		if ( $send_state && ! is_wp_error( $this->check_ip_send_rate( 'email' ) ) ) {
			$this->record_login_otp_send( $identifier, $is_resend );
			if ( $user ) {
				cev_pro()->function->wuev_user_id          = $user->ID;
				cev_pro()->function->registered_user_email = $user->user_email;
				if ( cev_pro()->function->code_mail_sender( $user->user_email, 'email_account_verify' ) && method_exists( cev_pro()->function, 'log_event' ) ) {
					cev_pro()->function->log_event( $user->user_email, 'otp_sent', 'login', array(), $user->ID );
				}
			}
		}

		CEV_Ajax_Response::send_success(
			array(
				'login'       => $identifier,
				'step'        => 'otp',
				'channel'     => 'email',
				'destination' => $this->display_identifier( $identifier ),
			),
			__( 'If an account exists, we have sent you a sign-in code.', 'customer-email-verification' ),
			'otp_sent'
		);
	}

	/**
	 * AJAX: email-OTP login — verify the code and sign the customer in. The OTP
	 * proves email ownership, so an unverified account is also marked verified.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function login_otp_verify() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), self::NONCE_ACTION ) ) {
			CEV_Ajax_Response::send_nonce_error();
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$identifier = isset( $_POST['email'] ) ? sanitize_text_field( wp_unslash( $_POST['email'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$code = isset( $_POST['otp'] ) ? preg_replace( '/[^0-9]/', '', sanitize_text_field( wp_unslash( $_POST['otp'] ) ) ) : '';

		if ( '' === $identifier ) {
			CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
			return;
		}
		if ( '' === $code ) {
			CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
			return;
		}

		$user = $this->resolve_login_user( $identifier );
		if ( ! $user ) {
			CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
			return;
		}
		$user_id      = (int) $user->ID;
		$stored       = get_user_meta( $user_id, 'cev_email_verification_pin', true );
		$attempts_key = 'cev_sf_login_failed_' . $user_id;

		if ( ! is_array( $stored ) || empty( $stored['pin'] ) ) {
			CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
			return;
		}
		if ( ! empty( $stored['enddate'] ) && time() > (int) $stored['enddate'] ) {
			CEV_Ajax_Response::send_invalid_code_error( 'expired' );
			return;
		}
		if ( (string) $code !== (string) $stored['pin'] ) {
			$failed = (int) get_transient( $attempts_key ) + 1;
			if ( 5 <= $failed ) {
				delete_user_meta( $user_id, 'cev_email_verification_pin' );
				delete_transient( $attempts_key );
				CEV_Ajax_Response::send_invalid_code_error( 'max_attempts' );
				return;
			}
			set_transient( $attempts_key, $failed, HOUR_IN_SECONDS );
			CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
			return;
		}

		// Correct — clear the code, mark verified (OTP proves ownership), sign in.
		delete_user_meta( $user_id, 'cev_email_verification_pin' );
		delete_user_meta( $user_id, 'cev_user_resend_times' );
		delete_transient( $attempts_key );
		$this->clear_login_otp_sends( $identifier );

		if ( ! cev_pro()->function->is_user_email_verified( $user_id ) ) {
			update_user_meta( $user_id, 'customer_email_verified', cev_pro()->function->resolve_post_verification_state( $user_id ) );
		}

		if ( method_exists( cev_pro()->function, 'log_event' ) ) {
			cev_pro()->function->log_event( $user->user_email, 'otp_verified', 'login', array(), $user_id );
		}

		// SECURITY: this OTP proves email/phone ownership, but is NOT the
		// account's second factor. Smart Form's OTP login authenticates
		// directly (no wp_signon()), so it never passes through the
		// `authenticate` filter that CEV_2FA_Login::gate_login() uses to
		// challenge password logins. Without this check, a customer with
		// Authenticator App 2FA enabled could be signed in here without
		// ever being asked for their 2FA code. Park them and send the
		// browser to the same 2FA challenge instead of completing login.
		if ( class_exists( 'CEV_2FA_Manager' ) && class_exists( 'CEV_2FA_Login' ) ) {
			$cev_sf_2fa_mgr = CEV_2FA_Manager::instance();
			if ( $cev_sf_2fa_mgr->is_enabled_globally() && $cev_sf_2fa_mgr->is_enrolled( $user_id ) ) {
				CEV_Ajax_Response::send_success(
					array(
						'redirect_url' => CEV_2FA_Login::build_park_url( $user ),
						'requires_2fa' => true,
					),
					__( 'Enter your authenticator code to finish signing in.', 'customer-email-verification' ),
					'2fa_required'
				);
				return;
			}
		}

		if ( function_exists( 'wc_set_customer_auth_cookie' ) ) {
			wc_set_customer_auth_cookie( $user_id );
		} else {
			// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified OTP factor; wp_signon() needs a password.
			wp_set_current_user( $user_id );
			// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified OTP factor; wp_signon() needs a password.
			wp_set_auth_cookie( $user_id, true ); // nosemgrep: audit.php.wp.security.auth-bypass.wp-set-auth-cookie -- $user_id is the account resolved AND OTP-verified above, not raw request input.
		}

		CEV_Ajax_Response::send_success(
			array( 'redirect_url' => $this->redirect_url( $user_id ) ),
			__( 'You are now logged in.', 'customer-email-verification' ),
			'logged_in'
		);
	}

	/**
	 * Transient key for the sign-in code throttle state of one identifier.
	 *
	 * @since 3.0.6
	 * @param string $prefix     Key prefix (which counter).
	 * @param string $identifier The email, username, or phone the visitor typed.
	 * @return string
	 */
	private function login_otp_key( $prefix, $identifier ) {
		return $prefix . md5( strtolower( trim( (string) $identifier ) ) );
	}

	/**
	 * Whether a sign-in code request may send a fresh code.
	 *
	 * Each "Sign in" click starts a new attempt and gets a code, except within
	 * the resend delay of the previous one (that code is still valid, so it is
	 * not replaced) or past the hourly cap. Popup resends within an attempt
	 * honour the admin "Verification Email Resend Limit".
	 *
	 * @since 3.0.6
	 * @param string $identifier The email, username, or phone the visitor typed.
	 * @param bool   $is_resend  Whether the request is the popup "Resend code".
	 * @return bool|WP_Error True to send, false to keep the code just sent, WP_Error when a limit is reached.
	 */
	private function login_otp_send_state( $identifier, $is_resend ) {
		if ( $is_resend ) {
			$limit = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_redirect_limit_resend', 1 );
			$count = (int) get_transient( $this->login_otp_key( 'cev_sf_login_resends_', $identifier ) );
			return ( $count >= $limit ) ? new WP_Error( 'limit_reached' ) : true;
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$hourly_max = (int) apply_filters( 'cev_smart_form_login_otp_hourly_max', 10 );
		$sent_count = (int) get_transient( $this->login_otp_key( 'cev_sf_login_sends_', $identifier ) );
		if ( 0 < $hourly_max && $sent_count >= $hourly_max ) {
			return new WP_Error( 'limit_reached' );
		}

		return false === get_transient( $this->login_otp_key( 'cev_sf_login_sent_', $identifier ) );
	}

	/**
	 * Record that a sign-in code was sent for an identifier.
	 *
	 * @since 3.0.6
	 * @param string $identifier The email, username, or phone the visitor typed.
	 * @param bool   $is_resend  Whether the request is the popup "Resend code".
	 * @return void
	 */
	private function record_login_otp_send( $identifier, $is_resend ) {
		$resend_key = $this->login_otp_key( 'cev_sf_login_resends_', $identifier );
		if ( $is_resend ) {
			set_transient( $resend_key, (int) get_transient( $resend_key ) + 1, HOUR_IN_SECONDS );
			return;
		}

		// A new attempt gets the full resend allowance again.
		delete_transient( $resend_key );

		$sends_key = $this->login_otp_key( 'cev_sf_login_sends_', $identifier );
		set_transient( $sends_key, (int) get_transient( $sends_key ) + 1, HOUR_IN_SECONDS );

		// Same delay as the popup's "Resend code" countdown.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$cooldown = (int) apply_filters( 'cev_smart_form_resend_delay', 30 );
		if ( 0 < $cooldown ) {
			set_transient( $this->login_otp_key( 'cev_sf_login_sent_', $identifier ), time(), $cooldown );
		}
	}

	/**
	 * Clear the sign-in code throttle state after a successful sign-in.
	 *
	 * @since 3.0.6
	 * @param string $identifier The email, username, or phone the visitor typed.
	 * @return void
	 */
	private function clear_login_otp_sends( $identifier ) {
		delete_transient( $this->login_otp_key( 'cev_sf_login_resends_', $identifier ) );
		delete_transient( $this->login_otp_key( 'cev_sf_login_sends_', $identifier ) );
		delete_transient( $this->login_otp_key( 'cev_sf_login_sent_', $identifier ) );
	}

	/**
	 * Log the freshly-registered customer in (filterable) so they land on the
	 * account page already signed in.
	 *
	 * @since 2.10.0
	 * @param int $user_id The user to authenticate.
	 * @return void
	 */
	private function maybe_auto_login( $user_id ) {
		if ( is_user_logged_in() ) {
			return;
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$auto_login = (bool) apply_filters( 'cev_smart_form_auto_login', true, $user_id );
		if ( ! $auto_login ) {
			return;
		}

		if ( function_exists( 'wc_set_customer_auth_cookie' ) ) {
			wc_set_customer_auth_cookie( $user_id );
		} else {
			// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified OTP factor; wp_signon() needs a password.
			wp_set_current_user( $user_id );
			// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified OTP factor; wp_signon() needs a password.
			wp_set_auth_cookie( $user_id, true ); // nosemgrep: audit.php.wp.security.auth-bypass.wp-set-auth-cookie -- $user_id is the account resolved AND OTP-verified above, not raw request input.
		}
	}

	/**
	 * Post-registration redirect URL (filterable).
	 *
	 * @since 2.10.0
	 * @param int $user_id The registered user.
	 * @return string
	 */
	private function redirect_url( $user_id ) {
		$url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );

		// Honour a redirect the visitor arrived with, so a private / members-only
		// store returns them to the page they originally requested instead of the
		// account dashboard.
		$requested = $this->requested_redirect_url();
		if ( '' !== $requested ) {
			$url = $requested;
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (string) apply_filters( 'cev_smart_form_register_redirect', $url, $user_id );
	}

	/**
	 * The redirect the visitor asked for, when there is a safe one.
	 *
	 * Private / members-only stores send visitors to the login page carrying a
	 * redirect_to parameter naming the page they originally requested. Accept it
	 * from the posted payload, else read it off the referring form page — during
	 * an AJAX request the referer IS that page, query string included.
	 * wp_validate_redirect() drops anything pointing off-site.
	 *
	 * @since 3.0.4
	 * @return string Validated URL, or an empty string when there is none.
	 */
	private function requested_redirect_url() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$requested = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';

		if ( '' === $requested ) {
			$referer = wp_get_referer();
			$query   = $referer ? wp_parse_url( $referer, PHP_URL_QUERY ) : '';

			if ( ! empty( $query ) ) {
				$args = array();
				parse_str( (string) $query, $args );

				if ( ! empty( $args['redirect_to'] ) && is_string( $args['redirect_to'] ) ) {
					$requested = esc_url_raw( $args['redirect_to'] );
				}
			}
		}

		if ( '' === $requested ) {
			return '';
		}

		return (string) wp_validate_redirect( $requested, '' );
	}

	/**
	 * Send WooCommerce's "account created" welcome email. Called only AFTER the
	 * email is OTP-verified (it is suppressed during account creation), so the
	 * welcome never arrives before the customer has confirmed their address.
	 * Honours the merchant's WC email settings — sends nothing if that email is
	 * disabled.
	 *
	 * @since 2.10.0
	 * @param int $user_id The verified customer.
	 * @return void
	 */
	private function send_new_account_email( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return;
		}

		// Send the welcome email OUT-OF-BAND so a slow SMTP server can't hold the
		// registration request open and trip a 504. Action Scheduler (bundled
		// with WooCommerce) runs it moments later; fall back to a one-off WP-Cron
		// event, and only send inline as a last resort.
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::WELCOME_EMAIL_ACTION, array( $user_id ), 'cev-smart-form' );
			return;
		}
		if ( ! wp_next_scheduled( self::WELCOME_EMAIL_ACTION, array( $user_id ) ) ) {
			wp_schedule_single_event( time() + 5, self::WELCOME_EMAIL_ACTION, array( $user_id ) );
			return;
		}

		$this->dispatch_new_account_email( $user_id );
	}

	/**
	 * Trigger WooCommerce's "account created" welcome email. Runs from the
	 * background hook (self::WELCOME_EMAIL_ACTION) scheduled by
	 * send_new_account_email(), so SMTP latency never blocks the register
	 * request. Honours the merchant's WC email settings.
	 *
	 * @since 2.10.0
	 * @param int $user_id The verified customer.
	 * @return void
	 */
	public function dispatch_new_account_email( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 || ! function_exists( 'WC' ) ) {
			return;
		}

		$emails = WC()->mailer()->emails;
		$cev_new_account_email = isset( $emails['WC_Email_Customer_New_Account'] ) ? $emails['WC_Email_Customer_New_Account'] : null;
		if ( $cev_new_account_email instanceof WC_Email_Customer_New_Account ) {
			// The customer set their own password, so none is included.
			$cev_new_account_email->trigger( $user_id, '', false );
		}
	}

	/**
	 * Per-IP OTP-send rate limit (Phase 10 hardening). Returns a WP_Error when
	 * the client IP has requested too many codes in the rolling window, else
	 * true. SMS gets a tighter cap because each message has a real cost. This
	 * complements the per-account resend limit (is_resend_limit_reached) by
	 * stopping one IP from spraying codes across many identifiers (email-bombing
	 * / SMS-cost abuse). Filterable via cev_smart_form_ip_send_max /
	 * cev_smart_form_ip_send_window.
	 *
	 * @since 2.10.0
	 * @param string $channel 'email' or 'sms'.
	 * @return true|WP_Error
	 */
	private function check_ip_send_rate( $channel = 'email' ) {
		$ip = cev_pro()->function->get_client_ip();
		if ( '' === $ip || '192.0.2.0' === $ip ) {
			return true; // No usable IP — rely on the per-account limits.
		}

		$is_sms = ( 'sms' === $channel );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$max    = (int) apply_filters( 'cev_smart_form_ip_send_max', $is_sms ? 8 : 20, $channel );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$window = (int) apply_filters( 'cev_smart_form_ip_send_window', HOUR_IN_SECONDS, $channel );
		if ( $max <= 0 ) {
			return true;
		}

		$key   = 'cev_sf_ipsend_' . md5( $channel . '|' . $ip );
		$count = (int) get_transient( $key );
		if ( $count >= $max ) {
			return new WP_Error( 'rate_limited', __( 'Too many code requests from your network. Please wait a while and try again.', 'customer-email-verification' ) );
		}
		set_transient( $key, $count + 1, $window );

		return true;
	}

	/**
	 * Send the OTP before the account exists. SMS stores the PIN in a transient;
	 * email uses CEV_Signup_Email which writes to cev_user_log by address
	 * (no user_id required). verify_register() reads from the same stores.
	 *
	 * @since 2.10.0
	 * @param string $email   The registrant's email address.
	 * @param string $phone   Normalised E.164 phone (SMS channel only).
	 * @param bool   $use_sms Whether to deliver by SMS.
	 * @return true|WP_Error
	 */
	private function deliver_pre_account_otp( $email, $phone, $use_sms ) {
		if ( $use_sms ) {
			if ( '' === (string) $phone ) {
				return new WP_Error( 'invalid_phone', __( 'No phone number is available for verification.', 'customer-email-verification' ) );
			}

			$pin = (string) cev_pro()->function->generate_verification_pin();
			set_transient(
				'cev_sf_sms_otp_' . md5( strtolower( $email ) ),
				array(
					'pin'     => $pin,
					'enddate' => time() + 600,
				),
				620
			);

			/* translators: %s = the verification code. */
			$message = sprintf( __( 'Your verification code is %s', 'customer-email-verification' ), $pin );
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$message = (string) apply_filters( 'cev_smart_form_sms_otp_message', $message, $pin, 0 );
			return CEV_SMS_Compat::deliver_sms( $phone, $message );
		}

		// Email OTP — CEV_Signup_Email stores the PIN in cev_user_log keyed by
		// email address, so it works perfectly before the account is created.
		if ( ! class_exists( 'CEV_Signup_Email' ) ) {
			require_once cev_pro()->get_plugin_path() . '/includes/signup-verification/cev-pro-signup-email.php';
		}
		$email_sender = new CEV_Signup_Email();
		if ( ! $email_sender->send_verification_email( $email ) ) {
			return new WP_Error( 'send_failed', __( 'We could not send your verification code. Please try again.', 'customer-email-verification' ) );
		}
		return true;
	}

	/**
	 * Deliver the registration OTP over the chosen channel. SMS registration
	 * generates + stores the PIN (no email) and sends it with CEV_SMS_Gateway;
	 * the email path reuses code_mail_sender(). Both write the same
	 * cev_email_verification_pin meta that verify_register() reads.
	 *
	 * @since 2.10.0
	 * @param int    $user_id The customer.
	 * @param string $email   The account email.
	 * @param string $phone   Normalised E.164 phone (SMS channel only).
	 * @param bool   $use_sms Whether to deliver by SMS.
	 * @return true|WP_Error
	 */
	private function deliver_registration_otp( $user_id, $email, $phone, $use_sms ) {
		if ( $use_sms ) {
			if ( '' === (string) $phone ) {
				return new WP_Error( 'invalid_phone', __( 'No phone number is on file for this account.', 'customer-email-verification' ) );
			}
			if ( ! class_exists( 'CEV_SMS_Gateway' ) ) {
				return new WP_Error( 'sms_unavailable', __( 'Phone verification is temporarily unavailable.', 'customer-email-verification' ) );
			}

			$pin = (string) cev_pro()->function->store_verification_pin( $user_id );
			if ( '' === $pin ) {
				return new WP_Error( 'otp_failed', __( 'We could not generate a verification code. Please try again.', 'customer-email-verification' ) );
			}

			/* translators: %s = the verification code. */
			$message = sprintf( __( 'Your verification code is %s', 'customer-email-verification' ), $pin );
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$message = (string) apply_filters( 'cev_smart_form_sms_otp_message', $message, $pin, $user_id );

			return CEV_SMS_Compat::deliver_sms( $phone, $message );
		}

		cev_pro()->function->wuev_user_id          = $user_id;
		cev_pro()->function->registered_user_email = $email;
		if ( ! cev_pro()->function->code_mail_sender( $email, 'email_registration' ) ) {
			return new WP_Error( 'send_failed', __( 'We could not send your verification code. Please try again.', 'customer-email-verification' ) );
		}

		return true;
	}

	/**
	 * Normalise a user-entered phone number to E.164 (leading +, digits only).
	 * Returns '' when the number is too short to be valid.
	 *
	 * @since 2.10.0
	 * @param string $raw The entered phone number.
	 * @return string E.164 number, or '' if invalid.
	 */
	public static function normalize_phone( $raw ) {
		$digits = preg_replace( '/[^0-9]/', '', (string) $raw );
		if ( 8 > strlen( $digits ) ) {
			return '';
		}
		return '+' . $digits;
	}

	/**
	 * Whether another account already uses this phone number (matched against the
	 * canonical phone meta). Returns the owning user ID, or 0 if the number is
	 * free. Phone must be unique because Phone OTP login resolves an account by it.
	 *
	 * @since 2.10.0
	 * @param string $phone The phone number (any format).
	 * @return int Owning user ID, or 0 when unused.
	 */
	public static function phone_exists( $phone ) {
		$digits = preg_replace( '/[^0-9]/', '', (string) $phone );
		if ( 8 > strlen( $digits ) ) {
			return 0;
		}

		global $wpdb;
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
				self::PHONE_META,
				'+' . $digits
			)
		);
		// phpcs:enable
	}

	/**
	 * Mask a phone number for display (keep the last four digits).
	 *
	 * @since 2.10.0
	 * @param string $phone The phone number.
	 * @return string Masked number.
	 */
	private function mask_phone( $phone ) {
		$digits = preg_replace( '/[^0-9]/', '', (string) $phone );
		if ( 4 >= strlen( $digits ) ) {
			return $phone;
		}
		return '••• ' . substr( $digits, -4 );
	}

	/**
	 * Resolve a login identifier (email, username, or phone number) to a user.
	 * Phone numbers are matched against the canonical phone meta (PHONE_META).
	 *
	 * @since 2.10.0
	 * @param string $identifier Email, username, or phone number.
	 * @return WP_User|null
	 */
	private function resolve_login_user( $identifier ) {
		$identifier = trim( (string) $identifier );
		if ( '' === $identifier ) {
			return null;
		}

		if ( is_email( $identifier ) ) {
			$user = get_user_by( 'email', $identifier );
			if ( $user ) {
				return $user;
			}
		}

		$user = get_user_by( 'login', $identifier );
		if ( $user ) {
			return $user;
		}

		// Phone number — match the canonical phone meta (stored as +digits).
		$digits = preg_replace( '/[^0-9]/', '', $identifier );
		if ( 8 <= strlen( $digits ) ) {
			global $wpdb;
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
			$user_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
					self::PHONE_META,
					'+' . $digits
				)
			);
			// phpcs:enable
			if ( 0 < $user_id ) {
				$user = get_user_by( 'ID', $user_id );
				if ( $user ) {
					return $user;
				}
			}
		}

		return null;
	}

	/**
	 * Display form of a login identifier for the OTP popup — masks a phone-like
	 * value, otherwise echoes what the visitor entered. Derived only from input,
	 * so it never reveals whether an account exists.
	 *
	 * @since 2.10.0
	 * @param string $identifier The entered identifier.
	 * @return string
	 */
	private function display_identifier( $identifier ) {
		$identifier = trim( (string) $identifier );
		$digits     = preg_replace( '/[^0-9]/', '', $identifier );
		if ( ! is_email( $identifier ) && 8 <= strlen( $digits ) ) {
			return $this->mask_phone( $identifier );
		}
		return $identifier;
	}

	/**
	 * Whether the password meets the strong-password policy: at least 8
	 * characters with lower + upper case, a digit, and a symbol. Filterable.
	 *
	 * @since 2.10.0
	 * @param string $password The submitted password.
	 * @return bool
	 */
	private function is_strong_password( $password ) {
		$policy = CEV_Smart_Form::password_policy();
		$strong = ( $policy['min_length'] <= strlen( $password ) );

		if ( $policy['require_strong'] ) {
			$strong = $strong
				&& ( 1 === preg_match( '/[a-z]/', $password ) )
				&& ( 1 === preg_match( '/[A-Z]/', $password ) )
				&& ( 1 === preg_match( '/[0-9]/', $password ) )
				&& ( 1 === preg_match( '/[^a-zA-Z0-9]/', $password ) );
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (bool) apply_filters( 'cev_smart_form_password_is_strong', $strong, $password );
	}

	/**
	 * Validate a third-party WooCommerce-form captcha injected into the Smart
	 * Form via the woocommerce_register_form / woocommerce_login_form hook.
	 *
	 * Integrates All In One WP Security (AIOS): its render hook gates on its own
	 * setting, and its verify filter gates on the WC nonce (absent in our AJAX),
	 * so we call its public verify_captcha_submit() directly. Other captcha
	 * plugins can hook the cev_smart_form_captcha_error filter.
	 *
	 * @since 2.10.0
	 * @param string $context Either 'register' or 'login'.
	 * @return WP_Error|null WP_Error when the captcha fails, null when it passes or is absent.
	 */
	private function third_party_captcha_error( $context ) {
		$error = null;

		global $aio_wp_security;
		if ( isset( $aio_wp_security ) && is_object( $aio_wp_security )
			&& isset( $aio_wp_security->configs, $aio_wp_security->captcha_obj )
			&& is_object( $aio_wp_security->captcha_obj )
			&& method_exists( $aio_wp_security->captcha_obj, 'verify_captcha_submit' ) ) {

			$setting = ( 'login' === $context ) ? 'aiowps_enable_woo_login_captcha' : 'aiowps_enable_woo_register_captcha';
			if ( '1' === (string) $aio_wp_security->configs->get_value( $setting )
				&& ! $aio_wp_security->captcha_obj->verify_captcha_submit() ) {
				$error = new WP_Error( 'captcha_failed', __( 'Your CAPTCHA answer was incorrect — please try again.', 'customer-email-verification' ) );
			}
		}

		/**
		 * Filter the Smart Form third-party captcha result. Return a WP_Error to
		 * block the submission (for captcha plugins other than AIOS).
		 *
		 * @since 2.10.0
		 * @param WP_Error|null $error   Current captcha error (null = passed).
		 * @param string        $context 'register' or 'login'.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return apply_filters( 'cev_smart_form_captcha_error', $error, $context );
	}

	/**
	 * Validate + sanitize the developer-registered custom fields from the
	 * register submission. Pure helper (no superglobals) — the caller reads
	 * $_POST['cev_cf'] after verifying the nonce and passes the raw array in.
	 *
	 * @since 3.0.2
	 * @param array $raw Raw (unslashed) cev_cf submission array.
	 * @return array|WP_Error Sanitized values keyed by field key, or WP_Error when a required field is missing.
	 */
	private function validate_custom_fields( $raw ) {
		if ( ! class_exists( 'CEV_Smart_Form' ) ) {
			return array();
		}
		$fields = CEV_Smart_Form::get_custom_fields();
		if ( empty( $fields ) ) {
			return array();
		}
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		$values = array();
		foreach ( $fields as $key => $field ) {
			$submitted = isset( $raw[ $key ] ) ? $raw[ $key ] : '';
			$value     = $this->sanitize_custom_value( $field, $submitted );

			// Whitelist the submitted value(s) for choice fields.
			if ( in_array( $field['type'], array( 'select', 'radio', 'checkbox_group' ), true ) ) {
				$allowed = CEV_Smart_Form::custom_field_option_values( $field );
				if ( 'checkbox_group' === $field['type'] ) {
					$value = array_values( array_intersect( (array) $value, $allowed ) );
				} elseif ( '' !== $value && ! in_array( $value, $allowed, true ) ) {
					$value = '';
				}
			}

			if ( ! empty( $field['required'] ) && $this->is_empty_custom_value( $field, $value ) ) {
				return new WP_Error(
					'missing_custom_field',
					sprintf(
						/* translators: %s: the form field label. */
						__( '%s is required.', 'customer-email-verification' ),
						$this->custom_field_label_text( $field )
					)
				);
			}

			$values[ $key ] = $value;
		}

		return $values;
	}

	/**
	 * Sanitize a single custom-field value according to its type.
	 *
	 * @since 3.0.2
	 * @param array $field     Normalised field definition.
	 * @param mixed $submitted The raw submitted value.
	 * @return mixed
	 */
	private function sanitize_custom_value( $field, $submitted ) {
		switch ( $field['type'] ) {
			case 'email':
				return sanitize_email( is_scalar( $submitted ) ? (string) $submitted : '' );
			case 'textarea':
				return sanitize_textarea_field( is_scalar( $submitted ) ? (string) $submitted : '' );
			case 'url':
				return esc_url_raw( is_scalar( $submitted ) ? (string) $submitted : '' );
			case 'acceptance':
				$scalar = is_scalar( $submitted ) ? (string) $submitted : '';
				return ( '' !== $scalar && '0' !== $scalar ) ? '1' : '';
			case 'checkbox_group':
				$out = array();
				foreach ( (array) $submitted as $item ) {
					$out[] = sanitize_text_field( (string) $item );
				}
				return $out;
			default:
				return sanitize_text_field( is_scalar( $submitted ) ? (string) $submitted : '' );
		}
	}

	/**
	 * Whether a sanitized custom value counts as "empty" for the required check.
	 *
	 * @since 3.0.2
	 * @param array $field Normalised field definition.
	 * @param mixed $value Sanitized value.
	 * @return bool
	 */
	private function is_empty_custom_value( $field, $value ) {
		if ( 'acceptance' === $field['type'] ) {
			return '1' !== $value;
		}
		if ( 'checkbox_group' === $field['type'] ) {
			return empty( $value );
		}
		return '' === trim( (string) $value );
	}

	/**
	 * Plain-text label for a custom field (tags stripped) for error messages.
	 *
	 * @since 3.0.2
	 * @param array $field Normalised field definition.
	 * @return string
	 */
	private function custom_field_label_text( $field ) {
		$label = isset( $field['label'] ) ? wp_strip_all_tags( (string) $field['label'] ) : '';
		return ( '' !== $label ) ? $label : (string) $field['key'];
	}

	/**
	 * Run the store's registration validation for an email, ahead of time.
	 *
	 * Mirrors exactly what wc_create_new_customer() does at account-creation time
	 * — it resolves the username WooCommerce would generate, fires
	 * woocommerce_register_post, then filters through woocommerce_registration_errors
	 * — so the Smart Form rejects a registration the store would refuse
	 * BEFORE any code is sent, rather than failing after the customer has already
	 * entered their code.
	 *
	 * registration_errors (WP core) is deliberately NOT fired here: WooCommerce
	 * does not fire it when creating a customer, so a rejection there would block a
	 * registration that account creation would have allowed.
	 *
	 * @since 3.0.4
	 * @param string $email Email address being registered.
	 * @return WP_Error Populated when the store rejects the registration.
	 */
	private function validate_registration( $email ) {
		$username = function_exists( 'wc_create_new_customer_username' ) ? wc_create_new_customer_username( $email ) : '';
		$username = sanitize_user( $username );

		$errors = new WP_Error();
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		do_action( 'woocommerce_register_post', $username, $email, $errors );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		$errors = apply_filters( 'woocommerce_registration_errors', $errors, $username, $email );

		return $errors;
	}

	/**
	 * Expose validated custom-field values through $_POST under the field names a
	 * standard WooCommerce register form would have submitted.
	 *
	 * The Smart Form posts custom fields as cev_cf[key], so third-party code on
	 * woocommerce_register_post / woocommerce_registration_errors /
	 * woocommerce_created_customer never sees them. Mirroring the values onto the
	 * conventional names lets that code validate and save them unchanged. A value
	 * already present in the request is never overwritten.
	 *
	 * @since 3.0.4
	 * @param array $values Sanitized values keyed by custom-field key.
	 * @return void
	 */
	private function expose_custom_fields_to_post( $values ) {
		if ( ! is_array( $values ) || empty( $values ) ) {
			return;
		}

		$map = array(
			'first_name' => array( 'first_name', 'billing_first_name' ),
			'last_name'  => array( 'last_name', 'billing_last_name' ),
		);
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$map = (array) apply_filters( 'cev_smart_form_custom_field_post_map', $map, $values );

		foreach ( $values as $key => $value ) {
			$targets = isset( $map[ $key ] ) ? (array) $map[ $key ] : array( $key );

			foreach ( $targets as $target ) {
				$target = sanitize_key( (string) $target );
				if ( '' === $target ) {
					continue;
				}
				// Read the superglobal on its own statement so the ignore reliably
				// applies (a nested read inside an if() condition can slip past).
				// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
				$already_submitted = ! empty( $_POST[ $target ] );
				if ( $already_submitted ) {
					continue;
				}
				// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
				$_POST[ $target ] = $value;
			}
		}
	}

	/**
	 * Save the validated custom-field values to the new account. The field key
	 * IS the user-meta key (first_name / last_name / billing_* are all meta
	 * keys), so one update_user_meta call per field covers every destination.
	 * Developers needing non-meta storage hook cev_smart_form_custom_fields_saved.
	 *
	 * @since 3.0.2
	 * @param int   $user_id The freshly-created customer.
	 * @param array $values  Sanitized values keyed by field key.
	 * @return void
	 */
	private function save_custom_fields( $user_id, $values ) {
		if ( ! class_exists( 'CEV_Smart_Form' ) ) {
			return;
		}
		$fields = CEV_Smart_Form::get_custom_fields();
		$saved  = array();

		foreach ( $values as $key => $value ) {
			if ( ! isset( $fields[ $key ] ) ) {
				continue;
			}
			update_user_meta( $user_id, $key, $value );
			$saved[ $key ] = $value;
		}

		if ( ! empty( $saved ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			do_action( 'cev_smart_form_custom_fields_saved', $user_id, $saved );
		}
	}
}
