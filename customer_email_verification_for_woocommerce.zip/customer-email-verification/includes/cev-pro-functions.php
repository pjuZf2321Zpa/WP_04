<?php
/**
 * Shared Utility Functions for Customer Email Verification
 *
 * This file contains common utility functions used across multiple modules
 * of the Customer Email Verification plugin. These functions handle:
 * - Email verification status checks
 * - Verification PIN generation
 * - Resend limit checking and management
 * - User meta operations for verification
 *
 * @package Customer_Email_Verification
 * @since 2.8.6
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Functions_Pro Class
 *
 * Singleton class containing utility methods for Customer Email Verification.
 * Handles email verification status checks, PIN generation, resend limits,
 * and user meta operations.
 *
 * @package Customer_Email_Verification
 * @since 2.8.6
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Functions_Pro {

	/**
	 * Instance of this class.
	 *
	 * @var CEV_Functions_Pro|null Class Instance
	 */
	private static $instance = null;

	/**
	 * Private constructor to prevent direct instantiation.
	 *
	 * @since 2.8.6
	 */
	private function __construct() {
		// Private constructor to enforce singleton pattern.
	}

	/**
	 * Get the class instance.
	 *
	 * @since 2.8.6
	 * @return CEV_Functions_Pro Class instance.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Prevent cloning of the instance.
	 *
	 * @since 2.8.6
	 */
	private function __clone() {
		// Prevent cloning.
	}

	/**
	 * Prevent unserializing of the instance.
	 *
	 * @since 2.8.6
	 */
	public function __wakeup() {
		// Prevent unserializing.
	}

	/**
	 * Convert a hex color string to an RGB(A) string.
	 *
	 * Example usage:
	 * - hex2rgba('#ff0000') → 'rgb(255,0,0)'
	 * - hex2rgba('#ff0000', 0.5) → 'rgba(255,0,0,0.5)'
	 *
	 * @param string     $color   Hexadecimal color code (e.g., "#ff0000" or "ff0000").
	 * @param float|bool $opacity Optional. Opacity level (0 to 1). Default is false (returns RGB).
	 *
	 * @return string RGB or RGBA color string.
	 */
	public function hex2rgba( $color, $opacity = false ) {
		$default = 'rgba(116,194,225,0.7)'; // Default fallback color.

		// Return default if no color is provided.
		if ( empty( $color ) ) {
			return $default;
		}

		// Remove '#' if present.
		if ( '#' === $color[0] ) {
			$color = substr( $color, 1 );
		}

		// Validate color format and extract RGB components.
		if ( 6 === strlen( $color ) ) {
			$hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
		} elseif ( 3 === strlen( $color ) ) {
			$hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
		} else {
			return $default;
		}

		// Convert hex values to decimal RGB.
		$rgb = array_map( 'hexdec', $hex );

		// Determine if opacity is set (RGBA or RGB).
		if ( false !== $opacity ) {
			$opacity = ( abs( $opacity ) > 1 ) ? 1.0 : $opacity;
			return 'rgba(' . implode( ',', $rgb ) . ',' . $opacity . ')';
		}

		return 'rgb(' . implode( ',', $rgb ) . ')';
	}

	public $wuev_user_id = null;
	public $email_type = null;
	public $login_ip = null;
	public $login_time = null;
	public $login_browser = null;
	public $login_device = null;
	public $wuev_myaccount_page_id = null;
	public $registered_user_email = null;

	/**
	 * PIN being sent by the Edit Account email-change flow.
	 *
	 * Set only while that email is built, so {cev_user_verification_pin}
	 * prints the PIN stored in cev_edit_account_verification_pin instead of
	 * one looked up from another flow.
	 *
	 * @var string|null
	 */
	public $edit_account_pin = null;

	/**
	 * Check if an email address is verified.
	 *
	 * For registered users, checks the 'customer_email_verified' user meta.
	 * For guest users, checks if they have completed orders with valid statuses.
	 *
	 * @since 2.8.6
	 * @param string $email Email address to check.
	 * @return bool True if verified, false otherwise.
	 */
	public function check_email_verify( $email ) {
		if ( empty( $email ) || ! is_email( $email ) ) {
			return false;
		}

		$user = get_user_by( 'email', $email );

		// For registered users, check user meta.
		if ( $user ) {
			$user_id  = $user->ID;
			$verified = get_user_meta( $user_id, 'customer_email_verified', true );
			// Both the fully-verified state and the "pending paid order"
			// gatekeeping state count as email-verified here — a pending
			// user has already proven email ownership, so they must never
			// be re-prompted to verify. See cev_pro_is_pending_paid_order().
			return ( 'true' === $verified || 'pending_paid_order' === $verified );
		}

		// For guest users, check if they have completed orders.
		$valid_statuses = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
		$orders         = wc_get_orders(
			array(
				'billing_email' => $email,
				'limit'         => 1,
				'status'        => $valid_statuses,
			)
		);

		return ! empty( $orders );
	}

	/**
	 * Whether the "Paid-Order Gatekeeping" feature is enabled.
	 *
	 * When on, a user who verifies their email (OTP / link) is held in the
	 * `pending_paid_order` state instead of being fully verified, until they
	 * complete their first genuinely paid WooCommerce order.
	 *
	 * @since 2.10.0
	 * @return bool True when the setting toggle is enabled.
	 */
	public function cev_pro_paid_order_gatekeeping_enabled() {
		return (bool) $this->cev_pro_admin_settings( 'cev_enable_paid_order_gatekeeping', 0 );
	}

	/**
	 * Cart amount used for the threshold comparison, in the ACTIVE currency.
	 *
	 * Reads the cart per the configured metric — subtotal (excludes shipping
	 * and tax) or total (includes them). Returns 0.0 when the cart is
	 * unavailable (e.g. admin / REST context).
	 *
	 * @since 2.10.0
	 * @return float Cart amount in the active display currency.
	 */
	public function cev_pro_get_cart_amount_active_currency() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return 0.0;
		}

		$metric = $this->cev_pro_admin_settings( 'cev_cart_verification_threshold_metric', 'subtotal' );
		if ( 'total' === $metric ) {
			return (float) WC()->cart->get_total( 'edit' );
		}

		return (float) WC()->cart->get_subtotal();
	}

	/**
	 * Convert an amount from the active store currency to the base currency.
	 *
	 * Cart amounts are rendered in the shopper's active currency on
	 * multi-currency stores, but the threshold is configured in the store
	 * base currency — so we normalise before comparing. Supports Aelia and
	 * WOOCS out of the box and exposes the `cev_cart_amount_in_base_currency`
	 * filter as a universal escape hatch; falls back to the raw amount when
	 * no converter is present or the currencies already match.
	 *
	 * @since 2.10.0
	 * @param float $amount Amount in the active currency.
	 * @return float Amount in the store base currency.
	 */
	public function cev_pro_convert_to_base_currency( $amount ) {
		if ( ! function_exists( 'get_woocommerce_currency' ) ) {
			return (float) $amount;
		}

		$active = get_woocommerce_currency();
		$base   = get_option( 'woocommerce_currency' );
		if ( empty( $base ) || $active === $base ) {
			return (float) $amount;
		}

		// Aelia Currency Switcher.
		if ( has_filter( 'wc_aelia_cs_convert' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
			return (float) apply_filters( 'wc_aelia_cs_convert', $amount, $active, $base );
		}

		// WOOCS / Currency Switcher for WooCommerce.
		if ( isset( $GLOBALS['WOOCS'] ) && is_object( $GLOBALS['WOOCS'] ) && method_exists( $GLOBALS['WOOCS'], 'back_convert' ) ) {
			return (float) $GLOBALS['WOOCS']->back_convert( $amount );
		}

		// Escape hatch for any other multi-currency plugin.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (float) apply_filters( 'cev_cart_amount_in_base_currency', $amount, $active, $base );
	}

	/**
	 * Cart amount for the threshold comparison, normalised to base currency.
	 *
	 * @since 2.10.0
	 * @return float Cart amount in the store base currency.
	 */
	public function cev_pro_get_cart_threshold_amount() {
		return $this->cev_pro_convert_to_base_currency( $this->cev_pro_get_cart_amount_active_currency() );
	}

	/**
	 * Master decision: should checkout verification apply to THIS cart?
	 *
	 * Returns true = "verification applies, do not skip"; false = "skip the
	 * verification gate for this cart". Composes the conditional modes with
	 * OR logic — verification applies if the cart meets the Cart-Total
	 * Threshold OR contains a flagged product category. When NO conditional
	 * mode is active (default) it always returns true, preserving existing
	 * behaviour.
	 *
	 * @since 2.10.0
	 * @return bool True when verification should apply to the current cart.
	 */
	public function cev_pro_should_apply_verification() {
		$threshold        = (float) $this->cev_pro_admin_settings( 'cev_cart_verification_threshold_amount', 0 );
		$threshold_active = ( 1 === (int) $this->cev_pro_admin_settings( 'cev_enable_cart_threshold_verification', 0 ) && $threshold > 0 );
		$category_active  = $this->cev_pro_category_conditional_active();

		// No conditional mode active → verification applies exactly as today.
		if ( ! $threshold_active && ! $category_active ) {
			return true;
		}

		// OR logic: verification applies if ANY active condition is met.
		if ( $threshold_active && $this->cev_pro_get_cart_threshold_amount() >= $threshold ) {
			return true;
		}
		if ( $category_active && $this->cev_pro_cart_has_flagged_category() ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether the category-conditional verification mode is active: the toggle
	 * is on AND at least one flagged category is configured.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function cev_pro_category_conditional_active() {
		if ( 1 !== (int) $this->cev_pro_admin_settings( 'cev_enable_conditional_verification_by_category', 0 ) ) {
			return false;
		}

		$cats = $this->cev_pro_get_required_categories();
		return ! empty( $cats );
	}

	/**
	 * The flagged product-category term IDs (from the multi-select map).
	 *
	 * @since 2.10.0
	 * @return int[] Term IDs flagged for verification.
	 */
	public function cev_pro_get_required_categories() {
		$map = $this->cev_pro_admin_settings( 'cev_required_verification_categories', array() );
		if ( ! is_array( $map ) ) {
			return array();
		}

		$ids = array();
		foreach ( $map as $term_id => $selected ) {
			if ( 1 === (int) $selected ) {
				$ids[] = (int) $term_id;
			}
		}

		return $ids;
	}

	/**
	 * Whether the current cart contains at least one product from a flagged
	 * category. Matches the product's own categories AND their ancestors, so
	 * flagging a parent category catches products in its child categories.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function cev_pro_cart_has_flagged_category() {
		$match    = false;
		$required = array_map( 'intval', $this->cev_pro_get_required_categories() );

		if ( ! empty( $required ) && function_exists( 'WC' ) && WC()->cart && function_exists( 'wc_get_product' ) ) {
			foreach ( WC()->cart->get_cart() as $cart_item ) {
				$product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
				if ( $product_id <= 0 ) {
					continue;
				}

				$product = wc_get_product( $product_id );
				if ( ! $product ) {
					continue;
				}

				$cat_ids = $product->get_category_ids();
				if ( empty( $cat_ids ) ) {
					continue;
				}

				// Expand with ancestors so a flagged parent category matches.
				$all_ids = $cat_ids;
				foreach ( $cat_ids as $cat_id ) {
					$all_ids = array_merge( $all_ids, get_ancestors( (int) $cat_id, 'product_cat' ) );
				}

				$hit = array_intersect( $required, array_map( 'intval', $all_ids ) );
				if ( ! empty( $hit ) ) {
					$match = true;
					break;
				}
			}
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (bool) apply_filters( 'cev_pro_cart_has_flagged_category', $match );
	}

	/**
	 * The custom verification message for the first flagged in-cart category
	 * that has one (else ''). Lets merchants explain why verification is
	 * required for a specific high-risk category.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public function cev_pro_get_triggering_category_message() {
		if ( ! $this->cev_pro_category_conditional_active() || ! function_exists( 'WC' ) || ! WC()->cart || ! function_exists( 'wc_get_product' ) ) {
			return '';
		}

		$messages = $this->cev_pro_admin_settings( 'cev_conditional_category_message', array() );
		if ( ! is_array( $messages ) || empty( $messages ) ) {
			return '';
		}

		$required = array_map( 'intval', $this->cev_pro_get_required_categories() );
		foreach ( WC()->cart->get_cart() as $cart_item ) {
			$product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
			if ( $product_id <= 0 ) {
				continue;
			}

			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$all_ids = $product->get_category_ids();
			foreach ( $product->get_category_ids() as $cat_id ) {
				$all_ids = array_merge( $all_ids, get_ancestors( (int) $cat_id, 'product_cat' ) );
			}

			foreach ( array_map( 'intval', $all_ids ) as $cat_id ) {
				if ( in_array( $cat_id, $required, true ) && isset( $messages[ $cat_id ] ) && '' !== trim( (string) $messages[ $cat_id ] ) ) {
					return (string) $messages[ $cat_id ];
				}
			}
		}

		return '';
	}

	/**
	 * Log the category-conditional gate decision once per request (analytics
	 * funnel): high-risk (verification required) vs low-risk (let through).
	 * No-op unless category mode is active. Event names are distinct from the
	 * otp_sent and blocked_ event families, so existing aggregates stay intact.
	 *
	 * @since 2.10.0
	 * @param string $context Event context label.
	 * @return void
	 */
	public function cev_pro_log_category_gate_decision( $context = 'checkout' ) {
		static $logged = false;
		if ( $logged || ! $this->cev_pro_category_conditional_active() || ! method_exists( $this, 'log_event' ) ) {
			return;
		}
		$logged = true;

		$email   = ( function_exists( 'WC' ) && WC()->customer ) ? WC()->customer->get_billing_email() : '';
		$user_id = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$event   = $this->cev_pro_cart_has_flagged_category() ? 'verification_required_high_risk_cart' : 'verification_skipped_low_risk_cart';

		$this->log_event( $email, $event, $context, array(), $user_id );
	}

	/**
	 * Decide which verified state a freshly-verified user should receive,
	 * honouring Paid-Order Gatekeeping.
	 *
	 * - Gatekeeping OFF → always 'true' (fully verified).
	 * - Gatekeeping ON  → 'true' if the user already has a paid order
	 *   (processing/completed), otherwise 'pending_paid_order'.
	 *
	 * Use this wherever a user re-confirms their email (e.g. the account
	 * verify-on-login popup) so the result matches the gatekeeping rule:
	 * a verified email with no paid order lands in "Pending Order".
	 *
	 * @since 2.10.0
	 * @param int $user_id User ID.
	 * @return string 'true' or 'pending_paid_order'.
	 */
	public function resolve_post_verification_state( $user_id ) {
		if ( ! $this->cev_pro_paid_order_gatekeeping_enabled() ) {
			return 'true';
		}

		$user_id = absint( $user_id );
		if ( $user_id > 0 && function_exists( 'wc_get_orders' ) ) {
			$orders = wc_get_orders(
				array(
					'customer_id' => $user_id,
					'limit'       => 1,
					'return'      => 'ids',
					'status'      => array( 'wc-processing', 'wc-completed' ),
				)
			);
			if ( ! empty( $orders ) ) {
				return 'true';
			}
		}

		return 'pending_paid_order';
	}

	/**
	 * Whether a registered user is in the "verified, pending paid order" state.
	 *
	 * @since 2.10.0
	 * @param int $user_id User ID.
	 * @return bool True when the user's verification meta is `pending_paid_order`.
	 */
	public function cev_pro_is_pending_paid_order( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		return 'pending_paid_order' === get_user_meta( $user_id, 'customer_email_verified', true );
	}

	/**
	 * Whether a registered user counts as email-verified for gating purposes.
	 *
	 * Treats BOTH the fully-verified state (`true`) and the gatekeeping
	 * `pending_paid_order` state as verified, because a pending user has
	 * already proven email ownership — they just have not completed a paid
	 * order yet. Use this for every "should we re-prompt / block checkout /
	 * show the verification popup" decision so pending users are never asked
	 * to verify their email a second time.
	 *
	 * @since 2.10.0
	 * @param int $user_id User ID.
	 * @return bool True when the user is verified or pending a paid order.
	 */
	public function is_user_email_verified( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		$verified = get_user_meta( $user_id, 'customer_email_verified', true );

		return ( 'true' === $verified || 'pending_paid_order' === $verified );
	}

	/**
	 * Whether a user holds a back-office role that checkout verification exempts.
	 *
	 * Store staff are not customers. Holding an administrator, editor or shop
	 * manager behind an email OTP stops them placing test orders, and on a store
	 * whose mail is misconfigured it locks them out of checkout entirely. This
	 * mirrors the exclusion the verify-on-login prompt and the force-reverify
	 * tool already apply.
	 *
	 * @since 3.0.3
	 * @param int $user_id Optional. User to test. Defaults to the current user.
	 * @return bool True when the user holds an elevated role.
	 */
	public function is_back_office_user( $user_id = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}

		$user = get_userdata( $user_id );
		if ( ! $user instanceof WP_User ) {
			return false;
		}

		$cev_elevated = array( 'administrator', 'editor', 'shop_manager' );

		/**
		 * Filter the roles treated as back-office for verification gating.
		 *
		 * @since 3.0.3
		 * @param array   $cev_elevated Role slugs exempt from verification.
		 * @param WP_User $user         The user being tested.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned filter; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$cev_elevated = (array) apply_filters( 'cev_back_office_roles', $cev_elevated, $user );

		return (bool) array_intersect( $cev_elevated, (array) $user->roles );
	}

	/**
	 * Whether the current request should show the "verify your email" prompt
	 * to a logged-in but unverified customer.
	 *
	 * Gated by the `cev_require_verify_unverified_login` setting. Back-office
	 * roles (administrator / editor / shop_manager) are never prompted, and
	 * users who are already verified (or pending a paid order) are skipped.
	 * Both the asset enqueue and the footer render use this single check so
	 * they can never disagree.
	 *
	 * @since 2.10.0
	 * @return bool True when the account-verification popup should appear.
	 */
	public function should_prompt_account_verify() {
		if ( is_admin() || ! is_user_logged_in() ) {
			return false;
		}

		$user = wp_get_current_user();
		if ( ! $user || 0 === (int) $user->ID ) {
			return false;
		}

		$prompt_enabled = $this->should_verify_unverified_on_login();
		/**
		 * Whether the account-verify prompt is enabled for the current user.
		 * Lets integrations (e.g. the Dokan vendor flow) force the prompt for a
		 * specific user even when the global login-verify setting is off.
		 *
		 * @since 2.10.0
		 * @param bool    $prompt_enabled Current enabled state.
		 * @param WP_User $user           The logged-in user.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$prompt_enabled = (bool) apply_filters( 'cev_account_verify_prompt_enabled', $prompt_enabled, $user );
		if ( ! $prompt_enabled ) {
			return false;
		}

		$elevated = array( 'administrator', 'editor', 'shop_manager' );
		if ( array_intersect( $elevated, (array) $user->roles ) ) {
			return false;
		}

		// A login OTP is already in flight for this customer — that code
		// verifies the same address, so showing this popup too would mean two
		// prompts and two emails for one address.
		if ( $this->has_pending_login_otp( $user->ID ) ) {
			return false;
		}

		// Already verified (or pending a paid order) — no prompt needed.
		return ! $this->is_user_email_verified( $user->ID );
	}

	/**
	 * Whether unverified logged-in customers must verify their email.
	 *
	 * True when the merchant enabled the dedicated switch, OR when "Require OTP
	 * on every login" is on. The latter subsumes it: every-login already
	 * challenges an unverified customer at login and records the verification,
	 * so the same intent has to cover a customer who is ALREADY logged in and
	 * would not otherwise be asked again. That is what lets the admin hide the
	 * dedicated switch under every-login without creating a silent gap.
	 *
	 * @since 3.0.3
	 * @return bool
	 */
	public function should_verify_unverified_on_login() {
		if ( 1 === (int) $this->cev_pro_admin_settings( 'cev_require_verify_unverified_login', 0 ) ) {
			return true;
		}

		return ( 1 === (int) $this->cev_pro_admin_settings( 'cev_enable_login_authentication', 0 )
			&& 1 === (int) $this->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 ) );
	}

	/**
	 * Whether a login OTP is currently awaiting entry for this user.
	 *
	 * Set by the login-authentication flow when it emails a code, and cleared
	 * once the code is accepted. Used to keep the account-verify prompt out of
	 * the way while the login code is outstanding — both verify the same
	 * address, so running both would send two codes for one login.
	 *
	 * @since 3.0.3
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public function has_pending_login_otp( $user_id ) {
		$required = get_user_meta( (int) $user_id, 'cev_login_otp_required', true );
		if ( empty( $required ) ) {
			return false;
		}

		return '' !== (string) get_user_meta( (int) $user_id, 'cev_login_otp', true );
	}

	/**
	 * Auto-send the account-verification OTP to a user, throttled.
	 *
	 * Powers the "verify on login" auto-send so the customer never has to
	 * click a button. Safe to call on every login / front-end load because:
	 *   - it skips if a still-valid (non-expired) code already exists, and
	 *   - it sets a short-lived transient so a page-refresh loop can't spam
	 *     emails (interval filterable via `cev_account_verify_resend_interval`).
	 *
	 * Caller is responsible for the "should this user be prompted" checks
	 * (setting on, unverified, not an elevated role).
	 *
	 * @since 2.10.0
	 * @param int $user_id User to email.
	 * @return bool True if a code was sent this call; false if skipped/failed.
	 */
	public function maybe_send_account_verify_code( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		// Throttle: at most one auto-send per interval per user.
		$rate_key = 'cev_av_otp_sent_' . $user_id;
		if ( get_transient( $rate_key ) ) {
			return false;
		}

		// Skip if a still-valid (non-expired) code already exists.
		$pin = get_user_meta( $user_id, 'cev_email_verification_pin', true );
		if ( is_array( $pin ) && ! empty( $pin['pin'] ) ) {
			$enddate = isset( $pin['enddate'] ) ? (int) $pin['enddate'] : 0;
			if ( 0 === $enddate || time() < $enddate ) {
				return false;
			}
		}

		$user = get_user_by( 'id', $user_id );
		if ( ! $user || ! is_email( $user->user_email ) ) {
			return false;
		}

		$this->wuev_user_id          = $user_id;
		$this->registered_user_email = $user->user_email;
		$sent                        = $this->code_mail_sender( $user->user_email, 'email_account_verify' );

		if ( $sent ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$interval = (int) apply_filters( 'cev_account_verify_resend_interval', 90 );
			set_transient( $rate_key, 1, max( 10, $interval ) );
		}

		return $sent;
	}

	/**
	 * Complete the paid-order gate for a pending user: flip to fully verified
	 * and resume the held post-verification flows.
	 *
	 * Idempotent — only acts on a user whose meta is currently
	 * `pending_paid_order`, so it is safe to call from both the
	 * `woocommerce_order_status_completed` and `woocommerce_payment_complete`
	 * hooks for the same order, and on every subsequent order.
	 *
	 * On a successful flip it:
	 *   - Sets `customer_email_verified` = `true`.
	 *   - Logs a `verification_completed_via_paid_order` analytics event.
	 *   - Does NOT send the WooCommerce "New Account" welcome email — that
	 *     goes out at registration and is no longer held by gatekeeping.
	 *   - Fires `do_action( 'cev_paid_order_gatekeeping_completed', $user_id,
	 *     $source )` so coupon / marketing-list integrations can resume any
	 *     post-verification flows they held back.
	 *
	 * @since 2.10.0
	 * @param int    $user_id User ID to activate.
	 * @param string $source  Where the flip originated: `paid_order` or `admin`.
	 * @return bool True if the user was pending and got flipped; false otherwise.
	 */
	public function complete_paid_order_gatekeeping( $user_id, $source = 'paid_order' ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		// Only flip users who are actually pending — keeps the call idempotent.
		if ( 'pending_paid_order' !== get_user_meta( $user_id, 'customer_email_verified', true ) ) {
			return false;
		}

		update_user_meta( $user_id, 'customer_email_verified', 'true' );

		$user = get_user_by( 'id', $user_id );
		if ( $user && method_exists( $this, 'log_event' ) ) {
			$this->log_event(
				$user->user_email,
				'verification_completed_via_paid_order',
				$source,
				array( 'source' => $source ),
				$user_id
			);
		}

		// Note: the WooCommerce welcome email is NOT sent here — it goes out
		// normally at registration and is no longer held by gatekeeping.

		// Let integrations resume any held post-verification flows.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		do_action( 'cev_paid_order_gatekeeping_completed', $user_id, $source );

		return true;
	}

	/**
	 * Generate a verification PIN code.
	 *
	 * Generates a random numeric PIN based on the configured code length setting.
	 * Default length is 4 digits, but can be 4 or 6 digits based on admin settings.
	 *
	 * @since 2.8.6
	 * @return string Generated PIN code.
	 */
	public function generate_verification_pin() {
		$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', '1' );
		$code_length = (string) $code_length; // Ensure string type for consistent comparison

		if ( '1' == $code_length ) {
			$digits = 4;
		} elseif ( '2' == $code_length ) {
			$digits = 6;
		} else {
			$digits = 4; // Default to 4 digits if invalid setting
		}

		$pin = '';
		for ( $i = 0; $i < $digits; $i++ ) {
			// Generate a random number between 0 and 9.
			$pin .= random_int( 0, 9 );
		}

		return $pin;
	}

	/**
	 * Check if resend limit has been reached for a user.
	 *
	 * Compares the user's resend count against the configured limit.
	 * Returns true if the user has reached or exceeded the limit.
	 *
	 * @since 2.8.6
	 * @param int $user_id User ID to check.
	 * @return bool True if limit reached, false otherwise.
	 */
	public function is_resend_limit_reached( $user_id ) {
		// Validate user ID is a positive integer.
		if ( empty( $user_id ) || $user_id <= 0 || ! is_numeric( $user_id ) ) {
			return false;
		}

		// Check if user exists.
		$user = get_user_by( 'ID', $user_id );
		if ( ! $user ) {
			return false;
		}

		$resend_times = (int) get_user_meta( $user_id, 'cev_user_resend_times', true );
		$limit        = (int) $this->cev_pro_admin_settings( 'cev_redirect_limit_resend', 1 );

		return $resend_times >= $limit;
	}

	/**
	 * Increment resend counter for a user.
	 *
	 * @since 2.8.6
	 * @param int $user_id User ID.
	 * @return void
	 */
	public function increment_resend_counter( $user_id ) {
		// Validate user ID is a positive integer.
		if ( empty( $user_id ) || $user_id <= 0 || ! is_numeric( $user_id ) ) {
			return;
		}

		// Check if user exists.
		$user = get_user_by( 'ID', $user_id );
		if ( ! $user ) {
			return;
		}

		$resend_times = $this->get_resend_count( $user_id );
		update_user_meta( $user_id, 'cev_user_resend_times', $resend_times + 1 );
	}

	/**
	 * Get resend count for a user.
	 *
	 * @since 2.8.6
	 * @param int $user_id User ID.
	 * @return int Current resend count.
	 */
	public function get_resend_count( $user_id ) {
		// Validate user ID is a positive integer.
		if ( empty( $user_id ) || $user_id <= 0 || ! is_numeric( $user_id ) ) {
			return 0;
		}

		// Check if user exists.
		$user = get_user_by( 'ID', $user_id );
		if ( ! $user ) {
			return 0;
		}

		return (int) get_user_meta( $user_id, 'cev_user_resend_times', true );
	}

	/**
	 * Get a plugin admin setting value from the consolidated settings option.
	 *
	 * Retrieves a setting value from the consolidated 'cev_pro_admin_settings' option.
	 * Falls back to individual option if migration hasn't been completed yet
	 * (backward compatibility). This function should be used instead of get_option()
	 * for all plugin admin settings.
	 *
	 * @since 2.9
	 * @param string $key     Setting key to retrieve.
	 * @param mixed  $default Default value if setting doesn't exist.
	 * @return mixed Setting value or default.
	 */
	public function cev_pro_admin_settings( $key, $default = false ) {
		$consolidated_settings = get_option( 'cev_pro_admin_settings', array() );

		// If consolidated settings exist and key is present, return it.
		if ( is_array( $consolidated_settings ) && isset( $consolidated_settings[ $key ] ) ) {
			return $consolidated_settings[ $key ];
		}

		// Fallback to individual option for backward compatibility.
		return get_option( $key, $default );
	}

	/**
	 * Get a customizer setting value from the consolidated customizer option.
	 *
	 * Retrieves a setting value from the consolidated 'cev_pro_customizer' option.
	 * Falls back to individual option if migration hasn't been completed yet
	 * (backward compatibility). This function should be used instead of get_option()
	 * for all customizer settings.
	 *
	 * If the retrieved value is empty, null, or whitespace-only, it will automatically
	 * fall back to the provided default value to ensure emails always have valid content.
	 *
	 * @since 2.9.0
	 * @param string $key     Setting key to retrieve.
	 * @param mixed  $default Default value if setting doesn't exist or is empty.
	 * @return mixed Setting value or default.
	 */
	public function cev_pro_customizer_settings( $key, $default = false ) {
		$consolidated_settings = get_option( 'cev_pro_customizer', array() );
		$value = false;

		// If consolidated settings exist and key is present, get the value.
		if ( is_array( $consolidated_settings ) && isset( $consolidated_settings[ $key ] ) ) {
			$value = $consolidated_settings[ $key ];
		} else {
			// Fallback to individual option for backward compatibility.
			$value = get_option( $key, false );
		}

		// If value is empty, null, or whitespace-only, fall back to default.
		// This ensures emails always have valid content (subject, heading, body).
		if ( false === $value || null === $value || '' === $value || ( is_string( $value ) && '' === trim( $value ) ) ) {
			return $default;
		}

		return $value;
	}

	/**
	 * Build the popup design-token map from the Customizer settings.
	 *
	 * Single source of truth for every customer-facing verification surface.
	 * Before this existed each template re-read the same keys and re-emitted
	 * them as inline style="" attributes, which meant the values could not be
	 * reused by CSS, could not be overridden by a stylesheet, and drifted
	 * between the real templates and their Customizer previews.
	 *
	 * Returns raw values keyed by CSS custom property name. Use
	 * popup_style_attr() to render them into a style attribute.
	 *
	 * @since 3.1.0
	 * @return array Map of custom-property name => value.
	 */
	public function popup_style_tokens() {
		$customizer_options = class_exists( 'CEV_Customizer_Options' ) ? new CEV_Customizer_Options() : null;
		$defaults           = ( is_object( $customizer_options ) && isset( $customizer_options->defaults ) && is_array( $customizer_options->defaults ) )
			? $customizer_options->defaults
			: array();

		$fallback = function ( $key, $hard_default ) use ( $defaults ) {
			return isset( $defaults[ $key ] ) ? $defaults[ $key ] : $hard_default;
		};

		$overlay = $this->cev_pro_customizer_settings( 'cev_verification_popup_overlay_background_color', $fallback( 'cev_verification_popup_overlay_background_color', '#ffffff' ) );
		$surface = $this->cev_pro_customizer_settings( 'cev_verification_popup_background_color', $fallback( 'cev_verification_popup_background_color', '#ffffff' ) );
		$align   = $this->cev_pro_customizer_settings( 'cev_content_align', 'center' );
		$width   = $this->cev_pro_customizer_settings( 'cev_widget_content_width', 440 );
		$pad     = $this->cev_pro_customizer_settings( 'cev_widget_content_padding', 30 );
		$img_w   = $this->cev_pro_customizer_settings( 'cev_widget_header_image_width', 80 );
		$head_fs = $this->cev_pro_customizer_settings( 'cev_button_text_header_font_size', 18 );
		$btn_bg  = $this->cev_pro_customizer_settings( 'cev_button_color_widget_header', $fallback( 'cev_button_color_widget_header', '#212121' ) );
		$btn_fg  = $this->cev_pro_customizer_settings( 'cev_button_text_color_widget_header', $fallback( 'cev_button_text_color_widget_header', '#ffffff' ) );

		// Button size / full-width settings. These used to be re-computed and
		// re-inlined by each checkout template; as tokens the stylesheet owns
		// the button and the settings still drive it.
		$btn_size  = $this->cev_pro_customizer_settings( 'cev_popup_button_size', $fallback( 'cev_popup_button_size', 'normal' ) );
		$btn_full  = $this->cev_pro_customizer_settings( 'sample_toggle_switch_cev', $fallback( 'sample_toggle_switch_cev', 0 ) );
		$is_large  = ( 'large' === strtolower( (string) $btn_size ) );

		// 'left' is the only alternative the Customizer offers; anything else is centre.
		$align = ( 'left' === strtolower( (string) $align ) ) ? 'left' : 'center';

		$tokens = array(
			'--cev-popup-overlay'      => $this->hex2rgba( $overlay, '0.7' ),
			'--cev-popup-surface'      => $surface,
			'--cev-popup-align'        => $align,
			// text-align cannot steer a flex container, so the OTP row needs the
			// alignment as a justify-content value too or it stays centred while
			// the copy above it goes left.
			'--cev-popup-justify'      => ( 'left' === $align ) ? 'flex-start' : 'center',
			'--cev-popup-width'        => absint( $width ) . 'px',
			'--cev-popup-pad'          => absint( $pad ) . 'px',
			'--cev-popup-img-width'    => absint( $img_w ) . 'px',
			'--cev-popup-heading-size' => absint( $head_fs ) . 'px',
			'--cev-popup-accent'       => $btn_bg,
			'--cev-popup-on-accent'    => $btn_fg,
			'--cev-popup-btn-size'     => $is_large ? '17px' : '15px',
			'--cev-popup-btn-pad'      => $is_large ? '14px 24px' : '12px 20px',
			'--cev-popup-btn-width'    => ( '1' === (string) $btn_full ) ? '100%' : 'auto',
		);

		/**
		 * Filter the popup design tokens.
		 *
		 * Lets a site override any token (or add its own) without touching a
		 * template. Values are emitted verbatim into a style attribute, so any
		 * value added here must already be a safe CSS value.
		 *
		 * @since 3.1.0
		 * @param array $tokens Map of custom-property name => value.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return apply_filters( 'cev_popup_style_tokens', $tokens );
	}

	/**
	 * Render the popup design tokens as a style attribute value.
	 *
	 * Emit this on a popup ROOT element; every descendant then reads the
	 * tokens through var(). Returns a RAW "--key:value;" string — escape it
	 * at the call site with esc_attr() as usual:
	 *
	 *   style="<?php echo esc_attr( cev_pro()->function->popup_style_attr() ); ?>"
	 *
	 * @since 3.1.0
	 * @return string Raw "--key:value;--key:value;" string.
	 */
	public function popup_style_attr() {
		$out = '';
		foreach ( $this->popup_style_tokens() as $prop => $value ) {
			if ( '' === $value || null === $value ) {
				continue;
			}
			// Strip anything that could break out of the attribute or inject
			// a second declaration; tokens are colours, lengths and keywords.
			$value = str_replace( array( '"', "'", ';', '<', '>' ), '', (string) $value );
			$out  .= $prop . ':' . trim( $value ) . ';';
		}
		return $out;
	}

	/**
	 * Whether the popup header should render the built-in mark.
	 *
	 * The mark is the default header: a small accent tile with an envelope
	 * glyph, sized and coloured from the popup tokens. It replaces the old
	 * logo lockup, which dominated the card and looked different on every
	 * store.
	 *
	 * The Customizer's Header Image setting still wins — a merchant who
	 * uploads their own image gets exactly that. The mark shows when the
	 * setting is empty or still on one of the bundled defaults, i.e. when the
	 * merchant has not chosen anything.
	 *
	 * @since 3.1.0
	 * @return bool True when the mark should render instead of an <img>.
	 */
	public function popup_uses_mark() {
		$image = (string) $this->cev_pro_customizer_settings( 'cev_verification_image', '' );

		$bundled = array(
			cev_pro()->plugin_dir_url() . 'assets/css/images/email-verification.svg',
			cev_pro()->plugin_dir_url() . 'assets/css/images/email-verification-icon.svg',
			cev_pro()->plugin_dir_url() . 'assets/css/images/email-verification.png',
		);

		$uses_mark = ( '' === trim( $image ) || in_array( $image, $bundled, true ) );

		/**
		 * Filter whether the popup renders the built-in mark.
		 *
		 * Return true to force the mark even when a Header Image is set, or
		 * false to always honour the image.
		 *
		 * @since 3.1.0
		 * @param bool   $uses_mark Whether the mark renders.
		 * @param string $image     The configured Header Image URL.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (bool) apply_filters( 'cev_popup_uses_mark', $uses_mark, $image );
	}

	/**
	 * Render the popup header — the mark, or the merchant's Header Image.
	 *
	 * Single source of truth so the live popups and their Customizer previews
	 * cannot drift. Returns escaped, ready-to-echo markup.
	 *
	 * @since 3.1.0
	 * @param string $alt Alt text for the image variant.
	 * @return string HTML.
	 */
	public function popup_header_html( $alt = '' ) {
		if ( ! $this->popup_uses_mark() ) {
			$image = (string) $this->cev_pro_customizer_settings( 'cev_verification_image', '' );
			if ( '' === trim( $image ) ) {
				return '';
			}
			return '<div class="popup_image"><img src="' . esc_url( $image ) . '" alt="' . esc_attr( $alt ) . '" /></div>';
		}

		// Envelope glyph, stroked with currentColor so it inherits the mark's
		// foreground token.
		return '<span class="cev-popup-mark" aria-hidden="true">'
			. '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" focusable="false">'
			. '<rect x="2" y="4" width="20" height="16" rx="2"></rect>'
			. '<path d="m22 7-10 6L2 7"></path>'
			. '</svg></span>';
	}

	/**
	 * Whether Polylang (free or Pro) is active.
	 *
	 * Auto-detected — there is no admin toggle. Gates all Polylang string
	 * registration / translation so WPML-only and non-multilingual installs
	 * are completely unaffected.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public function cev_pro_is_polylang_active() {
		return ( defined( 'POLYLANG_VERSION' ) || function_exists( 'pll_register_string' ) ) && function_exists( 'pll__' );
	}

	/**
	 * Convert a WordPress locale (e.g. de_DE) to a Polylang slug (e.g. de).
	 *
	 * Polylang exposes no public locale→slug API, so we index-match the
	 * parallel slug/locale lists.
	 *
	 * @since 2.10.0
	 * @param string $locale WordPress locale.
	 * @return string Polylang slug, or '' when not found.
	 */
	private function cev_pro_locale_to_slug( $locale ) {
		if ( empty( $locale ) || ! function_exists( 'pll_languages_list' ) ) {
			return '';
		}

		$slugs   = pll_languages_list( array( 'fields' => 'slug' ) );
		$locales = pll_languages_list( array( 'fields' => 'locale' ) );
		if ( is_array( $slugs ) && is_array( $locales ) ) {
			$index = array_search( $locale, $locales, true );
			if ( false !== $index && isset( $slugs[ $index ] ) ) {
				return $slugs[ $index ];
			}
		}

		return '';
	}

	/**
	 * Resolve the Polylang language slug to use for a verification email.
	 *
	 * Prefers the recipient's saved WP profile locale (registered users),
	 * then the current request language, then the site default. Filterable
	 * via `cev_pro_email_language_slug`.
	 *
	 * @since 2.10.0
	 * @param int    $user_id         Recipient user ID (0 for guests).
	 * @param string $recipient_email Recipient email (passed to the filter).
	 * @return string Polylang language slug ('' when Polylang is inactive).
	 */
	public function cev_pro_recipient_language( $user_id = 0, $recipient_email = '' ) {
		$slug = '';

		if ( $this->cev_pro_is_polylang_active() ) {
			if ( $user_id > 0 ) {
				$slug = $this->cev_pro_locale_to_slug( get_user_meta( $user_id, 'locale', true ) );
			}
			if ( '' === $slug && function_exists( 'pll_current_language' ) ) {
				$current = pll_current_language( 'slug' );
				$slug    = $current ? $current : '';
			}
			if ( '' === $slug && function_exists( 'pll_default_language' ) ) {
				$default = pll_default_language( 'slug' );
				$slug    = $default ? $default : '';
			}
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return apply_filters( 'cev_pro_email_language_slug', $slug, $user_id, $recipient_email );
	}

	/**
	 * Translate a registered string into a given Polylang language.
	 *
	 * No-op (returns the value unchanged) when Polylang is inactive, so WPML
	 * and non-multilingual installs are untouched. When the slug is empty the
	 * current/default language is used. Returns the original when no
	 * translation exists or the language is inactive — never fatals/blanks.
	 *
	 * @since 2.10.0
	 * @param string $value     The (registered) source string.
	 * @param string $lang_slug Target language slug; '' = current/default.
	 * @return string Translated string, or the original.
	 */
	public function cev_pro_translate_string( $value, $lang_slug = '' ) {
		if ( ! is_string( $value ) || '' === $value || ! $this->cev_pro_is_polylang_active() ) {
			return $value;
		}

		if ( '' === $lang_slug ) {
			if ( function_exists( 'pll_current_language' ) ) {
				$current   = pll_current_language( 'slug' );
				$lang_slug = $current ? $current : '';
			}
			if ( '' === $lang_slug && function_exists( 'pll_default_language' ) ) {
				$default   = pll_default_language( 'slug' );
				$lang_slug = $default ? $default : '';
			}
		}

		if ( '' === $lang_slug || ! function_exists( 'pll_translate_string' ) ) {
			return $value;
		}

		return pll_translate_string( $value, $lang_slug );
	}

	/**
	 * Read an admin message and translate it into the current Polylang
	 * language. Used at the customer-facing display sites of the three admin
	 * messages (resend-limit / success / disposable-block).
	 *
	 * @since 2.10.0
	 * @param string $key       Admin setting key.
	 * @param mixed  $default   Default value.
	 * @param string $lang_slug Target slug; '' = current/default.
	 * @return mixed Translated value (raw value when Polylang inactive).
	 */
	public function cev_pro_admin_message( $key, $default = false, $lang_slug = '' ) {
		return $this->cev_pro_translate_string( $this->cev_pro_admin_settings( $key, $default ), $lang_slug );
	}

	/**
	 * The full list of admin-configurable strings exposed to Polylang's
	 * String Translations panel. Single source of truth for registration.
	 *
	 * Each entry: name (panel label — plain English, NOT a gettext string),
	 * key (option key), reader ('customizer' | 'admin'), multiline (bool).
	 *
	 * @since 2.10.0
	 * @return array
	 */
	public function cev_pro_string_registry() {
		return array(
			array( 'name' => 'Registration Email Subject', 'key' => 'cev_verification_email_subject', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Registration Email Heading', 'key' => 'cev_verification_email_heading', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Registration Email Body', 'key' => 'cev_verification_email_body', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Registration Email Footer', 'key' => 'cev_new_verification_Footer_content', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Account Verify Email Subject', 'key' => 'cev_verification_email_subject_av', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Account Verify Email Heading', 'key' => 'cev_verification_email_heading_av', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Account Verify Email Body', 'key' => 'cev_verification_email_body_av', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Account Verify Email Footer', 'key' => 'cev_new_verification_Footer_content_av', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Checkout Email Subject', 'key' => 'cev_verification_email_subject_che', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Checkout Email Heading', 'key' => 'cev_verification_email_heading_che', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Checkout Email Body', 'key' => 'cev_verification_email_body_che', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Checkout Email Footer', 'key' => 'cev_new_verification_Footer_content_che', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Edit Account Email Subject', 'key' => 'cev_verification_email_subject_ed', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Edit Account Email Heading', 'key' => 'cev_verification_email_heading_ed', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Edit Account Email Body', 'key' => 'cev_verification_email_body_ed', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Login OTP Email Subject', 'key' => 'cev_verification_login_otp_email_subject', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Login OTP Email Heading', 'key' => 'cev_verification_login_otp_email_heading', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Login OTP Email Content', 'key' => 'cev_verification_login_otp_email_content', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Login OTP Email Footer', 'key' => 'cev_login_otp_footer_content', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Login Auth Email Subject', 'key' => 'cev_verification_login_auth_email_subject', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Login Auth Email Heading', 'key' => 'cev_verification_login_auth_email_heading', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Login Auth Email Content', 'key' => 'cev_verification_login_auth_email_content', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Login Auth Email Footer', 'key' => 'cev_login_auth_footer_content', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Registration Popup Header', 'key' => 'cev_verification_header', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Registration Popup Message', 'key' => 'cev_verification_message', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Registration Popup Footer', 'key' => 'cev_verification_widget_footer', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Registration Popup Button Text', 'key' => 'cev_verification_header_button_text', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Popup Send Button Text', 'key' => 'cev_verification_header_send_verify_button_text', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Popup Verify Button Text', 'key' => 'cev_verification_header_verify_button_text', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Checkout Popup Header', 'key' => 'cev_header_text_checkout', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Checkout Popup Message', 'key' => 'cev_verification_widget_message_checkout', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Checkout Popup Footer', 'key' => 'cev_verification_widget_message_footer_checkout_pro', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Account Verify Popup Header', 'key' => 'cev_account_verify_header', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Account Verify Popup Message', 'key' => 'cev_account_verify_message', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Account Verify Popup Footer', 'key' => 'cev_account_verify_footer', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Login Auth Popup Header', 'key' => 'cev_login_auth_header', 'reader' => 'customizer', 'multiline' => false ),
			array( 'name' => 'Login Auth Popup Message', 'key' => 'cev_login_auth_message', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Login Auth Popup Footer', 'key' => 'cev_login_auth_widget_footer', 'reader' => 'customizer', 'multiline' => true ),
			array( 'name' => 'Resend Limit Message', 'key' => 'cev_resend_limit_message', 'reader' => 'admin', 'multiline' => false ),
			array( 'name' => 'Verification Success Message', 'key' => 'cev_verification_success_message', 'reader' => 'admin', 'multiline' => false ),
			array( 'name' => 'Disposable Block Message', 'key' => 'cev_disposable_block_message', 'reader' => 'admin', 'multiline' => false ),
		);
	}

	/**
	 * Register every admin-configurable string with Polylang so it appears in
	 * Languages → String Translations under "Customer Email Verification Pro".
	 * Hooked on admin_init (Polylang only registers admin-side).
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function cev_pro_register_polylang_strings() {
		if ( ! $this->cev_pro_is_polylang_active() || ! function_exists( 'pll_register_string' ) ) {
			return;
		}

		$customizer_options = class_exists( 'CEV_Customizer_Options' ) ? new CEV_Customizer_Options() : null;
		$defaults           = ( $customizer_options && isset( $customizer_options->defaults ) ) ? $customizer_options->defaults : array();
		$context            = 'Customer Email Verification Pro';

		foreach ( $this->cev_pro_string_registry() as $entry ) {
			$default = isset( $defaults[ $entry['key'] ] ) ? $defaults[ $entry['key'] ] : '';
			if ( 'admin' === $entry['reader'] ) {
				$value = $this->cev_pro_admin_settings( $entry['key'], $default );
			} else {
				$value = $this->cev_pro_customizer_settings( $entry['key'], $default );
			}
			if ( is_string( $value ) && '' !== $value ) {
				pll_register_string( $entry['name'], $value, $context, ! empty( $entry['multiline'] ) );
			}
		}
	}

	/**
	 * Send verification code email
	 *
	 * Generates a verification PIN, stores it in user meta, and sends an email
	 * with the verification code to the recipient.
	 *
	 * @since 1.0.0
	 * @param string $recipient Email address to send verification code to.
	 * @return bool True if email was sent successfully, false otherwise.
	 */
	public function code_mail_sender( $recipient, $email_type = 'email_registration' ) {
		if ( empty( $recipient ) || ! is_email( $recipient ) ) {
			return false;
		}
		
		$user_id = $this->wuev_user_id;
		if ( empty( $user_id ) || ! get_user_by( 'ID', $user_id ) ) {
			return false;
		}
		
		$verification_pin = $this->generate_verification_pin();
		$CEV_Customizer_Options = new CEV_Customizer_Options();
		
		$expire_time = $this->cev_pro_admin_settings( 'cev_verification_code_expiration', 'never' );
		
		if ( empty( $expire_time ) ) {
			$expire_time = 'never';
		}
		
		// Calculate enddate - handle 'never' case properly.
		if ( 'never' === $expire_time ) {
			$enddate = 0; // Never expires.
		} else {
			$enddate = time() + (int) $expire_time;
		}
		
		$verification_data = array(
			'pin' => $verification_pin, 
			'startdate' => time(),
			'enddate' => $enddate,
		);		

		update_user_meta( $user_id, 'cev_email_verification_pin', $verification_data );
		
		$result = false;

		// Resolve which customizer option keys to read based on the email
		// type, so a dedicated type (e.g. Account Verification) uses its own
		// subject/heading/body/footer while defaulting to Registration.
		$key_map = array(
			'email_registration'   => array(
				'subject' => 'cev_verification_email_subject',
				'heading' => 'cev_verification_email_heading',
				'body'    => 'cev_verification_email_body',
				'footer'  => 'cev_new_verification_Footer_content',
			),
			'email_account_verify' => array(
				'subject' => 'cev_verification_email_subject_av',
				'heading' => 'cev_verification_email_heading_av',
				'body'    => 'cev_verification_email_body_av',
				'footer'  => 'cev_new_verification_Footer_content_av',
			),
		);
		$keys = isset( $key_map[ $email_type ] ) ? $key_map[ $email_type ] : $key_map['email_registration'];

		// Translate the customizer strings into the recipient's language (Polylang; no-op otherwise).
		$cev_lang = $this->cev_pro_recipient_language( $user_id, $recipient );

		$email_subject = $this->cev_pro_customizer_settings( $keys['subject'], $CEV_Customizer_Options->defaults[ $keys['subject'] ] );
		$email_subject = $this->cev_pro_translate_string( $email_subject, $cev_lang );
		$email_subject = $this->maybe_parse_merge_tags( $email_subject, $this );
		$email_heading = $this->cev_pro_customizer_settings( $keys['heading'], $CEV_Customizer_Options->defaults[ $keys['heading'] ] );
		$email_heading = $this->cev_pro_translate_string( $email_heading, $cev_lang );

		$mailer = WC()->mailer();

		$content = $this->cev_pro_customizer_settings( $keys['body'], $CEV_Customizer_Options->defaults[ $keys['body'] ] );
		$content = $this->cev_pro_translate_string( $content, $cev_lang );
		$content = $this->maybe_parse_merge_tags( $content, $this );
		$footer_content = $this->cev_pro_customizer_settings( $keys['footer'], '' );
		$footer_content = $this->cev_pro_translate_string( $footer_content, $cev_lang );
		
		$email_content = '';
		
		$local_template = get_stylesheet_directory() . '/woocommerce/emails/cev-email-verification.php';
		if ( file_exists( $local_template ) ) {
			$email_content .= wc_get_template_html( 'emails/cev-email-verification.php', array(
				'email_heading' => $email_heading,
				'content' => $content,
				'footer_content' => $footer_content,
			), 'customer-email-verification/', get_stylesheet_directory() . '/woocommerce/' );
		} else {
			$email_content .= wc_get_template_html( 'emails/cev-email-verification.php', array( 
				'email_heading' => $email_heading,
				'content' => $content,
				'footer_content' => $footer_content,					
			), 'customer-email-verification/', cev_pro()->get_plugin_path() . '/templates/' );
		}
		
		// create a new email
		$email = new WC_Email();
		$email->id = 'CEV_Registration_Verification';
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		$email_body = apply_filters( 'woocommerce_mail_content', $email->style_inline( $mailer->wrap_message( $email_heading, $email_content ) ) );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned filter (legacy wc_cev_ prefix); renaming would break sites already hooking it.
		$email_body = apply_filters( 'wc_cev_decode_html_content', $email_body );
		
		add_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
		add_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
				
		// Bound a stuck SMTP connection so a verification email can't hold the
		// request open for minutes (PHPMailer defaults to a 300s timeout) and
		// trip a 504. Scoped to this send only.
		add_action( 'phpmailer_init', array( $this, 'cap_smtp_timeout' ) );
		$result = wp_mail( $recipient, $email_subject, $email_body, $email->get_headers() );
		remove_action( 'phpmailer_init', array( $this, 'cap_smtp_timeout' ) );

		return $result;
	}

	/**
	 * Cap PHPMailer's SMTP timeout for a verification-email send. PHPMailer
	 * defaults to 300 seconds, so a stuck SMTP connection can hold an AJAX
	 * request open long enough to trip a 504. Added/removed around individual
	 * sends in code_mail_sender(); filter cev_smtp_timeout to adjust.
	 *
	 * @since 2.10.0
	 * @param object $phpmailer The PHPMailer instance (passed by reference).
	 * @return void
	 */
	public function cap_smtp_timeout( $phpmailer ) {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$timeout = (int) apply_filters( 'cev_smtp_timeout', 15 );
		if ( 0 < $timeout ) {
			$phpmailer->Timeout = $timeout;
		}
	}

	/**
	 * Generate a verification PIN and store it in the cev_email_verification_pin
	 * user meta WITHOUT sending an email. Used by channels that deliver the OTP
	 * themselves (e.g. the Smart Form's SMS registration). Mirrors the storage
	 * shape code_mail_sender() writes, so the existing verify routines read it
	 * unchanged.
	 *
	 * @since 2.10.0
	 * @param int $user_id User to issue the code for.
	 * @return string The generated PIN, or '' on failure.
	 */
	public function store_verification_pin( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 || ! get_user_by( 'ID', $user_id ) ) {
			return '';
		}

		$verification_pin = $this->generate_verification_pin();

		$expire_time = $this->cev_pro_admin_settings( 'cev_verification_code_expiration', 'never' );
		if ( empty( $expire_time ) ) {
			$expire_time = 'never';
		}
		$enddate = ( 'never' === $expire_time ) ? 0 : time() + (int) $expire_time;

		update_user_meta(
			$user_id,
			'cev_email_verification_pin',
			array(
				'pin'       => $verification_pin,
				'startdate' => time(),
				'enddate'   => $enddate,
			)
		);

		return (string) $verification_pin;
	}

	/**
	 * Maybe try and parse content to found the merge tags.
	 *
	 * Converts merge tags to their actual values in email content.
	 * Supports both {{tag}} and {tag} formats.
	 * This is a consolidated method moved from multiple classes to eliminate duplication.
	 *
	 * @since 2.8.6
	 * @param string $content Content to parse.
	 * @param object $context_object Object that contains get_all_tags() method and merge tag callback methods.
	 * @return string Parsed content with merge tags replaced.
	 */
	public function maybe_parse_merge_tags( $content = '', $context_object = null ) {
		if ( empty( $content ) ) {
			return $content;
		}

		// If no context object provided, use the email common class as default.
		if ( null === $context_object ) {
			$context_object = $this;
		}

		// Determine context type for get_all_tags.
		// Use 'full' context to allow all merge tags (login_browser, login_device, etc.) to work.
		// The individual methods will handle context-specific logic internally.
		$context_type = 'full';

		// Get all available merge tags from functions class.
		$get_all      = $this->get_all_tags( $context_type );
		$get_all_tags = wp_list_pluck( $get_all, 'tag' );

		if ( empty( $get_all_tags ) || ! is_array( $get_all_tags ) ) {
			return $content;
		}

		// Parse both {{tag}} and {tag} formats in a single pass.
		$content = $this->parse_merge_tags_format( $content, $get_all_tags, $context_object );

		return $content;
	}

	/**
	 * Parse merge tags in both {{tag}} and {tag} formats.
	 *
	 * Helper method for maybe_parse_merge_tags(). Optimized to parse both formats in a single pass.
	 *
	 * @since 2.8.6
	 * @param string $content        Content to parse.
	 * @param array  $tags           Array of tag names.
	 * @param object $context_object Object that contains merge tag callback methods.
	 * @return string Parsed content.
	 */
	private function parse_merge_tags_format( $content, $tags, $context_object ) {
		foreach ( $tags as $tag ) {
			// Simplified regex patterns without unnecessary capture groups.
			$patterns = array(
				'/\{{' . preg_quote( $tag, '/' ) . '\}}/',  // {{tag}} format.
				'/\{' . preg_quote( $tag, '/' ) . '\}/',    // {tag} format.
			);

			foreach ( $patterns as $pattern ) {
				$matches = array();
				preg_match_all( $pattern, $content, $matches );

				if ( ! empty( $matches[0] ) && is_array( $matches[0] ) ) {
					foreach ( $matches[0] as $exact_match ) {
						$old_match = $exact_match;
						$single    = str_replace( array( '{{', '}}', '{', '}' ), '', $old_match );

						// Unified method resolution - check functions class first.
						if ( method_exists( $this, $single ) ) {
							// Check if method is static (like site_title).
							$reflection = new ReflectionMethod( $this, $single );
							if ( $reflection->isStatic() ) {
								// Call static method.
								try {
									$get_parsed_value = call_user_func( array( get_class( $this ), $single ) );
								} catch ( Exception $e ) {
									continue;
								}
							} else {
								// Call instance method with context object.
								try {
									$get_parsed_value = call_user_func( array( $this, $single ), $context_object );
								} catch ( Exception $e ) {
									continue;
								}
							}

							// Validate return type is string.
							if ( ! is_string( $get_parsed_value ) ) {
								$get_parsed_value = (string) $get_parsed_value;
							}

							$content = str_replace( $old_match, $get_parsed_value, $content );
						} elseif ( method_exists( $context_object, $single ) ) {
							// Fallback: Check if callback method exists in context object (for backward compatibility).
							try {
								$get_parsed_value = call_user_func( array( $context_object, $single ) );
								// Validate return type is string.
								if ( ! is_string( $get_parsed_value ) ) {
									$get_parsed_value = (string) $get_parsed_value;
								}
								$content = str_replace( $old_match, $get_parsed_value, $content );
							} catch ( Exception $e ) {
								continue;
							}
						}
					}
				}
			}
		}

		return $content;
	}

	/**
	 * Get all available merge tags.
	 *
	 * Returns array of merge tags based on context type.
	 * This is a consolidated method moved from multiple classes to eliminate duplication.
	 *
	 * @since 2.8.6
	 * @param string $context_type Type of context: 'full' for all tags (default), 'checkout' for checkout-specific tags only.
	 * @return array Array of merge tags with name and tag keys.
	 */
	public function get_all_tags( $context_type = 'full' ) {
		if ( 'checkout' === $context_type ) {
			// Checkout-specific tags (limited set).
			return array(
				array(
					'name' => __( 'Verification Pin', 'customer-email-verification' ),
					'tag'  => 'cev_user_verification_pin',
				),
				array(
					'name' => __( 'Site Title', 'customer-email-verification' ),
					'tag'  => 'site_title',
				),
			);
		}

		// Full set of tags (default).
		return array(
			array(
				'name' => __( 'User login', 'customer-email-verification' ),
				'tag'  => 'cev_user_login',
			),
			array(
				'name' => __( 'User display name', 'customer-email-verification' ),
				'tag'  => 'cev_display_name',
			),
			array(
				'name' => __( 'User email', 'customer-email-verification' ),
				'tag'  => 'cev_user_email',
			),
			array(
				'name' => __( 'Verification Pin', 'customer-email-verification' ),
				'tag'  => 'cev_user_verification_pin',
			),
			array(
				'name' => __( 'Site Title', 'customer-email-verification' ),
				'tag'  => 'site_title',
			),
			array(
				'name' => __( 'Try Again', 'customer-email-verification' ),
				'tag'  => 'cev_resend_verification',
			),
			array(
				'name' => __( 'Login IP', 'customer-email-verification' ),
				'tag'  => 'login_ip',
			),
			array(
				'name' => __( 'Login Time', 'customer-email-verification' ),
				'tag'  => 'login_time',
			),
			array(
				'name' => __( 'Login Browser', 'customer-email-verification' ),
				'tag'  => 'login_browser',
			),
			array(
				'name' => __( 'Login Device', 'customer-email-verification' ),
				'tag'  => 'login_device',
			),
			array(
				'name' => __( 'Cancel Verification', 'customer-email-verification' ),
				'tag'  => 'cev_cancel_verification',
			),
			array(
				'name' => __( 'Login OTP', 'customer-email-verification' ),
				'tag'  => 'login_otp',
			),
			array(
				'name' => __( 'Change Password Button', 'customer-email-verification' ),
				'tag'  => 'change_password',
			),
			array(
				'name' => __( 'Registration Page URL', 'customer-email-verification' ),
				'tag'  => 'registration_page_url',
			),
		);
	}

	/**
	 * Return the registration / My Account page URL.
	 *
	 * Used by the re-engagement reminder email button as a default
	 * destination — sends users to the My Account page where they can
	 * complete sign-up. Falls back to the site root if the My Account
	 * page isn't configured.
	 *
	 * Filterable via `cev_reengagement_button_url` so integrators can
	 * point it at a custom landing page if needed.
	 *
	 * @since 2.10.0
	 * @param object|null $context_object Unused — kept for callback signature parity.
	 * @return string URL.
	 */
	public function registration_page_url( $context_object = null ) {
		$url = '';
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			$url = (string) wc_get_page_permalink( 'myaccount' );
		}
		if ( empty( $url ) ) {
			$url = home_url( '/' );
		}
		/**
		 * Filter the URL used by the re-engagement reminder button.
		 *
		 * @since 2.10.0
		 * @param string $url The resolved URL.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return apply_filters( 'cev_reengagement_button_url', $url );
	}

	/**
	 * Decide whether login authentication should run for a given user.
	 *
	 * Replaces the legacy "always skip Administrator / Editor" check. The
	 * admin chooses an enforcement policy in Settings → Login Authentication
	 * → Apply to, which can be:
	 *
	 *   - all_users      — every user must verify
	 *   - roles_only     — only users in `cev_login_auth_roles` (e.g. Admin + Editor)
	 *   - excluded_roles — every user EXCEPT roles in `cev_login_auth_roles`
	 *                      (default — preserves the pre-2.10.0 behaviour
	 *                      where Administrator + Editor were skipped)
	 *
	 * Filterable via `cev_should_enforce_login_auth_for_user` so site owners
	 * can plug in custom logic (e.g. exempt a specific user, force enable
	 * for a custom role) without editing the plugin.
	 *
	 * @since 2.10.0
	 * @param int $user_id WP user ID.
	 * @return bool True if login auth should run for this user.
	 */
	public function should_enforce_login_auth_for_user( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return false;
		}

		$user = get_userdata( $user_id );
		if ( ! $user || ! $user->exists() ) {
			return false;
		}

		// Default to the legacy behaviour for upgrade safety: skip
		// Administrator + Editor unless the admin overrides.
		$policy = (string) $this->cev_pro_admin_settings( 'cev_login_auth_enforcement', 'excluded_roles' );

		// Roles list is stored by the multiple_select renderer as
		// { role_key => 0|1 }. Normalise to a flat list of role keys.
		$roles_raw = $this->cev_pro_admin_settings( 'cev_login_auth_roles', array() );
		$roles     = array();
		if ( is_array( $roles_raw ) ) {
			foreach ( $roles_raw as $key => $val ) {
				if ( is_int( $key ) ) {
					$roles[] = (string) $val;
				} elseif ( 1 === (int) $val ) {
					$roles[] = (string) $key;
				}
			}
		}

		// Backward-compat: if the admin never visited the new settings,
		// `cev_login_auth_roles` is empty. Fall back to the historical
		// admin/editor exclusion so existing sites behave identically.
		if ( empty( $roles ) && 'excluded_roles' === $policy ) {
			$roles = array( 'administrator', 'editor' );
		}

		$user_roles = (array) $user->roles;

		switch ( $policy ) {
			case 'all_users':
				$enforce = true;
				break;

			case 'roles_only':
				// Empty role list with `roles_only` would mean "enforce on no
				// one" — treat as a misconfig and fail closed (don't enforce).
				$enforce = ! empty( $roles ) && (bool) array_intersect( $user_roles, $roles );
				break;

			case 'excluded_roles':
			default:
				$enforce = ! array_intersect( $user_roles, $roles );
				break;
		}

		/**
		 * Filter the final enforcement decision for a given user.
		 *
		 * @since 2.10.0
		 * @param bool   $enforce Whether login auth should run for this user.
		 * @param int    $user_id User being evaluated.
		 * @param string $policy  Resolved policy value.
		 * @param array  $roles   Resolved role list.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (bool) apply_filters( 'cev_should_enforce_login_auth_for_user', $enforce, $user_id, $policy, $roles );
	}

	/**
	 * Return Email Verification pin (alias method that routes based on context).
	 * 
	 * This method routes to the appropriate PIN retrieval method based on the context object type.
	 * For backward compatibility with merge tag {cev_user_verification_pin}.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object to determine user type.
	 * @return string Verification pin HTML.
	 */
	public function cev_user_verification_pin( $context_object = null ) {
		// Validate context object - if null or not an object, default to registered user context.
		if ( null === $context_object || ! is_object( $context_object ) ) {
			$context_object = $this;
		}

		// If a login OTP value is present on the context (e.g. for login OTP
		// emails), prefer that directly. This allows {cev_user_verification_pin}
		// to be used for login OTP emails and previews.
		if ( isset( $context_object->login_otp ) && '' !== $context_object->login_otp ) {
			return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $context_object->login_otp ) . '</span></span>';
		}
		
		// Check if this is a checkout preview context (has session data but not a CEV_Checkout_Email instance).
		$is_checkout_preview = ( isset( $context_object->is_checkout_preview ) && $context_object->is_checkout_preview );
		
		// Route to appropriate method based on context object type.
		// CEV_Checkout_Email indicates guest user during checkout.
		if ( is_a( $context_object, 'CEV_Checkout_Email' ) || $is_checkout_preview ) {
			// Guest user context - get PIN from WooCommerce session.
			return $this->cev_guest_user_verification_pin();
		} else {
			// Registered user context - get PIN from database or user meta.
			return $this->cev_registered_user_verification_pin( $context_object );
		}
	}

	/**
	 * Return verification PIN for registered users.
	 * 
	 * Gets PIN from database (cev_user_log table) or user meta for registered users.
	 * This is a consolidated method moved from Email Common class to eliminate duplication.
	 *
	 * @since 2.8.6
	 * @param object $context_object Context object that contains registered_user_email and wuev_user_id properties.
	 * @return string Verification PIN wrapped in span tag.
	 */
	public function cev_registered_user_verification_pin( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}

		// Edit Account email change: print the PIN that flow just stored, not
		// a PIN from cev_user_log / cev_email_verification_pin (another flow).
		if ( isset( $context_object->edit_account_pin ) && '' !== (string) $context_object->edit_account_pin ) {
			return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $context_object->edit_account_pin ) . '</span></span>';
		}

		$user_email = isset( $context_object->registered_user_email ) ? $context_object->registered_user_email : null;
		
		if ( empty( $user_email ) ) {
			return '<span></span>';
		}
		
		global $wpdb;
		
		// Optimized: Single query to get PIN from database instead of two queries.
		try {
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
			$verification_pin = $wpdb->get_var( $wpdb->prepare( "SELECT pin FROM {$wpdb->prefix}cev_user_log WHERE email = %s LIMIT 1", $user_email ) );
			// phpcs:enable
		} catch ( Exception $e ) {
			$verification_pin = null;
		}
		
		if ( $verification_pin ) {
			// PIN found in database.
			return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $verification_pin ) . '</span></span>';
		}
		
		// PIN not found in database, check user meta.
		$user_id = isset( $context_object->wuev_user_id ) ? $context_object->wuev_user_id : null;
		if ( empty( $user_id ) ) {
			return '<span></span>';
		}
		
		try {
			$cev_email_verification_pin = get_user_meta( $user_id, 'cev_email_verification_pin', true );
			if ( ! empty( $cev_email_verification_pin ) && isset( $cev_email_verification_pin['pin'] ) ) {
				$verification_pin = $cev_email_verification_pin['pin'];
				return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $verification_pin ) . '</span></span>';
			}
		} catch ( Exception $e ) {
			// PIN lookup failed — fall through to generate a new one.
			unset( $e );
		}

		// PIN not found, generate new one.
		$verification_pin = $this->generate_verification_pin();
		return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $verification_pin ) . '</span></span>';
	}

	/**
	 * Return Email Verification pin for guest users.
	 * 
	 * Gets PIN from WooCommerce session data for guest users during checkout.
	 * This is a consolidated method moved from Checkout Email class to eliminate duplication.
	 *
	 * @since 2.8.6
	 * @return string Verification pin HTML.
	 */
	public function cev_guest_user_verification_pin() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return '';
		}

		$cev_user_verification_data_raw = WC()->session->get( 'cev_user_verification_data' );
		$cev_user_verification_data     = ! is_null( $cev_user_verification_data_raw ) ? json_decode( $cev_user_verification_data_raw ) : null;

		if ( empty( $cev_user_verification_data ) || ! isset( $cev_user_verification_data->pin ) ) {
			return '';
		}

		$pin = base64_decode( $cev_user_verification_data->pin ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

		return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $pin ) . '</span></span>';
	}

	/**
	 * Return cancel verification link.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @return string Cancel verification link HTML.
	 */
	public function cev_cancel_verification() {
		ob_start(); 
		?>
			<a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" class="">
				<?php esc_html_e( 'Cancel Verification', 'customer-email-verification' ); ?>
			</a>
			<?php 
		$logout = ob_get_clean();
		return $logout;
	}

	/**
	 * Return user login name.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id property.
	 * @return string User login name.
	 */
	public function cev_user_login( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		$user = get_userdata( $context_object->wuev_user_id );
		if ( ! $user ) {
			return '';
		}
		return $user->user_login;
	}

	/**
	 * Return user email address.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id property.
	 * @return string User email address.
	 */
	public function cev_user_email( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		$user = get_userdata( $context_object->wuev_user_id );
		if ( ! $user ) {
			return '';
		}
		return $user->user_email;
	}

	/**
	 * Return user display name.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id property.
	 * @return string User display name.
	 */
	public function cev_display_name( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		// For checkout emails (guest users), return site title or empty.
		$email_type = isset( $context_object->email_type ) ? $context_object->email_type : null;
		if ( 'checkout' == $email_type ) {
			// For guest users, return site title as display name.
			return get_bloginfo( 'name' );
		}
		// For registered users, get from user data.
		$user_id = isset( $context_object->wuev_user_id ) ? $context_object->wuev_user_id : null;
		if ( ! empty( $user_id ) ) {
			$user = get_userdata( $user_id );
			if ( $user ) {
				return $user->display_name;
			}
		}
		return '';
	}

	/**
	 * Return site title.
	 * 
	 * Returns the WordPress site name for use in merge tags.
	 * This is a static method that doesn't require context.
	 *
	 * @since 2.8.6
	 * @return string Site title/name.
	 */
	public static function site_title() {
		return get_bloginfo( 'name' );
	}

	/**
	 * Return resend verification link.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_myaccount_page_id property.
	 * @return string Resend verification link HTML.
	 */
	public function cev_resend_verification( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		
		$resend_limit_reached = $this->is_resend_limit_reached( get_current_user_id() );
		if ( 'login-authentication' == WC()->query->get_current_endpoint() ) {
			$resend_email_link = add_query_arg( array('cev_resend_login_otp_email' => base64_encode( get_current_user_id() ),), get_the_permalink( $context_object->wuev_myaccount_page_id ) );
		} else {
			$resend_email_link = add_query_arg( array('cev_redirect_limit_resend' => base64_encode( get_current_user_id() ),), get_the_permalink( $context_object->wuev_myaccount_page_id ) );
		}
		
		// On account pages, logged-in users navigate via URL to MY ACCOUNT to trigger resend.
		// Everywhere else (cart, checkout, etc.) use AJAX resend — works for both logged-in and guest.
		if ( is_user_logged_in() && is_account_page() ) {
			ob_start(); 
			$class = ( $resend_limit_reached ) ? 'cev-try-again-disable' : '';	
			?>
			<a href="<?php echo esc_html( $resend_email_link ); ?>" class="cev-link-try-again <?php echo esc_html( $class ); ?>"><?php esc_html_e( 'Try Again', 'customer-email-verification' ); ?></a>
			<?php 
			$try_again_url = ob_get_clean();
			return $try_again_url;
		} else { 
			$class = ( $resend_limit_reached ) ? 'cev-try-again-disable' : '';	
			if ( is_account_page() ) {
				ob_start(); 
				?>
				<a href="#" class="cev-link-try-again send_again_link  <?php echo esc_html( $class ); ?>"><?php esc_html_e( 'Try Again', 'customer-email-verification' ); ?></a>
				<?php 
				$try_again_url = ob_get_clean();
				return $try_again_url;
			} else {
				ob_start(); 
				?>
				<a href="#" class="cev-link-try-again resend_verification_code_guest_user  <?php echo esc_html( $class ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'wc_cev_email_guest_user' ) ); ?>"><?php esc_html_e( 'Try Again', 'customer-email-verification' ); ?></a>
				<?php 
				$try_again_url = ob_get_clean();
				return $try_again_url;
			}
		}		
	}


	/**
	 * Return login IP address.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id, email_type, and login_ip properties.
	 * @return string Login IP address.
	 */
	public function login_ip( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		$email_type = isset( $context_object->email_type ) ? $context_object->email_type : null;
		// For login_otp and checkout email types, use context object properties.
		if ( 'login_otp' == $email_type || 'checkout' == $email_type ) {
			if ( isset( $context_object->login_ip ) ) {
				return $context_object->login_ip;
			}
		}
		// For registered users, get from user meta.
		$user_id = isset( $context_object->wuev_user_id ) ? $context_object->wuev_user_id : null;
		if ( ! empty( $user_id ) ) {
			$user_last_login_details = get_user_meta( $user_id, 'cev_last_login_detail', true );
			if ( is_array( $user_last_login_details ) && isset( $user_last_login_details['last_login_ip'] ) ) {
				return $user_last_login_details['last_login_ip'];
			}
			if ( is_array( $user_last_login_details ) && isset( $user_last_login_details[0]['last_login_ip'] ) ) {
				return $user_last_login_details[0]['last_login_ip'];
			}
		}
		// Default fallback.
		return '192.0.2.0';
	}

	/**
	 * Return login time.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id, email_type, and login_time properties.
	 * @return string Login time.
	 */
	public function login_time( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		$email_type = isset( $context_object->email_type ) ? $context_object->email_type : null;
		// For login_otp and checkout email types, use context object properties.
		if ( 'login_otp' == $email_type || 'checkout' == $email_type ) {
			if ( isset( $context_object->login_time ) ) {
				return $context_object->login_time;
			}
		}
		// For registered users, get from user meta.
		$user_id = isset( $context_object->wuev_user_id ) ? $context_object->wuev_user_id : null;
		if ( ! empty( $user_id ) ) {
			$user_last_login_time = get_user_meta( $user_id, 'cev_last_login_time', true );
			if ( ! empty( $user_last_login_time ) ) {
				return $user_last_login_time;
			}
		}
		// Default fallback.
		return current_time( 'mysql' );
	}

	/**
	 * Return login browser.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id, email_type, and login_browser properties.
	 * @return string Login browser name.
	 */
	public function login_browser( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		$email_type = isset( $context_object->email_type ) ? $context_object->email_type : null;
		// For login_otp and checkout email types, use context object properties.
		if ( 'login_otp' == $email_type || 'checkout' == $email_type ) {
			if ( isset( $context_object->login_browser ) ) {
				return $context_object->login_browser;
			}
		}
		// For registered users, get from user meta.
		$user_id = isset( $context_object->wuev_user_id ) ? $context_object->wuev_user_id : null;
		if ( ! empty( $user_id ) ) {
			$user_last_login_details = get_user_meta( $user_id, 'cev_last_login_detail', true );
			if ( is_array( $user_last_login_details ) && isset( $user_last_login_details['last_login_browser'] ) ) {
				return $user_last_login_details['last_login_browser'];
			}
			if ( is_array( $user_last_login_details ) && isset( $user_last_login_details[0]['last_login_browser'] ) ) {
				return $user_last_login_details[0]['last_login_browser'];
			}
		}
		// Default fallback.
		return 'Chrome';
	}

	/**
	 * Return login device.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param object|null $context_object Context object with wuev_user_id, email_type, and login_device properties.
	 * @return string Login device name.
	 */
	public function login_device( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}
		$user_id = $context_object->wuev_user_id;	
		$email_type = $context_object->email_type;
		if ( 'login_otp' == $email_type ) {
			return $context_object->login_device;
		} else {
			$user_last_login_details = get_user_meta( $user_id, 'cev_last_login_detail', true );
			if ( is_array( $user_last_login_details ) && isset( $user_last_login_details['last_login_device'] ) ) {
				return $user_last_login_details['last_login_device'];
			}
			if ( is_array( $user_last_login_details ) && isset( $user_last_login_details[0]['last_login_device'] ) ) {
				return $user_last_login_details[0]['last_login_device'];
			}
			return 'Windows';
		}
	}

	/**
	 * Return login OTP styled HTML box for {login_otp} merge tag.
	 *
	 * @since 2.9.0
	 * @param object|null $context_object Context object with login_otp property.
	 * @return string Styled OTP box HTML or empty string.
	 */
	public function login_otp( $context_object = null ) {
		if ( null === $context_object ) {
			$context_object = $this;
		}

		if ( isset( $context_object->login_otp ) && '' !== $context_object->login_otp ) {
			return '<span style="display:inline-block; width:100%; max-width:300px; background-color:#f8f8fc; border:2px dashed #d0d0e0; border-radius:14px; padding:20px 16px 24px 16px; text-align:center; margin:16px 0; font-weight:normal; box-sizing:border-box;"><span style="display:block; font-size:12px; font-weight:600; color:#8888a0; text-transform:uppercase; letter-spacing:2px; font-family:Arial,Helvetica,sans-serif; margin-bottom:12px;">Your OTP Code</span><span style="display:block; font-size:36px; font-weight:800; color:#1a1a2e; letter-spacing:8px; font-family:Courier,monospace;">' . esc_html( $context_object->login_otp ) . '</span></span>';
		}

		return '';
	}

	/**
	 * Return a Change Password button for {change_password} merge tag.
	 *
	 * @since 2.9.0
	 * @param object|null $context_object Unused, kept for signature consistency.
	 * @return string HTML anchor button linking to WooCommerce change password page.
	 */
	public function change_password( $context_object = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		// Get WooCommerce "Edit account" endpoint URL.
		$change_password_url = '';

		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$change_password_url = wc_get_account_endpoint_url( 'edit-account' );
		}

		if ( empty( $change_password_url ) ) {
			$account_page_id = get_option( 'woocommerce_myaccount_page_id' );
			if ( $account_page_id ) {
				$change_password_url = get_permalink( $account_page_id );
			}
		}

		if ( empty( $change_password_url ) ) {
			return '';
		}

		$label = __( 'Change Password', 'customer-email-verification' );

		// Basic button-style link for emails.
		return '<a href="' . esc_url( $change_password_url ) . '" class="cev-change-password-button" style="display:inline-block;padding:10px 20px;background-color:#2271b1;color:#ffffff;text-decoration:none;border-radius:3px;">' . esc_html( $label ) . '</a>';
	}

	/**
	 * Decode HTML content for email display.
	 * 
	 * Removes script tags, decodes HTML entities, and removes backslashes.
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param string $content Content to decode.
	 * @return string Decoded content.
	 */
	public function wc_cev_decode_html_content( $content ) {
		if ( empty( $content ) ) {
			return '';
		}
		$content = preg_replace( '#<script(.*?)>(.*?)</script>#is', '', $content );
		// Pass $flags explicitly — PHP 8.1 changed the default; this pins the
		// modern behaviour (also decode single quotes, substitute invalid) on
		// every PHP version.
		return html_entity_decode( stripslashes( $content ), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 );
	}

	/**
	 * Get the from name for outgoing emails.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @return string From name.
	 */
	public function get_from_name() {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		$from_name = apply_filters( 'woocommerce_email_from_name', get_option( 'woocommerce_email_from_name' ), $this );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$from_name = apply_filters( 'cev_email_from_name', $from_name, $this );
		return wp_specialchars_decode( esc_html( $from_name ), ENT_QUOTES );
	}

	/**
	 * Get the from address for outgoing emails.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @return string From address.
	 */
	public function get_from_address() {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		$from_address = apply_filters( 'woocommerce_email_from_address', get_option( 'woocommerce_email_from_address' ), $this );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$from_address = apply_filters( 'cev_email_from_address', $from_address, $this );
		return sanitize_email( $from_address );
	}

	/**
	 * Allow style tags in HTML content.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param array $tags Allowed HTML tags.
	 * @return array Modified tags array.
	 */
	public function my_allowed_tags( $tags ) {
		$tags['style'] = array( 'type' => true );
		return $tags;
	}

	/**
	 * Allow display CSS style property.
	 * 
	 * Consolidated method moved from Email Common class.
	 *
	 * @since 2.8.6
	 * @param array $styles Safe CSS styles.
	 * @return array Modified styles array.
	 */
	public function safe_style_css_callback( $styles ) {
		$styles[] = 'display';
		return $styles;
	}

	/**
	 * Set up checkout email context properties for merge tag parsing.
	 * 
	 * Sets browser, device, IP, time, and other properties needed for merge tags
	 * like {login_browser}, {login_device}, {login_ip}, {login_time}, etc.
	 * This is a consolidated method moved from CEV_Checkout_Email class.
	 *
	 * @since 2.8.6
	 * @param object $context_object Context object to set properties on (typically CEV_Checkout_Email instance).
	 * @return void
	 */
	public function set_checkout_email_context_properties( $context_object ) {
		if ( ! is_object( $context_object ) ) {
			return;
		}

		// Set email type to allow merge tag methods to use context properties.
		$context_object->email_type = 'checkout';
		
		// Get user agent and parse browser/device info.
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		
		// Detect browser.
		if ( strpos( $user_agent, 'Chrome' ) !== false ) {
			$context_object->login_browser = 'Chrome';
		} elseif ( strpos( $user_agent, 'Firefox' ) !== false ) {
			$context_object->login_browser = 'Firefox';
		} elseif ( strpos( $user_agent, 'Safari' ) !== false ) {
			$context_object->login_browser = 'Safari';
		} elseif ( strpos( $user_agent, 'Edge' ) !== false ) {
			$context_object->login_browser = 'Edge';
		} elseif ( strpos( $user_agent, 'Opera' ) !== false ) {
			$context_object->login_browser = 'Opera';
		} else {
			$context_object->login_browser = 'Unknown';
		}
		
		// Detect device.
		if ( strpos( $user_agent, 'Mobile' ) !== false || strpos( $user_agent, 'Android' ) !== false || strpos( $user_agent, 'iPhone' ) !== false ) {
			$context_object->login_device = 'Mobile';
		} elseif ( strpos( $user_agent, 'Tablet' ) !== false || strpos( $user_agent, 'iPad' ) !== false ) {
			$context_object->login_device = 'Tablet';
		} else {
			$context_object->login_device = 'Desktop';
		}
		
		// Get IP address.
		$context_object->login_ip = $this->get_client_ip();
		
		// Set login time.
		$context_object->login_time = current_time( 'mysql' );
		
		// Set user ID to null for guest users (merge tag methods will handle this).
		$context_object->wuev_user_id = null;
	}

	/**
	 * Get client IP address.
	 * 
	 * Consolidated method moved from CEV_Checkout_Email class.
	 * Handles various proxy headers and validates IP addresses.
	 *
	 * @since 2.8.6
	 * @return string IP address.
	 */
	public function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP', // Cloudflare.
			'HTTP_X_REAL_IP',        // Nginx proxy.
			'HTTP_X_FORWARDED_FOR',  // Proxy.
			'REMOTE_ADDR',           // Standard.
		);

		foreach ( $ip_keys as $key ) {
			if ( isset( $_SERVER[ $key ] ) && ! empty( $_SERVER[ $key ] ) ) {
				$ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				// Handle comma-separated IPs (from X-Forwarded-For).
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = trim( explode( ',', $ip )[0] );
				}
				// Validate IP.
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}

		return '192.0.2.0'; // Default fallback.
	}

	/**
	 * Record a verification-related event in the analytics events table.
	 *
	 * Append-only. Swallows DB errors silently — the events table is for
	 * reporting only and should NEVER block the live signup / login flow
	 * if (say) the table is missing or write-locked.
	 *
	 * Common event_type values:
	 *   otp_sent / otp_verified / otp_failed
	 *   blocked_disposable / blocked_mx / blocked_blocklist /
	 *   blocked_not_in_allowlist
	 *   2fa_enrolled / 2fa_verified / 2fa_failed
	 *
	 * @since 2.10.0
	 * @param string $email      Email the event is for (or '' if unknown).
	 * @param string $event_type Short event-type slug (see list above).
	 * @param string $context    Where the event fired: 'signup' | 'checkout' |
	 *                           'edit_account' | 'login' | '2fa' | ''.
	 * @param array  $extra      Optional misc JSON-able data (e.g. domain
	 *                           that was blocked, OTP length, etc.).
	 * @param int    $user_id    Optional WP user ID (0 for guest checkout).
	 * @return void
	 */
	public function log_event( $email, $event_type, $context = '', $extra = array(), $user_id = 0 ) {
		global $wpdb;
		$table = $wpdb->prefix . 'cev_verification_events';

		// Best-effort insert. Wrap in try-catch so a bad write never
		// breaks the user-facing flow that called us.
		try {
			$ip = '';
			if ( method_exists( $this, 'get_client_ip' ) ) {
				$candidate = $this->get_client_ip();
				if ( is_string( $candidate ) && '192.0.2.0' !== $candidate ) {
					$ip = $candidate;
				}
			}

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->insert(
				$table, // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array(
					'user_id'    => $user_id > 0 ? (int) $user_id : null,
					'email'      => substr( (string) $email, 0, 190 ),
					'event_type' => substr( (string) $event_type, 0, 40 ),
					'context'    => substr( (string) $context, 0, 20 ),
					'ip'         => '' !== $ip ? substr( $ip, 0, 45 ) : null,
					'country'    => null,
					'extra'      => empty( $extra ) ? null : wp_json_encode( $extra ),
					'created_at' => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
			);
			// phpcs:enable
		} catch ( Exception $e ) {
			// Swallow — analytics must never block real user flows.
			unset( $e );
		}
	}
}

/**
 * Get the CEV_Functions_Pro instance.
 *
 * Convenience function to get the singleton instance.
 *
 * @since 2.8.6
 * @return CEV_Functions_Pro Class instance.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Plugin-owned global function; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
function cev_functions_pro() {
	return CEV_Functions_Pro::get_instance();
}

