<?php
/**
 * Dokan multi-vendor compatibility for Customer Email Verification.
 *
 * Makes Dokan vendor registrations trigger CEV's email verification by reusing
 * the existing account-verify popup + email + AJAX. Active whenever Dokan is
 * present AND signup verification (`cev_enable_email_verification`) is on — no
 * extra settings, no product gate, no vendor-specific template.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'CEV_Dokan_Integration' ) ) {

	/**
	 * CEV ↔ Dokan integration.
	 */
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Dokan_Integration {

		/**
		 * Singleton instance.
		 *
		 * @var CEV_Dokan_Integration|null
		 */
		private static $instance = null;

		/**
		 * Get the singleton instance.
		 *
		 * @since 2.10.0
		 * @return CEV_Dokan_Integration
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 *
		 * Hooks are registered unconditionally and are inert without Dokan
		 * (the `dokan_new_seller_created` action never fires, and the two
		 * filters return their defaults because no user is a vendor). This
		 * avoids plugin load-order issues from detecting Dokan this early.
		 *
		 * @since 2.10.0
		 */
		public function __construct() {
			add_action( 'dokan_new_seller_created', array( $this, 'on_vendor_registered' ), 20, 2 );
			add_filter( 'cev_account_verify_prompt_enabled', array( $this, 'force_prompt_for_vendor' ), 10, 2 );
			add_filter( 'cev_account_verify_event_context', array( $this, 'tag_vendor_context' ), 10, 2 );
			// Attach the inline signup OTP popup to the Dokan vendor registration
			// form so vendors verify at registration (then Dokan's setup wizard
			// runs as normal). This is the primary flow; the account-verify popup
			// above is only a fallback for vendors created without the inline flow.
			add_filter( 'cev_signup_register_form_selector', array( $this, 'extend_signup_register_form_selector' ) );

			// Print the signup OTP popup markup on Dokan's registration page —
			// CEV's core print runs on the WooCommerce login-form hook, which
			// Dokan's custom registration template does not fire.
			add_action( 'wp_footer', array( $this, 'maybe_render_signup_popup' ) );
		}

		/**
		 * Ensure the signup OTP popup markup exists on the Dokan vendor
		 * registration page. CEV normally prints it via the WooCommerce
		 * login-form hook, which does not fire on Dokan's custom registration
		 * template — so the inline flow would send the OTP but have no popup to
		 * show. The template uses `require_once`, so this safely dedups against
		 * the core print on standard My Account pages.
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function maybe_render_signup_popup() {
			if ( is_user_logged_in() || ! $this->dokan_active() || ! $this->signup_verification_on() ) {
				return;
			}
			$template = cev_pro()->get_plugin_path() . '/includes/signup-verification/views/cev-signup-popup.php';
			if ( file_exists( $template ) ) {
				require_once $template;
			}
		}

		/**
		 * Whether Dokan is active.
		 *
		 * @since 2.10.0
		 * @return bool
		 */
		private function dokan_active() {
			return function_exists( 'dokan' ) || defined( 'DOKAN_PLUGIN_VERSION' );
		}

		/**
		 * Extend CEV's inline signup OTP popup so it attaches to the Dokan vendor
		 * registration form (`#dokan-vendor-register`). Only extends the selector
		 * when Dokan is active and signup verification is enabled.
		 *
		 * @since 2.10.0
		 * @param string $selector Current jQuery selector for the register form.
		 * @return string
		 */
		public function extend_signup_register_form_selector( $selector ) {
			if ( ! $this->dokan_active() || ! $this->signup_verification_on() ) {
				return $selector;
			}
			return $selector . ', #dokan-vendor-register';
		}

		/**
		 * Whether CEV signup verification is enabled — the gate for vendor
		 * verification (parity with regular customer signups).
		 *
		 * @since 2.10.0
		 * @return bool
		 */
		private function signup_verification_on() {
			return 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification', 0 );
		}

		/**
		 * Whether a user is a Dokan vendor (seller). Guarded so it is safe when
		 * Dokan is inactive (returns false).
		 *
		 * @since 2.10.0
		 * @param int $user_id User ID.
		 * @return bool
		 */
		private function is_vendor( $user_id ) {
			$user_id = absint( $user_id );
			if ( $user_id <= 0 ) {
				return false;
			}
			if ( function_exists( 'dokan_is_user_seller' ) ) {
				return (bool) dokan_is_user_seller( $user_id );
			}
			return user_can( $user_id, 'dokandar' );
		}

		/**
		 * Dispatch email verification when a new Dokan vendor registers.
		 *
		 * Reuses the Account-Verification email + PIN; the account-verify popup
		 * (forced on for vendors via force_prompt_for_vendor) reads the same PIN.
		 *
		 * @since 2.10.0
		 * @param int   $user_id        New vendor user ID.
		 * @param array $dokan_settings Vendor profile settings (unused).
		 * @return void
		 */
		public function on_vendor_registered( $user_id, $dokan_settings = array() ) {
			$user_id = absint( $user_id );
			if ( $user_id <= 0 || ! $this->signup_verification_on() ) {
				return;
			}

			// Skip if already verified — e.g. the inline OTP popup verified them
			// at registration, or an existing verified customer became a vendor.
			if ( cev_pro()->function->is_user_email_verified( $user_id ) ) {
				return;
			}

			// Mark unverified (never delete the meta key). NO email is sent here:
			// the account-verify popup shown on the vendor's first dashboard load
			// auto-sends the OTP, so sending one here too would double up. This
			// branch is only reached when the inline registration popup did not
			// verify them (e.g. JS disabled / cached) — the dashboard popup is
			// the fallback.
			update_user_meta( $user_id, 'customer_email_verified', 'false' );
		}

		/**
		 * Force the account-verify popup for an unverified vendor even when the
		 * global login-verify setting is off, so vendor verification works
		 * whenever signup verification is enabled.
		 *
		 * @since 2.10.0
		 * @param bool    $enabled Current prompt-enabled state.
		 * @param WP_User $user    Logged-in user.
		 * @return bool
		 */
		public function force_prompt_for_vendor( $enabled, $user ) {
			if ( $enabled ) {
				return true;
			}
			if ( ! $this->signup_verification_on() ) {
				return $enabled;
			}
			if ( $user instanceof WP_User && $this->is_vendor( $user->ID ) ) {
				return true;
			}
			return $enabled;
		}

		/**
		 * Tag account-verify analytics events with the vendor cohort context.
		 *
		 * @since 2.10.0
		 * @param string $context Default event context.
		 * @param int    $user_id Verifying user ID.
		 * @return string
		 */
		public function tag_vendor_context( $context, $user_id ) {
			if ( $this->is_vendor( $user_id ) ) {
				return 'vendor_signup';
			}
			return $context;
		}
	}
}
