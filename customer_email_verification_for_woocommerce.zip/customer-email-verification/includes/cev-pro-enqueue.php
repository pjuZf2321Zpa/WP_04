<?php
/**
 * Enqueue class for Customer Email Verification PRO
 *
 * Move admin and front enqueue functions here from main plugin file.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CEV_Enqueue_Pro' ) ) {

	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Enqueue_Pro {

		/**
		 * Whether cev_ajax_object has already been localized this request.
		 *
		 * Static, not per-instance: the plugin bootstrap constructs more than
		 * one CEV_Enqueue_Pro, so every enqueue callback runs several times per
		 * request. An instance flag would still emit one copy per instance.
		 *
		 * @since 3.0.3
		 * @var bool
		 */
		private static $localized = false;

		/**
		 * Constructor - register hooks
		 */
		public function __construct() {
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ), 4 );
			add_action( 'admin_enqueue_scripts', array( $this, 'review_notice_styles' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'agent_os_notice_styles' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_scripts' ) );
		}

		/**
		 * Enqueue the self-contained ZUI plugin-notice component stylesheet for
		 * the review call-out.
		 *
		 * The main ZUI bundle is page-guarded to the settings screen, but the
		 * review notice renders on other admin pages via `admin_notices`, so we
		 * load just the standalone `plugin-notice.css` (every rule is written
		 * scoped + unscoped with hard-coded token fallbacks) when — and only
		 * when — the notice is actually going to show.
		 *
		 * @since 3.0.2
		 * @return void
		 */
		public function review_notice_styles() {
			if ( ! class_exists( 'CEV_Pro_Review_Notice' ) ) {
				return;
			}
			if ( ! CEV_Pro_Review_Notice::get_instance()->should_display() ) {
				return;
			}

			$zui_url = cev_pro()->plugin_dir_url() . 'assets/zui/';
			$zui_dir = cev_pro()->get_plugin_path() . '/assets/zui/';
			$zui_ver = is_readable( $zui_dir . 'VERSION' )
				// phpcs:ignore WordPress.WP.AlternativeFunctions -- Local bundled VERSION file read for asset cache-busting; not a remote request.
				? trim( file_get_contents( $zui_dir . 'VERSION' ) )
				: cev_pro()->version;

			wp_enqueue_style( 'cev-zui-plugin-notice', $zui_url . 'css/components/plugin-notice.css', array(), $zui_ver );
		}

		/**
		 * Enqueue the ZUI plugin-notice stylesheet plus the offer/coupon styling
		 * for the AI Agent OS launch notice, only when that notice will show.
		 *
		 * @since 3.0.6
		 * @return void
		 */
		public function agent_os_notice_styles() {
			if ( ! class_exists( 'CEV_Pro_Agent_Os_Notice' ) ) {
				return;
			}
			if ( ! CEV_Pro_Agent_Os_Notice::get_instance()->should_display() ) {
				return;
			}

			$zui_url = cev_pro()->plugin_dir_url() . 'assets/zui/';
			$zui_dir = cev_pro()->get_plugin_path() . '/assets/zui/';
			$zui_ver = is_readable( $zui_dir . 'VERSION' )
				// phpcs:ignore WordPress.WP.AlternativeFunctions -- Local bundled VERSION file read for asset cache-busting; not a remote request.
				? trim( file_get_contents( $zui_dir . 'VERSION' ) )
				: cev_pro()->version;

			// Same handle as the review notice, so the stylesheet loads once.
			wp_enqueue_style( 'cev-zui-plugin-notice', $zui_url . 'css/components/plugin-notice.css', array(), $zui_ver );
			wp_add_inline_style(
				'cev-zui-plugin-notice',
				'.cev-aos-notice .zui-pnotice__text.cev-aos-notice__offer{display:inline-flex;align-items:center;flex-wrap:wrap;gap:6px;margin-block-start:10px;padding:8px 14px;background:#fff7ed;border:1px solid #fdba74;border-radius:8px;color:#7c2d12;font-size:13px}'
				. '.cev-aos-notice .cev-aos-notice__offer strong{color:#c2410c;font-size:14px}'
				. '.cev-aos-notice__coupon{display:inline-block;padding:2px 10px;border:1px dashed #ea580c;border-radius:6px;background:#ffffff;color:#c2410c;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:13px;font-weight:700;letter-spacing:.06em;user-select:all}'
				. '.cev-aos-notice .zui-pnotice__close{text-decoration:none}'
			);
		}

		/**
		 * Single callback for wp_enqueue_scripts that calls all frontend enqueue methods.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function enqueue_frontend_scripts() {
			// Register the shared popup design system first — every popup
			// stylesheet below depends on it.
			$this->register_popup_style();

			// Enqueue signup verification scripts.
			$this->signup_verification_enqueue();

			// Enqueue checkout verification scripts if enabled.
			$this->enqueue_checkout_scripts();

			// Enqueue the Login Authentication OTP popup assets. Deliberately a
			// separate entry point from the checkout enqueue above so the popup
			// never depends on the checkout-verification feature being enabled.
			$this->login_authentication_enqueue();

			// Enqueue edit account verification scripts.
			$this->front_enqueue();

			// Enqueue the verify-on-login popup for unverified customers.
			$this->account_verify_enqueue();

			// Enqueue Smart Form assets where the [cev_smart_form] shortcode is.
			$this->smart_form_enqueue();
		}

		/**
		 * Register the shared popup design system stylesheet.
		 *
		 * The cev-popup.css stylesheet holds the overlay, card, typography, OTP
		 * input, buttons, states, motion and responsive rules used by EVERY
		 * customer-facing verification surface. The per-surface stylesheets
		 * (front.css, signup-style.css) declare it as a dependency, so it
		 * loads exactly once and always before them.
		 *
		 * Registering (not enqueueing) keeps the existing per-surface gating
		 * intact — nothing loads on a page that has no popup.
		 *
		 * @since 3.1.0
		 * @return void
		 */
		public function register_popup_style() {
			if ( wp_style_is( 'cev-popup', 'registered' ) ) {
				return;
			}

			// Cache-bust with the plugin version, matching every other CEV
			// stylesheet in this class. Bumping the plugin version re-fetches
			// cev-popup.css; within a release the browser may cache it.
			wp_register_style(
				'cev-popup',
				cev_pro()->plugin_dir_url() . 'assets/css/cev-popup.css',
				array(),
				cev_pro()->version
			);
		}

		/**
		 * Enqueue the Smart Form CSS/JS — only on pages that contain the
		 * [cev_smart_form] shortcode, and only when Smart Form is the active
		 * signup type. Gating + the JS config live in CEV_Smart_Form.
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function smart_form_enqueue() {
			if ( ! class_exists( 'CEV_Smart_Form' ) ) {
				return;
			}

			$smart_form = CEV_Smart_Form::get_instance();

			if ( ! $smart_form->is_active_on_page() ) {
				return;
			}

			// The Smart Form reuses the shared signup OTP popup (#otp-popup),
			// styled by signup-style.css. The classic signup enqueue is skipped on
			// Smart Form pages (see signup_verification_enqueue), so load it here.
			$this->register_popup_style();
			wp_enqueue_style(
				'cev-signup-style',
				cev_pro()->plugin_dir_url() . 'assets/css/signup-style.css',
				array( 'cev-popup' ),
				cev_pro()->version
			);

			wp_enqueue_style(
				'cev-smart-form',
				cev_pro()->plugin_dir_url() . 'assets/css/smart-form.css',
				array( 'cev-signup-style' ),
				cev_pro()->version
			);

			$cev_cfg    = $smart_form->get_config();
			$smart_deps = array( 'jquery' );

			// International phone input (intl-tel-input) — load only when a phone
			// field can appear on the register form and the feature is enabled.
			// The library files live in assets/intl-tel-input/ (added separately).
			$cev_reg_method   = isset( $cev_cfg['reg_method'] ) ? $cev_cfg['reg_method'] : 'email';
			$cev_phone_shown  = ( 'phone' === $cev_reg_method ) || ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_show_phone_field', 0 ) );
			$cev_intl_enabled = ! empty( $cev_cfg['intl_phone']['enabled'] );
			if ( $cev_phone_shown && $cev_intl_enabled ) {
				wp_enqueue_style(
					'cev-intl-tel-input',
					cev_pro()->plugin_dir_url() . 'assets/intl-tel-input/css/intlTelInput.min.css',
					array(),
					'17.0.19'
				);
				wp_enqueue_script(
					'cev-intl-tel-input',
					cev_pro()->plugin_dir_url() . 'assets/intl-tel-input/js/intlTelInput.min.js',
					array(),
					'17.0.19',
					true
				);
				$smart_deps[] = 'cev-intl-tel-input';
			}

			wp_enqueue_script(
				'cev-smart-form',
				cev_pro()->plugin_dir_url() . 'assets/js/smart-form.js',
				$smart_deps,
				cev_pro()->version,
				true
			);

			// Verify Button (manual-verify) mode for the shared OTP popup — the
			// Smart Form has its own OTP handling in smart-form.js, so it needs
			// the flag (and the incomplete-code message) in its own config bag.
			$cev_cfg['show_verify_button'] = $this->show_verify_button_flag();
			if ( ! isset( $cev_cfg['i18n'] ) || ! is_array( $cev_cfg['i18n'] ) ) {
				$cev_cfg['i18n'] = array();
			}
			$cev_cfg['i18n']['enter_code'] = __( 'Please enter the complete code.', 'customer-email-verification' );

			// Registration password policy - the browser mirror of the server
			// validator ( CEV_Smart_Form_Ajax::is_strong_password ). smart-form.js
			// gates the submit on these and shows the matching message.
			$cev_pw_policy = CEV_Smart_Form::password_policy();

			$cev_cfg['password_min_length']     = $cev_pw_policy['min_length'];
			$cev_cfg['password_require_strong'] = $cev_pw_policy['require_strong'] ? 1 : 0;
			$cev_cfg['i18n']['password_weak']   = CEV_Smart_Form::password_error_message();

			wp_localize_script( 'cev-smart-form', 'cev_smart_form', $cev_cfg );
		}

		/**
		 * Enqueue the account-verification popup assets for a logged-in
		 * unverified customer. All gating lives in should_prompt_account_verify().
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function account_verify_enqueue() {
			if ( ! cev_pro()->function->should_prompt_account_verify() ) {
				return;
			}

			// Reuse the registration popup styling so the account-verify
			// popup matches the signup / login popups.
			$this->register_popup_style();
			wp_enqueue_style(
				'cev-account-verify-style',
				cev_pro()->plugin_dir_url() . 'assets/css/signup-style.css',
				array( 'cev-popup' ),
				cev_pro()->version
			);

			wp_enqueue_script(
				'cev-account-verify',
				cev_pro()->plugin_dir_url() . 'assets/js/account-verify.js',
				array( 'jquery' ),
				cev_pro()->version,
				true
			);

			$user = wp_get_current_user();
			wp_localize_script(
				'cev-account-verify',
				'cev_account_verify',
				array(
					'ajax_url'        => admin_url( 'admin-ajax.php' ),
					'nonce'           => wp_create_nonce( 'cev_account_verify_nonce' ),
					'email'           => ( $user instanceof WP_User ) ? $user->user_email : '',
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
					'resend_delay'    => (int) apply_filters( 'cev_account_verify_resend_delay', 30 ),
					'show_verify_button' => $this->show_verify_button_flag(),
					'count_down_text' => __( 'You can resend the code in', 'customer-email-verification' ),
					'i18n'            => array(
						'sending'       => __( 'Sending…', 'customer-email-verification' ),
						'code_sent'     => __( 'Code sent — check your inbox.', 'customer-email-verification' ),
						'send_failed'   => __( 'Could not send the code. Please try again.', 'customer-email-verification' ),
						'enter_code'    => __( 'Please enter the code.', 'customer-email-verification' ),
						'verifying'     => __( 'Verifying…', 'customer-email-verification' ),
						'verified'      => __( 'Verified! Reloading…', 'customer-email-verification' ),
						'verify_failed' => __( 'Invalid or expired code.', 'customer-email-verification' ),
					),
				)
			);
		}

		/**
		 * Cache-busting version string for a bundled asset.
		 *
		 * The plugin version alone is not enough during a release cycle: admin.js
		 * and admin.css are edited many times while the version string stays put,
		 * so browsers keep serving the copy they cached under the same ?ver= and
		 * new UI behaviour silently never runs. Appending the file's mtime makes
		 * every edit produce a fresh URL, while still collapsing to the plugin
		 * version when the file cannot be stat'ed.
		 *
		 * @since 3.0.3
		 * @param string $relative_path Path relative to the plugin root, e.g. 'assets/js/admin.js'.
		 * @return string Version string suitable for wp_enqueue_script/style().
		 */
		private static function asset_version( $relative_path ) {
			$version = cev_pro()->version;
			$file    = cev_pro()->get_plugin_path() . '/' . ltrim( $relative_path, '/' );

			if ( ! is_readable( $file ) ) {
				return $version;
			}

			$mtime = filemtime( $file );

			return false === $mtime ? $version : $version . '.' . $mtime;
		}

		/**
		 * Enqueue admin styles and scripts for the Email Verification settings page.
		 *
		 * @param string $hook The current admin page hook suffix.
		 */
		public function admin_styles( $hook ) {
			// Ensure the styles and scripts are loaded only on the Email Verification settings page.
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only admin-page guard; no state change.
			$cev_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
			if ( 'customer-email-verification-for-woocommerce' !== $cev_page ) {
				return;
			}

			// ----- Zorem UI shared admin design library -----
			// Used directly from assets/zui/ (single CSS + JS bundle). Loaded
			// first so the plugin's own admin assets can depend on it. The
			// VERSION file is the cache-bust token, so a library refresh busts
			// the browser cache automatically.
			$zui_url = cev_pro()->plugin_dir_url() . 'assets/zui/';
			$zui_dir = cev_pro()->get_plugin_path() . '/assets/zui/';
			$zui_ver = is_readable( $zui_dir . 'VERSION' )
				// phpcs:ignore WordPress.WP.AlternativeFunctions -- Local bundled VERSION file read for asset cache-busting; not a remote request.
				? trim( file_get_contents( $zui_dir . 'VERSION' ) )
				: cev_pro()->version;
			wp_enqueue_style( 'zui', $zui_url . 'css/zui.css', array(), $zui_ver );
			wp_enqueue_script( 'zui', $zui_url . 'js/zui.js', array(), $zui_ver, true );

			// CEV-only overrides on top of the shared library (scoped to .cev-admin).
			wp_enqueue_style( 'cev-admin-overrides', cev_pro()->plugin_dir_url() . 'assets/css/cev-admin.css', array( 'zui' ), self::asset_version( 'assets/css/cev-admin.css' ) );

			// Determine script suffix based on debug mode.
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			
			// Enqueue jQuery (required for many scripts).
			wp_enqueue_script( 'jquery' );
			
			// WC_VERSION is defined by WooCommerce at runtime.
			$wc_version = defined( 'WC_VERSION' ) ? (string) constant( 'WC_VERSION' ) : cev_pro()->version;

			// Enqueue select2 and related scripts for enhanced dropdown functionality.
			wp_enqueue_script( 'wc-select2', WC()->plugin_url() . '/assets/js/select2/select2.full' . $suffix . '.js', array( 'jquery' ), '4.0.3', true );
			wp_enqueue_script( 'selectWoo', WC()->plugin_url() . '/assets/js/selectWoo/selectWoo.full' . $suffix . '.js', array( 'jquery' ), '1.0.4', true );
			wp_enqueue_script( 'wc-enhanced-select', WC()->plugin_url() . '/assets/js/admin/wc-enhanced-select' . $suffix . '.js', array( 'jquery', 'selectWoo' ), $wc_version, true );

			// Enqueue BlockUI script for loading spinners.
			wp_enqueue_script( 'wc-jquery-blockui', WC()->plugin_url() . '/assets/js/jquery-blockui/jquery.blockUI' . $suffix . '.js', array( 'jquery' ), '2.70', true );
		
			// Enqueue WooCommerce admin styles.
			wp_enqueue_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), cev_pro()->version );
			
			// Enqueue DataTables library (vendored locally — external CDN offloading is disallowed by the marketplace audit).
			wp_enqueue_script( 'datatables-js', cev_pro()->plugin_dir_url() . 'assets/js/vendor/jquery.dataTables.min.js', array( 'jquery' ), '1.11.5', true );
			wp_enqueue_style( 'datatables-css', cev_pro()->plugin_dir_url() . 'assets/css/jquery.dataTables.min.css', array(), '1.11.5' );
			
			// Enqueue custom admin scripts and styles for the plugin.
			wp_enqueue_script( 'cev_pro_admin_js', cev_pro()->plugin_dir_url() . 'assets/js/admin.js', array('jquery', 'wp-util', 'datatables-js', 'wc-jquery-tiptip', 'zui'), self::asset_version( 'assets/js/admin.js' ), true );
			wp_enqueue_style( 'cev-pro-admin-css', cev_pro()->plugin_dir_url() . 'assets/css/admin.css', array(), self::asset_version( 'assets/css/admin.css' ) );

			// Analytics dashboard — vendored mini chart library +
			// page-specific JS + page-specific CSS. Loaded on the same
			// CEV admin page that owns the Analytics tab.
			wp_enqueue_script(
				'cev-chart',
				cev_pro()->plugin_dir_url() . 'assets/js/vendor/cev-chart.min.js',
				array(),
				cev_pro()->version,
				true
			);
			wp_enqueue_script(
				'cev-analytics',
				cev_pro()->plugin_dir_url() . 'assets/js/cev-analytics.js',
				array( 'jquery', 'cev-chart' ),
				cev_pro()->version,
				true
			);
			wp_enqueue_style(
				'cev-analytics-css',
				cev_pro()->plugin_dir_url() . 'assets/css/cev-analytics.css',
				array(),
				cev_pro()->version
			);
			wp_localize_script( 'cev-analytics', 'CEV_ANALYTICS', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'cev_analytics_nonce' ),
			) );
			
			// Localize script to pass variables and data to JavaScript.
			wp_localize_script( 'cev_pro_admin_js', 'cev_pro_admin_js', array() );
			wp_localize_script('cev_pro_admin_js', 'iconUrls', array(
				'verified' => cev_pro()->plugin_dir_url() . 'assets/css/images/checked.png',
				'unverified' => cev_pro()->plugin_dir_url() . 'assets/css/images/cross.png',
			));
			if ( class_exists( 'CEV_Pro_Setup_Checklist' ) ) {
				wp_localize_script( 'cev_pro_admin_js', 'cev_setup_checklist', CEV_Pro_Setup_Checklist::get_instance()->get_script_data() );
			}
			wp_localize_script('cev_pro_admin_js', 'cev_vars', array(
				'delete_user_nonce' => wp_create_nonce('delete_user_nonce'),
				'ajax_url' => admin_url('admin-ajax.php'),
				'cev_create_an_account_during_checkout' => get_option( 'woocommerce_enable_signup_and_login_from_checkout', 'no' ) ,
			));

			// Translatable strings consumed from admin.js. Keep keys
			// stable — translators register the source strings via the
			// __() calls below and the JS reads them from this global
			// object at runtime. Add new keys here when adding new
			// snackbar / modal copy on the JS side.
			wp_localize_script( 'cev_pro_admin_js', 'cev_admin_i18n', array(
				// Settings save flow.
				'settings_saved'      => __( 'Your Settings have been successfully saved.', 'customer-email-verification' ),
				'settings_save_failed' => __( 'Failed to save settings.', 'customer-email-verification' ),
				'saving'              => __( 'Saving…', 'customer-email-verification' ),
				'sms_testing'         => __( 'Sending…', 'customer-email-verification' ),
				'sms_test_phone'      => __( 'Please enter a phone number to test.', 'customer-email-verification' ),
				'sms_test_failed'     => __( 'Could not send the test. Please try again.', 'customer-email-verification' ),

				// User-log delete (existing flow).
				'users_deleted'       => __( 'Users deleted successfully.', 'customer-email-verification' ),
				'user_deleted'        => __( 'User deleted successfully.', 'customer-email-verification' ),
				'error_deleting_users' => __( 'Error deleting users.', 'customer-email-verification' ),
				'error_deleting_user' => __( 'Error deleting user.', 'customer-email-verification' ),
				'no_users_selected'   => __( 'No users selected for deletion', 'customer-email-verification' ),

				// Cleanup card.
				'cleanup_complete'    => __( 'Cleanup complete.', 'customer-email-verification' ),
				'cleanup_failed'      => __( 'Cleanup failed.', 'customer-email-verification' ),
				'cleanup_request_failed' => __( 'Cleanup request failed.', 'customer-email-verification' ),
				'user_cleanup_count_failed' => __( 'Could not count eligible accounts.', 'customer-email-verification' ),

				// Re-engagement card + per-row send.
				'reminder_sent'       => __( 'Reminder sent.', 'customer-email-verification' ),
				'reminders_sent'      => __( 'Reminders sent.', 'customer-email-verification' ),
				'could_not_send_reminder' => __( 'Could not send reminder.', 'customer-email-verification' ),
				'could_not_send_reminder_mailer' => __( 'Could not send reminder. Check your mailer configuration.', 'customer-email-verification' ),
				'bulk_send_failed'    => __( 'Bulk send failed.', 'customer-email-verification' ),
				'bulk_send_failed_mailer' => __( 'Bulk send failed. Check your mailer configuration.', 'customer-email-verification' ),
				'run_failed'          => __( 'Run failed.', 'customer-email-verification' ),
				'run_failed_mailer'   => __( 'Run failed. Check your mailer configuration.', 'customer-email-verification' ),
				'test_email_sent'     => __( 'Test email sent.', 'customer-email-verification' ),
				'test_send_failed'    => __( 'Test send failed.', 'customer-email-verification' ),
				'test_send_failed_mailer' => __( 'Test send failed. Check your mailer configuration.', 'customer-email-verification' ),

				// Security / nonce errors.
				'missing_security_token' => __( 'Missing security token. Please reload the page.', 'customer-email-verification' ),

				// Modal — bulk delete users.
				'modal_delete_title'        => __( 'Delete selected users?', 'customer-email-verification' ),
				'modal_delete_body_one'     => __( 'This will permanently delete <strong>1</strong> verification log entry.', 'customer-email-verification' ),
				/* translators: %d: number of selected entries (always > 1 when shown). */
				'modal_delete_body_many'    => __( 'This will permanently delete <strong>%d</strong> verification log entries.', 'customer-email-verification' ),
				'modal_undone_warning'      => __( 'This action cannot be undone.', 'customer-email-verification' ),
				'modal_btn_delete'          => __( 'Delete', 'customer-email-verification' ),
				'modal_btn_cancel'          => __( 'Cancel', 'customer-email-verification' ),

				// Modal — per-row delete.
				'modal_delete_one_title'    => __( 'Delete this entry?', 'customer-email-verification' ),
				/* translators: %s: customer email address. */
				'modal_delete_one_body'     => __( 'Permanently delete the verification log entry for <strong>%s</strong>?', 'customer-email-verification' ),
				'modal_delete_one_body_no_email' => __( 'Permanently delete this verification log entry?', 'customer-email-verification' ),

				// Modal — bulk send reminder.
				'modal_send_reminder_title' => __( 'Send re-engagement reminder?', 'customer-email-verification' ),
				/* translators: 1: number of users, 2: noun (user/users) */
				'modal_send_reminder_body_one'  => __( 'Send the customizer-defined reminder email to <strong>1</strong> user.', 'customer-email-verification' ),
				/* translators: %d: number of selected users (always > 1 when shown). */
				'modal_send_reminder_body_many' => __( 'Send the customizer-defined reminder email to <strong>%d</strong> users.', 'customer-email-verification' ),
				'modal_send_reminder_safeguards' => __( 'Users who already verified, have orders, or were active recently are skipped automatically.', 'customer-email-verification' ),
				'modal_btn_send'            => __( 'Send', 'customer-email-verification' ),

				// Modal — user cleanup run-now confirmation.
				'modal_user_cleanup_title'  => __( 'Run user cleanup now?', 'customer-email-verification' ),
				'modal_user_cleanup_body'   => __( 'This will permanently delete unverified user accounts that pass all the safeguard checks (orders, subscriptions, roles, recent login).', 'customer-email-verification' ),
				'modal_user_cleanup_btn'    => __( 'Delete now', 'customer-email-verification' ),

				// Modal — Tools "Force re-verify all customers".
				'modal_force_reverify_title' => __( 'Force re-verify all customers?', 'customer-email-verification' ),
				'modal_force_reverify_body'  => __( 'They will be required to verify their email on their next login. Nobody is deleted.', 'customer-email-verification' ),
				'modal_force_reverify_btn'   => __( 'Force re-verify', 'customer-email-verification' ),
				'force_reverify_started'     => __( 'Force re-verify started in the background.', 'customer-email-verification' ),
				'force_reverify_failed'      => __( 'Could not start force re-verify.', 'customer-email-verification' ),
				'force_reverify_count_failed' => __( 'Could not load the affected user count.', 'customer-email-verification' ),
				'force_reverify_count_fallback' => __( 'Selected customers will be marked unverified.', 'customer-email-verification' ),

				// Modal — user cleanup activation guard.
				'modal_user_cleanup_activate_title' => __( 'Enable auto-delete of unverified user accounts?', 'customer-email-verification' ),
				'modal_user_cleanup_activate_body'  => __( 'This will permanently delete WP user accounts that never verified their email after the retention window.', 'customer-email-verification' ),
				'modal_user_cleanup_safeguards_intro' => __( 'Safeguards (always applied):', 'customer-email-verification' ),
				'modal_user_cleanup_skip_verified'  => __( 'Verified users are never deleted', 'customer-email-verification' ),
				'modal_user_cleanup_skip_orders'    => __( 'Users with any orders are never deleted', 'customer-email-verification' ),
				'modal_user_cleanup_skip_subs'      => __( 'Users with active subscriptions are never deleted', 'customer-email-verification' ),
				'modal_user_cleanup_skip_role'      => __( 'Users with elevated roles (admin, editor, etc.) are never deleted', 'customer-email-verification' ),
				'modal_user_cleanup_skip_login'     => __( 'Users with login activity in the last 30 days are never deleted', 'customer-email-verification' ),
				'modal_user_cleanup_recommend'      => __( 'Recommended: click <strong>Preview affected users</strong> first to see what would be deleted.', 'customer-email-verification' ),
				'modal_btn_enable'                  => __( 'Enable', 'customer-email-verification' ),

				// User-cleanup preview panel.
				'preview_loading'         => __( 'Loading…', 'customer-email-verification' ),
				'preview_failed'          => __( 'Preview failed.', 'customer-email-verification' ),
				'preview_request_failed'  => __( 'Preview request failed.', 'customer-email-verification' ),
				'preview_no_users'        => __( 'No users currently match your settings.', 'customer-email-verification' ),
				/* translators: %d: retention window in days. */
				'preview_retention_window'  => __( 'Retention window: %d days. All recent / staff / paying customers are safely excluded.', 'customer-email-verification' ),
				/* translators: %d: number of users that would be deleted. */
				'preview_count_one'         => __( '1 user would be deleted on the next run.', 'customer-email-verification' ),
				/* translators: %d: number of users that would be deleted (always > 1 when shown). */
				'preview_count_many'        => __( '%d users would be deleted on the next run.', 'customer-email-verification' ),
				/* translators: %d: retention window in days. */
				'preview_retention_short'   => __( 'Retention window: %d days.', 'customer-email-verification' ),
				'preview_col_email'         => __( 'Email', 'customer-email-verification' ),
				'preview_col_registered'    => __( 'Registered', 'customer-email-verification' ),
				'preview_col_role'          => __( 'Role', 'customer-email-verification' ),
				'preview_hide'              => __( 'Hide preview', 'customer-email-verification' ),

				// Date picker (analytics range picker) — calendar labels.
				'dp_prev_month'  => __( 'Previous month', 'customer-email-verification' ),
				'dp_next_month'  => __( 'Next month', 'customer-email-verification' ),
				'cal_months'     => array(
					__( 'January', 'customer-email-verification' ),
					__( 'February', 'customer-email-verification' ),
					__( 'March', 'customer-email-verification' ),
					__( 'April', 'customer-email-verification' ),
					__( 'May', 'customer-email-verification' ),
					__( 'June', 'customer-email-verification' ),
					__( 'July', 'customer-email-verification' ),
					__( 'August', 'customer-email-verification' ),
					__( 'September', 'customer-email-verification' ),
					__( 'October', 'customer-email-verification' ),
					__( 'November', 'customer-email-verification' ),
					__( 'December', 'customer-email-verification' ),
				),
				'cal_months_short' => array(
					/* translators: short month label, January */
					_x( 'Jan', 'short month', 'customer-email-verification' ),
					/* translators: short month label, February */
					_x( 'Feb', 'short month', 'customer-email-verification' ),
					/* translators: short month label, March */
					_x( 'Mar', 'short month', 'customer-email-verification' ),
					/* translators: short month label, April */
					_x( 'Apr', 'short month', 'customer-email-verification' ),
					/* translators: short month label, May */
					_x( 'May', 'short month', 'customer-email-verification' ),
					/* translators: short month label, June */
					_x( 'Jun', 'short month', 'customer-email-verification' ),
					/* translators: short month label, July */
					_x( 'Jul', 'short month', 'customer-email-verification' ),
					/* translators: short month label, August */
					_x( 'Aug', 'short month', 'customer-email-verification' ),
					/* translators: short month label, September */
					_x( 'Sep', 'short month', 'customer-email-verification' ),
					/* translators: short month label, October */
					_x( 'Oct', 'short month', 'customer-email-verification' ),
					/* translators: short month label, November */
					_x( 'Nov', 'short month', 'customer-email-verification' ),
					/* translators: short month label, December */
					_x( 'Dec', 'short month', 'customer-email-verification' ),
				),
				'cal_dow' => array(
					/* translators: two-letter weekday label, Monday */
					_x( 'Mo', 'two-letter weekday', 'customer-email-verification' ),
					/* translators: two-letter weekday label, Tuesday */
					_x( 'Tu', 'two-letter weekday', 'customer-email-verification' ),
					/* translators: two-letter weekday label, Wednesday */
					_x( 'We', 'two-letter weekday', 'customer-email-verification' ),
					/* translators: two-letter weekday label, Thursday */
					_x( 'Th', 'two-letter weekday', 'customer-email-verification' ),
					/* translators: two-letter weekday label, Friday */
					_x( 'Fr', 'two-letter weekday', 'customer-email-verification' ),
					/* translators: two-letter weekday label, Saturday */
					_x( 'Sa', 'two-letter weekday', 'customer-email-verification' ),
					/* translators: two-letter weekday label, Sunday */
					_x( 'Su', 'two-letter weekday', 'customer-email-verification' ),
				),
			) );

			// Enqueue additional scripts and media uploader.
			wp_enqueue_script( 'media-lib-uploader-js' );
			wp_enqueue_script( 'wc-jquery-tiptip');
			wp_enqueue_media();
			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_script( 'jquery-ui-sortable' );
			wp_enqueue_script( 'media-upload' );
			wp_enqueue_script( 'thickbox' );
			wp_enqueue_style( 'thickbox' );
			wp_enqueue_script(
				'wc-dompurify',
				cev_pro()->plugin_dir_url() . '/assets/js/purify.min.js',
				array(),
				cev_pro()->version,
				true
			);
		}

		/**
		 * Frontend enqueue for edit account page only.
		 * Checkout verification enqueue is handled by CEV_Checkout_Enqueue class.
		 */
		public function front_enqueue() {
			// Register scripts for edit account page
			$this->register_checkout_scripts_and_styles();

			// edit-account check
			global $wp;
			$request = array();
			if ( isset( $wp->request ) ) {
				$request = explode( '/', $wp->request );
			}
			if ( ! empty( $request ) && ( end( $request ) === 'edit-account' ) && is_account_page() ) {
				$cev_temp_email = get_user_meta( get_current_user_id(), 'cev_temp_email', true );
				if ( null != $cev_temp_email ) {
					// front.js on this page reads cev_ajax_object (ajax_url + nonces)
					// and calls blockElement(), which needs jQuery BlockUI. Both used
					// to arrive only as a side effect of the checkout enqueue, so with
					// Checkout Verification switched off this page loaded the script
					// with neither — the same failure the login-auth popup had.
					$this->localize_checkout_scripts();
					wp_enqueue_script( 'underscore' );
					wp_enqueue_script( 'cev-front-js' );
					wp_enqueue_script( 'wc-jquery-blockui' );
					wp_enqueue_style( 'cev_front_style' );
					wp_enqueue_style( 'dashicons' );
				}
			}
		}

		/**
		 * Enqueue scripts and styles for signup verification.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function signup_verification_enqueue() {
			$plugin_instance = cev_pro();
			$plugin_url      = $plugin_instance->plugin_dir_url();

			// Skip on pages where the Smart Form is the active form: it drives the
			// shared OTP popup itself (smart-form.js), and the classic signup
			// script would double-bind the popup's OTP boxes against the wrong
			// verify endpoint.
			if ( class_exists( 'CEV_Smart_Form' ) && CEV_Smart_Form::get_instance()->is_active_on_page() ) {
				return;
			}

			wp_enqueue_script( 'cev-signup-script', $plugin_url . 'assets/js/signup-script.js', array( 'jquery', 'wp-i18n' ), cev_pro()->version, true );
			$this->register_popup_style();
			wp_enqueue_style( 'cev-custom-style', $plugin_url . 'assets/css/signup-style.css', array( 'cev-popup' ), cev_pro()->version );

			// Set resend delay to 30 seconds for signup verification.
			// This is independent of OTP expiration setting.
			$resend_delay = 30;

			// Get success message from settings (translated into the visitor's language via Polylang).
			$success_message = cev_pro()->function->cev_pro_admin_message( 'cev_verification_success_message', __( 'Your email is verified!', 'customer-email-verification' ) );

			// Get resend limit message from settings (translated into the visitor's language via Polylang).
			$resend_limit_message = cev_pro()->function->cev_pro_admin_message( 'cev_resend_limit_message', __( 'Too many attempts, please contact us for further assistance', 'customer-email-verification' ) );

			wp_localize_script(
				'cev-signup-script',
				'cev_ajax',
				array(
					'ajax_url'                        => admin_url( 'admin-ajax.php' ),
					'nonce'                           => wp_create_nonce( 'verify_otp_nonce' ),
					'loaderImage'                     => $plugin_url . 'assets/images/Eclipse.svg',
					'enableEmailVerification'         => (bool) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification' ),
					'password_setup_link_enabled'     => get_option( 'woocommerce_registration_generate_password', 'no' ),
					'cev_password_validation'         => __( 'Password is required.', 'customer-email-verification' ),
					'cev_email_validation'            => __( 'Email is required.', 'customer-email-verification' ),
					'enter_otp_code'                  => __( 'Please enter the OTP code.', 'customer-email-verification' ),
					'generic_error'                   => __( 'An error occurred. Please try again.', 'customer-email-verification' ),
					'otp_failed'                      => __( 'OTP verification failed. Please try again.', 'customer-email-verification' ),
					'otp_verify_error'                => __( 'An error occurred while verifying OTP. Please try again.', 'customer-email-verification' ),
					'resend_failed'                   => __( 'Failed to resend OTP. Please try again.', 'customer-email-verification' ),
					'cev_email_exists_validation'     => __( 'An account with this email address already exists. Please use a different email or log in to your existing account.', 'customer-email-verification' ),
					'cev_valid_email_validation'      => __( 'Enter a valid email address.', 'customer-email-verification' ),
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Public extension-point filter kept un-prefixed for back-compat with existing customizations.
					'cev_Validation_error_position_id' => apply_filters( 'change_validation_error_message_position', '#customer_login' ),
					'count_down_text'                 => __( 'You can resend the code in', 'customer-email-verification' ),
					'resend_delay'                    => $resend_delay,
					'success_message'                 => $success_message,
					'resend_limit_message'            => $resend_limit_message,
					'resend_success_message'          => __( 'Verification email sent successfully', 'customer-email-verification' ),
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
					'register_form_selector'          => apply_filters( 'cev_signup_register_form_selector', '.woocommerce-form-register' ),
					'show_verify_button'              => $this->show_verify_button_flag(),
				)
			);
		}

		/**
		 * Whether the popup Verify button is shown (manual-verify mode).
		 *
		 * Reads the Customizer "Verify Button" setting (Popup Style). 'hide'
		 * (default) keeps the auto-verify-on-last-digit behaviour; 'show'
		 * renders a visible Verify button and the front-end scripts skip the
		 * automatic submission.
		 *
		 * @since 3.1.0
		 * @return string '1' when the button is shown, '0' otherwise.
		 */
		private function show_verify_button_flag() {
			return ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', 'hide' ) ) ? '1' : '0';
		}

		/**
		 * Enqueue checkout verification scripts and styles.
		 *
		 * Registers and enqueues all necessary scripts and styles for checkout
		 * verification functionality, including localization data.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function enqueue_checkout_scripts() {
			// Feature gate: Only enqueue if checkout verification is enabled.
			if ( 1 != cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout', 0 ) ) {
				return;
			}

			// Register scripts and styles.
			$this->register_checkout_scripts_and_styles();

			// Localize scripts with AJAX data.
			$this->localize_checkout_scripts();

			// Enqueue on specific pages.
			$this->enqueue_checkout_on_pages();
		}

		/**
		 * Enqueue the Login Authentication OTP popup assets.
		 *
		 * The login-authentication account endpoint renders its own OTP popup
		 * (CEV_Login_Authentication::cev_login_authentication_endpoint_content),
		 * and that popup is driven entirely by front.js: the "Verify Code" button
		 * is hidden unless the merchant opts in, and the OTP inputs carry no name
		 * attribute, so there is no non-JS submit fallback.
		 *
		 * These assets used to be enqueued from enqueue_checkout_on_pages(), which
		 * sits behind the cev_enable_email_verification_checkout gate. On a store
		 * running Login Authentication with Checkout Verification switched off the
		 * popup therefore rendered with no JavaScript at all — no auto-advance, no
		 * auto-submit, no resend timer and no visible button — so the customer
		 * could type the code but could never submit it. This method gives the
		 * feature its own independent entry point.
		 *
		 * @since 3.0.3
		 * @return void
		 */
		public function login_authentication_enqueue() {
			// Feature gate: mirrors CEV_Login_Authentication::init().
			if ( 1 !== (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_login_authentication', 0 ) ) {
				return;
			}

			// Only load on the endpoint that actually renders the popup.
			if ( ! $this->is_login_authentication_page() ) {
				return;
			}

			$this->register_checkout_scripts_and_styles();
			$this->localize_checkout_scripts();
			$this->enqueue_verification_scripts();
		}

		/**
		 * Whether the current request is the login-authentication endpoint.
		 *
		 * Resolved through WooCommerce's own endpoint lookup rather than by
		 * comparing home_url( $wp->request ) against wc_get_account_endpoint_url().
		 * That string comparison broke on plain permalinks, WPML/Polylang
		 * translated endpoint slugs, www/non-www mismatches and subdirectory
		 * installs — all cases where WooCommerce resolves the endpoint (so the
		 * popup renders) but the two strings differ (so the assets did not load).
		 *
		 * @since 3.0.3
		 * @return bool
		 */
		private function is_login_authentication_page() {
			if ( ! function_exists( 'WC' ) || ! WC()->query ) {
				return false;
			}

			if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'login-authentication' ) ) {
				return true;
			}

			// Fallback: read the resolved endpoint directly. Covers setups where
			// the query var is present before is_wc_endpoint_url() can map it.
			return ( 'login-authentication' === WC()->query->get_current_endpoint() );
		}

		/**
		 * Register all checkout scripts and styles.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		private function register_checkout_scripts_and_styles() {
			// Only register if not already registered.
			if ( wp_script_is( 'cev-front-js', 'registered' ) ) {
				return;
			}

			$suffix  = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			// Register scripts.
			wp_register_script( 'cev-front-js', cev_pro()->plugin_dir_url() . 'assets/js/front.js', array( 'jquery', 'wp-i18n', 'underscore' ), cev_pro()->version, true );
			wp_register_script( 'cev-inline-front-js', cev_pro()->plugin_dir_url() . 'assets/js/inline-verification.js', array( 'jquery', 'wp-i18n', 'underscore' ), cev_pro()->version, true );

			// Register styles and BlockUI script.
			$this->register_popup_style();
			wp_register_style( 'cev_front_style', cev_pro()->plugin_dir_url() . 'assets/css/front.css', array( 'cev-popup' ), cev_pro()->version );
			wp_register_script( 'wc-jquery-blockui', WC()->plugin_url() . '/assets/js/jquery-blockui/jquery.blockUI' . $suffix . '.js', array( 'jquery' ), '2.70', true );
		}

		/**
		 * Localize checkout scripts with AJAX data.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		private function localize_checkout_scripts() {
			// Two independent entry points reach this now (checkout verification
			// and login authentication). wp_localize_script() CONCATENATES repeat
			// calls for the same handle, so guard it — otherwise the page would
			// carry the cev_ajax_object declaration twice.
			if ( self::$localized ) {
				return;
			}
			self::$localized = true;

			$cev_ajax_object = $this->get_checkout_localization_data();

			// Localize for both scripts.
			wp_localize_script( 'cev-front-js', 'cev_ajax_object', $cev_ajax_object );
			wp_localize_script( 'cev-inline-front-js', 'cev_ajax_object', $cev_ajax_object );
		}

		/**
		 * Get localization data for checkout scripts.
		 *
		 * @since 1.0.0
		 * @return array Localization data array.
		 */
		private function get_checkout_localization_data() {
			$guest_checkout_enabled = 'yes' === get_option( 'woocommerce_enable_guest_checkout' );
			$cev_create_account_during_checkout = $guest_checkout_enabled ? cev_pro()->function->cev_pro_admin_settings( 'cev_create_an_account_during_checkout', 0 ) : 0;

			// Get session data. WC()->session can be absent on unusual setups
			// (optimisation plugins that short-circuit it), and this method now
			// also runs on the login-authentication endpoint, so guard the read.
			$cev_user_verified_data_raw = WC()->session ? WC()->session->get( 'cev_user_verified_data', '' ) : '';
			$cev_user_verified_data = json_decode( (string) $cev_user_verified_data_raw, true );
			$cev_user_verified_data = $cev_user_verified_data ? $cev_user_verified_data : array();

			// Get settings.
			$cev_enable_email_verification_checkout = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout', 0 );
			$cev_inline_email_verification_checkout = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_checkout_dropdown_option' );
			$cev_enable_email_verification_free_orders = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_free_orders' );

			// Calculate order subtotal.
			$order_subtotal = 0;
			if ( WC()->cart ) {
				$order_subtotal = (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();
			}

			// Determine if inline verification is needed.
			$need_inline_verification = $this->calculate_need_inline_verification( $order_subtotal, $cev_enable_email_verification_checkout, $cev_inline_email_verification_checkout, $cev_enable_email_verification_free_orders );

			// Analytics: log the category-conditional gate decision once per
			// checkout load (covers classic + Blocks, which share this data).
			if ( function_exists( 'is_checkout' ) && is_checkout() ) {
				cev_pro()->function->cev_pro_log_category_gate_decision( 'checkout' );
			}

			// Get verified email status using the central check_email_verify() helper.
			// For logged-in users this reads user meta (admin unverify takes effect immediately).
			// For guests it falls back to WC session.
			if ( is_user_logged_in() ) {
				$verified_email = wp_get_current_user()->user_email;
				$is_verified    = cev_pro()->function->check_email_verify( $verified_email );
				if ( ! $is_verified ) {
					$verified_email = '';
				}
			} else {
				$verified_email = isset( $cev_user_verified_data['email'] ) ? (string) $cev_user_verified_data['email'] : '';
				$is_verified    = false;
				if ( isset( $cev_user_verified_data['verified'] ) ) {
					$is_verified = filter_var( $cev_user_verified_data['verified'], FILTER_VALIDATE_BOOLEAN );
				}
			}

			$checkout_wc = is_plugin_active( 'checkout-for-woocommerce/checkout-for-woocommerce.php' );

			return array(
				'ajax_url'                                 => admin_url( 'admin-ajax.php' ),
				'checkout_send_verification_email'         => wp_create_nonce( 'checkout-send-verification-email' ),
				'checkout_verify_code'                     => wp_create_nonce( 'checkout-verify-code' ),
				'wc_cev_email_guest_user'                  => wp_create_nonce( 'wc_cev_email_guest_user' ),
				'cev_login_auth_with_otp_nonce'            => wp_create_nonce( 'cev_login_auth_with_otp' ),
				'cev_resend_login_otp_nonce'               => wp_create_nonce( 'cev_resend_login_otp' ),
				'sending'                                  => __( 'Sending…', 'customer-email-verification' ),
				'generic_error'                            => __( 'An error occurred. Please try again.', 'customer-email-verification' ),
				'cev_verification_checkout_dropdown_option' => cev_pro()->function->cev_pro_admin_settings( 'cev_verification_checkout_dropdown_option' ),
				'cev_enable_email_verification_checkout'   => cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout' ),
				'need_inline_verification'                 => $need_inline_verification ? 1 : 0,
				'show_verify_button'                       => $this->show_verify_button_flag(),
				'is_user_logged_in'                        => is_user_logged_in() ? 1 : 0,
				'checkoutWC'                               => $checkout_wc ? true : false,
				'verification_send_msg'                    => __( 'We sent a verification code to your email', 'customer-email-verification' ),
				'email_verification_code_label'            => __( 'Email verification code', 'customer-email-verification' ),
				'verification_code_error_msg'              => __( 'Verification code does not match', 'customer-email-verification' ),
				/* translators: %d = number of digits in the verification code. */
				'otp_digits_label'                         => __( '%d-digit code', 'customer-email-verification' ),
				/* translators: %d = number of digits in the verification code. */
				'otp_incomplete_msg'                       => __( 'Please enter the complete %d-digit code.', 'customer-email-verification' ),
				'verify_button_text'                       => __( 'Verify', 'customer-email-verification' ),
				'resend_verification_msg'                  => __( 'Resend verification code', 'customer-email-verification' ),
				'email_required_msg'                       => __( 'Email is required for verification', 'customer-email-verification' ),
				'invalid_email_msg'                        => __( 'Email is Invalid', 'customer-email-verification' ),
				'email_verified_msg'                       => __( 'Email address verified', 'customer-email-verification' ),
				'email_verified_required_msg'              => __( 'Please verify your email to enable the Place Order button.', 'customer-email-verification' ),
				'all_ready_email_verified_msg'             => __( 'Email address is already verified', 'customer-email-verification' ),
				'cev_create_an_account_during_checkout'    => isset( $cev_create_account_during_checkout ) ? $cev_create_account_during_checkout : '',
				'guest_checkout_enabled'                   => ! empty( $guest_checkout_enabled ) ? 1 : 0,
				'verifiedEmail'                            => $verified_email,
				'isVerified'                               => $is_verified,
				'count_down_text'                          => __( 'You can resend the code in', 'customer-email-verification' ),
				'cancel_verification_text'                 => __( 'Cancel Verification', 'customer-email-verification' ),
				'please_enter_code_msg'                    => __( 'Please enter the verification code', 'customer-email-verification' ),
				'invalid_verification_code_msg'            => __( 'Invalid verification code', 'customer-email-verification' ),
				'network_error_msg'                        => __( 'Network error. Please check your connection and try again.', 'customer-email-verification' ),
				'server_error_msg'                         => __( 'Server error. Please try again later.', 'customer-email-verification' ),
				'invalid_response_msg'                     => __( 'Invalid response from server', 'customer-email-verification' ),
				'verification_error_msg'                   => __( 'An error occurred while verifying. Please try again.', 'customer-email-verification' ),
				'email_verified_success_msg'               => __( 'Email verified successfully', 'customer-email-verification' ),
			);
		}

		/**
		 * Calculate if inline verification is needed.
		 *
		 * @since 1.0.0
		 * @param float $order_subtotal                            Order subtotal.
		 * @param int   $cev_enable_email_verification_checkout    Checkout verification enabled.
		 * @param int   $cev_inline_email_verification_checkout    Inline verification mode.
		 * @param int   $cev_enable_email_verification_free_orders Free orders exempt setting.
		 * @return bool True if inline verification is needed, false otherwise.
		 */
		private function calculate_need_inline_verification( $order_subtotal, $cev_enable_email_verification_checkout, $cev_inline_email_verification_checkout, $cev_enable_email_verification_free_orders ) {
			// Verified logged-in users do not need inline verification.
			if ( is_user_logged_in()
				&& cev_pro()->function->is_user_email_verified( get_current_user_id() )
			) {
				return false;
			}

			// Store staff are not customers — never hold them behind an OTP.
			if ( is_user_logged_in() && cev_pro()->function->is_back_office_user() ) {
				return false;
			}

			// Cart-total threshold: below the threshold → no inline verification
			// (keeps the Blocks checkout + inline front.js in sync with the gate).
			if ( ! cev_pro()->function->cev_pro_should_apply_verification() ) {
				return false;
			}

			// If order has value and free orders are not exempt, verification needed.
			if ( $order_subtotal > 0 && 1 !== (int) $cev_enable_email_verification_free_orders ) {
				return true;
			}

			// If order is free and inline mode is enabled, verification needed.
			if ( 0 === (int) $order_subtotal && 1 === (int) $cev_enable_email_verification_checkout && 2 === (int) $cev_inline_email_verification_checkout ) {
				return true;
			}

			return false;
		}

		/**
		 * Enqueue checkout scripts on specific pages.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		private function enqueue_checkout_on_pages() {
			// The login-authentication endpoint used to be handled here too. It
			// now has its own entry point, login_authentication_enqueue(), so the
			// OTP popup's JS no longer rides on the checkout feature gate.

			// Enqueue on checkout and cart pages.
			if ( is_checkout() || is_cart() ) {
				$this->enqueue_verification_scripts();

				// Enqueue inline verification script if needed.
				$cev_enable_email_verification_checkout = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout', 0 );
				$cev_inline_email_verification_checkout = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_checkout_dropdown_option' );
				$cev_enable_email_verification_free_orders = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_free_orders' );
				$order_subtotal = WC()->cart ? (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax() : 0;

				$need_inline_verification = $this->calculate_need_inline_verification(
					$order_subtotal,
					$cev_enable_email_verification_checkout,
					$cev_inline_email_verification_checkout,
					$cev_enable_email_verification_free_orders
				);

				$user_needs_inline = is_user_logged_in()
					? ( ! cev_pro()->function->is_user_email_verified( get_current_user_id() ) )
					: true;

				if ( 1 === (int) $cev_enable_email_verification_checkout && 2 === (int) $cev_inline_email_verification_checkout && $need_inline_verification && $user_needs_inline ) {
					wp_enqueue_script( 'cev-inline-front-js' );
				}
			}
		}

		/**
		 * Enqueue verification scripts and styles.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		private function enqueue_verification_scripts() {
			wp_enqueue_style( 'cev_front_style' );
			wp_enqueue_script( 'underscore' );
			wp_enqueue_script( 'cev-front-js' );
			wp_enqueue_script( 'wc-jquery-blockui' );
		}
	}
}
