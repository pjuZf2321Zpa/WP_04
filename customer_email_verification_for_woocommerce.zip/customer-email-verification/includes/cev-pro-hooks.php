<?php
/**
 * All hooks for Customer Email Verification PRO
 * (admin menu, endpoints, my account, WPML, REST disable)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CEV_Pro_Hooks' ) ) {

	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Pro_Hooks {

		protected $plugin;
		private static $hooks_registered = false;

		/**
		 * Initialize hooks class
		 * 
		 * @param object $plugin_instance Optional. Main plugin instance. If not provided, gets it via cev_pro()
		 */
		public function __construct( $plugin_instance = null ) {
			// Prevent multiple registrations
			if ( self::$hooks_registered ) {
				return;
			}
			
			// Get main plugin instance - ensure we have a valid instance
			if ( null === $plugin_instance ) {
				if ( function_exists( 'cev_pro' ) ) {
					$plugin_instance = cev_pro();
				} else {
					return; // Can't proceed without plugin instance
				}
			}
			$this->plugin = $plugin_instance;
			
			// Mark as registered
			self::$hooks_registered = true;

			// Admin menu
			add_action( 'admin_menu', array( $this->plugin->admin, 'add_email_verification_submenu' ), 99 );

			// My account menu
			add_filter( 'woocommerce_account_menu_items', array( $this, 'cev_account_menu_items' ), 10 );
			add_filter( 'woocommerce_account_menu_items', array( $this, 'hide_cev_menu_my_account' ), 999 );

			// Endpoints (login-authentication)
			add_action( 'init', array( $this, 'cev_add_my_account_endpoint' ) );

			// Only register if login authentication object exists
			if ( isset( $this->plugin->cev_pro_login_authentication ) && is_object( $this->plugin->cev_pro_login_authentication ) ) {
				add_action( 'woocommerce_account_login-authentication_endpoint', array( $this->plugin->cev_pro_login_authentication, 'cev_login_authentication_endpoint_content' ) );
			}

			// WPML endpoint support
			add_filter( 'wcml_register_endpoints_query_vars', array( $this, 'register_endpoint_WPML' ), 10, 3 );
			add_filter( 'wcml_endpoint_permalink_filter', array( $this, 'endpoint_permalink_filter' ), 10, 2 );
			add_filter( 'woocommerce_get_query_vars', array( $this, 'add_query_vars' ) );

			// Polylang support (auto-detected) — register all admin-configurable
			// strings in Languages → String Translations. WPML path is untouched.
			if ( cev_pro()->function->cev_pro_is_polylang_active() ) {
				add_action( 'admin_init', array( cev_pro()->function, 'cev_pro_register_polylang_strings' ) );
			}

			// Security: Disable Store API
			add_filter( 'rest_pre_dispatch', array( $this, 'disable_wc_endpoint' ), 10, 3 );

			// Resend verification email
			add_action( 'wp', array( $this, 'cev_resend_verification_email' ) );

			// Auto-verify user meta after successful signup verification.
			add_action( 'user_register', array( $this, 'auto_verify_user_on_registration' ), 10, 1 );

			// Paid-Order Gatekeeping.
			// Flip the `pending_paid_order` state to fully verified once the
			// user's first real order lands. Hooked on processing + completed
			// (covers COD / BACS / cheque / manually-created orders, which never
			// fire woocommerce_payment_complete) AND payment_complete (covers
			// auto-capture gateways). All idempotent (see
			// complete_paid_order_gatekeeping). The WooCommerce "New Account"
			// welcome email is NOT held — it is sent normally at registration.
			add_action( 'woocommerce_order_status_processing', array( $this, 'cev_complete_gatekeeping_on_paid_order' ), 10, 1 );
			add_action( 'woocommerce_order_status_completed', array( $this, 'cev_complete_gatekeeping_on_paid_order' ), 10, 1 );
			add_action( 'woocommerce_payment_complete', array( $this, 'cev_complete_gatekeeping_on_paid_order' ), 10, 1 );

			// Verify-on-login prompt for unverified logged-in customers.
			// (Gated by the cev_require_verify_unverified_login setting.)
			add_action( 'wp_footer', array( $this, 'maybe_render_account_verify_popup' ) );
			add_action( 'wp_ajax_cev_account_send_code', array( $this, 'ajax_account_send_code' ) );
			add_action( 'wp_ajax_cev_account_verify_code', array( $this, 'ajax_account_verify_code' ) );

			// Auto-send the OTP so the customer never clicks a button:
			//  - on login (immediate), and
			//  - on the front-end when the popup is due but no valid code exists.
			// Both go through the throttled maybe_send_account_verify_code().
			add_action( 'wp_login', array( $this, 'maybe_send_account_verify_on_login' ), 20, 2 );
			add_action( 'wp', array( $this, 'maybe_autosend_account_verify_code' ) );

			// Tracking data
			add_filter( 'zorem_tracking_data', array( $this, 'get_settings_data' ) );

			// Verification popup message
			add_filter( 'cev_verification_popup_message', array( $this, 'cev_verification_popup_message_callback' ), 10, 2 );

			// Email content decoding filter (moved from Email Common class)
			add_filter( 'wc_cev_decode_html_content', array( cev_pro()->function, 'wc_cev_decode_html_content' ), 1 );
		}

		/**
		 * Auto-verify user on registration when signup OTP was previously verified.
		 *
		 * When a customer verifies their email via the registration OTP popup before
		 * creating an account, we store a transient keyed by their email address.
		 * This callback runs after the WordPress user is created and, if that flag
		 * exists, marks the user as verified in user meta.
		 *
		 * @since 2.8.13
		 * @param int $user_id Newly created user ID.
		 * @return void
		 */
		public function auto_verify_user_on_registration( $user_id ) {
			$user = get_user_by( 'id', $user_id );

			if ( ! $user || ! isset( $user->user_email ) || ! is_email( $user->user_email ) ) {
				return;
			}

			$email = $user->user_email;

			// Paid-Order Gatekeeping: when enabled, a freshly-verified user is
			// held in the `pending_paid_order` state (email proven, perks held)
			// instead of being fully verified, until their first paid order
			// completes. Off → behaviour is the original two-state ('true').
			$gatekeeping    = cev_pro()->function->cev_pro_paid_order_gatekeeping_enabled();
			$verified_state = $gatekeeping ? 'pending_paid_order' : 'true';

			// Case 1: User verified via signup OTP before registration (transient set).
			$verified_transient_key = 'cev_signup_email_verified_' . md5( strtolower( $email ) );
			if ( get_transient( $verified_transient_key ) ) {
				update_user_meta( $user_id, 'customer_email_verified', $verified_state );
				delete_transient( $verified_transient_key );
				if ( $gatekeeping && method_exists( cev_pro()->function, 'log_event' ) ) {
					cev_pro()->function->log_event( $email, 'verification_pending_paid_order', 'signup', array(), $user_id );
				}
				return;
			}

			// Case 2: Guest verified email via checkout OTP in current WC session.
			// Covers first-time guests who verified at checkout then ticked "Create Account".
			if ( function_exists( 'WC' ) && WC()->session ) {
				$raw = WC()->session->get( 'cev_user_verified_data' );
				if ( ! empty( $raw ) ) {
					$session_data = json_decode( $raw );
					if ( is_object( $session_data )
						&& isset( $session_data->email, $session_data->verified )
						&& true === $session_data->verified
						&& strtolower( $session_data->email ) === strtolower( $email )
					) {
						update_user_meta( $user_id, 'customer_email_verified', $verified_state );
						WC()->session->__unset( 'cev_user_verified_data' );
						if ( $gatekeeping && method_exists( cev_pro()->function, 'log_event' ) ) {
							cev_pro()->function->log_event( $email, 'verification_pending_paid_order', 'checkout', array(), $user_id );
						}
						return;
					}
				}
			}

			// Case 3: Returning customer with prior valid orders on this email.
			// Email ownership is implicitly proven by successful past orders,
			// which is why checkout verification was bypassed for them. Without this,
			// an account created during checkout would remain flagged as unverified
			// and trigger a re-verification popup on the next page load.
			$orders = wc_get_orders(
				array(
					'billing_email' => $email,
					'limit'         => 1,
					'status'        => array( 'wc-processing', 'wc-completed', 'wc-on-hold' ),
					'return'        => 'ids',
				)
			);

			if ( ! empty( $orders ) ) {
				update_user_meta( $user_id, 'customer_email_verified', 'true' );
			}
		}

		/**
		 * Flip a `pending_paid_order` user to fully verified on their first
		 * genuinely paid order.
		 *
		 * Bound to `woocommerce_order_status_processing`,
		 * `woocommerce_order_status_completed` and `woocommerce_payment_complete`
		 * so the gate clears as soon as a real order lands — `processing` /
		 * `completed` cover COD / BACS / cheque / manually-created orders (which
		 * never fire `woocommerce_payment_complete`), while `payment_complete`
		 * covers auto-capture gateways. The underlying flip
		 * (complete_paid_order_gatekeeping) is idempotent, so firing on multiple
		 * hooks (and on later orders) is harmless.
		 *
		 * Free / zero-total orders do NOT satisfy the gate — that would let a
		 * spammer unlock perks with a $0 order, defeating the feature.
		 *
		 * @since 2.10.0
		 * @param int $order_id The order being completed / paid.
		 * @return void
		 */
		public function cev_complete_gatekeeping_on_paid_order( $order_id ) {
			if ( ! cev_pro()->function->cev_pro_paid_order_gatekeeping_enabled() ) {
				return;
			}

			if ( ! function_exists( 'wc_get_order' ) ) {
				return;
			}

			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				return;
			}

			// Only a genuinely paid order clears the gate.
			if ( (float) $order->get_total() <= 0 ) {
				return;
			}

			$user_id = (int) $order->get_customer_id();

			// Fallback: match the order's billing email to a registered user.
			// Covers accounts created during checkout where the order was not
			// linked to the customer ID at the time this hook fires.
			if ( $user_id <= 0 ) {
				$billing_email = $order->get_billing_email();
				if ( $billing_email && is_email( $billing_email ) ) {
					$matched = get_user_by( 'email', $billing_email );
					if ( $matched ) {
						$user_id = (int) $matched->ID;
					}
				}
			}

			if ( $user_id <= 0 ) {
				return;
			}

			cev_pro()->function->complete_paid_order_gatekeeping( $user_id, 'paid_order' );
		}

		/**
		 * Footer render: show the account-verification popup for a logged-in
		 * unverified customer. All gating lives in should_prompt_account_verify().
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function maybe_render_account_verify_popup() {
			if ( ! cev_pro()->function->should_prompt_account_verify() ) {
				return;
			}

			$current_user = wp_get_current_user();
			$cev_av_email = ( $current_user instanceof WP_User ) ? $current_user->user_email : '';
			$template     = cev_pro()->get_plugin_path() . '/includes/login-authentication/views/account-verify-popup.php';
			if ( file_exists( $template ) ) {
				include $template;
			}
		}

		/**
		 * Auto-send the verification OTP when an unverified customer logs in,
		 * so the code is waiting in their inbox before the popup appears.
		 *
		 * @since 2.10.0
		 * @param string       $user_login The user login name.
		 * @param WP_User|null $user       The logged-in user object.
		 * @return void
		 */
		public function maybe_send_account_verify_on_login( $user_login, $user = null ) {
			if ( ! $user instanceof WP_User ) {
				$user = get_user_by( 'login', $user_login );
			}
			if ( ! $user ) {
				return;
			}

			// Gating mirrors should_prompt_account_verify(): the dedicated switch,
			// or "Require OTP on every login", which subsumes it.
			if ( ! cev_pro()->function->should_verify_unverified_on_login() ) {
				return;
			}

			$elevated = array( 'administrator', 'editor', 'shop_manager' );
			if ( array_intersect( $elevated, (array) $user->roles ) ) {
				return;
			}

			// Only unverified users (verified / pending-paid-order are skipped).
			if ( cev_pro()->function->is_user_email_verified( $user->ID ) ) {
				return;
			}

			// Login authentication (priority 10 on this same hook) may have just
			// issued its own code for this address. Skip rather than send a
			// second one — the login OTP now records the verification itself.
			if ( cev_pro()->function->has_pending_login_otp( $user->ID ) ) {
				return;
			}

			cev_pro()->function->maybe_send_account_verify_code( $user->ID );
		}

		/**
		 * Auto-send the verification OTP on a front-end load when the popup is
		 * due but no valid code exists yet (covers already-logged-in customers
		 * whose login didn't fire this request). Throttled in the helper.
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function maybe_autosend_account_verify_code() {
			if ( ! cev_pro()->function->should_prompt_account_verify() ) {
				return;
			}
			cev_pro()->function->maybe_send_account_verify_code( get_current_user_id() );
		}

		/**
		 * AJAX: email a fresh verification code to the logged-in user.
		 *
		 * Self-contained numeric OTP (independent of the global link/OTP
		 * verification type) so the account popup always works with a code.
		 * Stores the PIN in the same `cev_email_verification_pin` user meta
		 * the rest of the plugin uses.
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function ajax_account_send_code() {
			if ( ! is_user_logged_in() ) {
				CEV_Ajax_Response::send_error( 'not_logged_in', __( 'Please log in first.', 'customer-email-verification' ) );
				return;
			}
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'cev_account_verify_nonce' ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			$user = wp_get_current_user();
			if ( ! $user || ! is_email( $user->user_email ) ) {
				CEV_Ajax_Response::send_error( 'invalid_user', __( 'Could not resolve your account email.', 'customer-email-verification' ) );
				return;
			}

			// This endpoint powers the explicit "Resend code" action, so honour
			// the admin resend limit (same setting as registration).
			if ( cev_pro()->function->is_resend_limit_reached( $user->ID ) ) {
				CEV_Ajax_Response::send_error( 'limit_reached', __( 'You have reached the resend limit. Please try again later.', 'customer-email-verification' ) );
				return;
			}

			// Reuse the styled, customizer-driven verification email (the same
			// template the registration flow sends) instead of a plain email.
			// code_mail_sender() generates the PIN, stores it in the
			// cev_email_verification_pin user meta our verify step reads, and
			// emails it via the customizable template.
			cev_pro()->function->wuev_user_id          = $user->ID;
			cev_pro()->function->registered_user_email = $user->user_email;
			$sent = cev_pro()->function->code_mail_sender( $user->user_email, 'email_account_verify' );

			if ( ! $sent ) {
				CEV_Ajax_Response::send_error( 'send_failed', __( 'We could not send the code. Please try again.', 'customer-email-verification' ) );
				return;
			}

			// Count this resend against the admin resend limit.
			cev_pro()->function->increment_resend_counter( $user->ID );

			CEV_Ajax_Response::send_success(
				array( 'emailAddress' => $user->user_email ),
				__( 'A verification code has been sent to your email.', 'customer-email-verification' ),
				'email_sent'
			);
		}

		/**
		 * AJAX: verify the code entered in the account-verification popup.
		 *
		 * On success marks the user fully verified, clears the stored PIN and
		 * the force-reverify marker, and logs an analytics event.
		 *
		 * @since 2.10.0
		 * @return void
		 */
		public function ajax_account_verify_code() {
			if ( ! is_user_logged_in() ) {
				CEV_Ajax_Response::send_error( 'not_logged_in', __( 'Please log in first.', 'customer-email-verification' ) );
				return;
			}
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'cev_account_verify_nonce' ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			$code = isset( $_POST['code'] ) ? preg_replace( '/[^0-9]/', '', sanitize_text_field( wp_unslash( $_POST['code'] ) ) ) : '';
			if ( '' === $code ) {
				CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
				return;
			}

			$user    = wp_get_current_user();
			$user_id = (int) $user->ID;
			$stored  = get_user_meta( $user_id, 'cev_email_verification_pin', true );

			if ( ! is_array( $stored ) || empty( $stored['pin'] ) ) {
				CEV_Ajax_Response::send_invalid_code_error( 'session_expired' );
				return;
			}

			if ( ! empty( $stored['enddate'] ) && time() > (int) $stored['enddate'] ) {
				CEV_Ajax_Response::send_invalid_code_error( 'expired' );
				return;
			}

			if ( (string) $code !== (string) $stored['pin'] ) {
				CEV_Ajax_Response::send_invalid_code_error( 'invalid' );
				return;
			}

			// Success — verify (honouring Paid-Order Gatekeeping: a user with
			// no paid order lands in 'pending_paid_order', not 'true'), then
			// clear the PIN + the force-reverify marker.
			$new_state = cev_pro()->function->resolve_post_verification_state( $user_id );
			update_user_meta( $user_id, 'customer_email_verified', $new_state );
			delete_user_meta( $user_id, 'cev_email_verification_pin' );
			delete_user_meta( $user_id, 'cev_force_reverified_at' );
			delete_user_meta( $user_id, 'cev_user_resend_times' );

			if ( method_exists( cev_pro()->function, 'log_event' ) ) {
				// Integrations (e.g. Dokan) can tag the cohort, e.g. 'vendor_signup'.
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
				$cev_verify_context = apply_filters( 'cev_account_verify_event_context', 'account', $user_id );
				cev_pro()->function->log_event( $user->user_email, 'otp_verified', $cev_verify_context, array(), $user_id );
				if ( 'pending_paid_order' === $new_state ) {
					cev_pro()->function->log_event( $user->user_email, 'verification_pending_paid_order', $cev_verify_context, array(), $user_id );
				}
			}

			CEV_Ajax_Response::send_success(
				array( 'verified' => true ),
				__( 'Your email has been verified.', 'customer-email-verification' ),
				'verified'
			);
		}

		/**
		 * Add custom menu items to WooCommerce My Account page
		 * 
		 * Adds "Login Authentication" menu item to the My Account navigation menu.
		 *
		 * @since 1.0.0
		 *
		 * @param array $items Existing My Account menu items
		 * @return array Modified menu items with new endpoints added
		 */
		public function cev_account_menu_items( $items ) {
			// Add login authentication menu item
			$items['login-authentication'] = __( 'Login Authentication', 'customer-email-verification' );
			
			return $items;
		}

		/**
		 * Hide custom menu items from My Account navigation
		 * 
		 * These endpoints are registered but hidden from the menu. They're accessed
		 * programmatically when needed.
		 *
		 * @since 1.0.0
		 *
		 * @param array $items My Account menu items
		 * @return array Menu items with verification endpoints removed
		 */
		public function hide_cev_menu_my_account( $items ) {
			// Remove login authentication from visible menu
			unset($items['login-authentication']);
			
			return $items;
		}

		/**
		 * Register custom rewrite endpoints for My Account page
		 * 
		 * Creates URL endpoints that can be accessed via:
		 * - /my-account/login-authentication/
		 * 
		 * Also handles permalink structure updates for older plugin versions.
		 *
		 * @since 1.0.0
		 */
		public function cev_add_my_account_endpoint() {
			// Register login authentication endpoint
			add_rewrite_endpoint( 'login-authentication', EP_PAGES );
			
			// Update permalink structure for older plugin versions (legacy compatibility)
			if (version_compare(get_option( 'cev_version' ), '1.7', '<') ) {
				global $wp_rewrite;
				$wp_rewrite->set_permalink_structure('/%postname%/');
				$wp_rewrite->flush_rules();
				update_option( 'cev_version', '1.7');
			}
		}

		/**
		 * Register endpoints with WPML for multilingual support
		 * 
		 * Ensures that custom endpoints are properly translated and registered
		 * when using WPML (WordPress Multilingual Plugin).
		 *
		 * @since 1.0.0
		 *
		 * @param array  $query_vars Existing query variables
		 * @param array  $wc_vars    WooCommerce query variables
		 * @param object $obj        WPML endpoint translation object
		 * @return array Modified query variables with translated endpoints
		 */
		public function register_endpoint_WPML( $query_vars, $wc_vars, $obj ) {
			// Register translated login authentication endpoint
			$query_vars['login-authentication'] = $obj->get_endpoint_translation('login-authentication', isset( $wc_vars['login-authentication']) ? $wc_vars['login-authentication'] : 'login-authentication' );
			
			return $query_vars;
		}

		/**
		 * Filter endpoint permalinks for WPML compatibility
		 * 
		 * Ensures endpoint permalinks remain consistent across different languages
		 * when using WPML.
		 *
		 * @since 1.0.0
		 *
		 * @param string $endpoint The endpoint slug
		 * @param string $key      The endpoint key
		 * @return string The filtered endpoint slug
		 */
		public function endpoint_permalink_filter( $endpoint, $key ) {
			// Return standard endpoint for login authentication
			if ( 'login-authentication' == $key ) {
				return 'login-authentication';
			}
			
			return $endpoint;
		}

		/**
		 * Add custom query variables for endpoints
		 * 
		 * Registers custom query variables so WordPress recognizes the endpoints
		 * in URL parsing.
		 *
		 * @since 1.0.0
		 *
		 * @param array $query_vars Existing WooCommerce query variables
		 * @return array Modified query variables with custom endpoints
		 */
		public function add_query_vars( $query_vars ) {
			// Add login authentication query var
			$query_vars['login-authentication'] = 'login-authentication';
			
			return $query_vars;
		}

		/**
		 * Disable WC Store API checkout endpoint to stop carding attacks.
		 *
		 * Hooked to rest_pre_dispatch so it returns a proper JSON 403 error
		 * to REST clients (WC Blocks uses fetch, not browser navigation).
		 * Covers both the legacy route (/wc/store/checkout) and the current
		 * versioned route (/wc/store/v1/checkout).
		 *
		 * @since 1.0.0
		 * @param mixed           $result  Current dispatch result (null = not handled yet).
		 * @param WP_REST_Server  $server  REST server instance.
		 * @param WP_REST_Request $request Current REST request.
		 * @return mixed WP_Error if blocked, original $result otherwise.
		 */
		public function disable_wc_endpoint( $result, $server, $request ) {
			if ( 1 !== (int) cev_pro()->function->cev_pro_admin_settings( 'cev_disable_wooCommerce_store_api', 0 ) ) {
				return $result;
			}

			$route = $request->get_route();

			// Block both the legacy (/wc/store/checkout) and versioned (/wc/store/v1/checkout) routes.
			if ( false !== strpos( $route, '/wc/store/v1/checkout' ) || false !== strpos( $route, '/wc/store/checkout' ) ) {
				return new WP_Error(
					'cev_store_api_disabled',
					__( 'Checkout via the Store API is disabled.', 'customer-email-verification' ),
					array( 'status' => 403 )
				);
			}

			return $result;
		}

		/**
		 * Resend verification email handler
		 * 
		 * This function sends a new verification email to user if the user clicks on 'resend verification email' link.
		 * If the email is already verified then it shows a notice.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function cev_resend_verification_email() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only redirect param; base64-decoded downstream.
			$cev_redirect_limit_resend = isset( $_GET['cev_redirect_limit_resend'] ) ? sanitize_text_field( wp_unslash( $_GET['cev_redirect_limit_resend'] ) ) : '';
			if ( '' !== $cev_redirect_limit_resend ) {
				$user_id = base64_decode( $cev_redirect_limit_resend ); // WPCS: input var ok, CSRF ok.

				$cev_session = WC()->session;
				if ( method_exists( $cev_session, 'has_session' )
					&& method_exists( $cev_session, 'set_customer_session_cookie' )
					&& false === $cev_session->has_session()
				) {
					$cev_session->set_customer_session_cookie( true );
				}

				$verified = get_user_meta( $user_id, 'customer_email_verified', true );

				// A pending-paid-order user has already proven their email, so
				// treat them as verified here (no point re-sending the OTP).
				if ( 'true' === $verified || 'pending_paid_order' === $verified ) {
					$verified_message = cev_pro()->function->cev_pro_admin_settings('cev_verified_user_message', 'Your email is already verified');
					wc_add_notice( $verified_message, 'notice' );
				} else {
					// Get my account page ID
					$my_account = get_option( 'woocommerce_myaccount_page_id' );
					if ( '' === $my_account ) {
						$my_account = get_option( 'page_on_front' );
					}

					cev_pro()->function->wuev_user_id                  = $user_id;
					cev_pro()->function->wuev_myaccount_page_id        = $my_account;
					
					$current_user = get_user_by( 'id', $user_id );
					
					$resend_limit_reached = cev_pro()->function->is_resend_limit_reached( $user_id );
					
					if ( $resend_limit_reached ) {
						return;
					}
					cev_pro()->function->increment_resend_counter( $user_id );
					
					cev_pro()->function->code_mail_sender( $current_user->user_email );
					$message = cev_pro()->function->cev_pro_admin_settings('cev_resend_verification_email_message', 'A new verification link is sent. Check email.');
					$message = cev_pro()->function->maybe_parse_merge_tags( $message, cev_pro()->function );
					wc_add_notice( $message, 'notice' );
				}
			}
		}

		/**
		 * Get settings data for tracking
		 *
		 * @since 1.0.0
		 * @param array $data Existing tracking data.
		 * @return array Modified tracking data with plugin settings.
		 */
		public function get_settings_data( $data ) {
			$data['settings'] = array(
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Array key in the tracking-data payload, not a DB meta query.
				'meta_key' => 'cev_pro_settings',
				'settings_data' => array(
					'cev_enable_email_verification' => array(
						'label' => 'Enable Signup Verification',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification', 1 )
					),
					'cev_enable_email_verification_checkout' => array(
						'label' => 'Enable Checkout Verification',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout', 0 )
					),
					'cev_enable_email_verification_free_orders' => array(
						'label' => 'Require checkout verification only for free orders',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_free_orders', 0 )
					),
					'cev_verification_type' => array(
						'label' => 'Verification type',
						'value' => cev_pro()->function->cev_pro_admin_settings('cev_verification_type', 'otp')
					),
					'cev_verification_code_length' => array(
						'label' => 'OTP length',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', '1' )
					),
					'cev_verification_code_expiration' => array(
						'label' => 'OTP expiration',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_expiration', 'never' )
					),
					'cev_redirect_limit_resend' => array(
						'label' => 'Verification email resend limit',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_redirect_limit_resend', '1' )
					),
					'cev_resend_limit_message' => array(
						'label' => 'Resend limit message',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_resend_limit_message', 'Too many attempts, please contact us for further assistance' )
					),
					'cev_verification_success_message' => array(
						'label' => 'Email verification success message',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_verification_success_message', 'Your email is verified!' )
					),
					'cev_skip_verification_for_selected_roles' => array(
						'label' => 'Skip email verification for the selected user roles',
						'value' => cev_pro()->function->cev_pro_admin_settings('cev_skip_verification_for_selected_roles', [])
					),
					'cev_enable_login_authentication' => array(
						'label' => 'Enable Login Authentication',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_enable_login_authentication', 1 )
					),
					'cev_require_otp_every_login' => array(
						'label' => 'Require OTP on every login',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 )
					),
					'enable_email_otp_for_account' => array(
						'label' => 'Require OTP verification for unrecognized login',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'enable_email_otp_for_account', 1 )
					),
					'enable_email_auth_for_new_device' => array(
						'label' => 'Login from a new device',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_new_device', 1 )
					),
					'enable_email_auth_for_new_location' => array(
						'label' => 'Login from a new location',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_new_location', 1 )
					),
					'enable_email_auth_for_login_time' => array(
						'label' => 'Last login more then',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_login_time', 1 )
					),
					'cev_last_login_more_then_time' => array(
						'label' => 'Last Login more then Time',
						'value' => cev_pro()->function->cev_pro_admin_settings( 'cev_last_login_more_then_time', '15' )
					),
				),
			);

			return $data;
		}

		/**
		 * Return Email verification widget message
		 *
		 * Filters the verification popup message to allow customization via customizer settings.
		 * Replaces placeholders and parses merge tags.
		 *
		 * @since 1.0.0
		 * @param string $message Default verification message.
		 * @param string $email   Customer email address.
		 * @return string Filtered verification message.
		 */
		public function cev_verification_popup_message_callback( $message, $email ) {
			$message_text = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_message', $message );
			$message_text = str_replace( '{customer_email}', $email, $message_text );
			$message_text = cev_pro()->function->maybe_parse_merge_tags( $message_text, cev_pro()->function );
			if ( '' != $message_text ) {
				return $message_text;
			}
			return $message;
		}

	}
}
