<?php
/**
 * Signup Verification Class for Customer Email Verification
 *
 * Main class that orchestrates the signup verification process including
 * OTP generation, email sending, verification checks, CAPTCHA validation,
 * and AJAX handlers.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Signup_Verification Class
 *
 * Manages signup verification process including email validation,
 * OTP generation and verification, CAPTCHA support, and AJAX handlers.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Signup_Verification {

	/**
	 * Instance of this class.
	 *
	 * @var CEV_Signup_Verification|null Class Instance
	 */
	private static $instance = null;

	/**
	 * CAPTCHA validator instance.
	 *
	 * @var CEV_Signup_Captcha
	 */
	private $captcha_validator;

	/**
	 * Email sender instance.
	 *
	 * @var CEV_Signup_Email
	 */
	private $email_sender;

	/**
	 * AJAX handler instance.
	 *
	 * @var CEV_Signup_Ajax
	 */
	private $ajax_handler;

	/**
	 * Initialize the main plugin function.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->init_components();
		add_action( 'init', array( $this, 'init' ) );
	}

	/**
	 * Load required class files.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function load_dependencies() {
		$plugin_path = cev_pro()->get_plugin_path();
		require_once $plugin_path . '/includes/class-cev-ajax-response.php';
		require_once $plugin_path . '/includes/signup-verification/cev-pro-signup-captcha.php';
		require_once $plugin_path . '/includes/signup-verification/cev-pro-signup-email.php';
		require_once $plugin_path . '/includes/signup-verification/cev-pro-signup-ajax.php';
	}

	/**
	 * Initialize component instances.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function init_components() {
		$this->captcha_validator = new CEV_Signup_Captcha();
		$this->email_sender      = new CEV_Signup_Email();
		$this->ajax_handler      = new CEV_Signup_Ajax( $this->captcha_validator, $this->email_sender );
	}

	/**
	 * Get the class instance.
	 *
	 * @since 1.0.0
	 * @return CEV_Signup_Verification Class instance.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Initialize hooks and actions.
	 *
	 * Registers WordPress hooks for template display and AJAX handlers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function init() {
		// Display OTP popup on My Account login form.
		add_action( 'woocommerce_before_customer_login_form', array( $this, 'add_otp_popup_to_my_account' ) );

		// Register AJAX handlers for email checking, OTP verification, and resending.
		add_action( 'wp_ajax_nopriv_check_email_exists', array( $this->ajax_handler, 'check_email_exists' ) );
		add_action( 'wp_ajax_verify_otp', array( $this->ajax_handler, 'verify_otp' ) );
		add_action( 'wp_ajax_nopriv_verify_otp', array( $this->ajax_handler, 'verify_otp' ) );
		add_action( 'wp_ajax_resend_otp', array( $this->ajax_handler, 'resend_otp' ) );
		add_action( 'wp_ajax_nopriv_resend_otp', array( $this->ajax_handler, 'resend_otp' ) );

		// Bypass external CAPTCHA plugin validation when user has already verified email via OTP.
		// Runs after i13 "reCaptcha for WooCommerce" plugin's validation (priority 10) to remove
		// its captcha error, since the Google reCAPTCHA token is single-use and was already
		// consumed during CEV's pre-OTP validation step.
		add_action( 'woocommerce_register_post', array( $this, 'bypass_captcha_after_verification' ), 99, 3 );
	}

	/**
	 * Remove external reCAPTCHA validation errors after successful OTP verification.
	 *
	 * When a user completes OTP verification, CEV sets a short-lived transient to mark
	 * the email as verified. This method checks that transient and, if present, strips
	 * the reCAPTCHA error from the registration validation errors. This prevents a
	 * double-validation failure where CEV's initial captcha check consumes the Google
	 * reCAPTCHA token, causing a second external plugin to fail when it tries to
	 * re-verify the now-spent token during the final form submission.
	 *
	 * @since 2.9.4
	 * @param string   $username          The submitted username.
	 * @param string   $email             The submitted email address.
	 * @param mixed    $validation_errors The WP_Error object collecting registration errors.
	 *                                    Typed loosely because the guard below tolerates a
	 *                                    third-party filter passing something else.
	 * @return void
	 */
	public function bypass_captcha_after_verification( $username, $email, $validation_errors ) {
		if ( empty( $email ) || ! is_email( $email ) ) {
			return;
		}

		if ( ! is_wp_error( $validation_errors ) ) {
			return;
		}

		$verified_transient_key = 'cev_signup_email_verified_' . md5( strtolower( $email ) );
		if ( ! get_transient( $verified_transient_key ) ) {
			return;
		}

		// Remove reCAPTCHA-related error codes added by external CAPTCHA plugins.
		$captcha_error_codes = array( 'g-recaptcha_error', 'h-captcha_error', 'turnstile_error' );
		foreach ( $captcha_error_codes as $code ) {
			if ( in_array( $code, $validation_errors->get_error_codes(), true ) ) {
				$validation_errors->remove( $code );
			}
		}

		// Note: do NOT delete the transient here. The later `user_register` hook in
		// auto_verify_user_on_registration() still needs it to mark the new account
		// as verified. That handler consumes the transient after use.
	}

	/**
	 * Add OTP popup to My Account page.
	 *
	 * Loads and displays the signup verification popup template
	 * on the WooCommerce My Account login form.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function add_otp_popup_to_my_account() {
		$template_path = cev_pro()->get_plugin_path() . '/includes/signup-verification/views/cev-signup-popup.php';
		if ( file_exists( $template_path ) ) {
			require_once $template_path;
		}
	}

	/**
	 * Send signup verification email to recipient.
	 *
	 * Wrapper method for backward compatibility.
	 * Delegates to the email sender class.
	 *
	 * @since 1.0.0
	 * @param string $recipient Email address to send verification to.
	 * @return bool True if email was sent successfully, false otherwise.
	 */
	public function send_signup_verification_email( $recipient ) {
		return $this->email_sender->send_verification_email( $recipient );
	}

}
