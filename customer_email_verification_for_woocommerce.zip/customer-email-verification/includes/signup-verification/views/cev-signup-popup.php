<?php
/**
 * Signup Verification Popup Template
 *
 * Displays the OTP verification popup on the My Account login/registration page.
 * This template is included when users attempt to register a new account.
 * The popup allows users to enter the verification code sent to their email address.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template is require_once'd inside a method (add_otp_popup_to_my_account / Smart Form render / Dokan integration), so these are function-scoped locals, not globals.

// Initialize customizer options for default values.
$cev_customizer_options = new CEV_Customizer_Options();
$defaults               = is_object( $cev_customizer_options ) && isset( $cev_customizer_options->defaults ) && is_array( $cev_customizer_options->defaults ) ? $cev_customizer_options->defaults : array();

// Popup appearance is driven entirely by the design tokens emitted on the
// root element below (see CEV_Functions_Pro::popup_style_tokens). Do NOT
// re-read the style keys here and re-emit them as inline style attributes —
// an inline style beats the stylesheet, which is what stopped the card from
// being themeable in the first place.
$cev_popup_style = cev_pro()->function->popup_style_attr();

$enable_email_verification   = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification' );
$password_setup_link_enabled = get_option( 'woocommerce_registration_generate_password', 'no' );

// Get verification header text with fallback to default.
$verification_header = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header', isset( $defaults['cev_verification_header'] ) ? $defaults['cev_verification_header'] : '' );
$verification_header = cev_pro()->function->cev_pro_translate_string( $verification_header );
$heading_default     = __( 'Verify its you.', 'customer-email-verification' );
$heading_text        = ! empty( $verification_header ) ? $verification_header : $heading_default;

// Get verification message from customizer settings (with placeholder for email).
$verification_message = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_message',
	__( 'We sent verification code to {customer_email}. To verify your email address, please check your inbox and enter the code below.', 'customer-email-verification' )
);
// Translate the configured message (Polylang current language) before merge tags.
$verification_message = cev_pro()->function->cev_pro_translate_string( $verification_message );
// Parse other merge tags (like {site_title}) but keep {customer_email} for JavaScript replacement.
$verification_message = cev_pro()->function->maybe_parse_merge_tags( $verification_message, cev_pro()->function );
// Note: {customer_email} will be replaced dynamically via JavaScript when popup is shown.

// SMS-specific message used by the Smart Form when delivering via phone (JS picks this via data-cev-sf-sms-tpl).
$verification_message_sms = cev_pro()->function->maybe_parse_merge_tags(
	__( 'We sent a verification code to {customer_email}. Please check your SMS messages and enter the code below.', 'customer-email-verification' ),
	cev_pro()->function
);

// Determine OTP input field count based on code length setting.
$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
if ( '1' === $code_length ) {
	$otp_digits = 4;
} elseif ( '2' === $code_length ) {
	$otp_digits = 6;
} else {
	// Default to 4 digits if invalid setting is provided.
	$otp_digits = 4;
}

// Get footer message with merge tag support.
$footer_message = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_widget_footer',
	isset( $defaults['cev_verification_widget_footer'] ) ? $defaults['cev_verification_widget_footer'] : ''
);
$footer_message = cev_pro()->function->cev_pro_translate_string( $footer_message );

// Parse merge tags in footer message if method exists.
if ( ! empty( $footer_message ) ) {
	$footer_message = cev_pro()->function->maybe_parse_merge_tags( $footer_message, cev_pro()->function );
}

// Verify Button visibility (Customizer → Popup Style). 'hide' (default) keeps
// the auto-verify-on-last-digit behaviour, with the button kept hidden so the
// JS can trigger it programmatically; 'show' renders it as a visible button
// the customer must click (auto-verify is disabled in signup-script.js).
$cev_show_verify_button = ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', isset( $defaults['cev_show_verify_button'] ) ? $defaults['cev_show_verify_button'] : 'hide' ) );
$cev_verify_btn_class   = $cev_show_verify_button ? 'cev-button cev-button_size_promo cev-button_type_block cev-verify-otp-visible' : '';
$cev_verify_btn_style   = $cev_show_verify_button ? 'margin-top: 16px;' : 'display: none;';
?>

<!-- OTP Verification Popup Container -->
<div id="otp-popup" style="display: none;<?php echo esc_attr( $cev_popup_style ); ?>" class="cev-authorization-grid__visual" role="dialog" aria-labelledby="otp-popup-title" aria-modal="true">
	<div class="otp_popup_inn">
		<div class="otp_content">
			<div class="cev-authorization-grid__visual">
				<div class="cev-authorization-grid__holder">
					<div class="cev-authorization-grid__inner">
						<div class="cev-authorization">
							<section class="cev-authorization__holder">
								<?php
								/*
								 * Close control. The class name is historical — .back_btn is
								 * what signup-script.js and smart-form.js bind to — but the
								 * action has always been "hide the popup", so it now carries
								 * a close icon instead of the old back arrow.
								 */
								?>
								<div class="back_btn" role="button" tabindex="0" aria-label="<?php esc_attr_e( 'Close popup', 'customer-email-verification' ); ?>">
									<svg viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
										<path d="M1 1l12 12M13 1L1 13"></path>
									</svg>
								</div>

								<?php
								/*
								 * Popup header — the built-in mark, or the merchant's Header
								 * Image when they have set one. popup_header_html() is the
								 * single source of truth so this popup and its Customizer
								 * preview cannot drift.
								 */
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
								echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
								?>

								<!-- Popup Heading and Description -->
								<div class="cev-authorization__heading">
									<span id="otp-popup-title" class="cev-authorization__title">
										<?php echo wp_kses_post( $heading_text ); ?>
									</span>
									<span class="cev-authorization__description" data-cev-sf-sms-tpl="<?php echo esc_attr( $verification_message_sms ); ?>">
										<?php echo wp_kses_post( $verification_message ); ?>
									</span>
								</div>

								<!-- OTP Input Fields -->
								<div class="otp-container" role="group" aria-label="<?php esc_attr_e( 'Enter verification code', 'customer-email-verification' ); ?>">
									<?php for ( $i = 1; $i <= $otp_digits; $i++ ) : ?>
										<?php
										/* translators: %d: OTP digit position number */
										$aria_label = sprintf( esc_attr__( 'OTP digit %d', 'customer-email-verification' ), (int) $i );
										?>
										<input
											type="text"
											maxlength="1"
											class="otp-input"
											id="otp_input_<?php echo esc_attr( $i ); ?>"
											placeholder=" "
											aria-label="<?php echo esc_attr( $aria_label ); ?>"
											inputmode="numeric"
											autocomplete="one-time-code"
										/>
									<?php endfor; ?>
								</div>

								<!-- Error Message Container -->
								<div class="error_mesg" role="alert" aria-live="polite"></div>

								<!-- Hidden Form Fields -->
								<input type="hidden" value="<?php echo esc_attr( $enable_email_verification ); ?>" name="cev_enable_email_verification_popup" id="cev_enable_email_verification_popup">
								<input type="hidden" value="<?php echo esc_attr( $password_setup_link_enabled ); ?>" name="password_setup_link_enabled" id="password_setup_link_enabled">

								<!-- Verify Button (visible when Customizer "Verify Button" is Show; otherwise hidden and triggered by JS) -->
								<button id="verify-otp-button" type="button" class="<?php echo esc_attr( $cev_verify_btn_class ); ?>" style="<?php echo esc_attr( $cev_verify_btn_style ); ?>" aria-label="<?php esc_attr_e( 'Verify OTP code', 'customer-email-verification' ); ?>">
									<?php esc_html_e( 'Verify', 'customer-email-verification' ); ?>
								</button>

								<!-- Resend Success Message -->
								<p class="resend_sucsess" style="display:none;" role="status" aria-live="polite">
									<?php esc_html_e( 'OTP sent successfully', 'customer-email-verification' ); ?>
								</p>

								<!-- Footer Message -->
								<?php if ( ! empty( $footer_message ) ) : ?>
									<footer class="cev-authorization__footer" style="display:none;">
										<?php echo wp_kses_post( $footer_message ); ?>
									</footer>
								<?php endif; ?>

								<!-- Resend Timer -->
								<span class="cev_resend_timer" style="display:none;" aria-live="polite"></span>
							</section>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Loading Overlay -->
<div class="cev_loading_overlay" style="<?php echo esc_attr( $cev_popup_style ); ?>" aria-hidden="true"></div>
<?php
/*
 * The overlay tint used to be painted here by an unscoped <style> block with
 * !important. That hit EVERY .cev-authorization-grid__visual on the page —
 * including the one nested inside this popup — so the tint was applied twice
 * and the backdrop rendered darker than the configured colour. It is now the
 * --cev-popup-overlay token on the root above, and cev-popup.css makes any
 * nested overlay transparent.
 */
?>
