<?php
/**
 * Cron Manager for Customer Email Verification PRO
 *
 * Single source of truth for every WP-Cron event the plugin owns.
 * Schedules on activation, clears on deactivation, and self-heals on
 * `init` if a plugin update added a new event without re-activation.
 *
 * Hook names are exposed as class constants so callers (the maintenance
 * class, settings page, etc.) reference one canonical name instead of
 * hard-coded strings sprinkled across the codebase.
 *
 * Note: this class only manages SCHEDULING (the "when"). The actual
 * event handlers live with their domain logic — see CEV_Pro_Maintenance
 * for the cleanup + re-engagement callbacks. Separating the two keeps
 * this file small and gives admins one obvious place to look when
 * something cron-related misbehaves.
 *
 * License-related crons (cev_pro_check_subscription_daily etc.) live
 * in the main plugin file because they're tightly coupled to the Pro
 * licence module and don't exist in the Woo Marketplace build.
 *
 * @package Customer_Email_Verification
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Pro_Cron Class
 *
 * All scheduling logic. No callbacks live here.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Pro_Cron {

	/**
	 * Cron hook: daily cleanup of stale unverified records (Task 5).
	 *
	 * @var string
	 */
	const HOOK_LOG_CLEANUP = 'cev_pro_unverified_cleanup_daily';

	/**
	 * Cron hook: daily auto-delete of unverified WP user accounts (Task 5c).
	 *
	 * @var string
	 */
	const HOOK_USER_CLEANUP = 'cev_pro_unverified_users_cleanup_daily';

	/**
	 * Cron hook: daily re-engagement reminder emails (Task 5d).
	 *
	 * @var string
	 */
	const HOOK_REENGAGEMENT = 'cev_pro_reengagement_daily';

	/**
	 * Legacy cron hook from earlier disposable-domain auto-update logic.
	 * Kept here only so deactivation can clean it up on existing installs.
	 *
	 * @var string
	 */
	const HOOK_LEGACY_DISPOSABLE = 'cev_pro_update_disposable_list_weekly';

	/**
	 * Tracks one-time hook registration for the init self-heal.
	 *
	 * @var bool
	 */
	private static $hooks_registered = false;

	/**
	 * Get the canonical schedule for every plugin-owned cron.
	 *
	 * Each entry: hook name => array(
	 *     'recurrence' => 'daily' | 'hourly' | 'twicedaily',
	 *     'offset'     => Seconds to add to time() on first schedule. Used
	 *                     to stagger maintenance crons so they don't all
	 *                     fire at the same minute on an active store.
	 * )
	 *
	 * Filterable via `cev_pro_cron_schedules` so integrators can add their
	 * own events or change the cadence without forking the plugin.
	 *
	 * @since 2.10.0
	 * @return array<string, array{recurrence:string, offset:int}>
	 */
	public static function get_schedules() {
		$schedules = array(
			self::HOOK_LOG_CLEANUP  => array(
				'recurrence' => 'daily',
				'offset'     => HOUR_IN_SECONDS,        // +1h
			),
			self::HOOK_USER_CLEANUP => array(
				'recurrence' => 'daily',
				'offset'     => 2 * HOUR_IN_SECONDS,    // +2h — stagger from log cleanup.
			),
			self::HOOK_REENGAGEMENT => array(
				'recurrence' => 'daily',
				'offset'     => 3 * HOUR_IN_SECONDS,    // +3h — stagger from user cleanup.
			),
		);

		/**
		 * Filter the plugin's cron schedule.
		 *
		 * @since 2.10.0
		 * @param array $schedules Map of hook => { recurrence, offset }.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (array) apply_filters( 'cev_pro_cron_schedules', $schedules );
	}

	/**
	 * Schedule every plugin cron event that isn't already scheduled.
	 *
	 * Called from the activation hook AND from `init` (via self::register())
	 * so a plugin update that introduces a new cron without prompting a
	 * full re-activation still gets that cron scheduled.
	 *
	 * Idempotent — wp_next_scheduled() guards each call.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function register_schedules() {
		$schedules = self::get_schedules();
		$now       = time();

		foreach ( $schedules as $hook => $config ) {
			if ( wp_next_scheduled( $hook ) ) {
				continue;
			}
			$recurrence = isset( $config['recurrence'] ) ? (string) $config['recurrence'] : 'daily';
			$offset     = isset( $config['offset'] )     ? (int) $config['offset']         : 0;
			wp_schedule_event( $now + $offset, $recurrence, $hook );
		}
	}

	/**
	 * Clear every cron event the plugin owns + the legacy hook.
	 *
	 * Called from the deactivation hook. Always safe — wp_clear_scheduled_hook
	 * is a no-op if nothing is scheduled.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function clear_schedules() {
		$hooks = array_keys( self::get_schedules() );
		// Always include legacy hooks so old installs get cleaned up.
		$hooks[] = self::HOOK_LEGACY_DISPOSABLE;

		foreach ( $hooks as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
	}

	/**
	 * Register the init-time self-heal.
	 *
	 * Idempotent — call once from the main plugin bootstrap. The init
	 * action checks every owned hook and schedules any that are missing.
	 *
	 * Why: a plugin update that adds a NEW cron (like Task 5d's
	 * re-engagement hook on existing 5/5c installs) wouldn't run the
	 * activation hook again, so the new cron would silently never fire.
	 * Self-heal on init catches that case.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function register() {
		if ( self::$hooks_registered ) {
			return;
		}
		self::$hooks_registered = true;

		add_action( 'init', array( __CLASS__, 'register_schedules' ), 5 );
	}
}
