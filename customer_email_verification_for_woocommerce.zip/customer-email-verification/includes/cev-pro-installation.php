<?php
if (!defined('ABSPATH')) {
	exit;
}
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Pro_Installation {
	public $plugin_file;

	/**
	 * Background action hook that runs the one-time analytics backfill so a
	 * large user table can never block a normal request (gateway 504).
	 *
	 * @var string
	 */
	const BACKFILL_ACTION = 'cev_pro_run_analytics_backfill';

	/**
	 * Initialize the main plugin function
	 */
	public function __construct( $plugin_file ) {
		$this->plugin_file = $plugin_file;
		register_activation_hook($this->plugin_file, array($this, 'on_install_cev'));		
		add_action( 'init', array( $this, 'on_update_cev' ) );

		// Background handler for the one-time analytics backfill — scheduled by
		// maybe_schedule_backfill() so it never runs inline on a normal request.
		add_action( self::BACKFILL_ACTION, array( $this, 'backfill_historical_events' ) );
	}

	/**
	 * Instance of this class.
	 *
	 * @var object Class Instance
	 */
	private static $instance;

	/**
	 * Get the class instance
	 *
	 * @param string $plugin_file
	 * @return CEV_Pro_Installation
	 */
	public static function get_instance( $plugin_file ) {
		if (null === self::$instance) {
			self::$instance = new self($plugin_file);
		}

		return self::$instance;
	}
	public function on_install_cev() {
		$this->create_user_log_table();
		$this->create_analytics_events_table();

		// Register all WC My-Account rewrite endpoints owned by the plugin
		// BEFORE flushing, so flush_rewrite_rules() captures them in the
		// cache. Without this, the endpoint URLs return 404 until an admin
		// manually saves the Settings → Permalinks page.
		add_rewrite_endpoint( 'login-authentication', EP_PAGES );
		add_rewrite_endpoint( 'cev-2fa', EP_PAGES );
		flush_rewrite_rules();
	}

	/**
	 * Create the analytics events table.
	 *
	 * Single append-only table where every verification-related event
	 * (signup OTP sent, code verified, code failed, disposable email
	 * blocked, MX check failed, blocklist hit, B2B allowlist denied,
	 * 2FA enrol / verify) is recorded with a timestamp. Powers the
	 * Analytics tab.
	 *
	 * Indexes:
	 *   - (created_at, event_type)  → fast date-range + event-type filter
	 *   - (email)                   → fast lookup by user for debugging
	 *
	 * @since 2.10.0
	 */
	public function create_analytics_events_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'cev_verification_events';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			email VARCHAR(190) NOT NULL DEFAULT '',
			event_type VARCHAR(40) NOT NULL,
			context VARCHAR(20) NOT NULL DEFAULT '',
			ip VARCHAR(45) NULL,
			country VARCHAR(2) NULL,
			extra LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY created_at_event_type (created_at, event_type),
			KEY email (email)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Backfill historical verification events for the Analytics dashboard.
	 *
	 * One-shot migration run on update to v2.10.0 so existing customers
	 * don't see an empty Analytics dashboard right after upgrading.
	 *
	 * TWO sources, used for different purposes:
	 *
	 *   1. `wp_users` JOIN `wp_usermeta` (customer_email_verified) —
	 *      authoritative list of REGISTERED users.
	 *        - One `otp_sent` event per user (ts = `user_registered`).
	 *        - One additional `otp_verified` if `meta_value === 'true'`.
	 *
	 *   2. `wp_cev_user_log` — abandoned/incomplete signup attempts
	 *      (OTP went out, user never completed registration).
	 *        - One `otp_sent` event per row (ts = `last_updated`).
	 *        - NO `otp_verified` event (these never verified).
	 *        - Only included if the email isn't ALSO in wp_users (a
	 *          completed signup) — dedupe so we never double-count.
	 *
	 * Why both? Because the dashboard reads them differently:
	 *   - Signups KPI = unique wp_users only (excludes abandoned).
	 *   - Funnel "email sent" step = ALL otp_sent events (so the
	 *     drop-off to verified is visible).
	 *
	 * (See CLAUDE.md → Data Model for why cev_user_log is NOT counted
	 * as signups but IS counted in the funnel's sent step.)
	 *
	 * Notes / limitations:
	 *   - We don't know the original context (signup vs. checkout vs.
	 *     edit_account) for backfilled rows, so we tag everything as
	 *     `signup` — the most common case.
	 *   - `user_id` is left NULL for backfill rows (we'd need an extra
	 *     placeholder per row to wire it through; the value isn't used
	 *     by the dashboard's aggregates).
	 *   - Capped at 50,000 source rows per pass to avoid PHP timeouts
	 *     on very large stores. The idempotency option
	 *     `cev_pro_analytics_backfill` prevents re-runs; admins on huge
	 *     installs can bump the cap via the `cev_analytics_backfill_cap`
	 *     filter.
	 *   - Bulk INSERT (one query per 500-row source batch) for speed.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function backfill_historical_events() {
		global $wpdb;

		// Idempotency gate — only ever run once per site.
		if ( 'done' === get_option( 'cev_pro_analytics_backfill', '' ) ) {
			return;
		}

		$events_table = $wpdb->prefix . 'cev_verification_events';

		// Events table must exist; otherwise mark done and exit.
		$events_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events_table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( ! $events_exists ) {
			update_option( 'cev_pro_analytics_backfill', 'done', false );
			return;
		}

		// Try to give the migration enough headroom on big stores. These
		// calls are no-ops on hosts that disable them.
		if ( function_exists( 'ignore_user_abort' ) ) {
			ignore_user_abort( true );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,Squiz.PHP.DiscouragedFunctions.Discouraged -- Extend execution time for a potentially long one-time install/backfill; guarded by function_exists.
			@set_time_limit( 120 );
		}

		$batch_size   = 500;
		$offset       = 0;
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$max_rows     = (int) apply_filters( 'cev_analytics_backfill_cap', 50000 );
		$total_events = 0;

		// Read REGISTERED users (the only valid source of "signups").
		// Pull each user with a `customer_email_verified` usermeta — that
		// meta key exists on every user the plugin has ever touched, so
		// it's the right scope. Users without the meta key predate the
		// plugin's involvement with their account; ignoring them is the
		// safe call.
		do {
			$user_rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT u.user_email, u.user_registered, um.meta_value AS verified
					 FROM {$wpdb->users} u
					 INNER JOIN {$wpdb->usermeta} um ON um.user_id = u.ID AND um.meta_key = %s
					 WHERE u.user_email <> ''
					   AND u.user_registered IS NOT NULL
					   AND u.user_registered <> %s
					 ORDER BY u.ID ASC
					 LIMIT %d OFFSET %d",
					'customer_email_verified',
					'0000-00-00 00:00:00',
					$batch_size,
					$offset
				),
				ARRAY_A
			);

			if ( empty( $user_rows ) ) {
				break;
			}

			$placeholders = array();
			$values       = array();
			foreach ( $user_rows as $row ) {
				$email     = isset( $row['user_email'] ) ? (string) $row['user_email'] : '';
				$verified  = isset( $row['verified'] ) ? (string) $row['verified'] : '';
				$timestamp = isset( $row['user_registered'] ) ? (string) $row['user_registered'] : '';

				// Defensive: skip rows with missing email or invalid timestamp.
				if ( '' === $email || '' === $timestamp || '0000-00-00 00:00:00' === $timestamp ) {
					continue;
				}

				// Every registered user → one otp_sent event.
				$placeholders[] = '(%s, %s, %s, %s)';
				$values[]       = $email;
				$values[]       = 'otp_sent';
				$values[]       = 'signup';
				$values[]       = $timestamp;

				// Verified users → one additional otp_verified event.
				if ( 'true' === $verified ) {
					$placeholders[] = '(%s, %s, %s, %s)';
					$values[]       = $email;
					$values[]       = 'otp_verified';
					$values[]       = 'signup';
					$values[]       = $timestamp;
				}
			}

			if ( ! empty( $placeholders ) ) {
				$sql = "INSERT INTO {$wpdb->prefix}cev_verification_events (email, event_type, context, created_at) VALUES " . implode( ', ', $placeholders ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery
				$total_events += count( $placeholders );
			}

			$offset += $batch_size;

			// Hard cap so a million-user store can't hang the migration.
			if ( $offset >= $max_rows ) {
				break;
			}
		} while ( count( $user_rows ) === $batch_size );

		// SECOND PASS — `wp_cev_user_log` abandoned attempts.
		//
		// Insert `otp_sent` events only (NO `otp_verified` — these never
		// verified). Dedupe against `wp_users` so we don't double-count
		// users who completed signup. These rows feed the funnel's
		// "Verification email sent" step but NOT the Signups KPI
		// (Signups reads from wp_users directly).
		$log_table  = $wpdb->prefix . 'cev_user_log';
		$log_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $log_table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $log_exists ) {
			$log_offset = 0;
			do {
				$log_rows = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT email, last_updated FROM {$wpdb->prefix}cev_user_log
						 WHERE last_updated IS NOT NULL
						   AND last_updated <> %s
						   AND email <> ''
						   AND email NOT IN ( SELECT user_email FROM {$wpdb->users} )
						 ORDER BY id ASC
						 LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						'0000-00-00 00:00:00',
						$batch_size,
						$log_offset
					),
					ARRAY_A
				);

				if ( empty( $log_rows ) ) {
					break;
				}

				$placeholders = array();
				$values       = array();
				foreach ( $log_rows as $row ) {
					$email     = isset( $row['email'] ) ? (string) $row['email'] : '';
					$timestamp = isset( $row['last_updated'] ) ? (string) $row['last_updated'] : '';

					if ( '' === $email || '' === $timestamp || '0000-00-00 00:00:00' === $timestamp ) {
						continue;
					}

					// Abandoned attempt — only otp_sent, no otp_verified.
					$placeholders[] = '(%s, %s, %s, %s)';
					$values[]       = $email;
					$values[]       = 'otp_sent';
					$values[]       = 'signup';
					$values[]       = $timestamp;
				}

				if ( ! empty( $placeholders ) ) {
					$sql = "INSERT INTO {$wpdb->prefix}cev_verification_events (email, event_type, context, created_at) VALUES " . implode( ', ', $placeholders ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery
					$total_events += count( $placeholders );
				}

				$log_offset += $batch_size;

				if ( $log_offset >= $max_rows ) {
					break;
				}
			} while ( count( $log_rows ) === $batch_size );
		}

		// Persist a stamp so this never re-runs even if the version
		// option gets reset somehow.
		update_option( 'cev_pro_analytics_backfill', 'done', false );
		update_option( 'cev_pro_analytics_backfill_count', $total_events, false );
	}

	/**
	 * Create user log table
	 */
	public function create_user_log_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'cev_user_log';
		if ( ! $wpdb->query( $wpdb->prepare( 'show tables like %s', $table_name ) ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $this->get_user_log_table_schema() );
		}
	}

	/**
	 * CREATE TABLE statement for `cev_user_log`, in dbDelta format.
	 *
	 * Indexes:
	 *   - email        → OTP lookups on signup / checkout / edit-account (`WHERE email = %s`)
	 *   - verified     → Maintenance stats + cleanup cron (`WHERE verified != 'true'`)
	 *   - last_updated → Unverified Users list ordering + cleanup cutoff
	 *
	 * Before 3.0.6 the table only had its primary key, so every one of those
	 * queries was a full scan — harmless on a few hundred rows, a timeout
	 * risk once a spam-hit store accumulates hundreds of thousands.
	 *
	 * @since 3.0.6
	 * @return string
	 */
	private function get_user_log_table_schema() {
		global $wpdb;
		$table_name      = $wpdb->prefix . 'cev_user_log';
		$charset_collate = $wpdb->get_charset_collate();

		// Two spaces after PRIMARY KEY are required by dbDelta.
		return "CREATE TABLE $table_name (
			id int(11) NOT NULL AUTO_INCREMENT,
			email varchar(100) NOT NULL,
			pin varchar(100) NOT NULL,
			verified varchar(10) NOT NULL,
			secret_code varchar(100) NOT NULL,
			last_updated datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY email (email),
			KEY verified (verified),
			KEY last_updated (last_updated)
		) $charset_collate;";
	}

	/**
	 * Add the `cev_user_log` indexes on sites that created the table before
	 * 3.0.6. dbDelta compares the live table with the schema and only emits
	 * the missing ALTERs, so this is safe to re-run.
	 *
	 * @since 3.0.6
	 * @return void
	 */
	public function upgrade_user_log_table_indexes() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'cev_user_log';
		if ( ! $wpdb->query( $wpdb->prepare( 'show tables like %s', $table_name ) ) ) {
			return; // Nothing to upgrade; create_user_log_table() builds it with indexes.
		}
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $this->get_user_log_table_schema() );
	}

	/**
	 * Handle plugin update tasks.
	 *
	 * Runs migration logic when plugin version changes.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function on_update_cev() {
		if ( ! is_admin() ) {
			return;
		}

		$current_version = get_option( 'cev_pro_update_version', '1.0' );

		// Version 1.1 migration.
		if ( version_compare( $current_version, '1.1', '<' ) ) {
			$this->create_user_log_table();
			update_option( 'cev_verification_message', 'We sent verification code. To verify your email address, please check your inbox and enter the code below.' );
			// Note: Migration code uses update_option directly to set defaults during migration
			$settings = get_option( 'cev_pro_admin_settings', array() );
			$settings['cev_verification_code_length'] = '1';
			update_option( 'cev_pro_admin_settings', $settings );
			update_option( 'cev_verification_email_body', 'Thank you for signing up for {site_title}, to activate your account, we need to verify your email address. <p>Your verification code: <strong>{cev_user_verification_pin}</strong></p>' );
			update_option( 'cev_pro_update_version', '1.1' );
		}

		// Version 2.9.0 migration: Consolidate customizer settings into single option.
		if ( version_compare( $current_version, '1.3', '<' ) ) {
			$this->migrate_settings_to_single_option();
			$this->migrate_customizer_settings_to_single_option();
			update_option( 'cev_pro_update_version', '1.3' );
		}

		// Version 2.10.0 migration: seed login-auth role enforcement
		// policy with the legacy default (skip Administrator + Editor)
		// so existing installs see no behaviour change after the upgrade.
		// Only writes if the keys are unset — never overwrites a value
		// the admin already set.
		if ( version_compare( $current_version, '1.4', '<' ) ) {
			$settings = get_option( 'cev_pro_admin_settings', array() );
			if ( ! is_array( $settings ) ) {
				$settings = array();
			}
			if ( ! isset( $settings['cev_login_auth_enforcement'] ) ) {
				$settings['cev_login_auth_enforcement'] = 'excluded_roles';
			}
			if ( ! isset( $settings['cev_login_auth_roles'] ) ) {
				$settings['cev_login_auth_roles'] = array(
					'administrator' => 1,
					'editor'        => 1,
				);
			}
			update_option( 'cev_pro_admin_settings', $settings );
			update_option( 'cev_pro_update_version', '1.4' );
		}

		// Version 2.10.0 migration (continued): flush rewrite rules so
		// the new `/my-account/cev-2fa/` WooCommerce endpoint registers
		// without the admin needing to manually visit Settings →
		// Permalinks. The endpoint is registered via add_rewrite_endpoint()
		// on every `init`, but the rewrite rule cache only picks it up
		// after a flush. We do this exactly once per upgrade.
		if ( version_compare( $current_version, '1.5', '<' ) ) {
			// Make sure our endpoint is registered BEFORE flushing so
			// flush_rewrite_rules() captures it in the cache.
			if ( class_exists( 'CEV_2FA_Setup' ) && method_exists( 'CEV_2FA_Setup', 'instance' ) ) {
				CEV_2FA_Setup::instance()->register_wc_endpoint();
			}
			flush_rewrite_rules( false ); // false = don't write .htaccess; option-table cache is enough.
			update_option( 'cev_pro_update_version', '1.5' );
		}

		// Version 2.10.0 migration (continued): create the verification
		// events table that powers the new Analytics dashboard. Existing
		// sites get the table on the first admin page load after upgrade;
		// dbDelta is idempotent so re-runs are safe.
		if ( version_compare( $current_version, '1.6', '<' ) ) {
			$this->create_analytics_events_table();
			update_option( 'cev_pro_update_version', '1.6' );
		}

		// Version 2.10.0 migration (continued): backfill historical
		// signups + verifications from the legacy `cev_user_log` table
		// into the new analytics events table so existing customers see
		// real charts on day 1 instead of an empty dashboard.
		//
		// Gate uses TWO conditions OR'd together:
		//   1. version_compare gate — for installs whose
		//      `cev_pro_update_version` follows the internal 1.x counter.
		//   2. Direct check on the `cev_pro_analytics_backfill` sentinel —
		//      self-healing path for legacy installs whose
		//      `cev_pro_update_version` was accidentally set to a
		//      plugin-style number (e.g. "2.9.0") by an older release,
		//      which would otherwise skip ALL 1.x migrations.
		//
		// Either way, the function itself is idempotent (returns
		// immediately once the sentinel is 'done'), so an extra call is
		// cheap.
		$backfill_done = ( 'done' === get_option( 'cev_pro_analytics_backfill', '' ) );
		if ( version_compare( $current_version, '1.7', '<' ) || ! $backfill_done ) {
			$this->maybe_schedule_backfill();
			update_option( 'cev_pro_update_version', '1.7' );
		}

		// Version 2.10.0 migration: seed Smart Form customizer defaults so the
		// subheading, button labels, brand colour and panel settings show up in
		// the form and Customizer on fresh installs and upgrades without the
		// merchant having to open and re-save the Customizer manually.
		// Only writes keys that are not already present — never overwrites saved
		// merchant customisations.
		if ( version_compare( $current_version, '1.8', '<' ) ) {
			$this->seed_smart_form_defaults();
			update_option( 'cev_pro_update_version', '1.8' );
		}

		// Version 3.0.6 migration: index `cev_user_log` (email / verified /
		// last_updated). Existing installs created the table with only a
		// primary key, so the Unverified Users list, the Maintenance stats and
		// the cleanup cron all full-scanned it.
		if ( version_compare( $current_version, '1.9', '<' ) ) {
			$this->upgrade_user_log_table_indexes();
			update_option( 'cev_pro_update_version', '1.9' );
		}
	}

	/**
	 * Seed Smart Form customizer defaults into cev_pro_customizer for fresh
	 * installs and upgrades. Only writes keys that are not already present so
	 * merchant customisations are never overwritten.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	private function seed_smart_form_defaults() {
		$customizer = get_option( 'cev_pro_customizer', array() );
		if ( ! is_array( $customizer ) ) {
			$customizer = array();
		}

		$sf_sub = __( 'Choose how you\'d like to continue', 'customer-email-verification' );
		$sf_log = __( 'Log in', 'customer-email-verification' );
		$sf_reg = __( 'Create account', 'customer-email-verification' );

		$defaults = array();
		foreach ( array( 't1', 't2', 't3', 't4' ) as $t ) {
			$defaults[ 'cev_sf_' . $t . '_brand_color' ]     = '#4f46e5';
			$defaults[ 'cev_sf_' . $t . '_btn_font_color' ]  = '#ffffff';
			$defaults[ 'cev_sf_' . $t . '_subheading' ]      = $sf_sub;
			$defaults[ 'cev_sf_' . $t . '_login_button' ]    = $sf_log;
			$defaults[ 'cev_sf_' . $t . '_register_button' ] = $sf_reg;
		}
		// Templates 2 & 3 — brand-panel / banner fields.
		$defaults['cev_sf_t2_panel_bg_solid']   = '#4f46e5';
		$defaults['cev_sf_t2_panel_text_color'] = '#ffffff';
		$defaults['cev_sf_t3_panel_bg_solid']   = '#4f46e5';
		$defaults['cev_sf_t3_panel_text_color'] = '#ffffff';

		$changed = false;
		foreach ( $defaults as $key => $value ) {
			if ( ! isset( $customizer[ $key ] ) ) {
				$customizer[ $key ] = $value;
				$changed            = true;
			}
		}

		if ( $changed ) {
			update_option( 'cev_pro_customizer', $customizer );
		}
	}

	/**
	 * Queue the one-time analytics backfill to run in the BACKGROUND instead of
	 * inline on `init`. Prefers Action Scheduler (bundled with WooCommerce),
	 * falls back to a single WP-Cron event. Cheap + safe to call on every
	 * request: it no-ops once the backfill is done or already queued.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function maybe_schedule_backfill() {
		// Already finished — nothing to do.
		if ( 'done' === get_option( 'cev_pro_analytics_backfill', '' ) ) {
			return;
		}

		// Action Scheduler (preferred — ships with WooCommerce): runs ASAP in a
		// background loopback request, so the user's request never waits on it.
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_enqueue_async_action' ) ) {
			if ( ! as_has_scheduled_action( self::BACKFILL_ACTION ) ) {
				as_enqueue_async_action( self::BACKFILL_ACTION, array(), 'cev-pro' );
			}
			return;
		}

		// WP-Cron fallback.
		if ( ! wp_next_scheduled( self::BACKFILL_ACTION ) ) {
			wp_schedule_single_event( time() + 30, self::BACKFILL_ACTION );
		}
	}

	/**
	 * Migrate all individual settings options to a single consolidated option.
	 *
	 * Collects all plugin settings from individual options, stores them in
	 * a single serialized option 'cev_pro_admin_settings', and deletes the
	 * old individual options to clean up the database.
	 *
	 * @since 2.9
	 * @return void
	 */
	private function migrate_settings_to_single_option() {
		// List of all plugin settings option keys to migrate.
		$settings_keys = $this->get_all_settings_keys();

		// Check if migration has already been completed.
		$migrated_option = get_option( 'cev_pro_admin_settings', false );
		$existing_settings = array();
		if ( false !== $migrated_option && is_array( $migrated_option ) ) {
			// Migration already completed, but ensure all keys are present.
			$existing_settings = $migrated_option;
		}

		// Collect all existing individual option values.
		$migrated_settings = $existing_settings;
		foreach ( $settings_keys as $key ) {
			$individual_value = get_option( $key, null );
			// Migrate individual option value if it exists and not already in consolidated option.
			if ( null !== $individual_value && ! isset( $migrated_settings[ $key ] ) ) {
				$migrated_settings[ $key ] = $individual_value;
			}
		}

		// Save consolidated settings (even if empty, to mark migration as started).
		update_option( 'cev_pro_admin_settings', $migrated_settings );

		// Delete old individual options after successful migration.
		// Only delete if we successfully saved consolidated settings.
		$verify_consolidated = get_option( 'cev_pro_admin_settings', false );
		if ( false !== $verify_consolidated && is_array( $verify_consolidated ) ) {
			foreach ( $settings_keys as $key ) {
				delete_option( $key );
			}
			// Mark migration as completed.
			update_option( 'cev_settings_migration_completed', true );
		}
	}

	/**
	 * Get list of all plugin settings option keys.
	 *
	 * Returns an array of all option keys used by the plugin for settings.
	 * This list is used during migration to collect and consolidate settings.
	 *
	 * @since 2.9
	 * @return array Array of setting option keys.
	 */
	private function get_all_settings_keys() {
		return array(
			// Main verification settings.
			'cev_enable_email_verification',
			'cev_enable_email_verification_checkout',
			'cev_verification_checkout_dropdown_option',
			'cev_create_an_account_during_checkout',
			'cev_enable_email_verification_cart_page',
			'cev_enable_email_verification_free_orders',
			'cev_disable_wooCommerce_store_api',

			// General settings.
			'cev_verification_code_length',
			'cev_verification_code_expiration',
			'cev_redirect_limit_resend',
			'cev_resend_limit_message',
			'cev_verification_success_message',

			// Login authentication settings.
			'cev_enable_login_authentication',
			'cev_require_otp_every_login',
			'enable_email_otp_for_account',
			'enable_email_auth_for_new_device',
			'enable_email_auth_for_new_location',
			'enable_email_auth_for_login_time',
			'cev_last_login_more_then_time',
		);
	}

	/**
	 * Migrate customizer settings to consolidated option.
	 *
	 * Collects all customizer settings from individual options (keys from cev_generate_defaults),
	 * stores them in a single serialized option 'cev_pro_customizer', and deletes the
	 * old individual options to clean up the database.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	private function migrate_customizer_settings_to_single_option() {
		// Get all customizer option keys from defaults.
		$customizer_keys = $this->get_customizer_option_keys();

		// Check if migration has already been completed.
		$existing_customizer = get_option( 'cev_pro_customizer', false );
		$migrated_customizer = array();
		
		if ( false !== $existing_customizer && is_array( $existing_customizer ) ) {
			// Migration already completed, but ensure all keys are present.
			$migrated_customizer = $existing_customizer;
		}

		// Collect all existing individual customizer option values.
		foreach ( $customizer_keys as $key ) {
			$individual_value = get_option( $key, null );
			// Migrate individual option value if it exists and not already in consolidated option.
			if ( null !== $individual_value && ! isset( $migrated_customizer[ $key ] ) ) {
				$migrated_customizer[ $key ] = $individual_value;
			}
		}

		// Save consolidated customizer settings (even if empty, to mark migration as started).
		update_option( 'cev_pro_customizer', $migrated_customizer );

		// Delete old individual options after successful migration.
		// Only delete if we successfully saved consolidated settings.
		$verify_consolidated = get_option( 'cev_pro_customizer', false );
		if ( false !== $verify_consolidated && is_array( $verify_consolidated ) ) {
			foreach ( $customizer_keys as $key ) {
				delete_option( $key );
			}
			// Mark migration as completed.
			update_option( 'cev_customizer_migration_completed', true );
		}
	}

	/**
	 * Get list of all customizer option keys from cev_generate_defaults().
	 *
	 * Returns an array of all option keys used by the customizer.
	 * These are the keys defined in CEV_Customizer_Options::cev_generate_defaults().
	 *
	 * @since 2.9.0
	 * @return array Array of customizer option keys.
	 */
	private function get_customizer_option_keys() {
		return array(
			// Email style defaults.
			'cev_widget_content_width_style',
			'cev_content_align_style',
			'cev_widget_content_padding_style',
			'cev_verification_content_background_color',
			'cev_verification_content_border_color',
			'cev_verification_content_font_color',
			'cev_verification_image_content',
			'cev_email_content_widget_header_image_width',
			'cev_header_content_font_size',
			'cev_button_text_font_size',
			'cev_button_padding_size',
			'cev_content_widget_type',
			
			// Email content defaults - Registration.
			'cev_verification_email_heading',
			'cev_verification_email_subject',
			'cev_verification_email_body',
			
			// Email content defaults - Checkout.
			'cev_verification_email_heading_che',
			'cev_verification_email_subject_che',
			'cev_verification_email_body_che',
			
			// Email content defaults - Edit Account.
			'cev_verification_email_heading_ed',
			'cev_verification_email_subject_ed',
			'cev_verification_email_body_ed',
			
			'cev_header_button_size_pro',
			
			// Footer content defaults.
			'cev_new_verification_Footer_content',
			'cev_new_verification_Footer_content_che',
			
			// Popup style defaults.
			'cev_verification_image',
			'cev_widget_header_image_width',
			'cev_button_text_header_font_size',
			'cev_button_color_widget_header',
			'cev_button_text_color_widget_header',
			'cev_button_text_size_widget_header',
			'cev_verification_popup_background_color',
			'cev_verification_popup_overlay_background_color',
			'cev_widget_content_width',
			'cev_content_align',
			'cev_button_padding_size_widget_header',
			'cev_widget_content_padding',
			'sample_toggle_switch_cev',
			'cev_verification_hide_otp_section',
			'cev_verification_widget_hide_otp_section',
			'cev_login_hide_otp_section',
			'cev_popup_button_size',
			'cev_widget_type',
			
			// Popup content defaults - Registration.
			'cev_verification_header',
			'cev_verification_message',
			'cev_verification_widget_footer',
			
			// Popup content defaults - Login Authentication.
			'cev_login_auth_header',
			'cev_login_auth_message',
			'cev_login_auth_widget_footer',
			'cev_login_auth_button_text',
			
			// Popup content defaults - Checkout.
			'cev_header_text_checkout',
			'cev_verification_widget_message_checkout',
			'cev_verification_widget_message_footer_checkout_pro',
			'cev_verification_header_button_text',
			
			// Login authentication email defaults.
			'cev_verification_login_auth_email_subject',
			'cev_verification_login_auth_email_heading',
			'cev_verification_login_auth_email_content',
			'cev_login_auth_footer_content',
			
			// Login OTP email defaults.
			'cev_verification_login_otp_email_subject',
			'cev_verification_login_otp_email_heading',
			'cev_verification_login_otp_email_content',
			'cev_login_otp_footer_content',
		);
	}
}
