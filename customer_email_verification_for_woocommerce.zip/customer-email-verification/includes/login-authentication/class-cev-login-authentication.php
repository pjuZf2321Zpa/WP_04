<?php
/**
 * Login Authentication Handler
 *
 * Handles login authentication with OTP verification for unrecognized logins.
 * Manages device/location tracking, OTP generation, email sending, and verification.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WC_Customer_Email_Verification_Login_Authentication Class
 *
 * Manages login authentication with OTP verification.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class WC_Customer_Email_Verification_Login_Authentication {

	/**
	 * Instance of this class.
	 *
	 * @var WC_Customer_Email_Verification_Login_Authentication
	 */
	private static $instance;

	/**
	 * Basic browser detection patterns.
	 *
	 * @var array<string, string>
	 */
	private $basic_browser = array(
		'Trident\/7.0' => 'Internet Explorer 11',
		'Beamrise'     => 'Beamrise',
		'Opera'        => 'Opera',
		'OPR'          => 'Opera',
		'Shiira'       => 'Shiira',
		'Chimera'      => 'Chimera',
		'Phoenix'      => 'Phoenix',
		'Firebird'     => 'Firebird',
		'Camino'       => 'Camino',
		'Netscape'     => 'Netscape',
		'OmniWeb'      => 'OmniWeb',
		'Konqueror'    => 'Konqueror',
		'icab'         => 'iCab',
		'Lynx'         => 'Lynx',
		'Links'        => 'Links',
		'hotjava'      => 'HotJava',
		'amaya'        => 'Amaya',
		'IBrowse'      => 'IBrowse',
		'iTunes'       => 'iTunes',
		'Silk'         => 'Silk',
		'Dillo'        => 'Dillo',
		'Maxthon'      => 'Maxthon',
		'Arora'        => 'Arora',
		'Galeon'       => 'Galeon',
		'Iceape'       => 'Iceape',
		'Iceweasel'    => 'Iceweasel',
		'Midori'       => 'Midori',
		'QupZilla'     => 'QupZilla',
		'Namoroka'     => 'Namoroka',
		'NetSurf'      => 'NetSurf',
		'BOLT'         => 'BOLT',
		'EudoraWeb'    => 'EudoraWeb',
		'shadowfox'    => 'ShadowFox',
		'Swiftfox'     => 'Swiftfox',
		'Uzbl'         => 'Uzbl',
		'UCBrowser'    => 'UCBrowser',
		'Kindle'       => 'Kindle',
		'wOSBrowser'   => 'wOSBrowser',
		'Epiphany'     => 'Epiphany',
		'SeaMonkey'    => 'SeaMonkey',
		'Avant Browser' => 'Avant Browser',
		'Firefox'      => 'Firefox',
		'Chrome'       => 'Google Chrome',
		'MSIE'         => 'Internet Explorer',
		'Internet Explorer' => 'Internet Explorer',
		'Safari'       => 'Safari',
		'Mozilla'      => 'Mozilla',
	);

	/**
	 * Basic platform detection patterns.
	 *
	 * @var array<string, string>
	 */
	private $basic_platform = array(
		'windows'     => 'Windows',
		'iPad'        => 'iPad',
		'iPod'        => 'iPod',
		'iPhone'      => 'iPhone',
		'mac'         => 'Apple',
		'android'     => 'Android',
		'linux'       => 'Linux',
		'Nokia'       => 'Nokia',
		'BlackBerry'  => 'BlackBerry',
		'FreeBSD'     => 'FreeBSD',
		'OpenBSD'     => 'OpenBSD',
		'NetBSD'      => 'NetBSD',
		'UNIX'        => 'UNIX',
		'DragonFly'   => 'DragonFlyBSD',
		'OpenSolaris' => 'OpenSolaris',
		'SunOS'       => 'SunOS',
		'OS\/2'       => 'OS/2',
		'BeOS'        => 'BeOS',
		'win'         => 'Windows',
		'Dillo'       => 'Linux',
		'PalmOS'      => 'PalmOS',
		'RebelMouse'  => 'RebelMouse',
	);

	/**
	 * Initialize the main plugin function.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Get the class instance.
	 *
	 * @return WC_Customer_Email_Verification_Login_Authentication
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * AJAX handler instance.
	 *
	 * @var CEV_Login_Authentication_Ajax
	 */
	private $ajax_handler;

	/**
	 * Initialize hooks and filters.
	 *
	 * @return void
	 */
	public function init() {
		if ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_login_authentication', 0 ) ) {
			add_action( 'woocommerce_created_customer', array( $this, 'add_last_login_details_to_new_customers' ), 10, 3 );
			add_action( 'wp_login', array( $this, 'cev_woocommerce_account_login_check' ), 10, 1 );
			add_action( 'wp', array( $this, 'check_user_and_redirect_to_endpoint' ) );
			add_action( 'wp', array( $this, 'cev_resend_login_otp_email' ), 1 );
			add_filter( 'cev_login_auth_message', array( $this, 'cev_login_auth_message_callback' ), 10, 2 );

			// Smart suspicious-login detection: track failed password attempts so
			// a burst of them right before a success raises the login risk score.
			if ( $this->smart_detection_enabled() ) {
				add_action( 'wp_login_failed', array( $this, 'record_failed_login_attempt' ) );
			}

			// Initialize AJAX handler.
			require_once cev_pro()->get_plugin_path() . '/includes/login-authentication/class-cev-login-authentication-ajax.php';
			$this->ajax_handler = new CEV_Login_Authentication_Ajax( $this );
		}
	}

	/**
	 * Add last login details to new customers.
	 *
	 * @param int    $user_id            User ID.
	 * @param array  $new_customer_data   New customer data.
	 * @param string $password_generated Generated password.
	 * @return void
	 */
	public function add_last_login_details_to_new_customers( $user_id, $new_customer_data, $password_generated ) {
		$login_details = $this->get_current_login_details();

		if ( empty( $login_details ) ) {
			return;
		}

		$this->update_user_login_details( $user_id, $login_details );
	}

	/**
	 * Check login and send OTP if needed.
	 *
	 * @param string $user_login User login name.
	 * @return void
	 */
	public function cev_woocommerce_account_login_check( $user_login ) {
		// The wp_login hook fires on all logins, so we don't need strict form field checks.
		// Just verify we have a valid user login parameter.
		if ( empty( $user_login ) ) {
			return;
		}

		$user = get_user_by( 'login', $user_login );
		if ( ! $user ) {
			return;
		}

		$user_id    = $user->ID;
		$user_email = $user->user_email;

		// Skip Administrator + Editor — these accounts use the legacy
		// hard-coded skip and should not be subject to email-OTP login auth.
		// (The role-based policy in the 2FA section gates the Authenticator
		// App flow only, not this email-OTP "unrecognized login" feature.)
		if ( cev_pro()->admin->is_admin_user( $user_id ) ) {
			return;
		}

		// "Require OTP on every login" challenges everyone, so it needs the wider
		// back-office exemption (editors and shop managers as well) that the
		// is_admin_user() guard above does not cover. Scoped to this option only,
		// so existing installs keep their current behaviour exactly.
		$every_login_enabled = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 ) );
		if ( $every_login_enabled && $this->is_elevated_role( $user_id ) ) {
			return;
		}

		// An unverified customer used to be skipped outright. The login code is
		// emailed to the address being claimed, so entering it proves ownership
		// — let them through when the merchant asked for a code on every login
		// or asked unverified customers to verify, and record the verification
		// once the code is accepted.
		$verified = cev_pro()->function->check_email_verify( $user_email );
		if ( false === $verified && ! $this->challenges_unverified_login( $user_id ) ) {
			return;
		}

		$login_authentication_enabled = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_login_authentication', 0 ) );
		// An unverified address must receive a CODE — the notification-only
		// branch proves nothing and so can never verify the address.
		$email_otp_enabled            = $this->is_email_otp_flow_enabled() || false === $verified;

		$login_details = $this->get_current_login_details();
		if ( empty( $login_details ) ) {
			return;
		}

		$user_last_login_details = get_user_meta( $user_id, 'cev_last_login_detail', true );
		$user_last_login_time    = get_user_meta( $user_id, 'cev_last_login_time', true );

		if ( $login_authentication_enabled && $email_otp_enabled ) {
			$this->handle_otp_verification_flow( $user_id, $user_email, $login_details, $user_last_login_details, $user_last_login_time );
		} elseif ( $login_authentication_enabled ) {
			$this->handle_authentication_email_flow( $user_id, $user_email, $login_details, $user_last_login_details, $user_last_login_time );
		} else {
			$this->update_user_login_details( $user_id, $login_details );
		}

		// The failed-password counter has served its purpose for this login;
		// clear it so it does not carry over to the next sign-in.
		$this->clear_failed_login_count( $user_id );
	}

	/**
	 * Whether the email-OTP branch (rather than the notification-email-only
	 * branch) should run.
	 *
	 * "Require OTP on every login" implies a one-time code, so it forces the OTP
	 * flow on regardless of the "Require OTP verification for unrecognized login"
	 * setting — otherwise a store could switch it on and never be asked for
	 * anything. The condition rows are hidden in the admin while it is on, so
	 * the stored value of that setting is not meaningful in this state.
	 *
	 * @since 3.0.3
	 * @return bool
	 */
	private function is_email_otp_flow_enabled() {
		if ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 ) ) {
			return true;
		}

		return ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_otp_for_account', 1 ) );
	}

	/**
	 * Whether the user holds a back-office role that must never be challenged by
	 * "Require OTP on every login".
	 *
	 * The long-standing guard for this feature, is_admin_user(), only matches
	 * administrators. Challenging every login makes that gap visible for editors
	 * and shop managers, so this wider check is applied — but only when the new
	 * option is on, leaving existing installs untouched. The role list mirrors
	 * CEV_Functions_Pro::should_prompt_account_verify().
	 *
	 * @since 3.0.3
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private function is_elevated_role( $user_id ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user instanceof WP_User ) {
			return false;
		}

		$elevated = array( 'administrator', 'editor', 'shop_manager' );

		return (bool) array_intersect( $elevated, (array) $user->roles );
	}

	/**
	 * Whether an UNVERIFIED customer should be challenged by the login OTP.
	 *
	 * This flow was originally written for customers whose address is already
	 * confirmed, and skipped everyone else. But the code is emailed to the
	 * address being claimed, so entering it correctly IS proof of ownership —
	 * which means the login OTP can verify the address instead of ignoring it.
	 *
	 * Applies when the login-auth master switch is on AND the merchant has
	 * asked for either:
	 *   - a code on every login ('cev_require_otp_every_login'), or
	 *   - unverified customers to verify ('cev_require_verify_unverified_login').
	 *
	 * Back-office roles are never challenged, matching
	 * CEV_Functions_Pro::should_prompt_account_verify().
	 *
	 * @since 3.0.3
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private function challenges_unverified_login( $user_id ) {
		if ( 1 !== (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_login_authentication', 0 ) ) {
			return false;
		}

		if ( $this->is_elevated_role( $user_id ) ) {
			return false;
		}

		$every_login     = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 ) );
		$verify_on_login = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_require_verify_unverified_login', 0 ) );

		$challenge = ( $every_login || $verify_on_login );

		/**
		 * Filter whether an unverified customer is challenged by the login OTP.
		 *
		 * @since 3.0.3
		 * @param bool $challenge Resolved state.
		 * @param int  $user_id   User ID.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (bool) apply_filters( 'cev_challenge_unverified_login', $challenge, $user_id );
	}

	/**
	 * Handle OTP verification flow.
	 *
	 * @param int    $user_id              User ID.
	 * @param string $user_email           User email address.
	 * @param array  $login_details        Current login details.
	 * @param array  $user_last_login_details Last login details.
	 * @param string $user_last_login_time Last login time.
	 * @return void
	 */
	private function handle_otp_verification_flow( $user_id, $user_email, $login_details, $user_last_login_details, $user_last_login_time ) {
		// An unverified address is challenged unconditionally: the device /
		// location / idle conditions describe a known customer's usual pattern,
		// which says nothing about an address that was never confirmed.
		$should_send_otp = false === cev_pro()->function->check_email_verify( $user_email )
			|| $this->should_send_login_otp( $user_id, $login_details, $user_last_login_details, $user_last_login_time );

		if ( $should_send_otp ) {
			$this->send_and_store_login_otp( $user_id, $user_email, $login_details );
		} else {
			$this->update_user_login_details( $user_id, $login_details );
		}
	}

	/**
	 * Handle authentication email flow (without OTP).
	 *
	 * @param int    $user_id              User ID.
	 * @param string $user_email           User email address.
	 * @param array  $login_details        Current login details.
	 * @param array  $user_last_login_details Last login details.
	 * @param string $user_last_login_time Last login time.
	 * @return void
	 */
	private function handle_authentication_email_flow( $user_id, $user_email, $login_details, $user_last_login_details, $user_last_login_time ) {
		$should_send_email = $this->should_send_authentication_email( $user_id, $login_details, $user_last_login_details, $user_last_login_time );

		$this->update_user_login_details( $user_id, $login_details );

		if ( $should_send_email ) {
			$this->send_login_authentication_email( $user_id, $user_email );
		}
	}

	/**
	 * Determine if login OTP should be sent.
	 *
	 * @param array  $login_details        Current login details.
	 * @param array  $user_last_login_details Last login details.
	 * @param string $user_last_login_time Last login time.
	 * @return bool
	 */
	private function should_send_login_otp( $user_id, $login_details, $user_last_login_details, $user_last_login_time ) {
		// "Require OTP on every login" overrides every condition below. It is
		// deliberately checked before Smart detection: smart_should_challenge()
		// returns false when the user has no known profiles yet (first-ever login
		// is enrolled silently), and "every login" must not inherit that escape.
		if ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 ) ) {
			return true;
		}

		// Smart suspicious-login detection replaces the fixed conditions below
		// with a risk score when the merchant has enabled it.
		if ( $this->smart_detection_enabled() ) {
			return $this->smart_should_challenge( $user_id, $login_details, $user_last_login_time );
		}

		// Ensure user_last_login_details is an array.
		if ( ! is_array( $user_last_login_details ) ) {
			$user_last_login_details = array();
		}

		$enable_time_check    = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_login_time', 1 ) );
		$time_threshold_days   = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_last_login_more_then_time', 15 );
		$day_difference       = $this->get_day_difference( gmdate( 'Y-m-d' ), $user_last_login_time );

		if ( $enable_time_check && $day_difference > $time_threshold_days ) {
			return true;
		}

		$enable_device_check = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_new_device', 1 ) );
		if ( $enable_device_check ) {
			$last_device    = isset( $user_last_login_details['last_login_device'] ) ? $user_last_login_details['last_login_device'] : '';
			$current_device = isset( $login_details['last_login_device'] ) ? $login_details['last_login_device'] : '';
			
			// If no previous device data exists (first login or missing data), trigger OTP.
			if ( empty( $last_device ) ) {
				return true;
			}
			
			// If device changed, trigger OTP.
			if ( ! empty( $current_device ) && $current_device !== $last_device ) {
				return true;
			}
		}

		$enable_location_check = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_new_location', 1 ) );
		if ( $enable_location_check ) {
			$last_postal    = isset( $user_last_login_details['last_login_postal'] ) ? $user_last_login_details['last_login_postal'] : '';
			$current_postal = isset( $login_details['last_login_postal'] ) ? $login_details['last_login_postal'] : '';
			
			// If no previous location data exists (first login or missing data), trigger OTP.
			if ( empty( $last_postal ) ) {
				return true;
			}
			
			// If location changed, trigger OTP.
			if ( ! empty( $current_postal ) && $current_postal !== $last_postal ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Determine if authentication email should be sent.
	 *
	 * @param array  $login_details        Current login details.
	 * @param array  $user_last_login_details Last login details.
	 * @param string $user_last_login_time Last login time.
	 * @return bool
	 */
	private function should_send_authentication_email( $user_id, $login_details, $user_last_login_details, $user_last_login_time ) {
		// Smart suspicious-login detection replaces the fixed conditions below
		// with a risk score when the merchant has enabled it.
		if ( $this->smart_detection_enabled() ) {
			return $this->smart_should_challenge( $user_id, $login_details, $user_last_login_time );
		}

		// Ensure user_last_login_details is an array.
		if ( ! is_array( $user_last_login_details ) ) {
			$user_last_login_details = array();
		}

		$enable_time_check    = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_login_time', 1 ) );
		$time_threshold_days   = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_last_login_more_then_time', 15 );
		$day_difference       = $this->get_day_difference( gmdate( 'Y-m-d' ), $user_last_login_time );

		if ( $enable_time_check && $day_difference > $time_threshold_days ) {
			return true;
		}

		$enable_device_check = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_new_device', 1 ) );
		if ( $enable_device_check ) {
			$last_device    = isset( $user_last_login_details['last_login_device'] ) ? $user_last_login_details['last_login_device'] : '';
			$current_device = isset( $login_details['last_login_device'] ) ? $login_details['last_login_device'] : '';
			
			// If no previous device data exists (first login or missing data), trigger email.
			if ( empty( $last_device ) ) {
				return true;
			}
			
			// If device changed, trigger email.
			if ( ! empty( $current_device ) && $current_device !== $last_device ) {
				return true;
			}
		}

		$enable_location_check = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'enable_email_auth_for_new_location', 1 ) );
		if ( $enable_location_check ) {
			$last_postal    = isset( $user_last_login_details['last_login_postal'] ) ? $user_last_login_details['last_login_postal'] : '';
			$current_postal = isset( $login_details['last_login_postal'] ) ? $login_details['last_login_postal'] : '';
			
			// If no previous location data exists (first login or missing data), trigger email.
			if ( empty( $last_postal ) ) {
				return true;
			}
			
			// If location changed, trigger email.
			if ( ! empty( $current_postal ) && $current_postal !== $last_postal ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Send and store login OTP.
	 *
	 * @param int    $user_id      User ID.
	 * @param string $user_email   User email address.
	 * @param array  $login_details Login details.
	 * @return void
	 */
	private function send_and_store_login_otp( $user_id, $user_email, $login_details ) {
		$login_otp = cev_pro()->function->generate_verification_pin();

		update_user_meta( $user_id, 'cev_login_otp', $login_otp );
		update_user_meta( $user_id, 'cev_login_otp_required', '1' );

		// Save login details even when OTP is required, so we have a record for comparison.
		// These will be updated again after OTP verification to ensure accuracy.
		$this->update_user_login_details( $user_id, $login_details );

		$email_common = cev_pro()->function;
		$email_common->wuev_user_id  = $user_id;
		$email_common->email_type    = 'login_otp';
		$email_common->login_ip      = isset( $login_details['last_login_ip'] ) ? $login_details['last_login_ip'] : '';
		$email_common->login_time    = current_time( 'mysql' );
		$email_common->login_browser = isset( $login_details['last_login_browser'] ) ? $login_details['last_login_browser'] : '';
		$email_common->login_device  = isset( $login_details['last_login_device'] ) ? $login_details['last_login_device'] : '';

		$this->send_login_otp_email( $user_email, $login_otp );
	}

	/**
	 * Get current login details (IP, device, browser, location).
	 *
	 * @return array Login details array or empty array on failure.
	 */
	public function get_current_login_details() {
		$user_ip        = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$user_agent     = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		
		// If no IP or user agent, return empty array.
		if ( empty( $user_ip ) && empty( $user_agent ) ) {
			return array();
		}
		
		$parsed_details = $this->cev_parse_user_agent( $user_agent );

		$login_device  = isset( $parsed_details['platform'] ) ? $parsed_details['platform'] : '';
		$login_browser = isset( $parsed_details['browser'] ) ? $parsed_details['browser'] : '';

		// Try to get location data, but don't fail if it's unavailable.
		$location_data = $this->get_location_data( $user_ip );
		
		// Build login details array even if location data is unavailable.
		$login_details = array(
			'last_login_device'  => $login_device,
			'last_login_browser' => $login_browser,
			'last_login_ip'      => $user_ip,
			'last_login_city'    => '',
			'last_login_region'  => '',
			'last_login_country' => '',
			'last_login_postal'  => '',
		);
		
		// Add location data if available.
		if ( false !== $location_data && is_object( $location_data ) ) {
			$login_details['last_login_city']    = isset( $location_data->city ) ? $location_data->city : '';
			$login_details['last_login_region']  = isset( $location_data->region ) ? $location_data->region : '';
			$login_details['last_login_country'] = isset( $location_data->country ) ? $location_data->country : '';
			$login_details['last_login_postal']  = isset( $location_data->postal ) ? $location_data->postal : '';
		}

		return $login_details;
	}

	/**
	 * Get location data from IP address.
	 *
	 * @param string $ip_address IP address.
	 * @return object|false Location data object or false on failure.
	 */
	private function get_location_data( $ip_address ) {
		if ( empty( $ip_address ) ) {
			return false;
		}

		$url      = esc_url_raw( "http://ipinfo.io/{$ip_address}/json" );
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 5,
				'sslverify'   => false,
				'httpversion' => '1.1',
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		if ( empty( $body ) ) {
			return false;
		}

		$data = json_decode( $body );
		if ( null === $data ) {
			return false;
		}

		return $data;
	}

	/**
	 * Update user login details in user meta.
	 *
	 * @param int   $user_id       User ID.
	 * @param array $login_details Login details array.
	 * @return void
	 */
	public function update_user_login_details( $user_id, $login_details ) {
		update_user_meta( $user_id, 'cev_last_login_detail', $login_details );
		update_user_meta( $user_id, 'cev_last_login_time', current_time( 'mysql' ) );

		// Record this device/location as "known" so Smart detection can trust
		// it on future logins. Runs on every accepted login (unchallenged, or
		// after a successful OTP), so a verified device becomes trusted.
		$this->remember_login_profile( $user_id, $login_details );
	}

	/**
	 * Whether Smart suspicious-login detection is enabled.
	 *
	 * @since 3.0.2
	 * @return bool
	 */
	private function smart_detection_enabled() {
		return 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_login_detection', 0 );
	}

	/**
	 * Risk-score threshold for the configured sensitivity. A login is
	 * challenged when its score reaches this value.
	 *
	 * @since 3.0.2
	 * @return int
	 */
	private function smart_sensitivity_threshold() {
		$sensitivity = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_login_sensitivity', 'balanced' );
		$map         = array(
			'low'      => 70, // Only clearly risky sign-ins.
			'balanced' => 50,
			'strict'   => 30, // Challenge on weaker signals.
		);
		$threshold = isset( $map[ $sensitivity ] ) ? $map[ $sensitivity ] : 50;

		/**
		 * Filter the Smart-detection challenge threshold.
		 *
		 * @since 3.0.2
		 * @param int    $threshold   Score at or above which a login is challenged.
		 * @param string $sensitivity Configured sensitivity (low|balanced|strict).
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the audit doesn't honour the phpcs.xml prefix registration.
		return (int) apply_filters( 'cev_login_risk_threshold', $threshold, $sensitivity );
	}

	/**
	 * A family-level (version-tolerant) fingerprint for the current device,
	 * built from the parsed platform + browser so a minor browser update is
	 * not treated as a brand-new device.
	 *
	 * @since 3.0.2
	 * @param array $login_details Current login details.
	 * @return string
	 */
	private function login_fingerprint( $login_details ) {
		$device  = isset( $login_details['last_login_device'] ) ? (string) $login_details['last_login_device'] : '';
		$browser = isset( $login_details['last_login_browser'] ) ? (string) $login_details['last_login_browser'] : '';
		return md5( strtolower( $device . '|' . $browser ) );
	}

	/**
	 * Compute the risk score + reasons for the current login.
	 *
	 * Weighted signals (all server-side, no external service):
	 *   - Unknown device fingerprint                  +50
	 *   - New country (never seen before)             +35
	 *   - Several failed passwords before success     +40
	 *   - Long idle period since the last login       +15
	 *
	 * @since 3.0.2
	 * @param int    $user_id              User ID.
	 * @param array  $login_details        Current login details.
	 * @param array  $known_profiles       The user's known device/location profiles.
	 * @param string $user_last_login_time Last login time (mysql).
	 * @return array { score:int, reasons:string[] }
	 */
	public function calculate_login_risk( $user_id, $login_details, $known_profiles, $user_last_login_time ) {
		$reasons = array();
		$score   = 0;

		if ( ! is_array( $known_profiles ) ) {
			$known_profiles = array();
		}

		$fingerprint = $this->login_fingerprint( $login_details );
		$country     = isset( $login_details['last_login_country'] ) ? (string) $login_details['last_login_country'] : '';

		$known_device  = false;
		$known_country = false;
		foreach ( $known_profiles as $profile ) {
			if ( isset( $profile['fp'] ) && $profile['fp'] === $fingerprint ) {
				$known_device = true;
			}
			if ( '' !== $country && isset( $profile['country'] ) && $profile['country'] === $country ) {
				$known_country = true;
			}
		}

		// New / unknown device.
		if ( ! $known_device ) {
			$score    += 50;
			$reasons[] = 'new_device';
		}

		// New country (only meaningful when geolocation is available).
		if ( '' !== $country && ! $known_country ) {
			$score    += 35;
			$reasons[] = 'new_country';
		}

		// A burst of failed passwords right before this success (credential stuffing).
		$failed_attempts = $this->recent_failed_login_count( $user_id );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the audit doesn't honour the phpcs.xml prefix registration.
		$fail_threshold  = (int) apply_filters( 'cev_login_risk_failed_threshold', 3 );
		if ( $failed_attempts >= $fail_threshold ) {
			$score    += 40;
			$reasons[] = 'failed_attempts';
		}

		// Long idle period.
		$idle_days      = $this->get_day_difference( gmdate( 'Y-m-d' ), $user_last_login_time );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the audit doesn't honour the phpcs.xml prefix registration.
		$idle_threshold = (int) apply_filters( 'cev_login_risk_idle_days', 60 );
		if ( $idle_days > $idle_threshold ) {
			$score    += 15;
			$reasons[] = 'long_idle';
		}

		$result = array(
			'score'   => (int) $score,
			'reasons' => $reasons,
		);

		/**
		 * Filter the computed login-risk result (score + reasons).
		 *
		 * @since 3.0.2
		 * @param array $result         { score:int, reasons:string[] }.
		 * @param int   $user_id        User ID.
		 * @param array $login_details  Current login details.
		 * @param array $known_profiles Known device/location profiles.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the audit doesn't honour the phpcs.xml prefix registration.
		return apply_filters( 'cev_login_risk', $result, $user_id, $login_details, $known_profiles );
	}

	/**
	 * Smart decision: should this login be challenged?
	 *
	 * The very first login (no known profiles yet) is enrolled silently — there
	 * is nothing to compare it against — so it is never challenged.
	 *
	 * @since 3.0.2
	 * @param int    $user_id              User ID.
	 * @param array  $login_details        Current login details.
	 * @param string $user_last_login_time Last login time (mysql).
	 * @return bool
	 */
	private function smart_should_challenge( $user_id, $login_details, $user_last_login_time ) {
		$known_profiles = get_user_meta( $user_id, 'cev_login_known_profiles', true );

		// First-ever login (or no history): enroll silently, do not challenge.
		if ( empty( $known_profiles ) || ! is_array( $known_profiles ) ) {
			return false;
		}

		$risk      = $this->calculate_login_risk( $user_id, $login_details, $known_profiles, $user_last_login_time );
		$challenge = ( $risk['score'] >= $this->smart_sensitivity_threshold() );

		// Analytics: log the challenge decision (best-effort; only when we act).
		if ( $challenge && method_exists( cev_pro()->function, 'log_event' ) ) {
			$user  = get_user_by( 'id', $user_id );
			$email = ( $user instanceof WP_User ) ? $user->user_email : '';
			cev_pro()->function->log_event(
				$email,
				'login_risk_challenge',
				'login',
				array(
					'score'   => $risk['score'],
					'reasons' => $risk['reasons'],
				),
				$user_id
			);
		}

		return (bool) $challenge;
	}

	/**
	 * Remember the current device/location as a known profile (rolling list).
	 *
	 * Upserts by fingerprint + country, prunes profiles unseen for 90 days,
	 * and caps the list to the 10 most-recent so trust decays over time.
	 *
	 * @since 3.0.2
	 * @param int   $user_id       User ID.
	 * @param array $login_details Current login details.
	 * @return void
	 */
	private function remember_login_profile( $user_id, $login_details ) {
		if ( empty( $login_details ) || ! is_array( $login_details ) ) {
			return;
		}

		$fingerprint = $this->login_fingerprint( $login_details );
		$country     = isset( $login_details['last_login_country'] ) ? (string) $login_details['last_login_country'] : '';
		$city        = isset( $login_details['last_login_city'] ) ? (string) $login_details['last_login_city'] : '';
		$now         = current_time( 'mysql' );

		$profiles = get_user_meta( $user_id, 'cev_login_known_profiles', true );
		if ( ! is_array( $profiles ) ) {
			$profiles = array();
		}

		// Drop profiles not seen for 90 days so old trust expires.
		$cutoff   = strtotime( '-90 days' );
		$profiles = array_values(
			array_filter(
				$profiles,
				function ( $profile ) use ( $cutoff ) {
					$seen = ( isset( $profile['last_seen'] ) ) ? strtotime( $profile['last_seen'] ) : 0;
					return $seen && $seen >= $cutoff;
				}
			)
		);

		// Upsert by fingerprint + country.
		$found = false;
		foreach ( $profiles as $index => $profile ) {
			if ( isset( $profile['fp'], $profile['country'] ) && $profile['fp'] === $fingerprint && $profile['country'] === $country ) {
				$profiles[ $index ]['last_seen'] = $now;
				$profiles[ $index ]['city']      = $city;
				$profiles[ $index ]['count']     = ( isset( $profile['count'] ) ? (int) $profile['count'] : 0 ) + 1;
				$found                           = true;
				break;
			}
		}

		if ( ! $found ) {
			array_unshift(
				$profiles,
				array(
					'fp'        => $fingerprint,
					'country'   => $country,
					'city'      => $city,
					'last_seen' => $now,
					'count'     => 1,
				)
			);
		}

		// Cap to the 10 most-recent profiles.
		if ( 10 < count( $profiles ) ) {
			$profiles = array_slice( $profiles, 0, 10 );
		}

		update_user_meta( $user_id, 'cev_login_known_profiles', $profiles );
	}

	/**
	 * Increment the short-lived failed-password counter for the typed username.
	 * Hooked to wp_login_failed only when Smart detection is enabled.
	 *
	 * @since 3.0.2
	 * @param string $username The username/email that failed to authenticate.
	 * @return void
	 */
	public function record_failed_login_attempt( $username ) {
		if ( ! is_string( $username ) || '' === $username ) {
			return;
		}
		$key   = 'cev_login_pw_failed_' . md5( strtolower( $username ) );
		$count = (int) get_transient( $key );
		set_transient( $key, $count + 1, 15 * MINUTE_IN_SECONDS );
	}

	/**
	 * Recent failed-password attempts for a user, checked against both the
	 * user_login and the email (the visitor may have typed either).
	 *
	 * @since 3.0.2
	 * @param int $user_id User ID.
	 * @return int
	 */
	private function recent_failed_login_count( $user_id ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return 0;
		}
		$count = 0;
		foreach ( array( $user->user_login, $user->user_email ) as $identifier ) {
			if ( '' === (string) $identifier ) {
				continue;
			}
			$count = max( $count, (int) get_transient( 'cev_login_pw_failed_' . md5( strtolower( $identifier ) ) ) );
		}
		return $count;
	}

	/**
	 * Clear the failed-password counter for a user after a completed login.
	 *
	 * @since 3.0.2
	 * @param int $user_id User ID.
	 * @return void
	 */
	private function clear_failed_login_count( $user_id ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return;
		}
		foreach ( array( $user->user_login, $user->user_email ) as $identifier ) {
			if ( '' === (string) $identifier ) {
				continue;
			}
			delete_transient( 'cev_login_pw_failed_' . md5( strtolower( $identifier ) ) );
		}
	}

	/**
	 * Get day difference between two dates.
	 *
	 * @param string $current_date    Current date in Y-m-d format.
	 * @param string $last_login_date Last login date.
	 * @return int Day difference (positive or negative).
	 */
	public function get_day_difference( $current_date, $last_login_date ) {
		if ( empty( $last_login_date ) ) {
			return 999; // Return large number if no last login date.
		}

		$date1 = date_create( $last_login_date );
		$date2 = date_create( $current_date );

		if ( false === $date1 || false === $date2 ) {
			return 999;
		}

		$diff = date_diff( $date1, $date2 );
		return (int) $diff->format( '%R%a' );
	}

	/**
	 * Send login OTP email.
	 *
	 * @param string $recipient Recipient email address.
	 * @param string $login_otp Login OTP code.
	 * @return bool|null True when wp_mail() accepted the message, false when it
	 *                   did not, null when the send was skipped.
	 */
	public function send_login_otp_email( $recipient, $login_otp ) {
		if ( empty( $recipient ) || ! is_email( $recipient ) ) {
			return null;
		}

		$email_common = cev_pro()->function;
		// Expose login OTP on context so {cev_user_verification_pin} (and legacy {login_otp}) merge tags work.
		$email_common->login_otp = $login_otp;

		// Translate into the recipient's language (Polylang; no-op otherwise).
		$cev_lang = cev_pro()->function->cev_pro_recipient_language( 0, $recipient );

		$email_subject = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_login_otp_email_subject', cev_pro()->customizer_options->defaults['cev_verification_login_otp_email_subject'] );
		$email_subject = cev_pro()->function->cev_pro_translate_string( $email_subject, $cev_lang );
		$email_subject = cev_pro()->function->maybe_parse_merge_tags( $email_subject, $email_common );

		$email_heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_login_otp_email_heading', cev_pro()->customizer_options->defaults['cev_verification_login_otp_email_heading'] );
		$email_heading = cev_pro()->function->cev_pro_translate_string( $email_heading, $cev_lang );
		$email_heading = cev_pro()->function->maybe_parse_merge_tags( $email_heading, $email_common );

		$email_content = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_login_otp_email_content', cev_pro()->customizer_options->defaults['cev_verification_login_otp_email_content'] );
		$email_content = cev_pro()->function->cev_pro_translate_string( $email_content, $cev_lang );
		$email_content = cev_pro()->function->maybe_parse_merge_tags( $email_content, $email_common );

		$footer_content = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_otp_footer_content', cev_pro()->customizer_options->defaults['cev_login_otp_footer_content'] );
		$footer_content = cev_pro()->function->cev_pro_translate_string( $footer_content, $cev_lang );

		$mailer = WC()->mailer();
		$email  = new WC_Email();
		$email->id = 'CEV_Login_OTP';

		$template_path = $this->get_email_template_path();
		$template_args = array(
			'email_heading'  => $email_heading,
			'content'        => $email_content,
			'footer_content' => $footer_content,
			'login_otp'      => $login_otp,
		);

		ob_start();
		wc_get_template( 'emails/cev-login-authentication.php', $template_args, 'customer-email-verification/', $template_path );
		$content = ob_get_clean();

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		$message = apply_filters( 'woocommerce_mail_content', $email->style_inline( $mailer->wrap_message( $email_heading, $content ) ) );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned filter (legacy wc_cev_ prefix); renaming would break sites already hooking it.
		$message = apply_filters( 'wc_cev_decode_html_content', $message );

		add_filter( 'wp_mail_from', array( cev_pro()->function, 'get_from_address' ) );
		add_filter( 'wp_mail_from_name', array( cev_pro()->function, 'get_from_name' ) );

		$result = wp_mail( $recipient, $email_subject, $message, $email->get_headers() );

		remove_filter( 'wp_mail_from', array( cev_pro()->function, 'get_from_address' ) );
		remove_filter( 'wp_mail_from_name', array( cev_pro()->function, 'get_from_name' ) );

		// Analytics: record the login-time OTP send.
		if ( method_exists( cev_pro()->function, 'log_event' ) ) {
			cev_pro()->function->log_event( $recipient, 'otp_sent', 'login_auth' );
		}

		return $result;
	}

	/**
	 * Send login authentication email.
	 *
	 * @param int    $user_id   User ID.
	 * @param string $recipient Recipient email address.
	 * @return void
	 */
	public function send_login_authentication_email( $user_id, $recipient ) {
		if ( empty( $recipient ) || ! is_email( $recipient ) ) {
			return;
		}

		$email_common = cev_pro()->function;
		$email_common->email_type  = 'login_authentication';
		$email_common->wuev_user_id = $user_id;

		// Translate into the recipient's language (Polylang; no-op otherwise).
		$cev_lang = cev_pro()->function->cev_pro_recipient_language( $user_id, $recipient );

		$email_subject = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_login_auth_email_subject', cev_pro()->customizer_options->defaults['cev_verification_login_auth_email_subject'] );
		$email_subject = cev_pro()->function->cev_pro_translate_string( $email_subject, $cev_lang );
		$email_subject = cev_pro()->function->maybe_parse_merge_tags( $email_subject, $email_common );

		$email_heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_login_auth_email_heading', cev_pro()->customizer_options->defaults['cev_verification_login_auth_email_heading'] );
		$email_heading = cev_pro()->function->cev_pro_translate_string( $email_heading, $cev_lang );
		$email_heading = cev_pro()->function->maybe_parse_merge_tags( $email_heading, $email_common );

		$email_content = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_login_auth_email_content', cev_pro()->customizer_options->defaults['cev_verification_login_auth_email_content'] );
		$email_content = cev_pro()->function->cev_pro_translate_string( $email_content, $cev_lang );
		$email_content = cev_pro()->function->maybe_parse_merge_tags( $email_content, $email_common );

		$footer_content = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_footer_content', cev_pro()->customizer_options->defaults['cev_login_auth_footer_content'] );
		$footer_content = cev_pro()->function->cev_pro_translate_string( $footer_content, $cev_lang );

		$mailer = WC()->mailer();
		$email  = new WC_Email();
		$email->id = 'CEV_Login_Authentication';

		$template_path = $this->get_email_template_path();
		$template_args = array(
			'email_heading'  => $email_heading,
			'content'        => $email_content,
			'footer_content' => $footer_content,
			'login_otp'      => '',
		);

		ob_start();
		wc_get_template( 'emails/cev-login-authentication.php', $template_args, 'customer-email-verification/', $template_path );
		$content = ob_get_clean();

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		$message = apply_filters( 'woocommerce_mail_content', $email->style_inline( $mailer->wrap_message( $email_heading, $content ) ) );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned filter (legacy wc_cev_ prefix); renaming would break sites already hooking it.
		$message = apply_filters( 'wc_cev_decode_html_content', $message );

		add_filter( 'wp_mail_from', array( cev_pro()->function, 'get_from_address' ) );
		add_filter( 'wp_mail_from_name', array( cev_pro()->function, 'get_from_name' ) );

		wp_mail( $recipient, $email_subject, $message, $email->get_headers() );
	}

	/**
	 * Get email template path (local or plugin default).
	 *
	 * @return string Template path.
	 */
	private function get_email_template_path() {
		$local_template = get_stylesheet_directory() . '/woocommerce/emails/cev-login-authentication.php';

		if ( file_exists( $local_template ) ) {
			return get_stylesheet_directory() . '/woocommerce/';
		}

		return cev_pro()->get_plugin_path() . '/templates/';
	}

	/**
	 * Check user and redirect to endpoint if OTP required.
	 *
	 * @return void
	 */
	public function check_user_and_redirect_to_endpoint() {
		if ( ! is_account_page() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$user = get_user_by( 'id', get_current_user_id() );
		if ( ! $user ) {
			return;
		}

		$user_id    = $user->ID;
		$user_email = $user->user_email;

		// Mirrors the wp_login gate: an unverified customer reaches the OTP
		// screen when the merchant asked for a code on every login, or asked
		// unverified customers to verify.
		$verified = cev_pro()->function->check_email_verify( $user_email );
		if ( false === $verified && ! $this->challenges_unverified_login( $user_id ) ) {
			return;
		}

		$login_authentication_enabled = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_login_authentication', 0 ) );
		$email_otp_enabled           = $this->is_email_otp_flow_enabled() || false === $verified;

		if ( ! $login_authentication_enabled || ! $email_otp_enabled ) {
			return;
		}

		// Legacy skip — Administrator + Editor are exempt from email-OTP
		// login auth (the 2FA section's role policy gates Authenticator App
		// only, not this flow).
		if ( cev_pro()->admin->is_admin_user( $user_id ) ) {
			return;
		}

		$login_otp_required = get_user_meta( get_current_user_id(), 'cev_login_otp_required', true );
		if ( empty( $login_otp_required ) || ( '1' !== $login_otp_required && true !== $login_otp_required && 1 !== $login_otp_required ) ) {
			return;
		}

		// SECURITY: do NOT exempt the redirect just because no OTP is
		// currently stored. `cev_login_otp` is deleted after 5 wrong
		// attempts (class-cev-login-authentication-ajax.php) while
		// `cev_login_otp_required` is deliberately left set — that flag,
		// not the presence of a code, is what "still needs to verify"
		// means. The endpoint page (cev_login_authentication_endpoint_content()
		// below) never required a stored OTP to render either; it already
		// offers a resend. Returning early here let a customer who
		// exhausted their attempts browse the rest of the account pages
		// without ever completing login OTP.
		global $wp;
		$logout_url              = wc_get_account_endpoint_url( 'customer-logout' );
		$logout_url              = strtok( $logout_url, '?' );
		$logout_url              = rtrim( strtok( $logout_url, '?' ), '/' );
		$login_authentication_url = rtrim( wc_get_account_endpoint_url( 'login-authentication' ), '/' );
		$current_url              = rtrim( home_url( $wp->request ), '/' );

		if ( $current_url === $logout_url ) {
			return;
		}

		if ( $current_url !== $login_authentication_url ) {
			$redirect_url = wc_get_account_endpoint_url( 'login-authentication' );
			wp_safe_redirect( $redirect_url );
			exit;
		}
	}

	/**
	 * Information content for login authentication endpoint.
	 *
	 * @return void
	 */
	public function cev_login_authentication_endpoint_content() {
		$current_user = wp_get_current_user();
		if ( ! $current_user || ! $current_user->exists() ) {
			return;
		}

		$user_id = get_current_user_id();
		// Legacy skip for email-OTP login auth.
		if ( cev_pro()->admin->is_admin_user( $user_id ) ) {
			return;
		}

		$login_otp_required = get_user_meta( $user_id, 'cev_login_otp_required', true );
		if ( empty( $login_otp_required ) || ( '1' !== $login_otp_required && true !== $login_otp_required && 1 !== $login_otp_required ) ) {
			return;
		}

		$customizer_options = new CEV_Customizer_Options();
		$overlay_color      = get_option(
			'cev_verification_popup_overlay_background_color',
			$customizer_options->defaults['cev_verification_popup_overlay_background_color']
		);

		// Output inline styles.
		?>
		<style>
		.cev-authorization-grid__visual{
			background: <?php echo esc_attr( cev_pro()->function->hex2rgba( $overlay_color, '0.7' ) ); ?> !important;
		}
		</style>
		<?php

		// Load customizer options for template.
		$button_color              = cev_pro()->function->cev_pro_customizer_settings( 'cev_button_color_widget_header', '#212121' );
		$button_text_color         = cev_pro()->function->cev_pro_customizer_settings( 'cev_button_text_color_widget_header', '#ffffff' );
		$widget_header_image_width = cev_pro()->function->cev_pro_customizer_settings( 'cev_widget_header_image_width', '80' );
		$button_text_font_size     = cev_pro()->function->cev_pro_customizer_settings( 'cev_button_text_header_font_size', '22' );
		$toggle_switch             = cev_pro()->function->cev_pro_customizer_settings( 'sample_toggle_switch_cev', $customizer_options->defaults['sample_toggle_switch_cev'] );

		$popup_button_size         = cev_pro()->function->cev_pro_customizer_settings( 'cev_popup_button_size', $customizer_options->defaults['cev_popup_button_size'] );
		$button_text_size_header   = ( 'large' === $popup_button_size ) ? 18 : 16;
		$button_padding             = ( 'large' === $popup_button_size ) ? '15px 25px' : '12px 20px';

		$template_path = cev_pro()->get_plugin_path() . '/includes/login-authentication/views/popup-template.php';
		if ( file_exists( $template_path ) ) {
			require_once $template_path;
		}
	}

	/**
	 * Resend login OTP email.
	 *
	 * @return void
	 */
	public function cev_resend_login_otp_email() {
		// Read the parameter once, on its own statement, so the previous-line
		// phpcs:ignore reliably covers it. A superglobal nested inside a
		// multi-condition if() is not covered on some audit-server PHPCS
		// versions. There is no nonce here by design: this is a link mailed to
		// the customer, and the value is validated as the CURRENT user's own id
		// below before anything happens.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$encoded_user_id = isset( $_GET['cev_resend_login_otp_email'] ) ? sanitize_text_field( wp_unslash( $_GET['cev_resend_login_otp_email'] ) ) : '';

		if ( '' === $encoded_user_id ) {
			return;
		}

		$user_id         = base64_decode( $encoded_user_id ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

		if ( empty( $user_id ) || ! is_numeric( $user_id ) ) {
			return;
		}

		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return;
		}

		// Check if user is logged in and matches the user ID.
		if ( ! is_user_logged_in() || get_current_user_id() !== (int) $user_id ) {
			return;
		}

		$user_email = $user->user_email;

		$cev_session = WC()->session;
		if ( method_exists( $cev_session, 'has_session' )
			&& method_exists( $cev_session, 'set_customer_session_cookie' )
			&& false === $cev_session->has_session()
		) {
			$cev_session->set_customer_session_cookie( true );
		}

		$login_otp         = get_user_meta( $user_id, 'cev_login_otp', true );
		$login_otp_required = get_user_meta( $user_id, 'cev_login_otp_required', true );

		// Check if OTP is required and exists.
		if ( empty( $login_otp_required ) || ( '1' !== $login_otp_required && true !== $login_otp_required && 1 !== $login_otp_required ) ) {
			return;
		}

		if ( empty( $login_otp ) ) {
			return;
		}

		// Prevent duplicate sends within 2 minutes using transient.
		$transient_key = 'cev_resend_login_otp_' . $user_id;
		$last_sent = get_transient( $transient_key );
		
		if ( false !== $last_sent ) {
			// Email was sent recently, don't send again.
			return;
		}

		// Send the email.
		$email_sent = $this->send_login_otp_email( $user_email, $login_otp );
		
		if ( $email_sent ) {
			// Set transient to prevent duplicate sends for 2 minutes (120 seconds).
			set_transient( $transient_key, time(), 120 );
			
			$message = __( 'A new login OTP email is sent.', 'customer-email-verification' );
			wc_add_notice( $message, 'notice' );
		}
	}


	/**
	 * Parse user agent string to extract browser and platform information.
	 *
	 * @param string|null $user_agent User agent string.
	 * @return array<string, string|null> Parsed user agent data with 'platform', 'browser', and 'version' keys.
	 */
	public function cev_parse_user_agent( $user_agent = null ) {
		$platform = null;
		$browser  = null;
		$version  = '';

		if ( empty( $user_agent ) ) {
			return array(
				'platform' => $platform,
				'browser'  => $browser,
				'version'  => $version,
			);
		}

		// Detect browser.
		foreach ( $this->basic_browser as $pattern => $name ) {
			if ( preg_match( '/' . preg_quote( $pattern, '/' ) . '/i', $user_agent, $match ) ) {
				$browser = $name;

				// Extract version number.
				$known_patterns = array( 'Version', $pattern, 'other' );
				$version_pattern = '#(?<browser>' . join( '|', $known_patterns ) . ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';

				if ( preg_match_all( $version_pattern, $user_agent, $matches ) ) {
					$match_count = count( $matches['browser'] );

					if ( 1 === $match_count ) {
						$version = $matches['version'][0];
					} else {
						// Determine if version appears before or after browser name.
						$version_pos = strripos( $user_agent, 'Version' );
						$pattern_pos = strripos( $user_agent, $pattern );

						if ( false !== $version_pos && false !== $pattern_pos ) {
							$version = ( $version_pos < $pattern_pos ) ? $matches['version'][0] : $matches['version'][1];
						} else {
							$version = $matches['version'][0];
						}
					}
				}

				break;
			}
		}

		// Detect platform.
		foreach ( $this->basic_platform as $key => $platform_name ) {
			if ( stripos( $user_agent, $key ) !== false ) {
				$platform = $platform_name;
				break;
			}
		}

		return array(
			'platform' => $platform,
			'browser'  => $browser,
			'version'  => $version,
		);
	}

	/**
	 * Filter callback for login authentication message.
	 *
	 * @since 1.0.0
	 * @param string $message Default message text.
	 * @param string $email   Email address.
	 * @return string Filtered message.
	 */
	public function cev_login_auth_message_callback( $message, $email ) {
		$message_text = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_message', $message );
		$message_text = str_replace( '{customer_email}', $email, $message_text );

		if ( '' !== $message_text ) {
			return $message_text;
		}

		return $message;
	}
}
