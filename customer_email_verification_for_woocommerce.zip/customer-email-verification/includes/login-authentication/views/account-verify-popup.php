<?php
/**
 * Account verification popup for logged-in unverified customers.
 *
 * Reuses the registration popup design (the `.cev-authorization` card styled
 * by signup-style.css) and its own Customizer "Account Verification Popup"
 * content settings, so it matches the registration / login popups and is
 * editable in the Customizer. Wired to the cev_account_send_code /
 * cev_account_verify_code AJAX via account-verify.js.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 *
 * @var string $cev_av_email Current user's email address.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$cev_customizer_options = new CEV_Customizer_Options();
$defaults               = ( is_object( $cev_customizer_options ) && isset( $cev_customizer_options->defaults ) && is_array( $cev_customizer_options->defaults ) ) ? $cev_customizer_options->defaults : array();

// Shared popup STYLE settings — emitted once as design tokens on the root
// element below. See CEV_Functions_Pro::popup_style_tokens().
$cev_popup_style = cev_pro()->function->popup_style_attr();

// Account-Verification-specific CONTENT settings (its own Popup Type).
$heading_text = cev_pro()->function->cev_pro_customizer_settings( 'cev_account_verify_header', isset( $defaults['cev_account_verify_header'] ) ? $defaults['cev_account_verify_header'] : __( 'Verify your email', 'customer-email-verification' ) );
$heading_text = cev_pro()->function->cev_pro_translate_string( $heading_text );
if ( '' === $heading_text ) {
	$heading_text = __( 'Verify your email', 'customer-email-verification' );
}

$verification_message = cev_pro()->function->cev_pro_customizer_settings( 'cev_account_verify_message', isset( $defaults['cev_account_verify_message'] ) ? $defaults['cev_account_verify_message'] : '' );
$verification_message = cev_pro()->function->cev_pro_translate_string( $verification_message );
$verification_message = cev_pro()->function->maybe_parse_merge_tags( $verification_message, cev_pro()->function );
$verification_message = str_replace( '{customer_email}', '<strong>' . esc_html( $cev_av_email ) . '</strong>', $verification_message );

$footer_message = cev_pro()->function->cev_pro_customizer_settings( 'cev_account_verify_footer', isset( $defaults['cev_account_verify_footer'] ) ? $defaults['cev_account_verify_footer'] : '' );
$footer_message = cev_pro()->function->cev_pro_translate_string( $footer_message );
if ( ! empty( $footer_message ) ) {
	$footer_message = cev_pro()->function->maybe_parse_merge_tags( $footer_message, cev_pro()->function );
}

$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
$otp_digits  = ( '2' === (string) $code_length ) ? 6 : 4;

// Verify Button visibility (Customizer → Popup Style). 'hide' (default) keeps
// the auto-verify-on-last-digit behaviour; 'show' renders a Verify button the
// customer must click (auto-verify is disabled in account-verify.js).
$cev_av_show_verify_button = ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', isset( $defaults['cev_show_verify_button'] ) ? $defaults['cev_show_verify_button'] : 'hide' ) );
?>
<div id="cev-account-verify" class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>" role="dialog" aria-modal="true" aria-labelledby="cev-av-title">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">
				<section class="cev-authorization__holder">
					<?php
					// Popup header — mark, or the merchant's Header Image. See
					// CEV_Functions_Pro::popup_header_html().
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
					echo cev_pro()->function->popup_header_html();
					?>

					<div class="cev-authorization__heading">
						<span id="cev-av-title" class="cev-authorization__title">
							<?php echo wp_kses_post( $heading_text ); ?>
						</span>
						<span class="cev-authorization__description">
							<?php echo wp_kses_post( $verification_message ); ?>
						</span>
					</div>

					<?php // OTP is auto-sent. With the Verify Button hidden (default) the boxes auto-verify when fully entered; with it shown the customer clicks to verify. ?>
					<div class="otp-container" role="group" aria-label="<?php esc_attr_e( 'Enter verification code', 'customer-email-verification' ); ?>">
						<?php for ( $i = 1; $i <= $otp_digits; $i++ ) : ?>
							<?php /* translators: %d: OTP digit position number */ ?>
							<input type="text" maxlength="1" class="otp-input cev-av-otp" placeholder=" " inputmode="numeric" autocomplete="one-time-code" aria-label="<?php echo esc_attr( sprintf( __( 'OTP digit %d', 'customer-email-verification' ), (int) $i ) ); ?>" />
						<?php endfor; ?>
					</div>

					<?php if ( $cev_av_show_verify_button ) : ?>
						<button type="button" data-cev-av="verify" class="cev-button cev-button_size_promo cev-button_type_block cev-verify-otp-visible" style="margin-top: 16px;">
							<?php esc_html_e( 'Verify', 'customer-email-verification' ); ?>
						</button>
					<?php endif; ?>

					<div class="cev-av-msg" data-cev-av="msg" role="alert" aria-live="polite"></div>

					<div class="cev-resend-section">
						<span class="cev_resend_timer" data-cev-av="timer"></span>
						<a href="#" data-cev-av="resend" class="cev_resend_link_front" style="display:none;">
							<?php esc_html_e( 'Resend code', 'customer-email-verification' ); ?>
						</a>
					</div>

					<?php if ( ! empty( $footer_message ) ) : ?>
						<footer class="cev-authorization__footer">
							<?php echo wp_kses_post( $footer_message ); ?>
						</footer>
					<?php endif; ?>
				</section>
			</div>
		</div>
	</div>
</div>
<div class="cev_loading_overlay" style="<?php echo esc_attr( $cev_popup_style ); ?>" aria-hidden="true"></div>
<?php
/*
 * The overlay tint is the --cev-popup-overlay token on the root above; it used
 * to be an !important background painted by an inline <style> block here.
 */
?>
