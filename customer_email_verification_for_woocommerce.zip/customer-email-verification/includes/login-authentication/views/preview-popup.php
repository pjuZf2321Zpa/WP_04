<?php
/**
 * Login Authentication Popup Preview Template
 *
 * Preview template for customizer.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$email = ( 'johny@example.com' );
$Try_again = __('Try again', 'customer-email-verification');
$CEV_Customizer_Options = new CEV_Customizer_Options();

$cev_login_hide_otp_section =  cev_pro()->function->cev_pro_customizer_settings('cev_login_hide_otp_section', $CEV_Customizer_Options->defaults['cev_login_hide_otp_section'] );
// Popup appearance is emitted once as design tokens on the root element
// below. Single source of truth: CEV_Functions_Pro::popup_style_tokens().
$cev_popup_style = cev_pro()->function->popup_style_attr();

?>

<div class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">				
				<form class="cev_login_authentication_form" method="post">    
					<section class="cev-authorization__holder">
						<?php
						// Popup header — the built-in mark, or the merchant's Header Image.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
						?>
						<div class="cev-authorization__heading">
							<span class="cev-authorization__title">
							<?php
								$heading_default = __('Verify its you.', 'customer-email-verification');
								$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_header', $CEV_Customizer_Options->defaults['cev_login_auth_header'] ); 
							if ( !empty($heading) ) { 
								echo wp_kses_post( $heading ); 
							} else {
								echo wp_kses_post( $heading_default ); 
							}
							?>
							</span>
							<span class="cev-authorization__description">
								<?php
								/* translators: %s: search customer email */
								$message = sprintf(__('We sent verification code to <strong>%s</strong>. To verify your email address, please check your inbox and enter the code below.', 'customer-email-verification'), $email); 
								// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
								$message = apply_filters( 'cev_login_auth_message', $message, $email );
								echo wp_kses_post( $message );
								?>
							</span>
						</div>
						<?php if ( 0 == $cev_login_hide_otp_section ) { ?>
								<div class="cev-pin-verification">		
									<div class="cev-pin-verification__row">
										<div class="cev-field cev-field_size_extra-large cev-field_icon_left cev-field_event_right cev-field_text_center">
											<h5 class="required-filed">
											<?php 
											// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
											echo wp_kses_post(apply_filters( 'cev_verification_code_length', __( '4-digit code', 'customer-email-verification' ) ) ); 
											?>
											*
											</h5>
											<?php 
												$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
											if ( '1' == $code_length ) {
												$digits = 4;
											} else if ( '2' == $code_length ) {
												$digits = 6;
											} else {
												// Default value in case $code_length is neither '1' nor '2'
												$digits = 4;
											}
											?>
										<div class="otp-container">
											<?php for ($i = 1; $i <= $digits; $i++) : ?>
												<input type="text" maxlength="1" class="otp-input" placeholder=" " id="<?php echo esc_attr('otp_input_' . $i); ?>" />
											<?php endfor; ?>
										</div>
									</div>
									<div class="cev-pin-verification__failure js-pincode-invalid" style="display: none;">
										<div class="cev-alert cev-alert_theme_red">										
											<span class="js-pincode-error-message"><?php esc_html_e('Verification code does not match', 'customer-email-verification'); ?></span>
										</div>
									</div>
									<div class="cev-pin-verification__events">
										<input type="hidden" name="cev_user_id" value="8">
										<input type="hidden" name="action" value="cev_verify_user_email_with_pin">
										<button class="cev-button  cev-button_size_promo cev-button_type_block cev-pin-verification__button is-disabled" type="submit" >
										<?php
										$verify_default = __('Verify Code', 'customer-email-verification');
										$verify = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_button_text', $CEV_Customizer_Options->defaults['cev_login_auth_button_text'] );
										if ( !empty($verify) ) { 
											echo wp_kses_post( $verify ); 
										} else {
											echo wp_kses_post( $verify_default );
										} 
										?>
										</button>									
									</div>
								</div>
							<?php } ?>
						<footer class="cev-authorization__footer">
							<?php
							/* translators: %s: search for footer customer resend link */
							$footer_message = sprintf( __( "Didn't receive an email? <strong>%s</strong>", 'customer-email-verification' ), $Try_again ); 
							$defaults = $CEV_Customizer_Options->defaults;
							$footer_message = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_widget_footer', $defaults['cev_login_auth_widget_footer'] );
							$footer_message = str_replace( '{cev_resend_verification}', $Try_again, $footer_message );
							echo wp_kses_post( $footer_message ); 
							?>
						</footer>
					</section>
				</form>
			</div>
		</div>
	</div>
</div>

