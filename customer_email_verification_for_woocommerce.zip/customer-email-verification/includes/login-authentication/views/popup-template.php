<?php
/**
 * Login Authentication Popup Template
 *
 * Template for displaying the login authentication OTP verification popup.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$CEV_Customizer_Options     = new CEV_Customizer_Options();
$cev_login_hide_otp_section = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_hide_otp_section', $CEV_Customizer_Options->defaults['cev_login_hide_otp_section'] );

// Popup appearance is emitted once as design tokens on the root element below
// (see CEV_Functions_Pro::popup_style_tokens) — colours, width, padding,
// alignment, heading size and the button size/width all live there. Do NOT
// re-read those keys here and re-emit them as inline style attributes.
$cev_popup_style = cev_pro()->function->popup_style_attr();

// Ensure $email is defined to avoid undefined variable notices in the message.
if ( ! isset( $email ) ) {
	$user = wp_get_current_user();
	$email = ( $user && $user->exists() ) ? $user->user_email : '';
}
?>
<div class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">
				<form class="cev_login_authentication_form" method="post">
					<section class="cev-authorization__holder">
						<?php
						// Popup header — the built-in mark, or the merchant's Header Image.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
						?>
						<div class="cev-authorization__heading">
							<span class="cev-authorization__title">
								<?php
								$heading_default = __('Verify its you.', 'customer-email-verification');
								$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_header', $CEV_Customizer_Options->defaults['cev_login_auth_header']);
								$heading = cev_pro()->function->cev_pro_translate_string( $heading );
								if ( !empty($heading) ) {
									echo wp_kses_post( $heading ); 
								} else {
									echo wp_kses_post( $heading_default ); 
								}
								?>
							</span>
							<span class="cev-authorization__description">
								<?php
								/*
								 * cev_login_auth_message is a registered Customizer setting with a
								 * shipped default, but this template hardcoded the copy with
								 * sprintf() and ignored it — so editing that field in the
								 * Customizer did nothing. Read the setting, fall back to the
								 * default, then swap {customer_email} for the address.
								 */
								$message = cev_pro()->function->cev_pro_customizer_settings(
									'cev_login_auth_message',
									isset( $CEV_Customizer_Options->defaults['cev_login_auth_message'] ) ? $CEV_Customizer_Options->defaults['cev_login_auth_message'] : ''
								);
								$message = cev_pro()->function->cev_pro_translate_string( $message );
								$message = cev_pro()->function->maybe_parse_merge_tags( $message, cev_pro()->function );

								if ( '' === trim( wp_strip_all_tags( (string) $message ) ) ) {
									$message = __( 'We sent verification code to {customer_email}. To verify your email address, please check your inbox and enter the code below.', 'customer-email-verification' );
								}

								$message = str_replace( '{customer_email}', '<strong>' . esc_html( $email ) . '</strong>', $message );

								/** Kept for back-compat with sites already filtering this string. */
								// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
								$message = apply_filters( 'cev_login_auth_message', $message, $email );
								echo wp_kses_post( $message );
								?>
							</span>
						</div>
						<?php if ( 0 == $cev_login_hide_otp_section ) { ?>
								<div class="cev-pin-verification">
									<div class="cev-pin-verification__row">
										<div class="cev-field cev-field_size_extra-large cev-field_icon_left cev-field_event_right cev-field_text_center">
											<h5 class="required-filed">
												<?php
												// Determine number of digits from setting: '1' => 4, '2' => 6 (default 4).
												$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );

												if ( '2' === $code_length ) {
													$code_label = __( '6-digit code', 'customer-email-verification' );
												} else {
													$code_label = __( '4-digit code', 'customer-email-verification' );
												}

												/**
												 * Filter the OTP code length label shown above the inputs.
												 *
												 * @since 2.8.13
												 *
												 * @param string $code_label  Default label based on setting (e.g. "4-digit code").
												 * @param mixed  $code_length Raw setting value for code length.
												 */
												// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
												$codelength = apply_filters( 'cev_verification_code_length', $code_label, $code_length );
												echo wp_kses_post( $codelength );
												?>
												*
											</h5>
											<?php 
											if ( '1' == $code_length ) {
												$digits = 4;
											} elseif ( '2' == $code_length ) {
												$digits = 6;
											} else {
												// Default value in case $code_length is neither '1' nor '2'.
												$digits = 4;
											}
											?>
											<div class="otp-container">
												<?php for ( $i = 1; $i <= $digits; $i++ ) : ?>
													<input type="text" maxlength="1" class="otp-input-login" id="otp_input_<?php echo esc_attr('otp_input_' . $i); ?>" placeholder=" " inputmode="numeric" autocomplete="one-time-code" />
												<?php endfor; ?>
											</div>
										</div>
									</div>
									<div class="cev-pin-verification__failure js-pincode-invalid" style="display: none;">
										<div class="cev-alert cev-alert_theme_red">										
											<span class="js-pincode-error-message">
											<?php
											esc_html_e( 'Login OTP does not match', 'customer-email-verification' ); 
											?>
											</span>
										</div>
									</div>
									<div class="cev-pin-verification__success js-pincode-success" style="display: none;">
										<div class="cev-alert cev-alert_theme_green">										
											<span class="js-pincode-success-message">
											</span>
										</div>
									</div>
									<div class="cev-pin-verification__events">
										<input type="hidden" name="cev_user_id" value="<?php echo esc_attr( get_current_user_id() ); ?>">
										<?php wp_nonce_field( 'cev_login_auth_with_otp', 'cev_login_auth_with_otp' ); ?>
										<input type="hidden" name="action" value="cev_login_auth_with_otp">
										<?php
										// Verify Button visibility (Customizer → Popup Style).
										// 'show' = manual mode: the button is visible and front.js
										// skips the auto-verify on the last digit.
										$cev_show_verify_button_login = ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', 'hide' ) );
										$cev_login_btn_style          = $cev_show_verify_button_login ? 'margin-top: 16px;' : 'display:none';
										?>
										<button class="cev-button  cev-button_size_promo cev-button_type_block cev-pin-verification__button is-disabled cev_login_btn" id="loginSubmitPinButton" type="submit" style="<?php echo esc_attr( $cev_login_btn_style ); ?>" >
										<?php 
										$verify = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_button_text', $CEV_Customizer_Options->defaults['cev_login_auth_button_text'] );
										if ( !empty($verify) ) { 
											echo wp_kses_post( $verify ); 
										} else {
											esc_html_e('Verify Code', 'customer-email-verification');
										} 
										?>
										</button>
									</div>
								</div>
							<?php } ?>
						<footer class="cev-authorization__footer" style="display:none;">
						<?php 
							$CEV_Customizer_Options = new CEV_Customizer_Options();
							$footer_message = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_widget_footer', $CEV_Customizer_Options->defaults['cev_login_auth_widget_footer']);
								$footer_message = cev_pro()->function->cev_pro_translate_string( $footer_message );
							$footer_message = cev_pro()->function->maybe_parse_merge_tags( $footer_message, cev_pro()->function );			
							echo wp_kses_post( $footer_message );
						?>
						</footer>
						<div class="cev-resend-section">
							<a href="#" class="cev_resend_link_front" style="display:none;">
								<?php esc_html_e( 'Resend verification code', 'customer-email-verification' ); ?>
							</a>
							<span class="cev_resend_timer"></span>
						</div>
					</section>
				</form>            
			</div>
		</div>
	</div>
</div>
<div class="cev_loading_overlay" style="<?php echo esc_attr( $cev_popup_style ); ?>"></div>
<?php
/*
 * The overlay tint is the --cev-popup-overlay token on the root above. It used
 * to be an unscoped <style> block with !important, which repainted every
 * .cev-authorization-grid__visual on the page.
 */
?>
