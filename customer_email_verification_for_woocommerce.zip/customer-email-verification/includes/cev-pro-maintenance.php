<?php
/**
 * Maintenance for Customer Email Verification PRO
 *
 * Handles background hygiene tasks for the verification log:
 *
 *   - Auto-cleanup: a daily WP-Cron job that deletes stale unverified
 *     records from the `wp_cev_user_log` table after a configurable
 *     retention window. Helps keep the table from growing unbounded
 *     under bot traffic and supports basic GDPR / data-retention
 *     compliance out of the box.
 *
 *   - Stats helpers: small read-only helpers consumed by the
 *     Unverified Users admin tab (total counts, oldest pending, etc.).
 *
 *   - CSV-export helper: builds the rows array shipped by the Export
 *     CSV button. Lives here (not in the admin handler) because the
 *     data shape is the same as what the cleanup job operates on.
 *
 * Note: this class only touches PENDING records (`verified` != 'true').
 * Verified records are kept indefinitely as proof of verification.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Pro_Maintenance Class
 *
 * Singleton. Hook registration happens once via ::register().
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Pro_Maintenance {

	/**
	 * Singleton instance.
	 *
	 * @var CEV_Pro_Maintenance|null
	 */
	private static $instance = null;

	/**
	 * Tracks one-time hook registration.
	 *
	 * @var bool
	 */
	private static $hooks_registered = false;

	/**
	 * Cron hook name for the daily log-table cleanup job.
	 *
	 * @var string
	 */
	const CRON_HOOK_DAILY_CLEANUP = 'cev_pro_unverified_cleanup_daily';

	/**
	 * Cron hook name for the daily WP-user cleanup job (Task 5c).
	 *
	 * Deletes registered users who never verified their email — with a
	 * stack of safeguards (skip orders, skip elevated roles, etc.).
	 *
	 * @var string
	 */
	const CRON_HOOK_USER_CLEANUP = 'cev_pro_unverified_users_cleanup_daily';

	/**
	 * Cron hook name for the daily re-engagement reminder job (Task 5d).
	 *
	 * Sends customizer-driven reminder emails to unverified users at
	 * configured intervals (1h / 24h / 3d / 7d). Per-user dedup via
	 * the `cev_reengagement_sent` usermeta.
	 *
	 * @var string
	 */
	const CRON_HOOK_REENGAGEMENT = 'cev_pro_reengagement_daily';

	/**
	 * Hard cap on reminders sent per cron tick to protect SMTP from
	 * a backlog of thousands of users.
	 *
	 * @var int
	 */
	const REENGAGEMENT_BATCH_LIMIT = 50;

	/**
	 * Minimum retention window for the user-cleanup feature.
	 * Lower bound is enforced server-side regardless of UI config to
	 * prevent destructive misconfiguration.
	 *
	 * @var int
	 */
	const USER_CLEANUP_MIN_DAYS = 30;

	/**
	 * Database table (without prefix) holding verification log entries.
	 *
	 * @var string
	 */
	const USER_LOG_TABLE = 'cev_user_log';

	/**
	 * User-meta marker stamped when an admin force-reverifies a user.
	 *
	 * Holds the MySQL datetime of the flip. Used to (a) protect the user
	 * from the auto-delete + re-engagement crons while pending re-verify,
	 * and (b) drive the "verify on next login" front-end prompt. Cleared
	 * once the user re-verifies their email.
	 *
	 * @var string
	 */
	const FORCE_REVERIFY_MARKER = 'cev_force_reverified_at';

	/**
	 * Action Scheduler / WP-Cron hook for processing one force-reverify batch.
	 *
	 * @var string
	 */
	const FORCE_REVERIFY_BATCH_HOOK = 'cev_pro_force_reverify_batch';

	/**
	 * How many users to flip per background batch.
	 *
	 * @var int
	 */
	const FORCE_REVERIFY_BATCH_SIZE = 200;

	/**
	 * Transient holding the cached "eligible for deletion" count shown on
	 * the Maintenance card. Stores array( 'eligible' => int, 'partial' => bool ).
	 *
	 * @var string
	 */
	const USER_CLEANUP_COUNT_CACHE = 'cev_pro_user_cleanup_eligible_count';

	/**
	 * Diagnostics from the most recent find_unverified_user_candidates() run.
	 *
	 * `exhausted` is true only when the scan reached the end of the matching
	 * user set — i.e. the returned candidate list is complete. When the scan
	 * stopped early (time budget, max-scan cap or the requested limit) the
	 * count is a lower bound and callers should present it as such.
	 *
	 * @var array { scanned:int, exhausted:bool, budget_hit:bool }
	 */
	private $last_scan = array(
		'scanned'    => 0,
		'exhausted'  => false,
		'budget_hit' => false,
	);

	/**
	 * Get the singleton instance.
	 *
	 * @since 2.10.0
	 * @return CEV_Pro_Maintenance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register the cron action handler.
	 *
	 * Idempotent — call once from the main plugin file.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function register() {
		if ( self::$hooks_registered ) {
			return;
		}
		self::$hooks_registered = true;

		add_action(
			self::CRON_HOOK_DAILY_CLEANUP,
			array( self::get_instance(), 'cron_daily_cleanup' )
		);

		// "Run cleanup now" admin button on the Maintenance tab.
		add_action(
			'wp_ajax_cev_run_cleanup_now',
			array( self::get_instance(), 'ajax_run_cleanup_now' )
		);

		// ── User-account cleanup (Task 5c) ─────────────────────────

		add_action(
			self::CRON_HOOK_USER_CLEANUP,
			array( self::get_instance(), 'cron_daily_user_cleanup' )
		);

		add_action(
			'wp_ajax_cev_run_user_cleanup_now',
			array( self::get_instance(), 'ajax_run_user_cleanup_now' )
		);

		add_action(
			'wp_ajax_cev_preview_unverified_users',
			array( self::get_instance(), 'ajax_preview_unverified_users' )
		);

		// Lazy "N users eligible for deletion" count for the Maintenance card.
		// Fetched by admin.js after the page has rendered so the (potentially
		// slow) user scan never runs inside a page load.
		add_action(
			'wp_ajax_cev_user_cleanup_count',
			array( self::get_instance(), 'ajax_user_cleanup_count' )
		);

		// ── Re-engagement reminder emails (Task 5d) ────────────────

		add_action(
			self::CRON_HOOK_REENGAGEMENT,
			array( self::get_instance(), 'cron_daily_reengagement' )
		);

		// "Run now" admin button on the Maintenance tab.
		add_action(
			'wp_ajax_cev_reengagement_run_now',
			array( self::get_instance(), 'ajax_run_reengagement_now' )
		);

		// Test send button — emails the current admin to validate template.
		add_action(
			'wp_ajax_cev_reengagement_send_test',
			array( self::get_instance(), 'ajax_send_test_reengagement' )
		);

		// Manual per-row send from the Unverified Users table.
		add_action(
			'wp_ajax_cev_reengagement_send_one',
			array( self::get_instance(), 'ajax_send_one_reengagement' )
		);

		// Bulk send from the Unverified Users table dropdown.
		add_action(
			'wp_ajax_cev_reengagement_send_bulk',
			array( self::get_instance(), 'ajax_send_bulk_reengagement' )
		);

		// ── Retroactive force re-verify (Tools) ────────────────────

		// Count affected users for the confirmation modal.
		add_action(
			'wp_ajax_cev_count_force_reverify',
			array( self::get_instance(), 'ajax_count_force_reverify' )
		);

		// Kick off the background force-reverify job.
		add_action(
			'wp_ajax_cev_force_reverify_all',
			array( self::get_instance(), 'ajax_force_reverify_all' )
		);

		// Background batch worker (Action Scheduler async action, or the
		// WP-Cron single-event fallback). Receives the job context array.
		add_action(
			self::FORCE_REVERIFY_BATCH_HOOK,
			array( self::get_instance(), 'run_force_reverify_batch' ),
			10,
			1
		);
	}
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching

	/**
	 * AJAX handler for the "Run cleanup now" button on the Maintenance tab.
	 *
	 * Lets admins trigger the cleanup on demand without waiting 24 hours.
	 * Capability-gated (manage_woocommerce) + nonce-protected.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_run_cleanup_now() {
		// Capability check first.
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array(
				'message' => __( 'You do not have permission to run cleanup.', 'customer-email-verification' ),
			), 403 );
		}

		// Nonce check.
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_run_cleanup_nonce' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Security check failed.', 'customer-email-verification' ),
			), 403 );
		}

		// Resolve retention window from settings, defaulting safely if disabled.
		$days = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_cleanup_pending_days', 14 );
		if ( $days <= 0 ) {
			$days = 14;
		}

		$deleted = $this->delete_pending_older_than( $days );

		if ( false === $deleted ) {
			wp_send_json_error( array(
				'message' => __( 'Cleanup query failed. Check the error log.', 'customer-email-verification' ),
			), 500 );
		}

		wp_send_json_success( array(
			'deleted' => (int) $deleted,
			'days'    => (int) $days,
			'message' => sprintf(
				/* translators: 1: number of records deleted, 2: retention window in days */
				_n(
					'Cleaned %1$d record older than %2$d days.',
					'Cleaned %1$d records older than %2$d days.',
					(int) $deleted,
					'customer-email-verification'
				),
				(int) $deleted,
				(int) $days
			),
		) );
	}

	/**
	 * Cron entry point for the unverified-log cleanup.
	 *
	 * Thin void wrapper: a WordPress action callback must not return a value,
	 * while run_daily_cleanup() returns a row count for direct callers.
	 *
	 * @since 3.0.3
	 * @return void
	 */
	public function cron_daily_cleanup() {
		$this->run_daily_cleanup();
	}

	/**
	 * Cron entry point for the user-account cleanup.
	 *
	 * Thin void wrapper: a WordPress action callback must not return a value,
	 * while run_daily_user_cleanup() returns a user count for direct callers.
	 *
	 * @since 3.0.3
	 * @return void
	 */
	public function cron_daily_user_cleanup() {
		$this->run_daily_user_cleanup();
	}

	/**
	 * Cron entry point for the re-engagement reminders.
	 *
	 * Thin void wrapper: a WordPress action callback must not return a value,
	 * while run_daily_reengagement() returns a send count for direct callers.
	 *
	 * @since 3.0.3
	 * @return void
	 */
	public function cron_daily_reengagement() {
		$this->run_daily_reengagement();
	}

	/**
	 * Daily cron callback: delete stale unverified log rows.
	 *
	 * Bails out cleanly if the feature is disabled in settings, or if
	 * no retention window is configured.
	 *
	 * @since 2.10.0
	 * @return int|false Number of rows deleted, or false on failure / disabled.
	 */
	public function run_daily_cleanup() {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_cleanup_enabled', 0 );
		if ( 1 !== $enabled ) {
			return false;
		}

		$days = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_cleanup_pending_days', 14 );
		if ( $days <= 0 ) {
			return false;
		}

		return $this->delete_pending_older_than( $days );
	}

	/**
	 * Delete pending unverified records older than $days.
	 *
	 * Pending = `verified` is NOT 'true' AND `last_updated` is older
	 * than the cutoff. Verified records are never touched.
	 *
	 * @since 2.10.0
	 * @param int $days Retention window in days.
	 * @return int|false Rows deleted, or false on query failure.
	 */
	public function delete_pending_older_than( $days ) {
		global $wpdb;

		$days = (int) $days;
		if ( $days <= 0 ) {
			return false;
		}

		$table  = $wpdb->prefix . self::USER_LOG_TABLE;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name interpolated; cutoff parameterised.
		$deleted = $wpdb->query( $wpdb->prepare(
			"DELETE FROM {$table}
			 WHERE ( verified IS NULL OR verified != %s )
			   AND last_updated IS NOT NULL
			   AND last_updated < %s",
			'true',
			$cutoff
		) );

		if ( false === $deleted ) {
			return false;
		}

		// Track when we last ran + how many we cleaned, for the stats panel.
		update_option( 'cev_pro_last_cleanup_at', current_time( 'mysql' ), false );
		update_option( 'cev_pro_last_cleanup_count', (int) $deleted, false );

		return (int) $deleted;
	}

	/**
	 * Compute lightweight stats for the Unverified Users admin tab.
	 *
	 * Returns counts the tab can render without bespoke SQL. Cheap
	 * (one COUNT per status) and not cached because the tab is rarely
	 * loaded on busy sites.
	 *
	 * @since 2.10.0
	 * @return array {
	 *     @type int    $pending           Pending (unverified) count.
	 *     @type int    $verified          Verified count.
	 *     @type int    $total             Total rows in the log.
	 *     @type int    $oldest_pending_age_days  Age in days of oldest pending row, or 0 if none.
	 *     @type string $last_cleanup_at   Datetime of last auto-cleanup run, or '' if never.
	 *     @type int    $last_cleanup_count Rows deleted in last cleanup run, or 0.
	 * }
	 */
	public function get_stats() {
		global $wpdb;

		$table = $wpdb->prefix . self::USER_LOG_TABLE;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name interpolated.
		$pending = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$table} WHERE verified IS NULL OR verified != %s",
			'true'
		) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name interpolated.
		$verified = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$table} WHERE verified = %s",
			'true'
		) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name interpolated.
		$oldest_pending = $wpdb->get_var( $wpdb->prepare(
			"SELECT last_updated FROM {$table}
			 WHERE ( verified IS NULL OR verified != %s )
			   AND last_updated IS NOT NULL
			 ORDER BY last_updated ASC
			 LIMIT 1",
			'true'
		) );

		$oldest_age_days = 0;
		if ( ! empty( $oldest_pending ) ) {
			$ts = strtotime( $oldest_pending );
			if ( $ts ) {
				$oldest_age_days = (int) floor( ( time() - $ts ) / DAY_IN_SECONDS );
			}
		}

		return array(
			'pending'                  => $pending,
			'verified'                 => $verified,
			'total'                    => $pending + $verified,
			'oldest_pending_age_days'  => $oldest_age_days,
			'last_cleanup_at'          => (string) get_option( 'cev_pro_last_cleanup_at', '' ),
			'last_cleanup_count'       => (int) get_option( 'cev_pro_last_cleanup_count', 0 ),
		);
	}

	/**
	 * Fetch all rows from the verification log for CSV export.
	 *
	 * Includes pending + verified rows. Caller is responsible for
	 * formatting (CSV, Excel, etc.).
	 *
	 * @since 2.10.0
	 * @return array Array of associative arrays (id, email, status, last_updated).
	 */
	public function get_export_rows() {
		global $wpdb;

		$table = $wpdb->prefix . self::USER_LOG_TABLE;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name interpolated; no user input.
		$rows = $wpdb->get_results(
			"SELECT id, email, verified, last_updated
			 FROM {$table}
			 ORDER BY last_updated DESC",
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'id'           => isset( $row['id'] ) ? (int) $row['id'] : 0,
				'email'        => isset( $row['email'] ) ? (string) $row['email'] : '',
				'status'       => ( isset( $row['verified'] ) && 'true' === $row['verified'] ) ? 'verified' : 'pending',
				'last_updated' => isset( $row['last_updated'] ) ? (string) $row['last_updated'] : '',
			);
		}

		return $out;
	}

	// ─────────────────────────────────────────────────────────────────
	//  USER-ACCOUNT CLEANUP (Task 5c)
	// ─────────────────────────────────────────────────────────────────
	//
	//  Deletes registered WP users who never verified their email.
	//  This is destructive — every safeguard below exists for a reason.
	//  Off by default. Minimum retention window is 30 days, hardcoded.
	//
	//  Skip rules (a user is NEVER deleted if any are true):
	//    - Has any order (any status)
	//    - Has any active subscription (if WC Subscriptions is installed)
	//    - Has a role other than `customer` or `subscriber`
	//    - Account younger than the retention window
	//    - Has logged in within the last 30 days (per cev_last_login_detail)
	//    - `customer_email_verified` usermeta = 'true'

	/**
	 * Daily cron callback for user-account cleanup.
	 *
	 * @since 2.10.0
	 * @return int|false Number of users deleted, or false on failure / disabled.
	 */
	public function run_daily_user_cleanup() {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_delete_unverified_users', 0 );
		if ( 1 !== $enabled ) {
			return false;
		}

		$days = $this->resolve_user_cleanup_days();
		if ( $days < self::USER_CLEANUP_MIN_DAYS ) {
			return false;
		}

		$result = $this->delete_unverified_users_older_than( $days, 200, false );
		$deleted = is_array( $result ) ? (int) $result['deleted'] : 0;

		// Track for the stats panel.
		update_option( 'cev_pro_last_user_cleanup_at', current_time( 'mysql' ), false );
		update_option( 'cev_pro_last_user_cleanup_count', $deleted, false );

		// Eligible-count cache is now stale — drop it so the next admin
		// page load reflects the new state.
		delete_transient( self::USER_CLEANUP_COUNT_CACHE );

		// Append to audit log (rolling, last 30 entries).
		$this->append_user_cleanup_audit( $deleted, 'cron' );

		return $deleted;
	}

	/**
	 * Resolve the configured retention window with the hard 30-day floor.
	 *
	 * @since 2.10.0
	 * @return int Days, never less than USER_CLEANUP_MIN_DAYS.
	 */
	private function resolve_user_cleanup_days() {
		$days = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_delete_unverified_users_days', 90 );
		if ( $days < self::USER_CLEANUP_MIN_DAYS ) {
			$days = self::USER_CLEANUP_MIN_DAYS;
		}
		return $days;
	}

	/**
	 * Find candidate WP users for deletion (does NOT delete).
	 *
	 * Scales to large stores via a paginated scan with a time budget +
	 * safety cap on total users examined. Without pagination we'd hit a
	 * hard ceiling (limit×3) — fine on small stores, but on a 50k-user
	 * store with mostly real customers (orders/subs) the candidate query
	 * never reached the genuinely deletable users buried deep in the
	 * registration history. The loop below resolves that.
	 *
	 * Tunable via filters so hosts with constrained resources can dial
	 * the scan down, and customers running multi-minute crons can dial
	 * it up:
	 *
	 *   - `cev_user_cleanup_query_page_size`  — rows per WP_User_Query call (default 500)
	 *   - `cev_user_cleanup_max_scan`         — hard cap on total users examined (default 100k)
	 *   - `cev_user_cleanup_time_budget`      — seconds to spend before bailing (default 25)
	 *
	 * @since 2.10.0
	 * @param int $days  Retention window. Hard-clamped to >= 30.
	 * @param int $limit Maximum candidates to return.
	 * @return array Array of WP_User objects that pass all safeguards.
	 */
	public function find_unverified_user_candidates( $days, $limit = 100, $args = array() ) {
		$days  = max( self::USER_CLEANUP_MIN_DAYS, (int) $days );
		$limit = max( 1, min( 1000, (int) $limit ) );

		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$page_size   = (int) apply_filters( 'cev_user_cleanup_query_page_size', 500 );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$max_scan    = (int) apply_filters( 'cev_user_cleanup_max_scan', 100000 );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$time_budget = (float) apply_filters( 'cev_user_cleanup_time_budget', 25.0 );

		// Caller overrides — the admin "eligible count" uses a much tighter
		// budget than the nightly cron, which owns the filtered defaults.
		if ( isset( $args['max_scan'] ) ) {
			$max_scan = (int) $args['max_scan'];
		}
		if ( isset( $args['time_budget'] ) ) {
			$time_budget = (float) $args['time_budget'];
		}

		// Clamp filter values to sane bounds so a misconfigured filter
		// can't accidentally crash the cron.
		$page_size   = max( 50, min( 2000, $page_size ) );
		$max_scan    = max( 1000, min( 1000000, $max_scan ) );
		$time_budget = max( 5.0, min( 60.0, $time_budget ) );

		$base_args = array(
			'role__in'    => array( 'customer', 'subscriber' ),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Necessary user lookup by verification-status meta (maintenance/cron context); no alternative.
			'meta_query'  => array(
				'relation' => 'OR',
				array(
					'key'     => 'customer_email_verified',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'customer_email_verified',
					'value'   => 'true',
					'compare' => '!=',
				),
			),
			'date_query'  => array(
				array(
					'column' => 'user_registered',
					'before' => $cutoff,
				),
			),
			'orderby'     => 'registered',
			'order'       => 'ASC',
			'count_total' => false, // skip COUNT(*) — we don't need pagination metadata
		);

		$passed   = array();
		$scanned  = 0;
		$deadline = microtime( true ) + $time_budget;

		$this->last_scan = array(
			'scanned'    => 0,
			'exhausted'  => false,
			'budget_hit' => false,
		);

		while ( count( $passed ) < $limit && $scanned < $max_scan ) {
			// Bail gracefully if we're approaching shared-host PHP limits.
			if ( microtime( true ) > $deadline ) {
				$this->last_scan['budget_hit'] = true;
				break;
			}

			$page_args = $base_args + array(
				'number' => $page_size,
				'offset' => $scanned,
			);

			$users = get_users( $page_args );
			if ( empty( $users ) ) {
				$this->last_scan['exhausted'] = true;
				break; // exhausted the matching set — nothing left to scan.
			}

			// Resolve "has orders?" for the whole page in ONE query instead
			// of one wc_get_orders() per user. On a real store nearly every
			// customer has an order, so this is the check that decides most
			// rows — and per-user it was the cost that made a 500-user page
			// outlast a gateway timeout.
			$ids_with_orders = $this->user_ids_with_orders( wp_list_pluck( $users, 'ID' ) );

			foreach ( $users as $user ) {
				if ( count( $passed ) >= $limit ) {
					break 2;
				}

				// Per-user budget check: a single page of per-user meta
				// lookups can itself run long on a big store, so don't wait
				// for the page to finish before honouring the budget.
				if ( microtime( true ) > $deadline ) {
					$this->last_scan['budget_hit'] = true;
					break 2;
				}

				++$scanned;

				if ( null !== $ids_with_orders && isset( $ids_with_orders[ (int) $user->ID ] ) ) {
					continue; // has_orders — already decided by the page query.
				}

				if ( null === $this->skip_reason_for_user( $user, null !== $ids_with_orders ) ) {
					$passed[] = $user;
				}
			}

			// If the page returned fewer than $page_size rows, we've hit
			// the end of the matching set — no point in another loop.
			if ( count( $users ) < $page_size ) {
				$this->last_scan['exhausted'] = true;
				break;
			}
		}

		$this->last_scan['scanned'] = $scanned;

		return $passed;
	}

	/**
	 * Which of the given users have at least one order — resolved in one
	 * query for the whole batch (HPOS-aware).
	 *
	 * Replaces a per-user wc_get_orders() call inside the candidate scan.
	 * Any order of type shop_order counts, whatever its status: for a tool
	 * that DELETES accounts, "ever transacted" is the safe test.
	 *
	 * @since 3.0.6
	 * @param int[] $user_ids User IDs in the current page.
	 * @return array<int,true>|null Set keyed by user ID, or null when the
	 *                              lookup can't be made (WooCommerce not
	 *                              loaded) and the caller must fall back to
	 *                              the per-user check.
	 */
	private function user_ids_with_orders( $user_ids ) {
		global $wpdb;

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return null;
		}

		$user_ids = array_values( array_filter( array_unique( array_map( 'absint', (array) $user_ids ) ) ) );
		if ( empty( $user_ids ) ) {
			return array();
		}

		$hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		if ( $hpos ) {
			$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
			$found        = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT customer_id FROM {$wpdb->prefix}wc_orders WHERE type = 'shop_order' AND customer_id IN ({$placeholders})",
				$user_ids
			) );
		} else {
			// Legacy posts storage: _customer_user is a string meta value, so
			// bind as strings to keep the comparison on the stored type.
			$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%s' ) );
			$found        = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = 'shop_order' AND pm.meta_key = '_customer_user' AND pm.meta_value IN ({$placeholders})",
				array_map( 'strval', $user_ids )
			) );
		}
		// phpcs:enable

		return array_fill_keys( array_map( 'absint', (array) $found ), true );
	}

	/**
	 * Determine if a user should be skipped from deletion, and why.
	 *
	 * Returns a human-readable skip reason string, or null if the user
	 * is safe to delete. Order of checks is cheap → expensive.
	 *
	 * @since 2.10.0
	 * @param WP_User $user
	 * @param bool    $orders_resolved True when the caller already settled
	 *                                 the "has orders?" question for this
	 *                                 user (batch lookup) — skips the
	 *                                 per-user wc_get_orders() call.
	 * @return string|null Skip reason or null.
	 */
	private function skip_reason_for_user( $user, $orders_resolved = false ) {
		if ( ! $user || ! $user->exists() ) {
			return 'invalid_user';
		}

		// 1. Has elevated role? (defense-in-depth alongside role__in).
		$roles = (array) $user->roles;
		$allowed_roles = array( 'customer', 'subscriber' );
		foreach ( $roles as $role ) {
			if ( ! in_array( $role, $allowed_roles, true ) ) {
				return 'has_elevated_role';
			}
		}

		// 2. Already verified? (defense-in-depth alongside meta_query).
		$verified_meta = get_user_meta( $user->ID, 'customer_email_verified', true );
		if ( 'true' === $verified_meta ) {
			return 'already_verified';
		}

		// 2b. Verified email but pending their first paid order
		// (Paid-Order Gatekeeping). They HAVE proven email ownership, so they
		// must never be pruned by the cleanup cron or nagged by the
		// re-engagement cron as if they were unverified.
		if ( 'pending_paid_order' === $verified_meta ) {
			return 'pending_paid_order';
		}

		// 2c. Force re-verified by an admin (retroactive bulk re-verify tool).
		// These users were intentionally flipped back to unverified so they
		// re-confirm their email on next login. While the marker is set they
		// must NOT be pruned by the cleanup cron nor nagged by the
		// re-engagement cron — the marker is cleared once they verify.
		if ( '' !== (string) get_user_meta( $user->ID, self::FORCE_REVERIFY_MARKER, true ) ) {
			return 'force_reverified';
		}

		// 3. Recent login (last 30 days)?
		$login_detail = get_user_meta( $user->ID, 'cev_last_login_detail', true );
		if ( is_array( $login_detail ) && ! empty( $login_detail['time'] ) ) {
			$last_login_ts = is_numeric( $login_detail['time'] )
				? (int) $login_detail['time']
				: strtotime( (string) $login_detail['time'] );
			if ( $last_login_ts && ( time() - $last_login_ts ) < ( 30 * DAY_IN_SECONDS ) ) {
				return 'recent_login';
			}
		}

		// 4. Has any orders? (HPOS-aware via wc_get_orders.) Skipped when the
		// candidate scan already answered this for the whole page.
		if ( ! $orders_resolved && function_exists( 'wc_get_orders' ) ) {
			$orders = wc_get_orders( array(
				'customer_id' => $user->ID,
				'limit'       => 1,
				'return'      => 'ids',
				'status'      => array_keys( wc_get_order_statuses() ),
			) );
			if ( ! empty( $orders ) ) {
				return 'has_orders';
			}
		}

		// 5. Has any subscriptions? (WC Subscriptions plugin.)
		if ( function_exists( 'wcs_user_has_subscription' ) ) {
			if ( wcs_user_has_subscription( $user->ID ) ) {
				return 'has_subscription';
			}
		}

		/**
		 * Filter to add custom skip reasons.
		 *
		 * Return a non-null string to skip the user, or null to allow
		 * deletion. Useful for plugin integrations (loyalty points,
		 * memberships, etc.).
		 *
		 * @since 2.10.0
		 * @param string|null $reason Skip reason, or null.
		 * @param WP_User     $user   The user being evaluated.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return apply_filters( 'cev_user_cleanup_skip_reason', null, $user );
	}

	/**
	 * Delete unverified WP users older than $days.
	 *
	 * Runs candidate query + safeguards, then deletes via wp_delete_user()
	 * so other plugins' delete_user hook fires and they can react.
	 *
	 * @since 2.10.0
	 * @param int  $days    Retention window. Hard-clamped to >= 30.
	 * @param int  $limit   Maximum to delete in one run (cron-safe batching).
	 * @param bool $dry_run If true, only return what WOULD be deleted; don't delete.
	 * @return array {
	 *     @type int   $deleted    Number actually deleted (0 in dry-run).
	 *     @type array $candidates Array of user payloads (id, email, registered, role) for preview.
	 * }
	 */
	public function delete_unverified_users_older_than( $days, $limit = 100, $dry_run = false ) {
		// Lazy-load wp_delete_user() in cron context where wp-admin isn't loaded.
		if ( ! function_exists( 'wp_delete_user' ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		$candidates = $this->find_unverified_user_candidates( $days, $limit );
		$deleted    = 0;
		$payloads   = array();

		foreach ( $candidates as $user ) {
			$payloads[] = array(
				'id'         => (int) $user->ID,
				'email'      => (string) $user->user_email,
				'registered' => (string) $user->user_registered,
				'role'       => isset( $user->roles[0] ) ? (string) $user->roles[0] : '',
			);

			if ( $dry_run ) {
				continue;
			}

			// Final safety re-check immediately before deletion to close
			// any race between query time and delete time.
			$skip = $this->skip_reason_for_user( $user );
			if ( null !== $skip ) {
				continue;
			}

			// Capture identity BEFORE deletion so we can log the analytics
			// event with the user's email + ID after the row is gone.
			$deleted_email = (string) $user->user_email;
			$deleted_id    = (int) $user->ID;

			// Reassign content to nobody (these are customer accounts; very
			// rarely have authored content).
			$ok = wp_delete_user( $user->ID );
			if ( $ok ) {
				$deleted++;

				// Analytics: record the auto-deletion so the dashboard can
				// surface "X stale users cleaned up this month."
				if ( function_exists( 'cev_pro' )
					&& cev_pro()
					&& isset( cev_pro()->function )
					&& method_exists( cev_pro()->function, 'log_event' )
				) {
					cev_pro()->function->log_event(
						$deleted_email,
						'auto_deleted',
						'maintenance_cron',
						array( 'user_id' => $deleted_id )
					);
				}
			}
		}

		return array(
			'deleted'    => $deleted,
			'candidates' => $payloads,
		);
	}

	/**
	 * Append a single entry to the rolling audit log.
	 *
	 * Stored in option `cev_pro_user_deletion_log`. Rolling window of
	 * the last 30 entries — bounded so the option size never grows
	 * unbounded.
	 *
	 * @since 2.10.0
	 * @param int    $count   Number deleted.
	 * @param string $trigger 'cron' | 'manual'.
	 * @return void
	 */
	private function append_user_cleanup_audit( $count, $trigger ) {
		$log = get_option( 'cev_pro_user_deletion_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		$log[] = array(
			'timestamp' => current_time( 'mysql' ),
			'count'     => (int) $count,
			'trigger'   => 'manual' === $trigger ? 'manual' : 'cron',
		);
		// Roll to last 30 entries.
		if ( count( $log ) > 30 ) {
			$log = array_slice( $log, -30 );
		}
		update_option( 'cev_pro_user_deletion_log', $log, false );
	}

	/**
	 * AJAX: trigger user cleanup on demand from the Maintenance tab.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_run_user_cleanup_now() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to run user cleanup.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_run_user_cleanup_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$days   = $this->resolve_user_cleanup_days();
		$result = $this->delete_unverified_users_older_than( $days, 200, false );

		update_option( 'cev_pro_last_user_cleanup_at', current_time( 'mysql' ), false );
		update_option( 'cev_pro_last_user_cleanup_count', (int) $result['deleted'], false );
		delete_transient( 'cev_pro_user_cleanup_eligible_count' );
		$this->append_user_cleanup_audit( (int) $result['deleted'], 'manual' );

		wp_send_json_success( array(
			'deleted' => (int) $result['deleted'],
			'days'    => (int) $days,
			'message' => sprintf(
				/* translators: 1: number of users deleted, 2: retention window in days */
				_n(
					'Deleted %1$d unverified user account older than %2$d days.',
					'Deleted %1$d unverified user accounts older than %2$d days.',
					(int) $result['deleted'],
					'customer-email-verification'
				),
				(int) $result['deleted'],
				(int) $days
			),
		) );
	}

	/**
	 * AJAX: preview the next batch of users that would be deleted.
	 *
	 * Read-only — never deletes. Returns up to 100 candidates so the
	 * admin can sanity-check their settings before enabling auto-delete
	 * or running it manually.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_preview_unverified_users() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to preview unverified users.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_preview_users_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$days   = $this->resolve_user_cleanup_days();
		$result = $this->delete_unverified_users_older_than( $days, 100, true );

		wp_send_json_success( array(
			'days'       => (int) $days,
			'count'      => count( $result['candidates'] ),
			'candidates' => $result['candidates'],
		) );
	}

	/**
	 * Stats helper: count unverified users that would currently be eligible
	 * for cleanup. Used by the user-cleanup card footer.
	 *
	 * @since 2.10.0
	 * @return array { eligible: int, last_cleanup_at: string, last_cleanup_count: int }
	 */
	public function get_user_cleanup_stats() {
		// READ-ONLY: this runs inside the admin page render, so it must never
		// trigger the user scan. Earlier builds computed the count here on a
		// cache miss; on a 20k-customer store that scan (one order lookup per
		// user, nothing cached until it finished) outlasted the gateway
		// timeout and the Settings page 504'd. The count is now computed by
		// compute_user_cleanup_eligible_count() via AJAX after the page loads.
		$cached   = get_transient( self::USER_CLEANUP_COUNT_CACHE );
		$eligible = null;
		$partial  = false;

		if ( is_array( $cached ) && isset( $cached['eligible'] ) ) {
			$eligible = (int) $cached['eligible'];
			$partial  = ! empty( $cached['partial'] );
		} elseif ( false !== $cached && is_numeric( $cached ) ) {
			$eligible = (int) $cached; // Cache written by a pre-3.0.6 build.
		}

		return array(
			'eligible'           => $eligible,
			'is_partial'         => $partial,
			'last_cleanup_at'    => (string) get_option( 'cev_pro_last_user_cleanup_at', '' ),
			'last_cleanup_count' => (int) get_option( 'cev_pro_last_user_cleanup_count', 0 ),
		);
	}

	/**
	 * Compute (and cache for 15 minutes) how many accounts the auto-delete
	 * would currently remove.
	 *
	 * Deliberately bounded: it stops after `cev_user_cleanup_stats_time_budget`
	 * seconds (default 5) or `cev_user_cleanup_stats_max_scan` users (default
	 * 2000), or once 200 candidates are found — whichever comes first. When it
	 * stops early the result is a lower bound and `is_partial` is true; the UI
	 * shows it as "N+". The nightly cron keeps its own, much larger budget and
	 * processes the full list in batches, so a partial count here never limits
	 * what actually gets cleaned up.
	 *
	 * The partial result is cached immediately, so a slow store pays the scan
	 * at most once per 15 minutes regardless of how often the card is opened.
	 *
	 * @since 3.0.6
	 * @param bool $force Ignore the cache and rescan.
	 * @return array { eligible:int, is_partial:bool }
	 */
	public function compute_user_cleanup_eligible_count( $force = false ) {
		if ( ! $force ) {
			$stats = $this->get_user_cleanup_stats();
			if ( null !== $stats['eligible'] ) {
				return array(
					'eligible'   => (int) $stats['eligible'],
					'is_partial' => (bool) $stats['is_partial'],
				);
			}
		}

		$days = $this->resolve_user_cleanup_days();

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$time_budget = (float) apply_filters( 'cev_user_cleanup_stats_time_budget', 5.0 );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$max_scan = (int) apply_filters( 'cev_user_cleanup_stats_max_scan', 2000 );

		$candidates = $this->find_unverified_user_candidates( $days, 200, array(
			'time_budget' => $time_budget,
			'max_scan'    => $max_scan,
		) );

		$result = array(
			'eligible'   => count( $candidates ),
			'is_partial' => empty( $this->last_scan['exhausted'] ),
		);

		set_transient( self::USER_CLEANUP_COUNT_CACHE, array(
			'eligible' => $result['eligible'],
			'partial'  => $result['is_partial'],
		), 15 * MINUTE_IN_SECONDS );

		return $result;
	}

	/**
	 * Human-readable sentence for the Maintenance card's eligible-count note.
	 *
	 * Shared by the template (cached value on render) and the AJAX endpoint
	 * so both paths word the state identically.
	 *
	 * @since 3.0.6
	 * @param int  $eligible   Candidate count (a lower bound when partial).
	 * @param bool $is_partial Whether the scan stopped before the end.
	 * @return string
	 */
	public function user_cleanup_eligible_message( $eligible, $is_partial ) {
		$eligible = (int) $eligible;

		if ( $is_partial && $eligible > 0 ) {
			return sprintf(
				/* translators: %s: number of users found before the scan limit was reached */
				__( '%s+ users eligible for deletion (large store — count limited; the nightly cleanup processes all eligible accounts in batches).', 'customer-email-verification' ),
				number_format_i18n( $eligible )
			);
		}

		if ( $is_partial ) {
			return __( 'Count limited on this large store — the nightly cleanup checks all eligible accounts in batches.', 'customer-email-verification' );
		}

		if ( $eligible > 0 ) {
			return sprintf(
				/* translators: %d: number of users currently eligible for deletion */
				_n( '%d user currently eligible for deletion.', '%d users currently eligible for deletion.', $eligible, 'customer-email-verification' ),
				$eligible
			);
		}

		return __( 'No eligible users right now.', 'customer-email-verification' );
	}

	/**
	 * AJAX: the Maintenance card's "eligible for deletion" count.
	 *
	 * Called by admin.js once the card is on screen, so the user scan runs
	 * in its own bounded request instead of inside the page load.
	 *
	 * @since 3.0.6
	 * @return void
	 */
	public function ajax_user_cleanup_count() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_user_cleanup_count_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_delete_unverified_users', 0 );
		if ( 1 !== $enabled ) {
			wp_send_json_success( array(
				'enabled'    => false,
				'eligible'   => 0,
				'is_partial' => false,
				'message'    => __( 'Enable auto-delete to see how many accounts are eligible.', 'customer-email-verification' ),
			) );
		}

		$result = $this->compute_user_cleanup_eligible_count();

		wp_send_json_success( array(
			'enabled'    => true,
			'eligible'   => (int) $result['eligible'],
			'is_partial' => (bool) $result['is_partial'],
			'message'    => $this->user_cleanup_eligible_message( $result['eligible'], $result['is_partial'] ),
		) );
	}

	// ─────────────────────────────────────────────────────────────────
	//  RE-ENGAGEMENT REMINDER EMAILS (Task 5d)
	// ─────────────────────────────────────────────────────────────────
	//
	//  Sends customizer-driven reminder emails to unverified users at
	//  configured intervals (1h / 24h / 3d / 7d). Per-user dedup via
	//  `cev_reengagement_sent` usermeta — an array of intervals already
	//  sent (e.g. ['1h', '24h']). Off by default; admin opts in via the
	//  Maintenance tab.

	/**
	 * Resolve the configured reminder intervals.
	 *
	 * @since 2.10.0
	 * @return array Array of interval strings ('1h', '24h', '3d', '7d')
	 *               in ascending order. Empty array means feature is off.
	 */
	private function resolve_reengagement_intervals() {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_send_reengagement_emails', 0 );
		if ( 1 !== $enabled ) {
			return array();
		}

		$intervals_raw = cev_pro()->function->cev_pro_admin_settings(
			'cev_reengagement_intervals',
			array( '1h' => 0, '24h' => 1, '3d' => 0, '7d' => 1 )
		);
		if ( ! is_array( $intervals_raw ) ) {
			$intervals_raw = array();
		}

		// Multiple-select field stores { '24h': 1 } for selected, { '1h': 0 }
		// for unselected. Normalize to a flat list of selected keys.
		$intervals = array();
		foreach ( $intervals_raw as $key => $val ) {
			if ( is_int( $key ) ) {
				// Already a flat list (e.g. cron-triggered programmatic save).
				$intervals[] = (string) $val;
			} elseif ( 1 === (int) $val ) {
				$intervals[] = (string) $key;
			}
		}

		// Whitelist + sort by ascending duration so dedup behaves predictably.
		$allowed = array( '1h', '24h', '3d', '7d' );
		$out     = array();
		foreach ( $allowed as $key ) {
			if ( in_array( $key, $intervals, true ) ) {
				$out[] = $key;
			}
		}

		// Cap intervals to the user-cleanup window so we don't email
		// users about to be deleted on the same morning.
		$cleanup_enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_delete_unverified_users', 0 );
		if ( 1 === $cleanup_enabled ) {
			$cleanup_days = $this->resolve_user_cleanup_days();
			$out = array_filter( $out, function( $interval ) use ( $cleanup_days ) {
				return $this->interval_to_seconds( $interval ) < ( $cleanup_days * DAY_IN_SECONDS );
			} );
			$out = array_values( $out );
		}

		return $out;
	}

	/**
	 * Convert an interval shorthand to seconds.
	 *
	 * @since 2.10.0
	 * @param string $interval One of '1h' | '24h' | '3d' | '7d'.
	 * @return int Seconds. 0 for unknown values.
	 */
	private function interval_to_seconds( $interval ) {
		switch ( (string) $interval ) {
			case '1h':
				return HOUR_IN_SECONDS;
			case '24h':
				return DAY_IN_SECONDS;
			case '3d':
				return 3 * DAY_IN_SECONDS;
			case '7d':
				return 7 * DAY_IN_SECONDS;
		}
		return 0;
	}

	/**
	 * Daily cron callback: send re-engagement reminders.
	 *
	 * Source of truth is the `wp_cev_user_log` table — the same data set
	 * the admin sees on the Unverified Users tab. This means:
	 *
	 *   - Both registered customers AND guest checkout entries are eligible
	 *     (anything that hit the verification flow but didn't finish).
	 *   - The admin's "Send re-engagement reminder emails" toggle reflects
	 *     exactly what this cron operates on — no hidden registered-only
	 *     filter behind the scenes.
	 *
	 * Per-email interval dedup is stored in option `cev_pro_reengagement_email_dedup`
	 * (capped at 10k entries) so an email never gets the same interval twice.
	 * For rows that ALSO match a registered user, the existing safeguards
	 * (orders / role / recent login) still apply — we won't email someone
	 * who quietly verified later, placed an order, etc.
	 *
	 * Hard-capped at REENGAGEMENT_BATCH_LIMIT sends per run to protect SMTP.
	 *
	 * @since 2.10.0
	 * @return int Number of reminders sent this run.
	 */
	public function run_daily_reengagement() {
		$intervals = $this->resolve_reengagement_intervals();
		if ( empty( $intervals ) ) {
			return 0;
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$batch_limit       = (int) apply_filters( 'cev_reengagement_batch_limit', self::REENGAGEMENT_BATCH_LIMIT );
		$min_interval_secs = min( array_map( array( $this, 'interval_to_seconds' ), $intervals ) );

		// Pull pending log rows old enough to be eligible for at least
		// the smallest configured interval. Oldest first so longest-due
		// emails are processed before newer ones if we hit the batch cap.
		//
		// Uses MySQL's DATE_SUB(NOW(), ...) so the comparison happens
		// entirely in MySQL's timezone — matches whatever timezone
		// last_updated was stored in (since both come from the same
		// server clock). Earlier versions of this query computed the
		// cutoff via PHP's gmdate() which produced a UTC string while
		// last_updated may be stored in WP local time, silently filtering
		// out perfectly valid rows on non-UTC sites.
		global $wpdb;
		$table = $wpdb->prefix . self::USER_LOG_TABLE;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name interpolated; values parameterised.
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, email, last_updated,
			        TIMESTAMPDIFF( SECOND, last_updated, NOW() ) AS age_seconds
			 FROM {$table}
			 WHERE ( verified IS NULL OR verified != %s )
			   AND last_updated IS NOT NULL
			   AND last_updated <= DATE_SUB( NOW(), INTERVAL %d SECOND )
			 ORDER BY last_updated ASC
			 LIMIT %d",
			'true',
			$min_interval_secs,
			$batch_limit * 4
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		// Diagnostic snapshot — recorded into an option so admins can
		// inspect exactly what the cron saw without enabling WP_DEBUG_LOG.
		// Helpful for surfacing "Sent 0" mysteries on production sites
		// where direct PHP debugging isn't available.
		$debug = array(
			'started_at'        => current_time( 'mysql' ),
			'intervals'         => $intervals,
			'min_interval_secs' => $min_interval_secs,
			'rows_returned'     => count( (array) $rows ),
			'rows_processed'    => 0,
			'no_user_path'      => 0,
			'has_user_path'     => 0,
			'safeguard_skips'   => 0,
			'send_succeeded'    => 0,
			'send_failed'       => 0,
			'last_mail_error'   => '',
			'sample_rows'       => array(),
		);

		if ( empty( $rows ) ) {
			update_option( 'cev_pro_last_reengagement_at', current_time( 'mysql' ), false );
			update_option( 'cev_pro_last_reengagement_count', 0, false );
			update_option( 'cev_pro_reengagement_debug', $debug, false );
			return 0;
		}

		// Capture a sample of returned rows for diagnostic purposes.
		foreach ( array_slice( (array) $rows, 0, 5 ) as $sample ) {
			$debug['sample_rows'][] = array(
				'email'        => isset( $sample->email ) ? $sample->email : '',
				'last_updated' => isset( $sample->last_updated ) ? $sample->last_updated : '',
				'age_seconds'  => isset( $sample->age_seconds ) ? (int) $sample->age_seconds : 0,
			);
		}

		$dedup_map = $this->get_reengagement_dedup_map();
		$sent      = 0;

		foreach ( $rows as $row ) {
			if ( $sent >= $batch_limit ) {
				break;
			}

			$email = (string) $row->email;
			if ( ! is_email( $email ) ) {
				continue;
			}

			// age_seconds was computed in MySQL via TIMESTAMPDIFF — same
			// timezone as the stored last_updated, so no client-side
			// timezone math (and no risk of a timezone-mismatch bug).
			$age_seconds = isset( $row->age_seconds ) ? (int) $row->age_seconds : 0;
			if ( $age_seconds <= 0 ) {
				continue;
			}

			// No artificial age ceiling — the dedup map below ensures each
			// (email, interval) pair is sent at most once, so picking small
			// intervals like "1h" still sends to old rows ONCE and never
			// again. If admin wants to skip very old rows they can wire up
			// the `cev_reengagement_skip_row` filter.
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			if ( apply_filters( 'cev_reengagement_skip_row', false, $row, $age_seconds ) ) {
				continue;
			}

			$key          = strtolower( $email );
			$already_sent = isset( $dedup_map[ $key ] ) && is_array( $dedup_map[ $key ] )
				? $dedup_map[ $key ]
				: array();

			// Pick the largest interval that's due AND not yet sent.
			$interval_to_send = null;
			foreach ( $intervals as $interval ) {
				$threshold = $this->interval_to_seconds( $interval );
				if ( $age_seconds < $threshold ) {
					continue;
				}
				if ( in_array( $interval, $already_sent, true ) ) {
					continue;
				}
				$interval_to_send = $interval;
			}
			if ( null === $interval_to_send ) {
				continue;
			}

			$debug['rows_processed']++;

			// Two send paths depending on whether the email belongs to
			// a registered user:
			//   - Registered → existing send_reengagement_to_user with
			//     full safeguards (skip if they have orders, etc.).
			//   - Guest → straight to wp_mail; no user to safeguard.
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				$debug['has_user_path']++;
				if ( null !== $this->skip_reason_for_user( $user ) ) {
					$debug['safeguard_skips']++;
					continue;
				}
				$ok = $this->send_reengagement_to_user( (int) $user->ID, $interval_to_send );
			} else {
				$debug['no_user_path']++;
				$ok = $this->send_reengagement_to_email( $email );
			}

			if ( $ok ) {
				$debug['send_succeeded']++;
				$already_sent[]      = $interval_to_send;
				$dedup_map[ $key ]   = array_values( array_unique( $already_sent ) );
				$sent++;
			} else {
				$debug['send_failed']++;
				if ( ! empty( $this->last_mail_error ) ) {
					$debug['last_mail_error'] = $this->last_mail_error;
				}
			}
		}

		update_option( 'cev_pro_reengagement_debug', $debug, false );

		$this->save_reengagement_dedup_map( $dedup_map );

		update_option( 'cev_pro_last_reengagement_at', current_time( 'mysql' ), false );
		update_option( 'cev_pro_last_reengagement_count', $sent, false );

		return $sent;
	}

	/**
	 * Per-email interval dedup map.
	 *
	 * Stored as a single option `cev_pro_reengagement_email_dedup` keyed by
	 * lowercased email address → array of intervals already sent. Lets us
	 * dedup guest emails (no usermeta available) and registered users from
	 * one shared store.
	 *
	 * @since 2.10.0
	 * @return array<string, array<int, string>>
	 */
	private function get_reengagement_dedup_map() {
		$map = get_option( 'cev_pro_reengagement_email_dedup', array() );
		return is_array( $map ) ? $map : array();
	}

	/**
	 * Persist the dedup map. Capped at 10,000 entries (oldest pruned first)
	 * so the option doesn't grow unbounded on busy stores.
	 *
	 * @since 2.10.0
	 * @param array $map
	 * @return void
	 */
	private function save_reengagement_dedup_map( $map ) {
		if ( ! is_array( $map ) ) {
			return;
		}
		$max = 10000;
		if ( count( $map ) > $max ) {
			// Keep the most recently touched entries.
			$map = array_slice( $map, -1 * $max, null, true );
		}
		update_option( 'cev_pro_reengagement_email_dedup', $map, false );
	}

	/**
	 * Find unverified users that may be eligible for a reminder.
	 *
	 * Reuses the same skip-rules engine as user cleanup so we never
	 * email customers with orders, staff, or recently active users.
	 *
	 * @since 2.10.0
	 * @param array $intervals Active interval list — controls how far back to look.
	 * @return WP_User[]
	 */
	private function find_reengagement_candidates( $intervals ) {
		if ( empty( $intervals ) ) {
			return array();
		}

		// Smallest interval = earliest moment a user could be due. Pull
		// any unverified user whose account is at least that old.
		$min_seconds = min( array_map( array( $this, 'interval_to_seconds' ), $intervals ) );
		if ( $min_seconds <= 0 ) {
			return array();
		}

		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $min_seconds );

		$query_args = array(
			'role__in'    => array( 'customer', 'subscriber' ),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Necessary user lookup by verification-status meta (maintenance/cron context); no alternative.
			'meta_query'  => array(
				'relation' => 'OR',
				array(
					'key'     => 'customer_email_verified',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'customer_email_verified',
					'value'   => 'true',
					'compare' => '!=',
				),
			),
			'date_query'  => array(
				array(
					'column' => 'user_registered',
					'before' => $cutoff,
				),
			),
			'number'      => self::REENGAGEMENT_BATCH_LIMIT * 4,
			'orderby'     => 'registered',
			'order'       => 'DESC',
		);

		$users  = get_users( $query_args );
		$passed = array();
		foreach ( $users as $user ) {
			if ( null === $this->skip_reason_for_user( $user ) ) {
				$passed[] = $user;
			}
		}
		return $passed;
	}

	/**
	 * Compute age (in seconds) since the user started the verification flow.
	 *
	 * Falls back to user_registered if the PIN startdate isn't set
	 * (e.g. users predating the verification flow upgrade).
	 *
	 * @since 2.10.0
	 * @param WP_User $user
	 * @return int Age in seconds. 0 if unable to resolve.
	 */
	private function user_unverified_age_seconds( $user ) {
		$pin = get_user_meta( $user->ID, 'cev_email_verification_pin', true );
		if ( is_array( $pin ) && ! empty( $pin['startdate'] ) ) {
			$ts = is_numeric( $pin['startdate'] )
				? (int) $pin['startdate']
				: strtotime( (string) $pin['startdate'] );
			if ( $ts ) {
				return max( 0, time() - $ts );
			}
		}
		$registered_ts = strtotime( (string) $user->user_registered );
		if ( $registered_ts ) {
			return max( 0, time() - $registered_ts );
		}
		return 0;
	}

	/**
	 * Build the rendered email body for a given user OR a raw email.
	 *
	 * Resolves customizer settings, applies merge tags in the appropriate
	 * context, and hands off to the re-engagement template wrapped in
	 * WC's mailer styles.
	 *
	 * Accepts EITHER a WP_User (registered customer flow with full merge
	 * tag context) OR a string email (guest flow — no WP user behind the
	 * row in cev_user_log; admin explicitly authorized the send via the
	 * per-row Send button).
	 *
	 * @since 2.10.0
	 * @param WP_User|string $user_or_email A registered WP_User instance,
	 *                                       or an email string for guest sends.
	 * @return array { subject, message } — both strings ready to send.
	 */
	private function build_reengagement_email( $user_or_email ) {
		// Defence-in-depth: this method touches WC()->mailer() + new WC_Email()
		// which fatal if WooCommerce is deactivated. Cron events can still
		// fire on a site that temporarily disabled WC (or where it crashed),
		// so bail with an empty payload — callers already treat empty subject
		// /message as a soft failure and increment the failed-send counter.
		if ( ! function_exists( 'WC' ) || ! WC() ) {
			return array( 'subject' => '', 'message' => '' );
		}
		// WC_Email is loaded lazily — only when WC's mailer is first touched.
		// Other WC emails work because they fire inside that lifecycle, but
		// this AJAX path runs cold, so we have to force-init the mailer
		// before WC_Email exists. Without this, class_exists('WC_Email')
		// returns false even though WC is fully active.
		WC()->mailer();
		if ( ! class_exists( 'WC_Email' ) ) {
			return array( 'subject' => '', 'message' => '' );
		}

		$func = cev_pro()->function;
		$defs = cev_pro()->customizer_options->defaults;

		// Set context for merge tag resolution.
		if ( $user_or_email instanceof WP_User ) {
			$func->wuev_user_id          = (int) $user_or_email->ID;
			$func->registered_user_email = (string) $user_or_email->user_email;
		} else {
			// Guest send: no WP user → merge tags that need user data
			// (e.g. {cev_display_name}) gracefully fall back to empty.
			$func->wuev_user_id          = 0;
			$func->registered_user_email = (string) $user_or_email;
		}

		$subject = $func->cev_pro_customizer_settings( 'cev_reengagement_email_subject', $defs['cev_reengagement_email_subject'] );
		$subject = $func->maybe_parse_merge_tags( $subject, $func );

		$heading = $func->cev_pro_customizer_settings( 'cev_reengagement_email_heading', $defs['cev_reengagement_email_heading'] );
		$heading = $func->maybe_parse_merge_tags( $heading, $func );

		$body = $func->cev_pro_customizer_settings( 'cev_reengagement_email_body', $defs['cev_reengagement_email_body'] );
		$body = $func->maybe_parse_merge_tags( $body, $func );

		$button_text = $func->cev_pro_customizer_settings( 'cev_reengagement_email_button_text', $defs['cev_reengagement_email_button_text'] );

		$button_url = $func->cev_pro_customizer_settings( 'cev_reengagement_email_button_url', $defs['cev_reengagement_email_button_url'] );
		$button_url = $func->maybe_parse_merge_tags( $button_url, $func );
		if ( empty( $button_url ) ) {
			$button_url = $func->registration_page_url();
		}

		$footer = $func->cev_pro_customizer_settings( 'cev_reengagement_footer_content', '' );

		// Render the WooCommerce-styled email body.
		$mailer = WC()->mailer();
		$email     = new WC_Email();
		$email->id = 'CEV_Reengagement_Reminder';

		ob_start();
		$local_template = get_stylesheet_directory() . '/woocommerce/emails/cev-reengagement-email.php';
		if ( file_exists( $local_template ) ) {
			wc_get_template(
				'emails/cev-reengagement-email.php',
				array(
					'email_heading'  => $heading,
					'content'        => $body,
					'button_text'    => $button_text,
					'button_url'     => $button_url,
					'footer_content' => $footer,
				),
				'customer-email-verification/',
				get_stylesheet_directory() . '/woocommerce/'
			);
		} else {
			wc_get_template(
				'emails/cev-reengagement-email.php',
				array(
					'email_heading'  => $heading,
					'content'        => $body,
					'button_text'    => $button_text,
					'button_url'     => $button_url,
					'footer_content' => $footer,
				),
				'customer-email-verification/',
				cev_pro()->get_plugin_path() . '/templates/'
			);
		}
		$inner = ob_get_clean();

		$message = $email->style_inline( $mailer->wrap_message( $heading, $inner ) );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned filter (legacy wc_cev_ prefix); renaming would break sites already hooking it.
		$message = apply_filters( 'wc_cev_decode_html_content', $message );

		return array(
			'subject' => (string) $subject,
			'message' => (string) $message,
		);
	}

	/**
	 * Send a single re-engagement email.
	 *
	 * Re-checks safeguards immediately before sending so no race between
	 * candidate query and send time can result in emailing a user who
	 * just verified or just placed an order. The per-row "Send reminder"
	 * button in the admin Unverified Users table passes
	 * $bypass_safeguards = true so an explicit admin click always sends
	 * (the safeguards exist to protect bulk / cron flows from spamming).
	 *
	 * @since 2.10.0
	 * @param int    $user_id
	 * @param string $interval_label    Logged in usermeta + audit. '' for manual sends.
	 * @param bool   $bypass_safeguards Skip the skip_reason_for_user() check
	 *                                  (per-row admin sends only). Default false.
	 * @return bool True on success.
	 */
	public function send_reengagement_to_user( $user_id, $interval_label = '', $bypass_safeguards = false ) {
		// Reset captured error so the AJAX layer doesn't read a stale message.
		$this->last_mail_error = '';

		$user = get_user_by( 'id', (int) $user_id );
		if ( ! $user || ! $user->exists() ) {
			$this->last_mail_error = __( 'User not found.', 'customer-email-verification' );
			return false;
		}

		// Safeguards (skip orders, recent login, verified, etc.).
		// Reuse the same engine as auto-cleanup. Bypassed for per-row admin
		// sends — they're explicit intent, not background automation.
		if ( ! $bypass_safeguards ) {
			$skip = $this->skip_reason_for_user( $user );
			if ( null !== $skip ) {
				$this->last_mail_error = $this->reengagement_skip_message( $skip );
				return false;
			}
		}

		$built = $this->build_reengagement_email( $user );
		$subj_empty = empty( $built['subject'] );
		$msg_empty  = empty( $built['message'] );
		if ( $subj_empty || $msg_empty ) {
			$wc_loaded = ( function_exists( 'WC' ) && WC() && class_exists( 'WC_Email' ) );
			if ( ! $wc_loaded ) {
				$this->last_mail_error = __( 'Cannot render the re-engagement email: WooCommerce is not active or its email subsystem failed to load.', 'customer-email-verification' );
			} elseif ( $subj_empty && $msg_empty ) {
				$this->last_mail_error = __( 'The re-engagement email subject and body are both empty. Open Customize → Re-engagement reminder and set both, then try again.', 'customer-email-verification' );
			} elseif ( $subj_empty ) {
				$this->last_mail_error = __( 'The re-engagement email subject is empty. Open Customize → Re-engagement reminder and set a subject.', 'customer-email-verification' );
			} else {
				$this->last_mail_error = __( 'The re-engagement email body could not be rendered (the WC template returned empty). Check Customize → Re-engagement reminder and confirm a body is set.', 'customer-email-verification' );
			}
			return false;
		}

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		// Capture the real PHPMailer error during this send so callers
		// can surface it verbatim instead of inventing a generic message.
		// last_mail_error was already reset at the top of this method.
		$capture = function( $wp_error ) {
			if ( is_wp_error( $wp_error ) ) {
				$this->last_mail_error = (string) $wp_error->get_error_message();
			}
		};
		add_action( 'wp_mail_failed', $capture );

		// Detect plugins that hijack `pre_wp_mail` and return false silently
		// (logging plugins, "stop mail" debug plugins, etc.). When wp_mail
		// short-circuits via this filter, wp_mail_failed never fires.
		$pre_intercepted = false;
		$pre_filter = function( $pre ) use ( &$pre_intercepted ) {
			if ( false === $pre ) {
				$pre_intercepted = true;
			}
			return $pre;
		};
		add_filter( 'pre_wp_mail', $pre_filter, PHP_INT_MAX );

		$ok = wp_mail(
			(string) $user->user_email,
			(string) $built['subject'],
			(string) $built['message'],
			$headers
		);

		remove_action( 'wp_mail_failed', $capture );
		remove_filter( 'pre_wp_mail', $pre_filter, PHP_INT_MAX );

		// If wp_mail returned false but neither hook captured a reason,
		// fall back to PHPMailer's ErrorInfo (set even when send() returns
		// false without throwing) and the pre_wp_mail interception flag.
		if ( ! $ok && '' === $this->last_mail_error ) {
			if ( $pre_intercepted ) {
				$this->last_mail_error = __( 'Another plugin blocked this email via the pre_wp_mail filter (likely an email-logging or stop-mail plugin). Check your active plugins.', 'customer-email-verification' );
			} elseif ( isset( $GLOBALS['phpmailer'] ) && is_object( $GLOBALS['phpmailer'] ) && ! empty( $GLOBALS['phpmailer']->ErrorInfo ) ) {
				$this->last_mail_error = (string) $GLOBALS['phpmailer']->ErrorInfo;
			}
		}

		if ( $ok ) {
			$this->append_reengagement_audit( 1, $interval_label ? 'cron' : 'manual', $interval_label );
		}

		return (bool) $ok;
	}

	/**
	 * Human-readable message for each skip_reason_for_user() code.
	 *
	 * Shown to admins when the per-row "Send reminder" button is clicked
	 * but the user is skipped by a safeguard. Per-row sends pass
	 * $bypass_safeguards = true so they never hit this — kept for
	 * completeness and for any future caller that wants the cron flow's
	 * reason surfaced verbatim.
	 *
	 * @since 2.10.0
	 * @param string $code Code returned from skip_reason_for_user().
	 * @return string
	 */
	private function reengagement_skip_message( $code ) {
		$map = array(
			'invalid_user'        => __( 'User not found.', 'customer-email-verification' ),
			'has_elevated_role'   => __( 'Skipped: this user has an elevated role (admin, editor, etc.).', 'customer-email-verification' ),
			'already_verified'    => __( 'Skipped: this user is already verified.', 'customer-email-verification' ),
			'pending_paid_order'  => __( 'Skipped: this user has verified their email and is awaiting their first paid order.', 'customer-email-verification' ),
			'force_reverified'    => __( 'Skipped: this user was recently force re-verified by an admin.', 'customer-email-verification' ),
			'recent_login'        => __( 'Skipped: this user has logged in within the last 30 days.', 'customer-email-verification' ),
			'has_orders'          => __( 'Skipped: this user has at least one order.', 'customer-email-verification' ),
			'has_subscription'    => __( 'Skipped: this user has an active subscription.', 'customer-email-verification' ),
		);
		return isset( $map[ $code ] ) ? $map[ $code ] : __( 'Skipped by a custom safeguard.', 'customer-email-verification' );
	}

	/**
	 * Last error message captured from `wp_mail_failed` during a send.
	 *
	 * Populated by send_reengagement_to_user() / ajax_send_test_reengagement()
	 * so AJAX handlers can echo back PHPMailer's actual reason instead of
	 * inventing a generic "send failed" string. Empty when no error fired.
	 *
	 * @var string
	 */
	private $last_mail_error = '';

	/**
	 * Send a re-engagement reminder to a raw email address (guest path).
	 *
	 * Used by the per-row "Send reminder" button on the Unverified Users
	 * table when the row's email isn't tied to a WP user account
	 * (typically a guest checkout entry). No safeguards — admin explicitly
	 * clicked Send, so we trust them.
	 *
	 * The cron-driven flow stays user-only; this method is for manual
	 * admin actions only.
	 *
	 * @since 2.10.0
	 * @param string $email Recipient email.
	 * @return bool True on success.
	 */
	public function send_reengagement_to_email( $email ) {
		$this->last_mail_error = '';

		if ( ! is_email( $email ) ) {
			$this->last_mail_error = __( 'The recipient address is not a valid email.', 'customer-email-verification' );
			return false;
		}

		$built = $this->build_reengagement_email( $email );
		$subj_empty = empty( $built['subject'] );
		$msg_empty  = empty( $built['message'] );
		if ( $subj_empty || $msg_empty ) {
			$wc_loaded = ( function_exists( 'WC' ) && WC() && class_exists( 'WC_Email' ) );
			if ( ! $wc_loaded ) {
				$this->last_mail_error = __( 'Cannot render the re-engagement email: WooCommerce is not active or its email subsystem failed to load.', 'customer-email-verification' );
			} elseif ( $subj_empty && $msg_empty ) {
				$this->last_mail_error = __( 'The re-engagement email subject and body are both empty. Open Customize → Re-engagement reminder and set both, then try again.', 'customer-email-verification' );
			} elseif ( $subj_empty ) {
				$this->last_mail_error = __( 'The re-engagement email subject is empty. Open Customize → Re-engagement reminder and set a subject.', 'customer-email-verification' );
			} else {
				$this->last_mail_error = __( 'The re-engagement email body could not be rendered (the WC template returned empty). Check Customize → Re-engagement reminder and confirm a body is set.', 'customer-email-verification' );
			}
			return false;
		}

		$capture = function( $wp_error ) {
			if ( is_wp_error( $wp_error ) ) {
				$this->last_mail_error = (string) $wp_error->get_error_message();
			}
		};
		add_action( 'wp_mail_failed', $capture );

		$pre_intercepted = false;
		$pre_filter = function( $pre ) use ( &$pre_intercepted ) {
			if ( false === $pre ) {
				$pre_intercepted = true;
			}
			return $pre;
		};
		add_filter( 'pre_wp_mail', $pre_filter, PHP_INT_MAX );

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		$ok = wp_mail( $email, (string) $built['subject'], (string) $built['message'], $headers );

		remove_action( 'wp_mail_failed', $capture );
		remove_filter( 'pre_wp_mail', $pre_filter, PHP_INT_MAX );

		// When wp_mail returns false but nothing was captured, fall back
		// to PHPMailer's ErrorInfo and the pre_wp_mail interception flag.
		if ( ! $ok && '' === $this->last_mail_error ) {
			if ( $pre_intercepted ) {
				$this->last_mail_error = __( 'Another plugin blocked this email via the pre_wp_mail filter (likely an email-logging or stop-mail plugin). Check your active plugins.', 'customer-email-verification' );
			} elseif ( isset( $GLOBALS['phpmailer'] ) && is_object( $GLOBALS['phpmailer'] ) && ! empty( $GLOBALS['phpmailer']->ErrorInfo ) ) {
				$this->last_mail_error = (string) $GLOBALS['phpmailer']->ErrorInfo;
			}
		}

		if ( $ok ) {
			$this->append_reengagement_audit( 1, 'manual_guest', '' );
		}

		return (bool) $ok;
	}

	/**
	 * Append a single entry to the rolling re-engagement audit log.
	 *
	 * Stored in option `cev_pro_reengagement_log`. Rolling window of
	 * the last 30 entries — bounded so the option size never grows
	 * unbounded.
	 *
	 * @since 2.10.0
	 * @param int    $count    Number sent in this batch.
	 * @param string $trigger  'cron' | 'manual' | 'bulk' | 'test'.
	 * @param string $interval Interval label (1h/24h/3d/7d) or '' for manual.
	 * @return void
	 */
	private function append_reengagement_audit( $count, $trigger, $interval = '' ) {
		$log = get_option( 'cev_pro_reengagement_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		$log[] = array(
			'timestamp' => current_time( 'mysql' ),
			'count'     => (int) $count,
			'trigger'   => (string) $trigger,
			'interval'  => (string) $interval,
		);
		if ( count( $log ) > 30 ) {
			$log = array_slice( $log, -30 );
		}
		update_option( 'cev_pro_reengagement_log', $log, false );
	}

	/**
	 * Stats helper: simple summary for the re-engagement card.
	 *
	 * @since 2.10.0
	 * @return array { sent_30d: int, last_at: string, last_count: int, intervals: array }
	 */
	public function get_reengagement_stats() {
		$log = get_option( 'cev_pro_reengagement_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}

		$cutoff   = time() - ( 30 * DAY_IN_SECONDS );
		$sent_30d = 0;
		foreach ( $log as $entry ) {
			$ts = isset( $entry['timestamp'] ) ? strtotime( (string) $entry['timestamp'] ) : 0;
			if ( $ts && $ts >= $cutoff ) {
				$sent_30d += isset( $entry['count'] ) ? (int) $entry['count'] : 0;
			}
		}

		return array(
			'sent_30d'   => $sent_30d,
			'last_at'    => (string) get_option( 'cev_pro_last_reengagement_at', '' ),
			'last_count' => (int) get_option( 'cev_pro_last_reengagement_count', 0 ),
			'intervals'  => $this->resolve_reengagement_intervals(),
		);
	}

	/**
	 * AJAX: trigger re-engagement send on demand from the Maintenance tab.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_run_reengagement_now() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to run re-engagement.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_run_reengagement_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$sent = $this->run_daily_reengagement();

		wp_send_json_success( array(
			'sent'    => (int) $sent,
			'message' => sprintf(
				/* translators: %d: number of reminders sent */
				_n(
					'Sent %d re-engagement reminder.',
					'Sent %d re-engagement reminders.',
					(int) $sent,
					'customer-email-verification'
				),
				(int) $sent
			),
		) );
	}

	/**
	 * AJAX: send a test re-engagement email to the current admin.
	 *
	 * Lets the admin sanity-check their customizer changes against a
	 * real inbox without waiting for a real eligible user. Skips the
	 * usermeta dedup write so testing is repeatable.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_send_test_reengagement() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to send a test email.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_send_test_reengagement_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$user = wp_get_current_user();
		if ( ! $user || ! $user->exists() ) {
			wp_send_json_error( array( 'message' => __( 'Could not resolve current user.', 'customer-email-verification' ) ), 400 );
		}

		// Build using current user as the merge-tag context but bypass
		// the safeguard skip rules — admins are explicitly allowed to
		// send themselves a test.
		$built = $this->build_reengagement_email( $user );

		// Capture the real PHPMailer error so we surface it verbatim.
		$this->last_mail_error = '';
		$capture = function( $wp_error ) {
			if ( is_wp_error( $wp_error ) ) {
				$this->last_mail_error = (string) $wp_error->get_error_message();
			}
		};
		add_action( 'wp_mail_failed', $capture );

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		$ok = wp_mail( $user->user_email, $built['subject'], $built['message'], $headers );

		remove_action( 'wp_mail_failed', $capture );

		if ( $ok ) {
			$this->append_reengagement_audit( 1, 'test', '' );
			wp_send_json_success( array(
				'message' => sprintf(
					/* translators: %s: admin email address */
					__( 'Test email sent to %s.', 'customer-email-verification' ),
					$user->user_email
				),
			) );
		}

		// Return 200 + JSON error so the JS reads it from response.data.
		// Echo PHPMailer's actual reason if we captured one; otherwise
		// just say wp_mail() failed — no friendly editorialising.
		wp_send_json_error( array(
			'message' => $this->last_mail_error
				? $this->last_mail_error
				: __( 'wp_mail() returned false.', 'customer-email-verification' ),
		) );
	}

	/**
	 * AJAX: send a single re-engagement email to a user identified by their
	 * row in `wp_cev_user_log` (per-row icon on the Unverified Users tab).
	 *
	 * Resolves the user via the email column — works for registered users.
	 * Guests-only entries are reported back so the admin understands why
	 * the send was a no-op.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_send_one_reengagement() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to send reminders.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_reengagement_send_one_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid log entry.', 'customer-email-verification' ) ), 400 );
		}

		global $wpdb;
		$table = $wpdb->prefix . self::USER_LOG_TABLE;
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Table name interpolated; id parameterised.
		$email = (string) $wpdb->get_var( $wpdb->prepare( "SELECT email FROM {$table} WHERE id = %d LIMIT 1", $id ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Log entry not found.', 'customer-email-verification' ) ), 404 );
		}

		// Per-row "Send reminder" is an explicit admin action — bypass the
		// cron/bulk safeguards (orders / verified / recent login / etc.).
		// If the admin clicked Send for THIS person, they want it sent.
		//   1. Email belongs to a registered WP user → send-to-user flow
		//      with safeguards bypassed.
		//   2. Email has no WP user (guest checkout entry) → no safeguards
		//      in that path either.
		$user = get_user_by( 'email', $email );
		if ( $user ) {
			$ok = $this->send_reengagement_to_user( (int) $user->ID, '', true );
		} else {
			$ok = $this->send_reengagement_to_email( $email );
		}

		if ( $ok ) {
			wp_send_json_success( array(
				'message' => sprintf(
					/* translators: %s: recipient email */
					__( 'Reminder sent to %s.', 'customer-email-verification' ),
					$email
				),
			) );
		}

		// 200 + JSON error. Echo PHPMailer's real error if one was
		// captured during the send; otherwise the generic wp_mail() fail.
		wp_send_json_error( array(
			'message' => $this->last_mail_error
				? $this->last_mail_error
				: __( 'wp_mail() returned false.', 'customer-email-verification' ),
		) );
	}

	/**
	 * AJAX: bulk send re-engagement emails — one per selected log row.
	 *
	 * Same dedup as the per-row send: skips users already verified, with
	 * orders, with recent login, etc.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_send_bulk_reengagement() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to send reminders.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_reengagement_send_bulk_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		if ( ! isset( $_POST['ids'] ) || ! is_array( $_POST['ids'] ) || empty( $_POST['ids'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No entries selected.', 'customer-email-verification' ) ), 400 );
		}

		$ids = array_map( 'absint', $_POST['ids'] );
		$ids = array_filter( $ids );

		if ( empty( $ids ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid entries.', 'customer-email-verification' ) ), 400 );
		}

		global $wpdb;
		$table = $wpdb->prefix . self::USER_LOG_TABLE;

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name interpolated; %d placeholders built dynamically.
		$emails = $wpdb->get_col( $wpdb->prepare( "SELECT email FROM {$table} WHERE id IN ($placeholders)", $ids ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		$sent    = 0;
		$skipped = 0;
		foreach ( (array) $emails as $email ) {
			$email = (string) $email;
			if ( ! is_email( $email ) ) {
				$skipped++;
				continue;
			}
			// Same fall-through as the per-row send: registered users get
			// the safeguarded path; guest entries go straight to wp_mail.
			$user = get_user_by( 'email', $email );
			$ok   = $user
				? $this->send_reengagement_to_user( (int) $user->ID, '' )
				: $this->send_reengagement_to_email( $email );
			if ( $ok ) {
				$sent++;
			} else {
				$skipped++;
			}
		}

		wp_send_json_success( array(
			'sent'    => $sent,
			'skipped' => $skipped,
			'message' => sprintf(
				/* translators: 1: sent count, 2: skipped count */
				__( 'Sent %1$d reminders, skipped %2$d.', 'customer-email-verification' ),
				$sent,
				$skipped
			),
		) );
	}

	/**
	 * Whether a user holds an elevated (back-office) role that the
	 * force-reverify tool excludes by default.
	 *
	 * @since 2.10.0
	 * @param WP_User $user User object.
	 * @return bool True if the user has administrator/editor/shop_manager.
	 */
	private function user_has_elevated_role( $user ) {
		if ( ! $user instanceof WP_User ) {
			return false;
		}
		$elevated = array( 'administrator', 'editor', 'shop_manager' );
		foreach ( (array) $user->roles as $role ) {
			if ( in_array( $role, $elevated, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Flip a single user back to unverified (force re-verify).
	 *
	 * Shared by the bulk Tools batch and the Users-list bulk action. Only
	 * flips users currently in a verified-ish state ('true' or the
	 * gatekeeping 'pending_paid_order'); already-unverified users are left
	 * untouched. Stamps the force-reverify marker (so the cleanup +
	 * re-engagement crons skip them) and logs one analytics event.
	 *
	 * @since 2.10.0
	 * @param int    $user_id User to flip.
	 * @param string $context Analytics context (e.g. 'admin_bulk').
	 * @return bool True if the user was flipped; false if skipped.
	 */
	public function force_reverify_user( $user_id, $context = 'admin_bulk' ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return false;
		}

		// Never touch back-office accounts (administrator / editor / shop_manager).
		if ( $this->user_has_elevated_role( $user ) ) {
			return false;
		}

		// Only flip users who are currently verified-ish — flipping an
		// already-unverified user is a no-op we don't want to log or count.
		$current = (string) get_user_meta( $user_id, 'customer_email_verified', true );
		if ( 'true' !== $current && 'pending_paid_order' !== $current ) {
			return false;
		}

		update_user_meta( $user_id, 'customer_email_verified', 'false' );
		update_user_meta( $user_id, self::FORCE_REVERIFY_MARKER, current_time( 'mysql' ) );

		// Analytics — one event per flipped user. Sites flipping tens of
		// thousands of users can short-circuit this via the filter to avoid
		// a huge event table, trading per-user detail for a summary event.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$log_per_user = (bool) apply_filters( 'cev_log_retroactive_unverify_per_user', true );
		if ( $log_per_user
			&& function_exists( 'cev_pro' )
			&& isset( cev_pro()->function )
			&& method_exists( cev_pro()->function, 'log_event' )
		) {
			cev_pro()->function->log_event( $user->user_email, 'retroactive_unverify', $context, array(), $user_id );
		}

		return true;
	}

	/**
	 * Count users the "Force re-verify all customers" tool would flip.
	 *
	 * Counts customer-side users currently in a verified-ish state
	 * ('true' or 'pending_paid_order'). Administrators, editors and shop
	 * managers are always excluded.
	 *
	 * @since 2.10.0
	 * @return int Affected user count.
	 */
	public function count_force_reverify_candidates() {
		$args = array(
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Necessary user lookup by verification-status meta (maintenance/cron context); no alternative.
			'meta_query'   => array(
				array(
					'key'     => 'customer_email_verified',
					'value'   => array( 'true', 'pending_paid_order' ),
					'compare' => 'IN',
				),
			),
			'number'       => 1,
			'count_total'  => true,
			'fields'       => 'ID',
			'role__not_in' => array( 'administrator', 'editor', 'shop_manager' ),
		);

		$query = new WP_User_Query( $args );
		return (int) $query->get_total();
	}

	/**
	 * Stats for the Force re-verify Tools section status line.
	 *
	 * @since 2.10.0
	 * @return array { last_at, last_count, running }
	 */
	public function get_force_reverify_stats() {
		return array(
			'last_at'    => (string) get_option( 'cev_pro_last_force_reverify_at', '' ),
			'last_count' => (int) get_option( 'cev_pro_last_force_reverify_count', 0 ),
			'running'    => (bool) get_option( 'cev_pro_force_reverify_running', 0 ),
		);
	}

	/**
	 * AJAX: return the affected-user count for the force-reverify modal.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_count_force_reverify() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_force_reverify_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$count = $this->count_force_reverify_candidates();

		wp_send_json_success( array(
			'count'   => $count,
			'message' => sprintf(
				/* translators: %s: number of users */
				_n(
					'%s customer will be marked unverified.',
					'%s customers will be marked unverified.',
					$count,
					'customer-email-verification'
				),
				number_format_i18n( $count )
			),
		) );
	}

	/**
	 * AJAX: start the background force-reverify job.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_force_reverify_all() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'customer-email-verification' ) ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'cev_force_reverify_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$estimated = $this->count_force_reverify_candidates();

		// Flag a running job so the Tools UI can reflect progress.
		update_option( 'cev_pro_force_reverify_running', 1, false );

		$this->schedule_force_reverify_batch( array(
			'flipped' => 0,
		) );

		wp_send_json_success( array(
			'estimated' => $estimated,
			'message'   => sprintf(
				/* translators: %s: number of users */
				_n(
					'Started — %s customer is being marked unverified in the background.',
					'Started — %s customers are being marked unverified in the background.',
					$estimated,
					'customer-email-verification'
				),
				number_format_i18n( $estimated )
			),
		) );
	}

	/**
	 * Schedule the next force-reverify batch via Action Scheduler, falling
	 * back to a WP-Cron single event when Action Scheduler is unavailable.
	 *
	 * @since 2.10.0
	 * @param array $context Job context (currently just 'flipped' = running total).
	 * @return void
	 */
	private function schedule_force_reverify_batch( $context ) {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::FORCE_REVERIFY_BATCH_HOOK, array( $context ), 'cev-force-reverify' );
			return;
		}
		wp_schedule_single_event( time() + 5, self::FORCE_REVERIFY_BATCH_HOOK, array( $context ) );
	}

	/**
	 * Process one force-reverify batch, then chain the next until the
	 * candidate set is exhausted.
	 *
	 * Flipping a user removes them from the candidate set (their meta is no
	 * longer 'true'/'pending_paid_order'), so each batch can safely query
	 * from the top. Stops when a page comes back short or nothing flipped
	 * this round (guards against an infinite loop).
	 *
	 * @since 2.10.0
	 * @param array $context Job context (currently just 'flipped' = running total).
	 * @return void
	 */
	public function run_force_reverify_batch( $context = array() ) {
		$context       = is_array( $context ) ? $context : array();
		$flipped_total = isset( $context['flipped'] ) ? (int) $context['flipped'] : 0;

		$args = array(
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Necessary user lookup by verification-status meta (maintenance/cron context); no alternative.
			'meta_query'   => array(
				array(
					'key'     => 'customer_email_verified',
					'value'   => array( 'true', 'pending_paid_order' ),
					'compare' => 'IN',
				),
			),
			'number'       => self::FORCE_REVERIFY_BATCH_SIZE,
			'fields'       => array( 'ID', 'user_email' ),
			'orderby'      => 'ID',
			'order'        => 'ASC',
			'count_total'  => false,
			'role__not_in' => array( 'administrator', 'editor', 'shop_manager' ),
		);

		$users = get_users( $args );

		$flipped_this_batch = 0;
		foreach ( $users as $user ) {
			if ( $this->force_reverify_user( (int) $user->ID, 'admin_bulk' ) ) {
				++$flipped_this_batch;
			}
		}

		$flipped_total += $flipped_this_batch;

		// More to do? Chain the next batch.
		if ( count( $users ) >= self::FORCE_REVERIFY_BATCH_SIZE && $flipped_this_batch > 0 ) {
			$this->schedule_force_reverify_batch( array(
				'flipped' => $flipped_total,
			) );
			return;
		}

		// Done — record the run.
		update_option( 'cev_pro_last_force_reverify_at', current_time( 'mysql' ), false );
		update_option( 'cev_pro_last_force_reverify_count', (int) $flipped_total, false );
		update_option( 'cev_pro_force_reverify_running', 0, false );
	}
}
// phpcs:enable
