<?php
/**
 * Smart Form — Customizer panel (Phase 8).
 *
 * Registers a dedicated top-level "Smart Form" panel in the Email Verification
 * customizer (separate from Design / Popup Content / Email Content), holding the
 * Smart Form's design + content options and a per-template live preview. PHP-only
 * — no React rebuild — following the generic panel/field pattern that
 * cev-customizer-options.php uses (a 'type' => 'panel' setting whose key is the
 * `parent` of its fields). Defaults are passed inline so this file is
 * self-contained (no entry needed in CEV_Customizer_Options::cev_generate_defaults()).
 *
 * Each of the 4 templates stores its own independent set of customizer values
 * under a per-template prefix: cev_sf_t1_, cev_sf_t2_, cev_sf_t3_, cev_sf_t4_.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Customizer_Smart_Form class.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Customizer_Smart_Form {

	/**
	 * Top-level panel key (used as the `parent` of every Smart Form field).
	 *
	 * @var string
	 */
	const PANEL = 'cev_smart_form_panel';

	/**
	 * Single instance.
	 *
	 * @var CEV_Customizer_Smart_Form|null
	 */
	private static $instance = null;

	/**
	 * Retrieve the singleton instance.
	 *
	 * @since 2.10.0
	 * @return CEV_Customizer_Smart_Form
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — register the Smart Form options on the customizer filter.
	 *
	 * @since 2.10.0
	 */
	public function __construct() {
		add_filter( 'cev_customizer_email_options', array( $this, 'register_options' ), 20, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_panel_visibility_script' ), 30 );
		add_action( 'wp_ajax_cev_sf_reset_t1_defaults', array( $this, 'ajax_reset_t1_defaults' ) );
	}

	/**
	 * Inline JS attached to the customizer page. Handles two concerns:
	 *
	 * 1. Field visibility: hides the T2 brand-panel bg sub-fields based on the
	 *    bg-type select (solid/gradient/image).
	 * 2. Reset-to-defaults button: shown for Template 1; clicking it calls the
	 *    AJAX handler that clears the T1 keys from cev_pro_customizer and reloads.
	 *
	 * @since 2.10.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_panel_visibility_script( $hook ) {
		unset( $hook );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- read-only admin-page check, no state change.
		$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		if ( 'cev_customizer' !== $page ) {
			return;
		}

		if ( ! wp_script_is( 'cev_customizer', 'registered' ) && ! wp_script_is( 'cev_customizer', 'enqueued' ) ) {
			return;
		}

		$reset_nonce    = wp_create_nonce( 'cev_sf_reset_t1_defaults' );
		$ajax_url       = admin_url( 'admin-ajax.php' );
		$js_confirm_msg = wp_json_encode( __( 'Reset all Template 1 fields to their default values?', 'customer-email-verification' ) );
		$js_saved_msg   = wp_json_encode( __( 'Settings saved successfully!', 'customer-email-verification' ) );

		$js_reset_nonce = wp_json_encode( $reset_nonce );
		$js_ajax_url    = wp_json_encode( $ajax_url );

		// Intercept fetch BEFORE the React bundle loads so save calls are captured.
		$before_script = '(function(){'
			. 'var MSG=' . $js_saved_msg . ';'
			. 'var _f=window.fetch;'
			. 'window.fetch=function(){'
			. 'var a=arguments,p=_f.apply(this,a);'
			. 'var url=typeof a[0]==="string"?a[0]:(a[0]&&a[0].url?a[0].url:"");'
			. 'var m=a[1]&&a[1].method?a[1].method.toUpperCase():"GET";'
			. 'if(url.indexOf("cev_customizer/store/update")!==-1&&"POST"===m){'
			. 'p.then(function(r){if(r.ok){cevSfSaveToast();}}).catch(function(){});}'
			. 'return p;};'
			. 'function cevSfSaveToast(){'
			. 'var e=document.getElementById("cev-sf-save-toast");'
			. 'if(e){clearTimeout(e._t);e.parentNode&&e.parentNode.removeChild(e);}'
			. 'var t=document.createElement("div");'
			. 't.id="cev-sf-save-toast";'
			. 't.textContent=MSG;'
			. 't.style.cssText="position:fixed;bottom:24px;left:50%;transform:translateX(-50%);'
			. 'background:#10b981;color:#fff;padding:10px 24px;border-radius:8px;font-size:14px;'
			. 'font-weight:500;letter-spacing:.01em;box-shadow:0 4px 16px rgba(0,0,0,.18);'
			. 'z-index:999999;opacity:1;transition:opacity .35s;pointer-events:none;white-space:nowrap;";'
			. 'document.body.appendChild(t);'
			. 't._t=setTimeout(function(){'
			. 't.style.opacity="0";'
			. 'setTimeout(function(){t.parentNode&&t.parentNode.removeChild(t);},350);'
			. '},2500);}'
			. '})();';

		wp_add_inline_script( 'cev_customizer', $before_script, 'before' );

		$script = "(function(){\n"
			. 'var RESET_NONCE=' . $js_reset_nonce . ";\n"
			. 'var AJAX_URL=' . $js_ajax_url . ";\n"
			. 'var RESET_CONFIRM=' . $js_confirm_msg . ";\n"
			. "function wire(){\n"
			. "var btn=document.getElementById('cev-sf-t1-reset-btn');\n"
			. "if(btn&&!btn.__cevResetWired){btn.__cevResetWired=true;btn.addEventListener('click',function(){if(!window.confirm(RESET_CONFIRM)){return;}var fd=new FormData();fd.append('action','cev_sf_reset_t1_defaults');fd.append('nonce',RESET_NONCE);fetch(AJAX_URL,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){if(d.success){location.reload();}}).catch(function(){});});}\n"
			. "}\n"
			. "if(window.MutationObserver){new MutationObserver(wire).observe(document.body,{childList:true,subtree:true});}\n"
			. "document.addEventListener('DOMContentLoaded',wire);\n"
			. '})();';

		wp_add_inline_script( 'cev_customizer', $script );
	}

	/**
	 * Preview-key => template-slug map (one preview per template).
	 *
	 * @since 2.10.0
	 * @return array
	 */
	public function template_map() {
		return array(
			'smartform_template1' => 'template1',
			'smartform_template2' => 'template2',
			'smartform_template3' => 'template3',
			'smartform_template4' => 'template4',
		);
	}

	/**
	 * The Smart Form preview keys (consumed by CEV_Customizer's allow-list and
	 * full-HTML-preview check).
	 *
	 * @since 2.10.0
	 * @return array
	 */
	public function preview_keys() {
		return array_keys( $this->template_map() );
	}

	/**
	 * Iframe URLs for the Smart Form template previews (consumed by
	 * CEV_Customizer::customizer_enqueue_scripts).
	 *
	 * @since 2.10.0
	 * @param string $action The preview AJAX action name.
	 * @return array
	 */
	public function iframe_urls( $action ) {
		$urls = array();
		foreach ( $this->preview_keys() as $key ) {
			$urls[ $key ] = admin_url( 'admin-ajax.php?action=' . rawurlencode( $action ) . '&preview=' . rawurlencode( $key ) );
		}
		return $urls;
	}

	/**
	 * Read a customizer value with an inline default.
	 *
	 * @since 2.10.0
	 * @param string $key     Setting key.
	 * @param string $default Default value.
	 * @return mixed
	 */
	private function get( $key, $default = '' ) {
		return cev_pro()->function->cev_pro_customizer_settings( $key, $default );
	}

	/**
	 * Build the shared base fields (colour + text) for a given template prefix.
	 *
	 * @since 2.10.0
	 * @param string $pfx Template prefix, e.g. 'cev_sf_t1_'.
	 * @param string $cls React show/hide class string for these fields.
	 * @return array
	 */
	private function base_fields( $pfx, $cls ) {
		return array(
			$pfx . 'brand_color'     => array(
				'title'       => esc_html__( 'Brand Color', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'type'        => 'color',
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'brand_color', '#4f46e5' ),
				'show'        => true,
				'option_name' => $pfx . 'brand_color',
				'option_type' => 'key',
				'live'        => true,
			),
			$pfx . 'btn_font_color'  => array(
				'title'       => esc_html__( 'Button Font Color', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'type'        => 'color',
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'btn_font_color', '#ffffff' ),
				'show'        => true,
				'option_name' => $pfx . 'btn_font_color',
				'option_type' => 'key',
				'live'        => true,
			),
			$pfx . 'heading'         => array(
				'title'       => esc_html__( 'Heading', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'heading', get_bloginfo( 'name' ) ),
				'placeholder' => get_bloginfo( 'name' ),
				'type'        => 'text',
				'show'        => true,
				'option_name' => $pfx . 'heading',
				'option_type' => 'key',
				'refresh'     => true,
			),
			$pfx . 'subheading'      => array(
				'title'       => esc_html__( 'Subheading', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'subheading', __( 'Choose how you\'d like to continue', 'customer-email-verification' ) ),
				'placeholder' => esc_html__( 'e.g. Sign in or create your account', 'customer-email-verification' ),
				'type'        => 'text',
				'show'        => true,
				'option_name' => $pfx . 'subheading',
				'option_type' => 'key',
				'refresh'     => true,
			),
			$pfx . 'login_button'    => array(
				'title'       => esc_html__( 'Login Button Label', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'login_button', __( 'Log in', 'customer-email-verification' ) ),
				'placeholder' => esc_html__( 'Log in', 'customer-email-verification' ),
				'type'        => 'text',
				'show'        => true,
				'option_name' => $pfx . 'login_button',
				'option_type' => 'key',
				'refresh'     => true,
			),
			$pfx . 'register_button' => array(
				'title'       => esc_html__( 'Register Button Label', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'register_button', __( 'Create account', 'customer-email-verification' ) ),
				'placeholder' => esc_html__( 'Create account', 'customer-email-verification' ),
				'type'        => 'text',
				'show'        => true,
				'option_name' => $pfx . 'register_button',
				'option_type' => 'key',
				'refresh'     => true,
			),
			$pfx . 'footer'          => array(
				'title'       => esc_html__( 'Footer Content', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'footer', '' ),
				'placeholder' => esc_html__( 'Footer Content', 'customer-email-verification' ),
				'type'        => 'textarea',
				'show'        => true,
				'option_name' => $pfx . 'footer',
				'option_type' => 'key',
				'refresh'     => true,
			),
		);
	}

	/**
	 * Build the brand-panel fields for a given template prefix.
	 *
	 * @since 2.10.0
	 * @param string $pfx      Template prefix, e.g. 'cev_sf_t2_'.
	 * @param string $cls      React show/hide class string for these fields.
	 * @param bool   $has_side Whether to include a panel-side (left/right) select.
	 * @return array
	 */
	private function panel_fields( $pfx, $cls, $has_side = false ) {
		unset( $has_side );
		return array(
			$pfx . 'panel_bg_solid'   => array(
				'title'       => esc_html__( 'Panel background color', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'type'        => 'color',
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'panel_bg_solid', '#4f46e5' ),
				'show'        => true,
				'option_name' => $pfx . 'panel_bg_solid',
				'option_type' => 'key',
				'live'        => true,
			),
			$pfx . 'panel_text_color' => array(
				'title'       => esc_html__( 'Panel font color', 'customer-email-verification' ),
				'parent'      => self::PANEL,
				'type'        => 'color',
				'class'       => $cls,
				'default'     => $this->get( $pfx . 'panel_text_color', '#ffffff' ),
				'show'        => true,
				'option_name' => $pfx . 'panel_text_color',
				'option_type' => 'key',
				'live'        => true,
			),
		);
	}

	/**
	 * Register the Smart Form panel + per-template fields on the customizer settings.
	 *
	 * @since 2.10.0
	 * @param array  $settings Current customizer settings.
	 * @param string $preview  Active preview (unused — the panel always registers).
	 * @return array
	 */
	public function register_options( $settings, $preview ) {
		unset( $preview );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		// Active template — drives both the panel's initial preview and the
		// preview-selector default.
		$active = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_signup_smart_template', 'template1' );
		$active = in_array( $active, array( 'template1', 'template2', 'template3', 'template4' ), true ) ? $active : 'template1';

		// Top-level panel. The `preview` key tells the React which preview iframe
		// to load when the panel is opened (mirrors the Popup / Email panels), so
		// the Smart Form preview shows immediately — not only after changing the
		// dropdown.
		$settings[ self::PANEL ] = array(
			'title'   => esc_html__( 'Smart Form', 'customer-email-verification' ),
			'type'    => 'panel',
			'preview' => 'smartform_' . $active,
			'show'    => true,
		);

		// Template to preview. The `previewType` flag tells React to hide all
		// `.all_status_submenu` elements and show `.{value}_sub_menu` when this
		// select changes — driving the per-template field visibility.
		$settings['cev_smart_form_preview_template'] = array(
			'title'       => esc_html__( 'Preview template', 'customer-email-verification' ),
			'parent'      => self::PANEL,
			'type'        => 'select',
			'default'     => 'smartform_' . $active,
			'options'     => array(
				'smartform_template1' => __( 'Template 1 — Tabbed card', 'customer-email-verification' ),
				'smartform_template2' => __( 'Template 2 — Split / brand panel', 'customer-email-verification' ),
				'smartform_template3' => __( 'Template 3 — Brand header banner', 'customer-email-verification' ),
				'smartform_template4' => __( 'Template 4 — Side-by-side', 'customer-email-verification' ),
			),
			'show'        => true,
			'option_name' => 'cev_smart_form_preview_template',
			'option_type' => 'key',
			'previewType' => true,
		);

		// ---- Template 1: Tabbed card (base fields only + reset button) ----
		$settings = array_merge( $settings, $this->base_fields( 'cev_sf_t1_', 'smartform_template1_sub_menu all_status_submenu' ) );
		$settings['cev_sf_t1_reset'] = array(
			'title'  => '',
			'parent' => self::PANEL,
			'type'   => 'desc',
			'class'  => 'smartform_template1_sub_menu all_status_submenu',
			'html'   => '<button type="button" id="cev-sf-t1-reset-btn" style="width:100%;padding:8px 0;border:1px solid #d1d5db;border-radius:6px;background:#f9fafb;cursor:pointer;font-size:12px;color:#374151;">' . esc_html__( 'Reset to defaults', 'customer-email-verification' ) . '</button>',
			'show'   => true,
		);

		// ---- Template 2: Split / brand panel (base + panel fields interleaved) ----
		// Panel background/font colour sit immediately after Brand Color.
		$t2_cls   = 'smartform_template2_sub_menu all_status_submenu';
		$t2_base  = $this->base_fields( 'cev_sf_t2_', $t2_cls );
		$t2_panel = $this->panel_fields( 'cev_sf_t2_', $t2_cls );
		$t2_fields = array();
		foreach ( $t2_base as $k => $v ) {
			$t2_fields[ $k ] = $v;
			if ( 'cev_sf_t2_brand_color' === $k ) {
				foreach ( $t2_panel as $pk => $pv ) {
					$t2_fields[ $pk ] = $pv;
				}
			}
		}
		$settings = array_merge( $settings, $t2_fields );

		// ---- Template 3: Brand header banner (base + panel fields interleaved) ----
		// Panel background/font colour sit immediately after Brand Color.
		$t3_cls   = 'smartform_template3_sub_menu all_status_submenu';
		$t3_base  = $this->base_fields( 'cev_sf_t3_', $t3_cls );
		$t3_panel = $this->panel_fields( 'cev_sf_t3_', $t3_cls );
		$t3_fields = array();
		foreach ( $t3_base as $k => $v ) {
			$t3_fields[ $k ] = $v;
			if ( 'cev_sf_t3_brand_color' === $k ) {
				foreach ( $t3_panel as $pk => $pv ) {
					$t3_fields[ $pk ] = $pv;
				}
			}
		}
		$settings = array_merge( $settings, $t3_fields );

		// ---- Template 4: Side-by-side (heading + subheading not used) ----
		$t4_fields = $this->base_fields( 'cev_sf_t4_', 'smartform_template4_sub_menu all_status_submenu' );
		unset( $t4_fields['cev_sf_t4_heading'], $t4_fields['cev_sf_t4_subheading'] );
		$settings = array_merge( $settings, $t4_fields );

		return $settings;
	}

	/**
	 * Render a specific Smart Form template for the Customizer preview iframe.
	 * The whole document is re-sanitized by CEV_Customizer::get_preview_func()
	 * (Smart Form previews are registered as full-HTML "popup" previews).
	 *
	 * @since 2.10.0
	 * @param string $template Template slug (template1..template4).
	 * @return string Preview HTML.
	 */
	public function preview( $template ) {
		// Resolve per-template prefix so the preview reads from the correct key set.
		$t_map = array( 'template1' => 't1', 'template2' => 't2', 'template3' => 't3', 'template4' => 't4' );
		$t_key = isset( $t_map[ (string) $template ] ) ? $t_map[ (string) $template ] : 't1';
		$pfx   = 'cev_sf_' . $t_key . '_';

		// Register ONLY the styles this preview needs, with explicit URLs. We do
		// NOT call wp_head()/wp_footer() here: those run every theme + plugin
		// head/footer hook (web fonts, other plugins' remote calls, etc.) inside
		// this uncached admin-ajax request, which can block past the gateway
		// timeout and return a 504. A self-contained document avoids all that.
		$base = cev_pro()->plugin_dir_url();
		$ver  = time();
		wp_register_style( 'cev-smart-form-preview-front', $base . 'assets/css/front.css', array(), $ver );
		wp_register_style( 'cev-smart-form-preview-signup', $base . 'assets/css/signup-style.css', array(), $ver );
		wp_register_style( 'cev-smart-form-preview', $base . 'assets/css/smart-form.css', array( 'cev-smart-form-preview-signup' ), $ver );

		$inline_css = '
			html { background: none; }
			body {
				margin: 0;
				padding: 32px 16px;
				min-height: 100vh;
				box-sizing: border-box;
				background: #f1f5f9;
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			.customize-partial-edit-shortcut-button { display: none; }
		';
		wp_add_inline_style( 'cev-smart-form-preview', $inline_css );

		ob_start();
		wp_print_styles( array( 'cev-smart-form-preview-front', 'cev-smart-form-preview-signup', 'cev-smart-form-preview' ) );

		if ( class_exists( 'CEV_Smart_Form' ) ) {
			// render() returns markup assembled from templates whose values are
			// escaped at source; the whole fragment is re-sanitized via wp_kses
			// by CEV_Customizer::get_preview_func().
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo CEV_Smart_Form::get_instance()->render( (string) $template );
		}

		// Seed the live-preview panel state so single-key postMessage updates can
		// recompute interdependent values (the panel background needs the bg type,
		// both colours, the angle, the overlay and the image together). Encoded
		// with JSON_HEX_* so the payload carries no raw <, >, &, ", ' and therefore
		// survives the wp_kses pass in CEV_Customizer::get_preview_func().
		$cev_sf_fn         = cev_pro()->function;
		$cev_sf_brand_seed = sanitize_hex_color( (string) $cev_sf_fn->cev_pro_customizer_settings( $pfx . 'brand_color', '#4f46e5' ) );
		if ( empty( $cev_sf_brand_seed ) ) {
			$cev_sf_brand_seed = '#4f46e5';
		}
		$cev_sf_state      = array(
			'brand'    => $cev_sf_brand_seed,
			'bg_solid' => (string) $cev_sf_fn->cev_pro_customizer_settings( $pfx . 'panel_bg_solid', $cev_sf_brand_seed ),
		);
		$cev_sf_state_json = wp_json_encode( $cev_sf_state, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
		if ( false === $cev_sf_state_json ) {
			$cev_sf_state_json = '{}';
		}

		$cev_sf_pfx_json = wp_json_encode( $pfx );
		if ( false === $cev_sf_pfx_json ) {
			$cev_sf_pfx_json = '"cev_sf_t1_"';
		}

		// Preview-only scripts: (1) a tab switcher, and (2) a live-preview
		// listener that applies field changes the React customizer postMessages
		// here — instantly, with no save and no iframe reload (the reload is what
		// made per-keystroke text editing slow). The full smart-form.js is
		// intentionally NOT loaded here (it would fire real AJAX — e.g. a
		// "Send code" click could send an OTP). Both handlers are deliberately
		// free of < > & so they survive the wp_kses pass in
		// CEV_Customizer::get_preview_func().
		?>
		<script>
		<?php
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with JSON_HEX_* flags above; carries no raw <,>,&,",' so it is safe to embed inline and survives wp_kses.
		echo 'window.cevSfPanelState = ' . $cev_sf_state_json . ';';
		echo 'window.cevSfPfx=' . $cev_sf_pfx_json . ';';
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
		?>
		( function () {
			document.addEventListener( 'click', function ( e ) {
				var trigger = e.target.closest ? e.target.closest( '[data-cev-sf-tab]' ) : null;
				if ( ! trigger ) { return; }
				e.preventDefault();
				var root = trigger.closest( '[data-cev-smart-form]' ) || document;
				var target = trigger.getAttribute( 'data-cev-sf-tab' );
				root.querySelectorAll( '.cev-sf-tab' ).forEach( function ( tab ) {
					var on = tab.getAttribute( 'data-cev-sf-tab' ) === target;
					tab.classList.toggle( 'is-active', on );
					if ( 'tab' === tab.getAttribute( 'role' ) ) { tab.setAttribute( 'aria-selected', on ? 'true' : 'false' ); }
				} );
				root.querySelectorAll( '.cev-sf-panel' ).forEach( function ( p ) {
					p.classList.toggle( 'is-active', p.getAttribute( 'data-cev-sf-panel' ) === target );
				} );
			} );
		} )();
		( function () {
			// Apply a single "live" field change from the React customizer.
			function setText( sel, val ) {
				var form = document.querySelector( '[data-cev-smart-form]' );
				if ( ! form ) { return; }
				var el = form.querySelector( sel );
				if ( el ) { el.textContent = val; }
			}
			function applySub( form, val ) {
				var panels = form.querySelector( '.cev-sf-panels' );
				var head = form.querySelector( '.cev-sf-headings' );
				if ( head ) {
					if ( '' === val ) { head.parentNode.removeChild( head ); return; }
					var sub = head.querySelector( '.cev-sf-subheading' );
					if ( ! sub ) {
						sub = document.createElement( 'div' );
						sub.className = 'cev-sf-subheading';
						head.appendChild( sub );
					}
					sub.textContent = val;
					return;
				}
				if ( '' === val || ! panels ) { return; }
				var wrap = document.createElement( 'div' );
				wrap.className = 'cev-sf-headings';
				var ns = document.createElement( 'div' );
				ns.className = 'cev-sf-subheading';
				ns.textContent = val;
				wrap.appendChild( ns );
				var tabs = form.querySelector( '.cev-sf-tabs' );
				var ref = tabs ? tabs : panels;
				ref.parentNode.insertBefore( wrap, ref );
			}
			function applyFooter( form, val ) {
				var footer = form.querySelector( '.cev-sf-footer' );
				if ( footer ) {
					if ( '' === val ) { footer.parentNode.removeChild( footer ); }
					else { footer.textContent = val; }
					return;
				}
				if ( '' === val ) { return; }
				var panels = form.querySelector( '.cev-sf-panels' );
				if ( ! panels ) { return; }
				var nf = document.createElement( 'div' );
				nf.className = 'cev-sf-footer';
				nf.textContent = val;
				panels.parentNode.insertBefore( nf, panels.nextSibling );
			}
			// Current panel state (seeded from PHP) so a single-key live update can
			// rebuild interdependent values like the panel background.
			var cevSfState = window.cevSfPanelState || {};
			var CEV_SF_PFX = window.cevSfPfx || 'cev_sf_t1_';
			function cevSfRecomputeBg( form ) {
				form.style.setProperty( '--cev-sf-panel-bg', cevSfState.bg_solid || cevSfState.brand || '#4f46e5' );
			}
			window.addEventListener( 'message', function ( ev ) {
				var data = ev.data;
				if ( ! data ) { return; }
				if ( true !== data.cev_customizer_preview ) { return; }
				var key = data.key;
				var val = ( null === data.value || undefined === data.value ) ? '' : String( data.value );
				var form = document.querySelector( '[data-cev-smart-form]' );
				if ( ! form ) { return; }
				if ( CEV_SF_PFX + 'brand_color' === key ) { cevSfState.brand = val; form.style.setProperty( '--cev-sf-brand', val ); cevSfRecomputeBg( form ); return; }
				if ( CEV_SF_PFX + 'heading' === key ) { setText( '.cev-sf-logo, .cev-sf-brand__logo, .cev-sf-banner__title', val ); return; }
				if ( CEV_SF_PFX + 'login_button' === key ) { setText( '[data-cev-sf-form="login"] button[type="submit"]', val ); return; }
				if ( CEV_SF_PFX + 'register_button' === key ) { setText( '[data-cev-sf-form="register"] button[type="submit"]', val ); return; }
				if ( CEV_SF_PFX + 'subheading' === key ) {
					var tmpl = form.getAttribute( 'data-template' );
					if ( 'template2' === tmpl || 'template3' === tmpl ) {
						var bs = form.querySelector( '.cev-sf-brand__subheading' );
						if ( '' === val ) {
							if ( bs ) { bs.parentNode.removeChild( bs ); }
						} else if ( bs ) {
							bs.textContent = val;
						} else {
							var bsNew = document.createElement( 'p' );
							bsNew.className = 'cev-sf-brand__subheading';
							bsNew.textContent = val;
							var bsRef = form.querySelector( 'template2' === tmpl ? '.cev-sf-brand__logo' : '.cev-sf-banner__title' );
							if ( bsRef ) { bsRef.parentNode.insertBefore( bsNew, bsRef.nextSibling ); }
						}
					} else {
						applySub( form, val );
					}
					return;
				}
				if ( CEV_SF_PFX + 'footer' === key ) { applyFooter( form, val ); return; }
				if ( CEV_SF_PFX + 'panel_bg_solid' === key ) { cevSfState.bg_solid = val; cevSfRecomputeBg( form ); return; }
				if ( CEV_SF_PFX + 'panel_text_color' === key ) { form.style.setProperty( '--cev-sf-panel-text', val || '' ); return; }
				if ( CEV_SF_PFX + 'btn_font_color' === key ) { form.style.setProperty( '--cev-sf-on-brand', val || '' ); return; }
			} );
		} )();
		</script>
		<?php
		return ob_get_clean();
	}

	/**
	 * AJAX handler — reset Template 1 customizer fields to their PHP defaults.
	 *
	 * Removes the affected keys from the consolidated cev_pro_customizer option
	 * so PHP-defined defaults take effect on next load. The JS caller reloads
	 * the page after a success response.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function ajax_reset_t1_defaults() {
		if ( ! check_ajax_referer( 'cev_sf_reset_t1_defaults', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Invalid nonce.' ), 403 );
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'Insufficient permissions.' ), 403 );
			return;
		}

		$keys = array(
			'cev_sf_t1_brand_color',
			'cev_sf_t1_btn_font_color',
			'cev_sf_t1_heading',
			'cev_sf_t1_subheading',
			'cev_sf_t1_login_button',
			'cev_sf_t1_register_button',
			'cev_sf_t1_footer',
		);

		$stored = get_option( 'cev_pro_customizer', array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		foreach ( $keys as $key ) {
			unset( $stored[ $key ] );
		}
		update_option( 'cev_pro_customizer', $stored );

		wp_send_json_success();
	}
}
