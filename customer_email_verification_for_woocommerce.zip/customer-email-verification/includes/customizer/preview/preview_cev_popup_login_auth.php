<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$email = ( 'johny@example.com' );
$Try_again = __('Try again', 'customer-email-verification');
$CEV_Customizer_Options = new CEV_Customizer_Options();

$cev_login_hide_otp_section =  cev_pro()->function->cev_pro_customizer_settings('cev_login_hide_otp_section', $CEV_Customizer_Options->defaults['cev_login_hide_otp_section'] );

// Get overlay background color for inline style.
// Popup appearance is emitted once as design tokens on the root element
// below. Single source of truth: CEV_Functions_Pro::popup_style_tokens().
$cev_popup_style = cev_pro()->function->popup_style_attr();

?>

<div class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">				
				<form class="cev_login_authentication_form" method="post">    
					<section class="cev-authorization__holder">
						<!-- Verification Image -->
						<?php 
						$image = cev_pro()->function->cev_pro_customizer_settings('cev_verification_image', cev_pro()->plugin_dir_url() . 'assets/css/images/email-verification-icon.svg'); 
						if ( !empty($image) ) {
							?>
							<?php
						// Popup header — the built-in mark, or the merchant's Header Image.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
						?>
						<?php } ?>
						<div class="cev-authorization__heading">
							<span class="cev-authorization__title">
							<?php
								$heading_default = __('Verify its you.', 'customer-email-verification');
								$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_header', $CEV_Customizer_Options->defaults['cev_login_auth_header'] ); 
							if ( !empty($heading) ) { 
								echo wp_kses_post( $heading ); 
							} else {
								echo wp_kses_post( $heading_default ); 
							}
							?>
							</span>
							<span class="cev-authorization__description">
								<?php
								// Get verification message from customizer settings.
								$message = cev_pro()->function->cev_pro_customizer_settings(
									'cev_login_auth_message',
									$CEV_Customizer_Options->defaults['cev_login_auth_message']
								);
								// Parse merge tags (like {site_title}).
								$message = cev_pro()->function->maybe_parse_merge_tags( $message, cev_pro()->function );
								// Replace {customer_email} with actual email for preview.
								$message = str_replace( '{customer_email}', '<strong>' . esc_html( $email ) . '</strong>', $message );
								// Allow filtering of message.
								// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
								$message = apply_filters( 'cev_login_auth_message', $message, $email );
								echo wp_kses_post( $message );
								?>
							</span>
						</div>
						<?php if ( 0 == $cev_login_hide_otp_section ) : ?>
							<?php
							// Determine number of OTP digits based on setting.
							$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
							if ( '1' === $code_length ) {
								$otp_digits = 4;
							} elseif ( '2' === $code_length ) {
								$otp_digits = 6;
							} else {
								// Default to 4 digits if setting is invalid.
								$otp_digits = 4;
							}
							?>
							<div class="otp-container" role="group" aria-label="<?php esc_attr_e( 'Enter verification code', 'customer-email-verification' ); ?>">
								<?php for ( $i = 1; $i <= $otp_digits; $i++ ) : ?>
									<?php
									/* translators: %d: OTP digit position number */
									$aria_label = sprintf( esc_attr__( 'OTP digit %d', 'customer-email-verification' ), (int) $i );
									?>
									<input
										type="text"
										maxlength="1"
										class="otp-input" placeholder=" "
										id="otp_input_<?php echo esc_attr( $i ); ?>"
										aria-label="<?php echo esc_attr( $aria_label ); ?>"
										inputmode="numeric"
										autocomplete="one-time-code"
									/>
								<?php endfor; ?>
							</div>

							<!-- Error Message Container -->
							<div class="error_mesg" role="alert" aria-live="polite" style="display: none;"></div>

							<?php
							// Verify Button preview (Customizer → Popup Style → Verify Button = Show).
							$cev_show_verify_button_preview = ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', 'hide' ) );
							$cev_login_auth_button_label    = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_button_text', $CEV_Customizer_Options->defaults['cev_login_auth_button_text'] );
							if ( empty( $cev_login_auth_button_label ) ) {
								$cev_login_auth_button_label = __( 'Verify Code', 'customer-email-verification' );
							}
							?>
							<?php if ( $cev_show_verify_button_preview ) : ?>
								<button type="button" class="cev-button cev-button_size_promo cev-button_type_block cev-pin-verification__button" style="margin-top: 16px;">
									<?php echo wp_kses_post( $cev_login_auth_button_label ); ?>
								</button>
							<?php endif; ?>

							<!-- Footer Message -->
							<?php
							$footer_message = cev_pro()->function->cev_pro_customizer_settings( 'cev_login_auth_widget_footer', $CEV_Customizer_Options->defaults['cev_login_auth_widget_footer'] );
							// Parse merge tags in footer message.
							if ( ! empty( $footer_message ) ) {
								$footer_message = cev_pro()->function->maybe_parse_merge_tags( $footer_message, cev_pro()->function );
								$footer_message = str_replace( '{cev_resend_verification}', $Try_again, $footer_message );
							}
							?>
							<?php if ( ! empty( $footer_message ) ) : ?>
								<footer class="cev-authorization__footer">
									<?php echo wp_kses_post( $footer_message ); ?>
								</footer>
							<?php endif; ?>
						<?php endif; ?>
					</section>
				</form>
			</div>
		</div>
	</div>
</div>
