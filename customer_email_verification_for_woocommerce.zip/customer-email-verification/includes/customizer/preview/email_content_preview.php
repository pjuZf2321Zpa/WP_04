<?php
/**
 * Customizer email-content preview wrapper.
 *
 * @package Customer_Email_Verification
 *
 * Expected variables, supplied by the including scope:
 *
 * @var CEV_Customizer $this The customizer object that included this template.
 */

// Exit if accessed directly
if ( !defined('ABSPATH') ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

?>
	<head>
		<meta charset="<?php bloginfo('charset'); ?>" />
		<meta name="viewport" content="width=device-width" />
			<style type="text/css" id="cev_designer_custom_css">.woocommerce-store-notice.demo_store, .mfp-hide {display: none;}</style>
	</head>
	<body class="cev_preview_body">
		<div id="overlay"></div>
			<div id="cev_preview_wrapper" style="display: block;">
				<?php 
				$cev_content_widget_type = cev_pro()->function->cev_pro_customizer_settings('cev_content_widget_type', cev_pro()->customizer_options->defaults['cev_content_widget_type']);
				if ( 'checkout' == $cev_content_widget_type ) {
					$this->preview_checkout_email();	
				} else {
					$this->preview_account_email();	
				}
				?>
			</div>
				<?php
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
					do_action( 'woomail_footer' );
					wp_footer(); 
				?>
	</body>
</html>
