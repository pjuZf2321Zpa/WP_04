<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$email = ( 'johny@example.com' );
$Try_again = __('Try again', 'customer-email-verification');
$CEV_Customizer_Options = new CEV_Customizer_Options();

// Header-image width and heading font-size are now --cev-popup-img-width and
// --cev-popup-heading-size, applied by cev-popup.css from the tokens on the root.
$cev_verification_hide_otp_section =  cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_hide_otp_section', $CEV_Customizer_Options->defaults['cev_verification_hide_otp_section'] );
$verification_type = get_option( 'cev_verification_type' );

// Appearance comes from the shared popup design tokens, emitted once on the
// root below — exactly as the live template does, so this preview and the
// storefront cannot drift apart. Do NOT re-add inline style attributes here.
$cev_popup_style = cev_pro()->function->popup_style_attr();
?>

<div class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">
					<section class="cev-authorization__holder">
						<?php
						/*
						 * Popup header — same helper the live template uses, so the
						 * Customizer preview shows exactly what the storefront renders:
						 * the built-in mark, or the merchant's Header Image once they
						 * set one.
						 */
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
						?>
						<div class="cev-authorization__heading">
							<span class="cev-authorization__title">
							<?php
								$heading_default = __('Verify its you.', 'customer-email-verification');
								$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header', $CEV_Customizer_Options->defaults['cev_verification_header'] ); 
							if ( !empty($heading) ) { 
								echo wp_kses_post( $heading ); 
							} else {
								echo wp_kses_post( $heading_default ); 
							}
							?>
							</span>
							<span class="cev-authorization__description">
								<?php
								// Get verification message from customizer settings (with placeholder for email).
								$verification_message = cev_pro()->function->cev_pro_customizer_settings(
									'cev_verification_message',
									__( 'We sent verification code to {customer_email}. To verify your email address, please check your inbox and enter the code below.', 'customer-email-verification' )
								);
								// Parse other merge tags (like {site_title}) but keep {customer_email} for display.
								$verification_message = cev_pro()->function->maybe_parse_merge_tags( $verification_message, cev_pro()->function );
								// Replace {customer_email} with actual email for preview.
								$verification_message = str_replace( '{customer_email}', '<strong>' . esc_html( $email ) . '</strong>', $verification_message );
								echo wp_kses_post( $verification_message );
								?>
							</span>
						</div>
						<?php if ( 0 == $cev_verification_hide_otp_section ) { ?>
								<!-- OTP Input Fields -->
											<?php 
											$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
											if ( '1' == $code_length ) {
									$otp_digits = 4;
											} else if ( '2' == $code_length ) {
									$otp_digits = 6;
											} else {
									$otp_digits = 4;
											}
											?>
								<div class="otp-container" role="group" aria-label="<?php esc_attr_e( 'Enter verification code', 'customer-email-verification' ); ?>">
									<?php for ( $i = 1; $i <= $otp_digits; $i++ ) : ?>
										<?php
										/* translators: %d: OTP digit position number */
										$aria_label = sprintf( esc_attr__( 'OTP digit %d', 'customer-email-verification' ), (int) $i );
										?>
										<input
											type="text"
											maxlength="1"
											class="otp-input" placeholder=" "
											id="otp_input_<?php echo esc_attr( $i ); ?>"
											aria-label="<?php echo esc_attr( $aria_label ); ?>"
											inputmode="numeric"
											autocomplete="one-time-code"
										/>
									<?php endfor; ?>
									</div>

								<!-- Error Message Container -->
								<div class="error_mesg" role="alert" aria-live="polite"></div>

								<?php
								// Verify Button preview (Customizer → Popup Style → Verify Button = Show).
								$cev_show_verify_button_preview = ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', 'hide' ) );
								?>
								<?php if ( $cev_show_verify_button_preview ) : ?>
									<button type="button" class="cev-button cev-button_size_promo cev-button_type_block cev-verify-otp-visible" style="margin-top: 16px;">
										<?php esc_html_e( 'Verify', 'customer-email-verification' ); ?>
									</button>
								<?php endif; ?>

								<!-- Footer Message -->
									<?php
									$CEV_Customizer_Options = new CEV_Customizer_Options();
									$footer_message = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_widget_footer', $CEV_Customizer_Options->defaults['cev_verification_widget_footer']);
								$footer_message = cev_pro()->function->maybe_parse_merge_tags( $footer_message, cev_pro()->function );
									if ( ! empty( $footer_message ) ) :
										?>
									<footer class="cev-authorization__footer">
										<?php echo wp_kses_post( $footer_message ); ?>
						</footer>
								<?php endif; ?>
							<?php } ?>
						
					</section>
			</div>
		</div>
	</div>
</div>
