<?php
/**
 * Customizer account-email preview wrapper.
 *
 * @package Customer_Email_Verification
 *
 * Expected variables, supplied by the including scope:
 *
 * @var CEV_Customizer $this The customizer object that included this template.
 */

// Exit if accessed directly
if ( !defined('ABSPATH') ) {
	exit;
}
?>
	<head>
		<meta charset="<?php bloginfo('charset'); ?>" />
		<meta name="viewport" content="width=device-width" />
			<style type="text/css" id="cev_designer_custom_css">.woocommerce-store-notice.demo_store, .mfp-hide {display: none;}</style>
	</head>
	<body class="cev_preview_body">
		<div id="overlay"></div>
			<div id="cev_preview_wrapper" style="display: block;">
				<?php $this->preview_account_email(); ?>
			</div>
				<?php
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
					do_action( 'woomail_footer' );
					wp_footer(); 
				?>
	</body>
</html>
