<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// For preview, use sample email for checkout email popup.
$email = 'johny@example.com';

$CEV_Customizer_Options = new CEV_Customizer_Options();

// Get header text - use checkout email popup header.
$heading_default = __('Verify its you.', 'customer-email-verification');
$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_header_text_checkout', $heading_default );
if ( empty( $heading ) ) {
	$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header', $heading_default );
}

// Get verification image.
$image = cev_pro()->function->cev_pro_customizer_settings('cev_verification_image', cev_pro()->plugin_dir_url() . 'assets/css/images/email-verification-icon.svg');

// Get verification message from checkout email popup customizer settings.
$verification_message = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_widget_message_checkout',
	$CEV_Customizer_Options->defaults['cev_verification_widget_message_checkout']
);
// Parse other merge tags (like {site_title}).
$verification_message = cev_pro()->function->maybe_parse_merge_tags( $verification_message, cev_pro()->function );

$cev_content_align = cev_pro()->function->cev_pro_customizer_settings( 'cev_content_align', 'center' );

// Get button text and width settings.
// Guard against missing default array key to avoid PHP warnings.
$verify_send_default = isset( $CEV_Customizer_Options->defaults['cev_verification_header_send_verify_button_text'] )
	? $CEV_Customizer_Options->defaults['cev_verification_header_send_verify_button_text']
	: __( 'Verify Your Email', 'customer-email-verification' );

$verify_send = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header_send_verify_button_text', $verify_send_default );

// Get footer message for checkout email popup.
$footer_message_checkout = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_widget_message_footer_checkout_pro',
	$CEV_Customizer_Options->defaults['cev_verification_widget_message_footer_checkout_pro']
);
// Parse merge tags in footer message.
if ( ! empty( $footer_message_checkout ) ) {
	$footer_message_checkout = cev_pro()->function->maybe_parse_merge_tags( $footer_message_checkout, cev_pro()->function );
}

// Get overlay background color for inline style.
// Popup appearance is emitted once as design tokens on the root element
// below. Single source of truth: CEV_Functions_Pro::popup_style_tokens().
$cev_popup_style = cev_pro()->function->popup_style_attr();

?>

<div class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">
				<form id="cev_verify_email" class="cev_pin_verification_form_pro" method="post">
					<section class="cev-authorization__holder">
						<!-- Verification Image -->
						<?php if ( ! empty( $image ) ) : ?>
							<?php
						// Popup header — the built-in mark, or the merchant's Header Image.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
						?>
						<?php endif; ?>

						<!-- Popup Heading and Description -->
						<div class="cev-authorization__heading">
							<span class="cev-authorization__title">
								<?php echo wp_kses_post( $heading ); ?>
							</span>
							<span class="cev-authorization__description">
								<?php echo wp_kses_post( $verification_message ); ?>
							</span>
						</div>

						<!-- Email Input Section -->
						<div class="cev-field cev-field_size_extra-large cev-field_icon_left cev-field_event_right cev-hide-success-message">
							
							<input class="cev_pin_box_email" id="cev_pin_email" name="cev_pin_email" type="email" placeholder="<?php esc_attr_e('Enter your email address', 'customer-email-verification'); ?>" required />
							
							<a href="javascript:;" class="cev_already_verify" >
								<?php esc_html_e( 'Already have verification code?', 'customer-email-verification' ); ?>
							</a>
							
							<div class="cev_send_email_tag">
								<button wp_nonce="<?php echo esc_attr( wp_create_nonce( 'wc_cev_email_guest_user' ) ); ?>" class="cev-button cev-button_color_success cev-send-verification-code" type="button">
									<?php 
									if ( !empty( $verify_send ) ) { 
										echo esc_html( $verify_send ); 
									} else {
										esc_html_e('Verify Your Email', 'customer-email-verification');
									} 
									?>
								</button>
								<div class="cev_limit_message" style="display: none;">
									<?php
									// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
									$resend_limit_message = apply_filters( 'cev_resend_limit_message', __( 'Too many attempts, please contact us for further assistance', 'customer-email-verification' ) );
									echo esc_html( $resend_limit_message );
									?>
								</div>
							</div>
						</div>

						<!-- Footer Message -->
						<?php if ( ! empty( $footer_message_checkout ) ) : ?>
							<footer class="cev-authorization__footer cev_send_email_span_tag">
								<?php echo wp_kses_post( $footer_message_checkout ); ?>
							</footer>
						<?php endif; ?>
					</section>
				</form>
			</div>
		</div>
	</div>
</div>
