<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// For preview, use sample email and show OTP popup directly.
$email = 'johny@example.com';

$CEV_Customizer_Options = new CEV_Customizer_Options();

// Get header text - use checkout OTP popup header.
$heading_default = __('Verify its you.', 'customer-email-verification');
$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_header_text_checkout_otp', $heading_default );
if ( empty( $heading ) ) {
	$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header', $heading_default );
}

// Get verification image.
$image = cev_pro()->function->cev_pro_customizer_settings('cev_verification_image', cev_pro()->plugin_dir_url() . 'assets/css/images/email-verification-icon.svg');

// Get verification message from checkout OTP popup customizer settings.
$verification_message = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_widget_message_checkout_otp',
	$CEV_Customizer_Options->defaults['cev_verification_widget_message_checkout_otp']
);
// Parse other merge tags (like {site_title}) but keep {customer_email} for display.
$verification_message = cev_pro()->function->maybe_parse_merge_tags( $verification_message, cev_pro()->function );
// Replace {customer_email} with actual email for preview.
$verification_message = str_replace( '{customer_email}', '<strong>' . esc_html( $email ) . '</strong>', $verification_message );

$cev_content_align = cev_pro()->function->cev_pro_customizer_settings( 'cev_content_align', 'center' );
$cev_verification_hide_otp_section = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_hide_otp_section', $CEV_Customizer_Options->defaults['cev_verification_hide_otp_section'] );

// Determine OTP input field count based on code length setting.
$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
if ( '1' === $code_length ) {
	$otp_digits = 4;
} elseif ( '2' === $code_length ) {
	$otp_digits = 6;
} else {
	$otp_digits = 4;
}

// Get footer message with merge tag support for checkout OTP popup.
$footer_message = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_widget_footer_checkout_otp',
	isset( $CEV_Customizer_Options->defaults['cev_verification_widget_footer_checkout_otp'] ) ? $CEV_Customizer_Options->defaults['cev_verification_widget_footer_checkout_otp'] : ''
);
// Parse merge tags in footer message if method exists.
if ( ! empty( $footer_message ) ) {
	$footer_message = cev_pro()->function->maybe_parse_merge_tags( $footer_message, cev_pro()->function );
}

// Get overlay background color for inline style.
// Popup appearance is emitted once as design tokens on the root element
// below. Single source of truth: CEV_Functions_Pro::popup_style_tokens().
$cev_popup_style = cev_pro()->function->popup_style_attr();

?>

<div class="cev-authorization-grid__visual" style="<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">
				<section class="cev-authorization__holder">
					<!-- Verification Image -->
					<?php if ( ! empty( $image ) ) : ?>
						<?php
						// Popup header — the built-in mark, or the merchant's Header Image.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email verification', 'customer-email-verification' ) );
						?>
					<?php endif; ?>

					<!-- Popup Heading and Description -->
					<div class="cev-authorization__heading">
						<span class="cev-authorization__title">
							<?php echo wp_kses_post( $heading ); ?>
						</span>
						<span class="cev-authorization__description">
							<?php echo wp_kses_post( $verification_message ); ?>
						</span>
					</div>

					<!-- OTP Input Fields -->
					<?php if ( 0 == $cev_verification_hide_otp_section ) : ?>
						<div class="otp-container" role="group" aria-label="<?php esc_attr_e( 'Enter verification code', 'customer-email-verification' ); ?>">
							<?php for ( $i = 1; $i <= $otp_digits; $i++ ) : ?>
								<?php
								/* translators: %d: OTP digit position number */
								$aria_label = sprintf( esc_attr__( 'OTP digit %d', 'customer-email-verification' ), (int) $i );
								?>
								<input
									type="text"
									maxlength="1"
									class="otp-input" placeholder=" "
									id="otp_input_<?php echo esc_attr( $i ); ?>"
									aria-label="<?php echo esc_attr( $aria_label ); ?>"
									inputmode="numeric"
									autocomplete="one-time-code"
								/>
							<?php endfor; ?>
						</div>

						<!-- Error Message Container -->
						<div class="error_mesg" role="alert" aria-live="polite"></div>

						<?php
						// Verify Button preview (Customizer → Popup Style → Verify Button = Show).
						$cev_show_verify_button_preview = ( 'show' === cev_pro()->function->cev_pro_customizer_settings( 'cev_show_verify_button', 'hide' ) );
						?>
						<?php if ( $cev_show_verify_button_preview ) : ?>
							<div class="cev_send_email_tag">
								<button id="cev_submit_pin_button" class="cev-button cev-button_color_success" type="button">
									<?php esc_html_e( 'Verify Code', 'customer-email-verification' ); ?>
								</button>
							</div>
						<?php endif; ?>

						<!-- Footer Message -->
						<?php if ( ! empty( $footer_message ) ) : ?>
							<footer class="cev-authorization__footer">
								<?php echo wp_kses_post( $footer_message ); ?>
							</footer>
						<?php endif; ?>
					<?php endif; ?>
				</section>
			</div>
		</div>
	</div>
</div>

