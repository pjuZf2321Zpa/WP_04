<?php
/**
 * AI Spam/Fraud Risk Scoring for signups & guest checkout.
 *
 * Scores each registration / checkout email (0–100) from on-device signals —
 * no external service, no API key — and blocks the sign-up when the score
 * crosses the sensitivity threshold. It plugs into the shared
 * CEV_Email_Validation chain via the `cev_email_validation_rules` filter, so
 * it runs everywhere that chain runs (signup, checkout, edit-account, Smart
 * Form) and its blocks are logged to Analytics automatically.
 *
 * Philosophy mirrors the Smart suspicious-login detection: many weighted
 * signals combine into one score, so no single benign trait blocks a real
 * customer — a block needs a genuinely risky combination.
 *
 * @package Customer_Email_Verification
 * @since 3.0.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CEV_Signup_Risk' ) ) {

	/**
	 * CEV_Signup_Risk
	 */
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Signup_Risk {

		/**
		 * Singleton instance.
		 *
		 * @var CEV_Signup_Risk|null
		 */
		private static $instance = null;

		/**
		 * Whether hooks have been registered.
		 *
		 * @var bool
		 */
		private static $hooks_registered = false;

		/**
		 * Per-request memo of assessments, keyed by md5(email|context), so the
		 * validation chain and the checkout OTP-gate never re-score the same
		 * email twice in one request.
		 *
		 * @var array
		 */
		private $assessment_cache = array();

		/**
		 * Per-request memo of which email+context pairs already logged a
		 * `signup_risk_scored` analytics event.
		 *
		 * @var array
		 */
		private $logged_cache = array();

		/**
		 * Common mailbox providers that are never treated as a "suspicious
		 * domain" — keeps false positives off ordinary customers.
		 *
		 * @var string[]
		 */
		private $common_providers = array(
			'gmail.com',
			'googlemail.com',
			'yahoo.com',
			'yahoo.co.uk',
			'ymail.com',
			'outlook.com',
			'hotmail.com',
			'hotmail.co.uk',
			'live.com',
			'msn.com',
			'icloud.com',
			'me.com',
			'mac.com',
			'aol.com',
			'protonmail.com',
			'proton.me',
			'gmx.com',
			'gmx.net',
			'zoho.com',
			'yandex.com',
			'mail.com',
			'fastmail.com',
		);

		/**
		 * Get the singleton instance.
		 *
		 * @since 3.0.2
		 * @return CEV_Signup_Risk
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Register hooks. Appends the AI rule to the email-validation chain.
		 *
		 * @since 3.0.2
		 * @return void
		 */
		public static function register() {
			if ( self::$hooks_registered ) {
				return;
			}
			self::$hooks_registered = true;

			// Run after the built-in rules (disposable / blocklist / allowlist /
			// MX) so a cheap exact-match block short-circuits before scoring.
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			add_filter( 'cev_email_validation_rules', array( self::get_instance(), 'append_rule' ), 20, 3 );
		}

		/**
		 * Whether AI risk scoring is enabled.
		 *
		 * @since 3.0.2
		 * @return bool
		 */
		public function is_enabled() {
			return 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_ai_risk_scoring', 0 );
		}

		/**
		 * Score cutoffs for the two risk bands, per the configured sensitivity:
		 * the OTP band (medium) and the block band (high).
		 *
		 * @since 3.0.2
		 * @return array { otp:int, block:int }
		 */
		private function thresholds() {
			$sensitivity = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_ai_risk_sensitivity', 'balanced' );
			$map         = array(
				'low'      => array(
					'otp'   => 55,
					'block' => 85,
				),
				'balanced' => array(
					'otp'   => 40,
					'block' => 70,
				),
				'strict'   => array(
					'otp'   => 30,
					'block' => 55,
				),
			);
			$thresholds = isset( $map[ $sensitivity ] ) ? $map[ $sensitivity ] : $map['balanced'];

			/**
			 * Filter the AI-risk score cutoffs (otp + block bands).
			 *
			 * @since 3.0.2
			 * @param array  $thresholds  { otp:int, block:int }.
			 * @param string $sensitivity Configured sensitivity (low|balanced|strict).
			 */
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$thresholds = apply_filters( 'cev_signup_risk_thresholds', $thresholds, $sensitivity );

			$otp   = isset( $thresholds['otp'] ) ? (int) $thresholds['otp'] : 40;
			$block = isset( $thresholds['block'] ) ? (int) $thresholds['block'] : 70;
			return array(
				'otp'   => $otp,
				'block' => $block,
			);
		}

		/**
		 * Configured action for the medium (OTP) risk band.
		 *
		 * @since 3.0.2
		 * @return string allow|otp|block
		 */
		private function medium_action() {
			return $this->sanitize_action(
				cev_pro()->function->cev_pro_admin_settings( 'cev_ai_risk_medium_action', 'otp' ),
				'otp'
			);
		}

		/**
		 * Configured action for the high (block) risk band.
		 *
		 * @since 3.0.2
		 * @return string allow|otp|block
		 */
		private function high_action() {
			return $this->sanitize_action(
				cev_pro()->function->cev_pro_admin_settings( 'cev_ai_risk_high_action', 'block' ),
				'block'
			);
		}

		/**
		 * Constrain an action value to the allowed set.
		 *
		 * @since 3.0.2
		 * @param mixed  $value    Raw stored value.
		 * @param string $fallback Default when invalid.
		 * @return string
		 */
		private function sanitize_action( $value, $fallback ) {
			$value = (string) $value;
			return in_array( $value, array( 'allow', 'otp', 'block' ), true ) ? $value : $fallback;
		}

		/**
		 * Assess an email: compute the score + reasons, resolve the action to
		 * take (allow / otp / block), memoize for the request, persist the
		 * latest result for the admin Risk column, and log one analytics event.
		 *
		 * @since 3.0.2
		 * @param string $email   Email address.
		 * @param string $context Validation context.
		 * @return array { score:int, reasons:string[], action:string }
		 */
		public function assess( $email, $context = 'signup' ) {
			$email = strtolower( trim( (string) $email ) );
			$key   = md5( $email . '|' . $context );
			if ( isset( $this->assessment_cache[ $key ] ) ) {
				return $this->assessment_cache[ $key ];
			}

			$risk       = $this->score( $email, $context );
			$thresholds = $this->thresholds();

			if ( $risk['score'] >= $thresholds['block'] ) {
				$action = $this->high_action();
			} elseif ( $risk['score'] >= $thresholds['otp'] ) {
				$action = $this->medium_action();
			} else {
				$action = 'allow';
			}

			$assessment = array(
				'score'   => (int) $risk['score'],
				'reasons' => (array) $risk['reasons'],
				'action'  => $action,
			);

			/**
			 * Filter the final AI-risk decision for an email.
			 *
			 * @since 3.0.2
			 * @param array  $assessment { score:int, reasons:string[], action:string }.
			 * @param string $email      Email address.
			 * @param string $context    Validation context.
			 */
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$assessment = apply_filters( 'cev_signup_risk_action', $assessment, $email, $context );

			$this->assessment_cache[ $key ] = $assessment;
			$this->store_risk( $email, $assessment );
			$this->log_scored_once( $email, $context, $assessment );

			return $assessment;
		}

		/**
		 * Whether this email lands in the "require OTP" band. Used by the
		 * checkout gate to force verification for a medium-risk guest even when
		 * the cart-level rules would otherwise skip it. A block-band email is
		 * already stopped by the validation chain, so it returns false here.
		 *
		 * @since 3.0.2
		 * @param string $email   Email address.
		 * @param string $context Validation context.
		 * @return bool
		 */
		public function requires_otp( $email, $context = 'checkout' ) {
			if ( ! $this->is_enabled() ) {
				return false;
			}
			$assessment = $this->assess( $email, $context );
			return 'otp' === $assessment['action'];
		}

		/**
		 * Append the AI rule to the validation chain (only when enabled).
		 *
		 * @since 3.0.2
		 * @param array  $rules   Existing rule callables.
		 * @param string $email   Email being validated.
		 * @param string $context Validation context.
		 * @return array
		 */
		public function append_rule( $rules, $email, $context ) {
			unset( $email, $context );
			if ( $this->is_enabled() && is_array( $rules ) ) {
				$rules[] = array( $this, 'rule_ai_risk' );
			}
			return $rules;
		}

		/**
		 * Validation rule: block the sign-up only when the resolved action is
		 * "block". The "otp" band does not block here — it is enforced by the
		 * verification flow (checkout gate / signup OTP), which is always
		 * required at or above the medium threshold anyway.
		 *
		 * @since 3.0.2
		 * @param string $email   Email address.
		 * @param string $context Validation context.
		 * @return true|WP_Error
		 */
		public function rule_ai_risk( $email, $context ) {
			$assessment = $this->assess( $email, $context );

			if ( 'block' !== $assessment['action'] ) {
				return true;
			}

			$default_message = __(
				"We couldn't verify this email address. Please use a different email or contact us for help.",
				'customer-email-verification'
			);
			$message = (string) cev_pro()->function->cev_pro_admin_message( 'cev_ai_risk_block_message', $default_message );
			if ( '' === trim( $message ) ) {
				$message = $default_message;
			}

			return new WP_Error(
				'blocked_ai_risk',
				$message,
				array(
					'email'   => $email,
					'score'   => $assessment['score'],
					'reasons' => $assessment['reasons'],
				)
			);
		}

		/**
		 * Persist the latest assessment for an email (score + reasons + action)
		 * so the admin Unverified Users Risk column can show it. Kept 7 days.
		 *
		 * @since 3.0.2
		 * @param string $email      Lowercased email.
		 * @param array  $assessment The assessment result.
		 * @return void
		 */
		private function store_risk( $email, $assessment ) {
			if ( '' === $email ) {
				return;
			}
			set_transient(
				'cev_ai_risk_' . md5( $email ),
				array(
					'score'   => (int) $assessment['score'],
					'reasons' => array_values( (array) $assessment['reasons'] ),
					'action'  => (string) $assessment['action'],
				),
				7 * DAY_IN_SECONDS
			);
		}

		/**
		 * The stored risk assessment for an email, or null if none.
		 *
		 * @since 3.0.2
		 * @param string $email Email address.
		 * @return array|null { score:int, reasons:string[], action:string }
		 */
		public static function get_stored_risk( $email ) {
			$email = strtolower( trim( (string) $email ) );
			if ( '' === $email ) {
				return null;
			}
			$data = get_transient( 'cev_ai_risk_' . md5( $email ) );
			return is_array( $data ) ? $data : null;
		}

		/**
		 * Log a single `signup_risk_scored` analytics event per email+context
		 * per request (carries the numeric score + resolved action).
		 *
		 * @since 3.0.2
		 * @param string $email      Email address.
		 * @param string $context    Validation context.
		 * @param array  $assessment The assessment result.
		 * @return void
		 */
		private function log_scored_once( $email, $context, $assessment ) {
			$key = md5( $email . '|' . $context );
			if ( isset( $this->logged_cache[ $key ] ) ) {
				return;
			}
			$this->logged_cache[ $key ] = true;

			if ( method_exists( cev_pro()->function, 'log_event' ) ) {
				cev_pro()->function->log_event(
					$email,
					'signup_risk_scored',
					$context,
					array(
						'score'   => (int) $assessment['score'],
						'action'  => (string) $assessment['action'],
						'reasons' => array_values( (array) $assessment['reasons'] ),
					)
				);
			}
		}

		/**
		 * Compute the risk score (0–100) + the reasons that contributed.
		 *
		 * @since 3.0.2
		 * @param string $email   Email address.
		 * @param string $context Validation context.
		 * @return array { score:int, reasons:string[] }
		 */
		public function score( $email, $context ) {
			$reasons = array();
			$score   = 0;

			$email = strtolower( trim( (string) $email ) );
			$at    = strpos( $email, '@' );
			$local = ( false !== $at ) ? substr( $email, 0, $at ) : $email;
			$domain = ( false !== $at ) ? substr( $email, $at + 1 ) : '';

			// 1. Gibberish local-part (random keyboard-mash mailbox).
			$points = $this->gibberish_score( $local );
			if ( $points > 0 ) {
				$score    += $points;
				$reasons[] = 'gibberish_local';
			}

			// 2. Suspicious (non-mainstream, random-looking) domain.
			$points = $this->domain_pattern_score( $domain );
			if ( $points > 0 ) {
				$score    += $points;
				$reasons[] = 'suspicious_domain';
			}

			// 3. Address shape — role mailbox or plus-address abuse.
			$points = $this->address_shape_score( $local );
			if ( $points > 0 ) {
				$score    += $points;
				$reasons[] = 'address_shape';
			}

			// 4. Sign-up velocity — many distinct emails from one IP recently.
			$points = $this->velocity_score( $email );
			if ( $points > 0 ) {
				$score    += $points;
				$reasons[] = 'signup_velocity';
			}

			$score  = min( 100, $score );
			$result = array(
				'score'   => (int) $score,
				'reasons' => $reasons,
			);

			/**
			 * Filter the computed sign-up risk (score + reasons). Lets a site
			 * add its own signals (e.g. ASN reputation) without editing core.
			 *
			 * @since 3.0.2
			 * @param array  $result  { score:int, reasons:string[] }.
			 * @param string $email   Email address.
			 * @param string $context Validation context.
			 */
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			return apply_filters( 'cev_signup_risk', $result, $email, $context );
		}

		/**
		 * Score how "random / keyboard-mash" the local-part looks (0–35).
		 * Weighted low enough that it never blocks on its own.
		 *
		 * @since 3.0.2
		 * @param string $local Local-part (before the @).
		 * @return int
		 */
		private function gibberish_score( $local ) {
			// Judge the base mailbox only (before any +tag), stripped of the
			// common human separators . _ - which structured names use.
			$core = strtok( $local, '+' );
			$core = str_replace( array( '.', '_', '-' ), '', (string) $core );
			$len  = strlen( $core );

			if ( $len < 8 ) {
				return 0; // Too short to judge reliably.
			}

			$digits = preg_match_all( '/[0-9]/', $core );
			$vowels = preg_match_all( '/[aeiou]/', $core );
			preg_match_all( '/[bcdfghjklmnpqrstvwxyz]{5,}/', $core, $runs );
			$has_long_consonant_run = ! empty( $runs[0] );

			$digit_ratio = ( $len > 0 ) ? ( $digits / $len ) : 0;
			$vowel_ratio = ( $len > 0 ) ? ( $vowels / $len ) : 0;

			$points = 0;
			if ( $has_long_consonant_run ) {
				$points += 18;
			}
			if ( $digit_ratio > 0.4 ) {
				$points += 12;
			}
			if ( $vowel_ratio < 0.2 ) {
				$points += 12; // Almost no vowels = unlikely to be a real word/name.
			}

			return (int) min( 35, $points );
		}

		/**
		 * Score a non-mainstream, random-looking domain (0–12). Kept small so
		 * legitimate business domains are never blocked on this signal alone.
		 *
		 * @since 3.0.2
		 * @param string $domain Domain part (after the @).
		 * @return int
		 */
		private function domain_pattern_score( $domain ) {
			$domain = (string) $domain;
			if ( '' === $domain || in_array( $domain, $this->common_providers, true ) ) {
				return 0;
			}

			// Look at the second-level label only (e.g. "acme" in acme.co.uk).
			$parts = explode( '.', $domain );
			$sld   = isset( $parts[0] ) ? $parts[0] : '';
			$len   = strlen( $sld );
			if ( $len < 8 ) {
				return 0;
			}

			$digits = preg_match_all( '/[0-9]/', $sld );
			preg_match_all( '/[bcdfghjklmnpqrstvwxyz]{6,}/', $sld, $runs );

			$points = 0;
			if ( ! empty( $runs[0] ) ) {
				$points += 8;
			}
			if ( $len > 0 && ( $digits / $len ) > 0.4 ) {
				$points += 8;
			}

			return (int) min( 12, $points );
		}

		/**
		 * Score the address "shape" — role mailboxes and plus-address use
		 * (0–10). Mild signals; meaningful only alongside others.
		 *
		 * @since 3.0.2
		 * @param string $local Local-part (before the @).
		 * @return int
		 */
		private function address_shape_score( $local ) {
			$points = 0;

			$base  = strtok( $local, '+' );
			$roles = array( 'admin', 'administrator', 'test', 'noreply', 'no-reply', 'postmaster', 'webmaster', 'root', 'spam' );
			if ( in_array( (string) $base, $roles, true ) ) {
				$points += 5;
			}

			if ( false !== strpos( $local, '+' ) ) {
				$points += 5;
			}

			return (int) min( 10, $points );
		}

		/**
		 * Score sign-up velocity (0–40): the number of DISTINCT emails seen
		 * from the current IP within a rolling window. Counting distinct emails
		 * (not raw calls) keeps repeated validation of the same address from
		 * inflating the score.
		 *
		 * @since 3.0.2
		 * @param string $email Email address (already lower-cased).
		 * @return int
		 */
		private function velocity_score( $email ) {
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
			if ( '' === $ip ) {
				return 0;
			}

			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$window = (int) apply_filters( 'cev_signup_risk_velocity_window', HOUR_IN_SECONDS );
			$key    = 'cev_ai_ipsignups_' . md5( $ip );
			$seen   = get_transient( $key );
			if ( ! is_array( $seen ) ) {
				$seen = array();
			}

			$hash = md5( $email );
			if ( ! in_array( $hash, $seen, true ) ) {
				$seen[] = $hash;
				// Guard against unbounded growth from a hostile IP.
				if ( count( $seen ) > 200 ) {
					$seen = array_slice( $seen, -200 );
				}
				set_transient( $key, $seen, max( 60, $window ) );
			}

			$count = count( $seen );
			if ( $count >= 7 ) {
				return 40;
			}
			if ( $count >= 4 ) {
				return 30;
			}
			if ( $count >= 2 ) {
				return 15;
			}
			return 0;
		}
	}
}
