<?php
/**
 * Bot-cluster detection for signups & guest checkout.
 *
 * Where the AI risk score (CEV_Signup_Risk) judges a single email on its own
 * merits, this rule looks for COORDINATED signup bursts — the signature of a
 * bot run rather than one bad address:
 *
 *   1. Subnet + user-agent flood — many distinct emails from one /24 IP block
 *      sharing an identical browser fingerprint in a short window (bots rotate
 *      IPs within a subnet but keep the same UA string).
 *   2. Address enumeration — john1@x, john2@x, john3@x… (same local-part stem
 *      + same domain, incrementing).
 *   3. Domain flood — a burst of signups all on the same non-mainstream domain.
 *
 * Counters live in short-lived transients (default 10-minute window) and count
 * DISTINCT emails, so re-validating the same address never inflates a cluster.
 * It plugs into the shared CEV_Email_Validation chain via the
 * `cev_email_validation_rules` filter, so blocks are logged to Analytics
 * automatically (event `blocked_bot_cluster`).
 *
 * @package Customer_Email_Verification
 * @since 3.0.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CEV_Bot_Cluster' ) ) {

	/**
	 * CEV_Bot_Cluster
	 */
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Bot_Cluster {

		/**
		 * Singleton instance.
		 *
		 * @var CEV_Bot_Cluster|null
		 */
		private static $instance = null;

		/**
		 * Whether hooks have been registered.
		 *
		 * @var bool
		 */
		private static $hooks_registered = false;

		/**
		 * Get the singleton instance.
		 *
		 * @since 3.0.2
		 * @return CEV_Bot_Cluster
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Register hooks. Appends the bot-cluster rule to the validation chain
		 * after the AI risk rule (priority 30).
		 *
		 * @since 3.0.2
		 * @return void
		 */
		public static function register() {
			if ( self::$hooks_registered ) {
				return;
			}
			self::$hooks_registered = true;

			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			add_filter( 'cev_email_validation_rules', array( self::get_instance(), 'append_rule' ), 30, 3 );
		}

		/**
		 * Whether bot-cluster detection is enabled.
		 *
		 * @since 3.0.2
		 * @return bool
		 */
		public function is_enabled() {
			return 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_bot_cluster_detection', 0 );
		}

		/**
		 * Cluster-size thresholds for the configured sensitivity.
		 *
		 * @since 3.0.2
		 * @return array { subnet:int, stem:int, domain:int }
		 */
		private function thresholds() {
			$sensitivity = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_bot_cluster_sensitivity', 'balanced' );
			$map         = array(
				'low'      => array(
					'subnet' => 8,
					'stem'   => 5,
					'domain' => 10,
				),
				'balanced' => array(
					'subnet' => 5,
					'stem'   => 4,
					'domain' => 6,
				),
				'strict'   => array(
					'subnet' => 3,
					'stem'   => 3,
					'domain' => 4,
				),
			);
			$thresholds = isset( $map[ $sensitivity ] ) ? $map[ $sensitivity ] : $map['balanced'];

			/**
			 * Filter the bot-cluster size thresholds.
			 *
			 * @since 3.0.2
			 * @param array  $thresholds  { subnet:int, stem:int, domain:int }.
			 * @param string $sensitivity Configured sensitivity.
			 */
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			return apply_filters( 'cev_bot_cluster_thresholds', $thresholds, $sensitivity );
		}

		/**
		 * Rolling window (seconds) over which a cluster is measured.
		 *
		 * @since 3.0.2
		 * @return int
		 */
		private function window() {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			$window = (int) apply_filters( 'cev_bot_cluster_window', 10 * MINUTE_IN_SECONDS );
			return max( MINUTE_IN_SECONDS, $window );
		}

		/**
		 * Append the bot-cluster rule to the validation chain (only when on).
		 *
		 * @since 3.0.2
		 * @param array  $rules   Existing rule callables.
		 * @param string $email   Email being validated.
		 * @param string $context Validation context.
		 * @return array
		 */
		public function append_rule( $rules, $email, $context ) {
			unset( $email, $context );
			if ( $this->is_enabled() && is_array( $rules ) ) {
				$rules[] = array( $this, 'rule_bot_cluster' );
			}
			return $rules;
		}

		/**
		 * Validation rule: block when this signup is part of an active cluster.
		 *
		 * @since 3.0.2
		 * @param string $email   Email address.
		 * @param string $context Validation context.
		 * @return true|WP_Error
		 */
		public function rule_bot_cluster( $email, $context ) {
			$detection = $this->evaluate( $email );

			if ( ! $detection['is_cluster'] ) {
				return true;
			}

			$default_message = __(
				'Too many signups were detected from your network. Please try again later or contact us for help.',
				'customer-email-verification'
			);
			$message = (string) cev_pro()->function->cev_pro_admin_message( 'cev_bot_cluster_message', $default_message );
			if ( '' === trim( $message ) ) {
				$message = $default_message;
			}

			return new WP_Error(
				'blocked_bot_cluster',
				$message,
				array(
					'email'   => $email,
					'signals' => $detection['signals'],
				)
			);
		}

		/**
		 * Update the rolling cluster counters with this attempt and decide
		 * whether it belongs to a bot cluster.
		 *
		 * @since 3.0.2
		 * @param string $email Email address.
		 * @return array { is_cluster:bool, signals:string[] }
		 */
		public function evaluate( $email ) {
			$signals = array();
			$email   = strtolower( trim( (string) $email ) );
			$hash    = md5( $email );

			$thresholds = $this->thresholds();
			$window     = $this->window();

			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
			$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

			// 1. Subnet + user-agent flood.
			$subnet = $this->ip_subnet( $ip );
			if ( '' !== $subnet ) {
				$count = $this->bump_distinct( 'cev_bc_net_' . md5( $subnet . '|' . $ua ), $hash, $window );
				if ( $count >= (int) $thresholds['subnet'] ) {
					$signals[] = 'subnet_ua_flood';
				}
			}

			// 2. Address enumeration (same local stem + domain, incrementing).
			$stem_key = $this->local_stem_key( $email );
			if ( '' !== $stem_key ) {
				$count = $this->bump_distinct( 'cev_bc_stem_' . md5( $stem_key ), $hash, $window );
				if ( $count >= (int) $thresholds['stem'] ) {
					$signals[] = 'address_enumeration';
				}
			}

			// 3. Domain flood (non-mainstream domain seen many times).
			$domain = $this->domain_of( $email );
			if ( '' !== $domain && ! $this->is_common_provider_domain( $domain ) ) {
				$count = $this->bump_distinct( 'cev_bc_dom_' . md5( $domain ), $hash, $window );
				if ( $count >= (int) $thresholds['domain'] ) {
					$signals[] = 'domain_flood';
				}
			}

			$result = array(
				'is_cluster' => ! empty( $signals ),
				'signals'    => $signals,
			);

			/**
			 * Filter the bot-cluster decision + signals for this attempt.
			 *
			 * @since 3.0.2
			 * @param array  $result { is_cluster:bool, signals:string[] }.
			 * @param string $email  Email address.
			 */
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
			return apply_filters( 'cev_bot_cluster_result', $result, $email );
		}

		/**
		 * Add an email hash to a rolling set stored in a transient and return
		 * the current distinct count. Counting distinct hashes (not raw hits)
		 * means repeated validation of the same address doesn't inflate it.
		 *
		 * @since 3.0.2
		 * @param string $key    Transient key.
		 * @param string $hash   Email hash to record.
		 * @param int    $window Lifetime (seconds).
		 * @return int Distinct count after recording.
		 */
		private function bump_distinct( $key, $hash, $window ) {
			$seen = get_transient( $key );
			if ( ! is_array( $seen ) ) {
				$seen = array();
			}

			if ( ! in_array( $hash, $seen, true ) ) {
				$seen[] = $hash;
				// Guard against unbounded growth from a hostile source.
				if ( count( $seen ) > 500 ) {
					$seen = array_slice( $seen, -500 );
				}
				set_transient( $key, $seen, $window );
			}

			return count( $seen );
		}

		/**
		 * IPv4 /24 subnet (first three octets) or the full IPv6 for grouping.
		 *
		 * @since 3.0.2
		 * @param string $ip Raw IP address.
		 * @return string Grouping key, or '' if unusable.
		 */
		private function ip_subnet( $ip ) {
			if ( '' === $ip ) {
				return '';
			}
			if ( false !== strpos( $ip, '.' ) ) {
				$parts = explode( '.', $ip );
				if ( count( $parts ) >= 3 ) {
					return $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.0/24';
				}
			}
			// IPv6 or unexpected shape: group on the address itself.
			return $ip;
		}

		/**
		 * Enumeration key: local-part with trailing digits stripped + domain.
		 * "john123@x" and "john124@x" collapse to the same key; a lone "john@x"
		 * (no digits) is ignored so ordinary names don't form a cluster.
		 *
		 * @since 3.0.2
		 * @param string $email Lowercased email.
		 * @return string Key, or '' when not an enumerated address.
		 */
		private function local_stem_key( $email ) {
			$at = strpos( $email, '@' );
			if ( false === $at ) {
				return '';
			}
			$local  = substr( $email, 0, $at );
			$domain = substr( $email, $at + 1 );

			// Only treat as enumeration when the local-part ENDS in digits.
			if ( ! preg_match( '/^(.*?)([0-9]{1,})$/', $local, $matches ) ) {
				return '';
			}
			$stem = $matches[1];
			if ( strlen( $stem ) < 2 ) {
				return ''; // Too short to be a meaningful stem (e.g. "a1").
			}
			return $stem . '@' . $domain;
		}

		/**
		 * Domain part of an email (lowercased).
		 *
		 * @since 3.0.2
		 * @param string $email Lowercased email.
		 * @return string
		 */
		private function domain_of( $email ) {
			$at = strrpos( $email, '@' );
			return ( false === $at ) ? '' : substr( $email, $at + 1 );
		}

		/**
		 * Well-known consumer mailbox providers — excluded from the domain-flood
		 * signal (a burst of Gmail signups is normal, not a cluster).
		 *
		 * @since 3.0.2
		 * @param string $domain Lowercased domain.
		 * @return bool
		 */
		private function is_common_provider_domain( $domain ) {
			$providers = array(
				'gmail.com',
				'googlemail.com',
				'yahoo.com',
				'yahoo.co.uk',
				'ymail.com',
				'outlook.com',
				'hotmail.com',
				'hotmail.co.uk',
				'live.com',
				'msn.com',
				'icloud.com',
				'me.com',
				'mac.com',
				'aol.com',
				'protonmail.com',
				'proton.me',
				'gmx.com',
				'gmx.net',
				'zoho.com',
				'yandex.com',
				'mail.com',
				'email.com',
				'fastmail.com',
			);
			return in_array( $domain, $providers, true );
		}
	}
}
