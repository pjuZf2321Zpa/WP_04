<?php
/**
 * Admin Settings Class for Customer Email Verification
 *
 * Handles all settings-related functionality including form rendering,
 * field definitions, AJAX save operations, and settings updates.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Load AJAX response helper class.
if ( ! class_exists( 'CEV_Ajax_Response' ) ) {
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Plugin-owned global; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
	$cev_plugin_instance = cev_pro();
	if ( $cev_plugin_instance ) {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Plugin-owned global; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$cev_plugin_path = $cev_plugin_instance->get_plugin_path();
		require_once $cev_plugin_path . '/includes/class-cev-ajax-response.php';
	}
}

/**
 * CEV_Pro_Admin_Settings Class
 *
 * Manages all admin settings for the Customer Email Verification plugin.
 * This includes defining settings fields, rendering form elements, and
 * handling AJAX requests to save settings.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Pro_Admin_Settings {

	/**
	 * Instance of this class (Singleton pattern).
	 *
	 * @var CEV_Pro_Admin_Settings
	 */
	private static $instance;

	/**
	 * Consolidated admin settings option key.
	 *
	 * All plugin settings are stored in this single serialized option.
	 *
	 * @var string
	 */
	const CONSOLIDATED_SETTINGS_OPTION = 'cev_pro_admin_settings';

	/**
	 * Verification type option name.
	 *
	 * @var string
	 */
	const VERIFICATION_TYPE_OPTION = 'cev_verification_type';

	/**
	 * Verification email body option name.
	 *
	 * @var string
	 */
	const VERIFICATION_EMAIL_BODY_OPTION = 'cev_verification_email_body';

	/**
	 * AJAX action for settings form update.
	 *
	 * @var string
	 */
	const AJAX_ACTION_UPDATE = 'cev_settings_form_update';

	/**
	 * Nonce action for settings form.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'cev_settings_form_nonce';

	/**
	 * Field types that don't require a label.
	 *
	 * @var array
	 */
	const FIELD_TYPES_WITHOUT_LABEL = array( 'desc', 'checkbox', 'checkbox_select', 'toogel', 'separator' );


	/**
	 * Checkout verification type: Popup.
	 *
	 * @var int
	 */
	const CHECKOUT_TYPE_POPUP = 1;

	/**
	 * Checkout verification type: Inline.
	 *
	 * @var int
	 */
	const CHECKOUT_TYPE_INLINE = 2;

	/**
	 * Get the singleton instance of this class.
	 *
	 * Ensures that only one instance of the class is created throughout
	 * the WordPress request lifecycle (Singleton pattern).
	 *
	 * @since 1.0.0
	 * @return CEV_Pro_Admin_Settings The single instance of this class.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Initialize hooks and filters for the plugin.
	 *
	 * Registers WordPress hooks for AJAX handlers and other functionality.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function init() {
		// Register AJAX handler for updating the main settings form.
		add_action( 'wp_ajax_' . self::AJAX_ACTION_UPDATE, array( $this, 'cev_settings_form_update_fun' ) );

		// Per-section save — each accordion in admin_options_settings.php
		// has its own Save button and POSTs to this endpoint with a
		// `cev_section` key. Only that section's settings are touched,
		// so saving "Email verification" never resets "Spam Protection"
		// (and vice-versa).
		add_action( 'wp_ajax_cev_save_section', array( $this, 'cev_save_section_fun' ) );

		// Register AJAX handler for the standalone Maintenance tab form.
		// Lives separately so saving from the Maintenance tab doesn't reset
		// other toggles (e.g. signup verification) that aren't on this form.
		add_action( 'wp_ajax_cev_maintenance_form_update', array( $this, 'cev_maintenance_form_update_fun' ) );

		// Register AJAX handler for the User Cleanup form (Task 5c).
		// Separate from the log cleanup form so saving one doesn't reset
		// the other.
		add_action( 'wp_ajax_cev_user_cleanup_form_update', array( $this, 'cev_user_cleanup_form_update_fun' ) );

		// Register AJAX handler for the Re-engagement form (Task 5d).
		// Same per-card form-isolation pattern as 5c.
		add_action( 'wp_ajax_cev_reengagement_form_update', array( $this, 'cev_reengagement_form_update_fun' ) );

		// Pre-warm endpoint. Fired silently by admin.js ~500ms after the
		// admin page loads. Its job is to wake PHP-FPM + warm opcache so
		// the user's first real Save (which used to 504 on cold workers)
		// lands on a hot stack. Handler returns instantly — no nonce, no
		// cap check, no DB writes. Safe to expose: it does nothing.
		add_action( 'wp_ajax_cev_admin_warmup', array( $this, 'cev_admin_warmup_fun' ) );
	}

	/**
	 * No-op pre-warm handler. See the registration above for context.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function cev_admin_warmup_fun() {
		wp_send_json_success( array( 'warm' => true ) );
	}

	/**
	 * AJAX handler for the Maintenance tab form.
	 *
	 * Saves ONLY the maintenance section (auto-cleanup toggle + retention
	 * dropdown). Reuses the same nonce as the main settings form so the
	 * existing JS auto-save handler works without changes.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function cev_maintenance_form_update_fun() {
		try {
			// Verify nonce — same nonce action as the main settings form.
			if ( empty( $_POST ) || ! check_admin_referer( self::NONCE_ACTION, self::NONCE_ACTION ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			// Capability check — these settings affect background jobs.
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				CEV_Ajax_Response::send_error(
					'forbidden',
					__( 'You do not have permission to update maintenance settings.', 'customer-email-verification' )
				);
				return;
			}

			// Sanitize POST.
			$sanitized_post = array();
			foreach ( $_POST as $key => $value ) {
				$clean_key = sanitize_key( $key );
				if ( is_array( $value ) ) {
					$sanitized_post[ $clean_key ] = array_map( 'sanitize_text_field', wp_unslash( $value ) );
				} else {
					$sanitized_post[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
				}
			}

			// The Maintenance tab is now a single accordion form covering
			// all three feature sections — handle them together so the
			// global Save button persists everything in one round-trip.
			$maintenance_settings  = $this->get_cev_maintenance_settings_data();
			$user_cleanup_settings = $this->get_cev_user_cleanup_settings_data();
			$reengagement_settings = $this->get_cev_reengagement_settings_data();

			// Toggle fields (auto-cleanup, auto-delete, reengagement).
			// Each toggle has a hidden input + a checkbox; we read whatever
			// arrived in POST and fall back to 0 when absent (unchecked).
			$toggle_keys = array(
				'cev_auto_cleanup_enabled',
				'cev_auto_delete_unverified_users',
				'cev_send_reengagement_emails',
			);
			foreach ( $toggle_keys as $key ) {
				if ( isset( $sanitized_post[ $key ] ) ) {
					$value = $sanitized_post[ $key ];
					if ( is_array( $value ) ) {
						$value = end( $value );
					}
					$this->update_setting( $key, $value );
				} else {
					$this->update_setting( $key, 0 );
				}
			}

			// Non-toggle fields (dropdowns, multi-selects, etc.) for all 3 sections.
			$this->update_settings( $maintenance_settings, $sanitized_post );
			$this->update_settings( $user_cleanup_settings, $sanitized_post );
			$this->update_settings( $reengagement_settings, $sanitized_post );

			CEV_Ajax_Response::send_success(
				array( 'isUpdated' => true ),
				__( 'Maintenance settings saved.', 'customer-email-verification' ),
				'settings_saved'
			);
		} catch ( Exception $e ) {
			CEV_Ajax_Response::send_server_error( $e->getMessage() );
		}
	}

	/**
	 * AJAX handler for the User Cleanup tab form (Task 5c).
	 *
	 * Saves ONLY the user-cleanup settings. Mirrors `cev_maintenance_form_update_fun`
	 * but scoped to the user-cleanup section so each card owns its own
	 * persistence and saving one card never resets the other.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function cev_user_cleanup_form_update_fun() {
		try {
			if ( empty( $_POST ) || ! check_admin_referer( self::NONCE_ACTION, self::NONCE_ACTION ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				CEV_Ajax_Response::send_error(
					'forbidden',
					__( 'You do not have permission to update user-cleanup settings.', 'customer-email-verification' )
				);
				return;
			}

			$sanitized_post = array();
			foreach ( $_POST as $key => $value ) {
				$clean_key = sanitize_key( $key );
				if ( is_array( $value ) ) {
					$sanitized_post[ $clean_key ] = array_map( 'sanitize_text_field', wp_unslash( $value ) );
				} else {
					$sanitized_post[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
				}
			}

			$user_cleanup_settings = $this->get_cev_user_cleanup_settings_data();

			// Toggle field needs special handling.
			if ( isset( $sanitized_post['cev_auto_delete_unverified_users'] ) ) {
				$value = $sanitized_post['cev_auto_delete_unverified_users'];
				if ( is_array( $value ) ) {
					$value = end( $value );
				}
				$this->update_setting( 'cev_auto_delete_unverified_users', $value );
			} else {
				$this->update_setting( 'cev_auto_delete_unverified_users', 0 );
			}

			$this->update_settings( $user_cleanup_settings, $sanitized_post );

			CEV_Ajax_Response::send_success(
				array( 'isUpdated' => true ),
				__( 'User-cleanup settings saved.', 'customer-email-verification' ),
				'settings_saved'
			);
		} catch ( Exception $e ) {
			CEV_Ajax_Response::send_server_error( $e->getMessage() );
		}
	}

	/**
	 * AJAX handler for the Re-engagement Reminder form (Task 5d).
	 *
	 * Saves ONLY the re-engagement settings (toggle + intervals).
	 * Mirrors `cev_user_cleanup_form_update_fun` pattern so the
	 * Maintenance tab's three cards stay independent.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function cev_reengagement_form_update_fun() {
		try {
			if ( empty( $_POST ) || ! check_admin_referer( self::NONCE_ACTION, self::NONCE_ACTION ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				CEV_Ajax_Response::send_error(
					'forbidden',
					__( 'You do not have permission to update re-engagement settings.', 'customer-email-verification' )
				);
				return;
			}

			$sanitized_post = array();
			foreach ( $_POST as $key => $value ) {
				$clean_key = sanitize_key( $key );
				if ( is_array( $value ) ) {
					$sanitized_post[ $clean_key ] = array_map( 'sanitize_text_field', wp_unslash( $value ) );
				} else {
					$sanitized_post[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
				}
			}

			$reengagement_settings = $this->get_cev_reengagement_settings_data();

			// Toggle.
			if ( isset( $sanitized_post['cev_send_reengagement_emails'] ) ) {
				$value = $sanitized_post['cev_send_reengagement_emails'];
				if ( is_array( $value ) ) {
					$value = end( $value );
				}
				$this->update_setting( 'cev_send_reengagement_emails', $value );
			} else {
				$this->update_setting( 'cev_send_reengagement_emails', 0 );
			}

			// Multiple-select intervals (handled by update_settings via field type).
			$this->update_settings( $reengagement_settings, $sanitized_post );

			CEV_Ajax_Response::send_success(
				array( 'isUpdated' => true ),
				__( 'Re-engagement settings saved.', 'customer-email-verification' ),
				'settings_saved'
			);
		} catch ( Exception $e ) {
			CEV_Ajax_Response::send_server_error( $e->getMessage() );
		}
	}

	/**
	 * Get the path to a view template file.
	 *
	 * @since 1.0.0
	 * @param string $template_name The name of the template file (without .php extension).
	 * @return string The full path to the template file.
	 */
	private function get_view_path( $template_name ) {
		$plugin_instance = cev_pro();
		$plugin_path     = $plugin_instance->get_plugin_path();
		return $plugin_path . '/includes/admin/views/' . $template_name . '.php';
	}

	/**
	 * Get a setting value from the consolidated settings option.
	 *
	 * Retrieves a setting value from the consolidated 'cev_pro_admin_settings' option.
	 * Falls back to individual option if migration hasn't been completed yet
	 * (backward compatibility).
	 *
	 * @since 2.9
	 * @param string $key     Setting key to retrieve.
	 * @param mixed  $default Default value if setting doesn't exist.
	 * @return mixed Setting value or default.
	 */
	private function get_setting( $key, $default = false ) {
		$consolidated_settings = get_option( self::CONSOLIDATED_SETTINGS_OPTION, array() );

		// If consolidated settings exist and key is present, return it.
		if ( is_array( $consolidated_settings ) && isset( $consolidated_settings[ $key ] ) ) {
			return $consolidated_settings[ $key ];
		}

		// Fallback to individual option for backward compatibility.
		return get_option( $key, $default );
	}

	/**
	 * Update a setting value in the consolidated settings option.
	 *
	 * Updates a setting value in the consolidated 'cev_pro_admin_settings' option.
	 * Reads existing settings, merges the new value, and saves back.
	 *
	 * @since 2.9
	 * @param string $key   Setting key to update.
	 * @param mixed  $value Value to set.
	 * @return bool True if option was updated, false otherwise.
	 */
	private function update_setting( $key, $value ) {
		$consolidated_settings = get_option( self::CONSOLIDATED_SETTINGS_OPTION, array() );

		// Ensure we have an array.
		if ( ! is_array( $consolidated_settings ) ) {
			$consolidated_settings = array();
		}

		// Update the setting value.
		$consolidated_settings[ $key ] = $value;

		// Save consolidated settings.
		return update_option( self::CONSOLIDATED_SETTINGS_OPTION, $consolidated_settings );
	}

	/**
	 * Retrieve settings data for the Signup Verification section.
	 *
	 * Returns the form field definitions for new-account registration
	 * verification. Checkout-side options live in their own section —
	 * see get_cev_checkout_verification_settings_data().
	 *
	 * @since 1.0.0
	 * @return array Array of configuration options for signup verification.
	 */
	public function get_cev_signup_verification_settings_data() {
		// Current form type drives the Template picker's initial visibility.
		$cev_signup_form_type = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_signup_form_type', 'woocommerce' );
		// Registration method + phone-field state drive the phone-field options' visibility.
		$cev_reg_method_val = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_reg_method', 'email' );
		$cev_phone_field_on = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_show_phone_field', 0 ) );

		// The SMS gateway row is needed for phone (SMS) verification OR Phone OTP login.
		$cev_login_has_phone_otp = in_array( 'phone_otp', array_map( 'trim', explode( ',', (string) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_login_method', 'password' ) ) ), true );

		// Build the signup verification settings form data.
		$form_data = array(
			// Enable signup verification toggle.
			'cev_enable_email_verification' => array(
				'type'        => 'toogel',
				'title'       => __( 'Enable Signup Verification', 'customer-email-verification' ),
				'show'        => true,
				'class'       => 'toogel',
				'name'        => 'cev_enable_email_verification',
				'id'          => 'cev_enable_email_verification',
				'Default'     => 1,
				'tooltip'     => __( 'Require email verification when users create an account.', 'customer-email-verification' ),
				'description' => __( 'Customers will need to confirm their email before completing signup.', 'customer-email-verification' ),
			),

			// Signup form type — standard WooCommerce form (current) or the
			// new ready-made Smart Form. Smart Form sub-options ship later.
			'cev_signup_form_type'          => array(
				'type'        => 'segmented',
				'title'       => __( 'Signup form type', 'customer-email-verification' ),
				'show'        => true,
				'name'        => 'cev_signup_form_type',
				'id'          => 'cev_signup_form_type',
				'Default'     => 'woocommerce',
				'options'     => array(
					'woocommerce' => __( 'WooCommerce Form', 'customer-email-verification' ),
					'smart'       => __( 'Smart Form', 'customer-email-verification' ),
				),
				'tooltip'     => __( 'WooCommerce Form keeps the default WooCommerce registration/login form. Smart Form swaps in a modern, ready-made login + registration form with built-in email/phone verification — placed with the [cev_smart_form] shortcode or by taking over the My Account page.', 'customer-email-verification' ),
				'description' => __( 'Choose the standard WooCommerce form or a modern, ready-made Smart Form.', 'customer-email-verification' ),
			),

			// --- Smart Form configuration — shown only when Smart Form is the
			// selected form type (all carry .cev-smart-only; SmartFormUI toggles them). ---

			// Placement — kept at the TOP of the Smart Form block (right under the
			// form-type toggle) as a copy-to-clipboard callout so it's the first
			// thing merchants see.
			'cev_smart_placement'           => array(
				'type'              => 'shortcode',
				'title'             => __( 'Add the Smart Form to any page', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'cev-smart-only',
				'shortcode'         => '[cev_smart_form]',
				'description'       => __( 'Paste this shortcode where you want the form to appear.', 'customer-email-verification' ),
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
			),

			// My Account takeover — when on, the Smart Form replaces the standard
			// WooCommerce login/register form on the My Account page (logged-out
			// visitors only). When off, the WC form stays and the merchant places
			// the Smart Form with the [cev_smart_form] shortcode.
			'cev_smart_takeover_myaccount'  => array(
				'type'              => 'toogel',
				'title'             => __( 'Replace the My Account page form with the Smart Form', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'toogel cev-smart-only',
				'name'              => 'cev_smart_takeover_myaccount',
				'id'                => 'cev_smart_takeover_myaccount',
				'Default'           => 0,
				'tooltip'           => __( 'On: the Smart Form takes over the My Account login/registration page. Off: the standard WooCommerce form stays and you add the Smart Form with the [cev_smart_form] shortcode.', 'customer-email-verification' ),
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
			),

			// Smart Form template picker.
			'cev_signup_smart_template'     => array(
				'type'              => 'template_picker',
				'title'             => __( 'Template', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'cev-smart-only',
				'name'              => 'cev_signup_smart_template',
				'id'                => 'cev_signup_smart_template',
				'Default'           => 'template1',
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
				'description'       => __( 'Every template shows Login and Register — template 1 uses tabs, the others switch with a link (or show both columns). Design & content for the selected template are tuned in the Customizer tab.', 'customer-email-verification' ),
			),

			// Registration verification method — single-select (email | phone).
			'cev_smart_reg_method'          => array(
				'type'              => 'toggle_select',
				'show'              => true,
				'class'             => 'cev-smart-only cev-smart-indent cev-smart-indent--first',
				'name'              => 'cev_smart_reg_method',
				'id'                => 'cev_smart_reg_method',
				'Default'           => 'email',
				'heading'           => __( 'Registration verification method', 'customer-email-verification' ),
				'tooltip'           => __( 'How a new customer proves they own their contact detail at sign-up. Email verification sends a one-time code to their email; Phone (SMS) verification sends it to their phone (needs an SMS gateway such as SMS for WooCommerce).', 'customer-email-verification' ),
				'options'           => array(
					'email' => array( 'label' => __( 'Email verification', 'customer-email-verification' ) ),
					'phone' => array(
						'label' => __( 'Phone (SMS) verification', 'customer-email-verification' ),
						'desc'  => __( 'Requires an SMS gateway (e.g. SMS for WooCommerce).', 'customer-email-verification' ),
					),
				),
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
			),

			// Phone-number field options — only relevant to EMAIL registration.
			// Phone (SMS) registration forces the field on + required (so these
			// are hidden then). The "required" toggle is revealed by JS only once
			// the field itself is enabled.
			'cev_smart_show_phone_field'    => array(
				'type'              => 'toogel',
				'title'             => __( 'Show phone number field', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'toogel cev-smart-only cev-smart-indent cev-phone-opt',
				'name'              => 'cev_smart_show_phone_field',
				'id'                => 'cev_smart_show_phone_field',
				'Default'           => 0,
				'tooltip'           => __( 'Display a phone number field on the registration form. It is always shown and required when Phone (SMS) verification is the registration method.', 'customer-email-verification' ),
				'initially_visible' => ( 'smart' === $cev_signup_form_type && 'email' === $cev_reg_method_val ) ? 'yes' : 'no',
			),

			'cev_smart_phone_required'      => array(
				'type'              => 'toogel',
				'title'             => __( 'Require the phone number', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'toogel cev-smart-only cev-smart-indent cev-phone-opt cev-phone-required-opt',
				'name'              => 'cev_smart_phone_required',
				'id'                => 'cev_smart_phone_required',
				'Default'           => 0,
				'tooltip'           => __( 'Make the phone number mandatory on the registration form.', 'customer-email-verification' ),
				'initially_visible' => ( 'smart' === $cev_signup_form_type && 'email' === $cev_reg_method_val && $cev_phone_field_on ) ? 'yes' : 'no',
			),

			// Login method — multi-select. A store can enable any combination of
			// Password, Email OTP and Phone OTP; the Smart Form login shows a tab
			// per enabled method. The stored value is a comma-separated list
			// (e.g. "password,email_otp"). phone_otp is revealed by JS only when
			// the reg method is phone. admin.js keeps at least one method on.
			'cev_smart_login_method'        => array(
				'type'              => 'toggle_select',
				'multi'             => true,
				'show'              => true,
				'class'             => 'cev-smart-only cev-smart-indent',
				'name'              => 'cev_smart_login_method',
				'id'                => 'cev_smart_login_method',
				'Default'           => 'password',
				'heading'           => __( 'Login method', 'customer-email-verification' ),
				'tooltip'           => __( 'How returning customers sign in on the Smart Form. Enable any combination: Password is the classic email/username + password; Email OTP sends a one-time code to their email (no password); Phone OTP sends the code by SMS (needs an SMS gateway), with Email OTP as the fallback for customers without a phone. When more than one is enabled, the login form shows a tab for each.', 'customer-email-verification' ),
				'options'           => array(
					'password'  => array( 'label' => __( 'Password', 'customer-email-verification' ) ),
					'email_otp' => array( 'label' => __( 'Email OTP', 'customer-email-verification' ) ),
					'phone_otp' => array(
						'label'               => __( 'Phone OTP', 'customer-email-verification' ),
						'desc'                => __( 'Requires an SMS gateway. Customers without a phone keep using the Email OTP fallback until they add one.', 'customer-email-verification' ),
						'hidden_unless_phone' => true,
					),
				),
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
			),

			// Registration password policy (Smart Form). The strong rule + minimum
			// length are enforced in BOTH smart-form.js and the server validator
			// ( CEV_Smart_Form_Ajax::is_strong_password ), which read the same policy
			// via CEV_Smart_Form::password_policy(). Strong defaults ON so existing
			// installs keep the historical rule.
			'cev_smart_require_strong_password' => array(
				'type'              => 'toogel',
				'title'             => __( 'Require a strong password', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'toogel cev-smart-only cev-smart-indent',
				'name'              => 'cev_smart_require_strong_password',
				'id'                => 'cev_smart_require_strong_password',
				'Default'           => 1,
				'tooltip'           => __( 'On: registration passwords must include upper- and lower-case letters, a number, and a symbol (plus the minimum length below). Off: only the minimum length is required, so customers can use simpler passwords.', 'customer-email-verification' ),
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
			),

			'cev_smart_password_min_length'     => array(
				'type'              => 'dropdown',
				'title'             => __( 'Minimum password length', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'cev-smart-only cev-smart-indent',
				'name'              => 'cev_smart_password_min_length',
				'id'                => 'cev_smart_password_min_length',
				'Default'           => '8',
				'options'           => array(
					'6'  => __( '6 characters', 'customer-email-verification' ),
					'8'  => __( '8 characters', 'customer-email-verification' ),
					'10' => __( '10 characters', 'customer-email-verification' ),
					'12' => __( '12 characters', 'customer-email-verification' ),
				),
				'tooltip'           => __( 'The minimum number of characters a registration password must have. Applies whether or not the strong-password rule is enabled.', 'customer-email-verification' ),
				'initially_visible' => ( 'smart' === $cev_signup_form_type ) ? 'yes' : 'no',
			),

			// SMS Gateway — provider + credentials. Shown by JS only when phone
			// verification or Phone OTP login is selected (and Smart Form is on).
			'cev_smart_sms_gateway'         => array(
				'type'              => 'sms_gateway',
				'show'              => true,
				'class'             => 'cev-smart-only cev-smart-indent cev-sms-row',
				'initially_visible' => ( 'smart' === $cev_signup_form_type && ( 'phone' === $cev_reg_method_val || $cev_login_has_phone_otp ) ) ? 'yes' : 'no',
			),
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the Checkout Verification section.
	 *
	 * Returns the form field definitions for guest/checkout email
	 * verification (type, cart-page, free-orders, cart-threshold,
	 * conditional-by-category, and the Store API toggle).
	 *
	 * @since 1.0.0
	 * @return array Array of configuration options for checkout verification.
	 */
	public function get_cev_checkout_verification_settings_data() {
		// Check if account creation during checkout is enabled.
		$create_account_during_checkout = 'yes' === get_option( 'woocommerce_enable_signup_and_login_from_checkout' );
		$checkout_dropdown_val          = absint( $this->get_setting( 'cev_verification_checkout_dropdown_option', 0 ) );

		// Define checkout verification types.
		$checkout_verification_types = array(
			self::CHECKOUT_TYPE_POPUP  => __( 'Popup', 'customer-email-verification' ),
			self::CHECKOUT_TYPE_INLINE => __( 'Inline', 'customer-email-verification' ),
		);

		// Build the checkout verification settings form data.
		$form_data = array(
			// Enable checkout verification toggle.
			'cev_enable_email_verification_checkout' => array(
				'type'        => 'toogel',
				'title'       => __( 'Enable Checkout Verification', 'customer-email-verification' ),
				'show'        => true,
				'class'       => 'toogel',
				'name'        => 'cev_enable_email_verification_checkout',
				'id'          => 'cev_enable_email_verification_checkout',
				'Default'     => 0,
				'tooltip'     => __( 'Require email verification during the checkout process.', 'customer-email-verification' ),
				'description' => __( 'Customers will need to confirm their email to place an order.', 'customer-email-verification' ),
			),

			// Checkout verification type dropdown.
			'cev_verification_checkout_dropdown_option' => array(
				'type'        => 'dropdown',
				'title'       => __( 'Checkout Verification Type', 'customer-email-verification' ),
				'options'     => $checkout_verification_types,
				'show'        => true,
				'class'       => 'cev-skip-bottom-padding',
				'tooltip'     => __( 'Select how the verification is presented to the user.', 'customer-email-verification' ),
				'description' => __( 'Choose between a popup overlay or an inline form element.', 'customer-email-verification' ),
			),
		);

		// Add conditional field for account creation during checkout.
		$form_data['cev_create_an_account_during_checkout'] = array(
			'type'             => 'toogel',
			'title'            => __( 'Require email verification only when Create an account during checkout is selected', 'customer-email-verification' ),
			'show'             => true,
			'class'            => 'toogel cev-create-account-field',
			'name'             => 'cev_create_an_account_during_checkout',
			'id'               => 'cev_create_an_account_during_checkout',
			'Default'          => 0,
			'tooltip'           => __( 'Apply verification only to new account creations at checkout.', 'customer-email-verification' ),
			'description'       => __( 'Guest checkouts will bypass email verification.', 'customer-email-verification' ),
			'initially_visible' => ( $create_account_during_checkout && self::CHECKOUT_TYPE_INLINE === $checkout_dropdown_val ) ? 'yes' : 'no',
		);

		// Enable email verification on cart page.
		$form_data['cev_enable_email_verification_cart_page'] = array(
			'type'        => 'toogel',
			'title'       => __( 'Enable the email verification on the cart page', 'customer-email-verification' ),
			'show'        => true,
			'id'          => 'cev_enable_email_verification_cart_page',
			'tooltip'     => __( 'Show verification step earlier in the funnel on the cart page.', 'customer-email-verification' ),
			'description' => __( 'Customers can verify their email before proceeding to checkout.', 'customer-email-verification' ),
		);

		// Require checkout verification only for free orders.
		$form_data['cev_enable_email_verification_free_orders'] = array(
			'type'        => 'toogel',
			'title'       => __( 'Require checkout verification only for free orders', 'customer-email-verification' ),
			'show'        => true,
			'id'          => 'cev_enable_email_verification_free_orders',
			'Default'     => 0,
			'tooltip'     => __( 'Only prompt verification when the order total is 0.', 'customer-email-verification' ),
			'description' => __( 'Ensure free orders are tied to valid email addresses.', 'customer-email-verification' ),
		);

		// Cart-Total Threshold Verification: require OTP only above a cart amount.
		// Checkbox sub-option under checkout verification (like the cart-page /
		// free-orders options) — greys out when checkout verification is off.
		$form_data['cev_enable_cart_threshold_verification'] = array(
			'type'        => 'toogel',
			'title'       => __( 'Require verification only above a cart amount', 'customer-email-verification' ),
			'show'        => true,
			'name'        => 'cev_enable_cart_threshold_verification',
			'id'          => 'cev_enable_cart_threshold_verification',
			'Default'     => 0,
			'tooltip'     => __( 'Set a minimum value before triggering verification.', 'customer-email-verification' ),
			'description' => __( 'High-value orders can require extra verification.', 'customer-email-verification' ),
		);

		// Threshold amount (shown only when the toggle above is on).
		$form_data['cev_cart_verification_threshold_amount'] = array(
			'type'              => 'text',
			'title'             => __( 'Cart amount threshold', 'customer-email-verification' ),
			'show'              => true,
			'name'              => 'cev_cart_verification_threshold_amount',
			'id'                => 'cev_cart_verification_threshold_amount',
			'Default'           => '',
			'placeholder'       => '100.00',
			'initially_visible' => 'no',
			'tooltip'           => __( 'Require OTP verification only when the cart total exceeds this amount, in your store base currency. Leaves small purchases frictionless. Enter a plain number, e.g. 100.00. Leave blank to keep verification on for every cart.', 'customer-email-verification' ),
		);

		// Threshold metric — compare against subtotal or total.
		$form_data['cev_cart_verification_threshold_metric'] = array(
			'type'              => 'dropdown',
			'title'             => __( 'Compare against', 'customer-email-verification' ),
			'options'           => array(
				'subtotal' => __( 'Cart subtotal', 'customer-email-verification' ),
				'total'    => __( 'Cart total', 'customer-email-verification' ),
			),
			'show'              => true,
			'name'              => 'cev_cart_verification_threshold_metric',
			'id'                => 'cev_cart_verification_threshold_metric',
			'Default'           => 'subtotal',
			'initially_visible' => 'no',
			'tooltip'           => __( 'Subtotal excludes shipping and taxes; total includes them.', 'customer-email-verification' ),
		);

		// Conditional Verification by product category — a checkout sub-option
		// (only relevant when Checkout Verification is enabled; JS gates it).
		$form_data = array_merge( $form_data, $this->get_cev_conditional_verification_settings_data() );

		// Separator.
		$form_data['cev_settings_separator_10'] = array(
			'type' => 'separator',
			'id'   => 'cev_settings_separator_10',
			'show' => true,
		);

		// Disable WooCommerce Store API Checkout.
		$form_data['cev_disable_wooCommerce_store_api'] = array(
			'type'        => 'toogel',
			'title'       => __( 'Disable WooCommerce Store API Checkout', 'customer-email-verification' ),
			'show'        => true,
			'class'       => 'toogel',
			'name'        => 'cev_disable_wooCommerce_store_api',
			'id'          => 'cev_disable_wooCommerce_store_api',
			'Default'     => 0,
			'tooltip'     => __( 'Prevents blocks-based checkout where verification may not hook correctly.', 'customer-email-verification' ),
			'description' => __( 'Use if you rely entirely on the classic shortcode checkout.', 'customer-email-verification' ),
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the Spam Protection section.
	 *
	 * Houses two independently-toggleable pre-flight rules that run before
	 * an OTP email is generated:
	 *
	 *   1. Disposable / temporary email blocking (built-in list + additional
	 *      admin-defined domains).
	 *   2. MX record validation (DNS check confirming the email's domain
	 *      has a mail server, with a 24-hour transient cache per domain).
	 *
	 * Both rules respect a shared "Excluded domains" allowlist — any domain
	 * in that list is never blocked, regardless of either rule.
	 *
	 * @since 2.10.0
	 * @return array Form field definitions for the Spam Protection section.
	 */
	public function get_cev_spam_protection_settings_data() {
		$form_data = array();

		// ── Disposable / temporary email blocking ─────────────────────

		// Toggle: block disposable / temporary email addresses.
		$form_data['cev_block_disposable_emails'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Block disposable / temporary emails', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_block_disposable_emails',
			'id'      => 'cev_block_disposable_emails',
			'Default' => 0,
			'tooltip' => __( 'Reject signups and guest checkouts using known temporary email services (mailinator, 10minutemail, tempmail, etc.).', 'customer-email-verification' ),
		);

		// Description with "View built-in list" link (opens .txt in new tab).
		$built_in_list_url = cev_pro()->plugin_dir_url() . 'assets/data/disposable-domains.txt';
		$form_data['cev_disposable_built_in_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_disposable_built_in_desc',
			'show' => true,
			'html' => sprintf(
				/* translators: %s: link to view the built-in disposable domains list. */
				esc_html__( 'Built-in list contains 430+ known disposable email domains. %s', 'customer-email-verification' ),
				'<a href="' . esc_url( $built_in_list_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View built-in list ↗', 'customer-email-verification' ) . '</a>'
			),
		);

		// Textarea: additional blocked domains (added ON TOP of built-in list).
		// Wildcard support: `*.ru` blocks all .ru subdomains.
		$form_data['cev_disposable_custom_domains'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Additional blocked domains', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 4,
			'placeholder' => "spamdomain.com\nbaddomain.net\n*.ru",
			'tooltip'     => __( 'One domain per line. Blocked in addition to the built-in list. Wildcard supported: "*.ru" blocks every .ru domain. Lines starting with # are comments.', 'customer-email-verification' ),
			'Default'     => '',
		);

		// Textarea: excluded domains (always allowed; overrides the built-in
		// + additional blocked list above). Lives inside the disposable
		// feature block — hides/shows with the Disposable toggle.
		// Wildcard support: `*.acme.com` excludes every subdomain of acme.com.
		$form_data['cev_disposable_excluded_domains'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Excluded domains (always allowed)', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 4,
			'placeholder' => "trusteddomain.com\nclient-domain.com\n*.acme.com",
			'tooltip'     => __( 'One domain per line. Always allowed, even if on the built-in or additional blocked list. Wildcard supported: "*.acme.com" excludes every subdomain of acme.com. Useful for whitelisting corporate domains or fixing false positives.', 'customer-email-verification' ),
			'Default'     => '',
		);

		// Textarea: rejection message shown to the customer (disposable).
		$form_data['cev_disposable_block_message'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Disposable rejection message', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 1,
			'placeholder' => __( "Disposable email addresses aren't allowed. Please use a permanent address.", 'customer-email-verification' ),
			'tooltip'     => __( 'Message shown to the customer when their email is blocked as disposable.', 'customer-email-verification' ),
			'Default'     => '',
		);

		// Sub-toggle: heuristic (AI) disposable detection — catches throwaway
		// domains that aren't on the static list, by pattern. Part of the
		// disposable feature block, so it hides/shows with the master toggle.
		$form_data['cev_disposable_heuristic'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Also catch unknown disposable domains (AI pattern match)', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel cev_disposable_heuristic',
			'name'    => 'cev_disposable_heuristic',
			'id'      => 'cev_disposable_heuristic',
			'Default' => 0,
			'tooltip' => __( 'On top of the built-in list of 430+ domains, detect throwaway / temporary email domains by pattern — new temp-mail services that follow the usual naming (tempmail-new.xyz, trashbox24.info, etc.). Common providers (Gmail, Outlook, iCloud…) and your excluded domains are never affected. Uses the same rejection message above.', 'customer-email-verification' ),
		);

		// Separator between disposable and MX feature blocks.
		$form_data['cev_settings_separator_spam_1'] = array(
			'type' => 'separator',
			'id'   => 'cev_settings_separator_spam_1',
			'show' => true,
		);

		// ── MX record validation ──────────────────────────────────────

		// Toggle: validate email domain has an MX record.
		$form_data['cev_validate_mx'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Validate email domain (MX check)', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_validate_mx',
			'id'      => 'cev_validate_mx',
			'Default' => 0,
			'tooltip' => __( 'Confirm the email\'s domain has a mail server before generating an OTP. Catches typos like gmial.com, fake bot domains, and dead inboxes. Off by default — DNS lookups can be slow on some hosts.', 'customer-email-verification' ),
		);

		// Description for the MX feature.
		$form_data['cev_mx_check_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_mx_check_desc',
			'show' => true,
			'html' => esc_html__( 'Performs a fast DNS lookup to confirm the email\'s domain has a mail server. Results are cached for 24 hours per domain so repeat signups don\'t pay the lookup cost twice.', 'customer-email-verification' ),
		);

		// Textarea: rejection message shown to the customer (MX failure).
		$form_data['cev_mx_fail_message'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'MX rejection message', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 1,
			'placeholder' => __( "We couldn't deliver mail to that domain. Please check the address.", 'customer-email-verification' ),
			'tooltip'     => __( "Message shown to the customer when their email's domain has no mail server (typo, fake domain, or dead inbox).", 'customer-email-verification' ),
			'Default'     => '',
		);

		// Separator before B2B Allowlist (Task 3).
		$form_data['cev_settings_separator_spam_2'] = array(
			'type' => 'separator',
			'id'   => 'cev_settings_separator_spam_2',
			'show' => true,
		);

		// ── B2B Allowlist (Task 3a) ───────────────────────────────────
		// Restrictive: when ON + non-empty list, only listed domains
		// can sign up. Independent toggle and message — different
		// mental model from the personal email ban list below.

		$form_data['cev_enable_b2b_allowlist'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Restrict signups to specific domains (B2B mode)', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_enable_b2b_allowlist',
			'id'      => 'cev_enable_b2b_allowlist',
			'Default' => 0,
			'tooltip' => __( 'When enabled with a non-empty Allowlist, ONLY the listed domains can sign up. Perfect for B2B / wholesale stores limiting signups to partner companies. Leave the Allowlist empty to disable the gate without flipping the toggle.', 'customer-email-verification' ),
		);

		$form_data['cev_b2b_allowlist_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_b2b_allowlist_desc',
			'show' => true,
			'html' => esc_html__( 'Lock signups to specific domains. Wildcards supported: "*.acme.com" matches every subdomain of acme.com.', 'customer-email-verification' ),
		);

		$form_data['cev_domain_allowlist'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Allowed domains (only these can sign up)', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 4,
			'placeholder' => "acme.com\npartner-corp.com\n*.acme.com",
			'tooltip'     => __( 'One domain per line. Leave EMPTY to disable the gate (no restriction). When non-empty, ONLY listed domains can sign up. Wildcard supported: "*.acme.com" matches subdomains. Lines starting with # are comments.', 'customer-email-verification' ),
			'Default'     => '',
		);

		$form_data['cev_domain_allowlist_message'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Allowlist rejection message', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 1,
			'placeholder' => __( 'Sign-ups are restricted to specific company domains. Please contact us for access.', 'customer-email-verification' ),
			'tooltip'     => __( 'Message shown when a customer\'s email domain is not in the Allowlist.', 'customer-email-verification' ),
			'Default'     => '',
		);

		// Separator between Allowlist and Blocked emails.
		$form_data['cev_settings_separator_spam_3'] = array(
			'type' => 'separator',
			'id'   => 'cev_settings_separator_spam_3',
			'show' => true,
		);

		// ── Blocked Email Addresses (Task 3b) ─────────────────────────
		// Additive: ban specific people regardless of their domain.
		// Independent toggle + message from the B2B allowlist above.

		$form_data['cev_enable_blocked_emails'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Block specific email addresses', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_enable_blocked_emails',
			'id'      => 'cev_enable_blocked_emails',
			'Default' => 0,
			'tooltip' => __( 'Personal ban list. Enter exact email addresses to block them permanently. Useful for scrapers, abusers, or banned customers who keep re-signing up.', 'customer-email-verification' ),
		);

		$form_data['cev_blocked_emails_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_blocked_emails_desc',
			'show' => true,
			'html' => esc_html__( 'Block specific people by their full email address (exact match). Wildcards are NOT supported here — use the Disposable "Additional blocked domains" field above for domain-level blocks.', 'customer-email-verification' ),
		);

		$form_data['cev_blocked_emails'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Blocked email addresses', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 4,
			'placeholder' => "scraper@competitor.com\nbanned-customer@gmail.com",
			'tooltip'     => __( 'One full email address per line. Exact match only. Useful for permanently banning specific abusers, scrapers, or customers. Lines starting with # are comments. Invalid email lines are silently skipped.', 'customer-email-verification' ),
			'Default'     => '',
		);

		$form_data['cev_blocked_emails_message'] = array(
			'type'        => 'textarea',
			'inline'      => true,
			'title'       => __( 'Blocked email rejection message', 'customer-email-verification' ),
			'show'        => true,
			'rows'        => 1,
			'placeholder' => __( 'This email address is not allowed at our store.', 'customer-email-verification' ),
			'tooltip'     => __( 'Message shown when a customer\'s email is on the personal ban list.', 'customer-email-verification' ),
			'Default'     => '',
		);

		// Separator before AI risk scoring.
		$form_data['cev_settings_separator_spam_3'] = array(
			'type' => 'separator',
			'id'   => 'cev_settings_separator_spam_3',
			'show' => true,
		);

		// ── AI spam / fraud risk scoring ──────────────────────────────
		// Scores each signup / guest-checkout email from many on-device
		// signals (no external service) and blocks only when the combined
		// score crosses the sensitivity threshold.
		$ai_risk_on = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_ai_risk_scoring', 0 ) );

		$form_data['cev_ai_risk_scoring'] = array(
			'type'    => 'toogel',
			'title'   => __( 'AI spam & fraud risk scoring', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel cev_ai_risk_scoring',
			'name'    => 'cev_ai_risk_scoring',
			'id'      => 'cev_ai_risk_scoring',
			'Default' => 0,
			'tooltip' => __( 'Score every signup and guest-checkout email from many on-device signals — random-looking mailbox, suspicious domain, role/plus-address shape, and signup velocity from the same IP — and block it only when the combined risk is high. Runs locally with no external service. Off by default.', 'customer-email-verification' ),
		);

		// Description for the AI risk feature.
		$form_data['cev_ai_risk_desc'] = array(
			'type'              => 'desc',
			'id'                => 'cev_ai_risk_desc',
			'show'              => true,
			'initially_visible' => $ai_risk_on ? 'yes' : 'no',
			'html'              => esc_html__( 'Combines several weak signals into a single 0–100 score so no single trait blocks a real customer — a block needs a genuinely risky combination. Nothing leaves your server.', 'customer-email-verification' ),
		);

		// Sensitivity for AI risk scoring (shown only when the feature is on).
		// Sets the two score cutoffs (medium/OTP band + high/block band).
		$form_data['cev_ai_risk_sensitivity'] = array(
			'type'              => 'dropdown',
			'title'             => __( 'Risk sensitivity', 'customer-email-verification' ),
			'options'           => array(
				'low'      => __( 'Low — only clearly risky signups', 'customer-email-verification' ),
				'balanced' => __( 'Balanced (recommended)', 'customer-email-verification' ),
				'strict'   => __( 'Strict — act on weaker combinations', 'customer-email-verification' ),
			),
			'show'              => true,
			'id'                => 'cev_ai_risk_sensitivity',
			'Default'           => 'balanced',
			'class'             => 'cev-ai-risk-sensitivity',
			'initially_visible' => $ai_risk_on ? 'yes' : 'no',
			'tooltip'           => __( 'How readily a signup is acted on. Lower = fewer false positives (only obvious spam); higher = acts on weaker signal combinations. This sets the medium and high score cutoffs.', 'customer-email-verification' ),
		);

		// Action at the medium (OTP) risk band.
		$form_data['cev_ai_risk_medium_action'] = array(
			'type'              => 'dropdown',
			'title'             => __( 'At medium risk', 'customer-email-verification' ),
			'options'           => array(
				'allow' => __( 'Allow', 'customer-email-verification' ),
				'otp'   => __( 'Require a one-time code', 'customer-email-verification' ),
				'block' => __( 'Block', 'customer-email-verification' ),
			),
			'show'              => true,
			'id'                => 'cev_ai_risk_medium_action',
			'Default'           => 'otp',
			'class'             => 'cev-ai-risk-medium-action',
			'initially_visible' => $ai_risk_on ? 'yes' : 'no',
			'tooltip'           => __( 'What to do when a signup or guest checkout scores in the medium risk band. Default: require a one-time email code.', 'customer-email-verification' ),
		);

		// Action at the high (block) risk band.
		$form_data['cev_ai_risk_high_action'] = array(
			'type'              => 'dropdown',
			'title'             => __( 'At high risk', 'customer-email-verification' ),
			'options'           => array(
				'allow' => __( 'Allow', 'customer-email-verification' ),
				'otp'   => __( 'Require a one-time code', 'customer-email-verification' ),
				'block' => __( 'Block', 'customer-email-verification' ),
			),
			'show'              => true,
			'id'                => 'cev_ai_risk_high_action',
			'Default'           => 'block',
			'class'             => 'cev-ai-risk-high-action',
			'initially_visible' => $ai_risk_on ? 'yes' : 'no',
			'tooltip'           => __( 'What to do when a signup or guest checkout scores in the high risk band. Default: block with the message below.', 'customer-email-verification' ),
		);

		// Textarea: rejection message shown to the customer (AI risk block).
		$form_data['cev_ai_risk_block_message'] = array(
			'type'              => 'textarea',
			'inline'            => true,
			'title'             => __( 'Risk block rejection message', 'customer-email-verification' ),
			'show'              => true,
			'rows'              => 1,
			'initially_visible' => $ai_risk_on ? 'yes' : 'no',
			'placeholder'       => __( "We couldn't verify this email address. Please use a different email or contact us for help.", 'customer-email-verification' ),
			'tooltip'           => __( 'Message shown to the customer when their signup is blocked by the risk score.', 'customer-email-verification' ),
			'Default'           => '',
		);

		// Separator before bot-cluster detection.
		$form_data['cev_settings_separator_spam_4'] = array(
			'type' => 'separator',
			'id'   => 'cev_settings_separator_spam_4',
			'show' => true,
		);

		// ── Bot-cluster detection ─────────────────────────────────────
		// Detects coordinated signup bursts (subnet + user-agent floods,
		// address enumeration, single-domain floods) within a short window.
		$bot_cluster_on = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_bot_cluster_detection', 0 ) );

		$form_data['cev_bot_cluster_detection'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Bot signup-cluster detection', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel cev_bot_cluster_detection',
			'name'    => 'cev_bot_cluster_detection',
			'id'      => 'cev_bot_cluster_detection',
			'Default' => 0,
			'tooltip' => __( 'Detect coordinated signup bursts rather than judging one email at a time — many signups from the same network sharing a browser fingerprint, sequential addresses (john1@, john2@…), or a flood on a single domain within a few minutes. Blocks attempts that match an active cluster. Runs locally with no external service. Off by default.', 'customer-email-verification' ),
		);

		// Description for the bot-cluster feature.
		$form_data['cev_bot_cluster_desc'] = array(
			'type'              => 'desc',
			'id'                => 'cev_bot_cluster_desc',
			'show'              => true,
			'initially_visible' => $bot_cluster_on ? 'yes' : 'no',
			'html'              => esc_html__( 'Counts are kept in memory for a rolling few-minute window and only count distinct emails, so normal traffic and common providers (Gmail, Outlook…) are never grouped into a cluster.', 'customer-email-verification' ),
		);

		// Sensitivity for bot-cluster detection (shown only when enabled).
		$form_data['cev_bot_cluster_sensitivity'] = array(
			'type'              => 'dropdown',
			'title'             => __( 'Cluster sensitivity', 'customer-email-verification' ),
			'options'           => array(
				'low'      => __( 'Low — only large, obvious bursts', 'customer-email-verification' ),
				'balanced' => __( 'Balanced (recommended)', 'customer-email-verification' ),
				'strict'   => __( 'Strict — block on smaller clusters', 'customer-email-verification' ),
			),
			'show'              => true,
			'id'                => 'cev_bot_cluster_sensitivity',
			'Default'           => 'balanced',
			'class'             => 'cev-bot-cluster-sensitivity',
			'initially_visible' => $bot_cluster_on ? 'yes' : 'no',
			'tooltip'           => __( 'How many matching signups form a "cluster" before new ones are blocked. Lower = only large bursts; higher = smaller clusters trip the block sooner.', 'customer-email-verification' ),
		);

		// Textarea: rejection message shown to the customer (bot cluster).
		$form_data['cev_bot_cluster_message'] = array(
			'type'              => 'textarea',
			'inline'            => true,
			'title'             => __( 'Cluster block rejection message', 'customer-email-verification' ),
			'show'              => true,
			'rows'              => 1,
			'initially_visible' => $bot_cluster_on ? 'yes' : 'no',
			'placeholder'       => __( 'Too many signups were detected from your network. Please try again later or contact us for help.', 'customer-email-verification' ),
			'tooltip'           => __( 'Message shown to the customer when their signup is blocked as part of a detected bot cluster.', 'customer-email-verification' ),
			'Default'           => '',
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the Advanced section.
	 *
	 * Houses power-user / behaviour-changing options that don't belong with
	 * the day-to-day verification or spam-protection settings.
	 *
	 * Currently: Paid-Order Gatekeeping — holds a user's fully-verified state
	 * until their first genuinely paid order completes. Until then they are
	 * "verified, pending paid order": email proven, but no coupon access /
	 * promotional triggers (the welcome email still goes out at registration).
	 * Stops spam signups that verify only to harvest signup perks and never buy.
	 *
	 * @since 2.10.0
	 * @return array Form field definitions for the Advanced section.
	 */
	public function get_cev_advanced_settings_data() {
		$form_data = array();

		$form_data['cev_enable_paid_order_gatekeeping'] = array(
			'type'        => 'toogel',
			'title'       => __( 'Require a paid order to finish verification', 'customer-email-verification' ),
			'show'        => true,
			'class'       => 'toogel',
			'name'        => 'cev_enable_paid_order_gatekeeping',
			'id'          => 'cev_enable_paid_order_gatekeeping',
			'Default'     => 0,
			'tooltip'     => __( 'When enabled, a verified customer is kept in a "pending paid order" state — counted as verified for login and checkout, but not fully activated — until their first genuinely paid order completes. A completion hook (cev_paid_order_gatekeeping_completed) then fires so your own coupon / marketing integrations can release any perks they hold back. The welcome email still goes out at registration. Off by default.', 'customer-email-verification' ),
			'description' => __( 'The customer can still log in and check out normally — their account stays in a "pending paid order" state (verified, but not fully activated) until their first genuinely paid order completes. Free / zero-total orders do not satisfy the requirement.', 'customer-email-verification' ),
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the Conditional Verification section.
	 *
	 * Require checkout OTP only when the cart contains a flagged product
	 * category. Composes with the Cart-Total Threshold via OR logic.
	 *
	 * @since 2.10.0
	 * @return array Array of conditional-verification field definitions.
	 */
	public function get_cev_conditional_verification_settings_data() {
		$form_data = array();

		$form_data['cev_enable_conditional_verification_by_category'] = array(
			'type'        => 'toogel',
			'title'       => __( 'Require verification only for flagged product categories', 'customer-email-verification' ),
			'show'        => true,
			'name'        => 'cev_enable_conditional_verification_by_category',
			'id'          => 'cev_enable_conditional_verification_by_category',
			'Default'     => 0,
			'tooltip'     => __( 'Limit verification to specific sensitive product categories.', 'customer-email-verification' ),
			'description' => __( 'Useful for digital goods, gift cards, or age-restricted items.', 'customer-email-verification' ),
		);

		// Build the product-category options for the multi-select.
		$category_options = array();
		if ( function_exists( 'taxonomy_exists' ) && taxonomy_exists( 'product_cat' ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'hide_empty' => false,
				)
			);
			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( isset( $term->term_id, $term->name ) ) {
						$category_options[ (string) $term->term_id ] = $term->name;
					}
				}
			}
		}

		$is_on = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_conditional_verification_by_category', 0 ) );

		$form_data['cev_required_verification_categories'] = array(
			'type'              => 'multiple_select',
			'title'             => __( 'Categories that require verification', 'customer-email-verification' ),
			'options'           => $category_options,
			'show'              => true,
			'name'              => 'cev_required_verification_categories',
			'id'                => 'cev_required_verification_categories',
			'Default'           => '',
			'initially_visible' => $is_on ? 'yes' : 'no',
			'tooltip'           => __( 'Only require OTP verification when the cart contains items from these categories. Leaves low-risk checkouts frictionless.', 'customer-email-verification' ),
		);

		$form_data['cev_conditional_category_message'] = array(
			'type'              => 'category_messages',
			'title'             => __( 'Per-category verification message (optional)', 'customer-email-verification' ),
			'show'              => true,
			'id'                => 'cev_conditional_category_message',
			'initially_visible' => $is_on ? 'yes' : 'no',
		);

		return $form_data;
	}

	/**
	 * Retrieve general settings data for email verification.
	 *
	 * Returns an array of form field definitions for general verification
	 * settings including OTP length, expiration, resend limits, and messages.
	 *
	 * @since 1.0.0
	 * @return array Array of general configuration options.
	 */
	public function get_cev_general_settings_data() {
		// Define OTP length options.
		$otp_lengths = array(
			'1' => __( '4-digit', 'customer-email-verification' ),
			'2' => __( '6-digit', 'customer-email-verification' ),
		);

		// Define OTP expiration options (in seconds).
		$otp_expirations = array(
			'never'   => __( 'Never', 'customer-email-verification' ),
			'600'     => __( '10 min', 'customer-email-verification' ),
			'900'     => __( '15 min', 'customer-email-verification' ),
			'1800'    => __( '30 min', 'customer-email-verification' ),
			'3600'    => __( '1 Hour', 'customer-email-verification' ),
			'86400'   => __( '24 Hours', 'customer-email-verification' ),
			'259200'  => __( '72 Hours', 'customer-email-verification' ),
		);

		// Define resend limit options.
		$resend_limits = array(
			'1' => __( 'Allow 1 Attempt', 'customer-email-verification' ),
			'3' => __( 'Allow 3 Attempts', 'customer-email-verification' ),
			'0' => __( 'Disable Resend', 'customer-email-verification' ),
		);

		// Build form data array.
		$form_data = array(
			// OTP length dropdown.
			'cev_verification_code_length' => array(
				'type'    => 'dropdown',
				'title'   => __( 'OTP Length', 'customer-email-verification' ),
				'options' => $otp_lengths,
				'show'    => true,
				'tooltip' => __( 'Number of digits in the one-time code sent to customers — 4 is quicker to type, 6 is harder to guess.', 'customer-email-verification' ),
			),

			// OTP expiration dropdown.
			'cev_verification_code_expiration' => array(
				'type'    => 'dropdown',
				'title'   => __( 'OTP Expiration', 'customer-email-verification' ),
				'options' => $otp_expirations,
				'show'    => true,
				'tooltip' => __( 'Choose if you wish to set expiry time to the OTP.', 'customer-email-verification' ),
			),

			// Separator for visual separation.
			'cev_settings_separator_3' => array(
				'type' => 'separator',
				'id'   => 'cev_settings_separator_3',
				'show' => true,
			),

			// Resend limit dropdown.
			'cev_redirect_limit_resend' => array(
				'type'    => 'dropdown',
				'title'   => __( 'Verification Email Resend Limit', 'customer-email-verification' ),
				'options' => $resend_limits,
				'show'    => true,
				'class'   => 'redirect_page',
				'tooltip' => __( 'How many times a customer can request a fresh code before resending is blocked — protects against email/SMS flooding.', 'customer-email-verification' ),
			),

			// Resend limit message textarea.
			'cev_resend_limit_message' => array(
				'type'        => 'textarea',
				'inline'      => true,
				'title'       => __( 'Resend Limit Message', 'customer-email-verification' ),
				'show'        => true,
				'rows'        => 1,
				'tooltip'     => __( 'Limit the number of resend attempts.', 'customer-email-verification' ),
				'placeholder' => __( 'Too many attempts, please contact us for further assistance', 'customer-email-verification' ),
				'Default'     => '',
				'class'       => 'cev_text_design top',
			),

			// Email verification success message.
			'cev_verification_success_message' => array(
				'type'        => 'textarea',
				'inline'      => true,
				'title'       => __( 'Email Verification Success Message', 'customer-email-verification' ),
				'show'        => true,
				'rows'        => 1,
				'tooltip'     => __( 'Message shown after successful verification.', 'customer-email-verification' ),
				'placeholder' => __( 'Your email is verified!', 'customer-email-verification' ),
				'Default'     => '',
			),
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the Maintenance section.
	 *
	 * Houses background-hygiene options that don't belong in the
	 * functional verification flow:
	 *
	 *   - Auto-cleanup of stale unverified records (cron-driven).
	 *
	 * Default state: feature OFF — existing installs upgrade with
	 * zero behavior change.
	 *
	 * @since 2.10.0
	 * @return array Form field definitions for the Maintenance section.
	 */
	public function get_cev_maintenance_settings_data() {
		$form_data = array();

		// Toggle: enable the daily auto-cleanup cron.
		$form_data['cev_auto_cleanup_enabled'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Auto-cleanup unverified records', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_auto_cleanup_enabled',
			'id'      => 'cev_auto_cleanup_enabled',
			'Default' => 0,
			'tooltip' => __( 'Automatically delete pending (unverified) records that have been sitting in the verification log past the retention window below. Verified records are never deleted. Helps keep the table from growing unbounded under bot traffic and supports basic GDPR / data-retention compliance out of the box.', 'customer-email-verification' ),
		);

		// Description for the auto-cleanup feature.
		$form_data['cev_auto_cleanup_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_auto_cleanup_desc',
			'show' => true,
			'html' => esc_html__( 'Runs once per day in the background. Only PENDING records are deleted — verified records stay forever as proof of verification.', 'customer-email-verification' ),
		);

		// Dropdown: how many days to keep pending entries before deletion.
		$retention_options = array(
			'1'  => __( '1 day', 'customer-email-verification' ),
			'3'  => __( '3 days', 'customer-email-verification' ),
			'7'  => __( '7 days', 'customer-email-verification' ),
			'14' => __( '14 days (recommended)', 'customer-email-verification' ),
			'30' => __( '30 days', 'customer-email-verification' ),
			'60' => __( '60 days', 'customer-email-verification' ),
			'90' => __( '90 days', 'customer-email-verification' ),
		);
		$form_data['cev_auto_cleanup_pending_days'] = array(
			'type'    => 'dropdown',
			'title'   => __( 'Delete pending records after', 'customer-email-verification' ),
			'options' => $retention_options,
			'show'    => true,
			'tooltip' => __( 'Pending records older than this are deleted on the next daily cleanup run. We recommend 14 days — enough time for a distracted customer to come back and finish, but not so long that bots pile up.', 'customer-email-verification' ),
			'Default' => '14',
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the User Cleanup section (Task 5c).
	 *
	 * SEPARATE from the log-table cleanup because this one is destructive
	 * — it deletes actual WP user accounts. Lives in its own card on the
	 * Maintenance tab so the difference is unambiguous.
	 *
	 * Skip rules (built into the runner — NOT user-configurable for safety):
	 *   - Users with any orders are never deleted
	 *   - Users with active subscriptions are never deleted
	 *   - Users with elevated roles (admin, editor, etc.) are never deleted
	 *   - Users with recent login (last 30 days) are never deleted
	 *   - Already-verified users are never deleted
	 *
	 * @since 2.10.0
	 * @return array Form field definitions for user cleanup.
	 */
	public function get_cev_user_cleanup_settings_data() {
		$form_data = array();

		// Toggle: enable auto-delete of unverified WP user accounts.
		$form_data['cev_auto_delete_unverified_users'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Auto-delete unverified user accounts', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_auto_delete_unverified_users',
			'id'      => 'cev_auto_delete_unverified_users',
			'Default' => 0,
			'tooltip' => __( 'Permanently deletes WP user accounts that never verified their email. DESTRUCTIVE. Has built-in safeguards: verified users, users with orders, active subscriptions, elevated roles, or recent login activity are never deleted.', 'customer-email-verification' ),
		);

		// Description listing the safeguards so admins can see them inline.
		$form_data['cev_auto_delete_unverified_users_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_auto_delete_unverified_users_desc',
			'show' => true,
			'html' => esc_html__( 'Skip rules (always applied): verified users, users with any orders, active subscriptions, non-customer roles, or login activity in the last 30 days are never deleted.', 'customer-email-verification' ),
		);

		// Dropdown: retention window (minimum 30 days hard-floored server-side).
		$user_retention_options = array(
			'30'  => __( '30 days', 'customer-email-verification' ),
			'60'  => __( '60 days', 'customer-email-verification' ),
			'90'  => __( '90 days (recommended)', 'customer-email-verification' ),
			'180' => __( '180 days', 'customer-email-verification' ),
			'365' => __( '365 days', 'customer-email-verification' ),
		);
		$form_data['cev_auto_delete_unverified_users_days'] = array(
			'type'    => 'dropdown',
			'title'   => __( 'Delete after', 'customer-email-verification' ),
			'options' => $user_retention_options,
			'show'    => true,
			'tooltip' => __( 'Account-age threshold for deletion. Minimum is 30 days (enforced server-side). 90 days is recommended — long enough for genuine customers to verify late, short enough to keep the user table clean.', 'customer-email-verification' ),
			'Default' => '90',
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for the Re-engagement Reminder section (Task 5d).
	 *
	 * Lives on the Maintenance tab as a third card. The email body itself
	 * is customized via the email customizer (Re-engagement Reminder type)
	 * — this card only carries the on/off + intervals toggle.
	 *
	 * Default intervals: 24h + 7d (industry-standard cadence; long enough
	 * to avoid feeling spammy, short enough that a real customer hasn't
	 * forgotten the brand).
	 *
	 * @since 2.10.0
	 * @return array Form field definitions for the re-engagement section.
	 */
	public function get_cev_reengagement_settings_data() {
		$form_data = array();

		// Toggle: enable re-engagement reminders.
		$form_data['cev_send_reengagement_emails'] = array(
			'type'    => 'toogel',
			'title'   => __( 'Send re-engagement reminder emails', 'customer-email-verification' ),
			'show'    => true,
			'class'   => 'toogel',
			'name'    => 'cev_send_reengagement_emails',
			'id'      => 'cev_send_reengagement_emails',
			'Default' => 0,
			'tooltip' => __( 'Email registered users who never finished verifying — at the configured intervals after sign-up — to bring them back. The email content is fully customizable through the email customizer.', 'customer-email-verification' ),
		);

		$form_data['cev_reengagement_desc'] = array(
			'type' => 'desc',
			'id'   => 'cev_reengagement_desc',
			'show' => true,
			'html' => esc_html__( 'A reminder is sent at most once per interval per user, capped at 50 sends per cron run. Customize the email subject, heading, body and CTA button via the email customizer.', 'customer-email-verification' ),
		);

		// Multi-select: intervals after signup at which to send a reminder.
		$form_data['cev_reengagement_intervals'] = array(
			'type'    => 'multiple_select',
			'title'   => __( 'Send reminder at', 'customer-email-verification' ),
			'options' => array(
				'1h'  => __( '1 hour after sign-up', 'customer-email-verification' ),
				'24h' => __( '24 hours after sign-up', 'customer-email-verification' ),
				'3d'  => __( '3 days after sign-up', 'customer-email-verification' ),
				'7d'  => __( '7 days after sign-up', 'customer-email-verification' ),
			),
			'show'    => true,
			'name'    => 'cev_reengagement_intervals',
			'id'      => 'cev_reengagement_intervals',
			'tooltip' => __( 'Each user gets at most one email per interval, ever. Pick whatever cadence matches your brand voice.', 'customer-email-verification' ),
			'Default' => '',
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for login OTP configuration.
	 *
	 * Returns an array of form field definitions for login authentication
	 * settings including OTP verification for unrecognized logins and
	 * conditions for triggering verification.
	 *
	 * @since 1.0.0
	 * @return array Array of settings configuration for login OTP.
	 */
	public function get_cev_settings_data_login_otp() {
		// When Smart suspicious-login detection is on, it replaces the fixed
		// "Unrecognized Login Conditions" — those rows start hidden and the
		// sensitivity selector starts shown (admin.js keeps them in sync live).
		$smart_on = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_smart_login_detection', 0 ) );

		// "Require OTP on every login" overrides everything below it — when it is
		// on, every other condition row is hidden because none of them can change
		// the outcome. Rows stay hidden (not disabled) so their saved values still
		// POST and survive a save untouched.
		$every_login_on = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_require_otp_every_login', 0 ) );

		// Visibility of the conditions block, resolved once for the first paint.
		$show_conditions  = ( ! $every_login_on && ! $smart_on ) ? 'yes' : 'no';
		$show_sensitivity = ( ! $every_login_on && $smart_on ) ? 'yes' : 'no';
		$show_when_manual = $every_login_on ? 'no' : 'yes';

		// Build form data array.
		$form_data = array(
			// Toggle for enabling login authentication.
			'cev_enable_login_authentication' => array(
				'type'    => 'toogel',
				'title'   => __( 'Enable Login Authentication', 'customer-email-verification' ),
				'show'    => true,
				'class'   => 'toogel cev_enable_login_authentication',
				'name'    => 'cev_enable_login_authentication',
				'id'      => 'cev_enable_login_authentication',
				'value'   => '1',
				'tooltip' => __( 'Master switch. When on, returning customers may be asked for a one-time code at login based on the risk conditions below.', 'customer-email-verification' ),
			),

			// Challenge every single login, ignoring every condition below.
			// Overrides the unrecognized-login conditions and Smart detection.
			'cev_require_otp_every_login' => array(
				'type'    => 'toogel',
				'title'   => __( 'Require OTP on every login', 'customer-email-verification' ),
				'show'    => true,
				'class'   => 'toogel cev_require_otp_every_login',
				'name'    => 'cev_require_otp_every_login',
				'id'      => 'cev_require_otp_every_login',
				'Default' => 0,
				'tooltip' => __( 'Ask every customer for a one-time code at every login, ignoring the conditions below. Administrators, editors and shop managers are never prompted.', 'customer-email-verification' ),
			),

			// Checkbox for requiring OTP verification for unrecognized logins.
			'enable_email_otp_for_account' => array(
				'type'              => 'toogel',
				'title'             => __( 'Require OTP verification for unrecognized login', 'customer-email-verification' ),
				'show'              => true,
				'id'                => 'enable_email_otp_for_account',
				'Default'           => 1,
				'class'             => 'cev-login-cond-block',
				'initially_visible' => $show_when_manual,
				'tooltip'           => __( 'Ask for a one-time code only when a sign-in looks unfamiliar (matching the conditions below), instead of on every login.', 'customer-email-verification' ),
			),

			// Smart suspicious-login detection. When on, a risk score (built
			// from new device, new location, failed-password bursts and idle
			// time) decides when to challenge — replacing the fixed conditions.
			'cev_smart_login_detection' => array(
				'type'              => 'toogel',
				'title'             => __( 'Smart suspicious-login detection', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'toogel cev_smart_login_detection cev-login-cond-block',
				'name'              => 'cev_smart_login_detection',
				'id'                => 'cev_smart_login_detection',
				'Default'           => 0,
				'initially_visible' => $show_when_manual,
				'tooltip'           => __( 'Instead of firing on every device or location change, score each sign-in and only ask for a code when it looks genuinely risky (new device, new country, failed-password bursts, or a long idle period). This replaces the manual conditions below.', 'customer-email-verification' ),
			),

			// Sensitivity for Smart detection (shown only when Smart is on).
			'cev_smart_login_sensitivity' => array(
				'type'              => 'dropdown',
				'title'             => __( 'Detection sensitivity', 'customer-email-verification' ),
				'options'           => array(
					'low'      => __( 'Low — only clearly risky sign-ins', 'customer-email-verification' ),
					'balanced' => __( 'Balanced (recommended)', 'customer-email-verification' ),
					'strict'   => __( 'Strict — challenge on weaker signals', 'customer-email-verification' ),
				),
				'show'              => true,
				'id'                => 'cev_smart_login_sensitivity',
				'Default'           => 'balanced',
				'class'             => 'cev-smart-login-sensitivity cev-login-cond-block',
				'initially_visible' => $show_sensitivity,
				'tooltip'           => __( 'How readily a sign-in is challenged. Lower = fewer codes for real customers; higher = more codes, catching weaker signals.', 'customer-email-verification' ),
			),

			// Separator for visual separation.
			'cev_settings_separator_4' => array(
				'type' => 'separator',
				'id'   => 'cev_settings_separator_4',
				'show' => true,
			),

			// Description for unrecognized login conditions.
			'login_auth_desc' => array(
				'type'              => 'desc',
				'title'             => __( 'Unrecognized Login Conditions:', 'customer-email-verification' ),
				'show'              => true,
				'id'                => 'login_auth_desc',
				'class'             => 'cev-manual-login-cond cev-login-cond-block',
				'initially_visible' => $show_conditions,
			),

			// Checkbox for login authentication based on new device.
			'enable_email_auth_for_new_device' => array(
				'type'              => 'toogel',
				'title'             => __( 'Login from a new device', 'customer-email-verification' ),
				'show'              => true,
				'id'                => 'enable_email_auth_for_new_device',
				'Default'           => 1,
				'class'             => 'cev-manual-login-cond cev-login-cond-block',
				'initially_visible' => $show_conditions,
				'tooltip'           => __( 'Trigger a one-time code when the customer signs in from a browser or device not seen before.', 'customer-email-verification' ),
			),

			// Checkbox for login authentication based on new location.
			'enable_email_auth_for_new_location' => array(
				'type'              => 'toogel',
				'title'             => __( 'Login from a new location', 'customer-email-verification' ),
				'show'              => true,
				'id'                => 'enable_email_auth_for_new_location',
				'Default'           => 1,
				'class'             => 'cev-manual-login-cond cev-login-cond-block',
				'initially_visible' => $show_conditions,
				'tooltip'           => __( 'Trigger a one-time code when the customer signs in from a new IP address or location.', 'customer-email-verification' ),
			),

			// Checkbox select for login authentication based on last login time.
			'enable_email_auth_for_login_time' => array(
				'type'   => 'checkbox_select',
				'title'  => __( 'Last login more than', 'customer-email-verification' ),
				'select' => array(
					'options' => array(
						15 => __( '15 Days', 'customer-email-verification' ),
						30 => __( '30 Days', 'customer-email-verification' ),
						60 => __( '60 Days', 'customer-email-verification' ),
					),
					'id' => 'cev_last_login_more_then_time',
				),
				'show'              => true,
				'id'                => 'enable_email_auth_for_login_time',
				'Default'           => 1,
				'class'             => 'enable_email_auth_for_login_time cev-manual-login-cond cev-login-cond-block',
				'initially_visible' => $show_conditions,
				'tooltip'           => __( 'Trigger a one-time code when the customer has not logged in for longer than the selected period.', 'customer-email-verification' ),
			),

			// Separator before the force-verify-on-login control. Hides with that
			// control so no stray rule is left at the foot of the card.
			'cev_settings_separator_login_reverify' => array(
				'type'              => 'separator',
				'id'                => 'cev_settings_separator_login_reverify',
				'show'              => true,
				'class'             => 'cev-login-cond-block',
				'initially_visible' => $show_when_manual,
			),

			// Require unverified logged-in customers to verify their email.
			// Powers the "verify on next login" prompt that Tools → Force
			// re-verify relies on.
			// Hidden while "Require OTP on every login" is on: that option already
			// challenges unverified customers at login and records the
			// verification, so this switch cannot change the outcome. The runtime
			// treats every-login as implying it (see
			// CEV_Functions_Pro::should_prompt_account_verify()), which is what
			// makes hiding it safe rather than a silent gap.
			'cev_require_verify_unverified_login' => array(
				'type'              => 'toogel',
				'title'             => __( 'Require unverified logged-in customers to verify', 'customer-email-verification' ),
				'show'              => true,
				'class'             => 'toogel cev-login-cond-block',
				'name'              => 'cev_require_verify_unverified_login',
				'id'                => 'cev_require_verify_unverified_login',
				'Default'           => 0,
				'initially_visible' => $show_when_manual,
				'tooltip'           => __( 'When on, a logged-in customer whose email is not verified is shown a verification popup on the front-end until they confirm their email. Pairs with Tools → "Force re-verify all customers".', 'customer-email-verification' ),
			),

			'cev_require_verify_unverified_login_desc' => array(
				'type'              => 'desc',
				'id'                => 'cev_require_verify_unverified_login_desc',
				'show'              => true,
				'class'             => 'cev-login-cond-block',
				'initially_visible' => $show_when_manual,
				'html'              => esc_html__( 'Administrators, editors and shop managers are never prompted.', 'customer-email-verification' ),
			),
		);

		return $form_data;
	}

	/**
	 * Retrieve settings data for Two-Factor Authentication (2FA).
	 *
	 * Lives in its own settings section — separate from Login Authentication
	 * — so role-based enforcement (and future Authenticator-app support) is
	 * managed in one focused place rather than mixed in with the legacy
	 * email-OTP login auth toggles.
	 *
	 * For now this section just owns the role-based scoping policy that
	 * decides WHICH users must complete 2FA. Phase 2 (TOTP authenticator
	 * apps, recovery codes, etc.) will add to this same group.
	 *
	 * @since 2.10.0
	 * @return array Form field definitions for the 2FA section.
	 */
	public function get_cev_2fa_settings_data() {
		// Build a {role_key => label} map of every WP role for the
		// enforcement policy multi-select. translate_user_role() localises
		// the human-readable label without changing the role slug.
		$role_options = array();
		if ( function_exists( 'wp_roles' ) ) {
			$role_options = wp_roles()->get_names();
			$role_options = array_map( 'translate_user_role', $role_options );
		}

		// The Roles multi-select only means something for the two role-based
		// policies — "All users" ignores roles entirely. Resolve its
		// visibility once here so the first paint is already correct (admin.js
		// keeps it in sync live as the dropdown / master toggle change).
		$cev_2fa_on     = ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_2fa', 0 ) );
		$cev_2fa_policy = cev_pro()->function->cev_pro_admin_settings( 'cev_login_auth_enforcement', 'excluded_roles' );
		$show_2fa_roles = ( $cev_2fa_on && 'all_users' !== $cev_2fa_policy ) ? 'yes' : 'no';

		$form_data = array(
			// Section description — Authenticator-App only, no email OTP here.
			'cev_2fa_intro' => array(
				'type' => 'desc',
				'id'   => 'cev_2fa_intro',
				'show' => true,
				'html' => esc_html__( 'Let users add an extra layer of security with an Authenticator App (Google Authenticator, Authy, Microsoft Authenticator, 1Password, etc.). Setup is optional — anyone the policy applies to will see a "Set up 2FA" card on their account page, but no one is ever forced to enrol or blocked from logging in.', 'customer-email-verification' ),
			),

			// Master toggle — enables the 2FA Authenticator App flow site-wide.
			// Defaults to OFF so existing installs upgrade silently.
			'cev_enable_2fa' => array(
				'type'  => 'toogel',
				'title' => __( 'Enable Authenticator App 2FA', 'customer-email-verification' ),
				'show'  => true,
				'class' => 'toogel cev_enable_2fa',
				'name'  => 'cev_enable_2fa',
				'id'    => 'cev_enable_2fa',
				'value' => '1',
			),

			// Visibility policy — decides which users SEE the
			// "Set up 2FA" option on their account page. Setup is
			// optional even for these users; the policy just hides
			// the UI for users it doesn't apply to so they aren't
			// bothered.
			'cev_login_auth_enforcement' => array(
				'type'    => 'dropdown',
				'title'   => __( 'Show 2FA option to', 'customer-email-verification' ),
				'options' => array(
					'all_users'      => __( 'All users', 'customer-email-verification' ),
					'roles_only'     => __( 'Only users with selected roles', 'customer-email-verification' ),
					'excluded_roles' => __( 'All users EXCEPT selected roles', 'customer-email-verification' ),
				),
				'show'    => true,
				'tooltip' => __( 'Pick which users see the Authenticator-App setup card on their account page. Setup is OPTIONAL — no user is ever forced to enrol or blocked from logging in. "Only users with selected roles" is useful when you want to offer 2FA to staff (Administrator / Editor) but keep it hidden from shoppers.', 'customer-email-verification' ),
				'Default' => 'excluded_roles',
			),

			// Roles multi-select — paired with the dropdown above.
			'cev_login_auth_roles' => array(
				'type'              => 'multiple_select',
				'inline'            => true,
				'title'             => __( 'Roles', 'customer-email-verification' ),
				'options'           => $role_options,
				'show'              => true,
				'name'              => 'cev_login_auth_roles',
				'id'                => 'cev_login_auth_roles',
				'initially_visible' => $show_2fa_roles,
				'tooltip'           => __( 'The roles the policy above applies to. Default selection is Administrator + Editor (matches the legacy behaviour).', 'customer-email-verification' ),
				'Default'           => '',
			),

			// Trust period — after a user enters their 6-digit code
			// successfully, the same browser/device is "remembered"
			// for this many days and won't be re-prompted until the
			// period elapses. 0 = always ask at every login.
			'cev_2fa_grace_days' => array(
				'type'    => 'dropdown',
				'title'   => __( 'Remember this device for', 'customer-email-verification' ),
				'options' => array(
					'0'  => __( "Don't remember — ask for code every login", 'customer-email-verification' ),
					'1'  => __( '1 day', 'customer-email-verification' ),
					'3'  => __( '3 days', 'customer-email-verification' ),
					'7'  => __( '7 days (recommended)', 'customer-email-verification' ),
					'14' => __( '14 days', 'customer-email-verification' ),
					'30' => __( '30 days', 'customer-email-verification' ),
				),
				'show'    => true,
				'tooltip' => __( 'After a successful 2FA verification, skip the 6-digit code prompt on the same browser/device for this many days. The user will be asked for a code again on the first login after this period elapses, or any time they sign in from a different browser/device.', 'customer-email-verification' ),
				'Default' => '7',
			),
		);

		return $form_data;
	}

	/**
	 * Generate HTML for the settings fields based on the provided settings array.
	 *
	 * Renders form fields in an unordered list structure, handling different
	 * field types (dropdown, checkbox, toggle, textarea, etc.) and applying
	 * conditional logic for visibility and disabled states.
	 *
	 * @since 1.0.0
	 * @param array $fields Settings fields array with field definitions.
	 * @return void
	 */
	public function render_settings_fields( $fields, $wrap_card = true ) {
		// Prepare disabled states for all fields.
		$disabled_states = array();

		// Include settings fields list template.
		$template_path = $this->get_view_path( 'fields/settings-fields-list' );
		if ( file_exists( $template_path ) ) {
			$field_types_without_label = self::FIELD_TYPES_WITHOUT_LABEL;
			$settings_instance = $this;
			$cev_wrap_card     = (bool) $wrap_card;
			include $template_path;
		}
	}


	/**
	 * Render field label with optional tooltip.
	 *
	 * @since 1.0.0
	 * @param array  $field    Field definition array.
	 * @param string $disabled Disabled state attribute.
	 * @return void
	 */
	private function render_field_label( $field, $disabled ) {
		$template_path = $this->get_view_path( 'fields/field-label' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render field based on its type.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @param string $disabled Disabled state attribute.
	 * @return void
	 */
	public function render_field_by_type( $field_id, $field, $disabled ) {
		switch ( $field['type'] ) {
			case 'dropdown':
				$this->render_dropdown_field( $field_id, $field, $disabled );
				break;

			case 'segmented':
				$this->render_segmented_field( $field_id, $field );
				break;

			case 'template_picker':
				$this->render_template_picker_field( $field_id, $field );
				break;

			case 'shortcode':
				$this->render_shortcode_field( $field_id, $field );
				break;

			case 'toggle_select':
				$this->render_toggle_select_field( $field_id, $field );
				break;

			case 'sms_gateway':
				$this->render_sms_gateway_field( $field_id, $field );
				break;

			case 'multiple_select':
				$this->render_multiple_select_field( $field_id, $field );
				break;

			case 'checkbox':
				$this->render_checkbox_field( $field_id, $field, $disabled );
				break;

			case 'toogel':
				$this->render_toggle_field( $field_id, $field );
				break;

			case 'textarea':
				$this->render_textarea_field( $field_id, $field );
				break;

			case 'checkbox_select':
				$this->render_checkbox_select_field( $field_id, $field, $disabled );
				break;

			case 'desc':
				$this->render_description_field( $field_id, $field, $disabled );
				break;

			case 'separator':
				$this->render_separator();
				break;

			case 'category_messages':
				$this->render_category_messages_field( $field_id, $field );
				break;

			default:
				$this->render_text_input_field( $field_id, $field );
				break;
		}
	}

	/**
	 * Render the per-category verification-message fields.
	 *
	 * Outputs one labelled textarea per currently-flagged category, stored as
	 * a { term_id: message } map. The admin JS adds/removes rows live as the
	 * category multi-select changes; this server render covers the saved
	 * selection on page load.
	 *
	 * @since 2.10.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	private function render_category_messages_field( $field_id, $field ) {
		$selected = cev_pro()->function->cev_pro_get_required_categories();
		$messages = cev_pro()->function->cev_pro_admin_settings( 'cev_conditional_category_message', array() );
		if ( ! is_array( $messages ) ) {
			$messages = array();
		}
		?>
		<div class="cev-category-messages" data-cev-category-messages>
			<?php
			foreach ( $selected as $term_id ) {
				$term = get_term( (int) $term_id, 'product_cat' );
				if ( ! $term || is_wp_error( $term ) ) {
					continue;
				}
				$value = isset( $messages[ $term_id ] ) ? (string) $messages[ $term_id ] : '';
				?>
				<div class="zui-field" data-cev-cat-id="<?php echo esc_attr( $term_id ); ?>">
					<label class="zui-field__label"><?php echo esc_html( $term->name ); ?></label>
					<textarea class="zui-textarea zui-field__input" rows="2" name="cev_conditional_category_message[<?php echo esc_attr( $term_id ); ?>]" placeholder="<?php esc_attr_e( 'Optional message shown when this category requires verification', 'customer-email-verification' ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Persist the per-category verification messages as a { term_id: message }
	 * map. Values arrive already sanitized from the section-save handler.
	 *
	 * @since 2.10.0
	 * @param string $key     The field key.
	 * @param array  $request The (sanitized) request data.
	 * @return void
	 */
	private function update_category_messages_field( $key, $request ) {
		$messages = array();
		if ( isset( $request[ $key ] ) && is_array( $request[ $key ] ) ) {
			foreach ( $request[ $key ] as $term_id => $msg ) {
				$messages[ (int) $term_id ] = sanitize_text_field( (string) $msg );
			}
		}

		$this->update_setting( $key, $messages );
	}

	/**
	 * Render description field.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @param string $disabled Disabled state attribute.
	 * @return void
	 */
	private function render_description_field( $field_id, $field, $disabled ) {
		$template_path = $this->get_view_path( 'fields/field-description' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render separator element.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function render_separator() {
		$template_path = $this->get_view_path( 'fields/field-separator' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render checkbox_select field.
	 *
	 * Renders a checkbox with an associated select dropdown, typically used
	 * for conditional settings with multiple options.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @param string $disabled Disabled state attribute.
	 * @return void
	 */
	public function render_checkbox_select_field( $field_id, $field, $disabled ) {
		$template_path = $this->get_view_path( 'fields/field-checkbox-select' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render dropdown field.
	 *
	 * Renders a select dropdown with options from the field definition.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @param string $disabled Disabled state attribute.
	 * @return void
	 */
	public function render_dropdown_field( $field_id, $field, $disabled ) {
		$template_path = $this->get_view_path( 'fields/field-dropdown' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render a segmented control (pill toggle) field.
	 *
	 * @since 2.10.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_segmented_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-segmented' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render the Smart Form template picker (radio cards with wireframes).
	 *
	 * @since 2.10.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_template_picker_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-template-picker' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render a read-only shortcode chip (e.g. the Smart Form placement code).
	 *
	 * @since 2.10.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_shortcode_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-shortcode' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render a single-select toggle group (radio-as-toggles).
	 *
	 * @since 2.10.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_toggle_select_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-toggle-select' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render the Smart Form SMS Gateway section (provider + credentials).
	 *
	 * @since 2.10.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_sms_gateway_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-sms-gateway' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Persist the SMS Gateway fields. Each credential input is named after its
	 * own setting key; the two toggles write 1/0 based on presence.
	 *
	 * @since 2.10.0
	 * @param array $request Sanitised POST data.
	 * @return void
	 */
	private function update_sms_gateway_field( $request ) {
		$text_keys = array(
			'cev_sms_provider',
			'cev_sms_wa_access_token',
			'cev_sms_wa_namespace',
			'cev_sms_wa_sender',
			'cev_sms_wa_header_image_url',
			'cev_sms_twilio_account_sid',
			'cev_sms_twilio_auth_token',
			'cev_sms_twilio_send_via',
			'cev_sms_twilio_phone',
			'cev_sms_twilio_messaging_service_sid',
			'cev_sms_vonage_key',
			'cev_sms_vonage_secret',
			'cev_sms_vonage_sender',
			'cev_sms_msg91_auth_key',
			'cev_sms_msg91_sender',
		);
		foreach ( $text_keys as $sms_key ) {
			if ( isset( $request[ $sms_key ] ) ) {
				$this->update_setting( $sms_key, $request[ $sms_key ] );
			}
		}
		$this->update_setting( 'cev_sms_wa_header_image', isset( $request['cev_sms_wa_header_image'] ) ? 1 : 0 );
		$this->update_setting( 'cev_sms_msg91_use_dlt', isset( $request['cev_sms_msg91_use_dlt'] ) ? 1 : 0 );
	}

	/**
	 * Render multiple select field.
	 *
	 * Renders a multi-select dropdown for selecting multiple options,
	 * typically used for role selection.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_multiple_select_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-multiple-select' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render checkbox field.
	 *
	 * Renders a standard checkbox input with label.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @param string $disabled Disabled state attribute.
	 * @return void
	 */
	public function render_checkbox_field( $field_id, $field, $disabled ) {
		$template_path = $this->get_view_path( 'fields/field-checkbox' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render toggle field.
	 *
	 * Renders a toggle switch (styled checkbox) with label.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_toggle_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-toggle' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render textarea field.
	 *
	 * Renders a textarea input with optional placeholder.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_textarea_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-textarea' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Render text input field.
	 *
	 * Renders a standard text input with optional placeholder.
	 *
	 * @since 1.0.0
	 * @param string $field_id Field ID.
	 * @param array  $field    Field definition array.
	 * @return void
	 */
	public function render_text_input_field( $field_id, $field ) {
		$template_path = $this->get_view_path( 'fields/field-text-input' );
		if ( file_exists( $template_path ) ) {
			include $template_path;
		}
	}

	/**
	 * Handle AJAX request to update Customer Email Verification settings form.
	 *
	 * Verifies nonce, sanitizes input, and updates all settings fields
	 * including general settings, login OTP settings, and verification
	 * email body based on verification type.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function cev_settings_form_update_fun() {
		try {
			// Verify nonce for security.
			if ( empty( $_POST ) || ! check_admin_referer( self::NONCE_ACTION, self::NONCE_ACTION ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			// Capability check — plugin settings are a store-admin action.
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				CEV_Ajax_Response::send_error(
					'forbidden',
					__( 'You do not have permission to update these settings.', 'customer-email-verification' )
				);
				return;
			}

			// Build set of textarea-type fields so we sanitize them with sanitize_textarea_field
			// (which preserves newlines) instead of sanitize_text_field (which strips them).
			$textarea_keys = array();
			foreach ( array_merge(
				$this->get_cev_signup_verification_settings_data(),
				$this->get_cev_checkout_verification_settings_data(),
				$this->get_cev_spam_protection_settings_data(),
				$this->get_cev_general_settings_data(),
				$this->get_cev_settings_data_login_otp(),
				$this->get_cev_maintenance_settings_data()
			) as $field_key => $field_def ) {
				if ( isset( $field_def['type'] ) && 'textarea' === $field_def['type'] ) {
					$textarea_keys[ $field_key ] = true;
				}
			}

			// Sanitize POST data after nonce verification.
			$sanitized_post = array();
			foreach ( $_POST as $key => $value ) {
				$clean_key = sanitize_key( $key );
				if ( is_array( $value ) ) {
					$sanitized_post[ $clean_key ] = array_map( 'sanitize_text_field', wp_unslash( $value ) );
				} elseif ( isset( $textarea_keys[ $clean_key ] ) ) {
					$sanitized_post[ $clean_key ] = sanitize_textarea_field( wp_unslash( $value ) );
				} else {
					$sanitized_post[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
				}
			}

			// Fetch all settings data.
			$signup_settings         = $this->get_cev_signup_verification_settings_data();
			$checkout_settings       = $this->get_cev_checkout_verification_settings_data();
			$spam_protection         = $this->get_cev_spam_protection_settings_data();
			$login_otp_settings      = $this->get_cev_settings_data_login_otp();
			$two_factor_settings     = $this->get_cev_2fa_settings_data();
			$general_settings_data   = $this->get_cev_general_settings_data();
			$maintenance_settings    = $this->get_cev_maintenance_settings_data();
			$advanced_settings       = $this->get_cev_advanced_settings_data();

			// Update toggle/select fields that need special handling.
			$this->update_toggle_fields( $sanitized_post );

			// Update all settings sections.
			$this->update_settings( $signup_settings, $sanitized_post );
			$this->update_settings( $checkout_settings, $sanitized_post );
			$this->update_settings( $spam_protection, $sanitized_post );
			$this->update_settings( $login_otp_settings, $sanitized_post );
			$this->update_settings( $two_factor_settings, $sanitized_post );
			$this->update_settings( $general_settings_data, $sanitized_post );
			$this->update_settings( $maintenance_settings, $sanitized_post );
			$this->update_settings( $advanced_settings, $sanitized_post );

			// Update verification email body based on verification type.
			$this->update_verification_email_body( $sanitized_post );

			// Send success response.
			CEV_Ajax_Response::send_success(
				array( 'isUpdated' => true ),
				__( 'Settings saved successfully.', 'customer-email-verification' ),
				'settings_saved'
			);
		} catch ( Exception $e ) {
			CEV_Ajax_Response::send_server_error( $e->getMessage() );
		}
	}

	/**
	 * Per-section save handler.
	 *
	 * Each accordion on the Settings page POSTs only its own fields to
	 * this endpoint with a `cev_section` key. We dispatch to the
	 * matching settings-data method to figure out which fields belong
	 * to that section, then update ONLY those keys — without touching
	 * any other section's saved values.
	 *
	 * Toggle fields (`type === 'toogel'`) get special handling:
	 * unchecked toggles don't send any value, so we explicitly write 0
	 * for any toggle in the section that wasn't in the POST. Otherwise
	 * a user clicking "off" then Save wouldn't persist.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public function cev_save_section_fun() {
		try {
			// Use wp_verify_nonce directly — `check_admin_referer` calls
			// wp_die() on failure, which sends back an HTML "Are you
			// sure?" page that breaks the AJAX response. Verifying
			// manually lets us return a proper JSON error.
			$nonce = isset( $_POST[ self::NONCE_ACTION ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::NONCE_ACTION ] ) ) : '';
			if ( empty( $_POST ) || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
				CEV_Ajax_Response::send_nonce_error();
				return;
			}

			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				CEV_Ajax_Response::send_error(
					'forbidden',
					__( 'You do not have permission to update settings.', 'customer-email-verification' )
				);
				return;
			}

			$section = isset( $_POST['cev_section'] ) ? sanitize_key( wp_unslash( $_POST['cev_section'] ) ) : '';

			// Section → settings-data method map. Each method returns
			// the field definitions for that accordion.
			$section_map = array(
				'signup_verification'   => 'get_cev_signup_verification_settings_data',
				'checkout_verification' => 'get_cev_checkout_verification_settings_data',
				'general'               => 'get_cev_general_settings_data',
				'login_auth'            => 'get_cev_settings_data_login_otp',
				'two_factor'            => 'get_cev_2fa_settings_data',
				'spam_protection'       => 'get_cev_spam_protection_settings_data',
				'advanced'              => 'get_cev_advanced_settings_data',
			);

			if ( ! isset( $section_map[ $section ] ) ) {
				CEV_Ajax_Response::send_error(
					'invalid_section',
					__( 'Unknown settings section.', 'customer-email-verification' )
				);
				return;
			}

			$method = $section_map[ $section ];
			if ( ! method_exists( $this, $method ) ) {
				CEV_Ajax_Response::send_error(
					'missing_method',
					__( 'Settings handler is not available.', 'customer-email-verification' )
				);
				return;
			}
			$fields = $this->{$method}();

			// Build a lookup of textarea field keys so they keep their
			// newlines through sanitisation.
			$textarea_keys = array();
			foreach ( $fields as $field_key => $field_def ) {
				if ( isset( $field_def['type'] ) && 'textarea' === $field_def['type'] ) {
					$textarea_keys[ $field_key ] = true;
				}
			}

			// Sanitise POST.
			$sanitized_post = array();
			foreach ( $_POST as $key => $value ) {
				$clean_key = sanitize_key( $key );
				if ( is_array( $value ) ) {
					$sanitized_post[ $clean_key ] = array_map( 'sanitize_text_field', wp_unslash( $value ) );
				} elseif ( isset( $textarea_keys[ $clean_key ] ) ) {
					$sanitized_post[ $clean_key ] = sanitize_textarea_field( wp_unslash( $value ) );
				} else {
					$sanitized_post[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
				}
			}

			// Toggle fields — explicitly set to 0 if not present so an
			// "off" toggle persists. Limited to toggles in THIS section
			// so we don't accidentally clear a toggle from another section.
			foreach ( $fields as $field_key => $field_def ) {
				if ( isset( $field_def['type'] ) && 'toogel' === $field_def['type'] ) {
					if ( isset( $sanitized_post[ $field_key ] ) ) {
						$value = $sanitized_post[ $field_key ];
						if ( is_array( $value ) ) {
							$value = end( $value );
						}
						$this->update_setting( $field_key, $value );
					} else {
						$this->update_setting( $field_key, 0 );
					}
				}
			}

			// Verification-type radio (Email verification section only) —
			// has the same off-toggle problem as a toggle, plus it's a
			// special "select" field that lives in update_toggle_fields.
			if ( 'signup_verification' === $section && isset( $sanitized_post[ self::VERIFICATION_TYPE_OPTION ] ) ) {
				$this->update_setting( self::VERIFICATION_TYPE_OPTION, $sanitized_post[ self::VERIFICATION_TYPE_OPTION ] );
			}

			// Update non-toggle fields (dropdowns, multi-selects, text,
			// textarea, etc.) using the existing helper.
			$this->update_settings( $fields, $sanitized_post );

			// Email-verification section also owns the verification email
			// body which depends on verification_type. Replicate that
			// special case from the legacy "Save all" handler.
			if ( 'signup_verification' === $section ) {
				$this->update_verification_email_body( $sanitized_post );
			}

			CEV_Ajax_Response::send_success(
				array(
					'isUpdated' => true,
					'section'   => $section,
				),
				__( 'Settings saved.', 'customer-email-verification' ),
				'settings_saved'
			);
		} catch ( Exception $e ) {
			CEV_Ajax_Response::send_server_error( $e->getMessage() );
		}
	}

	/**
	 * Update toggle fields that need special handling.
	 *
	 * @since 1.0.0
	 * @param array $sanitized_data Sanitized POST data.
	 * @return void
	 */
	private function update_toggle_fields( $sanitized_data ) {
		$toggle_fields = array(
			'cev_enable_email_verification',
			'cev_enable_email_verification_checkout',
			'cev_enable_login_authentication',
			'cev_enable_2fa',
			'cev_block_disposable_emails',
			'cev_validate_mx',
			'cev_enable_b2b_allowlist',
			'cev_enable_blocked_emails',
			'cev_enable_paid_order_gatekeeping',
			'cev_auto_cleanup_enabled',
			'cev_send_reengagement_emails',
			self::VERIFICATION_TYPE_OPTION,
		);

		foreach ( $toggle_fields as $field ) {
			if ( isset( $sanitized_data[ $field ] ) ) {
				$value = $sanitized_data[ $field ];
				// Handle array values from checkboxes (hidden input + checkbox both submit).
				if ( is_array( $value ) ) {
					// Take the last value (checkbox value '1' if checked, or '0' if unchecked).
					$value = end( $value );
				}
				$this->update_setting( $field, $value );
			}
		}
	}

	/**
	 * Update verification email body based on verification type.
	 *
	 * @since 1.0.0
	 * @param array $sanitized_data Sanitized POST data.
	 * @return void
	 */
	private function update_verification_email_body( $sanitized_data ) {
		if ( isset( $sanitized_data[ self::VERIFICATION_TYPE_OPTION ] ) ) {
			$verification_type = $sanitized_data[ self::VERIFICATION_TYPE_OPTION ];
			// Handle array values from checkboxes (hidden input + checkbox both submit).
			if ( is_array( $verification_type ) ) {
				$verification_type = end( $verification_type );
			}
			$email_body = $this->get_verification_email_body( $verification_type );
			$this->update_setting( self::VERIFICATION_EMAIL_BODY_OPTION, $email_body );
		}
	}

	/**
	 * Update settings from a given settings array and request data.
	 *
	 * Iterates through settings array and updates each field value from
	 * the request data. Handles special field types like multiple_select
	 * and checkbox_select differently.
	 *
	 * @since 1.0.0
	 * @param array $settings The settings data array.
	 * @param array $request  The request data (typically $_POST).
	 * @return void
	 */
	private function update_settings( $settings, $request ) {
		foreach ( $settings as $key => $field ) {
			if ( isset( $request[ $key ] ) ) {
				// Handle multiple select fields.
				if ( isset( $field['type'] ) && 'multiple_select' === $field['type'] ) {
					$this->update_multiple_select_field( $key, $field, $request );
				} elseif ( isset( $field['type'] ) && 'checkbox_select' === $field['type'] ) {
					$this->update_checkbox_select_field( $key, $field, $request );
				} elseif ( isset( $field['type'] ) && 'category_messages' === $field['type'] ) {
					$this->update_category_messages_field( $key, $request );
				} elseif ( isset( $field['type'] ) && 'sms_gateway' === $field['type'] ) {
					$this->update_sms_gateway_field( $request );
				} else {
					// Handle checkbox/toggle fields that may have duplicate values.
					$value = $request[ $key ];
					if ( is_array( $value ) ) {
						// For checkbox/toggle fields, take the last value (checkbox value '1' if checked).
						$value = end( $value );
					}
					// Update standard fields (data is already sanitized).
					$this->update_setting( $key, $value );
				}
			} elseif ( isset( $field['type'] ) && 'multiple_select' === $field['type'] ) {
				// Clear multiple select field if not set.
				$this->update_setting( $key, '' );
			} elseif ( isset( $field['type'] ) && 'category_messages' === $field['type'] ) {
				// Clear per-category messages if none submitted.
				$this->update_setting( $key, array() );
			} elseif ( isset( $field['type'] ) && ( 'checkbox' === $field['type'] || 'toogel' === $field['type'] ) ) {
				// Set unchecked checkbox/toggle to 0 if not in request.
				$this->update_setting( $key, 0 );
			}
		}
	}

	/**
	 * Update a multiple select field.
	 *
	 * Processes selected options from a multiple select field and saves
	 * them as an array with keys representing options and values (1 or 0)
	 * indicating selection status.
	 *
	 * @since 1.0.0
	 * @param string $key     The field key.
	 * @param array  $field   The field data.
	 * @param array  $request The request data.
	 * @return void
	 */
	private function update_multiple_select_field( $key, $field, $request ) {
		if ( ! isset( $request[ $key ] ) || ! is_array( $request[ $key ] ) ) {
			return;
		}

		// Initialize all options as unselected.
		$roles = array();
		foreach ( $field['options'] as $option_key => $option_val ) {
			$roles[ $option_key ] = 0;
		}

		// Mark selected options (data is already sanitized).
		$selected_options = $request[ $key ];
		foreach ( $selected_options as $selected_option ) {
			if ( isset( $roles[ $selected_option ] ) ) {
				$roles[ $selected_option ] = 1;
			}
		}

		$this->update_setting( $key, $roles );
	}

	/**
	 * Update a checkbox_select field.
	 *
	 * Updates both the checkbox state and the associated select field value.
	 *
	 * @since 1.0.0
	 * @param string $key     The field key.
	 * @param array  $field   The field data.
	 * @param array  $request The request data.
	 * @return void
	 */
	private function update_checkbox_select_field( $key, $field, $request ) {
		// Update checkbox value (data is already sanitized).
		if ( isset( $request[ $key ] ) ) {
			$value = $request[ $key ];
			// Handle array values from checkboxes (hidden input + checkbox both submit).
			if ( is_array( $value ) ) {
				$value = end( $value );
			}
			$this->update_setting( $key, $value );
		} else {
			// Set unchecked checkbox to 0.
			$this->update_setting( $key, 0 );
		}

		// Update associated select field if present (data is already sanitized).
		if ( isset( $field['select']['id'] ) && isset( $request[ $field['select']['id'] ] ) ) {
			$select_value = $request[ $field['select']['id'] ];
			// Handle array values if present.
			if ( is_array( $select_value ) ) {
				$select_value = end( $select_value );
			}
			$this->update_setting( $field['select']['id'], $select_value );
		}
	}

	/**
	 * Get verification email body content based on verification type.
	 *
	 * Returns the appropriate email body template based on the verification
	 * method selected (OTP only).
	 *
	 * @since 1.0.0
	 * @param string $verification_type The type of verification: 'otp'.
	 * @return string The email body content with placeholders.
	 */
	private function get_verification_email_body( $verification_type ) {
		$email_templates = array(
			'otp'  => __( 'Thank you for signing up for {site_title}, to activate your account, we need to verify your email address.<p>Your verification code: <strong>{cev_user_verification_pin}</strong></p>', 'customer-email-verification' ),
		);

		// Default to OTP verification if type not found.
		$default_template = __( 'Thank you for signing up for {site_title}, to activate your account, we need to verify your email address.<p>Your verification code: <strong>{cev_user_verification_pin}</strong></p>', 'customer-email-verification' );

		return isset( $email_templates[ $verification_type ] ) ? $email_templates[ $verification_type ] : $default_template;
	}
}
