<?php
/**
 * Analytics tab template (ZUI) — Verification Analytics dashboard.
 *
 * Visual shell only; everything dynamic (KPI numbers, chart series, funnel,
 * verification status, top domains, range label) is populated by
 * cev-analytics.js via the cev_analytics_data AJAX endpoint. All data-cev-*
 * hooks are preserved; the JS now injects .zui-meter / .zui-ranklist markup.
 *
 * @package Customer_Email_Verification
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Restore the user's last chosen range (and custom dates) on open;
// fall back to "Last 30 days" when no preference has been saved yet
// or when the saved value isn't one of the allowed range keys.
$saved_range = (string) get_user_meta( get_current_user_id(), 'cev_analytics_range', true );
if ( ! in_array( $saved_range, array( '7d', '30d', '90d', 'custom' ), true ) ) {
	$saved_range = '30d';
}
$saved_from = (string) get_user_meta( get_current_user_id(), 'cev_analytics_from', true );
$saved_to   = (string) get_user_meta( get_current_user_id(), 'cev_analytics_to', true );

// Friendly display formatter for the .zui-datepicker visible input
// (the hidden ISO field still feeds the analytics AJAX).
$cev_format_date_display = function ( $iso ) {
	if ( '' === $iso ) {
		return '';
	}
	$ts = strtotime( $iso );
	return $ts ? date_i18n( 'M j, Y', $ts ) : '';
};
$cev_calendar_icon_svg = '<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>';

$cev_chevron = '<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>';

/**
 * Echoes already-safe HTML (built from constant string maps, no user input).
 * One centralised phpcs:ignore so callsites stay free of trailing same-line
 * suppression comments — those are unreliable on the audit server's PHPCS
 * for the EscapeOutput sniff.
 */
$cev_print_html = function ( $html ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Callers pass SVG / HTML built from constant strings with no user input; wp_kses_post would strip required SVG attributes.
	echo $html;
};
?>
<section id="cev_content_analytics">
	<div class="cev-analytics" data-cev-analytics
		data-initial-range="<?php echo esc_attr( $saved_range ); ?>"
		data-initial-from="<?php echo esc_attr( $saved_from ); ?>"
		data-initial-to="<?php echo esc_attr( $saved_to ); ?>">

		<!-- Header + date range picker -->
		<div class="zui-section-header">
			<div class="zui-section-header__main">
				<span class="zui-section-header__icon">
					<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v18h18"></path><rect x="7" y="10" width="3" height="7" rx="1"></rect><rect x="12" y="6" width="3" height="11" rx="1"></rect><rect x="17" y="13" width="3" height="4" rx="1"></rect></svg>
				</span>
				<div class="zui-section-header__text">
					<div class="zui-section-header__titlewrap">
						<h2 class="zui-section-header__title"><?php esc_html_e( 'Verification analytics', 'customer-email-verification' ); ?></h2>
					</div>
					<p class="zui-section-header__sub" data-cev-range-label>—</p>
				</div>
			</div>
			<div class="zui-section-header__actions">
				<label for="cev_analytics_range" class="screen-reader-text"><?php esc_html_e( 'Date range', 'customer-email-verification' ); ?></label>
				<div class="zui-select-wrap">
					<select id="cev_analytics_range" class="zui-select" data-cev-range>
						<option value="7d"     <?php selected( $saved_range, '7d' ); ?>><?php esc_html_e( 'Last 7 days', 'customer-email-verification' ); ?></option>
						<option value="30d"    <?php selected( $saved_range, '30d' ); ?>><?php esc_html_e( 'Last 30 days', 'customer-email-verification' ); ?></option>
						<option value="90d"    <?php selected( $saved_range, '90d' ); ?>><?php esc_html_e( 'Last 90 days', 'customer-email-verification' ); ?></option>
						<option value="custom" <?php selected( $saved_range, 'custom' ); ?>><?php esc_html_e( 'Custom range…', 'customer-email-verification' ); ?></option>
					</select>
					<span class="zui-select-chevron"><?php $cev_print_html( $cev_chevron ); ?></span>
				</div>

				<div class="zui-control-group" data-cev-custom-range <?php echo 'custom' === $saved_range ? '' : 'hidden'; ?>>
					<div class="zui-datepicker" data-cev-datepicker>
						<div class="zui-datepicker__input">
							<input type="text" class="zui-input" readonly value="<?php echo esc_attr( $cev_format_date_display( $saved_from ) ); ?>" aria-label="<?php esc_attr_e( 'From date', 'customer-email-verification' ); ?>" data-cev-datepicker-display>
							<span class="zui-datepicker__icon"><?php $cev_print_html( $cev_calendar_icon_svg ); ?></span>
						</div>
						<input type="hidden" data-cev-from value="<?php echo esc_attr( $saved_from ); ?>">
					</div>
					<span>—</span>
					<div class="zui-datepicker" data-cev-datepicker>
						<div class="zui-datepicker__input">
							<input type="text" class="zui-input" readonly value="<?php echo esc_attr( $cev_format_date_display( $saved_to ) ); ?>" aria-label="<?php esc_attr_e( 'To date', 'customer-email-verification' ); ?>" data-cev-datepicker-display>
							<span class="zui-datepicker__icon"><?php $cev_print_html( $cev_calendar_icon_svg ); ?></span>
						</div>
						<input type="hidden" data-cev-to value="<?php echo esc_attr( $saved_to ); ?>">
					</div>
					<button type="button" class="zui-btn-soft" data-cev-apply-range><?php esc_html_e( 'Apply', 'customer-email-verification' ); ?></button>
				</div>
			</div>
		</div>

		<!-- Skeleton (shown during every fetch) -->
		<div data-cev-skeleton aria-hidden="true">
			<div class="zui-card-grid zui-card-grid--cols-4">
				<?php for ( $i = 0; $i < 4; $i++ ) : ?>
					<div class="zui-card zui-stat">
						<span class="zui-skeleton zui-skeleton--pill"></span>
						<span class="zui-skeleton zui-skeleton--lg"></span>
						<span class="zui-skeleton zui-skeleton--label"></span>
					</div>
				<?php endfor; ?>
			</div>
			<div class="zui-card zui-chart-card" style="margin-top:24px;">
				<span class="zui-skeleton zui-skeleton--label"></span>
				<div class="zui-skeleton zui-skeleton--chart"></div>
			</div>
		</div>

		<!-- In-flight loading (kept hidden — skeleton is the loading affordance) -->
		<div data-cev-loading hidden></div>

		<!-- Empty state -->
		<div class="zui-card zui-placeholder" data-cev-empty hidden style="text-align:center;">
			<svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="var(--zui-text-muted)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="margin:0 auto 8px;">
				<path d="M3 3v18h18"></path><path d="M7 14l4-4 4 4 5-5"></path>
			</svg>
			<p class="zui-placeholder__title"><?php esc_html_e( 'No verification activity yet', 'customer-email-verification' ); ?></p>
			<p class="zui-placeholder__text"><?php esc_html_e( 'Once your first customer signs up or a spam attempt is blocked, charts and stats will appear here. Try widening the date range.', 'customer-email-verification' ); ?></p>
		</div>

		<!-- Content -->
		<div data-cev-content hidden>

			<!-- KPI stat cards -->
			<div class="zui-card-grid zui-card-grid--cols-4">
				<div class="zui-card zui-stat">
					<span class="zui-stat__accent"></span>
					<div class="zui-stat__label"><?php esc_html_e( 'Total signups', 'customer-email-verification' ); ?></div>
					<div class="zui-stat__value" data-cev-kpi="signups">—</div>
					<div class="zui-stat__delta" data-cev-trend="signups"></div>
				</div>
				<div class="zui-card zui-stat">
					<span class="zui-stat__accent zui-stat__accent--success"></span>
					<div class="zui-stat__label"><?php esc_html_e( 'Verified', 'customer-email-verification' ); ?></div>
					<div class="zui-stat__value" data-cev-kpi="verified">—</div>
					<div class="zui-stat__delta" data-cev-trend="verified"></div>
				</div>
				<div class="zui-card zui-stat">
					<span class="zui-stat__accent zui-stat__accent--danger"></span>
					<div class="zui-stat__label"><?php esc_html_e( 'Spam blocked', 'customer-email-verification' ); ?></div>
					<div class="zui-stat__value" data-cev-kpi="blocked">—</div>
					<div class="zui-stat__delta" data-cev-trend="blocked"></div>
				</div>
				<div class="zui-card zui-stat">
					<span class="zui-stat__accent zui-stat__accent--warning"></span>
					<div class="zui-stat__label"><?php esc_html_e( 'Avg. time to verify', 'customer-email-verification' ); ?></div>
					<div class="zui-stat__value" data-cev-kpi="avg">—</div>
					<div class="zui-stat__delta" data-cev-trend="avg"></div>
				</div>
			</div>

			<!-- Time-series chart -->
			<div class="zui-card zui-chart-card" style="margin-top:24px;">
				<h3 class="zui-card__title"><?php esc_html_e( 'Signups vs verified vs blocked', 'customer-email-verification' ); ?></h3>
				<p class="zui-card__sub"><?php esc_html_e( 'Daily activity across the selected period.', 'customer-email-verification' ); ?></p>
				<div class="cev-analytics__chart-wrap" style="margin-top:16px;">
					<canvas data-cev-chart></canvas>
				</div>
				<div class="zui-chart-legend">
					<span class="zui-chart-legend__item"><span class="zui-chart-legend__dot" style="background:#4338ca;"></span><?php esc_html_e( 'Signups', 'customer-email-verification' ); ?></span>
					<span class="zui-chart-legend__item"><span class="zui-chart-legend__dot" style="background:#047857;"></span><?php esc_html_e( 'Verified', 'customer-email-verification' ); ?></span>
					<span class="zui-chart-legend__item"><span class="zui-chart-legend__dot" style="background:#b91c1c;"></span><?php esc_html_e( 'Blocked', 'customer-email-verification' ); ?></span>
				</div>
			</div>

			<!-- Funnel + verification status -->
			<div class="zui-card-grid zui-card-grid--cols-2" style="margin-top:24px;">
				<div class="zui-card">
					<div class="zui-card__head">
						<h3 class="zui-card__title"><?php esc_html_e( 'Verification funnel', 'customer-email-verification' ); ?></h3>
						<p class="zui-card__sub"><?php esc_html_e( 'How many of your signups complete verification.', 'customer-email-verification' ); ?></p>
					</div>
					<div class="zui-card__body" data-cev-funnel></div>
				</div>
				<div class="zui-card">
					<div class="zui-card__head">
						<h3 class="zui-card__title"><?php esc_html_e( 'Verification status', 'customer-email-verification' ); ?></h3>
						<p class="zui-card__sub"><?php esc_html_e( 'Breakdown of registered users by verification state.', 'customer-email-verification' ); ?></p>
					</div>
					<div class="zui-card__body">
						<div data-cev-status></div>
						<p class="zui-row__desc" data-cev-status-empty hidden><?php esc_html_e( 'No registered users in this period.', 'customer-email-verification' ); ?></p>
					</div>
				</div>
			</div>

			<!-- Top blocked domains -->
			<div class="zui-card" style="margin-top:24px;">
				<div class="zui-card__head">
					<h3 class="zui-card__title"><?php esc_html_e( 'Top blocked domains', 'customer-email-verification' ); ?></h3>
					<p class="zui-card__sub"><?php esc_html_e( 'Where the spam is coming from.', 'customer-email-verification' ); ?></p>
				</div>
				<div class="zui-card__body">
					<div class="zui-ranklist" data-cev-top-domains></div>
					<p class="zui-row__desc" data-cev-top-empty hidden><?php esc_html_e( 'No blocks recorded in this period.', 'customer-email-verification' ); ?></p>
				</div>
			</div>

			<!-- AI risk scoring (only shown when signups were scored in this period) -->
			<div class="zui-card" style="margin-top:24px;" data-cev-ai-risk hidden>
				<div class="zui-card__head">
					<h3 class="zui-card__title"><?php esc_html_e( 'AI risk scoring', 'customer-email-verification' ); ?></h3>
					<p class="zui-card__sub"><?php esc_html_e( 'How the risk engine scored signups in this period.', 'customer-email-verification' ); ?></p>
				</div>
				<div class="zui-card__body">
					<div class="cev-ai-risk-stats">
						<div class="cev-ai-risk-stat">
							<div class="cev-ai-risk-stat__value" data-cev-ai-avg>—</div>
							<div class="cev-ai-risk-stat__label"><?php esc_html_e( 'Avg. signup risk', 'customer-email-verification' ); ?></div>
						</div>
						<div class="cev-ai-risk-stat">
							<div class="cev-ai-risk-stat__value" data-cev-ai-blocked>—</div>
							<div class="cev-ai-risk-stat__label"><?php esc_html_e( 'Blocked by AI', 'customer-email-verification' ); ?></div>
						</div>
						<div class="cev-ai-risk-stat">
							<div class="cev-ai-risk-stat__value" data-cev-ai-scored>—</div>
							<div class="cev-ai-risk-stat__label"><?php esc_html_e( 'Signups scored', 'customer-email-verification' ); ?></div>
						</div>
					</div>
					<h4 class="cev-ai-risk-reasons__title"><?php esc_html_e( 'Top risk reasons', 'customer-email-verification' ); ?></h4>
					<div class="zui-ranklist" data-cev-ai-reasons></div>
					<p class="zui-row__desc" data-cev-ai-reasons-empty hidden><?php esc_html_e( 'No risk signals triggered in this period.', 'customer-email-verification' ); ?></p>
				</div>
			</div>

		</div>
	</div>
</section>
