<?php
/**
 * Maintenance Sub-tab Template (ZUI)
 *
 * Rendered inside the Unverified Users → Maintenance section. Four maintenance
 * features, each a .zui-card (head title + its fields + a .zui-card__foot with
 * a status note and action buttons). One <form> posts every setting via
 * cev_maintenance_form_update. All button hooks / nonces / ids are preserved.
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Stats from the Maintenance helper (single source of truth).
$cev_stats = array(
	'pending'                 => 0,
	'verified'                => 0,
	'total'                   => 0,
	'oldest_pending_age_days' => 0,
	'last_cleanup_at'         => '',
	'last_cleanup_count'      => 0,
);
if ( class_exists( 'CEV_Pro_Maintenance' ) ) {
	$cev_stats = CEV_Pro_Maintenance::get_instance()->get_stats();
}

// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only page reference for the form action URL; no state change.
$cev_page        = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
$cev_form_action = admin_url( 'admin.php?page=' . $cev_page );

$cev_last_cleanup_label = '';
if ( ! empty( $cev_stats['last_cleanup_at'] ) ) {
	$ts = strtotime( $cev_stats['last_cleanup_at'] );
	if ( $ts ) {
		$cev_last_cleanup_label = human_time_diff( $ts, current_time( 'timestamp' ) );
	}
}

// User-cleanup stats (Task 5c).
$cev_user_cleanup_stats = array(
	'eligible'           => null,
	'is_partial'         => false,
	'last_cleanup_at'    => '',
	'last_cleanup_count' => 0,
);
if ( class_exists( 'CEV_Pro_Maintenance' ) ) {
	$cev_user_cleanup_stats = CEV_Pro_Maintenance::get_instance()->get_user_cleanup_stats();
}
$cev_last_user_cleanup_label = '';
if ( ! empty( $cev_user_cleanup_stats['last_cleanup_at'] ) ) {
	$ts = strtotime( $cev_user_cleanup_stats['last_cleanup_at'] );
	if ( $ts ) {
		$cev_last_user_cleanup_label = human_time_diff( $ts, current_time( 'timestamp' ) );
	}
}

// Re-engagement reminder stats (Task 5d).
$cev_reengagement_stats = array(
	'sent_30d'   => 0,
	'last_at'    => '',
	'last_count' => 0,
	'intervals'  => array(),
);
if ( class_exists( 'CEV_Pro_Maintenance' ) ) {
	$cev_reengagement_stats = CEV_Pro_Maintenance::get_instance()->get_reengagement_stats();
}
$cev_last_reengagement_label = '';
if ( ! empty( $cev_reengagement_stats['last_at'] ) ) {
	$ts = strtotime( $cev_reengagement_stats['last_at'] );
	if ( $ts ) {
		$cev_last_reengagement_label = human_time_diff( $ts, current_time( 'timestamp' ) );
	}
}

// Force re-verify (Tools) stats.
$cev_force_reverify_stats = array(
	'last_at'    => '',
	'last_count' => 0,
	'running'    => false,
);
if ( class_exists( 'CEV_Pro_Maintenance' ) ) {
	$cev_force_reverify_stats = CEV_Pro_Maintenance::get_instance()->get_force_reverify_stats();
}
$cev_last_force_reverify_label = '';
if ( ! empty( $cev_force_reverify_stats['last_at'] ) ) {
	$ts = strtotime( $cev_force_reverify_stats['last_at'] );
	if ( $ts ) {
		$cev_last_force_reverify_label = date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts );
	}
}

// Deep-link to the email customizer pre-filtered to the re-engagement preview.
$cev_customizer_url = admin_url( 'admin.php?page=cev_customizer&preview=email_reengagement' );
?>

<form method="post" id="cev_maintenance_form" action="<?php echo esc_url( $cev_form_action ); ?>" autocomplete="off">

	<?php /* Section 1 — Auto-cleanup of stale verification log entries (non-destructive). */ ?>
	<div class="zui-card">
		<div class="zui-card__head">
			<h3 class="zui-card__title"><?php esc_html_e( 'Auto-cleanup unverified records', 'customer-email-verification' ); ?></h3>
		</div>
		<?php
		if ( isset( $admin_instance ) ) {
			$admin_instance->render_settings_fields( $admin_instance->get_cev_maintenance_settings_data(), false );
		}
		?>
		<div class="zui-card__foot">
			<span class="zui-card__foot-note">
				<?php if ( ! empty( $cev_last_cleanup_label ) ) : ?>
					<?php
					printf(
						/* translators: 1: time ago, 2: number of records cleaned */
						esc_html__( 'Last run: %1$s ago — cleaned %2$d records.', 'customer-email-verification' ),
						esc_html( $cev_last_cleanup_label ),
						(int) $cev_stats['last_cleanup_count']
					);
					?>
				<?php else : ?>
					<?php esc_html_e( 'Cleanup has not run yet.', 'customer-email-verification' ); ?>
				<?php endif; ?>
			</span>
			<div class="zui-card__foot-actions">
				<button type="button" class="zui-btn-soft cev_run_cleanup_now" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_run_cleanup_nonce' ) ); ?>">
					<?php esc_html_e( 'Run cleanup now', 'customer-email-verification' ); ?>
				</button>
			</div>
		</div>
	</div>

	<?php /* Section 2 — Auto-delete unverified WP user accounts (destructive, Task 5c). */ ?>
	<div class="zui-card">
		<div class="zui-card__head">
			<h3 class="zui-card__title"><?php esc_html_e( 'Auto-delete unverified user accounts', 'customer-email-verification' ); ?></h3>
		</div>
		<?php
		if ( isset( $admin_instance ) ) {
			$admin_instance->render_settings_fields( $admin_instance->get_cev_user_cleanup_settings_data(), false );
		}
		?>
		<div class="cev_user_cleanup_preview" style="display:none;" aria-live="polite"></div>
		<?php
		// The eligible-count is NOT computed during page render (on a large
		// store that scan outlasted the gateway timeout and 504'd the whole
		// Settings page). The note shows the cached value when there is one;
		// otherwise admin.js fetches it via `cev_user_cleanup_count` once the
		// card is visible (data-cev-needs-count="1").
		$cev_user_cleanup_enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_auto_delete_unverified_users', 0 );
		$cev_user_cleanup_count_known = ( null !== $cev_user_cleanup_stats['eligible'] );
		$cev_user_cleanup_needs_count = ( 1 === $cev_user_cleanup_enabled && ! $cev_user_cleanup_count_known ) ? '1' : '0';
		?>
		<div class="zui-card__foot">
			<span class="zui-card__foot-note cev_user_cleanup_eligible" aria-live="polite" data-cev-needs-count="<?php echo esc_attr( $cev_user_cleanup_needs_count ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_user_cleanup_count_nonce' ) ); ?>">
				<?php if ( 1 !== $cev_user_cleanup_enabled && ! empty( $cev_last_user_cleanup_label ) ) : ?>
					<?php
					printf(
						/* translators: 1: time ago, 2: number of users deleted */
						esc_html__( 'Last run: %1$s ago — deleted %2$d users.', 'customer-email-verification' ),
						esc_html( $cev_last_user_cleanup_label ),
						(int) $cev_user_cleanup_stats['last_cleanup_count']
					);
					?>
				<?php elseif ( 1 !== $cev_user_cleanup_enabled ) : ?>
					<?php esc_html_e( 'Enable auto-delete to see how many accounts are eligible.', 'customer-email-verification' ); ?>
				<?php elseif ( $cev_user_cleanup_count_known && class_exists( 'CEV_Pro_Maintenance' ) ) : ?>
					<?php echo esc_html( CEV_Pro_Maintenance::get_instance()->user_cleanup_eligible_message( (int) $cev_user_cleanup_stats['eligible'], (bool) $cev_user_cleanup_stats['is_partial'] ) ); ?>
				<?php else : ?>
					<?php esc_html_e( 'Counting eligible accounts…', 'customer-email-verification' ); ?>
				<?php endif; ?>
			</span>
			<div class="zui-card__foot-actions">
				<button type="button" class="zui-btn-soft cev_preview_unverified_users" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_preview_users_nonce' ) ); ?>">
					<?php esc_html_e( 'Preview affected users', 'customer-email-verification' ); ?>
				</button>
				<button type="button" class="zui-btn-primary cev_run_user_cleanup_now" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_run_user_cleanup_nonce' ) ); ?>">
					<?php esc_html_e( 'Run now', 'customer-email-verification' ); ?>
				</button>
			</div>
		</div>
	</div>

	<?php /* Section 3 — Re-engagement reminder emails (Task 5d). */ ?>
	<div class="zui-card">
		<div class="zui-card__head">
			<h3 class="zui-card__title"><?php esc_html_e( 'Re-engagement reminder emails', 'customer-email-verification' ); ?></h3>
			<p class="zui-card__sub">
				<?php esc_html_e( 'Bring lapsed sign-ups back. The plugin emails users who never finished verifying — at the intervals you choose — with a styled reminder and a one-click link to complete sign-up.', 'customer-email-verification' ); ?>
				<a href="<?php echo esc_url( $cev_customizer_url ); ?>" class="cev_reengagement_customize_link"><?php esc_html_e( 'Customize email →', 'customer-email-verification' ); ?></a>
			</p>
		</div>
		<?php
		if ( isset( $admin_instance ) ) {
			$admin_instance->render_settings_fields( $admin_instance->get_cev_reengagement_settings_data(), false );
		}
		?>
		<div class="zui-card__foot">
			<span class="zui-card__foot-note">
				<?php if ( $cev_reengagement_stats['sent_30d'] > 0 ) : ?>
					<?php
					printf(
						/* translators: %d: reminders sent in last 30 days */
						esc_html( _n( '%d reminder sent in the last 30 days.', '%d reminders sent in the last 30 days.', (int) $cev_reengagement_stats['sent_30d'], 'customer-email-verification' ) ),
						(int) $cev_reengagement_stats['sent_30d']
					);
					?>
				<?php elseif ( ! empty( $cev_last_reengagement_label ) ) : ?>
					<?php
					printf(
						/* translators: 1: time ago, 2: number of reminders sent */
						esc_html__( 'Last run: %1$s ago — sent %2$d reminders.', 'customer-email-verification' ),
						esc_html( $cev_last_reengagement_label ),
						(int) $cev_reengagement_stats['last_count']
					);
					?>
				<?php else : ?>
					<?php esc_html_e( 'No reminders sent yet.', 'customer-email-verification' ); ?>
				<?php endif; ?>
			</span>
			<div class="zui-card__foot-actions">
				<button type="button" class="zui-btn-soft cev_reengagement_send_test" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_send_test_reengagement_nonce' ) ); ?>">
					<?php esc_html_e( 'Send test', 'customer-email-verification' ); ?>
				</button>
				<button type="button" class="zui-btn-primary cev_reengagement_run_now" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_run_reengagement_nonce' ) ); ?>">
					<?php esc_html_e( 'Run now', 'customer-email-verification' ); ?>
				</button>
			</div>
		</div>
	</div>

	<?php /* Section 4 — Tools: Force re-verify all customers. */ ?>
	<div class="zui-card">
		<div class="zui-card__head">
			<h3 class="zui-card__title"><?php esc_html_e( 'Tools', 'customer-email-verification' ); ?></h3>
			<p class="zui-card__sub">
				<?php esc_html_e( 'Force re-verify your customer base — e.g. after a spam attack, or on a fresh install over legacy accounts. Every verified customer is marked unverified and must re-confirm their email on their next login. Administrators, editors and shop managers are never affected. Runs in the background; large stores are processed in batches.', 'customer-email-verification' ); ?>
			</p>
		</div>
		<div class="zui-card__foot">
			<span class="zui-card__foot-note">
				<?php if ( ! empty( $cev_force_reverify_stats['running'] ) ) : ?>
					<?php esc_html_e( 'Re-verify in progress… customers are being marked unverified in the background.', 'customer-email-verification' ); ?>
				<?php elseif ( ! empty( $cev_last_force_reverify_label ) ) : ?>
					<?php
					printf(
						/* translators: 1: number of users, 2: date and time */
						esc_html__( 'Last bulk re-verify: %1$d users on %2$s.', 'customer-email-verification' ),
						(int) $cev_force_reverify_stats['last_count'],
						esc_html( $cev_last_force_reverify_label )
					);
					?>
				<?php else : ?>
					<?php esc_html_e( 'Has not run yet.', 'customer-email-verification' ); ?>
				<?php endif; ?>
			</span>
			<div class="zui-card__foot-actions">
				<button type="button" class="zui-btn-soft cev_force_reverify_all" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_force_reverify_nonce' ) ); ?>">
					<?php esc_html_e( 'Force re-verify all customers', 'customer-email-verification' ); ?>
				</button>
			</div>
		</div>
	</div>

	<?php // The Save button lives in the Maintenance section header (cev_users_tab.php) and submits this form via its form="cev_maintenance_form" attribute. ?>
	<?php
	// Same nonce action/name as the Settings form (the maintenance AJAX
	// handlers verify `cev_settings_form_nonce`), but emitted with a UNIQUE id
	// — the Settings form already outputs an element with
	// id="cev_settings_form_nonce", and an id must be unique per page.
	?>
	<input type="hidden" id="cev_maintenance_form_nonce" name="cev_settings_form_nonce" value="<?php echo esc_attr( wp_create_nonce( 'cev_settings_form_nonce' ) ); ?>" />
	<?php wp_referer_field(); ?>
	<input type="hidden" name="action" value="cev_maintenance_form_update">
</form>
